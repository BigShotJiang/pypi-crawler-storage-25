"""Tests for self-referential policy invariants (v0.13.0).

Covers both shipped behaviours:

* ``InstabilityGuard`` -- rejection-triggered tightening that auto-loosens
  after a quiet period. Exercises the hot path directly and through the
  daemon, composes with a ``SpendingCap`` for shared-variable projection,
  and compiles the z3 body to prove fragment membership.
* ``MergeFailureCooldown`` -- daemon-level short-circuit after a merge
  conflict. Exercised via ``merge_branch`` ops against a real daemon,
  with rehydration from the sidecar JSON on restart.

Acceptance Test 3 (``test_acceptance_3_repeated_failures_trigger_stricter_policy``)
is the load-bearing end-to-end check the patch spec calls out.
"""
from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.invariants import InvariantError, SpendingCap
from adapter.payment_intent_matcher import PaymentIntent
from adapter.self_ref_policy import (
    InstabilityGuard,
    MergeFailureCooldown,
    MergeFailureCooldownError,
    build_merge_failure_cooldown,
)
from daemon.server import CageDaemon


def _intent(
    *,
    amount: str,
    provider: str = "anthropic",
    counterparty: str = "v",
    timestamp_unix: int = 1_700_000_000,
    currency: str = "USDC",
) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency=currency,
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=timestamp_unix,
        metadata={},
        request_id=None,
    )


# ── InstabilityGuard unit tests ─────────────────────────────────────────────


class TestInstabilityGuardConstruction:
    def test_valid_construction(self) -> None:
        g = InstabilityGuard(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        assert g.provider == "anthropic"
        assert g.currency == "USDC"

    def test_empty_provider_rejected(self) -> None:
        with pytest.raises(InvariantError):
            InstabilityGuard(
                provider="",
                reject_threshold=3,
                window_seconds=60,
                tighten_to=Decimal("5"),
                recovery_seconds=300,
            )

    @pytest.mark.parametrize(
        "bad",
        [
            {"reject_threshold": 0},
            {"reject_threshold": -1},
            {"window_seconds": 0},
            {"recovery_seconds": 0},
            {"tighten_to": Decimal("0")},
            {"tighten_to": Decimal("-1")},
        ],
    )
    def test_invalid_numeric_args_rejected(self, bad) -> None:
        kwargs = dict(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        kwargs.update(bad)
        with pytest.raises(InvariantError):
            InstabilityGuard(**kwargs)

    def test_frozen_dataclass_is_immutable(self) -> None:
        g = InstabilityGuard(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        with pytest.raises(Exception):
            g.reject_threshold = 99  # type: ignore[misc]


class TestInstabilityGuardCheckPayment:
    GUARD = InstabilityGuard(
        provider="anthropic",
        reject_threshold=3,
        window_seconds=60,
        tighten_to=Decimal("5"),
        recovery_seconds=300,
    )

    def test_below_threshold_permits_over_tighten(self) -> None:
        now = 1_700_000_100
        rejects = [_intent(amount="10", timestamp_unix=now - 30)]
        intent = _intent(amount="10", timestamp_unix=now)
        assert self.GUARD.check_payment(intent, history=(), rejects=rejects) is None

    def test_other_provider_ignored(self) -> None:
        now = 1_700_000_100
        rejects = [
            _intent(amount="10", provider="openai", timestamp_unix=now - i)
            for i in range(1, 4)
        ]
        intent = _intent(amount="10", provider="openai", timestamp_unix=now)
        # Guard only watches anthropic, so openai is untouched.
        assert self.GUARD.check_payment(intent, history=(), rejects=rejects) is None

    def test_crossing_threshold_tightens(self) -> None:
        now = 1_700_000_100
        rejects = [
            _intent(amount="10", timestamp_unix=now - i * 5)
            for i in range(1, 4)
        ]
        intent = _intent(amount="10", timestamp_unix=now)
        v = self.GUARD.check_payment(intent, history=(), rejects=rejects)
        assert v is not None
        assert v.rule_id == "instability_guard"
        assert "anthropic" in v.reason_text
        assert "10" in v.reason_text

    def test_tightened_under_cap_still_permits(self) -> None:
        now = 1_700_000_100
        rejects = [
            _intent(amount="10", timestamp_unix=now - i * 5)
            for i in range(1, 4)
        ]
        intent = _intent(amount="3", timestamp_unix=now)
        assert self.GUARD.check_payment(intent, history=(), rejects=rejects) is None

    def test_tighten_exactly_at_cap_permits(self) -> None:
        now = 1_700_000_100
        rejects = [
            _intent(amount="10", timestamp_unix=now - i * 5)
            for i in range(1, 4)
        ]
        intent = _intent(amount="5", timestamp_unix=now)
        assert self.GUARD.check_payment(intent, history=(), rejects=rejects) is None

    def test_old_rejects_fall_out_of_window(self) -> None:
        now = 1_700_000_100
        # All rejects older than 60s (the window). Guard should be quiet.
        rejects = [
            _intent(amount="10", timestamp_unix=now - 120 - i)
            for i in range(3)
        ]
        intent = _intent(amount="10", timestamp_unix=now)
        assert self.GUARD.check_payment(intent, history=(), rejects=rejects) is None

    def test_recovery_window_restores_cap(self) -> None:
        # 3 rejects inside window -> guard active. After recovery_seconds
        # pass without new rejects, guard fades.
        reject_ts = 1_700_000_000
        rejects = [
            _intent(amount="10", timestamp_unix=reject_ts - i * 5)
            for i in range(3)
        ]
        # Query at reject_ts + 301s (> recovery_seconds=300). Note that
        # the reject window in this test is wider than recovery, so the
        # window cutoff still includes some rejects but the recovery
        # threshold has passed.
        guard = InstabilityGuard(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=3600,  # very wide window
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        later = reject_ts + 301
        intent = _intent(amount="10", timestamp_unix=later)
        assert guard.check_payment(intent, history=(), rejects=rejects) is None

    def test_currency_mismatch_not_scoped(self) -> None:
        # Guard is USDC-scoped. An intent in another currency is outside
        # the guard's scope and flows to the next invariant.
        now = 1_700_000_100
        rejects = [
            _intent(amount="10", timestamp_unix=now - i * 5)
            for i in range(1, 4)
        ]
        eth = _intent(
            amount="10", timestamp_unix=now, currency="ETH",
            counterparty="e",
        )
        assert self.GUARD.check_payment(eth, history=(), rejects=rejects) is None


class TestInstabilityGuardActiveFor:
    def test_active_for_follows_check_payment(self) -> None:
        guard = InstabilityGuard(
            provider="anthropic",
            reject_threshold=2,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        now = 1_700_000_100
        rejects = [
            _intent(amount="10", timestamp_unix=now - 10),
            _intent(amount="10", timestamp_unix=now - 20),
        ]
        assert guard.active_for(rejects, now) is True
        # After recovery elapses with no new rejects the guard fades.
        assert guard.active_for(rejects, now + 301) is False


# ── z3 fragment composition ─────────────────────────────────────────────────


z3 = pytest.importorskip("z3", reason="z3-solver not installed")


class TestInstabilityGuardZ3Composition:
    def test_body_compiles_and_is_sat(self) -> None:
        guard = InstabilityGuard(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        constraints, summary = guard.compile_z3_body(unroll_steps=5)
        assert summary["class"] == "InstabilityGuard"
        assert summary["unroll_steps"] == 5
        solver = z3.Solver()
        for c in constraints:
            solver.add(c)
        assert solver.check() == z3.sat, "valid guard must compose SAT"

    def test_shared_variable_projection_with_spending_cap(self) -> None:
        """Two invariants on overlapping domains must stay consistent.

        This test proves there is no false cross-fragment conflict
        between an InstabilityGuard (tightens to 5 USDC) and a
        SpendingCap (max 100 USDC per window): the tighter rule is a
        subset, so the composition is SAT.
        """
        from adapter.z3_compiler import compile_invariant_v2
        guard = InstabilityGuard(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        cap = SpendingCap(
            max_amount=Decimal("100"),
            scope="per_window",
            window_seconds=60,
        )
        guard_cs, _ = guard.compile_z3_body(unroll_steps=5)
        cap_cs, _ = compile_invariant_v2(cap, unroll_steps=5)
        solver = z3.Solver()
        for c in guard_cs:
            solver.add(c)
        for c in cap_cs:
            solver.add(c)
        assert solver.check() == z3.sat, (
            "InstabilityGuard + SpendingCap must compose SAT "
            "(no false cross-fragment conflict)"
        )


# ── MergeFailureCooldown unit tests ─────────────────────────────────────────


class TestMergeFailureCooldown:
    def test_disabled_when_zero_seconds(self) -> None:
        c = MergeFailureCooldown(cooldown_seconds=0)
        assert c.enabled is False
        assert c.trigger("main") == 0
        assert c.status_for("main") is None

    def test_negative_seconds_rejected(self) -> None:
        with pytest.raises(MergeFailureCooldownError):
            MergeFailureCooldown(cooldown_seconds=-1)

    def test_trigger_sets_cooldown(self) -> None:
        c = MergeFailureCooldown(cooldown_seconds=60)
        expiry = c.trigger("main", now_unix=1000)
        assert expiry == 1060
        assert c.status_for("main", now_unix=1030) == 1060

    def test_cooldown_elapses(self) -> None:
        c = MergeFailureCooldown(cooldown_seconds=60)
        c.trigger("main", now_unix=1000)
        # Past expiry -> status_for returns None and clears the entry.
        assert c.status_for("main", now_unix=1061) is None
        assert "main" not in c._state

    def test_multiple_branches_tracked_independently(self) -> None:
        c = MergeFailureCooldown(cooldown_seconds=60)
        c.trigger("main", now_unix=1000)
        c.trigger("release", now_unix=1010)
        assert c.status_for("main", now_unix=1030) == 1060
        assert c.status_for("release", now_unix=1030) == 1070

    def test_clear_removes_entry(self) -> None:
        c = MergeFailureCooldown(cooldown_seconds=60)
        c.trigger("main", now_unix=1000)
        c.clear("main")
        assert c.status_for("main", now_unix=1030) is None

    def test_active_cooldowns_sweeps_stale(self) -> None:
        c = MergeFailureCooldown(cooldown_seconds=60)
        c.trigger("main", now_unix=1000)     # expires at 1060
        c.trigger("release", now_unix=2000)  # expires at 2060
        active = c.active_cooldowns(now_unix=1061)
        assert "main" not in active
        assert active["release"] == 2060


class TestMergeFailureCooldownPersistence:
    def test_roundtrip_via_sidecar(self, tmp_path: Path) -> None:
        sidecar = tmp_path / "sub" / "_merge_cooldown.json"
        c = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        c.trigger("main", now_unix=1000)
        assert sidecar.exists()
        # New instance rehydrates.
        c2 = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        assert c2.status_for("main", now_unix=1030) == 1120

    def test_missing_file_starts_empty(self, tmp_path: Path) -> None:
        sidecar = tmp_path / "missing.json"
        c = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        assert c.active_cooldowns(now_unix=1000) == {}

    def test_malformed_sidecar_raises(self, tmp_path: Path) -> None:
        sidecar = tmp_path / "bad.json"
        sidecar.write_text("{ not json ", encoding="utf-8")
        with pytest.raises(MergeFailureCooldownError):
            build_merge_failure_cooldown(
                cooldown_seconds=120,
                sidecar_path=sidecar,
            )

    def test_empty_file_starts_empty(self, tmp_path: Path) -> None:
        sidecar = tmp_path / "empty.json"
        sidecar.write_text("", encoding="utf-8")
        c = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        assert c.active_cooldowns(now_unix=1000) == {}


# ── Daemon integration ─────────────────────────────────────────────────────


@pytest.fixture
def daemon_factory() -> Iterator:
    """Factory that spins up a CageDaemon in a background thread.

    Yields a callable ``(revision_log_path=None, merge_cooldown=None)``
    that returns ``(daemon, socket_path)`` and tracks instances for
    teardown. Short UDS paths avoid the macOS 104-char limit.
    """
    daemons: list[tuple[CageDaemon, threading.Thread]] = []
    paths: list[str] = []

    def _build(
        *,
        revision_log_path: Path | None = None,
        merge_cooldown: MergeFailureCooldown | None = None,
    ) -> tuple[CageDaemon, str]:
        fd, path = tempfile.mkstemp(prefix="sr-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(path)
        d = CageDaemon(
            socket_path=path,
            revision_log_path=revision_log_path,
            merge_cooldown=merge_cooldown,
        )
        t = threading.Thread(target=d.serve_forever, daemon=True)
        t.start()
        for _ in range(100):
            if os.path.exists(path):
                break
            time.sleep(0.01)
        daemons.append((d, t))
        paths.append(path)
        return d, path

    try:
        yield _build
    finally:
        for d, t in daemons:
            d.shutdown()
            t.join(timeout=1.0)


def _send(path: str, request: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


class TestInstabilityGuardDaemonWiring:
    def test_build_x402_invariant_recognizes_kind(self, daemon_factory) -> None:
        d, path = daemon_factory()
        r = _send(path, {
            "op": "declare_x402",
            "kind": "instability_guard",
            "provider": "anthropic",
            "reject_threshold": 3,
            "window_seconds": 60,
            "tighten_to": "5",
            "recovery_seconds": 300,
        })
        # declare flows through the prover chain; we accept either an
        # immediate 'updated' or an error -- what we're asserting is the
        # dispatch doesn't fall through to 'bad_invariant'.
        assert r.get("category") != "bad_invariant"

    def test_health_surfaces_self_ref_state(self, daemon_factory) -> None:
        d, path = daemon_factory()
        r = _send(path, {"op": "health"})
        assert "self_ref" in r
        assert r["self_ref"]["instability_active_providers"] == []
        assert r["self_ref"]["merge_cooldown_expires_unix"] is None

    def test_self_ref_status_op_empty(self, daemon_factory) -> None:
        d, path = daemon_factory()
        r = _send(path, {"op": "self_ref_status"})
        assert r["verdict"] == "ok"
        assert r["instability_guards"] == []
        assert r["merge_cooldown"]["enabled"] is False


class TestAcceptanceTest3EndToEnd:
    """Acceptance Test 3: repeated failures trigger stricter policy.

    Spec: ``InstabilityGuard(provider=X, threshold=3, window=60,
    tighten_to=$5, recovery=300)``; cause 3 rejects for X; subsequent $10
    payment is rejected; after 300s of quiet, $10 permits again.
    """

    def _run_guard(self, guard: InstabilityGuard) -> None:
        pass  # documentation only

    def test_acceptance_3_repeated_failures_trigger_stricter_policy(
        self,
    ) -> None:
        guard = InstabilityGuard(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        # Phase 1: three fresh rejects inside the window.
        t0 = 1_700_000_000
        rejects = [
            _intent(amount="10", timestamp_unix=t0 + i * 5)
            for i in range(3)
        ]
        # Phase 2: a $10 intent should be tightened.
        intent_10 = _intent(amount="10", timestamp_unix=t0 + 20)
        v = guard.check_payment(intent_10, history=(), rejects=rejects)
        assert v is not None, (
            "After 3 rejects in window, a $10 payment must be rejected"
        )
        assert v.rule_id == "instability_guard"
        # Under the tightened cap, $5 still permits.
        intent_5 = _intent(amount="5", timestamp_unix=t0 + 21)
        assert guard.check_payment(intent_5, history=(), rejects=rejects) is None, (
            "Under tightened cap, $5 must still permit"
        )
        # Phase 3: 300s of quiet (no new rejects for this provider).
        # The newest reject is at t0+10; query at t0+10+301=t0+311 so
        # the recovery check sees 301s since the last reject.
        intent_later = _intent(amount="10", timestamp_unix=t0 + 311)
        assert guard.check_payment(intent_later, history=(), rejects=rejects) is None, (
            "After 300s of quiet, $10 must permit again"
        )


class TestMergeCooldownDaemonWiring:
    def _declare_and_branch(self, path: str) -> None:
        """Create a simple divergence that triggers a conflict on merge."""
        # Declare a MaxPerCall on main.
        _send(path, {
            "op": "declare_x402", "kind": "max_per_call", "max_amount": "10",
        })
        # Branch off.
        _send(path, {"op": "create_branch", "name": "b1"})
        _send(path, {"op": "checkout_branch", "name": "b1"})
        _send(path, {
            "op": "add_invariant",
            "invariant": {
                "kind": "max_per_call", "max_amount": "20",
            },
        })
        # Switch back to main and diverge there with the same class.
        _send(path, {"op": "checkout_branch", "name": "main"})
        _send(path, {
            "op": "add_invariant",
            "invariant": {
                "kind": "max_per_call", "max_amount": "30",
            },
        })

    def test_first_conflict_triggers_cooldown(
        self, tmp_path: Path, daemon_factory,
    ) -> None:
        sidecar = tmp_path / "_merge_cooldown.json"
        cooldown = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        d, path = daemon_factory(merge_cooldown=cooldown)
        self._declare_and_branch(path)
        r = _send(path, {
            "op": "merge_branch", "src": "b1", "dst": "main",
            "reviewer": "alice",
        })
        assert r["verdict"] == "conflict"
        assert r.get("cooldown_triggered") is True
        assert r.get("cooldown_retry_after_s") == 120
        # Sidecar persisted.
        assert sidecar.exists()
        data = json.loads(sidecar.read_text(encoding="utf-8"))
        assert "main" in data["cooldowns"]

    def test_during_cooldown_next_merge_short_circuits(
        self, tmp_path: Path, daemon_factory,
    ) -> None:
        sidecar = tmp_path / "_merge_cooldown.json"
        cooldown = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        d, path = daemon_factory(merge_cooldown=cooldown)
        self._declare_and_branch(path)
        _send(path, {
            "op": "merge_branch", "src": "b1", "dst": "main",
            "reviewer": "alice",
        })
        r2 = _send(path, {
            "op": "merge_branch", "src": "b1", "dst": "main",
            "reviewer": "bob",
        })
        assert r2["verdict"] == "cooldown"
        assert r2["merge_kind"] == "cooldown"
        assert r2["dst"] == "main"
        assert r2["retry_after_s"] > 0
        assert r2["retry_after_s"] <= 120

    def test_disabled_cooldown_never_short_circuits(
        self, tmp_path: Path, daemon_factory,
    ) -> None:
        cooldown = build_merge_failure_cooldown(
            cooldown_seconds=0, sidecar_path=None,
        )
        d, path = daemon_factory(merge_cooldown=cooldown)
        self._declare_and_branch(path)
        # Conflict but no cooldown trigger.
        r = _send(path, {
            "op": "merge_branch", "src": "b1", "dst": "main",
            "reviewer": "alice",
        })
        assert r["verdict"] == "conflict"
        assert r.get("cooldown_triggered") is not True
        # Second merge also not short-circuited.
        r2 = _send(path, {
            "op": "merge_branch", "src": "b1", "dst": "main",
            "reviewer": "bob",
        })
        assert r2["verdict"] == "conflict"

    def test_cooldown_expiry_restores_normal_merge(
        self, tmp_path: Path, daemon_factory, monkeypatch,
    ) -> None:
        """After the cooldown elapses the next merge runs normally.

        We can't wait 120s in tests, so we drive the cooldown clock
        directly on the cooldown object: trigger a conflict, fast-forward
        by overwriting the stored expiry, then check the merge-branch op
        no longer short-circuits.
        """
        sidecar = tmp_path / "_merge_cooldown.json"
        cooldown = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        d, path = daemon_factory(merge_cooldown=cooldown)
        self._declare_and_branch(path)
        _send(path, {
            "op": "merge_branch", "src": "b1", "dst": "main",
            "reviewer": "alice",
        })
        # Fast-forward the cooldown past expiry.
        cooldown.clear("main")
        # Recreate divergence (the earlier conflict didn't advance main).
        # The merge should now proceed past the short-circuit. Outcome
        # is implementation-defined (conflict or merged), but it is
        # NOT a cooldown short-circuit.
        r = _send(path, {
            "op": "merge_branch", "src": "b1", "dst": "main",
            "reviewer": "carol",
        })
        assert r["verdict"] != "cooldown"

    def test_rehydrate_across_daemon_restart(
        self, tmp_path: Path, daemon_factory,
    ) -> None:
        sidecar = tmp_path / "_merge_cooldown.json"
        cooldown = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        d, path = daemon_factory(merge_cooldown=cooldown)
        self._declare_and_branch(path)
        _send(path, {
            "op": "merge_branch", "src": "b1", "dst": "main",
            "reviewer": "alice",
        })
        # Sidecar should now carry the cooldown.
        data = json.loads(sidecar.read_text(encoding="utf-8"))
        assert "main" in data["cooldowns"]
        expiry_before = data["cooldowns"]["main"]
        # Spin up a fresh cooldown bound to the same sidecar -- the
        # equivalent of a daemon restart.
        cooldown2 = build_merge_failure_cooldown(
            cooldown_seconds=120,
            sidecar_path=sidecar,
        )
        assert cooldown2.status_for("main", now_unix=int(time.time())) is not None
        # And the expiry is the same as what was persisted.
        active = cooldown2.active_cooldowns(now_unix=int(time.time()))
        assert active["main"] == expiry_before


class TestSelfRefStatusOpWithState:
    def test_status_reports_active_guard(self, daemon_factory) -> None:
        d, path = daemon_factory()
        # Direct registry plumb-in (avoid needing the prover chain to
        # admit the invariant): add the guard via the daemon's
        # _x402_registry directly. The daemon is single-threaded during
        # this test, so the read-only registry is safe to swap.
        from adapter.x402_registry import X402Registry
        guard = InstabilityGuard(
            provider="anthropic",
            reject_threshold=2,
            window_seconds=3600,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        d._x402_registry = X402Registry.empty().declare(guard)
        # Seed the reject history with 2 fresh rejects.
        now = int(time.time())
        d._history_store.append(
            _intent(amount="10", timestamp_unix=now - 10), kind="reject",
        )
        d._history_store.append(
            _intent(amount="10", timestamp_unix=now - 5), kind="reject",
        )
        r = _send(path, {"op": "self_ref_status"})
        assert r["verdict"] == "ok"
        guards = r["instability_guards"]
        assert len(guards) == 1
        assert guards[0]["provider"] == "anthropic"
        assert guards[0]["active"] is True
        assert guards[0]["recent_rejects"] == 2

    def test_health_surfaces_active_providers(self, daemon_factory) -> None:
        d, path = daemon_factory()
        from adapter.x402_registry import X402Registry
        guard = InstabilityGuard(
            provider="anthropic",
            reject_threshold=1,
            window_seconds=3600,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        d._x402_registry = X402Registry.empty().declare(guard)
        now = int(time.time())
        d._history_store.append(
            _intent(amount="10", timestamp_unix=now - 5), kind="reject",
        )
        r = _send(path, {"op": "health"})
        assert "anthropic" in r["self_ref"]["instability_active_providers"]


class TestSelfRefStatusCli:
    def test_cli_status_text(self, daemon_factory) -> None:
        from daemon import cli as cli_mod
        d, path = daemon_factory()
        from adapter.x402_registry import X402Registry
        guard = InstabilityGuard(
            provider="anthropic",
            reject_threshold=2,
            window_seconds=3600,
            tighten_to=Decimal("5"),
            recovery_seconds=300,
        )
        d._x402_registry = X402Registry.empty().declare(guard)
        now = int(time.time())
        d._history_store.append(
            _intent(amount="10", timestamp_unix=now - 5), kind="reject",
        )
        d._history_store.append(
            _intent(amount="10", timestamp_unix=now - 3), kind="reject",
        )

        import argparse
        args = argparse.Namespace(
            socket=path,
            self_ref_action="status",
            fmt="text",
        )
        rc = cli_mod._cmd_self_ref(args)
        assert rc == 0

    def test_cli_status_json(self, daemon_factory, capsys) -> None:
        from daemon import cli as cli_mod
        d, path = daemon_factory()
        import argparse
        args = argparse.Namespace(
            socket=path,
            self_ref_action="status",
            fmt="json",
        )
        rc = cli_mod._cmd_self_ref(args)
        assert rc == 0
        captured = capsys.readouterr()
        payload = json.loads(captured.out)
        assert payload["verdict"] == "ok"
        assert "instability_guards" in payload
        assert "merge_cooldown" in payload

    def test_cli_requires_subaction(self) -> None:
        from daemon import cli as cli_mod
        import argparse
        args = argparse.Namespace(self_ref_action=None)
        assert cli_mod._cmd_self_ref(args) == 2
