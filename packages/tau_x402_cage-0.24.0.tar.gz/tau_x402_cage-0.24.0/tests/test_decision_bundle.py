"""Tests for signed decision bundles (v0.15.0).

Coverage targets:
  * build_decision_bundle assembles snapshot + chain + artifacts
  * round-trip: sign -> build -> serialize -> deserialize -> verify
  * tamper envelope -> fails verify
  * tamper snapshot -> compile_hash mismatch
  * tamper chain (drop a revision) -> binding mismatch
  * wrong public key -> signature mismatch
  * chain_limit=N truncates from oldest
  * daemon op for permit verdict
  * daemon op for reject verdict
  * CLI bundle + bundle-verify end-to-end
  * Ed25519 round-trip
  * empty policy snapshot builds and verifies
"""

from __future__ import annotations

import json
import subprocess
import sys
import time
import uuid
from decimal import Decimal
from pathlib import Path
from typing import Any, Tuple

import pytest

from adapter.decision_bundle import (
    BUNDLE_VERSION_V1,
    DecisionBundle,
    DecisionBundleError,
    VerifyResult,
    build_decision_bundle,
    bundle_from_jsonl,
    bundle_to_jsonl,
    compute_policy_snapshot_hash,
    verify_decision_bundle,
)
from adapter.invariants import MaxPerCall, ProviderAllowlist, SpendingCap
from adapter.payment_intent_matcher import PaymentIntent
from adapter.policy_revision import PolicyRevision, _serialize_invariant
from adapter.verdict_signer import (
    ALG_ED25519,
    ALG_HMAC_SHA256,
    SignedEnvelope,
    Verdict,
    hash_intent,
    sign,
)
from daemon.server import CageDaemon


# ── fixtures ────────────────────────────────────────────────────────────────


HMAC_SECRET = b"x" * 32


def _make_intent(amount: str = "25.00", request_id: str | None = None) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency="USDC",
        provider="anthropic",
        counterparty="vendor_x",
        rail="x402",
        timestamp_unix=1_700_000_000,
        metadata={},
        request_id=request_id,
    )


def _make_revision(
    idx: int,
    predecessor: str | None,
    invariants: Tuple[Any, ...] | None = None,
) -> PolicyRevision:
    invs = invariants if invariants is not None else (
        SpendingCap(
            max_amount=Decimal(str(100 + idx)),
            currency="USDC",
            scope="per_window",
            window_seconds=3600,
        ),
        MaxPerCall(max_amount=Decimal("50"), currency="USDC"),
    )
    return PolicyRevision(
        revision_id=f"rev-{idx:04d}",
        invariants=invs,
        proof_backend="python-pattern",
        proof_strength="pattern",
        prover_mode="compat",
        compile_hash=None,
        fragment_version="v1",
        tau_backend_version=None,
        admitted_at_unix=1_700_000_000 + idx,
        predecessor_revision_id=predecessor,
        delta={},
        revision_depth=idx,
        branch="main",
    )


def _sign_envelope(
    intent: PaymentIntent,
    revision: PolicyRevision | None,
    outcome: str = "permit",
    secret: bytes = HMAC_SECRET,
) -> SignedEnvelope:
    verdict = Verdict(
        outcome=outcome,
        rule_id=None if outcome == "permit" else "max_per_call",
        witness=None,
        reason_text=None if outcome == "permit" else "over cap",
        issued_at_unix=0,
        ttl_seconds=30,
    )
    return sign(
        verdict,
        intent,
        secret,
        now_unix=1_700_000_000,
        revision=revision,
    )


# ── compute_policy_snapshot_hash ───────────────────────────────────────────


class TestSnapshotHash:
    def test_deterministic_for_same_snapshot(self) -> None:
        inv = SpendingCap(
            max_amount=Decimal("100"),
            currency="USDC",
            scope="per_window",
            window_seconds=3600,
        )
        snap = [_serialize_invariant(inv)]
        assert compute_policy_snapshot_hash(snap) == compute_policy_snapshot_hash(snap)

    def test_reorder_does_not_change_hash(self) -> None:
        a = _serialize_invariant(
            SpendingCap(max_amount=Decimal("100"), currency="USDC",
                        scope="per_window", window_seconds=3600)
        )
        b = _serialize_invariant(MaxPerCall(max_amount=Decimal("50"), currency="USDC"))
        assert compute_policy_snapshot_hash([a, b]) == compute_policy_snapshot_hash([b, a])

    def test_modify_changes_hash(self) -> None:
        a = _serialize_invariant(MaxPerCall(max_amount=Decimal("50"), currency="USDC"))
        b = _serialize_invariant(MaxPerCall(max_amount=Decimal("51"), currency="USDC"))
        assert compute_policy_snapshot_hash([a]) != compute_policy_snapshot_hash([b])

    def test_empty_snapshot_is_stable(self) -> None:
        assert compute_policy_snapshot_hash([]) == compute_policy_snapshot_hash([])


# ── build_decision_bundle ───────────────────────────────────────────────────


class TestBuild:
    def test_assembles_snapshot_chain_and_artifacts(self) -> None:
        rev0 = _make_revision(0, None)
        rev1 = _make_revision(1, rev0.revision_id)
        intent = _make_intent()
        env = _sign_envelope(intent, rev1)
        bundle = build_decision_bundle(
            env,
            active_invariants=rev1.invariants,
            revision_log=[rev0, rev1],
            cage_version="0.15.0",
            bundle_id="b-1",
            created_at_unix=1_700_000_500,
            chain_limit=50,
        )
        assert bundle.bundle_version == BUNDLE_VERSION_V1
        assert bundle.envelope is env
        assert len(bundle.policy_snapshot) == len(rev1.invariants)
        assert len(bundle.revision_chain) == 2
        assert bundle.revision_chain[-1].revision_id == rev1.revision_id
        assert bundle.proof_artifacts["proof_backend"] == rev1.proof_backend
        assert bundle.proof_artifacts["proof_strength"] == rev1.proof_strength
        assert bundle.proof_artifacts["prover_mode"] == rev1.prover_mode
        # compile_hash recomputed over snapshot — not the revision's
        # internal Tau-source hash.
        assert (
            bundle.proof_artifacts["compile_hash"]
            == compute_policy_snapshot_hash(bundle.policy_snapshot)
        )
        assert bundle.intent_hash == env.intent_hash
        assert bundle.bundle_id == "b-1"
        assert bundle.cage_version == "0.15.0"
        assert bundle.truncated is False

    def test_empty_snapshot_builds_and_verifies(self) -> None:
        intent = _make_intent()
        env = _sign_envelope(intent, revision=None)
        bundle = build_decision_bundle(
            env,
            active_invariants=[],
            revision_log=[],
            cage_version="0.15.0",
            bundle_id="b-empty",
            created_at_unix=1_700_000_500,
        )
        assert bundle.policy_snapshot == ()
        assert bundle.revision_chain == ()
        # Empty snapshot still produces a well-defined hash.
        assert isinstance(bundle.proof_artifacts["compile_hash"], str)
        result = verify_decision_bundle(bundle, secret=HMAC_SECRET)
        assert result.valid, result.reason

    def test_chain_limit_truncates_from_oldest(self) -> None:
        revs = []
        pred: str | None = None
        for i in range(100):
            r = _make_revision(i, pred)
            revs.append(r)
            pred = r.revision_id
        intent = _make_intent()
        env = _sign_envelope(intent, revs[-1])
        bundle = build_decision_bundle(
            env,
            active_invariants=revs[-1].invariants,
            revision_log=revs,
            cage_version="0.15.0",
            bundle_id="b-big",
            created_at_unix=1_700_000_500,
            chain_limit=50,
        )
        assert bundle.truncated is True
        assert bundle.chain_total == 100
        assert len(bundle.revision_chain) == 50
        # Head (most recent) revision must still match the envelope.
        assert bundle.revision_chain[-1].revision_id == revs[-1].revision_id

    def test_bad_chain_limit_raises(self) -> None:
        with pytest.raises(DecisionBundleError):
            build_decision_bundle(
                _sign_envelope(_make_intent(), revision=None),
                active_invariants=[],
                revision_log=[],
                cage_version="0.15.0",
                bundle_id="b-bad",
                created_at_unix=0,
                chain_limit=0,
            )


# ── round-trip serialize / deserialize / verify ─────────────────────────────


class TestRoundTrip:
    def test_serialize_deserialize_verify(self) -> None:
        rev = _make_revision(0, None)
        intent = _make_intent()
        env = _sign_envelope(intent, rev)
        bundle = build_decision_bundle(
            env,
            active_invariants=rev.invariants,
            revision_log=[rev],
            cage_version="0.15.0",
            bundle_id="b-rt",
            created_at_unix=1_700_000_500,
        )
        raw = bundle_to_jsonl(bundle)
        assert isinstance(raw, bytes)
        restored = bundle_from_jsonl(raw)
        assert restored.bundle_id == bundle.bundle_id
        assert restored.intent_hash == bundle.intent_hash
        assert restored.envelope.mac_hex == env.mac_hex
        assert len(restored.policy_snapshot) == len(bundle.policy_snapshot)
        assert len(restored.revision_chain) == 1
        # Verify the restored bundle with the original secret.
        result = verify_decision_bundle(restored, secret=HMAC_SECRET)
        assert result.valid, result.reason
        assert result.envelope_signature_ok
        assert result.revision_binding_ok
        assert result.compile_hash_ok

    def test_deterministic_serialization(self) -> None:
        """Same inputs produce byte-identical JSONL."""
        rev = _make_revision(0, None)
        intent = _make_intent()
        env = _sign_envelope(intent, rev)

        def _build() -> bytes:
            b = build_decision_bundle(
                env,
                active_invariants=rev.invariants,
                revision_log=[rev],
                cage_version="0.15.0",
                bundle_id="b-det",
                created_at_unix=42,
            )
            return bundle_to_jsonl(b)

        assert _build() == _build()


# ── tamper scenarios ────────────────────────────────────────────────────────


def _tamper_envelope(env: SignedEnvelope, new_outcome: str = "permit") -> SignedEnvelope:
    """Return a new envelope with a tampered outcome but the same MAC.

    Simulates an attacker who rewrites a reject into a permit without
    being able to re-sign (because they don't have the key).
    """
    return SignedEnvelope(
        outcome=new_outcome,
        rule_id=env.rule_id,
        witness=env.witness,
        reason_text=env.reason_text,
        issued_at_unix=env.issued_at_unix,
        ttl_seconds=env.ttl_seconds,
        intent_hash=env.intent_hash,
        mac_hex=env.mac_hex,
        mac_alg=env.mac_alg,
        algorithm=env.algorithm,
        version=env.version,
        policy_revision_id=env.policy_revision_id,
        proof_backend=env.proof_backend,
        proof_strength=env.proof_strength,
        prover_mode=env.prover_mode,
        compile_hash=env.compile_hash,
        without_system=env.without_system,
        mode=env.mode,
        shadow_would_reject=env.shadow_would_reject,
        shadow_rule_id=env.shadow_rule_id,
        shadow_reason_text=env.shadow_reason_text,
    )


class TestTamper:
    def test_tampered_envelope_fails_verify(self) -> None:
        rev = _make_revision(0, None)
        intent = _make_intent()
        env = _sign_envelope(intent, rev, outcome="reject")
        bundle = build_decision_bundle(
            env,
            active_invariants=rev.invariants,
            revision_log=[rev],
            cage_version="0.15.0",
            bundle_id="b-tamper",
            created_at_unix=0,
        )
        tampered_env = _tamper_envelope(env, new_outcome="permit")
        tampered_bundle = DecisionBundle(
            bundle_version=bundle.bundle_version,
            envelope=tampered_env,
            policy_snapshot=bundle.policy_snapshot,
            revision_chain=bundle.revision_chain,
            proof_artifacts=bundle.proof_artifacts,
            created_at_unix=bundle.created_at_unix,
            cage_version=bundle.cage_version,
            bundle_id=bundle.bundle_id,
            intent_hash=bundle.intent_hash,
        )
        result = verify_decision_bundle(tampered_bundle, secret=HMAC_SECRET)
        assert not result.valid
        assert not result.envelope_signature_ok
        assert "signature" in (result.reason or "").lower()

    def test_tampered_snapshot_fails_compile_hash(self) -> None:
        rev = _make_revision(0, None)
        intent = _make_intent()
        env = _sign_envelope(intent, rev)
        bundle = build_decision_bundle(
            env,
            active_invariants=rev.invariants,
            revision_log=[rev],
            cage_version="0.15.0",
            bundle_id="b-snap",
            created_at_unix=0,
        )
        # Append a fake invariant to the snapshot but leave the stored
        # compile_hash pointing at the original. This is exactly the
        # "silently add a rule to the evidence file" attack.
        fake_item = _serialize_invariant(
            ProviderAllowlist(providers=frozenset({"evil-provider"}))
        )
        tampered_snapshot = bundle.policy_snapshot + (fake_item,)
        tampered_bundle = DecisionBundle(
            bundle_version=bundle.bundle_version,
            envelope=bundle.envelope,
            policy_snapshot=tampered_snapshot,
            revision_chain=bundle.revision_chain,
            proof_artifacts=bundle.proof_artifacts,
            created_at_unix=bundle.created_at_unix,
            cage_version=bundle.cage_version,
            bundle_id=bundle.bundle_id,
            intent_hash=bundle.intent_hash,
        )
        result = verify_decision_bundle(tampered_bundle, secret=HMAC_SECRET)
        assert not result.valid
        # Envelope + revision-binding still passed; only compile_hash failed.
        assert result.envelope_signature_ok
        assert result.revision_binding_ok
        assert not result.compile_hash_ok
        assert "compile_hash" in (result.reason or "")

    def test_tampered_chain_fails_revision_binding(self) -> None:
        rev0 = _make_revision(0, None)
        rev1 = _make_revision(1, rev0.revision_id)
        intent = _make_intent()
        env = _sign_envelope(intent, rev1)
        bundle = build_decision_bundle(
            env,
            active_invariants=rev1.invariants,
            revision_log=[rev0, rev1],
            cage_version="0.15.0",
            bundle_id="b-chain",
            created_at_unix=0,
        )
        # Drop the head revision so the chain's head no longer matches
        # the envelope's policy_revision_id.
        tampered_chain = bundle.revision_chain[:-1]
        tampered_bundle = DecisionBundle(
            bundle_version=bundle.bundle_version,
            envelope=bundle.envelope,
            policy_snapshot=bundle.policy_snapshot,
            revision_chain=tampered_chain,
            proof_artifacts=bundle.proof_artifacts,
            created_at_unix=bundle.created_at_unix,
            cage_version=bundle.cage_version,
            bundle_id=bundle.bundle_id,
            intent_hash=bundle.intent_hash,
        )
        result = verify_decision_bundle(tampered_bundle, secret=HMAC_SECRET)
        assert not result.valid
        assert result.envelope_signature_ok
        assert not result.revision_binding_ok
        assert "revision" in (result.reason or "").lower()

    def test_wrong_secret_fails_verify(self) -> None:
        rev = _make_revision(0, None)
        intent = _make_intent()
        env = _sign_envelope(intent, rev)
        bundle = build_decision_bundle(
            env,
            active_invariants=rev.invariants,
            revision_log=[rev],
            cage_version="0.15.0",
            bundle_id="b-wrong",
            created_at_unix=0,
        )
        result = verify_decision_bundle(bundle, secret=b"y" * 32)
        assert not result.valid
        assert not result.envelope_signature_ok


# ── daemon op round-trips ───────────────────────────────────────────────────


@pytest.fixture
def daemon_with_hmac(tmp_path: Path) -> CageDaemon:
    return CageDaemon(
        socket_path=str(tmp_path / "daemon.sock"),
        hmac_secret=HMAC_SECRET,
    )


def _declare_max_per_call(daemon: CageDaemon, cap: str = "100") -> None:
    r = daemon.dispatch({"op": "declare_x402", "kind": "max_per_call", "max_amount": cap})
    assert r["verdict"] == "updated", r


def _intent_dict(amount: str = "10") -> dict:
    return {
        "amount": amount,
        "currency": "USDC",
        "provider": "anthropic",
        "counterparty": "vendor_x",
        "rail": "x402",
        "timestamp_unix": 1_700_000_000,
    }


class TestDaemonOp:
    def test_bundle_for_permit_verdict(self, daemon_with_hmac: CageDaemon) -> None:
        _declare_max_per_call(daemon_with_hmac, "100")
        r = daemon_with_hmac.dispatch(
            {"op": "check_payment", "intent": _intent_dict("10")}
        )
        assert r["verdict"] == "permit", r
        # Fetch recent verdicts to find the bundle_id we want to bundle up.
        rv = daemon_with_hmac.dispatch({"op": "recent_verdicts"})
        entry = rv["entries"][0]
        assert entry["verdict"] == "permit"
        bundle_id = entry["bundle_id"]
        assert bundle_id
        resp = daemon_with_hmac.dispatch(
            {"op": "build_decision_bundle", "bundle_id": bundle_id}
        )
        assert resp["verdict"] == "ok", resp
        bundle = bundle_from_jsonl(resp["bundle_jsonl"].encode("utf-8"))
        result = verify_decision_bundle(bundle, secret=HMAC_SECRET)
        assert result.valid, result.reason
        assert bundle.envelope.outcome == "permit"

    def test_bundle_for_reject_verdict(self, daemon_with_hmac: CageDaemon) -> None:
        _declare_max_per_call(daemon_with_hmac, "100")
        r = daemon_with_hmac.dispatch(
            {"op": "check_payment", "intent": _intent_dict("500")}
        )
        assert r["verdict"] == "reject", r
        rv = daemon_with_hmac.dispatch({"op": "recent_verdicts"})
        entry = rv["entries"][0]
        assert entry["verdict"] == "reject"
        resp = daemon_with_hmac.dispatch(
            {"op": "build_decision_bundle", "bundle_id": entry["bundle_id"]}
        )
        assert resp["verdict"] == "ok", resp
        bundle = bundle_from_jsonl(resp["bundle_jsonl"].encode("utf-8"))
        result = verify_decision_bundle(bundle, secret=HMAC_SECRET)
        assert result.valid, result.reason
        assert bundle.envelope.outcome == "reject"
        assert bundle.envelope.rule_id == "max_per_call"

    def test_bundle_by_intent_hash(self, daemon_with_hmac: CageDaemon) -> None:
        _declare_max_per_call(daemon_with_hmac, "100")
        daemon_with_hmac.dispatch(
            {"op": "check_payment", "intent": _intent_dict("30")}
        )
        rv = daemon_with_hmac.dispatch({"op": "recent_verdicts"})
        entry = rv["entries"][0]
        ih = entry["intent_hash"]
        resp = daemon_with_hmac.dispatch(
            {"op": "build_decision_bundle", "intent_hash": ih}
        )
        assert resp["verdict"] == "ok", resp
        assert resp["intent_hash"] == ih

    def test_unknown_bundle_id_errors(self, daemon_with_hmac: CageDaemon) -> None:
        resp = daemon_with_hmac.dispatch(
            {"op": "build_decision_bundle", "bundle_id": "does-not-exist"}
        )
        assert resp["verdict"] == "error"
        assert resp["category"] == "unknown_verdict"

    def test_missing_lookup_keys_errors(self, daemon_with_hmac: CageDaemon) -> None:
        resp = daemon_with_hmac.dispatch(
            {"op": "build_decision_bundle"}
        )
        assert resp["verdict"] == "error"
        assert resp["category"] == "bad_payload"

    def test_missing_hmac_errors(self, tmp_path: Path) -> None:
        d = CageDaemon(socket_path=str(tmp_path / "no-hmac.sock"))
        _declare_max_per_call(d, "100")
        d.dispatch({"op": "check_payment", "intent": _intent_dict("10")})
        rv = d.dispatch({"op": "recent_verdicts"})
        resp = d.dispatch(
            {"op": "build_decision_bundle", "bundle_id": rv["entries"][0]["bundle_id"]}
        )
        assert resp["verdict"] == "error"
        assert resp["category"] == "signer_unavailable"


# ── ed25519 path ────────────────────────────────────────────────────────────


class TestEd25519:
    def test_ed25519_signed_envelope_verifies(self, tmp_path: Path) -> None:
        pytest.importorskip("cryptography")
        from adapter.verdict_signer import (
            Ed25519Signer,
            generate_ed25519_keypair,
            load_ed25519_public_key,
            sign_ed25519,
        )

        priv, pub = generate_ed25519_keypair(str(tmp_path / "key"))
        signer = Ed25519Signer.from_pem_files(priv, pub)
        rev = _make_revision(0, None)
        intent = _make_intent()
        verdict = Verdict(
            outcome="permit",
            rule_id=None,
            witness=None,
            reason_text=None,
            issued_at_unix=0,
            ttl_seconds=30,
        )
        env = sign_ed25519(
            verdict, intent, signer, now_unix=1_700_000_000, revision=rev,
        )
        assert env.algorithm == ALG_ED25519
        bundle = build_decision_bundle(
            env,
            active_invariants=rev.invariants,
            revision_log=[rev],
            cage_version="0.15.0",
            bundle_id="b-ed",
            created_at_unix=0,
        )
        raw = bundle_to_jsonl(bundle)
        restored = bundle_from_jsonl(raw)
        pk = load_ed25519_public_key(pub)
        result = verify_decision_bundle(restored, public_key=pk)
        assert result.valid, result.reason
        # And a wrong key fails cleanly.
        other_priv, other_pub = generate_ed25519_keypair(str(tmp_path / "other"))
        bad_pk = load_ed25519_public_key(other_pub)
        bad_result = verify_decision_bundle(restored, public_key=bad_pk)
        assert not bad_result.valid


# ── CLI end-to-end ──────────────────────────────────────────────────────────


def _daemon_subprocess(
    socket_path: Path, secret_hex: str, tmp_path: Path
) -> subprocess.Popen:
    env_file = tmp_path / "daemon.env"
    env_file.write_text("")
    import os
    env = os.environ.copy()
    env["TAU_X402_HMAC_SECRET"] = secret_hex
    return subprocess.Popen(
        [
            sys.executable, "-m", "daemon.cli",
            "--socket", str(socket_path),
        ],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def _wait_for_socket(path: Path, timeout: float = 5.0) -> None:
    import socket as sk
    deadline = time.time() + timeout
    while time.time() < deadline:
        if path.exists():
            try:
                s = sk.socket(sk.AF_UNIX, sk.SOCK_STREAM)
                s.settimeout(0.5)
                s.connect(str(path))
                s.close()
                return
            except OSError:
                pass
        time.sleep(0.05)
    raise TimeoutError(f"daemon socket did not come up: {path}")


class TestCli:
    def test_bundle_and_verify_end_to_end(self, tmp_path: Path) -> None:
        # Short UDS path; macOS caps at ~104 chars
        sock = Path(f"/tmp/tx402-bundle-{uuid.uuid4().hex[:8]}.sock")
        secret_hex = HMAC_SECRET.hex()
        proc = _daemon_subprocess(sock, secret_hex, tmp_path)
        try:
            _wait_for_socket(sock, timeout=10.0)
            import socket as sk
            # Declare a policy via UDS.
            def send(payload: dict) -> dict:
                s = sk.socket(sk.AF_UNIX, sk.SOCK_STREAM)
                s.settimeout(5.0)
                s.connect(str(sock))
                s.sendall((json.dumps(payload) + "\n").encode("utf-8"))
                f = s.makefile("r")
                line = f.readline()
                s.close()
                return json.loads(line)
            r = send({"op": "declare_x402", "kind": "max_per_call",
                      "max_amount": "100"})
            assert r["verdict"] == "updated", r
            r = send({"op": "check_payment", "intent": _intent_dict("10")})
            assert r["verdict"] == "permit"
            rv = send({"op": "recent_verdicts"})
            bundle_id = rv["entries"][0]["bundle_id"]
            # Fetch via CLI.
            out_path = tmp_path / "bundle.jsonl"
            cli = subprocess.run(
                [
                    sys.executable, "-m", "daemon.cli", "bundle",
                    bundle_id,
                    "--out", str(out_path),
                    "--socket", str(sock),
                ],
                capture_output=True, text=True, timeout=15.0,
            )
            assert cli.returncode == 0, cli.stderr
            assert out_path.exists()
            # Verify via CLI with the shared secret.
            verify = subprocess.run(
                [
                    sys.executable, "-m", "daemon.cli", "bundle-verify",
                    str(out_path),
                    "--secret", secret_hex,
                ],
                capture_output=True, text=True, timeout=10.0,
            )
            assert verify.returncode == 0, verify.stderr
            assert "OK" in verify.stdout
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                proc.kill()
            if sock.exists():
                try:
                    sock.unlink()
                except OSError:
                    pass

    def test_bundle_verify_invalid_returns_1(self, tmp_path: Path) -> None:
        # Build a valid bundle, then corrupt it on disk, then assert the
        # CLI returns 1 (invalid) not 2 (transport).
        rev = _make_revision(0, None)
        intent = _make_intent()
        env = _sign_envelope(intent, rev)
        bundle = build_decision_bundle(
            env,
            active_invariants=rev.invariants,
            revision_log=[rev],
            cage_version="0.15.0",
            bundle_id="b-corrupt",
            created_at_unix=0,
        )
        out = tmp_path / "bundle.jsonl"
        out.write_bytes(bundle_to_jsonl(bundle))
        # Verify works.
        ok = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "bundle-verify", str(out),
             "--secret", HMAC_SECRET.hex()],
            capture_output=True, text=True, timeout=10.0,
        )
        assert ok.returncode == 0, ok.stderr
        # Verify with wrong secret returns 1.
        bad = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "bundle-verify", str(out),
             "--secret", (b"y" * 32).hex()],
            capture_output=True, text=True, timeout=10.0,
        )
        assert bad.returncode == 1, bad.stdout + bad.stderr
        assert "INVALID" in bad.stderr
