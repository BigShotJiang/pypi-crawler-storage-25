"""Tests for ``adapter.guaranteed_language.assert_pure_bv_policy``.

v1.2.0 promises the tier admits only pure ``bv`` BA constructs. Even
when the variant gate in ``is_supported`` admits a rule, the compiled
Tau source is re-scanned for forbidden sentinels (``:nlang`` tags,
SMT-LIB z3 declarations) before the prover runs. This file pins the
helper's behaviour.
"""
from __future__ import annotations

import pytest

from adapter.guaranteed_language import (
    PureBvAssertionError,
    assert_pure_bv_policy,
)


# ── happy path ─────────────────────────────────────────────────────────


def test_pure_bv_body_admits():
    """A plain bv[16] enum equality under G passes."""
    body = "G(intent_jurisdiction[t]:bv[16] = { 1 }:bv[16])"
    assert_pure_bv_policy(body)  # no raise


def test_nested_bv_composition_admits():
    """MutualExclusion-style composed body: ``G(!(A && B))``."""
    body = (
        "G(!(((intent_provider[t]:bv[16] = { 1 }:bv[16])) && "
        "((intent_provider[t]:bv[16] = { 2 }:bv[16]))))"
    )
    assert_pure_bv_policy(body)


# ── rejections ─────────────────────────────────────────────────────────


def test_empty_source_rejected():
    with pytest.raises(PureBvAssertionError) as excinfo:
        assert_pure_bv_policy("")
    assert "empty" in excinfo.value.detail


def test_whitespace_only_source_rejected():
    with pytest.raises(PureBvAssertionError):
        assert_pure_bv_policy("   \n  ")


def test_non_string_input_rejected():
    with pytest.raises(PureBvAssertionError):
        assert_pure_bv_policy(None)  # type: ignore[arg-type]
    with pytest.raises(PureBvAssertionError):
        assert_pure_bv_policy(12345)  # type: ignore[arg-type]


def test_nlang_type_tag_rejected():
    body = "G({<hello>}:nlang = { 1 }:nlang)"
    with pytest.raises(PureBvAssertionError) as excinfo:
        assert_pure_bv_policy(body)
    assert excinfo.value.detail == ":nlang"


def test_nlang_literal_opener_rejected():
    """The ``{<`` substring is an nlang literal marker."""
    body = "G(foo[t] = {<hello})"
    with pytest.raises(PureBvAssertionError):
        assert_pure_bv_policy(body)


def test_smt_declare_fun_rejected():
    """Fragment-v2 / z3 SMT-LIB declarations must never reach the
    Guaranteed prover. If they do it's a routing bug and the admission
    must fail closed."""
    body = "(declare-fun spend () Int) (assert (>= spend 0))"
    with pytest.raises(PureBvAssertionError) as excinfo:
        assert_pure_bv_policy(body)
    assert "declare-fun" in excinfo.value.detail


def test_smt_assert_rejected():
    body = "(assert (>= x 0))"
    with pytest.raises(PureBvAssertionError):
        assert_pure_bv_policy(body)


def test_error_carries_detail_substring():
    body = "G(x:nlang = 1)"
    with pytest.raises(PureBvAssertionError) as excinfo:
        assert_pure_bv_policy(body)
    assert isinstance(excinfo.value.detail, str)
    assert excinfo.value.detail  # non-empty
