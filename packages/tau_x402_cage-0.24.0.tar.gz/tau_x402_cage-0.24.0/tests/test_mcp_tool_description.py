"""Tests for the MCP ``should_pay_x402`` tool description voice (v0.23.0).

The MCP tool description is the single text block the agent LLM
reads when deciding whether to call the cage. Its opening sentence
determines whether the agent frames the tool as "call this to get a
payment decision" (correct) or "call this to use formal methods"
(incorrect — formal methods is implementation, not capability).

We pin three properties on the description:

  1. It leads with decision-layer framing ("Decides whether" or
     "Authorise"), not with formal-methods language.
  2. It explicitly names the three protection scenarios the brief
     called out: retry-loop, burst, overspend.
  3. It does NOT lead with "Tau Language" or "formal methods" —
     those are fine further down, but must not be the first thing
     the agent reads.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest


# The ``mcp`` subpackage is a sibling installable distribution
# (``pip install -e mcp``) and its ``__init__`` imports
# ``tau_x402_cage_client`` which is NOT part of the core tree. We
# only need the schemas-level constants, so we load ``schemas.py``
# directly by path — sidesteps the package-init import chain.
_SCHEMAS_PATH = (
    Path(__file__).resolve().parent.parent
    / "mcp" / "tau_x402_cage_mcp" / "schemas.py"
)


def _load_schemas_module():
    spec = importlib.util.spec_from_file_location(
        "tau_x402_cage_mcp_schemas_under_test", _SCHEMAS_PATH
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_schemas = _load_schemas_module()
TOOL_DESCRIPTIONS = _schemas.TOOL_DESCRIPTIONS
TOOL_INPUT_SCHEMAS = _schemas.TOOL_INPUT_SCHEMAS


# ── the single tool this file pins ──────────────────────────────────────────


@pytest.fixture
def description() -> str:
    """The canonical should_pay_x402 description, as shipped."""
    desc = TOOL_DESCRIPTIONS.get("should_pay_x402")
    assert desc is not None, "should_pay_x402 description missing"
    return desc


# ── leads with decision-layer framing ───────────────────────────────────────


class TestDescriptionOpensWithDecisionLanguage:
    """The first sentence must describe what the tool *does*."""

    def test_opens_with_decides_or_authorise(self, description: str) -> None:
        """The first sentence must lead with decision-layer framing.

        Any of "Decides whether", "Decide", or "Authorise" is OK; we
        check the first ~80 characters so the contract is robust to
        wording tweaks that keep the same voice.
        """
        opening = description[:120].lower()
        assert any(lead in opening for lead in (
            "decides whether", "decide whether", "authorise", "authorize",
        )), f"description does not lead with decision-layer framing:\n{opening!r}"

    def test_opening_does_not_lead_with_formal_methods(
        self, description: str
    ) -> None:
        """Formal-methods language is fine further down, not first."""
        opening = description[:200].lower()
        # "formal methods", "formal verification", "Tau Language" must
        # not be the *first* thing the LLM reads.
        assert "formal methods" not in opening, (
            "description leads with formal-methods language:\n"
            + opening
        )
        assert "formal verification" not in opening, (
            "description leads with formal-verification language:\n"
            + opening
        )
        assert "tau language" not in opening, (
            "description leads with Tau Language framing:\n"
            + opening
        )

    def test_opening_mentions_x402_payment(self, description: str) -> None:
        """The first sentence must name 'x402 payment' so the agent
        knows what decision class this is (vs a general-purpose ACL)."""
        opening = description[:200].lower()
        assert "x402" in opening and "payment" in opening


# ── names the three protection scenarios ────────────────────────────────────


class TestDescriptionNamesProtections:
    """Brief: 'Use this to protect the agent from retry loops, bursts,
    and overspend.' All three must appear in the description so the
    LLM can map its situation to the tool's protection surface."""

    def test_mentions_retry_loop_protection(self, description: str) -> None:
        # "retry loops" or "retry_loop_detected" both count.
        assert (
            "retry loop" in description.lower()
            or "retry_loop" in description.lower()
            or "retry flood" in description.lower()
        ), "description does not mention retry-loop protection"

    def test_mentions_burst_protection(self, description: str) -> None:
        assert (
            "burst" in description.lower()
            or "velocity" in description.lower()
        ), "description does not mention burst / velocity protection"

    def test_mentions_overspend_protection(self, description: str) -> None:
        assert (
            "overspend" in description.lower()
            or "over-spend" in description.lower()
            or "spend" in description.lower()  # weaker but accepts the v0.22 wording
        ), "description does not mention overspend protection"


# ── shape + response contract remain intact ─────────────────────────────────


class TestDescriptionRetainsResponseContract:
    """The description still needs to enumerate the PaymentDecision shape
    so agents know what to parse on the other side."""

    def test_names_allowed_field(self, description: str) -> None:
        assert "`allowed`" in description or "allowed" in description

    def test_names_reason_field(self, description: str) -> None:
        assert "`reason`" in description or "reason" in description.lower()

    def test_names_next_action_field(self, description: str) -> None:
        assert "next_action" in description

    def test_names_signed_envelope(self, description: str) -> None:
        assert "signed_envelope" in description

    def test_cage_unavailable_fail_closed_remains_documented(
        self, description: str
    ) -> None:
        """The fail-closed behaviour on cage-unreachable is safety-
        critical; it must stay in the description so the LLM doesn't
        retry-loop on transport errors."""
        assert "cage_unavailable" in description


# ── short input-schema description also leads with decision language ────────


class TestInputSchemaDescription:
    """The JSON-Schema-level description (shown by some clients as a
    tooltip) must also lead with decision framing."""

    def test_input_schema_description_leads_with_decision(self) -> None:
        desc = TOOL_INPUT_SCHEMAS["should_pay_x402"].get("description", "")
        opening = desc[:120].lower()
        assert any(lead in opening for lead in (
            "decides whether", "decide whether", "authorise", "authorize",
        )), f"input-schema description does not lead with decision framing:\n{opening!r}"
