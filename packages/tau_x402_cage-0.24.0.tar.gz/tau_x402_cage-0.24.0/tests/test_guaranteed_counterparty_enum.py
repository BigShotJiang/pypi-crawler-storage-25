"""v1.2.0 tests for CounterpartyConstraint admission in Guaranteed Mode.

Covers:
* admit pure-allowlist variant (approved_ids non-empty, sanctioned_ids empty),
* reject sanctions-negation variant,
* totality round-trip,
* dry-run encoding is closed bv BA with bv[16] slots, no nlang tag,
* widening the allowlist is rejected as a weakening mutation because
  ``widen_allowlist`` is not in ``SUPPORTED_MUTATION_FORMS``.
"""
from __future__ import annotations

from types import SimpleNamespace

import pytest

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.guaranteed_totality import validate_totality
from adapter.invariants import CounterpartyConstraint
from adapter.tau_compiler import _v12_encode, dry_run_encode


# ── admission ──────────────────────────────────────────────────────────


def test_counterparty_pure_allowlist_admits():
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(approved_ids=frozenset({"acme", "globex"}))
    )
    assert ok is True
    assert code is None


def test_counterparty_single_allowlist_admits():
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(approved_ids=frozenset({"acme"}))
    )
    assert ok is True
    assert code is None


def test_counterparty_empty_rejected():
    """Empty approved set + empty sanctioned set has no enum_bv content."""
    ok, code = GuaranteedLanguage.is_supported(CounterpartyConstraint())
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


def test_counterparty_with_sanctions_rejected():
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(
            approved_ids=frozenset({"acme"}),
            sanctioned_ids=frozenset({"evil-inc"}),
        )
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


def test_counterparty_only_sanctions_rejected():
    """Pure sanctions-list with no allowlist is NOT the enum_bv variant."""
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(sanctioned_ids=frozenset({"evil-inc"}))
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


# ── totality ───────────────────────────────────────────────────────────


def _mk_policy(invariants, **extra):
    return SimpleNamespace(invariants=tuple(invariants), **extra)


def test_totality_counterparty_allowlist_alone_passes():
    report = validate_totality(
        _mk_policy([CounterpartyConstraint(approved_ids=frozenset({"acme"}))])
    )
    assert report.is_total is True
    assert report.reason_code is None
    assert report.language_version == GUARANTEED_LANGUAGE_VERSION


def test_totality_counterparty_sanctions_variant_rejected():
    report = validate_totality(
        _mk_policy(
            [
                CounterpartyConstraint(
                    approved_ids=frozenset({"acme"}),
                    sanctioned_ids=frozenset({"evil-inc"}),
                )
            ]
        )
    )
    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value
    )


# ── widening-set weakening ─────────────────────────────────────────────


def test_widen_allowlist_mutation_form_is_not_supported():
    """Growing a pure-allowlist CounterpartyConstraint in Guaranteed
    Mode is a weakening move. The cage refuses because
    ``widen_allowlist`` is not in SUPPORTED_MUTATION_FORMS — the
    fail-closed whitelist blocks the mutation without any special-case
    code needed."""
    assert (
        GuaranteedLanguage.is_mutation_form_supported("widen_allowlist")
        is False
    )


def test_totality_rejects_widen_allowlist_mutation_form():
    """Stage-3 mutation-form admission rejects the widening move even if
    the invariant itself would be admitted."""
    report = validate_totality(
        _mk_policy(
            [CounterpartyConstraint(approved_ids=frozenset({"acme"}))],
            mutation_forms=["widen_allowlist"],
        )
    )
    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value
    )
    # The surfaced reason names the offending mutation form.
    assert any("widen_allowlist" in node for node in report.unsupported_nodes)


# ── dry-run encoding shape ─────────────────────────────────────────────


def test_dry_run_encode_pure_allowlist_ok():
    ok, detail = dry_run_encode(
        CounterpartyConstraint(approved_ids=frozenset({"acme"}))
    )
    assert ok is True
    assert detail == ""


def test_v12_encoded_body_is_closed_g_wrapper():
    body = _v12_encode(
        CounterpartyConstraint(approved_ids=frozenset({"acme", "globex"}))
    )
    assert body.startswith("G(")
    assert body.endswith(")")
    assert body.count("(") == body.count(")")


def test_v12_encoded_body_has_bv16_slots_per_counterparty():
    body = _v12_encode(
        CounterpartyConstraint(
            approved_ids=frozenset({"acme", "globex", "initech"})
        )
    )
    # Each counterparty contributes one bv[16] equality.
    assert body.count(":bv[16]") >= 3
    assert "intent_counterparty" in body


def test_v12_encoded_body_deterministic_over_set_order():
    """Same input -> same output regardless of iteration order."""
    a = _v12_encode(
        CounterpartyConstraint(approved_ids=frozenset({"acme", "globex"}))
    )
    b = _v12_encode(
        CounterpartyConstraint(approved_ids=frozenset({"globex", "acme"}))
    )
    assert a == b


def test_v12_encoded_body_no_nlang_no_smt_sentinels():
    body = _v12_encode(
        CounterpartyConstraint(
            approved_ids=frozenset({"acme", "globex", "initech"})
        )
    )
    assert ":nlang" not in body
    assert "{<" not in body
    assert "(declare-fun" not in body
    assert "(assert " not in body
