"""Tests for the v0.19.0 bank evaluation demo.

Runs the demo as a subprocess with --quiet, asserts exit 0, parses the
summary JSON, and verifies the six expected state transitions held.
Completes in well under 30s on a developer laptop.
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict

import pytest

ROOT = Path(__file__).resolve().parent.parent
DEMO = ROOT / "demos" / "bank_evaluation_demo.py"


def _run_demo(args: list[str]) -> tuple[int, str, str, float]:
    start = time.monotonic()
    proc = subprocess.run(
        [sys.executable, str(DEMO)] + args,
        capture_output=True, text=True, timeout=60,
    )
    return proc.returncode, proc.stdout, proc.stderr, time.monotonic() - start


class TestBankEvaluationDemo:
    def test_demo_file_exists(self) -> None:
        assert DEMO.is_file(), f"demo script missing at {DEMO}"

    def test_quiet_run_exits_0(self) -> None:
        rc, out, err, elapsed = _run_demo(["--quiet"])
        assert rc == 0, f"rc={rc} stderr={err!r}"
        assert elapsed < 30.0, f"demo took {elapsed:.2f}s, must be < 30s"

    def test_quiet_run_emits_structured_summary(self) -> None:
        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        # The last stdout line is the JSON summary.
        lines = [line for line in out.splitlines() if line.strip()]
        summary = json.loads(lines[-1])
        assert summary["demo"] == "bank_evaluation_v0.19.0"
        assert len(summary["steps"]) == 6

    def test_all_six_step_state_transitions(self) -> None:
        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        lines = [line for line in out.splitlines() if line.strip()]
        summary: Dict[str, Any] = json.loads(lines[-1])
        by_idx = {s["index"]: s for s in summary["steps"]}
        expected = {
            1: "ok",        # propose
            2: "ok",        # admit
            3: "ok",        # allow
            4: "blocked",   # blocked by cap
            5: "rejected",  # mutation weakening rejected
            6: "ok",        # bundle verified
        }
        for idx, want in expected.items():
            got = by_idx[idx]["status"]
            assert got == want, f"step {idx} expected {want!r}, got {got!r}"

    def test_final_bundle_verifies(self) -> None:
        from adapter.guaranteed_audit import GuaranteedAuditBundle

        rc, out, err, _ = _run_demo(["--quiet"])
        assert rc == 0, err
        lines = [line for line in out.splitlines() if line.strip()]
        summary = json.loads(lines[-1])
        bundle_path = Path(summary["bundle"]["out_path"])
        assert bundle_path.exists(), f"bundle not written at {bundle_path}"
        # The demo uses a fixed key so we can reload + verify it here.
        from demos.bank_evaluation_demo import _DEMO_HMAC_KEY
        assert GuaranteedAuditBundle.verify(bundle_path.read_bytes(), _DEMO_HMAC_KEY)

    def test_narrative_mode_prints_steps(self) -> None:
        rc, out, err, _ = _run_demo([])
        assert rc == 0, err
        for fragment in ["STEP 1/6", "STEP 3/6", "STEP 6/6", "FINAL SUMMARY"]:
            assert fragment in out, f"missing narrative fragment {fragment!r}"
