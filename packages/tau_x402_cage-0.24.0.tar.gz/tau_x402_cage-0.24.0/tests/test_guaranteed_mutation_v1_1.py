"""v1.1.0 mutation-pipeline weakening classification for new rule types.

``NoWeakening`` must refuse a weakening transition for the three new
v1.1.0 rule classes on the monitored branch. The existing
``GuaranteedMutationPipeline`` wires ``NoWeakening`` through
``cross_revision``; adding new monitored classes should flow straight
through without pipeline changes.

The tests here confirm:

  * RetryRateLimit with lower min_gap_seconds is refused on ``main``.
  * RollingWindowCap with higher max_count OR shorter window_seconds
    is refused.
  * BurstVelocityCap with higher max_per_window OR shorter window is
    refused.
  * Tightening mutations for the new rules flow through cleanly.
  * Feature-branch weakening (branch != ``main``) still passes since
    NoWeakening is monitored-branch scoped.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Tuple

import pytest

from adapter.cross_revision import (
    CrossRevisionValidator,
    NoWeakening,
)
from adapter.invariants import (
    BurstVelocityCap,
    Invariant,
    RetryRateLimit,
    RollingWindowCap,
)


# ── minimal revision double ────────────────────────────────────────────


@dataclass(frozen=True)
class _Revision:
    """Enough shape for NoWeakening / CrossRevisionValidator to work."""

    id: str
    invariants: Tuple[Invariant, ...]
    predecessor_id: str = ""
    depth: int = 0
    affected_scope: dict = field(default_factory=dict)
    admitted_at_unix: int = 0


def _pair(old_invs, new_invs) -> tuple[_Revision, _Revision]:
    old = _Revision(id="r0", invariants=tuple(old_invs))
    new = _Revision(
        id="r1",
        invariants=tuple(new_invs),
        predecessor_id="r0",
        depth=1,
    )
    return old, new


# ── RetryRateLimit ─────────────────────────────────────────────────────


def test_retry_rate_limit_lowering_gap_is_rejected_on_main():
    old_inv = RetryRateLimit(min_gap_seconds=60)
    new_inv = RetryRateLimit(min_gap_seconds=5)
    old, new = _pair([old_inv], [new_inv])

    result = NoWeakening().validate_transition(old, new, "main")
    assert result, "lowering min_gap_seconds should surface a weakening"
    assert any(v.category == "weakened_retry_rate_limit" for v in result)


def test_retry_rate_limit_raising_gap_is_clean():
    old_inv = RetryRateLimit(min_gap_seconds=30)
    new_inv = RetryRateLimit(min_gap_seconds=120)
    old, new = _pair([old_inv], [new_inv])

    result = NoWeakening().validate_transition(old, new, "main")
    assert result == ()


def test_retry_rate_limit_removal_flags_weakening():
    old_inv = RetryRateLimit(min_gap_seconds=30)
    old, new = _pair([old_inv], [])

    result = NoWeakening().validate_transition(old, new, "main")
    assert result
    assert any(v.category == "removed_retry_rate_limit" for v in result)


def test_retry_rate_limit_feature_branch_bypass():
    """NoWeakening is branch-scoped; dev branches can loosen freely."""
    old_inv = RetryRateLimit(min_gap_seconds=30)
    new_inv = RetryRateLimit(min_gap_seconds=5)
    old, new = _pair([old_inv], [new_inv])

    # Feature branch: pre-merge relaxation allowed.
    assert NoWeakening().validate_transition(old, new, "feature/x") == ()


# ── RollingWindowCap ───────────────────────────────────────────────────


def test_rolling_window_cap_raising_max_count_is_rejected():
    old_inv = RollingWindowCap(max_count=5, window_seconds=60)
    new_inv = RollingWindowCap(max_count=20, window_seconds=60)
    old, new = _pair([old_inv], [new_inv])

    result = NoWeakening().validate_transition(old, new, "main")
    assert result
    assert any(v.category == "weakened_rolling_window_cap" for v in result)


def test_rolling_window_cap_shortening_window_is_rejected():
    old_inv = RollingWindowCap(max_count=5, window_seconds=120)
    new_inv = RollingWindowCap(max_count=5, window_seconds=10)
    old, new = _pair([old_inv], [new_inv])

    result = NoWeakening().validate_transition(old, new, "main")
    assert result
    assert any(v.category == "weakened_rolling_window_cap" for v in result)


def test_rolling_window_cap_tightening_is_clean():
    old_inv = RollingWindowCap(max_count=10, window_seconds=60)
    new_inv = RollingWindowCap(max_count=5, window_seconds=60)
    old, new = _pair([old_inv], [new_inv])

    assert NoWeakening().validate_transition(old, new, "main") == ()


def test_rolling_window_cap_per_group_keys_independent():
    """Caps with distinct group_by don't compare against each other."""
    old = _Revision(
        id="r0",
        invariants=(
            RollingWindowCap(max_count=5, window_seconds=60, group_by="provider"),
        ),
    )
    new = _Revision(
        id="r1",
        invariants=(
            # Same group_by is tightened (5 -> 3).
            RollingWindowCap(max_count=3, window_seconds=60, group_by="provider"),
            # New group_by added — strictly more restrictive.
            RollingWindowCap(max_count=2, window_seconds=60, group_by="global"),
        ),
        predecessor_id="r0",
        depth=1,
    )
    assert NoWeakening().validate_transition(old, new, "main") == ()


# ── BurstVelocityCap ───────────────────────────────────────────────────


def test_burst_velocity_cap_raising_max_is_rejected():
    old_inv = BurstVelocityCap(max_per_window=Decimal("50"), window_seconds=10)
    new_inv = BurstVelocityCap(max_per_window=Decimal("500"), window_seconds=10)
    old, new = _pair([old_inv], [new_inv])

    result = NoWeakening().validate_transition(old, new, "main")
    assert result
    assert any(v.category == "weakened_burst_velocity_cap" for v in result)


def test_burst_velocity_cap_shortening_window_is_rejected():
    old_inv = BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=60)
    new_inv = BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=5)
    old, new = _pair([old_inv], [new_inv])

    result = NoWeakening().validate_transition(old, new, "main")
    assert result
    assert any(v.category == "weakened_burst_velocity_cap" for v in result)


def test_burst_velocity_cap_lowering_cap_is_clean():
    old_inv = BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=10)
    new_inv = BurstVelocityCap(max_per_window=Decimal("50"), window_seconds=10)
    old, new = _pair([old_inv], [new_inv])

    assert NoWeakening().validate_transition(old, new, "main") == ()


def test_burst_velocity_cap_cross_vs_per_provider_kept_separate():
    """(currency, cross_provider) is the key; different keys don't
    compare against each other."""
    old_inv = BurstVelocityCap(
        max_per_window=Decimal("100"),
        window_seconds=10,
        cross_provider=True,
    )
    # Adding a new per-provider variant alongside is a pure tightening.
    new_invs = [
        old_inv,
        BurstVelocityCap(
            max_per_window=Decimal("20"),
            window_seconds=10,
            cross_provider=False,
        ),
    ]
    old, new = _pair([old_inv], new_invs)
    assert NoWeakening().validate_transition(old, new, "main") == ()


# ── composed validator flow ────────────────────────────────────────────


def test_validator_container_aggregates_new_rule_violations():
    """CrossRevisionValidator composes NoWeakening with other rules and
    returns every violation in one shot."""
    validator = CrossRevisionValidator(invariants=(NoWeakening(),))
    old_invs = [
        RetryRateLimit(min_gap_seconds=60),
        RollingWindowCap(max_count=5, window_seconds=60),
    ]
    new_invs = [
        RetryRateLimit(min_gap_seconds=10),
        RollingWindowCap(max_count=50, window_seconds=60),
    ]
    old, new = _pair(old_invs, new_invs)
    result = validator.validate(
        old_revision=old,
        new_revision=new,
        branch="main",
    )
    assert result.valid is False
    categories = {v.category for v in result.violations}
    assert "weakened_retry_rate_limit" in categories
    assert "weakened_rolling_window_cap" in categories
