"""Tests for v0.21.0 cross-revision runtime awareness.

Covers:

* ``previous_policy_revision`` + ``current_policy_revision`` populated
  from the revision log.
* ``revision_transition_issue`` populated when the runtime observes a
  limit-relaxation while adaptive tightening is active (agent A's
  Protocol-satisfying source).
* No false positives: without a tightening source, or without a
  monitored-class weakening, no transition issue is reported.
* Envelope serialises the new fields; the explainer renders a
  runtime-transition narrative distinct from the declare-time
  cross-revision describer.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Dict, List, Optional

import pytest

from adapter.cross_revision import NoWeakening
from adapter.decision_explainer import explain_decision
from adapter.decision_schema import PaymentDecision, next_action_for
from adapter.invariants import MaxPerCall, ProviderAllowlist, SpendingCap
from adapter.policy_revision import PolicyRevision
from adapter.revision_runtime import (
    RevisionRuntimeContext,
    compute_revision_runtime_context,
)
from adapter.runtime_guard import (
    NULL_TIGHTENING_STATE_SOURCE,
    TighteningStateSource,
)


# ── test doubles ────────────────────────────────────────────────────────────


@dataclass
class _FakeTighteningSource:
    """Structural match for TighteningStateSource. Agent A will ship the real one."""

    active_for: Dict[str, bool]

    def is_tightening_active(self, agent_id: str) -> bool:
        return bool(self.active_for.get(agent_id, False))


@dataclass
class _FakeRevisionLog:
    """Minimal log shim: holds an ordered list of revisions + id lookup."""

    revisions: List[PolicyRevision]

    @property
    def latest(self) -> Optional[PolicyRevision]:
        return self.revisions[-1] if self.revisions else None

    def get_revision(self, revision_id: str) -> Optional[PolicyRevision]:
        for rev in self.revisions:
            if rev.revision_id == revision_id:
                return rev
        return None


def _rev(
    revision_id: str,
    invariants: tuple,
    *,
    predecessor: Optional[str] = None,
) -> PolicyRevision:
    return PolicyRevision(
        revision_id=revision_id,
        invariants=invariants,
        proof_backend="tau",
        proof_strength="pattern",
        prover_mode="strict",
        compile_hash="deadbeef",
        fragment_version="v1",
        tau_backend_version="test",
        admitted_at_unix=1_000_000,
        predecessor_revision_id=predecessor,
        revision_depth=0 if predecessor is None else 1,
        branch="main",
    )


# ── Protocol satisfaction ────────────────────────────────────────────────────


class TestTighteningStateSourceProtocol:
    def test_null_source_is_protocol_compliant(self) -> None:
        assert isinstance(NULL_TIGHTENING_STATE_SOURCE, TighteningStateSource)

    def test_null_source_returns_false(self) -> None:
        assert NULL_TIGHTENING_STATE_SOURCE.is_tightening_active("agent-x") is False

    def test_fake_source_satisfies_protocol(self) -> None:
        fake = _FakeTighteningSource(active_for={"agent-a": True})
        assert isinstance(fake, TighteningStateSource)


# ── revision context plumbing ────────────────────────────────────────────────


class TestRevisionContext:
    """Previous / current revision ids are populated from the log."""

    def test_latest_and_previous_ids_populated(self) -> None:
        prev = _rev("rev_12", (MaxPerCall(max_amount=Decimal("100")),))
        cur = _rev(
            "rev_13",
            (MaxPerCall(max_amount=Decimal("100")),),
            predecessor="rev_12",
        )
        log = _FakeRevisionLog(revisions=[prev, cur])
        ctx = compute_revision_runtime_context(revision_log=log)
        assert ctx.current_policy_revision == "rev_13"
        assert ctx.previous_policy_revision == "rev_12"

    def test_no_log_gives_empty_context(self) -> None:
        ctx = compute_revision_runtime_context()
        assert ctx.current_policy_revision is None
        assert ctx.previous_policy_revision is None
        assert ctx.transition_issue is None

    def test_explicit_current_revision_overrides_log_latest(self) -> None:
        prev = _rev("rev_12", (MaxPerCall(max_amount=Decimal("100")),))
        cur = _rev(
            "rev_13",
            (MaxPerCall(max_amount=Decimal("100")),),
            predecessor="rev_12",
        )
        log = _FakeRevisionLog(revisions=[prev, cur])
        ctx = compute_revision_runtime_context(
            revision_log=log, current_revision=prev,
        )
        assert ctx.current_policy_revision == "rev_12"
        assert ctx.previous_policy_revision is None  # prev is genesis-like


# ── transition-issue detection ──────────────────────────────────────────────


class TestTransitionIssueDetection:
    """limit_relaxation_during_active_tightening surfacing + false-positive guards."""

    def _weakening_log(self) -> _FakeRevisionLog:
        prev = _rev(
            "rev_12",
            (MaxPerCall(max_amount=Decimal("100")),),
        )
        cur = _rev(
            "rev_13",
            (MaxPerCall(max_amount=Decimal("200")),),  # weaker
            predecessor="rev_12",
        )
        return _FakeRevisionLog(revisions=[prev, cur])

    def test_weakening_plus_active_tightening_triggers(self) -> None:
        log = self._weakening_log()
        src = _FakeTighteningSource(active_for={"agent-a": True})
        ctx = compute_revision_runtime_context(
            revision_log=log,
            tightening_source=src,
            agent_id="agent-a",
        )
        assert ctx.transition_issue is not None
        assert (
            ctx.transition_issue["kind"]
            == "limit_relaxation_during_active_tightening"
        )
        details = ctx.transition_issue["details"]
        assert details["agent_id"] == "agent-a"
        assert "weakened_max_per_call" in details["weakened_rules"]

    def test_weakening_without_tightening_silent(self) -> None:
        """No false positive: weakening alone isn't flagged."""
        log = self._weakening_log()
        ctx = compute_revision_runtime_context(
            revision_log=log,
            tightening_source=NULL_TIGHTENING_STATE_SOURCE,
            agent_id="agent-a",
        )
        assert ctx.transition_issue is None
        # But the revision ids ARE still populated.
        assert ctx.current_policy_revision == "rev_13"

    def test_tightening_without_weakening_silent(self) -> None:
        """Tightening alone (no monitored weakening) is also not a warning."""
        prev = _rev(
            "rev_12",
            (MaxPerCall(max_amount=Decimal("100")),),
        )
        cur = _rev(
            "rev_13",
            (MaxPerCall(max_amount=Decimal("50")),),  # STRICTER
            predecessor="rev_12",
        )
        log = _FakeRevisionLog(revisions=[prev, cur])
        src = _FakeTighteningSource(active_for={"agent-a": True})
        ctx = compute_revision_runtime_context(
            revision_log=log,
            tightening_source=src,
            agent_id="agent-a",
        )
        assert ctx.transition_issue is None

    def test_no_agent_id_gives_no_warning(self) -> None:
        """Without an agent id to query, the check degrades to silent."""
        log = self._weakening_log()
        src = _FakeTighteningSource(active_for={"agent-a": True})
        ctx = compute_revision_runtime_context(
            revision_log=log,
            tightening_source=src,
            agent_id=None,
        )
        assert ctx.transition_issue is None

    def test_different_agent_not_tightening_silent(self) -> None:
        log = self._weakening_log()
        src = _FakeTighteningSource(active_for={"agent-x": True})
        ctx = compute_revision_runtime_context(
            revision_log=log,
            tightening_source=src,
            agent_id="agent-a",
        )
        assert ctx.transition_issue is None


# ── envelope wire + explainer ───────────────────────────────────────────────


class TestRevisionTransitionEnvelope:
    def test_envelope_exposes_fields(self) -> None:
        d = PaymentDecision(
            allowed=False,
            reason="revision_transition_violation",
            previous_policy_revision="rev_12",
            current_policy_revision="rev_13",
            revision_transition_issue={
                "kind": "limit_relaxation_during_active_tightening",
                "details": {"agent_id": "agent-a"},
            },
            next_action="adjust_policy",
        )
        wire = d.to_wire()
        assert wire["previous_policy_revision"] == "rev_12"
        assert wire["current_policy_revision"] == "rev_13"
        assert (
            wire["revision_transition_issue"]["kind"]
            == "limit_relaxation_during_active_tightening"
        )

    def test_envelope_roundtrip(self) -> None:
        d = PaymentDecision(
            allowed=False,
            reason="revision_transition_violation",
            previous_policy_revision="rev_1",
            current_policy_revision="rev_2",
            revision_transition_issue={"kind": "k", "details": {"x": 1}},
        )
        restored = PaymentDecision.from_wire(d.to_wire())
        assert restored.previous_policy_revision == "rev_1"
        assert restored.current_policy_revision == "rev_2"
        assert restored.revision_transition_issue == {"kind": "k", "details": {"x": 1}}

    def test_runtime_explainer_renders_transition(self) -> None:
        record = {
            "verdict": "reject",
            "rule_id": "revision_transition_violation",
            "previous_policy_revision": "rev_12",
            "current_policy_revision": "rev_13",
            "revision_transition_issue": {
                "kind": "limit_relaxation_during_active_tightening",
                "details": {"agent_id": "agent-a"},
            },
        }
        explanation = explain_decision(record)
        assert explanation.outcome == "reject"
        assert "rev_12" in explanation.summary
        assert "rev_13" in explanation.summary
        assert "limit relaxation during active tightening" in explanation.summary
        assert "agent_id=agent-a" in explanation.narrative

    def test_next_action_for_transition_is_adjust_policy(self) -> None:
        assert next_action_for("revision_transition_violation") == "adjust_policy"


class TestRevisionContextToWire:
    def test_context_to_wire_shape(self) -> None:
        ctx = RevisionRuntimeContext(
            previous_policy_revision="rev_a",
            current_policy_revision="rev_b",
            transition_issue={"kind": "x", "details": {}},
        )
        wire = ctx.to_wire()
        assert wire["previous_policy_revision"] == "rev_a"
        assert wire["current_policy_revision"] == "rev_b"
        assert wire["revision_transition_issue"] == {"kind": "x", "details": {}}

    def test_empty_context_wire_shape(self) -> None:
        ctx = RevisionRuntimeContext()
        wire = ctx.to_wire()
        assert wire["previous_policy_revision"] is None
        assert wire["current_policy_revision"] is None
        assert wire["revision_transition_issue"] is None
