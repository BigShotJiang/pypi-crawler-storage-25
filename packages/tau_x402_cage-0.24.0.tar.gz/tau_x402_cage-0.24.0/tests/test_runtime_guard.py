"""Tests for the v0.17.0 runtime guard.

Covers every surface the patch spec calls out:

* ``SpendVelocity`` -- empty history, steady burst, cross-provider
  aggregation, window boundary.
* ``retry_density`` -- identical-tuple matching, provider isolation,
  burst-window boundary.
* ``CooldownState`` -- empty, RetryRateLimit active, InstabilityGuard
  active on multiple providers, expired entries pruned.
* ``TighteningLevel`` -- none, mild, moderate, severe.
* ``BurstVelocityCap`` -- under cap, cross-provider sum over cap,
  fragment-v2 composability under z3.
* ``SpendingCap`` with ``cross_provider_cap`` -- per-provider under cap
  but cross-provider over, and old behaviour preserved when None.
* ``project_spend`` -- linear extrapolation + horizon cap.
* Daemon ``runtime_state`` op round-trip.
* Critical test 3 (adaptive tightening): repeated violations reduce
  later thresholds so subsequent requests are blocked earlier.
* Revision-aware: ``update_invariant`` does NOT reset velocity counters
  -- history persists and the new cap applies immediately.
"""
from __future__ import annotations

import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator, List, Optional

import pytest

from adapter.history_store import InMemoryHistoryStore
from adapter.invariants import (
    BurstVelocityCap,
    InvariantError,
    RetryRateLimit,
    SpendingCap,
    Violation,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.runtime_guard import (
    CooldownEntry,
    CooldownState,
    MAX_PROJECTION_HORIZON_SECONDS,
    RetryDensity,
    RuntimeGuard,
    SEVERE_REJECT_THRESHOLD,
    SpendVelocity,
    TighteningLevel,
)
from adapter.self_ref_policy import InstabilityGuard, MergeFailureCooldown
from adapter.x402_registry import X402Registry


# ── helpers ─────────────────────────────────────────────────────────────────


def _intent(
    *,
    amount: str,
    provider: str = "anthropic",
    counterparty: str = "cp1",
    timestamp_unix: int = 1_700_000_000,
    currency: str = "USDC",
    rail: str = "x402",
) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency=currency,
        provider=provider,
        counterparty=counterparty,
        rail=rail,
        timestamp_unix=timestamp_unix,
        metadata={},
        request_id=None,
    )


def _fresh_store() -> InMemoryHistoryStore:
    return InMemoryHistoryStore(cap=10_000)


# ── SpendVelocity ───────────────────────────────────────────────────────────


class TestSpendVelocity:
    def test_empty_history_returns_zero(self) -> None:
        store = _fresh_store()
        guard = RuntimeGuard(store)
        v = guard.spend_velocity(X402Registry.empty(), now_unix=1_700_000_100)
        assert v.rate_per_second == Decimal("0")
        assert v.total_in_window == Decimal("0")
        assert v.cross_provider is False
        # Projections default to the {60, 300} horizons.
        for horizon, amount in v.projected_spend_next_n.items():
            assert horizon in (60, 300)
            assert amount == Decimal("0")

    def test_ten_payments_of_ten_in_ten_seconds(self) -> None:
        """10 payments of $10 in last 10s → rate 10/s, 60s projection = $600."""
        store = _fresh_store()
        now = 1_700_000_100
        for i in range(10):
            # ts covers now-9 ... now (i.e. all inside a 10s window ending at now)
            store.append(
                _intent(amount="10", timestamp_unix=now - 9 + i),
                kind="permit",
            )
        guard = RuntimeGuard(store)
        v = guard.spend_velocity(
            X402Registry.empty(), window_seconds=10, now_unix=now
        )
        assert v.total_in_window == Decimal("100")
        # 100 / 10s = 10/s.
        assert v.rate_per_second == Decimal("10")
        # 10/s * 60s = 600.
        assert v.projected_spend_next_n[60] == Decimal("600")
        # 10/s * 300s = 3000.
        assert v.projected_spend_next_n[300] == Decimal("3000")
        assert v.cross_provider is False  # all same provider

    def test_cross_provider_aggregation(self) -> None:
        """Sum across providers; cross_provider flag flips True."""
        store = _fresh_store()
        now = 1_700_000_100
        store.append(_intent(amount="10", provider="anthropic", timestamp_unix=now - 5), "permit")
        store.append(_intent(amount="20", provider="openai", timestamp_unix=now - 4), "permit")
        store.append(_intent(amount="30", provider="cohere", timestamp_unix=now - 3), "permit")
        guard = RuntimeGuard(store)
        v = guard.spend_velocity(
            X402Registry.empty(), window_seconds=10, now_unix=now
        )
        assert v.total_in_window == Decimal("60")
        assert v.cross_provider is True

    def test_window_older_payments_excluded(self) -> None:
        """Payments older than the window don't count."""
        store = _fresh_store()
        now = 1_700_000_100
        # Inside the 10s window.
        store.append(_intent(amount="10", timestamp_unix=now - 5), "permit")
        # Outside the window.
        store.append(_intent(amount="999", timestamp_unix=now - 100), "permit")
        store.append(_intent(amount="999", timestamp_unix=now - 30), "permit")
        guard = RuntimeGuard(store)
        v = guard.spend_velocity(
            X402Registry.empty(), window_seconds=10, now_unix=now
        )
        assert v.total_in_window == Decimal("10")

    def test_currency_filter_applies(self) -> None:
        """Requested currency isolates from the store."""
        store = _fresh_store()
        now = 1_700_000_100
        store.append(_intent(amount="10", timestamp_unix=now - 1), "permit")
        store.append(_intent(amount="500", currency="ETH", counterparty="cp2", timestamp_unix=now - 1), "permit")
        guard = RuntimeGuard(store)
        usdc = guard.spend_velocity(X402Registry.empty(), currency="USDC", now_unix=now)
        eth = guard.spend_velocity(X402Registry.empty(), currency="ETH", now_unix=now)
        assert usdc.total_in_window == Decimal("10")
        assert eth.total_in_window == Decimal("500")

    def test_wire_is_json_safe(self) -> None:
        """``to_wire`` produces strings for Decimals so JSON can round-trip."""
        v = SpendVelocity(
            rate_per_second=Decimal("1.5"),
            projected_spend_next_n={60: Decimal("90")},
            total_in_window=Decimal("15"),
            cross_provider=True,
            window_seconds=10,
            currency="USDC",
        )
        wire = v.to_wire()
        assert wire["rate_per_second"] == "1.5"
        assert wire["projected_spend_next_n"]["60"] == "90"
        assert wire["cross_provider"] is True


# ── retry_density ───────────────────────────────────────────────────────────


class TestRetryDensity:
    def test_seven_identical_tuple_attempts(self) -> None:
        """7 identical-tuple payments in 9s → identical_attempts=7."""
        store = _fresh_store()
        now = 1_700_000_100
        sig = {"provider": "anthropic", "counterparty": "cp1", "amount": "10", "currency": "USDC"}
        for i in range(7):
            store.append(
                _intent(amount="10", timestamp_unix=now - 8 + i),
                "reject",
            )
        guard = RuntimeGuard(store, burst_window_seconds=10)
        d = guard.retry_density(X402Registry.empty(), sig, now_unix=now)
        assert d.identical_attempts_in_burst == 7
        assert d.burst_window_seconds == 10
        assert 0.0 < d.density_score <= 1.0

    def test_different_providers_excluded(self) -> None:
        """Same-tuple query ignores mismatched providers."""
        store = _fresh_store()
        now = 1_700_000_100
        sig = {"provider": "anthropic", "counterparty": "cp1", "amount": "10", "currency": "USDC"}
        for i in range(5):
            store.append(
                _intent(amount="10", provider="openai", timestamp_unix=now - i),
                "reject",
            )
        guard = RuntimeGuard(store, burst_window_seconds=10)
        d = guard.retry_density(X402Registry.empty(), sig, now_unix=now)
        assert d.identical_attempts_in_burst == 0

    def test_burst_window_boundary(self) -> None:
        """Only attempts inside the burst window are counted."""
        store = _fresh_store()
        now = 1_700_000_100
        sig = {"provider": "anthropic", "counterparty": "cp1", "amount": "10", "currency": "USDC"}
        # Inside the window (5).
        for i in range(5):
            store.append(_intent(amount="10", timestamp_unix=now - i), "reject")
        # Outside the window.
        for i in range(10):
            store.append(_intent(amount="10", timestamp_unix=now - 100 - i), "reject")
        guard = RuntimeGuard(store, burst_window_seconds=10)
        d = guard.retry_density(X402Registry.empty(), sig, now_unix=now)
        assert d.identical_attempts_in_burst == 5

    def test_missing_signature_keys_returns_zero(self) -> None:
        store = _fresh_store()
        guard = RuntimeGuard(store)
        d = guard.retry_density(
            X402Registry.empty(),
            {"provider": "anthropic"},  # missing counterparty/amount/currency
            now_unix=1_700_000_100,
        )
        assert d.identical_attempts_in_burst == 0


# ── CooldownState ───────────────────────────────────────────────────────────


class TestCooldownState:
    def test_empty_when_no_sources(self) -> None:
        store = _fresh_store()
        guard = RuntimeGuard(store)
        cs = guard.cooldown_state(X402Registry.empty(), now_unix=1_700_000_100)
        assert cs.active_cooldowns == ()

    def test_retry_rate_limit_active_contributes_one_entry(self) -> None:
        store = _fresh_store()
        now = 1_700_000_100
        # A recent reject locks out the (provider, counterparty) pair.
        store.append(_intent(amount="10", timestamp_unix=now - 5), "reject")
        reg = X402Registry.empty().declare(RetryRateLimit(min_gap_seconds=30))
        guard = RuntimeGuard(store)
        cs = guard.cooldown_state(reg, now_unix=now)
        assert len(cs.active_cooldowns) == 1
        assert cs.active_cooldowns[0].source == "RetryRateLimit"
        assert cs.active_cooldowns[0].expires_at_unix == (now - 5) + 30

    def test_instability_guard_active_on_two_providers(self) -> None:
        store = _fresh_store()
        now = 1_700_000_100
        # 3 rejects per provider inside a 60s window.
        for provider in ("anthropic", "openai"):
            for i in range(3):
                store.append(
                    _intent(
                        amount="10",
                        provider=provider,
                        counterparty=f"cp_{provider}",
                        timestamp_unix=now - 5 - i,
                    ),
                    "reject",
                )
        reg = X402Registry.empty()
        for p in ("anthropic", "openai"):
            reg = reg.declare(
                InstabilityGuard(
                    provider=p,
                    reject_threshold=3,
                    window_seconds=60,
                    tighten_to=Decimal("5"),
                    recovery_seconds=120,
                )
            )
        guard = RuntimeGuard(store)
        cs = guard.cooldown_state(reg, now_unix=now)
        ig_entries = [e for e in cs.active_cooldowns if e.source == "InstabilityGuard"]
        assert len(ig_entries) == 2

    def test_expired_entries_pruned(self) -> None:
        store = _fresh_store()
        now = 1_700_000_100
        # Reject happened 60s ago; min_gap_seconds=30 is already elapsed.
        store.append(_intent(amount="10", timestamp_unix=now - 60), "reject")
        reg = X402Registry.empty().declare(RetryRateLimit(min_gap_seconds=30))
        guard = RuntimeGuard(store)
        cs = guard.cooldown_state(reg, now_unix=now)
        assert cs.active_cooldowns == ()

    def test_cooldowns_sorted_by_expiry(self) -> None:
        store = _fresh_store()
        now = 1_700_000_100
        # Two rejects on different counterparties with different ages.
        store.append(
            _intent(amount="10", counterparty="cp_old", timestamp_unix=now - 20),
            "reject",
        )
        store.append(
            _intent(amount="10", counterparty="cp_new", timestamp_unix=now - 2),
            "reject",
        )
        reg = X402Registry.empty().declare(RetryRateLimit(min_gap_seconds=60))
        guard = RuntimeGuard(store)
        cs = guard.cooldown_state(reg, now_unix=now)
        assert len(cs.active_cooldowns) == 2
        # Ascending by expiry.
        assert cs.active_cooldowns[0].expires_at_unix < cs.active_cooldowns[1].expires_at_unix

    def test_merge_cooldown_contributes_entries(self) -> None:
        store = _fresh_store()
        cd = MergeFailureCooldown(cooldown_seconds=60)
        cd.trigger("main", now_unix=1_700_000_100)
        guard = RuntimeGuard(store, merge_cooldown=cd)
        cs = guard.cooldown_state(X402Registry.empty(), now_unix=1_700_000_120)
        assert any(e.source == "MergeFailureCooldown" for e in cs.active_cooldowns)


# ── TighteningLevel ─────────────────────────────────────────────────────────


class TestTighteningLevel:
    def test_none_when_no_guards(self) -> None:
        store = _fresh_store()
        guard = RuntimeGuard(store)
        level = guard.tightening_level(X402Registry.empty(), now_unix=1_700_000_100)
        assert level.level == "none"
        assert level.providers_tightening == ()
        assert level.severe_provider is None

    def test_mild_when_one_guard_active(self) -> None:
        store = _fresh_store()
        now = 1_700_000_100
        for i in range(3):
            store.append(_intent(amount="10", timestamp_unix=now - i), "reject")
        reg = X402Registry.empty().declare(
            InstabilityGuard(
                provider="anthropic", reject_threshold=3,
                window_seconds=60, tighten_to=Decimal("5"), recovery_seconds=120,
            )
        )
        guard = RuntimeGuard(store)
        level = guard.tightening_level(reg, now_unix=now)
        assert level.level == "mild"
        assert "anthropic" in level.providers_tightening

    def test_moderate_when_three_plus_simultaneous(self) -> None:
        store = _fresh_store()
        now = 1_700_000_100
        providers = ("anthropic", "openai", "cohere")
        for p in providers:
            for i in range(3):
                store.append(
                    _intent(amount="10", provider=p, counterparty=f"cp_{p}", timestamp_unix=now - i),
                    "reject",
                )
        reg = X402Registry.empty()
        for p in providers:
            reg = reg.declare(
                InstabilityGuard(
                    provider=p, reject_threshold=3,
                    window_seconds=60, tighten_to=Decimal("5"), recovery_seconds=120,
                )
            )
        guard = RuntimeGuard(store)
        level = guard.tightening_level(reg, now_unix=now)
        assert level.level == "moderate"
        assert len(level.providers_tightening) == 3

    def test_severe_when_single_provider_hits_threshold(self) -> None:
        store = _fresh_store()
        now = 1_700_000_100
        # One provider with >= SEVERE_REJECT_THRESHOLD rejects in window.
        for i in range(SEVERE_REJECT_THRESHOLD + 1):
            store.append(_intent(amount="10", timestamp_unix=now - i), "reject")
        reg = X402Registry.empty().declare(
            InstabilityGuard(
                provider="anthropic", reject_threshold=3,
                window_seconds=60, tighten_to=Decimal("5"), recovery_seconds=120,
            )
        )
        guard = RuntimeGuard(store)
        level = guard.tightening_level(reg, now_unix=now)
        assert level.level == "severe"
        assert level.severe_provider == "anthropic"


# ── BurstVelocityCap ────────────────────────────────────────────────────────


class TestBurstVelocityCap:
    def test_under_cap_permits(self) -> None:
        cap = BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=10)
        history = [
            _intent(amount="10", timestamp_unix=1_700_000_000 + i)
            for i in range(5)
        ]
        intent = _intent(amount="10", timestamp_unix=1_700_000_010)
        assert cap.check_payment(intent, history) is None

    def test_cross_provider_sum_over_cap_rejects(self) -> None:
        cap = BurstVelocityCap(
            max_per_window=Decimal("100"),
            window_seconds=10,
            cross_provider=True,
        )
        # Three providers each at $40; total 120 > 100.
        now = 1_700_000_010
        history = [
            _intent(amount="40", provider="anthropic", timestamp_unix=now - 5),
            _intent(amount="40", provider="openai", timestamp_unix=now - 3),
        ]
        intent = _intent(amount="40", provider="cohere", counterparty="cp3", timestamp_unix=now)
        v = cap.check_payment(intent, history)
        assert v is not None
        assert v.rule_id == "burst_velocity_exceeded"

    def test_per_provider_mode_ignores_other_providers(self) -> None:
        cap = BurstVelocityCap(
            max_per_window=Decimal("100"),
            window_seconds=10,
            cross_provider=False,
        )
        now = 1_700_000_010
        history = [
            _intent(amount="90", provider="openai", counterparty="cp2", timestamp_unix=now - 1),
        ]
        intent = _intent(amount="10", provider="anthropic", timestamp_unix=now)
        # openai's $90 should not count against anthropic.
        assert cap.check_payment(intent, history) is None

    def test_validation(self) -> None:
        with pytest.raises(InvariantError):
            BurstVelocityCap(max_per_window=Decimal("0"), window_seconds=10)
        with pytest.raises(InvariantError):
            BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=0)


class TestBurstVelocityCapZ3Composition:
    def test_fragment_v2_membership(self) -> None:
        """BurstVelocityCap advertises as fragment v2."""
        from adapter.z3_compiler import is_fragment_v2_invariant
        bvc = BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=10)
        assert is_fragment_v2_invariant(bvc)

    def test_body_compiles_sat_under_z3(self) -> None:
        z3 = pytest.importorskip("z3")
        from adapter.z3_compiler import compile_invariant_v2
        bvc = BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=10)
        constraints, summary = compile_invariant_v2(bvc, unroll_steps=5)
        assert summary["class"] == "BurstVelocityCap"
        solver = z3.Solver()
        for c in constraints:
            solver.add(c)
        assert solver.check() == z3.sat

    def test_composes_cleanly_with_spending_cap(self) -> None:
        """BurstVelocityCap + SpendingCap compose without false conflict."""
        z3 = pytest.importorskip("z3")
        from adapter.z3_compiler import compile_invariant_v2
        bvc = BurstVelocityCap(max_per_window=Decimal("50"), window_seconds=10)
        sc = SpendingCap(
            max_amount=Decimal("1000"), scope="per_window", window_seconds=60
        )
        bvc_cs, _ = compile_invariant_v2(bvc, unroll_steps=5)
        sc_cs, _ = compile_invariant_v2(sc, unroll_steps=5)
        solver = z3.Solver()
        for c in bvc_cs + sc_cs:
            solver.add(c)
        assert solver.check() == z3.sat


# ── SpendingCap with cross_provider_cap ─────────────────────────────────────


class TestSpendingCapCrossProvider:
    def test_none_preserves_old_behaviour(self) -> None:
        cap = SpendingCap(
            max_amount=Decimal("100"),
            scope="per_window",
            window_seconds=60,
            cross_provider_cap=None,
        )
        now = 1_700_000_100
        # $40 + $40 (same provider) + $40 intent = $120 > 100 → reject.
        history = [
            _intent(amount="40", provider="anthropic", timestamp_unix=now - 30),
            _intent(amount="40", provider="anthropic", timestamp_unix=now - 20),
        ]
        intent = _intent(amount="40", provider="anthropic", timestamp_unix=now)
        v = cap.check_payment(intent, history)
        assert v is not None
        assert v.rule_id == "spending_cap_per_window"

    def test_per_provider_under_cap_cross_over_rejects(self) -> None:
        """Per-provider scope: cumulative-per-provider is under cap, but the
        cross-provider aggregate crosses its cap.
        """
        cap = SpendingCap(
            max_amount=Decimal("100"),
            scope="per_provider_per_window",
            window_seconds=60,
            provider="anthropic",
            cross_provider_cap=Decimal("150"),
        )
        now = 1_700_000_100
        # anthropic: $50 history + $40 intent = $90 < 100 (per-provider ok).
        # All providers: $50 + $70 + $40 = $160 > 150 (cross-provider cap
        # tripped).
        history = [
            _intent(amount="50", provider="anthropic", timestamp_unix=now - 30),
            _intent(amount="70", provider="openai", counterparty="cp2", timestamp_unix=now - 20),
        ]
        intent = _intent(amount="40", provider="anthropic", timestamp_unix=now)
        v = cap.check_payment(intent, history)
        assert v is not None
        assert v.rule_id == "spending_cap_per_provider_per_window_cross_provider"

    def test_validation(self) -> None:
        with pytest.raises(InvariantError):
            SpendingCap(
                max_amount=Decimal("100"),
                scope="per_window",
                window_seconds=60,
                cross_provider_cap=Decimal("-1"),
            )
        with pytest.raises(InvariantError):
            # per_tx + cross_provider_cap forbidden (no window to aggregate).
            SpendingCap(
                max_amount=Decimal("100"),
                scope="per_tx",
                cross_provider_cap=Decimal("500"),
            )


# ── project_spend ───────────────────────────────────────────────────────────


class TestProjectSpend:
    def test_steady_linear_extrapolation(self) -> None:
        store = _fresh_store()
        guard = RuntimeGuard(store)
        # 2/s for 60s = 120.
        assert guard.project_spend(Decimal("2"), 60) == Decimal("120")

    def test_horizon_capped_at_max(self) -> None:
        store = _fresh_store()
        guard = RuntimeGuard(store)
        # Asking for 10_000s → clipped to MAX_PROJECTION_HORIZON_SECONDS.
        projected = guard.project_spend(Decimal("1"), 10_000)
        assert projected == Decimal(MAX_PROJECTION_HORIZON_SECONDS)

    def test_negative_velocity_clamps_to_zero(self) -> None:
        store = _fresh_store()
        guard = RuntimeGuard(store)
        assert guard.project_spend(Decimal("-5"), 60) == Decimal("0")

    def test_negative_horizon_rejected(self) -> None:
        store = _fresh_store()
        guard = RuntimeGuard(store)
        with pytest.raises(ValueError):
            guard.project_spend(Decimal("1"), -1)


# ── Critical Test 3: adaptive tightening reduces later thresholds ───────────


class TestAdaptiveTightening:
    def test_repeated_violations_tighten_and_reduce_effective_limit(self) -> None:
        """CRITICAL: repeated rejections tighten the guard so later requests
        are blocked at a LOWER amount than the original policy allowed.

        Before: intent of $50 passes under SpendingCap of $100.
        After:  the same $50 intent fails once InstabilityGuard has tightened
                to $5 after repeated rejects.
        """
        from adapter.invariants import MaxPerCall
        store = _fresh_store()
        # SpendingCap allows up to $100 per tx. MaxPerCall caps at $30 to
        # force rejects that feed the instability guard.
        max_per_call = MaxPerCall(max_amount=Decimal("30"))
        guard_inv = InstabilityGuard(
            provider="anthropic",
            reject_threshold=3,
            window_seconds=60,
            tighten_to=Decimal("5"),
            recovery_seconds=120,
        )
        reg = (
            X402Registry.empty()
            .declare(max_per_call)
            .declare(guard_inv)
        )
        now = 1_700_000_100
        rejects: List[PaymentIntent] = []

        # Simulate 3 rejects from MaxPerCall (all above $30).
        for i in range(3):
            r = _intent(amount="50", timestamp_unix=now - 30 + i)
            v = reg.check_payment(r, history=(), rejects=tuple(rejects))
            # MaxPerCall trips first.
            assert v is not None and v.rule_id == "max_per_call"
            rejects.append(r)
            store.append(r, "reject")

        # Runtime guard now sees tightening.
        rg = RuntimeGuard(store)
        level = rg.tightening_level(reg, now_unix=now)
        assert level.level in ("mild", "moderate", "severe")
        assert "anthropic" in level.providers_tightening

        # Crucially: an intent that the BASE SpendingCap-style rule would
        # admit ($20, well under MaxPerCall of $30) is now REJECTED by the
        # instability-guard tightening-to-$5 rule because of the accumulated
        # rejects. "Repeated violations reduce effective limits."
        under_orig_threshold = _intent(amount="20", timestamp_unix=now)
        v = reg.check_payment(
            under_orig_threshold, history=(), rejects=tuple(rejects)
        )
        assert v is not None, (
            "adaptive tightening should block a request that the initial "
            "policy admitted"
        )
        assert v.rule_id == "instability_guard"


# ── Revision-aware ──────────────────────────────────────────────────────────


class TestRevisionAware:
    def test_update_invariant_preserves_history_and_applies_new_cap(self) -> None:
        """A policy update does NOT reset velocity counters; the new cap
        applies to subsequent checks against the same history.
        """
        store = _fresh_store()
        now = 1_700_000_100
        # Seed the permit history.
        for i in range(5):
            store.append(_intent(amount="20", timestamp_unix=now - 10 + i), "permit")
        guard = RuntimeGuard(store)
        v1 = guard.spend_velocity(
            X402Registry.empty(), window_seconds=30, now_unix=now
        )
        # First measurement sees the whole $100 in the window.
        assert v1.total_in_window == Decimal("100")
        # Simulate a revision swap: new SpendingCap with a tighter
        # cross_provider_cap. The history store is untouched by the swap.
        reg_new = X402Registry.empty().declare(
            SpendingCap(
                max_amount=Decimal("500"),
                scope="per_window",
                window_seconds=30,
                cross_provider_cap=Decimal("75"),
            )
        )
        # Velocity is still $100 in the window -- policy swap did not
        # reset state.
        v2 = guard.spend_velocity(reg_new, window_seconds=30, now_unix=now)
        assert v2.total_in_window == v1.total_in_window
        # New cap now applies: a $1 intent pushes the running total past
        # $75 so the SpendingCap rejects (via its cross_provider_cap arm).
        cap = reg_new.invariants[0]
        intent = _intent(amount="1", provider="cohere", counterparty="cp3", timestamp_unix=now)
        history = tuple(
            p for p in store.recent_oldest_first("permit")
            if isinstance(p, PaymentIntent)
        )
        vio = cap.check_payment(intent, history)
        assert vio is not None
        assert vio.rule_id.endswith("_cross_provider")


# ── Daemon runtime_state op round-trip ──────────────────────────────────────


@pytest.fixture
def daemon_socket(tmp_path: Path) -> Iterator[str]:
    """Spin up a CageDaemon on a short UDS path (macOS 104-char limit)."""
    # /tmp keeps paths well under 104 chars even on macOS Sequoia.
    sock_path = f"/tmp/rg-{os.getpid()}-{int(time.time() * 1000) % 100_000}.sock"
    try:
        os.unlink(sock_path)
    except FileNotFoundError:
        pass
    from daemon.server import CageDaemon
    daemon = CageDaemon(socket_path=sock_path)
    yield sock_path, daemon
    try:
        os.unlink(sock_path)
    except FileNotFoundError:
        pass


class TestDaemonRuntimeStateOp:
    def test_runtime_state_empty_registry(self, daemon_socket) -> None:
        sock_path, daemon = daemon_socket
        resp = daemon.dispatch({"op": "runtime_state"})
        assert resp["verdict"] == "ok"
        assert "spend_velocity" in resp
        assert "retry_density" in resp
        assert "cooldown_state" in resp
        assert "tightening_level" in resp
        assert resp["tightening_level"]["level"] == "none"
        assert resp["active_cooldowns_count"] == 0

    def test_runtime_state_with_active_velocity(self, daemon_socket) -> None:
        sock_path, daemon = daemon_socket
        now = int(time.time())
        store = daemon._history_store
        for i in range(5):
            store.append(_intent(amount="10", timestamp_unix=now - i), "permit")
        resp = daemon.dispatch({"op": "runtime_state", "currency": "USDC"})
        assert resp["verdict"] == "ok"
        total = Decimal(resp["spend_velocity"]["total_in_window"])
        assert total == Decimal("50")

    def test_runtime_state_currency_filter(self, daemon_socket) -> None:
        sock_path, daemon = daemon_socket
        now = int(time.time())
        store = daemon._history_store
        store.append(_intent(amount="10", timestamp_unix=now - 1), "permit")
        resp_usdc = daemon.dispatch({"op": "runtime_state", "currency": "USDC"})
        resp_eth = daemon.dispatch({"op": "runtime_state", "currency": "ETH"})
        assert Decimal(resp_usdc["spend_velocity"]["total_in_window"]) == Decimal("10")
        assert Decimal(resp_eth["spend_velocity"]["total_in_window"]) == Decimal("0")


class TestDaemonBurstVelocityCapBuilder:
    def test_build_burst_velocity_cap(self, daemon_socket) -> None:
        sock_path, daemon = daemon_socket
        inv = daemon._build_x402_invariant(
            {
                "kind": "burst_velocity_cap",
                "max_per_window": "100",
                "window_seconds": 10,
                "currency": "USDC",
                "cross_provider": True,
            }
        )
        assert isinstance(inv, BurstVelocityCap)
        assert inv.max_per_window == Decimal("100")
        assert inv.cross_provider is True

    def test_build_spending_cap_with_cross_provider_cap(self, daemon_socket) -> None:
        sock_path, daemon = daemon_socket
        inv = daemon._build_x402_invariant(
            {
                "kind": "spending_cap",
                "max_amount": "100",
                "scope": "per_window",
                "window_seconds": 60,
                "cross_provider_cap": "250",
            }
        )
        assert isinstance(inv, SpendingCap)
        assert inv.cross_provider_cap == Decimal("250")
