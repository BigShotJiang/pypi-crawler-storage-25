"""Tests for the v0.19.0 Guaranteed Mode audit evidence chain.

Covers:
  * PolicyAdmissionEvidence / RuntimeDecisionEvidence frozen-ness.
  * GuaranteedAuditBundle append-only locking, HMAC sign + verify,
    tamper detection, version gating.
  * JSONL store append + iterate round-trips, find helpers.
  * CLI subcommands (inspect-policy, inspect-proof, replay-decision,
    export-audit-bundle) through argparse wiring.
  * Audit replay: a blocked runtime decision is saved, exported,
    reloaded via replay-decision, and matches byte-for-byte.
"""

from __future__ import annotations

import io
import json
import os
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from types import MappingProxyType
from typing import Any, Dict

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from adapter.guaranteed_audit import (
    AuditBundleLocked,
    BUNDLE_VERSION_V1,
    GuaranteedAuditBundle,
    GuaranteedAuditError,
    PolicyAdmissionEvidence,
    RuntimeDecisionEvidence,
    append_admission_record,
    append_decision_record,
    bundle_records,
    export_range,
    find_admission_by_revision,
    find_decision_by_id,
    iter_records,
    load_admissions,
    load_decisions,
    temporary_audit_store,
)
from adapter.guaranteed_stubs import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedProver,
    GuaranteedMutationPipeline,
    MutationProposal,
    ProofArtifactStore,
    build_admission_evidence,
    build_decision_evidence,
    guaranteed_should_pay_x402,
)
from adapter.invariants import MaxPerCall, ProviderAllowlist, SpendingCap
from adapter.payment_intent_matcher import PaymentIntent
from adapter.x402_registry import X402Registry


_DEMO_KEY = b"A" * 32
_OTHER_KEY = b"B" * 32


# ── fixtures ────────────────────────────────────────────────────────────────


@pytest.fixture
def admission_evidence() -> PolicyAdmissionEvidence:
    now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=timezone.utc)
    return PolicyAdmissionEvidence(
        policy_id="bank-prod",
        revision_id="rev-001",
        policy_source_hash="a" * 64,
        compile_hash="b" * 64,
        proof_result="proven",
        prove_backend_version="shim-prover-0.1",
        prove_timestamp=now,
        totality_status="passed",
        language_tier_version=GUARANTEED_LANGUAGE_VERSION,
        admitted_at=now,
        admitted_by="compliance-bot",
    )


@pytest.fixture
def decision_evidence() -> RuntimeDecisionEvidence:
    now = datetime(2026, 4, 19, 12, 5, 0, tzinfo=timezone.utc)
    return RuntimeDecisionEvidence(
        decision_id="dec-001",
        payment_intent_hash="c" * 64,
        policy_revision_used="rev-001",
        proof_mode="guaranteed",
        proof_artifact_reference="art-001:abc123",
        guard_state_summary={"intent_amount": "40", "cap": "100"},
        allow=True,
        reason="allow",
        explanation="Under every cap.",
        decision_timestamp=now,
    )


@pytest.fixture
def tmp_audit_store(tmp_path):
    """Point the audit store at a tempdir for the duration of a test."""
    target = tmp_path / "guaranteed_audit.jsonl"
    prev = os.environ.get("TAU_X402_CAGE_AUDIT_STORE")
    os.environ["TAU_X402_CAGE_AUDIT_STORE"] = str(target)
    try:
        yield target
    finally:
        if prev is None:
            os.environ.pop("TAU_X402_CAGE_AUDIT_STORE", None)
        else:
            os.environ["TAU_X402_CAGE_AUDIT_STORE"] = prev


# ── evidence dataclasses ────────────────────────────────────────────────────


class TestPolicyAdmissionEvidence:
    def test_is_frozen(self, admission_evidence: PolicyAdmissionEvidence) -> None:
        with pytest.raises(Exception):  # dataclass frozen → FrozenInstanceError
            admission_evidence.policy_id = "hacked"  # type: ignore[misc]

    def test_validates_totality_status(self) -> None:
        now = datetime.now(tz=timezone.utc)
        with pytest.raises(GuaranteedAuditError):
            PolicyAdmissionEvidence(
                policy_id="x", revision_id="y",
                policy_source_hash="a", compile_hash="b",
                proof_result="proven", prove_backend_version="z",
                prove_timestamp=now,
                totality_status="fake-status",
                language_tier_version="t",
                admitted_at=now,
            )

    def test_requires_non_empty_strings(self) -> None:
        now = datetime.now(tz=timezone.utc)
        with pytest.raises(GuaranteedAuditError):
            PolicyAdmissionEvidence(
                policy_id="", revision_id="y",
                policy_source_hash="a", compile_hash="b",
                proof_result="proven", prove_backend_version="z",
                prove_timestamp=now, totality_status="passed",
                language_tier_version="t", admitted_at=now,
            )

    def test_dict_roundtrip_is_stable(
        self, admission_evidence: PolicyAdmissionEvidence,
    ) -> None:
        blob = json.dumps(admission_evidence.to_dict(), sort_keys=True)
        rehydrated = PolicyAdmissionEvidence.from_dict(json.loads(blob))
        assert rehydrated == admission_evidence


class TestRuntimeDecisionEvidence:
    def test_is_frozen(self, decision_evidence: RuntimeDecisionEvidence) -> None:
        with pytest.raises(Exception):
            decision_evidence.allow = False  # type: ignore[misc]

    def test_guard_state_is_readonly_proxy(
        self, decision_evidence: RuntimeDecisionEvidence,
    ) -> None:
        assert isinstance(decision_evidence.guard_state_summary, MappingProxyType)
        with pytest.raises(TypeError):
            decision_evidence.guard_state_summary["hacked"] = "yes"  # type: ignore[index]

    def test_proof_mode_is_guaranteed_only(self) -> None:
        now = datetime.now(tz=timezone.utc)
        with pytest.raises(GuaranteedAuditError):
            RuntimeDecisionEvidence(
                decision_id="x",
                payment_intent_hash="y",
                policy_revision_used="z",
                proof_mode="advisory",  # type: ignore[arg-type]
                proof_artifact_reference="ref",
                guard_state_summary={},
                allow=True,
                reason="r",
                explanation="e",
                decision_timestamp=now,
            )

    def test_dict_roundtrip_is_stable(
        self, decision_evidence: RuntimeDecisionEvidence,
    ) -> None:
        rehydrated = RuntimeDecisionEvidence.from_dict(decision_evidence.to_dict())
        assert rehydrated.to_dict() == decision_evidence.to_dict()


# ── JSONL store ─────────────────────────────────────────────────────────────


class TestStore:
    def test_append_and_iter_roundtrip(
        self, tmp_audit_store: Path,
        admission_evidence: PolicyAdmissionEvidence,
        decision_evidence: RuntimeDecisionEvidence,
    ) -> None:
        append_admission_record(admission_evidence)
        append_decision_record(decision_evidence)

        records = list(iter_records())
        assert len(records) == 2
        assert records[0][0] == "policy_admission"
        assert records[1][0] == "runtime_decision"

    def test_find_by_revision(
        self, tmp_audit_store: Path,
        admission_evidence: PolicyAdmissionEvidence,
    ) -> None:
        append_admission_record(admission_evidence)
        found = find_admission_by_revision("rev-001")
        assert found == admission_evidence
        assert find_admission_by_revision("nonexistent") is None

    def test_find_by_decision_id(
        self, tmp_audit_store: Path,
        decision_evidence: RuntimeDecisionEvidence,
    ) -> None:
        append_decision_record(decision_evidence)
        found = find_decision_by_id("dec-001")
        assert found is not None
        assert found.to_dict() == decision_evidence.to_dict()

    def test_malformed_line_raises(self, tmp_audit_store: Path) -> None:
        tmp_audit_store.parent.mkdir(parents=True, exist_ok=True)
        tmp_audit_store.write_text("not-json\n", encoding="utf-8")
        with pytest.raises(GuaranteedAuditError):
            list(iter_records())


# ── bundle sign + verify ────────────────────────────────────────────────────


class TestBundle:
    def test_serialize_verify_roundtrip(
        self, admission_evidence: PolicyAdmissionEvidence,
        decision_evidence: RuntimeDecisionEvidence,
    ) -> None:
        b = GuaranteedAuditBundle()
        b.add_admission(admission_evidence)
        b.add_decision(decision_evidence)
        blob = b.serialize(hmac_key=_DEMO_KEY)

        assert GuaranteedAuditBundle.verify(blob, _DEMO_KEY) is True
        assert GuaranteedAuditBundle.verify(blob, _OTHER_KEY) is False

    def test_tamper_breaks_verification(
        self, admission_evidence: PolicyAdmissionEvidence,
    ) -> None:
        b = GuaranteedAuditBundle()
        b.add_admission(admission_evidence)
        blob = b.serialize(hmac_key=_DEMO_KEY)
        # Flip a byte in the payload portion (first line).
        payload, sig = blob.split(b"\n", 1)
        tampered_payload = payload[:-2] + b"Z" + payload[-1:]
        tampered = tampered_payload + b"\n" + sig
        assert GuaranteedAuditBundle.verify(tampered, _DEMO_KEY) is False

    def test_is_append_only_after_serialize(
        self, admission_evidence: PolicyAdmissionEvidence,
        decision_evidence: RuntimeDecisionEvidence,
    ) -> None:
        b = GuaranteedAuditBundle()
        b.add_admission(admission_evidence)
        _ = b.serialize(hmac_key=_DEMO_KEY)

        with pytest.raises(AuditBundleLocked):
            b.add_admission(admission_evidence)
        with pytest.raises(AuditBundleLocked):
            b.add_decision(decision_evidence)
        with pytest.raises(AuditBundleLocked):
            b.serialize(hmac_key=_DEMO_KEY)

    def test_short_key_rejected(
        self, admission_evidence: PolicyAdmissionEvidence,
    ) -> None:
        b = GuaranteedAuditBundle()
        b.add_admission(admission_evidence)
        with pytest.raises(GuaranteedAuditError):
            b.serialize(hmac_key=b"short")

    def test_records_rehydrate_from_bundle(
        self, admission_evidence: PolicyAdmissionEvidence,
        decision_evidence: RuntimeDecisionEvidence,
    ) -> None:
        b = GuaranteedAuditBundle()
        b.add_admission(admission_evidence)
        b.add_decision(decision_evidence)
        blob = b.serialize(hmac_key=_DEMO_KEY)
        admissions, decisions = bundle_records(blob)
        assert admissions == (admission_evidence,)
        assert decisions[0].to_dict() == decision_evidence.to_dict()

    def test_version_mismatch_fails(self) -> None:
        # Hand-craft a bundle with wrong version and confirm verify rejects.
        body = json.dumps(
            {"bundle_version": "99", "records": [], "created_at": "2026-01-01T00:00:00+00:00"},
            sort_keys=True, separators=(",", ":"),
        )
        import hashlib, hmac as _hmac
        mac = _hmac.new(_DEMO_KEY, body.encode("utf-8"), hashlib.sha256).hexdigest()
        sig = json.dumps({"signature": mac, "algorithm": "hmac-sha256"}, sort_keys=True, separators=(",", ":"))
        blob = (body + "\n" + sig + "\n").encode("utf-8")
        assert GuaranteedAuditBundle.verify(blob, _DEMO_KEY) is False


# ── range export + audit replay ─────────────────────────────────────────────


class TestExportRange:
    def test_export_filters_by_time(self, tmp_audit_store: Path) -> None:
        early = PolicyAdmissionEvidence(
            policy_id="p", revision_id="r1",
            policy_source_hash="a", compile_hash="b",
            proof_result="proven", prove_backend_version="v",
            prove_timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
            totality_status="passed", language_tier_version="t",
            admitted_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        )
        late = PolicyAdmissionEvidence(
            policy_id="p", revision_id="r2",
            policy_source_hash="a", compile_hash="b",
            proof_result="proven", prove_backend_version="v",
            prove_timestamp=datetime(2026, 6, 1, tzinfo=timezone.utc),
            totality_status="passed", language_tier_version="t",
            admitted_at=datetime(2026, 6, 1, tzinfo=timezone.utc),
        )
        append_admission_record(early)
        append_admission_record(late)
        bundle = export_range(since=datetime(2026, 3, 1, tzinfo=timezone.utc))
        assert bundle.admission_count == 1


class TestAuditReplay:
    """Integration: blocked decision -> exported -> reloaded == original."""

    def test_blocked_decision_survives_export_roundtrip(
        self, tmp_audit_store: Path,
    ) -> None:
        # Set up a registry that will reject a $150 tx.
        reg = X402Registry.empty().declare(
            SpendingCap(max_amount=Decimal("100"), currency="USDC", scope="per_tx"),
        )
        intent = PaymentIntent(
            amount=Decimal("150"), currency="USDC",
            provider="provider-a", counterparty="vendor",
            rail="x402", timestamp_unix=1_713_456_789,
        )
        store = ProofArtifactStore()
        prover = GuaranteedProver(artifact_store=store)
        artifact = prover.prove_admission(
            policy_id="p", revision_id="rev-100",
            invariants=(SpendingCap(max_amount=Decimal("100"), currency="USDC", scope="per_tx"),),
            policy_source="[]",
        )
        decision = guaranteed_should_pay_x402(
            intent=intent, registry=reg,
            policy_revision_id="rev-100",
            proof_artifact=artifact,
        )
        assert decision.allow is False
        evidence = build_decision_evidence(
            intent=intent, decision=decision,
            policy_revision_id="rev-100", artifact=artifact,
        )
        append_decision_record(evidence)

        # Export bundle, verify, and reload.
        b = export_range()
        blob = b.serialize(hmac_key=_DEMO_KEY)
        assert GuaranteedAuditBundle.verify(blob, _DEMO_KEY)
        _, decisions = bundle_records(blob)
        assert len(decisions) == 1
        replayed = decisions[0]
        assert replayed.allow == decision.allow
        assert replayed.reason == decision.reason
        assert replayed.policy_revision_used == "rev-100"


# ── CLI subcommands ─────────────────────────────────────────────────────────


class TestCLISubcommands:
    """Exercise the ``tau-x402-cage guaranteed ...`` subparser tree."""

    def _invoke(self, argv: list[str]) -> tuple[int, str, str]:
        """Run daemon.cli.main with argv and capture (rc, stdout, stderr)."""
        # Patch sys.argv to reach the argparse-driven entry point.
        import contextlib

        from daemon import cli
        stdout, stderr = io.StringIO(), io.StringIO()
        rc = 0
        old_argv = sys.argv[:]
        sys.argv = ["tau-x402-cage"] + argv
        try:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                try:
                    rc = cli.main()
                except SystemExit as se:
                    rc = int(se.code or 0)
        finally:
            sys.argv = old_argv
        return rc, stdout.getvalue(), stderr.getvalue()

    def test_inspect_policy_returns_json(
        self, tmp_audit_store: Path,
        admission_evidence: PolicyAdmissionEvidence,
    ) -> None:
        append_admission_record(admission_evidence)
        rc, out, err = self._invoke(
            ["guaranteed", "inspect-policy", admission_evidence.revision_id]
        )
        assert rc == 0, f"stderr={err!r}"
        data = json.loads(out)
        assert data["revision_id"] == "rev-001"
        assert data["totality_status"] == "passed"

    def test_inspect_policy_missing_returns_1(self, tmp_audit_store: Path) -> None:
        rc, _, err = self._invoke(
            ["guaranteed", "inspect-policy", "nope"]
        )
        assert rc == 1
        assert "not found" in err.lower() or "no admission" in err.lower()

    def test_inspect_proof_returns_json(
        self, tmp_audit_store: Path,
        admission_evidence: PolicyAdmissionEvidence,
    ) -> None:
        append_admission_record(admission_evidence)
        rc, out, err = self._invoke(
            ["guaranteed", "inspect-proof", admission_evidence.revision_id]
        )
        assert rc == 0, f"stderr={err!r}"
        data = json.loads(out)
        assert "compile_hash" in data or "artifact_id" in data

    def test_replay_decision_roundtrips(
        self, tmp_audit_store: Path,
        decision_evidence: RuntimeDecisionEvidence,
    ) -> None:
        append_decision_record(decision_evidence)
        rc, out, err = self._invoke(
            ["guaranteed", "replay-decision", "dec-001"]
        )
        assert rc == 0, f"stderr={err!r}"
        data = json.loads(out)
        assert data["decision_id"] == "dec-001"
        assert data["replay"] == "ok"
        assert data["allow"] == decision_evidence.allow

    def test_export_audit_bundle_writes_signed_file(
        self, tmp_audit_store: Path, tmp_path: Path,
        admission_evidence: PolicyAdmissionEvidence,
    ) -> None:
        append_admission_record(admission_evidence)
        out = tmp_path / "audit.bundle"
        rc, stdout, stderr = self._invoke([
            "guaranteed", "export-audit-bundle",
            "--out", str(out),
            "--hmac-key-hex", _DEMO_KEY.hex(),
        ])
        assert rc == 0, f"stderr={stderr!r}"
        assert out.exists()
        summary = json.loads(stdout)
        assert summary["admission_count"] == 1
        assert GuaranteedAuditBundle.verify(out.read_bytes(), _DEMO_KEY)

    def test_export_missing_key_errors(
        self, tmp_audit_store: Path, tmp_path: Path,
        admission_evidence: PolicyAdmissionEvidence,
    ) -> None:
        append_admission_record(admission_evidence)
        # Ensure no env leak.
        prev = os.environ.pop("TAU_X402_CAGE_AUDIT_BUNDLE_KEY", None)
        try:
            rc, _, err = self._invoke([
                "guaranteed", "export-audit-bundle",
                "--out", str(tmp_path / "x.bundle"),
            ])
        finally:
            if prev is not None:
                os.environ["TAU_X402_CAGE_AUDIT_BUNDLE_KEY"] = prev
        assert rc == 1
        assert "hmac" in err.lower() or "key" in err.lower()
