"""Coverage-closing tests for the v0.18.0 CI gate.

Groups of tests targeting error branches + edge cases that were uncovered
by the feature-focused test suite:

  * saas/billing.py — StripeBillingReporter success, non-2xx, network error
  * saas/app.py — rate-limit middleware 429, error paths, exempt prefixes
  * saas/metrics_route.py — 503 when prometheus_client unavailable
  * adapter/policy_loader.py — tiny YAML fallback (no-pyyaml path)
  * adapter/audit_export.py — verify_bundle error branches
  * adapter/webhook_sink.py — circuit-breaker + config edge cases
  * adapter/revision_sync.py — config edge cases + loop prevention

No production code is modified; only tests are added.
"""
from __future__ import annotations

import base64
import io
import json
import os
import sys
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict
from unittest.mock import patch, MagicMock

import pytest


# ═══════════════════════════════════════════════════════════════════════════
# saas/billing.py — StripeBillingReporter paths
# ═══════════════════════════════════════════════════════════════════════════


class TestStripeBillingReporter:
    def test_from_env_reads_api_key_and_event(self, monkeypatch) -> None:
        from saas.billing import StripeBillingReporter

        monkeypatch.setenv("STRIPE_API_KEY", "sk_test_abc")
        monkeypatch.setenv("STRIPE_METER_EVENT_NAME", "custom_event")
        reporter = StripeBillingReporter.from_env()
        assert reporter.api_key == "sk_test_abc"
        assert reporter.event_name == "custom_event"

    def test_from_env_default_event_name(self, monkeypatch) -> None:
        from saas.billing import StripeBillingReporter

        monkeypatch.setenv("STRIPE_API_KEY", "sk_test")
        monkeypatch.delenv("STRIPE_METER_EVENT_NAME", raising=False)
        reporter = StripeBillingReporter.from_env()
        assert reporter.event_name == "tau_x402_check"

    def test_record_check_posts_to_stripe(self) -> None:
        from saas.billing import StripeBillingReporter

        reporter = StripeBillingReporter(api_key="sk_test", event_name="evt")

        # Fake urlopen context manager returning 200.
        fake_resp = MagicMock()
        fake_resp.status = 200
        fake_resp.reason = "OK"
        fake_resp.__enter__ = MagicMock(return_value=fake_resp)
        fake_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=fake_resp) as mock_open:
            reporter.record_check(tenant_id="cus_abc", verdict="permit")
            assert mock_open.called
            call_req = mock_open.call_args[0][0]
            # Stripe wants the bearer header + urlencoded form body.
            assert call_req.headers["Authorization"] == "Bearer sk_test"

    def test_record_check_swallows_error(self) -> None:
        from saas.billing import StripeBillingReporter

        reporter = StripeBillingReporter(api_key="sk_test", event_name="evt")
        with patch("urllib.request.urlopen", side_effect=OSError("no network")):
            # Must not raise — billing never fails the hot path.
            reporter.record_check(tenant_id="cus_abc", verdict="permit")

    def test_record_check_warns_on_non_2xx(self, caplog) -> None:
        from saas.billing import StripeBillingReporter

        reporter = StripeBillingReporter(api_key="sk_test", event_name="evt")
        fake_resp = MagicMock()
        fake_resp.status = 400
        fake_resp.reason = "Bad Request"
        fake_resp.__enter__ = MagicMock(return_value=fake_resp)
        fake_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=fake_resp):
            reporter.record_check(tenant_id="cus_abc", verdict="permit")

    def test_null_billing_reporter_is_noop(self) -> None:
        from saas.billing import NullBillingReporter

        # No raise on any verdict; no state.
        NullBillingReporter().record_check(tenant_id="x", verdict="permit")
        NullBillingReporter().record_check(tenant_id="x", verdict="reject")


# ═══════════════════════════════════════════════════════════════════════════
# saas/app.py — rate-limit middleware, SaasConfig.from_env validation
# ═══════════════════════════════════════════════════════════════════════════


def _fresh_saas_env(monkeypatch) -> None:
    """Strip SaaS env so each from_env test starts from a clean slate."""
    for k in list(os.environ.keys()):
        if k.startswith(("TAU_X402_", "STRIPE_")):
            monkeypatch.delenv(k, raising=False)


class TestSaasConfigFromEnv:
    def test_missing_hmac_secret_raises(self, monkeypatch) -> None:
        from saas.app import SaasConfig

        _fresh_saas_env(monkeypatch)
        monkeypatch.setenv("TAU_X402_API_KEYS", "{}")
        with pytest.raises(RuntimeError, match="HMAC_SECRET"):
            SaasConfig.from_env()

    def test_short_hmac_secret_raises(self, monkeypatch) -> None:
        from saas.app import SaasConfig

        _fresh_saas_env(monkeypatch)
        monkeypatch.setenv("TAU_X402_API_KEYS", "{}")
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", "0011")  # too short
        with pytest.raises(RuntimeError, match="16 bytes"):
            SaasConfig.from_env()

    def test_non_hex_hmac_secret_raises(self, monkeypatch) -> None:
        from saas.app import SaasConfig

        _fresh_saas_env(monkeypatch)
        monkeypatch.setenv("TAU_X402_API_KEYS", "{}")
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", "zz" * 20)
        with pytest.raises(RuntimeError, match="hex"):
            SaasConfig.from_env()

    def test_non_json_api_keys_raises(self, monkeypatch) -> None:
        from saas.app import SaasConfig

        _fresh_saas_env(monkeypatch)
        monkeypatch.setenv("TAU_X402_API_KEYS", "not-json")
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", "0011223344556677" * 2)
        with pytest.raises(RuntimeError, match="JSON"):
            SaasConfig.from_env()

    def test_non_object_api_keys_raises(self, monkeypatch) -> None:
        from saas.app import SaasConfig

        _fresh_saas_env(monkeypatch)
        monkeypatch.setenv("TAU_X402_API_KEYS", "[]")
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", "0011223344556677" * 2)
        with pytest.raises(RuntimeError, match="object"):
            SaasConfig.from_env()

    def test_defaults_build_cleanly(self, monkeypatch) -> None:
        from saas.app import SaasConfig

        _fresh_saas_env(monkeypatch)
        monkeypatch.setenv("TAU_X402_API_KEYS", '{"tenant":"key"}')
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", "0011223344556677" * 2)
        cfg = SaasConfig.from_env()
        assert cfg.api_keys == {"tenant": "key"}


class TestRateLimitMiddleware:
    def _make_app(self, *, rate_limiter=None, api_keys=None):
        from saas.app import SaasConfig, create_app
        from saas.billing import NullBillingReporter

        api_keys = api_keys or {"tenant1": "k1"}
        cfg = SaasConfig(
            api_keys=api_keys,
            socket_path="/tmp/nonexistent.sock",
            hmac_secret=b"\x00" * 16,
            billing=NullBillingReporter(),
            jwt=None,
            rate_limiter=rate_limiter,
        )
        return create_app(cfg)

    def test_health_is_rate_limit_exempt(self) -> None:
        from fastapi.testclient import TestClient

        # Rate limiter that would reject everything; health must still pass.
        class AlwaysRejectLimiter:
            def try_acquire(self, tenant):
                from saas.rate_limit import AcquireResult
                return AcquireResult(
                    allowed=False,
                    limit=100,
                    remaining=0,
                    reset_at_unix=int(time.time()) + 60,
                    retry_after_s=60.0,
                    reason="qps",
                    quota_limit=0,
                    quota_remaining=0,
                    quota_reset_at_unix=int(time.time()) + 86400,
                )

        app = self._make_app(rate_limiter=AlwaysRejectLimiter())
        client = TestClient(app)
        r = client.get("/v1/health")
        assert r.status_code == 200

    def test_unknown_bearer_bypasses_middleware_then_401(self) -> None:
        from fastapi.testclient import TestClient

        class CountingLimiter:
            def __init__(self):
                self.calls = 0
            def try_acquire(self, tenant):
                self.calls += 1
                from saas.rate_limit import AcquireResult
                return AcquireResult(
                    allowed=True, limit=1000, remaining=999,
                    reset_at_unix=0, retry_after_s=0.0, reason=None,
                    quota_limit=0, quota_remaining=0, quota_reset_at_unix=0,
                )

        limiter = CountingLimiter()
        app = self._make_app(rate_limiter=limiter)
        client = TestClient(app)
        r = client.get("/v1/usage", headers={"authorization": "Bearer nope"})
        assert r.status_code == 401
        # Middleware skipped because tenant unresolved.
        assert limiter.calls == 0

    def test_429_when_rate_limit_exceeded(self) -> None:
        from fastapi.testclient import TestClient

        class RejectLimiter:
            def try_acquire(self, tenant):
                from saas.rate_limit import AcquireResult
                return AcquireResult(
                    allowed=False, limit=100, remaining=0,
                    reset_at_unix=int(time.time()) + 60,
                    retry_after_s=1.5, reason="qps",
                    quota_limit=0, quota_remaining=0, quota_reset_at_unix=0,
                )

        app = self._make_app(rate_limiter=RejectLimiter())
        client = TestClient(app)
        r = client.get("/v1/usage", headers={"authorization": "Bearer k1"})
        assert r.status_code == 429
        assert "Retry-After" in r.headers

    def test_429_quota_variant(self) -> None:
        from fastapi.testclient import TestClient

        class QuotaRejectLimiter:
            def try_acquire(self, tenant):
                from saas.rate_limit import AcquireResult
                return AcquireResult(
                    allowed=False, limit=100, remaining=5,
                    reset_at_unix=int(time.time()) + 60,
                    retry_after_s=3600.0, reason="quota",
                    quota_limit=10, quota_remaining=0,
                    quota_reset_at_unix=int(time.time()) + 86400,
                )

        app = self._make_app(rate_limiter=QuotaRejectLimiter())
        client = TestClient(app)
        r = client.get("/v1/usage", headers={"authorization": "Bearer k1"})
        assert r.status_code == 429
        assert r.headers.get("X-RateLimit-Quota-Exhausted") == "monthly"
        body = r.json()
        assert "quota" in body.get("detail", "").lower()

    def test_503_when_limiter_unreachable(self) -> None:
        from fastapi.testclient import TestClient
        from saas.rate_limit import RateLimitError

        class BrokenLimiter:
            def try_acquire(self, tenant):
                raise RateLimitError("redis down")

        app = self._make_app(rate_limiter=BrokenLimiter())
        client = TestClient(app)
        r = client.get("/v1/usage", headers={"authorization": "Bearer k1"})
        assert r.status_code == 503

    def test_successful_request_gets_rate_headers(self) -> None:
        from fastapi.testclient import TestClient

        class PermitLimiter:
            def try_acquire(self, tenant):
                from saas.rate_limit import AcquireResult
                return AcquireResult(
                    allowed=True, limit=100, remaining=99,
                    reset_at_unix=int(time.time()) + 60,
                    retry_after_s=0.0, reason=None,
                    quota_limit=1000, quota_remaining=999,
                    quota_reset_at_unix=int(time.time()) + 86400,
                )

        app = self._make_app(rate_limiter=PermitLimiter())
        client = TestClient(app)
        r = client.get("/v1/usage", headers={"authorization": "Bearer k1"})
        assert r.status_code == 200
        assert r.headers.get("X-RateLimit-Limit") == "100"
        assert r.headers.get("X-RateLimit-Remaining") == "99"


# ═══════════════════════════════════════════════════════════════════════════
# saas/metrics_route.py — 503 when prometheus_client unavailable
# ═══════════════════════════════════════════════════════════════════════════


class TestMetricsRouteUnavailable:
    def test_503_when_prometheus_client_not_available(self) -> None:
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from saas.metrics_route import build_metrics_router

        app = FastAPI()
        app.include_router(build_metrics_router(token="scrape-token"))
        client = TestClient(app)

        with patch("saas.metrics_route.metrics_available", return_value=False):
            r = client.get(
                "/metrics", headers={"authorization": "Bearer scrape-token"},
            )
        assert r.status_code == 503


# ═══════════════════════════════════════════════════════════════════════════
# saas/main.py — smoke its entry (single import-time line)
# ═══════════════════════════════════════════════════════════════════════════


class TestSaasMainImport:
    def test_importing_saas_main_creates_app(self, monkeypatch) -> None:
        """saas/main.py creates a module-level ``app``. Gate env so the
        import doesn't blow up on missing TAU_X402_HMAC_SECRET."""
        monkeypatch.setenv("TAU_X402_API_KEYS", '{"t":"k"}')
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", "00" * 16)
        # Remove from cache so import runs fresh.
        sys.modules.pop("saas.main", None)
        import saas.main as m
        assert m.app is not None


# ═══════════════════════════════════════════════════════════════════════════
# adapter/policy_loader.py — tiny YAML fallback parser
# ═══════════════════════════════════════════════════════════════════════════


class TestTinyYamlFallback:
    def test_tiny_yaml_parse_basic_mapping(self) -> None:
        from adapter.policy_loader import _tiny_yaml_parse

        doc = _tiny_yaml_parse("version: 1\npolicy:\n  - kind: max_per_call\n    max_amount: \"50\"\n")
        assert doc["version"] == 1
        assert len(doc["policy"]) == 1
        assert doc["policy"][0]["kind"] == "max_per_call"
        assert doc["policy"][0]["max_amount"] == "50"

    def test_tiny_yaml_parse_scalars(self) -> None:
        from adapter.policy_loader import _tiny_yaml_parse

        doc = _tiny_yaml_parse(
            "v: 1\n"
            "name: test\n"
            "flag: true\n"
            "flag2: false\n"
            "empty: null\n"
            "float_val: 1.5\n"
            "list_inline: [a, b, c]\n"
            "empty_list: []\n"
        )
        assert doc["v"] == 1
        assert doc["name"] == "test"
        assert doc["flag"] is True
        assert doc["flag2"] is False
        assert doc["empty"] is None
        assert doc["float_val"] == 1.5
        assert doc["list_inline"] == ["a", "b", "c"]
        assert doc["empty_list"] == []

    def test_tiny_yaml_parse_quoted_strings(self) -> None:
        from adapter.policy_loader import _tiny_yaml_parse

        doc = _tiny_yaml_parse('a: "hello"\nb: \'world\'\n')
        assert doc["a"] == "hello"
        assert doc["b"] == "world"

    def test_tiny_yaml_nested_list_of_scalars(self) -> None:
        from adapter.policy_loader import _tiny_yaml_parse

        doc = _tiny_yaml_parse(
            "providers:\n"
            "  - anthropic\n"
            "  - openai\n"
        )
        assert doc["providers"] == ["anthropic", "openai"]

    def test_tiny_yaml_fallback_on_import_error(self, monkeypatch, tmp_path) -> None:
        """When pyyaml is unavailable, fall back to the tiny parser."""
        from adapter import policy_loader

        p = tmp_path / "policy.yaml"
        p.write_text(
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            "    max_amount: \"50\"\n"
        )

        # Force the fallback path inside _parse_yaml.
        real_import = __builtins__["__import__"] if isinstance(__builtins__, dict) else __import__

        def fake_import(name, *args, **kwargs):
            if name == "yaml":
                raise ImportError("simulated absence")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=fake_import):
            loaded = policy_loader.load_policy(p)
        assert len(loaded.invariants) == 1


class TestPolicyLoaderEdges:
    def test_missing_policy_file(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        with pytest.raises(PolicyLoaderError, match="not found"):
            load_policy(tmp_path / "does_not_exist.yaml")

    def test_non_mapping_top_level(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text("- just_a_list\n")
        with pytest.raises(PolicyLoaderError, match="top-level"):
            load_policy(p)

    def test_wrong_version(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "v.yaml"
        p.write_text("version: 2\npolicy: []\n")
        with pytest.raises(PolicyLoaderError, match="version"):
            load_policy(p)

    def test_policy_not_a_list(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text("version: 1\npolicy: {}\n")
        with pytest.raises(PolicyLoaderError, match="list"):
            load_policy(p)

    def test_entry_not_a_mapping(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text("version: 1\npolicy:\n  - just_a_scalar\n")
        with pytest.raises(PolicyLoaderError, match="not a mapping"):
            load_policy(p)

    def test_unknown_kind(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text("version: 1\npolicy:\n  - kind: made_up\n")
        with pytest.raises(PolicyLoaderError, match="unknown invariant kind"):
            load_policy(p)

    def test_cage_block_bad_type(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text("version: 1\npolicy: []\ncage: not-a-mapping\n")
        with pytest.raises(PolicyLoaderError, match="mapping"):
            load_policy(p)

    def test_cage_bad_prover_mode(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text(
            "version: 1\npolicy: []\ncage:\n  prover_mode: wacky\n"
        )
        with pytest.raises(PolicyLoaderError, match="prover_mode"):
            load_policy(p)

    def test_cage_strict_requires_fail_closed(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text(
            "version: 1\npolicy: []\ncage:\n"
            "  prover_mode: strict\n"
            "  fail_closed_on_inconclusive: false\n"
        )
        with pytest.raises(PolicyLoaderError, match="fail_closed"):
            load_policy(p)

    def test_cage_bad_semantic_fragment(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text(
            "version: 1\npolicy: []\ncage:\n  semantic_fragment: v99\n"
        )
        with pytest.raises(PolicyLoaderError, match="semantic_fragment"):
            load_policy(p)

    def test_cage_non_int_tau_timeout(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text(
            "version: 1\npolicy: []\ncage:\n  tau_timeout_ms: not-an-int\n"
        )
        with pytest.raises(PolicyLoaderError, match="tau_timeout_ms"):
            load_policy(p)

    def test_providers_not_a_list(self, tmp_path) -> None:
        from adapter.policy_loader import PolicyLoaderError, load_policy

        p = tmp_path / "bad.yaml"
        p.write_text(
            "version: 1\npolicy:\n  - kind: provider_allowlist\n    providers: scalar\n"
        )
        with pytest.raises(PolicyLoaderError):
            load_policy(p)


# ═══════════════════════════════════════════════════════════════════════════
# adapter/audit_export.py — verify_bundle error branches
# ═══════════════════════════════════════════════════════════════════════════


def _make_keypair(tmp_path: Path) -> tuple[Path, Path]:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    priv = Ed25519PrivateKey.generate()
    priv_pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_pem = priv.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    priv_path = tmp_path / "signing.key"
    pub_path = tmp_path / "signing.pub"
    priv_path.write_bytes(priv_pem)
    pub_path.write_bytes(pub_pem)
    return priv_path, pub_path


class TestAuditVerifyBundleErrors:
    def test_missing_file(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        missing = tmp_path / "nope.jsonl"
        priv, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(missing), str(pub))
        assert not result.valid
        assert "not found" in (result.reason or "")

    def test_not_utf8(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_bytes(b"\xff\xfe\xfd")
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid

    def test_not_two_lines(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_text("just_one_line")
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid
        assert "two-line" in (result.reason or "") or "two JSONL" in (result.reason or "")

    def test_bundle_line_not_json(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_text("not json at all\n{}\n")
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid

    def test_signature_line_not_json(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_text('{"bundle_version":"1","exported_at_unix":1,"revisions":[],"branches":[],"proposals":[],"merge_commits":[]}\nnot json\n')
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid

    def test_non_dict_bundle(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_text('[1,2,3]\n{"signature":"x","public_key":"y","algorithm":"ed25519"}\n')
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid

    def test_wrong_version(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_text('{"bundle_version":"99"}\n{"signature":"x","public_key":"y","algorithm":"ed25519"}\n')
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid
        assert "unsupported bundle_version" in (result.reason or "")

    def test_wrong_algorithm(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_text('{"bundle_version":"1"}\n{"signature":"x","public_key":"y","algorithm":"rsa"}\n')
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid
        assert "unsupported signature algorithm" in (result.reason or "")

    def test_missing_signature_field(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_text('{"bundle_version":"1"}\n{"algorithm":"ed25519"}\n')
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid
        assert "signature" in (result.reason or "").lower()

    def test_bad_base64_signature(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        bad = tmp_path / "bad.jsonl"
        bad.write_text('{"bundle_version":"1"}\n{"signature":"not$$base64","algorithm":"ed25519"}\n')
        _, pub = _make_keypair(tmp_path)
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid

    def test_missing_public_key_path(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        # Need a well-formed bundle line for the code to get to the pubkey load.
        sig = base64.b64encode(b"A" * 64).decode("ascii")
        bundle = json.dumps({
            "bundle_version": "1", "exported_at_unix": 1,
            "revisions": [], "branches": [], "proposals": [], "merge_commits": [],
        })
        sig_rec = json.dumps({"signature": sig, "public_key": "x", "algorithm": "ed25519"})
        bad = tmp_path / "bad.jsonl"
        bad.write_text(bundle + "\n" + sig_rec + "\n")
        result = verify_bundle(str(bad), str(tmp_path / "no-such-key.pem"))
        assert not result.valid
        assert "public key not found" in (result.reason or "")

    def test_malformed_public_key_pem(self, tmp_path: Path) -> None:
        from adapter.audit_export import verify_bundle

        sig = base64.b64encode(b"A" * 64).decode("ascii")
        bundle = json.dumps({
            "bundle_version": "1", "exported_at_unix": 1,
            "revisions": [], "branches": [], "proposals": [], "merge_commits": [],
        })
        sig_rec = json.dumps({"signature": sig, "public_key": "x", "algorithm": "ed25519"})
        bad = tmp_path / "bad.jsonl"
        bad.write_text(bundle + "\n" + sig_rec + "\n")
        pub = tmp_path / "bad.pem"
        pub.write_text("-----BEGIN PUBLIC KEY-----\nINVALID\n-----END PUBLIC KEY-----\n")
        result = verify_bundle(str(bad), str(pub))
        assert not result.valid

    def test_non_ed25519_public_key(self, tmp_path: Path) -> None:
        """A PEM pub key that is not Ed25519 surfaces AuditExportError in _load."""
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa

        from adapter.audit_export import verify_bundle

        rsa_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pub_pem = rsa_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        sig = base64.b64encode(b"A" * 64).decode("ascii")
        bundle = json.dumps({
            "bundle_version": "1", "exported_at_unix": 1,
            "revisions": [], "branches": [], "proposals": [], "merge_commits": [],
        })
        sig_rec = json.dumps({"signature": sig, "public_key": "x", "algorithm": "ed25519"})
        bad = tmp_path / "bad.jsonl"
        bad.write_text(bundle + "\n" + sig_rec + "\n")
        pub_path = tmp_path / "rsa.pem"
        pub_path.write_bytes(pub_pem)
        result = verify_bundle(str(bad), str(pub_path))
        assert not result.valid


class TestAuditSignErrors:
    def test_sign_non_dict(self, tmp_path: Path) -> None:
        from adapter.audit_export import AuditExportError, sign_bundle

        priv, _pub = _make_keypair(tmp_path)
        with pytest.raises(AuditExportError, match="dict"):
            sign_bundle([], str(priv))  # type: ignore[arg-type]

    def test_sign_non_json_serialisable(self, tmp_path: Path) -> None:
        from adapter.audit_export import AuditExportError, sign_bundle

        priv, _pub = _make_keypair(tmp_path)
        # A set is not JSON-serialisable.
        with pytest.raises(AuditExportError, match="JSON"):
            sign_bundle({"bad": {1, 2, 3}}, str(priv))

    def test_sign_bad_private_key_path(self, tmp_path: Path) -> None:
        from adapter.audit_export import AuditExportError, sign_bundle

        with pytest.raises(AuditExportError, match="cannot read"):
            sign_bundle({"a": 1}, str(tmp_path / "nope.pem"))

    def test_sign_malformed_private_pem(self, tmp_path: Path) -> None:
        from adapter.audit_export import AuditExportError, sign_bundle

        bad_key = tmp_path / "bad.pem"
        bad_key.write_bytes(b"not a valid pem")
        with pytest.raises(AuditExportError, match="malformed"):
            sign_bundle({"a": 1}, str(bad_key))

    def test_sign_non_ed25519_private_key(self, tmp_path: Path) -> None:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa

        from adapter.audit_export import AuditExportError, sign_bundle

        rsa_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pem = rsa_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        key_path = tmp_path / "rsa.pem"
        key_path.write_bytes(pem)
        with pytest.raises(AuditExportError, match="not Ed25519"):
            sign_bundle({"a": 1}, str(key_path))


# ═══════════════════════════════════════════════════════════════════════════
# adapter/webhook_sink.py — config + circuit-breaker edges
# ═══════════════════════════════════════════════════════════════════════════


SECRET_16 = b"0123456789abcdef"


class TestWebhookConfigValidation:
    def test_empty_name_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="name"):
            WebhookConfig(name="", url="http://x/y", secret=SECRET_16)

    def test_bad_url_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="url"):
            WebhookConfig(name="n", url="ftp://x/y", secret=SECRET_16)

    def test_no_netloc_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="url"):
            WebhookConfig(name="n", url="http:///", secret=SECRET_16)

    def test_short_secret_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="secret"):
            WebhookConfig(name="n", url="http://x/y", secret=b"short")

    def test_non_bytes_secret_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="secret"):
            WebhookConfig(name="n", url="http://x/y", secret="not-bytes")  # type: ignore[arg-type]

    def test_zero_timeout_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="timeout"):
            WebhookConfig(name="n", url="http://x/y", secret=SECRET_16, timeout_s=0)

    def test_negative_retry_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="retry"):
            WebhookConfig(name="n", url="http://x/y", secret=SECRET_16, retry=-1)

    def test_zero_queue_size_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="queue_size"):
            WebhookConfig(name="n", url="http://x/y", secret=SECRET_16, queue_size=0)

    def test_bad_only_verdicts_rejected(self) -> None:
        from adapter.webhook_sink import WebhookConfig, WebhookConfigError

        with pytest.raises(WebhookConfigError, match="only_verdicts"):
            WebhookConfig(
                name="n", url="http://x/y", secret=SECRET_16,
                only_verdicts=frozenset({"noway"}),
            )

    def test_compute_signature_requires_bytes(self) -> None:
        from adapter.webhook_sink import compute_signature

        with pytest.raises(TypeError):
            compute_signature("not-bytes", "123", b"body")  # type: ignore[arg-type]

    def test_matches_filter_by_verdict(self) -> None:
        from adapter.webhook_sink import WebhookConfig

        cfg = WebhookConfig(
            name="n", url="http://x/y", secret=SECRET_16,
            only_verdicts=frozenset({"reject"}),
        )
        assert cfg.matches({"verdict": "reject"}) is True
        assert cfg.matches({"verdict": "permit"}) is False

    def test_matches_filter_by_rule(self) -> None:
        from adapter.webhook_sink import WebhookConfig

        cfg = WebhookConfig(
            name="n", url="http://x/y", secret=SECRET_16,
            only_rules=frozenset({"spending_cap"}),
        )
        assert cfg.matches({"verdict": "reject", "rule_id": "spending_cap"}) is True
        assert cfg.matches({"verdict": "reject", "rule_id": "other"}) is False
        # permit with no rule_id -> filtered by only_rules
        assert cfg.matches({"verdict": "permit"}) is False


class TestWebhookConfigLoader:
    def test_load_from_dict(self) -> None:
        from adapter.webhook_sink import load_webhook_config

        cfg = load_webhook_config({
            "version": 1,
            "webhooks": [
                {
                    "name": "dd", "url": "http://x/y", "secret": "a" * 32,
                    "only_verdicts": ["reject"],
                }
            ],
        })
        assert len(cfg) == 1
        assert cfg[0].name == "dd"

    def test_load_empty_webhooks(self) -> None:
        from adapter.webhook_sink import load_webhook_config

        assert load_webhook_config({}) == []
        assert load_webhook_config({"webhooks": None}) == []

    def test_load_none_source(self) -> None:
        from adapter.webhook_sink import load_webhook_config

        assert load_webhook_config(None) == []

    def test_load_non_mapping_top_level(self) -> None:
        from adapter.webhook_sink import WebhookConfigError, load_webhook_config

        with pytest.raises(WebhookConfigError, match="mapping"):
            load_webhook_config([1, 2, 3])

    def test_load_webhooks_not_a_list(self) -> None:
        from adapter.webhook_sink import WebhookConfigError, load_webhook_config

        with pytest.raises(WebhookConfigError, match="list"):
            load_webhook_config({"webhooks": "not-a-list"})

    def test_load_entry_not_a_mapping(self) -> None:
        from adapter.webhook_sink import WebhookConfigError, load_webhook_config

        with pytest.raises(WebhookConfigError, match="mapping"):
            load_webhook_config({"webhooks": [[1, 2]]})

    def test_load_entry_missing_url(self) -> None:
        from adapter.webhook_sink import WebhookConfigError, load_webhook_config

        with pytest.raises(WebhookConfigError, match="url"):
            load_webhook_config({"webhooks": [{"name": "a", "secret": "x" * 16}]})

    def test_load_secret_env_unset(self, monkeypatch) -> None:
        from adapter.webhook_sink import WebhookConfigError, load_webhook_config

        monkeypatch.delenv("TEST_WEBHOOK_SECRET", raising=False)
        with pytest.raises(WebhookConfigError, match="unset"):
            load_webhook_config({
                "webhooks": [
                    {"name": "a", "url": "http://x/y", "secret_env": "TEST_WEBHOOK_SECRET"},
                ],
            })

    def test_load_secret_env_empty_name(self) -> None:
        from adapter.webhook_sink import WebhookConfigError, load_webhook_config

        with pytest.raises(WebhookConfigError, match="secret_env"):
            load_webhook_config({
                "webhooks": [
                    {"name": "a", "url": "http://x/y", "secret_env": ""},
                ],
            })

    def test_load_no_secret_source(self) -> None:
        from adapter.webhook_sink import WebhookConfigError, load_webhook_config

        with pytest.raises(WebhookConfigError, match="secret"):
            load_webhook_config({
                "webhooks": [{"name": "a", "url": "http://x/y"}],
            })

    def test_load_bytes_secret(self) -> None:
        from adapter.webhook_sink import load_webhook_config

        cfgs = load_webhook_config({
            "webhooks": [{
                "name": "a", "url": "http://x/y", "secret": b"x" * 32,
            }],
        })
        assert cfgs[0].secret == b"x" * 32

    def test_load_bad_secret_type(self) -> None:
        from adapter.webhook_sink import WebhookConfigError, load_webhook_config

        with pytest.raises(WebhookConfigError, match="str or bytes"):
            load_webhook_config({
                "webhooks": [{"name": "a", "url": "http://x/y", "secret": 123}],
            })

    def test_load_secret_env_path(self, monkeypatch) -> None:
        from adapter.webhook_sink import load_webhook_config

        monkeypatch.setenv("TEST_WH_SECRET", "a" * 32)
        cfgs = load_webhook_config({
            "webhooks": [
                {"name": "a", "url": "http://x/y", "secret_env": "TEST_WH_SECRET"},
            ],
        })
        assert cfgs[0].secret == (b"a" * 32)


class TestWebhookSinkCircuitBreaker:
    def test_force_close_circuit_resets(self) -> None:
        from adapter.webhook_sink import WebhookSink

        sink = WebhookSink(
            url="http://127.0.0.1/x",
            secret=SECRET_16,
        )
        sink._circuit_open_until = time.monotonic() + 999
        sink._consecutive_failures = 9
        sink.force_close_circuit()
        assert sink.circuit_open_until == 0.0

    def test_circuit_open_reopens_after_cooldown(self) -> None:
        from adapter.webhook_sink import WebhookSink

        clock_state = [100.0]

        def fake_clock() -> float:
            return clock_state[0]

        sink = WebhookSink(
            url="http://127.0.0.1/x",
            secret=SECRET_16,
            clock=fake_clock,
        )
        sink._circuit_open_until = 150.0
        assert sink._circuit_open() is True
        clock_state[0] = 200.0
        assert sink._circuit_open() is False
        assert sink._circuit_open_until == 0.0

    def test_emit_filtered_verdict_does_not_queue(self) -> None:
        from adapter.webhook_sink import WebhookSink

        sink = WebhookSink(
            url="http://x/y",
            secret=SECRET_16,
            only_verdicts=("reject",),
        )
        # permit does not match filter -> does not enter queue.
        sink.emit({"verdict": "permit"})
        assert len(sink._buf) == 0

    def test_metrics_snapshot_shape(self) -> None:
        from adapter.webhook_sink import WebhookSink

        sink = WebhookSink(url="http://x/y", secret=SECRET_16)
        snap = sink.metrics_snapshot()
        assert set(snap.keys()) == {
            "delivered", "dropped", "failed",
            "queued", "consecutive_failures", "circuit_open",
        }


# ═══════════════════════════════════════════════════════════════════════════
# adapter/revision_sync.py — config + lifecycle edges
# ═══════════════════════════════════════════════════════════════════════════


class TestRevisionSyncConfig:
    def test_sync_config_resolved_client_id_stable(self) -> None:
        from adapter.revision_sync import SyncConfig

        cfg = SyncConfig(
            url="redis://localhost:6379/0",
            channel="cage",
            client_id="fixed-id",
        )
        assert cfg.resolved_client_id() == "fixed-id"

    def test_sync_config_auto_client_id(self) -> None:
        from adapter.revision_sync import SyncConfig

        cfg = SyncConfig(
            url="redis://localhost:6379/0",
            channel="cage",
        )
        # Generated when None.
        cid = cfg.resolved_client_id()
        assert isinstance(cid, str)
        assert len(cid) > 0


class TestRevisionSyncPublisherErrors:
    def test_publish_malformed_payload_fail_open(self) -> None:
        """Unserialisable payload logs a warning but never raises upstream."""
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.revision_sync import RevisionSyncPublisher, SyncConfig

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="cid")
        pub = RevisionSyncPublisher(cfg, redis_client=client)

        # Use the private _publish_raw with an unserialisable payload.
        pub._publish_raw({"_sync_kind": "bogus", "bad": {1, 2, 3}})  # set isn't JSON

    def test_publisher_close_safe(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.revision_sync import RevisionSyncPublisher, SyncConfig

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="cid")
        pub = RevisionSyncPublisher(cfg, redis_client=client)
        pub.close()
        pub.close()  # idempotent


class TestRevisionSyncBuildErrors:
    def test_build_without_redis_raises(self) -> None:
        """When url is empty and no redis_client injected, factory fails fast."""
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import RevisionSyncError, SyncConfig, build_revision_sync

        cfg = SyncConfig(url="", channel="ch", client_id="cid")
        log = RevisionLog()
        with pytest.raises(RevisionSyncError, match="non-empty"):
            build_revision_sync(cfg, log, preflight=False)


class TestSubscriberApplyEdges:
    def test_unknown_sync_kind_ignored(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import (
            RevisionSyncSubscriber,
            SyncConfig,
        )

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="sub")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(cfg, log, redis_client=client)

        # Feed a message with unknown kind.
        sub._handle_raw_message(json.dumps({
            "_sync_kind": "made_up",
            "source_client_id": "other",
        }))

    def test_message_from_self_dropped(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import (
            KIND_REVISION,
            RevisionSyncSubscriber,
            SyncConfig,
        )

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="self")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(cfg, log, redis_client=client)
        sub._handle_raw_message(json.dumps({
            "_sync_kind": KIND_REVISION,
            "source_client_id": "self",  # same as our id
            "revision": {},
        }))

    def test_malformed_message_ignored(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import RevisionSyncSubscriber, SyncConfig

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="sub")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(cfg, log, redis_client=client)

        sub._handle_raw_message("not json")
        sub._handle_raw_message(b"\xff\xfe")
        sub._handle_raw_message(json.dumps([1, 2]))  # not a dict
        sub._handle_raw_message(None)  # not str/bytes

    def test_branch_checkout_for_unknown_branch_deferred(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import (
            KIND_BRANCH_CHECKOUT,
            RevisionSyncSubscriber,
            SyncConfig,
        )

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="sub")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(cfg, log, redis_client=client)
        applied = sub._apply_branch_checkout({
            "name": "nonexistent",
            "source_client_id": "other",
        })
        assert applied is False

    def test_branch_checkout_missing_name(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import RevisionSyncSubscriber, SyncConfig

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="sub")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(cfg, log, redis_client=client)
        assert sub._apply_branch_checkout({}) is False
        assert sub._apply_branch_checkout({"name": 123}) is False

    def test_branch_merge_missing_dst(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import RevisionSyncSubscriber, SyncConfig

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="sub")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(cfg, log, redis_client=client)
        assert sub._apply_branch_merge({}) is False
        assert sub._apply_branch_merge({"dst": 0}) is False


class TestSubscriberLifecycle:
    def test_subscriber_lag_ms_returns_neg1_before_first_msg(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import RevisionSyncSubscriber, SyncConfig

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="sub")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(cfg, log, redis_client=client)
        assert sub.subscriber_lag_ms() == -1

    def test_subscriber_stop_idempotent(self) -> None:
        fakeredis = pytest.importorskip("fakeredis")
        from adapter.policy_revision import RevisionLog
        from adapter.revision_sync import RevisionSyncSubscriber, SyncConfig

        client = fakeredis.FakeRedis(decode_responses=True)
        cfg = SyncConfig(url="redis://x", channel="ch", client_id="sub")
        log = RevisionLog()
        sub = RevisionSyncSubscriber(cfg, log, redis_client=client)
        sub.stop()
        sub.stop()  # must not raise
