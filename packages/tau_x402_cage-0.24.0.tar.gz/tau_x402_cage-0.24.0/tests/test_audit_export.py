"""Tests for the signed audit export bundle (v0.9.0).

Coverage targets:
  * export_bundle is deterministic — same input state yields byte-identical
    canonical JSON (holding ``exported_at_unix`` constant)
  * sign → verify round-trip
  * tampered revision fails verify
  * tampered signature fails verify
  * wrong public key fails verify
  * empty state exports a valid empty bundle
  * large state (100 revisions + 50 proposals) exports + verifies

The tests skip cleanly when ``cryptography`` isn't installed so the base
HMAC-only test run stays green on machines without the signing-ed25519
extra.
"""

from __future__ import annotations

import base64
import json
import time
from decimal import Decimal
from pathlib import Path
from typing import List

import pytest

pytest.importorskip("cryptography")

from adapter.approval_queue import ApprovalQueue, Proposal
from adapter.audit_export import (
    AUDIT_ALGORITHM,
    BUNDLE_VERSION_V1,
    AuditExportError,
    VerifyResult,
    _canonical_dumps,
    export_bundle,
    sign_bundle,
    verify_bundle,
)
from adapter.invariants import MaxPerCall, SpendingCap
from adapter.policy_revision import (
    Branch,
    PolicyRevision,
    RevisionLog,
)
from adapter.verdict_signer import generate_ed25519_keypair


# ── fixtures ────────────────────────────────────────────────────────────────


@pytest.fixture
def keypair(tmp_path: Path) -> tuple[str, str]:
    """Produce a disposable ed25519 keypair scoped to the test."""
    return generate_ed25519_keypair(str(tmp_path / "audit"))


@pytest.fixture
def another_keypair(tmp_path: Path) -> tuple[str, str]:
    """A second disposable keypair to test 'wrong public key' failures."""
    return generate_ed25519_keypair(str(tmp_path / "other"))


def _make_revision(
    idx: int,
    predecessor: str | None,
    branch: str = "main",
) -> PolicyRevision:
    """Minimal PolicyRevision suitable for audit export tests.

    We don't care about prover semantics in this module — we're exercising
    the serializer. Keep enough invariant variety that delta walking has
    something to chew on.
    """
    return PolicyRevision(
        revision_id=f"rev-{idx:04d}",
        invariants=(
            SpendingCap(
                max_amount=Decimal(str(100 + idx)),
                currency="USDC",
                scope="per_window",
                window_seconds=3600,
            ),
            MaxPerCall(max_amount=Decimal(str(10 + idx)), currency="USDC"),
        ),
        proof_backend="python-pattern",
        proof_strength="pattern",
        prover_mode="compat",
        compile_hash=None,
        fragment_version="v1",
        tau_backend_version=None,
        admitted_at_unix=1_700_000_000 + idx,
        predecessor_revision_id=predecessor,
        delta={},
        revision_depth=idx,
        branch=branch,
    )


def _make_proposal(idx: int) -> Proposal:
    return Proposal(
        proposal_id=f"prop-{idx:04d}",
        submitted_by=f"agent-{idx}",
        submitted_at=1_700_000_500 + idx,
        invariants=(MaxPerCall(max_amount=Decimal("25"), currency="USDC"),),
        diff_from_revision=f"rev-{idx:04d}" if idx % 2 == 0 else None,
        status="pending",
    )


def _build_small_log(path: Path | None = None) -> RevisionLog:
    log = RevisionLog(path=path)
    r0 = _make_revision(0, None)
    r1 = _make_revision(1, r0.revision_id)
    log.append(r0)
    log.append(r1)
    return log


# ── determinism ─────────────────────────────────────────────────────────────


class TestDeterminism:
    """export_bundle must be byte-stable across calls with identical state."""

    def test_same_state_yields_identical_canonical_json(self) -> None:
        log_a = _build_small_log()
        log_b = _build_small_log()
        bundle_a = export_bundle(
            log_a.revisions, approval_queue=[], branches=log_a.list_branches(),
            now_unix=1_700_000_999,
        )
        bundle_b = export_bundle(
            log_b.revisions, approval_queue=[], branches=log_b.list_branches(),
            now_unix=1_700_000_999,
        )
        # Full structural equality …
        assert bundle_a == bundle_b
        # … AND byte-stable serialization. This is the load-bearing guarantee
        # for the signed wire format.
        assert _canonical_dumps(bundle_a) == _canonical_dumps(bundle_b)

    def test_timestamp_override_makes_export_reproducible(self) -> None:
        log = _build_small_log()
        first = export_bundle(
            log.revisions, [], log.list_branches(), now_unix=42,
        )
        second = export_bundle(
            log.revisions, [], log.list_branches(), now_unix=42,
        )
        assert first["exported_at_unix"] == 42
        assert first == second

    def test_bundle_version_is_frozen_at_v1(self) -> None:
        log = _build_small_log()
        b = export_bundle(log.revisions, [], log.list_branches(), now_unix=1)
        assert b["bundle_version"] == BUNDLE_VERSION_V1 == "1"


# ── round trip ──────────────────────────────────────────────────────────────


class TestSignVerifyRoundTrip:
    def test_round_trip(self, tmp_path: Path, keypair) -> None:
        priv, pub = keypair
        log = _build_small_log()
        queue = ApprovalQueue()
        # populate one proposal so the proposals lane has content
        queue._proposals["p1"] = _make_proposal(1)
        bundle = export_bundle(
            log.revisions, queue.list(), log.list_branches(), now_unix=100,
        )
        raw = sign_bundle(bundle, priv)
        out = tmp_path / "audit.jsonl"
        out.write_bytes(raw)
        result = verify_bundle(str(out), pub)
        assert result.valid is True
        assert result.reason is None
        assert result.bundle_version == "1"
        assert result.exported_at_unix == 100
        assert result.revisions == 2
        assert result.proposals == 1
        # At least "main" is always there. Our log has only main, so 1.
        assert result.branches >= 1
        assert result.merge_commits == 0

    def test_jsonl_has_exactly_two_lines(self, tmp_path: Path, keypair) -> None:
        priv, _ = keypair
        log = _build_small_log()
        bundle = export_bundle(log.revisions, [], log.list_branches(), now_unix=7)
        raw = sign_bundle(bundle, priv)
        text = raw.decode("utf-8")
        lines = [ln for ln in text.split("\n") if ln != ""]
        assert len(lines) == 2, f"expected 2 JSONL lines, got {len(lines)}"
        # Line 2 must carry the ed25519 marker.
        sig = json.loads(lines[1])
        assert sig["algorithm"] == AUDIT_ALGORITHM
        # Public key is PEM-encoded, so it must start with a PEM header.
        assert sig["public_key"].startswith("-----BEGIN PUBLIC KEY-----")


# ── tamper detection ───────────────────────────────────────────────────────


class TestTamperDetection:
    def test_tampered_revision_fails_verify(
        self, tmp_path: Path, keypair
    ) -> None:
        """Flipping one byte in the revisions list invalidates the signature."""
        priv, pub = keypair
        log = _build_small_log()
        bundle = export_bundle(log.revisions, [], log.list_branches(), now_unix=1)
        raw = sign_bundle(bundle, priv)
        text = raw.decode("utf-8")
        line1, _, line2 = text.partition("\n")
        # Mutate line1 — rewrite the first revision's admitted_at_unix.
        tampered_bundle = json.loads(line1)
        tampered_bundle["revisions"][0]["admitted_at_unix"] += 1
        tampered_line1 = _canonical_dumps(tampered_bundle)
        tampered = (tampered_line1 + "\n" + line2.rstrip("\n") + "\n").encode("utf-8")
        out = tmp_path / "bad.jsonl"
        out.write_bytes(tampered)
        result = verify_bundle(str(out), pub)
        assert result.valid is False
        assert "signature verification failed" in (result.reason or "")

    def test_tampered_signature_fails_verify(
        self, tmp_path: Path, keypair
    ) -> None:
        """Flipping a base64 bit in the signature field fails verification."""
        priv, pub = keypair
        log = _build_small_log()
        bundle = export_bundle(log.revisions, [], log.list_branches(), now_unix=1)
        raw = sign_bundle(bundle, priv)
        text = raw.decode("utf-8")
        line1, _, line2 = text.partition("\n")
        sig_dict = json.loads(line2.rstrip("\n"))
        # Flip one byte of the decoded signature and re-encode.
        sig_bytes = bytearray(base64.b64decode(sig_dict["signature"]))
        sig_bytes[0] ^= 0xFF
        sig_dict["signature"] = base64.b64encode(bytes(sig_bytes)).decode("ascii")
        tampered_line2 = _canonical_dumps(sig_dict)
        tampered = (line1 + "\n" + tampered_line2 + "\n").encode("utf-8")
        out = tmp_path / "bad.jsonl"
        out.write_bytes(tampered)
        result = verify_bundle(str(out), pub)
        assert result.valid is False
        assert "signature verification failed" in (result.reason or "")

    def test_wrong_public_key_fails_verify(
        self, tmp_path: Path, keypair, another_keypair
    ) -> None:
        priv, _ = keypair
        _, wrong_pub = another_keypair
        log = _build_small_log()
        bundle = export_bundle(log.revisions, [], log.list_branches(), now_unix=1)
        raw = sign_bundle(bundle, priv)
        out = tmp_path / "audit.jsonl"
        out.write_bytes(raw)
        result = verify_bundle(str(out), wrong_pub)
        assert result.valid is False
        assert "signature verification failed" in (result.reason or "")


# ── edge cases ─────────────────────────────────────────────────────────────


class TestEmptyAndLargeState:
    def test_empty_state_exports_valid_empty_bundle(
        self, tmp_path: Path, keypair
    ) -> None:
        priv, pub = keypair
        bundle = export_bundle(
            revision_log=[], approval_queue=[], branches=[], now_unix=0,
        )
        assert bundle["revisions"] == []
        assert bundle["branches"] == []
        assert bundle["proposals"] == []
        assert bundle["merge_commits"] == []
        assert bundle["bundle_version"] == "1"
        out = tmp_path / "empty.jsonl"
        out.write_bytes(sign_bundle(bundle, priv))
        result = verify_bundle(str(out), pub)
        assert result.valid is True
        assert result.revisions == 0
        assert result.branches == 0
        assert result.proposals == 0

    def test_large_state_round_trip(self, tmp_path: Path, keypair) -> None:
        """100 revisions + 50 proposals round-trip in under a second.

        Not a microbenchmark, but exercises the serializer against volumes
        an enterprise cage would realistically carry a month into the log.
        """
        priv, pub = keypair
        revisions: List[PolicyRevision] = []
        predecessor: str | None = None
        for i in range(100):
            rev = _make_revision(i, predecessor)
            revisions.append(rev)
            predecessor = rev.revision_id
        proposals = [_make_proposal(i) for i in range(50)]
        branches = (Branch(
            name="main", head_revision_id=revisions[-1].revision_id,
            created_at=1_700_000_000, created_by="test",
        ),)
        t0 = time.monotonic()
        bundle = export_bundle(
            revisions, proposals, branches, now_unix=12345,
        )
        signed = sign_bundle(bundle, priv)
        t1 = time.monotonic()
        assert t1 - t0 < 2.0  # generous; typical is well under 100ms
        out = tmp_path / "big.jsonl"
        out.write_bytes(signed)
        result = verify_bundle(str(out), pub)
        assert result.valid is True
        assert result.revisions == 100
        assert result.proposals == 50
        assert result.branches == 1


# ── error surface ──────────────────────────────────────────────────────────


class TestErrorSurface:
    """Boundary checks. Audit tooling is only trustworthy if errors surface."""

    def test_missing_file_returns_invalid_not_raise(self, tmp_path: Path) -> None:
        # Create a valid keypair to pass the key-check stage.
        priv, pub = generate_ed25519_keypair(str(tmp_path / "k"))
        result = verify_bundle(str(tmp_path / "nope.jsonl"), pub)
        assert result.valid is False
        assert "not found" in (result.reason or "")

    def test_bad_version_rejected(self, tmp_path: Path, keypair) -> None:
        """A bundle that declares bundle_version != '1' must be refused.

        Simulates a v2 bundle reaching a v1-only verifier — we want the
        verifier to refuse rather than silently parse unknown fields.
        """
        priv, pub = keypair
        bundle = export_bundle([], [], [], now_unix=1)
        bundle["bundle_version"] = "99"
        out = tmp_path / "bad_ver.jsonl"
        out.write_bytes(sign_bundle(bundle, priv))
        result = verify_bundle(str(out), pub)
        assert result.valid is False
        assert "unsupported bundle_version" in (result.reason or "")

    def test_non_dict_bundle_rejected(self, tmp_path: Path, keypair) -> None:
        priv, pub = keypair
        with pytest.raises(AuditExportError):
            sign_bundle("not a dict", priv)  # type: ignore[arg-type]

    def test_invariant_type_rejected_in_export(self) -> None:
        with pytest.raises(AuditExportError):
            export_bundle(
                revision_log=["not a revision"],  # type: ignore[list-item]
                approval_queue=[],
                branches=[],
                now_unix=1,
            )


# ── daemon op ──────────────────────────────────────────────────────────────


class TestDaemonExportAuditOp:
    """The ``export_audit`` op must return a well-formed bundle.

    We exercise the in-process ``CageDaemon.dispatch`` directly so the test
    stays under 100ms and doesn't stand up a UDS.
    """

    def test_empty_daemon_exports_valid_empty_bundle(self, tmp_path: Path) -> None:
        from daemon.server import CageDaemon
        # Use a fake socket path; we never bind it.
        daemon = CageDaemon(socket_path=str(tmp_path / "noop.sock"))
        resp = daemon.dispatch({"op": "export_audit"})
        assert resp["verdict"] == "ok"
        bundle = resp["bundle"]
        assert bundle["bundle_version"] == "1"
        assert bundle["revisions"] == []
        assert bundle["proposals"] == []
        assert bundle["merge_commits"] == []
        # main is always present as a Branch snapshot even before any append.
        assert isinstance(bundle["branches"], list)

    def test_daemon_export_is_signable(
        self, tmp_path: Path, keypair
    ) -> None:
        """End-to-end: daemon op returns bundle, CLI-equivalent flow signs it."""
        from daemon.server import CageDaemon
        priv, pub = keypair
        daemon = CageDaemon(socket_path=str(tmp_path / "noop.sock"))
        resp = daemon.dispatch({"op": "export_audit"})
        bundle = resp["bundle"]
        raw = sign_bundle(bundle, priv)
        out = tmp_path / "daemon.jsonl"
        out.write_bytes(raw)
        result = verify_bundle(str(out), pub)
        assert result.valid is True
