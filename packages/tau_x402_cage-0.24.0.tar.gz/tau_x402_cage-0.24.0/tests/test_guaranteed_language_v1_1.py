"""Tests for the Guaranteed Language tier v1.1.0 widening (v0.20.0).

v1.1.0 adds three rule classes (RetryRateLimit, RollingWindowCap,
BurstVelocityCap), opens SpendingCap's windowed scopes, admits past-LTL
``O`` / ``H`` temporal operators, and ships three new mutation forms
(``tighten_window``, ``shorten_retry_cooldown``, ``tighten_burst_cap``).

The upstream Tau patches (Bug 1 pair-consistency + Bug 3 past-LTL grammar
+ Bug 4 ``&`` chains) are presumed merged; this test file pins the
language surface exactly so silent expansion or silent regression both
fail loudly at CI time.
"""
from __future__ import annotations

import json
from decimal import Decimal

import pytest

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.invariants import (
    BurstVelocityCap,
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    MutualExclusion,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)


# ── version pin ────────────────────────────────────────────────────────


def test_language_version_is_at_least_1_1_0():
    # The v1.1.0 tier surface is a subset of every subsequent tier; v1.2.0
    # preserves every v1.1.0 admission and adds (a) enum/composition rule
    # types from agent β and (b) meta-policies from agent γ. Pin the lower
    # bound here; dedicated v1.2.0 tests pin the exact semver.
    major, minor, _ = GUARANTEED_LANGUAGE_VERSION.split(".")
    assert (int(major), int(minor)) >= (1, 1)


# ── new rule types admitted ────────────────────────────────────────────


def test_is_supported_admits_retry_rate_limit_v1_1():
    ok, code = GuaranteedLanguage.is_supported(
        RetryRateLimit(min_gap_seconds=30)
    )
    assert ok is True
    assert code is None


def test_is_supported_admits_rolling_window_cap_v1_1():
    ok, code = GuaranteedLanguage.is_supported(
        RollingWindowCap(max_count=10, window_seconds=60)
    )
    assert ok is True
    assert code is None


def test_is_supported_admits_burst_velocity_cap_v1_1():
    ok, code = GuaranteedLanguage.is_supported(
        BurstVelocityCap(max_per_window=Decimal("100"), window_seconds=10)
    )
    assert ok is True
    assert code is None


def test_is_supported_admits_retry_rate_limit_with_edge_min_gap():
    """min_gap_seconds at the boundary (1s, 300s) still admitted."""
    for gap in (1, 30, 300):
        ok, code = GuaranteedLanguage.is_supported(
            RetryRateLimit(min_gap_seconds=gap)
        )
        assert ok is True, f"gap={gap} was unexpectedly rejected"
        assert code is None


def test_is_supported_admits_rolling_window_cap_every_group_by():
    """All three group_by variants admit in v1.1.0."""
    for group_by in ("provider", "counterparty", "global"):
        ok, code = GuaranteedLanguage.is_supported(
            RollingWindowCap(max_count=5, window_seconds=60, group_by=group_by)
        )
        assert ok is True, f"group_by={group_by} was unexpectedly rejected"


def test_is_supported_admits_burst_velocity_cap_both_scopes():
    """Cross-provider + per-provider BurstVelocityCap both admit."""
    for cross in (True, False):
        ok, code = GuaranteedLanguage.is_supported(
            BurstVelocityCap(
                max_per_window=Decimal("50"),
                window_seconds=10,
                cross_provider=cross,
            )
        )
        assert ok is True


# ── widened SpendingCap scopes ─────────────────────────────────────────


def test_is_supported_admits_spending_cap_per_window_v1_1():
    ok, code = GuaranteedLanguage.is_supported(
        SpendingCap(
            max_amount=Decimal("100"),
            scope="per_window",
            window_seconds=86400,
        )
    )
    assert ok is True
    assert code is None


def test_is_supported_admits_spending_cap_per_provider_per_window_v1_1():
    ok, code = GuaranteedLanguage.is_supported(
        SpendingCap(
            max_amount=Decimal("100"),
            scope="per_provider_per_window",
            window_seconds=86400,
            provider="openai",
        )
    )
    assert ok is True
    assert code is None


# ── past-LTL temporal ops admitted ─────────────────────────────────────


def test_past_ltl_operators_admitted():
    """O (once) and H (historically) become admitted in v1.1.0 once
    upstream Tau ships the past-LTL grammar fix (Bug 3)."""
    assert GuaranteedLanguage.is_temporal_supported("G") is True
    assert GuaranteedLanguage.is_temporal_supported("O") is True
    assert GuaranteedLanguage.is_temporal_supported("H") is True


def test_future_ltl_operators_still_rejected():
    """F / X / U / W are future/binary operators; still outside v1.1.0."""
    for op in ("F", "X", "U", "W"):
        assert GuaranteedLanguage.is_temporal_supported(op) is False


# ── new mutation forms admitted ────────────────────────────────────────


def test_new_mutation_forms_admitted():
    assert GuaranteedLanguage.is_mutation_form_supported("tighten_window") is True
    assert (
        GuaranteedLanguage.is_mutation_form_supported("shorten_retry_cooldown")
        is True
    )
    assert GuaranteedLanguage.is_mutation_form_supported("tighten_burst_cap") is True


def test_all_v1_0_mutation_forms_still_admitted():
    assert GuaranteedLanguage.is_mutation_form_supported("add_invariant") is True
    assert GuaranteedLanguage.is_mutation_form_supported("remove_invariant") is True
    assert GuaranteedLanguage.is_mutation_form_supported("tighten_limit") is True


def test_weakening_mutation_forms_still_rejected():
    """v1.1.0 does not open any weakening mutation form."""
    assert GuaranteedLanguage.is_mutation_form_supported("loosen_limit") is False
    assert (
        GuaranteedLanguage.is_mutation_form_supported("replace_invariant") is False
    )
    assert GuaranteedLanguage.is_mutation_form_supported("widen_window") is False


# ── describe() surface pins exact v1.1.0 shape ─────────────────────────


def test_describe_reflects_v1_1_rule_types():
    """v1.2.0 keeps every v1.1.0 admission and adds three more rule
    types. This test now checks the v1.1.0 subset is a subset of the
    current tier — the exact v1.2.0 surface is pinned in
    tests/test_guaranteed_language_v1_2.py."""
    surface = GuaranteedLanguage.describe()
    admitted = set(surface["supported_rule_types"])
    for v1_1_rule in (
        "BurstVelocityCap",
        "MaxPerCall",
        "ProviderAllowlist",
        "RetryRateLimit",
        "RollingWindowCap",
        "SpendingCap",
    ):
        assert v1_1_rule in admitted


def test_describe_reflects_v1_1_scopes():
    surface = GuaranteedLanguage.describe()
    assert surface["supported_scopes"]["SpendingCap"] == [
        "per_tx",
        "per_window",
        "per_provider_per_window",
    ]


def test_describe_reflects_v1_1_temporal():
    surface = GuaranteedLanguage.describe()
    assert surface["supported_temporal"] == ["G", "H", "O"]


def test_describe_reflects_v1_1_mutation_forms():
    surface = GuaranteedLanguage.describe()
    assert surface["supported_mutation_forms"] == sorted(
        [
            "add_invariant",
            "remove_invariant",
            "tighten_limit",
            "tighten_window",
            "shorten_retry_cooldown",
            "tighten_burst_cap",
        ]
    )


def test_describe_v1_1_excluded_set_shrunk():
    """v1.1.0 removes the three past-LTL holdouts from the excluded map.
    (v1.2.0 further moves Jurisdiction/Counterparty/MutualExclusion into
    the tier; those variant holdouts are pinned by v1.2.0 tests.)"""
    surface = GuaranteedLanguage.describe()
    excluded = surface["excluded_rule_types_with_reason"]
    assert "RetryRateLimit" not in excluded
    assert "RollingWindowCap" not in excluded
    assert "BurstVelocityCap" not in excluded
    assert "SpendingCap.per_window" not in excluded
    assert "SpendingCap.per_provider_per_window" not in excluded


def test_describe_v1_1_excluded_set_retains_structural_holdouts():
    """v1.2.0 moves the bare-class entries into the tier and documents
    the richer variants with qualified keys. Assert the richer holdouts
    are still documented so Bug 2 (nlang) remains visible to auditors."""
    surface = GuaranteedLanguage.describe()
    excluded = surface["excluded_rule_types_with_reason"]
    for variant_key in (
        "JurisdictionRule.nested_composition",
        "JurisdictionRule.nlang",
        "CounterpartyConstraint.sanctions_negation",
        "CounterpartyConstraint.nlang",
    ):
        assert variant_key in excluded
        assert excluded[variant_key].strip()


def test_describe_json_round_trip_v1_1():
    """The full surface round-trips through JSON without dropping fields.
    The v1.1.0 additions (RetryRateLimit, past-LTL ``O``) are present in
    every subsequent tier."""
    surface = GuaranteedLanguage.describe()
    blob = json.dumps(surface)
    restored = json.loads(blob)
    # v1.2.0 bumped the version to cover both agent β's rule-type
    # widening and agent γ's meta-policy tier; the v1.1.0 rule-type +
    # temporal surface is preserved and is what this test pins.
    assert restored["language_version"] == "1.2.0"
    assert "RetryRateLimit" in restored["supported_rule_types"]
    assert "O" in restored["supported_temporal"]


# ── v1.2.0 admits the three classes that v1.1.0 refused ────────────────


def test_jurisdiction_rule_admits_enum_bv_variant_v1_2():
    """v1.2.0 moves JurisdictionRule(no additional_invariants) into the
    tier. The nested-composition variant stays out."""
    ok, code = GuaranteedLanguage.is_supported(
        JurisdictionRule(jurisdiction="EU")
    )
    assert ok is True
    assert code is None


def test_counterparty_constraint_admits_allowlist_variant_v1_2():
    """v1.2.0 moves pure-allowlist CounterpartyConstraint into the tier.
    The sanctions-negation variant stays out."""
    ok, code = GuaranteedLanguage.is_supported(
        CounterpartyConstraint(approved_ids=frozenset({"a"}))
    )
    assert ok is True
    assert code is None


def test_mutual_exclusion_admits_rule_composition_variant_v1_2():
    """v1.2.0 moves the two-group MutualExclusion into the tier via
    ``rule_composition`` (bv BA conjunction + negation)."""
    ok, code = GuaranteedLanguage.is_supported(
        MutualExclusion(group_a=frozenset({"a"}), group_b=frozenset({"b"}))
    )
    assert ok is True
    assert code is None


# ── purity / determinism ───────────────────────────────────────────────


def test_is_supported_is_pure_for_new_types():
    """Two calls with equal invariants yield equal (bool, code) pairs."""
    inv = RollingWindowCap(max_count=10, window_seconds=60)
    a = GuaranteedLanguage.is_supported(inv)
    b = GuaranteedLanguage.is_supported(inv)
    assert a == b
