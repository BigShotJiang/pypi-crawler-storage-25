"""Tests for the simplified first-run front door (v0.23.0).

The v0.23.0 front-door pass shipped three contract-bearing surface
changes:

  1. ``tau-x402 run`` banner centers authorisation + the MCP tool,
     and hides advanced internals (fragment version, prover chain,
     semantic fragment tier) behind ``--verbose``.
  2. The default-policy loader works without an explicit ``--policy``.
  3. ``tau-x402 quickstart --dry-run``-equivalent invocation completes
     without touching live state.

These tests pin each contract so a later refactor that rewords the
banner (fine) can't silently re-introduce the "fragment / prover_chain
/ semantic_fragment" first-run vocabulary (not fine).

We avoid spinning up a real daemon by using ``--dry-run`` on ``run``
and ``--dir=<tmp>`` on ``quickstart``; the tests cover argparse +
banner emission without binding the UDS socket.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent


def _run_cli(*argv: str, timeout: float = 30.0) -> subprocess.CompletedProcess:
    """Invoke ``python -m daemon.cli`` with PYTHONPATH pointed at the repo.

    Kept local to this module (rather than importing from
    tests/test_tau_x402_run.py) so this file stays independently
    maintainable when the v0.21.0 entry-point tests retire.
    """
    env = dict(os.environ)
    env["PYTHONPATH"] = str(REPO_ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *argv],
        capture_output=True,
        text=True,
        env=env,
        timeout=timeout,
    )


# ── banner centers authorisation + the MCP tool ─────────────────────────────


class TestFirstRunBannerContract:
    """The default-verbosity banner must lead with decision-layer framing."""

    def test_run_dry_run_exits_zero(self) -> None:
        """Test 6 (brief): ``tau-x402 run --dry-run`` exits 0."""
        out = _run_cli("run", "--dry-run")
        assert out.returncode == 0, (
            f"stderr={out.stderr}\nstdout={out.stdout}"
        )

    def test_banner_mentions_mcp_tool(self) -> None:
        """Test 6 (brief): banner names ``MCP tool: should_pay_x402``.

        This is the single most load-bearing line for adoption: an
        operator who grep's the first-run banner must see the tool
        name that their agent will call, wired to the socket path
        the daemon listens on.
        """
        out = _run_cli("run", "--dry-run")
        assert out.returncode == 0, f"stderr={out.stderr}"
        assert "MCP tool:" in out.stderr
        assert "should_pay_x402" in out.stderr

    def test_banner_centers_authorisation(self) -> None:
        """Banner leads with 'authorising payment decisions', not with
        'fragment' or 'prover'.

        The first line the operator sees must describe what the cage
        *does* (authorise payments) rather than what's *inside* it
        (provers, fragments).
        """
        out = _run_cli("run", "--dry-run")
        assert "authorising payment decisions" in out.stderr

    def test_banner_names_mode_and_policy_and_runtime_guard(self) -> None:
        """The four front-door bullets must all land in the headline block."""
        out = _run_cli("run", "--dry-run")
        stderr = out.stderr
        assert "policy:" in stderr
        assert "mode:" in stderr
        assert "runtime guard:" in stderr
        assert "MCP tool:" in stderr

    def test_default_verbosity_hides_fragments_and_provers(self) -> None:
        """Advanced concepts (fragment / prover_chain / semantic_fragment)
        must NOT appear in the default-verbosity banner.

        We walk the banner-prefixed lines only (``tau-x402:`` and
        ``tau-x402 run:``); any adjacent noise from signal-handler
        setup or environment-probe diagnostics would NOT be expected
        to contain these vocabulary items either, but we pin the
        banner specifically so a later regression can't silently
        leak them back in.
        """
        out = _run_cli("run", "--dry-run")
        banner_lines = [
            line for line in out.stderr.splitlines()
            if line.startswith("tau-x402:") or line.startswith("tau-x402 run:")
        ]
        banner_text = "\n".join(banner_lines)
        # These are the three advanced-concept tokens the brief calls
        # out specifically. Any of them in the default banner is a
        # regression against Priority 4c.
        for bad in ("fragment", "prover_chain", "semantic_fragment"):
            assert bad not in banner_text, (
                f"default banner leaks advanced concept {bad!r}:\n{banner_text}"
            )


# ── --verbose surfaces advanced concepts when asked ─────────────────────────


class TestVerboseBannerOptIn:
    """Opt-in visibility of advanced details via ``--verbose``."""

    def test_verbose_flag_parses(self) -> None:
        """``tau-x402 run --help`` documents the --verbose flag."""
        out = _run_cli("run", "--help")
        assert out.returncode == 0
        assert "--verbose" in out.stdout

    def test_verbose_banner_can_show_fragment(self) -> None:
        """With ``--verbose`` the advanced surface is fair game."""
        out = _run_cli("run", "--dry-run", "--verbose")
        assert out.returncode == 0, f"stderr={out.stderr}"
        # Verbose mode reveals the fragment + prover details. We don't
        # pin the exact strings (the labels may evolve) but verify at
        # least one of the advanced-concept tokens DOES show up when
        # the operator asks for it.
        stderr = out.stderr
        mentions_advanced = any(
            tok in stderr
            for tok in ("semantic-fragment", "prover-chain", "prover-mode")
        )
        assert mentions_advanced, (
            "verbose banner should name at least one advanced subsystem; got:\n"
            + stderr
        )

    def test_verbose_short_flag_also_parses(self) -> None:
        """``-v`` is the short form of ``--verbose``."""
        out = _run_cli("run", "--dry-run", "-v")
        assert out.returncode == 0, f"stderr={out.stderr}"


# ── default policy loads without explicit --policy ──────────────────────────


class TestDefaultPolicyFirstRun:
    """First-run flow must resolve the packaged default policy."""

    def test_default_policy_resolves_via_run_dry(self) -> None:
        """Running ``tau-x402 run --dry-run`` with no --policy must use
        the packaged default policy and surface its path in the banner.
        """
        out = _run_cli("run", "--dry-run")
        assert out.returncode == 0, f"stderr={out.stderr}"
        # The banner line names the resolved policy path. We don't pin
        # the exact path (it's platform-dependent under site-packages)
        # but verify the default-policy filename shows up.
        assert "default_policy.yaml" in out.stderr

    def test_default_policy_open_allowlist_load_path(self) -> None:
        """``--open-allowlist`` exercises ``_load_default_policy_without_allowlist``.

        Confirms the second default-policy load path (the one with
        the allowlist rule stripped) also resolves cleanly on first run.
        """
        out = _run_cli("run", "--dry-run", "--open-allowlist")
        assert out.returncode == 0, f"stderr={out.stderr}"
        assert "open-allowlist" in out.stderr


# ── quickstart completes without error ──────────────────────────────────────


class TestQuickstartDryCompletes:
    """The ``quickstart`` subcommand must scaffold without error.

    Equivalent to the 'dry-run' requirement in the brief — we
    scaffold into a temp dir so the test doesn't touch the user's
    home directory.
    """

    def test_quickstart_scaffolds_into_tmp(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            out = _run_cli("quickstart", "--dir", tmp)
            assert out.returncode == 0, (
                f"stderr={out.stderr}\nstdout={out.stdout}"
            )
            # The scaffold must at minimum produce a policy.yaml +
            # .env so the first-run path is self-contained.
            assert (Path(tmp) / "policy.yaml").exists()
            assert (Path(tmp) / ".env").exists()
