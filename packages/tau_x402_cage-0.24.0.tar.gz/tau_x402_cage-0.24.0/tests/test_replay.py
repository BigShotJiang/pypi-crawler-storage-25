"""Tests for policy replay / backtest (v0.10.0).

Covers:
  - Empty history → zeroed ReplayResult.
  - Candidate = current → every entry unchanged (regression guard).
  - Stricter candidate → new_rejects > 0, no new_permits.
  - Looser candidate → new_permits > 0, no new_rejects.
  - Mixed invariants (v1 + v2) → both fragments evaluated correctly.
  - Prover inconclusive on candidate → counted, not treated as permit.
  - Daemon replay op round-trip.
  - CLI ``replay --candidate`` end-to-end with stubbed history.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.invariants import (
    Invariant,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
    Violation,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.replay import (
    DEFAULT_MAX_ENTRIES,
    ReplayChange,
    ReplayResult,
    replay_against_candidate,
)
from adapter.x402_registry import X402Registry
from daemon.server import CageDaemon


# ── fixtures ─────────────────────────────────────────────────────────────────


def _intent(
    amount: str = "10.00",
    provider: str = "anthropic",
    counterparty: str = "vendor_x",
    timestamp_unix: int = 1_700_000_000,
    currency: str = "USDC",
) -> PaymentIntent:
    """Build a PaymentIntent for test history."""
    return PaymentIntent(
        amount=Decimal(amount),
        currency=currency,
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=timestamp_unix,
    )


def _history(n: int = 5, base_amount: int = 10) -> list[PaymentIntent]:
    """Build a deterministic OLDEST-first history list."""
    return [
        _intent(
            amount=str(base_amount + i),
            timestamp_unix=1_700_000_000 + i,
        )
        for i in range(n)
    ]


# ── ReplayResult: empty + identity ───────────────────────────────────────────


class TestReplayResultBasics:
    def test_empty_history_returns_zeroed_result(self) -> None:
        r = replay_against_candidate(
            history=[],
            current_invariants=[MaxPerCall(max_amount=Decimal("100"))],
            candidate_invariants=[MaxPerCall(max_amount=Decimal("50"))],
        )
        assert r.total == 0
        assert r.unchanged == 0
        assert r.new_rejects == 0
        assert r.new_permits == 0
        assert r.prover_inconclusive == 0
        assert r.changed == ()

    def test_candidate_equals_current_all_unchanged(self) -> None:
        """Regression guard: replacing the policy with itself must never
        surface a flip. If this fails, either the evaluator is not
        deterministic or the history accumulator is leaking candidate
        verdicts into the current path.
        """
        inv = MaxPerCall(max_amount=Decimal("100"))
        hist = _history(10)
        r = replay_against_candidate(
            history=hist,
            current_invariants=[inv],
            candidate_invariants=[inv],
        )
        assert r.total == 10
        assert r.unchanged == 10
        assert r.new_rejects == 0
        assert r.new_permits == 0
        assert r.prover_inconclusive == 0
        assert r.changed == ()


# ── stricter / looser ────────────────────────────────────────────────────────


class TestStricterCandidate:
    def test_stricter_cap_produces_new_rejects(self) -> None:
        current = [MaxPerCall(max_amount=Decimal("100"))]
        candidate = [MaxPerCall(max_amount=Decimal("12"))]
        hist = _history(5, base_amount=10)
        # history amounts: 10, 11, 12, 13, 14
        r = replay_against_candidate(
            history=hist,
            current_invariants=current,
            candidate_invariants=candidate,
        )
        assert r.total == 5
        # amounts 13 and 14 exceed the stricter 12-cap; 10, 11, 12 stay
        # (MaxPerCall compares <=).
        assert r.unchanged == 3
        assert r.new_rejects == 2
        assert r.new_permits == 0
        # Every change should flip permit → reject under a stricter cap.
        for c in r.changed:
            assert c.before_verdict == "permit"
            assert c.after_verdict == "reject"
            assert c.rule_id == "max_per_call"

    def test_new_allowlist_rejects_unlisted_providers(self) -> None:
        current: list[Invariant] = []  # nothing declared → permit-all
        candidate = [ProviderAllowlist(providers=frozenset({"anthropic"}))]
        hist = [
            _intent(provider="anthropic", timestamp_unix=1_700_000_000),
            _intent(provider="openai", timestamp_unix=1_700_000_001),
            _intent(provider="anthropic", timestamp_unix=1_700_000_002),
        ]
        r = replay_against_candidate(
            history=hist,
            current_invariants=current,
            candidate_invariants=candidate,
        )
        assert r.total == 3
        assert r.new_rejects == 1
        assert r.new_permits == 0
        assert len(r.changed) == 1
        assert r.changed[0].intent["provider"] == "openai"


class TestLooserCandidate:
    def test_looser_cap_produces_new_permits(self) -> None:
        # Current rejects amounts > 11; candidate allows up to 100.
        current = [MaxPerCall(max_amount=Decimal("11"))]
        candidate = [MaxPerCall(max_amount=Decimal("100"))]
        hist = _history(5, base_amount=10)
        # amounts: 10, 11, 12, 13, 14 — under current, 12, 13, 14 reject.
        r = replay_against_candidate(
            history=hist,
            current_invariants=current,
            candidate_invariants=candidate,
        )
        assert r.total == 5
        assert r.new_permits == 3
        assert r.new_rejects == 0
        for c in r.changed:
            assert c.before_verdict == "reject"
            assert c.after_verdict == "permit"


# ── mixed fragment v1 + v2 ───────────────────────────────────────────────────


class TestMixedFragments:
    def test_v1_allowlist_plus_v2_rolling_cap(self) -> None:
        """Candidate combines a fragment-v1 rule (ProviderAllowlist) and a
        fragment-v2 rule (RollingWindowCap). Both must be evaluated —
        otherwise the replay would miss one dimension of enforcement.
        """
        current: list[Invariant] = []
        candidate = [
            ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
            RollingWindowCap(max_count=2, window_seconds=3600, group_by="provider"),
        ]
        # 4 anthropic intents in the same hour → 3rd and 4th exceed the cap.
        hist = [
            _intent(provider="anthropic", timestamp_unix=1_700_000_000),
            _intent(provider="anthropic", timestamp_unix=1_700_000_100),
            _intent(provider="anthropic", timestamp_unix=1_700_000_200),
            _intent(provider="anthropic", timestamp_unix=1_700_000_300),
            # Disallowed provider — fires ProviderAllowlist not RollingWindowCap.
            _intent(provider="not_on_list", timestamp_unix=1_700_000_400),
        ]
        r = replay_against_candidate(
            history=hist,
            current_invariants=current,
            candidate_invariants=candidate,
        )
        # All 5 were permitted under the empty current; the candidate
        # should reject intents 3, 4 (rolling-cap) and 5 (allowlist).
        assert r.total == 5
        assert r.new_rejects == 3
        assert r.new_permits == 0
        rule_ids = {c.rule_id for c in r.changed}
        assert "provider_allowlist" in rule_ids
        assert any(rid and rid.startswith("rolling_window_cap") for rid in rule_ids)

    def test_v2_spending_cap_per_window(self) -> None:
        # Per-window cap of 30 over a 1h window; history spends 10 four times.
        current: list[Invariant] = []
        candidate = [
            SpendingCap(
                max_amount=Decimal("30"),
                currency="USDC",
                scope="per_window",
                window_seconds=3600,
            ),
        ]
        hist = [
            _intent(amount="10", timestamp_unix=1_700_000_000),
            _intent(amount="10", timestamp_unix=1_700_000_100),
            _intent(amount="10", timestamp_unix=1_700_000_200),  # cumulative = 30 (ok, <=)
            _intent(amount="10", timestamp_unix=1_700_000_300),  # cumulative = 40 (reject)
        ]
        r = replay_against_candidate(
            history=hist,
            current_invariants=current,
            candidate_invariants=candidate,
        )
        assert r.total == 4
        # Under the candidate, the 4th intent takes cumulative to 40 > 30.
        # BUT history accumulation tracks CURRENT's permits (all 4), so the
        # candidate sees a window holding intents 1-3 and evaluates #4. That
        # matches how replay is documented: history is accumulated against
        # the current registry's verdicts, not the candidate's.
        assert r.new_rejects == 1
        assert r.new_permits == 0


# ── inconclusive candidate ───────────────────────────────────────────────────


from dataclasses import dataclass as _dc_dataclass


@_dc_dataclass(frozen=True)
class _RaisingInvariant(Invariant):
    """Test-only invariant whose check_payment always raises.

    Simulates a candidate rule that fails at replay time (e.g. a future
    fragment-v3 rule the current Python layer can't evaluate). The replay
    contract says these must surface as ``prover_inconclusive`` counts,
    not silent permits.
    """

    def _body(self) -> str:
        return "T"

    def check_payment(self, intent, history, rejects=()):
        raise RuntimeError("simulated fragment-v3 unsupported at replay time")


class TestInconclusive:
    def test_raising_candidate_counts_as_inconclusive(self) -> None:
        hist = _history(3)
        r = replay_against_candidate(
            history=hist,
            current_invariants=[],
            candidate_invariants=[_RaisingInvariant()],
        )
        assert r.total == 3
        assert r.prover_inconclusive == 3
        # Inconclusive is NOT silently treated as permit — it lands in
        # `changed` with after_verdict="inconclusive".
        assert r.new_rejects == 0
        assert r.new_permits == 0
        assert len(r.changed) == 3
        for c in r.changed:
            assert c.after_verdict == "inconclusive"
            assert c.before_verdict == "permit"  # current is empty → permit


# ── daemon op round-trip ─────────────────────────────────────────────────────


def _send(path: str, request: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(5.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


@pytest.fixture
def running_daemon() -> Iterator[tuple[CageDaemon, str]]:
    """Spin up a real daemon in a thread with a short UDS path."""
    fd, path = tempfile.mkstemp(prefix="replay-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield d, path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


class TestDaemonReplayOp:
    def test_replay_requires_invariants_list(self, running_daemon) -> None:
        _, path = running_daemon
        resp = _send(path, {"op": "replay_policy"})
        assert resp["verdict"] == "error"
        assert resp["category"] == "bad_payload"

    def test_replay_with_empty_history_is_zeroed(self, running_daemon) -> None:
        _, path = running_daemon
        resp = _send(
            path,
            {
                "op": "replay_policy",
                "invariants": [
                    {"kind": "max_per_call", "max_amount": "50"},
                ],
            },
        )
        assert resp["verdict"] == "ok"
        assert resp["total"] == 0
        assert resp["unchanged"] == 0
        assert resp["new_rejects"] == 0
        assert resp["new_permits"] == 0

    def test_replay_flips_verdicts_against_stored_history(
        self, running_daemon
    ) -> None:
        d, path = running_daemon
        # Seed history via check_payment: permit a series of increasing amounts
        # under a loose cap.
        resp = _send(
            path,
            {"op": "declare_x402", "kind": "max_per_call", "max_amount": "1000"},
        )
        assert resp["verdict"] == "updated"
        for i in range(5):
            r = _send(
                path,
                {
                    "op": "check_payment",
                    "intent": {
                        "amount": str(20 + i),
                        "currency": "USDC",
                        "provider": "anthropic",
                        "counterparty": "vendor_x",
                        "rail": "x402",
                        "timestamp_unix": 1_700_000_000 + i,
                    },
                },
            )
            assert r["verdict"] == "permit", r
        # Replay with a stricter cap of 22: amounts 23, 24 should reject.
        resp = _send(
            path,
            {
                "op": "replay_policy",
                "invariants": [
                    {"kind": "max_per_call", "max_amount": "22"},
                ],
            },
        )
        assert resp["verdict"] == "ok"
        assert resp["total"] == 5
        assert resp["new_rejects"] == 2
        assert resp["new_permits"] == 0
        assert resp["history_available"] == 5

    def test_replay_honours_window_seconds(self, running_daemon) -> None:
        d, path = running_daemon
        _send(
            path,
            {"op": "declare_x402", "kind": "max_per_call", "max_amount": "1000"},
        )
        # 3 old intents (timestamp 1000) + 2 recent (timestamp 2000).
        for ts in (1_000, 1_000, 1_000, 2_000, 2_000):
            _send(
                path,
                {
                    "op": "check_payment",
                    "intent": {
                        "amount": "10",
                        "currency": "USDC",
                        "provider": "anthropic",
                        "counterparty": "vendor_x",
                        "rail": "x402",
                        "timestamp_unix": ts,
                    },
                },
            )
        # Window 500 covers only the newest 2 entries (timestamps within
        # 500s of the newest, which is 2000 → 1500..2000).
        resp = _send(
            path,
            {
                "op": "replay_policy",
                "invariants": [{"kind": "max_per_call", "max_amount": "5"}],
                "window_seconds": 500,
            },
        )
        assert resp["verdict"] == "ok"
        assert resp["total"] == 2
        assert resp["new_rejects"] == 2

    def test_replay_max_entries_caps(self, running_daemon) -> None:
        _, path = running_daemon
        resp = _send(
            path,
            {
                "op": "replay_policy",
                "invariants": [{"kind": "max_per_call", "max_amount": "5"}],
                "max_entries": 5_000_000_000,  # huge; should be clamped
            },
        )
        assert resp["verdict"] == "ok"
        assert resp["max_entries"] == DEFAULT_MAX_ENTRIES

    def test_replay_bad_invariant_aborts_whole_call(self, running_daemon) -> None:
        _, path = running_daemon
        resp = _send(
            path,
            {
                "op": "replay_policy",
                "invariants": [{"kind": "not_a_real_kind"}],
            },
        )
        assert resp["verdict"] == "error"
        assert resp["category"] == "bad_invariant"


# ── CLI end-to-end ───────────────────────────────────────────────────────────


def _run_cli(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    repo_root = str(Path(__file__).resolve().parent.parent)
    env["PYTHONPATH"] = os.pathsep.join(
        [repo_root, env.get("PYTHONPATH", "")]
    ).rstrip(os.pathsep)
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *args],
        cwd=cwd, capture_output=True, text=True, timeout=30, env=env,
    )


class TestCliReplay:
    def test_replay_subcommand_in_help(self) -> None:
        r = _run_cli(["--help"])
        assert r.returncode == 0
        assert "replay" in r.stdout

    def test_replay_fails_on_missing_candidate(self, tmp_path: Path) -> None:
        r = _run_cli(
            [
                "replay",
                "--socket", str(tmp_path / "dead.sock"),
                "--candidate", str(tmp_path / "nonexistent.yaml"),
            ],
        )
        assert r.returncode == 2

    def test_replay_end_to_end_against_live_daemon(
        self, running_daemon, tmp_path: Path
    ) -> None:
        _, path = running_daemon
        # Seed history via UDS.
        _send(
            path,
            {"op": "declare_x402", "kind": "max_per_call", "max_amount": "1000"},
        )
        for i in range(3):
            _send(
                path,
                {
                    "op": "check_payment",
                    "intent": {
                        "amount": str(50 + i),
                        "currency": "USDC",
                        "provider": "anthropic",
                        "counterparty": "vendor_x",
                        "rail": "x402",
                        "timestamp_unix": 1_700_000_000 + i,
                    },
                },
            )
        # Write a stricter candidate policy.
        candidate = tmp_path / "candidate.yaml"
        candidate.write_text(
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            '    max_amount: "49"\n'
        )
        r = _run_cli(
            [
                "replay",
                "--socket", path,
                "--candidate", str(candidate),
            ]
        )
        assert r.returncode == 0, r.stderr
        assert "Policy replay" in r.stdout
        assert "replayed:" in r.stdout
        # 50, 51, 52 all exceed the candidate's 49-cap.
        assert "new_rejects:        3" in r.stdout

    def test_replay_renders_table_for_changed_entries(
        self, running_daemon, tmp_path: Path
    ) -> None:
        _, path = running_daemon
        _send(
            path,
            {"op": "declare_x402", "kind": "max_per_call", "max_amount": "1000"},
        )
        _send(
            path,
            {
                "op": "check_payment",
                "intent": {
                    "amount": "100",
                    "currency": "USDC",
                    "provider": "anthropic",
                    "counterparty": "vendor_x",
                    "rail": "x402",
                    "timestamp_unix": 1_700_000_000,
                },
            },
        )
        candidate = tmp_path / "candidate.yaml"
        candidate.write_text(
            "version: 1\n"
            "policy:\n"
            "  - kind: max_per_call\n"
            '    max_amount: "10"\n'
        )
        r = _run_cli(
            ["replay", "--socket", path, "--candidate", str(candidate)]
        )
        assert r.returncode == 0, r.stderr
        # Header row + the single flipped entry.
        assert "amount" in r.stdout
        assert "before" in r.stdout
        assert "after" in r.stdout
        assert "max_per_call" in r.stdout
