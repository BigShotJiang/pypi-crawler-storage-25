"""Adversarial battle pack for the envelope layer.

Originally authored by an external reviewer (ChatGPT phase-2 adversarial
run, 2026-04-20) that flagged two red-flag behaviours:

1. ``verify()`` was stateless, so a captured envelope could be re-presented
   for the same intent within its TTL window.
2. ``SignedEnvelope.from_json()`` silently dropped surplus top-level
   fields, weakening the audit/forensics posture.

v0.23.1 hardened both: :class:`ReplayCache` closes the replay window when
passed to :func:`verify`, and ``from_json(..., strict=True)`` rejects
unknown top-level fields. These tests gate on that behaviour so neither
hardening can regress.
"""
from __future__ import annotations

import json
from decimal import Decimal

import pytest

from adapter.history_store import RedisHistoryStore
from adapter.payment_intent_matcher import PaymentIntent
from adapter.verdict_signer import (
    ReplayCache,
    SignatureError,
    SignedEnvelope,
    Verdict,
    hash_intent,
    sign,
    verify,
)


SECRET = b"0123456789abcdef0123456789abcdef"


def _intent(
    amount: str = "10.00",
    *,
    provider: str = "anthropic",
    counterparty: str = "vendor_x",
    timestamp_unix: int = 1_700_000_000,
    request_id: str | None = "req-1",
    metadata: dict[str, str] | None = None,
) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency="USDC",
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=timestamp_unix,
        metadata=metadata or {},
        request_id=request_id,
    )


class TestCanonicalizationAndBinding:
    def test_hash_intent_is_stable_under_metadata_key_order(self) -> None:
        a = _intent(metadata={"trace_id": "t1", "session": "s1"})
        b = _intent(metadata={"session": "s1", "trace_id": "t1"})
        assert hash_intent(a) == hash_intent(b)

    def test_hash_intent_changes_when_request_id_changes(self) -> None:
        a = _intent(request_id="req-1")
        b = _intent(request_id="req-2")
        assert hash_intent(a) != hash_intent(b)


class TestReplayAndParserHardening:
    def test_same_signed_envelope_cannot_be_reused_before_expiry(self) -> None:
        cache = ReplayCache()
        intent = _intent(request_id="req-replay")
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )

        verify(env, intent, SECRET, now_unix=1005, replay_cache=cache)
        with pytest.raises(SignatureError, match="already consumed"):
            verify(env, intent, SECRET, now_unix=1006, replay_cache=cache)

    def test_replay_cache_expires_entries_after_ttl(self) -> None:
        cache = ReplayCache()
        intent = _intent(request_id="req-replay-ttl")
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )
        verify(env, intent, SECRET, now_unix=1005, replay_cache=cache)
        assert len(cache) == 1

        # A later mark_seen call reaps entries whose expiry (1030) is
        # at or before now_unix.
        later_intent = _intent(request_id="req-replay-ttl-2", timestamp_unix=1_700_000_100)
        later_env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            later_intent,
            SECRET,
            now_unix=2000,
        )
        verify(later_env, later_intent, SECRET, now_unix=2005, replay_cache=cache)
        # Original row (expiry 1030) reaped; only the later row remains.
        assert len(cache) == 1

    def test_verify_without_cache_remains_stateless_for_back_compat(self) -> None:
        """Legacy callers that retry must not see the stricter behaviour."""
        intent = _intent(request_id="req-stateless")
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )
        verify(env, intent, SECRET, now_unix=1005)
        verify(env, intent, SECRET, now_unix=1006)  # must still pass

    def test_envelope_parser_rejects_unknown_top_level_fields_in_strict_mode(self) -> None:
        intent = _intent()
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )
        payload = json.loads(env.to_json())
        payload["surplus_field"] = "should-not-be-accepted"
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))

        with pytest.raises(SignatureError, match="unknown top-level fields"):
            SignedEnvelope.from_json(raw, strict=True)

    def test_envelope_parser_stays_permissive_by_default(self) -> None:
        """Forward-compatible wire ingestion must still work."""
        intent = _intent()
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )
        payload = json.loads(env.to_json())
        payload["surplus_field"] = "ignored-by-default"
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))

        parsed = SignedEnvelope.from_json(raw)
        assert parsed.mac_hex == env.mac_hex


class TestRedisFailurePaths:
    def test_corrupt_redis_row_fails_loudly_on_decode(self) -> None:
        try:
            import fakeredis  # type: ignore[import-untyped]
        except ImportError:
            pytest.skip("fakeredis not installed")

        client = fakeredis.FakeRedis(decode_responses=True)
        store = RedisHistoryStore(url="redis://fake", redis_client=client, cap=10)
        client.lpush("tau-x402-cage:history:permit", '{"_tag":"intent","amount":"10"}')

        with pytest.raises(Exception):
            store.recent("permit", limit=1)

    def test_pipeline_execute_failure_is_not_silent(self) -> None:
        class BrokenPipe:
            def lpush(self, *args, **kwargs):
                return self

            def ltrim(self, *args, **kwargs):
                return self

            def execute(self):
                raise RuntimeError("write failed")

        class BrokenClient:
            def ping(self):
                return True

            def pipeline(self):
                return BrokenPipe()

        store = RedisHistoryStore(url="redis://fake", redis_client=BrokenClient(), cap=10)
        with pytest.raises(RuntimeError, match="write failed"):
            store.append(_intent(), kind="permit")


class TestIntentBindingTamperResistance:
    def test_verification_rejects_same_envelope_for_different_request_id(self) -> None:
        original = _intent(request_id="req-a")
        mutated = _intent(request_id="req-b")
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            original,
            SECRET,
            now_unix=1000,
        )

        with pytest.raises(SignatureError, match="intent_hash mismatch"):
            verify(env, mutated, SECRET, now_unix=1005)
