"""Tests for TauConsistencyProver, ChainedProver semantics, and prover_from_env.

The Tau CLI binary is not a required dep, so the bulk of these tests drive the
prover via a mocked `subprocess.run` so behavior is deterministic without the
real runtime. One integration test runs against a real Tau binary and skips
cleanly when unavailable.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from decimal import Decimal
from unittest.mock import patch

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
)
from adapter.prover import (
    ConsistencyProver,
    Contradiction,
    ProofToken,
    PythonPatternProver,
    TauConsistencyProver,
    TauUnavailable,
    prover_from_env,
)


# ── fixture: pretend tau is installed via TAU_BINARY env ─────────────────────


@pytest.fixture
def fake_tau_binary(tmp_path, monkeypatch):
    """Point TAU_BINARY at a harmless script so is_available() passes."""
    fake = tmp_path / "tau"
    fake.write_text("#!/bin/sh\necho T\n")
    fake.chmod(0o755)
    monkeypatch.setenv("TAU_BINARY", str(fake))
    yield fake


# ── is_available() ───────────────────────────────────────────────────────────


class TestIsAvailable:
    def test_missing_binary_returns_false(self, monkeypatch) -> None:
        monkeypatch.delenv("TAU_BINARY", raising=False)
        monkeypatch.setenv("PATH", "/nonexistent")
        assert TauConsistencyProver.is_available() is False

    def test_tau_binary_env_makes_it_available(self, fake_tau_binary) -> None:
        assert TauConsistencyProver.is_available() is True


# ── prove(): happy paths via mocked subprocess ───────────────────────────────


class TestProveWithMockedTau:
    def test_tau_sat_returns_complete_token(self, fake_tau_binary) -> None:
        p = TauConsistencyProver(timeout_seconds=1.0)
        with patch("adapter.prover.subprocess.run") as mock_run:
            mock_run.return_value = subprocess.CompletedProcess(
                args=[], returncode=0, stdout="sat: 0.18 ms\n%1: T\n", stderr="",
            )
            result = p.prove([MaxPerCall(max_amount=Decimal("10"))])
        assert isinstance(result, ProofToken)
        assert result.backend == "tau"
        assert result.proof_strength == "complete"

    def test_tau_unsat_returns_contradiction(self, fake_tau_binary) -> None:
        p = TauConsistencyProver(timeout_seconds=1.0)
        with patch("adapter.prover.subprocess.run") as mock_run:
            mock_run.return_value = subprocess.CompletedProcess(
                args=[], returncode=0, stdout="sat: 0.08 ms\n%1: F\n", stderr="",
            )
            result = p.prove([MaxPerCall(max_amount=Decimal("10"))])
        assert isinstance(result, Contradiction)
        assert result.backend == "tau"
        assert "unsatisfiable" in result.reason.lower()

    def test_tau_parse_error_falls_back_to_pattern(self, fake_tau_binary) -> None:
        p = TauConsistencyProver(timeout_seconds=1.0)
        with patch("adapter.prover.subprocess.run") as mock_run:
            mock_run.return_value = subprocess.CompletedProcess(
                args=[], returncode=0, stdout="(Error) Syntax Error at line 1", stderr="",
            )
            result = p.prove([MaxPerCall(max_amount=Decimal("10"))])
        assert isinstance(result, ProofToken)
        assert result.backend == "chained:tau->pattern"
        assert result.proof_strength == "pattern+tau-inconclusive"

    def test_tau_timeout_falls_back_to_pattern(self, fake_tau_binary) -> None:
        p = TauConsistencyProver(timeout_seconds=0.01)
        with patch("adapter.prover.subprocess.run") as mock_run:
            mock_run.side_effect = subprocess.TimeoutExpired(cmd="tau", timeout=0.01)
            result = p.prove([MaxPerCall(max_amount=Decimal("10"))])
        assert isinstance(result, ProofToken)
        assert result.proof_strength == "pattern+tau-inconclusive"

    def test_tau_binary_missing_falls_back(self, monkeypatch) -> None:
        monkeypatch.delenv("TAU_BINARY", raising=False)
        monkeypatch.setenv("PATH", "/nonexistent")
        p = TauConsistencyProver()
        result = p.prove([MaxPerCall(max_amount=Decimal("10"))])
        assert isinstance(result, ProofToken)
        assert result.proof_strength == "pattern+tau-unavailable"

    def test_pattern_caught_contradiction_short_circuits(self, fake_tau_binary) -> None:
        """If pattern prover already finds UNSAT, don't call Tau."""
        p = TauConsistencyProver()
        # Cross-rule approved/sanctioned overlap: one rule approves vendor_a,
        # another sanctions vendor_a. Pattern prover catches this (C3 in
        # _detect_conflict); Tau should never be invoked.
        rules = [
            CounterpartyConstraint(approved_ids=frozenset({"vendor_a"})),
            CounterpartyConstraint(sanctioned_ids=frozenset({"vendor_a"})),
        ]
        with patch("adapter.prover.subprocess.run") as mock_run:
            result = p.prove(rules)
            mock_run.assert_not_called()
        assert isinstance(result, Contradiction)
        assert result.backend == "python-pattern"


# ── stronger PythonPatternProver checks ──────────────────────────────────────


class TestStrongerPatternProver:
    def test_sanctioned_approved_cross_rule_caught(self) -> None:
        p = PythonPatternProver()
        rules = [
            CounterpartyConstraint(approved_ids=frozenset({"vendor_a"})),
            CounterpartyConstraint(sanctioned_ids=frozenset({"vendor_a"})),
        ]
        result = p.prove(rules)
        assert isinstance(result, Contradiction)
        assert "sanctioned" in result.reason.lower()

    def test_multi_allowlist_empty_intersection_caught(self) -> None:
        p = PythonPatternProver()
        rules = [
            ProviderAllowlist(providers=frozenset({"a", "b"})),
            ProviderAllowlist(providers=frozenset({"c", "d"})),
        ]
        result = p.prove(rules)
        assert isinstance(result, Contradiction)
        assert "empty pairwise intersection" in result.reason.lower()

    def test_multi_allowlist_nonempty_intersection_ok(self) -> None:
        rules = [
            ProviderAllowlist(providers=frozenset({"a", "b"})),
            ProviderAllowlist(providers=frozenset({"a", "c"})),
        ]
        result = PythonPatternProver().prove(rules)
        assert isinstance(result, ProofToken)


# ── prover_from_env factory ──────────────────────────────────────────────────


class TestProverFromEnv:
    def test_default_is_pattern(self, monkeypatch) -> None:
        monkeypatch.delenv("CAGE_PROVER", raising=False)
        p = prover_from_env()
        assert p.backend == "python-pattern"

    def test_explicit_pattern(self, monkeypatch) -> None:
        monkeypatch.setenv("CAGE_PROVER", "pattern")
        p = prover_from_env()
        assert p.backend == "python-pattern"

    def test_explicit_tau(self, monkeypatch) -> None:
        monkeypatch.setenv("CAGE_PROVER", "tau")
        p = prover_from_env()
        assert p.backend == "tau"

    def test_auto_without_tau_falls_back(self, monkeypatch) -> None:
        monkeypatch.setenv("CAGE_PROVER", "auto")
        monkeypatch.delenv("TAU_BINARY", raising=False)
        monkeypatch.setenv("PATH", "/nonexistent")
        p = prover_from_env()
        assert p.backend == "python-pattern"

    def test_unknown_falls_back(self, monkeypatch) -> None:
        monkeypatch.setenv("CAGE_PROVER", "quantum")
        p = prover_from_env()
        assert p.backend == "python-pattern"


# ── real Tau integration (skips if binary not available) ─────────────────────


@pytest.mark.skipif(
    not TauConsistencyProver.is_available(),
    reason="Tau binary not on PATH and TAU_BINARY not set; skipping real-Tau test",
)
class TestRealTauIntegration:
    def test_trivially_sat_returns_token_or_inconclusive(self) -> None:
        """End-to-end against a real Tau binary. Accepts 'complete' OR
        'pattern+tau-inconclusive' because stream-typed specs may time out
        in some Tau builds; the adapter handles both honestly."""
        rules = [MaxPerCall(max_amount=Decimal("10"))]
        p = TauConsistencyProver(timeout_seconds=5.0)
        result = p.prove(rules)
        assert isinstance(result, ProofToken)
        assert result.proof_strength in ("complete", "pattern+tau-inconclusive")
