"""Tests for branching revision graphs (v0.7.0).

Covers:
  * Branch dataclass shape + serialization round-trip.
  * RevisionLog.create_branch / checkout_branch / list_branches.
  * Mutations are tagged with the active branch.
  * checkout_branch swaps the live registry to the branch's head.
  * Fast-forward merge updates dst's head.
  * Non-FF merge returns a structured BranchMergeConflict with two deltas.
  * Persistence: jsonl rehydrates branches, revisions, and active branch.
  * Daemon `current_branch` op surfaces the active branch.
  * Backward-compat: v0.6.x logs (no _record_type) still load cleanly.
"""
from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
)
from adapter.policy_revision import (
    DEFAULT_BRANCH,
    Branch,
    BranchMergeConflict,
    PolicyRevision,
    RevisionLog,
    RevisionLogError,
)
from adapter.prover import ProofToken
from daemon.server import CageDaemon


# ── helpers ──────────────────────────────────────────────────────────────────


def _token(config_hash: str, nonce: str, predecessor: str | None = None) -> ProofToken:
    return ProofToken(
        config_hash=config_hash,
        issued_at_unix=1_713_000_000,
        backend="python-pattern",
        proof_strength="pattern",
        nonce=nonce,
        predecessor_hash=predecessor,
        prover_mode="compat",
        fragment_version=None,
        compile_hash=None,
        tau_backend_version=None,
    )


def _rev(
    cfg: str,
    nonce: str,
    invariants: tuple,
    predecessor: str | None = None,
    branch: str = "main",
    depth: int = 0,
) -> PolicyRevision:
    from dataclasses import replace
    base = PolicyRevision.from_proof_token(
        token=_token(cfg, nonce, predecessor),
        invariants=invariants,
        predecessor_revision_id=predecessor,
    )
    return replace(base, branch=branch, revision_depth=depth)


def _send(path: str, req: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


@pytest.fixture
def daemon_sock(tmp_path) -> Iterator[tuple[str, Path, CageDaemon]]:
    """Bring up a CageDaemon on a short UDS path with disk persistence."""
    fd, sock = tempfile.mkstemp(prefix="brn-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(sock)
    log_path = tmp_path / "revs.jsonl"
    d = CageDaemon(socket_path=sock, revision_log_path=log_path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(sock):
            break
        time.sleep(0.01)
    try:
        yield sock, log_path, d
    finally:
        d.shutdown()
        t.join(timeout=1.0)


# ── Branch dataclass ─────────────────────────────────────────────────────────


class TestBranchShape:
    def test_branch_is_frozen(self) -> None:
        b = Branch(name="shadow", head_revision_id="r1", created_at=1, created_by="jme")
        with pytest.raises(Exception):
            b.name = "other"  # type: ignore[misc]

    def test_branch_with_head_returns_new_branch(self) -> None:
        b = Branch(name="shadow", head_revision_id="r1", created_at=1, created_by="jme")
        b2 = b.with_head("r2")
        assert b2.head_revision_id == "r2"
        assert b.head_revision_id == "r1"   # original untouched
        assert b2.name == b.name
        assert b2.created_at == b.created_at

    def test_branch_to_dict_from_dict_round_trip(self) -> None:
        b = Branch(name="shadow", head_revision_id="abc:1", created_at=42, created_by="jme")
        d = b.to_dict()
        assert d["_record_type"] == "branch"
        rebuilt = Branch.from_dict(d)
        assert rebuilt == b

    def test_branch_from_dict_rejects_missing_name(self) -> None:
        with pytest.raises(RevisionLogError):
            Branch.from_dict({})


# ── RevisionLog.create_branch / list_branches ────────────────────────────────


class TestCreateAndListBranches:
    def test_default_branch_present_without_explicit_create(self) -> None:
        log = RevisionLog()
        branches = log.list_branches()
        names = [b.name for b in branches]
        assert DEFAULT_BRANCH in names

    def test_active_branch_defaults_to_main(self) -> None:
        log = RevisionLog()
        assert log.active_branch == DEFAULT_BRANCH

    def test_create_branch_from_current_head(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        shadow = log.create_branch("shadow", created_by="jme")
        assert shadow.name == "shadow"
        assert shadow.head_revision_id == r1.revision_id
        assert shadow.created_by == "jme"
        names = sorted(b.name for b in log.list_branches())
        assert DEFAULT_BRANCH in names and "shadow" in names

    def test_create_branch_from_explicit_revision(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        r2 = _rev("h2", "n2", invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, depth=1)
        log.append(r2)
        b = log.create_branch("feature", from_revision_id=r1.revision_id)
        assert b.head_revision_id == r1.revision_id

    def test_create_branch_rejects_duplicate_name(self) -> None:
        log = RevisionLog()
        log.create_branch("shadow")
        with pytest.raises(RevisionLogError):
            log.create_branch("shadow")

    def test_create_branch_rejects_unknown_from_revision(self) -> None:
        log = RevisionLog()
        with pytest.raises(RevisionLogError):
            log.create_branch("shadow", from_revision_id="nope")

    def test_create_branch_rejects_empty_name(self) -> None:
        log = RevisionLog()
        with pytest.raises(RevisionLogError):
            log.create_branch("")


# ── checkout / append tagging ───────────────────────────────────────────────


class TestCheckoutAndAppendTagging:
    def test_checkout_swaps_active_branch(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow")
        log.checkout_branch("shadow")
        assert log.active_branch == "shadow"

    def test_checkout_unknown_branch_raises(self) -> None:
        log = RevisionLog()
        with pytest.raises(RevisionLogError):
            log.checkout_branch("no-such")

    def test_append_tags_revision_with_active_branch(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        log.checkout_branch("shadow")
        # Append a revision EXPLICITLY tagged to the active branch.
        r2 = _rev(
            "h2", "n2",
            invariants=(MaxPerCall(max_amount=Decimal("20")),),
            predecessor=r1.revision_id,
            branch="shadow",
            depth=1,
        )
        log.append(r2)
        # latest follows the active branch
        assert log.latest is not None
        assert log.latest.revision_id == r2.revision_id
        assert log.latest.branch == "shadow"
        # main head stays at r1
        main_head = log.head_of("main")
        assert main_head is not None
        assert main_head.revision_id == r1.revision_id

    def test_checkout_back_to_main_restores_main_head(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        log.checkout_branch("shadow")
        r2 = _rev("h2", "n2", invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r2)
        log.checkout_branch("main")
        assert log.active_branch == "main"
        assert log.latest is not None
        assert log.latest.revision_id == r1.revision_id


# ── ancestry + merge ────────────────────────────────────────────────────────


class TestBranchAncestor:
    def test_lca_returns_branch_point(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        log.checkout_branch("shadow")
        r2 = _rev("h2", "n2", invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r2)
        assert log.branch_ancestor("shadow", "main") == r1.revision_id

    def test_lca_none_when_branches_empty(self) -> None:
        log = RevisionLog()
        log.create_branch("shadow")
        assert log.branch_ancestor("shadow", "main") is None


class TestMergeBranch:
    def test_ff_merge_advances_dst_head(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        log.checkout_branch("shadow")
        r2 = _rev("h2", "n2", invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r2)
        # main is still at r1; shadow is at r2; FF is legal.
        result = log.merge_branch("shadow", "main", reviewer="jme")
        assert isinstance(result, Branch)
        assert result.head_revision_id == r2.revision_id
        assert log.head_of("main").revision_id == r2.revision_id

    def test_non_ff_merge_with_overlapping_class_returns_conflict(self) -> None:
        """v0.8.0 semantics: a non-FF merge where BOTH sides touched the
        same invariant class still returns a BranchMergeConflict with a
        populated ``conflicting_invariants`` list. The disjoint-deltas
        fast-path is covered in ``tests/test_three_way_merge.py``.

        This was `test_non_ff_merge_returns_conflict` in v0.7.0; updated
        for v0.8.0 so the non-FF case explicitly overlaps (both sides
        modify MaxPerCall) and still conflicts.
        """
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        # Advance main: bump MaxPerCall to 20 and add ProviderAllowlist.
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("20")),
                              ProviderAllowlist(providers=frozenset({"anthropic"}))),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        # Advance shadow: bump MaxPerCall to 30 (conflicting edit on same class).
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("30")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        # Both branches diverged AND both modified MaxPerCall -> conflict.
        result = log.merge_branch("shadow", "main", reviewer="jme")
        assert isinstance(result, BranchMergeConflict)
        assert result.src == "shadow"
        assert result.dst == "main"
        assert result.common_ancestor == r1.revision_id
        # Each delta names what each side added relative to r1.
        assert result.src_delta["added"]   # new MaxPerCall + RetryRateLimit
        assert result.dst_delta["added"]   # new MaxPerCall + ProviderAllowlist
        # dst head did not move.
        assert log.head_of("main").revision_id == r2.revision_id
        # v0.8.0: conflicting_invariants names MaxPerCall as the overlap.
        conflicting_classes = [c["class_name"] for c in result.conflicting_invariants]
        assert "MaxPerCall" in conflicting_classes

    def test_merge_reviewer_required_at_call_site(self) -> None:
        log = RevisionLog()
        log.create_branch("shadow")
        # Merging an empty src branch into main is a hard error (nothing to do).
        with pytest.raises(RevisionLogError):
            log.merge_branch("shadow", "main", reviewer="jme")

    def test_merge_same_branch_rejected(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        with pytest.raises(RevisionLogError):
            log.merge_branch("main", "main", reviewer="jme")

    def test_ff_merge_to_empty_dst(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),),
                  branch="main")
        log.append(r1)
        log.create_branch("shadow")  # head at r1 (inherits main's head)
        log.checkout_branch("shadow")
        r2 = _rev("h2", "n2", invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r2)
        # Now create an empty branch and merge shadow into it.
        log.create_branch("empty_dst", from_revision_id=None)
        # NB: default from_revision_id is the current head of active (shadow),
        # so force it to None explicitly.
        from dataclasses import replace
        log._branches["empty_dst"] = replace(log._branches["empty_dst"], head_revision_id=None)
        result = log.merge_branch("shadow", "empty_dst", reviewer="jme")
        assert isinstance(result, Branch)
        assert result.head_revision_id == r2.revision_id


# ── persistence ──────────────────────────────────────────────────────────────


class TestBranchPersistence:
    def test_branch_records_written_to_jsonl(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        log = RevisionLog(path=p)
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id, created_by="jme")
        log.checkout_branch("shadow")
        lines = p.read_text().splitlines()
        # one revision + one branch + one checkout = 3
        assert len(lines) == 3
        records = [json.loads(ln) for ln in lines]
        assert records[0].get("_record_type") is None   # revision
        assert records[1].get("_record_type") == "branch"
        assert records[2].get("_record_type") == "checkout"

    def test_rehydrate_restores_branches_and_active(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        log = RevisionLog(path=p)
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id, created_by="jme")
        log.checkout_branch("shadow")
        r2 = _rev("h2", "n2", invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r2)
        # Reload.
        log2 = RevisionLog.load(p)
        assert log2.active_branch == "shadow"
        assert log2.latest is not None
        assert log2.latest.revision_id == r2.revision_id
        names = sorted(b.name for b in log2.list_branches())
        assert "main" in names and "shadow" in names
        # main's head is still r1 after reload.
        main_head = log2.head_of("main")
        assert main_head.revision_id == r1.revision_id

    def test_rehydrate_ff_merge_restores_dst_head(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        log = RevisionLog(path=p)
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        log.checkout_branch("shadow")
        r2 = _rev("h2", "n2", invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r2)
        result = log.merge_branch("shadow", "main", reviewer="jme")
        assert isinstance(result, Branch)
        # Reload and confirm main's head still = r2.
        log2 = RevisionLog.load(p)
        assert log2.head_of("main").revision_id == r2.revision_id

    def test_v06x_log_without_branch_records_loads_cleanly(self, tmp_path) -> None:
        """Backward-compat: a jsonl produced by v0.6.x has no _record_type
        lines and no `branch` field. We should still load it and default
        to main."""
        p = tmp_path / "rev.jsonl"
        # Simulate v0.6.x: a plain revision dict with NO branch key.
        # (to_dict now emits "branch" but we write a legacy shape here.)
        legacy = {
            "revision_id": "cfg:n1",
            "invariants": [{"class_name": "MaxPerCall",
                            "repr": {"max_amount": "10", "currency": "USDC"}}],
            "proof_backend": "python-pattern",
            "proof_strength": "pattern",
            "prover_mode": "compat",
            "compile_hash": None,
            "fragment_version": None,
            "tau_backend_version": None,
            "admitted_at_unix": 1_713_000_000,
            "predecessor_revision_id": None,
        }
        p.write_text(json.dumps(legacy) + "\n")
        log = RevisionLog.load(p)
        assert len(log) == 1
        assert log.active_branch == "main"
        assert log.latest is not None
        assert log.latest.branch == "main"
        # And main is listed as a branch.
        names = [b.name for b in log.list_branches()]
        assert "main" in names


# ── daemon op surface ────────────────────────────────────────────────────────


class TestDaemonBranchOps:
    def test_current_branch_defaults_to_main(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        r = _send(sock, {"op": "current_branch"})
        assert r["verdict"] == "ok"
        assert r["active_branch"] == "main"
        assert r["head_revision_id"] is None   # fresh log

    def test_create_and_list_branches_via_daemon(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        r = _send(sock, {"op": "create_branch", "name": "shadow", "created_by": "jme"})
        assert r["verdict"] == "ok"
        assert r["branch"]["name"] == "shadow"
        # list_branches sees both
        r2 = _send(sock, {"op": "list_branches"})
        assert r2["verdict"] == "ok"
        names = [b["name"] for b in r2["branches"]]
        assert "main" in names and "shadow" in names

    def test_checkout_then_mutations_go_to_shadow(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        # Admit a revision on main.
        r0 = _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        main_rev = r0["revision_id"]
        # Branch off main.
        _send(sock, {"op": "create_branch", "name": "shadow"})
        _send(sock, {"op": "checkout_branch", "name": "shadow"})
        assert _send(sock, {"op": "current_branch"})["active_branch"] == "shadow"
        # Mutation on shadow.
        r1 = _send(sock, {
            "op": "declare_x402",
            "kind": "retry_rate_limit",
            "min_gap_seconds": 5,
        })
        assert r1["verdict"] == "updated"
        # current_branch's head is now the shadow revision, not the main one.
        cb = _send(sock, {"op": "current_branch"})
        assert cb["head_revision_id"] == r1["revision_id"]
        assert r1["revision_id"] != main_rev
        # Switching back to main restores the main head (and the main
        # invariant set -- shadow's retry_rate_limit is no longer active).
        _send(sock, {"op": "checkout_branch", "name": "main"})
        active = _send(sock, {"op": "active_x402"})
        assert "MaxPerCall" in active["kinds"]
        assert "RetryRateLimit" not in active["kinds"]

    def test_merge_branch_ff_via_daemon(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "create_branch", "name": "shadow"})
        _send(sock, {"op": "checkout_branch", "name": "shadow"})
        _send(sock, {"op": "declare_x402", "kind": "retry_rate_limit",
                     "min_gap_seconds": 5})
        r = _send(sock, {"op": "merge_branch",
                         "src": "shadow", "dst": "main", "reviewer": "jme"})
        assert r["verdict"] == "merged"
        assert r["branch"]["name"] == "main"
        # Switch to main and confirm the merged invariants are live.
        _send(sock, {"op": "checkout_branch", "name": "main"})
        active = _send(sock, {"op": "active_x402"})
        assert sorted(active["kinds"]) == ["MaxPerCall", "RetryRateLimit"]

    def test_merge_branch_non_ff_overlapping_returns_conflict(self, daemon_sock) -> None:
        """v0.8.0 semantics: non-FF merges with OVERLAPPING class touches
        still conflict. The disjoint-deltas fast path is covered in
        ``tests/test_three_way_merge.py``.

        This was `test_merge_branch_non_ff_returns_conflict` in v0.7.0;
        rewritten so both sides modify the same invariant class
        (MaxPerCall) and the merge must still conflict.
        """
        sock, _, _ = daemon_sock
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "create_branch", "name": "shadow"})
        # diverge main: retract MaxPerCall and re-declare tighter.
        _send(sock, {"op": "retract_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "40"})
        # diverge shadow: retract MaxPerCall and re-declare with a DIFFERENT value.
        _send(sock, {"op": "checkout_branch", "name": "shadow"})
        _send(sock, {"op": "retract_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "30"})
        r = _send(sock, {"op": "merge_branch",
                         "src": "shadow", "dst": "main", "reviewer": "jme"})
        assert r["verdict"] == "conflict"
        assert r["merge_kind"] == "conflict"
        assert r["src"] == "shadow"
        assert r["dst"] == "main"
        assert r["common_ancestor"] is not None
        # Both sides touched MaxPerCall (add + remove), so conflict.
        assert r["src_delta"]["added"] or r["src_delta"]["removed"]
        assert r["dst_delta"]["added"] or r["dst_delta"]["removed"]
        conflicting_classes = [c["class_name"] for c in r["conflicting_invariants"]]
        assert "MaxPerCall" in conflicting_classes

    def test_rehydrate_roundtrip_via_daemon(self, tmp_path) -> None:
        """Bring up a daemon, mutate across branches, bring it down, bring
        it back up, and verify state."""
        log_path = tmp_path / "revs.jsonl"
        fd, sock1 = tempfile.mkstemp(prefix="brn-rh-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(sock1)

        d1 = CageDaemon(socket_path=sock1, revision_log_path=log_path)
        t1 = threading.Thread(target=d1.serve_forever, daemon=True)
        t1.start()
        for _ in range(50):
            if os.path.exists(sock1):
                break
            time.sleep(0.01)
        try:
            _send(sock1, {"op": "declare_x402", "kind": "max_per_call",
                          "max_amount": "50"})
            _send(sock1, {"op": "create_branch", "name": "shadow"})
            _send(sock1, {"op": "checkout_branch", "name": "shadow"})
            _send(sock1, {"op": "declare_x402", "kind": "retry_rate_limit",
                          "min_gap_seconds": 5})
        finally:
            d1.shutdown()
            t1.join(timeout=1.0)

        # Reopen with a new socket but the same log path.
        fd, sock2 = tempfile.mkstemp(prefix="brn-rh2-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(sock2)
        d2 = CageDaemon(socket_path=sock2, revision_log_path=log_path)
        t2 = threading.Thread(target=d2.serve_forever, daemon=True)
        t2.start()
        for _ in range(50):
            if os.path.exists(sock2):
                break
            time.sleep(0.01)
        try:
            cb = _send(sock2, {"op": "current_branch"})
            assert cb["active_branch"] == "shadow"
            lb = _send(sock2, {"op": "list_branches"})
            names = [b["name"] for b in lb["branches"]]
            assert "main" in names and "shadow" in names
            # The shadow head is the retry_rate_limit revision; the live
            # registry should reflect both invariants (MaxPerCall from the
            # branch-point plus RetryRateLimit added on shadow).
            active = _send(sock2, {"op": "active_x402"})
            assert sorted(active["kinds"]) == ["MaxPerCall", "RetryRateLimit"]
        finally:
            d2.shutdown()
            t2.join(timeout=1.0)

    def test_create_branch_bad_payload(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        r = _send(sock, {"op": "create_branch"})
        assert r["verdict"] == "error"
        assert r["category"] == "bad_payload"

    def test_merge_branch_requires_reviewer(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "create_branch", "name": "shadow"})
        r = _send(sock, {"op": "merge_branch", "src": "shadow", "dst": "main"})
        assert r["verdict"] == "error"
        assert r["category"] == "bad_payload"

    def test_checkout_unknown_branch_via_daemon(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        r = _send(sock, {"op": "checkout_branch", "name": "nope"})
        assert r["verdict"] == "error"
        assert r["category"] == "branch_error"


# ── CLI parser wiring ───────────────────────────────────────────────────────


class TestCliBranchParser:
    """Verify the `branch` subcommand parses the documented shapes.

    Subprocess execution of daemon.cli is covered elsewhere; here we just
    confirm argparse accepts every shape we care about.
    """

    def test_branch_list_parses(self) -> None:
        from daemon.cli import _build_parser
        args = _build_parser().parse_args(["branch", "list"])
        assert args.subcommand == "branch"
        assert args.branch_action == "list"

    def test_branch_create_parses_with_from_flag(self) -> None:
        from daemon.cli import _build_parser
        args = _build_parser().parse_args(
            ["branch", "create", "shadow", "--from", "cfg:n1", "--created-by", "jme"]
        )
        assert args.branch_action == "create"
        assert args.name == "shadow"
        assert args.from_revision == "cfg:n1"
        assert args.created_by == "jme"

    def test_branch_checkout_parses(self) -> None:
        from daemon.cli import _build_parser
        args = _build_parser().parse_args(["branch", "checkout", "shadow"])
        assert args.branch_action == "checkout"
        assert args.name == "shadow"

    def test_branch_merge_parses(self) -> None:
        from daemon.cli import _build_parser
        args = _build_parser().parse_args(
            ["branch", "merge", "shadow", "--into", "main", "--reviewer", "jme"]
        )
        assert args.branch_action == "merge"
        assert args.src == "shadow"
        assert args.into == "main"
        assert args.reviewer == "jme"

    def test_branch_merge_requires_reviewer(self) -> None:
        from daemon.cli import _build_parser
        with pytest.raises(SystemExit):
            _build_parser().parse_args(
                ["branch", "merge", "shadow", "--into", "main"]
            )
