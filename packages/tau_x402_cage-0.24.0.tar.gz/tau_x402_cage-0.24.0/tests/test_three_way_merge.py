"""Tests for three-way merge of branching revisions (v0.8.0).

Covers the new v0.8.0 strategy ladder over v0.7.0's FF-only merge:

  1. Fast-forward case stays on the fast path (merge_kind=fast-forward).
  2. Non-FF + disjoint deltas: automatic 3-way merge commit
     (merge_kind=three-way, merge_parent_ids populated).
  3. Non-FF + overlapping deltas: structured conflict with a populated
     ``conflicting_invariants`` list.
  4. Persistence round-trip of three-way merge records (merge + merge
     commit revision both reload cleanly).
  5. ``branch_ancestor`` honours the DAG: after a three-way merge, the
     merge commit's ancestors include BOTH parents.
  6. Backward-compat: v0.7.0-style FF-only merge records (no ``merge_kind``,
     no ``merged_revision_id``, no ``merge_parent_ids``) still load.
"""
from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Iterator

import pytest

from adapter.invariants import (
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.policy_revision import (
    Branch,
    BranchMergeConflict,
    PolicyRevision,
    RevisionLog,
    _find_conflicting_invariants,
)
from adapter.prover import ProofToken
from daemon.server import CageDaemon


# ── helpers ──────────────────────────────────────────────────────────────────


def _token(config_hash: str, nonce: str, predecessor: str | None = None) -> ProofToken:
    return ProofToken(
        config_hash=config_hash,
        issued_at_unix=1_713_000_000,
        backend="python-pattern",
        proof_strength="pattern",
        nonce=nonce,
        predecessor_hash=predecessor,
        prover_mode="compat",
        fragment_version=None,
        compile_hash=None,
        tau_backend_version=None,
    )


def _rev(
    cfg: str,
    nonce: str,
    invariants: tuple,
    predecessor: str | None = None,
    branch: str = "main",
    depth: int = 0,
) -> PolicyRevision:
    from dataclasses import replace
    base = PolicyRevision.from_proof_token(
        token=_token(cfg, nonce, predecessor),
        invariants=invariants,
        predecessor_revision_id=predecessor,
    )
    return replace(base, branch=branch, revision_depth=depth)


def _send(path: str, req: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


@pytest.fixture
def daemon_sock(tmp_path) -> Iterator[tuple[str, Path, CageDaemon]]:
    fd, sock = tempfile.mkstemp(prefix="3way-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(sock)
    log_path = tmp_path / "revs.jsonl"
    d = CageDaemon(socket_path=sock, revision_log_path=log_path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(200):
        if os.path.exists(sock):
            try:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.settimeout(0.1)
                s.connect(sock)
                s.close()
                break
            except (ConnectionRefusedError, OSError):
                pass
        time.sleep(0.02)
    try:
        yield sock, log_path, d
    finally:
        d.shutdown()
        t.join(timeout=1.0)


# ── unit: conflict detection helper ──────────────────────────────────────────


class TestFindConflictingInvariants:
    def test_disjoint_classes_no_conflict(self) -> None:
        src_delta = {
            "added": [{"class_name": "RetryRateLimit", "repr": {"min_gap_seconds": 5}}],
            "removed": [],
        }
        dst_delta = {
            "added": [{"class_name": "ProviderAllowlist", "repr": {"providers": ["a"]}}],
            "removed": [],
        }
        assert _find_conflicting_invariants(src_delta, dst_delta) == []

    def test_same_class_added_both_sides_is_conflict_when_different(self) -> None:
        src_delta = {
            "added": [{"class_name": "MaxPerCall",
                       "repr": {"max_amount": "10", "currency": "USDC"}}],
            "removed": [],
        }
        dst_delta = {
            "added": [{"class_name": "MaxPerCall",
                       "repr": {"max_amount": "20", "currency": "USDC"}}],
            "removed": [],
        }
        conflicts = _find_conflicting_invariants(src_delta, dst_delta)
        assert len(conflicts) == 1
        assert conflicts[0]["class_name"] == "MaxPerCall"
        assert conflicts[0]["src_ops"] == ["added"]
        assert conflicts[0]["dst_ops"] == ["added"]

    def test_same_class_added_identical_is_not_conflict(self) -> None:
        """Idempotent add: both sides added the same invariant. Safe to merge."""
        shared = {"class_name": "RetryRateLimit", "repr": {"min_gap_seconds": 5}}
        src_delta = {"added": [shared], "removed": []}
        dst_delta = {"added": [shared], "removed": []}
        assert _find_conflicting_invariants(src_delta, dst_delta) == []

    def test_removed_on_one_added_on_other_is_conflict(self) -> None:
        src_delta = {
            "added": [],
            "removed": [{"class_name": "MaxPerCall",
                         "repr": {"max_amount": "10", "currency": "USDC"}}],
        }
        dst_delta = {
            "added": [{"class_name": "MaxPerCall",
                       "repr": {"max_amount": "20", "currency": "USDC"}}],
            "removed": [],
        }
        conflicts = _find_conflicting_invariants(src_delta, dst_delta)
        assert len(conflicts) == 1
        assert conflicts[0]["class_name"] == "MaxPerCall"
        assert "removed" in conflicts[0]["src_ops"]
        assert "added" in conflicts[0]["dst_ops"]


# ── library-level three-way merge ────────────────────────────────────────────


class TestThreeWayMergeDisjoint:
    """Branches that diverged on DIFFERENT invariant classes auto-merge."""

    def test_disjoint_deltas_produce_merge_commit(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        # Main adds ProviderAllowlist (new class).
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              ProviderAllowlist(providers=frozenset({"anthropic"}))),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        # Shadow adds RetryRateLimit (different new class).
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)

        result = log.merge_branch("shadow", "main", reviewer="ops")
        assert isinstance(result, Branch)
        assert result.name == "main"
        # Head of main is now the merge commit, not src_head.
        head = log.head_of("main")
        assert head is not None
        assert head.merge_parent_ids is not None
        assert head.merge_parent_ids == (r2.revision_id, r3.revision_id)
        # The merge commit's invariants contain BOTH added rules + the shared MaxPerCall.
        class_names = sorted(type(i).__name__ for i in head.invariants)
        assert class_names == ["MaxPerCall", "ProviderAllowlist", "RetryRateLimit"]

    def test_merge_commit_predecessor_is_dst_head(self) -> None:
        """The merge commit's linear predecessor remains dst's pre-merge head,
        so code that only reads ``predecessor_revision_id`` still sees a
        valid chain back to the common ancestor."""
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              ProviderAllowlist(providers=frozenset({"a"}))),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        log.merge_branch("shadow", "main", reviewer="ops")
        head = log.head_of("main")
        assert head is not None
        assert head.predecessor_revision_id == r2.revision_id
        assert head.branch == "main"

    def test_merge_commit_delta_equals_src_delta(self) -> None:
        """A merge commit's own delta (vs its linear predecessor, i.e. dst's
        pre-merge head) should be exactly what src contributed on top of the
        ancestor. This keeps diff_revisions rendering consistent."""
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              ProviderAllowlist(providers=frozenset({"a"}))),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        log.merge_branch("shadow", "main", reviewer="ops")
        head = log.head_of("main")
        added_classes = sorted(e["class_name"] for e in head.delta.get("added", []))
        assert added_classes == ["RetryRateLimit"]
        assert head.delta.get("removed", []) == []


class TestThreeWayMergeOverlapping:
    """Branches that touched the same invariant class must still conflict."""

    def test_both_sides_added_same_class_with_different_values_conflicts(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=())
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        result = log.merge_branch("shadow", "main", reviewer="ops")
        assert isinstance(result, BranchMergeConflict)
        assert result.conflicting_invariants
        classes = [c["class_name"] for c in result.conflicting_invariants]
        assert "MaxPerCall" in classes
        # v0.14.0: classified_conflicts populated alongside legacy field.
        assert result.classified_conflicts
        categories = {c["category"] for c in result.classified_conflicts}
        # MaxPerCall is fragment v1, so 10 vs 20 is a semantic conflict.
        assert categories == {"semantic"}
        # dst head did not move.
        assert log.head_of("main").revision_id == r2.revision_id

    def test_conflict_retains_deltas_for_ui(self) -> None:
        """The conflict payload still carries both sides' deltas so
        reviewers can see what each branch attempted."""
        log = RevisionLog()
        r1 = _rev("h1", "n1",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        # Main: update MaxPerCall to 20.
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("20")),),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        # Shadow: update MaxPerCall to 30.
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("30")),),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        result = log.merge_branch("shadow", "main", reviewer="ops")
        assert isinstance(result, BranchMergeConflict)
        assert result.src_delta["added"]
        assert result.dst_delta["added"]
        assert result.src_delta["removed"]
        assert result.dst_delta["removed"]


class TestFastForwardStillFastPath:
    """v0.7.0 FF semantics unchanged."""

    def test_ff_merge_does_not_fabricate_merge_commit(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        log.checkout_branch("shadow")
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r2)
        count_before = len(log.revisions)
        result = log.merge_branch("shadow", "main", reviewer="ops")
        assert isinstance(result, Branch)
        # FF advances the head pointer to an EXISTING revision — no new revision appended.
        assert len(log.revisions) == count_before
        head = log.head_of("main")
        assert head is not None
        assert head.revision_id == r2.revision_id
        assert head.merge_parent_ids is None   # not a merge commit


# ── ancestry on the DAG ──────────────────────────────────────────────────────


class TestBranchAncestorMultiParent:
    def test_lca_across_merge_commit_still_works(self) -> None:
        """After a three-way merge, the merge commit has two parents.
        branch_ancestor between the merged branch and a further descendant
        still walks the DAG correctly."""
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              ProviderAllowlist(providers=frozenset({"a"}))),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        log.merge_branch("shadow", "main", reviewer="ops")
        # LCA(shadow, main) should be the src_head (r3) because main now
        # contains r3 via the merge commit.
        assert log.branch_ancestor("shadow", "main") == r3.revision_id

    def test_ancestors_of_merge_commit_include_both_parents(self) -> None:
        log = RevisionLog()
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              ProviderAllowlist(providers=frozenset({"a"}))),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        log.merge_branch("shadow", "main", reviewer="ops")
        merge_commit_id = log.head_of("main").revision_id
        anc = log._ancestors_of(merge_commit_id)
        assert r1.revision_id in anc
        assert r2.revision_id in anc
        assert r3.revision_id in anc


# ── persistence ──────────────────────────────────────────────────────────────


class TestThreeWayMergePersistence:
    def test_three_way_merge_roundtrips_via_jsonl(self, tmp_path) -> None:
        p = tmp_path / "rev.jsonl"
        log = RevisionLog(path=p)
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              ProviderAllowlist(providers=frozenset({"a"}))),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        result = log.merge_branch("shadow", "main", reviewer="ops")
        assert isinstance(result, Branch)
        merge_commit_id = result.head_revision_id
        assert merge_commit_id is not None

        # Reload from disk.
        log2 = RevisionLog.load(p)
        # Main's head should still be the merge commit.
        main_head = log2.head_of("main")
        assert main_head is not None
        assert main_head.revision_id == merge_commit_id
        assert main_head.merge_parent_ids == (r2.revision_id, r3.revision_id)
        # Ancestors walk still works after rehydration.
        anc = log2._ancestors_of(merge_commit_id)
        assert r2.revision_id in anc
        assert r3.revision_id in anc

    def test_merge_record_carries_extended_fields(self, tmp_path) -> None:
        """The v0.8.0 merge event row must include merge_kind,
        merged_revision_id, and merge_parent_ids on the three-way branch."""
        p = tmp_path / "rev.jsonl"
        log = RevisionLog(path=p)
        r1 = _rev("h1", "n1", invariants=(MaxPerCall(max_amount=Decimal("10")),))
        log.append(r1)
        log.create_branch("shadow", from_revision_id=r1.revision_id)
        r2 = _rev("h2", "n2",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              ProviderAllowlist(providers=frozenset({"a"}))),
                  predecessor=r1.revision_id, branch="main", depth=1)
        log.append(r2)
        log.checkout_branch("shadow")
        r3 = _rev("h3", "n3",
                  invariants=(MaxPerCall(max_amount=Decimal("10")),
                              RetryRateLimit(min_gap_seconds=5)),
                  predecessor=r1.revision_id, branch="shadow", depth=1)
        log.append(r3)
        log.merge_branch("shadow", "main", reviewer="ops")
        lines = p.read_text().splitlines()
        merge_lines = [json.loads(ln) for ln in lines
                       if json.loads(ln).get("_record_type") == "merge"]
        assert merge_lines
        mr = merge_lines[-1]
        assert mr["merge_kind"] == "three-way"
        assert "merged_revision_id" in mr
        assert mr["merge_parent_ids"] == [r2.revision_id, r3.revision_id]

    def test_v07_ff_only_merge_records_still_load(self, tmp_path) -> None:
        """A jsonl written by v0.7.0 has merge records with only
        `_record_type`, `src`, `dst`, `reviewer`, `new_head_revision_id`
        (no merge_kind, no merged_revision_id, no merge_parent_ids).
        v0.8.0 must still rehydrate such a log.
        """
        p = tmp_path / "legacy.jsonl"
        # Minimal v0.7.0 log: two revisions on main, one branch record,
        # one legacy FF merge record.
        legacy_lines = [
            # r1 on main
            {
                "revision_id": "cfg:n1",
                "invariants": [{"class_name": "MaxPerCall",
                                "repr": {"max_amount": "10", "currency": "USDC"}}],
                "proof_backend": "python-pattern",
                "proof_strength": "pattern",
                "prover_mode": "compat",
                "compile_hash": None,
                "fragment_version": None,
                "tau_backend_version": None,
                "admitted_at_unix": 1_713_000_000,
                "predecessor_revision_id": None,
                "delta": {},
                "revision_depth": 0,
                "branch": "main",
            },
            # shadow branch record
            {"_record_type": "branch", "name": "shadow",
             "head_revision_id": "cfg:n1", "created_at": 1_713_000_001,
             "created_by": "jme"},
            # r2 on shadow
            {
                "revision_id": "cfg:n2",
                "invariants": [{"class_name": "MaxPerCall",
                                "repr": {"max_amount": "10", "currency": "USDC"}},
                               {"class_name": "RetryRateLimit",
                                "repr": {"min_gap_seconds": 5}}],
                "proof_backend": "python-pattern",
                "proof_strength": "pattern",
                "prover_mode": "compat",
                "compile_hash": None,
                "fragment_version": None,
                "tau_backend_version": None,
                "admitted_at_unix": 1_713_000_002,
                "predecessor_revision_id": "cfg:n1",
                "delta": {"added": [{"class_name": "RetryRateLimit",
                                     "repr": {"min_gap_seconds": 5}}],
                          "removed": []},
                "revision_depth": 1,
                "branch": "shadow",
            },
            # v0.7.0-shape merge record (no merge_kind field)
            {"_record_type": "merge", "src": "shadow", "dst": "main",
             "reviewer": "jme", "new_head_revision_id": "cfg:n2"},
        ]
        with p.open("w", encoding="utf-8") as f:
            for rec in legacy_lines:
                f.write(json.dumps(rec, sort_keys=True) + "\n")

        log = RevisionLog.load(p)
        # main's head is the merged revision (FF).
        assert log.head_of("main").revision_id == "cfg:n2"
        # And that revision has no merge_parent_ids (linear FF).
        assert log.head_of("main").merge_parent_ids is None


# ── daemon op surface ───────────────────────────────────────────────────────


class TestDaemonThreeWayMerge:
    def test_daemon_ff_merge_carries_merge_kind_field(self, daemon_sock) -> None:
        sock, _, _ = daemon_sock
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "create_branch", "name": "shadow"})
        _send(sock, {"op": "checkout_branch", "name": "shadow"})
        _send(sock, {"op": "declare_x402", "kind": "retry_rate_limit",
                     "min_gap_seconds": 5})
        r = _send(sock, {"op": "merge_branch",
                         "src": "shadow", "dst": "main", "reviewer": "ops"})
        assert r["verdict"] == "merged"
        assert r["merge_kind"] == "fast-forward"
        # No merge commit fabricated -> no merged_revision_id on FF.
        assert "merged_revision_id" not in r

    def test_daemon_three_way_merge_succeeds_with_disjoint_deltas(
        self, daemon_sock
    ) -> None:
        sock, _, _ = daemon_sock
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "create_branch", "name": "shadow"})
        # main adds ProviderAllowlist
        _send(sock, {"op": "declare_x402", "kind": "provider_allowlist",
                     "providers": ["anthropic"]})
        # shadow adds RetryRateLimit
        _send(sock, {"op": "checkout_branch", "name": "shadow"})
        _send(sock, {"op": "declare_x402", "kind": "retry_rate_limit",
                     "min_gap_seconds": 5})
        r = _send(sock, {"op": "merge_branch",
                         "src": "shadow", "dst": "main", "reviewer": "ops"})
        assert r["verdict"] == "merged"
        assert r["merge_kind"] == "three-way"
        assert r["merged_revision_id"]
        assert isinstance(r["merge_parent_ids"], list)
        assert len(r["merge_parent_ids"]) == 2
        # Switch to main and confirm all three classes are now live.
        _send(sock, {"op": "checkout_branch", "name": "main"})
        active = _send(sock, {"op": "active_x402"})
        assert sorted(active["kinds"]) == sorted(
            ["MaxPerCall", "ProviderAllowlist", "RetryRateLimit"]
        )

    def test_daemon_three_way_merge_roundtrips_across_daemon_restart(
        self, tmp_path
    ) -> None:
        """Spin up daemon, do a three-way merge, bring it down, bring it
        back up, and confirm the state is intact."""
        log_path = tmp_path / "revs.jsonl"
        fd, sock1 = tempfile.mkstemp(prefix="3way-rh-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(sock1)

        d1 = CageDaemon(socket_path=sock1, revision_log_path=log_path)
        t1 = threading.Thread(target=d1.serve_forever, daemon=True)
        t1.start()
        # Wait for the socket to become connectable (existence alone is
        # insufficient on loaded machines -- accept() must be ready too).
        for _ in range(200):
            if os.path.exists(sock1):
                try:
                    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    s.settimeout(0.1)
                    s.connect(sock1)
                    s.close()
                    break
                except (ConnectionRefusedError, OSError):
                    pass
            time.sleep(0.02)
        merged_revision_id = None
        try:
            _send(sock1, {"op": "declare_x402", "kind": "max_per_call",
                          "max_amount": "50"})
            _send(sock1, {"op": "create_branch", "name": "shadow"})
            _send(sock1, {"op": "declare_x402", "kind": "provider_allowlist",
                          "providers": ["anthropic"]})
            _send(sock1, {"op": "checkout_branch", "name": "shadow"})
            _send(sock1, {"op": "declare_x402", "kind": "retry_rate_limit",
                          "min_gap_seconds": 5})
            r = _send(sock1, {"op": "merge_branch",
                              "src": "shadow", "dst": "main", "reviewer": "ops"})
            assert r["merge_kind"] == "three-way"
            merged_revision_id = r["merged_revision_id"]
        finally:
            d1.shutdown()
            t1.join(timeout=1.0)

        fd, sock2 = tempfile.mkstemp(prefix="3way-rh2-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(sock2)
        d2 = CageDaemon(socket_path=sock2, revision_log_path=log_path)
        t2 = threading.Thread(target=d2.serve_forever, daemon=True)
        t2.start()
        for _ in range(200):
            if os.path.exists(sock2):
                try:
                    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    s.settimeout(0.1)
                    s.connect(sock2)
                    s.close()
                    break
                except (ConnectionRefusedError, OSError):
                    pass
            time.sleep(0.02)
        try:
            _send(sock2, {"op": "checkout_branch", "name": "main"})
            cb = _send(sock2, {"op": "current_branch"})
            assert cb["active_branch"] == "main"
            # Main's head should be the merge commit we computed earlier.
            assert cb["head_revision_id"] == merged_revision_id
            active = _send(sock2, {"op": "active_x402"})
            assert sorted(active["kinds"]) == sorted(
                ["MaxPerCall", "ProviderAllowlist", "RetryRateLimit"]
            )
        finally:
            d2.shutdown()
            t2.join(timeout=1.0)

    def test_daemon_overlapping_merge_returns_conflict_with_details(
        self, daemon_sock
    ) -> None:
        sock, _, _ = daemon_sock
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "create_branch", "name": "shadow"})
        # main: retract + re-declare (same class)
        _send(sock, {"op": "retract_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "40"})
        # shadow: retract + re-declare with a DIFFERENT value
        _send(sock, {"op": "checkout_branch", "name": "shadow"})
        _send(sock, {"op": "retract_x402", "kind": "max_per_call", "max_amount": "50"})
        _send(sock, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "30"})
        r = _send(sock, {"op": "merge_branch",
                         "src": "shadow", "dst": "main", "reviewer": "ops"})
        assert r["verdict"] == "conflict"
        assert r["merge_kind"] == "conflict"
        assert r["conflicting_invariants"]
        classes = [c["class_name"] for c in r["conflicting_invariants"]]
        assert "MaxPerCall" in classes
