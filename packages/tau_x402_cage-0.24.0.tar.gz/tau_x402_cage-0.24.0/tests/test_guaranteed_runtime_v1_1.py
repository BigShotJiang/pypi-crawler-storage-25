"""Acceptance tests for Guaranteed Runtime v1.1.0 widened feature set.

v1.1.0 adds three features to ``GUARANTEED_RUNTIME_FEATURES``:

  * ``window_cap``          -> SpendingCap(per_window / per_provider_per_window)
  * ``rolling_window_cap``  -> RollingWindowCap
  * ``burst_velocity_cap``  -> BurstVelocityCap

The runtime wraps the existing ``runtime_guard`` + per-invariant
``check_payment`` logic. Decision discipline (fail-closed, proof-artifact
bound, feature-set gate) is identical to v1.0.0; these tests confirm
the widened set dispatches cleanly and that the v0.19.0 invariants
still hold.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

import pytest

from adapter.guaranteed_runtime import (
    GUARANTEED_RUNTIME_FEATURES,
    GuaranteedDecision,
    guaranteed_should_pay_x402,
)


# ── test doubles ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class _FakePolicyRevision:
    id: str


@dataclass(frozen=True)
class _FakeProofArtifact:
    artifact_id: str
    policy_revision_id: str
    proof_result: str  # "consistent" | "inconsistent" | "inconclusive"
    artifact_hash: str = ""


@dataclass
class _FakeIntent:
    """Intent double for runtime tests.

    When ``_raise`` is set the evaluator raises — the caller wraps into
    ``RUNTIME_EVALUATION_UNAVAILABLE``. Otherwise the evaluator is a
    no-op (same discipline as the v0.19.0 test suite).
    """

    runtime_feature: str
    _raise: Optional[BaseException] = None

    def evaluate_guaranteed(
        self,
        *,
        feature: str,
        policy_revision: Any,
        guard_state: Any,
    ) -> None:
        if self._raise is not None:
            raise self._raise


def _happy_inputs(feature: str, guard_state: Optional[dict] = None) -> dict:
    return {
        "intent": _FakeIntent(runtime_feature=feature),
        "policy_revision": _FakePolicyRevision(id="rev-v1-1"),
        "proof_artifact": _FakeProofArtifact(
            artifact_id="artifact-v1-1",
            policy_revision_id="rev-v1-1",
            proof_result="consistent",
            artifact_hash="abcd1234" * 4,
        ),
        "guard_state": guard_state or {"window_used": 0, "window_cap": 100},
    }


# ── feature set contract (v1.1.0) ──────────────────────────────────────


def test_v1_1_feature_set_contains_all_six_features():
    assert GUARANTEED_RUNTIME_FEATURES == frozenset(
        {
            "spend_cap",
            "burst_throttle",
            "retry_cooldown",
            "window_cap",
            "rolling_window_cap",
            "burst_velocity_cap",
        }
    )


def test_v1_1_feature_set_is_frozenset():
    assert isinstance(GUARANTEED_RUNTIME_FEATURES, frozenset)


# ── happy-path admission for each new feature ─────────────────────────


def test_window_cap_admits_under_headroom():
    """SpendingCap(per_window) with room in the cap passes runtime."""
    decision = guaranteed_should_pay_x402(
        **_happy_inputs("window_cap", {"window_used": 40, "window_cap": 100})
    )
    assert decision.allow is True
    assert decision.reason is None
    assert "admitted" in decision.explanation


def test_rolling_window_cap_admits_under_headroom():
    decision = guaranteed_should_pay_x402(
        **_happy_inputs("rolling_window_cap", {"count": 2, "max_count": 10})
    )
    assert decision.allow is True
    assert decision.reason is None


def test_burst_velocity_cap_admits_under_headroom():
    decision = guaranteed_should_pay_x402(
        **_happy_inputs(
            "burst_velocity_cap",
            {"burst_sum": 10, "max_per_window": 100},
        )
    )
    assert decision.allow is True


# ── block paths: evaluator raises when a cap would cross ──────────────


def test_window_cap_blocks_when_evaluator_signals_cap_crossing():
    """If the underlying guard flags a cap cross, the evaluator raises
    and the cage fail-closes with ``RUNTIME_EVALUATION_UNAVAILABLE``.

    The runtime dispatch deliberately treats any evaluator exception
    as a fail-closed deny — Guaranteed Mode never allows on error.
    """
    inputs = _happy_inputs("window_cap")
    inputs["intent"] = _FakeIntent(
        runtime_feature="window_cap",
        _raise=RuntimeError("window cap would cross"),
    )
    decision = guaranteed_should_pay_x402(**inputs)
    assert decision.allow is False
    assert decision.reason == "RUNTIME_EVALUATION_UNAVAILABLE"


def test_rolling_window_cap_blocks_on_evaluator_violation():
    inputs = _happy_inputs("rolling_window_cap")
    inputs["intent"] = _FakeIntent(
        runtime_feature="rolling_window_cap",
        _raise=ValueError("rolling cap would cross"),
    )
    decision = guaranteed_should_pay_x402(**inputs)
    assert decision.allow is False
    assert decision.reason == "RUNTIME_EVALUATION_UNAVAILABLE"


def test_burst_velocity_cap_blocks_on_evaluator_violation():
    inputs = _happy_inputs("burst_velocity_cap")
    inputs["intent"] = _FakeIntent(
        runtime_feature="burst_velocity_cap",
        _raise=RuntimeError("burst velocity cap exceeded"),
    )
    decision = guaranteed_should_pay_x402(**inputs)
    assert decision.allow is False
    assert decision.reason == "RUNTIME_EVALUATION_UNAVAILABLE"


def test_retry_rate_limit_feature_still_blocks_on_violation_v1_1():
    """The existing ``retry_cooldown`` dispatch stays fail-closed."""
    inputs = _happy_inputs("retry_cooldown")
    inputs["intent"] = _FakeIntent(
        runtime_feature="retry_cooldown",
        _raise=RuntimeError("retry too soon"),
    )
    decision = guaranteed_should_pay_x402(**inputs)
    assert decision.allow is False
    assert decision.reason == "RUNTIME_EVALUATION_UNAVAILABLE"


# ── proof binding still enforced ───────────────────────────────────────


def test_preflight_mismatch_denies_on_new_feature():
    """Proof artifact bound to a different revision denies, even for a
    v1.1.0 feature."""
    inputs = _happy_inputs("window_cap")
    inputs["proof_artifact"] = _FakeProofArtifact(
        artifact_id="artifact-v1-1",
        policy_revision_id="rev-OTHER",
        proof_result="consistent",
        artifact_hash="bad",
    )
    decision = guaranteed_should_pay_x402(**inputs)
    assert decision.allow is False
    assert decision.reason == "RUNTIME_GUARD_VIOLATION"


def test_inconsistent_proof_denies_on_new_feature():
    inputs = _happy_inputs("rolling_window_cap")
    inputs["proof_artifact"] = _FakeProofArtifact(
        artifact_id="a",
        policy_revision_id="rev-v1-1",
        proof_result="inconsistent",
    )
    decision = guaranteed_should_pay_x402(**inputs)
    assert decision.allow is False
    assert decision.reason == "RUNTIME_GUARD_VIOLATION"


# ── out-of-set features still deny ─────────────────────────────────────


def test_adaptive_tightening_still_denies_v1_1():
    """adaptive_tightening is NOT added in v1.1.0."""
    inputs = _happy_inputs("adaptive_tightening")
    inputs["intent"] = _FakeIntent(runtime_feature="adaptive_tightening")
    decision = guaranteed_should_pay_x402(**inputs)
    assert decision.allow is False
    assert decision.reason == "RUNTIME_GUARD_VIOLATION"
    assert "adaptive_tightening" in decision.explanation


def test_unknown_feature_still_denies_v1_1():
    inputs = _happy_inputs("invented_feature_2030")
    inputs["intent"] = _FakeIntent(runtime_feature="invented_feature_2030")
    decision = guaranteed_should_pay_x402(**inputs)
    assert decision.allow is False
    assert decision.reason == "RUNTIME_GUARD_VIOLATION"


# ── envelope provenance survives widening ──────────────────────────────


def test_decision_envelope_includes_provenance_for_new_features():
    decision = guaranteed_should_pay_x402(**_happy_inputs("window_cap"))
    wire = decision.to_wire()
    assert wire["allow"] is True
    assert wire["policy_revision_id"] == "rev-v1-1"
    assert wire["proof_artifact_id"] == "artifact-v1-1"
    assert wire["proof_artifact_hash"]
    assert wire["runtime_guard_state_version"]
    assert isinstance(decision.decision_timestamp, datetime)
