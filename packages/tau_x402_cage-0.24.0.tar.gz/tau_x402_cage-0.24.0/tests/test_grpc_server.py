"""Tests for the gRPC surface.

Gate on ``importorskip("grpc")`` so the whole file is cleanly skipped in
Python environments that don't have grpcio installed. Contract parity is
the load-bearing test concern: every HTTP op has a gRPC method and the
two surfaces must return the same verdict for the same input.

The fixture spins a real :class:`daemon.server.CageDaemon` in a thread
(short /tmp/<n>.sock path; macOS UDS path cap is ~104 chars) and wires both
the FastAPI TestClient and the gRPC server at it. That way we can compare
byte-for-byte envelopes across the two surfaces without mocking the daemon.
"""
from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from typing import Iterator, Tuple

import pytest

grpc = pytest.importorskip("grpc")
pytest.importorskip("google.protobuf")

from daemon.server import CageDaemon  # noqa: E402
from saas import grpc_pb2, grpc_pb2_grpc  # noqa: E402
from saas.grpc_server import (  # noqa: E402
    CageGrpcServer,
    CageServiceServicer,
    GrpcServerConfig,
    _BearerAuthInterceptor,
    _envelope_to_response,
    _request_to_http_shape,
)


# ── shared constants ────────────────────────────────────────────────────────

SECRET_HEX = "a" * 64  # 32 bytes of 0xaa
SECRET = bytes.fromhex(SECRET_HEX)
API_KEYS = {"acme": "sk_test_acme_123"}
BEARER_TOKENS = tuple(API_KEYS.values())


# ── fixtures ────────────────────────────────────────────────────────────────


@pytest.fixture
def daemon_socket() -> Iterator[str]:
    """Spin up a CageDaemon + seed a max_per_call invariant."""
    fd, path = tempfile.mkstemp(prefix="grpc-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)

    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()

    # Wait for the daemon to start accepting connections. `os.path.exists`
    # is racy because the socket file exists before `accept()` is ready;
    # actually connect() until it succeeds.
    last_err: Exception | None = None
    for _ in range(200):
        if os.path.exists(path):
            try:
                probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                probe.settimeout(0.5)
                probe.connect(path)
                probe.close()
                break
            except (ConnectionRefusedError, FileNotFoundError) as exc:
                last_err = exc
        time.sleep(0.02)
    else:
        raise RuntimeError(f"daemon never came up at {path}: {last_err}")

    # Seed a max_per_call invariant so both permit and reject paths are testable.
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    s.sendall((json.dumps({
        "op": "declare_x402",
        "kind": "max_per_call",
        "max_amount": "100.00",
    }) + "\n").encode())
    s.recv(4096)
    s.close()
    try:
        yield path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


@pytest.fixture
def grpc_server(daemon_socket: str) -> Iterator[Tuple[CageGrpcServer, int]]:
    """Start a CageGrpcServer bound to an ephemeral port."""
    server = CageGrpcServer(
        daemon_socket=daemon_socket,
        bearer_tokens=BEARER_TOKENS,
        hmac_secret=SECRET,
        port=0,  # ephemeral
        host="127.0.0.1",
    )
    port = server.start()
    try:
        yield server, port
    finally:
        server.stop(grace=0.5)


@pytest.fixture
def grpc_channel(grpc_server: Tuple[CageGrpcServer, int]) -> Iterator[grpc.Channel]:
    _, port = grpc_server
    channel = grpc.insecure_channel(f"127.0.0.1:{port}")
    try:
        yield channel
    finally:
        channel.close()


@pytest.fixture
def grpc_stub(grpc_channel: grpc.Channel) -> grpc_pb2_grpc.CageServiceStub:
    return grpc_pb2_grpc.CageServiceStub(grpc_channel)


def _bearer() -> list[tuple[str, str]]:
    return [("authorization", f"Bearer {BEARER_TOKENS[0]}")]


# ── CheckPayment: parity + auth ─────────────────────────────────────────────


class TestCheckPayment:
    def test_permit_under_cap(self, grpc_stub: grpc_pb2_grpc.CageServiceStub) -> None:
        resp = grpc_stub.CheckPayment(
            grpc_pb2.CheckPaymentRequest(
                amount="50.00",
                currency="USDC",
                provider="anthropic",
                counterparty="vendor_x",
                timestamp=1_700_000_000,
            ),
            metadata=_bearer(),
        )
        assert resp.outcome == "permit"
        assert resp.intent_hash  # always set
        assert resp.mac_hex
        assert resp.ttl_seconds > 0

    def test_reject_over_cap(self, grpc_stub: grpc_pb2_grpc.CageServiceStub) -> None:
        resp = grpc_stub.CheckPayment(
            grpc_pb2.CheckPaymentRequest(
                amount="500.00",
                currency="USDC",
                provider="anthropic",
                counterparty="vendor_x",
                timestamp=1_700_000_000,
            ),
            metadata=_bearer(),
        )
        assert resp.outcome == "reject"
        assert resp.rule_id == "max_per_call"
        assert resp.reason_text  # TTI-critical field, must not be empty


class TestHttpParity:
    """Contract-parity: HTTP and gRPC return the same verdict for the same input.

    This is the load-bearing discipline for v0.11.0. We specifically compare
    the decision-relevant fields (outcome, rule_id, intent_hash) rather than
    the MAC — the MAC mixes in the signing timestamp, so two calls seconds
    apart produce different MACs even for the same intent. Intent-hash parity
    proves the daemon saw identical canonicalized intents from both surfaces.
    """

    def test_grpc_check_matches_http_verdict(
        self,
        daemon_socket: str,
        grpc_stub: grpc_pb2_grpc.CageServiceStub,
    ) -> None:
        try:
            from fastapi.testclient import TestClient
        except ImportError:
            pytest.skip("fastapi not installed")
        from saas.app import SaasConfig, create_app
        from saas.billing import NullBillingReporter

        cfg = SaasConfig(
            api_keys=dict(API_KEYS),
            socket_path=daemon_socket,
            hmac_secret=SECRET,
            billing=NullBillingReporter(),
        )
        http = TestClient(create_app(cfg))

        body = {
            "amount": "42.00",
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "vendor_x",
            "timestamp": 1_700_000_000,
        }
        http_resp = http.post(
            "/v1/check",
            headers={"Authorization": f"Bearer {BEARER_TOKENS[0]}"},
            json=body,
        )
        http_env = http_resp.json()

        grpc_resp = grpc_stub.CheckPayment(
            grpc_pb2.CheckPaymentRequest(
                amount="42.00",
                currency="USDC",
                provider="anthropic",
                counterparty="vendor_x",
                timestamp=1_700_000_000,
            ),
            metadata=_bearer(),
        )

        assert http_env["outcome"] == grpc_resp.outcome
        assert http_env["intent_hash"] == grpc_resp.intent_hash
        # rule_id is absent on permit envelopes; gRPC fills empty string.
        if http_env.get("rule_id"):
            assert http_env["rule_id"] == grpc_resp.rule_id
        assert http_env["ttl_seconds"] == grpc_resp.ttl_seconds

    def test_reject_parity(
        self,
        daemon_socket: str,
        grpc_stub: grpc_pb2_grpc.CageServiceStub,
    ) -> None:
        """Reject path parity: same input, same rule_id, same intent_hash."""
        try:
            from fastapi.testclient import TestClient
        except ImportError:
            pytest.skip("fastapi not installed")
        from saas.app import SaasConfig, create_app
        from saas.billing import NullBillingReporter

        cfg = SaasConfig(
            api_keys=dict(API_KEYS),
            socket_path=daemon_socket,
            hmac_secret=SECRET,
            billing=NullBillingReporter(),
        )
        http = TestClient(create_app(cfg))

        body = {
            "amount": "999.00",
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "vendor_x",
            "timestamp": 1_700_000_000,
        }
        http_resp = http.post(
            "/v1/check",
            headers={"Authorization": f"Bearer {BEARER_TOKENS[0]}"},
            json=body,
        )
        assert http_resp.status_code == 403
        http_env = http_resp.json()

        grpc_resp = grpc_stub.CheckPayment(
            grpc_pb2.CheckPaymentRequest(
                amount="999.00",
                currency="USDC",
                provider="anthropic",
                counterparty="vendor_x",
                timestamp=1_700_000_000,
            ),
            metadata=_bearer(),
        )
        assert http_env["outcome"] == grpc_resp.outcome == "reject"
        assert http_env["rule_id"] == grpc_resp.rule_id == "max_per_call"
        assert http_env["intent_hash"] == grpc_resp.intent_hash


class TestContractParityMatrix:
    """For each method exposed by gRPC, assert a matching HTTP/daemon response."""

    def test_every_grpc_method_has_http_or_daemon_counterpart(
        self,
        daemon_socket: str,
        grpc_stub: grpc_pb2_grpc.CageServiceStub,
    ) -> None:
        # Inspect the proto service; for every method, assert a counterpart
        # exists on the HTTP surface (CheckPayment → POST /v1/check,
        # Health → GET /v1/health) or the daemon (InspectPolicy →
        # inspect_policy op).
        service = grpc_pb2.DESCRIPTOR.services_by_name["CageService"]
        methods = {m.name for m in service.methods}
        expected = {"CheckPayment", "Health", "InspectPolicy"}
        assert methods == expected, f"proto methods drifted: {methods}"

        # CheckPayment: covered by TestHttpParity above.
        # Health: HTTP returns status=ok + version string; gRPC must do the same.
        try:
            from fastapi.testclient import TestClient
        except ImportError:
            pytest.skip("fastapi not installed")
        from saas.app import SaasConfig, create_app
        from saas.billing import NullBillingReporter

        cfg = SaasConfig(
            api_keys=dict(API_KEYS),
            socket_path=daemon_socket,
            hmac_secret=SECRET,
            billing=NullBillingReporter(),
        )
        http = TestClient(create_app(cfg))

        http_health = http.get("/v1/health").json()
        grpc_health = grpc_stub.Health(grpc_pb2.Empty())
        assert http_health["status"] == grpc_health.status == "ok"
        assert http_health["version"] == grpc_health.version

        # InspectPolicy: daemon op returns active_invariants + invariants list.
        # gRPC surface must expose the same shape.
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(daemon_socket)
        s.sendall(b'{"op":"inspect_policy"}\n')
        daemon_inspect = json.loads(s.makefile("r").readline())
        s.close()

        grpc_inspect = grpc_stub.InspectPolicy(
            grpc_pb2.Empty(),
            metadata=_bearer(),
        )
        assert grpc_inspect.active_invariants == daemon_inspect["active_invariants"]
        assert len(grpc_inspect.invariants) == len(daemon_inspect["invariants"])


# ── Health: same fields as /v1/health ───────────────────────────────────────


class TestHealth:
    def test_returns_ok_and_version(
        self, grpc_stub: grpc_pb2_grpc.CageServiceStub
    ) -> None:
        resp = grpc_stub.Health(grpc_pb2.Empty())
        assert resp.status == "ok"
        assert resp.version  # non-empty

    def test_health_requires_no_auth(
        self, grpc_stub: grpc_pb2_grpc.CageServiceStub
    ) -> None:
        # No bearer metadata at all.
        resp = grpc_stub.Health(grpc_pb2.Empty())
        assert resp.status == "ok"


# ── InspectPolicy: same fields as daemon inspect_policy op ──────────────────


class TestInspectPolicy:
    def test_returns_active_invariants(
        self,
        grpc_stub: grpc_pb2_grpc.CageServiceStub,
    ) -> None:
        resp = grpc_stub.InspectPolicy(grpc_pb2.Empty(), metadata=_bearer())
        assert resp.active_invariants == 1
        assert len(resp.invariants) == 1
        # The seeded invariant is MaxPerCall.
        assert "MaxPerCall" in resp.invariants[0].kind


# ── Auth: UNAUTHENTICATED on missing / wrong bearer ─────────────────────────


class TestAuth:
    def test_missing_bearer_is_unauthenticated(
        self, grpc_stub: grpc_pb2_grpc.CageServiceStub
    ) -> None:
        with pytest.raises(grpc.RpcError) as exc_info:
            grpc_stub.CheckPayment(
                grpc_pb2.CheckPaymentRequest(
                    amount="10",
                    provider="a",
                    counterparty="b",
                ),
            )
        assert exc_info.value.code() == grpc.StatusCode.UNAUTHENTICATED

    def test_wrong_bearer_is_unauthenticated(
        self, grpc_stub: grpc_pb2_grpc.CageServiceStub
    ) -> None:
        with pytest.raises(grpc.RpcError) as exc_info:
            grpc_stub.CheckPayment(
                grpc_pb2.CheckPaymentRequest(
                    amount="10",
                    provider="a",
                    counterparty="b",
                ),
                metadata=[("authorization", "Bearer nope")],
            )
        assert exc_info.value.code() == grpc.StatusCode.UNAUTHENTICATED

    def test_malformed_bearer_is_unauthenticated(
        self, grpc_stub: grpc_pb2_grpc.CageServiceStub
    ) -> None:
        with pytest.raises(grpc.RpcError) as exc_info:
            grpc_stub.CheckPayment(
                grpc_pb2.CheckPaymentRequest(amount="10"),
                metadata=[("authorization", "Basic something")],
            )
        assert exc_info.value.code() == grpc.StatusCode.UNAUTHENTICATED


# ── Deadlines / slow daemon ─────────────────────────────────────────────────


class TestDeadline:
    def test_deadline_exceeded_when_daemon_unreachable(self) -> None:
        """If the daemon socket doesn't exist, mediate() still returns a signed
        reject (fail-closed), so gRPC CheckPayment returns outcome=reject
        with rule_id=cage_unavailable rather than DEADLINE_EXCEEDED. That's
        correct behaviour per the fail-closed contract.

        For a true DEADLINE_EXCEEDED path, we rely on the client-side
        deadline. Here we exercise the gRPC deadline machinery directly
        against a server with a stale UDS path.
        """
        # Nonexistent socket path — daemon is not running here.
        server = CageGrpcServer(
            daemon_socket="/tmp/nonexistent-cage.sock",
            bearer_tokens=BEARER_TOKENS,
            hmac_secret=SECRET,
            port=0,
            host="127.0.0.1",
        )
        port = server.start()
        try:
            channel = grpc.insecure_channel(f"127.0.0.1:{port}")
            stub = grpc_pb2_grpc.CageServiceStub(channel)
            # Very tight deadline. mediate() is fast; we expect a signed
            # reject rather than a DEADLINE_EXCEEDED in this path.
            resp = stub.CheckPayment(
                grpc_pb2.CheckPaymentRequest(
                    amount="10",
                    provider="a",
                    counterparty="b",
                    timestamp=1_700_000_000,
                ),
                metadata=_bearer(),
                timeout=2.0,
            )
            assert resp.outcome == "reject"
            assert resp.rule_id == "cage_unavailable"
            channel.close()
        finally:
            server.stop(grace=0.5)


# ── Graceful shutdown: no orphan threads ────────────────────────────────────


class TestGracefulShutdown:
    def test_stop_joins_thread_pool(self, daemon_socket: str) -> None:
        server = CageGrpcServer(
            daemon_socket=daemon_socket,
            bearer_tokens=BEARER_TOKENS,
            hmac_secret=SECRET,
            port=0,
            host="127.0.0.1",
            max_workers=4,
        )
        before = set(threading.enumerate())
        server.start()
        server.stop(grace=0.5)
        # Give the executor a beat to finalize the threads.
        time.sleep(0.2)
        after = set(threading.enumerate())
        orphans = {t for t in after - before if t.is_alive() and "ThreadPoolExecutor" in t.name}
        assert not orphans, f"orphan executor threads after stop(): {orphans}"

    def test_stop_is_idempotent(self, daemon_socket: str) -> None:
        server = CageGrpcServer(
            daemon_socket=daemon_socket,
            bearer_tokens=BEARER_TOKENS,
            hmac_secret=SECRET,
            port=0,
            host="127.0.0.1",
        )
        server.start()
        server.stop(grace=0.2)
        # Second call must not raise.
        server.stop(grace=0.2)


# ── Proto schema round-trip ─────────────────────────────────────────────────


class TestProtoSchema:
    def test_proto_file_exists_and_imports_cleanly(self) -> None:
        """Load .proto → parse → compile → imports cleanly.

        The proto file ships in the repo at proto/tau_x402_cage.proto. The
        generated stubs are committed at saas/grpc_pb2.py + saas/grpc_pb2_grpc.py
        so pip-install users don't need protoc. This test proves both the
        source proto and the generated stubs stay in sync with the committed
        schema.
        """
        # Generated imports succeed (otherwise this test file wouldn't load).
        assert hasattr(grpc_pb2, "CheckPaymentRequest")
        assert hasattr(grpc_pb2, "CheckPaymentResponse")
        assert hasattr(grpc_pb2, "HealthResponse")
        assert hasattr(grpc_pb2, "InspectPolicyResponse")
        assert hasattr(grpc_pb2, "Empty")
        assert hasattr(grpc_pb2, "InvariantSummary")

        # Service descriptor has the three expected methods.
        service = grpc_pb2.DESCRIPTOR.services_by_name["CageService"]
        method_names = {m.name for m in service.methods}
        assert method_names == {"CheckPayment", "Health", "InspectPolicy"}

        # Package name is versioned for wire-stability.
        assert grpc_pb2.DESCRIPTOR.package == "tau.x402.cage.v1"

    def test_proto_source_file_exists(self) -> None:
        import pathlib
        repo_root = pathlib.Path(__file__).resolve().parent.parent
        proto_path = repo_root / "proto" / "tau_x402_cage.proto"
        assert proto_path.exists(), f"proto source missing: {proto_path}"
        content = proto_path.read_text(encoding="utf-8")
        assert 'package tau.x402.cage.v1;' in content
        assert "service CageService {" in content

    def test_request_round_trip_preserves_fields(self) -> None:
        req = grpc_pb2.CheckPaymentRequest(
            amount="1.23",
            currency="USDC",
            provider="a",
            counterparty="b",
            rail="x402",
            timestamp=1_700_000_000,
            request_id="req-42",
            metadata_json='{"foo":"bar"}',
        )
        wire = req.SerializeToString()
        parsed = grpc_pb2.CheckPaymentRequest.FromString(wire)
        assert parsed.amount == "1.23"
        assert parsed.currency == "USDC"
        assert parsed.provider == "a"
        assert parsed.counterparty == "b"
        assert parsed.rail == "x402"
        assert parsed.timestamp == 1_700_000_000
        assert parsed.request_id == "req-42"
        assert parsed.metadata_json == '{"foo":"bar"}'


# ── Translation helpers ─────────────────────────────────────────────────────


class TestTranslationHelpers:
    """Unit tests for the internal proto <-> HTTP-shape translation helpers.

    These are pure functions; covering them here gives the helpers
    independent coverage from the end-to-end tests above.
    """

    def test_request_to_http_shape_omits_unset_defaults(self) -> None:
        req = grpc_pb2.CheckPaymentRequest(amount="1.00")
        headers, body = _request_to_http_shape(req)
        parsed = json.loads(body)
        assert parsed == {"amount": "1.00"}
        assert headers["content-type"] == "application/json"

    def test_request_to_http_shape_preserves_metadata(self) -> None:
        req = grpc_pb2.CheckPaymentRequest(
            amount="1.00",
            provider="a",
            counterparty="b",
            metadata_json='{"tenant":"acme"}',
        )
        _, body = _request_to_http_shape(req)
        parsed = json.loads(body)
        assert parsed["metadata"] == {"tenant": "acme"}

    def test_request_to_http_shape_drops_malformed_metadata(self) -> None:
        req = grpc_pb2.CheckPaymentRequest(
            amount="1.00",
            metadata_json="{not valid json",
        )
        _, body = _request_to_http_shape(req)
        parsed = json.loads(body)
        assert "metadata" not in parsed

    def test_envelope_to_response_fills_none_fields_with_empty_string(self) -> None:
        from adapter.verdict_signer import SignedEnvelope

        env = SignedEnvelope(
            outcome="permit",
            rule_id=None,
            witness=None,
            reason_text=None,
            issued_at_unix=1_700_000_000,
            ttl_seconds=30,
            intent_hash="abc",
            mac_hex="def",
        )
        proto_resp = _envelope_to_response(env)
        assert proto_resp.outcome == "permit"
        assert proto_resp.rule_id == ""  # None → ""
        assert proto_resp.witness == ""
        assert proto_resp.reason_text == ""
        assert proto_resp.intent_hash == "abc"
        assert proto_resp.mac_hex == "def"


# ── Config loader ───────────────────────────────────────────────────────────


class TestGrpcServerConfig:
    def test_from_env_reads_api_keys_and_secret(self, monkeypatch) -> None:
        monkeypatch.setenv("TAU_X402_API_KEYS", json.dumps(API_KEYS))
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", SECRET_HEX)
        monkeypatch.setenv("TAU_X402_GRPC_PORT", "50099")
        cfg = GrpcServerConfig.from_env()
        assert cfg.bearer_tokens == tuple(API_KEYS.values())
        assert cfg.hmac_secret == SECRET
        assert cfg.port == 50099

    def test_from_env_rejects_short_secret(self, monkeypatch) -> None:
        monkeypatch.setenv("TAU_X402_API_KEYS", "{}")
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", "ab")  # 1 byte
        with pytest.raises(RuntimeError, match=">= 16 bytes"):
            GrpcServerConfig.from_env()

    def test_from_env_rejects_bad_api_keys_json(self, monkeypatch) -> None:
        monkeypatch.setenv("TAU_X402_API_KEYS", "not json")
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", SECRET_HEX)
        with pytest.raises(RuntimeError, match="JSON object"):
            GrpcServerConfig.from_env()

    def test_from_env_rejects_non_object_api_keys(self, monkeypatch) -> None:
        monkeypatch.setenv("TAU_X402_API_KEYS", '["not","object"]')
        monkeypatch.setenv("TAU_X402_HMAC_SECRET", SECRET_HEX)
        with pytest.raises(RuntimeError, match="must decode to an object"):
            GrpcServerConfig.from_env()


# ── Interceptor unit coverage ───────────────────────────────────────────────


class TestInterceptor:
    def test_health_bypasses_auth(self) -> None:
        interceptor = _BearerAuthInterceptor([])

        class FakeDetails:
            method = "/tau.x402.cage.v1.CageService/Health"
            invocation_metadata = ()

        def continuation(details):
            return "ok"

        result = interceptor.intercept_service(continuation, FakeDetails())
        assert result == "ok"

    def test_check_payment_requires_bearer(self) -> None:
        interceptor = _BearerAuthInterceptor(["sk_valid"])

        class FakeDetails:
            method = "/tau.x402.cage.v1.CageService/CheckPayment"
            invocation_metadata = ()

        def continuation(details):
            return "should not be called"

        handler = interceptor.intercept_service(continuation, FakeDetails())
        # Handler for unauth path is a unary_unary handler that aborts.
        # We assert it is the abort handler (not the pass-through result).
        assert handler is not "should not be called"  # noqa: F632 (identity check intentional)
        assert hasattr(handler, "unary_unary")
