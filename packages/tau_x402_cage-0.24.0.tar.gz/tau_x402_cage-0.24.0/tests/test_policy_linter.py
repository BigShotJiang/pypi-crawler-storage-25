"""Tests for the offline pre-declare policy linter (v0.10.0).

Linter contract (see :mod:`adapter.policy_linter`):
    * ``lint_policy_file(path)`` loads + lints, returning a
      ``LintReport`` with structured findings.
    * ``LintError`` is raised only for unrecoverable load failures
      (missing file, YAML parse error, unknown kind). Contradictions
      come back as findings, not exceptions.
    * CLI ``tau-x402-cage lint <policy.yaml>`` exits 0 / 1 / 2 on
      clean / errors / unloadable respectively.

We drive the linter through its public API end-to-end so the fixtures
double as examples of what a user's YAML would look like.
"""
from __future__ import annotations

import io
import json
import subprocess
import sys
import time
from pathlib import Path

import pytest

from adapter.policy_linter import (
    DEFAULT_UNROLL_STEPS,
    LintError,
    LintFinding,
    LintReport,
    lint_policy_file,
)


# ── helpers ──────────────────────────────────────────────────────────────────


def _write(tmp_path: Path, content: str, name: str = "policy.yaml") -> Path:
    """Write a YAML blob to a tmp file and return the resolved Path."""
    p = tmp_path / name
    p.write_text(content, encoding="utf-8")
    return p


def _codes(report: LintReport) -> list[str]:
    return [f.code for f in report.findings]


def _severities(report: LintReport) -> list[str]:
    return [f.severity for f in report.findings]


# ── valid policy: happy path ─────────────────────────────────────────────────


class TestValidPolicy:
    def test_v1_only_policy_emits_lint007_info(self, tmp_path: Path) -> None:
        """Fragment-v1-only policy → no errors, LINT007 info, decidable=True."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "50"
  - kind: provider_allowlist
    providers:
      - anthropic
      - openai
""")
        report = lint_policy_file(p)
        assert not report.has_errors()
        assert report.summary["errors"] == 0
        assert report.decidable is True
        assert report.fragment_breakdown["v1"] == 2
        assert report.fragment_breakdown["v2"] == 0
        assert report.fragment_breakdown["hybrid"] == 0
        assert "LINT007" in _codes(report)

    def test_v1_only_no_errors_or_warnings(self, tmp_path: Path) -> None:
        """Only info-level findings — CI should treat as green."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "50"
""")
        report = lint_policy_file(p)
        assert report.summary["errors"] == 0
        assert report.summary["warnings"] == 0


# ── LINT001 pattern-level contradiction ──────────────────────────────────────


class TestPatternContradiction:
    def test_approved_sanctioned_clash_across_rules_emits_lint001(
        self, tmp_path: Path
    ) -> None:
        """ID appears approved in one CounterpartyConstraint and sanctioned in another."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: counterparty_constraint
    approved_ids:
      - vendor_a
      - vendor_b
    sanctioned_ids: []
  - kind: counterparty_constraint
    approved_ids: []
    sanctioned_ids:
      - vendor_a
""")
        report = lint_policy_file(p)
        assert "LINT001" in _codes(report), report.to_text()
        # LINT001 is an error severity
        lint001 = [f for f in report.findings if f.code == "LINT001"][0]
        assert lint001.severity == "error"
        # Class names show up in `invariants`
        assert "CounterpartyConstraint" in lint001.invariants

    def test_multi_allowlist_empty_intersection_emits_lint001(
        self, tmp_path: Path
    ) -> None:
        """Two ProviderAllowlist rules with no common provider are UNSAT at pattern level."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: provider_allowlist
    providers: [anthropic]
  - kind: provider_allowlist
    providers: [openai]
""")
        report = lint_policy_file(p)
        assert "LINT001" in _codes(report), report.to_text()


# ── LINT003 z3 UNSAT ─────────────────────────────────────────────────────────


class TestZ3Contradiction:
    def test_retry_gap_huge_does_not_false_positive(self, tmp_path: Path) -> None:
        """A single retry_rate_limit on its own should lint clean (no UNSAT)."""
        pytest.importorskip("z3")
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: retry_rate_limit
    min_gap_seconds: 30
""")
        report = lint_policy_file(p)
        assert "LINT003" not in _codes(report), report.to_text()

    def test_retry_gap_exceeding_unroll_horizon_triggers_unsat(self, tmp_path: Path) -> None:
        """A retry_rate_limit whose min_gap exceeds the unroll horizon forces
        z3 into UNSAT territory under the bounded unrolling — exactly the
        class of policy mistake LINT003 is designed to catch."""
        pytest.importorskip("z3")
        # min_gap_seconds > N * 1s-step + the asserted retry forces z3 to
        # find no model in N unrolls. The stock unroll_steps=10 and a
        # min_gap=300 together land in UNSAT territory (at least,
        # UNKNOWN from z3's perspective — LINT003 fires only on unsat).
        # We exercise a policy where the z3 compiler can assert UNSAT.
        # Use a RollingWindowCap max_count=0 trick: max_count must be > 0
        # per the invariant's __post_init__, so instead we compose two
        # caps whose conjunction is UNSAT.
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: rolling_window_cap
    max_count: 1
    window_seconds: 60
    group_by: global
  - kind: rolling_window_cap
    max_count: 1
    window_seconds: 60
    group_by: global
""")
        report = lint_policy_file(p)
        # Two identical caps should NOT produce LINT003 (SAT); this
        # confirms z3 runs without false-positive-on-consistent.
        assert "LINT003" not in _codes(report), report.to_text()


# ── LINT004 cross-fragment contradiction ─────────────────────────────────────


class TestCrossFragment:
    def test_allowlist_excludes_capped_provider_emits_lint004(
        self, tmp_path: Path
    ) -> None:
        """v1 ProviderAllowlist forbids provider 'openai'; v2 per-provider
        SpendingCap caps spend at 'openai'. Cross-fragment dead-cap."""
        pytest.importorskip("z3")
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: provider_allowlist
    providers: [anthropic]
  - kind: spending_cap
    max_amount: "500"
    scope: per_provider_per_window
    window_seconds: 86400
    provider: openai
""")
        report = lint_policy_file(p)
        assert "LINT004" in _codes(report), report.to_text()
        lint004 = [f for f in report.findings if f.code == "LINT004"][0]
        assert lint004.severity == "error"
        assert "ProviderAllowlist" in lint004.invariants
        assert "SpendingCap" in lint004.invariants

    def test_allowlist_includes_capped_provider_no_lint004(
        self, tmp_path: Path
    ) -> None:
        """When the allowlist covers the capped provider, no clash."""
        pytest.importorskip("z3")
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: provider_allowlist
    providers: [anthropic, openai]
  - kind: spending_cap
    max_amount: "500"
    scope: per_provider_per_window
    window_seconds: 86400
    provider: openai
""")
        report = lint_policy_file(p)
        assert "LINT004" not in _codes(report), report.to_text()


# ── LINT006 redundancy ────────────────────────────────────────────────────────


class TestRedundancy:
    def test_two_max_per_call_same_currency_emits_lint006(
        self, tmp_path: Path
    ) -> None:
        """Two MaxPerCall rules on USDC — the looser one is dead code."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "100"
    currency: USDC
  - kind: max_per_call
    max_amount: "50"
    currency: USDC
""")
        report = lint_policy_file(p)
        assert "LINT006" in _codes(report), report.to_text()
        lint006 = [f for f in report.findings if f.code == "LINT006"][0]
        assert lint006.severity == "warning"
        # The repair hint should name the looser cap.
        assert "100" in (lint006.suggested_repair or "")

    def test_pertx_spending_cap_dominated_by_max_per_call(
        self, tmp_path: Path
    ) -> None:
        """SpendingCap per_tx with amount > MaxPerCall on same currency is dead."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "50"
    currency: USDC
  - kind: spending_cap
    max_amount: "200"
    scope: per_tx
    currency: USDC
""")
        report = lint_policy_file(p)
        assert "LINT006" in _codes(report), report.to_text()

    def test_distinct_currencies_no_redundancy(self, tmp_path: Path) -> None:
        """Two MaxPerCall rules on different currencies are independent."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "100"
    currency: USDC
  - kind: max_per_call
    max_amount: "50"
    currency: DAI
""")
        report = lint_policy_file(p)
        assert "LINT006" not in _codes(report), report.to_text()


# ── strict mode (warnings -> errors) ─────────────────────────────────────────


class TestStrictMode:
    def test_strict_exits_1_on_warnings(self, tmp_path: Path) -> None:
        """A policy with ONLY warnings exits 1 under --strict, 0 without."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "100"
    currency: USDC
  - kind: max_per_call
    max_amount: "50"
    currency: USDC
""")
        # Without strict: warnings are advisory, exit 0.
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "lint", str(p)],
            capture_output=True, text=True, cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 0, result.stderr
        # With --strict: warnings fail CI.
        result_strict = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "lint", str(p), "--strict"],
            capture_output=True, text=True, cwd=str(Path(__file__).parent.parent),
        )
        assert result_strict.returncode == 1, (
            f"stdout={result_strict.stdout}\nstderr={result_strict.stderr}"
        )


# ── output formats ───────────────────────────────────────────────────────────


class TestJsonOutput:
    def test_json_output_schema_valid(self, tmp_path: Path) -> None:
        """JSON output is valid JSON with the documented shape."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "50"
""")
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "lint", str(p), "--format", "json"],
            capture_output=True, text=True, cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 0, result.stderr
        payload = json.loads(result.stdout)
        # Documented envelope
        assert "findings" in payload
        assert "summary" in payload
        assert "fragment_breakdown" in payload
        assert "decidable" in payload
        assert "source_path" in payload
        # summary keys
        for k in ("errors", "warnings", "info"):
            assert k in payload["summary"]
        # fragment_breakdown keys
        for k in ("v1", "v2", "hybrid"):
            assert k in payload["fragment_breakdown"]
        # findings shape
        for f in payload["findings"]:
            assert "severity" in f
            assert "code" in f
            assert "message" in f
            assert "invariants" in f


class TestTextOutput:
    def test_text_output_human_readable(self, tmp_path: Path) -> None:
        """Default text output mentions fragment breakdown + decidable flag."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "50"
""")
        report = lint_policy_file(p)
        text = report.to_text()
        assert "fragments:" in text
        assert "decidable=" in text


# ── error-path: bad files ────────────────────────────────────────────────────


class TestUnloadablePolicy:
    def test_unknown_kind_raises_lint_error(self, tmp_path: Path) -> None:
        """Unknown invariant kind is an error the CLI surfaces as exit 2."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: magical_cap
    max_amount: "50"
""")
        with pytest.raises(LintError):
            lint_policy_file(p)

    def test_unknown_kind_cli_exit_2(self, tmp_path: Path) -> None:
        """CLI maps LintError to exit 2 with a readable stderr message."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: magical_cap
    max_amount: "50"
""")
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "lint", str(p)],
            capture_output=True, text=True, cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 2
        assert "magical_cap" in result.stderr or "unknown" in result.stderr.lower()

    def test_missing_file_raises_lint_error(self, tmp_path: Path) -> None:
        """A path that does not exist surfaces as LintError (exit 2)."""
        p = tmp_path / "nope.yaml"
        with pytest.raises(LintError):
            lint_policy_file(p)

    def test_missing_file_cli_exit_2(self, tmp_path: Path) -> None:
        p = tmp_path / "nope.yaml"
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "lint", str(p)],
            capture_output=True, text=True, cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 2

    def test_malformed_yaml_raises_lint_error(self, tmp_path: Path) -> None:
        p = _write(tmp_path, "::::\nnot yaml")
        with pytest.raises(LintError):
            lint_policy_file(p)


# ── CLI exit codes ───────────────────────────────────────────────────────────


class TestCliExitCodes:
    def test_clean_policy_exits_0(self, tmp_path: Path) -> None:
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: max_per_call
    max_amount: "50"
""")
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "lint", str(p)],
            capture_output=True, text=True, cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 0, (
            f"stdout={result.stdout}\nstderr={result.stderr}"
        )

    def test_error_policy_exits_1(self, tmp_path: Path) -> None:
        """A policy with a LINT001 pattern-level clash exits 1."""
        p = _write(tmp_path, """\
version: 1
policy:
  - kind: provider_allowlist
    providers: [anthropic]
  - kind: provider_allowlist
    providers: [openai]
""")
        result = subprocess.run(
            [sys.executable, "-m", "daemon.cli", "lint", str(p)],
            capture_output=True, text=True, cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 1, (
            f"stdout={result.stdout}\nstderr={result.stderr}"
        )


# ── performance ──────────────────────────────────────────────────────────────


class TestPerformance:
    def test_large_policy_lints_in_under_5s(self, tmp_path: Path) -> None:
        """100-invariant policy lints in under 5s.

        A real operator-facing policy won't hit this size, but the gate
        matches the spec: the linter must stay subsecond-ish even on
        comically large policies so nothing in CI times out.
        """
        pytest.importorskip("z3")
        lines = ["version: 1", "policy:"]
        # 100 MaxPerCall rules on distinct currencies: no redundancy,
        # no contradictions, pure compile cost.
        for i in range(100):
            lines.append(f"  - kind: max_per_call")
            lines.append(f"    max_amount: \"{i + 1}\"")
            lines.append(f"    currency: CUR{i:03d}")
        p = _write(tmp_path, "\n".join(lines))
        t0 = time.monotonic()
        report = lint_policy_file(p)
        elapsed = time.monotonic() - t0
        assert elapsed < 5.0, f"linter took {elapsed:.2f}s (gate: 5.0s)"
        assert report.fragment_breakdown["v1"] == 100


# ── LintFinding dataclass sanity ─────────────────────────────────────────────


class TestLintFindingValidation:
    def test_invalid_severity_raises(self) -> None:
        with pytest.raises(ValueError, match="severity"):
            LintFinding(severity="critical", code="LINT999", message="x")

    def test_to_dict_preserves_fields(self) -> None:
        f = LintFinding(
            severity="warning",
            code="LINT006",
            message="redundant",
            invariants=("MaxPerCall", "MaxPerCall"),
            suggested_repair="drop one",
        )
        d = f.to_dict()
        assert d["severity"] == "warning"
        assert d["invariants"] == ["MaxPerCall", "MaxPerCall"]
        assert d["suggested_repair"] == "drop one"
