"""Acceptance tests for Guaranteed Mode runtime decision discipline (v0.19.0).

Covers Deliverable 4 of the Guaranteed Mode spec:

  * The bounded ``GUARANTEED_RUNTIME_FEATURES`` set is the ONLY dispatch
    surface. Unbounded feature requests deny with
    ``RUNTIME_GUARD_VIOLATION``.
  * Every internal-exception path fails closed with
    ``RUNTIME_EVALUATION_UNAVAILABLE``. The path that would have been
    "best-effort allow" in Flexible Mode must never allow under error
    in Guaranteed Mode.
  * The decision envelope is frozen and carries the full bank-audit
    provenance (policy revision id, proof artifact id + hash, guard
    state version, decision id, timestamp).
  * The proof artifact must be present, consistent, and bound to the
    revision by id. Missing or mismatched bindings deny.

Tests use plain dataclass doubles (not the agent 1 / 2 stacks) so the
assertions run without the full guaranteed stack merging.
"""
from __future__ import annotations

from dataclasses import FrozenInstanceError, dataclass, field
from datetime import datetime
from typing import Any, Mapping, Optional

import pytest

from adapter.guaranteed_runtime import (
    GUARANTEED_RUNTIME_FEATURES,
    GuaranteedDecision,
    guaranteed_should_pay_x402,
)


# ── test doubles ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class _FakePolicyRevision:
    """Tiny stand-in for a policy revision — only ``id`` is read."""

    id: str


@dataclass(frozen=True)
class _FakeProofArtifact:
    """Stand-in for ``GuaranteedProofArtifact`` with only the fields we read."""

    artifact_id: str
    policy_revision_id: str
    proof_result: str  # "consistent" | "inconsistent" | "inconclusive"
    artifact_hash: str = ""


@dataclass
class _FakeIntent:
    """Mutable by design — one test monkeypatches .evaluate_guaranteed."""

    runtime_feature: str
    _raise: Optional[BaseException] = None

    def evaluate_guaranteed(
        self,
        *,
        feature: str,
        policy_revision: Any,
        guard_state: Any,
    ) -> None:
        # Default: no-op. When ``_raise`` is set, we raise to simulate a
        # failing subsystem.
        if self._raise is not None:
            raise self._raise


def _happy_path_inputs() -> dict[str, Any]:
    revision = _FakePolicyRevision(id="rev-1")
    artifact = _FakeProofArtifact(
        artifact_id="artifact-1",
        policy_revision_id="rev-1",
        proof_result="consistent",
        artifact_hash="abc123def456" * 3,
    )
    intent = _FakeIntent(runtime_feature="spend_cap")
    guard_state = {"cap": 100, "used": 5}
    return {
        "intent": intent,
        "policy_revision": revision,
        "proof_artifact": artifact,
        "guard_state": guard_state,
    }


# ── happy path ──────────────────────────────────────────────────────────────


class TestHappyPath:
    def test_allow_on_consistent_proof_and_bounded_feature(self):
        inputs = _happy_path_inputs()

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is True
        assert decision.mode == "guaranteed"
        assert decision.policy_revision_id == "rev-1"
        assert decision.proof_artifact_id == "artifact-1"
        assert decision.proof_artifact_hash  # non-empty
        assert decision.runtime_guard_state_version  # non-empty
        assert decision.reason is None
        assert "admitted" in decision.explanation
        assert decision.decision_id  # UUID populated
        assert isinstance(decision.decision_timestamp, datetime)

    def test_all_bounded_features_dispatch(self):
        """Each entry in ``GUARANTEED_RUNTIME_FEATURES`` admits cleanly."""
        for feature in GUARANTEED_RUNTIME_FEATURES:
            inputs = _happy_path_inputs()
            inputs["intent"] = _FakeIntent(runtime_feature=feature)
            decision = guaranteed_should_pay_x402(**inputs)
            assert decision.allow is True, f"feature {feature!r} denied unexpectedly"
            assert decision.reason is None


# ── Test 5: fail-closed runtime ─────────────────────────────────────────────


class TestFailClosedRuntime:
    """Test 5 from the patch spec: any internal exception → deny.

    The runtime guard subsystem is modelled here via ``_FakeIntent._raise``.
    When the evaluator raises, the decision must be a deny with reason
    ``RUNTIME_EVALUATION_UNAVAILABLE``. Never ``allow=True``.
    """

    def test_evaluator_raises_runtime_error(self):
        inputs = _happy_path_inputs()
        inputs["intent"] = _FakeIntent(
            runtime_feature="spend_cap",
            _raise=RuntimeError("simulated subsystem outage"),
        )

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is False
        assert decision.reason == "RUNTIME_EVALUATION_UNAVAILABLE"
        assert "RuntimeError" in decision.explanation

    def test_evaluator_raises_value_error(self):
        inputs = _happy_path_inputs()
        inputs["intent"] = _FakeIntent(
            runtime_feature="burst_throttle",
            _raise=ValueError("bad input"),
        )

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is False
        assert decision.reason == "RUNTIME_EVALUATION_UNAVAILABLE"

    def test_evaluator_raises_arbitrary_exception(self):
        class WeirdError(Exception):
            pass

        inputs = _happy_path_inputs()
        inputs["intent"] = _FakeIntent(
            runtime_feature="retry_cooldown",
            _raise=WeirdError("anything"),
        )

        decision = guaranteed_should_pay_x402(**inputs)

        # Absolutely must not allow on unknown errors.
        assert decision.allow is False
        assert decision.reason == "RUNTIME_EVALUATION_UNAVAILABLE"

    def test_never_best_effort_allows_under_any_error(self):
        """Scan every tested error path to confirm allow=False everywhere."""
        for exc in (
            RuntimeError("x"),
            ValueError("y"),
            KeyError("z"),
            TypeError("t"),
            AttributeError("a"),
        ):
            inputs = _happy_path_inputs()
            inputs["intent"] = _FakeIntent(
                runtime_feature="spend_cap",
                _raise=exc,
            )
            decision = guaranteed_should_pay_x402(**inputs)
            assert decision.allow is False, (
                f"best-effort allow leaked through for {type(exc).__name__}"
            )


# ── runtime guard violation: unbounded features ─────────────────────────────


class TestRuntimeGuardViolation:
    def test_adaptive_tightening_denied_as_out_of_set(self):
        """The v1.0.0 feature set explicitly excludes adaptive_tightening."""
        inputs = _happy_path_inputs()
        inputs["intent"] = _FakeIntent(runtime_feature="adaptive_tightening")

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is False
        assert decision.reason == "RUNTIME_GUARD_VIOLATION"
        assert "adaptive_tightening" in decision.explanation

    def test_unknown_feature_denied(self):
        inputs = _happy_path_inputs()
        inputs["intent"] = _FakeIntent(runtime_feature="chaos_mode")

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is False
        assert decision.reason == "RUNTIME_GUARD_VIOLATION"

    def test_empty_feature_denied(self):
        inputs = _happy_path_inputs()
        inputs["intent"] = _FakeIntent(runtime_feature="")

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is False
        assert decision.reason == "RUNTIME_GUARD_VIOLATION"


# ── proof artifact bindings ─────────────────────────────────────────────────


class TestProofArtifactBinding:
    def test_inconsistent_proof_denied(self):
        inputs = _happy_path_inputs()
        inputs["proof_artifact"] = _FakeProofArtifact(
            artifact_id="a",
            policy_revision_id="rev-1",
            proof_result="inconsistent",
        )

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is False
        assert decision.reason == "RUNTIME_GUARD_VIOLATION"
        assert "consistent" in decision.explanation.lower()

    def test_inconclusive_proof_denied(self):
        inputs = _happy_path_inputs()
        inputs["proof_artifact"] = _FakeProofArtifact(
            artifact_id="a",
            policy_revision_id="rev-1",
            proof_result="inconclusive",
        )

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is False
        assert decision.reason == "RUNTIME_GUARD_VIOLATION"

    def test_artifact_bound_to_wrong_revision_denied(self):
        inputs = _happy_path_inputs()
        inputs["proof_artifact"] = _FakeProofArtifact(
            artifact_id="a",
            policy_revision_id="rev-OTHER",
            proof_result="consistent",
        )

        decision = guaranteed_should_pay_x402(**inputs)

        assert decision.allow is False
        assert decision.reason == "RUNTIME_GUARD_VIOLATION"
        assert "bound" in decision.explanation.lower() or "revision" in decision.explanation.lower()


# ── provenance envelope ─────────────────────────────────────────────────────


class TestProvenanceEnvelope:
    def test_envelope_includes_all_provenance_fields_on_allow(self):
        inputs = _happy_path_inputs()
        decision = guaranteed_should_pay_x402(**inputs)

        wire = decision.to_wire()
        assert wire["mode"] == "guaranteed"
        assert wire["policy_revision_id"] == "rev-1"
        assert wire["proof_artifact_id"] == "artifact-1"
        assert wire["proof_artifact_hash"]  # non-empty
        assert wire["runtime_guard_state_version"]  # non-empty
        assert wire["allow"] is True
        assert wire["decision_id"]  # UUID populated
        assert wire["decision_timestamp"]  # ISO timestamp populated
        assert wire["reason"] is None

    def test_envelope_includes_all_provenance_fields_on_deny(self):
        inputs = _happy_path_inputs()
        inputs["intent"] = _FakeIntent(runtime_feature="adaptive_tightening")

        decision = guaranteed_should_pay_x402(**inputs)
        wire = decision.to_wire()

        assert wire["mode"] == "guaranteed"
        assert wire["policy_revision_id"] == "rev-1"
        # Proof artifact fields are still present on deny.
        assert wire["proof_artifact_id"] == "artifact-1"
        assert wire["proof_artifact_hash"]
        assert wire["runtime_guard_state_version"]
        assert wire["allow"] is False
        assert wire["reason"] == "RUNTIME_GUARD_VIOLATION"

    def test_decision_is_frozen(self):
        inputs = _happy_path_inputs()
        decision = guaranteed_should_pay_x402(**inputs)

        with pytest.raises((FrozenInstanceError, AttributeError)):
            decision.allow = True  # type: ignore[misc]

    def test_decision_timestamp_is_utc(self):
        inputs = _happy_path_inputs()
        decision = guaranteed_should_pay_x402(**inputs)

        # Must be timezone-aware UTC.
        assert decision.decision_timestamp.tzinfo is not None

    def test_guard_state_version_stable_for_same_state(self):
        """Same guard state → same version hash (deterministic)."""
        inputs_1 = _happy_path_inputs()
        inputs_2 = _happy_path_inputs()
        # Different intent/artifact identity is fine — state hash depends on
        # the guard state dict only.
        inputs_2["guard_state"] = dict(inputs_1["guard_state"])

        d1 = guaranteed_should_pay_x402(**inputs_1)
        d2 = guaranteed_should_pay_x402(**inputs_2)

        assert d1.runtime_guard_state_version == d2.runtime_guard_state_version

    def test_guard_state_version_differs_for_different_state(self):
        inputs_1 = _happy_path_inputs()
        inputs_2 = _happy_path_inputs()
        inputs_2["guard_state"] = {"cap": 200, "used": 150}  # different

        d1 = guaranteed_should_pay_x402(**inputs_1)
        d2 = guaranteed_should_pay_x402(**inputs_2)

        assert d1.runtime_guard_state_version != d2.runtime_guard_state_version


# ── feature-set contract ────────────────────────────────────────────────────


class TestFeatureSetContract:
    def test_feature_set_is_frozen(self):
        assert isinstance(GUARANTEED_RUNTIME_FEATURES, frozenset)

    def test_feature_set_v1_exact_membership(self):
        """v1.1.0 pins the feature set exactly — new members are a wire change.

        Adding an entry requires a language tier version bump + totality
        proof covering the feature's runtime semantics.
        """
        assert GUARANTEED_RUNTIME_FEATURES == frozenset({
            "spend_cap",
            "burst_throttle",
            "retry_cooldown",
            "window_cap",
            "rolling_window_cap",
            "burst_velocity_cap",
        })

    def test_adaptive_tightening_excluded(self):
        assert "adaptive_tightening" not in GUARANTEED_RUNTIME_FEATURES
