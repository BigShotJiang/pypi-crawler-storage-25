"""Tests for the webhook sink (v0.10.0).

Covers config parsing, signature canonicalisation + verification, the
delivery / retry / circuit-breaker worker loop, daemon integration
(permit and reject both fan out, hot-path latency unaffected by sink
failure), the ``webhook-test`` CLI, and a deterministic back-pressure
check (queue_size=2 evicts oldest).

Every test that spins a worker either injects a fake ``transport``
callable or uses a tiny stdlib ``http.server`` on ``127.0.0.1:0``, so
the suite never touches the network and runs under a second.
"""
from __future__ import annotations

import hashlib
import hmac
import http.server
import json
import os
import queue
import socket
import socketserver
import subprocess
import sys
import tempfile
import threading
import time
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterator

import pytest

from adapter.webhook_sink import (
    CIRCUIT_BREAKER_COOLDOWN_S,
    CIRCUIT_BREAKER_THRESHOLD,
    WebhookConfig,
    WebhookConfigError,
    WebhookSink,
    _HTTPResult,
    canonicalize_verdict,
    compute_signature,
    load_webhook_config,
)
from daemon.server import CageDaemon


SECRET_16 = b"0123456789abcdef"
SECRET_32 = b"A" * 32
REAL_SECRET = b"really-long-webhook-secret-for-tests"


# ── helpers ──────────────────────────────────────────────────────────────────


class _CapturingTransport:
    """Records every POST so tests can assert on what got delivered."""

    def __init__(
        self,
        status_code: int = 200,
        raise_exc: Exception | None = None,
        status_sequence: list[int] | None = None,
    ) -> None:
        self.status_code = status_code
        self.raise_exc = raise_exc
        self.status_sequence = list(status_sequence) if status_sequence else None
        self.calls: list[dict[str, Any]] = []
        self.lock = threading.Lock()
        self.call_event = threading.Event()

    def __call__(self, url: str, headers: dict[str, str], body: bytes, timeout_s: float) -> _HTTPResult:
        with self.lock:
            self.calls.append(
                {"url": url, "headers": dict(headers), "body": body, "timeout_s": timeout_s}
            )
            self.call_event.set()
            if self.raise_exc is not None:
                raise self.raise_exc
            if self.status_sequence:
                return _HTTPResult(status_code=self.status_sequence.pop(0))
            return _HTTPResult(status_code=self.status_code)

    def wait_for_calls(self, n: int, timeout_s: float = 2.0) -> None:
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            with self.lock:
                if len(self.calls) >= n:
                    return
            time.sleep(0.01)
        raise AssertionError(
            f"timed out waiting for {n} webhook POSTs; got {len(self.calls)}"
        )


def _start_sink(**kwargs: Any) -> tuple[WebhookSink, _CapturingTransport]:
    transport = kwargs.pop("transport", None) or _CapturingTransport()
    sink = WebhookSink(
        url="http://127.0.0.1/notify",
        secret=SECRET_16,
        transport=transport,
        **kwargs,
    )
    sink.start()
    return sink, transport


# ── config surface ──────────────────────────────────────────────────────────


class TestWebhookConfig:
    def test_builds_with_defaults(self) -> None:
        cfg = WebhookConfig(
            name="datadog",
            url="https://example.com/hook",
            secret=SECRET_16,
        )
        assert cfg.timeout_s == 3.0
        assert cfg.retry == 3
        assert cfg.queue_size == 10_000
        assert cfg.only_verdicts == frozenset()
        assert cfg.only_rules == frozenset()

    def test_rejects_non_http_url(self) -> None:
        with pytest.raises(WebhookConfigError, match="url must be"):
            WebhookConfig(name="x", url="ftp://ex.com", secret=SECRET_16)

    def test_rejects_short_secret(self) -> None:
        with pytest.raises(WebhookConfigError, match="secret must be bytes"):
            WebhookConfig(name="x", url="http://a/b", secret=b"short")

    def test_rejects_zero_timeout(self) -> None:
        with pytest.raises(WebhookConfigError, match="timeout_s"):
            WebhookConfig(name="x", url="http://a/b", secret=SECRET_16, timeout_s=0)

    def test_rejects_negative_retry(self) -> None:
        with pytest.raises(WebhookConfigError, match="retry"):
            WebhookConfig(name="x", url="http://a/b", secret=SECRET_16, retry=-1)

    def test_rejects_empty_name(self) -> None:
        with pytest.raises(WebhookConfigError):
            WebhookConfig(name="", url="http://a/b", secret=SECRET_16)

    def test_rejects_unknown_only_verdicts(self) -> None:
        with pytest.raises(WebhookConfigError, match="only_verdicts"):
            WebhookConfig(
                name="x", url="http://a/b", secret=SECRET_16,
                only_verdicts=frozenset({"maybe"}),
            )

    def test_matches_only_verdicts(self) -> None:
        cfg = WebhookConfig(
            name="x", url="http://a/b", secret=SECRET_16,
            only_verdicts=frozenset({"reject"}),
        )
        assert cfg.matches({"verdict": "reject", "rule_id": "rl"})
        assert not cfg.matches({"verdict": "permit", "rule_id": None})

    def test_matches_only_rules_drops_permits_by_default(self) -> None:
        cfg = WebhookConfig(
            name="x", url="http://a/b", secret=SECRET_16,
            only_rules=frozenset({"spending_cap_per_tx"}),
        )
        # Permit has no rule_id -> filtered out by rule list.
        assert not cfg.matches({"verdict": "permit", "rule_id": None})
        assert not cfg.matches({"verdict": "reject", "rule_id": "other"})
        assert cfg.matches({"verdict": "reject", "rule_id": "spending_cap_per_tx"})


class TestLoadWebhookConfig:
    def test_yaml_round_trip(self, tmp_path: Path) -> None:
        yaml_body = f"""
version: 1
webhooks:
  - name: datadog
    url: https://http.example/hook
    secret: {'B' * 32}
    timeout_s: 2.5
    retry: 1
    queue_size: 500
    only_verdicts: [reject]
    only_rules: [spending_cap_per_tx]
"""
        path = tmp_path / "wh.yaml"
        path.write_text(yaml_body)
        configs = load_webhook_config(path)
        assert len(configs) == 1
        cfg = configs[0]
        assert cfg.name == "datadog"
        assert cfg.url == "https://http.example/hook"
        assert cfg.timeout_s == 2.5
        assert cfg.retry == 1
        assert cfg.queue_size == 500
        assert cfg.only_verdicts == frozenset({"reject"})
        assert cfg.only_rules == frozenset({"spending_cap_per_tx"})

    def test_secret_env_pulls_from_environment(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setenv("MY_TEST_SECRET", "C" * 20)
        body = """
version: 1
webhooks:
  - name: via-env
    url: http://ex.com/h
    secret_env: MY_TEST_SECRET
"""
        cfgs = load_webhook_config(body)
        assert cfgs[0].secret == ("C" * 20).encode("utf-8")

    def test_secret_env_missing_var_raises(self, monkeypatch) -> None:
        monkeypatch.delenv("ABSENT_SECRET", raising=False)
        body = """
version: 1
webhooks:
  - name: x
    url: http://ex.com/h
    secret_env: ABSENT_SECRET
"""
        with pytest.raises(WebhookConfigError, match="unset or empty"):
            load_webhook_config(body)

    def test_missing_secret_raises(self) -> None:
        body = """
version: 1
webhooks:
  - name: x
    url: http://ex.com/h
"""
        with pytest.raises(WebhookConfigError, match="secret"):
            load_webhook_config(body)

    def test_missing_url_raises(self) -> None:
        body = """
version: 1
webhooks:
  - name: x
    secret: aaaaaaaaaaaaaaaa
"""
        with pytest.raises(WebhookConfigError, match="url"):
            load_webhook_config(body)

    def test_empty_config_returns_empty_list(self, tmp_path: Path) -> None:
        p = tmp_path / "empty.yaml"
        p.write_text("")
        assert load_webhook_config(p) == []

    def test_list_shape_rejected(self) -> None:
        with pytest.raises(WebhookConfigError, match="mapping"):
            load_webhook_config("- not a mapping")

    def test_no_webhooks_key_returns_empty(self) -> None:
        assert load_webhook_config("version: 1") == []


# ── signature canonicalisation ──────────────────────────────────────────────


class TestSignatureCanonicalisation:
    def test_canonical_output_is_sorted(self) -> None:
        body = canonicalize_verdict({"b": 2, "a": 1, "c": {"z": 9, "a": 0}})
        # Keys sorted top-level AND nested.
        assert body == b'{"a":1,"b":2,"c":{"a":0,"z":9}}'

    def test_signature_verifies_via_stdlib_hmac(self) -> None:
        verdict = {"verdict": "reject", "rule_id": "r1", "intent": {"amount": "10"}}
        body = canonicalize_verdict(verdict)
        ts = "1700000000"
        sig = compute_signature(REAL_SECRET, ts, body)
        expected = hmac.new(
            REAL_SECRET, digestmod=hashlib.sha256,
        )
        expected.update(ts.encode("ascii"))
        expected.update(b".")
        expected.update(body)
        assert sig == expected.hexdigest()

    def test_signature_changes_if_timestamp_changes(self) -> None:
        body = b'{"x":1}'
        s1 = compute_signature(REAL_SECRET, "1", body)
        s2 = compute_signature(REAL_SECRET, "2", body)
        assert s1 != s2


# ── delivery happy path ─────────────────────────────────────────────────────


class TestDeliveryHappyPath:
    def test_permit_delivered(self) -> None:
        sink, transport = _start_sink()
        try:
            sink.emit({"verdict": "permit", "rule_id": None, "intent": {"amount": "1"}})
            transport.wait_for_calls(1)
        finally:
            sink.stop()
        assert len(transport.calls) == 1
        headers = transport.calls[0]["headers"]
        assert headers["X-Cage-Signature"].startswith("sha256=")
        assert headers["X-Cage-Timestamp"].isdigit()
        assert headers["X-Cage-Verdict-Id"]  # non-empty

    def test_reject_delivered(self) -> None:
        sink, transport = _start_sink()
        try:
            sink.emit({
                "verdict": "reject",
                "rule_id": "spending_cap_per_tx",
                "reason_text": "over cap",
                "intent": {"amount": "1001"},
            })
            transport.wait_for_calls(1)
        finally:
            sink.stop()
        call = transport.calls[0]
        payload = json.loads(call["body"])
        assert payload["verdict"] == "reject"
        assert payload["rule_id"] == "spending_cap_per_tx"
        # Signature binds the exact canonical body.
        ts = call["headers"]["X-Cage-Timestamp"]
        sig = call["headers"]["X-Cage-Signature"].split("=", 1)[1]
        expected = compute_signature(SECRET_16, ts, call["body"])
        assert hmac.compare_digest(sig, expected)


# ── filter behaviour ────────────────────────────────────────────────────────


class TestFilters:
    def test_only_reject_drops_permits(self) -> None:
        sink, transport = _start_sink(only_verdicts=["reject"])
        try:
            sink.emit({"verdict": "permit", "rule_id": None, "intent": {}})
            sink.emit({"verdict": "reject", "rule_id": "r1", "intent": {}})
            transport.wait_for_calls(1)
            # Make sure a second delivery doesn't sneak in.
            time.sleep(0.1)
        finally:
            sink.stop()
        assert len(transport.calls) == 1
        assert json.loads(transport.calls[0]["body"])["verdict"] == "reject"


# ── back-pressure (drop oldest, deterministic queue_size=2) ─────────────────


class TestBackPressure:
    def test_queue_full_drops_oldest(self) -> None:
        """With queue_size=2 and 4 emits the 2 oldest get evicted."""
        gate = threading.Event()

        def blocking_transport(url, headers, body, timeout_s):
            # Block the worker so the queue actually fills.
            gate.wait(timeout=2.0)
            return _HTTPResult(200)

        sink = WebhookSink(
            url="http://127.0.0.1/notify",
            secret=SECRET_16,
            queue_size=2,
            retry=0,
            transport=blocking_transport,
        )
        sink.start()
        try:
            # First emit enters the worker and is blocked on `gate`;
            # three more sit in the queue. Queue size 2 means the 3rd
            # one into the queue evicts the oldest of the queued ones.
            sink.emit({"verdict": "reject", "rule_id": "a", "seq": 1, "intent": {}})
            # Give the worker a moment to pick up #1.
            deadline = time.monotonic() + 0.5
            while time.monotonic() < deadline:
                with sink._buf_lock:
                    if len(sink._buf) == 0:
                        break
                time.sleep(0.01)
            # Now fill the queue past capacity.
            sink.emit({"verdict": "reject", "rule_id": "b", "seq": 2, "intent": {}})
            sink.emit({"verdict": "reject", "rule_id": "c", "seq": 3, "intent": {}})
            # This fourth emit forces an eviction: buf was full (size 2),
            # so the oldest queued entry (b) is dropped in favour of d.
            sink.emit({"verdict": "reject", "rule_id": "d", "seq": 4, "intent": {}})
            snap = sink.metrics_snapshot()
            assert snap["dropped"] >= 1, f"expected at least 1 drop, got {snap}"
        finally:
            gate.set()
            sink.stop()


# ── circuit breaker ─────────────────────────────────────────────────────────


class TestCircuitBreaker:
    def test_opens_after_five_consecutive_failures(self) -> None:
        transport = _CapturingTransport(status_code=500)
        sink = WebhookSink(
            url="http://127.0.0.1/hook",
            secret=SECRET_16,
            retry=0,  # no internal retries; each emit counts as one failure
            transport=transport,
            sleep=lambda _s: None,
        )
        sink.start()
        try:
            for i in range(CIRCUIT_BREAKER_THRESHOLD):
                sink.emit({"verdict": "reject", "rule_id": f"r{i}", "intent": {}})
            # Let the worker chew through them.
            deadline = time.monotonic() + 2.0
            while time.monotonic() < deadline:
                if sink.metrics_snapshot()["consecutive_failures"] >= CIRCUIT_BREAKER_THRESHOLD:
                    break
                time.sleep(0.02)
            snap = sink.metrics_snapshot()
            assert snap["consecutive_failures"] >= CIRCUIT_BREAKER_THRESHOLD
            assert sink.circuit_open_until > 0.0, "circuit should be open"
        finally:
            sink.stop()

    def test_closes_after_cooldown(self) -> None:
        """Force-close the circuit (simulating cooldown elapse), and a
        subsequent success resets the consecutive-failure counter."""
        transport = _CapturingTransport(status_code=200)
        sink = WebhookSink(
            url="http://127.0.0.1/hook",
            secret=SECRET_16,
            retry=0,
            transport=transport,
            sleep=lambda _s: None,
        )
        sink.start()
        try:
            # Pre-load the breaker state, then emit and observe recovery.
            sink._consecutive_failures = CIRCUIT_BREAKER_THRESHOLD
            sink._circuit_open_until = 0.0  # simulate "cooldown done"
            sink.emit({"verdict": "permit", "rule_id": None, "intent": {}})
            transport.wait_for_calls(1)
            deadline = time.monotonic() + 1.0
            while time.monotonic() < deadline:
                if sink.metrics_snapshot()["consecutive_failures"] == 0:
                    break
                time.sleep(0.02)
            assert sink.metrics_snapshot()["consecutive_failures"] == 0
        finally:
            sink.stop()


# ── daemon integration ─────────────────────────────────────────────────────


@pytest.fixture
def daemon_with_sink() -> Iterator[tuple[CageDaemon, str, _CapturingTransport, WebhookSink]]:
    fd, path = tempfile.mkstemp(prefix="x402-wh-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)

    transport = _CapturingTransport()
    sink = WebhookSink(
        url="http://127.0.0.1/ingest",
        secret=SECRET_16,
        retry=0,
        transport=transport,
    )
    d = CageDaemon(socket_path=path, webhook_sinks=[sink])
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline:
        if os.path.exists(path):
            try:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.settimeout(0.2)
                s.connect(path)
                s.close()
                break
            except OSError:
                pass
        time.sleep(0.02)
    try:
        yield d, path, transport, sink
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, request: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


class TestDaemonIntegration:
    def test_permit_fans_out(self, daemon_with_sink) -> None:
        _, path, transport, _ = daemon_with_sink
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "100"})
        resp = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "10",
                "currency": "USDC",
                "provider": "openai",
                "counterparty": "vendor_a",
                "rail": "x402",
                "timestamp_unix": 0,
                "request_id": "rq-1",
            },
        })
        assert resp["verdict"] == "permit"
        transport.wait_for_calls(1)
        body = json.loads(transport.calls[0]["body"])
        assert body["verdict"] == "permit"

    def test_reject_fans_out(self, daemon_with_sink) -> None:
        _, path, transport, _ = daemon_with_sink
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "5"})
        resp = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "1000",
                "currency": "USDC",
                "provider": "openai",
                "counterparty": "vendor_a",
                "rail": "x402",
                "timestamp_unix": 0,
                "request_id": "rq-2",
            },
        })
        assert resp["verdict"] == "reject"
        transport.wait_for_calls(1)
        body = json.loads(transport.calls[0]["body"])
        assert body["verdict"] == "reject"
        assert body["rule_id"] == "max_per_call"


# ── hot-path latency unaffected by webhook failure ─────────────────────────


class TestHotPathLatency:
    def test_webhook_failure_does_not_slow_response(self) -> None:
        """A transport that sleeps for 500ms must not delay the response.

        We assert p95 over a small batch stays well under the sleep time.
        """
        def slow_transport(url, headers, body, timeout_s):
            time.sleep(0.5)
            return _HTTPResult(500)

        fd, path = tempfile.mkstemp(prefix="x402-lat-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(path)
        sink = WebhookSink(
            url="http://127.0.0.1/slow",
            secret=SECRET_16,
            retry=0,
            queue_size=100,
            transport=slow_transport,
            sleep=lambda _s: None,
        )
        daemon = CageDaemon(socket_path=path, webhook_sinks=[sink])
        t = threading.Thread(target=daemon.serve_forever, daemon=True)
        t.start()
        # Wait for UDS to be connectable, not just present on disk.
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline:
            if os.path.exists(path):
                try:
                    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    s.settimeout(0.2)
                    s.connect(path)
                    s.close()
                    break
                except OSError:
                    pass
            time.sleep(0.02)
        try:
            _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "100"})
            samples: list[float] = []
            for i in range(20):
                t0 = time.perf_counter()
                resp = _send(path, {
                    "op": "check_payment",
                    "intent": {
                        "amount": "1",
                        "currency": "USDC",
                        "provider": "openai",
                        "counterparty": "vendor_a",
                        "rail": "x402",
                        "timestamp_unix": 0,
                        "request_id": f"rq-{i}",
                    },
                })
                samples.append(time.perf_counter() - t0)
                assert resp["verdict"] == "permit"
            # If webhook dispatch blocked the hot path, each round-trip would
            # be >=500ms. We allow generous headroom for pytest overhead.
            p95 = sorted(samples)[int(len(samples) * 0.95)]
            assert p95 < 0.2, f"p95 hot-path latency {p95*1000:.1f}ms -- sink leaked into hot path"
        finally:
            daemon.shutdown()
            t.join(timeout=1.0)


# ── CLI: webhook-test ───────────────────────────────────────────────────────


class _RecordingHandler(http.server.BaseHTTPRequestHandler):
    received: list[dict[str, Any]] = []

    def do_POST(self):  # noqa: N802 - stdlib naming
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        _RecordingHandler.received.append({
            "path": self.path,
            "headers": {k: v for k, v in self.headers.items()},
            "body": body,
        })
        self.send_response(200)
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"ok")

    def log_message(self, *a, **k):  # silence test output
        pass


class _QuietTCPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    allow_reuse_address = True
    daemon_threads = True


@pytest.fixture
def http_sink_server() -> Iterator[str]:
    _RecordingHandler.received = []
    server = _QuietTCPServer(("127.0.0.1", 0), _RecordingHandler)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        yield f"http://127.0.0.1:{port}/ingest"
    finally:
        server.shutdown()
        server.server_close()


class TestWebhookTestCLI:
    def _run_cli(self, args: list[str]) -> subprocess.CompletedProcess:
        env = os.environ.copy()
        repo_root = str(Path(__file__).resolve().parent.parent)
        env["PYTHONPATH"] = os.pathsep.join(
            [repo_root, env.get("PYTHONPATH", "")]
        ).rstrip(os.pathsep)
        return subprocess.run(
            [sys.executable, "-m", "daemon.cli", *args],
            env=env, capture_output=True, text=True, timeout=15,
        )

    def test_dry_run_prints_canonical_body_and_signature(self) -> None:
        result = self._run_cli([
            "webhook-test",
            "--url", "http://127.0.0.1:1/ignored",
            "--secret", "integration-webhook-secret",
            "--dry-run",
        ])
        assert result.returncode == 0, result.stderr
        assert "X-Cage-Signature: sha256=" in result.stdout
        assert "X-Cage-Timestamp:" in result.stdout
        assert '"verdict":"reject"' in result.stdout

    def test_prints_valid_signature(self, http_sink_server: str) -> None:
        result = self._run_cli([
            "webhook-test",
            "--url", http_sink_server,
            "--secret", "integration-webhook-secret",
        ])
        assert result.returncode == 0, (result.stdout, result.stderr)
        # Extract the signature line
        sig_line = [ln for ln in result.stdout.splitlines() if ln.startswith("X-Cage-Signature")]
        assert sig_line, result.stdout
        sig_hex = sig_line[0].split("sha256=", 1)[1].strip()
        assert len(sig_hex) == 64
        bytes.fromhex(sig_hex)  # must be valid hex


# ── smoke: daemon accepts webhook_sinks=None (back-compat) ──────────────────


class TestBackwardsCompatibility:
    def test_daemon_with_no_sinks_works(self) -> None:
        fd, path = tempfile.mkstemp(prefix="x402-nohook-", suffix=".sock", dir="/tmp")
        os.close(fd)
        os.unlink(path)
        d = CageDaemon(socket_path=path)
        assert d.webhook_sinks == ()
        t = threading.Thread(target=d.serve_forever, daemon=True)
        t.start()
        for _ in range(50):
            if os.path.exists(path):
                break
            time.sleep(0.01)
        try:
            r = _send(path, {"op": "health"})
            assert r["verdict"] == "ok"
        finally:
            d.shutdown()
            t.join(timeout=1.0)
