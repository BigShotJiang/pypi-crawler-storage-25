"""Daemon integration tests for pointwise revision.

Covers the lifecycle: declare -> proof token, contradicting declare is rejected,
retract updates the log, audit-log op returns the chain.
"""
from __future__ import annotations

import json
import os
import socket
import tempfile
import threading
import time
from typing import Iterator

import pytest

from daemon.server import CageDaemon


@pytest.fixture
def daemon() -> Iterator[str]:
    fd, path = tempfile.mkstemp(prefix="rev-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)
    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, req: dict) -> dict:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        f = s.makefile("r")
        return json.loads(f.readline())
    finally:
        s.close()


class TestDeclareIssuesProofToken:
    def test_declare_returns_proof_token(self, daemon: str) -> None:
        r = _send(daemon, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "50",
        })
        assert r["verdict"] == "updated"
        assert "proof_token" in r
        token = r["proof_token"]
        assert token["backend"] == "python-pattern"
        assert token["proof_strength"] == "pattern"
        assert token["config_hash"]
        assert token["nonce"]
        # First revision has no predecessor
        assert token["predecessor_hash"] is None

    def test_second_declare_chains_predecessor(self, daemon: str) -> None:
        r1 = _send(daemon, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "50"})
        r2 = _send(daemon, {"op": "declare_x402", "kind": "retry_rate_limit", "min_gap_seconds": 30})
        assert r2["proof_token"]["predecessor_hash"] == r1["proof_token"]["config_hash"]


class TestContradictionRejectsUpdate:
    def test_cross_rule_sanctioned_approved_is_rejected(self, daemon: str) -> None:
        """Real contradiction: counterparty X is approved in one rule AND sanctioned in another.

        Replaces the v0.3.2 test that asserted disjoint ProviderAllowlist and
        CounterpartyConstraint.approved were a contradiction -- that check
        was semantically wrong (provider and counterparty are independent
        fields) and was removed in v0.3.3.
        """
        _send(daemon, {
            "op": "declare_x402",
            "kind": "counterparty_constraint",
            "approved_ids": ["vendor_a"],
            "sanctioned_ids": [],
        })
        r = _send(daemon, {
            "op": "declare_x402",
            "kind": "counterparty_constraint",
            "approved_ids": [],
            "sanctioned_ids": ["vendor_a"],
        })
        assert r["verdict"] == "contradiction"
        assert "witness" in r
        assert "sanctioned" in r["reason"].lower()

    def test_contradiction_does_not_activate_rule(self, daemon: str) -> None:
        _send(daemon, {
            "op": "declare_x402",
            "kind": "counterparty_constraint",
            "approved_ids": ["vendor_a"],
            "sanctioned_ids": [],
        })
        _send(daemon, {
            "op": "declare_x402",
            "kind": "counterparty_constraint",
            "approved_ids": [],
            "sanctioned_ids": ["vendor_a"],
        })
        # Still only 1 invariant active (the first CounterpartyConstraint);
        # contradiction blocked the second.
        active = _send(daemon, {"op": "active_x402"})
        assert active["active_invariants"] == 1
        assert active["kinds"] == ["CounterpartyConstraint"]


class TestRevisionLog:
    def test_empty_log_on_fresh_daemon(self, daemon: str) -> None:
        r = _send(daemon, {"op": "revision_log"})
        assert r["verdict"] == "ok"
        assert r["length"] == 0
        assert r["revisions"] == []

    def test_log_records_every_successful_revision(self, daemon: str) -> None:
        _send(daemon, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        _send(daemon, {"op": "declare_x402", "kind": "retry_rate_limit", "min_gap_seconds": 5})
        _send(daemon, {"op": "retract_x402", "kind": "max_per_call", "max_amount": "10"})
        r = _send(daemon, {"op": "revision_log"})
        assert r["length"] == 3
        # Chain integrity: each token's predecessor is the previous one's config_hash
        revs = r["revisions"]
        assert revs[0]["predecessor_hash"] is None
        assert revs[1]["predecessor_hash"] == revs[0]["config_hash"]
        assert revs[2]["predecessor_hash"] == revs[1]["config_hash"]

    def test_contradictions_are_not_logged(self, daemon: str) -> None:
        _send(daemon, {
            "op": "declare_x402", "kind": "counterparty_constraint",
            "approved_ids": ["vendor_a"], "sanctioned_ids": [],
        })
        _send(daemon, {
            "op": "declare_x402", "kind": "counterparty_constraint",
            "approved_ids": [], "sanctioned_ids": ["vendor_a"],
        })  # cross-rule sanctioned/approved overlap -> contradiction
        r = _send(daemon, {"op": "revision_log"})
        assert r["length"] == 1  # only the successful declare


class TestRetractProofToken:
    def test_retract_issues_fresh_proof(self, daemon: str) -> None:
        d = _send(daemon, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        r = _send(daemon, {"op": "retract_x402", "kind": "max_per_call", "max_amount": "10"})
        assert r["verdict"] == "retracted"
        assert "proof_token" in r
        # Retracting back to empty set: new token, different config_hash from declare
        assert r["proof_token"]["config_hash"] != d["proof_token"]["config_hash"]
