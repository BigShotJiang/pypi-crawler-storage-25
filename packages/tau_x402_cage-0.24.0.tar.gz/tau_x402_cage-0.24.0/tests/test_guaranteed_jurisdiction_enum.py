"""v1.2.0 tests for JurisdictionRule admission in Guaranteed Mode.

Covers:
* admit / reject cases for the enum_bv variant,
* the dry-run Tau encoding (pure bv BA, no nlang tag, closed G wrapper),
* totality round-trip through ``validate_totality``,
* the nested-composition variant stays out at the variant gate.

The encoding itself is emitted by ``adapter.tau_compiler._v12_encode``;
this file asserts its shape-level properties (balanced parens, bv slot
present, no forbidden substrings). Semantic correctness of the Tau body
is covered when the Tau prover lands in the pipeline — here we just pin
the generator stays decidable and auditable.
"""
from __future__ import annotations

from decimal import Decimal
from types import SimpleNamespace

import pytest

from adapter.guaranteed_errors import GuaranteedFailureCode
from adapter.guaranteed_language import (
    GUARANTEED_LANGUAGE_VERSION,
    GuaranteedLanguage,
)
from adapter.guaranteed_totality import validate_totality
from adapter.invariants import (
    JurisdictionRule,
    MaxPerCall,
    ProviderAllowlist,
)
from adapter.tau_compiler import _v12_encode, dry_run_encode


# ── admission ──────────────────────────────────────────────────────────


def test_jurisdiction_rule_eu_admits():
    ok, code = GuaranteedLanguage.is_supported(
        JurisdictionRule(jurisdiction="EU")
    )
    assert ok is True
    assert code is None


def test_jurisdiction_rule_all_five_codes_admit():
    for code in ("EU", "UK", "US", "APAC", "OTHER"):
        ok, failure = GuaranteedLanguage.is_supported(
            JurisdictionRule(jurisdiction=code)
        )
        assert ok is True
        assert failure is None


def test_jurisdiction_rule_with_additional_invariants_rejected():
    """Nested-composition variant is a different admission path; reject
    at the variant gate, not at the dry-run encoder."""
    ok, code = GuaranteedLanguage.is_supported(
        JurisdictionRule(
            jurisdiction="EU",
            additional_invariants=(MaxPerCall(max_amount=Decimal("10")),),
        )
    )
    assert ok is False
    assert code is GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE


# ── totality ───────────────────────────────────────────────────────────


def _mk_policy(invariants):
    return SimpleNamespace(invariants=tuple(invariants))


def test_totality_jurisdiction_rule_alone_passes():
    report = validate_totality(_mk_policy([JurisdictionRule(jurisdiction="US")]))
    assert report.is_total is True
    assert report.reason_code is None
    assert report.language_version == GUARANTEED_LANGUAGE_VERSION


def test_totality_jurisdiction_composed_with_flat_rules_passes():
    """Realistic composition: an x402 agent restricts jurisdiction AND
    enforces a per-call cap AND a provider allowlist."""
    report = validate_totality(
        _mk_policy(
            [
                JurisdictionRule(jurisdiction="EU"),
                MaxPerCall(max_amount=Decimal("25")),
                ProviderAllowlist(providers=frozenset({"openai", "anthropic"})),
            ]
        )
    )
    assert report.is_total is True


def test_totality_nested_jurisdiction_rejected():
    """Stage-1 rule-type + variant check rejects the nested variant
    before stage 4 encoding runs."""
    report = validate_totality(
        _mk_policy(
            [
                JurisdictionRule(
                    jurisdiction="EU",
                    additional_invariants=(
                        MaxPerCall(max_amount=Decimal("1")),
                    ),
                )
            ]
        )
    )
    assert report.is_total is False
    assert report.reason_code == (
        GuaranteedFailureCode.UNSUPPORTED_FOR_GUARANTEED_MODE.value
    )


# ── dry-run encoding shape ─────────────────────────────────────────────


def test_dry_run_encode_produces_pure_bv_body():
    ok, detail = dry_run_encode(JurisdictionRule(jurisdiction="EU"))
    assert ok is True
    assert detail == ""


def test_v12_encoded_body_is_closed_g_wrapper():
    body = _v12_encode(JurisdictionRule(jurisdiction="EU"))
    assert body.startswith("G(")
    assert body.endswith(")")
    assert body.count("(") == body.count(")")


def test_v12_encoded_body_contains_bv16_slot():
    body = _v12_encode(JurisdictionRule(jurisdiction="US"))
    # The encoding uses bv[16] for jurisdiction enum slots.
    assert ":bv[16]" in body
    # And names the intent_jurisdiction stream so the prover binds it.
    assert "intent_jurisdiction" in body


def test_v12_encoded_body_carries_no_nlang_tag():
    """The whole point of the enum_bv variant: no nlang dependency."""
    for code in ("EU", "UK", "US", "APAC", "OTHER"):
        body = _v12_encode(JurisdictionRule(jurisdiction=code))
        assert ":nlang" not in body
        assert "{<" not in body  # nlang literal opener


def test_v12_encoded_body_is_deterministic():
    """Same input -> same output. Audit pipelines depend on this."""
    a = _v12_encode(JurisdictionRule(jurisdiction="EU"))
    b = _v12_encode(JurisdictionRule(jurisdiction="EU"))
    assert a == b


def test_v12_encoded_body_differs_per_jurisdiction():
    """Different codes -> different bv slots. If two codes collapse to
    the same slot the enum allow-list trivially admits both, violating
    separation of jurisdictions."""
    bodies = {
        code: _v12_encode(JurisdictionRule(jurisdiction=code))
        for code in ("EU", "UK", "US", "APAC", "OTHER")
    }
    # Every body is distinct.
    assert len(set(bodies.values())) == len(bodies)
