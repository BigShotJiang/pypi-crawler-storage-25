"""Tests for the Prometheus metrics surface (v0.9.0).

Every test here gates on ``importorskip("prometheus_client")`` so CI
without the ``[metrics]`` extra still passes clean. The tests cover:

* the :class:`CageMetrics` registry API surface (counter / histogram /
  gauge semantics, label taxonomy validation, snapshot shape);
* daemon-level instrumentation (every admission bumps the right label;
  prover latency records under the correct backend; revisions bump);
* SaaS ``/metrics`` auth (bearer token required, missing token 403,
  wrong token 403, happy path renders Prometheus text format);
* the ``tau-x402-cage metrics`` CLI (``--format=text`` emits the
  exposition, ``--format=json`` emits a snapshot dict).
"""
from __future__ import annotations

import io
import json
import os
import subprocess
import sys
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

import pytest

prom = pytest.importorskip("prometheus_client")


# ── helpers ──────────────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def _reset_default_metrics():
    """Give every test a fresh module-level metrics singleton."""
    from adapter import metrics as m
    m.reset_default()
    yield
    m.reset_default()


def _fresh_metrics():
    from adapter.metrics import CageMetrics
    return CageMetrics()


# ── CageMetrics unit behaviour ───────────────────────────────────────────────


class TestCageMetricsUnit:
    def test_is_available_true(self):
        from adapter.metrics import is_available
        assert is_available() is True

    def test_counter_bumps_each_label(self):
        metrics = _fresh_metrics()
        metrics.record_admission("permit")
        metrics.record_admission("permit")
        metrics.record_admission("reject")
        metrics.record_admission("inconclusive")
        snap = metrics.snapshot()
        assert snap["admissions_total"]["permit"] == 2.0
        assert snap["admissions_total"]["reject"] == 1.0
        assert snap["admissions_total"]["inconclusive"] == 1.0

    def test_counter_coerces_unknown_verdict_to_inconclusive(self):
        metrics = _fresh_metrics()
        metrics.record_admission("garbage")
        assert metrics.snapshot()["admissions_total"]["inconclusive"] == 1.0

    def test_histogram_records_under_correct_backend(self):
        metrics = _fresh_metrics()
        metrics.observe_prover_latency("tau", 0.05)
        metrics.observe_prover_latency("z3", 0.2)
        metrics.observe_prover_latency("tau", 0.12)
        text = metrics.render_text().decode()
        assert 'tau_x402_prover_latency_seconds_count{backend="tau"} 2' in text
        assert 'tau_x402_prover_latency_seconds_count{backend="z3"} 1' in text
        # hybrid and pattern still expose zero-series:
        assert 'tau_x402_prover_latency_seconds_count{backend="hybrid"} 0' in text
        assert 'tau_x402_prover_latency_seconds_count{backend="pattern"} 0' in text

    def test_histogram_rejects_unknown_backend(self):
        metrics = _fresh_metrics()
        with pytest.raises(ValueError):
            metrics.observe_prover_latency("made-up-prover", 0.01)

    def test_histogram_clamps_negative_seconds(self):
        metrics = _fresh_metrics()
        # Should not raise; negative clamped to 0 bucket.
        metrics.observe_prover_latency("tau", -0.5)
        text = metrics.render_text().decode()
        assert 'tau_x402_prover_latency_seconds_count{backend="tau"} 1' in text

    def test_revisions_counter_bumps(self):
        metrics = _fresh_metrics()
        for _ in range(3):
            metrics.record_revision()
        assert metrics.snapshot()["revisions_total"] == 3.0

    def test_proposal_gauge_set_per_status(self):
        metrics = _fresh_metrics()
        metrics.set_proposals("pending", 5)
        metrics.set_proposals("approved", 3)
        metrics.set_proposals("rejected", 1)
        snap = metrics.snapshot()
        assert snap["proposals"]["pending"] == 5
        assert snap["proposals"]["approved"] == 3
        assert snap["proposals"]["rejected"] == 1

    def test_proposal_gauge_rejects_bad_status(self):
        metrics = _fresh_metrics()
        with pytest.raises(ValueError):
            metrics.set_proposals("pretty-sure", 1)

    def test_history_gauge_set_per_stream(self):
        metrics = _fresh_metrics()
        metrics.set_history_size("permit", 1000)
        metrics.set_history_size("reject", 10)
        metrics.set_history_size("verdict", 1010)
        snap = metrics.snapshot()
        assert snap["history_size"]["permit"] == 1000
        assert snap["history_size"]["reject"] == 10
        assert snap["history_size"]["verdict"] == 1010

    def test_history_gauge_rejects_bad_stream(self):
        metrics = _fresh_metrics()
        with pytest.raises(ValueError):
            metrics.set_history_size("pending", 10)

    def test_branches_and_z3_gauges(self):
        metrics = _fresh_metrics()
        metrics.set_branches_active(7)
        metrics.set_z3_push_depth(4)
        snap = metrics.snapshot()
        assert snap["branches_active"] == 7
        assert snap["z3_push_depth"] == 4

    def test_text_scrape_has_help_lines_for_every_metric(self):
        metrics = _fresh_metrics()
        text = metrics.render_text().decode()
        # HELP lines per spec.
        expected = [
            "# HELP tau_x402_admissions_total",
            "# HELP tau_x402_prover_latency_seconds",
            "# HELP tau_x402_revisions_total",
            "# HELP tau_x402_proposals",
            "# HELP tau_x402_history_size",
            "# HELP tau_x402_branches_active",
            "# HELP tau_x402_z3_push_depth",
        ]
        for line in expected:
            assert line in text, f"missing HELP line: {line!r}"

    def test_text_scrape_has_type_lines(self):
        metrics = _fresh_metrics()
        text = metrics.render_text().decode()
        assert "# TYPE tau_x402_admissions_total counter" in text
        assert "# TYPE tau_x402_prover_latency_seconds histogram" in text
        assert "# TYPE tau_x402_revisions_total counter" in text
        assert "# TYPE tau_x402_proposals gauge" in text
        assert "# TYPE tau_x402_history_size gauge" in text
        assert "# TYPE tau_x402_branches_active gauge" in text
        assert "# TYPE tau_x402_z3_push_depth gauge" in text

    def test_default_singleton_is_stable_per_process(self):
        from adapter.metrics import get_default
        a = get_default()
        b = get_default()
        assert a is b


# ── daemon instrumentation ───────────────────────────────────────────────────


_SOCK_COUNTER = [0]


def _daemon_with_metrics(tmp_path):
    """Build a CageDaemon wired to a fresh CageMetrics. No network / sockets."""
    import tempfile
    from adapter.metrics import CageMetrics
    from daemon.server import CageDaemon
    metrics = CageMetrics()
    # Per-test short socket path (macOS UDS limit ~104 chars). We only
    # call dispatch() directly here — the socket is never bound.
    _SOCK_COUNTER[0] += 1
    fd, sock = tempfile.mkstemp(
        prefix=f"tau-metrics-{_SOCK_COUNTER[0]}-", suffix=".sock", dir="/tmp",
    )
    os.close(fd)
    os.unlink(sock)
    d = CageDaemon(socket_path=sock, metrics=metrics)
    return d, metrics


class TestDaemonInstrumentation:
    def test_permit_bumps_permit_label(self, tmp_path):
        d, metrics = _daemon_with_metrics(tmp_path)
        # No invariants = everything permits.
        resp = d.dispatch({
            "op": "check_payment",
            "intent": {
                "amount": "1.00",
                "currency": "USDC",
                "provider": "anthropic",
                "counterparty": "vendor",
                "rail": "x402",
                "timestamp_unix": 1_700_000_000,
            },
        })
        assert resp["verdict"] == "permit"
        snap = metrics.snapshot()
        assert snap["admissions_total"]["permit"] == 1.0
        assert snap["admissions_total"]["reject"] == 0.0

    def test_malformed_request_bumps_reject(self, tmp_path):
        d, metrics = _daemon_with_metrics(tmp_path)
        resp = d.dispatch({"op": "check_payment", "intent": "not-a-dict"})
        assert resp["verdict"] == "reject"
        snap = metrics.snapshot()
        assert snap["admissions_total"]["reject"] == 1.0

    def test_rejected_intent_bumps_reject_label(self, tmp_path):
        d, metrics = _daemon_with_metrics(tmp_path)
        # Declare a provider allowlist that excludes "rogue".
        d.dispatch({
            "op": "declare_x402",
            "kind": "provider_allowlist",
            "providers": ["anthropic"],
        })
        resp = d.dispatch({
            "op": "check_payment",
            "intent": {
                "amount": "1.00",
                "currency": "USDC",
                "provider": "rogue",
                "counterparty": "vendor",
                "rail": "x402",
                "timestamp_unix": 1_700_000_000,
            },
        })
        assert resp["verdict"] == "reject"
        snap = metrics.snapshot()
        assert snap["admissions_total"]["reject"] == 1.0

    def test_declare_bumps_revisions_and_prover_latency(self, tmp_path):
        d, metrics = _daemon_with_metrics(tmp_path)
        resp = d.dispatch({
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "100",
        })
        assert resp["verdict"] == "updated"
        snap = metrics.snapshot()
        assert snap["revisions_total"] == 1.0
        # Admission path attributed under pattern (pure-python pattern prover).
        text = metrics.render_text().decode()
        assert 'tau_x402_prover_latency_seconds_count{backend="pattern"}' in text

    def test_hot_path_latency_recorded_under_pattern(self, tmp_path):
        d, metrics = _daemon_with_metrics(tmp_path)
        d.dispatch({
            "op": "check_payment",
            "intent": {
                "amount": "1.00",
                "currency": "USDC",
                "provider": "anthropic",
                "counterparty": "vendor",
                "rail": "x402",
                "timestamp_unix": 1_700_000_000,
            },
        })
        text = metrics.render_text().decode()
        # At least one observation under pattern.
        assert 'tau_x402_prover_latency_seconds_count{backend="pattern"} 1' in text


# ── SaaS /metrics route ──────────────────────────────────────────────────────


pytest.importorskip("fastapi")


class TestSaasMetricsRoute:
    def _build_app(self, token=None, metrics=None):
        from fastapi import FastAPI
        from saas.metrics_route import build_metrics_router
        app = FastAPI()
        app.include_router(build_metrics_router(metrics=metrics, token=token))
        return app

    def test_metrics_requires_bearer_token(self):
        from fastapi.testclient import TestClient
        metrics = _fresh_metrics()
        app = self._build_app(token="sk_ops_0123", metrics=metrics)
        client = TestClient(app)
        r = client.get("/metrics")
        assert r.status_code == 403

    def test_metrics_rejects_wrong_token(self):
        from fastapi.testclient import TestClient
        metrics = _fresh_metrics()
        app = self._build_app(token="sk_ops_0123", metrics=metrics)
        client = TestClient(app)
        r = client.get("/metrics", headers={"Authorization": "Bearer nope"})
        assert r.status_code == 403

    def test_metrics_succeeds_with_correct_token(self):
        from fastapi.testclient import TestClient
        metrics = _fresh_metrics()
        metrics.record_admission("permit")
        app = self._build_app(token="sk_ops_0123", metrics=metrics)
        client = TestClient(app)
        r = client.get(
            "/metrics", headers={"Authorization": "Bearer sk_ops_0123"}
        )
        assert r.status_code == 200
        assert "text/plain" in r.headers["content-type"]
        body = r.text
        # Every metric name must show up in the exposition.
        assert "tau_x402_admissions_total" in body
        assert "tau_x402_prover_latency_seconds" in body
        assert "tau_x402_revisions_total" in body
        assert "tau_x402_proposals" in body
        assert "tau_x402_history_size" in body
        assert "tau_x402_branches_active" in body
        assert "tau_x402_z3_push_depth" in body
        # HELP lines must be present.
        assert "# HELP tau_x402_admissions_total" in body
        # Counter for permit should be 1.
        assert 'tau_x402_admissions_total{verdict="permit"} 1' in body

    def test_metrics_fails_closed_when_token_unset(self):
        from fastapi.testclient import TestClient
        # Explicit empty token + no env var.
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("TAU_X402_METRICS_TOKEN", None)
            app = self._build_app(token="", metrics=_fresh_metrics())
        client = TestClient(app)
        r = client.get(
            "/metrics", headers={"Authorization": "Bearer anything"}
        )
        assert r.status_code == 403
        assert "not provisioned" in r.json()["detail"]

    def test_metrics_not_mounted_when_env_token_missing(self):
        """SaaS app factory skips the router if the env var is empty."""
        from fastapi.testclient import TestClient
        from saas.app import SaasConfig, create_app
        from saas.billing import NullBillingReporter
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("TAU_X402_METRICS_TOKEN", None)
            cfg = SaasConfig(
                api_keys={"dev": "sk_dev"},
                socket_path="/tmp/does-not-exist.sock",
                hmac_secret=b"\x00" * 32,
                billing=NullBillingReporter(),
            )
            app = create_app(cfg)
        client = TestClient(app)
        r = client.get("/metrics")
        assert r.status_code == 404


# ── CLI ──────────────────────────────────────────────────────────────────────


class TestMetricsCLI:
    def test_cli_text_format_prints_exposition(self, capsys):
        from daemon.cli import main
        # Prime the default metrics so there's at least one non-zero sample.
        from adapter.metrics import get_default
        metrics = get_default()
        metrics.record_admission("permit")
        with patch.object(sys, "argv", ["tau-x402-cage", "metrics", "--format=text"]):
            rc = main()
        assert rc == 0
        out = capsys.readouterr().out
        assert "tau_x402_admissions_total" in out
        assert 'tau_x402_admissions_total{verdict="permit"} 1' in out

    def test_cli_json_format_prints_snapshot(self, capsys):
        from daemon.cli import main
        from adapter.metrics import get_default
        metrics = get_default()
        metrics.record_admission("reject")
        metrics.record_revision()
        with patch.object(sys, "argv", ["tau-x402-cage", "metrics", "--format=json"]):
            rc = main()
        assert rc == 0
        out = capsys.readouterr().out.strip()
        data = json.loads(out)
        assert data["available"] is True
        assert data["admissions_total"]["reject"] == 1.0
        assert data["revisions_total"] == 1.0

    def test_cli_default_format_is_text(self, capsys):
        from daemon.cli import main
        with patch.object(sys, "argv", ["tau-x402-cage", "metrics"]):
            rc = main()
        assert rc == 0
        out = capsys.readouterr().out
        # Text format emits the # HELP lines; json does not.
        assert "# HELP tau_x402_admissions_total" in out
