"""
runtime/loader.py — 工具运行时框架进程级初始化入口

职责：
    进程级一次性初始化，组装框架核心组件（pipeline / policy / registry）并统一管理工具注册。
    loader 只负责注册 RuntimeTool，不构造 StructuredTool。
    StructuredTool 构造由 factory（create_loop_agent）在 graph 构建时负责，
    通过 create_loop_agent(loader=...) 在构图时调用 to_langchain_tools() 构造 StructuredTool。

    policy_config 用于构造 DefaultPolicyEngine，在 register() 时自动注入给每个工具。
    工具无需手动传入 policy，由 loader 统一治理。

装配路径：
    ToolRuntimeLoader(policy_config=...) 构造
        → DefaultPolicyEngine(policy_config)
        → register(tool): 只存储 RuntimeTool，注入 policy
        → 传入 create_loop_agent(loader=loader, ...)
        → factory 内部调用 loader._registry.to_langchain_tools() 构造 StructuredTool
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from langchain_core.tools import BaseTool

from .adapter import LangChainAdapter
from .base import RuntimeTool
from .pipeline import ToolExecutorPipeline, ToolOutputManager
from .policy import DefaultPolicyEngine, PolicyEngine, ToolPolicyConfig
from .registry import RuntimeToolRegistry
from .resolvers import PermissionResolver
from .session_store import AgentSessionStore


class ToolRuntimeLoader:
    """
    工具运行时进程级装配入口。

    policy_config:  策略配置，构造 DefaultPolicyEngine 并自动注入给所有注册工具。
                    为 None 时不注入 policy（工具默认 allow，适用于开发/测试模式）。
    policy_engine:  直接传入自定义 PolicyEngine 实例（优先于 policy_config）。
    output_manager: 工具输出大小管控器，为 None 时使用默认配置。
    headless:       是否处于无交互（headless）模式。
                    True  — check_permissions 返回 ask 时自动降级为 deny（API 调用、CI、批处理场景）。
                    False — check_permissions 返回 ask 时抛出 PermissionAskInterrupt（交互场景，默认）。
                    对应 CC 的 shouldAvoidPermissionPrompts / isNonInteractiveSession。
    """

    def __init__(
        self,
        *,
        policy_config: ToolPolicyConfig | None = None,
        policy_engine: PolicyEngine | None = None,
        output_manager: ToolOutputManager | None = None,
        headless: bool = False,
        permission_resolver: PermissionResolver | None = None,
    ) -> None:
        self._headless = headless
        self._permission_resolver = permission_resolver
        self._pipeline = ToolExecutorPipeline(
            output_manager=output_manager,
            headless=headless,
            permission_resolver=permission_resolver,
        )
        self._adapter = LangChainAdapter()
        self._registry = RuntimeToolRegistry(
            pipeline=self._pipeline,
            adapter=self._adapter,
        )
        # 优先使用外部传入的 policy_engine；其次从 policy_config 构造；否则为 None
        if policy_engine is not None:
            self._policy: PolicyEngine | None = policy_engine
        elif policy_config is not None:
            self._policy = DefaultPolicyEngine(policy_config)
        else:
            self._policy = None

    def register(self, tool: RuntimeTool) -> "ToolRuntimeLoader":
        """
        注册工具并自动注入 PolicyEngine。

        注入规则：
            - 工具已有 _policy（初始化时手动传入）→ 不覆盖，保留工具自己的 policy
            - 工具无 _policy（_policy is None）→ 注入 loader 的统一 policy
        这允许个别工具使用专属 policy，其余工具统一受 loader policy 保护。
        """
        if self._policy is not None and getattr(tool, "_policy", None) is None:
            tool._policy = self._policy
        self._registry.register(tool)
        return self

    def register_default_tools(
        self,
        *,
        workspace_root: str,
        agent_home: str = ".langchain_agentx",
        include_agent: bool = True,
        include_skill: bool = False,
        agent_registry: Any | None = None,
    ) -> "ToolRuntimeLoader":
        """
        注册默认工具集（Read/Grep/Glob/Bash + 可选 Agent/Skill）。

        用于打通默认工具装配链路，避免每个调用方重复手写 register 序列。
        """
        from pathlib import Path

        from langchain_agentx.tools.bash import BashRuntimeTool
        from langchain_agentx.tools.glob import GlobRuntimeTool
        from langchain_agentx.tools.grep import GrepRuntimeTool
        from langchain_agentx.tools.read import ReadRuntimeTool
        from langchain_agentx.tools.ripgrep_plugin_exclusions import PluginCacheGlobExclusions
        from langchain_agentx.tool_runtime.state_bridge import ToolStateBridge
        from langchain_agentx.workspace.config import AgentWorkspaceConfig

        self.register(ReadRuntimeTool())
        default_tool_state_bridge = ToolStateBridge()
        wr = Path(workspace_root).resolve()
        cfg = AgentWorkspaceConfig(workspace_root=wr, agent_home=agent_home)
        plugin_ex = PluginCacheGlobExclusions(
            cache_root=str(cfg.plugin_cache_dir.resolve()),
        )
        self.register(
            GrepRuntimeTool(
                workspace_root=str(wr),
                plugin_cache_glob_exclusions=plugin_ex,
            )
        )
        self.register(
            GlobRuntimeTool(
                workspace_root=str(wr),
                plugin_cache_glob_exclusions=plugin_ex,
                state_bridge=default_tool_state_bridge,
            )
        )
        self.register(BashRuntimeTool())

        if include_agent:
            from langchain_agentx.tools.agent import AgentRuntimeTool

            self.register(AgentRuntimeTool(registry=agent_registry))

        if include_skill:
            from langchain_agentx.tools.skill import SkillRuntimeTool

            self.register(
                SkillRuntimeTool(
                    workspace_root=workspace_root,
                    agent_home=agent_home,
                )
            )

        return self

    def create_session(self, session_id: str | None = None) -> AgentSessionStore:
        return AgentSessionStore(session_id=session_id)

    def fork_with_tools(self, tools: list[RuntimeTool]) -> "ToolRuntimeLoader":
        """
        基于当前 loader 派生一个子 loader（共享 policy/headless 语义），并注册给定工具集。

        目的：为 subagent 组装“过滤后的工具池”而不丢失权限/管控语义。
        """
        child = ToolRuntimeLoader(
            policy_engine=self._policy,
            headless=self._headless,
            permission_resolver=self._permission_resolver,
        )
        for t in tools:
            child.register(t)
        return child

    def set_permission_resolver(
        self,
        permission_resolver: PermissionResolver | None,
    ) -> None:
        """更新 loader 与 pipeline 的 permission_resolver。"""
        self._permission_resolver = permission_resolver
        self._pipeline.set_permission_resolver(permission_resolver)

    @property
    def registry(self) -> RuntimeToolRegistry:
        return self._registry

    @property
    def pipeline(self) -> ToolExecutorPipeline:
        return self._pipeline

    @property
    def adapter(self) -> LangChainAdapter:
        return self._adapter

    def __repr__(self) -> str:
        return f"<ToolRuntimeLoader tools={list(self._registry._tools.keys())}>"
