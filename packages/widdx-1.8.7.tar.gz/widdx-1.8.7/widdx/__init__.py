"""WIDDX CLI — Autonomous AI Orchestration System.

Powered by DeepSeek V4 + 5 Free Models + Google Gemini.
"""

from __future__ import annotations


def _get_version() -> str:
    """Read version from pyproject.toml — single source of truth."""
    try:
        from pathlib import Path
        pyproject = Path(__file__).parent.parent / "pyproject.toml"
        if pyproject.exists():
            for line in pyproject.read_text(encoding="utf-8").splitlines():
                if line.startswith("version ="):
                    return line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    return "1.8.5"


__version__ = _get_version()
