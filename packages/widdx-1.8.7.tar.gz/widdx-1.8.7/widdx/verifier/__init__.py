"""
widdx/verifier/__init__.py -- Verification and Self-Correction System

Ensures output quality through an automatic verify-fix-retry loop at every level:
  - Tool-level: after every Write/Edit, check for syntax errors
  - Agent-level: after agent finishes, run tests and validate
  - Pipeline-level: after all agents, cross-check consistency

Core principle: Write -> Test -> Fix -> Test -> Done (never "write and hope")
"""

from __future__ import annotations

import logging
import os
import re
import shlex
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger("widdx.verifier")

# Maximum self-correction attempts before giving up
MAX_FIX_ATTEMPTS = 3

# Test commands to try (in order) when verifying.
# Each is a plain string without shell redirections — they are parsed
# with shlex.split() and run with shell=False.
TEST_COMMANDS = [
    "python -m pytest tests/ -x --tb=short -q",
    "php artisan test --stop-on-failure",
    "npm test -- --passWithNoTests",
    "go test ./...",
    "cargo test",
]


@dataclass
class VerifyResult:
    """Result of a verification run."""
    passed: bool
    total_tests: int = 0
    failed_tests: int = 0
    errors: list[str] = field(default_factory=list)
    output: str = ""
    fix_attempts: int = 0
    files_snapshotted: list[str] = field(default_factory=list)


class ProjectVerifier:
    """Runs verification and self-correction on code changes.

    The verification loop:
    1. Snapshot files before changes (safety net)
    2. Run appropriate test/lint commands
    3. If tests fail: feed errors back to the LLM for fixing
    4. Re-test (up to MAX_FIX_ATTEMPTS cycles)
    5. If all attempts exhausted: restore from snapshot, report failure
    """

    def __init__(self, router=None, repair_memory=None) -> None:
        self._router = router
        self._repair_memory = repair_memory
        self._snapshots: dict[str, str] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def verify_step(
        self,
        files_changed: list[str],
        auto_fix: bool = True,
    ) -> VerifyResult:
        """Verify after a Write/Edit tool use.

        Args:
            files_changed: List of file paths that were modified.
            auto_fix: If True, attempt automatic fix on failure.

        Returns:
            VerifyResult describing the verification outcome.
        """
        if not files_changed:
            return VerifyResult(passed=True)

        try:
            return self._verify_step_impl(files_changed, auto_fix)
        except Exception as e:
            return VerifyResult(
                passed=True,
                output=f"Verification skipped (tool unavailable): {e}",
            )

    def _verify_step_impl(
        self,
        files_changed: list[str],
        auto_fix: bool = True,
    ) -> VerifyResult:
        """Inner verification logic — wrapped in safety try/except."""
        # Snapshot for rollback
        self._snapshot_files(files_changed)

        # Phase 1: syntax-level check (fast, catches obvious errors)
        syntax_errors = self._syntax_check(files_changed)
        if syntax_errors:
            result = VerifyResult(
                passed=False,
                errors=syntax_errors,
                output="\n".join(syntax_errors),
                files_snapshotted=list(self._snapshots.keys()),
            )
            if auto_fix and (self._router or self._repair_memory):
                return self._auto_fix_loop(result, files_changed)
            return result

        # Phase 2: run tests (slower, catches logic errors)
        test_result = self._run_tests()
        if not test_result.passed:
            if auto_fix and (self._router or self._repair_memory):
                return self._auto_fix_loop(test_result, files_changed)
            return test_result

        # All good -- clear snapshots
        self._clear_snapshots()
        return test_result

    def verify_agent(
        self,
        agent_output: str,
        files_created: list[str],
        files_edited: list[str],
    ) -> VerifyResult:
        """Verify after an agent completes its work.

        More thorough than verify_step: runs the full test suite
        and validates all agent outputs.
        """
        all_files = list(set(files_created + files_edited))
        if not all_files:
            return VerifyResult(passed=True)

        self._snapshot_files(all_files)

        # Run full test suite
        test_result = self._run_tests(full_suite=True)
        if not test_result.passed and self._router:
            return self._auto_fix_loop(test_result, all_files)

        self._clear_snapshots()
        return test_result

    def verify_pipeline(
        self,
        all_files: list[str] | None = None,
    ) -> VerifyResult:
        """Final verification after all agents in a pipeline finish.

        If no files provided, detects changed files via git diff.

        Checks:
        - All tests pass across the entire project
        - All changed files have valid syntax
        """
        if all_files is None:
            all_files = self._detect_changed_files()

        if not all_files:
            return VerifyResult(passed=True)

        # Deduplicate
        all_files = list(dict.fromkeys(all_files))

        if not all_files:
            return VerifyResult(passed=True)

        # Snapshot everything
        self._snapshot_files(all_files)

        # Run full test suite
        test_result = self._run_tests(full_suite=True)

        # Also check for import/syntax errors across all new files
        syntax_errors = self._syntax_check(all_files)
        if syntax_errors:
            test_result.passed = False
            test_result.errors.extend(syntax_errors)

        if not test_result.passed and self._router:
            return self._auto_fix_loop(test_result, all_files)

        self._clear_snapshots()
        return test_result

    # ------------------------------------------------------------------
    # Self-correction loop
    # ------------------------------------------------------------------

    def _auto_fix_loop(
        self,
        initial_result: VerifyResult,
        files: list[str],
    ) -> VerifyResult:
        """Attempt automatic fixes for failing tests.

        Phase 1: Check RepairMemory for known fix patterns (free).
        Phase 2: If no known fix, call LLM for a fix.
        Phase 3: If LLM fix succeeds, store the pattern.
        """
        errors = initial_result.errors
        language = self._detect_language(files)

        # ── Phase 1: Check RepairMemory ─────────────────────────────
        if self._repair_memory and self._repair_memory.is_enabled:
            matched = self._repair_memory.lookup(errors, language)
            if matched:
                best = matched[0]
                logger.info(
                    "RepairMemory hit: fp=%s conf=%.2f",
                    best["fingerprint"][:12], best["confidence"],
                )
                fix_text = best["fix_template"]
                applied = self._apply_fixes(fix_text, files)
                if applied:
                    re_result = self._run_tests()
                    re_result.fix_attempts = 0
                    if re_result.passed:
                        self._repair_memory.record_success(best["fingerprint"])
                        self._clear_snapshots()
                        return re_result
                    self._repair_memory.record_failure(best["fingerprint"])
                    self._rollback()
                    self._snapshot_files(files)

        # ── Phase 2: LLM fix loop ─────────────────────────────────
        for attempt in range(1, MAX_FIX_ATTEMPTS + 1):
            fix_prompt = self._build_fix_prompt(
                errors=errors,
                test_output=initial_result.output,
                files=files,
                attempt=attempt,
            )

            system = (
                "You are a senior developer fixing failing tests. "
                "Read the error output and the current file contents, then fix the code. "
                "Make minimal changes. Only fix what's broken. "
                "Reply with the fixed code for each file that needs changes."
            )
            result = self._router.call_executor(system, fix_prompt, max_tokens=4096)

            if "error" in result:
                continue

            fix_text = result.get("text", "")

            applied = self._apply_fixes(fix_text, files)
            if not applied:
                continue

            re_result = self._run_tests()
            re_result.fix_attempts = attempt

            if re_result.passed:
                # ── Phase 3: Store successful fix pattern ──────────
                if self._repair_memory and self._repair_memory.is_enabled and errors:
                    from ..repair_memory import RepairMemory
                    fingerprint = self._repair_memory.store(
                        errors=errors,
                        fix_template=RepairMemory.extract_fix_template(
                            fix_text, files,
                        ),
                        language=language,
                        file_pattern=self._infer_file_pattern(files),
                    )
                    if fingerprint:
                        logger.info("Stored fix pattern: fp=%s", fingerprint[:12])
                self._clear_snapshots()
                return re_result

            errors = re_result.errors
            initial_result = re_result

        # All attempts exhausted -- rollback
        self._rollback()
        return VerifyResult(
            passed=False,
            errors=[
                f"Self-correction failed after {MAX_FIX_ATTEMPTS} attempts. "
                "Changes have been rolled back to the previous state."
            ],
            fix_attempts=MAX_FIX_ATTEMPTS,
            files_snapshotted=list(self._snapshots.keys()),
        )

    # ------------------------------------------------------------------
    # Test execution
    # ------------------------------------------------------------------

    def _run_tests(self, full_suite: bool = False) -> VerifyResult:
        """Run the project's test suite.

        Tries multiple test commands and uses the first one that works.
        Commands are parsed with ``shlex.split`` and run with ``shell=False``.
        """
        for cmd_str in TEST_COMMANDS:
            try:
                args = shlex.split(cmd_str, posix=(sys.platform != "win32"))
            except ValueError:
                args = cmd_str.split()
            try:
                proc = subprocess.run(
                    args,
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=120,
                    cwd=Path.cwd(),
                )
            except (subprocess.TimeoutExpired, OSError):
                continue

            output = (proc.stdout + proc.stderr).strip()

            # Parse test results
            total, failed = self._parse_test_output(output)

            if total > 0:
                return VerifyResult(
                    passed=proc.returncode == 0 and failed == 0,
                    total_tests=total,
                    failed_tests=failed,
                    output=output[-4000:],  # Keep last 4000 chars for error context
                    errors=self._extract_errors(output),
                )

        # No test command worked -- assume passed (no test framework found)
        return VerifyResult(passed=True, output="No test framework detected")

    # ------------------------------------------------------------------
    # Syntax checking
    # ------------------------------------------------------------------

    def _syntax_check(self, files: list[str]) -> list[str]:
        """Fast syntax validation for changed files."""
        errors: list[str] = []
        for f in files:
            try:
                path = Path(f)
                if not path.exists():
                    continue
                if path.suffix == ".py":
                    try:
                        compile(path.read_text(encoding="utf-8"), f, "exec")
                    except SyntaxError as e:
                        errors.append(f"SyntaxError in {f}:{e.lineno}: {e.msg}")
                elif path.suffix == ".json":
                    try:
                        import json
                        json.loads(path.read_text(encoding="utf-8"))
                    except json.JSONDecodeError as e:
                        errors.append(f"JSON Error in {f}:{e.lineno}: {e.msg}")
                elif path.suffix in (".php",):
                    try:
                        proc = subprocess.run(
                            ["php", "-l", f],
                            shell=False,
                            capture_output=True,
                            text=True,
                            timeout=10,
                        )
                        if proc.returncode != 0:
                            errors.append(proc.stderr.strip() or proc.stdout.strip())
                    except (FileNotFoundError, OSError):
                        pass
                elif path.suffix in (".js",):
                    try:
                        proc = subprocess.run(
                            ["node", "--check", f],
                            shell=False,
                            capture_output=True,
                            text=True,
                            timeout=10,
                        )
                        if proc.returncode != 0:
                            errors.append(proc.stderr.strip() or proc.stdout.strip())
                    except (FileNotFoundError, OSError):
                        pass
            except Exception:
                logger.debug("Syntax check failed for file", exc_info=True)
        return errors

    # ------------------------------------------------------------------
    # File snapshots
    # ------------------------------------------------------------------

    def _snapshot_files(self, files: list[str]) -> None:
        """Save copies of files before modification for rollback."""
        for f in files:
            path = Path(f)
            if path.exists() and f not in self._snapshots:
                try:
                    self._snapshots[f] = path.read_text(encoding="utf-8")
                except OSError:
                    pass

    def _rollback(self) -> None:
        """Restore all snapshotted files to their original state."""
        for f, content in self._snapshots.items():
            try:
                Path(f).write_text(content, encoding="utf-8")
            except OSError:
                pass
        self._snapshots.clear()

    def _clear_snapshots(self) -> None:
        self._snapshots.clear()

    # ------------------------------------------------------------------
    # Fix prompt and application
    # ------------------------------------------------------------------

    def _build_fix_prompt(
        self,
        errors: list[str],
        test_output: str,
        files: list[str],
        attempt: int,
    ) -> str:
        """Build a prompt that asks the LLM to fix failing code."""
        file_contents = ""
        for f in files:
            path = Path(f)
            if path.exists():
                try:
                    content = path.read_text(encoding="utf-8")
                    file_contents += f"\n### {f}\n```\n{content[:3000]}\n```\n"
                except OSError:
                    pass

        return (
            f"Fix attempt {attempt}/{MAX_FIX_ATTEMPTS}.\n\n"
            f"## Errors\n{chr(10).join(errors)}\n\n"
            f"## Test Output\n{test_output[-3000:]}\n\n"
            f"## Current Files\n{file_contents}\n\n"
            f"Fix the code to resolve all errors. "
            f"Output each fixed file with its path and the complete corrected code."
        )

    def _apply_fixes(self, fix_text: str, files: list[str]) -> bool:
        """Extract code blocks from LLM response and apply to files."""
        applied = False

        # Match: ### filename\n```\ncode\n```
        pattern = r"(?:###?\s*([^\n]+)\s*\n)?```(?:[a-z]*\n)?(.*?)\n```"
        matches = re.findall(pattern, fix_text, re.DOTALL)

        for filename_hint, code in matches:
            filename_hint = filename_hint.strip()
            # Try to match hint to actual file
            target = None
            for f in files:
                fname = Path(f).name
                if filename_hint and (fname in filename_hint or filename_hint in fname):
                    target = f
                    break
            if target is None and files:
                target = files[0]  # fallback to first file

            if target and len(code.strip()) > 10:
                try:
                    Path(target).write_text(code.strip(), encoding="utf-8")
                    applied = True
                except OSError:
                    pass

        return applied

    # ------------------------------------------------------------------
    # Language & file pattern helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_language(files: list[str]) -> str:
        """Detect the primary programming language from file extensions."""
        ext_map = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".tsx": "typescript",
            ".jsx": "javascript",
            ".php": "php",
            ".go": "go",
            ".rs": "rust",
            ".java": "java",
            ".rb": "ruby",
            ".cs": "csharp",
            ".swift": "swift",
            ".kt": "kotlin",
            ".json": "json",
            ".sql": "sql",
        }
        for f in files:
            ext = Path(f).suffix.lower()
            if ext in ext_map:
                return ext_map[ext]
        return "python"

    @staticmethod
    def _infer_file_pattern(files: list[str]) -> str:
        """Infer a file pattern from the list of changed files."""
        if not files:
            return ""
        try:
            common = Path(files[0]).suffix
            for f in files[1:]:
                if Path(f).suffix != common:
                    common = ""
                    break
            if common:
                return f"*{common}"
        except (ValueError, IndexError):
            pass
        return ""

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Build verification
    # ------------------------------------------------------------------

    def verify_build(self) -> dict:
        """Try to build the project (compile, bundle, or check syntax).

        Returns a dict with keys: passed (bool), status (str), output (str).
        """
        cwd = Path.cwd()

        build_commands = self._detect_build_commands(cwd)
        for label, cmd, args in build_commands:
            try:
                proc = subprocess.run(
                    args if isinstance(args, list) else [cmd] + (args or []),
                    shell=isinstance(cmd, str) and " " in cmd,
                    capture_output=True,
                    text=True,
                    timeout=120,
                    cwd=cwd,
                )
                if proc.returncode == 0:
                    return {"passed": True, "status": f"Build OK ({label})", "output": label}
                return {
                    "passed": False,
                    "status": f"Build failed ({label})",
                    "output": (proc.stderr or proc.stdout or "").strip()[:2000],
                }
            except (subprocess.TimeoutExpired, OSError):
                continue

        return {"passed": True, "status": "No build tool detected", "output": ""}

    @staticmethod
    def _detect_build_commands(cwd: Path) -> list[tuple[str, str, list[str] | None]]:
        """Detect which build tool to run based on project files."""
        commands: list[tuple[str, str, list[str] | None]] = []

        if (cwd / "package.json").exists():
            commands.append(("npm run build", "npm", ["run", "build"]))
            commands.append(("npx tsc --noEmit", "npx", ["tsc", "--noEmit"]))

        if (cwd / "composer.json").exists():
            commands.append(("composer validate", "composer", ["validate"]))

        if (cwd / "pyproject.toml").exists():
            commands.append(("pip install -e .", "pip", ["install", "-e", "."]))

        if (cwd / "artisan").exists():
            commands.append(("php artisan optimize", "php", ["artisan", "optimize"]))

        if (cwd / "manage.py").exists():
            commands.append(("python manage.py check", "python", ["manage.py", "check"]))

        return commands

    @staticmethod
    def _detect_changed_files() -> list[str]:
        """Detect files changed in the working tree via git diff."""
        try:
            proc = subprocess.run(
                ["git", "diff", "--name-only", "HEAD"],
                shell=False,
                capture_output=True,
                text=True,
                timeout=10,
                cwd=Path.cwd(),
            )
            if proc.returncode == 0:
                return [f for f in proc.stdout.strip().split("\n") if f]
        except (subprocess.TimeoutExpired, OSError):
            pass
        # Fallback: git status
        try:
            proc = subprocess.run(
                ["git", "status", "--porcelain"],
                shell=False,
                capture_output=True,
                text=True,
                timeout=10,
                cwd=Path.cwd(),
            )
            if proc.returncode == 0:
                files = []
                for line in proc.stdout.strip().split("\n"):
                    if line and len(line) > 3:
                        files.append(line[3:].strip())
                return files
        except (subprocess.TimeoutExpired, OSError):
            pass
        return []

    @staticmethod
    def _parse_test_output(output: str) -> tuple[int, int]:
        """Parse test output to extract total and failed counts."""
        total, failed = 0, 0

        # pytest: "3 passed, 1 failed"
        m = re.search(r"(\d+)\s+passed", output)
        if m:
            total += int(m.group(1))
        m = re.search(r"(\d+)\s+failed", output)
        if m:
            failed += int(m.group(1))
            total += int(m.group(1))

        # PHPUnit: "Tests: 5, Assertions: 10, Failures: 1"
        m = re.search(r"Tests:\s*(\d+).*Failures:\s*(\d+)", output)
        if m:
            total = int(m.group(1))
            failed = int(m.group(2))

        # Jest: "Tests: 5 failed, 10 passed, 15 total"
        m = re.search(r"Tests:.*?(\d+)\s+total", output)
        if m:
            total = int(m.group(1))
        m = re.search(r"(\d+)\s+failed", output)
        if m:
            failed = int(m.group(1))

        # Go: "FAIL    pkg/path [build failed]"
        if "FAIL" in output and total == 0:
            failed = 1
            total = 1

        return total, failed

    @staticmethod
    def _extract_errors(output: str) -> list[str]:
        """Extract error lines from test output."""
        errors: list[str] = []
        for line in output.split("\n"):
            stripped = line.strip()
            if any(
                marker in stripped
                for marker in ("FAILED", "FAIL:", "Error:", "error:", "assert", "AssertionError")
            ):
                errors.append(stripped[:200])
        return errors[-10:]  # Keep last 10 errors max


__all__ = ["ProjectVerifier", "VerifyResult"]
