"""
widdx/mcp/client.py — MCP transport clients (GAP-1, tasks 6.2 & 6.3)

MCPClient      — communicates with one MCP server via JSON-RPC 2.0 over stdin/stdout.
MCPHTTPClient  — communicates with one MCP server via JSON-RPC 2.0 over HTTP POST.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import urllib.error
import urllib.request
from typing import Any

logger = logging.getLogger(__name__)

# Timeout in seconds for waiting on a JSON-RPC response.
_RESPONSE_TIMEOUT = 30.0

# MCP protocol version this client speaks.
_PROTOCOL_VERSION = "2024-11-05"


class MCPClient:
    """Communicates with one MCP server via stdio JSON-RPC.

    The server is launched as a subprocess.  Every request is a JSON object
    terminated by a newline; responses arrive the same way.

    Usage::

        client = MCPClient("github", "uvx", args=["mcp-server-github"],
                           env={"GITHUB_TOKEN": "ghp_..."})
        client.connect()
        tools = client.list_tools()
        result = client.call_tool("create_issue", {"title": "Bug"})
        client.disconnect()
    """

    def __init__(
        self,
        name: str,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        self._name = name
        self._command = command
        self._args: list[str] = args or []
        self._env: dict[str, str] | None = env
        self._process: subprocess.Popen[bytes] | None = None
        self._id_counter: int = 0
        # Lock so concurrent callers don't interleave writes/reads.
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Start the server process and perform the MCP handshake.

        Sends ``initialize`` and waits for the server's capabilities reply,
        then sends the ``initialized`` notification.

        Raises:
            RuntimeError: If the process fails to start or the handshake fails.
            TimeoutError: If the server does not respond within 30 seconds.
        """
        merged_env = {**os.environ}
        if self._env:
            merged_env.update(self._env)

        cmd = [self._command, *self._args]
        try:
            self._process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=merged_env,
            )
        except (OSError, FileNotFoundError) as exc:
            self._process = None
            raise RuntimeError(
                f"Failed to start MCP server '{self._name}' with command {cmd!r}: {exc}"
            ) from exc

        # MCP handshake: initialize → initialized
        try:
            response = self._send(
                "initialize",
                {
                    "protocolVersion": _PROTOCOL_VERSION,
                    "capabilities": {},
                    "clientInfo": {"name": "widdx", "version": __import__("widdx").__version__},
                },
            )
        except Exception as exc:
            self._terminate()
            raise RuntimeError(
                f"MCP handshake failed for server '{self._name}': {exc}"
            ) from exc

        if "error" in response:
            self._terminate()
            raise RuntimeError(
                f"MCP server '{self._name}' rejected initialize: {response['error']}"
            )

        # Acknowledge — no response expected.
        self._notify("notifications/initialized")
        logger.debug("Connected to MCP server '%s'", self._name)

    def list_tools(self) -> list[dict]:
        """Call ``tools/list`` and return the raw tool schema list.

        Returns:
            List of tool dicts as returned by the server (each has at least
            ``name`` and optionally ``description`` and ``inputSchema``).

        Raises:
            RuntimeError: If not connected or the server returns an error.
        """
        self._require_connected()
        response = self._send("tools/list")
        if "error" in response:
            raise RuntimeError(
                f"tools/list failed on server '{self._name}': {response['error']}"
            )
        result = response.get("result", {})
        return list(result.get("tools", []))

    def call_tool(self, name: str, arguments: dict) -> dict:
        """Call ``tools/call`` and return the result dict.

        Args:
            name:      Tool name as reported by ``list_tools``.
            arguments: Arguments dict matching the tool's ``inputSchema``.

        Returns:
            Result dict from the server.

        Raises:
            RuntimeError: If not connected or the server returns an error.
        """
        self._require_connected()
        response = self._send("tools/call", {"name": name, "arguments": arguments})
        if "error" in response:
            raise RuntimeError(
                f"tools/call '{name}' failed on server '{self._name}': {response['error']}"
            )
        return dict(response.get("result", {}))

    def disconnect(self) -> None:
        """Terminate the server subprocess cleanly."""
        self._terminate()

    # ------------------------------------------------------------------
    # Internal transport
    # ------------------------------------------------------------------

    def _send(self, method: str, params: dict | None = None) -> dict:
        """Send a JSON-RPC request and return the parsed response dict.

        The response dict contains either a ``result`` key (success) or an
        ``error`` key (JSON-RPC error).

        Args:
            method: JSON-RPC method name.
            params: Optional parameters dict.

        Returns:
            Parsed JSON-RPC response as a plain dict.

        Raises:
            RuntimeError: If the process is not running or the pipe is broken.
            TimeoutError: If no response arrives within ``_RESPONSE_TIMEOUT``.
        """
        self._require_connected()
        assert self._process is not None  # for type checker

        self._id_counter += 1
        request_id = self._id_counter

        message: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }
        if params is not None:
            message["params"] = params

        raw = (json.dumps(message) + "\n").encode("utf-8")

        with self._lock:
            try:
                assert self._process.stdin is not None
                self._process.stdin.write(raw)
                self._process.stdin.flush()
            except BrokenPipeError as exc:
                raise RuntimeError(
                    f"MCP server '{self._name}' stdin pipe broken: {exc}"
                ) from exc

            return self._read_response(request_id)

    def _notify(self, method: str, params: dict | None = None) -> None:
        """Send a JSON-RPC notification (no ``id``, no response expected).

        Args:
            method: JSON-RPC method name.
            params: Optional parameters dict.
        """
        if self._process is None:
            return

        message: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            message["params"] = params

        raw = (json.dumps(message) + "\n").encode("utf-8")
        try:
            assert self._process.stdin is not None
            self._process.stdin.write(raw)
            self._process.stdin.flush()
        except BrokenPipeError:
            logger.warning("MCP server '%s': broken pipe while sending notification", self._name)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _read_response(self, expected_id: int) -> dict:
        """Read lines from stdout until we find the response for *expected_id*.

        Skips any notifications (lines without an ``id`` field) that arrive
        before the response.

        Args:
            expected_id: The request ID we are waiting for.

        Returns:
            Parsed response dict.

        Raises:
            TimeoutError: If no matching response arrives within the timeout.
            RuntimeError: If the stdout pipe closes unexpectedly.
        """
        assert self._process is not None
        assert self._process.stdout is not None

        # Use a threading.Event + background reader so we can enforce a timeout
        # without blocking the GIL indefinitely on readline().
        result_holder: list[dict] = []
        error_holder: list[Exception] = []
        done = threading.Event()

        def _reader() -> None:
            try:
                while True:
                    line = self._process.stdout.readline()  # type: ignore[union-attr]
                    if not line:
                        error_holder.append(
                            RuntimeError(
                                f"MCP server '{self._name}' stdout closed unexpectedly"
                            )
                        )
                        done.set()
                        return
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                    except json.JSONDecodeError as exc:
                        logger.warning(
                            "MCP server '%s' sent non-JSON line: %r (%s)",
                            self._name,
                            line[:200],
                            exc,
                        )
                        continue
                    # Skip notifications (no id) and responses for other ids.
                    if msg.get("id") == expected_id:
                        result_holder.append(msg)
                        done.set()
                        return
                    # Log unexpected messages at debug level and keep reading.
                    logger.debug(
                        "MCP server '%s': ignoring message id=%r while waiting for id=%d",
                        self._name,
                        msg.get("id"),
                        expected_id,
                    )
            except Exception as exc:  # noqa: BLE001
                error_holder.append(exc)
                done.set()

        reader_thread = threading.Thread(target=_reader, daemon=True)
        reader_thread.start()

        if not done.wait(timeout=_RESPONSE_TIMEOUT):
            raise TimeoutError(
                f"MCP server '{self._name}' did not respond within {_RESPONSE_TIMEOUT}s "
                f"(method id={expected_id})"
            )

        if error_holder:
            raise error_holder[0]

        return result_holder[0]

    def _require_connected(self) -> None:
        """Raise RuntimeError if the subprocess is not running."""
        if self._process is None or self._process.poll() is not None:
            raise RuntimeError(
                f"MCP server '{self._name}' is not connected. Call connect() first."
            )

    def _terminate(self) -> None:
        """Terminate the subprocess if it is still running."""
        if self._process is None:
            return
        try:
            if self._process.poll() is None:
                self._process.terminate()
                try:
                    self._process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self._process.kill()
        except OSError:
            pass
        finally:
            self._process = None


class MCPHTTPClient:
    """Communicates with one MCP server via HTTP JSON-RPC 2.0 (POST /).

    The server must accept JSON-RPC 2.0 requests as HTTP POST to its base URL.
    Uses only ``urllib.request`` from the standard library — no extra dependencies.

    mcp.json entry format::

        {
          "mcpServers": {
            "remote-server": {
              "url": "http://localhost:8080",
              "headers": { "Authorization": "Bearer token" }
            }
          }
        }

    Usage::

        client = MCPHTTPClient("remote", "http://localhost:8080",
                               headers={"Authorization": "Bearer tok"})
        client.connect()
        tools = client.list_tools()
        result = client.call_tool("search", {"query": "hello"})
        client.disconnect()
    """

    def __init__(
        self,
        name: str,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> None:
        self._name = name
        self._url = url.rstrip("/")
        self._headers: dict[str, str] = headers or {}
        self._id_counter: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Verify the server is reachable by sending an ``initialize`` request.

        Raises:
            RuntimeError: If the server is unreachable or rejects the handshake.
            TimeoutError: If the server does not respond within 30 seconds.
        """
        response = self._send(
            "initialize",
            {
                "protocolVersion": _PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "widdx", "version": "1.4.0"},
            },
        )
        if "error" in response:
            raise RuntimeError(
                f"MCP HTTP server '{self._name}' rejected initialize: {response['error']}"
            )
        logger.debug("Connected to MCP HTTP server '%s' at %s", self._name, self._url)

    def list_tools(self) -> list[dict]:
        """Send ``tools/list`` and return the raw tool schema list.

        Returns:
            List of tool dicts as returned by the server.

        Raises:
            RuntimeError: If the server returns an error.
        """
        response = self._send("tools/list")
        if "error" in response:
            raise RuntimeError(
                f"tools/list failed on HTTP server '{self._name}': {response['error']}"
            )
        result = response.get("result", {})
        return list(result.get("tools", []))

    def call_tool(self, name: str, arguments: dict) -> dict:
        """Send ``tools/call`` and return the result dict.

        Args:
            name:      Tool name as reported by ``list_tools``.
            arguments: Arguments dict matching the tool's ``inputSchema``.

        Returns:
            Result dict from the server.

        Raises:
            RuntimeError: If the server returns an error.
        """
        response = self._send("tools/call", {"name": name, "arguments": arguments})
        if "error" in response:
            raise RuntimeError(
                f"tools/call '{name}' failed on HTTP server '{self._name}': {response['error']}"
            )
        return dict(response.get("result", {}))

    def disconnect(self) -> None:
        """No-op — HTTP is stateless; nothing to tear down."""

    # ------------------------------------------------------------------
    # Internal transport
    # ------------------------------------------------------------------

    def _send(self, method: str, params: dict | None = None) -> dict:
        """Send a JSON-RPC 2.0 request via HTTP POST and return the parsed response.

        Args:
            method: JSON-RPC method name.
            params: Optional parameters dict.

        Returns:
            Parsed JSON-RPC response as a plain dict.

        Raises:
            RuntimeError: If the HTTP request fails or the response is not valid JSON.
            TimeoutError: If the server does not respond within ``_RESPONSE_TIMEOUT``.
        """
        self._id_counter += 1
        request_id = self._id_counter

        message: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }
        if params is not None:
            message["params"] = params

        body = json.dumps(message).encode("utf-8")

        req = urllib.request.Request(
            self._url,
            data=body,
            method="POST",
        )
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")
        for header_name, header_value in self._headers.items():
            req.add_header(header_name, header_value)

        try:
            with urllib.request.urlopen(req, timeout=_RESPONSE_TIMEOUT) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as exc:
            raise RuntimeError(
                f"MCP HTTP server '{self._name}' returned HTTP {exc.code}: {exc.reason}"
            ) from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(
                f"MCP HTTP server '{self._name}' is unreachable at {self._url}: {exc.reason}"
            ) from exc
        except TimeoutError as exc:
            raise TimeoutError(
                f"MCP HTTP server '{self._name}' did not respond within {_RESPONSE_TIMEOUT}s"
            ) from exc

        try:
            return dict(json.loads(raw))
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                f"MCP HTTP server '{self._name}' returned non-JSON response: {exc}"
            ) from exc


__all__ = ["MCPClient", "MCPHTTPClient"]
