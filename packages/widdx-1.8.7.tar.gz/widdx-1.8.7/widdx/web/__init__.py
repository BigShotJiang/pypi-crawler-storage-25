"""WIDDX Web UI — FastAPI server with SSE streaming and professional dashboard.

Start:  widdx web          (opens http://localhost:8520)
        widdx web --port 9000
        widdx web --no-open
"""
from __future__ import annotations

import asyncio
import json
import logging
import queue
import threading
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

try:
    from fastapi import FastAPI, Request
    from fastapi.responses import StreamingResponse, HTMLResponse, JSONResponse
    import uvicorn
    HAS_WEB = True
except ImportError:
    HAS_WEB = False


class WiddxWebServer:
    """Embedded web server that exposes WIDDX via a browser-based UI."""

    def __init__(self, port: int = 8520, open_browser: bool = True) -> None:
        if not HAS_WEB:
            raise ImportError("Web UI requires: pip install fastapi uvicorn")
        self._port = port
        self._open_browser = open_browser
        self._app = FastAPI(title="WIDDX Web UI", version=__import__("widdx").__version__, docs_url=None, redoc_url=None)
        self._sessions: dict[str, dict] = {}
        self._setup_routes()

    def _setup_routes(self) -> None:
        app = self._app

        @app.get("/", response_class=HTMLResponse)
        async def index():
            return _get_html()

        @app.get("/api/status")
        async def status():
            return {"status": "running", "version": __import__("widdx").__version__}

        @app.post("/api/chat")
        async def chat(request: Request):
            data = await request.json()
            task = data.get("task", "").strip()
            session_id = data.get("session_id", str(time.time_ns()))
            if not task:
                return JSONResponse({"error": "Empty task"}, status_code=400)
            session = self._get_or_create_session(session_id)
            return StreamingResponse(
                self._stream_task(task, session_id, session),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )

        @app.get("/api/files")
        async def list_files(path: str = "."):
            p = Path(path).resolve()
            if not p.exists():
                return {"files": [], "error": f"Path not found: {path}"}
            files = []
            try:
                for item in sorted(p.iterdir()):
                    if item.name.startswith(".") or item.name == "__pycache__":
                        continue
                    files.append({
                        "name": item.name, "path": str(item),
                        "type": "dir" if item.is_dir() else "file",
                        "size": item.stat().st_size if item.is_file() else 0,
                    })
            except PermissionError:
                pass
            return {"files": files, "cwd": str(p)}

        @app.get("/api/file")
        async def read_file(path: str):
            p = Path(path)
            if not p.exists() or not p.is_file():
                return JSONResponse({"error": "File not found"}, status_code=404)
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
                return {"content": content, "path": str(p), "size": p.stat().st_size}
            except Exception as e:
                return JSONResponse({"error": str(e)}, status_code=500)

        @app.get("/api/health")
        async def health():
            providers = []
            try:
                from widdx.config import load_config
                from widdx.router import AIRouter
                config = load_config()
                router = AIRouter(config, None)
                providers = router.list_providers()
            except Exception:
                pass
            return {"status": "healthy", "python": True, "providers": [p["name"] for p in providers]}

        @app.get("/api/project")
        async def project_info():
            """Return project summary for dashboard."""
            cwd = Path.cwd()
            files = []
            try:
                files = [f.name for f in sorted(cwd.iterdir())
                        if not f.name.startswith(".") and f.is_file()][:20]
            except Exception:
                pass
            return {"cwd": str(cwd), "name": cwd.name, "files": files,
                    "files_count": len(list(cwd.glob("*")))}

    def _get_or_create_session(self, session_id: str) -> dict:
        if session_id not in self._sessions:
            self._sessions[session_id] = {
                "id": session_id, "created_at": time.time(),
                "history": [], "created_files": [], "edited_files": [],
            }
        return self._sessions[session_id]

    async def _stream_task(self, task: str, session_id: str, session: dict):
        q: queue.Queue = queue.Queue()
        yield f"data: {json.dumps({'type': 'start', 'task': task})}\n\n"

        def run_in_thread():
            try:
                from widdx.config import load_config
                from widdx.memory import MemoryStore
                from widdx.router import AIRouter
                from widdx.tool_loop import ToolLoop
                config = load_config()
                memory = MemoryStore(config.get("memory", {}).get("db_path", "~/.widdx/memory.db"))
                router = AIRouter(config, memory)

                # Patch display BEFORE creating ToolLoop so it picks up our captures
                import widdx.tool_loop.display as dm
                import widdx.tool_loop as tl
                _orig_call = dm.print_tool_call
                _orig_result = dm.print_tool_result

                def _cap_call(name, args):
                    q.put({"type": "tool_call", "name": name, "args": args})

                def _cap_result(name, output):
                    q.put({"type": "tool_result", "name": name, "output": output})

                dm.print_tool_call = _cap_call
                dm.print_tool_result = _cap_result
                # Also patch the module-level references that ToolLoop imported
                tl.print_tool_call = _cap_call
                tl.print_tool_result = _cap_result

                loop = ToolLoop(router, max_steps=15)
                q.put({"type": "thinking", "text": "Analyzing task..."})

                result = loop.run(task)

                # Restore originals
                dm.print_tool_call = _orig_call
                dm.print_tool_result = _orig_result

                session["history"].append({"role": "user", "content": task})
                session["history"].append({"role": "assistant", "content": result[:2000]})
                session["created_files"] = list(loop._created_files) if hasattr(loop, '_created_files') else []
                session["edited_files"] = list(loop._edited_files) if hasattr(loop, '_edited_files') else []
                created = list(loop._created_files) if hasattr(loop, '_created_files') else []
                edited = list(loop._edited_files) if hasattr(loop, '_edited_files') else []

                q.put({"type": "done", "result": result[:5000],
                       "files": {"created": created, "edited": edited}})
            except Exception as e:
                logger.exception("Task execution failed")
                q.put({"type": "error", "text": str(e)[:500]})

        thread = threading.Thread(target=run_in_thread, daemon=True)
        thread.start()

        last_hb = time.time()
        while thread.is_alive() or not q.empty():
            try:
                event = q.get(timeout=0.1)
                yield f"data: {json.dumps(event, default=str)}\n\n"
                last_hb = time.time()
            except queue.Empty:
                if time.time() - last_hb > 1:
                    yield f"data: {json.dumps({'type': 'heartbeat'})}\n\n"
                    last_hb = time.time()
        yield f"data: {json.dumps({'type': 'closed'})}\n\n"

    def run(self) -> None:
        print(f"\n  ◆ WIDDX Web UI  →  http://localhost:{self._port}")
        print(f"  ◆ Press Ctrl+C to stop\n")
        if self._open_browser:
            threading.Timer(1.0, lambda: __import__("webbrowser").open(
                f"http://localhost:{self._port}")).start()
        uvicorn.run(self._app, host="0.0.0.0", port=self._port, log_level="warning")


def start_web_server(port: int = 8520, open_browser: bool = True) -> None:
    if not HAS_WEB:
        print("Web UI requires: pip install fastapi uvicorn")
        return
    server = WiddxWebServer(port=port, open_browser=open_browser)
    server.run()


def _get_html() -> str:
    return r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>WIDDX — Autonomous AI Engineering OS</title>
<style>
:root{--bg:#0a0e14;--surface:#12171f;--surface2:#181e28;--border:#1e2a3a;
--brand:#00e5a0;--brand-dim:rgba(0,229,160,0.12);--blue:#0090ff;--text:#e0e6f0;
--dim:#5a6880;--success:#10b981;--warn:#f59e0b;--error:#ef4444;
--radius:8px;--font:system-ui,-apple-system,sans-serif;--mono:'JetBrains Mono','Cascadia Code',monospace}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--text);font:14px/1.6 var(--font);display:flex;height:100vh;overflow:hidden}

.sidebar{width:280px;background:var(--surface);border-right:1px solid var(--border);
display:flex;flex-direction:column;flex-shrink:0;z-index:10}
.sidebar-header{padding:16px 20px;border-bottom:1px solid var(--border);
background:linear-gradient(135deg,var(--surface),var(--surface2))}
.sidebar-header h1{font-size:16px;color:var(--brand);font-weight:800;letter-spacing:1px}
.sidebar-header .sub{font-size:10px;color:var(--dim);margin-top:3px;text-transform:uppercase;letter-spacing:1px}
.sidebar-tabs{display:flex;border-bottom:1px solid var(--border)}
.sidebar-tab{flex:1;padding:10px 0;text-align:center;font-size:11px;color:var(--dim);cursor:pointer;
border-bottom:2px solid transparent;transition:all .2s}
.sidebar-tab:hover{color:var(--text);background:var(--surface2)}
.sidebar-tab.active{color:var(--brand);border-bottom-color:var(--brand)}
.sidebar-content{flex:1;overflow-y:auto;padding:8px}
.file-item{padding:5px 10px;cursor:pointer;font:12px var(--mono);border-radius:4px;color:var(--dim);
white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:all .15s;
display:flex;align-items:center;gap:6px}
.file-item:hover{background:var(--brand-dim);color:var(--text)}
.file-item .icon{font-size:14px;width:18px;text-align:center;flex-shrink:0}
.file-item.dir{color:var(--blue)}
.file-item.active{background:var(--brand-dim);color:var(--brand)}
.file-item .size{font-size:10px;color:var(--dim);margin-left:auto;flex-shrink:0}
.stats-bar{padding:10px 20px;border-top:1px solid var(--border);font:11px var(--mono);color:var(--dim);
display:flex;justify-content:space-between}
.stats-bar span{color:var(--brand)}

.main{flex:1;display:flex;flex-direction:column;min-width:0;background:var(--bg)}
.toolbar{display:flex;align-items:center;gap:16px;padding:8px 20px;border-bottom:1px solid var(--border)}
.toolbar .dot{width:7px;height:7px;border-radius:50%;background:var(--brand);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
.toolbar .info{font:11px var(--mono);color:var(--dim)}
.toolbar .info b{color:var(--text);font-weight:600}

.messages{flex:1;overflow-y:auto;padding:16px 24px;display:flex;flex-direction:column;gap:10px}
.msg{padding:12px 18px;border-radius:var(--radius);max-width:88%;font-size:13px;line-height:1.6;
white-space:pre-wrap;word-break:break-word;animation:fadeIn .2s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
.msg.user{background:var(--surface);border:1px solid var(--border);align-self:flex-end;border-bottom-right-radius:2px}
.msg.assistant{background:var(--brand-dim);border:1px solid rgba(0,229,160,0.08);align-self:flex-start;border-bottom-left-radius:2px}
.msg.system{font-size:11px;color:var(--dim);text-align:center;align-self:center;background:none;border:none}
.msg.system.welcome{font-size:15px;color:var(--text);padding:30px}
.msg.system.welcome b{color:var(--brand);font-size:20px;display:block;margin-bottom:8px}
.msg.system.welcome span{display:block;margin:3px 0;font-size:12px;color:var(--dim)}
.tool-entry{border:1px solid var(--border);border-radius:var(--radius);margin:4px 0;overflow:hidden;
background:var(--surface);animation:fadeIn .2s ease}
.tool-header{padding:6px 12px;display:flex;align-items:center;gap:8px;font:12px var(--mono);cursor:pointer}
.tool-header:hover{background:var(--surface2)}
.tool-header .t-icon{font-size:14px;width:20px;text-align:center}
.tool-header .t-name{font-weight:600}
.tool-header .t-path{color:var(--dim);margin-left:auto;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px}
.tool-body{padding:6px 12px 6px 40px;font:11px var(--mono);color:var(--dim);display:none}
.tool-entry.open .tool-body{display:block}
.tool-body .ok{color:var(--success)}
.tool-body .err{color:var(--error)}
.tool-body .diff-add{color:var(--success)}
.tool-body .diff-del{color:var(--error)}
.file-viewer{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);
margin:8px 0;display:none;max-height:350px;overflow:auto}
.file-viewer.show{display:block}
.file-viewer .fv-header{padding:8px 12px;border-bottom:1px solid var(--border);font:11px var(--mono);color:var(--dim);
position:sticky;top:0;background:var(--surface2);display:flex;justify-content:space-between}
.file-viewer .fv-close{cursor:pointer;color:var(--dim);font-size:14px}
.file-viewer .fv-close:hover{color:var(--error)}
.file-viewer pre{margin:0;padding:12px;font:12px var(--mono);line-height:1.5;color:var(--text);
white-space:pre-wrap;word-break:break-word;tab-size:2}

.input-area{padding:12px 24px;border-top:1px solid var(--border);display:flex;gap:10px;align-items:flex-end}
.input-area textarea{flex:1;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);
color:var(--text);padding:10px 14px;font:13px var(--font);resize:none;min-height:44px;max-height:120px;outline:none}
.input-area textarea:focus{border-color:var(--brand);box-shadow:0 0 0 2px var(--brand-dim)}
.input-area button{background:var(--brand);color:#000;border:none;border-radius:var(--radius);padding:10px 24px;
font:13px var(--font);font-weight:700;cursor:pointer;transition:all .2s;white-space:nowrap}
.input-area button:hover{opacity:.9;transform:translateY(-1px)}
.input-area button:disabled{opacity:.3;cursor:not-allowed;transform:none}

.thinking{display:flex;align-items:center;gap:10px;padding:8px 0;font-size:12px;color:var(--dim);animation:fadeIn .2s ease}
.thinking .spinner{width:14px;height:14px;border:2px solid var(--border);border-top-color:var(--brand);border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

.quick-actions{display:flex;gap:6px;padding:0 24px 8px;flex-wrap:wrap}
.quick-btn{padding:4px 12px;border:1px solid var(--border);border-radius:16px;font:11px var(--mono);color:var(--dim);
background:transparent;cursor:pointer;transition:all .15s}
.quick-btn:hover{border-color:var(--brand);color:var(--brand);background:var(--brand-dim)}

::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:var(--dim)}
</style>
</head>
<body>

<div class="sidebar">
<div class="sidebar-header"><h1>◆ WIDDX</h1><div class="sub">v""" + __import__("widdx").__version__ + """ · Web UI</div></div>
<div class="sidebar-tabs">
<div class="sidebar-tab active" onclick="switchTab('files',this)">Files</div>
<div class="sidebar-tab" onclick="switchTab('project',this)">Project</div>
</div>
<div class="sidebar-content" id="sidebarContent"></div>
<div class="stats-bar"><span id="statMsg">0</span> msgs · <span id="statTok">0</span> tok</div>
</div>

<div class="main">
<div class="toolbar">
<div class="dot"></div><div class="info">WIDDX <b>Web UI</b> · <span id="hdrModel">loading</span> · <span id="hdrCwd"></span></div>
</div>
<div class="messages" id="messages">
<div class="msg system welcome"><b>◆ WIDDX Web UI</b><span>Autonomous AI Engineering OS</span><span>Type a task below or use quick actions to get started</span></div>
</div>
<div class="quick-actions" id="quickActions">
<button class="quick-btn" onclick="fillTask('Analyze this project and suggest improvements')">🔍 Analyze</button>
<button class="quick-btn" onclick="fillTask('Fix all bugs in the code')">🐛 Fix Bugs</button>
<button class="quick-btn" onclick="fillTask('Add tests for the project')">🧪 Add Tests</button>
<button class="quick-btn" onclick="fillTask('Refactor the code for better quality')">♻ Refactor</button>
<button class="quick-btn" onclick="fillTask('Create a README for this project')">📄 README</button>
</div>
<div class="input-area">
<textarea id="taskInput" placeholder="Describe your task... (Enter to send, Shift+Enter for new line)" rows="1"></textarea>
<button id="sendBtn" onclick="sendTask()">Send</button>
</div>
</div>

<script>
let busy=false,thinkingEl=null,currentTab='files',lastToolId=null;
const icons={Read:'📄',Write:'✨',Edit:'✏',Bash:'⚙',Grep:'🔎',Glob:'🔍',WebSearch:'🌐',ListDir:'📁'};
const colors={Read:'#38bdf8',Write:'#00e5a0',Edit:'#f59e0b',Bash:'#f59e0b',Grep:'#38bdf8',Glob:'#38bdf8'};

async function sendTask(){
 const input=document.getElementById('taskInput'),task=input.value.trim();
 if(!task||busy)return;
 busy=true;input.value='';document.getElementById('sendBtn').disabled=true;
 document.getElementById('quickActions').style.display='none';
 addMessage('user',task);thinkingEl=addThinking();lastToolId=null;
 try{
  const resp=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({task,session_id:sessionStorage.getItem('wid')||Date.now().toString(36)})});
  if(!resp.ok){throw new Error('Server error: '+resp.status)}
  const reader=resp.body.getReader(),decoder=new TextDecoder();let buffer='';
  while(true){const{ done,value}=await reader.read();if(done)break;
   buffer+=decoder.decode(value,{stream:true});const lines=buffer.split('\n');buffer=lines.pop()||'';
   for(const line of lines){if(line.startsWith('data: ')){try{handleEvent(JSON.parse(line.slice(6)))}catch(e){console.error('JSON parse:',e,line.slice(0,100))}}}
  }
 }catch(e){addMessage('system','❌ Error: '+e.message)}
 finally{removeThinking();busy=false;document.getElementById('sendBtn').disabled=false;
  document.getElementById('quickActions').style.display='flex';loadFiles('.');updateStats()}
}

function handleEvent(e){
 try{
  switch(e.type){
   case'start':break;
   case'tool_call':removeThinking();addToolCall(e.name,e.args);break;
   case'tool_result':addToolResult(e.name,e.output);break;
   case'done':removeThinking();
    if(e.result)addMessage('assistant',e.result);
    if(e.files){loadFiles('.');updateProject()}updateStats();break;
   case'error':removeThinking();addMessage('system','❌ '+(e.text||'Unknown error'));break;
   case'heartbeat':case'closed':break;
  }
 }catch(err){console.error('handleEvent error:',err,e)}
}

function addMessage(role,text){
 if(!text)return;
 const m=document.getElementById('messages'),d=document.createElement('div');
 d.className='msg '+role;d.textContent=text.slice(0,10000);m.appendChild(d);m.scrollTop=m.scrollHeight
}

function addThinking(){
 const m=document.getElementById('messages'),d=document.createElement('div');
 d.className='thinking';d.innerHTML='<div class="spinner"></div><span>Thinking...</span>';
 m.appendChild(d);m.scrollTop=m.scrollHeight;return d
}
function removeThinking(){if(thinkingEl){thinkingEl.remove();thinkingEl=null}}

function addToolCall(name,args){
 const m=document.getElementById('messages'),d=document.createElement('div'),id='tc-'+Date.now()+'-'+Math.random().toString(36).slice(2,6);
 d.className='tool-entry open';d.id=id;lastToolId=id;
 const label=args&&args.file_path?args.file_path.replace(/\\/g,'/').split('/').pop():args&&args.command?String(args.command).slice(0,40):'';
 d.innerHTML='<div class="tool-header" onclick="var el=document.getElementById(\''+id+'\');el.classList.toggle(\'open\')">'
  +'<span class="t-icon" style="color:'+(colors[name]||'#fff')+'">'+(icons[name]||'◆')+'</span>'
  +'<span class="t-name" style="color:'+(colors[name]||'#fff')+'">'+name+'</span>'
  +'<span class="t-path">'+escapeHtml(label)+'</span></div><div class="tool-body" id="'+id+'-body"></div>';
 m.appendChild(d);m.scrollTop=m.scrollHeight
}

function addToolResult(name,output){
 const bodyId=lastToolId?lastToolId+'-body':null;
 const b=bodyId?document.getElementById(bodyId):null;
 if(!b){
  const entries=document.querySelectorAll('.tool-entry');
  if(!entries.length)return;
  const last=entries[entries.length-1];
  const tb=last.querySelector('.tool-body');
  if(!tb)return;
  fillToolBody(tb,name,output);
 }else{fillToolBody(b,name,output)}
}

function fillToolBody(el,name,output){
 if(output&&output.error){el.innerHTML='<div class="err">✗ '+escapeHtml(String(output.error).slice(0,200))+'</div>'}
 else{let h='';if(name==='Read')h='<span class="ok">✓</span> '+(output&&output.total_lines||0)+' lines read';
  else if(name==='Write')h='<span class="ok">✓</span> Written · '+(output&&output.status||'created');
  else if(name==='Edit')h='<span class="ok">✓</span> '+(output&&output.replacements||1)+' replacements';
  else if(name==='Grep')h='<span class="ok">✓</span> '+(output&&output.count||0)+' matches';
  else if(name==='Glob')h='<span class="ok">✓</span> '+(output&&output.count||0)+' files';
  else if(name==='Bash')h=(output&&output.exit_code===0?'<span class="ok">✓</span>':'<span class="err">✗</span>')+' exit '+(output&&output.exit_code===0?'0':(output&&output.exit_code||'?'));
  else h='<span class="ok">✓</span>';
  el.innerHTML=h}
}

function fillTask(text){document.getElementById('taskInput').value=text;document.getElementById('taskInput').focus()}

async function loadFiles(dir){
 if(currentTab!=='files')return;
 try{const resp=await fetch('/api/files?path='+encodeURIComponent(dir));
  const data=await resp.json();const c=document.getElementById('sidebarContent');if(!c)return;
  let h='<div class="file-item dir" onclick="loadFiles(\'..\')"><span class="icon">📁</span>..</div>';
  for(const f of data.files||[]){const icon=f.type==='dir'?'📁':'📄',cls=f.type||'';
   const safepath=f.path.replace(/'/g,"\\'");
   h+='<div class="file-item '+cls+'" onclick="'+(f.type==='dir'?'loadFiles(\''+safepath+'\')':'previewFile(\''+safepath+'\')')+'">'
    +'<span class="icon">'+icon+'</span>'+escapeHtml(f.name)
    +'<span class="size">'+(f.type==='file'?formatSize(f.size):'')+'</span></div>';}
  c.innerHTML=h}catch(e){}
}

async function previewFile(path){
 let v=document.getElementById('fileViewer');
 if(!v){v=document.createElement('div');v.id='fileViewer';v.className='file-viewer show';
  const msgs=document.getElementById('messages');if(msgs)msgs.after(v)}
 try{const resp=await fetch('/api/file?path='+encodeURIComponent(path));
  const data=await resp.json();v.className='file-viewer show';
  v.innerHTML='<div class="fv-header"><span>📄 '+escapeHtml(path)+'</span><span class="fv-close" onclick="this.parentElement.parentElement.classList.remove(\'show\')">✕</span></div><pre>'+escapeHtml(data.content||'')+'</pre>'}catch(e){}
}

async function updateProject(){
 if(currentTab!=='project')return;
 try{const resp=await fetch('/api/project');const data=await resp.json();
  const sc=document.getElementById('sidebarContent');if(!sc)return;
  sc.innerHTML='<div style="padding:12px"><div style="font-size:13px;font-weight:700;color:var(--brand);margin-bottom:8px">📦 '+(data.name||'project')+'</div>'
   +'<div style="font-size:11px;color:var(--dim);margin-bottom:12px">'+(data.cwd||'')+'</div>'
   +'<div style="font-size:12px;color:var(--dim)">'+(data.files_count||0)+' items</div></div>'}catch(e){}
}

async function updateStats(){
 try{const resp=await fetch('/api/health');const data=await resp.json();
  const el=document.getElementById('hdrModel');if(el)el.textContent=(data.providers||[]).join(' + ')||'unknown'}
 catch(e){}
 const el2=document.getElementById('statMsg');if(el2)el2.textContent=document.querySelectorAll('.msg.user,.msg.assistant').length
}

function switchTab(tab,el){
 currentTab=tab;document.querySelectorAll('.sidebar-tab').forEach(t=>t.classList.remove('active'));
 el.classList.add('active');
 if(tab==='files')loadFiles('.');else updateProject()
}
function formatSize(b){return b<1024?b+'B':b<1048576?(b/1024).toFixed(1)+'KB':(b/1048576).toFixed(1)+'MB'}
function escapeHtml(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}

(function init(){
 const inp=document.getElementById('taskInput');
 if(inp){
  inp.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendTask()}});
  inp.focus();
 }
 loadFiles('.');updateProject();updateStats();
})();
</script>
</body>
</html>"""


def start_web_server(port: int = 8520, open_browser: bool = True) -> None:
    if not HAS_WEB:
        print("Web UI requires: pip install fastapi uvicorn")
        return
    server = WiddxWebServer(port=port, open_browser=open_browser)
    server.run()
