"""Provider and API key commands — /providers, /provider, /key."""
from __future__ import annotations

import os

from widdx import ui


def _show_providers(self, arg: str) -> None:
    from widdx import ui
    c = ui.get_console()
    router = getattr(self, "_router", None)
    if router is None:
        c.print("  [dim]Router not available[/]")
        return

    providers = router.list_providers()
    if not providers:
        c.print("  [dim]No providers configured[/]")
        return

    parts = arg.strip().split()
    if len(parts) >= 2 and parts[0].lower() == "toggle":
        router.toggle_provider(parts[1])
        return

    try:
        _interactive_provider_manager(router, providers, c)
    except Exception:
        pass


def _interactive_provider_manager(router, providers: list[dict], console: object) -> None:
    from prompt_toolkit import PromptSession as _Session
    from prompt_toolkit.formatted_text import HTML as _HTML
    from prompt_toolkit.key_binding import KeyBindings as _Bindings

    _enabled = {p["name"]: p["enabled"] for p in providers}
    _names = [p["name"] for p in providers]
    _idx = [0]

    _kb = _Bindings()

    @_kb.add("up")
    def _up(ev):
        _idx[0] = (_idx[0] - 1) % len(_names)

    @_kb.add("down")
    def _down(ev):
        _idx[0] = (_idx[0] + 1) % len(_names)

    @_kb.add("space")
    def _space(ev):
        _name = _names[_idx[0]]
        router.toggle_provider(_name)
        _enabled[_name] = _enabled[_name] if False else True

    @_kb.add("enter")
    def _enter(ev):
        ev.app.exit()

    @_kb.add("c-c")
    def _cancel(ev):
        ev.app.exit()

    @_kb.add("escape")
    def _esc(ev):
        ev.app.exit()

    _session: _Session = _Session(key_bindings=_kb)

    def _render():
        _lines = ["<ansiyellow> PROVIDER MANAGER</ansiyellow>\n\n"]
        for _i, _n in enumerate(_names):
            _on = _enabled.get(_n, True)
            _marker = "<ansibrightgreen>\u25b8</ansibrightgreen>" if _i == _idx[0] else " "
            _st = "<ansigreen>\u2713 enabled</ansigreen>" if _on else "<ansired>\u2717 disabled</ansired>"
            _arrow = "<ansired>\u2190</ansired>" if providers[_i].get("last_used") else ""
            _lines.append(f"  {_marker} <ansicyan>{_n:22}</ansicyan> {_st} {_arrow}\n")
        _lines.append(
            "\n<ansibrightblack>  \u2191\u2193 navigate</ansibrightblack>"
            "  \u00b7  <ansibrightblack>Space toggle</ansibrightblack>"
            "  \u00b7  <ansibrightblack>Enter done</ansibrightblack>"
        )
        return _HTML("".join(_lines))

    _session.prompt(_render)

    if hasattr(console, "print"):
        c2 = ui.get_console()
        c2.print()
        active = sum(1 for p in router.list_providers() if p["enabled"])
        total = len(router.list_providers())
        c2.print(f"  [brand]\u25c6[/] [text]{active}/{total}[/] providers active  [dim]\u00b7  use /provider <name> to switch[/]")
        if active == 1:
            c2.print(f"  [warning]\u26a0 Only one provider active \u2014 if it fails, no fallback available[/]")


def _set_active_provider(self, arg: str) -> None:
    c = ui.get_console()
    router = getattr(self, "_router", None)
    if router is None:
        c.print("  [dim]Router not available[/]")
        return

    providers = router.list_providers()
    if not providers:
        c.print("  [dim]No providers configured[/]")
        return

    from widdx.ui.professional import confirm_with_options

    names = [p["name"] for p in providers]
    c.print()
    choice = confirm_with_options("Choose active provider", names + ["All providers"], default="All providers")

    if choice == "All providers":
        router.enable_all()
        c.print("  [success]\u2713 All providers enabled[/]")
    else:
        router.enable_only(choice)
        c.print(f"  [success]\u2713 Active: [text]{choice}[/][/]")


def _set_api_key(self, arg: str) -> None:
    from widdx.config import save_config_key, load_config
    c = ui.get_console()

    current_config = load_config()
    current_key = current_config.get("deepseek_api_key") or current_config.get("__env__", {}).get("deepseek_key")
    google_key = current_config.get("google_api_key") or current_config.get("__env__", {}).get("google_key")

    if current_key:
        masked = current_key[:8] + "..." + current_key[-4:] if len(current_key) > 12 else "***"
        c.print(f"  [dim]DeepSeek:[/] [success]\u2713 {masked}[/]")
    else:
        c.print(f"  [dim]DeepSeek:[/] [warning]not set[/]")
    if google_key:
        masked = google_key[:8] + "..." + google_key[-4:] if len(google_key) > 12 else "***"
        c.print(f"  [dim]Google:[/]   [success]\u2713 {masked}[/]")
    else:
        c.print(f"  [dim]Google:[/]   [dim]not set[/]")

    key = arg.strip()
    if not key:
        c.print("  [dim]Usage: /key  (then paste your key when prompted)[/]")
        c.print("  [dim]Or: /key sk-...  (not recommended \u2014 stays in terminal scrollback)[/]")
        c.print("  [dim]Or set env: $env:DEEPSEEK_API_KEY = 'sk-...' (session only)[/]")

        try:
            from prompt_toolkit import prompt as pt_prompt
            from prompt_toolkit.formatted_text import HTML
            key = pt_prompt(HTML(
                '<ansiyellow>  Paste DeepSeek API key: </ansiyellow>'
            ), is_password=True)
        except Exception:
            try:
                key = input("  Paste DeepSeek API key: ").strip()
            except (KeyboardInterrupt, EOFError):
                return
        if not key:
            return
    else:
        key = key.strip().strip("'\"")

    if not key.startswith("sk-") and not key.startswith("AIza"):
        which = "Google" if len(key) == 39 and key.isascii() else "DeepSeek"
        c.print(f"  [warning]\u26a0 Key doesn't match known format. Treat as {which}?[/]", end=" ")
        try:
            confirm = input().strip().lower()
        except (KeyboardInterrupt, EOFError):
            return
        if not confirm.startswith("y"):
            return

    provider = "google" if key.startswith("AIza") else "deepseek"
    if provider == "google":
        save_config_key("google_api_key", key)
        self._config["google_api_key"] = key
        self._config["__env__"]["google_key"] = key
    else:
        save_config_key("deepseek_api_key", key)
        self._config["deepseek_api_key"] = key
        self._config["__env__"]["deepseek_key"] = key

    try:
        import stat
        config_path = os.path.expanduser("~/.widdx/config.yaml")
        os.chmod(config_path, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass

    _strip_key_from_history()

    masked = key[:8] + "..." + key[-4:]
    c.print(f"  [success]\u2713 API key saved ({masked}). DeepSeek is now available.[]")


def _strip_key_from_history() -> None:
    try:
        history_path = os.path.expanduser("~/.widdx/history")
        if not os.path.exists(history_path):
            return
        with open(history_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        filtered = [l for l in lines if "/key" not in l.lower()]
        if len(filtered) < len(lines):
            with open(history_path, "w", encoding="utf-8") as f:
                f.writelines(filtered)
    except Exception:
        pass
