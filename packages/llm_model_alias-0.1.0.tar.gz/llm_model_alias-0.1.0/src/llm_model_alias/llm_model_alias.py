from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

from huggingface_hub import try_to_load_from_cache

from .types import MODEL_PLATFORMS, ModelMapping, ModelPlatform, ResolvedModelMapping


class LLMModelAlias:
  def __init__(
    self,
    data_file: Path | None = None,
    ollama_url: str | None = None,
  ) -> None:
    self._data_file = data_file
    self._ollama_url = ollama_url
    self._data: list[ModelMapping] = self.load()

  def resolve(self, model_name: str, platform: ModelPlatform) -> str:
    mapping = self.get(model_name, platform)
    if mapping is not None:
      return mapping["resolved_model_name"]
    return self.normalize_model_name(model_name)

  def get(self, model_name: str, platform: ModelPlatform) -> ResolvedModelMapping:
    if platform in ["custom", "openai"]:
      return ResolvedModelMapping(
        model_name=model_name,
        resolved_model_name=model_name,
      )
    normalized_model_name = self.normalize_model_name(model_name)
    for row in reversed(self._data):
      match_found = False
      for platform_key in MODEL_PLATFORMS:
        if platform_key not in row:
          continue
        row_name = row[platform_key]["name"]
        if row_name is not None and self.normalize_model_name(row_name) == normalized_model_name:
          match_found = True
          break
      if not match_found:
        continue
      mapping = self._resolve_row(row, platform)
      if mapping is not None:
        return mapping
    return ResolvedModelMapping(
      model_name=model_name,
      resolved_model_name=model_name,
    )

  def is_downloaded(self, model_name: str, platform: ModelPlatform) -> bool:
    mapping = self.get(model_name, platform)
    if mapping is None:
      return False

    resolved_model_name = mapping["resolved_model_name"]
    if platform == "ollama":
      return self._is_ollama_downloaded(resolved_model_name)

    return self._is_hf_downloaded(resolved_model_name)

  def load(self) -> list[ModelMapping]:
    prefix = "LLMModelAlias.load"
    path = self.json_path()
    if self._data_file and not path.exists():
        raise FileNotFoundError(f"{prefix} Specified model alias file not found at {path}")
    if not path.exists():
      path = self._default_json_path()
    return self._load_mappings(path)

  def json_path(self) -> Path:
    if self._data_file is not None:
      return self._data_file.expanduser().resolve()

    env_path = os.getenv("MODEL_ALIAS_JSON_FILE")
    if env_path:
      return Path(env_path).expanduser().resolve()

    if os.name == "posix" and "darwin" in os.uname().sysname.lower():
      return (Path.home() / "Library" / "Application Support" / "llm_model_alias" / "model_mappings.json").resolve()

    xdg_data_home = os.getenv("XDG_DATA_HOME")
    if xdg_data_home:
      base = Path(xdg_data_home).expanduser()
    else:
      base = Path.home() / ".local" / "share"
    return (base / "llm_model_alias" / "model_mappings.json").resolve()

  def normalize_model_name(self, model_name: str) -> str:
    return model_name.strip().lower()

  def _default_json_path(self) -> Path:
    return Path(__file__).parent / "data" / "default_model_mappings.json"

  def _load_mappings(self, file: Path) -> list[ModelMapping]:
    with file.open("r", encoding="utf-8") as file_handle:
      defaults = json.load(file_handle)
    if not isinstance(defaults, dict):
      raise ValueError(f"Expected JSON object in {file}")
    mappings = defaults.get("mappings")
    if not isinstance(mappings, list):
      raise ValueError(f"Expected 'mappings' list in {file}")
    loaded_mappings: list[ModelMapping] = []
    for item in mappings:
      if isinstance(item, dict):
        parsed_row = self._parse_row(item)
        if parsed_row is not None:
          loaded_mappings.append(parsed_row)
    return loaded_mappings

  def _parse_row(self, item: dict[str, object]) -> ModelMapping | None:
    parsed_row: ModelMapping = {}
    for platform_key in MODEL_PLATFORMS:
      platform_value = item.get(platform_key)
      if not isinstance(platform_value, dict):
        continue
      parsed_row[platform_key] = {
        "name": self._as_optional_str(platform_value.get("name")),
        "size": self._as_optional_str(platform_value.get("size")),
        "quantization": self._as_optional_str(platform_value.get("quantization")),
      }
    return parsed_row

  def _resolve_row(
    self,
    row: ModelMapping,
    platform: ModelPlatform,
  ) -> ResolvedModelMapping | None:
    ollama_mapping = row.get("ollama")
    if ollama_mapping is None:
      return None
    row_model_name = ollama_mapping["name"]
    if row_model_name is None:
      return None
    platform_mapping = row.get(platform)
    if platform_mapping is None:
      return None
    resolved_model_name = platform_mapping["name"]
    if resolved_model_name is None:
      return None

    return {
      "model_name": row_model_name,
      "resolved_model_name": resolved_model_name,
    }

  def _as_optional_str(self, value: object) -> str | None:
    if value is None:
      return None
    if type(value) is str:
      return value
    return None

  def _is_ollama_downloaded(self, model_name: str) -> bool:
    process = subprocess.run(
      ["ollama", "list"],
      check=False,
      capture_output=True,
      text=True,
    )
    if process.returncode != 0:
      return False

    output = process.stdout.lower()
    return model_name.lower() in output

  def _is_hf_downloaded(self, model_name: str) -> bool:
    cached = try_to_load_from_cache(repo_id=model_name, filename="config.json")
    return cached is not None

  def ollama_url(self) -> str:
    if self._ollama_url is not None:
      return self._ollama_url
    env_url = os.getenv("MODEL_ALIAS_OLLAMA_URL")
    if env_url:
      return env_url
    return "http://localhost:11434"
