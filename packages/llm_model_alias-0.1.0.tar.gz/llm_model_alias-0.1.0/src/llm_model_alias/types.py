from typing import Literal, TypedDict, get_args

ModelPlatform = Literal["vllm", "vllm-metal", "ollama", "openai", "custom"]
MODEL_PLATFORMS = get_args(ModelPlatform)


class ResolvedModelMapping(TypedDict):
  model_name: str
  resolved_model_name: str


class ModelPlatformMapping(TypedDict):
  name: str | None
  size: str | None
  quantization: str | None


ModelMapping = dict[ModelPlatform, ModelPlatformMapping]
