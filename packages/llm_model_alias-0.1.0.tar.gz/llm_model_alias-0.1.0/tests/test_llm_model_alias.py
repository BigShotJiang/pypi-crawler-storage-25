import json
from pathlib import Path

import pytest
from llm_model_alias.llm_model_alias import LLMModelAlias
from llm_model_alias.types import ModelPlatform


def _write_rows(path: Path, rows: list[dict[str, object]]) -> None:
  path.write_text(json.dumps({"mappings": rows}), encoding="utf-8")


def test_data_file_missing_loads_empty_only(tmp_path: Path) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(data_path, [])
  alias = LLMModelAlias(data_file=data_path)
  assert alias.get("qwen3:8b", "vllm")["resolved_model_name"] == "qwen3:8b"


def test_data_file_existing_is_only_source(tmp_path: Path) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(
    data_path,
    [
      {
        "ollama": {"name": "custom:1b", "size": "1b", "quantization": None},
        "vllm": {"name": "org/custom-1b", "size": "1b", "quantization": None},
        "vllm-metal": {"name": "mlx-community/custom-1b-4bit", "size": "1b", "quantization": "4bit"},
      }
    ],
  )
  alias = LLMModelAlias(data_file=data_path)
  mapping = alias.get("custom:1b", "vllm")
  assert mapping is not None
  assert mapping["model_name"] == "custom:1b"
  assert mapping["resolved_model_name"] == "org/custom-1b"
  assert alias.get("qwen3:8b", "vllm")["resolved_model_name"] == "qwen3:8b"


def test_defaults_loaded_when_data_file_not_provided(monkeypatch: pytest.MonkeyPatch) -> None:
  monkeypatch.delenv("MODEL_ALIAS_JSON_FILE", raising=False)
  alias = LLMModelAlias()
  mapping = alias.get("qwen3:8b", "vllm")
  assert mapping is not None
  assert mapping["resolved_model_name"] == "Qwen/Qwen3-8B"
  reverse_mapping = alias.get("Qwen/Qwen3-8B", "ollama")
  assert reverse_mapping is not None
  assert reverse_mapping["resolved_model_name"] == "qwen3:8b"


@pytest.mark.parametrize(
  ("model_name", "platform", "expected"),
  [
    ("qwen3:8b", "ollama", "qwen3:8b"),
    ("qwen3:8b", "vllm", "Qwen/Qwen3-8B"),
    ("qwen3:8b", "vllm-metal", "mlx-community/Josiefied-Qwen3-8B-abliterated-v1-4bit"),
    ("Qwen/Qwen3-8B", "vllm", "Qwen/Qwen3-8B"),
    ("Qwen/Qwen3-8B", "vllm-metal", "mlx-community/Josiefied-Qwen3-8B-abliterated-v1-4bit"),
    ("Qwen/Qwen3-8B", "ollama", "qwen3:8b"),
    (
      "mlx-community/Josiefied-Qwen3-8B-abliterated-v1-4bit",
      "vllm-metal",
      "mlx-community/Josiefied-Qwen3-8B-abliterated-v1-4bit",
    ),
  ],
)
def test_resolve_matrix_from_user_file(
  tmp_path: Path,
  model_name: str,
  platform: ModelPlatform,
  expected: str,
) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(
    data_path,
    [
      {
        "ollama": {"name": "qwen3:8b", "size": "8b", "quantization": None},
        "vllm": {"name": "Qwen/Qwen3-8B", "size": "8b", "quantization": None},
        "vllm-metal": {
          "name": "mlx-community/Josiefied-Qwen3-8B-abliterated-v1-4bit",
          "size": "8b",
          "quantization": "4bit",
        },
      }
    ],
  )
  alias = LLMModelAlias(data_file=data_path)
  assert alias.resolve(model_name, platform) == expected


def test_resolve_miss_returns_normalized_name(tmp_path: Path) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(data_path, [])
  alias = LLMModelAlias(data_file=data_path)
  assert alias.resolve("  Qwen/Qwen3-8B  ", "vllm") == "  Qwen/Qwen3-8B  "


def test_is_downloaded_uses_ollama_list_only(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(
    data_path,
    [
      {
        "ollama": {"name": "custom:model", "size": "1b", "quantization": None},
        "vllm": {"name": None, "size": None, "quantization": None},
        "vllm-metal": {"name": None, "size": None, "quantization": None},
      }
    ],
  )
  alias = LLMModelAlias(data_file=data_path)
  monkeypatch.setattr(alias, "_is_ollama_downloaded", lambda model_name: model_name == "custom:model")
  assert alias.is_downloaded("custom:model", "ollama") is True


def test_is_downloaded_uses_hf_cache_for_non_ollama(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(
    data_path,
    [
      {
        "ollama": {"name": "qwen3:8b", "size": "8b", "quantization": None},
        "vllm": {"name": "Qwen/Qwen3-8B", "size": "8b", "quantization": None},
        "vllm-metal": {"name": None, "size": None, "quantization": None},
      }
    ],
  )
  alias = LLMModelAlias(data_file=data_path)
  monkeypatch.setattr(alias, "_is_hf_downloaded", lambda model_name: model_name == "Qwen/Qwen3-8B")
  assert alias.is_downloaded("qwen3:8b", "vllm") is True
  assert alias.is_downloaded("qwen3:8b", "vllm-metal") is False


def test_get_returns_none_when_target_platform_name_missing(tmp_path: Path) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(
    data_path,
    [
      {
        "ollama": {"name": "qwen3:8b", "size": "8b", "quantization": None},
        "vllm": {"name": None, "size": None, "quantization": None},
        "vllm-metal": {"name": "mlx-community/Qwen3-8B-4bit", "size": "8b", "quantization": "4bit"},
      }
    ],
  )
  alias = LLMModelAlias(data_file=data_path)
  assert alias.get("qwen3:8b", "vllm")["resolved_model_name"] == "qwen3:8b"
  assert alias.get("qwen3:8b", "vllm-metal") is not None


def test_load_raises_for_non_list_user_file(tmp_path: Path) -> None:
  data_path = tmp_path / "model_mappings.json"
  data_path.write_text(json.dumps({"mappings": {}}), encoding="utf-8")
  with pytest.raises(ValueError, match="Expected 'mappings' list"):
    LLMModelAlias(data_file=data_path)


def test_load_skips_invalid_rows_and_keeps_valid_rows(tmp_path: Path) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(
    data_path,
    [
      {
        "ollama": {"name": "valid:1b", "size": "1b", "quantization": None},
        "vllm": {"name": "org/valid-1b", "size": "1b", "quantization": None},
        "vllm-metal": {"name": "mlx-community/valid-1b-4bit", "size": "1b", "quantization": "4bit"},
      },
      {
        "ollama": {"name": "bad:1b", "size": "1b", "quantization": None},
        "vllm": {"name": "org/bad-1b", "size": "1b", "quantization": None},
      },
    ],
  )
  alias = LLMModelAlias(data_file=data_path)
  assert alias.get("valid:1b", "vllm") is not None
  assert alias.get("bad:1b", "vllm-metal")["resolved_model_name"] == "bad:1b"


def test_json_path_precedence_constructor_over_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
  env_path = tmp_path / "from_env.json"
  direct_path = tmp_path / "from_constructor.json"
  _write_rows(direct_path, [])
  monkeypatch.setenv("MODEL_ALIAS_JSON_FILE", str(env_path))
  alias = LLMModelAlias(data_file=direct_path)
  assert alias.json_path() == direct_path.resolve()


def test_json_path_uses_env_when_set(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
  env_path = tmp_path / "from_env.json"
  monkeypatch.setenv("MODEL_ALIAS_JSON_FILE", str(env_path))
  alias = LLMModelAlias()
  assert alias.json_path() == env_path.resolve()


def test_ollama_url_prefers_constructor_value(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(data_path, [])
  monkeypatch.setenv("MODEL_ALIAS_OLLAMA_URL", "http://env-host:11434")
  alias = LLMModelAlias(data_file=data_path, ollama_url="http://param-host:11434")
  assert alias.ollama_url() == "http://param-host:11434"


def test_ollama_url_uses_env_when_parameter_missing(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
  data_path = tmp_path / "model_mappings.json"
  _write_rows(data_path, [])
  monkeypatch.setenv("MODEL_ALIAS_OLLAMA_URL", "http://env-host:11434")
  alias = LLMModelAlias(data_file=data_path)
  assert alias.ollama_url() == "http://env-host:11434"
