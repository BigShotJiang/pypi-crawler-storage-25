"""
xploitenc.exceptions - Custom exceptions
"""

class XploitEncError(Exception):
    """Base exception for all xploitenc errors"""
    pass

class InvalidKeyError(XploitEncError):
    """Raised when the key is invalid or corrupted"""
    pass

class DecryptionError(XploitEncError):
    """Raised when decryption fails (wrong key or tampered data)"""
    pass

class SignatureError(XploitEncError):
    """Raised when signature verification fails"""
    pass

class VaultError(XploitEncError):
    """Raised on vault operations errors"""
    pass
