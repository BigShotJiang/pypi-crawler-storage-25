"""
Youtube: JustXploit
Github: @canxploit
Author: canxploit
"""

from .core import (
    encrypt,
    decrypt,
    XploitCipher,
    generate_key,
    hash_password,
    verify_password,
    sign,
    verify_signature,
    KeyManager,
    SecureVault,
)

from .exceptions import (
    XploitEncError,
    InvalidKeyError,
    DecryptionError,
    SignatureError,
    VaultError,
)

__version__ = "1.0.0"
__author__ = "xploitenc"
__all__ = [
    "encrypt",
    "decrypt",
    "XploitCipher",
    "generate_key",
    "hash_password",
    "verify_password",
    "sign",
    "verify_signature",
    "KeyManager",
    "SecureVault",
    "XploitEncError",
    "InvalidKeyError",
    "DecryptionError",
    "SignatureError",
    "VaultError",
]
