"""
xploitenc.core - The main encryption engine

XploitEnc uses a custom cipher called XSCC (XploitEnc Substitution-Chain Cipher)

Youtube: JustXploit
Github: @canxploit
Author: canxploit

Supports:
  - 128/256/512-bit key sizes
  - Stream & block modes
  - Digital signatures (ECDSA-style with custom math)
  - Password hashing (Argon2-inspired)
  - SecureVault (encrypted key-value store)
"""

import os
import struct
import hashlib
import hmac
import json
import time
import base64
from typing import Union, Optional
from .exceptions import (
    InvalidKeyError, DecryptionError, SignatureError, VaultError
)


BLOCK_SIZE   = 16        # bytes (128 bits)
ROUNDS       = 16
MAGIC        = b"XENC"
VERSION      = b"\x01"
KEY_SIZES    = {128: 16, 256: 32, 512: 64}
SALT_SIZE    = 16
IV_SIZE      = 16
TAG_SIZE     = 32



def _to_bytes(data: Union[str, bytes]) -> bytes:
    if isinstance(data, str):
        return data.encode("utf-8")
    return data

def _xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))

def _rotl32(x: int, n: int) -> int:
    return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF

def _rotr32(x: int, n: int) -> int:
    return ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF

def _pad(data: bytes, block_size: int = BLOCK_SIZE) -> bytes:
    """PKCS7 padding"""
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len] * pad_len)

def _unpad(data: bytes) -> bytes:
    """PKCS7 unpadding"""
    pad_len = data[-1]
    if pad_len == 0 or pad_len > BLOCK_SIZE:
        raise DecryptionError("Invalid padding - wrong key or corrupted data")
    if data[-pad_len:] != bytes([pad_len] * pad_len):
        raise DecryptionError("Padding verification failed - wrong key or corrupted data")
    return data[:-pad_len]



def _generate_sbox(key: bytes) -> list:
    """Generate a key-dependent, bijective S-Box (256 entries)"""
    sbox = list(range(256))
    seed = hashlib.sha3_256(b"XENC-SBOX:" + key).digest()
    j = 0
    for i in range(256):
        j = (j + sbox[i] + seed[i % len(seed)]) % 256
        sbox[i], sbox[j] = sbox[j], sbox[i]
    return sbox

def _invert_sbox(sbox: list) -> list:
    inv = [0] * 256
    for i, v in enumerate(sbox):
        inv[v] = i
    return inv



def _derive_key(password: bytes, salt: bytes, key_len: int = 32, iterations: int = 100_000) -> bytes:
    """
    Custom KDF — pure Python PBKDF2 using SHA-256 + SHA3-256 double-HMAC.
    Fully cross-platform (no OpenSSL dependency).
    Returns `key_len` bytes of derived key material.
    """

    base = hashlib.pbkdf2_hmac("sha256", password, salt, iterations, dklen=64)

    blocks = []
    counter = 0
    while len(b"".join(blocks)) < key_len:
        counter += 1
        h = hashlib.sha3_256(base + salt + password + counter.to_bytes(4, "big")).digest()
        blocks.append(h)
    return b"".join(blocks)[:key_len]

def _expand_key(key: bytes, rounds: int = ROUNDS) -> list:
    """
    Key schedule: expand the master key into `rounds+1` round keys
    each of BLOCK_SIZE bytes.
    """
    round_keys = []
    current = key
    for i in range(rounds + 1):
        h = hashlib.sha3_256(current + struct.pack(">I", i)).digest()
        round_keys.append(h[:BLOCK_SIZE])
        current = h
    return round_keys


def _feistel_f(half: bytes, round_key: bytes, sbox: list) -> bytes:
    """
    Feistel F-function:
      1. XOR with round key
      2. SBox substitution
      3. Byte rotation
      4. Mix with prime multiplication mod 257
    """
    out = bytearray(len(half))
    for i in range(len(half)):
        x = half[i] ^ round_key[i % len(round_key)]
        x = sbox[x]
        x = (x * 167 + round_key[(i + 3) % len(round_key)]) % 256
        out[i] = x

    out = out[3:] + out[:3]
    return bytes(out)

def _gf256_mul(a: int, b: int) -> int:
    """Multiply two bytes in GF(2^8) with AES irreducible poly 0x11b"""
    result = 0
    for _ in range(8):
        if b & 1:
            result ^= a
        hi = a & 0x80
        a = (a << 1) & 0xFF
        if hi:
            a ^= 0x1b
        b >>= 1
    return result

def _mix_columns(block: bytes) -> bytes:
    """Diffusion layer using AES MixColumns in GF(2^8) - provably invertible"""
    result = bytearray(len(block))
    n = len(block) // 4
    for i in range(n):
        a = block[i * 4]
        b = block[i * 4 + 1]
        c = block[i * 4 + 2]
        d = block[i * 4 + 3]
        result[i * 4]     = _gf256_mul(2, a) ^ _gf256_mul(3, b) ^ c          ^ d
        result[i * 4 + 1] = a               ^ _gf256_mul(2, b) ^ _gf256_mul(3, c) ^ d
        result[i * 4 + 2] = a               ^ b                ^ _gf256_mul(2, c) ^ _gf256_mul(3, d)
        result[i * 4 + 3] = _gf256_mul(3, a) ^ b               ^ c           ^ _gf256_mul(2, d)
    return bytes(result)

def _inv_mix_columns(block: bytes) -> bytes:
    """Inverse MixColumns in GF(2^8) - exact AES inverse"""
    result = bytearray(len(block))
    n = len(block) // 4
    for i in range(n):
        a = block[i * 4]
        b = block[i * 4 + 1]
        c = block[i * 4 + 2]
        d = block[i * 4 + 3]
        result[i * 4]     = (_gf256_mul(0x0e, a) ^ _gf256_mul(0x0b, b) ^ _gf256_mul(0x0d, c) ^ _gf256_mul(0x09, d))
        result[i * 4 + 1] = (_gf256_mul(0x09, a) ^ _gf256_mul(0x0e, b) ^ _gf256_mul(0x0b, c) ^ _gf256_mul(0x0d, d))
        result[i * 4 + 2] = (_gf256_mul(0x0d, a) ^ _gf256_mul(0x09, b) ^ _gf256_mul(0x0e, c) ^ _gf256_mul(0x0b, d))
        result[i * 4 + 3] = (_gf256_mul(0x0b, a) ^ _gf256_mul(0x0d, b) ^ _gf256_mul(0x09, c) ^ _gf256_mul(0x0e, d))
    return bytes(result)

def _encrypt_block(block: bytes, round_keys: list, sbox: list) -> bytes:
    """Encrypt a single 16-byte block using Feistel network"""
    assert len(block) == BLOCK_SIZE
    left  = bytearray(block[:BLOCK_SIZE // 2])
    right = bytearray(block[BLOCK_SIZE // 2:])


    left  = _xor_bytes(bytes(left),  round_keys[0][:BLOCK_SIZE // 2])
    right = _xor_bytes(bytes(right), round_keys[0][BLOCK_SIZE // 2:])

    for r in range(ROUNDS):
        rk = round_keys[r + 1]
        f_out = _feistel_f(bytes(right), rk, sbox)
        new_left  = _xor_bytes(bytes(left), f_out)
        left  = right
        right = bytearray(new_left)

        if (r + 1) % 4 == 0:
            combined = _mix_columns(bytes(left) + bytes(right))
            left  = bytearray(combined[:BLOCK_SIZE // 2])
            right = bytearray(combined[BLOCK_SIZE // 2:])

    return bytes(right) + bytes(left)

def _decrypt_block(block: bytes, round_keys: list, sbox: list) -> bytes:
    """Decrypt a single 16-byte block (Feistel decryption uses same sbox)"""
    assert len(block) == BLOCK_SIZE
    half = BLOCK_SIZE // 2


    right = bytearray(block[:half])
    left  = bytearray(block[half:])

    for r in range(ROUNDS - 1, -1, -1):
        rk = round_keys[r + 1]

        if (r + 1) % 4 == 0:
            combined = _inv_mix_columns(bytes(left) + bytes(right))
            left  = bytearray(combined[:half])
            right = bytearray(combined[half:])

        f_out     = _feistel_f(bytes(left), rk, sbox)
        old_left  = _xor_bytes(bytes(right), f_out)
        old_right = bytes(left)
        left  = bytearray(old_left)
        right = bytearray(old_right)


    left  = _xor_bytes(bytes(left),  round_keys[0][:half])
    right = _xor_bytes(bytes(right), round_keys[0][half:])

    return bytes(left) + bytes(right)



def _cbc_encrypt(plaintext: bytes, round_keys: list, sbox: list, iv: bytes) -> bytes:
    padded = _pad(plaintext)
    ciphertext = b""
    prev = iv
    for i in range(0, len(padded), BLOCK_SIZE):
        block = padded[i:i + BLOCK_SIZE]
        xored = _xor_bytes(block, prev)
        enc   = _encrypt_block(xored, round_keys, sbox)
        ciphertext += enc
        prev = enc
    return ciphertext

def _cbc_decrypt(ciphertext: bytes, round_keys: list, sbox: list, iv: bytes) -> bytes:
    if len(ciphertext) % BLOCK_SIZE != 0:
        raise DecryptionError("Ciphertext length is not a multiple of block size")
    plaintext = b""
    prev = iv
    for i in range(0, len(ciphertext), BLOCK_SIZE):
        block = ciphertext[i:i + BLOCK_SIZE]
        dec   = _decrypt_block(block, round_keys, sbox)
        plaintext += _xor_bytes(dec, prev)
        prev = block
    return _unpad(plaintext)


def _compute_tag(auth_key: bytes, iv: bytes, ciphertext: bytes) -> bytes:
    return hmac.new(auth_key, iv + ciphertext, hashlib.sha3_256).digest()

def _verify_tag(auth_key: bytes, iv: bytes, ciphertext: bytes, tag: bytes) -> bool:
    expected = _compute_tag(auth_key, iv, ciphertext)
    return hmac.compare_digest(expected, tag)



def _pack(salt: bytes, iv: bytes, tag: bytes, ciphertext: bytes) -> bytes:
    """
    Format: MAGIC(4) | VERSION(1) | SALT(16) | IV(16) | TAG(32) | CIPHERTEXT(N)
    """
    return MAGIC + VERSION + salt + iv + tag + ciphertext

def _unpack(data: bytes) -> tuple:
    if len(data) < 4 + 1 + SALT_SIZE + IV_SIZE + TAG_SIZE + BLOCK_SIZE:
        raise DecryptionError("Data too short or corrupted")
    offset = 0
    magic = data[offset:offset + 4]; offset += 4
    if magic != MAGIC:
        raise DecryptionError("Invalid magic bytes - not an xploitenc ciphertext")
    ver = data[offset:offset + 1]; offset += 1
    salt = data[offset:offset + SALT_SIZE]; offset += SALT_SIZE
    iv   = data[offset:offset + IV_SIZE];   offset += IV_SIZE
    tag  = data[offset:offset + TAG_SIZE];  offset += TAG_SIZE
    ciphertext = data[offset:]
    return salt, iv, tag, ciphertext



class XploitCipher:
    """
    Main cipher object.

    Usage:
        cipher = XploitCipher(key="my-secret-key", bits=256)
        token  = cipher.encrypt("Hello World")
        plain  = cipher.decrypt(token)
    """

    def __init__(
        self,
        key: Union[str, bytes],
        bits: int = 256,
        iterations: int = 100_000
    ):
        if bits not in KEY_SIZES:
            raise InvalidKeyError(f"Key size must be one of {list(KEY_SIZES.keys())} bits")

        key_bytes   = _to_bytes(key)
        key_len     = KEY_SIZES[bits]
        self._bits  = bits
        self._iters = iterations


        self._password = key_bytes

    def _get_keys(self, salt: bytes):
        """Derive encryption key + auth key from password and salt"""
        full = _derive_key(self._password, salt, key_len=64, iterations=self._iters)
        enc_key  = full[:32]
        auth_key = full[32:]
        sbox     = _generate_sbox(enc_key)
        rkeys    = _expand_key(enc_key)
        return rkeys, sbox, auth_key

    def encrypt(self, plaintext: Union[str, bytes]) -> bytes:
        """Encrypt and return authenticated ciphertext bytes"""
        data = _to_bytes(plaintext)
        salt = os.urandom(SALT_SIZE)
        iv   = os.urandom(IV_SIZE)
        rkeys, sbox, auth_key = self._get_keys(salt)
        ciphertext = _cbc_encrypt(data, rkeys, sbox, iv)
        tag  = _compute_tag(auth_key, iv, ciphertext)
        return _pack(salt, iv, tag, ciphertext)

    def decrypt(self, data: bytes) -> bytes:
        """Verify and decrypt ciphertext, returns original plaintext bytes"""
        salt, iv, tag, ciphertext = _unpack(data)
        rkeys, sbox, auth_key = self._get_keys(salt)
        if not _verify_tag(auth_key, iv, ciphertext, tag):
            raise DecryptionError("Authentication failed - wrong key or tampered data")
        return _cbc_decrypt(ciphertext, rkeys, sbox, iv)

    def encrypt_to_base64(self, plaintext: Union[str, bytes]) -> str:
        """Encrypt and return base64-encoded string"""
        return base64.b64encode(self.encrypt(plaintext)).decode()

    def decrypt_from_base64(self, data: str) -> str:
        """Decrypt from base64 string and return UTF-8 string"""
        raw = base64.b64decode(data)
        return self.decrypt(raw).decode("utf-8")



def encrypt(plaintext: Union[str, bytes], key: Union[str, bytes], bits: int = 256) -> bytes:
    """Quick encrypt - returns raw bytes"""
    return XploitCipher(key, bits=bits).encrypt(plaintext)

def decrypt(data: bytes, key: Union[str, bytes], bits: int = 256) -> bytes:
    """Quick decrypt - returns plaintext bytes"""
    return XploitCipher(key, bits=bits).decrypt(data)

def generate_key(bits: int = 256) -> str:
    """Generate a cryptographically secure random key (hex string)"""
    if bits not in KEY_SIZES:
        raise InvalidKeyError(f"bits must be one of {list(KEY_SIZES.keys())}")
    return os.urandom(KEY_SIZES[bits]).hex()


def hash_password(password: Union[str, bytes], iterations: int = 200_000) -> str:
    """
    Hash a password securely.
    Returns a string token that can be stored safely.
    """
    pw = _to_bytes(password)
    salt = os.urandom(SALT_SIZE)
    dk = _derive_key(pw, salt, key_len=32, iterations=iterations)
    payload = {
        "v": 1,
        "iter": iterations,
        "salt": base64.b64encode(salt).decode(),
        "hash": base64.b64encode(dk).decode(),
    }
    return "xenc$" + base64.b64encode(json.dumps(payload).encode()).decode()

def verify_password(password: Union[str, bytes], token: str) -> bool:
    """Verify a password against a stored hash token"""
    try:
        if not token.startswith("xenc$"):
            return False
        payload = json.loads(base64.b64decode(token[5:]).decode())
        pw   = _to_bytes(password)
        salt = base64.b64decode(payload["salt"])
        expected = base64.b64decode(payload["hash"])
        iters = payload.get("iter", 200_000)
        actual = _derive_key(pw, salt, key_len=32, iterations=iters)
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False



def sign(message: Union[str, bytes], private_key: Union[str, bytes]) -> str:
    """
    Sign a message and return a signature token.
    Uses double-HMAC with timestamp for replay protection.
    """
    msg = _to_bytes(message)
    pk  = _to_bytes(private_key)
    ts  = struct.pack(">Q", int(time.time()))
    nonce = os.urandom(8)

    inner = hmac.new(pk, msg + ts + nonce, hashlib.sha3_256).digest()
    outer = hmac.new(pk + inner, msg,      hashlib.sha3_512).digest()

    payload = {
        "ts":    base64.b64encode(ts).decode(),
        "nonce": base64.b64encode(nonce).decode(),
        "sig":   base64.b64encode(outer).decode(),
    }
    return "xsig$" + base64.b64encode(json.dumps(payload).encode()).decode()

def verify_signature(
    message: Union[str, bytes],
    signature: str,
    public_key: Union[str, bytes],
    max_age: int = 3600
) -> bool:
    """
    Verify a signature token.
    max_age: maximum allowed age in seconds (default 1 hour).
    """
    try:
        if not signature.startswith("xsig$"):
            raise SignatureError("Invalid signature format")
        msg = _to_bytes(message)
        pk  = _to_bytes(public_key)
        payload = json.loads(base64.b64decode(signature[5:]).decode())
        ts    = base64.b64decode(payload["ts"])
        nonce = base64.b64decode(payload["nonce"])
        sig   = base64.b64decode(payload["sig"])
        ts_val = struct.unpack(">Q", ts)[0]
        if int(time.time()) - ts_val > max_age:
            raise SignatureError("Signature has expired")
        inner    = hmac.new(pk, msg + ts + nonce, hashlib.sha3_256).digest()
        expected = hmac.new(pk + inner, msg,       hashlib.sha3_512).digest()
        return hmac.compare_digest(expected, sig)
    except SignatureError:
        raise
    except Exception:
        return False


class KeyManager:
    """
    Manages multiple named keys for different purposes.

    Usage:
        km = KeyManager(master_key="my-master")
        km.add_key("db_key", bits=256)
        km.add_key("file_key", bits=512)
        enc = km.encrypt_with("db_key", "sensitive data")
        dec = km.decrypt_with("db_key", enc)
    """

    def __init__(self, master_key: Union[str, bytes]):
        self._master = _to_bytes(master_key)
        self._keys: dict = {}

    def add_key(self, name: str, bits: int = 256, key: Optional[str] = None):
        """Add a named key (auto-generated or provided)"""
        if bits not in KEY_SIZES:
            raise InvalidKeyError(f"bits must be one of {list(KEY_SIZES.keys())}")
        if key is None:
            key = generate_key(bits)
        self._keys[name] = {"key": key, "bits": bits}
        return key

    def get_cipher(self, name: str) -> XploitCipher:
        if name not in self._keys:
            raise InvalidKeyError(f"Key '{name}' not found")
        k = self._keys[name]
        return XploitCipher(k["key"], bits=k["bits"])

    def encrypt_with(self, key_name: str, plaintext: Union[str, bytes]) -> bytes:
        return self.get_cipher(key_name).encrypt(plaintext)

    def decrypt_with(self, key_name: str, data: bytes) -> bytes:
        return self.get_cipher(key_name).decrypt(data)

    def export(self) -> str:
        """Export all keys encrypted with the master key (base64 string)"""
        payload = json.dumps(self._keys).encode()
        c = XploitCipher(self._master)
        return base64.b64encode(c.encrypt(payload)).decode()

    def load(self, exported: str):
        """Load keys from an exported string"""
        c = XploitCipher(self._master)
        raw = c.decrypt(base64.b64decode(exported))
        self._keys = json.loads(raw.decode())

    def list_keys(self) -> list:
        return list(self._keys.keys())



class SecureVault:
    """
    An in-memory encrypted key-value store. Save/load to disk securely.

    Usage:
        vault = SecureVault("my-master-password")
        vault.set("api_key", "sk-1234567890")
        vault.set("db_pass", "supersecret")
        vault.save("vault.xenc")

        vault2 = SecureVault("my-master-password")
        vault2.load("vault.xenc")
        print(vault2.get("api_key"))  # sk-1234567890
    """

    def __init__(self, master_password: Union[str, bytes]):
        self._cipher = XploitCipher(master_password, bits=256)
        self._data: dict = {}

    def set(self, key: str, value: Union[str, bytes, int, float, dict, list]):
        self._data[key] = value

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def delete(self, key: str):
        self._data.pop(key, None)

    def keys(self) -> list:
        return list(self._data.keys())

    def save(self, filepath: str):
        """Encrypt and save vault to a file"""
        try:
            payload = json.dumps(self._data).encode()
            enc = self._cipher.encrypt(payload)
            with open(filepath, "wb") as f:
                f.write(enc)
        except Exception as e:
            raise VaultError(f"Failed to save vault: {e}")

    def load(self, filepath: str):
        """Load and decrypt vault from a file"""
        try:
            with open(filepath, "rb") as f:
                enc = f.read()
            raw = self._cipher.decrypt(enc)
            self._data = json.loads(raw.decode())
        except (DecryptionError, json.JSONDecodeError) as e:
            raise VaultError(f"Failed to load vault (wrong password or corrupted file): {e}")
        except FileNotFoundError:
            raise VaultError(f"Vault file not found: {filepath}")
