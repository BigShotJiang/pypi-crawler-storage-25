# xploitenc 🔐

A powerful custom encryption library for Python — built from scratch, no dependencies.

---

## Installation

Install `xploitenc` via pip

```bash
pip install xploitenc
```

---

## Quick Start

```python
import xploitenc

# Encrypt & decrypt
enc = xploitenc.encrypt("Hello!", key="my-secret-key")
dec = xploitenc.decrypt(enc, key="my-secret-key")
print(dec.decode())  # Hello!

# Generate a secure random key
key = xploitenc.generate_key(bits=256)
```

---

## Features

### XploitCipher — Main Cipher
```python
cipher = xploitenc.XploitCipher("password", bits=256)  # 128 / 256 / 512

enc  = cipher.encrypt(b"data")
dec  = cipher.decrypt(enc)

b64  = cipher.encrypt_to_base64("data")   # returns str
text = cipher.decrypt_from_base64(b64)    # returns str
```

### Password Hashing
```python
hashed = xploitenc.hash_password("MyPassword123!")
xploitenc.verify_password("MyPassword123!", hashed)  # True
xploitenc.verify_password("WrongPassword",  hashed)  # False
```

### Digital Signatures
```python
key = xploitenc.generate_key(256)
sig = xploitenc.sign("my message", key)
xploitenc.verify_signature("my message", sig, key)   # True
xploitenc.verify_signature("tampered",   sig, key)   # False
```

### KeyManager — Multiple Keys
```python
km = xploitenc.KeyManager(master_key="master-password")
km.add_key("db_key",  bits=256)
km.add_key("api_key", bits=128)

enc = km.encrypt_with("db_key", "secret")
dec = km.decrypt_with("db_key", enc)

exported = km.export()   # save all keys (encrypted)
km.load(exported)        # restore
```

### SecureVault — Encrypted Config Store
A safe alternative to `.env` files — everything is encrypted on disk.

```python
# Save secrets
vault = xploitenc.SecureVault("master-password")
vault.set("api_key", "sk-abc123")
vault.set("db_pass", "P@ssw0rd!")
vault.save("vault.xenc")

# Load secrets
vault = xploitenc.SecureVault("master-password")
vault.load("vault.xenc")
print(vault.get("api_key"))  # sk-abc123
```

> **Tip:** Add `vault.xenc` to `.gitignore` — never commit it.

---

## Error Handling

```python
try:
    xploitenc.decrypt(data, "wrong-key")
except xploitenc.DecryptionError:
    print("Wrong key or tampered data")

try:
    xploitenc.verify_signature(msg, expired_sig, key)
except xploitenc.SignatureError:
    print("Signature invalid or expired")
```

---

## How It Works

| Layer | Details |
|-------|---------|
| Cipher | 16-round Feistel network (XSCC) |
| S-Box | Key-dependent, non-linear substitution |
| Diffusion | GF(2⁸) MixColumns — identical to AES |
| Key derivation | PBKDF2-SHA256 + SHA3-256 chain, 100k iterations, random salt per message |
| Integrity | HMAC-SHA3-256 authentication tag on every message |
| Key sizes | 128 / 256 / 512-bit |

---

## Key Sizes

| Bits | Use Case |
|------|----------|
| 128 | General data |
| 256 | Sensitive data *(default)* |
| 512 | Maximum security |
