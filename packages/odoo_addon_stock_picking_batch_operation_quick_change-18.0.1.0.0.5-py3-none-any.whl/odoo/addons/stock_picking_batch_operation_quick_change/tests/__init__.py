# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import test_stock_picking_batch_operation_quick_change
