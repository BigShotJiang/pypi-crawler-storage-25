import os
import sys
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.theme import Theme
from prompt_toolkit import prompt
from prompt_toolkit.history import FileHistory
from aura.core.engine import AuraEngine

console = Console(theme=Theme({"aura": "bold cyan", "tool": "dim yellow", "err": "bold red"}))

LOGO = """[bold cyan]
     ╔═══════════════════════════════════════╗
     ║            ✨  A U R A  ✨            ║
     ║       Your Intelligent Presence       ║
     ╚═══════════════════════════════════════╝[/bold cyan]"""

TOOL_ICONS = {
    "execute_command": "⚡",
    "read_file": "📖",
    "write_file": "✏️ ",
    "search_files": "🔍",
    "list_directory": "📁",
    "send_email": "📧",
    "create_document": "📄",
}


def show_tool(name, args):
    icon = TOOL_ICONS.get(name, "🔧")
    detail = args.get("command") or args.get("path") or args.get("to") or args.get("pattern") or ""
    console.print(f"  [tool]{icon} {name}:[/tool] [dim]{str(detail)[:80]}[/dim]")


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "setup":
        from aura.core.config import run_setup
        run_setup()
        return

    from aura.core.config import get_api_key
    key = get_api_key()
    if not key:
        from aura.core.config import run_setup
        run_setup()
        key = get_api_key()
        if not key:
            console.print("  [err]No key provided. Exiting.[/err]")
            sys.exit(1)

    console.print(LOGO)
    console.print("  [dim]Type naturally. 'exit' to quit.[/dim]\n")
    console.rule("[cyan]session[/cyan]")

    engine = AuraEngine(api_key=key, tool_callback=show_tool)
    hist = FileHistory(os.path.expanduser("~/.aura_history"))

    while True:
        try:
            inp = prompt("\n  ❯ ", history=hist).strip()
            if not inp:
                continue
            if inp.lower() in ("exit", "quit", "bye"):
                break

            console.print()
            with console.status("  [cyan]thinking...[/cyan]", spinner="dots"):
                from aura.core.config import get_msg_count, increment_msg_count, is_subscribed
                if not is_subscribed() and get_msg_count() >= 5:
                    console.print(Panel(
                        "[bold]Free limit reached (5 messages)[/bold]\n\n"
                        "  Contact admin for subscription to continue using Aura.\n"
                        "  Email: support@aura-ai.com",
                        border_style="yellow",
                        title="[yellow]⚡ Upgrade Required[/yellow]",
                    ))
                    continue
                resp = engine.chat(inp)
                increment_msg_count()

            console.print()
            console.print(Panel(Markdown(resp), border_style="cyan", padding=(1, 2)))

        except KeyboardInterrupt:
            break
        except Exception as e:
            console.print(f"\n  [err]{e}[/err]")

    console.print()
    console.rule("[cyan]end[/cyan]")
    console.print("  [cyan]✨[/cyan]\n")


if __name__ == "__main__":
    main()
