"""
Settings window for Alto — native window with web UI via pywebview.

The webview runs in a subprocess because GTK webview requires the main
thread, which is occupied by pystray + hotkey listener in the daemon.
"""

import json
import logging
import subprocess
import sys
import threading
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from alto.config import ServiceConfig, save_config

if TYPE_CHECKING:
    from alto.api_client import AltoAPIClient
    from alto.platforms.linux.hotkey import HotkeyListener

logger = logging.getLogger(__name__)

LANGUAGES = {
    "fr": "Francais",
    "en": "English",
    "es": "Espanol",
    "de": "Deutsch",
    "it": "Italiano",
    "pt": "Portugues",
    "nl": "Nederlands",
    "pl": "Polski",
    "ru": "Russian",
    "ja": "Japanese",
    "zh": "Chinese",
    "ko": "Korean",
    "ar": "Arabic",
}

_SETTINGS_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Alto</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, sans-serif;
         background: #fafafa; color: #1a1a1a; padding: 24px 24px 20px;
         -webkit-user-select: none; user-select: none; }

  .header { margin-bottom: 18px; }
  .header h1 { font-size: 18px; font-weight: 700; color: #1a1a1a; }
  .header p { color: #888; font-size: 12px; margin-top: 2px; }

  .card { background: #fff; border: 1px solid #e5e5e5; border-radius: 10px;
          padding: 14px 18px; margin-bottom: 10px; }
  .card-title { font-size: 10px; font-weight: 600; text-transform: uppercase;
                letter-spacing: 0.5px; color: #1a1a1a; margin-bottom: 10px; }

  select, .key-display { width: 100%; padding: 8px 12px; font-size: 13px; font-family: inherit;
           background: #fff; border: 1px solid #ddd; border-radius: 8px;
           color: #1a1a1a; outline: none; transition: border-color 0.15s; }
  select:focus { border-color: #1a1a1a; }

  .hint { font-size: 11px; color: #999; margin-top: 5px; }

  .account-row { display: flex; align-items: center; gap: 8px; margin-bottom: 2px; }
  .account-email { font-size: 13px; font-weight: 500; color: #1a1a1a; }
  .account-tier { font-size: 10px; color: #1a1a1a; background: #f0f0f0; padding: 2px 7px;
                  border-radius: 4px; font-weight: 500; }
  .usage-text { font-size: 12px; color: #666; margin-top: 4px; }
  .bar-bg { height: 3px; background: #e5e5e5; border-radius: 2px; overflow: hidden; margin-top: 6px; }
  .bar-fill { height: 100%; background: #1a1a1a; border-radius: 2px; transition: width 0.3s; min-width: 3px; }
  .bar-fill.warn { background: #e0a030; }
  .bar-fill.crit { background: #d04040; }

  .upgrade-link { display: inline-block; font-size: 12px; color: #1a1a1a; font-weight: 500;
                  margin-top: 8px; text-decoration: none; border-bottom: 1px solid #1a1a1a;
                  padding-bottom: 1px; cursor: pointer; transition: opacity 0.15s; }
  .upgrade-link:hover { opacity: 0.6; }

  .key-row { display: flex; gap: 8px; align-items: stretch; }
  .key-display { flex: 1; display: flex; align-items: center; font-size: 13px; font-weight: 500; }
  .detect-btn { padding: 8px 14px; font-size: 12px; font-family: inherit;
                background: #fff; border: 1px solid #ddd;
                border-radius: 8px; color: #1a1a1a; cursor: pointer; white-space: nowrap;
                transition: all 0.15s; }
  .detect-btn:hover { border-color: #1a1a1a; }
  .detect-btn.detecting { background: #fff8e1; color: #8a6d00; border-color: #e0d090;
                          cursor: wait; }

  .actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px; }
  .btn { padding: 9px 20px; font-size: 13px; font-family: inherit; border-radius: 8px;
         border: none; cursor: pointer; font-weight: 500; transition: all 0.15s; }
  .btn-cancel { background: #fff; color: #1a1a1a; border: 1px solid #e5e5e5; }
  .btn-cancel:hover { border-color: #1a1a1a; }
  .btn-save { background: #1a1a1a; color: #fff; }
  .btn-save:hover { background: #333; }

  .not-connected { color: #999; font-size: 12px; }
</style>
</head>
<body>
  <div class="header">
    <h1>Settings</h1>
    <p>Alto — voice dictation</p>
  </div>

  <div class="card" id="account-card" style="display:{account_display}">
    <div class="card-title">Account</div>
    <div id="account-content">{account_html}</div>
  </div>

  <div class="card">
    <div class="card-title">Language</div>
    <select id="language">{language_options}</select>
  </div>

  <div class="card">
    <div class="card-title">Push-to-talk key</div>
    <div class="key-row">
      <div class="key-display" id="key-display">{current_key}</div>
      <button class="detect-btn" id="detect-btn" onclick="detectKey()">Detect</button>
    </div>
    <div class="hint">Click Detect then press the desired key</div>
  </div>

  <div class="actions">
    <button class="btn btn-cancel" onclick="cancel()">Cancel</button>
    <button class="btn btn-save" onclick="save()">Save</button>
  </div>

<script>
var currentKey = "{current_key}";

function detectKey() {
  var btn = document.getElementById('detect-btn');
  btn.textContent = 'Press...';
  btn.classList.add('detecting');
  btn.disabled = true;
  pywebview.api.detect_key().then(function(key) {
    if (key) {
      currentKey = key;
      document.getElementById('key-display').textContent = key;
    }
    btn.textContent = 'Detect';
    btn.classList.remove('detecting');
    btn.disabled = false;
  });
}

function save() {
  var data = JSON.stringify({
    language: document.getElementById('language').value,
    evdev_key: currentKey
  });
  pywebview.api.save_settings(data);
}

function cancel() {
  pywebview.api.close_window();
}


</script>
</body>
</html>"""


def _build_account_html(api_client: Optional["AltoAPIClient"]) -> tuple[str, str]:
    if api_client is None:
        return "", "none"
    try:
        user_info = api_client.get_me()
    except Exception:
        return '<span class="not-connected">Not connected</span>', "block"

    email = user_info.get("email", "")
    tier = user_info.get("tier", "free").capitalize()
    html = f'<div class="account-row">'
    html += f'<span class="account-email">{email}</span>'
    html += f'<span class="account-tier">{tier}</span></div>'

    try:
        usage = api_client.get_usage()
        secs = usage.get("audio_seconds", 0)
        mins = secs / 60.0
        t = user_info.get("tier", "free")
        lim = {"free": 15, "pro": 180, "max": 600}.get(t, 0)
        if lim > 0:
            pct = min(1.0, mins / lim)
            cls = " crit" if pct >= 0.9 else (" warn" if pct >= 0.7 else "")
            html += f'<div class="usage-text">{mins:.1f} / {lim} min</div>'
            html += f'<div class="bar-bg"><div class="bar-fill{cls}" style="width:{pct*100:.0f}%"></div></div>'
        else:
            html += f'<div class="usage-text">{mins:.1f} min (unlimited)</div>'
    except Exception:
        pass

    active = user_info.get("subscription_active", False)
    t = user_info.get("tier", "free")
    if not active and t == "free":
        # Pre-generate checkout URL
        try:
            checkout_url = api_client.create_checkout("pro")
            if checkout_url:
                html += f'<a class="upgrade-link" href="{checkout_url}" target="_blank">Upgrade to Pro →</a>'
        except Exception:
            pass

    return html, "block"


def _build_language_options(current: str) -> str:
    return "".join(
        f'<option value="{code}" {"selected" if code == current else ""}>{name} ({code})</option>'
        for code, name in LANGUAGES.items()
    )


def open_settings_window(
    config: ServiceConfig,
    config_path: Path,
    on_close: Optional[Callable[[bool], None]] = None,
    api_client: Optional["AltoAPIClient"] = None,
    # Legacy compat
    on_save: Optional[Callable[[], None]] = None,
    hotkey_listener: Optional["HotkeyListener"] = None,
) -> None:
    thread = threading.Thread(
        target=_run_settings,
        args=(config, config_path, on_close or (lambda saved: on_save() if saved and on_save else None), api_client),
        daemon=True,
        name="SettingsWindow",
    )
    thread.start()


def _run_settings(
    config: ServiceConfig,
    config_path: Path,
    on_close: Optional[Callable[[bool], None]],
    api_client: Optional["AltoAPIClient"],
) -> None:
    # Build page HTML
    account_html, account_display = _build_account_html(api_client)
    page = (
        _SETTINGS_HTML
        .replace("{account_display}", account_display)
        .replace("{account_html}", account_html)
        .replace("{language_options}", _build_language_options(config.language))
        .replace("{current_key}", config.evdev_key)
    )

    # Run webview in a subprocess (GTK needs the main thread)
    proc = subprocess.run(
        [sys.executable, "-c", _SUBPROCESS_CODE],
        input=page,
        capture_output=True,
        text=True,
        timeout=600,
    )

    logger.info(f"Settings subprocess stdout: {proc.stdout.strip()!r}")

    result = None
    stdout = proc.stdout.strip()
    # Extract last line (JSON result), ignore any prior debug output
    if stdout:
        last_line = stdout.splitlines()[-1]
        try:
            result = json.loads(last_line)
        except json.JSONDecodeError:
            logger.warning(f"Settings subprocess output not JSON: {last_line!r}")

    if proc.stderr.strip():
        for line in proc.stderr.strip().split("\n"):
            if "Gtk" not in line and "WARNING" not in line:
                logger.debug(f"Settings subprocess: {line}")

    logger.info(f"Settings subprocess exited with code {proc.returncode}")

    saved = False
    if result and result.get("saved"):
        config.language = result.get("language", config.language)
        config.evdev_key = result.get("evdev_key", config.evdev_key)
        try:
            config.validate()
            save_config(config_path, config)
            logger.info("Settings saved")
            saved = True
        except Exception as e:
            logger.error(f"Settings save error: {e}")

    logger.info(f"Settings window closed (saved={saved}), calling on_close")
    if on_close:
        on_close(saved)


# Code executed in the subprocess — receives HTML on stdin, outputs JSON on stdout
_SUBPROCESS_CODE = '''
import json
import sys
import threading

html = sys.stdin.read()
result = {"saved": False}

def detect_key(timeout=10.0):
    try:
        import select, time, evdev
        from evdev import InputDevice, ecodes
        devices = []
        for path in evdev.list_devices():
            try:
                dev = InputDevice(path)
                if "alto" in dev.name.lower():
                    dev.close()
                    continue
                caps = dev.capabilities(verbose=False)
                if ecodes.EV_KEY in caps:
                    devices.append(dev)
            except (OSError, PermissionError):
                continue
        if not devices:
            return ""
        fd_map = {dev.fd: dev for dev in devices}
        deadline = time.time() + timeout
        try:
            while time.time() < deadline:
                r, _, _ = select.select(fd_map.keys(), [], [], 0.2)
                for fd in r:
                    dev = fd_map[fd]
                    for event in dev.read():
                        if event.type == ecodes.EV_KEY and event.value == 1 and event.code < 272:
                            key_event = evdev.categorize(event)
                            name = key_event.keycode
                            if isinstance(name, (list, tuple)):
                                name = name[0]
                            return name
        finally:
            for dev in devices:
                try: dev.close()
                except: pass
    except Exception:
        pass
    return ""

class Api:
    def detect_key(self):
        return detect_key()

    def save_settings(self, data_json):
        data = json.loads(data_json)
        result["saved"] = True
        result["language"] = data.get("language", "en")
        result["evdev_key"] = data.get("evdev_key", "KEY_GRAVE")
        # Delay destroy to let the js_bridge_call wrapper finish first
        threading.Timer(0.2, window.destroy).start()

    def close_window(self):
        threading.Timer(0.1, window.destroy).start()

    def upgrade(self):
        pass

import webview
api = Api()
window = webview.create_window("Alto", html=html, js_api=api,
                               width=440, height=460, resizable=False,
                               text_select=False)
webview.start()
print(json.dumps(result), flush=True)
'''


def _detect_next_key(timeout: float = 10.0) -> str:
    """Fallback key detection (used outside webview)."""
    try:
        import select
        import time
        import evdev
        from evdev import InputDevice, ecodes

        devices = []
        for path in evdev.list_devices():
            try:
                dev = InputDevice(path)
                if "alto" in dev.name.lower():
                    dev.close()
                    continue
                caps = dev.capabilities(verbose=False)
                if ecodes.EV_KEY in caps:
                    devices.append(dev)
            except (OSError, PermissionError):
                continue
        if not devices:
            return ""
        fd_map = {dev.fd: dev for dev in devices}
        deadline = time.time() + timeout
        try:
            while time.time() < deadline:
                r, _, _ = select.select(fd_map.keys(), [], [], 0.2)
                for fd in r:
                    dev = fd_map[fd]
                    for event in dev.read():
                        if event.type == ecodes.EV_KEY and event.value == 1 and event.code < 272:
                            from evdev import categorize
                            key_event = categorize(event)
                            name = key_event.keycode
                            if isinstance(name, (list, tuple)):
                                name = name[0]
                            return name
        finally:
            for dev in devices:
                try:
                    dev.close()
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"Key detection failed: {e}")
    return ""
