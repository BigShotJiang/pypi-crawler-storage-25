"""LinkFile CLI package."""
