# PetriTUB

The Python toolbox ``petritub`` allows to manipulate untimed Petri nets and provides max-plus and min-plus algebra tools for the study of timed event graphs.

For instance, the library provides functions for performing the following tasks:

- Drawing the coverability tree for a given Petri net
- Computing the maximally permissive state-based controller, given a set of specifications
- Finding the cycle time of a timed event graph and solving the related eigenproblem
- Drawing the trajectory of a timed event graph as a Gantt chart

Please read the [documentation](https://control.gitlab-pages.tu-berlin.de/discrete-event-systems/petritub).

## Directory structure

- **./petritub/**: contains the toolbox. Import the individual modules `from petritub.module_name import *` to use the toolbox.
- **./doc/**: contains the Sphinx source documentation of the toolbox.
- **./figures/**: contains some figures for the tutorial jupyter notebooks.
- Two jupyter notebook tutorials (`tutorial_max_plus.ipynb` and `tutorial_untimed_pn.ipynb`) demonstrating the usage of the toolbox are in the root folder.

## Authors

The toolbox is continuously developed at the [Control Systems Group](https://www.control.tu-berlin.de/) of the [Technical University Berlin](https://www.tu.berlin/). The first version of the code was designed in the summer semester of 2022 by Jan Bednar, Jan Clevorn, Jakub Dvorak, Dominik Tirpak, under the supervision of Davide Zorzenon, as part of the course "Projekt Synthese und Analyse von Regelsystemen". External contributions are highly welcome, for contact write to [Davide Zorzenon](mailto:davide.zorzenon@tu-berlin.de).
