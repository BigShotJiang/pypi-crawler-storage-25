from __future__ import annotations
import math
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

from ._node import Node, OMEGA
from ._coverability import CoverabilityTree, _isGreaterEqual
from ._state_controller import StateController


def _getFontSizeCT(numPlaces: int) -> int:
    if numPlaces <= 6:
        return 10
    elif numPlaces <= 10:
        return 9
    elif numPlaces <= 15:
        return 8
    elif numPlaces <= 20:
        return 7
    elif numPlaces <= 28:
        return 6
    elif numPlaces <= 36:
        return 5
    elif numPlaces <= 48:
        return 4
    elif numPlaces <= 65:
        return 3
    elif numPlaces <= 100:
        return 2
    else:
        return 1

class PetriNet():
    """ Class that represents Petri net with the initial vector x0 and the
        matrices Aplus and Aminus.

        Attributes
        ----------
        Aplus : np.ndarray
            The entries of this matrix represent the number of tokens that
            place p_i gains when transition t_j fires.
        Aminus : np.ndarray
            The entries of this matrix represent the number of tokens that
            place p_i loses when transition t_j fires. 
        x0 : np.ndarray
            Initial marking vector.
        A : np.ndarray
            Incidence matrix of the Petri net. Computed internally from
            matrices Aplus and Aminus.
        _coverabilityTree : CoverabilityTree
            Instance of the class CoverabilityTree. If the coverability tree
            has not yet been calculated, the attribute has the value None.
        
        Examples
        --------
        To create an instance of the PetriNet class. Pass the matrices Aplus,
        Aminus and the initial marking vector (as a column vector).
        
        >>> A_plus = np.array([[0, 1, 0, 1, 0],
        ...                    [0, 0, 0, 1, 0],
        ...                    [1, 0, 1, 0, 0],
        ...                    [0, 0, 1, 0, 1],
        ...                    [0, 0, 0, 1, 0]])
        >>> A_minus = np.array([[1, 0, 0, 1, 0],
        ...                     [0, 0, 0, 0, 0],
        ...                     [0, 1, 1, 0, 0],
        ...                     [0, 0, 0, 1, 0],
        ...                     [0, 0, 0, 0, 1]])
        >>> x0 = np.array([[1],
        ...                [0],
        ...                [0],
        ...                [0],
        ...                [0]])
        >>> pn = PetriNet(A_plus, A_minus, x0)
    """

    def __init__(self, Aplus: np.ndarray, Aminus: np.ndarray,
                 x0: np.ndarray) -> None:

        self.Aplus: np.ndarray = Aplus.astype(float)
        self.Aminus: np.ndarray = Aminus.astype(float)
        self.A: np.ndarray = np.subtract(Aplus, Aminus)
        self.x0: np.ndarray = x0.astype(float)
        self._coverabilityTree: CoverabilityTree | None = None

    def _possibleTransitions(self, node: Node) -> list[int]:
        """
        PRIVATE: Finds all transitions that can fire in a given node.
        """

        # Transitions are represented as column numbers.
        _possibleTransitions = []
        # Try all transitions and append the ones that are defined
        for i in range(np.shape(self.Aminus)[1]):
            if _isGreaterEqual(node._state, self.Aminus[:, [i]]):
                _possibleTransitions.append(i)
        return _possibleTransitions

    def _computeCoverabilityTree(self) -> None:
        """
        PRIVATE: Computes the coverability tree of the Petri net for which this function
        has been called. It saves the coverability tree as its attribute
        and does not return any value.
        """

        # Initialize the root node
        root_node = Node(self.x0, 0)

        # Initialize the coverability tree
        ct = CoverabilityTree(root_node)

        # Repeat untill all nodes are explored
        while ct._emptyUnxplored() is not True:

            # Choose a node from unxplore nodes and evaluate f(x^k, t_j)
            # for all possible transitions
            node = ct._explore()
            _possibleTransitions = self._possibleTransitions(node)

            # Check if node is a deadlock
            if len(_possibleTransitions) == 0:
                node._deadlock = True
                # Check if it is also a duplicate
                if ct._containsState(node._state):
                    node._duplicate = True
            else:
                # Check if the node is a duplicate
                if ct._containsState(node._state):
                    node._duplicate = True
                else:
                    # If there are possible transitions, create a new node
                    for transition in _possibleTransitions:
                        # Fire the transition
                        new_node = ct._fire(node, transition, self.Aminus,
                                           self.A)
                        # Check if a new_node has been indeed created
                        # (same child may have existed already)
                        if new_node is not None:
                            ct._addUnexplored(new_node)

            # Add the node to the explored ones
            ct._addExplored(node)

        # Save the coverability tree as an attribute
        self._coverabilityTree = ct

    def _getOrComputeTree(self) -> CoverabilityTree:
        """Returns the coverability tree, computing it first if needed."""
        if self._coverabilityTree is None:
            self._computeCoverabilityTree()
        assert self._coverabilityTree is not None
        return self._coverabilityTree

    def _computeCoverabilityTreeLD(self) -> bool:
        """
        PRIVATE: Computes the coverability tree of the Petri net for the case
        when only the information about the liveness of transitions is needed.
        Therefore useful for large coverability trees. If all transitions
        have been fired at least once, it stops and returns True.
        """
        
        transArr = np.zeros(np.shape(self.Aminus)[1])
        
        # Initialize the root node
        root_node = Node(self.x0, 0)

        # Initialize the coverability tree
        ct = CoverabilityTree(root_node)

        # Repeat untill all nodes are explored
        while ct._emptyUnxplored() is not True:

            # Choose a node from unxplore nodes and evaluate f(x^k, t_j)
            # for all possible transitions
            node = ct._explore()
            _possibleTransitions = self._possibleTransitions(node)
            
            for t in _possibleTransitions:
                transArr[t] = 1
                
            if ((transArr > 0).all()):
                return True
            
            # Check if node is a deadlock
            if len(_possibleTransitions) == 0:
                node._deadlock = True
                # Check if it is also a duplicate
                if ct._containsState(node._state):
                    node._duplicate = True
            else:
                # Check if the node is a duplicate
                if ct._containsState(node._state):
                    node._duplicate = True
                else:
                    # If there are possible transitions, create a new node
                    for transition in _possibleTransitions:
                        # Fire the transition
                        new_node = ct._fire(node, transition, self.Aminus,
                                           self.A)
                        # Check if a new_node has been indeed created
                        # (same child may have existed already)
                        if new_node is not None:
                            ct._addUnexplored(new_node)

            # Add the node to the explored ones
            ct._addExplored(node)
        
        # Save the coverability tree as an attribute
        self._coverabilityTree = ct
        
        return False
    
    def setInitialMarking(self, new_x0: np.ndarray) -> None:
        """ Sets the initial marking vector of a Petri net.
        
        Use this function if you want to change the initial marking vector
        x0 of an already existing Petri net. It will set the new initial
        marking vector as the attribute x0 of that Petri net and reset 
        the coverability tree.
        
        Parameters
        ----------
        new_x0 : np.ndarray
            New initial marking vector.

        Returns
        -------
        None
    
        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created.
        
        >>> new_x0 = np.array([[0],
        ...                    [0],
        ...                    [1],
        ...                    [0],
        ...                    [1]])
        >>> pn.setInitialMarking(new_x0)
        
        """
        
        #set the new initial marking vector as the attribute x0
        self.x0 = new_x0.astype(float)
        
        #reset the coverability tree
        self._coverabilityTree = None
        
    def isBounded(self) -> bool:
        """Checks the boundedness of a Petri net.
        
        Checks if a Petri net is bounded using its coverability tree, seeing
        whether there are any unbounded places containing an omega.
        If the coverability tree has not been computed yet,
        it will do so automatically.
        
        Parameters
        ----------
        None

        Returns
        -------
        bool
            `True` if the Petri net is bounded, `False` if it
            is not bounded.
    
        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created
        and the Petri net `pn` is not bounded.
        
        >>> print(pn.isBounded())
        False
        
        """

        # Compute coverability tree if it is not already available
        ct = self._getOrComputeTree()

        # Search all explored nodes of the coverability tree for OMEGA
        for node in ct._explored:
            for i in range(np.shape(node._state)[0]):
                if(node._state[i, 0] == OMEGA):
                    return False

        # Petri Net is bounded if OMEGA was not found
        return True

    def isTransitionDead(self, transition: int) -> bool:
        """Checks the liveness of a transition.
        
        Checks the liveness of a given transition in the Petri for which
        this function is called using its coverability tree. This function
        does not differentiate between the specific types of live transitions
        as L1-live, L3-live and live. It solely tells you whether a transition
        is dead or not (i.e., at least L1-live). If the coverability tree has
        not been computed yet, it will do so automatically.

        Parameters
        ----------
        transition : int
            An integer value corresponding to the 
            transition of which the liveness should be checked.
            
        Returns
        -------
        bool
            `True` if the given transition is dead, `False` if it
            is at least L1-live.

        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created,
        in which transition t1 is L3-live, transition t2 is live
        and transition t3 is dead.
        
        >>> print(pn.isTransitionDead(1))
        True
        >>> print(pn.isTransitionDead(2))
        True
        >>> print(pn.isTransitionDead(3))
        False

        """

        # Compute coverability tree if it is not already available
        ct = self._getOrComputeTree()

        # Subtract 1 as toolbox works with numbers of A-columns
        # which are indexed from 0
        if transition - 1 in ct._fired_transitions:
            return False
        else:
            return True

    def _LiveDeadTransitions(self) -> list[list[int]]:
        '''PRIVATE: Returns a list of L1-live transitions
        and a list of dead transitions.'''
        
        allLive = False
        
        # Compute coverability tree if it is not already available
        if self._coverabilityTree is None:
            allLive = self._computeCoverabilityTreeLD()
        
        liveTransitions = []
        deadTransitions = []
        
        if allLive == True:
            for i in range(np.shape(self.Aplus)[1]):
                liveTransitions.append(i)

        else:
            for i in range(np.shape(self.Aplus)[1]):
                if self.isTransitionDead(i+1) == False:
                    liveTransitions.append(i)
                else:
                    deadTransitions.append(i)
        
        return [liveTransitions, deadTransitions]
           
    def printLiveDeadTransitions(self) -> None:
        """Prints out a list of L1-live and a list of dead transitions.
        
        Checks the liveness of each transition in a Petri net and
        prints out a list of live transitions and a list of dead transitions.

        Parameters
        ----------
        None
        
        Returns
        -------
        None
            It automatically prints the lists out.
    
        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created,
        in which transition t1 is L3-live, transition t2 is live
        and transition t3 is dead.
    
        >>> pn.printLiveDeadTransitions()
        L1-live transitions:
        T1 T2
        Dead transitions:
        T3
        """
        
        print("L1-live transitions: ")
        for liveT in self._LiveDeadTransitions()[0]:
            print("T"+str(liveT+1), end = ' ')
        
        print("\n\nDead transitions: ")
        for deadT in self._LiveDeadTransitions()[1]:
            print("T"+str(deadT+1), end = ' ')
        print("\n\n")
    
    def isStateCovered(self, state: np.ndarray) -> bool:
        """Checks the coverability of a state.
        
        Checks if the given state `state` is coverable by the Petri net
        by using its coverability tree. If the coverability tree has not
        been computed yet, it will do so automatically.

        Parameters
        ----------
        state : numpy.ndarray
            A vector which coverability should be checked. Pass it to
            the function as a column vector.
            
        Returns
        -------
        bool
            `True` if the vector is coverable by the Petri net,
            `False` if it is not.
    
        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created 
        and the state [[1], [1], [0], [0]] is coverable by the Petri net `pn`.
        
        >>> state = np.array([[1],
        ...                   [1],
        ...                   [0],
        ...                   [0]])
        >>> print(pn.isStateCovered(state))
        True
        """
       

        # Compute coverability tree if it is not already available
        ct = self._getOrComputeTree()

        # Go through all explored nodes
        for node in ct._explored:
            if _isGreaterEqual(node._state, state):
                return True

        return False

    def isConservative(self, vector: np.ndarray) -> bool:
        """Checks the conservation of a Petri net.
        
        Checks if the Petri net is conservative with respect to the given
        vector by using its coverability tree. If the coverability tree has not
        been computed yet, it will do so automatically.
        
        Parameters
        ----------
        vector : numpy.ndarray
            A vector with respect to which the conservation of
            a Petri net should be checked. Pass it to
            the function as a column vector.
        Returns
        -------
        bool
            `True` if the Petri net is conservative with respect
            to the chosen vector, `False` if it is not.
    
        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created 
        and the Petri net `pn` is not conservative with respect 
        to the vector [[1], [1], [0], [0]].
        
        >>> vector = np.array([[1],
        ...                    [1],
        ...                    [0],
        ...                    [0]])
        >>> print(pn.isConservative(vector))
        False
        """

        # Check if the passed state has only positiv values
        # as the conditions do not hold for negativ values
        for i in range(vector.shape[0]):
            if(vector[i, 0] < 0):
                raise Exception('''Method cannot be used for a vector with negative values''')

        # Compute coverability tree if it is not already available
        ct = self._getOrComputeTree()

        # If the coverability tree is not bounded, check if the passed state
        # has an 0-element where OMEGA occurs
        if not self.isBounded():
            for node in ct._explored:
                for i in range(np.shape(node._state)[0]):
                    if(node._state[i] == OMEGA and vector[i, 0] != 0):
                        return False

        # Set the constant with the initial marking vector
        const = CoverabilityTree._vdot(vector, self.x0)

        # Check if all nodes in coverability tree give the same constant
        for node in ct._explored:
            if CoverabilityTree._vdot(vector, node._state) != const:
                return False
        return True
    
    def drawCoverabilityTree(self, name: str | None = None) -> None:
        """Draws the coverability tree of a Petri net.
        
        Draws the coverability tree of a petri net as a matplotlib type plot
        using the networkx library. If the coverability tree has not 
        been computed yet, it will do so automatically. Depending on the number 
        of nodes the states will either be displayed as single column vectors 
        or in a more compact, multiline vector form. If no parameter ist given, 
        it will only display the coverability tree plot. If a name is given 
        as a parameter, the plot will be saved in a PDF format.

        Parameters
        ----------
        name : str, optional
            Choose a name for the PDF file if you wish to save
            the drawn coverability tree, defaults to None and does not save
            the CT as a PDF if no name is given.
            
        Returns
        -------
        None
            This function only draws the CT and shows the plot,
            if parameter name is given, the resulting plot will 
            be saved as a PDF.
        
        Raises
        ------
    
        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created.
        
        >>> pn.drawCoverabilityTree()
        """

        # Compute coverability tree if it is not already available
        ct = self._getOrComputeTree()

        # Save the id of the first element to use it as the 0th index later
        startIdx = ct._explored[0]._id

        # Create empty lists for edges and transitions
        edges = ()
        transitions = ()

        # Loop through all nodes in the coverability Tree
        for node in ct._explored:
            # Adds edges as tuples of indices
            # of parent and children node pairs to the list
            for j in range(len(node._children)):
                edges = edges + ((node._id - startIdx,
                                  node._children[j][1]._id - startIdx),)
            # Adds transitions' labels as strings to the list of transitions
            if (node._id > startIdx):
                transName = "$t_{" + str(node._trans_par[0]+1) + "}"
                for t in node._trans_par[1:]:
                    transName = transName + ", t_{" + str(t+1) + "}"
                transName = transName + "$"
                transitions = transitions + ((transName),)

        # Create dictionary with edges as keys and transition labels as elements
        edgesDict = dict(zip(edges, transitions))


        # The Depths array will contain the depth of each node
        # in the coverability tree, starting at 0 for the initial marking vector
        Depths = np.array([])

        # Adds the depths of each node to the array
        for node in ct._explored:
            Depths = np.append(Depths, node._depth)
        
        # unique array contains each depth level of the CT once 
        # and basically works as Python's range() with maximum depth as argument
        # counts array contains the numbers of nodes at each depth
        # eg. counts[2] = 4 means there are 4 nodes with depth = 2
        unique, counts = np.unique(Depths, return_counts=True)
        
        # maximum_val the highest number of nodes with the same depth
        maximum_val = max(counts)
        
        # Now the positions of all nodes in the (x,y) form are computed: 
        # x coordinate is always the depth of the node;
        # for each depth the y axis is divided into "x" segments using
        # the formula "x = maximum_val/<number of nodes at that depth + 1>"
        # the borders of these segments are then used as the y coordinates
        
        # pos is a list of positions as tuples
        pos = ((0,maximum_val/(counts[0]+1)),)
        
        # In the for-loop positions of all nodes at one depth will be computed
        # when there are no more nodes at that depth, the loop will go to
        # the next depth, this is checked
        # by comparing the unique and Depth arrays
        j = 1
        m = 0
        for i in range(1, np.shape(Depths)[0]):
            # k is the size of each segment
            k = maximum_val/(counts[j]+1)
            # l and m are being used for moving along the y axis
            l = counts[j]
            pos = pos + ((Depths[i],round(((l-m)*k), 2)), )
            if (i != np.shape(Depths)[0]-1 and Depths[i+1] != unique[j]):
                j += 1
                m = 0
            else:
                m += 1
        # Two nodes are added to the list to set the total size of the graph
        # and will not be seen in the final plot
        # One is at the origin (0,0) and the other at the opposite corner
        # at (<max depth>, maximum_val)
        pos = pos + ((0,0), )
        pos = pos + ((Depths[-1],maximum_val), )
        # Create a range to enumerate all the nodes
        nodes = range(np.shape(Depths)[0]+2)
    
        # Create a dictionary with nodes as keys and tuples
        # of their positions as elements
        posDict = dict(zip(nodes, pos))
        
        maxPlaces = maximum_val * (np.shape(self.x0)[0] + 2.5)

        # Scale the font sizes
        fontSizeNode = _getFontSizeCT(maxPlaces) + 2
        fontSizeEdge = fontSizeNode +0.5
        nodeSize = 2 * fontSizeNode + 4
        #fontSizeNode = 7.5 - 1.75 * np.log(NodeSize)
        edgeWidth = 0.1* fontSizeNode
        
        # Create a list of all node labels using the stateToString method
        nodeLabels = ()
        if maxPlaces <= 250:
            for node in ct._explored:
                nodeLabels = nodeLabels + ((node._stateToString()), )
        else:
            rowLen = math.ceil(math.sqrt(np.shape(self.x0)[0]))
            for node in ct._explored:
                nodeLabels = nodeLabels + ((node._stateToStringSquare(rowLen)), )
        # Create a dictionary with nodes as keys and their labels as elements
        nodeLabelsDict = dict(zip(nodes, nodeLabels))
        
         
        #bBox = dict(boxstyle='round', ec=(1.0, 1.0, 1.0), fc=(1.0, 1.0, 1.0))
        
        # Create the graph using networkx and plot it using matplotlib
        G=nx.DiGraph()
        
        # Add using the keys from the nodes dictionary
        G.add_nodes_from(posDict.keys())
        
        # Add edges using the keys from the edges dictionary
        G.add_edges_from(edgesDict.keys())
        
        # Draw the graph
        nx.draw(G, posDict, labels=nodeLabelsDict,
                font_size= fontSizeNode, node_size = nodeSize, node_color="white",
                with_labels=True, min_source_margin = fontSizeNode -1,
                min_target_margin = fontSizeNode -1, arrowsize = fontSizeNode-2,
                width = edgeWidth)

        # Edge labels settings
        _ = nx.draw_networkx_edge_labels(
            G, posDict,
            edge_labels= edgesDict,
            font_color='black',
            font_size=fontSizeEdge,
            bbox={'facecolor':'white', 'edgecolor':'none', 'pad':1}
        )
        
        # Save the graph as pdf (optional) and display the plot
        if name is not None:
            plt.savefig(name+".pdf")
            
        plt.show()

    def getStateController(self, Gamma : np.ndarray, b : np.ndarray,
                           multipleCtrls: bool = False,
                           trans_ouc: list[int] | None = None,
                           trans_uouc: list[int] | None = None) -> StateController:
        """Computes the state controller of a Petri net.
        
        Computes the state controller of a Petri net according to the given
        conditions and regarding the controllability and observability
        of all transitions. It then saves all its properties as its attributes
        which are reachable by the user through corresponding getter-methods.
        
        Parameters
        ----------
        Gamma : numpy.ndarray
            The Gamma matrix of the inequality defining the conditions
            for which the controller should be computed.
        b : numpy.ndarray
            The b vector of the inequality defining the conditions
            for which the controller should be computed. Pass it to
            the function as a column vector.
        multipleCtrls : bool, default False
            If set to `True`, the function will first
            compute a state controller and create the respective object of
            the StateController class but then print out the state controller
            and continue computing other possible controllers and printing out 
            the new ones found. Maximum of 5 different controllers
            can be computed.
        trans_ouc : list[int], optional
            A list of integers corresponding to all the observable
            but uncontrollable transitions of the Petri net, defaults to None.
        trans_uouc : list[int], optional
            A list of integers corresponding to all the unobservable
            and therefore also uncontrollable transitions of the Petri net,
            defaults to None.
        
        Returns
        -------
        object of :class:`StateController`
            An object of the clas StateController with the properties
            of the controller as the objects attributes.

        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created,
        in which transition t2 is observable but uncontrollabe,
        transitions t1 and t4 are unobservable and therefore uncontrollabe
        and the rest of transitions is observable and controllable.
        
        >>> Gamma = np.array([[5, 2, 0, 0],
        ...                   [0, 0, 0, 1],
        ...                   [-1, 1, 0, 0]])
        >>> b = np.array([[20],
        ...               [1],
        ...               [0]])
        >>> controller = pn.getStateController(Gamma, b, trans_ouc=[2]}, 
        ...                                    trans_uouc=[1, 4])
        """
        return StateController(Gamma, b, self.A, self.x0, 
                               multipleCtrls, trans_ouc, trans_uouc)

    def closedLoop(self, controller: StateController) -> PetriNet:
        """Returns the Petri net representing the closed-loop system.

        Computes the Petri net representing the closed-loop system formed by a 
        PetriNet object, corresponding to the plant, and a StateController
        object, corresponding to the controller.

        Parameters
        ----------
        controller : StateController
            Controller computed using method `getStateController()` of the class
            PetriNet

        Returns
        -------
        object of :class:`PetriNet`
            An object of the class PetriNet corresponding to the closed-loop 
            system

        Examples
        --------
        Assuming an object `pn` of the class PetriNet, and np.arrays Gamma and b
        has already been defined.

        >>> controller = pn.getStateController(Gamma, b)
        ... cl_pn = closedLoop(pn, controller)
        """
        # get matrix Ac and initial marking vector xc0 for the controller places
        Ac = controller.getA_c()
        xc0 = controller.getx_c()

        # construct matrices Ac_plus and Ac_minus, such that
        # Ac = Ac_plus - Ac_minus
        Ac_plus =   np.where(Ac >= 0, Ac, 0)
        Ac_minus =  np.where(Ac <= 0, -Ac, 0)

        # obtain closed-loop Petri net's matrices A+ and A-, and initial state
        Acl_plus =  np.concatenate((self.Aplus,Ac_plus))
        Acl_minus = np.concatenate((self.Aminus,Ac_minus))
        xcl0 =      np.concatenate((self.x0,xc0))

        # define the closed-loop Petri net
        return PetriNet(Acl_plus, Acl_minus, xcl0)

    def fire(self, transition_number: int) -> None:
        """Update the initial state of a Petri net by firing a transition.
        
        Checks if it is possible to fire the given transition. If not, raises 
        an error, otherwise, updates the initial state of the Petri net with the 
        new marking obtained after firing the transition.
        
        Parameters
        ----------
        transition_number : int
            Number of transition to be fired, starting from 0.
        
        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created,
        the following code simulates the firing of the first transition of `pn` 
        and updates the initial state of `pn` accordingly (recall that Python is
        0-based).
        
        >>> pn.fire(0)
        """

        if not _isGreaterEqual(self.x0,
                                    self.Aminus[:, [transition_number]]):
            raise Exception("The transition cannot fire.")
        else:
            # Update the state of the Petri net
            self.setInitialMarking(np.add(self.x0,
                                          self.A[:, [transition_number]]))

def input_unweighted_PN() -> PetriNet:
    """Step-by-step procedure to define an unweighted Petri net

    Returns
    -------
    object of :class:`PetriNet`
        The unweighted Petri net as indicated in the step-by-step procedure
    """

    #function to manualy create the incidence matrices and the initial marking
    NumOfPlaces = int(input("Insert number of places: "))
    NumOfTransitions = int(input("Insert number of transitions: "))
    Amin = np.zeros([NumOfPlaces, NumOfTransitions])
    Aplus = np.zeros([NumOfPlaces, NumOfTransitions])
    x_0 = np.zeros([NumOfPlaces,1])
    i = 0
    while (i < NumOfPlaces):
        error_flag = 1 # to handle errors
        while error_flag == 1:
            try:
                amin = [int(x) for x in input(
                    "Transitions with P" + str(i+1) + " as input place: ").split()]
            except:
                print("Warning: only numbers separated by space are accepted. Retry")
                continue
            j = 0
            try:
                for j in range(np.shape(amin)[0]):
                    Amin[i][amin[j]-1] += 1
            except IndexError:
                print("Warning: transition T" + str(amin[j]) + " does not exist. Retry")
                continue
            error_flag = 0

        error_flag = 1 # to handle errors
        while error_flag == 1:
            try:
                aplus = [int(x) for x in input(
                    "Transitions with P" + str(i+1) + " as output place: ").split()]
            except:
                print("Warning: only numbers separated by space are accepted. Retry")
                continue
            j = 0
            try:
                for j in range(np.shape(aplus)[0]):
                    Aplus[i][aplus[j]-1] += 1
            except IndexError:
                print("Warning: transition T" + str(aplus[j]) + " does not exist. Retry")
                continue
            error_flag = 0
        
        error_flag = 1 # to handle errors
        while error_flag == 1:
            try:
                x_0[i] = [int(x) for x in input(
                    "Initial marking of P" + str(i+1) + ": ")]
            except:
                print("Warning: only numbers are accepted. Retry")
                continue
            error_flag = 0

        i += 1 
    return PetriNet(Aplus.astype(int), Amin.astype(int), x_0)
