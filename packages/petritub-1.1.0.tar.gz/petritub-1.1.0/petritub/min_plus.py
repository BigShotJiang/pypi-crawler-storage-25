# -*- coding: utf-8 -*-
"""
Min Plus Toolbox
"""
from __future__ import annotations

import math
from typing import final

from . import _tropical
from ._tropical import e as e

eps: float = math.inf   # epsilon (bottom element)
top: float = -math.inf  # top element


@final
class Matrix(_tropical.Matrix):
    eps = math.inf
    top = -math.inf
    addition = staticmethod(min)


@final
class PrecedenceGraph(_tropical.PrecedenceGraph):
    matrix_cls = Matrix


Matrix.precedence_graph_cls = PrecedenceGraph

oplus = Matrix.oplus
otimes = Matrix.otimes
