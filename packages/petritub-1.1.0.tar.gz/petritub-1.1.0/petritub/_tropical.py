# -*- coding: utf-8 -*-
"""
Shared base classes for max-plus and min-plus tropical algebras.

The ``Matrix`` and ``PrecedenceGraph`` classes defined here are abstract: each
concrete algebra (max-plus, min-plus) is obtained by subclassing them and
binding the class-level constants ``eps``, ``top``, ``addition`` (and the
matching ``matrix_cls`` / ``precedence_graph_cls`` cross-references). Not
intended for direct use - import from ``max_plus`` or ``min_plus`` instead.
"""
from __future__ import annotations

import copy
import math
from collections import defaultdict
from typing import Any, Callable, ClassVar, cast

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
try:
    from typing import Self, override  # Python 3.12+
except ImportError:
    try:
        from typing_extensions import Self, override
    except ImportError:
        from typing import TypeVar
        Self = TypeVar("Self")  # type: ignore[assignment]
        def override(f):  # type: ignore[misc]
            return f

plt.rcParams['font.family'] = 'DejaVu Sans'

e: int = 0  # neutral element for multiplication (same in both algebras)


class Matrix:
    """Abstract base class for tropical matrices.

    Concrete subclasses (max-plus, min-plus) bind the class-level constants
    ``eps``, ``top``, ``addition`` and ``precedence_graph_cls``.

    Attributes
    ----------
    elements : list
        Two-dimensional list, containing the elements of the Matrix.
    height : int
        Size of the Matrix in the first dimension.
    width : int
        Size of the Matrix in the second dimension.
    """

    eps: ClassVar[float]
    top: ClassVar[float]
    addition: ClassVar[Callable[..., float]]
    precedence_graph_cls: ClassVar[type[PrecedenceGraph]]

    elements: list[list[float]]
    height: int
    width: int
    _eigval: float | None
    _eigvecs: Matrix | None

    def __init__(self, elements: list[list[float]] | float | int):
        """Constructor for a tropical Matrix based on a two-dimensional list.

        Parameters
        ----------
        elements : list or float or int
            Two-dimensional list containing the elements of the Matrix,
            or a scalar (int or float) to create a 1x1 Matrix.
        """
        if isinstance(elements, (int, float)):
            self.elements = [[float(elements)]]
            self.height = 1
            self.width = 1
        else:
            self.elements = elements
            self.height = len(elements)
            self.width = len(elements[0])
        self._eigval = None
        self._eigvecs = None

    # ------------------------------------------------------------------ #
    #  Tropical operations                                               #
    # ------------------------------------------------------------------ #

    @classmethod
    def oplus(cls, a: Matrix | float, b: Matrix | float) -> Matrix | float:
        """Tropical addition of two Matrices or two scalars.

        Tropical addition (i.e., standard (element-wise) maximum or minimum
        operation depending on the algebra) of two Matrices or two scalars.
        Accordingly, the result is a scalar or a Matrix.

        Parameters
        ----------
        a : float or Matrix
            First operand.
        b : float or Matrix
            Second operand.

        Returns
        -------
        float or Matrix
            The result of the tropical addition operation.
        """
        if isinstance(a, Matrix) and isinstance(b, Matrix):
            if a.size() == b.size():
                result = a.copy()
                for i in range(a.height):
                    for j in range(a.width):
                        result[i, j] = cls.addition(a[i, j], b[i, j])
                return result
            else:
                print("Addition of\n", a, "\nand\n", b,
                      "\nnot possible (incompatible sizes)! Zero Matrix of"
                      " size", a.height, "x", a.width, "was returned.")
                return cls.zeros(a.height, a.width)
        if isinstance(a, Matrix):
            result = a.copy()
            for i in range(a.height):
                for j in range(a.width):
                    result[i, j] = cls.addition(a[i, j], b)
            return result
        elif isinstance(b, Matrix):
            result = b.copy()
            for i in range(b.height):
                for j in range(b.width):
                    result[i, j] = cls.addition(a, b[i, j])
            return result
        return cls.addition(a, b)

    @classmethod
    def otimes(cls, a: Matrix | float, b: Matrix | float) -> Matrix | float:
        """Tropical multiplication of two Matrices, two scalars or a Matrix and a scalar.

        Tropical multiplication (i.e., Matrix product containing standard
        addition and the tropical addition operation) of two Matrices, two
        scalars or a Matrix and a scalar. Accordingly, the result is a scalar
        or a Matrix.

        Parameters
        ----------
        a : float or Matrix
            First operand.
        b : float or Matrix
            Second operand.

        Returns
        -------
        float or Matrix
            The result of the tropical multiplication operation.
        """
        result: Matrix | float = 0
        if isinstance(a, Matrix) and isinstance(b, Matrix):
            if a.size() == (1, 1):
                return cls.otimes(a[0, 0], b)
            if b.size() == (1, 1):
                return cls.otimes(b[0, 0], a)
            if a.size()[1] == b.size()[0]:
                result = cls.zeros(a.height, b.width)
                for i in range(a.height):
                    for j in range(b.width):
                        for k in range(a.width):
                            result[i, j] = cls.addition(result[i, j],
                                                        cls.otimes(a[i, k],
                                                                   b[k, j]))
            else:
                print("Multiplication of\n", a, "\nand\n", b,
                      "\nnot possible (incompatible sizes)! Zero Matrix of"
                      " size", a.height, "x", b.width, "was returned.")
                result = cls.zeros(a.size()[0], b.size()[1])
        elif isinstance(a, Matrix):
            result = a.copy()
            for i in range(a.height):
                for j in range(a.width):
                    result[i, j] = cast(float, cls.otimes(result[i, j], b))
        elif isinstance(b, Matrix):
            result = b.copy()
            for i in range(b.height):
                for j in range(b.width):
                    result[i, j] = cast(float, cls.otimes(result[i, j], a))
        else:
            if a == cls.eps or b == cls.eps:
                result = cls.eps
            else:
                result = a + b
        return result

    # ------------------------------------------------------------------ #
    #  Operator overloads                                                #
    # ------------------------------------------------------------------ #

    def __add__(self, x: Matrix | float) -> Self:
        """Adds two Matrix objects in the tropical sense (element-wise).
        The + symbol can be used for this operation.

        Parameters
        ----------
        x : Matrix
            Matrix to add to the Matrix the method was called on.

        Returns
        -------
        Matrix
            Resulting Matrix after carrying out this operation.
        """
        return cast(Self, type(self).oplus(self, x))

    def __radd__(self, x: Matrix | float) -> Self:
        """Adds two Matrix objects in the tropical sense (element-wise).
        The + symbol can be used for this operation.

        Parameters
        ----------
        x : Matrix
            Matrix to add to the Matrix the method was called on.

        Returns
        -------
        Matrix
            Resulting Matrix after carrying out this operation.
        """
        return cast(Self, type(self).oplus(x, self))

    def __mul__(self, x: Matrix | float) -> Self:
        """Tropical (left) multiplication (*).
        The * symbol can be used for this operation.

        Parameters
        ----------
        x : Matrix or float or int
            Element to multiply with the Matrix the method was called on.

        Returns
        -------
        Matrix
            Resulting Matrix after carrying out this operation.
        """
        return cast(Self, type(self).otimes(self, x))

    def __rmul__(self, x: Matrix | float) -> Self:
        """Tropical (right) multiplication (*).
        The * symbol can be used for this operation.

        Parameters
        ----------
        x : Matrix or float or int
            Element to be multiplied with the Matrix the method was called on.

        Returns
        -------
        Matrix
            Resulting Matrix after carrying out this operation.
        """
        return cast(Self, type(self).otimes(x, self))

    def __pow__(self, x: int) -> Self:
        """Tropical exponentiation operation.
        The ** symbol can be used for this operation.

        Parameters
        ----------
        x : int
            Exponent to which to raise the Matrix the method was called on.
        """
        if self.width != self.height:
            raise ValueError(
                'The exponentiation operation accepts only square matrices')
        if type(x) != int:
            raise ValueError('The exponent must be integer')
        if x < 0:
            raise ValueError('The exponent must be non-negative')
        if x == 0:
            return type(self).eye(self.width)
        A_result = self.copy()
        for _ in range(x - 1):
            A_result *= self
        return A_result

    @override
    def __eq__(self, x: object) -> bool:
        """Determine (with ==) if two Matrix objects have the same elements.

        Parameters
        ----------
        x : Matrix
            Matrix to compare the calling object to.

        Returns
        -------
        bool
            True if the two Matrix objects have equal elements.
        """
        if isinstance(x, Matrix):
            if self.height == x.height and self.width == x.width:
                return self.elements == x.elements
            return False
        return False

    def __getitem__(self, key: tuple[int, int]) -> float:
        """Returns the Matrix element at index (key[0], key[1]).
        Use with e.g. A[1, 2]. Indexing is zero-based.

        Parameters
        ----------
        key : Tuple[int,int]
            Zero-based pair of indices for the position of the required element.

        Returns
        -------
        float
            The Matrix element at the requested position.
        """
        return self.elements[key[0]][key[1]]

    def __setitem__(self, key: tuple[int, int], value: float) -> None:
        """Sets the Matrix element at index (key[0], key[1]).
        Use with e.g. A[1, 2] = 5. Indexing is zero-based.

        Parameters
        ----------
        key : Tuple[int,int]
            Zero-based pair of indices for the position of the element to be changed.
        """
        self.elements[key[0]][key[1]] = value

    def __iter__(self):
        """Iterator for a Matrix object.

        Iterates through all Matrix elements (row by row).

        Returns
        -------
        Iterator[float]
            Iterator object.
        """
        for i in range(self.height):
            for j in range(self.width):
                yield self.elements[i][j]

    def __hash__(self) -> int:
        return id(self)

    @override
    def __str__(self) -> str:
        """String method for a Matrix object.

        Returns a string consisting of the elements of the Matrix.
        Used for console output.

        Returns
        -------
        str
            String containing the Matrix elements.
        """
        cls = type(self)
        if self.size() == (1, 1):
            if self == cls.zeros(1):
                return 'ε'
            elif self == cls.ones(1):
                return 'e'
            else:
                return str(self.elements[0][0])
        else:
            def hor_space_fun(x: float) -> int:
                return (1 if x == -np.inf
                        else (1 if x == 0
                              else len(str(x))))
            space = [0] * self.width
            for j in range(self.width):
                for i in range(self.height):
                    space[j] = max(space[j],
                                   hor_space_fun(self.elements[i][j]))
            if max(space) < 4:
                between_space_num = 3
            elif max(space) < 9:
                between_space_num = 8
            else:
                between_space_num = max(space)
            matrix_string = "\n   "
            for i in range(self.height):
                if i != 0:
                    matrix_string += "   "
                for j in range(self.width):
                    if self.elements[i][j] == cls.eps:
                        string_ij = "ε"
                    elif self.elements[i][j] == e:
                        string_ij = "e"
                    else:
                        string_ij = str(self.elements[i][j])
                    matrix_string += (
                        " " * (between_space_num
                               - hor_space_fun(self.elements[i][j]))
                        + string_ij)
                    if j != self.width - 1:
                        matrix_string += "   "
                matrix_string += "\n"
            return matrix_string

    @override
    def __format__(self, spec: str) -> str:
        """Format method for a Matrix object.

        Returns a string representing the Matrix object with different
        formatting options.

        Parameters
        ----------
        spec : str
            Format specification. Supported formats:

            * ``v`` or ``verbose``: print numeric values instead of ``ε`` and ``e``

        Returns
        -------
        str
            String containing the Matrix elements in the desired format.
        """
        cls = type(self)
        if spec.endswith('verbose') or spec.endswith('v'):
            if self.size() == (1, 1):
                if self == cls.zeros(1):
                    return str(cls.eps)
                elif self == cls.ones(1):
                    return '0'
                else:
                    return str(self.elements[0][0])
            else:
                def hor_space_fun(x: float) -> int:
                    return 4 if x == -np.inf else len(str(x))
                space = [0] * self.width
                for j in range(self.width):
                    for i in range(self.height):
                        space[j] = max(
                            space[j],
                            hor_space_fun(self.elements[i][j]))
                if max(space) < 5:
                    between_space_num = 4
                elif max(space) < 9:
                    between_space_num = 8
                else:
                    between_space_num = max(space)
                matrix_string = "\n   "
                for i in range(self.height):
                    if i != 0:
                        matrix_string += "   "
                    for j in range(self.width):
                        if self.elements[i][j] == cls.eps:
                            string_ij = str(cls.eps)
                        elif self.elements[i][j] == e:
                            string_ij = "0"
                        else:
                            string_ij = str(self.elements[i][j])
                        matrix_string += (
                            " " * (between_space_num
                                   - hor_space_fun(self.elements[i][j]))
                            + string_ij)
                        if j != self.width - 1:
                            matrix_string += "   "
                    matrix_string += "\n"
                return matrix_string.__format__(spec[:-6])
        else:
            return str(self).__format__(spec)

    # ------------------------------------------------------------------ #
    #  Plain Matrix utilities                                            #
    # ------------------------------------------------------------------ #

    def copy(self) -> Self:
        """Returns a copy of a Matrix object.

        Returns
        -------
        Matrix
            Copy of the calling Matrix object.
        """
        return copy.deepcopy(self)

    def size(self) -> tuple[int, int]:
        """Returns the dimensions of the Matrix as a tuple: (height, width).

        Returns
        -------
        Tuple[int,int]
            Dimensions of the Matrix as a tuple: (height, width).
        """
        return (self.height, self.width)

    def T(self) -> Self:
        """Transpose of a Matrix.

        Returns a new Matrix object with transposed elements.

        Returns
        -------
        Matrix
            The transposed Matrix.
        """
        m = self.copy()
        m.elements = cast(list[list[float]], np.array(m.elements).T.tolist())
        m.height = self.width
        m.width = self.height
        return m

    def star(self) -> Self:
        """Kleene star operator.

        Applies the Kleene star operator to the Matrix. Uses the
        Floyd-Warshall algorithm.
        See https://en.wikipedia.org/wiki/Floyd%E2%80%93Warshall_algorithm
        and Algorithm 2 in Hardouin et al., 2018.

        Returns
        -------
        Matrix
            Matrix resulting from applying the Kleene star operator.
        """
        cls = type(self)
        if self.size()[0] != self.size()[1]:
            print("Input argument for Kleene star operator is not a"
                  " square Matrix! Zero Matrix was returned.")
            return cls.zeros(self.size()[0])
        n = self.size()[0]
        A_list: list[Matrix] = [self]
        success = True
        for k in range(n):
            A_k = cls.zeros(self.size()[0])
            A_k_1 = A_list[-1]
            for i in range(n):
                for j in range(n):
                    # Star of diagonal element diverges when
                    # addition(A_kk, e) != e
                    # (max-plus: A_kk > 0; min-plus: A_kk < 0)
                    s = cls.top if cls.addition(A_k_1[k, k], e) != e else e
                    if s == cls.top:
                        success = False
                    A_k[i, j] = cast(float, cls.oplus(
                        A_k_1[i, j],
                        cls.otimes(A_k_1[i, k],
                                   cls.otimes(s, A_k_1[k, j]))))
            A_list.append(A_k)
        if not success:
            print("Warning! The star operator of the matrix\n", self,
                  "cannot be computed (there exist circuits with"
                  " positive weight in its precedence graph)!", sep='')
        return cast(Self, cls.oplus(cls.eye(n), A_list[-1]))

    def plus(self) -> Self:
        """Kleene plus operator.

        Applies the Kleene plus operator to the Matrix. Uses the Kleene
        star operator.
        See https://en.wikipedia.org/wiki/Floyd%E2%80%93Warshall_algorithm
        and Algorithm 2 in Hardouin et al., 2018.

        Returns
        -------
        Matrix
            Matrix resulting from applying the Kleene plus operator.
        """
        cls = type(self)
        if self.size()[0] != self.size()[1]:
            print("Input argument for Kleene plus operator is not a"
                  " square matrix!")
            return cls.zeros(self.size()[0])
        return cast(Self, cls.otimes(self, self.star()))

    def minor(self, i: int, j: int) -> Self:
        """Returns a Matrix with the i-th row and j-th column excluded.

        Parameters
        ----------
        i : int
            Row to be excluded.
        j : int
            Column to be excluded.

        Returns
        -------
        Matrix
            Matrix resulting from excluding the specified row and column.
        """
        arr = np.delete(self.elements, i, 0)
        return type(self)(cast(list[list[float]],
                               np.delete(arr, j, 1).tolist()))

    def del_row(self, i: int) -> Self:
        """Returns a Matrix with the i-th row excluded.

        Parameters
        ----------
        i : int
            Row to be excluded.

        Returns
        -------
        Matrix
            Matrix resulting from excluding the specified row.
        """
        return type(self)(cast(list[list[float]],
                               np.delete(self.elements, i, 0).tolist()))

    def del_col(self, i: int) -> Self:
        """Returns a Matrix with the i-th column excluded.

        Parameters
        ----------
        i : int
            Column to be excluded.

        Returns
        -------
        Matrix
            Matrix resulting from excluding the specified column.
        """
        return type(self)(cast(list[list[float]],
                               np.delete(self.elements, i, 1).tolist()))

    def eigenvalue(self) -> float:
        """Largest eigenvalue of the Matrix.

        Returns the largest eigenvalue of the Matrix, computed using the
        trace formula.

        Returns
        -------
        float
            Largest eigenvalue of the Matrix. If the Matrix is not square,
            -1 is returned.
        """
        cls = type(self)
        if self._eigval is None:
            if self.size()[0] == self.size()[1]:
                trace_divided: list[float] = []
                newA: Matrix = self
                for j in range(1, self.size()[0] + 1):
                    trace: float = cls.eps  # neutral element for addition
                    for i in range(newA.size()[0]):
                        trace = cast(float, cls.oplus(newA[i, i], trace))
                    trace_divided.append(trace / j)
                    newA = cast(Matrix, cls.otimes(newA, self))
                self._eigval = cls.addition(trace_divided)
            else:
                print("Function \"eigenvalue()\": Matrix\n", self,
                      "\nis not square! -1 was returned.")
                self._eigval = -1
        return self._eigval

    def eigenvectors(self) -> Matrix:
        """Returns a list of linearly independent eigenvectors of
        the matrix, corresponding to the largest eigenvalue.

        Returns
        -------
        Matrix
            Linearly independent eigenvectors as columns of a Matrix.
        """
        cls = type(self)
        if self._eigvecs is None:
            eig = self.eigenvalue()
            Q = cast(Matrix, cls.otimes(-eig, self))
            Q_plus = Q.plus()
            col_indices: list[int] = []
            for i in range(Q_plus.size()[1]):
                col_i = [row[i] for row in Q_plus.elements]
                if abs(col_i[i]) < 1e-10:
                    col_indices.append(i)
            dependent: list[tuple[int, int]] = []
            to_remove: set[int] = set()
            for i in range(len(col_indices) - 1):
                for j in range(i + 1, len(col_indices)):
                    x1, x2 = col_indices[i], col_indices[j]
                    if abs(cast(float, cls.otimes(Q_plus[x1, x2],
                                  Q_plus[x2, x1]))) < 1e-10:
                        dependent.append((x1, x2))
                        to_remove.add(x1)
            independent = list(set(col_indices) - to_remove)
            self._eigvecs = cls(
                [[row[i] for row in Q_plus.elements]
                 for i in independent]).T()
        return self._eigvecs

    def is_irreducible(self) -> bool:
        """Determine if the Matrix is irreducible.

        Returns
        -------
        bool
            True if the Matrix is irreducible.
        """
        G = type(self).precedence_graph_cls(self)
        for component in list(G.strongly_connected_components()):
            if len(component) == 1:
                return False
        return True

    def is_reducible(self) -> bool:
        """Determine if the Matrix is reducible.

        Returns
        -------
        bool
            True if the Matrix is reducible.
        """
        return not self.is_irreducible()

    def cyclicity(self) -> float:
        """Returns the cyclicity of the matrix (if it is irreducible).

        Returns
        -------
        float
            Cyclicity of Matrix. In case the Matrix is reducible,
            -1 is returned.
        """
        if not self.is_irreducible():
            print("cyclicity: The given matrix\n", self,
                  "\nhas a reducible precedence graph! -1 was returned.")
            return -1
        G = type(self).precedence_graph_cls(self).critical()
        gcd_list: list[int] = []
        lcm_list: list[int] = []
        gcd = 0
        for nodes in G.msc_components():
            gcd_list = []
            subgraph = G.subgraph(nodes)
            cycles = subgraph.cycles()
            for cycle in cycles:
                gcd_list.append(len(cycle))
            if 1 in gcd_list:
                gcd = 1
            else:
                gcd = gcd_list[0]
                if len(gcd_list) > 1:
                    for x in gcd_list:
                        gcd = math.gcd(gcd, x)
            lcm_list.append(gcd)
        lcm = 1
        for x in lcm_list:
            lcm = (x * lcm) // math.gcd(x, lcm)
        return lcm

    def cyc(self) -> float:
        """Same as cyclicity()."""
        return self.cyclicity()

    # ------------------------------------------------------------------ #
    #  Class-level constructors                                          #
    # ------------------------------------------------------------------ #

    @classmethod
    def zeros(cls, m: int, n: int | None = None) -> Self:
        """Zero matrix.

        Returns the m x n zero Matrix, consisting of epsilon-elements.

        Parameters
        ----------
        m : int
            First dimension of the zero Matrix.
        n : Optional[int]
            Second dimension of the zero Matrix. If None, this is set to m.

        Returns
        -------
        Matrix
            m x n zero Matrix. If n = None, m x m zero matrix.
        """
        if n is None:
            return cls([[cls.eps] * m for _ in range(m)])
        return cls([[cls.eps] * n for _ in range(m)])

    @classmethod
    def ones(cls, m: int, n: int | None = None) -> Self:
        """One matrix.

        Returns the m x n unit Matrix, consisting of e-elements.

        Parameters
        ----------
        m : int
            First dimension of the unit Matrix.
        n : Optional[int]
            Second dimension of the unit Matrix. If None, this is set to m.

        Returns
        -------
        Matrix
            m x n unit Matrix. If n = None, m x m one matrix.
        """
        if n is None:
            return cls([[float(e)] * m for _ in range(m)])
        return cls([[float(e)] * n for _ in range(m)])

    @classmethod
    def eye(cls, n: int) -> Self:
        """Identity matrix.

        Returns the n x n identity Matrix, consisting of e-elements on the
        diagonal and epsilon-elements elsewhere.

        Parameters
        ----------
        n : int
            Dimensions of the identity Matrix.

        Returns
        -------
        Matrix
            n x n identity Matrix.
        """
        A = cls.zeros(n)
        for i in range(n):
            A[i, i] = e
        return A

    @classmethod
    def tops(cls, m: int, n: int | None = None) -> Self:
        """Top matrix.

        Returns the m x n top Matrix, consisting of top-elements.

        Parameters
        ----------
        m : int
            First dimension of the top Matrix.
        n : Optional[int]
            Second dimension of the top Matrix. If None, this is set to m.

        Returns
        -------
        Matrix
            m x n top Matrix. If n = None, m x m top matrix.
        """
        if n is None:
            return cls([[cls.top] * m for _ in range(m)])
        return cls([[cls.top] * n for _ in range(m)])


# ---------------------------------------------------------------------- #
#  Graph drawing helpers (independent of the algebra)                    #
# ---------------------------------------------------------------------- #

def _my_draw_networkx_edge_labels(
    G: nx.DiGraph,
    pos: dict[Any, Any],
    edge_labels: dict[Any, Any] | None = None,
    label_pos: float = 0.5,
    font_size: int = 10,
    font_color: str = "green",
    font_family: str = "sans-serif",
    font_weight: str = "normal",
    alpha: float | None = None,
    bbox: dict[str, Any] | None = None,
    horizontalalignment: str = "center",
    verticalalignment: str = "center",
    ax: Any = None,
    rotate: bool = True,
    clip_on: bool = True,
    rad: float = 0,
) -> dict[Any, Any]:
    # From https://stackoverflow.com/questions/22785849/
    _ = label_pos
    if ax is None:
        ax = plt.gca()
    if edge_labels is None:
        labels = {(u, v): d for u, v, d in G.edges(data=True)}
    else:
        labels = edge_labels
    text_items: dict[Any, Any] = {}
    for (n1, n2), label in labels.items():
        (x1, y1) = pos[n1]
        (x2, y2) = pos[n2]
        pos_1 = ax.transData.transform(np.array(pos[n1]))
        pos_2 = ax.transData.transform(np.array(pos[n2]))
        linear_mid = 0.5 * pos_1 + 0.5 * pos_2
        d_pos = pos_2 - pos_1
        rotation_matrix = np.array([(0, 1), (-1, 0)])
        ctrl_1 = linear_mid + rad * rotation_matrix @ d_pos
        ctrl_mid_1 = 0.5 * pos_1 + 0.5 * ctrl_1
        ctrl_mid_2 = 0.5 * pos_2 + 0.5 * ctrl_1
        bezier_mid = 0.5 * ctrl_mid_1 + 0.5 * ctrl_mid_2
        (x, y) = ax.transData.inverted().transform(bezier_mid)
        if rotate:
            angle: float = float(np.arctan2(y2 - y1, x2 - x1)
                                 / (2.0 * np.pi) * 360)
            if angle > 90:
                angle -= 180
            if angle < -90:
                angle += 180
            xy = np.array((x, y))
            trans_angle = ax.transData.transform_angles(
                np.array((angle,)), xy.reshape((1, 2)))[0]
        else:
            trans_angle = 0.0
        if bbox is None:
            bbox = dict(boxstyle="round",
                        ec=(1.0, 1.0, 1.0), fc=(1.0, 1.0, 1.0))
        if not isinstance(label, str):
            label = str(label)
        t = ax.text(
            x, y, label, size=font_size, color=font_color,
            family=font_family, weight=font_weight, alpha=alpha,
            horizontalalignment=horizontalalignment,
            verticalalignment=verticalalignment,
            rotation=trans_angle, transform=ax.transData,
            bbox=bbox, zorder=1, clip_on=clip_on)
        text_items[(n1, n2)] = t
    _ = ax.tick_params(axis="both", which="both", bottom=False, left=False,
                       labelbottom=False, labelleft=False)
    return text_items


def _nudge(pos: dict[Any, Any],
           x_shift: float, y_shift: float) -> dict[Any, tuple[float, float]]:
    return {n: (x + x_shift, y + y_shift) for n, (x, y) in pos.items()}


# ---------------------------------------------------------------------- #
#  PrecedenceGraph class                                                 #
# ---------------------------------------------------------------------- #

class PrecedenceGraph(nx.DiGraph):
    """Abstract base class for the precedence graph of a tropical matrix.

    Concrete subclasses bind the class-level constant ``matrix_cls`` to the
    matching ``Matrix`` subclass.

    Attributes
    ----------
    A : Matrix
        Tropical Matrix the Precedence Graph is based on.
    fig : matplotlib.figure.Figure
        Figure containing the Precedence Graph, with strongly connected
        components indicated.
    fig_crit : matplotlib.figure.Figure
        Figure containing the Precedence Graph, where the critical graph
        is highlighted.
    """

    matrix_cls: ClassVar[type[Matrix]]

    A: Matrix
    _fig: Any
    _fig_crit: Any
    edge_list: list[tuple[int, int, dict[str, str]]]

    def __init__(self, mat: Matrix,
                 incoming_graph_data: Any = None, **attr: Any):
        """Constructor for a Precedence Graph, based on a tropical Matrix.

        Parameters
        ----------
        mat : Matrix
            Tropical Matrix the Precedence Graph is based on.
        """
        nx.DiGraph.__init__(self, incoming_graph_data, **attr)
        self.A = mat  # pyright: ignore[reportConstantRedefinition]
        self._fig = None
        self._fig_crit = None
        self.edge_list = []
        eps = type(self).matrix_cls.eps
        if mat.size()[0] == mat.size()[1]:
            self.add_nodes_from(np.arange(mat.size()[0]) + 1)
            for i in range(mat.size()[0]):
                for j in range(mat.size()[1]):
                    if mat[i, j] != eps:
                        self.edge_list.append(
                            (j + 1, i + 1, {'w': '{}'.format(mat[i, j])}))
                    if mat.size()[0] == 1:
                        self.edge_list.append(
                            (j + 1, i + 1, {'w': '{}'.format(mat[i, j])}))
            self.add_edges_from(self.edge_list)
        else:
            print("PrecedenceGraph: the given matrix is not a"
                  " square matrix!")

    def draw(self, critical: bool = False,
             spread: float = 1.0, seed: int = 1) -> None:
        """Draws the Precedence Graph, where each strongly connected
        component is colored differently.

        Parameters
        ----------
        critical : Optional[bool]
            If True, the Critical Graph is drawn instead.
        spread : Optional[float]
            Scale parameter passed to ``circular_layout``, controlling
            how far apart the nodes are drawn.
        seed : Optional[int]
            Kept for API compatibility (not used with circular layout).
        """
        _ = seed
        eps_str = str(type(self).matrix_cls.eps)
        if self.A.size()[0] != self.A.size()[1]:
            print("PrecedenceGraph: the given matrix is not a"
                  " square matrix!")
            return
        alpha_nodes = ([0.15] if critical else [1]) * len(self.nodes)
        if critical:
            for cycle in self.critical_cycles():
                for i, node in enumerate(cycle):
                    alpha_nodes[node - 1] = 1
        node_colors = ["darkgray"] * len(self.nodes)
        components = self._components()
        for i, comp in enumerate(components):
            for node in comp:
                if alpha_nodes[node - 1] < 1:
                    node_colors[node - 1] = "darkgray"
                else:
                    node_colors[node - 1] = "C" + str(i)
        alpha_nodes[:] = [alpha_nodes[i - 1] for i in self.nodes]
        node_colors_old = node_colors.copy()
        node_colors[:] = [node_colors[i - 1] for i in list(self.nodes)]
        pos = nx.circular_layout(self, scale=spread)
        pos_arcs = _nudge(pos, -0.1, 0.25)
        fig, ax = plt.subplots(figsize=(7, 7))
        _ = nx.draw_networkx_nodes(self, pos, ax=ax,
                                   node_color=node_colors,
                                   alpha=alpha_nodes)
        _ = nx.draw_networkx_labels(self, pos, ax=ax)
        edges_set = set(self.edges)
        curved_edges = [edge for edge in edges_set
                        if (edge[1], edge[0]) in edges_set]
        straight_edges = list(edges_set - set(curved_edges))
        curved_colors: list[str] = []
        straight_colors: list[str] = []
        if critical:
            critical_edges = self.critical_edges()
            for e_ in curved_edges:
                curved_colors.append(
                    node_colors_old[e_[0] - 1]
                    if e_ in critical_edges else "darkgray")
            for e_ in straight_edges:
                straight_colors.append(
                    node_colors_old[e_[0] - 1]
                    if e_ in critical_edges else "darkgray")
        else:
            for e_ in curved_edges:
                curved_colors.append(
                    node_colors_old[e_[0] - 1]
                    if node_colors_old[e_[0] - 1]
                    == node_colors_old[e_[1] - 1] else "k")
            for e_ in straight_edges:
                straight_colors.append(
                    node_colors_old[e_[0] - 1]
                    if node_colors_old[e_[0] - 1]
                    == node_colors_old[e_[1] - 1] else "k")
        arc_rad = 0.2
        _ = nx.draw_networkx_edges(self, pos, ax=ax,
                                   edgelist=straight_edges,
                                   edge_color=straight_colors)
        _ = nx.draw_networkx_edges(self, pos, ax=ax,
                                   edgelist=curved_edges,
                                   connectionstyle=f'arc3, rad = {arc_rad}',
                                   edge_color=curved_colors)
        edge_weights = nx.get_edge_attributes(self, 'w')
        curved_edge_labels = {e_: edge_weights[e_]
                              for e_ in curved_edges}
        straight_edge_labels = {e_: edge_weights[e_]
                                for e_ in straight_edges}
        loop_edge_labels = {e_: edge_weights[e_]
                            for e_ in self.edges if e_[0] == e_[1]}
        edge_labels = {e_: edge_weights[e_] for e_ in self.edges}
        for i in range(self.A.size()[0]):
            for j in range(self.A.size()[1]):
                if j == i:
                    _ = curved_edge_labels.pop((i + 1, j + 1), None)
                    if (edge_labels
                            and next(iter(edge_labels.items()))[1]
                            == eps_str):
                        _ = loop_edge_labels.pop((i + 1, j + 1), None)
                else:
                    _ = loop_edge_labels.pop((i + 1, j + 1), None)
        _ = _my_draw_networkx_edge_labels(
            self, pos=pos_arcs, ax=ax,
            edge_labels=loop_edge_labels, rotate=False,
            rad=arc_rad, font_color="k")
        _ = _my_draw_networkx_edge_labels(
            self, pos, ax=ax, edge_labels=curved_edge_labels,
            rotate=False, rad=arc_rad, font_color="k")
        _ = nx.draw_networkx_edge_labels(
            self, pos, ax=ax,
            edge_labels=straight_edge_labels,
            rotate=False, font_color="k")
        _ = ax.set_xlim(-1.5, 1.5)
        _ = ax.set_ylim(-1.5, 1.5)
        if critical:
            self._fig_crit = fig
        else:
            self._fig = fig

    def savefig(self, name: str, crit: bool = False) -> None:
        """Saves the Precedence Graph figure as a pdf.

        Parameters
        ----------
        name : str
            Name of the pdf file (without ``.pdf`` extension).
        crit : Optional[bool]
            If True, saves the critical graph figure instead.
        """
        if crit:
            if self._fig_crit is None:
                self.draw_critical()
            self.savefig_critical(name)
        else:
            if self._fig is None:
                self.draw()
            assert self._fig is not None
            self._fig.savefig(name + ".pdf", bbox_inches="tight")
        print("Saved precedence graph as pdf:", name)

    def savefig_critical(self, name: str) -> None:
        """Saves the Critical Graph figure as a pdf.

        Parameters
        ----------
        name : str
            Name of the pdf file (without ``.pdf`` extension).
        """
        if self._fig_crit is None:
            self.draw_critical()
        assert self._fig_crit is not None
        self._fig_crit.savefig(name + ".pdf", bbox_inches="tight")
        print("Saved precedence graph as pdf:", name)

    def draw_critical(self, spread: float = 1.0, seed: int = 1) -> None:
        """Draws the Critical Graph, highlighting the critical cycles.

        Parameters
        ----------
        spread : Optional[float]
            Scale parameter passed to ``circular_layout``.
        seed : Optional[int]
            Kept for API compatibility (not used with circular layout).
        """
        self.draw(True, spread, seed)

    def strongly_connected_components(self):
        """Returns the strongly connected components of the graph.

        Returns
        -------
        generator
            Generator of sets of nodes, one per strongly connected
            component.
        """
        return nx.strongly_connected_components(self)

    def transpose(self) -> PrecedenceGraph:
        """Returns the transpose of the Precedence Graph.

        Returns
        -------
        PrecedenceGraph
            Precedence Graph of the transposed Matrix.
        """
        return type(self)(self.A.T())

    def cycles(self) -> list[list[int]]:
        """Returns all simple cycles of the graph.

        Returns
        -------
        list
            List of cycles, each cycle being a list of node indices.
        """
        return list(nx.simple_cycles(nx.DiGraph(self.edges)))

    def circuits(self) -> list[list[int]]:
        """Same as cycles()."""
        return self.cycles()

    @override
    def subgraph(self, nodes: Any) -> PrecedenceGraph:
        """Returns the subgraph induced by the given nodes.

        Parameters
        ----------
        nodes : list
            List of node indices to keep.

        Returns
        -------
        PrecedenceGraph
            Precedence Graph induced by ``nodes``.
        """
        s_mat = self.A.copy()
        to_delete = list(set(self.nodes) - set(cast(list[int], nodes)))
        for i, node in enumerate(to_delete):
            s_mat = s_mat.minor(node - i - 1, node - i - 1)
        return type(self)(s_mat)

    def _components(self) -> list[list[int]]:
        """Returns maximal strongly connected components as lists of
        nodes; isolated nodes without self-loops appear as singletons."""
        cls = type(self).matrix_cls
        eig = self.A.eigenvalue()
        Q = cast(Matrix, cls.otimes(-eig, self.A))
        Q_plus = Q.plus()
        component_number = list(range(1, self.A.size()[0] + 1))
        for i in range(self.A.size()[0]):
            if Q_plus[i, i] == cls.eps:
                component_number[i] = 0
                continue
            for j in range(i + 1, self.A.size()[0]):
                if abs(cast(float, cls.otimes(Q_plus[i, j],
                              Q_plus[j, i]))) < 1e-10:
                    component_number[j] = component_number[i]
        groups: dict[int, list[int]] = defaultdict(list)
        for i, value in enumerate(component_number):
            if value != 0:
                groups[value].append(i + 1)
        return list(groups.values())

    def msc_components(self) -> list[list[int]]:
        """Returns the maximal strongly connected components that
        contain at least one critical cycle.

        Returns
        -------
        list
            List of components (each a list of node indices).
        """
        msc: list[list[int]] = []
        for comp in self._components():
            if len(comp) > 1:
                msc.append(comp)
            elif abs(self.A[comp[0] - 1, comp[0] - 1]
                     - self.A.eigenvalue()) < 1e-8:
                msc.append(comp)
        return msc

    def critical_cycles(self) -> list[list[int]]:
        """Returns the critical cycles of the Precedence Graph.

        Returns
        -------
        list
            List of critical cycles, each cycle being a list of node
            indices.
        """
        crit: list[list[int]] = []
        eig = self.A.eigenvalue()
        for comp in self._components():
            G = self.subgraph(list(comp))
            node_transform = [i + 1 - node
                              for i, node in enumerate(comp)]
            node_transform[:] = [node_transform[i - 1]
                                 for i in G.nodes]
            for cycle in G.cycles():
                weight = 0.0
                for i in range(len(cycle) - 1):
                    weight += float(
                        G.get_edge_data(cycle[i], cycle[i + 1])["w"])
                weight += float(
                    G.get_edge_data(cycle[-1], cycle[0])["w"])
                mean_weight = weight / len(cycle)
                if abs(mean_weight - eig) < 1e-8:
                    nodes_list = list(G.nodes)
                    crit.append([
                        node - node_transform[
                            nodes_list.index(node)]
                        for node in cycle])
        return crit

    def critical_circuits(self) -> list[list[int]]:
        """Same as critical_cycles()."""
        return self.critical_cycles()

    def critical_edges(self) -> list[tuple[int, int]]:
        """Returns the edges belonging to critical cycles.

        Returns
        -------
        list
            List of tuples ``(u, v)`` representing critical edges.
        """
        crit: list[tuple[int, int]] = []
        crit_cycles = [[*c, c[0]] for c in self.critical_cycles()]
        for cycle in crit_cycles:
            for i in range(len(cycle) - 1):
                crit.append((cycle[i], cycle[i + 1]))
        return crit

    def is_strongly_connected(self) -> bool:
        """Returns True if the graph is strongly connected.

        Returns
        -------
        bool
            True if the underlying Matrix is irreducible.
        """
        return self.A.is_irreducible()

    def critical(self) -> PrecedenceGraph:
        """Returns the Critical Graph as a PrecedenceGraph.

        Returns
        -------
        PrecedenceGraph
            Precedence Graph containing only the critical edges.
        """
        cls = type(self).matrix_cls
        A = self.A
        critical_edges = self.critical_edges()
        A_critical = cls.zeros(A.size()[0])
        for i in critical_edges:
            A_critical[i[1] - 1, i[0] - 1] = A[i[1] - 1, i[0] - 1]
        return type(self)(A_critical)
