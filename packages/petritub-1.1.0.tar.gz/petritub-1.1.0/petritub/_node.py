from __future__ import annotations
from typing import final
import itertools
import numpy as np

OMEGA = float('inf')
OMEGAstr = r"$\omega$"

@final
class Node():
    """
        PRIVATE: Represents a node in a coverability tree. An instance has
        a state vector and additional information that is needed for
        coverability tree computation.

        Attributes
        ----------
        _id : int
            Unique instance id.
        _state : np.ndarray
            Numpy vector that represents marking.
        _depth : int
            Depth of the node in the coverability tree, starting with 0 from
            the initial vector.
        _duplicate : bool
            Tells if there exists a duplicate in the coverability tree.
        _deadlock : bool
            Tells if the node is a deadlock.
        _parent : Node | None
            Reference to the parent node. Set to "None" for the initial node.
        _children : list[tuple[int, Node]]
            List of children nodes. Every child is tuple with following
            structure: (transition number to the child, child reference). If
            there are no children than the attribute is an empty list.
        _trans_par : list[int]
            List of all parent transitions. A tree has only one parent per
            definition but identical children be created after firing
            different transitions. In this case, only one node will be created
            and multiple transitions will be stored. The list is empty for the
            initial node.
        """

    # Create an intertools counter that will create a unique id for each
    # instance of the class Node
    _id_inter: itertools.count[int] = itertools.count()

    def __init__(self, state: np.ndarray, depth: int) -> None:
        self._id = next(Node._id_inter)
        self._state = state
        self._depth = depth
        self._duplicate = False
        self._deadlock = False
        self._parent: Node | None = None
        self._children: list[tuple[int, Node]] = []
        self._trans_par: list[int] = []

    def _stateToString(self) -> str:
        """
        Creates a string that represents the state of node in the drawn
        coverability tree.
        """

        stateStr = ""

        # Go though the state and add either OMEGA in LATEX-form or
        # the number of tokens in the place
        for i in range(self._state.shape[0]):
            # First element without line break
            if i == 0:
                if(self._state[i, 0] == np.inf):
                    stateStr = stateStr + OMEGAstr
                else:
                    stateStr = stateStr + str(int(self._state[i, 0]))
            # Other elements with line break
            else:
                if(self._state[i, 0] == np.inf):
                    stateStr = stateStr + "\n" + OMEGAstr
                else:
                    stateStr = stateStr + "\n" + str(int(self._state[i, 0]))
        return stateStr

    def _stateToStringSquare(self, rowLen: int) -> str:
        """
        Creates a compact string that represents the state of node in the drawn
        coverability tree.
        """
        OMEGAstrSq = "w"
        
        stateStr = "["
        
        # Go though the state and add either OMEGA or
        # the number of tokens in the place
        for i in range(self._state.shape[0]):
            # First element without line break
            if (i>0 and (i+1)%rowLen == 0):
                if(self._state[i, 0] == np.inf):
                    stateStr = stateStr + OMEGAstrSq + ",\n"
                else:
                    stateStr = stateStr + str(int(self._state[i, 0])) + ",\n"
            # Other elements with line break
            elif (i != (self._state.shape[0]-1)):
                if(self._state[i, 0] == np.inf):
                    stateStr = stateStr + OMEGAstrSq + ","
                else:
                    stateStr = stateStr + str(int(self._state[i, 0])) + ","
            else:
                if(self._state[i, 0] == np.inf):
                    stateStr = stateStr + OMEGAstrSq + "]"
                else:
                    stateStr = stateStr + str(int(self._state[i, 0])) + "]"
        return stateStr
