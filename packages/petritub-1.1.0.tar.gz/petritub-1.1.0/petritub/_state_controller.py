from __future__ import annotations
from typing import final
import math
import numpy as np

def _oppSgn(x: float, y: float) -> bool:
    return x*y < 0

def _lcm(a: int, b: int) -> int:
    gcd = math.gcd(a, b)
    if gcd == 0:
        return 0
    else:
        return abs((a * b) // gcd)

@final
class StateController():
    """
        PRIVATE: Used to compute the StateController for a Petri Net.

        Attributes
        ----------
        _Gamma : numpy.ndarray
            The Gamma matrix of the inequality defining the conditions
            for which the controller should be computed.
        _b : numpy.ndarray
            The b vector of the inequality defining the conditions
            for which the controller should be computed. Pass it to
            the function as a column vector.
        _A : np.ndarray
            Incidence matrix of a Petri Net.
        _x0 : np.ndarray
            Initial marking vector of a Petri Net.
        _trans_ouc: list[int] | None
            List of observable but uncontrollable transitions.
        _trans_uouc: list[int] | None
            List of unobservable and uncontrollable transitions.
    """

    def __init__(self, Gamma : np.ndarray, b : np.ndarray, A : np.ndarray,
                 x0 : np.ndarray, multipleCtrls: bool, 
                 trans_ouc: list[int] | None = None,
                 trans_uouc: list[int] | None = None) -> None:  
        
        # Initialize attributes
        self._cptMore = multipleCtrls
        self._Gamma = Gamma.astype(int)
        self._b = b.astype(int)
        self._A = A.astype(int)
        self._x0 = x0.astype(int)
        self._A_ouc: np.ndarray = np.empty(0)
        self._A_uouc: np.ndarray = np.empty(0)
        self._identity: np.ndarray = np.empty(0)
        
        # Observable but uncontrollable transitions
        if trans_ouc is not None:
            trans_ouc = list(set(trans_ouc))
            self._trans_ouc = [t_uc - 1 for t_uc in trans_ouc]
        else:
            self._trans_ouc = None

        # Unobservable and uncontrollable transitions
        if trans_uouc is not None:
            trans_uouc = list(set(trans_uouc))
            self._trans_uouc = [t_uouc - 1 for t_uouc in trans_uouc]
        else:
            self._trans_uouc = None

        # Check for wrong input from user
        if trans_ouc is not None and trans_uouc is not None:
            if bool(set(trans_ouc).intersection(trans_uouc)):
                raise Exception("""The parameters \"trans_ouc\" and
                                \"trans_uouc\" cannot include the same
                                transition.""")

        # Compute the ideal state controller
        self._computeIdealSC()

        # Check if the ideal case is ideally enforceable and if not,
        # compute the non-ideal case
        if not self._isIdeallyEnforceable():
            self._hasSolution = True
            self._ideal_case = False
            self._computeNonIdealSC()
            
        else:
            self._ideal_case = True
    
    @staticmethod
    def _getColumns(Mtrx: np.ndarray, transitions: list[int] | None) -> np.ndarray:
        if transitions is None:
            return np.zeros((Mtrx.shape[0], 0))
        if Mtrx.ndim == 1:
            return Mtrx[transitions]
        else:
            return Mtrx[:, transitions]
    
    def _isIdeallyEnforceable(self) -> bool:

        # If all transitions are controllable and observable the ideal case
        # is ideally enforceable
        if(self._trans_ouc is None and self._trans_uouc is None):
            return True
        
        # If not, check both conditions from the DES lecture
        else:
            
            # Condition (2.23): -Gamma*A_ouc >= 0
            mGammaA_ouc = StateController._getColumns(self.A_c, self._trans_ouc)
            if(not np.greater_equal(mGammaA_ouc, np.zeros(mGammaA_ouc.shape)).all()):
                return False
            
            # Condition (2.24): -Gamma*A_uouc = 0
            mGammaA_uouc = StateController._getColumns(self.A_c, self._trans_uouc)
            if(not np.equal(mGammaA_uouc, np.zeros(mGammaA_uouc.shape)).all()):
                return False
            return True

    def _computeIdealSC(self) -> None:

        # Check the "Gamma*x_0 <= b" specification
        if(not all(np.less_equal(np.matmul(self._Gamma, self._x0), self._b))):
            raise Exception("""The ideal case could not be computed because
                               the condition \"Gamma*x_0 <= b\" was
                               violated.""")
        
        # Compute the controller's state vector
        self.x_c = np.subtract(self._b, np.matmul(self._Gamma, self._x0))
        # Compute the controller matrix
        self.A_c = -np.matmul(self._Gamma, self._A)

    def _computeNonIdealSC(self) -> None:
        if self._trans_ouc is None:
            self._trans_ouc = []
        self._A_ouc = StateController._getColumns(self._A, self._trans_ouc)
        self._A_uouc = (StateController._getColumns(self._A, self._trans_uouc)
                        if self._trans_uouc is not None
                        else np.zeros((self._A.shape[0], 0), dtype=int))
        self._run_algorithm()
        
    # ------------------------------------------------------------------
    # Non-ideal synthesis helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _make_J(vec: list[int]) -> np.ndarray:
        """Indices of positive entries in vec (set J in the algorithm)."""
        return np.array([t for t, v in enumerate(vec) if v > 0], dtype=int)

    @staticmethod
    def _make_L(uec: list[int]) -> np.ndarray:
        """Indices of non-zero entries in uec (set L in the algorithm)."""
        return np.array([t for t, u in enumerate(uec) if u != 0], dtype=int)

    def _elim_ouc(self, vec: list[int], uec: list[int],
                  r1: np.ndarray, r2: np.ndarray,
                  j: int, randomize: bool) -> tuple | None:
        """Step 3 row operation: eliminate v[j] > 0. Returns (vec,uec,r1,r2) or None."""
        Ineg = np.array([i for i in range(self._A_ouc.shape[0])
                         if self._A_ouc[i, j] < 0], dtype=int)
        if Ineg.size == 0:
            print("Computation of the state controller is not possible.\n"
                  "Algorithm terminated at step 5.\n")
            return None
        if randomize:
            lcmIdx = Ineg[np.random.randint(len(Ineg))]
        else:
            lcmIdx, best = Ineg[0], _lcm(int(self._A_ouc[Ineg[0], j]), vec[j])
            for k, i in enumerate(Ineg[1:]):
                c = _lcm(int(self._A_ouc[i, j]), vec[j])
                if c < best:
                    best, lcmIdx = c, Ineg[k + 1]
        lcm   = _lcm(int(self._A_ouc[lcmIdx, j]), vec[j])
        d_Auc = int(lcm / abs(self._A_ouc[lcmIdx, j]))
        d_v   = int(lcm / abs(vec[j]))
        ouc_row = d_Auc * self._A_ouc[lcmIdx]
        vec = [int(a + b) for a, b in zip(ouc_row, [x * d_v for x in vec])]
        if self._A_uouc.shape[1] > 0:
            uouc_row = d_Auc * self._A_uouc[lcmIdx]
            uec = [int(a + b) for a, b in zip(uouc_row, [x * d_v for x in uec])]
        r1 = (d_Auc * self._identity[lcmIdx] + d_v * r1).astype(int)
        r2 = (r2 * d_v).astype(int)
        return vec, uec, r1, r2

    def _elim_uouc(self, vec: list[int], uec: list[int],
                   r1: np.ndarray, r2: np.ndarray,
                   l: int, randomize: bool) -> tuple | None:
        """Step 4 row operation: eliminate u[l] != 0. Returns (vec,uec,r1,r2) or None."""
        Zopp = np.array([z for z in range(self._A_uouc.shape[0])
                         if _oppSgn(self._A_uouc[z, l], uec[l])], dtype=int)
        if Zopp.size == 0:
            print("Computation of the state controller is not possible.\n"
                  "Algorithm terminated at step 6.\n")
            return None
        if randomize:
            lcmIdx = Zopp[np.random.randint(len(Zopp))]
        else:
            lcmIdx, best = Zopp[0], _lcm(int(self._A_uouc[Zopp[0], l]), uec[l])
            for k, z in enumerate(Zopp[1:]):
                c = _lcm(int(self._A_uouc[z, l]), uec[l])
                if c < best:
                    best, lcmIdx = c, Zopp[k + 1]
        lcm     = _lcm(int(self._A_uouc[lcmIdx, l]), uec[l])
        d_Auouc = int(lcm / abs(self._A_uouc[lcmIdx, l]))
        d_u     = int(lcm / abs(uec[l]))
        ouc_row  = d_Auouc * self._A_ouc[lcmIdx]
        uouc_row = d_Auouc * self._A_uouc[lcmIdx]
        vec = [int(a + b) for a, b in zip(ouc_row,  [x * d_u for x in vec])]
        uec = [int(a + b) for a, b in zip(uouc_row, [x * d_u for x in uec])]
        r1 = (d_Auouc * self._identity[lcmIdx] + d_u * r1).astype(int)
        r2 = (r2 * d_u).astype(int)
        return vec, uec, r1, r2

    def _run_row(self, vec: list[int], uec: list[int],
                 randomize: bool) -> tuple | None:
        """Runs the full algorithm for one constraint row. Returns (r1,r2) or None."""
        n = self._identity.shape[0]
        r1 = np.zeros(n, dtype=int)
        r2 = np.ones(1, dtype=int)
        Jay  = StateController._make_J(vec)
        Elle = StateController._make_L(uec)
        for _ in range(1000):
            for __ in range(1000):     #–––step 2: eliminate all v > 0–––
                if Jay.size == 0:
                    break
                j = Jay[np.random.randint(len(Jay))] if randomize else Jay[0]
                res = self._elim_ouc(vec, uec, r1, r2, j, randomize)
                if res is None:
                    return None
                vec, uec, r1, r2 = res
                Jay = StateController._make_J(vec)
            Elle = StateController._make_L(uec)
            if Elle.size != 0:         #–––step 4: eliminate one u entry–––
                l = Elle[np.random.randint(len(Elle))] if randomize else Elle[0]
                res = self._elim_uouc(vec, uec, r1, r2, l, randomize)
                if res is None:
                    return None
                vec, uec, r1, r2 = res
                Elle = StateController._make_L(uec)
            Jay = StateController._make_J(vec)  #–––step 5: go to step 2–––
            if Jay.size == 0 and Elle.size == 0:
                return r1, r2
        print("Computation of the state controller is not possible.\nTimeout.")
        return None

    def _update_gamma_b_row(self, idx: int, r1: np.ndarray, r2: np.ndarray,
                            newGamma: np.ndarray, newB: np.ndarray,
                            b_ref: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Update the idx-th row of newGamma and newB after the algorithm."""
        if self._Gamma.ndim == 1:
            return (r1 + r2 * self._Gamma.astype(int)), (r2 * (b_ref + 1) - 1)
        newGamma[idx] = r1 + r2 * self._Gamma[idx].astype(int)
        newB[idx] = r2 * (b_ref[idx, 0] + 1) - 1
        return newGamma, newB

    def _run_algorithm(self) -> None:
        """Deterministic synthesis pass; optionally searches for more controllers."""
        self._identity = np.eye(self._A.shape[0])
        newGamma = self._Gamma.astype(int)
        newB = self._b.astype(int)
        v_vectors = np.atleast_2d(
            -StateController._getColumns(self.A_c, self._trans_ouc)).astype(int)
        u_vectors = np.atleast_2d(
            -StateController._getColumns(self.A_c, self._trans_uouc)).astype(int)
        for idx in range(v_vectors.shape[0]):
            vec = [int(v) for v in v_vectors[idx].tolist()]
            uec = [int(u) for u in u_vectors[idx].tolist()]
            res = self._run_row(vec, uec, randomize=False)
            if res is None:
                self._hasSolution = False
                return
            r1, r2 = res
            newGamma, newB = self._update_gamma_b_row(idx, r1, r2, newGamma, newB, self._b)
        self.A_c = -np.matmul(newGamma, self._A)
        self._b = newB
        self.x_c = self._b - np.matmul(newGamma, self._x0)
        if self._cptMore:
            self._run_cptMore(v_vectors, u_vectors, newGamma)

    def _run_cptMore(self, v_vectors: np.ndarray, u_vectors: np.ndarray,
                     newGamma_first: np.ndarray) -> None:
        """Randomised search for additional (distinct) controllers."""
        startB = self._b
        print("Option 1: \n", self.toString(), "\n")
        prevCtrls = np.array([newGamma_first])
        oldA_c, old_b, oldx_c = self.A_c, self._b, self.x_c
        loop = newCtrl = 0
        while loop < 1000 and newCtrl < 5:
            newGamma = self._Gamma.astype(int)
            newB1 = self._b.astype(int)
            for idx in range(v_vectors.shape[0]):
                vec = [int(v) for v in v_vectors[idx].tolist()]
                uec = [int(u) for u in u_vectors[idx].tolist()]
                res = self._run_row(vec, uec, randomize=True)
                if res is None:
                    self._hasSolution = False
                    return
                r1, r2 = res
                newGamma, newB1 = self._update_gamma_b_row(
                    idx, r1, r2, newGamma, newB1, startB)
            if not any(np.equal(newGamma, p).all() for p in prevCtrls):
                newCtrl += 1
                prevCtrls = np.append(prevCtrls, [newGamma], axis=0)
                self.A_c = -np.matmul(newGamma, self._A)
                self._b = newB1
                self.x_c = self._b - np.matmul(newGamma, self._x0)
                print(f"Option {newCtrl + 1}:\n", self.toString(), "\n")
            loop += 1
        self.A_c = oldA_c
        self._b = old_b
        self.x_c = oldx_c

    def toString(self) -> str:
        """Returns the computed state controller in a string format.
        
        If a state controller has already been computed using
        the .getStateController() function, this function will return the result
        in a string format as matrix. Furthermore, the string will also
        tell the user whether the state controller was ideally enforceable.
        In case the state controlled could not have been obtained, it will
        return a message saying the controller has no solution.

        Parameters
        ----------
        None
        
        Returns
        -------
        str
            A state controller as a matrix in a string format and information
            about the ideal enforceability or a message saying the state 
            controller has no solution.

        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created
        and its state controller has been computed and saved as `controller`.
        
        >>> print(controller.toString())
        State Controller (non-ideal case):
        - Initial marking of the controller places:
        [[3]
         [3]
         [2]]
        - Controller matrix:
        [[ 0 -1  0  1  0  0  0  0  0]
         [ 0  0  0  0 -1  0  0  0  1]
         [ 0  0  0  0 -1  0  0  0  1]]
    
        """

        result = ""
        # Check if it is ideal case or not
        if(self._ideal_case):
            result = result + "State Controller (ideal case):\n"
            result = result + "- Initial marking of the controller places:\n"
            result = result + np.array2string(self.x_c) + "\n"
            result = result + "- Controller matrix:\n"
            result = result + np.array2string(self.A_c)
            return result
        else:
            if self._hasSolution == True:
                result = result + "State Controller (non-ideal case):\n"
                result = result + "- Initial marking of the controller places:\n"
                result = result + np.array2string(self.x_c) + "\n"
                result = result + "- Controller matrix:\n"
                result = result + np.array2string(self.A_c)
            else:
                result = "State controller has no solution."
            return result

    def getA_c(self) -> np.ndarray:
        """Returns the computed matrix A_c.

        If a state controller has already been computed using
        the .getStateController() function, this function will return matrix
        A_c in the form of a numpy ndarray. In case the state controlled could
        not have been obtained, it will throw an error.

        Parameters
        ----------
        None
        
        Returns
        -------
        numpy.array
            The incidence matrix relative to the controller places.

        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created
        and its state controller has been computed and saved as `controller`.
        
        >>> print(controller.getA_c())
        [[ 0 -1  0  1  0  0  0  0  0]
         [ 0  0  0  0 -1  0  0  0  1]
         [ 0  0  0  0 -1  0  0  0  1]]
    
        """
        if self._ideal_case == True:
            return self.A_c
        elif self._hasSolution == False:
            raise Exception('''State controller has no solution.''')
        else:
            return self.A_c

    def getx_c(self) -> np.ndarray:
        """Returns the computed initial marking of the controller places.

        If a state controller has already been computed using
        the .getStateController() function, this function will return vector
        x_c in the form of a numpy ndarray. This vector represent the initial
        marking of the controller places. In case the state controlled could
        not have been obtained, it will throw an error.

        Parameters
        ----------
        None
        
        Returns
        -------
        numpy.array
            The initial marking of the controller places.

        Examples
        --------
        Assuming an object `pn` of the class PetriNet has already been created
        and its state controller has been computed and saved as `controller`.
        
        >>> print(controller.getxc())
        [[3]
         [3]
         [2]]
    
        """
        if self._ideal_case == True:
            return self.x_c
        elif self._hasSolution == False:
            raise Exception('''State controller has no solution.''')
        else:
            return self.x_c
