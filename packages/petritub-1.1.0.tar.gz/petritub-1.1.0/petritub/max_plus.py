# -*- coding: utf-8 -*-
"""
Max Plus Toolbox
"""
from __future__ import annotations

import math
from collections.abc import Sequence
from typing import final

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import colors as mcolors
from matplotlib.figure import Figure

from . import _tropical
from ._tropical import e as e

eps: float = -math.inf  # epsilon (bottom element)
top: float = math.inf   # top element


@final
class Matrix(_tropical.Matrix):
    eps = -math.inf
    top = math.inf
    addition = staticmethod(max)


@final
class PrecedenceGraph(_tropical.PrecedenceGraph):
    matrix_cls = Matrix


Matrix.precedence_graph_cls = PrecedenceGraph

oplus = Matrix.oplus
otimes = Matrix.otimes


def mp(elements: list[list[float]]) -> Matrix:
    """Constructor for a Matrix object based on a two-dimensional list.

    Parameters
    ----------
    elements : list
        Two-dimensional list containing the elements of the Matrix object.
    """
    return Matrix(elements)


def concatenate(matrices: Sequence[Matrix],
                axis: int = 0) -> Matrix:
    """Concatenate Matrix objects.

    Parameters
    ----------
    matrices : tuple
        The tuple of Matrix objects to be concatenated.
    axis : Optional[int]
        The axis along which the matrices are concatenated. Default is 0.
    """
    return mp(np.concatenate(
        [np.array(matrices[i].elements) for i in range(len(matrices))],
        axis).tolist())


def zeros(m: int, n: int | None = None) -> Matrix:
    """Matrix filled with max-plus zeros (epsilon elements).

    Parameters
    ----------
    m : int
        First dimension of the zero matrix.
    n : Optional[int]
        Second dimension. If None, returns an m x m matrix.

    Returns
    -------
    Matrix
        m x n zero Matrix.
    """
    return Matrix.zeros(m, n)


def ones(m: int, n: int | None = None) -> Matrix:
    """Matrix filled with max-plus e elements.

    Parameters
    ----------
    m : int
        First dimension.
    n : Optional[int]
        Second dimension. If None, returns an m x m matrix.

    Returns
    -------
    Matrix
        m x n ones Matrix.
    """
    return Matrix.ones(m, n)


def eye(n: int) -> Matrix:
    """Identity matrix in max-plus algebra.

    Parameters
    ----------
    n : int
        Dimension of the identity Matrix.

    Returns
    -------
    Matrix
        n x n identity Matrix.
    """
    return Matrix.eye(n)


def tops(m: int, n: int | None = None) -> Matrix:
    """Matrix filled with max-plus top elements.

    Parameters
    ----------
    m : int
        First dimension.
    n : Optional[int]
        Second dimension. If None, returns an m x m matrix.

    Returns
    -------
    Matrix
        m x n top Matrix.
    """
    return Matrix.tops(m, n)


@final
class Gantt:
    """Class for representing a Gantt Chart object, showing the resource
    occupancy of places in a max-plus model of a Timed Event Graph as a
    function of time.

    Attributes
    ----------
    matrix : list
        Two-dimensional list where each row is the firing-time sequence
        of a transition.  Each column of the original max-plus state Matrix
        represents the state vector x(k) for a given integer k.
    pairs : List[Tuple[int,int]]
        List of pairs of integers representing pairs of transitions.
        For each pair a row in the chart is drawn, showing the resource
        occupancy of the place between the two transitions.
    """

    matrix: list[list[float]]
    pairs: list[tuple[int, int]]
    _fig: Figure | None

    def __init__(self,
                 matrix: list[list[float]] | Matrix,
                 pairs: list[tuple[int, int]]):
        """Constructor for a Gantt chart object.

        Parameters
        ----------
        matrix : List[List[float]] or Matrix
            Max-plus Matrix the Gantt chart is based on, with each column
            representing the state vector x(k) for a given integer k.
        pairs : List[Tuple[int,int]]
            List of pairs of integers representing pairs of transitions.
        """
        if isinstance(matrix, Matrix):
            m = matrix
            while Matrix([col[0:1] for col in m.elements]) == zeros(m.height, 1):
                m = m.del_col(0)
            self.matrix = m.elements
        else:
            self.matrix = matrix
        self.pairs = pairs
        self._fig = None

    def save(self, name: str) -> None:
        """Saves the bar chart figure as a pdf.  Same as savefig(name).

        Parameters
        ----------
        name : str
            Name of the pdf file (without ``.pdf`` extension).
        """
        if self._fig is None:
            self.draw()
        assert self._fig is not None
        print("Figure saved as pdf:", name)
        self._fig.savefig(name + ".pdf", bbox_inches="tight")

    def savefig(self, name: str) -> None:
        """Saves the bar chart figure as a pdf.  Same as save(name).

        Parameters
        ----------
        name : str
            Name of the pdf file (without ``.pdf`` extension).
        """
        self.save(name)

    def draw(self, t_end: int = 40) -> None:
        """Draws the Gantt chart as a matplotlib bar chart.

        Parameters
        ----------
        t_end : Optional[int]
            The final time instant on the horizontal axis.
        """
        num_rows = len(self.pairs)
        fig, ax = plt.subplots(figsize=(10.5, 1.25 + 0.625 * num_rows))
        y_step = 0.08

        _pairs = list(reversed(self.pairs))
        y_pos = np.linspace(0, y_step * num_rows, num=num_rows)
        edge_color = "black"

        x_labels = np.arange(0, t_end + 1)
        y_labels = list(reversed(["$(x_{" + str(p[0]) + "}, x_{" + str(p[1])
                                  + "})$" for p in self.pairs]))

        _ = ax.set_xticks(x_labels)
        _ = ax.set_yticks(np.linspace(0, y_step * num_rows, num=num_rows))
        _ = ax.set_yticklabels(y_labels)
        _ = ax.set_xlim(0, t_end)
        _ = ax.set_ylim(-y_step, y_step * (num_rows + 1))

        n = 1
        if t_end <= 60:          n = 2
        elif t_end <= 100:       n = 5
        elif t_end <= 200:       n = 10
        elif t_end <= 500:       n = 20
        elif t_end <= 1000:      n = 50
        elif t_end <= 1500:      n = 100
        elif t_end <= 2000:      n = 200
        else:                    n = t_end // 1000 * 100

        [label.set_visible(False)
         for idx, label in enumerate(ax.xaxis.get_ticklabels())
         if idx % n != 0]

        my_colors = mcolors.TABLEAU_COLORS

        delay_max_all = 0
        for row, pair in enumerate(_pairs):
            diff = [p2 - p1
                    for p2, p1 in zip(self.matrix[pair[1] - 1],
                                      self.matrix[pair[0] - 1])
                    if not math.isnan(p2 - p1)]

            delay = 0
            delay_max = 0
            for x in diff:
                if x < 0:
                    delay += 1
                else:
                    if delay > delay_max:
                        delay_max = delay
                    delay = 0
                if delay_max > delay_max_all:
                    delay_max_all = delay_max

            if delay > delay_max:
                delay_max = delay
            else:
                delay = delay_max
            if delay_max > delay_max_all:
                delay_max_all = delay_max

            row_1 = [0] * delay + self.matrix[pair[0] - 1]
            row_2 = self.matrix[pair[1] - 1] + [t_end + 1] * delay

            bar_lengths = [row_2[i] - row_1[i] for i in range(len(row_1))]
            bar_starts = row_1

            max_height = 0.05
            y_pos_min = [y_pos[row] - max_height / 2] * len(row_1)
            right_overlapping = [0] * len(row_1)

            for k in range(len(row_1)):
                for h in range(k + 1, len(row_1)):
                    if bar_starts[k] + bar_lengths[k] > bar_starts[h]:
                        right_overlapping[k] += 1
                    else:
                        break

            levels = [0] * len(row_1)
            heights = [max_height / (max(right_overlapping) + 1)] * len(row_1)

            for k in range(len(row_1)):
                flag = True
                h = 1
                while flag:
                    if k - h < 0:
                        flag = False
                    elif right_overlapping[k - h] < h:
                        flag = False
                    else:
                        if levels[k] == levels[k - h]:
                            levels[k] += 1
                            h = 0
                    h += 1
                y_pos_min[k] += levels[k] * heights[k]

            _ = ax.barh(y_pos_min, bar_lengths, left=bar_starts,
                        height=heights, label="test", edgecolor=edge_color,
                        alpha=1, color=my_colors, hatch="", align='edge')

        _ = plt.xlabel("Time unit $t$")
        _ = plt.ylabel("Resource")
        plt.tight_layout()
        self._fig = fig
        plt.show()

    def _alpha_out(self, alpha: float, num: int = 1) -> float:  # pyright: ignore[reportUnusedFunction]
        """Computes the final alpha value of overlapping alpha values."""
        result = alpha
        if num == 1:
            return result
        for _ in range(2, num + 1):
            result = result + alpha * (1 - result)
        return result


def trajectory(A: Matrix,
               x_0: Matrix | list[float],
               k_end: int | None = None,
               B: Matrix | None = None,
               u: Matrix | None = None) -> Matrix:
    """Computes a trajectory for x(k+1) = Ax(k) + Bu(k+1) or x(k+1) = Ax(k).

    Parameters
    ----------
    A : Matrix
        Dynamics Matrix of the state equation x(k+1) = Ax(k) + Bu(k+1).
    x_0 : Matrix or List[float]
        Initial state x_0 = x(0).
    k_end : Optional[int]
        Final k value for the trajectory. If u is provided, set to
        u.size()[1].
    B : Optional[Matrix]
        Input Matrix of the state equation.
    u : Optional[Matrix]
        Input signal u(k) for k = 1, ..., u.size()[1].

    Returns
    -------
    Matrix
        Matrix whose columns are the computed state vectors x(k).
    """
    if isinstance(x_0, list):
        x_0 = Matrix([[x] for x in x_0])

    b_mat: Matrix
    u_mat: Matrix
    if k_end is None:
        if u is not None:
            k_end = u.size()[1]
            u_mat = u
            if B is None:
                b_mat = Matrix.zeros(u.size()[0], x_0.size()[0])
            else:
                b_mat = B
        else:
            k_end = 10
            b_mat = Matrix.zeros(x_0.size()[0], 1)
            u_mat = Matrix.zeros(1, k_end)
    else:
        if u is None or B is None:
            b_mat = Matrix.zeros(x_0.size()[0], 1)
            u_mat = Matrix.zeros(1, k_end)
        else:
            b_mat = B
            u_mat = u
            if k_end > u.size()[1]:
                k_end = u.size()[1]

    x_old = x_0.copy()
    tr = [[a[0] for a in x_0.elements]]
    for i in range(k_end):
        x_new = (A * x_old
                 + b_mat * Matrix([col[i:i + 1] for col in u_mat.elements]))
        tr.append([a[0] for a in x_new.elements])
        x_old = x_new.copy()

    def hor_space_fun(x: float) -> int:
        return 1 if x == -np.inf or abs(x) < 1e-8 else len(str(x))
    print("State trajectory:")
    j_max = x_0.size()[0]
    space = [0] * (k_end + 1)
    for i in range(k_end + 1):
        for j in range(j_max):
            space[i] = max(space[i], hor_space_fun(tr[i][j]))

    for j in range(j_max):
        for i in range(k_end + 1):
            if tr[i][j] == eps:
                string_num = "ε"
            elif abs(tr[i][j]) < 1e-8:
                string_num = "e"
            else:
                string_num = str(tr[i][j])
            if j == j_max // 2 and i < k_end:
                print(" " * (space[i] - len(string_num)) + string_num + " -> ",
                      end="")
            else:
                print(" " * (space[i] - len(string_num)) + string_num + "    ",
                      end="")
        print()
    print()

    return Matrix(tr).T()


def output_trajectory(trajectory_matrix: Matrix, C: Matrix) -> Matrix:
    """Computes and prints the output trajectory y(k) = C x(k).

    Parameters
    ----------
    trajectory_matrix : Matrix
        State trajectory as returned by :func:`trajectory`.
    C : Matrix
        Output Matrix.

    Returns
    -------
    Matrix
        Output trajectory Matrix.
    """
    y = concatenate(
        [C * Matrix([col[i:i + 1]
                     for col in trajectory_matrix.elements])
         for i in range(trajectory_matrix.width)],
        axis=1)

    def hor_space_fun(x: float) -> int:
        return 1 if x == -np.inf or abs(x) < 1e-8 else len(str(x))
    tr = y.copy().T().elements
    print("Output trajectory:")
    j_max = y.height
    k_end = y.width
    space = [0] * k_end
    for i in range(k_end):
        for j in range(j_max):
            space[i] = max(space[i], hor_space_fun(tr[i][j]))

    for j in range(j_max):
        for i in range(k_end):
            if tr[i][j] == eps:
                string_num = "ε"
            elif abs(tr[i][j]) < 1e-8:
                string_num = "e"
            else:
                string_num = str(tr[i][j])
            if j == j_max // 2 and i < k_end - 1:
                print(" " * (space[i] - len(string_num)) + string_num + " -> ",
                      end="")
            else:
                print(" " * (space[i] - len(string_num)) + string_num + "    ",
                      end="")
        print()
    print()

    return y
