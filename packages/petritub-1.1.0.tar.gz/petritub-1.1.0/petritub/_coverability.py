from __future__ import annotations
from typing import final
import numpy as np
from ._node import Node, OMEGA


def _isGreaterEqual(vector1: np.ndarray, vector2: np.ndarray) -> bool:
    """Returns True if vector1 >= vector2 element-wise."""
    return bool(np.greater_equal(vector1, vector2).all())


@final
class CoverabilityTree():
    """
        PRIVATE: Used to compute the coverability tree of a Petri Net.

        Attributes
        ----------
        _initial_node : Node
            Initial markings of a Petri Net.
        _unexplored : list[Node]
            List of all nodes yet to be explored.
        _explored : list[Node]
            List of all explored nodes.
        _fired_transitions: set[int]
            Set of all fired transition in the coverability tree.
    """
    
    def __init__(self, initial_node: Node) -> None:
    
        self._initial_node = initial_node
        self._unexplored: list[Node] = [initial_node]
        self._explored: list[Node] = []
        self._fired_transitions: set[int] = set()

    def _addUnexplored(self, node: Node) -> None:
        self._unexplored.append(node)

    def _addExplored(self, node: Node) -> None:
        self._explored.append(node)

    def _addFiredTransition(self, transition: int) -> None:
        if transition not in self._fired_transitions:
            self._fired_transitions.add(transition)

    def _containsState(self, state: np.ndarray) -> bool:
        """
        PRIVATE: Checks if there already exists a node with an identical state in the
        explored list.
        """
        return any(np.array_equal(node._state, state)
                   for node in self._explored)

    def _emptyUnxplored(self) -> bool:
        return len(self._unexplored) == 0

    def _explore(self) -> Node:
        node = self._unexplored[0]
        self._unexplored = self._unexplored[1:]
        return node

    @staticmethod
    def _vdot(state1: np.ndarray, state2: np.ndarray) -> float:
        '''
        PRIVATE: Gives the dot product of two states/vectors where one or both
        are from the coverability tree.
        '''
        # np.nan_to_num creates in default a copy of the passed array
        # -> attribute coverability_tree will not be changed
        return float(np.vdot(np.nan_to_num(state1), np.nan_to_num(state2)))

    @staticmethod
    def _checkForGrowth(new_state: np.ndarray, node: Node) -> np.ndarray:
        """
        PRIVATE: Examines the path from the root node in the coverability tree to the
        "node"(given as an argument). If there exists a node "ksi" in this path
        which is covered by, but not equal to, the "node", set
        "node.state[i] = OMEGA" for all "i" such that
        "node.state[i] > ksi.state[i]".
        """

        # Check if the state of the node is covered by the new_state
        if _isGreaterEqual(new_state, node._state):
            # Set all elements of the new_state to OMEGA if they are
            # strictly greater then the elements in covered node
            for i, element in enumerate(np.greater(new_state, node._state)):
                if element:
                    new_state[i, 0] = OMEGA

        # Keep checking for a covered node until the root node
        while node._parent is not None:
            node = node._parent

            # Check if the state of the parent node is covered by the new_state
            if _isGreaterEqual(new_state, node._state):
                # Set all elements of the new_state to OMEGA if they are
                # strictly greater then the elements in covered node
                for i, element in enumerate(np.greater(new_state, node._state)):
                    if element:
                        new_state[i, 0] = OMEGA

        # Return the corrected state
        return new_state

    def _fire(self, node: Node, transition_number: int,
             Aminus: np.ndarray, A: np.ndarray) -> Node | None:
        """
        PRIVATE: Fires given transition on a given node and returns the new node.
        """

        if not _isGreaterEqual(node._state,
                                       Aminus[:, [transition_number]]):
            raise Exception("Transition can not fire.")
        else:
            # Compute new state
            new_state = np.add(node._state, A[:, [transition_number]])
            # Check for new omega
            new_state = CoverabilityTree._checkForGrowth(new_state, node)

            # Check if the node does not have the same child already
            if len(node._children) != 0:
                for child in node._children:
                    # If it is the case append transition number to the
                    # existing child and return None
                    if np.array_equal(child[1]._state, new_state):
                        child[1]._trans_par.append(transition_number)
                        self._addFiredTransition(transition_number)
                        return None

            # Otherwise, continue with creation of the new_node and return it
            new_node = Node(new_state, node._depth + 1)

            # Log fired transition and previous node in new_node
            new_node._parent = node
            new_node._trans_par.append(transition_number)
            # Log fired transition and new_node in node
            node._children.append((transition_number, new_node))

            # Add transtions to fired transtitions
            self._addFiredTransition(transition_number)

            return new_node
