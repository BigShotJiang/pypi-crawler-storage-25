To generate the documentation, use
```
sphinx-build -b html source build
```