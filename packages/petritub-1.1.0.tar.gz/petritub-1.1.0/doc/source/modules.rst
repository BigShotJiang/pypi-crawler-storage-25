Functions
=========

The ``untimed_pn`` module provides tools for computing a coverability tree of a Petri net, drawing it, analyzing its properties and computing a state based controller.

The ``max_plus`` and ``min_plus`` modules add timing information to Petri nets, allowing us to compute state trajectories. To obtain linear state equations, one can use the max-plus algebra or the min-plus algebra.

.. toctree::
   :maxdepth: 2

   untimed_pn
   max_plus
   min_plus
