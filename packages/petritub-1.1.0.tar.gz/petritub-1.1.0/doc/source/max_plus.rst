Max-plus toolbox
================

The module contained in folder ``petritub/max_plus`` defines the classes ``Matrix``, ``PrecedenceGraph`` and ``Gantt``.

The ``Matrix`` class represents max-plus matrices and contains methods for max-plus matrix operations and properties (e.g. max-plus addition, multiplication, the Kleene star operator, irreducibility).

The ``PrecedenceGraph`` class is based on a max-plus ``Matrix`` object and represents the precedence graph of this matrix. It can be used to analyse precedence graphs (strongly connected components, cyclicity, etc). It is moreover possible to graphically represent a precedence graph as well as compute and draw the critical graph.

The ``Gantt`` class can produce a bar chart (*Gantt chart*) showing the resource occupancy of places as a function of time. This is based on a max-plus ``Matrix`` object as well.

Matrix
******

.. autoclass:: petritub.max_plus.Matrix
   :members:
   :exclude-members: addition

PrecedenceGraph
***************

.. autoclass:: petritub.max_plus.PrecedenceGraph
   :members:
   :exclude-members: addition

Gantt
*****

.. autoclass:: petritub.max_plus.Gantt
   :members:
   :exclude-members: addition

