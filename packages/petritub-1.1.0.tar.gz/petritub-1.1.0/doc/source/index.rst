.. toolbox documentation master file, created by
   sphinx-quickstart on Sun Jun 19 18:31:49 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PetriTUB
========

Introduction
------------

The Python toolbox ``petritub`` allows to manipulate untimed Petri nets and provides max-plus and min-plus algebra tools for the study of timed event graphs.

For example, the library provides functions for performing the following tasks:

- Drawing the coverability tree for a given Petri net
- Computing the maximally permissive state-based controller, given a set of specifications
- Finding the cycle time of a timed event graph and solving the related eigenproblem
- Drawing the trajectory of a timed event graph as a Gantt chart

Authors
-------

The toolbox is continuously developed at the `Control Systems Group <https://www.control.tu-berlin.de/>`_ of the `Technical University Berlin <https://www.tu.berlin/>`_. The first version of the code was designed in the summer semester of 2022 by Jan Bednar, Jan Clevorn, Jakub Dvorak, Dominik Tirpak, under the supervision of Davide Zorzenon, as part of the course "Projekt Synthese und Analyse von Regelsystemen". External contributions are highly welcome, for contact write to `Davide Zorzenon <mailto:davide.zorzenon@tu-berlin.de>`_.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   gettingStarted
   modules
   tutorials

.. Indices and tables
   ==================
   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
