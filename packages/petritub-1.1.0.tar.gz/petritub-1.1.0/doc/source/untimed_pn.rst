Untimed Petri nets toolbox
==========================

The module ``untimed_pn`` contains four classes – ``PetriNet``, ``Node``, ``CoverabilityTree`` and ``StateController``.

Two have public functions (``PetriNet`` and ``StateController``) that can be used to analyze untimed Petri nets or to compute their state-based controller for a given specification.

Two are private (``Node``, ``CoverabilityTree``) and only their attributes are documented on this page. For further information about their functions, see directly the ``untimed_pn`` module.

PetriNet
********

.. autoclass:: petritub.untimed_pn.PetriNet
   :members:

Node
****

.. autoclass:: petritub.untimed_pn.Node
   :members:

CoverabilityTree
****************

.. autoclass:: petritub.untimed_pn.CoverabilityTree
   :members:

StateController
***************

.. autoclass:: petritub.untimed_pn.StateController
   :members:
