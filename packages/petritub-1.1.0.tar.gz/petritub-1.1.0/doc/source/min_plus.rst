Min-plus toolbox
===========================

The module ``petritub/min_plus`` contains the classes ``Matrix`` and ``PrecedenceGraph``. This module is very similar to ``max_plus``, as it contains methods for computations in the min-plus algebra, which is dual to the max-plus algebra.

The ``Matrix`` class represents min-plus matrices and contains methods for min-plus matrix operations and properties (e.g. min-plus addition, multiplication, the Kleene star operator, irreducibility).

The ``PrecedenceGraph`` class is based on a min-plus ``Matrix`` object and represents the precedence graph of this matrix. It can analyze precedence graphs (based on strongly connected components and properties such as cyclicity). It is moreover possible to graphically represent a precedence graph as well as compute and draw the critical graph.

Matrix
******

.. autoclass:: petritub.min_plus.Matrix
   :members:
   :exclude-members: addition

PrecedenceGraph
***************

.. autoclass:: petritub.min_plus.PrecedenceGraph
   :members:
   :exclude-members: addition
