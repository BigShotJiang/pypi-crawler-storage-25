Getting Started
===============

Systems Requirements
--------------------

In order to use the ``petritub`` toolbox, you need to install

* ``Python 3`` (tested on `3.8`)

and the following libraries

* ``numpy`` (tested on `1.19.3`)
* ``matplotlib`` (tested on `3.4.3`)
* ``networkx`` (tested on `2.6.3`)

Installing the toolbox
----------------------

Download the latest version of the toolbox from its `GitLab repository <https://git.tu-berlin.de/control/discrete-event-systems/petritub>`_. The toolbox is further divided into three modules. For more information see `Functions <modules.html>`_.

Import the desired toolbox as a script using ``from petritub.module_name import *``. E.g., ``from petritub.untimed_pn import *``

Structure of the project
------------------------

The repository is structured as follows:

* ``petritub``: contains the toolbox. Import the individual modules `from petritub.module_name import *` to use the toolbox.
* ``doc``: contains the Sphinx source documentation of the toolbox.
* two jupyter notebook tutorials (`tutorial_max_plus.ipynb` and `tutorial_untimed_pn.ipynb`) demonstrating the usage of the toolbox are in the root folder.

How to Read this Documentation
------------------------------

In the section `Functions <modules.html>`_ the ``Python`` functions present in the package are described. They are divided in the following subsections:

* Untimed Petri nets:

  * `untimed_pn toolbox (for untimed Petri nets) <untimed_pn.html>`_: contains the classes and functions related to untimed Petri nets, e.g., for drawing the coverability tree, computing the state base control, and analyzing further properties of a Petri net;
* Timed event graphs:

  * `max_plus toolbox <max_plus.html>`_: contains classes and functions for max-plus operations (e.g. addition, multiplication, Kleene star), the max-plus eigenvalue problem, visual representation and analysis of precedence graphs and visual representation of resource occupancy in Gantt charts.
  * `min_plus toolbox <min_plus.html>`_: analogously to the max-plus toolbox, this section contains classes and functions to handle min-plus matrices and precedence graphs.

In the section `Tutorials <tutorials.html>`_ you can see the functions of this library being used on a practical example of a manufacturing system.
