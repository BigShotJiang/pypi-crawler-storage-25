# Changelog

## 10th November 2023: Fire!

* untimed_pn:
	* method `fire()` of class `PetriNet` to fire a transition of a Petri net and see how the state evolves
	* method `closedLoop()` returns the Petri net representing the closed-loop system "plant + controller", where the plant is represented by a Petri net and the controller is a state-based controller computed using method `getStateController()`

## 13th March 2023: Bug fix, critical graph, and formatting

* max_plus:
	* method `cyclicity()` now returns the right cyclicity of a irreducible `Matrix`, using the circuits of the critical graph
	* method `critical()` of class `PrecedenceGrapg` added, which allows to determine the critical graph associated to a givven precedence graph
	* method `__format__()` of class `Matrix` added, which allows to choose among different formats for printing the matrix

## 15th January 2023: Colorful Gantt charts

* max_plus:
	* Gantt charts are now colored, and multi occupancy is shown by stacking bars vertically
	* method `__eq__()` returns false when comparing Matrix object with something else
	* method `__str__()` now visualizes epsilons and e's as such (instead of -inf and 0); moreover, matrices are nicely displayed (following pseudo-Matlab style)
	* method `eigenvectors()` now returns a matrix, whose columns are eigenvectors (transposed w.r.t. before)
	* precedence graphs now are more informative: gray nodes correspond to those that do not belong to any msc subgraph
	* distinction between strongly connected and maximal strongly connected components no more useful. Method `strongly_connected_components()` to be removed in future versions
	* trajectories now visualize epsilons and e's as such. Moreover, horizontal distance is decreased and should be more consistent

## 10th November 2022: Added new features and cleaned the directory

* Renamed toolbox to `petritub`, and toolbox modules to `untimed_pn`, `max_plus`, and `min_plus`
* max_plus:
	* Class `Matrix`:
		* more flexible handling of scalar objects
		* methods `__radd__()`, `__rmul__()` for reverse operations added
		* methods `del_row()` and `del_col()` to delete single rows and columns
		* methods `zero()`, `top()` renamed into `zeros()` and `tops()`, respectively
		* method `ones()` (similar to `zeros()` but for e-elements) added
		* method `__pow__()` for exponentiation added
		* method `T()` fixed, now the retuned Matrix has the right width and height
	* function `mp()` to construct a Matrix object
	* function `concatenate()` to construct block matrices
	* functions `zeros()`, `eye()`, `ones()`, `top()` independent from class `Matrix`
	* function `trajectory()` now can compute the trajectory for non-autonomous systems
	* function `output_trajectory()` to compute the output trajectory for a non-autonomous system
* notebook `tutorial_max_plus` now extended, to show other functionalities
* now the documentation updates automatically once the files are modified. Also, extensions `nbsphinx` and `nbsphinx_link` added to sphinx for more flexibility

## 12th August 2022: Submitted version

* General improvements to code readability and comments
* Documentation of all ("non-private") classes and methods
* Renamed the class "Schedule" to "Gantt"
* Min-plus toolbox added: dual toolbox to the max-plus toolbox with classes Matrix and PrecedenceGraph

## 3rd July 2022: Gantt charts

* Methods eigenvalue() and eigenvectors() moved to the Matrix class
* Method trajectory(): computes trajectory for x(k+1)=Ax(k), x(0)=x_0, input arguments are A, x(0) and k_end (number of iterations)
* Class Matrix:
	* method cyclicity(), same as cyc() computes the cyclicity of an irreducible matrix
	* method is_irreducible()
* Class PrecedenceGraph:
	* method critical_circuits() returns a list of critical (elementary) circuits
	* added parameters for spread and seed in draw() method
	* methods savefig(), savefig_critical() to save the graph as a pdf
	* method is_strongly_connected()
* Class Schedule (new) *later renamed to Gantt*: for drawing resource occupation as a bar chart (Gantt chart)
	* inpus arguments: Matrix or 2d array (each column is x(k) for a specific k value) and pairs of transitions
	* method draw(t_end=40) draws the bar chart, up to a specified end time
	* method save() saves the chart as a pdf

## 13th June 2022: Critical graph

* Function eigenvalue(A) computes the largest eigenvalue of A
* Function eigenvectors(A) lists the linearly (in)dependent eigenvectors of A
* Class PrecedenceGraph: class for precedence graph corresponding to a max-plus matrix
	* draw: draws the precedence graph, where each strongly connected component has a unique color
	* draw_critical: draws the critical graph, where non-critical components are drawn transparently
	* strongly_connected_components: lists the strongly connected components
	* transpose: returns the transpose graph (directions of all arrows are reversed)
	* cycles: returns a list of (elementary) cycles of the graph
	* subgraph(nodes): returns a subgraph consisting of the given node list and the corresponding edges
	* msc_components: lists the maximally strongly connected components of the critical graph
	* critical_cycles: returns a list of critical cycles of the graph
	* critical_edges: returns a list of critical edges of the graph

## 7th May 2022: First commit

* First version of the max-plus toolbox, including matrix operations and a class for max-plus matrices
	* zero, top and identity matrices
	* star and plus operator
