"""Provider-neutral input normalization."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import Any, Iterable

from p_moderation.image_encode import data_url_from_bytes
from p_moderation.image_encode import normalize_image_bytes
from p_moderation.models import (
    EncodedImage,
    ImageInput,
    ProviderInputItem,
    ProviderModerationRequest,
)


def prepare_provider_request(
    *,
    texts: Iterable[str] = (),
    images: Iterable[ImageInput] = (),
    request_id: str | None = None,
    client_id: str | None = None,
) -> ProviderModerationRequest:
    """Normalize caller inputs into a provider-neutral request shape."""
    items: list[ProviderInputItem] = []
    item_index = 0

    for text in texts:
        items.append(
            ProviderInputItem(
                item_index=item_index,
                input_type="text",
                text=text,
            )
        )
        item_index += 1

    for image in images:
        items.append(_normalize_image_item(image=image, item_index=item_index))
        item_index += 1

    return ProviderModerationRequest(
        items=items,
        request_id=request_id,
        client_id=client_id,
    )


def image_input_to_url(image: ImageInput) -> str:
    """Convert ImageInput into a URL accepted by URL-based provider payloads."""
    item = _normalize_image_item(image=image, item_index=0)
    if item.image_url is not None:
        return item.image_url
    if item.image_bytes is None:
        raise ValueError("Image input is missing bytes and URL content.")
    return data_url_from_bytes(item.image_bytes, mime_type=item.mime_type or "image/jpeg")


def _normalize_image_item(image: ImageInput, *, item_index: int) -> ProviderInputItem:
    if isinstance(image, EncodedImage):
        return ProviderInputItem(
            item_index=item_index,
            input_type="image",
            image_bytes=image.content,
            mime_type=image.mime_type,
            source=image.source,
        )

    if isinstance(image, bytes):
        content, mime_type = normalize_image_bytes(image)
        return ProviderInputItem(
            item_index=item_index,
            input_type="image",
            image_bytes=content,
            mime_type=mime_type,
        )

    if isinstance(image, Path):
        content, mime_type = normalize_image_bytes(image)
        return ProviderInputItem(
            item_index=item_index,
            input_type="image",
            image_bytes=content,
            mime_type=mime_type,
            source=str(image),
        )

    # Handle PIL Image objects
    if _is_pil_image(image):
        content, mime_type = _pil_image_to_bytes(image)
        return ProviderInputItem(
            item_index=item_index,
            input_type="image",
            image_bytes=content,
            mime_type=mime_type,
        )

    value = str(image)
    if value.startswith(("http://", "https://")):
        return ProviderInputItem(
            item_index=item_index,
            input_type="image",
            image_url=value,
            source=value,
        )

    content, mime_type = normalize_image_bytes(value)
    return ProviderInputItem(
        item_index=item_index,
        input_type="image",
        image_bytes=content,
        mime_type=mime_type,
        source=value,
    )


def _is_pil_image(obj: Any) -> bool:
    """Check if object is a PIL Image without requiring PIL import."""
    return hasattr(obj, "save") and hasattr(obj, "format") and type(obj).__module__ == "PIL.Image"


def _pil_image_to_bytes(pil_image: Any) -> tuple[bytes, str]:
    """Convert a PIL Image to bytes and detect MIME type."""
    output = BytesIO()
    # Use JPEG format by default for compatibility
    fmt = pil_image.format or "JPEG"
    pil_image.save(output, format=fmt)
    content = output.getvalue()

    # Map format to MIME type
    mime_type_map = {
        "JPEG": "image/jpeg",
        "JPG": "image/jpeg",
        "PNG": "image/png",
        "GIF": "image/gif",
        "WEBP": "image/webp",
    }
    mime_type = mime_type_map.get(fmt.upper(), "image/jpeg")
    return content, mime_type
