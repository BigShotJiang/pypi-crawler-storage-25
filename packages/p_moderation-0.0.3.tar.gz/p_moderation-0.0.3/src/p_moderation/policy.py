"""Policy evaluation for provider-neutral moderation responses."""

from __future__ import annotations

from p_moderation.exceptions import ProviderConfigurationError, ProviderResponseShapeError
from p_moderation.models import (
    ModerationAction,
    ModerationItemResult,
    ModerationResult,
    ProviderItemResult,
    ProviderModerationRequest,
    ProviderModerationResponse,
    ProviderPolicy,
    aggregate_actions,
    stronger_action,
)


def apply_policy_single_item(
    response: ProviderModerationResponse,
    *,
    policy: ProviderPolicy,
    input_type: str = "text",
) -> ModerationResult:
    """Fast path for single-item moderation (used by moderate() method)."""
    if policy.provider_name != response.provider_name:
        raise ProviderConfigurationError(
            f"Policy provider '{policy.provider_name}' does not match '{response.provider_name}'."
        )

    if not response.item_results:
        raise ProviderResponseShapeError("OpenAI moderation response contains no results.")

    provider_item = response.item_results[0]
    item_result = _apply_policy_to_item(
        provider_item=provider_item,
        policy=policy,
        request_input_type=input_type,
    )

    return ModerationResult(
        provider_name=response.provider_name,
        provider_response_id=response.provider_response_id,
        model=response.model,
        action=item_result.action,
        flagged=item_result.flagged,
        categories=item_result.categories,
        category_scores=item_result.category_scores,
        category_applied_input_types=item_result.category_applied_input_types,
        item_results=[item_result],
    )


def apply_policy_from_provider_response(
    response: ProviderModerationResponse,
    *,
    policy: ProviderPolicy,
    request: ProviderModerationRequest,
) -> ModerationResult:
    """Apply a provider-specific policy to a provider-neutral response.

    Handles both per-item results (one per input) and aggregated results (one for all inputs).
    """
    if policy.provider_name != response.provider_name:
        raise ProviderConfigurationError(
            f"Policy provider '{policy.provider_name}' does not match '{response.provider_name}'."
        )

    # Check if this is an aggregated result (1 result for all items) or per-item results
    is_aggregated = len(response.item_results) == 1 and len(request.items) > 1

    if not is_aggregated and len(response.item_results) != len(request.items):
        raise ProviderResponseShapeError(
            f"Provider returned {len(response.item_results)} item result(s) "
            f"but {len(request.items)} item(s) were requested."
        )

    item_results: list[ModerationItemResult] = []

    if is_aggregated:
        # Single aggregated result for all inputs
        provider_item = response.item_results[0]
        # Use provider's determined input type (text, image, or combined)
        item_results.append(
            _apply_policy_to_item(
                provider_item=provider_item,
                policy=policy,
                request_input_type=provider_item.input_type,
            )
        )
    else:
        # Per-item results (one result per input item)
        for provider_item in response.item_results:
            if provider_item.item_index >= len(request.items):
                raise ProviderResponseShapeError(
                    "Provider item index is out of range for the request."
                )
            request_item = request.items[provider_item.item_index]
            item_results.append(
                _apply_policy_to_item(
                    provider_item=provider_item,
                    policy=policy,
                    request_input_type=request_item.input_type,
                )
            )

    return ModerationResult(
        provider_name=response.provider_name,
        provider_response_id=response.provider_response_id,
        model=response.model,
        action=aggregate_actions([item.action for item in item_results]),
        flagged=any(item.flagged for item in item_results),
        categories=_aggregate_categories(item_results),
        category_scores=_aggregate_scores(item_results),
        category_applied_input_types=_aggregate_applied_input_types(item_results),
        item_results=item_results,
        request_id=request.request_id,
        client_id=request.client_id,
    )


def _apply_policy_to_item(
    *,
    provider_item: ProviderItemResult,
    policy: ProviderPolicy,
    request_input_type: str,
) -> ModerationItemResult:
    """Map categories through policy; item action is ``aggregate_actions`` of per-category actions."""
    category_actions: dict[str, ModerationAction] = {}
    category_scores: dict[str, float] = {}
    category_applied_input_types: dict[str, list[str]] = {}

    for category, result in provider_item.categories.items():
        applied = result.applied_input_types
        category_applied_input_types[category] = list(applied) if applied else []
        if result.score is not None:
            category_scores[category] = float(result.score)
        if result.flagged:
            category_actions[category] = policy.get_action(category, request_input_type)
        else:
            category_actions[category] = ModerationAction.PASS

    flagged = provider_item.flagged or any(r.flagged for r in provider_item.categories.values())
    action = aggregate_actions(list(category_actions.values()))
    if flagged and action == ModerationAction.PASS:
        action = ModerationAction.MONITOR

    return ModerationItemResult(
        item_index=provider_item.item_index,
        input_type=provider_item.input_type,
        action=action,
        flagged=flagged,
        categories=category_actions,
        category_scores=category_scores,
        category_applied_input_types=category_applied_input_types,
    )


def _aggregate_categories(item_results: list[ModerationItemResult]) -> dict[str, ModerationAction]:
    aggregated: dict[str, ModerationAction] = {}
    for item in item_results:
        for category, action in item.categories.items():
            previous = aggregated.get(category)
            aggregated[category] = action if previous is None else stronger_action(previous, action)
    return aggregated


def _aggregate_scores(item_results: list[ModerationItemResult]) -> dict[str, float]:
    aggregated: dict[str, float] = {}
    for item in item_results:
        for category, score in item.category_scores.items():
            aggregated[category] = max(score, aggregated.get(category, 0.0))
    return aggregated


def _aggregate_applied_input_types(
    item_results: list[ModerationItemResult],
) -> dict[str, list[str]]:
    aggregated: dict[str, list[str]] = {}
    for item in item_results:
        for category, input_types in item.category_applied_input_types.items():
            existing = aggregated.setdefault(category, [])
            for input_type in input_types:
                if input_type not in existing:
                    existing.append(input_type)
    return aggregated
