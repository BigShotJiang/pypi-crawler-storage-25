"""OpenAI moderation provider.

This module calls ``AsyncOpenAI().moderations.create(model=..., input=[...])`` with the same
``input`` list shape as the OpenAI API and Python SDK: each element is either
``{"type": "text", "text": "..."}`` or
``{"type": "image_url", "image_url": {"url": "https://..."} | "data:...;base64,..."}``.
``AsyncOpenAI`` is the async counterpart to ``from openai import OpenAI``; the request
payload is identical.
"""

from __future__ import annotations

import asyncio
import hashlib
import uuid
from typing import Any

import aiohttp
import httpx
from openai import AsyncOpenAI

from p_moderation.exceptions import (
    ModerationProviderError,
    ProviderConfigurationError,
    ProviderResponseShapeError,
)
from p_moderation.image_encode import data_url_from_bytes
from p_moderation.models import (
    ImageInput,
    ModerationAction,
    ProviderCategoryResult,
    ProviderItemResult,
    ProviderModerationResponse,
    ProviderPolicy,
    ProviderPrediction,
)
from p_moderation.normalize import image_input_to_url
from p_moderation.providers.base import BaseModerationProvider
from p_moderation.providers._client_manager import (
    OPTIMIZED_LIMITS,
    get_default_http_client,
    get_default_aiohttp_client,
)

OPENAI_PROVIDER_NAME = "openai"

DEFAULT_OMNI_MODERATION_MODEL = "omni-moderation-latest"


def _coalesce_key(text: str | None, image: ImageInput | None) -> str:
    """Generate a deduplication key for request coalescing."""
    text_part = text or ""
    image_part = repr(image) if image else ""
    combined = f"{text_part}|{image_part}"
    return hashlib.sha256(combined.encode()).hexdigest()[:16]

def _get_default_aiohttp_client() -> aiohttp.ClientSession:
    """Get or create default aiohttp client with optimized connection pooling."""
    return get_default_aiohttp_client()


def _get_default_http_client() -> httpx.AsyncClient:
    """Get or create the default httpx client."""
    return get_default_http_client()


class OpenAIProvider(BaseModerationProvider):
    """Adapts :class:`ProviderModerationRequest` to OpenAI ``moderations.create`` payloads."""

    name = OPENAI_PROVIDER_NAME
    supports_text = True
    supports_image = True

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str = "omni-moderation-latest",
        default_timeout: float = 10.0,
        http_backend: str = "default",
        max_retries: int = 0,
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._model_supports_image = model.lower().startswith("omni-moderation")
        self._base_url = base_url
        self._default_timeout = default_timeout
        self._http_backend = http_backend
        self._max_retries = max_retries
        self._client_cache: dict[str, AsyncOpenAI] = {}
        self._http_client: Any = None
        self._inflight: dict[str, tuple[asyncio.Event, dict[str, Any]]] = {}

    def default_policy(self) -> ProviderPolicy:
        """Return the default OpenAI category policy."""
        return ProviderPolicy(
            provider_name=self.name,
            category_actions={
                "harassment": ModerationAction.MONITOR,
                "harassment/threatening": ModerationAction.BLOCK,
                "hate": ModerationAction.MONITOR,
                "hate/threatening": ModerationAction.BLOCK,
                "illicit": ModerationAction.MONITOR,
                "illicit/violent": ModerationAction.BLOCK,
                "self-harm": ModerationAction.BLOCK,
                "self-harm/intent": ModerationAction.BLOCK,
                "self-harm/instructions": ModerationAction.BLOCK,
                "sexual": ModerationAction.MONITOR,
                "sexual/minors": ModerationAction.BLOCK,
                "violence": ModerationAction.MONITOR,
                "violence/graphic": ModerationAction.BLOCK,
            },
        )

    async def moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        request_id: str | None = None,
        client_id: str | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Call ``moderations.create`` with single text and/or image.

        Returns 1 aggregated ProviderModerationResponse per request.
        Deduplicates concurrent requests with identical inputs.
        """
        if not text and not image:
            raise ProviderConfigurationError("At least one of text or image must be provided.")

        if image and not self._model_supports_image:
            raise ProviderConfigurationError(
                "OpenAI image moderation requires an omni-moderation model."
            )

        # Request coalescing: reuse in-flight requests for identical inputs
        key = _coalesce_key(text, image)
        if key in self._inflight:
            event, result_box = self._inflight[key]
            await event.wait()
            if "error" in result_box:
                raise result_box["error"]
            return result_box["result"]

        # First caller for this input; initialize tracking
        event = asyncio.Event()
        result_box: dict[str, Any] = {}
        self._inflight[key] = (event, result_box)

        try:
            result = await self._do_moderate(text=text, image=image, timeout=timeout)
            result_box["result"] = result
            return result
        except Exception as exc:
            result_box["error"] = exc
            raise
        finally:
            event.set()
            self._inflight.pop(key, None)

    async def _do_moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Execute moderation request (internal; called by moderate)."""
        payload = []
        if text:
            payload.append({"type": "text", "text": text})
        if image:
            payload.append(_to_openai_input_single(image))

        client = self._get_client(self._api_key)
        model = self._model

        try:
            # Client has default timeout; only override if explicitly provided
            kwargs = {"model": model, "input": payload}
            if timeout is not None and timeout != self._default_timeout:
                kwargs["timeout"] = timeout
            response = await client.moderations.create(**kwargs)
        except Exception as exc:
            raise ModerationProviderError(str(exc)) from exc

        results = response.results if hasattr(response, "results") else []
        if not results:
            raise ProviderResponseShapeError("OpenAI moderation response contains no results.")

        # OpenAI returns 1 aggregated result
        raw = _coerce_raw_result(results[0])
        categories = raw.get("categories", {})
        category_scores = raw.get("category_scores", {})
        category_applied_input_types = raw.get("category_applied_input_types", {})

        item_categories: dict[str, ProviderCategoryResult] = {}
        for category, flagged in categories.items():
            applied = category_applied_input_types.get(category)
            item_categories[category] = ProviderCategoryResult(
                flagged=bool(flagged),
                score=_coerce_score(category_scores.get(category)),
                applied_input_types=list(applied) if applied else [],
            )

        # Determine input type for the result
        if image:
            input_type = "combined" if text else "image"
        else:
            input_type = "text"

        # Use raw.get("flagged") if available, else check categories
        is_flagged = raw.get("flagged")
        if not is_flagged and item_categories:
            is_flagged = any(item.flagged for item in item_categories.values())

        item_results: list[ProviderItemResult] = [
            ProviderItemResult(
                item_index=0,
                input_type=input_type,
                flagged=bool(is_flagged),
                categories=item_categories,
            )
        ]

        return ProviderModerationResponse(
            provider_name=self.name,
            provider_response_id=getattr(response, "id", None),
            model=getattr(response, "model", model),
            item_results=item_results,
        )

    async def submit(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> ProviderPrediction:
        """Run moderation in the current task and return a completed prediction.

        OpenAI moderation completes in one await; the returned object includes
        ``output`` and ``status='completed'`` so callers are not required to
        poll or call :meth:`ProviderPrediction.wait`.
        """
        text, image = self._extract_first_items(texts, images)
        result = await self.moderate(
            text=text,
            image=image,
            request_id=request_id,
            client_id=client_id,
        )
        job_id = str(uuid.uuid4())
        self._get_job_results()[job_id] = result
        return ProviderPrediction(
            id=job_id,
            provider_name=self.name,
            status="completed",
            output=result,
            _provider=self,
        )

    async def aclose(self) -> None:
        """Close any AsyncOpenAI clients created by this provider."""
        for client in self._client_cache.values():
            await client.close()
        self._client_cache.clear()

    async def warmup(self) -> None:
        """Eagerly initialize HTTP client (connection pool).

        Call this during provider setup to reduce latency on the first request.
        """
        # Eagerly create client and prime the HTTP connection pool
        self._get_client(self._api_key)

    def _get_client(self, api_key: str | None) -> AsyncOpenAI:
        cache_key = api_key or ""
        if cache_key not in self._client_cache:
            kwargs: dict[str, Any] = {
                "api_key": api_key,
                "base_url": self._base_url,
                "max_retries": self._max_retries,
                "timeout": self._default_timeout,  # Set global timeout on client
                "_strict_response_validation": False,  # Optimize: skip validation, we control format
            }
            if self._http_backend == "aiohttp":
                if self._http_client is None:
                    self._http_client = _get_default_aiohttp_client()
                kwargs["http_client"] = self._http_client
            else:
                # Use shared default httpx client (reduces per-instance creation)
                kwargs["http_client"] = _get_default_http_client()
            self._client_cache[cache_key] = AsyncOpenAI(**kwargs)
        return self._client_cache[cache_key]


def _to_openai_input_single(image: ImageInput) -> dict[str, Any]:
    """Convert a single ImageInput to OpenAI image_url format."""
    url = image_input_to_url(image)

    return {
        "type": "image_url",
        "image_url": {"url": url},
    }


def _to_openai_input(item) -> dict[str, Any]:
    """Convert a ProviderInputItem to OpenAI format (for backward compatibility)."""
    if item.input_type == "text":
        return {"type": "text", "text": item.text}

    if item.image_url is not None:
        url = item.image_url
    elif item.image_bytes is not None:
        url = data_url_from_bytes(item.image_bytes, mime_type=item.mime_type or "image/jpeg")
    else:
        raise ProviderConfigurationError("Image moderation item is missing image content.")

    return {
        "type": "image_url",
        "image_url": {"url": url},
    }


def _coerce_raw_result(result: Any) -> dict[str, Any]:
    if hasattr(result, "model_dump"):
        return result.model_dump(by_alias=True)
    if hasattr(result, "items"):
        return dict(result)
    raise ProviderResponseShapeError(
        "OpenAI moderation result could not be converted into a mapping."
    )


def _coerce_score(value: Any) -> float | None:
    if value is None:
        return None
    return float(value)
