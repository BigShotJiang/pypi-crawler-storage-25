"""Optimized Replicate client: connection pooling, adaptive polling."""

from __future__ import annotations

import asyncio
from contextlib import ExitStack
import os
import queue
import threading
import time
from io import BytesIO
from pathlib import Path
from typing import Optional, Any, Callable

from replicate.client import Client

from p_moderation.image_encode import normalize_image_bytes
from p_moderation.image_url_fetch import fetch_image_url_bytes_sync

REPLICATE_PROVIDER_NAME = "replicate"
DEFAULT_REPLICATE_DEPLOYMENT = "prunaai/p-moderation"


def _is_remote_image_url(value: Any) -> bool:
    return isinstance(value, str) and value.startswith(("http://", "https://"))


def _is_data_url(value: Any) -> bool:
    return isinstance(value, str) and value.startswith("data:")


def _is_pil_image(value: Any) -> bool:
    return (
        value.__class__.__module__.startswith("PIL.")
        and value.__class__.__name__.endswith("Image")
        and callable(getattr(value, "save", None))
    )


def _to_upload_buffer(content: bytes, *, mime_type: str = "image/jpeg") -> BytesIO:
    extension = "jpg" if "jpeg" in mime_type else mime_type.split("/")[-1]
    buffer = BytesIO(content)
    buffer.name = f"upload.{extension}"
    buffer.seek(0)
    return buffer


def _local_path_from_str(value: str) -> Path | None:
    path = Path(value).expanduser()
    return path if path.is_file() else None


def _has_remote_image_input(input_data: dict[str, Any]) -> bool:
    image = input_data.get("image")
    if _is_remote_image_url(image):
        return True
    images = input_data.get("images")
    return isinstance(images, (list, tuple)) and any(_is_remote_image_url(v) for v in images)


def _looks_like_remote_fetch_error(message: str) -> bool:
    lowered = message.lower()
    return "http error" in lowered or "forbidden" in lowered or "403" in lowered


def _normalize_single_image_input(
    value: Any,
    *,
    timeout_s: float,
    prefer_remote_urls: bool,
    stack: ExitStack,
) -> Any:
    if _is_data_url(value):
        return value
    if _is_remote_image_url(value):
        if prefer_remote_urls:
            return value
        raw_bytes = fetch_image_url_bytes_sync(value, timeout=timeout_s)
        image_bytes, mime_type = normalize_image_bytes(raw_bytes)
        return _to_upload_buffer(image_bytes, mime_type=mime_type)
    if isinstance(value, Path):
        return stack.enter_context(value.expanduser().open("rb"))
    if isinstance(value, str):
        local_path = _local_path_from_str(value)
        if local_path is not None:
            return stack.enter_context(local_path.open("rb"))
    if isinstance(value, bytes):
        image_bytes, mime_type = normalize_image_bytes(value)
        return _to_upload_buffer(image_bytes, mime_type=mime_type)
    if _is_pil_image(value):
        buffer = BytesIO()
        value.save(buffer, format="PNG")
        image_bytes, mime_type = normalize_image_bytes(buffer.getvalue())
        return _to_upload_buffer(image_bytes, mime_type=mime_type)
    return value


def _normalize_prediction_input(
    input_data: dict[str, Any],
    *,
    stack: ExitStack,
    prefer_remote_urls: bool = True,
) -> dict[str, Any]:
    normalized_input = dict(input_data)
    raw_timeout = normalized_input.get("timeout", 5.0)
    timeout_s = float(raw_timeout) if isinstance(raw_timeout, (int, float)) else 5.0

    if "image" in normalized_input:
        normalized_input["image"] = _normalize_single_image_input(
            normalized_input["image"],
            timeout_s=timeout_s,
            prefer_remote_urls=prefer_remote_urls,
            stack=stack,
        )

    images = normalized_input.get("images")
    if isinstance(images, (list, tuple)):
        normalized_input["images"] = [
            _normalize_single_image_input(
                value,
                timeout_s=timeout_s,
                prefer_remote_urls=prefer_remote_urls,
                stack=stack,
            )
            for value in images
        ]

    return normalized_input


class SingletonClientManager:
    """Thread-safe singleton pattern for shared client instances."""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls, *args: Any, **kwargs: Any) -> SingletonClientManager:
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        self._initialized = True

    @property
    def _initialized(self) -> bool:
        return getattr(self, "_init_flag", False)

    @_initialized.setter
    def _initialized(self, value: bool) -> None:
        self._init_flag = value


def run_in_thread(
    fn: Callable[..., Any],
    *args: Any,
    **kwargs: Any,
) -> tuple[queue.Queue, threading.Event]:
    """Run callable (async or sync) in background thread, return (queue, event).

    Queue contains ("success", result) or ("error", exception).
    Event is set when operation completes.
    """
    result_queue: queue.Queue = queue.Queue()
    result_event = threading.Event()

    def run() -> None:
        try:
            if asyncio.iscoroutinefunction(fn):
                result = asyncio.run(fn(*args, **kwargs))
            else:
                result = fn(*args, **kwargs)
            result_queue.put(("success", result))
        except Exception as e:
            result_queue.put(("error", e))
        finally:
            result_event.set()

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    return result_queue, result_event



def wait_optimized(
    prediction: Any,
    poll_interval: float = 0.01,
    timeout: Optional[float] = None,
) -> None:
    """Wait for prediction with early completion detection and exponential backoff."""
    start = time.time()

    # Check status immediately (no initial sleep - fast completion detection)
    if prediction.status in ["succeeded", "failed", "canceled"]:
        return

    interval = poll_interval
    while True:
        if timeout and (time.time() - start) > timeout:
            raise TimeoutError(f"Prediction wait exceeded {timeout}s")

        time.sleep(interval)
        interval = min(interval * 1.5, 0.5)  # Exponential backoff, cap at 500ms

        prediction.reload()
        if prediction.status in ["succeeded", "failed", "canceled"]:
            return


class ReplicateProvider(SingletonClientManager):
    """Singleton with connection pooling and optimized polling."""

    def __init__(self) -> None:
        super().__init__()
        if getattr(self, "_replicate_initialized", False):
            return
        api_token = os.environ.get("REPLICATE_API_TOKEN")
        if not api_token:
            raise RuntimeError("REPLICATE_API_TOKEN must be set")
        self._client = Client(api_token=api_token)
        self._deployments: dict[str, Any] = {}
        self._deployment_lock = threading.Lock()
        self._replicate_initialized = True

    def get_deployment(self, name: str) -> Any:
        """Get deployment with caching."""
        if name not in self._deployments:
            with self._deployment_lock:
                if name not in self._deployments:
                    self._deployments[name] = self._client.deployments.get(name)
        return self._deployments[name]

    def create_and_wait(
        self,
        deployment_name: str,
        input_data: dict[str, Any],
        timeout: Optional[float] = None,
        poll_interval: Optional[float] = None,
    ) -> dict[str, Any]:
        """Create prediction and wait with optimized polling.

        If poll_interval not specified, auto-tune based on input timeout.
        """
        deployment = self.get_deployment(deployment_name)
        with ExitStack() as stack:
            normalized_input_data = _normalize_prediction_input(
                input_data=input_data,
                stack=stack,
                prefer_remote_urls=True,
            )
            prediction = deployment.predictions.create(input=normalized_input_data)

            if poll_interval is None:
                input_timeout = normalized_input_data.get("timeout", 5.0)
                poll_interval = max(0.005, min(0.05, input_timeout / 10))

            wait_optimized(prediction, poll_interval=poll_interval, timeout=timeout)
            if prediction.status == "succeeded":
                return prediction.output or {}

            prediction_error = str(prediction.error or "unknown")
            should_retry_remote = _has_remote_image_input(input_data) and _looks_like_remote_fetch_error(
                prediction_error
            )
            if not should_retry_remote:
                raise RuntimeError(f"Prediction failed: {prediction_error}")

            fallback_input_data = _normalize_prediction_input(
                input_data=input_data,
                stack=stack,
                prefer_remote_urls=False,
            )
            fallback_prediction = deployment.predictions.create(input=fallback_input_data)
            wait_optimized(fallback_prediction, poll_interval=poll_interval, timeout=timeout)
            if fallback_prediction.status == "succeeded":
                return fallback_prediction.output or {}
            fallback_error = str(fallback_prediction.error or "unknown")
            raise RuntimeError(f"Prediction failed: {fallback_error}")

    def create_and_wait_deployment_thread(
        self,
        deployment_name: str,
        input_data: dict[str, Any],
        poll_interval: float = 0.05,
    ) -> tuple[queue.Queue, threading.Event]:
        """Spawn background thread for deployment prediction."""
        return run_in_thread(
            self.create_and_wait,
            deployment_name, input_data, poll_interval=poll_interval
        )



def get_replicate_provider() -> ReplicateProvider:
    """Get singleton optimized client."""
    return ReplicateProvider()
