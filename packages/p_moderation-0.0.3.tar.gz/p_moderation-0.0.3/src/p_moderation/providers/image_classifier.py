"""Local transformers image-classification moderation (allowlisted models only)."""

from __future__ import annotations

import asyncio
import uuid
from io import BytesIO
from typing import Final

from PIL import Image

from p_moderation.exceptions import (
    ModerationProviderError,
    ProviderCapabilityError,
    ProviderConfigurationError,
    ProviderDependencyError,
)
from p_moderation.image_encode import normalize_image_bytes
from p_moderation.image_url_fetch import fetch_image_url_bytes
from p_moderation.models import (
    ImageInput,
    ModerationAction,
    ProviderCategoryResult,
    ProviderItemResult,
    ProviderModerationResponse,
    ProviderPolicy,
    ProviderPrediction,
)
from p_moderation.normalize import prepare_provider_request
from p_moderation.providers.base import BaseModerationProvider
from p_moderation.providers._transformers_classifier_base import (
    TransformersClassifierProviderBase,
)
from p_moderation.providers.hf_pipeline_labels import (
    merge_class_scores,
    normalize_label_score_rows,
)

TRANSFORMERS_IMAGE_CLASSIFIER_PROVIDER_NAME: Final[str] = "transformers_image_classifier"

SUPPORTED_IMAGE_CLASSIFIER_MODEL_IDS: frozenset[str] = frozenset(
    {
        "Falconsai/nsfw_image_detection_26",
    }
)

DEFAULT_IMAGE_CLASSIFIER_MODEL_ID: Final[str] = "Falconsai/nsfw_image_detection_26"


def validate_image_classifier_model_id(model_id: str) -> None:
    """Reject unsupported Hugging Face model ids for the image-classifier path.

    Args:
        model_id: Hugging Face model id passed to ``transformers.pipeline``.

    Raises:
        ProviderConfigurationError: If ``model_id`` is not allowlisted.
    """
    if model_id not in SUPPORTED_IMAGE_CLASSIFIER_MODEL_IDS:
        supported = ", ".join(sorted(SUPPORTED_IMAGE_CLASSIFIER_MODEL_IDS))
        raise ProviderConfigurationError(
            f"Unsupported image classifier model_id {model_id!r}. Supported values: {supported}."
        )


class TransformersImageClassifierProvider(
    TransformersClassifierProviderBase,
    BaseModerationProvider,
):
    """Image-only provider backed by a local transformers image-classification pipeline."""

    name = TRANSFORMERS_IMAGE_CLASSIFIER_PROVIDER_NAME
    supports_text = False
    supports_image = True

    def __init__(
        self,
        *,
        model_id: str = DEFAULT_IMAGE_CLASSIFIER_MODEL_ID,
        hf_token: str | None = None,
        device: str | int | None = None,
        batch_size: int = 1,
    ) -> None:
        validate_image_classifier_model_id(model_id)
        super().__init__(
            task="image-classification",
            model_id=model_id,
            hf_token=hf_token,
            device=device,
            batch_size=batch_size,
            dependency_hint=(
                "TransformersImageClassifierProvider requires optional dependencies. "
                "Install them with `pip install p-moderation[transformers]`."
            ),
        )
        self._job_results: dict[str, ProviderModerationResponse] = {}

    def default_policy(self) -> ProviderPolicy:
        """Return the built-in policy for the default Falconsai NSFW classifier only.

        Returns:
            Policy mapping ``nsfw`` / ``normal`` for ``Falconsai/nsfw_image_detection_26``.

        Raises:
            ProviderConfigurationError: If ``model_id`` is not
                ``DEFAULT_IMAGE_CLASSIFIER_MODEL_ID`` — supply an explicit
                :class:`~p_moderation.models.ProviderPolicy` aligned with that model's
                ``id2label`` classes instead.
        """
        if self.model_id != DEFAULT_IMAGE_CLASSIFIER_MODEL_ID:
            raise ProviderConfigurationError(
                "TransformersImageClassifierProvider has no built-in policy for "
                f"model_id {self.model_id!r}. Pass an explicit policy= to "
                "ModerationClient (or from_image_classifier) with category_actions for "
                "your model's id2label classes (provider_name must match "
                f"{self.name!r})."
            )
        return ProviderPolicy(
            provider_name=self.name,
            category_actions={
                "nsfw": ModerationAction.BLOCK,
                "normal": ModerationAction.PASS,
            },
        )

    async def moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        request_id: str | None = None,
        client_id: str | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Execute local inference for image inputs.

        Class labels and full per-label scores are aligned with ``model.config.id2label`` on
        the loaded pipeline: every id2label value (lowercased) appears in each item's category
        results with a float score, even when the forward pass returns only a subset (e.g.
        top-k).
        """
        # Convert singular to list for prepare_provider_request
        texts = [text] if text else []
        images = [image] if image else []

        request = prepare_provider_request(
            texts=texts,
            images=images,
            request_id=request_id,
            client_id=client_id,
        )
        if any(item.input_type == "text" for item in request.items):
            raise ProviderCapabilityError(
                "TransformersImageClassifierProvider does not support text moderation."
            )
        if any(item.image_url for item in request.items):
            timeout_s = 10.0 if timeout is None else timeout
            await _materialize_remote_image_urls(request.items, timeout=timeout_s)

        try:
            pipeline, class_labels = await self._ensure_pipeline_and_labels()
            item_results = await asyncio.to_thread(
                self._infer_sync,
                request.items,
                pipeline,
                class_labels,
            )
        except (ProviderCapabilityError, ProviderDependencyError):
            raise
        except Exception as exc:
            raise ModerationProviderError(str(exc)) from exc

        return ProviderModerationResponse(
            provider_name=self.name,
            provider_response_id=None,
            model=self.model_id,
            item_results=item_results,
        )

    async def submit(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> ProviderPrediction:
        """Run local inference in the current task and return a completed prediction."""
        text, image = self._extract_first_items(texts, images)
        result = await self.moderate(
            text=text,
            image=image,
            request_id=request_id,
            client_id=client_id,
        )
        job_id = str(uuid.uuid4())
        self._get_job_results()[job_id] = result
        return ProviderPrediction(
            id=job_id,
            provider_name=self.name,
            status="completed",
            output=result,
            _provider=self,
        )

    def _infer_sync(
        self,
        items,
        pipeline,
        class_labels: frozenset[str],
    ) -> list[ProviderItemResult]:
        images = [_load_pil_image(item.image_bytes) for item in items]
        raw_predictions = pipeline(images, batch_size=self.batch_size)
        if raw_predictions and isinstance(raw_predictions[0], dict):
            raw_predictions = [raw_predictions]
        if len(raw_predictions) != len(items):
            raise ModerationProviderError(
                "Image classifier pipeline returned a different number of predictions than images."
            )

        item_results: list[ProviderItemResult] = []
        for item, prediction in zip(items, raw_predictions):
            normalized_raw = normalize_label_score_rows(prediction)
            if not normalized_raw:
                raise ModerationProviderError(
                    "Image classifier returned no prediction labels with scores."
                )
            normalized = merge_class_scores(class_labels, normalized_raw)
            top_label = max(normalized, key=normalized.get) if normalized else None
            nsfw_score = normalized.get("nsfw")
            normal_score = normalized.get("normal")
            flagged = bool(
                (nsfw_score is not None and normal_score is not None and nsfw_score >= normal_score)
                or (nsfw_score is not None and normal_score is None and top_label == "nsfw")
            )

            categories = {
                label: ProviderCategoryResult(
                    flagged=label == top_label,
                    score=score,
                    applied_input_types=[item.input_type],
                )
                for label, score in normalized.items()
            }
            item_results.append(
                ProviderItemResult(
                    item_index=item.item_index,
                    input_type=item.input_type,
                    flagged=flagged,
                    categories=categories,
                )
            )
        return item_results


def _load_pil_image(content: bytes | None) -> Image.Image:
    if content is None:
        raise ProviderCapabilityError("TransformersImageClassifierProvider requires image bytes.")
    return Image.open(BytesIO(content)).convert("RGB")


async def _materialize_remote_image_urls(items, *, timeout: float) -> None:
    for item in items:
        if item.image_url is None:
            continue
        if not item.image_url.startswith(("http://", "https://")):
            continue
        raw_bytes = await fetch_image_url_bytes(item.image_url, timeout=timeout)
        content, mime_type = normalize_image_bytes(raw_bytes)
        item.image_bytes = content
        item.mime_type = mime_type
        item.image_url = None
