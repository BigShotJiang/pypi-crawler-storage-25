"""Shared HTTP client management and connection pooling utilities."""

from __future__ import annotations

import aiohttp
import httpx


OPTIMIZED_LIMITS = httpx.Limits(
    max_connections=200,
    max_keepalive_connections=100,
    keepalive_expiry=30.0,
)

_DEFAULT_HTTP_CLIENT: httpx.AsyncClient | None = None
_DEFAULT_AIOHTTP_CLIENT: aiohttp.ClientSession | None = None


def get_default_http_client() -> httpx.AsyncClient:
    """Get or create default httpx client with optimized connection pooling."""
    global _DEFAULT_HTTP_CLIENT
    if _DEFAULT_HTTP_CLIENT is None:
        _DEFAULT_HTTP_CLIENT = httpx.AsyncClient(limits=OPTIMIZED_LIMITS)
    return _DEFAULT_HTTP_CLIENT


def get_default_aiohttp_client() -> aiohttp.ClientSession:
    """Get or create default aiohttp client with optimized connection pooling."""
    global _DEFAULT_AIOHTTP_CLIENT
    if _DEFAULT_AIOHTTP_CLIENT is None:
        connector = aiohttp.TCPConnector(
            limit=256,
            limit_per_host=128,
            ttl_dns_cache=300,
            keepalive_timeout=30,
        )
        _DEFAULT_AIOHTTP_CLIENT = aiohttp.ClientSession(connector=connector)
    return _DEFAULT_AIOHTTP_CLIENT
