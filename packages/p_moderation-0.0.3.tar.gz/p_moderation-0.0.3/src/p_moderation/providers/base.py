"""Provider base abstractions."""

from __future__ import annotations

import asyncio
import uuid
from abc import ABC, abstractmethod

from p_moderation.models import (
    ImageInput,
    ProviderModerationResponse,
    ProviderPolicy,
    ProviderPrediction,
)


class BaseModerationProvider(ABC):
    """Abstract base for moderation providers."""

    name: str = ""
    supports_text: bool = False
    supports_image: bool = False

    _job_results: dict[str, ProviderModerationResponse] | None = None
    _job_events: dict[str, asyncio.Event] | None = None
    _job_errors: dict[str, Exception] | None = None

    def _get_job_results(self) -> dict[str, ProviderModerationResponse]:
        """Lazy-initialize job results dict."""
        if self._job_results is None:
            self._job_results = {}
        return self._job_results

    def _get_job_events(self) -> dict[str, asyncio.Event]:
        if self._job_events is None:
            self._job_events = {}
        return self._job_events

    def _get_job_errors(self) -> dict[str, Exception]:
        if self._job_errors is None:
            self._job_errors = {}
        return self._job_errors

    @staticmethod
    def _extract_first_items(
        texts: list[str] | tuple[str, ...],
        images: list[ImageInput] | tuple[ImageInput, ...],
    ) -> tuple[str | None, ImageInput | None]:
        """Extract first text and image from lists."""
        return (texts[0] if texts else None, images[0] if images else None)

    @abstractmethod
    def default_policy(self) -> ProviderPolicy:
        """Return the provider's default policy mapping."""

    @abstractmethod
    async def moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        request_id: str | None = None,
        client_id: str | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Moderate content with optional text and/or image (max 1 of each)."""

    async def submit(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> ProviderPrediction:
        """Submit a moderation request and return immediately with a prediction object.

        The returned ProviderPrediction can be used to:
        - Call wait() to block until result is ready
        - Call check_status() to poll status
        - Store the ID and retrieve later with retrieve()
        """
        text, image = self._extract_first_items(texts, images)
        job_id = str(uuid.uuid4())
        self._get_job_events()[job_id] = asyncio.Event()

        asyncio.create_task(self._moderate_and_store(job_id, text, image, request_id, client_id))

        return ProviderPrediction(
            id=job_id,
            provider_name=self.name,
            status="pending",
            _provider=self,
        )

    async def _moderate_and_store(
        self,
        job_id: str,
        text: str | None,
        image: ImageInput | None,
        request_id: str | None,
        client_id: str | None,
    ) -> None:
        """Run moderation in background, store result."""
        try:
            result = await self.moderate(
                text=text,
                image=image,
                request_id=request_id,
                client_id=client_id,
            )
            self._get_job_results()[job_id] = result
        except Exception as exc:
            self._get_job_errors()[job_id] = exc
        finally:
            event = self._get_job_events().pop(job_id, None)
            if event is not None:
                event.set()

    async def retrieve(
        self,
        job_id: str,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Retrieve the result of a previously submitted moderation job.

        Args:
            job_id: The prediction ID from submit().
            timeout: Optional timeout for waiting.

        Returns:
            ProviderModerationResponse when complete.

        Raises:
            ValueError: If job_id not found.
            TimeoutError: If ``timeout`` expires before the job completes.
            Exception: If the background task raised from ``moderate()``.
        """
        results = self._get_job_results()
        if job_id in results:
            return results[job_id]
        errors = self._get_job_errors()
        if job_id in errors:
            raise errors[job_id]
        events = self._get_job_events()
        event = events.get(job_id)
        if event is None:
            raise ValueError(f"Job {job_id} not found")
        if timeout is None:
            await event.wait()
        else:
            try:
                await asyncio.wait_for(event.wait(), timeout=timeout)
            except TimeoutError as exc:
                msg = f"Job {job_id} did not complete within {timeout} seconds"
                raise TimeoutError(msg) from exc
        if job_id in results:
            return results[job_id]
        if job_id in errors:
            raise errors[job_id]
        raise RuntimeError(f"Job {job_id} finished without result or error")

    async def _check_prediction_status(self, job_id: str) -> dict:
        """Internal method for ProviderPrediction.check_status().

        Returns dict with optional keys: status, output, error
        """
        results = self._get_job_results()
        if job_id in results:
            return {"status": "completed", "output": results[job_id]}
        errors = self._get_job_errors()
        if job_id in errors:
            return {"status": "failed", "error": str(errors[job_id])}
        if job_id in self._get_job_events():
            return {"status": "pending"}
        return {"status": "pending"}

    async def aclose(self) -> None:
        """Release provider-owned resources."""

    def supports_input_type(self, input_type: str) -> bool:
        """Return whether the provider supports the requested input type."""
        if input_type == "text":
            return self.supports_text
        if input_type == "image":
            return self.supports_image
        return False
