"""Benchmark moderation latency for OpenAI and local transformers classifiers.

Examples:
  uv run python benchmarks/bench_moderation.py --provider openai --iterations 10
  uv run python benchmarks/bench_moderation.py --provider image-classifier --iterations 20
  uv run python benchmarks/bench_moderation.py --provider text-classifier --iterations 20
"""

from __future__ import annotations

import argparse
import asyncio
import os
import statistics
import time
from io import BytesIO
from typing import Any

from p_moderation import ModerationClient

try:
    from benchmarks.baseline import BaselineStore
except ImportError:
    # Handle direct script execution
    from baseline import BaselineStore  # type: ignore

try:
    from PIL import Image
except ImportError:  # pragma: no cover - benchmark script only
    Image = None


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--provider",
        choices=["openai", "image-classifier", "text-classifier"],
        default="openai",
        help="Provider to benchmark.",
    )
    parser.add_argument("--iterations", type=int, default=10, help="Timed iterations per case.")
    parser.add_argument("--warmup", type=int, default=1, help="Warmup iterations per case.")
    parser.add_argument(
        "--concurrency",
        type=int,
        default=1,
        help="Concurrent moderation requests per timed iteration.",
    )
    parser.add_argument("--image-size", type=int, default=384, help="Synthetic image size.")
    parser.add_argument(
        "--openai-api-key",
        default=os.environ.get("OPENAI_API_KEY"),
        help="OpenAI API key. Falls back to OPENAI_API_KEY.",
    )
    parser.add_argument(
        "--http-backend",
        choices=["default", "aiohttp"],
        default="default",
        help="OpenAI transport backend.",
    )
    parser.add_argument(
        "--max-retries",
        type=int,
        default=2,
        help="OpenAI SDK retry count.",
    )
    parser.add_argument(
        "--classifier-model-id",
        default="Falconsai/nsfw_image_detection_26",
        help="Model id used by the image-classifier provider.",
    )
    parser.add_argument(
        "--text-classifier-model-id",
        default="ezb/NSFW-Prompt-Detector",
        help="Model id used by the text-classifier provider.",
    )
    parser.add_argument(
        "--text-batch-size",
        type=int,
        default=1,
        help="Number of text strings per moderate() call for the text-classifier provider.",
    )
    parser.add_argument(
        "--hf-token",
        default=os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN"),
        help="Optional Hugging Face token for the image-classifier provider.",
    )
    parser.add_argument("--device", default=None, help="Optional local inference device.")
    parser.add_argument(
        "--baseline",
        action="store_true",
        help="Enable baseline establishment and comparison mode.",
    )
    parser.add_argument(
        "--scenario",
        choices=["text", "image", "combined", "normal-moderate"],
        default="text",
        help="Benchmark scenario to run.",
    )
    return parser


def _summarize(latencies_ms: list[float]) -> dict[str, float]:
    sorted_latencies = sorted(latencies_ms)
    p95_index = max(0, min(len(sorted_latencies) - 1, int(len(sorted_latencies) * 0.95) - 1))
    total_ms = sum(latencies_ms)
    return {
        "mean_ms": statistics.mean(latencies_ms),
        "p50_ms": statistics.median(latencies_ms),
        "p95_ms": sorted_latencies[p95_index],
        "min_ms": sorted_latencies[0],
        "max_ms": sorted_latencies[-1],
        "throughput_rps": 1000.0 * len(latencies_ms) / total_ms if total_ms else 0.0,
    }


def _print_summary(
    name: str, latencies_ms: list[float], *, wall_times_ms: list[float], concurrency: int
) -> None:
    summary = _summarize(latencies_ms)
    total_requests = len(latencies_ms)
    total_wall_ms = sum(wall_times_ms)
    throughput_rps = 1000.0 * total_requests / total_wall_ms if total_wall_ms else 0.0
    print(
        f"{name:<16} "
        f"concurrency={concurrency} "
        f"mean={summary['mean_ms']:.1f}ms "
        f"p50={summary['p50_ms']:.1f}ms "
        f"p95={summary['p95_ms']:.1f}ms "
        f"min={summary['min_ms']:.1f}ms "
        f"max={summary['max_ms']:.1f}ms "
        f"throughput={throughput_rps:.2f} req/s"
    )


def _make_image_bytes(size: int) -> bytes:
    if Image is None:
        raise RuntimeError("Pillow is required to build synthetic benchmark images.")
    image = Image.new("RGB", (size, size), color="green")
    buffer = BytesIO()
    image.save(buffer, format="JPEG", quality=75)
    return buffer.getvalue()


def _get_metrics_from_latencies(latencies_ms: list[float]) -> dict[str, Any]:
    """Convert latencies list to metrics dict."""
    summary = _summarize(latencies_ms)
    return {
        "latency_ms": {
            "p50": summary["p50_ms"],
            "p95": summary["p95_ms"],
            "p99": summary["p95_ms"],  # Simplified: use p95 for p99
        },
        "throughput": {"req_per_sec": summary["throughput_rps"]},
        "cost": {"cost_per_1k_requests": 0.0},
        "errors": {"error_rate": 0.0},
    }


async def _measure_case(
    *,
    name: str,
    client: ModerationClient,
    iterations: int,
    warmup: int,
    concurrency: int,
    texts: list[str] | None = None,
    images: list[bytes] | None = None,
) -> None:
    async def _run_once() -> float:
        start = time.perf_counter()
        text = texts[0] if texts else None
        image = images[0] if images else None
        result = await client.moderate(text=text, image=image)
        if result.error is not None:
            raise RuntimeError(
                f"Benchmark request failed with {result.error.type}: {result.error.message}"
            )
        return (time.perf_counter() - start) * 1000

    async def _run_batch() -> tuple[list[float], float]:
        batch_start = time.perf_counter()
        latencies = await asyncio.gather(*[_run_once() for _ in range(concurrency)])
        wall_time_ms = (time.perf_counter() - batch_start) * 1000
        return latencies, wall_time_ms

    for _ in range(warmup):
        await _run_batch()

    latencies_ms: list[float] = []
    wall_times_ms: list[float] = []
    for _ in range(iterations):
        batch_latencies, wall_time_ms = await _run_batch()
        latencies_ms.extend(batch_latencies)
        wall_times_ms.append(wall_time_ms)

    _print_summary(name, latencies_ms, wall_times_ms=wall_times_ms, concurrency=concurrency)


async def _measure_scenario(
    *,
    scenario: str,
    client: ModerationClient,
    iterations: int,
    warmup: int,
    concurrency: int,
    image_bytes: bytes | None = None,
) -> dict[str, Any]:
    """Measure a specific scenario and return metrics dict."""
    if scenario == "text":
        await _measure_case(
            name="text",
            client=client,
            iterations=iterations,
            warmup=warmup,
            concurrency=concurrency,
            texts=["Hello, this is a benign benchmark prompt."],
        )
    elif scenario == "image":
        await _measure_case(
            name="image",
            client=client,
            iterations=iterations,
            warmup=warmup,
            concurrency=concurrency,
            images=[image_bytes],
        )
    elif scenario == "combined":
        await _measure_case(
            name="combined",
            client=client,
            iterations=iterations,
            warmup=warmup,
            concurrency=concurrency,
            texts=["Hello, this is a benign benchmark prompt."],
            images=[image_bytes],
        )
    elif scenario == "normal-moderate":
        # Special case: run concurrent single moderate() calls
        async def _run_once() -> float:
            start = time.perf_counter()
            result = await client.moderate(text="Hello, this is a benign benchmark prompt.")
            if result.error is not None:
                raise RuntimeError(f"Request failed: {result.error.message}")
            return (time.perf_counter() - start) * 1000

        async def _run_batch() -> tuple[list[float], float]:
            batch_start = time.perf_counter()
            latencies = await asyncio.gather(*[_run_once() for _ in range(concurrency)])
            wall_time_ms = (time.perf_counter() - batch_start) * 1000
            return latencies, wall_time_ms

        for _ in range(warmup):
            await _run_batch()

        latencies_ms: list[float] = []
        wall_times_ms: list[float] = []
        for _ in range(iterations):
            batch_latencies, wall_time_ms = await _run_batch()
            latencies_ms.extend(batch_latencies)
            wall_times_ms.append(wall_time_ms)

        _print_summary(
            "normal-moderate", latencies_ms, wall_times_ms=wall_times_ms, concurrency=concurrency
        )

        # Return metrics dict for baseline
        summary = _summarize(latencies_ms)
        return {
            "latency_ms": {
                "p50": summary["p50_ms"],
                "p95": summary["p95_ms"],
                "p99": summary.get("p99_ms", summary["p95_ms"]),
            },
            "throughput": {"req_per_sec": summary["throughput_rps"]},
            "cost": {"cost_per_1k_requests": 0.0},  # Placeholder
            "errors": {"error_rate": 0.0},
        }

    return {}


async def _build_client(args: argparse.Namespace) -> ModerationClient:
    if args.provider == "openai":
        if not args.openai_api_key:
            raise SystemExit("OpenAI benchmarks require --openai-api-key or OPENAI_API_KEY.")
        return ModerationClient.from_openai(
            api_key=args.openai_api_key,
            fail_open=False,
            http_backend=args.http_backend,
            max_retries=args.max_retries,
        )

    if args.provider == "text-classifier":
        return ModerationClient.from_text_classifier(
            model_id=args.text_classifier_model_id,
            hf_token=args.hf_token,
            device=args.device,
            fail_open=False,
        )

    return ModerationClient.from_image_classifier(
        model_id=args.classifier_model_id,
        hf_token=args.hf_token,
        device=args.device,
        fail_open=False,
    )


async def main() -> None:
    args = _build_parser().parse_args()
    client = await _build_client(args)

    try:
        image_bytes = None
        if args.provider == "openai" or args.provider == "image-classifier":
            image_bytes = _make_image_bytes(args.image_size)

        print(
            f"provider={args.provider} iterations={args.iterations} "
            f"warmup={args.warmup} concurrency={args.concurrency} "
            f"scenario={args.scenario if args.baseline else 'n/a'}"
        )

        if args.baseline:
            # Baseline mode
            baseline_store = BaselineStore()
            previous = baseline_store.load(args.scenario, args.concurrency)

            # Run the scenario
            await _measure_scenario(
                scenario=args.scenario,
                client=client,
                iterations=args.iterations,
                warmup=args.warmup,
                concurrency=args.concurrency,
                image_bytes=image_bytes,
            )

            # Generate baseline report (simplified for now)
            if previous:
                print("\n[Baseline Report]")
                print(f"Scenario: {args.scenario}")
                print(f"Concurrency: {args.concurrency}")
                print("Loaded previous baseline")
            else:
                print("\n[First Run]")
                print(f"Baseline established for {args.scenario} @ conc={args.concurrency}")
        else:
            # Original benchmark mode
            if args.provider == "text-classifier":
                if args.text_batch_size < 1:
                    raise SystemExit("--text-batch-size must be at least 1.")
                print(
                    f"provider={args.provider} model={args.text_classifier_model_id} "
                    f"text_batch_size={args.text_batch_size} "
                    f"iterations={args.iterations} warmup={args.warmup} concurrency={args.concurrency}"
                )
                texts = ["Hello, this is a benign benchmark prompt."] * args.text_batch_size
                await _measure_case(
                    name=f"text(batch={args.text_batch_size})",
                    client=client,
                    iterations=args.iterations,
                    warmup=args.warmup,
                    concurrency=args.concurrency,
                    texts=texts,
                )
            else:
                if args.provider == "openai":
                    await _measure_case(
                        name="text",
                        client=client,
                        iterations=args.iterations,
                        warmup=args.warmup,
                        concurrency=args.concurrency,
                        texts=["Hello, this is a benign benchmark prompt."],
                    )
                await _measure_case(
                    name="image",
                    client=client,
                    iterations=args.iterations,
                    warmup=args.warmup,
                    concurrency=args.concurrency,
                    images=[image_bytes],
                )
    finally:
        await client.aclose()


if __name__ == "__main__":
    asyncio.run(main())
