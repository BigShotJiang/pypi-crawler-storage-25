"""Baseline storage and comparison for moderation benchmarks."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class BaselineStore:
    """Load and save baseline performance data."""

    def __init__(
        self,
        baseline_dir: Path | str = "benchmarks/baselines",
        provider: str = "openai",
    ) -> None:
        self.baseline_dir = Path(baseline_dir)
        self.baseline_dir.mkdir(parents=True, exist_ok=True)
        self.provider = provider

    def _validate_params(self, scenario: str, concurrency: int) -> None:
        """Validate scenario and concurrency parameters."""
        if not scenario or not isinstance(scenario, str):
            raise ValueError(f"scenario must be a non-empty string, got {scenario!r}")
        if not isinstance(concurrency, int) or concurrency <= 0:
            raise ValueError(f"concurrency must be a positive integer, got {concurrency!r}")

    def _get_filename(self, scenario: str, concurrency: int) -> Path:
        """Generate baseline filename for scenario + concurrency."""
        return self.baseline_dir / f"{self.provider}-{scenario}-conc{concurrency}.json"

    def load(self, scenario: str, concurrency: int) -> dict[str, Any] | None:
        """Load baseline from file. Return None if file doesn't exist.

        Raises:
            ValueError: If scenario or concurrency parameters are invalid.
            OSError: If file exists but cannot be read (permission denied, corruption).
            json.JSONDecodeError: If file contains invalid JSON.
        """
        self._validate_params(scenario, concurrency)
        filepath = self._get_filename(scenario, concurrency)
        if not filepath.exists():
            return None
        try:
            return json.loads(filepath.read_text())
        except json.JSONDecodeError as e:
            raise json.JSONDecodeError(
                f"Failed to parse JSON in {filepath}: {e.msg}",
                e.doc,
                e.pos,
            ) from e
        except OSError as e:
            raise OSError(f"Failed to read baseline file {filepath}: {e}") from e

    def save(self, scenario: str, concurrency: int, baseline: dict[str, Any]) -> None:
        """Save baseline to file.

        Raises:
            ValueError: If scenario or concurrency parameters are invalid.
            OSError: If file cannot be written (permission denied, disk full).
            TypeError: If baseline data contains non-JSON-serializable objects.
        """
        self._validate_params(scenario, concurrency)
        filepath = self._get_filename(scenario, concurrency)
        try:
            filepath.write_text(json.dumps(baseline, indent=2))
        except OSError as e:
            raise OSError(f"Failed to write baseline file {filepath}: {e}") from e
        except TypeError as e:
            raise TypeError(f"Baseline data contains non-JSON-serializable objects: {e}") from e


@dataclass
class ToleranceConfig:
    """Tolerance thresholds for baseline comparison."""

    latency_pct: float = 15.0  # ±15% for latency
    throughput_pct: float = 15.0  # ±15% for throughput
    cost_pct: float = 10.0  # ±10% for cost
    error_rate_pct: float = 0.0  # Any error rate > 0 fails


class BaselineComparison:
    """Compare current vs. previous baseline and detect regressions.

    Requires metric data structured with these metric groups:
    - latency_ms: Dictionary of latency metrics (e.g., {"p50": float, "p95": float})
    - throughput: Dictionary of throughput metrics (e.g., {"req_per_sec": float})
    - cost: Dictionary of cost metrics (e.g., {"cost_per_1k_requests": float})
    - errors: Dictionary of error metrics (e.g., {"error_rate": float})

    Example input format:
        {
            "metrics": {
                "latency_ms": {"p50": 100.0, "p95": 200.0},
                "throughput": {"req_per_sec": 5.0},
                "cost": {"cost_per_1k_requests": 0.06},
                "errors": {"error_rate": 0.0}
            }
        }
    """

    def __init__(
        self,
        previous: dict[str, Any],
        current: dict[str, Any],
        tolerance: ToleranceConfig | None = None,
    ) -> None:
        self.previous = previous
        self.current = current
        self.tolerance = tolerance or ToleranceConfig()

    def compute_changes(self) -> dict[str, Any]:
        """Compute % changes for all metrics."""
        changes = {}
        prev_metrics = self.previous.get("metrics", {})
        curr_metrics = self.current.get("metrics", {})

        for metric_group, prev_values in prev_metrics.items():
            changes[metric_group] = {}
            curr_values = curr_metrics.get(metric_group, {})

            for metric_name, prev_value in prev_values.items():
                curr_value = curr_values.get(metric_name, prev_value)
                if prev_value == 0:
                    # When baseline is 0, treat as 0% change (no meaningful percentage exists)
                    pct_change = 0.0
                else:
                    pct_change = ((curr_value - prev_value) / prev_value) * 100

                changes[metric_group][metric_name] = {
                    "previous": prev_value,
                    "current": curr_value,
                    "pct_change": pct_change,
                }

        return changes

    def classify_status(self) -> str:
        """Classify status as ✓ (ok), ⚠ (warning), or ✗ (failure)."""
        changes = self.compute_changes()

        # Check error rate first (any error = failure)
        if changes.get("errors", {}).get("error_rate", {}).get("current", 0) > 0:
            return "✗"

        has_warning = False

        # Check latency metrics
        for metric_name, data in changes.get("latency_ms", {}).items():
            pct = abs(data["pct_change"])
            if pct > self.tolerance.latency_pct:
                has_warning = True

        # Check throughput
        for metric_name, data in changes.get("throughput", {}).items():
            pct = abs(data["pct_change"])
            if pct > self.tolerance.throughput_pct:
                has_warning = True

        # Check cost
        for metric_name, data in changes.get("cost", {}).items():
            pct = abs(data["pct_change"])
            if pct > self.tolerance.cost_pct:
                has_warning = True

        return "⚠" if has_warning else "✓"


class ReportGenerator:
    """Generate baseline comparison reports in multiple formats."""

    def __init__(
        self,
        comparison: BaselineComparison,
        scenario: str,
        concurrency: int,
    ) -> None:
        self.comparison = comparison
        self.scenario = scenario
        self.concurrency = concurrency
        self.changes = comparison.compute_changes()
        self.status = comparison.classify_status()

    def terminal_table(self) -> str:
        """Generate formatted terminal table row."""
        lines = []
        lines.append(
            f"{'Scenario':<16} {'Concurrency':<12} {'Metric':<20} {'Current':<12} {'Previous':<12} {'Change':<10} {'Status':<6}"
        )
        lines.append("-" * 100)

        for metric_group, metrics in self.changes.items():
            for metric_name, data in metrics.items():
                lines.append(
                    f"{self.scenario:<16} {self.concurrency:<12} {metric_name:<20} "
                    f"{data['current']:<12.2f} {data['previous']:<12.2f} "
                    f"{data['pct_change']:+.1f}%{'':<6} {self.status}"
                )

        return "\n".join(lines)

    def markdown(self) -> str:
        """Generate markdown report."""
        lines = []
        lines.append(f"## {self.scenario.capitalize()} Moderation (Concurrency={self.concurrency})")
        lines.append("")
        lines.append(f"**Status:** {self.status}")
        lines.append("")
        lines.append("| Metric | Current | Previous | Change |")
        lines.append("|--------|---------|----------|--------|")

        for metric_group, metrics in self.changes.items():
            for metric_name, data in metrics.items():
                pct_str = f"{data['pct_change']:+.1f}%"
                lines.append(
                    f"| {metric_name} | {data['current']:.2f} | {data['previous']:.2f} | {pct_str} |"
                )

        return "\n".join(lines)

    def json(self) -> str:
        """Generate JSON report."""
        report = {
            "scenario": self.scenario,
            "concurrency": self.concurrency,
            "status": self.status,
            "changes": self.changes,
        }
        return json.dumps(report, indent=2)
