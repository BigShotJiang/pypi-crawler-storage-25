# p-moderation

Async moderation library for Pruna AI with a provider-based architecture.

- `OpenAIProvider` handles text + image moderation through OpenAI.
- `TransformersImageClassifierProvider` (via `ModerationClient.from_image_classifier`) handles local image moderation through `transformers`, for allowlisted `model_id` values only.
- `TransformersTextClassifierProvider` (via `ModerationClient.from_text_classifier`) handles local text classification through `transformers`, for allowlisted `model_id` values only (default: `ezb/NSFW-Prompt-Detector`).

## Install

Base package:

```bash
uv add p-moderation
# or
pip install p-moderation
```

With local `transformers` support:

```bash
pip install 'p-moderation[transformers]'
```

## Quick Start

OpenAI via the convenience constructor:

```python
import asyncio
import os

from p_moderation import ModerationClient


async def main() -> None:
    client = ModerationClient.from_openai(
        api_key=os.environ["OPENAI_API_KEY"],
        fail_open=True,
    )
    result = await client.moderate(text="Hello, this is a benign test.")
    print(result.action)  # ModerationAction.PASS
    print(result.flagged)  # False
    print(result.categories)  # {'harassment': ModerationAction.PASS, ...}
    await client.aclose()


asyncio.run(main())
```

Explicit provider injection:

```python
from p_moderation import ModerationClient, OpenAIProvider

provider = OpenAIProvider(api_key="sk-...", model="omni-moderation-latest")
client = ModerationClient(provider=provider)
```

## Provider Usage

### OpenAI

Single text and/or image per request:

```python
# Text only
result = await client.moderate(text="This is safe text")
print(result.action)  # ModerationAction.PASS
print(result.item_results[0].input_type)  # "text"

# Image only
result = await client.moderate(image="https://example.com/image.jpg")
print(result.item_results[0].input_type)  # "image"

# Text + Image combined
result = await client.moderate(
    text="User prompt",
    image=image_bytes,
)
print(result.item_results[0].input_type)  # "combined"
```

OpenAI returns provider-native categories such as `violence`, `self-harm`, and `sexual`. The response includes `category_applied_input_types` showing which input types (text/image) were evaluated for each category.

### Fast image path

If you already have bounded JPEG or PNG bytes, use `EncodedImage` to skip extra normalization work:

```python
from p_moderation import EncodedImage

encoded = EncodedImage(
    content=image_bytes,
    mime_type="image/jpeg",
)
result = await client.moderate(image=encoded)
print(result.action)  # ModerationAction.PASS
```

`EncodedImage` is an optimization path for advanced users. Regular `bytes`, `Path`, and URL strings remain the default API.

### Local image classifier

Only Hugging Face model ids in `SUPPORTED_IMAGE_CLASSIFIER_MODEL_IDS` are accepted (validated when the provider is constructed or when using `from_image_classifier`).

```python
from p_moderation import ModerationClient, ProviderPolicy

client = ModerationClient.from_image_classifier(
    model_id="Falconsai/nsfw_image_detection_26",
)

custom_policy = ProviderPolicy(
    provider_name="transformers_image_classifier",
    category_actions={
        "nsfw": "monitor",
        "normal": "pass",
    },
)
```

Use enum values rather than raw strings in real code:

```python
from p_moderation import ModerationAction, ProviderPolicy

custom_policy = ProviderPolicy(
    provider_name="transformers_image_classifier",
    category_actions={
        "nsfw": ModerationAction.MONITOR,
        "normal": ModerationAction.PASS,
    },
)

client = ModerationClient.from_image_classifier(policy=custom_policy)
result = await client.moderate(image="/path/to/image.jpg")
print(result.action)  # ModerationAction.MONITOR or ModerationAction.PASS
```

`TransformersImageClassifierProvider` is image-only. It rejects text inputs and only covers a narrow NSFW classification use case for the supported model; it is not equivalent to OpenAI's broader moderation taxonomy.

### Local text classifier

Only Hugging Face model ids in `SUPPORTED_TEXT_CLASSIFIER_MODEL_IDS` are accepted. The default model labels map to `sfw` / `nsfw` (see model `id2label` on the Hub).

```python
from p_moderation import ModerationClient

client = ModerationClient.from_text_classifier()
result = await client.moderate(text="Have a great weekend!")
print(result.action)  # ModerationAction.PASS
print(result.categories)  # {'sfw': ModerationAction.PASS, 'nsfw': ModerationAction.PASS}
```

`TransformersTextClassifierProvider` is text-only. It rejects image inputs.

## Response Format

All providers return the same `ModerationResult` with policy already applied. Serialize to JSON with configurable detail levels:

```python
result = await client.moderate(text="Hello, this is safe text")

# Minimal (~50B): action + flagged only
minimal = result.to_dict(detail="minimal")

# Balanced (~200B, recommended): action + categories
balanced = result.to_dict(detail="balanced")

# Full (~1KB): complete response with all metadata
full = result.to_dict(detail="full")
```

### Response Examples

**Minimal** (~50 bytes, for polling):
```json
{
  "success": true,
  "action": "pass",
  "flagged": false
}
```

**Balanced** (~200 bytes, **recommended** for production):
```json
{
  "success": true,
  "action": "pass",
  "flagged": false,
  "categories": {
    "harassment": "pass",
    "hate": "pass",
    "self-harm": "pass",
    "sexual": "pass",
    "violence": "pass"
  },
  "provider_response_id": "modr-8MZo6m9F5OMVdXcg3SBF6I0z"
}
```

**Full** (~1KB, for debugging):
```json
{
  "success": true,
  "provider_name": "openai",
  "model": "omni-moderation-latest",
  "action": "pass",
  "flagged": false,
  "categories": {
    "harassment": "pass",
    "hate": "pass",
    "self-harm": "pass",
    "sexual": "pass",
    "violence": "pass"
  },
  "category_scores": {
    "harassment": 0.000023,
    "hate": 0.000010,
    "self-harm": 0.000005,
    "sexual": 0.000048,
    "violence": 0.000487
  },
  "category_applied_input_types": {
    "harassment": ["text"],
    "sexual": ["text", "image"],
    "violence": ["text", "image"]
  },
  "item_results": [
    {
      "item_index": 0,
      "input_type": "text",
      "action": "pass",
      "flagged": false,
      "categories": {
        "harassment": "pass",
        "sexual": "pass",
        "violence": "pass"
      },
      "category_scores": {
        "harassment": 0.000023,
        "sexual": 0.000048,
        "violence": 0.000487
      },
      "category_applied_input_types": {
        "harassment": ["text"],
        "sexual": ["text", "image"],
        "violence": ["text", "image"]
      }
    }
  ],
  "provider_response_id": "modr-8MZo6m9F5OMVdXcg3SBF6I0z",
  "request_id": null,
  "client_id": null,
  "error": null
}
```

**Error Response** (fail-open, action=pass):
```json
{
  "success": false,
  "action": "pass",
  "flagged": false,
  "provider_response_id": null,
  "error": {
    "type": "TimeoutError",
    "message": "OpenAI API request timed out"
  }
}
```

**Balanced is recommended** for production (58% smaller than full, retains all decision transparency).

## Async Jobs: Submit and Retrieve

All providers support fire-and-forget job submission with later retrieval. This is useful when you want to submit a moderation request and do other work before checking the result.

### Quick Example

Submit a request and retrieve later:

```python
provider = OpenAIProvider(api_key="sk-...")

# Submit request
prediction = await provider.submit(text="Some text to moderate")
job_id = prediction.id

# Do other work...
await run_expensive_computation()

# Retrieve result
result = await provider.retrieve(job_id)
print(result.item_results[0].flagged)  # False
```

### Polling Status

You can check the status of a job without blocking:

```python
prediction = await provider.submit(text="Text to moderate")

# Poll for completion
while True:
    status = await prediction.check_status()
    if status == "completed":
        break
    await asyncio.sleep(1)

result = prediction.output
print(result.item_results[0].input_type)  # "text"
```

### Wait for Completion

Or use the prediction's `.wait()` method to block until done:

```python
prediction = await provider.submit(text="Text to moderate")

# Wait for result (blocks until completion)
result = await prediction.wait(timeout=30.0)
print(result.provider_response_id)  # "modr-..."
```

### Provider-Specific Behavior

- **Replicate**: Wraps real long-running predictions. Jobs are persisted on Replicate's servers.
- **OpenAI**: Returns immediately with results (synchronous). Jobs are stored in memory.
- **Transformers**: Returns immediately with results (local inference). Jobs are stored in memory.

## Batch Moderation: `moderate_many`

Process multiple items efficiently using provider-specific optimizations.

### Input Format

Each item is a dictionary with optional `text` and/or `image`:

```python
items = [
    {"text": "Check this text"},
    {"image": image_bytes},
    {"text": "With image", "image": img_bytes},
]

results = await client.moderate_many(items)
```

### Provider-Specific Strategies

**OpenAI/Replicate**: Submit-wait parallelization

- Submits up to `max_concurrency` items in parallel
- Respects API rate limits via concurrency tuning
- Best for: API-based moderation with many items

```python
client = ModerationClient.from_openai(api_key=api_key)

items = [
    {"text": f"Item {i}"} for i in range(100)
]

results = await client.moderate_many(
    items,
    max_concurrency=5,  # Tune based on rate limits
)
```

**Transformers Classifiers**: Sequential + batched pipeline

- Items processed sequentially
- Internal pipeline handles GPU batching via `batch_size`
- Best for: Local inference with many texts/images

```python
client = ModerationClient.from_text_classifier(batch_size=64)

items = [
    {"text": f"Text {i}"} for i in range(1000)
]

results = await client.moderate_many(items)
```

### Response Structure

`moderate_many` returns a list of `ModerationResult` objects in input order:

```python
results = await client.moderate_many(items)

for i, result in enumerate(results):
    print(f"Item {i}:")
    print(f"  action: {result.action}")  # ModerationAction enum
    print(f"  flagged: {result.flagged}")  # Boolean
    print(f"  input_type: {result.item_results[0].input_type}")  # "text", "image", "combined"
    print(f"  categories: {result.categories}")  # {category: action}
    print(f"  category_scores: {result.category_scores}")  # {category: float}
    if result.error:
        print(f"  error: {result.error}")
```

### Response Examples

**Text-only moderation:**

```python
result = await client.moderate(text="Have a great day!")
print(result)
# ModerationResult(
#   provider_name='openai',
#   model='omni-moderation-latest',
#   action=ModerationAction.PASS,
#   flagged=False,
#   categories={
#     'harassment': ModerationAction.PASS,
#     'hate': ModerationAction.PASS,
#     'self-harm': ModerationAction.PASS,
#     'sexual': ModerationAction.PASS,
#     'violence': ModerationAction.PASS,
#     ...
#   },
#   category_scores={
#     'harassment': 1.2e-05,
#     'hate': 9.8e-06,
#     'self-harm': 1.5e-05,
#     'sexual': 4.8e-05,
#     'violence': 4.8e-04,
#     ...
#   },
#   category_applied_input_types={
#     'harassment': ['text'],
#     'sexual': ['text'],
#     'violence': ['text'],
#     ...
#   },
#   item_results=[
#     ProviderItemResult(
#       item_index=0,
#       input_type='text',
#       flagged=False,
#       categories={...}
#     )
#   ]
# )
```

**Combined text + image:**

```python
result = await client.moderate(text="User prompt", image=image_bytes)
print(result.item_results[0].input_type)  # "combined"
print(result.category_applied_input_types['violence'])  # ['text', 'image']
# Violence category was evaluated against both text and image
```

**Batch with mixed inputs:**

```python
items = [
    {"text": "Text 1"},
    {"image": img1},
    {"text": "Text 2", "image": img2},
]

results = await client.moderate_many(items, max_concurrency=3)

# results[0].item_results[0].input_type → "text"
# results[1].item_results[0].input_type → "image"
# results[2].item_results[0].input_type → "combined"
```

**Error handling:**

```python
results = await client.moderate_many(
    items,
    fail_open=True,  # Return PASS on errors
)

for i, result in enumerate(results):
    if result.error:
        print(f"Item {i} failed: {result.error.message}")
        print(f"Error type: {result.error.type}")
    else:
        print(f"Item {i}: {result.action}")
```

### Performance Tips

- **OpenAI**: Start with `max_concurrency=5`, increase gradually while monitoring for rate limits (429 errors)
- **Transformers**: Tune `batch_size` in provider initialization (larger = faster but more VRAM needed)
- **Mixed inputs**: Combine texts and images in the same batch safely (each gets appropriate evaluation)

## Policies

Policies are provider-specific. The policy's `provider_name` must match the active provider.

```python
from p_moderation import ModerationAction, ProviderPolicy

policy = ProviderPolicy(
    provider_name="openai",
    category_actions={
        "violence": ModerationAction.BLOCK,
        "violence/graphic": ModerationAction.BLOCK,
    },
    input_type_overrides={
        "image": {"sexual": ModerationAction.BLOCK},
    },
)
```

## Failure Behavior

- `fail_open=True`: provider/runtime errors return `action=pass` with `result.error`
- `fail_open=False`: provider/runtime errors raise
- provider configuration or capability errors raise regardless of `fail_open`

## Benchmarks

General moderation latency:

```bash
uv run python benchmarks/bench_moderation.py --provider openai --iterations 10
uv run python benchmarks/bench_moderation.py --provider image-classifier --iterations 10
uv run --extra transformers python benchmarks/bench_moderation.py --provider text-classifier --iterations 10
uv run python benchmarks/bench_moderation.py --provider openai --iterations 10 --concurrency 5
uv run --extra aiohttp python benchmarks/bench_moderation.py --provider openai --iterations 10 --concurrency 5 --http-backend aiohttp
```

The moderation benchmark reports per-request latency plus aggregate throughput for the selected concurrency level.
For OpenAI, you can also compare the default SDK transport versus `aiohttp`.
See [benchmarks/README.md](benchmarks/README.md) for recorded commands and the latest captured numbers.

## Development

Install the git hooks once:

```bash
uv run --extra dev pre-commit install
```

Useful local commands:

```bash
make check
make bench-openai BENCH_ARGS='--concurrency 5'
make bench-image-classifier BENCH_ARGS='--concurrency 5'
make bench-text-classifier BENCH_ARGS='--concurrency 5'
```

## Notes

- Categories are provider-specific by design. OpenAI, image-classifier, and text-classifier labels are not normalized into one shared taxonomy.
- Migration: old `FalconsAITransformersProvider` naming was removed; use `TransformersImageClassifierProvider` or `ModerationClient.from_image_classifier(...)`.
