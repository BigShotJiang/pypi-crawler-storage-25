# Benchmarks

This directory contains scripts for measuring moderation latency.

## Commands

OpenAI moderation, default transport:

```bash
uv run python benchmarks/bench_moderation.py --provider openai --iterations 10 --warmup 1 --concurrency 5
```

OpenAI moderation, `aiohttp` transport:

```bash
uv run --extra aiohttp python benchmarks/bench_moderation.py --provider openai --iterations 10 --warmup 1 --concurrency 5 --http-backend aiohttp
```

Local image-classifier moderation:

```bash
uv run --extra transformers python benchmarks/bench_moderation.py --provider image-classifier --iterations 10 --warmup 1 --concurrency 5
```

Local text-classifier moderation (`ezb/NSFW-Prompt-Detector` by default):

```bash
uv run --extra transformers python benchmarks/bench_moderation.py --provider text-classifier --iterations 10 --warmup 1 --concurrency 5
```

## Latest Recorded Numbers

Recorded on March 30, 2026 from this machine.

### OpenAI

Command:

```bash
make bench-openai BENCH_ARGS='--iterations 10 --warmup 1 --concurrency 5'
```

Output:

```text
note: OpenAI moderation currently accepts at most one image-bearing item per request.
provider=openai iterations=10 warmup=1 concurrency=5 http_backend=default max_retries=2
text             concurrency=5 mean=430.1ms p50=348.1ms p95=1104.5ms min=199.8ms max=1489.9ms throughput=7.18 req/s
image            concurrency=5 mean=353.9ms p50=334.9ms p95=508.6ms min=222.1ms max=641.6ms throughput=10.29 req/s
```

### Image Classifier

Command:

```bash
uv run --extra transformers python benchmarks/bench_moderation.py --provider image-classifier --iterations 10 --warmup 1 --concurrency 5
```

Output:

```text
provider=image-classifier iterations=10 warmup=1 concurrency=5 http_backend=n/a max_retries=n/a
image            concurrency=5 mean=62.0ms p50=61.8ms p95=64.5ms min=59.9ms max=68.2ms throughput=79.17 req/s
```

### Text Classifier

Command:

```bash
uv run --extra transformers python benchmarks/bench_moderation.py --provider text-classifier --iterations 10 --warmup 1 --concurrency 5
```

Output:

```text
provider=text-classifier model=ezb/NSFW-Prompt-Detector text_batch_size=1 iterations=10 warmup=1 concurrency=5
text(batch=1)    concurrency=5 mean=28.3ms p50=27.7ms p95=33.4ms min=24.4ms max=34.7ms throughput=170.97 req/s
```

## Notes

- OpenAI numbers are network-dependent and vary with rate limits and backend load.
- The OpenAI path currently accepts at most one image-bearing item per request.
- Transformer classifier providers now use lock-protected lazy initialization per provider instance, so concurrent calls should not trigger duplicate model loads in one process.
