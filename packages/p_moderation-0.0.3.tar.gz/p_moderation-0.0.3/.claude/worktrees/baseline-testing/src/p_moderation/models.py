"""Shared types for provider-based moderation workflows."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Literal


InputType = Literal["text", "image", "combined"]


class ModerationAction(str, Enum):
    """Policy action returned by the library."""

    PASS = "pass"
    MONITOR = "monitor"
    BLOCK = "block"


def stronger_action(left: ModerationAction, right: ModerationAction) -> ModerationAction:
    """Return the stronger moderation action."""
    order = {
        ModerationAction.PASS: 0,
        ModerationAction.MONITOR: 1,
        ModerationAction.BLOCK: 2,
    }
    return right if order[right] > order[left] else left


def aggregate_actions(actions: list[ModerationAction]) -> ModerationAction:
    """Reduce a list of actions to the strongest one."""
    strongest = ModerationAction.PASS
    for action in actions:
        strongest = stronger_action(strongest, action)
    return strongest


@dataclass(slots=True, frozen=True)
class EncodedImage:
    """Already-normalized image bytes for the fastest moderation path."""

    content: bytes
    mime_type: str = "image/jpeg"
    source: str | None = None
    id: str | None = None


ImageInput = str | bytes | Path | EncodedImage


@dataclass(slots=True)
class ModerationRequest:
    """Convenience request wrapper for callers that want a typed payload."""

    texts: list[str] = field(default_factory=list)
    images: list[ImageInput] = field(default_factory=list)
    request_id: str | None = None
    client_id: str | None = None


@dataclass(slots=True)
class ProviderInputItem:
    """Normalized item passed to a provider implementation."""

    item_index: int
    input_type: InputType
    text: str | None = None
    image_bytes: bytes | None = None
    image_url: str | None = None
    mime_type: str | None = None
    source: str | None = None


@dataclass(slots=True)
class ProviderModerationRequest:
    """Provider-neutral moderation request."""

    items: list[ProviderInputItem] = field(default_factory=list)
    request_id: str | None = None
    client_id: str | None = None


@dataclass(slots=True)
class ProviderCategoryResult:
    """Provider-native category result."""

    flagged: bool
    score: float | None = None
    applied_input_types: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ProviderItemResult:
    """Provider-native per-item moderation result."""

    item_index: int
    input_type: InputType
    flagged: bool
    categories: dict[str, ProviderCategoryResult] = field(default_factory=dict)


@dataclass(slots=True)
class ProviderModerationResponse:
    """Provider-neutral moderation response."""

    provider_name: str
    model: str
    item_results: list[ProviderItemResult] = field(default_factory=list)
    provider_response_id: str | None = None


@dataclass(slots=True)
class ProviderPolicy:
    """Provider-specific policy mapping."""

    provider_name: str
    default_action: ModerationAction = ModerationAction.PASS
    category_actions: dict[str, ModerationAction] = field(default_factory=dict)
    input_type_overrides: dict[str, dict[str, ModerationAction]] = field(default_factory=dict)

    def get_action(self, category: str, input_type: str | None = None) -> ModerationAction:
        """Resolve the effective action for a category and optional input type."""
        if input_type is not None:
            override = self.input_type_overrides.get(input_type, {}).get(category)
            if override is not None:
                return override
        return self.category_actions.get(category, self.default_action)


@dataclass(slots=True)
class ModerationErrorInfo:
    """Error metadata returned on fail-open provider errors."""

    type: str
    message: str


@dataclass(slots=True)
class ModerationItemResult:
    """Policy-applied per-item moderation result."""

    item_index: int
    input_type: InputType
    action: ModerationAction
    flagged: bool
    categories: dict[str, ModerationAction] = field(default_factory=dict)
    category_scores: dict[str, float] = field(default_factory=dict)
    category_applied_input_types: dict[str, list[str]] = field(default_factory=dict)


@dataclass(slots=True)
class ModerationResult:
    """Aggregate moderation result returned to callers.

    The action, flagged, and categories fields always have the policy applied.
    category_scores are provider confidence scores (unchanged from provider).
    """

    provider_name: str
    model: str
    action: ModerationAction
    flagged: bool
    categories: dict[str, ModerationAction] = field(default_factory=dict)
    category_scores: dict[str, float] = field(default_factory=dict)
    category_applied_input_types: dict[str, list[str]] = field(default_factory=dict)
    item_results: list[ModerationItemResult] = field(default_factory=list)
    provider_response_id: str | None = None
    error: ModerationErrorInfo | None = None
    request_id: str | None = None
    client_id: str | None = None

    def to_dict(self, detail: str = "balanced") -> dict[str, Any]:
        """Serialize to dict with configurable detail level.

        Args:
            detail: Response detail level:
                - "minimal": action, flagged only (~50 bytes)
                - "balanced": action, flagged, categories (~200 bytes, recommended)
                - "full": complete response with all metadata (~2KB)

        Returns:
            Dict ready for JSON serialization with policy already applied.
        """

        # Helper to convert action to string value
        def action_value(action: ModerationAction | str) -> str:
            if isinstance(action, ModerationAction):
                return action.value
            return str(action)

        if detail == "minimal":
            return {
                "success": True,
                "action": action_value(self.action),
                "flagged": self.flagged,
            }
        elif detail == "balanced":
            return {
                "success": True,
                "action": action_value(self.action),
                "flagged": self.flagged,
                "categories": {
                    cat: action_value(action) for cat, action in self.categories.items()
                },
                "provider_response_id": self.provider_response_id,
            }
        elif detail == "full":
            return {
                "success": True,
                "provider_name": self.provider_name,
                "model": self.model,
                "action": action_value(self.action),
                "flagged": self.flagged,
                "categories": {
                    cat: action_value(action) for cat, action in self.categories.items()
                },
                "category_scores": self.category_scores,
                "category_applied_input_types": self.category_applied_input_types,
                "item_results": [
                    {
                        "item_index": item.item_index,
                        "input_type": item.input_type,
                        "action": action_value(item.action),
                        "flagged": item.flagged,
                        "categories": {
                            cat: action_value(action) for cat, action in item.categories.items()
                        },
                        "category_scores": item.category_scores,
                        "category_applied_input_types": item.category_applied_input_types,
                    }
                    for item in self.item_results
                ],
                "provider_response_id": self.provider_response_id,
                "request_id": self.request_id,
                "client_id": self.client_id,
                "error": asdict(self.error) if self.error else None,
            }
        else:
            raise ValueError(f"Unknown detail level: {detail}")


@dataclass(slots=True)
class ProviderPrediction:
    """Unified prediction/job object across all providers.

    Provides a consistent interface for async moderation jobs:
    - Replicate: wraps real long-running predictions
    - OpenAI/Transformers: in-memory job tracking
    """

    id: str
    provider_name: str
    status: str
    output: ProviderModerationResponse | None = None
    error: str | None = None
    _provider: object = field(default=None, repr=False, hash=False, compare=False)

    async def wait(self, timeout: float | None = None) -> ProviderModerationResponse:
        """Wait for prediction to complete and return result.

        Args:
            timeout: Maximum time to wait in seconds.

        Returns:
            ProviderModerationResponse when complete.

        Raises:
            Exception: If prediction failed or provider unavailable.
        """
        if self.output is not None:
            return self.output
        if self.error is not None:
            raise Exception(f"Prediction {self.id} failed: {self.error}")
        if self._provider is None:
            raise ValueError("Cannot wait on detached prediction")
        return await self._provider.retrieve(self.id, timeout=timeout)

    async def check_status(self) -> str:
        """Check current prediction status without blocking.

        Returns:
            Status string: "pending", "completed", or "failed".
        """
        if self._provider is None:
            return self.status
        status_obj = await self._provider._check_prediction_status(self.id)
        self.status = status_obj.get("status", self.status)
        if "output" in status_obj:
            self.output = status_obj["output"]
        if "error" in status_obj:
            self.error = status_obj["error"]
        return self.status
