"""Moderation via a Replicate *deployment* (e.g. ``prunaai/p-moderation``)."""

from __future__ import annotations

import asyncio
import json
from dataclasses import replace
from typing import Any

import replicate

from p_moderation.exceptions import (
    ModerationProviderError,
    ProviderResponseShapeError,
)
from p_moderation.image_encode import data_url_from_bytes
from p_moderation.models import (
    ImageInput,
    ProviderCategoryResult,
    ProviderItemResult,
    ProviderModerationRequest,
    ProviderModerationResponse,
    ProviderPolicy,
    ProviderPrediction,
)
from p_moderation.normalize import prepare_provider_request
from p_moderation.providers.base import BaseModerationProvider
from p_moderation.providers.openai import OpenAIProvider

REPLICATE_PROVIDER_NAME = "replicate"


def _replicate_client(api_token: str | None) -> Any:
    if api_token:
        return replicate.Client(api_token=api_token)
    return replicate.Client()


def _item_to_image_value(item) -> str:
    if item.image_url is not None:
        return item.image_url
    if item.image_bytes is not None:
        return data_url_from_bytes(
            item.image_bytes,
            mime_type=item.mime_type or "image/jpeg",
        )
    raise ModerationProviderError("Image moderation item is missing image content.")


def _build_input(
    request: ProviderModerationRequest,
    endpoint_info: str,
) -> dict[str, Any]:
    texts: list[str] = []
    images: list[str] = []
    for it in request.items:
        if it.input_type == "text" and it.text is not None:
            texts.append(it.text)
        elif it.input_type == "image":
            images.append(_item_to_image_value(it))
    return {
        "texts": texts,
        "images": images,
        "endpoint_info": endpoint_info,
    }


def _unwrap_output(raw: Any) -> dict[str, Any]:
    if raw is None:
        return {}
    if isinstance(raw, list) and len(raw) == 1 and isinstance(raw[0], dict):
        return raw[0]
    if isinstance(raw, dict):
        return raw
    raise ProviderResponseShapeError("Replicate deployment output was not a dict or list of dict.")


def _response_from_wire(
    data: dict[str, Any],
    request: ProviderModerationRequest,
    *,
    model: str,
    provider_response_id: str | None,
) -> ProviderModerationResponse:
    if data.get("success") is False and data.get("error"):
        err = data["error"]
        msg = err if isinstance(err, str) else (err.get("message") or json.dumps(err))
        raise ModerationProviderError(f"Replicate model error: {msg}")

    item_wire = data.get("item_results")
    n = len(request.items)
    if isinstance(item_wire, list) and len(item_wire) == n and n > 0:
        return ProviderModerationResponse(
            provider_name=REPLICATE_PROVIDER_NAME,
            provider_response_id=provider_response_id,
            model=str(data.get("model") or model),
            item_results=[
                _wire_item_to_provider(iw, request.items[i]) for i, iw in enumerate(item_wire)
            ],
        )
    if n == 0:
        return ProviderModerationResponse(
            provider_name=REPLICATE_PROVIDER_NAME,
            provider_response_id=provider_response_id,
            model=str(data.get("model") or model),
            item_results=[],
        )
    return _response_from_aggregate_wire(
        data, request, model=model, provider_response_id=provider_response_id
    )


def _wire_item_to_provider(w: dict[str, Any], req_item) -> ProviderItemResult:
    idx = int(w.get("item_index", req_item.item_index))
    itype: str = w.get("input_type", req_item.input_type)
    if itype not in ("text", "image"):
        itype = req_item.input_type
    scores = w.get("category_scores") or {}
    applied = w.get("category_applied_input_types") or {}
    cat_actions = w.get("categories") or {}
    categories: dict[str, ProviderCategoryResult] = {}
    for cat, score in scores.items():
        ait = list(applied.get(cat) or [])
        act = cat_actions.get(cat)
        if isinstance(act, str):
            cat_flagged = act in ("block", "monitor", "unsafe", "true", "True")
        elif act is not None:
            cat_flagged = bool(act)
        else:
            cat_flagged = float(score or 0) > 0.0
        categories[cat] = ProviderCategoryResult(
            flagged=cat_flagged,
            score=float(score) if score is not None else None,
            applied_input_types=ait,
        )
    item_flagged = w.get("flagged")
    if item_flagged is None:
        item_flagged = any(c.flagged for c in categories.values()) if categories else False
    if not categories and w.get("flagged") is not None:
        categories["unspecified"] = ProviderCategoryResult(
            flagged=bool(w["flagged"]),
            score=None,
            applied_input_types=[],
        )
    return ProviderItemResult(
        item_index=idx,
        input_type=itype,
        flagged=bool(item_flagged),
        categories=categories,
    )


def _response_from_aggregate_wire(
    data: dict[str, Any],
    request: ProviderModerationRequest,
    *,
    model: str,
    provider_response_id: str | None,
) -> ProviderModerationResponse:
    scores = data.get("category_scores") or {}
    applied = data.get("category_applied_input_types") or {}
    top_flagged = bool(data.get("flagged", False))
    item_results: list[ProviderItemResult] = []
    for i, req_item in enumerate(request.items):
        categories: dict[str, ProviderCategoryResult] = {}
        for cat, score in scores.items():
            ait = list((applied or {}).get(cat) or [])
            categories[cat] = ProviderCategoryResult(
                flagged=(float(score or 0) > 0.0) or top_flagged,
                score=float(score) if score is not None else None,
                applied_input_types=ait,
            )
        if not categories and top_flagged:
            categories["unspecified"] = ProviderCategoryResult(
                flagged=True,
                score=None,
                applied_input_types=[],
            )
        item_results.append(
            ProviderItemResult(
                item_index=i,
                input_type=req_item.input_type,
                flagged=top_flagged,
                categories=categories,
            )
        )
    return ProviderModerationResponse(
        provider_name=REPLICATE_PROVIDER_NAME,
        provider_response_id=provider_response_id,
        model=str(data.get("model") or model),
        item_results=item_results,
    )


class ReplicateDeploymentProvider(BaseModerationProvider):
    """Calls ``replicate.Client().deployments.get(name).predictions.create(...)`` then ``wait()`` .

    The deployment ``input`` includes ``texts``, ``images`` (``https`` or ``data:`` URL strings), and
    ``endpoint_info`` (e.g. JSON from
    :func:`p_moderation.providers.replicate_endpoint.endpoint_info_json_from_environment` or any
    string the deployment accepts), aligned with the same client :meth:`moderate` flow as OpenAI.
    """

    name = REPLICATE_PROVIDER_NAME
    supports_text = True
    supports_image = True

    def __init__(
        self,
        *,
        model: str = "prunaai/p-moderation",
        api_key: str | None = None,
        endpoint_info: str | None = None,
        default_timeout: float = 120.0,
    ) -> None:
        self._model = model
        self._api_key = api_key
        self._endpoint_info = endpoint_info or ""
        self._default_timeout = default_timeout

    @property
    def model(self) -> str:
        """Replicate model id (``owner/name``) passed to :meth:`replicate.Client.deployments.get`."""
        return self._model

    def default_policy(self) -> ProviderPolicy:
        return replace(
            OpenAIProvider().default_policy(),
            provider_name=self.name,
        )

    async def moderate(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        request_id: str | None = None,
        client_id: str | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        request = prepare_provider_request(
            texts=texts,
            images=images,
            request_id=request_id,
            client_id=client_id,
        )
        t = self._default_timeout if timeout is None else timeout
        payload = _build_input(request, self._endpoint_info)
        if not request.items:
            return ProviderModerationResponse(
                provider_name=self.name,
                model="",
                item_results=[],
            )
        if not payload["texts"] and not payload["images"]:
            return ProviderModerationResponse(
                provider_name=self.name,
                model="",
                item_results=[],
            )

        def _sync() -> tuple[dict[str, Any], str | None]:
            client = _replicate_client(self._api_key)
            deployment = client.deployments.get(self._model)
            prediction = deployment.predictions.create(input=payload)
            prediction.wait()
            return _unwrap_output(prediction.output), getattr(prediction, "id", None)

        data, pred_id = await asyncio.wait_for(asyncio.to_thread(_sync), timeout=t)
        return _response_from_wire(
            data,
            request,
            model=self._deployment,
            provider_response_id=pred_id,
        )

    async def submit(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> ProviderPrediction:
        """Submit a moderation request and return immediately with prediction ID."""
        request = prepare_provider_request(
            texts=texts,
            images=images,
            request_id=request_id,
            client_id=client_id,
        )
        payload = _build_input(request, self._endpoint_info)

        def _create_prediction() -> tuple[str, Any]:
            client = _replicate_client(self._api_key)
            deployment = client.deployments.get(self._model)
            prediction = deployment.predictions.create(input=payload)
            return prediction.id, prediction

        pred_id, _ = await asyncio.to_thread(_create_prediction)
        return ProviderPrediction(
            id=pred_id,
            provider_name=self.name,
            status="pending",
            _provider=self,
        )

    async def retrieve(
        self,
        job_id: str,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Retrieve the result of a submitted moderation job."""
        t = self._default_timeout if timeout is None else timeout

        def _get_prediction() -> tuple[dict[str, Any], str | None]:
            client = _replicate_client(self._api_key)
            prediction = client.predictions.get(job_id)

            if prediction.status == "failed":
                raise ModerationProviderError(f"Prediction {job_id} failed: {prediction.error}")

            prediction.wait()
            return _unwrap_output(prediction.output), job_id

        data, pred_id = await asyncio.wait_for(asyncio.to_thread(_get_prediction), timeout=t)
        # Build a minimal request for _response_from_wire
        request = ProviderModerationRequest()
        return _response_from_wire(
            data,
            request,
            model=self._model,
            provider_response_id=pred_id,
        )

    async def _check_prediction_status(self, job_id: str) -> dict:
        """Check status of a prediction without waiting."""

        def _get_status() -> str:
            client = _replicate_client(self._api_key)
            prediction = client.predictions.get(job_id)
            return prediction.status

        status = await asyncio.to_thread(_get_status)
        status_map = {
            "processing": "pending",
            "succeeded": "completed",
            "failed": "failed",
        }
        return {"status": status_map.get(status, status)}

    async def aclose(self) -> None:
        return None


__all__ = [
    "REPLICATE_PROVIDER_NAME",
    "ReplicateDeploymentProvider",
]
