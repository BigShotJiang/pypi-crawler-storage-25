"""OpenAI moderation provider.

This module calls ``AsyncOpenAI().moderations.create(model=..., input=[...])`` with the same
``input`` list shape as the OpenAI API and Python SDK: each element is either
``{"type": "text", "text": "..."}`` or
``{"type": "image_url", "image_url": {"url": "https://..."} | "data:...;base64,..."}``.
``AsyncOpenAI`` is the async counterpart to ``from openai import OpenAI``; the request
payload is identical.
"""

from __future__ import annotations

import asyncio
import uuid
from typing import Any

from openai import AsyncOpenAI, DefaultAioHttpClient

from p_moderation.exceptions import (
    ModerationProviderError,
    ProviderConfigurationError,
    ProviderResponseShapeError,
)
from p_moderation.image_encode import data_url_from_bytes
from p_moderation.models import (
    ImageInput,
    ModerationAction,
    ProviderCategoryResult,
    ProviderItemResult,
    ProviderModerationResponse,
    ProviderPolicy,
    ProviderPrediction,
)
from p_moderation.providers.base import BaseModerationProvider

OPENAI_PROVIDER_NAME = "openai"

DEFAULT_OMNI_MODERATION_MODEL = "omni-moderation-latest"


class OpenAIProvider(BaseModerationProvider):
    """Adapts :class:`ProviderModerationRequest` to OpenAI ``moderations.create`` payloads."""

    name = OPENAI_PROVIDER_NAME
    supports_text = True
    supports_image = True

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str = "omni-moderation-latest",
        default_timeout: float = 10.0,
        http_backend: str = "default",
        max_retries: int = 2,
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._base_url = base_url
        self._default_timeout = default_timeout
        self._http_backend = http_backend
        self._max_retries = max_retries
        self._client_cache: dict[str, AsyncOpenAI] = {}
        self._job_results: dict[str, ProviderModerationResponse] = {}

    def default_policy(self) -> ProviderPolicy:
        """Return the default OpenAI category policy."""
        return ProviderPolicy(
            provider_name=self.name,
            category_actions={
                "harassment": ModerationAction.MONITOR,
                "harassment/threatening": ModerationAction.BLOCK,
                "hate": ModerationAction.MONITOR,
                "hate/threatening": ModerationAction.BLOCK,
                "illicit": ModerationAction.MONITOR,
                "illicit/violent": ModerationAction.BLOCK,
                "self-harm": ModerationAction.BLOCK,
                "self-harm/intent": ModerationAction.BLOCK,
                "self-harm/instructions": ModerationAction.BLOCK,
                "sexual": ModerationAction.MONITOR,
                "sexual/minors": ModerationAction.BLOCK,
                "violence": ModerationAction.MONITOR,
                "violence/graphic": ModerationAction.BLOCK,
            },
        )

    async def moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        request_id: str | None = None,
        client_id: str | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Call ``moderations.create`` with single text and/or image.

        Returns 1 aggregated ProviderModerationResponse per request.
        """
        if not text and not image:
            raise ProviderConfigurationError("At least one of text or image must be provided.")

        if image and not str(self._model).lower().startswith("omni-moderation"):
            raise ProviderConfigurationError(
                "OpenAI image moderation requires an omni-moderation model."
            )

        payload: list[dict] = []
        if text:
            payload.append({"type": "text", "text": text})
        if image:
            payload.append(_to_openai_input_single(image))

        client = self._get_client(self._api_key)
        model = self._model
        timeout_s = self._default_timeout if timeout is None else timeout

        try:
            response = await asyncio.wait_for(
                client.moderations.create(model=model, input=payload),
                timeout=timeout_s,
            )
        except Exception as exc:
            raise ModerationProviderError(str(exc)) from exc

        results = getattr(response, "results", None) or []
        if not results:
            raise ProviderResponseShapeError("OpenAI moderation response contains no results.")

        # OpenAI returns 1 aggregated result
        raw = _coerce_raw_result(results[0])
        categories = raw.get("categories") or {}
        category_scores = raw.get("category_scores") or {}
        category_applied_input_types = raw.get("category_applied_input_types") or {}

        item_categories: dict[str, ProviderCategoryResult] = {}
        for category, flagged in categories.items():
            item_categories[category] = ProviderCategoryResult(
                flagged=bool(flagged),
                score=_coerce_score(category_scores.get(category)),
                applied_input_types=list(category_applied_input_types.get(category) or []),
            )

        # Determine input type for the result
        if text and image:
            input_type = "combined"
        elif image:
            input_type = "image"
        else:
            input_type = "text"

        item_results: list[ProviderItemResult] = [
            ProviderItemResult(
                item_index=0,
                input_type=input_type,
                flagged=bool(raw.get("flagged"))
                or any(item.flagged for item in item_categories.values()),
                categories=item_categories,
            )
        ]

        return ProviderModerationResponse(
            provider_name=self.name,
            provider_response_id=getattr(response, "id", None),
            model=getattr(response, "model", model),
            item_results=item_results,
        )

    async def submit(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> ProviderPrediction:
        """Submit a moderation request. Returns immediately since OpenAI is synchronous."""
        # Convert to single text/image for moderate() since OpenAI moderate expects 1 of each max
        text = texts[0] if texts else None
        image = images[0] if images else None

        result = await self.moderate(
            text=text,
            image=image,
            request_id=request_id,
            client_id=client_id,
        )
        job_id = str(uuid.uuid4())
        self._job_results[job_id] = result
        return ProviderPrediction(
            id=job_id,
            provider_name=self.name,
            status="completed",
            output=result,
            _provider=self,
        )

    async def retrieve(
        self,
        job_id: str,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Retrieve a previously submitted moderation job result."""
        if job_id not in self._job_results:
            raise ValueError(f"Job {job_id} not found")
        return self._job_results[job_id]

    async def _check_prediction_status(self, job_id: str) -> dict:
        """Check status of a job."""
        if job_id not in self._job_results:
            return {"status": "pending"}
        return {"status": "completed", "output": self._job_results[job_id]}

    async def aclose(self) -> None:
        """Close any AsyncOpenAI clients created by this provider."""
        for client in self._client_cache.values():
            await client.close()
        self._client_cache.clear()

    def _get_client(self, api_key: str | None) -> AsyncOpenAI:
        cache_key = api_key or ""
        if cache_key not in self._client_cache:
            kwargs: dict[str, Any] = {
                "api_key": api_key,
                "base_url": self._base_url,
                "max_retries": self._max_retries,
            }
            if self._http_backend == "aiohttp":
                kwargs["http_client"] = DefaultAioHttpClient()
            self._client_cache[cache_key] = AsyncOpenAI(**kwargs)
        return self._client_cache[cache_key]


def _to_openai_input_single(image: ImageInput) -> dict[str, Any]:
    """Convert a single ImageInput to OpenAI image_url format."""
    from p_moderation.image_encode import data_url_from_bytes
    from p_moderation.models import EncodedImage

    if isinstance(image, str):
        # String URL (https or data)
        url = image
    elif isinstance(image, bytes):
        # Raw bytes
        url = data_url_from_bytes(image, mime_type="image/jpeg")
    elif isinstance(image, EncodedImage):
        # Pre-encoded image
        url = data_url_from_bytes(image.content, mime_type=image.mime_type)
    else:
        # Assume it's a Path
        import pathlib

        path = pathlib.Path(image)
        with open(path, "rb") as f:
            url = data_url_from_bytes(f.read(), mime_type="image/jpeg")

    return {
        "type": "image_url",
        "image_url": {"url": url},
    }


def _to_openai_input(item) -> dict[str, Any]:
    """Convert a ProviderInputItem to OpenAI format (for backward compatibility)."""
    if item.input_type == "text":
        return {"type": "text", "text": item.text}

    if item.image_url is not None:
        url = item.image_url
    elif item.image_bytes is not None:
        url = data_url_from_bytes(item.image_bytes, mime_type=item.mime_type or "image/jpeg")
    else:
        raise ProviderConfigurationError("Image moderation item is missing image content.")

    return {
        "type": "image_url",
        "image_url": {"url": url},
    }


def _coerce_raw_result(result: Any) -> dict[str, Any]:
    if hasattr(result, "model_dump"):
        return result.model_dump()
    if hasattr(result, "items"):
        return dict(result)
    raise ProviderResponseShapeError(
        "OpenAI moderation result could not be converted into a mapping."
    )


def _coerce_score(value: Any) -> float | None:
    if value is None:
        return None
    return float(value)
