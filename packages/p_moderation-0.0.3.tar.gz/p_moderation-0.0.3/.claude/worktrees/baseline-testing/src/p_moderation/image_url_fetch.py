"""Download remote image bytes for moderation inputs."""

from __future__ import annotations

import asyncio
from typing import Final
from urllib.request import Request, urlopen

_USER_AGENT: Final[str] = "p-moderation/0.1"


def fetch_image_url_bytes_sync(url: str, *, timeout: float) -> bytes:
    """Download bytes from an HTTP(S) image URL.

    Args:
        url: Absolute http or https URL.
        timeout: Socket timeout in seconds.

    Returns:
        Raw response body.

    Raises:
        urllib.error.HTTPError: On non-success HTTP status.
        urllib.error.URLError: On network or URL errors.
    """
    req = Request(url, headers={"User-Agent": _USER_AGENT})
    with urlopen(req, timeout=timeout) as resp:
        return resp.read()


async def fetch_image_url_bytes(url: str, *, timeout: float) -> bytes:
    """Download image bytes without blocking the event loop.

    Args:
        url: Absolute http or https URL.
        timeout: Socket timeout in seconds.

    Returns:
        Raw response body.

    Raises:
        urllib.error.HTTPError: On non-success HTTP status.
        urllib.error.URLError: On network or URL errors.
    """
    return await asyncio.to_thread(fetch_image_url_bytes_sync, url, timeout=timeout)
