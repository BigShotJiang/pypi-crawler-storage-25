"""Provider-agnostic moderation client."""

from __future__ import annotations

import asyncio
from typing import Any

from p_moderation.exceptions import (
    ProviderCapabilityError,
    ProviderConfigurationError,
)
from p_moderation.image_encode import normalize_image_bytes
from p_moderation.image_url_fetch import fetch_image_url_bytes
from p_moderation.models import (
    ImageInput,
    ModerationAction,
    ModerationErrorInfo,
    ModerationResult,
    ProviderPolicy,
)
from p_moderation.pending import OpenAIModerationPending
from p_moderation.policy import apply_policy_from_provider_response
from p_moderation.providers.base import BaseModerationProvider
from p_moderation.providers.image_classifier import (
    DEFAULT_IMAGE_CLASSIFIER_MODEL_ID,
    TransformersImageClassifierProvider,
)
from p_moderation.providers.openai import OpenAIProvider
from p_moderation.providers.replicate import ReplicateDeploymentProvider
from p_moderation.providers.text_classifier import (
    DEFAULT_TEXT_CLASSIFIER_MODEL_ID,
    TransformersTextClassifierProvider,
)


class ModerationClient:
    """Provider-neutral moderation client."""

    def __init__(
        self,
        provider: BaseModerationProvider,
        *,
        policy: ProviderPolicy | None = None,
        fail_open: bool = True,
        default_timeout: float = 10.0,
    ) -> None:
        self._provider = provider
        self._policy = policy or provider.default_policy()
        self.fail_open = fail_open
        self.default_timeout = default_timeout
        self._validate_policy(self._policy)

    @classmethod
    def from_openai(
        cls,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str = "omni-moderation-latest",
        policy: ProviderPolicy | None = None,
        fail_open: bool = True,
        default_timeout: float = 10.0,
        http_backend: str = "default",
        max_retries: int = 2,
    ) -> "ModerationClient":
        """Construct a client backed by the OpenAI provider.

        Uses the same ``moderations.create`` ``input`` layout as the official
        ``OpenAI().moderations.create`` (``AsyncOpenAI`` in this library), including
        mixed text and ``image_url`` (https or data URL) in a single :meth:`ModerationClient.moderate` call.
        """
        provider = OpenAIProvider(
            api_key=api_key,
            base_url=base_url,
            model=model,
            default_timeout=default_timeout,
            http_backend=http_backend,
            max_retries=max_retries,
        )
        return cls(
            provider=provider,
            policy=policy,
            fail_open=fail_open,
            default_timeout=default_timeout,
        )

    @classmethod
    def from_replicate_deployment(
        cls,
        *,
        model: str = "prunaai/p-moderation",
        api_key: str | None = None,
        endpoint_info: str | None = None,
        policy: ProviderPolicy | None = None,
        fail_open: bool = True,
        default_timeout: float = 120.0,
    ) -> "ModerationClient":
        """Construct a client backed by a Replicate *deployment* (e.g. ``prunaai/p-moderation``).

        The deployment input matches the hosted Cog model: ``texts``, ``images`` (string URLs
        or data URLs), and ``endpoint_info`` (pass JSON from
        :func:`~p_moderation.providers.replicate_endpoint.endpoint_info_json_from_environment` if needed).

        For any ``deployment`` other than :data:`~p_moderation.DEFAULT_REPLICATE_DEPLOYMENT`,
        you must pass ``policy`` with ``category_actions`` for that deployment's category
        names (and ``provider_name`` set to ``replicate_deployment``).
        """
        provider = ReplicateDeploymentProvider(
            model=model,
            api_key=api_key,
            endpoint_info=endpoint_info,
            default_timeout=default_timeout,
        )
        return cls(
            provider=provider,
            policy=policy,
            fail_open=fail_open,
            default_timeout=default_timeout,
        )

    @classmethod
    def from_image_classifier(
        cls,
        *,
        model_id: str = DEFAULT_IMAGE_CLASSIFIER_MODEL_ID,
        hf_token: str | None = None,
        device: str | int | None = None,
        batch_size: int = 1,
        policy: ProviderPolicy | None = None,
        fail_open: bool = True,
        default_timeout: float = 10.0,
    ) -> "ModerationClient":
        """Construct a client backed by an allowlisted Hugging Face image-classifier model.

        For any ``model_id`` other than ``Falconsai/nsfw_image_detection_26``, you must
        pass ``policy`` with ``category_actions`` for that model's label set.
        """
        provider = TransformersImageClassifierProvider(
            model_id=model_id,
            hf_token=hf_token,
            device=device,
            batch_size=batch_size,
        )
        return cls(
            provider=provider,
            policy=policy,
            fail_open=fail_open,
            default_timeout=default_timeout,
        )

    @classmethod
    def from_text_classifier(
        cls,
        *,
        model_id: str = DEFAULT_TEXT_CLASSIFIER_MODEL_ID,
        hf_token: str | None = None,
        device: str | int | None = None,
        batch_size: int = 1,
        policy: ProviderPolicy | None = None,
        fail_open: bool = True,
        default_timeout: float = 10.0,
    ) -> "ModerationClient":
        """Construct a client backed by an allowlisted Hugging Face text-classifier model.

        For any ``model_id`` other than ``ezb/NSFW-Prompt-Detector``, you must
        pass ``policy`` with ``category_actions`` for that model's label set.
        """
        provider = TransformersTextClassifierProvider(
            model_id=model_id,
            hf_token=hf_token,
            device=device,
            batch_size=batch_size,
        )
        return cls(
            provider=provider,
            policy=policy,
            fail_open=fail_open,
            default_timeout=default_timeout,
        )

    async def __aenter__(self) -> "ModerationClient":
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Release provider-owned resources."""
        await self._provider.aclose()

    async def moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        timeout: float | None = None,
        policy: ProviderPolicy | None = None,
        fail_open: bool | None = None,
        fetch_image_urls: bool = False,
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> ModerationResult:
        """Run moderation for optional text and/or image (max 1 of each).

        Args:
            text: Single text string to moderate (optional).
            image: Single image to moderate (optional). Supports str (URL), bytes, Path, or EncodedImage.
            fetch_image_urls: If True, download http(s) image URLs to bytes before calling
                the provider. Required for providers that do not accept remote URLs.
            policy: Custom policy to apply. Uses provider's default if not specified.
            fail_open: If True, return PASS action on provider errors. Uses client default if not specified.

        Returns:
            A single ModerationResult with aggregated scores for the provided inputs.
        """
        if not text and not image:
            return ModerationResult(
                provider_name=self._provider.name,
                provider_response_id=None,
                model="",
                action=ModerationAction.PASS,
                flagged=False,
                categories={},
                category_scores={},
                category_applied_input_types={},
                item_results=[],
                request_id=request_id,
                client_id=client_id,
            )

        effective_policy = policy or self._policy
        self._validate_policy(effective_policy)

        # Validate image URL if needed
        if (
            fetch_image_urls
            and image
            and isinstance(image, str)
            and image.startswith(("http://", "https://"))
        ):
            from p_moderation.image_url_fetch import fetch_image_url_bytes
            from p_moderation.image_encode import normalize_image_bytes

            timeout_s = self.default_timeout if timeout is None else timeout
            raw_bytes = await fetch_image_url_bytes(image, timeout=timeout_s)
            content, mime_type = normalize_image_bytes(raw_bytes)
            image = content

        timeout_s = self.default_timeout if timeout is None else timeout
        current_fail_open = self.fail_open if fail_open is None else fail_open

        try:
            response = await self._provider.moderate(
                text=text,
                image=image,
                request_id=request_id,
                client_id=client_id,
                timeout=timeout_s,
            )
            # Create a minimal request object for policy application
            from p_moderation.models import ProviderModerationRequest, ProviderInputItem

            minimal_request = ProviderModerationRequest(
                items=[
                    ProviderInputItem(
                        item_index=0,
                        input_type=response.item_results[0].input_type
                        if response.item_results
                        else "text",
                        text=text,
                    )
                ]
                if response.item_results
                else [],
                request_id=request_id,
                client_id=client_id,
            )
            return apply_policy_from_provider_response(
                response,
                policy=effective_policy,
                request=minimal_request,
            )
        except (ProviderConfigurationError, ProviderCapabilityError):
            raise
        except Exception as exc:
            if not current_fail_open:
                raise
            return ModerationResult(
                provider_name=self._provider.name,
                provider_response_id=None,
                model="",
                action=ModerationAction.PASS,
                flagged=False,
                categories={},
                category_scores={},
                category_applied_input_types={},
                item_results=[],
                error=ModerationErrorInfo(
                    type=type(exc).__name__,
                    message=str(exc),
                ),
                request_id=request_id,
                client_id=client_id,
            )

    async def moderate_non_blocking(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        timeout: float | None = None,
        policy: ProviderPolicy | None = None,
        fail_open: bool | None = None,
        fetch_image_urls: bool = False,
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> OpenAIModerationPending:
        """Schedule :meth:`moderate` and return a handle; await the handle for the result.

        Supported for :class:`~p_moderation.providers.openai.OpenAIProvider` and
        :class:`~p_moderation.providers.replicate_deployment.ReplicateDeploymentProvider`
        (e.g. :meth:`from_openai`, :meth:`from_replicate_deployment`). The underlying
        call is still a single round-trip; this only defers awaiting it via
        :class:`asyncio.Task` so other coroutines can run in parallel.

        Args:
            texts: See :meth:`moderate`.
            images: See :meth:`moderate`.
            timeout: See :meth:`moderate`.
            policy: See :meth:`moderate`.
            fail_open: See :meth:`moderate`.
            fetch_image_urls: See :meth:`moderate`.
            request_id: See :meth:`moderate`.
            client_id: See :meth:`moderate`.

        Returns:
            An :class:`~p_moderation.pending.OpenAIModerationPending` to ``await`` for
            the :class:`~p_moderation.models.ModerationResult`.

        Raises:
            ProviderCapabilityError: If the client was not built with a supported provider.
        """
        if not isinstance(self._provider, (OpenAIProvider, ReplicateDeploymentProvider)):
            raise ProviderCapabilityError(
                "moderate_non_blocking is only supported for OpenAI or Replicate deployment. "
                "Build the client with ModerationClient.from_openai(...) or "
                "ModerationClient.from_replicate_deployment(...)."
            )
        coro = self.moderate(
            texts=texts,
            images=images,
            timeout=timeout,
            policy=policy,
            fail_open=fail_open,
            fetch_image_urls=fetch_image_urls,
            request_id=request_id,
            client_id=client_id,
        )
        return OpenAIModerationPending(
            _task=asyncio.create_task(coro),
            request_id=request_id,
            client_id=client_id,
        )

    async def moderate_many(
        self,
        items: list[dict[str, Any]],
        max_concurrency: int = 5,
        timeout: float | None = None,
        policy: ProviderPolicy | None = None,
        fail_open: bool | None = None,
        fetch_image_urls: bool = False,
        use_batching: bool = True,
    ) -> list[ModerationResult]:
        """Moderate multiple items using provider-optimized strategies.

        Automatically selects the best processing approach based on the provider:

        - **OpenAI/Replicate**: submit-wait parallelization with bounded concurrency
          - Each item submitted asynchronously up to max_concurrency limit
          - Ideal for API-based providers with async support
          - Results returned in input order

        - **Transformers (Text/Image Classifiers)**: batched pipeline processing
          - Items processed sequentially but internally batched by the pipeline
          - Respects the provider's batch_size parameter for efficient GPU processing
          - Falls back to sequential processing if batching unavailable

        Args:
            items: List of dicts with 'text' and/or 'image' keys (single text/image per item).
                  Example: [{"text": "hello"}, {"image": img_bytes}, {"text": "world", "image": img}]
            max_concurrency: Max concurrent requests (for OpenAI/Replicate). Default: 5.
            timeout: Per-request timeout in seconds.
            policy: Custom policy to apply.
            fail_open: If True, return PASS on provider errors.
            fetch_image_urls: If True, download http(s) image URLs to bytes before moderation.
            use_batching: If True, use batched pipeline for transformers classifiers.

        Returns:
            List of ModerationResults in the same order as input items.

        Example:
            ```python
            items = [
                {"text": "Check this text"},
                {"image": image_bytes},
                {"text": "And this", "image": another_image},
            ]
            results = await client.moderate_many(items, max_concurrency=3)
            for item, result in zip(items, results):
                print(f"{item} -> {result.action}")
            ```
        """
        if not items:
            return []

        # Use batched processing for transformers classifiers if enabled
        if use_batching and self._provider.name in (
            "transformers_text_classifier",
            "transformers_image_classifier",
        ):
            return await self._moderate_many_batched(
                items=items,
                timeout=timeout,
                policy=policy,
                fail_open=fail_open,
                fetch_image_urls=fetch_image_urls,
            )

        # Use submit-wait for OpenAI/Replicate
        if self._provider.name in ("openai", "replicate_deployment"):
            return await self._moderate_many_submit_wait(
                items=items,
                max_concurrency=max_concurrency,
                timeout=timeout,
                policy=policy,
                fail_open=fail_open,
                fetch_image_urls=fetch_image_urls,
            )

        # Fall back to sequential processing for other providers
        return await self._moderate_many_sequential(
            items=items,
            timeout=timeout,
            policy=policy,
            fail_open=fail_open,
            fetch_image_urls=fetch_image_urls,
        )

    async def _moderate_many_submit_wait(
        self,
        items: list[dict[str, Any]],
        max_concurrency: int,
        timeout: float | None,
        policy: ProviderPolicy | None,
        fail_open: bool | None,
        fetch_image_urls: bool,
    ) -> list[ModerationResult]:
        """Submit all items in parallel up to max_concurrency, then collect results.

        Used for OpenAI and Replicate providers which support async submit/retrieve pattern.
        This allows multiple items to be processed concurrently rather than sequentially,
        improving throughput for large batches.
        """
        sem = asyncio.Semaphore(max_concurrency)

        async def _moderate_one(item: dict[str, Any]) -> ModerationResult:
            async with sem:
                return await self.moderate(
                    text=item.get("text"),
                    image=item.get("image"),
                    timeout=timeout,
                    policy=policy,
                    fail_open=fail_open,
                    fetch_image_urls=item.get("fetch_image_urls", fetch_image_urls),
                    request_id=item.get("request_id"),
                    client_id=item.get("client_id"),
                )

        return await asyncio.gather(*[_moderate_one(item) for item in items])

    async def _moderate_many_sequential(
        self,
        items: list[dict[str, Any]],
        timeout: float | None,
        policy: ProviderPolicy | None,
        fail_open: bool | None,
        fetch_image_urls: bool,
    ) -> list[ModerationResult]:
        """Process items sequentially (generic fallback)."""
        results = []
        for item in items:
            result = await self.moderate(
                text=item.get("text"),
                image=item.get("image"),
                timeout=timeout,
                policy=policy,
                fail_open=fail_open,
                fetch_image_urls=item.get("fetch_image_urls", fetch_image_urls),
                request_id=item.get("request_id"),
                client_id=item.get("client_id"),
            )
            results.append(result)
        return results

    async def _moderate_many_batched(
        self,
        items: list[dict[str, Any]],
        timeout: float | None,
        policy: ProviderPolicy | None,
        fail_open: bool | None,
        fetch_image_urls: bool,
    ) -> list[ModerationResult]:
        """Process items using batched pipeline (Transformers classifiers pattern).

        For transformers classifiers, batching is handled internally by the pipeline.
        Falls back to sequential processing to respect the provider's batch_size parameter.
        """

        # Fall back to sequential if batching didn't work as expected
        return await self._moderate_many_sequential(
            items=items,
            timeout=timeout,
            policy=policy,
            fail_open=fail_open,
            fetch_image_urls=fetch_image_urls,
        )

    def _validate_policy(self, policy: ProviderPolicy) -> None:
        if policy.provider_name != self._provider.name:
            raise ProviderConfigurationError(
                f"Policy provider '{policy.provider_name}' does not match '{self._provider.name}'."
            )

    def _validate_provider_capabilities(self, request) -> None:
        for item in request.items:
            if not self._provider.supports_input_type(item.input_type):
                raise ProviderCapabilityError(
                    f"Provider '{self._provider.name}' does not support '{item.input_type}' inputs."
                )

    @staticmethod
    def error_response(
        exc: Exception,
        provider_name: str = "",
        detail: str = "balanced",
    ) -> dict[str, Any]:
        """Create a standardized error response (fail-open pass).

        Args:
            exc: The exception that occurred.
            provider_name: Provider name for context.
            detail: Detail level (minimal/balanced/full).

        Returns:
            Dict with action=pass for fail-open behavior.
        """
        if detail == "minimal":
            return {
                "success": False,
                "action": "pass",
                "flagged": False,
            }
        else:  # balanced or full
            return {
                "success": False,
                "action": "pass",
                "flagged": False,
                "provider_response_id": None,
                "error": {
                    "type": type(exc).__name__,
                    "message": str(exc),
                },
            }

    @staticmethod
    def invalid_input_response() -> dict[str, Any]:
        """Create response for invalid input (no text, no image)."""
        return {
            "success": False,
            "error": "Provide at least one of: non-empty text, image file.",
        }

    async def _materialize_remote_image_urls(
        self,
        request,
        timeout_s: float,
    ) -> None:
        for item in request.items:
            url = item.image_url
            if not url or not url.startswith(("http://", "https://")):
                continue
            raw = await fetch_image_url_bytes(url, timeout=timeout_s)
            content, mime_type = normalize_image_bytes(raw)
            item.image_bytes = content
            item.mime_type = mime_type
            item.image_url = None
