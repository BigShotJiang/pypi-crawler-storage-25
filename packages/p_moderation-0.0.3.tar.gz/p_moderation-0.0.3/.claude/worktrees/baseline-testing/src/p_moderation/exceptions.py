"""Exception hierarchy for provider-based moderation."""


class ModerationProviderError(RuntimeError):
    """Base class for provider execution errors."""


class ProviderConfigurationError(ValueError):
    """Raised for invalid provider or policy configuration."""


class ProviderCapabilityError(ValueError):
    """Raised when a provider does not support a requested input type."""


class ProviderDependencyError(ImportError):
    """Raised when an optional provider dependency is missing."""


class ProviderResponseShapeError(ModerationProviderError):
    """Raised when a provider returns an unexpected response shape."""


class ContentModerationBlockedError(ModerationProviderError):
    """Raised when upstream moderation output indicates content should be blocked."""

    def __init__(
        self,
        message: str = "content moderation blocked",
        *,
        categories: object | None = None,
    ) -> None:
        super().__init__(message)
        self.categories = categories


def raise_e005_content_moderation_error(categories: object | None) -> None:
    """Raise :class:`ContentModerationBlockedError` for a blocked moderation payload.

    Args:
        categories: Category payload from the moderation result, if any.

    Raises:
        ContentModerationBlockedError: Always.
    """
    raise ContentModerationBlockedError(categories=categories)
