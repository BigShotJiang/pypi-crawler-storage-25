"""Shared helpers for Hugging Face classification pipelines (id2label and score rows)."""

from __future__ import annotations

from typing import Any

from p_moderation.exceptions import ModerationProviderError


def normalize_label_score_rows(prediction: Any) -> dict[str, float]:
    """Turn pipeline prediction rows into a lowercased label → score map.

    Args:
        prediction: A list of ``{"label": ..., "score": ...}`` dicts, a single such dict,
            or an empty/None value.

    Returns:
        Mapping from normalized label string to float score.

    Example:
        >>> normalize_label_score_rows([{"label": "NSFW", "score": 0.9}])
        {'nsfw': 0.9}
    """
    rows = prediction
    if rows is None:
        rows = []
    elif isinstance(rows, dict):
        rows = [rows]
    normalized: dict[str, float] = {}
    for row in rows:
        label = str(row.get("label", "")).strip().lower()
        if not label:
            continue
        normalized[label] = float(row.get("score", 0.0))
    return normalized


def class_labels_from_pipeline(pipeline: Any) -> frozenset[str]:
    """Read classification label strings from a transformers pipeline's model config.

    Args:
        pipeline: A ``transformers`` classification pipeline with ``model.config.id2label``.

    Returns:
        Distinct labels from ``id2label``, each lowercased and stripped.

    Raises:
        ModerationProviderError: If the pipeline has no model/config or no usable ``id2label``.
    """
    model = getattr(pipeline, "model", None)
    if model is None:
        raise ModerationProviderError("Classification pipeline has no model; cannot read id2label.")
    config = getattr(model, "config", None)
    if config is None:
        raise ModerationProviderError("Model has no config; cannot read id2label.")
    id2label = getattr(config, "id2label", None)
    if not id2label:
        raise ModerationProviderError(
            "Model config has no id2label mapping; cannot resolve class labels."
        )

    def sort_key(key: Any) -> tuple[int, Any]:
        try:
            return (0, int(key))
        except (TypeError, ValueError):
            return (1, str(key))

    labels: list[str] = []
    seen: set[str] = set()
    for idx in sorted(id2label.keys(), key=sort_key):
        raw = id2label[idx]
        text = str(raw).strip().lower()
        if text and text not in seen:
            seen.add(text)
            labels.append(text)
    if not labels:
        raise ModerationProviderError("Model id2label contains no usable label strings.")
    return frozenset(labels)


def merge_class_scores(
    class_labels: frozenset[str], normalized: dict[str, float]
) -> dict[str, float]:
    """Ensure every configured class label has a numeric score (missing → 0.0).

    Args:
        class_labels: Label set from the loaded model's ``id2label``.
        normalized: Label → score map from the pipeline output.

    Returns:
        Full label → score map.
    """
    merged: dict[str, float] = {}
    for label in sorted(class_labels):
        merged[label] = float(normalized.get(label, 0.0))
    for label, score in normalized.items():
        if label not in merged:
            merged[label] = float(score)
    return merged
