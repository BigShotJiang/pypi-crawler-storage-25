"""Portable image encode/resize helpers for moderation input."""

from __future__ import annotations

import base64
from io import BytesIO
from pathlib import Path

from PIL import Image


def data_url_from_bytes(content: bytes, mime_type: str = "image/jpeg") -> str:
    """Wrap already-encoded image bytes in a data URL."""
    b64 = base64.b64encode(content).decode("ascii")
    return f"data:{mime_type};base64,{b64}"


def decode_data_url(data_url: str) -> tuple[bytes, str]:
    """Decode a data URL into bytes and mime type."""
    if not data_url.startswith("data:") or ";base64," not in data_url:
        raise ValueError("Expected a base64 data URL.")
    header, payload = data_url.split(",", 1)
    mime_type = header[5:].split(";", 1)[0] or "application/octet-stream"
    return base64.b64decode(payload), mime_type


def normalize_image_bytes(
    source: str | bytes | Path,
    quality: int = 60,
    max_dim: int = 384,
    format: str = "JPEG",
) -> tuple[bytes, str]:
    """Resize and encode local image inputs into a stable binary format."""
    if isinstance(source, str) and source.startswith(("http://", "https://")):
        raise ValueError("Remote image URLs cannot be normalized into local bytes.")

    if isinstance(source, bytes):
        fast_path = _normalize_raw_image_bytes(source, max_dim=max_dim)
        if fast_path is not None:
            return fast_path

    image = _load_image(source)
    image = _resize_to_max(image, max_dim)

    buffer = BytesIO()
    image.save(buffer, format=format, quality=quality, optimize=True)
    mime = "jpeg" if format.upper() == "JPEG" else format.lower()
    return buffer.getvalue(), f"image/{mime}"


def encode_image(
    source: str | bytes | Path,
    quality: int = 60,
    max_dim: int = 384,
    format: str = "JPEG",
) -> str:
    """
    Encode image to a base64 data URL with optional resize.

    Remote HTTP(S) URLs pass through unchanged for providers that support them.
    """
    if isinstance(source, str) and source.startswith(("http://", "https://", "data:")):
        return source

    content, mime_type = normalize_image_bytes(
        source,
        quality=quality,
        max_dim=max_dim,
        format=format,
    )
    return data_url_from_bytes(content, mime_type=mime_type)


def _load_image(source: str | bytes | Path) -> Image.Image:
    if isinstance(source, (str, Path)):
        if isinstance(source, str) and source.startswith("data:"):
            raw, _ = decode_data_url(source)
            return Image.open(BytesIO(raw)).convert("RGB")
        return Image.open(Path(source)).convert("RGB")
    return Image.open(BytesIO(source)).convert("RGB")


def _normalize_raw_image_bytes(source: bytes, *, max_dim: int) -> tuple[bytes, str] | None:
    """Preserve already-small JPEG/PNG payloads to avoid unnecessary re-encoding."""
    try:
        with Image.open(BytesIO(source)) as image:
            image_format = str(image.format or "").lower()
            width, height = image.size
    except Exception:
        return None
    if image_format not in {"jpeg", "png"}:
        return None
    if width > max_dim or height > max_dim:
        return None

    mime_type = "image/jpeg" if image_format == "jpeg" else "image/png"
    return source, mime_type


def _resize_to_max(img: Image.Image, max_dim: int) -> Image.Image:
    """Resize image so the longer side is at most max_dim."""
    w, h = img.size
    if w <= max_dim and h <= max_dim:
        return img
    if w >= h:
        new_w = max_dim
        new_h = int(h * max_dim / w)
    else:
        new_h = max_dim
        new_w = int(w * max_dim / h)
    return img.resize((new_w, new_h), Image.Resampling.LANCZOS)
