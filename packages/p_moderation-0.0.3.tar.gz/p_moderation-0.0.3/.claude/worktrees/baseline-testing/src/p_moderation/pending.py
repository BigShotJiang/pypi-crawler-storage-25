"""In-flight moderation handles (async :class:`asyncio.Task` wrappers for OpenAI)."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

from p_moderation.models import ModerationResult


@dataclass(slots=True)
class OpenAIModerationPending:
    """Handle for a scheduled :meth:`~p_moderation.client.ModerationClient.moderate` run.

    OpenAI's moderation API is a single request/response call; it does not expose a job id
    to poll later. This type only wraps a local :class:`asyncio.Task` so you can await the
    :class:`ModerationResult` when ready.

    Args:
        _task: Task running the same path as :meth:`~p_moderation.client.ModerationClient.moderate`.
        request_id: Optional request id passed through to the result, if any.
        client_id: Optional client id passed through to the result, if any.
    """

    _task: asyncio.Task[ModerationResult] = field(repr=False, compare=False)
    request_id: str | None = None
    client_id: str | None = None

    @property
    def task(self) -> asyncio.Task[ModerationResult]:
        return self._task

    def done(self) -> bool:
        return self._task.done()

    def cancel(self) -> bool:
        return self._task.cancel()

    async def result(self) -> ModerationResult:
        return await self._task

    def __await__(self) -> object:
        return self.result().__await__()


__all__ = ["OpenAIModerationPending"]
