"""Provider base abstractions."""

from __future__ import annotations

from abc import ABC, abstractmethod

from p_moderation.models import (
    ImageInput,
    ProviderModerationResponse,
    ProviderPolicy,
    ProviderPrediction,
)


class BaseModerationProvider(ABC):
    """Abstract base for moderation providers."""

    name: str = ""
    supports_text: bool = False
    supports_image: bool = False

    @abstractmethod
    def default_policy(self) -> ProviderPolicy:
        """Return the provider's default policy mapping."""

    @abstractmethod
    async def moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        request_id: str | None = None,
        client_id: str | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Moderate content with optional text and/or image (max 1 of each)."""

    @abstractmethod
    async def submit(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> ProviderPrediction:
        """Submit a moderation request and return immediately with a prediction object.

        The returned ProviderPrediction can be used to:
        - Call wait() to block until result is ready
        - Call check_status() to poll status
        - Store the ID and retrieve later with retrieve()
        """

    @abstractmethod
    async def retrieve(
        self,
        job_id: str,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Retrieve the result of a previously submitted moderation job.

        Args:
            job_id: The prediction ID from submit().
            timeout: Optional timeout for waiting.

        Returns:
            ProviderModerationResponse when complete.

        Raises:
            ValueError: If job_id not found.
            Exception: If prediction failed.
        """

    async def _check_prediction_status(self, job_id: str) -> dict:
        """Internal method for ProviderPrediction.check_status().

        Returns dict with optional keys: status, output, error
        """
        raise NotImplementedError("Provider does not support status checking")

    async def aclose(self) -> None:
        """Release provider-owned resources."""

    def supports_input_type(self, input_type: str) -> bool:
        """Return whether the provider supports the requested input type."""
        if input_type == "text":
            return self.supports_text
        if input_type == "image":
            return self.supports_image
        return False
