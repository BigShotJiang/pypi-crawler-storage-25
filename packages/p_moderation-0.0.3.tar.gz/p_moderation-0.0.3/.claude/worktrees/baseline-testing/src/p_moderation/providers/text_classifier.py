"""Local transformers text-classification moderation (allowlisted models only)."""

from __future__ import annotations

import asyncio
import uuid
from typing import Final

from p_moderation.exceptions import (
    ModerationProviderError,
    ProviderCapabilityError,
    ProviderConfigurationError,
    ProviderDependencyError,
)
from p_moderation.models import (
    ImageInput,
    ModerationAction,
    ProviderCategoryResult,
    ProviderInputItem,
    ProviderItemResult,
    ProviderModerationResponse,
    ProviderPolicy,
    ProviderPrediction,
)
from p_moderation.normalize import prepare_provider_request
from p_moderation.providers.base import BaseModerationProvider
from p_moderation.providers._transformers_classifier_base import (
    TransformersClassifierProviderBase,
)
from p_moderation.providers.hf_pipeline_labels import (
    merge_class_scores,
    normalize_label_score_rows,
)

TRANSFORMERS_TEXT_CLASSIFIER_PROVIDER_NAME: Final[str] = "transformers_text_classifier"

SUPPORTED_TEXT_CLASSIFIER_MODEL_IDS: frozenset[str] = frozenset(
    {
        "ezb/NSFW-Prompt-Detector",
    }
)

DEFAULT_TEXT_CLASSIFIER_MODEL_ID: Final[str] = "ezb/NSFW-Prompt-Detector"


def validate_text_classifier_model_id(model_id: str) -> None:
    """Reject unsupported Hugging Face model ids for the text-classifier path.

    Args:
        model_id: Hugging Face model id passed to ``transformers.pipeline``.

    Raises:
        ProviderConfigurationError: If ``model_id`` is not allowlisted.
    """
    if model_id not in SUPPORTED_TEXT_CLASSIFIER_MODEL_IDS:
        supported = ", ".join(sorted(SUPPORTED_TEXT_CLASSIFIER_MODEL_IDS))
        raise ProviderConfigurationError(
            f"Unsupported text classifier model_id {model_id!r}. Supported values: {supported}."
        )


class TransformersTextClassifierProvider(
    TransformersClassifierProviderBase,
    BaseModerationProvider,
):
    """Text-only provider backed by a local transformers text-classification pipeline."""

    name = TRANSFORMERS_TEXT_CLASSIFIER_PROVIDER_NAME
    supports_text = True
    supports_image = False

    def __init__(
        self,
        *,
        model_id: str = DEFAULT_TEXT_CLASSIFIER_MODEL_ID,
        hf_token: str | None = None,
        device: str | int | None = None,
        batch_size: int = 1,
    ) -> None:
        validate_text_classifier_model_id(model_id)
        super().__init__(
            task="text-classification",
            model_id=model_id,
            hf_token=hf_token,
            device=device,
            batch_size=batch_size,
            dependency_hint=(
                "TransformersTextClassifierProvider requires optional dependencies. "
                "Install them with `pip install p-moderation[transformers]`."
            ),
        )
        self._job_results: dict[str, ProviderModerationResponse] = {}

    def default_policy(self) -> ProviderPolicy:
        """Return the built-in policy for the default NSFW prompt detector only.

        Returns:
            Policy mapping ``nsfw`` / ``sfw`` for ``ezb/NSFW-Prompt-Detector``.

        Raises:
            ProviderConfigurationError: If ``model_id`` is not
                ``DEFAULT_TEXT_CLASSIFIER_MODEL_ID`` — supply an explicit
                :class:`~p_moderation.models.ProviderPolicy` aligned with that model's
                ``id2label`` classes instead.
        """
        if self.model_id != DEFAULT_TEXT_CLASSIFIER_MODEL_ID:
            raise ProviderConfigurationError(
                "TransformersTextClassifierProvider has no built-in policy for "
                f"model_id {self.model_id!r}. Pass an explicit policy= to "
                "ModerationClient (or from_text_classifier) with category_actions for "
                "your model's id2label classes (provider_name must match "
                f"{self.name!r})."
            )
        return ProviderPolicy(
            provider_name=self.name,
            category_actions={
                "nsfw": ModerationAction.BLOCK,
                "sfw": ModerationAction.PASS,
            },
        )

    async def moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        request_id: str | None = None,
        client_id: str | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Execute local inference for text inputs.

        Class labels and full per-label scores follow ``model.config.id2label`` on the
        loaded pipeline: every id2label value (lowercased) appears in each item's category
        results with a float score, even when the forward pass returns only a subset.
        """
        # Convert singular to list for prepare_provider_request
        texts = [text] if text else []
        images = [image] if image else []

        request = prepare_provider_request(
            texts=texts,
            images=images,
            request_id=request_id,
            client_id=client_id,
        )
        if any(item.input_type != "text" for item in request.items):
            raise ProviderCapabilityError(
                "TransformersTextClassifierProvider does not support image moderation."
            )

        try:
            pipeline, class_labels = await self._ensure_pipeline_and_labels()
            item_results = await asyncio.to_thread(
                self._infer_sync,
                request.items,
                pipeline,
                class_labels,
            )
        except (ProviderCapabilityError, ProviderDependencyError):
            raise
        except Exception as exc:
            raise ModerationProviderError(str(exc)) from exc

        return ProviderModerationResponse(
            provider_name=self.name,
            provider_response_id=None,
            model=self.model_id,
            item_results=item_results,
        )

    async def submit(
        self,
        *,
        texts: list[str] | tuple[str, ...] = (),
        images: list[ImageInput] | tuple[ImageInput, ...] = (),
        request_id: str | None = None,
        client_id: str | None = None,
    ) -> ProviderPrediction:
        """Submit a moderation request. Returns immediately since inference is local."""
        result = await self.moderate(
            texts=texts,
            images=images,
            request_id=request_id,
            client_id=client_id,
        )
        job_id = str(uuid.uuid4())
        self._job_results[job_id] = result
        return ProviderPrediction(
            id=job_id,
            provider_name=self.name,
            status="completed",
            output=result,
            _provider=self,
        )

    async def retrieve(
        self,
        job_id: str,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        """Retrieve a previously submitted moderation job result."""
        if job_id not in self._job_results:
            raise ValueError(f"Job {job_id} not found")
        return self._job_results[job_id]

    async def _check_prediction_status(self, job_id: str) -> dict:
        """Check status of a job."""
        if job_id not in self._job_results:
            return {"status": "pending"}
        return {"status": "completed", "output": self._job_results[job_id]}

    def _infer_sync(
        self,
        items: list[ProviderInputItem],
        pipeline,
        class_labels: frozenset[str],
    ) -> list[ProviderItemResult]:
        texts: list[str] = []
        for item in items:
            if item.text is None:
                raise ProviderCapabilityError(
                    "TransformersTextClassifierProvider requires non-null text for text items."
                )
            texts.append(item.text)

        raw_predictions = pipeline(texts, batch_size=self.batch_size)
        if isinstance(raw_predictions, dict):
            raw_predictions = [raw_predictions]
        elif (
            raw_predictions is not None
            and len(raw_predictions) > 0
            and isinstance(raw_predictions[0], dict)
        ):
            raw_predictions = [raw_predictions]
        if len(raw_predictions) != len(items):
            raise ModerationProviderError(
                "Text classifier pipeline returned a different number of predictions than texts."
            )

        item_results: list[ProviderItemResult] = []
        for item, prediction in zip(items, raw_predictions):
            normalized_raw = normalize_label_score_rows(prediction)
            if not normalized_raw:
                raise ModerationProviderError(
                    "Text classifier returned no prediction labels with scores."
                )
            normalized = merge_class_scores(class_labels, normalized_raw)
            top_label = max(normalized, key=normalized.get) if normalized else None
            nsfw_score = normalized.get("nsfw")
            sfw_score = normalized.get("sfw")
            flagged = bool(
                (nsfw_score is not None and sfw_score is not None and nsfw_score >= sfw_score)
                or (nsfw_score is not None and sfw_score is None and top_label == "nsfw")
            )

            categories = {
                label: ProviderCategoryResult(
                    flagged=label == top_label,
                    score=score,
                    applied_input_types=[item.input_type],
                )
                for label, score in normalized.items()
            }
            item_results.append(
                ProviderItemResult(
                    item_index=item.item_index,
                    input_type=item.input_type,
                    flagged=flagged,
                    categories=categories,
                )
            )
        return item_results
