"""Shared internals for local transformers classifier providers."""

from __future__ import annotations

import asyncio
import importlib
from typing import Any

from p_moderation.exceptions import ProviderDependencyError
from p_moderation.providers.hf_pipeline_labels import class_labels_from_pipeline


class TransformersClassifierProviderBase:
    """Shared lazy pipeline + label cache lifecycle for transformers classifiers."""

    def __init__(
        self,
        *,
        task: str,
        model_id: str,
        hf_token: str | None,
        device: str | int | None,
        batch_size: int,
        dependency_hint: str,
    ) -> None:
        self._task = task
        self.model_id = model_id
        self.hf_token = hf_token
        self.device = device
        self.batch_size = batch_size
        self._dependency_hint = dependency_hint
        self._pipeline: Any | None = None
        self._class_labels: frozenset[str] | None = None
        self._pipeline_lock = asyncio.Lock()

    async def _ensure_pipeline_and_labels(self) -> tuple[Any, frozenset[str]]:
        if self._pipeline is not None and self._class_labels is not None:
            return self._pipeline, self._class_labels

        async with self._pipeline_lock:
            if self._pipeline is None:
                self._pipeline = await asyncio.to_thread(self._get_pipeline)
            if self._class_labels is None:
                self._class_labels = class_labels_from_pipeline(self._pipeline)

        return self._pipeline, self._class_labels

    def _get_pipeline(self) -> Any:
        if self._pipeline is None:
            self._pipeline = self._build_pipeline()
        return self._pipeline

    def _build_pipeline(self) -> Any:
        try:
            transformers = importlib.import_module("transformers")
        except ImportError as exc:
            raise ProviderDependencyError(self._dependency_hint) from exc

        pipeline = getattr(transformers, "pipeline")
        return pipeline(
            self._task,
            model=self.model_id,
            token=self.hf_token,
            device=self.device,
            top_k=None,
        )
