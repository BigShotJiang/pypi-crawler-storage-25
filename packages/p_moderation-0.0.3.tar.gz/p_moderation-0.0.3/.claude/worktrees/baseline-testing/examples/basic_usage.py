"""Example: provider-based moderation usage.

Run: uv run python examples/basic_usage.py
Requires: OPENAI_API_KEY
"""

from __future__ import annotations

import asyncio
import os

from p_moderation import (
    ModerationAction,
    ModerationClient,
    OpenAIProvider,
    ProviderPolicy,
)


async def main() -> None:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("Set OPENAI_API_KEY to run this example.")
        return

    print("1. OpenAI convenience constructor")
    async with ModerationClient.from_openai(api_key=api_key, fail_open=True) as client:
        result = await client.moderate(texts=["Hello, this is a benign test message."])
        print(f"   action={result.action} categories={result.categories}\n")

    print("2. Explicit provider injection")
    provider = OpenAIProvider(api_key=api_key, model="omni-moderation-latest")
    policy = ProviderPolicy(
        provider_name="openai",
        category_actions={
            "harassment": ModerationAction.MONITOR,
            "harassment/threatening": ModerationAction.BLOCK,
            "hate": ModerationAction.MONITOR,
            "hate/threatening": ModerationAction.BLOCK,
            "illicit": ModerationAction.MONITOR,
            "illicit/violent": ModerationAction.BLOCK,
            "self-harm": ModerationAction.BLOCK,
            "self-harm/intent": ModerationAction.BLOCK,
            "self-harm/instructions": ModerationAction.BLOCK,
            "sexual": ModerationAction.MONITOR,
            "sexual/minors": ModerationAction.BLOCK,
            "violence": ModerationAction.MONITOR,
            "violence/graphic": ModerationAction.BLOCK,
        },
        input_type_overrides={
            "image": {"sexual": ModerationAction.BLOCK},
        },
    )
    client = ModerationClient(provider=provider, policy=policy)
    result = await client.moderate(texts=["Another safe prompt"])
    print(f"   action={result.action} categories={result.categories}\n")

    print("3. Batch moderation")
    results = await client.moderate_many(
        [
            {"texts": ["A friendly greeting"]},
            {"texts": ["Another safe prompt"]},
        ]
    )
    for index, item_result in enumerate(results):
        print(f"   item {index}: action={item_result.action}")

    print("\n4. Generic image-classifier constructor")
    print("   client = ModerationClient.from_image_classifier()")
    print("   result = await client.moderate(images=['/path/to/image.jpg'])")

    print("\n5. EncodedImage fast path")
    print("   encoded = EncodedImage(content=image_bytes, mime_type='image/jpeg')")
    print("   result = await client.moderate(images=[encoded])")

    await client.aclose()


if __name__ == "__main__":
    asyncio.run(main())
