"""Example: local text NSFW classification with Hugging Face transformers.

Run: uv run python examples/text_classifier_usage.py
Requires: ``uv sync --extra transformers`` (see pyproject optional-deps).

Equivalent low-level Hugging Face usage::

    from transformers import pipeline
    pipe = pipeline("text-classification", model="ezb/NSFW-Prompt-Detector")
    pipe("Have a great weekend!")
"""

from __future__ import annotations

import asyncio

from p_moderation import ModerationClient


async def main() -> None:
    async with ModerationClient.from_text_classifier() as client:
        safe = await client.moderate(texts=["Have a great weekend! See you next week!"])
        print(
            f"safe example: action={safe.action} flagged={safe.flagged} scores={safe.category_scores}"
        )


if __name__ == "__main__":
    asyncio.run(main())
