"""Tests for the transformers text-classifier provider."""

from __future__ import annotations

import asyncio
import types
from unittest.mock import patch

import pytest

from p_moderation import ModerationAction, ModerationClient, ProviderPolicy
from p_moderation.exceptions import (
    ModerationProviderError,
    ProviderCapabilityError,
    ProviderConfigurationError,
    ProviderDependencyError,
)
from p_moderation.normalize import prepare_provider_request
from p_moderation.providers.hf_pipeline_labels import class_labels_from_pipeline
from p_moderation.providers.text_classifier import (
    DEFAULT_TEXT_CLASSIFIER_MODEL_ID,
    TransformersTextClassifierProvider,
    validate_text_classifier_model_id,
)


def _fake_text_pipeline(
    id2label: dict[int, str],
    predict_fn,
):
    """Callable fake matching transformers text-classification pipeline shape."""

    def fake_pipeline(texts, batch_size: int = 1):  # noqa: ARG001
        return predict_fn(texts, batch_size)

    fake_pipeline.model = types.SimpleNamespace(config=types.SimpleNamespace(id2label=id2label))
    return fake_pipeline


def test_validate_text_classifier_model_id_rejects_unknown() -> None:
    with pytest.raises(ProviderConfigurationError, match="Unsupported text classifier model_id"):
        validate_text_classifier_model_id("unknown/model")


def test_transformers_text_classifier_provider_rejects_unlisted_model() -> None:
    with pytest.raises(ProviderConfigurationError, match="Unsupported text classifier model_id"):
        TransformersTextClassifierProvider(model_id="other/model")


@pytest.mark.asyncio
async def test_text_classifier_provider_rejects_image_inputs() -> None:
    provider = TransformersTextClassifierProvider()
    request = prepare_provider_request(texts=["a"], images=["https://example.com/x.png"])

    with pytest.raises(ProviderCapabilityError, match="does not support image moderation"):
        await provider.moderate(request)


@pytest.mark.asyncio
async def test_text_classifier_provider_uses_default_model_id() -> None:
    provider = TransformersTextClassifierProvider()

    assert provider.model_id == DEFAULT_TEXT_CLASSIFIER_MODEL_ID


def test_text_classifier_constructor_builds_default_provider() -> None:
    client = ModerationClient.from_text_classifier()

    assert isinstance(client._provider, TransformersTextClassifierProvider)


@pytest.mark.asyncio
async def test_text_classifier_provider_rejects_missing_dependency() -> None:
    provider = TransformersTextClassifierProvider()
    request = prepare_provider_request(texts=["hello"])

    with patch(
        "p_moderation.providers._transformers_classifier_base.importlib.import_module",
        side_effect=ImportError,
    ):
        with pytest.raises(ProviderDependencyError, match="p-moderation\\[transformers\\]"):
            await provider.moderate(request)


@pytest.mark.asyncio
async def test_text_classifier_provider_accepts_multiple_texts() -> None:
    provider = TransformersTextClassifierProvider()

    def predict(texts, batch_size: int = 1):  # noqa: ARG001
        assert len(texts) == 2
        return [
            [
                {"label": "NSFW", "score": 0.9},
                {"label": "SFW", "score": 0.1},
            ],
            [
                {"label": "SFW", "score": 0.8},
                {"label": "NSFW", "score": 0.2},
            ],
        ]

    fake = _fake_text_pipeline({0: "SFW", 1: "NSFW"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    request = prepare_provider_request(texts=["bad", "good"])
    response = await provider.moderate(request)

    assert response.provider_name == "transformers_text_classifier"
    assert response.item_results[0].flagged is True
    assert response.item_results[0].categories["nsfw"].score == 0.9
    assert response.item_results[1].input_type == "text"
    assert response.item_results[1].flagged is False


@pytest.mark.asyncio
async def test_text_classifier_client_respects_custom_policy() -> None:
    provider = TransformersTextClassifierProvider()

    def predict(texts, batch_size: int = 1):  # noqa: ARG001
        return [[{"label": "NSFW", "score": 0.95}, {"label": "SFW", "score": 0.05}]]

    fake = _fake_text_pipeline({0: "SFW", 1: "NSFW"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    client = ModerationClient(
        provider=provider,
        policy=ProviderPolicy(
            provider_name="transformers_text_classifier",
            category_actions={
                "nsfw": ModerationAction.MONITOR,
                "sfw": ModerationAction.PASS,
            },
        ),
    )

    result = await client.moderate(texts=["x"])

    assert result.action == ModerationAction.MONITOR


@pytest.mark.asyncio
async def test_text_classifier_fills_missing_class_scores() -> None:
    provider = TransformersTextClassifierProvider()

    def predict(texts, batch_size: int = 1):  # noqa: ARG001
        return [[{"label": "NSFW", "score": 0.4}]]

    fake = _fake_text_pipeline({0: "SFW", 1: "NSFW"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    request = prepare_provider_request(texts=["x"])
    response = await provider.moderate(request)

    assert response.item_results[0].categories["nsfw"].score == 0.4
    assert response.item_results[0].categories["sfw"].score == 0.0


@pytest.mark.asyncio
async def test_text_classifier_rejects_empty_prediction() -> None:
    provider = TransformersTextClassifierProvider()

    def predict(texts, batch_size: int = 1):  # noqa: ARG001
        return [[]]

    fake = _fake_text_pipeline({0: "SFW", 1: "NSFW"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    request = prepare_provider_request(texts=["x"])

    with pytest.raises(ModerationProviderError, match="no prediction labels"):
        await provider.moderate(request)


@pytest.mark.asyncio
async def test_text_classifier_wraps_single_dict_batch_output() -> None:
    """When the pipeline returns one list of dicts for a single text, normalize like batch."""
    provider = TransformersTextClassifierProvider()

    def predict(texts, batch_size: int = 1):  # noqa: ARG001
        return [
            {"label": "SFW", "score": 0.99},
            {"label": "NSFW", "score": 0.01},
        ]

    fake = _fake_text_pipeline({0: "SFW", 1: "NSFW"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    request = prepare_provider_request(texts=["hello"])
    response = await provider.moderate(request)

    assert response.item_results[0].flagged is False


@pytest.mark.asyncio
async def test_text_classifier_wraps_top_level_single_dict() -> None:
    """When the pipeline returns one dict (top-1 style), wrap to one item."""
    provider = TransformersTextClassifierProvider()

    def predict(texts, batch_size: int = 1):  # noqa: ARG001
        return {"label": "NSFW", "score": 0.77}

    fake = _fake_text_pipeline({0: "SFW", 1: "NSFW"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    request = prepare_provider_request(texts=["x"])
    response = await provider.moderate(request)

    assert response.item_results[0].flagged is True
    assert response.item_results[0].categories["nsfw"].score == 0.77


def test_non_default_text_model_requires_explicit_policy_for_default_policy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import p_moderation.providers.text_classifier as tc

    other = "org/other_text_classifier"
    monkeypatch.setattr(
        tc,
        "SUPPORTED_TEXT_CLASSIFIER_MODEL_IDS",
        frozenset({DEFAULT_TEXT_CLASSIFIER_MODEL_ID, other}),
    )
    provider = TransformersTextClassifierProvider(model_id=other)
    with pytest.raises(ProviderConfigurationError, match="explicit policy"):
        provider.default_policy()


@pytest.mark.asyncio
async def test_non_default_text_model_client_requires_explicit_policy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import p_moderation.providers.text_classifier as tc

    other = "org/other_text_classifier"
    monkeypatch.setattr(
        tc,
        "SUPPORTED_TEXT_CLASSIFIER_MODEL_IDS",
        frozenset({DEFAULT_TEXT_CLASSIFIER_MODEL_ID, other}),
    )
    with pytest.raises(ProviderConfigurationError, match="explicit policy"):
        ModerationClient.from_text_classifier(model_id=other)


def test_class_labels_from_pipeline_reads_id2label_text_stub() -> None:
    def predict(texts, batch_size: int = 1):  # noqa: ARG001
        return [[]]

    fake = _fake_text_pipeline({1: "NSFW", 0: "SFW"}, predict)
    labels = class_labels_from_pipeline(fake)
    assert labels == frozenset({"nsfw", "sfw"})


@pytest.mark.asyncio
async def test_text_classifier_pipeline_initialized_once_under_concurrency() -> None:
    provider = TransformersTextClassifierProvider()
    init_calls = 0

    def build_pipeline():
        nonlocal init_calls
        init_calls += 1
        return _fake_text_pipeline(
            {0: "SFW", 1: "NSFW"},
            lambda texts, batch_size=1: [
                [{"label": "SFW", "score": 0.9}, {"label": "NSFW", "score": 0.1}] for _ in texts
            ],
        )

    provider._build_pipeline = build_pipeline  # type: ignore[method-assign]

    async def call_once() -> None:
        await provider.moderate(prepare_provider_request(texts=["hello"]))

    await asyncio.gather(*(call_once() for _ in range(8)))
    assert init_calls == 1
