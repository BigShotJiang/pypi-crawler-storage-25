"""Tests for p_moderation.image_encode."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path
from unittest.mock import patch

from PIL import Image

from p_moderation.image_encode import decode_data_url, encode_image, normalize_image_bytes


def test_encode_image_url_passthrough() -> None:
    """HTTP and data URLs should pass through unchanged."""
    assert encode_image("https://example.com/img.png") == "https://example.com/img.png"
    assert encode_image("data:image/png;base64,abc") == "data:image/png;base64,abc"


def test_encode_image_bytes_resizes_and_decodes() -> None:
    """Local bytes should be normalized into a bounded JPEG data URL."""
    image = Image.new("RGB", (800, 600), color="red")
    buffer = BytesIO()
    image.save(buffer, format="JPEG")

    data_url = encode_image(buffer.getvalue(), max_dim=100)
    decoded, mime_type = decode_data_url(data_url)

    assert mime_type == "image/jpeg"
    out = Image.open(BytesIO(decoded))
    assert max(out.size) <= 100


def test_normalize_image_bytes_from_path(tmp_path: Path) -> None:
    """Path-based inputs should normalize into stable JPEG bytes."""
    image = Image.new("RGB", (120, 80), color="blue")
    path = tmp_path / "test.png"
    image.save(path, format="PNG")

    content, mime_type = normalize_image_bytes(path, max_dim=64)

    assert mime_type == "image/jpeg"
    out = Image.open(BytesIO(content))
    assert max(out.size) <= 64


def test_normalize_image_bytes_preserves_small_jpeg() -> None:
    """Already-small JPEG bytes should not be re-encoded."""
    image = Image.new("RGB", (32, 32), color="green")
    buffer = BytesIO()
    image.save(buffer, format="JPEG")
    raw = buffer.getvalue()

    with patch("p_moderation.image_encode._load_image") as mock_load:
        content, mime_type = normalize_image_bytes(raw, max_dim=64)

    assert content == raw
    assert mime_type == "image/jpeg"
    mock_load.assert_not_called()
