"""Tests for the provider-neutral moderation client."""

from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from PIL import Image

from p_moderation import (
    ModerationAction,
    ModerationClient,
    OpenAIProvider,
    OpenAIModerationPending,
    ProviderPolicy,
)
from p_moderation.exceptions import ProviderCapabilityError, ProviderConfigurationError
from p_moderation.models import (
    ProviderCategoryResult,
    ProviderItemResult,
    ProviderModerationRequest,
    ProviderModerationResponse,
)
from p_moderation.providers.base import BaseModerationProvider


@dataclass
class FakeProvider(BaseModerationProvider):
    """Small fake provider for client tests."""

    name: str = "fake"
    supports_text: bool = True
    supports_image: bool = True
    response: ProviderModerationResponse | None = None
    error: Exception | None = None

    def __post_init__(self) -> None:
        self.requests: list[tuple[ProviderModerationRequest, float | None]] = []

    def default_policy(self) -> ProviderPolicy:
        return ProviderPolicy(
            provider_name=self.name,
            category_actions={"review": ModerationAction.MONITOR},
        )

    async def moderate(
        self,
        request: ProviderModerationRequest,
        *,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        self.requests.append((request, timeout))
        if self.error is not None:
            raise self.error
        if self.response is not None:
            return self.response
        return ProviderModerationResponse(
            provider_name=self.name,
            provider_response_id="fake-1",
            model="fake-model",
            item_results=[
                ProviderItemResult(
                    item_index=item.item_index,
                    input_type=item.input_type,
                    flagged=False,
                    categories={},
                )
                for item in request.items
            ],
        )


def _jpeg_bytes() -> bytes:
    image = Image.new("RGB", (8, 8), color="blue")
    buffer = BytesIO()
    image.save(buffer, format="JPEG")
    return buffer.getvalue()


@pytest.mark.asyncio
async def test_fetch_image_urls_downloads_before_provider() -> None:
    """Remote http(s) strings should become bytes when fetch_image_urls is set."""
    provider = FakeProvider()
    client = ModerationClient(provider=provider)
    url = "https://example.com/a.jpg"
    jpeg = _jpeg_bytes()

    with patch(
        "p_moderation.client.fetch_image_url_bytes",
        new_callable=AsyncMock,
        return_value=jpeg,
    ) as mock_fetch:
        await client.moderate(images=[url], fetch_image_urls=True)

    mock_fetch.assert_awaited_once_with(url, timeout=10.0)
    sent = provider.requests[0][0]
    assert len(sent.items) == 1
    assert sent.items[0].image_url is None
    assert sent.items[0].image_bytes is not None
    assert sent.items[0].mime_type == "image/jpeg"


@pytest.mark.asyncio
async def test_moderate_empty_input_skips_provider() -> None:
    """Empty input should short-circuit without calling the provider."""
    provider = FakeProvider()
    client = ModerationClient(provider=provider)

    result = await client.moderate()

    assert result.action == ModerationAction.PASS
    assert result.provider_name == "fake"
    assert result.item_results == []
    assert provider.requests == []


@pytest.mark.asyncio
async def test_moderate_applies_provider_policy() -> None:
    """Provider-native categories should be mapped through the configured policy."""
    provider = FakeProvider(
        response=ProviderModerationResponse(
            provider_name="fake",
            provider_response_id="resp-1",
            model="fake-model",
            item_results=[
                ProviderItemResult(
                    item_index=0,
                    input_type="text",
                    flagged=True,
                    categories={
                        "review": ProviderCategoryResult(
                            flagged=True,
                            score=0.9,
                            applied_input_types=["text"],
                        )
                    },
                )
            ],
        )
    )
    client = ModerationClient(provider=provider)

    result = await client.moderate(
        texts=["hello"],
        request_id="req-1",
        client_id="client-1",
    )

    assert result.action == ModerationAction.MONITOR
    assert result.provider_name == "fake"
    assert result.provider_response_id == "resp-1"
    assert result.request_id == "req-1"
    assert result.client_id == "client-1"
    assert result.categories["review"] == ModerationAction.MONITOR
    assert provider.requests[0][1] == 10.0


@pytest.mark.asyncio
async def test_moderate_fail_open_returns_error_metadata() -> None:
    """Provider errors should return a pass result when fail-open is enabled."""
    client = ModerationClient(provider=FakeProvider(error=RuntimeError("boom")), fail_open=True)

    result = await client.moderate(texts=["hello"])

    assert result.action == ModerationAction.PASS
    assert result.error is not None
    assert result.error.type == "RuntimeError"
    assert result.error.message == "boom"


@pytest.mark.asyncio
async def test_moderate_fail_closed_raises() -> None:
    """Fail-closed mode should propagate provider errors."""
    client = ModerationClient(provider=FakeProvider(error=RuntimeError("boom")), fail_open=False)

    with pytest.raises(RuntimeError, match="boom"):
        await client.moderate(texts=["hello"])


def test_policy_provider_mismatch_raises() -> None:
    """Client construction should reject policies for the wrong provider."""
    with pytest.raises(ProviderConfigurationError, match="does not match"):
        ModerationClient(
            provider=FakeProvider(),
            policy=ProviderPolicy(provider_name="other"),
        )


def test_convenience_constructor_builds_openai_provider() -> None:
    """The OpenAI classmethod should wire an OpenAIProvider into the client."""
    client = ModerationClient.from_openai(api_key="sk-test")

    assert isinstance(client._provider, OpenAIProvider)


@pytest.mark.asyncio
async def test_moderate_non_blocking_requires_openai() -> None:
    """Only OpenAI-backed clients should support deferred moderation."""
    client = ModerationClient(provider=FakeProvider())

    with pytest.raises(ProviderCapabilityError, match="moderate_non_blocking"):
        await client.moderate_non_blocking(texts=["hi"])


@pytest.mark.asyncio
async def test_moderate_non_blocking_awaits_to_moderation_result() -> None:
    """A pending handle should resolve to the same path as :meth:`ModerationClient.moderate`."""
    mock_response = MagicMock()
    mock_response.id = "modr-1"
    mock_response.model = "omni-moderation-latest"
    raw = MagicMock()
    raw.model_dump.return_value = {
        "flagged": False,
        "categories": {},
        "category_scores": {},
        "category_applied_input_types": {},
    }
    mock_response.results = [raw]
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        client = ModerationClient.from_openai(api_key="sk-test")
        pending = await client.moderate_non_blocking(texts=["hello"])
        assert isinstance(pending, OpenAIModerationPending)
        result = await pending
        assert result.flagged is False
        assert result.item_results[0].input_type == "text"
        assert mock_create.await_count == 1
        await client.aclose()
