"""Tests for the Replicate deployment moderation provider."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from p_moderation import (
    ModerationAction,
    ModerationClient,
    ProviderConfigurationError,
    ProviderPolicy,
    ReplicateDeploymentProvider,
)
from p_moderation.normalize import prepare_provider_request
from p_moderation.providers.replicate_deployment import (
    DEFAULT_REPLICATE_DEPLOYMENT,
    REPLICATE_DEPLOYMENT_PROVIDER_NAME,
)
from p_moderation.providers.replicate_deployment import _build_input
from p_moderation.providers.replicate_endpoint import (
    REPLICATE_ENVIRONMENT_KEYS,
    endpoint_info_json_from_environment,
    normalize_replicate_environment,
)


def test_build_input_includes_endpoint_info_and_empty_slots() -> None:
    env = {k: None for k in REPLICATE_ENVIRONMENT_KEYS}
    env["REPLICATE_DEPLOYMENT_NAME"] = "prod"
    endpoint_info = json.dumps(normalize_replicate_environment(env), sort_keys=True)
    req = prepare_provider_request(texts=["a"], images=["https://e/x.png"])
    p = _build_input(req, endpoint_info)
    assert p["texts"] == ["a"]
    assert p["images"] == ["https://e/x.png"]
    assert p["endpoint_info"] == endpoint_info
    assert "replicate_environment" not in p


@patch("p_moderation.providers.replicate_deployment._replicate_client")
@pytest.mark.asyncio
async def test_replicate_moderation_maps_item_results(mock_replicate: MagicMock) -> None:
    mock_deployment = MagicMock()
    mock_replicate.return_value.deployments.get.return_value = mock_deployment
    out = {
        "success": True,
        "model": "m",
        "item_results": [
            {
                "item_index": 0,
                "input_type": "text",
                "flagged": False,
                "category_scores": {"harassment": 0.01},
                "categories": {"harassment": "pass"},
                "category_applied_input_types": {"harassment": ["text"]},
            }
        ],
    }
    pred = MagicMock()
    pred.output = out
    pred.id = "p1"
    mock_deployment.predictions.create.return_value = pred

    provider = ReplicateDeploymentProvider(
        deployment="p/p",
        endpoint_info=json.dumps({"REPLICATE_MODEL_NAME": "m"}),
    )
    req = prepare_provider_request(texts=["x"])
    response = await provider.moderate(req, timeout=30.0)
    assert response.provider_name == "replicate_deployment"
    assert response.model == "m"
    assert response.item_results[0].flagged is False
    mock_replicate.assert_called_once()
    call_kw = mock_deployment.predictions.create.call_args[1]
    assert "endpoint_info" in call_kw["input"]
    assert "replicate_environment" not in call_kw["input"]


def test_convenience_constructor_makes_replicate_deployment() -> None:
    client = ModerationClient.from_replicate_deployment(
        api_token="t",
        deployment="a/b",
        policy=ProviderPolicy(
            provider_name=REPLICATE_DEPLOYMENT_PROVIDER_NAME,
            category_actions={"custom": ModerationAction.BLOCK},
        ),
    )
    p = client._provider
    assert p.name == "replicate_deployment"
    assert isinstance(p, ReplicateDeploymentProvider)
    assert p.deployment_id == "a/b"


def test_non_default_deployment_requires_explicit_policy_for_client() -> None:
    with pytest.raises(ProviderConfigurationError):
        ModerationClient.from_replicate_deployment(
            api_token="t",
            deployment="other/model",
        )


def test_default_policy_pruna_uses_openai_category_names() -> None:
    policy = ReplicateDeploymentProvider(
        deployment=DEFAULT_REPLICATE_DEPLOYMENT,
    ).default_policy()
    assert policy.provider_name == REPLICATE_DEPLOYMENT_PROVIDER_NAME
    assert "harassment" in policy.category_actions
    assert "sexual" in policy.category_actions


def test_default_policy_non_pruna_deployment_errors() -> None:
    with pytest.raises(ProviderConfigurationError):
        ReplicateDeploymentProvider(deployment="a/b").default_policy()


def test_endpoint_info_from_os(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("REPLICATE_DEPLOYMENT_NAME", "d1")
    s = endpoint_info_json_from_environment()
    o = json.loads(s)
    assert o.get("REPLICATE_DEPLOYMENT_NAME") == "d1"
