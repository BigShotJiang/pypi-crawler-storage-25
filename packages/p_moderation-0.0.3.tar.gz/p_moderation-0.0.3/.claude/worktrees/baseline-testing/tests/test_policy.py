"""Tests for provider-neutral policy evaluation."""

from __future__ import annotations

import pytest

from p_moderation import ModerationAction, ProviderPolicy
from p_moderation.exceptions import ProviderConfigurationError, ProviderResponseShapeError
from p_moderation.models import (
    ProviderCategoryResult,
    ProviderItemResult,
    ProviderModerationRequest,
    ProviderModerationResponse,
    ProviderInputItem,
)
from p_moderation.policy import apply_policy_from_provider_response


def test_apply_policy_from_provider_response_preserves_provider_categories() -> None:
    """Provider-native categories should remain intact in the library result."""
    request = ProviderModerationRequest(
        items=[
            ProviderInputItem(item_index=0, input_type="text", text="hello"),
            ProviderInputItem(
                item_index=1, input_type="image", image_bytes=b"x", mime_type="image/jpeg"
            ),
        ],
        request_id="req-1",
        client_id="client-1",
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[
            ProviderItemResult(
                item_index=0,
                input_type="text",
                flagged=True,
                categories={
                    "review": ProviderCategoryResult(
                        flagged=True,
                        score=0.7,
                        applied_input_types=["text"],
                    )
                },
            ),
            ProviderItemResult(
                item_index=1,
                input_type="image",
                flagged=True,
                categories={
                    "sexual": ProviderCategoryResult(
                        flagged=True,
                        score=0.9,
                        applied_input_types=["image"],
                    )
                },
            ),
        ],
    )
    policy = ProviderPolicy(
        provider_name="fake",
        category_actions={
            "review": ModerationAction.MONITOR,
            "sexual": ModerationAction.MONITOR,
        },
        input_type_overrides={"image": {"sexual": ModerationAction.BLOCK}},
    )

    result = apply_policy_from_provider_response(response, policy=policy, request=request)

    assert result.action == ModerationAction.BLOCK
    assert result.categories["review"] == ModerationAction.MONITOR
    assert result.categories["sexual"] == ModerationAction.BLOCK
    assert result.item_results[1].category_applied_input_types["sexual"] == ["image"]
    assert result.request_id == "req-1"
    assert result.client_id == "client-1"


def test_apply_policy_from_provider_response_rejects_provider_mismatch() -> None:
    """Policies should be pinned to the active provider."""
    request = ProviderModerationRequest(
        items=[ProviderInputItem(item_index=0, input_type="text", text="hello")]
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[],
    )

    with pytest.raises(ProviderConfigurationError, match="does not match"):
        apply_policy_from_provider_response(
            response,
            policy=ProviderPolicy(provider_name="other"),
            request=request,
        )


def test_apply_policy_from_provider_response_rejects_count_mismatch() -> None:
    """The policy layer should fail loudly on response cardinality mismatches."""
    request = ProviderModerationRequest(
        items=[ProviderInputItem(item_index=0, input_type="text", text="hello")]
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[],
    )

    with pytest.raises(ProviderResponseShapeError, match="different number of item results"):
        apply_policy_from_provider_response(
            response,
            policy=ProviderPolicy(provider_name="fake"),
            request=request,
        )
