"""Tests for the transformers image-classifier provider."""

from __future__ import annotations

import asyncio
import types
from io import BytesIO
from unittest.mock import patch

import pytest
from PIL import Image

from p_moderation import ModerationAction, ModerationClient, ProviderPolicy
from p_moderation.exceptions import (
    ModerationProviderError,
    ProviderCapabilityError,
    ProviderConfigurationError,
    ProviderDependencyError,
)
from p_moderation.normalize import prepare_provider_request
from p_moderation.providers.hf_pipeline_labels import class_labels_from_pipeline
from p_moderation.providers.image_classifier import (
    DEFAULT_IMAGE_CLASSIFIER_MODEL_ID,
    TransformersImageClassifierProvider,
    validate_image_classifier_model_id,
)


def _fake_image_pipeline(
    id2label: dict[int, str],
    predict_fn,
):
    """Callable fake matching transformers pipeline shape (``__call__`` + ``model.config.id2label``)."""

    def fake_pipeline(images, batch_size: int = 1):  # noqa: ARG001
        return predict_fn(images, batch_size)

    fake_pipeline.model = types.SimpleNamespace(config=types.SimpleNamespace(id2label=id2label))
    return fake_pipeline


def _jpeg_bytes() -> bytes:
    image = Image.new("RGB", (24, 24), color="red")
    buffer = BytesIO()
    image.save(buffer, format="JPEG")
    return buffer.getvalue()


def test_validate_image_classifier_model_id_rejects_unknown() -> None:
    with pytest.raises(ProviderConfigurationError, match="Unsupported image classifier model_id"):
        validate_image_classifier_model_id("unknown/model")


def test_transformers_image_classifier_provider_rejects_unlisted_model() -> None:
    with pytest.raises(ProviderConfigurationError, match="Unsupported image classifier model_id"):
        TransformersImageClassifierProvider(model_id="other/vit")


@pytest.mark.asyncio
async def test_image_classifier_provider_rejects_text_inputs() -> None:
    """The image-classifier provider is image-only."""
    provider = TransformersImageClassifierProvider()
    request = prepare_provider_request(texts=["hello"])

    with pytest.raises(ProviderCapabilityError, match="does not support text"):
        await provider.moderate(request)


@pytest.mark.asyncio
async def test_image_classifier_provider_uses_default_model_id() -> None:
    """The default Hugging Face model id should match the allowlisted default."""
    provider = TransformersImageClassifierProvider()

    assert provider.model_id == DEFAULT_IMAGE_CLASSIFIER_MODEL_ID


def test_image_classifier_constructor_builds_default_provider() -> None:
    """The convenience constructor should build the transformers image-classifier provider."""
    client = ModerationClient.from_image_classifier()

    assert isinstance(client._provider, TransformersImageClassifierProvider)


@pytest.mark.asyncio
async def test_image_classifier_provider_rejects_missing_dependency() -> None:
    """Missing optional dependencies should produce a clear install hint."""
    provider = TransformersImageClassifierProvider()
    request = prepare_provider_request(images=[_jpeg_bytes()])

    with patch(
        "p_moderation.providers._transformers_classifier_base.importlib.import_module",
        side_effect=ImportError,
    ):
        with pytest.raises(ProviderDependencyError, match="p-moderation\\[transformers\\]"):
            await provider.moderate(request)


@pytest.mark.asyncio
async def test_image_classifier_provider_accepts_multiple_images() -> None:
    """Multiple image items should run through local inference."""
    provider = TransformersImageClassifierProvider()

    def predict(images, batch_size: int = 1):  # noqa: ARG001
        assert len(images) == 2
        return [
            [
                {"label": "nsfw", "score": 0.9},
                {"label": "normal", "score": 0.1},
            ],
            [
                {"label": "normal", "score": 0.8},
                {"label": "nsfw", "score": 0.2},
            ],
        ]

    fake = _fake_image_pipeline({0: "nsfw", 1: "normal"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    request = prepare_provider_request(images=[_jpeg_bytes(), _jpeg_bytes()])
    response = await provider.moderate(request)

    assert response.provider_name == "transformers_image_classifier"
    assert response.item_results[0].flagged is True
    assert response.item_results[0].categories["nsfw"].score == 0.9
    assert response.item_results[1].input_type == "image"
    assert response.item_results[1].flagged is False


@pytest.mark.asyncio
async def test_image_classifier_client_respects_custom_policy() -> None:
    """Callers should be able to override the default provider policy."""
    provider = TransformersImageClassifierProvider()

    def predict(images, batch_size: int = 1):  # noqa: ARG001
        return [[{"label": "nsfw", "score": 0.95}, {"label": "normal", "score": 0.05}]]

    fake = _fake_image_pipeline({0: "nsfw", 1: "normal"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    client = ModerationClient(
        provider=provider,
        policy=ProviderPolicy(
            provider_name="transformers_image_classifier",
            category_actions={
                "nsfw": ModerationAction.MONITOR,
                "normal": ModerationAction.PASS,
            },
        ),
    )

    result = await client.moderate(images=[_jpeg_bytes()])

    assert result.action == ModerationAction.MONITOR


@pytest.mark.asyncio
async def test_image_classifier_fills_missing_class_scores() -> None:
    """Partial top-k output should still include scores for all id2label classes."""
    provider = TransformersImageClassifierProvider()

    def predict(images, batch_size: int = 1):  # noqa: ARG001
        return [[{"label": "nsfw", "score": 0.4}]]

    fake = _fake_image_pipeline({0: "nsfw", 1: "normal"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    request = prepare_provider_request(images=[_jpeg_bytes()])
    response = await provider.moderate(request)

    assert response.item_results[0].categories["nsfw"].score == 0.4
    assert response.item_results[0].categories["normal"].score == 0.0


@pytest.mark.asyncio
async def test_image_classifier_rejects_empty_prediction() -> None:
    """Pipeline rows with no usable labels must not return an empty score map."""
    provider = TransformersImageClassifierProvider()

    def predict(images, batch_size: int = 1):  # noqa: ARG001
        return [[]]

    fake = _fake_image_pipeline({0: "nsfw", 1: "normal"}, predict)
    provider._get_pipeline = lambda: fake  # type: ignore[method-assign]
    request = prepare_provider_request(images=[_jpeg_bytes()])

    with pytest.raises(ModerationProviderError, match="no prediction labels"):
        await provider.moderate(request)


def test_non_default_model_requires_explicit_policy_for_default_policy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Built-in nsfw/normal policy applies only to the default Falconsai model."""
    import p_moderation.providers.image_classifier as ic

    other = "org/other_image_classifier"
    monkeypatch.setattr(
        ic,
        "SUPPORTED_IMAGE_CLASSIFIER_MODEL_IDS",
        frozenset({DEFAULT_IMAGE_CLASSIFIER_MODEL_ID, other}),
    )
    provider = TransformersImageClassifierProvider(model_id=other)
    with pytest.raises(ProviderConfigurationError, match="explicit policy"):
        provider.default_policy()


@pytest.mark.asyncio
async def test_non_default_model_client_requires_explicit_policy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """ModerationClient must receive policy when using a non-default classifier model."""
    import p_moderation.providers.image_classifier as ic

    other = "org/other_image_classifier"
    monkeypatch.setattr(
        ic,
        "SUPPORTED_IMAGE_CLASSIFIER_MODEL_IDS",
        frozenset({DEFAULT_IMAGE_CLASSIFIER_MODEL_ID, other}),
    )
    with pytest.raises(ProviderConfigurationError, match="explicit policy"):
        ModerationClient.from_image_classifier(model_id=other)


def test_class_labels_from_pipeline_reads_id2label() -> None:
    """Labels used for score merging should match ``model.config.id2label``."""

    def predict(images, batch_size: int = 1):  # noqa: ARG001
        return [[]]

    fake = _fake_image_pipeline({1: "Normal", 0: "NSFW"}, predict)
    labels = class_labels_from_pipeline(fake)
    assert labels == frozenset({"normal", "nsfw"})


@pytest.mark.asyncio
async def test_image_classifier_pipeline_initialized_once_under_concurrency() -> None:
    provider = TransformersImageClassifierProvider()
    init_calls = 0

    def build_pipeline():
        nonlocal init_calls
        init_calls += 1
        return _fake_image_pipeline(
            {0: "nsfw", 1: "normal"},
            lambda images, batch_size=1: [
                [{"label": "normal", "score": 0.9}, {"label": "nsfw", "score": 0.1}] for _ in images
            ],
        )

    provider._build_pipeline = build_pipeline  # type: ignore[method-assign]

    async def call_once() -> None:
        await provider.moderate(prepare_provider_request(images=[_jpeg_bytes()]))

    await asyncio.gather(*(call_once() for _ in range(8)))
    assert init_calls == 1
