"""Tests for provider-neutral input normalization."""

from __future__ import annotations

from unittest.mock import patch

from p_moderation.models import EncodedImage
from p_moderation.normalize import prepare_provider_request


def test_prepare_provider_request_preserves_encoded_image() -> None:
    """EncodedImage should bypass image normalization and pass through unchanged."""
    encoded = EncodedImage(content=b"jpeg-bytes", mime_type="image/jpeg", source="cache")

    with patch("p_moderation.normalize.normalize_image_bytes") as mock_normalize:
        request = prepare_provider_request(images=[encoded])

    item = request.items[0]
    assert item.input_type == "image"
    assert item.image_bytes == b"jpeg-bytes"
    assert item.mime_type == "image/jpeg"
    assert item.source == "cache"
    mock_normalize.assert_not_called()
