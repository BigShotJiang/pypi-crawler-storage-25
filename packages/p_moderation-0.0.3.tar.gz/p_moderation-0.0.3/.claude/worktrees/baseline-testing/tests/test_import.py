"""Minimal package import smoke test."""


def test_package_imports() -> None:
    """Key public symbols should be importable from the package root."""
    import p_moderation

    assert p_moderation.EncodedImage is not None
    assert p_moderation.ModerationClient is not None
    assert p_moderation.OpenAIModerationPending is not None
    assert p_moderation.OpenAIProvider is not None
    assert p_moderation.ReplicateDeploymentProvider is not None
    assert p_moderation.REPLICATE_ENVIRONMENT_KEYS
    assert p_moderation.TransformersImageClassifierProvider is not None
    assert p_moderation.TransformersTextClassifierProvider is not None
    assert p_moderation.SUPPORTED_IMAGE_CLASSIFIER_MODEL_IDS
    assert p_moderation.SUPPORTED_TEXT_CLASSIFIER_MODEL_IDS
    assert p_moderation.validate_image_classifier_model_id is not None
    assert p_moderation.validate_text_classifier_model_id is not None
