"""Tests for the OpenAI provider adapter."""

from __future__ import annotations

from io import BytesIO
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from PIL import Image

from p_moderation.exceptions import (
    ProviderConfigurationError,
    ProviderDependencyError,
    ProviderResponseShapeError,
)
from p_moderation.providers import openai as openai_provider_module
from p_moderation.providers.openai import OpenAIProvider


def _make_response(*payloads: dict, model: str = "omni-moderation-latest") -> MagicMock:
    response = MagicMock()
    response.id = "modr-1"
    response.model = model
    response.results = []
    for payload in payloads:
        result = MagicMock()
        result.model_dump.return_value = payload
        response.results.append(result)
    return response


def _jpeg_bytes() -> bytes:
    image = Image.new("RGB", (32, 32), color="red")
    buffer = BytesIO()
    image.save(buffer, format="JPEG")
    return buffer.getvalue()


@pytest.mark.asyncio
async def test_openai_provider_maps_text_requests() -> None:
    """Text-only requests should be converted into OpenAI moderation payloads."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        response = await provider.moderate(text="hello")
        await provider.aclose()

    assert response.provider_name == "openai"
    assert response.item_results[0].input_type == "text"
    kwargs = mock_create.await_args.kwargs
    assert kwargs["model"] == "omni-moderation-latest"
    assert kwargs["input"] == [{"type": "text", "text": "hello"}]
    mock_openai.close.assert_awaited_once()


@pytest.mark.asyncio
async def test_openai_provider_combined_text_and_image_url_like_sdk() -> None:
    """Match OpenAI ``moderations.create`` with text and https ``image_url``."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())
    image_url = "https://example.com/image.png"
    text = "...text to classify goes here..."

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test", model="omni-moderation-latest")
        await provider.moderate(text=text, image=image_url)

    kwargs = mock_create.await_args.kwargs
    assert kwargs["model"] == "omni-moderation-latest"
    assert kwargs["input"] == [
        {"type": "text", "text": text},
        {"type": "image_url", "image_url": {"url": image_url}},
    ]


@pytest.mark.asyncio
async def test_openai_provider_maps_image_request() -> None:
    """Image bytes should become an OpenAI image_url payload."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        response = await provider.moderate(image=_jpeg_bytes())

    kwargs = mock_create.await_args.kwargs
    assert response.item_results[0].input_type == "image"
    assert kwargs["input"][0]["type"] == "image_url"
    assert kwargs["input"][0]["image_url"]["url"].startswith("data:image/jpeg;base64,")


@pytest.mark.asyncio
async def test_openai_provider_uses_omni_model_for_images() -> None:
    """Image-bearing requests should use the configured omni moderation model."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test", model="omni-moderation-latest")
        await provider.moderate(image=_jpeg_bytes())

    assert mock_create.await_args.kwargs["model"] == "omni-moderation-latest"


@pytest.mark.asyncio
async def test_openai_provider_rejects_image_requests_without_omni_model() -> None:
    """Image requests should fail if the model is not omni-moderation."""
    provider = OpenAIProvider(api_key="sk-test", model="text-moderation-latest")

    with pytest.raises(ProviderConfigurationError, match="requires an omni-moderation model"):
        await provider.moderate(image=_jpeg_bytes())


@pytest.mark.asyncio
async def test_openai_provider_rejects_empty_response() -> None:
    """Empty response should raise a provider error."""
    mock_response = MagicMock()
    mock_response.results = []
    mock_openai = MagicMock(
        moderations=MagicMock(create=AsyncMock(return_value=mock_response)),
        close=AsyncMock(),
    )

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        with pytest.raises(ProviderResponseShapeError, match="contains no results"):
            await provider.moderate(text="hello")


@pytest.mark.asyncio
async def test_openai_provider_requires_input() -> None:
    """OpenAI provider should require at least text or image."""
    provider = OpenAIProvider(api_key="sk-test")

    with pytest.raises(ProviderConfigurationError, match="At least one of text or image"):
        await provider.moderate()


def test_openai_provider_can_build_aiohttp_client() -> None:
    """The provider should pass the aiohttp transport to AsyncOpenAI when requested."""
    mock_openai = MagicMock(moderations=MagicMock(create=AsyncMock()), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai) as mock_cls:
        with patch.object(openai_provider_module, "_build_aiohttp_client", return_value="client"):
            provider = OpenAIProvider(api_key="sk-test", http_backend="aiohttp")
            provider._get_client("sk-test")

    assert mock_cls.call_args.kwargs["http_client"] == "client"


def test_openai_provider_aiohttp_requires_dependency() -> None:
    """Requesting the aiohttp transport without the dependency should fail clearly."""
    provider = OpenAIProvider(api_key="sk-test", http_backend="aiohttp")

    with patch("p_moderation.providers.openai.importlib.import_module", side_effect=ImportError):
        with pytest.raises(ProviderDependencyError, match="p-moderation\\[aiohttp\\]"):
            provider._get_client("sk-test")
