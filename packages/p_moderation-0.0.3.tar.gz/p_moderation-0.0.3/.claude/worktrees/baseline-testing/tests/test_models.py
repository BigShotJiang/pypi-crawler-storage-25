"""Tests for p_moderation.models."""

from __future__ import annotations

from p_moderation.models import (
    EncodedImage,
    ModerationAction,
    ModerationRequest,
    ProviderPolicy,
    aggregate_actions,
)


def test_provider_policy_input_override() -> None:
    """Input-type overrides should take precedence over category defaults."""
    policy = ProviderPolicy(
        provider_name="fake",
        category_actions={"sexual": ModerationAction.MONITOR},
        input_type_overrides={"image": {"sexual": ModerationAction.BLOCK}},
    )

    assert policy.get_action("sexual", "text") == ModerationAction.MONITOR
    assert policy.get_action("sexual", "image") == ModerationAction.BLOCK
    assert policy.get_action("unknown", "image") == ModerationAction.PASS


def test_moderation_request_defaults() -> None:
    """The public request wrapper should use empty defaults."""
    request = ModerationRequest()

    assert request.texts == []
    assert request.images == []
    assert request.request_id is None
    assert request.client_id is None


def test_encoded_image_defaults() -> None:
    """EncodedImage should carry stable defaults for fast-path inputs."""
    image = EncodedImage(content=b"123")

    assert image.content == b"123"
    assert image.mime_type == "image/jpeg"
    assert image.source is None
    assert image.id is None


def test_aggregate_actions_uses_strict_precedence() -> None:
    """Block should win over monitor, and monitor should win over pass."""
    assert (
        aggregate_actions([ModerationAction.PASS, ModerationAction.MONITOR])
        == ModerationAction.MONITOR
    )
    assert (
        aggregate_actions([ModerationAction.MONITOR, ModerationAction.BLOCK])
        == ModerationAction.BLOCK
    )
