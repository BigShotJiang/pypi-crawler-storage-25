"""Tests for ModerationClient.moderate_many."""

from __future__ import annotations

import asyncio

import pytest

from p_moderation import ModerationAction, ModerationClient, ProviderPolicy
from p_moderation.models import (
    ProviderCategoryResult,
    ProviderItemResult,
    ProviderModerationRequest,
    ProviderModerationResponse,
)
from p_moderation.providers.base import BaseModerationProvider


class DelayedProvider(BaseModerationProvider):
    """Fake provider used to exercise moderate_many ordering."""

    name = "fake"
    supports_text = True
    supports_image = False

    def default_policy(self) -> ProviderPolicy:
        return ProviderPolicy(
            provider_name=self.name,
            category_actions={"review": ModerationAction.MONITOR},
        )

    async def moderate(
        self,
        request: ProviderModerationRequest,
        *,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        text = request.items[0].text or ""
        await asyncio.sleep(0.01 if text == "slow" else 0.0)
        return ProviderModerationResponse(
            provider_name=self.name,
            provider_response_id=text,
            model="fake-model",
            item_results=[
                ProviderItemResult(
                    item_index=0,
                    input_type="text",
                    flagged=text == "flag",
                    categories={
                        "review": ProviderCategoryResult(
                            flagged=text == "flag",
                            score=0.8 if text == "flag" else 0.0,
                            applied_input_types=["text"],
                        )
                    },
                )
            ],
        )


@pytest.mark.asyncio
async def test_moderate_many_preserves_order() -> None:
    """Results should stay aligned with input order even when tasks finish out of order."""
    client = ModerationClient(provider=DelayedProvider())

    results = await client.moderate_many(
        [
            {"texts": ["slow"]},
            {"texts": ["flag"]},
        ],
        max_concurrency=2,
    )

    assert [result.provider_response_id for result in results] == ["slow", "flag"]
    assert results[0].action == ModerationAction.PASS
    assert results[1].action == ModerationAction.MONITOR
