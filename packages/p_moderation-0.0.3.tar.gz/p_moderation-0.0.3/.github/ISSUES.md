# Issues Overview

| # | Title | Labels | Status | GitHub Issue | PR |
|---|-------|--------|--------|--------------|-----|
| 1 | Scaffold uv library | `setup`, `priority-high` | completed | - | - |
| 2 | Core models + policy engine | `feature` | completed | - | - |
| 3 | Async OpenAI client | `feature` | completed | - | - |
| 4 | Image pipeline | `feature` | completed | - | - |
| 5 | Video sampling + grid | `feature` | completed | - | - |
| 6 | Concurrency helpers + benchmarks | `feature` | completed | - | - |
| 7 | Architecture doc | `docs` | completed | - | - |

---

## Issue 1: Scaffold uv library

**Labels:** `setup`, `priority-high`
**Status:** pending

**Body:**
Set up the p-moderation package as a uv-managed, versioned library.

- Add `pyproject.toml` with project name `p-moderation` (or `pruna-moderation`), version `0.1.0`
- Add dependencies: `openai`, `pydantic`
- Add dev dependencies: `pytest`, `pytest-asyncio`, `ruff`
- Use src layout: `src/p_moderation/`
- Add `uv sync` instructions for contributors

**Acceptance:**
- `uv sync` installs all dependencies
- `uv run pytest` runs (empty or minimal test)
- Package is importable as `p_moderation`

---

## Issue 2: Core models + policy engine

**Labels:** `feature`
**Status:** pending

**Body:**
Implement Pydantic models and category→action policy mapping.

- `ModerationAction` enum: `pass`, `monitor`, `block`
- Request model: `request_id`, `client_id`, `texts`, `images`, `videos` (optional)
- Response model: `id`, `model`, `action`, per-category actions, scores, `category_applied_input_types`
- Policy engine: map OpenAI `categories[bool]` + scores → `pass|monitor|block` per category
- Default category→action mapping per spec table (block list fixed; monitor/block for ambiguous rows)
- Aggregate action: precedence `block` > `monitor` > `pass`

**Acceptance:**
- Pure functions, no HTTP
- Full unit tests for policy engine and models
- Defaults match spec category table

---

## Issue 3: Async OpenAI client

**Labels:** `feature`
**Status:** pending

**Body:**
Implement thin async wrapper around `moderations.create`.

- Accept texts + list of images (path / bytes / URL)
- Call `omni-moderation-latest`
- Return raw parsed response + policy-applied result object
- Explicit timeout parameter
- Explicit `on_error` behavior: default **fail-open** (pass on API error) per spec; configurable for strict mode

**Acceptance:**
- Mocked tests pass without network
- Timeout propagates correctly
- Fail-open default documented and tested

---

## Issue 4: Image pipeline

**Labels:** `feature`
**Status:** pending

**Body:**
Portable image encode/resize for moderation input.

- Replace gist's `optimized_base64` with standalone implementation
- Resize with `max_dim` (default 384), JPEG quality (default 60)
- Document max dimension aligned with OpenAI limits
- Support path, bytes, or URL as input

**Acceptance:**
- No app-specific imports
- Unit tests with fixture images or in-memory bytes

---

## Issue 5: Video sampling + grid

**Labels:** `feature`
**Status:** pending

**Body:**
Frame extraction and grid builder for video moderation.

- 1 fps sampling (configurable)
- Cap max frames
- Resize/compress each frame
- Build mosaic/grid image suitable for `image_url` data URL
- Use OpenCV or ffmpeg subprocess (choose based on deploy constraints)

**Acceptance:**
- Tests with synthetic video fixture or mocked frame iterator (no large binaries in repo)
- Grid dimensions documented

---

## Issue 6: Concurrency helpers + benchmarks

**Labels:** `feature`
**Status:** pending

**Body:**
- `moderate_many` with bounded semaphore (tune to rate limits)
- Benchmark scripts under `benchmarks/` for text, image, grid
- Report p50/p95 over N iterations
- Gate live benchmarks behind `OPENAI_API_KEY` env

**Acceptance:**
- CI runs mocked/offline only; live benchmarks optional
- Benchmark script prints stable timing when key present

---

## Issue 7: Architecture doc

**Labels:** `docs`
**Status:** pending

**Body:**
Add root `ARCHITECTURE.md`.

- Overview: one-line purpose
- Modules: client, models, policy, video, image_encode
- Policy defaults and failure modes
- Video strategy (1 fps, grid)

**Acceptance:**
- Doc exists and covers modules, defaults, operational failure mode
