"""Tests for provider-neutral policy evaluation."""

from __future__ import annotations

import pytest

from p_moderation import ModerationAction, ProviderPolicy
from p_moderation.exceptions import ProviderConfigurationError, ProviderResponseShapeError
from p_moderation.models import (
    ProviderCategoryResult,
    ProviderItemResult,
    ProviderModerationRequest,
    ProviderModerationResponse,
    ProviderInputItem,
)
from p_moderation.policy import apply_policy_from_provider_response


def test_apply_policy_from_provider_response_preserves_provider_categories() -> None:
    """Provider-native categories should remain intact in the library result."""
    request = ProviderModerationRequest(
        items=[
            ProviderInputItem(item_index=0, input_type="text", text="hello"),
            ProviderInputItem(
                item_index=1, input_type="image", image_bytes=b"x", mime_type="image/jpeg"
            ),
        ],
        request_id="req-1",
        client_id="client-1",
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[
            ProviderItemResult(
                item_index=0,
                input_type="text",
                flagged=True,
                categories={
                    "review": ProviderCategoryResult(
                        flagged=True,
                        score=0.7,
                        applied_input_types=["text"],
                    )
                },
            ),
            ProviderItemResult(
                item_index=1,
                input_type="image",
                flagged=True,
                categories={
                    "sexual": ProviderCategoryResult(
                        flagged=True,
                        score=0.9,
                        applied_input_types=["image"],
                    )
                },
            ),
        ],
    )
    policy = ProviderPolicy(
        provider_name="fake",
        category_actions={
            "review": ModerationAction.MONITOR,
            "sexual": ModerationAction.MONITOR,
        },
        input_type_overrides={"image": {"sexual": ModerationAction.BLOCK}},
    )

    result = apply_policy_from_provider_response(response, policy=policy, request=request)

    assert result.action == ModerationAction.BLOCK
    assert result.categories["review"] == ModerationAction.MONITOR
    assert result.categories["sexual"] == ModerationAction.BLOCK
    assert result.item_results[1].category_applied_input_types["sexual"] == ["image"]
    assert result.request_id == "req-1"
    assert result.client_id == "client-1"


def test_apply_policy_from_provider_response_rejects_provider_mismatch() -> None:
    """Policies should be pinned to the active provider."""
    request = ProviderModerationRequest(
        items=[ProviderInputItem(item_index=0, input_type="text", text="hello")]
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[],
    )

    with pytest.raises(ProviderConfigurationError, match="does not match"):
        apply_policy_from_provider_response(
            response,
            policy=ProviderPolicy(provider_name="other"),
            request=request,
        )


def test_apply_policy_from_provider_response_rejects_count_mismatch() -> None:
    """The policy layer should fail loudly on response cardinality mismatches."""
    request = ProviderModerationRequest(
        items=[ProviderInputItem(item_index=0, input_type="text", text="hello")]
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[],
    )

    with pytest.raises(ProviderResponseShapeError, match="Provider returned 0 item result"):
        apply_policy_from_provider_response(
            response,
            policy=ProviderPolicy(provider_name="fake"),
            request=request,
        )


def test_apply_policy_item_level_flagged_without_category_flags_uses_monitor() -> None:
    """Item flagged with no per-category data must not report action=pass only."""
    request = ProviderModerationRequest(
        items=[ProviderInputItem(item_index=0, input_type="text", text="suspicious")],
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[
            ProviderItemResult(
                item_index=0,
                input_type="text",
                flagged=True,
                categories={},
            ),
        ],
    )
    policy = ProviderPolicy(provider_name="fake")
    result = apply_policy_from_provider_response(response, policy=policy, request=request)

    assert result.flagged is True
    assert result.item_results[0].action == ModerationAction.MONITOR


def test_apply_policy_item_flagged_all_categories_unflagged_uses_monitor() -> None:
    """Top-level item flag with no per-category flags still gets a non-pass item action."""
    request = ProviderModerationRequest(
        items=[ProviderInputItem(item_index=0, input_type="text", text="hello")],
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[
            ProviderItemResult(
                item_index=0,
                input_type="text",
                flagged=True,
                categories={
                    "sexual": ProviderCategoryResult(
                        flagged=False, score=0.01, applied_input_types=["text"]
                    )
                },
            ),
        ],
    )
    policy = ProviderPolicy(
        provider_name="fake",
        category_actions={"sexual": ModerationAction.BLOCK},
    )
    result = apply_policy_from_provider_response(response, policy=policy, request=request)

    assert result.flagged is True
    assert result.item_results[0].action == ModerationAction.MONITOR
    assert result.item_results[0].categories["sexual"] == ModerationAction.PASS


def test_apply_policy_aggregates_actions_across_flagged_categories() -> None:
    """Item action is the strongest of all per-category policy actions."""
    request = ProviderModerationRequest(
        items=[ProviderInputItem(item_index=0, input_type="text", text="hello")],
    )
    response = ProviderModerationResponse(
        provider_name="fake",
        provider_response_id="resp-1",
        model="fake-model",
        item_results=[
            ProviderItemResult(
                item_index=0,
                input_type="text",
                flagged=True,
                categories={
                    "a": ProviderCategoryResult(
                        flagged=True, score=0.9, applied_input_types=["text"]
                    ),
                    "b": ProviderCategoryResult(
                        flagged=True, score=0.8, applied_input_types=["text"]
                    ),
                },
            ),
        ],
    )
    policy = ProviderPolicy(
        provider_name="fake",
        category_actions={"a": ModerationAction.MONITOR, "b": ModerationAction.BLOCK},
    )
    result = apply_policy_from_provider_response(response, policy=policy, request=request)

    assert result.item_results[0].action == ModerationAction.BLOCK
