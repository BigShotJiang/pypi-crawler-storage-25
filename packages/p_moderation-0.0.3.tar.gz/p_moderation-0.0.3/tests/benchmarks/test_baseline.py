"""Tests for baseline module."""

import json
import tempfile
from pathlib import Path
import pytest
from benchmarks.baseline import BaselineStore, BaselineComparison, ToleranceConfig, ReportGenerator


def test_baseline_store_load_existing_file():
    """Test loading an existing baseline file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        baseline_dir = Path(tmpdir)
        baseline_file = baseline_dir / "openai-text-conc8.json"

        test_data = {
            "scenario": "text",
            "concurrency": 8,
            "timestamp": "2026-04-20T10:00:00Z",
            "metrics": {
                "latency_ms": {"p50": 145.2, "p95": 210.5, "p99": 289.1},
                "throughput": {"req_per_sec": 6.31},
                "cost": {"cost_per_1k_requests": 0.06},
                "errors": {"error_rate": 0.0},
            },
        }

        baseline_file.write_text(json.dumps(test_data))

        store = BaselineStore(baseline_dir)
        loaded = store.load("text", 8)

        assert loaded is not None
        assert loaded["scenario"] == "text"
        assert loaded["concurrency"] == 8
        assert loaded["metrics"]["latency_ms"]["p95"] == 210.5


def test_baseline_store_load_nonexistent_file():
    """Test loading returns None when baseline file doesn't exist."""
    with tempfile.TemporaryDirectory() as tmpdir:
        baseline_dir = Path(tmpdir)
        store = BaselineStore(baseline_dir)
        loaded = store.load("text", 8)
        assert loaded is None


def test_baseline_store_save():
    """Test saving a baseline."""
    with tempfile.TemporaryDirectory() as tmpdir:
        baseline_dir = Path(tmpdir)
        store = BaselineStore(baseline_dir)

        baseline_data = {
            "scenario": "text",
            "concurrency": 8,
            "timestamp": "2026-04-23T14:30:45Z",
            "metrics": {
                "latency_ms": {"p50": 145.2, "p95": 210.5},
                "throughput": {"req_per_sec": 6.31},
                "cost": {"cost_per_1k_requests": 0.06},
                "errors": {"error_rate": 0.0},
            },
        }

        store.save("text", 8, baseline_data)

        baseline_file = baseline_dir / "openai-text-conc8.json"
        assert baseline_file.exists()

        loaded_data = json.loads(baseline_file.read_text())
        assert loaded_data == baseline_data


def test_baseline_corrupted_json():
    """Test loading corrupted JSON raises JSONDecodeError."""
    with tempfile.TemporaryDirectory() as tmpdir:
        baseline_dir = Path(tmpdir)
        baseline_file = baseline_dir / "openai-text-conc8.json"
        baseline_file.write_text("{invalid json")

        store = BaselineStore(baseline_dir)
        try:
            store.load("text", 8)
            assert False, "Expected JSONDecodeError"
        except json.JSONDecodeError:
            pass  # Expected


def test_baseline_invalid_scenario():
    """Test that invalid scenario raises ValueError."""
    with tempfile.TemporaryDirectory() as tmpdir:
        baseline_dir = Path(tmpdir)
        store = BaselineStore(baseline_dir)

        try:
            store.load("", 8)  # Empty scenario
            assert False, "Expected ValueError"
        except ValueError as e:
            assert "scenario" in str(e)


def test_baseline_invalid_concurrency():
    """Test that invalid concurrency raises ValueError."""
    with tempfile.TemporaryDirectory() as tmpdir:
        baseline_dir = Path(tmpdir)
        store = BaselineStore(baseline_dir)

        try:
            store.load("text", -1)  # Negative concurrency
            assert False, "Expected ValueError"
        except ValueError as e:
            assert "concurrency" in str(e)


def test_baseline_roundtrip():
    """Test save/load round-trip preserves data exactly."""
    with tempfile.TemporaryDirectory() as tmpdir:
        baseline_dir = Path(tmpdir)
        store = BaselineStore(baseline_dir)

        original_data = {
            "scenario": "image",
            "concurrency": 4,
            "timestamp": "2026-04-23T14:30:45Z",
            "metrics": {
                "latency_ms": {"p50": 250.5, "p95": 450.2, "p99": 750.8},
                "throughput": {"req_per_sec": 2.5},
                "cost": {"cost_per_1k_requests": 0.15},
                "errors": {"error_rate": 0.001},
            },
        }

        store.save("image", 4, original_data)
        loaded_data = store.load("image", 4)

        assert loaded_data == original_data


def test_baseline_comparison_compute_changes():
    """Test computing % changes between baselines."""
    previous = {
        "metrics": {
            "latency_ms": {"p95": 200.0},
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }
    current = {
        "metrics": {
            "latency_ms": {"p95": 210.0},
            "throughput": {"req_per_sec": 4.85},
            "cost": {"cost_per_1k_requests": 0.063},
            "errors": {"error_rate": 0.0},
        }
    }

    comparison = BaselineComparison(previous, current)
    changes = comparison.compute_changes()

    assert changes["latency_ms"]["p95"]["pct_change"] == pytest.approx(5.0)  # (210-200)/200 * 100
    assert changes["throughput"]["req_per_sec"]["pct_change"] == pytest.approx(
        -3.0
    )  # (4.85-5)/5 * 100
    assert changes["cost"]["cost_per_1k_requests"]["pct_change"] == pytest.approx(5.0)
    assert changes["errors"]["error_rate"]["pct_change"] == pytest.approx(0.0)


def test_baseline_comparison_classify_status():
    """Test status classification based on % change and tolerance."""
    previous = {
        "metrics": {
            "latency_ms": {"p95": 200.0},
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }
    # Within tolerance (±15%)
    current_ok = {
        "metrics": {
            "latency_ms": {"p95": 210.0},  # +5%
            "throughput": {"req_per_sec": 4.85},  # -3%
            "cost": {"cost_per_1k_requests": 0.063},  # +5%
            "errors": {"error_rate": 0.0},
        }
    }
    # Minor regression
    current_warn = {
        "metrics": {
            "latency_ms": {"p95": 235.0},  # +17.5% - exceeds 15%
            "throughput": {"req_per_sec": 4.85},
            "cost": {"cost_per_1k_requests": 0.063},
            "errors": {"error_rate": 0.0},
        }
    }
    # Error rate regression
    current_fail = {
        "metrics": {
            "latency_ms": {"p95": 210.0},
            "throughput": {"req_per_sec": 4.85},
            "cost": {"cost_per_1k_requests": 0.063},
            "errors": {"error_rate": 0.1},  # Any > 0 is failure
        }
    }

    # OK case
    comparison_ok = BaselineComparison(previous, current_ok)
    status_ok = comparison_ok.classify_status()
    assert status_ok == "✓"

    # Warning case
    comparison_warn = BaselineComparison(previous, current_warn)
    status_warn = comparison_warn.classify_status()
    assert status_warn == "⚠"

    # Failure case
    comparison_fail = BaselineComparison(previous, current_fail)
    status_fail = comparison_fail.classify_status()
    assert status_fail == "✗"


def test_baseline_comparison_zero_baseline():
    """Test division by zero when baseline metric is 0."""
    previous = {
        "metrics": {
            "latency_ms": {"p95": 0.0},  # Zero baseline
            "throughput": {"req_per_sec": 0.0},
            "cost": {"cost_per_1k_requests": 0.0},
            "errors": {"error_rate": 0.0},
        }
    }
    current = {
        "metrics": {
            "latency_ms": {"p95": 100.0},  # Changed from 0
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.05},
            "errors": {"error_rate": 0.0},
        }
    }

    comparison = BaselineComparison(previous, current)
    changes = comparison.compute_changes()

    # When baseline is 0, pct_change should be 0.0 (no meaningful percentage)
    assert changes["latency_ms"]["p95"]["pct_change"] == 0.0
    assert changes["throughput"]["req_per_sec"]["pct_change"] == 0.0
    assert changes["cost"]["cost_per_1k_requests"]["pct_change"] == 0.0
    assert changes["errors"]["error_rate"]["pct_change"] == 0.0


def test_baseline_comparison_missing_metric_group():
    """Test when a metric group is missing from current data."""
    previous = {
        "metrics": {
            "latency_ms": {"p95": 200.0},
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }
    current = {
        "metrics": {
            # "throughput" group is missing
            "latency_ms": {"p95": 200.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }

    comparison = BaselineComparison(previous, current)
    changes = comparison.compute_changes()

    # Should still have changes for missing group with 0% change (uses previous value)
    assert "throughput" in changes
    assert changes["throughput"]["req_per_sec"]["previous"] == 5.0
    assert changes["throughput"]["req_per_sec"]["current"] == 5.0  # Defaults to previous
    assert changes["throughput"]["req_per_sec"]["pct_change"] == 0.0


def test_baseline_comparison_missing_individual_metric():
    """Test when an individual metric is missing from current data."""
    previous = {
        "metrics": {
            "latency_ms": {"p50": 100.0, "p95": 200.0, "p99": 300.0},
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }
    current = {
        "metrics": {
            "latency_ms": {"p95": 210.0},  # p50 and p99 are missing
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }

    comparison = BaselineComparison(previous, current)
    changes = comparison.compute_changes()

    # Missing metrics should default to previous value, resulting in 0% change
    assert changes["latency_ms"]["p50"]["previous"] == 100.0
    assert changes["latency_ms"]["p50"]["current"] == 100.0  # Defaults to previous
    assert changes["latency_ms"]["p50"]["pct_change"] == 0.0

    assert changes["latency_ms"]["p95"]["pct_change"] == pytest.approx(5.0)

    assert changes["latency_ms"]["p99"]["previous"] == 300.0
    assert changes["latency_ms"]["p99"]["current"] == 300.0  # Defaults to previous
    assert changes["latency_ms"]["p99"]["pct_change"] == 0.0


def test_baseline_comparison_custom_tolerance():
    """Test that custom ToleranceConfig values are respected in classify_status()."""
    previous = {
        "metrics": {
            "latency_ms": {"p95": 200.0},
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }
    # +18% change (exceeds default 15% but within custom 20%)
    current = {
        "metrics": {
            "latency_ms": {"p95": 236.0},  # +18%
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }

    # With default tolerance (15%), this should be warning
    comparison_default = BaselineComparison(previous, current)
    status_default = comparison_default.classify_status()
    assert status_default == "⚠"

    # With custom tolerance (20%), this should be OK
    custom_tolerance = ToleranceConfig(latency_pct=20.0)
    comparison_custom = BaselineComparison(previous, current, custom_tolerance)
    status_custom = comparison_custom.classify_status()
    assert status_custom == "✓"


def test_report_generator_terminal_table():
    """Test terminal table generation."""
    previous = {
        "metrics": {
            "latency_ms": {"p95": 200.0, "p99": 300.0},
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }
    current = {
        "scenario": "text",
        "concurrency": 8,
        "metrics": {
            "latency_ms": {"p95": 210.0, "p99": 300.0},
            "throughput": {"req_per_sec": 4.85},
            "cost": {"cost_per_1k_requests": 0.063},
            "errors": {"error_rate": 0.0},
        },
    }

    comparison = BaselineComparison(previous, current)
    report = ReportGenerator(comparison, "text", 8)

    table = report.terminal_table()

    # Verify table contains key elements
    assert "text" in table
    assert "8" in table
    assert "210" in table or "210.0" in table  # current p95
    assert "200" in table or "200.0" in table  # previous p95
    assert "✓" in table or "⚠" in table or "✗" in table  # status


def test_report_generator_markdown():
    """Test markdown report generation."""
    previous = {
        "metrics": {
            "latency_ms": {"p95": 200.0},
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }
    current = {
        "scenario": "text",
        "concurrency": 8,
        "timestamp": "2026-04-23T14:30:45Z",
        "metrics": {
            "latency_ms": {"p95": 210.0},
            "throughput": {"req_per_sec": 4.85},
            "cost": {"cost_per_1k_requests": 0.063},
            "errors": {"error_rate": 0.0},
        },
    }

    comparison = BaselineComparison(previous, current)
    report = ReportGenerator(comparison, "text", 8)

    markdown = report.markdown()

    assert "## Text Moderation" in markdown or "text" in markdown.lower()
    assert "Concurrency" in markdown or "8" in markdown
    assert "p95" in markdown.lower()


def test_report_generator_json():
    """Test JSON report generation."""
    previous = {
        "metrics": {
            "latency_ms": {"p95": 200.0},
            "throughput": {"req_per_sec": 5.0},
            "cost": {"cost_per_1k_requests": 0.06},
            "errors": {"error_rate": 0.0},
        }
    }
    current = {
        "scenario": "text",
        "concurrency": 8,
        "metrics": {
            "latency_ms": {"p95": 210.0},
            "throughput": {"req_per_sec": 4.85},
            "cost": {"cost_per_1k_requests": 0.063},
            "errors": {"error_rate": 0.0},
        },
    }

    comparison = BaselineComparison(previous, current)
    report = ReportGenerator(comparison, "text", 8)

    json_str = report.json()
    json_data = json.loads(json_str)

    assert json_data["scenario"] == "text"
    assert json_data["concurrency"] == 8
    assert "changes" in json_data
    assert json_data["status"] in ("✓", "⚠", "✗")


def test_baseline_workflow_end_to_end():
    """Test complete baseline workflow: save, load, compare, report."""
    with tempfile.TemporaryDirectory() as tmpdir:
        baseline_dir = Path(tmpdir)
        store = BaselineStore(baseline_dir)

        first_run = {
            "scenario": "text",
            "concurrency": 8,
            "timestamp": "2026-04-23T14:00:00Z",
            "metrics": {
                "latency_ms": {"p50": 145.2, "p95": 210.5, "p99": 289.1},
                "throughput": {"req_per_sec": 6.31},
                "cost": {"cost_per_1k_requests": 0.06},
                "errors": {"error_rate": 0.0},
            },
        }
        store.save("text", 8, first_run)

        second_run = {
            "scenario": "text",
            "concurrency": 8,
            "timestamp": "2026-04-23T15:00:00Z",
            "metrics": {
                "latency_ms": {"p50": 142.0, "p95": 205.0, "p99": 280.0},
                "throughput": {"req_per_sec": 6.45},
                "cost": {"cost_per_1k_requests": 0.06},
                "errors": {"error_rate": 0.0},
            },
        }

        previous = store.load("text", 8)
        assert previous is not None

        comparison = BaselineComparison(previous, second_run)
        changes = comparison.compute_changes()
        status = comparison.classify_status()

        assert changes["latency_ms"]["p95"]["pct_change"] < 0
        assert status == "✓"

        report = ReportGenerator(comparison, "text", 8)
        terminal = report.terminal_table()
        markdown = report.markdown()
        json_report = report.json()

        assert "text" in terminal and "text" in markdown.lower() and "text" in json_report

        store.save("text", 8, second_run)
        loaded = store.load("text", 8)
        assert loaded["timestamp"] == "2026-04-23T15:00:00Z"
