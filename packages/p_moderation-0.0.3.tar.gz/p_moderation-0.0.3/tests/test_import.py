"""Minimal package import smoke test."""


def test_package_imports() -> None:
    """Key public symbols should be importable from the package root."""
    import p_moderation

    assert p_moderation.ModerationClient is not None
    assert p_moderation.ModerationResult is not None
    assert p_moderation.ModerationAction is not None
    assert p_moderation.ProviderPolicy is not None
    assert p_moderation.ImageInput is not None
    assert p_moderation.OpenAIModerationPending is not None
    assert p_moderation.ModerationProviderError is not None
    assert p_moderation.ProviderConfigurationError is not None
