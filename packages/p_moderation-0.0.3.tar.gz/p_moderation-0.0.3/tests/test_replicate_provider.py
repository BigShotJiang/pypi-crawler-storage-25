"""Tests for replicate provider input normalization."""

from __future__ import annotations

from contextlib import ExitStack
from pathlib import Path

from PIL import Image

from p_moderation.providers.replicate import _normalize_prediction_input


def test_normalize_prediction_input_preserves_non_remote_images() -> None:
    """Data URLs should pass through unchanged."""
    data_url = "data:image/png;base64,abc123"
    with ExitStack() as stack:
        normalized = _normalize_prediction_input(
            {"image": data_url, "timeout": 0.5},
            stack=stack,
        )
    assert normalized["image"] == data_url


def test_normalize_prediction_input_preserves_remote_image_by_default() -> None:
    """Remote image URLs should pass through by default for fastest request path."""
    with ExitStack() as stack:
        normalized = _normalize_prediction_input(
            {"image": "https://example.com/image.png", "timeout": 0.75},
            stack=stack,
        )
    assert normalized["image"] == "https://example.com/image.png"


def test_normalize_prediction_input_supports_images_list(monkeypatch) -> None:
    """Remote URLs inside images lists can be converted for fallback mode."""

    monkeypatch.setattr(
        "p_moderation.providers.replicate.fetch_image_url_bytes_sync",
        lambda _url, timeout: b"raw",
    )
    monkeypatch.setattr(
        "p_moderation.providers.replicate.normalize_image_bytes",
        lambda _raw: (b"jpeg-content", "image/jpeg"),
    )

    with ExitStack() as stack:
        normalized = _normalize_prediction_input(
            {
                "images": [
                    "https://example.com/a.png",
                    "data:image/jpeg;base64,abc",
                ],
                "timeout": 1.0,
            },
            stack=stack,
            prefer_remote_urls=False,
        )
        assert hasattr(normalized["images"][0], "read")
        assert normalized["images"][1] == "data:image/jpeg;base64,abc"


def test_normalize_prediction_input_supports_local_path(tmp_path: Path) -> None:
    """Local image paths should be opened as binary file handles."""
    image_path = tmp_path / "input.png"
    Image.new("RGB", (16, 16), color="blue").save(image_path, format="PNG")

    with ExitStack() as stack:
        normalized = _normalize_prediction_input(
            {"image": str(image_path), "timeout": 0.5},
            stack=stack,
        )
        assert hasattr(normalized["image"], "read")


def test_normalize_prediction_input_supports_pil_image() -> None:
    """PIL images should be converted to binary upload buffers."""
    pil_image = Image.new("RGB", (16, 16), color="red")

    with ExitStack() as stack:
        normalized = _normalize_prediction_input(
            {"image": pil_image, "timeout": 0.5},
            stack=stack,
        )
        assert hasattr(normalized["image"], "read")
