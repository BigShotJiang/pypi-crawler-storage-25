"""Tests for provider image-input normalization behavior."""

from __future__ import annotations

from io import BytesIO
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from PIL import Image

from p_moderation.normalize import image_input_to_url
from p_moderation.providers.image_classifier import TransformersImageClassifierProvider
from p_moderation.providers.openai import OpenAIProvider


def _png_bytes() -> bytes:
    image = Image.new("RGB", (24, 24), color="green")
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()


@pytest.mark.asyncio
async def test_openai_provider_uses_shared_image_normalization_for_pil() -> None:
    mock_response = MagicMock()
    mock_response.id = "modr-1"
    mock_response.model = "omni-moderation-latest"
    mock_result = MagicMock()
    mock_result.model_dump.return_value = {
        "flagged": False,
        "categories": {},
        "category_scores": {},
        "category_applied_input_types": {},
    }
    mock_response.results = [mock_result]
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())
    pil_image = Image.new("RGB", (32, 32), color="blue")

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        await provider.moderate(image=pil_image)

    payload = mock_create.await_args.kwargs["input"]
    assert payload[0]["type"] == "image_url"
    assert payload[0]["image_url"]["url"].startswith("data:image/")


def test_image_input_to_url_preserves_png_mime_for_bytes() -> None:
    data_url = image_input_to_url(_png_bytes())
    assert data_url.startswith("data:image/png;base64,")


@pytest.mark.asyncio
async def test_image_classifier_fetches_remote_urls() -> None:
    provider = TransformersImageClassifierProvider()
    provider._ensure_pipeline_and_labels = AsyncMock(  # type: ignore[method-assign]
        return_value=(
            lambda images, batch_size=1: [  # noqa: ARG005
                [{"label": "normal", "score": 0.9}, {"label": "nsfw", "score": 0.1}]
                for _ in images
            ],
            frozenset({"normal", "nsfw"}),
        )
    )

    with patch(
        "p_moderation.providers.image_classifier.fetch_image_url_bytes",
        new_callable=AsyncMock,
        return_value=_png_bytes(),
    ) as mock_fetch:
        response = await provider.moderate(image="https://example.com/image.png")

    assert response.item_results[0].input_type == "image"
    mock_fetch.assert_awaited_once()
