"""Tests for the OpenAI provider adapter."""

from __future__ import annotations

import asyncio
from io import BytesIO
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from PIL import Image

from p_moderation.exceptions import (
    ProviderConfigurationError,
    ProviderDependencyError,
    ProviderResponseShapeError,
)
from p_moderation.providers import openai as openai_provider_module
from p_moderation.providers.openai import OpenAIProvider


def _make_response(*payloads: dict, model: str = "omni-moderation-latest") -> MagicMock:
    response = MagicMock()
    response.id = "modr-1"
    response.model = model
    response.results = []
    for payload in payloads:
        result = MagicMock()
        result.model_dump.return_value = payload
        response.results.append(result)
    return response


def _jpeg_bytes() -> bytes:
    image = Image.new("RGB", (32, 32), color="red")
    buffer = BytesIO()
    image.save(buffer, format="JPEG")
    return buffer.getvalue()


@pytest.mark.asyncio
async def test_openai_provider_maps_text_requests() -> None:
    """Text-only requests should be converted into OpenAI moderation payloads."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        response = await provider.moderate(text="hello")
        await provider.aclose()

    assert response.provider_name == "openai"
    assert response.item_results[0].input_type == "text"
    kwargs = mock_create.await_args.kwargs
    assert kwargs["model"] == "omni-moderation-latest"
    assert kwargs["input"] == [{"type": "text", "text": "hello"}]
    mock_openai.close.assert_awaited_once()


@pytest.mark.asyncio
async def test_openai_submit_returns_completed_with_output() -> None:
    """``submit`` should await moderation and expose the result without polling."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        prediction = await provider.submit(texts=["hello"])
        await provider.aclose()

    assert prediction.status == "completed"
    assert prediction.output is not None
    assert prediction.output.item_results[0].input_type == "text"
    assert await prediction.wait() is prediction.output


@pytest.mark.asyncio
async def test_openai_provider_combined_text_and_image_url_like_sdk() -> None:
    """Match OpenAI ``moderations.create`` with text and https ``image_url``."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())
    image_url = "https://example.com/image.png"
    text = "...text to classify goes here..."

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test", model="omni-moderation-latest")
        await provider.moderate(text=text, image=image_url)

    kwargs = mock_create.await_args.kwargs
    assert kwargs["model"] == "omni-moderation-latest"
    assert kwargs["input"] == [
        {"type": "text", "text": text},
        {"type": "image_url", "image_url": {"url": image_url}},
    ]


@pytest.mark.asyncio
async def test_openai_provider_maps_image_request() -> None:
    """Image bytes should become an OpenAI image_url payload."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        response = await provider.moderate(image=_jpeg_bytes())

    kwargs = mock_create.await_args.kwargs
    assert response.item_results[0].input_type == "image"
    assert kwargs["input"][0]["type"] == "image_url"
    assert kwargs["input"][0]["image_url"]["url"].startswith("data:image/jpeg;base64,")


@pytest.mark.asyncio
async def test_openai_provider_uses_omni_model_for_images() -> None:
    """Image-bearing requests should use the configured omni moderation model."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test", model="omni-moderation-latest")
        await provider.moderate(image=_jpeg_bytes())

    assert mock_create.await_args.kwargs["model"] == "omni-moderation-latest"


@pytest.mark.asyncio
async def test_openai_provider_rejects_image_requests_without_omni_model() -> None:
    """Image requests should fail if the model is not omni-moderation."""
    provider = OpenAIProvider(api_key="sk-test", model="text-moderation-latest")

    with pytest.raises(ProviderConfigurationError, match="requires an omni-moderation model"):
        await provider.moderate(image=_jpeg_bytes())


@pytest.mark.asyncio
async def test_openai_provider_rejects_empty_response() -> None:
    """Empty response should raise a provider error."""
    mock_response = MagicMock()
    mock_response.results = []
    mock_openai = MagicMock(
        moderations=MagicMock(create=AsyncMock(return_value=mock_response)),
        close=AsyncMock(),
    )

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        with pytest.raises(ProviderResponseShapeError, match="contains no results"):
            await provider.moderate(text="hello")


@pytest.mark.asyncio
async def test_openai_provider_requires_input() -> None:
    """OpenAI provider should require at least text or image."""
    provider = OpenAIProvider(api_key="sk-test")

    with pytest.raises(ProviderConfigurationError, match="At least one of text or image"):
        await provider.moderate()


def test_openai_provider_can_build_aiohttp_client() -> None:
    """The provider should pass the aiohttp transport to AsyncOpenAI when requested."""
    mock_openai = MagicMock(moderations=MagicMock(create=AsyncMock()), close=AsyncMock())
    mock_session = MagicMock()

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai) as mock_cls:
        with patch.object(openai_provider_module, "_get_default_aiohttp_client", return_value=mock_session):
            provider = OpenAIProvider(api_key="sk-test", http_backend="aiohttp")
            provider._get_client("sk-test")

    assert mock_cls.call_args.kwargs["http_client"] == mock_session


@pytest.mark.asyncio
async def test_openai_provider_request_coalescing() -> None:
    """Identical concurrent requests should share a single event."""
    mock_response = _make_response(
        {
            "flagged": False,
            "categories": {},
            "category_scores": {},
            "category_applied_input_types": {},
        }
    )
    mock_create = AsyncMock(return_value=mock_response)
    mock_openai = MagicMock(moderations=MagicMock(create=mock_create), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        provider = OpenAIProvider(api_key="sk-test")
        text = "hello"

        # Launch three concurrent moderate calls
        results = await asyncio.gather(
            provider.moderate(text=text),
            provider.moderate(text=text),
            provider.moderate(text=text),
        )

        await provider.aclose()

    # Verify all three got results
    assert len(results) == 3
    assert all(r.provider_name == "openai" for r in results)
    # Verify the event/result_box structure was used (key should not be in _inflight after)
    assert len(provider._inflight) == 0


@pytest.mark.asyncio
async def test_openai_provider_warmup_preconnects() -> None:
    """Warmup should eagerly create client and pre-establish connection."""
    mock_openai = MagicMock(moderations=MagicMock(create=AsyncMock()), close=AsyncMock())
    mock_httpx_client = MagicMock()
    mock_httpx_client.head = AsyncMock()

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai):
        with patch.object(openai_provider_module, "_get_default_http_client", return_value=mock_httpx_client):
            provider = OpenAIProvider(api_key="sk-test")
            await provider.warmup()

    mock_httpx_client.head.assert_awaited_once()
    call_args = mock_httpx_client.head.await_args
    assert call_args.args[0] == "https://api.openai.com"
    assert call_args.kwargs.get("timeout") == 5.0


def test_openai_provider_no_retries_by_default() -> None:
    """OpenAI provider should have no retries by default."""
    provider = OpenAIProvider(api_key="sk-test")
    assert provider._max_retries == 0


@pytest.mark.asyncio
async def test_openai_provider_http2_enabled() -> None:
    """Default httpx client should have HTTP/2 enabled."""
    # This test verifies the httpx client is created with http2=True
    mock_openai = MagicMock(moderations=MagicMock(create=AsyncMock()), close=AsyncMock())

    with patch("p_moderation.providers.openai.AsyncOpenAI", return_value=mock_openai) as mock_cls:
        provider = OpenAIProvider(api_key="sk-test")
        provider._get_client("sk-test")

    # Verify that the httpx client passed has http2 support
    # (We can't directly inspect the http2 kwarg since it's created in _get_default_http_client,
    # but we verify the client was created and passed)
    assert mock_cls.call_args.kwargs.get("http_client") is not None
