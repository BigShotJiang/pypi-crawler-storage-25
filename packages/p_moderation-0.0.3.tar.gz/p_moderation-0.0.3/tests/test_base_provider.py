"""Tests for BaseModerationProvider job lifecycle (submit/retrieve)."""

from __future__ import annotations

import asyncio
import uuid

import pytest

from p_moderation.models import ImageInput, ProviderModerationResponse, ProviderPolicy
from p_moderation.providers.base import BaseModerationProvider


class _DelayProvider(BaseModerationProvider):
    """Minimal provider with configurable delay in ``moderate``."""

    name: str = "delay_stub"
    supports_text: bool = True

    def __init__(self, delay_s: float = 0.08) -> None:
        self._delay_s = delay_s
        self._should_fail: bool = False

    def default_policy(self) -> ProviderPolicy:
        return ProviderPolicy(provider_name=self.name)

    async def moderate(
        self,
        *,
        text: str | None = None,
        image: ImageInput | None = None,
        request_id: str | None = None,
        client_id: str | None = None,
        timeout: float | None = None,
    ) -> ProviderModerationResponse:
        if self._should_fail:
            msg = "intentional moderate failure"
            raise ValueError(msg)
        await asyncio.sleep(self._delay_s)
        return ProviderModerationResponse(
            provider_name=self.name,
            model="stub",
            item_results=[],
        )


@pytest.mark.asyncio
async def test_retrieve_waits_for_inflight_job() -> None:
    """``retrieve`` immediately after ``submit`` must not raise before the task finishes."""
    provider = _DelayProvider(delay_s=0.06)
    prediction = await provider.submit(texts=["x"])
    result = await provider.retrieve(prediction.id)
    assert result.provider_name == "delay_stub"
    assert result.model == "stub"


@pytest.mark.asyncio
async def test_retrieve_rejects_unknown_job_id() -> None:
    """Unknown IDs (never submitted) raise ValueError."""
    provider = _DelayProvider()
    bad_id = str(uuid.uuid4())
    with pytest.raises(ValueError, match="not found"):
        await provider.retrieve(bad_id)


@pytest.mark.asyncio
async def test_retrieve_times_out_if_job_too_slow() -> None:
    provider = _DelayProvider(delay_s=0.2)
    prediction = await provider.submit(texts=["x"])
    with pytest.raises(TimeoutError, match="did not complete"):
        await provider.retrieve(prediction.id, timeout=0.01)


@pytest.mark.asyncio
async def test_retrieve_reraises_moderate_exception() -> None:
    provider = _DelayProvider()
    provider._should_fail = True
    prediction = await provider.submit(texts=["x"])
    with pytest.raises(ValueError, match="intentional"):
        await provider.retrieve(prediction.id)


@pytest.mark.asyncio
async def test_check_status_failed_after_moderate_error() -> None:
    provider = _DelayProvider()
    provider._should_fail = True
    prediction = await provider.submit(texts=["x"])
    for _ in range(50):
        status = await prediction.check_status()
        if status == "failed":
            assert prediction.error is not None
            assert "intentional" in prediction.error
            return
        await asyncio.sleep(0.01)
    msg = "expected failed status"
    raise AssertionError(msg)
