"""Super Agent 数据面 API / Super Agent Data Plane API

继承 :class:`agentrun.utils.data_api.DataAPI`, 复用:

- ``_get_ram_data_endpoint``: RAM ``-ram`` 前缀改写
- ``get_base_url`` / ``with_path``: URL 拼接 (含版本号)
- ``auth``: RAM 签名头生成 (``Agentrun-Authorization`` / ``x-acs-*``)

本文件为 **模板** (``__data_async_template.py``);
当前 ``codegen`` 的 async→sync 转换不支持 async generator (``async for + yield``)
以及 ``async with ... as x`` 里的作用域保留, 所以 ``api/data.py`` 的同步骨架
(同步方法第一版仅保留 ``NotImplementedError`` 占位) 目前 **手工维护**。
运行 ``make codegen`` 会生成不可运行的版本, 请不要直接覆盖。
"""

import json
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional

import httpx

from agentrun.super_agent.api.control import _prune_forwarded_props
from agentrun.super_agent.model import InvokeResponseData
from agentrun.super_agent.stream import parse_sse_async, SSEEvent
from agentrun.utils.config import Config
from agentrun.utils.data_api import DataAPI, ResourceType
from agentrun.utils.log import logger

API_VERSION = "2025-09-10"
SUPER_AGENT_RESOURCE_PATH = "__SUPER_AGENT__"
SUPER_AGENT_NAMESPACE = (
    f"{API_VERSION}/super-agents/{SUPER_AGENT_RESOURCE_PATH}"
)

_SYNC_UNSUPPORTED_MSG = (
    "sync version not supported, use *_async (see decision 14 in"
    " openspec/changes/add-super-agent-sdk/design.md)"
)


class SuperAgentDataAPI(DataAPI):
    """Super Agent 数据面 API (异步主路径 + 同步占位)."""

    def __init__(
        self,
        agent_runtime_name: str,
        config: Optional[Config] = None,
    ):
        super().__init__(
            resource_name=agent_runtime_name,
            resource_type=ResourceType.Runtime,
            namespace=SUPER_AGENT_NAMESPACE,
            config=config,
        )
        self.agent_runtime_name = agent_runtime_name

    def _build_invoke_body(
        self,
        messages: List[Dict[str, Any]],
        conversation_id: Optional[str],
        forwarded_extras: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        # ``forwarded_extras`` 承载从 AgentRuntime 元数据读出的业务字段
        # (prompt/agents/tools/skills/sandboxes/workspaces/modelServiceName/modelName),
        # 由上层 ``SuperAgent.invoke_async`` 注入。``metadata`` 和 ``conversationId``
        # 由 SDK 管理, 不允许 extras 覆盖; 先 prune 掉 extras 里的 None scalar 和
        # 空 list (保留 SDK 即将覆写的 metadata 占位), 再把 SDK 托管字段写入。
        forwarded: Dict[str, Any] = dict(forwarded_extras or {})
        forwarded = _prune_forwarded_props(
            forwarded, keep_keys=("metadata", "conversationId")
        )
        forwarded["metadata"] = {"agentRuntimeName": self.agent_runtime_name}
        if conversation_id is not None:
            forwarded["conversationId"] = conversation_id
        else:
            # 即便用户 extras 里写了 conversationId (被 keep_keys 保留),
            # 外部 SDK 约定 conversation_id=None 时必须不出现。
            forwarded.pop("conversationId", None)
        return {"messages": list(messages), "forwardedProps": forwarded}

    def _parse_invoke_response(
        self, payload: Dict[str, Any]
    ) -> InvokeResponseData:
        if not isinstance(payload, dict):
            raise ValueError(
                "Invalid invoke response: expected object, got"
                f" {type(payload).__name__}"
            )
        data = payload.get("data")
        if not isinstance(data, dict):
            raise ValueError("Invalid invoke response: missing data field")
        conversation_id = data.get("conversationId")
        if not conversation_id:
            raise ValueError(
                "Invalid invoke response: missing conversationId field"
            )
        stream_url = data.get("url")
        if not stream_url:
            raise ValueError("Invalid invoke response: missing url field")
        raw_headers = data.get("headers") or {}
        stream_headers = {str(k): str(v) for k, v in dict(raw_headers).items()}
        return InvokeResponseData(
            conversation_id=str(conversation_id),
            stream_url=str(stream_url),
            stream_headers=stream_headers,
        )

    async def invoke_async(
        self,
        messages: List[Dict[str, Any]],
        conversation_id: Optional[str] = None,
        config: Optional[Config] = None,
        forwarded_extras: Optional[Dict[str, Any]] = None,
    ) -> InvokeResponseData:
        """Phase 1: POST /invoke, 返回 Phase 2 的 URL 与 headers."""
        cfg = Config.with_configs(self.config, config)
        url = self.with_path("invoke", config=cfg)
        body = self._build_invoke_body(
            messages, conversation_id, forwarded_extras
        )
        body_bytes = json.dumps(body).encode("utf-8")
        _, signed_headers, _ = self.auth(
            url=url,
            method="POST",
            headers=cfg.get_headers(),
            body=body_bytes,
            config=cfg,
        )
        signed_headers.setdefault("Content-Type", "application/json")
        logger.debug("super_agent invoke request: POST %s body=%s", url, body)

        async with httpx.AsyncClient(timeout=cfg.get_timeout()) as client:
            resp = await client.post(
                url, headers=signed_headers, content=body_bytes
            )
            resp.raise_for_status()
            payload = resp.json()
        logger.debug(
            "super_agent invoke response: status=%d payload=%s",
            resp.status_code,
            payload,
        )
        return self._parse_invoke_response(payload)

    def invoke(
        self,
        messages: List[Dict[str, Any]],
        conversation_id: Optional[str] = None,
        config: Optional[Config] = None,
        forwarded_extras: Optional[Dict[str, Any]] = None,
    ) -> InvokeResponseData:
        raise NotImplementedError(_SYNC_UNSUPPORTED_MSG)

    async def stream_async(
        self,
        stream_url: str,
        stream_headers: Optional[Dict[str, str]] = None,
        config: Optional[Config] = None,
    ) -> AsyncIterator[SSEEvent]:
        """Phase 2: GET stream_url → 流式 yield SSEEvent.

        合并优先级 (低 → 高): ``cfg.get_headers()`` → ``stream_headers`` → RAM 签名头。
        """
        cfg = Config.with_configs(self.config, config)
        _, signed_headers, _ = self.auth(
            url=stream_url,
            method="GET",
            headers=cfg.get_headers(),
            config=cfg,
        )
        merged_headers: Dict[str, str] = {}
        merged_headers.update(cfg.get_headers())
        if stream_headers:
            merged_headers.update(stream_headers)
        merged_headers.update(signed_headers)

        logger.debug("super_agent stream request: GET %s", stream_url)
        timeout = httpx.Timeout(cfg.get_timeout(), read=None)
        client = httpx.AsyncClient(timeout=timeout)
        try:
            ctx = client.stream("GET", stream_url, headers=merged_headers)
            response = await ctx.__aenter__()
            try:
                response.raise_for_status()
                logger.debug(
                    "super_agent stream response: status=%d headers=%s",
                    response.status_code,
                    dict(response.headers),
                )
                async for event in parse_sse_async(response):
                    logger.debug("super_agent stream event: %s", event)
                    yield event
            finally:
                await ctx.__aexit__(None, None, None)
        finally:
            await client.aclose()

    def stream(
        self,
        stream_url: str,
        stream_headers: Optional[Dict[str, str]] = None,
        config: Optional[Config] = None,
    ) -> Iterator[SSEEvent]:
        raise NotImplementedError(_SYNC_UNSUPPORTED_MSG)

    async def list_conversations_async(
        self,
        metadata: Optional[Dict[str, Any]] = None,
        config: Optional[Config] = None,
    ) -> List[Dict[str, Any]]:
        """GET /conversations → 返回服务端 ``data.conversations`` 数组 (缺失时返回 [])。

        ``metadata`` 若非 None, 会以 JSON 编码后通过 ``metadata`` query 参数下发;
        服务端按该 metadata 过滤 (例如 ``{"agentRuntimeName": "..."}``)。
        不传则由服务端按当前 sub uid 过滤。
        """
        cfg = Config.with_configs(self.config, config)
        query: Optional[Dict[str, Any]] = None
        if metadata is not None:
            query = {"metadata": json.dumps(metadata, ensure_ascii=False)}
        url = self.with_path("conversations", query=query, config=cfg)
        _, signed_headers, _ = self.auth(
            url=url,
            method="GET",
            headers=cfg.get_headers(),
            config=cfg,
        )
        logger.debug("super_agent list_conversations request: GET %s", url)
        async with httpx.AsyncClient(timeout=cfg.get_timeout()) as client:
            resp = await client.get(url, headers=signed_headers)
            resp.raise_for_status()
            payload = resp.json() if resp.text else {}
        logger.debug(
            "super_agent list_conversations response: status=%d payload=%s",
            resp.status_code,
            payload,
        )
        if not isinstance(payload, dict):
            return []
        data = payload.get("data")
        if not isinstance(data, dict):
            return []
        raw_list = data.get("conversations")
        if not isinstance(raw_list, list):
            return []
        return [item for item in raw_list if isinstance(item, dict)]

    def list_conversations(
        self,
        metadata: Optional[Dict[str, Any]] = None,
        config: Optional[Config] = None,
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError(_SYNC_UNSUPPORTED_MSG)

    async def get_conversation_async(
        self,
        conversation_id: str,
        config: Optional[Config] = None,
    ) -> Dict[str, Any]:
        """GET /conversations/{id} → 返回服务端 ``data`` 字段 dict."""
        cfg = Config.with_configs(self.config, config)
        url = self.with_path(f"conversations/{conversation_id}", config=cfg)
        _, signed_headers, _ = self.auth(
            url=url,
            method="GET",
            headers=cfg.get_headers(),
            config=cfg,
        )
        logger.debug("super_agent get_conversation request: GET %s", url)
        async with httpx.AsyncClient(timeout=cfg.get_timeout()) as client:
            resp = await client.get(url, headers=signed_headers)
            resp.raise_for_status()
            payload = resp.json() if resp.text else {}
        logger.debug(
            "super_agent get_conversation response: status=%d payload=%s",
            resp.status_code,
            payload,
        )
        if not isinstance(payload, dict):
            return {}
        data = payload.get("data")
        return data if isinstance(data, dict) else {}

    def get_conversation(
        self,
        conversation_id: str,
        config: Optional[Config] = None,
    ) -> Dict[str, Any]:
        raise NotImplementedError(_SYNC_UNSUPPORTED_MSG)

    async def delete_conversation_async(
        self,
        conversation_id: str,
        config: Optional[Config] = None,
    ) -> None:
        """DELETE /conversations/{id}."""
        cfg = Config.with_configs(self.config, config)
        url = self.with_path(f"conversations/{conversation_id}", config=cfg)
        _, signed_headers, _ = self.auth(
            url=url,
            method="DELETE",
            headers=cfg.get_headers(),
            config=cfg,
        )
        logger.debug("super_agent delete_conversation request: DELETE %s", url)
        async with httpx.AsyncClient(timeout=cfg.get_timeout()) as client:
            resp = await client.delete(url, headers=signed_headers)
            resp.raise_for_status()
        logger.debug(
            "super_agent delete_conversation response: status=%d body=%s",
            resp.status_code,
            resp.text,
        )

    def delete_conversation(
        self,
        conversation_id: str,
        config: Optional[Config] = None,
    ) -> None:
        raise NotImplementedError(_SYNC_UNSUPPORTED_MSG)


__all__ = [
    "API_VERSION",
    "SUPER_AGENT_RESOURCE_PATH",
    "SUPER_AGENT_NAMESPACE",
    "SuperAgentDataAPI",
]
