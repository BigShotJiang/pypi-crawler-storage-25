"""
Shared command line argument definitions for MS2 and MGF extractors.
"""

import argparse
import logging


def add_common_args(parser: argparse.ArgumentParser) -> None:
    """Add common arguments shared between MS2 and MGF extractors."""

    parser.add_argument("analysis_dir", type=str, help="Path to the .D analysis directory")

    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default=None,
        help="Output file path (default: <analysis_dir_name>.<ext>)",
    )

    parser.add_argument(
        "--remove-precursor",
        action="store_true",
        help="Remove precursor peaks from MS/MS spectra",
    )

    parser.add_argument(
        "--precursor-peak-width",
        type=float,
        default=2.0,
        help="Width around precursor m/z to remove (Da)",
    )

    parser.add_argument(
        "--batch-size", type=int, default=100, help="Batch size for processing spectra"
    )

    parser.add_argument(
        "--top-n-peaks",
        type=int,
        default=None,
        help="Keep only top N most intense peaks per spectrum",
    )

    parser.add_argument(
        "--min-spectra-intensity",
        type=float,
        default=None,
        help="Minimum intensity threshold for MS/MS peaks (absolute or relative when within [0.0-1.0] for percentage)",
    )

    parser.add_argument(
        "--max-spectra-intensity",
        type=float,
        default=None,
        help="Maximum intensity threshold for MS/MS peaks (absolute or relative when within [0.0-1.0] for percentage)",
    )

    parser.add_argument(
        "--min-spectra-mz",
        type=float,
        default=None,
        help="Minimum m/z filter for MS/MS peaks",
    )

    parser.add_argument(
        "--max-spectra-mz",
        type=float,
        default=None,
        help="Maximum m/z filter for MS/MS peaks",
    )

    parser.add_argument(
        "--min-precursor-intensity",
        type=float,
        default=None,
        help="Minimum absolute precursor intensity filter",
    )

    parser.add_argument(
        "--max-precursor-intensity",
        type=float,
        default=None,
        help="Maximum absolute precursor intensity filter",
    )

    parser.add_argument(
        "--min-precursor-charge",
        type=int,
        default=None,
        help="Minimum precursor charge state filter",
    )

    parser.add_argument(
        "--max-precursor-charge",
        type=int,
        default=None,
        help="Maximum precursor charge state filter",
    )

    parser.add_argument(
        "--min-precursor-mz",
        type=float,
        default=None,
        help="Minimum precursor m/z filter",
    )

    parser.add_argument(
        "--max-precursor-mz",
        type=float,
        default=None,
        help="Maximum precursor m/z filter",
    )

    parser.add_argument(
        "--min-precursor-rt",
        type=float,
        default=None,
        help="Minimum precursor retention time filter (seconds)",
    )

    parser.add_argument(
        "--max-precursor-rt",
        type=float,
        default=None,
        help="Maximum precursor retention time filter (seconds)",
    )

    parser.add_argument(
        "--min-precursor-ccs",
        type=float,
        default=None,
        help="Minimum precursor CCS filter",
    )

    parser.add_argument(
        "--max-precursor-ccs",
        type=float,
        default=None,
        help="Maximum precursor CCS filter",
    )

    parser.add_argument(
        "--min-precursor-neutral-mass",
        type=float,
        default=None,
        help="Minimum precursor neutral mass filter",
    )

    parser.add_argument(
        "--max-precursor-neutral-mass",
        type=float,
        default=None,
        help="Maximum precursor neutral mass filter",
    )

    parser.add_argument(
        "--mz-precision",
        type=int,
        default=5,
        help="Number of decimal places for m/z values",
    )

    parser.add_argument(
        "--intensity-precision",
        type=int,
        default=0,
        help="Number of decimal places for intensity values",
    )

    parser.add_argument(
        "--keep-empty-spectra",
        action="store_true",
        help="Keep spectra with no peaks (default: False)",
    )

    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")

    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing output file if it exists",
    )

    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of worker threads for processing spectra (default: 1)",
    )


def add_ms2_specific_args(parser: argparse.ArgumentParser) -> None:
    """Add MS2-specific arguments."""

    parser.add_argument(
        "--ip2",
        action="store_true",
        help="Use IP2 Settings",
    )


def add_mgf_specific_args(parser: argparse.ArgumentParser) -> None:
    """Add MGF-specific arguments."""

    parser.add_argument(
        "--casanovo",
        action="store_true",
        help="Use Casanovo preset settings (optimized for de novo sequencing)",
    )


def add_mzml_specific_args(parser: argparse.ArgumentParser) -> None:
    """Add mzML-specific arguments."""

    parser.add_argument(
        "--no-ms1",
        action="store_true",
        help="Skip MS1 spectra and write only MS2 PASEF spectra to the mzML file",
    )

    _COMPRESSORS = [
        "none",
        "zlib",
        "zstd",
        "numpress-linear",
        "numpress-slof",
        "numpress-pic",
    ]
    parser.add_argument(
        "--mz-compression",
        choices=_COMPRESSORS,
        default="zlib",
        help=(
            "Compression for m/z arrays. zstd requires zstandard; numpress-* requires pynumpress."
        ),
    )
    parser.add_argument(
        "--intensity-compression",
        choices=_COMPRESSORS,
        default="zlib",
        help="Compression for intensity arrays.",
    )
    parser.add_argument(
        "--mobility-compression",
        choices=_COMPRESSORS,
        default="zlib",
        help=(
            "Compression for the per-peak mean inverse reduced ion mobility "
            "array written alongside MS1 spectra."
        ),
    )
    # The two encoding flags below correspond to the
    # ``tdfextractor.args.EncodingBitWidth`` Literal type. argparse cannot
    # consume a Literal directly, so the runtime constraint lives in
    # ``choices`` while the static type lives on :class:`MzmlArgs`.
    parser.add_argument(
        "--mz-encoding",
        type=int,
        choices=[32, 64],
        default=64,
        help="Bit width for m/z array values (default: 64).",
    )
    parser.add_argument(
        "--intensity-encoding",
        type=int,
        choices=[32, 64],
        default=32,
        help="Bit width for intensity array values (default: 32).",
    )

    _NOISE_FILTERS = ["none", "mad", "percentile", "histogram", "baseline", "iterative_median"]
    parser.add_argument(
        "--centroid-noise-filter",
        choices=_NOISE_FILTERS,
        default="none",
        help=(
            "Noise filter applied before centroiding. "
            "'none' disables filtering (default); 'mad' uses median absolute deviation."
        ),
    )
    parser.add_argument(
        "--centroid-mz-tolerance",
        type=float,
        default=8.0,
        help="m/z tolerance for peak centroiding (default: 8.0).",
    )
    parser.add_argument(
        "--centroid-mz-tolerance-type",
        choices=["ppm", "da"],
        default="ppm",
        help="Unit for --centroid-mz-tolerance (default: ppm).",
    )
    parser.add_argument(
        "--centroid-im-tolerance",
        type=float,
        default=0.05,
        help="Ion mobility tolerance for peak centroiding (default: 0.05).",
    )
    parser.add_argument(
        "--centroid-im-tolerance-type",
        choices=["relative", "absolute"],
        default="relative",
        help="Unit for --centroid-im-tolerance (default: relative).",
    )
    parser.add_argument(
        "--centroid-min-peaks",
        type=int,
        default=5,
        help="Minimum number of raw peaks required to form a centroided peak (default: 5).",
    )


def create_ms2_parser() -> argparse.ArgumentParser:
    """Create argument parser for MS2 extractor."""

    parser = argparse.ArgumentParser(
        description="Extract MS2 files from TimsTOF .D folders",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    add_common_args(parser)
    add_ms2_specific_args(parser)

    return parser


def create_mgf_parser() -> argparse.ArgumentParser:
    """Create argument parser for MGF extractor."""

    parser = argparse.ArgumentParser(
        description="Extract MGF files from TimsTOF .D folders",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    add_common_args(parser)
    add_mgf_specific_args(parser)

    return parser


def create_mzml_parser() -> argparse.ArgumentParser:
    """Create argument parser for mzML extractor."""

    parser = argparse.ArgumentParser(
        description="Extract mzML files from TimsTOF .D folders (uses psims)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    add_common_args(parser)
    add_mzml_specific_args(parser)

    return parser


def apply_preset_settings(logger: logging.Logger, args: argparse.Namespace) -> None:
    """Apply preset settings based on flags."""

    if hasattr(args, "ip2") and args.ip2:
        # Set IP2 specific defaults
        if args.min_precursor_charge is not None:
            logger.warning(
                f"IP2 preset overridden... setting min_precursor_charge to {args.min_precursor_charge}"
            )
        else:
            args.min_precursor_charge = 2
        if args.top_n_peaks is not None:
            logger.warning(f"IP2 preset overridden... setting top_n_peaks to {args.top_n_peaks}")
        else:
            args.top_n_peaks = 500

    if hasattr(args, "casanovo") and args.casanovo:
        # Set Casanovo specific defaults

        args.remove_precursor = True

        if args.precursor_peak_width is not None:
            logger.warning(
                f"Casanovo preset overridden... setting precursor_peak_width to {args.precursor_peak_width}"
            )
        else:
            args.precursor_peak_width = 2.0

        if args.top_n_peaks is not None:
            logger.warning(
                f"Casanovo preset overridden... setting top_n_peaks to {args.top_n_peaks}"
            )
        else:
            args.top_n_peaks = 150
        if args.min_spectra_intensity is not None:
            logger.warning(
                f"Casanovo preset overridden... setting min_spectra_intensity to {args.min_spectra_intensity}"
            )
        else:
            args.min_spectra_intensity = 0.01

        if args.min_spectra_mz is not None:
            logger.warning(
                f"Casanovo preset overridden... setting min_spectra_mz to {args.min_spectra_mz}"
            )
        else:
            args.min_spectra_mz = 50

        if args.max_spectra_mz is not None:
            logger.warning(
                f"Casanovo preset overroverriddeniden... setting max_spectra_mz to {args.max_spectra_mz}"
            )
        else:
            args.max_spectra_mz = 2500

        if args.min_precursor_intensity is not None:
            logger.warning(
                f"Casanovo preset overridden... setting min_precursor_intensity to {args.min_precursor_intensity}"
            )
        else:
            args.min_precursor_charge = 2


def log_common_args(logger: logging.Logger, args: argparse.Namespace, extractor_type: str) -> None:
    """Log common arguments for both extractors."""

    logger.info(f"{extractor_type} Extractor Arguments:")
    logger.info(f"  Analysis Directory: {args.analysis_dir}")
    logger.info(f"  Output File: {args.output if args.output else 'Within .d folder'}")
    logger.info(f"  Remove Precursor: {args.remove_precursor}")
    logger.info(f"  Precursor Peak Width: {args.precursor_peak_width} Da")
    logger.info(f"  Batch Size: {args.batch_size}")
    logger.info(f"  Top N Peaks: {args.top_n_peaks if args.top_n_peaks is not None else 'All'}")
    logger.info(
        f"  Min Spectra Intensity: {args.min_spectra_intensity if args.min_spectra_intensity is not None else 'None'}"
    )
    logger.info(
        f"  Max Spectra Intensity: {args.max_spectra_intensity if args.max_spectra_intensity is not None else 'None'}"
    )
    logger.info(
        f"  Min Spectra m/z: {args.min_spectra_mz if args.min_spectra_mz is not None else 'None'}"
    )
    logger.info(
        f"  Max Spectra m/z: {args.max_spectra_mz if args.max_spectra_mz is not None else 'None'}"
    )
    logger.info(
        f"  Min Precursor Intensity: {args.min_precursor_intensity if args.min_precursor_intensity is not None else 'None'}"
    )
    logger.info(
        f"  Max Precursor Intensity: {args.max_precursor_intensity if args.max_precursor_intensity is not None else 'None'}"
    )
    logger.info(
        f"  Min Precursor Charge: {args.min_precursor_charge if args.min_precursor_charge is not None else 'None'}"
    )
    logger.info(
        f"  Max Precursor Charge: {args.max_precursor_charge if args.max_precursor_charge is not None else 'None'}"
    )
    logger.info(
        f"  Min Precursor m/z: {args.min_precursor_mz if args.min_precursor_mz is not None else 'None'}"
    )
    logger.info(
        f"  Max Precursor m/z: {args.max_precursor_mz if args.max_precursor_mz is not None else 'None'}"
    )
    logger.info(
        f"  Min Precursor RT: {args.min_precursor_rt if args.min_precursor_rt is not None else 'None'} seconds"
    )
    logger.info(
        f"  Max Precursor RT: {args.max_precursor_rt if args.max_precursor_rt is not None else 'None'} seconds"
    )
    logger.info(
        f"  Min Precursor CCS: {args.min_precursor_ccs if args.min_precursor_ccs is not None else 'None'}"
    )
    logger.info(
        f"  Max Precursor CCS: {args.max_precursor_ccs if args.max_precursor_ccs is not None else 'None'}"
    )
    logger.info(
        f"  Min Precursor Neutral Mass: {args.min_precursor_neutral_mass if args.min_precursor_neutral_mass is not None else 'None'}"
    )
    logger.info(
        f"  Max Precursor Neutral Mass: {args.max_precursor_neutral_mass if args.max_precursor_neutral_mass is not None else 'None'}"
    )
    logger.info(f"  Overwrite Existing Output: {args.overwrite}")
    logger.info(f"  m/z Precision: {args.mz_precision} decimal places")
    logger.info(f"  Intensity Precision: {args.intensity_precision} decimal places")
    logger.info(f"  Keep Empty Spectra: {args.keep_empty_spectra}")
    logger.info(f"  Verbose Logging: {args.verbose}")
    logger.info(f"  Workers: {args.workers}")

    # Log preset-specific settings
    if hasattr(args, "ip2") and args.ip2:
        logger.info(f"  IP2 Settings: {args.ip2}")

    if hasattr(args, "casanovo") and args.casanovo:
        logger.info(f"  Casanovo Preset: {args.casanovo}")

    # mzML-only knobs
    if hasattr(args, "no_ms1"):
        logger.info(f"  Include MS1: {not args.no_ms1}")
    if hasattr(args, "mz_compression"):
        logger.info(f"  m/z Compression: {args.mz_compression}")
    if hasattr(args, "intensity_compression"):
        logger.info(f"  Intensity Compression: {args.intensity_compression}")
    if hasattr(args, "mobility_compression"):
        logger.info(f"  Mobility Compression: {args.mobility_compression}")
    if hasattr(args, "mz_encoding"):
        logger.info(f"  m/z Encoding: {args.mz_encoding}-bit")
    if hasattr(args, "intensity_encoding"):
        logger.info(f"  Intensity Encoding: {args.intensity_encoding}-bit")
