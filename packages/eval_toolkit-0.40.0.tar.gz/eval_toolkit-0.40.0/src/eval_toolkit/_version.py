"""Single lightweight version source."""

__all__ = ["__version__"]

__version__ = "0.40.0"
