"""Tests for protoruf."""
