"""Helpers for scoped state management across the swarm runtime and HTTP APIs."""

from __future__ import annotations

import copy
import re
from typing import Any, Dict, Iterable

from .models import SwarmDefinition, SwarmNode, SwarmSession


INTENT_STACK_KEY = "intent_stack"
INTENT_STATE_KEY = "intent_state"
ACTIVE_INTENT_KEY = "_active_intent"
HANDOFF_CONTEXT_KEY = "_handoff_context"
INTERNAL_GLOBAL_KEYS = {HANDOFF_CONTEXT_KEY, INTENT_STACK_KEY, INTENT_STATE_KEY, ACTIVE_INTENT_KEY}


def _ensure_state(session: SwarmSession) -> Dict[str, Any]:
    state = session.state if isinstance(session.state, dict) else {}
    if state is not session.state:
        session.state = state
    return state


def _intent_namespace(value: str) -> str:
    raw = str(value or "").strip().lower()
    if not raw:
        return "general"
    normalized = re.sub(r"[^a-z0-9_]+", "_", raw)
    normalized = re.sub(r"_+", "_", normalized).strip("_")
    return normalized or "general"


def _get_intent_stack(session: SwarmSession, *, create: bool = False) -> list[dict]:
    state = _ensure_state(session)
    stack = state.get(INTENT_STACK_KEY)
    if isinstance(stack, list):
        cleaned = []
        for item in stack:
            if not isinstance(item, dict):
                continue
            intent = str(item.get("intent") or "").strip()
            target_node_key = str(item.get("target_node_key") or "").strip()
            target_agent = str(item.get("target_agent") or "").strip()
            if intent and target_node_key:
                cleaned.append(
                    {
                        "intent": intent,
                        "target_node_key": target_node_key,
                        "target_agent": target_agent,
                    }
                )
        if len(cleaned) != len(stack):
            state[INTENT_STACK_KEY] = cleaned
        return cleaned
    if not create:
        return []
    state[INTENT_STACK_KEY] = []
    return state[INTENT_STACK_KEY]


def _set_intent_stack(session: SwarmSession, stack: list[dict]) -> None:
    cleaned = []
    for item in stack or []:
        if not isinstance(item, dict):
            continue
        intent = str(item.get("intent") or "").strip()
        target_node_key = str(item.get("target_node_key") or "").strip()
        target_agent = str(item.get("target_agent") or "").strip()
        if intent and target_node_key:
            cleaned.append(
                {
                    "intent": intent,
                    "target_node_key": target_node_key,
                    "target_agent": target_agent,
                }
            )
    _get_intent_stack(session, create=True)
    session.state[INTENT_STACK_KEY] = cleaned


def _pop_next_intent(session: SwarmSession) -> dict | None:
    stack = _get_intent_stack(session, create=False)
    if not stack:
        return None
    next_item = stack.pop(0)
    _set_intent_stack(session, stack)
    return next_item


def _get_intent_state(session: SwarmSession, *, create: bool = False) -> dict:
    session_state = _ensure_state(session)
    scoped_state = session_state.get(INTENT_STATE_KEY)
    if isinstance(scoped_state, dict):
        return scoped_state
    if not create:
        return {}
    session_state[INTENT_STATE_KEY] = {}
    return session_state[INTENT_STATE_KEY]


def _get_active_intent(session: SwarmSession, *, current_node: SwarmNode | None = None, explicit_intent: str | None = None) -> str:
    if explicit_intent:
        return _intent_namespace(explicit_intent)
    state = _ensure_state(session)
    active = str(state.get(ACTIVE_INTENT_KEY) or "").strip()
    if active:
        return _intent_namespace(active)
    if current_node is not None:
        return _intent_namespace(current_node.intent or current_node.name)
    return "general"


def _set_active_intent(session: SwarmSession, *, intent: str | None = None, current_node: SwarmNode | None = None) -> str:
    active_intent = _get_active_intent(session, current_node=current_node, explicit_intent=intent)
    _ensure_state(session)[ACTIVE_INTENT_KEY] = active_intent
    return active_intent


def _get_scoped_state_bucket(
    session: SwarmSession,
    *,
    intent: str | None = None,
    current_node: SwarmNode | None = None,
    create: bool = False,
) -> dict:
    intent_state = _get_intent_state(session, create=create)
    active_intent = _get_active_intent(session, current_node=current_node, explicit_intent=intent)
    bucket = intent_state.get(active_intent)
    if isinstance(bucket, dict):
        return bucket
    if not create:
        return {}
    intent_state[active_intent] = {}
    return intent_state[active_intent]


def _visible_state(session: SwarmSession, *, current_node: SwarmNode | None = None) -> Dict[str, Any]:
    state = _ensure_state(session)
    result = {
        str(key): value
        for key, value in state.items()
        if str(key) not in INTERNAL_GLOBAL_KEYS
    }
    scoped = _get_scoped_state_bucket(session, current_node=current_node, create=False)
    for key, value in scoped.items():
        result[str(key)] = value
    return result


def _get_scoped_variable(session: SwarmSession, key: str, *, current_node: SwarmNode | None = None) -> Any:
    bucket = _get_scoped_state_bucket(session, current_node=current_node, create=False)
    if key in bucket:
        return bucket.get(key)
    return _ensure_state(session).get(key)


def _set_scoped_variable(session: SwarmSession, key: str, value: Any, *, current_node: SwarmNode | None = None) -> None:
    bucket = _get_scoped_state_bucket(session, current_node=current_node, create=True)
    bucket[key] = value
    _ensure_state(session)[key] = value


class SessionStateManager:
    """Centralizes runtime state updates, visibility, and API serialization."""

    def __init__(self, swarm: SwarmDefinition | None = None, *, internal_keys: Iterable[str] | None = None) -> None:
        self._variable_rules: Dict[str, str] = {}
        self._variable_descriptions: Dict[str, str] = {}
        if swarm is not None:
            for variable in swarm.variables:
                self._variable_rules[str(variable.key_name)] = str(variable.reducer_rule or "overwrite")
                self._variable_descriptions[str(variable.key_name)] = str(variable.description or "")
        self._internal_keys = set(internal_keys or INTERNAL_GLOBAL_KEYS)

    @classmethod
    def from_swarm(cls, swarm: SwarmDefinition) -> "SessionStateManager":
        return cls(swarm)

    def rule_for(self, key_name: str) -> str:
        return self._variable_rules.get(str(key_name), "overwrite")

    def resolve_rule(self, key_name: str, *, reducer_rule: str | None = None) -> str:
        resolved = str(reducer_rule or self.rule_for(key_name) or "overwrite").strip().lower()
        return resolved or "overwrite"

    def normalize_value(
        self,
        key: str,
        value: Any,
        *,
        session: SwarmSession,
        current_node: SwarmNode | None = None,
    ) -> Any:
        del key, session, current_node
        return value

    def validate_value(
        self,
        key: str,
        value: Any,
        *,
        session: SwarmSession,
        current_node: SwarmNode | None = None,
        reducer_rule: str,
    ) -> None:
        del key, value, session, current_node, reducer_rule

    def apply_rule(
        self,
        session: SwarmSession,
        key: str,
        value: Any,
        *,
        current_node: SwarmNode | None = None,
        reducer_rule: str,
    ) -> None:
        current = _get_scoped_variable(session, key, current_node=current_node)
        if reducer_rule == "overwrite":
            _set_scoped_variable(session, key, value, current_node=current_node)
            return
        if reducer_rule == "append":
            if isinstance(current, list):
                updated = list(current)
                updated.append(value)
                _set_scoped_variable(session, key, updated, current_node=current_node)
            elif current is None:
                _set_scoped_variable(session, key, [value], current_node=current_node)
            else:
                _set_scoped_variable(session, key, [current, value], current_node=current_node)
            return
        if reducer_rule == "keep_first":
            if current is None:
                _set_scoped_variable(session, key, value, current_node=current_node)
            return
        _set_scoped_variable(session, key, value, current_node=current_node)

    def definitions(self) -> list[Dict[str, Any]]:
        return [
            {
                "key_name": key_name,
                "description": self._variable_descriptions.get(key_name, ""),
                "reducer_rule": self.rule_for(key_name),
            }
            for key_name in sorted(self._variable_rules.keys())
        ]

    def visible(self, session: SwarmSession, *, current_node: SwarmNode | None = None) -> Dict[str, Any]:
        return copy.deepcopy(_visible_state(session, current_node=current_node))

    def visible_state(self, session: SwarmSession, *, current_node: SwarmNode | None = None) -> Dict[str, Any]:
        return self.visible(session, current_node=current_node)

    def scoped(self, session: SwarmSession, *, current_node: SwarmNode | None = None) -> Dict[str, Any]:
        return copy.deepcopy(_get_scoped_state_bucket(session, current_node=current_node, create=False))

    def scoped_state(self, session: SwarmSession, *, current_node: SwarmNode | None = None) -> Dict[str, Any]:
        return self.scoped(session, current_node=current_node)

    def internal(self, session: SwarmSession) -> Dict[str, Any]:
        state = _ensure_state(session)
        return {
            str(key): copy.deepcopy(value)
            for key, value in state.items()
            if str(key) in self._internal_keys
        }

    def internal_state(self, session: SwarmSession) -> Dict[str, Any]:
        return self.internal(session)

    def snapshot(self, session: SwarmSession, *, current_node: SwarmNode | None = None) -> Dict[str, Any]:
        state = _ensure_state(session)
        visible = self.visible(session, current_node=current_node)
        scoped = self.scoped(session, current_node=current_node)
        internal = self.internal(session)
        return {
            "definitions": self.definitions(),
            "visible": visible,
            "visible_state": copy.deepcopy(visible),
            "scoped": scoped,
            "scoped_state": copy.deepcopy(scoped),
            "internal": internal,
            "internal_state": copy.deepcopy(internal),
            "active_intent": _get_active_intent(session, current_node=current_node),
            "intent_stack": copy.deepcopy(_get_intent_stack(session, create=False)),
            "intent_state": copy.deepcopy(_get_intent_state(session, create=False)),
            "raw": copy.deepcopy(state),
            "raw_state": copy.deepcopy(state),
        }

    def get(self, session: SwarmSession, key: str, *, current_node: SwarmNode | None = None) -> Any:
        return copy.deepcopy(_get_scoped_variable(session, key, current_node=current_node))

    def apply_value(
        self,
        session: SwarmSession,
        key: str,
        value: Any,
        *,
        current_node: SwarmNode | None = None,
        reducer_rule: str | None = None,
    ) -> None:
        normalized_key = str(key)
        resolved_rule = self.resolve_rule(normalized_key, reducer_rule=reducer_rule)
        normalized_value = self.normalize_value(
            normalized_key,
            value,
            session=session,
            current_node=current_node,
        )
        self.validate_value(
            normalized_key,
            normalized_value,
            session=session,
            current_node=current_node,
            reducer_rule=resolved_rule,
        )
        self.apply_rule(
            session,
            normalized_key,
            normalized_value,
            current_node=current_node,
            reducer_rule=resolved_rule,
        )

    def apply_updates(
        self,
        session: SwarmSession,
        values: Dict[str, Any] | None,
        *,
        current_node: SwarmNode | None = None,
    ) -> None:
        for key, value in dict(values or {}).items():
            self.apply_value(session, str(key), value, current_node=current_node)

    def update_state(
        self,
        session: SwarmSession,
        values: Dict[str, Any] | None,
        *,
        current_node: SwarmNode | None = None,
    ) -> None:
        self.apply_updates(session, values, current_node=current_node)

    def replace_visible(
        self,
        session: SwarmSession,
        values: Dict[str, Any] | None,
        *,
        current_node: SwarmNode | None = None,
        preserve_internal: bool = True,
    ) -> None:
        preserved = self.internal(session) if preserve_internal else {}
        session.state = copy.deepcopy(preserved)
        self.apply_updates(session, values, current_node=current_node)

    def replace_state(
        self,
        session: SwarmSession,
        values: Dict[str, Any] | None,
        *,
        current_node: SwarmNode | None = None,
        preserve_internal: bool = True,
    ) -> None:
        self.replace_visible(
            session,
            values,
            current_node=current_node,
            preserve_internal=preserve_internal,
        )
GlobalVariableManager = SessionStateManager
_ensure_global_variables = _ensure_state
_visible_global_variables = _visible_state