"""Abstract store interfaces for runtime sessions and checkpoints."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from ..models import SessionCheckpoint, SwarmSession


class SessionStore(ABC):
    """Persistence contract for sessions and checkpoints."""

    @abstractmethod
    async def get_session(self, session_id: str) -> SwarmSession | None:
        """Load a persisted session by id."""

    @abstractmethod
    async def save_session(self, session: SwarmSession) -> SwarmSession:
        """Persist the latest session state."""

    @abstractmethod
    async def append_checkpoint(self, checkpoint: SessionCheckpoint) -> SessionCheckpoint:
        """Persist a new checkpoint."""

    @abstractmethod
    async def list_checkpoints(self, session_id: str) -> List[SessionCheckpoint]:
        """Return checkpoints for a session in step order."""
