"""In-memory runtime persistence for swarm sessions and checkpoints."""

from __future__ import annotations

import copy
from typing import Dict, List

from ..models import SessionCheckpoint, SwarmSession
from .base import SessionStore


class InMemorySessionStore(SessionStore):
    """Simple in-memory implementation of the runtime store contract."""

    def __init__(self) -> None:
        self._sessions: Dict[str, SwarmSession] = {}
        self._checkpoints: Dict[str, List[SessionCheckpoint]] = {}

    async def get_session(self, session_id: str) -> SwarmSession | None:
        session = self._sessions.get(session_id)
        return copy.deepcopy(session) if session is not None else None

    async def save_session(self, session: SwarmSession) -> SwarmSession:
        session.touch()
        self._sessions[session.id] = copy.deepcopy(session)
        return copy.deepcopy(session)

    async def append_checkpoint(self, checkpoint: SessionCheckpoint) -> SessionCheckpoint:
        self._checkpoints.setdefault(checkpoint.session_id, []).append(copy.deepcopy(checkpoint))
        return copy.deepcopy(checkpoint)

    async def list_checkpoints(self, session_id: str) -> List[SessionCheckpoint]:
        checkpoints = self._checkpoints.get(session_id, [])
        return copy.deepcopy(sorted(checkpoints, key=lambda item: item.step_number))
