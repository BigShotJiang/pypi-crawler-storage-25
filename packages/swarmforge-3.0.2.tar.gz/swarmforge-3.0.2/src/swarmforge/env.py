"""Environment helpers for local examples and source usage."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import find_dotenv, load_dotenv

_DOTENV_LOADED = False


def load_local_env() -> None:
    """Load a nearby dotenv file once so examples, tests, and local usage share one config path."""
    global _DOTENV_LOADED
    if _DOTENV_LOADED:
        return
    configured_filename = str(os.getenv("SWARMFORGE_ENV_FILE") or "").strip()
    candidate_filenames = [configured_filename] if configured_filename else [".env"]
    dotenv_path = ""
    for filename in candidate_filenames:
        candidate_path = find_dotenv(filename=filename, usecwd=True)
        if candidate_path and Path(candidate_path).is_file():
            dotenv_path = candidate_path
            break
    load_dotenv(dotenv_path=dotenv_path or None)
    _DOTENV_LOADED = True


def reset_local_env_loader() -> None:
    """Reset the one-time dotenv loader for tests."""
    global _DOTENV_LOADED
    _DOTENV_LOADED = False


def get_env(name: str, *, default: str | None = None, required: bool = False) -> str | None:
    """Read an environment variable after loading the local .env file."""
    load_local_env()
    value = os.getenv(name, default)
    if required and (value is None or value == ""):
        raise ValueError(
            f"Environment variable {name} is required. "
            "Copy .env.example to .env and set it before running this example."
        )
    return value


def get_env_int(name: str, *, default: int) -> int:
    """Read an integer environment variable after loading the local .env file."""
    value = get_env(name)
    if value in {None, ""}:
        return default
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"Environment variable {name} must be an integer, got {value!r}") from exc


def require_env_vars(*names: str) -> dict[str, str]:
    """Return required environment variables or raise with setup guidance."""
    load_local_env()
    values: dict[str, str] = {}
    missing: list[str] = []
    for name in names:
        value = os.getenv(name)
        if value:
            values[name] = value
        else:
            missing.append(name)
    if missing:
        missing_list = ", ".join(sorted(missing))
        raise ValueError(
            f"Missing required environment variables: {missing_list}. "
            "Copy .env.example to .env and set them before running this example."
        )
    return values
