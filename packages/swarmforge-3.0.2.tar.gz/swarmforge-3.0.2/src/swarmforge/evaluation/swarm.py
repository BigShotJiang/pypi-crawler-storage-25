"""Pure helpers for multi-agent swarm scenario generation and scoring."""

from __future__ import annotations

import copy
import json
import re
from collections import deque
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple

from ..swarm.models import SessionCheckpoint
from ._graph import (
    build_graph_snapshot,
    build_node_label_map,
    build_shortest_routing_paths,
    get_all_agent_coverage,
    get_entry_node_snapshot,
    replace_node_keys_with_labels,
)
from ._scoring import (
    aggregate_scenario_results,
    compare_expected_tools,
    compare_expected_variables,
    compare_sequence,
    evaluate_scenario_artifacts,
    extract_actual_tool_calls,
    infer_actual_routing,
    normalize_value,
    serialize_checkpoints,
)


def is_invalid_follow_up_user_beat(beat: str) -> bool:
    lowered = beat.lower()
    invalid_fragments = (
        "remaining objective:",
        "expected routing:",
        "success criteria:",
        "required agent coverage:",
        "conversation plan:",
    )
    if any(fragment in lowered for fragment in invalid_fragments):
        return True
    if re.search(r"\bagent_[0-9a-f]{6,}\b", beat, re.IGNORECASE):
        return True
    if re.search(r"\ban agent\b", lowered):
        return True
    if re.search(r"\bbilling agent\b|\bfaq agent\b|\btechnical agent\b", lowered):
        return True
    return False


def normalize_follow_up_user_beats(value: Any, graph_snapshot: Optional[Dict[str, Any]] = None) -> List[str]:
    candidates = [value] if isinstance(value, str) else value if isinstance(value, list) else []
    normalized: List[str] = []
    for item in candidates:
        beat = str(item or "").strip()
        if graph_snapshot:
            beat = replace_node_keys_with_labels(beat, graph_snapshot)
        if not beat or beat in normalized:
            continue
        if is_invalid_follow_up_user_beat(beat):
            return []
        normalized.append(beat)
    return normalized


def describe_user_need_from_node(node_snapshot: Dict[str, Any]) -> str:
    node_name = str(node_snapshot.get("name") or node_snapshot.get("node_key") or "this").strip().lower()
    intent = str(node_snapshot.get("intent") or "").strip().rstrip(".")
    lowered_intent = intent.lower()

    if "billing" in lowered_intent or "billing" in node_name:
        return "I also have a billing question I need help with."
    if any(keyword in lowered_intent for keyword in ["policy", "faq", "hours", "return"]) or "faq" in node_name:
        return "I also have a general policy question."
    if any(keyword in lowered_intent for keyword in ["technical", "bug", "error", "device"]) or any(
        keyword in node_name for keyword in ["technical", "support", "tech"]
    ):
        return "I also ran into a technical problem in the app."

    if intent:
        intent = re.sub(r"^(handle|manage|process|review|route|answer|provide|resolve)\s+", "", intent, flags=re.IGNORECASE)
        intent = intent[:1].lower() + intent[1:] if intent else ""
        if intent:
            return f"I also need help with {intent}."

    return f"I also have another question related to {node_name}."


def build_default_follow_up_user_beats(
    graph_snapshot: Dict[str, Any],
    required_agent_coverage: List[str],
    primary_agent_key: str = "",
) -> List[str]:
    entry_node_key = get_entry_node_snapshot(graph_snapshot)["node_key"]
    node_by_key = {
        str(node.get("node_key") or "").strip(): node
        for node in (graph_snapshot.get("nodes") or [])
        if str(node.get("node_key") or "").strip()
    }
    ordered_keys = [key for key in required_agent_coverage if key and key not in {primary_agent_key, entry_node_key}]

    beats: List[str] = []
    for node_key in ordered_keys:
        node_snapshot = node_by_key.get(node_key)
        if node_snapshot is None:
            continue
        beat = describe_user_need_from_node(node_snapshot)
        if beat not in beats:
            beats.append(beat)
    return beats


def build_scenario_follow_up_user_beats(
    graph_snapshot: Dict[str, Any],
    scenario_seed: Dict[str, Any],
) -> List[str]:
    explicit_beats = normalize_follow_up_user_beats(scenario_seed.get("follow_up_user_beats"), graph_snapshot)
    if explicit_beats:
        return explicit_beats

    expected_routing = [str(item).strip() for item in (scenario_seed.get("expected_routing") or []) if str(item).strip()]
    primary_agent_key = expected_routing[-1] if expected_routing else ""
    required_agent_coverage = [
        str(item).strip()
        for item in (scenario_seed.get("required_agent_coverage") or get_all_agent_coverage(graph_snapshot))
        if str(item).strip()
    ]
    return build_default_follow_up_user_beats(graph_snapshot, required_agent_coverage, primary_agent_key)


def build_edge_adjacency(graph_snapshot: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    adjacency: Dict[str, List[Dict[str, Any]]] = {}
    entry_node_key = get_entry_node_snapshot(graph_snapshot)["node_key"]
    node_keys = {
        str(node.get("node_key") or "").strip()
        for node in (graph_snapshot.get("nodes") or [])
        if str(node.get("node_key") or "").strip()
    }
    explicit_targets_by_source: Dict[str, set[str]] = {}

    for edge in graph_snapshot.get("edges") or []:
        source_key = str(edge.get("source_node_key") or "").strip()
        if not source_key:
            continue
        target_key = str(edge.get("target_node_key") or "").strip()
        adjacency.setdefault(source_key, []).append(edge)
        explicit_targets_by_source.setdefault(source_key, set())
        if target_key:
            explicit_targets_by_source[source_key].add(target_key)

    for node_key in node_keys:
        if not node_key or node_key == entry_node_key:
            continue
        if entry_node_key in explicit_targets_by_source.get(node_key, set()):
            continue
        adjacency.setdefault(node_key, []).append(
            {
                "source_node_key": node_key,
                "target_node_key": entry_node_key,
                "required_variables": [],
                "handoff_description": "Implicit reroute to entry node for re-triage.",
                "implicit_reroute": True,
            }
        )

    return adjacency


def find_edge_path(
    graph_snapshot: Dict[str, Any],
    start_node_key: str,
    end_node_key: str,
) -> Optional[List[Dict[str, Any]]]:
    if start_node_key == end_node_key:
        return []

    adjacency = build_edge_adjacency(graph_snapshot)
    queue: deque[Tuple[str, List[Dict[str, Any]]]] = deque([(start_node_key, [])])
    visited = {start_node_key}

    while queue:
        current_key, edge_path = queue.popleft()
        for edge in adjacency.get(current_key, []):
            next_key = str(edge.get("target_node_key") or "").strip()
            if not next_key or next_key in visited:
                continue
            next_path = edge_path + [edge]
            if next_key == end_node_key:
                return next_path
            visited.add(next_key)
            queue.append((next_key, next_path))

    return None


def classify_scenario_feasibility(
    graph_snapshot: Dict[str, Any],
    scenario_seed: Dict[str, Any],
) -> Dict[str, Any]:
    node_keys = {
        str(node.get("node_key") or "").strip()
        for node in (graph_snapshot.get("nodes") or [])
        if str(node.get("node_key") or "").strip()
    }
    entry_node_key = get_entry_node_snapshot(graph_snapshot)["node_key"]
    required_agent_coverage = [
        str(item).strip()
        for item in (scenario_seed.get("required_agent_coverage") or [])
        if str(item).strip()
    ]
    expected_routing = [
        str(item).strip()
        for item in (scenario_seed.get("expected_routing") or [])
        if str(item).strip()
    ]
    target_sequence = required_agent_coverage or expected_routing or [entry_node_key]
    if target_sequence[0] != entry_node_key:
        target_sequence = [entry_node_key] + target_sequence

    referenced_nodes = [node for node in list(dict.fromkeys(target_sequence + expected_routing)) if node]
    missing_nodes = [node for node in referenced_nodes if node not in node_keys]
    if missing_nodes:
        return {
            "status": "impossible",
            "missing_nodes": missing_nodes,
            "required_variables": [],
            "target_sequence": target_sequence,
            "resolved_paths": [],
            "reason": "scenario_references_unknown_nodes",
        }

    resolved_paths: List[List[str]] = []
    required_variables: List[str] = []
    for source_key, target_key in zip(target_sequence, target_sequence[1:]):
        edge_path = find_edge_path(graph_snapshot, source_key, target_key)
        if edge_path is None:
            return {
                "status": "impossible",
                "missing_nodes": [],
                "required_variables": required_variables,
                "target_sequence": target_sequence,
                "resolved_paths": resolved_paths,
                "reason": f"no_path:{source_key}->{target_key}",
            }
        if not edge_path:
            resolved_paths.append([source_key])
            continue
        resolved_paths.append([source_key] + [str(edge.get("target_node_key") or "").strip() for edge in edge_path])
        for edge in edge_path:
            for variable in edge.get("required_variables") or []:
                normalized_variable = str(variable or "").strip()
                if normalized_variable and normalized_variable not in required_variables:
                    required_variables.append(normalized_variable)

    return {
        "status": "conditionally_feasible" if required_variables else "feasible",
        "missing_nodes": [],
        "required_variables": required_variables,
        "target_sequence": target_sequence,
        "resolved_paths": resolved_paths,
        "reason": "requires_handoff_variables" if required_variables else "graph_supports_requested_coverage",
    }


def build_heuristic_swarm_scenario_seeds(
    graph_snapshot: Dict[str, Any],
    num_scenarios: int,
    min_turns: int,
) -> List[Dict[str, Any]]:
    nodes = list(graph_snapshot.get("nodes") or [])
    if not nodes:
        raise ValueError("Cannot generate scenarios for a swarm with no nodes.")

    entry_node = get_entry_node_snapshot(graph_snapshot)
    entry_node_key = entry_node["node_key"]
    routing_paths = build_shortest_routing_paths(graph_snapshot, entry_node_key)
    required_agent_coverage = get_all_agent_coverage(graph_snapshot)
    ordered_nodes = sorted(
        nodes,
        key=lambda node: (0 if node.get("is_entry_node") else 1, node.get("name") or node.get("node_key") or ""),
    )

    scenario_seeds: List[Dict[str, Any]] = []
    for node_snapshot in ordered_nodes:
        node_key = node_snapshot["node_key"]
        node_name = (node_snapshot.get("name") or node_key).strip()
        node_intent = (node_snapshot.get("intent") or "").strip()
        routing = routing_paths.get(node_key) or [entry_node_key, node_key]
        label_map = build_node_label_map(graph_snapshot)
        coverage_labels = [label_map.get(agent_key, agent_key) for agent_key in required_agent_coverage]
        routing_labels = [label_map.get(agent_key, agent_key) for agent_key in routing]

        goal_text = node_intent or f"reach the {node_name} agent"
        conversation_plan_parts = [
            f"Initial user goal: {goal_text}.",
            f"Turn flow: start with one focused request, then introduce follow-up details that naturally drive the conversation through {' -> '.join(coverage_labels)}.",
            f"Expected routing direction: {' -> '.join(routing_labels)}.",
            "The initial starting_prompt must be only the first user task, not the full workflow or all steps at once.",
        ]
        if node_snapshot.get("enabled_tools"):
            conversation_plan_parts.append("Use tools only when the target agent would realistically need them.")

        success_criteria = [
            f"Route through {' -> '.join(routing_labels)}.",
            f"{node_name} should own the final response.",
            f"Every specialist in the swarm must participate at least once: {', '.join(coverage_labels)}.",
        ]

        starting_prompt = node_intent or f"I need help with {node_name.lower()}."
        if node_snapshot.get("is_entry_node"):
            starting_prompt = node_intent or f"I need help from the {node_name.lower()} workflow."

        scenario_seeds.append(
            {
                "starting_prompt": starting_prompt,
                "conversation_plan": " ".join(conversation_plan_parts),
                "follow_up_user_beats": build_default_follow_up_user_beats(
                    graph_snapshot,
                    required_agent_coverage,
                    node_key,
                ),
                "min_turns": max(1, min_turns, len(required_agent_coverage)),
                "success_criteria": success_criteria,
                "expected_routing": routing,
                "required_agent_coverage": required_agent_coverage,
                "expected_variables": {},
                "expected_tools": [],
            }
        )
        if len(scenario_seeds) >= num_scenarios:
            break

    while len(scenario_seeds) < num_scenarios:
        scenario_seeds.append(copy.deepcopy(scenario_seeds[len(scenario_seeds) % len(scenario_seeds)]))

    return scenario_seeds[:num_scenarios]


def build_heuristic_swarm_intents(
    graph_snapshot: Dict[str, Any],
    num_intents: int,
) -> List[Dict[str, str]]:
    nodes = list(graph_snapshot.get("nodes") or [])
    if not nodes:
        raise ValueError("Cannot generate intents for a swarm with no nodes.")

    ordered_nodes = sorted(
        nodes,
        key=lambda node: (0 if node.get("is_entry_node") else 1, node.get("name") or node.get("node_key") or ""),
    )

    intents: List[Dict[str, str]] = []
    seen_titles: set[str] = set()
    for node_snapshot in ordered_nodes:
        raw_title = str(node_snapshot.get("intent") or "").strip() or f"Get help from {(node_snapshot.get('name') or node_snapshot.get('node_key') or 'this workflow').strip()}"
        title = replace_node_keys_with_labels(re.sub(r"\s+", " ", raw_title).strip().rstrip("."), graph_snapshot)
        if not title or title.lower() in seen_titles:
            continue
        seen_titles.add(title.lower())
        intents.append({"id": f"intent_{len(intents) + 1}", "title": title})
        if len(intents) >= num_intents:
            break

    while intents and len(intents) < num_intents:
        duplicated = copy.deepcopy(intents[len(intents) % len(intents)])
        duplicated["id"] = f"intent_{len(intents) + 1}"
        intents.append(duplicated)

    return intents[:num_intents]


def build_swarm_scenario_generation_context(graph_snapshot: Dict[str, Any]) -> str:
    nodes = graph_snapshot.get("nodes") or []
    edges = graph_snapshot.get("edges") or []
    variables = graph_snapshot.get("variables") or []

    node_lines = [
        f"- {node['node_key']} ({node.get('name') or node['node_key']}) | intent: {(node.get('intent') or '').strip() or 'n/a'} | entry: {'yes' if node.get('is_entry_node') else 'no'}"
        for node in nodes
    ]
    edge_lines = [
        f"- {edge['source_node_key']} -> {edge['target_node_key']} | required vars: {', '.join(edge.get('required_variables') or []) or 'none'} | handoff: {(edge.get('handoff_description') or '').strip() or 'n/a'}"
        for edge in edges
    ]
    variable_lines = [
        f"- {variable['key_name']} | reducer: {(variable.get('reducer_rule') or 'overwrite')} | description: {(variable.get('description') or '').strip() or 'n/a'}"
        for variable in variables
    ]
    swarm_name = (graph_snapshot.get("swarm") or {}).get("name") or "Unnamed swarm"
    return "\n".join(
        [
            f"Swarm name: {swarm_name}",
            "Nodes:",
            *(node_lines or ["- none"]),
            "Edges:",
            *(edge_lines or ["- none"]),
            "Variables:",
            *(variable_lines or ["- none"]),
        ]
    )


def normalize_swarm_intent_titles(intents: Any, graph_snapshot: Dict[str, Any]) -> List[str]:
    if not isinstance(intents, list):
        return []
    normalized: List[str] = []
    for item in intents:
        raw_title = item.get("title") if isinstance(item, dict) else item
        title = replace_node_keys_with_labels(str(raw_title or "").strip(), graph_snapshot)
        title = re.sub(r"^\d+[\).:\-\s]+", "", title).strip().rstrip(".")
        if title and title not in normalized:
            normalized.append(title)
    return normalized


def intent_title_to_starting_prompt(title: str) -> str:
    normalized = str(title or "").strip().rstrip(".")
    if not normalized:
        return "I need help with this request."
    lowered = normalized.lower()
    prefixes = ("i ", "my ", "can ", "could ", "would ", "will ", "what ", "why ", "how ", "when ", "where ", "is ", "are ", "do ", "does ", "did ")
    if lowered.startswith(prefixes):
        return f"{normalized}{'' if normalized.endswith(('?', '.')) else '?'}"
    return f"I need help with {normalized[:1].lower()}{normalized[1:]}."


def build_intent_based_swarm_scenario_seeds(
    graph_snapshot: Dict[str, Any],
    intents: List[str],
    num_scenarios: int,
    min_turns: int,
) -> List[Dict[str, Any]]:
    templates = build_heuristic_swarm_scenario_seeds(graph_snapshot, num_scenarios, min_turns)
    cleaned_intents = normalize_swarm_intent_titles(intents, graph_snapshot)
    if not cleaned_intents:
        return templates

    seeds: List[Dict[str, Any]] = []
    for index in range(num_scenarios):
        template = copy.deepcopy(templates[index % len(templates)])
        intent_title = cleaned_intents[index % len(cleaned_intents)]
        template["starting_prompt"] = intent_title_to_starting_prompt(intent_title)
        template["conversation_plan"] = f"Primary user intent: {intent_title}. {template.get('conversation_plan') or ''}".strip()
        success_criteria = list(template.get("success_criteria") or [])
        template["success_criteria"] = [f"Address the user intent: {intent_title}.", *success_criteria]
        seeds.append(template)
    return seeds


def parse_json_string(value: Any, fallback: Any) -> Any:
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return fallback
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            return fallback
    return fallback


def normalize_generated_expected_variables(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if not isinstance(value, list):
        return {}
    normalized: Dict[str, Any] = {}
    for item in value:
        if not isinstance(item, dict):
            continue
        key = str(item.get("key") or "").strip()
        if key:
            normalized[key] = parse_json_string(item.get("value_json"), item.get("value_json"))
    return normalized


def normalize_generated_expected_tools(value: Any) -> List[Dict[str, Any]]:
    if not isinstance(value, list):
        return []
    normalized: List[Dict[str, Any]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        if name:
            normalized.append({"name": name, "arguments": parse_json_string(item.get("arguments_json"), {})})
    return normalized


def normalize_generated_swarm_scenario_seeds(
    seeds: Any,
    graph_snapshot: Dict[str, Any],
    num_scenarios: int,
    min_turns: int,
    required_agent_coverage: List[str],
) -> List[Dict[str, Any]]:
    if not isinstance(seeds, list):
        return []
    normalized = []
    for seed in seeds[:num_scenarios]:
        if not isinstance(seed, dict):
            continue
        starting_prompt = str(seed.get("starting_prompt") or "").strip()
        conversation_plan = replace_node_keys_with_labels(str(seed.get("conversation_plan") or "").strip(), graph_snapshot)
        follow_up_user_beats = normalize_follow_up_user_beats(seed.get("follow_up_user_beats"), graph_snapshot)
        raw_min_turns = seed.get("min_turns", min_turns)
        expected_routing = [str(item).strip() for item in (seed.get("expected_routing") or []) if str(item).strip()]
        normalized_required_agent_coverage = [
            str(item).strip()
            for item in (seed.get("required_agent_coverage") or required_agent_coverage)
            if str(item).strip()
        ]
        if not starting_prompt or not conversation_plan or not expected_routing:
            continue
        if len(starting_prompt) > 280:
            continue
        try:
            normalized_min_turns = max(int(raw_min_turns), min_turns, len(normalized_required_agent_coverage), 1)
        except (TypeError, ValueError):
            normalized_min_turns = max(1, min_turns, len(normalized_required_agent_coverage))
        normalized.append(
            {
                "starting_prompt": starting_prompt,
                "conversation_plan": conversation_plan,
                "follow_up_user_beats": follow_up_user_beats,
                "min_turns": normalized_min_turns,
                "success_criteria": [
                    replace_node_keys_with_labels(str(item).strip(), graph_snapshot)
                    for item in (seed.get("success_criteria") or [])
                    if str(item).strip()
                ],
                "expected_routing": expected_routing,
                "required_agent_coverage": normalized_required_agent_coverage,
                "expected_variables": normalize_generated_expected_variables(seed.get("expected_variables")),
                "expected_tools": normalize_generated_expected_tools(seed.get("expected_tools")),
            }
        )
    return normalized


def sanitize_turn_context_for_simulator(turn_context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    turn_context = turn_context or {}
    requested_fields: List[str] = []
    for handoff_detail in turn_context.get("handoff_details") or []:
        for field_name in (handoff_detail.get("missing_variables") or []):
            normalized = str(field_name or "").strip()
            if normalized and normalized not in requested_fields:
                requested_fields.append(normalized)
    return {
        "requested_fields": requested_fields,
        "transfer_requested": bool(turn_context.get("transfer_requested")),
        "handoff_occurred": bool(turn_context.get("handoff_occurred")),
        "handoff_blocked": bool(turn_context.get("handoff_blocked")),
    }


def classify_assistant_turn(latest_assistant_message: str, turn_context: Optional[Dict[str, Any]] = None) -> str:
    turn_context = turn_context or {}
    if turn_context.get("requested_fields"):
        return "request_fields"
    if turn_context.get("transfer_requested") or turn_context.get("handoff_occurred"):
        return "handoff"
    if "?" in str(latest_assistant_message or ""):
        return "question"
    if str(latest_assistant_message or "").strip():
        return "informational"
    return "empty"


def build_simulator_context(
    scenario_seed: Dict[str, Any],
    latest_assistant_message: str,
    turn_context: Optional[Dict[str, Any]],
    force_continue: bool,
    pending_follow_up_user_beats: Optional[List[str]] = None,
    consumed_follow_up_user_beats: Optional[List[str]] = None,
    turn_number: int = 0,
    min_turn_target: int = 1,
    intent_shift_allowed: bool = True,
) -> Dict[str, Any]:
    sanitized_turn_context = sanitize_turn_context_for_simulator(turn_context)
    assistant_turn_kind = classify_assistant_turn(latest_assistant_message, sanitized_turn_context)
    return {
        "user_goal": str(scenario_seed.get("starting_prompt") or "").strip(),
        "conversation_plan": str(scenario_seed.get("conversation_plan") or "").strip(),
        "latest_assistant_message": latest_assistant_message.strip(),
        "requested_fields": sanitized_turn_context["requested_fields"],
        "transfer_requested": sanitized_turn_context["transfer_requested"],
        "handoff_occurred": sanitized_turn_context["handoff_occurred"],
        "handoff_blocked": sanitized_turn_context["handoff_blocked"],
        "assistant_turn_kind": assistant_turn_kind,
        "awaiting_user_reply": assistant_turn_kind in {"request_fields", "question"},
        "force_continue": force_continue,
        "pending_follow_up_user_beats": list(pending_follow_up_user_beats or []),
        "consumed_follow_up_user_beats": list(consumed_follow_up_user_beats or []),
        "turn_number": turn_number,
        "min_turn_target": min_turn_target,
        "intent_shift_allowed": bool(intent_shift_allowed),
    }


def _normalize_free_text(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\s]", " ", str(value or "").lower())).strip()


def determine_next_user_input(
    *,
    signal: str,
    next_user_input: Optional[str],
    follow_up_user_beats: List[str],
    next_beat_index: int,
    missing_agents: List[str],
    needs_more_turns: bool,
    plan_progression_locked: bool = False,
    allow_follow_up_progression: bool = True,
) -> Tuple[Optional[str], str, int]:
    generated_input = str(next_user_input or "").strip()
    if generated_input:
        advanced_beat_index = next_beat_index
        if not plan_progression_locked and next_beat_index < len(follow_up_user_beats):
            current_beat = str(follow_up_user_beats[next_beat_index] or "").strip()
            normalized_generated = _normalize_free_text(generated_input)
            normalized_beat = _normalize_free_text(current_beat)
            similarity = SequenceMatcher(None, normalized_generated, normalized_beat).ratio() if normalized_generated and normalized_beat else 0.0
            if normalized_generated == normalized_beat or similarity >= 0.78:
                advanced_beat_index += 1
        return generated_input, "simulator_generated", advanced_beat_index

    if plan_progression_locked or not allow_follow_up_progression:
        if signal == "STOP" and (needs_more_turns or missing_agents):
            return "I'm still focused on this issue. What should I provide next?", "locked_fallback", next_beat_index
        return None, "stop", next_beat_index

    if next_beat_index < len(follow_up_user_beats) and (signal == "STOP" or needs_more_turns or missing_agents):
        return follow_up_user_beats[next_beat_index], "follow_up_beat", next_beat_index + 1

    return None, "stop", next_beat_index

