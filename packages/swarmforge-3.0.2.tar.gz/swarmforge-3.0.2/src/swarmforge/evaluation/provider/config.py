"""Model configuration for OpenAI-compatible endpoints."""

from __future__ import annotations

import os
import re
from typing import Any, Match

from swarmforge.env import load_local_env

DEFAULT_LLM_MODEL = "openrouter/auto"
DEFAULT_PROVIDER = "openrouter"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


def _load_local_env() -> None:
    """Load a nearby .env once so local development works without manual exports."""
    load_local_env()


def get_default_model_name() -> str:
    _load_local_env()
    return (
        os.getenv("llm_model")
        or os.getenv("LLM_MODEL")
        or DEFAULT_LLM_MODEL
    )


def get_default_provider() -> str:
    _load_local_env()
    return (
        os.getenv("model_provider")
        or os.getenv("MODEL_PROVIDER")
        or DEFAULT_PROVIDER
    )


def _parse_csv_list(raw_value: str | None) -> list[str]:
    if not raw_value:
        return []
    return [item.strip() for item in raw_value.split(",") if item.strip()]


def get_openrouter_fallback_models() -> list[str]:
    """Return OpenRouter fallback models from environment configuration."""
    _load_local_env()
    return _parse_csv_list(
        os.getenv("OPENROUTER_FALLBACK_MODELS")
        or os.getenv("openrouter_fallback_models")
    )


def resolve_env_var(value: str) -> str:
    """Resolve ${ENV_VAR} syntax in API keys."""
    _load_local_env()
    pattern = r"\$\{([^}]+)\}"

    def replace(match: Match[str]) -> str:
        env_var = match.group(1)
        env_value = os.getenv(env_var)
        if env_value is None:
            raise ValueError(f"Environment variable {env_var} is not set")
        return env_value

    return re.sub(pattern, replace, value)


def get_api_key_for_provider(provider: str, api_key: str | None = None) -> str:
    """Resolve the API key from input or provider-specific environment variables."""
    _load_local_env()
    if api_key:
        return resolve_env_var(api_key)

    provider_lower = provider.lower()
    if provider_lower == "openrouter":
        env_key = os.getenv("OPENROUTER_API_KEY")
        if env_key:
            return env_key
        raise ValueError(
            "API key not provided and OPENROUTER_API_KEY environment variable is not set"
        )

    if provider_lower in {"gemini", "google"}:
        env_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
        if env_key:
            return env_key
        raise ValueError(
            "API key not provided and GOOGLE_API_KEY or GEMINI_API_KEY environment variable is not set"
        )

    if provider_lower == "openai":
        env_key = os.getenv("OPENAI_API_KEY")
        if env_key:
            return env_key
        raise ValueError(
            "API key not provided and OPENAI_API_KEY environment variable is not set"
        )

    env_key = os.getenv(f"{provider.upper()}_API_KEY")
    if env_key:
        return env_key
    raise ValueError(
        f"API key not provided and {provider.upper()}_API_KEY environment variable is not set"
    )


def get_base_url_for_provider(provider: str, base_url: str | None = None) -> str:
    """Return the provider-specific OpenAI-compatible base URL."""
    if base_url:
        return base_url

    provider_lower = provider.lower()
    if provider_lower == "openrouter":
        return OPENROUTER_BASE_URL
    if provider_lower in {"gemini", "google"}:
        return "https://generativelanguage.googleapis.com/v1beta/openai/"
    if provider_lower == "openai":
        return "https://api.openai.com/v1"
    return "https://api.openai.com/v1"


def get_default_headers_for_provider(
    provider: str,
    *,
    site_url: str | None = None,
    app_name: str | None = None,
    default_headers: dict[str, str] | None = None,
) -> dict[str, str]:
    """Return provider-specific default headers."""
    _load_local_env()
    headers = dict(default_headers or {})
    if provider.lower() != "openrouter":
        return headers

    resolved_site_url = (
        site_url
        or os.getenv("OPENROUTER_SITE_URL")
        or os.getenv("OPENROUTER_HTTP_REFERER")
        or os.getenv("OPENROUTER_APP_URL")
    )
    resolved_app_name = (
        app_name
        or os.getenv("OPENROUTER_APP_NAME")
        or os.getenv("OPENROUTER_X_TITLE")
    )

    if resolved_site_url:
        headers.setdefault("HTTP-Referer", resolved_site_url)
    if resolved_app_name:
        headers.setdefault("X-OpenRouter-Title", resolved_app_name)
    return headers


class ModelConfig:
    """Configuration for an OpenAI-compatible model endpoint."""

    def __init__(
        self,
        provider: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        site_url: str | None = None,
        app_name: str | None = None,
        default_headers: dict[str, str] | None = None,
        default_chat_params: dict[str, Any] | None = None,
        fallback_models: list[str] | None = None,
    ) -> None:
        resolved_provider = provider or get_default_provider()
        resolved_model = model or get_default_model_name()
        self.provider = resolved_provider
        self.base_url = get_base_url_for_provider(resolved_provider, base_url)
        self.api_key = get_api_key_for_provider(resolved_provider, api_key)
        self.model = resolved_model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.default_headers = get_default_headers_for_provider(
            resolved_provider,
            site_url=site_url,
            app_name=app_name,
            default_headers=default_headers,
        )
        self.default_chat_params = dict(default_chat_params or {})
        parsed_fallbacks = fallback_models
        if parsed_fallbacks is None and resolved_provider.lower() == "openrouter":
            parsed_fallbacks = get_openrouter_fallback_models()
        self.fallback_models = [
            candidate for candidate in (parsed_fallbacks or []) if candidate != resolved_model
        ]
