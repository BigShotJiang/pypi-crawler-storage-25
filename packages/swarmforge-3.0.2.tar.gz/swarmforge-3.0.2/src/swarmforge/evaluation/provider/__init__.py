"""Provider configuration and OpenAI-compatible clients."""

from .client import OpenAIClientWrapper
from .config import ModelConfig, OPENROUTER_BASE_URL

__all__ = ["ModelConfig", "OPENROUTER_BASE_URL", "OpenAIClientWrapper"]
