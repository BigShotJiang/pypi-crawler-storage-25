"""Shared graph snapshot helpers for swarm evaluation."""

from __future__ import annotations

from collections import deque
from typing import Any, Dict, List

from ..swarm.models import SwarmDefinition, serialize_system_prompt
from ..swarm.tools import sanitize_tool_definitions


def build_graph_snapshot(swarm: SwarmDefinition) -> Dict[str, Any]:
    nodes = []
    for node in swarm.nodes:
        node_snapshot = {
            "id": node.id,
            "node_key": node.node_key,
            "name": node.name,
            "persona": node.persona,
            "system_prompt": serialize_system_prompt(node.system_prompt),
            "model_choice": node.model_choice,
            "enabled_tools": sanitize_tool_definitions(node.enabled_tools or []),
            "behavior_config": node.behavior_config.to_dict(),
            "is_entry_node": node.is_entry_node,
        }
        if str(node.intent or "").strip():
            node_snapshot["intent"] = node.intent
        if list(node.capabilities or []):
            node_snapshot["capabilities"] = list(node.capabilities or [])
        nodes.append(node_snapshot)

    return {
        "swarm": {
            "id": swarm.id,
            "name": swarm.name,
            "graph_version": swarm.graph_version,
        },
        "nodes": nodes,
        "edges": [
            {
                "id": edge.id,
                "source_node_key": swarm.node_by_id(edge.source_node_id).node_key if swarm.node_by_id(edge.source_node_id) else "",
                "target_node_key": swarm.node_by_id(edge.target_node_id).node_key if swarm.node_by_id(edge.target_node_id) else "",
                "required_variables": list(edge.required_variables or []),
                "handoff_description": edge.handoff_description,
            }
            for edge in swarm.edges
        ],
        "variables": [
            {
                "key_name": variable.key_name,
                "description": variable.description,
                "reducer_rule": variable.reducer_rule,
            }
            for variable in swarm.variables
        ],
    }


def build_shortest_routing_paths(graph_snapshot: Dict[str, Any], entry_node_key: str) -> Dict[str, List[str]]:
    adjacency: Dict[str, List[str]] = {}
    for edge in graph_snapshot.get("edges") or []:
        adjacency.setdefault(edge["source_node_key"], []).append(edge["target_node_key"])

    paths: Dict[str, List[str]] = {entry_node_key: [entry_node_key]}
    queue: deque[str] = deque([entry_node_key])

    while queue:
        current_key = queue.popleft()
        current_path = paths[current_key]
        for next_key in adjacency.get(current_key, []):
            if next_key in paths:
                continue
            paths[next_key] = current_path + [next_key]
            queue.append(next_key)

    return paths


def get_all_agent_coverage(graph_snapshot: Dict[str, Any]) -> List[str]:
    nodes = list(graph_snapshot.get("nodes") or [])
    ordered_nodes = sorted(
        nodes,
        key=lambda node: (0 if node.get("is_entry_node") else 1, node.get("name") or node.get("node_key") or ""),
    )
    return [str(node.get("node_key") or "").strip() for node in ordered_nodes if str(node.get("node_key") or "").strip()]


def build_node_label_map(graph_snapshot: Dict[str, Any]) -> Dict[str, str]:
    label_map: Dict[str, str] = {}
    for node in graph_snapshot.get("nodes") or []:
        node_key = str(node.get("node_key") or "").strip()
        if node_key:
            label_map[node_key] = str(node.get("name") or node_key).strip()
    return label_map


def replace_node_keys_with_labels(value: str, graph_snapshot: Dict[str, Any]) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    for node_key, label in sorted(build_node_label_map(graph_snapshot).items(), key=lambda item: len(item[0]), reverse=True):
        text = text.replace(node_key, label)
    return text


def get_entry_node_snapshot(graph_snapshot: Dict[str, Any]) -> Dict[str, Any]:
    nodes = graph_snapshot.get("nodes") or []
    if not nodes:
        raise ValueError("Swarm evaluation graph snapshot has no nodes")
    return next((node for node in nodes if node.get("is_entry_node")), nodes[0])
