"""Multi-turn conversation runner with trace capture."""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List

from ..provider.client import OpenAIClientWrapper
from ..trace.capture import ConversationTrace, Message, TurnTrace
from .tool_mocks import MockNotFoundBehavior, ToolMockMatcher
from .user_simulator import UserSimulator


logger = logging.getLogger(__name__)


class ConversationRunner:
    """Runs multi-turn conversations and captures traces."""

    def __init__(
        self,
        client: OpenAIClientWrapper,
        system_prompt: str,
        timeout_ms: int = 30000,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        tools: List[Dict[str, Any]] | None = None,
        no_mock_behavior: MockNotFoundBehavior = MockNotFoundBehavior.RAISE,
        max_tool_iterations: int = 10,
    ) -> None:
        self.client = client
        self.system_prompt = system_prompt
        self.timeout_ms = timeout_ms
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.conversation_history: List[Dict[str, Any]] = []
        self.default_tools = tools
        self.max_tool_iterations = max_tool_iterations
        self.mock_matcher = ToolMockMatcher(
            tools=tools or [],
            no_mock_behavior=no_mock_behavior,
        ) if tools else None

        provider_name = getattr(getattr(self.client, "config", None), "provider", "")
        self._use_function_role_for_tools = provider_name.lower() in {"gemini", "google"}

    @staticmethod
    def _safe_tool_mock_error_payload() -> str:
        return json.dumps({"error": "Tool mock execution failed"})

    @staticmethod
    def _safe_turn_error_message() -> str:
        return "Turn execution failed"

    def _assemble_messages(self, user_input: str | None = None) -> List[Dict[str, Any]]:
        messages: List[Dict[str, Any]] = []

        if self.system_prompt:
            messages.append({
                "role": "system",
                "content": self.system_prompt,
            })

        messages.extend(self.conversation_history)

        if user_input:
            messages.append({
                "role": "user",
                "content": user_input,
            })

        return messages

    def _execute_turn(
        self,
        user_input: str,
        turn_number: int,
        tools: List[Dict[str, Any]] | None = None,
        turn_type: str = "agent",
    ) -> TurnTrace:
        turn_trace = TurnTrace(
            turn_number=turn_number,
            user_input=user_input,
            assistant_response="",
            turn_type=turn_type,
        )

        tools_to_use = tools if tools is not None else self.default_tools
        mock_matcher_to_use = None

        if tools_to_use:
            no_mock_behavior = (
                self.mock_matcher.no_mock_behavior
                if self.mock_matcher
                else MockNotFoundBehavior.RAISE
            )
            mock_matcher_to_use = ToolMockMatcher(
                tools=tools_to_use,
                no_mock_behavior=no_mock_behavior,
            )
            clean_tools = mock_matcher_to_use.get_clean_tools()
        else:
            clean_tools = None
            mock_matcher_to_use = self.mock_matcher

        initial_messages = self._assemble_messages(user_input)
        for msg in initial_messages:
            turn_trace.messages.append(Message(
                role=msg["role"],
                content=msg.get("content", ""),
                tool_calls=msg.get("tool_calls"),
                tool_call_id=msg.get("tool_call_id"),
            ))

        timeout_seconds = self.timeout_ms / 1000.0
        max_tool_iterations = self.max_tool_iterations
        user_input_added = False

        for attempt in range(self.max_retries):
            try:
                total_request_duration = 0.0
                tool_iteration = 0
                assistant_content = ""
                response = None

                if not user_input_added:
                    self.conversation_history.append({
                        "role": "user",
                        "content": user_input,
                    })
                    user_input_added = True

                while tool_iteration < max_tool_iterations:
                    messages = self._assemble_messages()

                    request_start = time.time()
                    response = self.client.chat_completion(
                        messages=messages,
                        tools=clean_tools,
                        timeout=timeout_seconds,
                    )
                    request_duration = time.time() - request_start
                    total_request_duration += request_duration

                    assistant_message = response.choices[0].message
                    assistant_content = assistant_message.content or ""

                    tool_calls: List[Dict[str, Any]] = []
                    if assistant_message.tool_calls:
                        for tool_call in assistant_message.tool_calls:
                            tool_calls.append({
                                "id": tool_call.id,
                                "name": tool_call.function.name,
                                "arguments": tool_call.function.arguments,
                            })

                    turn_trace.messages.append(Message(
                        role="assistant",
                        content=assistant_content,
                        tool_calls=tool_calls if tool_calls else None,
                    ))

                    if not tool_calls:
                        turn_trace.assistant_response = assistant_content
                        turn_trace.timings = {
                            "request_duration_ms": total_request_duration * 1000,
                            "attempt": attempt + 1,
                        }
                        turn_trace.request_metadata = {
                            "model": response.model,
                            "usage": {
                                "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                                "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                                "total_tokens": response.usage.total_tokens if response.usage else 0,
                            },
                            "finish_reason": response.choices[0].finish_reason,
                        }

                        self.conversation_history.append({
                            "role": "assistant",
                            "content": assistant_content,
                        })
                        return turn_trace

                    tool_calls_processed = []
                    for tool_call in tool_calls:
                        tool_call_id = tool_call["id"]
                        tool_name = tool_call.get("name") or "unknown_tool"
                        tool_args = tool_call["arguments"]

                        if mock_matcher_to_use:
                            try:
                                mock_result = mock_matcher_to_use.get_mock_result(
                                    tool_call_id=tool_call_id,
                                    tool_name=tool_name,
                                    arguments=tool_args,
                                )
                                tool_result = json.dumps(mock_result) if mock_result is not None else "null"
                            except Exception:
                                logger.exception("Tool mock resolution failed")
                                tool_result = self._safe_tool_mock_error_payload()
                        else:
                            tool_result = json.dumps({
                                "error": f"No tool mocking configured for '{tool_name}'"
                            })

                        if self._use_function_role_for_tools:
                            tool_message = {
                                "role": "function",
                                "name": tool_name,
                                "content": tool_result,
                            }
                        else:
                            tool_message = {
                                "role": "tool",
                                "content": tool_result,
                                "tool_call_id": tool_call_id,
                                "name": tool_name,
                            }
                        self.conversation_history.append(tool_message)

                        turn_trace.messages.append(Message(
                            role=tool_message["role"],
                            content=tool_result,
                            tool_call_id=tool_call_id,
                        ))
                        tool_calls_processed.append(tool_call)

                    turn_trace.tool_calls.extend(tool_calls_processed)
                    tool_iteration += 1

                if response is None:
                    raise RuntimeError("Conversation runner exhausted tool iterations without a response")

                turn_trace.assistant_response = assistant_content
                turn_trace.timings = {
                    "request_duration_ms": total_request_duration * 1000,
                    "attempt": attempt + 1,
                    "tool_iterations": tool_iteration,
                }
                turn_trace.request_metadata = {
                    "model": response.model,
                    "usage": {
                        "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                        "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                        "total_tokens": response.usage.total_tokens if response.usage else 0,
                    },
                    "finish_reason": response.choices[0].finish_reason,
                    "warning": f"Reached max tool iterations ({max_tool_iterations})",
                }
                self.conversation_history.append({
                    "role": "assistant",
                    "content": assistant_content,
                })
                return turn_trace

            except Exception:
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                else:
                    logger.exception("Conversation turn failed after retries")
                    turn_trace.assistant_response = self._safe_turn_error_message()
                    turn_trace.request_metadata = {
                        "error": self._safe_turn_error_message(),
                        "error_type": "TurnExecutionError",
                    }
                    turn_trace.timings = {
                        "attempt": attempt + 1,
                        "failed": True,
                    }
                    raise

        raise RuntimeError("Conversation turn exited unexpectedly")

    def run_conversation(
        self,
        suite_id: str,
        case_id: str,
        conversation: List[Dict[str, str]],
        tools: List[Dict[str, Any]] | None = None,
    ) -> ConversationTrace:
        self.conversation_history = []

        trace = ConversationTrace(
            suite_id=suite_id,
            case_id=case_id,
        )

        turn_number = 0
        for turn_spec in conversation:
            user_input = turn_spec.get("user_input", "")
            if not user_input:
                continue

            turn_number += 1
            turn_trace = self._execute_turn(
                user_input=user_input,
                turn_number=turn_number,
                tools=tools,
            )
            trace.turns.append(turn_trace)

        trace.finish()
        return trace

    def run_conversation_plan(
        self,
        suite_id: str,
        case_id: str,
        starting_prompt: str,
        conversation_plan: str,
        max_invocations: int,
        min_invocations: int,
        user_simulator: UserSimulator,
        tools: List[Dict[str, Any]] | None = None,
        max_tool_iterations: int | None = None,
    ) -> ConversationTrace:
        del conversation_plan
        self.conversation_history = []

        original_max_tool_iterations = self.max_tool_iterations
        if max_tool_iterations is not None:
            self.max_tool_iterations = max_tool_iterations

        try:
            trace = ConversationTrace(
                suite_id=suite_id,
                case_id=case_id,
            )

            current_user_input = starting_prompt
            turn_number = 0
            simulator_invocations = 0
            min_invocations_not_met = False
            force_continue_attempted = False

            while simulator_invocations < max_invocations:
                turn_number += 1
                turn_trace = self._execute_turn(
                    user_input=current_user_input,
                    turn_number=turn_number,
                    tools=tools,
                    turn_type="agent",
                )
                trace.turns.append(turn_trace)

                simulator_history: List[Dict[str, str]] = [
                    {
                        "role": msg.get("role", ""),
                        "content": msg.get("content", ""),
                    }
                    for msg in self.conversation_history
                    if msg.get("role") in {"user", "assistant"}
                ]
                simulator_history = simulator_history[-30:]

                simulator_invocations += 1
                signal, next_user_input = user_simulator.generate_next_turn(
                    conversation_history=simulator_history
                )

                if (signal == "STOP" or next_user_input is None) and simulator_invocations < min_invocations:
                    force_continue_attempted = True
                    signal, next_user_input = user_simulator.generate_next_turn(
                        conversation_history=simulator_history,
                        force_continue=True,
                    )
                    if signal == "STOP" or next_user_input is None:
                        min_invocations_not_met = True

                if signal == "STOP" or next_user_input is None:
                    break

                current_user_input = next_user_input

            if simulator_invocations >= max_invocations:
                trace.metadata = {
                    "termination_reason": "max_invocations_reached",
                    "simulator_invocations": simulator_invocations,
                }
            else:
                trace.metadata = {
                    "termination_reason": "simulator_stop_signal",
                    "simulator_invocations": simulator_invocations,
                }
                if min_invocations_not_met:
                    trace.metadata["min_invocations_not_met"] = True
                if force_continue_attempted:
                    trace.metadata["force_continue_attempted"] = True

            trace.finish()
            return trace
        finally:
            self.max_tool_iterations = original_max_tool_iterations