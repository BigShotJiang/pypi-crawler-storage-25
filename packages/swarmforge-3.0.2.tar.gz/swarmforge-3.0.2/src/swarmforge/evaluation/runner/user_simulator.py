"""User simulator for generating dynamic conversation turns."""

from __future__ import annotations

import logging
import time
from enum import Enum
from typing import Dict, List, Literal, Optional, Tuple

from pydantic import BaseModel

from ..provider.client import OpenAIClientWrapper


logger = logging.getLogger(__name__)


class StopSignal(str, Enum):
    """Stop signal values for user simulator."""

    CONTINUE = "CONTINUE"
    STOP = "STOP"


class SimulatorOutput(BaseModel):
    assistant_answer: str
    conversation_state: Literal["continue", "stop"]


class UserSimulator:
    """Simulates user behavior by generating the next user turn."""

    SYSTEM_PROMPT_TEMPLATE = """You are simulating a user in a conversation with an AI assistant.

Your goal is to follow this conversation plan:
{conversation_plan}

Guidelines:
- Generate natural, realistic user messages that follow the plan
- Respond appropriately to the assistant's messages
- Short acknowledgements like \"ok\", \"okay\", \"parfait\", \"merci\" are allowed when appropriate.
- Avoid getting stuck in acknowledgement-only loops: if you acknowledge, try to add a detail or ask a follow-up within the next turn.
- If the assistant asks a question, answer it with concrete details when you can (timeline, budget range, city, availability).
- Prefer to advance the plan by adding new info or asking a relevant follow-up question.
- Keep it realistic for a lead in this scenario; do not mention you are a simulator.
- When the conversation plan is complete or the goal is achieved, set conversation_state to \"stop\"
- Otherwise, set conversation_state to \"continue\"

Return a JSON object only, with this exact shape:
{{
    \"assistant_answer\": \"<the user's next message>\",
    \"conversation_state\": \"continue\" | \"stop\"
}}

Do not include any other text or explanation."""

    def __init__(
        self,
        client: OpenAIClientWrapper,
        conversation_plan: str,
        timeout_ms: int = 30000,
        max_retries: int = 3,
        retry_delay: float = 1.0,
    ) -> None:
        self.client = client
        self.conversation_plan = conversation_plan
        self.timeout_ms = timeout_ms
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.system_prompt = self.SYSTEM_PROMPT_TEMPLATE.format(
            conversation_plan=conversation_plan
        )

    @staticmethod
    def _safe_generation_failure_message() -> str:
        return "User simulator failed after retries"

    def generate_next_turn(
        self,
        conversation_history: List[Dict[str, str]],
        force_continue: bool = False,
    ) -> Tuple[Literal["CONTINUE", "STOP"], Optional[str]]:
        timeout_seconds = self.timeout_ms / 1000.0
        system_prompt = self.system_prompt
        if force_continue:
            system_prompt = (
                f"{system_prompt}\n\nIMPORTANT: The conversation has not yet reached its minimum length. "
                "You MUST set conversation_state to \"continue\" and provide a follow-up message."
            )

        for attempt in range(self.max_retries):
            try:
                messages: List[Dict[str, str]] = [
                    {"role": "system", "content": system_prompt}
                ]
                messages.extend(conversation_history)

                response = self.client.chat_completion(
                    messages=messages,
                    timeout=timeout_seconds,
                    response_format=SimulatorOutput,
                )

                parsed = getattr(response.choices[0].message, "parsed", None)
                if not parsed:
                    return (StopSignal.STOP.value, None)

                if parsed.conversation_state == "stop":
                    return (StopSignal.STOP.value, None)

                message = (parsed.assistant_answer or "").strip()
                if not message:
                    return (StopSignal.STOP.value, None)

                return (StopSignal.CONTINUE.value, message)
            except Exception:
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                else:
                    logger.exception("User simulator failed after %s attempts", self.max_retries)
                    raise RuntimeError(self._safe_generation_failure_message())

        return (StopSignal.STOP.value, None)