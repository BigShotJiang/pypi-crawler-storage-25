"""Tool mocking engine for deterministic tool call results."""

from __future__ import annotations

import json
from enum import Enum
from typing import Any, Dict, List


class MockNotFoundBehavior(str, Enum):
    """Behavior when no matching mock is found."""

    RAISE = "raise"
    RETURN_ERROR = "return_error"
    RETURN_NONE = "return_none"


class ToolMockMatcher:
    """Matches tool calls to mock configurations and returns mock results."""

    def __init__(
        self,
        tools: List[Dict[str, Any]],
        no_mock_behavior: MockNotFoundBehavior = MockNotFoundBehavior.RAISE,
    ) -> None:
        self.tools = tools
        self.no_mock_behavior = no_mock_behavior
        self._tool_mocks: Dict[str, List[Dict[str, Any]]] = {}
        self._extract_mocks()

    def _extract_mocks(self) -> None:
        for tool_def in self.tools:
            function_def = tool_def.get("function", {})
            if not isinstance(function_def, dict):
                continue

            tool_name = function_def.get("name")
            if not tool_name:
                continue

            mock_response = tool_def.get("mock_response")
            if mock_response is None:
                continue

            mock_config = {
                "match": {"strategy": "first"},
                "result": mock_response,
            }
            self._tool_mocks.setdefault(tool_name, []).append(mock_config)

    def _normalize_tool_call(
        self,
        tool_call_id: str,
        tool_name: str,
        arguments: str,
    ) -> Dict[str, Any]:
        try:
            args_dict = json.loads(arguments) if isinstance(arguments, str) else arguments
        except json.JSONDecodeError:
            args_dict = {}

        return {
            "id": tool_call_id,
            "name": tool_name,
            "args": args_dict,
        }

    def _find_mock(self, tool_name: str, call_args: Dict[str, Any]) -> Dict[str, Any] | None:
        del call_args
        if tool_name not in self._tool_mocks:
            return None

        mock_configs = self._tool_mocks[tool_name]
        if mock_configs:
            return mock_configs[0].get("result")
        return None

    def get_mock_result(
        self,
        tool_call_id: str,
        tool_name: str,
        arguments: str,
    ) -> Any:
        normalized_call = self._normalize_tool_call(tool_call_id, tool_name, arguments)
        mock_result = self._find_mock(tool_name, normalized_call["args"])

        if mock_result is not None:
            return mock_result

        if self.no_mock_behavior == MockNotFoundBehavior.RAISE:
            raise ValueError(
                f"No mock found for tool '{tool_name}' with args: {normalized_call['args']}. "
                f"Available mocks for '{tool_name}': {len(self._tool_mocks.get(tool_name, []))} entries."
            )
        if self.no_mock_behavior == MockNotFoundBehavior.RETURN_ERROR:
            return {
                "error": f"No mock found for tool '{tool_name}' with args: {normalized_call['args']}"
            }
        return None

    def get_clean_tools(self) -> List[Dict[str, Any]]:
        from ...swarm.tools import sanitize_tool_definition

        return [sanitize_tool_definition(tool_def) for tool_def in self.tools]