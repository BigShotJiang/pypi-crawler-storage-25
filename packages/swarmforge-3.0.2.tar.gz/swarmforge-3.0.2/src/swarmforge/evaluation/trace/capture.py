"""Trace capture for conversation runs."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class Message:
    """A single message in the conversation trace."""

    role: str
    content: str
    timestamp: float = field(default_factory=time.time)
    tool_calls: List[Dict[str, Any]] | None = None
    tool_call_id: str | None = None


@dataclass
class TurnTrace:
    """Trace for a single conversation turn."""

    turn_number: int
    user_input: str
    assistant_response: str
    messages: List[Message] = field(default_factory=list)
    request_metadata: Dict[str, Any] = field(default_factory=dict)
    timings: Dict[str, Any] = field(default_factory=dict)
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    scores: Dict[str, Any] = field(default_factory=dict)
    turn_type: str = "agent"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "turn_number": self.turn_number,
            "user_input": self.user_input,
            "assistant_response": self.assistant_response,
            "messages": [
                {
                    "role": msg.role,
                    "content": msg.content,
                    "timestamp": msg.timestamp,
                    "tool_calls": msg.tool_calls,
                    "tool_call_id": msg.tool_call_id,
                }
                for msg in self.messages
            ],
            "request_metadata": self.request_metadata,
            "timings": self.timings,
            "tool_calls": self.tool_calls,
            "scores": self.scores,
            "turn_type": self.turn_type,
        }


@dataclass
class ConversationTrace:
    """Complete trace for a multi-turn conversation."""

    suite_id: str
    case_id: str
    turns: List[TurnTrace] = field(default_factory=list)
    start_time: float = field(default_factory=time.time)
    end_time: float | None = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def finish(self) -> None:
        self.end_time = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "suite_id": self.suite_id,
            "case_id": self.case_id,
            "turns": [turn.to_dict() for turn in self.turns],
            "start_time": self.start_time,
            "end_time": self.end_time,
            "total_duration": (self.end_time or time.time()) - self.start_time,
            "metadata": self.metadata,
        }