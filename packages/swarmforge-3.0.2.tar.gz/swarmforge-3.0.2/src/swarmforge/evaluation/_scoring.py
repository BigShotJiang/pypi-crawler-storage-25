"""Artifact scoring helpers for swarm evaluation."""

from __future__ import annotations

import json
from typing import Any, Dict, List

from ..swarm.models import SessionCheckpoint
from ._graph import build_node_label_map, get_entry_node_snapshot


def normalize_value(value: Any) -> Any:
    return json.loads(json.dumps(value, sort_keys=True, default=str))


def serialize_checkpoints(checkpoints: List[SessionCheckpoint]) -> List[Dict[str, Any]]:
    serialized: List[Dict[str, Any]] = []
    for checkpoint in checkpoints:
        snapshot = normalize_value(checkpoint.state_snapshot or {})
        serialized.append(
            {
                "id": checkpoint.id,
                "acting_node_id": checkpoint.acting_node_id,
                "step_number": checkpoint.step_number,
                "action_type": checkpoint.action_type,
                "state_snapshot": snapshot,
                "state": snapshot.get("state") or snapshot.get("global_variables", {}),
                "global_variables": snapshot.get("global_variables") or snapshot.get("state", {}),
                "handoff_details": snapshot.get("handoff"),
                "created_at": checkpoint.created_at,
            }
        )
    return serialized


def infer_actual_routing(
    entry_node_key: str,
    event_log: List[Dict[str, Any]],
    checkpoints: List[Dict[str, Any]],
    node_key_by_name: Dict[str, str],
) -> List[str]:
    actual_routing = [entry_node_key]
    handoff_targets: List[str] = []
    for event in event_log:
        if event.get("event") != "handoff":
            continue
        target_name = str((event.get("data") or {}).get("to") or "").strip()
        if target_name:
            handoff_targets.append(node_key_by_name.get(target_name, target_name))
    if not handoff_targets:
        for checkpoint in checkpoints:
            if checkpoint.get("action_type") != "handoff":
                continue
            handoff = checkpoint.get("handoff_details") or {}
            target_name = str(handoff.get("to") or "").strip()
            if target_name:
                handoff_targets.append(node_key_by_name.get(target_name, target_name))
    actual_routing.extend(handoff_targets)
    return actual_routing


def compare_sequence(expected: List[Any], actual: List[Any]) -> Dict[str, Any]:
    normalized_expected = [normalize_value(item) for item in expected]
    normalized_actual = [normalize_value(item) for item in actual]
    matched_positions = sum(
        1
        for index in range(min(len(normalized_expected), len(normalized_actual)))
        if normalized_expected[index] == normalized_actual[index]
    )
    denominator = max(len(normalized_expected), len(normalized_actual), 1)
    return {
        "expected": normalized_expected,
        "actual": normalized_actual,
        "matched_positions": matched_positions,
        "score": matched_positions / denominator,
        "passed": not normalized_expected or normalized_expected == normalized_actual,
    }


def compare_expected_variables(expected_variables: Dict[str, Any], final_globals: Dict[str, Any]) -> Dict[str, Any]:
    normalized_expected = {key: normalize_value(value) for key, value in (expected_variables or {}).items()}
    normalized_actual = {key: normalize_value((final_globals or {}).get(key)) for key in normalized_expected}
    matched_keys = [key for key, expected_value in normalized_expected.items() if normalized_actual.get(key) == expected_value]
    score = len(matched_keys) / len(normalized_expected) if normalized_expected else 1.0
    return {
        "expected": normalized_expected,
        "actual": normalized_actual,
        "matched_keys": matched_keys,
        "score": score,
        "passed": len(matched_keys) == len(normalized_expected),
    }


def extract_actual_tool_calls(event_log: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    tool_calls: List[Dict[str, Any]] = []
    for event in event_log:
        if event.get("event") != "tool_use":
            continue
        for function_call in ((event.get("data") or {}).get("functionCalls") or []):
            name = function_call.get("name")
            if name and name != "transfer_to_agent":
                tool_calls.append({"name": name, "args": normalize_value(function_call.get("args") or {})})
    return tool_calls


def compare_expected_tools(expected_tools: List[Dict[str, Any]], actual_tools: List[Dict[str, Any]]) -> Dict[str, Any]:
    normalized_expected = [
        {"name": tool.get("name") or "", "args": normalize_value(tool.get("arguments") or tool.get("args") or {})}
        for tool in (expected_tools or [])
    ]
    normalized_actual = [
        {"name": tool.get("name") or "", "args": normalize_value(tool.get("args") or {})}
        for tool in (actual_tools or [])
    ]
    if not normalized_expected and not normalized_actual:
        return {
            "expected": normalized_expected,
            "actual": normalized_actual,
            "matched_positions": 0,
            "score": 1.0,
            "passed": True,
        }
    matched_positions = sum(
        1
        for index in range(min(len(normalized_expected), len(normalized_actual)))
        if normalized_expected[index]["name"] == normalized_actual[index]["name"]
        and normalized_expected[index]["args"] == normalized_actual[index]["args"]
    )
    denominator = max(len(normalized_expected), len(normalized_actual), 1)
    return {
        "expected": normalized_expected,
        "actual": normalized_actual,
        "matched_positions": matched_positions,
        "score": matched_positions / denominator,
        "passed": not normalized_expected or normalized_expected == normalized_actual,
    }


def count_actual_turns(checkpoints: List[Dict[str, Any]]) -> int:
    return sum(1 for checkpoint in checkpoints if checkpoint.get("action_type") == "agent_response")


def compare_min_turns(min_turns: Any, actual_turn_count: int) -> Dict[str, Any]:
    try:
        normalized_min_turns = max(int(min_turns), 1)
    except (TypeError, ValueError):
        normalized_min_turns = 1
    passed = actual_turn_count >= normalized_min_turns
    score = min(actual_turn_count / normalized_min_turns, 1.0) if normalized_min_turns > 0 else 1.0
    return {
        "expected": normalized_min_turns,
        "actual": actual_turn_count,
        "score": score,
        "passed": passed,
    }


def compare_agent_coverage(required_agent_coverage: List[str], actual_routing: List[str]) -> Dict[str, Any]:
    normalized_required = [str(item).strip() for item in (required_agent_coverage or []) if str(item).strip()]
    normalized_actual = [str(item).strip() for item in (actual_routing or []) if str(item).strip()]
    covered_agents = [agent for agent in normalized_required if agent in normalized_actual]
    score = len(covered_agents) / len(normalized_required) if normalized_required else 1.0
    return {
        "expected": normalized_required,
        "actual": normalized_actual,
        "covered_agents": covered_agents,
        "missing_agents": [agent for agent in normalized_required if agent not in normalized_actual],
        "score": score,
        "passed": len(covered_agents) == len(normalized_required),
    }


def evaluate_scenario_artifacts(
    graph_snapshot: Dict[str, Any],
    scenario_seed: Dict[str, Any],
    *,
    event_log: List[Dict[str, Any]],
    checkpoints: List[SessionCheckpoint] | List[Dict[str, Any]],
) -> Dict[str, Any]:
    serialized_checkpoints = checkpoints if checkpoints and isinstance(checkpoints[0], dict) else serialize_checkpoints(checkpoints)  # type: ignore[index]
    entry_node_key = get_entry_node_snapshot(graph_snapshot)["node_key"]
    node_key_by_name = {value: key for key, value in build_node_label_map(graph_snapshot).items()}
    actual_routing = infer_actual_routing(entry_node_key, event_log, serialized_checkpoints, node_key_by_name)
    final_globals = (
        (serialized_checkpoints[-1].get("state") or serialized_checkpoints[-1].get("global_variables"))
        if serialized_checkpoints
        else {}
    ) or {}
    actual_tools = extract_actual_tool_calls(event_log)
    actual_turn_count = count_actual_turns(serialized_checkpoints)

    routing_result = compare_sequence(scenario_seed.get("expected_routing") or [], actual_routing)
    variable_result = compare_expected_variables(scenario_seed.get("expected_variables") or {}, final_globals)
    tool_result = compare_expected_tools(scenario_seed.get("expected_tools") or [], actual_tools)
    min_turn_result = compare_min_turns(scenario_seed.get("min_turns"), actual_turn_count)
    coverage_result = compare_agent_coverage(scenario_seed.get("required_agent_coverage") or [], actual_routing)

    components = [routing_result["score"], variable_result["score"], tool_result["score"], min_turn_result["score"], coverage_result["score"]]
    overall_score = sum(components) / len(components)
    passed = all(
        result["passed"]
        for result in (routing_result, variable_result, tool_result, min_turn_result, coverage_result)
    )
    return {
        "passed": passed,
        "overall_score": overall_score,
        "routing": routing_result,
        "variables": variable_result,
        "tools": tool_result,
        "min_turns": min_turn_result,
        "coverage": coverage_result,
        "final_globals": final_globals,
        "actual_tools": actual_tools,
        "actual_routing": actual_routing,
    }


def aggregate_scenario_results(scenario_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    overall_score = (
        sum(result.get("overall_score", 0.0) for result in scenario_results) / len(scenario_results)
        if scenario_results
        else 0.0
    )
    return {
        "scenario_results": scenario_results,
        "scenario_count": len(scenario_results),
        "passed": all(result.get("passed", False) for result in scenario_results),
        "overall_score": overall_score,
    }
