from swarmforge.env import reset_local_env_loader
from swarmforge.evaluation.provider.client import OpenAIClientWrapper
from swarmforge.evaluation.provider.config import (
    OPENROUTER_BASE_URL,
    ModelConfig,
    get_api_key_for_provider,
    get_base_url_for_provider,
    get_default_model_name,
    get_openrouter_fallback_models,
    get_default_provider,
    get_default_headers_for_provider,
)


def test_openrouter_provider_uses_openrouter_env_and_base_url(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or-test")

    assert get_api_key_for_provider("openrouter") == "sk-or-test"
    assert get_base_url_for_provider("openrouter") == OPENROUTER_BASE_URL


def test_openrouter_default_headers_pick_up_attribution_env(monkeypatch):
    monkeypatch.setenv("OPENROUTER_SITE_URL", "https://example-app.dev")
    monkeypatch.setenv("OPENROUTER_APP_NAME", "Example Agent SDK")

    headers = get_default_headers_for_provider("openrouter")

    assert headers == {
        "HTTP-Referer": "https://example-app.dev",
        "X-OpenRouter-Title": "Example Agent SDK",
    }


def test_model_config_defaults_to_openrouter(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or-test")

    config = ModelConfig()

    assert config.provider == "openrouter"
    assert config.base_url == OPENROUTER_BASE_URL
    assert config.api_key == "sk-or-test"
    assert config.model == "openrouter/auto"


def test_openrouter_fallback_models_can_be_loaded_from_env(monkeypatch):
    monkeypatch.setenv("OPENROUTER_FALLBACK_MODELS", "openai/gpt-4o-mini, anthropic/claude-3.5-sonnet")

    assert get_openrouter_fallback_models() == [
        "openai/gpt-4o-mini",
        "anthropic/claude-3.5-sonnet",
    ]


def test_model_config_sets_openrouter_fallback_models(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or-test")
    monkeypatch.setenv("OPENROUTER_FALLBACK_MODELS", "openrouter/auto,openai/gpt-4o-mini")

    config = ModelConfig(provider="openrouter", model="openrouter/auto")

    assert config.fallback_models == ["openai/gpt-4o-mini"]


def test_openrouter_api_key_can_be_loaded_from_dotenv(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    (tmp_path / ".env").write_text("OPENROUTER_API_KEY=sk-or-dotenv\n", encoding="utf-8")
    reset_local_env_loader()

    assert get_api_key_for_provider("openrouter") == "sk-or-dotenv"
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    reset_local_env_loader()


def test_model_defaults_can_be_loaded_from_dotenv(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    monkeypatch.delenv("MODEL_PROVIDER", raising=False)
    monkeypatch.delenv("LLM_MODEL", raising=False)
    (tmp_path / ".env").write_text(
        "OPENROUTER_API_KEY=sk-or-dotenv\nMODEL_PROVIDER=openrouter\nLLM_MODEL=openrouter/horizon-beta\n",
        encoding="utf-8",
    )
    reset_local_env_loader()

    assert get_default_provider() == "openrouter"
    assert get_default_model_name() == "openrouter/horizon-beta"

    config = ModelConfig()
    assert config.provider == "openrouter"
    assert config.model == "openrouter/horizon-beta"
    assert config.api_key == "sk-or-dotenv"
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    monkeypatch.delenv("MODEL_PROVIDER", raising=False)
    monkeypatch.delenv("LLM_MODEL", raising=False)
    reset_local_env_loader()


def test_gemini_provider_uses_google_openai_compat_endpoint(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "gem-test")

    config = ModelConfig(
        provider="gemini",
        model="gemini-3-flash-preview",
    )

    assert config.provider == "gemini"
    assert config.base_url == "https://generativelanguage.googleapis.com/v1beta/openai/"
    assert config.api_key == "gem-test"
    assert config.model == "gemini-3-flash-preview"


def test_client_wrapper_passes_default_headers_to_openai(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or-test")
    captured = {}

    class _FakeOpenAI:
        def __init__(self, **kwargs):
            captured.update(kwargs)

    monkeypatch.setattr("swarmforge.evaluation.provider.client.OpenAI", _FakeOpenAI)

    config = ModelConfig(
        provider="openrouter",
        site_url="https://example-app.dev",
        app_name="Example Agent SDK",
    )
    OpenAIClientWrapper(config)

    assert captured["base_url"] == OPENROUTER_BASE_URL
    assert captured["api_key"] == "sk-or-test"
    assert captured["default_headers"] == {
        "HTTP-Referer": "https://example-app.dev",
        "X-OpenRouter-Title": "Example Agent SDK",
    }


def test_client_wrapper_merges_default_and_per_call_chat_params(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "gem-test")
    captured = {}

    class _FakeCompletions:
        def create(self, **kwargs):
            captured.update(kwargs)
            return object()

    class _FakeChat:
        def __init__(self):
            self.completions = _FakeCompletions()

    class _FakeOpenAI:
        def __init__(self, **kwargs):
            self.chat = _FakeChat()
            self.beta = object()

    monkeypatch.setattr("swarmforge.evaluation.provider.client.OpenAI", _FakeOpenAI)

    client = OpenAIClientWrapper(
        ModelConfig(
            provider="gemini",
            model="gemini-3-flash-preview",
            default_chat_params={"reasoning_effort": "low"},
        )
    )
    client.chat_completion(
        messages=[{"role": "user", "content": "Hello"}],
        extra_params={"extra_body": {"google": {"thinking_config": {"include_thoughts": True}}}},
    )

    assert captured["model"] == "gemini-3-flash-preview"
    assert captured["reasoning_effort"] == "low"
    assert captured["extra_body"] == {"google": {"thinking_config": {"include_thoughts": True}}}


def test_client_wrapper_retries_openrouter_with_fallback_models(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or-test")
    captured_models = []

    class _FakeCompletions:
        def create(self, **kwargs):
            model = kwargs["model"]
            captured_models.append(model)
            if model == "openrouter/auto":
                raise RuntimeError("primary model unavailable")
            return object()

    class _FakeChat:
        def __init__(self):
            self.completions = _FakeCompletions()

    class _FakeOpenAI:
        def __init__(self, **kwargs):
            self.chat = _FakeChat()
            self.beta = object()

    monkeypatch.setattr("swarmforge.evaluation.provider.client.OpenAI", _FakeOpenAI)

    client = OpenAIClientWrapper(
        ModelConfig(
            provider="openrouter",
            model="openrouter/auto",
            fallback_models=["openai/gpt-4o-mini"],
        )
    )

    response = client.chat_completion(messages=[{"role": "user", "content": "Hello"}])

    assert response is not None
    assert captured_models == ["openrouter/auto", "openai/gpt-4o-mini"]
