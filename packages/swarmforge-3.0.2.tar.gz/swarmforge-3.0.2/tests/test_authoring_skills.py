from swarmforge.authoring import (
    META_PROMPT_NODE,
    META_PROMPT_SWARM,
    SKILL_PROMPT_GENERATE_AGENT,
    SKILL_PROMPT_GENERATE_AGENT_API,
    SKILL_PROMPT_GENERATE_SWARM,
    SKILL_PROMPT_GENERATE_SWARM_API,
    SKILL_PROMPTS,
)


def test_skill_prompt_mapping_exposes_expected_commands():
    assert SKILL_PROMPTS == {
        "/generate_agent": SKILL_PROMPT_GENERATE_AGENT,
        "/generate_agent_api": SKILL_PROMPT_GENERATE_AGENT_API,
        "/generate_swarm": SKILL_PROMPT_GENERATE_SWARM,
        "/generate_swarm_api": SKILL_PROMPT_GENERATE_SWARM_API,
    }


def test_agent_skill_prompts_wrap_node_authoring_prompt():
    assert META_PROMPT_NODE in SKILL_PROMPT_GENERATE_AGENT
    assert META_PROMPT_NODE in SKILL_PROMPT_GENERATE_AGENT_API
    assert "SwarmNode" in SKILL_PROMPT_GENERATE_AGENT
    assert "create_fastapi_app" in SKILL_PROMPT_GENERATE_AGENT_API


def test_swarm_skill_prompts_wrap_swarm_authoring_prompt():
    assert META_PROMPT_SWARM in SKILL_PROMPT_GENERATE_SWARM
    assert META_PROMPT_SWARM in SKILL_PROMPT_GENERATE_SWARM_API
    assert "build_swarm_definition" in SKILL_PROMPT_GENERATE_SWARM
    assert "create_fastapi_app" in SKILL_PROMPT_GENERATE_SWARM_API