from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SKILLS_ROOT = ROOT / "skills"

EXPECTED_SKILLS = {
    "generate_agent": "/generate_agent",
    "generate_agent_api": "/generate_agent_api",
    "generate_swarm": "/generate_swarm",
    "generate_swarm_api": "/generate_swarm_api",
}


def test_skills_readme_exists_and_mentions_editor_install_path():
    text = (SKILLS_ROOT / "README.md").read_text(encoding="utf-8")

    assert ".github/skills/<skill-name>/" in text
    assert "skills.sh" in text


def test_each_editor_skill_has_skill_md_and_reference_file():
    for skill_name, trigger in EXPECTED_SKILLS.items():
        skill_dir = SKILLS_ROOT / skill_name
        skill_md = skill_dir / "SKILL.md"
        references_dir = skill_dir / "references"

        assert skill_dir.is_dir()
        assert skill_md.is_file()
        assert references_dir.is_dir()
        assert any(references_dir.iterdir())

        content = skill_md.read_text(encoding="utf-8")
        assert content.startswith("---\n")
        assert f"name: {skill_name}" in content
        assert "description:" in content
        assert trigger in content
        assert "Always read `references/" in content


def test_skill_descriptions_are_swarmforge_specific():
    for skill_name in EXPECTED_SKILLS:
        content = (SKILLS_ROOT / skill_name / "SKILL.md").read_text(encoding="utf-8")

        assert "SwarmForge" in content
        assert "system_prompt" in content or "swarm_payload" in content