from swarmforge.swarm import function_tool, infer_tool_parameters
from swarmforge.swarm.tools import sanitize_tool_definition


def test_infer_tool_parameters_from_signature_and_google_docstring():
    def lookup_order(order_id: str, include_history: bool = False, context=None):
        """Fetch order status for a customer order.

        Args:
            order_id: The unique order identifier.
            include_history: Whether to include tracking history.
        """

        del context
        return {"order_id": order_id, "include_history": include_history}

    schema = infer_tool_parameters(lookup_order)

    assert schema["type"] == "object"
    assert schema["required"] == ["order_id"]
    assert schema["properties"]["order_id"]["type"] == "string"
    assert schema["properties"]["order_id"]["description"] == "The unique order identifier."
    assert schema["properties"]["include_history"]["type"] == "boolean"
    assert schema["properties"]["include_history"]["description"] == "Whether to include tracking history."
    assert "context" not in schema["properties"]


def test_function_tool_infers_name_description_and_parameters_from_handler():
    def lookup_order(order_id: str):
        """Fetch order status.

        :param order_id: The order identifier.
        """

        return {"order_id": order_id}

    tool = function_tool(handler=lookup_order)

    assert tool["function"]["name"] == "lookup_order"
    assert tool["function"]["description"] == "Fetch order status."
    assert tool["function"]["parameters"]["properties"]["order_id"]["description"] == "The order identifier."


def test_sanitize_tool_definition_removes_runtime_only_fields():
    def lookup_order(order_id: str, state=None):
        """Fetch order status.

        Args:
            order_id: The order identifier.
        """

        return {"order_id": order_id, "tenant": state["tenant"]}

    tool = sanitize_tool_definition(function_tool(handler=lookup_order))

    assert tool["function"]["name"] == "lookup_order"
    assert tool["function"]["parameters"]["properties"]["order_id"]["type"] == "string"
    assert "handler" not in tool
    assert "mock_response" not in tool