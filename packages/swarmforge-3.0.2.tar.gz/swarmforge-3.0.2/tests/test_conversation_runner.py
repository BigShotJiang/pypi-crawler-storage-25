from typing import List, Optional, Tuple

from swarmforge.evaluation.runner.conversation import ConversationRunner
from swarmforge.evaluation.trace.capture import TurnTrace


class _FakeClient:
    def chat_completion(self, **_kwargs):
        raise AssertionError("chat_completion should not be called in this unit test")


class _FakeSimulator:
    def __init__(self, responses: List[Tuple[str, Optional[str]]]):
        self._responses = responses
        self.calls = []

    def generate_next_turn(self, conversation_history, force_continue=False):
        self.calls.append({
            "force_continue": force_continue,
            "history_size": len(conversation_history),
        })
        if not self._responses:
            return ("STOP", None)
        return self._responses.pop(0)


def _mock_execute_turn_factory(assistant_responses: List[str]):
    def _mock_execute_turn(self, user_input, turn_number, tools=None, turn_type="agent"):
        del tools
        assistant_response = assistant_responses[min(turn_number - 1, len(assistant_responses) - 1)]
        self.conversation_history.append({"role": "user", "content": user_input})
        self.conversation_history.append({"role": "assistant", "content": assistant_response})
        return TurnTrace(
            turn_number=turn_number,
            user_input=user_input,
            assistant_response=assistant_response,
            turn_type=turn_type,
        )

    return _mock_execute_turn


def test_run_conversation_plan_stops_cleanly_when_force_continue_still_returns_stop(monkeypatch):
    runner = ConversationRunner(client=_FakeClient(), system_prompt="System")
    monkeypatch.setattr(
        ConversationRunner,
        "_execute_turn",
        _mock_execute_turn_factory(["Parfait, merci. Cela conclut notre echange."]),
    )

    simulator = _FakeSimulator(
        responses=[
            ("STOP", None),
            ("STOP", None),
        ]
    )

    trace = runner.run_conversation_plan(
        suite_id="suite-1",
        case_id="case-1",
        starting_prompt="Bonjour",
        conversation_plan="Keep it short.",
        max_invocations=10,
        min_invocations=3,
        user_simulator=simulator,
    )

    assert len(trace.turns) == 1
    assert trace.metadata["termination_reason"] == "simulator_stop_signal"
    assert trace.metadata["simulator_invocations"] == 1
    assert trace.metadata["min_invocations_not_met"] is True
    assert trace.metadata["force_continue_attempted"] is True
    assert simulator.calls[1]["force_continue"] is True
    assert all(
        turn.user_input != "Je cherche un investissement locatif et je suis disponible cette semaine."
        for turn in trace.turns
    )


def test_run_conversation_plan_uses_force_continue_message_when_available(monkeypatch):
    runner = ConversationRunner(client=_FakeClient(), system_prompt="System")
    monkeypatch.setattr(
        ConversationRunner,
        "_execute_turn",
        _mock_execute_turn_factory([
            "Can you share your account id?",
            "Thanks. Do you need anything else?",
        ]),
    )

    simulator = _FakeSimulator(
        responses=[
            ("STOP", None),
            ("CONTINUE", "My account id is ACCO-ID-001."),
            ("STOP", None),
            ("STOP", None),
        ]
    )

    trace = runner.run_conversation_plan(
        suite_id="suite-1",
        case_id="case-2",
        starting_prompt="I need help with billing.",
        conversation_plan="Collect account id then end.",
        max_invocations=10,
        min_invocations=3,
        user_simulator=simulator,
    )

    assert len(trace.turns) == 2
    assert trace.turns[1].user_input == "My account id is ACCO-ID-001."
    assert trace.metadata["termination_reason"] == "simulator_stop_signal"
    assert trace.metadata["simulator_invocations"] == 2
    assert trace.metadata["min_invocations_not_met"] is True
    assert trace.metadata["force_continue_attempted"] is True
    assert all(
        turn.user_input != "Je cherche un investissement locatif et je suis disponible cette semaine."
        for turn in trace.turns
    )