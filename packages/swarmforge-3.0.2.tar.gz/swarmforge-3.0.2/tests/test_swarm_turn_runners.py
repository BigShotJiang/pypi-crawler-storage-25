import asyncio
from types import SimpleNamespace

from swarmforge.evaluation.provider import ModelConfig
from swarmforge.swarm import AgentTurnConfig, SwarmNode, build_openai_compatible_turn_runner, build_turn_runner
from swarmforge.swarm.turn_runners import OpenAICompatibleTurnRunner


class _FakeChatClient:
    def __init__(self) -> None:
        self.calls = []

    def chat_completion(self, messages, tools=None):
        self.calls.append({"messages": messages, "tools": tools})
        assistant_message = SimpleNamespace(
            content="Order 123 has shipped.",
            tool_calls=[
                SimpleNamespace(
                    id="tool-call-1",
                    function=SimpleNamespace(name="lookup_order", arguments='{"order_id": "123"}'),
                )
            ],
        )
        return SimpleNamespace(choices=[SimpleNamespace(message=assistant_message)])


class _FakeOpenAIClientWrapper(_FakeChatClient):
    def __init__(self, config) -> None:
        super().__init__()
        self.config = config


def test_build_openai_compatible_turn_runner_adapts_messages_and_tool_calls():
    client = _FakeChatClient()
    runner = build_openai_compatible_turn_runner(client)
    node = SwarmNode(
        id="assistant",
        node_key="assistant",
        name="Assistant",
        intent="Handle general requests",
        system_prompt="You are helpful.",
        is_entry_node=True,
    )
    config = AgentTurnConfig(
        system_instruction="You are concise.",
        tools=[
            {
                "type": "function",
                "function": {
                    "name": "lookup_order",
                    "description": "Fetch an order.",
                    "parameters": {"type": "object", "properties": {"order_id": {"type": "string"}}},
                },
            }
        ],
    )
    contents = [
        {"role": "user", "content": "Where is order 123?"},
        {"role": "model", "content": "Let me check."},
        {
            "role": "tool",
            "content": '{"status": "shipped"}',
            "tool_call_id": "tool-call-1",
            "name": "lookup_order",
        },
    ]

    result = asyncio.run(runner.run_turn(agent_node=node, contents=contents, config=config))

    assert result.response_text == "Order 123 has shipped."
    assert result.tool_calls == [{"id": "tool-call-1", "name": "lookup_order", "args": {"order_id": "123"}}]

    client_call = client.calls[0]
    assert client_call["tools"] == config.tools
    assert client_call["messages"] == [
        {"role": "system", "content": "You are concise."},
        {"role": "user", "content": "Where is order 123?"},
        {"role": "assistant", "content": "Let me check."},
        {
            "role": "tool",
            "content": '{"status": "shipped"}',
            "tool_call_id": "tool-call-1",
            "name": "lookup_order",
        },
    ]


def test_build_turn_runner_wraps_model_config(monkeypatch):
    from swarmforge import evaluation

    monkeypatch.setattr(evaluation.provider, "OpenAIClientWrapper", _FakeOpenAIClientWrapper)

    model_config = ModelConfig(provider="openrouter", api_key="sk-test", model="openrouter/auto")
    runner = build_turn_runner(model_config)

    assert isinstance(runner, OpenAICompatibleTurnRunner)
    assert isinstance(runner.client, _FakeOpenAIClientWrapper)
    assert runner.client.config is model_config
