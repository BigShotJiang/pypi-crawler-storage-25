from swarmforge.authoring import (
    apply_swarm_graph_payload,
    build_generated_variables_from_swarm_payload,
    build_swarm_definition,
    validate_generated_edge_payload,
    validate_generated_swarm_payload,
    validate_swarm_definition,
)


def test_validate_generated_edge_payload_normalizes_required_variables():
    payload = validate_generated_edge_payload(
        {
            "handoff_description": "Transfer billing requests after confirming the user wants billing help.",
            "required_variables": ["account_id", "", "account_id", "invoice_id"],
        }
    )

    assert payload["handoff_description"].startswith("Transfer billing requests")
    assert payload["required_variables"] == ["account_id", "account_id", "invoice_id"][:3]


def test_build_generated_variables_from_swarm_payload_collects_unique_edge_variables():
    variables = build_generated_variables_from_swarm_payload(
        {
            "edges": [
                {"required_variables": ["account_id", "invoice_id"]},
                {"required_variables": ["invoice_id", "region"]},
            ]
        }
    )

    assert variables == [
        {"key_name": "account_id", "description": "", "reducer_rule": "overwrite"},
        {"key_name": "invoice_id", "description": "", "reducer_rule": "overwrite"},
        {"key_name": "region", "description": "", "reducer_rule": "overwrite"},
    ]


def test_build_swarm_definition_creates_runtime_models_and_increments_graph_version():
    payload = validate_generated_swarm_payload(
        {
            "nodes": [
                {
                    "node_key": "triage",
                    "name": "Triage",
                    "persona": "",
                    "is_entry_node": True,
                },
                {
                    "node_key": "billing",
                    "name": "Billing",
                    "persona": "Direct and calm",
                    "is_entry_node": False,
                },
            ],
            "edges": [
                {
                    "source_node_key": "triage",
                    "target_node_key": "billing",
                    "handoff_description": "Route to billing after confirming the issue is about charges or invoices.",
                    "required_variables": ["account_id"],
                }
            ],
        }
    )
    swarm = build_swarm_definition(payload, swarm_id="swarm-1", name="Support")
    validate_swarm_definition(swarm)

    assert swarm.graph_version == 1
    assert swarm.entry_node().node_key == "triage"
    assert swarm.entry_node().intent == ""
    assert swarm.entry_node().capabilities == []
    assert swarm.node_by_key("billing").persona == "Direct and calm"
    assert swarm.variables[0].key_name == "account_id"

    updated = apply_swarm_graph_payload(
        swarm,
        {
            "nodes": payload["nodes"],
            "edges": payload["edges"],
            "variables": [{"key_name": "account_id", "description": "Customer id", "reducer_rule": "overwrite"}],
        },
    )

    assert updated is swarm
    assert swarm.graph_version == 2
    assert swarm.variables[0].description == "Customer id"


def test_build_swarm_definition_preserves_enabled_tools_and_behavior_config():
    payload = validate_generated_swarm_payload(
        {
            "nodes": [
                {
                    "node_key": "ops",
                    "name": "Ops",
                    "persona": "Direct",
                    "system_prompt": "You handle operational requests.",
                    "model_choice": "openrouter/auto",
                    "enabled_tools": [
                        {
                            "type": "function",
                            "function": {
                                "name": "lookup_order",
                                "description": "Fetch order status",
                                "parameters": {
                                    "type": "object",
                                    "properties": {"order_id": {"type": "string"}},
                                    "required": ["order_id"],
                                },
                            },
                        }
                    ],
                    "behavior_config": {"history_scope": "shared"},
                    "is_entry_node": True,
                }
            ],
            "edges": [],
        }
    )

    swarm = build_swarm_definition(payload, swarm_id="swarm-1", name="Support")

    assert swarm.entry_node().model_choice == "openrouter/auto"
    assert swarm.entry_node().enabled_tools[0]["function"]["name"] == "lookup_order"
    assert swarm.entry_node().behavior_config.history_scope == "shared"
