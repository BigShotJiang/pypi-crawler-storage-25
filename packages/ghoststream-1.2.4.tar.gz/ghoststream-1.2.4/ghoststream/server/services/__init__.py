"""GhostStream server services package."""
