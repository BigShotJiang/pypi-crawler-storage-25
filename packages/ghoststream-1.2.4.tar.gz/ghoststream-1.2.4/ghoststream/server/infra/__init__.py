"""GhostStream server infrastructure package."""
