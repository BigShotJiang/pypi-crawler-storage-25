"""GhostStream zeroconf infrastructure package."""
