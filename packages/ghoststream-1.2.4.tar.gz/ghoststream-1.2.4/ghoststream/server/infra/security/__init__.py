"""GhostStream security infrastructure package."""
