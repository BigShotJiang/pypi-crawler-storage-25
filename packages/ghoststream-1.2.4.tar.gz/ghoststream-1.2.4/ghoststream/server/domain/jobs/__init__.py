"""GhostStream jobs domain package."""
