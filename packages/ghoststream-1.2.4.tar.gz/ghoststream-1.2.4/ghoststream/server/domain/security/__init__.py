"""GhostStream security domain package."""
