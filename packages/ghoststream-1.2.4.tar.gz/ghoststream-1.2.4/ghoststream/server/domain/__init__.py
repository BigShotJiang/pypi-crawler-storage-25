"""GhostStream server domain package."""
