"""GhostStream server runtime package."""
