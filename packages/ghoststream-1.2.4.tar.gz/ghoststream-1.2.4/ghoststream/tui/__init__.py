"""GhostStream TUI package."""
