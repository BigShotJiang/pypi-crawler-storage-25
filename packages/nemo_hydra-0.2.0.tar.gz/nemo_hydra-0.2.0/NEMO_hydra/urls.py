from NEMO.urls import router, sort_urls

from . import api


def replace_api_url(url_to_replace, new_config):
    for reg in router.registry:
        if reg[0] == url_to_replace:
            router.registry.remove(reg)
    router.register(*new_config)


replace_api_url("tools", (r"tools", api.ToolWithHydraOptionsViewSet))
router.registry.sort(key=sort_urls)

urlpatterns = []
