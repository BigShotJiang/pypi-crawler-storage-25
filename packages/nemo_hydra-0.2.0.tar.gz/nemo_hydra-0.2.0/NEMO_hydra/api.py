from copy import deepcopy

from NEMO.models import Tool
from NEMO.serializers import ModelSerializer, ToolSerializer
from NEMO.views.api import ToolViewSet

from .models import HYDRA_TOOL_OPTIONS_FIELD_NAME, HydraToolOptions


class HydraToolOptionsSerializer(ModelSerializer):
    class Meta:
        model = HydraToolOptions
        exclude = ("tool",)


class ToolWithHydraOptionsSerializer(ToolSerializer):
    # this needs to match HYDRA_TOOL_OPTIONS_FIELD_NAME
    hydra_tool_options = HydraToolOptionsSerializer(required=False)

    def get_fields(self):
        fields = super().get_fields()
        hydra_options_fields = fields.pop(HYDRA_TOOL_OPTIONS_FIELD_NAME, {})
        if hydra_options_fields:
            for key, value in hydra_options_fields.fields.items():
                if key == "id":
                    continue
                # reset the source to hydra_tool_options
                value.source = f"{HYDRA_TOOL_OPTIONS_FIELD_NAME}.{key}"
                value.source_attrs = value.source.split(".")
                fields[key] = value
        return fields

    def validate(self, attrs):
        attributes_data = dict(attrs)
        hydra_options_attrs = attributes_data.pop(HYDRA_TOOL_OPTIONS_FIELD_NAME, {})
        super().validate(attributes_data)
        tool_options = get_tool_options(self.instance)
        for details_attr, details_value in hydra_options_attrs.items():
            setattr(tool_options, details_attr, details_value)
        HydraToolOptionsSerializer().full_clean(tool_options, exclude=["tool"])
        return attrs

    def update(self, instance, validated_data) -> Tool:
        data = deepcopy(validated_data)
        options_data = data.pop(HYDRA_TOOL_OPTIONS_FIELD_NAME, {})
        tool_instance = super().update(instance, data)
        tool_options = get_tool_options(tool_instance)
        HydraToolOptionsSerializer().update(tool_options, options_data)
        return tool_instance

    def create(self, validated_data) -> Tool:
        data = deepcopy(validated_data)
        options_data = data.pop(HYDRA_TOOL_OPTIONS_FIELD_NAME, {})
        tool_instance = super().create(data)
        options_data["tool"] = tool_instance
        HydraToolOptionsSerializer().create(options_data)
        return tool_instance


class ToolWithHydraOptionsViewSet(ToolViewSet):
    serializer_class = ToolWithHydraOptionsSerializer


def get_tool_options(tool: Tool):
    try:
        return tool.hydra_tool_options
    except (HydraToolOptions.DoesNotExist, AttributeError):
        return HydraToolOptions(tool=tool)
