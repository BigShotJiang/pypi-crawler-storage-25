from NEMO.models import BaseModel, Tool

from django.db import models


HYDRA_TOOL_OPTIONS_FIELD_NAME = "hydra_tool_options"


class HydraToolOptions(BaseModel):
    tool = models.OneToOneField(Tool, related_name=HYDRA_TOOL_OPTIONS_FIELD_NAME, on_delete=models.CASCADE)
    hydra_tool_description = models.TextField(blank=True, null=True, verbose_name="Hydra Tool Description")

    def __str__(self):
        return f"Hydra Tool Options for {self.tool}"
