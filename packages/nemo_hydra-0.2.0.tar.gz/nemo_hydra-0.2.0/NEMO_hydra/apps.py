from django.apps import AppConfig


class HydraConfig(AppConfig):
    name = "NEMO_hydra"
    verbose_name = "hydra"
    default_auto_field = "django.db.models.AutoField"

    def ready(self):
        """
        This code will be run when Django starts.
        """
        from . import customizations  # needed

        add_inline_and_register()


def add_inline_and_register():
    from django.contrib import admin
    from NEMO.models import Tool
    from .admin import ToolHydraOptionsInline

    add_inline_to_admin_class(Tool, ToolHydraOptionsInline)


# Remove when NEMO 8.0.0 is released
def add_inline_to_admin_class(model_class, inline_class):
    from django.contrib import admin

    if model_class not in admin.site._registry:
        return

    OriginalModelAdminClass = admin.site._registry[model_class].__class__

    if inline_class in list(OriginalModelAdminClass.inlines):
        return

    NewModelAdminClassWithInline = type(
        f"{model_class.__name__}AdminWithInline",
        (OriginalModelAdminClass,),
        {"inlines": [inline_class] + list(OriginalModelAdminClass.inlines)},
    )

    # re-register
    admin.site.unregister(model_class)
    admin.site.register(model_class, NewModelAdminClassWithInline)
