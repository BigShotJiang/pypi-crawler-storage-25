from django.contrib import admin

from .models import HydraToolOptions


class ToolHydraOptionsInline(admin.StackedInline):
    model = HydraToolOptions
    can_delete = False
    min_num = 1

    class Media:
        js = ("NEMO_hydra/admin/copy_description.js",)
