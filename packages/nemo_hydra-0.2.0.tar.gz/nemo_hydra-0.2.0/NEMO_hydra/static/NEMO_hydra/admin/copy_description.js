window.addEventListener("load", function() {
    (function ($) {
        const $toolDesc = $("#id_hydra_tool_options-0-hydra_tool_description");
        if ($toolDesc.length) {
            const $btn = $('<button type="button" class="button" style="margin-left:8px;padding: 6px 9px; background: #28a745; height: 30px; line-height: 15px; white-space: nowrap">Copy tool description</button>');
            $btn.on("click", function () {
                $toolDesc.val($("#id__description").val());
            });
            $toolDesc.after($btn);
        }
    })(django.jQuery);
});
