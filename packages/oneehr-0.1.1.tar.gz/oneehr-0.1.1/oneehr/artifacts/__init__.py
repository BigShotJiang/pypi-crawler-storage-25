"""Artifact read/write utilities."""
