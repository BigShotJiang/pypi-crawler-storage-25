from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np


@dataclass
class MonitorResult:
    score: float
    flagged: bool
    tau: float
    phase: str
    monitor_id: str
    error: str = None


class _LocalModel:
    """Client-side feature extractor — hooks + signatures only, no calibration logic."""

    def __init__(self, model, num_classes: int):
        from signai.client._instrumentor import AutoInstrumentor
        from signai.client._signatures import SignatureExtractor
        self.model = model
        self.num_classes = num_classes
        self.instrumentor = AutoInstrumentor(model)
        self.extractor = SignatureExtractor(model, instrumentor=self.instrumentor)
        self._infer_ready = False

    def prepare_inference_hooks(self, example_batch):
        self.instrumentor.auto_select_layers(example_batch)
        self.instrumentor.enable_selected_hooks()
        self._infer_ready = True

    def load_hooks_from_artifact(self, path: str):
        with open(path, encoding="utf-8") as f:
            payload = json.load(f)
        if payload.get("format") != "signai_integrity_v1":
            raise ValueError("Unsupported signAI artifact")
        self.num_classes = int(payload["num_classes"])
        hooks = list(payload.get("hooks", []))
        if hooks:
            self.instrumentor.selected = hooks
            self.instrumentor.enable_selected_hooks()
            self._infer_ready = True


def attach(
    model,
    num_classes: int,
    artifact: str = None,
    endpoint: str = None,
    api_key: str = None,
    monitor_id: str = None,
    on_flag=None,
    on_error=None,
    device: str = "cpu",
) -> "Monitor":
    return Monitor(
        model=model,
        num_classes=num_classes,
        artifact=artifact,
        endpoint=endpoint,
        api_key=api_key,
        monitor_id=monitor_id,
        on_flag=on_flag,
        on_error=on_error,
        device=device,
        _load_artifact=False,
    )


def load(
    model,
    num_classes: int = 10,
    artifact: str = None,
    endpoint: str = None,
    api_key: str = None,
    monitor_id: str = None,
    on_flag=None,
    on_error=None,
    device: str = "cpu",
) -> "Monitor":
    return Monitor(
        model=model,
        num_classes=num_classes,
        artifact=artifact,
        endpoint=endpoint,
        api_key=api_key,
        monitor_id=monitor_id,
        on_flag=on_flag,
        on_error=on_error,
        device=device,
        _load_artifact=True,
    )


class Monitor:
    def __init__(
        self,
        model,
        num_classes: int,
        artifact: str = None,
        endpoint: str = None,
        api_key: str = None,
        monitor_id: str = None,
        on_flag: Optional[Callable[[MonitorResult], None]] = None,
        on_error: Optional[Callable[[Exception], None]] = None,
        device: str = "cpu",
        _load_artifact: bool = False,
    ):
        from signai.client.backends import LocalBackend, RemoteBackend

        self._device = device
        self._monitor_id = monitor_id or ""
        self._on_flag = on_flag
        self._on_error = on_error
        self._lm = _LocalModel(model, num_classes)
        self._backend = None

        if _load_artifact and artifact:
            self._lm.load_hooks_from_artifact(artifact)

        if endpoint:
            self._backend = RemoteBackend(
                endpoint=endpoint,
                api_key=api_key or "",
                monitor_id=self._monitor_id,
                on_error=on_error,
            )
            if _load_artifact and artifact is None and self._monitor_id:
                metadata = self._backend.get_artifact_metadata(self._monitor_id)
                hooks = list(metadata.get("hooks", []))
                self._lm.instrumentor.selected = hooks
                if hooks:
                    self._lm.instrumentor.enable_selected_hooks()
                    self._lm._infer_ready = True
        elif artifact:
            self._backend = LocalBackend(artifact)
        else:
            # Auto-detect daemon on localhost:7731 — use it if running
            from signai.client.backends import DaemonBackend
            from signai.client.daemon import try_daemon_endpoint
            ep = try_daemon_endpoint()
            if ep:
                self._backend = DaemonBackend(ep)

    def calibrate(
        self,
        loader,
        device: str,
        phase: str = "inference",
        calib_batches: int = 200,
        optimizer=None,
        criterion=None,
        warmup_steps: int = 200,
    ) -> None:
        from signai.client.backends import DaemonBackend

        self._device = device

        if isinstance(self._backend, DaemonBackend):
            self._calibrate_via_daemon(loader, device, phase, calib_batches, optimizer, criterion, warmup_steps)
            return

        raise RuntimeError(
            "Local calibration requires the signAI daemon. "
            "Start the daemon (`signai-server`) and pass no artifact/endpoint to Monitor — "
            "it will auto-connect on localhost:7731."
        )

    def _calibrate_via_daemon(self, loader, device, phase, calib_batches, optimizer, criterion, warmup_steps):
        """Extract (S, Z) locally using PyTorch hooks, stream to daemon for fitting."""
        import torch
        import torch.nn.functional as F
        from signai.client._torch_utils import _to_device, _forward, _example_tensor

        lm = self._lm
        model = lm.model
        s_batches: list = []
        z_batches: list = []

        if phase == "inference":
            model.eval()
            for i, (x, y) in enumerate(loader):
                if i >= calib_batches:
                    break
                x, y = _to_device(x, device), y.to(device)
                if not lm._infer_ready:
                    ex = _example_tensor(x)
                    if isinstance(x, dict):
                        probe = {k: (v[:8] if isinstance(v, torch.Tensor) else v) for k, v in x.items()}
                    else:
                        probe = ex[:8]
                    lm.prepare_inference_hooks(probe)

                x_t = _example_tensor(x)
                x_g = x_t.clone().detach()
                use_sens = x_g.is_floating_point()
                if use_sens:
                    x_g.requires_grad_(True)

                x_fwd = x
                if use_sens and isinstance(x, dict):
                    x_fwd = dict(x)
                    for k, v in x_fwd.items():
                        if isinstance(v, torch.Tensor):
                            x_fwd[k] = x_g
                            break
                elif use_sens:
                    x_fwd = x_g

                logits = _forward(model, x_fwd)
                s = lm.extractor.input_signature(x_g.detach(), logits.detach()).numpy()
                acts = lm.instrumentor.get_activations()
                a = lm.extractor.activation_signature(acts).numpy()
                sens = np.zeros(1, dtype=np.float32)
                if use_sens:
                    model.zero_grad(set_to_none=True)
                    if x_g.grad is not None:
                        x_g.grad.zero_()
                    try:
                        loss = F.cross_entropy(logits, y)
                        loss.backward()
                    except RuntimeError as exc:
                        msg = str(exc).lower()
                        if "cudnn rnn backward can only be called in training mode" not in msg:
                            raise
                        was_training = model.training
                        model.train()
                        model.zero_grad(set_to_none=True)
                        if x_g.grad is not None:
                            x_g.grad.zero_()
                        logits = _forward(model, x_fwd)
                        loss = F.cross_entropy(logits, y)
                        loss.backward()
                        if not was_training:
                            model.eval()
                    sens = lm.extractor.sensitivity_signature(x_g).numpy()
                z = np.concatenate([a, sens], axis=0)
                s_batches.append(s.tolist())
                z_batches.append(z.tolist())

        elif phase == "training":
            if optimizer is None or criterion is None:
                raise ValueError("optimizer and criterion are required for training calibration")
            model.train()
            lm.extractor.reset_ema()
            for i, (x, y) in enumerate(loader):
                if i >= warmup_steps:
                    break
                x, y = _to_device(x, device), y.to(device)
                optimizer.zero_grad()
                logits = _forward(model, x)
                loss = criterion(logits, y)
                loss.backward()
                optimizer.step()
                s = lm.extractor.batch_signature(logits.detach(), loss).numpy()
                z = lm.extractor.update_signature().numpy()
                s_batches.append(s.tolist())
                z_batches.append(z.tolist())
        else:
            raise ValueError(f"phase must be 'inference' or 'training', got {phase!r}")

        self._backend.calibrate(
            monitor_id=self._monitor_id,
            num_classes=lm.num_classes,
            phase=phase,
            s_batches=s_batches,
            z_batches=z_batches,
            hooks=list(lm.instrumentor.selected),
        )
        self._sync_lm_from_daemon()

    def _sync_lm_from_daemon(self) -> None:
        """Download the fitted artifact from the daemon and sync hooks into _lm."""
        artifact = self._backend.download_artifact_full(self._monitor_id)
        lm = self._lm
        hooks = artifact.get("hooks", [])
        if hooks:
            lm.instrumentor.selected = hooks
            lm.instrumentor.enable_selected_hooks()
            lm._infer_ready = True
        lm.num_classes = int(artifact.get("num_classes", lm.num_classes))
        self._daemon_artifact = artifact

    def save(self, path: str) -> None:
        from signai.client.backends import DaemonBackend, LocalBackend, RemoteBackend

        if isinstance(self._backend, DaemonBackend):
            artifact = getattr(self, "_daemon_artifact", None) or \
                       self._backend.download_artifact_full(self._monitor_id)
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(artifact, fh, indent=2, sort_keys=True)
            self._backend = LocalBackend(path)
            return

        raise RuntimeError(
            "save() is only supported after calibrate() via the daemon. "
            "Use the DaemonBackend flow to calibrate, then call save()."
        )

    def score_inference(self, x, y) -> MonitorResult:
        if self._backend is None:
            return MonitorResult(
                score=0.0,
                flagged=False,
                tau=0.0,
                phase="inference",
                monitor_id=self._monitor_id,
                error="No backend configured. Call save() after calibrate() first.",
            )
        try:
            s, z = self._extract_inference_features(x, y)
            result = self._backend.score_inference(s, z, self._monitor_id)
            if result.flagged and self._on_flag:
                self._on_flag(result)
            return result
        except Exception as exc:
            if self._on_error:
                self._on_error(exc)
            return MonitorResult(
                score=0.0,
                flagged=False,
                tau=0.0,
                phase="inference",
                monitor_id=self._monitor_id,
                error=str(exc),
            )

    def score_training(self, logits, loss) -> MonitorResult:
        if self._backend is None:
            return MonitorResult(
                score=0.0,
                flagged=False,
                tau=0.0,
                phase="training",
                monitor_id=self._monitor_id,
                error="No backend configured. Call save() after calibrate() first.",
            )
        try:
            s = self._lm.extractor.batch_signature(logits.detach(), loss).numpy()
            z = self._lm.extractor.update_signature().numpy()
            result = self._backend.score_training(s, z, self._monitor_id)
            if result.flagged and self._on_flag:
                self._on_flag(result)
            return result
        except Exception as exc:
            if self._on_error:
                self._on_error(exc)
            return MonitorResult(
                score=0.0,
                flagged=False,
                tau=0.0,
                phase="training",
                monitor_id=self._monitor_id,
                error=str(exc),
            )

    def _extract_inference_features(self, x, y):
        import torch
        import torch.nn.functional as F
        from signai.client._torch_utils import _to_device, _forward, _example_tensor

        lm = self._lm
        model = lm.model
        model.eval()

        x = _to_device(x, self._device)
        if y is not None:
            y = y.to(self._device)

        if not lm._infer_ready:
            ex = _example_tensor(x)
            if isinstance(x, dict):
                probe = {k: (v[:8] if isinstance(v, torch.Tensor) else v) for k, v in x.items()}
            else:
                probe = ex[:8]
            lm.prepare_inference_hooks(probe)

        x_t = _example_tensor(x)
        x_g = x_t.clone().detach()
        use_sens = bool(y is not None and x_g.is_floating_point())
        if use_sens:
            x_g.requires_grad_(True)

        x_fwd = x
        if use_sens and isinstance(x, dict):
            x_fwd = dict(x)
            for k, v in x_fwd.items():
                if isinstance(v, torch.Tensor):
                    x_fwd[k] = x_g
                    break
        elif use_sens:
            x_fwd = x_g

        logits = _forward(model, x_fwd)
        s = lm.extractor.input_signature(x_g.detach(), logits.detach()).numpy()
        acts = lm.instrumentor.get_activations()
        a = lm.extractor.activation_signature(acts).numpy()

        sens = np.zeros(1, dtype=np.float32)
        if use_sens:
            model.zero_grad(set_to_none=True)
            if x_g.grad is not None:
                x_g.grad.zero_()
            try:
                loss = F.cross_entropy(logits, y)
                loss.backward()
            except RuntimeError as exc:
                msg = str(exc).lower()
                if "cudnn rnn backward can only be called in training mode" not in msg:
                    raise
                was_training = model.training
                model.train()
                model.zero_grad(set_to_none=True)
                if x_g.grad is not None:
                    x_g.grad.zero_()
                logits = _forward(model, x_fwd)
                loss = F.cross_entropy(logits, y)
                loss.backward()
                if not was_training:
                    model.eval()
            sens = lm.extractor.sensitivity_signature(x_g).numpy()

        z = np.concatenate([a, sens], axis=0)
        return s, z
