from __future__ import annotations

import json
from typing import Callable, Optional

import numpy as np

from signai.client.monitor import MonitorResult
from signai.client._scorer import ArtifactDetector


class LocalBackend:
    def __init__(self, artifact_path: str):
        with open(artifact_path, encoding="utf-8") as f:
            payload = json.load(f)
        if payload.get("format") != "signai_integrity_v1":
            raise ValueError(f"Unsupported artifact format: {payload.get('format')!r}")
        self._det_infer  = ArtifactDetector.from_dict(payload["det_infer"])  if payload.get("det_infer")  else None
        self._det_update = ArtifactDetector.from_dict(payload["det_update"]) if payload.get("det_update") else None

    def score_inference(self, s: np.ndarray, z: np.ndarray, monitor_id: str) -> MonitorResult:
        try:
            if self._det_infer is None:
                raise RuntimeError("Inference detector not calibrated. Run calibrate() with phase='inference' first.")
            score = self._det_infer.score(s, z)
            return MonitorResult(
                score=score,
                flagged=score > self._det_infer.tau,
                tau=self._det_infer.tau,
                phase="inference",
                monitor_id=monitor_id,
            )
        except Exception as exc:
            return MonitorResult(
                score=0.0,
                flagged=False,
                tau=0.0,
                phase="inference",
                monitor_id=monitor_id,
                error=str(exc),
            )

    def score_training(self, s: np.ndarray, z: np.ndarray, monitor_id: str) -> MonitorResult:
        try:
            if self._det_update is None:
                raise RuntimeError("Training detector not calibrated. Run calibrate() with phase='training' first.")
            score = self._det_update.score(s, z)
            return MonitorResult(
                score=score,
                flagged=score > self._det_update.tau,
                tau=self._det_update.tau,
                phase="training",
                monitor_id=monitor_id,
            )
        except Exception as exc:
            return MonitorResult(
                score=0.0,
                flagged=False,
                tau=0.0,
                phase="training",
                monitor_id=monitor_id,
                error=str(exc),
            )

    def upload_artifact(self, path: str, monitor_id: str) -> None:
        return None


class DaemonBackend:
    """Talks to a local signai-daemon process (localhost:7731 by default).

    Handles calibration by streaming (S, Z) batches to the daemon via the
    start / push / commit protocol.  Scoring is a plain POST like RemoteBackend.
    """

    def __init__(self, endpoint: str | None = None):
        import requests
        from signai.client.daemon import daemon_endpoint
        self.endpoint = (endpoint or daemon_endpoint()).rstrip("/")
        self._session = requests.Session()
        self._session.headers["Content-Type"] = "application/json"

    # ── scoring (free, always) ────────────────────────────────────────── #

    def score_inference(self, s: np.ndarray, z: np.ndarray, monitor_id: str) -> "MonitorResult":
        return self._post_score("/v1/score/inference", s, z, monitor_id, "inference")

    def score_training(self, s: np.ndarray, z: np.ndarray, monitor_id: str) -> "MonitorResult":
        return self._post_score("/v1/score/training", s, z, monitor_id, "training")

    def _post_score(self, path, s, z, monitor_id, phase) -> "MonitorResult":
        import sys
        try:
            resp = self._session.post(
                f"{self.endpoint}{path}",
                json={"monitor_id": monitor_id, "s": s.tolist(), "z": z.tolist()},
                timeout=5.0,
            )
            resp.raise_for_status()
            payload = resp.json()
            nudge = payload.get("nudge")
            if nudge:
                print(f"[signAI] {nudge}", file=sys.stderr)
            return MonitorResult(
                score=float(payload["score"]),
                flagged=bool(payload["flagged"]),
                tau=float(payload["tau"]),
                phase=phase,
                monitor_id=monitor_id,
            )
        except Exception as exc:
            return MonitorResult(score=0.0, flagged=False, tau=0.0, phase=phase,
                                 monitor_id=monitor_id, error=str(exc))

    # ── calibration (metered) ─────────────────────────────────────────── #

    def calibrate(
        self,
        monitor_id: str,
        num_classes: int,
        phase: str,
        s_batches: list[list[float]],
        z_batches: list[list[float]],
        hooks: list[str] | None = None,
    ) -> dict:
        """Stream (S, Z) pairs to the daemon and commit.  Returns daemon response."""
        # start session
        resp = self._session.post(
            f"{self.endpoint}/v1/calibrate/start",
            json={"monitor_id": monitor_id, "num_classes": num_classes, "phase": phase, "hooks": hooks or []},
            timeout=10.0,
        )
        resp.raise_for_status()
        session_id = resp.json()["session_id"]

        # push in chunks of 50 to stay under request-size limits
        CHUNK = 50
        for i in range(0, len(s_batches), CHUNK):
            resp = self._session.post(
                f"{self.endpoint}/v1/calibrate/push",
                json={
                    "session_id": session_id,
                    "s_batch": s_batches[i : i + CHUNK],
                    "z_batch": z_batches[i : i + CHUNK],
                },
                timeout=30.0,
            )
            resp.raise_for_status()

        # commit (usage counter incremented here inside daemon)
        resp = self._session.post(
            f"{self.endpoint}/v1/calibrate/commit",
            json={"session_id": session_id},
            timeout=120.0,
        )
        if resp.status_code == 402:
            body = resp.json()
            detail = body.get("detail", body)
            msg = detail.get("message", str(detail)) if isinstance(detail, dict) else str(detail)
            raise RuntimeError(f"SignAILimitError: {msg}")
        resp.raise_for_status()
        return resp.json()

    def upload_artifact(self, path: str, monitor_id: str) -> None:
        with open(path, encoding="utf-8") as f:
            payload = json.load(f)
        resp = self._session.post(
            f"{self.endpoint}/v1/artifacts",
            json={"monitor_id": monitor_id, "artifact": payload},
            timeout=30.0,
        )
        resp.raise_for_status()

    def get_artifact(self, monitor_id: str) -> dict:
        resp = self._session.get(f"{self.endpoint}/v1/artifacts/{monitor_id}", timeout=10.0)
        resp.raise_for_status()
        return resp.json()

    def download_artifact_full(self, monitor_id: str) -> dict:
        """Download the complete artifact JSON (det_infer, det_update, hooks, etc.)."""
        resp = self._session.get(
            f"{self.endpoint}/v1/artifacts/{monitor_id}/download", timeout=10.0
        )
        resp.raise_for_status()
        return resp.json()

    # ── usage & license ───────────────────────────────────────────────── #

    def usage(self) -> dict:
        resp = self._session.get(f"{self.endpoint}/v1/usage", timeout=5.0)
        resp.raise_for_status()
        return resp.json()

    def apply_license_key(self, key: str) -> dict:
        resp = self._session.post(
            f"{self.endpoint}/v1/license",
            json={"key": key},
            timeout=10.0,
        )
        resp.raise_for_status()
        return resp.json()


class RemoteBackend:
    def __init__(
        self,
        endpoint: str,
        api_key: str,
        monitor_id: str,
        on_error: Optional[Callable[[Exception], None]] = None,
    ):
        import requests

        self.endpoint = endpoint.rstrip("/")
        self._monitor_id = monitor_id
        self._on_error = on_error
        self._session = requests.Session()
        if api_key:
            self._session.headers["Authorization"] = f"Bearer {api_key}"
        self._session.headers["Content-Type"] = "application/json"

    def score_inference(self, s: np.ndarray, z: np.ndarray, monitor_id: str) -> MonitorResult:
        return self._post_score("/v1/score/inference", s, z, monitor_id, "inference")

    def score_training(self, s: np.ndarray, z: np.ndarray, monitor_id: str) -> MonitorResult:
        return self._post_score("/v1/score/training", s, z, monitor_id, "training")

    def upload_artifact(self, path: str, monitor_id: str) -> None:
        payload = load_json(path)
        response = self._session.post(
            f"{self.endpoint}/v1/artifacts",
            json={"monitor_id": monitor_id, "artifact": payload},
            timeout=30.0,
        )
        response.raise_for_status()

    def get_artifact_metadata(self, monitor_id: str) -> dict:
        response = self._session.get(
            f"{self.endpoint}/v1/artifacts/{monitor_id}",
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()

    def _post_score(
        self,
        path: str,
        s: np.ndarray,
        z: np.ndarray,
        monitor_id: str,
        phase: str,
    ) -> MonitorResult:
        try:
            response = self._session.post(
                f"{self.endpoint}{path}",
                json={"monitor_id": monitor_id, "s": s.tolist(), "z": z.tolist()},
                timeout=5.0,
            )
            response.raise_for_status()
            payload = response.json()
            return MonitorResult(
                score=float(payload["score"]),
                flagged=bool(payload["flagged"]),
                tau=float(payload["tau"]),
                phase=phase,
                monitor_id=monitor_id,
            )
        except Exception as exc:
            if self._on_error:
                self._on_error(exc)
            return MonitorResult(
                score=0.0,
                flagged=False,
                tau=0.0,
                phase=phase,
                monitor_id=monitor_id,
                error=str(exc),
            )
