from __future__ import annotations


class CalibrationSession:
    def __init__(self):
        self._session = None
        self._endpoint = None

    def _make_session(self, api_key: str):
        import requests

        session = requests.Session()
        if api_key:
            session.headers["Authorization"] = f"Bearer {api_key}"
        session.headers["Content-Type"] = "application/json"
        return session

    def start(self, endpoint, api_key, monitor_id, num_classes, phase) -> str:
        self._endpoint = endpoint.rstrip("/")
        self._session = self._make_session(api_key)
        response = self._session.post(
            f"{self._endpoint}/v1/calibrate/start",
            json={
                "monitor_id": monitor_id,
                "num_classes": num_classes,
                "phase": phase,
            },
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()["session_id"]

    def push(self, session_id, s_batch, z_batch) -> int:
        response = self._session.post(
            f"{self._endpoint}/v1/calibrate/push",
            json={
                "session_id": session_id,
                "s_batch": s_batch,
                "z_batch": z_batch,
            },
            timeout=30.0,
        )
        response.raise_for_status()
        return int(response.json()["total"])

    def commit(self, session_id) -> dict:
        response = self._session.post(
            f"{self._endpoint}/v1/calibrate/commit",
            json={"session_id": session_id},
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
