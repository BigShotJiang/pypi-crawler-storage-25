"""Daemon discovery and health check helpers.

Checks whether signai-daemon is running on localhost.
Does NOT auto-start — tell the user how to start it instead.

Start the daemon:
    signai-daemon                        # native binary
    docker run -p 7731:7731 signai/daemon  # Docker
    python -m signai_server              # development
"""
from __future__ import annotations

import os
from typing import Optional

DAEMON_DEFAULT_PORT = int(os.environ.get("SIGNAI_DAEMON_PORT", "7731"))
DAEMON_DEFAULT_HOST = os.environ.get("SIGNAI_DAEMON_HOST", "127.0.0.1")


def daemon_endpoint(host: str = DAEMON_DEFAULT_HOST, port: int = DAEMON_DEFAULT_PORT) -> str:
    return f"http://{host}:{port}"


def is_running(host: str = DAEMON_DEFAULT_HOST, port: int = DAEMON_DEFAULT_PORT) -> bool:
    """Return True if a signai-daemon is reachable and healthy on host:port."""
    try:
        import urllib.request
        url = f"http://{host}:{port}/health"
        with urllib.request.urlopen(url, timeout=1.0) as resp:
            import json
            body = json.loads(resp.read())
            return bool(body.get("ok"))
    except Exception:
        return False


def require_daemon(host: str = DAEMON_DEFAULT_HOST, port: int = DAEMON_DEFAULT_PORT) -> str:
    """Return the daemon endpoint, or raise a helpful RuntimeError if not running."""
    endpoint = daemon_endpoint(host, port)
    if not is_running(host, port):
        raise RuntimeError(
            f"signai-daemon is not running on {endpoint}.\n"
            "Start it with one of:\n"
            "  signai-daemon                            # native binary\n"
            "  docker run -p 7731:7731 signai/daemon    # Docker\n"
            "  python -m signai_server                  # development\n"
            f"Or set SIGNAI_DAEMON_PORT / SIGNAI_DAEMON_HOST to point elsewhere."
        )
    return endpoint


def try_daemon_endpoint(host: str = DAEMON_DEFAULT_HOST, port: int = DAEMON_DEFAULT_PORT) -> Optional[str]:
    """Return the daemon endpoint if running, else None (no exception)."""
    if is_running(host, port):
        return daemon_endpoint(host, port)
    return None
