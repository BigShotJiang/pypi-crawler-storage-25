import torch


def _to_device(x, device):
    """Move x to device — handles plain tensors and HuggingFace dict inputs."""
    if isinstance(x, dict):
        return {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in x.items()}
    return x.to(device)


def _forward(model, x):
    """Run forward pass — handles plain tensors and HuggingFace dict inputs/outputs."""
    out = model(**x) if isinstance(x, dict) else model(x)
    if hasattr(out, "logits"):
        return out.logits
    return out


def _example_tensor(x):
    """Return a plain tensor from x for hook auto-selection (uses first value if dict)."""
    if isinstance(x, dict):
        return next(v for v in x.values() if isinstance(v, torch.Tensor))
    return x


def _set_primary_input(x, replacement: torch.Tensor):
    """Return x with the first tensor input replaced by replacement."""
    if isinstance(x, dict):
        out = dict(x)
        for k, v in out.items():
            if isinstance(v, torch.Tensor):
                out[k] = replacement
                return out
        return out
    return replacement
