"""Minimal artifact scorer — loads from JSON, no fitting logic."""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np


@dataclass
class _MLPJSON:
    activation: str
    coefs: List[np.ndarray]
    intercepts: List[np.ndarray]

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        H = X
        for i, (W, b) in enumerate(zip(self.coefs, self.intercepts)):
            H = H @ W + b
            if i < len(self.coefs) - 1:
                if self.activation == "relu":
                    H = np.maximum(H, 0.0)
                elif self.activation == "tanh":
                    H = np.tanh(H)
                elif self.activation == "logistic":
                    H = 1.0 / (1.0 + np.exp(-H))
                else:
                    raise ValueError(f"Unsupported activation: {self.activation}")
        return H

    @staticmethod
    def from_dict(d: dict) -> "_MLPJSON":
        return _MLPJSON(
            activation=d["activation"],
            coefs=[np.asarray(w, dtype=np.float64) for w in d["coefs"]],
            intercepts=[np.asarray(b, dtype=np.float64) for b in d["intercepts"]],
        )


class ArtifactDetector:
    """Read-only Mahalanobis scorer. Loads from artifact dict, never fits."""

    def __init__(self, s_dim: int, z_dim: int, tau: float, mu_json: _MLPJSON, inv_cov: np.ndarray):
        self.s_dim = s_dim
        self.z_dim = z_dim
        self.tau = tau
        self._mu = mu_json
        self._inv_cov = inv_cov

    def score(self, s: np.ndarray, z: np.ndarray) -> float:
        z = np.asarray(z, dtype=np.float64).reshape(-1)
        s = np.asarray(s, dtype=np.float64).reshape(1, -1)
        mu = self._mu.predict(s).reshape(-1)
        r = z - mu
        return float(r.T @ self._inv_cov @ r)

    @staticmethod
    def from_dict(d: dict) -> "ArtifactDetector":
        return ArtifactDetector(
            s_dim=int(d["s_dim"]),
            z_dim=int(d["z_dim"]),
            tau=float(d["tau"]),
            mu_json=_MLPJSON.from_dict(d["mlp"]),
            inv_cov=np.asarray(d["inv_cov"], dtype=np.float64),
        )
