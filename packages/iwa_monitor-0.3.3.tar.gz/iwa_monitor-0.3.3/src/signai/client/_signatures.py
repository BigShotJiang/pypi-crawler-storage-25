import torch
import torch.nn.functional as F
from typing import Dict, List, Optional


class SignatureExtractor:
    def __init__(self, model, instrumentor=None):
        self.model = model
        self.instrumentor = instrumentor
        self._prev_params: Optional[torch.Tensor] = None
        self._ema_update: Optional[torch.Tensor] = None

    @staticmethod
    def _logit_stats(logits: torch.Tensor) -> torch.Tensor:
        probs = F.softmax(logits, dim=1)
        entropy = (-probs * torch.log(probs + 1e-8)).sum(dim=1)
        top2 = probs.topk(2, dim=1).values
        margin = top2[:, 0] - top2[:, 1]
        return torch.stack([
            entropy.mean(),
            entropy.std(unbiased=False),
            margin.mean(),
            margin.std(unbiased=False),
            probs.max(dim=1).values.mean(),
        ])

    def batch_signature(self, logits: torch.Tensor, loss: torch.Tensor) -> torch.Tensor:
        return torch.cat([loss.detach().reshape(1).cpu(), self._logit_stats(logits).detach().cpu()]).float()

    def reset_ema(self) -> None:
        self._prev_params = None
        self._ema_update = None

    def update_signature(self) -> torch.Tensor:
        flat = torch.cat([p.detach().view(-1).cpu() for p in self.model.parameters() if p.requires_grad])
        if self._prev_params is None:
            self._prev_params = flat.clone()
            return torch.zeros(6, dtype=torch.float32)
        delta = flat - self._prev_params
        self._prev_params = flat.clone()
        if self._ema_update is None:
            self._ema_update = delta.clone()
        l2 = torch.norm(delta, p=2)
        linf = torch.norm(delta, p=float("inf"))
        cos = F.cosine_similarity(delta.unsqueeze(0), self._ema_update.unsqueeze(0)).squeeze(0)
        sign_flip = (torch.sign(delta) != torch.sign(self._ema_update)).float().mean()
        mean = delta.mean()
        std = delta.std(unbiased=False)
        self._ema_update = 0.9 * self._ema_update + 0.1 * delta
        return torch.stack([l2, linf, cos, sign_flip, mean, std]).float()

    @staticmethod
    def input_signature(x: torch.Tensor, logits: torch.Tensor) -> torch.Tensor:
        lstats = SignatureExtractor._logit_stats(logits).detach().cpu()
        x_flat = x.detach().float().view(x.shape[0], -1)
        x_l2 = torch.norm(x_flat, dim=1).mean().cpu()
        x_std = x_flat.std(dim=1, unbiased=False).mean().cpu()
        return torch.cat([lstats, torch.tensor([x_l2, x_std])]).float()

    @staticmethod
    def activation_signature(acts: Dict[str, torch.Tensor], eps: float = 1e-6) -> torch.Tensor:
        feats: List[torch.Tensor] = []
        for h in acts.values():
            hf = h.view(h.shape[0], -1)
            feats.extend([
                hf.mean(dim=0).norm(p=2),
                hf.std(dim=0, unbiased=False).norm(p=2),
                hf.norm(p=2, dim=1).mean(),
                hf.norm(p=2, dim=1).std(unbiased=False),
                (hf.abs() < eps).float().mean(),
            ])
        if not feats:
            return torch.zeros(5, dtype=torch.float32)
        return torch.stack(feats).detach().cpu().float()

    @staticmethod
    def sensitivity_signature(x: torch.Tensor) -> torch.Tensor:
        if x.grad is None:
            return torch.zeros(1, dtype=torch.float32)
        g = x.grad.detach().view(x.shape[0], -1)
        return torch.tensor([torch.norm(g, dim=1).mean().cpu()], dtype=torch.float32)
