import torch
import torch.nn as nn
from typing import Any, Dict, List, Tuple


def _is_leaf_module(m: nn.Module) -> bool:
    return len(list(m.children())) == 0


class AutoInstrumentor:
    def __init__(self, model: nn.Module):
        self.model = model
        self._leaf_by_name: Dict[str, nn.Module] = {}
        self._probe_handles: List[Any] = []
        self._keep_handles: List[Any] = []
        self._records: List[Tuple[str, torch.Size]] = []
        self._latest_acts: Dict[str, torch.Tensor] = {}
        self.selected: List[str] = []
        for name, m in self.model.named_modules():
            if _is_leaf_module(m):
                self._leaf_by_name[name] = m

    def _clear_probe(self):
        for h in self._probe_handles:
            try:
                h.remove()
            except Exception:
                pass
        self._probe_handles = []

    def _clear_keep(self):
        for h in self._keep_handles:
            try:
                h.remove()
            except Exception:
                pass
        self._keep_handles = []
        self._latest_acts = {}

    def _probe_hook(self, name: str):
        def _hook(module, inp, out):
            if isinstance(out, torch.Tensor):
                self._records.append((name, out.shape))
        return _hook

    def _keep_hook(self, name: str):
        def _hook(module, inp, out):
            if isinstance(out, torch.Tensor):
                self._latest_acts[name] = out.detach()
        return _hook

    @torch.no_grad()
    def auto_select_layers(self, example_batch) -> List[str]:
        self._records = []
        self._latest_acts = {}
        self._clear_probe()
        for name, m in self._leaf_by_name.items():
            self._probe_handles.append(m.register_forward_hook(self._probe_hook(name)))
        if isinstance(example_batch, dict):
            _ = self.model(**example_batch)
        else:
            _ = self.model(example_batch)
        self._clear_probe()
        candidates = [(n, s) for (n, s) in self._records if len(s) >= 2]
        if not candidates:
            self.selected = []
            return self.selected
        n = len(candidates)
        idxs = sorted(set([max(0, int(0.10 * (n - 1))), max(0, int(0.50 * (n - 1))), max(0, int(0.90 * (n - 1)))]))
        self.selected = []
        for i in idxs:
            name = candidates[i][0]
            if name not in self.selected:
                self.selected.append(name)
        return self.selected

    def enable_selected_hooks(self):
        self._clear_keep()
        for name in self.selected:
            m = self._leaf_by_name.get(name)
            if m is not None:
                self._keep_handles.append(m.register_forward_hook(self._keep_hook(name)))

    def get_activations(self) -> Dict[str, torch.Tensor]:
        return dict(self._latest_acts)

    def close(self):
        self._clear_probe()
        self._clear_keep()
