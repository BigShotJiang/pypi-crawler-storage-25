"""
signAI - Behavioral integrity layer for AI systems.

Your model weights never leave your infrastructure.
"""

from .client import monitor
from .client.monitor import Monitor, MonitorResult, attach, load

__version__ = "0.3.3"
__all__ = [
    "Monitor",
    "MonitorResult",
    "attach",
    "load",
    "monitor",
]
