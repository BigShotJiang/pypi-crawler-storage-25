from __future__ import annotations

import argparse
import json
import os
import sys


def cmd_version(args):
    from signai import __version__
    print(f"signai {__version__}")


def cmd_status(args):
    from signai.client.daemon import try_daemon_endpoint
    from signai.client.backends import DaemonBackend

    ep = try_daemon_endpoint()
    if not ep:
        print("signai daemon: not running (start with `signai-server`)")
        sys.exit(1)

    try:
        b = DaemonBackend(ep)
        usage = b.usage()
        print(f"signai daemon: running at {ep}")
        print(json.dumps(usage, indent=2))
    except Exception as exc:
        print(f"signai daemon: error — {exc}")
        sys.exit(1)


def cmd_license(args):
    from signai.client.daemon import try_daemon_endpoint
    from signai.client.backends import DaemonBackend

    ep = try_daemon_endpoint()
    if not ep:
        print("Error: signai daemon not running. Start it first.")
        sys.exit(1)

    try:
        b = DaemonBackend(ep)
        result = b.apply_license_key(args.key)
        print(f"License applied. Tier: {result.get('tier')}, Expiry: {result.get('expiry')}")
    except Exception as exc:
        print(f"Error applying license: {exc}")
        sys.exit(1)


def build_parser():
    parser = argparse.ArgumentParser(prog="signai", description="signAI SDK CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("version").set_defaults(func=cmd_version)

    sub.add_parser("status").set_defaults(func=cmd_status)

    lic = sub.add_parser("license", help="Apply a license key to the local daemon")
    lic.add_argument("key", help="License key string")
    lic.set_defaults(func=cmd_license)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)
