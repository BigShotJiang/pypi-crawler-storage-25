from __future__ import annotations

from collections import OrderedDict

import torch

from signai.core.signatures import SignatureExtractor


def test_activation_signature_preserves_capture_order():
    acts = OrderedDict(
        [
            ("layer10", torch.full((2, 1, 1, 1), 10.0)),
            ("layer2", torch.full((2, 1, 1, 1), 2.0)),
            ("layer1", torch.full((2, 1, 1, 1), 1.0)),
        ]
    )

    features = SignatureExtractor.activation_signature(acts)

    # Each layer contributes 5 features. The first feature of each block is
    # the L2 norm of the per-dimension mean, which equals the scalar value here.
    assert torch.isclose(features[0], torch.tensor(10.0))
    assert torch.isclose(features[5], torch.tensor(2.0))
    assert torch.isclose(features[10], torch.tensor(1.0))
