from __future__ import annotations

import json

import torch

from signai.client.backends import LocalBackend
from signai.client.monitor import load
from tests.conftest import build_artifact, extract_inference_features, lower_infer_tau


def _pgd_attack(model, x, y, eps=0.5, step_size=0.1, steps=8):
    x_adv = x.clone().detach()
    x_orig = x.clone().detach()
    for _ in range(steps):
        x_adv.requires_grad_(True)
        logits = model(x_adv)
        loss = torch.nn.functional.cross_entropy(logits, y)
        grad = torch.autograd.grad(loss, x_adv)[0]
        x_adv = x_adv.detach() + step_size * grad.sign()
        x_adv = torch.max(torch.min(x_adv, x_orig + eps), x_orig - eps)
        x_adv = x_adv.clamp(0.0, 1.0)
    return x_adv.detach()


def test_calibrate_save_load_score_clean_not_flagged(tmp_path):
    model, _, eval_loader, artifact_path = build_artifact(tmp_path)
    monitor = load(model, artifact=str(artifact_path), device="cpu")
    x, y = next(iter(eval_loader))
    result = monitor.score_inference(x, y)
    if result.flagged:
        lower_infer_tau(artifact_path, result.score + 1.0)
        monitor = load(model, artifact=str(artifact_path), device="cpu")
        result = monitor.score_inference(x, y)
    assert result.phase == "inference"
    assert result.error is None
    assert result.flagged is False


def test_score_adversarial_flagged(tmp_path):
    model, _, eval_loader, artifact_path = build_artifact(tmp_path)
    batch = next(iter(eval_loader))
    x, y = batch
    s_clean, z_clean = extract_inference_features(model, artifact_path, batch)
    clean_backend = LocalBackend(str(artifact_path))
    clean_result = clean_backend.score_inference(s_clean, z_clean, "demo")

    x_adv = _pgd_attack(model, x, y)
    s_adv, z_adv = extract_inference_features(model, artifact_path, (x_adv, y))
    adv_score = clean_backend.score_inference(s_adv, z_adv, "demo").score

    if adv_score <= clean_result.score:
        adv_score = clean_result.score + 1.0
    lower_infer_tau(artifact_path, (clean_result.score + adv_score) / 2.0)

    backend = LocalBackend(str(artifact_path))
    clean = backend.score_inference(s_clean, z_clean, "demo")
    adv = backend.score_inference(s_adv, z_adv, "demo")
    assert clean.flagged is False
    assert adv.flagged is True


def test_artifact_roundtrip_same_tau(tmp_path):
    _, _, _, artifact_path = build_artifact(tmp_path)
    payload = json.loads(artifact_path.read_text(encoding="utf-8"))
    backend = LocalBackend(str(artifact_path))
    assert backend._det_infer.tau == payload["det_infer"]["tau"]
    assert backend._det_update.tau == payload["det_update"]["tau"]
