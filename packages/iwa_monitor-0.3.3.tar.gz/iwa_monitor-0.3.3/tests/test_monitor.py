from __future__ import annotations

import torch

from signai.client import monitor
from signai.client.monitor import MonitorResult
from tests.conftest import build_artifact, make_pattern_loaders


def test_attach_calibrate_save_load_end_to_end(tmp_path):
    train_loader, eval_loader = make_pattern_loaders()
    model = torch.nn.Sequential(
        torch.nn.Conv2d(1, 8, kernel_size=3, padding=1),
        torch.nn.ReLU(),
        torch.nn.Flatten(),
        torch.nn.Linear(8 * 28 * 28, 10),
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = torch.nn.CrossEntropyLoss()

    attached = monitor.attach(model, num_classes=10, device="cpu")
    attached.calibrate(eval_loader, device="cpu", phase="inference", calib_batches=4)
    attached.calibrate(
        train_loader,
        device="cpu",
        phase="training",
        optimizer=optimizer,
        criterion=criterion,
        warmup_steps=4,
    )

    artifact_path = tmp_path / "monitor.json"
    attached.save(str(artifact_path))
    loaded = monitor.load(model, artifact=str(artifact_path), device="cpu")
    x, y = next(iter(eval_loader))
    result = loaded.score_inference(x, y)
    assert isinstance(result, MonitorResult)
    assert result.error is None


def test_score_inference_returns_monitor_result(tmp_path):
    model, _, eval_loader, artifact_path = build_artifact(tmp_path)
    loaded = monitor.load(model, artifact=str(artifact_path), device="cpu")
    x, y = next(iter(eval_loader))
    result = loaded.score_inference(x, y)
    assert isinstance(result, MonitorResult)
    assert result.phase == "inference"


def test_score_training_returns_monitor_result(tmp_path):
    model, train_loader, _, artifact_path = build_artifact(tmp_path)
    loaded = monitor.load(model, artifact=str(artifact_path), device="cpu")
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = torch.nn.CrossEntropyLoss()
    x, y = next(iter(train_loader))
    optimizer.zero_grad()
    logits = model(x)
    loss = criterion(logits, y)
    loss.backward()
    optimizer.step()
    result = loaded.score_training(logits, loss)
    assert isinstance(result, MonitorResult)
    assert result.phase == "training"


def test_on_flag_callback_fires_when_flagged(tmp_path):
    fired = []
    model, _, eval_loader, artifact_path = build_artifact(tmp_path)
    loaded = monitor.load(
        model,
        artifact=str(artifact_path),
        device="cpu",
        monitor_id="demo-monitor",
        on_flag=fired.append,
    )
    loaded._backend._det_infer.tau = -1.0
    x, y = next(iter(eval_loader))
    result = loaded.score_inference(x, y)
    assert result.flagged is True
    assert len(fired) == 1
    assert fired[0].monitor_id == "demo-monitor"


def test_network_error_returns_safe_monitor_result(monkeypatch):
    class FailingRemoteBackend:
        def __init__(self, endpoint, api_key, monitor_id, on_error=None):
            self._on_error = on_error

        def get_artifact_metadata(self, monitor_id):
            return {"hooks": []}

        def score_inference(self, s, z, monitor_id):
            exc = RuntimeError("network down")
            if self._on_error:
                self._on_error(exc)
            return MonitorResult(
                score=0.0,
                flagged=False,
                tau=0.0,
                phase="inference",
                monitor_id=monitor_id,
                error="network down",
            )

        def score_training(self, s, z, monitor_id):
            return self.score_inference(s, z, monitor_id)

        def upload_artifact(self, path, monitor_id):
            raise AssertionError("not used")

    errors = []
    monkeypatch.setattr("signai.client.backends.RemoteBackend", FailingRemoteBackend)

    model = torch.nn.Sequential(
        torch.nn.Conv2d(1, 8, kernel_size=3, padding=1),
        torch.nn.ReLU(),
        torch.nn.Flatten(),
        torch.nn.Linear(8 * 28 * 28, 10),
    )
    _, eval_loader = make_pattern_loaders()
    attached = monitor.attach(
        model,
        num_classes=10,
        endpoint="http://unit.test",
        monitor_id="demo-monitor",
        on_error=errors.append,
        device="cpu",
    )
    x, y = next(iter(eval_loader))
    result = attached.score_inference(x, y)
    assert result.error == "network down"
    assert result.flagged is False
    assert len(errors) == 1
