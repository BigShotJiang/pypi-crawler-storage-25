from __future__ import annotations

import json

from fastapi.testclient import TestClient

import signai_server.edition as edition_module
from signai_server.api import create_app
from signai_server.store import FileStore
from tests.conftest import build_artifact, extract_inference_features


def test_health_returns_200(tmp_path):
    client = TestClient(create_app(store=FileStore(str(tmp_path / "artifacts"))))
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["ok"] is True


def test_post_artifact_with_real_artifact_returns_200(tmp_path):
    _, _, _, artifact_path = build_artifact(tmp_path)
    payload = json.loads(artifact_path.read_text(encoding="utf-8"))
    client = TestClient(create_app(store=FileStore(str(tmp_path / "artifacts"))))
    response = client.post("/v1/artifacts", json={"monitor_id": "demo", "artifact": payload})
    assert response.status_code == 200
    assert response.json()["monitor_id"] == "demo"


def test_post_score_inference_with_valid_sz_returns_score(tmp_path):
    model, _, eval_loader, artifact_path = build_artifact(tmp_path)
    payload = json.loads(artifact_path.read_text(encoding="utf-8"))
    client = TestClient(create_app(store=FileStore(str(tmp_path / "artifacts"))))
    client.post("/v1/artifacts", json={"monitor_id": "demo", "artifact": payload})

    batch = next(iter(eval_loader))
    s, z = extract_inference_features(model, artifact_path, batch)
    response = client.post(
        "/v1/score/inference",
        json={"monitor_id": "demo", "s": s.tolist(), "z": z.tolist()},
    )
    assert response.status_code == 200
    body = response.json()
    assert "score" in body
    assert "tau" in body


def test_post_score_inference_wrong_s_dim_returns_422(tmp_path):
    _, _, _, artifact_path = build_artifact(tmp_path)
    payload = json.loads(artifact_path.read_text(encoding="utf-8"))
    client = TestClient(create_app(store=FileStore(str(tmp_path / "artifacts"))))
    client.post("/v1/artifacts", json={"monitor_id": "demo", "artifact": payload})
    response = client.post(
        "/v1/score/inference",
        json={"monitor_id": "demo", "s": [0.0] * 6, "z": [0.0] * 16},
    )
    assert response.status_code == 422


def test_get_history_without_pro_returns_402(tmp_path):
    previous = edition_module.EDITION
    edition_module.EDITION = "community"
    try:
        client = TestClient(create_app(store=FileStore(str(tmp_path / "artifacts"))))
        response = client.get("/v1/history/demo")
        assert response.status_code == 402
    finally:
        edition_module.EDITION = previous


def test_get_history_with_pro_returns_200(tmp_path):
    previous = edition_module.EDITION
    edition_module.EDITION = "pro"
    try:
        client = TestClient(create_app(store=FileStore(str(tmp_path / "artifacts"))))
        response = client.get("/v1/history/demo")
        assert response.status_code == 200
        assert response.json() == {"events": []}
    finally:
        edition_module.EDITION = previous
