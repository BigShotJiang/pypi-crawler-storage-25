def test_imports():
    import signai
    from signai.core.integrity import IWAIntegrityModel
    from signai.core.detector import ConditionalMahalanobis
    assert IWAIntegrityModel is not None
    assert ConditionalMahalanobis is not None
