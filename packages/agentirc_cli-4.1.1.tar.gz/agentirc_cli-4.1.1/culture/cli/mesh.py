"""Mesh subcommands: culture mesh {overview,setup,update,console}."""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import shutil
import subprocess
import sys
import time

from culture.clients.claude.config import (
    load_config,
    load_config_or_default,
)
from culture.pidfile import is_process_alive, read_pid

from ._helpers import (
    DEFAULT_CONFIG,
    build_server_start_cmd,
    generate_mesh_from_agents,
    server_stop_by_name,
    stop_agent,
)

logger = logging.getLogger("culture")

NAME = "mesh"


def register(subparsers: argparse._SubParsersAction) -> None:
    mesh_parser = subparsers.add_parser(
        "mesh", help="Mesh operations (overview, setup, update, console)"
    )
    mesh_sub = mesh_parser.add_subparsers(dest="mesh_command")

    # -- overview -------------------------------------------------------------
    overview_parser = mesh_sub.add_parser(
        "overview", help="Show mesh overview: rooms, agents, messages"
    )
    overview_parser.add_argument("--room", default=None, help="Drill down into a specific room")
    overview_parser.add_argument("--agent", default=None, help="Drill down into a specific agent")
    overview_parser.add_argument(
        "--messages",
        "-n",
        type=int,
        default=4,
        help="Messages per room (default: 4, max: 20)",
    )
    overview_parser.add_argument("--serve", action="store_true", help="Start live web dashboard")
    overview_parser.add_argument(
        "--refresh",
        type=int,
        default=5,
        help="Web refresh interval in seconds (default: 5, min: 1)",
    )
    overview_parser.add_argument("--config", default=DEFAULT_CONFIG)

    # -- setup ----------------------------------------------------------------
    setup_parser = mesh_sub.add_parser("setup", help="Set up mesh from mesh.yaml")
    setup_parser.add_argument(
        "--config",
        default=os.path.expanduser("~/.culture/mesh.yaml"),
        help="Path to mesh.yaml",
    )
    setup_parser.add_argument(
        "--uninstall",
        action="store_true",
        help="Remove auto-start entries and stop services",
    )

    # -- update ---------------------------------------------------------------
    update_parser = mesh_sub.add_parser("update", help="Upgrade and restart the mesh")
    update_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would happen without executing",
    )
    update_parser.add_argument(
        "--skip-upgrade",
        action="store_true",
        help="Just restart, don't upgrade the package",
    )
    update_parser.add_argument(
        "--config",
        default=os.path.expanduser("~/.culture/mesh.yaml"),
        help="Path to mesh.yaml",
    )

    # -- console --------------------------------------------------------------
    console_parser = mesh_sub.add_parser("console", help="Interactive admin console")
    console_parser.add_argument(
        "server_name",
        nargs="?",
        default=None,
        help="Server to connect to (auto-detects if omitted)",
    )
    console_parser.add_argument(
        "--config",
        default=DEFAULT_CONFIG,
        help="Config file path",
    )


def dispatch(args: argparse.Namespace) -> None:
    if not args.mesh_command:
        print("Usage: culture mesh {overview|setup|update|console}", file=sys.stderr)
        sys.exit(1)

    handlers = {
        "overview": _cmd_overview,
        "setup": _cmd_setup,
        "update": _cmd_update,
        "console": _cmd_console,
    }
    handler = handlers.get(args.mesh_command)
    if handler:
        handler(args)
    else:
        print(f"Unknown mesh command: {args.mesh_command}", file=sys.stderr)
        sys.exit(1)


# -----------------------------------------------------------------------
# Overview
# -----------------------------------------------------------------------


def _cmd_overview(args: argparse.Namespace) -> None:
    """Show mesh overview."""
    from culture.overview.collector import collect_mesh_state
    from culture.overview.renderer_text import render_text

    config = load_config_or_default(args.config)
    message_limit = max(1, min(args.messages, 20))
    refresh_interval = max(1, args.refresh)

    if args.serve:
        from culture.overview.renderer_web import serve_web

        serve_web(
            host=config.server.host,
            port=config.server.port,
            server_name=config.server.name,
            room_filter=args.room,
            agent_filter=args.agent,
            message_limit=message_limit,
            refresh_interval=refresh_interval,
        )
        return

    host, port = config.server.host, config.server.port
    try:
        mesh = asyncio.run(
            collect_mesh_state(
                host=host,
                port=port,
                server_name=config.server.name,
                message_limit=message_limit,
            )
        )
    except ConnectionRefusedError:
        print(
            f"Error: could not connect to {host}:{port} — is the server running?",
            file=sys.stderr,
        )
        sys.exit(1)
    except TimeoutError:
        print(
            f"Error: server at {host}:{port} not responding" " — it may still be starting up",
            file=sys.stderr,
        )
        sys.exit(1)
    except OSError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    output = render_text(
        mesh,
        room_filter=args.room,
        agent_filter=args.agent,
        message_limit=message_limit,
    )
    print(output, end="")


# -----------------------------------------------------------------------
# Console
# -----------------------------------------------------------------------


def _resolve_server(server_name: str | None) -> tuple[str, int] | None:
    """Resolve server name and port from running servers."""
    from culture.pidfile import list_servers, read_default_server, read_port

    if server_name:
        p = read_port(server_name)
        port = p if p else 6667
        return server_name, port

    servers = list_servers()
    if not servers:
        return None

    if len(servers) == 1:
        return servers[0]["name"], servers[0]["port"]

    default = read_default_server()
    if default:
        match = [s for s in servers if s["name"] == default]
        if match:
            return match[0]["name"], match[0]["port"]

    return servers[0]["name"], servers[0]["port"]


def _resolve_console_nick() -> str:
    """Resolve the human nick: git username -> OS user -> config override."""
    import re
    import subprocess

    try:
        result = subprocess.run(
            ["git", "config", "user.name"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.returncode == 0 and result.stdout.strip():
            name = result.stdout.strip().lower()
            name = re.sub(r"[^a-z0-9-]", "", name.replace(" ", "-"))
            if name:
                return name
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    import os

    return os.environ.get("USER", "human")


def _cmd_console(args: argparse.Namespace) -> None:
    """Launch the interactive console TUI."""
    result = _resolve_server(args.server_name)
    if result is None:
        print("No culture servers running. Start one with: culture server start")
        return

    server_name, port = result
    host = "127.0.0.1"

    nick_suffix = _resolve_console_nick()
    nick = f"{server_name}-{nick_suffix}"

    from culture.console.app import ConsoleApp
    from culture.console.client import ConsoleIRCClient

    client = ConsoleIRCClient(host=host, port=port, nick=nick, mode="H")

    async def run():
        await client.connect()
        app = ConsoleApp(irc_client=client, server_name=server_name)
        await app.run_async()

    asyncio.run(run())


# -----------------------------------------------------------------------
# Setup
# -----------------------------------------------------------------------


def _store_mesh_credentials(mesh) -> None:
    """Prompt for link passwords and store them in the OS keyring (never in files)."""
    import getpass

    from culture.credentials import lookup_credential, store_credential

    for link in mesh.server.links:
        existing = lookup_credential(link.name)
        if existing:
            print(f"  Credential for '{link.name}' already in keyring")
        else:
            password = getpass.getpass(f"Link password for {link.name}: ")
            if store_credential(link.name, password):
                print(f"  Stored credential for '{link.name}' in OS keyring")
            else:
                print(
                    f"  Warning: failed to store credential for '{link.name}'",
                    file=sys.stderr,
                )
                print(
                    "  You may need to install secret-tool (Linux)"
                    " or check Keychain access (macOS)",
                    file=sys.stderr,
                )


def _generate_agent_configs(mesh, server_name: str) -> None:
    """Generate agents.yaml for each agent workdir defined in the mesh config."""
    from culture.clients.claude.config import AgentConfig as BaseAgentConfig
    from culture.clients.claude.config import (
        DaemonConfig,
        ServerConnConfig,
        save_config,
    )

    workdir_agents: dict[str, list] = {}
    for agent in mesh.agents:
        workdir = os.path.expanduser(agent.workdir)
        workdir_agents.setdefault(workdir, []).append(agent)

    for workdir, agents in workdir_agents.items():
        os.makedirs(workdir, exist_ok=True)
        config_path = os.path.join(workdir, ".culture", "agents.yaml")
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        agent_configs = []
        for a in agents:
            full_nick = f"{server_name}-{a.nick}"
            agent_configs.append(
                BaseAgentConfig(
                    nick=full_nick,
                    agent=a.type,
                    directory=workdir,
                    channels=list(a.channels),
                )
            )

        daemon_config = DaemonConfig(
            server=ServerConnConfig(name=server_name, host="localhost", port=mesh.server.port),
            agents=agent_configs,
        )
        save_config(config_path, daemon_config)
        print(f"  Wrote {config_path}")


def _install_mesh_services(mesh, server_name: str, culture_bin: str, config_path: str) -> None:
    """Install auto-start service entries for the server and all agents."""
    from culture.persistence import install_service

    server_cmd = build_server_start_cmd(mesh, culture_bin, config_path)
    svc_name = f"culture-server-{server_name}"
    path = install_service(svc_name, server_cmd, f"culture server {server_name}")
    print(f"  Installed {svc_name} → {path}")

    for agent in mesh.agents:
        full_nick = f"{server_name}-{agent.nick}"
        workdir = os.path.expanduser(agent.workdir)
        agent_config_path = os.path.join(workdir, ".culture", "agents.yaml")
        agent_cmd = [
            culture_bin,
            "agent",
            "start",
            full_nick,
            "--foreground",
            "--config",
            agent_config_path,
        ]
        agent_svc = f"culture-agent-{full_nick}"
        path = install_service(agent_svc, agent_cmd, f"culture agent {full_nick}")
        print(f"  Installed {agent_svc} → {path}")


def _cmd_setup(args: argparse.Namespace) -> None:
    from culture.mesh_config import load_mesh_config
    from culture.persistence import list_services, uninstall_service

    try:
        mesh = load_mesh_config(args.config)
    except FileNotFoundError:
        mesh = generate_mesh_from_agents(args.config)
        if mesh is None:
            sys.exit(1)

    server_name = mesh.server.name

    if args.uninstall:
        print("Uninstalling culture services...")
        expected = {f"culture-server-{server_name}"}
        for agent in mesh.agents:
            expected.add(f"culture-agent-{server_name}-{agent.nick}")
        for svc in list_services():
            if svc in expected:
                print(f"  Removing {svc}")
                uninstall_service(svc)
        server_stop_by_name(server_name)
        for agent in mesh.agents:
            full_nick = f"{server_name}-{agent.nick}"
            stop_agent(full_nick)
        print("Done.")
        return

    _store_mesh_credentials(mesh)

    _generate_agent_configs(mesh, server_name)

    culture_bin = shutil.which("culture") or "culture"
    _install_mesh_services(mesh, server_name, culture_bin, args.config)

    print(f"\nSetup complete for mesh node '{server_name}'.")
    print("Services installed. Start with your service manager or reboot.")


# -----------------------------------------------------------------------
# Update
# -----------------------------------------------------------------------


def _upgrade_culture_package(args: argparse.Namespace) -> bool:
    """Upgrade the culture package via uv or pip, then re-exec with --skip-upgrade."""
    if args.skip_upgrade:
        return True

    if args.dry_run:
        print("[dry-run] Would run: uv tool upgrade culture")
        print("[dry-run] Would re-exec with --skip-upgrade")
        return False

    uv = shutil.which("uv")
    if uv:
        print("Upgrading via uv...")
        result = subprocess.run(
            [uv, "tool", "upgrade", "culture"],
            capture_output=True,
            text=True,
        )
        print(result.stdout.strip() if result.stdout else "")
        if result.returncode != 0:
            print(f"uv upgrade failed: {result.stderr}", file=sys.stderr)
            sys.exit(1)
    else:
        pip = shutil.which("pip") or shutil.which("pip3")
        if pip:
            print("Upgrading via pip...")
            result = subprocess.run(
                [pip, "install", "--upgrade", "culture"],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                print(f"pip upgrade failed: {result.stderr}", file=sys.stderr)
                sys.exit(1)
        else:
            print("Neither uv nor pip found", file=sys.stderr)
            sys.exit(1)

    culture_bin = shutil.which("culture") or "culture"
    reexec_args = [culture_bin, "mesh", "update", "--skip-upgrade", "--config", args.config]
    print("Re-executing with updated code...")
    if sys.platform == "win32":
        sys.exit(subprocess.run(reexec_args).returncode)
    else:
        os.execvp(culture_bin, reexec_args)


def _restart_mesh_services(
    mesh, server_name: str, culture_bin: str, config_path: str, dry_run: bool
) -> None:
    """Stop agents and server, regenerate service entries, then restart everything."""
    print(f"Restarting mesh node '{server_name}'...")

    if dry_run:
        for agent in mesh.agents:
            print(f"[dry-run] Would stop agent {server_name}-{agent.nick}")
        print(f"[dry-run] Would stop server {server_name}")
        print("[dry-run] Would regenerate auto-start entries")
        print(f"[dry-run] Would start server {server_name}")
        for agent in mesh.agents:
            print(f"[dry-run] Would start agent {server_name}-{agent.nick}")
        return

    for agent in mesh.agents:
        full_nick = f"{server_name}-{agent.nick}"
        print(f"  Stopping {full_nick}...")
        stop_agent(full_nick)

    print(f"  Stopping server {server_name}...")
    server_stop_by_name(server_name)

    from culture.persistence import install_service

    server_cmd = build_server_start_cmd(mesh, culture_bin, config_path)
    install_service(f"culture-server-{server_name}", server_cmd, f"culture server {server_name}")

    for agent in mesh.agents:
        full_nick = f"{server_name}-{agent.nick}"
        workdir = os.path.expanduser(agent.workdir)
        agent_config_path = os.path.join(workdir, ".culture", "agents.yaml")
        agent_cmd = [
            culture_bin,
            "agent",
            "start",
            full_nick,
            "--foreground",
            "--config",
            agent_config_path,
        ]
        install_service(f"culture-agent-{full_nick}", agent_cmd, f"culture agent {full_nick}")

    from culture.persistence import restart_service

    server_svc = f"culture-server-{server_name}"
    print(f"  Restarting {server_svc}...")
    if not restart_service(server_svc):
        if sys.platform == "win32":
            print(
                "  No service file found. Run 'culture mesh setup' to install services.",
                file=sys.stderr,
            )
        else:
            print("  No service file found, starting via CLI...")
            subprocess.run(
                [
                    culture_bin,
                    "server",
                    "start",
                    "--name",
                    server_name,
                    "--host",
                    mesh.server.host,
                    "--port",
                    str(mesh.server.port),
                    "--mesh-config",
                    config_path,
                ],
                check=False,
            )

    import socket as _socket

    for _ in range(50):
        try:
            with _socket.create_connection(("localhost", mesh.server.port), timeout=1):
                break
        except (ConnectionRefusedError, OSError):
            time.sleep(0.1)

    for agent in mesh.agents:
        full_nick = f"{server_name}-{agent.nick}"
        agent_svc = f"culture-agent-{full_nick}"
        print(f"  Restarting {agent_svc}...")
        if not restart_service(agent_svc):
            workdir = os.path.expanduser(agent.workdir)
            agent_config_path = os.path.join(workdir, ".culture", "agents.yaml")
            subprocess.run(
                [culture_bin, "agent", "start", full_nick, "--config", agent_config_path],
                check=False,
            )

    print("\nUpdate complete. All services restarted.")


def _cmd_update(args: argparse.Namespace) -> None:
    from culture.mesh_config import load_mesh_config

    try:
        mesh = load_mesh_config(args.config)
    except FileNotFoundError:
        mesh = generate_mesh_from_agents(args.config)
        if mesh is None:
            sys.exit(1)

    server_name = mesh.server.name

    if not _upgrade_culture_package(args):
        return

    culture_bin = shutil.which("culture") or "culture"
    _restart_mesh_services(mesh, server_name, culture_bin, args.config, args.dry_run)
