"""Two-stage wake-word gate using faster-whisper tiny.en as a fast pre-filter.

Stage 1 — tiny.en (~39 MB, ~100 ms on CPU):
    Transcribes the utterance cheaply and checks if the first word is a
    recognised wake word.  Rejects ~95 % of non-wake-word speech here.

Stage 2 — caller's full model (small.en / medium.en / mlx / …):
    Only fires when Stage 1 confirms a wake word.  Produces the final,
    high-accuracy transcription used for command dispatch.

Usage::

    gate = WakeWordGate()          # loads tiny.en once
    result = gate.check(pcm_int16, sample_rate=16000)
    if result.wake:
        full_text = my_full_stt.transcribe(pcm_int16, sample_rate)
        cmd = extract_command(full_text, result.wake_idx)
"""

from __future__ import annotations

import os
import platform
from dataclasses import dataclass

import numpy as np


# ── Wake-word lexicon (first word only, after our earlier fix) ────────────────

WAKE_VARIANTS: dict[str, set[str]] = {
    "claude": {"claude", "clawed", "clod", "cloudy", "clyde", "claud"},
    "codex":  {"codex", "codec", "codecs", "coded", "coed", "goodx", "godex"},
}

# Words that score high in fuzzy matching but are NOT wake words.
# Checked before fuzzy ratio to prevent false triggers on common speech.
FUZZY_BLOCKLIST: set[str] = {
    "cortex", "kodak", "clot", "cloak",
    "code", "codes", "coke", "cope", "core",
}

# Gate checks this many words (lenient — Stage 2 provides final precision).
GATE_CHECK_WORDS: int = 2

# Utterances shorter than this are passed straight to Stage-2 STT — tiny.en
# is unreliable on single-word audio (~0.5-0.8 s) and would block genuine
# bare wake words like "claude" or "codex" said alone.
MIN_GATE_DURATION_S: float = 1.0


@dataclass
class GateResult:
    wake: str | None       # e.g. "claude" / "codex", or None if not a wake word
    wake_idx: int          # word index of the wake word in tiny.en transcript
    tiny_text: str         # raw transcript from tiny.en (useful for logging)
    passed: bool           # True iff this utterance should proceed to full STT


class WakeWordGate:
    """Loads faster-whisper tiny.en once; exposes ``check()`` for each utterance."""

    def __init__(
        self,
        model_size: str = "tiny.en",
        device: str = "auto",
        compute_type: str = "int8",
    ) -> None:
        from faster_whisper import WhisperModel

        if device == "auto":
            machine = platform.machine()
            sys_plat = platform.system()
            if sys_plat == "Darwin" and machine in ("arm64", "aarch64"):
                device = "cpu"          # MPS not stable for CTranslate2 yet
            else:
                device = "cpu"

        self._model = WhisperModel(model_size, device=device, compute_type=compute_type)
        self.model_size = model_size

    def _first_word_matches(self, text: str) -> tuple[str | None, int]:
        """Return (wake_word, word_index) checking the first GATE_CHECK_WORDS words.

        The gate is intentionally lenient — Stage-2 STT + text matching
        provides final precision.  We check 2 words to recover cases where
        tiny.en prepends "The" or "A" before the wake word.
        """
        import difflib
        words = [w.strip(",.!?;:\"'") for w in text.split() if w.strip(",.!?;:\"'")]
        if not words:
            return None, -1
        for idx, word in enumerate(words[:GATE_CHECK_WORDS]):
            lw = word.lower()
            if lw in FUZZY_BLOCKLIST:
                continue
            for wake, variants in WAKE_VARIANTS.items():
                if lw in variants:
                    return wake, idx
                for variant in variants:
                    if difflib.SequenceMatcher(None, lw, variant).ratio() >= 0.78:
                        return wake, idx
        return None, -1

    def check(self, pcm_int16: np.ndarray, sample_rate: int = 16000) -> GateResult:
        """Run Stage-1 gate on the utterance.

        Returns a GateResult.  Only call your full STT model when ``result.passed``
        is True.
        """
        # Short utterances (bare wake words) trip up tiny.en — pass them
        # straight through to Stage-2 STT which is far more reliable.
        duration_s = len(pcm_int16) / sample_rate
        if duration_s < MIN_GATE_DURATION_S:
            return GateResult(wake=None, wake_idx=-1, tiny_text="<short>", passed=True)

        audio_f32 = pcm_int16.astype(np.float32) / 32768.0

        # Suppress faster-whisper's INFO logs during the quick check
        import logging
        fw_log = logging.getLogger("faster_whisper")
        prev_level = fw_log.level
        fw_log.setLevel(logging.ERROR)

        try:
            segments, _ = self._model.transcribe(
                audio_f32,
                language="en",
                beam_size=1,            # fastest decode
                best_of=1,
                temperature=0.0,
                condition_on_previous_text=False,
                no_speech_threshold=0.6,
                log_prob_threshold=-1.0,
            )
            tiny_text = " ".join(s.text.strip() for s in segments).strip()
        finally:
            fw_log.setLevel(prev_level)

        wake, idx = self._first_word_matches(tiny_text)
        return GateResult(
            wake=wake,
            wake_idx=idx,
            tiny_text=tiny_text,
            passed=wake is not None,
        )
