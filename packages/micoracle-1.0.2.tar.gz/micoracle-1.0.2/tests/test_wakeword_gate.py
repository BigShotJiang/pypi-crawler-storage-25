"""Test suite for the two-stage wake-word gate — 20 commands covering
true positives, false positives, edge cases, and hallucinations.

Run:
    python -m pytest tests/test_wakeword_gate.py -v
or directly:
    python tests/test_wakeword_gate.py
"""

from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from wakeword import WakeWordGate


# ─────────────────────────── audio helpers ───────────────────────────────────

def tts_to_pcm(phrase: str, voice: str = "Samantha", rate: int = 145) -> np.ndarray:
    """Synthesise phrase with macOS say → 16 kHz int16 PCM."""
    with tempfile.NamedTemporaryFile(suffix=".aiff", delete=False) as tmp_aiff, \
         tempfile.NamedTemporaryFile(suffix=".wav",  delete=False) as tmp_wav:
        aiff_path = tmp_aiff.name
        wav_path  = tmp_wav.name

    subprocess.run(
        ["say", "-v", voice, "-r", str(rate), phrase, "-o", aiff_path],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["ffmpeg", "-y", "-i", aiff_path, "-ar", "16000", "-ac", "1",
         "-sample_fmt", "s16", wav_path, "-loglevel", "quiet"],
        check=True, capture_output=True,
    )
    pcm, _ = sf.read(wav_path, dtype="int16")
    Path(aiff_path).unlink(missing_ok=True)
    Path(wav_path).unlink(missing_ok=True)
    return pcm


def silence(duration_s: float = 1.0) -> np.ndarray:
    return np.zeros(int(16000 * duration_s), dtype=np.int16)


# ─────────────────────────── fixtures ────────────────────────────────────────

@pytest.fixture(scope="module")
def gate():
    return WakeWordGate()


# ─────────────────────────── test cases ──────────────────────────────────────

# 10 TRUE POSITIVES — must pass gate
TRUE_POSITIVES = [
    ("claude refactor this function into smaller helpers", "Samantha"),
    ("codex write a Python hello world",                  "Daniel"),
    ("claude explain what this class does",               "Fred"),
    ("codex add unit tests for this module",              "Karen"),
    ("claude fix the bug on line forty two",              "Moira"),
    ("clyde run the build",                               "Albert"),   # mishear → claude
    ("codecs write a dockerfile",                         "Victoria"), # mishear → codex
    ("coded push this commit",                            "Ava"),      # mishear → codex
    ("claude",                                            "Samantha"), # bare wake word
    ("codex",                                             "Daniel"),   # bare wake word
]

# 10 FALSE POSITIVES — must be blocked by the gate
# Note: "cloud storage" passes the gate (cloud ≈ claude phonetically) but
# Stage-2 text matching blocks it — that's the correct two-stage behaviour.
FALSE_POSITIVES = [
    ("I asked claude to handle it",           "Fred"),     # claude not first word
    ("the cortex pathway is important",       "Karen"),    # cortex in blocklist
    ("kodak makes great cameras",             "Moira"),    # kodak in blocklist
    ("explain what the codex manuscript says","Albert"),   # codex not first word
    ("okay thanks for watching",              "Daniel"),   # no wake word
    ("thank you very much",                   "Victoria"), # no wake word
    ("hello there how are you",               "Fred"),     # no wake word
    ("run the build pipeline now",            "Karen"),    # no wake word
    ("check the logs for errors",             "Moira"),    # no wake word
    ("please open the terminal window",       "Samantha"), # no wake word
]


@pytest.mark.parametrize("phrase,voice", TRUE_POSITIVES,
                         ids=[p[0][:40] for p in TRUE_POSITIVES])
def test_true_positive(gate, phrase, voice):
    pcm = tts_to_pcm(phrase, voice)
    result = gate.check(pcm)
    assert result.passed, (
        f"MISS — should have detected wake word in: {phrase!r}\n"
        f"  tiny.en said: {result.tiny_text!r}"
    )


@pytest.mark.parametrize("phrase,voice", FALSE_POSITIVES,
                         ids=[p[0][:40] for p in FALSE_POSITIVES])
def test_false_positive(gate, phrase, voice):
    pcm = tts_to_pcm(phrase, voice)
    result = gate.check(pcm)
    assert not result.passed, (
        f"FALSE POSITIVE — gate should have blocked: {phrase!r}\n"
        f"  tiny.en said: {result.tiny_text!r}"
    )


def test_silence_does_not_pass(gate):
    result = gate.check(silence(1.5))
    assert not result.passed, (
        f"Gate passed on silence! tiny.en said: {result.tiny_text!r}"
    )


# ─────────────────────────── standalone runner ───────────────────────────────

if __name__ == "__main__":
    print("Loading WakeWordGate...")
    g = WakeWordGate()
    print(f"Gate ready ({g.model_size})\n")

    passed = failed = 0

    print("=" * 60)
    print("TRUE POSITIVES  (gate must pass these)")
    print("=" * 60)
    for phrase, voice in TRUE_POSITIVES:
        pcm = tts_to_pcm(phrase, voice)
        r = g.check(pcm)
        ok = r.passed
        mark = "✅" if ok else "❌ MISS"
        if ok: passed += 1
        else:  failed += 1
        print(f"  {mark}  [{voice:10s}] {phrase[:50]}")
        if not ok:
            print(f"           tiny.en: {r.tiny_text!r}")

    print()
    print("=" * 60)
    print("FALSE POSITIVES  (gate must block these)")
    print("=" * 60)
    for phrase, voice in FALSE_POSITIVES:
        pcm = tts_to_pcm(phrase, voice)
        r = g.check(pcm)
        ok = not r.passed
        mark = "✅ blocked" if ok else "❌ TRIGGERED"
        if ok: passed += 1
        else:  failed += 1
        print(f"  {mark}  [{voice:10s}] {phrase[:50]}")
        if not ok:
            print(f"           tiny.en: {r.tiny_text!r}")

    print()
    print("=" * 60)
    print("SILENCE")
    print("=" * 60)
    r = g.check(silence(1.5))
    ok = not r.passed
    mark = "✅ blocked" if ok else "❌ TRIGGERED"
    if ok: passed += 1
    else:  failed += 1
    print(f"  {mark}  [silence 1.5s] tiny.en: {r.tiny_text!r}")

    total = passed + failed
    print()
    print(f"Results: {passed}/{total} passed  {'✅ ALL GOOD' if failed == 0 else f'❌ {failed} FAILED'}")
    sys.exit(0 if failed == 0 else 1)
