"""
Codemods that transform a Vercel repo into a Varity-deployable repo.

Each transform is:
  - Targeted (touches one Vercel-ism)
  - Idempotent (re-running doesn't break)
  - Reversible (original files are backed up to .vercel-migration-backup/)

The apply() entry point orchestrates them based on a MigrationReport.
"""

from __future__ import annotations

import json
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

from varitykit.migrate.detector import MigrationReport


BACKUP_DIR_NAME = ".vercel-migration-backup"


@dataclass
class AppliedChanges:
    """Records what a migration run did — used to render diffs and to roll
    back. Ordering matters: files_removed + files_modified are replayed in
    reverse on rollback."""
    project_path: Path
    files_modified: List[Path] = field(default_factory=list)
    files_removed: List[Path] = field(default_factory=list)
    files_created: List[Path] = field(default_factory=list)
    package_json_changes: Dict[str, str] = field(default_factory=dict)
    env_changes: Dict[str, Dict[str, str]] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return bool(
            self.files_modified
            or self.files_removed
            or self.files_created
            or self.package_json_changes
            or self.env_changes
        )


def apply(report: MigrationReport, dry_run: bool = False) -> AppliedChanges:
    """Apply every migration implied by `report`.

    If `dry_run` is True, compute the changes but don't write them. Useful
    for the CLI's `analyze` command to show a preview.

    Returns an `AppliedChanges` describing what was done (or would be done).
    """
    changes = AppliedChanges(project_path=report.project_path)
    if not dry_run:
        _ensure_backup_dir(report.project_path)

    if report.has_vercel_json:
        _remove_vercel_json(report, changes, dry_run)

    if report.next_config_needs_images_unoptimized and report.next_config_path:
        _patch_next_config_images(report.next_config_path, changes, dry_run)

    if report.vercel_packages_found:
        _remove_vercel_packages(report, changes, dry_run)

    if report.env_renames_needed:
        _rename_env_vars(report, changes, dry_run)

    return changes


# ---------------------------------------------------------------------------
# Individual transforms
# ---------------------------------------------------------------------------

def _remove_vercel_json(
    report: MigrationReport,
    changes: AppliedChanges,
    dry_run: bool,
) -> None:
    """Move vercel.json into the backup dir. Its headers/redirects should be
    reimplemented in next.config.js (out of scope for v1 — we warn)."""
    src = report.project_path / "vercel.json"
    if not dry_run:
        _backup_and_remove(src, report.project_path)
    changes.files_removed.append(src)
    # Warn if the user had custom headers/redirects that we'd be losing silently
    if report.vercel_json_content:
        had_custom = any(
            report.vercel_json_content.get(k)
            for k in ("headers", "redirects", "rewrites")
        )
        if had_custom:
            changes.notes.append(
                "vercel.json had custom headers/redirects/rewrites — these were "
                "backed up to .vercel-migration-backup/. Re-add them to "
                "next.config.js if needed."
            )


def _patch_next_config_images(
    config_path: Path,
    changes: AppliedChanges,
    dry_run: bool,
) -> None:
    """Ensure `images: { unoptimized: true, ... }` in next.config.*

    Akash doesn't provide Vercel's image CDN — next/image served normally
    would attempt to hit /_next/image which 500s. Setting unoptimized: true
    disables the optimizer and serves images as-is.

    Three cases handled:
      1. `images: { ... }` block exists without `unoptimized` → inject it
      2. `images: { ... unoptimized: <falsy> ... }` → flip to true
      3. No `images` block at all → inject one
    """
    original = config_path.read_text(encoding="utf-8")

    patched = _apply_unoptimized_transform(original)

    if patched == original:
        # Already in the desired state (shouldn't happen if detector ran, but
        # stay idempotent).
        return

    if not dry_run:
        _backup(config_path, config_path.parent)
        config_path.write_text(patched, encoding="utf-8")
    changes.files_modified.append(config_path)


def _apply_unoptimized_transform(content: str) -> str:
    """Pure-function regex transform on next.config content."""
    # Case 2: exists but set to a falsy value → flip to true
    content = re.sub(
        r"(unoptimized\s*:\s*)(?:false|0|null|undefined)",
        r"\1true",
        content,
    )

    # If we already set it true, done.
    if re.search(r"unoptimized\s*:\s*true", content):
        return content

    # Case 1: `images: {` exists → inject the key right after the opening brace
    images_block = re.search(r"(images\s*:\s*\{)", content)
    if images_block:
        insert_pos = images_block.end()
        # Preserve the style of the surrounding code: if the block uses
        # tabs/spaces inline, match it.
        return (
            content[:insert_pos]
            + "\n    unoptimized: true,"
            + content[insert_pos:]
        )

    # Case 3: no images block at all → inject one before the closing `}` of
    # the main config object. We look for the LAST `};` or `}` followed by
    # a newline that's at zero indent — the top-level config object close.
    # This is best-effort; for configs too complex to parse we bail and warn.
    # Find `const X = { ... }` → inject before the matching closing brace.
    match = re.search(
        r"(const\s+\w+\s*=\s*\{)",
        content,
    )
    if match:
        # Find the matching closing brace by balance counting from the open.
        open_idx = match.end() - 1
        depth = 0
        close_idx = None
        for i in range(open_idx, len(content)):
            ch = content[i]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    close_idx = i
                    break
        if close_idx is not None:
            # Insert before the closing brace
            return (
                content[:close_idx]
                + "  images: {\n    unoptimized: true,\n  },\n"
                + content[close_idx:]
            )

    # Last resort: append a best-effort hint at the end as a commented note —
    # better than silently skipping. The user can run migration again after
    # they simplify the config.
    return content + (
        "\n\n// VARITY MIGRATION NOTE: could not auto-inject images.unoptimized = true.\n"
        "// Add this to your next.config images block manually:\n"
        "//   images: { unoptimized: true, ... }\n"
    )


def _remove_vercel_packages(
    report: MigrationReport,
    changes: AppliedChanges,
    dry_run: bool,
) -> None:
    """Strip @vercel/* from package.json deps. Records recommended
    replacements in `changes.notes` for the human."""
    pkg_path = report.project_path / "package.json"
    if not pkg_path.exists():
        return

    try:
        data = json.loads(pkg_path.read_text())
    except (json.JSONDecodeError, IOError):
        return

    removed = []
    for section in ("dependencies", "devDependencies"):
        deps = data.get(section, {})
        for vercel_pkg in list(deps.keys()):
            if vercel_pkg in report.vercel_packages_found:
                del deps[vercel_pkg]
                removed.append(vercel_pkg)

    if not removed:
        return

    if not dry_run:
        _backup(pkg_path, report.project_path)
        pkg_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

    changes.files_modified.append(pkg_path)
    for pkg_name in removed:
        replacement = report.vercel_package_replacements.get(pkg_name)
        changes.package_json_changes[pkg_name] = replacement or "(removed)"
        if replacement:
            changes.notes.append(
                f"Removed {pkg_name}. Install {replacement} as a replacement "
                "and update import statements."
            )


def _rename_env_vars(
    report: MigrationReport,
    changes: AppliedChanges,
    dry_run: bool,
) -> None:
    """Rewrite .env* files to rename Vercel-injected keys to Varity conventions.

    We rename, not remove — the VALUE is the user's data (a real postgres URL,
    for example). Varity's sidecar wiring will clobber it with our managed
    URL at deploy time (that's Phase 4's _is_user_env_key filter doing its
    job), but leaving the renamed key in .env keeps the code working in local
    dev if the user points to a local DB.
    """
    env_files = [
        ".env.varity", ".env.local", ".env",
        ".env.production", ".env.development",
    ]
    for fname in env_files:
        env_file = report.project_path / fname
        if not env_file.exists():
            continue
        try:
            original = env_file.read_text(encoding="utf-8")
        except IOError:
            continue

        new_text = original
        file_changes: Dict[str, str] = {}
        for old, new in report.env_renames_needed.items():
            # Match KEY at start-of-line (optionally with `export `),
            # not inside a value.
            pattern = re.compile(
                rf"(?m)^(\s*(?:export\s+)?){re.escape(old)}(=)"
            )
            if pattern.search(new_text):
                new_text = pattern.sub(rf"\1{new}\2", new_text)
                file_changes[old] = new

        if file_changes and new_text != original:
            if not dry_run:
                _backup(env_file, report.project_path)
                env_file.write_text(new_text, encoding="utf-8")
            changes.files_modified.append(env_file)
            changes.env_changes[fname] = file_changes


# ---------------------------------------------------------------------------
# Backup helpers (rollback support)
# ---------------------------------------------------------------------------

def _ensure_backup_dir(project_root: Path) -> Path:
    backup = project_root / BACKUP_DIR_NAME
    backup.mkdir(parents=True, exist_ok=True)
    return backup


def _backup(src: Path, project_root: Path) -> Path:
    """Copy `src` into the backup dir, mirroring its relative path."""
    backup_root = _ensure_backup_dir(project_root)
    try:
        rel = src.relative_to(project_root)
    except ValueError:
        rel = Path(src.name)
    dest = backup_root / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    return dest


def _backup_and_remove(src: Path, project_root: Path) -> Path:
    """Copy to backup, then delete the original. Rollback restores the copy."""
    dest = _backup(src, project_root)
    src.unlink()
    return dest


def rollback(project_path: str | Path) -> List[Path]:
    """Restore every file from the backup dir back to its original location,
    then remove the backup dir. Returns paths restored.

    Idempotent — calling rollback with no backup dir is a no-op."""
    root = Path(project_path)
    backup = root / BACKUP_DIR_NAME
    if not backup.exists():
        return []

    restored: List[Path] = []
    for src in backup.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(backup)
        dest = root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        restored.append(dest)

    shutil.rmtree(backup)
    return restored
