"""Reusable transformer layer parts."""

