"""Identity facet for Mithril provider.

Implements IdentityProtocol by delegating to the Mithril API client
and UsersService for current user and teammate discovery.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.mithril.provider.context import MithrilContext

logger = logging.getLogger(__name__)


def _extract_teammates_from_response(response: Any) -> list[dict[str, Any]]:
    """Extract teammate list from supported Mithril API response envelopes."""
    if isinstance(response, list):
        return response

    if isinstance(response, dict):
        for key in ("data", "teammates", "users", "members", "results", "items"):
            value = response.get(key)
            if isinstance(value, list):
                return value
            if isinstance(value, dict) and isinstance(value.get("items"), list):
                return value["items"]

    return []


class IdentityFacet:
    """Mithril implementation of IdentityProtocol."""

    def __init__(self, ctx: MithrilContext) -> None:
        self.ctx = ctx

    def get_current_user(self) -> dict[str, Any]:
        """Get the current authenticated user's info from the Mithril API."""
        response = self.ctx.api.get_me()
        if isinstance(response, dict):
            data = response.get("data", response)
            if isinstance(data, dict):
                return data
        return response

    def get_user_teammates(self, user_id: str) -> list[dict[str, Any]]:
        """Get all teammates for the given user."""
        response = self.ctx.users.get_user_teammates(user_id)
        return _extract_teammates_from_response(response)
