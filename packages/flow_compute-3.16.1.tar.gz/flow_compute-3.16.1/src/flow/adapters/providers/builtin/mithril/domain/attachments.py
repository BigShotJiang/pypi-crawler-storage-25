"""Volume attachment planner service.

Resolves provided identifiers (IDs or names) to volume IDs and builds
attachment specifications for the bid payload using mount paths from config or
defaults.
"""

from __future__ import annotations

import logging
from typing import Any

from flow.adapters.providers.builtin.mithril.bidding.builder import BidBuilder
from flow.sdk.models import TaskConfig
from flow.utils.paths import default_volume_mount_path

logger = logging.getLogger(__name__)


class VolumeAttachmentPlanner:
    """Plan volume attachments for bids."""

    def __init__(self, ctx: Any) -> None:
        self._ctx = ctx

    def prepare_volume_attachments(
        self,
        volume_ids: list[str] | None,
        config: TaskConfig,
        *,
        strict: bool = False,
        cached_volumes: list[Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Resolve identifiers and build attachment specs.

        Args:
            volume_ids: List of volume IDs or names
            config: Task configuration (for mount_path defaults)
            strict: When True, raise on ambiguous or missing names; otherwise skip them
            cached_volumes: Pre-fetched volume list to avoid redundant API calls.
                When provided, skips the internal list_volumes() call.
        """
        if not volume_ids:
            return []

        # Resolve names to IDs -- reuse cached list when available
        resolved: list[str] = []
        all_vols = (
            cached_volumes
            if cached_volumes is not None
            else self._ctx.volumes.list_volumes(
                project_id=self._ctx.get_project_id(), region=None, limit=1000
            )
        )

        def _is_volume_id(identifier: str) -> bool:
            return str(identifier).startswith("vol_")

        from flow.adapters.providers.builtin.mithril.domain.volume_prep import resolve_volume

        for ident in volume_ids:
            if _is_volume_id(ident):
                resolved.append(ident)
                continue

            match = resolve_volume(ident, all_vols)
            if match:
                resolved.append(match.id)
                continue

            # Partial match fallback (CLI ergonomic -- not in shared resolver)
            partial = [
                v for v in all_vols if getattr(v, "name", "").lower().find(ident.lower()) != -1
            ]
            if len(partial) == 1:
                resolved.append(partial[0].id)
            elif strict:
                from flow.errors import ValidationError

                raise ValidationError(f"No volume found matching '{ident}'.")
            else:
                logger.warning("No volume found matching '%s'. Skipping.", ident)

        # Build attachments
        attachments: list[dict[str, Any]] = []
        cfg_vols = list(getattr(config, "volumes", []) or [])
        for i, vid in enumerate(resolved):
            if i < len(cfg_vols) and getattr(cfg_vols[i], "mount_path", None):
                mount_path = cfg_vols[i].mount_path
            else:
                name = getattr(cfg_vols[i], "name", None) if i < len(cfg_vols) else None
                mount_path = default_volume_mount_path(name=name, volume_id=vid)
            attachments.append(
                BidBuilder.format_volume_attachment(volume_id=vid, mount_path=mount_path, mode="rw")
            )
        return attachments
