"""Bid management adapter for Mithril provider.

This adapter handles the infrastructure concerns of bid submission,
delegating business logic to domain services.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import Any

from flow.adapters.providers.builtin.mithril.api.client import MithrilApiClient
from flow.errors import APIError, FlowError
from flow.sdk.models import TaskConfig

logger = logging.getLogger(__name__)


class BidSubmissionError(FlowError):
    """Raised when a bid submission fails.

    For chunked partial-fulfillment requests, ``completed_chunks`` and
    ``failed_chunk_index`` preserve the diagnostic context the caller needs
    to decide whether to release the already-fulfilled chunks or retry the
    remainder.
    """

    def __init__(
        self,
        message: str,
        *,
        completed_chunks: list[BidResult] | None = None,
        failed_chunk_index: int | None = None,
        failed_chunk_quantity: int | None = None,
    ) -> None:
        super().__init__(message)
        self.completed_chunks: list[BidResult] = completed_chunks or []
        self.failed_chunk_index = failed_chunk_index
        self.failed_chunk_quantity = failed_chunk_quantity


class BidStatus(Enum):
    PENDING = "pending"
    FULFILLED = "fulfilled"


@dataclass
class BidRequest:
    auction_id: str
    instance_type_id: str
    quantity: int
    max_price_per_hour: float
    task_name: str
    ssh_keys: list[str]
    startup_script: str
    disk_attachments: list[dict[str, Any]] | None = None
    allow_partial: bool = False
    min_quantity: int = 1
    chunk_size: int | None = None


@dataclass
class BidResult:
    bid_id: str
    quantity_fulfilled: int
    instances: list[str]
    status: BidStatus = BidStatus.PENDING


class BidManager:
    """Adapter for bid submission using domain services."""

    def __init__(self, api_client: MithrilApiClient):
        """Initialize bid manager.

        Args:
            api_client: HTTP client for API requests
        """
        self._api: MithrilApiClient = api_client

    def submit_bid(
        self,
        request: BidRequest,
        startup_script_customizer: Callable[[int, str], str] | None = None,
    ) -> list[BidResult]:
        """Submit bid with optional partial fulfillment.

        Args:
            request: Bid request parameters
            startup_script_customizer: Optional function to customize startup script per chunk

        Returns:
            List of bid results (one per chunk if using partial fulfillment)
        """
        # Create chunk requests locally if partial allowed; otherwise single request
        chunk_requests: list[BidRequest] = []
        if request.allow_partial and request.chunk_size:
            chunks = self._calculate_chunks(
                request.quantity, request.chunk_size, request.min_quantity
            )
            total = len(chunks)
            for idx, qty in enumerate(chunks):
                startup_script = self._customize_startup_script(
                    request.startup_script, idx, total, startup_script_customizer
                )
                chunk_requests.append(
                    BidRequest(
                        auction_id=request.auction_id,
                        instance_type_id=request.instance_type_id,
                        quantity=qty,
                        max_price_per_hour=request.max_price_per_hour,
                        task_name=request.task_name,
                        ssh_keys=request.ssh_keys,
                        startup_script=startup_script,
                        disk_attachments=request.disk_attachments or [],
                        allow_partial=False,
                    )
                )
        else:
            chunk_requests = [request]

        results: list[BidResult] = []
        for idx, chunk_request in enumerate(chunk_requests):
            try:
                result = self._submit_single_bid(chunk_request)
            except BidSubmissionError as exc:
                logger.error("Chunk %d/%d failed: %s", idx + 1, len(chunk_requests), exc)
                # First-chunk failure with no prior results: surface the raw
                # error so callers see a standard failure path.
                if not results:
                    raise
                # Mid-chunk failure: preserve both the completed chunks and
                # the failed chunk's position so callers can release partial
                # capacity or retry the remainder instead of silently
                # receiving a truncated result list.
                raise BidSubmissionError(
                    f"Chunked bid failed at chunk {idx + 1}/{len(chunk_requests)} "
                    f"after {len(results)} successful chunk(s): {exc}",
                    completed_chunks=results,
                    failed_chunk_index=idx,
                    failed_chunk_quantity=chunk_request.quantity,
                ) from exc

            results.append(result)
            # Stop if we got less than requested (partial fulfillment signal
            # from the auction); further chunks are unlikely to succeed.
            if result.quantity_fulfilled < chunk_request.quantity:
                logger.warning(
                    "Chunk %d/%d only fulfilled %d out of %d requested",
                    idx + 1,
                    len(chunk_requests),
                    result.quantity_fulfilled,
                    chunk_request.quantity,
                )
                break

        # Log summary for chunked bids
        if len(chunk_requests) > 1:
            total_fulfilled = sum(r.quantity_fulfilled for r in results)
            logger.info(
                f"Partial fulfillment complete: {total_fulfilled}/{request.quantity} instances "
                f"across {len(results)} bids"
            )

        return results

    def _submit_single_bid(self, request: BidRequest) -> BidResult:
        """Submit a single bid via API."""
        payload = {
            "auction_id": request.auction_id,
            "instance_type": request.instance_type_id,
            "quantity": request.quantity,
            "max_price": round(request.max_price_per_hour * 100),  # Convert to cents
            "task_name": request.task_name,
            "ssh_keys": request.ssh_keys,
            "startup_script": request.startup_script,
            "disk_attachments": request.disk_attachments or [],
        }

        try:
            response = self._api.create_legacy_bid(payload)

            bid_id = response.get("bid_id", response.get("fid"))
            instances = response.get("instances", [])

            return BidResult(
                bid_id=bid_id,
                quantity_fulfilled=len(instances),
                instances=[inst.get("fid") for inst in instances],
                status=BidStatus.FULFILLED if instances else BidStatus.PENDING,
            )

        except Exception as e:
            raise BidSubmissionError(f"Failed to submit bid: {e}") from e

    @staticmethod
    def _calculate_chunks(total_quantity: int, chunk_size: int, min_quantity: int) -> list[int]:
        chunks: list[int] = []
        remaining = total_quantity
        while remaining > 0:
            current = min(chunk_size, remaining)
            if current >= min_quantity:
                chunks.append(current)
                remaining -= current
            else:
                if chunks:
                    chunks[-1] += remaining
                else:
                    chunks.append(remaining)
                break
        return chunks

    @staticmethod
    def _customize_startup_script(
        base_script: str,
        chunk_index: int,
        total_chunks: int,
        customizer: Callable[[int, str], str] | None,
    ) -> str:
        """Produce the per-chunk startup script.

        When a customizer is supplied, its output is authoritative and any
        exception it raises is surfaced to the caller. Swallowing customizer
        errors previously meant a typo in the customizer would silently ship
        the wrong environment to every chunk.
        """
        if customizer is not None:
            return customizer(chunk_index, base_script)
        meta = (
            f"export CHUNK_INDEX={chunk_index}\n"
            f"export TOTAL_CHUNKS={total_chunks}\n"
            f"export CHUNK_ID=chunk-{chunk_index}\n"
        )
        return meta + (base_script or "")

    def cancel_bid(self, bid_id: str) -> bool:
        """Cancel a bid if possible.

        Args:
            bid_id: ID of the bid to cancel.

        Returns:
            True if the bid was cancelled by this call, False if the backend
            reports the bid no longer exists (already cancelled or never
            created).

        Raises:
            AuthenticationError: Caller lacks permission to cancel the bid.
            APIError: Non-404 API failure. The previous implementation
                conflated every failure with "already cancelled", hiding
                auth denials and backend outages from the user.
            NetworkError: Backend unreachable.
        """
        try:
            self._api.delete_bid(bid_id)
            return True
        except APIError as exc:
            if exc.status_code == 404:
                logger.info("Bid %s already cancelled or not found", bid_id)
                return False
            raise

    def create_request_from_config(
        self,
        config: TaskConfig,
        auction_id: str,
        instance_type_id: str,
        startup_script: str,
        disk_attachments: list[dict[str, Any]],
        allow_partial: bool = False,
        chunk_size: int | None = None,
    ) -> BidRequest:
        """Create bid request from task configuration.

        Args:
            config: Task configuration
            auction_id: Auction to bid on
            instance_type_id: Resolved instance type ID
            startup_script: Complete startup script
            disk_attachments: Volume attachments
            allow_partial: Whether to allow partial fulfillment
            chunk_size: Size of chunks for partial fulfillment

        Returns:
            BidRequest object
        """
        # Determine per-instance max price: explicit > derived from pricing tiers
        if config.max_price_per_hour is not None:
            max_pph = float(config.max_price_per_hour)
        else:
            from flow.domain.pricing.calculator import resolve_limit_price

            prio = (getattr(config, "priority", None) or "med").lower()
            inst = getattr(config, "instance_type", None) or ""
            max_pph = resolve_limit_price(inst, priority=prio)

        return BidRequest(
            auction_id=auction_id,
            instance_type_id=instance_type_id,
            quantity=config.num_instances,
            max_price_per_hour=max_pph,
            task_name=config.name,
            ssh_keys=config.ssh_keys,
            startup_script=startup_script,
            disk_attachments=disk_attachments,
            allow_partial=allow_partial,
            min_quantity=1,
            chunk_size=chunk_size,
        )
