"""Mithril provider setup adapter.

Extracts Mithril-specific logic from the wizard to keep the wizard provider-agnostic
while preserving the UI and functionality.
"""

import atexit
import logging
import os
import threading
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Literal

from rich.console import Console
from rich.markup import escape

from flow.adapters.http.client import HttpClient
from flow.adapters.providers.builtin.mithril.api.client import MithrilApiClient
from flow.application.config.manager import ConfigManager
from flow.core.setup_adapters import ConfigField, FieldType, ProviderSetupAdapter, ValidationResult
from flow.errors import FlowError
from flow.sdk.helpers.masking import mask_api_key
from flow.utils.links import WebLinks

logger = logging.getLogger(__name__)

# Type-safe field names for Mithril provider configuration
MithrilFieldName = Literal["api_key", "project", "default_ssh_key", "billing"]

# Mithril API URL fragments the setup adapter caches and may invalidate.
# Keeping these in the adapter (not HttpClient) so the HTTP layer stays
# provider-agnostic; the transport should not know the names of Mithril
# resources.
_MITHRIL_CACHE_PATHS: tuple[str, ...] = ("/v2/projects", "/v2/ssh-keys")
_SETUP_ADAPTER_ERRORS = (
    FlowError,
    ImportError,
    AttributeError,
    TypeError,
    ValueError,
    OSError,
    KeyError,
)


class MithrilSetupAdapter(ProviderSetupAdapter[MithrilFieldName]):
    """Mithril provider setup adapter."""

    def __init__(
        self,
        console: Console | None = None,
        *,
        api_url: str | None = None,
        config_path: Path | None = None,
    ):
        """Initialize Mithril setup adapter.

        Args:
            console: Rich console for output (creates one if not provided).
            api_url: Mithril API endpoint. Defaults to the production URL.
            config_path: Destination for the generated config. Defaults to
                ``~/.flow/config.yaml``.
        """
        if console is not None:
            self.console = console
        else:
            try:
                from flow.cli.utils.theme_manager import theme_manager as _tm

                self.console = _tm.create_console()
            except ImportError:
                self.console = Console()

        from flow.adapters.providers.builtin.mithril.core.constants import (
            MITHRIL_API_PRODUCTION_URL,
        )

        self.api_url = api_url or MITHRIL_API_PRODUCTION_URL
        self.config_path = config_path or Path.home() / ".flow" / "config.yaml"

        self.billing_not_configured = False

        self._client: HttpClient | None = None
        self._client_api_key: str | None = None
        self._cached_user_id: str | None = None

        self.ssh_key_names: dict[str, str] = {}

        self._prefetch_executor: ThreadPoolExecutor | None = None
        self._prefetch_executor_lock = threading.Lock()

    def get_provider_name(self) -> str:
        return "mithril"

    def get_configuration_fields(self) -> list[ConfigField]:
        return [
            ConfigField(
                name="api_key",
                field_type=FieldType.PASSWORD,
                required=True,
                mask_display=True,
                help_text=(
                    f"Get an API key: [link]{WebLinks.api_keys()}[/link]\n"
                    "Stored in ~/.flow/config.yaml; setup output masks the value.\n"
                    "CI: set MITHRIL_API_KEY instead of running the wizard."
                ),
                default=None,
                display_name="API Key",
            ),
            ConfigField(
                name="project",
                field_type=FieldType.CHOICE,
                required=True,
                dynamic_choices=True,
                depends_on=["api_key"],
                empty_choices_hint="Requires API key to list projects",
            ),
            ConfigField(
                name="default_ssh_key",
                field_type=FieldType.CHOICE,
                required=True,
                dynamic_choices=True,
                display_name="Default SSH Key",
                default="_auto_",
                depends_on=["api_key", "project"],
                empty_choices_hint="Requires API key and project to list SSH keys",
                help_text="Keys from your Mithril account. Local keys in ~/.flow/keys/ marked (local).",
            ),
            ConfigField(
                name="billing",
                field_type=FieldType.LINK,
                required=False,
                display_name="Billing",
                depends_on=["api_key"],
                options={
                    "url_provider": lambda ctx: self.get_billing_setup_url(ctx["api_key"]),
                    "prompt_text": "Opening your browser to configure billing...",
                    "fallback_text": (
                        f"Visit this url to configure billing: "
                        f"[link]{WebLinks.billing_settings()}[/link]."
                    ),
                    "wait_text": "Press [bold]Enter[/bold] to continue.",
                    "launch_browser": True,
                },
            ),
        ]

    def validate_field(
        self, field_name: MithrilFieldName, value: str, context: dict[str, Any] | None = None
    ) -> ValidationResult:
        ctx = context or {}
        if field_name == "api_key":
            return self._validate_api_key(value)
        elif field_name == "project":
            return self._validate_project(value, ctx)
        elif field_name == "default_ssh_key":
            return self._validate_ssh_key(value, ctx)
        elif field_name == "billing":
            return self._validate_billing(value, ctx)
        else:
            return ValidationResult(is_valid=False, message=f"Unknown field: {field_name}")

    def is_field_configured(self, field_name: str, value: Any) -> bool:
        """Check whether a field value represents a valid configured state."""
        if not value:
            return False
        v = str(value)
        if v.startswith("YOUR_"):
            return False
        if field_name == "api_key":
            return v.startswith("fkey_") and len(v) >= 20
        if field_name == "project":
            return len(v.strip()) > 0
        if field_name == "default_ssh_key":
            return v == "_auto_" or v.startswith("sshkey_")
        return True

    def get_dynamic_choices(
        self, field_name: MithrilFieldName, context: dict[str, Any]
    ) -> list[str]:
        if field_name == "project":
            return self._get_project_choices(context.get("api_key"))
        elif field_name == "default_ssh_key":
            return self._get_ssh_key_choices(context.get("api_key"), context.get("project"))
        else:
            return []

    def detect_existing_config(self) -> dict[str, Any]:
        manager = ConfigManager(self.config_path)
        return manager.detect_existing_config()

    def save_configuration(self, config: dict[str, Any]) -> bool:
        try:
            manager = ConfigManager(self.config_path)
            payload = dict(config)
            payload.setdefault("provider", "mithril")
            saved = manager.save(payload)
            manager.write_env_script(saved)

            return True
        except (OSError, ValueError, TypeError):
            return False

    def verify_configuration(self, config: dict[str, Any]) -> tuple[bool, str | None]:
        """Verify that the configuration works end-to-end.

        Uses direct API calls instead of importing the full SDK client,
        and does not mutate os.environ.
        """
        api_key = config.get("api_key")
        if not api_key:
            return False, "API key is required for verification"

        try:
            client = self._get_client(api_key)
            api = MithrilApiClient(client)

            # Verify API access by listing projects
            api.list_projects()

            # Check billing status (non-blocking)
            try:
                user_id = self._get_user_id_cached(api)
                billing_response = api.get_stripe_payment_methods(user_id)
                billing_address = billing_response.get("billing_address")
                payment_info = billing_response.get("payment_info")
                if not (billing_address and payment_info):
                    self.billing_not_configured = True
                    self.console.print(
                        "\n[warning]Note: Billing not configured yet. Set it up at:[/warning]"
                    )
                    self.console.print(f"[accent]{WebLinks.billing_settings()}[/accent]")
            except _SETUP_ADAPTER_ERRORS:
                pass

            return True, None

        except _SETUP_ADAPTER_ERRORS as e:
            return False, str(e)

    def get_welcome_message(self) -> tuple[str, list[str]]:
        return (
            "Welcome to Flow Setup",
            [
                "Get and validate your API key",
                "Select your project",
                "Configure SSH access",
                "Verify everything works",
            ],
        )

    def get_completion_message(self) -> str:
        return "Setup Complete. Flow is configured and ready for GPU workloads."

    def get_environment_api_url(self, environment: str) -> str:
        """Return the Mithril API URL for the given environment."""
        api_url, _ = self.for_environment(environment)
        return api_url

    def prefetch_after(self, field_name: str, context: dict[str, Any]) -> None:
        """Warm project / SSH-key caches in the background.

        After ``api_key`` validates, kick off ``list_projects()`` so the
        project-selection menu renders from cache. After ``project``
        resolves, kick off ``list_ssh_keys()`` so the SSH-key menu is
        instant too.

        Runs in a small thread pool. Only the interactive wizard calls this
        hook; non-interactive setup never invokes prefetch.
        """
        api_key = context.get("api_key")
        if not api_key:
            return

        if field_name == "api_key":
            self._prefetch_in_background(
                "list_projects", lambda: self._get_project_choices(api_key)
            )
            return

        if field_name == "project":
            project = context.get("project")
            if not project:
                return
            self._prefetch_in_background(
                "list_ssh_keys",
                lambda: self._get_ssh_key_choices(api_key, project),
            )

    def invalidate_resource_cache(self) -> None:
        """Evict Mithril-owned cache entries (projects, SSH keys).

        Called after mutating operations (e.g. server-side key generation)
        so subsequent reads don't serve stale inventory. The HTTP client
        only exposes generic URL-pattern invalidation; the adapter owns
        which patterns correspond to which Mithril resources.
        """
        if self._client is not None:
            self._client.invalidate_cache_by_url_pattern(list(_MITHRIL_CACHE_PATHS))

    def _prefetch_in_background(self, label: str, fn: Callable[[], object]) -> None:
        """Submit a prefetch task, logging failures rather than raising."""
        executor = self._get_or_create_executor()

        def _run():
            try:
                fn()
            except Exception as e:  # noqa: BLE001
                logger.debug("Prefetch %s failed: %s", label, e)

        try:
            executor.submit(_run)
        except RuntimeError:
            logger.debug("Prefetch executor unavailable; skipping %s", label)

    def _get_or_create_executor(self) -> ThreadPoolExecutor:
        """Return the shared prefetch executor, creating it on first use.

        Registers an atexit hook so in-flight prefetches don't keep the
        process alive after a cancelled wizard; the default
        ``ThreadPoolExecutor`` has non-daemon workers that would
        otherwise block interpreter shutdown.
        """
        if self._prefetch_executor is not None:
            return self._prefetch_executor
        with self._prefetch_executor_lock:
            if self._prefetch_executor is None:
                executor = ThreadPoolExecutor(
                    max_workers=2, thread_name_prefix="mithril-setup-prefetch"
                )
                atexit.register(executor.shutdown, wait=False, cancel_futures=True)
                self._prefetch_executor = executor
        return self._prefetch_executor

    @classmethod
    def for_environment(cls, environment: str) -> tuple[str, Path]:
        """Return (api_url, config_path) for a Mithril environment.

        Callers thread these into :meth:`__init__` so setup never mutates
        ``os.environ`` to propagate environment choices.
        """
        from flow.adapters.providers.builtin.mithril.core.constants import (
            MITHRIL_API_PRODUCTION_URL,
            MITHRIL_API_STAGING_URL,
        )

        if environment == "staging":
            api_url = MITHRIL_API_STAGING_URL
            config_path = Path.home() / ".flow" / "config-staging.yaml"
        else:
            api_url = MITHRIL_API_PRODUCTION_URL
            config_path = Path.home() / ".flow" / "config.yaml"
        return api_url, config_path

    # --- Internal helpers ---

    def _get_client(self, api_key: str) -> HttpClient:
        """Return shared HttpClient, creating one if api_key changed."""
        if self._client is None or self._client_api_key != api_key:
            self._client = HttpClient(
                base_url=self.api_url,
                headers={"Authorization": f"Bearer {api_key}"},
                in_setup_context=True,
            )
            self._client_api_key = api_key
            self._cached_user_id = None
        return self._client

    def _get_user_id(self, api: MithrilApiClient) -> str:
        me_response = api.get_me()
        return me_response["id"]

    def _get_user_id_cached(self, api: MithrilApiClient) -> str:
        """Return cached user ID, fetching once per api_key."""
        if self._cached_user_id is None:
            self._cached_user_id = api.get_me()["id"]
        return self._cached_user_id

    def _validate_api_key(self, api_key: str) -> ValidationResult:
        # Strip whitespace from copy-paste; embedded spaces are still rejected.
        api_key = api_key.strip() if isinstance(api_key, str) else api_key
        if not api_key or any(ch.isspace() for ch in api_key):
            return ValidationResult(
                is_valid=False,
                message="API key contains whitespace. Re-copy without spaces or newlines.",
            )
        if not api_key.startswith("fkey_") or len(api_key) < 20:
            return ValidationResult(
                is_valid=False,
                message="Invalid API key format. Expected: fkey_XXXXXXXXXXXXXXXXXXXXXXXX",
            )

        try:
            client = self._get_client(api_key)
            MithrilApiClient(client).list_projects()
            masked_key = mask_api_key(api_key)
            return ValidationResult(
                is_valid=True, display_value=masked_key, processed_value=api_key
            )
        except _SETUP_ADAPTER_ERRORS as e:
            return ValidationResult(is_valid=False, message=f"API validation failed: {e}")

    def _validate_project(self, project: str, context: dict[str, Any]) -> ValidationResult:
        if not project or not project.strip():
            return ValidationResult(is_valid=False, message="Project name cannot be empty")

        api_key = context.get("api_key")
        if not api_key:
            return ValidationResult(
                is_valid=False,
                message="API key is required to validate project. "
                "Provide --api-key or configure via 'flow setup'.",
            )

        available_projects = self._get_project_choices(api_key)
        if available_projects and project not in available_projects:
            msg = f"Project '{escape(project)}' not found in your account."
            if available_projects:
                msg += f"\n\nAvailable projects: {', '.join(available_projects)}"
            return ValidationResult(is_valid=False, message=msg)

        return ValidationResult(is_valid=True, display_value=project)

    def _validate_ssh_key(self, ssh_key: str, context: dict[str, Any]) -> ValidationResult:
        if not ssh_key or not ssh_key.strip():
            return ValidationResult(is_valid=False, message="SSH key ID cannot be empty")

        # Handle platform auto-generation
        if ssh_key == "_auto_":
            generated_key_id = self._generate_server_side_key(context)
            if generated_key_id:
                return ValidationResult(
                    is_valid=True, display_value=generated_key_id, processed_value=generated_key_id
                )
            return ValidationResult(is_valid=False, message="Failed to generate SSH key")

        if ssh_key == "GENERATE_SERVER":
            generated_key_id = self._generate_server_side_key(context)
            if generated_key_id:
                try:
                    from rich.panel import Panel as _Panel

                    from flow.cli.utils.theme_manager import theme_manager as _tm

                    body = [
                        f"  [muted]ID:[/muted] {generated_key_id}",
                        "  [muted]Private key:[/muted] [repr.path]~/.flow/keys/[/repr.path]",
                        f"  [muted]Manage keys:[/muted] [link]{WebLinks.ssh_keys()}[/link]",
                    ]
                    panel = _Panel(
                        "\n".join(body),
                        title="[accent][bold]SSH Key Generated[/bold][/accent]",
                        border_style=_tm.get_color("table.border"),
                        expand=False,
                    )
                    self.console.print("")
                    self.console.print(panel)
                except (ImportError, AttributeError, TypeError):
                    self.console.print(
                        f"[success]✓[/success] SSH key generated: {generated_key_id}"
                        " — private key saved to ~/.flow/keys/"
                    )
                return ValidationResult(
                    is_valid=True, display_value=generated_key_id, processed_value=generated_key_id
                )
            else:
                return ValidationResult(is_valid=False, message="Failed to generate SSH key")

        # Regular SSH key ID -- show human-readable name if available.
        # Lazy-load names when cache is cold (e.g., re-run with existing config
        # where the SSH key field was skipped and _get_ssh_key_choices never ran).
        if not self.ssh_key_names:
            self._get_ssh_key_choices(context.get("api_key"), context.get("project"))
        display_value = self.ssh_key_names.get(ssh_key, ssh_key)
        return ValidationResult(is_valid=True, display_value=display_value)

    def _validate_billing(self, value: str, context: dict[str, Any]) -> ValidationResult:
        api_key = context.get("api_key")
        if not api_key:
            return ValidationResult(
                is_valid=False,
                display_value="API key required",
                message="Provide API key first to check billing status",
            )

        try:
            client = self._get_client(api_key)
            api = MithrilApiClient(client)
            user_id = self._get_user_id_cached(api)
            billing_response = api.get_stripe_payment_methods(user_id)
        except _SETUP_ADAPTER_ERRORS as e:
            return ValidationResult(is_valid=False, message=f"Billing check failed: {e}")

        billing_address = billing_response.get("billing_address")
        payment_info = billing_response.get("payment_info")

        if billing_address and payment_info:
            return ValidationResult(is_valid=True, display_value="Configured")

        return ValidationResult(
            is_valid=False,
            message="Billing not configured. Add payment information to access compute.",
        )

    def get_billing_setup_url(self, api_key: str) -> str:
        """Get the Stripe URL for billing configuration."""
        origin = (
            "https://app.staging.mithril.ai"
            if "staging.mithril.ai" in self.api_url
            else "https://app.mithril.ai"
        )

        # Stripe session requests need Origin header, so use a dedicated client
        client = HttpClient(
            base_url=self.api_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Origin": origin,
                "Accept": "application/json",
            },
            in_setup_context=True,
        )
        api = MithrilApiClient(client)
        user_id = self._get_user_id_cached(api)

        billing_response = api.get_stripe_payment_methods(user_id)
        billing_address = billing_response.get("billing_address")
        payment_info = billing_response.get("payment_info")

        if billing_address and payment_info:
            resp = api.get_stripe_session(user_id)
        else:
            resp = api.get_stripe_setup_payment_session(user_id)

        return resp["url"]

    def _get_project_choices(self, api_key: str | None) -> list[str]:
        if not api_key:
            return []

        try:
            client = self._get_client(api_key)
            projects = MithrilApiClient(client).list_projects()
            return [proj["name"] for proj in projects if isinstance(proj, dict)]
        except _SETUP_ADAPTER_ERRORS:
            return []

    def _get_ssh_key_choices(self, api_key: str | None, project: str | None) -> list[str]:
        choices = ["GENERATE_SERVER|Generate new SSH key"]

        if not api_key or not project:
            return choices

        try:
            client = self._get_client(api_key)
            api = MithrilApiClient(client)
            projects = api.list_projects()
            project_id = None
            for proj in projects:
                if proj.get("name") == project:
                    project_id = proj.get("fid") or proj.get("id") or proj.get("project_id")
                    break

            if not project_id:
                return choices

            # Get existing SSH keys
            ssh_manager = None
            try:
                from flow.adapters.providers.builtin.mithril.resources.ssh import (
                    SSHKeyManager as _SSHKeyManager,
                )

                ssh_manager = _SSHKeyManager(api, get_project_id=lambda: project_id)
                ssh_keys = ssh_manager.list_keys()
            except (ImportError, AttributeError, TypeError):
                ssh_keys = client.request(
                    "GET", "/v2/ssh-keys", params={"project": project_id}, timeout_seconds=10.0
                )

            # Build set of key IDs with matching local private keys
            local_ids: set[str] = set()
            try:
                import json as _json

                meta_path = Path.home() / ".flow" / "keys" / "metadata.json"
                if meta_path.exists():
                    data = _json.loads(meta_path.read_text())
                    if isinstance(data, dict):
                        for kid, info in data.items():
                            p = Path((info or {}).get("private_key_path", ""))
                            if p.exists():
                                local_ids.add(kid)
            except (OSError, ValueError, TypeError, KeyError):
                pass

            if isinstance(ssh_keys, list):
                for key in ssh_keys:
                    if isinstance(key, dict):
                        created_at = key.get("created_at", "")
                        public_key = key.get("public_key", "")
                        required = key.get("required") or key.get("is_required")
                        fid = key.get("fid")
                        key_name = key.get("name", "")
                    else:
                        created_at = getattr(key, "created_at", "")
                        public_key = getattr(key, "public_key", "")
                        required = getattr(key, "required", None) or getattr(
                            key, "is_required", None
                        )
                        fid = getattr(key, "fid", None)
                        key_name = getattr(key, "name", "")

                    fingerprint = self._extract_fingerprint(public_key or "")
                    required_flag = " (required)" if required else ""

                    # Check metadata.json for local key presence (fast path).
                    # We intentionally skip ssh_manager.find_matching_local_key()
                    # here because it scans the filesystem and spawns ssh-keygen
                    # subprocesses per key. That O(N*M) cost hangs the wizard.
                    has_local = bool(fid and fid in local_ids)

                    name_display = f"{key_name}{required_flag}"
                    if has_local:
                        name_display = f"{name_display} (local)"

                    if fid:
                        self.ssh_key_names[fid] = name_display
                        choices.append(f"{fid}|{name_display}|{created_at}|{fingerprint}")

            return choices
        except _SETUP_ADAPTER_ERRORS:
            return choices

    def _generate_server_side_key(self, context: dict[str, Any] | None = None) -> str | None:
        """Generate SSH key server-side using context for credentials."""
        try:
            ctx = context or {}
            config = self.detect_existing_config()
            api_key = (
                ctx.get("api_key") or config.get("api_key") or os.environ.get("MITHRIL_API_KEY")
            )
            project = (
                ctx.get("project") or config.get("project") or os.environ.get("MITHRIL_PROJECT")
            )

            if not api_key or not project:
                self.console.print(
                    "[error]API key and project required for SSH key generation[/error]"
                )
                return None

            client = self._get_client(api_key)
            api = MithrilApiClient(client)
            projects = api.list_projects()
            project_id = None
            for proj in projects:
                if proj.get("name") == project:
                    project_id = proj.get("fid") or proj.get("id") or proj.get("project_id")
                    break

            if not project_id:
                self.console.print("[error]Could not resolve project ID[/error]")
                return None

            from flow.adapters.providers.builtin.mithril.resources.ssh import SSHKeyManager

            ssh_manager = SSHKeyManager(api, get_project_id=lambda: project_id)
            generated_key_id = ssh_manager.generate_server_key()
            # Invalidate adapter-owned caches after the mutating operation so
            # subsequent reads (wizard menus, verification) see the new key.
            self.invalidate_resource_cache()
            self.ssh_key_names.clear()
            return generated_key_id

        except _SETUP_ADAPTER_ERRORS as e:
            self.console.print(
                f"[error]Error generating SSH key: {escape(type(e).__name__)}: {escape(str(e))}[/error]"
            )
            return None

    def _extract_fingerprint(self, public_key: str) -> str:
        if not public_key:
            return ""
        try:
            from flow.core.utils.ssh_key import (
                sha256_fingerprint_from_public_key as _fp_sha256,
            )

            full = _fp_sha256(public_key) or ""
            if not full:
                return ""
            try:
                body = full.split(":", 1)[1]
            except (IndexError, ValueError):
                body = full
            return f"SHA256:{body[:8]}..."
        except (ImportError, AttributeError, TypeError):
            return ""
