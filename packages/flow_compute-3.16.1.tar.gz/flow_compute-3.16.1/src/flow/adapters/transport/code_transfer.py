from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Protocol

from flow.adapters.transport.rsync import (
    RsyncTransferStrategy,
    TransferError,
)
from flow.adapters.transport.ssh import (
    ExponentialBackoffSSHWaiter,
    ISSHWaiter,
    SSHConnectionInfo,
)
from flow.core.code_upload.targets import MARKER_FILENAME, home_fallback
from flow.core.ignore import build_exclude_patterns
from flow.core.transfer import (
    CodeTransferConfig,
    IProgressReporter,
    ITransferStrategy,
    TransferResult,
)
from flow.errors import CodeTransferError, FlowError

logger = logging.getLogger(__name__)


class TransferTask(Protocol):
    task_id: str
    ssh_host: str | None


class CodeTransferManager:
    def __init__(
        self,
        provider: object | None = None,
        ssh_waiter: ISSHWaiter | None = None,
        transfer_strategy: ITransferStrategy | None = None,
        progress_reporter: IProgressReporter | None = None,
    ):
        self.provider = provider
        self.ssh_waiter = ssh_waiter or ExponentialBackoffSSHWaiter(provider)
        self.transfer_strategy = transfer_strategy or RsyncTransferStrategy()
        self.progress_reporter = progress_reporter

    def transfer_code_to_task(
        self,
        task: TransferTask,
        config: CodeTransferConfig | None = None,
        node: int | None = None,
    ) -> TransferResult:
        if not config:
            config = CodeTransferConfig()

        logger.info(
            f"Starting code transfer to task {task.task_id}\n  Source: {config.source_dir}\n  Target: {task.task_id}:{config.target_dir}"
        )

        self._current_transfer_config = config
        try:
            connection = self._wait_for_ssh(task, config, node)
            result = self._transfer_code(connection, config)
            self._verify_transfer(connection, config)
            return result
        except (TimeoutError, OSError, RuntimeError, FlowError, TransferError) as e:
            logger.debug("Code transfer failed for task %s: %s", task.task_id, e, exc_info=True)
            raise CodeTransferError(
                f"Failed to transfer code to task {task.task_id}",
                suggestions=[
                    "Check SSH connectivity to the instance",
                    "Verify the target directory has write permissions",
                    "Retry the operation — transient SSH errors are common",
                ],
            ) from e
        finally:
            self._current_transfer_config = None

    def _wait_for_ssh(
        self, task: TransferTask, config: CodeTransferConfig, node: int | None = None
    ) -> SSHConnectionInfo:
        # When an ssh_host is present, a very short probe can still catch the VM mid-provision.
        # Avoid the previous overly aggressive 3s quick probe; allow a brief stabilization window instead.
        if task.ssh_host:
            try:
                return self.ssh_waiter.wait_for_ssh(
                    task, timeout=min(30, int(config.ssh_timeout or 1200)), node=node
                )
            except (TimeoutError, OSError, RuntimeError, FlowError):
                # Fall through to a full wait with progress
                pass

        def ssh_progress(status: str):
            if self.progress_reporter:
                self.progress_reporter.update_status(status)

        try:
            if self.progress_reporter:
                with self.progress_reporter.ssh_wait_progress("Waiting for SSH access"):
                    return self.ssh_waiter.wait_for_ssh(
                        task, timeout=config.ssh_timeout, progress_callback=ssh_progress, node=node
                    )
            return self.ssh_waiter.wait_for_ssh(
                task, timeout=config.ssh_timeout, progress_callback=ssh_progress, node=node
            )
        except (TimeoutError, OSError, RuntimeError, FlowError) as e:
            logger.debug("SSH connection failed for code transfer: %s", e, exc_info=True)
            raise CodeTransferError(
                "Failed to establish SSH connection for code transfer",
                suggestions=[
                    "The instance may still be booting — wait and retry",
                    "Check instance status: flow status",
                    "Verify SSH key is configured: flow ssh-key list",
                ],
            ) from e

    def _stabilize_ssh(self, connection: SSHConnectionInfo, *, seconds: int = 20) -> None:
        """Best-effort: require a couple of consecutive quick successes before heavy operations.

        Uses is_ssh_ready() against the same host/key so we reuse any control master.
        Returns after the window or two consecutive OKs. Probe failures count as
        a reset rather than a fatal error.
        """
        import time as _t

        from flow.core.ssh import is_ssh_ready

        deadline = _t.time() + max(5, int(seconds))
        ok = 0
        while _t.time() < deadline and ok < 2:
            try:
                prefix_args = ["-J", str(connection.proxyjump)] if connection.proxyjump else None
                if is_ssh_ready(
                    user=connection.user,
                    host=connection.host,
                    port=connection.port,
                    key_path=connection.key_path,
                    prefix_args=prefix_args,
                ):
                    ok += 1
                else:
                    ok = 0
            except (OSError, subprocess.SubprocessError, TimeoutError):
                ok = 0
            _t.sleep(2)

    def _transfer_code(
        self, connection: SSHConnectionInfo, config: CodeTransferConfig
    ) -> TransferResult:
        incremental_requested = config.git_incremental is True
        # ``_is_incremental_safe`` already swallows remote-exec failures and
        # returns False, so no extra wrapper is needed here.
        use_incremental = (
            self._is_incremental_safe(connection, config) if incremental_requested else False
        )

        target_to_use = self._resolve_target(connection, config)
        transfer_progress = self._build_progress_callback()

        try:
            result = self._execute_transfer(
                connection,
                config,
                target_to_use,
                use_incremental,
                incremental_requested,
                transfer_progress,
            )
            self._finalize_transfer(connection, config, result)
            return result
        except TransferError as e:
            return self._handle_transfer_failure(
                e,
                connection,
                config,
                target_to_use,
                use_incremental,
                transfer_progress,
            )

    def _resolve_target(self, connection: SSHConnectionInfo, config: CodeTransferConfig) -> str:
        """Determine effective target directory, probing writability for absolute paths."""
        target_to_use = config.target_dir
        probe_target = str(target_to_use).strip() if target_to_use else None

        # Best-effort stabilization before preflight
        self._stabilize_ssh(connection, seconds=10)
        self._preflight_target_dir(connection, probe_target)

        # Only probe absolute paths for writability; ~ and ~/... are assumed writable.
        # ``_is_remote_dir_writable`` already returns False on probe failures, so
        # we just trust it and fall back when it reports non-writable.
        if (
            probe_target
            and probe_target.startswith("/")
            and not self._is_remote_dir_writable(connection, probe_target)
        ):
            fallback = self._compute_home_fallback(config)
            if fallback != probe_target and self.progress_reporter:
                self.progress_reporter.update_status(
                    f"Remote path {probe_target} not writable; using {fallback}"
                )
            return fallback
        return target_to_use

    def _build_progress_callback(self):
        """Build a progress callback that delegates to the progress reporter."""

        def transfer_progress(progress):
            if not self.progress_reporter:
                return
            if hasattr(self.progress_reporter, "update_transfer"):
                self.progress_reporter.update_transfer(
                    progress.percentage, progress.speed, progress.eta, progress.current_file
                )
            elif progress.current_file:
                file_display = progress.current_file.split("/")[-1]
                self.progress_reporter.update_status(f"Uploading: {file_display}")
            elif progress.percentage is not None:
                status = f"Progress: {progress.percentage:.0f}%"
                if progress.speed:
                    status += f" @ {progress.speed}"
                if progress.eta:
                    status += f" (ETA: {progress.eta})"
                self.progress_reporter.update_status(status)

        # Attach seed helper for transfer strategies to seed realistic ETA estimates
        if self.progress_reporter and hasattr(self.progress_reporter, "seed_estimated_seconds"):
            transfer_progress.seed_estimated_seconds = (
                lambda seconds: self.progress_reporter.seed_estimated_seconds(seconds)
            )
        return transfer_progress

    def _execute_transfer(
        self,
        connection: SSHConnectionInfo,
        config: CodeTransferConfig,
        target: str,
        use_incremental: bool,
        incremental_requested: bool,
        progress_callback,
    ) -> TransferResult:
        """Run the rsync transfer with optional progress reporting."""
        if self.progress_reporter:
            with self.progress_reporter.transfer_progress(f"Uploading code to {target}"):
                if incremental_requested and not use_incremental:
                    self.progress_reporter.update_status(
                        "Incremental requested but no matching baseline; using full scan"
                    )
                else:
                    self.progress_reporter.update_status("Starting rsync (scanning changes)...")
                result = self.transfer_strategy.transfer(
                    source=config.source_dir,  # type: ignore[arg-type]
                    target=target,
                    connection=connection,
                    progress_callback=progress_callback,
                    git_incremental=use_incremental,
                )
                self.progress_reporter.update_status("Verifying upload on remote...")
                self._set_completion_note(result)
                return result
        return self.transfer_strategy.transfer(
            source=config.source_dir,  # type: ignore[arg-type]
            target=target,
            connection=connection,
            progress_callback=progress_callback,
            git_incremental=use_incremental,
        )

    def _finalize_transfer(
        self,
        connection: SSHConnectionInfo,
        config: CodeTransferConfig,
        result: TransferResult,
    ) -> None:
        """Post-transfer bookkeeping: write marker, track final target."""
        self._write_remote_marker(connection, config, result)
        self._last_final_target = getattr(result, "final_target", None) or config.target_dir

    def _set_completion_note(self, result: TransferResult) -> None:
        """Attach a concise summary to the progress reporter."""
        if not hasattr(self.progress_reporter, "set_completion_note"):
            return
        rate = result.transfer_rate
        mb = max(0, int(result.bytes_transferred / (1024 * 1024)))
        note = f"{result.files_transferred} files, {mb} MB"
        if isinstance(rate, str) and rate and rate != "N/A":
            note += f" @ {rate}"
        # ``UploadProgressReporter.set_completion_note`` is already best-effort.
        self.progress_reporter.set_completion_note(note)

    def _handle_transfer_failure(
        self,
        error: TransferError,
        connection: SSHConnectionInfo,
        config: CodeTransferConfig,
        target: str,
        use_incremental: bool,
        progress_callback,
    ) -> TransferResult:
        """Handle TransferError with permission fallback and retry logic."""
        msg = str(error)
        effective_target = target or config.target_dir

        # Permission-denied fallback to the same home target used by the planner.
        attempted_fallback = False
        fallback_home_target = None
        if (
            effective_target
            and effective_target != "~"
            and self._is_permission_error(msg, effective_target)
        ):
            fallback_home_target = home_fallback(config.source_dir)
            if self.progress_reporter:
                self.progress_reporter.update_status(
                    f"Remote path {effective_target} not writable; retrying with {fallback_home_target}"
                )
            try:
                attempted_fallback = True
                fb_result = self.transfer_strategy.transfer(
                    source=config.source_dir,  # type: ignore[arg-type]
                    target=fallback_home_target,
                    connection=connection,
                    progress_callback=progress_callback,
                    git_incremental=use_incremental,
                )
                fb_result.final_target = str(fallback_home_target)
                self._finalize_transfer(connection, config, fb_result)
                return fb_result
            except TransferError:
                pass

        # Network-related errors: stabilize SSH before retry
        if self._is_network_error(msg) and config.retry_on_failure:
            if self.progress_reporter:
                self.progress_reporter.update_status("SSH unstable; re-checking connection")
            self._stabilize_ssh(connection, seconds=30)

        if config.retry_on_failure:
            retry_target = fallback_home_target if attempted_fallback else config.target_dir
            try:
                return self.transfer_strategy.transfer(
                    source=config.source_dir,  # type: ignore[arg-type]
                    target=retry_target,
                    connection=connection,
                    git_incremental=use_incremental,
                )
            except (TransferError, OSError, TimeoutError, RuntimeError) as e2:
                logger.debug("Code transfer failed after retry: %s", e2, exc_info=True)
                raise CodeTransferError(
                    "Code transfer failed after retrying",
                    suggestions=[
                        "Check network stability to the instance",
                        "Verify disk space on the remote instance",
                        "Try restarting the instance if the problem persists",
                    ],
                ) from e2

        raise CodeTransferError(f"Code transfer failed: {error}") from error

    @staticmethod
    def _is_permission_error(error_text: str, target_dir: str) -> bool:
        denied_indicators = [
            "Permission denied",
            "failed: Permission denied",
            f'mkdir "{target_dir}" failed',
            "error in file IO (code 11)",
        ]
        return any(ind in error_text for ind in denied_indicators)

    @staticmethod
    def _is_network_error(error_text: str) -> bool:
        indicators = (
            "connection closed by",
            "banner exchange",
            "timed out",
            "connection refused",
            "network is unreachable",
        )
        low = error_text.lower()
        return any(s in low for s in indicators)

    def _preflight_target_dir(self, connection: SSHConnectionInfo, target_dir: str | None) -> None:
        """Best-effort remote mkdir for common absolute targets to minimize permission issues.

        Supports absolute paths, home-relative paths (``~/...``), and bare ``~``.
        ``ensure_dir`` and ``ensure_writable`` already swallow subprocess errors,
        so we delegate without an extra wrapper.
        """
        if not target_dir:
            return
        td = str(target_dir).strip()
        from flow.adapters.transport.remote_helpers import ensure_dir, ensure_writable

        allow_sudo = self._get_prepare_absolute_policy()
        ensure_dir(connection, td, sudo=allow_sudo)
        # If we used sudo to create an absolute path, also try to make it
        # writable for the SSH user.
        if allow_sudo and td.startswith("/"):
            ensure_writable(connection, td, user=connection.user, sudo=True)

    def _verify_transfer(self, connection: SSHConnectionInfo, config: CodeTransferConfig) -> None:
        """Best-effort verification that code landed on the remote host."""
        if not getattr(self.provider, "remote_exec", None):
            return
        final_target = getattr(self, "_last_final_target", None) or config.target_dir
        try:
            output = self.provider.remote_exec(
                connection.task_id, f"ls -la {final_target} | head -5"
            )
            if output and "No such file or directory" in output:
                raise CodeTransferError(f"Target directory {final_target} not found after transfer")
        except CodeTransferError:
            raise
        except Exception:  # noqa: BLE001 - remote exec can fail in many ways
            pass

    # ---------------- incremental handshake helpers ----------------
    def _get_git_head(self, source: Path | None) -> str | None:
        if not source:
            return None
        try:
            check = subprocess.run(
                ["git", "rev-parse", "--is-inside-work-tree"],
                cwd=source,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if check.returncode != 0 or check.stdout.strip().lower() != "true":
                return None
            head = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=source,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if head.returncode == 0:
                return head.stdout.strip()
        except (OSError, subprocess.SubprocessError):
            return None
        return None

    def _hash_patterns(self, patterns: list[str]) -> str:
        h = hashlib.sha256()
        for p in sorted(patterns):
            h.update(p.encode("utf-8", "ignore") + b"\n")
        return h.hexdigest()

    def _is_incremental_safe(
        self, connection: SSHConnectionInfo, config: CodeTransferConfig
    ) -> bool:
        source_dir = config.source_dir or Path.cwd()
        commit = self._get_git_head(source_dir)
        if not commit:
            return False
        spec = build_exclude_patterns(source_dir)
        ignore_hash = self._hash_patterns(spec.patterns)

        # Candidate marker locations: requested target and home
        candidates: list[str] = []
        if config.target_dir:
            candidates.append(self._remote_marker_path_expr(config.target_dir))
        candidates.append(self._remote_marker_path_expr("~"))

        if not getattr(self.provider, "remote_exec", None):
            return False
        for remote_path_expr in candidates:
            try:
                out = self.provider.remote_exec(
                    connection.task_id, f"cat {remote_path_expr} 2>/dev/null || true"
                )
            except (OSError, RuntimeError, FlowError, json.JSONDecodeError):
                continue
            if not out:
                continue
            try:
                data = json.loads(out)
            except json.JSONDecodeError:
                continue
            if (
                isinstance(data, dict)
                and data.get("commit") == commit
                and data.get("ignore_hash") == ignore_hash
            ):
                return True
        return False

    def _write_remote_marker(
        self, connection: SSHConnectionInfo, config: CodeTransferConfig, result: TransferResult
    ) -> None:
        if not getattr(self.provider, "remote_exec", None):
            return
        source_dir = config.source_dir or Path.cwd()
        spec = build_exclude_patterns(source_dir)
        meta = {
            "version": 1,
            "commit": self._get_git_head(source_dir),
            "ignore_hash": self._hash_patterns(spec.patterns),
            "ignore_source": spec.source,
            "target_dir": getattr(result, "final_target", config.target_dir),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        content = json.dumps(meta, separators=(",", ":"))
        remote_dir = getattr(result, "final_target", config.target_dir)
        encoded = base64.b64encode(content.encode()).decode()
        target_expr = self._remote_marker_path_expr(remote_dir)
        cmd = f"echo '{encoded}' | base64 -d > {target_expr}"
        try:
            self.provider.remote_exec(connection.task_id, cmd)
        except Exception:  # noqa: BLE001 - best-effort marker write
            logger.debug("Failed to write remote sync marker", exc_info=True)

    @staticmethod
    def _remote_marker_path_expr(remote_dir: str | None) -> str:
        """Return a shell path expression for the sync marker.

        The leading ``~`` cannot be single-quoted because shells do not expand
        it in that position. Use "$HOME"/<quoted suffix> so home-relative
        targets still handle spaces and metacharacters safely.
        """
        raw = str(remote_dir or "~")
        marker = MARKER_FILENAME
        if raw in {"~", "~/"}:
            return f'"$HOME"/{marker}'
        if raw.startswith("~/"):
            suffix_dir = raw[2:].rstrip("/")
            suffix = f"{suffix_dir}/{marker}" if suffix_dir else marker
            return '"$HOME"/' + shlex.quote(suffix)

        base = "/" if raw == "/" else raw.rstrip("/")
        return shlex.quote(f"{base}/{marker}")

    # ---------------- remote helpers ----------------
    def _is_remote_dir_writable(self, connection: SSHConnectionInfo, target_dir: str) -> bool:
        """Best-effort probe to check whether the remote directory is writable.

        Uses provider.remote_exec when available. Returns False on any error.
        Avoids aggressive shell constructs to minimize compatibility issues.
        """
        if not getattr(self.provider, "remote_exec", None):
            try:
                from flow.adapters.transport.remote_helpers import is_writable

                return is_writable(connection, target_dir)
            except Exception:  # noqa: BLE001
                return False
        td = str(target_dir).strip()
        if not td:
            return False
        # Only probe absolute or home-relative destinations; ignore plain '~'
        if td == "~":
            return True
        try:
            from flow.adapters.transport.remote_helpers import is_writable

            return is_writable(connection, td)
        except Exception:  # noqa: BLE001
            return False

    def _compute_home_fallback(self, config: CodeTransferConfig) -> str:
        return home_fallback(config.source_dir)

    def _get_prepare_absolute_policy(self) -> bool:
        """Resolve whether to allow sudo for preparing absolute paths.

        Precedence: CodeTransferConfig.prepare_absolute > env FLOW_UPLOAD_ALLOW_SUDO.
        """
        current_cfg = getattr(self, "_current_transfer_config", None)
        if current_cfg and current_cfg.prepare_absolute is not None:
            return bool(current_cfg.prepare_absolute)
        env_val = os.environ.get("FLOW_UPLOAD_ALLOW_SUDO")
        if env_val is not None:
            return str(env_val).strip().lower() in {"1", "true", "yes", "on"}
        return False
