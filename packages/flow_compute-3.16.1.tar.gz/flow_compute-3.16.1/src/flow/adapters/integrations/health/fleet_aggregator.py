"""Fleet health aggregation from node snapshots.

Aggregates health snapshots from multiple nodes into fleet-wide summaries.
"""

from __future__ import annotations

from datetime import datetime, timezone

from flow.adapters.integrations.health.config import DEFAULT_CONFIG
from flow.core.health_models import (
    FleetHealthSummary,
    HealthStatus,
    NodeHealthSnapshot,
)


class FleetHealthAggregator:
    """Aggregates node health snapshots into fleet summaries."""

    def aggregate(self, snapshots: list[NodeHealthSnapshot]) -> FleetHealthSummary:
        """Calculate fleet-wide health summary from node snapshots.

        Args:
            snapshots: List of node health snapshots

        Returns:
            Aggregated fleet health summary
        """
        if not snapshots:
            return self._empty_summary()

        # Separate monitored vs unmonitored nodes
        monitored = [s for s in snapshots if s.health_status != HealthStatus.UNKNOWN]
        unmonitored = [s for s in snapshots if s.health_status == HealthStatus.UNKNOWN]

        # Count nodes by status
        healthy_nodes = sum(1 for s in monitored if s.health_status == HealthStatus.HEALTHY)
        degraded_nodes = sum(1 for s in monitored if s.health_status == HealthStatus.DEGRADED)
        critical_nodes = sum(1 for s in monitored if s.health_status == HealthStatus.CRITICAL)

        # Count legacy nodes (no GPUd installed)
        legacy_nodes = sum(
            1 for s in unmonitored if "legacy" in (s.machine_info.get("note", "") or "").lower()
        )

        # Calculate GPU metrics
        gpu_stats = self._calculate_gpu_stats(monitored)

        # Collect critical issues and warnings
        critical_issues, warnings = self._collect_issues(snapshots)

        return FleetHealthSummary(
            timestamp=datetime.now(timezone.utc),
            total_nodes=len(monitored),
            healthy_nodes=healthy_nodes,
            degraded_nodes=degraded_nodes,
            critical_nodes=critical_nodes,
            total_gpus=gpu_stats["total_gpus"],
            healthy_gpus=gpu_stats["healthy_gpus"],
            avg_gpu_temperature=gpu_stats["avg_temperature"],
            avg_gpu_utilization=gpu_stats["avg_utilization"],
            avg_gpu_memory_utilization=gpu_stats["avg_memory"],
            critical_issues=critical_issues,
            warnings=warnings,
            legacy_nodes=legacy_nodes,
        )

    def _empty_summary(self) -> FleetHealthSummary:
        """Return an empty fleet summary."""
        return FleetHealthSummary(
            timestamp=datetime.now(timezone.utc),
            total_nodes=0,
            healthy_nodes=0,
            degraded_nodes=0,
            critical_nodes=0,
            total_gpus=0,
            healthy_gpus=0,
            avg_gpu_temperature=0.0,
            avg_gpu_utilization=0.0,
            avg_gpu_memory_utilization=0.0,
        )

    def _calculate_gpu_stats(
        self,
        snapshots: list[NodeHealthSnapshot],
    ) -> dict[str, float | int]:
        """Calculate aggregate GPU statistics across all nodes.

        For multi-node tasks, total_gpus is extrapolated (count * nodes) but
        healthy_gpus and averages are computed only from measured GPUs to avoid
        extrapolating health status to nodes we haven't observed.
        """
        total_gpus = 0
        healthy_gpus = 0
        measured_gpus = 0
        sum_temp = 0.0
        sum_util = 0.0
        sum_mem = 0.0

        for snapshot in snapshots:
            try:
                nodes = int(snapshot.machine_info.get("nodes", 1) or 1)
            except (TypeError, ValueError):
                nodes = 1

            gpus_per_node = len(snapshot.gpu_metrics)
            if gpus_per_node == 0:
                gpus_per_node = int(snapshot.machine_info.get("gpus_per_node", 0) or 0)

            # Total is an estimate (safe to extrapolate count)
            total_gpus += nodes * gpus_per_node

            # Health and averages: only count GPUs we actually measured
            for gpu in snapshot.gpu_metrics:
                measured_gpus += 1
                if (
                    gpu.temperature_c < DEFAULT_CONFIG.scoring.temperature_warning_c
                    and not gpu.is_throttling
                ):
                    healthy_gpus += 1

                sum_temp += gpu.temperature_c
                sum_util += gpu.gpu_utilization_pct
                sum_mem += gpu.memory_utilization_pct

        if measured_gpus > 0:
            avg_temp = sum_temp / measured_gpus
            avg_util = sum_util / measured_gpus
            avg_mem = sum_mem / measured_gpus
        else:
            avg_temp = 0.0
            avg_util = 0.0
            avg_mem = 0.0

        return {
            "total_gpus": total_gpus,
            "healthy_gpus": healthy_gpus,
            "avg_temperature": avg_temp,
            "avg_utilization": avg_util,
            "avg_memory": avg_mem,
        }

    def _collect_issues(
        self,
        snapshots: list[NodeHealthSnapshot],
    ) -> tuple[list[dict], list[dict]]:
        """Collect critical issues and warnings from all snapshots.

        Returns:
            Tuple of (critical_issues, warnings)
        """
        critical_issues: list[dict] = []
        warnings: list[dict] = []

        temp_critical = DEFAULT_CONFIG.scoring.temperature_critical_c
        temp_warning = DEFAULT_CONFIG.scoring.temperature_warning_c

        for snapshot in snapshots:
            # Critical temperature issues
            for gpu in snapshot.gpu_metrics:
                if gpu.temperature_c >= temp_critical:
                    critical_issues.append(
                        {
                            "task_name": snapshot.task_name,
                            "component": f"GPU {gpu.gpu_index}",
                            "message": f"Critical temperature: {gpu.temperature_c}°C",
                        }
                    )
                elif gpu.temperature_c >= temp_warning:
                    warnings.append(
                        {
                            "task_name": snapshot.task_name,
                            "component": f"GPU {gpu.gpu_index}",
                            "message": f"High temperature: {gpu.temperature_c}°C",
                        }
                    )

                # ECC errors
                if gpu.ecc_errors > 0:
                    critical_issues.append(
                        {
                            "task_name": snapshot.task_name,
                            "component": f"GPU {gpu.gpu_index}",
                            "message": f"{gpu.ecc_errors} ECC errors detected",
                        }
                    )

                # XID events
                if gpu.xid_events:
                    critical_issues.append(
                        {
                            "task_name": snapshot.task_name,
                            "component": f"GPU {gpu.gpu_index}",
                            "message": f"XID events: {', '.join(gpu.xid_events[:3])}",
                        }
                    )

                # Memory pressure
                if gpu.memory_utilization_pct >= 95:
                    warnings.append(
                        {
                            "task_name": snapshot.task_name,
                            "component": f"GPU {gpu.gpu_index}",
                            "message": f"Memory nearly full: {gpu.memory_utilization_pct:.0f}%",
                        }
                    )

                # Throttling
                if gpu.is_throttling:
                    warnings.append(
                        {
                            "task_name": snapshot.task_name,
                            "component": f"GPU {gpu.gpu_index}",
                            "message": f"Throttling (clock: {gpu.clock_mhz}/{gpu.max_clock_mhz} MHz)",
                        }
                    )

            # Critical node status
            if snapshot.health_status == HealthStatus.CRITICAL:
                critical_issues.append(
                    {
                        "task_name": snapshot.task_name,
                        "component": "node",
                        "message": f"Node health critical (score: {snapshot.health_score:.2f})",
                    }
                )

        legacy_count = 0
        not_installed_count = 0
        for snapshot in snapshots:
            if snapshot.health_status != HealthStatus.UNKNOWN:
                continue
            note = (snapshot.machine_info.get("note") or "").lower()
            if "legacy" in note:
                legacy_count += 1
            elif "not installed" in note:
                not_installed_count += 1

        if legacy_count:
            warnings.append(
                _unmonitored_warning(
                    "Legacy Tasks",
                    legacy_count,
                    "started before GPU monitoring was available",
                )
            )

        if not_installed_count:
            warnings.insert(
                0,
                _unmonitored_warning(
                    "Manual Tasks",
                    not_installed_count,
                    "without GPU monitoring (started manually or via console)",
                ),
            )

        return critical_issues, warnings


def _unmonitored_warning(label: str, count: int, suffix: str) -> dict:
    return {
        "task_name": label,
        "component": "GPU Monitoring",
        "message": f"{count} task(s) {suffix}",
    }


__all__ = ["FleetHealthAggregator"]
