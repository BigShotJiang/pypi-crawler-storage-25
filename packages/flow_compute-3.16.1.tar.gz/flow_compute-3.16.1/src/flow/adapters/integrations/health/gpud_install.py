"""Install GPUd on a remote instance over SSH.

Single source of truth for the curl install + ``gpud up`` start + healthz
poll cycle. Used by both the dashboard subcommand and the auto-install
fallback in HealthChecker.
"""

from __future__ import annotations

import logging
import subprocess
import time
from collections.abc import Callable

logger = logging.getLogger(__name__)

INSTALL_URL = "https://pkg.gpud.dev/install.sh"
HEALTHZ_TIMEOUT_SECONDS = 30
HEALTHZ_POLL_INTERVAL = 2


def _silent(_msg: str) -> None:
    return None


def ensure_gpud_running(
    ssh_prefix: list[str],
    *,
    bind: str,
    port: int,
    version: str,
    emit: Callable[[str], None] = _silent,
    write_marker: bool = False,
    skip_initial_probe: bool = False,
) -> bool:
    """Probe, install if missing, start, and verify GPUd over SSH.

    Args:
        ssh_prefix: argv list that runs subsequent commands on the target host
            (e.g., the output of ``build_ssh_command``).
        bind: bind address for ``gpud up`` (e.g., ``127.0.0.1``).
        port: TCP port for ``gpud up``.
        version: GPUd release version to install.
        emit: callback for user-facing status lines (Rich-formatted strings).
        write_marker: write ``/var/run/flow-gpud-status`` after start (used by
            the auto-install path so subsequent checks can detect manual starts).
        skip_initial_probe: skip the up-front healthz check when the caller has
            already determined GPUd is missing (saves one SSH round-trip).

    Returns:
        True when GPUd's healthz endpoint responds within
        ``HEALTHZ_TIMEOUT_SECONDS``.
    """
    health_cmd = ssh_prefix + [f"curl -sf -m 3 https://localhost:{port}/healthz -k"]

    if (
        not skip_initial_probe
        and subprocess.run(health_cmd, capture_output=True, text=True, timeout=15).returncode == 0
    ):
        return True

    emit("[warning]Installing GPU monitoring daemon (GPUd)...[/warning]")
    install_cmd = ssh_prefix + [f"curl -fsSL {INSTALL_URL} | bash -s -- {version}"]
    install = subprocess.run(install_cmd, capture_output=True, text=True, timeout=120)
    if install.returncode != 0:
        err = install.stderr.strip() if install.stderr else "unknown error"
        logger.debug("GPUd install failed: %s", err)
        emit(f"[warning]GPUd install failed: {err}[/warning]")
        return False

    start_cmd = ssh_prefix + [f"sudo gpud up --web-address={bind}:{port}"]
    start_result = subprocess.run(start_cmd, capture_output=True, text=True, timeout=30)
    if start_result.returncode != 0:
        err = start_result.stderr.strip() if start_result.stderr else "unknown error"
        logger.debug("GPUd start failed: %s", err)
        emit(f"[warning]GPUd start failed: {err}[/warning]")
        return False

    if write_marker:
        marker_cmd = ssh_prefix + ["echo 'running' | sudo tee /var/run/flow-gpud-status"]
        subprocess.run(marker_cmd, capture_output=True, text=True, timeout=10)

    deadline = time.monotonic() + HEALTHZ_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        poll = subprocess.run(health_cmd, capture_output=True, text=True, timeout=5)
        if poll.returncode == 0:
            emit("[success]GPUd installed and running.[/success]")
            return True
        time.sleep(HEALTHZ_POLL_INTERVAL)

    emit(
        "[warning]GPUd installed but health endpoint not responding "
        f"after {HEALTHZ_TIMEOUT_SECONDS}s on port {port}[/warning]"
    )
    return False


__all__ = ["INSTALL_URL", "ensure_gpud_running"]
