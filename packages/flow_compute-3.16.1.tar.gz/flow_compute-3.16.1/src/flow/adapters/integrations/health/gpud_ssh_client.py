"""SSH-based GPUd client.

Communicates with GPUd by executing curl commands over SSH. Uses the same
module-level parsing functions as the HTTP client for consistent behavior.
"""

from __future__ import annotations

import json
import logging
import subprocess
from typing import Any

from flow.adapters.integrations.health.config import DEFAULT_GPUD_PORT
from flow.adapters.integrations.health.gpud_v08_adapter import (
    build_events,
    build_gpu_metrics,
    build_health_states,
    build_system_metrics,
    parse_network_health,
)
from flow.core.health_models import (
    GPUMetric,
    HealthState,
    SystemEvent,
    SystemMetrics,
)
from flow.errors import GPUdConnectionError, HealthCheckTimeoutError

logger = logging.getLogger(__name__)


class GPUdSSHClient:
    """SSH-based client for GPUd v0.8.0+ API.

    Executes curl commands via SSH to communicate with GPUd on remote hosts.
    Uses HTTPS with self-signed cert verification disabled (-k flag), matching
    GPUd's default TLS configuration.
    """

    def __init__(
        self,
        ssh_command_prefix: list[str],
        gpud_port: int = DEFAULT_GPUD_PORT,
        curl_timeout: int = 5,
    ):
        """Initialize GPUd SSH client.

        Args:
            ssh_command_prefix: SSH command prefix including host and options
                (e.g., ["ssh", "-i", "/path/to/key", "user@host"]).
            gpud_port: GPUd port on the remote host.
            curl_timeout: Timeout for curl commands in seconds.
        """
        self.ssh_prefix = ssh_command_prefix
        self.gpud_port = gpud_port
        self.curl_timeout = curl_timeout
        self._machine_info_cache: dict[str, Any] | None = None

    def _curl(self, path: str) -> str:
        """Execute a curl command via SSH and return stdout.

        Args:
            path: URL path to fetch (e.g., "/v1/states").

        Returns:
            Response body as string.

        Raises:
            GPUdConnectionError: If curl fails.
            HealthCheckTimeoutError: If SSH/curl times out.
        """
        cmd = self.ssh_prefix + [
            "curl",
            "-sk",
            "-f",
            "-m",
            str(self.curl_timeout),
            f"https://localhost:{self.gpud_port}{path}",
        ]
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.curl_timeout + 5,
            )
            if result.returncode != 0:
                raise GPUdConnectionError(f"SSH curl to {path} failed (exit {result.returncode})")
            return result.stdout
        except subprocess.TimeoutExpired:
            raise HealthCheckTimeoutError(
                f"SSH curl to {path}",
                timeout_seconds=self.curl_timeout + 5,
            )

    def _fetch_json(self, path: str) -> Any:
        """Fetch a JSON endpoint via SSH.

        Args:
            path: URL path.

        Returns:
            Parsed JSON response.

        Raises:
            GPUdConnectionError: On network or parse errors.
        """
        out = self._curl(path)
        if not out:
            raise GPUdConnectionError(f"Empty response from {path}")
        try:
            return json.loads(out)
        except json.JSONDecodeError as e:
            raise GPUdConnectionError(f"Invalid JSON from {path}: {e}") from e

    def is_healthy(self) -> bool:
        """Check if GPUd is responding."""
        try:
            self._curl("/healthz")
            return True
        except (GPUdConnectionError, HealthCheckTimeoutError):
            return False

    def get_machine_info(self) -> dict[str, Any]:
        """Get machine info from GPUd."""
        if self._machine_info_cache is not None:
            return self._machine_info_cache
        try:
            self._machine_info_cache = self._fetch_json("/machine-info")
            return self._machine_info_cache
        except GPUdConnectionError as e:
            logger.warning(f"Failed to get machine info via SSH: {e}")
            return {}

    def get_gpu_metrics(self) -> list[GPUMetric]:
        """Get GPU metrics by aggregating component states."""
        components = self._fetch_json("/v1/states")
        machine_info = self.get_machine_info()
        return build_gpu_metrics(components, machine_info)

    def get_system_metrics(self) -> SystemMetrics | None:
        """Get system metrics from component states."""
        try:
            components = self._fetch_json("/v1/states")
        except GPUdConnectionError as e:
            logger.warning(f"Failed to get system metrics via SSH: {e}")
            return None
        return build_system_metrics(components)

    def get_health_states(self) -> list[HealthState]:
        """Get component health states."""
        try:
            components = self._fetch_json("/v1/states")
        except GPUdConnectionError as e:
            logger.warning(f"Failed to get health states via SSH: {e}")
            return []
        return build_health_states(components)

    def get_events(self) -> list[SystemEvent]:
        """Get recent events from GPUd."""
        try:
            components = self._fetch_json("/v1/events")
        except GPUdConnectionError as e:
            logger.warning(f"Failed to get events via SSH: {e}")
            return []
        return build_events(components)

    def get_network_health(self) -> dict[str, bool]:
        """Get InfiniBand and NCCL health flags."""
        try:
            components = self._fetch_json("/v1/states")
        except GPUdConnectionError as e:
            logger.warning(f"Failed to get network health via SSH: {e}")
            return {"infiniband_healthy": True, "nccl_healthy": True}
        return parse_network_health(components)

    def close(self) -> None:
        """No-op for SSH client (no persistent connection)."""

    def __enter__(self) -> GPUdSSHClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


__all__ = ["GPUdSSHClient"]
