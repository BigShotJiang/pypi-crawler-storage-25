"""User identity management for Slurm overlay clusters."""

from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Any

from flow.application.slurm_overlay.models import ClusterUser

LINUX_USERNAME_PATTERN = re.compile(r"^[a-z_][a-z0-9_]{0,31}$")


def derive_slurm_username(user_info: dict[str, Any]) -> str:
    """Derive a valid Linux username from Flow user info.

    Priority: user_name -> email prefix -> user_id prefix.
    Linux rules: max 32 chars, lowercase alphanumeric + underscore, starts with letter.
    """
    user_name = user_info.get("user_name") or user_info.get("username")
    if user_name:
        username = re.sub(r"[^a-z0-9_]", "", str(user_name).lower())
        if username and username[0].isalpha():
            return username[:32]

    email = user_info.get("email") or user_info.get("primary_email")
    if email and "@" in str(email):
        username = re.sub(r"[^a-z0-9_]", "", str(email).split("@")[0].lower())
        if username and username[0].isalpha():
            return username[:32]

    user_id = user_info.get("fid") or user_info.get("id") or user_info.get("user_id") or "flowuser"
    username = re.sub(r"[^a-z0-9_]", "", str(user_id).lower().replace("user_", "u"))
    if not username or not username[0].isalpha():
        username = "u" + username
    return username[:32]


def ensure_unique_username(username: str, existing: set[str]) -> str:
    """Ensure username is unique by appending _N suffix if needed."""
    if username not in existing:
        return username
    for i in range(2, 100):
        candidate = f"{username[:29]}_{i}"
        if candidate not in existing:
            return candidate
    raise ValueError(f"Could not generate unique username for {username}")


def validate_linux_username(username: str) -> str:
    """Validate a generated Linux username before using it in shell commands."""
    if not LINUX_USERNAME_PATTERN.fullmatch(username):
        raise ValueError(f"Invalid Linux username: {username}")
    return username


def create_cluster_user(user_info: dict[str, Any], existing_usernames: set[str]) -> ClusterUser:
    """Create a ClusterUser from Flow user info with unique username."""
    flow_user_id = user_info.get("fid") or user_info.get("id") or user_info.get("user_id")
    if not flow_user_id:
        raise ValueError("Flow user identity is missing fid/id/user_id")

    username = ensure_unique_username(derive_slurm_username(user_info), existing_usernames)
    validate_linux_username(username)
    return ClusterUser(
        flow_user_id=str(flow_user_id),
        flow_email=user_info.get("email") or user_info.get("primary_email"),
        linux_username=username,
        provisioned_at=datetime.now(UTC),
    )
