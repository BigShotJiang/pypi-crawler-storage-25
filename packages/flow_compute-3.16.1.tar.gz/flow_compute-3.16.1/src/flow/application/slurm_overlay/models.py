"""Slurm overlay cluster configuration and state models."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

if TYPE_CHECKING:
    from typing import Self


DEFAULT_SHARED_MOUNT_PATHS = ["/home", "/scratch"]


class SlurmOverlayConfig(BaseModel):
    """Configuration for a Slurm overlay cluster."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(
        ...,
        description="Cluster name (3-63 chars, lowercase alphanumeric with hyphens)",
        pattern=r"^[a-z0-9][a-z0-9-]*[a-z0-9]$",
        min_length=3,
        max_length=63,
    )
    controller: str = Field(
        ...,
        description="Instance to use as Slurm controller (slurmctld)",
    )
    workers: list[str] = Field(
        default_factory=list,
        description="Instances to use as Slurm workers (slurmd)",
    )

    partition: str = Field(
        "gpu",
        description="Default partition name",
        pattern=r"^[a-zA-Z][a-zA-Z0-9_]*$",
    )
    max_time: str = Field(
        "7-00:00:00",
        description="Maximum job time (Slurm time format: D-HH:MM:SS)",
        pattern=r"^\d+-\d{2}:\d{2}:\d{2}$|^INFINITE$",
    )

    shared_volume: str | None = Field(
        None,
        description=(
            "Reserved for future shared-storage integration. "
            "Overlay clusters do not currently mount shared volumes automatically."
        ),
    )
    shared_mount_paths: list[str] = Field(
        default_factory=lambda: list(DEFAULT_SHARED_MOUNT_PATHS),
        description=(
            "Reserved for future shared-storage integration. "
            "Custom mount paths are rejected until overlay-managed shared volumes exist."
        ),
    )
    accounting: bool = Field(
        False,
        description=(
            "Reserved for future slurmdbd-backed accounting support. "
            "Overlay clusters currently do not support sacct/fair-share accounting."
        ),
    )

    slurm_conf: str | dict[str, Any] | None = Field(
        None,
        description=(
            "Override/extend slurm.conf directives. "
            "Can be a string (appended verbatim) or dict (key=value pairs)."
        ),
    )
    slurm_conf_extra: str | None = Field(
        None,
        description="Deprecated: use slurm_conf instead. Additional lines to append to slurm.conf",
    )
    gres_conf: str | None = Field(
        None,
        description=(
            "Reserved for future node-local override support. "
            "Overlay clusters currently use auto-detected gres.conf content."
        ),
    )
    cgroup_conf: str | None = Field(
        None,
        description=(
            "Reserved for future node-local override support. "
            "Overlay clusters currently use the built-in cgroup.conf template."
        ),
    )

    @field_validator("controller", mode="before")
    @classmethod
    def validate_controller(cls, value: str) -> str:
        """Validate controller instance identifier."""
        if not isinstance(value, str):
            raise ValueError("Controller instance identifier must be a string")  # noqa: TRY004
        controller = value.strip()
        if len(controller) < 3:
            raise ValueError("Controller instance identifier must be at least 3 characters")
        return controller

    @field_validator("workers", mode="before")
    @classmethod
    def validate_workers(cls, value: list[str] | None) -> list[str]:
        """Validate worker instance identifiers without silently dropping entries."""
        if value is None:
            return []
        if not isinstance(value, list):
            raise ValueError("workers must be a list of instance identifiers")  # noqa: TRY004

        workers: list[str] = []
        for item in value:
            if not isinstance(item, str):
                raise ValueError("Worker instance identifiers must be strings")  # noqa: TRY004
            worker = item.strip()
            if len(worker) < 3:
                raise ValueError("Worker instance identifiers must be at least 3 characters")
            workers.append(worker)
        return workers

    @model_validator(mode="after")
    def validate_config(self) -> Self:
        """Validate overlay configuration."""
        if self.controller in self.workers:
            raise ValueError(
                f"Controller '{self.controller}' cannot also be listed as a worker. "
                "The controller runs slurmctld but can also run jobs (it has slurmd too)."
            )

        if self.max_time != "INFINITE":
            parts = self.max_time.split("-")
            if len(parts) != 2:
                raise ValueError(f"Invalid max_time format: {self.max_time}")

        if self.shared_volume is not None:
            raise ValueError(
                "shared_volume is not supported for Slurm overlay clusters yet. "
                "Mount shared storage outside the overlay workflow before cluster creation."
            )

        if self.shared_mount_paths != DEFAULT_SHARED_MOUNT_PATHS:
            raise ValueError(
                "shared_mount_paths is not supported for Slurm overlay clusters yet because "
                "overlay-managed shared storage is not implemented."
            )

        if self.accounting:
            raise ValueError(
                "accounting=True is not supported for Slurm overlay clusters. "
                "Overlay clusters currently provide queue visibility and job completion logs, "
                "but not sacct/slurmdbd-backed accounting."
            )

        if self.gres_conf is not None:
            raise ValueError(
                "gres_conf overrides are not supported for Slurm overlay clusters yet."
            )

        if self.cgroup_conf is not None:
            raise ValueError(
                "cgroup_conf overrides are not supported for Slurm overlay clusters yet."
            )

        if self.slurm_conf_extra is not None:
            raise ValueError("slurm_conf_extra is deprecated; use slurm_conf instead.")

        return self

    @property
    def all_instances(self) -> list[str]:
        """All instances in the cluster (controller + workers)."""
        return [self.controller] + list(self.workers)

    @property
    def node_count(self) -> int:
        """Total number of nodes in the cluster."""
        return len(self.all_instances)

    def get_slurm_conf_extra_lines(self) -> str:
        """Get effective extra slurm.conf directives as text."""
        lines: list[str] = []

        if self.slurm_conf is not None:
            if isinstance(self.slurm_conf, dict):
                for key, value in self.slurm_conf.items():
                    lines.append(f"{key}={value}")
            else:
                lines.append(self.slurm_conf)

        return "\n".join(lines)

    @classmethod
    def from_yaml(cls, path: str) -> SlurmOverlayConfig:
        """Load configuration from a YAML file."""
        import yaml

        with open(Path(path).expanduser(), encoding="utf-8") as f:
            data = yaml.safe_load(f)

        if not isinstance(data, dict):
            raise TypeError(f"Expected YAML dictionary, got {type(data).__name__}")

        return cls(**data)

    def to_yaml(self, path: str) -> None:
        """Save configuration to a YAML file."""
        import yaml

        with open(Path(path).expanduser(), "w", encoding="utf-8") as f:
            yaml.dump(
                self.model_dump(exclude_none=True, exclude_defaults=True),
                f,
                sort_keys=False,
                default_flow_style=False,
            )


class ClusterUser(BaseModel):
    """A user provisioned on a Slurm overlay cluster."""

    model_config = ConfigDict(extra="forbid")

    flow_user_id: str = Field(..., min_length=1, description="Flow user ID (fid)")
    flow_email: str | None = Field(None, description="User's email address")
    linux_username: str = Field(
        ...,
        description="Linux username on cluster nodes",
        pattern=r"^[a-z_][a-z0-9_]{0,31}$",
    )
    provisioned_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When this user was provisioned on the cluster",
    )


class SlurmOverlayState(BaseModel):
    """Runtime state of a Slurm overlay cluster."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="Cluster name")
    status: Literal["creating", "ready", "degraded", "dissolving"] = Field(
        "ready",
        description="Cluster status",
    )

    controller_fid: str = Field(..., description="Controller instance FID")
    controller_ip: str | None = Field(None, description="Controller private IP")

    worker_fids: list[str] = Field(
        default_factory=list,
        description="Worker instance FIDs",
    )
    worker_ips: dict[str, str] = Field(
        default_factory=dict,
        description="Worker instance FIDs to IPs mapping",
    )

    partition: str = Field("gpu", description="Slurm partition name")
    created_at: datetime | None = Field(None, description="Cluster creation time")

    project_id: str | None = Field(None, description="Project FID this cluster belongs to")
    created_by_user_id: str | None = Field(None, description="Flow user ID who created cluster")
    created_by_username: str | None = Field(None, description="Linux username of cluster creator")
    users: list[ClusterUser] = Field(
        default_factory=list,
        description="Users provisioned on this cluster",
    )

    @property
    def node_count(self) -> int:
        """Total nodes including controller."""
        return 1 + len(self.worker_fids)

    @property
    def all_fids(self) -> list[str]:
        """All instance FIDs in the cluster."""
        return [self.controller_fid] + list(self.worker_fids)

    def get_user_by_flow_id(self, flow_user_id: str) -> ClusterUser | None:
        """Find a cluster user by their Flow user ID."""
        for user in self.users:
            if user.flow_user_id == flow_user_id:
                return user
        return None

    def get_user_by_username(self, username: str) -> ClusterUser | None:
        """Find a cluster user by their Linux username."""
        for user in self.users:
            if user.linux_username == username:
                return user
        return None


class SlurmOverlayMetadata(BaseModel):
    """Metadata stored on each instance in a Slurm overlay cluster."""

    model_config = ConfigDict(extra="forbid")

    cluster: str = Field(..., description="Cluster name this instance belongs to")
    role: Literal["controller", "worker"] = Field(..., description="Node role in cluster")
    controller_ip: str = Field(..., description="Controller private IP (for slurm.conf)")
    partition: str = Field("gpu", description="Slurm partition name (detected from GPU type)")
    joined_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When this instance joined the cluster",
    )
