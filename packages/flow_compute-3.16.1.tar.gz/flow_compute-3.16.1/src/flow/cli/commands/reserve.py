"""Reservations command group — plan and manage capacity.

Implements `flow reserve` with subcommands to check availability, create,
list, show, extend, and a convenience `now` helper. Imports remain lazy
to keep CLI startup responsive.
"""

from __future__ import annotations

import sys
from datetime import datetime as _dt
from datetime import timedelta as _td
from datetime import timezone as _tz
from typing import Any

import click

import flow.sdk.factory as sdk_factory
from flow.cli.commands.base import BaseCommand, console
from flow.cli.services.reservations_service import ReservationsService
from flow.cli.ui.presentation.reservations_view import (
    handle_availability_flow,
    handle_list_flow,
    render_reservation_details,
)
from flow.cli.utils.error_handling import cli_error_guard
from flow.sdk.client import Flow

# --------------- Shared helpers ---------------


def _get_flow_client(ctx: click.Context) -> Flow:
    """Retrieve or create the Flow SDK client from Click context."""
    flow = (ctx.obj or {}).get("flow_client") if getattr(ctx, "obj", None) else None
    return flow or sdk_factory.create_client(auto_init=True)


def _resolve_project(flow: Flow) -> str | None:
    """Resolve project ID from SDK config or environment."""
    import os

    cfg = getattr(flow, "config", None)
    if cfg and isinstance(getattr(cfg, "provider_config", None), dict):
        project = cfg.provider_config.get("project")
        if project:
            return project
    return os.getenv("MITHRIL_PROJECT_ID") or os.getenv("MITHRIL_PROJECT")


def _resolve_region(flow: Flow) -> str | None:
    """Resolve region from SDK config."""
    cfg = getattr(flow, "config", None)
    if cfg and isinstance(getattr(cfg, "provider_config", None), dict):
        return cfg.provider_config.get("region")
    return None


def _extract_reservation_id(task: Any) -> str:
    """Extract reservation ID from provider_metadata, falling back to task_id."""
    if getattr(task, "provider_metadata", None):
        rid = task.provider_metadata.get("reservation", {}).get("reservation_id")
        if rid:
            return rid
    return task.task_id


def _print_reservation_created(task: Any, *, output_json: bool = False) -> None:
    """Print reservation creation confirmation."""
    rid = _extract_reservation_id(task)
    if output_json:
        from flow.cli.utils.json_output import print_json

        print_json({"reservation_id": rid, "task_id": task.task_id})
    else:
        console.print(f"Created reservation: [accent]{rid}[/accent]")


def _is_interactive_tty() -> bool:
    """Return True when stdout and stdin are both TTY."""
    return bool(getattr(sys.stdout, "isatty", lambda: False)()) and bool(
        getattr(sys.stdin, "isatty", lambda: True)()
    )


def _find_immediate_slot(
    service: ReservationsService,
    *,
    instance_type: str,
    region: str,
    now_iso: str,
    duration: int,
    quantity: int,
) -> dict[str, Any] | None:
    """Find a slot that can start within 2 minutes of now with sufficient duration/quantity."""
    end_iso = ReservationsService.isoformat_utc_z(_dt.now(_tz.utc) + _td(hours=duration))
    slots_raw = service.availability(
        ReservationsService.AvailabilityQuery(
            instance_type=instance_type,
            region=region,
            earliest_start_time=now_iso,
            latest_end_time=end_iso,
            quantity=quantity,
            duration_hours=duration,
            mode="slots",
        )
    )
    slots = ReservationsService.normalize_slots(slots_raw)
    now_dt = _dt.fromisoformat(now_iso.replace("Z", "+00:00"))

    for slot in slots:
        st = ReservationsService._to_dt(slot.get("start_time_utc"))
        if not st:
            continue
        starts_soon = abs((st - now_dt).total_seconds()) < 120
        enough_duration = ReservationsService.slot_duration_hours(slot) >= duration
        enough_quantity = int(slot.get("quantity", 0) or 0) >= quantity
        if starts_soon and enough_duration and enough_quantity:
            return slot
    return None


def _offer_fallback_slot(
    cmd: BaseCommand,
    service: ReservationsService,
    *,
    instance_type: str,
    region: str,
    now_iso: str,
    quantity: int,
    duration: int,
    name: str | None,
    ssh_keys: list[str],
    output_json: bool,
    local_time: bool,
) -> None:
    """Search next 24h for availability and offer the earliest slot interactively."""
    horizon_iso = ReservationsService.isoformat_utc_z(_dt.now(_tz.utc) + _td(hours=24))
    slots_raw = service.availability(
        ReservationsService.AvailabilityQuery(
            instance_type=instance_type,
            region=region,
            earliest_start_time=now_iso,
            latest_end_time=horizon_iso,
            quantity=quantity,
            duration_hours=duration,
            mode="slots",
        )
    )
    slots = ReservationsService.filter_slots(
        ReservationsService.normalize_slots(slots_raw),
        min_quantity=quantity,
        min_duration_hours=duration,
    )

    if output_json:
        from flow.cli.utils.json_output import print_json

        print_json({"reserved": False, "slots": slots})
        return

    if not slots:
        console.print(
            "No self-serve availability found within the next 24 hours. "
            "Please reach out to the Flow team."
        )
        return

    recommended = slots[0]
    console.print("Earliest available slot:")
    from flow.cli.ui.presentation.reservations_renderer import ReservationsRenderer

    ReservationsRenderer(console).render_availability_table(
        [recommended], local_time=local_time, show_price=False, title=None
    )

    try:
        if click.confirm("Reserve this slot?", default=True):
            start_iso = ReservationsService.isoformat_utc_z(recommended.get("start_time_utc"))
            task = service.create_reservation(
                instance_type=instance_type,
                region=region,
                quantity=quantity,
                start_time_iso_z=start_iso,
                duration_hours=duration,
                name=name or f"reservation-{instance_type}",
                ssh_keys=ssh_keys,
            )
            _print_reservation_created(task)
            return
    except click.Abort:
        pass
    except Exception as e:  # noqa: BLE001
        cmd.handle_error(e)
        return
    console.print("Reservation not created.")


class ReserveCommand(BaseCommand):
    """Manage reservations (availability, create, list, show, extend, now)."""

    @property
    def name(self) -> str:
        return "reserve"

    @property
    def help(self) -> str:
        return "Reserve capacity (create/list/show)"

    def get_command(self) -> click.Command:
        from flow.cli.completion import (
            complete_instance_types as _complete_instance_types,
        )

        @click.group(name=self.name, help=self.help, invoke_without_command=True)
        @click.pass_context
        @cli_error_guard(self)
        def grp(ctx):
            """Group entry point for the reserve commands.

            Sets up a shared Flow client on the Click context and, when run
            as `flow reserve` in a TTY without a subcommand, launches the
            interactive wizard.
            """
            # Initialize and cache a single client per invocation for reuse
            try:
                ctx.ensure_object(dict)
                if (ctx.obj or {}).get("flow_client") is None:
                    ctx.obj["flow_client"] = sdk_factory.create_client(auto_init=True)
            except Exception:  # noqa: BLE001
                ctx.ensure_object(dict)
                ctx.obj["flow_client"] = None

            no_sub = ctx.invoked_subcommand is None
            is_tty = _is_interactive_tty()

            if no_sub and is_tty:
                try:
                    from flow.cli.ui.components.reserve_wizard import ReserveWizard as _Wizard

                    flow = _get_flow_client(ctx)
                    _Wizard(console).run(flow)
                    return
                except KeyboardInterrupt:
                    return
                except Exception as e:  # noqa: BLE001
                    console.print(f"[error]Wizard error:[/error] {e}")
            if no_sub and not is_tty:
                console.print("Usage: flow reserve [availability|create|list|show|now]")
                console.print(
                    "Example: flow reserve availability -i h100 -r us-central1-b -d 4 --format json"
                )

        @grp.command(name="availability", help="Get availability slots for reservations")
        @click.option(
            "-i",
            "--instance-type",
            "--type",
            "instance_type",
            required=False,
            help="Instance type (e.g., 1xh100, 8xh100); when omitted, use selector in TTY (Phase 2)",
            shell_complete=_complete_instance_types,
        )
        @click.option(
            "-r", "--region", required=False, help="Region/zone; defaults from config when omitted"
        )
        @click.option(
            "-s",
            "--earliest",
            "--from",
            "earliest_start_time",
            required=False,
            help="Earliest start (ISO8601 or relative: now, +2h); default: now",
        )
        @click.option(
            "-e",
            "--latest",
            "latest_end_time",
            required=False,
            help="Latest end (ISO8601); default: earliest + duration",
        )
        @click.option(
            "-q",
            "--qty",
            "quantity",
            type=int,
            default=None,
            help="Requested instance quantity (default 1)",
        )
        @click.option(
            "-d",
            "--duration",
            "--for",
            type=int,
            default=None,
            help="Requested duration in hours (default 8)",
        )
        @click.option(
            "--mode",
            type=click.Choice(["slots", "latest_end_time", "check"], case_sensitive=False),
            default=None,
            help=(
                "Availability mode (provider-dependent). Defaults to 'slots' for TTY/table output "
                "and 'latest_end_time' for JSON output"
            ),
        )
        @click.option("--json", "output_json", is_flag=True, help="Output JSON for automation")
        @click.option(
            "--format",
            "format_",
            type=click.Choice(["table", "json"], case_sensitive=False),
            default=None,
            help="Output format (TTY default: table; non-TTY default: json)",
        )
        @click.option("--local-time", is_flag=True, help="Display local time in tables")
        @click.option(
            "--show-price", is_flag=True, help="Show estimated price (heuristic)", hidden=True
        )
        @click.option(
            "--grid", is_flag=True, help="Show compact daily grid under table", hidden=True
        )
        @click.option(
            "--raw",
            is_flag=True,
            help="Show raw provider slots (no aggregation/dedup)",
        )
        @click.pass_context
        def availability_cmd(
            ctx,
            instance_type: str,
            region: str,
            earliest_start_time: str,
            latest_end_time: str,
            quantity: int | None,
            duration: int | None,
            mode: str | None,
            output_json: bool,
            format_: str | None,
            local_time: bool,
            show_price: bool,
            grid: bool,
            raw: bool,
        ) -> None:
            """Display availability slots for reservations."""
            flow = _get_flow_client(ctx)

            if not _resolve_project(flow):
                console.print(
                    "Project is required for availability. Run 'flow setup' or set MITHRIL_PROJECT."
                )
                return

            # Default duration (hours)
            duration = int(duration) if duration is not None else 8
            # Parse earliest (default now)
            parsed_earliest = ReservationsService.parse_time_expr(earliest_start_time or "now")
            # Compute latest if omitted
            latest_end_time = latest_end_time or ReservationsService.parse_time_expr(
                parsed_earliest
            )
            try:
                st = _dt.fromisoformat(parsed_earliest.replace("Z", "+00:00"))
                if not latest_end_time or latest_end_time == parsed_earliest:
                    latest_end_time = (st + _td(hours=duration)).replace(
                        microsecond=0
                    ).isoformat() + "Z"
            except (ValueError, AttributeError):
                pass

            # Normalize format/output modes
            is_tty = _is_interactive_tty()
            if output_json or str(format_ or "").lower() == "json":
                output_json = True
            elif format_ is None:
                output_json = not is_tty

            # Local time default: true in TTY unless JSON output
            if not output_json and not local_time and is_tty:
                local_time = True

            if not instance_type:
                console.print("Instance type is required. Pass -i/--instance-type (e.g., 1xh100).")
                return
            if not region:
                region = _resolve_region(flow)
            if not region:
                console.print(
                    "Region is required. Set a default with 'flow setup' or pass -r/--region."
                )
                return

            if mode is None:
                mode = "slots" if (not output_json and is_tty) else "latest_end_time"

            try:
                handle_availability_flow(
                    console,
                    flow_client=flow,
                    instance_type=instance_type,
                    region=region,
                    earliest_start_time=parsed_earliest,
                    latest_end_time=latest_end_time,
                    quantity=quantity,
                    duration=duration,
                    mode=mode,
                    output_json=output_json,
                    local_time=local_time,
                    show_price=show_price,
                    grid=grid,
                    aggregate=(not raw),
                )
            except Exception as e:  # noqa: BLE001
                self.handle_error(e)
                return

        @grp.command(name="create", help="Create a new reservation")
        @click.option(
            "--instance-type",
            "--type",
            "instance_type",
            required=True,
            shell_complete=_complete_instance_types,
        )
        @click.option("--region", required=False)
        @click.option("--quantity", type=int, default=1)
        @click.option(
            "--start",
            "start_time",
            required=True,
            help="ISO8601 UTC or relative time (e.g., +2h, +30m, now)",
        )
        @click.option("--duration", "duration_hours", type=int, required=True)
        @click.option("--name", default=None)
        @click.option("--ssh-key", "ssh_keys", multiple=True)
        @click.option(
            "--with-slurm",
            is_flag=True,
            help="Provision Slurm controller/workers for this reservation",
        )
        @click.option(
            "--slurm-version", default=None, help="Requested Slurm version (e.g., 25.05.1)"
        )
        @click.option(
            "--format",
            "format_",
            type=click.Choice(["table", "json"], case_sensitive=False),
            default="table",
            show_default=True,
            help="Output format",
        )
        @click.option(
            "--json", "output_json", is_flag=True, help="Output JSON (alias for --format json)"
        )
        @click.option(
            "--yes",
            "-y",
            "skip_confirm",
            is_flag=True,
            help="Skip interactive confirmation (commits to the reservation)",
        )
        @click.pass_context
        def create(
            ctx,
            instance_type: str,
            region: str | None,
            quantity: int,
            start_time: str,
            duration_hours: int,
            name: str | None,
            ssh_keys: tuple[str, ...],
            with_slurm: bool,
            slurm_version: str | None,
            format_: str,
            output_json: bool,
            skip_confirm: bool,
        ):
            """Create a reservation for a time window."""
            try:
                start_iso = ReservationsService.isoformat_utc_z(
                    ReservationsService.parse_time_expr(start_time)
                )
            except (ValueError, TypeError) as e:
                self.handle_error(e)
                return

            flow = _get_flow_client(ctx)
            service = ReservationsService(flow)
            if not service.supports_reservations():
                console.print(
                    "Reservations are not supported by the current provider (demo/mock mode)."
                )
                self.show_next_actions(
                    [
                        "Switch provider: flow setup --provider mithril",
                        "Create a reservation: flow reserve create --instance-type 1xh100 --start <ISO> --duration <h>",
                    ]
                )
                return

            env: dict[str, str] | None = None
            if with_slurm:
                env = {"_FLOW_WITH_SLURM": "1"}
                if slurm_version:
                    env["_FLOW_SLURM_VERSION"] = slurm_version

            # Confirm before billing the user. Skip in JSON mode (automation)
            # and when --yes is set; otherwise show the commit summary and ask.
            if not output_json and not skip_confirm:
                summary_parts = [
                    f"{quantity}×{instance_type}",
                    f"{duration_hours}h",
                    f"start {start_iso}",
                ]
                if region:
                    summary_parts.append(f"region {region}")
                if with_slurm:
                    summary_parts.append("with slurm")
                console.print(f"[bold]Reservation commit:[/bold] {' · '.join(summary_parts)}")
                console.print(
                    "[dim]This commits capacity and incurs charges for the full window.[/dim]"
                )
                if not click.confirm("Proceed with reservation?", default=True):
                    console.print("[warning]Cancelled.[/warning]")
                    return

            task = service.create_reservation(
                instance_type=instance_type,
                region=region,
                quantity=quantity,
                start_time_iso_z=start_iso,
                duration_hours=duration_hours,
                name=name,
                ssh_keys=list(ssh_keys or ()),
                env=env,
            )

            rid = _extract_reservation_id(task)
            ReservationsService.telemetry(
                "reservations.create",
                {
                    "instance_type": instance_type,
                    "region": region,
                    "quantity": quantity,
                    "duration_hours": duration_hours,
                    "with_slurm": with_slurm,
                    "slurm_version": slurm_version,
                    "reservation_id": rid,
                },
            )
            fmt = "json" if output_json else (format_ or "table")
            if fmt == "json":
                from flow.cli.utils.json_output import print_json

                print_json({"reservation_id": rid, "task_id": task.task_id})
                return
            console.print(f"Created reservation: [accent]{rid}[/accent]")
            self.show_next_actions(
                [
                    "List reservations: [accent]flow reserve list[/accent]",
                    f"Show details: [accent]flow reserve show {rid}[/accent]",
                    "Monitor tasks: [accent]flow status --all[/accent]",
                ]
            )

        @grp.command(name="list", help="List reservations")
        @click.option(
            "--json", "output_json", is_flag=True, help="Output JSON (alias for --format json)"
        )
        @click.option("--slurm-only", is_flag=True, help="Show only Slurm-enabled reservations")
        @click.option(
            "--status",
            type=click.Choice(["scheduled", "active", "expired", "failed"], case_sensitive=False),
            default=None,
            help="Filter by status",
        )
        @click.option("--region", type=str, default=None, help="Filter by region")
        @click.option(
            "-i",
            "--instance-type",
            "--type",
            "instance_type",
            type=str,
            default=None,
            help="Filter by instance type",
            shell_complete=_complete_instance_types,
        )
        @click.option(
            "--format",
            "format_",
            type=click.Choice(["table", "json", "csv", "yaml"], case_sensitive=False),
            default="table",
            show_default=True,
            help="Output format",
        )
        @click.option(
            "--columns", type=str, default=None, help="Comma-separated columns for table output"
        )
        @click.option(
            "--local-time", is_flag=True, help="Display local time instead of UTC in tables"
        )
        @click.pass_context
        def list_cmd(
            ctx,
            output_json: bool,
            slurm_only: bool,
            status: str | None,
            region: str | None,
            instance_type: str | None,
            format_: str,
            columns: str | None,
            local_time: bool,
        ):
            """List reservations with optional filters and formats."""
            flow = _get_flow_client(ctx)
            try:
                cols = [c.strip() for c in columns.split(",") if c.strip()] if columns else None
                handle_list_flow(
                    console,
                    flow_client=flow,
                    output_json=output_json,
                    slurm_only=slurm_only,
                    status=status,
                    region=region,
                    instance_type=instance_type,
                    format_=format_,
                    columns=cols,
                    local_time=local_time,
                )
            except Exception as e:  # noqa: BLE001
                self.handle_error(e)
                return

        @grp.command(name="show", help="Show reservation details")
        @click.argument("reservation_id")
        @click.option(
            "--json", "output_json", is_flag=True, help="Output JSON (alias for --format json)"
        )
        @click.option(
            "--format",
            "format_",
            type=click.Choice(["table", "json"], case_sensitive=False),
            default="table",
            show_default=True,
            help="Output format",
        )
        @click.option(
            "--local-time", is_flag=True, help="Display local time instead of UTC in tables"
        )
        @click.option("--watch", is_flag=True, help="Live update the reservation details")
        @click.option(
            "--refresh-rate",
            type=float,
            default=5.0,
            show_default=True,
            help="Refresh interval for --watch (seconds)",
        )
        @click.pass_context
        def show_cmd(
            ctx,
            reservation_id: str,
            output_json: bool,
            format_: str,
            local_time: bool,
            watch: bool,
            refresh_rate: float,
        ):
            """Show details for a reservation, optionally live-updating."""
            flow = _get_flow_client(ctx)
            service = ReservationsService(flow)
            if not service.supports_reservations():
                console.print(
                    "Reservations are not supported by the current provider (demo/mock mode)."
                )
                return
            # Resolve name -> FID when the identifier is not already a FID
            if not reservation_id.startswith("res_"):
                try:
                    provider_ctx = self._get_provider_context(ctx)
                    api = provider_ctx.api
                    project_id: str | None = None
                    try:
                        project_id = provider_ctx.get_project_id()
                    except Exception:  # noqa: BLE001
                        pass
                    resolved = self._resolve_reservation(api, reservation_id, project_id=project_id)
                    reservation_id = resolved["fid"]
                except click.ClickException:
                    raise
                except Exception as e:  # noqa: BLE001
                    self.handle_error(e)
                    return

            try:
                res = flow.get_reservation(reservation_id)
            except Exception as e:  # noqa: BLE001
                self.handle_error(e)
                return
            fmt = "json" if output_json else (format_ or "table")
            if fmt == "json":
                from flow.cli.utils.json_output import print_json, reservation_to_json

                print_json(reservation_to_json(res))
                return
            # Telemetry (best-effort)
            ReservationsService.telemetry(
                "reservations.show",
                {
                    "reservation_id": reservation_id,
                    "format": fmt,
                    "watch": watch,
                    "refresh_rate": refresh_rate,
                },
            )
            if watch:
                try:
                    from flow.cli.ui.presentation.reservations_view import (
                        render_reservation_live,
                    )

                    def _fetch_once():
                        try:
                            return flow.get_reservation(reservation_id)
                        except Exception:  # noqa: BLE001
                            return res

                    render_reservation_live(
                        console,
                        fetch_once=_fetch_once,
                        local_time=local_time,
                        refresh_rate=refresh_rate,
                    )
                except KeyboardInterrupt:
                    return
                except Exception:  # noqa: BLE001
                    render_reservation_details(
                        console, res, local_time=local_time, title="Reservation"
                    )
            else:
                render_reservation_details(console, res, local_time=local_time, title="Reservation")
                self.show_next_actions(
                    [
                        "List reservations: [accent]flow reserve list[/accent]",
                        "Monitor capacity: [accent]flow alloc --watch[/accent]",
                    ]
                )

        @grp.command(
            name="extension-availability", help="Show extension availability for a reservation"
        )
        @click.argument("reservation_id")
        @click.option("--json", "output_json", is_flag=True, help="Output JSON for automation")
        @click.option("--local-time", is_flag=True, help="Display local time in tables")
        @click.pass_context
        def extension_availability_cmd(
            ctx,
            reservation_id: str,
            output_json: bool,
            local_time: bool,
        ) -> None:
            flow = _get_flow_client(ctx)
            try:
                slots = flow.reservation_extension_availability(reservation_id)
            except Exception as e:  # noqa: BLE001
                self.handle_error(e)
                return
            if output_json:
                import json as _json

                console.print(_json.dumps(slots))
                return
            if not slots:
                console.print("No extension availability or provider unsupported.")
                return
            from flow.cli.ui.presentation.reservations_view import render_availability

            render_availability(
                console,
                slots,
                local_time=local_time,
                show_price=False,
                title="Extension Availability",
                grid=False,
            )

        @grp.command(name="extend", help="Extend a reservation's end time")
        @click.argument("reservation_id")
        @click.option(
            "--end-time",
            "end_time",
            required=True,
            help="New end time (ISO8601 or relative: +2h, +30m, now)",
        )
        @click.option("--json", "output_json", is_flag=True, help="Output JSON for automation")
        @click.pass_context
        def extend_cmd(
            ctx,
            reservation_id: str,
            end_time: str,
            output_json: bool,
        ) -> None:
            """Extend a reservation's end time."""
            flow = _get_flow_client(ctx)
            try:
                end_iso = ReservationsService.isoformat_utc_z(
                    ReservationsService.parse_time_expr(end_time)
                )
            except (ValueError, TypeError) as e:
                self.handle_error(e)
                return
            try:
                res = flow.extend_reservation(reservation_id, end_iso)
            except Exception as e:  # noqa: BLE001
                self.handle_error(e)
                return
            if output_json:
                from flow.cli.utils.json_output import print_json

                print_json({"ok": bool(res is not None), "end_time": end_iso})
                return
            if res is None:
                console.print("Provider does not support reservation extension or request failed.")
                return
            console.print(f"Requested extension to: [accent]{end_iso}[/accent]")

        @grp.command(name="now", help="Reserve capacity starting now with fast fallback")
        @click.option(
            "-i",
            "--instance-type",
            "--type",
            "instance_type",
            required=False,
            shell_complete=_complete_instance_types,
        )
        @click.option("-r", "--region", required=False)
        @click.option("-d", "--duration", type=int, default=None, help="Duration hours (default 8)")
        @click.option(
            "-q", "--qty", "quantity", type=int, default=None, help="Quantity (default 1)"
        )
        @click.option("--name", type=str, default=None, help="Reservation name")
        @click.option(
            "--ssh-key", "ssh_keys", multiple=True, help="SSH key name or path (repeatable)"
        )
        @click.option("--json", "output_json", is_flag=True, help="Output JSON for automation")
        @click.option("--local-time", is_flag=True, help="Display local time")
        @click.pass_context
        def reserve_now(
            ctx,
            instance_type: str | None,
            region: str | None,
            duration: int | None,
            quantity: int | None,
            name: str | None,
            ssh_keys: tuple[str, ...],
            output_json: bool,
            local_time: bool,
        ) -> None:
            """Check immediate availability; reserve now or suggest nearest slot."""
            flow = _get_flow_client(ctx)

            if not _resolve_project(flow):
                console.print("Project is required. Run 'flow setup' or set MITHRIL_PROJECT.")
                return

            duration = int(duration) if duration is not None else 8
            quantity = int(quantity) if quantity is not None else 1
            if not instance_type:
                console.print("Instance type is required. Pass -i/--instance-type (e.g., 1xh100).")
                return
            if not region:
                region = _resolve_region(flow)
            if not region:
                console.print(
                    "Region is required. Set a default with 'flow setup' or pass -r/--region."
                )
                return

            if not output_json and not local_time and _is_interactive_tty():
                local_time = True

            service = ReservationsService(flow)
            now_iso = ReservationsService.isoformat_utc_z(_dt.now(_tz.utc))

            # Try immediate slot
            immediate = _find_immediate_slot(
                service,
                instance_type=instance_type,
                region=region,
                now_iso=now_iso,
                duration=duration,
                quantity=quantity,
            )

            if immediate is not None:
                try:
                    task = service.create_reservation(
                        instance_type=instance_type,
                        region=region,
                        quantity=quantity,
                        start_time_iso_z=now_iso,
                        duration_hours=duration,
                        name=name or f"reservation-{instance_type}",
                        ssh_keys=list(ssh_keys or ()),
                    )
                except Exception as e:  # noqa: BLE001
                    self.handle_error(e)
                    return
                if output_json:
                    from flow.cli.utils.json_output import print_json

                    rid = _extract_reservation_id(task)
                    print_json({"reserved": True, "reservation_id": rid, "task_id": task.task_id})
                    return
                _print_reservation_created(task)
                return

            # Fallback: search next 24 hours
            _offer_fallback_slot(
                self,
                service,
                instance_type=instance_type,
                region=region,
                now_iso=now_iso,
                quantity=quantity,
                duration=duration,
                name=name,
                ssh_keys=list(ssh_keys or ()),
                output_json=output_json,
                local_time=local_time,
            )

        # ── pause ─────────────────────────────────────────────
        @grp.command(name="pause", help="Pause a reservation to earn pause credits")
        @click.argument("reservation")
        @click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
        @click.option("--json", "output_json", is_flag=True, help="Output as JSON")
        @click.pass_context
        def pause_cmd(
            ctx,
            reservation: str,
            yes: bool,
            output_json: bool,
        ) -> None:
            """Pause a reservation by name or FID.

            Instances must stay paused at least 1 hour to earn pause credit.
            """
            self._execute_pause_resume(
                ctx,
                identifier=reservation,
                pause=True,
                yes=yes,
                output_json=output_json,
            )

        # ── resume ────────────────────────────────────────────
        @grp.command(name="resume", help="Resume a paused reservation")
        @click.argument("reservation")
        @click.option("--json", "output_json", is_flag=True, help="Output as JSON")
        @click.pass_context
        def resume_cmd(
            ctx,
            reservation: str,
            output_json: bool,
        ) -> None:
            """Resume a paused reservation by name or FID.

            Restart may take up to 7 minutes if spot preemption is needed.
            """
            self._execute_pause_resume(
                ctx,
                identifier=reservation,
                pause=False,
                yes=True,
                output_json=output_json,
            )

        return grp

    @staticmethod
    def _get_provider_context(ctx: click.Context) -> Any:
        """Access the Mithril provider context (api + project resolver)."""
        flow = _get_flow_client(ctx)
        provider = flow.provider
        provider_ctx = getattr(provider, "ctx", None) or getattr(provider, "_ctx", None)
        if provider_ctx is None:
            raise click.ClickException(
                "Reservation pause requires the Mithril provider. "
                "Ensure provider is 'mithril' in ~/.flow/config.yaml"
            )
        return provider_ctx

    @staticmethod
    def _resolve_reservation(
        api: Any, identifier: str, project_id: str | None = None
    ) -> dict[str, Any]:
        """Resolve a reservation by FID or name.

        If identifier looks like a FID (starts with ``res_``), fetches directly.
        Otherwise lists reservations and matches by name.

        Args:
            api: MithrilApiClient instance.
            identifier: Reservation FID (``res_xxx``) or human name.
            project_id: Project FID for listing (required for name resolution).

        Returns:
            Raw reservation dict from the API.

        Raises:
            click.ClickException: On no match or ambiguous match.
        """
        # Build params with project for all list calls
        list_params: dict[str, Any] = {}
        if project_id:
            list_params["project"] = project_id

        # Direct FID lookup
        if identifier.startswith("res_"):
            try:
                res = api.get_reservation(identifier)
                if isinstance(res, dict) and "fid" in res:
                    return res
            except Exception:  # noqa: BLE001
                pass
            # Fall through to list-based lookup in case get_reservation
            # doesn't work (some API versions require listing)

        # List non-terminated reservations and match
        try:
            resp = api.list_reservations(list_params)
        except Exception as e:  # noqa: BLE001
            raise click.ClickException(f"Failed to list reservations: {e}")

        all_res: list[dict[str, Any]] = resp if isinstance(resp, list) else resp.get("data", [])
        # Filter out ended/canceled
        active = [r for r in all_res if r.get("status", "").lower() not in ("ended", "canceled")]

        # If identifier is a FID, match directly in the list
        if identifier.startswith("res_"):
            for r in active:
                if r.get("fid") == identifier:
                    return r
            raise click.ClickException(f"Reservation {identifier} not found.")

        # Exact name match (case-insensitive)
        matches = [r for r in active if (r.get("name") or "").lower() == identifier.lower()]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            fids = ", ".join(m["fid"] for m in matches)
            raise click.ClickException(
                f"Multiple reservations match {identifier!r}: {fids}. "
                "Use the reservation FID instead."
            )

        # Partial / substring match
        partials = [r for r in active if identifier.lower() in (r.get("name") or "").lower()]
        if len(partials) == 1:
            return partials[0]
        if len(partials) > 1:
            names = ", ".join(f"{p.get('name', p['fid'])} ({p['fid']})" for p in partials)
            raise click.ClickException(
                f"Ambiguous: {identifier!r} matches multiple reservations: {names}"
            )

        raise click.ClickException(
            f"No reservation found matching {identifier!r}. "
            "Run 'flow reserve list' to see active reservations."
        )

    def _execute_pause_resume(
        self,
        ctx: click.Context,
        *,
        identifier: str,
        pause: bool,
        yes: bool,
        output_json: bool,
    ) -> None:
        """Shared implementation for pause and resume subcommands."""
        import json as _json

        from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress

        action = "pause" if pause else "resume"
        action_past = "Paused" if pause else "Resumed"

        try:
            provider_ctx = self._get_provider_context(ctx)
            api = provider_ctx.api
        except Exception as e:  # noqa: BLE001
            self.handle_error(e)
            return

        # Resolve project for list-based lookups
        project_id: str | None = None
        try:
            project_id = provider_ctx.get_project_id()
        except Exception:  # noqa: BLE001
            pass

        # Resolve identifier to a reservation dict (supports name or FID)
        try:
            with AnimatedEllipsisProgress(
                console, "Looking up reservation", transient=True, start_immediately=True
            ):
                res = self._resolve_reservation(api, identifier, project_id=project_id)
        except click.ClickException:
            raise
        except Exception as e:  # noqa: BLE001
            self.handle_error(e)
            return

        reservation_id = res["fid"]
        res_name = res.get("name") or reservation_id
        res_status = res.get("status", "unknown")

        if not output_json and not yes:
            credit_note = (
                "\n  [dim]Instances must stay paused at least 1 hour for credit.[/dim]"
                if pause
                else "\n  [dim]Restart may take up to 7 minutes.[/dim]"
            )
            console.print(
                f"\n  Reservation: [bold]{res_name}[/bold]"
                f"\n  ID:          {reservation_id}"
                f"\n  Status:      {res_status}"
                f"\n  Action:      {action}{credit_note}\n"
            )
            if not click.confirm("  Proceed?", default=True):
                console.print("[dim]Cancelled[/dim]")
                return

        try:
            with AnimatedEllipsisProgress(
                console,
                f"{'Pausing' if pause else 'Resuming'} reservation",
                transient=True,
                start_immediately=True,
            ):
                result = api.patch_reservation(reservation_id, {"paused": pause})
        except Exception as e:  # noqa: BLE001
            self.handle_error(e)
            return

        if output_json:
            click.echo(_json.dumps(result if isinstance(result, dict) else {"ok": True}, indent=2))
            return

        new_status = result.get("status", "unknown") if isinstance(result, dict) else "unknown"
        console.print(
            f"\n  [bold green]{action_past}[/bold green] [bold]{res_name}[/bold]"
            f"  (status: {new_status})\n"
        )

        if pause:
            self.show_next_actions(
                [
                    f"Resume: [accent]flow reserve resume {reservation_id}[/accent]",
                    f"Show details: [accent]flow reserve show {reservation_id}[/accent]",
                ]
            )


command = ReserveCommand()
