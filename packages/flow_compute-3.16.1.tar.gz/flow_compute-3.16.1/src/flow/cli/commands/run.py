"""Run command alias with task-oriented help."""

from __future__ import annotations

import click

from flow.cli.commands.base import BaseCommand


class RunCommand(BaseCommand):
    """Expose the submit execution path as ``flow run`` with matching help."""

    @property
    def name(self) -> str:
        return "run"

    @property
    def help(self) -> str:
        return "Run a command or task from YAML configuration"

    def get_command(self) -> click.Command:
        from flow.cli.commands.submit import command as submit_command

        base_cmd = submit_command.get_command()
        help_text = """Run a command or task from YAML configuration

\b
Examples:
  flow run -- nvidia-smi                 # Quick GPU test
  flow run -i h100 -- python train.py    # Run a script directly
  flow run <config.yaml>                 # Run from config file
  flow run <config.yaml> --watch         # Watch progress interactively
  flow run --port 8080 -- python -m http.server 8080  # Expose a service

\b
Notes:
  - Provide the command positionally. Use "--" to disambiguate from files.
  - Use --port (repeatable) to expose high ports (>=1024) on the instance's public IP
  - No runtime limit is applied by default. To auto-terminate, set max_run_time_hours in your TaskConfig
"""

        @click.command(
            name=self.name,
            help=help_text,
            context_settings=getattr(base_cmd, "context_settings", None),
            params=getattr(base_cmd, "params", None),
            epilog=getattr(base_cmd, "epilog", None),
            short_help=self.help,
            add_help_option=getattr(base_cmd, "add_help_option", True),
        )
        @click.pass_context
        def run(ctx: click.Context, **kwargs) -> None:
            ctx.invoke(base_cmd, **kwargs)

        return run


command = RunCommand()
