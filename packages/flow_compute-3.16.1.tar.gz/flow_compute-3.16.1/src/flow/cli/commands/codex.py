"""Install Codex skills for flow-compute globally.

Copies bundled skill definitions into ``$CODEX_HOME/skills`` or
``~/.codex/skills`` so Codex can use them across projects.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

import click
from rich.console import Console

from flow.cli.commands.base import BaseCommand, console
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.theme_manager import theme_manager


def get_bundled_dir() -> Path:
    """Return the path to bundled Codex data shipped with the package."""
    from flow.data.codex import get_data_dir

    return get_data_dir()


def get_codex_skills_dir(target_home: Path) -> Path:
    """Return Codex's skill installation directory."""
    codex_home = os.environ.get("CODEX_HOME", "").strip()
    if codex_home:
        return Path(codex_home).expanduser() / "skills"
    return target_home / ".codex" / "skills"


def _copy_skill_dir(src_dir: Path, dst_dir: Path) -> None:
    """Copy one skill directory while ignoring transient Python artifacts."""

    def _ignore(_directory: str, names: list[str]) -> set[str]:
        return {
            name
            for name in names
            if name == "__pycache__" or name == ".DS_Store" or name.endswith(".pyc")
        }

    shutil.copytree(src_dir, dst_dir, dirs_exist_ok=True, ignore=_ignore)
    for script in (dst_dir / "scripts").glob("*"):
        if script.is_file() and script.suffix in {".py", ".sh"}:
            script.chmod(script.stat().st_mode | 0o111)


def install_skills(target_home: Path, bundled_dir: Path) -> list[str]:
    """Copy bundled skills into the Codex skills directory.

    Returns installed skill names.
    """
    skills_src = bundled_dir / "skills"
    skills_dst = get_codex_skills_dir(target_home)
    installed: list[str] = []

    if not skills_src.exists():
        return installed

    skills_dst.mkdir(parents=True, exist_ok=True)
    for skill_dir in sorted(skills_src.iterdir()):
        if not skill_dir.is_dir():
            continue
        skill_file = skill_dir / "SKILL.md"
        if not skill_file.exists():
            continue

        _copy_skill_dir(skill_dir, skills_dst / skill_dir.name)
        installed.append(skill_dir.name)

    return installed


def install_codex_assets(target_home: Path, out: Console | None = None) -> None:
    """Install Codex skills globally, printing results to console."""
    out = out or console
    bundled_dir = get_bundled_dir()
    skills_dst = get_codex_skills_dir(target_home)
    success_color = theme_manager.get_color("success")
    muted = theme_manager.get_color("muted")

    installed = install_skills(target_home, bundled_dir)

    if installed:
        out.print(
            f"\n[{success_color}]✓[/{success_color}] Installed {len(installed)} "
            f"Codex skills into {skills_dst}"
        )
        for name in installed:
            out.print(f"  [{muted}]{name}[/{muted}]")
        out.print(f"\n[{muted}]Flow skills are now available in Codex[/{muted}]")
    else:
        out.print("[warning]No Codex skills found to install[/warning]")


class CodexCommand(BaseCommand):
    """Install Codex skills for flow-compute."""

    @property
    def name(self) -> str:
        return "codex"

    @property
    def help(self) -> str:
        return "Install Codex skills globally"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option(
            "--list", "list_only", is_flag=True, help="List bundled skills without installing"
        )
        @cli_error_guard(self)
        def codex(list_only: bool) -> None:
            """Install Codex skills globally.

            \b
            Examples:
                flow codex              # Install skills globally
                flow codex --list       # Show available skills
            """
            if list_only:
                bundled_dir = get_bundled_dir()
                muted = theme_manager.get_color("muted")
                skills_dir = bundled_dir / "skills"
                if not skills_dir.exists():
                    console.print("[warning]No bundled Codex skills found[/warning]")
                    return

                console.print("\n[bold]Bundled Codex skills[/bold]\n")
                for skill_dir in sorted(skills_dir.iterdir()):
                    if not skill_dir.is_dir():
                        continue
                    skill_file = skill_dir / "SKILL.md"
                    if not skill_file.exists():
                        continue

                    content = skill_file.read_text()
                    name = skill_dir.name
                    desc = ""
                    if content.startswith("---"):
                        end = content.find("---", 3)
                        front_matter = content[3:end] if end > 3 else content[3:]
                        for line in front_matter.split("\n"):
                            if line.startswith("description:"):
                                desc = line.split(":", 1)[1].strip()
                                break

                    console.print(f"  [accent]{name:<30}[/accent] [{muted}]{desc}[/{muted}]")

                console.print(f"\n[{muted}]Install with: flow codex[/{muted}]")
                return

            install_codex_assets(Path.home(), console)

        return codex


command = CodexCommand()
