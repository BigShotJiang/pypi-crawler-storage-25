"""Setup command for Flow SDK configuration.

Supports both interactive wizard and direct configuration via flags.

Examples:
    Interactive setup:
        $ flow setup

    Direct configuration:
        $ flow setup --provider mithril --api-key fkey_xxx --project myproject

    Dry run to preview:
        $ flow setup --provider mithril --dry-run
"""

import logging
from pathlib import Path

import click
import yaml
from rich.markup import escape

from flow.cli.commands.base import BaseCommand
from flow.cli.utils.config_validator import ConfigValidator
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.lazy_imports import import_attr as _import_attr
from flow.cli.utils.theme_manager import theme_manager
from flow.core.cloud_detection import detect_all_clouds
from flow.core.setup_wizard import SetupPipeline
from flow.sdk.helpers.masking import mask_api_key
from flow.sdk.setup import get_adapter as _get_adapter
from flow.sdk.setup import list_providers as _list_providers
from flow.sdk.setup import register_providers as _register_providers
from flow.utils.parsing import parse_bool_env

logger = logging.getLogger(__name__)

console = theme_manager.create_console()

SETUP_NEXT_ACTIONS: tuple[str, ...] = (
    "Run GPU check: [accent]flow example gpu-test[/accent] [dim](confirms before launch)[/dim]",
    "Check health: [accent]flow health[/accent]",
    "Guided first GPU run: [accent]flow tutorial[/accent]",
)


def render_setup_next_actions(target_console=None) -> None:
    """Render the canonical post-setup actions."""
    from flow.cli.ui.presentation.next_steps import render_next_steps_panel

    render_next_steps_panel(
        target_console or console,
        SETUP_NEXT_ACTIONS,
        title="Next steps",
        max_items=len(SETUP_NEXT_ACTIONS),
    )


def _load_existing_api_key() -> str | None:
    """Load existing API key from config if available."""
    ConfigLoader = _import_attr("flow.application.config.loader", "ConfigLoader", default=None)
    if ConfigLoader:
        loader = ConfigLoader()
        sources = loader.load_all_sources()
        existing_api_key = sources.api_key
        if existing_api_key and not existing_api_key.startswith("YOUR_"):
            return existing_api_key
    return None


def _install_shell_completion() -> None:
    """Install shell completion if not already installed (best effort).

    Kept in the CLI layer so the setup pipeline stays free of CLI
    dependencies; ``core_is_framework_agnostic`` forbids core from
    importing ``flow.cli``.
    """
    try:
        from flow.cli.completion.shell_manager import ShellCompletionManager

        ShellCompletionManager().install_if_missing()
    except Exception:  # noqa: BLE001
        pass


def _finalize_environment_marker(environment: str) -> None:
    """Write the current-environment marker after a successful setup run.

    Kept at the CLI layer rather than inside ``SetupPipeline`` so the
    pipeline doesn't transitively drag ``flow.application.config`` (and
    its provider-specific side effects) into ``flow.core``.
    """
    from flow.application.config.config import _set_current_environment

    _set_current_environment(environment)


def _resolve_provider_for_setup(provider: str | None) -> str | None:
    """Return the provider to run setup against, or None to cancel.

    Resolution order:
      1. Explicit ``provider`` argument (validated against registry).
      2. Provider recorded in the user's existing config.
      3. Interactive backend selection menu (mithril vs. BYO cloud).

    Returns the resolved provider name (e.g. ``"mithril"``) or ``None``
    if the user cancelled the backend selection. ``"cloud"`` is a
    special sentinel handled by the caller.
    """
    if provider:
        if not _get_adapter(provider):
            available = _list_providers()
            if not available:
                raise RuntimeError("Unexpected error: no providers available.")
            console.print(
                f"[error]Error:[/error] Unknown or unavailable provider: {escape(str(provider))}"
            )
            console.print(f"\n[dim]Available providers:[/dim] {', '.join(available)}")
            return None
        return provider

    # Consult existing config for a previously-chosen provider.
    try:
        ConfigLoader = _import_attr("flow.application.config.loader", "ConfigLoader", default=None)
        loader = ConfigLoader() if ConfigLoader else None
        if loader:
            resolved = loader.load_all_sources().provider or None
        else:
            resolved = None
    except Exception:  # noqa: BLE001
        resolved = None

    # Mock adapter is demo-only; treat as unresolved unless explicitly enabled.
    if (resolved or "").strip().lower() == "mock" and not parse_bool_env(
        "FLOW_ENABLE_DEMO_ADAPTER"
    ):
        resolved = None

    if resolved:
        return resolved

    from flow.core.setup_wizard.menu_selector import interactive_menu_select

    backend_options = [
        ("mithril", "Mithril (recommended)", "Managed multi-cloud GPU platform"),
        (
            "cloud",
            "Your cloud account (AWS, GCP, Azure)",
            "Use your own cloud credentials directly",
        ),
    ]
    backend = interactive_menu_select(
        backend_options,
        title="Select your compute backend",
        default_index=0,
        breadcrumbs=["Flow Setup"],
    )
    return backend


def _build_adapter(provider: str, environment: str):
    """Instantiate a provider adapter with registry-owned environment defaults."""
    return _get_adapter(provider, environment=environment)


def run_setup_wizard(provider: str | None = None, environment: str = "production") -> bool:
    """Run the setup wizard for the resolved provider.

    Thin shim over :class:`SetupPipeline`; kept for call-site compatibility
    (``tutorial.py``, :func:`prompt_and_run_setup`).

    Args:
        provider: Provider name to use, or ``None`` to prompt interactively.
        environment: Environment to configure (production or staging).
    """
    _register_providers()

    resolved = _resolve_provider_for_setup(provider)
    if resolved is None:
        return False
    if resolved == "cloud":
        return run_cloud_setup()

    adapter = _build_adapter(resolved, environment)
    if not adapter:
        console.print(f"[error]Error: Provider not available: {resolved}[/error]")
        return False

    pipeline = SetupPipeline(adapter, console=console, environment=environment)
    try:
        result = pipeline.run(interactive=True)
    except Exception as e:
        console.print(f"\n\n[error]Setup error:[/error] {escape(str(e))}")
        logger.exception("Setup wizard error")
        return False
    if result.success:
        _finalize_environment_marker(environment)
        _install_shell_completion()
    return result.success


def run_cloud_setup() -> bool:
    """Run cloud backend setup: detect credentials, select clouds, write config.

    Returns:
        True if configuration was saved successfully, False otherwise.
    """
    from rich.prompt import Confirm

    from flow.application.config.writer import ConfigWriter
    from flow.cli.ui.components.models import SelectionItem
    from flow.cli.ui.components.selector_api import Selector
    from flow.sdk.models import ValidationResult

    success_color = theme_manager.get_color("success")
    error_color = "red"

    # Detect cloud credentials
    console.print("\n  Checking cloud credentials...\n")
    statuses = detect_all_clouds()

    # Display status table
    for status in statuses:
        if status.is_configured:
            indicator = f"[{success_color}]ok[/{success_color}]"
        else:
            indicator = f"[{error_color}]x[/{error_color}]"
        console.print(f"    {indicator}  {status.name:<8} {status.credential_source}")

    # Show setup instructions for unconfigured clouds
    unconfigured = [s for s in statuses if not s.is_configured]
    if unconfigured:
        console.print("")
        for status in unconfigured:
            console.print(f"  To set up {status.name}:")
            for i, (label, command) in enumerate(status.setup_instructions, 1):
                console.print(f"    {i}. {label}")
                console.print(f"       {command}")

    # Check if any clouds are configured
    configured = [s for s in statuses if s.is_configured]
    if not configured:
        console.print(
            "\n  No cloud credentials detected. Set up at least one cloud, "
            "then re-run: [accent]flow setup[/accent]\n"
        )
        return False

    console.print("")

    # Multi-select from configured clouds
    items = [
        SelectionItem(
            value=s.key,
            id=s.key,
            title=s.name,
            subtitle=s.credential_source,
            status="",
        )
        for s in configured
    ]

    selected_clouds = Selector.select_many(
        items=items,
        title="Which clouds do you want to enable?",
        console=console,
    )

    if not selected_clouds:
        console.print("\n  [warning]No clouds selected. Setup cancelled.[/warning]")
        return False

    # Spot instance preference
    use_spot = Confirm.ask(
        "\n  Use spot instances by default? (cheaper, can be interrupted)",
        default=True,
        console=console,
    )

    # Build and write config
    config = {
        "provider": "skypilot",
        "skypilot": {
            "clouds": sorted(selected_clouds),
            "defaults": {
                "use_spot": use_spot,
            },
        },
    }

    writer = ConfigWriter()
    writer.write(config, ValidationResult(is_valid=True))

    # Show completion summary
    cloud_names = [s.name for s in statuses if s.key in selected_clouds]
    console.print(
        f"\n  [{success_color}]Configuration saved to ~/.flow/config.yaml[/{success_color}]"
    )
    console.print(f"  Enabled clouds: {', '.join(cloud_names)}")

    render_setup_next_actions(console)

    try:
        from flow.cli.completion.shell_manager import ShellCompletionManager

        ShellCompletionManager().install_if_missing()
    except Exception:  # noqa: BLE001
        pass

    return True


class SetupCommand(BaseCommand):
    """Setup command implementation."""

    def __init__(self):
        super().__init__()
        self.validator = ConfigValidator()

    @property
    def name(self) -> str:
        return "setup"

    @property
    def help(self) -> str:
        return "Configure credentials and provider settings"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option("--provider", envvar="FLOW_PROVIDER", help="Provider to use")
        @click.option(
            "--environment",
            type=click.Choice(["production", "staging"]),
            default="production",
            help="Environment to configure (production or staging)",
            hidden=True,
        )
        @click.option("--api-key", help="API key for authentication")
        @click.option("--project", help="Project name")
        @click.option("--api-url", help="API endpoint URL")
        @click.option("--dry-run", is_flag=True, help="Show configuration without saving")
        @click.option(
            "--output",
            type=click.Path(dir_okay=False),
            help="Write dry-run YAML to file (with --dry-run)",
        )
        @click.option("--verbose", "-v", is_flag=True, help="Show detailed setup information")
        @click.option("--reset", is_flag=True, help="Reset configuration to start fresh")
        @click.option("--show", is_flag=True, help="Print current resolved configuration and exit")
        @click.option("--yes", is_flag=True, help="Non-interactive; answer yes to prompts (CI)")
        @click.option(
            "--claude-code",
            is_flag=True,
            help="Install the Flow plugin for Claude Code (skips provider setup)",
        )
        @cli_error_guard(self)
        def setup(
            provider: str | None,
            environment: str,
            api_key: str | None,
            project: str | None,
            api_url: str | None,
            dry_run: bool,
            output: str | None,
            verbose: bool,
            reset: bool,
            show: bool,
            yes: bool,
            claude_code: bool,
        ):
            """Configure Flow.

            \b
            Examples:
                flow setup                              # Interactive setup wizard
                flow setup --dry-run                   # Preview configuration
                flow setup --show                      # Show current configuration
                flow setup --provider mithril --api-key xxx  # Direct setup
                flow setup --claude-code               # Install Claude Code plugin

            Use 'flow setup --verbose' for detailed configuration options.
            """
            if claude_code:
                from flow.cli.commands.claude import install_claude_assets

                install_claude_assets(Path.home(), console)
                return

            if verbose and not any([provider, api_key, project, api_url, dry_run]):
                self._print_verbose_help()
                return

            if show:
                self._show_config()
                return

            self._run_setup(
                provider,
                environment,
                api_key,
                project,
                api_url,
                dry_run,
                verbose,
                reset,
                output_path=output,
                assume_yes=yes,
            )

        return setup

    def _show_config(self):
        """Print current resolved configuration and exit."""
        try:
            import importlib

            ConfigManager = importlib.import_module("flow.application.config.manager").ConfigManager
            manager = ConfigManager()
            sources = manager.load_sources()
            from flow.application.config.config import _get_current_environment

            show_dict = {
                "environment": _get_current_environment(),
                "provider": sources.provider,
                "api_key": mask_api_key(sources.api_key),
                "mithril": sources.get_mithril_config(),
            }
            console.print(yaml.safe_dump(show_dict, default_flow_style=False))
        except Exception as e:  # noqa: BLE001
            console.print(f"[error]Error loading configuration:[/error] {escape(str(e))}")
            raise click.exceptions.Exit(1)

    def _print_verbose_help(self) -> None:
        """Print detailed, read-only help for `flow setup --verbose`."""
        from rich.panel import Panel as _Panel

        from flow.cli.utils.icons import flow_icon as _flow_icon

        bullet = "[muted]•[/muted]"
        border = theme_manager.get_color("table.border")

        console.print("")
        console.print(
            _Panel(
                f"[bold]{_flow_icon()} Flow — Detailed Guide[/bold]\n"
                "[muted]Setup configures your environment; it never provisions resources.[/muted]",
                border_style=border,
                expand=False,
            )
        )

        sections = [
            (
                "What This Configures",
                [
                    "Provider (backend)",
                    "API key (verified)",
                    "Default project",
                    "Default SSH key behavior",
                ],
            ),
            (
                "Where It's Saved",
                [
                    "[repr.path]~/.flow/config.yaml[/repr.path]  [muted]— user config[/muted]",
                    "[repr.path]./.flow/config.yaml[/repr.path]  [muted]— project override[/muted]",
                    "[repr.path]~/.flow/env.sh[/repr.path]  [muted]— optional env script (source it)[/muted]",
                ],
            ),
            (
                "SSH Keys",
                [
                    "Recommended: Generate on Mithril",
                    "Saves private key under [repr.path]~/.flow/keys/[/repr.path] with secure permissions",
                    "Private keys are never uploaded (only public keys are uploaded when needed)",
                    "Existing local keys: [repr.path]~/.ssh/[/repr.path] (id_ed25519, id_rsa, id_ecdsa)",
                ],
            ),
            (
                "Configuration & Environment",
                [
                    "Precedence: Environment > Config files > Interactive init",
                    "MITHRIL_API_KEY",
                    "MITHRIL_PROJECT",
                    "MITHRIL_SSH_KEYS  [muted]— comma-separated IDs or paths[/muted]",
                    "MITHRIL_SSH_KEY   [muted]— absolute private key path[/muted]",
                ],
            ),
            (
                "Useful Commands",
                [
                    "List known keys: [accent]flow ssh-key list[/accent]",
                    "Upload a local key: [accent]flow ssh-key upload ~/.ssh/id_ed25519.pub[/accent]",
                    "Inspect a key:      [accent]flow ssh-key info <sshkey_id>[/accent]",
                    "Health check:       [accent]flow health[/accent]",
                    "Claude Code skills: [accent]flow claude[/accent]",
                ],
            ),
        ]

        for title, items in sections:
            console.print("")
            body = "\n".join(f"  {bullet} {item}" for item in items)
            console.print(
                _Panel(
                    body,
                    title=f"[accent][bold]{title}[/bold][/accent]",
                    border_style=border,
                    expand=False,
                )
            )

        console.print("")
        self.show_next_actions(
            [
                "flow health",
                "flow example gpu-test    # GPU check starter",
                "flow tutorial             # guided first GPU run",
                "flow status",
            ]
        )

    def _run_setup(
        self,
        provider: str | None,
        environment: str,
        api_key: str | None,
        project: str | None,
        api_url: str | None,
        dry_run: bool,
        verbose: bool = False,
        reset: bool = False,
        output_path: str | None = None,
        assume_yes: bool = False,
    ):
        """Execute setup command.

        Routes all three entry points (CLI flags, bare ``flow setup`` wizard,
        and ``flow setup --dry-run``) through :class:`SetupPipeline`. Next
        actions run from exactly one place on success so copy stays
        consistent across paths.
        """
        if reset:
            if self._reset_configuration(assume_yes=assume_yes):
                success_color = theme_manager.get_color("success")
                console.print(
                    f"[{success_color}]✓[/{success_color}] Configuration reset successfully"
                )
                if not (provider or api_key or project or api_url):
                    if assume_yes:
                        return
                    console.print("\nStarting fresh setup...\n")
            else:
                return

        explicit_non_interactive = bool(api_key or project or api_url or dry_run)

        if explicit_non_interactive:
            success = self._configure_with_options(
                provider, environment, api_key, project, api_url, dry_run, output_path
            )
        else:
            if assume_yes:
                console.print(
                    "[error]Error:[/error] --yes requires non-interactive options. "
                    "Provide --provider and related flags."
                )
                raise click.exceptions.Exit(1)
            success = run_setup_wizard(provider, environment)

        if success and not dry_run:
            # run_setup_wizard already installs completion on its own path;
            # the non-interactive branch funnels through this call site.
            if explicit_non_interactive:
                _install_shell_completion()
            self._render_post_setup_actions()

        if not success:
            raise click.exceptions.Exit(1)

    def _configure_with_options(
        self,
        provider: str | None,
        environment: str,
        api_key: str | None,
        project: str | None,
        api_url: str | None,
        dry_run: bool,
        output_path: str | None,
    ) -> bool:
        """Configure using command-line options (non-interactive)."""
        _register_providers()

        resolved_provider = self._resolve_non_interactive_provider(provider)
        if not resolved_provider:
            return False

        adapter = _build_adapter(resolved_provider, environment)
        if not adapter:
            console.print(
                f"[error]Error:[/error] Unknown or unavailable provider: "
                f"{escape(str(resolved_provider))}"
            )
            return False

        prefill: dict[str, object] = {}
        if api_key:
            prefill["api_key"] = api_key
        if project:
            prefill["project"] = project
        if api_url:
            prefill["api_url"] = api_url

        pipeline = SetupPipeline(adapter, console=console, environment=environment)
        result = pipeline.run(
            prefill=prefill,
            interactive=False,
            dry_run=dry_run,
            output_path=Path(output_path) if output_path else None,
        )
        if not result.success:
            return False

        if not dry_run:
            _finalize_environment_marker(environment)
            config_file = "config-staging.yaml" if environment == "staging" else "config.yaml"
            success_color = theme_manager.get_color("success")
            console.print(
                f"\n[{success_color}]✓[/{success_color}] Configuration saved to "
                f"~/.flow/{config_file}"
            )
            if environment == "staging":
                console.print(f"[{success_color}]✓[/{success_color}] Environment set to staging")
            if resolved_provider == "mithril" and api_key:
                console.print(
                    "\n[dim]Note:[/dim] Running tasks provisions real infrastructure "
                    "and may incur costs."
                )
        return True

    def _resolve_non_interactive_provider(self, provider: str | None) -> str | None:
        """Pick a provider for non-interactive setup, defaulting to mithril."""
        if provider:
            return provider
        adapters = _list_providers() or ["mithril"]
        if len(adapters) == 1:
            return adapters[0]
        if "mithril" in adapters:
            return "mithril"
        console.print(
            "[error]Error:[/error] Provider must be specified with "
            "--provider in non-interactive mode"
        )
        return None

    def _render_post_setup_actions(self) -> None:
        """Emit the single post-setup call-to-action.

        One big green tick, one "try it now" command, two dim auxiliary
        commands. Rendered from exactly one place so interactive and
        non-interactive completions show the same copy.
        """
        render_setup_next_actions(console)

    def _reset_configuration(self, *, assume_yes: bool = False) -> bool:
        """Reset Flow configuration to initial state."""
        from rich.prompt import Confirm

        flow_dir = Path.home() / ".flow"
        files_to_clear = []

        if flow_dir.exists():
            for config_name in ("config.yaml", "config-staging.yaml"):
                config_file = flow_dir / config_name
                if config_file.exists():
                    files_to_clear.append(config_file)
            for cred_file in flow_dir.glob("credentials.*"):
                files_to_clear.append(cred_file)
            env_script = flow_dir / "env.sh"
            if env_script.exists():
                files_to_clear.append(env_script)

        if not files_to_clear:
            console.print("[warning]No configuration files found to reset[/warning]")
            return True

        console.print("\n[bold]The following files will be removed:[/bold]")
        for file in files_to_clear:
            console.print(f"  • {file}")

        console.print("")
        confirm = assume_yes or Confirm.ask(
            "[warning]Are you sure you want to reset configuration?[/warning]"
        )

        if not confirm:
            console.print("[dim]Reset cancelled[/dim]")
            return False

        for file in files_to_clear:
            try:
                file.unlink()
            except Exception as e:  # noqa: BLE001
                console.print(f"[error]Error deleting {file}: {escape(str(e))}[/error]")
                return False

        return True


# Export command instance
command = SetupCommand()
