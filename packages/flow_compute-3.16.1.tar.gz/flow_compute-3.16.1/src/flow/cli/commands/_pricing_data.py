"""Shared data-fetch helpers for the pricing CLI command.

Extracted from ``pricing.py`` so Phase 2 (``flow pricing stats``) can reuse
them. These are Mithril-specific HTTP helpers; they fail closed by letting
HTTP and JSON errors bubble up to the caller for explicit handling.
"""

import json
import re
import ssl
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib import request as urlreq
from urllib.parse import urlencode, urljoin

from flow.domain.parsers.instance_parser import extract_gpu_info
from flow.utils.parsing import parse_cost_string

_GPU_COUNT_RE = re.compile(r"^(\d+)x([a-z0-9-]+)$|^([a-z0-9-]+)x(\d+)$")
_INSTANCE_TYPES_FETCH_LIMIT = 1000
_SEED_INSTANCE_TYPES: dict[str, str] = {
    "it_RrgkIZz6c9BZu5gi": "a100-80gb.sxm.1x",
    "it_TiAPxzKNi4xO0IAr": "a100-80gb.sxm.2x",
    "it_4TugeYWOov5FllEf": "a100-80gb.sxm.4x",
    "it_Sg1nDx1I8NFep60J": "a100-80gb.sxm.8x",
    "it_5ECSoHQjLBzrp5YM": "h100-80gb.sxm.8x",
    "it_XqgKWbhZ5gznAYsG": "h100-80gb.sxm.8x",
    "it_7RHoQUztab9lU9Ne": "h200.8x",
    "it_q0oUtmD4bgy36kb": "neb-b200.sxm.8x",
    "it_nFEHySv5IMnHKbKi": "b200-192gb.8x",
    "it_tcjiKnwIK0jX21t3": "b200-192gb.1x",
    "it_WCJ0NkfuADQ7yexV": "b200-192gb.2x",
    "it_OS38SJAdsS1l6QFU": "b200-192gb.4x",
}


def parse_gpu_spec(raw: str) -> tuple[str, int | None]:
    """Extract (gpu_type, gpu_count) from a shorthand like '1xb200' or 'h100x8'.

    Returns (gpu_type, None) when no count prefix/suffix is present.
    """
    cleaned = raw.strip().lower()
    m = _GPU_COUNT_RE.match(cleaned)
    if m:
        if m.group(1):
            return m.group(2), int(m.group(1))
        return m.group(3), int(m.group(4))
    return cleaned, None


def _resolve_api_context() -> tuple[str, str | None, str | None]:
    """Resolve Mithril API base URL, API key, and project from env/config."""
    import os

    api_base = os.getenv("MITHRIL_API_URL", "https://api.mithril.ai").rstrip("/") + "/"
    api_key = os.getenv("MITHRIL_API_KEY")
    project = os.getenv("MITHRIL_PROJECT_ID") or os.getenv("MITHRIL_PROJECT")

    if not api_key or not project:
        try:
            from flow.application.config.config import Config as _Cfg

            cfg = _Cfg.from_env(require_auth=False)
            if not api_key:
                api_key = cfg.auth_token or api_key
            if not project:
                project = (cfg.provider_config or {}).get("project") or project
            api_base = ((cfg.provider_config or {}).get("api_url") or api_base).rstrip("/") + "/"
        except Exception:  # noqa: BLE001
            pass

    return api_base, api_key, project


def _api_get_json(api_base: str, api_key: str | None, path: str, params: dict | None = None) -> Any:
    """HTTP GET against Mithril API, returns parsed JSON."""
    qs = f"?{urlencode(params)}" if params else ""
    url = urljoin(api_base, path.lstrip("/")) + qs
    headers: dict[str, str] = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urlreq.Request(url, headers=headers, method="GET")
    ctx = ssl.create_default_context()
    with urlreq.urlopen(req, context=ctx, timeout=15) as resp:
        data = resp.read()
        return json.loads(data.decode("utf-8"))


def _fetch_instance_type_map(api_base: str, api_key: str | None) -> dict[str, tuple[str, int, str]]:
    """Fetch instance types. Returns {fid: (display_name, gpu_count, gpu_type)}."""
    result: dict[str, tuple[str, int, str]] = {
        fid: (name, count, gpu_type)
        for fid, name in _SEED_INSTANCE_TYPES.items()
        for gpu_type, count in [extract_gpu_info(name)]
    }
    itypes = _api_get_json(
        api_base,
        api_key,
        "/v2/instance-types",
        {"limit": _INSTANCE_TYPES_FETCH_LIMIT},
    )
    if not isinstance(itypes, list):
        return result

    for it in itypes:
        try:
            fid = it.get("fid") or it.get("id")
            name = it.get("name") or fid
            gpu_count = 0
            gpu_type = ""

            # Try new format first
            if it.get("gpu_type"):
                gpu_type = extract_gpu_info(str(it["gpu_type"]))[0]
                gpu_count = int(it.get("num_gpus") or 0)

            # Fallback to legacy gpus array
            if not gpu_type:
                for g in it.get("gpus", []) or []:
                    try:
                        gpu_count += int(g.get("count", 0) or 0)
                        if not gpu_type:
                            detected = extract_gpu_info(str(g.get("name") or ""))[0]
                            if detected != "default":
                                gpu_type = detected
                    except Exception:  # noqa: BLE001
                        continue

            if not gpu_type:
                gpu_type = extract_gpu_info(str(name))[0]

            if fid:
                result[str(fid)] = (str(name), gpu_count or 0, gpu_type)
        except Exception:  # noqa: BLE001
            continue

    return result


def _fetch_price_history(
    api_base: str,
    api_key: str | None,
    fid_map: dict[str, tuple[str, int, str]],
    gpu_filter: str | None,
    region_filter: str | None,
    target_regions: list[str] | None = None,
) -> dict[tuple[str, str, int], dict[str, Any]]:
    """Fetch price history for ALL instance types, keyed by (gpu_type, region, gpu_count).

    Each GPU count tier is a distinct market with its own price dynamics
    (e.g., B200 1x $0.01-$14/GPU vs B200 8x $0.00-$112.50/GPU).
    Returns data for every available tier so callers can display per-config rows.

    Prices are normalized to per-GPU USD/hr.

    When ``target_regions`` is provided, also runs one unfiltered probe so
    GPU families whose history lives in retired regions (e.g. H100/H200
    history in ``us-central2-*`` while the live markets moved to
    ``us-central3-a`` / ``us-central5-a``) still surface under the caller's
    current-region keys. Per-region matches always win over the aliased
    cross-region fallback.
    """
    # Include ALL FIDs (all GPU counts), not one per GPU type
    fid_to_gpu: dict[str, tuple[str, int]] = {}
    for fid, (_name, gpu_count, gpu_type) in fid_map.items():
        if gpu_filter and gpu_type != gpu_filter.lower():
            continue
        gc = gpu_count if gpu_count > 0 else 8
        fid_to_gpu[fid] = (gpu_type, gc)

    if not fid_to_gpu:
        return {}

    regions_to_query = target_regions or ([region_filter] if region_filter else [None])
    all_fids = ",".join(fid_to_gpu.keys())
    result: dict[tuple[str, str, int], dict[str, Any]] = {}

    # Request 14 days of history via start_time: 7d for the bid guide
    # (clipped via window_hours=168) plus 7d for week-over-week trends.
    start_time = (datetime.now(timezone.utc) - timedelta(days=14)).isoformat()

    def _series_from_price_points(points: list[Any]) -> list[dict[str, Any]]:
        grouped: dict[tuple[str, str], dict[str, Any]] = {}
        for point in points:
            if not isinstance(point, dict):
                continue
            fid = point.get("instance_type") or point.get("instance_type_id")
            if not fid:
                continue
            series_region = str(point.get("region") or "")
            key = (str(fid), series_region)
            series = grouped.setdefault(
                key,
                {
                    "instance_type": str(fid),
                    "region": series_region,
                    "spot_prices": [],
                    "timestamps": [],
                },
            )
            series["spot_prices"].append(
                point.get("spot_instance_price") or point.get("spot_price") or point.get("price")
            )
            series["timestamps"].append(point.get("timestamp"))
        return list(grouped.values())

    def _series_from_response(resp: Any) -> list[dict[str, Any]]:
        if isinstance(resp, dict):
            series = resp.get("series")
            if isinstance(series, list):
                return [item for item in series if isinstance(item, dict)]

            prices = resp.get("prices")
            if isinstance(prices, list):
                return _series_from_price_points(prices)

            return [resp]

        if isinstance(resp, list):
            if any(isinstance(item, dict) and "spot_instance_price" in item for item in resp):
                return _series_from_price_points(resp)
            return [item for item in resp if isinstance(item, dict)]

        return []

    def _collect(rgn: str | None, assign_regions: list[str] | None) -> None:
        params: dict[str, Any] = {
            "instance_types": all_fids,
            "num_samples": 1000,
            "start_time": start_time,
        }
        if rgn:
            params["region"] = rgn

        try:
            resp = _api_get_json(api_base, api_key, "/v2/pricing/history", params)
        except Exception:  # noqa: BLE001
            return

        series_list = _series_from_response(resp)

        for series in series_list:
            raw_prices = series.get("spot_prices", [])
            timestamps = series.get("timestamps", [])
            series_fid = series.get("instance_type") or series.get("instance_type_id", "")
            series_region = series.get("region") or rgn or ""

            if not raw_prices:
                continue

            # Forward-fill (LOCF)
            filled_prices: list[float] = []
            filled_timestamps: list[str] = []
            last_valid: float | None = None
            for p, t in zip(raw_prices, timestamps[: len(raw_prices)], strict=True):
                if p is not None:
                    parsed = parse_cost_string(p, default=-1.0)
                    if parsed > 0:
                        last_valid = parsed
                if last_valid is not None:
                    filled_prices.append(last_valid)
                    filled_timestamps.append(t if isinstance(t, str) else str(t))

            if not filled_prices:
                continue

            # Match series to GPU type via FID
            gpu_type, gpu_count = "", 8
            if series_fid and series_fid in fid_to_gpu:
                gpu_type, gpu_count = fid_to_gpu[series_fid]
            elif len(fid_to_gpu) == 1:
                gpu_type, gpu_count = next(iter(fid_to_gpu.values()))
            else:
                continue

            per_gpu_prices = [p / gpu_count for p in filled_prices]
            payload = {
                "spot_prices": per_gpu_prices,
                "timestamps": filled_timestamps,
                "gpu_count": gpu_count,
            }

            # Primary key: the region the API reported the series in.
            primary_key = (gpu_type, series_region, gpu_count)
            if primary_key not in result:
                result[primary_key] = payload

            # Alias keys: when the caller requested a specific catalog region
            # and the series lives elsewhere (retired regions), mirror the
            # payload under the catalog region so downstream per-region
            # lookups still hit — but never clobber a real per-region series.
            for alias_region in assign_regions or []:
                if not alias_region or alias_region == series_region:
                    continue
                alias_key = (gpu_type, alias_region, gpu_count)
                if alias_key not in result:
                    result[alias_key] = payload

    for rgn in regions_to_query:
        _collect(rgn, assign_regions=None)

    # Cross-region fallback for GPU families whose history lives only in
    # retired regions: any catalog config still missing history gets aliased
    # to the unfiltered response for its (gpu, gpu_count) pair.
    if target_regions:
        missing_before = {
            (gpu_type, region, gc)
            for region in target_regions
            for gpu_type, gc in fid_to_gpu.values()
            if region and (gpu_type, region, gc) not in result
        }
        if missing_before:
            _collect(None, assign_regions=target_regions)

    return result
