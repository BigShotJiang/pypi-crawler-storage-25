"""Register additional ``TimeSeries`` I/O handlers on import.

Canonical direct-I/O names include ``"mseed"``, ``"nc"``,
``"hdf.ndscope"``, and ``"xml.diaggui"``. Legacy aliases remain registered
for backward compatibility.
"""
from __future__ import annotations

# Readers are registered on import
from gwexpy.timeseries._gwf_io import _sync_gwf_registry_aliases

from . import (
    ats,  # noqa: F401
    audio,  # noqa: F401
    csv_enhanced,  # noqa: F401
    dttxml,  # noqa: F401
    gbd,  # noqa: F401
    ndscope_hdf5,  # noqa: F401
    netcdf4_,  # noqa: F401
    sdb,  # noqa: F401
    seismic,  # noqa: F401
    stubs,  # noqa: F401
    tdms,  # noqa: F401
    wav,  # noqa: F401
    win,  # noqa: F401
    zarr_,  # noqa: F401
)

_sync_gwf_registry_aliases()

__all__: list[str] = []
