"""NetCDF4 reader/writer for gwexpy (via xarray).

Reads variables that have a ``time`` dimension and converts them to
:class:`~gwexpy.timeseries.TimeSeries`.
"""
from __future__ import annotations

import json
import logging
from collections import OrderedDict

import numpy as np

from gwexpy.io.utils import (
    apply_unit,
    datetime_to_gps,
    ensure_dependency,
    filter_by_channels,
    set_provenance,
)

from .. import TimeSeries, TimeSeriesDict, TimeSeriesMatrix
from ._registration import register_timeseries_format

logger = logging.getLogger(__name__)
_MATRIX_VAR_PREFIX = "__gwexpy_matrix__"


def _to_json_native(val):
    """Convert a value to a JSON-serializable Python native type.

    numpy integer/float/bool scalars expose .item() which maps to the
    corresponding Python built-in.  Exotic types (datetime64, timedelta64, …)
    also have .item() but produce objects that json.dumps() still rejects, so
    we fall back to str() for anything that remains non-serializable.
    """
    if hasattr(val, "item"):
        val = val.item()
    if not isinstance(val, (bool, int, float, str, type(None))):
        return str(val)
    return val


def _encode_netcdf_var_name(key) -> str:
    """Convert mapping keys to NetCDF-safe variable names.

    For tuple keys the variable name uses a SHA-256 hash of the repr so that
    the name is always unique, contains only hex characters, and contains no
    illegal NetCDF4 characters (parentheses, spaces, …).  The true row/col
    identity is always stored in ``gwexpy_row_key``/``gwexpy_col_key``
    attributes; the variable name itself only needs to be unique and valid.
    """
    if isinstance(key, tuple):
        import hashlib

        h = hashlib.sha256(repr(key).encode()).hexdigest()[:20]
        return f"{_MATRIX_VAR_PREFIX}{h}"
    return str(key)


def _decode_netcdf_key(raw):
    """Deserialize a key stored as JSON; fall back to str for legacy files."""
    if raw is None:
        return None
    try:
        result = json.loads(raw)
        if isinstance(result, list):
            return tuple(result)
        return result
    except (json.JSONDecodeError, TypeError, ValueError):
        return str(raw)


def _import_xarray():
    try:
        xr = ensure_dependency("xarray", extra="netcdf4")
    except ImportError as exc:
        raise ImportError(
            "xarray is required for reading/writing NetCDF4 files. "
            "Install with `pip install 'gwexpy[netcdf4]'`."
        ) from exc
    return xr


def _time_coord_name(ds):
    """Return the name of the time coordinate, or *None*."""
    for name in ("time", "Time", "TIME", "t"):
        if name in ds.coords:
            return name
    # Fallback: first datetime64 coordinate
    for name, coord in ds.coords.items():
        if np.issubdtype(coord.dtype, np.datetime64):
            return name
    return None


def read_timeseriesdict_netcdf4(
    source,
    *,
    channels=None,
    unit=None,
    time_coord=None,
    **kwargs,
) -> TimeSeriesDict:
    """Read a NetCDF4 file into a TimeSeriesDict.

    Parameters
    ----------
    source : str or path-like
        Path to a ``.nc`` file.
    channels : iterable of str, optional
        Variable names to read.  If *None*, all variables with a time
        dimension are loaded.
    unit : str, optional
        Physical unit override applied to every channel.
    time_coord : str, optional
        Name of the time coordinate.  Auto-detected if *None*.
    **kwargs
        Additional keyword arguments forwarded to ``xarray.open_dataset``.

    """
    xr = _import_xarray()

    # gwpy's registry may pass a file-like object; extract the path.
    if hasattr(source, "name"):
        source = source.name

    # Strip gwpy-injected kwargs that xarray.open_dataset does not accept.
    _gwpy_keys = {"start", "end", "pad", "gap", "nproc", "scaled"}
    xr_kwargs = {k: v for k, v in kwargs.items() if k not in _gwpy_keys}
    ds = xr.open_dataset(str(source), **xr_kwargs)
    try:
        tc = time_coord or _time_coord_name(ds)
        if tc is None:
            raise ValueError(
                "No time coordinate found in the NetCDF4 file. "
                "Specify one explicitly via time_coord='...'."
            )

        time_vals = ds[tc].values

        # Compute t0 (GPS) and dt (seconds).
        # Handle both datetime64 and numeric time coordinates.
        if np.issubdtype(np.asarray(time_vals).dtype, np.datetime64):
            import datetime as _dt

            t0_dt64 = time_vals[0]
            t0_unix_ns = (t0_dt64 - np.datetime64("1970-01-01T00:00:00", "ns")).astype(
                np.int64
            )
            t0_datetime = _dt.datetime.fromtimestamp(t0_unix_ns / 1e9, tz=_dt.UTC)
            t0 = datetime_to_gps(t0_datetime)

            if len(time_vals) > 1:
                diffs_ns = np.diff(time_vals.astype("datetime64[ns]").astype(np.int64))
                dt = float(np.median(diffs_ns)) / 1e9
            else:
                dt = 1.0
        else:
            # Numeric time coordinate (e.g. seconds, GPS times, or cftime
            # objects that were decoded to floats).
            numeric = np.asarray(time_vals, dtype=np.float64)
            t0 = float(numeric[0])
            if len(numeric) > 1:
                dt = float(np.median(np.diff(numeric)))
            else:
                dt = 1.0

        tsd = TimeSeriesDict()

        var_names = list(channels) if channels else list(ds.data_vars)
        for var in var_names:
            if var not in ds.data_vars:
                logger.debug("Variable '%s' not found in dataset, skipping", var)
                continue
            da = ds[var]
            if tc not in da.dims:
                logger.debug(
                    "Variable '%s' has no time dimension '%s', skipping", var, tc
                )
                continue

            data = da.values
            # Handle multi-dimensional variables: flatten non-time dims
            if data.ndim > 1:
                time_axis = list(da.dims).index(tc)
                # Move time axis first, then flatten remaining
                data = np.moveaxis(data, time_axis, 0)
                data = data.reshape(data.shape[0], -1)
                # Create one channel per flattened index
                for i in range(data.shape[1]):
                    ch_name = f"{var}_{i}" if data.shape[1] > 1 else var
                    var_unit = unit or da.attrs.get("units") or da.attrs.get("unit")
                    ts = TimeSeries(
                        data[:, i].astype(np.float64),
                        t0=t0,
                        dt=dt,
                        name=ch_name,
                        channel=ch_name,
                    )
                    ts = apply_unit(ts, var_unit) if var_unit else ts
                    tsd[ch_name] = ts
            else:
                var_unit = unit or da.attrs.get("units") or da.attrs.get("unit")
                ts = TimeSeries(
                    data.astype(np.float64),
                    t0=t0,
                    dt=dt,
                    name=var,
                    channel=var,
                )
                ts = apply_unit(ts, var_unit) if var_unit else ts
                tsd[var] = ts

        # filter_by_channels matches against the *final* dict keys.
        # Multi-dimensional variables are flattened to "var_0", "var_1", …
        # so we must accept both the original name and the suffixed names.
        if channels:
            expanded = set(channels)
            for ch in channels:
                expanded.update(k for k in tsd if k == ch or k.startswith(f"{ch}_"))
            tsd = TimeSeriesDict(filter_by_channels(tsd, expanded))

        set_provenance(
            tsd,
            {
                "format": "nc",
                "time_coord": tc,
                "channels": list(tsd.keys()),
                "unit_source": "override" if unit else "file",
            },
        )
        return tsd
    finally:
        ds.close()


def read_timeseries_netcdf4(source, **kwargs) -> TimeSeries:
    """Read a NetCDF4 file and return the first time-series variable."""
    tsd = read_timeseriesdict_netcdf4(source, **kwargs)
    if not tsd:
        raise ValueError("No time-series variables found in NetCDF4 file")
    return tsd[next(iter(tsd.keys()))]


def read_timeseriesmatrix_netcdf4(source, **kwargs) -> TimeSeriesMatrix:
    """Read a NetCDF4 file and convert its channels to a matrix."""
    xr = _import_xarray()

    if hasattr(source, "name"):
        source = source.name

    _gwpy_keys = {"start", "end", "pad", "gap", "nproc", "scaled"}
    xr_kwargs = {k: v for k, v in kwargs.items() if k not in _gwpy_keys}
    ds = xr.open_dataset(str(source), **xr_kwargs)
    try:
        tc = kwargs.get("time_coord") or _time_coord_name(ds)
        if tc is None:
            raise ValueError(
                "No time coordinate found in the NetCDF4 file. "
                "Specify one explicitly via time_coord='...'."
            )

        matrix_vars = []
        for var_name, da in ds.data_vars.items():
            row_raw = da.attrs.get("gwexpy_row_key")
            col_raw = da.attrs.get("gwexpy_col_key")
            if row_raw is None or col_raw is None or tc not in da.dims:
                continue
            if da.attrs.get("gwexpy_key_format") == "json":
                row_key = _decode_netcdf_key(row_raw)
                col_key = _decode_netcdf_key(col_raw)
            else:
                row_key = str(row_raw)
                col_key = str(col_raw)
            matrix_vars.append((row_key, col_key, da))

        if not matrix_vars:
            tsd = read_timeseriesdict_netcdf4(source, **kwargs)
            return tsd.to_matrix()

        row_keys = list(OrderedDict.fromkeys(row for row, _, _ in matrix_vars))
        col_keys = list(OrderedDict.fromkeys(col for _, col, _ in matrix_vars))

        first = matrix_vars[0][2]
        unit = first.attrs.get("units") or first.attrs.get("unit")
        time_vals = ds[tc].values

        if np.issubdtype(np.asarray(time_vals).dtype, np.datetime64):
            import datetime as _dt

            t0_dt64 = time_vals[0]
            t0_unix_ns = (t0_dt64 - np.datetime64("1970-01-01T00:00:00", "ns")).astype(
                np.int64
            )
            t0_datetime = _dt.datetime.fromtimestamp(t0_unix_ns / 1e9, tz=_dt.UTC)
            t0 = datetime_to_gps(t0_datetime)
            if len(time_vals) > 1:
                diffs_ns = np.diff(time_vals.astype("datetime64[ns]").astype(np.int64))
                dt = float(np.median(diffs_ns)) / 1e9
            else:
                dt = 1.0
        else:
            numeric = np.asarray(time_vals, dtype=np.float64)
            t0 = float(numeric[0])
            dt = float(np.median(np.diff(numeric))) if len(numeric) > 1 else 1.0

        data = np.empty((len(row_keys), len(col_keys), len(time_vals)), dtype=np.float64)
        for row_key, col_key, da in matrix_vars:
            i = row_keys.index(row_key)
            j = col_keys.index(col_key)
            data[i, j, :] = np.asarray(da.values, dtype=np.float64)

        matrix = TimeSeriesMatrix(
            data,
            t0=t0,
            dt=dt,
            unit=unit,
        )
        if row_keys != list(matrix.row_keys()) or col_keys != list(matrix.col_keys()):
            from gwexpy.types.metadata import MetaData, MetaDataDict

            matrix.rows = MetaDataDict(
                OrderedDict((key, MetaData()) for key in row_keys),
                expected_size=len(row_keys),
                key_prefix="row",
            )
            matrix.cols = MetaDataDict(
                OrderedDict((key, MetaData()) for key in col_keys),
                expected_size=len(col_keys),
                key_prefix="col",
            )
        return matrix
    finally:
        ds.close()


# -- Writer --------------------------------------------------------------------


def write_timeseriesdict_netcdf4(tsd, target, **kwargs):
    """Write a TimeSeriesDict to a NetCDF4 file.

    Each channel becomes a variable with a shared ``time`` coordinate
    reconstructed from ``t0`` and ``dt``.
    """
    xr = _import_xarray()
    import datetime as _dt

    if not tsd:
        raise ValueError("Cannot write empty TimeSeriesDict to NetCDF4")

    first_key = next(iter(tsd.keys()))
    first = tsd[first_key]
    n_samples = first.shape[0]
    dt_sec = float(first.dt.value)
    t0_gps = float(first.t0.value)

    # Reconstruct datetime64 time axis from GPS t0
    from gwpy.time import from_gps

    t0_dt = from_gps(t0_gps)
    if hasattr(t0_dt, "to_pydatetime"):
        t0_dt = t0_dt.to_pydatetime()
    if t0_dt.tzinfo is None:
        t0_dt = t0_dt.replace(tzinfo=_dt.UTC)
    t0_ns = np.datetime64(t0_dt, "ns")
    dt_ns = np.timedelta64(int(round(dt_sec * 1e9)), "ns")
    time_axis = t0_ns + np.arange(n_samples) * dt_ns

    data_vars = {}
    for key, ts in tsd.items():
        attrs = {}
        if ts.unit is not None:
            attrs["units"] = str(ts.unit)
        var_name = _encode_netcdf_var_name(key)
        if isinstance(key, tuple) and len(key) == 2:
            attrs["gwexpy_row_key"] = json.dumps(_to_json_native(key[0]))
            attrs["gwexpy_col_key"] = json.dumps(_to_json_native(key[1]))
            attrs["gwexpy_key_format"] = "json"
        data_vars[var_name] = xr.DataArray(
            np.asarray(ts.value, dtype=np.float64),
            dims=["time"],
            attrs=attrs,
        )

    ds = xr.Dataset(data_vars, coords={"time": time_axis})
    ds.to_netcdf(str(target), **kwargs)


def write_timeseries_netcdf4(ts, target, **kwargs):
    """Write one ``TimeSeries`` to a NetCDF4 file."""
    write_timeseriesdict_netcdf4(
        TimeSeriesDict({ts.name or "channel_0": ts}), target, **kwargs
    )


# -- Registration --------------------------------------------------------------

register_timeseries_format(
    "nc",
    aliases=("netcdf4",),
    reader_dict=read_timeseriesdict_netcdf4,
    reader_single=read_timeseries_netcdf4,
    reader_matrix=read_timeseriesmatrix_netcdf4,
    writer_dict=write_timeseriesdict_netcdf4,
    writer_single=write_timeseries_netcdf4,
    extension="nc",
)
