"""Neo interop helpers."""

from __future__ import annotations

from ._optional import require_optional

__all__ = ["to_neo", "from_neo"]


def to_neo(obj, units=None):
    """Convert a `TimeSeries` or `TimeSeriesMatrix` to `neo.AnalogSignal`."""
    neo = require_optional("neo")
    import quantities as pq  # neo uses quantities
    from gwpy.timeseries import TimeSeries as BaseTimeSeries

    if isinstance(obj, BaseTimeSeries):
        # TimeSeries -> (time, 1)
        data = obj.value[:, None]
        ch_names = [str(obj.name or "ch0")]
        sample_rate = obj.sample_rate
        t0 = obj.t0
        unit = obj.unit
        name = obj.name
    else:
        # TimeSeriesMatrix shape: (ch, 1, time) or (ch, time)??
        # SeriesMatrix base is 3D: (rows, cols, time)
        # TimeSeriesMatrix is usually (ch, 1, time)
        val = obj.value
        if val.ndim == 3:
            # (n_ch, 1, time) -> (time, n_ch)
            data = val.squeeze(axis=1).T

            # channels is 2D (n_ch, 1) extract first column
            # Try to get names/channels from metadata
            # SeriesMatrix base has obj.names and obj.channels
            def _is_valid_array(arr):
                if arr is None or arr.size == 0:
                    return False
                # Check at least one element is not None AND has a useful name
                for x in arr.flat:
                    if x is None:
                        continue
                    # For GWpy Channel objects, check if name is not None/ "None"
                    if hasattr(x, "name"):
                        if x.name is not None and str(x.name) != "None":
                            return True
                    else:
                        # For raw strings or other objects
                        if x is not None and str(x) != "None":
                            return True
                return False

            if hasattr(obj, "channel_names") and obj.channel_names:
                ch_names = [str(x) for x in obj.channel_names]
            elif hasattr(obj, "channels") and _is_valid_array(obj.channels):
                ch_names = [str(x) for x in obj.channels[:, 0]]
            elif hasattr(obj, "names") and _is_valid_array(obj.names):
                ch_names = [str(x) for x in obj.names[:, 0]]
            else:
                ch_names = [str(i) for i in range(data.shape[1])]
        else:
            # Handle other cases if needed
            data = val.T
            ch_names = [str(i) for i in range(data.shape[1])]

        sample_rate = obj.sample_rate
        t0 = obj.t0
        # TimeSeriesMatrix has .units (2D array), not .unit
        if hasattr(obj, "unit"):
            unit = obj.unit
        elif hasattr(obj, "units"):
            # Get unit from first element
            unit = obj.units[0, 0] if obj.units.size > 0 else None
        else:
            unit = None
        name = getattr(obj, "name", None)

    fs = float(sample_rate.value) * pq.Hz
    t_start = float(t0.value if hasattr(t0, "value") else t0) * pq.s

    # unit mapping astropy -> quantities
    u_str = str(unit) if units is None else units

    sig = neo.AnalogSignal(
        data * pq.Quantity(1, u_str), sampling_rate=fs, t_start=t_start, name=name
    )
    sig.array_annotations = {"channel_names": ch_names}

    return sig


def from_neo(cls, sig):
    """Create a `TimeSeriesMatrix` from `neo.AnalogSignal`."""
    # sig shape: (time, ch)
    data = sig.magnitude.T  # (ch, time)
    data = data[:, None, :]  # (ch, 1, time)

    # meta
    sfreq = sig.sampling_rate.rescale("Hz").magnitude
    dt = 1.0 / sfreq
    t0 = sig.t_start.rescale("s").magnitude
    unit = str(sig.units.dimensionality)

    # channels?
    ch_names = sig.array_annotations.get("channel_names", None)

    return cls(data, t0=t0, dt=dt, unit=unit, channel_names=ch_names)
