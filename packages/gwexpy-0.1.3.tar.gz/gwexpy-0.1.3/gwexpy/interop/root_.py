from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, TypeVar, Union

import numpy as np

from ._optional import require_optional
from .base import to_plain_array

if TYPE_CHECKING:
    import ROOT

    from gwexpy.frequencyseries import FrequencySeries
    from gwexpy.spectrogram import Spectrogram
    from gwexpy.timeseries import TimeSeries

T_s = TypeVar("T_s", bound=Union["TimeSeries", "FrequencySeries", "Spectrogram"])


def _get_label(obj: Any, unit: Any, default_name: str = "x") -> str:
    name = getattr(obj, "name", None) or default_name
    unit_str = str(unit) if unit else ""
    if unit_str:
        return f"{name} [{unit_str}]"
    return str(name)


def _extract_error_array(series, error):
    """Extract a matching error array from supported input types."""
    from astropy import units as u

    # If it's a gwpy/gwexpy Series
    if hasattr(error, "value") and hasattr(error, "xindex"):
        if len(error) != len(series):
            raise ValueError(
                f"Error series length ({len(error)}) does not match data length ({len(series)})"
            )
        # Check xindex matching (optional check, maybe too strict if slightly shifted?)
        # For now, just extract value
        return to_plain_array(error.value)

    # If it's an astropy Quantity
    if isinstance(error, u.Quantity):
        if error.shape != series.shape:
            raise ValueError(
                f"Error shape {error.shape} does not match data shape {series.shape}"
            )
        # Try to match units if series has unit
        if hasattr(series, "unit") and series.unit:
            try:
                return error.to(series.unit).value
            except u.UnitConversionError:
                # If not convertible, just use raw value but warn?
                # User might be passing relative error or something.
                # But requirement says "same unit".
                pass
        return error.value

    # If it's a plain numpy array or list
    err_arr = np.asarray(error)
    if err_arr.shape != series.shape:
        raise ValueError(
            f"Error shape {err_arr.shape} does not match data shape {series.shape}"
        )
    return err_arr


def to_tgraph(series: Any, error: Optional[Any] = None) -> ROOT.TGraph:
    """Convert a 1D series to a ROOT ``TGraph`` or ``TGraphErrors``."""
    ROOT = require_optional("ROOT")

    x = to_plain_array(series.xindex).astype(float)
    y = to_plain_array(series.value).astype(float)
    n = len(x)

    if error is not None:
        ey = _extract_error_array(series, error).astype(float)
        ex = np.zeros(n)
        graph = ROOT.TGraphErrors(n, x, y, ex, ey)
    else:
        graph = ROOT.TGraph(n, x, y)

    name = str(series.name or "graph")
    graph.SetName(name)
    graph.SetTitle(name)

    # Axis labels
    str(series.xunit) if hasattr(series, "xunit") else ""
    str(series.unit) if hasattr(series, "unit") else ""

    graph.GetXaxis().SetTitle(_get_label(series.xindex, series.xunit, default_name="x"))
    graph.GetYaxis().SetTitle(_get_label(series, series.unit, default_name="y"))

    return graph


def to_th1d(series: Any, error: Optional[Any] = None) -> ROOT.TH1D:
    """Convert a 1D series to a ROOT ``TH1D``."""
    ROOT = require_optional("ROOT")

    # Handle Histogram objects (composite, not ndarray-based)
    if hasattr(series, "edges") and hasattr(series, "values"):
        # Get edges and values
        edges = to_plain_array(series.edges).astype(float)
        y = to_plain_array(series.values).astype(float)
        n = len(y)

        name = str(getattr(series, "name", None) or "hist")
        title = name
        hist = ROOT.TH1D(name, title, n, edges)

        # Fill bins
        # ROOT bins: 0 = underflow, 1..n = content, n+1 = overflow
        content = np.zeros(n + 2, dtype=np.float64)
        content[1:-1] = y
        content[0] = to_plain_array(getattr(series, "underflow", 0.0)).astype(float)
        content[-1] = to_plain_array(getattr(series, "overflow", 0.0)).astype(float)
        hist.SetContent(content)

        # Errors: prefer sumw2 if available, otherwise diagonal of cov, otherwise derived from error arg
        if error is not None:
            ey = _extract_error_array(series, error).astype(float)
        elif hasattr(series, "errors") and series.errors is not None:
            ey = to_plain_array(series.errors).astype(float)
        else:
            ey = None

        if ey is not None:
            err_content = np.zeros(n + 2, dtype=np.float64)
            err_content[1:-1] = ey
            # Underflow/overflow errors from sumw2 if available
            sw2_under = getattr(series, "underflow_sumw2", None)
            if sw2_under is not None:
                err_content[0] = np.sqrt(to_plain_array(sw2_under).astype(float))
            sw2_over = getattr(series, "overflow_sumw2", None)
            if sw2_over is not None:
                err_content[-1] = np.sqrt(to_plain_array(sw2_over).astype(float))

            hist.SetError(err_content)

        # Labels
        hist.GetXaxis().SetTitle(
            _get_label(series.edges, series.xunit, default_name="x")
        )
        hist.GetYaxis().SetTitle(_get_label(series, series.unit, default_name="y"))

        return hist

    # Fallback to existing Series logic
    x = to_plain_array(series.xindex).astype(float)
    y = to_plain_array(series.value).astype(float)
    n = len(x)

    if n < 2:
        raise ValueError("Series must have at least 2 points for TH1D")

    # Determine binning
    # TH1D requires bin edges. Series usually represents bin centers or samples.
    # We assume regular if possible, or use variable bins.

    dx_vals = np.diff(x)
    is_regular = np.allclose(dx_vals, dx_vals[0])

    name = str(series.name or "hist")
    title = name

    if is_regular:
        dx = dx_vals[0]
        xlow = x[0] - dx / 2.0
        xup = x[-1] + dx / 2.0
        hist = ROOT.TH1D(name, title, n, xlow, xup)
    else:
        # Variable bin widths
        # We construct edges halfway between centers
        edges = np.zeros(n + 1)
        edges[1:-1] = (x[:-1] + x[1:]) / 2.0
        # Extrapolate edges for first and last
        edges[0] = x[0] - (edges[1] - x[0])
        edges[-1] = x[-1] + (x[-1] - edges[-2])
        hist = ROOT.TH1D(name, title, n, edges)

    # Fill bins (vectorized)
    # TH1 has n+2 bins (0=underflow, n+1=overflow)
    content = np.zeros(n + 2, dtype=np.float64)
    content[1:-1] = y
    hist.SetContent(content)

    if error is not None:
        ey = _extract_error_array(series, error).astype(float)
        # Check if SetError is available (usually is for TH1)
        err_content = np.zeros(n + 2, dtype=np.float64)
        err_content[1:-1] = ey
        hist.SetError(err_content)

    # Labels
    str(series.xunit) if hasattr(series, "xunit") else ""
    str(series.unit) if hasattr(series, "unit") else ""
    hist.GetXaxis().SetTitle(_get_label(series.xindex, series.xunit, default_name="x"))
    hist.GetYaxis().SetTitle(_get_label(series, series.unit, default_name="y"))

    return hist


def to_th2d(spec: Spectrogram, error: Optional[Any] = None) -> ROOT.TH2D:
    """Convert a spectrogram to a ROOT ``TH2D``."""
    ROOT = require_optional("ROOT")

    times = to_plain_array(spec.times).astype(float)
    freqs = to_plain_array(spec.frequencies).astype(float)
    data = to_plain_array(spec.value).astype(float)

    nt = len(times)
    nf = len(freqs)

    # helper for edges
    def _get_edges(arr):
        if len(arr) < 2:
            return np.array([arr[0] - 0.5, arr[0] + 0.5])
        dx = np.diff(arr)
        if np.allclose(dx, dx[0]):
            step = dx[0]
            return np.linspace(arr[0] - step / 2, arr[-1] + step / 2, len(arr) + 1)
        else:
            edges = np.zeros(len(arr) + 1)
            edges[1:-1] = (arr[:-1] + arr[1:]) / 2.0
            edges[0] = arr[0] - (edges[1] - arr[0])
            edges[-1] = arr[-1] + (arr[-1] - edges[-2])
            return edges

    t_edges = _get_edges(times)
    f_edges = _get_edges(freqs)

    name = str(spec.name or "spectrogram")
    hist = ROOT.TH2D(name, name, nt, t_edges, nf, f_edges)

    # Fill (vectorized)
    # ROOT stores data as linearized array with index = x + (nx+2)*y
    # This corresponds to a C-style flattened array of shape (ny+2, nx+2)
    # where y is major (slow) and x is minor (fast).
    # We construct the 2D array in (ny+2, nx+2) shape, then flatten.

    full_content = np.zeros((nf + 2, nt + 2), dtype=np.float64)
    # Assign data. data is (nt, nf) -> tranpose to (nf, nt) to match [y, x]
    full_content[1:-1, 1:-1] = data.T

    hist.SetContent(full_content.flatten())

    if error is not None:
        err_arr = np.asarray(error).astype(float)
        if err_arr.shape != data.shape:
            raise ValueError("Error shape mismatch")
        full_error = np.zeros((nf + 2, nt + 2), dtype=np.float64)
        full_error[1:-1, 1:-1] = err_arr.T
        hist.SetError(full_error.flatten())

    # Labels
    hist.GetXaxis().SetTitle(
        _get_label(spec.times, spec.times.unit, default_name="time")
    )
    hist.GetYaxis().SetTitle(
        _get_label(spec.frequencies, spec.frequencies.unit, default_name="frequency")
    )
    hist.GetZaxis().SetTitle(_get_label(spec, spec.unit, default_name="value"))

    return hist


def from_root(
    cls: type[T_s], obj: Union[ROOT.TGraph, ROOT.TH1], return_error: bool = False
) -> Union[T_s, tuple[T_s, T_s]]:
    """Create a GWexpy series object from a ROOT ``TGraph`` or ``TH1``."""
    ROOT = require_optional("ROOT")

    # Check type
    is_hist = isinstance(obj, ROOT.TH1)
    is_hist2d = isinstance(obj, ROOT.TH2)
    is_graph = isinstance(obj, ROOT.TGraph)

    if not is_hist and not is_graph and not is_hist2d:
        raise TypeError(f"Object {obj} is neither TH1, TH2 nor TGraph")

    is_histogram_cls = (cls.__name__ == "Histogram") if hasattr(cls, "__name__") else False

    if is_hist2d:
        if is_histogram_cls:
            raise TypeError("Histogram class does not support 2D ROOT objects yet. Use Spectrogram.")
        nx = obj.GetNbinsX()
        ny = obj.GetNbinsY()
        x = np.array([obj.GetXaxis().GetBinCenter(i + 1) for i in range(nx)])
        y = np.array([obj.GetYaxis().GetBinCenter(j + 1) for j in range(ny)])
        z = np.zeros((nx, ny))
        ez = np.zeros((nx, ny)) if return_error else None

        # Optimize reading using GetArray (returns pointer to linearized array)
        # Array size is (nx+2)*(ny+2)
        total_size = (nx + 2) * (ny + 2)
        buff_ptr = obj.GetArray()
        # Copy to numpy
        arr_flat = np.frombuffer(buff_ptr, dtype=np.float64, count=total_size)

        # Reshape to (ny+2, nx+2) to match ROOT layout [y][x]
        arr_2d = arr_flat.reshape((ny + 2, nx + 2))

        # Extract central part and transpose to getting (nx, ny) -> (Time, Freq)
        z = arr_2d[1:-1, 1:-1].T.copy()

        if return_error:
            # GetSumw2() usually stores errors squared? No GetBinError uses fSumw2 if present.
            # But direct access to errors might be tricky if fSumw2 is not just an array.
            # TH2::GetBinError(bin) = sqrt(fSumw2[bin])
            # Getting fSumw2 array directly: obj.GetSumw2().GetArray()
            # If default errors (sqrt(N)), GetSumw2 might be empty.
            if obj.GetSumw2N() > 0:
                err_ptr = obj.GetSumw2().GetArray()
                err_flat = np.frombuffer(err_ptr, dtype=np.float64, count=total_size)
                err_2d = err_flat.reshape((ny + 2, nx + 2))
                # sqrt needed? fSumw2 stores variance (sigma^2).
                # GetBinError returns sqrt(content) if Sumw2 not set, or sqrt(Sumw2) if set.
                ez = np.sqrt(err_2d[1:-1, 1:-1].T).copy()
            else:
                # Default Poisson errors
                ez = np.sqrt(z)

        # In GWpy Spectrogram, typically shape is (Time, Freq)
        name = obj.GetName()
        unit = None
        # ... logic for unit extraction from Z axis if possible ...
        z_title = obj.GetZaxis().GetTitle()
        if "[" in z_title and "]" in z_title:
            import re

            match = re.search(r"\[(.*?)\]", z_title)
            if match:
                unit = match.group(1)

        res = cls(z, times=x, frequencies=y, unit=unit, name=name)
        if return_error:
            from typing import cast
            err_res = cls(cast(Any, ez), times=x, frequencies=y, unit=unit, name=f"{name}_error")
            return res, err_res
        return res

    if is_hist:
        # TH1
        n = obj.GetNbinsX()

        # Edges: length n + 1
        edges = np.array([obj.GetXaxis().GetBinLowEdge(i + 1) for i in range(n + 1)])

        buff_ptr = obj.GetArray()
        # buffer size n+2. ROOT bins: 0=underflow, 1..n=data, n+1=overflow
        full_y = np.frombuffer(buff_ptr, dtype=np.float64, count=n + 2).copy()
        y = full_y[1:-1]
        underflow = full_y[0]
        overflow = full_y[-1]

        if return_error or is_histogram_cls:
            if obj.GetSumw2N() > 0:
                err_ptr = obj.GetSumw2().GetArray()
                err_raw_full = np.frombuffer(
                    err_ptr, dtype=np.float64, count=n + 2
                ).copy()
                err_raw = err_raw_full[1:-1]
                underflow_sw2 = err_raw_full[0]
                overflow_sw2 = err_raw_full[-1]
                # If it's a Histogram class, we often want sumw2 (variance)
                # But Histogram(sumw2=...) takes Sigma^2
                # whereas Series(error=...) takes Sigma (RMS).
                ey = np.sqrt(err_raw).copy()
                sw2 = err_raw.copy()
            else:
                ey = np.sqrt(y)
                sw2 = y.copy()
                underflow_sw2 = underflow
                overflow_sw2 = overflow
        else:
            ey = None
            sw2 = None
            underflow_sw2 = None
            overflow_sw2 = None

        if is_histogram_cls:
            name = obj.GetName()
            # Unit extraction
            y_title = obj.GetYaxis().GetTitle()
            x_title = obj.GetXaxis().GetTitle()
            unit = None
            xunit = None
            import re

            if "[" in y_title and "]" in y_title:
                m = re.search(r"\[(.*?)\]", y_title)
                if m:
                    unit = m.group(1)
            if "[" in x_title and "]" in x_title:
                m = re.search(r"\[(.*?)\]", x_title)
                if m:
                    xunit = m.group(1)

            histogram_cls: Any = cls
            return histogram_cls(
                y,
                edges,
                unit=unit,
                xunit=xunit,
                sumw2=sw2,
                underflow=underflow,
                overflow=overflow,
                underflow_sumw2=underflow_sw2,
                overflow_sumw2=overflow_sw2,
                name=name,
            )
    else:  # is_graph
        if is_histogram_cls:
            raise TypeError("Cannot create Histogram from TGraph. Use TH1 instead.")
        n = obj.GetN()
        # buffer access is faster
        x = np.frombuffer(obj.GetX(), dtype=np.float64, count=n).copy()
        y = np.frombuffer(obj.GetY(), dtype=np.float64, count=n).copy()
        if return_error:
            if hasattr(obj, "GetEY"):
                ey = np.frombuffer(obj.GetEY(), dtype=np.float64, count=n).copy()
            else:
                ey = np.zeros(n)
        else:
            ey = None

    # Try to extract name and unit
    name = obj.GetName()
    title = obj.GetYaxis().GetTitle()
    unit = None
    if "[" in title and "]" in title:
        # Simple parser "Name [Unit]"
        import re

        match = re.search(r"\[(.*?)\]", title)
        if match:
            unit = match.group(1)

    # Regularity check
    if is_graph:
        if n > 1:
            dx_vals = np.diff(x)
            if np.allclose(dx_vals, dx_vals[0]):
                res = cls(y, x0=float(x[0]), dx=float(dx_vals[0]), unit=unit, name=name)
            else:
                if "Frequency" in cls.__name__:
                    res = cls(y, frequencies=x, unit=unit, name=name)
                else:
                    res = cls(y, times=x, unit=unit, name=name)
        else:
            res = cls(y, x0=float(x[0]) if n == 1 else 0, unit=unit, name=name)

        if return_error:
            from typing import cast
            # Create a matching series for error
            if "Frequency" in cls.__name__:
                err_res = cls(cast(Any, ey), frequencies=x, unit=unit, name=f"{name}_error")
            else:
                err_res = cls(cast(Any, ey), times=x, unit=unit, name=f"{name}_error")
            return res, err_res
        return res
    else:
        # is_hist: Already returned above for Histogram class,
        # but for other classes we need a fallback or error.
        # Currently the logic was mixed. Let's make it consistent.
        raise NotImplementedError("TH1 to non-Histogram class conversion not fully implemented yet.")


def to_tmultigraph(collection, name: Optional[str] = None) -> Any:
    """Convert a collection of series to a ROOT ``TMultiGraph``."""
    ROOT = require_optional("ROOT")
    mg = ROOT.TMultiGraph()
    title = name or getattr(collection, "name", "multigraph")
    mg.SetName(str(title))
    mg.SetTitle(str(title))

    # Handle dict or list
    if hasattr(collection, "items"):
        items = collection.items()
    else:
        items = enumerate(collection)

    for i, (key, series) in enumerate(items):
        if hasattr(series, "to_tgraph"):
            g = series.to_tgraph()
        else:
            g = to_tgraph(series)

        # Set default colors (ROOT color cycle: 1=Black, 2=Red, 3=Green, 4=Blue, ...)
        # Skip 0 (White) and handle large i
        color = (i % 9) + 1
        g.SetLineColor(color)
        g.SetMarkerColor(color)

        # Ensure it has a meaningful name in the legend
        if g.GetName() in ["graph", ""]:
            g.SetName(str(key))
            g.SetTitle(str(key))

        mg.Add(g)

    return mg


def write_root_file(collection, filename: str, **kwargs: Any) -> None:
    """Write a collection of series to a ROOT ``TFile``."""
    ROOT = require_optional("ROOT")
    mode = kwargs.get("mode", "recreate")

    # Save current directory to restore later
    old_dir = ROOT.gDirectory.GetDirectory("")

    f = ROOT.TFile.Open(filename, mode)
    if not f or f.IsZombie():
        raise OSError(f"Failed to open {filename} for writing")

    if hasattr(collection, "items"):
        items = collection.items()
    else:
        items = enumerate(collection)

    for key, series in items:
        if hasattr(series, "to_th1d"):
            obj = series.to_th1d()
        elif hasattr(series, "to_th2d"):
            obj = series.to_th2d()
        elif hasattr(series, "to_tgraph"):
            obj = series.to_tgraph()
        else:
            obj = to_tgraph(series)

        # Determine a good name for the object in the ROOT file
        obj_name = str(key)
        if isinstance(key, int):
            # For lists, try to use the object's own name if it has one
            obj_name = getattr(series, "name", None) or str(key)

        obj.SetName(str(obj_name))
        obj.Write()

    f.Close()
    if old_dir:
        old_dir.cd()
