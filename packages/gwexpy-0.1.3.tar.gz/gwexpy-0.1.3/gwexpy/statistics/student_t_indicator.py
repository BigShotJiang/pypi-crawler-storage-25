"""gwexpy.statistics.student_t_indicator - Student-t indicator for non-Gaussianity."""
from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

try:
    from scipy import stats
except ImportError as _exc:
    raise ImportError(
        "scipy is required for gwexpy.statistics. Install with: pip install scipy"
    ) from _exc

from ..spectrogram import Spectrogram

if TYPE_CHECKING:
    from ..timeseries import TimeSeries


def compute_student_t_nu(
    ts: TimeSeries,
    fftlength: float,
    stride: float | None = None,
    window: int = 40,
    overlap: float | None = None,
    frange: tuple[float, float] | None = None,
) -> Spectrogram:
    """Compute Student-t degree of freedom (nu) for non-Gaussianity detection.

    Nu -> infinity for Gaussian, small nu (e.g., < 10) for non-Gaussian.

    Parameters
    ----------
    ts : TimeSeries
        Input time series to analyze.
    fftlength : float
        FFT segment length in seconds.
    stride : float, optional
        Step between adjacent FFT windows in seconds.
    window : int, default=40
        Number of STFT segments per Student-t fit window.
    overlap : float, optional
        Overlap between adjacent FFT windows in seconds.
    frange : (float, float), optional
        Frequency range (low, high) in Hz to limit computation.

    Returns
    -------
    Spectrogram
        Spectrogram of estimated Student-t ``nu`` values.

    """
    if stride is None:
        if overlap is None:
            stride = fftlength
        else:
            stride = fftlength - overlap

    # 1. Compute FFT segments
    # Actually, we can use ts.spectrogram with 'complex' return if possible,
    # but gwpy's spectrogram normally returns real PSD.
    # We need the complex FFT coefficients.

    fs = ts.sample_rate.value
    nfft = int(fftlength * fs)
    nstep = int(stride * fs)

    # Simple STFT to get complex values
    # shape (n_freqs, n_times)
    from scipy.signal import stft
    f, t, Zxx = stft(
        ts.value,
        fs=fs,
        nperseg=nfft,
        noverlap=nfft - nstep,
        return_onesided=True,
    )
    # Zxx shape: (n_freqs, n_times)

    n_freqs, n_times = Zxx.shape

    # Apply frequency range restriction to limit computation
    if frange is not None:
        flo, fhi = frange
        freq_mask = (f >= flo) & (f <= fhi)
        f = f[freq_mask]
        Zxx = Zxx[freq_mask, :]
        n_freqs = f.size

    if n_times < window:
        raise ValueError(f"Too few segments ({n_times}) for window size {window}.")

    n_out = n_times - window + 1
    nu_map = np.zeros((n_out, n_freqs))

    for i in range(n_out):
        for j in range(n_freqs):
            # Complex FFT values for this frequency bin over the window
            # Zxx is (freq, time)
            segments = Zxx[j, i : i + window]

            # Use real and imaginary parts as independent samples
            samples = np.concatenate([np.real(segments), np.imag(segments)])

            # Fit Student-t distribution
            # scipy.stats.t.fit(data) returns (nu, loc, scale)
            # nu = degree of freedom
            try:
                nu, _, _ = stats.t.fit(samples)
                nu_map[i, j] = nu
            except Exception:
                nu_map[i, j] = np.nan

    # Center times
    out_times = t[window // 2 : window // 2 + n_out]

    return Spectrogram(
        nu_map,
        times=out_times,
        frequencies=f,
        unit="",
        name="student_t_nu",
    )
