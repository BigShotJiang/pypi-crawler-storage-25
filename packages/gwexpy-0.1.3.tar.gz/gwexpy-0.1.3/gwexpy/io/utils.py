from __future__ import annotations

import contextlib
import datetime as _dt
import importlib
import math
import warnings
from collections.abc import Iterable
from pathlib import Path
from typing import Any, cast
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import numpy as np
from astropy import units as u
from gwpy.time import to_gps


def parse_timezone(tz: Any) -> _dt.tzinfo:
    r"""Convert a timezone specifier into a tzinfo.

    Accepts IANA zone names (\"Asia/Tokyo\") or numeric offsets like \"+09:00\".
    """
    if tz is None:
        raise ValueError("timezone must be specified for this format")
    if isinstance(tz, _dt.tzinfo):
        return tz
    if isinstance(tz, (int, float)):
        return _dt.timezone(_dt.timedelta(hours=float(tz)))
    if isinstance(tz, str):
        with contextlib.suppress(ZoneInfoNotFoundError):
            return ZoneInfo(tz)
        # parse \"+09:00\" or \"-0800\"
        cleaned = tz.strip()
        if cleaned.lower() in {"utc", "gmt"}:
            return _dt.UTC
        sign = 1
        if cleaned.startswith("-"):
            sign = -1
            cleaned = cleaned[1:]
        elif cleaned.startswith("+"):
            cleaned = cleaned[1:]
        if ":" in cleaned:
            hours, minutes = cleaned.split(":", 1)
        else:
            hours, minutes = cleaned[:2], cleaned[2:] or "0"
        try:
            delta = _dt.timedelta(hours=sign * int(hours), minutes=sign * int(minutes))
            return _dt.timezone(delta)
        except (
            ValueError,
            TypeError,
            OverflowError,
        ) as exc:  # pragma: no cover - defensive
            raise ValueError(f"Could not parse timezone {tz!r}") from exc
    raise ValueError(f"Unsupported timezone specifier: {tz!r}")


def datetime_to_gps(dt: _dt.datetime) -> float:
    """Convert an aware datetime or date into a LIGO GPS float."""
    if isinstance(dt, _dt.date) and not isinstance(dt, _dt.datetime):
        dt = _dt.datetime.combine(dt, _dt.time(0, 0), tzinfo=_dt.UTC)
    if dt.tzinfo is None:
        raise ValueError("datetime must be timezone-aware to convert to GPS")
    return float(to_gps(dt))


def ensure_datetime(value: Any, tzinfo: _dt.tzinfo | None = None) -> _dt.datetime:
    """Parse a timestamp into a timezone-aware datetime.

    Tries common formats like ``YYYY/MM/DD HH:MM:SS(.fff)``.
    """
    if isinstance(value, _dt.datetime):
        if value.tzinfo is None and tzinfo is not None:
            return value.replace(tzinfo=tzinfo)
        if value.tzinfo is None:
            raise ValueError("Naive datetime requires timezone")
        return value
    if isinstance(value, (int, float)):
        return _dt.datetime.fromtimestamp(float(value), tz=_dt.UTC)
    if isinstance(value, str):
        text = value.strip()
        formats = [
            "%Y/%m/%d %H:%M:%S.%f",
            "%Y/%m/%d %H:%M:%S",
            "%Y-%m-%d %H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d,%H:%M:%S",
        ]
        for fmt in formats:
            with contextlib.suppress(ValueError):
                dt = _dt.datetime.strptime(text, fmt)
                if dt.tzinfo is None and tzinfo is not None:
                    dt = dt.replace(tzinfo=tzinfo)
                return dt
    raise ValueError(f"Unrecognised time value: {value!r}")


def apply_unit(series: Any, unit: Any | None) -> Any:
    """Override the unit on a series-like object if requested."""
    if unit is None:
        return series
    if unit == "":
        return series
    try:
        from gwexpy.interop._registry import ConverterRegistry

        SeriesMatrix = ConverterRegistry.get_constructor("SeriesMatrix")
        series_matrix_types: tuple[type, ...] = (SeriesMatrix,)
    except (ImportError, KeyError, AttributeError, TypeError):
        series_matrix_types = ()
    if isinstance(series, series_matrix_types):
        series_obj = cast(Any, series)
        try:
            for i in range(series_obj.meta.shape[0]):
                for j in range(series_obj.meta.shape[1]):
                    series_obj.meta[i, j]["unit"] = u.Unit(unit)
            return series_obj
        except (KeyError, IndexError, AttributeError):
            pass
    # GWpy series objects keep `.unit` immutable after construction, but
    # provide `override_unit()` for metadata-only changes.
    with contextlib.suppress(AttributeError, TypeError, ValueError):
        if hasattr(series, "override_unit"):
            series.override_unit(unit)
            return series
    try:
        series.unit = u.Unit(unit)
        return series
    except (AttributeError, TypeError):
        # fallback to constructor
        try:
            return series.__class__(
                series.value,
                times=getattr(series, "times", None),
                dt=getattr(series, "dt", None),
                t0=getattr(series, "t0", None),
                frequencies=getattr(series, "frequencies", None),
                df=getattr(series, "df", None),
                f0=getattr(series, "f0", None),
                unit=unit,
                channel=getattr(series, "channel", None),
                name=getattr(series, "name", None),
                epoch=getattr(series, "epoch", None),
            )
        except (TypeError, ValueError) as exc:  # pragma: no cover - defensive
            raise ValueError(f"Could not apply unit {unit!r}") from exc


def set_provenance(obj: Any, info: dict[str, Any]) -> None:
    """Attach provenance metadata to a gwexpy or gwpy object."""
    try:
        if hasattr(obj, "attrs") and isinstance(obj.attrs, dict):
            obj.attrs.update(info)
            return
    except (TypeError, AttributeError):
        pass
    with contextlib.suppress(AttributeError, TypeError):
        setattr(obj, "_gwexpy_io", {**info})


def filter_by_channels(mapping: dict[str, Any], channels: Iterable[str] | None):
    """Return a mapping filtered by selected channel names."""
    if channels is None:
        return mapping
    wanted = set(channels)
    return {k: v for k, v in mapping.items() if k in wanted}


def _ceil_nonnegative_sample_count(value: Any) -> int:
    """Return a conservative non-negative sample count for float spans."""
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return 0
    if numeric <= 0:
        return 0
    return int(math.ceil(numeric - 1e-12))


def _pad_gwf_series_to_span(
    ts: Any,
    pad: Any,
    start: Any | None = None,
    end: Any | None = None,
    *,
    error: bool = False,
) -> Any:
    """Pad or reject a GWF series that does not cover the requested interval."""
    span = ts.span
    if start is None:
        start = span[0]
    if end is None:
        end = span[1]

    rate = ts.sample_rate.value
    pada = _ceil_nonnegative_sample_count((span[0] - start) * rate)
    padb = _ceil_nonnegative_sample_count((end - span[1]) * rate)
    if not (pada or padb):
        return ts
    if error:
        msg = (
            f"{type(ts).__name__} with span {span} does not cover "
            f"requested interval {type(span)(start, end)}"
        )
        raise ValueError(msg)
    return ts.pad((pada, padb), mode="constant", constant_values=(pad,))


def maybe_pad_timeseries(ts, pad_value=np.nan, start=None, end=None, gap="pad"):
    """Pad gaps or raise using gwpy join semantics."""
    if gap not in ("pad", "raise"):
        return ts

    return _pad_gwf_series_to_span(
        ts,
        pad_value,
        start=start,
        end=end,
        error=(gap == "raise"),
    )


def ensure_dependency(
    package_name: str,
    *,
    extra: str | None = None,
    import_name: str | None = None,
) -> Any:
    """Import a package or raise a standardized ImportError.

    Parameters
    ----------
    package_name : str
        PyPI package name (for pip install instructions).
    extra : str, optional
        Optional extras specifier (e.g., "gui", "analysis").
    import_name : str, optional
        Import name if different from package_name.

    Returns
    -------
    module
        The imported module.

    Raises
    ------
    ImportError
        With standardized installation instructions.

    Examples
    --------
    >>> xarray = ensure_dependency("xarray")  # doctest: +SKIP
    >>> nptdms = ensure_dependency("nptdms", import_name="nptdms")  # doctest: +SKIP

    """
    try:
        name = import_name or package_name
        return importlib.import_module(name)
    except ImportError as exc:
        if extra:
            install_cmd = f"pip install 'gwexpy[{extra}]'"
        else:
            install_cmd = f"pip install {package_name}"
        msg = f"{package_name} is required. Install with: {install_cmd}"
        raise ImportError(msg) from exc


def extract_audio_metadata(source: str | Path) -> dict[str, Any]:
    """Extract audio metadata using tinytag.

    Attempts to read common audio metadata fields (title, artist, album, genre,
    duration, bitrate, etc.) from audio files. Returns an empty dictionary if
    tinytag is not installed or if metadata extraction fails.

    Parameters
    ----------
    source : str or Path
        Path to the audio file.

    Returns
    -------
    dict
        Dictionary of metadata fields. Only non-None values are included.
        Possible keys: title, artist, album, genre, duration, bitrate,
        comment, track, year.

    Notes
    -----
    Requires the optional ``tinytag`` package. Install it via a GWexpy extra::

        pip install 'gwexpy[audio]'

    Or install the bundled optional dependencies used by GWexpy tutorials::

        pip install "gwexpy[all]"

    Examples
    --------
    >>> metadata = extract_audio_metadata("song.mp3")  # doctest: +SKIP
    >>> print(metadata.get("title"))  # doctest: +SKIP
    'Song Title'

    """
    try:
        from tinytag import TinyTag

        tag = TinyTag.get(str(source))
        metadata = {
            "title": tag.title,
            "artist": tag.artist,
            "album": tag.album,
            "genre": tag.genre,
            "duration": tag.duration,
            "bitrate": tag.bitrate,
            "comment": tag.comment,
            "track": tag.track,
            "year": tag.year,
        }
        # Filter out None values
        return {k: v for k, v in metadata.items() if v is not None}
    except ImportError:
        warnings.warn(
            "tinytag is required for metadata extraction. "
            "Install with: pip install 'gwexpy[audio]' "
            'or pip install "gwexpy[all]"',
            UserWarning,
            stacklevel=3,
        )
        return {}
    except Exception as e:
        # Metadata extraction failure should not break file reading
        warnings.warn(
            f"Failed to extract metadata: {e}",
            UserWarning,
            stacklevel=3,
        )
        return {}
