from __future__ import annotations

from gwpy.types.series import Series as GwpySeries

from ._stats import StatisticalMethodsMixin

__all__ = ["Series"]


class Series(StatisticalMethodsMixin, GwpySeries):
    """1D series with unified statistical methods."""

    pass


# Dynamic import from gwpy (to keep other symbols if any)
# But usually series.py just has Series and some helpers.
