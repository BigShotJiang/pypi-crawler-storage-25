from __future__ import annotations

import logging
import pickle
import warnings
from collections import OrderedDict
from copy import deepcopy
from typing import TYPE_CHECKING, Any, Optional, SupportsIndex, cast

import numpy as np
from astropy import units as u

from gwexpy.types.mixin import InteropMixin, RegularityMixin

from ._stats import StatisticalMethodsMixin
from .metadata import MetaData, MetaDataDict, MetaDataMatrix

if TYPE_CHECKING:
    from gwexpy.types.typing import IndexLike, MetaDataCollectionType, UnitLike
from .series_matrix_analysis import SeriesMatrixAnalysisMixin
from .series_matrix_core import SeriesMatrixCoreMixin
from .series_matrix_indexing import SeriesMatrixIndexingMixin
from .series_matrix_io import SeriesMatrixIOMixin
from .series_matrix_math import SeriesMatrixMathMixin
from .series_matrix_structure import SeriesMatrixStructureMixin
from .series_matrix_validation_mixin import SeriesMatrixValidationMixin
from .series_matrix_visualization import SeriesMatrixVisualizationMixin
from .seriesmatrix_validation import (
    _check_attribute_consistency,
    _check_shape_consistency,
    _fill_missing_attributes,
    _make_meta_matrix,
    _normalize_input,
    build_index_if_needed,
    check_add_sub_compatibility,
    check_shape_xindex_compatibility,
)

logger = logging.getLogger(__name__)

_SERIESMATRIX_PICKLE_METADATA_FIELDS = (
    "_xindex",
    "meta",
    "rows",
    "cols",
    "name",
    "epoch",
    "attrs",
)

_ADD_SUB_COMPARISON_UFUNCS = {
    np.add,
    np.subtract,
    np.less,
    np.less_equal,
    np.equal,
    np.not_equal,
    np.greater,
    np.greater_equal,
}


class _UnsetType:
    """Sentinel type for omitted constructor arguments."""


_UNSET = _UnsetType()


def _copy_xindex(xindex: Any) -> Any:
    """Copy an x-axis index without assuming a specific index implementation."""
    if xindex is None:
        return None
    try:
        return xindex.copy()
    except (IndexError, KeyError, TypeError, ValueError, AttributeError):
        return deepcopy(xindex)


def _copy_metadata_matrix(meta: MetaDataMatrix) -> MetaDataMatrix:
    """Deep-copy a metadata matrix and its per-cell metadata entries."""
    return MetaDataMatrix(deepcopy(np.asarray(meta, dtype=object)))


def _copy_metadata_dict(meta: MetaDataDict, key_prefix: str) -> MetaDataDict:
    """Deep-copy row or column metadata while preserving keys."""
    items = OrderedDict()
    for key, value in meta.items():
        items[key] = MetaData(**deepcopy(dict(value)))
    return MetaDataDict(items, expected_size=len(items), key_prefix=key_prefix)


def _pickle_safe_attrs(attrs: Any, protocol: int) -> dict[str, Any]:
    """Return attrs entries that can be serialized by pickle."""
    if not isinstance(attrs, dict):
        return {}
    safe_attrs = {}
    for key, value in attrs.items():
        try:
            pickle.dumps((key, value), protocol=protocol)
        except Exception:
            continue
        safe_attrs[key] = value
    return safe_attrs


class PerformanceWarning(RuntimeWarning):
    """Warning raised when an operation falls back to a slower implementation."""

    pass


class SeriesMatrix(  # type: ignore[misc]
    RegularityMixin,
    InteropMixin,
    SeriesMatrixCoreMixin,
    SeriesMatrixIndexingMixin,
    SeriesMatrixIOMixin,
    SeriesMatrixMathMixin,
    SeriesMatrixAnalysisMixin,
    SeriesMatrixStructureMixin,
    SeriesMatrixVisualizationMixin,
    SeriesMatrixValidationMixin,
    StatisticalMethodsMixin,
    np.ndarray,
):
    """N-dimensional matrix of aligned series values with per-cell metadata."""

    def __new__(
        cls,
        data: Any = None,
        *,
        meta: MetaDataMatrix | np.ndarray | list | None = None,
        unit: object | None = None,
        units: np.ndarray | object | None = None,
        names: np.ndarray | None = None,
        channels: np.ndarray | None = None,
        rows: MetaDataCollectionType = None,
        cols: MetaDataCollectionType = None,
        shape: tuple[int, ...] | None = None,
        xindex: IndexLike | None = None,
        dx: u.Quantity | None = None,
        x0: u.Quantity | None = None,
        xunit: UnitLike = None,
        name: str | _UnsetType = _UNSET,
        epoch: float | _UnsetType = _UNSET,
        attrs: dict[str, Any] | None | _UnsetType = _UNSET,
    ) -> SeriesMatrix:
        """Create a SeriesMatrix with normalized inputs and metadata."""
        if unit is not None:
            if units is not None:
                raise ValueError("give only one of unit or units")
            units = unit

        source_matrix = data if isinstance(data, SeriesMatrix) else None
        explicit_units = units is not None
        explicit_names = names is not None
        explicit_channels = channels is not None

        if xindex is not None and xunit is not None:
            try:
                xindex = u.Quantity(xindex, xunit)
            except (TypeError, ValueError, AttributeError) as e:
                # xunit implies the caller intended a unit conversion; warn and continue
                # so that downstream code still has the raw xindex to work with.
                logger.warning("SeriesMatrix xindex conversion failed: %s", e)

        value_array, data_attrs, detected_xindex = _normalize_input(
            data=data,
            units=units,
            names=names,
            channels=channels,
            shape=shape,
            xindex=xindex,
            dx=dx,
            x0=x0,
            xunit=xunit,
        )

        if meta is None and source_matrix is not None:
            meta_matrix = _copy_metadata_matrix(source_matrix.meta)
            if explicit_units:
                meta_matrix.units = data_attrs["unit"]
            if explicit_names:
                meta_matrix.names = data_attrs["name"]
            if explicit_channels:
                meta_matrix.channels = data_attrs["channel"]
        else:
            if meta is not None:
                if not isinstance(meta, MetaDataMatrix):
                    try:
                        meta = MetaDataMatrix(meta)
                    except (TypeError, ValueError) as e:
                        raise TypeError(
                            "meta must be a MetaDataMatrix or a 2D array-like of MetaData/dict"
                        ) from e
                if units is None:
                    data_attrs["unit"] = None
                if names is None:
                    data_attrs["name"] = None
                if channels is None:
                    data_attrs["channel"] = None
                _check_attribute_consistency(data_attrs=data_attrs, meta=meta)
                units_arr, names_arr, channels_arr = _fill_missing_attributes(
                    data_attrs=data_attrs, meta=meta
                )
            else:
                units_arr = data_attrs.get("unit", None)
                names_arr = data_attrs.get("name", None)
                channels_arr = data_attrs.get("channel", None)

            meta_matrix = _make_meta_matrix(
                shape=value_array.shape[:2],
                units=units_arr,
                names=names_arr,
                channels=channels_arr,
            )

        if xindex is None:
            if detected_xindex is not None:
                xindex = (
                    _copy_xindex(detected_xindex)
                    if source_matrix is not None
                    else detected_xindex
                )
            else:
                if value_array.shape[2] == 0 and dx is None and x0 is None:
                    xindex = np.asarray([])
                else:
                    xindex = build_index_if_needed(
                        xindex=None,
                        dx=dx,
                        x0=x0,
                        xunit=xunit,
                        length=value_array.shape[2],
                    )

        _check_shape_consistency(
            value_array=value_array,
            meta_matrix=meta_matrix,
            xindex=cast(Optional[np.ndarray], xindex),
        )

        obj = np.asarray(value_array).view(cls)

        obj._value = obj.view(np.ndarray)

        obj.meta = meta_matrix
        N, M = value_array.shape[:2]
        if source_matrix is not None:
            if rows is None and getattr(source_matrix, "rows", None) is not None:
                rows = _copy_metadata_dict(source_matrix.rows, "row")
            if cols is None and getattr(source_matrix, "cols", None) is not None:
                cols = _copy_metadata_dict(source_matrix.cols, "col")
        if isinstance(rows, dict) and not isinstance(rows, OrderedDict):
            rows = OrderedDict(rows)
        if isinstance(cols, dict) and not isinstance(cols, OrderedDict):
            cols = OrderedDict(cols)
        if name is _UNSET:
            name = (
                getattr(source_matrix, "name", "") if source_matrix is not None else ""
            )
        if epoch is _UNSET:
            epoch = (
                getattr(source_matrix, "epoch", 0.0)
                if source_matrix is not None
                else 0.0
            )
        if attrs is _UNSET:
            attrs = (
                deepcopy(getattr(source_matrix, "attrs", {}))
                if source_matrix is not None
                else {}
            )
        elif attrs is None:
            attrs = {}
        obj.rows = MetaDataDict(cast(Any, rows), expected_size=N, key_prefix="row")
        obj.cols = MetaDataDict(cast(Any, cols), expected_size=M, key_prefix="col")
        obj.xindex = xindex
        obj.name = cast(str, name)
        obj.epoch = cast(float, epoch)
        obj.attrs = cast(dict[str, Any], attrs) or {}

        return obj

    def __array_finalize__(self, obj: Any) -> None:
        if obj is None:
            return
        self._value = self.view(np.ndarray)
        self._suppress_xindex_check = True
        self.xindex = getattr(obj, "xindex", None)
        if hasattr(self, "_suppress_xindex_check"):
            delattr(self, "_suppress_xindex_check")
        from typing import cast

        from gwexpy.types.metadata import MetaDataDict, MetaDataMatrix

        self.meta = cast(MetaDataMatrix, getattr(obj, "meta", None))
        self.rows = cast(MetaDataDict, getattr(obj, "rows", None))
        self.cols = cast(MetaDataDict, getattr(obj, "cols", None))
        self.name = getattr(obj, "name", "")
        self.epoch = getattr(obj, "epoch", 0.0)
        self.attrs = getattr(obj, "attrs", getattr(self, "attrs", {}))

        # Propagate custom _gwex_ attributes
        for key, val in getattr(obj, "__dict__", {}).items():
            if key.startswith("_gwex_") and key not in self.__dict__:
                self.__dict__[key] = val

    def _reduce_with_protocol(self, protocol: int) -> tuple[Any, ...]:
        """Include SeriesMatrix metadata in ndarray-subclass pickle state."""
        picked = list(np.ndarray.__reduce__(self))
        matrix_state = {
            key: _pickle_safe_attrs(value, protocol) if key == "attrs" else value
            for key, value in self.__dict__.items()
            if key in _SERIESMATRIX_PICKLE_METADATA_FIELDS
        }
        base_state = picked[2] if isinstance(picked[2], tuple) else ()
        picked[2] = base_state + (matrix_state,)
        return tuple(picked)

    def __reduce_ex__(self, protocol: SupportsIndex) -> tuple[Any, ...]:
        """Include SeriesMatrix metadata using the active pickle protocol."""
        reducer = type(self).__reduce__
        if reducer is not SeriesMatrix.__reduce__:
            return cast(Any, reducer)(self)
        return self._reduce_with_protocol(protocol.__index__())

    def __reduce__(self) -> tuple[Any, ...]:
        """Include SeriesMatrix metadata for legacy pickle callers."""
        return self._reduce_with_protocol(pickle.DEFAULT_PROTOCOL)

    def __setstate__(self, state: tuple[Any, ...]) -> None:
        """Restore SeriesMatrix metadata from pickle state."""
        if state and isinstance(state[-1], dict):
            matrix_state = state[-1]
            ndarray_state = state[:-1]
        else:
            matrix_state = {}
            ndarray_state = state
        super().__setstate__(ndarray_state)
        self.__dict__.update(matrix_state)
        self._value = self.view(np.ndarray)

    def __array_ufunc__(
        self, ufunc: Any, method: str, *inputs: Any, **kwargs: Any
    ) -> Any:
        if method != "__call__":
            base_inputs = [
                inp.view(np.ndarray) if isinstance(inp, SeriesMatrix) else inp
                for inp in inputs
            ]
            try:
                method_literal = cast(Any, method)
                return np.ndarray.__array_ufunc__(
                    self.view(np.ndarray),
                    ufunc,
                    method_literal,
                    *base_inputs,
                    **kwargs,
                )
            except (IndexError, KeyError, TypeError, ValueError, AttributeError):
                return NotImplemented

        casted_inputs = []
        xindex = self.xindex
        shape = self._value.shape
        rows = self.rows
        cols = self.cols
        epoch = getattr(self, "epoch", 0.0)
        name = getattr(self, "name", "")
        attrs = getattr(self, "attrs", {})

        for inp in inputs:
            if isinstance(inp, SeriesMatrix):
                casted_inputs.append(inp)
            elif isinstance(inp, u.Quantity):
                val = np.asarray(inp.value)
                N, M, K = shape
                if val.ndim == 0:
                    arr = np.full(shape, val)
                elif val.ndim == 1:
                    if val.shape != (K,):
                        raise ValueError(
                            f"1D Quantity must have length N_samples={K}, got {val.shape}"
                        )
                    arr = np.broadcast_to(val.reshape(1, 1, K), shape)
                elif val.ndim == 2:
                    if val.shape != (N, M):
                        raise ValueError(
                            f"2D Quantity must have shape (Nrow,Ncol)={(N, M)}, got {val.shape}"
                        )
                    arr = np.broadcast_to(val.reshape(N, M, 1), shape)
                elif val.ndim == 3:
                    if val.shape != shape:
                        raise ValueError(
                            f"3D Quantity must have shape {shape}, got {val.shape}"
                        )
                    arr = val
                else:
                    raise ValueError(
                        f"Quantity with ndim={val.ndim} is not supported in __array_ufunc__"
                    )
                unit = inp.unit
                meta_array = np.empty(self._value.shape[:2], dtype=object)
                for i in range(self._value.shape[0]):
                    for j in range(self._value.shape[1]):
                        meta_array[i, j] = MetaData(unit=unit, name=f"s{i}{j}")
                meta_matrix = MetaDataMatrix(meta_array)
                casted_inputs.append(
                    self.__class__(
                        arr, xindex=xindex, meta=meta_matrix, shape=self._value.shape
                    )
                )
            elif isinstance(inp, (float, int, complex)):
                arr = np.full(self._value.shape, inp)
                unit = u.dimensionless_unscaled
                meta_array = np.empty(self._value.shape[:2], dtype=object)
                for i in range(self._value.shape[0]):
                    for j in range(self._value.shape[1]):
                        meta_array[i, j] = MetaData(unit=unit, name=f"s{i}{j}")
                meta_matrix = MetaDataMatrix(meta_array)
                casted_inputs.append(
                    self.__class__(
                        arr, xindex=xindex, meta=meta_matrix, shape=self._value.shape
                    )
                )
            elif isinstance(inp, np.ndarray):
                val = np.asarray(inp)
                N, M, K = shape
                if val.ndim == 0:
                    arr = np.full(shape, val)
                elif val.ndim == 1:
                    if val.shape != (K,):
                        raise ValueError(
                            f"1D ndarray must have length N_samples={K}, got {val.shape}"
                        )
                    arr = np.broadcast_to(val.reshape(1, 1, K), shape)
                elif val.ndim == 2:
                    if val.shape != (N, M):
                        raise ValueError(
                            f"2D ndarray must have shape (Nrow,Ncol)={(N, M)}, got {val.shape}"
                        )
                    arr = np.broadcast_to(val.reshape(N, M, 1), shape)
                elif val.ndim == 3:
                    if val.shape != shape:
                        raise ValueError(
                            f"3D ndarray must have shape {shape}, got {val.shape}"
                        )
                    arr = val
                else:
                    raise ValueError(
                        f"ndarray with ndim={val.ndim} is not supported in __array_ufunc__"
                    )

                casted_inputs.append(
                    self.__class__(arr, xindex=xindex, shape=self._value.shape)
                )
            else:
                return NotImplemented

        check_shape_xindex_compatibility(*casted_inputs)

        if ufunc in _ADD_SUB_COMPARISON_UFUNCS:
            check_add_sub_compatibility(*casted_inputs)

        value_arrays = [inp.view(np.ndarray) for inp in casted_inputs]

        meta_matrices = [inp.meta for inp in casted_inputs]

        ufunc_kwargs = {k: v for k, v in kwargs.items() if k not in ("out", "where")}

        N, M = self._value.shape[:2]
        logical_ufuncs = {
            np.logical_and,
            np.logical_or,
            np.logical_xor,
            np.logical_not,
            np.isfinite,
            np.isinf,
            np.isnan,
            np.isclose,
        }
        meta_passthrough_ufuncs = logical_ufuncs | {
            np.sign,
            np.floor,
            np.ceil,
            np.trunc,
            np.rint,
            np.mod,
            np.remainder,
            np.clip,
        }
        ufunc_name = getattr(ufunc, "__name__", None)
        meta_passthrough = ufunc in meta_passthrough_ufuncs or ufunc_name in {"clip"}
        result_dtype = np.dtype(self._value.dtype)
        try:
            probe_val_args = [v[0, 0] for v in value_arrays]
            probe_result = ufunc(*probe_val_args, **ufunc_kwargs)
            boolean_ufuncs = {
                np.less,
                np.less_equal,
                np.equal,
                np.not_equal,
                np.greater,
                np.greater_equal,
                np.logical_and,
                np.logical_or,
                np.logical_xor,
                np.logical_not,
                np.isfinite,
                np.isinf,
                np.isnan,
                np.isclose,
            }
            if ufunc in boolean_ufuncs:
                result_dtype = np.dtype(np.bool_)
            else:
                result_dtype = np.asarray(probe_result).dtype
        except (IndexError, KeyError, TypeError, ValueError, AttributeError):
            result_dtype = np.dtype(self._value.dtype)

        # Vectorized value calculation
        try:
            result_values = ufunc(*value_arrays, **ufunc_kwargs)
        except (TypeError, ValueError, AttributeError, RuntimeError) as e:
            # Fallback to loop if vectorized call fails (likely due to custom ufunc or mixed types)
            warnings.warn(
                f"ufunc {ufunc.__name__} failed vectorized execution; falling back to loop. Error: {e}",
                PerformanceWarning,
            )
            result_values = np.empty(self._value.shape, dtype=result_dtype)
            for i in range(N):
                for j in range(M):
                    val_args = [v[i, j] for v in value_arrays]
                    result_values[i, j] = ufunc(*val_args, **ufunc_kwargs)

        result_meta = np.empty(self._value.shape[:2], dtype=object)
        bool_result = np.issubdtype(result_dtype, np.bool_)

        # Optimize Metadata calculation
        # If all input matrices have uniform units, we can avoid the loop
        def _get_uniform_meta(meta_mat):
            first = meta_mat[0, 0]
            # Check if all elements are effectively the same in terms of ufunc result
            # For simplicity, we check if all have the same unit.
            if np.all(meta_mat.units == first.unit):
                return first
            return None

        uniform_metas = [_get_uniform_meta(m) for m in meta_matrices]
        all_uniform = all(m is not None for m in uniform_metas)

        if all_uniform and not (bool_result or meta_passthrough):
            try:
                # Compute resulting meta once
                res_meta_obj = ufunc(*uniform_metas, **ufunc_kwargs)
                result_meta = np.full((N, M), res_meta_obj, dtype=object)
            except (AttributeError, RuntimeError, TypeError, ValueError) as e:
                # Optimize: vectorized meta-ufunc failed, use fallback
                logger.exception(
                    "MetaData ufunc optimization failed; using element-wise calculation."
                )
                warnings.warn(
                    f"MetaData ufunc optimization failed: {e}. Using element-wise calculation.",
                    PerformanceWarning,
                )
                all_uniform = False

        if not all_uniform:
            try:
                if bool_result or meta_passthrough:
                    # In these cases, we typically take the first operand's metadata
                    result_meta = meta_matrices[0].copy()
                else:
                    # Leverage MetaDataMatrix's vectorized ufunc support
                    result_meta = ufunc(*meta_matrices, **ufunc_kwargs)
            except (AttributeError, RuntimeError, TypeError, ValueError) as e:
                # Fallback to loop if vectorized meta-ufunc fails
                logger.exception(
                    "MetaData vectorized ufunc failed; falling back to loop."
                )
                warnings.warn(
                    f"MetaData vectorized ufunc failed; falling back to loop. Error: {e}",
                    PerformanceWarning,
                )
                result_meta = np.empty((N, M), dtype=object)
                for i in range(N):
                    for j in range(M):
                        meta_args = [m[i, j] for m in meta_matrices]
                        if bool_result or meta_passthrough:
                            result_meta[i, j] = meta_args[0]
                        else:
                            result_meta[i, j] = ufunc(*meta_args, **ufunc_kwargs)

        result_meta_matrix = MetaDataMatrix(result_meta)
        result_units = result_meta_matrix.units
        return self.__class__(
            result_values,
            xindex=self.xindex,
            meta=result_meta_matrix,
            units=result_units,
            rows=rows,
            cols=cols,
            name=name,
            epoch=epoch,
            attrs=attrs,
        )
