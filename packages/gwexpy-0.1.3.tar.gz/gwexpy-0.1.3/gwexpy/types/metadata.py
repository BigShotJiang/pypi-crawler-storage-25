from __future__ import annotations

import importlib
import warnings
from collections import OrderedDict
from collections.abc import Iterable
from html import escape
from typing import TYPE_CHECKING, Any, cast

import numpy as np

try:
    pd: Any = importlib.import_module("pandas")
except ImportError:
    pd = None

from astropy import units as u
from astropy.units import Unit, UnitConversionError
from gwpy.detector import Channel
from gwpy.types.array import Array
from gwpy.types.series import Series

if TYPE_CHECKING:
    pass

_UFUNC_ABS_REAL = {np.abs, np.negative, np.positive, np.real, np.imag}
_UFUNC_CONJ = {np.conjugate, np.conj}
_UFUNC_TRANSCENDENTAL = {np.exp, np.sin, np.cos, np.log}
_UFUNC_ADD_SUB = {np.add, np.subtract}
_UFUNC_COMPARISON = {
    np.less,
    np.less_equal,
    np.equal,
    np.not_equal,
    np.greater,
    np.greater_equal,
}
_UFUNC_MULT_DIV = {np.multiply, np.divide, np.floor_divide}
from gwpy.frequencyseries import FrequencySeries
from gwpy.timeseries import TimeSeries

# =============================
# MetaData: metadata for a single object (e.g., row/column/parameter)
# =============================


class MetaData(dict):
    """A dictionary-like container for metadata describing a single data object.

    This class serves as the core metadata container for channels, parameters,
    or matrix rows/columns in GWexpy. It ensures type safety and consistency
    for crucial physical attributes, particularly the physical unit.

    Parameters
    ----------
    name : str, optional
        A human-readable name or label (default: "").
    channel : str or gwpy.detector.Channel, optional
        The data channel associated with this metadata (default: "").
    unit : str, astropy.units.UnitBase, or pint.Unit, optional
        The physical unit of the data. Automatically converted to an
        `astropy.units.UnitBase` instance (default: dimensionless).
    **kwargs
        Additional arbitrary metadata key-value pairs.

    Attributes
    ----------
    name : str
        The human-readable name.
    channel : gwpy.detector.Channel
        The associated data channel.
    unit : astropy.units.UnitBase
        The physical unit of the data.

    Examples
    --------
    >>> from gwexpy.types.metadata import MetaData
    >>> from astropy import units as u
    >>> meta = MetaData(name="strain", channel="H1:STRAIN", unit="m")
    >>> meta.unit
    Unit("m")
    >>> meta.name
    'strain'

    Notes
    -----
    When performing arithmetic with `MetaData` instances (e.g., using NumPy ufuncs),
    the `unit` attribute is automatically propagated correctly. For example,
    multiplying two `MetaData` objects will result in a new `MetaData` object
    with the multiplied units.

    """

    def __init__(self, **kwargs):
        kwargs.setdefault("name", "")
        kwargs.setdefault("channel", "")
        kwargs.setdefault("unit", u.dimensionless_unscaled)
        super().__init__(**kwargs)

        try:
            self["channel"] = Channel(self.get("channel"))
        except (ValueError, TypeError):
            self["channel"] = Channel("")

        raw_unit = kwargs.get("unit", u.dimensionless_unscaled)
        try:
            if isinstance(raw_unit, u.UnitBase):
                self["unit"] = raw_unit
            elif isinstance(raw_unit, str):
                self["unit"] = (
                    u.Unit(raw_unit) if raw_unit else u.dimensionless_unscaled
                )
            else:
                self["unit"] = u.Unit(raw_unit)
        except (ValueError, TypeError):
            self["unit"] = u.dimensionless_unscaled

    @property
    def name(self):
        """Return the name of the metadata."""
        return self["name"]

    @name.setter
    def name(self, value):
        self["name"] = value

    @property
    def channel(self):
        """Return the channel name of the metadata."""
        return self["channel"]

    @channel.setter
    def channel(self, value):
        try:
            self["channel"] = Channel(value)
        except (ValueError, TypeError):
            self["channel"] = Channel("")

    @property
    def unit(self):
        """Return the physical unit of the metadata."""
        return self["unit"]

    @unit.setter
    def unit(self, value):
        try:
            if isinstance(value, u.UnitBase):
                self["unit"] = value
            elif isinstance(value, str):
                self["unit"] = u.Unit(value) if value else u.dimensionless_unscaled
            else:
                self["unit"] = u.Unit(value)
        except (ValueError, TypeError):
            self["unit"] = u.dimensionless_unscaled

    @classmethod
    def from_series(cls, series):
        """Create a MetaData instance from a GWpy Series object."""
        return cls(
            name=getattr(series, "name", ""),
            channel=getattr(series, "channel", ""),
            unit=get_unit(series),
        )

    def as_meta(self, obj):
        """Coerce an object into a MetaData instance.

        If *obj* is already a ``MetaData`` instance it is returned unchanged.
        Otherwise a new ``MetaData`` is constructed whose **name** and
        **channel** are inherited from ``self`` and whose **unit** is inferred
        from *obj* via :func:`get_unit`.

        Parameters
        ----------
        obj : MetaData, astropy.Quantity, numeric, or any object with a .unit
            The object to coerce.

        Returns
        -------
        MetaData

        """
        if isinstance(obj, MetaData):
            return obj
        return MetaData(name=self.name, channel=self.channel, unit=get_unit(obj))

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        """NumPy ufunc protocol for unit propagation.

        Unit-checking policy
        --------------------
        * **Strict** (raises ``UnitConversionError``):
          - ``add`` / ``subtract``: both operands must be dimensionally compatible.
          - Transcendental functions (``exp``, ``sin``, ``cos``, ``log``): input
            must be dimensionless.
          - Comparison ufuncs: operands must be dimensionally compatible.
          - ``power``: exponent must be dimensionless (numeric scalar or
            dimensionless ``Quantity``).
        * **Flexible** (unit derived algebraically, no compatibility check):
          - ``multiply``, ``divide``, ``floor_divide``: result unit is
            ``lhs_unit * rhs_unit`` or ``lhs_unit / rhs_unit`` respectively.
            ``floor_divide`` carries the same dimensional result as ``divide``;
            the integer truncation applies only to the numeric value, not the
            unit.
          - ``sqrt``, ``square``: result unit is ``lhs_unit ** 0.5`` or
            ``lhs_unit ** 2``.
          - Unary ``abs``, ``negative``, ``positive``, ``real``, ``imag``,
            ``conjugate``: unit is preserved unchanged.
        """
        if method != "__call__":
            return NotImplemented

        # unary operations
        if len(inputs) == 1:
            lhs = self
            if ufunc in _UFUNC_ABS_REAL:
                return MetaData(name=lhs.name, channel=lhs.channel, unit=lhs.unit)
            if ufunc in _UFUNC_CONJ:
                return MetaData(name=lhs.name, channel=lhs.channel, unit=lhs.unit)
            if ufunc == np.sqrt:
                return MetaData(name=lhs.name, channel=lhs.channel, unit=lhs.unit**0.5)
            if ufunc == np.square:
                return MetaData(name=lhs.name, channel=lhs.channel, unit=lhs.unit**2)
            if ufunc in _UFUNC_TRANSCENDENTAL:
                if not lhs.unit.is_equivalent(1):
                    raise UnitConversionError(
                        f"{ufunc.__name__} requires dimensionless input"
                    )
                return MetaData(
                    name=lhs.name, channel=lhs.channel, unit=u.dimensionless_unscaled
                )
            return NotImplemented

        # binary operations (two or more operands)
        lhs_raw, rhs_raw = inputs

        # power: exponent must stay as a numeric scalar (do not wrap into MetaData)
        if ufunc == np.power:
            lhs = self.as_meta(lhs_raw)
            lhs_unit = get_unit(lhs)

            if isinstance(rhs_raw, (int, float, complex, np.number)):
                exponent = rhs_raw
            elif isinstance(rhs_raw, u.Quantity):
                if not rhs_raw.unit.is_equivalent(1):
                    raise UnitConversionError("Exponent must be dimensionless")
                exponent = rhs_raw.to_value(u.dimensionless_unscaled)
            else:
                raise UnitConversionError("Exponent must be dimensionless")

            base = lhs if isinstance(lhs, MetaData) else self
            return MetaData(
                name=base.name, channel=base.channel, unit=lhs_unit**exponent
            )

        lhs = self.as_meta(lhs_raw)
        rhs = self.as_meta(rhs_raw)
        lhs_unit = get_unit(lhs)
        rhs_unit = get_unit(rhs)

        # addition / subtraction
        if ufunc in _UFUNC_ADD_SUB:
            if not lhs_unit.is_equivalent(rhs_unit):
                raise UnitConversionError(f"{ufunc.__name__} requires compatible units")
            base = lhs if isinstance(lhs, MetaData) else rhs
            return MetaData(name=base.name, channel=base.channel, unit=lhs_unit)

        # comparisons -> dimensionless (bool result)
        if ufunc in _UFUNC_COMPARISON:
            if not lhs_unit.is_equivalent(rhs_unit):
                raise UnitConversionError(f"{ufunc.__name__} requires compatible units")
            base = lhs if isinstance(lhs, MetaData) else rhs
            return MetaData(
                name=base.name, channel=base.channel, unit=u.dimensionless_unscaled
            )

        # multiplication/division
        if ufunc in _UFUNC_MULT_DIV:
            if ufunc == np.multiply:
                new_unit = lhs_unit * rhs_unit
            else:
                new_unit = lhs_unit / rhs_unit
            base = lhs if isinstance(lhs, MetaData) else rhs
            return MetaData(name=base.name, channel=base.channel, unit=new_unit)

        return NotImplemented

    def __abs__(self):
        return np.abs(self)

    def __neg__(self):
        return np.negative(self)

    def __pos__(self):
        return np.positive(self)

    def __add__(self, other):
        return np.add(cast(Any, self), other)

    def __radd__(self, other):
        return np.add(other, cast(Any, self))

    def __sub__(self, other):
        return np.subtract(cast(Any, self), other)

    def __rsub__(self, other):
        return np.subtract(other, cast(Any, self))

    def __mul__(self, other):
        return np.multiply(cast(Any, self), other)

    def __rmul__(self, other):
        return np.multiply(other, cast(Any, self))

    def __truediv__(self, other):
        return np.divide(cast(Any, self), other)

    def __rtruediv__(self, other):
        return np.divide(other, cast(Any, self))

    def __pow__(self, exponent, modulo=None):
        return np.power(cast(Any, self), exponent)

    def __repr__(self):
        keys = ["name", "unit", "channel"]
        summary = ", ".join(f"{k}={self.get(k, '')}" for k in keys)
        return f"({summary})"

    def __str__(self):
        keys = ["name", "unit", "channel"]
        return "\t".join(f"{k:>8}: {self.get(k, '')}" for k in keys)

    def _repr_html_(self):
        keys = ["name", "unit", "channel"]
        html = "<table>"
        for k in keys:
            html += (
                f"<tr><td><b>{k}</b></td><td>{escape(str(self.get(k, '')))}</td></tr>"
            )
        html += "</table>"
        return html


# =============================
# MetaDataDict: ordered mapping from keys to MetaData
# =============================


class MetaDataDict(OrderedDict[str, MetaData]):
    """Ordered dictionary mapping keys to MetaData instances.

    This container enforces that all values are MetaData objects,
    providing a type-safe collection for row/column metadata in
    SeriesMatrix and related classes.
    """

    def __init__(
        self,
        entries: dict | list | pd.DataFrame | MetaDataDict | None = None,
        expected_size: int | None = None,
        key_prefix: str = "key",
    ) -> None:
        super().__init__()
        final_entries: OrderedDict[str, MetaData] = OrderedDict()
        actual_size: int | None = None

        if entries is None:
            if expected_size is None:
                actual_size = 0
            else:
                if not isinstance(expected_size, int) or expected_size < 0:
                    raise ValueError(
                        "expected_size must be a non-negative integer when entries is None"
                    )
                for i in range(expected_size):
                    final_entries[f"{key_prefix}{i}"] = MetaData()
                actual_size = expected_size

        elif isinstance(entries, MetaDataDict):
            final_entries = entries
            actual_size = len(entries)

        elif isinstance(entries, (list, tuple)):
            actual_size = len(entries)
            if not entries:
                pass
            elif all(isinstance(e, str) for e in entries):
                if len(set(entries)) != actual_size:
                    raise ValueError("Duplicate keys detected in string list.")
                for key in entries:
                    final_entries[key] = MetaData()
            elif all(isinstance(e, (dict, MetaData)) for e in entries):
                for i, entry in enumerate(entries):
                    key = f"{key_prefix}{i}"
                    final_entries[key] = (
                        MetaData(**entry) if isinstance(entry, dict) else entry
                    )
            else:
                raise TypeError(
                    "List entries must be all strings or all dict/MetaData objects."
                )

        elif isinstance(entries, (dict, OrderedDict)):
            actual_size = len(entries)
            for key, entry in entries.items():
                final_entries[key] = (
                    MetaData(**entry) if isinstance(entry, dict) else entry
                )
            # Dict insertion order is guaranteed in Python 3.7+ as part of language spec.

        elif pd is not None and isinstance(entries, pd.DataFrame):
            actual_size = len(entries)
            for key, row in entries.iterrows():
                meta_data_kwargs = cast(dict[str, Any], row.dropna().to_dict())
                final_entries[str(key)] = MetaData(**meta_data_kwargs)

        else:
            raise TypeError(f"Unsupported type for entries: {type(entries)}")

        # --- Size validation ---
        if expected_size is not None and actual_size != expected_size:
            raise ValueError(
                f"Number of entries ({actual_size}) does not match expected size ({expected_size})."
            )

        # Populate self
        self.update(final_entries)

    @property
    def names(self) -> list[str]:
        """List of names from all MetaData entries."""
        return [entry.name for entry in self.values()]

    @property
    def channels(self) -> list[Channel]:
        """List of channels from all MetaData entries."""
        return [entry.channel for entry in self.values()]

    @property
    def units(self) -> list[u.UnitBase]:
        """List of units from all MetaData entries."""
        return [entry.unit for entry in self.values()]

    def to_dataframe(self):
        """Convert the metadata collection to a pandas DataFrame.

        The ``unit`` column is serialised as a string so that the DataFrame
        can be written to CSV and read back without loss of unit information.
        """
        if pd is None:
            raise ImportError("pandas is required for to_dataframe()")
        data = [
            {**{k: (str(v) if k == "unit" else v) for k, v in entry.items()}, "key": key}
            for key, entry in self.items()
        ]
        df = pd.DataFrame(data).set_index("key")
        return df

    def write(self, path, **kwargs):
        """Write the metadata collection to a CSV file."""
        self.to_dataframe().to_csv(path, **kwargs)

    @classmethod
    def read(cls, path, **kwargs):
        """Read a metadata collection from a CSV file."""
        if pd is None:
            raise ImportError("pandas is required for read()")
        df = pd.read_csv(path, index_col=0, **kwargs)
        return cls(df)

    @classmethod
    def from_series(cls, collection):
        """Create a MetaDataCollection from a group of series."""
        if isinstance(collection, (list, tuple)):
            return cls(
                {f"key{i}": MetaData.from_series(s) for i, s in enumerate(collection)}
            )
        elif isinstance(collection, dict):
            return cls({k: MetaData.from_series(s) for k, s in collection.items()})
        else:
            raise TypeError("Expected list, tuple, or dict of series objects.")

    def _binary_op(self, other, op):
        if isinstance(other, MetaDataDict):
            if self.keys() != other.keys():
                raise ValueError("Keys do not match")
            result = MetaDataDict()
            for key in self:
                result[key] = op(self[key], other[key])
            return result
        else:
            result = MetaDataDict()
            for key in self:
                result[key] = op(self[key], other)
            return result

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        if method != "__call__":
            return NotImplemented
        keys = self.keys()
        result = {}
        ufunc_kwargs = {k: v for k, v in kwargs.items() if k not in ("out", "where")}
        for key in keys:
            args = []
            for inp in inputs:
                if isinstance(inp, MetaDataDict):
                    args.append(inp[key])
                else:
                    args.append(inp)
            result[key] = ufunc(*args, **ufunc_kwargs)
        return self.__class__(result)

    def __abs__(self):
        return np.abs(self)

    def __neg__(self):
        return np.negative(self)

    def __pos__(self):
        return np.positive(self)

    def __add__(self, other):
        return self._binary_op(other, np.add)

    def __sub__(self, other):
        return self._binary_op(other, np.subtract)

    def __mul__(self, other):
        return self._binary_op(other, np.multiply)

    def __truediv__(self, other):
        return self._binary_op(other, np.divide)

    def __pow__(self, other):
        return self._binary_op(other, np.power)

    def __radd__(self, other):
        return self.__add__(other)

    def __rsub__(self, other):
        return self.__sub__(other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __rtruediv__(self, other):
        return self.__truediv__(other)

    def __str__(self):
        return self.to_dataframe().to_string()

    def __repr__(self):
        return f"MetaDataDict(keys={list(self.keys())})"

    def _repr_html_(self):
        return self.to_dataframe().to_html()


# =============================
# MetaDataMatrix: matrix container for unit/name per element
# =============================
class MetaDataMatrix(np.ndarray):
    """A matrix container for multiple MetaData instances.

    This class extends numpy.ndarray to provide a grid-like view of metadata,
    supporting vectorized attribute access (names, units, channels).
    """

    def __new__(cls, input_array=None, shape=None, default=None):
        """Create a MetaDataMatrix from an array-like or shape.

        Parameters
        ----------
        input_array : array-like of object or None
            Object array whose elements are MetaData or mappings accepted by ``MetaData(**kwargs)``.
        shape : tuple of int, optional
            Target shape used when ``input_array`` is omitted.
        default : MetaData or dict, optional
            Default value to fill when ``shape`` is given without ``input_array``.

        Returns
        -------
        MetaDataMatrix

        """
        if input_array is None:
            if shape is None:
                raise ValueError("Must provide either input_array or shape")
            default = (
                default
                if isinstance(default, MetaData)
                else MetaData(**(default or {}))
            )
            input_array = np.empty(shape, dtype=object)
            for idx in np.ndindex(shape):
                input_array[idx] = MetaData(**dict(default))

        obj = np.asarray(input_array, dtype=object).copy().view(cls)
        flat = list(obj.flat)
        converted = []
        needs_writeback = False
        for v in flat:
            if isinstance(v, MetaData):
                converted.append(v)
            elif v is None:
                converted.append(MetaData())
                needs_writeback = True
            elif isinstance(v, dict):
                converted.append(MetaData(**v))
                needs_writeback = True
            else:
                # Fallback: infer unit and wrap into MetaData
                try:
                    unit = get_unit(v)
                except (AttributeError, TypeError, ValueError):
                    unit = u.dimensionless_unscaled
                converted.append(MetaData(unit=unit, name="", channel=""))
                needs_writeback = True
        if needs_writeback:
            obj.flat[:] = converted

        return obj

    def __init__(
        self, input_array=None, shape=None, default=None, row_keys=None, col_keys=None
    ):
        N, M = self.shape
        self.row_keys = (
            list(row_keys) if row_keys is not None else [f"row{i}" for i in range(N)]
        )
        self.col_keys = (
            list(col_keys) if col_keys is not None else [f"col{j}" for j in range(M)]
        )

    def fill(self, value):
        """Fill the matrix with a single MetaData value.

        Parameters
        ----------
        value : MetaData | dict
            MetaData instance used as-is, or mapping passed once to ``MetaData(**value)``.

        Notes
        -----
        Each cell receives an independent MetaData copy to avoid shared references.

        """
        base = value if isinstance(value, MetaData) else MetaData(**value)
        arr = np.empty(self.shape, dtype=object)
        for idx in np.ndindex(self.shape):
            arr[idx] = MetaData(**dict(base))
        self[...] = arr

    @property
    def names(self):
        """Return a matrix of metadata names."""
        flat = [m.name for m in self.reshape(-1)]
        return np.asarray(flat, dtype=object).reshape(self.shape)

    @names.setter
    def names(self, value):
        """Set names for all elements.

        Parameters
        ----------
        value : array-like
            Must either match the matrix shape exactly or be a 1-D flat array
            of ``self.size`` elements (which is then reshaped in row-major
            order).  Any other shape raises ``ValueError`` to prevent silent
            element reordering.

        """
        value = np.asarray(value)
        if value.shape == self.shape:
            pass
        elif value.ndim == 1 and value.size == self.size:
            value = value.reshape(self.shape)
        else:
            raise ValueError(
                f"Cannot set names: shape {value.shape} is incompatible with "
                f"matrix shape {self.shape}. Provide an exact-shape array or "
                f"a 1-D flat array of size {self.size}."
            )
        flat_iter = cast(Iterable[MetaData], self.reshape(-1))
        value_iter = cast(Iterable[object], value.reshape(-1))
        for m, name in zip(flat_iter, value_iter):
            m.name = name

    @property
    def units(self):
        """Return a matrix of physical units."""
        flat = [m.unit for m in self.reshape(-1)]
        return np.asarray(flat, dtype=object).reshape(self.shape)

    @units.setter
    def units(self, value):
        """Set units for all elements.

        Parameters
        ----------
        value : array-like
            Must either match the matrix shape exactly or be a 1-D flat array
            of ``self.size`` elements (which is then reshaped in row-major
            order).  Any other shape raises ``ValueError`` to prevent silent
            element reordering.

        """
        value = np.asarray(value)
        if value.shape == self.shape:
            pass
        elif value.ndim == 1 and value.size == self.size:
            value = value.reshape(self.shape)
        else:
            raise ValueError(
                f"Cannot set units: shape {value.shape} is incompatible with "
                f"matrix shape {self.shape}. Provide an exact-shape array or "
                f"a 1-D flat array of size {self.size}."
            )
        flat_iter = cast(Iterable[MetaData], self.reshape(-1))
        value_iter = cast(Iterable[object], value.reshape(-1))
        for m, unit in zip(flat_iter, value_iter):
            m.unit = unit

    @property
    def channels(self):
        """Return a matrix of channel names."""
        flat = [m.channel for m in self.reshape(-1)]
        return np.asarray(flat, dtype=object).reshape(self.shape)

    @channels.setter
    def channels(self, value):
        """Set channels for all elements.

        Parameters
        ----------
        value : array-like
            Must either match the matrix shape exactly or be a 1-D flat array
            of ``self.size`` elements (which is then reshaped in row-major
            order).  Any other shape raises ``ValueError`` to prevent silent
            element reordering.

        """
        value = np.asarray(value)
        if value.shape == self.shape:
            pass
        elif value.ndim == 1 and value.size == self.size:
            value = value.reshape(self.shape)
        else:
            raise ValueError(
                f"Cannot set channels: shape {value.shape} is incompatible with "
                f"matrix shape {self.shape}. Provide an exact-shape array or "
                f"a 1-D flat array of size {self.size}."
            )
        flat_iter = cast(Iterable[MetaData], self.reshape(-1))
        value_iter = cast(Iterable[object], value.reshape(-1))
        for m, channel in zip(flat_iter, value_iter):
            m.channel = channel

    @classmethod
    def from_array(cls, array2d):
        """Create a MetaDataMatrix from a 2D array of MetaData objects."""
        return cls(array2d)

    def to_dataframe(self):
        """Convert the matrix to a long-format pandas DataFrame (row, col, name, etc.)."""
        rows, cols = self.shape
        data = [
            {
                **dict(meta),  # expand MetaData to dict
                "row": idx // cols,  # row index
                "col": idx % cols,  # column index
            }
            for idx, meta in enumerate(self.flat)
        ]

        if pd is None:
            raise ImportError("pandas is required for to_dataframe()")
        df = pd.DataFrame(data)
        if "unit" in df.columns:
            df["unit"] = df["unit"].astype(str)
        return df

    @classmethod
    def from_dataframe(cls, df, shape=None):
        """Create a MetaDataMatrix from a long-format pandas DataFrame."""
        if shape is None:
            shape = (df["row"].max() + 1, df["col"].max() + 1)
        arr = np.empty(shape, dtype=object)
        for _, row in df.iterrows():
            i, j = int(row["row"]), int(row["col"])
            arr[i, j] = MetaData(**row.drop(["row", "col"]).to_dict())
        return cls(arr)

    def write(self, filepath, **kwargs):
        """Write the matrix to a CSV file."""
        self.to_dataframe().to_csv(filepath, index=False, **kwargs)

    @classmethod
    def read(cls, filepath, **kwargs):
        """Read a matrix from a CSV file."""
        if pd is None:
            raise ImportError("pandas is required for read()")
        df = pd.read_csv(filepath, **kwargs)
        return cls.from_dataframe(df)

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        if method != "__call__":
            return NotImplemented

        shape = self.shape  # (N, M)

        def _to_array(inp):
            if isinstance(inp, MetaDataMatrix):
                return np.asarray(inp)
            if isinstance(inp, (MetaData, u.Quantity, u.UnitBase, int, float, complex)):
                arr = np.empty(shape, dtype=object)
                arr.flat[:] = [inp] * arr.size
                return arr
            raise TypeError(f"Unsupported operand type: {type(inp)}")

        arr_inputs = [_to_array(inp) for inp in inputs]
        if len({a.shape for a in arr_inputs}) != 1:
            raise ValueError(
                f"Shape mismatch among operands: {[a.shape for a in arr_inputs]}"
            )

        ufunc_kwargs = {k: v for k, v in kwargs.items() if k not in ("out", "where")}

        apply_elem = np.vectorize(
            lambda *args: ufunc(*args, **ufunc_kwargs), otypes=[object]
        )
        result = apply_elem(*arr_inputs)  # shape (N, M)
        return MetaDataMatrix(result)

    def __mul__(self, other):
        return np.multiply(cast(Any, self), other)

    def __rmul__(self, other):
        return np.multiply(other, cast(Any, self))

    def __add__(self, other):
        return np.add(cast(Any, self), other)

    def __radd__(self, other):
        return np.add(other, cast(Any, self))

    def __sub__(self, other):
        return np.subtract(cast(Any, self), other)

    def __rsub__(self, other):
        return np.subtract(other, cast(Any, self))

    def __truediv__(self, other):
        return np.divide(cast(Any, self), other)

    def __rtruediv__(self, other):
        return np.divide(other, cast(Any, self))

    def __pow__(self, exponent, modulo: None = None, /):
        return np.power(cast(Any, self), exponent)

    def __repr__(self):
        return f"MetaDataMatrix(shape={self.shape})"

    def _repr_html_(self):
        return self.to_dataframe().to_html()

    def __str__(self):
        df = self.to_dataframe()
        if "unit" in df.columns:
            df["unit"] = df["unit"].apply(str)
        return df.to_string()


# =============================
# Utirity Functions
# =============================


def get_unit(obj) -> u.UnitBase:
    """Obtain an `astropy` unit for a variety of input types.

    This helper returns an `astropy.units.UnitBase` instance describing the
    physical unit associated with `obj`. It is used to canonicalize units
    across metadata and to supply a reasonable default (dimensionless) for
    inputs without explicit units.

    Parameters
    ----------
    obj : MetaData, astropy.units.Quantity, gwpy Series/TimeSeries/Array, or scalar
        The object whose unit is to be determined. Supported inputs:
        - MetaData: return `obj.unit`.
        - astropy Quantity: return `obj.unit`.
        - gwpy Series/TimeSeries/FrequencySeries/Array: attempt to return
          `obj.unit` (or `obj.unit`-equivalent attribute).
        - Plain numeric scalars (int/float) or numpy arrays without unit:
          treated as dimensionless.

    Returns
    -------
    astropy.units.UnitBase
        The resolved unit. If resolution fails, `astropy.units.dimensionless_unscaled`
        is returned.

    Examples
    --------
    >>> from astropy import units as u
    >>> get_unit(3.0 * u.m)
    Unit("m")
    >>> md = MetaData(unit="s")
    >>> get_unit(md)
    Unit("s")
    >>> get_unit(5.0)
    Unit("dimensionless")
    >>> get_unit(3.14)
    Unit(dimensionless)

    """
    if isinstance(obj, (int, float, complex, np.number)):
        return u.dimensionless_unscaled
    elif isinstance(obj, u.UnitBase):
        return obj
    elif isinstance(
        obj, (u.Quantity, Array, Series, TimeSeries, FrequencySeries, MetaData)
    ):
        return obj.unit
    elif hasattr(obj, "unit"):
        try:
            return Unit(obj.unit)
        except (ValueError, TypeError):
            warnings.warn(
                f"Cannot interpret .unit from {type(obj)}: {obj.unit} - treating as dimensionless"
            )
            return u.dimensionless_unscaled

    warnings.warn(
        f"Cannot extract unit from object of type {type(obj)} - treating as dimensionless"
    )
    return u.dimensionless_unscaled
