"""
Standalone test for Sidekick.fetch(). Uses httpx.MockTransport — no server.

Usage:
    cd sdks/python
    python -m pip install -e .
    python scripts/test_fetch.py
"""
import asyncio
import json
import sys

import httpx

from sidekick_ads.client import FetchResult, Sidekick

passed, failed = 0, 0
def check(cond: bool, msg: str) -> None:
    global passed, failed
    if cond:
        passed += 1
        print(f"  ok: {msg}")
    else:
        failed += 1
        print(f"  FAIL: {msg}")


def make_sk(handler):
    transport = httpx.MockTransport(handler)
    sk = Sidekick(api_key="sk_live_test", platform_id="plt_test", base_url="http://t")
    # bypass _ensure_client by injecting a pre-built AsyncClient with MockTransport
    sk._client = httpx.AsyncClient(
        base_url="http://t",
        transport=transport,
        headers={
            "Authorization": "Bearer sk_live_test",
            "Content-Type": "application/json",
            "User-Agent": "sidekick-python/test",
        },
    )
    return sk


async def main() -> None:
    # Case 1: has_ad=true with parse_mode
    captured_body = {}

    def h1(request: httpx.Request) -> httpx.Response:
        captured_body.update(json.loads(request.content))
        return httpx.Response(200, json={
            "has_ad": True,
            "impression_id": "imp_xx",
            "ad": {
                "ad_text": "Hi",
                "ad_url": "https://e.com/x",
                "button_text": "Btn",
                "button_url": "https://e.com/x",
                "ad_text_formatted": "<a href=\"https://e.com/x\">Hi</a>",
            },
        })

    sk = make_sk(h1)
    r1 = await sk.fetch(user_id=7, language_code="en", parse_mode="HTML")
    check(r1.has_ad is True, "has_ad true")
    check(r1.impression_id == "imp_xx", "impression_id")
    check(r1.ad is not None and r1.ad.ad_text == "Hi", "ad.ad_text")
    check(r1.ad is not None and r1.ad.button_url == "https://e.com/x", "ad.button_url")
    check(r1.ad is not None and (r1.ad.ad_text_formatted or "").startswith("<a"), "ad.ad_text_formatted")
    check(captured_body.get("user_id") == 7, "body.user_id")
    check(captured_body.get("platform_id") == "plt_test", "body.platform_id")
    check(captured_body.get("parse_mode") == "HTML", "body.parse_mode when provided")
    await sk.close()

    # Case 2: no parse_mode → omitted in body, ad_text_formatted None
    captured_body.clear()

    def h2(request: httpx.Request) -> httpx.Response:
        captured_body.update(json.loads(request.content))
        return httpx.Response(200, json={
            "has_ad": True,
            "impression_id": "imp_yy",
            "ad": {
                "ad_text": "X", "ad_url": "https://e/y",
                "button_text": "B", "button_url": "https://e/y",
            },
        })

    sk = make_sk(h2)
    r2 = await sk.fetch(user_id=8, language_code="en")
    check("parse_mode" not in captured_body, "parse_mode omitted in body")
    check(r2.ad is not None and r2.ad.ad_text_formatted is None, "ad.ad_text_formatted None")
    await sk.close()

    # Case 3: has_ad=false
    def h3(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"has_ad": False, "impression_id": None, "ad": None})
    sk = make_sk(h3)
    r3 = await sk.fetch(user_id=9, language_code="en")
    check(r3.has_ad is False and r3.ad is None, "has_ad false shape")
    await sk.close()

    # Case 4: server error → fallback
    def h4(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, json={"error": "nope"})
    sk = make_sk(h4)
    r4 = await sk.fetch(user_id=10, language_code="en")
    check(r4.has_ad is False, "5xx → has_ad false")
    await sk.close()

    # Case 5: network error → fallback
    def h5(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom")
    sk = make_sk(h5)
    r5 = await sk.fetch(user_id=11, language_code="en")
    check(r5.has_ad is False, "network error → has_ad false")
    await sk.close()

    print(f"\nResults: {passed} passed, {failed} failed")
    sys.exit(0 if failed == 0 else 1)


asyncio.run(main())
