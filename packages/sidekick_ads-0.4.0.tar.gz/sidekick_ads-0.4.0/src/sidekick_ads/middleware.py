from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict, Optional

from sidekick_ads.client import Sidekick


class SidekickMiddleware:
    """aiogram 3.x middleware that injects a ``Sidekick`` instance into
    handler data so handlers can access it via dependency injection.

    Usage::

        dp.message.middleware(SidekickMiddleware(api_key="...", platform_id="..."))

    Then in a handler::

        async def handle(message: Message, sidekick: Sidekick):
            result = await sidekick.inject(...)
    """

    def __init__(
        self,
        api_key: str,
        platform_id: str,
        *,
        base_url: str = "https://sidekick-ads.com",
        timeout: float = 3.0,
        platform: str = "telegram",
    ) -> None:
        self._sidekick = Sidekick(
            api_key=api_key,
            platform_id=platform_id,
            base_url=base_url,
            timeout=timeout,
            platform=platform,
        )

    async def __call__(
        self,
        handler: Callable[[Any, Dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: Dict[str, Any],
    ) -> Any:
        data["sidekick"] = self._sidekick
        return await handler(event, data)
