from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

import httpx

__version__ = "0.4.0"

_TELEGRAM_MAX_MESSAGE_LENGTH = 4096
_TELEGRAM_MAX_KEYBOARD_ROWS = 13


@dataclass
class InjectResult:
    message: str
    has_ad: bool
    impression_id: Optional[str]
    ad: Optional[dict]
    keyboard: Any


@dataclass
class FetchAdData:
    ad_text: str
    ad_url: str
    button_text: str
    button_url: str
    ad_text_formatted: Optional[str] = None


@dataclass
class FetchResult:
    has_ad: bool
    impression_id: Optional[str]
    ad: Optional[FetchAdData]


class Sidekick:
    def __init__(
        self,
        api_key: str,
        platform_id: str,
        *,
        base_url: str = "https://sidekick-ads.com",
        timeout: float = 3.0,
        platform: str = "telegram",
    ) -> None:
        self._api_key = api_key
        self._platform_id = platform_id
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._platform = platform
        self._client: Optional[httpx.AsyncClient] = None

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "User-Agent": f"sidekick-python/{__version__}",
                },
                timeout=httpx.Timeout(
                    connect=self._timeout,
                    read=self._timeout,
                    write=self._timeout,
                    pool=self._timeout,
                ),
            )
        return self._client

    async def close(self) -> None:
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def inject(
        self,
        *,
        user_id: int,
        message: str,
        language_code: Optional[str] = None,
        is_premium: Optional[bool] = None,
        keyboard: Any = None,
        ad_button_position: str = "bottom",
        parse_mode: Optional[str] = None,
    ) -> InjectResult:
        fallback = InjectResult(
            message=message,
            has_ad=False,
            impression_id=None,
            ad=None,
            keyboard=keyboard,
        )
        try:
            client = self._ensure_client()

            payload = {
                "user_id": user_id,
                "message": message,
                "platform_id": self._platform_id,
                "language_code": language_code if language_code is not None else "",
                "is_premium": is_premium if is_premium is not None else False,
                "platform": self._platform,
            }
            if parse_mode is not None:
                payload["parse_mode"] = parse_mode

            resp = await client.post("/api/v1/ad", json=payload)
            resp.raise_for_status()
            data = resp.json()

            has_ad: bool = data.get("has_ad", False)
            ad_message: str = data.get("message", message)
            impression_id: Optional[str] = data.get("impression_id")
            ad: Optional[dict] = data.get("ad")

            if not has_ad or ad is None:
                return InjectResult(
                    message=ad_message,
                    has_ad=False,
                    impression_id=impression_id,
                    ad=None,
                    keyboard=keyboard,
                )

            # --- Build the result with ad ---

            result_message = ad_message
            result_keyboard = keyboard

            # Check if the ad message fits within the Telegram limit.
            # If the server-returned message is too long, fall back to the
            # original message (text CTA stripped) but still try the button.
            if len(result_message.encode("utf-8")) > _TELEGRAM_MAX_MESSAGE_LENGTH:
                result_message = message

            # Try to add the ad button to the keyboard
            button_text = ad.get("button_text", "")
            button_url = ad.get("button_url", "")

            if button_text and button_url:
                result_keyboard = _merge_keyboard(
                    keyboard, button_text, button_url, ad_button_position
                )

            # If we couldn't add button AND couldn't add text CTA, return
            # original message entirely unchanged.
            if result_keyboard is keyboard and result_message == message:
                return fallback

            return InjectResult(
                message=result_message,
                has_ad=True,
                impression_id=impression_id,
                ad=ad,
                keyboard=result_keyboard,
            )

        except Exception:
            return fallback

    async def fetch(
        self,
        *,
        user_id: int,
        language_code: str,
        is_premium: Optional[bool] = None,
        parse_mode: Optional[str] = None,
    ) -> FetchResult:
        empty = FetchResult(has_ad=False, impression_id=None, ad=None)
        try:
            client = self._ensure_client()

            payload = {
                "user_id": user_id,
                "platform_id": self._platform_id,
                "language_code": language_code,
                "is_premium": is_premium if is_premium is not None else False,
                "platform": self._platform,
            }
            if parse_mode is not None:
                payload["parse_mode"] = parse_mode

            resp = await client.post("/api/v1/ad/fetch", json=payload)
            resp.raise_for_status()
            data = resp.json()

            if not data.get("has_ad") or data.get("ad") is None or not data.get("impression_id"):
                return empty

            raw_ad = data["ad"]
            ad = FetchAdData(
                ad_text=raw_ad["ad_text"],
                ad_url=raw_ad["ad_url"],
                button_text=raw_ad["button_text"],
                button_url=raw_ad["button_url"],
                ad_text_formatted=raw_ad.get("ad_text_formatted"),
            )
            return FetchResult(
                has_ad=True,
                impression_id=data["impression_id"],
                ad=ad,
            )
        except Exception:
            return empty


# ---------------------------------------------------------------------------
# Keyboard helpers
# ---------------------------------------------------------------------------


def _merge_keyboard(
    keyboard: Any,
    button_text: str,
    button_url: str,
    position: str,
) -> Any:
    """Return a new keyboard with the ad button row inserted, or the original
    keyboard unchanged when the button cannot be added."""

    # --- aiogram 3.x ---
    aiogram_markup_cls = _try_import_aiogram()
    if aiogram_markup_cls is not None:
        markup_cls, button_cls = aiogram_markup_cls
        if keyboard is None:
            ad_btn = button_cls(text=button_text, url=button_url)
            return markup_cls(inline_keyboard=[[ad_btn]])
        if isinstance(keyboard, markup_cls):
            rows = list(keyboard.inline_keyboard)
            if len(rows) >= _TELEGRAM_MAX_KEYBOARD_ROWS:
                return keyboard
            ad_btn = button_cls(text=button_text, url=button_url)
            if position == "top":
                rows = [[ad_btn]] + rows
            else:
                rows = rows + [[ad_btn]]
            return markup_cls(inline_keyboard=rows)

    # --- python-telegram-bot v20+ ---
    ptb_markup_cls = _try_import_ptb()
    if ptb_markup_cls is not None:
        markup_cls, button_cls = ptb_markup_cls
        if keyboard is None:
            ad_btn = button_cls(text=button_text, url=button_url)
            return markup_cls([[ad_btn]])
        if isinstance(keyboard, markup_cls):
            rows = list(keyboard.inline_keyboard)
            if len(rows) >= _TELEGRAM_MAX_KEYBOARD_ROWS:
                return keyboard
            ad_btn = button_cls(text=button_text, url=button_url)
            ad_row = (ad_btn,)
            if position == "top":
                rows = [ad_row] + rows
            else:
                rows = rows + [ad_row]
            return markup_cls(rows)

    # Unrecognized type — return unchanged
    return keyboard


def _try_import_aiogram():
    try:
        from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

        return InlineKeyboardMarkup, InlineKeyboardButton
    except ImportError:
        return None


def _try_import_ptb():
    try:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        return InlineKeyboardMarkup, InlineKeyboardButton
    except ImportError:
        return None
