from sidekick_ads.client import (
    FetchAdData,
    FetchResult,
    InjectResult,
    Sidekick,
)

__all__ = ["Sidekick", "InjectResult", "FetchResult", "FetchAdData"]
__version__ = "0.3.0"
