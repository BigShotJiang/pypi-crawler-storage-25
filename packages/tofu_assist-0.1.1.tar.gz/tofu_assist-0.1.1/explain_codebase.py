#!/usr/bin/env python3
"""
tofu-assist explain — Understand any OpenTofu codebase in plain English.

Usage:
    tofu-assist explain              # current directory
    tofu-assist explain ./infra      # specific directory
    tofu-assist explain --detailed   # verbose output with security + cost analysis

This is different from 'explain.py' which explains 'tofu plan' JSON output.
This module explains the STATIC .tf files — what resources exist, how they
connect, what they cost, and what security risks they carry.
"""

import json
import sys
from pathlib import Path
from dataclasses import dataclass, field

from llm_utils import call_llm, MODEL


EXPLAIN_SYSTEM_PROMPT = """You are an infrastructure codebase explainer. You receive OpenTofu/Terraform .tf files and produce a plain-English summary that a new team member could read and immediately understand the infrastructure.

OUTPUT FORMAT:
Return a JSON object with this structure:

{
  "overview": "<one-paragraph summary of what this infrastructure does>",
  "resources": [
    {"name": "<resource name>", "type": "<aws_s3_bucket etc>", "purpose": "<one line>"},
    ...
  ],
  "architecture": "<how resources connect: VPC → subnets → EKS → RDS etc>",
  "dependencies": ["<external dependency 1>", "<external dependency 2>", ...],
  "security_notes": ["<concern 1>", "<concern 2>", ...],
  "cost_notes": ["<cost implication 1>", "<cost implication 2>", ...],
  "suggestions": ["<improvement 1>", "<improvement 2>", ...]
}

RULES:
1. List EVERY resource found in the files. Don't skip any.
2. For resources you recognize (aws_s3_bucket, aws_rds_instance, etc.), describe their purpose in plain English — not HCL terminology. "Stores uploaded files" not "S3 bucket resource".
3. For architecture, describe the flow: what talks to what, in what order, through what network paths.
4. For security, flag: public S3 buckets, wide-open security groups (0.0.0.0/0), hardcoded secrets, missing encryption, wildcard IAM.
5. For cost, note expensive resources: NAT gateways, RDS instances (especially multi-AZ), EKS clusters, Load Balancers.
6. For suggestions, note: missing outputs, hardcoded values that should be variables, resources that should be encrypted, missing tags.
7. If you can't determine something, say "Unknown" rather than guessing.
8. Be specific. "This VPC has 2 public and 2 private subnets across us-east-1a and us-east-1b" not "There is a VPC with subnets".
9. Keep the overview to 3-5 sentences max.
10. Keep each resource description to one line.

Files to explain:

{files_text}

Return ONLY the JSON object. No explanation. No markdown. No backticks."""


@dataclass
class ExplainResult:
    """Result of a codebase explanation."""
    success: bool
    overview: str = ""
    resources: list[dict] = field(default_factory=list)
    architecture: str = ""
    dependencies: list[str] = field(default_factory=list)
    security_notes: list[str] = field(default_factory=list)
    cost_notes: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    error: str = ""


def explain_codebase(
    tf_dir: str = ".",
    detailed: bool = False,
    model: str = MODEL,
) -> ExplainResult:
    """Explain an OpenTofu codebase in plain English.

    Args:
        tf_dir: Directory containing .tf files
        detailed: If True, request deeper security and cost analysis
        model: LLM model to use

    Returns:
        ExplainResult with structured explanation
    """
    dir_path = Path(tf_dir).resolve()
    if not dir_path.exists():
        return ExplainResult(success=False, error=f"Directory not found: {tf_dir}")
    if not dir_path.is_dir():
        return ExplainResult(success=False, error=f"Not a directory: {tf_dir}")

    # 1. Read all .tf files
    files_text = ""
    tf_files = sorted(dir_path.glob("*.tf"))
    tf_files = [f for f in tf_files if not f.name.startswith(".")]

    if not tf_files:
        return ExplainResult(
            success=False,
            error=f"No .tf files found in {tf_dir}. Run 'tofu-assist explain' from a directory with OpenTofu config."
        )

    for f in tf_files:
        content = f.read_text()
        files_text += f"\n=== {f.name} ===\n{content}\n"

    # 2. Build system prompt
    system = EXPLAIN_SYSTEM_PROMPT.replace("{files_text}", files_text)

    if detailed:
        system += (
            "\n\nDETAILED MODE: Provide extra depth on security analysis "
            "(check every resource for encryption, public access, IAM scope) "
            "and cost analysis (estimate rough monthly costs for each expensive resource). "
            "List at least 5 suggestions for improvement."
        )

    # 3. Call LLM
    try:
        raw = call_llm(system, "Explain this OpenTofu codebase.", model=model)
    except RuntimeError as e:
        return ExplainResult(success=False, error=f"LLM call failed: {e}")

    # 4. Parse JSON
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return ExplainResult(
            success=False,
            error="LLM returned malformed response. Try again."
        )

    if not isinstance(data, dict):
        return ExplainResult(
            success=False,
            error="LLM response was not a JSON object."
        )

    # 5. Build result
    resources = data.get("resources", [])
    if not isinstance(resources, list):
        resources = []

    security = data.get("security_notes", [])
    if not isinstance(security, list):
        security = []

    cost = data.get("cost_notes", [])
    if not isinstance(cost, list):
        cost = []

    suggestions = data.get("suggestions", [])
    if not isinstance(suggestions, list):
        suggestions = []

    dependencies = data.get("dependencies", [])
    if not isinstance(dependencies, list):
        dependencies = []

    return ExplainResult(
        success=True,
        overview=data.get("overview", "No overview provided."),
        resources=resources,
        architecture=data.get("architecture", "No architecture description provided."),
        dependencies=dependencies,
        security_notes=security,
        cost_notes=cost,
        suggestions=suggestions,
    )


def render_explanation(result: ExplainResult, detailed: bool = False) -> str:
    """Render an ExplainResult as a human-readable terminal string."""
    lines = []
    sep = "─" * 60

    lines.append(sep)
    lines.append("CODEBASE EXPLANATION")
    lines.append(sep)
    lines.append("")

    lines.append("OVERVIEW")
    lines.append(result.overview)
    lines.append("")

    if result.resources:
        lines.append(f"RESOURCES ({len(result.resources)})")
        lines.append("")
        for r in result.resources:
            name = r.get("name", "unknown")
            rtype = r.get("type", "unknown")
            purpose = r.get("purpose", "")
            lines.append(f"  • {name} ({rtype})")
            if purpose:
                lines.append(f"    {purpose}")
        lines.append("")

    if result.architecture:
        lines.append("ARCHITECTURE")
        lines.append(result.architecture)
        lines.append("")

    if result.dependencies:
        lines.append("DEPENDENCIES")
        for dep in result.dependencies:
            lines.append(f"  • {dep}")
        lines.append("")

    if result.security_notes:
        lines.append("SECURITY NOTES")
        for note in result.security_notes:
            prefix = "⚠ " if any(
                kw in note.lower()
                for kw in ["public", "0.0.0.0", "wildcard", "hardcoded", "missing encryption", "open"]
            ) else "• "
            lines.append(f"  {prefix}{note}")
        lines.append("")

    if result.cost_notes:
        lines.append("COST IMPLICATIONS")
        for note in result.cost_notes:
            lines.append(f"  💰 {note}")
        lines.append("")

    if result.suggestions:
        lines.append("SUGGESTIONS")
        for s in result.suggestions:
            lines.append(f"  → {s}")
        lines.append("")

    lines.append(sep)
    if not detailed:
        lines.append("Run with --detailed for deeper security and cost analysis.")
    lines.append(sep)

    return "\n".join(lines)


def main() -> None:
    """CLI entry point for tofu-assist explain."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Explain an OpenTofu codebase in plain English"
    )
    parser.add_argument(
        "directory",
        nargs="?",
        default=".",
        help="Directory containing .tf files (default: current directory)",
    )
    parser.add_argument(
        "--detailed", "-d",
        action="store_true",
        help="Deeper security and cost analysis",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        help="Output raw JSON instead of formatted text",
    )

    args = parser.parse_args()
    tf_dir = str(Path(args.directory).resolve())

    print(f"Analyzing {tf_dir}...")
    print()

    result = explain_codebase(tf_dir, detailed=args.detailed)

    if not result.success:
        print(f"✗ {result.error}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        output = {
            "overview": result.overview,
            "resources": result.resources,
            "architecture": result.architecture,
            "dependencies": result.dependencies,
            "security_notes": result.security_notes,
            "cost_notes": result.cost_notes,
            "suggestions": result.suggestions,
        }
        print(json.dumps(output, indent=2))
    else:
        print(render_explanation(result, detailed=args.detailed))


if __name__ == "__main__":
    main()
