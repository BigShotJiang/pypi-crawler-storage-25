#!/usr/bin/env python3
"""
tofu-assist — Natural language → provisioned infrastructure, with safety checks.

Full pipeline:
    NL prompt → generate .tf files → Checkov scan → tofu plan → explain → cost → approve

Usage:
    tofu-assist "I need a k8s cluster with postgres"
    tofu-assist --dry-run "S3 bucket with CloudFront CDN"
"""

import subprocess
import sys
from pathlib import Path

# Import from sibling modules
from generate import (
    detect_provider, generate_tf, MODEL,
)
from explain import (
    analyze_plan, render_plain, load_plan_json, validate_schema,
    run_security_scan,
)


def run_tofu_plan(tf_dir: str) -> tuple[bool, str, str]:
    """Run 'tofu plan -json' in the given directory.

    Returns (success, plan_json_string, error_message).
    """
    try:
        result = subprocess.run(
            ["tofu", "init"],
            capture_output=True, text=True,
            cwd=tf_dir, timeout=120,
        )
        if result.returncode != 0:
            return False, "", f"tofu init failed:\n{result.stderr[-500:]}"

        result = subprocess.run(
            ["tofu", "plan", "-json"],
            capture_output=True, text=True,
            cwd=tf_dir, timeout=120,
        )
    except FileNotFoundError:
        return False, "", "OpenTofu is not installed. Install: https://opentofu.org"
    except subprocess.TimeoutExpired:
        return False, "", "Plan timed out"

    if result.returncode == 0:
        return True, result.stdout, ""
    if result.returncode == 2:
        # Exit code 2 = planned changes detected (this is a successful plan)
        return True, result.stdout, ""

    error = (result.stdout + result.stderr).strip()[-1000:]

    # Make common errors human-readable
    if "failed to get shared config profile" in error:
        return False, "", (
            "No AWS credentials found.\n"
            "  Set AWS_PROFILE or run: aws configure\n"
            "  Or use --dry-run to preview without credentials."
        )
    if "Error: " in error:
        # Extract just the error lines, skip JSON noise
        lines = []
        for line in error.split("\n"):
            line = line.strip()
            if line.startswith("Error: "):
                lines.append(line)
            elif line.startswith("│ Error: "):
                lines.append(line.replace("│ ", ""))
        if lines:
            error = "\n".join(lines[:5])
    return False, "", f"Plan failed:\n{error}"


def run_tofu_apply(tf_dir: str) -> tuple[bool, str]:
    """Run 'tofu apply -auto-approve'. Returns (success, output)."""
    try:
        result = subprocess.run(
            ["tofu", "apply", "-auto-approve"],
            capture_output=True, text=True,
            cwd=tf_dir, timeout=600,
        )
    except FileNotFoundError:
        return False, "OpenTofu is not installed"
    except subprocess.TimeoutExpired:
        return False, "Apply timed out"

    output = (result.stdout + result.stderr).strip()
    return result.returncode == 0, output[-2000:]


def main() -> None:
    # Subcommand: edit
    if len(sys.argv) > 1 and sys.argv[1] == "edit":
        import edit
        sys.argv.pop(1)
        edit.main()
        return

    # Subcommand: explain
    if len(sys.argv) > 1 and sys.argv[1] == "explain":
        import explain_codebase
        sys.argv.pop(1)
        explain_codebase.main()
        return

    dry_run = "--dry-run" in sys.argv
    args = [a for a in sys.argv[1:] if a not in ("--dry-run", "--json")]

    if not args or "--help" in sys.argv or "-h" in sys.argv:
        print("Usage: tofu-assist 'I need a kubernetes cluster with postgres'", file=sys.stderr)
        print(file=sys.stderr)
        print("Options:", file=sys.stderr)
        print("  --dry-run    Preview plan without applying", file=sys.stderr)
        print("  --json       Output plan as JSON", file=sys.stderr)
        print(file=sys.stderr)
        print("Subcommands:", file=sys.stderr)
        print("  edit         Modify existing config via natural language", file=sys.stderr)
        print("  explain      Explain any .tf codebase in plain English", file=sys.stderr)
        print(file=sys.stderr)
        print("Examples:", file=sys.stderr)
        print("  tofu-assist 'I need a k8s cluster with postgres'", file=sys.stderr)
        print("  tofu-assist edit 'add a read replica to the RDS'", file=sys.stderr)
        print("  tofu-assist explain ./infra", file=sys.stderr)
        sys.exit(0 if "--help" in sys.argv or "-h" in sys.argv else 1)

    user_prompt = " ".join(args)

    # ── Step 1: Provider detection ──────────────────────────────────────
    provider, region = detect_provider()
    if provider == "unknown":
        print("⚠ Could not detect cloud provider.", file=sys.stderr)
        print("  Set AWS_PROFILE, GOOGLE_APPLICATION_CREDENTIALS, or ARM_SUBSCRIPTION_ID.", file=sys.stderr)
        print("  Or create .tf files with provider blocks first.", file=sys.stderr)
        sys.exit(1)

    print(f"Provider: {provider} ({region})")
    print(f"Model: {MODEL}")

    # ── Step 2: Generate HCL ────────────────────────────────────────────
    print("Generating configuration...")
    print()

    result = generate_tf(user_prompt, provider, region)

    if not result.success:
        print(f"✗ Generation failed: {result.error}", file=sys.stderr)
        if result.pending_dir:
            print(f"  Partial files saved to: {result.pending_dir}", file=sys.stderr)
        sys.exit(1)

    print(f"   ✓ main.tf ({result.files.get('main_tf', '').count(chr(10)) + 1} lines)")
    print(f"   ✓ variables.tf ({result.files.get('variables_tf', '').count(chr(10)) + 1} lines)")
    print(f"   ✓ outputs.tf ({result.files.get('outputs_tf', '').count(chr(10)) + 1} lines)")
    print()

    tf_dir = result.pending_dir

    # ── Step 3: Security scan (always run) ──────────────────────────────
    security = run_security_scan(tf_dir)
    # Separate tool-status messages from real findings
    tool_status = [f for f in security.findings
                   if "unavailable" in f.lower() or "timed out" in f.lower()]
    real_findings = [f for f in security.findings if f not in tool_status]

    if real_findings:
        print(f"Security scan: ⚠ {len(real_findings)} issue(s)")
        for finding in real_findings:
            print(f"  {finding}")
        print()
    elif tool_status:
        print(f"Security scan: {tool_status[0]}")
        print()
    else:
        print("Security scan: ✓ no issues found")
        print()

    # ── Step 4: tofu plan (always run) ──────────────────────────────────
    print("Running tofu plan...")
    success, plan_json, error = run_tofu_plan(tf_dir)

    if not success:
        print(f"✗ {error}", file=sys.stderr)
        print(f"  Files saved to: {tf_dir}", file=sys.stderr)
        print(f"  Fix the errors and run: tofu-assist retry {tf_dir}", file=sys.stderr)
        sys.exit(1)

    # Save plan JSON for Infracost
    plan_path = Path(tf_dir) / "plan.json"
    plan_path.write_text(plan_json)

    # ── Step 5: Explain ─────────────────────────────────────────────────
    plan = load_plan_json(plan_json)
    if plan is None:
        print("✗ Could not parse plan output", file=sys.stderr)
        sys.exit(1)

    schema_error = validate_schema(plan)
    if schema_error:
        print(f"✗ {schema_error}", file=sys.stderr)
        sys.exit(1)

    explain_result = analyze_plan(plan)

    # Inject real security findings into the explain output
    if real_findings:
        explain_result.attention_items = real_findings + explain_result.attention_items

    print()

    # ── Step 6: Render explain output ───────────────────────────────────
    if dry_run:
        print("━" * 60)
        print("DRY RUN — nothing will be applied")
        print("━" * 60)
        print()

    output = render_plain(explain_result, str(plan_path))
    print(output)
    print()

    if dry_run:
        print(f"Files saved to: {tf_dir}")
        print(f"Run `tofu-assist apply {tf_dir}` to apply this plan.")
        return

    # ── Step 7: Approve (live mode only) ────────────────────────────────
    # Check for hard-stop conditions
    if explain_result.alarming:
        print("⚠ This plan requires manual review. Apply manually:", file=sys.stderr)
        print(f"  cd {tf_dir} && tofu apply", file=sys.stderr)
        sys.exit(3)

    # Re-surface critical risks before the y/N decision.
    # These are the line in the sand — user must consciously override.
    critical_risks = [a for a in explain_result.attention_items if a.startswith("⛔")]
    if critical_risks:
        print("━" * 60)
        print("⛔  CRITICAL RISKS DETECTED:")
        for item in critical_risks[:3]:
            print(f"  {item}")
        if len(critical_risks) > 3:
            print(f"  ... and {len(critical_risks) - 3} more critical issue(s)")
        print("━" * 60)
        print()

    try:
        if critical_risks:
            choice = input("Apply this plan? CRITICAL RISKS ABOVE [y/N] ").strip().lower()
        else:
            choice = input("Apply this plan? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled.")
        print(f"Files saved to: {tf_dir}")
        print(f"Review and apply manually: cd {tf_dir} && tofu apply")
        sys.exit(0)

    if choice in ("y", "yes"):
        print("Applying...")
        success, output = run_tofu_apply(tf_dir)
        if success:
            print("✓ Infrastructure provisioned successfully.")
            from generate import archive_applied
            applied = archive_applied(tf_dir)
            if applied:
                print(f"  Config archived to: {applied}")
        else:
            print(f"✗ Apply failed:\n{output}", file=sys.stderr)
            print(f"Files saved to: {tf_dir}")
            sys.exit(1)
    else:
        print(f"Files saved to: {tf_dir}")
        print(f"Apply manually: cd {tf_dir} && tofu apply")


if __name__ == "__main__":
    main()
