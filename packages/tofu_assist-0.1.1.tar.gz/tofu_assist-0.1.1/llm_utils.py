#!/usr/bin/env python3
"""Shared LLM utilities for tofu-assist — API calling, config, provider detection."""

import json
import os
import subprocess
from pathlib import Path
from typing import Optional

# ─── Configuration ────────────────────────────────────────────────────────────

TOFU_ASSIST_HOME = Path.home() / ".tofu-assist"
PENDING_DIR = TOFU_ASSIST_HOME / "pending"
APPLIED_DIR = TOFU_ASSIST_HOME / "applied"

API_KEY = os.environ.get("TOFU_ASSIST_API_KEY") or os.environ.get("DEEPSEEK_API_KEY") or ""
API_BASE = os.environ.get("TOFU_ASSIST_API_BASE", "https://api.deepseek.com/v1")
MODEL = os.environ.get("TOFU_ASSIST_MODEL", "deepseek-chat")

PROVIDER_DETECTION_ORDER = [
    ("AWS_PROFILE", "aws", "us-east-1"),
    ("AWS_DEFAULT_REGION", "aws", None),
    ("GOOGLE_APPLICATION_CREDENTIALS", "gcp", "us-central1"),
    ("ARM_SUBSCRIPTION_ID", "azure", "eastus"),
]

# ─── LLM Calling ─────────────────────────────────────────────────────────────

def call_llm(
    system_prompt: str,
    user_prompt: str,
    model: str = MODEL,
    api_key: str = API_KEY,
    api_base: str = API_BASE,
    timeout: int = 120,
) -> str:
    """Call an OpenAI-compatible chat completions API via curl.

    Uses curl instead of urllib — some providers (OpenCode Go) reject
    Python's urllib TLS handshake with 403/1010.

    Returns the raw response text (expected to be JSON).
    Raises RuntimeError on network/auth/API errors — caller handles retry.
    """
    url = f"{api_base.rstrip('/')}/chat/completions"

    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.1,
        "max_tokens": 16384,
    })

    try:
        result = subprocess.run(
            ["curl", "-s", url,
             "-H", f"Authorization: Bearer {api_key}",
             "-H", "Content-Type: application/json",
             "-d", body,
             "--max-time", str(timeout)],
            capture_output=True, text=True, timeout=timeout + 5,
        )
    except FileNotFoundError:
        raise RuntimeError("curl is not installed")
    except subprocess.TimeoutExpired:
        raise RuntimeError("LLM call timed out")

    if result.returncode != 0:
        raise RuntimeError(f"curl failed: {result.stderr[:500]}")

    raw = result.stdout.strip()
    if not raw:
        raise RuntimeError("LLM returned empty response")

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        raise RuntimeError(f"LLM returned malformed response: {raw[:200]}")

    if "error" in data:
        err = data["error"]
        raise RuntimeError(f"API error: {err.get('message', str(err))}")

    content = data["choices"][0]["message"]["content"]
    if not content:
        raise RuntimeError("LLM returned empty content — try increasing max_tokens")

    return content


# ─── Provider Detection ──────────────────────────────────────────────────────

def detect_provider(tf_dir: Optional[str] = None) -> tuple[str, str]:
    """Detect cloud provider and region. Returns (provider, region)."""
    provider = None
    region = None

    if tf_dir:
        tf_path = Path(tf_dir)
        if tf_path.exists():
            for tf_file in tf_path.glob("*.tf"):
                content = tf_file.read_text()
                if 'provider "aws"' in content:
                    provider = "aws"
                elif 'provider "google"' in content:
                    provider = "gcp"
                elif 'provider "azurerm"' in content:
                    provider = "azure"
                if provider:
                    break

    if not provider:
        for env_var, prov, default_region in PROVIDER_DETECTION_ORDER:
            if os.environ.get(env_var):
                provider = prov
                if not region and default_region:
                    region = default_region
                break

    if provider == "aws" and not region:
        aws_config = Path.home() / ".aws" / "config"
        if aws_config.exists():
            for line in aws_config.read_text().splitlines():
                line = line.strip()
                if line.startswith("region"):
                    region = line.split("=")[-1].strip()
                    break
        if not region:
            region = "us-east-1"

    if provider == "gcp" and not region:
        region = "us-central1"
    if provider == "azure" and not region:
        region = "eastus"

    return provider or "unknown", region or "unknown"


# ─── Provider Boilerplate ────────────────────────────────────────────────────

def get_provider_boilerplate(provider: str, region: str) -> str:
    """Return the terraform/provider block for the given cloud provider."""
    boilerplates = {
        "aws": 'terraform {\n  required_providers {\n    aws = {\n      source  = "hashicorp/aws"\n      version = "~> 5.0"\n    }\n  }\n}\n\nprovider "aws" {\n  region = var.region\n}\n\n',
        "gcp": 'terraform {\n  required_providers {\n    google = {\n      source  = "hashicorp/google"\n      version = "~> 6.0"\n    }\n  }\n}\n\nprovider "google" {\n  region = var.region\n}\n\n',
        "azure": 'terraform {\n  required_providers {\n    azurerm = {\n      source  = "hashicorp/azurerm"\n      version = "~> 4.0"\n    }\n  }\n}\n\nprovider "azurerm" {\n  features {}\n}\n\n',
    }
    return boilerplates.get(provider, boilerplates["aws"])
