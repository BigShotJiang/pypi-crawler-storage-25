#!/usr/bin/env python3
"""
tofu-assist generate — Natural language → OpenTofu HCL, with safety defaults baked in.

The system prompt IS the moat. Security defaults are encoded in the prompt,
not enforced after the fact. The LLM generates secure config by default.

Usage:
    tofu-assist "I need a k8s cluster with postgres"
    tofu-assist --model deepseek-chat "A simple web server on AWS"
    tofu-assist --provider aws --region eu-west-1 "S3 bucket with CDN"
"""

import json
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

# ─── Configuration ────────────────────────────────────────────────────────────

from llm_utils import (
    PENDING_DIR, APPLIED_DIR,
    MODEL,
    detect_provider, call_llm, get_provider_boilerplate,
)

# Re-export for backward compatibility with tofu_assist.py

SYSTEM_PROMPT = """You are an OpenTofu infrastructure generator. You generate valid, secure, production-quality HCL.

Return ONLY a JSON object with exactly three keys. No explanation. No markdown. No backticks.

The format:
{
  "main_tf": "resource \\"aws_vpc\\" \\"main\\" { ... }",
  "variables_tf": "variable \\"region\\" { ... }",
  "outputs_tf": "output \\"vpc_id\\" { ... }"
}

The values are raw HCL strings containing full resource definitions.
IMPORTANT: The HCL inside these strings should use normal double quotes — do NOT backslash-escape them.
The JSON wrapper handles escaping automatically. Write valid HCL exactly as you would in a .tf file.

SECURITY DEFAULTS — always apply unless the user explicitly overrides:
- Encryption at rest: enabled on all storage (S3, RDS, EBS, EFS) and databases
- S3 buckets: public access blocked (block_public_acls=true, block_public_policy=true, ignore_public_acls=true, restrict_public_buckets=true)
- Security groups: NO ingress from 0.0.0.0/0 on ports 22, 3306, 5432, 6379, 27017, 3389. Use specific CIDR ranges or internal VPC access only.
- IAM: no wildcard actions (no "s3:*", no "*") unless the user explicitly asks for admin access
- Database passwords: use random_password resource, never hardcode

STYLE RULES:
- snake_case for all resource names (aws_vpc "main_vpc", not "main-vpc" or "MainVpc")
- Variables for: region, instance_type, environment, database_password
- Outputs for: all endpoints, connection strings, public IPs, database host/port
- One # comment per resource block explaining what it does
- Do NOT generate terraform{} or provider{} blocks — they are added automatically
- Use data sources for: availability_zones, ami, caller_identity where useful

Provider: {provider}
Region: {region}

Generate the configuration now. Return ONLY the JSON object."""


# ─── Data Structures ──────────────────────────────────────────────────────────

@dataclass
class GenerateResult:
    """Result of a generation attempt."""
    success: bool
    files: dict[str, str] = field(default_factory=dict)
    error: str = ""
    attempts: int = 0
    pending_dir: str = ""


# ─── Provider Detection ──────────────────────────────────────────────────────



# ─── LLM Calling ─────────────────────────────────────────────────────────────



# ─── Validation ───────────────────────────────────────────────────────────────

def run_tofu_validate(tf_dir: str) -> tuple[bool, str]:
    """Run 'tofu validate' in the given directory.

    Runs 'tofu init' first so providers are available.
    Returns (is_valid, error_message).
    """
    try:
        # Init first — tofu validate needs providers downloaded
        init_result = subprocess.run(
            ["tofu", "init"],
            capture_output=True, text=True,
            cwd=tf_dir, timeout=120,
        )
        if init_result.returncode != 0:
            error = (init_result.stdout + init_result.stderr).strip()
            return False, f"tofu init failed: {error[-500:]}"

        result = subprocess.run(
            ["tofu", "validate"],
            capture_output=True, text=True,
            cwd=tf_dir, timeout=30,
        )
    except FileNotFoundError:
        return False, "OpenTofu is not installed"
    except subprocess.TimeoutExpired:
        return False, "Validation timed out"

    if result.returncode == 0:
        return True, ""

    # Collect both stdout and stderr — tofu puts errors in stdout
    error = (result.stdout + result.stderr).strip()
    # Truncate long errors
    if len(error) > 1000:
        error = error[:1000] + "..."
    return False, error


# ─── File Management ──────────────────────────────────────────────────────────

def write_pending(files: dict[str, str]) -> str:
    """Write generated HCL files to the pending directory.

    Creates a timestamped subdirectory under ~/.tofu-assist/pending/.
    Returns the path to the written directory.
    """
    # Map JSON keys to proper .tf filenames
    FILENAME_MAP = {
        "main_tf": "main.tf",
        "variables_tf": "variables.tf",
        "outputs_tf": "outputs.tf",
    }

    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    pending_path = PENDING_DIR / timestamp
    pending_path.mkdir(parents=True, exist_ok=True)

    for filename, content in files.items():
        disk_name = FILENAME_MAP.get(filename, filename)
        (pending_path / disk_name).write_text(content)

    return str(pending_path)





def archive_applied(pending_dir: str) -> str:
    """Move a successfully applied config to the applied archive."""
    src = Path(pending_dir)
    if not src.exists():
        return ""

    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    dest = APPLIED_DIR / timestamp
    dest.mkdir(parents=True, exist_ok=True)

    for f in src.iterdir():
        if f.is_file():
            (dest / f.name).write_text(f.read_text())

    return str(dest)


# ─── Core Generation Loop ─────────────────────────────────────────────────────

def generate_tf(
    prompt: str,
    provider: str,
    region: str,
    model: str = MODEL,
    max_attempts: int = 2,
) -> GenerateResult:
    """Generate OpenTofu HCL from a natural language prompt.

    Attempts generation, validates with 'tofu validate', retries once
    if validation fails with the error fed back into the prompt.

    Returns GenerateResult with success flag, files, and error info.
    """
    system = SYSTEM_PROMPT.replace("{provider}", provider).replace("{region}", region)
    current_prompt = prompt

    for attempt in range(max_attempts):
        # 1. Call LLM
        try:
            raw = call_llm(system, current_prompt, model=model)
        except RuntimeError as e:
            return GenerateResult(
                success=False,
                error=f"LLM call failed: {e}",
                attempts=attempt + 1,
            )

        # 2. Parse JSON
        files = {}
        try:
            files = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            if attempt < max_attempts - 1:
                current_prompt = (
                    f"{prompt}\n\n"
                    f"Your previous response was not valid JSON. "
                    f"Return ONLY a JSON object with keys: main_tf, variables_tf, outputs_tf. "
                    f"No markdown, no explanation."
                )
                continue
            return GenerateResult(
                success=False,
                files=files if isinstance(files, dict) else {},
                error="LLM returned malformed JSON after retry",
                attempts=attempt + 1,
            )

        # 3. Inject provider boilerplate
        files["main_tf"] = get_provider_boilerplate(provider, region) + files.get("main_tf", "")

        # 4. Validate keys
        required_keys = {"main_tf", "variables_tf", "outputs_tf"}
        if not required_keys.issubset(files.keys()):
            if attempt < max_attempts - 1:
                missing = required_keys - set(files.keys())
                current_prompt = (
                    f"{prompt}\n\n"
                    f"Missing required keys in your response: {', '.join(missing)}. "
                    f"Return ONLY a JSON object with keys: main_tf, variables_tf, outputs_tf."
                )
                continue
            return GenerateResult(
                success=False,
                files=files,
                error=f"Missing required keys: {required_keys - set(files.keys())}",
                attempts=attempt + 1,
            )

        # 5. Write to pending
        pending_dir = write_pending(files)

        # 6. Validate with tofu
        valid, error = run_tofu_validate(pending_dir)

        if valid:
            return GenerateResult(
                success=True,
                files=files,
                attempts=attempt + 1,
                pending_dir=pending_dir,
            )

        # 7. Retry with error feedback
        if attempt < max_attempts - 1:
            current_prompt = (
                f"{prompt}\n\n"
                f"The previous attempt failed validation with this error:\n{error}\n\n"
                f"Fix the error and regenerate. Return ONLY the JSON object."
            )
            continue

        return GenerateResult(
            success=False,
            files=files,
            error=f"Validation failed after {max_attempts} attempts: {error}",
            attempts=attempt + 1,
            pending_dir=pending_dir,
        )

    # Unreachable
    return GenerateResult(success=False, error="Unexpected error", attempts=max_attempts)


# ─── Main (standalone test) ───────────────────────────────────────────────────

def main() -> None:
    """Standalone mode: detect provider, generate, save to pending."""
    if len(sys.argv) < 2:
        print("Usage: python generate.py 'I need a k8s cluster'", file=sys.stderr)
        sys.exit(1)

    user_prompt = " ".join(sys.argv[1:])
    provider, region = detect_provider()

    print(f"Provider: {provider} ({region})")
    print(f"Model: {MODEL}")
    print("Generating...")
    print()

    result = generate_tf(user_prompt, provider, region)

    if result.success:
        print(f"✓ Generation successful ({result.attempts} attempt(s))")
        print(f"  Files saved to: {result.pending_dir}")
        for name, content in result.files.items():
            lines = content.count('\n') + 1
            print(f"    {name}: {lines} lines")
    else:
        print(f"✗ Generation failed: {result.error}", file=sys.stderr)
        if result.files:
            print(f"  Partial files saved to: {result.pending_dir}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
