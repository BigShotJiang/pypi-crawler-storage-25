"""cctx: profile, debug, and optimize Claude Code and Agent SDK sessions."""

__version__ = "1.0.0"
