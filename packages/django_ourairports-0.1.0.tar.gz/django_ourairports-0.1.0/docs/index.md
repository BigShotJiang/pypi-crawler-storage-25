---
layout: default
title: Home
nav_order: 1
---

# django-ourairports

A Django application to download and import aviation data from [OurAirports](https://ourairports.com/data/).

## Features

- **Comprehensive Data**: Import airports, runways, frequencies, navaids, countries, and regions
- **GeoDjango Support**: Full spatial query support with PostGIS
- **Flexible Imports**: Import all data or select specific types
- **Plugin System**: Customize imports with pre/post hooks
- **Incremental Updates**: Smart change detection to minimize database writes
- **Management Command**: Easy-to-use CLI for all operations

## Quick Start

```bash
pip install django-ourairports
```

```python
INSTALLED_APPS = [
    ...
    'django.contrib.gis',
    'ourairports',
]
```

```bash
python manage.py migrate ourairports
python manage.py ourairports --import=all
```

## Data Coverage

OurAirports provides data for:

- **70,000+** airports worldwide
- **45,000+** runways
- **30,000+** radio frequencies
- **11,000+** navigation aids
- **250+** countries
- **4,000+** regions

## Navigation

- [Installation](installation.md) - Setup and requirements
- [Configuration](configuration.md) - Settings and options
- [Importing Data](importing-data.md) - Management command usage
- [Models](models.md) - Database models reference
- [Examples](examples.md) - Code examples and recipes

## License

MIT License
