---
layout: default
title: Configuration
nav_order: 3
---

# Configuration

## Settings

Configure django-ourairports in your Django `settings.py`:

```python
OURAIRPORTS = {
    # Directory for downloaded data files
    'DATA_DIR': '/path/to/data',

    # Cache duration in seconds (default: 86400 = 24 hours)
    'CACHE_DURATION': 86400,

    # Batch size for bulk operations (default: 1000)
    'BATCH_SIZE': 1000,

    # Plugin modules for import hooks
    'PLUGINS': [],
}
```

## Setting Reference

### DATA_DIR

Directory where downloaded CSV files are stored.

**Default**: `~/.ourairports/data`

```python
OURAIRPORTS = {
    'DATA_DIR': '/var/data/ourairports',
}
```

### CACHE_DURATION

How long to cache downloaded files before re-downloading.

**Default**: `86400` (24 hours)

```python
OURAIRPORTS = {
    'CACHE_DURATION': 3600,  # 1 hour
}
```

Set to `0` to always re-download:

```python
OURAIRPORTS = {
    'CACHE_DURATION': 0,
}
```

### BATCH_SIZE

Number of records to process in each batch during bulk operations.

**Default**: `1000`

```python
OURAIRPORTS = {
    'BATCH_SIZE': 5000,  # Larger batches for faster imports
}
```

### PLUGINS

List of Python modules containing import hooks.

**Default**: `[]`

```python
OURAIRPORTS = {
    'PLUGINS': [
        'myapp.ourairports_hooks',
        'otherapp.plugins',
    ],
}
```

## Environment Variables

Settings can also be configured via environment variables:

```bash
export OURAIRPORTS_DATA_DIR=/var/data/ourairports
export OURAIRPORTS_CACHE_DURATION=3600
export OURAIRPORTS_BATCH_SIZE=5000
```

## Data URLs

The default data URLs point to the official OurAirports data repository:

```python
DATA_URLS = {
    'airports': 'https://davidmegginson.github.io/ourairports-data/airports.csv',
    'countries': 'https://davidmegginson.github.io/ourairports-data/countries.csv',
    'regions': 'https://davidmegginson.github.io/ourairports-data/regions.csv',
    'runways': 'https://davidmegginson.github.io/ourairports-data/runways.csv',
    'airport-frequencies': 'https://davidmegginson.github.io/ourairports-data/airport-frequencies.csv',
    'navaids': 'https://davidmegginson.github.io/ourairports-data/navaids.csv',
}
```

To use custom URLs:

```python
OURAIRPORTS = {
    'DATA_URLS': {
        'airports': 'https://your-mirror.com/airports.csv',
    },
}
```

## Logging

Configure logging for import operations:

```python
LOGGING = {
    'version': 1,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'ourairports': {
            'handlers': ['console'],
            'level': 'INFO',
        },
    },
}
```

Available log levels:
- `DEBUG`: Detailed import progress
- `INFO`: Summary statistics
- `WARNING`: Skipped records
- `ERROR`: Import failures
