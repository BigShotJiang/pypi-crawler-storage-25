---
layout: default
title: Examples
nav_order: 6
---

# Examples

## Basic Queries

### Find Airport by Code

```python
from ourairports.models import Airport

# By IATA code
jfk = Airport.objects.get(iata_code='JFK')

# By ICAO/GPS code
kjfk = Airport.objects.get(gps_code='KJFK')

# By identifier
airport = Airport.objects.get(ident='KJFK')
```

### List Airports by Country

```python
from ourairports.models import Airport

# US airports
us_airports = Airport.objects.filter(iso_country='US')

# UK large airports
uk_large = Airport.objects.filter(
    iso_country='GB',
    airport_type='large_airport'
)
```

### Airports with Scheduled Service

```python
from ourairports.models import Airport

scheduled = Airport.objects.filter(scheduled_service=True)

# Scheduled service in a region
ca_scheduled = Airport.objects.filter(
    iso_region='US-CA',
    scheduled_service=True
)
```

## Spatial Queries

### Find Nearby Airports

```python
from django.contrib.gis.geos import Point
from django.contrib.gis.measure import D
from ourairports.models import Airport

# JFK coordinates
point = Point(-73.7781, 40.6413)

# Airports within 50km
nearby = Airport.objects.filter(
    location__distance_lte=(point, D(km=50))
).order_by('location')

for airport in nearby:
    print(f"{airport.iata_code}: {airport.name}")
```

### Distance Calculation

```python
from django.contrib.gis.db.models.functions import Distance
from django.contrib.gis.geos import Point
from ourairports.models import Airport

point = Point(-73.7781, 40.6413)

airports = Airport.objects.filter(
    iso_country='US',
    scheduled_service=True
).annotate(
    distance=Distance('location', point)
).order_by('distance')[:10]

for airport in airports:
    print(f"{airport.iata_code}: {airport.distance.km:.1f} km")
```

### Airports Within Bounding Box

```python
from django.contrib.gis.geos import Polygon
from ourairports.models import Airport

# New York area bounding box
bbox = Polygon.from_bbox((-74.5, 40.4, -73.5, 41.0))

airports = Airport.objects.filter(location__within=bbox)
```

## Related Data

### Airport Runways

```python
from ourairports.models import Airport

jfk = Airport.objects.get(iata_code='JFK')

for runway in jfk.runways.all():
    print(f"Runway {runway.le_ident}/{runway.he_ident}: "
          f"{runway.length_ft}ft x {runway.width_ft}ft, "
          f"Surface: {runway.surface}")
```

### Airport Frequencies

```python
from ourairports.models import Airport

jfk = Airport.objects.get(iata_code='JFK')

# All frequencies
for freq in jfk.frequencies.all():
    print(f"{freq.frequency_type}: {freq.frequency_mhz} MHz")

# Tower frequencies only
tower_freqs = jfk.frequencies.filter(frequency_type='TWR')
```

### Navaids Near Airport

```python
from ourairports.models import Airport, Navaid

jfk = Airport.objects.get(iata_code='JFK')

# Associated navaids
navaids = jfk.navaids.all()

# VORs near JFK
from django.contrib.gis.measure import D
vors = Navaid.objects.filter(
    navaid_type__in=['VOR', 'VOR-DME', 'VORTAC'],
    location__distance_lte=(jfk.location, D(nm=50))
)
```

## Filtering and Aggregation

### Count Airports by Type

```python
from django.db.models import Count
from ourairports.models import Airport

counts = Airport.objects.values('airport_type').annotate(
    count=Count('id')
).order_by('-count')

for item in counts:
    print(f"{item['airport_type']}: {item['count']}")
```

### Airports by Continent

```python
from django.db.models import Count
from ourairports.models import Airport

by_continent = Airport.objects.values('continent').annotate(
    count=Count('id')
).order_by('-count')
```

### Longest Runways

```python
from ourairports.models import Runway

longest = Runway.objects.filter(
    length_ft__isnull=False
).select_related('airport').order_by('-length_ft')[:10]

for runway in longest:
    print(f"{runway.airport.name}: {runway.length_ft}ft")
```

## Complex Queries

### Airports with Long Runways and Scheduled Service

```python
from django.db.models import Max
from ourairports.models import Airport

# Airports with runways >= 10000ft and scheduled service
airports = Airport.objects.filter(
    scheduled_service=True,
    runways__length_ft__gte=10000
).distinct()
```

### Regions with Most Airports

```python
from django.db.models import Count
from ourairports.models import Region

regions = Region.objects.annotate(
    airport_count=Count('airports')
).order_by('-airport_count')[:20]

for region in regions:
    print(f"{region.name}: {region.airport_count} airports")
```

### Search Airports

```python
from django.db.models import Q
from ourairports.models import Airport

query = "international"
results = Airport.objects.filter(
    Q(name__icontains=query) |
    Q(municipality__icontains=query) |
    Q(keywords__icontains=query)
)
```

## Views and Serializers

### Django REST Framework Example

```python
from rest_framework import serializers, viewsets
from ourairports.models import Airport

class AirportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Airport
        fields = [
            'id', 'ident', 'name', 'iata_code', 'gps_code',
            'airport_type', 'latitude', 'longitude',
            'municipality', 'iso_country', 'scheduled_service',
        ]

class AirportViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Airport.objects.all()
    serializer_class = AirportSerializer
    filterset_fields = ['airport_type', 'iso_country', 'scheduled_service']
    search_fields = ['name', 'iata_code', 'municipality']
```

### GeoJSON Export

```python
from django.contrib.gis.serializers import Serializer as GeoJSONSerializer
from ourairports.models import Airport

airports = Airport.objects.filter(iso_country='US', scheduled_service=True)
geojson = GeoJSONSerializer().serialize(
    airports,
    geometry_field='location',
    fields=['name', 'iata_code', 'municipality']
)
```

## Cron Job Example

```python
# management/commands/update_airports.py
from django.core.management.base import BaseCommand
from django.core.management import call_command

class Command(BaseCommand):
    help = 'Daily airport data update'

    def handle(self, *args, **options):
        call_command('ourairports', import_type='all', force=True)
        self.stdout.write('Airport data updated')
```

```bash
# Crontab entry (daily at 2 AM)
0 2 * * * /path/to/venv/bin/python /path/to/manage.py update_airports
```
