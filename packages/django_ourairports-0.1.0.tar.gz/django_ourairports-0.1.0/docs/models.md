---
layout: default
title: Models
nav_order: 5
---

# Models

## Country

Country information from OurAirports.

```python
from ourairports.models import Country
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `ourairports_id` | PositiveIntegerField | OurAirports unique ID |
| `code` | CharField(2) | ISO 3166-1 alpha-2 code |
| `name` | CharField(100) | Country name |
| `continent` | CharField(2) | Continent code (AF, AN, AS, EU, NA, OC, SA) |
| `wikipedia_link` | URLField | Wikipedia article URL |
| `keywords` | TextField | Search keywords |

### Relationships

- `regions` - Related Region objects
- `airports` - Related Airport objects
- `navaids` - Related Navaid objects

---

## Region

Administrative regions (states, provinces, territories).

```python
from ourairports.models import Region
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `ourairports_id` | PositiveIntegerField | OurAirports unique ID |
| `code` | CharField(10) | ISO 3166-2 code (e.g., US-CA) |
| `local_code` | CharField(10) | Local code (e.g., CA) |
| `name` | CharField(100) | Region name |
| `continent` | CharField(2) | Continent code |
| `iso_country` | CharField(2) | ISO country code |
| `wikipedia_link` | URLField | Wikipedia article URL |
| `keywords` | TextField | Search keywords |
| `country` | ForeignKey | Related Country |

### Relationships

- `country` - Parent Country object
- `airports` - Related Airport objects

---

## Airport

Airport and airfield information.

```python
from ourairports.models import Airport
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `ourairports_id` | PositiveIntegerField | OurAirports unique ID |
| `ident` | CharField(10) | ICAO identifier or local code |
| `airport_type` | CharField(20) | Airport type (see choices below) |
| `name` | CharField(200) | Airport name |
| `slug` | SlugField | URL-friendly name |
| `location` | PointField | Geographic location (SRID 4326) |
| `latitude` | FloatField | Latitude in decimal degrees |
| `longitude` | FloatField | Longitude in decimal degrees |
| `elevation_ft` | IntegerField | Elevation in feet |
| `elevation_m` | FloatField | Elevation in meters |
| `continent` | CharField(2) | Continent code |
| `iso_country` | CharField(2) | ISO country code |
| `iso_region` | CharField(10) | ISO region code |
| `municipality` | CharField(100) | City/town name |
| `scheduled_service` | BooleanField | Has scheduled airline service |
| `gps_code` | CharField(10) | GPS/ICAO code |
| `iata_code` | CharField(3) | IATA code |
| `local_code` | CharField(10) | Local identifier |
| `home_link` | URLField | Airport website |
| `wikipedia_link` | URLField | Wikipedia article URL |
| `keywords` | TextField | Search keywords |
| `country` | ForeignKey | Related Country |
| `region` | ForeignKey | Related Region |
| `created_at` | DateTimeField | Record created timestamp |
| `updated_at` | DateTimeField | Record updated timestamp |

### Airport Types

| Value | Display |
|-------|---------|
| `balloonport` | Balloonport |
| `closed` | Closed |
| `heliport` | Heliport |
| `large_airport` | Large Airport |
| `medium_airport` | Medium Airport |
| `seaplane_base` | Seaplane Base |
| `small_airport` | Small Airport |

### Relationships

- `country` - Parent Country object
- `region` - Parent Region object
- `runways` - Related Runway objects
- `frequencies` - Related Frequency objects
- `navaids` - Related Navaid objects

---

## Runway

Airport runway information.

```python
from ourairports.models import Runway
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `ourairports_id` | PositiveIntegerField | OurAirports unique ID |
| `airport_ident` | CharField(10) | Airport identifier |
| `length_ft` | IntegerField | Runway length in feet |
| `width_ft` | IntegerField | Runway width in feet |
| `surface` | CharField(50) | Surface type (ASP, CON, GRS, etc.) |
| `lighted` | BooleanField | Has lighting |
| `closed` | BooleanField | Is closed |
| `le_ident` | CharField(10) | Low-end designation (e.g., 09) |
| `le_location` | PointField | Low-end coordinates |
| `le_latitude` | FloatField | Low-end latitude |
| `le_longitude` | FloatField | Low-end longitude |
| `le_elevation_ft` | IntegerField | Low-end elevation |
| `le_heading` | FloatField | Low-end true heading |
| `le_displaced_threshold_ft` | IntegerField | Low-end displaced threshold |
| `he_ident` | CharField(10) | High-end designation (e.g., 27) |
| `he_location` | PointField | High-end coordinates |
| `he_latitude` | FloatField | High-end latitude |
| `he_longitude` | FloatField | High-end longitude |
| `he_elevation_ft` | IntegerField | High-end elevation |
| `he_heading` | FloatField | High-end true heading |
| `he_displaced_threshold_ft` | IntegerField | High-end displaced threshold |
| `airport` | ForeignKey | Related Airport |
| `created_at` | DateTimeField | Record created timestamp |
| `updated_at` | DateTimeField | Record updated timestamp |

---

## Frequency

Airport radio frequencies.

```python
from ourairports.models import Frequency
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `ourairports_id` | PositiveIntegerField | OurAirports unique ID |
| `airport_ident` | CharField(10) | Airport identifier |
| `frequency_type` | CharField(20) | Frequency type (TWR, APP, etc.) |
| `description` | CharField(200) | Frequency description |
| `frequency_mhz` | DecimalField | Frequency in MHz |
| `airport` | ForeignKey | Related Airport |
| `created_at` | DateTimeField | Record created timestamp |
| `updated_at` | DateTimeField | Record updated timestamp |

### Common Frequency Types

| Type | Description |
|------|-------------|
| `TWR` | Tower |
| `APP` | Approach |
| `DEP` | Departure |
| `GND` | Ground |
| `ATIS` | Automatic Terminal Information Service |
| `CTAF` | Common Traffic Advisory Frequency |
| `UNICOM` | Universal Communications |

---

## Navaid

Navigation aid information.

```python
from ourairports.models import Navaid
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `ourairports_id` | PositiveIntegerField | OurAirports unique ID |
| `ident` | CharField(10) | Navaid identifier |
| `name` | CharField(100) | Navaid name |
| `slug` | SlugField | URL-friendly name |
| `navaid_type` | CharField(10) | Navaid type (see choices below) |
| `location` | PointField | Geographic location |
| `latitude` | FloatField | Latitude in decimal degrees |
| `longitude` | FloatField | Longitude in decimal degrees |
| `elevation_ft` | IntegerField | Elevation in feet |
| `frequency_khz` | IntegerField | Frequency in kHz |
| `dme_frequency_khz` | IntegerField | DME frequency in kHz |
| `dme_channel` | CharField(10) | DME channel |
| `dme_location` | PointField | DME location (if separate) |
| `dme_latitude` | FloatField | DME latitude |
| `dme_longitude` | FloatField | DME longitude |
| `dme_elevation_ft` | IntegerField | DME elevation |
| `slaved_variation` | FloatField | Slaved magnetic variation |
| `magnetic_variation` | FloatField | Local magnetic variation |
| `usage_type` | CharField(20) | Usage type (TERMINAL, BOTH, etc.) |
| `power` | CharField(20) | Power output |
| `iso_country` | CharField(2) | ISO country code |
| `associated_airport_ident` | CharField(10) | Associated airport identifier |
| `country` | ForeignKey | Related Country |
| `associated_airport` | ForeignKey | Related Airport |
| `created_at` | DateTimeField | Record created timestamp |
| `updated_at` | DateTimeField | Record updated timestamp |

### Navaid Types

| Value | Description |
|-------|-------------|
| `DME` | Distance Measuring Equipment |
| `NDB` | Non-Directional Beacon |
| `NDB-DME` | NDB with DME |
| `TACAN` | Tactical Air Navigation |
| `VOR` | VHF Omnidirectional Range |
| `VOR-DME` | VOR with DME |
| `VORTAC` | VOR with TACAN |
