---
layout: default
title: Importing Data
nav_order: 4
---

# Importing Data

## Management Command

The `ourairports` management command handles all data operations.

```bash
python manage.py ourairports [options]
```

## Import Data

### Import All Data

```bash
python manage.py ourairports --import=all
```

This imports in dependency order:
1. Countries
2. Regions
3. Airports
4. Runways
5. Frequencies
6. Navaids

### Import Specific Types

```bash
# Single type
python manage.py ourairports --import=airport

# Multiple types
python manage.py ourairports --import=airport,runway,frequency
```

### Available Import Types

| Type | Description | Records |
|------|-------------|---------|
| `country` | Countries | ~250 |
| `region` | Regions/States | ~4,000 |
| `airport` | Airports | ~70,000 |
| `runway` | Runways | ~45,000 |
| `frequency` | Radio frequencies | ~30,000 |
| `navaid` | Navigation aids | ~11,000 |
| `all` | Everything | ~160,000 |

## Flush Data

Delete existing data before importing:

```bash
# Flush all
python manage.py ourairports --flush=all --import=all

# Flush specific types
python manage.py ourairports --flush=airport,runway --import=airport,runway
```

## Command Options

### --import

Specify what to import.

```bash
python manage.py ourairports --import=all
python manage.py ourairports --import=airport,runway
```

### --flush

Delete existing data before import.

```bash
python manage.py ourairports --flush=all
python manage.py ourairports --flush=airport
```

### --force

Force re-download of data files, ignoring cache.

```bash
python manage.py ourairports --import=all --force
```

### --quiet

Suppress progress output.

```bash
python manage.py ourairports --import=all --quiet
```

### --dry-run

Parse data without saving to database.

```bash
python manage.py ourairports --import=airport --dry-run
```

### --download-only

Download files without importing.

```bash
python manage.py ourairports --download-only
```

### --list

List cached data files.

```bash
python manage.py ourairports --list
```

### --clear

Clear the download cache.

```bash
python manage.py ourairports --clear
```

## Import Process

### How It Works

1. **Download**: CSV files are downloaded from OurAirports
2. **Parse**: CSV rows are parsed and validated
3. **Transform**: Data is transformed to model fields
4. **Resolve**: Foreign keys are resolved (country, region, airport)
5. **Save**: Records are created or updated in batches

### Change Detection

The importer uses `ourairports_id` to detect existing records:

- **New records**: Created with all fields
- **Existing records**: Updated if data has changed
- **Missing records**: Optionally deleted (with `--flush`)

### Dependency Order

Imports respect dependencies:

1. **Countries** (no dependencies)
2. **Regions** (depends on countries)
3. **Airports** (depends on countries, regions)
4. **Runways** (depends on airports)
5. **Frequencies** (depends on airports)
6. **Navaids** (depends on countries, airports)

## Examples

### Initial Setup

```bash
# First time: import everything
python manage.py ourairports --import=all
```

### Daily Update

```bash
# Update all data (uses cache if < 24 hours old)
python manage.py ourairports --import=all

# Force fresh download
python manage.py ourairports --import=all --force
```

### Refresh Airports Only

```bash
python manage.py ourairports --flush=airport --import=airport
```

### Development Testing

```bash
# Dry run to check for errors
python manage.py ourairports --import=airport --dry-run

# Import with verbose output
python manage.py ourairports --import=country,region
```

## Troubleshooting

### Import Fails with Foreign Key Error

Ensure you import dependencies first:

```bash
# Wrong: airports before countries
python manage.py ourairports --import=airport  # May fail

# Correct: import in order
python manage.py ourairports --import=country,region,airport
```

### Memory Issues

Reduce batch size in settings:

```python
OURAIRPORTS = {
    'BATCH_SIZE': 500,
}
```

### Slow Imports

Increase batch size (if memory allows):

```python
OURAIRPORTS = {
    'BATCH_SIZE': 5000,
}
```
