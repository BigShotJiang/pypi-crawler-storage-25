---
layout: default
title: Installation
nav_order: 2
---

# Installation

## Requirements

- Python 3.10 or higher
- Django 4.2 or higher
- PostGIS (recommended) or SpatiaLite
- GDAL library

## Install from PyPI

```bash
pip install django-ourairports
```

## Install from Source

```bash
git clone https://github.com/yourusername/django-ourairports.git
cd django-ourairports
pip install -e .
```

## Django Configuration

Add `ourairports` to your `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    'django.contrib.gis',
    'ourairports',
]
```

## Database Setup

### PostGIS (Recommended)

1. Install PostGIS extension in your PostgreSQL database:

```sql
CREATE EXTENSION postgis;
```

2. Configure Django to use PostGIS:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': 'your_database',
        'USER': 'your_user',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
```

### SpatiaLite (Development)

For development/testing with SQLite:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.spatialite',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

SPATIALITE_LIBRARY_PATH = '/usr/lib/x86_64-linux-gnu/mod_spatialite.so'
```

## Run Migrations

```bash
python manage.py migrate ourairports
```

## Verify Installation

```bash
python manage.py ourairports --help
```

## GDAL Installation

### macOS

```bash
brew install gdal
```

### Ubuntu/Debian

```bash
sudo apt-get install gdal-bin libgdal-dev
```

### Windows

Download from [GIS Internals](https://www.gisinternals.com/release.php) or use OSGeo4W.

## Troubleshooting

### GDAL Library Not Found

Set the GDAL library path:

```python
GDAL_LIBRARY_PATH = '/path/to/libgdal.so'
```

### SpatiaLite Library Not Found

Install and configure SpatiaLite:

```bash
# Ubuntu/Debian
sudo apt-get install libsqlite3-mod-spatialite

# macOS
brew install spatialite-tools
```
