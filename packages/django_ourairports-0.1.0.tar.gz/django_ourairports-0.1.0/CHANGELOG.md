# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2024-01-01

### Added
- Initial release
- Country model with ISO codes and continent
- Region model with ISO 3166-2 codes
- Airport model with full OurAirports data
- Runway model with both end coordinates
- Frequency model for radio communications
- Navaid model (VOR, NDB, DME, TACAN)
- Management command for importing data
- GeoDjango support for spatial queries
- Plugin system for import customization
- Django admin integration
- Documentation
