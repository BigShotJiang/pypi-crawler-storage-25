# django-ourairports

A Django application to download and import aviation data from [OurAirports](https://ourairports.com/data/).

## Features

- Import airports, runways, frequencies, navaids, countries, and regions
- GeoDjango support for spatial queries
- Customizable import via plugin hooks
- Management command for easy data management
- Incremental updates with change detection

## Requirements

- Python 3.10+
- Django 4.2+
- PostGIS (recommended) or SpatiaLite
- GDAL

## Installation

```bash
pip install django-ourairports
```

Add to your `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    'django.contrib.gis',
    'ourairports',
]
```

Run migrations:

```bash
python manage.py migrate ourairports
```

## Quick Start

Import all data:

```bash
python manage.py ourairports --import=all
```

Import specific data types:

```bash
python manage.py ourairports --import=airport,runway
```

Flush and reimport:

```bash
python manage.py ourairports --flush=all --import=all
```

## Configuration

Optional settings in `settings.py`:

```python
OURAIRPORTS = {
    # Directory for downloaded data files
    'DATA_DIR': '/path/to/data',

    # Cache duration in seconds (default: 86400 = 24 hours)
    'CACHE_DURATION': 86400,

    # Batch size for bulk operations
    'BATCH_SIZE': 1000,
}
```

## Models

### Country
Country information with ISO codes and continent.

### Region
Administrative regions (states, provinces) with ISO 3166-2 codes.

### Airport
Airports with location, type, codes (IATA, ICAO/GPS), and metadata.

### Runway
Runway details including dimensions, surface, lighting, and end coordinates.

### Frequency
Radio frequencies (TWR, APP, ATIS, etc.) for airports.

### Navaid
Navigation aids (VOR, NDB, DME, TACAN) with locations and frequencies.

## Usage Examples

```python
from ourairports.models import Airport, Country, Runway

# Find airports by IATA code
jfk = Airport.objects.get(iata_code='JFK')

# Find large airports in a country
us_large = Airport.objects.filter(
    iso_country='US',
    airport_type='large_airport'
)

# Airports with scheduled service
scheduled = Airport.objects.filter(scheduled_service=True)

# Find airports near a point (requires PostGIS)
from django.contrib.gis.geos import Point
from django.contrib.gis.measure import D

point = Point(-73.7781, 40.6413)  # JFK coordinates
nearby = Airport.objects.filter(
    location__distance_lte=(point, D(km=50))
)

# Get runways for an airport
runways = jfk.runways.all()

# Get frequencies for an airport
frequencies = jfk.frequencies.filter(frequency_type='TWR')
```

## Management Command

```bash
# Show help
python manage.py ourairports --help

# Import all data
python manage.py ourairports --import=all

# Import specific types
python manage.py ourairports --import=country,region,airport

# Flush data before import
python manage.py ourairports --flush=airport --import=airport

# Force re-download (ignore cache)
python manage.py ourairports --import=all --force

# Dry run (parse without saving)
python manage.py ourairports --import=airport --dry-run

# Download only (no import)
python manage.py ourairports --download-only

# List cached files
python manage.py ourairports --list

# Clear cache
python manage.py ourairports --clear
```

## Import Options

| Option | Description |
|--------|-------------|
| `country` | Countries |
| `region` | Regions (states/provinces) |
| `airport` | Airports |
| `runway` | Runways |
| `frequency` | Radio frequencies |
| `navaid` | Navigation aids |
| `all` | All of the above |

## Plugin System

Customize imports with hooks:

```python
# yourapp/plugins.py
from ourairports.plugin import HookException

def airport_pre(row, importer):
    """Called before each airport is processed."""
    # Skip closed airports
    if row.get('type') == 'closed':
        raise HookException("Skipping closed airport")
    return row

def airport_post(airport, row, importer):
    """Called after each airport is saved."""
    # Add custom processing
    pass
```

Register in settings:

```python
OURAIRPORTS = {
    'PLUGINS': ['yourapp.plugins'],
}
```

## Data Source

Data is sourced from [OurAirports](https://ourairports.com/data/), a community-maintained database of airports worldwide. The data is released to the public domain.

## Disclaimer

This project is not affiliated with, endorsed by, or associated with [OurAirports](https://ourairports.com/) or its maintainers. It is an independent, third-party Django integration that consumes publicly available OurAirports data.

## License

MIT License - see [LICENSE](LICENSE) for details.

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](.github/CONTRIBUTING.md) for guidelines.
