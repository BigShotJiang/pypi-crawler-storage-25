"""
Django models for OurAirports aviation data.

Provides models for airports, runways, frequencies, navaids, countries, and regions.
"""

from django.contrib.gis.db import models as gis_models
from django.db import models
from django.utils.translation import gettext_lazy as _


class Country(models.Model):
    """
    Country reference model from OurAirports.
    """

    # OurAirports ID
    ourairports_id = models.PositiveIntegerField(
        _("OurAirports ID"),
        unique=True,
    )

    # ISO country code
    code = models.CharField(
        _("code"),
        max_length=2,
        unique=True,
        db_index=True,
        help_text=_("ISO 3166-1 alpha-2 country code"),
    )

    name = models.CharField(
        _("name"),
        max_length=100,
        db_index=True,
    )

    continent = models.CharField(
        _("continent"),
        max_length=2,
        blank=True,
        db_index=True,
        help_text=_("Continent code (AF, AN, AS, EU, NA, OC, SA)"),
    )

    wikipedia_link = models.URLField(
        _("Wikipedia link"),
        max_length=500,
        blank=True,
    )

    keywords = models.TextField(
        _("keywords"),
        blank=True,
        help_text=_("Comma-separated search keywords"),
    )

    class Meta:
        verbose_name = _("country")
        verbose_name_plural = _("countries")
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.code})"


class Region(models.Model):
    """
    Region/subdivision reference model from OurAirports.
    """

    # OurAirports ID
    ourairports_id = models.PositiveIntegerField(
        _("OurAirports ID"),
        unique=True,
    )

    # ISO region code (e.g., "US-CA")
    code = models.CharField(
        _("code"),
        max_length=10,
        unique=True,
        db_index=True,
        help_text=_("ISO 3166-2 subdivision code"),
    )

    local_code = models.CharField(
        _("local code"),
        max_length=10,
        blank=True,
        help_text=_("Local administrative code"),
    )

    name = models.CharField(
        _("name"),
        max_length=100,
        db_index=True,
    )

    continent = models.CharField(
        _("continent"),
        max_length=2,
        blank=True,
        db_index=True,
    )

    country = models.ForeignKey(
        Country,
        on_delete=models.CASCADE,
        related_name="regions",
        null=True,
        blank=True,
    )
    iso_country = models.CharField(
        _("ISO country"),
        max_length=2,
        blank=True,
        db_index=True,
    )

    wikipedia_link = models.URLField(
        _("Wikipedia link"),
        max_length=500,
        blank=True,
    )

    keywords = models.TextField(
        _("keywords"),
        blank=True,
    )

    class Meta:
        verbose_name = _("region")
        verbose_name_plural = _("regions")
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.code})"


class Airport(models.Model):
    """
    Airport model from OurAirports.

    Includes all airport types: large, medium, small airports,
    heliports, seaplane bases, balloonports, and closed airports.
    """

    # Airport type choices
    TYPE_CHOICES = [
        ("balloonport", _("Balloonport")),
        ("closed", _("Closed")),
        ("heliport", _("Heliport")),
        ("large_airport", _("Large Airport")),
        ("medium_airport", _("Medium Airport")),
        ("seaplane_base", _("Seaplane Base")),
        ("small_airport", _("Small Airport")),
    ]

    # OurAirports ID
    ourairports_id = models.PositiveIntegerField(
        _("OurAirports ID"),
        unique=True,
    )

    # Identifier (e.g., "KSFO")
    ident = models.CharField(
        _("identifier"),
        max_length=10,
        unique=True,
        db_index=True,
    )

    # Type
    airport_type = models.CharField(
        _("type"),
        max_length=20,
        choices=TYPE_CHOICES,
        db_index=True,
    )

    name = models.CharField(
        _("name"),
        max_length=200,
        db_index=True,
    )

    slug = models.SlugField(
        _("slug"),
        max_length=200,
        blank=True,
    )

    # Location
    location = gis_models.PointField(
        _("location"),
        srid=4326,
        null=True,
        blank=True,
    )
    latitude = models.FloatField(
        _("latitude"),
        null=True,
        blank=True,
    )
    longitude = models.FloatField(
        _("longitude"),
        null=True,
        blank=True,
    )
    elevation_ft = models.IntegerField(
        _("elevation (ft)"),
        null=True,
        blank=True,
        help_text=_("Elevation in feet"),
    )
    elevation_m = models.FloatField(
        _("elevation (m)"),
        null=True,
        blank=True,
        help_text=_("Elevation in meters"),
    )

    # Geographic references
    continent = models.CharField(
        _("continent"),
        max_length=2,
        blank=True,
        db_index=True,
    )

    country = models.ForeignKey(
        Country,
        on_delete=models.SET_NULL,
        related_name="airports",
        null=True,
        blank=True,
    )
    iso_country = models.CharField(
        _("ISO country"),
        max_length=2,
        blank=True,
        db_index=True,
    )

    region = models.ForeignKey(
        Region,
        on_delete=models.SET_NULL,
        related_name="airports",
        null=True,
        blank=True,
    )
    iso_region = models.CharField(
        _("ISO region"),
        max_length=10,
        blank=True,
        db_index=True,
    )

    municipality = models.CharField(
        _("municipality"),
        max_length=100,
        blank=True,
        db_index=True,
        help_text=_("City or town served"),
    )

    # Service info
    scheduled_service = models.BooleanField(
        _("scheduled service"),
        default=False,
        db_index=True,
        help_text=_("Has scheduled airline service"),
    )

    # Codes
    gps_code = models.CharField(
        _("GPS code"),
        max_length=10,
        blank=True,
        db_index=True,
        help_text=_("ICAO code or local GPS code"),
    )
    iata_code = models.CharField(
        _("IATA code"),
        max_length=3,
        blank=True,
        db_index=True,
    )
    local_code = models.CharField(
        _("local code"),
        max_length=10,
        blank=True,
        help_text=_("Local/national identifier"),
    )

    # Links
    home_link = models.URLField(
        _("home link"),
        max_length=500,
        blank=True,
    )
    wikipedia_link = models.URLField(
        _("Wikipedia link"),
        max_length=500,
        blank=True,
    )

    keywords = models.TextField(
        _("keywords"),
        blank=True,
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("airport")
        verbose_name_plural = _("airports")
        ordering = ["name"]
        indexes = [
            models.Index(fields=["airport_type", "iso_country"]),
            models.Index(fields=["iso_country", "scheduled_service"]),
        ]

    def __str__(self):
        if self.iata_code:
            return f"{self.name} ({self.iata_code})"
        return f"{self.name} ({self.ident})"

    def save(self, *args, **kwargs):
        if not self.slug:
            from .util import slugify

            base_slug = slugify(self.name)
            if self.iata_code:
                self.slug = f"{base_slug}-{self.iata_code.lower()}"
            elif self.ident:
                self.slug = f"{base_slug}-{self.ident.lower()}"
            else:
                self.slug = base_slug
        super().save(*args, **kwargs)


class Runway(models.Model):
    """
    Runway model from OurAirports.
    """

    # OurAirports ID
    ourairports_id = models.PositiveIntegerField(
        _("OurAirports ID"),
        unique=True,
    )

    airport = models.ForeignKey(
        Airport,
        on_delete=models.CASCADE,
        related_name="runways",
        null=True,
        blank=True,
    )
    airport_ident = models.CharField(
        _("airport identifier"),
        max_length=10,
        db_index=True,
    )

    # Dimensions
    length_ft = models.IntegerField(
        _("length (ft)"),
        null=True,
        blank=True,
    )
    width_ft = models.IntegerField(
        _("width (ft)"),
        null=True,
        blank=True,
    )

    surface = models.CharField(
        _("surface"),
        max_length=50,
        blank=True,
        help_text=_("Surface material (ASPH, CONC, TURF, etc.)"),
    )

    lighted = models.BooleanField(
        _("lighted"),
        default=False,
    )
    closed = models.BooleanField(
        _("closed"),
        default=False,
    )

    # Low-end (LE) - lower numbered end
    le_ident = models.CharField(
        _("LE identifier"),
        max_length=10,
        blank=True,
        help_text=_("Low-end runway designation (e.g., '09')"),
    )
    le_location = gis_models.PointField(
        _("LE location"),
        srid=4326,
        null=True,
        blank=True,
    )
    le_latitude = models.FloatField(
        _("LE latitude"),
        null=True,
        blank=True,
    )
    le_longitude = models.FloatField(
        _("LE longitude"),
        null=True,
        blank=True,
    )
    le_elevation_ft = models.IntegerField(
        _("LE elevation (ft)"),
        null=True,
        blank=True,
    )
    le_heading = models.FloatField(
        _("LE heading"),
        null=True,
        blank=True,
        help_text=_("True heading in degrees"),
    )
    le_displaced_threshold_ft = models.IntegerField(
        _("LE displaced threshold (ft)"),
        null=True,
        blank=True,
    )

    # High-end (HE) - higher numbered end
    he_ident = models.CharField(
        _("HE identifier"),
        max_length=10,
        blank=True,
        help_text=_("High-end runway designation (e.g., '27')"),
    )
    he_location = gis_models.PointField(
        _("HE location"),
        srid=4326,
        null=True,
        blank=True,
    )
    he_latitude = models.FloatField(
        _("HE latitude"),
        null=True,
        blank=True,
    )
    he_longitude = models.FloatField(
        _("HE longitude"),
        null=True,
        blank=True,
    )
    he_elevation_ft = models.IntegerField(
        _("HE elevation (ft)"),
        null=True,
        blank=True,
    )
    he_heading = models.FloatField(
        _("HE heading"),
        null=True,
        blank=True,
        help_text=_("True heading in degrees"),
    )
    he_displaced_threshold_ft = models.IntegerField(
        _("HE displaced threshold (ft)"),
        null=True,
        blank=True,
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("runway")
        verbose_name_plural = _("runways")
        ordering = ["airport_ident", "le_ident"]

    def __str__(self):
        return f"{self.airport_ident} {self.le_ident}/{self.he_ident}"

    @property
    def designation(self) -> str:
        """Return runway designation (e.g., '09/27')."""
        return f"{self.le_ident}/{self.he_ident}"


class Frequency(models.Model):
    """
    Airport frequency model from OurAirports.
    """

    # OurAirports ID
    ourairports_id = models.PositiveIntegerField(
        _("OurAirports ID"),
        unique=True,
    )

    airport = models.ForeignKey(
        Airport,
        on_delete=models.CASCADE,
        related_name="frequencies",
        null=True,
        blank=True,
    )
    airport_ident = models.CharField(
        _("airport identifier"),
        max_length=10,
        db_index=True,
    )

    frequency_type = models.CharField(
        _("type"),
        max_length=20,
        db_index=True,
        help_text=_("Frequency type (TWR, APP, GND, ATIS, etc.)"),
    )

    description = models.CharField(
        _("description"),
        max_length=200,
        blank=True,
    )

    frequency_mhz = models.DecimalField(
        _("frequency (MHz)"),
        max_digits=8,
        decimal_places=3,
        help_text=_("Frequency in megahertz"),
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("frequency")
        verbose_name_plural = _("frequencies")
        ordering = ["airport_ident", "frequency_type"]

    def __str__(self):
        return f"{self.airport_ident} {self.frequency_type} {self.frequency_mhz}"


class Navaid(models.Model):
    """
    Navigation aid model from OurAirports.

    Includes VOR, NDB, DME, TACAN, and combined types.
    """

    TYPE_CHOICES = [
        ("DME", _("DME")),
        ("NDB", _("NDB")),
        ("NDB-DME", _("NDB-DME")),
        ("TACAN", _("TACAN")),
        ("VOR", _("VOR")),
        ("VOR-DME", _("VOR-DME")),
        ("VORTAC", _("VORTAC")),
    ]

    # OurAirports ID
    ourairports_id = models.PositiveIntegerField(
        _("OurAirports ID"),
        unique=True,
    )

    ident = models.CharField(
        _("identifier"),
        max_length=10,
        db_index=True,
    )

    name = models.CharField(
        _("name"),
        max_length=100,
    )

    slug = models.SlugField(
        _("slug"),
        max_length=100,
        blank=True,
    )

    navaid_type = models.CharField(
        _("type"),
        max_length=10,
        choices=TYPE_CHOICES,
        db_index=True,
    )

    # Location
    location = gis_models.PointField(
        _("location"),
        srid=4326,
        null=True,
        blank=True,
    )
    latitude = models.FloatField(
        _("latitude"),
        null=True,
        blank=True,
    )
    longitude = models.FloatField(
        _("longitude"),
        null=True,
        blank=True,
    )
    elevation_ft = models.IntegerField(
        _("elevation (ft)"),
        null=True,
        blank=True,
    )

    # Frequency
    frequency_khz = models.IntegerField(
        _("frequency (kHz)"),
        null=True,
        blank=True,
    )

    # DME info (for DME-equipped navaids)
    dme_frequency_khz = models.IntegerField(
        _("DME frequency (kHz)"),
        null=True,
        blank=True,
    )
    dme_channel = models.CharField(
        _("DME channel"),
        max_length=10,
        blank=True,
    )
    dme_location = gis_models.PointField(
        _("DME location"),
        srid=4326,
        null=True,
        blank=True,
    )
    dme_latitude = models.FloatField(
        _("DME latitude"),
        null=True,
        blank=True,
    )
    dme_longitude = models.FloatField(
        _("DME longitude"),
        null=True,
        blank=True,
    )
    dme_elevation_ft = models.IntegerField(
        _("DME elevation (ft)"),
        null=True,
        blank=True,
    )

    # Magnetic variation
    slaved_variation = models.FloatField(
        _("slaved variation"),
        null=True,
        blank=True,
        help_text=_("Slaved variation in degrees"),
    )
    magnetic_variation = models.FloatField(
        _("magnetic variation"),
        null=True,
        blank=True,
        help_text=_("Magnetic variation in degrees"),
    )

    # Usage
    usage_type = models.CharField(
        _("usage type"),
        max_length=20,
        blank=True,
        help_text=_("LO, HI, BOTH, TERMINAL, etc."),
    )
    power = models.CharField(
        _("power"),
        max_length=20,
        blank=True,
        help_text=_("Power output category"),
    )

    # Geographic
    country = models.ForeignKey(
        Country,
        on_delete=models.SET_NULL,
        related_name="navaids",
        null=True,
        blank=True,
    )
    iso_country = models.CharField(
        _("ISO country"),
        max_length=2,
        blank=True,
        db_index=True,
    )

    # Associated airport
    associated_airport = models.ForeignKey(
        Airport,
        on_delete=models.SET_NULL,
        related_name="navaids",
        null=True,
        blank=True,
    )
    associated_airport_ident = models.CharField(
        _("associated airport"),
        max_length=10,
        blank=True,
        db_index=True,
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("navaid")
        verbose_name_plural = _("navaids")
        ordering = ["ident"]

    def __str__(self):
        return f"{self.ident} ({self.navaid_type})"

    def save(self, *args, **kwargs):
        if not self.slug:
            from .util import slugify

            self.slug = slugify(f"{self.ident}-{self.name}") or self.ident.lower()
        super().save(*args, **kwargs)
