"""Navaid importer for OurAirports data."""

import logging
from typing import Optional, Tuple

from django.contrib.gis.geos import Point
from django.db import transaction

from ..conf import LOGGER_NAME, get_ourairports_settings
from ..models import Airport, Country, Navaid
from ..util import clean_ident, parse_csv_value, parse_float, parse_int, slugify
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class NavaidImporter(BaseImporter):
    """Importer for navigation aids."""

    data_type = "navaids"

    def __init__(self, command, options: dict):
        super().__init__(command, options)
        self.existing_ids = set()
        self.country_index = {}
        self.airport_index = {}

    def get_model_class(self) -> type:
        return Navaid

    def build_indices(self) -> None:
        self.existing_ids = set(
            Navaid.objects.values_list("ourairports_id", flat=True)
        )
        self.country_index = {
            c.code: c for c in Country.objects.only("id", "code")
        }
        self.airport_index = {
            a.ident: a for a in Airport.objects.only("id", "ident")
        }

    def parse_item(self, item: dict) -> Optional[dict]:
        settings = get_ourairports_settings()

        ourairports_id = parse_int(item.get("id"))
        if not ourairports_id:
            return None

        ident = clean_ident(item.get("ident"))
        if not ident:
            return None

        name = parse_csv_value(item.get("name"))
        if not name:
            name = ident

        navaid_type = (parse_csv_value(item.get("type")) or "")[:10]

        # Location
        latitude = parse_float(item.get("latitude_deg"))
        longitude = parse_float(item.get("longitude_deg"))
        location = None
        if settings.import_geometry and latitude and longitude:
            if -90 <= latitude <= 90 and -180 <= longitude <= 180:
                location = Point(longitude, latitude, srid=4326)

        # DME location
        dme_lat = parse_float(item.get("dme_latitude_deg"))
        dme_lon = parse_float(item.get("dme_longitude_deg"))
        dme_location = None
        if settings.import_geometry and dme_lat and dme_lon:
            if -90 <= dme_lat <= 90 and -180 <= dme_lon <= 180:
                dme_location = Point(dme_lon, dme_lat, srid=4326)

        # Country
        iso_country = (parse_csv_value(item.get("iso_country")) or "")[:2].upper()
        country = self.country_index.get(iso_country)

        # Associated airport
        airport_ident = (parse_csv_value(item.get("associated_airport")) or "")[:10]
        airport = self.airport_index.get(airport_ident)

        slug = slugify(f"{ident}-{name}") or ident.lower()

        return {
            "ourairports_id": ourairports_id,
            "ident": ident[:10],
            "name": name[:100],
            "slug": slug[:100],
            "navaid_type": navaid_type,
            "location": location,
            "latitude": latitude,
            "longitude": longitude,
            "elevation_ft": parse_int(item.get("elevation_ft")),
            "frequency_khz": parse_int(item.get("frequency_khz")),
            "dme_frequency_khz": parse_int(item.get("dme_frequency_khz")),
            "dme_channel": (parse_csv_value(item.get("dme_channel")) or "")[:10],
            "dme_location": dme_location,
            "dme_latitude": dme_lat,
            "dme_longitude": dme_lon,
            "dme_elevation_ft": parse_int(item.get("dme_elevation_ft")),
            "slaved_variation": parse_float(item.get("slaved_variation_deg")),
            "magnetic_variation": parse_float(item.get("magnetic_variation_deg")),
            "usage_type": (parse_csv_value(item.get("usageType")) or "")[:20],
            "power": (parse_csv_value(item.get("power")) or "")[:20],
            "country": country,
            "iso_country": iso_country,
            "associated_airport": airport,
            "associated_airport_ident": airport_ident,
        }

    @transaction.atomic
    def create_or_update(self, parsed: dict) -> Tuple[Navaid, bool]:
        ourairports_id = parsed.pop("ourairports_id")
        location = parsed.pop("location", None)
        dme_location = parsed.pop("dme_location", None)

        if ourairports_id not in self.existing_ids:
            obj = Navaid(ourairports_id=ourairports_id, **parsed)
            if location:
                obj.location = location
            if dme_location:
                obj.dme_location = dme_location
            obj.save()
            self.existing_ids.add(ourairports_id)
            return obj, True
        else:
            obj, created = Navaid.objects.update_or_create(
                ourairports_id=ourairports_id,
                defaults=parsed,
            )
            if location or dme_location:
                if location:
                    obj.location = location
                if dme_location:
                    obj.dme_location = dme_location
                obj.save(update_fields=["location", "dme_location"])
            return obj, created
