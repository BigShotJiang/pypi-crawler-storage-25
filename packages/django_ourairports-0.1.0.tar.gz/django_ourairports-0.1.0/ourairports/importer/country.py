"""Country importer for OurAirports data."""

import logging
from typing import Optional, Tuple

from django.db import transaction

from ..conf import LOGGER_NAME
from ..models import Country
from ..util import parse_csv_value, parse_int
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class CountryImporter(BaseImporter):
    """Importer for countries."""

    data_type = "countries"

    def __init__(self, command, options: dict):
        super().__init__(command, options)
        self.existing_ids = set()

    def get_model_class(self) -> type:
        return Country

    def build_indices(self) -> None:
        self.existing_ids = set(
            Country.objects.values_list("ourairports_id", flat=True)
        )

    def parse_item(self, item: dict) -> Optional[dict]:
        ourairports_id = parse_int(item.get("id"))
        if not ourairports_id:
            return None

        code = parse_csv_value(item.get("code"))
        if not code:
            return None

        name = parse_csv_value(item.get("name"))
        if not name:
            return None

        return {
            "ourairports_id": ourairports_id,
            "code": code[:2].upper(),
            "name": name[:100],
            "continent": (parse_csv_value(item.get("continent")) or "")[:2],
            "wikipedia_link": (parse_csv_value(item.get("wikipedia_link")) or "")[:500],
            "keywords": parse_csv_value(item.get("keywords")) or "",
        }

    @transaction.atomic
    def create_or_update(self, parsed: dict) -> Tuple[Country, bool]:
        ourairports_id = parsed.pop("ourairports_id")

        if ourairports_id not in self.existing_ids:
            obj = Country.objects.create(ourairports_id=ourairports_id, **parsed)
            self.existing_ids.add(ourairports_id)
            return obj, True
        else:
            obj, created = Country.objects.update_or_create(
                ourairports_id=ourairports_id,
                defaults=parsed,
            )
            return obj, created
