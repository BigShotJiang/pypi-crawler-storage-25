"""Airport importer for OurAirports data."""

import logging
from typing import Optional, Tuple

from django.contrib.gis.geos import Point
from django.db import transaction

from ..conf import LOGGER_NAME, get_ourairports_settings
from ..models import Airport, Country, Region
from ..util import (
    clean_iata_code,
    clean_icao_code,
    clean_ident,
    feet_to_meters,
    parse_bool,
    parse_csv_value,
    parse_float,
    parse_int,
    slugify,
)
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class AirportImporter(BaseImporter):
    """Importer for airports."""

    data_type = "airports"

    def __init__(self, command, options: dict):
        super().__init__(command, options)
        self.existing_ids = set()
        self.country_index = {}
        self.region_index = {}

    def get_model_class(self) -> type:
        return Airport

    def build_indices(self) -> None:
        self.existing_ids = set(
            Airport.objects.values_list("ourairports_id", flat=True)
        )
        self.country_index = {
            c.code: c for c in Country.objects.only("id", "code")
        }
        self.region_index = {
            r.code: r for r in Region.objects.only("id", "code")
        }

    def parse_item(self, item: dict) -> Optional[dict]:
        settings = get_ourairports_settings()

        ourairports_id = parse_int(item.get("id"))
        if not ourairports_id:
            return None

        ident = clean_ident(item.get("ident"))
        if not ident:
            return None

        name = parse_csv_value(item.get("name"))
        if not name:
            return None

        airport_type = parse_csv_value(item.get("type")) or "small_airport"

        # Location
        latitude = parse_float(item.get("latitude_deg"))
        longitude = parse_float(item.get("longitude_deg"))

        location = None
        if settings.import_geometry and latitude is not None and longitude is not None:
            if -90 <= latitude <= 90 and -180 <= longitude <= 180:
                location = Point(longitude, latitude, srid=4326)

        elevation_ft = parse_int(item.get("elevation_ft"))
        elevation_m = feet_to_meters(elevation_ft) if elevation_ft else None

        # Geographic references
        iso_country = (parse_csv_value(item.get("iso_country")) or "")[:2].upper()
        iso_region = (parse_csv_value(item.get("iso_region")) or "")[:10]
        continent = (parse_csv_value(item.get("continent")) or "")[:2]

        country = self.country_index.get(iso_country)
        region = self.region_index.get(iso_region)

        # Codes
        gps_code = clean_icao_code(item.get("gps_code"))
        iata_code = clean_iata_code(item.get("iata_code"))
        local_code = (parse_csv_value(item.get("local_code")) or "")[:10]

        # Slug
        slug = slugify(name)
        if iata_code:
            slug = f"{slug}-{iata_code.lower()}" if slug else iata_code.lower()
        elif ident:
            slug = f"{slug}-{ident.lower()}" if slug else ident.lower()

        return {
            "ourairports_id": ourairports_id,
            "ident": ident[:10],
            "airport_type": airport_type[:20],
            "name": name[:200],
            "slug": slug[:200],
            "location": location,
            "latitude": latitude,
            "longitude": longitude,
            "elevation_ft": elevation_ft,
            "elevation_m": elevation_m,
            "continent": continent,
            "country": country,
            "iso_country": iso_country,
            "region": region,
            "iso_region": iso_region,
            "municipality": (parse_csv_value(item.get("municipality")) or "")[:100],
            "scheduled_service": parse_bool(item.get("scheduled_service")),
            "gps_code": gps_code,
            "iata_code": iata_code,
            "local_code": local_code,
            "home_link": (parse_csv_value(item.get("home_link")) or "")[:500],
            "wikipedia_link": (parse_csv_value(item.get("wikipedia_link")) or "")[:500],
            "keywords": parse_csv_value(item.get("keywords")) or "",
        }

    @transaction.atomic
    def create_or_update(self, parsed: dict) -> Tuple[Airport, bool]:
        ourairports_id = parsed.pop("ourairports_id")
        location = parsed.pop("location", None)

        if ourairports_id not in self.existing_ids:
            obj = Airport(ourairports_id=ourairports_id, **parsed)
            if location:
                obj.location = location
            obj.save()
            self.existing_ids.add(ourairports_id)
            return obj, True
        else:
            obj, created = Airport.objects.update_or_create(
                ourairports_id=ourairports_id,
                defaults=parsed,
            )
            if location:
                obj.location = location
                obj.save(update_fields=["location"])
            return obj, created
