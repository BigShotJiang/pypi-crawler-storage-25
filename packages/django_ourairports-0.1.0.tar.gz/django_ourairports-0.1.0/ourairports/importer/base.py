"""
Base importer class for OurAirports data.
"""

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Tuple

from django.db import models
from tqdm import tqdm

from ..conf import LOGGER_NAME, get_ourairports_settings
from ..exceptions import HookException, ValidationError
from ..services import CSVParser, Downloader

logger = logging.getLogger(LOGGER_NAME)


class BaseImporter(ABC):
    """Abstract base class for OurAirports data importers."""

    data_type: str = None

    def __init__(self, command, options: dict):
        self.command = command
        self.options = options
        self.settings = get_ourairports_settings()

        self.force = options.get("force", False)
        self.quiet = options.get("quiet", False)
        self.dry_run = options.get("dry_run", False)

        self.downloader = Downloader(
            data_dir=self.settings.data_dir,
            force=self.force,
            quiet=self.quiet,
        )

        self.stats = {
            "processed": 0,
            "created": 0,
            "updated": 0,
            "skipped": 0,
            "errors": 0,
        }

        self.plugins = self._load_plugins()

    def _load_plugins(self) -> list:
        plugins = []
        for plugin_path in self.settings.plugins:
            try:
                module_path, class_name = plugin_path.rsplit(".", 1)
                module = __import__(module_path, fromlist=[class_name])
                plugin_class = getattr(module, class_name)
                plugins.append(plugin_class())
            except Exception as e:
                logger.warning("Failed to load plugin %s: %s", plugin_path, e)
        return plugins

    def run(self) -> dict:
        """Execute import workflow."""
        logger.info("Starting %s import", self.get_description())

        try:
            file_path = self.downloader.download(self.data_type)
            self.build_indices()
            self._import_from_file(file_path)
            self.cleanup()
        except Exception as e:
            logger.error("Import failed: %s", e, exc_info=True)
            raise

        logger.info(
            "Complete: %d processed, %d created, %d updated, %d skipped, %d errors",
            self.stats["processed"],
            self.stats["created"],
            self.stats["updated"],
            self.stats["skipped"],
            self.stats["errors"],
        )

        return self.stats

    def _import_from_file(self, file_path: Path) -> None:
        parser = CSVParser(file_path, self.data_type, quiet=self.quiet)
        total = parser.count_records()

        with tqdm(total=total, desc=self.get_description(), disable=self.quiet) as pbar:
            for item in parser.iter_records():
                self._process_item(item)
                pbar.update(1)

    def _process_item(self, item: dict) -> None:
        self.stats["processed"] += 1

        try:
            if not self._call_hook("pre", item):
                self.stats["skipped"] += 1
                return

            parsed = self.parse_item(item)
            if parsed is None:
                self.stats["skipped"] += 1
                return

            if self.dry_run:
                return

            obj, created = self.create_or_update(parsed)

            if created:
                self.stats["created"] += 1
            else:
                self.stats["updated"] += 1

            self._call_hook("post", obj, item)

        except ValidationError as e:
            logger.debug("Validation error: %s", e)
            self.stats["skipped"] += 1
        except Exception as e:
            logger.error("Error: %s", e, exc_info=True)
            self.stats["errors"] += 1

    def _call_hook(self, hook_type: str, *args) -> bool:
        hook_name = f"{self.get_hook_prefix()}_{hook_type}"
        for plugin in self.plugins:
            hook = getattr(plugin, hook_name, None)
            if hook:
                try:
                    hook(self.command, *args)
                except HookException:
                    return False
        return True

    def build_indices(self) -> None:
        pass

    def cleanup(self) -> None:
        pass

    def get_description(self) -> str:
        model = self.get_model_class()
        return f"Importing {model._meta.verbose_name_plural}"

    def get_hook_prefix(self) -> str:
        model = self.get_model_class()
        return model._meta.model_name

    @abstractmethod
    def get_model_class(self) -> type:
        pass

    @abstractmethod
    def parse_item(self, item: dict) -> Optional[dict]:
        pass

    @abstractmethod
    def create_or_update(self, parsed: dict) -> Tuple[models.Model, bool]:
        pass
