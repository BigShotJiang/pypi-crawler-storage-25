"""Runway importer for OurAirports data."""

import logging
from typing import Optional, Tuple

from django.contrib.gis.geos import Point
from django.db import transaction

from ..conf import LOGGER_NAME, get_ourairports_settings
from ..models import Airport, Runway
from ..util import parse_bool, parse_csv_value, parse_float, parse_int
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class RunwayImporter(BaseImporter):
    """Importer for runways."""

    data_type = "runways"

    def __init__(self, command, options: dict):
        super().__init__(command, options)
        self.existing_ids = set()
        self.airport_index = {}

    def get_model_class(self) -> type:
        return Runway

    def build_indices(self) -> None:
        self.existing_ids = set(
            Runway.objects.values_list("ourairports_id", flat=True)
        )
        self.airport_index = {
            a.ident: a for a in Airport.objects.only("id", "ident")
        }

    def parse_item(self, item: dict) -> Optional[dict]:
        settings = get_ourairports_settings()

        ourairports_id = parse_int(item.get("id"))
        if not ourairports_id:
            return None

        airport_ident = (parse_csv_value(item.get("airport_ident")) or "")[:10]
        airport = self.airport_index.get(airport_ident)

        # LE (low-end) coordinates
        le_lat = parse_float(item.get("le_latitude_deg"))
        le_lon = parse_float(item.get("le_longitude_deg"))
        le_location = None
        if settings.import_geometry and le_lat and le_lon:
            if -90 <= le_lat <= 90 and -180 <= le_lon <= 180:
                le_location = Point(le_lon, le_lat, srid=4326)

        # HE (high-end) coordinates
        he_lat = parse_float(item.get("he_latitude_deg"))
        he_lon = parse_float(item.get("he_longitude_deg"))
        he_location = None
        if settings.import_geometry and he_lat and he_lon:
            if -90 <= he_lat <= 90 and -180 <= he_lon <= 180:
                he_location = Point(he_lon, he_lat, srid=4326)

        return {
            "ourairports_id": ourairports_id,
            "airport": airport,
            "airport_ident": airport_ident,
            "length_ft": parse_int(item.get("length_ft")),
            "width_ft": parse_int(item.get("width_ft")),
            "surface": (parse_csv_value(item.get("surface")) or "")[:50],
            "lighted": parse_bool(item.get("lighted")),
            "closed": parse_bool(item.get("closed")),
            "le_ident": (parse_csv_value(item.get("le_ident")) or "")[:10],
            "le_location": le_location,
            "le_latitude": le_lat,
            "le_longitude": le_lon,
            "le_elevation_ft": parse_int(item.get("le_elevation_ft")),
            "le_heading": parse_float(item.get("le_heading_degT")),
            "le_displaced_threshold_ft": parse_int(item.get("le_displaced_threshold_ft")),
            "he_ident": (parse_csv_value(item.get("he_ident")) or "")[:10],
            "he_location": he_location,
            "he_latitude": he_lat,
            "he_longitude": he_lon,
            "he_elevation_ft": parse_int(item.get("he_elevation_ft")),
            "he_heading": parse_float(item.get("he_heading_degT")),
            "he_displaced_threshold_ft": parse_int(item.get("he_displaced_threshold_ft")),
        }

    @transaction.atomic
    def create_or_update(self, parsed: dict) -> Tuple[Runway, bool]:
        ourairports_id = parsed.pop("ourairports_id")
        le_location = parsed.pop("le_location", None)
        he_location = parsed.pop("he_location", None)

        if ourairports_id not in self.existing_ids:
            obj = Runway(ourairports_id=ourairports_id, **parsed)
            if le_location:
                obj.le_location = le_location
            if he_location:
                obj.he_location = he_location
            obj.save()
            self.existing_ids.add(ourairports_id)
            return obj, True
        else:
            obj, created = Runway.objects.update_or_create(
                ourairports_id=ourairports_id,
                defaults=parsed,
            )
            if le_location or he_location:
                if le_location:
                    obj.le_location = le_location
                if he_location:
                    obj.he_location = he_location
                obj.save(update_fields=["le_location", "he_location"])
            return obj, created
