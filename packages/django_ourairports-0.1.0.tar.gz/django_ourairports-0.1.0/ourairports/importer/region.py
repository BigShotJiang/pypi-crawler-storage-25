"""Region importer for OurAirports data."""

import logging
from typing import Optional, Tuple

from django.db import transaction

from ..conf import LOGGER_NAME
from ..models import Country, Region
from ..util import parse_csv_value, parse_int
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class RegionImporter(BaseImporter):
    """Importer for regions."""

    data_type = "regions"

    def __init__(self, command, options: dict):
        super().__init__(command, options)
        self.existing_ids = set()
        self.country_index = {}

    def get_model_class(self) -> type:
        return Region

    def build_indices(self) -> None:
        self.existing_ids = set(
            Region.objects.values_list("ourairports_id", flat=True)
        )
        self.country_index = {
            c.code: c for c in Country.objects.only("id", "code")
        }

    def parse_item(self, item: dict) -> Optional[dict]:
        ourairports_id = parse_int(item.get("id"))
        if not ourairports_id:
            return None

        code = parse_csv_value(item.get("code"))
        if not code:
            return None

        name = parse_csv_value(item.get("name"))
        if not name:
            return None

        iso_country = (parse_csv_value(item.get("iso_country")) or "")[:2].upper()
        country = self.country_index.get(iso_country)

        return {
            "ourairports_id": ourairports_id,
            "code": code[:10],
            "local_code": (parse_csv_value(item.get("local_code")) or "")[:10],
            "name": name[:100],
            "continent": (parse_csv_value(item.get("continent")) or "")[:2],
            "country": country,
            "iso_country": iso_country,
            "wikipedia_link": (parse_csv_value(item.get("wikipedia_link")) or "")[:500],
            "keywords": parse_csv_value(item.get("keywords")) or "",
        }

    @transaction.atomic
    def create_or_update(self, parsed: dict) -> Tuple[Region, bool]:
        ourairports_id = parsed.pop("ourairports_id")

        if ourairports_id not in self.existing_ids:
            obj = Region.objects.create(ourairports_id=ourairports_id, **parsed)
            self.existing_ids.add(ourairports_id)
            return obj, True
        else:
            obj, created = Region.objects.update_or_create(
                ourairports_id=ourairports_id,
                defaults=parsed,
            )
            return obj, created
