"""Frequency importer for OurAirports data."""

import logging
from decimal import Decimal, InvalidOperation
from typing import Optional, Tuple

from django.db import transaction

from ..conf import LOGGER_NAME
from ..models import Airport, Frequency
from ..util import parse_csv_value, parse_int
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)


class FrequencyImporter(BaseImporter):
    """Importer for airport frequencies."""

    data_type = "frequencies"

    def __init__(self, command, options: dict):
        super().__init__(command, options)
        self.existing_ids = set()
        self.airport_index = {}

    def get_model_class(self) -> type:
        return Frequency

    def build_indices(self) -> None:
        self.existing_ids = set(
            Frequency.objects.values_list("ourairports_id", flat=True)
        )
        self.airport_index = {
            a.ident: a for a in Airport.objects.only("id", "ident")
        }

    def parse_item(self, item: dict) -> Optional[dict]:
        ourairports_id = parse_int(item.get("id"))
        if not ourairports_id:
            return None

        airport_ident = (parse_csv_value(item.get("airport_ident")) or "")[:10]
        airport = self.airport_index.get(airport_ident)

        frequency_str = parse_csv_value(item.get("frequency_mhz"))
        if not frequency_str:
            return None

        try:
            frequency_mhz = Decimal(frequency_str)
        except InvalidOperation:
            return None

        return {
            "ourairports_id": ourairports_id,
            "airport": airport,
            "airport_ident": airport_ident,
            "frequency_type": (parse_csv_value(item.get("type")) or "")[:20],
            "description": (parse_csv_value(item.get("description")) or "")[:200],
            "frequency_mhz": frequency_mhz,
        }

    @transaction.atomic
    def create_or_update(self, parsed: dict) -> Tuple[Frequency, bool]:
        ourairports_id = parsed.pop("ourairports_id")

        if ourairports_id not in self.existing_ids:
            obj = Frequency.objects.create(ourairports_id=ourairports_id, **parsed)
            self.existing_ids.add(ourairports_id)
            return obj, True
        else:
            obj, created = Frequency.objects.update_or_create(
                ourairports_id=ourairports_id,
                defaults=parsed,
            )
            return obj, created
