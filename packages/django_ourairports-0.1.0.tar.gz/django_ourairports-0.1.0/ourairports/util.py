"""Utility functions for OurAirports operations."""

import re
import unicodedata
from typing import Optional

from .conf import FEET_TO_METERS


def slugify(value: str, allow_unicode: bool = False) -> str:
    """
    Convert a string to a URL-friendly slug.

    Args:
        value: String to slugify
        allow_unicode: If True, allow unicode characters

    Returns:
        Slugified string
    """
    if allow_unicode:
        value = unicodedata.normalize("NFKC", value)
    else:
        value = unicodedata.normalize("NFKD", value)
        value = value.encode("ascii", "ignore").decode("ascii")

    value = re.sub(r"[^\w\s-]", "", value.lower())
    return re.sub(r"[-\s]+", "-", value).strip("-_")


def parse_csv_value(value: str) -> Optional[str]:
    """
    Parse a CSV value, handling empty strings.

    Args:
        value: Raw value from CSV

    Returns:
        Cleaned value or None
    """
    if value is None:
        return None
    value = str(value).strip()
    if value in ("", "NULL", "null"):
        return None
    return value


def parse_int(value, default: Optional[int] = None) -> Optional[int]:
    """
    Parse an integer value.

    Args:
        value: Value to parse
        default: Default if parsing fails

    Returns:
        Parsed integer or default
    """
    cleaned = parse_csv_value(value)
    if cleaned is None:
        return default
    try:
        return int(float(cleaned))  # Handle "123.0" format
    except (ValueError, TypeError):
        return default


def parse_float(value, default: Optional[float] = None) -> Optional[float]:
    """
    Parse a float value.

    Args:
        value: Value to parse
        default: Default if parsing fails

    Returns:
        Parsed float or default
    """
    cleaned = parse_csv_value(value)
    if cleaned is None:
        return default
    try:
        return float(cleaned)
    except (ValueError, TypeError):
        return default


def parse_bool(value, default: bool = False) -> bool:
    """
    Parse a boolean value.

    OurAirports uses "yes"/"no" and 1/0 for booleans.

    Args:
        value: Value to parse
        default: Default if parsing fails

    Returns:
        Parsed boolean
    """
    cleaned = parse_csv_value(value)
    if cleaned is None:
        return default
    cleaned = str(cleaned).lower()
    return cleaned in ("yes", "true", "1", "t", "y")


def feet_to_meters(feet: float) -> float:
    """
    Convert feet to meters.

    Args:
        feet: Value in feet

    Returns:
        Value in meters
    """
    return feet * FEET_TO_METERS


def clean_ident(ident: str) -> str:
    """
    Clean and validate an airport/navaid identifier.

    Args:
        ident: Raw identifier

    Returns:
        Cleaned identifier or empty string
    """
    cleaned = parse_csv_value(ident)
    if not cleaned:
        return ""
    return cleaned.upper().strip()


def clean_iata_code(code: str) -> str:
    """
    Clean and validate IATA code.

    Args:
        code: Raw IATA code

    Returns:
        Cleaned 3-letter code or empty string
    """
    cleaned = parse_csv_value(code)
    if not cleaned:
        return ""
    cleaned = cleaned.upper().strip()
    if len(cleaned) != 3:
        return ""
    if not cleaned.isalpha():
        return ""
    return cleaned


def clean_icao_code(code: str) -> str:
    """
    Clean and validate ICAO/GPS code.

    Args:
        code: Raw ICAO code

    Returns:
        Cleaned 4-letter code or empty string
    """
    cleaned = parse_csv_value(code)
    if not cleaned:
        return ""
    cleaned = cleaned.upper().strip()
    if len(cleaned) != 4:
        return ""
    if not cleaned.isalnum():
        return ""
    return cleaned


def parse_keywords(keywords: str) -> list:
    """
    Parse keywords string into a list.

    Keywords are comma-separated.

    Args:
        keywords: Raw keywords string

    Returns:
        List of keyword strings
    """
    cleaned = parse_csv_value(keywords)
    if not cleaned:
        return []
    return [k.strip() for k in cleaned.split(",") if k.strip()]


def normalize_surface(surface: str) -> str:
    """
    Normalize runway surface type.

    Args:
        surface: Raw surface string

    Returns:
        Normalized surface type
    """
    cleaned = parse_csv_value(surface)
    if not cleaned:
        return ""
    return cleaned.upper().strip()
