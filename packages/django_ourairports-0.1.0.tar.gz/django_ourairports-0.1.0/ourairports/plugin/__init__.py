"""
Plugin system for OurAirports import customization.

Available Hooks:
    country_pre, country_post
    region_pre, region_post
    airport_pre, airport_post
    runway_pre, runway_post
    frequency_pre, frequency_post
    navaid_pre, navaid_post
"""

from ..exceptions import HookException

__all__ = ["HookException"]
