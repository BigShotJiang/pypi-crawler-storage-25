"""
CSV parser service for OurAirports data files.
"""

import csv
import logging
from pathlib import Path
from typing import Generator, List

from ..conf import (
    AIRPORT_FIELDS,
    COUNTRY_FIELDS,
    FREQUENCY_FIELDS,
    LOGGER_NAME,
    NAVAID_FIELDS,
    REGION_FIELDS,
    RUNWAY_FIELDS,
)
from ..exceptions import ParseError
from ..util import parse_csv_value

logger = logging.getLogger(LOGGER_NAME)


class CSVParser:
    """Parser for OurAirports CSV data files."""

    FIELD_DEFS = {
        "airports": AIRPORT_FIELDS,
        "runways": RUNWAY_FIELDS,
        "frequencies": FREQUENCY_FIELDS,
        "navaids": NAVAID_FIELDS,
        "countries": COUNTRY_FIELDS,
        "regions": REGION_FIELDS,
    }

    def __init__(self, file_path: Path, data_type: str, quiet: bool = False):
        self.file_path = Path(file_path)
        self.data_type = data_type
        self.quiet = quiet

        if not self.file_path.exists():
            raise ParseError(f"File not found: {file_path}")

        self.fields = self.FIELD_DEFS.get(data_type)
        if not self.fields:
            raise ParseError(f"Unknown data type: {data_type}")

    def count_records(self) -> int:
        """Count records in file."""
        with open(self.file_path, "r", encoding="utf-8", errors="replace") as f:
            return sum(1 for _ in f) - 1  # Subtract header row

    def iter_records(self) -> Generator[dict, None, None]:
        """Iterate over records."""
        with open(self.file_path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.DictReader(f)

            for row_num, row in enumerate(reader, 2):
                try:
                    record = self._parse_row(row)
                    if record:
                        yield record
                except Exception as e:
                    logger.warning("Error parsing row %d: %s", row_num, e)

    def _parse_row(self, row: dict) -> dict:
        """Parse a CSV row."""
        record = {}
        for field in self.fields:
            value = row.get(field, "")
            record[field] = parse_csv_value(value)
        return record
