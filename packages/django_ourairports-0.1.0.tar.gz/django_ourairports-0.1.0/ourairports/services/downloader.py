"""
File download service for OurAirports data.
"""

import logging
from pathlib import Path

import requests
from tqdm import tqdm

from ..conf import DATA_URLS, LOGGER_NAME, get_ourairports_settings
from ..exceptions import DownloadError

logger = logging.getLogger(LOGGER_NAME)


class Downloader:
    """Service for downloading OurAirports data files."""

    def __init__(self, data_dir: str = None, force: bool = False, quiet: bool = False):
        settings = get_ourairports_settings()
        self.data_dir = Path(data_dir or settings.data_dir)
        self.force = force
        self.quiet = quiet
        self.timeout = settings.download_timeout
        self.max_size = settings.max_download_size

        self.data_dir.mkdir(parents=True, exist_ok=True)

    def get_file_path(self, data_type: str) -> Path:
        """Get local path for a data file."""
        filenames = {
            "airports": "airports.csv",
            "runways": "runways.csv",
            "frequencies": "airport-frequencies.csv",
            "navaids": "navaids.csv",
            "countries": "countries.csv",
            "regions": "regions.csv",
        }
        return self.data_dir / filenames.get(data_type, f"{data_type}.csv")

    def download(self, data_type: str) -> Path:
        """Download a data file."""
        file_path = self.get_file_path(data_type)

        if file_path.exists() and not self.force:
            logger.info("Using cached file: %s", file_path)
            return file_path

        url = DATA_URLS.get(data_type)
        if not url:
            raise DownloadError(f"Unknown data type: {data_type}")

        logger.info("Downloading %s data...", data_type)
        self._download_file(url, file_path)
        return file_path

    def _download_file(self, url: str, dest: Path) -> None:
        """Download file with progress."""
        try:
            response = requests.get(
                url,
                stream=True,
                timeout=self.timeout,
                headers={"User-Agent": "django-ourairports/0.1"},
            )
            response.raise_for_status()

            total_size = int(response.headers.get("content-length", 0))

            with open(dest, "wb") as f:
                with tqdm(
                    total=total_size,
                    unit="B",
                    unit_scale=True,
                    desc=dest.name,
                    disable=self.quiet,
                ) as pbar:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            pbar.update(len(chunk))

            logger.info("Downloaded: %s", dest)

        except requests.RequestException as e:
            if dest.exists():
                dest.unlink()
            raise DownloadError(f"Failed to download {url}: {e}") from e

    def download_all(self) -> dict:
        """Download all data files."""
        paths = {}
        for data_type in DATA_URLS:
            try:
                paths[data_type] = self.download(data_type)
            except DownloadError as e:
                logger.error("Failed to download %s: %s", data_type, e)
        return paths

    def list_cached(self) -> list:
        """List cached files."""
        cached = []
        for data_type in DATA_URLS:
            path = self.get_file_path(data_type)
            if path.exists():
                cached.append((data_type, path))
        return cached

    def clear_cache(self, data_type: str = None) -> None:
        """Clear cached files."""
        if data_type:
            path = self.get_file_path(data_type)
            if path.exists():
                path.unlink()
        else:
            for dt in DATA_URLS:
                path = self.get_file_path(dt)
                if path.exists():
                    path.unlink()
