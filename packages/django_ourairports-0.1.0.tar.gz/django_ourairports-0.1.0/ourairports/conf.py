"""
Configuration for OurAirports data import.

Settings can be overridden in Django settings using the OURAIRPORTS_ prefix.
"""

import os
from dataclasses import dataclass, field
from typing import Optional

from django.conf import settings as django_settings

# Logger name for all OurAirports operations
LOGGER_NAME = "ourairports"

# OurAirports data URLs (GitHub hosted)
DATA_URLS = {
    "airports": "https://davidmegginson.github.io/ourairports-data/airports.csv",
    "runways": "https://davidmegginson.github.io/ourairports-data/runways.csv",
    "frequencies": "https://davidmegginson.github.io/ourairports-data/airport-frequencies.csv",
    "navaids": "https://davidmegginson.github.io/ourairports-data/navaids.csv",
    "countries": "https://davidmegginson.github.io/ourairports-data/countries.csv",
    "regions": "https://davidmegginson.github.io/ourairports-data/regions.csv",
}

# Field definitions for CSV parsing
AIRPORT_FIELDS = [
    "id",
    "ident",
    "type",
    "name",
    "latitude_deg",
    "longitude_deg",
    "elevation_ft",
    "continent",
    "iso_country",
    "iso_region",
    "municipality",
    "scheduled_service",
    "gps_code",
    "iata_code",
    "local_code",
    "home_link",
    "wikipedia_link",
    "keywords",
]

RUNWAY_FIELDS = [
    "id",
    "airport_ref",
    "airport_ident",
    "length_ft",
    "width_ft",
    "surface",
    "lighted",
    "closed",
    "le_ident",
    "le_latitude_deg",
    "le_longitude_deg",
    "le_elevation_ft",
    "le_heading_degT",
    "le_displaced_threshold_ft",
    "he_ident",
    "he_latitude_deg",
    "he_longitude_deg",
    "he_elevation_ft",
    "he_heading_degT",
    "he_displaced_threshold_ft",
]

FREQUENCY_FIELDS = [
    "id",
    "airport_ref",
    "airport_ident",
    "type",
    "description",
    "frequency_mhz",
]

NAVAID_FIELDS = [
    "id",
    "filename",
    "ident",
    "name",
    "type",
    "frequency_khz",
    "latitude_deg",
    "longitude_deg",
    "elevation_ft",
    "iso_country",
    "dme_frequency_khz",
    "dme_channel",
    "dme_latitude_deg",
    "dme_longitude_deg",
    "dme_elevation_ft",
    "slaved_variation_deg",
    "magnetic_variation_deg",
    "usageType",
    "power",
    "associated_airport",
]

COUNTRY_FIELDS = [
    "id",
    "code",
    "name",
    "continent",
    "wikipedia_link",
    "keywords",
]

REGION_FIELDS = [
    "id",
    "code",
    "local_code",
    "name",
    "continent",
    "iso_country",
    "wikipedia_link",
    "keywords",
]

# Airport types from OurAirports
AIRPORT_TYPES = [
    "balloonport",
    "closed",
    "heliport",
    "large_airport",
    "medium_airport",
    "seaplane_base",
    "small_airport",
]

# Navaid types
NAVAID_TYPES = [
    "DME",
    "NDB",
    "NDB-DME",
    "TACAN",
    "VOR",
    "VOR-DME",
    "VORTAC",
]

# Frequency types
FREQUENCY_TYPES = [
    "APP",      # Approach
    "ARR",      # Arrival
    "ATIS",     # Automatic Terminal Information Service
    "AWO",      # Automatic Weather Observation
    "AWOS",     # Automated Weather Observing System
    "CLD",      # Clearance Delivery
    "CTAF",     # Common Traffic Advisory Frequency
    "DEP",      # Departure
    "FSS",      # Flight Service Station
    "GND",      # Ground
    "INFO",     # Information
    "MISC",     # Miscellaneous
    "OPS",      # Operations
    "RDO",      # Radio
    "RMP",      # Ramp
    "SFA",      # Surface Movement
    "TRSA",     # Terminal Radar Service Area
    "TWR",      # Tower
    "UNIC",     # Unicom
]

# Continent codes
CONTINENTS = {
    "AF": "Africa",
    "AN": "Antarctica",
    "AS": "Asia",
    "EU": "Europe",
    "NA": "North America",
    "OC": "Oceania",
    "SA": "South America",
}

# Import options
IMPORT_OPTS = ["all", "airport", "runway", "frequency", "navaid", "country", "region"]
IMPORT_OPTS_ALL = ["country", "region", "airport", "runway", "frequency", "navaid"]

# Flush options
FLUSH_OPTS = ["all", "airport", "runway", "frequency", "navaid", "country", "region"]
FLUSH_OPTS_ALL = ["airport", "runway", "frequency", "navaid", "country", "region"]

# Feet to meters conversion
FEET_TO_METERS = 0.3048


@dataclass
class OurAirportsSettings:
    """Configuration settings for OurAirports import operations."""

    # Directory for downloaded data
    data_dir: str = ""

    # What to import by default
    import_airports: bool = True
    import_runways: bool = True
    import_frequencies: bool = True
    import_navaids: bool = True
    import_countries: bool = True
    import_regions: bool = True

    # Whether to import geometry
    import_geometry: bool = True

    # HTTP download timeout in seconds
    download_timeout: int = 120

    # Maximum download size in bytes (default 50MB)
    max_download_size: int = 50 * 1024 * 1024

    # Batch size for bulk operations
    batch_size: int = 1000

    # Plugin classes to load
    plugins: list = field(default_factory=list)


def get_settings() -> OurAirportsSettings:
    """
    Create settings object from Django settings.

    Reads settings with OURAIRPORTS_ prefix from Django settings.
    """
    # Default data directory
    app_dir = os.path.dirname(os.path.abspath(__file__))
    default_data_dir = os.path.join(app_dir, "data")

    settings_obj = OurAirportsSettings(
        data_dir=getattr(django_settings, "OURAIRPORTS_DATA_DIR", default_data_dir),
        import_airports=getattr(django_settings, "OURAIRPORTS_IMPORT_AIRPORTS", True),
        import_runways=getattr(django_settings, "OURAIRPORTS_IMPORT_RUNWAYS", True),
        import_frequencies=getattr(django_settings, "OURAIRPORTS_IMPORT_FREQUENCIES", True),
        import_navaids=getattr(django_settings, "OURAIRPORTS_IMPORT_NAVAIDS", True),
        import_countries=getattr(django_settings, "OURAIRPORTS_IMPORT_COUNTRIES", True),
        import_regions=getattr(django_settings, "OURAIRPORTS_IMPORT_REGIONS", True),
        import_geometry=getattr(django_settings, "OURAIRPORTS_IMPORT_GEOMETRY", True),
        download_timeout=getattr(django_settings, "OURAIRPORTS_DOWNLOAD_TIMEOUT", 120),
        max_download_size=getattr(
            django_settings, "OURAIRPORTS_MAX_DOWNLOAD_SIZE", 50 * 1024 * 1024
        ),
        batch_size=getattr(django_settings, "OURAIRPORTS_BATCH_SIZE", 1000),
        plugins=getattr(django_settings, "OURAIRPORTS_PLUGINS", []),
    )

    # Ensure data directory exists
    os.makedirs(settings_obj.data_dir, exist_ok=True)

    return settings_obj


# Singleton settings instance
_settings: Optional[OurAirportsSettings] = None


def get_ourairports_settings() -> OurAirportsSettings:
    """Get or create the singleton settings instance."""
    global _settings
    if _settings is None:
        _settings = get_settings()
    return _settings


def reset_settings() -> None:
    """Reset settings (useful for testing)."""
    global _settings
    _settings = None
