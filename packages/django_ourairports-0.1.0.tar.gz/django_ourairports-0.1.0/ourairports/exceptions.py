"""Custom exceptions for OurAirports import operations."""


class OurAirportsException(Exception):
    """Base exception for OurAirports operations."""

    pass


class ValidationError(OurAirportsException):
    """Raised when data validation fails during import."""

    pass


class DownloadError(OurAirportsException):
    """Raised when file download fails."""

    pass


class ParseError(OurAirportsException):
    """Raised when data parsing fails."""

    pass


class HookException(OurAirportsException):
    """Raise in plugin hooks to skip the current item."""

    pass
