"""Django admin for OurAirports models."""

from django.contrib import admin
from django.contrib.gis.admin import GISModelAdmin

from .models import Airport, Country, Frequency, Navaid, Region, Runway


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "continent")
    list_filter = ("continent",)
    search_fields = ("code", "name")
    ordering = ("name",)


@admin.register(Region)
class RegionAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "iso_country", "continent")
    list_filter = ("continent", "iso_country")
    search_fields = ("code", "name")
    raw_id_fields = ("country",)
    ordering = ("name",)


@admin.register(Airport)
class AirportAdmin(GISModelAdmin):
    list_display = (
        "ident", "name", "airport_type", "iata_code", "municipality",
        "iso_country", "scheduled_service",
    )
    list_filter = ("airport_type", "scheduled_service", "iso_country", "continent")
    search_fields = ("ident", "name", "iata_code", "gps_code", "municipality")
    raw_id_fields = ("country", "region")
    readonly_fields = ("created_at", "updated_at")
    ordering = ("name",)


@admin.register(Runway)
class RunwayAdmin(GISModelAdmin):
    list_display = ("airport_ident", "le_ident", "he_ident", "length_ft", "surface", "lighted")
    list_filter = ("lighted", "closed", "surface")
    search_fields = ("airport_ident", "le_ident", "he_ident")
    raw_id_fields = ("airport",)
    ordering = ("airport_ident",)


@admin.register(Frequency)
class FrequencyAdmin(admin.ModelAdmin):
    list_display = ("airport_ident", "frequency_type", "frequency_mhz", "description")
    list_filter = ("frequency_type",)
    search_fields = ("airport_ident", "description")
    raw_id_fields = ("airport",)
    ordering = ("airport_ident",)


@admin.register(Navaid)
class NavaidAdmin(GISModelAdmin):
    list_display = ("ident", "name", "navaid_type", "frequency_khz", "iso_country")
    list_filter = ("navaid_type", "iso_country")
    search_fields = ("ident", "name")
    raw_id_fields = ("country", "associated_airport")
    ordering = ("ident",)
