"""
Management command to download and import OurAirports data.

Usage:
    python manage.py ourairports --import=all
    python manage.py ourairports --import=airport,runway
    python manage.py ourairports --flush=all --import=all
"""

import logging

from django.core.management.base import BaseCommand, CommandError

from ourairports.conf import (
    FLUSH_OPTS,
    FLUSH_OPTS_ALL,
    IMPORT_OPTS,
    IMPORT_OPTS_ALL,
    LOGGER_NAME,
    get_ourairports_settings,
)
from ourairports.importer import (
    AirportImporter,
    CountryImporter,
    FrequencyImporter,
    NavaidImporter,
    RegionImporter,
    RunwayImporter,
)
from ourairports.models import Airport, Country, Frequency, Navaid, Region, Runway
from ourairports.services import Downloader

logger = logging.getLogger(LOGGER_NAME)


class Command(BaseCommand):
    help = "Download and import OurAirports aviation data"

    IMPORTERS = {
        "country": CountryImporter,
        "region": RegionImporter,
        "airport": AirportImporter,
        "runway": RunwayImporter,
        "frequency": FrequencyImporter,
        "navaid": NavaidImporter,
    }

    def add_arguments(self, parser):
        parser.add_argument(
            "--import",
            type=str,
            default="",
            dest="import_type",
            help=f"What to import: {', '.join(IMPORT_OPTS)}",
        )
        parser.add_argument(
            "--flush",
            type=str,
            default="",
            help=f"Delete existing data: {', '.join(FLUSH_OPTS)}",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Force re-download",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress progress",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Parse without saving",
        )
        parser.add_argument(
            "--download-only",
            action="store_true",
            help="Only download files",
        )
        parser.add_argument(
            "--list",
            action="store_true",
            dest="list_cached",
            help="List cached files",
        )
        parser.add_argument(
            "--clear",
            action="store_true",
            help="Clear cache",
        )

    def handle(self, *args, **options):
        settings = get_ourairports_settings()
        downloader = Downloader(
            data_dir=settings.data_dir,
            force=options["force"],
            quiet=options["quiet"],
        )

        if options["list_cached"]:
            self._list_cached(downloader)
            return

        if options["clear"]:
            downloader.clear_cache()
            self.stdout.write("Cleared cache")
            return

        if options["download_only"]:
            downloader.download_all()
            return

        import_type = options["import_type"]
        flush_type = options["flush"]

        if not import_type and not flush_type:
            self.stdout.write(self.style.WARNING("Use --import=all or --help"))
            return

        if flush_type:
            self._handle_flush(flush_type)

        if import_type:
            self._handle_import(import_type, options)

    def _list_cached(self, downloader):
        cached = downloader.list_cached()
        if not cached:
            self.stdout.write("No cached files")
            return
        for dt, path in cached:
            size = path.stat().st_size / 1024
            self.stdout.write(f"  {dt}: {path} ({size:.1f} KB)")

    def _handle_flush(self, flush_type):
        flush_types = [f.strip() for f in flush_type.split(",")]
        if "all" in flush_types:
            targets = FLUSH_OPTS_ALL
        else:
            targets = flush_types

        for target in targets:
            self._flush(target)

    def _flush(self, target):
        self.stdout.write(f"Flushing {target}...")
        models = {
            "country": Country,
            "region": Region,
            "airport": Airport,
            "runway": Runway,
            "frequency": Frequency,
            "navaid": Navaid,
        }
        if target in models:
            count = models[target].objects.all().delete()[0]
            self.stdout.write(f"  Deleted {count}")

    def _handle_import(self, import_type, options):
        import_types = [t.strip() for t in import_type.split(",")]

        if "all" in import_types:
            targets = IMPORT_OPTS_ALL
        else:
            targets = import_types

        total_stats = {"processed": 0, "created": 0, "updated": 0, "skipped": 0, "errors": 0}

        # Import in dependency order
        order = ["country", "region", "airport", "runway", "frequency", "navaid"]
        for target in order:
            if target in targets:
                self._run_importer(target, options, total_stats)

        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("Import complete!"))
        self.stdout.write(f"  Processed: {total_stats['processed']}")
        self.stdout.write(f"  Created:   {total_stats['created']}")
        self.stdout.write(f"  Updated:   {total_stats['updated']}")
        self.stdout.write(f"  Skipped:   {total_stats['skipped']}")

    def _run_importer(self, target, options, total_stats):
        importer_class = self.IMPORTERS.get(target)
        if not importer_class:
            return

        self.stdout.write(f"Importing {target}...")
        try:
            importer = importer_class(self, options)
            stats = importer.run()
            for key in total_stats:
                total_stats[key] += stats.get(key, 0)
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Failed: {e}"))
            raise CommandError(str(e)) from e
