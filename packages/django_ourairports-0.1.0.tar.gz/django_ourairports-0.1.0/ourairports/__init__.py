"""
Django OurAirports - Import and manage OurAirports aviation data.

Provides models for airports, runways, frequencies, navaids, countries, and regions.
Data sourced from OurAirports (https://ourairports.com/data/).

License: MIT
Data License: OurAirports data is released to the public domain.
"""

__version__ = "0.1.0"
__author__ = "Your Name"

default_app_config = "ourairports.apps.OurAirportsConfig"
