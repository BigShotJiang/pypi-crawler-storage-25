from django.apps import AppConfig


class OurAirportsConfig(AppConfig):
    """Django app configuration for OurAirports."""

    name = "ourairports"
    verbose_name = "OurAirports"
    default_auto_field = "django.db.models.BigAutoField"
