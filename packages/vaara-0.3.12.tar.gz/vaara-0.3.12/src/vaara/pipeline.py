"""Interception pipeline — the main entry point for the Vaara execution layer.

Wires the components together:

    ActionRequest → Registry (classify) → Scorer (risk) → Policy (decide)
                                                       → Audit (record)
                                                       → Execute or Block

Usage::

    from vaara.pipeline import InterceptionPipeline

    pipeline = InterceptionPipeline()

    # Agent wants to execute a tool
    result = pipeline.intercept(
        agent_id="agent-007",
        tool_name="tx.transfer",
        parameters={"to": "0x...", "amount": 1000},
        agent_confidence=0.8,
    )

    if result.allowed:
        # Execute the action
        actual_result = execute_tool(tool_name, parameters)
        # Report outcome for learning
        pipeline.report_outcome(result.action_id, outcome_severity=0.0)
    else:
        print(f"Blocked: {result.reason}")
"""

from __future__ import annotations

import logging
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Optional

from vaara._sanitize import json_safe
from vaara.audit.trail import AuditTrail
from vaara.compliance.engine import ComplianceEngine, ConformityReport
from vaara.scorer.adaptive import AdaptiveScorer, Decision
from vaara.taxonomy.actions import (
    ActionRegistry,
    ActionRequest,
    ActionType,
    create_default_registry,
)

logger = logging.getLogger(__name__)

# Cap on pending-outcome records. Callers that never invoke
# report_outcome (crashes, fire-and-forget loops, streaming aborts)
# would otherwise grow the dict unboundedly across a long-running
# agent session. Evicting the oldest entry keeps memory bounded;
# late report_outcome calls after eviction no-op with a warning.
_MAX_PENDING_OUTCOMES = 50_000


def _json_safe_dict(d: Optional[dict]) -> dict:
    if not d:
        return {}
    return {str(k): json_safe(v) for k, v in d.items()}


@dataclass
class InterceptionResult:
    """Result of intercepting an action request."""
    allowed: bool
    action_id: str              # For tracking outcome later
    decision: str               # "allow", "deny", "escalate"
    risk_score: float           # Point estimate
    risk_interval: tuple[float, float]  # Conformal (lower, upper)
    reason: str
    action_type: ActionType
    signals: dict[str, float]   # Contributing risk signals
    evaluation_ms: float


class InterceptionPipeline:
    """Main entry point — intercepts agent actions with risk scoring and audit.

    Thread-safe for read operations.  Write operations (intercept, report_outcome)
    should be serialized per agent_id in concurrent environments.
    """

    def __init__(
        self,
        registry: Optional[ActionRegistry] = None,
        scorer: Optional[AdaptiveScorer] = None,
        trail: Optional[AuditTrail] = None,
        compliance: Optional[ComplianceEngine] = None,
    ) -> None:
        self.registry = registry or create_default_registry()
        self.scorer = scorer or AdaptiveScorer()
        self.trail = trail or AuditTrail()
        self.compliance = compliance or ComplianceEngine()

        # Track action_id → (predicted_risk, signals) for outcome feedback.
        # OrderedDict + bounded FIFO eviction — see _MAX_PENDING_OUTCOMES.
        self._pending_outcomes: OrderedDict[
            str, tuple[float, dict[str, float]]
        ] = OrderedDict()

    def intercept(
        self,
        agent_id: str,
        tool_name: str,
        parameters: Optional[dict] = None,
        context: Optional[dict] = None,
        agent_confidence: Optional[float] = None,
        session_id: str = "",
        parent_action_id: Optional[str] = None,
        sequence_position: int = 0,
    ) -> InterceptionResult:
        """Intercept an agent action request.

        This is the single function that agents/frameworks call.
        It classifies, scores, decides, and audits in one shot.

        Returns an InterceptionResult — check .allowed before executing.
        """
        start = time.monotonic()

        # 1. Classify the action
        action_type = self.registry.classify(tool_name, parameters)

        # Sanitize parameters/context at the boundary so the audit-trail
        # hash chain can be computed with strict JSON. Integrations also
        # sanitize, but direct pipeline users can still pass datetimes,
        # bytes, dataclasses — json_safe keeps those from crashing the
        # audit trail without mutating the hash input downstream.
        safe_params = _json_safe_dict(parameters)
        safe_context = _json_safe_dict(context)

        # 2. Build the request envelope
        request = ActionRequest(
            agent_id=agent_id,
            tool_name=tool_name,
            action_type=action_type,
            parameters=safe_params,
            context=safe_context,
            confidence=agent_confidence,
            session_id=session_id,
            parent_action_id=parent_action_id,
            sequence_position=sequence_position,
            timestamp_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        )

        # 3. Record the request in audit trail
        action_id = self.trail.record_action_requested(request)

        # 4. Score the risk
        policy_context = request.to_policy_context()
        scorer_result = self.scorer.evaluate(policy_context)

        raw = scorer_result.get("raw_result", {})
        point_estimate = raw.get("point_estimate", 0.5)
        interval = raw.get("conformal_interval", [0.2, 0.8])
        signals = raw.get("signals", {})

        # 5. Record risk scoring in audit
        self.trail.record_risk_scored(
            action_id=action_id,
            agent_id=agent_id,
            tool_name=tool_name,
            assessment={
                "point_estimate": point_estimate,
                "conformal_lower": interval[0],
                "conformal_upper": interval[1],
                "signals": signals,
                "calibration_size": raw.get("calibration_size", 0),
            },
            regulatory_domains=action_type.regulatory_domains,
        )

        # 6. Extract decision
        decision_str = scorer_result.get("action", "deny")
        allowed = scorer_result.get("allowed", False)
        reason = scorer_result.get("reason", "")

        # 7. Record the decision in audit
        self.trail.record_decision(
            action_id=action_id,
            agent_id=agent_id,
            tool_name=tool_name,
            decision=decision_str,
            reason=reason,
            risk_score=point_estimate,
            regulatory_domains=action_type.regulatory_domains,
        )

        # 8. If escalated, record escalation
        if decision_str == "escalate":
            self.trail.record_escalation(
                action_id=action_id,
                agent_id=agent_id,
                tool_name=tool_name,
                escalation_target="human_reviewer",
                risk_score=point_estimate,
            )

        # 9. Store for outcome feedback with bounded FIFO eviction
        self._pending_outcomes[action_id] = (point_estimate, signals)
        if len(self._pending_outcomes) > _MAX_PENDING_OUTCOMES:
            self._pending_outcomes.popitem(last=False)

        elapsed_ms = (time.monotonic() - start) * 1000

        logger.info(
            "Intercepted %s/%s: %s (risk=%.3f [%.3f,%.3f], %.1fms)",
            agent_id, tool_name, decision_str,
            point_estimate, interval[0], interval[1], elapsed_ms,
        )

        return InterceptionResult(
            allowed=allowed,
            action_id=action_id,
            decision=decision_str,
            risk_score=point_estimate,
            risk_interval=(interval[0], interval[1]),
            reason=reason,
            action_type=action_type,
            signals=signals,
            evaluation_ms=elapsed_ms,
        )

    def report_outcome(
        self,
        action_id: str,
        outcome_severity: float,
        description: str = "",
    ) -> None:
        """Report the actual outcome of an executed action.

        Call this after action execution with the observed severity.
        0.0 = completely safe, 1.0 = catastrophic.

        This closes the feedback loop:
        - Updates MWU expert weights in the scorer
        - Updates conformal calibration set
        - Records outcome in the audit trail
        """
        pending = self._pending_outcomes.pop(action_id, None)
        if pending is None:
            logger.warning("No pending outcome for action_id=%s", action_id)
            return

        # Clamp severity to [0, 1]. MWU and conformal both assume this
        # range; out-of-range values would corrupt weight updates and
        # calibration residuals. Coerce to float up-front so a caller
        # that passes a string ("high"), bool, or NaN can't raise a
        # TypeError inside the comparison — or silently poison the
        # calibration set with a non-finite outcome.
        import math
        try:
            outcome_severity = float(outcome_severity)
        except (TypeError, ValueError):
            logger.warning(
                "Non-numeric outcome_severity=%r for action_id=%s; "
                "defaulting to 0.0",
                outcome_severity, action_id,
            )
            outcome_severity = 0.0
        if not math.isfinite(outcome_severity):
            logger.warning(
                "Non-finite outcome_severity=%s for action_id=%s; "
                "defaulting to 0.0",
                outcome_severity, action_id,
            )
            outcome_severity = 0.0
        if not (0.0 <= outcome_severity <= 1.0):
            logger.warning(
                "Clamping outcome_severity=%s to [0, 1] for action_id=%s",
                outcome_severity, action_id,
            )
            outcome_severity = max(0.0, min(1.0, outcome_severity))

        predicted_risk, signals = pending

        # Get agent_id and tool_name from the audit trail
        trail = self.trail.get_action_trail(action_id)
        if not trail:
            logger.warning("No audit trail for action_id=%s", action_id)
            return

        agent_id = trail[0].agent_id
        tool_name = trail[0].tool_name

        # Update scorer (MWU + conformal)
        self.scorer.record_outcome(
            agent_id=agent_id,
            tool_name=tool_name,
            predicted_risk=predicted_risk,
            actual_outcome=outcome_severity,
            signals=signals,
        )

        # Record in audit trail
        self.trail.record_outcome(
            action_id=action_id,
            agent_id=agent_id,
            tool_name=tool_name,
            outcome_severity=outcome_severity,
            description=description,
        )

    def resolve_escalation(
        self,
        action_id: str,
        resolution: str,
        reviewer: str,
        justification: str = "",
    ) -> None:
        """Record human resolution of an escalated action.

        Args:
            action_id: The action that was escalated.
            resolution: "allow" or "deny".
            reviewer: Who made the decision.
            justification: Why.
        """
        # Narrow the resolution to the two values downstream compliance
        # queries assume. Unchecked, a typo like "alllow" or a caller
        # who passes an Enum instance (e.g., Decision.ALLOW rather than
        # "allow") would be written to the audit trail verbatim and silently
        # misclassify the outcome during regulatory evidence assembly.
        if not isinstance(resolution, str):
            logger.warning(
                "resolve_escalation: non-string resolution=%r for action_id=%s; coercing via str()",
                resolution, action_id,
            )
            resolution = str(resolution)
        normalized = resolution.strip().lower()
        if normalized not in ("allow", "deny"):
            logger.warning(
                "resolve_escalation: unexpected resolution=%r for action_id=%s; "
                "expected 'allow' or 'deny'. Recording as-is.",
                resolution, action_id,
            )
        else:
            resolution = normalized

        trail = self.trail.get_action_trail(action_id)
        if not trail:
            logger.warning("No audit trail for action_id=%s", action_id)
            return

        agent_id = trail[0].agent_id
        tool_name = trail[0].tool_name

        self.trail.record_escalation_resolved(
            action_id=action_id,
            agent_id=agent_id,
            tool_name=tool_name,
            resolution=resolution,
            reviewer=reviewer,
            justification=justification,
        )

    def run_compliance_assessment(
        self,
        system_name: str = "Vaara Execution Layer",
        system_version: str = "0.1.0",
    ) -> ConformityReport:
        """Run a compliance assessment against the current audit trail."""
        return self.compliance.assess(
            self.trail,
            system_name=system_name,
            system_version=system_version,
        )

    def status(self) -> dict[str, Any]:
        """Dashboard-friendly status snapshot."""
        return {
            "scorer": self.scorer.status(),
            "trail_size": self.trail.size,
            "trail_chain_intact": self.trail.chain_intact,
            "pending_outcomes": len(self._pending_outcomes),
            "registered_action_types": len(self.registry.all_types),
        }
