"""Internal JSON-safe coercion for audit-trail hashing.

Real agent tools routinely pass datetimes, bytes, dataclasses, and
sets as tool arguments. The audit-trail hash requires strict JSON,
so sanitize at the pipeline/integration boundary rather than mutating
the hash input (which would break chain verification).

Recursion is bounded to guard against circular refs.
"""

from __future__ import annotations

from typing import Any


def json_safe(value: Any, _depth: int = 0) -> Any:
    if _depth > 10:
        return f"<truncated depth>{type(value).__name__}</truncated>"
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return f"<bytes len={len(value)}>"
    if isinstance(value, (list, tuple, set, frozenset)):
        return [json_safe(v, _depth + 1) for v in value]
    if isinstance(value, dict):
        return {str(k): json_safe(v, _depth + 1) for k, v in value.items()}
    try:
        return repr(value)
    except Exception:
        return f"<unreprable {type(value).__name__}>"
