# -*- coding: utf-8 -*-
# inscript/analyzer.py  — Phase 3: Semantic Analyzer + Type Checker
#
# Walks the AST and validates:
#   1. All names are declared before use
#   2. Types are compatible in operations
#   3. Return types match function signatures
#   4. Struct fields exist and have correct types
#   5. Break/continue only inside loops
#   6. No duplicate declarations in same scope
#
# On success  → returns a typed symbol table
# On failure  → raises SemanticError with line/col info

from __future__ import annotations
from typing import Dict, List, Optional, Set, Any
from ast_nodes import *
from errors import (
    SemanticError, MultiError, InScriptWarning,
    hint_for_name, levenshtein, did_you_mean
)


# ─────────────────────────────────────────────────────────────────────────────
# TYPE SYSTEM
# Built-in InScript types represented as strings internally.
# ─────────────────────────────────────────────────────────────────────────────

class InScriptType:
    """Represents an InScript type."""
    def __init__(self, name: str, params: list = None):
        self.name   = name
        self.params = params or []   # for generic types like Array<int>

    def __eq__(self, other):
        if not isinstance(other, InScriptType): return False
        return self.name == other.name and self.params == other.params

    def __repr__(self):
        if self.params:
            return f"{self.name}<{', '.join(str(p) for p in self.params)}>"
        return self.name

    def __hash__(self):
        return hash((self.name, tuple(self.params)))


# Singleton built-in types
T_INT    = InScriptType("int")
T_FLOAT  = InScriptType("float")
T_BOOL   = InScriptType("bool")
T_STRING = InScriptType("string")
T_VOID   = InScriptType("void")
T_NULL   = InScriptType("null")
T_ANY    = InScriptType("any")    # escape hatch — disables type checking

# Game-specific built-in types
T_VEC2   = InScriptType("Vec2")
T_VEC3   = InScriptType("Vec3")
T_VEC4   = InScriptType("Vec4")
T_COLOR  = InScriptType("Color")
T_RECT   = InScriptType("Rect")
T_TRANSFORM2D = InScriptType("Transform2D")
T_TRANSFORM3D = InScriptType("Transform3D")
T_TEXTURE = InScriptType("Texture")

T_NEVER  = InScriptType("never")   # v1.8.3: bottom type — function never returns normally
T_PROMISE = InScriptType("Promise") # v1.9.7: async fn return type

BUILTIN_TYPES: Dict[str, InScriptType] = {
    # canonical names
    "int": T_INT, "float": T_FLOAT, "bool": T_BOOL,
    "string": T_STRING, "void": T_VOID, "null": T_NULL, "any": T_ANY,
    "never": T_NEVER,                                   # v1.8.3
    "Promise": T_PROMISE,                               # v1.9.7: async fn return type
    # common aliases
    "str": T_STRING, "boolean": T_BOOL, "number": T_FLOAT,
    "nil": T_NULL, "object": T_ANY, "auto": T_ANY,
    "Integer": T_INT, "Float": T_FLOAT, "String": T_STRING, "Bool": T_BOOL,
    # game types
    "Vec2": T_VEC2, "Vec3": T_VEC3, "Vec4": T_VEC4,
    "Color": T_COLOR, "Rect": T_RECT,
    "Transform2D": T_TRANSFORM2D, "Transform3D": T_TRANSFORM3D,
    "Texture": T_TEXTURE,
    # tuple / array shorthand
    "Tuple": T_ANY, "List": T_ANY, "Dict": T_ANY, "Map": T_ANY,
    # v1.9.1: bare 'array' without element type (deprecated — use [T] in v2.0.0)
    "array": InScriptType("Array", [T_ANY]),
}

def array_type(elem: InScriptType) -> InScriptType:
    return InScriptType("Array", [elem])

def dict_type(key: InScriptType, val: InScriptType) -> InScriptType:
    return InScriptType("Dict", [key, val])

def union_type(*members: InScriptType) -> InScriptType:
    """v1.8.1: Create a Union type from two or more member types.
    Flattens nested unions; deduplicates; single-member unions collapse."""
    flat = []
    seen = set()
    for m in members:
        if m.name == "Union":
            for p in m.params:
                if p not in seen:
                    flat.append(p); seen.add(p)
        else:
            if m not in seen:
                flat.append(m); seen.add(m)
    if len(flat) == 1:
        return flat[0]
    return InScriptType("Union", flat)

def optional_type(inner: InScriptType) -> InScriptType:
    """v1.8.1: `T?` is sugar for `T | nil`."""
    return union_type(inner, T_NULL)

def union_members(t: InScriptType) -> list:
    """v1.8.1: Return list of member types (works on non-unions too)."""
    return t.params if t.name == "Union" else [t]

def literal_type(value: str) -> InScriptType:
    """v1.8.2: A string-literal type like `"left"` or `"right"`."""
    return InScriptType("__literal__", [value])   # params[0] is the string value

def fn_type(param_types: list, return_type: InScriptType) -> InScriptType:
    """v1.8.2: A function type `fn(int,string)->bool`."""
    return InScriptType("__fn__", param_types + [return_type])

def is_literal_type(t: InScriptType) -> bool:
    return t.name == "__literal__"

def literal_value(t: InScriptType) -> str:
    return t.params[0] if t.params else ""

def is_numeric(t: InScriptType) -> bool:
    return t in (T_INT, T_FLOAT)

def is_vec(t: InScriptType) -> bool:
    return t.name in ("Vec2", "Vec3", "Vec4")

def numeric_result(a: InScriptType, b: InScriptType) -> InScriptType:
    """int op int → int; anything with float → float"""
    if a == T_FLOAT or b == T_FLOAT: return T_FLOAT
    return T_INT

def types_compatible(expected: InScriptType, got: InScriptType) -> bool:
    """True if `got` can be used where `expected` is required."""
    if expected == T_ANY or got == T_ANY: return True
    if expected == got: return True
    # v1.8.3: `never` is the bottom type — compatible with any expected type
    if got == T_NEVER: return True
    # int can widen to float
    if expected == T_FLOAT and got == T_INT: return True
    # null/nil can be assigned to any nullable or union containing nil
    if got == T_NULL:
        if expected == T_NULL: return True
        if expected.name == "Union" and T_NULL in expected.params: return True
        return False
    # v1.8.1: if expected is a Union, got must be a member (or compatible with one)
    if expected.name == "Union":
        return any(types_compatible(m, got) for m in expected.params)
    # v1.8.1: if got is a Union, every member must be compatible with expected
    if got.name == "Union":
        return all(types_compatible(expected, m) for m in got.params)
    # v1.8.2: string literal type — `"left"` is compatible with string
    if is_literal_type(expected):
        # Expected a specific literal: got must be the same literal
        if is_literal_type(got):
            return literal_value(expected) == literal_value(got)
        # A plain string variable can fill a literal slot (runtime check)
        return got == T_STRING
    if is_literal_type(got):
        # A literal can always fill a plain string slot
        if expected == T_STRING: return True
        # A literal can fill a Union<string, ...> slot
        if expected.name == "Union":
            return any(types_compatible(m, got) for m in expected.params)
        return False
    # v1.8.2: fn types — compatible if same signature, or got is T_ANY/Function (lambda)
    if expected.name == "__fn__":
        if got == T_ANY: return True
        if got.name in ("Function", "__fn__"): return True
        return False
    # Array<X> compatible with Array<any> and vice versa
    if expected.name == "Array" and got.name == "Array": return True
    # Dict<K,V> compatible with Dict<any,any>
    if expected.name == "Dict" and got.name == "Dict": return True
    # User struct type vs any
    return False


# ─────────────────────────────────────────────────────────────────────────────
# SYMBOL  —  one entry in the symbol table
# ─────────────────────────────────────────────────────────────────────────────

class Symbol:
    def __init__(self, name: str, type_: InScriptType,
                 kind: str = "var",       # "var" | "const" | "fn" | "struct" | "scene"
                 is_const: bool = False,
                 fn_node: FunctionDecl = None,
                 struct_node: StructDecl = None,
                 line: int = 0, col: int = 0):
        self.name        = name
        self.type_       = type_
        self.kind        = kind
        self.is_const    = is_const
        self.fn_node     = fn_node       # for functions: the AST node
        self.struct_node = struct_node   # for structs: the AST node
        self.line        = line
        self.col         = col
        self.used        = False         # v1.2.0: unused-variable tracking


# ─────────────────────────────────────────────────────────────────────────────
# SCOPE  —  one level of the scope chain
# ─────────────────────────────────────────────────────────────────────────────

class Scope:
    def __init__(self, parent: Optional["Scope"] = None, kind: str = "block"):
        self.parent:   Optional[Scope]   = parent
        self.kind:     str               = kind      # "global"|"fn"|"block"|"struct"|"scene"
        self.symbols:  Dict[str, Symbol] = {}

    def define(self, sym: Symbol, error_cb) -> None:
        if sym.name in self.symbols:
            existing = self.symbols[sym.name]
            error_cb(
                f"'{sym.name}' is already declared in this scope "
                f"(first declared at line {existing.line})",
                sym.line, sym.col
            )
        self.symbols[sym.name] = sym

    def lookup(self, name: str) -> Optional[Symbol]:
        if name in self.symbols:
            return self.symbols[name]
        if self.parent:
            return self.parent.lookup(name)
        return None

    def lookup_local(self, name: str) -> Optional[Symbol]:
        return self.symbols.get(name)


# ─────────────────────────────────────────────────────────────────────────────
# SEMANTIC ANALYZER
# ─────────────────────────────────────────────────────────────────────────────

class Analyzer(Visitor):
    """
    Walks the AST in two passes:
      Pass 1: Register all top-level struct/scene/fn names (hoisting)
      Pass 2: Full type-checking walk
    """

    def __init__(self, source_lines: List[str] = None,
                 multi_error: bool = True,
                 warn_as_error: bool = False,
                 no_warn: bool = False,
                 no_warn_unused: bool = False,
                 strict: bool = False):
        self._src         = source_lines or []
        self._scope       = Scope(kind="global")
        self._errors:   List[SemanticError]    = []   # collected (multi-error)
        self._warnings: List[InScriptWarning]  = []
        self._multi_error  = multi_error
        self._warn_as_error = warn_as_error
        self._no_warn      = no_warn
        self._no_warn_unused = no_warn_unused
        self._strict       = strict   # v1.9.1: enables extra v2.0.0-readiness errors
        self._dispatch: dict = {}   # v1.3.0: cached dispatch

        # State for context-sensitive checks
        self._current_fn_return_type: Optional[InScriptType] = None
        self._loop_depth:  int  = 0
        self._in_scene:    bool = False
        self._in_match_arm: bool = False
        self._struct_defs: Dict[str, StructDecl] = {}
        self._type_aliases: Dict[str, "InScriptType"] = {}  # v1.8.2
        self._interfaces:   Dict[str, dict] = {}             # v1.8.3: name → {method: (params, ret)}

        # Pre-register built-in global functions
        self._register_builtins()

    def _src_line(self, line: int) -> str:
        return self._src[line - 1] if self._src and 0 < line <= len(self._src) else ""

    def _error(self, msg: str, line: int = 0, col: int = 0,
               candidates: List[str] = None):
        """
        Emit a semantic error.
        In multi-error mode: collect it and continue.
        In single-error mode: raise immediately.
        Automatically appends a 'did you mean?' hint when candidates are provided.
        """
        hint = ""
        if candidates:
            suggestion = did_you_mean(
                # Extract bare name from message like "Undefined name: 'foo'"
                msg.split("'")[1] if "'" in msg else msg,
                candidates
            )
            if suggestion:
                hint = f"Did you mean: '{suggestion}'?"

        err = SemanticError(msg, line, col, self._src_line(line), hint=hint)

        if self._multi_error:
            self._errors.append(err)
            if len(self._errors) >= MultiError.MAX_ERRORS:
                raise MultiError(self._errors)
        else:
            raise err

    def _warn(self, kind: str, msg: str, line: int = 0):
        if self._no_warn:
            return
        w = InScriptWarning(kind, msg, line, self._src_line(line))
        if self._warn_as_error:
            self._error(f"[warning as error] {msg}", line)
        else:
            self._warnings.append(w)

    def _define(self, sym: Symbol):
        # Warn if this name already exists in an outer scope (shadowing)
        if self._scope.parent:
            outer = self._scope.parent.lookup(sym.name)
            if outer and not self._no_warn:
                self._warn(
                    "shadow",
                    f"'{sym.name}' shadows outer declaration from line {outer.line}",
                    sym.line
                )
        self._scope.define(sym, self._error)

    def _lookup(self, name: str, line: int = 0, col: int = 0) -> Symbol:
        sym = self._scope.lookup(name)
        if sym is None:
            # Inside a match arm, unknown names may be ADT field bindings
            # injected at runtime — treat them as any rather than erroring
            if self._in_match_arm:
                return Symbol(name, T_ANY, kind="var")
            # Collect all visible names for "did you mean?"
            candidates = list(self._all_visible_names())
            self._error(f"Undefined name: '{name}'", line, col, candidates)
            return Symbol(name, T_ANY, kind="var")   # dummy to continue analysis
        sym.used = True   # v1.2.0: mark as used
        return sym

    def _all_visible_names(self) -> List[str]:
        """Walk scope chain and return all reachable names."""
        seen = []
        scope = self._scope
        while scope:
            seen.extend(scope.symbols.keys())
            scope = scope.parent
        return seen

    def _resolve_type_ann(self, ann: Optional[TypeAnnotation]) -> InScriptType:
        """Convert a TypeAnnotation AST node into an InScriptType."""
        if ann is None:
            return T_ANY

        if ann.is_array:
            inner = self._resolve_type_ann(ann.generics[0]) if ann.generics else T_ANY
            return array_type(inner)

        if ann.is_dict:
            k = self._resolve_type_ann(ann.key_type) if ann.key_type else T_STRING
            v = self._resolve_type_ann(ann.generics[0]) if ann.generics else T_ANY
            return dict_type(k, v)

        # v1.8.1: `T?` — nullable shorthand
        if ann.is_nullable or ann.name == "Optional":
            inner = self._resolve_type_ann(ann.generics[0]) if ann.generics else T_ANY
            return optional_type(inner)

        # v1.8.1: `A | B | C` — union type
        if ann.name == "Union":
            members = [self._resolve_type_ann(g) for g in ann.generics]
            return union_type(*members)

        # v1.8.2: string literal type — `"left"`
        if ann.name == "__literal__":
            return literal_type(ann.literal_value or "")

        # v1.8.2: fn type — `fn(int) -> bool`
        if ann.name == "__fn__":
            params = [self._resolve_type_ann(p) for p in (ann.fn_params or [])]
            ret    = self._resolve_type_ann(ann.fn_return) if ann.fn_return else T_ANY
            return fn_type(params, ret)

        if ann.name in BUILTIN_TYPES:
            t = BUILTIN_TYPES[ann.name]
            # v1.9.1: bare `array` without element type is a hard error in strict mode
            if ann.name == "array" and not ann.generics and self._strict:
                self._error(
                    "Bare 'array' type without element type is a breaking change in v2.0.0. "
                    "Use '[T]' (e.g. '[int]') or annotate the element type.",
                    ann.line, ann.col
                )
            return t

        # v1.8.2: registered type aliases
        if ann.name in self._type_aliases:
            return self._type_aliases[ann.name]

        # Check user-defined structs
        if ann.name in self._struct_defs:
            return InScriptType(ann.name)

        # Check user-defined enums (registered in global scope with kind='enum')
        enum_sym = self._scope.lookup(ann.name)
        if enum_sym and enum_sym.kind == "enum":
            return InScriptType(ann.name)

        self._error(f"Unknown type: '{ann.name}'", ann.line, ann.col)
        return T_ANY  # multi-error: continue safely

    def _push_scope(self, kind: str = "block") -> Scope:
        self._scope = Scope(parent=self._scope, kind=kind)
        return self._scope

    def _pop_scope(self) -> Scope:
        old = self._scope
        # v1.2.0: warn about unused locals in fn/block scopes
        if (not self._no_warn and not self._no_warn_unused
                and old.kind in ("fn", "block", "match_arm")):
            for sym in old.symbols.values():
                if (sym.kind in ("var", "const")
                        and not sym.used
                        and not sym.name.startswith("_")):
                    self._warn(
                        "unused",
                        f"Variable '{sym.name}' is defined but never used "
                        f"(prefix with '_' to suppress)",
                        sym.line,
                    )
        self._scope = self._scope.parent
        return old

    # ── Built-in registrations ────────────────────────────────────────────────

    def _register_builtins(self):
        """Pre-populate the global scope with built-in functions and constants."""
        builtins = [
            # print / output
            Symbol("print",   T_VOID,   kind="fn"),
            Symbol("println", T_VOID,   kind="fn"),
            # type inspection
            Symbol("typeof",  T_STRING, kind="fn"),
            Symbol("type",    T_STRING, kind="fn"),
            Symbol("is_nil",  T_BOOL,   kind="fn"),
            Symbol("is_null", T_BOOL,   kind="fn"),
            Symbol("isinstance", T_BOOL, kind="fn"),
            # math
            Symbol("sin",     T_FLOAT, kind="fn"),
            Symbol("cos",     T_FLOAT, kind="fn"),
            Symbol("tan",     T_FLOAT, kind="fn"),
            Symbol("sqrt",    T_FLOAT, kind="fn"),
            Symbol("abs",     T_FLOAT, kind="fn"),
            Symbol("floor",   T_INT,   kind="fn"),
            Symbol("ceil",    T_INT,   kind="fn"),
            Symbol("round",   T_INT,   kind="fn"),
            Symbol("clamp",   T_FLOAT, kind="fn"),
            Symbol("lerp",    T_FLOAT, kind="fn"),
            Symbol("min",     T_FLOAT, kind="fn"),
            Symbol("max",     T_FLOAT, kind="fn"),
            Symbol("pow",     T_FLOAT, kind="fn"),
            Symbol("log",     T_FLOAT, kind="fn"),
            Symbol("random",  T_FLOAT, kind="fn"),
            # collections
            Symbol("len",     T_INT,   kind="fn"),
            Symbol("range",   T_ANY,   kind="fn"),
            Symbol("next",    T_ANY,   kind="fn"),
            Symbol("has_key", T_BOOL,  kind="fn"),
            Symbol("keys",    T_ANY,   kind="fn"),
            Symbol("values",  T_ANY,   kind="fn"),
            Symbol("zip",     T_ANY,   kind="fn"),
            Symbol("map",     T_ANY,   kind="fn"),
            Symbol("filter",  T_ANY,   kind="fn"),
            Symbol("reduce",  T_ANY,   kind="fn"),
            Symbol("sorted",  T_ANY,   kind="fn"),
            Symbol("reversed",T_ANY,   kind="fn"),
            Symbol("enumerate",T_ANY,  kind="fn"),
            # Result types
            Symbol("Ok",      T_ANY,   kind="fn"),
            Symbol("Err",     T_ANY,   kind="fn"),
            # type conversions
            Symbol("int",     T_INT,   kind="fn"),
            Symbol("float",   T_FLOAT, kind="fn"),
            Symbol("string",  T_STRING, kind="fn"),
            Symbol("str",     T_STRING, kind="fn"),
            Symbol("bool",    T_BOOL,  kind="fn"),
            # I/O
            Symbol("input_str", T_STRING, kind="fn"),
            Symbol("read_file", T_STRING, kind="fn"),
            Symbol("write_file", T_VOID,  kind="fn"),
            # game built-ins (constructors / namespaces)
            Symbol("Vec2",    T_VEC2,  kind="fn"),
            Symbol("Vec3",    T_VEC3,  kind="fn"),
            Symbol("Vec4",    T_VEC4,  kind="fn"),
            Symbol("Color",   T_COLOR, kind="fn"),
            Symbol("Rect",    T_RECT,  kind="fn"),
            # global objects
            Symbol("input",   T_ANY,   kind="var"),
            Symbol("draw",    T_ANY,   kind="var"),
            Symbol("draw3d",  T_ANY,   kind="var"),
            Symbol("audio",   T_ANY,   kind="var"),
            Symbol("scene",   T_ANY,   kind="var"),
            Symbol("world",   T_ANY,   kind="var"),
            Symbol("network", T_ANY,   kind="var"),
            Symbol("navmesh", T_ANY,   kind="var"),
            Symbol("time",    T_ANY,   kind="var"),
        ]
        for sym in builtins:
            self._scope.symbols[sym.name] = sym

    # ── Main entry point ──────────────────────────────────────────────────────

    def analyze(self, program: Program) -> Dict[str, Symbol]:
        """
        Analyze a full program.
        Returns the global symbol table on success.

        In multi-error mode (default): raises MultiError with ALL errors found.
        In single-error mode: raises SemanticError on first error.
        Warnings are available in self._warnings after the call.
        """
        # Pass 1: hoist top-level names so they can reference each other
        self._hoist_top_level(program)
        # Pass 2: full type-checking walk
        self.visit(program)

        # Flush any collected errors
        if self._errors:
            raise MultiError(self._errors)

        return self._scope.symbols

    def _hoist_top_level(self, program: Program):
        """Register structs, scenes, top-level functions, and type aliases before checking bodies."""
        from ast_nodes import TypeAliasDecl, InterfaceDecl
        # First sub-pass: register type aliases, structs, and interfaces
        for node in program.body:
            if isinstance(node, StructDecl):
                self._struct_defs[node.name] = node
                self._scope.symbols[node.name] = Symbol(
                    node.name, InScriptType(node.name),
                    kind="struct", struct_node=node,
                    line=node.line, col=node.col
                )
            elif isinstance(node, TypeAliasDecl):
                type_ann = getattr(node, 'type_ann', None)
                if type_ann is not None:
                    resolved = self._resolve_type_ann(type_ann)
                else:
                    resolved = BUILTIN_TYPES.get(node.target, InScriptType(node.target))
                self._type_aliases[node.name] = resolved
                self._scope.symbols[node.name] = Symbol(
                    node.name, resolved, kind="type",
                    line=node.line, col=node.col
                )
            elif isinstance(node, InterfaceDecl):
                # v1.8.3: register interface so structs can reference it
                iface_methods = {}
                for m in getattr(node, 'methods', []):
                    ret    = self._resolve_type_ann(getattr(m, 'return_type', None))
                    params = [self._resolve_type_ann(getattr(p, 'type_ann', None))
                              for p in getattr(m, 'params', [])]
                    iface_methods[m.name] = (params, ret)
                self._interfaces[node.name] = iface_methods
                self._scope.symbols[node.name] = Symbol(
                    node.name, T_ANY, kind="interface",
                    line=node.line, col=node.col
                )
        # Second sub-pass: hoist functions, scenes, enums (can now reference aliases)
        for node in program.body:
            if isinstance(node, FunctionDecl):
                ret  = self._resolve_type_ann(node.return_type)
                self._scope.symbols[node.name] = Symbol(
                    node.name, ret, kind="fn", fn_node=node,
                    line=node.line, col=node.col
                )
            elif isinstance(node, SceneDecl):
                self._scope.symbols[node.name] = Symbol(
                    node.name, T_ANY, kind="scene",
                    line=node.line, col=node.col
                )
            elif isinstance(node, EnumDecl):
                self._scope.symbols[node.name] = Symbol(
                    node.name, InScriptType(node.name), kind="enum",
                    fn_node=node,
                    line=node.line, col=node.col
                )

    # ── Visitor methods ───────────────────────────────────────────────────────

    def visit_Program(self, node: Program) -> InScriptType:
        for stmt in node.body:
            self.visit(stmt)
        return T_VOID

    # ── Declarations ──────────────────────────────────────────────────────────

    def visit_VarDecl(self, node: VarDecl) -> InScriptType:
        declared_type = self._resolve_type_ann(node.type_ann)
        init_type     = T_ANY

        if node.initializer:
            init_type = self.visit(node.initializer)
            if declared_type != T_ANY and not types_compatible(declared_type, init_type):
                self._error(
                    f"Type mismatch in declaration of '{node.name}': "
                    f"expected '{declared_type}', got '{init_type}'",
                    node.line, node.col
                )
        # Infer type from initializer if no annotation
        if declared_type == T_ANY and node.initializer:
            # v1.8.2: literal_type("hello") is a string value — store as T_STRING
            declared_type = T_STRING if is_literal_type(init_type) else init_type

        self._define(Symbol(
            node.name, declared_type,
            kind="const" if node.is_const else "var",
            is_const=node.is_const,
            line=node.line, col=node.col
        ))
        return declared_type

    def visit_TupleDestructureDecl(self, node) -> InScriptType:
        """let (a, b) = expr  — register each name as a variable."""
        if hasattr(node, "initializer") and node.initializer:
            self.visit(node.initializer)
        for name in node.names:
            self._define(Symbol(name, T_ANY, kind="var", line=node.line))
        return T_ANY

    def visit_DestructureDecl(self, node) -> InScriptType:
        """let [a, b] = arr  or  let {x, y} = obj — register each name."""
        if hasattr(node, "initializer") and node.initializer:
            self.visit(node.initializer)
        names = getattr(node, "names", []) or getattr(node, "targets", [])
        for name in names:
            if isinstance(name, str):
                self._define(Symbol(name, T_ANY, kind="var", line=node.line))
        return T_ANY

    def visit_FunctionDecl(self, node: FunctionDecl) -> InScriptType:
        ret_type = self._resolve_type_ann(node.return_type)

        # v1.9.7: async fn — external return type is Promise<T>, but the body
        # is checked against the inner type T (what the fn actually returns).
        # E.g.: `async fn f() -> string` → body checked vs `string`, external type = Promise<string>
        is_async = getattr(node, 'is_async', False)
        if is_async:
            inner_ret_type = ret_type if ret_type not in (T_ANY, T_VOID) else T_ANY
            external_ret_type = InScriptType("Promise", [inner_ret_type])
        else:
            inner_ret_type    = ret_type
            external_ret_type = ret_type

        # v1.8.4: return type inference — if no annotation and body has a single
        # unambiguous return type, infer it automatically (use inner type for async)
        if node.return_type is None and inner_ret_type == T_ANY and node.body:
            inferred = self._infer_fn_return_type(node)
            if inferred not in (T_ANY, T_VOID, T_NULL):
                inner_ret_type = inferred
                if is_async:
                    external_ret_type = InScriptType("Promise", [inner_ret_type])
                else:
                    external_ret_type = inner_ret_type
                # Update the hoisted symbol's type to the inferred one
                existing = self._scope.lookup(node.name)
                if existing and existing.kind == "fn":
                    existing.type_ = external_ret_type

        # Register in current scope using external type (Promise<T> for async)
        if not self._scope.lookup_local(node.name):
            self._define(Symbol(
                node.name, external_ret_type, kind="fn",
                fn_node=node, line=node.line, col=node.col
            ))

        # 3.6: warn when a non-private function has no return type annotation
        if node.return_type is None and not node.name.startswith("_"):
            self._warn(
                "missing_return_ann",
                f"Function '{node.name}' has no return type annotation",
                node.line
            )

        # Warn if function declares a non-void return type but body may not return
        if (node.return_type is not None and
                inner_ret_type.name not in ("void", "nil", "any", "") and
                not node.is_native if hasattr(node, 'is_native') else True):
            if node.body and not self._body_always_returns(node.body):
                if inner_ret_type == T_NEVER:
                    # v1.8.3: `-> never` functions MUST always throw / diverge
                    self._error(
                        f"Function '{node.name}' is declared '-> never' "
                        f"but not all code paths throw or diverge",
                        node.line
                    )
                else:
                    self._warn(
                        "missing-return",
                        f"Function '{node.name}' declares return type '{inner_ret_type.name}' "
                        f"but not all code paths return a value",
                        node.line
                    )

        # Analyze body in a new scope — body return type is inner (not Promise<T>)
        self._push_scope("fn")
        prev_ret = self._current_fn_return_type
        self._current_fn_return_type = inner_ret_type

        # Register parameters — mark used=True so we never warn about unused params
        for param in node.params:
            p_type = self._resolve_type_ann(param.type_ann)
            sym = Symbol(
                param.name, p_type, kind="var",
                line=param.line, col=param.col
            )
            sym.used = True   # params are always "used" by the caller
            self._define(sym)

        # Analyze body
        self.visit(node.body)

        self._current_fn_return_type = prev_ret
        self._pop_scope()
        return external_ret_type

    def _body_always_returns(self, block) -> bool:
        """Return True if every code path through block ends with a return/throw."""
        from ast_nodes import (ReturnStmt, ThrowStmt, BlockStmt, IfStmt,
                               WhileStmt, ForInStmt, MatchStmt)
        stmts = getattr(block, 'body', [])
        for stmt in reversed(stmts):
            if isinstance(stmt, (ReturnStmt, ThrowStmt)):
                return True
            if isinstance(stmt, IfStmt):
                if (stmt.else_branch and
                        self._body_always_returns(stmt.then_branch) and
                        self._body_always_returns(stmt.else_branch)):
                    return True
            if isinstance(stmt, MatchStmt):
                # If there's a wildcard arm and all arms return, it's exhaustive
                has_wildcard = any(arm.pattern is None for arm in stmt.arms)
                if has_wildcard and all(self._body_always_returns(arm.body) for arm in stmt.arms):
                    return True
        return False

    def visit_StructDecl(self, node: StructDecl) -> InScriptType:
        struct_type = InScriptType(node.name)
        self._push_scope("struct")

        # Register self
        self._define(Symbol("self", struct_type, kind="var", line=node.line))

        # Register fields
        for field in node.fields:
            f_type = self._resolve_type_ann(field.type_ann)
            self._define(Symbol(
                field.name, f_type, kind="var",
                line=field.line, col=field.col
            ))
            if field.default:
                default_type = self.visit(field.default)
                if not types_compatible(f_type, default_type):
                    self._error(
                        f"Struct field '{field.name}' default type mismatch: "
                        f"expected '{f_type}', got '{default_type}'",
                        field.line, field.col
                    )

        # Analyze methods
        for method in node.methods:
            self.visit_FunctionDecl(method)

        # v1.8.3: interface enforcement — check every declared interface is satisfied
        struct_method_names = {m.name for m in node.methods}
        # Also include methods from static_methods
        struct_method_names |= {m.name for m in (node.static_methods or [])}
        for iface_name in (node.interfaces or []):
            required = self._interfaces.get(iface_name)
            if required is None:
                self._error(
                    f"Struct '{node.name}' implements unknown interface '{iface_name}'",
                    node.line
                )
                continue
            missing_methods = sorted(required.keys() - struct_method_names)
            if missing_methods:
                self._error(
                    f"Struct '{node.name}' implements '{iface_name}' "
                    f"but is missing method(s): {missing_methods}",
                    node.line
                )

        self._pop_scope()
        return struct_type

    def visit_SceneDecl(self, node: SceneDecl) -> InScriptType:
        self._push_scope("scene")
        self._in_scene = True

        # Register scene-level vars
        for var in node.vars:
            self.visit_VarDecl(var)

        # Analyze lifecycle hooks
        for hook in node.hooks:
            self._push_scope("fn")
            prev_ret = self._current_fn_return_type
            self._current_fn_return_type = T_VOID

            for param in hook.params:
                p_type = self._resolve_type_ann(param.type_ann)
                self._define(Symbol(param.name, p_type, "var",
                                    line=param.line, col=param.col))

            self.visit(hook.body)
            self._current_fn_return_type = prev_ret
            self._pop_scope()

        # Analyze scene methods
        for method in node.methods:
            self.visit_FunctionDecl(method)

        self._in_scene = False
        self._pop_scope()
        return T_VOID

    def visit_EnumDecl(self, node: EnumDecl) -> InScriptType:
        enum_type = InScriptType(node.name)
        for variant in node.variants:
            # Register each variant as a constant in the global scope
            self._scope.symbols[f"{node.name}::{variant.name}"] = Symbol(
                f"{node.name}::{variant.name}", enum_type, kind="const",
                line=variant.line, col=variant.col
            )
        return enum_type

    def visit_InterfaceDecl(self, node) -> InScriptType:
        """v1.8.3: Register interface method signatures for implementation checking."""
        iface_methods = {}
        for m in getattr(node, 'methods', []):
            ret  = self._resolve_type_ann(getattr(m, 'return_type', None))
            params = [self._resolve_type_ann(getattr(p, 'type_ann', None))
                      for p in getattr(m, 'params', [])]
            iface_methods[m.name] = (params, ret)
        self._interfaces[node.name] = iface_methods
        self._scope.symbols[node.name] = Symbol(
            node.name, T_ANY, kind="interface",
            line=node.line, col=node.col
        )
        return T_VOID

    def visit_TypeAliasDecl(self, node) -> InScriptType:
        """v1.8.2: Register a type alias so annotations can reference it by name."""
        if hasattr(node, 'type_ann') and node.type_ann is not None:
            resolved = self._resolve_type_ann(node.type_ann)
        else:
            # Legacy alias with only a target string
            resolved = BUILTIN_TYPES.get(node.target, InScriptType(node.target))
        self._type_aliases[node.name] = resolved
        # Also register in scope so the name is "used" and not flagged undefined
        self._scope.symbols[node.name] = Symbol(node.name, resolved, kind="type",
                                                 line=node.line, col=node.col)
        return T_VOID

    def visit_ImportDecl(self, node: ImportDecl) -> InScriptType:
        """Register imported symbols so the type checker knows about them."""
        try:
            import stdlib as _stdlib
            mod = _stdlib.load_module(node.path)
        except Exception:
            # Unknown module - skip analysis, interpreter will catch it
            return T_VOID

        if node.alias:
            self._define(Symbol(node.alias, T_ANY, kind="var",
                                line=node.line, col=node.col))
        elif node.names:
            for name in node.names:
                self._define(Symbol(name, T_ANY, kind="var",
                                    line=node.line, col=node.col))
        else:
            # import "math" — register all exported names
            for name in mod:
                if not self._scope.lookup_local(name):
                    self._scope.symbols[name] = Symbol(name, T_ANY, kind="var",
                                                        line=node.line, col=node.col)
        return T_VOID

    # ── Statements ────────────────────────────────────────────────────────────

    def visit_BlockStmt(self, node: BlockStmt) -> InScriptType:
        self._push_scope("block")
        terminated = False   # True after return/break/continue/throw
        for stmt in node.body:
            if terminated and not self._no_warn:
                line = getattr(stmt, "line", 0)
                self._warn("unreachable",
                           "Unreachable code after return/break/continue/throw",
                           line)
                # Still visit so inner undefined-name errors are caught
            self.visit(stmt)
            from ast_nodes import ThrowStmt as ThrowStmt_
            if isinstance(stmt, (ReturnStmt, BreakStmt, ContinueStmt, ThrowStmt_)):
                terminated = True
        self._pop_scope()
        return T_VOID

    def visit_ExprStmt(self, node: ExprStmt) -> InScriptType:
        return self.visit(node.expr)

    def visit_PrintStmt(self, node: PrintStmt) -> InScriptType:
        for arg in node.args:
            self.visit(arg)
        return T_VOID

    def visit_ReturnStmt(self, node: ReturnStmt) -> InScriptType:
        if self._current_fn_return_type is None:
            self._error("'return' outside of function", node.line, node.col)
            return T_VOID   # multi-error: continue safely

        ret_type = T_VOID
        if node.value:
            ret_type = self.visit(node.value)

        if not types_compatible(self._current_fn_return_type, ret_type):
            self._error(
                f"Return type mismatch: function expects "
                f"'{self._current_fn_return_type}', got '{ret_type}'",
                node.line, node.col
            )
        return ret_type

    def visit_BreakStmt(self, node: BreakStmt) -> InScriptType:
        if self._loop_depth == 0:
            self._error("'break' outside of loop", node.line, node.col)
        return T_VOID

    def visit_ContinueStmt(self, node: ContinueStmt) -> InScriptType:
        if self._loop_depth == 0:
            self._error("'continue' outside of loop", node.line, node.col)
        return T_VOID

    def _extract_typeof_narrowing(self, condition) -> tuple:
        """v1.8.1: If condition is `typeof(x) == "T"` return (var_name, narrowed_type).
        Returns (None, None) if the condition is not that pattern."""
        if not (hasattr(condition, 'op') and condition.op == "=="):
            return (None, None)
        left, right = condition.left, condition.right
        # Support both sides for the string literal
        if (hasattr(right, 'args') and isinstance(getattr(right, 'callee', None), object)
                and hasattr(left, 'value') and isinstance(left.value, str)):
            left, right = right, left
        # left must be a CallExpr(callee=IdentExpr("typeof"|"type"), args=[IdentExpr])
        if not hasattr(left, 'callee') or not hasattr(left, 'args'):
            return (None, None)
        callee_name = getattr(left.callee, 'name', None)
        if callee_name not in ("typeof", "type"):
            return (None, None)
        if not left.args:
            return (None, None)
        arg0 = left.args[0]
        arg_val = getattr(arg0, 'value', arg0)  # Argument node wraps value
        var_name = getattr(arg_val, 'name', None)
        if var_name is None:
            return (None, None)
        # right must be a StringLiteralExpr
        if not hasattr(right, 'value') or not isinstance(right.value, str):
            return (None, None)
        type_name = right.value
        narrow_to = BUILTIN_TYPES.get(type_name, InScriptType(type_name))
        return (var_name, narrow_to)

    def visit_IfStmt(self, node: IfStmt) -> InScriptType:
        cond_type = self.visit(node.condition)
        if cond_type not in (T_BOOL, T_ANY):
            self._warn(
                f"Condition expression has type '{cond_type}' (expected bool) — "
                f"non-bool conditions will be truthy/falsy at runtime",
                node.line
            )

        # v1.8.1: union narrowing — `if typeof(x) == "int" { }` narrows x to int
        var_name, narrow_to = self._extract_typeof_narrowing(node.condition)
        if var_name and narrow_to:
            # Push a scope, inject narrowed binding, then visit the BODY STATEMENTS
            # directly so the narrowed type is visible for the entire then-branch.
            self._push_scope("block")
            sym = self._scope.parent.lookup(var_name) if self._scope.parent else None
            if sym:
                narrowed_sym = Symbol(var_name, narrow_to, sym.kind,
                                      line=sym.line, col=sym.col)
                narrowed_sym.used = True
                self._define(narrowed_sym)
            # Visit body stmts without letting visit_BlockStmt push another scope
            from ast_nodes import BlockStmt
            body = node.then_branch
            stmts = body.body if isinstance(body, BlockStmt) else [body]
            for stmt in stmts:
                self.visit(stmt)
            self._pop_scope()
        else:
            self.visit(node.then_branch)

        if node.else_branch:
            self.visit(node.else_branch)
        return T_VOID

    def visit_WhileStmt(self, node: WhileStmt) -> InScriptType:
        self.visit(node.condition)
        self._loop_depth += 1
        self.visit(node.body)
        self._loop_depth -= 1
        return T_VOID

    def visit_ForInStmt(self, node: ForInStmt) -> InScriptType:
        iter_type = self.visit(node.iterable)
        self._push_scope("block")

        # Infer element type from iterable type
        if isinstance(iter_type, InScriptType) and iter_type.name == "Array" and iter_type.params:
            elem_type = iter_type.params[0]
        elif isinstance(iter_type, InScriptType) and iter_type.name in ("Range",):
            elem_type = T_INT
        else:
            elem_type = T_ANY  # unknown iterable

        self._define(Symbol(node.var_name, elem_type, "var",
                            line=node.line, col=node.col))
        self._loop_depth += 1
        self.visit(node.body)
        self._loop_depth -= 1
        self._pop_scope()
        return T_VOID

    def visit_MatchStmt(self, node: MatchStmt) -> InScriptType:
        self.visit(node.subject)

        # 1.6 — Exhaustiveness check for enum matches
        has_wildcard = any(arm.pattern is None for arm in node.arms)
        if not has_wildcard:
            self._check_match_exhaustiveness(node)

        for arm in node.arms:
            self._push_scope("match_arm")
            if arm.binding:
                self._define(Symbol(arm.binding, T_ANY, kind="var", line=node.line))
            if arm.pattern:
                self.visit(arm.pattern)
            if arm.guard:
                self.visit(arm.guard)
            prev = self._in_match_arm
            self._in_match_arm = True
            self.visit(arm.body)
            self._in_match_arm = prev
            self._pop_scope()
        return T_VOID

    def _check_match_exhaustiveness(self, node: MatchStmt) -> None:
        """
        v1.8.3: Enum exhaustiveness is now a SemanticError (not a warning).
        If the match subject is a variable typed as a known enum and no wildcard
        is present, every variant must be explicitly covered.
        """
        subject  = node.subject
        enum_name = None

        if isinstance(subject, IdentExpr):
            sym = self._scope.lookup(subject.name)
            if sym and sym.type_:
                t = sym.type_
                # Resolve via the full scope chain, not just current scope
                cand = self._scope.lookup(t.name)
                if cand and cand.kind == "enum":
                    enum_name = t.name

        if enum_name is None:
            return  # subject is not a typed enum variable — skip

        enum_sym = self._scope.lookup(enum_name)
        if not enum_sym or enum_sym.fn_node is None:
            return
        enum_decl  = enum_sym.fn_node
        all_variants = {v.name for v in getattr(enum_decl, 'variants', [])}
        if not all_variants:
            return

        # Collect explicitly covered variants
        # `case Dir::Left` → NamespaceAccessExpr(namespace="Dir", member="Left")
        # `case Dir.Left`  → GetAttrExpr(obj=IdentExpr("Dir"), attr="Left")  (legacy)
        covered = set()
        for arm in node.arms:
            p = arm.pattern
            if p is None:
                return  # wildcard — exhaustive by definition
            # Primary form: Dir::Variant
            if (hasattr(p, 'namespace') and hasattr(p, 'member')
                    and p.namespace == enum_name):
                covered.add(p.member)
            # Legacy form: Dir.Variant
            elif (isinstance(p, GetAttrExpr)
                    and isinstance(p.obj, IdentExpr)
                    and p.obj.name == enum_name):
                covered.add(p.attr)

        missing = sorted(all_variants - covered)
        if missing:
            self._error(
                f"Non-exhaustive match on '{enum_name}': "
                f"missing variant(s) {missing}. Add the missing cases or a wildcard arm 'case _'",
                node.line
            )

    def visit_ThrowStmt(self, node: ThrowStmt) -> InScriptType:
        self.visit(node.value)
        return T_VOID

    def visit_TryCatchStmt(self, node: TryCatchStmt) -> InScriptType:
        self.visit(node.body)
        self._push_scope("block")
        if node.catch_var:
            catch_t = self._resolve_type_ann(node.catch_type) if node.catch_type else T_ANY
            self._define(Symbol(node.catch_var, catch_t, "var", line=node.line))
        self.visit(node.handler)
        self._pop_scope()
        return T_VOID

    # ── Expressions ───────────────────────────────────────────────────────────

    def visit_IntLiteralExpr(self, node: IntLiteralExpr)   -> InScriptType: return T_INT
    def visit_FloatLiteralExpr(self, node: FloatLiteralExpr) -> InScriptType: return T_FLOAT
    def visit_StringLiteralExpr(self, node: StringLiteralExpr) -> InScriptType:
        # v1.8.2: return a specific literal type so union-of-literals is enforced
        return literal_type(node.value)
    def visit_BoolLiteralExpr(self, node: BoolLiteralExpr) -> InScriptType: return T_BOOL
    def visit_NullLiteralExpr(self, node: NullLiteralExpr) -> InScriptType: return T_NULL

    def visit_IdentExpr(self, node: IdentExpr) -> InScriptType:
        sym = self._lookup(node.name, node.line, node.col)
        return sym.type_

    def visit_ArrayLiteralExpr(self, node: ArrayLiteralExpr) -> InScriptType:
        if not node.elements:
            return array_type(T_ANY)
        # v1.9.8: infer element type; fall back to Array<any> on mixed types
        first_type = self.visit(node.elements[0])
        # Normalise literal string types to T_STRING for array inference
        if is_literal_type(first_type):
            first_type = T_STRING
        mixed = False
        for elem in node.elements[1:]:
            et = self.visit(elem)
            if is_literal_type(et):
                et = T_STRING
            if not types_compatible(first_type, et) and not types_compatible(et, first_type):
                mixed = True
        if mixed:
            return array_type(T_ANY)   # [1, "a", true] → Array<any>
        return array_type(first_type)  # [1, 2, 3] → Array<int>

    def visit_DictLiteralExpr(self, node: DictLiteralExpr) -> InScriptType:
        if not node.pairs:
            return dict_type(T_ANY, T_ANY)
        k_type = self.visit(node.pairs[0][0])
        v_type = self.visit(node.pairs[0][1])
        for k, v in node.pairs[1:]:
            self.visit(k); self.visit(v)
        return dict_type(k_type, v_type)

    def visit_BinaryExpr(self, node: BinaryExpr) -> InScriptType:
        left  = self.visit(node.left)
        right = self.visit(node.right)
        op    = node.op

        # v1.8.2: literal string types act as T_STRING in all operations
        if is_literal_type(left):  left  = T_STRING
        if is_literal_type(right): right = T_STRING

        # Comparison operators always return bool
        if op in ("==", "!=", "<", ">", "<=", ">="):
            return T_BOOL

        # Logical operators require bool (but we allow any and warn)
        if op in ("&&", "||"):
            return T_BOOL

        # Arithmetic
        if op in ("+", "-", "*", "/", "%", "**"):
            # String concatenation — any + string, or string + any → string
            if op == "+" and (left == T_STRING or right == T_STRING):
                return T_STRING
            if is_numeric(left) and is_numeric(right):
                return numeric_result(left, right)
            # Vector arithmetic
            if is_vec(left) and is_vec(right) and left == right:
                return left
            if is_vec(left) and is_numeric(right):
                return left
            if is_numeric(left) and is_vec(right):
                return right
            if left == T_ANY or right == T_ANY:
                return T_ANY
            self._error(
                f"Operator '{op}' cannot be applied to types '{left}' and '{right}'",
                node.line, node.col
            )

        return T_ANY

    def visit_UnaryExpr(self, node: UnaryExpr) -> InScriptType:
        operand = self.visit(node.operand)
        if node.op == "!":
            return T_BOOL
        if node.op == "-":
            if is_numeric(operand) or is_vec(operand) or operand == T_ANY:
                return operand
            self._error(f"Unary '-' cannot be applied to type '{operand}'",
                        node.line, node.col)
        return T_ANY

    def visit_AssignExpr(self, node: AssignExpr) -> InScriptType:
        val_type = self.visit(node.value)

        if isinstance(node.target, IdentExpr):
            sym = self._lookup(node.target.name, node.line, node.col)
            if sym.is_const:
                self._error(f"Cannot assign to constant '{sym.name}'",
                            node.line, node.col)
            if not types_compatible(sym.type_, val_type):
                self._error(
                    f"Type mismatch in assignment to '{sym.name}': "
                    f"expected '{sym.type_}', got '{val_type}'",
                    node.line, node.col
                )
            return sym.type_
        else:
            # Attribute or index assignment — check the target is valid
            self.visit(node.target)
            return val_type

    def visit_SetAttrExpr(self, node: SetAttrExpr) -> InScriptType:
        self.visit(node.obj)
        return self.visit(node.value)

    def visit_SetIndexExpr(self, node: SetIndexExpr) -> InScriptType:
        self.visit(node.obj)
        self.visit(node.index)
        return self.visit(node.value)

    def visit_GetAttrExpr(self, node: GetAttrExpr) -> InScriptType:
        obj_type = self.visit(node.obj)

        # If the object is a known struct type, validate field/method access
        # Walk the full inheritance chain: child → parent → grandparent
        if obj_type.name in self._struct_defs:
            name = obj_type.name
            while name and name in self._struct_defs:
                struct = self._struct_defs[name]
                for field in struct.fields:
                    if field.name == node.attr:
                        return self._resolve_type_ann(field.type_ann)
                for method in struct.methods:
                    if method.name == node.attr:
                        return self._resolve_type_ann(method.return_type)
                name = getattr(struct, "parent_name", None)
            self._error(
                f"Struct '{obj_type.name}' has no field or method '{node.attr}'",
                node.line, node.col
            )

        # For built-in game types, return any (we trust the runtime)
        return T_ANY

    def visit_IndexExpr(self, node: IndexExpr) -> InScriptType:
        obj_type = self.visit(node.obj)
        self.visit(node.index)
        if obj_type.name == "Array" and obj_type.params:
            return obj_type.params[0]
        if obj_type.name == "Dict" and obj_type.params:
            return obj_type.params[1] if len(obj_type.params) > 1 else T_ANY
        return T_ANY

    def visit_CallExpr(self, node: CallExpr) -> InScriptType:
        callee_type = self.visit(node.callee)
        for arg in node.args:
            self.visit(arg.value)

        # If callee is a known function, check arg count and return declared type
        if isinstance(node.callee, IdentExpr):
            sym = self._scope.lookup(node.callee.name)
            if sym and sym.kind == "fn" and sym.fn_node:
                fn = sym.fn_node
                # Count required params (those without defaults) vs total
                n_args   = len(node.args)
                params   = fn.params or []
                n_total  = len(params)
                n_required = sum(1 for p in params
                                 if not getattr(p, 'default', None) and
                                    not getattr(p, 'variadic', False))
                has_variadic = any(getattr(p, 'variadic', False) for p in params)
                if not has_variadic:
                    if n_args < n_required:
                        self._warn(
                            "arg-count",
                            f"Too few arguments: '{node.callee.name}' expects at least "
                            f"{n_required} arg(s), got {n_args}",
                            node.line
                        )
                    elif n_args > n_total:
                        self._warn(
                            "arg-count",
                            f"Too many arguments: '{node.callee.name}' expects at most "
                            f"{n_total} arg(s), got {n_args}",
                            node.line
                        )
                # v1.8.1: check argument types against declared param types
                for i, arg in enumerate(node.args):
                    if i >= len(params):
                        break
                    p_type = self._resolve_type_ann(params[i].type_ann)
                    if p_type == T_ANY:
                        continue
                    arg_type = self.visit(arg.value)
                    if not types_compatible(p_type, arg_type):
                        self._error(
                            f"Argument {i+1} to '{node.callee.name}': "
                            f"expected '{p_type}', got '{arg_type}'",
                            getattr(arg.value, 'line', node.line)
                        )
                return self._resolve_type_ann(fn.return_type)
            if sym:
                if sym.kind == "struct":
                    return InScriptType(sym.name)
                return sym.type_

        if isinstance(node.callee, GetAttrExpr):
            # v1.8.4: infer return types of array method chains
            obj_type = self.visit(node.callee.obj)
            # v1.8.2 literal_type("hello") → dispatch as T_STRING
            if is_literal_type(obj_type):
                obj_type = T_STRING
            method   = node.callee.attr
            return self._infer_method_call_type(obj_type, method, node)

        return T_ANY

    def _infer_method_call_type(self, obj_type: InScriptType,
                                 method: str, call_node) -> InScriptType:
        """
        v1.8.4: Infer the return type of a method call based on the receiver's type.

        Array methods:
          .map(fn)      → Array<T> where T = inferred return type of fn
          .filter(fn)   → Array<elem>  (same element type, just fewer items)
          .flatMap(fn)  → Array<T>
          .take(n)      → Array<elem>
          .skip(n)      → Array<elem>
          .slice(a,b)   → Array<elem>
          .sorted()     → Array<elem>
          .reversed()   → Array<elem>
          .unique()     → Array<elem>
          .len()        → int
          .count()      → int
          .sum()        → int | float
          .first()      → elem?   (optional)
          .last()       → elem?
          .find(fn)     → elem?
          .any(fn)      → bool
          .all(fn)      → bool
          .reduce(fn,i) → any (can't infer accumulator type without annotation)
          .join(sep)    → string
          .push(v)      → void
          .pop()        → elem?
          .contains(v)  → bool
          .index_of(v)  → int?

        String methods:
          .split(sep)   → Array<string>
          .trim()       → string
          .upper()      → string
          .lower()      → string
          .replace(...) → string
          .starts_with()→ bool
          .ends_with()  → bool
          .contains()   → bool
          .len()        → int
          .chars()      → Array<string>
        """
        # ── Array method inference ────────────────────────────────────────────
        if obj_type.name == "Array":
            elem = obj_type.params[0] if obj_type.params else T_ANY

            # Methods that return Array<same-elem>
            if method in ("filter", "take", "skip", "slice", "sorted",
                          "reversed", "unique", "shuffle", "concat"):
                return array_type(elem)

            # .map(fn) / .flatMap(fn) → infer fn return type
            if method in ("map", "flatMap"):
                fn_ret = self._infer_fn_arg_return(call_node, arg_index=0, param_type=elem)
                inner  = fn_ret if fn_ret != T_ANY else T_ANY
                if method == "flatMap" and inner.name == "Array":
                    inner = inner.params[0] if inner.params else T_ANY
                return array_type(inner)

            # Scalar reductions
            if method in ("len", "count", "index_of"):
                return T_INT
            if method == "sum":
                return elem if elem in (T_INT, T_FLOAT) else T_INT
            if method in ("any", "all", "contains", "is_empty"):
                return T_BOOL
            if method == "join":
                return T_STRING
            if method in ("push", "append", "extend", "clear", "insert",
                          "remove", "remove_at"):
                return T_VOID

            # Optional-returning methods
            if method in ("first", "last", "pop", "find", "get"):
                return optional_type(elem)

            # .reduce → T_ANY (accumulator type unknown without annotation)
            if method == "reduce":
                return T_ANY

            # .each(fn) → void (side-effect traversal)
            if method in ("each", "for_each"):
                return T_VOID

        # ── String method inference ───────────────────────────────────────────
        if obj_type == T_STRING:
            if method in ("trim", "upper", "lower", "replace", "strip",
                          "lstrip", "rstrip", "pad_left", "pad_right",
                          "repeat", "reverse", "slice"):
                return T_STRING
            if method in ("len", "count", "index_of", "find"):
                return T_INT
            if method in ("starts_with", "ends_with", "contains", "is_empty",
                          "matches"):
                return T_BOOL
            if method == "split":
                return array_type(T_STRING)
            if method == "chars":
                return array_type(T_STRING)
            if method == "to_int":
                return optional_type(T_INT)
            if method == "to_float":
                return optional_type(T_FLOAT)

        # ── Int / Float methods ───────────────────────────────────────────────
        if obj_type in (T_INT, T_FLOAT):
            if method in ("abs", "floor", "ceil", "round", "sqrt",
                          "clamp", "min", "max"):
                return obj_type
            if method == "to_string":
                return T_STRING

        # ── Struct method return type ─────────────────────────────────────────
        if obj_type.name in self._struct_defs:
            struct = self._struct_defs[obj_type.name]
            for m in (struct.methods or []):
                if m.name == method:
                    return self._resolve_type_ann(m.return_type)

        return T_ANY

    def _infer_fn_return_type(self, node) -> InScriptType:
        """
        v1.8.4: Infer a function's return type from its body when no annotation exists.
        Only infers when ALL return paths agree on the same concrete type.
        Falls back to T_ANY if ambiguous.
        NOTE: errors are suppressed — inference is best-effort, never raises.
        """
        from ast_nodes import ReturnStmt, BlockStmt

        if not node.body:
            return T_VOID

        # Stash and suppress the real error list — inference must never pollute it
        saved_errors = self._errors
        self._errors  = []

        try:
            # Push a temporary scope with params typed per their annotations
            self._push_scope("infer-fn")
            for p in (node.params or []):
                p_type = self._resolve_type_ann(getattr(p, 'type_ann', None))
                pname  = getattr(p, 'name', None)
                if pname:
                    self._scope.symbols[pname] = Symbol(
                        pname, p_type, kind="var",
                        line=getattr(p, 'line', 0), col=getattr(p, 'col', 0)
                    )
                    self._scope.symbols[pname].used = True

            # Collect return types from first-level stmts + if/else branches
            types_seen = set()
            stmts = node.body.body if isinstance(node.body, BlockStmt) else [node.body]
            for stmt in stmts:
                if isinstance(stmt, ReturnStmt) and stmt.value is not None:
                    try:
                        t = self.visit(stmt.value)
                        if is_literal_type(t): t = T_STRING
                        types_seen.add(t)
                    except Exception:
                        types_seen.add(T_ANY)
                for branch_attr in ('then_branch', 'else_branch'):
                    branch = getattr(stmt, branch_attr, None)
                    if branch is None:
                        continue
                    inner = getattr(branch, 'body', [branch])
                    if not isinstance(inner, list):
                        inner = [inner]
                    for s in inner:
                        if isinstance(s, ReturnStmt) and s.value is not None:
                            try:
                                t = self.visit(s.value)
                                if is_literal_type(t): t = T_STRING
                                types_seen.add(t)
                            except Exception:
                                types_seen.add(T_ANY)

            self._pop_scope()

            if not types_seen:
                return T_VOID
            non_any = {t for t in types_seen if t != T_ANY}
            if len(non_any) == 1:
                return next(iter(non_any))
            if non_any == {T_INT, T_FLOAT}:
                return T_FLOAT
            return T_ANY

        except Exception:
            return T_ANY
        finally:
            # Always restore the real error list
            self._errors = saved_errors

    def _infer_fn_arg_return(self, call_node, arg_index: int,
                              param_type: InScriptType) -> InScriptType:
        """
        v1.8.4: Given a CallExpr and an argument position that expects a fn,
        try to infer that fn's return type by visiting its body with a temporary
        scope that binds the param to param_type.
        Returns T_ANY if inference fails.
        """
        from ast_nodes import FunctionDecl, LambdaExpr
        if arg_index >= len(call_node.args):
            return T_ANY
        fn_arg = call_node.args[arg_index].value

        # Handle both lambda `fn(x) { return x * 2 }` and named refs
        params = None; body = None
        if isinstance(fn_arg, FunctionDecl) or isinstance(fn_arg, LambdaExpr):
            params = getattr(fn_arg, 'params', [])
            body   = getattr(fn_arg, 'body', None)
        else:
            return T_ANY

        # Stash and suppress the real error list
        saved_errors  = self._errors
        self._errors   = []

        try:
            # Push a temporary scope, bind first param to elem type
            self._push_scope("infer")
            if params:
                p0 = params[0]
                p_name = getattr(p0, 'name', None)
                if p_name:
                    self._scope.symbols[p_name] = Symbol(
                        p_name, param_type, kind="var",
                        line=getattr(p0, 'line', 0), col=getattr(p0, 'col', 0)
                    )
                    self._scope.symbols[p_name].used = True

            inferred = T_ANY
            if body is not None:
                inferred = self._infer_block_return_type(body)

            self._pop_scope()
            return inferred
        except Exception:
            return T_ANY
        finally:
            self._errors = saved_errors

    def _infer_block_return_type(self, block) -> InScriptType:
        """
        v1.8.4: Walk a block/expression to find the first return statement's type.
        Also handles single-expression lambdas.
        """
        from ast_nodes import BlockStmt, ReturnStmt
        stmts = []
        if isinstance(block, BlockStmt):
            stmts = block.body
        elif hasattr(block, '__iter__'):
            stmts = list(block)
        else:
            # Single expression (arrow lambda)
            try:
                return self.visit(block)
            except Exception:
                return T_ANY

        for stmt in stmts:
            if isinstance(stmt, ReturnStmt) and stmt.value is not None:
                try:
                    return self.visit(stmt.value)
                except Exception:
                    return T_ANY
            # Recurse into if/while bodies for early returns
            if hasattr(stmt, 'then_branch'):
                t = self._infer_block_return_type(stmt.then_branch)
                if t != T_ANY:
                    return t
        return T_ANY

    def visit_NamespaceAccessExpr(self, node: NamespaceAccessExpr) -> InScriptType:
        # Color::RED, Vec2::ZERO, etc.  — return T_ANY for now
        return T_ANY

    def visit_StructInitExpr(self, node: StructInitExpr) -> InScriptType:
        if node.struct_name not in self._struct_defs:
            self._error(
                f"Unknown struct: '{node.struct_name}'",
                node.line, node.col
            )
            return T_ANY   # multi-error: continue safely
        # Collect fields from the full inheritance chain
        field_map = {}
        chain = []
        name = node.struct_name
        while name and name in self._struct_defs:
            chain.append(self._struct_defs[name])
            parent = getattr(self._struct_defs[name], "parent_name", None)
            name = parent
        for struct in reversed(chain):      # parent fields first, child overrides
            for f in struct.fields:
                field_map[f.name] = f

        for field_name, value_node in node.fields:
            if field_name not in field_map:
                field_candidates = list(field_map.keys())
                self._error(
                    f"Struct '{node.struct_name}' has no field '{field_name}'",
                    node.line, node.col,
                    candidates=field_candidates
                )
                self.visit(value_node)   # still visit to catch inner errors
                continue
            val_type = self.visit(value_node)
            expected = self._resolve_type_ann(field_map[field_name].type_ann)
            if not types_compatible(expected, val_type):
                self._error(
                    f"Struct field '{field_name}': expected '{expected}', got '{val_type}'",
                    node.line, node.col
                )

        return InScriptType(node.struct_name)

    def visit_RangeExpr(self, node: RangeExpr) -> InScriptType:
        s = self.visit(node.start)
        e = self.visit(node.end)
        if s not in (T_INT, T_ANY) or e not in (T_INT, T_ANY):
            self._error(f"Range bounds must be int, got '{s}' and '{e}'",
                        node.line, node.col)
        return InScriptType("Range", [T_INT])

    def visit_LambdaExpr(self, node: LambdaExpr) -> InScriptType:
        self._push_scope("fn")
        prev_ret = self._current_fn_return_type
        ret_type = self._resolve_type_ann(node.return_type)
        self._current_fn_return_type = ret_type

        for param in node.params:
            p_type = self._resolve_type_ann(param.type_ann)
            self._define(Symbol(param.name, p_type, "var",
                                line=param.line, col=param.col))
        self.visit(node.body)

        self._current_fn_return_type = prev_ret
        self._pop_scope()
        return InScriptType("Function")

    def visit_AwaitExpr(self, node: AwaitExpr) -> InScriptType:
        return self.visit(node.expr)

    def visit_SpawnExpr(self, node: SpawnExpr) -> InScriptType:
        return T_ANY   # entity type

    def visit_WaitStmt(self, node: WaitStmt) -> InScriptType:
        dur = self.visit(node.duration)
        if not types_compatible(T_FLOAT, dur):
            self._error(f"'wait' expects a float duration, got '{dur}'",
                        node.line, node.col)
        return T_VOID

    def visit_AIDecl(self, node: AIDecl) -> InScriptType:
        for state in node.states:
            self._push_scope("fn")
            for hook in state.hooks:
                self._push_scope("fn")
                prev_ret = self._current_fn_return_type
                self._current_fn_return_type = T_VOID
                for param in hook.params:
                    p_type = self._resolve_type_ann(param.type_ann)
                    self._define(Symbol(param.name, p_type, "var", line=param.line))
                self.visit(hook.body)
                self._current_fn_return_type = prev_ret
                self._pop_scope()
            self._pop_scope()
        return T_VOID

    def visit_ShaderDecl(self, node: ShaderDecl) -> InScriptType:
        return T_VOID  # Shader analysis is Phase 14

    def visit_MatchArm(self, node: MatchArm) -> InScriptType:
        if node.pattern:
            self.visit(node.pattern)
        self.visit(node.body)
        return T_VOID

    def generic_visit(self, node: Node) -> InScriptType:
        # Silently pass through nodes we haven't handled yet
        return T_ANY


# ─────────────────────────────────────────────────────────────────────────────
# CONVENIENCE FUNCTION
# ─────────────────────────────────────────────────────────────────────────────

def analyze(program: Program, source: str = "") -> Dict[str, Symbol]:
    """Run the semantic analyzer on a parsed program. Returns symbol table."""
    src_lines = source.splitlines() if source else []
    return Analyzer(src_lines).analyze(program)
