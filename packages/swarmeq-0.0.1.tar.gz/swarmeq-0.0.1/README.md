# swarmeq

Reserved namespace. Affective-state observability for AI agents and multi-agent systems.

See https://github.com/swarmeq for updates.

swarmeq™ is a trademark of Matt Hahnfeld.
