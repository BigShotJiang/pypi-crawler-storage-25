"""Reserved namespace. The swarmeq package is staged for an upcoming release.

See https://github.com/swarmeq for updates.
"""

__version__ = "0.0.1"
