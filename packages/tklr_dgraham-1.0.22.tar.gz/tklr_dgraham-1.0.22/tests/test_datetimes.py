import time
from datetime import date, datetime

import pytest

from tklr.item import Item
from tklr.model import DatabaseManager, UrgencyComputer
from tklr.tklr_env import TklrEnvironment


@pytest.fixture
def isolated_env(tmp_path, monkeypatch):
    """Create a throwaway TKLR_HOME so tests never touch local data."""
    home = tmp_path / "tklr-home"
    monkeypatch.delenv("TKLR_HOME", raising=False)
    monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
    monkeypatch.setenv("TKLR_HOME", str(home))

    env = TklrEnvironment()
    env.ensure(init_config=True, init_db_fn=None)
    return env


@pytest.mark.parametrize("tz_name", ["Etc/GMT+5"])
def test_rdate_rows_use_local_time(isolated_env, monkeypatch, tz_name):
    """
    Regression test: RDATE-only reminders must emit local-naive timestamps
    into DateTimes even though the rruleset stores UTC ('...Z').
    """

    monkeypatch.setenv("TZ", tz_name)
    if hasattr(time, "tzset"):
        time.tzset()

    dbm = DatabaseManager(
        str(isolated_env.db_path),
        isolated_env,
        reset=True,
        auto_populate=False,
    )

    single = Item(
        env=isolated_env,
        raw="* single @s 2026-01-08 11:00 @e 1h",
        final=True,
    )
    recurring = Item(
        env=isolated_env,
        raw="* repeating @s 2026-01-08 11:00 @e 1h @r w",
        final=True,
    )

    single_id = dbm.add_item(single)
    repeat_id = dbm.add_item(recurring)

    dbm.generate_datetimes_for_record(single_id, clear_existing=True)
    dbm.generate_datetimes_for_record(repeat_id, clear_existing=True)
    dbm.conn.commit()

    (rruleset_single,) = dbm.cursor.execute(
        "SELECT rruleset FROM Records WHERE id=?", (single_id,)
    ).fetchone()
    assert "RDATE:20260108T1600Z" in rruleset_single

    rows = dbm.cursor.execute(
        "SELECT start_datetime FROM DateTimes WHERE record_id=? ORDER BY start_datetime",
        (single_id,),
    ).fetchall()
    assert rows == [("20260108T1100",)]

    repeat_rows = dbm.cursor.execute(
        "SELECT start_datetime FROM DateTimes WHERE record_id=? ORDER BY start_datetime LIMIT 2",
        (repeat_id,),
    ).fetchall()
    assert repeat_rows[0][0].endswith("1100")
    assert repeat_rows[1][0].endswith("1100")

    dbm.conn.close()


@pytest.mark.parametrize("tz_name", ["US/Eastern"])
def test_aware_weekly_recurrence_keeps_local_wall_time_across_dst(
    isolated_env, monkeypatch, tz_name
):
    """
    Aware recurring reminders are stored in UTC, but each generated instance
    should be expanded in the record's timezone before conversion back to the
    viewer's local timezone. This keeps an 8:00 AM US/Eastern series at 8:00 AM
    after the March 8, 2026 DST transition.
    """

    monkeypatch.setenv("TZ", tz_name)
    if hasattr(time, "tzset"):
        time.tzset()

    dbm = DatabaseManager(
        str(isolated_env.db_path),
        isolated_env,
        reset=True,
        auto_populate=False,
    )

    item = Item(
        env=isolated_env,
        raw=(
            "* pickleball @s 2026-01-05 8:00AM @e 90m @r w &w MO, TH @- 20260129T0800"
        ),
        final=True,
    )
    record_id = dbm.add_item(item)

    dbm.generate_datetimes_for_record(
        record_id,
        clear_existing=True,
        window=(datetime(2026, 3, 1), datetime(2026, 3, 31, 23, 59)),
    )
    dbm.conn.commit()

    (rruleset,) = dbm.cursor.execute(
        "SELECT rruleset FROM Records WHERE id=?",
        (record_id,),
    ).fetchone()
    assert "DTSTART:20260105T1300Z" in rruleset
    assert "EXDATE:20260129T1300Z" in rruleset

    rows = dbm.cursor.execute(
        "SELECT start_datetime FROM DateTimes WHERE record_id=? ORDER BY start_datetime",
        (record_id,),
    ).fetchall()
    assert rows == [
        ("20260302T0800",),
        ("20260305T0800",),
        ("20260309T0800",),
        ("20260312T0800",),
        ("20260316T0800",),
        ("20260319T0800",),
        ("20260323T0800",),
        ("20260326T0800",),
        ("20260330T0800",),
    ]

    dbm.conn.close()


def test_repetitions_fallback_handles_aware_rrules_without_datetime_rows(
    test_controller, item_factory, freeze_at
):
    item = item_factory(
        "* test for mel @s 2026-02-27 8:00AM @r w @a 0m: n",
        final=True,
    )
    record_id = test_controller.add_item(item)

    test_controller.db_manager.cursor.execute(
        "DELETE FROM DateTimes WHERE record_id = ?",
        (record_id,),
    )
    test_controller.db_manager.conn.commit()

    with freeze_at("2026-03-13 11:37:00"):
        title, lines = test_controller.get_record_repetitions(record_id, limit=3)

    assert title == "Repetitions for test for mel"
    assert lines
    assert not any("Unable to parse rruleset" in line for line in lines)
    assert lines[0].startswith("Next ")


def test_repetitions_can_start_from_selected_instance_with_datetime_rows(
    test_controller, item_factory, freeze_at
):
    item = item_factory("* weekly check-in @s 2026-02-27 8:00AM @r w", final=True)
    record_id = test_controller.add_item(item)

    test_controller.db_manager.generate_datetimes_for_record(
        record_id,
        clear_existing=True,
        window=(datetime(2026, 2, 1), datetime(2026, 4, 30, 23, 59)),
    )
    test_controller.db_manager.conn.commit()

    with freeze_at("2026-03-13 11:37:00"):
        title, lines = test_controller.get_record_repetitions(
            record_id,
            limit=3,
            instance_ts="20260327T0800",
        )

    assert title == "Repetitions for weekly check-in"
    assert lines[0] == "Next 3 occurrence(s):"
    assert lines[1] == f"  • {test_controller.fmt_user(datetime(2026, 3, 27, 8, 0))}"
    assert lines[2] == f"  • {test_controller.fmt_user(datetime(2026, 4, 3, 8, 0))}"


def test_repetitions_fallback_can_start_from_selected_instance(
    test_controller, item_factory, freeze_at
):
    item = item_factory("* weekly fallback @s 2026-02-27 8:00AM @r w", final=True)
    record_id = test_controller.add_item(item)

    test_controller.db_manager.cursor.execute(
        "DELETE FROM DateTimes WHERE record_id = ?",
        (record_id,),
    )
    test_controller.db_manager.conn.commit()

    with freeze_at("2026-03-13 11:37:00"):
        title, lines = test_controller.get_record_repetitions(
            record_id,
            limit=3,
            instance_ts="20260327T0800",
        )

    assert title == "Repetitions for weekly fallback"
    assert lines[0] == "Next 3 occurrence(s):"
    assert lines[1] == f"  • {test_controller.fmt_user(datetime(2026, 3, 27, 8, 0))}"


def test_repetitions_fallback_handles_aware_until_date_without_parse_error(
    test_controller, item_factory, freeze_at
):
    item = item_factory(
        "* maintenance aware until @s 2026-03-20 @r d &u 2026-03-22",
        final=True,
    )
    record_id = test_controller.add_item(item)

    test_controller.db_manager.cursor.execute(
        "DELETE FROM DateTimes WHERE record_id = ?",
        (record_id,),
    )
    test_controller.db_manager.conn.commit()

    with freeze_at("2026-03-19 11:37:00"):
        title, lines = test_controller.get_record_repetitions(record_id, limit=3)

    assert title == "Repetitions for maintenance aware until"
    assert lines
    assert not any("Unable to parse rruleset" in line for line in lines)
    assert lines[0] == "Next 3 occurrence(s):"
    assert lines[1] == f"  • {test_controller.fmt_user_date_only(date(2026, 3, 20))}"
    assert lines[2] == f"  • {test_controller.fmt_user_date_only(date(2026, 3, 21))}"
    assert lines[3] == f"  • {test_controller.fmt_user_date_only(date(2026, 3, 22))}"


def test_repetitions_all_day_midnight_without_extent_hide_time(
    test_controller, item_factory, freeze_at
):
    item = item_factory("* maintenance @s 2026-03-20 @r d &u 2026-03-22", final=True)
    record_id = test_controller.add_item(item)

    test_controller.db_manager.cursor.execute(
        "DELETE FROM DateTimes WHERE record_id = ?",
        (record_id,),
    )
    test_controller.db_manager.conn.commit()

    with freeze_at("2026-03-19 11:37:00"):
        title, lines = test_controller.get_record_repetitions(record_id, limit=3)

    assert title == "Repetitions for maintenance"
    assert lines[0] == "Next 3 occurrence(s):"
    assert lines[1] == f"  • {test_controller.fmt_user_date_only(date(2026, 3, 20))}"
    assert lines[2] == f"  • {test_controller.fmt_user_date_only(date(2026, 3, 21))}"
    assert lines[3] == f"  • {test_controller.fmt_user_date_only(date(2026, 3, 22))}"


def test_repetitions_midnight_with_extent_keep_time(
    test_controller, item_factory, freeze_at
):
    item = item_factory(
        "* midnight event @s 2026-03-20 00:00 @e 1h @r d &u 2026-03-22",
        final=True,
    )
    record_id = test_controller.add_item(item)

    test_controller.db_manager.cursor.execute(
        "DELETE FROM DateTimes WHERE record_id = ?",
        (record_id,),
    )
    test_controller.db_manager.conn.commit()

    with freeze_at("2026-03-19 11:37:00"):
        title, lines = test_controller.get_record_repetitions(record_id, limit=3)

    assert title == "Repetitions for midnight event"
    assert lines[0] == "Next 3 occurrence(s):"
    assert "00:00" in lines[1] or "12:00" in lines[1]
    assert lines[1] != f"  • {test_controller.fmt_user_date_only(date(2026, 3, 20))}"
    assert test_controller.fmt_user_date_only(
        date(2026, 3, 20)
    ) != test_controller.fmt_user(datetime(2026, 3, 20, 0, 0))


def test_urgency_age_uses_created_while_recent_uses_modified(isolated_env, freeze_at):
    urgency = UrgencyComputer(isolated_env)

    with freeze_at("2025-01-11 12:00:00"):
        now_seconds = int(datetime.now().timestamp())
        created_seconds = int(datetime(2025, 1, 1, 12, 0, 0).timestamp())
        modified_seconds = int(datetime(2025, 1, 10, 12, 0, 0).timestamp())

        age = urgency.urgency_age(created_seconds, now_seconds)
        recent = urgency.urgency_recent(modified_seconds, now_seconds)

        assert age == urgency.urgency_age(created_seconds, now_seconds)
        assert recent == urgency.urgency_recent(modified_seconds, now_seconds)
        assert age != urgency.urgency_age(modified_seconds, now_seconds)
        assert recent != urgency.urgency_recent(created_seconds, now_seconds)

        _, _, weights = urgency.from_args_and_weights(
            now=now_seconds,
            created=created_seconds,
            modified=modified_seconds,
            due=None,
            extent=0,
            priority_level=0,
            description=False,
            jobs=False,
            pinned=False,
        )

    assert weights["age"] == age
    assert weights["recent"] == recent
    assert weights["age"] != urgency.urgency_age(modified_seconds, now_seconds)
    assert weights["recent"] != urgency.urgency_recent(created_seconds, now_seconds)


def test_undefined_alert_command_fails_parse(item_factory):
    item = item_factory(
        "~ alert warning example @s 2026-03-20 9:00 @a 0m: x", final=True
    )

    assert not item.parse_ok
    assert "Undefined alert command: x" in item.parse_message
    assert "0m: x" not in item.alerts
