import subprocess
import sys
import json
import os
import platform
import hashlib
import tarfile
import zipfile
import shutil
import urllib.request

# ألوان الترمينال
class Colors:
    RED = '\033[91m'
    ORANGE = '\033[93m'
    YELLOW = '\033[93m'
    GREEN = '\033[92m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    END = '\033[0m'

def print_colored(text, color):
    print(f"{color}{text}{Colors.END}")

def calculate_score(vulns):
    score = 100
    for v in vulns:
        sev = v.get("severity", "").upper()
        if sev == "CRITICAL":
            score -= 10
        elif sev == "HIGH":
            score -= 5
        elif sev == "MEDIUM":
            score -= 2
        elif sev == "LOW":
            score -= 1
    return max(0, min(100, score))

def get_or_download_trivy():
    home_dir = os.path.expanduser("~/.dockeriq")
    bin_dir = os.path.join(home_dir, "bin")
    trivy_exe = "trivy.exe" if platform.system() == "Windows" else "trivy"
    trivy_path = os.path.join(bin_dir, trivy_exe)

    if os.path.exists(trivy_path):
        return trivy_path

    os.makedirs(bin_dir, exist_ok=True)
    print_colored("[+] DockerIQ: Downloading vulnerability scanner (one-time only)...", Colors.CYAN)

    system = platform.system().lower()
    arch = platform.machine().lower()

    # تحديد نظام التشغيل
    if system == "darwin":
        os_name = "macOS"
    elif system == "windows":
        os_name = "Windows"
    else:
        os_name = "Linux"

    # تحديد البنية
    if arch in ("x86_64", "amd64"):
        arch_name = "64bit"
    elif arch in ("aarch64", "arm64"):
        arch_name = "ARM64"
    elif arch in ("armv7l", "armv7"):
        arch_name = "ARM"
    else:
        print_colored(f"❌ Unsupported architecture: {arch}", Colors.RED)
        sys.exit(1)

    version = "0.69.3"
    ext = "zip" if system == "windows" else "tar.gz"
    # Trivy يستخدم '-' بين OS و arch، مش '_'
    tarball_name = f"trivy_{version}_{os_name}-{arch_name}.{ext}"
    url = f"https://github.com/aquasecurity/trivy/releases/download/v{version}/{tarball_name}"

    try:
        tmp_file = os.path.join(bin_dir, tarball_name)
        urllib.request.urlretrieve(url, tmp_file)

        if ext == "zip":
            with zipfile.ZipFile(tmp_file, 'r') as zip_ref:
                zip_ref.extractall(bin_dir)
        else:
            with tarfile.open(tmp_file, 'r:gz') as tar_ref:
                tar_ref.extractall(bin_dir)

        # تحديد مكان الملف التنفيذي بعد الفك
        candidate_paths = [
            os.path.join(bin_dir, trivy_exe),
            os.path.join(bin_dir, f"trivy_{version}_{os_name}_{arch_name}", trivy_exe),
        ]
        found = False
        for src in candidate_paths:
            if os.path.exists(src):
                shutil.move(src, trivy_path)
                found = True
                break

        if not found:
            print_colored("❌ Failed to locate Trivy binary after extraction.", Colors.RED)
            sys.exit(1)

        if system != "windows":
            os.chmod(trivy_path, 0o755)

        os.remove(tmp_file)
        return trivy_path

    except Exception as e:
        print_colored(f"❌ Failed to download or extract Trivy: {e}", Colors.RED)
        print("👉 Please install Trivy manually from: https://github.com/aquasecurity/trivy")
        sys.exit(1)

def scan_image(image_name):
    print_colored(f"\n[+] DockerIQ: Scanning image '{image_name}'...", Colors.CYAN)

    trivy_path = get_or_download_trivy()

    # أولًا: نزّل قاعدة البيانات (عشان ميطبعش "Downloading DB..." في stdout)
    try:
        subprocess.run([
            trivy_path, "image", "--download-db-only", "--quiet"
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
    except Exception:
        pass  # لو فشل، Trivy هيتعامل معاه لاحقًا

    # ثانيًا: شغّل الفحص الحقيقي
    try:
        result = subprocess.run([
            trivy_path, "image",
            "--format", "json",
            "--no-progress",
            "--quiet",
            image_name
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    except Exception as e:
        print_colored(f"❌ Scan failed to start: {e}", Colors.RED)
        sys.exit(1)

    # Trivy يرجع exit code 1 لو لقى ثغرات — ده طبيعي
    if result.returncode not in (0, 1):
        print_colored(f"❌ Trivy error: {result.stderr.strip()}", Colors.RED)
        sys.exit(1)

    # تحقق من أن الإخراج مش فارغ
    if not result.stdout.strip():
        print_colored("❌ Empty response from scanner.", Colors.RED)
        sys.exit(1)

    # اقرأ الـ JSON
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        print_colored("❌ Invalid scan output (not valid JSON).", Colors.RED)
        sys.exit(1)

    # استخرج الثغرات
    vulns = []
    for res in data.get("Results", []):
        for v in res.get("Vulnerabilities", []):
            vulns.append({
                "pkg": v.get("PkgName", "unknown"),
                "id": v.get("VulnerabilityID", "N/A"),
                "severity": v.get("Severity", "UNKNOWN").upper(),
                "title": v.get("Title", "No title available")
            })

    # حساب الدرجة والعرض
    critical = [v for v in vulns if v["severity"] == "CRITICAL"]
    high = [v for v in vulns if v["severity"] == "HIGH"]
    medium = [v for v in vulns if v["severity"] == "MEDIUM"]
    low = [v for v in vulns if v["severity"] == "LOW"]
    total = len(vulns)
    score = calculate_score(vulns)

    if total == 0:
        print_colored("\n✅ DockerIQ: No vulnerabilities found!", Colors.GREEN)
        print_colored(f"🛡️  Security Score: {score}/100", Colors.BOLD)
    else:
        print_colored(f"\n🚨 DockerIQ: Found {total} vulnerabilities", Colors.RED)
        print_colored(f"🛡️  Security Score: {score}/100", Colors.BOLD)

        print(f"\n📊 Summary:")
        if critical:
            print_colored(f"   🔴 Critical: {len(critical)}", Colors.RED)
        if high:
            print_colored(f"   🟠 High: {len(high)}", Colors.ORANGE)
        if medium:
            print_colored(f"   🟡 Medium: {len(medium)}", Colors.YELLOW)
        if low:
            print_colored(f"   🟢 Low: {len(low)}", Colors.GREEN)

        print(f"\n🔍 Details (first 5):")
        for v in vulns[:5]:
            sev = v["severity"]
            icon = "🔴" if sev == "CRITICAL" else "🟠" if sev == "HIGH" else "🟡" if sev == "MEDIUM" else "🟢"
            color = Colors.RED if sev == "CRITICAL" else Colors.ORANGE if sev == "HIGH" else Colors.YELLOW if sev == "MEDIUM" else Colors.GREEN
            pkg = v["pkg"]
            vid = v["id"]
            title = v["title"][:80] + "..." if len(v["title"]) > 80 else v["title"]
            print_colored(f"   {icon} [{sev}] {vid} in `{pkg}`", color)
            print(f"      → {title}\n")   
def main():
    if len(sys.argv) != 3 or sys.argv[1] != "scan":
        print("Usage: dockeriq scan <image-name>")
        print("Example: dockeriq scan nginx:latest")
        sys.exit(1)

    image = sys.argv[2]
    scan_image(image)

if __name__ == "__main__":
    main()
