from setuptools import setup, find_packages

setup(
    name="dockeriq",
    version="0.2.4",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "dockeriq=dockeriq.cli:main",
        ],
    },
    python_requires=">=3.7",
    author="Your Team",
    description="Secure Docker images with automated vulnerability scanning",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourteam/dockeriq-cli",
)
