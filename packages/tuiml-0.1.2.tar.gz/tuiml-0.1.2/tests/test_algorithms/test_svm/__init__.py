"""Tests for svm algorithms."""
