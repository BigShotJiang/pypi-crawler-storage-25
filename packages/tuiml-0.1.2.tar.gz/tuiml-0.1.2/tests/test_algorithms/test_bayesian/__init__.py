"""Tests for bayesian algorithms."""
