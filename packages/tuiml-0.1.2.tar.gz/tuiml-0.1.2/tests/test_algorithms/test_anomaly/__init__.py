"""Tests for anomaly algorithms."""
