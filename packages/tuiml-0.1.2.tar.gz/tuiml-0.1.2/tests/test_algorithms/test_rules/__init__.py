"""Tests for rules algorithms."""
