"""Tests for associations algorithms."""
