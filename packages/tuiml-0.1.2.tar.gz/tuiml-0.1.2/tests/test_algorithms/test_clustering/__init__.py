"""Tests for clustering algorithms."""
