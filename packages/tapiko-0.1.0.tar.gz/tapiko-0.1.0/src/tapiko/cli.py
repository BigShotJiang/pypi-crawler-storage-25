from __future__ import annotations

import argparse
import os
import shutil
from typing import Optional

from .detector import EnvironmentKind, detect_environment
from .launcher import resolve_chromium_path


def _is_node_installed() -> bool:
    return shutil.which("node") is not None


def _find_playwright_browser_cache() -> bool:
    cache = os.path.expanduser("~/.cache/ms-playwright")
    return os.path.exists(cache)


def run_setup() -> int:
    env = detect_environment()
    chromium_path: Optional[str] = resolve_chromium_path(env)

    print(f"Environment: {env.kind.value}")

    if env.kind == EnvironmentKind.TERMUX_NATIVE:
        if chromium_path:
            print(f"Chromium detected at: {chromium_path}")
        else:
            print("Chromium not found.")
            print("Run: pkg install chromium nodejs-lts")
        if not _is_node_installed():
            print("Node.js is not installed.")
            print("Run: pkg install nodejs-lts")
        return 0

    if env.kind == EnvironmentKind.TERMUX_PROOT:
        if chromium_path:
            print(f"Chromium detected at: {chromium_path}")
        else:
            print("Chromium not found in common paths.")
            print("Install Chromium in your distro, or provide executable_path explicitly.")
        return 0

    if chromium_path:
        print(f"Chromium detected at: {chromium_path}")
        return 0

    if _find_playwright_browser_cache():
        print("Playwright browser cache detected.")
    else:
        print("Playwright browser cache not detected.")
        print("Run: playwright install chromium")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="tapiko", description="Tapiko CLI")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("setup", help="Detect environment and print setup guidance")

    args = parser.parse_args()

    if args.command == "setup":
        return run_setup()

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
