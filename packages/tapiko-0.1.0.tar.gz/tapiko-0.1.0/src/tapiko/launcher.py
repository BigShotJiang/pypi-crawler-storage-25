from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .detector import EnvironmentInfo, EnvironmentKind, detect_environment


class TapikoError(Exception):
    """User-friendly error for tapiko failures."""


@dataclass
class LaunchConfig:
    executable_path: Optional[str]
    args: List[str]


TERMUX_CANDIDATE_PATHS = [
    "/data/data/com.termux/files/usr/bin/chromium",
    "/data/data/com.termux/files/usr/bin/chromium-browser",
]


def resolve_chromium_path(env: EnvironmentInfo) -> Optional[str]:
    if env.kind == EnvironmentKind.NORMAL:
        return None

    candidates = list(TERMUX_CANDIDATE_PATHS)
    prefix = os.environ.get("PREFIX")
    if prefix:
        candidates.extend(
            [
                f"{prefix}/bin/chromium",
                f"{prefix}/bin/chromium-browser",
            ]
        )

    found = shutil.which("chromium") or shutil.which("chromium-browser")
    if found:
        candidates.insert(0, found)

    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            return candidate
    return None


def get_launch_config(env: Optional[EnvironmentInfo] = None) -> LaunchConfig:
    env_info = env or detect_environment()
    executable_path = resolve_chromium_path(env_info)
    args: List[str] = []

    if env_info.kind == EnvironmentKind.TERMUX_NATIVE:
        args.extend(["--no-sandbox", "--disable-gpu-sandbox"])

    if env_info.kind in {EnvironmentKind.TERMUX_NATIVE, EnvironmentKind.TERMUX_PROOT}:
        if not executable_path:
            raise TapikoError(
                "Chromium not found. Install it with: pkg install chromium"
            )

    return LaunchConfig(executable_path=executable_path, args=args)


def import_playwright_sync() -> Any:
    try:
        from playwright.sync_api import sync_playwright  # type: ignore

        return sync_playwright
    except Exception as exc:
        raise TapikoError("playwright is not installed. Run: pip install playwright") from exc


def import_playwright_async() -> Any:
    try:
        from playwright.async_api import async_playwright  # type: ignore

        return async_playwright
    except Exception as exc:
        raise TapikoError("playwright is not installed. Run: pip install playwright") from exc


def merge_launch_kwargs(base_kwargs: Dict[str, Any], config: LaunchConfig) -> Dict[str, Any]:
    kwargs = dict(base_kwargs)
    existing_args = list(kwargs.get("args", []))
    kwargs["args"] = [*existing_args, *config.args]

    if config.executable_path and "executable_path" not in kwargs:
        kwargs["executable_path"] = config.executable_path

    return kwargs
