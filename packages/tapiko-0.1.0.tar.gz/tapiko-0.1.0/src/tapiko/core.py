from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from .launcher import (
    TapikoError,
    get_launch_config,
    import_playwright_async,
    import_playwright_sync,
    merge_launch_kwargs,
)


@dataclass
class BrowserHandle:
    _browser: Any

    def new_page(self, *args: Any, **kwargs: Any) -> Any:
        return self._browser.new_page(*args, **kwargs)

    def close(self) -> None:
        self._browser.close()

    @property
    def raw(self) -> Any:
        return self._browser


@dataclass
class BrowserContextHandle:
    _context: Any

    def new_page(self, *args: Any, **kwargs: Any) -> Any:
        return self._context.new_page(*args, **kwargs)

    def close(self) -> None:
        self._context.close()

    @property
    def raw(self) -> Any:
        return self._context


class BrowserFacade:
    def __init__(self) -> None:
        self._pw_manager: Any = None
        self._playwright: Any = None

    def _ensure_started(self) -> Any:
        if self._playwright is None:
            sync_playwright = import_playwright_sync()
            self._pw_manager = sync_playwright()
            self._playwright = self._pw_manager.start()
        return self._playwright

    def launch(self, **kwargs: Any) -> BrowserHandle:
        playwright = self._ensure_started()
        config = get_launch_config()
        launch_kwargs: Dict[str, Any] = merge_launch_kwargs(kwargs, config)
        browser = playwright.chromium.launch(**launch_kwargs)
        return BrowserHandle(browser)

    def launch_persistent_context(self, user_data_dir: str, **kwargs: Any) -> BrowserContextHandle:
        playwright = self._ensure_started()
        config = get_launch_config()
        launch_kwargs: Dict[str, Any] = merge_launch_kwargs(kwargs, config)
        context = playwright.chromium.launch_persistent_context(user_data_dir, **launch_kwargs)
        return BrowserContextHandle(context)

    def close(self) -> None:
        if self._pw_manager is not None:
            self._pw_manager.stop()
            self._pw_manager = None
            self._playwright = None


class AsyncBrowserFacade:
    def __init__(self) -> None:
        self._pw_manager: Any = None
        self._playwright: Any = None

    async def _ensure_started(self) -> Any:
        if self._playwright is None:
            async_playwright = import_playwright_async()
            self._pw_manager = async_playwright()
            self._playwright = await self._pw_manager.start()
        return self._playwright

    async def launch(self, **kwargs: Any) -> Any:
        playwright = await self._ensure_started()
        config = get_launch_config()
        launch_kwargs = merge_launch_kwargs(kwargs, config)
        return await playwright.chromium.launch(**launch_kwargs)

    async def launch_persistent_context(self, user_data_dir: str, **kwargs: Any) -> Any:
        playwright = await self._ensure_started()
        config = get_launch_config()
        launch_kwargs = merge_launch_kwargs(kwargs, config)
        return await playwright.chromium.launch_persistent_context(user_data_dir, **launch_kwargs)

    async def close(self) -> None:
        if self._pw_manager is not None:
            await self._pw_manager.stop()
            self._pw_manager = None
            self._playwright = None


browser = BrowserFacade()
async_browser = AsyncBrowserFacade()

__all__ = [
    "TapikoError",
    "BrowserHandle",
    "BrowserContextHandle",
    "BrowserFacade",
    "AsyncBrowserFacade",
    "browser",
    "async_browser",
]
