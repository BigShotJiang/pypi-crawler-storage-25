from __future__ import annotations

import os
import platform
from dataclasses import dataclass
from enum import Enum


class EnvironmentKind(str, Enum):
    NORMAL = "normal"
    TERMUX_NATIVE = "termux_native"
    TERMUX_PROOT = "termux_proot"


@dataclass(frozen=True)
class EnvironmentInfo:
    kind: EnvironmentKind
    is_android: bool
    is_linux: bool
    is_arm64: bool


def detect_environment() -> EnvironmentInfo:
    system = platform.system().lower()
    machine = platform.machine().lower()
    is_linux = system == "linux"
    is_arm64 = machine in {"aarch64", "arm64"}

    termux_prefix = os.environ.get("PREFIX", "")
    termux_files = "/data/data/com.termux/files"
    in_termux = termux_prefix.startswith(termux_files)

    is_android = in_termux or "android" in platform.platform().lower()

    if in_termux:
        if _is_proot_environment():
            return EnvironmentInfo(EnvironmentKind.TERMUX_PROOT, is_android, is_linux, is_arm64)
        return EnvironmentInfo(EnvironmentKind.TERMUX_NATIVE, is_android, is_linux, is_arm64)

    return EnvironmentInfo(EnvironmentKind.NORMAL, is_android, is_linux, is_arm64)


def _is_proot_environment() -> bool:
    if os.environ.get("PROOT_TMP_DIR"):
        return True

    if os.environ.get("DISTRO_NAME") or os.environ.get("PROOT_DISTRO"):
        return True

    return os.path.exists("/etc/proot_version")
