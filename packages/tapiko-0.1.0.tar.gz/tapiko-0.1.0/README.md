# tapiko

Playwright-like browser automation for Python with automatic environment handling, including difficult setups like Termux and Termux + Proot.

`tapiko` keeps usage simple while handling Chromium path resolution and launch flags behind the scenes.

## Who this is for

- Developers who want Playwright-style browser automation from Python
- Termux users who want zero-config launch behavior
- Teams that need one API for desktop and Android-like environments

## Why tapiko

- Auto-detects runtime environment (`normal`, `termux_native`, `termux_proot`)
- Auto-resolves Chromium in common Termux locations
- Adds required Termux-native launch arguments automatically
- Shows clear, actionable error messages
- Uses minimal dependency strategy with `playwright` only (no separate browser install step for Termux)

## Install

```bash
pip install tapiko
```

## Quick start

### Basic usage

```python
from tapiko import browser

br = browser.launch(headless=True)
page = br.new_page()
page.goto("https://example.com")
print(page.title())
br.close()
browser.close()
```

### Persistent profile

```python
from tapiko import browser

ctx = browser.launch_persistent_context("./profile-data", headless=False)
page = ctx.new_page()
page.goto("https://example.com")
ctx.close()
browser.close()
```

### Async usage

```python
import asyncio
from tapiko.core import async_browser


async def main() -> None:
    br = await async_browser.launch(headless=True)
    page = await br.new_page()
    await page.goto("https://example.com")
    print(await page.title())
    await br.close()
    await async_browser.close()


asyncio.run(main())
```

## Environment behavior

`tapiko` selects launch behavior automatically.

- **Normal environment** (Windows/macOS/Linux): standard Playwright-core launch flow
- **Termux native**: Chromium lookup + auto args
  - `--no-sandbox`
  - `--disable-gpu-sandbox`
- **Termux + Proot**: Chromium lookup in common locations, with optional manual override via `executable_path`

## Setup helper

Run:

```bash
tapiko setup
```

This command:

- Detects your environment
- Checks Chromium availability
- Prints exact next-step commands

Examples of guidance:

- Termux missing dependencies: `Run: pkg install chromium nodejs-lts`
- Desktop runner missing browser cache: `Run: playwright install chromium`

## Termux troubleshooting

If launch fails in Termux, run:

```bash
pkg update
pkg install chromium nodejs-lts
python -m pip install --upgrade pip
python -m pip install playwright tapiko
tapiko setup
```

If needed, verify Chromium path:

```bash
which chromium
```

Then pass explicit path:

```python
from tapiko import browser

br = browser.launch(executable_path="/data/data/com.termux/files/usr/bin/chromium")
```

## Documentation (Diataxis)

- Tutorial: `docs/tutorials/first-run-on-termux.md`
- How-to: `docs/how-to/use-persistent-profile.md`
- Reference: `docs/reference/api.md`
- Explanation: `docs/explanation/why-tapiko.md`

## FAQ

### Do I need to install `playwright`?

Yes. `tapiko` uses Python Playwright APIs, so install `playwright`.

### Why is Node.js still needed in Termux?

Playwright runtime components require Node.js. Install it with:

```bash
pkg install nodejs-lts
```

### Is ARM64 Android supported?

Yes. ARM64 is a primary target for Termux usage.

### What errors should I expect for missing setup?

- `Chromium not found. Install it with: pkg install chromium`
- `playwright is not installed. Run: pip install playwright`

## Development

```bash
python -m pip install -e .[dev]
pytest
```

## CI and release automation

- `/.github/workflows/ci.yml`: test matrix for Python 3.8 to 3.12
- `/.github/workflows/publish-pypi.yml`: PyPI publish workflow with Trusted Publishing (OIDC)

Before release publishing works, configure PyPI Trusted Publisher for this repository.

## Manual publish (optional)

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine upload dist/*
```

## License

MIT
