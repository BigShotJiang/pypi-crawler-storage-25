from __future__ import annotations

from tapiko.detector import EnvironmentInfo, EnvironmentKind
from tapiko.launcher import TapikoError, get_launch_config, resolve_chromium_path


def test_resolve_chromium_path_from_prefix(monkeypatch):
    env = EnvironmentInfo(
        kind=EnvironmentKind.TERMUX_NATIVE,
        is_android=True,
        is_linux=True,
        is_arm64=True,
    )

    monkeypatch.setenv("PREFIX", "/data/data/com.termux/files/usr")
    monkeypatch.setattr("tapiko.launcher.shutil.which", lambda _: None)

    def fake_exists(path: str) -> bool:
        return path.endswith("/bin/chromium")

    monkeypatch.setattr("tapiko.launcher.os.path.exists", fake_exists)

    path = resolve_chromium_path(env)
    assert path == "/data/data/com.termux/files/usr/bin/chromium"


def test_get_launch_config_termux_adds_flags_and_requires_chromium(monkeypatch):
    env = EnvironmentInfo(
        kind=EnvironmentKind.TERMUX_NATIVE,
        is_android=True,
        is_linux=True,
        is_arm64=True,
    )

    monkeypatch.setattr("tapiko.launcher.resolve_chromium_path", lambda _: "/fake/chromium")

    config = get_launch_config(env)
    assert config.executable_path == "/fake/chromium"
    assert "--no-sandbox" in config.args
    assert "--disable-gpu-sandbox" in config.args


def test_get_launch_config_termux_errors_when_missing(monkeypatch):
    env = EnvironmentInfo(
        kind=EnvironmentKind.TERMUX_NATIVE,
        is_android=True,
        is_linux=True,
        is_arm64=True,
    )

    monkeypatch.setattr("tapiko.launcher.resolve_chromium_path", lambda _: None)

    try:
        get_launch_config(env)
        assert False, "Expected TapikoError"
    except TapikoError as exc:
        assert "Chromium not found" in str(exc)
