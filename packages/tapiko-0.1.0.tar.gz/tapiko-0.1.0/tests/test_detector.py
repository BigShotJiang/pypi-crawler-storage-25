from __future__ import annotations

from tapiko.detector import EnvironmentKind, detect_environment


def test_detect_termux_native(monkeypatch):
    monkeypatch.setenv("PREFIX", "/data/data/com.termux/files/usr")
    monkeypatch.delenv("PROOT_TMP_DIR", raising=False)
    monkeypatch.delenv("DISTRO_NAME", raising=False)

    env = detect_environment()
    assert env.kind == EnvironmentKind.TERMUX_NATIVE


def test_detect_termux_proot(monkeypatch):
    monkeypatch.setenv("PREFIX", "/data/data/com.termux/files/usr")
    monkeypatch.setenv("PROOT_TMP_DIR", "/tmp/proot")

    env = detect_environment()
    assert env.kind == EnvironmentKind.TERMUX_PROOT


def test_detect_normal(monkeypatch):
    monkeypatch.delenv("PREFIX", raising=False)
    monkeypatch.delenv("PROOT_TMP_DIR", raising=False)
    monkeypatch.delenv("DISTRO_NAME", raising=False)

    env = detect_environment()
    assert env.kind == EnvironmentKind.NORMAL
