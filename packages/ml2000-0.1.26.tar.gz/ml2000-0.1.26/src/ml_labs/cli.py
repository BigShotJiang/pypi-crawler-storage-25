import argparse
import sys
from .generator import print_requirements, interactive_menu

def main():
    parser = argparse.ArgumentParser(description="ML Labs Experiments Generator")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # requirements command
    req_parser = subparsers.add_parser("requirements", help="Print required packages")

    args = parser.parse_args()

    if args.command == "requirements":
        print_requirements()
    else:
        # If no arguments provided, run the interactive menu
        interactive_menu()

if __name__ == "__main__":
    main()
