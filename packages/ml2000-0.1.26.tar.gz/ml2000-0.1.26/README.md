# ML Labs Generator

This tool generates boilerplate code and datasets for standard Machine Learning experiments.

## Installation

```bash
pipx install .
```

## Usage

```bash
# Generate the experiments and datasets
ml-labs generate

# Print the required packages
ml-labs requirements
```
