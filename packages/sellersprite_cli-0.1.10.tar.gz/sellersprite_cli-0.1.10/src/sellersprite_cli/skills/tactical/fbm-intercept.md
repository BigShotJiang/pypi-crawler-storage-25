低品牌覆盖 FBM 高销量产品

> **分类**：六、机会捕捉型 | **难度**：⭐ | **适用阶段**：快速上新 / 低风险入场

---

## 核心逻辑

FBM 产品月销 300+ = **需求强劲到足以克服"无 Prime 标识"的信任损失**。
用 FBA 发同款就能靠 Prime 标识直接拦截需求。

## 触发场景

- "帮我找FBM发货但月销很高的产品"
- "我想用FBA优势去抢占FBM卖家的市场"
- "有没有配送慢但仍然卖得好的产品？"

## MCP 工具

`mcp__sellersprite__product_research`

## 参数配置

```json
{
  "marketplace": "US",
  "fulfillment": "FBM",
  "minUnits": 300,
  "variation": "Y",
  "order": {"field": "total_units", "desc": true},
  "size": 20
}
```

## 参数说明

| 参数 | 含义 | 建议值 | 调节指南 |
|------|------|--------|----------|
| `fulfillment` | 发货方式 | FBM | 核心筛选条件 |
| `minUnits` | 月最低销量 | ≥ 300 | 提高到 500 可筛选更刚需的产品 |
| `variation` | 排除变体 | Y | 避免同父体重复计算 |

## 结果解读要点

1. **FBM 月销 > 500**：说明产品极度刚需，消费者愿意忍受慢配送
2. **`sellers` = 1**：独家经营，竞争更低，FBA 入场优势更大
3. **关注配送时效**：FBM 通常 7~14 天，FBA 次日达优势极大
4. **交叉验证**：**并行调用** `mcp__sellersprite__asin_prediction`（该工具仅支持单个 ASIN 查询，不支持批量，需将所有候选 ASIN 的调用同时发起）确认销量趋势是否稳定

## 风险提示

- FBM 卖家可能随时转 FBA，窗口期有限，需尽快决策
- 部分 FBM 产品可能是品牌方控价渠道，跟卖需谨慎
- FBM 高销量可能伴随高退货率，需关注竞品评论中的物流投诉
- 务必核查产品是否存在品牌备案或专利保护

## 组合打法

本 SKILL 筛出候选 ASIN 后，建议串联：
1. → **高毛利轻小品**：轻小品 FBM = 头程低 + 拦截收益高
2. → **低质量Listing高销量**：Listing 质量差 + FBM 配送 = 双重竞争弱势
3. → **评论语义分析**：分析 FBM 竞品差评，找出物流和品质痛点
---

## 参考文档

本 Skill 涉及的 API 详细参数说明：

- [`asin_prediction`](../../reference/asin_prediction.md)
- [`product_research`](../../reference/product_research.md)
