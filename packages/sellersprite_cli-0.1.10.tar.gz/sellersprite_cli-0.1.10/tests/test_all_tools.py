#!/usr/bin/env python3
"""Test all 38 MCP tools — paginated ones with explicit page/size."""

import os
import sys
import traceback

os.environ["SELLERSPRITE_KEY"] = "25645c7346f74f51a478acc53754a93b"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from sellersprite_cli.registry import TOOLS
from sellersprite_cli.cli import _call_tool

MARKETPLACE = "US"
TEST_ASIN = "B07Z82895W"
TEST_KEYWORD = "wireless earbuds"
TEST_CATEGORY_ID = "172282"
TEST_NODE_PATH = "2619525011"

# Tool-specific base params (snake_case to match method signatures)
TEST_PARAMS = {
    # ASIN (non-paginated)
    "asin_detail": {"asin": TEST_ASIN},
    "asin_prediction": {"asin": TEST_ASIN},
    "asin_coupon_trend": {"asin": TEST_ASIN},
    "asin_detail_with_coupon_trend": {"asin": TEST_ASIN},
    "keepa_info": {"asin": TEST_ASIN},
    # Product
    "product_research": {"keyword": TEST_KEYWORD},
    "competitor_lookup": {"asins": [TEST_ASIN]},
    "product_node": {"keyword": "electronics"},
    # Keyword
    "keyword_miner": {"keyword": TEST_KEYWORD},
    "keyword_research": {"keywords": TEST_KEYWORD},
    "keyword_research_trends": {"keyword": TEST_KEYWORD},
    "keyword_order": {"asins": [TEST_ASIN], "reverse_type": "M", "date": "202604"},
    "bsr_prediction": {"bsr": 10000, "category_id": TEST_CATEGORY_ID},
    # Traffic
    "traffic_keyword": {"asin": TEST_ASIN},
    "traffic_keyword_stat": {"asin": TEST_ASIN},
    "traffic_source": {"q": TEST_ASIN, "month": "202604"},
    "traffic_listing_stat": {"asin": TEST_ASIN},
    "traffic_listing": {"asin_list": [TEST_ASIN], "relations": ["also_viewed"]},
    "traffic_extend": {"asin_list": [TEST_ASIN], "query_type": 2},
    # Market
    "market_research": {"keyword": "electronics"},
    "market_research_statistics": {"node_id_path": TEST_NODE_PATH},
    "market_price_distribution": {"node_id_path": TEST_NODE_PATH},
    "market_brand_concentration": {"node_id_path": TEST_NODE_PATH},
    "market_product_concentration": {"node_id_path": TEST_NODE_PATH},
    "market_seller_concentration": {"node_id_path": TEST_NODE_PATH},
    "market_rating_distribution": {"node_id_path": TEST_NODE_PATH},
    "market_ratings_count_distribution": {"node_id_path": TEST_NODE_PATH},
    "market_listing_date_distribution": {"node_id_path": TEST_NODE_PATH},
    "market_listing_trend_distribution": {"node_id_path": TEST_NODE_PATH},
    "market_seller_country_distribution": {"node_id_path": TEST_NODE_PATH},
    "market_seller_type_concentration": {"node_id_path": TEST_NODE_PATH},
    "market_ebc_distribution": {"node_id_path": TEST_NODE_PATH},
    "market_product_demand_trend": {"node_id_path": TEST_NODE_PATH},
    # Trend
    "aba_research_weekly": {"keyword_list": [TEST_KEYWORD]},
    "aba_research_monthly": {"keyword_list": [TEST_KEYWORD]},
    "aba_research_trend": {"keyword": TEST_KEYWORD},
    "google_trend": {"keyword": TEST_KEYWORD},
    "review": {"asin": TEST_ASIN, "category_id": TEST_CATEGORY_ID},
}


def run_test():
    ok = []
    fail = []

    for tool_name, meta in TOOLS.items():
        params = dict(TEST_PARAMS.get(tool_name, {}))
        paginated = meta.paginated

        # For paginated tools, add explicit page/size to verify injection works
        if paginated:
            params["page"] = 1
            params["size"] = 3  # small size for speed

        label = meta.label
        try:
            result = _call_tool(tool_name, None, MARKETPLACE, **params)
            status = "OK"

            # Summarize result
            info = ""
            if isinstance(result, dict):
                if "items" in result:
                    items = result.get("items", [])
                    info = f"items={len(items)}"
                elif "data" in result:
                    d = result.get("data")
                    info = f"data={len(d) if isinstance(d, list) else 'dict'}"
                elif "total" in result:
                    info = f"total={result.get('total')}"
                else:
                    info = f"keys={list(result.keys())[:3]}"
            elif isinstance(result, list):
                info = f"list={len(result)}"
            else:
                info = f"type={type(result).__name__}"

            ok.append((tool_name, label, paginated, info))
        except Exception as e:
            err = str(e)
            if len(err) > 120:
                err = err[:120] + "..."
            fail.append((tool_name, label, paginated, err))

    # Print results
    print("=" * 90)
    print(f"{'Tool':<35} {'Label':<22} {'Paginated':<10} {'Status':<6} Details")
    print("-" * 90)

    for tool_name, label, paginated, info in ok:
        pflag = "Y" if paginated else "N"
        print(f"{tool_name:<35} {label:<22} {pflag:<10} {'OK':<6} {info}")

    for tool_name, label, paginated, err in fail:
        pflag = "Y" if paginated else "N"
        print(f"{tool_name:<35} {label:<22} {pflag:<10} {'FAIL':<6} {err}")

    print("=" * 90)
    print(f"Total: {len(TOOLS)} | OK: {len(ok)} | FAIL: {len(fail)}")

    if fail:
        print("\n--- FAILED DETAILS ---")
        for tool_name, label, paginated, err in fail:
            print(f"\n[{tool_name}] {label} (paginated={paginated})")
            print(f"  Error: {err}")
        sys.exit(1)
    else:
        print("\nAll tests passed!")


if __name__ == "__main__":
    run_test()
