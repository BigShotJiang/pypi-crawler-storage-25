# WPCVPN

`wpcvpn` is a small macOS CLI package that installs the `wpc` command. It switches Cloudflare WARP into full-device mode and keeps the tunnel connected for the whole computer.

## Install

```bash
pip install wpcvpn
```

## Use

```bash
wpc
```

The command will:

- find or install Cloudflare WARP
- register the device if needed
- switch WARP into full-device mode
- connect the tunnel and keep it active until you stop it

Press `Ctrl+C` to disconnect.
