#!/usr/bin/env python3
import atexit
import os
import shutil
import signal
import subprocess
import sys
import threading
import time

__version__ = "6.0.0"
_PKG = "wpc"
WARP_MODES = ("warp", "warp+doh")

R = "\033[0m"
B = "\033[1m"
DIM = "\033[2m"
RED = "\033[91m"
GRN = "\033[92m"
YLW = "\033[93m"
CYN = "\033[96m"

BANNER = f"""{CYN}{B}
╔════════════════════════════════════════════════════╗
║ WPC                                                ║
║ Full-device Cloudflare WARP tunnel for this Mac    ║
╚════════════════════════════════════════════════════╝{R}
"""


def _status(icon, color, message):
    print(f"  {color}{icon}{R} {message}")


def _clear():
    os.system("clear" if os.name != "nt" else "cls")


def _spinner(message, done_event, success_flag):
    frames = ["|", "/", "-", "\\"]
    i = 0
    while not done_event.is_set():
        print(f"\r  {CYN}{frames[i % len(frames)]}{R} {message}", end="", flush=True)
        time.sleep(0.1)
        i += 1
    marker = f"{GRN}✓{R}" if success_flag[0] else f"{RED}✗{R}"
    print(f"\r  {marker} {message}{' ' * 6}")


def _with_spinner(message, fn):
    done = threading.Event()
    success = [False]
    thread = threading.Thread(target=_spinner, args=(message, done, success), daemon=True)
    thread.start()
    try:
        result = fn()
        success[0] = True
        return result
    finally:
        done.set()
        thread.join()


def _run(cli, *args, check=True):
    result = subprocess.run(
        [cli, "--accept-tos", *args],
        capture_output=True,
        text=True,
    )
    if check and result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "warp-cli failed")
    return result


def _find_warp():
    cli = shutil.which("warp-cli")
    if cli:
        return cli
    app_cli = "/Applications/Cloudflare WARP.app/Contents/Resources/warp-cli"
    if os.path.exists(app_cli):
        return app_cli
    return None


def _install_warp():
    brew = shutil.which("brew")
    if not brew:
        raise RuntimeError("Homebrew is not installed. Install it from https://brew.sh first.")
    _with_spinner("Installing Cloudflare WARP...", lambda: _install_with_brew(brew))
    cli = _find_warp()
    if not cli:
        raise RuntimeError("WARP installed, but warp-cli was not found.")
    return cli


def _install_with_brew(brew):
    result = subprocess.run(
        [brew, "install", "--cask", "cloudflare-warp"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "brew install failed")
    return True


def _ensure_registration(cli):
    status = _run(cli, "status", check=False)
    text = f"{status.stdout}\n{status.stderr}".lower()
    if "registration missing" not in text and status.returncode == 0:
        return

    def _register():
        result = _run(cli, "registration", "new", check=False)
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "registration failed")
        return True

    _with_spinner("Registering this Mac with Cloudflare...", _register)


def _set_full_device_mode(cli):
    for mode in WARP_MODES:
        result = _run(cli, "mode", mode, check=False)
        if result.returncode == 0:
            return mode
    raise RuntimeError("Could not switch WARP into full-device mode.")


def _wait_for_connection(cli, timeout=30):
    for _ in range(timeout):
        status = _run(cli, "status", check=False)
        text = f"{status.stdout}\n{status.stderr}".lower()
        if "connected" in text:
            return status.stdout.strip() or "Connected"
        time.sleep(1)
    raise RuntimeError("Timed out waiting for WARP to connect.")


def _disconnect(cli):
    _run(cli, "disconnect", check=False)


def main():
    _clear()
    print(BANNER)
    _status("✓", GRN, f"{_PKG} v{__version__}")

    cli = _find_warp()
    if not cli:
        _status("→", YLW, "Cloudflare WARP is not installed.")
        cli = _install_warp()
    else:
        _status("✓", GRN, "Cloudflare WARP found")

    _ensure_registration(cli)
    mode = _set_full_device_mode(cli)
    _status("✓", GRN, f"Full-device mode selected: {mode}")

    _with_spinner("Connecting full-device tunnel...", lambda: _run(cli, "connect"))
    summary = _wait_for_connection(cli)
    atexit.register(_disconnect, cli)

    print()
    _status("✓", GRN, "WARP is connected for the whole computer")
    print(f"  {DIM}{summary}{R}")
    print(f"  {DIM}Press Ctrl+C to disconnect.{R}")

    def _exit(sig=None, frame=None):
        _disconnect(cli)
        print(f"\n  {CYN}Disconnected WARP.{R}")
        sys.exit(0)

    signal.signal(signal.SIGINT, _exit)
    signal.signal(signal.SIGTERM, _exit)

    while True:
        time.sleep(1)
