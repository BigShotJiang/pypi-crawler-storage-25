from wpc import main

main()
