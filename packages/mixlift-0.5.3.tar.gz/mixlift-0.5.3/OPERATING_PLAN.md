# MixLift Operating Plan

**Chief of Staff Directive | March 7, 2026 | Supersedes STRATEGY.md Sprint Plan**

This document is the single source of truth for MixLift operations from March 7 through Day 90. All leadership team members operate from this plan. Conflicts have been resolved. Decisions are final unless new customer data forces a revisit.

---

## 1. Executive Summary

**Where we are:** MixLift shipped and was verified end-to-end on March 7, 2026. v0.2.0 is on PyPI. Stripe is processing payments. The License API is live at api.mixlift.io. A stranger can install, pay, and run an analysis today. Zero customers.

**What changed since STRATEGY.md was written (March 5):** The codebase leapt ahead of the strategy document. A codebase audit confirms the following items listed as "TODO" in STRATEGY.md are ALREADY SHIPPED:

| Item | STRATEGY.md Said | Actual Status |
|---|---|---|
| Holiday controls | "Ship Week 5" | SHIPPED in `preprocessing.py` (auto-detect US holidays via `holidays` package) |
| Headless API license gate | "Ship Week 4" | SHIPPED in `api.py` (validates license, enforces tier limits, redacts dollars) |
| Free tier metering | "Local counter Week 4-5" | SHIPPED in `metering.py` (2 runs/month, monthly reset) |
| Contextual memory | "Ship Week 7-8" | SHIPPED in `memory.py` + integrated into `server.py` (fingerprinting, deltas, CI overlap heuristic) |
| Posterior predictive | "Add to fit_model()" | SHIPPED in `engine.py:127` (`sample_posterior_predictive`) |
| 4-chain MCMC config | "Update Week 4" | SHIPPED in `defaults.py` (4 chains x 250 draws, target_accept=0.90) |
| Tier naming fix | "30-minute fix" | SHIPPED in `api.py:90` (accepts both "pro" and "growth") |

**Net assessment:** The codebase is at Week 7-8 maturity on a Week 4 calendar. The product is more ready to sell than anyone on this team realized two days ago. The constraint is no longer code -- it is customers.

**The one thing that matters most right now:** Start selling. Every day without outreach is a day wasted. The product is good enough. It will never be perfect. Ship the demo, hit LinkedIn, book calls.

---

## 2. Resolved Conflicts

### Conflict 1: Fix quality gaps THEN sell vs. Start outreach NOW

**Ruling: Start outreach NOW. Quality work runs in parallel, not as a gate.**

The Strategist recommended fixing 3 demo-killing gaps before outreach. Two of those three (model fit metrics empty, holiday controls missing) are already shipped. The third (free tier dollar leak) is a monetization hygiene issue, not a demo killer -- no prospect evaluating MixLift on their own data in a live demo will notice JSON field redaction.

Marketing and Sales are correct: time-to-first-paying-customer is the existential risk. Outreach begins March 10 (Monday). Engineering hardening runs concurrently. If a demo-killing bug surfaces during a live call, we fix it that day. That is the concierge model working as designed.

### Conflict 2: Zero new features for 30 days (EM) vs. Sample dataset + report export + data hardening (PM)

**Ruling: The PM's "sample dataset + guided first-run" ships. Report export waits. The EM is right on everything else.**

The PM correctly identifies that "I don't have my data ready" is the #1 conversion blocker. A sample dataset with a guided first-run experience is not a feature -- it is sales infrastructure. It ships Week 1-2.

Report export (PDF/HTML) is a real feature with real scope. It waits until we have paying customers asking for it. Data hardening (messy CSV handling) ships opportunistically as we encounter real customer CSVs during concierge demos -- not as a planned sprint item.

The EM's core directive -- harden, don't build -- governs all other engineering decisions. No new modeling features. No new analysis modes. No architectural changes. Monitoring, fail-closed licensing, and integration tests are the engineering priorities.

### Conflict 3: LOO-CV and uncertainty propagation (DS Manager) vs. Harden, don't build (EM)

**Ruling: LOO-CV ships in Week 3-4. Uncertainty propagation in the budget optimizer waits.**

The DS Manager is right that LOO-CV transforms model credibility from "trust us" to "here's the math." This is a 2-day implementation using ArviZ (already a dependency). It directly supports the Sales Lead's demo structure where the prospect needs to trust the numbers. LOO-CV is hardening, not a new feature -- it validates existing output.

Uncertainty propagation through the budget optimizer is a real modeling change. It waits until customer feedback demands it. The current point-estimate optimizer with posterior means is good enough for the first 5 customers, especially when paired with confidence intervals on ROAS and scenario mode.

### Conflict 4: When exactly does outreach begin?

**Ruling: March 10, 2026 (Monday). Non-negotiable.**

The Strategist said "by March 15 at latest." Marketing said "5 demos in first 10 days." Sales said "300 outreach messages over 6 weeks." All of these are compatible with a March 10 start. The 90-second Loom demo and LinkedIn prospect list are the only prerequisites, and both can be completed over the weekend (March 8-9).

---

## 3. The 30-Day Plan

*Revised March 15, 2026. Original plan assumed LinkedIn cold DMs as primary channel. Founder assessed this as network spam — not a viable channel. Revised GTM uses inbound-first approach: paid search (high-intent), content marketing, community engagement, warm intros. Cold outbound is removed entirely.*

### Week 1 (March 8-14): ACTUAL RESULTS

*Recorded for posterity. Week 1 deviated from original plan but produced useful assets.*

**What shipped:**
- v0.3.0 released: LOO-CV, fail-closed licensing, `mixlift_prepare` tool (ahead of schedule)
- Google Ads infrastructure: thank-you page, GA4 instrumentation, conversion tracking with real AW ID
- Landing page variants: `/compare/`, `/fix-wasted-spend/`
- Sample dataset + first-run guide (partial, in v0.3.0 GTM docs)

**What did not ship:**
- Loom demo video
- UptimeRobot monitoring
- Any customer-facing outreach or demos
- Track B infrastructure hardening (B1-B6 unconfirmed)

### Week 2 (March 15-21): "LIGHT THE CHANNELS"

Three parallel tracks. Content and ads generate inbound. Engineering stabilizes.

**Track A: Content + Inbound (Owner: Founder)**

| # | Deliverable | Due | Definition of Done |
|---|---|---|---|
| A1 | Record Loom demo video (3-5 min) | Mar 16 (Sun) | Shows: CSV drop into Claude, model runs, dollar headline, saturation lights, scenario mode. Posted to LinkedIn + embedded on landing page. |
| A2 | Launch Google Ads Campaign 1 only ("MMM Tools" high-intent) | Mar 17 (Mon) | Billing confirmed, campaign built in Ads UI, GA4↔Ads linked. **Budget cap: $17/day ($500/mo).** Test period: 14 days. Kill if CPA > $300 after 14 days. |
| A3 | LinkedIn post: teardown of sample data analysis | Mar 17 (Mon) | Educational content post (NOT a DM). Show real MixLift output on anonymized data. Dollar headline, saturation findings, budget reallocation. Soft CTA: "Want me to run this on your data? Link in comments." |
| A4 | Reddit teardown post on r/PPC or r/dtc | Mar 19 (Wed) | Run MixLift on anonymized data, post results with commentary. Link to landing page in comments, not post body. Follow subreddit rules — lead with value, not promotion. |
| A5 | Submit MCP marketplace listing | Mar 18 (Tue) | MixLift listed with description, install command, screenshots. One-time effort. |
| A6 | Create "Day 0 case study" from sample data | Mar 19 (Wed) | Anonymized but realistic. Shows dollar headline, saturation insights, budget reallocation. Published on landing page. |
| A7 | Ask 5 people in network for warm intros | Mar 21 (Fri) | Not cold outreach — ask existing contacts: "Do you know any DTC brand marketers frustrated with ad attribution?" One warm intro is worth 20 cold DMs. |

**Track B: Infrastructure (Owner: Engineering)**

| # | Deliverable | Due | Definition of Done |
|---|---|---|---|
| B1 | UptimeRobot monitoring for api.mixlift.io | Mar 15 (today) | Health check pinging `/health` every 5 minutes. Alerts to Founder's phone on downtime. 10-minute task. |
| B2 | Verify Render disk persistence for SQLite | Mar 17 (Mon) | Confirm SQLite DB survives Render redeploy. If not, implement backup or switch to Postgres. Document either way. |
| B3 | Confirm `last_validated_at` is deployed | Mar 17 (Mon) | Updated on every `/v1/license/validate` call. Required for passive churn detection. |
| B4 | Update STRATEGY.md and PROJECT_STATUS.md | Mar 19 (Wed) | Mark shipped items as shipped. Remove "BLOCKED" from items that are live. These docs are stale. |

**Track C: Code Freeze**

No new features this week. Engineering work limited to Track B items and any demo-blocking bugs. v0.3.0 is the product for demos. LOO-CV and fail-closed licensing already shipped.

### Week 3 (March 22-28): "DEMO AND CLOSE"

**Track A: Sales + Content (Owner: Founder)**

| # | Deliverable | Due | Definition of Done |
|---|---|---|---|
| A8 | Complete 3+ live demos | Mar 28 | From any source: ads, content inbound, warm intros, MCP marketplace. Track: source / showed up / ran on their data / objections / outcome. |
| A9 | Second LinkedIn content post | Mar 24 (Mon) | Different angle: "5 Signs Your Ad Budget Has a Leak" carousel or video. Build on engagement from Week 2 post. |
| A10 | Second Reddit post (different subreddit or angle) | Mar 26 (Wed) | If r/PPC worked, try r/dtc or r/ecommerce. If it didn't, adjust angle. |
| A11 | Close first paying customer | Mar 28 | $299 collected via Stripe. License key issued. Customer running MixLift independently. |
| A12 | Begin onboarding playbook for first customer | Immediately on close | Day 0: Do MCP setup FOR them. Day 1-3: Check-in call. |
| A13 | Evaluate Google Ads Campaign 1 performance | Mar 28 | Review CPA, CTR, conversion rate. If CPA < $200: add Campaign 2 (Competitor Conquest) at $500/mo. If CPA > $300: pause and diagnose. |

**Track B: Engineering (Owner: Engineering)**

| # | Deliverable | Due | Definition of Done |
|---|---|---|---|
| B5 | Strip raw saturation curves from MCP output | Mar 26 | Keep traffic lights. Remove the 100-point-per-channel data dump. Reduces token waste. |
| B6 | Fix any bugs surfaced during demos | Rolling | Same-day turnaround on demo-killing issues. |

### Week 4 (March 29 - April 4): "COMPOUND"

**Track A: Sales + Content (Owner: Founder)**

| # | Deliverable | Due | Definition of Done |
|---|---|---|---|
| A14 | Complete 8+ total live demos | Apr 4 | |
| A15 | 3 paying customers | Apr 4 | |
| A16 | First customer Day 7 interpretation call | Per playbook | Scenario mode demo. Confirm independent usage. |
| A17 | Weekly LinkedIn content post | Apr 1 | Maintain cadence. Use learnings from Weeks 2-3 engagement. |
| A18 | Scale Google Ads if CPA < $200 | Apr 1 | Add Campaign 2 and/or increase Campaign 1 budget. Total ads spend capped at $1,500/mo until 3 customers exist. |

**Track B: Engineering (Owner: Engineering)**

| # | Deliverable | Due | Definition of Done |
|---|---|---|---|
| B7 | Data hardening based on real customer CSVs | Rolling | Fix whatever broke. Messy headers, date formats, currency symbols, encoding issues. |
| B8 | Intercept decomposition (baseline/organic revenue) | Apr 2 | Surface the model intercept as "organic/baseline revenue" in results. |

---

## 4. Strategic Decisions

### DECIDED

| # | Decision | Resolution | Rationale |
|---|---|---|---|
| 1 | **~~Outreach starts March 10~~ GTM channels go live March 17** | Revised March 15 | Original plan assumed LinkedIn cold DMs. Founder assessed as network spam. Replaced with inbound-first: Google Ads (high-intent, capped), content (LinkedIn posts, Reddit), warm intros, MCP marketplace. |
| 2 | **Demo target: 3/week from inbound** | Revised March 15 | Inbound channels have longer ramp than cold outreach. Expect 1-2 demos Week 2, 3+ Week 3 as content and ads generate pipeline. 15+ total demos by Day 45. |
| 3 | **Pricing stays at $299/mo** | No change until 15+ customers | Sales Lead is right: first 10 customers are case studies. $299 is intentionally low. Raise to $799 Pro tier after 15-20 customers + 3 published case studies. |
| 4 | **No annual pricing until Week 8-10** | Finance recommendation adopted | Annual ($2,690/yr, 25% discount) becomes a closing tool only after we understand retention. Offering annual too early masks churn signal. |
| 5 | **LOO-CV ships Week 3** | DS Manager + EM compromise | LOO-CV is validation of existing output, not a new feature. 2-day effort. Transforms "trust us" into "here's the out-of-sample score." |
| 6 | **Report export deferred** | PM accepts deferral | No customer has asked for it yet. Build it the week a prospect says "I need to share this with my boss" and doesn't close. |
| 7 | **Zero new modeling features for 30 days** | EM directive stands | No time-varying coefficients. No cross-channel interactions. No new adstock specs. Customer feedback drives the next modeling sprint. |
| 8 | **Sample dataset ships Week 1** | PM priority, EM-approved scope | Not a feature. Sales infrastructure. Realistic 8-channel CSV + 1-page guide. |
| 9 | **Fail-closed licensing ships Week 2** | EM + Strategy aligned | Current fail-open behavior is a revenue leak. 24hr cached grace period prevents locking out paid users during outages. |
| 10 | **STRATEGY.md gets updated Week 2** | Overdue | The strategy document says License API is "NOT YET LIVE" and PyPI is "BLOCKED." Both shipped. Stale docs cause bad decisions. |
| 11 | **Kill the 12-month $75K MRR projection** | Strategist recommendation adopted | It is a fantasy number. The only projection that matters: 5 customers by Day 45. Everything beyond that is earned with data, not spreadsheets. |
| 12 | **Memory fingerprinting stays as-is** | EM flagged fragility, but not worth fixing now | Yes, renaming a CSV breaks the fingerprint. This is acceptable for first 5 customers who will use consistent filenames. Revisit if customer complaints surface. |

### WAITS FOR DATA

| # | Decision | Trigger | What We'll Learn |
|---|---|---|---|
| 1 | **Pro tier launch ($799/mo)** | 15+ customers + 3 case studies | Whether there's demand for higher limits and priority support. |
| 2 | **Report export (PDF/HTML)** | First prospect who doesn't close because they can't share results | Whether the buyer vs. decision-maker gap is real. |
| 3 | **Automated monthly refresh with delta reporting** | First customer approaching Day 30 renewal | Whether memory deltas are compelling enough to drive retention. |
| 4 | **Uncertainty propagation in budget optimizer** | Customer questions the optimization recommendations | Whether point estimates are "good enough" or eroding trust. |
| 5 | **Agency tier / multi-client** | Inbound agency interest | Whether agencies are a viable channel before Week 9. |
| 6 | **Annual pricing** | Week 8-10, after observing first renewal cohort | Whether retention supports locking in annual commitments. |
| 7 | **Kill or pivot** | Day 90: <10 paying + >15% churn | Whether the product has market fit. |

---

## 5. Metrics Dashboard

### Weekly Dashboard (Every Monday, starting March 22)

| Metric | Week 1 (actual) | Week 2 | Week 3 | Week 4 | Day 45 Target |
|---|---|---|---|---|---|
| Content pieces published | 0 | 3 | 2 | 1 | 8+ |
| Google Ads impressions | 0 | Track | Track | Track | Track |
| Google Ads CPA | N/A | Measuring | Measuring | <$200 | <$150 |
| Google Ads spend | $0 | ~$120 | ~$250 | ~$500 | <$1,500/mo |
| Inbound demo requests | 0 | 1-2 | 3+ | 3+ | 15+ total |
| Live demos completed | 0 | 1-2 | 3+ | 8+ | 15+ |
| Demo-to-close rate | N/A | Measuring | Measuring | Measuring | 25%+ |
| Paying customers | 0 | 0 | 1 | 3 | 5 |
| MRR | $0 | $0 | $299 | $897 | $1,495 |
| Cash collected | $0 | $0 | $299 | $897 | $1,495 |
| Infra + ads cost (monthly) | ~$15 | ~$530 | ~$530 | ~$530 | <$1,550 |
| api.mixlift.io uptime | Unknown | 99%+ | 99%+ | 99%+ | 99.5%+ |
| Bugs found in demos | N/A | Track | Track | Track | <1/demo |

### Monthly Dashboard (Starting Day 30)

| Metric | Day 30 | Day 60 | Day 90 |
|---|---|---|---|
| Paying customers | 3-5 | 8-12 | 15-25 |
| MRR | $897-$1,495 | $2,392-$3,588 | $4,485-$7,475 |
| Monthly logo churn | N/A (no renewals yet) | Measuring | <10% |
| Month 2 retention (first 5) | N/A | N/A | TARGET: 80%+ |
| Gross margin | 95%+ | 95%+ | 95%+ |
| Customer using memory/deltas | N/A | Track | 50%+ |

### Trigger-Based Actions

| Signal | Threshold | Action |
|---|---|---|
| Demo show rate | <30% of booked | Change messaging. Lead with free teardown offer. |
| Demo-to-close rate | <15% after 10 demos | Diagnose: is it trust? Price? Urgency? Interview every non-closer. |
| First renewal churn | >50% of first 5 churn at Day 30 | STOP all content/ads. Customer interviews only. Fix the product. |
| api.mixlift.io downtime | >1 hour | Founder gets paged. If Render, evaluate Railway/Fly.io migration. |
| Google Ads CPA | >$300 after 14 days | Pause campaign. Diagnose: keywords, landing page, or market? |
| Google Ads CPA | <$200 after 14 days | Add Campaign 2 (Competitor Conquest) at $500/mo. |
| LinkedIn post engagement | <500 impressions on 2 consecutive posts | Change content angle. Try video instead of text/carousel. |
| Reddit post | Removed by mods or <10 upvotes | Adjust tone — more value, less promotion. Try different subreddit. |
| "I need to share this" objection | 3+ prospects say it | Build PDF report export immediately. |
| Month 2 retention of first 5 | 80%+ | Green light for scaling ads to $2,500/mo. |
| Month 2 retention of first 5 | <60% | Pause acquisition. All effort on retention mechanics. |

### Finance Scenarios (Day 90 Decision Framework)

| Scenario | Probability | Metrics | Decision |
|---|---|---|---|
| **Downside** | 15% | <10 paying, >15% churn | Kill or pivot. Consider web app, Shopify app, or open-source-with-support model. |
| **Base** | 60% | 10-15 paying, 5-10% churn | Lifestyle path. Stay lean. $100-180K ARR ceiling is a fine outcome. |
| **Upside** | 25% | 15-25 paying, <5% churn | Invest moderately. Launch Pro tier. Hire first contractor (growth marketer). |

---

## 6. Operating Principles

These five rules govern every decision for the next 90 days. When in doubt, apply these in order.

### Principle 1: Customers Before Code

No engineering work is justified by "best practice" or "technical correctness." Every task must answer: "Which customer interaction does this enable, protect, or improve?" If the answer is "none right now," it goes in the backlog. The EM's hardening work is justified because downtime during a demo kills a deal. LOO-CV is justified because it answers "can I trust this?" during a sale. Report export is not justified because no customer has asked for it.

### Principle 2: Concierge Is the Product

For the first 10 customers, the founder IS the product. Do MCP setup for them. Sit on the call while the model runs. Interpret the results together. Fix bugs in real time. This is not overhead -- this is the fastest path to understanding what the product must become. Every concierge interaction generates signal worth more than a week of speculative feature work.

### Principle 3: Measure Retention, Not Acquisition

Getting 5 customers to pay $299 is a sales problem. Getting them to pay again next month is a product problem. The product problem is harder and more important. Every feature decision after Day 30 is driven by retention data, not acquisition ambition. The critical metric is Month 2 retention of the first 5 customers, available around Day 75.

### Principle 4: One Bet at a Time

MixLift is betting on: (a) Bayesian MMM delivered via MCP, (b) to DTC eCommerce brands, (c) at $299/month, (d) sold via inbound-led concierge sales (content + capped paid search + warm intros). If this combination does not work, we change ONE variable at a time. We do not simultaneously pivot the channel, the audience, and the price. Sequential experiments with clear kill criteria.

### Principle 5: Shipped Beats Correct

A demo with a minor model quality issue that closes a customer beats a perfect model that nobody sees. The DS Manager's concerns about posterior means in the optimizer, prior sensitivity on short data, and missing cross-channel interactions are all technically valid. None of them matter until a customer notices. Ship, sell, listen, then fix what customers tell us is broken.

---

## Appendix A: Onboarding Playbook (First 5 Customers)

Adopted from Customer Success with modifications.

| Day | Action | Owner | Goal |
|---|---|---|---|
| 0 | Live demo on THEIR data. Close on the call. Do MCP setup FOR them (screenshare). | Founder | Aha moment: dollar headline on their own data that contradicts platform attribution. |
| 1 | Send follow-up email: summary of findings, link to scenario mode docs, "try running it yourself." | Founder | Confirm they can run independently. |
| 3 | Check-in message: "Were you able to run it on your own? Any questions about the results?" | Founder | Catch installation/usage friction early. |
| 7 | Scheduled call: Interpretation deep-dive + scenario mode walkthrough. "What if you cut TikTok by 20%?" | Founder | Deepen engagement. Demonstrate ongoing value beyond first analysis. |
| 14 | Async check-in: "Have your numbers changed? Want to re-run with this week's data?" | Founder | Trigger second analysis. Memory deltas kick in. |
| 21 | Pre-renewal call: Run fresh analysis together. Show deltas from Day 0. "Your Meta ROAS improved from 2.3x to 2.8x." | Founder | Reframe from "diagnosis tool" to "tracking tool." Make renewal feel obvious. |
| 30 | Renewal happens automatically (Stripe). Follow up: "Glad to have you for another month. Here's what we're shipping next." | Founder | Retain. Collect feedback on what they'd pay more for. |

---

## Appendix B: Qualification Criteria (Adopted from Sales Lead)

**QUALIFY:**
- DTC eCommerce, $5M-$50M revenue
- $30K+/month ad spend across 3+ channels
- Director/VP of Growth or Marketing (budget authority)
- Frustrated with platform attribution or "flying blind"
- 6+ months of historical spend data available

**DISQUALIFY:**
- Pre-revenue or pre-product-market-fit startups
- Single-channel advertisers (MixLift needs channel mix)
- Has an in-house data science team (they'll build, not buy)
- Committee buyers requiring 3+ stakeholder approval
- Agencies (deferred to Week 9+)

---

## Appendix C: What Is Already Shipped (Codebase Truth)

For reference, to prevent re-debating or re-building things that exist.

| Capability | Location | Status |
|---|---|---|
| PyPI package (v0.2.0) | `pip install mixlift` | LIVE |
| License API | api.mixlift.io | LIVE |
| Stripe payment flow | Payment Link -> Webhook -> License | LIVE |
| Email delivery (Resend) | `mixlift-api/src/mixlift_api/email_service.py` | LIVE |
| Holiday controls (auto-detect US) | `mixlift/modeling/preprocessing.py` | SHIPPED |
| Contextual memory + deltas | `src/mixlift_mcp/memory.py` + `server.py` | SHIPPED |
| Free tier metering (2 runs/mo) | `src/mixlift_mcp/metering.py` | SHIPPED |
| Headless API with license gate | `mixlift/api.py` | SHIPPED |
| Posterior predictive sampling | `mixlift/modeling/engine.py:127` | SHIPPED |
| 4-chain MCMC config | `mixlift/modeling/defaults.py` | SHIPPED |
| Tier naming fix (pro + growth) | `mixlift/api.py:90` | SHIPPED |
| Dollar headline gate (free=%, paid=$) | `src/mixlift_mcp/server.py` | SHIPPED |
| Saturation traffic lights | `src/mixlift_mcp/server.py` | SHIPPED |
| Scenario mode | `src/mixlift_mcp/server.py` | SHIPPED |
| Confidence explainers | `src/mixlift_mcp/server.py` | SHIPPED |
| Path traversal protection | `src/mixlift_mcp/server.py` | SHIPPED |
| Convergence diagnostics (R-hat) | `mixlift/modeling/engine.py` | SHIPPED |
| Marginal ROAS | `mixlift/modeling/engine.py` | SHIPPED |
| Battle card | `docs/battle-card.md` | SHIPPED |
| Outreach templates (5) | `docs/outreach-templates.md` | SHIPPED |
| ICP profiles | `docs/icp-profiles.md` | SHIPPED |
| Landing page | Netlify | LIVE |

---

*This plan was produced on March 7, 2026.*
*First review: March 17, 2026 (Monday).*
*Review cadence: Every Monday.*
*Owner: Founder (with Chief of Staff oversight).*

**The next action is not reading this document. It is recording the Loom demo and building the prospect list this weekend. Monday morning, DMs go out. Go.**
