"""Benchmark: nutpie vs PyMC sampler wall-clock time on demo.csv.

Usage:
    python scripts/benchmark_samplers.py

Reports wall-clock time per run, mean ± std, and nutpie speedup factor.
Not a pytest test — manual review only.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from statistics import mean, stdev

# Add the mixlift package root to sys.path so we can import without installing
_repo_root = Path(__file__).parents[1]
sys.path.insert(0, str(_repo_root))
sys.path.insert(0, str(_repo_root / "src"))

import pandas as pd  # noqa: E402

from mixlift.ingest.loader import load_wide_format  # noqa: E402
from mixlift.modeling.engine import run_full_pipeline  # noqa: E402

DEMO_CSV = _repo_root / "src" / "mixlift_mcp" / "data" / "demo.csv"
N_RUNS = 3
SEEDS = [1001, 2002, 3003]

# Benchmark MCMC config — use production-level draws so timing is representative.
# This matches DEFAULT_MCMC_CONFIG (4 chains × 1000 tune × 1000 draws).
BENCH_CONFIG = {
    "chains": 4,
    "tune": 1000,
    "draws": 1000,
    "target_accept": 0.90,
}


def _run_once(sampler: str, seed: int) -> float:
    """Return wall-clock seconds for one complete pipeline run."""
    df = pd.read_csv(DEMO_CSV)
    features, target, channels = load_wide_format(df)

    config = {**BENCH_CONFIG, "random_seed": seed}

    orig = os.environ.get("MIXLIFT_SAMPLER")
    os.environ["MIXLIFT_SAMPLER"] = sampler
    t0 = time.perf_counter()
    try:
        run_full_pipeline(features, target, channels, mcmc_config=config)
    finally:
        if orig is None:
            os.environ.pop("MIXLIFT_SAMPLER", None)
        else:
            os.environ["MIXLIFT_SAMPLER"] = orig

    return time.perf_counter() - t0


def _check_nutpie() -> bool:
    try:
        import nutpie  # noqa: F401
        return True
    except ImportError:
        return False


def _fmt_row(sampler: str, times: list[float]) -> str:
    m = mean(times)
    s = stdev(times) if len(times) > 1 else 0.0
    runs = "  ".join(f"{t:7.1f}s" for t in times)
    return f"  {sampler:<10} {runs}   mean={m:6.1f}s  std={s:5.1f}s"


def main() -> None:
    print(f"\nBenchmark: PyMC vs nutpie samplers — {N_RUNS} runs each on demo.csv")
    n_chains = BENCH_CONFIG["chains"]
    n_tune = BENCH_CONFIG["tune"]
    n_draws = BENCH_CONFIG["draws"]
    print(f"Config: {n_chains} chains × {n_tune} tune × {n_draws} draws\n")

    if not _check_nutpie():
        print("ERROR: nutpie is not installed. Install with: pip install 'mixlift[fast]'")
        sys.exit(1)

    samplers = ["pymc", "nutpie"]
    results: dict[str, list[float]] = {}

    for sampler in samplers:
        print(f"Running {N_RUNS}x with {sampler}…")
        times = []
        for i, seed in enumerate(SEEDS):
            print(f"  run {i + 1}/{N_RUNS} (seed={seed})… ", end="", flush=True)
            t = _run_once(sampler, seed)
            times.append(t)
            print(f"{t:.1f}s")
        results[sampler] = times
        print()

    # Print results table
    header = f"  {'Sampler':<10}  " + "  ".join(f"{'Run ' + str(i + 1):>8}" for i in range(N_RUNS))
    print("=" * 70)
    print(header)
    print("-" * 70)
    for sampler in samplers:
        print(_fmt_row(sampler, results[sampler]))
    print("=" * 70)

    pymc_mean = mean(results["pymc"])
    nutpie_mean = mean(results["nutpie"])
    speedup = pymc_mean / nutpie_mean if nutpie_mean > 0 else float("inf")

    print(f"\nSpeedup: nutpie is {speedup:.2f}x faster than pymc (mean wall-clock)")
    print(f"  pymc:   {pymc_mean:.1f}s mean")
    print(f"  nutpie: {nutpie_mean:.1f}s mean")

    if speedup >= 3.0:
        print("\nResult: target 3-5x speedup ACHIEVED.")
    elif speedup >= 2.0:
        print(
            f"\nResult: {speedup:.2f}x speedup "
            "(below 3x target — acceptable for prod flip if parity holds)."
        )
    else:
        print(f"\nResult: only {speedup:.2f}x speedup — investigate before flipping the flag.")


if __name__ == "__main__":
    main()
