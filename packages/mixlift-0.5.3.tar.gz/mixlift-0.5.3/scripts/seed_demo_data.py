"""Seed demo data: generate synthetic CSV and print summary."""

from pathlib import Path

from scripts.generate_synthetic import generate_synthetic_data


def main():
    output_path = Path(__file__).parent.parent / "data" / "demo_data.csv"
    df = generate_synthetic_data(n_weeks=104, seed=42, output_path=str(output_path))

    print("\nDemo data summary:")
    print(f"  Weeks: {len(df)}")

    spend_cols = [c for c in df.columns if c.endswith("_spend")]
    for col in spend_cols:
        channel = col.replace("_spend", "").replace("_", " ").title()
        print(f"  {channel}: avg ${df[col].mean():,.0f}/week, total ${df[col].sum():,.0f}")

    print(f"  Avg revenue: ${df['revenue'].mean():,.0f}/week")
    print(f"\nFile saved to: {output_path}")


if __name__ == "__main__":
    main()
