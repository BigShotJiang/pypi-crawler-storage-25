#!/usr/bin/env python3
"""One-shot script to update Stripe product name + description.

Usage:
    export STRIPE_SECRET_KEY=sk_live_...
    python scripts/update_stripe_copy.py
"""
import os
import sys

try:
    import stripe
except ImportError:
    print("ERROR: pip install stripe")
    sys.exit(1)

stripe.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
if not stripe.api_key:
    print("ERROR: Set STRIPE_SECRET_KEY first.")
    sys.exit(1)

PRODUCT_ID = "prod_U5HcqoapvLGkVJ"
NEW_NAME = "MixLift Growth"
NEW_DESC = (
    "Full Bayesian Marketing Mix Modeling in your AI assistant. "
    "Analyze up to 8 channels and 50,000 rows with unlimited runs per month. "
    "Get dollar-value ROAS with uncertainty ranges, budget optimization, "
    "and saturation curves \u2014 all processed locally on your machine. Cancel anytime."
)

product = stripe.Product.modify(PRODUCT_ID, name=NEW_NAME, description=NEW_DESC)
print(f"Updated product: {product.name} ({product.id})")
print(f"Description: {product.description}")
