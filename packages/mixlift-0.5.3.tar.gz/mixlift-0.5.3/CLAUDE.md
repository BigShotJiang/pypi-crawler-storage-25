# MixLift Project Instructions

## Product Overview

MixLift is the first AI-native Marketing Mix Modeling (MMM) SaaS. It delivers Bayesian MMM through a conversational AI interface (MCP server for Claude Desktop) and a headless Python API. A marketer drops a CSV of ad spend into Claude and gets back dollar-denominated ROAS, budget optimization, and saturation analysis — in minutes, for $299/month.

**Version:** 0.3.0 | **PyPI:** `pip install mixlift` | **License API:** api.mixlift.io (LIVE)

## Architecture

```
USER'S MACHINE                         REMOTE
┌─────────────────────────┐            ┌──────────────────┐
│ Claude Desktop          │            │ api.mixlift.io   │
│   └─ MixLift MCP Server │──HTTPS──→ │ License API      │
│       └─ Modeling Engine │            │ (FastAPI+SQLite) │
│          (PyMC-Marketing)│            └──────────────────┘
│                          │            ┌──────────────────┐
│ Headless: mixlift.analyze│            │ Stripe           │
└─────────────────────────┘            │ (payments+hooks) │
                                        └──────────────────┘
Landing page: Netlify | Frontend: Streamlit (parked) | Backend: FastAPI (parked)
```

## Key Files

| Component | Location | Notes |
|-----------|----------|-------|
| MCP Server | `src/mixlift_mcp/server.py` | Main tool: `mixlift_analyze`, `mixlift_prepare` |
| License client | `src/mixlift_mcp/license.py` | Fail-closed, 24h grace cache |
| Metering | `src/mixlift_mcp/metering.py` | 2 runs/month free tier |
| Memory | `src/mixlift_mcp/memory.py` | Cross-run analysis deltas |
| Modeling engine | `mixlift/modeling/engine.py` | PyMC-Marketing MMM wrapper |
| Budget optimizer | `mixlift/modeling/optimizer.py` | Gradient-based allocation |
| Preprocessing | `mixlift/modeling/preprocessing.py` | Weekly agg, holidays, controls |
| Recommendations | `mixlift/modeling/recommendations.py` | Plain-English budget advice |
| MCMC defaults | `mixlift/modeling/defaults.py` | 4 chains, 250 draws, target_accept=0.90 |
| CSV ingestion | `mixlift/ingest/service.py` | Auto-detect Meta/Google/TikTok/generic |
| Headless API | `mixlift/api.py` | `from mixlift import analyze` |
| Config | `mixlift/config.py` | Pydantic settings, tier limits |
| Demo data | `src/mixlift_mcp/data/demo.csv` | 3 channels, 52 weeks |
| Tests | `tests/` | 46+ quick tests, 18 test files |

## Current Status

- **Stage:** Pre-revenue. Product shipped. Selling via founder-led concierge demos.
- **Pricing:** Free ($0, 2ch/2000rows/2runs) | Growth ($299/mo, 8ch/50K rows/unlimited)
- **ICP:** Director/VP of Growth at DTC eComm brands, $5M-$50M rev, no data scientist on staff
- **Key docs:** `STRATEGY.md`, `OPERATING_PLAN.md`, `PROJECT_STATUS.md`, `docs/agent-status.md`

## Agent Briefings

When an agent persona is active (via `/agent` or auto-routing), read your role-specific briefing for deep project context:

| Agent(s) | Briefing file |
|----------|---------------|
| software-engineer, engineering-manager | `docs/agent-briefs/engineering.md` |
| data-science-manager, data-analyst | `docs/agent-briefs/data-science.md` |
| product-manager, product-designer | `docs/agent-briefs/product.md` |
| marketing-manager | `docs/agent-briefs/marketing.md` |
| sales-lead | `docs/agent-briefs/sales.md` |
| finance | `docs/agent-briefs/finance.md` |
| customer-success | `docs/agent-briefs/customer-success.md` |
| strategist, chief-of-staff | `docs/agent-briefs/strategy.md` |

Read the briefing file BEFORE starting work. It contains the context you need to operate effectively.

## Dev Commands

```bash
make install          # pip install -e ".[dev]"
make test             # Quick tests (excludes slow MCMC)
make test-cov         # With coverage
make lint / make format
make run              # FastAPI :8000
make frontend         # Streamlit :8501
```

## Conventions

- Tests: `pytest`, fixtures in `tests/conftest.py`
- Linting: `ruff`
- Type checking: `mypy`
- CI: GitHub Actions (Python 3.11, 3.12), ruff + pytest
- Release: Tag `v*` triggers PyPI publish via OIDC
- MCP server is the primary product. Web app (FastAPI + Streamlit) is parked.
- Agent status board: `docs/agent-status.md` — update your section after completing work

# Compact instructions

When compacting, preserve: current task name, any failing test names, which files were recently modified, and the current experiment budget status. Drop: file contents already on disk, verbose error traces (keep just the error message), and conversation about approach decisions already made.
