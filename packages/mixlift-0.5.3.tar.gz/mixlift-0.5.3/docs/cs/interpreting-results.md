# Interpreting Your MixLift Results

**Audience:** Marketing directors and growth leads -- no statistics background needed
**Last updated:** 2026-03-07

When you run MixLift, Claude returns several sections of results. This guide explains what each section means and what to do with it.

---

## 1. The Dollar Headline

**What it is:** A single number at the top of your results showing the estimated revenue you could gain by reallocating your current ad budget. No extra spend -- just moving dollars between channels more efficiently.

**Example:**
> Estimated revenue lift: +$8,400/month (+6.2%) by reallocating current budget

**How to read it:**
- This is the model's best estimate, not a guarantee. Think of it as a directional signal.
- The percentage tells you the relative size of the opportunity. Under 3% means your budget is already fairly well-allocated. Over 10% means there's significant room for improvement.
- This number assumes you follow the full reallocation recommendation below.

**What to do next:**
- If the number is large (>5%): Review the budget optimization section carefully. There's likely a clear overspend on one or more channels.
- If the number is small (<3%): Your budget allocation is solid. Focus on the saturation analysis to see if there's room to scale total spend.
- If the number seems unrealistically large (>25%): Your model may need more data, or there's a data quality issue. Contact your MixLift contact to review.

---

## 2. ROAS Per Channel (Return on Ad Spend)

**What it is:** For each ad channel, how many dollars of revenue you get back for every $1 spent.

**Example:**

| Channel | ROAS | 95% CI |
|---------|------|--------|
| google_search | 4.2x | 3.1 - 5.8 |
| meta_prospecting | 2.8x | 1.9 - 3.5 |
| tiktok | 1.3x | 0.6 - 2.1 |

**How to read it:**
- **ROAS of 1.0x** = break-even. You're getting back exactly what you spend.
- **ROAS above 1.0x** = profitable. Higher is better.
- **ROAS below 1.0x** = losing money on that channel (on average).
- **The 95% CI (confidence interval)** shows the range of plausible values. A narrow range (like 3.1-5.8) means the model is fairly confident. A wide range (like 0.6-2.1) means there's more uncertainty.

**Important:** This is *average* ROAS across your entire data period, measured by the Bayesian model. It may differ from what your ad platform reports because:
- Platform attribution double-counts conversions across channels
- MixLift isolates each channel's independent contribution
- The model accounts for diminishing returns at higher spend levels

**What to do next:**
- **High ROAS channel (>3x):** This channel is working. Check the saturation analysis to see if there's room to spend more.
- **Moderate ROAS channel (1.5-3x):** Solid performer. Maintain current spend unless saturation is high.
- **Low ROAS channel (<1.5x):** Consider reducing spend. But check the confidence interval first -- if it's wide (e.g., 0.6 - 2.1), the model isn't sure yet. More data will help.
- **ROAS below 1.0x:** The model says you're losing money on this channel. Consider cutting spend by 20-30% and re-running in 2-3 weeks to see if the picture changes.

---

## 3. Confidence Summary

**What it is:** A plain-English assessment of how confident the model is in each channel's ROAS estimate.

**Example:**
- google_search: High confidence (tight uncertainty bounds)
- meta_prospecting: Moderate confidence (consider more data for precision)
- tiktok: Low confidence (wide uncertainty bounds)

**How to read it:**
- **High confidence:** The model has enough data to give a reliable estimate. You can act on this number.
- **Moderate confidence:** The estimate is directionally useful but could shift with more data. Act cautiously.
- **Low confidence:** The model is uncertain. This usually means the channel has low or inconsistent spend in your data. Don't make major budget decisions based on this alone.

**What to do next:**
- For low-confidence channels: Add more weeks of data and re-run. If a channel has very low spend, the model simply doesn't have enough signal to estimate its effect.
- For moderate-confidence channels: Treat the ROAS estimate as a range (use the CI) rather than a precise number.

---

## 4. Marginal ROAS

**What it is:** The return on the *next* dollar you spend on each channel. While average ROAS tells you how the channel has performed overall, marginal ROAS tells you what you'd get from spending *more*.

**Example:**
- google_search: Marginal ROAS 3.1x (vs. average 4.2x)
- meta_prospecting: Marginal ROAS 1.4x (vs. average 2.8x)

**How to read it:**
- Marginal ROAS is almost always lower than average ROAS because of diminishing returns -- the more you spend, the less each additional dollar produces.
- A big gap between average and marginal (like meta going from 2.8x average to 1.4x marginal) means you're already deep into diminishing returns on that channel.
- A small gap (like google going from 4.2x to 3.1x) means there's still room to scale.

**What to do next:**
- Focus on channels where marginal ROAS is highest -- that's where additional spend produces the most return.
- If a channel's marginal ROAS is below 1.0x, you're past the point of profitability on additional spend. Scale back.

---

## 5. Saturation Traffic Lights

**What it is:** A color-coded indicator showing how close each channel is to the point of diminishing returns.

**Example:**
- google_search: GREEN -- 35% saturated, 65% headroom (room to scale)
- meta_prospecting: YELLOW -- 62% saturated (approaching diminishing returns)
- tiktok: RED -- 84% saturated (diminishing returns)

**How to read it:**
- **GREEN (under 50% saturated):** This channel has significant headroom. You could increase spend here and still get strong returns.
- **YELLOW (50-75% saturated):** Approaching the efficiency ceiling. Additional spend still produces returns, but they're shrinking. Maintain or modestly increase.
- **RED (over 75% saturated):** Deep into diminishing returns. Every extra dollar here produces less and less. Consider reallocating some of this budget to green channels.

**What to do next:**

| Traffic Light | Action |
|---------------|--------|
| GREEN | Consider increasing spend by 10-20%. Re-run in 2-3 weeks to track the impact. |
| YELLOW | Hold steady. If budget is tight, this is a channel to pull from before red channels. |
| RED | Reduce spend by 10-20%. Move those dollars to a green channel. Re-run in 2-3 weeks. |

**Important nuance:** A channel can be highly saturated AND still have good ROAS. "Red" doesn't mean "bad channel" -- it means "you've already captured most of the available return from this channel at current spend levels." The channel may still be your best performer. It just doesn't need more money.

---

## 6. Budget Optimization

**What it is:** The mathematically optimal allocation of your current total ad budget across all channels, based on the model's estimates of each channel's response curve.

**Example:**

| Channel | Current Spend | Optimal Spend | Change |
|---------|--------------|---------------|--------|
| google_search | $12,000/mo | $16,500/mo | +$4,500 |
| meta_prospecting | $18,000/mo | $14,000/mo | -$4,000 |
| tiktok | $5,000/mo | $4,500/mo | -$500 |

**How to read it:**
- "Current Spend" is the average from your data.
- "Optimal Spend" is what the model recommends.
- "Change" shows the suggested reallocation.
- The total budget stays the same -- the optimizer moves money between channels, it doesn't increase your total spend.

**What to do next:**
- **Don't move everything at once.** Start with the largest recommended shift. If the model says to move $4,500 from Meta to Google, start by moving $1,500-$2,000 and see how performance responds over 2-3 weeks.
- **Re-run after making changes.** Update your CSV with the new spend data and run MixLift again. The model will refine its estimates.
- **Use scenario mode to preview.** Before making a change, ask Claude: "What happens if I move $2,000 from meta to google?" to see the projected impact.

---

## 7. Scenario Mode

**What it is:** A "what if" simulator that projects how budget changes would affect revenue, using the fitted model.

**How to use it:**
Ask Claude with your analysis:
> "Run mixlift_analyze on my_data.csv with scenario 'cut meta by 20%'"
> "Run mixlift_analyze on my_data.csv with scenario 'move $3000 from tiktok to google'"
> "Run mixlift_analyze on my_data.csv with scenario 'increase google by $5000'"

**Example result:**
> Scenario: "cut meta by 20%"
> Projected revenue change: -3.2% (-$2,100/month)
> 80% credible interval: -5.1% to -1.4%

**How to read it:**
- The projected change is the model's best estimate of what would happen.
- The credible interval gives you the range of likely outcomes. "80% credible interval" means there's an 80% chance the actual result falls in that range.
- "Direction confidence" tells you how sure the model is about the direction (positive or negative) of the change.

**What to do next:**
- Use scenario mode to test ideas before committing budget. Run multiple scenarios to compare options.
- **If the interval is wide** (e.g., -8% to +2%), the model isn't sure whether this change helps or hurts. Proceed with caution or gather more data.
- **If the interval is narrow and clearly positive** (e.g., +2% to +6%), this is a high-confidence improvement.
- **If the interval is narrow and clearly negative** (e.g., -5% to -2%), avoid this change.

**Scenario mode requires the Growth plan ($299/mo).** Free tier users will see a message asking them to upgrade.

---

## 8. Memory Deltas (After Your Second Run)

**What it is:** When you run MixLift more than once, it remembers your previous analysis and shows what changed.

**Example:**
- google_search ROAS moved +0.4 (from 3.8x to 4.2x)
- meta_prospecting ROAS moved -0.3 (from 3.1x to 2.8x)

**How to read it:**
- Positive deltas mean the channel's estimated ROAS improved since last run.
- Negative deltas mean estimated ROAS decreased.
- These changes can happen because: you added new data, you changed your spend mix, or the model refined its estimates with more information.

**What to do next:**
- Track deltas over time. If you made a budget change based on MixLift's recommendation, the deltas show whether it's working.
- If a channel's ROAS drops after you increased spend on it, you may be hitting saturation faster than expected. Pull back slightly.
- If a channel's ROAS improves after you reduced spend, the model is confirming you were overspending there.

---

## 9. Model Quality Indicators

**What it is:** Diagnostic information about how well the statistical model fit your data.

**Convergence (R-hat):** Values near 1.0 mean the model converged properly. If you see a warning about R-hat values above 1.05, the model may not be reliable. This usually means you need more data.

**Prior-dominated warning:** If MixLift warns that certain channels are "more influenced by priors than by your data," it means there isn't enough data for those channels to get a precise estimate. The model falls back on default assumptions. Treat those channels' ROAS numbers as directional only.

**What to do next:**
- If you see convergence warnings: Add more weeks of data and re-run.
- If you see prior-dominated warnings for a channel: That channel probably has very low or very inconsistent spend. The model needs more variation to learn its effect.
- If everything looks good: No action needed. The numbers are reliable.

---

## Quick Reference: What To Do For Common Findings

| Finding | What It Means | What To Do |
|---------|--------------|------------|
| Channel has GREEN saturation + high ROAS | Strong channel with room to grow | Increase spend 10-20%. Re-run in 2-3 weeks. |
| Channel has RED saturation + high ROAS | Strong channel but maxed out | Maintain spend. Don't add more -- you won't get proportional returns. |
| Channel has RED saturation + low ROAS | Overspending on a weak channel | Reduce spend 10-20%. Reallocate to green channels. |
| Channel has GREEN saturation + low ROAS | Channel isn't performing but has room | Keep current spend. May improve with better creative. Low confidence? Need more data. |
| Wide confidence interval on ROAS | Model is uncertain about this channel | Don't make big decisions on this channel yet. Add more data. |
| Large gap between average and marginal ROAS | Deep into diminishing returns | You're spending too much here. Scale back toward the efficient frontier. |
| Scenario shows wide interval crossing zero | Model can't tell if this change helps or hurts | Don't make this change based on model alone. Test with a small experiment. |
| Memory delta shows ROAS improving | Your budget changes are working | Continue the strategy. Consider pushing further in the same direction. |
| Memory delta shows ROAS declining | Something changed -- spend, market, or seasonality | Investigate. Re-run scenario mode to diagnose. |

---

## Questions?

If anything in your results is unclear, reply to any email from your MixLift contact or ask Claude directly -- "What does [specific term] mean in my MixLift results?" Claude can explain using your actual numbers.
