# Churn Risk Signals and Action Plans

**Owner:** Founder
**Purpose:** Identify customers at risk of churning before they cancel. Every signal has a specific action plan.
**Last updated:** 2026-03-07

---

## How To Use This Document

Review each active customer against these signals weekly (Monday check). A customer exhibiting one signal needs monitoring. Two or more signals means proactive intervention is required today, not next week.

---

## Signal 1: No Analysis After Day 7

**What it looks like:** The customer has not run MixLift since the initial setup call (Day 0) or the Day 7 interpretation call. The `last_validated_at` timestamp in the license database is 7+ days old.

**Why it matters:** If a customer isn't using the product in the first week, they almost certainly won't use it in week 2 or 3. The Day 0-7 window is when habits form. A customer who runs 3+ analyses in week 1 is far more likely to renew than one who runs 1.

**Risk level:** HIGH

**Action plan:**
1. Check the license database for the `last_validated_at` timestamp. Confirm they haven't run any analysis.
2. Send a direct, personal message (not a template):
   > "Hey [Name], I noticed MixLift hasn't been used since our call. Totally normal if you've been busy -- but I want to make sure nothing is broken on your end. Can I run a quick analysis on your latest data and send you the results? Takes me 2 minutes."
3. If no response within 48 hours, call them directly.
4. If you reach them and they cite time constraints, offer to run analyses for them weekly until they have bandwidth. This is concierge -- it's the product for the first 10 customers.
5. If you cannot reach them after 3 attempts (email + call + text), note them as pre-churn. Continue the standard playbook but expect cancellation.

---

## Signal 2: No Scenario Mode Usage

**What it looks like:** The customer has run 1-2 basic analyses but has never used scenario mode ("what if" questions). Check API logs for the absence of the scenario parameter.

**Why it matters:** Scenario mode is the stickiest feature. It transforms MixLift from a one-time diagnostic tool into an ongoing decision-support tool. Customers who use scenario mode are engaging with the product at a deeper level and are far more likely to see it as essential to their workflow.

**Risk level:** MEDIUM

**Action plan:**
1. On the next touchpoint (Day 7 call, Day 14 email, or ad hoc), introduce scenario mode with a specific, relevant example:
   > "I wanted to show you something I think you'll find really useful. Based on your last analysis, [Channel X] looks oversaturated. Let's see what happens if you shift some of that budget. Ask Claude: 'Run mixlift_analyze on [their file] with scenario cut [channel] by 20%'"
2. Tie the scenario to a real decision they're facing. If they mentioned considering a TikTok budget change on a call, use that exact scenario.
3. Follow up after the next analysis to ask if they tried scenario mode.
4. If they still haven't used it by Day 14, offer to run 3 scenarios for them and send results with commentary.

---

## Signal 3: No Data Refresh

**What it looks like:** The customer is running analyses but always on the same original CSV. They haven't added new weeks of data. You can infer this from the absence of memory deltas in their results (deltas only appear when the underlying data changes).

**Why it matters:** A customer running the same data repeatedly isn't getting new value. They've already seen the findings. Without fresh data, there's no reason to keep paying. Data refresh is what turns MixLift into a monitoring tool vs. a one-time report.

**Risk level:** MEDIUM

**Action plan:**
1. On the next touchpoint, explain the value of fresh data:
   > "The real power of MixLift shows up when you add new weeks. It tracks how your channel performance evolves and shows you deltas -- 'Meta ROAS went from 2.3x to 2.8x since your last analysis.' Want to add your latest 2-3 weeks and re-run?"
2. Offer to help them set up a simple data export workflow: "What platform are you pulling this from? I can help you set up a quick process to update your CSV weekly."
3. If they say data collection is too manual, note this as product feedback. A future data connector or simpler import flow could address this.

---

## Signal 4: Support Tickets About Accuracy

**What it looks like:** The customer emails or asks questions like:
- "These numbers don't match what Google Ads shows me"
- "I don't think the ROAS is right for [channel]"
- "The model says to cut [channel] but that's our best performer"
- "How accurate is this really?"

**Why it matters:** Trust is the foundation. If a customer doesn't trust the numbers, every other touchpoint is irrelevant. They won't act on recommendations, they won't renew, and they may tell others the tool doesn't work.

**Risk level:** HIGH

**Action plan:**
1. **Respond within 4 hours.** Accuracy concerns decay into cancellation if left unaddressed.
2. **Do not be defensive.** Start with: "That's a great question and exactly the kind of thing I want to dig into with you."
3. **Explain the expected discrepancy:**
   > "MixLift intentionally gives different numbers than your ad platform. Here's why: Google Ads gives you 'last click' attribution -- it takes credit for every conversion where Google was the last touchpoint. But your customer may have seen a Meta ad, then a TikTok ad, then searched on Google and clicked. Google claims the full sale. MixLift uses a statistical model to isolate each channel's independent contribution. So the numbers should be different -- that's the point."
4. **Walk through the confidence intervals:** "See the 95% CI column? That shows the range of uncertainty. If the CI is wide, the model is telling you it's not fully sure. Let's look at which channels have high confidence and which ones need more data."
5. **Validate against their intuition:** "Based on your experience, which channels do you think are your strongest? Let's compare that to what the model says and see where they agree and disagree."
6. **If the discrepancy is genuinely problematic** (e.g., model says a channel is negative ROAS but the customer knows it drives 30% of their revenue), escalate internally. There may be a data issue, a column mapping problem, or a model limitation to investigate. Fix it within 48 hours and report back.
7. **Follow up within 1 week** to confirm trust has been restored.

---

## Signal 5: Questions About Cancellation or Billing

**What it looks like:** The customer asks:
- "How do I cancel?"
- "When does my subscription renew?"
- "Can I pause my subscription?"
- "Is there a cheaper plan?"

**Why it matters:** This is the most direct pre-churn signal. The customer is already thinking about leaving. You have 24-48 hours to change the trajectory.

**Risk level:** CRITICAL

**Action plan:**
1. **Respond within 2 hours.** Not tomorrow. Not end of day. Now.
2. **Answer their question honestly first.** Don't dodge: "Your subscription renews on [date] via Stripe. You can cancel anytime by [instructions]."
3. **Then ask why:**
   > "I want to make sure you're getting value. What's driving the question? Is there something that isn't working for you?"
4. **Listen and categorize the response:**

   | Reason | Response |
   |--------|----------|
   | "Too expensive" | "I hear you. Would it help if I ran your analyses for you this month so you get maximum value from the subscription? Let's talk about what would make it worth $299 to you." |
   | "Not using it enough" | "Totally fair. What if I set up a weekly automated reminder and ran the analysis for you? Or we could do a monthly deep-dive call together instead of self-serve." |
   | "Don't trust the numbers" | See Signal 4 action plan. Offer a live session to walk through methodology. |
   | "Got what I needed" | "Glad it was useful. The real value shows up over time as you track changes. Can I show you the delta tracking feature before you decide? One more month of data makes the model significantly more accurate." |
   | "Switching to another tool" | "Interesting -- what are you switching to? I'd genuinely love to know what they do better." (Competitive intelligence is gold.) |
   | "Budget cuts across the board" | "Understood. Would a one-month pause be helpful? I'd rather keep you as a customer at a later date than lose you entirely." |

5. **If they still want to cancel:** Be gracious. Process it promptly. Ask for a 5-minute exit interview. Log the reason in detail.
6. **Post-cancellation:** Send a final email 30 days later: "Hey [Name], just checking in. How did things go with your marketing mix since we last spoke? If you ever want to re-run, your data is still here."

---

## Signal 6: Declining Usage Frequency

**What it looks like:** The customer was active in weeks 1-2 (multiple analyses, scenario mode) but usage has dropped. Fewer analyses per week, longer gaps between runs.

**Why it matters:** Declining usage is the leading indicator of cancellation, usually by 2-4 weeks. Customers rarely cancel while actively using a product.

**Risk level:** MEDIUM (escalates to HIGH if combined with any other signal)

**Action plan:**
1. Check the license validation logs for the frequency pattern. Compare week 1-2 usage to week 3-4.
2. Send a "here's what changed" email tied to their data:
   > "Hi [Name], it's been [X] days since your last analysis. If your spend has shifted at all in the last few weeks, now's a great time to re-run -- the model will pick up the changes and show you updated recommendations. Want me to run it for you?"
3. If the customer ran analyses in weeks 1-2 but stopped, it often means they acted on the initial recommendations and now feel "done." The key is showing ongoing value:
   - Memory deltas that track the impact of changes they made
   - New scenarios based on current market conditions
   - Seasonal shifts that affect optimal allocation

---

## Signal 7: Negative Feedback on Calls

**What it looks like:** On a scheduled call, the customer gives short answers, seems distracted, scores satisfaction below 7/10, or says things like "it's fine" or "I haven't really looked at it."

**Why it matters:** "Fine" is not a retention signal. Retained customers say things like "I found something interesting" or "I showed this to my team." Low-energy calls predict churn.

**Risk level:** MEDIUM

**Action plan:**
1. On the call, ask directly: "On a scale of 1-10, how useful has MixLift been? And what would make it a 10?"
2. If they score 6 or below, pivot the call to discovery: "I'd rather spend our time figuring out how to make this more valuable for you than walking through results you're not excited about. What's the biggest marketing question you're trying to answer right now?"
3. Connect MixLift to their stated problem. If MixLift can't address it, be honest: "That's not something we can help with today, but here's what we can show you..."
4. Schedule a shorter follow-up (15 min) in 3-4 days rather than waiting 2 weeks.

---

## Churn Signal Severity Matrix

| Signals Present | Severity | Action Timeline |
|----------------|----------|-----------------|
| Any 1 signal | Monitor | Address at next scheduled touchpoint |
| Signal 5 (cancellation questions) alone | Critical | Within 2 hours |
| Signal 4 (accuracy concerns) alone | High | Within 4 hours |
| Any 2 signals combined | High | Within 24 hours |
| 3+ signals combined | Critical | Same day. Phone call. |
| Signal 1 + Signal 5 (no usage + cancel question) | Critical | Immediate. Likely lost but attempt save. |

---

## Tracking Template

Maintain this log for each at-risk customer:

| Date | Customer | Signals Observed | Action Taken | Outcome | Follow-Up Date |
|------|----------|-----------------|-------------|---------|---------------|
| | | | | | |

Review this log every Monday alongside the retention health check dashboard.
