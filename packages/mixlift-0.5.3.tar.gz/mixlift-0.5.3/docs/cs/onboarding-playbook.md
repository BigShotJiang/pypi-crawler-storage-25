# MixLift Onboarding Playbook (First 5 Customers)

**Owner:** Founder (all customer interactions)
**Source:** Appendix A of OPERATING_PLAN.md, expanded with templates and escalation paths
**Last updated:** 2026-03-07

---

## Guiding Principles

1. **Concierge is the product.** For the first 10 customers, the founder IS the product. Do the setup for them. Sit on the call while the model runs. Interpret the results together.
2. **Speed kills churn.** The faster a customer sees their own dollar headline, the more likely they renew. Day 0 is everything.
3. **Don't wait for them to ask.** Every touchpoint is proactive. If a customer goes quiet, that is a signal, not permission to relax.
4. **Document everything.** Every call, every question, every friction point feeds back into the product and this playbook.

---

## Day 0: Live Demo + MCP Setup (MOST CRITICAL)

**Goal:** Customer sees their own data analyzed and gets MixLift running independently on their machine.

### Call Agenda (45-60 minutes)

| Time | Activity | Notes |
|------|----------|-------|
| 0-5 min | Welcome, confirm they have their CSV ready | If no CSV, use sample dataset as fallback |
| 5-15 min | Run MixLift on THEIR data via screenshare | You run it on your machine first to show them |
| 15-25 min | Walk through results together | Focus on the dollar headline and one surprising finding |
| 25-40 min | Install MixLift on THEIR machine (screenshare) | Follow the MCP setup guide step by step |
| 40-50 min | They run an analysis independently while you watch | Confirm it works end-to-end on their machine |
| 50-60 min | Quick intro to scenario mode, next steps | Tee up the Day 7 interpretation call |

### MCP Setup Steps (Do This ON Their Machine via Screenshare)

Refer to `/Users/felix/software-projects/mixlift/docs/cs/mcp-setup-guide.md` for the full guide. The abbreviated version for the live call:

1. Check Python version: `python3 --version` (need 3.11+)
2. Install MixLift: `pip install mixlift`
3. Open Claude Desktop config:
   - macOS: `open ~/Library/Application\ Support/Claude/claude_desktop_config.json`
   - Windows: Navigate to `%APPDATA%\Claude\claude_desktop_config.json`
4. Add the MixLift server config:
   ```json
   {
     "mcpServers": {
       "mixlift": {
         "command": "mixlift-mcp"
       }
     }
   }
   ```
5. Set license key as environment variable:
   - macOS: Add `export MIXLIFT_LICENSE_KEY="their-key-here"` to `~/.zshrc`, then restart terminal
   - Windows: System Settings > Environment Variables > New > `MIXLIFT_LICENSE_KEY` = `their-key-here`
6. Restart Claude Desktop
7. Test: Ask Claude "Run mixlift_analyze on /path/to/their/data.csv"

### First Analysis Walkthrough Script

When results appear, walk them through in this order:

1. **Dollar headline:** "See this number at the top? That's how much additional revenue the model thinks you could capture by reallocating your current budget. No extra spend -- just moving dollars between channels."
2. **ROAS table:** "This shows return on ad spend per channel. [Highest channel] is your best performer at [X]x -- every dollar there generates [X] dollars of revenue. [Lowest channel] at [Y]x might be worth pulling back."
3. **Saturation traffic lights:** "Green means room to scale. Yellow means approaching diminishing returns. Red means you're past the point of efficiency. Look at [red channel] -- the model says you're oversaturated there."
4. **Budget optimizer:** "Here's the specific reallocation the model recommends. It suggests moving $[X] from [channel A] to [channel B]."
5. **Teaser for scenario mode:** "Next week we'll dig into 'what if' scenarios -- like what happens if you cut [channel] by 20%. That's where it gets really powerful."

### Success Criteria

- Customer has MixLift installed and running on their own machine
- Customer has seen their own data analyzed with a dollar headline
- Customer can articulate one insight they did not have before ("I didn't know Meta was that saturated")
- Day 7 interpretation call is scheduled on the calendar

### Email Template: Post-Setup Confirmation

**Subject:** You're live on MixLift -- here's your summary

**Body:**

```
Hi [Name],

Great call today. Here's a quick recap of what we found:

HEADLINE: Your model suggests a potential [X]% revenue lift ($[Y]/month)
by reallocating your current budget -- no additional spend needed.

KEY FINDINGS:
- [Channel A] is your strongest performer at [X]x ROAS
- [Channel B] is [saturated/approaching saturation] -- the model suggests
  reducing spend by [X]%
- Moving $[X] from [Channel B] to [Channel A] could drive an estimated
  $[Y] in additional monthly revenue

YOUR SETUP:
- MixLift is installed on your machine
- Your license key is active (Growth plan, unlimited analyses)
- Your data file is at: [path they saved it]

TO RUN ANOTHER ANALYSIS:
Open Claude Desktop and type:
"Run mixlift_analyze on [/path/to/their/data.csv]"

TO TRY SCENARIO MODE:
"Run mixlift_analyze on [/path/to/their/data.csv] with scenario
'cut [channel] by 20%'"

We have our deep-dive interpretation call scheduled for [Day 7 date].
Between now and then, try running it yourself and jot down any questions.

If anything isn't working, reply to this email and I'll jump on a call
same day.

Best,
[Founder name]
```

### Escalation: Customer Can't Get Setup Working

If MCP setup fails during the live call:

1. **Don't panic.** Stay on the call. Most issues are Python version or PATH problems.
2. Check the troubleshooting section of the MCP setup guide.
3. If unresolvable in 10 minutes, pivot: "Let me run the analysis on my machine for now. I'll send you the results and we'll debug your setup async."
4. Send them the MCP setup guide link and schedule a 15-minute follow-up call for the next day.
5. Log the issue -- it feeds back into the setup guide.

---

## Day 1: Follow-Up Email

**Goal:** Confirm they can run independently. Reinforce the key finding. Keep momentum.

### Email Template

**Subject:** Quick follow-up: try running it yourself

**Body:**

```
Hi [Name],

Just checking in after yesterday. Two things:

1. HAVE YOU TRIED RUNNING IT YOURSELF?
   Open Claude Desktop and ask:
   "Run mixlift_analyze on [/path/to/their/data.csv]"

   You should see the same results we reviewed together. If anything
   looks different or you hit an error, just reply here.

2. SOMETHING TO THINK ABOUT BEFORE OUR CALL ON [DAY 7 DATE]:
   That finding about [specific insight from their analysis] -- has that
   changed how you're thinking about your [channel] spend this week?

No rush to reply. Just wanted to make sure everything is running smoothly.

Best,
[Founder name]
```

### Success Criteria

- Customer replies confirming they ran an analysis (ideal)
- OR customer replies with a question (still engaged)
- If no reply by end of Day 2, proceed to Day 3 touchpoint

### Escalation: No Reply

If no reply by end of Day 1, do not send another email. Wait for the Day 3 touchpoint. One email per day is the maximum cadence in the first week.

---

## Day 3: Check-In Message

**Goal:** Catch installation or usage friction early. Surface questions they are too polite to ask.

### Message Template (Email or LinkedIn DM, whichever channel they prefer)

**Subject:** Quick check-in

**Body:**

```
Hi [Name],

Quick check-in -- were you able to run MixLift on your own since our
setup call?

A few things people commonly ask at this point:

- "Can I update my CSV and re-run?" -- Yes, just update your file and
  run the same command. MixLift will remember your previous analysis and
  show you what changed.

- "What if I add a new channel?" -- Add a new [channel]_spend column to
  your CSV. MixLift will pick it up automatically.

- "How often should I re-run?" -- Weekly or biweekly works well. The
  model gets better with more data, and you'll see trend deltas over time.

Anything else on your mind? Our deep-dive call is on [Day 7 date] --
looking forward to it.

Best,
[Founder name]
```

### Success Criteria

- Customer confirms they have run at least one analysis independently
- Customer asks a question (indicates engagement)
- Any friction points are identified and addressed

### Escalation: Customer Not Engaging

If no reply to Day 1 email AND no reply to Day 3 message:

1. **Do not send another written message.** Switch channels.
2. If you have their phone number, send a brief text: "Hey [Name], just wanted to make sure MixLift is working for you. Happy to jump on a quick call if you're hitting any snags."
3. If no phone number, send a LinkedIn voice message (30 seconds max).
4. If still no response by Day 5, call them directly if you have the number.
5. If no contact by Day 7, keep the scheduled call but prepare for a possible cancellation conversation.

**Root cause investigation:** Non-engagement in the first 3 days usually means one of:
- Setup didn't actually work (they were too polite to say so on the call)
- They haven't had time (they're busy, not disinterested)
- Buyer's remorse (they don't see the value yet)

The Day 7 call is designed to address all three.

---

## Day 7: Interpretation Deep-Dive Call

**Goal:** Deepen engagement beyond "one-time diagnosis." Demonstrate ongoing value through scenario mode. Transition from "tool I tried" to "tool I use."

### Call Agenda (30 minutes)

| Time | Activity | Notes |
|------|----------|-------|
| 0-5 min | Check in: How did the first week go? Any questions? | Listen for friction signals |
| 5-10 min | Re-run analysis on fresh data (if they have it) | Show memory deltas: "Your Meta ROAS moved from 2.3x to 2.5x" |
| 10-20 min | Scenario mode walkthrough | Run 2-3 scenarios they care about |
| 20-25 min | Discuss what actions they've taken or plan to take | Connect MixLift output to real budget decisions |
| 25-30 min | Set expectations for next 3 weeks | Mention the Day 21 pre-renewal check-in |

### Scenario Mode Demo Script

"Let me show you something powerful. Let's say you're thinking about cutting your [weakest channel] spend. Ask Claude:"

> "Run mixlift_analyze on [path] with scenario 'cut [channel] by 20%'"

"See that? The model projects a [X]% change in revenue. Now let's try moving that money to [strongest channel]:"

> "Run mixlift_analyze on [path] with scenario 'move $[X] from [channel A] to [channel B]'"

"Now you can test budget decisions before you make them. Try a few on your own -- what scenarios are you curious about?"

### Success Criteria

- Customer runs at least one scenario mode analysis during the call
- Customer articulates a specific budget action they plan to take based on MixLift data
- Customer expresses interest in re-running with updated data
- No unresolved technical issues

### Email Template: Post-Call Summary

**Subject:** Scenarios we explored + next steps

**Body:**

```
Hi [Name],

Great call today. Here's what we explored:

SCENARIOS TESTED:
1. [Scenario 1]: Projected [X]% revenue change
2. [Scenario 2]: Projected [X]% revenue change
3. [Scenario 3]: Projected [X]% revenue change

YOUR PLANNED ACTIONS:
- [Action they mentioned, e.g., "Reduce TikTok spend by 15% next week"]
- [Action 2, if applicable]

WHAT TO DO NEXT:
- Make the budget changes you mentioned
- After 1-2 weeks of new data, update your CSV and re-run
- MixLift will show you deltas: how your ROAS per channel changed since
  Day 0

I'll check in around [Day 14 date] to see how the changes are playing
out. In the meantime, run as many scenarios as you like -- that's what
unlimited analyses are for.

Best,
[Founder name]
```

### Escalation: Customer Seems Disengaged on Call

Signs: short answers, camera off, checking other screens, "yeah it's fine."

1. **Ask directly:** "I want to make sure this is delivering value for you. On a scale of 1-10, how useful has MixLift been so far?"
2. If they score 6 or below, ask: "What would make it more useful?"
3. Common responses and how to handle:
   - "I haven't had time to use it" -- Offer to run their analysis right now together. Reduce friction.
   - "I'm not sure I trust the numbers" -- Walk through the confidence intervals. Acknowledge limitations for short data.
   - "It told me what I already knew" -- Run a scenario they haven't considered. Show marginal ROAS. Find the non-obvious insight.
   - "My boss needs a PDF" -- Note this. Log it as signal for report export feature.
4. If the call goes poorly, schedule a follow-up in 3 days rather than waiting for Day 14.

---

## Day 14: Async Check-In

**Goal:** Trigger a second analysis. Get them using MixLift as a recurring workflow, not a one-time tool. Memory deltas kick in here.

### Message Template

**Subject:** Time for a fresh look at your numbers?

**Body:**

```
Hi [Name],

It's been two weeks since we set you up on MixLift. If you've got
updated spend data (even just 1-2 new weeks added to your CSV), now is
a great time to re-run.

Here's why: MixLift remembers your Day 0 analysis. When you re-run,
it shows you what changed:

- Which channels' ROAS went up or down
- Whether your saturation levels shifted
- How the optimal allocation evolved with new data

TO RE-RUN:
Just update your CSV with the latest weeks and ask Claude:
"Run mixlift_analyze on [/path/to/their/data.csv]"

A FEW QUESTIONS FOR YOU:
- Did you make any budget changes based on what we found?
- If so, how are those changes performing?
- Anything surprising in the last two weeks?

I'd love to hear how it's going. And if you want to jump on a quick
call to review the new results together, just reply and we'll find a time.

Best,
[Founder name]
```

### Success Criteria

- Customer has run at least one additional analysis since Day 7
- Customer has updated their CSV with new data
- Customer mentions a budget decision influenced by MixLift
- Customer replies (even briefly)

### Escalation: No Analysis Since Day 7

Check the `last_validated_at` timestamp in the license database. If there has been no license validation call since Day 7:

1. This customer is at risk. They are paying but not using the product.
2. Send the Day 14 email as written, but add a personal note at the top: "I noticed it's been a bit since your last run -- totally normal during a busy stretch. Want me to run a quick analysis on your latest data and send you the highlights?"
3. Offer to do the work for them. Lower the bar to zero effort.
4. If no reply by Day 16, phone call or text. This is pre-churn behavior.
5. Log this customer in the retention health check as "at risk."

---

## Day 21: Pre-Renewal Call

**Goal:** Run a fresh analysis together. Show the journey from Day 0 to now. Make renewal feel like the obvious decision.

### Call Agenda (30 minutes)

| Time | Activity | Notes |
|------|----------|-------|
| 0-5 min | Check in: What's happened since Day 14? | Listen for budget actions taken |
| 5-15 min | Run fresh analysis together | Highlight memory deltas from Day 0 |
| 15-20 min | Review actions taken and results | "You cut TikTok by 15% -- let's see how ROAS responded" |
| 20-25 min | Forward-looking scenarios | What are they planning for next month? |
| 25-30 min | Renewal framing | "Your subscription renews on [date]. Here's what's coming next month." |

### Renewal Framing Script

"Your subscription auto-renews on [date] through Stripe -- you don't need to do anything. I wanted to share what we're working on for next month:

- [Mention one upcoming improvement, e.g., 'model quality scores so you can see how well the model fits your specific data']
- We'll keep the concierge support going -- any time you want to hop on a call and review results, just ping me.

Based on what we've seen so far, MixLift has identified $[X] in potential reallocation gains for you. Even if you capture half of that, the $299 is paying for itself [X] times over."

### Success Criteria

- Customer sees concrete before/after deltas from Day 0 to Day 21
- Customer acknowledges value received (specific dollar impact or insight)
- Customer does not express intent to cancel
- If customer raises concerns, they are addressed on the call (not deferred)

### Email Template: Post-Call

**Subject:** Your MixLift journey so far

**Body:**

```
Hi [Name],

Great catching up today. Here's a snapshot of your progress:

DAY 0 vs. TODAY:
- [Channel A] ROAS: [Day 0 value] -> [Day 21 value] ([direction])
- [Channel B] ROAS: [Day 0 value] -> [Day 21 value] ([direction])
- Budget reallocation potential: $[Day 0 value] -> $[Day 21 value]

ACTIONS YOU'VE TAKEN:
- [List specific budget changes they made based on MixLift]

WHAT'S NEXT:
- Your subscription renews on [date] -- no action needed
- Keep updating your CSV weekly for the sharpest results
- [Mention upcoming feature if relevant]

As always, I'm here whenever you want to dig into the numbers. Just
reply to this email or grab time on my calendar: [link]

Best,
[Founder name]
```

### Escalation: Customer Signals Cancellation Intent

If the customer says anything like "I'm not sure I'll keep using it" or "Can I cancel?":

1. **Do not get defensive.** Say: "Totally understand. Can you help me understand what's not working? I want to make sure you got value."
2. Listen. Write down their reasons verbatim.
3. Common reasons and responses:
   - "I only needed it once" -- "The real power is tracking over time. Your model gets better with more data, and the deltas show you whether your changes are working. Can we try one more month with weekly runs?"
   - "I don't trust the numbers" -- "That's fair feedback. Can you tell me specifically what felt off? I want to investigate." (Then actually investigate and report back within 24 hours.)
   - "It's too expensive for what I get" -- "What would make it worth $299 to you?" (Listen. This is product feedback.)
   - "I don't have time" -- "What if I ran the analysis for you every week and sent you a 3-bullet summary? Would that be valuable?" (Offer this as a temporary concierge service.)
4. If they still want to cancel, be gracious: "I'll process that for you. Would you be open to a 5-minute call in a month to share what you ended up doing instead? That feedback helps me build a better product."
5. Log the reason in the churn risk signals doc.

---

## Day 30: Post-Renewal

**Goal:** Retain. Collect feedback. Set up the second month for success.

### Email Template (Send on renewal date or day after)

**Subject:** Month 2 -- here's what's coming

**Body:**

```
Hi [Name],

Thanks for sticking with MixLift. Month 1 recap:

BY THE NUMBERS:
- Analyses run: [X]
- Scenarios tested: [X]
- Estimated reallocation opportunity identified: $[X]/month

WHAT'S NEW THIS MONTH:
- [Feature or improvement, e.g., "We've improved model confidence
  scoring -- you'll now see a fit quality grade with each analysis"]
- [Second item if applicable]

A QUICK ASK:
I'd love your honest feedback on one question: What is the single most
useful thing MixLift has shown you so far?

(And if you have a second: what's the one thing you wish it did better?)

Reply whenever you have a minute. Your feedback directly shapes what we
build next.

Best,
[Founder name]
```

### Success Criteria

- Renewal processed successfully (Stripe automatic)
- Customer replies with feedback (ideal)
- Customer has run 3+ analyses in Month 1
- No cancellation signal

### Escalation: Renewal Fails (Payment Issue)

1. Check Stripe for the failure reason (expired card, insufficient funds, etc.)
2. Send within 2 hours:

**Subject:** Quick heads up -- payment didn't go through

**Body:**

```
Hi [Name],

Heads up -- your MixLift renewal payment didn't process (looks like
[reason, e.g., "the card on file needs updating"]).

No rush, but you can update your payment method here: [Stripe billing
portal link]

Your access stays active while we sort this out. Let me know if you
need anything.

Best,
[Founder name]
```

3. If not resolved in 3 days, follow up once more. After 7 days with no payment, treat as churn.

---

## Touchpoint Summary

| Day | Type | Duration | Primary Goal | Escalation Trigger |
|-----|------|----------|-------------|-------------------|
| 0 | Live call | 45-60 min | Setup + first analysis + aha moment | Setup fails -> async debug + next-day call |
| 1 | Email | Async | Confirm independent usage | No reply -> wait for Day 3 |
| 3 | Message | Async | Catch friction early | No reply to Day 1 AND Day 3 -> switch channels |
| 7 | Live call | 30 min | Scenario mode + deepen engagement | Disengaged on call -> follow-up in 3 days |
| 14 | Email | Async | Trigger second analysis + memory deltas | No analysis since Day 7 -> offer to run for them |
| 21 | Live call | 30 min | Pre-renewal + show progress | Cancel intent -> listen, address, offer concierge |
| 30 | Email | Async | Retain + collect feedback | Payment failure -> same-day outreach |

---

## Appendix: Metrics to Track Per Customer

Maintain this for each customer in your CRM or pipeline tracker:

| Metric | Where to Find It |
|--------|-----------------|
| Last analysis date | `last_validated_at` in license database |
| Total analyses run | License API logs (count of validation calls) |
| Scenario mode usage | License API logs (look for scenario parameter) |
| Support tickets filed | Email/GitHub issues |
| NPS or satisfaction score | Ask at Day 7 and Day 21 calls |
| Budget actions taken | Self-reported on calls |
| Renewal status | Stripe dashboard |
