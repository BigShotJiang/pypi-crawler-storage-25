# Retention Health Check Template

**Owner:** Founder
**Frequency:** Run at Day 14 and Day 21 for each customer, then monthly after renewal
**Last updated:** 2026-03-07

---

## Instructions

Complete this checklist for each customer at the specified intervals. Any "No" answer is a signal that requires action. Two or more "No" answers in a single check means the customer is at risk -- see Intervention Actions below.

---

## Day 14 Health Check

**Customer:** _______________
**License Key:** _______________
**Date:** _______________
**Check performed by:** Founder

### Usage Signals

| # | Question | Yes/No | Notes |
|---|----------|--------|-------|
| 1 | Has the customer run at least 2 analyses since Day 0? | | Check `last_validated_at` in license DB |
| 2 | Has the customer run at least 1 analysis in the past 7 days? | | |
| 3 | Has the customer used scenario mode at least once? | | Check API logs for scenario parameter |
| 4 | Has the customer updated their CSV with new data? | | Ask them, or infer from memory deltas in results |

### Engagement Signals

| # | Question | Yes/No | Notes |
|---|----------|--------|-------|
| 5 | Did the customer reply to the Day 1 follow-up email? | | |
| 6 | Did the customer reply to the Day 3 check-in? | | |
| 7 | Did the customer attend the Day 7 interpretation call? | | |
| 8 | Has the customer asked any questions about their results? | | Via email, call, or chat |
| 9 | Has the customer mentioned a budget action taken based on MixLift? | | |

### Sentiment Signals

| # | Question | Yes/No | Notes |
|---|----------|--------|-------|
| 10 | On the Day 7 call, did the customer score satisfaction 7+ out of 10? | | If you asked |
| 11 | Has the customer expressed any frustration or skepticism about accuracy? | | Note specific concerns |
| 12 | Has the customer asked about cancellation or billing? | | Major red flag if yes |

### Day 14 Score

- **Questions 1-4 (Usage):** ___/4 Yes answers
- **Questions 5-9 (Engagement):** ___/5 Yes answers
- **Questions 10-12 (Sentiment):** See notes

**Overall assessment:**
- GREEN (7+ Yes out of 9, no red flags in 10-12): Customer is on track. Continue standard playbook.
- YELLOW (4-6 Yes out of 9, or minor concerns in 10-12): Customer needs attention. Execute intervention actions.
- RED (3 or fewer Yes out of 9, or cancellation questions): Customer is at risk. Immediate action required.

---

## Day 21 Health Check (Pre-Renewal)

**Customer:** _______________
**License Key:** _______________
**Date:** _______________
**Check performed by:** Founder

### Usage Signals

| # | Question | Yes/No | Notes |
|---|----------|--------|-------|
| 1 | Has the customer run at least 4 analyses total since Day 0? | | |
| 2 | Has the customer run at least 1 analysis in the past 7 days? | | |
| 3 | Has the customer used scenario mode at least twice? | | |
| 4 | Has the customer updated their CSV with new data at least once? | | |
| 5 | Has the customer run an analysis without founder assistance? | | Key independence indicator |

### Engagement Signals

| # | Question | Yes/No | Notes |
|---|----------|--------|-------|
| 6 | Is the Day 21 pre-renewal call scheduled? | | Should be booked by now |
| 7 | Has the customer been responsive to async messages (replies within 48 hrs)? | | |
| 8 | Has the customer mentioned MixLift results in a business context? | | E.g., "I shared this with my team" or "We adjusted our Meta budget" |
| 9 | Has the customer asked for any feature or improvement? | | Good sign -- they're thinking about using it more |

### Value Realization Signals

| # | Question | Yes/No | Notes |
|---|----------|--------|-------|
| 10 | Has the customer made at least one budget change based on MixLift? | | Strongest retention signal |
| 11 | Can the customer articulate a specific insight MixLift provided? | | Ask on Day 21 call |
| 12 | Does the customer view MixLift as ongoing (vs. one-time)? | | Listen for language: "next month" vs. "I got what I needed" |

### Renewal Risk Assessment

| # | Question | Yes/No | Notes |
|---|----------|--------|-------|
| 13 | Has the customer asked about cancellation? | | |
| 14 | Has the customer mentioned budget constraints? | | |
| 15 | Is the customer's payment method valid in Stripe? | | Check Stripe dashboard |

### Day 21 Score

- **Questions 1-5 (Usage):** ___/5 Yes answers
- **Questions 6-9 (Engagement):** ___/4 Yes answers
- **Questions 10-12 (Value):** ___/3 Yes answers
- **Questions 13-15 (Risk):** See notes (13 and 14 "No" is good; 15 "Yes" is good)

**Overall assessment:**
- GREEN (9+ Yes out of 12 positive indicators, no risk flags): Renewal is likely. Standard Day 21 call.
- YELLOW (6-8 Yes, or minor risk flags): Renewal is uncertain. Day 21 call needs to focus on value demonstration.
- RED (5 or fewer Yes, or cancellation questions): High churn risk. See Intervention Actions.

---

## Monthly Health Check (Post-Renewal, Ongoing)

**Customer:** _______________
**Month #:** ___
**Date:** _______________

| # | Question | Yes/No | Notes |
|---|----------|--------|-------|
| 1 | Customer ran at least 2 analyses this month | | |
| 2 | Customer used scenario mode this month | | |
| 3 | Customer updated their CSV with fresh data | | |
| 4 | Customer was responsive to check-in messages | | |
| 5 | Customer mentioned a budget action based on MixLift | | |
| 6 | No complaints about accuracy or value | | "No" if complaints were raised |
| 7 | Payment processed successfully | | Check Stripe |

**Score:** ___/7

- GREEN (5+): Healthy customer. Light-touch check-in next month.
- YELLOW (3-4): Engagement dropping. Proactive outreach needed.
- RED (0-2): At risk. Immediate intervention.

---

## Intervention Actions

### For YELLOW Customers

1. **Send a personalized value recap.** Show them specific findings from their analyses: "Your MixLift analyses have identified $X in reallocation opportunity. Here's what we've found so far..."
2. **Offer a live session.** "Want to hop on a 15-minute call? I'd love to walk through your latest results and show you a few scenario mode tricks."
3. **Lower the bar.** Offer to run the analysis for them and send results: "I know you're busy. Want me to run your latest data and send you a summary?"
4. **Ask what's missing.** "Is there something MixLift could show you that would make it more useful for your workflow?"

### For RED Customers

1. **Phone call within 24 hours.** Do not wait for them to respond to email. Call them.
2. **Lead with empathy, not a save pitch.** "I noticed you haven't been using MixLift much lately. I want to understand what's happening -- is there something that's not working for you?"
3. **Diagnose the root cause:**
   - **Technical friction:** Offer to redo setup, run analyses for them, simplify their workflow.
   - **Trust issue:** Walk through the model methodology. Show confidence intervals. Offer to compare MixLift recommendations against their known performance.
   - **No perceived value:** Ask what they expected vs. what they got. Can you reframe the value?
   - **Budget constraints:** Consider offering a one-month discount to retain them while they evaluate.
4. **Document everything.** Every churn conversation is product intelligence.
5. **If they still want to cancel:** Be gracious. Ask for a 5-minute exit interview. Log the reason.

---

## Customer Health Dashboard (Aggregate View)

Maintain a simple table across all active customers:

| Customer | Start Date | Last Analysis | Analyses This Month | Scenario Mode Used | Health Status | Next Action | Next Action Date |
|----------|-----------|---------------|--------------------|--------------------|---------------|-------------|-----------------|
| | | | | | GREEN/YELLOW/RED | | |

Review this table weekly (every Monday). Any customer who has been YELLOW for 2+ weeks should be escalated to RED.
