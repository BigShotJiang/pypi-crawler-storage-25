# Net Revenue Retention (NRR) Tracker

For a solo founder managing the first cohort of customers.
Copy each section into a separate tab in Google Sheets.

---

## Tab 1: Customer Health & Ledger

*Master database. Tracks individual customer health signals (usage) which are leading indicators for retention.*

| Customer ID | Customer Name | Cohort (Month) | Tier | MRR | Status | Last Analysis Date | Total Runs | Scenario Mode Usage | Health Score |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| CUST-001 | | 2026-04 | Growth | $299 | Active | | 0 | No | New |
| CUST-002 | | 2026-04 | Growth | $299 | Active | | 0 | No | New |
| CUST-003 | | 2026-04 | Growth | $299 | Active | | 0 | No | New |
| CUST-004 | | 2026-05 | Growth | $299 | Active | | 0 | No | New |
| CUST-005 | | 2026-05 | Growth | $299 | Active | | 0 | No | New |

**Formulas:**

- **MRR (Column E):** `=IF(D2="Growth", 299, IF(D2="Pro", 799, IF(D2="Agency", 1499, 0)))`
- **Health Score (Column J):** `=IF(F2="Churned", "Lost", IF(AND(H2>10, I2="Yes"), "Healthy", IF(H2>5, "OK", "Watch")))`

---

## Tab 2: Monthly NRR Calculator

*High-level financial view. Update once a month.*

| Metric | Description | Month 1 | Month 2 | Month 3 | Month 4 | Month 5 | Month 6 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **A. Starting MRR** | Revenue at start of month | $0 | | | | | |
| **B. New MRR** | Revenue from new customers | | | | | | |
| **C. Expansion MRR** | Upgrades (Growth -> Pro) | $0 | | | | | |
| **D. Contraction MRR** | Downgrades | $0 | | | | | |
| **E. Churned MRR** | Lost revenue from cancellations | $0 | | | | | |
| **F. Ending MRR** | A + B + C - D - E | | | | | | |
| **G. Net Revenue Retention** | (A + C - D - E) / A | N/A | | | | | |
| **H. Gross MRR (incl new)** | F | | | | | | |

**Formulas:**

- **Starting MRR (Row A):** Month 1 = `0`. Month 2+ = previous month's Ending MRR.
- **NRR % (Row G):** `=IF(A2=0, "N/A", (A2 + C2 - D2 - E2) / A2)`
  - Note: NRR excludes new customers. It measures whether your existing base is growing or shrinking.
- **Ending MRR (Row F):** `=A2 + B2 + C2 - D2 - E2`

---

## Tab 3: Cohort Revenue Grid

*Visualize "sticky revenue" by seeing which customers stick around month-over-month.*

| Cohort | Customer | Tier | Month 1 | Month 2 | Month 3 | Month 4 | Month 5 | Month 6 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Apr 2026 | Customer 1 | Growth | $299 | $299 | | | | |
| Apr 2026 | Customer 2 | Growth | $299 | $299 | | | | |
| Apr 2026 | Customer 3 | Growth | $299 | $0 | | | | |
| May 2026 | Customer 4 | Growth | | $299 | | | | |
| May 2026 | Customer 5 | Growth | | $299 | | | | |
| **Cohort Totals** | | | | | | | | |

---

## Tab 4: Running Churn Tracker

*Track logo churn against strategic targets.*

| Month | Starting Customers | New | Lost | Ending Customers | Monthly Logo Churn % | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Apr 2026 | 0 | | 0 | | 0% | |
| May 2026 | | | 0 | | | |
| Jun 2026 | | | 0 | | | |
| Jul 2026 | | | 0 | | | |

**Formulas:**

- **Monthly Logo Churn %:** `=IF(B2=0, 0%, C2/B2)`
- **Status (conditional):**
  - `< 3%` = "Venture Scale"
  - `3% - 5%` = "Viable SaaS"
  - `> 5%` = "Lifestyle Risk"

---

## Google Sheets Setup

### Conditional Formatting Rules

1. **NRR % (Tab 2):** Value < 100% = Red background. Value >= 100% = Green background.
2. **Churn Status (Tab 4):** "Lifestyle" = Red. "Venture" = Green. "Viable" = Yellow.
3. **Health Score (Tab 1):** "Watch" = Yellow. "Lost" = Grey. "Healthy" = Green.

### Solo Founder Workflow

1. **Daily:** Check Tab 1. If any customer's "Last Analysis Date" is >14 days ago, change status to "Watch" and email them.
2. **Weekly:** Review Health Scores. Any "Watch" customer gets a personal check-in.
3. **Monthly (Day 1):** Update Tab 2 (expansion/churn). Check Tab 4. If churn >5%, stop selling and start fixing the product.

### The Strategic Thresholds

- **Monthly churn >5%:** Lifestyle business. Caps at ~$500K ARR.
- **Monthly churn 3-5%:** Viable SaaS. Can reach $1-3M ARR.
- **Monthly churn <3%:** Venture-scale. Compounding math works. Raise a seed round.
