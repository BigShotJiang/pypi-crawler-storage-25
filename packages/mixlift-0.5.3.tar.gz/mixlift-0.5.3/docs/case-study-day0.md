# Case Study: How a DTC Beauty Brand Found $41,000/Month in Wasted Ad Spend

**GlowHaus (anonymized) | 8 channels | $480K annual ad budget | 52 weeks of data**

---

## The Situation

GlowHaus is a DTC skincare brand doing $5.6M in annual revenue. Their marketing team manages eight channels with a total ad budget of roughly $40,000 per month in the off-season, scaling to $80,000/month during the Q4 holiday push.

Like most DTC brands, they allocated budget based on platform-reported ROAS from Google Ads and Meta Ads Manager. Google Search was their largest line item ("it always shows the highest ROAS in Google Analytics"), and they had recently started testing TikTok and YouTube at modest budgets.

Their question: **"Are we spending in the right places?"**

---

## The Analysis

GlowHaus exported 52 weeks of spend-by-channel data and ran it through MixLift. The Bayesian Marketing Mix Model took 4 minutes to fit and returned results that contradicted their platform dashboards.

---

## Finding 1: Google Search Is Over-Saturated

**Platform-reported ROAS: 5.2x. Actual marginal ROAS: 1.4x.**

Google Search received the most budget ($4,200-$6,400/week) and showed the highest ROAS in Google Analytics. But MixLift's saturation analysis revealed that Google Search hit diminishing returns above roughly $3,500/week. Every dollar above that threshold was generating only $0.40 in incremental revenue.

The platform-reported 5.2x ROAS was inflating the channel's value by counting revenue from customers who would have purchased anyway -- branded search queries from people who already knew GlowHaus.

> **Saturation: RED** -- Google Search is operating well past its saturation point.

---

## Finding 2: TikTok Is Massively Under-Invested

**Current weekly spend: $680-$1,500. Estimated saturation point: $3,800/week.**

TikTok was the newest channel in GlowHaus's mix, receiving less than 5% of total budget. MixLift estimated a marginal ROAS of 3.8x -- the highest of any channel -- with significant room to scale before hitting diminishing returns.

The model's confidence interval was moderate (the channel had limited spend history), but the directional signal was strong: TikTok was generating disproportionate revenue relative to its budget allocation.

> **Saturation: GREEN** -- TikTok has substantial room to scale.

---

## Finding 3: Meta Prospecting Shows Healthy but Declining Returns

**Current ROAS: 2.1x. Saturation: approaching.**

Meta Prospecting (cold audience campaigns on Facebook and Instagram) was GlowHaus's second-largest channel. It was performing well but beginning to show signs of diminishing returns above $5,000/week. The model recommended holding Meta Prospecting spend steady rather than increasing it.

Meta Retargeting, by contrast, showed strong returns at its current modest budget with no saturation signal -- retargeting a warm audience remains efficient.

> **Saturation: YELLOW** -- Meta Prospecting is approaching the efficiency ceiling.

---

## Finding 4: Email and Affiliate Are Quietly Efficient

Email marketing ($420-$680/week) showed a ROAS above 5x -- the highest in the mix. This makes sense: email targets existing customers and subscribers at near-zero marginal cost. The model confirmed that email spend was the most capital-efficient channel but noted it has a natural ceiling (you can only email the list you have).

Affiliate marketing showed consistent 2.5-3x returns with no saturation signal, suggesting room for modest expansion.

---

## The Recommendation

MixLift's budget optimizer held total spend constant and recommended the following reallocation:

| Channel | Current Weekly | Recommended Weekly | Change |
|---|---|---|---|
| Google Search | $4,850 | $3,500 | -$1,350 |
| Meta Prospecting | $4,350 | $4,000 | -$350 |
| Meta Retargeting | $1,700 | $1,900 | +$200 |
| TikTok | $880 | $2,400 | +$1,520 |
| YouTube | $1,400 | $1,400 | -- |
| Email | $470 | $530 | +$60 |
| Affiliate | $950 | $1,020 | +$70 |
| Direct Mail | varies | no change | -- |

**Projected impact: +$10,300/week in revenue, or +$41,200/month, with the same total ad budget.**

The core move: cut $1,350/week from Google Search (which is past saturation) and redirect $1,520/week into TikTok (which has 2.5x the headroom). The remaining shifts fine-tune secondary channels.

---

## The Dollar Headline

> **Move $1,350/week from Google Search to TikTok for +$41,000/month in revenue -- with no increase in total ad spend.**

---

## What Made This Possible

Traditional attribution tools (Google Analytics, Meta Ads Manager) told GlowHaus that Google Search was their best channel. Platform attribution over-credits channels that capture demand rather than create it. Bayesian Marketing Mix Modeling measures the incremental impact of each dollar, accounting for saturation, diminishing returns, and cross-channel effects.

MixLift delivered this analysis in 4 minutes, from a single CSV upload, for $299/month. The equivalent analysis from a traditional analytics consultancy would cost $15,000-$50,000 and take 6-8 weeks.

---

## Try It Yourself

MixLift works inside Claude, Cursor, or any MCP-compatible AI assistant.

1. Install: `pip install mixlift`
2. Point it at your CSV: "Run mixlift_analyze on my_data.csv"
3. Get your dollar headline in under 5 minutes.

**Every DTC brand has a Google Search problem. MixLift finds it.**

[Start your free analysis at mixlift.io](https://mixlift.io)
