# MixLift GTM & Marketing Strategy

**Staff Marketing Manager | March 7, 2026 | 0 to 50 Customers**

*This is a comprehensive go-to-market plan built on the actual product state, competitive landscape, and existing assets. Every recommendation is prioritized by expected CAC efficiency and can be executed by a solo founder with no marketing budget.*

---

## Situation Assessment

Before strategy, the honest diagnosis:

**What we have:** A genuinely differentiated product (only Bayesian MMM under $500/mo), a novel distribution channel (MCP), solid sales assets (demo script, battle card, outreach templates, qualification scorecard), and a landing page. The product works end-to-end and a stranger can buy today.

**What we do not have:** Customers. Social proof. Inbound demand. Brand awareness. Email list. Community presence. Content track record. Any evidence that someone will pay $299/mo for this.

**The core marketing challenge:** We are selling a category (Bayesian MMM) that our buyers barely know exists, through a channel (MCP/Claude Desktop) most of them have never used, from a brand they have never heard of. Every one of those is a conversion barrier. The strategy must address all three simultaneously.

**The implication:** We cannot run demand generation for an unknown category on an unknown platform from an unknown brand and expect inbound to work in the first 60 days. Customers 1-15 are a sales problem, not a marketing problem. Marketing's job in the first 60 days is to create the conditions where outbound is easier (content that warms up cold prospects, social proof that closes skeptics) and to build the engine that generates inbound for customers 16-50.

---

## 1. Channel Strategy (Ranked by CAC Efficiency)

### Tier 1: Zero-Cost, High-Intent (Do This Week)

| Channel | Why | Tactic | Expected CAC | Volume |
|---|---|---|---|---|
| **LinkedIn organic (founder account)** | DTC marketing leaders live here. Founder credibility > brand account. | 3-5 posts/week. Teardown content, not product promotion. Build in public. | $0 | 2-5 demos/month by Month 2 |
| **Reddit (r/PPC, r/ecommerce, r/analytics)** | Practitioners with attribution pain. Self-qualifying audience. | 1 teardown post every 2 weeks. Comment CTA only. Never sell in body. | $0 | 1-3 demos/month |
| **LinkedIn outbound DMs** | Direct path to qualified buyers. Already have templates and qualification scorecard. | 10-15 personalized DMs/day. Use vertical templates. | $0 (time only) | 2-4 demos/week at 8-12% response rate |
| **MCP Marketplace listing** | Captures MCP early adopters who are actively browsing for tools. Zero effort after submission. | Submit the drafted listing. | $0 | Unknown -- small but zero maintenance |
| **Product Hunt launch** | One-day awareness burst. MCP angle is novel enough to get attention. | Prepare assets, launch on a Tuesday. Not before first 3 paying customers (need some social proof). Target: Week 6-8. | $0 | 50-200 installs, 2-5 conversions |

### Tier 2: Low-Cost, Audience Building (Start Week 2)

| Channel | Why | Tactic | Expected CAC | Volume |
|---|---|---|---|---|
| **Twitter/X** | MarTech, DTC, and data science communities are active. Good for short-form provocations. | Daily posts. Repurpose LinkedIn content. Engage with DTC and MMM conversations. Thread teardowns perform well. | $0 | Slow build. Expect meaningful inbound by Month 3. |
| **YouTube (short-form)** | "MixLift in 60 seconds" demo clips reusable across every channel. Long shelf life. SEO value. | 1 demo video (already planned). Cut into 3-4 short clips. One new video every 2 weeks. | $0 (time) | SEO tail compounds. 5-10 qualified views/day by Month 3. |
| **Hacker News** | Technical audience. MCP + PyMC-Marketing + AI-native angle plays well here. | "Show HN" post after Product Hunt. Frame as technical achievement, not SaaS pitch. | $0 | Burst. 500-2000 visits. 5-20 installs. 1-3 conversions. |
| **SEO (landing page + blog)** | "Marketing mix modeling" has 2,900 monthly searches. "Bayesian MMM" is growing. Long-tail plays. | Publish 2 SEO articles in Month 1. Target: "marketing mix modeling for DTC", "Bayesian MMM vs last-click attribution", "free marketing mix model tool". | $0 (time) | Slow. 100-500 organic visits/month by Month 3. Compounds. |

### Tier 3: Paid and Partnership (Start Month 2, Only After Proving Conversion)

| Channel | Why | Tactic | Expected CAC | Volume |
|---|---|---|---|---|
| **LinkedIn Ads** | Precise targeting: VP/Director of Marketing at DTC brands, 50-500 employees, ecommerce vertical. | Only after organic content identifies winning messages. Start with $1,000/month retargeting website visitors + lookalike of demo bookers. | $200-400 | 3-5 customers/month at scale |
| **Podcast sponsorships** | DTC-focused podcasts (Operators, Retention Radio, DTC Pod) have concentrated, high-intent audiences. | Guest spots first (free). Paid sponsorship of 1 podcast at $500-1,500/episode after Month 2. | $150-300 | 1-3 customers per sponsorship run |
| **Community partnerships** | Demand Curve, Reforge, Exit Five have curated audiences of growth leaders. | Apply to be featured in Demand Curve newsletter (free, earned). Offer exclusive teardown for Exit Five members. | $0-500 | 2-5 customers per feature |

### Channels to Deprioritize

| Channel | Why Not |
|---|---|
| **Google Ads** | "Marketing mix modeling" is searched by researchers and competitors, not buyers. CPC is high, intent is low. Revisit at $25K MRR. |
| **Instagram / TikTok (brand accounts)** | Our buyers use these to run ads, not to buy tools. Wrong context. |
| **Conferences / events** | Too expensive and too slow for pre-PMF. One trip costs $3-5K and reaches 50 people. LinkedIn reaches 50 people in a day. |
| **Display / programmatic ads** | CPMs too high for brand awareness at this stage. No retargeting audience to work with yet. |
| **PR / earned media** | No story yet. "We launched a SaaS" is not a story. "We grew from 0 to 50 customers in 90 days" is. Revisit after traction. |

---

## 2. Content Strategy: 90-Day Calendar

### Content Principles

1. **Lead with insight, never with product.** Every piece of content should teach something useful even if the reader never buys MixLift. The product is the punchline, not the opening line.
2. **Dollar numbers beat methodology.** "We found $47K in wasted spend" converts. "Our Bayesian MCMC engine uses PyMC-Marketing" does not.
3. **Teardowns beat tutorials.** Showing real (anonymized) analysis results is 10x more compelling than explaining how MMM works.
4. **Platform-native formatting.** Carousels on LinkedIn, threads on X, long-form on Reddit. Do not cross-post the same format everywhere.
5. **Controversy is reach.** "Your retargeting ROAS is a lie" gets shared. "How to improve your marketing attribution" does not.

### Month 1 (Days 1-30): Foundation

| Week | Content | Channel | Purpose |
|---|---|---|---|
| 1 | "5 Signs Your Ad Budget Has a Leak" carousel | LinkedIn | Demand creation. Problem-aware content. ASSET EXISTS. |
| 1 | 90-second Loom demo video | Landing page, LinkedIn, YouTube | Proof the product works. Reusable everywhere. |
| 1 | Reddit teardown post on r/PPC | Reddit | Credibility. Practitioner trust. ASSET EXISTS. |
| 2 | "Your Retargeting ROAS Is Inflated 5x. Here's the Math." thread | Twitter/X | Provocative angle. High share potential. |
| 2 | Blog post: "What Is Marketing Mix Modeling? (And Why DTC Brands Need It)" | mixlift.io/blog | SEO cornerstone. Target: "marketing mix modeling" keyword. |
| 3 | "I Ran Bayesian MMM on a DTC Brand's Data. Here's What Platform Attribution Got Wrong." long-form post | LinkedIn | Authority-building. Uses Reddit teardown data. |
| 3 | Blog post: "MixLift vs. Prescient AI vs. Robyn: Which MMM Tool Is Right for Your Brand?" | mixlift.io/blog | SEO comparison page. Captures competitor search traffic. |
| 4 | Short demo clip: "Finding $47K in wasted spend in 5 minutes" | YouTube Shorts, LinkedIn, Twitter | Visual proof. Reusable. |
| 4 | "The 3 Channels That Are Probably Lying to You About ROAS" carousel | LinkedIn | Follow-up to Week 1 carousel with new angle. |

### Month 2 (Days 31-60): Social Proof and Education

| Week | Content | Channel | Purpose |
|---|---|---|---|
| 5 | Customer case study #1 (with permission) | LinkedIn, landing page, blog | THE most important content asset. Real company, real numbers. |
| 5 | Blog post: "How to Prepare Your Data for Marketing Mix Modeling" | mixlift.io/blog | SEO + reduces activation friction for prospects. |
| 6 | "I Asked Our First 5 Customers What Surprised Them About Their MMM Results" | LinkedIn, Twitter | Social proof through customer voices. |
| 6 | Product Hunt launch | Product Hunt | Awareness burst. Time this for maximum momentum. |
| 7 | "Show HN: I Built Bayesian MMM as an MCP Tool for Claude" | Hacker News | Technical credibility. MCP angle is novel. |
| 7 | Blog post: "Why Your BI Dashboard Can't Replace a Marketing Mix Model" | mixlift.io/blog | SEO + objection handling content. |
| 8 | "The DTC Attribution Stack in 2026: What Actually Works" | LinkedIn long-form | Thought leadership. Positions MixLift in the broader ecosystem. |

### Month 3 (Days 61-90): Compounding and Conversion

| Week | Content | Channel | Purpose |
|---|---|---|---|
| 9 | Customer case study #2 | Blog, LinkedIn | Compound social proof. |
| 9 | "MMM Mistakes: 5 Things That Will Make Your Model Useless" | LinkedIn carousel, blog | Expert positioning. Addresses trust objection. |
| 10 | Guest post on a DTC newsletter or blog | Demand Curve, Reforge, or DTC media | Audience borrowing. Positions founder as expert. |
| 10 | "Monthly Media Mix Report: DTC Beauty Vertical" | LinkedIn, blog | First vertical benchmark content. Creates recurring series. |
| 11 | Video: "Live MMM Analysis of a Real DTC Brand" (20-min deep dive) | YouTube | Long-form authority. Reusable sales asset for demos. |
| 11 | Blog post: "Bayesian MMM vs. Multi-Touch Attribution: When to Use Which" | mixlift.io/blog | SEO. Captures people comparing methodologies. |
| 12 | "90-Day Retrospective: What We Learned Going from 0 to [X] Customers" | LinkedIn, Twitter, blog | Build-in-public milestone. Transparency builds trust. |

---

## 3. Demand Generation Plan: 0 to 50 Customers

### Phase 1: Customers 1-5 (Days 1-30) -- Pure Outbound

**Target:** 5 paying customers.
**Method:** 100% founder-led outbound sales.
**Cost:** $0 (founder time only).

**Specific tactics:**

1. **Build a prospect list of 200 qualified DTC brands.** Use LinkedIn Sales Navigator (free trial if needed). Filter: DTC ecommerce, 50-500 employees, Director/VP of Growth/Marketing. Run the qualification scorecard. Only demo prospects scoring 60+.

2. **Send 10-15 personalized LinkedIn DMs per day.** Use the vertical templates (beauty, food/bev, apparel) from outreach-templates.md. Personalize the first line with a specific observation about their brand (recent product launch, channel strategy visible from their ads library, etc.).

3. **Concierge demo on their data.** The demo script is solid. The key close: run the analysis live on their actual CSV during the Zoom call. Nothing sells like watching your own data reveal $47K in waste.

4. **Follow up relentlessly.** Day 1: recap email with key finding. Day 3: send the pricing one-pager. Day 7: "Just checking in -- did you get a chance to think about what we found?" Day 14: "I ran the numbers again with the latest week of data. Here is what changed."

**Expected conversion funnel:**

| Stage | Volume | Rate |
|---|---|---|
| DMs sent | 200 | -- |
| Responses | 20-30 | 10-15% |
| Demos booked | 10-15 | 50% of responses |
| Demos completed | 8-12 | 80% show rate |
| Closed | 3-6 | 30-50% close rate |

**Why this works at this stage:** $299/mo is below the threshold where most VPs need committee approval. The live demo on their data is the ultimate proof. Concierge touch justifies the price.

### Phase 2: Customers 5-15 (Days 30-60) -- Outbound + Content Flywheel

**Target:** 15 total paying customers.
**Method:** Continued outbound (50%) + inbound from content (30%) + referrals from happy customers (20%).
**Cost:** $0-500.

**New tactics layered on top of Phase 1:**

1. **Case study from first customers.** Get explicit permission. Anonymized is fine. "DTC beauty brand finds $32K/month in wasted retargeting spend." Publish on landing page, LinkedIn, and blog. This is your single most important marketing asset.

2. **Ask every paying customer for 1 introduction.** "Is there anyone on your team or in your network who faces the same attribution challenges?" At $299/mo, the ask is low-stakes. Target: 1 referral per customer = 5 warm leads.

3. **Product Hunt launch.** Prepare: 1-paragraph pitch, 5 screenshots (matching MCP marketplace listing), demo GIF, and 3 initial testimonials from paying customers. Launch on a Tuesday. Rally your network to upvote in the first 2 hours. Target: top 5 of the day.

4. **Hacker News "Show HN" post.** Frame it as a technical story: "I built Bayesian MMM as an MCP tool using PyMC-Marketing." Lead with the architecture, the MCP integration, and the open-source foundation. The DTC/marketing angle comes second. HN respects technical depth, not sales pitches.

5. **LinkedIn content cadence reaches 3-5 posts/week.** Teardowns, results, build-in-public stories. Each post should end with "DM me if you want me to run this on your data." This converts LinkedIn followers into demo requests.

### Phase 3: Customers 15-50 (Days 60-90) -- Inbound Engine + Paid Amplification

**Target:** 50 total paying customers.
**Method:** Inbound (50%) + outbound (30%) + referrals (15%) + paid (5%).
**Cost:** $1,000-3,000/month.

**New tactics:**

1. **LinkedIn Ads retargeting.** Pixel the landing page. Retarget visitors with the case study and "Book a Free Analysis" CTA. Budget: $500/month. This is the highest-ROI paid channel because you are retargeting people who already expressed interest.

2. **LinkedIn Ads prospecting.** Lookalike audience of demo bookers and website visitors. Carousel ad using the "5 Signs Your Ad Budget Has a Leak" content. Budget: $500-1,000/month. Target CAC: $200-300.

3. **Podcast guest appearances.** Pitch the founder as a guest on DTC-focused podcasts. Angle: "Why Bayesian statistics is replacing last-click attribution for DTC brands." Target 1-2 appearances per month.

4. **Community posts.** Demand Curve, Exit Five, RevGenius. One substantive post per community per month. Never a product pitch -- always an insight post with MixLift as the tool used.

5. **Email nurture for free tier users.** By this phase, free tier installs should be generating 20-50 users/month. Build a 5-email drip sequence: Day 1 (welcome + first-run guide), Day 3 (case study), Day 7 (scenario mode tutorial), Day 14 (comparison to platform attribution), Day 21 (growth tier upgrade offer with 15-min analysis incentive). Target: 5-8% free-to-paid conversion.

### Budget Summary (90 Days)

| Category | Month 1 | Month 2 | Month 3 | Total |
|---|---|---|---|---|
| LinkedIn Ads | $0 | $0 | $1,000-1,500 | $1,000-1,500 |
| Podcast sponsorship | $0 | $0 | $500-1,000 | $500-1,000 |
| Tools (Loom, Canva, etc.) | $50 | $50 | $50 | $150 |
| **Total** | **$50** | **$50** | **$1,550-2,550** | **$1,650-2,650** |

**Target blended CAC at Day 90:** $50-75 (most customers are founder-sold with zero ad spend).

---

## 4. Brand & Messaging

### The Problem with Current Messaging

The existing landing page headline is "Stop Guessing Your ROAS." This is fine but generic. Every analytics tool says some version of this. The v2 landing page copy ("Your Ad Platforms Are Lying About ROAS") is stronger because it is more specific and more provocative.

The battle card still uses "enterprise-grade" as a positioning phrase. Retire it. "Enterprise-grade" signals "we wish we were enterprise" to the exact buyers we are targeting.

### Recommended Messaging Framework

**One-liner (for elevator, LinkedIn bio, conference badge):**

> MixLift finds the wasted $47K in your ad budget. 5 minutes. $299/month.

This works because it leads with a dollar outcome, includes time-to-value, and anchors price. Every word does work.

**Elevator pitch (30 seconds):**

> Every ad platform inflates its own numbers. Meta says Meta is amazing, Google says Google is amazing, but your P&L tells a different story. MixLift is Bayesian Marketing Mix Modeling for DTC brands -- the same methodology Fortune 500s use, but delivered through Claude AI in 5 minutes for $299 a month. Drop in your spend data, and we show you exactly which channels are wasting money and where to move budget for more revenue. We just found $47K in recoverable spend for a $20M DTC brand. I can run the same analysis on your data in 15 minutes -- free, on Zoom.

**Homepage hero headline (test these three):**

| Variant | Headline | Subheadline |
|---|---|---|
| A (Outcome) | "Find the $47K Your Ad Budget Is Wasting" | "MixLift is Bayesian Marketing Mix Modeling for DTC brands. Same methodology as Prescient AI. 1/5th the price. 5 minutes to set up." |
| B (Provocative) | "Your Ad Platforms Are Lying About ROAS" | "MixLift uses Bayesian statistics -- not platform pixels -- to show you which channels actually drive revenue. $299/month." |
| C (Speed) | "From CSV to Budget Recommendations in 5 Minutes" | "No dashboards. No data scientists. No $1,500/month contracts. Just the truth about your ad spend." |

**Recommendation:** Start with Variant A. The dollar figure creates curiosity and specificity. Test B after 2 weeks of traffic data. C is weakest because it leads with process, not outcome.

**Taglines to test in ads and social:**

- "The $47K question your ad dashboard can't answer."
- "Bayesian MMM for DTC. $299/month. No data scientist required."
- "Same math as Prescient AI. $1,200/month cheaper."
- "Your retargeting ROAS is inflated 5x. We can prove it."

### Messaging Traps to Avoid

1. **Do not lead with "AI-native" or "MCP."** Buyers do not care about your architecture. They care about their wasted budget. MCP is a feature, not a benefit.
2. **Do not say "enterprise-grade."** It signals insecurity. Show the methodology credentials (PyMC-Marketing, Bayesian inference) and let the buyer conclude it is enterprise-quality.
3. **Do not compare yourself to Google Analytics or GA4.** They are not in the same category. Comparing down makes you look smaller.
4. **Do compare to Prescient AI, Paramark, and Recast by name.** These are the expensive incumbents. Naming them borrows their credibility and positions MixLift as the smart alternative.
5. **Always include a dollar figure.** "$47K in wasted spend," "$15K/year cheaper than Prescient," "$299/month." Abstract claims lose to specific numbers every time.

### Landing Page Issues to Fix Immediately

The current landing page at `/Users/felix/software-projects/mixlift-landing/index.html` has several problems:

1. **FAQ answer #3 says "3 channels" for the free tier and "$199/month" for a "Pro" plan.** The actual free tier is 2 channels, and the paid tier is "Growth" at $299/month. This will confuse and erode trust. Fix today.
2. **No case study or social proof section.** The v2 landing page copy includes a case study section. Implement it as soon as the Day 0 case study is written.
3. **No demo video.** The hero section should include the 90-second Loom demo. Video above the fold increases conversion 20-80% for SaaS landing pages.
4. **"Most Popular" badge on Growth tier** is premature with zero customers. Remove it until there is honest social proof. Replace with "Recommended" or remove the badge entirely.
5. **No "Book a Demo" CTA.** The current CTAs are "Try Free" and "Go Growth." Add a third: "Book a Free 15-Minute Analysis" with a Calendly link. At this stage, the highest-converting action is a live demo, not a self-serve install.
6. **Missing comparison table.** The pricing section should include the comparison table from the pricing one-pager (MixLift vs. Prescient AI vs. Recast vs. In-House DS).

---

## 5. Community & Thought Leadership

### The Goal

Make the founder the person people think of when they think "MMM for DTC brands." Not MixLift the brand -- the founder personally. At this scale, personal brand > company brand.

### Specific Plays

**LinkedIn presence (highest priority):**

- Post 3-5 times per week. Mix: 40% teardown/data content, 30% build-in-public (revenue numbers, customer stories, lessons learned), 20% educational (how MMM works, how to interpret saturation curves), 10% opinion/hot takes ("retargeting is the most over-funded channel in DTC").
- Engage with 10-15 relevant posts per day. Comment with substance, not "great post!" Target: DTC founders, growth leads, marketing VPs. Their followers see your comments.
- Accept every connection request. Follow everyone in DTC growth/marketing. The algorithm rewards network size.

**Reddit presence:**

- Post a teardown on r/PPC every 2 weeks. Never mention MixLift in the post body. Mention it in comments only, after the community engages.
- Also participate in r/ecommerce, r/analytics, r/datascience. Answer questions about attribution, MMM methodology, saturation curves. Link to MixLift blog posts (not landing page) when relevant.
- Build karma before posting promotional content. 2-3 weeks of helpful comments before the first teardown post.

**Community memberships:**

- Join Exit Five (free tier), DTC Twitter/X circles, and Demand Curve community.
- Do not pitch. Share insights. Answer questions. When someone asks "how should I measure my TikTok spend?" share methodology, not product.
- After establishing presence (2-4 weeks), propose a community-exclusive teardown: "I'll run an anonymized analysis on your data and share the results with the group."

**Conference and podcast strategy (Month 2+):**

- Apply to speak at MicroConf, SaaStr smaller stages, DTC-focused virtual summits. Talk title: "Why Your Retargeting Budget Is 5x What It Should Be: Lessons from Running 50 MMM Analyses."
- Pitch podcast guest spots on: Operators, DTC Pod, Marketing Against the Grain, Retention Radio. Angle: "The attribution crisis no one is talking about."
- Do not sponsor conferences yet. Guest appearances have 10x the credibility-per-dollar of a booth.

### Content Moat

Over 90 days, the founder should produce:

- 40-60 LinkedIn posts
- 4-6 Reddit teardowns
- 4-6 blog posts
- 2-3 case studies
- 1 long-form YouTube demo
- 3-4 short-form video clips

This volume creates a content moat that no competitor can overnight replicate. It also makes every subsequent outbound DM more effective because the prospect can look up the founder and find a track record of substantive content.

---

## 6. Growth Loops

### Loop 1: Analysis-to-Referral Loop (Activate First)

```
Customer runs MixLift analysis
  -> Finds surprising result (e.g., retargeting is 5x overstated)
  -> Shares finding with their team or peer network
  -> Peer says "how did you find that?"
  -> Customer refers MixLift
  -> New customer runs analysis
  -> Cycle repeats
```

**How to activate:** After every analysis, MixLift should produce a "shareable insight" -- a single headline finding formatted for easy copy-paste into Slack or email. Example: "MixLift just found that our TikTok ROAS is 2.1x higher than what platform attribution shows. We were about to cut TikTok."

**Tactics:**
- Ask every paying customer for 1 referral at the Day 14 check-in.
- Include a "Share This Insight" prompt in the MCP output (product change -- coordinate with engineering).
- Create a referral incentive: "Refer a friend, get one month free." At $299/mo, the LTV of a referred customer far exceeds $299.

**Why first:** This is the only loop where the product itself generates the distribution. All other loops require external effort.

### Loop 2: Content-to-Demo Loop

```
Founder posts teardown content on LinkedIn/Reddit
  -> DTC marketer sees it, resonates with the attribution problem
  -> Visits landing page or DMs founder
  -> Books 15-minute free analysis
  -> Analysis reveals actionable insight
  -> Converts to paid
  -> Becomes source material for next teardown (with permission)
  -> Cycle repeats
```

**How to activate:** Commit to the content calendar. Each customer interaction generates content fuel (new data points, new surprising results, new objections to address).

**Why second:** Requires consistent effort but compounds over time. Month 1 LinkedIn posts get 200 impressions; Month 3 posts get 2,000+ as the algorithm rewards consistency.

### Loop 3: Free-to-Paid Conversion Loop

```
MCP marketplace / SEO / referral drives free install
  -> User runs analysis on sample data or their own (2 channels)
  -> Sees percentage-based ROAS -- finds it useful but limited
  -> Hits the paywall: dollar values, scenario mode, budget optimizer
  -> Upgrades to $299/mo
  -> Monthly analysis habit forms (contextual memory + deltas)
  -> Retention loop engaged
```

**How to activate:** The free tier must be good enough to demonstrate value but clearly limited. Current gate (percentages vs. dollars) is elegant. Ensure the free-tier experience is flawless -- any friction here kills the funnel.

**Deferred loops (Phase 2+):**
- **Agency loop:** One agency uses MixLift across 10 clients = 10x revenue per sale. Activate after multi-client support ships.
- **Benchmark network effect:** Aggregated industry benchmarks attract new users who want to see how they compare. Requires 50+ customers.

---

## 7. Metrics & Attribution

### Leading Indicators (Track Weekly)

| Metric | Target (Day 30) | Target (Day 60) | Target (Day 90) |
|---|---|---|---|
| LinkedIn DMs sent | 150 | 300 | 500 |
| DM response rate | 10% | 12% | 15% |
| Demos completed | 8 | 20 | 40 |
| Demo-to-close rate | 30% | 35% | 35% |
| Free tier installs | 10 | 40 | 100 |
| Free-to-paid conversion | Measuring | 3% | 5% |
| LinkedIn post impressions (weekly avg) | 500 | 2,000 | 5,000 |
| Landing page visitors (weekly) | 50 | 200 | 500 |

### Lagging Indicators (Track Monthly)

| Metric | Target (Day 30) | Target (Day 60) | Target (Day 90) |
|---|---|---|---|
| Paying customers | 5 | 12 | 30 |
| MRR | $1,500 | $3,600 | $9,000 |
| Monthly logo churn | Measuring | <10% | <5% |
| Blended CAC | $0 (founder-sold) | $30 | $60 |
| Referral customers | 0 | 2 | 8 |
| Inbound demos (no outbound touch) | 0 | 3 | 10 |

### What to Measure in Each Channel

| Channel | Metric | Tool |
|---|---|---|
| LinkedIn organic | Impressions, profile views, DM conversations started | LinkedIn analytics |
| LinkedIn outbound | DMs sent, response rate, demos booked, closed | Pipeline tracker (docs/sales/pipeline-tracker.md) |
| Reddit | Post upvotes, comment engagement, landing page clicks (UTM) | Reddit + UTM tracking |
| Landing page | Visitors, time on page, CTA clicks, Stripe checkout starts | Simple analytics (Plausible or Fathom -- privacy-first, $9/mo) |
| Product Hunt | Upvotes, comments, install clicks | Product Hunt dashboard |
| Free tier | Installs (PyPI downloads), analyses run, upgrade clicks | PyPI stats + internal metering |
| Paid ads (Month 3) | CPC, CTR, demo bookings, CAC | LinkedIn Campaign Manager |

### Attribution Model

At this scale, do not overthink attribution. Use a simple last-touch model with UTM parameters:

- Every outbound DM includes a unique UTM link (`?utm_source=linkedin&utm_medium=dm&utm_campaign=outreach_v1`)
- Every content post links to a UTM-tagged landing page
- Every paid ad uses UTMs
- Pipeline tracker captures source for every demo

Multi-touch attribution matters at 500+ customers. At 50, you know where every customer came from because you talked to all of them.

### The Metric That Determines Everything

**Monthly logo churn.** From the strategy doc: >5% monthly churn caps at lifestyle business. <3% enables venture scale.

Start measuring from Day 1 of the first paying customer. If Month 2 churn is >15%, stop all marketing and talk to every churned customer before spending another minute on acquisition.

---

## 8. What NOT to Do

### Trap 1: Building Before Selling

"Let me just add one more feature before I start outreach." No. The product is 90% ready for the primary persona. PDF export, backtesting, and API connectors can wait. Ship the first customer on what exists today. Feature requests from paying customers are 100x more valuable than feature guesses from the roadmap.

### Trap 2: Brand Before Revenue

Do not spend time on a logo refresh, brand guidelines, a design system, or a "brand voice document." Do not hire a designer. The landing page is functional. The product works. Brand matters at 500 customers. Revenue matters at 0.

### Trap 3: Paid Ads Before Organic Proof

Do not run LinkedIn Ads or any paid channel until organic content has identified which messages resonate. If your organic posts about retargeting attribution get 10x the engagement of posts about saturation curves, that tells you what your paid ad creative should say. Paid amplifies signal; it does not create signal.

### Trap 4: Content Volume Without Distribution

One great teardown post with 50 comments on r/PPC is worth more than 20 blog posts that nobody reads. Distribution > creation. For every hour spent writing content, spend 30 minutes distributing it (sharing in communities, commenting on related threads, sending to prospects).

### Trap 5: Chasing Agencies Too Early

Agencies are a higher-LTV customer segment but with 3-5x longer sales cycles. They need multi-client support, white-label reports, and agency-specific pricing -- none of which exist. The strategy correctly defers agencies to Week 9+. Do not get distracted by an agency expressing interest before the DTC playbook is proven.

### Trap 6: Competing on Features

Triple Whale has API connectors. Prescient has dashboards. Trying to match their feature set is a losing game against better-funded competitors. MixLift's competitive position is: fastest setup, lowest price, AI-native UX, local data privacy. Lean into these. Every feature addition should reinforce one of these four pillars.

### Trap 7: Discounting

$299/month is already 5x cheaper than alternatives. Do not offer discounts, extended trials, or "first month free." Discounting trains customers to wait for deals and signals that you do not believe your own pricing. The only exception: annual pricing at a 25% discount ($2,690/year) which reduces churn mechanically. Ship this after reaching 15 customers.

### Trap 8: Premature Automation

Do not build email sequences, marketing automation, or CRM workflows before you have 50 prospects in the pipeline. Manual follow-up is more effective and teaches you what messaging works. The pipeline tracker markdown file is the right CRM at this scale.

### Trap 9: Ignoring the MCP Distribution Bet

MCP is either a massive distribution advantage or a niche channel with limited reach. The answer becomes clear in 90 days based on marketplace traction and organic discovery. Do not ignore it (list on the marketplace, optimize the listing) but do not bet everything on it either. The headless Python API and SEO ensure MixLift reaches buyers regardless of MCP's trajectory.

### Trap 10: Vanity Metrics

PyPI downloads, Twitter followers, LinkedIn impressions, and landing page visitors are not the goal. $299 transactions are the goal. It is tempting to celebrate 500 free installs, but if none convert to paid, those installs are worthless. Track vanity metrics as leading indicators, celebrate them never.

---

## Priority Matrix: What to Do This Week

| Priority | Action | Time | Impact |
|---|---|---|---|
| 1 | Fix landing page errors (FAQ pricing, tier names) | 1 hour | Prevents trust erosion |
| 2 | Record 90-second Loom demo | 2 hours | Enables all outbound |
| 3 | Send first 25 LinkedIn DMs | 3 hours | Direct path to demos |
| 4 | Post "5 Signs Your Ad Budget Has a Leak" carousel on LinkedIn | 1 hour | Content flywheel starts |
| 5 | Post Reddit teardown on r/PPC | 30 min | Community credibility |
| 6 | Submit MCP marketplace listing | 30 min | Set-and-forget distribution |
| 7 | Add Calendly "Book a Demo" link to landing page | 30 min | Captures high-intent visitors |
| 8 | Set up Plausible analytics on landing page | 30 min | Starts measurement baseline |

Everything else can wait until next week. These eight actions, done in this order, create the foundation for every subsequent play in this document.

---

*This strategy will be reviewed and updated every 2 weeks based on actual conversion data. The first update is due March 21, 2026.*

*Last updated: March 7, 2026*
