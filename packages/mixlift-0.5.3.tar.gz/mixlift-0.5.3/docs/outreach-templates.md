# LinkedIn Outreach Templates

5 templates for founder-led sales. Each uses a different angle.
CTA is always a 15-minute live demo on their data.

---

## 1. The "Price Anchor"

**Hook:** MMM for $299/mo (vs $1,500+)

**When to use:** Prospects who are cost-conscious or currently in a trial with a high-end competitor.

**Message:**

> Hi [Name],
>
> I know tools like Prescient AI or Paramark are the standard for Marketing Mix Modeling, but the $1,500+/mo price tag is a tough pill to swallow for most DTC brands.
>
> I built MixLift to solve that. We use the exact same Bayesian methodology, but because we deliver it through a Claude AI interface (and skip the flashy dashboards), we can offer it for $299/mo.
>
> Your data stays local, and you get the same strategic output for 1/5th of the cost.
>
> I'm running 15-minute live demos where I analyze a prospect's actual data. Want to see if we can spot some wasted spend in your accounts?

---

## 2. The "Pain Point"

**Hook:** Your ROAS is lying to you

**When to use:** VPs of Growth who are actively complaining about attribution or "black box" ad performance.

**Message:**

> Hi [Name],
>
> Post-iOS 14.5, relying on platform attribution is a gamble. You're likely over-investing in channels that look good on paper but are actually burning cash.
>
> You need Bayesian MMM to see the true incrementality of your spend, but usually, that requires a data science team or an enterprise SaaS contract.
>
> MixLift fixes this. We give you enterprise-grade modeling for $299/mo. It takes 5 minutes to set up.
>
> I'm offering a "concierge demo" -- I'll run the model live on your data for 15 minutes so you can see the blind spots immediately.
>
> Open to taking a look?

---

## 3. The "Social Proof / Results"

**Hook:** Found $47k in wasted spend in 5 minutes

**When to use:** Numbers-driven prospects who need to see ROI before committing to a conversation.

**Message:**

> Hi [Name],
>
> I recently ran a MixLift analysis for a DTC brand in the $15M revenue range. Using our Bayesian modeling, we identified $47,000/month being wasted on under-performing channels -- money they immediately reallocated to profitable growth.
>
> The best part? It took 5 minutes to find it.
>
> I'm looking to replicate this for a few other brands in the $5M-$200M range.
>
> I'd love to run a free, 15-minute analysis on your actual data over Zoom. No pitch decks, just the numbers.
>
> Worth a quarter of an hour to find the waste?

---

## 4. The "Curiosity / Pattern Interrupt"

**Hook:** a weird question about your ad budget

**When to use:** Prospects with "SaaS fatigue" who are tired of complex sales cycles and expensive contracts.

**Message:**

> Hi [Name],
>
> Most VPs of Growth I talk to are paying $20k+/year for MMM tools that they barely log into.
>
> I'm trying to prove that you can get the same Bayesian insights without the enterprise overhead.
>
> I built MixLift as an AI-native tool (powered by Claude). It runs locally on your machine, costs $299/mo, and delivers the analysis instantly.
>
> I'm not trying to be a standard SaaS vendor; I'm doing concierge onboarding personally.
>
> Up for a 15-minute experiment? I'll run MixLift on your CSV exports right now.

---

## 5. The "Warm Referral"

**Hook:** [Mutual Connection] suggested I reach out

**When to use:** Only when you have a legitimate mutual connection who gave permission to name-drop or suggested the intro.

**Message:**

> Hi [Name],
>
> [Mutual Connection] mentioned you're scaling [Company Name] pretty aggressively right now and might be hitting some attribution walls.
>
> They thought you'd be interested in what we're doing at MixLift. We provide Bayesian Marketing Mix Modeling for $299/mo -- about 5x cheaper than the incumbents like Paramark, but with the same statistical rigor.
>
> Since [Mutual Connection] spoke so highly of your growth strategy, I'd love to offer you a private demo.
>
> I'll run the analysis on your actual data live on Zoom (15 mins max). Let me know if you're game?

---

## 6. DTC Beauty Vertical

**Hook:** Your blended ROAS is dropping -- is it creative fatigue or channel saturation?

**When to use:** Directors/VPs of Growth at DTC beauty and skincare brands ($10M-$80M revenue) running heavy Meta + TikTok spend with declining returns.

**Message:**

> Hi [NAME],
>
> I've been watching [COMPANY] scale -- the product line expansion into [RECENT PRODUCT/COLLECTION] is impressive. Brands at your stage almost always hit the same wall: Meta ROAS is declining, TikTok looks promising but unproven, and you can't tell if the dip is creative fatigue or genuine channel saturation.
>
> The standard answer is "hire a data scientist" or "spend $1,500+/mo on Prescient AI." Neither is great when you're already investing heavily in new SKUs and influencer partnerships.
>
> I built MixLift specifically for brands like [COMPANY]. It's Bayesian Marketing Mix Modeling for $299/mo -- the same methodology the enterprise tools use, but delivered through Claude AI so there's no dashboard to learn. You drop in a CSV of your weekly spend by channel and revenue, and in 5 minutes you know exactly which channels are saturated and where your next dollar should go.
>
> I recently ran this for a beauty brand doing $20M. We found they were over-investing in Meta retargeting by $18K/month -- the channel had hit diminishing returns weeks ago, but platform ROAS still looked fine because of attribution inflation.
>
> I'm offering free 15-minute live analyses this week. I'll run MixLift on your actual data over Zoom -- no pitch, just the numbers. If it doesn't surface something surprising, I owe you a coffee.
>
> Worth a look, [NAME]?

---

## 7. DTC Food & Beverage Vertical

**Hook:** Your subscription LTV math might be hiding a channel problem

**When to use:** Growth leaders at DTC food, beverage, or supplement brands with subscription models, running 3+ paid channels, and likely measuring blended CAC rather than true incremental CAC by channel.

**Message:**

> Hi [NAME],
>
> Congrats on the momentum at [COMPANY] -- the subscription model in [PRODUCT CATEGORY] is clearly working. Quick question: when you look at your channel-level spend, do you actually know which channels are driving first-order subscribers vs. which are re-acquiring existing customers at full acquisition cost?
>
> This is the blind spot I keep seeing in food/bev DTC. Platform attribution lumps everything together, and because subscription LTV is strong, unprofitable channels hide behind the blended numbers for months before anyone notices.
>
> I built MixLift to solve this. It's a Bayesian Marketing Mix Model that separates true incremental contribution by channel -- think of it as an X-ray for your media spend. It costs $299/mo (not $1,500+ like the enterprise tools) and takes 5 minutes to run. No dashboards, no implementation -- you drop a CSV into Claude AI and get the analysis back instantly.
>
> For a supplements brand I analyzed recently, we found that their podcast sponsorships had 3x the incremental ROAS of their Google Search campaigns -- the opposite of what platform attribution showed. They shifted $25K/month and saw subscriber acquisition cost drop 22%.
>
> I'd love to run a free 15-minute analysis on [COMPANY]'s data. Just your weekly spend by channel and revenue -- I'll show you where the dollars are actually working. No strings.
>
> Game?

---

## 8. DTC Apparel Vertical

**Hook:** Q4 is coming -- do you know which channels actually drive seasonal revenue?

**When to use:** Marketing leaders at DTC fashion/athleisure/apparel brands ($10M-$80M) who deal with heavy seasonality and are scaling beyond founder-led marketing into structured media buying.

**Message:**

> Hi [NAME],
>
> I've been following [COMPANY]'s growth -- the [RECENT LAUNCH/COLLECTION/CAMPAIGN] looked strong. Here's what I keep seeing with apparel brands at your stage: you're spending across Meta, Google, TikTok, maybe influencer and affiliate, but when Q4 hits, you 2-3x your budget based on gut feel because there's no clean way to know which channels actually drove last year's holiday revenue vs. which just rode the seasonal wave.
>
> That's the exact problem Bayesian Marketing Mix Modeling solves. It separates the seasonal lift from the true channel contribution, so you know exactly where to put the incremental Q4 dollars.
>
> The catch has always been price and complexity -- tools like Prescient AI and Recast start at $1,500/mo and require a data science background. I built MixLift to change that. It's $299/mo, runs in 5 minutes through Claude AI, and automatically detects seasonality patterns. No dashboards to learn, no implementation project.
>
> I ran this for an athleisure brand doing $30M. They discovered that their YouTube spend -- which looked like a money pit on last-click -- was actually their highest-incrementality channel for new customer acquisition. They doubled down for Q4 and saw a 31% lift in new customer revenue vs. the prior year.
>
> I'm booking free 15-minute live analyses where I run MixLift on your actual data over Zoom. No slides, no pitch -- just your numbers and what they mean.
>
> Interested, [NAME]?
