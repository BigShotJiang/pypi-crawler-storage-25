# MixLift Product Roadmap

**Staff PM | March 7, 2026 | Confidential**

*This document defines the product roadmap for MixLift from current state through 12 months. It is opinionated, prioritized, and grounded in the actual shipped codebase -- not aspirations. Review quarterly; update monthly based on customer data.*

---

## Part I: Where We Are

### Product Definition

MixLift is Bayesian Marketing Mix Modeling delivered as a pip-installable MCP tool. A marketer types "run mixlift_analyze on my_data.csv" in Claude Desktop and gets back dollar-denominated budget reallocation recommendations in 3-5 minutes. No dashboards, no data science team, no six-figure contract. $299/month.

### User Personas

| Persona | Title | Company | Pain | Readiness |
|---|---|---|---|---|
| **Performance Marketer** (Primary) | Media Buyer, Growth Manager | DTC eComm, $5-50M rev | Platform attribution lies. No way to measure cross-channel impact. Needs to justify budget to VP. | 90% -- product works end-to-end for this user today. |
| **Marketing Leader** (Secondary) | VP/Director of Marketing | DTC eComm, $10-200M rev | Needs to defend budget to CFO. Wants independent measurement beyond platform self-reporting. Can't afford Prescient/Paramark. | 65% -- output is compelling but not shareable (no PDF export, no executive summary artifact). |
| **Agency Strategist** (Deferred) | Account Director, Media Planner | Digital agency, 10-50 clients | Needs to run MMM across multiple client accounts. Wants white-label output. | 20% -- no multi-client, no white-label, no agency pricing. |

### Jobs-to-Be-Done

| JTBD | Priority | Current State |
|---|---|---|
| **J1:** "Tell me which channels are actually working" | P0 | SOLVED -- ROAS with CIs, contribution analysis, confidence explainers |
| **J2:** "Tell me where to move my budget" | P0 | SOLVED -- Budget optimizer with dollar amounts, saturation traffic lights |
| **J3:** "Help me trust these numbers" | P0 | PARTIALLY SOLVED -- R-squared, MAPE, LOO-CV, convergence diagnostics. Missing: comparison to platform attribution, backtesting. |
| **J4:** "Show me what happens if I change X" | P1 | SOLVED -- Scenario mode ("cut Meta by 20%", "move $5K from Google to TikTok") |
| **J5:** "Track whether my changes worked" | P1 | PARTIALLY SOLVED -- Memory with deltas. Missing: automated monthly refresh, before/after comparison view. |
| **J6:** "Help me present this to my boss" | P1 | NOT SOLVED -- No exportable artifact. Claude chat is not a board deck. |
| **J7:** "Connect directly to my ad platforms" | P2 | NOT SOLVED -- CSV-only input. Manual export required. |
| **J8:** "Run this across all my clients" | P3 | NOT SOLVED -- Single-tenant, no multi-client support. |

### Product-Market Fit Assessment

**Signals of fit:**
- The output quality is genuinely differentiated. Dollar headlines + saturation traffic lights + confidence explainers make Bayesian MMM accessible to non-technical marketers for the first time.
- Price point ($299/mo) is 5-15x cheaper than alternatives (Prescient $1,500+, Paramark $2,000+, agencies $5K+/mo).
- Zero-infrastructure delivery via MCP is a genuine UX breakthrough. No dashboards to maintain, no integrations to configure.

**Signals of risk:**
- Zero paying customers. All fit signals are theoretical until money moves.
- MCP as primary distribution channel is a bet on an unproven platform. MCP marketplace traction is unknown.
- Single-tool surface area. One CSV analysis does not create a monthly workflow. Retention mechanics are nascent (memory shipped but not battle-tested).
- No data connectors. Every analysis requires manual CSV export, which is friction that compounds monthly.

**Honest PMF grade: Pre-PMF.** The product is well-built and differentiated. Whether anyone will pay $299/month for it is an open question that only sales will answer.

---

## Part II: Competitive Landscape

### Positioning Matrix

| Competitor | Methodology | Price | UX | Data Input | Threat |
|---|---|---|---|---|---|
| **Google Meridian** | Bayesian (open source) | Free | Code-only (Python/R) | Manual | MEDIUM -- requires data scientists, we don't |
| **Meta Robyn** | Ridge regression (open source) | Free | Code-only (R) | Manual | MEDIUM -- different methodology, frequentist |
| **Prescient AI** | Bayesian MMM | $1,500+/mo | Dashboard | API connectors | HIGH -- if they drop to $500/mo self-serve |
| **Paramark** | Bayesian MMM | $2,000+/mo | Dashboard | API connectors | HIGH -- closest methodology overlap |
| **Recast** | Bayesian MMM | $1,000+/mo | Dashboard | API connectors | HIGH -- exact same buyer persona |
| **Triple Whale** | Attribution + emerging MMM | $100-300/mo | Dashboard | Shopify-native | CRITICAL -- if they ship real Bayesian MMM at $199, game over on distribution |
| **Pecan AI** | Predictive analytics | $1,000+/mo | Dashboard | Connectors | MEDIUM-HIGH -- adjacent, not direct |
| **PyMC-Marketing** | Bayesian (open source) | Free | Code-only | Manual | HIGH -- if they ship a product UI |

### MixLift's Defensible Position

1. **AI-native UX** -- Only MMM solution that works inside an AI assistant. Zero infrastructure. No dashboard fatigue.
2. **Price** -- Only true Bayesian MMM under $500/month.
3. **Time-to-insight** -- 10 minutes from install to dollar-value recommendations. Competitors require days-to-weeks of onboarding.
4. **Contextual memory** -- Longitudinal tracking that creates switching costs. No competitor has this in an AI-native context.

### What Competitors Have That We Don't

| Capability | Who Has It | Impact |
|---|---|---|
| API data connectors (Meta, Google, TikTok) | Prescient, Recast, Triple Whale | HIGH -- CSV friction is the #1 activation blocker after install |
| Shareable reports (PDF/dashboard) | Everyone except open source | HIGH -- VP of Marketing can't forward a Claude chat to their CFO |
| Backtesting / holdout validation | Prescient, Paramark | MEDIUM -- "can I trust this?" is only partially answered |
| Multi-touch attribution alongside MMM | Triple Whale, Northbeam | MEDIUM -- marketers want both views |
| Cross-channel interaction effects | Paramark | LOW -- real but niche |

---

## Part III: The Roadmap

### Framework

Phases are organized as **Now / Next / Later** aligned to business milestones, not calendar dates. "Now" = before 15 paying customers. "Next" = 15-50 customers. "Later" = 50+ customers.

---

### Phase 1: NOW -- "Make Them Buy and Stay" (0-15 customers)

**Theme:** Close the activation gap, fix the retention loop, remove trust barriers.

**North Star Metric:** 5 paying customers by Day 45. Month 2 retention >80%.

| # | Feature | User Value | Effort |
|---|---|---|---|
| N1 | **PDF/HTML report export** | VP can email results to CFO. Closes the "I need to share this" objection. | SHIPPED (v0.5.1) |
| N2 | **Guided sample-data onboarding** | Prospect runs MixLift on realistic data without preparing their own CSV. | SHIPPED |
| N3 | **Free tier dollar leak fix** | Paywall integrity. Free users see %, paid users see $. | SHIPPED (v0.5.1) |
| N4 | **Fail-closed licensing with 24hr grace** | Prevents revenue leakage from fail-open on API errors. | SHIPPED (v0.3.0) |
| N5 | **Strip raw saturation curves from MCP output** | Reduces token waste (1,600 data points Claude can't render). Better AI summarization. | SHIPPED (v0.5.0) |
| N6 | **Exploratory analysis badge for <26 weeks** | Sets expectations on short data. Prevents trust erosion. | SHIPPED (v0.5.0) |
| N7 | **Backtesting / holdout validation** | Shows "here's how well we would have predicted your actual results." | SHIPPED (v0.5.1) |
| N8 | **Monthly refresh reminder via MCP** | When user opens Claude, MixLift nudges re-analysis after 30 days. Triggers re-engagement. | SHIPPED (v0.5.1) |
| N9 | **Platform attribution comparison** | "Platform says 3.2x, MixLift says 1.8x." Instant aha moment. | 2 wks |

| N10 | **Cloud MCP / Cowork connector** | Zero-install onboarding via remote MCP. "Add MixLift" in Cowork marketplace, no pip/terminal. 4 steps to first analysis. | PoC SHIPPED, 2-3 wks prod |

**Priority Order:** N10 > N9 (N1, N3, N5, N6, N7, N8 shipped)

**DS-aligned items for Phase 1:**
- ESS diagnostics (1 day) -- prevents silently bad results — SHIPPED (v0.5.1)
- ROAS plausibility checks (1 day) -- catches obviously wrong models — SHIPPED (v0.5.1)
- Time-series cross-validation (3 days) -- most convincing validation for marketers — SHIPPED (v0.5.1)

---

### Phase 2: NEXT -- "Make It Sticky" (15-50 customers)

**Theme:** Reduce friction, deepen engagement, build data moat.

**North Star Metric:** Monthly churn <5%. 40%+ of users running 2+ analyses/month.

| # | Feature | User Value | Effort |
|---|---|---|---|
| X1 | **Meta Ads API connector** | One-click data pull from Meta. Eliminates CSV export friction. | 3 wks |
| X2 | **Google Ads API connector** | Same as X1 for Google. Together covers 70%+ of DTC ad spend. | 3 wks |
| X3 | **Automated monthly analysis with email digest** | MixLift runs automatically each month, emails deltas. | 3-4 wks |
| X4 | **Pro tier ($799/mo)** | 20 channels, 500K rows, priority support. For larger brands. | 1 wk |
| X5 | **Scenario comparison mode** | Run 3 scenarios side-by-side with tabular comparison. | 1.5 wks |
| X6 | **Before/after comparison dashboard** | Visual deltas over time. Shows whether past budget changes improved results. | 2 wks |
| X7 | **Uncertainty-aware budget optimizer** | "Move $5K to TikTok (expected lift: $2K-$8K/week)." | 1 wk |
| X8 | **Model caching for repeat runs** | Re-running on similar data uses cached model. 10x faster. | 2 wks |
| X10 | **Annual pricing ($2,690/yr)** | 25% discount locks in committed customers. Reduces churn mechanically. | 0.5 day |

**Priority Order:** X10 > X6 > X3 > X1 > X5 > X2 > X7 > X4 > X8

**DS-aligned items for Phase 2:**
- Experiment calibration priors (1-2 wks) -- single biggest accuracy improvement
- Adaptive adstock lag selection (3-5 days) -- better defaults without user effort
- Custom control variables (3-5 days) -- addresses omitted variable bias
- Weibull adstock option (3-5 days) -- enables offline/long-cycle channels

---

### Phase 3: LATER -- "Build the Moat" (50+ customers)

**Theme:** Platform expansion, agency channel, data network effects.

**North Star Metric:** $50K MRR. NRR >110%. Agency revenue >20% of total.

| # | Feature | User Value | Effort |
|---|---|---|---|
| L1 | **Agency tier ($1,499/mo)** | Multi-client (10 brands), white-label reports. | 3 wks |
| L2 | **Vertical benchmarks** | "Your Google ROAS is in the 35th percentile for DTC beauty." Network effect moat. | 4 wks |
| L3 | **REST API** | Non-MCP distribution. Jupyter, custom dashboards can call MixLift. | 2 wks |
| L4 | **ChatGPT / OpenAI plugin** | Expands TAM beyond Claude users. | 3 wks |
| L5 | **Incrementality testing recommendations** | Recommends specific geo-holdout tests to validate findings. | 3 wks |
| L8 | **Shopify app** | One-click App Store install. Auto-pulls revenue + cost data. | 6 wks |

**DS-aligned items for Phase 3:**
- Time-varying coefficients (2-4 wks) -- major quality leap, differentiates from Robyn
- Geo-level MMM (3-4 wks) -- gold standard for causal identification
- Automated model selection (2 wks) -- eliminates "wrong model" objection
- Vertical benchmark priors (ongoing) -- data moat from aggregated posteriors

---

## Part IV: What to Kill

1. **Web app / Streamlit frontend** -- MCP-native is the differentiation. Dashboard makes MixLift a worse Prescient.
2. **Cross-channel interaction effects** -- Academically interesting, commercially irrelevant for 12 months.
3. **Real-time / daily MMM** -- Methodology requires weekly minimum. Feature mismatch.
4. **Custom priors UI** -- Opinionated defaults are the product. Don't expose Bayesian knobs to marketers.
5. **Hierarchical multi-level models** -- Requires agency-scale data that doesn't exist yet.

---

## Part V: 90-Day Milestone Map

| Day | Milestone | Key Deliverable |
|---|---|---|
| 10 | First 25 outreach DMs sent | LinkedIn prospect list + Loom demo |
| 20 | 5+ live demos completed | Concierge playbook validated |
| 30 | 3 paying customers | Dollar leak fixed. ESS diagnostics shipped. |
| 45 | 5 paying customers | PDF export shipped. Phase 1 engineering complete. |
| 60 | 8-12 paying customers | Month 2 retention data. Annual pricing launched. |
| 75 | First renewal cohort measured | Churn rate determines Phase 2 strategy. |
| 90 | Phase 1 exit criteria evaluated | 15 customers + <5% churn = Phase 2. <10 + >15% churn = pivot. |

---

## Part VI: The Honest Summary

MixLift is a well-engineered product with a clear value proposition, real price differentiation, and a novel distribution channel. It has zero customers. Everything in this roadmap is speculation until money moves.

The first 90 days are a sales execution problem, not a product problem. The product is 80% ready for the primary persona (performance marketer). The missing 20% is PDF export (J6), backtesting (J3), and API connectors (J7). Of these, only PDF export matters before customer #15.

The strategic bet is that MCP distribution + AI-native UX + $299 pricing creates enough differentiation to win 50-150 DTC brands before a well-funded competitor replicates the approach. Speed is the only moat that matters right now.

Build less. Sell more. Measure churn. Everything else is noise.

---

*Last updated: April 13, 2026*
*Next review: May 13, 2026*
