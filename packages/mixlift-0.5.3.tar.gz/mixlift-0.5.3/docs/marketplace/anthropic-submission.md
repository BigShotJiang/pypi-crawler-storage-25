# MixLift — MCP Registry Submission Packet

> Prep material only. Do NOT submit anything until legal items are resolved (see Section 6).
> Last updated: 2026-04-13

---

## 1. Submission Process

**Important context:** Anthropic does not operate a separate "Connector Marketplace" or curated partner directory with a gated submission form. The public listing surface is the **official MCP Registry** at `registry.modelcontextprotocol.io`, which is community-operated and open to any server. There is no gated "Claude Connector" approval process publicly documented.

**What exists:**
- Official MCP Registry docs: `https://modelcontextprotocol.io/registry/`
- Quickstart guide: `https://modelcontextprotocol.io/registry/quickstart`
- Registry API endpoint: `https://registry.modelcontextprotocol.io`

**No public documentation found** for a curated "Claude.ai Integrations" marketplace with a separate submission form. If Anthropic has a private partner program for featured placement in the Claude.ai interface, email `partnerships@anthropic.com` to inquire. The Claude.ai integrations settings page requires authentication and its curator process is not public.

### Step-by-step for MCP Registry listing (remote server path)

Source: `https://modelcontextprotocol.io/registry/quickstart` and `https://modelcontextprotocol.io/registry/remote-servers`

1. **Choose your authentication method.** MixLift has a domain (`mixlift.io`), so use **HTTP authentication** or **DNS authentication** for a `io.mixlift/*` namespace. Alternatively use GitHub auth for `io.github.mixlift-hq/mixlift` style naming.
   - HTTP auth: host a file at `https://mixlift.io/.well-known/mcp-registry-auth` containing your public key claim (`v=MCPv1; k=ed25519; p=<PUBLIC_KEY>`).
   - DNS auth: add a TXT record at `mixlift.io` with the same format.

2. **Install mcp-publisher CLI.**
   ```bash
   curl -L "https://github.com/modelcontextprotocol/registry/releases/latest/download/mcp-publisher_$(uname -s | tr '[:upper:]' '[:lower:]')_$(uname -m | sed 's/x86_64/amd64/;s/aarch64/arm64/').tar.gz" | tar xz mcp-publisher && sudo mv mcp-publisher /usr/local/bin/
   ```

3. **Generate key pair and set up domain auth.**
   ```bash
   openssl genpkey -algorithm Ed25519 -out key.pem
   PUBLIC_KEY="$(openssl pkey -in key.pem -pubout -outform DER | tail -c 32 | base64)"
   echo "v=MCPv1; k=ed25519; p=${PUBLIC_KEY}" > mcp-registry-auth
   # Host mcp-registry-auth at https://mixlift.io/.well-known/mcp-registry-auth
   ```

4. **Authenticate.**
   ```bash
   PRIVATE_KEY="$(openssl pkey -in key.pem -noout -text | grep -A3 "priv:" | tail -n +2 | tr -d ' :\n')"
   mcp-publisher login dns --domain "mixlift.io" --private-key "${PRIVATE_KEY}"
   ```

5. **Create `server.json`** (see Section 5 for draft content).
   ```bash
   mcp-publisher init   # generates template, then edit manually
   ```

6. **Publish.**
   ```bash
   mcp-publisher publish
   ```

7. **Verify listing.**
   ```bash
   curl "https://registry.modelcontextprotocol.io/v0.1/servers?search=io.mixlift/mixlift"
   ```

**Registry status note:** The MCP Registry is in preview as of April 2026. Breaking changes or data resets may occur before GA.

---

## 2. Required Assets Checklist

The MCP Registry is metadata-only — it does not host logos, screenshots, or marketing copy in the traditional "app store" sense. The `server.json` schema fields are what get indexed.

| Asset | Required | Notes |
|---|---|---|
| `name` | Yes | Reverse-DNS style: `io.mixlift/mixlift` |
| `title` | Yes | Human-readable: `MixLift` |
| `description` | Yes | Plain text, no documented length limit — keep under 500 chars for display safety |
| `version` | Yes | Semver string matching your release |
| `remotes[].url` | Yes (remote server) | `https://mixlift-cloud.fly.dev/mcp` |
| `remotes[].type` | Yes | `"streamable-http"` or `"sse"` |
| `repository.url` | Recommended | GitHub repo URL |
| Logo/icon | **Confirm with Anthropic** | Not required by MCP Registry; may be required by Claude.ai integrations curator |
| Screenshots | **Confirm with Anthropic** | Not documented for MCP Registry; may apply to featured/curated placement |
| Short/long description fields | **Confirm with Anthropic** | MCP Registry has only one `description` field; a curated marketplace may have more |
| Privacy policy URL | **Confirm with Anthropic** — likely required for Claude.ai featured listing | See Section 6 |
| ToS URL | **Confirm with Anthropic** | See Section 6 |
| Support email | Likely required for featured listing | `hello@mixlift.io` |

---

## 3. Draft Listing Copy

### Short description (≤ 280 chars)

> Your AI Head of Growth. Drop your marketing CSV into Claude and get a Bayesian media mix model, ROAS by channel, budget recommendations, and an exec-ready memo — in minutes. Cloud or local. $299/mo.

**Character count: 197.** Within limit.

---

### Medium description (~120 words)

MixLift is a Bayesian marketing mix model (MMM) built for growth teams at DTC brands doing $5M–$50M in revenue. Connect it to Claude and your workflow becomes: drop in a CSV of spend and revenue data, ask a question in plain English, and receive a channel-level ROAS breakdown, budget reallocation recommendations, and a polished exec memo — all grounded in rigorous PyMC-Marketing models with calibrated uncertainty. No data science team required. The Growth tier ($299/mo) includes model refresh reminders, scenario planning, diagnostic alerts, and HTML reports you can share with stakeholders. Your uploaded data is processed transiently and never sold. Available as Cloud-hosted or Local (data never leaves your machine).

---

### Long description (3–4 paragraphs)

**Paragraph 1 — ICP and the problem**
Directors and VPs of Growth at DTC brands between $5M and $50M in annual revenue are spending significant budget across Meta, Google, TikTok, email, and influencer — often with no reliable way to know what's actually working. Last-click attribution lies. Platform-reported ROAS double-counts. The result: budget allocated by gut feel, board meetings where the CMO can't defend the mix, and slow cycles of reacting to spend waste after the fact.

**Paragraph 2 — What MixLift does**
MixLift plugs a Bayesian marketing mix model directly into your Claude workspace. You connect the MixLift server once, drop a CSV of historical weekly spend and revenue by channel, and ask "What's my ROAS by channel?" or "What happens if I shift $20k from Meta to Google?" Claude handles the conversation layer; MixLift handles the econometric model under the hood — built on PyMC-Marketing with proper posterior uncertainty, saturation curves, and carry-over effects. Outputs are delivered as structured data Claude can reason about, plus optional HTML reports and memo-format summaries you can drop straight into a board deck.

**Paragraph 3 — Deliverables**
Each model run produces: channel-level ROAS estimates with confidence intervals, a budget recommendation memo, scenario comparison tables, and a refresh reminder when your data window needs updating. The Growth tier ($299/mo) adds diagnostic alerts (flags model instability before you act on bad numbers), export-ready HTML reports, and up to 5 saved scenarios. Annual plans are available.

**Paragraph 4 — Privacy and deployment options**
MixLift is available as a Cloud service (data uploaded transiently to a Fly.io container, never persisted beyond the session, license held in a minimal DB) or as a Local install (your CSV never leaves your machine — Claude connects to a localhost MCP server you run yourself). Both tiers use OAuth 2.0 for authentication. The Cloud MCP endpoint is `https://mixlift-cloud.fly.dev/mcp`.

---

## 4. Screenshots to Capture

Capture these 5 shots before submission. Use 1280×800 or 2560×1600 (retina). PNG preferred.

| # | UI State | Suggested Caption |
|---|---|---|
| 1 | Claude.ai with MixLift connector added (visible in sidebar/integrations panel), before any message is sent | "One-click connect — MixLift appears as a tool in your Claude workspace" |
| 2 | Claude conversation showing "Analyze my marketing data" prompt and the tool call in progress (spinner or tool-call block visible) | "Drop in a CSV and ask in plain English" |
| 3 | Claude response showing ROAS output with real dollar values per channel (e.g., "Meta: 2.3x, Google: 3.1x, TikTok: 1.4x") | "Channel-by-channel ROAS with Bayesian confidence intervals" |
| 4 | Claude response showing the budget recommendation memo (the formatted exec-ready paragraph output) | "An exec-ready budget memo, generated in minutes" |
| 5 | Scenario comparison output — two budget scenarios side by side or in a table | "Model your next spend shift before committing the budget" |
| 6 | (Optional) HTML report opened in browser showing a full model run summary | "Share a polished report with stakeholders — no data science degree required" |

**Screenshot tips:**
- Use real-looking (but synthetic) dollar values — e.g., `$847k total spend`, `$2.1M attributed revenue`.
- Redact any real client data. Use the `mixlift/data/demo_e2e.csv` dataset for a clean demo.
- Capture dark mode and light mode variants if possible; submit both to Anthropic if the listing supports it.

---

## 5. Logo / Icon Requirements

**MCP Registry:** No logo field in the `server.json` schema as of April 2026. Logo is not required for registry listing.

**Claude.ai featured listing / curated marketplace:** No public spec found. Confirm dimensions with Anthropic. Industry standard for OAuth app icons and integration listings is typically:
- Square icon: 256×256 px PNG minimum, ideally 512×512 px
- SVG master source recommended for scaling
- Background: must look good on both white and dark backgrounds (use transparent background or brand color fill)

**Current landing page assets:**
- `mixlift-landing/favicon.ico` — exists; likely 16×16 or 32×32, not suitable as a submission icon
- `mixlift-landing/og-image.png` — referenced in `<meta property="og:image">` but the file is not present in the landing directory (only referenced in HTML). Needs to be created or located.
- No SVG logo file found in `mixlift-landing/`

**Action items:**
1. Create a 512×512 px square icon with the MixLift "M" mark or wordmark on a solid brand-color background.
2. Export both PNG (512×512) and SVG master.
3. Confirm exact dimensions with Anthropic before submitting to a curated listing.
4. Place files at `mixlift/docs/marketplace/assets/icon-512.png` and `icon.svg`.

---

## 6. Required URLs

### Privacy Policy — `mixlift.io/privacy`

**Status: HTTP 404 — does not exist. Needs creation before any curated listing submission.**

---

**DRAFT PRIVACY POLICY — needs legal review before publishing**

```
MixLift Privacy Policy
Effective Date: [DATE]
Last Updated: [DATE]

1. Who We Are
MixLift ("we", "us") provides a Bayesian marketing mix modelling service accessible via
Claude and other MCP-compatible clients. Contact: privacy@mixlift.io

2. What We Collect
  a. Cloud Service Users
     - Uploaded CSV files: processed in-memory to run models; not persisted to disk
       beyond the duration of your session. Deleted on session close.
     - License and billing data: email address, subscription tier, OAuth tokens
       (encrypted at rest). Stored in our license database hosted on Fly.io.
     - Usage metadata: tool call logs (no CSV content), timestamps, model run counts.
       Retained for 90 days for abuse prevention and billing reconciliation.
     - OAuth tokens: stored encrypted; used only to authenticate your session.

  b. Local Installation Users
     - CSV data never leaves your machine.
     - License verification sends only your license key hash and machine fingerprint
       to api.mixlift.io. No marketing data is transmitted.

3. How We Use Your Data
  - To operate the service and run your requested models.
  - To enforce license terms and prevent abuse.
  - We do not sell your data. We do not use your marketing data to train models.

4. Data Sharing
  - Fly.io (cloud infrastructure): processes data under a DPA.
  - Stripe (billing): handles payment data under their privacy policy.
  - No other third-party data sharing.

5. Data Retention
  - CSV uploads: deleted at session end.
  - License records: retained for the life of the account plus 90 days after
    account closure for billing dispute resolution.

6. Your Rights
  - You may request deletion of your account and license data by emailing
    privacy@mixlift.io. We will respond within 30 days.
  - If you are in the EEA or UK, you have GDPR rights including access,
    rectification, erasure, and portability.

7. Security
  - Data in transit: TLS 1.2+ on all endpoints.
  - Data at rest: AES-256 encryption for license database.
  - We conduct periodic security reviews.

8. Changes
  - We will notify active subscribers of material changes 14 days in advance
    via the email on their account.

9. Contact
  privacy@mixlift.io
  MixLift, [Legal Entity Name, Address — confirm with legal]
```

---

### Terms of Service — `mixlift.io/terms`

**Status: HTTP 404 — does not exist. Needs creation before any curated listing submission.**

---

**DRAFT TERMS OF SERVICE — needs legal review before publishing**

```
MixLift Terms of Service
Effective Date: [DATE]

1. Acceptance
By using MixLift you agree to these Terms. If you are using MixLift on behalf of
a company, you represent you have authority to bind that company.

2. Service Description
MixLift provides a Bayesian marketing mix modelling tool accessible via MCP-compatible
AI clients including Anthropic Claude. The service produces statistical estimates;
outputs are not financial or investment advice.

3. License
Subject to payment of applicable fees, we grant you a non-exclusive, non-transferable
licence to use MixLift for your internal business purposes.

4. Acceptable Use
You may not: (a) resell or sublicense the service; (b) use the service to process
data you do not have rights to; (c) attempt to reverse-engineer the model.

5. Payment
Subscription fees are billed in advance. No refunds for partial months except
where required by law. Prices may change with 30 days notice to active subscribers.

6. Data
You own your marketing data. We process it only to provide the service. See our
Privacy Policy for details.

7. Disclaimers
THE SERVICE IS PROVIDED "AS IS". OUTPUTS ARE STATISTICAL ESTIMATES WITH UNCERTAINTY.
WE DO NOT WARRANT ACCURACY OR FITNESS FOR A PARTICULAR PURPOSE.

8. Limitation of Liability
TO THE MAXIMUM EXTENT PERMITTED BY LAW, OUR LIABILITY IS LIMITED TO THE FEES YOU
PAID IN THE 3 MONTHS PRECEDING THE CLAIM.

9. Governing Law
[Jurisdiction — confirm with legal]

10. Contact
hello@mixlift.io
```

---

### Other Required URLs

| URL | Status | Notes |
|---|---|---|
| Privacy policy | `mixlift.io/privacy` | 404 — draft above; needs legal review and deployment |
| Terms of service | `mixlift.io/terms` | 404 — draft above; needs legal review and deployment |
| Support email | `hello@mixlift.io` | Use this; already referenced in product copy |
| Connector endpoint | `https://mixlift-cloud.fly.dev/mcp` | Confirm live before submission |
| OAuth authorization server | `https://api.mixlift.io` | Confirm `/.well-known/oauth-authorization-server` is reachable |

---

## 7. Technical Validation Checklist

Run all of these before submitting. Every item must pass.

```bash
# 1. OAuth authorization server metadata
curl -s https://api.mixlift.io/.well-known/oauth-authorization-server | python3 -m json.tool
# Expected: valid JSON with issuer, authorization_endpoint, token_endpoint fields

# 2. OAuth protected resource metadata (FastMCP auto-publishes)
curl -s https://mixlift-cloud.fly.dev/.well-known/oauth-protected-resource | python3 -m json.tool
# Expected: valid JSON with resource, authorization_servers fields

# 3. JWKS endpoint
curl -s https://api.mixlift.io/.well-known/jwks.json | python3 -m json.tool
# Expected: valid JSON with "keys" array containing at least one JWK

# 4. MCP health check
curl -s -o /dev/null -w "%{http_code}" https://mixlift-cloud.fly.dev/mcp
# Expected: 200 or 401 (auth required is fine; connection error is not)

# 5. server.json schema validation
# Download schema and validate your server.json against it:
curl -s https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json -o /tmp/schema.json
# Use ajv or similar: npx ajv validate -s /tmp/schema.json -d server.json

# 6. End-to-end smoke test
# In Claude.ai (or MCP Inspector), add connector at https://mixlift-cloud.fly.dev/mcp
# Complete OAuth flow
# Send: "List the available MixLift tools"
# Confirm tools are returned
# Upload demo CSV and send: "Analyze my marketing data"
# Confirm model runs and returns structured output

# 7. Domain auth file (if using HTTP auth method)
curl -s https://mixlift.io/.well-known/mcp-registry-auth
# Expected: v=MCPv1; k=ed25519; p=<PUBLIC_KEY>

# 8. Privacy/ToS pages live
curl -o /dev/null -w "%{http_code}" https://mixlift.io/privacy
curl -o /dev/null -w "%{http_code}" https://mixlift.io/terms
# Expected: 200 for both (currently 404 — must fix before submission)
```

---

## 8. After Submission

### MCP Registry (open registry path)

- **Approval SLA:** Near-instant for the open registry — it's a CLI publish, no manual review queue. The registry is community-operated and permissive.
- **What gets removed:** Illegal content, malware, spam, and broken servers. See `https://modelcontextprotocol.io/registry/moderation-policy`.
- **Common issues:** Server not reachable at the declared URL, server.json name mismatch vs. package `mcpName`, version string not semver. Verify with `mcp-publisher publish --dry-run` if available.
- **Updates:** Submit a new `server.json` with a bumped version. Versions are immutable once published (same model as npm).
- **Appeals:** Open a GitHub issue at `https://github.com/modelcontextprotocol/registry` if your listing is removed.

### Claude.ai Curated/Featured Listing (if pursuing)

- **No public process documented.** Email `partnerships@anthropic.com` with:
  - Subject: "MCP Connector listing request — MixLift"
  - Include: connector URL, short/long descriptions (from Section 3), logo, privacy policy URL, ToS URL, support email, screenshot pack.
- **Expected turnaround:** Unknown — no public SLA. Follow up after 2 weeks.
- **Likely rejection reasons (inferred from similar platforms):**
  - Privacy policy missing or inadequate
  - Terms of service missing
  - OAuth flow broken or non-standard
  - Server unreliable / health check failing
  - Listing copy contains prohibited claims (e.g., "guaranteed ROI")
- **After rejection:** Address specific feedback, resubmit with a cover note describing changes.

---

## Appendix: Draft `server.json`

```json
{
  "$schema": "https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json",
  "name": "io.mixlift/mixlift",
  "title": "MixLift",
  "description": "Bayesian marketing mix model (MMM) for DTC growth teams. Drop a CSV of spend and revenue data into Claude and get channel-level ROAS, budget recommendations, and an exec-ready memo powered by PyMC-Marketing.",
  "version": "0.5.1",
  "repository": {
    "url": "https://github.com/mixlift-hq/mixlift",
    "source": "github"
  },
  "remotes": [
    {
      "type": "streamable-http",
      "url": "https://mixlift-cloud.fly.dev/mcp"
    }
  ]
}
```

> Note: Update `version` to match the live release at submission time. Update `repository.url` to the actual public repo URL (or remove if private).
