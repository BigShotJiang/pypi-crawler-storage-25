# OAuth 2.1 + DCR Plan — MixLift Cloud (Sprint Item 1)

**Status:** Draft v1 — awaiting review before implementation
**Target:** Ship by end of Week 1 (2026-04-20)
**Spec:** MCP Authorization (OAuth 2.1 draft-ietf-oauth-v2-1-11) + RFC 7591 DCR + RFC 9728 protected-resource metadata

## 1. Architecture

Three components, two repos:

```
┌──────────────┐     OAuth flow      ┌─────────────────────┐
│ claude.ai    │◄──────────────────►│ api.mixlift.io      │  ← Authorization Server
│ (MCP client) │   (authorize/token) │ (FastAPI on Fly,    │    issues JWT access tokens
│              │                     │  app=mixlift-api-*, │
│              │                     │  /data persistent)  │
└──────┬───────┘                     └──────────┬──────────┘
       │                                        │ signs with RS256
       │ Bearer <jwt>                           │ publishes JWKS
       ▼                                        │
┌──────────────────────────┐    verifies JWT    │
│ mixlift-cloud.fly.dev    │◄────(offline)──────┘
│ (FastMCP, Fly)           │  ← Resource Server
└──────────────────────────┘    validates, no round-trip per call
```

**Design choice: JWT (RS256) access tokens.** Stateless validation on Fly means no `/introspect` round-trip per MCP call. Public key served at `api.mixlift.io/.well-known/jwks.json`. Private key env-var on api.mixlift.io only.

## 2. Data model changes (`mixlift-api/src/mixlift_api/database.py`)

```sql
-- NEW: users table (one per email, links to licenses)
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  stripe_customer_id TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- NEW: dynamically-registered OAuth clients (RFC 7591)
CREATE TABLE oauth_clients (
  client_id TEXT PRIMARY KEY,          -- e.g. "claude-<uuid>"
  client_name TEXT,                    -- human label from registration
  redirect_uris TEXT NOT NULL,         -- JSON array
  grant_types TEXT NOT NULL,           -- JSON array, always ["authorization_code","refresh_token"]
  token_endpoint_auth_method TEXT DEFAULT 'none',  -- public client, PKCE
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- NEW: short-lived authorization codes (10 min TTL)
CREATE TABLE oauth_codes (
  code TEXT PRIMARY KEY,
  client_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  redirect_uri TEXT NOT NULL,
  code_challenge TEXT NOT NULL,        -- PKCE S256
  expires_at TIMESTAMP NOT NULL
);

-- NEW: refresh tokens (30-day TTL, rotated on use)
CREATE TABLE oauth_refresh_tokens (
  token_hash TEXT PRIMARY KEY,         -- sha256(token)
  client_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  revoked_at TIMESTAMP
);

-- MIGRATION: link existing licenses to users by email
ALTER TABLE licenses ADD COLUMN user_id INTEGER REFERENCES users(id);
-- Backfill: INSERT INTO users (email, ...) SELECT DISTINCT email, ... FROM licenses;
```

## 3. Authorization Server endpoints (api.mixlift.io)

| Method | Path | Purpose | Request | Response |
|---|---|---|---|---|
| GET | `/.well-known/oauth-authorization-server` | RFC 8414 metadata | — | `{issuer, authorization_endpoint, token_endpoint, registration_endpoint, revocation_endpoint, jwks_uri, scopes_supported: ["mcp:tools"], code_challenge_methods_supported: ["S256"], grant_types_supported: ["authorization_code","refresh_token"]}` |
| GET | `/.well-known/jwks.json` | RS256 public keys for resource servers | — | `{keys: [{kty,kid,n,e,alg:"RS256",use:"sig"}]}` |
| POST | `/oauth/register` | RFC 7591 DCR (public) | `{client_name, redirect_uris, grant_types, token_endpoint_auth_method:"none"}` | `{client_id, client_id_issued_at, redirect_uris, ...}` |
| GET | `/oauth/authorize` | Authorization endpoint (HTML consent/signup) | query: `response_type=code, client_id, redirect_uri, scope=mcp:tools, state, code_challenge, code_challenge_method=S256` | 302 redirect to email-entry page, then to `redirect_uri?code=…&state=…` after user completes Stripe or magic-link |
| POST | `/oauth/token` | Token exchange | `grant_type=authorization_code, code, redirect_uri, client_id, code_verifier` **or** `grant_type=refresh_token, refresh_token, client_id` | `{access_token (JWT), token_type:"Bearer", expires_in:3600, refresh_token, scope:"mcp:tools"}` |
| POST | `/oauth/revoke` | RFC 7009 revocation | `token, token_type_hint` | 200 |

**JWT access token claims:**
```json
{
  "iss": "https://api.mixlift.io",
  "sub": "<user_id>",
  "aud": "https://mixlift-cloud.fly.dev",
  "exp": <now + 3600>,
  "iat": <now>,
  "scope": "mcp:tools",
  "tier": "pro",           // from latest active license; refreshed on token issuance
  "license_key": "MIXLIFT-…"  // for metering fingerprint
}
```

## 4. Resource Server endpoint (mixlift-cloud.fly.dev)

FastMCP 1.26.0 auto-publishes this when we configure `AuthSettings`:

| Method | Path | Response |
|---|---|---|
| GET | `/.well-known/oauth-protected-resource` | `{resource: "https://mixlift-cloud.fly.dev", authorization_servers: ["https://api.mixlift.io"], bearer_methods_supported: ["header"], scopes_supported: ["mcp:tools"]}` |

## 5. MCP server integration (`src/mixlift_mcp/remote.py`)

~15 lines of new code:

```python
from mcp.server.auth.provider import TokenVerifier, AccessToken
from mcp.server.auth.settings import AuthSettings
import jwt, httpx

class MixLiftTokenVerifier(TokenVerifier):
    def __init__(self, jwks_url: str, issuer: str, audience: str):
        self._jwks_client = jwt.PyJWKClient(jwks_url, cache_jwk_set=True, lifespan=3600)
        self._issuer, self._audience = issuer, audience

    async def verify_token(self, token: str) -> AccessToken | None:
        try:
            signing_key = self._jwks_client.get_signing_key_from_jwt(token)
            claims = jwt.decode(token, signing_key.key, algorithms=["RS256"],
                                audience=self._audience, issuer=self._issuer)
            return AccessToken(token=token, client_id=claims["sub"],
                               scopes=claims["scope"].split(),
                               expires_at=claims["exp"],
                               extra={"tier": claims["tier"], "license_key": claims["license_key"]})
        except jwt.PyJWTError:
            return None

mcp.init(
    auth=AuthSettings(
        issuer_url="https://api.mixlift.io",
        resource_server_url="https://mixlift-cloud.fly.dev",
        required_scopes=["mcp:tools"],
    ),
    token_verifier=MixLiftTokenVerifier(
        jwks_url="https://api.mixlift.io/.well-known/jwks.json",
        issuer="https://api.mixlift.io",
        audience="https://mixlift-cloud.fly.dev",
    ),
)
```

**Backward compat:** `TokenVerifier` only runs when `Authorization: Bearer …` header is present. CLI/pip users calling tools with `license_key="MIXLIFT-…"` still hit the legacy `validate_license()` path — no change. Tool handlers check for bearer claims first, fall back to `license_key` param.

## 6. End-to-end signup flow

1. User clicks "Add MixLift to Claude" in claude.ai's connector directory
2. Claude hits `GET /.well-known/oauth-protected-resource` on the Fly server → finds `api.mixlift.io`
3. Claude hits `GET /.well-known/oauth-authorization-server` → learns endpoints
4. Claude does DCR: `POST /oauth/register` → gets a `client_id`
5. Claude redirects user to `GET /oauth/authorize?client_id=…&code_challenge=…&…`
6. On api.mixlift.io: email-entry page
   - **Email has active license** → magic-link email → click → auth code + redirect back
   - **Email has no license** → Stripe Checkout (Growth) → webhook creates license → return URL emits auth code → redirect back
   - **Email has cancelled license** → renew via Stripe, same as above
7. Claude exchanges code at `POST /oauth/token` → JWT access token (1h) + refresh token (30d)
8. Claude calls MCP tools with `Authorization: Bearer <jwt>`. Fly verifies offline via cached JWKS, enforces `required_scopes`, tool handlers read `tier`/`license_key` from token claims instead of tool parameter.

## 7. Locked design decisions (2026-04-13)

1. **Magic-link email.** Reuse existing Resend integration in `mixlift-api/src/mixlift_api/email_service.py` — add a second template `send_magic_link_email(email, login_url)` next to `send_license_email()`. Magic links are one-time tokens valid 15 minutes, stored in a new `oauth_magic_links(token_hash, email, expires_at, consumed_at)` table.
2. **Token lifetimes: access 1h, refresh 30d, rotated on use.** Old refresh invalidated when new one is issued (stored flag `revoked_at`). Stolen refresh is usable only until the real client rotates.
3. **Consent UI: server-rendered Jinja2 on api.mixlift.io.** Add `templates/` directory with `email_entry.html`, `magic_link_sent.html`, `consent.html`. Match mixlift.io branding with inline CSS (~200 LOC total). No separate frontend app, no CORS.
4. **SQLite stays.** api.mixlift.io is on Fly (not Render) with `/data` persistent volume already mounted per `fly.toml:15-17`. Redeploys preserve the DB. Revisit Postgres if we hit ~10K DAU or see write-contention issues. OAuth tables go into the existing `mixlift.db`.
5. **Tier-staleness.** JWT carries `tier` claim; stale for at most 1h after downgrade. Acceptable. Revocation via `/oauth/revoke` + refresh denial for cancelled licenses closes the loop for hard revokes.
6. **DCR rate limiting.** Soft limit: 10 registrations/hour/IP, global cap 10K rows in `oauth_clients`. Enforce in the `/oauth/register` handler.

## 8. Acceptance tests

- **Unit:** `MixLiftTokenVerifier.verify_token` — valid JWT ✓, expired ✓, wrong audience ✓, wrong issuer ✓, malformed ✓, missing scope ✓. Target: 8 tests.
- **Integration (mixlift-api):** full flow — register → authorize (with Stripe mock) → token → refresh → revoke. Target: 6 tests.
- **Integration (mixlift-cloud):** tool call with bearer succeeds; tool call with `license_key` param still succeeds (backward compat); tool call with no auth returns 401. Target: 4 tests.
- **Manual:** add the connector in claude.ai → sees "Sign in to MixLift" → email flow → analysis runs with dollar values (Growth tier).

## 9. Rollout

1. Ship auth server endpoints to api.mixlift.io behind a feature flag (`OAUTH_ENABLED=false` until tested).
2. Deploy Fly with `TokenVerifier` configured but keep accepting `license_key` param (dual-mode).
3. Flip `OAUTH_ENABLED=true` on api.mixlift.io.
4. Submit marketplace listing (Item 7) — by this point OAuth is the primary path.
5. Keep `license_key` path forever for pip/CLI users (no deprecation planned).

## 10. Risk / scope notes

- **Biggest risk:** signup-UX edge cases (user closes Stripe tab mid-flow, email already has license under different account, etc.). Budget ~1 day for UX hardening.
- **Out of scope:** device flow (RFC 8628) — CLI users keep using license keys.
- **Out of scope:** refresh token binding to client IP / device — adds complexity, not worth it at current threat model.
