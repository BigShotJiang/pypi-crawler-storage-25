# Product Brief: MixLift Cloud — Remote MCP for Zero-Friction Onboarding

**Date:** 2026-04-13 | **Status:** PoC Validated | **Author:** PM + Designer agents, synthesized by Opus

---

## Problem

MixLift requires `pip install`, JSON config editing, and a Claude restart. Our ICP (VP/Director of Growth, no data scientist) will never do this. Claude Cowork (launched Jan 2026) supports remote MCP connectors — "click to add," zero install — and targets exactly this audience: knowledge workers, not developers.

Every day we stay pip-only, we lose the non-technical half of our TAM.

---

## Proposed Solution: Dual-Mode Architecture

Ship MixLift as both a local MCP server (current) and a remote MCP server (new). Users choose their path:

- **Cloud (new default):** User clicks "Add MixLift" in Cowork/claude.ai connector marketplace. No install. Analysis runs on MixLift-hosted infrastructure.
- **Local (power-user option):** `pip install mixlift` for users who require zero data transit. Same product, same license key, same features.

---

## User Journey: Cloud Path

| Step | Action | Time |
|------|--------|------|
| 1 | Discover MixLift in Cowork marketplace or via mixlift.io | — |
| 2 | Click "Add MixLift" → Stripe checkout or free trial (no card) | 15s |
| 3 | Claude greets: "Upload a CSV, connect ad accounts, or try sample data" | 10s |
| 4 | User drops CSV into chat (or clicks "Try sample data" for instant demo) | 5s |
| 5 | MCMC runs. Claude asks intake question during wait. | 30-60s |
| 6 | Results: summary tier, top 3 actions, next steps | — |

**4 steps to first analysis. Under 2 minutes plus MCMC. No terminal.**

---

## Key Decisions

### 1. Privacy Messaging Shift

Replace "your data never leaves your machine" with a choice-based frame:

> **MixLift Cloud:** Zero-install. Data encrypted in transit, purged after analysis.
> **MixLift Local:** Data never leaves your machine.

Position local as the premium privacy option. The convenience-seeking buyer (primary ICP) gets the frictionless path.

### 2. Pricing Unchanged

Cloud and Local are delivery modes, not tiers. Free (2 runs/mo, percentages) and Growth ($299/mo, dollar values, unlimited) apply identically to both. No pricing fragmentation.

### 3. Paywall = The Dollar Sign

Free users see the full analysis with percentages. Dollar values are the upgrade trigger. The "aha" is seeing the shape of the opportunity; the conversion moment is wanting the exact number for a budget deck.

### 4. Sample Data on First Open

Eliminates "I don't have my CSV ready" drop-off. User sees a real 8-channel analysis within 60s of adding the connector. Uses the built-in GlowHaus dataset served from the remote MCP server.

### 5. CSV Upload Inside the Chat

No separate portal. The user's mental model is "I'm talking to Claude." Uploading a file to Claude is a gesture they already know. The remote MCP server receives it, validates, and runs the model.

### 6. Hosting Model

Ephemeral containers on Fly.io. Each analysis spins up an isolated container, runs MCMC, returns results, terminates. No disk writes, no CSV logging.

- **Cost:** ~$0.02-0.05 per analysis
- **COGS:** Under 5% of revenue at $299/mo with 4-8 analyses/month
- **Cold start:** 5-10s off-peak; warm pool of 2-3 containers during business hours

---

## Risks

| Risk | Severity | Mitigation |
|------|----------|------------|
| Privacy backlash from messaging change | HIGH | Frame as user choice. Local mode stays. Self-hosted option is itself a trust signal. |
| MCMC latency on cloud (>90s kills UX) | HIGH | Standard config (4 chains, 250 draws). Warm container pool. Monitor P95 latency. |
| Data breach liability | HIGH | Ephemeral containers, no disk writes, no CSV logging. SOC 2 Type I when revenue justifies. |
| Compute costs at scale | MEDIUM | $0.02-0.05/analysis. Add surcharge only if COGS >10%. |
| Container cold start | MEDIUM | Warm pool during business hours. 5-10s acceptable off-peak. |
| Remote MCP spec immaturity | MEDIUM | Wrap existing headless API (`mixlift.analyze()`). API surface is already clean. |

---

## Biggest UX Risk

The cloud path requires MixLift to run a remote MCP server that handles file uploads and MCMC computation. If the remote server is slow (>90s) or unreliable, the zero-friction onboarding promise collapses. This is the blocking dependency.

**Mitigation option:** Ship with a lighter MCMC config for first-run (fewer draws, faster), then offer full precision on follow-up runs.

---

## Recommended Next Step

**1-week proof-of-concept:**

1. Wrap `mixlift.analyze()` (already in `mixlift/api.py`) in a FastAPI-based remote MCP endpoint
2. Deploy to Fly.io
3. Test with a single Cowork account

This validates compute model, latency, and Cowork connector UX before committing to the full privacy messaging rewrite, marketplace listing, and landing page changes.

---

## PoC Results (2026-04-13)

**Built and deployed in 1 session.** Live at `https://mixlift-cloud.fly.dev/mcp`.

### What works end-to-end
- Streamable HTTP MCP transport on FastMCP's built-in HTTP mode (no FastAPI wrapper needed)
- 7 tools exposed remotely (analyze, readout, scenario, forecast, connect, connect_multi, prepare)
- `csv_content` parameter added to `mixlift_analyze` for inline uploads (no filesystem paths)
- Claude Desktop / Cowork custom connector picks up the server and surfaces `license_key` as a per-connector config field
- Free tier gating works remotely (percentages only)
- Paid tier unlocks dollar values (validated with `MIXLIFT-playground-test` key against live `api.mixlift.io`)

### Latency (smoke-tested with 2-channel × 52-week CSV)
| Machine size | Pre-sampling overhead | MCMC sampling | Total | Fit for target? |
|---|---|---|---|---|
| `shared-cpu-2x` | 95s | never finished (>5min) | — | ❌ unusable |
| `performance-2x` sequential chains | 38s | 133s | 189s | ❌ over 90s target |
| `performance-2x` + parallel chains | 38s | 80s | 170s | ⚠️ over target, but tolerable |

**Diagnosis:** JIT compilation (60s) is now the dominant pre-sampling cost; it runs once per Python process and doesn't parallelize. Options for dropping below 90s: pre-warm JIT cache in Docker image (~1 day) or switch sampler to `nutpie`/`blackjax` (~2-3 days, higher risk).

### Infrastructure learnings (gotchas)
1. **`FastMCP` transport security** — DNS rebinding protection defaults to localhost-only. Must explicitly allow the Fly domain + `claude.ai`/`claude.com` origins via `TransportSecuritySettings`. See `src/mixlift_mcp/remote.py`.
2. **Fly `auto_stop_machines = "suspend"` is aggressive** — kills in-flight MCMC if the client disconnects. For the PoC we tolerate this; production should use `min_machines_running = 1`.
3. **macOS cores=1 hardcode** — engine.py had `cores=1` as a macOS fork-deadlock workaround. Made it env-driven (`MIXLIFT_MCMC_CORES`) so Linux (Fly) can parallelize.
4. **Cost driver is `min_machines_running = 1`** (~$60/mo), not per-request compute (<$0.01/run). PoC runs at `= 0` for near-zero idle.

### Files shipped
- `src/mixlift_mcp/remote.py` — entry point, runs `mcp.run(transport="streamable-http")`
- `Dockerfile.remote` — slim Python 3.11 image, `pip install -e .` then `python -m mixlift_mcp.remote`
- `fly.toml` — `performance-2x` × 4GB RAM, region `iad`, autosuspend, parallel chains via env
- `tests/test_mcp/test_remote.py` — 7 tests covering `csv_content` + entry point

### OAuth 2.1 environment variables (Day 4)

The following env vars control OAuth token verification on the Fly resource server.
All are optional — defaults keep the existing PoC flow working until the flag is flipped.

| Variable | Default | Description |
|---|---|---|
| `OAUTH_ENABLED` | `false` | Set `true` to activate bearer-token verification.  Leave `false` until OAuth QA passes. |
| `OAUTH_ISSUER_URL` | `https://api.mixlift.io` | Expected `iss` claim in JWTs; also used as JWKS base URL if `OAUTH_JWKS_URL` is unset. |
| `OAUTH_AUDIENCE` | `https://mixlift-cloud.fly.dev` | Expected `aud` claim in JWTs; also used as `resource_server_url` in `AuthSettings`. |
| `OAUTH_JWKS_URL` | `{OAUTH_ISSUER_URL}/.well-known/jwks.json` | Override only if the JWKS endpoint differs from the issuer URL. |

**Do not set `OAUTH_ENABLED=true` in `fly.toml` yet.** The flag flip is a manual deploy step after QA of the full end-to-end flow (Day 5).

---

## Next Decisions (post-PoC)

1. **Latency ceiling** — 170s cold / ~110s warm. Acceptable? Founder gut-check after live Cowork test.
2. **Privacy messaging rewrite** — landing page still says "data never leaves your machine." Replace with "Cloud" vs "Local" framing from this brief.
3. **Marketplace listing** — submit to Claude/Cowork connector directory.
4. **Production hardening** — `min_machines_running = 1`, warm JIT pool, SOC 2 Type I when revenue justifies.

---

## Roadmap Placement

This is a **Phase 1.5** item — between "Make Them Buy" and "Make It Sticky." It doesn't add features; it removes the single biggest activation barrier. Should be prioritized above API connectors (X1/X2) because it solves the same friction (no CSV export needed) while also eliminating the install barrier.

| Phase | Item | Status |
|-------|------|--------|
| Phase 1 (NOW) | v0.5.0 MCP overhaul | SHIPPED |
| **Phase 1.5 (NOW)** | **Cloud MCP / Cowork connector** | **PoC VALIDATED** (2026-04-13) |
| Phase 2 (NEXT) | API connectors, monthly refresh | Planned |

---

*Generated 2026-04-13. PoC validated same day. Next review after production hardening decisions.*
