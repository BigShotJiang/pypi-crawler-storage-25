# Battle Card: MixLift vs. The Field

**Subject:** Bayesian Marketing Mix Modeling (MMM)
**Use Case:** Competitive displacement & Objection handling

---

## 1. Elevator Pitch & Positioning

**The "Why MixLift" Narrative:**
"MixLift is the first self-serve, Bayesian MMM tool built for the modern Growth Director. We take the exact same open-source probabilistic programming used by enterprise giants (PyMC-Marketing), wrap it in an AI-native interface, and deliver it at 20% of the cost. We don't charge you for dashboards or account managers -- we charge for the math."

**Value Proposition:**
Enterprise-grade methodology without the enterprise overhead.

**Target Persona:**
- **Title:** Director/VP of Growth, Head of Performance.
- **Profile:** DTC eCommerce, $5M - $200M Revenue.
- **Pain:** "My last-click attribution is lying to me," "I can't afford a data scientist," and "Enterprise MMM tools cost $20k/year."

---

## 2. The Kill Zone: Competitor Comparison

| Feature | **MixLift** | **Prescient AI / Paramark** | **Triple Whale** | **Robyn / Meridian** |
| :--- | :--- | :--- | :--- | :--- |
| **Methodology** | **True Bayesian (PyMC)** | True Bayesian | MTA / Heuristic (Not True MMM) | True Bayesian |
| **Pricing** | **$299/mo** | $1,500 - $2,500+/mo | $500+/mo (Bundled) | Free (Labor cost is high) |
| **Setup Time** | **Minutes (Self-serve)** | Weeks (Custom onboarding) | Days (Pixel install) | Months (Dev/DS required) |
| **Data Privacy** | **100% Local (User's machine)** | Cloud-hosted | Cloud/Pixel-based | Local (Code) |
| **Interface** | **AI-Native (MCP/Claude)** | Custom Dashboards | Dashboard / "Summary" | Code / Notebook output |
| **Requirement** | **No Data Scientist needed** | No Data Scientist needed | No Data Scientist needed | **Requires Data Scientist** |

---

## 3. Competitive Displacement Playbook

### vs. Prescient AI / Paramark (The High-End Bayesian)

**The Attack:** "You are paying a premium for human labor (Account Managers) and custom visualization layers, not better math."

- **Weakness:** High OPEX cost ($18k+ annually) and slow iteration cycles due to "managed" service layers.
- **Kill Shot:** "Prescient uses PyMC, and so do we. If you don't need a consultant to hold your hand, why are you paying consultant prices? With MixLift, you get the model tomorrow, not in 3 weeks."

### vs. Triple Whale (The DTC Incumbent)

**The Attack:** "Triple Whale is an attribution dashboard (MTA), not a statistical model. It's great for tracking, not for budget prediction."

- **Weakness:** Reliance on pixel data (subject to iOS tracking limits) and lack of true Bayesian causal inference (e.g., diminishing returns).
- **Kill Shot:** "Triple Whale tells you what *happened* (with limited data). MixLift tells you what to *do next* using full probabilistic simulation. Don't navigate with a rear-view mirror."

### vs. Robyn (Meta) / Meridian (Google)

**The Attack:** "The software is free, but the talent to run it costs $150k/year."

- **Weakness:** High technical barrier. Requires knowledge of R/Python, Bayesian statistics, and significant dev time.
- **Kill Shot:** "We've wrapped the power of Robyn/Meridian into a SaaS layer. You don't need to hire a Data Scientist to run the model; you just need MixLift."

---

## 4. Objection Handling

### "Why should I trust a $299 tool over Prescient at $1,500?"

- **The Reality:** You aren't paying for better math at $1,500; you are paying for overhead.
- **The Handle:** "That is exactly why we built this. The enterprise players use the same open-source methodology we do (PyMC-Marketing). The price difference isn't the accuracy of the model -- it's that we don't have Account Managers flying out to visit you or building custom dashboards you might not need. We pass those savings directly to you."
- **Proof Point:** "We are $299 because we are AI-native and automated. Same math, zero bloat."

### "We don't have a data scientist. Is this too technical for us?"

- **The Handle:** "Most tools require you to interpret complex posterior distributions. MixLift is AI-native. We integrate directly with tools like Claude (via MCP) to let you ask plain English questions about your data. You don't need to know Python; you just need to know your business goals."

### "Is my data safe?"

- **The Handle:** "Safer than anywhere else. MixLift processes data locally on your machine. We don't store your row-level data on our cloud servers like Prescient or Triple Whale. Your sensitive revenue numbers never leave your laptop."

### "Does 'Free' actually work for real businesses?"

- **The Handle:** "The Free tier is for validation. Upload your data, run the model, and see the curve fitting. When you want to see the actual dollar-value ROI and scale to your full history, you upgrade. It's proof before purchase."

### "How is this better than platform attribution?"

- **Acknowledge:** "Platform attribution is useful. It tells you which ad someone clicked before converting. You should keep looking at it."
- **Reframe:** "But every platform takes credit for the same conversion. Meta claims 500 sales, Google claims 400, TikTok claims 200 -- and you had 700 total. MMM solves this by modeling the actual statistical relationship between spend changes and revenue changes over time, independent of any pixel or click. It's the methodology Meta and Google use internally to audit their own platform numbers."
- **Evidence:** "Facebook's own research team has published that last-click attribution overestimates Meta ROAS by 20-40%. Google built Meridian (their open-source MMM tool) because they know platform dashboards are not enough. MixLift uses the same Bayesian engine."
- **Close:** "Platform attribution tells you who clicked. MixLift tells you what's actually driving revenue. You need both -- but only one can tell you where to move your next dollar."

### "We already have a BI tool."

- **Acknowledge:** "Great -- Looker, Tableau, and similar tools are essential for reporting. You should absolutely keep them."
- **Reframe:** "BI tools tell you what happened. MixLift tells you what to do next. Your BI dashboard can show that you spent $50K on Meta last month and revenue was $400K. But it cannot tell you whether spending $60K would have driven $500K or $405K. It cannot model diminishing returns or simulate budget reallocation. Those require a statistical model, not a reporting layer."
- **Evidence:** "Think of it this way: your BI tool is the speedometer -- it shows current speed. MixLift is the GPS -- it tells you where to turn. The most data-driven teams use both."
- **Close:** "MixLift complements your existing stack. The channel-level insights feed directly into the dashboards and reports you already use. It adds a layer of causal intelligence on top of your descriptive analytics."

### "Can I trust Bayesian models?"

- **Acknowledge:** "Healthy skepticism is a good sign. You should demand transparency from any tool making budget recommendations."
- **Reframe:** "Bayesian modeling is not new or experimental -- it is the gold standard for causal inference in marketing. Google built Meridian on Bayesian methods. Meta's Robyn uses them. Every Fortune 500 CPG company runs Bayesian MMM. The reason is simple: Bayesian models quantify uncertainty instead of hiding it. You get confidence intervals, not just a single number that pretends to be precise."
- **Evidence:** "MixLift shows you R-hat convergence diagnostics (did the model actually converge?), credible intervals on every ROAS estimate (how confident is it?), and saturation curves (where are diminishing returns?). We are also shipping LOO-CV -- leave-one-out cross-validation -- which gives you an out-of-sample accuracy score. You can verify the model against holdout data."
- **Close:** "Run it on your data. If your Google Search ROAS comes back at 0.2x when you know it's your best channel, something is wrong and I want to hear about it. But in practice, the model usually confirms your intuition on 2-3 channels and surprises you on 1-2 others. Those surprises are where the money is."

### "What if I only have 6 months of data?"

- **Acknowledge:** "More data is always better. Twelve to twenty-four months is ideal because it captures seasonality."
- **Reframe:** "But 6 months -- 26 weekly data points -- is workable, especially if you have meaningful variation in your spend levels across that period. Bayesian models handle small samples better than frequentist alternatives because they incorporate informative priors. The model does not just look at your data in isolation -- it starts with prior knowledge about how advertising typically works (adstock decay rates, saturation shapes) and updates those priors with your specific data."
- **Evidence:** "With 6 months, you will see wider confidence intervals on some channels -- that is the model being honest about uncertainty. But you will still get clear directional signals on which channels are working, which are saturated, and where reallocation makes sense. The traffic lights and ROAS rankings are robust even with shorter histories."
- **Close:** "Let's run it on your 6 months and look at the confidence intervals together. If they are too wide to be actionable on a specific channel, I will tell you. And every month you keep running it, the intervals tighten as the model gets more data. Start now, and by month 3 you will have the 9 months of history that makes the estimates even sharper."

### "Why $299/mo when I can hire a freelancer?"

- **Acknowledge:** "You can absolutely hire a freelance data scientist to build an MMM. A good one charges $100-$200 per hour."
- **Reframe:** "At that rate, a single MMM analysis costs $2,000-$5,000 and takes 2-4 weeks to deliver. You get a PDF report, maybe a notebook. If you want to re-run it next month with fresh data, that is another $2,000-$5,000 and another 2-4 weeks. With MixLift, you run it in 5 minutes, as often as you want, for $299/month. That is roughly 60x faster and 10x cheaper on a monthly basis."
- **Evidence:** "Beyond cost and speed: MixLift has scenario mode -- test 'what if I cut TikTok by 30%?' in real time during a meeting. Try asking a freelancer to run 10 simulations while you are on a call with your CMO. And MixLift has contextual memory -- it tracks how your channel performance changes month over month, showing deltas automatically. A freelancer gives you snapshots; MixLift gives you a time series of strategic intelligence."
- **Close:** "Freelancers make sense for one-time deep dives. If you want ongoing, on-demand budget intelligence that you can access in 5 minutes any time you need it, MixLift is the better tool. And at $299/month, it costs less than 2 hours of freelancer time."

---

## 5. Qualifying Questions (BANT)

- **Budget:** "Are you currently spending over $500k/year on ads? (If yes, our tool pays for itself in <1 day of optimized spend)."
- **Authority:** "Do you control the budget allocation decisions, or do you have to ask a Finance/Data team?" (Target: You control the budget).
- **Need:** "Are you making budget decisions based on Facebook/Google Ads Manager numbers, or are you looking for an independent view?"
- **Timing:** "How quickly can you get 2 years of historical ad data into a CSV?" (If they can do it now, close now).

---

## 6. Proof Points & Differentiators

- **Methodology:** Built on **PyMC-Marketing**, the industry standard for probabilistic programming (same tech stack powering Google Meridian).
- **Innovation:** The only platform offering **MCP (Model Context Protocol)** integration -- allowing you to chat with your model inside Claude AI.
- **Privacy:** **Zero-Cloud-Retention** architecture. Data is processed in-memory, locally.
- **Economics:** **5x cheaper** than the nearest "True Bayesian" competitor.
- **Freedom:** No contracts. No onboarding fees. Month-to-month SaaS.

---

## 7. Closing Statement

"Stop guessing with last-click attribution and stop overpaying for enterprise 'managed services.' Get the same Bayesian rigor as the Fortune 500, run it on your own machine, and save $15,000 a year."
