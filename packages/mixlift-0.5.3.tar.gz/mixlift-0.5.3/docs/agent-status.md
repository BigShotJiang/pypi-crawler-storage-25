# MixLift Agent Status Board

**Instructions:** Each manager owns their section below. Update it after every completed deliverable or when encountering a blocker. Read the FULL file before starting any work session.

**Format:** Use the exact headers shown. Do not add new sections -- only update your own.

---

## Engineering Manager

**Last updated:** --

### Completed
- (none yet)

### In Progress
- (none yet)

### Blocked
- (none yet)

### Needs Review
- (none yet)

---

## Data Science Manager

**Last updated:** 2026-03-07 23:00

### Completed
- [B10] LOO-CV design + implementation via ArviZ `az.loo()` (`mixlift/modeling/engine.py`, `src/mixlift_mcp/server.py`, `tests/test_modeling/test_engine_unit.py`)
- [B14] Intercept decomposition design + implementation — extracts baseline/organic revenue from model intercept, annualizes it, surfaces in MCP output (`mixlift/modeling/engine.py`, `src/mixlift_mcp/server.py`, `tests/test_modeling/test_engine_unit.py`)
- [NEW-DS1] Model quality documentation — covers priors, convergence, posterior predictive, LOO-CV guide, known limitations (`docs/model-quality.md`)

### In Progress
- (none)

### Blocked
- [NEW-DS2] Sample dataset validation -- DEPENDS ON: A4/PM sample dataset (not yet created at `data/sample_8channel.csv`)

### Needs Review
- [B10] EM should review LOO-CV integration into `engine.py` and `server.py`. Note: `az.loo()` requires `log_likelihood` group in InferenceData — verify PyMC-Marketing's `MMM.fit()` produces this by default.
- [B14] EM should review intercept decomposition. Intercept variable name assumed to be `"intercept"` — verify against actual PyMC-Marketing posterior variable names.
- [NEW-DS1] Marketing Manager should review `docs/model-quality.md` for content creation (credibility claims, "How it works" section).

---

## Product Manager

**Last updated:** --

### Completed
- (none yet)

### In Progress
- (none yet)

### Blocked
- (none yet)

### Needs Review
- (none yet)

---

## Marketing Manager

**Last updated:** 2026-03-07 18:00

### Completed
- [NEW-MK1] Added 3 ICP-specific outreach templates (DTC beauty, DTC food/bev, DTC apparel) to `docs/outreach-templates.md`
- [A8] LinkedIn carousel draft: "5 Signs Your Ad Budget Has a Leak" (`docs/content/linkedin-carousel-budget-leak.md`)
- [A9] Reddit teardown post draft for r/PPC (`docs/content/reddit-teardown.md`)
- [A11] MCP marketplace listing draft (`docs/content/mcp-marketplace-listing.md`)
- [NEW-MK3] Landing page v2 copy with sample dataset, free tier, and concierge positioning (`docs/content/landing-page-v2.md`)

### In Progress
- (none)

### Blocked
- [NEW-MK3] Landing page copy references A12 (Day 0 case study) which PM has not yet created. Used anonymized placeholder data. Will refine once `docs/case-study-day0.md` is available.

### Needs Review
- [A8] Founder: review carousel copy before posting to LinkedIn (`docs/content/linkedin-carousel-budget-leak.md`)
- [A9] Founder: review Reddit post before posting to r/PPC (`docs/content/reddit-teardown.md`)
- [A11] Founder: review marketplace listing before submitting (`docs/content/mcp-marketplace-listing.md`)
- [NEW-MK3] Founder: review landing page copy before deploying to Netlify (`docs/content/landing-page-v2.md`)

---

## Sales Lead

**Last updated:** --

### Completed
- (none yet)

### In Progress
- (none yet)

### Blocked
- (none yet)

### Needs Review
- (none yet)

---

## Customer Success Manager

**Last updated:** 2026-03-07 14:00

### Completed
- [A16] Detailed onboarding playbook (`/Users/felix/software-projects/mixlift/docs/cs/onboarding-playbook.md`)
- [NEW-CS1] MCP setup guide for customers (`/Users/felix/software-projects/mixlift/docs/cs/mcp-setup-guide.md`)
- [NEW-CS2] Results interpretation guide (`/Users/felix/software-projects/mixlift/docs/cs/interpreting-results.md`)
- [NEW-CS3] Retention health check template (`/Users/felix/software-projects/mixlift/docs/cs/retention-health-check.md`)
- [NEW-CS4] Churn risk signals doc (`/Users/felix/software-projects/mixlift/docs/cs/churn-risk-signals.md`)

### In Progress
- (none)

### Blocked
- (none)

### Needs Review
- [H8] Product Manager should review `docs/cs/interpreting-results.md` for accuracy -- guide language should match MCP output labels exactly
- [H9] Engineering Manager: once B7 (fail-closed licensing) ships, update `docs/cs/mcp-setup-guide.md` with cached grace period behavior

---

## Founder Action Items (from agent escalations)

*Managers: add items here when you are blocked by something only the founder can do.*

- (none yet)
