# MixLift Sales Strategy: Zero to 15 Customers in 45 Days

**Staff Sales Lead | March 7, 2026 | Confidential**

---

## 1. Sales Process Design

### The Funnel

MixLift is a $299/mo self-serve SaaS sold founder-led to DTC eCommerce marketing leaders. The sales cycle is 3-14 days. Anything longer than 14 days at this price point means the prospect is either unqualified or you are selling to the wrong person.

**Stage 1: Target Identification (Day 0)**
- Source prospect from LinkedIn/community/referral
- Score against qualification scorecard (minimum 60/100)
- Confirm: 3+ ad channels, $30K+/mo ad spend, Director+ title, can produce a CSV

**Stage 2: Cold Outreach (Day 0-1)**
- Personalized LinkedIn DM (not connection request -- direct InMail or message if connected)
- One message. One CTA: "15-minute live analysis on your data."
- No follow-up for 3 business days

**Stage 3: Warm Response (Day 1-5)**
- Prospect replies. Book the demo within 48 hours of response. Every day of delay kills conversion.
- Send calendar link immediately. No back-and-forth on scheduling.
- Pre-demo: ask them to pull their CSV ("weekly spend by channel + revenue, 6-12 months"). If they cannot do this, they will not convert. This is a qualification gate disguised as demo prep.

**Stage 4: Live Demo (Day 3-10)**
- 30-minute Zoom. Run MixLift live. On their data if they prepared it, on sample data if they did not.
- Demo-on-their-data conversion rate target: 40%+
- Demo-on-sample-data conversion rate target: 15-20%
- Close on the call. "I can set you up in 5 minutes right now."

**Stage 5: Close or Free Tier (Day 3-14)**
- Close: send Stripe payment link, activate license, walk through first analysis on their data during the call
- Stall: install free tier on the call, schedule Day 3 check-in, send pricing one-pager
- No: note objection, move to Closed Lost, ask for referral

**Stage 6: Onboarding (Day 0-7 post-close)**
- Day 0: Install + first analysis on their data (done on close call)
- Day 1: Follow-up email with written summary of findings
- Day 3: "Have you run a second analysis?" check-in
- Day 7: Interpretation call -- walk through results, introduce scenario mode
- Day 14: "What's changed since last month?" -- trigger contextual memory

### Qualification Criteria: MEDDIC-Lite for $299/mo

| Criterion | Question | Green | Red |
|---|---|---|---|
| **Metric** | "What metric do you optimize for?" | ROAS, CPA, CAC, revenue | "Brand awareness," "reach" |
| **Economic Buyer** | "Can you sign off on a $299/mo tool today?" | "Yes" / "I own the tools budget" | "I need to talk to procurement" |
| **Decision Process** | "What happens after this demo?" | "I'll try it" / "I'll decide this week" | "I need to present to the team" |
| **Decision Criteria** | "What would make you say yes?" | "If it finds something I didn't know" | "If it integrates with our stack" |
| **Identified Pain** | "What's broken about your current approach?" | Specific complaint about attribution | "Nothing, just exploring" |
| **Champion** | "Would you be the person using this daily?" | "Yes, I run the channels" | "No, my analyst would" |

**Auto-disqualify:** If the person on the call is not the person who would use MixLift, you are selling to the wrong person. At $299/mo, there is no committee. The user IS the buyer.

---

## 2. ICP Refinement

### The Exact Buyer

**Title:** Director of Growth, VP of Growth, Head of Performance Marketing, Head of Acquisition. NOT "Marketing Manager" (too junior, no budget authority). NOT "CMO" (too senior, won't use an MCP tool themselves).

**Company Profile:**
- DTC eCommerce (Shopify or Shopify Plus preferred -- they can export CSV easily)
- Revenue: $5M-$50M annually (sweet spot: $10-30M)
- Monthly ad spend: $30K-$150K across 3-8 channels
- Team size: 2-15 people in marketing. No dedicated data scientist.
- Channels: Meta + Google + at least one of (TikTok, YouTube, email, affiliate, podcast)

**Verticals (ordered by fit):**
1. **DTC Beauty/Skincare** -- Heavy Meta + TikTok spend, high CPAs, influencer-driven, very aware of attribution problems post-iOS 14.5. #1 vertical.
2. **DTC Food/Beverage/Supplements** -- Subscription models hide channel problems. Complex LTV math.
3. **DTC Apparel/Fashion** -- Seasonal spend swings make budget allocation painful.
4. **DTC Home/Fitness** -- Similar dynamics to beauty. Slightly lower urgency.

**Pain Signals (highest to lowest intent):**
1. Posted on LinkedIn/Twitter about attribution problems
2. Recently cut or added a channel and wants to measure impact
3. Tried Robyn/Meridian and abandoned it (awareness + failure = highest conversion)
4. Evaluated Prescient/Paramark and balked at price
5. Growing ad spend rapidly with declining blended ROAS

### Who NOT to Sell To

- Companies with in-house data science teams (they will build, not buy)
- Agencies (deferred to Week 9+)
- Companies spending <$15K/mo on ads (not enough spend variation)
- Companies with only 1-2 paid channels (MMM requires a mix)
- Enterprises requiring SOC 2 / security review
- Anyone who needs to "present to a committee" for a $299 decision

---

## 3. Prospecting Playbook: 100 Qualified Prospects in 30 Days

### Week 1: Build the List (50 prospects)

**LinkedIn Sales Navigator Queries:**

Query 1 -- DTC Growth Leaders:
- Title: "Director of Growth" OR "VP of Growth" OR "Head of Growth" OR "Head of Performance" OR "Director of Acquisition"
- Industry: Consumer Goods, Retail
- Company headcount: 11-200
- Keywords: "DTC" OR "ecommerce" OR "Shopify"
- Geography: US, UK, Canada, Australia

**Free Sources:**
1. **Shopify's "Built with Shopify" + BuiltWith.com** -- Cross-reference with LinkedIn to find growth leads
2. **2x eCommerce Podcast guest list** -- Every guest is a DTC growth leader
3. **PipeCandy or Store Leads** -- DTC brand databases with revenue estimates
4. **r/dtc and r/ecommerce** -- People posting about "scaling" or "attribution" are self-qualifying
5. **Twitter/X search: "iOS 14.5 attribution DTC"** -- Anyone complaining is a prospect
6. **Competitor case studies** -- Prescient, Paramark, Recast publish client names. Those clients are qualified AND price-sensitive.

**Daily target: 10 qualified prospects/day for 10 business days = 100 prospects.**

### Outreach Cadence

- Day 1: Send personalized DM (use vertical templates from outreach-templates.md)
- Day 4: One-sentence follow-up: "Hey [Name], wanted to bump this -- happy to show you the $47K waste case study if you're curious."
- Day 10: Final follow-up with Loom link: "Last one from me. Here's a 60-second demo video."
- After 3 touches with no response: Dormant. Do not contact again for 60 days.

**Volume: 10-15 DMs per day.** LinkedIn throttles above 20/day.

---

## 4. Demo Playbook

### Demo Structure (30 minutes)

**Minutes 0-2: Human Connection**
- Ask: "Before we start -- what made you take this call?" Their answer tells you which pain to amplify.

**Minutes 2-5: Problem Amplification**
- Make it personal: "You mentioned you're spending $80K/mo across 5 channels. When you look at Meta Ads Manager, what does it tell you your ROAS is? ...And you think that's accurate?"
- Plant doubt: "Every platform over-reports because they all claim credit for the same conversions. The question is: how much money is that costing you every month?"

**Minutes 5-15: Live Analysis**
- Run MixLift on their data (or sample data). While MCMC runs (2-3 min), fill silence: "This is the exact same methodology Prescient AI uses at $1,500/month."

**Minutes 15-25: Results -- Lead With the Surprise**
- Find the most interesting finding. "Look at this -- the model says your Google Search is past saturation. You're spending $5K/week there, but the marginal return above $3,500 is basically zero."
- Run one scenario mode query live: "What if you cut Google Search by 30%?"

**Minutes 25-28: The Price Drop**
- "Everything you just saw is the Growth plan. $299 a month. Cancel anytime. For context, Prescient charges $1,500+ for the same math." Pause. Let them react.

**Minutes 28-30: The Close**
- "Want me to set you up right now? I'll walk you through the install and we can run it on your full dataset before the end of this call."

### Handling "Let Me Think About It"

1. **Diagnose:** "Help me understand what you need to think about. Is it the price, the methodology, whether you'll actually use it, or something else?"
2. **Low-friction next step:** "Install the free tier right now -- takes 2 minutes. Run it on your data this week. If the results surprise you, upgrade."
3. **Takeaway:** "Honestly, MixLift isn't right for everyone. If you're comfortable with your current attribution, there might not be urgency here."

**Do NOT:** offer a discount, extend a trial, or follow up more than twice.

---

## 5. Pricing & Packaging

**$299/mo is correct for now.**
- Floor: $99 positions as a "toy." Need to be above dashboard pricing.
- Ceiling: $499 starts requiring second approval at some companies.
- Anchor: Prescient at $1,500 and Paramark at $2,000 make $299 feel like a steal.

**Do NOT offer free trials of paid tier.** The free tier IS the trial. Dollar headlines are the paywall.

**Annual pricing ($2,690/yr):** Launch only after 10+ paying customers with measured churn data.

---

## 6. Objection Handling

### "I've never heard of MMM."
"You know how every ad platform tells you they drove the most sales? Meta says 500, Google says 400, TikTok says 200, but you only had 700 total. Marketing Mix Modeling is the math that figures out who's actually telling the truth. Google and Meta use it internally to audit their own numbers."

### "I already have Google Analytics / GA4."
"GA4 tells you what happened after someone arrived at your site. MixLift tells you which ad dollars are actually responsible for getting them there. GA4 is the rearview mirror. MixLift is the GPS."

### "Can I try it for free?"
"Yes -- the free tier gives you 2 analyses per month with percentage-based results. The paid tier adds dollar values, scenario mode, and budget optimization. Want me to walk you through the install right now?"

### "I need to talk to my boss."
"Would it help if I sent you a one-page summary of the results from today's demo? You could forward that with 'here's what this found in our data' and let the numbers do the talking."

### "We're too busy right now."
"MixLift takes 5 minutes. You drop a CSV into Claude and get back the results. No implementation project, no dashboard to learn. When is your next budget planning cycle? Let's put 15 minutes on the calendar for two weeks before that."

### "What if the model is wrong?"
"Every model can be wrong. The difference is that MixLift tells you HOW CONFIDENT it is. Run it and compare to your intuition. On 2-3 channels, it will confirm what you know. On 1-2 channels, it will surprise you. Those surprises are where the money is."

### "Your product is too new."
"If you wait 6 months, you'll have made 6 months of budget decisions based on platform attribution that you already don't trust. On $50K/month ad spend, 15-25% waste is $7,500-$12,500/month. Waiting 6 months costs you $45K-$75K. MixLift costs $299/month."

---

## 7. Pipeline Targets

| Metric | Weekly Target | 45-Day Cumulative |
|---|---|---|
| Outreach sent | 35-50 DMs | 200-300 |
| Responses (15-20%) | 5-10 | 35-55 |
| Demos booked (50% of responses) | 3-5 | 18-30 |
| Demos completed (80% show) | 2-4 | 15-25 |
| Closed won (25-30% blended) | 1-2 by Week 4 | 10-15 |

### Red Flags
- Response rate <10%: outreach too generic or wrong ICP
- Demo booking <30% of responses: CTA too demanding
- Demo-to-close <15%: not running on their data or not closing on the call
- Month 1 churn >20%: stop selling, fix the product

---

## 8. Founder-Led Sales: Monday Morning Plan

**Hour 1 (8-9am):** Build first 15 prospects via LinkedIn search.

**Hour 2 (9-10am):** Send first 10 personalized DMs.

**Hour 3 (10-11am):** Record the 60-second Loom demo video.

**Rest of day:** Get to 25 prospects, send remaining DMs.

### Weekly Cadence

| Day | AM (2 hours) | PM (1 hour) |
|---|---|---|
| Monday | Add 10 prospects, send 10 DMs | Review pipeline, update tracker |
| Tuesday | Send 10 DMs, follow up Day 4 responses | Community engagement (Reddit/LinkedIn) |
| Wednesday | Demos (block 2-4pm) | Follow up on demos, send pricing one-pagers |
| Thursday | Send 10 DMs, follow up non-responders | LinkedIn content post (alternate weeks) |
| Friday | Demos (block 10am-12pm) | Weekly metrics review |

### Mistakes to Avoid

1. Explaining the technology instead of the outcome
2. Treating "interesting" as a buying signal
3. Optimizing templates instead of sending more outreach
4. Building instead of selling
5. Not closing on the call
6. Discounting

---

## 9. First 5 Customers Strategy

**Customer 1: Warm Network Close (Week 2-3)**
Ask your network: "Who do you know spending $30K+/mo on ads and frustrated with attribution?" Warm intro -> demo -> close.

**Customer 2: LinkedIn Power Prospect (Week 2-3)**
Find a DTC growth leader who posted about attribution problems. DM with vertical template referencing their post.

**Customer 3: Reddit/Community Inbound (Week 3-4)**
Post teardown on r/PPC. Convert commenters asking "how does this work?"

**Customer 4: Prescient/Paramark Price Refugee (Week 3-4)**
Search for companies using competitors. DM: "Same PyMC engine, $299/mo, self-serve."

**Customer 5: Concierge Re-engage (Week 4-5)**
Follow up warm-but-not-closed demos with a specific dollar finding from their data.

---

*The constraint is not strategy -- it is execution velocity. Send the DMs.*

*Last updated: March 7, 2026*
