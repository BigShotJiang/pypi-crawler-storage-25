# Reddit Teardown Post

**Target subreddit:** r/PPC (primary) or r/dtc (secondary)
**Tone:** Practitioner sharing findings. No selling in the post body. Conversational, specific, humble about limitations.
**CTA placement:** Comments only (per Reddit etiquette)

---

## Post Title Options (pick one)

1. "I ran a Bayesian MMM on a DTC brand's data -- here's what platform attribution got wrong"
2. "Ran Marketing Mix Modeling on 52 weeks of DTC spend data. The results were... uncomfortable."
3. "I built a Bayesian MMM tool and tested it on real (anonymized) DTC data. Here's the teardown."

---

## Post Body

Hey r/PPC,

I've been deep in the Marketing Mix Modeling rabbit hole for a while now, and I wanted to share a real analysis I ran on anonymized DTC eCommerce data. The brand runs 8 channels, spends about $50K/month on paid media, and does roughly $2M/month in revenue. Standard Shopify DTC operation.

I used a Bayesian MMM approach (PyMC-Marketing under the hood -- open source stats library). The model looks at 52 weeks of weekly spend-by-channel and revenue, then decomposes how much each channel actually contributed to revenue after controlling for seasonality, carryover effects (adstock), and diminishing returns (saturation).

Here's what the model found vs. what platform attribution claimed:

**Channel: Meta Prospecting**
- Platform ROAS: 4.2x
- Modeled ROAS: 2.8x
- Verdict: Still profitable, but significantly overstated. Meta is taking credit for organic and branded search conversions. About 33% of "Meta conversions" would have happened anyway.

**Channel: Meta Retargeting**
- Platform ROAS: 8.1x
- Modeled ROAS: 1.4x
- Verdict: This is the big one. Retargeting always looks incredible on last-click because it catches people who were already going to buy. The model says it's barely breaking even on a true incremental basis. The brand was spending $12K/month here -- the model recommends cutting to $4K.

**Channel: Google Search (Brand)**
- Platform ROAS: 12x
- Modeled ROAS: 0.9x (essentially zero incremental value)
- Verdict: Classic. People searching your brand name were going to buy anyway. This is a "defense" channel, not a "growth" channel. You need it, but you don't need to bid aggressively on it.

**Channel: Google Search (Non-Brand)**
- Platform ROAS: 2.1x
- Modeled ROAS: 2.4x
- Verdict: One of the few channels where the model actually shows HIGHER true ROAS than platform attribution. Non-brand search is genuinely driving incremental customers. The model says there's room to scale here.

**Channel: TikTok**
- Platform ROAS: 1.3x
- Modeled ROAS: 2.7x
- Verdict: The surprise winner. TikTok's attribution is terrible (short cookie window, cross-device issues), so platform ROAS dramatically understates its actual impact. The model picks up the halo effect -- TikTok drives awareness that converts on Google and Meta within 1-3 weeks. The brand was about to cut TikTok. The model says double down.

**Channel: YouTube**
- Platform ROAS: 0.6x
- Modeled ROAS: 1.8x
- Verdict: Same story as TikTok but less extreme. YouTube is an awareness driver that feeds downstream conversions. Platform attribution misses the assist entirely.

**Channel: Email**
- Not included in the model as paid media spend (it's a retention channel with near-zero marginal cost). The model treats email revenue as part of the baseline.

**Channel: Affiliate**
- Platform ROAS: 5.5x
- Modeled ROAS: 3.1x
- Verdict: Overstated but still strong. Affiliates are capturing some organic demand (coupon code users who would have bought anyway), but genuine new customer acquisition is happening.

**The budget optimizer output:**

After running the model, I asked it to optimize the same total monthly budget ($50K) for maximum revenue. The reallocation:

| Channel | Current | Optimized | Change |
|---|---|---|---|
| Meta Prospecting | $18,000 | $14,000 | -22% |
| Meta Retargeting | $12,000 | $4,000 | -67% |
| Google Brand | $5,000 | $2,000 | -60% |
| Google Non-Brand | $6,000 | $10,000 | +67% |
| TikTok | $4,000 | $11,000 | +175% |
| YouTube | $3,000 | $6,000 | +100% |
| Affiliate | $2,000 | $3,000 | +50% |

**Projected revenue impact:** +$47,000/month (+2.4%) at the same total spend.

**Caveats and limitations (being honest here):**

1. MMM is not a crystal ball. These are modeled estimates based on statistical relationships, not causal experiments. The gold standard is still geo-holdout testing, but that costs $50K+ and takes 8 weeks.

2. 52 weeks of data is on the lower end for MMM. The confidence intervals on some channels are wide. More data = tighter estimates.

3. The model assumes the historical relationship between spend and revenue will hold going forward. If the brand launches a viral product or a competitor enters the market, all bets are off.

4. Bayesian MMM uses prior distributions (informed assumptions about how ad channels typically behave). These priors help with small data but also mean the model isn't purely "letting the data speak." I used standard PyMC-Marketing priors which are well-validated for DTC.

5. The budget optimizer uses posterior mean estimates, not full posterior distributions. In plain English: the optimization is based on the model's best guess, not the full range of uncertainty. This is a known simplification.

**What surprised me:**

The retargeting result is always the most controversial. Brands are emotionally attached to retargeting because the ROAS numbers look incredible. But when you properly model incrementality, retargeting is almost always overstated by 3-5x. It's not that retargeting doesn't work -- it's that most of those "retargeted conversions" were people who were already going to buy.

The TikTok result is increasingly common. Short attribution windows systematically undervalue awareness channels. If your platform reports say TikTok has a 1.3x ROAS and you're about to cut it, you might be making a $100K+ mistake.

Happy to answer questions about the methodology. For those interested in how Bayesian MMM actually works -- the core idea is you're fitting a regression model where each channel's contribution is shaped by a saturation curve (diminishing returns) and an adstock decay function (carryover effect from past spend). The Bayesian part means you get probability distributions, not just point estimates, so you can quantify uncertainty.

---

## Comment CTA (post separately, ~30 min after the main post)

> For anyone who wants to try this on their own data -- I built this into a tool called MixLift. It runs through Claude AI (MCP protocol), costs $299/mo, and takes about 5 minutes to set up. `pip install mixlift` if you're curious. Happy to answer setup questions.

> Full disclosure: I'm the founder. But the post above is genuine analysis, not marketing. The methodology is open source (PyMC-Marketing). MixLift just makes it accessible without needing to write Python.
