# LinkedIn Carousel: "5 Signs Your Ad Budget Has a Leak"

**Format:** LinkedIn carousel (PDF upload), 7 slides total (cover + 5 content + CTA)
**Audience:** DTC growth marketers, VPs of Marketing, Directors of Growth
**Tone:** Direct, data-driven, slightly contrarian. No jargon without explanation.

---

## Slide 1: Cover

**Headline:** 5 Signs Your Ad Budget Has a Leak

**Body text:** You're spending $100K+/month on ads. Platform dashboards say everything is fine. But your bank account tells a different story.

**Visual description:** Bold white text on a dark navy background. A stylized funnel graphic with dollar signs visibly leaking out of cracks along the sides. MixLift logo small in the bottom corner.

---

## Slide 2: Sign #1

**Headline:** Your blended ROAS looks great, but profit margins are shrinking

**Body text:** Blended ROAS hides the truth. When you average a 5x channel with a 0.8x channel, the dashboard says 2.9x and everyone celebrates. Meanwhile, you're burning cash on a channel that loses money on every dollar you put in. The fix: measure each channel's TRUE incremental contribution, not what the platform claims.

**Visual description:** A simple bar chart showing two channels side by side. Channel A has a tall green bar (5x ROAS). Channel B has a short red bar (0.8x ROAS). A dotted line across both shows "Blended: 2.9x" with a checkmark next to it -- and an arrow pointing to Channel B saying "This is the leak."

---

## Slide 3: Sign #2

**Headline:** You doubled spend on a channel and revenue barely moved

**Body text:** Every ad channel has a saturation point -- a ceiling where more dollars stop producing more revenue. Most brands find this out the hard way, after they've already scaled spend 2x into diminishing returns. If you've ever thought "we scaled Meta from $30K to $60K and... nothing changed," that channel was already saturated.

**Visual description:** A saturation curve (S-curve) showing spend on the x-axis and revenue on the y-axis. The curve flattens dramatically on the right side. Two dots on the curve: one at $30K (steep part) and one at $60K (flat part). Arrow between them labeled "2x spend, 8% more revenue."

---

## Slide 4: Sign #3

**Headline:** Your "best channel" is the one with the most last-click conversions

**Body text:** Last-click attribution gives 100% credit to the final touchpoint. That's like giving your closer all the credit and ignoring the SDR who booked the meeting. Upper-funnel channels (YouTube, TikTok, podcasts) drive awareness that converts on Google and Meta. If you're cutting upper-funnel because "it doesn't convert," you're killing the channels that feed your converters.

**Visual description:** A simple flow diagram. Three icons in a row: YouTube (awareness) -> Meta (consideration) -> Google Search (conversion). An "X" mark over YouTube with text "Cut: no last-click conversions." Below it, a second row showing Meta and Google Search both with declining arrows, labeled "30 days later."

---

## Slide 5: Sign #4

**Headline:** You can't answer "what happens if I cut TikTok by 20%?"

**Body text:** If your response to this question is "let me check with the agency" or "we'd have to run a holdout test for 6 weeks," you're flying blind. A proper Marketing Mix Model can simulate budget scenarios in seconds -- because it has already modeled the relationship between each channel's spend and your revenue. No test required.

**Visual description:** A screenshot-style mockup of a scenario analysis output. Two columns: "Current Budget" and "Optimized Budget" with channel names (Meta, Google, TikTok, YouTube) and dollar amounts. A bold line at the bottom: "Projected revenue change: +$47,000/month." Clean, minimal design.

---

## Slide 6: Sign #5

**Headline:** You're spending the same amounts in July as you are in November

**Body text:** Seasonality changes everything. The channel that drives Q4 holiday revenue is not the same one that works in the summer slump. If your media plan is "same budget, same split, every month," you're leaving money on the table 10 months out of 12. The brands winning this game reallocate monthly based on modeled seasonal response curves.

**Visual description:** A 12-month line chart showing two lines. Line 1 (flat, red): "Actual monthly spend by channel -- constant." Line 2 (wavy, green): "Revenue response by channel -- highly seasonal." The gap between the two lines is shaded and labeled "Wasted spend" in the low-season months and "Missed opportunity" in the high-season months.

---

## Slide 7: CTA

**Headline:** Stop guessing. Start modeling.

**Body text:** MixLift is Bayesian Marketing Mix Modeling for DTC brands. Drop in your spend data, get the truth about your channels in 5 minutes. No data science team required. Starting at $299/month.

Book a free 15-minute live analysis -- we'll run it on YOUR data, live on Zoom. DM me or visit mixlift.io.

**Visual description:** Clean white slide. MixLift logo centered. Below the body text, a simple button-style graphic reading "Book Your Free Analysis." Subtle background gradient from white to light blue.
