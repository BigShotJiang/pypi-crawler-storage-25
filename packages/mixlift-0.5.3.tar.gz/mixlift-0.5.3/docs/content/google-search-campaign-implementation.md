# Google Search Campaign: Complete Implementation Package

**Campaign:** MixLift Google Search Ads | **Budget:** $2,500/month across 3 campaigns | **Goal:** Demo bookings | **Date:** March 7, 2026

---

## 1. Landing Page Copy — Main Variant (Campaign 1: MMM Tools)

**URL:** mixlift.io (or mixlift.io/mmm-tool)

### Hero Section

**Headline:**
Find the Wasted $47K in Your Ad Budget. In 5 Minutes. For $299/Month.

**Subheadline:**
MixLift is Bayesian Marketing Mix Modeling for DTC brands. The same methodology Prescient AI charges $1,500/month for — delivered through AI, with zero setup, and your data never leaves your machine.

**Primary CTA Button:**
Book a Free 15-Minute Live Analysis

**Secondary CTA (text link below button):**
Or install free: pip install mixlift — no credit card required

**Supporting Bullets (horizontal row below hero):**
- True Bayesian MMM (PyMC-Marketing engine)
- CSV to budget recommendations in 5 minutes
- No data scientist required
- 100% local — your data never leaves your machine

### Social Proof Bar

Since MixLift has zero customers at launch, use methodology credibility:

**Line 1 (centered, smaller text):**
Built on PyMC-Marketing — the same open-source Bayesian engine used by data science teams at HelloFresh, Wayfair, and Harry's.

**Line 2 (logo row):**
PyMC-Marketing | PyPI | Model Context Protocol (MCP) | Powered by MCMC Sampling

**Line 3 (quote block, italic):**
"We ran MixLift on 52 weeks of DTC brand data and found $41,000/month in recoverable revenue from budget reallocation — at the same total spend." — MixLift Sample Analysis

Replace with real customer testimonials as soon as 1-3 paying customers provide them.

### How It Works

**Section Headline:** From CSV to Clarity in 5 Minutes

**Step 1: Drop in Your Data**
Export your weekly spend by channel and revenue from Shopify, Google Sheets, or your ad platforms. One CSV file, one row per week. Minimum 26 weeks. MixLift auto-detects column names, date formats, and currency.

**Step 2: Run the Analysis**
Open Claude Desktop and say "Analyze my marketing data." MixLift's Bayesian engine fits a full Marketing Mix Model — adstock decay, saturation curves, seasonality, diminishing returns. No code. No dashboards. Just a conversation.

**Step 3: Get Budget Recommendations**
MixLift returns: true incremental ROAS by channel (not platform-inflated), saturation traffic lights (green/yellow/red), optimized budget allocation, and scenario modeling. Every estimate includes confidence intervals — no black-box point estimates.

### Features & Benefits

**Section Headline:** Enterprise Methodology. Startup Simplicity.

**Benefit 1: True Channel ROAS**
*Headline:* See What Each Channel Actually Contributes
Platform attribution double-counts conversions. Meta says 500 sales, Google says 400, TikTok says 200 — and you had 700 total. MixLift measures the incremental impact of each dollar, independent of any pixel or cookie. Every ROAS estimate includes a confidence interval so you know how certain the model is.

**Benefit 2: Saturation Analysis**
*Headline:* Know Exactly Where to Scale and Where to Cut
MixLift shows green/yellow/red traffic lights for every channel. Green means room to scale. Red means you are past the point of diminishing returns. The DTC brand in our analysis was spending $4,850/week on Google Search when the saturation point was $3,500. Every dollar above that was returning $0.40.

**Benefit 3: Budget Optimizer**
*Headline:* Same Spend. More Revenue. Show the CFO the Math.
MixLift finds the optimal allocation across your channels at your current total budget. No hand-waving — the model shows you exactly how much to shift from saturated channels to high-headroom channels and projects the revenue impact with uncertainty bounds.

**Benefit 4: Scenario Mode**
*Headline:* "What If I Cut TikTok by 30%?" — Answered in Seconds
Test budget scenarios without spending a dollar. Pull up MixLift during your weekly media review, run three scenarios, and make the call with data.

**Benefit 5: No Data Scientist Required**
*Headline:* Ask Questions in English. Get Answers in Dollars.
MixLift runs inside Claude, the AI assistant. You do not need to know Python, R, or Bayesian statistics. Ask "which channels should I scale?" and get a direct answer with supporting evidence.

**Benefit 6: Your Data Stays on Your Machine**
*Headline:* Zero-Cloud Architecture. Nothing Uploaded. Ever.
MixLift processes your data locally. The only network call is license key validation — no spend data, no revenue data, no customer data leaves your laptop.

### Competitor Comparison Table

**Section Headline:** How MixLift Compares

| | **MixLift** | **Prescient AI** | **Paramark** | **Robyn / Meridian** | **Triple Whale** |
|---|---|---|---|---|---|
| **Methodology** | True Bayesian MMM | True Bayesian MMM | True Bayesian MMM | True Bayesian MMM | Multi-touch attribution (not MMM) |
| **Price** | **$299/mo** | $1,500+/mo | $1,500+/mo | Free (software) | ~$199+/mo |
| **Setup time** | **5 minutes** | 2-4 weeks | 2-4 weeks | 1-3 months | Days (pixel install) |
| **Data scientist required** | **No** | No | No | **Yes** (R/Python) | No |
| **Data privacy** | **100% local** | Cloud upload | Cloud upload | Local (your code) | Cloud/pixel |
| **Confidence intervals** | Yes | Varies | Varies | Yes (manual) | No |
| **Saturation curves** | Yes | Yes | Yes | Yes (manual) | No |
| **Budget optimizer** | Yes | Yes | Yes | Manual | No |
| **Scenario modeling** | Yes (real-time) | Limited | Limited | Manual coding | No |
| **Interface** | AI conversation | Dashboard | Dashboard | Code / notebooks | Dashboard |

**Below table, small text:**
Triple Whale is an attribution tool, not a Marketing Mix Model. It uses pixel-based tracking subject to iOS 14.5+ data loss. Robyn (Meta) and Meridian (Google) are excellent open-source tools but require a data scientist who knows Python or R and 1-3 months to implement.

### FAQ Section

**Q: How is this different from what I see in Google Analytics or Meta Ads Manager?**
A: Platform attribution tells you who clicked before converting. The problem is every platform takes credit for the same conversion — and none can measure the impact of channels people did not click. Marketing Mix Modeling uses statistics, not pixels, to measure each channel's true incremental contribution.

**Q: How much data do I need?**
A: Minimum 26 weeks of weekly data (about 6 months). 52 weeks is ideal for full seasonality. You need one row per time period with columns for each channel's spend and a revenue column.

**Q: Can I trust a $299/month tool over Prescient AI at $1,500?**
A: MixLift uses the same open-source engine (PyMC-Marketing) that powers enterprise Bayesian MMM tools. The price difference is delivery: we do not have account managers, custom dashboards, or 4-week onboarding processes. We pass those savings to you.

**Q: Is my data safe?**
A: MixLift processes everything locally on your machine. No CSV uploads to our cloud. No revenue data transmitted. The only API call is a license key check that sends zero marketing data.

**Q: What if the model contradicts what I believe about my channels?**
A: Good — that is where the money is. In practice, the model confirms your intuition on 2-3 channels and surprises you on 1-2 others. Those surprises are where reallocation unlocks revenue.

**Q: Can I cancel anytime?**
A: Yes. Monthly billing through Stripe. No annual contracts. No cancellation fees.

### Final CTA Section

**Headline:** Every Month Without a Mix Model, You Are Leaving Money on the Table

The average MixLift analysis finds 15-25% of ad spend going to saturated or low-incrementality channels. At $30K/month in ad spend, that is $4,500-$7,500/month in recoverable revenue.

Book a free 15-minute live analysis. We will run MixLift on your actual data, live on Zoom. No pitch deck. No demo environment. Just your numbers and what they mean.

**Primary CTA Button:** Book Your Free 15-Minute Analysis
**Secondary CTA:** Or start free: pip install mixlift

### Footer Trust Elements

- "Built on PyMC-Marketing, the open-source Bayesian marketing science library"
- "Your data never leaves your machine"
- "No contracts. Cancel anytime."
- hello@mixlift.io

---

## 2. Landing Page Copy — Conquest Variant (Campaign 2)

**URL:** mixlift.io/compare

### Hero Section

**Headline:** Looking for a Prescient AI Alternative? Here Is What $1,200/Month in Savings Looks Like.

**Subheadline:** MixLift delivers the same Bayesian Marketing Mix Modeling methodology as Prescient AI, Paramark, and Recast — at $299/month instead of $1,500+. Same math. Same confidence intervals. No 4-week onboarding. No cloud data uploads.

**CTA Button:** Book a Free Side-by-Side Analysis

**Below CTA, small text:** We will run MixLift on your data live on Zoom. Compare the output to what you are getting today. 15 minutes. Free.

### Direct Comparison Table

| | **MixLift** | **Prescient AI** | **Paramark** | **Recast** |
|---|---|---|---|---|
| **Monthly price** | **$299** | $1,500-$2,500 | $1,500+ | $2,000+ |
| **Annual cost** | **$3,588** | $18,000-$30,000 | $18,000+ | $24,000+ |
| **Bayesian methodology** | Yes (PyMC) | Yes | Yes | Yes |
| **Setup time** | 5 minutes | 2-4 weeks | 2-4 weeks | 2-4 weeks |
| **Account manager** | No (not needed) | Yes (included in price) | Yes | Yes |
| **Custom dashboards** | No (AI conversation) | Yes | Yes | Yes |
| **Data upload to vendor cloud** | **No — 100% local** | Yes | Yes | Yes |
| **Real-time scenario modeling** | Yes | Limited | Limited | Limited |
| **Contract length** | Month-to-month | Annual typical | Annual typical | Annual typical |
| **Cancellation fees** | None | Varies | Varies | Varies |

**Below table:** The methodology is the same. The difference is delivery model. Prescient AI, Paramark, and Recast charge $1,500-$2,500/month because they bundle account managers, custom dashboards, and managed onboarding. If you want white-glove service, those are good products. If you want the same Bayesian math at 80% less cost and can upload a CSV yourself, MixLift is built for you.

### Why Teams Switch Section

**Reason 1: The math is the same, the price is not.** MixLift and enterprise MMM tools all use Bayesian inference with MCMC sampling. The $1,200/month difference buys you an account manager and a dashboard. If you do not need a human intermediary, that is $14,400/year back in your budget.

**Reason 2: 5 minutes vs. 4 weeks.** Enterprise vendors require multi-week onboarding. MixLift: install, upload CSV, run. You have results before the enterprise vendor finishes their intake form.

**Reason 3: Your data stays on your machine.** Enterprise vendors require cloud uploads of channel spend and revenue. MixLift runs locally. Your sensitive financial data never leaves your laptop.

**Reason 4: No annual lock-in.** Most enterprise MMM tools push annual contracts at $18,000-$30,000. MixLift is month-to-month at $299. No early termination fees.

**Reason 5: AI-native, not dashboard-native.** Ask Claude "Which channels should I scale next quarter?" and get a direct answer with evidence. Scenario modeling in real-time conversation, not a ticketing queue.

### Switching Narrative

**Headline:** Switching Takes 5 Minutes

You do not need to migrate anything. No data integration to undo, no pixels to remove, no API connections to disconnect.

1. Export your existing spend-by-channel data as a CSV (you already have this).
2. Install MixLift: `pip install mixlift`
3. Run the analysis in Claude Desktop: "Analyze my marketing data."
4. Compare the output to your current vendor's results.

If results align (they should — same methodology), you just saved $14,400/year. If they differ, book a free call and we will walk through the discrepancy together.

**CTA:** Book a Free Comparison Analysis

---

## 3. Landing Page Copy — Problem-Aware Variant (Campaign 3)

**URL:** mixlift.io/fix-wasted-spend

### Hero Section

**Headline:** Your Ad Platforms Are Lying About ROAS. Here Is How to Find the Truth.

**Subheadline:** Meta says Meta is amazing. Google says Google is incredible. TikTok says TikTok is the future. But your P&L tells a different story. There is a way to measure what is actually driving revenue — and it does not involve another pixel.

**CTA Button:** See How It Works — Free 15-Minute Analysis

### The Problem With Platform Attribution

**Section Headline:** Why Your Ad Dashboard Numbers Do Not Match Your P&L

You are spending $30K, $50K, maybe $100K+ per month on ads. The dashboards say everything is working. Meta reports 4x ROAS. Google shows 5x. TikTok claims 3x. Add it all up and you should be swimming in profit. But the bank account tells a different story.

**Every platform takes credit for the same conversion.** A customer sees a TikTok ad, clicks a Meta retargeting ad, and Googles your brand name to buy. TikTok claims it. Meta claims it. Google claims it. You had one sale and three platforms saying they each drove it.

**Retargeting ROAS is inflated 3-5x.** Retargeting campaigns show the highest ROAS because they capture people already going to buy. One DTC brand was spending $1,700/week on Meta retargeting with platform-reported 8x ROAS. Actual incremental ROAS: 1.9x.

**Upper-funnel channels look terrible on last-click.** TikTok, YouTube, and podcasts drive awareness that leads to a Google search and direct purchase. Last-click gives 100% credit to that final Google click. Result: you underinvest in channels driving real growth.

**iOS 14.5 made tracking worse, and it is not getting better.** Apple removed 40-60% of tracking signal. Cookie deprecation is next. Platform attribution is built on a crumbling foundation.

### There Is a Better Way

**Section Headline:** What Fortune 500 Companies Have Known for 60 Years

Companies like P&G, Unilever, and Coca-Cola use Marketing Mix Modeling (MMM). Instead of tracking clicks, MMM measures the statistical relationship between changes in spend and changes in revenue over time.

The problem: traditional MMM costs $50,000-$200,000, takes months, and requires a data science team.

**MixLift changes that.** Same methodology as the Fortune 500. Upload a CSV, get results in 5 minutes. $299/month instead of $50,000. No data scientist — you talk to an AI assistant.

### What MixLift Shows You

**True ROAS by Channel:** What each channel actually contributes, independent of platform reporting. With confidence intervals.

**Saturation Traffic Lights:** Green/yellow/red showing which channels have room to scale and which are past diminishing returns.

**Budget Optimizer:** Same total spend. More revenue. Exactly how much to shift and where.

**Scenario Modeling:** "What if I cut Meta retargeting by 50%?" Projected revenue impact in seconds.

### Sample Analysis

A DTC skincare brand ($5.6M revenue, 8 channels, $480K annual ad budget) ran MixLift. Platform attribution said Google Search was their best channel at 5.2x ROAS. MixLift showed it was past saturation — actual marginal ROAS: 1.4x. Meanwhile, TikTok had 3.8x incremental ROAS with massive headroom. Budget optimizer: reallocate $1,350/week from Google Search to TikTok. Projected impact: +$41,000/month, same total spend.

### Final CTA

**Headline:** Your Ad Budget Has a Leak. Find It in 15 Minutes.

Book a free call. We run MixLift on your actual data, live on Zoom. No pitch deck. No demo environment. Just your numbers and what they mean.

**CTA Button:** Book Your Free 15-Minute Analysis
**Below CTA:** Or start free: pip install mixlift — no credit card, no data uploads

---

## 4. Demo Booking Flow

### Recommended Tool: Calendly (Free Tier)

### Booking Page Setup

**Event type:** Free 15-Minute Live Analysis
**Duration:** 20 minutes (book as 20, market as 15 for buffer)
**Location:** Zoom (auto-generate unique link per booking)
**Minimum notice:** 24 hours
**Buffer:** 15 minutes between meetings
**Availability:** Spread across week, at least one slot bookable within 48 hours

**Page description:**
In 15 minutes, we will run MixLift on your actual marketing data and show you which channels are working, which are over-saturated, and where budget reallocation can unlock revenue. No pitch. No slides. Just your numbers.

### Form Fields

| Field | Type | Required |
|---|---|---|
| Full name | Text | Yes |
| Work email | Email | Yes |
| Company name | Text | Yes |
| Company website | URL | No |
| Monthly ad spend (approximate) | Dropdown: Under $10K / $10K-$30K / $30K-$50K / $50K-$100K / $100K+ | Yes |
| Number of paid channels | Dropdown: 1-2 / 3-4 / 5-7 / 8+ | Yes |
| Do you have 6+ months of weekly spend data in a CSV or spreadsheet? | Yes/No | Yes |
| Anything specific you want to learn? | Textarea | No |

### Confirmation Email

**Subject:** Your MixLift analysis is booked — here is how to prepare

Hi [First Name],

Your free 15-minute live analysis is confirmed for [Date] at [Time] [Timezone].

**Zoom link:** [auto-generated]

To make the most of our 15 minutes, please have your data ready:

**Your data file (CSV or Excel):**
- One row per week (or month)
- One column per channel with spend amounts (e.g., "meta_spend", "google_spend", "tiktok_spend")
- One column for revenue
- Minimum 26 weeks of data. 52 weeks is ideal.

**Where to get this:**
- Shopify: Analytics > Reports > Sales over time (export weekly)
- Google Sheets: If you track spend in a spreadsheet, export as CSV
- Ad platforms: Export weekly spend from each platform, combine into one sheet

Do not worry about formatting. MixLift auto-detects column names, date formats, and currency.

If you do not have data ready, no problem — we will use a realistic sample dataset.

Talk soon,
[Founder name]

P.S. If you need to reschedule: [reschedule URL]

### Reminder Email (24 hours before)

**Subject:** Tomorrow: your MixLift analysis at [Time]

Quick reminder — your free live analysis is tomorrow at [Time] [Timezone].

**Zoom link:** [link]

Quick checklist:
- Do you have your CSV/spreadsheet ready? (Weekly spend by channel + revenue)
- If not, no worries — we will use a sample dataset

### Post-Call Follow-Up Email (within 2 hours of call)

**Subject:** Your MixLift analysis results + next steps

Hi [First Name],

Great talking with you. Here is a recap:

**Key findings:**
- [Channel A] is [over-saturated / under-invested] — [one-line detail]
- [Channel B] [specific finding]
- Budget optimizer recommends [specific shift] for projected +$[X]/month at the same total spend

**What you can do right now:**
1. [Most impactful reallocation recommendation]
2. [Second recommendation]

**To get ongoing access (scenario mode, dollar values, budget optimizer, monthly re-runs):**
MixLift Growth is $299/month, cancel anytime. Install with `pip install mixlift` and activate your key.

Want me to set you up? Reply to this email or book a quick call: [booking link]

[Founder name]

---

## 5. Ad Extensions (Complete)

### Sitelink Extensions (8)

| # | Title (max 25 char) | Description Line 1 (max 35 char) | Description Line 2 (max 35 char) | URL |
|---|---|---|---|---|
| 1 | Free 15-Min Analysis | We run MixLift on your data. | Live on Zoom. No pitch. Free. | /book-demo |
| 2 | See Pricing | $299/mo. No contracts. | Same math as $1,500/mo tools. | /#pricing |
| 3 | How It Works | CSV to budget recs in 5 min. | No data scientist required. | /#how-it-works |
| 4 | Compare MMM Tools | MixLift vs Prescient, Robyn. | Side-by-side feature table. | /compare |
| 5 | DTC Sample Analysis | Found $41K/mo in wasted spend. | Real data, real results. | /#case-study |
| 6 | Try Free — No Card | 2 free analyses per month. | Full Bayesian engine included. | /#pricing |
| 7 | Data Privacy | Your data never leaves your PC. | 100% local processing. | /#faq |
| 8 | What Is MMM? | Marketing Mix Modeling guide. | Why platforms overstate ROAS. | /fix-wasted-spend |

### Callout Extensions (6)

1. No Data Scientist Needed
2. Results in 5 Minutes
3. $299/Month Cancel Anytime
4. 100% Local Data Privacy
5. True Bayesian MMM Engine
6. Free Tier Available

### Structured Snippet Extensions (2 sets)

**Set 1:**
- Header: Types
- Values: Channel ROAS, Saturation Analysis, Budget Optimizer, Scenario Modeling, Seasonality Detection, Convergence Diagnostics

**Set 2:**
- Header: Types
- Values: Bayesian MMM, Adstock Decay, Saturation Curves, Budget Allocation, What-If Analysis

### Price Extension

- Type: Brands / Currency: USD / Qualifier: From

| Item | Price | Description | URL |
|---|---|---|---|
| Free Tier | $0/mo | 2 analyses, % ROAS, no card | /#pricing |
| Growth Tier | $299/mo | Unlimited, $ values, optimizer | /#pricing |

---

## 6. UTM Parameter Structure

### Templates by Campaign

**Campaign 1 — MMM Tools:**
```
{lpurl}?utm_source=google&utm_medium=cpc&utm_campaign=mmm_tools_high_intent&utm_term={keyword}&utm_content={creative}
```

**Campaign 2 — Competitor Conquest:**
```
{lpurl}?utm_source=google&utm_medium=cpc&utm_campaign=competitor_conquest&utm_term={keyword}&utm_content={creative}
```

**Campaign 3 — Problem Aware:**
```
{lpurl}?utm_source=google&utm_medium=cpc&utm_campaign=problem_aware&utm_term={keyword}&utm_content={creative}
```

### Setup in Google Ads

1. Go to Campaign > Settings > Campaign URL options
2. Paste the template in "Tracking template"
3. `{lpurl}` = final URL from each ad, `{keyword}` = actual search query, `{creative}` = ad creative ID

### Naming Conventions

| Parameter | Convention | Examples |
|---|---|---|
| utm_source | Always `google` | google |
| utm_medium | Always `cpc` | cpc |
| utm_campaign | snake_case, descriptive | mmm_tools_high_intent |
| utm_term | Auto `{keyword}` | marketing_mix_modeling_tool |
| utm_content | Auto `{creative}` or manual A/B labels | ad_v1_outcome |

---

## 7. Conversion Tracking Setup Checklist

### Primary Conversion: Demo Booked

**Step 1: Create conversion in Google Ads**
1. Goals > Conversions > New conversion action > Website
2. Name: "Demo Booked"
3. Category: Submit lead form
4. Value: $299
5. Count: One per user
6. Click-through window: 30 days
7. View-through window: 1 day
8. Attribution: Data-driven

**Step 2: Install conversion tag**
- Set Calendly to redirect to mixlift.io/thank-you after booking
- Create /thank-you page with confirmation message
- Place Global site tag (gtag.js) in `<head>` of all pages
- Place Event snippet on /thank-you page only

**Step 3: Verify**
- Book a test demo, confirm /thank-you loads
- Check Google Tag Assistant fires correctly
- Wait 24h, confirm "Recording conversions" in Google Ads

### Secondary Conversions (observe, do not optimize)

| Conversion | Category | Trigger |
|---|---|---|
| CTA Click | Other | Click on "Book" button |
| Pricing Page View | Page view | Visit to /#pricing |
| Free Install Click | Other | Click on "pip install" links |

### GA4 Setup

1. Create GA4 property at analytics.google.com
2. Install GA4 tag on all pages
3. Link GA4 to Google Ads (Admin > Google Ads Links)
4. Enable auto-tagging in Google Ads
5. Create events: demo_booked (on /thank-you), cta_click, pricing_view, compare_view
6. Mark demo_booked as a conversion in GA4

---

## 8. Week 1 Launch Checklist

### Day 1: Foundation (2-3 hours)

- [ ] Create Google Ads account. Select "Expert Mode" — not Smart Campaigns.
- [ ] Set up billing. Add credit card.
- [ ] Enable auto-tagging (Account settings > Auto-tagging > check).
- [ ] Create GA4 property. Install GA4 tag on all pages. Link to Google Ads.
- [ ] Install Global site tag (gtag.js) on all landing pages.
- [ ] Create /thank-you page. Install conversion event snippet on this page only.
- [ ] Set up Calendly booking page with form fields. Post-booking redirect to /thank-you. Set up confirmation email. Test with dummy booking.
- [ ] Verify conversion tracking. Book test demo. Confirm tag fires. Wait 24h for "Recording conversions."

### Day 2: Campaign Build (3-4 hours)

- [ ] Create Campaign 1: MMM Tools (High Intent) — Search only, US targeting, $50/day
- [ ] Create ad groups with keywords (see keyword strategy doc)
- [ ] Write RSAs (15 headlines + 4 descriptions each)
- [ ] Create Campaign 2: Competitor Conquest — $17/day, landing page: /compare
- [ ] Create Campaign 3: Problem Aware — $17/day, landing page: /fix-wasted-spend
- [ ] Add account-level negative keywords
- [ ] Add all ad extensions (sitelinks, callouts, structured snippets, price)
- [ ] Set up campaign URL tracking templates

### Day 3: QA and Launch (1 hour)

- [ ] Review ads for editorial compliance. Do NOT use competitor names in headlines (trademark policy) — use in descriptions or keywords only.
- [ ] Preview all landing pages on desktop and mobile. Confirm CTAs, Calendly widget, page speed.
- [ ] Book one more test demo. Verify full path: landing page > CTA > Calendly > /thank-you > conversion fires.
- [ ] Set all three campaigns to "Enabled."
- [ ] Wait 2-4 hours. Confirm impressions showing in all campaigns.
- [ ] Set calendar reminders: 24h, 48h, 72h post-launch checks.

---

## 9. Daily/Weekly Monitoring Checklist

### Daily — Week 1 (5-10 minutes)

| Check | Action if threshold hit |
|---|---|
| Impressions showing? | If zero: check ad approval, keyword status, billing |
| CTR by campaign | If <2%: review ad copy relevance |
| Average CPC | If >$15: add negatives, check search terms |
| **Search terms report** | Add irrelevant terms as negatives. Do this EVERY DAY in Week 1. |
| Conversions | If zero after 3+ demos booked: tag is broken — fix now |
| Budget pacing | If under-spending: keywords may be too restrictive |

### Weekly — Weeks 2-4 (20-30 minutes)

| Check | Action |
|---|---|
| Full search terms review | Add negatives, find new keyword opportunities |
| CTR by ad group | If <2% after 200+ impressions: pause, test new headlines |
| Conversion rate by campaign | If zero conversions after 100+ clicks: review landing page |
| Quality Score | If <5: improve ad-keyword-landing page alignment |
| Cost per conversion | Target <$150. If >$200: tighten keywords, improve pages |
| Device performance | If mobile converts poorly: add -30% mobile bid adjustment |

### Decision Rules

- **Pause a keyword:** 100+ clicks, zero conversions
- **Pause an ad group:** CTR <1.5% after 500+ impressions
- **Pause Campaign 3:** Zero conversions after $200+ spend — reallocate to Campaign 1
- **Increase budget:** Cost per demo under $100 AND capacity for more demos
- **Switch bidding:** After 30+ conversions: switch to Target CPA

### Target Metrics

| Metric | Target | Good | Needs Work |
|---|---|---|---|
| CTR | 4-6% | >6% | <3% |
| Average CPC | $5-$12 | <$8 | >$15 |
| Landing page CVR | 3-5% | >5% | <2% |
| Cost per demo | $75-$150 | <$100 | >$200 |
| Demo show rate | 80%+ | >85% | <70% |
| Demo-to-close rate | 30-40% | >40% | <20% |
