# MCP Marketplace Listing: MixLift

**Submission target:** Anthropic MCP Tool Directory / Claude Marketplace
**Category:** Data Analysis / Marketing Analytics

---

## Listing Name

MixLift -- Bayesian Marketing Mix Modeling

## Tagline

Enterprise-grade Marketing Mix Modeling in your AI assistant. Drop a CSV, get channel-level ROAS, saturation analysis, and budget optimization in minutes.

## Description

MixLift brings Bayesian Marketing Mix Modeling (MMM) directly into Claude via MCP. It helps marketing teams understand the true incremental value of each advertising channel -- beyond what platform attribution reports.

**What it does:**

Upload your weekly spend-by-channel and revenue data as a CSV. MixLift runs a full Bayesian MMM analysis using PyMC-Marketing and returns:

- **True ROAS by channel** -- incremental revenue contribution, not last-click attribution
- **Saturation analysis** -- which channels have hit diminishing returns and which have headroom
- **Budget optimization** -- how to reallocate your existing budget for maximum revenue
- **Scenario modeling** -- "what happens if I cut TikTok by 20% and move it to YouTube?"
- **Confidence intervals** -- Bayesian uncertainty quantification on every estimate
- **Contextual memory** -- re-run on updated data and MixLift shows what changed since your last analysis

**Who it's for:**

DTC eCommerce brands spending $30K+/month on paid media across 3+ channels. Marketing Directors, VPs of Growth, and Heads of DTC who need enterprise-grade measurement without a data science team.

**How it works:**

1. Install: `pip install mixlift`
2. Configure your MCP client (Claude Desktop, Cursor, etc.) to connect to MixLift
3. Ask Claude: "Analyze my marketing spend data" and point it at your CSV
4. Get a full MMM analysis in ~5 minutes

No dashboards. No implementation project. No data science background required. Claude interprets the results in plain English.

## Install Command

```
pip install mixlift
```

## MCP Configuration

```json
{
  "mcpServers": {
    "mixlift": {
      "command": "python",
      "args": ["-m", "mixlift_mcp"]
    }
  }
}
```

## Feature List

- Bayesian Marketing Mix Modeling (PyMC-Marketing engine)
- Automatic format detection (weekly/monthly, date parsing, currency handling)
- Adstock decay modeling (carryover effects)
- Saturation curve fitting (diminishing returns)
- Holiday auto-detection (US holidays)
- Seasonality decomposition
- Channel-level ROAS with confidence intervals
- Marginal ROAS (next-dollar efficiency)
- Budget optimizer (same spend, more revenue)
- Scenario mode (what-if analysis)
- Saturation traffic lights (green/yellow/red per channel)
- Contextual memory with delta reporting (tracks changes over time)
- Posterior predictive checks (model validation)
- Convergence diagnostics (R-hat)
- Tiered access: Free (2 runs/month, % only) and Growth ($299/mo, full dollar values + all features)

## Requirements

- Python 3.10+
- MCP-compatible client (Claude Desktop, Cursor, or any MCP host)
- CSV data: weekly or monthly rows with spend-by-channel columns and a revenue column
- Minimum 26 weeks of data recommended (52 weeks ideal)

## Screenshot Descriptions

**Screenshot 1: "Analysis Request"**
Shows a Claude Desktop conversation where the user says "Analyze my marketing spend data from marketing_data.csv." Claude responds confirming it detected 8 channels, 52 weeks of data, and is running the model. Clean, conversational interface.

**Screenshot 2: "ROAS Results"**
Shows the MCP output rendered in Claude: a formatted table with channel names, platform-reported ROAS, modeled ROAS, confidence intervals, and a brief interpretation. Highlights the gap between platform and modeled ROAS for Meta Retargeting.

**Screenshot 3: "Saturation Traffic Lights"**
Shows the saturation analysis output with green/yellow/red indicators per channel. Green = headroom to scale. Yellow = approaching saturation. Red = saturated, consider reducing. Each channel has a one-line explanation.

**Screenshot 4: "Budget Optimizer"**
Shows the budget optimization output: a table with current allocation, recommended allocation, dollar change, and projected revenue impact. Bold bottom line: "+$47,000/month projected revenue at the same total spend."

**Screenshot 5: "Scenario Mode"**
Shows the user asking "What happens if I cut TikTok by 20% and move it to Google Non-Brand?" Claude returns the projected impact with confidence intervals. Demonstrates the conversational, iterative workflow.

## Pricing

- **Free tier:** 2 analyses per month. Results show percentage-based ROAS (no dollar values). Full modeling engine.
- **Growth tier:** $299/month. Unlimited analyses. Full dollar values, budget optimizer, scenario mode, contextual memory.

## Links

- Landing page: https://mixlift.io
- PyPI: https://pypi.org/project/mixlift/
- Documentation: https://mixlift.io/docs

## Support

- Email: hello@mixlift.io
- Concierge onboarding included for Growth tier customers
