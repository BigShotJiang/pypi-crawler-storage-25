# MixLift Landing Page v2 -- Copy Document

**Target keywords:** marketing mix modeling, Bayesian MMM, media mix model, MCP marketing, marketing attribution, DTC marketing analytics
**Audience:** DTC eCommerce marketing leaders ($10M-$80M revenue)
**Goal:** Demo booking (free 15-minute live analysis)

---

## Hero Section

### Headline

Your Ad Platforms Are Lying About ROAS. Here's the Truth.

### Subheadline

MixLift is Bayesian Marketing Mix Modeling for DTC brands. Drop in your spend data, get the real incremental value of every channel in 5 minutes. No data science team required. Starting at $299/month.

### Primary CTA

Book a Free 15-Minute Live Analysis

### Secondary CTA

Try the Sample Dataset -- No Account Needed

---

## Social Proof Bar

"We found $47,000/month in wasted spend in our first analysis." -- Anonymized DTC brand, $20M revenue

As seen on: PyPI | MCP Marketplace | Built with PyMC-Marketing

---

## Problem Section

### Headline

You're Spending $100K+/Month on Ads and Flying Blind

### Body

Platform attribution tells you what you want to hear. Meta says Meta is amazing. Google says Google is incredible. TikTok says TikTok is the future.

But when you look at your P&L, the numbers don't add up. Revenue isn't growing as fast as your "ROAS" suggests it should.

That's because platform attribution is fundamentally broken:

- **Last-click attribution** gives 100% credit to the final touchpoint and ignores the channels that drove awareness
- **Retargeting ROAS is inflated 3-5x** because it captures people who were already going to buy
- **Upper-funnel channels like TikTok and YouTube look terrible** on last-click, even when they're your biggest growth drivers
- **iOS 14.5+ destroyed tracking accuracy**, and it's only getting worse with cookie deprecation

The result: you're over-investing in channels that look good on dashboards and under-investing in channels that actually drive growth.

---

## Solution Section

### Headline

Marketing Mix Modeling That Doesn't Require a Data Science Team

### Body

Marketing Mix Modeling (MMM) has been the gold standard for media measurement at Fortune 500 companies for decades. It uses statistical modeling -- not pixel tracking -- to measure each channel's true contribution to revenue.

The problem? Traditional MMM costs $50K-$200K per engagement and takes months to deliver.

MixLift changes that.

We use the same Bayesian methodology (PyMC-Marketing) that powers enterprise MMM, but we deliver it through an AI interface. You talk to Claude, drop in your CSV, and get the full analysis in minutes.

No dashboards to learn. No implementation project. No data science hire. Just the truth about your ad spend.

---

## How It Works Section

### Headline

From CSV to Clarity in 5 Minutes

### Step 1: Drop in your data

Export your weekly spend by channel and revenue from Shopify, Google Sheets, or your ad platforms. One CSV file, one row per week.

### Step 2: Run the analysis

Open Claude Desktop (or any MCP client) and say: "Analyze my marketing spend data." MixLift's Bayesian engine runs a full Marketing Mix Model -- adstock decay, saturation curves, seasonality, the works.

### Step 3: Get the truth

MixLift returns: true ROAS by channel (not platform-inflated), saturation analysis (which channels have headroom), budget optimization (how to reallocate for maximum revenue), and scenario modeling (what-if analysis).

### Step 4: Act on it

Reallocate budget with confidence. Re-run monthly to track changes. MixLift remembers your previous analyses and shows what improved.

---

## Sample Dataset Section

### Headline

Don't Have Your Data Ready? Start With Ours.

### Body

We built a realistic 8-channel, 52-week sample dataset so you can see exactly what MixLift does before committing your own data. It simulates a $20M DTC brand spending $50K/month across Meta, Google, TikTok, YouTube, email, affiliate, and direct mail.

Install MixLift, load the sample dataset, and run the analysis. You'll see the full output -- channel ROAS, saturation traffic lights, budget optimization, scenario mode -- in under 5 minutes.

No account required for the free tier. Just `pip install mixlift` and go.

### CTA

Download the Sample Dataset and First-Run Guide

---

## Feature List Section

### Headline

Enterprise Methodology, Startup Simplicity

| Feature | Description |
|---|---|
| **Bayesian MMM Engine** | Full PyMC-Marketing model with MCMC sampling. Not a regression hack -- real Bayesian inference with posterior distributions. |
| **True Channel ROAS** | Incremental revenue contribution per channel, with confidence intervals. See what each channel actually contributes after controlling for everything else. |
| **Saturation Analysis** | Traffic-light indicators (green/yellow/red) showing which channels have room to scale and which have hit diminishing returns. |
| **Budget Optimizer** | Same total spend, more revenue. MixLift finds the optimal allocation across your channels and tells you exactly how much to shift. |
| **Scenario Mode** | "What if I cut TikTok by 20%?" Get projected revenue impact instantly. Test budget scenarios without spending a dollar. |
| **Seasonality Detection** | Automatic holiday and seasonal pattern detection. Separates true channel impact from seasonal lift. |
| **Contextual Memory** | Re-run on updated data and MixLift shows what changed. Track channel performance trends over time without starting from scratch. |
| **Convergence Diagnostics** | R-hat statistics and posterior predictive checks ensure the model actually fits your data. No black box. |
| **Data Privacy** | Your data stays on your machine. MixLift runs locally -- nothing is uploaded to our servers. The only API call is license validation. |
| **MCP Native** | Built for the Model Context Protocol. Works with Claude Desktop, Cursor, and any MCP-compatible client. |

---

## Results Section (Day 0 Case Study)

### Headline

What One Analysis Revealed for a $20M DTC Brand

### Body

We ran MixLift on 52 weeks of data from a DTC brand doing $20M in annual revenue with $600K in annual ad spend across 8 channels.

**The headline finding:** $47,000/month in recoverable revenue from budget reallocation -- at the same total spend.

**Key insights:**

- Meta Retargeting was overstated by 5.8x on platform attribution. The model showed it was barely breaking even on an incremental basis.
- TikTok was understated by 2.1x. Short attribution windows were hiding its true impact as an awareness driver.
- Google Non-Brand Search had significant headroom to scale -- the channel was far from saturation.
- The budget optimizer recommended shifting 22% of spend from saturated channels to high-headroom channels.

**The takeaway:** Platform attribution was telling this brand to do the exact opposite of what would maximize revenue. Without a Marketing Mix Model, they would have cut their best channel and doubled down on their worst.

---

## Pricing Section

### Headline

Pricing That Makes the Decision Easy

### Free Tier -- $0/month

- 2 analyses per month
- Full Bayesian MMM engine
- Percentage-based ROAS (no dollar values)
- Saturation traffic lights
- Works with sample dataset or your own data
- No credit card required

**Best for:** Evaluating MixLift before committing. See the methodology in action.

### Growth Tier -- $299/month

- Unlimited analyses
- Full dollar values on all metrics
- Budget optimizer
- Scenario mode (what-if analysis)
- Contextual memory and delta reporting
- Concierge onboarding (we set it up with you)
- Priority support

**Best for:** DTC brands ready to optimize their media spend with real numbers.

### How This Compares

| | MixLift Growth | Prescient AI | Recast | In-House DS Hire |
|---|---|---|---|---|
| Monthly cost | $299 | $1,500+ | $2,000+ | $15,000+ |
| Setup time | 5 minutes | 2-4 weeks | 2-4 weeks | 3-6 months |
| Data stays local | Yes | No | No | Yes |
| Bayesian methodology | Yes | Yes | Yes | Depends |
| Results in plain English | Yes (via Claude) | Dashboard | Dashboard | Depends |

---

## Trust Section

### Headline

Built on Open Science, Not Black Boxes

### Body

MixLift's modeling engine is built on PyMC-Marketing, the open-source Bayesian marketing science library maintained by PyMC Labs. The same methodology used by data science teams at brands like HelloFresh, Wayfair, and Harry's.

Every analysis includes convergence diagnostics (R-hat) and posterior predictive checks so you can verify the model fits your data. We show confidence intervals on every estimate because a point estimate without uncertainty is just a guess.

Your data never leaves your machine. MixLift runs entirely locally -- the only network call is license key validation against our API. No data uploads, no cloud processing, no third-party access.

---

## FAQ Section

**How much data do I need?**
Minimum 26 weeks of weekly data. 52 weeks (one full year) is ideal because it captures seasonality. Monthly data works too -- MixLift auto-detects the frequency.

**What format does my data need to be in?**
A CSV with one row per time period (week or month). Columns for each channel's spend and a revenue column. MixLift auto-detects column names, date formats, and currency symbols.

**Is this the same as what Prescient AI / Recast / Measured does?**
Methodologically, yes. They all use Bayesian Marketing Mix Modeling. The difference is delivery: MixLift runs locally through Claude AI instead of a SaaS dashboard, which is why it costs 80% less and sets up in 5 minutes instead of 4 weeks.

**Can I trust Bayesian models?**
Bayesian MMM has been used for media measurement since the 1960s (originally by Nielsen and P&G). The methodology is well-established in academic literature and industry practice. MixLift uses PyMC-Marketing's validated priors and includes model fit diagnostics with every analysis.

**What if I only have 3-4 channels?**
MixLift works with as few as 2 channels, though results improve with more channels and more data. The minimum viable input is 26 weeks of data with 2+ channels.

**My data is sensitive. Where does it go?**
Nowhere. MixLift runs entirely on your machine. Your CSV is read locally, the model runs locally, and results are returned locally. The only API call is a license key check (no data is transmitted).

**Can I cancel anytime?**
Yes. Monthly billing, cancel anytime through Stripe. No annual contracts, no cancellation fees.

---

## Final CTA Section

### Headline

Stop Guessing Where Your Ad Budget Should Go

### Body

Every month you run without a Marketing Mix Model, you're leaving money on the table. The average MixLift analysis finds 15-25% of ad spend going to saturated or low-incrementality channels.

Book a free 15-minute live analysis. We'll run MixLift on your actual data, live on Zoom. No pitch deck, no demo environment -- just your numbers and what they mean.

### Primary CTA

Book Your Free 15-Minute Analysis

### Secondary CTA

Install Free: pip install mixlift

---

## Footer

MixLift | Bayesian Marketing Mix Modeling for DTC Brands
hello@mixlift.io | mixlift.io
Built with PyMC-Marketing | Delivered via MCP
