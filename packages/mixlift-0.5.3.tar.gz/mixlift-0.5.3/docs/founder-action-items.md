# Founder Action Items

**Generated: March 7, 2026 | Source: Leadership Sync + Agent Execution**

All agent work is complete (298 tests green). These are the items only YOU can do.

---

## This Weekend (March 8-9) — Non-negotiable

- [ ] **Record 90-second Loom demo** (A1) — CSV drop into Claude, model runs, dollar headline appears, scenario mode. Post to LinkedIn + landing page.
- [ ] **Build LinkedIn prospect list: 50 DTC brands** (A2) — Use `docs/sales/qualification-scorecard.md` for scoring. Capture: name, title, company, revenue estimate, LinkedIn URL. Filter by: DTC eComm $5M-$50M, $30K+/mo spend, 3+ channels, Director/VP.
- [ ] **Set up UptimeRobot** (B1) — Ping `api.mixlift.io/health` every 5 min. Alert to phone on downtime.
- [ ] **Review agent output** — Skim `docs/sales/`, `docs/cs/`, `docs/content/`. These are your playbooks starting Monday.

---

## Monday March 10 — Outreach Starts

- [ ] **Send first 25 LinkedIn DMs** (A3) — Use templates from `docs/outreach-templates.md` (includes DTC beauty, food/bev, apparel variants). CTA: 15-min live data session.
- [ ] **Use the demo script** — `docs/sales/demo-script.md` has minute-by-minute structure + exact Claude prompts to type during demos.
- [ ] **Start the pipeline tracker** — `docs/sales/pipeline-tracker.md` is ready to fill in after each outreach batch.

---

## Week 1 — by March 14

- [ ] **Send next 25 DMs** (A5) — Adjust messaging based on response rates from first batch.
- [ ] **Complete 2+ live demos** (A6) — Use sample dataset (`data/sample_8channel.csv`) if prospect doesn't have data ready. Hand them `docs/first-run-guide.md`.
- [ ] **Verify Render disk persistence** (B4) — Redeploy on Render, confirm SQLite DB survives. If not, plan S3 backup or Render Postgres migration. Document in `docs/render-persistence.md`.

---

## Week 2 — by March 21

- [ ] **Post LinkedIn carousel** (A8) — Content ready at `docs/content/linkedin-carousel-budget-leak.md`. Copy-paste and post.
- [ ] **Post Reddit teardown** (A9) — Content at `docs/content/reddit-teardown.md`. Post to r/PPC or r/dtc. CTA in comments only.
- [ ] **Submit MCP marketplace listing** (A11) — Content at `docs/content/mcp-marketplace-listing.md`.
- [ ] **Deploy case study to landing page** (A12) — Content at `docs/case-study-day0.md`.
- [ ] **Deploy landing page v2** — Updated copy at `docs/content/landing-page-v2.md`. Deploy to Netlify.
- [ ] **Send 50 more DMs** (A7) — 10-15/day cadence. Total: 100.
- [ ] **Complete 5+ total live demos** (A10) — Track outcomes in pipeline tracker.

---

## Week 3 — by March 28

- [ ] **Send 50 more DMs** (A13) — Total: 150.
- [ ] **Complete 10+ total live demos** (A14).
- [ ] **Close first paying customer** (A15) — $299 via Stripe. License key issued.
- [ ] **Begin onboarding** (A16) — Use `docs/cs/onboarding-playbook.md`. Do MCP setup FOR them on screenshare. Day 0 is critical.

---

## Week 4 — by April 4

- [ ] **Send 50 more DMs** (A17) — Total: 200.
- [ ] **Complete 15+ total live demos** (A18).
- [ ] **3 paying customers** (A19).
- [ ] **First customer Day 7 interpretation call** (A20) — Use agenda in onboarding playbook. Demo scenario mode.

---

## One-Time Technical Tasks

- [ ] **Review + commit all code changes** — Run `git diff` to review. Key changes: LOO-CV (engine.py), fail-closed licensing (license.py), structured logging (mixlift-api/main.py), intercept decomposition. 298 tests pass.
- [ ] **Push updated package to PyPI** — After reviewing code changes.
- [ ] **Deploy License API updates to Render** — B2 (structured logging), B3 (last_validated_at), B5 (rate limit 60/min) need to go live.
- [ ] **Verify LOO-CV log_likelihood** — DS Manager flagged: `az.loo()` needs `log_likelihood` group in InferenceData. Run a real model fit and check. May need to add `idata_kwargs={"log_likelihood": True}` to the `fit()` call in `engine.py`.

---

## Ongoing (Every Week)

- [ ] **Weekly metrics dashboard** — Every Monday starting March 17. Fill in the table from OPERATING_PLAN.md Section 5 (outreach sent, demos completed, paying customers, MRR, uptime, bugs).
- [ ] **Pipeline tracker updates** — After every outreach batch and demo. `docs/sales/pipeline-tracker.md`.
- [ ] **Agent status review** — Check `docs/agent-status.md` for any blockers requiring your action.
- [ ] **Fix demo-killing bugs same-day** (B8) — If a bug surfaces during a live demo, fix it immediately. Agents can help once reported.
- [ ] **Retention health checks** — Use `docs/cs/retention-health-check.md` at Day 14 and Day 21 per customer.

---

## Trigger-Based (Act When Threshold Hit)

| Signal | Threshold | Action |
|--------|-----------|--------|
| Demo show rate | <30% of booked | Change messaging. Lead with free teardown offer. |
| Demo-to-close rate | <15% after 10 demos | Diagnose: trust? Price? Urgency? Interview every non-closer. |
| First renewal churn | >50% of first 5 churn at Day 30 | STOP outreach. Customer interviews only. Fix the product. |
| api.mixlift.io downtime | >1 hour | Evaluate Railway/Fly.io migration. |
| Outreach response rate | <5% on LinkedIn | Switch to warm intros, Reddit/Twitter content, or cold email. |
| "I need to share this" objection | 3+ prospects | Build PDF report export immediately. |
| Month 2 retention | 80%+ of first 5 | Green light to scale outreach to 50/week. |
| Month 2 retention | <60% of first 5 | Pause acquisition. All effort on retention. |

---

## Reference: Key Files Created by Agents

| File | Purpose |
|------|---------|
| `data/sample_8channel.csv` | 8-channel, 52-week sample dataset (GlowHaus fictional DTC brand) |
| `docs/first-run-guide.md` | Guide for prospects running the sample dataset |
| `docs/case-study-day0.md` | Landing page case study |
| `docs/model-quality.md` | Model methodology documentation |
| `docs/sales/demo-script.md` | 30-minute demo script with exact Claude prompts |
| `docs/sales/pipeline-tracker.md` | CRM tracking template |
| `docs/sales/qualification-scorecard.md` | Weighted prospect scoring |
| `docs/sales/pricing-one-pager.md` | Pricing leave-behind for prospects |
| `docs/battle-card.md` | Expanded with 5 new objection responses |
| `docs/outreach-templates.md` | Now includes DTC beauty, food/bev, apparel variants |
| `docs/content/linkedin-carousel-budget-leak.md` | LinkedIn carousel copy |
| `docs/content/reddit-teardown.md` | Reddit post copy |
| `docs/content/mcp-marketplace-listing.md` | MCP marketplace listing copy |
| `docs/content/landing-page-v2.md` | Updated landing page copy |
| `docs/cs/onboarding-playbook.md` | Day 0-30 customer onboarding playbook |
| `docs/cs/mcp-setup-guide.md` | Customer-facing MCP setup instructions |
| `docs/cs/interpreting-results.md` | Results interpretation for marketing directors |
| `docs/cs/retention-health-check.md` | Day 14/21 retention checklist |
| `docs/cs/churn-risk-signals.md` | Early warning signs + action plans |
| `docs/execution-framework.md` | CEO's execution framework (agent coordination) |
| `OPERATING_PLAN.md` | Chief of Staff's operating plan (source of truth) |
