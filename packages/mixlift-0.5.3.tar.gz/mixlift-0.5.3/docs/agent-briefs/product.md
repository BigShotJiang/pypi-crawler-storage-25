# Product Briefing — MixLift

**For:** product-manager, product-designer

---

## Product Summary

MixLift delivers Bayesian Marketing Mix Modeling through AI assistants. Users install an MCP server in Claude Desktop, point it at a CSV, and get dollar-denominated ROAS analysis + budget optimization in under 5 minutes.

**North Star:** "The tool that turns every marketer's ad spend data into a dollar-denominated action plan they trust enough to act on — delivered in minutes, for $299/month, inside the AI assistant they already use."

Key words: *dollar-denominated*, *trust*, *act on*, *already use*.

## User Personas

### Primary: Media Buyer / Performance Marketer
- **Title:** Director/VP of Growth at DTC eCommerce brand
- **Company:** $5M–$50M revenue, $30K+/month ad spend, 3+ channels
- **Pain:** Platform attribution is wrong. Can't trust ROAS numbers. No data scientist on staff. Flying blind on budget allocation.
- **Readiness:** 90%. Scenario CI remaining.

### Secondary: VP of Marketing
- **Readiness:** 65%. Needs shareable artifacts (PDF export) to share with execs. Narrative output shipped.

### Disqualified:
- CFO/CEO (won't use AI assistant for analytics)
- Single-channel advertisers (MixLift needs channel mix)
- Companies with in-house data science team (build, don't buy)
- Agencies (deferred to Week 9+)

See `docs/icp-profiles.md` for detailed ICP profiles.

## Tier Structure

| Tier | Price | Channels | Rows | Runs/Month | Dollar Headlines |
|------|-------|----------|------|------------|-----------------|
| Free | $0 | 2 | 2,000 | 2 | No (% only) |
| Growth | $299/mo | 8 | 50,000 | Unlimited | Yes |

**Planned (after 50 paying customers):**
- Pro ($799/mo) — 20 channels, 500K rows, priority support
- Agency ($1,499/mo) — multi-client (10), white-label reports

## User Flow

```
1. pip install mixlift
2. Add MCP server config to Claude Desktop
3. (Optional) Enter license key for Growth tier
4. Drop CSV into Claude: "Analyze my marketing data"
5. MCP auto-detects format (Meta/Google/TikTok/generic)
6. Model fits in 30-60 seconds (MCMC)
7. Results: Dollar headline, ROAS table, saturation traffic lights,
   budget recommendations, convergence diagnostics
8. Follow-up: "What if I cut TikTok by 20%?" (scenario mode)
9. Next month: Re-run → memory shows deltas from last analysis
```

## Feature Inventory (Shipped)

| Feature | What the user sees |
|---------|-------------------|
| Dollar headline | "MixLift found $47K/week in optimization opportunity" (Growth only; Free shows %) |
| ROAS table | Average ROAS per channel with 90% credible intervals |
| Marginal ROAS | Diminishing returns per channel |
| Saturation traffic lights | Green/yellow/red per channel with interpolated % |
| Budget recommendations | "Increase Google Search by $2,400/week (+18%)" with reasons |
| Confidence explainers | High/moderate/low confidence per channel based on posterior width |
| Model fit summary | R-squared, MAPE from posterior predictive |
| LOO-CV score | Out-of-sample model quality (good/fair/poor) |
| Scenario mode | "Cut Meta by 20%" → projected revenue impact with 80% CI |
| Contextual memory | "Since last analysis, your Meta ROAS improved from 2.3x to 2.8x" |
| Convergence diagnostics | R-hat warnings, divergent transitions |
| Intercept decomposition | Baseline/organic revenue estimate |
| Path traversal protection | Blocks access to sensitive files |
| Demo dataset | Built-in 3-channel, 52-week sample data |

## Feature Backlog (Deferred — Waiting for Customer Signal)

| Feature | Trigger to build |
|---------|-----------------|
| PDF/HTML report export | First prospect who doesn't close because they can't share results |
| Automated monthly refresh | First customer approaching Day 30 renewal |
| Pro tier ($799) | 15+ customers + 3 case studies |
| Agency tier + multi-client | Inbound agency interest |
| Annual pricing | Week 8-10, after observing first renewal cohort |
| Cross-channel interactions | Customer questions about channel synergies |
| API connector (Meta Ads API) | CSV friction blocks >40% of signups |

## UX Decisions

1. **MCP is the product.** Web app (Streamlit + FastAPI) is parked. Zero investment until Phase 3.
2. **Data stays local.** CSV never leaves the user's machine. Model runs locally. Only license validation hits remote API.
3. **AI interprets the output.** MixLift returns structured JSON; Claude renders it as narrative. "Verified by MixLift" markers prevent hallucination.
4. **Free → Growth gate:** Free tier shows percentages only. Growth shows dollar values. The dollar headline is the conversion trigger.
5. **Concierge onboarding for first 10 customers.** Founder does MCP setup on screenshare. Not self-serve yet.

## Conversion Blockers (Ranked)

1. "I don't have my data ready" → Sample dataset + first-run guide (shipping Week 1)
2. "Can I trust these numbers?" → LOO-CV score + convergence diagnostics + confidence explainers (shipped)
3. "I need to share this with my boss" → Report export (deferred until prospects say this)
4. "What if the model is wrong?" → Saturation traffic lights + scenario mode with CIs (shipped)

## Key Docs

| Doc | Location | Purpose |
|-----|----------|---------|
| Product Roadmap | `docs/PRODUCT_ROADMAP.md` | Feature roadmap with phases |
| Strategy | `STRATEGY.md` | Market positioning, pricing, competitive landscape |
| Operating Plan | `OPERATING_PLAN.md` | Sprint plan, resolved conflicts, metrics |
| First-Run Guide | `docs/first-run-guide.md` | User-facing setup instructions |
| Model Quality | `docs/model-quality.md` | User-facing methodology explanation |
| Agent Status | `docs/agent-status.md` | Cross-functional status board |

## Operating Principle

**Shipped beats correct.** A demo with a minor model quality issue that closes a customer beats a perfect model nobody sees. Customer feedback drives the next product sprint, not speculative feature work.
