# Data Science Briefing — MixLift

**For:** data-science-manager, data-analyst

---

## What MixLift Does (Statistically)

MixLift is a Bayesian Marketing Mix Model (MMM) built on PyMC-Marketing. It takes weekly channel-level ad spend data + a revenue/conversion target and estimates:
1. **Channel ROAS** — Average return on ad spend per channel with 90% credible intervals
2. **Marginal ROAS** — Diminishing returns via finite-difference approximation
3. **Channel contributions** — Revenue attribution per channel (posterior mean)
4. **Budget optimization** — Optimal allocation given total budget constraint
5. **Saturation analysis** — Traffic light system (green/yellow/red) per channel
6. **Scenario modeling** — "What if I cut Meta by 20%?" with median + 80% CI

## Modeling Pipeline

### 1. Preprocessing (`mixlift/modeling/preprocessing.py`)
- Aggregates daily → weekly sums
- Fills date gaps with zeros
- Pivots long format to wide (date × channel_spend columns + revenue)
- Adds control columns:
  - US holidays (auto-detected via `holidays` package)
  - Cyclical month encoding (sin/cos)
  - Q4 indicator
  - Linear trend

### 2. Model Specification (`mixlift/modeling/engine.py`)
- **Framework:** PyMC-Marketing `MMM` class
- **Adstock:** `GeometricAdstock(l_max=8)` — single decay parameter alpha per channel
- **Saturation:** `LogisticSaturation` — formula: `(1 - exp(-lam * x)) / (1 + exp(-lam * x))`
- **Seasonality:** 6 Fourier terms (yearly)
- **Priors:** PyMC-Marketing defaults (weakly informative). Priors dominate at <26 weeks of data — users are warned with "Exploratory Analysis" badge.

### 3. MCMC Fitting
- **Config (MCP path):** 4 chains × 250 draws, 500 tune, `target_accept=0.90`
- **Config (default):** 4 chains × 500 draws, 1000 tune
- **Posterior predictive:** `sample_posterior_predictive()` called during fit for model fit metrics
- **Diagnostics:**
  - R-hat > 1.05 → convergence warning
  - Divergent transitions → warning with count
  - Both surfaced in output JSON

### 4. Extraction
- `extract_channel_contributions()` — From `model.compute_channel_contribution_original_scale()`
- `extract_roas_estimates()` — Average ROAS = contribution / spend, with 90% CI from posterior
- `extract_marginal_roas()` — Finite-difference: perturb spend by 1%, measure contribution change
- `extract_saturation_curves()` — Vary spend 0–2× current, hold others constant, compute response
- `extract_intercept_decomposition()` — Baseline/organic revenue from model intercept, annualized

### 5. LOO-CV (`engine.py`)
- Uses ArviZ `az.loo()` on fitted InferenceData
- Requires `log_likelihood` group (PyMC-Marketing's `MMM.fit()` should produce this)
- Returns ELPD score + interpretation (good/fair/poor fit)
- Surfaces in MCP output as model quality indicator

### 6. Budget Optimization (`mixlift/modeling/optimizer.py`)
- Tries PyMC-Marketing built-in optimizer first
- Falls back to gradient descent with adstocked spend + saturation formula
- Pre-computes `sat_params` and `adstock_params` outside loop (performance fix)
- Returns: current_allocation, optimal_allocation, total_budget, expected_lift_pct
- **Known limitation:** Uses posterior means (point estimates). Uncertainty propagation through optimizer is deferred.

### 7. Recommendations (`mixlift/modeling/recommendations.py`)
- Compares optimal vs current allocation per channel
- Filters changes <5% to suppress noise
- Ranks by absolute change amount
- Generates plain-English reasons ("High ROAS, headroom available")

## Key Data Formats

**Input (wide CSV):**
```
date,google_spend,meta_spend,tiktok_spend,revenue
2024-01-01,1500,2000,800,15000
```

**Input (platform CSV):** Auto-detected. Meta/Google/TikTok exports parsed into canonical long format: `date, channel, spend, impressions, clicks, conversions`

**Model output (`ModelResults` dataclass):**
```python
{
    "roas_estimates": {"Google Search": 2.5, ...},
    "roas_ci": {"Google Search": (2.2, 2.8), ...},
    "marginal_roas_estimates": {...},
    "channel_contributions": {"Google Search": 45000.0, ...},
    "convergence_warnings": [...],
    "optimal_allocation": {"Google Search": 3500.0, ...},
    "expected_lift_pct": 12.3,
    "saturation_curves": {...},
    "loo_cv": {"elpd": -245.3, "p_loo": 4.2, "interpretation": "good"},
    "intercept_decomposition": {"weekly_baseline": 5200, "annualized": 270400}
}
```

## Data Validation Rules

| Rule | Threshold | Location |
|------|-----------|----------|
| Minimum channels | 2 | `ingest/service.py`, `server.py` |
| Minimum date range | 90 days (hard block) | `server.py` |
| Short data warning | <26 weeks → "Exploratory Analysis" badge | `server.py` |
| Free tier limits | 2 channels, 2,000 rows | `license.py`, `config.py` |
| Growth tier limits | 8 channels, 50,000 rows | `license.py`, `config.py` |
| No NaN/negative spend | Enforced | `ingest/service.py` |

## Metrics & Definitions

| Metric | Definition | Where computed |
|--------|-----------|---------------|
| Average ROAS | Total contribution / Total spend per channel | `engine.py:extract_roas_estimates()` |
| Marginal ROAS | ∂contribution/∂spend via 1% finite difference | `engine.py:extract_marginal_roas()` |
| Saturation % | Current spend position on saturation curve (0-100%) | `server.py` (traffic lights) |
| Expected lift | (optimal_response - current_response) / current_response | `optimizer.py` |
| R-hat | Gelman-Rubin convergence diagnostic | ArviZ `az.rhat()` |
| ELPD | Expected log pointwise predictive density (LOO-CV) | ArviZ `az.loo()` |

## Known Limitations & Open Questions

1. **Priors dominate on short data** — <26 weeks means posteriors barely move from priors. Badge warns users but doesn't block.
2. **Point estimates in optimizer** — Budget allocation uses posterior means, not full posterior. CI propagation deferred.
3. **No cross-channel interactions** — Model assumes independent channel effects. Real synergies (e.g., search + display) not captured.
4. **No time-varying coefficients** — ROAS assumed constant over time window. Seasonal ROAS shifts not modeled.
5. **Geometric adstock only** — No Weibull or delayed adstock options yet.
6. **US holidays only** — International users get no holiday controls.

## Key Files for DS Work

| File | Lines | What to know |
|------|-------|-------------|
| `mixlift/modeling/engine.py` | ~720 | Core model. All extract_* functions. Convergence checks. LOO-CV. |
| `mixlift/modeling/optimizer.py` | ~340 | Budget optimization. Saturation/adstock numpy implementations. |
| `mixlift/modeling/defaults.py` | ~50 | MCMC config, adstock config, seasonality config |
| `mixlift/modeling/preprocessing.py` | ~200 | Data pipeline. Holiday detection. Control columns. |
| `tests/test_modeling/test_engine_unit.py` | ~200 | Saturation formula verification, convergence diagnostic tests |
| `tests/test_modeling/test_engine_slow.py` | ~100 | Full MCMC integration tests |
| `docs/model-quality.md` | — | User-facing model quality documentation |

## DS Roadmap Status

See `docs/agent-status.md` → Data Science Manager section for current work items and blockers.

**Shipped:** LOO-CV, intercept decomposition, posterior predictive, 4-chain MCMC, convergence diagnostics, holiday controls, model quality docs.

**Deferred:** Uncertainty propagation in optimizer, cross-channel interactions, time-varying coefficients. All wait for customer feedback.
