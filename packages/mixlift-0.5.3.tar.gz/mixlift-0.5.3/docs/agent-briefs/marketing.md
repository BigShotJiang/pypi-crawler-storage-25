# Marketing Briefing — MixLift

**For:** marketing-manager

---

## Positioning

**One-liner:** "Find the wasted $47K in your ad budget. In 5 minutes. For $299/month."

**What MixLift is:** The first AI-native Marketing Mix Modeling platform. Enterprise-grade Bayesian MMM delivered through a conversational AI interface, at a fraction of competitor pricing.

**What it replaces:** $1,500+/month MMM tools (Prescient AI, Paramark), expensive consultants, or flying blind with platform attribution.

**Key differentiators:**
1. **Price:** Only true Bayesian MMM under $1,500/month ($299 vs. $1,500–$5,000)
2. **Speed:** Results in minutes, not weeks
3. **Zero onboarding:** Drop CSV into Claude. No dashboard to learn. No data scientist needed.
4. **AI-native UX:** Conversational interface, not another dashboard
5. **Data stays local:** CSV never leaves the user's machine

## ICP (Ideal Customer Profile)

**Primary buyer:** Director/VP of Growth or Marketing
- DTC eCommerce brand, $5M–$50M revenue
- $30K+/month ad spend across 3+ channels
- No data scientist on staff
- Frustrated with platform attribution or "flying blind"
- 6+ months of historical spend data

**Industries:** DTC beauty, DTC food & beverage, DTC apparel/fashion

See `docs/icp-profiles.md` for detailed profiles per vertical.

## Competitive Landscape

| Competitor | Price | Threat | Our angle |
|-----------|-------|--------|-----------|
| Prescient AI | $1,500+/mo | HIGH | 5x cheaper, same methodology |
| Paramark | $1,500+/mo | HIGH | Same Bayesian approach, fraction of cost |
| Triple Whale | ~$199/mo | HIGH | Has DTC distribution. If they ship real Bayesian MMM, we can't compete on distribution |
| Pecan AI | Enterprise | MEDIUM-HIGH | $116M raised, adding marketing measurement |
| Robyn/Meridian (open source) | Free | MEDIUM | We're easier — no data science needed |
| Platform attribution | Free | LOW | Proven unreliable post-iOS 14.5 |

**Key narrative:** "Everything below $1,500/month is shallow regression or basic attribution. MixLift is the only true Bayesian MMM under $1,500."

## Messaging Framework

### Pain points to hit:
1. "Your Meta ROAS number is wrong" (iOS 14.5 broke attribution)
2. "You're probably wasting 20-30% of your ad budget"
3. "You don't need a data scientist to run MMM"
4. "Platform attribution double-counts conversions"

### Trust builders:
1. LOO-CV model quality score
2. Convergence diagnostics (R-hat)
3. 90% credible intervals on every number
4. "Powered by PyMC-Marketing" (published methodology)
5. "Data never leaves your machine"

### Conversion triggers:
1. Dollar headline: "MixLift found $47K/week in optimization opportunity"
2. Specific channel insight: "Meta is 78% saturated — every additional dollar returns $0.40"
3. Actionable recommendation: "Move $2,400/week from TikTok to Google Search"

## Content Assets (Existing)

| Asset | Location | Status |
|-------|----------|--------|
| Outreach templates (5 ICP-specific) | `docs/outreach-templates.md` | SHIPPED |
| LinkedIn carousel: "5 Signs Your Ad Budget Has a Leak" | `docs/content/linkedin-carousel-budget-leak.md` | NEEDS REVIEW |
| Reddit teardown post | `docs/content/reddit-teardown.md` | NEEDS REVIEW |
| MCP marketplace listing | `docs/content/mcp-marketplace-listing.md` | NEEDS REVIEW |
| Landing page v2 copy | `docs/content/landing-page-v2.md` | NEEDS REVIEW |
| Battle card | `docs/battle-card.md` | SHIPPED |
| ICP profiles | `docs/icp-profiles.md` | SHIPPED |
| GTM strategy | `docs/GTM_MARKETING_STRATEGY.md` | SHIPPED |
| Day 0 case study | `docs/case-study-day0.md` | SHIPPED |

## Channel Strategy

### Phase 1 (Now — first 30 days):
1. **LinkedIn DMs** — Founder-led, personalized outreach to qualified DTC brands. Target: 300 messages → 20 demos → 5 customers.
2. **LinkedIn content** — Educational posts (carousel, insights). Soft CTA to demo.
3. **Reddit** (r/PPC, r/dtc) — Teardown posts with anonymized MixLift results. Value-first, link in comments.
4. **MCP marketplace** — One-time listing submission.

### Phase 2 (After first 5 customers):
5. Case studies with real customer data (anonymized)
6. SEO: "marketing mix modeling" keywords
7. Community building in AI/marketing intersection

### Not now:
- Paid ads (ironic but we're too early)
- Agency channel (deferred to Week 9+)
- Email marketing (no list yet)

## Brand Voice

- **Direct.** Lead with numbers, not adjectives.
- **Confident but not arrogant.** "The only true Bayesian MMM under $1,500" — factual claim.
- **Anti-dashboard.** We're the anti-SaaS SaaS. No login, no UI, no onboarding flow.
- **Practitioner language.** Speak like a performance marketer, not a data scientist. "ROAS" not "posterior mean."

## Key Metrics

| Metric | Current | Target |
|--------|---------|--------|
| Outreach messages sent | 0 | 300 by Day 45 |
| Demo show rate | Measuring | >30% |
| LinkedIn content engagement | Measuring | Track |
| MCP marketplace installs | Measuring | Track |
| Free → Growth conversion | Measuring | 3-5% |

## Docs to Reference

- `STRATEGY.md` — Full competitive landscape, moat analysis
- `OPERATING_PLAN.md` — Sprint plan, outreach cadence
- `docs/GTM_MARKETING_STRATEGY.md` — Detailed GTM strategy
- `docs/SALES_STRATEGY.md` — Sales strategy (coordinate with sales-lead)
- `docs/model-quality.md` — Technical credibility claims to use in content
- `docs/agent-status.md` → Marketing Manager section for your status board
