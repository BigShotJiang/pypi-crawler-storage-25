# Engineering Briefing — MixLift

**For:** software-engineer, engineering-manager

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Modeling | PyMC 5.10+, PyMC-Marketing 0.9+, ArviZ 0.17+ |
| MCP Server | `mcp` 1.0.0+ (stdio transport) |
| Backend (parked) | FastAPI, SQLAlchemy 2.0+ async, asyncpg, PostgreSQL |
| Frontend (parked) | Streamlit 1.30+, Plotly 5.18+ |
| License API | FastAPI, aiosqlite, SQLite (separate repo: mixlift-api) |
| Auth | python-jose (JWT), passlib (bcrypt) |
| Payments | stripe 7.0+ |
| Email | Resend |
| Dev tools | pytest, ruff, mypy, factory-boy |
| Package manager | uv (lock: uv.lock), hatchling (build) |
| Python | 3.11, 3.12 (CI matrix), also works on 3.13 |

## Codebase Map

### MCP Server (`src/mixlift_mcp/`) — THE PRODUCT
- `server.py` (~1300 lines) — Tool definitions, CSV pipeline, output formatting, scenario mode, path traversal validation
- `license.py` — License validation client. Fail-closed with 24h cached grace period. Calls `api.mixlift.io`
- `metering.py` — Local free-tier usage counter. 2 runs/month. Stored in `~/.mixlift/usage.json`
- `memory.py` — Cross-run analysis memory. Fingerprints datasets. Stores summaries in `~/.mixlift/memory/`. Computes deltas between runs.
- `data/demo.csv` — Bundled demo (3 channels, 52 weeks)

### Modeling Engine (`mixlift/modeling/`)
- `engine.py` (~720 lines) — Core MMM: `build_model()`, `fit_model()`, `extract_*()`, `check_convergence()`. Uses PyMC-Marketing's `MMM` class with GeometricAdstock + LogisticSaturation.
- `optimizer.py` (~340 lines) — `optimize_budget()`: tries PyMC-Marketing built-in, falls back to gradient descent. Pre-computes adstock/saturation params. `format_channel_name()` lives here.
- `preprocessing.py` — `aggregate_to_weekly()`, `fill_date_gaps()`, `pivot_channels()`, `_build_holiday_column()` (US holidays via `holidays` package), cyclical month encoding, Q4 indicator.
- `defaults.py` — `DEFAULT_MCMC_CONFIG` (4 chains, 1000 tune, 500 draws), `MCP_CONFIG` (4 chains, 500 tune, 250 draws for speed), adstock/seasonality defaults.
- `recommendations.py` — Generates ranked `Recommendation` objects. Filters <5% changes. Plain-English reasons.
- `service.py` — End-to-end pipeline orchestrator (web app path, not MCP).

### Data Ingestion (`mixlift/ingest/`)
- `service.py` — `detect_platform()`, `parse_csv()`, `validate_data()`. Auto-detects Meta/Google/TikTok/generic by column signatures.
- `parsers/` — Platform-specific parsers (meta.py, google.py, tiktok.py, generic.py)
- `templates.py` — Column name signatures for platform detection
- `loader.py` — CSV loading helpers, shared between MCP server and web app

### Web App (PARKED — MCP server is the product)
- `mixlift/main.py` — FastAPI app factory
- `mixlift/auth/` — JWT auth
- `mixlift/projects/` — CRUD. Models: User, Project, Dataset, ModelRun, Subscription
- `mixlift/billing/` — Stripe integration
- `frontend/` — Streamlit pages

## Testing

```
tests/
├── conftest.py              # Shared fixtures, mock sessions, auth headers, metering bypass
├── test_mcp/
│   ├── test_server.py       # 37 tests: format detection, tier limits, path traversal (21 security tests)
│   ├── test_license.py      # 8 tests: license validation with mocks
│   ├── test_memory.py       # Contextual memory
│   ├── test_prepare.py      # mixlift_prepare tool
│   └── test_integration.py  # End-to-end MCP flows
├── test_modeling/
│   ├── test_engine_unit.py  # 12 tests: saturation formula, adstock, convergence, LOO-CV
│   ├── test_optimizer.py    # 5 tests: response estimation, gradient optimizer
│   ├── test_preprocessing.py
│   ├── test_recommendations.py
│   └── test_engine_slow.py  # Actual MCMC fitting (@pytest.mark.slow)
├── test_ingest/test_parsers.py
├── test_api/                # FastAPI endpoint tests
├── test_billing/
└── fixtures/                # Sample CSVs
```

Run: `make test` (quick), `make test-all` (includes slow), `make test-cov` (coverage)

## CI/CD

- **CI** (`.github/workflows/ci.yml`): Push/PR to main → ruff lint + pytest on Python 3.11, 3.12
- **Release** (`.github/workflows/release.yml`): Tag `v*` → build wheel → publish to PyPI via OIDC
- **Deploy**: License API on Render (api.mixlift.io), Landing page on Netlify

## Key Patterns

**Path traversal protection** (`server.py`): Extension whitelist (.csv/.tsv/.txt), sensitive path blocklist (.ssh/, .env, .git/, credentials, secrets, .aws/, .gnupg/), optional `MIXLIFT_ALLOWED_DIRS` env var.

**Fail-closed licensing** (`license.py`): API down + no fresh cache → free tier (paid features blocked). API down + cache <24h → honor cached tier (grace period). Never silently downgrades paid users on transient errors.

**Convergence diagnostics** (`engine.py`): R-hat > 1.05 → warning. Divergent transitions → warning. Both surface in MCP JSON output.

**Saturation formula**: `(1 - exp(-lam * x)) / (1 + exp(-lam * x))` — matches PyMC-Marketing's LogisticSaturation. Verified with unit tests.

**Adstock**: Geometric. `adstocked[t] = spend[t] + alpha * adstocked[t-1]`. l_max=8 weeks default.

## Tech Debt (Ordered by Priority)

| # | Issue | Effort | Status |
|---|-------|--------|--------|
| 1 | Free tier dollar leak (budget_optimization shows $) | S | OPEN |
| 2 | `ingest/service.py` still 180-day minimum (should be 90) | S | OPEN |
| 3 | Raw saturation curves in MCP output (1600 wasted data points) | S | OPEN |
| 4 | Circular import risk (engine <-> optimizer) | S | OPEN |
| 5 | No end-to-end integration test in CI | M | OPEN |
| 6 | No model caching for repeat runs | M | OPEN |
| 7 | No monitoring/alerting for license API | S-M | OPEN |
| 8 | Web app code in same package (bloats install) | M | OPEN |

## Operating Directive

**Harden, don't build.** No new modeling features for 30 days unless customer feedback demands it. Engineering priorities: monitoring, fail-closed licensing, integration tests, bug fixes from live demos. Same-day turnaround on demo-killing issues.

See `OPERATING_PLAN.md` for the full sprint plan and `docs/agent-status.md` for the Engineering Manager status board.
