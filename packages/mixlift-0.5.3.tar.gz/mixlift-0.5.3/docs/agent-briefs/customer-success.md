# Customer Success Briefing — MixLift

**For:** customer-success

---

## Product Context

MixLift is an MCP server that runs Bayesian Marketing Mix Modeling inside Claude Desktop. Customers install it via `pip install mixlift`, configure it in Claude Desktop, and analyze their ad spend data by dropping a CSV into the conversation.

**Key output:** Dollar-denominated ROAS per channel, budget optimization recommendations, saturation analysis, scenario modeling, convergence diagnostics.

## Customer Journey

```
Awareness → Demo (founder-led) → Close ($299/mo) → MCP Setup → First Analysis
  → Day 7 Interpretation Call → Day 14 Re-run → Day 21 Pre-renewal → Day 30 Renewal
```

## Onboarding Playbook (First 5 Customers)

| Day | Action | Goal |
|-----|--------|------|
| 0 | Live demo on THEIR data. Close on call. Do MCP setup FOR them (screenshare). | Aha moment: dollar headline on their own data |
| 1 | Follow-up email: findings summary, scenario mode docs, "try running it yourself" | Confirm independent usage |
| 3 | Check-in: "Were you able to run it on your own? Any questions?" | Catch friction early |
| 7 | Scheduled call: Interpretation deep-dive + scenario mode walkthrough | Deepen engagement beyond first analysis |
| 14 | Async check-in: "Have your numbers changed? Want to re-run with this week's data?" | Trigger second analysis. Memory deltas kick in. |
| 21 | Pre-renewal call: Run fresh analysis together. Show deltas from Day 0. | Reframe from "diagnosis tool" to "tracking tool" |
| 30 | Renewal auto-processes (Stripe). Follow up: "Glad to have you for another month." | Retain. Collect feedback. |

See `docs/cs/onboarding-playbook.md` for the full playbook.

## Common Setup Issues

1. **"MCP server not found"** → Verify `mixlift-mcp` is in PATH. May need `pip install --user mixlift` or activate correct venv.
2. **"License key not working"** → Check api.mixlift.io/health. Verify key copied correctly. Check `~/.mixlift/cache/license_cache.json` for cached state.
3. **"Model takes too long"** → Normal: 30-60 seconds for MCMC. Large datasets (50K+ rows) may take longer. Check channel/row count.
4. **"CSV not recognized"** → Needs wide format (date + channel_spend columns + revenue) or platform export (Meta/Google/TikTok). See `docs/first-run-guide.md`.
5. **"Only 2 channels allowed"** → Free tier limit. Need Growth license ($299/mo) for up to 8 channels.
6. **"Results seem wrong"** → Check convergence diagnostics in output. R-hat warnings mean results may be unreliable. Suggest more data or fewer channels.

See `docs/cs/mcp-setup-guide.md` for the full setup guide.

## Interpreting Results for Customers

### ROAS Table
- Average ROAS: total return per dollar spent on each channel
- 90% credible interval: where the true ROAS likely falls
- Marginal ROAS: what one MORE dollar would return (diminishing returns)

### Saturation Traffic Lights
- Green: Channel has headroom. Increasing spend will likely increase returns.
- Yellow: Moderate saturation. Approach increases cautiously.
- Red: Highly saturated. Additional spend has diminishing returns.

### Budget Recommendations
- Ranked by impact. Largest recommended changes first.
- Changes <5% are suppressed (noise).
- Dollar amounts only visible on Growth tier (free shows percentages).

### Convergence Diagnostics
- "R-hat > 1.05" → Model may not have converged. Results less reliable. Suggest more data.
- "Divergent transitions" → Posterior sampling had issues. Results may be biased.
- No warnings = good fit.

See `docs/cs/interpreting-results.md` for the full guide.

## Churn Risk Signals

| Signal | Severity | Action |
|--------|----------|--------|
| No second analysis by Day 14 | HIGH | Proactive check-in. Offer to run it together. |
| "Results don't match platform data" | MEDIUM | Expected — explain attribution vs. MMM difference. This is the value prop. |
| "I need to share this with my boss" | MEDIUM | Send formatted summary. If this blocks close, escalate to PM for report export. |
| Setup issues not resolved in 48h | HIGH | Escalate to engineering. Same-day fix. |
| Low confidence / many convergence warnings | MEDIUM | Review data quality. May need more history or fewer channels. |
| No response to Day 7 or Day 21 outreach | HIGH | Direct message or call. They're churning silently. |

See `docs/cs/churn-risk-signals.md` for the full framework.

## Retention Mechanics (Built Into Product)

1. **Contextual memory** — Each analysis stores a summary. Next run shows deltas: "Your Meta ROAS improved from 2.3x to 2.8x since last analysis." This makes each run more valuable.
2. **Scenario mode** — "What if I cut TikTok by 20%?" keeps users engaged between full analyses.
3. **Concierge model** — Founder relationship is the retention mechanic for first 10 customers.

## Health Score Framework

| Factor | Weight | Green | Yellow | Red |
|--------|--------|-------|--------|-----|
| Analyses run (last 30d) | 30% | 2+ | 1 | 0 |
| Days since last analysis | 25% | <14 | 14-28 | >28 |
| Setup completed | 20% | Yes | Partial | No |
| Engagement with outreach | 15% | Responds | Slow response | No response |
| Support tickets | 10% | Resolved | Open | Escalated |

See `docs/cs/retention-health-check.md` for the full template.

## Key Docs

| Doc | Location | Purpose |
|-----|----------|---------|
| Onboarding playbook | `docs/cs/onboarding-playbook.md` | Full Day 0-30 playbook |
| MCP setup guide | `docs/cs/mcp-setup-guide.md` | Customer-facing setup instructions |
| Interpreting results | `docs/cs/interpreting-results.md` | Customer-facing results guide |
| Retention health check | `docs/cs/retention-health-check.md` | Health score template |
| Churn risk signals | `docs/cs/churn-risk-signals.md` | Warning signals and actions |
| First-run guide | `docs/first-run-guide.md` | User-facing getting started |
| Agent status | `docs/agent-status.md` → CS Manager section | Your status board |

## Operating Principle

**Concierge is the product.** For the first 10 customers, the founder IS the product. Do MCP setup for them. Sit on the call while the model runs. Interpret results together. Fix bugs in real time. Every interaction generates signal worth more than a week of speculative feature work.
