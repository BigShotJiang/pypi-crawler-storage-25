# Strategy Briefing — MixLift

**For:** strategist, chief-of-staff

---

## North Star

"MixLift is the tool that turns every marketer's ad spend data into a dollar-denominated action plan they trust enough to act on — delivered in minutes, for $299/month, inside the AI assistant they already use."

## Where We Are (March 7, 2026)

- **Stage:** Pre-revenue. Product shipped. Selling.
- **Version:** 0.3.0 on PyPI. License API live at api.mixlift.io. Stripe connected.
- **Customers:** 0 paying. Outreach started March 10.
- **Codebase maturity:** Week 7-8 features on a Week 4 calendar. The constraint is customers, not code.

## The Market

- **TAM:** Marketing analytics ~$5B today → $13-15B by 2030
- **The gap we exploit:** True Bayesian MMM starts at $1,500/month. Everything below is shallow regression. MixLift is the only true Bayesian MMM under $1,500.
- **Primary buyer:** Dir/VP of Growth at DTC eComm, $5M-$50M rev, $30K+/mo ad spend, no data scientist on staff.

## Competitive Landscape

| Competitor | Threat | Why | Our defense |
|-----------|--------|-----|-------------|
| PyMC-Marketing (open source) | HIGH | We build on this. If they ship a product, our tech layer vanishes. | Ship faster. Build moats they won't: data normalization, memory, dollar output. |
| Triple Whale | HIGH | Massive DTC distribution ($50M+ raised). If they ship real Bayesian MMM at $199, game over on distribution. | Speed. AI-native UX they can't replicate quickly. |
| Paramark | HIGH | Closest methodology. Self-serve $500 tier would narrow the gap. | 5x cheaper. Zero-onboarding UX. |
| Prescient AI | HIGH | Same methodology, 5-15x our price. Could drop prices. | They're enterprise-locked. We're self-serve. |
| Pecan AI | MEDIUM-HIGH | $116M raised. Adding marketing measurement. | Move fast while they're still platform-building. |

## Moat Stack (Build Priority Order)

1. **Output quality + trust** — Dollar headlines, confidence explainers, traffic lights. SHIPPED. Not durable (replicable in 1-2 weeks) but first-mover advantage.
2. **Data normalization** — Every CSV format, API schema, edge case. PARTIAL. Ongoing.
3. **Contextual memory** — "Last quarter you cut TikTift, revenue went up 8%." SHIPPED. Creates switching costs. First real moat.
4. **Default verb** — "Run MixLift on it." Requires scale we don't have yet.
5. **Vertical benchmarks** — Anonymized aggregated data from user base. Requires 100+ customers.

## Strategic Decisions (Resolved — Do Not Re-debate)

| # | Decision | Resolution |
|---|---------|------------|
| 1 | Distribution channel | MCP primary, Python API backup. AI-native UX is the differentiator. |
| 2 | Pricing | Free + Growth ($299) only. No $99 tier. No annual until Week 8-10. |
| 3 | Free tier | 2 channels, 2,000 rows, 2 runs/month, no dollar headlines. |
| 4 | Agency strategy | Deferred to Week 9+. DTC brands only in Phase 1. |
| 5 | Web app | Parked. MCP server is the product. Zero investment. |
| 6 | Data locality | Local by default. Opt-in benchmarking in Phase 2. |
| 7 | When to raise | After proving churn <5% with 30+ paying customers. |
| 8 | Feature freeze | Zero new modeling features for 30 days. Customer feedback drives next sprint. |

## Operating Principles (30-Day Governing Rules)

1. **Customers before code** — No engineering work justified by "best practice." Must answer: "Which customer interaction does this enable?"
2. **Concierge is the product** — Founder IS the product for first 10 customers. Do setup for them. Fix bugs live.
3. **Measure retention, not acquisition** — Month 2 retention of first 5 is THE metric. Available around Day 75.
4. **One bet at a time** — MCP + DTC + $299 + founder-led. If it doesn't work, change ONE variable.
5. **Shipped beats correct** — A demo that closes beats a perfect model nobody sees.

## Success Metrics

### The Only Metric That Matters
**5 paying customers by Day 45. 10 by Day 60.**

### Kill Criteria (Day 90)
- <10 paying + >15% churn → kill or pivot
- Zero inbound → distribution broken
- First 5 churn >50% at Day 30 → stop all outreach, fix product

### Churn Thresholds
- >5%/month → lifestyle business ($500K ARR cap)
- 3-5%/month → viable SaaS ($1-3M ARR)
- <3%/month → venture-scale, compounding works

## Probability Assessment (Honest)

- **$1M ARR probability:** 5-10%
- **Most likely outcome:** Lifestyle business at $100-180K ARR (fine outcome)
- **What determines outcome:** (1) ~~Can we deploy?~~ YES. (2) Can we convert? (next 4 weeks). (3) Can we retain? (next 3 months).

## Decisions Waiting for Data

| Decision | Trigger |
|----------|---------|
| Pro tier ($799) | 15+ customers + 3 case studies |
| Report export | 3+ prospects say "I need to share this with my boss" |
| Annual pricing | Week 8-10, after observing renewal cohort |
| Agency tier | Inbound agency interest |
| Kill or pivot | Day 90: <10 paying + >15% churn |

## Risk Matrix (Top 5)

| Risk | Severity | Mitigation |
|------|----------|-----------|
| PyMC-Marketing ships a product | HIGH | Ship faster. Build moats they won't build. |
| Triple Whale deepens MMM | HIGH | Speed. AI-native UX. |
| High churn (>5%) | HIGH | Memory, comparison, scenario features. Monthly workflow, not one-shot. |
| Anthropic platform dependency | HIGH | Headless Python API already shipped. REST API in Phase 2. |
| LLM hallucination erodes trust | HIGH | Deterministic JSON output. "Verified by MixLift" markers. |

## Key Docs

| Doc | Purpose |
|-----|---------|
| `STRATEGY.md` | Full strategy document (Sections I-X) |
| `OPERATING_PLAN.md` | 30-day sprint plan, resolved conflicts, metrics dashboard |
| `PROJECT_STATUS.md` | Technical status, QA audit findings |
| `docs/SCALING_STRATEGY.md` | Growth model and scaling plan |
| `docs/agent-status.md` | Cross-functional status board |
| `docs/execution-framework.md` | Execution tracking |

## What Winning Looks Like

**6 months:** 60 paying, $25K MRR, <4% churn, 3 agencies, Meta API connector, runs on Claude + ChatGPT.

**12 months:** 150 paying, $75K MRR, <3% churn, seed round at $3-5M on $20-30M valuation, team of 4.

**Today:** Get 5 paying customers. Measure churn. Everything else follows from that data.
