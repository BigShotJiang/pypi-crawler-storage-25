# Sales Briefing — MixLift

**For:** sales-lead

---

## What We Sell

**MixLift Growth** — $299/month. Bayesian Marketing Mix Modeling delivered through Claude Desktop (AI assistant). The marketer drops a CSV of their ad spend, gets back a dollar-denominated action plan in under 5 minutes.

**Headline value prop:** "Find the wasted $47K in your ad budget. In 5 minutes. For $299/month."

## Pricing

| Tier | Price | What they get |
|------|-------|--------------|
| Free | $0 | 2 channels, 2,000 rows, 2 runs/month, percentages only (no dollar values) |
| Growth | $299/mo | 8 channels, 50,000 rows, unlimited runs, dollar headlines, full optimization |

**No annual pricing yet.** Decision deferred to Week 8-10 after observing first renewal cohort. Annual ($2,690/yr, 25% discount) becomes a closing tool only after we understand retention.

**Pro tier ($799/mo)** planned after 15+ customers + 3 case studies.

## Qualification Criteria

**QUALIFY:**
- DTC eCommerce, $5M–$50M revenue
- $30K+/month ad spend across 3+ channels
- Director/VP of Growth or Marketing (budget authority)
- Frustrated with platform attribution or "flying blind"
- 6+ months of historical spend data available

**DISQUALIFY:**
- Pre-revenue or pre-PMF startups
- Single-channel advertisers
- Has in-house data science team
- Committee buyers (3+ stakeholder approval)
- Agencies (deferred to Week 9+)

See `docs/sales/qualification-scorecard.md` for the full scorecard.

## Demo Flow (30 minutes)

1. **Pain discovery** (5 min) — "How do you currently decide where to put your next dollar of ad spend?"
2. **Show the gap** (3 min) — "Platform attribution double-counts. iOS 14.5 broke it. You're probably wasting 20-30%."
3. **Live demo on THEIR data** (15 min) — Drop their CSV into Claude. Model runs. Dollar headline appears. Walk through ROAS, saturation, recommendations.
4. **Scenario mode** (5 min) — "What if you cut TikTok by 20%?" Live answer with confidence intervals.
5. **Close** (2 min) — "Ready to start? $299/month, cancel anytime."

If they don't have data ready: Use built-in sample dataset. But always push to run on their data — the dollar headline on THEIR data is the aha moment.

See `docs/sales/demo-script.md` for the full demo script.

## Objection Handling

| Objection | Response |
|-----------|----------|
| "Too expensive" | "Prescient AI charges $1,500+. Consultants charge $5K+. MixLift is $299 for the same Bayesian methodology." |
| "I don't trust AI" | "MixLift returns verified numbers, not AI opinions. Every number has a confidence interval. The AI just reads them to you." |
| "I already use Triple Whale / Northbeam" | "Those are attribution tools. Attribution tells you who touched the ad. MMM tells you if the ad actually worked. They complement each other." |
| "Can I try it first?" | "Yes — free tier: 2 channels, 2 runs/month. Or let me run it on your data right now, takes 5 minutes." |
| "I need to share this with my boss" | "I'll send you a summary you can forward. [Note: if this comes up 3+ times, we build PDF export.]" |
| "My data scientist can do this" | "They absolutely can — with PyMC-Marketing directly. MixLift saves them 2 weeks of pipeline work and gives you results in 5 minutes instead of 2 months." |
| "What about privacy?" | "Your data never leaves your machine. The model runs locally. Only a license key check goes to our server." |
| "How accurate is it?" | "We show LOO-CV (out-of-sample model quality), R-hat convergence diagnostics, and 90% credible intervals on every number. You can verify the math." |

See `docs/battle-card.md` for the full competitive battle card.

## Sales Process

**Model:** Founder-led concierge sales. No self-serve conversion funnel yet.

```
LinkedIn DM → 15-min discovery call → 30-min live demo → Close on call → MCP setup on screenshare
```

**Target pipeline:**
- 300 outreach messages → 20 demos → 5 customers (Day 45)
- 10-15 DMs/day cadence
- 5 demos/week target

## Closing Mechanics

1. **Payment:** Stripe Payment Link (embedded in demo follow-up). Monthly subscription, cancel anytime.
2. **Onboarding:** Founder does MCP setup FOR the customer on screenshare (Day 0).
3. **Follow-up cadence:** Day 1 email, Day 3 check-in, Day 7 interpretation call, Day 14 re-run prompt, Day 21 pre-renewal call.

See `OPERATING_PLAN.md` Appendix A for the full onboarding playbook.

## Key Numbers for Conversations

| Stat | Value | Source |
|------|-------|--------|
| Marketing analytics market | ~$5B today → $13-15B by 2030 | Industry reports |
| Cheapest competitor (real MMM) | $1,500/mo (Prescient, Paramark) | Public pricing |
| MixLift price | $299/mo | — |
| Time to results | <5 minutes | Live demos |
| Infrastructure cost | <$15/month (99%+ gross margin) | Render hosting |
| Data requirement | 90+ days, 2+ channels | Product spec |

## Key Docs

| Doc | Location | Purpose |
|-----|----------|---------|
| Demo script | `docs/sales/demo-script.md` | Full 30-minute demo structure |
| Battle card | `docs/battle-card.md` | Competitive positioning |
| Pricing one-pager | `docs/sales/pricing-one-pager.md` | Leave-behind for prospects |
| Qualification scorecard | `docs/sales/qualification-scorecard.md` | Lead scoring |
| Pipeline tracker | `docs/sales/pipeline-tracker.md` | Deal tracking |
| Sales strategy | `docs/SALES_STRATEGY.md` | Full sales strategy |
| Outreach templates | `docs/outreach-templates.md` | LinkedIn DM templates |
| ICP profiles | `docs/icp-profiles.md` | Detailed buyer profiles |
| Agent status | `docs/agent-status.md` → Sales Lead section | Your status board |

## Operating Principle

**First 10 customers are case studies, not revenue.** $299 is intentionally low. The goal is to learn what makes customers stay, not maximize ACV. Raise to Pro ($799) after 15-20 customers + 3 published case studies.
