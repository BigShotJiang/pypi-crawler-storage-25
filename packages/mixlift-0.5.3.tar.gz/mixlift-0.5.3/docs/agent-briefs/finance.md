# Finance Briefing — MixLift

**For:** finance

---

## Business Model

**Product:** Bayesian Marketing Mix Modeling SaaS, delivered via MCP server (Claude Desktop integration).

**Revenue model:** Monthly SaaS subscription. Stripe Payment Link → Stripe Checkout → Webhook → License API → License key delivered via email.

## Pricing

| Tier | Price | Channels | Rows | Status |
|------|-------|----------|------|--------|
| Free | $0 | 2 | 2,000 | Live (2 runs/month) |
| Growth | $299/mo | 8 | 50,000 | Live |
| Pro | $799/mo | 20 | 500,000 | Planned (after 15+ customers) |
| Agency | $1,499/mo | Multi-client (10) | — | Planned (after agency demand signal) |

**Annual pricing** deferred to Week 8-10. Planned at 25% discount ($2,690/yr). Not offered until retention data exists — annual masks churn signal.

## Unit Economics

| Metric | Value | Notes |
|--------|-------|-------|
| ARPU (current) | $299/mo | Single tier |
| Gross margin | 95%+ | Near-zero marginal cost (model runs locally) |
| Infrastructure cost | <$15/mo | Render (license API + landing page hosting) |
| COGS | ~$0 per customer | No compute cost — MCMC runs on customer's machine |
| CAC (current) | $0 | Founder-sold, LinkedIn DMs |
| CAC (target, 6mo) | <$150 | Content marketing + community |
| Stripe fees | 2.9% + $0.30 | ~$9/mo per customer |
| Net revenue per customer | ~$290/mo | After Stripe fees |
| Breakeven | 1 customer | Infrastructure costs < $15/mo |

## Cost Structure

| Category | Monthly | Notes |
|----------|---------|-------|
| Render (License API) | ~$7 | Free tier sufficient for now |
| Netlify (Landing page) | $0 | Free tier |
| Stripe fees | 2.9% + $0.30/txn | Per customer |
| Resend (email) | $0 | Free tier (100 emails/day) |
| Domain (mixlift.io) | ~$1.50/mo | Annual billing |
| GitHub (CI) | $0 | Free tier |
| PyPI | $0 | Free |
| **Total fixed** | **<$15/mo** | |
| **Total variable** | **~$9/customer/mo** | Stripe fees |

## Revenue Projections (from OPERATING_PLAN.md)

| Metric | Day 30 | Day 60 | Day 90 |
|--------|--------|--------|--------|
| Paying customers | 3-5 | 8-12 | 15-25 |
| MRR | $897-$1,495 | $2,392-$3,588 | $4,485-$7,475 |
| Monthly churn | N/A | Measuring | <10% |
| Gross margin | 95%+ | 95%+ | 95%+ |

## Scenario Analysis (Day 90 Decision)

| Scenario | Probability | Metrics | Implication |
|----------|------------|---------|-------------|
| Downside | 15% | <10 paying, >15% churn | Kill or pivot |
| Base | 60% | 10-15 paying, 5-10% churn | Lifestyle business ($100-180K ARR ceiling) |
| Upside | 25% | 15-25 paying, <5% churn | Invest moderately, launch Pro tier |

## Long-Term Targets (from STRATEGY.md)

| Metric | 30 Days | 90 Days | 6 Months | 12 Months |
|--------|---------|---------|----------|-----------|
| Paying customers | 5 | 25 | 60 | 150 |
| MRR | $1,500 | $7,500 | $25,000 | $75,000 |
| Monthly churn | Measuring | <8% | <5% | <3% |
| LTV/CAC | Measuring | >3x | >4x | >5x |

## The Churn Threshold

- **>5% monthly churn:** Lifestyle business, caps at ~$500K ARR
- **3-5% monthly churn:** Viable SaaS, $1-3M ARR achievable
- **<3% monthly churn:** Venture-scale, compounding math works

## Fundraising

**When to raise:** After proving churn <5% with 30+ paying customers.
**Target:** Seed round at $500K-$1M ARR run rate. $3-5M raise at $20-30M valuation.
**Probability of reaching $1M ARR:** 5-10% (honest assessment from STRATEGY.md).

## Kill Criteria (Day 90)

- <10 paying customers despite active sales → pivot distribution
- Monthly churn >15% → fundamental PMF problem
- Zero inbound interest → distribution not working

## Current Status

- **Stage:** Pre-revenue. v0.3.0 shipped. Infrastructure live.
- **Customers:** 0 paying
- **MRR:** $0
- **Burn rate:** <$15/month (founder time is unpaid)
- **Runway:** Infinite at current cost structure

## Key Docs

| Doc | Purpose |
|-----|---------|
| `STRATEGY.md` Section VI | Success metrics, churn thresholds |
| `OPERATING_PLAN.md` Section 5 | Weekly dashboard, trigger-based actions, finance scenarios |
| `docs/SCALING_STRATEGY.md` | Scaling strategy and growth model |
| `docs/sales/pricing-one-pager.md` | Pricing rationale |
| `docs/agent-status.md` | Cross-functional status board |
