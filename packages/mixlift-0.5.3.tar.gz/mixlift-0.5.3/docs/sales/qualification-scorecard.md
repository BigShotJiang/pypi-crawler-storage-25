# MixLift Prospect Qualification Scorecard

**Based on:** OPERATING_PLAN.md Appendix B
**Purpose:** Score every prospect before investing demo time. Minimum threshold: 60/100 to book a demo.

---

## Scoring Rubric

### 1. Revenue Range (20 points max)

| Revenue | Score | Rationale |
|---|---|---|
| $20M - $50M | 20 | Sweet spot. Enough spend to see clear results, not big enough for in-house DS. |
| $10M - $20M | 16 | Strong fit. Usually scaling paid media aggressively. |
| $5M - $10M | 12 | Good fit. May have tighter budgets but high pain. |
| $50M - $100M | 8 | Can afford enterprise tools. May have in-house resources. Still viable. |
| $2M - $5M | 4 | Marginal. Ad spend likely too low for robust modeling. |
| < $2M or > $100M | 0 | Too small (insufficient data) or too large (will build or buy enterprise). |

### 2. Monthly Ad Spend (25 points max)

| Monthly Ad Spend | Score | Rationale |
|---|---|---|
| $80K+ | 25 | High spend = high pain from misallocation. $299 is a rounding error. |
| $50K - $80K | 20 | Strong fit. Clear ROI case for optimization. |
| $30K - $50K | 15 | Minimum viable. Enough channel diversity for modeling. |
| $15K - $30K | 8 | Marginal. May not have enough spend variation per channel. |
| < $15K | 0 | Insufficient spend for meaningful MMM. Disqualify. |

### 3. Channel Count (15 points max)

| Channels | Score | Rationale |
|---|---|---|
| 5+ channels | 15 | Ideal. Complex mix = high attribution confusion = high pain. |
| 4 channels | 12 | Good. Enough for meaningful channel comparison. |
| 3 channels | 8 | Minimum for MMM. Model will work but fewer insights. |
| 2 channels | 3 | Marginal. Limited reallocation opportunity. |
| 1 channel | 0 | MMM requires a mix. Disqualify. |

### 4. Seniority / Budget Authority (20 points max)

| Role | Score | Rationale |
|---|---|---|
| VP/Director of Growth/Marketing (sole decision maker) | 20 | Can buy today. No committee. |
| Head of Performance/Acquisition (budget owner) | 16 | Usually has authority for tools under $500/mo. |
| CMO / Founder (at a small company) | 14 | Has authority but may be time-constrained. |
| Senior Marketing Manager (influences budget) | 8 | Can champion but likely needs approval. |
| Marketing Coordinator / Analyst | 3 | No authority. Will need multiple stakeholders. |
| Unknown | 0 | Qualify further before booking demo. |

### 5. Pain Signal (20 points max)

| Signal | Score | Rationale |
|---|---|---|
| Explicitly says attribution is broken / "flying blind" | 20 | Highest urgency. They know the problem. |
| Recently cut a channel and wants to measure impact | 16 | Active decision-making moment. High intent. |
| Tried MMM before (Robyn, freelancer) and it failed / stalled | 14 | Aware of MMM, had bad experience. Reframe opportunity. |
| Scaling spend and worried about efficiency | 12 | Growing pain. Proactive but not urgent. |
| "Just exploring options" / "Curious about MMM" | 6 | Low urgency. May not convert soon. |
| No clear pain articulated | 0 | Likely tire-kicking. Low priority. |

---

## Scoring Template

```
Prospect: _______________
Company: _______________
Date:    _______________

1. Revenue Range:       ___/20
2. Monthly Ad Spend:    ___/25
3. Channel Count:       ___/15
4. Seniority:           ___/20
5. Pain Signal:         ___/20
                       -------
TOTAL:                  ___/100
```

---

## Decision Thresholds

| Score | Action |
|---|---|
| 80-100 | Priority prospect. Book demo immediately. Personalize outreach heavily. |
| 60-79 | Qualified. Book demo. Standard outreach. |
| 40-59 | Marginal. Offer free tier + sample dataset. Revisit if they engage. |
| Below 40 | Disqualify. Do not invest demo time. |

---

## Auto-Disqualify Criteria

Regardless of score, disqualify if ANY of the following are true:

| Criterion | Reason |
|---|---|
| **Pre-revenue or pre-product-market-fit** | No historical data to model. No budget to optimize. |
| **Single-channel advertiser** | MMM requires a channel mix. No mix = no model. |
| **Has an in-house data science team** | They will build, not buy. Our value prop evaporates. |
| **Committee buyer requiring 3+ stakeholder approvals** | Sales cycle too long for $299/mo deal. Will drain founder time. |
| **Agency (for now)** | Deferred to Week 9+. Agency tier not yet built. |
| **Requires on-prem / SOC 2 / enterprise security review** | We are too early for enterprise compliance processes. |
| **Cannot produce a CSV of historical spend + revenue** | No data = no analysis. Come back when they can. |

---

## Qualification Questions to Ask

Use these during initial outreach or first call to fill in the scorecard:

1. "What's your approximate monthly ad spend across all channels?" (Ad Spend)
2. "How many paid channels are you running -- Meta, Google, TikTok, email, etc.?" (Channel Count)
3. "Who on your team makes the call on budget allocation?" (Seniority)
4. "How are you currently deciding how much to spend on each channel?" (Pain Signal)
5. "Could you pull 6-12 months of weekly spend and revenue data into a spreadsheet?" (Data readiness -- auto-disqualify check)
