# MixLift Sales Pipeline Tracker

**Owner:** Founder
**Update cadence:** After every outreach batch, response, and demo

---

## Active Pipeline

| Prospect | Company | Est. Revenue | Ad Spend/mo | Outreach Date | Channel | Response | Demo Date | Demo Outcome | Objections Raised | Close Date | MRR | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Jane Smith | GlowSkin Co | $12M | $45K | 2026-03-10 | LinkedIn DM | Replied, interested | 2026-03-13 | Ran on their data, strong engagement | "Need to check with CMO" | -- | -- | Follow up 3/16. Send pricing one-pager. |
| Mark Chen | FitFuel | $8M | $35K | 2026-03-10 | LinkedIn DM | Booked call | 2026-03-14 | Used sample data, impressed by saturation | "Only 8 months of data" | -- | -- | Reassured on short data. Sending free tier. |
| -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- |

## Closed Won

| Prospect | Company | Est. Revenue | Close Date | MRR | Onboarding Status | Notes |
|---|---|---|---|---|---|---|
| -- | -- | -- | -- | -- | -- | -- |

## Closed Lost

| Prospect | Company | Close Date | Reason | Objection | Learnings |
|---|---|---|---|---|---|
| -- | -- | -- | -- | -- | -- |

---

## Pipeline Summary

| Metric | Count |
|---|---|
| Total outreach sent | 0 |
| Responses received | 0 |
| Demos booked | 0 |
| Demos completed | 0 |
| Closed won | 0 |
| Closed lost | 0 |
| Response rate | -- |
| Demo-to-close rate | -- |
| Current MRR | $0 |

---

## Notes

- Update this file after every outreach batch and demo.
- Move prospects from Active to Closed Won or Closed Lost when resolved.
- Example rows above are templates -- replace with real data.
- Review weekly on Mondays alongside the metrics dashboard in OPERATING_PLAN.md Section 5.
