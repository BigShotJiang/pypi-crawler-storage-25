# MixLift Pricing

**Enterprise-grade marketing mix modeling. No enterprise price tag.**

---

## Plans

|  | Free | Growth -- $299/mo |
|---|---|---|
| **Analyses per month** | 2 | Unlimited |
| **Channel ROAS** | Percentages only | Full dollar values |
| **Confidence intervals** | Yes | Yes |
| **Saturation diagnostics** | Traffic lights | Traffic lights |
| **Budget optimizer** | -- | Yes |
| **Scenario mode** ("What if I cut TikTok 20%?") | -- | Yes |
| **Contextual memory** (track changes over time) | -- | Yes |
| **Dollar headline** (total media-driven revenue) | -- | Yes |
| **Marginal ROAS** | -- | Yes |
| **Holiday auto-detection** | Yes | Yes |
| **Data privacy** (100% local processing) | Yes | Yes |
| **Channels supported** | Up to 5 | Unlimited |
| **History length** | Up to 52 weeks | Unlimited |

---

## Why $299?

MixLift uses the same Bayesian methodology (PyMC-Marketing) as tools that charge $1,500-$2,500/month. The difference: we are AI-native and automated. No account managers. No custom dashboards. No onboarding fees. You get the math, not the overhead.

| Alternative | Cost | Setup Time |
|---|---|---|
| Prescient AI / Paramark | $1,500 - $2,500/mo | 2-4 weeks |
| Freelance data scientist | $2,000 - $5,000 per analysis | 2-4 weeks per run |
| In-house data scientist | $12,000+/mo (salary) | Months to build |
| Robyn / Meridian (open source) | Free (but requires DS hire) | Months |
| **MixLift Growth** | **$299/mo** | **5 minutes** |

---

## Frequently Asked Questions

**Can I cancel anytime?**
Yes. Month-to-month billing via Stripe. Cancel from your Stripe dashboard. No contracts, no cancellation fees, no questions asked.

**What data format do you need?**
A CSV file with weekly rows. One column for each channel's spend and one column for revenue. That is it. No pixel install, no SDK, no engineering work. If you can export from a spreadsheet, you can use MixLift.

**How long does an analysis take?**
2-5 minutes from prompt to results. The Bayesian MCMC simulation runs locally on your machine. No batch jobs, no waiting for a vendor to deliver a report.

**Is my data secure?**
MixLift processes everything locally on your machine. Your CSV data never leaves your laptop. We do not store, transmit, or have access to your revenue or spend data. The only network call is a lightweight license validation check (no data is sent).

**How much historical data do I need?**
Minimum: 6 months (26 weekly data points). Recommended: 12-24 months. More data produces tighter confidence intervals. The model will tell you honestly when it is uncertain.

**Do I need to know statistics or Python?**
No. MixLift runs inside Claude (via MCP). You type plain English questions about your marketing data and get plain English answers with specific dollar recommendations. No code, no notebooks, no statistical background required.

**What channels does MixLift support?**
Any paid or measurable channel: Google Search, Meta (Facebook/Instagram), TikTok, YouTube, email, affiliate, direct mail, podcast, influencer, OOH -- anything you can measure weekly spend for.

**What if the model gives unexpected results?**
The model produces confidence intervals, not just point estimates. Wide intervals mean honest uncertainty. If results contradict your intuition, that is often the most valuable finding -- it means your platform attribution was misleading you. We are happy to walk through results together on a call.

---

## Get Started

1. Install: `pip install mixlift`
2. Add to your MCP client (Claude Desktop, Cursor, etc.)
3. Drop your CSV and ask Claude to analyze your marketing mix
4. See percentage-based results immediately on the free tier
5. Upgrade to Growth ($299/mo) for dollar values, scenario mode, and budget optimization

**Payment link:** [Provided after demo or on request]
