# MixLift 30-Minute Demo Script

**For:** Founder use only
**Format:** Live screenshare with prospect
**Prerequisites:** Claude Desktop or Cursor open, MixLift installed, sample dataset at `data/sample_8channel.csv`

---

## Section 1: Opening (2 minutes)

### Talking Points

- Thank them for their time. Confirm their role and what they're hoping to get out of the call.
- Set expectations: "In the next 30 minutes, I'm going to run a full marketing mix model on sample data -- live, right here. You'll see exactly what you'd get on your own data. No slides, no vaporware."
- Confirm their current attribution setup: "Quick question before we dive in -- how are you currently measuring which channels are actually driving revenue? Platform dashboards? GA4? Something else?"

### What to Listen For

- "We look at ROAS in Ads Manager" -- they are relying on platform attribution (your strongest displacement angle).
- "We have a BI tool / Looker / Tableau" -- they have reporting but not causal modeling (different objection path, see Section 5 inline).
- "We tried Robyn / hired a freelancer" -- they have awareness of MMM but hit complexity barriers.

---

## Section 2: Problem Framing (3 minutes)

### Talking Points

- "Here's the problem with platform attribution: every platform takes credit for the same conversion. Meta says it drove 500 sales. Google says it drove 400. TikTok says 200. But you only had 700 total. Somebody is lying -- probably everybody."
- "Marketing Mix Modeling solves this by looking at the actual statistical relationship between your spend and your revenue over time. It's the same methodology Google and Meta use internally. It uses Bayesian statistics to figure out what's actually driving your revenue, independent of any tracking pixel."
- "The catch has always been access. Enterprise MMM tools cost $20K+ per year and take weeks to set up. Open-source alternatives like Robyn require a data scientist. MixLift gives you the same math -- literally the same PyMC engine -- in a 5-minute setup."

### Transition

- "Let me show you what I mean. I'm going to run an analysis right now on a realistic DTC dataset -- 8 channels, 52 weeks. This is what it would look like on your data."

---

## Section 3: Live Analysis on Sample Data (10 minutes)

### Setup (1 minute)

Show Claude Desktop / Cursor with MixLift installed. Open the sample CSV briefly so they can see the data format.

**Say:** "This is a standard CSV -- weekly rows, one column per channel for spend, and a revenue column. That's all MixLift needs. No pixel install, no SDK, no engineering team."

### Run the Analysis (9 minutes)

**Type this exact prompt into Claude:**

```
Analyze the marketing mix for the data in /Users/felix/software-projects/mixlift/data/sample_8channel.csv

This is a DTC eCommerce brand spending across 8 channels. I want to understand which channels are actually driving revenue, where I'm hitting diminishing returns, and how I should reallocate budget.
```

**While the model runs (1-2 minutes), fill the silence with:**

- "What's happening now is a full Bayesian MCMC simulation. It's fitting probability distributions -- not point estimates -- to the relationship between each channel's spend and revenue. Four parallel chains, convergence diagnostics, the works."
- "This runs entirely on my machine. Your data never leaves your laptop. That's a big deal for brands with sensitive revenue numbers."
- "The model accounts for adstock -- the carryover effect where today's ad spend influences next week's revenue -- and saturation, where more spend hits diminishing returns."

**If the prospect asks "How long does this take on real data?":**
- "Same thing. 2-5 minutes depending on how many channels and how much history. No overnight batch jobs."

### Results Appear

**Say:** "And here we go. Let me walk you through what we're looking at."

---

## Section 4: Results Walkthrough (10 minutes)

Walk through each section of the output as it appears. Adjust emphasis based on what the prospect reacted to in the problem framing.

### 4.1 Dollar Headline (2 minutes)

**Say:** "This is the headline number. The model estimates [X]% of revenue is attributable to paid media, with the remainder coming from organic/baseline factors -- brand equity, word of mouth, SEO, things you'd have even with zero ad spend."

**Key point:** "Platform attribution would tell you 100%+ of revenue comes from ads. The model says it's closer to [X]%. That gap is where you're making bad budget decisions."

### 4.2 Channel ROAS (3 minutes)

**Say:** "Here are the channel-level ROAS estimates with confidence intervals. Notice these are Bayesian credible intervals -- they tell you the range the true ROAS likely falls in, not a single number."

**Point out:**
- The highest-ROAS channel: "This is your workhorse. The model confirms it."
- A channel where platform ROAS and model ROAS likely diverge: "This is interesting -- [channel] probably looks great in Ads Manager, but the model suggests its incremental contribution is lower. That's the attribution double-counting at work."
- The confidence interval width: "Wider intervals mean more uncertainty. Narrow intervals mean the model is confident. This is honest -- most tools just give you a single number and pretend they're sure."

**If they ask "What's marginal ROAS?":**
- "That's the return on the NEXT dollar you spend, not the average return. It accounts for diminishing returns. A channel can have a great average ROAS but terrible marginal ROAS because you've already saturated it."

### 4.3 Saturation Traffic Lights (2 minutes)

**Say:** "These traffic lights show you where each channel sits on its saturation curve. Green means headroom -- you can spend more and still get good returns. Yellow means you're approaching the point of diminishing returns. Red means you're oversaturated -- you could spend less and barely notice a revenue impact."

**Key point:** "This is the insight that saves you money. If a channel is red, every additional dollar there is basically wasted. That budget should move to a green channel."

### 4.4 Budget Optimizer (3 minutes)

**Type this prompt:**

```
Based on this analysis, how should I reallocate my budget to maximize revenue? Keep total spend the same.
```

**Say:** "The optimizer takes the model's channel curves and finds the allocation that maximizes predicted revenue at the same total spend. It's not a guess -- it's a mathematical optimization over the fitted model."

**Point out the recommended shifts:** "It's suggesting we move $[X] from [oversaturated channel] to [channel with headroom]. The predicted revenue impact is +[Y]%."

**If they seem engaged, run scenario mode:**

```
What would happen to revenue if I cut TikTok spend by 30% and moved that budget to Google Search?
```

**Say:** "This is scenario mode. You can test any what-if question against the model. 'What if I kill this channel entirely? What if I double down on email?' You're not guessing anymore -- you're simulating."

---

## Section 5: Pricing and Close (5 minutes)

### Pricing (2 minutes)

**Say:** "So that's MixLift. What you just saw is the Growth plan at $299 per month. That includes unlimited analyses, all dollar-value outputs, scenario mode, budget optimization, and the memory feature -- where the model remembers your previous analyses and shows you how things changed over time."

**Pause. Let them react.**

**If they ask about the free tier:**
- "There's a free tier -- 2 analyses per month, percentage-based outputs instead of dollar values. It's great for kicking the tires, but the dollar headlines and scenario mode are what make this actionable."

**Comparison point:** "For context, Prescient AI charges $1,500-$2,500 a month for the same methodology. They use PyMC too. The difference is they wrap it in a managed service with account managers and custom dashboards. If you don't need someone holding your hand -- and based on this conversation, you clearly don't -- you're paying for overhead, not math."

### Inline Objection Handling

**"How is this better than platform attribution?"**
- Acknowledge: "Platform attribution isn't wrong about everything. It's great at telling you which ad someone clicked."
- Reframe: "But it can't tell you the incremental impact. When Meta and Google both claim credit for the same sale, you need an independent model that looks at the actual spend-revenue relationship over time. That's what MMM does."
- Evidence: "Facebook's own research team published papers showing last-click attribution overestimates Meta's contribution by 20-40%. They recommend MMM as the complement."
- Close: "MixLift gives you that independent view in 5 minutes, not 5 weeks."

**"We already have a BI tool."**
- Acknowledge: "Looker and Tableau are great for reporting. You should keep using them."
- Reframe: "But they show you what happened -- they don't tell you what to do next. BI tools can't model diminishing returns or simulate budget scenarios. They report; MixLift recommends."
- Evidence: "Think of it this way: your BI tool is the speedometer. MixLift is the GPS. You need both, but only one tells you where to turn."
- Close: "MixLift actually complements your BI stack. The insights you get here inform the dashboards you already have."

**"Can I trust Bayesian models?"**
- Acknowledge: "Healthy skepticism. You should be asking that about any tool."
- Reframe: "Bayesian modeling is the gold standard for causal inference in marketing. Google built Meridian on it. Meta's Robyn uses it. Every major CPG company runs Bayesian MMM."
- Evidence: "The model gives you confidence intervals, not just point estimates. It tells you when it's uncertain. And we're adding LOO-CV -- leave-one-out cross-validation -- which gives you an out-of-sample accuracy score. No black box."
- Close: "Run it on your data. If the results don't match your intuition on at least 2-3 channels, I'll be surprised -- and I want to hear about it."

**"What if I only have 6 months of data?"**
- Acknowledge: "More data is always better. Two years is ideal."
- Reframe: "But 6 months -- 26 weekly data points -- is workable, especially if you have variation in your spend levels. The Bayesian approach handles small samples better than frequentist methods because it uses informative priors."
- Evidence: "The model will show wider confidence intervals with less data -- that's it being honest about uncertainty. But you'll still get directional insights on which channels are working and where you're saturated."
- Close: "Let's run it on your 6 months and see. If the confidence intervals are too wide to be useful, I'll tell you. No charge until you're getting value."

**"Why $299/mo when I can hire a freelancer?"**
- Acknowledge: "You absolutely can. A good freelance data scientist costs $100-$200/hour."
- Reframe: "At that rate, one MMM analysis costs $2,000-$5,000 and takes 2-4 weeks. With MixLift, you run it in 5 minutes, as often as you want, for $299/month. And you get scenario mode -- try hiring a freelancer to run 10 what-if simulations in real time on a call."
- Evidence: "Plus, a freelancer gives you a PDF report once. MixLift remembers your previous analyses and shows you deltas over time. It's a living model, not a one-time project."
- Close: "The freelancer model works if you need this once a year. If you want to check in monthly -- or weekly during a big campaign -- MixLift is 10x cheaper and 100x faster."

### The Close (3 minutes)

**Say:** "Based on what you've seen, does this feel like something that would change how you make budget decisions?"

**If yes:**
- "Great. I can get you set up today. It takes about 5 minutes -- I'll walk you through the install right now, and we can run it on your actual data before the end of this call."
- "The Growth plan is $299/month, cancel anytime. I'll send you the payment link and your license key will be active within a minute."

**If they need to think about it / talk to their team:**
- "Totally understand. Here's what I'd suggest: let me send you the free tier. Install it, run it on your data, and see the percentage-based results. When you're ready for the dollar values and scenario mode, you upgrade with one click. No sales follow-up unless you want it."
- Send the pricing one-pager as a leave-behind.

**If they raise a concern not covered above:**
- Note it. Say: "That's a fair point. Let me think about that and follow up with a thoughtful answer rather than a quick one." Then actually follow up within 24 hours.

---

## Post-Demo Checklist

1. Update `/Users/felix/software-projects/mixlift/docs/sales/pipeline-tracker.md` with demo outcome, objections raised, and next steps.
2. Send follow-up email within 2 hours: summary of key findings from the demo, pricing link, and any answers to open questions.
3. If they installed: check in at Day 1 and Day 3 per the onboarding playbook.
4. If they didn't install: follow up at Day 3 with a specific insight from the demo ("Remember how the model showed your TikTok ROAS was lower than Ads Manager suggested? Here's why that matters...").
