"""Project request/response schemas."""

from datetime import datetime

from pydantic import BaseModel


class ProjectCreate(BaseModel):
    name: str
    target_metric: str = "revenue"
    currency: str = "USD"


class ProjectResponse(BaseModel):
    id: str
    name: str
    target_metric: str
    currency: str
    created_at: datetime
    dataset_count: int = 0
    latest_run_status: str | None = None

    model_config = {"from_attributes": True}


class DatasetResponse(BaseModel):
    id: str
    filename: str
    platform: str
    row_count: int
    date_range_start: datetime | None
    date_range_end: datetime | None
    channel_columns: dict | None
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}
