"""MixLift — AI-native Marketing Mix Modeling."""


def analyze(csv_path, mcmc_config=None, license_key=""):
    """Run a full Bayesian MMM analysis. See mixlift.api.analyze for details."""
    from mixlift.api import analyze as _analyze
    return _analyze(csv_path, mcmc_config=mcmc_config, license_key=license_key)


__all__ = ["analyze"]
