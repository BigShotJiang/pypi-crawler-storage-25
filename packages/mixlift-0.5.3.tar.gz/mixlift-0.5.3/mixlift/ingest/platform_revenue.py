"""Platform revenue extraction helpers for N9 Platform Attribution Comparison.

Currency parsing notes
----------------------
US/standard format  ``"$1,234.56"``  → ``1234.56``  (fully supported)
European format     ``"1.234,56"``   → ``1234.56``  (best-effort: detected when
    the string contains a comma after a period-group; silently falls back to
    ``NaN`` if ambiguous, which is then filled to ``0.0`` by callers).
Blank / NaN cells   → ``0.0`` (callers call ``.fillna(0.0)``).
Column absent       → callers omit ``platform_revenue`` from the result row.

Backward-compat choice for ``loader.py``
-----------------------------------------
A parallel helper ``load_platform_revenue_totals(df, platform)`` is exported.
Existing consumers of ``load_platform_csv`` are unaffected because its
signature and return type are unchanged.  The new helper is opt-in.
"""

from __future__ import annotations

import re

import pandas as pd

# ---------------------------------------------------------------------------
# Currency parsing
# ---------------------------------------------------------------------------

_EUROPEAN_RE = re.compile(r"^\d{1,3}(\.\d{3})+(,\d+)?$")


def _parse_currency(value: object) -> float:
    """Convert a currency-formatted value to float.

    Handles:
    - Numeric values (int / float) — returned directly.
    - US format: ``"$1,234.56"`` → ``1234.56``
    - European format: ``"1.234,56"`` → ``1234.56``
    - Ambiguous / unparseable strings → ``float("nan")``
    """
    if pd.isna(value):  # type: ignore[arg-type]
        return float("nan")
    if isinstance(value, (int, float)):
        return float(value)

    s = str(value).strip()
    if not s:
        return float("nan")

    # European: period as thousands separator, comma as decimal
    if _EUROPEAN_RE.match(s):
        s = s.replace(".", "").replace(",", ".")
        try:
            return float(s)
        except ValueError:
            return float("nan")

    # Strip currency symbols and whitespace; keep digits, dots, commas, minus
    s = re.sub(r"[^\d.,-]", "", s)
    # Remove thousands commas (US format: 1,234.56)
    s = s.replace(",", "")
    try:
        return float(s)
    except ValueError:
        return float("nan")


def parse_revenue_series(series: pd.Series) -> pd.Series:
    """Apply ``_parse_currency`` element-wise and fill NaN → 0.0."""
    return series.map(_parse_currency).fillna(0.0)


# ---------------------------------------------------------------------------
# Column detection helpers
# ---------------------------------------------------------------------------

def _find_revenue_column(df: pd.DataFrame, aliases: list[str]) -> str | None:
    """Return the first matching column name (case-insensitive, whitespace-stripped).

    Returns ``None`` if no alias matches.
    """
    lower_cols = {c.lower().strip(): c for c in df.columns}
    for alias in aliases:
        key = alias.lower().strip()
        if key in lower_cols:
            return lower_cols[key]
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_platform_revenue(df: pd.DataFrame, platform: str) -> dict[str, float]:
    """Aggregate platform-reported revenue by channel over the full window.

    Looks for ``platform_revenue`` in *canonical* long-format DataFrames
    (i.e., after a parser has already run).  Sums by ``channel``.

    Returns ``{channel_name: total_revenue}``.  Empty dict if the column is
    absent or the platform is unrecognised.
    """
    if "platform_revenue" not in df.columns:
        return {}
    if "channel" not in df.columns:
        return {}

    totals: dict[str, float] = (
        df.groupby("channel")["platform_revenue"]
        .sum()
        .to_dict()
    )
    return totals


def detect_platform_revenue_columns(df: pd.DataFrame) -> dict[str, str]:
    """Detect wide-format platform-revenue columns.

    Scans for ``{channel}_platform_revenue`` pattern (case-insensitive).
    Returns ``{channel_name: column_name}`` for each match.
    """
    result: dict[str, str] = {}
    suffix = "_platform_revenue"
    for col in df.columns:
        if col.lower().endswith(suffix):
            channel = col[: -len(suffix)]
            result[channel] = col
    return result
