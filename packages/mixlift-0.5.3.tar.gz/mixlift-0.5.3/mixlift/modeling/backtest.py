"""Walk-forward holdout validation for MixLift MMM.

Public API:
    run_backtest(X, y, channel_columns, ...) -> BacktestResult

The engine fits one MMM per fold on an expanding training window and evaluates
OOS predictions on the held-out horizon. Predictions use the combined train+test
window so that geometric adstock carryover is preserved across the boundary.

Do NOT call this module from server.py or renderers — that wiring is WB-2.
"""

from __future__ import annotations

import logging
import time
import warnings as _warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

from mixlift.modeling.defaults import FAST_BACKTEST_CONFIG
from mixlift.modeling.engine import build_model, fit_model

if TYPE_CHECKING:
    from mixlift_mcp.progress import ProgressReporter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public result type
# ---------------------------------------------------------------------------


@dataclass
class BacktestResult:
    """Container for backtest output."""

    mode: str  # "walk_forward" | "single_holdout" | "skipped"
    status: str  # "success" | "insufficient_data" | "failed"
    n_folds: int
    horizon_weeks: int
    train_weeks: int | None
    folds: list[dict] = field(default_factory=list)
    aggregate: dict = field(default_factory=dict)
    compute_secs: float = 0.0
    note: str | None = None  # populated on skip / failure


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_backtest(
    X: pd.DataFrame,
    y: pd.Series,
    channel_columns: list[str],
    adstock_l_max: int = 8,
    mcmc_config: dict | None = None,
    n_folds: int = 3,
    horizon: int = 4,
    reporter: "ProgressReporter | None" = None,
) -> BacktestResult:
    """Run walk-forward backtest with expanding training windows.

    Falls back to a single holdout split when data_weeks is in
    [30, n_folds*horizon + 26).  Skips entirely when data_weeks < 30.

    Args:
        X: Feature DataFrame (must contain a ``date`` column at position 0).
        y: Target series aligned to X.
        channel_columns: Spend column names used in build_model().
        adstock_l_max: Max adstock lag passed through to build_model().
        mcmc_config: MCMC overrides; defaults to FAST_BACKTEST_CONFIG.
        n_folds: Number of walk-forward folds (default 3).
        horizon: Weeks per fold held out for evaluation (default 4).
        reporter: Optional ProgressReporter for live phase notifications.

    Returns:
        BacktestResult with per-fold metrics and aggregate interpretation.
    """
    n = len(X)
    min_train = 26
    required = min_train + n_folds * horizon  # default: 38

    logger.info(
        f"run_backtest: n={n} weeks, n_folds={n_folds}, horizon={horizon}, "
        f"required={required}"
    )

    if n < 30:
        note = f"Need ≥30 weeks; have {n}. Walk-forward needs ≥{required}."
        logger.info(f"Backtest skipped: {note}")
        return BacktestResult(
            mode="skipped",
            status="insufficient_data",
            n_folds=0,
            horizon_weeks=horizon,
            train_weeks=None,
            note=note,
        )

    if n < required:
        logger.info(
            f"Falling back to single holdout (n={n} < required={required})."
        )
        return _run_single_holdout(
            X, y, channel_columns, adstock_l_max, mcmc_config, horizon, reporter
        )

    return _run_walk_forward(
        X, y, channel_columns, adstock_l_max, mcmc_config, n_folds, horizon, reporter
    )


# ---------------------------------------------------------------------------
# Walk-forward implementation
# ---------------------------------------------------------------------------


def _run_walk_forward(
    X: pd.DataFrame,
    y: pd.Series,
    channel_columns: list[str],
    adstock_l_max: int,
    mcmc_config: dict | None,
    n_folds: int,
    horizon: int,
    reporter: "ProgressReporter | None",
) -> BacktestResult:
    effective_config = mcmc_config or FAST_BACKTEST_CONFIG
    n = len(X)
    folds: list[dict] = []
    start = time.time()

    for i in range(n_folds):
        train_end = n - (n_folds - i) * horizon
        test_start = train_end
        test_end = test_start + horizon

        X_train = X.iloc[:train_end].copy()
        y_train = y.iloc[:train_end].copy()
        X_test = X.iloc[test_start:test_end].copy()
        y_test = y.iloc[test_start:test_end].copy()

        if reporter is not None:
            reporter.phase(f"Backtesting fold {i + 1}/{n_folds}", i, n_folds)

        logger.info(
            f"Fold {i + 1}/{n_folds}: train={len(X_train)} weeks, "
            f"test={len(X_test)} weeks"
        )

        fold_dict = _fit_and_score_fold(
            fold_idx=i + 1,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            channel_columns=channel_columns,
            adstock_l_max=adstock_l_max,
            effective_config=effective_config,
            horizon=horizon,
        )
        folds.append(fold_dict)

    aggregate = _aggregate_folds(folds)
    elapsed = time.time() - start

    return BacktestResult(
        mode="walk_forward",
        status="success",
        n_folds=n_folds,
        horizon_weeks=horizon,
        train_weeks=n - horizon,  # expanding window; reported in single-fold terms
        folds=folds,
        aggregate=aggregate,
        compute_secs=elapsed,
    )


# ---------------------------------------------------------------------------
# Single-holdout fallback
# ---------------------------------------------------------------------------


def _run_single_holdout(
    X: pd.DataFrame,
    y: pd.Series,
    channel_columns: list[str],
    adstock_l_max: int,
    mcmc_config: dict | None,
    horizon: int,
    reporter: "ProgressReporter | None",
) -> BacktestResult:
    effective_config = mcmc_config or FAST_BACKTEST_CONFIG
    n = len(X)
    start = time.time()

    X_train = X.iloc[: n - horizon].copy()
    y_train = y.iloc[: n - horizon].copy()
    X_test = X.iloc[n - horizon :].copy()
    y_test = y.iloc[n - horizon :].copy()

    if reporter is not None:
        reporter.phase("Backtesting single holdout fold", 0, 1)

    logger.info(
        f"Single holdout: train={len(X_train)} weeks, test={len(X_test)} weeks"
    )

    fold_dict = _fit_and_score_fold(
        fold_idx=1,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        channel_columns=channel_columns,
        adstock_l_max=adstock_l_max,
        effective_config=effective_config,
        horizon=horizon,
    )

    aggregate = _aggregate_folds([fold_dict])
    elapsed = time.time() - start

    return BacktestResult(
        mode="single_holdout",
        status="success",
        n_folds=1,
        horizon_weeks=horizon,
        train_weeks=n - horizon,
        folds=[fold_dict],
        aggregate=aggregate,
        compute_secs=elapsed,
    )


# ---------------------------------------------------------------------------
# Core fold fitting + scoring
# ---------------------------------------------------------------------------


def _fit_and_score_fold(
    fold_idx: int,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    channel_columns: list[str],
    adstock_l_max: int,
    effective_config: dict,
    horizon: int,
) -> dict:
    """Fit one fold's MMM and return a metrics dict."""
    with _warnings.catch_warnings():
        _warnings.filterwarnings("ignore", category=FutureWarning)
        mmm_fold = build_model(channel_columns, adstock_l_max=adstock_l_max)
        mmm_fold, _ = fit_model(mmm_fold, X_train, y_train, mcmc_config=effective_config)

    # Concatenate train+test so adstock carryover is preserved across boundary.
    # PyMC-Marketing's sample_posterior_predictive re-runs the adstock transform
    # over the full combined window; we then extract only the final `horizon` rows.
    X_combined = pd.concat([X_train, X_test], ignore_index=True)

    pp = mmm_fold.sample_posterior_predictive(
        X_combined, extend_idata=False, combined=False
    )

    # pp is an xarray Dataset/DataArray; get the target variable name.
    # When combined=False, dims are (chain, draw, date) after az.extract.
    target_var = list(pp.data_vars)[0] if hasattr(pp, "data_vars") else None

    if target_var is not None:
        y_pred_samples = pp[target_var].isel(date=slice(-horizon, None))
    else:
        # pp is already a DataArray (single var extracted)
        y_pred_samples = pp.isel(date=slice(-horizon, None))

    # Collapse chain + draw into point estimates and uncertainty bands
    chain_draw_dims = [d for d in y_pred_samples.dims if d in ("chain", "draw", "sample")]
    if chain_draw_dims:
        y_pred_mean = y_pred_samples.mean(dim=chain_draw_dims).values
        y_pred_low = y_pred_samples.quantile(0.10, dim=chain_draw_dims).values
        y_pred_high = y_pred_samples.quantile(0.90, dim=chain_draw_dims).values
    else:
        # Already collapsed (combined=True somehow) — use directly
        y_pred_mean = y_pred_samples.values
        y_pred_low = y_pred_mean
        y_pred_high = y_pred_mean

    y_actual = y_test.values

    fold_metrics = _compute_fold_metrics(y_actual, y_pred_mean, y_pred_low, y_pred_high)

    # Free model RAM before next fold
    del mmm_fold

    return {
        "fold": fold_idx,
        "train_start": X_train["date"].iloc[0].isoformat(),
        "train_end": X_train["date"].iloc[-1].isoformat(),
        "test_start": X_test["date"].iloc[0].isoformat(),
        "test_end": X_test["date"].iloc[-1].isoformat(),
        "mape": fold_metrics["mape"],
        "r_squared": fold_metrics["r_squared"],
        "coverage_80": fold_metrics["coverage_80"],
        "weekly_actual": y_actual.tolist(),
        "weekly_predicted_mean": y_pred_mean.tolist(),
        "weekly_predicted_low": y_pred_low.tolist(),
        "weekly_predicted_high": y_pred_high.tolist(),
    }


# ---------------------------------------------------------------------------
# Metric helpers
# ---------------------------------------------------------------------------


def _compute_fold_metrics(
    y_true: np.ndarray,
    y_pred_mean: np.ndarray,
    y_pred_low: np.ndarray,
    y_pred_high: np.ndarray,
) -> dict:
    """Compute per-fold predictive metrics.

    Args:
        y_true: Actual observed values, shape (horizon,).
        y_pred_mean: Posterior mean predictions, shape (horizon,).
        y_pred_low: 10th percentile predictions, shape (horizon,).
        y_pred_high: 90th percentile predictions, shape (horizon,).

    Returns:
        Dict with keys: mape, r_squared, coverage_80.
    """
    # MAPE — fall back to SMAPE when any y_true is zero to avoid divide-by-zero
    if np.all(y_true != 0):
        mape = float(np.mean(np.abs((y_true - y_pred_mean) / y_true)) * 100)
    else:
        # Symmetric MAPE: bounded between 0 and 200
        denom = np.abs(y_true) + np.abs(y_pred_mean)
        # Guard against both being zero simultaneously
        safe_denom = np.where(denom == 0, 1.0, denom)
        mape = float(np.mean(200 * np.abs(y_true - y_pred_mean) / safe_denom))

    # Point-estimate R²
    ss_res = float(np.sum((y_true - y_pred_mean) ** 2))
    ss_tot = float(np.sum((y_true - np.mean(y_true)) ** 2))
    r_squared: float | None = float(1 - ss_res / ss_tot) if ss_tot > 0 else None

    # 80% empirical coverage: fraction of actuals inside [low, high]
    in_ci = (y_true >= y_pred_low) & (y_true <= y_pred_high)
    coverage_80 = float(np.mean(in_ci))

    return {"mape": mape, "r_squared": r_squared, "coverage_80": coverage_80}


def _aggregate_folds(folds: list[dict]) -> dict:
    """Aggregate per-fold metrics across all folds.

    Args:
        folds: List of fold dicts each containing mape, r_squared, coverage_80.

    Returns:
        Dict with mean/median aggregates and an interpretation tag.
    """
    mapes = [f["mape"] for f in folds]
    r2s = [f["r_squared"] for f in folds if f.get("r_squared") is not None]
    covs = [f["coverage_80"] for f in folds]

    agg: dict = {
        "mape_mean": float(np.mean(mapes)),
        "mape_median": float(np.median(mapes)),
        "r_squared_mean": float(np.mean(r2s)) if r2s else None,
        "coverage_80_mean": float(np.mean(covs)),
    }

    tag, label = _interpret_aggregate(agg["mape_mean"], agg["coverage_80_mean"])
    agg["interpretation"] = tag
    agg["interpretation_label"] = label
    return agg


def _interpret_aggregate(mape_mean: float, coverage_80_mean: float) -> tuple[str, str]:
    """Classify aggregate backtest quality.

    Thresholds:
        great      — MAPE < 10 AND coverage in [0.70, 0.90]
        acceptable — MAPE < 20 AND coverage in [0.60, 0.95]
        poor       — anything else

    Args:
        mape_mean: Average MAPE across folds (percentage).
        coverage_80_mean: Average fraction of actuals inside 80% CI.

    Returns:
        Tuple of (tag, label).
    """
    if mape_mean < 10 and 0.70 <= coverage_80_mean <= 0.90:
        return "great", "well_calibrated"
    if mape_mean < 20 and 0.60 <= coverage_80_mean <= 0.95:
        return "acceptable", "directional"
    return "poor", "use_with_caution"
