"""Core MMM engine: build, fit, and extract results using PyMC-Marketing."""

from __future__ import annotations

import logging
import os as _os
import time
import warnings as _warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import arviz as az
import numpy as np
import pandas as pd
from pymc_marketing.mmm import GeometricAdstock, LogisticSaturation

from mixlift.modeling.optimizer import format_channel_name

if TYPE_CHECKING:
    from mixlift_mcp.progress import ProgressReporter

# pymc-marketing ≥0.18 ships a new multidimensional.MMM, but it drops
# compute_channel_contribution_original_scale() which our pipeline relies on.
# Use the legacy MMM (pymc_marketing.mmm.mmm.MMM) which retains the full API.
with _warnings.catch_warnings():
    _warnings.filterwarnings("ignore", category=FutureWarning)
    from pymc_marketing.mmm.mmm import MMM  # noqa: F811

from mixlift.modeling.defaults import DEFAULT_MCMC_CONFIG, DEFAULT_SEASONALITY

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Sampler feature flag
# ---------------------------------------------------------------------------
# MIXLIFT_SAMPLER env var selects which NUTS implementation to use.
# "pymc"   (default) — PyMC's built-in sampler. Zero behavior change from today.
# "nutpie"           — Rust-based NUTS via nutpie. 3-5x faster on Linux/macOS ARM.
#                      Requires `pip install "mixlift[fast]"` or `nutpie>=0.14`.
#                      Falls back to "pymc" with a warning if nutpie is not installed.
#
# NOTE: nutpie does NOT fire the per-draw callback kwarg.  When nutpie is active
# we emit coarser "phase marker" progress (start + done only) instead of the
# per-draw throttled notifications that pymc emits.  Correctness is unaffected.
#
# macOS fork deadlock: PyMC's multiprocess sampler requires MIXLIFT_MCMC_CORES=1
# on macOS ARM to avoid fork deadlocks.  nutpie is Rust-based and does NOT fork
# child processes — it runs all chains in a single process using Rust threads.
# This means nutpie is safe to run with cores>1 on any OS without the fork workaround.
# On Linux/Fly.io you can set MIXLIFT_MCMC_CORES=4 with nutpie for full parallelism.


def _resolve_sampler() -> str:
    """Return the effective sampler name, falling back to 'pymc' if nutpie is unavailable."""
    requested = _os.environ.get("MIXLIFT_SAMPLER", "pymc").lower().strip()
    if requested not in ("pymc", "nutpie"):
        logger.warning(
            "Unknown MIXLIFT_SAMPLER=%r. Falling back to 'pymc'.", requested
        )
        return "pymc"
    if requested == "nutpie":
        try:
            import nutpie  # noqa: F401
        except ImportError:
            logger.warning(
                "MIXLIFT_SAMPLER=nutpie requested but nutpie is not installed. "
                "Install with: pip install 'mixlift[fast]'. Falling back to pymc."
            )
            return "pymc"
    return requested


@dataclass
class ModelResults:
    """Container for fitted model results."""

    channel_contributions: dict[str, float]  # channel -> mean contribution
    channel_contributions_ci: dict[str, tuple[float, float]]  # channel -> (low, high)
    roas_estimates: dict[str, float]  # channel -> average ROAS
    roas_ci: dict[str, tuple[float, float]]  # channel -> (low, high)
    marginal_roas_estimates: dict[str, float]  # channel -> marginal ROAS
    marginal_roas_ci: dict[str, tuple[float, float]]  # channel -> (low, high)
    total_spend: dict[str, float]  # channel -> total spend
    duration_secs: float
    mmm: MMM  # the fitted model object
    convergence_warnings: list[str]  # MCMC convergence warnings
    posterior_predictive_warning: str = ""  # warning if posterior predictive failed
    raw_contributions: object = None  # xarray DataArray, reusable by optimizer
    loo_cv: dict = field(default_factory=dict)  # LOO-CV results from compute_loo_cv()
    intercept_decomposition: dict = field(default_factory=dict)  # baseline/organic revenue


def build_model(
    channel_columns: list[str],
    adstock_l_max: int = 8,
    yearly_seasonality: int | None = None,
) -> MMM:
    """Build a PyMC-Marketing MMM with opinionated defaults.

    Args:
        channel_columns: List of channel spend column names in X
        adstock_l_max: Maximum adstock lag in weeks
        yearly_seasonality: Number of Fourier terms for yearly seasonality
    """
    if yearly_seasonality is None:
        yearly_seasonality = DEFAULT_SEASONALITY["yearly_seasonality"]

    mmm = MMM(
        date_column="date",
        adstock=GeometricAdstock(l_max=adstock_l_max),
        saturation=LogisticSaturation(),
        yearly_seasonality=yearly_seasonality,
        channel_columns=channel_columns,
    )

    logger.info(
        f"Built MMM with {len(channel_columns)} channels, "
        f"adstock_l_max={adstock_l_max}, seasonality={yearly_seasonality}"
    )

    return mmm


def _make_pymc_callback(
    reporter: "ProgressReporter",
    n_chains: int,
    n_draws: int,
    draw_throttle: int = 25,
):
    """Return a PyMC sampling callback that emits throttled progress notifications.

    PyMC calls callback(trace, draw) in the main process for every accepted
    draw (both tuning and production). ``draw.tuning`` is True during the warmup
    phase; we only report production draws to keep the messages clean.

    Args:
        reporter: ProgressReporter wired to the MCP context.
        n_chains: Total number of chains (used for the progress label).
        n_draws: Production draws per chain (used for throttle math + progress bar).
        draw_throttle: Emit a notification every this many production draws.

    Returns:
        Callable suitable for pymc.sample(callback=...).
    """
    # draw_idx in the PyMC callback includes tune draws; we track production
    # draw count per chain separately.
    per_chain_counts: dict[int, int] = {}

    def callback(trace, draw) -> None:  # noqa: ANN001
        if draw.tuning:
            return  # Skip warmup draws — too noisy and users don't care

        chain = draw.chain
        per_chain_counts[chain] = per_chain_counts.get(chain, 0) + 1
        count = per_chain_counts[chain]

        if count % draw_throttle != 0 and count != n_draws:
            return  # Throttle: only emit every draw_throttle draws (and the last)

        # Total progress across all chains: treat each chain as n_draws units
        completed = sum(per_chain_counts.values())
        total_draws = n_chains * n_draws

        reporter.phase(
            f"Sampling chain {chain + 1}/{n_chains} (draw {count}/{n_draws})",
            progress=float(completed),
            total=float(total_draws),
        )

    return callback


def fit_model(
    mmm: MMM,
    X: pd.DataFrame,
    y: pd.Series,
    mcmc_config: dict | None = None,
    reporter: "ProgressReporter | None" = None,
    draw_throttle: int = 25,
) -> tuple[MMM, str]:
    """Fit the MMM model using MCMC sampling.

    Args:
        mmm: Built MMM model
        X: Feature DataFrame with channel spend columns + date + controls
        y: Target series (revenue or conversions)
        mcmc_config: Override MCMC settings
        reporter: Optional ProgressReporter for live progress notifications.
        draw_throttle: Emit a draw-level notification every this many draws.

    Returns:
        Tuple of (fitted MMM model, posterior predictive warning string)
    """
    config = {**DEFAULT_MCMC_CONFIG, **(mcmc_config or {})}
    n_chains = config["chains"]
    n_draws = config["draws"]

    logger.info(
        f"Starting model fitting: {n_chains} chains, "
        f"{config['tune']} tune, {n_draws} draws"
    )

    start = time.time()

    X = X.reset_index(drop=True)
    y = y.reset_index(drop=True)
    y.name = "y"  # pymc-marketing 0.18+ multidimensional MMM expects this name

    # Resolve sampler from env flag (default: "pymc").
    sampler = _resolve_sampler()

    # Default to single-core to avoid multiprocessing fork deadlocks on macOS ARM.
    # On Linux (e.g. Fly.io remote deployment), set MIXLIFT_MCMC_CORES=<n> in the
    # environment to parallelize chain sampling and cut latency.
    # NOTE: nutpie uses Rust threads (not fork), so it is fork-safe on all platforms.
    # MIXLIFT_MCMC_CORES still controls pymc's `cores` kwarg when sampler=="pymc".
    # nutpie ignores `cores` entirely — it always runs chains concurrently in Rust.
    try:
        _cores = max(1, int(_os.environ.get("MIXLIFT_MCMC_CORES", "1")))
    except ValueError:
        _cores = 1

    # Build a PyMC-level callback if we have a reporter.
    # IMPORTANT: nutpie does NOT invoke the callback kwarg (confirmed empirically).
    # When nutpie is active we emit coarser phase markers (start + done) instead.
    pymc_callback = None
    if reporter is not None and sampler == "pymc":
        pymc_callback = _make_pymc_callback(
            reporter=reporter,
            n_chains=n_chains,
            n_draws=n_draws,
            draw_throttle=draw_throttle,
        )
    elif reporter is not None and sampler == "nutpie":
        # Emit a single phase marker before sampling starts; done is reported by
        # fit_model's caller (run_full_pipeline) via its own progress markers.
        reporter.phase(
            f"Sampling (nutpie) — {n_chains} chains × {n_draws} draws",
            progress=0,
            total=1,
        )

    fit_kwargs: dict = dict(
        X=X,
        y=y,
        chains=n_chains,
        tune=config["tune"],
        draws=n_draws,
        target_accept=config["target_accept"],
    )

    if sampler == "pymc":
        # `cores` is only meaningful for PyMC's own multi-process sampler.
        fit_kwargs["cores"] = _cores
    else:
        # nutpie's NUTS diverges at pymc's default target_accept=0.90 on MMM's
        # log-posterior (~0.3–0.8% divergence rate, empirically). Force >=0.95
        # unless the caller explicitly passed something higher. The per-draw
        # cost is tiny compared to the 12× sampler speedup.
        if fit_kwargs["target_accept"] < 0.95:
            logger.info(
                "nutpie: raising target_accept %.2f → 0.95 to eliminate divergences",
                fit_kwargs["target_accept"],
            )
            fit_kwargs["target_accept"] = 0.95
        # Pass nuts_sampler through to PyMC, which routes to the external sampler.
        fit_kwargs["nuts_sampler"] = sampler
        logger.info("Using external NUTS sampler: %s", sampler)
        # Forward any nutpie-specific kwargs (e.g. cores=4 for Rust-thread parallelism).
        # nutpie does NOT use fork-based multiprocessing, so cores>1 is safe on macOS.
        nuts_sampler_kwargs = config.get("nuts_sampler_kwargs")
        if nuts_sampler_kwargs:
            fit_kwargs["nuts_sampler_kwargs"] = nuts_sampler_kwargs

    # Only pass random_seed if explicitly provided (backward compat for tests)
    seed = config.get("random_seed")
    if seed is not None:
        fit_kwargs["random_seed"] = seed
    if pymc_callback is not None:
        fit_kwargs["callback"] = pymc_callback

    mmm.fit(**fit_kwargs)

    # Generate posterior predictive for model fit metrics (R-squared, MAPE)
    pp_warning = ""
    try:
        mmm.sample_posterior_predictive(X, extend_idata=True, combined=False)
    except Exception as e:
        pp_warning = (
            f"Model fit metrics could not be validated — interpret results with caution. Error: {e}"
        )
        logger.warning(f"Could not generate posterior predictive: {e}")

    elapsed = time.time() - start
    logger.info(f"Model fitting completed in {elapsed:.1f}s")

    return mmm, pp_warning


def extract_channel_contributions(
    mmm: MMM,
    X: pd.DataFrame,
    channel_columns: list[str],
    contributions=None,
) -> tuple[dict[str, float], dict[str, tuple[float, float]]]:
    """Extract channel contribution estimates from fitted model.

    Args:
        contributions: Pre-computed contributions xarray (avoids recomputation).

    Returns:
        Tuple of (mean contributions dict, credible interval dict)
    """
    # Get posterior channel contributions (xarray DataArray)
    if contributions is None:
        contributions = mmm.compute_channel_contribution_original_scale()

    means = {}
    cis = {}

    for channel in channel_columns:
        display_name = format_channel_name(channel)

        # Select this channel, sum over date, stack chain+draw into samples
        channel_contrib = contributions.sel(channel=channel).sum(dim="date")
        samples = channel_contrib.values.flatten()
        means[display_name] = float(np.mean(samples))
        cis[display_name] = (
            float(np.percentile(samples, 5)),
            float(np.percentile(samples, 95)),
        )

    return means, cis


def extract_roas(
    mmm: MMM,
    X: pd.DataFrame,
    channel_columns: list[str],
    contributions=None,
) -> tuple[dict[str, float], dict[str, tuple[float, float]]]:
    """Extract average ROAS (total contribution / total spend) per channel.

    This is average ROAS, not marginal. Average ROAS tells you the overall
    return across all spend; marginal ROAS tells you the return on the next
    dollar spent. See extract_marginal_roas for the marginal variant.

    Args:
        contributions: Pre-computed contributions xarray (avoids recomputation).

    Returns:
        Tuple of (mean average ROAS dict, credible interval dict)
    """
    if contributions is None:
        contributions = mmm.compute_channel_contribution_original_scale()

    roas_means = {}
    roas_cis = {}

    for channel in channel_columns:
        display_name = format_channel_name(channel)

        total_spend = X[channel].sum()
        if total_spend < 1e-6:
            roas_means[display_name] = 0.0
            roas_cis[display_name] = (0.0, 0.0)
            continue

        channel_contrib = contributions.sel(channel=channel).sum(dim="date")
        samples = channel_contrib.values.flatten()
        roas_samples = samples / total_spend

        roas_means[display_name] = float(np.mean(roas_samples))
        roas_cis[display_name] = (
            float(np.percentile(roas_samples, 5)),
            float(np.percentile(roas_samples, 95)),
        )

    return roas_means, roas_cis


def extract_marginal_roas(
    mmm: MMM,
    X: pd.DataFrame,
    channel_columns: list[str],
    delta_pct: float = 0.01,
) -> tuple[dict[str, float], dict[str, tuple[float, float]]]:
    """Extract marginal ROAS per channel via finite-difference approximation.

    Marginal ROAS = d(contribution) / d(spend) evaluated at current spend level.
    Computed by bumping spend by delta_pct and measuring the change in contribution.

    Args:
        mmm: Fitted MMM model
        X: Feature DataFrame
        channel_columns: Channel column names
        delta_pct: Fractional bump to apply (default 1%)

    Returns:
        Tuple of (mean marginal ROAS dict, credible interval dict)
    """
    # Use channel_contribution_forward_pass for finite-difference marginal ROAS.
    # This takes preprocessed channel data as numpy and returns numpy arrays.
    channel_data_base = X[channel_columns].values  # (n_obs, n_channels)
    contributions_base = mmm.channel_contribution_forward_pass(channel_data_base)

    mroas_means = {}
    mroas_cis = {}

    for i, channel in enumerate(channel_columns):
        display_name = format_channel_name(channel)

        mean_spend = float(X[channel].mean())
        if mean_spend < 1e-6:
            mroas_means[display_name] = 0.0
            mroas_cis[display_name] = (0.0, 0.0)
            continue

        delta = mean_spend * delta_pct
        channel_data_bumped = channel_data_base.copy()
        channel_data_bumped[:, i] += delta

        contributions_bumped = mmm.channel_contribution_forward_pass(channel_data_bumped)

        # Sum over time for each posterior sample
        base_total = contributions_base[:, :, i].sum(axis=1)
        bumped_total = contributions_bumped[:, :, i].sum(axis=1)

        total_delta_spend = delta * len(X)
        mroas_samples = (bumped_total - base_total) / total_delta_spend

        mroas_means[display_name] = float(np.mean(mroas_samples))
        mroas_cis[display_name] = (
            float(np.percentile(mroas_samples, 5)),
            float(np.percentile(mroas_samples, 95)),
        )

    return mroas_means, mroas_cis


def extract_saturation_params(mmm: MMM, channel_columns: list[str]) -> dict[str, dict[str, float]]:
    """Extract posterior mean saturation parameters (lam, beta) per channel.

    PyMC-Marketing's LogisticSaturation uses: beta * (1 - exp(-lam * x)) / (1 + exp(-lam * x))

    Returns:
        dict mapping display_name -> {"lam": float, "beta": float}
    """
    posterior = mmm.idata.posterior
    lam_samples = posterior["saturation_lam"].values  # (chains, draws, n_channels)
    beta_samples = posterior["saturation_beta"].values

    params = {}
    for i, col in enumerate(channel_columns):
        display_name = format_channel_name(col)
        params[display_name] = {
            "lam": float(np.mean(lam_samples[:, :, i])),
            "beta": float(np.mean(beta_samples[:, :, i])),
        }
    return params


def extract_adstock_params(mmm: MMM, channel_columns: list[str]) -> dict[str, dict[str, float]]:
    """Extract posterior mean adstock parameters (alpha) per channel.

    GeometricAdstock uses alpha as the retention rate.

    Returns:
        dict mapping display_name -> {"alpha": float}
    """
    posterior = mmm.idata.posterior
    alpha_samples = posterior["adstock_alpha"].values  # (chains, draws, n_channels)

    params = {}
    for i, col in enumerate(channel_columns):
        display_name = format_channel_name(col)
        params[display_name] = {
            "alpha": float(np.mean(alpha_samples[:, :, i])),
        }
    return params


def logistic_saturation(spend: np.ndarray, lam: float) -> np.ndarray:
    """Apply logistic saturation matching PyMC-Marketing's formula.

    Formula: (1 - exp(-lam * x)) / (1 + exp(-lam * x))

    This is the raw saturation curve without the beta scaling.
    To get the full channel response, multiply by beta.
    """
    # Clamp exponent to prevent exp underflow (exp(-36) ≈ 2e-16 → result ≈ 1.0 exactly,
    # which gives zero gradient in the optimizer). Clamping at 30 keeps a small gradient.
    exponent = np.clip(lam * spend, 0, 30)
    return (1 - np.exp(-exponent)) / (1 + np.exp(-exponent))


def geometric_adstock_np(
    x: np.ndarray, alpha: float, l_max: int = 8, normalize: bool = True
) -> np.ndarray:
    """Apply geometric adstock transformation (NumPy version).

    Convolves spend with geometrically decaying weights [1, alpha, alpha^2, ...].
    At time t, output[t] = sum(weights[k] * x[t-k]) for k=0..l_max-1,
    treating x[t] = 0 for t < 0.

    Args:
        x: 1-D spend time series.
        alpha: Retention rate (0 to 1).
        l_max: Maximum lag.
        normalize: Whether to normalize weights to sum to 1.

    Returns:
        Adstocked spend array of same length as x.
    """
    weights = np.power(alpha, np.arange(l_max))
    if normalize:
        weights = weights / weights.sum()
    # np.convolve(x, weights) computes sum(x[k] * weights[t-k]) = sum(weights[k] * x[t-k])
    # which is exactly the causal convolution we need.
    # Take only the first len(x) elements (causal part, no future leakage).
    conv = np.convolve(x, weights)
    return conv[: len(x)]


def extract_saturation_curves(
    mmm: MMM,
    X: pd.DataFrame,
    channel_columns: list[str],
    n_points: int = 100,
) -> dict[str, dict[str, list[float]]]:
    """Generate saturation curve data for each channel.

    Returns:
        dict mapping channel_name -> {"spend": [...], "response": [...]}
    """
    params = extract_saturation_params(mmm, channel_columns)
    curves = {}

    for col in channel_columns:
        display_name = format_channel_name(col)
        max_spend = float(X[col].max()) * 2
        spend = np.linspace(0, max_spend, n_points)
        lam = params[display_name]["lam"]
        beta = params[display_name]["beta"]
        response = beta * logistic_saturation(spend, lam)
        curves[display_name] = {
            "spend": spend.tolist(),
            "response": response.tolist(),
        }

    return curves


def check_convergence(mmm: MMM) -> list[str]:
    """Check MCMC convergence diagnostics and return warnings.

    Checks:
    - R-hat > 1.05 for any parameter (indicates chains haven't converged)
    - Divergent transitions (indicates sampling problems)

    Returns:
        List of warning strings (empty if all checks pass)
    """
    warnings = []
    idata = mmm.idata

    # Check R-hat (requires ≥2 chains)
    try:
        n_chains = idata.posterior.sizes.get("chain", 1)
    except Exception:
        n_chains = 1

    if n_chains < 2:
        logger.info("R-hat not computed (requires ≥2 chains). Using single-chain diagnostics.")
        warnings.append(
            "R-hat not computed (requires ≥2 chains). "
            "Consider using ≥2 chains for more reliable convergence diagnostics."
        )
    else:
        try:
            rhat = az.rhat(idata)
            for var_name in rhat.data_vars:
                values = rhat[var_name].values
                max_rhat = float(np.max(values))
                if max_rhat > 1.05:
                    warnings.append(
                        f"R-hat for '{var_name}' is {max_rhat:.3f} (> 1.05). "
                        f"Chains may not have converged. Consider increasing tune/draws."
                    )
        except Exception as e:
            warnings.append(f"Could not compute R-hat: {e}")

    # Check ESS (Effective Sample Size)
    if n_chains >= 2:
        try:
            ess = az.ess(idata)
            for var_name in ess.data_vars:
                values = ess[var_name].values
                min_ess = float(np.min(values))
                if min_ess < 100:
                    warnings.append(
                        f"Low effective sample size for '{var_name}' "
                        f"(min ESS = {min_ess:.0f}). "
                        f"Results may be unreliable. Consider increasing draws."
                    )
        except Exception as e:
            logger.debug(f"Could not compute ESS: {e}")

    # Check divergences
    try:
        if hasattr(idata, "sample_stats"):
            divergent = idata.sample_stats.get("diverging", None)
            if divergent is not None:
                n_divergent = int(np.sum(divergent.values))
                if n_divergent > 0:
                    total_samples = int(np.prod(divergent.shape))
                    pct = 100 * n_divergent / total_samples
                    warnings.append(
                        f"{n_divergent} divergent transitions ({pct:.1f}% of samples). "
                        f"Consider increasing target_accept or reparameterizing the model."
                    )
    except Exception as e:
        warnings.append(f"Could not check divergences: {e}")

    if warnings:
        for w in warnings:
            logger.warning(f"Convergence issue: {w}")
    else:
        logger.info("All convergence diagnostics passed.")

    return warnings


def check_roas_plausibility(
    roas_estimates: dict[str, float],
    roas_ci: dict[str, tuple[float, float]],
) -> list[str]:
    """Check ROAS estimates for obviously implausible values.

    Flags:
    - ROAS > 20x (likely model artifact — few real channels sustain this)
    - ROAS < 0 (negative returns — possible but warrants investigation)
    - All channels ROAS < 0.5x (model may not have enough signal)
    - CI width > 10x the estimate (too uncertain to act on)

    Returns:
        List of warning strings (empty if all checks pass).
    """
    warnings: list[str] = []

    for channel, roas in roas_estimates.items():
        if roas > 20:
            warnings.append(
                f"{channel} ROAS is {roas:.1f}x — unusually high. "
                f"Verify data quality (e.g., double-counted conversions, "
                f"mismatched date ranges)."
            )
        elif roas < 0:
            warnings.append(
                f"{channel} ROAS is negative ({roas:.2f}x). "
                f"This channel may be associated with lower revenue periods. "
                f"Check for confounders or data issues."
            )

    # Check if all channels have very low ROAS
    if roas_estimates and all(v < 0.5 for v in roas_estimates.values()):
        warnings.append(
            "All channels show ROAS below 0.5x. The model may lack "
            "sufficient signal. Consider adding more data or checking "
            "that revenue is correctly attributed."
        )

    # Check for extremely wide CIs
    for channel, (low, high) in roas_ci.items():
        width = high - low
        estimate = roas_estimates.get(channel, 1)
        if estimate > 0 and width > 10 * estimate:
            warnings.append(
                f"{channel} has a very wide confidence interval "
                f"({low:.1f} – {high:.1f}). The estimate is too uncertain "
                f"to act on confidently."
            )

    return warnings


def compute_loo_cv(mmm: MMM, n_data_points: int) -> dict:
    """Compute LOO-CV (Leave-One-Out Cross-Validation) via ArviZ.

    Uses Pareto-Smoothed Importance Sampling LOO (PSIS-LOO) to estimate
    out-of-sample predictive accuracy without refitting the model.

    Interpretation:
    - "good fit": no high-k Pareto warnings, p_loo < 40% of n_data_points
    - "fair fit": some high-k warnings or p_loo is moderate
    - "poor fit": many high-k warnings or p_loo >= 40% of n_data_points

    Args:
        mmm: Fitted MMM model (must have idata with log_likelihood group)
        n_data_points: Number of observations in the dataset

    Returns:
        Dict with elpd_loo, se, p_loo, n_high_k, interpretation, and warnings.
        Returns a dict with an "error" key if LOO-CV cannot be computed.
    """
    idata = mmm.idata

    # Check for log_likelihood group (required by az.loo)
    if not hasattr(idata, "log_likelihood"):
        logger.warning(
            "LOO-CV skipped: InferenceData has no log_likelihood group. "
            "PyMC may need idata_kwargs={'log_likelihood': True} in fit()."
        )
        return {
            "error": "log_likelihood not available in InferenceData. "
            "LOO-CV requires pointwise log-likelihood computation.",
            "interpretation": "unavailable",
        }

    try:
        loo_result = az.loo(idata, pointwise=True)
    except Exception as e:
        logger.warning(f"LOO-CV computation failed: {e}")
        return {
            "error": f"LOO-CV computation failed: {e}",
            "interpretation": "unavailable",
        }

    elpd_loo = float(loo_result.elpd_loo)
    se = float(loo_result.se)
    p_loo = float(loo_result.p_loo)

    # Count high-k Pareto shape parameters (k > 0.7 indicates unreliable estimate)
    pareto_k = loo_result.pareto_k
    if pareto_k is not None:
        k_values = np.asarray(pareto_k)
        n_high_k = int(np.sum(k_values > 0.7))
        n_very_high_k = int(np.sum(k_values > 1.0))
    else:
        k_values = np.array([])
        n_high_k = 0
        n_very_high_k = 0

    # Build warnings list
    warnings = []
    if n_very_high_k > 0:
        warnings.append(
            f"{n_very_high_k} observations have Pareto k > 1.0 (very influential). "
            f"LOO estimates may be unreliable for these points."
        )
    if n_high_k > 0:
        warnings.append(
            f"{n_high_k} of {n_data_points} observations have Pareto k > 0.7 "
            f"(high influence). Consider using k-fold CV for more reliable estimates."
        )

    # Interpret: thresholds for "good", "fair", "poor"
    p_loo_ratio = p_loo / n_data_points if n_data_points > 0 else 1.0
    high_k_ratio = n_high_k / n_data_points if n_data_points > 0 else 0.0

    if n_high_k == 0 and p_loo_ratio < 0.4:
        interpretation = "good"
        interpretation_label = (
            f"Good model fit. ELPD-LOO = {elpd_loo:.1f} (SE = {se:.1f}). "
            f"No problematic observations detected. "
            f"Effective number of parameters (p_loo = {p_loo:.1f}) is reasonable."
        )
    elif high_k_ratio < 0.1 and p_loo_ratio < 0.4:
        interpretation = "fair"
        interpretation_label = (
            f"Fair model fit. ELPD-LOO = {elpd_loo:.1f} (SE = {se:.1f}). "
            f"{n_high_k} observation(s) have high influence (Pareto k > 0.7). "
            f"Results are usable but some data points may be poorly predicted."
        )
    else:
        interpretation = "poor"
        reasons = []
        if high_k_ratio >= 0.1:
            reasons.append(f"{n_high_k} high-influence observations ({high_k_ratio:.0%} of data)")
        if p_loo_ratio >= 0.4:
            reasons.append(
                f"p_loo ({p_loo:.1f}) is {p_loo_ratio:.0%} of data points (possible overfitting)"
            )
        interpretation_label = (
            f"Poor model fit. ELPD-LOO = {elpd_loo:.1f} (SE = {se:.1f}). "
            f"Issues: {'; '.join(reasons)}. "
            f"Consider increasing data, simplifying the model, or checking for outliers."
        )

    for w in warnings:
        logger.warning(f"LOO-CV: {w}")

    logger.info(
        f"LOO-CV complete: interpretation={interpretation}, "
        f"elpd={elpd_loo:.1f}, p_loo={p_loo:.1f}, n_high_k={n_high_k}"
    )

    return {
        "elpd_loo": round(elpd_loo, 2),
        "se": round(se, 2),
        "p_loo": round(p_loo, 2),
        "n_data_points": n_data_points,
        "n_high_k": n_high_k,
        "interpretation": interpretation,
        "interpretation_label": interpretation_label,
        "warnings": warnings,
    }


def extract_intercept(mmm: MMM, n_data_points: int) -> dict:
    """Extract the model intercept and decompose it as baseline/organic revenue.

    The intercept represents revenue that would occur with zero ad spend across
    all channels. This is the "organic" or "baseline" revenue from brand equity,
    direct traffic, SEO, word-of-mouth, etc.

    Math:
    - Weekly organic revenue = posterior mean of intercept
    - Annualized organic revenue = intercept * 52 (assuming weekly data)
    - Organic share = intercept * n_weeks / total_revenue (approximate)

    Args:
        mmm: Fitted MMM model
        n_data_points: Number of time periods (weeks) in the data

    Returns:
        Dict with weekly and annualized organic revenue estimates + CI.
    """
    posterior = mmm.idata.posterior

    # The intercept variable name in PyMC-Marketing MMM
    intercept_var = "intercept"
    if intercept_var not in posterior:
        # Try alternative names
        for alt in ["Intercept", "mu_intercept", "baseline"]:
            if alt in posterior:
                intercept_var = alt
                break
        else:
            logger.warning(
                "Could not find intercept variable in posterior. "
                f"Available variables: {list(posterior.data_vars)}"
            )
            return {
                "error": "Intercept variable not found in model posterior.",
                "interpretation": "unavailable",
            }

    try:
        intercept_samples = posterior[intercept_var].values.flatten()

        weekly_mean = float(np.mean(intercept_samples))
        weekly_ci = (
            float(np.percentile(intercept_samples, 5)),
            float(np.percentile(intercept_samples, 95)),
        )

        annualized_mean = weekly_mean * 52
        annualized_ci = (weekly_ci[0] * 52, weekly_ci[1] * 52)

        # Total organic revenue over the data period
        period_total = weekly_mean * n_data_points

        label = (
            f"Estimated organic/baseline revenue: ${weekly_mean:,.0f}/week "
            f"(${annualized_mean:,.0f}/year). "
            f"This is revenue attributable to brand, SEO, direct traffic, and other "
            f"non-paid sources — what you would earn with zero ad spend."
        )

        logger.info(
            f"Intercept decomposition: weekly=${weekly_mean:,.0f}, "
            f"annualized=${annualized_mean:,.0f}"
        )

        return {
            "weekly_organic_revenue": round(weekly_mean, 2),
            "weekly_ci": {"low": round(weekly_ci[0], 2), "high": round(weekly_ci[1], 2)},
            "annualized_organic_revenue": round(annualized_mean, 2),
            "annualized_ci": {
                "low": round(annualized_ci[0], 2),
                "high": round(annualized_ci[1], 2),
            },
            "period_total": round(period_total, 2),
            "n_weeks_in_data": n_data_points,
            "label": label,
        }
    except Exception as e:
        logger.warning(f"Intercept decomposition failed: {e}")
        return {
            "error": f"Intercept decomposition failed: {e}",
            "interpretation": "unavailable",
        }


def run_full_pipeline(
    X: pd.DataFrame,
    y: pd.Series,
    channel_columns: list[str],
    mcmc_config: dict | None = None,
    adstock_l_max: int = 8,
    reporter: "ProgressReporter | None" = None,
) -> ModelResults:
    """Run the complete modeling pipeline: build -> fit -> extract.

    Args:
        X: Feature DataFrame
        y: Target series
        channel_columns: Channel spend column names
        mcmc_config: Optional MCMC overrides
        adstock_l_max: Max adstock lag
        reporter: Optional ProgressReporter for live MCP progress notifications.
                  When None (default), the pipeline runs identically to before.

    Returns:
        ModelResults with all extracted information
    """
    def _report(name: str, progress: float | None = None, total: float | None = None) -> None:
        if reporter is not None:
            reporter.phase(name, progress=progress, total=total)

    start = time.time()

    _report("Building Bayesian model", progress=1, total=8)
    mmm = build_model(channel_columns, adstock_l_max=adstock_l_max)

    _report("Compiling model (JIT)", progress=2, total=8)
    try:
        mmm, pp_warning = fit_model(mmm, X, y, mcmc_config, reporter=reporter)
    except Exception:
        _report("Failed during MCMC sampling")
        raise

    _report("Computing posterior estimates", progress=6, total=8)

    # Check convergence (R-hat, ESS, divergences)
    convergence_warnings = check_convergence(mmm)

    _report("Generating ROAS + recommendations", progress=7, total=8)

    # Compute contributions once (expensive posterior operation) and reuse
    raw_contributions = mmm.compute_channel_contribution_original_scale()

    contributions, contributions_ci = extract_channel_contributions(
        mmm, X, channel_columns, contributions=raw_contributions
    )
    roas, roas_ci = extract_roas(mmm, X, channel_columns, contributions=raw_contributions)
    marginal_roas, marginal_roas_ci = extract_marginal_roas(mmm, X, channel_columns)

    # ROAS plausibility checks
    roas_warnings = check_roas_plausibility(roas, roas_ci)
    convergence_warnings.extend(roas_warnings)

    total_spend = {}
    for channel in channel_columns:
        display_name = format_channel_name(channel)
        total_spend[display_name] = float(X[channel].sum())

    # LOO-CV: out-of-sample predictive accuracy (best-effort, non-blocking)
    n_data_points = len(X)
    loo_cv = compute_loo_cv(mmm, n_data_points)

    # Intercept decomposition: baseline/organic revenue
    intercept = extract_intercept(mmm, n_data_points)

    duration = time.time() - start

    _report("Done", progress=8, total=8)

    return ModelResults(
        channel_contributions=contributions,
        channel_contributions_ci=contributions_ci,
        roas_estimates=roas,
        roas_ci=roas_ci,
        marginal_roas_estimates=marginal_roas,
        marginal_roas_ci=marginal_roas_ci,
        total_spend=total_spend,
        duration_secs=duration,
        mmm=mmm,
        convergence_warnings=convergence_warnings,
        posterior_predictive_warning=pp_warning,
        raw_contributions=raw_contributions,
        loo_cv=loo_cv,
        intercept_decomposition=intercept,
    )
