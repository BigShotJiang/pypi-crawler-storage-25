"""Compute platform self-reported vs MMM-measured ROAS comparison (N9)."""

from __future__ import annotations


def compute_platform_comparison(
    mmm_roas: dict[str, float],
    mmm_ci: dict[str, tuple[float, float]],
    spend_by_channel: dict[str, float],
    platform_roas: dict[str, float] | None = None,
    platform_revenue: dict[str, float] | None = None,
) -> dict:
    """Compare platform-self-reported ROAS to MMM-measured ROAS.

    If both platform_roas and platform_revenue are passed, platform_roas wins
    (explicit beats derived). If neither, returns empty dict (feature disabled).

    Args:
        mmm_roas: Channel -> MMM-estimated ROAS.
        mmm_ci: Channel -> (ci_low, ci_high) credible interval tuple.
        spend_by_channel: Channel -> total spend (all channels, used for filter).
        platform_roas: Optional explicit platform-reported ROAS per channel.
        platform_revenue: Optional platform-reported revenue per channel; used
            to derive ROAS when platform_roas is not supplied.

    Returns:
        Comparison dict with "source", "channels", "summary", "excluded_channels"
        keys, or empty dict when no platform data is provided.
    """
    # Rule 4: neither provided -> feature disabled
    if platform_roas is None and platform_revenue is None:
        return {}

    # --- Resolve source and effective platform ROAS ---------------------------
    if platform_roas is not None:
        source = "mcp_argument"
        # Per-channel revenue available only when both dicts are passed
        eff_platform_revenue: dict[str, float | None] = {}
        if platform_revenue is not None:
            eff_platform_revenue = dict(platform_revenue)
        # Keys driven by platform_roas
        platform_keys = set(platform_roas.keys())
    else:
        # Only platform_revenue supplied
        source = "csv_revenue_column"
        eff_platform_revenue = dict(platform_revenue)  # type: ignore[arg-type]
        platform_keys = set(platform_revenue.keys())  # type: ignore[union-attr]

    # --- Small-channel filter --------------------------------------------------
    total_spend = sum(spend_by_channel.values())
    threshold = 0.02 * total_spend if total_spend > 0 else 0.0

    excluded: list[dict] = []

    # Channels we will attempt to process (from platform input)
    channels_out: dict[str, dict] = {}

    for ch in platform_keys:
        spend = spend_by_channel.get(ch, 0.0)

        # Zero spend
        if spend == 0.0:
            excluded.append({"channel": ch, "reason": "zero_spend"})
            continue

        # Small channel
        spend_pct = spend / total_spend if total_spend > 0 else 0.0
        if spend < threshold:
            excluded.append(
                {
                    "channel": ch,
                    "reason": "insufficient_spend",
                    "spend_pct": round(spend_pct, 6),
                }
            )
            continue

        # Resolve effective platform ROAS for this channel
        if source == "mcp_argument":
            eff_roas = platform_roas[ch]  # type: ignore[index]
            ch_platform_revenue: float | None = eff_platform_revenue.get(ch)
        else:
            # derive from revenue / spend (spend != 0 guaranteed above)
            rev = eff_platform_revenue.get(ch)
            if rev is None:
                # Can't derive ROAS without revenue; treat as zero_spend-like
                excluded.append({"channel": ch, "reason": "zero_spend"})
                continue
            eff_roas = rev / spend
            ch_platform_revenue = rev

        # Negative / zero platform ROAS
        if eff_roas <= 0:
            excluded.append({"channel": ch, "reason": "negative_platform_roas"})
            continue

        # Must be in MMM
        if ch not in mmm_roas:
            excluded.append({"channel": ch, "reason": "not_in_mmm"})
            continue

        ch_mmm_roas = mmm_roas[ch]
        ci_low, ci_high = mmm_ci.get(ch, (0.0, 0.0))

        # --- Verdict ----------------------------------------------------------
        if ch_mmm_roas == 0 or ch_mmm_roas is None:
            verdict = "unmeasured"
        elif eff_roas > ci_high:
            verdict = "over_claiming"
        elif eff_roas < ci_low:
            verdict = "under_claiming"
        else:
            verdict = "aligned"

        # --- Gap pct ----------------------------------------------------------
        # Stored value: signed (mmm - plat) / plat; negative when over-claiming.
        # Spec example: plat=3.20, mmm=1.05 → (1.05-3.20)/3.20 = -0.672.
        mmm_roas_val = ch_mmm_roas if ch_mmm_roas is not None else 0.0
        if eff_roas != 0:
            gap_pct = (mmm_roas_val - eff_roas) / eff_roas
        else:
            gap_pct = 0.0

        # Severity uses (plat - mmm) / mmm — the "over-claim relative to MMM baseline"
        # which can exceed 100% (e.g. plat=3.20, mmm=1.05 → 204% over-claim).
        # This is the natural measure for how wrong the platform is.
        if mmm_roas_val != 0:
            severity_gap = (eff_roas - mmm_roas_val) / mmm_roas_val
        else:
            severity_gap = 0.0

        # --- Severity ---------------------------------------------------------
        severity: str | None = None
        if verdict == "over_claiming":
            abs_gap = abs(severity_gap)
            if abs_gap >= 1.0:
                severity = "extreme"
            elif abs_gap >= 0.4:
                severity = "severe"
            elif abs_gap >= 0.2:
                severity = "significant"
            elif abs_gap >= 0.1:
                severity = "modest"

        # --- Confidence -------------------------------------------------------
        if ch_mmm_roas == 0 or ch_mmm_roas is None:
            confidence = "low"
        else:
            ci_width_ratio = (ci_high - ci_low) / ch_mmm_roas
            if ci_width_ratio < 0.3:
                confidence = "high"
            elif ci_width_ratio < 0.6:
                confidence = "medium"
            else:
                confidence = "low"

        # --- One-liner --------------------------------------------------------
        if verdict == "unmeasured":
            one_liner = f"{ch}: MixLift could not measure ROAS."
        else:
            abs_gap_pct_display = abs(gap_pct) * 100
            one_liner = (
                f"{ch} claims {eff_roas:.2f}\u00d7 ROAS; "
                f"MixLift measures {ch_mmm_roas:.2f}\u00d7 "
                f"(CI {ci_low:.2f}\u2013{ci_high:.2f}\u00d7). "
                f"Gap {abs_gap_pct_display:.0f}%."
            )

        channels_out[ch] = {
            "platform_roas": eff_roas,
            "platform_revenue": ch_platform_revenue,
            "mmm_roas": ch_mmm_roas,
            "mmm_roas_ci_low": ci_low,
            "mmm_roas_ci_high": ci_high,
            "spend": spend,
            "gap_pct": gap_pct,
            "verdict": verdict,
            "severity": severity,
            "confidence": confidence,
            "one_liner": one_liner,
        }

    # Channels in MMM but absent from platform input: include only if
    # mmm_roas == 0 or None (unmeasured); otherwise silently skip.
    for ch, ch_mmm_roas in mmm_roas.items():
        if ch in channels_out:
            continue  # already processed
        if ch in platform_keys:
            continue  # was excluded above; don't double-add
        if ch_mmm_roas == 0 or ch_mmm_roas is None:
            # Include as unmeasured
            spend = spend_by_channel.get(ch, 0.0)
            ci_low, ci_high = mmm_ci.get(ch, (0.0, 0.0))
            channels_out[ch] = {
                "platform_roas": None,
                "platform_revenue": None,
                "mmm_roas": ch_mmm_roas,
                "mmm_roas_ci_low": ci_low,
                "mmm_roas_ci_high": ci_high,
                "spend": spend,
                "gap_pct": 0.0,
                "verdict": "unmeasured",
                "severity": None,
                "confidence": "low",
                "one_liner": f"{ch}: MixLift could not measure ROAS.",
            }
        # else: silently skip (brief: "simply not included")

    # --- Summary --------------------------------------------------------------
    over_claiming = [ch for ch, d in channels_out.items() if d["verdict"] == "over_claiming"]
    aligned = [ch for ch, d in channels_out.items() if d["verdict"] == "aligned"]
    under_claiming = [ch for ch, d in channels_out.items() if d["verdict"] == "under_claiming"]

    most_egregious: dict | None = None
    if over_claiming:
        worst_ch = max(over_claiming, key=lambda c: abs(channels_out[c]["gap_pct"]))
        most_egregious = {"channel": worst_ch, "gap_pct": channels_out[worst_ch]["gap_pct"]}

    total_mmm_revenue = sum(
        (d["mmm_roas"] or 0.0) * d["spend"] for d in channels_out.values()
    )

    # platform_revenue totals: None if any included channel lacks it
    all_rev = [d["platform_revenue"] for d in channels_out.values() if d["verdict"] != "unmeasured"]
    if all_rev and all(r is not None for r in all_rev):
        total_platform_revenue: float | None = sum(all_rev)  # type: ignore[arg-type]
        phantom_revenue_pct: float | None = (
            (total_platform_revenue - total_mmm_revenue) / total_platform_revenue
            if total_platform_revenue > 0
            else None
        )
    else:
        total_platform_revenue = None
        phantom_revenue_pct = None

    summary = {
        "channels_over_claiming": over_claiming,
        "channels_aligned": aligned,
        "channels_under_claiming": under_claiming,
        "most_egregious": most_egregious,
        "total_platform_revenue": total_platform_revenue,
        "total_mmm_revenue": total_mmm_revenue,
        "phantom_revenue_pct": phantom_revenue_pct,
    }

    return {
        "source": source,
        "channels": channels_out,
        "summary": summary,
        "excluded_channels": excluded,
    }
