"""MixLift MCP Server — Marketing Mix Modeling for AI assistants.

Provides a single tool `mixlift_analyze` that runs full Bayesian MMM analysis
on marketing CSV data and returns ROAS, budget optimization, and saturation curves.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any

import pandas as pd
from mcp.server.fastmcp import Context, FastMCP

from mixlift_mcp.analytics import maybe_fire_first_analyze
from mixlift_mcp.license import LicenseStatus, free_tier, validate_license
from mixlift_mcp.renderers.analyze_memo import render_analyze_memo
from mixlift_mcp.renderers.forecast_memo import render_forecast_memo
from mixlift_mcp.renderers.scenario_memo import render_scenario_memo

logger = logging.getLogger(__name__)

DEMO_CSV_PATH = Path(__file__).parent / "data" / "demo.csv"

mcp = FastMCP("mixlift")


# ---------------------------------------------------------------------------
# OAuth helpers — bearer-token path (Day 4)
# ---------------------------------------------------------------------------


def _extract_access_token() -> "MixLiftAccessToken | None":  # type: ignore[name-defined]  # noqa: F821
    """Return the validated ``MixLiftAccessToken`` for the current request, or None.

    FastMCP's ``AuthContextMiddleware`` stores the authenticated user in a
    ``contextvars.ContextVar`` (``auth_context_var``).  The public helper
    ``get_access_token()`` reads that contextvar and returns the ``AccessToken``
    (or ``None`` when no bearer token was presented / validated).

    This function is a thin wrapper that avoids importing auth internals at
    module load time (import is deferred so the local pip-install path — which
    never has ``OAUTH_ENABLED=true`` — doesn't pay the import cost).
    """
    try:
        from mcp.server.auth.middleware.auth_context import get_access_token

        return get_access_token()  # type: ignore[return-value]
    except Exception:
        return None


async def _resolve_license(
    license_key: str,
    ctx: "Context | None" = None,  # noqa: ARG001  # kept for call-site readability
) -> LicenseStatus:
    """Resolve tier + license from an OAuth bearer token or the legacy ``license_key`` param.

    Priority:
    1. Validated bearer token in current request context (OAuth path).
    2. ``license_key`` tool parameter (legacy pip-install / Claude Desktop path).
    3. Unauthenticated → free tier.

    The ``ctx`` parameter is accepted for call-site readability (mirrors the
    existing ``ctx: Context | None`` pattern in tool handlers) but is not used
    — token extraction reads the contextvar directly, which is always available
    when called from inside a tool handler regardless of whether ``ctx`` was
    injected.
    """
    access_token = _extract_access_token()
    if access_token is not None:
        extra = getattr(access_token, "extra", {}) or {}
        tier = extra.get("tier", "free")
        if tier in ("pro", "growth"):
            return LicenseStatus(
                is_pro=True,
                max_channels=8,
                max_rows=50_000,
                message="authenticated via OAuth bearer token",
            )
        # Bearer token present but free tier → fall through to free
        return free_tier("OAuth bearer token: free tier")

    # Fallback: legacy license_key param
    return await validate_license(license_key if license_key else None)


# ---------------------------------------------------------------------------
# MCP resource: monthly refresh reminder (N8)
# ---------------------------------------------------------------------------


@mcp.resource("mixlift://status")
def mixlift_status() -> str:
    """Check if any MixLift analyses are due for a monthly refresh.

    Returns a plain-text status summary. Claude should surface this
    proactively when the user starts a conversation with MixLift active.
    """
    try:
        from mixlift_mcp.memory import check_stale_analyses

        stale = check_stale_analyses(max_age_days=30)
        if not stale:
            return "All MixLift analyses are up to date."

        lines = [f"**{len(stale)} dataset(s) due for re-analysis:**\n"]
        for s in stale:
            channels = ", ".join(s["channels"][:4])
            lines.append(
                f"- **{s['dataset']}** — last run {s['last_run']} "
                f"({s['age_days']} days ago). Channels: {channels}"
            )
        lines.append(
            "\nRe-running with fresh data captures seasonal shifts and "
            "budget changes. Ask the user if they'd like to refresh."
        )
        return "\n".join(lines)
    except Exception:
        return "MixLift status unavailable."


# ---------------------------------------------------------------------------
# Model cache — persists fitted models within an MCP session for forecast/reuse
# ---------------------------------------------------------------------------

_MODEL_CACHE: dict[str, dict] = {}
# fingerprint -> {"mmm": MMM, "X": DataFrame, "channel_columns": list,
#                 "model_results": ModelResults, "result": dict}

# ---------------------------------------------------------------------------
# Path validation guardrails
# ---------------------------------------------------------------------------

#: File extensions that are allowed as CSV inputs.
_ALLOWED_EXTENSIONS = {".csv", ".tsv", ".txt"}

#: Path components that indicate sensitive locations. Checked against every
#: part of the resolved path (case-insensitive) so that tricks like
#: ``../../.ssh/id_rsa`` are caught after resolution.
_BLOCKED_PATH_FRAGMENTS = {
    ".ssh",
    ".env",
    ".git",
    "credentials",
    "secrets",
    ".aws",
    ".config",
    ".gnupg",
    ".gpg",
    "keychain",
    "id_rsa",
    "id_ed25519",
    "id_ecdsa",
    "id_dsa",
    "authorized_keys",
    "known_hosts",
}


def _validate_csv_path(csv_path: str) -> tuple[Path, str | None]:
    """Validate and resolve a user-supplied CSV path.

    Returns ``(resolved_path, None)`` on success, or ``(Path(), error_message)``
    on failure.

    Guardrails applied (in order):
    1. Extension must be in ``_ALLOWED_EXTENSIONS``.
    2. Resolved absolute path must not contain any ``_BLOCKED_PATH_FRAGMENTS``.
    3. If the environment variable ``MIXLIFT_ALLOWED_DIRS`` is set (colon-separated
       list of directories), the resolved path must fall within one of them.
    """
    resolved = Path(csv_path).expanduser().resolve()

    # 1. Extension check
    if resolved.suffix.lower() not in _ALLOWED_EXTENSIONS:
        return Path(), (
            f"Invalid file extension '{resolved.suffix}'. "
            f"Only {', '.join(sorted(_ALLOWED_EXTENSIONS))} files are allowed."
        )

    # 2. Sensitive-path check — inspect every part of the resolved path
    path_str_lower = str(resolved).lower()
    for fragment in _BLOCKED_PATH_FRAGMENTS:
        if fragment in path_str_lower:
            logger.warning("Blocked sensitive path access attempt: %s", resolved)
            return Path(), (
                f"Access denied: the path contains a restricted component ('{fragment}'). "
                "Please use a file outside sensitive system directories."
            )

    # 3. Allowed-directories check (opt-in via environment variable)
    allowed_dirs_env = os.environ.get("MIXLIFT_ALLOWED_DIRS", "").strip()
    if allowed_dirs_env:
        allowed_dirs = [
            Path(d).expanduser().resolve() for d in allowed_dirs_env.split(":") if d.strip()
        ]
        if not any(resolved == allowed or allowed in resolved.parents for allowed in allowed_dirs):
            allowed_display = ", ".join(str(d) for d in allowed_dirs)
            logger.warning(
                "Blocked path outside allowed directories: %s (allowed: %s)",
                resolved,
                allowed_display,
            )
            return Path(), (
                f"Access denied: '{resolved}' is not inside an allowed directory. "
                f"Allowed directories: {allowed_display}"
            )

    logger.info("Resolved CSV path: %s", resolved)
    return resolved, None


# ---------------------------------------------------------------------------
# CSV loading helpers — canonical implementations live in mixlift.ingest.loader;
# private aliases kept here for backward compatibility within the MCP server.
# ---------------------------------------------------------------------------
from mixlift.ingest.loader import (
    detect_csv_format as _detect_csv_format,
    validate_wide_format as _validate_wide_format,
    check_date_range_warnings as _check_date_range_warnings,
    load_wide_format as _load_wide_format,
    load_platform_csv as _load_platform_csv,
)


def _enforce_tier_limits(
    license_status: LicenseStatus,
    n_channels: int,
    n_rows: int,
) -> list[str]:
    """Raise ValueError if data exceeds tier limits.

    Returns a list of warning strings (e.g. high channel count for Pro tier).
    """
    tier_name = "Pro" if license_status.is_pro else "Free"
    warnings: list[str] = []

    if n_channels > license_status.max_channels:
        raise ValueError(
            f"{tier_name} tier allows up to {license_status.max_channels} channels, "
            f"but your data has {n_channels}. "
            f"Upgrade to Growth ($299/mo) at https://mixlift.io/pricing"
        )
    if n_rows > license_status.max_rows:
        raise ValueError(
            f"{tier_name} tier allows up to {license_status.max_rows} rows, "
            f"but your data has {n_rows}. "
            f"Upgrade to Growth ($299/mo) at https://mixlift.io/pricing"
        )

    # A4: Soft warning for Pro tier with many channels
    if n_channels > 15:
        msg = (
            f"Your data has {n_channels} channels. Models with >15 channels "
            f"may produce less precise estimates with default MCMC settings. "
            f"Consider increasing draws/tune for better posterior quality."
        )
        logger.warning(msg)
        warnings.append(msg)

    return warnings


def _compute_saturation_traffic_lights(
    saturation_curves: dict,
    optimization: dict,
) -> dict:
    """Compute per-channel saturation percentage and traffic light status.

    Uses the saturation curve: at current spend, how far along the curve are we?
    - Green (< 50%): Room to scale
    - Yellow (50-75%): Approaching saturation
    - Red (> 75%): Diminishing returns
    """
    lights = {}
    current = optimization.get("current_allocation", {})

    for channel, curve_data in saturation_curves.items():
        spend_points = curve_data.get("spend", [])
        response_points = curve_data.get("response", [])
        if not spend_points or not response_points:
            continue

        current_spend = current.get(channel, 0)
        max_response = max(response_points) if response_points else 1.0

        # Find response at current spend by interpolation
        import bisect

        idx = bisect.bisect_left(spend_points, current_spend)
        if idx >= len(response_points):
            current_response = response_points[-1]
        elif idx == 0:
            current_response = response_points[0]
        else:
            # Linear interpolation
            x0, x1 = spend_points[idx - 1], spend_points[idx]
            y0, y1 = response_points[idx - 1], response_points[idx]
            t = (current_spend - x0) / (x1 - x0) if x1 != x0 else 0
            current_response = y0 + t * (y1 - y0)

        saturation_pct = (
            round((current_response / max_response) * 100, 0) if max_response > 0 else 0
        )

        if saturation_pct < 50:
            status = "green"
            label = f"{channel} has {100 - saturation_pct:.0f}% headroom (room to scale)"
        elif saturation_pct < 75:
            status = "yellow"
            label = (
                f"{channel} is {saturation_pct:.0f}% saturated (approaching diminishing returns)"
            )
        else:
            status = "red"
            label = f"{channel} is {saturation_pct:.0f}% saturated (diminishing returns)"

        lights[channel] = {
            "saturation_pct": saturation_pct,
            "status": status,
            "label": label,
        }

    return lights


def _redact_dollars(text: str) -> str:
    """Strip dollar amounts from text for free-tier output."""
    import re

    return re.sub(r"\$[\d,]+(?:\.\d+)?(?:/week)?", "$XXX", text)


def _gate_channel_contributions(
    contributions: dict[str, float],
    contributions_ci: dict[str, tuple[float, float]],
    is_paid: bool,
) -> dict:
    """Gate channel contributions: dollar amounts for paid, percentages for free."""
    if is_paid:
        return {
            "estimates": contributions,
            "confidence_intervals": {
                k: {"low": v[0], "high": v[1]} for k, v in contributions_ci.items()
            },
        }

    # Free tier: convert to percentage shares (no dollar values)
    total = sum(contributions.values()) or 1.0
    return {
        "estimates": {k: round(v / total * 100, 1) for k, v in contributions.items()},
        "unit": "percent",
        "note": "Dollar values available on Growth plan ($299/mo). Showing contribution share (%).",
        "confidence_intervals": {
            k: {
                "low": round(v[0] / total * 100, 1),
                "high": round(v[1] / total * 100, 1),
            }
            for k, v in contributions_ci.items()
        },
    }


def _compute_dollar_headline(optimization: dict) -> dict:
    """Compute the dollar-value headline from budget optimization results.

    Returns headline data. Dollar values only shown to paid tier.
    """
    current = optimization.get("current_allocation", {})
    optimal = optimization.get("optimal_allocation", {})
    lift_pct = optimization.get("expected_lift_pct", 0)
    total_budget = optimization.get("total_budget", 0)

    # Total dollar opportunity = lift percentage applied to total budget
    dollar_opportunity = round(total_budget * abs(lift_pct) / 100, 0)

    # Per-channel reallocation in dollars and percentages
    reallocations = []
    for channel in current:
        curr = current.get(channel, 0)
        opt = optimal.get(channel, 0)
        delta = opt - curr
        if abs(delta) > 1:  # Ignore trivial changes
            pct_change = round((delta / curr) * 100, 1) if curr > 0 else 0
            action = "Increase" if delta > 0 else "Decrease"
            reallocations.append(
                {
                    "channel": channel,
                    "action": action,
                    "current_spend": round(curr, 0),
                    "optimal_spend": round(opt, 0),
                    "change_dollars": round(abs(delta), 0),
                    "change_pct": abs(pct_change),
                    "label": f"{action} {channel} by ${abs(delta):,.0f}/week ({abs(pct_change):.0f}%)",
                }
            )

    reallocations.sort(key=lambda x: x["change_dollars"], reverse=True)

    return {
        "dollar_opportunity": dollar_opportunity,
        "lift_pct": lift_pct,
        "headline": f"MixLift found ${dollar_opportunity:,.0f}/week in budget optimization opportunity ({lift_pct:+.1f}% expected lift)",
        "reallocations": reallocations,
    }


def _compute_confidence_summary(model_results) -> dict:
    """Generate plain-English confidence summary."""
    ci_widths = {}
    for channel, ci in model_results.roas_ci.items():
        width = ci[1] - ci[0]
        mean = model_results.roas_estimates.get(channel, 1)
        relative_width = width / mean if mean > 0 else float("inf")
        ci_widths[channel] = relative_width

    summaries = {}
    for channel, rel_width in ci_widths.items():
        if rel_width < 0.5:
            summaries[channel] = {
                "confidence": "high",
                "label": f"{channel}: High confidence (tight uncertainty bounds)",
            }
        elif rel_width < 1.0:
            summaries[channel] = {
                "confidence": "moderate",
                "label": f"{channel}: Moderate confidence (consider more data for precision)",
            }
        else:
            summaries[channel] = {
                "confidence": "low",
                "label": f"{channel}: Use with caution (wide uncertainty — more data recommended)",
            }

    return summaries


def _compute_model_fit(model_results) -> dict:
    """Compute model fit summary: R-squared and MAPE equivalent."""
    import numpy as np

    try:
        mmm = model_results.mmm
        idata = mmm.idata

        # Posterior predictive mean
        if hasattr(idata, "posterior_predictive"):
            pp = idata.posterior_predictive
            # Get the target variable name
            var_names = list(pp.data_vars)
            if var_names:
                y_pred = pp[var_names[0]].mean(dim=["chain", "draw"]).values
                y_actual = mmm.y.values if hasattr(mmm, "y") else None

                if y_actual is not None and len(y_pred) == len(y_actual):
                    ss_res = np.sum((y_actual - y_pred) ** 2)
                    ss_tot = np.sum((y_actual - np.mean(y_actual)) ** 2)
                    r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0

                    mape = (
                        np.mean(np.abs((y_actual - y_pred) / y_actual)) * 100
                        if np.all(y_actual != 0)
                        else None
                    )

                    r2_pct = round(r_squared * 100, 0)
                    return {
                        "r_squared": round(r_squared, 3),
                        "mape": round(mape, 1) if mape is not None else None,
                        "label": f"This model explains {r2_pct:.0f}% of your revenue variation.",
                    }
    except Exception:
        pass

    return {"label": "Model fit metrics not available for this run."}


def _safe_render_analyze_memo(result: dict) -> str:
    try:
        return render_analyze_memo(result)
    except Exception as exc:
        logger.warning("render_analyze_memo failed: %s", exc)
        return ""


def _build_tiered_response(result: dict) -> dict:
    """Build a tiered response for Claude: summary + structured_data.

    The summary tier (~2-4K chars) contains everything Claude needs to
    start an intelligent conversation. The structured_data tier contains
    full details Claude can reference on demand.
    """
    # Strip internal private keys before returning to the user.
    result.pop("_spend_by_channel", None)

    roas = result.get("roas", {})
    roas_estimates = roas.get("estimates", {})
    saturation = result.get("saturation_analysis", {})
    confidence = result.get("confidence_summary", {})
    budget_opt = result.get("budget_optimization", {})
    recommendations = result.get("recommendations", {})
    actions = recommendations.get("actions", [])
    backtest = result.get("backtest", {})

    # Build per-channel overview for summary (condensed)
    channel_overview = {}
    for ch in result.get("data", {}).get("channels", []):
        entry: dict = {}
        if ch in roas_estimates:
            entry["roas"] = round(roas_estimates[ch], 2)
        sat_info = saturation.get(ch, {})
        if sat_info:
            entry["saturation"] = sat_info.get("status", "unknown")
        conf_info = confidence.get(ch, {})
        if conf_info:
            entry["confidence"] = conf_info.get("confidence", "unknown")
        channel_overview[ch] = entry

    return {
        "status": result.get("status", "success"),
        "model_fingerprint": result.get("model_fingerprint", ""),
        "summary": {
            "headline": result.get("headline", ""),
            "readout_markdown": _safe_render_analyze_memo(result),
            "top_actions": actions[:3],
            "channel_overview": channel_overview,
            "model_fit": result.get("model_fit", {}),
            "expected_lift_pct": budget_opt.get("expected_lift_pct", 0),
            "total_budget": budget_opt.get("total_budget", 0),
            "n_channels": result.get("data", {}).get("n_channels", 0),
            "data_weeks": result.get("model_info", {}).get("data_window", {}).get("weeks"),
            "analysis_badge": result.get("analysis_badge"),
            "memory": result.get("memory"),
            "is_cache_hit": result.get("is_cache_hit", False),
            "cache_age_days": result.get("cache_age_days"),
            "backtest_mape": backtest.get("aggregate", {}).get("mape_mean"),
            "backtest_interpretation": backtest.get("aggregate", {}).get("interpretation"),
            "next_actions": [
                {
                    "tool": "mixlift_scenario",
                    "description": "Test a what-if budget change (e.g., 'cut Meta by 20%')",
                    "params": {"model_fingerprint": result.get("model_fingerprint", "")},
                },
                {
                    "tool": "mixlift_forecast",
                    "description": "Project revenue over next 12 weeks (current vs optimized)",
                    "params": {"model_fingerprint": result.get("model_fingerprint", "")},
                },
                {
                    "tool": "mixlift_readout",
                    "description": "Generate executive deliverables (budget memo, scorecard)",
                    "params": {"model_fingerprint": result.get("model_fingerprint", "")},
                },
            ],
            "intake_questions": [
                "What budget decision are you trying to make right now?",
                "Which channel is your biggest bet — and are you confident in it?",
                "Are you looking to scale up spend or find waste to cut?",
            ],
        },
        "structured_data": {
            "roas": roas,
            "saturation_analysis": saturation,
            "budget_optimization": budget_opt,
            "channel_contributions": result.get("channel_contributions", {}),
            "marginal_roas": result.get("marginal_roas", {}),
            "recommendations": recommendations,
            "confidence_summary": confidence,
            "scenario": result.get("scenario"),
            "platform_attribution_comparison": result.get("platform_attribution_comparison"),
            "backtest": backtest,
        },
        "license": result.get("license", {}),
        "model_info": result.get("model_info", {}),
        "data": result.get("data", {}),
    }


def _gate_backtest_for_tier(backtest: dict, is_paid: bool) -> dict:
    """Strip per-fold details and coverage from backtest for free tier.

    Free tier sees: mode, status, aggregate.mape_mean, aggregate.interpretation,
                    aggregate.interpretation_label, note, n_folds, horizon_weeks.
    Free tier does NOT see: per-fold weekly revenue arrays, coverage_80 (bayesian
    sophistication is a paid signal), r_squared_mean, compute_secs.
    """
    if is_paid:
        return backtest
    if not backtest:
        return backtest

    gated = {**backtest}
    # Strip per-fold weekly arrays (contain dollar values)
    if "folds" in gated:
        gated["folds"] = [
            {
                "fold": f.get("fold"),
                "test_start": f.get("test_start"),
                "test_end": f.get("test_end"),
                "mape": f.get("mape"),
                # NO weekly_actual, weekly_predicted_*, coverage_80, r_squared
            }
            for f in gated["folds"]
        ]
    # Strip coverage and r_squared from aggregate
    if "aggregate" in gated:
        agg = {**gated["aggregate"]}
        agg.pop("coverage_80_mean", None)
        agg.pop("r_squared_mean", None)
        gated["aggregate"] = agg
    return gated


def _gate_platform_comparison_for_tier(comparison: dict, is_paid: bool) -> dict:
    """Strip dollar values from platform comparison for free tier.

    Percentages and ROAS multiples remain visible (the viral artifact).
    Dollar amounts in platform_revenue and total_*_revenue are replaced with
    an upgrade prompt.
    """
    if is_paid:
        return comparison

    upgrade_str = "Upgrade to Growth ($299/mo) to see dollar amounts"
    gated = {**comparison}

    # Strip per-channel platform_revenue
    if "channels" in gated:
        gated["channels"] = {
            ch: {**data, "platform_revenue": None} for ch, data in gated["channels"].items()
        }

    # Strip total_*_revenue from summary
    if "summary" in gated:
        summary = {**gated["summary"]}
        if summary.get("total_platform_revenue") is not None:
            summary["total_platform_revenue"] = upgrade_str
        if summary.get("total_mmm_revenue") is not None:
            summary["total_mmm_revenue"] = upgrade_str
        gated["summary"] = summary

    return gated


def _has_detectable_platform_revenue(df: "pd.DataFrame") -> bool:
    """Return True if the DataFrame contains any auto-detectable platform revenue columns."""
    from mixlift.ingest.platform_revenue import detect_platform_revenue_columns

    return bool(detect_platform_revenue_columns(df))


def _add_platform_comparison(
    result: dict,
    df: "pd.DataFrame",
    platform_reported_roas: "dict[str, float] | None",
    is_paid: bool,
) -> dict:
    """Compute and attach platform_attribution_comparison to a result dict (post-hoc).

    Safe to call on a cached result — does not re-run MCMC.
    Returns result with platform_attribution_comparison set (or unchanged on error).
    """
    try:
        from mixlift.modeling.platform_attribution import compute_platform_comparison

        mmm_roas_estimates = result.get("roas", {}).get("estimates", {})
        mmm_ci_raw = result.get("roas", {}).get("confidence_intervals", {})
        mmm_ci = {
            ch: (ci.get("low"), ci.get("high"))
            for ch, ci in mmm_ci_raw.items()
            if ci.get("low") is not None and ci.get("high") is not None
        }

        # Spend by channel — prefer the private pre-redaction copy so free-tier
        # users still get the gap-% table even after current_allocation is replaced.
        if "_spend_by_channel" in result:
            spend_by_channel: dict[str, float] = result["_spend_by_channel"]
        else:
            budget_opt = result.get("budget_optimization", {})
            current_alloc = budget_opt.get("current_allocation", {})
            spend_by_channel = current_alloc if isinstance(current_alloc, dict) else {}

        # Resolve platform inputs
        platform_revenue = None
        if platform_reported_roas is None:
            from mixlift.ingest.platform_revenue import (
                detect_platform_revenue_columns,
                parse_revenue_series,
            )

            detected_cols = detect_platform_revenue_columns(df)
            if detected_cols:
                platform_revenue = {
                    ch: float(parse_revenue_series(df[col]).sum())
                    for ch, col in detected_cols.items()
                }
            else:
                # Fallback: long-format platform export (Meta/Google/TikTok CSV).
                # detect_platform_revenue_columns only finds wide-format suffix columns;
                # long-format CSVs expose revenue via the parser's platform_revenue column.
                try:
                    from mixlift.ingest.loader import detect_csv_format
                    from mixlift.ingest.loader import load_platform_revenue_totals
                    from mixlift.modeling.optimizer import format_channel_name

                    plat = detect_csv_format(df)
                    if plat in ("meta", "google", "tiktok", "generic") and not df.empty:
                        raw_totals = load_platform_revenue_totals(df, plat) or {}
                        if raw_totals:
                            # raw_totals keys are campaign-derived canonical channel names;
                            # normalize to MMM display names so compute_platform_comparison
                            # can match them against mmm_roas keys.
                            platform_revenue = {
                                format_channel_name(ch): val for ch, val in raw_totals.items()
                            }
                except Exception as exc:
                    logger.warning("long-format platform revenue auto-detect failed: %s", exc)

        comparison = compute_platform_comparison(
            mmm_roas=mmm_roas_estimates,
            mmm_ci=mmm_ci,
            spend_by_channel=spend_by_channel,
            platform_roas=platform_reported_roas,
            platform_revenue=platform_revenue,
        )

        if comparison:
            result = {
                **result,
                "platform_attribution_comparison": _gate_platform_comparison_for_tier(
                    comparison, is_paid
                ),
            }
    except Exception as exc:
        logger.warning("platform comparison computation failed: %s", exc, exc_info=True)

    return result


def _build_result(
    model_results,
    optimization: dict,
    saturation_curves: dict,
    channel_columns: list[str],
    license_status: LicenseStatus,
    csv_format: str,
    tier_warnings: list[str] | None = None,
    data_weeks: float = 52,
    platform_reported_roas: "dict[str, float] | None" = None,
    df: "pd.DataFrame | None" = None,
    backtest: "dict | None" = None,
) -> dict:
    """Build the final result dictionary."""
    from mixlift.modeling.recommendations import (
        generate_recommendations,
        format_all_recommendations,
    )

    # Generate recommendations
    recommendations, summary = generate_recommendations(
        current_allocation=optimization["current_allocation"],
        optimal_allocation=optimization["optimal_allocation"],
        roas_estimates=model_results.roas_estimates,
        expected_lift_pct=optimization["expected_lift_pct"],
    )

    # Compute new output features
    dollar_headline = _compute_dollar_headline(optimization)
    saturation_lights = _compute_saturation_traffic_lights(saturation_curves, optimization)
    confidence_summary = _compute_confidence_summary(model_results)
    model_fit = _compute_model_fit(model_results)

    # Exploratory analysis badge for short datasets
    analysis_badge = None
    if 0 < data_weeks < 26:
        analysis_badge = {
            "type": "exploratory",
            "label": "Exploratory Analysis",
            "note": (
                f"This analysis covers {data_weeks:.0f} weeks of data. "
                f"MixLift recommends at least 26 weeks for production-grade estimates. "
                f"Results with shorter datasets are influenced more by prior assumptions "
                f"than by your data. Treat ROAS estimates as directional, not precise."
            ),
        }

    is_paid = license_status.is_pro

    result = {
        "status": "success",
        "license": {
            "tier": "pro" if is_paid else "free",
            "message": license_status.message,
        },
        # --- HEADLINE (the most important field) ---
        "headline": dollar_headline["headline"]
        if is_paid
        else (
            f"MixLift found a {dollar_headline['lift_pct']:+.1f}% budget optimization opportunity. "
            f"Upgrade to Growth ($299/mo) to see exact dollar values."
        ),
        "data": {
            "format_detected": csv_format,
            "channels": list(model_results.roas_estimates.keys()),
            "n_channels": len(channel_columns),
        },
        "roas": {
            "estimates": model_results.roas_estimates,
            "confidence_intervals": {
                k: {"low": v[0], "high": v[1]} for k, v in model_results.roas_ci.items()
            },
        },
        "confidence_summary": confidence_summary,
        "channel_contributions": _gate_channel_contributions(
            model_results.channel_contributions,
            model_results.channel_contributions_ci,
            is_paid,
        ),
        "saturation_analysis": saturation_lights,
        "_spend_by_channel": dict(optimization["current_allocation"]),
        "budget_optimization": {
            "current_allocation": optimization["current_allocation"]
            if is_paid
            else "Upgrade to Growth ($299/mo) to see dollar allocations",
            "optimal_allocation": optimization["optimal_allocation"]
            if is_paid
            else "Upgrade to Growth ($299/mo) to see dollar allocations",
            "total_budget": optimization["total_budget"]
            if is_paid
            else "Upgrade to Growth ($299/mo) to see dollar allocations",
            "expected_lift_pct": optimization["expected_lift_pct"],
        },
        "recommendations": {
            "summary": summary if is_paid else _redact_dollars(summary),
            "actions": [
                {
                    "rank": r.rank,
                    "action": r.action,
                    "channel": r.channel,
                    "change_amount": r.change_amount if is_paid else "Upgrade to Growth ($299/mo)",
                    "current_spend": r.current_spend if is_paid else "Upgrade to Growth ($299/mo)",
                    "optimal_spend": r.optimal_spend if is_paid else "Upgrade to Growth ($299/mo)",
                    "roas": r.roas,
                    "reason": r.reason if is_paid else _redact_dollars(r.reason),
                }
                for r in recommendations
            ],
        },
        "marginal_roas": {
            "estimates": model_results.marginal_roas_estimates,
            "confidence_intervals": {
                k: {"low": v[0], "high": v[1]} for k, v in model_results.marginal_roas_ci.items()
            },
        },
        "diagnostics": {
            "convergence_warnings": model_results.convergence_warnings,
            "tier_warnings": tier_warnings or [],
        },
        "model_fit": model_fit,
        "analysis_badge": analysis_badge,
        "model_info": {
            "duration_secs": round(model_results.duration_secs, 1),
            "total_spend": model_results.total_spend if is_paid else "Upgrade to Growth ($299/mo)",
            "data_window": {"weeks": round(data_weeks, 1)},
        },
    }

    # MCMC configuration for traceability
    from mixlift.modeling.defaults import MCP_CONFIG

    result["model_info"]["mcmc_config"] = MCP_CONFIG

    # LOO-CV model validation (available to all tiers as a trust signal)
    if model_results.loo_cv:
        result["loo_cv"] = model_results.loo_cv

    # Intercept decomposition: baseline/organic revenue (paid tier only for dollar values)
    if model_results.intercept_decomposition:
        intercept = model_results.intercept_decomposition
        if "error" not in intercept:
            if is_paid:
                result["organic_revenue"] = intercept
            else:
                result["organic_revenue"] = {
                    "label": "Organic/baseline revenue estimate available on Growth plan ($299/mo).",
                    "note": "Your model includes baseline revenue from non-paid sources.",
                }
        else:
            result["organic_revenue"] = intercept

    # Dollar-value details only for paid tier
    if is_paid:
        result["dollar_value_analysis"] = dollar_headline
    else:
        result["dollar_value_analysis"] = {
            "headline": result["headline"],
            "note": "Dollar values are available on the Growth plan ($299/mo)."
            "Free tier shows percentage-based insights.",
        }

    # Raw saturation curves stripped from MCP output (Claude cannot render charts;
    # traffic lights in saturation_analysis provide the actionable summary).
    # Headless API users can access curves via the modeling engine directly.

    # Backtest holdout validation (N7) — threaded separately, injected here
    if backtest is not None:
        result["backtest"] = _gate_backtest_for_tier(backtest, is_paid=is_paid)

    # Platform attribution comparison (N9) — post-hoc, no MCMC required
    if df is not None or platform_reported_roas is not None:
        _df_for_comparison = df if df is not None else pd.DataFrame()
        result = _add_platform_comparison(
            result, _df_for_comparison, platform_reported_roas, is_paid
        )

    return result


def _run_pipeline(X, y, channel_columns, reporter=None):
    """Wrapper for run_full_pipeline (enables easy mocking in tests).

    Uses MCP_CONFIG (4 chains, 500 tune, 250 draws) for balanced
    convergence quality with ~30-60s response time.

    Args:
        reporter: Optional ProgressReporter for live progress notifications.
    """
    from mixlift.modeling.defaults import MCP_CONFIG
    from mixlift.modeling.engine import run_full_pipeline

    return run_full_pipeline(X, y, channel_columns, mcmc_config=MCP_CONFIG, reporter=reporter)


def _run_backtest(X, y, channel_columns, mcmc_config=None, reporter=None):
    """Thread-runnable wrapper for run_backtest. Returns dict (asdict of BacktestResult)."""
    from dataclasses import asdict

    from mixlift.modeling.backtest import run_backtest

    result = run_backtest(
        X=X,
        y=y,
        channel_columns=channel_columns,
        mcmc_config=mcmc_config,
        reporter=reporter,
    )
    return asdict(result)


def _run_optimizer(mmm, X, channel_columns, contributions=None, reporter=None):
    """Wrapper for optimize_budget (enables easy mocking in tests)."""
    from mixlift.modeling.optimizer import optimize_budget

    if reporter is not None:
        reporter.phase("Optimizing budget allocation", 5, 7)
    return optimize_budget(mmm, X, channel_columns, contributions=contributions)


def _run_saturation(mmm, X, channel_columns, reporter=None):
    """Wrapper for extract_saturation_curves (enables easy mocking in tests)."""
    from mixlift.modeling.engine import extract_saturation_curves

    if reporter is not None:
        reporter.phase("Analyzing saturation curves", 6, 7)
    return extract_saturation_curves(mmm, X, channel_columns)


@mcp.tool()
async def mixlift_analyze(
    csv_path: str = "",
    csv_content: str = "",
    license_key: str = "",
    force_refresh: bool = False,
    platform_reported_roas: dict[str, float] | None = None,
    ctx: Context | None = None,
) -> str:
    """Run full Bayesian Marketing Mix Model analysis on marketing spend data.

    Accepts a CSV file path with marketing data (Meta Ads, Google Ads, TikTok Ads,
    or generic format). Auto-detects the CSV format. If no path is provided, uses
    a bundled demo dataset.

    For remote/cloud usage, pass raw CSV text via csv_content instead of a file path.

    The response is structured in two tiers:
    - `summary`: headline, top actions, channel overview, model quality — enough
      to start an intelligent conversation (~2-4K chars)
    - `structured_data`: full ROAS with CIs, saturation analysis, budget details —
      reference on demand when the user asks for specifics

    Use your judgment to present findings conversationally. Lead with the headline
    and top actions. Surface details from structured_data only when relevant.
    After presenting key findings, ask one intake question from `intake_questions`
    to understand the user's context and tailor follow-up analysis.

    Args:
        csv_path: Path to a CSV file with marketing data. Leave empty to use demo data.
        csv_content: Raw CSV text (alternative to csv_path for remote/cloud usage).
        license_key: Optional MixLift Growth license key. Free tier: 2 channels, 2,000 rows.
        force_refresh: When True, skip cache lookup and re-fit fresh MCMC (~110s).
            Use this to get updated estimates after adding new data.
        platform_reported_roas: Optional dict mapping channel names to the ROAS
            self-reported by the platform (e.g. Meta Pixel, Google Conversions API).
            Example: {"Meta": 3.2, "Google": 1.8, "TikTok": 4.5}. When provided,
            MixLift adds a "Platform vs. MixLift Attribution" comparison showing
            where platforms may be over-claiming relative to the incremental lift
            MMM measures. If omitted, MixLift auto-detects platform-reported revenue
            columns from the ingested CSV and derives ROAS from those. If neither
            is available the comparison is omitted.

    Timing expectations for Claude:
    First-run analysis fits a Bayesian model and typically takes 3-8 minutes
    (scaling with data size and channel count). Datasets >= 30 weeks additionally
    run a walk-forward holdout validation adding ~1-2 minutes. Set this expectation
    with the user BEFORE invoking the tool — e.g. "This will take a few minutes
    because we're fitting a Bayesian model; I'll share updates as it runs."
    Subsequent runs on the same data return from cache in under a second. Progress
    notifications stream during compute, so the user will see phase updates.
    Passing a new platform_reported_roas on a cached dataset returns in <1 second
    because the platform comparison is computed post-hoc without re-fitting MCMC.

    Platform attribution comparison (optional):
    Pass `platform_reported_roas={"Meta": 3.2, "Google": 1.8}` to compare
    platform-self-reported ROAS to MMM-measured ROAS. This surfaces a
    "Platform vs. MixLift Attribution" section showing where your Meta Pixel,
    Google Conversions API, or TikTok Events API may be over-claiming
    attribution relative to the incremental lift MMM measures. If not passed,
    MixLift will auto-detect platform-reported revenue columns from the
    ingested CSV (e.g., Meta's "Purchases Conversion Value", Google's
    "Conv. value", TikTok's "Total complete payment value").

    Presentation instructions for Claude:
    The response contains `summary.readout_markdown` — a pre-rendered analyst-memo in
    finished form. Surface this verbatim as your primary response to the user. Do NOT
    wrap it in additional H1/H2 headings, do NOT add emoji, do NOT paraphrase the table
    or the "Three moves" blockquote. After surfacing, you may ask one clarifying
    question from `intake_questions`, or offer one of the `next_actions`. If the user
    asks for deeper detail on a specific channel, pull from `structured_data`.

    Example:
        mixlift_analyze(
            csv_path="marketing.csv",
            platform_reported_roas={"Meta": 3.2, "Google": 2.1, "TikTok": 4.5},
        )
    """
    import time as _time

    from mixlift_mcp.progress import ProgressReporter

    _step = 0

    async def _log(msg: str) -> None:
        """Send progress to client and log locally."""
        nonlocal _step
        _step += 1
        logger.info(msg)
        if ctx:
            try:
                await ctx.report_progress(_step, 7, msg)
            except Exception:
                pass  # Progress reporting is best-effort

    t0 = _time.monotonic()
    # Build a thread-safe reporter. The loop is captured here (in the async
    # context) so the worker thread can schedule back onto it.
    _loop = asyncio.get_running_loop()
    _reporter = ProgressReporter(ctx, _loop)

    await _log("Validating license...")
    # Validate license — checks OAuth bearer token first, falls back to license_key param
    license_status = await _resolve_license(license_key, ctx)

    # Fire-and-forget: emit `first_analyze` once per identity. Scheduled off the
    # critical path so the 500 ms analytics timeout never stalls the tool.
    asyncio.create_task(maybe_fire_first_analyze(license_key, license_status.is_pro, ctx))

    # Usage metering — shared store with local-file fallback
    if not license_status.is_pro:
        from mixlift_mcp._metering_identity import build_identity_hash
        from mixlift_mcp.metering import check_and_increment_remote

        identity_hash, _ = build_identity_hash(
            license_key=license_key,
            is_pro=False,
            ctx=ctx,
        )
        allowed, count = await check_and_increment_remote(
            identity_hash=identity_hash,
            limit=2,
            daily=False,
        )
        if not allowed:
            return json.dumps(
                {
                    "error": "quota_exceeded",
                    "limit": 2,
                    "count": count,
                    "message": "Free tier: 2 runs/month. Upgrade at mixlift.io/pricing.",
                }
            )
        await _log(f"Free tier: {count}/2 analyses used this month")

    # Load data — supports three modes:
    # 1. csv_content: raw CSV text (for remote/cloud usage)
    # 2. csv_path: local filesystem path
    # 3. Neither: demo dataset
    if csv_content:
        import io
        import tempfile

        try:
            df = pd.read_csv(io.StringIO(csv_content))
        except Exception as e:
            return json.dumps({"status": "error", "message": f"Failed to parse CSV content: {e}"})
        # Write to temp file so memory fingerprinting has a path
        _tmp = tempfile.NamedTemporaryFile(suffix=".csv", prefix="mixlift_upload_", delete=False)
        _tmp.write(csv_content.encode())
        _tmp.close()
        csv_file = Path(_tmp.name)
    else:
        use_demo = not csv_path
        if use_demo:
            if not DEMO_CSV_PATH.exists():
                return json.dumps(
                    {
                        "status": "error",
                        "message": "Demo data not found. Please provide a csv_path.",
                    }
                )
            csv_file = DEMO_CSV_PATH
        else:
            csv_file, validation_error = _validate_csv_path(csv_path)
            if validation_error:
                return json.dumps({"status": "error", "message": validation_error})
            if not csv_file.exists():
                return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

        try:
            df = pd.read_csv(csv_file)
        except Exception as e:
            return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    _reporter.phase("Validating CSV and detecting channels", 1, 7)
    await _log(f"CSV loaded ({len(df)} rows). Detecting format...")
    # Detect format and load
    csv_format = _detect_csv_format(df)

    try:
        if csv_format == "wide":
            X, y, channel_columns = _load_wide_format(df)
        else:
            X, y, channel_columns = _load_platform_csv(df, csv_format)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    _reporter.phase("Preprocessing (holidays, controls, weekly aggregation)", 2, 7)
    # Check date range warnings (90-179 days: warn but proceed)
    date_range_warnings = _check_date_range_warnings(df)
    for w in date_range_warnings:
        logger.warning(w)
        await _log(w)

    # Compute data length for exploratory badge
    try:
        _dates = pd.to_datetime(df["date"])
        _data_weeks = (_dates.max() - _dates.min()).days / 7
    except Exception:
        _data_weeks = 52  # Default to safe value

    # Enforce tier limits
    n_channels = len(channel_columns)
    n_rows = len(X)
    try:
        tier_warnings = _enforce_tier_limits(license_status, n_channels, n_rows)
        tier_warnings.extend(date_range_warnings)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    # ---------------------------------------------------------------------------
    # Persistent disk cache lookup — check before running ~110s MCMC
    # ---------------------------------------------------------------------------
    # Compute content-based fingerprint from CSV bytes + channels + MCMC config.
    # This fingerprint is stable across deploys (no code SHA).
    _csv_bytes = csv_content.encode() if csv_content else csv_file.read_bytes()
    from mixlift.modeling.defaults import FAST_BACKTEST_CONFIG, MCP_CONFIG
    from mixlift_mcp.model_cache import (
        _entry_dir as _cache_entry_dir,
        compute_backtest_fingerprint,
        compute_model_fingerprint,
        load_backtest,
        load_model as _disk_load_model,
        save_backtest,
        save_model as _disk_save_model,
    )

    _disk_fp = compute_model_fingerprint(_csv_bytes, channel_columns, MCP_CONFIG)

    if not force_refresh:
        # Persistent disk cache (survives fly deploy, cross-session)
        # The in-memory _MODEL_CACHE is intentionally NOT checked here — it is
        # only for within-session tool chaining (scenario/forecast/readout).
        # Skipping re-runs of mixlift_analyze from in-memory cache would break
        # contextual memory delta accumulation across multiple analyses.
        _disk_entry = await _disk_load_model(_disk_fp)
        if _disk_entry is not None:
            # Populate in-memory cache so follow-up tools (scenario/forecast) work
            _MODEL_CACHE[_disk_fp] = _disk_entry
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]

            cached_result = _disk_entry.get("result", {})
            # Annotate cache hit provenance
            cached_result["cache_hit"] = "persistent"
            meta_path = _cache_entry_dir(_disk_fp) / "meta.json"
            try:
                import json as _json

                _meta = _json.loads(meta_path.read_text())
                _cached_at = _meta.get("created_at", "")
                cached_result["cached_at"] = _cached_at
                # Human-readable age
                from datetime import datetime, timezone as _tz

                _fit_dt = datetime.fromisoformat(_cached_at)
                _age_days = (datetime.now(tz=_tz.utc) - _fit_dt).days
                _age_str = f"{_age_days} day{'s' if _age_days != 1 else ''} ago"
                cached_result["model_fingerprint"] = _disk_fp
                cached_result["_cache_age_days"] = _age_days
                cached_result["is_cache_hit"] = True
                cached_result["cache_age_days"] = _age_days
                # Inject cache notice into the summary text if present
                _summary = cached_result.get("summary", {})
                _headline = _summary.get("headline", "")
                if _headline:
                    _summary["headline"] = (
                        _headline + f"\n\n(Loaded from cache — fit completed {_age_str}. "
                        "Re-run with fresh MCMC by passing `force_refresh=true`.)"
                    )
            except Exception as _exc:
                logger.debug(f"model_cache: could not annotate cache_hit metadata: {_exc}")

            await _log(f"Cache hit — loaded fitted model from disk ({_disk_fp}).")
            # Platform comparison is post-hoc (no MCMC required) — apply fresh
            # even on cache hits so re-runs with new platform_reported_roas are instant.
            if platform_reported_roas is not None or _has_detectable_platform_revenue(df):
                cached_result = _add_platform_comparison(
                    cached_result, df, platform_reported_roas, license_status.is_pro
                )
            # Legacy cache entries predate backtest wiring (N7); mark as not_computed
            # rather than re-fitting 3 MCMC folds on every cache hit.
            if "backtest" not in cached_result:
                cached_result["backtest"] = {
                    "mode": "skipped",
                    "status": "not_computed",
                    "n_folds": 0,
                    "horizon_weeks": 0,
                    "train_weeks": None,
                    "folds": [],
                    "aggregate": {},
                    "compute_secs": 0.0,
                    "note": (
                        "Backtest not available for this cached result. "
                        "Re-run with force_refresh=True to generate."
                    ),
                }
            # Re-gate backtest for the current session's tier. Handles the edge
            # case where a user downgraded pro→free after the original fit —
            # the cached paid-tier backtest would otherwise leak per-fold
            # weekly revenue arrays and coverage values.
            if cached_result.get("backtest"):
                cached_result["backtest"] = _gate_backtest_for_tier(
                    cached_result["backtest"], is_paid=license_status.is_pro
                )
            return json.dumps(_build_tiered_response(cached_result), indent=2, default=str)

    # Run the modeling pipeline
    try:
        await _log(
            f"Starting MMM: {n_channels} channels, {n_rows} rows, "
            f"format={csv_format}, tier={'pro' if license_status.is_pro else 'free'}"
        )

        # Run CPU-bound MCMC sampling in a thread to avoid blocking the
        # MCP server's async event loop (which would make it appear hung).
        await _log(
            "Fitting Bayesian model via MCMC sampling (~30-60s)... "
            "Building a statistical model of how each channel drives revenue."
        )
        model_results = await asyncio.to_thread(_run_pipeline, X, y, channel_columns, _reporter)
        elapsed = _time.monotonic() - t0
        await _log(
            f"MCMC complete in {elapsed:.1f}s. "
            "Optimizing budget allocation — finding the spend mix that maximizes revenue..."
        )

        optimization = await asyncio.to_thread(
            _run_optimizer,
            model_results.mmm,
            X,
            channel_columns,
            model_results.raw_contributions,
            _reporter,
        )
        await _log(
            "Analyzing saturation curves — checking which channels have room to scale "
            "and which are hitting diminishing returns..."
        )

        saturation_curves = await asyncio.to_thread(
            _run_saturation, model_results.mmm, X, channel_columns, _reporter
        )

        # Backtest holdout validation (N7) — run inline for datasets ≥30 weeks
        _backtest_result: dict | None = None
        if _data_weeks >= 30:
            _n_folds = 3
            _horizon = 4
            _backtest_fp = compute_backtest_fingerprint(
                csv_bytes=_csv_bytes,
                channel_columns=channel_columns,
                mcmc_config=FAST_BACKTEST_CONFIG,
                n_folds=_n_folds,
                horizon=_horizon,
            )
            _cached_backtest = load_backtest(_backtest_fp)
            if _cached_backtest is not None and not force_refresh:
                logger.info("Using cached backtest (fingerprint=%s)", _backtest_fp[:8])
                _backtest_result = _cached_backtest
                if _reporter is not None:
                    _reporter.phase("Backtest loaded from cache", 7, 10)
            else:
                if _reporter is not None:
                    _reporter.phase("Running holdout validation (3 folds)", 7, 10)
                await _log(
                    "Running walk-forward holdout validation — "
                    "testing model accuracy on held-out weeks..."
                )
                try:
                    _backtest_result = await asyncio.to_thread(
                        _run_backtest,
                        X,
                        y,
                        channel_columns,
                        None,
                        _reporter,
                    )
                    if _backtest_result.get("status") == "success":
                        save_backtest(_backtest_fp, _backtest_result)
                except Exception as _bt_exc:
                    logger.warning("backtest failed: %s", _bt_exc, exc_info=True)
                    _backtest_result = {
                        "mode": "skipped",
                        "status": "failed",
                        "n_folds": 0,
                        "horizon_weeks": 0,
                        "train_weeks": None,
                        "folds": [],
                        "aggregate": {},
                        "compute_secs": 0.0,
                        "note": f"Backtest failed: {_bt_exc.__class__.__name__}",
                    }
        else:
            _backtest_result = {
                "mode": "skipped",
                "status": "insufficient_data",
                "n_folds": 0,
                "horizon_weeks": 0,
                "train_weeks": None,
                "folds": [],
                "aggregate": {},
                "compute_secs": 0.0,
                "note": f"Need \u226530 weeks; have {_data_weeks:.0f}.",
            }

        total = _time.monotonic() - t0
        await _log(f"Analysis complete in {total:.1f}s. Building results...")

        result = _build_result(
            model_results=model_results,
            optimization=optimization,
            saturation_curves=saturation_curves,
            channel_columns=channel_columns,
            license_status=license_status,
            csv_format=csv_format,
            tier_warnings=tier_warnings,
            data_weeks=_data_weeks,
            platform_reported_roas=platform_reported_roas,
            df=df,
            backtest=_backtest_result,
        )

        # Include saturation curves for the readout pipeline (diminishing returns)
        if license_status.is_pro:
            result["saturation_curves"] = saturation_curves

        # Contextual memory: compare to previous analysis on same dataset
        fp = None
        try:
            from mixlift_mcp.memory import (
                build_summary,
                compute_deltas,
                compute_fingerprint,
                load_previous,
                save_analysis,
            )

            channel_names = list(model_results.roas_estimates.keys())
            fp = compute_fingerprint(channel_names, str(csv_file))
            saturation_lights = result.get("saturation_analysis", {})

            mem_summary = build_summary(
                roas_estimates=model_results.roas_estimates,
                roas_ci=model_results.roas_ci,
                saturation_lights=saturation_lights,
                optimization=optimization,
                channel_contributions=model_results.channel_contributions,
                model_fit=result.get("model_fit", {}),
                data_weeks=_data_weeks,
                analysis_badge=result.get("analysis_badge"),
            )

            previous = load_previous(fp)
            if previous:
                deltas = compute_deltas(mem_summary, previous)
                result["memory"] = deltas
            else:
                result["memory"] = {
                    "note": "First analysis for this dataset. Future runs will show trends.",
                }

            save_analysis(fp, str(csv_file), mem_summary)

            # Use the content-based fingerprint (_disk_fp) as the canonical
            # cache key — it's stable across deploys and sessions.
            _MODEL_CACHE[_disk_fp] = {
                "mmm": model_results.mmm,
                "X": X,
                "channel_columns": channel_columns,
                "model_results": model_results,
            }
            # Evict oldest entries if cache exceeds 3 models
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]
            result["model_fingerprint"] = _disk_fp
        except Exception as e:
            logger.warning(f"Memory system error (non-fatal): {e}")

        result["is_cache_hit"] = False

        # Back-fill the complete result into the model cache
        if _disk_fp in _MODEL_CACHE:
            _MODEL_CACHE[_disk_fp]["result"] = result

        # Persist to disk cache (non-blocking, best-effort)
        asyncio.ensure_future(
            _disk_save_model(
                _disk_fp,
                mmm=model_results.mmm,
                X=X,
                channel_columns=channel_columns,
                result=result,
                mcmc_config=MCP_CONFIG,
            )
        )

        # Return tiered response (summary + structured_data) to Claude
        return json.dumps(_build_tiered_response(result), indent=2, default=str)

    except Exception as e:
        logger.exception("MMM analysis failed")
        return json.dumps({"status": "error", "message": f"Analysis failed: {e}"})


def _parse_scenario(scenario: str, current_allocation: dict) -> dict | None:
    """Parse a natural-language budget scenario into allocation changes.

    Supports patterns like:
    - "cut Meta by 20%"
    - "increase Google by $5000"
    - "move $3000 from Meta to Google"

    Returns modified allocation dict, or None if unparseable.
    """
    import re

    scenario_lower = scenario.lower().strip()
    modified = dict(current_allocation)
    channels_lower = {k.lower(): k for k in current_allocation}

    def _find_channel(text: str) -> str | None:
        # Exact match first, then substring (text in key, not key in text)
        for key, name in channels_lower.items():
            if key == text:
                return name
        for key, name in channels_lower.items():
            if text in key:
                return name
        return None

    # Pattern: "cut/reduce/decrease X by Y%"
    m = re.search(r"(?:cut|reduce|decrease)\s+(\w+)\s+by\s+(\d+)%", scenario_lower)
    if m:
        ch = _find_channel(m.group(1))
        pct = float(m.group(2)) / 100
        if ch and ch in modified:
            modified[ch] = round(modified[ch] * (1 - pct), 2)
            return modified

    # Pattern: "increase/boost X by Y%"
    m = re.search(r"(?:increase|boost|raise)\s+(\w+)\s+by\s+(\d+)%", scenario_lower)
    if m:
        ch = _find_channel(m.group(1))
        pct = float(m.group(2)) / 100
        if ch and ch in modified:
            modified[ch] = round(modified[ch] * (1 + pct), 2)
            return modified

    # Pattern: "cut/reduce X by $Y"
    m = re.search(r"(?:cut|reduce|decrease)\s+(\w+)\s+by\s+\$?([\d,]+)", scenario_lower)
    if m:
        ch = _find_channel(m.group(1))
        amount = float(m.group(2).replace(",", ""))
        if ch and ch in modified:
            modified[ch] = round(max(0, modified[ch] - amount), 2)
            return modified

    # Pattern: "increase X by $Y"
    m = re.search(r"(?:increase|boost|raise)\s+(\w+)\s+by\s+\$?([\d,]+)", scenario_lower)
    if m:
        ch = _find_channel(m.group(1))
        amount = float(m.group(2).replace(",", ""))
        if ch and ch in modified:
            modified[ch] = round(modified[ch] + amount, 2)
            return modified

    # Pattern: "move $Y from X to Z"
    m = re.search(r"move\s+\$?([\d,]+)\s+from\s+(\w+)\s+to\s+(\w+)", scenario_lower)
    if m:
        amount = float(m.group(1).replace(",", ""))
        from_ch = _find_channel(m.group(2))
        to_ch = _find_channel(m.group(3))
        if from_ch and to_ch and from_ch in modified and to_ch in modified:
            modified[from_ch] = round(max(0, modified[from_ch] - amount), 2)
            modified[to_ch] = round(modified[to_ch] + amount, 2)
            return modified

    return None


def _run_scenario(
    scenario: str,
    optimization: dict,
    model_results,
    X,
    channel_columns: list[str],
) -> dict | None:
    """Run a what-if scenario and project impact with confidence intervals."""
    import numpy as np

    from mixlift.modeling.optimizer import (
        _estimate_response,
        estimate_scenario_impact_samples,
    )

    current = optimization["current_allocation"]
    modified = _parse_scenario(scenario, current)

    if modified is None:
        return {
            "error": f"Could not parse scenario: '{scenario}'. "
            f"Try: 'cut Meta by 20%', 'increase Google by $5000', "
            f"or 'move $3000 from Meta to Google'."
        }

    # Point estimate (backward-compatible)
    current_response = _estimate_response(model_results.mmm, X, channel_columns, current)
    modified_response = _estimate_response(model_results.mmm, X, channel_columns, modified)

    if current_response > 0:
        impact_pct = ((modified_response - current_response) / current_response) * 100
    else:
        impact_pct = 0.0

    # Confidence intervals via posterior sampling
    ci_data = {}
    try:
        samples = estimate_scenario_impact_samples(
            model_results.mmm, X, channel_columns, current, modified
        )
        if len(samples) > 0:
            median = float(np.median(samples))
            ci_low = float(np.percentile(samples, 10))
            ci_high = float(np.percentile(samples, 90))
            impact_pct = median  # Use median instead of point estimate

            ci_data = {
                "impact_ci_80": {"low": round(ci_low, 1), "high": round(ci_high, 1)},
                "confidence_note": "80% credible interval from Bayesian posterior",
            }

            # Direction confidence language
            if ci_low > 0:
                direction_note = (
                    f"This would almost certainly increase revenue, "
                    f"likely by {ci_low:+.1f}% to {ci_high:+.1f}%."
                )
            elif ci_high < 0:
                direction_note = (
                    f"This would almost certainly reduce revenue, "
                    f"likely by {ci_high:.1f}% to {ci_low:.1f}%."
                )
            elif abs(median) > abs(ci_high - ci_low) * 0.1:
                word = "increase" if median > 0 else "reduce"
                direction_note = (
                    f"This would probably {word} revenue (median {median:+.1f}%), "
                    f"but there's a chance it could go either way."
                )
            else:
                direction_note = (
                    "The impact is uncertain — it could go either way. "
                    "Not enough signal to recommend this change."
                )
            ci_data["direction_note"] = direction_note
    except Exception as e:
        logger.warning(f"Could not compute scenario CIs: {e}")

    total_current = sum(current.values())
    total_modified = sum(modified.values())

    changes = []
    for ch in current:
        delta = modified.get(ch, 0) - current.get(ch, 0)
        if abs(delta) > 1:
            changes.append(
                {
                    "channel": ch,
                    "current": round(current[ch], 0),
                    "modified": round(modified.get(ch, 0), 0),
                    "change": round(delta, 0),
                }
            )

    result = {
        "scenario_input": scenario,
        "current_budget": round(total_current, 0),
        "modified_budget": round(total_modified, 0),
        "projected_impact_pct": round(impact_pct, 2),
        "headline": (
            f"Scenario: '{scenario}' would result in a {impact_pct:+.1f}% change "
            f"in projected revenue."
        ),
        "changes": changes,
        "modified_allocation": {k: round(v, 0) for k, v in modified.items()},
    }
    result.update(ci_data)
    return result


def _validate_output_dir(output_dir: str) -> tuple[Path, str | None]:
    """Validate and resolve the output directory path.

    Returns (resolved_path, error_message). error_message is None if valid.
    """
    if not output_dir:
        return Path.cwd(), None

    resolved = Path(output_dir).expanduser().resolve()
    path_str = str(resolved).lower()

    # Reuse the same blocked fragments from _validate_csv_path
    blocked = [
        "/etc/",
        "/var/",
        "/usr/",
        "/bin/",
        "/sbin/",
        "/system/",
        "/library/",
        "/.ssh/",
        "/.gnupg/",
        "/.aws/",
        "/.config/",
        "/windows/",
        "/program files/",
    ]
    for frag in blocked:
        if frag in path_str:
            return resolved, f"Output directory blocked for safety: {resolved}"

    return resolved, None


@mcp.tool()
async def mixlift_readout(
    model_fingerprint: str,
    output_dir: str = "",
    format: str = "markdown",
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Export MMM analysis results as executive-ready deliverables.

    Takes the model fingerprint from mixlift_analyze and generates deliverables.

    Two formats available:
    - "markdown" (default): Obsidian-flavored .md files with source citations
    - "html": Single self-contained HTML report, print-ready for PDF

    The HTML report is designed for sharing — a VP can email it to their CFO.
    Open in any browser and use Print > Save as PDF for a polished document.

    Requires Growth plan ($299/mo).

    Args:
        model_fingerprint: The model fingerprint returned by mixlift_analyze.
        output_dir: Directory to write deliverables. Defaults to current directory.
        format: Output format — "markdown" or "html". Default: "markdown".
        license_key: MixLift Growth license key. Required — free tier cannot generate deliverables.
    """
    # Validate license — checks OAuth bearer token first, falls back to license_key param
    license_status = await _resolve_license(license_key, ctx)
    if not license_status.is_pro:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "Deliverable export requires a Growth plan ($299/mo). "
                    "Upgrade at https://mixlift.io/pricing to generate "
                    "executive-ready budget memos, channel scorecards, and scenario briefs."
                ),
            }
        )

    if not model_fingerprint or model_fingerprint not in _MODEL_CACHE:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "Analysis result not found in session cache. "
                    "Run mixlift_analyze first, then call mixlift_readout."
                ),
            }
        )

    result = _MODEL_CACHE[model_fingerprint]["result"]

    if result.get("status") != "success":
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "Cannot generate deliverables from a failed analysis. "
                    "Run mixlift_analyze first."
                ),
            }
        )

    # Validate output directory
    output_path, dir_error = _validate_output_dir(output_dir)
    if dir_error:
        return json.dumps({"status": "error", "message": dir_error})

    # Generate deliverables
    try:
        if format == "html":
            from datetime import date as _date

            from mixlift_mcp.readout import generate_html_report

            html_dir = output_path / "MixLift" / _date.today().isoformat()
            html_file = html_dir / "report.html"
            summary = await asyncio.to_thread(generate_html_report, result, str(html_file))
        else:
            from mixlift_mcp.readout import generate_readout

            summary = await asyncio.to_thread(generate_readout, result, str(output_path))

        summary["next_actions"] = [
            {
                "tool": "mixlift_scenario",
                "description": "Test a what-if budget change",
                "params": {"model_fingerprint": model_fingerprint},
            },
            {
                "tool": "mixlift_forecast",
                "description": "Project revenue over the next 12 weeks",
                "params": {"model_fingerprint": model_fingerprint},
            },
        ]
        return json.dumps(summary, indent=2, default=str)
    except Exception as e:
        logger.exception("Deliverable generation failed")
        return json.dumps(
            {
                "status": "error",
                "message": f"Deliverable generation failed: {e}",
            }
        )


@mcp.tool()
async def mixlift_scenario(
    model_fingerprint: str,
    scenario: str,
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Run a what-if budget scenario using a previously fitted model.

    Reuses the model from mixlift_analyze (no MCMC re-run needed) to project
    the revenue impact of budget changes. Supports natural-language scenarios:
    - "cut Meta by 20%"
    - "increase Google by $5000"
    - "move $3000 from Meta to Google"

    The scenario result is also stored in the session cache so that
    mixlift_readout can include a scenario brief in deliverables.

    Requires Growth plan ($299/mo).

    Args:
        model_fingerprint: The model fingerprint returned by mixlift_analyze.
        scenario: Natural-language budget scenario description.
        license_key: MixLift Growth license key.

    Presentation instructions for Claude:
    The response contains `readout_markdown` — surface it verbatim, then offer one
    follow-up from `next_actions`. Do not paraphrase or re-structure the memo.
    """
    # Validate license — checks OAuth bearer token first, falls back to license_key param
    license_status = await _resolve_license(license_key, ctx)
    if not license_status.is_pro:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "Scenario analysis requires a Growth plan ($299/mo). "
                    "Upgrade at https://mixlift.io/pricing"
                ),
            }
        )

    if not model_fingerprint or model_fingerprint not in _MODEL_CACHE:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "Fitted model not found in session cache. "
                    "Run mixlift_analyze first, then call mixlift_scenario."
                ),
            }
        )

    cache = _MODEL_CACHE[model_fingerprint]
    result = cache["result"]
    model_results = cache["model_results"]
    X = cache["X"]
    channel_columns = cache["channel_columns"]

    optimization = result.get("budget_optimization", {})
    if not optimization.get("current_allocation"):
        return json.dumps(
            {
                "status": "error",
                "message": "No budget allocation found. Run mixlift_analyze first.",
            }
        )

    # Run scenario using cached model (no MCMC needed)
    scenario_result = await asyncio.to_thread(
        _run_scenario, scenario, optimization, model_results, X, channel_columns
    )

    if scenario_result is None:
        return json.dumps(
            {
                "status": "error",
                "message": f"Could not parse scenario: '{scenario}'.",
            }
        )

    # Inject into cached result so readout can include scenario-brief
    result["scenario"] = scenario_result

    scenario_result["status"] = "success"
    try:
        scenario_result["readout_markdown"] = render_scenario_memo(
            scenario_result,
            model_info=result.get("model_info"),
        )
    except Exception as exc:
        logger.warning("render_scenario_memo failed: %s", exc)
        scenario_result["readout_markdown"] = ""
    scenario_result["model_fingerprint"] = model_fingerprint
    scenario_result["next_actions"] = [
        {
            "tool": "mixlift_scenario",
            "description": "Try another what-if scenario",
            "params": {"model_fingerprint": model_fingerprint},
        },
        {
            "tool": "mixlift_forecast",
            "description": "Project revenue over the next 12 weeks",
            "params": {"model_fingerprint": model_fingerprint},
        },
        {
            "tool": "mixlift_readout",
            "description": "Generate deliverables (includes scenario brief)",
            "params": {"model_fingerprint": model_fingerprint},
        },
    ]
    return json.dumps(scenario_result, indent=2, default=str)


@mcp.tool()
async def mixlift_connect(
    platform: str,
    access_token: str,
    account_id: str,
    date_range: str = "",
    granularity: str = "platform",
    output_dir: str = "",
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Pull marketing data from an ad platform API and save as CSV.

    Connects directly to Meta, Google, or TikTok Ads APIs to pull
    spend + revenue data. Saves a wide-format CSV that can be passed
    directly to mixlift_analyze.

    Supported platforms: meta, google, tiktok

    After connecting, pass the returned output_path to mixlift_analyze.

    Requires Growth plan ($299/mo).

    Args:
        platform: Ad platform — "meta", "google", or "tiktok".
        access_token: Platform API access token.
            - Meta: User or system user access token.
            - Google: JSON string with developer_token, client_id, client_secret, refresh_token.
            - TikTok: Marketing API access token.
        account_id: Platform ad account identifier.
            - Meta: Ad account ID (with or without "act_" prefix).
            - Google: Customer ID (with or without dashes).
            - TikTok: Advertiser ID.
        date_range: Date range to pull. "last_90_days", "last_180_days",
                    "YYYY-MM-DD:YYYY-MM-DD", or empty for last 180 days.
        granularity: "platform" (one channel per platform) or "campaign"
                     (each campaign becomes a separate channel).
        output_dir: Directory to save the CSV. Defaults to current directory.
        license_key: MixLift Growth license key. Required.
    """
    # Validate license — checks OAuth bearer token first, falls back to license_key param
    license_status = await _resolve_license(license_key, ctx)
    if not license_status.is_pro:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "API data connectors require a Growth plan ($299/mo). "
                    "Upgrade at https://mixlift.io/pricing"
                ),
            }
        )

    # Validate platform
    platform = platform.strip().lower()
    if platform not in ("meta", "google", "tiktok"):
        return json.dumps(
            {
                "status": "error",
                "message": f"Unsupported platform: '{platform}'. Use 'meta', 'google', or 'tiktok'.",
            }
        )

    # Validate output dir
    output_path, dir_error = _validate_output_dir(output_dir)
    if dir_error:
        return json.dumps({"status": "error", "message": dir_error})

    try:
        from mixlift_mcp.connectors.base import DateRange, to_wide_format, save_wide_csv

        dr = DateRange.from_spec(date_range)

        # Get the right connector
        if platform == "meta":
            from mixlift_mcp.connectors.meta import MetaConnector

            connector = MetaConnector(access_token)
        elif platform == "google":
            from mixlift_mcp.connectors.google import GoogleConnector

            connector = GoogleConnector(access_token)
        else:
            from mixlift_mcp.connectors.tiktok import TikTokConnector

            connector = TikTokConnector(access_token)

        if ctx:
            try:
                await ctx.report_progress(1, 3, f"Connecting to {platform}...")
            except Exception:
                pass

        result = await connector.pull(account_id, dr, granularity)

        if result.row_count == 0:
            return json.dumps(
                {
                    "status": "error",
                    "message": (
                        f"No data returned from {platform} API. Check account_id and date_range."
                    ),
                }
            )

        if ctx:
            try:
                await ctx.report_progress(2, 3, f"Pulled {result.row_count} rows. Saving CSV...")
            except Exception:
                pass

        wide_df = to_wide_format([result])
        csv_path = save_wide_csv(wide_df, str(output_path), label=platform)

        if ctx:
            try:
                await ctx.report_progress(3, 3, "Done.")
            except Exception:
                pass

        return json.dumps(
            {
                "status": "success",
                "platform": platform,
                "output_path": str(csv_path),
                "channels": result.channels_found,
                "row_count": result.row_count,
                "date_range": {"start": dr.start.isoformat(), "end": dr.end.isoformat()},
                "message": (
                    f"Pulled {result.row_count} rows from {platform}. "
                    f"Pass output_path to mixlift_analyze to run MMM."
                ),
                "next_actions": [
                    {
                        "tool": "mixlift_analyze",
                        "description": "Run MMM analysis on the connected data",
                        "params": {"csv_path": str(csv_path)},
                    },
                ],
            },
            indent=2,
            default=str,
        )

    except ImportError as e:
        return json.dumps(
            {
                "status": "error",
                "message": str(e),
            }
        )
    except Exception as e:
        logger.exception("Connector failed: %s", platform)
        return json.dumps(
            {
                "status": "error",
                "message": f"{platform} connector failed: {e}",
            }
        )


@mcp.tool()
async def mixlift_connect_multi(
    connections: str,
    date_range: str = "",
    granularity: str = "platform",
    output_dir: str = "",
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Pull data from multiple ad platforms and merge into a single CSV.

    Pulls from Meta, Google, and/or TikTok in parallel, merges into one
    wide-format CSV with columns like: date, meta_spend, google_spend, revenue.

    Requires Growth plan ($299/mo).

    Args:
        connections: JSON array of connection specs. Each spec:
            {"platform": "meta", "access_token": "...", "account_id": "..."}
        date_range: Shared date range for all platforms.
        granularity: "platform" or "campaign" (applied to all platforms).
        output_dir: Directory to save the merged CSV. Defaults to current directory.
        license_key: MixLift Growth license key. Required.
    """
    # Validate license — checks OAuth bearer token first, falls back to license_key param
    license_status = await _resolve_license(license_key, ctx)
    if not license_status.is_pro:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "API data connectors require a Growth plan ($299/mo). "
                    "Upgrade at https://mixlift.io/pricing"
                ),
            }
        )

    # Parse connections
    try:
        conn_list = json.loads(connections)
        if not isinstance(conn_list, list) or len(conn_list) == 0:
            raise ValueError("connections must be a non-empty JSON array")
    except (json.JSONDecodeError, TypeError, ValueError) as e:
        return json.dumps(
            {
                "status": "error",
                "message": f"Invalid connections JSON: {e}",
            }
        )

    # Validate output dir
    output_path, dir_error = _validate_output_dir(output_dir)
    if dir_error:
        return json.dumps({"status": "error", "message": dir_error})

    try:
        from mixlift_mcp.connectors.base import DateRange, to_wide_format, save_wide_csv

        dr = DateRange.from_spec(date_range)
        results = []
        errors = []

        for i, conn in enumerate(conn_list):
            plat = conn.get("platform", "").strip().lower()
            token = conn.get("access_token", "")
            acct = conn.get("account_id", "")

            if not plat or not token or not acct:
                errors.append(f"Connection {i}: missing platform, access_token, or account_id")
                continue

            if ctx:
                try:
                    await ctx.report_progress(i + 1, len(conn_list) + 1, f"Pulling from {plat}...")
                except Exception:
                    pass

            try:
                if plat == "meta":
                    from mixlift_mcp.connectors.meta import MetaConnector

                    connector = MetaConnector(token)
                elif plat == "google":
                    from mixlift_mcp.connectors.google import GoogleConnector

                    connector = GoogleConnector(token)
                elif plat == "tiktok":
                    from mixlift_mcp.connectors.tiktok import TikTokConnector

                    connector = TikTokConnector(token)
                else:
                    errors.append(f"Connection {i}: unsupported platform '{plat}'")
                    continue

                result = await connector.pull(acct, dr, granularity)
                if result.row_count > 0:
                    results.append(result)
                else:
                    errors.append(f"{plat}: no data returned")
            except Exception as e:
                errors.append(f"{plat}: {e}")

        if not results:
            return json.dumps(
                {
                    "status": "error",
                    "message": "No data pulled from any platform.",
                    "errors": errors,
                }
            )

        if ctx:
            try:
                await ctx.report_progress(
                    len(conn_list) + 1, len(conn_list) + 1, "Merging and saving CSV..."
                )
            except Exception:
                pass

        wide_df = to_wide_format(results)
        platforms = [r.platform for r in results]
        csv_path = save_wide_csv(wide_df, str(output_path), label="_".join(platforms))

        all_channels = []
        total_rows = 0
        for r in results:
            all_channels.extend(r.channels_found)
            total_rows += r.row_count

        summary = {
            "status": "success",
            "platforms": platforms,
            "output_path": str(csv_path),
            "channels": all_channels,
            "total_rows": total_rows,
            "date_range": {
                "start": dr.start.isoformat(),
                "end": dr.end.isoformat(),
            },
            "message": (
                f"Pulled from {len(results)} platform(s): {', '.join(platforms)}. "
                f"{total_rows} total rows. "
                f"Pass output_path to mixlift_analyze to run MMM."
            ),
        }
        if errors:
            summary["warnings"] = errors

        summary["next_actions"] = [
            {
                "tool": "mixlift_analyze",
                "description": "Run MMM analysis on the combined data",
                "params": {"csv_path": str(csv_path)},
            },
        ]

        return json.dumps(summary, indent=2, default=str)

    except ImportError as e:
        return json.dumps({"status": "error", "message": str(e)})
    except Exception as e:
        logger.exception("Multi-connector failed")
        return json.dumps(
            {
                "status": "error",
                "message": f"Multi-connector failed: {e}",
            }
        )


@mcp.tool()
async def mixlift_forecast(
    model_fingerprint: str,
    horizon_weeks: int = 12,
    license_key: str = "",
    ctx: Context | None = None,
) -> str:
    """Forecast revenue under current vs optimized budget allocation.

    Uses the fitted MMM model from the most recent mixlift_analyze run
    to project weekly revenue for the next N weeks. Shows the gap between
    current allocation and the optimal allocation recommended by MixLift.

    Must be called after mixlift_analyze in the same session (the fitted
    model is cached in memory).

    Requires Growth plan ($299/mo).

    Args:
        model_fingerprint: The model fingerprint returned by mixlift_analyze.
        horizon_weeks: Number of weeks to forecast (default: 12).
        license_key: MixLift Growth license key.

    Presentation instructions for Claude:
    The response contains `readout_markdown` — a pre-rendered forecast memo. Surface
    it verbatim. Do not add emoji, do not re-order the weekly trajectory table.
    """
    import numpy as np

    # Validate license — checks OAuth bearer token first, falls back to license_key param
    license_status = await _resolve_license(license_key, ctx)
    if not license_status.is_pro:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "Forecasting requires a Growth plan ($299/mo). "
                    "Upgrade at https://mixlift.io/pricing"
                ),
            }
        )

    # Get model from cache
    if not model_fingerprint or model_fingerprint not in _MODEL_CACHE:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "Fitted model not found in session cache. "
                    "Run mixlift_analyze first, then call mixlift_forecast."
                ),
            }
        )

    cache = _MODEL_CACHE[model_fingerprint]
    result = cache["result"]
    mmm = cache["mmm"]
    X = cache["X"]
    channel_columns = cache["channel_columns"]

    # Clamp horizon
    horizon_weeks = max(1, min(horizon_weeks, 52))

    try:
        from mixlift.modeling.optimizer import (
            _estimate_response,
            estimate_scenario_impact_samples,
        )

        if ctx:
            try:
                await ctx.report_progress(1, 3, "Computing baseline forecast...")
            except Exception:
                pass

        # Get allocations from the result
        budget_opt = result.get("budget_optimization", {})
        current_alloc = budget_opt.get("current_allocation", {})
        optimal_alloc = budget_opt.get("optimal_allocation", {})

        if not current_alloc or not isinstance(current_alloc, dict):
            return json.dumps(
                {
                    "status": "error",
                    "message": ("No budget allocation found in result. Run mixlift_analyze first."),
                }
            )

        # Point estimate: weekly revenue at current allocation
        current_weekly = await asyncio.to_thread(
            _estimate_response, mmm, X, channel_columns, current_alloc
        )

        if ctx:
            try:
                await ctx.report_progress(2, 3, "Computing forecast uncertainty...")
            except Exception:
                pass

        # Get impact distribution from posterior
        impact_samples = await asyncio.to_thread(
            estimate_scenario_impact_samples,
            mmm,
            X,
            channel_columns,
            current_alloc,
            optimal_alloc,
        )

        # Compute stats
        if len(impact_samples) > 0:
            impact_median = float(np.median(impact_samples))
            impact_ci_low = float(np.percentile(impact_samples, 10))
            impact_ci_high = float(np.percentile(impact_samples, 90))
        else:
            impact_median = 0.0
            impact_ci_low = 0.0
            impact_ci_high = 0.0

        # Optimal weekly = current * (1 + impact/100)
        optimal_weekly_from_impact = current_weekly * (1 + impact_median / 100)

        # Build weekly projections
        weekly_delta = optimal_weekly_from_impact - current_weekly
        weeks = []
        cumulative_current = 0.0
        cumulative_optimal = 0.0
        cumulative_delta = 0.0

        for w in range(1, horizon_weeks + 1):
            cumulative_current += current_weekly
            cumulative_optimal += optimal_weekly_from_impact
            cumulative_delta += weekly_delta
            weeks.append(
                {
                    "week": w,
                    "current_revenue": round(current_weekly, 0),
                    "optimized_revenue": round(optimal_weekly_from_impact, 0),
                    "weekly_delta": round(weekly_delta, 0),
                    "cumulative_current": round(cumulative_current, 0),
                    "cumulative_optimized": round(cumulative_optimal, 0),
                    "cumulative_delta": round(cumulative_delta, 0),
                }
            )

        if ctx:
            try:
                await ctx.report_progress(3, 3, "Done.")
            except Exception:
                pass

        total_current = round(current_weekly * horizon_weeks, 0)
        total_optimal = round(optimal_weekly_from_impact * horizon_weeks, 0)
        total_delta = round(weekly_delta * horizon_weeks, 0)

        forecast_result = {
            "status": "success",
            "analysis_type": "forecast",
            "horizon_weeks": horizon_weeks,
            "summary": {
                "current_weekly_revenue": round(current_weekly, 0),
                "optimized_weekly_revenue": round(optimal_weekly_from_impact, 0),
                "weekly_delta": round(weekly_delta, 0),
                "total_current_revenue": total_current,
                "total_optimized_revenue": total_optimal,
                "total_delta": total_delta,
                "impact_pct": round(impact_median, 1),
                "impact_ci_80": {
                    "low": round(impact_ci_low, 1),
                    "high": round(impact_ci_high, 1),
                },
            },
            "weekly_projections": weeks,
            "current_allocation": current_alloc,
            "optimal_allocation": optimal_alloc,
            "headline": (
                f"Over {horizon_weeks} weeks, optimizing your budget would generate "
                f"an estimated ${total_delta:,.0f} in additional revenue "
                f"({impact_median:+.1f}% weekly, "
                f"80% CI: {impact_ci_low:+.1f}% to {impact_ci_high:+.1f}%)."
            ),
            "model_fingerprint": model_fingerprint,
            "model_info": result.get("model_info", {}),
            "data": result.get("data", {}),
            "license": result.get("license", {}),
        }

        try:
            forecast_result["readout_markdown"] = render_forecast_memo(forecast_result)
        except Exception as exc:
            logger.warning("render_forecast_memo failed: %s", exc)
            forecast_result["readout_markdown"] = ""

        forecast_result["next_actions"] = [
            {
                "tool": "mixlift_readout",
                "description": "Generate executive deliverables",
                "params": {"model_fingerprint": model_fingerprint},
            },
            {
                "tool": "mixlift_scenario",
                "description": "Test a what-if budget change",
                "params": {"model_fingerprint": model_fingerprint},
            },
        ]

        return json.dumps(forecast_result, indent=2, default=str)

    except Exception as e:
        logger.exception("Forecasting failed")
        return json.dumps(
            {
                "status": "error",
                "message": f"Forecasting failed: {e}",
            }
        )


def _run_marginal_roas(mmm: Any, X: Any, channel_columns: list[str]) -> tuple[dict, dict]:  # noqa: N803
    """Wrapper for extract_marginal_roas (enables easy mocking in tests)."""
    from mixlift.modeling.engine import extract_marginal_roas

    return extract_marginal_roas(mmm, X, channel_columns)


def _run_saturation_curves(mmm: Any, X: Any, channel_columns: list[str]) -> dict:  # noqa: N803
    """Wrapper for extract_saturation_curves (enables easy mocking in tests)."""
    from mixlift.modeling.engine import extract_saturation_curves

    return extract_saturation_curves(mmm, X, channel_columns)


@mcp.tool()
async def mixlift_saturation(
    csv_path: str,
    license_key: str | None = None,
    channels: list[str] | None = None,
    increment_steps: list[int] | None = None,
    mcmc_config: str = "default",
    ctx: Context | None = None,
) -> str:
    """Map every channel's response curve and quote what the next dollar earns.

    Use when the user asks where each channel sits on its saturation curve, which
    channels have room to scale, or what marginal ROAS to expect at the next spend
    increment. Reuses the cached model from a prior mixlift_analyze run.

    Do NOT use for period-over-period delta questions (use mixlift_wow) or for
    comparing hypothetical budget shifts (use mixlift_scenarios).

    Fires on questions like: "Where am I on each channel's saturation curve?"

    Args:
        csv_path: Path to a wide-format CSV (same as mixlift_analyze).
        license_key: MixLift Growth license key. Free tier: 2 channels, 2,000 rows.
        channels: Restrict output to these channel column names. Defaults to all.
            Channels absent from the fit are warned-and-skipped, not an error.
        increment_steps: Dollar increments to quote marginal returns at.
            Defaults to [1000, 5000, 10000, 25000].
        mcmc_config: MCMC preset. Ignored when a cached model exists.

    Returns:
        JSON string with: per-channel saturation_pct, status
        (room_to_scale / approaching / at_frontier / over_saturated), marginal ROAS
        with 90% CI, efficient_frontier_spend, next-dollar returns, and memo_markdown.

    Presentation: surface memo_markdown verbatim. No emoji, no table restructuring.
    """
    import time as _time  # noqa: I001, PLC0415

    from mixlift_mcp.model_cache import (
        compute_model_fingerprint,
        load_model as _disk_load_model,
        save_model as _disk_save_model,
    )
    from mixlift_mcp.progress import ProgressReporter
    from mixlift_mcp.renderers.saturation_memo import build_channel_saturation

    _step = 0

    async def _log(msg: str) -> None:
        nonlocal _step
        _step += 1
        logger.info(msg)
        if ctx:
            try:
                await ctx.report_progress(_step, 7, msg)
            except Exception:
                pass

    t0 = _time.monotonic()
    _loop = asyncio.get_running_loop()
    _reporter = ProgressReporter(ctx, _loop)

    # --- defaults ---
    _steps: list[int] = increment_steps if increment_steps else [1000, 5000, 10000, 25000]

    await _log("Validating license...")
    license_status = await _resolve_license(license_key or "", ctx)

    # --- path validation ---
    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

    try:
        df = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    _reporter.phase("Validating CSV and detecting channels", 1, 7)
    await _log(f"CSV loaded ({len(df)} rows). Detecting format...")

    csv_format = _detect_csv_format(df)
    try:
        if csv_format == "wide":
            X, y, all_channel_columns = _load_wide_format(df)  # noqa: N806
        else:
            X, y, all_channel_columns = _load_platform_csv(df, csv_format)  # noqa: N806
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    n_channels = len(all_channel_columns)
    n_rows = len(X)
    try:
        _enforce_tier_limits(license_status, n_channels, n_rows)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    # --- channel filter (warn-and-skip for unknown channels) ---
    _skipped_channels: list[str] = []
    if channels is not None:
        channel_columns = [c for c in channels if c in all_channel_columns]
        _skipped_raw = [c for c in channels if c not in all_channel_columns]
        if _skipped_raw:
            # Store raw column names so the footnote can say "check column names in your CSV"
            _skipped_channels = _skipped_raw
            logger.warning("mixlift_saturation: unknown channels skipped: %s", _skipped_raw)
    else:
        channel_columns = all_channel_columns

    if not channel_columns:
        return json.dumps(
            {"status": "error", "message": "No valid channels found after filtering."}
        )

    # --- data window ---
    try:
        _dates = pd.to_datetime(df["date"])
        _start = _dates.min().strftime("%Y-%m-%d")
        _end = _dates.max().strftime("%Y-%m-%d")
        _weeks = round((_dates.max() - _dates.min()).days / 7)
        data_window = f"{_start} to {_end} ({_weeks} weeks)"
    except Exception:
        data_window = ""

    # --- fingerprint + cache ---
    from mixlift.modeling.defaults import MCP_CONFIG

    _csv_bytes = csv_file.read_bytes()
    _disk_fp = compute_model_fingerprint(_csv_bytes, channel_columns, MCP_CONFIG)

    mmm = None
    X_fit = None  # noqa: N806

    # Try in-memory cache first
    if _disk_fp in _MODEL_CACHE:
        _mem = _MODEL_CACHE[_disk_fp]
        mmm = _mem["mmm"]
        X_fit = _mem["X"]  # noqa: N806
        await _log(f"Cache hit (in-memory) — loaded model ({_disk_fp}).")
    else:
        # Try disk cache
        _disk_entry = await _disk_load_model(_disk_fp)
        if _disk_entry is not None:
            _MODEL_CACHE[_disk_fp] = _disk_entry
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]
            mmm = _disk_entry["mmm"]
            X_fit = _disk_entry["X"]  # noqa: N806
            await _log(f"Cache hit (disk) — loaded model ({_disk_fp}).")

    if mmm is None:
        # Cold start: fit model
        await _log(
            "Fitting Bayesian model via MCMC sampling (~30-60s)... "
            "Building a statistical model of how each channel drives revenue."
        )
        _reporter.phase("Fitting model (MCMC sampling)", 3, 7)
        model_results = await asyncio.to_thread(_run_pipeline, X, y, channel_columns, _reporter)
        elapsed = _time.monotonic() - t0
        await _log(f"MCMC complete in {elapsed:.1f}s.")

        mmm = model_results.mmm
        X_fit = X  # noqa: N806

        # Persist to disk and in-memory caches
        _MODEL_CACHE[_disk_fp] = {
            "mmm": mmm,
            "X": X_fit,
            "channel_columns": channel_columns,
            "model_results": model_results,
        }
        if len(_MODEL_CACHE) > 3:
            oldest_key = next(iter(_MODEL_CACHE))
            del _MODEL_CACHE[oldest_key]

        asyncio.ensure_future(
            _disk_save_model(
                _disk_fp,
                mmm=mmm,
                X=X_fit,
                channel_columns=channel_columns,
                result={},
                mcmc_config=MCP_CONFIG,
            )
        )

    # --- Extract curves + marginal ROAS ---
    _reporter.phase("Computing saturation curves", 5, 7)
    await _log("Extracting saturation curves and marginal ROAS...")

    saturation_curves: dict = await asyncio.to_thread(
        _run_saturation_curves, mmm, X_fit, channel_columns
    )
    mroas_means: dict
    mroas_cis: dict
    mroas_means, mroas_cis = await asyncio.to_thread(
        _run_marginal_roas, mmm, X_fit, channel_columns
    )

    # --- Build per-channel output ---
    from mixlift.modeling.optimizer import format_channel_name as _fmt_name

    channel_output: list[dict] = []
    for raw_col in channel_columns:
        display = _fmt_name(raw_col)
        current_spend_wk = float(X_fit[raw_col].mean()) if raw_col in X_fit.columns else 0.0
        training_max = float(X_fit[raw_col].max()) if raw_col in X_fit.columns else 0.0

        curve = saturation_curves.get(display, {"spend": [], "response": []})
        mroas_mean = mroas_means.get(display, 0.0)
        mroas_ci_raw = mroas_cis.get(display, (0.0, 0.0))

        ch_dict = build_channel_saturation(
            channel_raw=raw_col,
            current_spend_wk=current_spend_wk,
            curve=curve,
            marginal_roas_mean=mroas_mean,
            marginal_roas_ci=mroas_ci_raw,
            increment_steps=_steps,
            training_max_spend=training_max,
        )
        channel_output.append(ch_dict)

    # --- Build result dict ---
    result_dict: dict = {
        "tool": "mixlift_saturation",
        "version": "0.5.3",
        "mcmc_config": MCP_CONFIG,
        "data_window": data_window,
        "channels": channel_output,
        "_skipped_channels": _skipped_channels,
    }

    # --- Render memo ---
    try:
        from mixlift_mcp.renderers.saturation_memo import render_saturation_memo as _render_sat

        result_dict["memo_markdown"] = _render_sat(result_dict)
    except Exception as exc:
        logger.warning("render_saturation_memo failed: %s", exc)
        result_dict["memo_markdown"] = ""

    # Strip internal key before returning
    result_dict.pop("_skipped_channels", None)

    await _log("Saturation analysis complete.")
    return json.dumps(result_dict, indent=2, default=str)


def _run_channel_contributions(
    mmm: Any,
    X: Any,
    channel_columns: list[str],  # noqa: N803
) -> tuple[dict, dict]:
    """Wrapper for extract_channel_contributions (enables easy mocking in tests)."""
    from mixlift.modeling.engine import extract_channel_contributions

    return extract_channel_contributions(mmm, X, channel_columns)


@mcp.tool()
async def mixlift_decompose(
    csv_path: str,
    license_key: str | None = None,
    period: str = "last_4_weeks",
    channels: list[str] | None = None,
    mcmc_config: str = "default",
    ctx: Context | None = None,
) -> str:
    """Split revenue into baseline vs paid-attributable, channel by channel, for a period.

    Use when the user needs a defensible attribution answer — "what did paid actually
    drive?" — anchored to observed revenue with credible intervals. Best for CFO-grade
    reporting and onboarding new clients who are skeptical of platform numbers.

    Do NOT use for comparing this period to last period (use mixlift_wow). Do NOT use
    for live channel-by-channel status (use mixlift_analyze or mixlift_saturation).

    Fires on questions like: "What did paid actually drive last 4 weeks?"

    Args:
        csv_path: Path to a wide-format CSV (same as mixlift_analyze).
        license_key: MixLift Growth license key. Free tier: 2 channels, 2,000 rows.
        period: Window to decompose. One of "last_week", "last_4_weeks",
            "last_quarter", "full_period". Default: "last_4_weeks".
        channels: Restrict to these channel column names. Defaults to all.
        mcmc_config: MCMC preset. Ignored when a cached model exists.

    Returns:
        JSON string with: total_revenue, baseline block (revenue + pct + CI),
        paid_total block, per-channel block (contribution, pct, spend, ROAS, CI),
        and memo_markdown.

    Presentation: surface memo_markdown verbatim. No emoji, no table restructuring.
    """
    import time as _time  # noqa: I001, PLC0415

    from mixlift_mcp.model_cache import (
        compute_model_fingerprint,
        load_model as _disk_load_model,
        save_model as _disk_save_model,
    )
    from mixlift_mcp.progress import ProgressReporter
    from mixlift_mcp.renderers.decompose_memo import (
        VALID_PERIODS,
        _PERIOD_DISPLAY,
        _PERIOD_WEEKS,
        build_decompose_result,
        render_decompose_memo,
    )

    _step = 0

    async def _log(msg: str) -> None:
        nonlocal _step
        _step += 1
        logger.info(msg)
        if ctx:
            try:
                await ctx.report_progress(_step, 7, msg)
            except Exception:
                pass

    t0 = _time.monotonic()
    _loop = asyncio.get_running_loop()
    _reporter = ProgressReporter(ctx, _loop)

    # --- Validate period ---
    if period not in VALID_PERIODS:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    f"Invalid period '{period}'. Valid options: {', '.join(VALID_PERIODS)}"
                ),
            }
        )

    await _log("Validating license...")
    license_status = await _resolve_license(license_key or "", ctx)

    # --- Path validation ---
    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

    try:
        df = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    _reporter.phase("Validating CSV and detecting channels", 1, 7)
    await _log(f"CSV loaded ({len(df)} rows). Detecting format...")

    csv_format = _detect_csv_format(df)
    try:
        if csv_format == "wide":
            X, y, all_channel_columns = _load_wide_format(df)  # noqa: N806
        else:
            X, y, all_channel_columns = _load_platform_csv(df, csv_format)  # noqa: N806
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    n_channels = len(all_channel_columns)
    n_rows = len(X)
    try:
        _enforce_tier_limits(license_status, n_channels, n_rows)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    # --- Channel filter (warn-and-skip for unknown channels) ---
    _skipped_channels: list[str] = []
    if channels is not None:
        channel_columns = [c for c in channels if c in all_channel_columns]
        _skipped_raw = [c for c in channels if c not in all_channel_columns]
        if _skipped_raw:
            _skipped_channels = _skipped_raw
            logger.warning("mixlift_decompose: unknown channels skipped: %s", _skipped_raw)
    else:
        channel_columns = all_channel_columns

    if not channel_columns:
        return json.dumps(
            {"status": "error", "message": "No valid channels found after filtering."}
        )

    # --- Data window ---
    try:
        _dates = pd.to_datetime(X["date"] if "date" in X.columns else df["date"])
        _start_all = _dates.min()
        _end_all = _dates.max()
        _weeks_total = round((_end_all - _start_all).days / 7)
        data_window = (
            f"{_start_all.strftime('%Y-%m-%d')} to "
            f"{_end_all.strftime('%Y-%m-%d')} ({_weeks_total} weeks)"
        )
    except Exception:
        _weeks_total = len(X)
        data_window = ""

    # --- Resolve period window ---
    period_weeks_req = _PERIOD_WEEKS[period]
    if period_weeks_req is None:
        # full_period
        period_weeks = _weeks_total
    else:
        period_weeks = period_weeks_req

    if period_weeks_req is not None and period_weeks > _weeks_total:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    f"Period '{period}' requires {period_weeks} weeks "
                    f"but fit window is only {_weeks_total} weeks"
                ),
            }
        )

    # --- Fingerprint + cache ---
    from mixlift.modeling.defaults import MCP_CONFIG

    _csv_bytes = csv_file.read_bytes()
    _disk_fp = compute_model_fingerprint(_csv_bytes, channel_columns, MCP_CONFIG)

    mmm = None
    X_fit = None  # noqa: N806
    y_fit: pd.Series | None = None

    # Try in-memory cache first
    if _disk_fp in _MODEL_CACHE:
        _mem = _MODEL_CACHE[_disk_fp]
        mmm = _mem["mmm"]
        X_fit = _mem["X"]  # noqa: N806
        y_fit = _mem.get("y")
        await _log(f"Cache hit (in-memory) — loaded model ({_disk_fp}).")
    else:
        _disk_entry = await _disk_load_model(_disk_fp)
        if _disk_entry is not None:
            _MODEL_CACHE[_disk_fp] = _disk_entry
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]
            mmm = _disk_entry["mmm"]
            X_fit = _disk_entry["X"]  # noqa: N806
            y_fit = _disk_entry.get("y")
            await _log(f"Cache hit (disk) — loaded model ({_disk_fp}).")

    if mmm is None:
        await _log(
            "Fitting Bayesian model via MCMC sampling (~30-60s)... "
            "Building a statistical model of how each channel drives revenue."
        )
        _reporter.phase("Fitting model (MCMC sampling)", 3, 7)
        model_results = await asyncio.to_thread(_run_pipeline, X, y, channel_columns, _reporter)
        elapsed = _time.monotonic() - t0
        await _log(f"MCMC complete in {elapsed:.1f}s.")

        mmm = model_results.mmm
        X_fit = X  # noqa: N806
        y_fit = y

        _MODEL_CACHE[_disk_fp] = {
            "mmm": mmm,
            "X": X_fit,
            "y": y_fit,
            "channel_columns": channel_columns,
            "model_results": model_results,
        }
        if len(_MODEL_CACHE) > 3:
            oldest_key = next(iter(_MODEL_CACHE))
            del _MODEL_CACHE[oldest_key]

        asyncio.ensure_future(
            _disk_save_model(
                _disk_fp,
                mmm=mmm,
                X=X_fit,
                y=y_fit,
                channel_columns=channel_columns,
                result={},
                mcmc_config=MCP_CONFIG,
            )
        )

    # --- Extract contributions ---
    _reporter.phase("Computing channel contributions", 5, 7)
    await _log("Extracting channel contributions...")

    means_dict: dict
    cis_dict: dict
    means_dict, cis_dict = await asyncio.to_thread(
        _run_channel_contributions, mmm, X_fit, channel_columns
    )

    # --- Resolve y for the full fit window ---
    # Priority: 1. y threaded from loader  2. mmm.y attribute (old cache entries)
    if y_fit is None:
        if hasattr(mmm, "y") and mmm.y is not None:
            y_fit = pd.Series(mmm.y.values if hasattr(mmm.y, "values") else mmm.y)
            y_fit.index = X_fit.index
        else:
            return json.dumps(
                {
                    "status": "error",
                    "message": (
                        "Model cache is from an older MixLift version; "
                        "please re-run mixlift_analyze to refresh."
                    ),
                }
            )

    # --- Slice data to period window ---
    try:
        _date_col = "date" if "date" in X_fit.columns else X_fit.columns[0]
        _fit_dates = pd.to_datetime(X_fit[_date_col])
        _period_end = _fit_dates.max()
        _period_start = _period_end - pd.Timedelta(weeks=period_weeks)
        # For full_period, include everything
        if period == "full_period":
            _mask = pd.Series([True] * len(X_fit), index=X_fit.index)
        else:
            _mask = _fit_dates > _period_start

        X_period = X_fit[_mask]  # noqa: N806
        period_label = (
            f"{_PERIOD_DISPLAY[period]} "
            f"({(_period_start + pd.Timedelta(days=1)).strftime('%Y-%m-%d')} "
            f"to {_period_end.strftime('%Y-%m-%d')})"
            if period != "full_period"
            else f"Full period ({_fit_dates.min().strftime('%Y-%m-%d')} to {_period_end.strftime('%Y-%m-%d')})"
        )
    except Exception:
        X_period = X_fit  # noqa: N806
        _mask = pd.Series([True] * len(X_fit), index=X_fit.index)
        period_label = _PERIOD_DISPLAY[period]

    # --- Scale contributions to the period slice ---
    # contributions from the extractor are sums over the full fit window.
    # Scale them proportionally by the fraction of rows in the period.
    n_full = len(X_fit)
    n_period = len(X_period)
    scale = n_period / n_full if n_full > 0 else 1.0

    from mixlift.modeling.optimizer import format_channel_name as _fmt_name

    scaled_means: dict[str, float] = {}
    scaled_cis: dict[str, tuple[float, float]] = {}
    spend_dict: dict[str, float] = {}

    for raw_col in channel_columns:
        display = _fmt_name(raw_col)
        scaled_means[display] = means_dict.get(display, 0.0) * scale
        raw_ci = cis_dict.get(display, (0.0, 0.0))
        scaled_cis[display] = (raw_ci[0] * scale, raw_ci[1] * scale)
        spend_dict[display] = float(X_period[raw_col].sum()) if raw_col in X_period.columns else 0.0

    # --- Compute total revenue for period from observed y ---
    # y_fit is aligned to X_fit's index; _mask selects the period rows.
    total_revenue = float(y_fit[_mask].sum())

    # --- Build result ---
    result_dict = build_decompose_result(
        period=period,
        period_weeks=period_weeks,
        period_label=period_label,
        data_window=data_window,
        total_revenue=total_revenue,
        means_dict=scaled_means,
        cis_dict=scaled_cis,
        spend_dict=spend_dict,
        channel_columns=channel_columns,
        mcmc_config=MCP_CONFIG,
        skipped_channels=_skipped_channels,
    )

    # --- Render memo ---
    try:
        result_dict["memo_markdown"] = render_decompose_memo(result_dict)
    except Exception as exc:
        logger.warning("render_decompose_memo failed: %s", exc)
        result_dict["memo_markdown"] = ""

    # Strip internal key before returning
    result_dict.pop("_skipped_channels", None)

    await _log("Revenue decomposition complete.")
    return json.dumps(result_dict, indent=2, default=str)


@mcp.tool()
async def mixlift_wow(
    csv_path: str,
    license_key: str | None = None,
    period: str = "week",
    mcmc_config: str = "default",
) -> str:
    """Diagnose why revenue moved this period vs the prior period, channel by channel.

    Use when the user asks why revenue went up or down week-over-week. Decomposes the
    total delta per channel into two effects: spend effect (you spent more or less)
    and efficiency effect (marginal ROAS shifted). Surfaces the biggest movers first.

    Do NOT use for absolute attribution across a period (use mixlift_decompose). Do
    NOT use for scenario planning (use mixlift_scenarios).

    Fires on questions like: "Why did revenue drop this week?"

    Args:
        csv_path: Path to a wide-format CSV (same as mixlift_analyze).
        license_key: MixLift Growth license key. Free tier: 2 channels, 2,000 rows.
        period: Comparison window. One of "week", "4_weeks", "quarter".
            Default: "week".
        mcmc_config: MCMC preset. Ignored when a cached model exists.

    Returns:
        JSON string with: current/prior revenue, baseline + paid totals with deltas,
        per-channel block (contribution_current, contribution_prior, delta,
        spend_effect, efficiency_effect, marginal ROAS both periods), memo_markdown.

    Presentation: surface memo_markdown verbatim. No emoji, no table restructuring.
    """
    import time as _time  # noqa: I001, PLC0415

    from mixlift_mcp.model_cache import (
        compute_model_fingerprint,
        load_model as _disk_load_model,
        save_model as _disk_save_model,
    )
    from mixlift_mcp.renderers.wow_memo import (
        VALID_PERIODS,
        _PERIOD_MIN_WEEKS,
        _PERIOD_WEEKS,
        build_wow_result,
        render_wow_memo,
    )

    t0 = _time.monotonic()

    # --- Validate period ---
    if period not in VALID_PERIODS:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    f"Invalid period '{period}'. "
                    f"Valid options: {', '.join(VALID_PERIODS)}"
                ),
            }
        )

    # --- License ---
    license_status = await _resolve_license(license_key or "", None)

    # --- Path validation ---
    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

    try:
        df = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    csv_format = _detect_csv_format(df)
    try:
        if csv_format == "wide":
            X, y, channel_columns = _load_wide_format(df)  # noqa: N806
        else:
            X, y, channel_columns = _load_platform_csv(df, csv_format)  # noqa: N806
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    n_channels = len(channel_columns)
    n_rows = len(X)
    try:
        _enforce_tier_limits(license_status, n_channels, n_rows)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    # --- Data window ---
    try:
        _dates = pd.to_datetime(X["date"] if "date" in X.columns else df["date"])
        _start_all = _dates.min()
        _end_all = _dates.max()
        _weeks_total = round((_end_all - _start_all).days / 7)
        data_window = (
            f"{_start_all.strftime('%Y-%m-%d')} to "
            f"{_end_all.strftime('%Y-%m-%d')} ({_weeks_total} weeks)"
        )
    except Exception:
        _weeks_total = len(X)
        data_window = ""

    # --- Check data is long enough for the chosen period ---
    _period_weeks = _PERIOD_WEEKS[period]
    _min_weeks = _PERIOD_MIN_WEEKS[period]
    if _weeks_total < _min_weeks:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    f"Period '{period}' requires at least {_min_weeks} weeks of data "
                    f"but the CSV only has ~{_weeks_total} weeks. "
                    f"Provide a longer dataset or choose a shorter period."
                ),
            }
        )

    # --- Fingerprint + cache ---
    from mixlift.modeling.defaults import MCP_CONFIG

    _csv_bytes = csv_file.read_bytes()
    _disk_fp = compute_model_fingerprint(_csv_bytes, channel_columns, MCP_CONFIG)

    mmm = None
    X_fit = None  # noqa: N806
    y_fit: pd.Series | None = None

    if _disk_fp in _MODEL_CACHE:
        _mem = _MODEL_CACHE[_disk_fp]
        mmm = _mem["mmm"]
        X_fit = _mem["X"]  # noqa: N806
        y_fit = _mem.get("y")
    else:
        _disk_entry = await _disk_load_model(_disk_fp)
        if _disk_entry is not None:
            _MODEL_CACHE[_disk_fp] = _disk_entry
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]
            mmm = _disk_entry["mmm"]
            X_fit = _disk_entry["X"]  # noqa: N806
            y_fit = _disk_entry.get("y")

    if mmm is None:
        model_results = await asyncio.to_thread(_run_pipeline, X, y, channel_columns, None)
        elapsed = _time.monotonic() - t0
        logger.info("mixlift_wow: MCMC complete in %.1fs.", elapsed)
        mmm = model_results.mmm
        X_fit = X  # noqa: N806
        y_fit = y
        _MODEL_CACHE[_disk_fp] = {
            "mmm": mmm,
            "X": X_fit,
            "y": y_fit,
            "channel_columns": channel_columns,
            "model_results": model_results,
            "result": {},
        }
        if len(_MODEL_CACHE) > 3:
            oldest_key = next(iter(_MODEL_CACHE))
            del _MODEL_CACHE[oldest_key]
        asyncio.ensure_future(
            _disk_save_model(
                _disk_fp,
                mmm=mmm,
                X=X_fit,
                y=y_fit,
                channel_columns=channel_columns,
                result={},
                mcmc_config=MCP_CONFIG,
            )
        )

    # --- Resolve y ---
    if y_fit is None:
        if hasattr(mmm, "y") and mmm.y is not None:
            y_fit = pd.Series(mmm.y.values if hasattr(mmm.y, "values") else mmm.y)
            y_fit.index = X_fit.index
        else:
            return json.dumps(
                {
                    "status": "error",
                    "message": (
                        "Model cache is from an older MixLift version; "
                        "please re-run mixlift_analyze to refresh."
                    ),
                }
            )

    # --- Slice into current and prior windows ---
    try:
        _date_col = "date" if "date" in X_fit.columns else X_fit.columns[0]
        _fit_dates = pd.to_datetime(X_fit[_date_col])
        _end_date = _fit_dates.max()

        _curr_start = _end_date - pd.Timedelta(weeks=_period_weeks) + pd.Timedelta(days=1)
        _prior_end = _curr_start - pd.Timedelta(days=1)
        _prior_start = _prior_end - pd.Timedelta(weeks=_period_weeks) + pd.Timedelta(days=1)

        _curr_mask = (_fit_dates >= _curr_start) & (_fit_dates <= _end_date)
        _prior_mask = (_fit_dates >= _prior_start) & (_fit_dates <= _prior_end)

        X_curr = X_fit[_curr_mask]  # noqa: N806
        X_prior = X_fit[_prior_mask]  # noqa: N806
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to slice data: {e}"})

    # --- Extract contributions for both windows ---
    _curr_means, _ = await asyncio.to_thread(
        _run_wow_channel_contributions, mmm, X_curr, channel_columns
    )
    _prior_means, _ = await asyncio.to_thread(
        _run_wow_channel_contributions, mmm, X_prior, channel_columns
    )

    # --- Revenue from observed y ---
    _y_series = (
        y_fit if hasattr(y_fit, "loc") else pd.Series(y_fit, index=X_fit.index)
    )
    _curr_rev = float(_y_series[_curr_mask].sum())
    _prior_rev = float(_y_series[_prior_mask].sum())

    # --- Spend per period ---
    from mixlift.modeling.optimizer import format_channel_name as _fmt_name

    _curr_spend: dict[str, float] = {}
    _prior_spend: dict[str, float] = {}
    for _raw_col in channel_columns:
        _disp = _fmt_name(_raw_col)
        _curr_spend[_disp] = (
            float(X_curr[_raw_col].sum()) if _raw_col in X_curr.columns else 0.0
        )
        _prior_spend[_disp] = (
            float(X_prior[_raw_col].sum()) if _raw_col in X_prior.columns else 0.0
        )

    # --- Period label ---
    _period_label_str = (
        f"Last {_period_weeks} week(s) "
        f"({_curr_start.strftime('%Y-%m-%d')} to {_end_date.strftime('%Y-%m-%d')}) "
        f"vs prior "
        f"({_prior_start.strftime('%Y-%m-%d')} to {_prior_end.strftime('%Y-%m-%d')})"
    )

    # --- Build result ---
    result_dict = build_wow_result(
        period=period,
        period_label=_period_label_str,
        data_window=data_window,
        current_revenue=_curr_rev,
        prior_revenue=_prior_rev,
        current_means=_curr_means,
        prior_means=_prior_means,
        current_spend=_curr_spend,
        prior_spend=_prior_spend,
        channel_columns=channel_columns,
        mcmc_config=MCP_CONFIG,
    )

    # --- Render memo ---
    try:
        result_dict["memo_markdown"] = render_wow_memo(result_dict)
    except Exception as exc:
        logger.warning("render_wow_memo failed: %s", exc)
        result_dict["memo_markdown"] = ""

    elapsed_total = _time.monotonic() - t0
    logger.info("mixlift_wow: complete in %.1fs.", elapsed_total)

    return json.dumps(result_dict, indent=2, default=str)


@mcp.tool()
async def mixlift_prepare(
    csv_path: str,
    date_col: str = "",
    channel_col: str = "",
    spend_col: str = "",
    revenue_col: str = "",
    ctx: Context | None = None,
) -> str:
    """Convert a non-standard marketing CSV into the wide format mixlift_analyze expects.

    Use BEFORE mixlift_analyze when the user's file is campaign-level, long/tidy, or
    a raw platform export with non-standard column names. Handles pivoting, aggregation,
    and column renaming automatically; column overrides are available when auto-detect
    fails. Also preserves platform-reported revenue columns (Meta, Google, TikTok) so
    mixlift_reconcile can use them later.

    Do NOT use if the CSV is already in wide format (date + {channel}_spend + revenue).
    mixlift_analyze will detect wide format and skip prepare automatically.

    Fires on questions like: "Here's my Meta campaign export — can you prep it for MMM?"

    Args:
        csv_path: Path to the raw CSV file.
        date_col: Override for the date column name. Auto-detected if empty.
        channel_col: Override for the channel/platform column name. Auto-detected if empty.
        spend_col: Override for the spend/cost column name. Auto-detected if empty.
        revenue_col: Override for the revenue/sales/target column name. Auto-detected if empty.

    Returns:
        JSON string with: output_path (ready to pass to mixlift_analyze), schema summary,
        row/column counts, and optional platform_revenue_hint when platform-reported
        revenue columns are detected (surfaces the N9 attribution comparison feature).
    """
    # Validate path
    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

    try:
        df = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    cols = list(df.columns)
    cols_lower = {c.lower(): c for c in cols}

    if ctx:
        try:
            await ctx.report_progress(1, 4, f"Loaded CSV: {len(df)} rows, {len(cols)} columns")
        except Exception:
            pass

    # --- Check if already in wide format ---
    spend_cols_existing = [c for c in cols if c.lower().endswith("_spend")]
    has_revenue = any(c in cols_lower for c in ("revenue", "target", "sales"))
    if len(spend_cols_existing) >= 2 and has_revenue:
        from mixlift_mcp.renderers.reconcile_memo import normalise_platform_revenue_columns

        _wide_plat_cols = normalise_platform_revenue_columns(cols)
        _plat_col_list = [v for v in _wide_plat_cols.values()]
        _already_wide_next: list[dict] = [
            {
                "tool": "mixlift_analyze",
                "description": "Run MMM analysis on this data",
                "params": {"csv_path": csv_path},
            },
        ]
        if _wide_plat_cols:
            _already_wide_next.append(
                {
                    "tool": "mixlift_reconcile",
                    "description": "Compare platform-reported vs MMM revenue attribution",
                    "params": {"csv_path": csv_path},
                }
            )
        return json.dumps(
            {
                "status": "already_wide",
                "message": "This CSV is already in MixLift wide format. Pass it directly to mixlift_analyze.",
                "output_path": str(csv_file),
                "channels": [c.replace("_spend", "") for c in spend_cols_existing],
                "platform_revenue_columns": _plat_col_list,
                "next_actions": _already_wide_next,
            }
        )

    # --- Auto-detect columns ---
    def _find_col(candidates: list[str], override: str = "") -> str | None:
        if override:
            # Exact or case-insensitive match
            if override in cols:
                return override
            for c in cols:
                if c.lower() == override.lower():
                    return c
            return None
        for candidate in candidates:
            for c in cols:
                if c.lower() == candidate.lower():
                    return c
        # Substring fallback
        for candidate in candidates:
            for c in cols:
                if candidate.lower() in c.lower():
                    return c
        return None

    detected_date = _find_col(
        ["date", "day", "week", "month", "period", "report_date", "campaign_date"],
        override=date_col,
    )
    detected_channel = _find_col(
        [
            "channel",
            "channel_used",
            "platform",
            "source",
            "medium",
            "campaign_type",
            "ad_channel",
            "traffic_source",
            "utm_source",
            "network",
            "publisher",
        ],
        override=channel_col,
    )
    detected_spend = _find_col(
        [
            "spend",
            "cost",
            "acquisition_cost",
            "ad_spend",
            "media_spend",
            "amount_spent",
            "total_cost",
            "budget",
            "investment",
        ],
        override=spend_col,
    )
    detected_revenue = _find_col(
        [
            "revenue",
            "sales",
            "target",
            "income",
            "conversion_value",
            "total_revenue",
            "value",
            "gmv",
            "roi",
        ],
        override=revenue_col,
    )

    errors = []
    if not detected_date:
        errors.append("Could not detect a date column. Provide date_col parameter.")
    if not detected_channel:
        errors.append("Could not detect a channel/platform column. Provide channel_col parameter.")
    if not detected_spend:
        errors.append("Could not detect a spend/cost column. Provide spend_col parameter.")

    if errors:
        return json.dumps(
            {
                "status": "error",
                "message": "Column auto-detection failed:\n"
                + "\n".join(f"  - {e}" for e in errors),
                "columns_found": cols,
                "hint": "Re-run with explicit date_col, channel_col, and spend_col parameters.",
            }
        )

    if ctx:
        try:
            await ctx.report_progress(
                2,
                4,
                f"Detected: date={detected_date}, channel={detected_channel}, "
                f"spend={detected_spend}, revenue={detected_revenue or 'none'}",
            )
        except Exception:
            pass

    # --- Transform to wide format ---
    work = df.copy()

    # Parse dates
    try:
        work["_date"] = pd.to_datetime(work[detected_date])
    except Exception as e:
        return json.dumps(
            {"status": "error", "message": f"Could not parse dates in '{detected_date}': {e}"}
        )

    # Parse spend (handle currency strings like "$16,174.00")
    try:
        spend_series = work[detected_spend]
        if spend_series.dtype == object:
            spend_series = spend_series.str.replace(r"[$,€£¥]", "", regex=True)
        work["_spend"] = pd.to_numeric(spend_series, errors="coerce").fillna(0)
    except Exception as e:
        return json.dumps(
            {"status": "error", "message": f"Could not parse spend in '{detected_spend}': {e}"}
        )

    # Parse revenue if available, otherwise derive from ROI if possible
    has_direct_revenue = False
    if detected_revenue:
        rev_col_lower = detected_revenue.lower()
        if rev_col_lower == "roi":
            # ROI column — derive revenue as spend * ROI
            try:
                work["_revenue"] = work["_spend"] * pd.to_numeric(
                    work[detected_revenue], errors="coerce"
                ).fillna(0)
                has_direct_revenue = True
            except Exception:
                pass
        else:
            try:
                rev_series = work[detected_revenue]
                if rev_series.dtype == object:
                    rev_series = rev_series.str.replace(r"[$,€£¥]", "", regex=True)
                work["_revenue"] = pd.to_numeric(rev_series, errors="coerce").fillna(0)
                has_direct_revenue = True
            except Exception:
                pass

    if not has_direct_revenue:
        # Check if there's an ROI column we can use as fallback
        roi_col = _find_col(["roi", "roas", "return_on_investment"])
        if roi_col and roi_col != detected_revenue:
            work["_revenue"] = work["_spend"] * pd.to_numeric(
                work[roi_col], errors="coerce"
            ).fillna(0)
            has_direct_revenue = True

    if not has_direct_revenue:
        return json.dumps(
            {
                "status": "error",
                "message": "Could not detect or compute a revenue column. "
                "Provide revenue_col (e.g. 'revenue', 'sales') or ensure an ROI column exists.",
                "columns_found": cols,
            }
        )

    # Aggregate to weekly by channel
    work["_week"] = work["_date"].dt.to_period("W").dt.start_time
    channel_series = work[detected_channel].astype(str).str.strip()

    # Clean channel names for column headers
    def _clean_channel_name(name: str) -> str:
        import re

        clean = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
        return clean

    work["_channel_clean"] = channel_series.apply(_clean_channel_name)

    # Pivot spend by channel
    weekly_spend = work.groupby(["_week", "_channel_clean"])["_spend"].sum().reset_index()
    wide_spend = weekly_spend.pivot(
        index="_week", columns="_channel_clean", values="_spend"
    ).fillna(0)
    wide_spend.columns = [f"{c}_spend" for c in wide_spend.columns]

    # Aggregate revenue by week (sum across all rows, not just paid channels)
    weekly_revenue = work.groupby("_week")["_revenue"].sum().reset_index()
    weekly_revenue.columns = ["_week", "revenue"]

    result_df = wide_spend.reset_index().merge(weekly_revenue, on="_week")
    result_df = result_df.rename(columns={"_week": "date"})

    # Sort by date
    result_df = result_df.sort_values("date").reset_index(drop=True)

    if ctx:
        try:
            await ctx.report_progress(
                3, 4, f"Transformed: {len(result_df)} weeks, {len(wide_spend.columns)} channels"
            )
        except Exception:
            pass

    # Drop channels with zero total spend
    spend_columns = [c for c in result_df.columns if c.endswith("_spend")]
    zero_channels = [c for c in spend_columns if result_df[c].sum() == 0]
    if zero_channels:
        result_df = result_df.drop(columns=zero_channels)
        spend_columns = [c for c in spend_columns if c not in zero_channels]

    # Validate minimum requirements
    if len(spend_columns) < 2:
        return json.dumps(
            {
                "status": "error",
                "message": f"Only {len(spend_columns)} channel(s) found after aggregation. "
                f"MixLift requires at least 2 channels.",
                "channels": [c.replace("_spend", "") for c in spend_columns],
            }
        )

    if len(result_df) < 13:
        return json.dumps(
            {
                "status": "error",
                "message": f"Only {len(result_df)} weeks of data after aggregation. "
                f"MixLift requires at least 13 weeks (90 days).",
            }
        )

    # Save output
    out_path = csv_file.parent / f"{csv_file.stem}_mixlift_ready.csv"
    result_df.to_csv(out_path, index=False)

    channels = [c.replace("_spend", "") for c in spend_columns]

    if ctx:
        try:
            await ctx.report_progress(4, 4, "Preparation complete")
        except Exception:
            pass

    # --- Platform-revenue hint (N9 attribution comparison nudge) ---
    from mixlift.ingest.service import detect_platform
    from mixlift.ingest.templates import PLATFORM_SIGNATURES

    platform_revenue_col: str | None = None
    platform_revenue_hint: str | None = None

    detected_platform = detect_platform(df)

    if detected_platform in ("meta", "google", "tiktok"):
        # Long-format: check original df columns against platform revenue aliases
        revenue_aliases = PLATFORM_SIGNATURES[detected_platform]["columns"].get("revenue", [])
        lower_cols = {c.lower().strip(): c for c in df.columns}
        for alias in revenue_aliases:
            if alias.lower().strip() in lower_cols:
                platform_revenue_col = lower_cols[alias.lower().strip()]
                break
        if platform_revenue_col:
            _platform_names = {"meta": "Meta", "google": "Google", "tiktok": "TikTok"}
            platform_name = _platform_names[detected_platform]
            platform_revenue_hint = (
                f"Detected {platform_name} platform-reported revenue in column "
                f"`{platform_revenue_col}`. When you run `mixlift_analyze`, MixLift "
                f"will compare {platform_name}'s self-reported ROAS to MMM-measured ROAS -- "
                f"this is often the most useful finding."
            )
    else:
        # Wide-format: scan for {channel}_platform_revenue columns
        from mixlift.ingest.platform_revenue import detect_platform_revenue_columns

        wide_detections = detect_platform_revenue_columns(result_df)
        if wide_detections:
            platform_revenue_col = "wide-format (multiple columns)"
            platform_revenue_hint = (
                "Detected platform-reported revenue columns in your CSV. When you run "
                "`mixlift_analyze`, MixLift will compare your platforms' self-reported "
                "ROAS to MMM-measured ROAS -- this is often the most useful finding."
            )

    # --- Detect platform_reported_revenue columns for reconcile ---
    from mixlift_mcp.renderers.reconcile_memo import (
        normalise_platform_revenue_columns as _norm_plat,
    )

    _norm_plat_result = _norm_plat(list(result_df.columns))
    _platform_revenue_columns = list(_norm_plat_result.values())

    next_actions: list[dict] = [
        {
            "tool": "mixlift_analyze",
            "description": "Run MMM analysis on the prepared data",
            "params": {"csv_path": str(out_path)},
        },
    ]
    if platform_revenue_hint:
        next_actions.insert(
            0,
            {
                "action": "run_analysis_with_platform_comparison",
                "description": "Run mixlift_analyze to see platform vs MMM ROAS comparison",
            },
        )
    if _platform_revenue_columns:
        next_actions.append(
            {
                "tool": "mixlift_reconcile",
                "description": "Compare platform-reported vs MMM revenue attribution",
                "params": {"csv_path": str(out_path)},
            }
        )

    response: dict = {
        "status": "success",
        "output_path": str(out_path),
        "message": f"Prepared {len(result_df)} weeks of data with {len(channels)} channels. "
        f"Pass output_path to mixlift_analyze.",
        "channels": channels,
        "date_range": f"{result_df['date'].min()} to {result_df['date'].max()}",
        "rows": len(result_df),
        "columns_detected": {
            "date": detected_date,
            "channel": detected_channel,
            "spend": detected_spend,
            "revenue": detected_revenue,
        },
        "platform_revenue_columns": _platform_revenue_columns,
        "next_actions": next_actions,
    }
    if platform_revenue_hint:
        response["platform_revenue_hint"] = platform_revenue_hint

    return json.dumps(response)


@mcp.tool()
async def mixlift_reconcile(
    csv_path: str,
    license_key: str | None = None,
    period: str = "last_4_weeks",
    mcmc_config: str = "default",
) -> str:
    """Surface the gap between what platforms claim and what MMM actually credits.

    Use when the user wants to reconcile dashboard ROAS against MMM attribution —
    "Meta says 4.2×, you say 1.5×, what's the $68k gap?" Requires the wide-format
    CSV to include platform-reported revenue columns: <channel>_platform_reported_revenue
    (aliases: <channel>_reported_revenue, <channel>_platform_revenue). These are
    preserved automatically when mixlift_prepare processes a platform export.

    Do NOT use to get overall ROAS or budget recommendations (use mixlift_analyze).
    Only use when platform-reported columns are available in the CSV.

    Fires on questions like: "Reconcile my Meta dashboard numbers against the MMM."

    Args:
        csv_path: Wide-format CSV that includes <channel>_platform_reported_revenue cols.
        license_key: MixLift Growth license key. Free tier: 2 channels, 2,000 rows.
        period: Time window. One of "last_week", "last_4_weeks", "last_quarter",
            "full_period". Default: "last_4_weeks".
        mcmc_config: MCMC preset. Ignored when a cached model exists.

    Returns:
        JSON string with: platform vs MMM totals + gap, per-channel block (platform
        revenue, MMM revenue + CI, gap $/%,  verdict, both ROAS figures), memo_markdown.

    Presentation: surface memo_markdown verbatim. No emoji, no table restructuring.
    """
    import time as _time  # noqa: I001, PLC0415

    from mixlift_mcp.model_cache import (
        compute_model_fingerprint,
        load_model as _disk_load_model,
        save_model as _disk_save_model,
    )
    from mixlift_mcp.renderers.decompose_memo import (
        VALID_PERIODS,
        _PERIOD_DISPLAY,
        _PERIOD_WEEKS,
    )
    from mixlift_mcp.renderers.reconcile_memo import (
        build_reconcile_result,
        normalise_platform_revenue_columns,
        render_reconcile_memo,
    )

    t0 = _time.monotonic()
    _loop = asyncio.get_running_loop()

    # --- Validate period ---
    if period not in VALID_PERIODS:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    f"Invalid period '{period}'. Valid options: {', '.join(VALID_PERIODS)}"
                ),
            }
        )

    license_status = await _resolve_license(license_key or "", None)

    # --- Path validation ---
    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

    try:
        df_raw = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    # --- Detect platform revenue columns (alias-normalised) ---
    all_cols = list(df_raw.columns)
    channel_to_canonical = normalise_platform_revenue_columns(all_cols)

    if not channel_to_canonical:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "No platform-reported revenue columns found in this CSV. "
                    "Add columns named <channel>_platform_reported_revenue (or "
                    "<channel>_reported_revenue / <channel>_platform_revenue) "
                    "to enable platform-vs-MMM reconciliation."
                ),
            }
        )

    # --- Validate no negative platform revenue values ---
    _alias_suffixes = (
        "_platform_reported_revenue",
        "_reported_revenue",
        "_platform_revenue",
    )
    for col in all_cols:
        col_lower = col.lower()
        for suffix in _alias_suffixes:
            if col_lower.endswith(suffix):
                if (df_raw[col] < 0).any():
                    return json.dumps(
                        {
                            "status": "error",
                            "message": (
                                f"Column '{col}' contains negative platform revenue values. "
                                "Platform-reported revenue must be non-negative."
                            ),
                        }
                    )
                break

    # --- Load wide format ---
    try:
        X, y, all_channel_columns = _load_wide_format(df_raw)  # noqa: N806
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    n_channels = len(all_channel_columns)
    n_rows = len(X)
    try:
        _enforce_tier_limits(license_status, n_channels, n_rows)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    # --- Data window ---
    try:
        _dates = pd.to_datetime(X["date"] if "date" in X.columns else df_raw["date"])
        _start_all = _dates.min()
        _end_all = _dates.max()
        _weeks_total = round((_end_all - _start_all).days / 7)
        data_window = (
            f"{_start_all.strftime('%Y-%m-%d')} to "
            f"{_end_all.strftime('%Y-%m-%d')} ({_weeks_total} weeks)"
        )
    except Exception:
        _weeks_total = len(X)
        data_window = ""

    # --- Resolve period window ---
    period_weeks_req = _PERIOD_WEEKS[period]
    if period_weeks_req is None:
        period_weeks = _weeks_total
    else:
        period_weeks = period_weeks_req

    if period_weeks_req is not None and period_weeks > _weeks_total:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    f"Period '{period}' requires {period_weeks} weeks "
                    f"but fit window is only {_weeks_total} weeks"
                ),
            }
        )

    # --- Fingerprint + cache ---
    from mixlift.modeling.defaults import MCP_CONFIG

    _csv_bytes = csv_file.read_bytes()
    _disk_fp = compute_model_fingerprint(_csv_bytes, all_channel_columns, MCP_CONFIG)

    mmm = None
    X_fit = None  # noqa: N806
    y_fit: pd.Series | None = None

    if _disk_fp in _MODEL_CACHE:
        _mem = _MODEL_CACHE[_disk_fp]
        mmm = _mem["mmm"]
        X_fit = _mem["X"]  # noqa: N806
        y_fit = _mem.get("y")
    else:
        _disk_entry = await _disk_load_model(_disk_fp)
        if _disk_entry is not None:
            _MODEL_CACHE[_disk_fp] = _disk_entry
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]
            mmm = _disk_entry["mmm"]
            X_fit = _disk_entry["X"]  # noqa: N806
            y_fit = _disk_entry.get("y")

    if mmm is None:
        logger.info("mixlift_reconcile: fitting model (cache miss)...")
        model_results = await asyncio.to_thread(
            _run_pipeline, X, y, all_channel_columns, None
        )
        elapsed = _time.monotonic() - t0
        logger.info("mixlift_reconcile: MCMC complete in %.1fs.", elapsed)

        mmm = model_results.mmm
        X_fit = X  # noqa: N806
        y_fit = y

        _MODEL_CACHE[_disk_fp] = {
            "mmm": mmm,
            "X": X_fit,
            "y": y_fit,
            "channel_columns": all_channel_columns,
            "model_results": model_results,
        }
        if len(_MODEL_CACHE) > 3:
            oldest_key = next(iter(_MODEL_CACHE))
            del _MODEL_CACHE[oldest_key]

        asyncio.ensure_future(
            _disk_save_model(
                _disk_fp,
                mmm=mmm,
                X=X_fit,
                y=y_fit,
                channel_columns=all_channel_columns,
                result={},
                mcmc_config=MCP_CONFIG,
            )
        )

    # --- Extract contributions ---
    means_dict: dict
    cis_dict: dict
    means_dict, cis_dict = await asyncio.to_thread(
        _run_channel_contributions, mmm, X_fit, all_channel_columns
    )

    # --- Slice data to period window ---
    try:
        _date_col = "date" if "date" in X_fit.columns else X_fit.columns[0]
        _fit_dates = pd.to_datetime(X_fit[_date_col])
        _period_end = _fit_dates.max()
        _period_start = _period_end - pd.Timedelta(weeks=period_weeks)
        if period == "full_period":
            _mask = pd.Series([True] * len(X_fit), index=X_fit.index)
        else:
            _mask = _fit_dates > _period_start
        _period_end_ts = _period_end
        X_period = X_fit[_mask]  # noqa: N806
        period_label = (
            f"{_PERIOD_DISPLAY[period]} "
            f"({(_period_start + pd.Timedelta(days=1)).strftime('%Y-%m-%d')} "
            f"to {_period_end.strftime('%Y-%m-%d')})"
            if period != "full_period"
            else (
                f"Full period ({_fit_dates.min().strftime('%Y-%m-%d')} "
                f"to {_period_end.strftime('%Y-%m-%d')})"
            )
        )
    except Exception:
        X_period = X_fit  # noqa: N806
        _mask = pd.Series([True] * len(X_fit), index=X_fit.index)
        _period_end_ts = None
        period_label = _PERIOD_DISPLAY[period]

    # --- Scale contributions to the period slice ---
    from mixlift.modeling.optimizer import format_channel_name as _fmt_name

    n_full = len(X_fit)
    n_period = len(X_period)
    scale = n_period / n_full if n_full > 0 else 1.0

    scaled_means: dict[str, float] = {}
    scaled_cis: dict[str, tuple[float, float]] = {}
    spend_dict: dict[str, float] = {}

    for raw_col in all_channel_columns:
        display = _fmt_name(raw_col)
        scaled_means[display] = means_dict.get(display, 0.0) * scale
        raw_ci = cis_dict.get(display, (0.0, 0.0))
        scaled_cis[display] = (raw_ci[0] * scale, raw_ci[1] * scale)
        spend_dict[display] = (
            float(X_period[raw_col].sum()) if raw_col in X_period.columns else 0.0
        )

    # --- Build platform_revenue_dict ---
    # channel_to_canonical maps channel_prefix → canonical_column_name.
    # We need to sum the actual column in df_raw over the period mask.
    # The mask is on X_fit's index; df_raw may have a different index.
    # Re-build mask on df_raw by date comparison.
    try:
        _raw_dates = pd.to_datetime(df_raw["date"])
        if period == "full_period" or _period_end_ts is None:
            _raw_mask = pd.Series([True] * len(df_raw))
        else:
            _raw_mask = _raw_dates > _period_start
    except Exception:
        _raw_mask = pd.Series([True] * len(df_raw))

    # Build a map from channel_prefix → actual column name in df_raw
    _channel_to_actual_col: dict[str, str] = {}
    for channel_prefix in channel_to_canonical:
        # Check each alias suffix to find the actual column in df_raw
        for suffix in _alias_suffixes:
            candidate = f"{channel_prefix}{suffix}"
            # Case-insensitive lookup
            _found = next(
                (c for c in df_raw.columns if c.lower() == candidate.lower()), None
            )
            if _found is not None:
                _channel_to_actual_col[channel_prefix] = _found
                break

    platform_revenue_dict: dict[str, float | None] = {}
    _skipped_platform_channels: list[str] = []
    _zero_platform_channels: list[str] = []

    for raw_col in all_channel_columns:
        channel_prefix = raw_col.replace("_spend", "")
        display = _fmt_name(raw_col)
        if channel_prefix in _channel_to_actual_col:
            actual_col = _channel_to_actual_col[channel_prefix]
            period_sum = float(df_raw.loc[_raw_mask, actual_col].sum())
            platform_revenue_dict[display] = period_sum
            if period_sum == 0.0:
                _zero_platform_channels.append(display)
        else:
            platform_revenue_dict[display] = None

    # Warn-and-skip: platform rev channels with no corresponding spend col
    for channel_prefix in channel_to_canonical:
        has_spend = f"{channel_prefix}_spend" in [c.lower() for c in all_channel_columns]
        if not has_spend:
            _skipped_platform_channels.append(channel_prefix)
            logger.warning(
                "mixlift_reconcile: platform revenue column for '%s' has no "
                "matching spend column — skipped.",
                channel_prefix,
            )

    # --- Build result dict ---
    result_dict = build_reconcile_result(
        period=period,
        period_weeks=period_weeks,
        period_label=period_label,
        data_window=data_window,
        mcmc_config=MCP_CONFIG,
        channel_columns=all_channel_columns,
        means_dict=scaled_means,
        cis_dict=scaled_cis,
        spend_dict=spend_dict,
        platform_revenue_dict=platform_revenue_dict,
    )

    # --- Render memo with warnings appended ---
    memo = render_reconcile_memo(result_dict)

    warning_lines: list[str] = []
    if _skipped_platform_channels:
        warning_lines.append(
            f"**Warning:** Platform revenue columns detected for channels with no "
            f"spend data — skipped: {', '.join(_skipped_platform_channels)}."
        )
    if _zero_platform_channels:
        warning_lines.append(
            f"**Warning:** Zero platform revenue reported for: "
            f"{', '.join(_zero_platform_channels)}. "
            "Check that the platform revenue columns contain data for this period."
        )

    if warning_lines:
        memo = memo + "\n\n" + "\n\n".join(warning_lines) if memo else "\n\n".join(warning_lines)

    result_dict["memo_markdown"] = memo

    return json.dumps(result_dict, indent=2, default=str)


@mcp.tool()
async def mixlift_clean(
    csv_path: str,
    license_key: str | None = None,
    apply_fixes: bool = False,
    output_path: str | None = None,
    channel_name_map: dict[str, str] | None = None,
) -> str:
    """Audit a marketing CSV for data-quality issues and optionally write a cleaned copy.

    Use BEFORE mixlift_prepare or mixlift_analyze when a client sends a messy CSV —
    inconsistent channel names, missing weeks, outlier spikes, duplicate rows,
    currency markers, date-format drift. Dry-run by default; pass apply_fixes=True
    to write a repaired copy. Free on all tiers.

    Do NOT use as a substitute for mixlift_prepare (which pivots/reshapes data).
    Run mixlift_clean first, then mixlift_prepare on the cleaned output.

    Fires on questions like: "Can you clean up this CSV before we model it?"

    Args:
        csv_path: Absolute path to the marketer's CSV file.
        license_key: MixLift license key (optional — clean is free on all tiers).
        apply_fixes: If True, write a cleaned copy to output_path. Default False.
        output_path: Destination for cleaned CSV. Defaults to <name>.cleaned.csv.
            Must not equal csv_path.
        channel_name_map: User-supplied channel renames e.g. {"FB": "Meta"}.
            Takes precedence over the built-in alias table.

    Returns:
        JSON string with: issues list (ranked by severity), fixes_applied (if
        apply_fixes=True), needs_your_call list for ambiguous cases, memo_markdown.

    Presentation: surface memo_markdown verbatim. No emoji, no table restructuring.
    """
    from mixlift_mcp.cleaners.detectors import run_all_detectors
    from mixlift_mcp.cleaners.fixers import apply_all_fixes
    from mixlift_mcp.renderers.clean_memo import render_clean_memo

    # --- Path validation ---
    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

    # --- Resolve output path ---
    if apply_fixes:
        if output_path is not None:
            out_file = Path(output_path).expanduser().resolve()
        else:
            out_file = csv_file.with_suffix("").with_suffix(".cleaned" + csv_file.suffix)
        # Refuse to overwrite input
        if out_file == csv_file:
            return json.dumps(
                {
                    "status": "error",
                    "message": (
                        f"output_path resolves to the same file as csv_path ({csv_file}). "
                        "Refusing to overwrite the input. "
                        "Provide a different output_path."
                    ),
                }
            )
    else:
        out_file = None

    # --- License check (mirrors saturation skeleton; clean is free) ---
    _license = await _resolve_license(license_key or "", None)
    _ = _license  # no tier gate for clean, but we still validate the key

    # --- Load CSV ---
    try:
        df = pd.read_csv(csv_file)
    except Exception as exc:
        return json.dumps(
            {
                "status": "error",
                "message": f"File is empty or unreadable: {exc}",
            }
        )

    if df.empty:
        return json.dumps(
            {
                "status": "error",
                "message": "File is empty or unreadable",
            }
        )

    # --- Minimal required-column check ---
    cols_lower = {c.lower().strip() for c in df.columns}
    has_date = any(kw in c for c in cols_lower for kw in ("date", "week", "day", "period"))
    has_spend = any(kw in c for c in cols_lower for kw in ("spend", "cost", "budget"))
    has_revenue = any(
        kw in c for c in cols_lower for kw in ("revenue", "sales", "target", "value", "gmv")
    )

    missing: list[str] = []
    if not has_date:
        missing.append("date")
    if not has_spend:
        missing.append("spend/cost")
    if not has_revenue:
        missing.append("revenue/sales")

    if missing:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    f"Missing required column(s): {', '.join(missing)}. "
                    f"Columns found: {list(df.columns)}"
                ),
            }
        )

    # --- Input summary ---
    def _build_summary(frame: pd.DataFrame) -> dict:
        from mixlift_mcp.cleaners.detectors import (  # noqa: I001
            _find_channel_col,
            _find_date_col,
            _try_parse_dates,
        )

        ch_col = _find_channel_col(frame)
        date_col = _find_date_col(frame)
        n_channels = frame[ch_col].nunique() if ch_col else 0
        dates_parsed = None
        if date_col:
            try:
                dates_parsed = _try_parse_dates(frame[date_col].dropna().astype(str))
            except Exception:
                pass
        if dates_parsed is not None and dates_parsed.dropna().notna().any():
            d_min = dates_parsed.min().strftime("%Y-%m-%d")
            d_max = dates_parsed.max().strftime("%Y-%m-%d")
            date_range = f"{d_min} to {d_max}"
            unique_dates = dates_parsed.dropna().unique()
            week_count = len(unique_dates)
        else:
            date_range = "unknown"
            week_count = 0
        return {
            "rows": len(frame),
            "channels": n_channels,
            "date_range": date_range,
            "week_count": week_count,
        }

    input_summary = _build_summary(df)

    # --- Run detectors ---
    issues = run_all_detectors(df, user_map=channel_name_map)

    # --- Apply fixes if requested ---
    fixes_applied: list[dict] = []
    output_summary: dict | None = None
    resolved_output_path: str | None = None

    if apply_fixes:
        cleaned_df, fixes_applied = apply_all_fixes(df, issues, user_map=channel_name_map)
        output_summary = _build_summary(cleaned_df)
        resolved_output_path = str(out_file)
        try:
            out_file.parent.mkdir(parents=True, exist_ok=True)
            cleaned_df.to_csv(out_file, index=False)
        except Exception as exc:
            return json.dumps(
                {
                    "status": "error",
                    "message": f"Failed to write cleaned CSV: {exc}",
                }
            )

    # --- Build result dict ---
    result: dict = {
        "tool": "mixlift_clean",
        "version": "0.5.3",
        "input_path": str(csv_file),
        "output_path": resolved_output_path,
        "applied": apply_fixes,
        "input_summary": input_summary,
        "issues": [i.to_dict() for i in issues],
        "fixes_applied": fixes_applied if apply_fixes else [],
        "output_summary": output_summary,
    }

    # --- Render memo ---
    result["memo_markdown"] = render_clean_memo(result)

    return json.dumps(result, indent=2, default=str)



# ---------------------------------------------------------------------------
# mixlift_scenarios helpers
# ---------------------------------------------------------------------------

_SCENARIOS_TOOL_VERSION = "0.5.3"


def _build_modified_allocation(
    base_allocation: dict[str, float],
    deltas: dict[str, float],
    mode: str,
    training_maxes: dict[str, float],
) -> tuple[dict[str, float], bool, bool]:
    """Apply a delta spec to a base allocation. Returns (modified, extrapolated, clipped)."""
    modified: dict[str, float] = dict(base_allocation)
    extrapolated = False
    clipped = False

    for ch, val in deltas.items():
        if ch not in modified:
            continue
        base_val = base_allocation[ch]
        if mode == "absolute":
            new_val = base_val + float(val)
        else:
            new_val = base_val * (1.0 + float(val))

        if new_val < 0:
            new_val = 0.0
            clipped = True

        train_max = training_maxes.get(ch, base_val)
        if train_max > 0 and new_val > 2.0 * train_max:
            extrapolated = True

        modified[ch] = round(new_val, 2)

    return modified, extrapolated, clipped


def _compute_canned_scenarios(
    current_allocation: dict[str, float],
    mroas_means: dict[str, float],
) -> list[dict]:
    """Generate 5 canonical canned scenario specs ranked by marginal ROAS."""
    channels = list(current_allocation.keys())
    if not channels:
        return []

    def _mroas(ch: str) -> float:
        return float(mroas_means.get(ch, 0.0))

    ranked = sorted(channels, key=_mroas)
    worst = ranked[0]
    best = ranked[-1]
    second_best = ranked[-2] if len(ranked) >= 2 else ranked[-1]

    return [
        {"name": "Status quo", "deltas": {}},
        {"name": f"Cut {worst} 50%", "deltas": {worst: -0.5}},
        {"name": f"Shift 20% from {worst} to {best}", "deltas": {worst: -0.2, best: 0.2}},
        {
            "name": f"+20% budget to {best} and {second_best}",
            "deltas": {best: 0.2, second_best: 0.2},
        },
        {"name": "−20% total budget", "deltas": {ch: -0.2 for ch in channels}},
    ]


def _validate_scenario_dicts(
    scenarios: list[dict],
    valid_channels: set[str],
) -> str | None:
    """Validate user-supplied scenario list. Returns error string or None."""
    for i, sc in enumerate(scenarios):
        if not isinstance(sc, dict):
            return f"Scenario at index {i} is not a dict."
        if "name" not in sc:
            return f"Scenario at index {i} is missing required key 'name'."
        if "deltas" not in sc:
            name_str = sc.get("name", f"index {i}")
            return f"Scenario '{name_str}' is missing required key 'deltas'."
        if not isinstance(sc["deltas"], dict):
            return f"Scenario '{sc['name']}': 'deltas' must be a dict."
        unknown = [ch for ch in sc["deltas"] if ch not in valid_channels]
        if unknown:
            return (
                f"Scenario '{sc['name']}': unknown channel(s) {unknown}. "
                f"Valid channels: {sorted(valid_channels)}."
            )
    return None


def _run_scenario_from_allocation(
    mmm: Any,
    X: Any,  # noqa: N803
    channel_columns: list[str],
    base_allocation: dict[str, float],
    modified_allocation: dict[str, float],
) -> tuple[float, float, float, list[float]]:
    """Return (revenue_median, ci_low_80, ci_high_80, pct_samples)."""
    import numpy as np

    from mixlift.modeling.optimizer import (
        _estimate_response,
        estimate_scenario_impact_samples,
    )

    base_response = _estimate_response(mmm, X, channel_columns, base_allocation)
    mod_response = _estimate_response(mmm, X, channel_columns, modified_allocation)

    try:
        samples = estimate_scenario_impact_samples(
            mmm, X, channel_columns, base_allocation, modified_allocation
        )
        if len(samples) > 0:
            pct_samples = np.array(samples, dtype=float)
            median_pct = float(np.median(pct_samples))
            ci_low_pct = float(np.percentile(pct_samples, 10))
            ci_high_pct = float(np.percentile(pct_samples, 90))
            if base_response > 0:
                revenue_median = base_response * (1 + median_pct / 100.0)
                ci_low = base_response * (1 + ci_low_pct / 100.0)
                ci_high = base_response * (1 + ci_high_pct / 100.0)
            else:
                revenue_median = mod_response
                ci_low = mod_response
                ci_high = mod_response
            return (
                round(revenue_median, 0),
                round(ci_low, 0),
                round(ci_high, 0),
                list(pct_samples),
            )
    except Exception as exc:
        logger.warning("Scenario CI sampling failed: %s", exc)

    return round(mod_response, 0), round(mod_response, 0), round(mod_response, 0), []


def _run_multi_scenario(
    mmm: Any,
    X: Any,  # noqa: N803
    channel_columns: list[str],
    base_allocation: dict[str, float],
    modified_allocation: dict[str, float],
) -> tuple[float, float, float]:
    """Wrapper enabling easy mocking. Returns (median, ci_low, ci_high)."""
    median, ci_low, ci_high, _ = _run_scenario_from_allocation(
        mmm, X, channel_columns, base_allocation, modified_allocation
    )
    return median, ci_low, ci_high


@mcp.tool()
async def mixlift_scenarios(
    csv_path: str,
    license_key: str | None = None,
    scenarios: list[dict] | None = None,
    mcmc_config: str = "default",
    ctx: Context | None = None,
) -> str:
    """Rank multiple budget-reallocation scenarios by expected revenue impact.

    Use when the user wants to compare two or more hypothetical spend moves side by
    side — e.g., "cut Meta 50% vs shift that spend to Email." Returns a ranked grid
    with projected revenue and 80% CI for each. If no scenarios are provided, runs
    five canned defaults (status quo, cut worst −50%, shift worst→best, +20% to top
    two, −20% across the board). Free tier accepted.

    Do NOT use for a single scenario (use mixlift_scenario). Do NOT use for budget
    tracking vs a plan (use mixlift_pacing).

    Fires on questions like: "Compare cutting Meta 50% vs adding 20% to Email."

    Args:
        csv_path: Path to a wide-format CSV.
        license_key: MixLift license key (free tier accepted).
        scenarios: List of {name, deltas, mode?} dicts. Omit for 5 canned defaults.
            Example: [{"name": "Cut Meta", "deltas": {"Meta_spend": -0.5}}]
        mcmc_config: MCMC preset. Ignored when a cached model exists.

    Returns:
        JSON string with: status_quo revenue + CI, ranked scenario list (name, deltas,
        projected_revenue, CI, delta vs status quo, extrapolated flag, rank),
        memo_markdown.

    Presentation: surface memo_markdown verbatim. No emoji, no table restructuring.
    """
    import time as _time  # noqa: I001, PLC0415

    from mixlift_mcp.model_cache import (
        compute_model_fingerprint,
        load_model as _disk_load_model,
        save_model as _disk_save_model,
    )
    from mixlift_mcp.progress import ProgressReporter

    _step = 0

    async def _log(msg: str) -> None:
        nonlocal _step
        _step += 1
        logger.info(msg)
        if ctx:
            try:
                await ctx.report_progress(_step, 8, msg)
            except Exception:
                pass

    t0 = _time.monotonic()
    _loop = asyncio.get_running_loop()
    _reporter = ProgressReporter(ctx, _loop)

    await _log("Validating license...")
    license_status = await _resolve_license(license_key or "", ctx)

    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps(
            {"status": "error", "message": f"File not found: {csv_file}"}
        )

    try:
        df = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    _reporter.phase("Validating CSV and detecting channels", 1, 8)
    await _log(f"CSV loaded ({len(df)} rows). Detecting format...")

    csv_format = _detect_csv_format(df)
    try:
        if csv_format == "wide":
            X, y, all_channel_columns = _load_wide_format(df)  # noqa: N806
        else:
            X, y, all_channel_columns = _load_platform_csv(df, csv_format)  # noqa: N806
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    n_channels = len(all_channel_columns)
    n_rows = len(X)
    try:
        _enforce_tier_limits(license_status, n_channels, n_rows)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    try:
        _dates = pd.to_datetime(df["date"])
        _start = _dates.min().strftime("%Y-%m-%d")
        _end = _dates.max().strftime("%Y-%m-%d")
        _weeks = round((_dates.max() - _dates.min()).days / 7)
        data_window = f"{_start} to {_end} ({_weeks} weeks)"
    except Exception:
        data_window = ""

    from mixlift.modeling.defaults import MCP_CONFIG

    _csv_bytes = csv_file.read_bytes()
    _disk_fp = compute_model_fingerprint(_csv_bytes, all_channel_columns, MCP_CONFIG)

    mmm = None
    X_fit = None  # noqa: N806

    if _disk_fp in _MODEL_CACHE:
        _mem = _MODEL_CACHE[_disk_fp]
        mmm = _mem["mmm"]
        X_fit = _mem["X"]  # noqa: N806
        await _log(f"Cache hit (in-memory) — loaded model ({_disk_fp}).")
    else:
        _disk_entry = await _disk_load_model(_disk_fp)
        if _disk_entry is not None:
            _MODEL_CACHE[_disk_fp] = _disk_entry
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]
            mmm = _disk_entry["mmm"]
            X_fit = _disk_entry["X"]  # noqa: N806
            await _log(f"Cache hit (disk) — loaded model ({_disk_fp}).")

    if mmm is None:
        await _log("Fitting Bayesian model via MCMC sampling (~30-60s)...")
        _reporter.phase("Fitting model (MCMC sampling)", 3, 8)
        _model_results = await asyncio.to_thread(
            _run_pipeline, X, y, all_channel_columns, _reporter
        )
        elapsed = _time.monotonic() - t0
        await _log(f"MCMC complete in {elapsed:.1f}s.")
        mmm = _model_results.mmm
        X_fit = X  # noqa: N806
        _MODEL_CACHE[_disk_fp] = {
            "mmm": mmm,
            "X": X_fit,
            "channel_columns": all_channel_columns,
            "model_results": _model_results,
        }
        if len(_MODEL_CACHE) > 3:
            oldest_key = next(iter(_MODEL_CACHE))
            del _MODEL_CACHE[oldest_key]
        asyncio.ensure_future(
            _disk_save_model(
                _disk_fp,
                mmm=mmm,
                X=X_fit,
                channel_columns=all_channel_columns,
                result={},
                mcmc_config=MCP_CONFIG,
            )
        )

    from mixlift.modeling.optimizer import format_channel_name as _fmt_name

    channel_columns = all_channel_columns
    display_names = [_fmt_name(c) for c in channel_columns]

    base_allocation: dict[str, float] = {}
    training_maxes: dict[str, float] = {}
    for raw_col, display in zip(channel_columns, display_names):
        if raw_col in X_fit.columns:
            base_allocation[display] = float(X_fit[raw_col].mean())
            training_maxes[display] = float(X_fit[raw_col].max())
        else:
            base_allocation[display] = 0.0
            training_maxes[display] = 0.0

    await _log("Extracting marginal ROAS...")
    _reporter.phase("Extracting marginal ROAS", 5, 8)
    mroas_means_raw: dict
    mroas_means_raw, _ = await asyncio.to_thread(
        _run_marginal_roas, mmm, X_fit, channel_columns
    )

    resolved_scenarios: list[dict]
    if not scenarios:
        resolved_scenarios = _compute_canned_scenarios(base_allocation, mroas_means_raw)
    else:
        resolved_scenarios = scenarios

    valid_channel_set = set(display_names)
    validation_err = _validate_scenario_dicts(resolved_scenarios, valid_channel_set)
    if validation_err:
        return json.dumps(
            {
                "status": "error",
                "message": validation_err,
                "valid_channels": sorted(valid_channel_set),
            }
        )

    await _log("Computing scenario projections...")
    _reporter.phase("Running scenario projections", 6, 8)

    sq_revenue, sq_ci_low, sq_ci_high = _run_multi_scenario(
        mmm, X_fit, channel_columns, base_allocation, base_allocation
    )

    scenario_results: list[dict] = []
    for sc in resolved_scenarios:
        sc_name: str = sc["name"]
        sc_deltas: dict = sc.get("deltas", {})
        sc_mode: str = sc.get("mode", "percent")

        modified_alloc, extrapolated, clipped = _build_modified_allocation(
            base_allocation, sc_deltas, sc_mode, training_maxes
        )

        proj_rev, proj_ci_low, proj_ci_high = _run_multi_scenario(
            mmm, X_fit, channel_columns, base_allocation, modified_alloc
        )

        delta = round(proj_rev - sq_revenue, 0)
        delta_pct = round((delta / sq_revenue) * 100.0, 2) if sq_revenue > 0 else 0.0

        sc_out: dict = {
            "name": sc_name,
            "deltas": sc_deltas,
            "projected_revenue": proj_rev,
            "projected_ci": [proj_ci_low, proj_ci_high],
            "delta_vs_status_quo": delta,
            "delta_pct": delta_pct,
            "extrapolated": extrapolated,
            "clipped": clipped,
            "rank": 0,
        }
        if sc_mode != "percent":
            sc_out["mode"] = sc_mode
        scenario_results.append(sc_out)

    scenario_results.sort(key=lambda s: s["delta_vs_status_quo"], reverse=True)
    for i, sc_out in enumerate(scenario_results, start=1):
        sc_out["rank"] = i

    result_dict: dict = {
        "tool": "mixlift_scenarios",
        "version": _SCENARIOS_TOOL_VERSION,
        "mcmc_config": MCP_CONFIG,
        "data_window": data_window,
        "status_quo_revenue": sq_revenue,
        "status_quo_ci": [sq_ci_low, sq_ci_high],
        "scenarios": scenario_results,
    }

    await _log("Rendering memo...")
    try:
        from mixlift_mcp.renderers.scenarios_memo import (
            render_scenarios_memo as _render_sm,
        )

        result_dict["memo_markdown"] = _render_sm(result_dict)
    except Exception as exc:
        logger.warning("render_scenarios_memo failed: %s", exc)
        result_dict["memo_markdown"] = ""

    elapsed_total = _time.monotonic() - t0
    await _log(f"Scenarios analysis complete in {elapsed_total:.1f}s.")

    return json.dumps(result_dict, indent=2, default=str)

def _run_wow_channel_contributions(
    mmm: Any,
    X: Any,  # noqa: N803
    channel_columns: list[str],
) -> tuple[dict, dict]:
    """Wrapper for extract_channel_contributions enabling easy mocking in tests."""
    from mixlift.modeling.engine import extract_channel_contributions

    return extract_channel_contributions(mmm, X, channel_columns)


@mcp.tool()
async def mixlift_weekly_digest(
    csv_path: str,
    license_key: str | None = None,
    include: list[str] | None = None,
    plan: dict[str, float] | None = None,
    mcmc_config: str = "default",
    ctx: Context | None = None,
) -> str:
    """Produce a Monday-morning digest: WoW delta, saturation snapshot, pacing, top 3 moves.

    Use when the user asks for a weekly brief or a single-shot status-check across
    all dimensions. Runs WoW, saturation, and (if plan is supplied) pacing in one
    call; synthesizes three recommended moves from the combined signals. Individual
    sections degrade gracefully — a section error becomes a footnote, not a failure.

    Do NOT use when the user is investigating one specific dimension — pick the
    targeted tool (mixlift_wow, mixlift_saturation, mixlift_pacing) instead.

    Fires on questions like: "Give me the Monday morning digest."

    Args:
        csv_path: Path to a wide-format CSV (same as mixlift_analyze).
        license_key: MixLift Growth license key. Free tier accepted.
        include: Sections to include. Default: ["wow","saturation","pacing","moves"].
            Valid values: "wow", "saturation", "pacing", "moves".
        plan: {channel_name: monthly_budget} dict. Required to render pacing section.
        mcmc_config: MCMC preset. Ignored when a cached model exists.

    Returns:
        JSON string with: digest_period, summary block (revenue_delta, biggest_winner,
        biggest_loser), per-section data, three recommended moves with rationale and
        expected impact, memo_markdown.

    Presentation: surface memo_markdown verbatim. No emoji, no table restructuring.
    """
    import time as _time  # noqa: I001, PLC0415

    from mixlift_mcp.model_cache import (
        compute_model_fingerprint,
        load_model as _disk_load_model,
        save_model as _disk_save_model,
    )
    from mixlift_mcp.progress import ProgressReporter
    from mixlift_mcp.renderers.digest_memo import VALID_SECTIONS, build_digest_result

    _step = 0

    async def _log(msg: str) -> None:
        nonlocal _step
        _step += 1
        logger.info(msg)
        if ctx:
            try:
                await ctx.report_progress(_step, 9, msg)
            except Exception:
                pass

    t0 = _time.monotonic()
    _loop = asyncio.get_running_loop()
    _reporter = ProgressReporter(ctx, _loop)

    # --- Resolve include list ---
    # None → default to all sections; [] → explicit empty → error below
    _include: list[str] = list(include) if include is not None else list(VALID_SECTIONS)

    # Validate early: empty include is always an error
    if not _include:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "include cannot be empty. "
                    f"Valid options: {list(VALID_SECTIONS)}"
                ),
            }
        )

    # Validate section names
    invalid = [s for s in _include if s not in VALID_SECTIONS]
    if invalid:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    f"Invalid section(s): {invalid}. "
                    f"Valid options: {list(VALID_SECTIONS)} "
                    f"(wow, saturation, pacing, moves)"
                ),
            }
        )

    # --- License ---
    await _log("Validating license...")
    license_status = await _resolve_license(license_key or "", ctx)

    # --- Path validation ---
    csv_file, validation_error = _validate_csv_path(csv_path)
    if validation_error:
        return json.dumps({"status": "error", "message": validation_error})
    if not csv_file.exists():
        return json.dumps({"status": "error", "message": f"File not found: {csv_file}"})

    try:
        df = pd.read_csv(csv_file)
    except Exception as e:
        return json.dumps({"status": "error", "message": f"Failed to read CSV: {e}"})

    _reporter.phase("Validating CSV and detecting channels", 1, 9)
    await _log(f"CSV loaded ({len(df)} rows). Detecting format...")

    csv_format = _detect_csv_format(df)
    try:
        if csv_format == "wide":
            X, y, all_channel_columns = _load_wide_format(df)  # noqa: N806
        else:
            X, y, all_channel_columns = _load_platform_csv(df, csv_format)  # noqa: N806
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    n_channels = len(all_channel_columns)
    n_rows = len(X)
    try:
        _enforce_tier_limits(license_status, n_channels, n_rows)
    except ValueError as e:
        return json.dumps({"status": "error", "message": str(e)})

    try:
        _dates = pd.to_datetime(df["date"])
        _start = _dates.min().strftime("%Y-%m-%d")
        _end = _dates.max().strftime("%Y-%m-%d")
        _weeks = round((_dates.max() - _dates.min()).days / 7)
        data_window = f"{_start} to {_end} ({_weeks} weeks)"
    except Exception:
        data_window = ""

    from mixlift.modeling.defaults import MCP_CONFIG

    _csv_bytes = csv_file.read_bytes()
    _disk_fp = compute_model_fingerprint(_csv_bytes, all_channel_columns, MCP_CONFIG)

    # --- Cache lookup ---
    mmm = None
    X_fit = None  # noqa: N806

    if _disk_fp in _MODEL_CACHE:
        _mem = _MODEL_CACHE[_disk_fp]
        mmm = _mem["mmm"]
        X_fit = _mem["X"]  # noqa: N806
        await _log(f"Cache hit (in-memory) — loaded model ({_disk_fp}).")
    else:
        _disk_entry = await _disk_load_model(_disk_fp)
        if _disk_entry is not None:
            _MODEL_CACHE[_disk_fp] = _disk_entry
            if len(_MODEL_CACHE) > 3:
                oldest_key = next(iter(_MODEL_CACHE))
                del _MODEL_CACHE[oldest_key]
            mmm = _disk_entry["mmm"]
            X_fit = _disk_entry["X"]  # noqa: N806
            await _log(f"Cache hit (disk) — loaded model ({_disk_fp}).")

    if mmm is None:
        _reporter.phase("Fitting model (MCMC sampling)", 3, 9)
        await _log("Fitting Bayesian model via MCMC sampling (~30-60s)...")
        _model_results = await asyncio.to_thread(
            _run_pipeline, X, y, all_channel_columns, _reporter
        )
        elapsed = _time.monotonic() - t0
        await _log(f"MCMC complete in {elapsed:.1f}s.")
        mmm = _model_results.mmm
        X_fit = X  # noqa: N806
        _MODEL_CACHE[_disk_fp] = {
            "mmm": mmm,
            "X": X_fit,
            "channel_columns": all_channel_columns,
            "model_results": _model_results,
        }
        if len(_MODEL_CACHE) > 3:
            oldest_key = next(iter(_MODEL_CACHE))
            del _MODEL_CACHE[oldest_key]
        asyncio.ensure_future(
            _disk_save_model(
                _disk_fp,
                mmm=mmm,
                X=X_fit,
                channel_columns=all_channel_columns,
                result={},
                mcmc_config=MCP_CONFIG,
            )
        )

    from mixlift.modeling.optimizer import format_channel_name as _fmt_name

    channel_columns = all_channel_columns
    sections_skipped: list[str] = []

    # --- Pacing: skip silently if no plan ---
    if "pacing" in _include and plan is None:
        sections_skipped.append("pacing")

    # --- WoW section ---
    wow_result: dict | None = None
    if "wow" in _include:
        _reporter.phase("Computing week-over-week contributions", 5, 9)
        await _log("Computing week-over-week channel contributions...")
        try:
            from mixlift_mcp.renderers.wow_memo import (
                _PERIOD_MIN_WEEKS,
                _PERIOD_WEEKS,
                build_wow_result,
            )

            _period = "week"
            _period_weeks = _PERIOD_WEEKS[_period]
            _min_weeks = _PERIOD_MIN_WEEKS[_period]
            # Use date column directly — X_fit has a RangeIndex (not DatetimeIndex)
            # after _load_wide_format; accessing .index would yield nanosecond-epoch
            # dates and cause _total_weeks to round to 0, silently dropping WoW.
            _date_col = "date" if "date" in X_fit.columns else X_fit.columns[0]  # type: ignore[union-attr]
            _dates_idx = pd.to_datetime(X_fit[_date_col])  # type: ignore[union-attr]
            _total_weeks = round((_dates_idx.max() - _dates_idx.min()).days / 7)

            if _total_weeks < _min_weeks:
                raise RuntimeError(
                    f"Data too short for WoW: {_total_weeks} weeks < {_min_weeks} needed."
                )

            _end_date = _dates_idx.max()
            _curr_start = _end_date - pd.Timedelta(weeks=_period_weeks) + pd.Timedelta(days=1)
            _prior_end = _curr_start - pd.Timedelta(days=1)
            _prior_start = _prior_end - pd.Timedelta(weeks=_period_weeks) + pd.Timedelta(days=1)

            _curr_mask = (_dates_idx >= _curr_start) & (_dates_idx <= _end_date)
            _prior_mask = (_dates_idx >= _prior_start) & (_dates_idx <= _prior_end)

            X_curr = X_fit[_curr_mask]  # noqa: N806
            X_prior = X_fit[_prior_mask]  # noqa: N806

            _curr_means, _ = await asyncio.to_thread(
                _run_wow_channel_contributions, mmm, X_curr, channel_columns
            )
            _prior_means, _ = await asyncio.to_thread(
                _run_wow_channel_contributions, mmm, X_prior, channel_columns
            )

            # Current and prior revenue from y (observed)
            _y_series = (
                y if hasattr(y, "loc") else pd.Series(y, index=X_fit.index)  # type: ignore[union-attr]
            )
            _curr_rev = float(_y_series[_curr_mask].sum())
            _prior_rev = float(_y_series[_prior_mask].sum())

            # Spend per period
            _curr_spend: dict[str, float] = {}
            _prior_spend: dict[str, float] = {}
            for _raw_col in channel_columns:
                _disp = _fmt_name(_raw_col)
                _curr_spend[_disp] = (
                    float(X_curr[_raw_col].sum()) if _raw_col in X_curr.columns else 0.0
                )
                _prior_spend[_disp] = (
                    float(X_prior[_raw_col].sum()) if _raw_col in X_prior.columns else 0.0
                )

            _period_label = (
                f"{_PERIOD_WEEKS[_period]}-week period ending "
                f"{_end_date.strftime('%Y-%m-%d')}"
            )

            wow_result = build_wow_result(
                period=_period,
                period_label=_period_label,
                data_window=data_window,
                current_revenue=_curr_rev,
                prior_revenue=_prior_rev,
                current_means=_curr_means,
                prior_means=_prior_means,
                current_spend=_curr_spend,
                prior_spend=_prior_spend,
                channel_columns=channel_columns,
                mcmc_config=MCP_CONFIG,
            )
        except Exception as _wow_exc:
            logger.warning("WoW section failed: %s", _wow_exc)
            sections_skipped.append("wow")

    # --- Saturation section ---
    sat_result: dict | None = None
    if "saturation" in _include or "moves" in _include:
        _reporter.phase("Computing saturation curves", 6, 9)
        await _log("Extracting saturation curves and marginal ROAS...")
        try:
            _sat_curves = await asyncio.to_thread(
                _run_saturation_curves, mmm, X_fit, channel_columns
            )
            _mroas_means, _mroas_cis = await asyncio.to_thread(
                _run_marginal_roas, mmm, X_fit, channel_columns
            )

            from mixlift_mcp.renderers.saturation_memo import build_channel_saturation

            _sat_channels: list[dict] = []
            for _raw_col in channel_columns:
                _disp = _fmt_name(_raw_col)
                _current_spend_wk = (
                    float(X_fit[_raw_col].mean())  # type: ignore[union-attr]
                    if _raw_col in X_fit.columns  # type: ignore[union-attr]
                    else 0.0
                )
                _training_max = (
                    float(X_fit[_raw_col].max())  # type: ignore[union-attr]
                    if _raw_col in X_fit.columns  # type: ignore[union-attr]
                    else 0.0
                )
                _curve = _sat_curves.get(_disp, {"spend": [], "response": []})
                _mroas_mean = _mroas_means.get(_disp, 0.0)
                _mroas_ci_raw = _mroas_cis.get(_disp, (0.0, 0.0))
                _sat_channels.append(
                    build_channel_saturation(
                        channel_raw=_raw_col,
                        current_spend_wk=_current_spend_wk,
                        curve=_curve,
                        marginal_roas_mean=_mroas_mean,
                        marginal_roas_ci=_mroas_ci_raw,
                        increment_steps=[1000, 5000, 10000, 25000],
                        training_max_spend=_training_max,
                    )
                )
            sat_result = {
                "tool": "mixlift_saturation",
                "channels": _sat_channels,
                "data_window": data_window,
            }
        except Exception as _sat_exc:
            logger.warning("Saturation section failed: %s", _sat_exc)
            if "saturation" in _include:
                sections_skipped.append("saturation")

    # --- Pacing section ---
    pacing_result: dict | None = None
    if "pacing" in _include and plan is not None:
        await _log("Computing pacing metrics...")
        try:
            from mixlift_mcp.renderers.pacing_memo import build_pacing_result

            _pacing_raw = build_pacing_result(
                csv_path=csv_path,
                plan=plan,
                plan_period="month",
                today_str=None,
            )
            if _pacing_raw.get("status") != "error":
                pacing_result = _pacing_raw
            else:
                logger.warning("Pacing build returned error: %s", _pacing_raw.get("message"))
                sections_skipped.append("pacing")
        except Exception as _pac_exc:
            logger.warning("Pacing section failed: %s", _pac_exc)
            sections_skipped.append("pacing")

    # --- Build digest result ---
    _reporter.phase("Rendering digest memo", 8, 9)
    await _log("Rendering weekly digest memo...")

    result_dict = build_digest_result(
        csv_path=csv_path,
        license_key=license_key,
        include=_include,
        plan=plan,
        mcmc_config=MCP_CONFIG,
        data_window=data_window,
        fingerprint=_disk_fp,
        wow_result=wow_result,
        sat_result=sat_result,
        pacing_result=pacing_result,
        sections_skipped=sections_skipped,
    )

    elapsed_total = _time.monotonic() - t0
    await _log(f"Digest complete in {elapsed_total:.1f}s.")

    return json.dumps(result_dict, indent=2, default=str)


@mcp.tool()
async def mixlift_pacing(
    csv_path: str,
    license_key: str | None = None,
    plan: dict[str, float] | None = None,
    plan_period: str = "month",
    today: str | None = None,
) -> str:
    """Report spend-vs-plan pacing per channel and project end-of-period variance.

    Use when the user asks if they're on track for a budget target — mid-month,
    mid-week, or mid-quarter. Pure data, no model fit. Requires a plan dict;
    returns per-channel status (Under / On track / Over) with daily-rate adjustment
    recommendations. Free on all tiers.

    Do NOT use for revenue forecasting (use mixlift_forecast) or for comparing
    hypothetical budget moves (use mixlift_scenarios).

    Fires on questions like: "Am I on track for my April budget?"

    Args:
        csv_path: Wide-format spend CSV with a date column and per-channel spend cols.
        license_key: MixLift license key (optional — pacing is free on all tiers).
        plan: {channel_name: budget_for_period} mapping. Required.
            Example: {"Meta": 80000, "Google Search": 60000}.
        plan_period: Billing cadence. One of "week", "month", "quarter".
            Default: "month".
        today: Reference date ISO YYYY-MM-DD. Defaults to today.

    Returns:
        JSON string with: period progress (days elapsed/remaining), per-channel block
        (budget, spent, projected_end, variance, daily_required, status), totals,
        memo_markdown.

    Presentation: surface memo_markdown verbatim. No emoji, no table restructuring.
    """
    from mixlift_mcp.renderers.pacing_memo import build_pacing_result

    # --- License check (no tier gate; pacing is free on all tiers) ---
    _license = await _resolve_license(license_key or "", None)
    _ = _license

    # --- Plan guard ---
    if plan is None:
        return json.dumps(
            {
                "status": "error",
                "message": (
                    "Plan required. Pass {channel: budget} as `plan`."
                ),
            }
        )

    # --- Delegate to renderer's builder (handles all validation + computation) ---
    result_dict = build_pacing_result(
        csv_path=csv_path,
        plan=plan,
        plan_period=plan_period,
        today_str=today,
    )

    return json.dumps(result_dict, indent=2, default=str)


def main():
    """Entry point for the MixLift MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
