"""Request-ID middleware for MixLift Cloud.

Reads ``X-Request-Id`` from incoming headers or generates a uuid4 hex string.
Stashes the value in ``request_id_var`` (a ``ContextVar``) so it is available
to the JSON log formatter and other per-request code.

Usage
-----
Attach ``RequestIdMiddleware`` to the Starlette ASGI app returned by
FastMCP's ``streamable_http_app()``:

    from starlette.middleware import Middleware
    app = mcp.streamable_http_app()
    app.add_middleware(RequestIdMiddleware)

``get_request_id()`` can be called from anywhere within a request handler.
"""

from __future__ import annotations

import uuid
from contextvars import ContextVar
from typing import Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

request_id_var: ContextVar[str | None] = ContextVar("request_id_var", default=None)

HEADER_NAME = "X-Request-Id"


def get_request_id() -> str | None:
    """Return the current request ID or ``None`` outside a request context."""
    return request_id_var.get(None)


class RequestIdMiddleware(BaseHTTPMiddleware):
    """Starlette middleware that injects/propagates a per-request UUID."""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:  # type: ignore[override]
        req_id = request.headers.get(HEADER_NAME) or uuid.uuid4().hex
        token = request_id_var.set(req_id)
        try:
            response: Response = await call_next(request)
        finally:
            request_id_var.reset(token)
        response.headers[HEADER_NAME] = req_id
        return response
