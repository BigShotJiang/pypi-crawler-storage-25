"""Core deliverables pipeline for MixLift.

Generates Obsidian-flavored markdown deliverables from MMM analysis results
with full traceability via wiki-link source citations.

Output layout (per run):
    {output_dir}/MixLift/{YYYY-MM-DD}/
        Standard MMM (analysis_type == "mmm" or absent):
            budget-memo.md
            channel-scorecard.md
            diminishing-returns.md  (conditional — only when saturation_curves present)
            scenario-brief.md       (conditional — only when scenario data is present)
            sources.md
        Forecast (analysis_type == "forecast"):
            forecast-brief.md
            sources.md
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import numpy as np
import yaml
from jinja2 import Environment, FileSystemLoader

from mixlift_mcp.renderers.analyze_memo import _backtest_narrative

logger = logging.getLogger(__name__)

_TEMPLATE_DIR = Path(__file__).parent / "templates" / "mmm"
_REPORT_TEMPLATE_DIR = Path(__file__).parent / "templates"


# ---------------------------------------------------------------------------
# Platform comparison helpers (used by generate_html_report)
# ---------------------------------------------------------------------------


def _verdict_label(verdict: str) -> str:
    return {
        "over_claiming": "Over-claiming",
        "under_claiming": "Under-claiming",
        "aligned": "Aligned",
        "unmeasured": "Unmeasured",
    }.get(verdict, verdict)


def _fmt_gap(gap_pct: float, verdict: str) -> str:
    if verdict == "unmeasured":
        return "\u2014"  # em dash
    pct = abs(gap_pct * 100)
    if verdict == "over_claiming":
        return f"\u2212{pct:.0f}%"  # U+2212 minus sign
    if verdict == "under_claiming":
        return f"+{pct:.0f}%"
    return f"\xb1{pct:.0f}%"  # aligned: ±


def _fmt_roas(x: float | None) -> str:
    if x is None:
        return "\u2014"  # em dash
    return f"{x:.2f}\u00d7"  # U+00D7 multiplication sign


# ---------------------------------------------------------------------------
# Source references
# ---------------------------------------------------------------------------


@dataclass
class SourceRef:
    anchor_id: str
    field_path: str
    value: str
    credible_interval: str
    data_window: str
    mcmc_config: str


class SourceCollector:
    """Accumulate source references and emit Obsidian wiki-links."""

    def __init__(self) -> None:
        self.refs: dict[str, SourceRef] = {}

    def cite(
        self,
        anchor_id: str,
        field_path: str,
        value: str,
        ci: str = "",
        data_window: str = "",
        mcmc_config: str = "",
    ) -> str:
        """Register a source reference and return an Obsidian wiki-link.

        If the same anchor_id is cited again the previous ref is overwritten.
        """
        self.refs[anchor_id] = SourceRef(
            anchor_id=anchor_id,
            field_path=field_path,
            value=value,
            credible_interval=ci,
            data_window=data_window,
            mcmc_config=mcmc_config,
        )
        return f"[[sources#{anchor_id}]]"


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def build_frontmatter(result: dict, doc_type: str) -> dict:
    """Build common YAML frontmatter for a deliverable document."""
    fm: dict = {
        "type": f"mixlift/{doc_type}",
        "run_date": date.today().isoformat(),
        "channels": result.get("data", {}).get("channels", []),
        "n_channels": int(result.get("data", {}).get("n_channels", 0)),
    }

    model_fit = result.get("model_fit", {})
    if "r_squared" in model_fit:
        fm["model_fit"] = float(model_fit["r_squared"])

    analysis_badge = result.get("analysis_badge", {})
    fm["analysis_badge"] = (
        analysis_badge.get("type", "production") if analysis_badge else "production"
    )  # noqa: E501

    model_info = result.get("model_info", {})
    data_window = model_info.get("data_window", {})
    if "weeks" in data_window:
        fm["data_weeks"] = float(data_window["weeks"])

    license_info = result.get("license", {})
    fm["tier"] = license_info.get("tier", "free")

    return fm


def _render_template(template_name: str, context: dict) -> str:
    """Load and render a Jinja2 template from the mmm templates directory."""
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATE_DIR)),
        autoescape=False,
        keep_trailing_newline=True,
    )
    template = env.get_template(template_name)
    return template.render(**context)


def _format_mcmc_config(result: dict) -> str:
    """Extract MCMC configuration and return a human-readable summary string."""
    mcmc = result.get("model_info", {}).get("mcmc_config", {})
    if not mcmc:
        return "Standard MCP configuration"

    chains = mcmc.get("chains", "")
    tune = mcmc.get("tune", "")
    draws = mcmc.get("draws", "")
    target_accept = mcmc.get("target_accept", "")

    parts: list[str] = []
    if chains:
        parts.append(f"{chains} chains")
    if tune:
        parts.append(f"{tune} tune")
    if draws:
        parts.append(f"{draws} draws")
    if target_accept:
        parts.append(f"target_accept={target_accept:.2f}")

    return ", ".join(parts) if parts else "Standard MCP configuration"


def _format_data_window(result: dict) -> str:
    """Extract data window in weeks and return a human-readable string."""
    weeks = result.get("model_info", {}).get("data_window", {}).get("weeks")
    if weeks is not None:
        return f"{int(weeks)} weeks"
    return "Unknown"


# ---------------------------------------------------------------------------
# Render functions
# ---------------------------------------------------------------------------


def render_budget_memo(result: dict, collector: SourceCollector) -> str:
    """Render the budget-memo deliverable from MMM results."""
    budget_opt = result.get("budget_optimization", {})
    expected_lift_pct = budget_opt.get("expected_lift_pct", 0)

    fm = build_frontmatter(result, "budget-memo")
    fm["expected_lift_pct"] = expected_lift_pct
    frontmatter_str = yaml.dump(fm, default_flow_style=False, sort_keys=False)

    mcmc_config = _format_mcmc_config(result)
    data_window = _format_data_window(result)

    roas_data = result.get("roas", {})
    roas_estimates = roas_data.get("estimates", {})
    roas_ci = roas_data.get("confidence_intervals", {})

    actions = result.get("recommendations", {}).get("actions", [])
    summary = result.get("recommendations", {}).get("summary", "")
    model_fit = result.get("model_fit", {})
    r_squared = model_fit.get("r_squared")

    # Cite each recommendation's ROAS, expected lift, and model fit
    for rec in actions:
        channel = rec.get("channel", "")
        if channel and channel in roas_estimates:
            roas_val = roas_estimates[channel]
            ci_bounds = roas_ci.get(channel, {})
            ci_low = ci_bounds.get("low", "")
            ci_high = ci_bounds.get("high", "")
            ci_str = f"{ci_low} – {ci_high} (90% CI)" if ci_low and ci_high else ""
            anchor = f"roas-{channel.lower().replace(' ', '-')}"
            rec["roas_cite"] = collector.cite(
                anchor_id=anchor,
                field_path=f"roas.estimates.{channel}",
                value=f"{roas_val:.2f}x",
                ci=ci_str,
                data_window=data_window,
                mcmc_config=mcmc_config,
            )

    lift_cite = collector.cite(
        anchor_id="expected-lift",
        field_path="optimization.expected_lift_pct",
        value=f"{expected_lift_pct:.1f}%",
        data_window=data_window,
        mcmc_config=mcmc_config,
    )

    fit_cite = ""
    if r_squared is not None:
        fit_cite = collector.cite(
            anchor_id="model-fit-r2",
            field_path="model_fit.r_squared",
            value=f"{r_squared:.3f}",
            data_window=data_window,
            mcmc_config=mcmc_config,
        )

    context = {
        "frontmatter_yaml": frontmatter_str,
        "result": result,
        "headline": result.get("headline", "Budget Optimization"),
        "badge": result.get("analysis_badge"),
        "summary": summary,
        "actions": actions,
        "expected_lift_pct": expected_lift_pct,
        "lift_cite": lift_cite,
        "fit_cite": fit_cite,
        "model_fit": model_fit,
        "loo_cv": result.get("loo_cv", {}),
        "convergence_warnings": result.get("diagnostics", {}).get("convergence_warnings", []),
        "r_squared": r_squared,
        "mcmc_config": mcmc_config,
        "data_window": data_window,
        "cite": collector.cite,
    }
    return _render_template("budget-memo.md.j2", context)


def render_channel_scorecard(result: dict, collector: SourceCollector) -> str:
    """Render the channel-scorecard deliverable from MMM results."""
    fm = build_frontmatter(result, "channel-scorecard")
    frontmatter_str = yaml.dump(fm, default_flow_style=False, sort_keys=False)

    mcmc_config = _format_mcmc_config(result)
    data_window = _format_data_window(result)

    roas_data = result.get("roas", {})
    roas_estimates = roas_data.get("estimates", {})
    roas_ci_raw = roas_data.get("confidence_intervals", {})

    saturation = result.get("saturation_analysis", {})
    marginal_roas_data = result.get("marginal_roas", {}).get("estimates", {})

    memory = result.get("memory", {})
    memory_changes = memory.get("changes", {}) if memory else {}

    channels = result.get("data", {}).get("channels", [])

    rows: list[dict] = []
    for channel in channels:
        roas_val = roas_estimates.get(channel, 0)
        ci_bounds = roas_ci_raw.get(channel, {})
        ci_low = ci_bounds.get("low", "")
        ci_high = ci_bounds.get("high", "")
        ci_str = f"{ci_low} – {ci_high} (90% CI)" if ci_low and ci_high else ""

        sat_info = saturation.get(channel, {})
        sat_status = sat_info.get("status", "unknown").capitalize()
        sat_pct = sat_info.get("saturation_pct", 0)

        mroas_val = marginal_roas_data.get(channel, 0)

        # Trend from memory deltas
        if not memory_changes:
            trend = "—"
        elif channel not in memory_changes:
            trend = "New"
        else:
            ch_delta = memory_changes[channel]
            delta_status = ch_delta.get("status", "")
            if delta_status == "new":
                trend = "New"
            elif delta_status == "stable":
                change_pct = ch_delta.get("change_pct", 0)
                trend = f"→ {change_pct:+.1f}%"
            elif delta_status == "changed":
                change_pct = ch_delta.get("change_pct", 0)
                arrow = "↑" if change_pct > 0 else "↓"
                trend = f"{arrow} {change_pct:+.1f}%"
            elif delta_status == "dropped":
                trend = "Dropped"
            else:
                trend = "—"

        roas_anchor = f"roas-{channel.lower().replace(' ', '-')}"
        roas_cite = collector.cite(
            anchor_id=roas_anchor,
            field_path=f"roas.estimates.{channel}",
            value=f"{roas_val:.2f}x",
            ci=ci_str,
            data_window=data_window,
            mcmc_config=mcmc_config,
        )

        sat_anchor = f"sat-{channel.lower().replace(' ', '-')}"
        sat_cite = collector.cite(
            anchor_id=sat_anchor,
            field_path=f"saturation.{channel}.status",
            value=f"{sat_status} ({sat_pct:.0f}%)",
            data_window=data_window,
            mcmc_config=mcmc_config,
        )

        mroas_anchor = f"mroas-{channel.lower().replace(' ', '-')}"
        mroas_cite = collector.cite(
            anchor_id=mroas_anchor,
            field_path=f"marginal_roas.{channel}",
            value=f"{mroas_val:.2f}x",
            data_window=data_window,
            mcmc_config=mcmc_config,
        )

        rows.append(
            {
                "name": channel,
                "roas_value": f"{roas_val:.2f}x",
                "roas_ci": ci_str,
                "roas_cite": roas_cite,
                "sat_status": sat_status,
                "sat_pct": sat_pct,
                "sat_cite": sat_cite,
                "marginal_roas": f"{mroas_val:.2f}x",
                "mroas_cite": mroas_cite,
                "trend": trend,
            }
        )

    context = {
        "frontmatter_yaml": frontmatter_str,
        "result": result,
        "badge": result.get("analysis_badge"),
        "channels": rows,
        "mcmc_config": mcmc_config,
        "data_window": data_window,
        "cite": collector.cite,
    }
    return _render_template("channel-scorecard.md.j2", context)


def render_scenario_brief(result: dict, collector: SourceCollector) -> str | None:
    """Render the scenario-brief deliverable, or return None if not applicable."""
    scenario = result.get("scenario")
    if not scenario or "error" in scenario:
        return None

    scenario_input = scenario.get("scenario_input", "")

    fm = build_frontmatter(result, "scenario-brief")
    fm["scenario_input"] = scenario_input
    frontmatter_str = yaml.dump(fm, default_flow_style=False, sort_keys=False)

    mcmc_config = _format_mcmc_config(result)
    data_window = _format_data_window(result)

    projected_impact_pct = scenario.get("projected_impact_pct", 0)
    impact_ci_80 = scenario.get("impact_ci_80", {})
    direction_note = scenario.get("direction_note", "")
    headline = scenario.get("headline", "")
    changes = scenario.get("changes", [])  # list of {channel, current, modified, change}

    collector.cite(
        anchor_id="scenario-impact",
        field_path="scenario.projected_impact_pct",
        value=f"{projected_impact_pct:.1f}%",
        ci=(
            f"{impact_ci_80.get('low', '')} – {impact_ci_80.get('high', '')} (80% CI)"
            if impact_ci_80
            else ""
        ),
        data_window=data_window,
        mcmc_config=mcmc_config,
    )

    if impact_ci_80:
        collector.cite(
            anchor_id="scenario-ci",
            field_path="scenario.impact_ci_80",
            value=f"{impact_ci_80.get('low', '')}% to {impact_ci_80.get('high', '')}%",
            ci="80% CI",
            data_window=data_window,
            mcmc_config=mcmc_config,
        )

    # Cite each channel change
    for ch_change in changes:
        ch_name = ch_change.get("channel", "")
        anchor = f"scenario-{ch_name.lower().replace(' ', '-')}"
        collector.cite(
            anchor_id=anchor,
            field_path=f"scenario.changes.{ch_name}",
            value=f"{ch_change.get('change', 0):,.0f}",
            data_window=data_window,
            mcmc_config=mcmc_config,
        )

    context = {
        "frontmatter_yaml": frontmatter_str,
        "result": result,
        "scenario_input": scenario_input,
        "headline": headline,
        "projected_impact_pct": projected_impact_pct,
        "impact_ci": impact_ci_80,
        "direction_note": direction_note,
        "changes": changes,
        "mcmc_config": mcmc_config,
        "data_window": data_window,
        "cite": collector.cite,
    }
    return _render_template("scenario-brief.md.j2", context)


def render_diminishing_returns(result: dict, collector: SourceCollector) -> str | None:
    """Render the diminishing-returns deliverable, or None if saturation curves are absent."""
    saturation_curves = result.get("saturation_curves")
    if not saturation_curves:
        return None

    fm = build_frontmatter(result, "diminishing-returns")
    frontmatter_str = yaml.dump(fm, default_flow_style=False, sort_keys=False)

    mcmc_config = _format_mcmc_config(result)
    data_window = _format_data_window(result)

    channels_list = result.get("data", {}).get("channels", [])
    budget_opt = result.get("budget_optimization", {})
    current_allocation = budget_opt.get("current_allocation", {})
    saturation_analysis = result.get("saturation_analysis", {})

    channel_rows: list[dict] = []
    for channel in channels_list:
        curve = saturation_curves.get(channel)
        if curve is None:
            continue

        curve_spends = np.array(curve["spend"], dtype=float)
        curve_responses = np.array(curve["response"], dtype=float)

        current_spend = float(current_allocation.get(channel, 0))

        # Sample 6 representative spend levels: 0%, 25%, 50%, 75%, 100%, 150%, 200%
        pct_levels = [0.0, 0.25, 0.50, 0.75, 1.00, 1.50, 2.00]
        target_spends = [p * current_spend for p in pct_levels]
        # Drop zero-spend if current_spend is zero to avoid degenerate rows
        if current_spend == 0:
            target_spends = [0.0]
        response_values = np.interp(target_spends, curve_spends, curve_responses).tolist()

        sat_info = saturation_analysis.get(channel, {})
        sat_status = sat_info.get("status", "unknown").capitalize()
        sat_pct = int(sat_info.get("saturation_pct", 0))

        sat_anchor = f"dr-sat-{channel.lower().replace(' ', '-')}"
        collector.cite(
            anchor_id=sat_anchor,
            field_path=f"saturation_analysis.{channel}.status",
            value=f"{sat_status} ({sat_pct}%)",
            data_window=data_window,
            mcmc_config=mcmc_config,
        )

        channel_rows.append(
            {
                "name": channel,
                "current_spend": current_spend,
                "saturation_pct": sat_pct,
                "inflection_spend": float(curve_spends[len(curve_spends) // 2]),
                "spend_levels": [float(s) for s in target_spends],
                "response_levels": [float(r) for r in response_values],
                "status": sat_status,
            }
        )

    context = {
        "frontmatter_yaml": frontmatter_str,
        "channels": channel_rows,
        "mcmc_config": mcmc_config,
        "data_window": data_window,
    }
    return _render_template("diminishing-returns.md.j2", context)


def render_forecast_brief(result: dict, collector: SourceCollector) -> str | None:
    """Render the forecast-brief deliverable, or None if result is not a forecast."""
    if result.get("analysis_type") != "forecast":
        return None

    fm = build_frontmatter(result, "forecast-brief")
    frontmatter_str = yaml.dump(fm, default_flow_style=False, sort_keys=False)

    mcmc_config = _format_mcmc_config(result)
    data_window = _format_data_window(result)

    summary = result.get("summary", {})
    weekly_projections = result.get("weekly_projections", [])
    horizon_weeks = result.get("horizon_weeks", len(weekly_projections))
    current_allocation = result.get("current_allocation") or (
        result.get("budget_optimization", {}).get("current_allocation", {})
    )
    optimal_allocation = result.get("optimal_allocation") or (
        result.get("budget_optimization", {}).get("optimal_allocation", {})
    )

    total_delta = summary.get("total_delta", 0)
    impact_pct = summary.get("impact_pct", 0)
    impact_ci_80 = summary.get("impact_ci_80", {})

    collector.cite(
        anchor_id="forecast-total-delta",
        field_path="summary.total_delta",
        value=f"${total_delta:,.0f}",
        data_window=data_window,
        mcmc_config=mcmc_config,
    )
    if impact_pct:
        ci_str = (
            f"{impact_ci_80.get('low', '')}% to {impact_ci_80.get('high', '')}% (80% CI)"
            if impact_ci_80
            else ""
        )
        collector.cite(
            anchor_id="forecast-impact-pct",
            field_path="summary.impact_pct",
            value=f"{impact_pct}%",
            ci=ci_str,
            data_window=data_window,
            mcmc_config=mcmc_config,
        )

    context = {
        "frontmatter_yaml": frontmatter_str,
        "headline": result.get("headline", "Forecast Analysis"),
        "summary": summary,
        "weeks": weekly_projections,
        "horizon_weeks": horizon_weeks,
        "current_allocation": current_allocation,
        "optimal_allocation": optimal_allocation,
        "mcmc_config": mcmc_config,
        "data_window": data_window,
    }
    return _render_template("forecast-brief.md.j2", context)


def render_sources(collector: SourceCollector) -> str:
    """Render the sources index from all collected SourceRef entries."""
    fm = {
        "type": "mixlift/sources",
        "run_date": date.today().isoformat(),
    }
    frontmatter_str = yaml.dump(fm, default_flow_style=False, sort_keys=False)

    sorted_refs = [collector.refs[k] for k in sorted(collector.refs)]

    context = {
        "frontmatter_yaml": frontmatter_str,
        "refs": sorted_refs,
    }
    return _render_template("sources.md.j2", context)


# ---------------------------------------------------------------------------
# Main orchestrator
# ---------------------------------------------------------------------------


def generate_readout(result: dict, output_dir: str) -> dict:
    """Generate Obsidian deliverables from MMM result dict.

    Creates: {output_dir}/MixLift/{YYYY-MM-DD}/
        budget-memo.md, channel-scorecard.md, scenario-brief.md (conditional), sources.md

    Returns dict with status, files_written list, output_path.
    """
    if result.get("status") != "success":
        return {
            "status": "error",
            "message": (
                f"Cannot generate readout: result status is "
                f"'{result.get('status', 'unknown')}', expected 'success'."
            ),
            "files_written": [],
            "output_path": None,
        }

    run_dir = Path(output_dir) / "MixLift" / date.today().isoformat()
    try:
        run_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logger.error("Failed to create output directory %s: %s", run_dir, e)
        return {
            "status": "error",
            "message": f"Could not create output directory: {e}",
            "files_written": [],
            "output_path": str(run_dir),
        }

    collector = SourceCollector()
    files_written: list[str] = []

    # Dispatch by analysis type
    analysis_type = result.get("analysis_type", "mmm")

    if analysis_type == "forecast":
        # Forecast results get a different set of deliverables
        try:
            forecast_md = render_forecast_brief(result, collector)
            if forecast_md:
                forecast_path = run_dir / "forecast-brief.md"
                forecast_path.write_text(forecast_md)
                files_written.append(str(forecast_path))
                logger.info("Wrote %s", forecast_path)
        except Exception as e:
            logger.warning("Failed to render forecast-brief: %s", e)
    else:
        # Standard MMM deliverables

        # budget-memo
        try:
            memo_md = render_budget_memo(result, collector)
            memo_path = run_dir / "budget-memo.md"
            memo_path.write_text(memo_md)
            files_written.append(str(memo_path))
            logger.info("Wrote %s", memo_path)
        except Exception as e:
            logger.warning("Failed to render budget-memo: %s", e)

        # channel-scorecard
        try:
            scorecard_md = render_channel_scorecard(result, collector)
            scorecard_path = run_dir / "channel-scorecard.md"
            scorecard_path.write_text(scorecard_md)
            files_written.append(str(scorecard_path))
            logger.info("Wrote %s", scorecard_path)
        except Exception as e:
            logger.warning("Failed to render channel-scorecard: %s", e)

        # diminishing-returns (conditional on saturation curves)
        try:
            dr_md = render_diminishing_returns(result, collector)
            if dr_md is not None:
                dr_path = run_dir / "diminishing-returns.md"
                dr_path.write_text(dr_md)
                files_written.append(str(dr_path))
                logger.info("Wrote %s", dr_path)
        except Exception as e:
            logger.warning("Failed to render diminishing-returns: %s", e)

        # scenario-brief (conditional)
        try:
            scenario_md = render_scenario_brief(result, collector)
            if scenario_md is not None:
                scenario_path = run_dir / "scenario-brief.md"
                scenario_path.write_text(scenario_md)
                files_written.append(str(scenario_path))
                logger.info("Wrote %s", scenario_path)
            else:
                logger.info("Skipping scenario-brief (no scenario data or scenario has error)")
        except Exception as e:
            logger.warning("Failed to render scenario-brief: %s", e)

    # sources (always last — collects refs from all previous renders)
    try:
        sources_md = render_sources(collector)
        sources_path = run_dir / "sources.md"
        sources_path.write_text(sources_md)
        files_written.append(str(sources_path))
        logger.info("Wrote %s", sources_path)
    except Exception as e:
        logger.warning("Failed to render sources: %s", e)

    return {
        "status": "success",
        "files_written": files_written,
        "output_path": str(run_dir),
    }


# ---------------------------------------------------------------------------
# HTML report generation (N1: PDF/HTML export)
# ---------------------------------------------------------------------------


def generate_html_report(result: dict, output_path: str) -> dict:
    """Generate a self-contained HTML report from MMM results.

    Produces a single file that a VP can email to their CFO. Print-ready
    with proper @media print rules for PDF conversion via browser.

    Args:
        result: The full analysis result dict from _build_result.
        output_path: File path to write the HTML report.

    Returns:
        Dict with status and output_path.
    """
    if result.get("status") != "success":
        return {
            "status": "error",
            "message": f"Cannot generate report: status is '{result.get('status')}'.",
        }

    mcmc_config = _format_mcmc_config(result)
    data_window = _format_data_window(result)

    # --- Extract actions (same as render_budget_memo) ---
    actions = result.get("recommendations", {}).get("actions", [])

    # --- Extract channel rows (same as render_channel_scorecard) ---
    roas_data = result.get("roas", {})
    roas_estimates = roas_data.get("estimates", {})
    roas_ci_raw = roas_data.get("confidence_intervals", {})
    saturation = result.get("saturation_analysis", {})
    marginal_roas_data = result.get("marginal_roas", {}).get("estimates", {})
    memory = result.get("memory", {})
    memory_changes = memory.get("changes", {}) if memory else {}

    channel_names = result.get("data", {}).get("channels", [])
    channels: list[dict] = []
    for ch_name in channel_names:
        roas_val = roas_estimates.get(ch_name, 0)
        ci_bounds = roas_ci_raw.get(ch_name, {})
        ci_str = ""
        if ci_bounds:
            ci_str = f"{ci_bounds.get('low', '')} – {ci_bounds.get('high', '')}"

        sat_info = saturation.get(ch_name, {})
        sat_status = sat_info.get("status", "unknown")
        sat_pct = sat_info.get("saturation_pct", 0)

        mroas_val = marginal_roas_data.get(ch_name, 0)

        # Trend
        if not memory_changes:
            trend = "—"
        elif ch_name not in memory_changes:
            trend = "New"
        else:
            ch_delta = memory_changes[ch_name]
            delta_status = ch_delta.get("status", "")
            change_pct = ch_delta.get("change_pct", 0)
            if delta_status == "new":
                trend = "New"
            elif delta_status == "stable":
                trend = f"→ {change_pct:+.1f}%"
            elif delta_status == "changed":
                arrow = "↑" if change_pct > 0 else "↓"
                trend = f"{arrow} {change_pct:+.1f}%"
            else:
                trend = "—"

        channels.append(
            {
                "name": ch_name,
                "roas_value": f"{roas_val:.2f}x",
                "roas_ci": ci_str,
                "sat_status": sat_status,
                "sat_pct": sat_pct,
                "marginal_roas": f"{mroas_val:.2f}x",
                "trend": trend,
            }
        )

    # --- Build template context ---
    model_fit = result.get("model_fit", {})
    # Provide safe defaults for model_fit values
    if "r_squared" not in model_fit:
        model_fit["r_squared"] = 0.0
    if "mape" not in model_fit:
        model_fit["mape"] = 0.0

    # --- Platform attribution comparison ---
    raw_pc = result.get("platform_attribution_comparison", {})
    platform_comparison: dict = {}
    if raw_pc and raw_pc.get("channels"):
        # Deep-copy so we don't mutate the original result dict
        import copy

        platform_comparison = copy.deepcopy(raw_pc)

        # Free-tier gating: strip platform_revenue dollar values
        license_info = result.get("license", {})
        is_free = license_info.get("tier", "free") == "free"
        if is_free:
            for ch_data in platform_comparison["channels"].values():
                ch_data["platform_revenue"] = None

        # Build summary_narrative from the summary sub-dict
        pc_summary = platform_comparison.get("summary", {})
        most_egregious = pc_summary.get("most_egregious")
        under_claiming = pc_summary.get("channels_under_claiming", [])
        all_channels = platform_comparison["channels"]

        if most_egregious:
            worst_ch = most_egregious["channel"]
            one_liner = all_channels[worst_ch].get("one_liner", "")
            narrative = (
                f"{one_liner} "
                f"Platform self-attribution typically overstates revenue by 20\u201340% "
                f"due to overlapping attribution windows \u2014 MixLift\u2019s incrementality "
                f"model is based on actual revenue lift."
            )
        elif under_claiming:
            ch_list = ", ".join(under_claiming)
            narrative = (
                f"MixLift measures higher ROAS than platforms report for {ch_list}. "
                f"This often indicates that platform attribution windows are too narrow "
                f"and miss view-through or cross-channel assists."
            )
        else:
            narrative = (
                "Platform-reported ROAS is broadly consistent with MixLift\u2019s "
                "incrementality estimates across all measured channels."
            )

        platform_comparison["summary_narrative"] = narrative

    # --- Backtest section ---
    license_info = result.get("license", {})
    is_free = license_info.get("tier", "free") == "free"
    raw_backtest = result.get("backtest", {})
    backtest_narrative = ""
    if (
        raw_backtest
        and isinstance(raw_backtest, dict)
        and raw_backtest.get("status") == "success"
        and raw_backtest.get("folds")
    ):
        backtest_narrative = _backtest_narrative(raw_backtest, is_free)

    context = {
        "title": "Budget Optimization Report",
        "run_date": date.today().isoformat(),
        "headline": result.get("headline", ""),
        "badge": result.get("analysis_badge"),
        "summary": result.get("recommendations", {}).get("summary", ""),
        "model_fit": model_fit,
        "loo_cv": result.get("loo_cv"),
        "convergence_warnings": result.get("diagnostics", {}).get("convergence_warnings", []),
        "channels": channels,
        "actions": actions,
        "data_window": data_window,
        "mcmc_config": mcmc_config,
        "platform_comparison": platform_comparison,
        "backtest": raw_backtest,
        "backtest_narrative": backtest_narrative,
        "is_free": is_free,
        "fmt_roas": _fmt_roas,
        "fmt_gap": _fmt_gap,
        "verdict_label": _verdict_label,
    }

    # --- Render ---
    env = Environment(
        loader=FileSystemLoader(str(_REPORT_TEMPLATE_DIR)),
        autoescape=True,
    )
    template = env.get_template("report.html.j2")
    html = template.render(**context)

    # --- Write ---
    out = Path(output_path)
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html)
    except Exception as e:
        return {"status": "error", "message": f"Failed to write report: {e}"}

    return {"status": "success", "output_path": str(out)}
