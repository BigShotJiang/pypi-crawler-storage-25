"""OAuth 2.1 bearer-token verifier for MixLift Cloud (Fly.io resource server).

Implements FastMCP's ``TokenVerifier`` protocol using RS256 JWTs issued by
api.mixlift.io.  JWKS are cached in-process with a configurable TTL so that
every MCP tool call does **not** require a network round-trip.

Custom claims carried by the JWT::

    tier         "free" | "pro" | "growth"
    license_key  "MIXLIFT-…"  (optional — absent for new OAuth-only accounts)

These are stored on a ``MixLiftAccessToken`` subclass so tool handlers can
read them without a separate API call.

Design notes
------------
- Returns ``None`` on ANY validation error — never raises.  Auth fails closed.
- ``jwt.PyJWKClient`` is synchronous internally; cache hits are O(1) dict
  lookups so the blocking overhead is negligible.
- The ``extra`` dict is NOT exposed to external callers by FastMCP; it is only
  used internally by ``_resolve_license`` in ``server.py``.
"""

from __future__ import annotations

import logging
import os
from typing import Any

import jwt
from mcp.server.auth.provider import AccessToken, TokenVerifier

logger = logging.getLogger(__name__)

DEFAULT_ISSUER = "https://api.mixlift.io"
DEFAULT_AUDIENCE = "https://mixlift-cloud.fly.dev"


class MixLiftAccessToken(AccessToken):
    """AccessToken subclass that carries MixLift-specific JWT claims.

    ``extra`` holds at minimum ``{"tier": str}`` and optionally
    ``{"license_key": str}``.  FastMCP does not inspect or serialize this field.
    """

    extra: dict[str, Any] = {}


class MixLiftTokenVerifier(TokenVerifier):
    """Verify RS256 JWTs issued by api.mixlift.io.

    Args:
        jwks_url:  JWKS endpoint URL.  Defaults to ``OAUTH_JWKS_URL`` env var,
                   then ``{issuer}/.well-known/jwks.json``.
        issuer:    Expected ``iss`` claim.  Defaults to ``OAUTH_ISSUER_URL``.
        audience:  Expected ``aud`` claim.  Defaults to ``OAUTH_AUDIENCE``.
    """

    def __init__(
        self,
        jwks_url: str | None = None,
        issuer: str | None = None,
        audience: str | None = None,
    ) -> None:
        self._issuer = issuer or os.environ.get("OAUTH_ISSUER_URL", DEFAULT_ISSUER)
        self._audience = audience or os.environ.get("OAUTH_AUDIENCE", DEFAULT_AUDIENCE)
        resolved_jwks = (
            jwks_url
            or os.environ.get("OAUTH_JWKS_URL")
            or f"{self._issuer}/.well-known/jwks.json"
        )
        # cache_jwk_set=True keeps the key set in memory; lifespan=3600 re-fetches
        # after 1 hour so key rotations propagate within that window.
        self._jwks_client = jwt.PyJWKClient(
            resolved_jwks,
            cache_jwk_set=True,
            lifespan=3600,
        )

    async def verify_token(self, token: str) -> MixLiftAccessToken | None:
        """Validate *token* and return a populated ``MixLiftAccessToken`` or ``None``.

        Validation steps (all must pass):
        1. Retrieve signing key from JWKS using the JWT ``kid`` header.
        2. Decode and verify signature, ``iss``, ``aud``, and ``exp``.
        3. Build ``MixLiftAccessToken`` from standard + custom claims.

        Returns ``None`` (not raises) on any failure so FastMCP enforces 401
        via ``RequireAuthMiddleware``.
        """
        try:
            signing_key = self._jwks_client.get_signing_key_from_jwt(token)
        except Exception as exc:  # network error, malformed header, unknown kid…
            logger.info("oauth_verifier: JWKS key fetch failed: %s", exc)
            return None

        try:
            claims: dict[str, Any] = jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=self._audience,
                issuer=self._issuer,
            )
        except jwt.PyJWTError as exc:
            logger.info("oauth_verifier: token rejected: %s", exc)
            return None

        extra: dict[str, Any] = {"tier": claims.get("tier", "free")}
        if "license_key" in claims:
            extra["license_key"] = claims["license_key"]

        return MixLiftAccessToken(
            token=token,
            client_id=str(claims["sub"]),
            scopes=claims.get("scope", "").split(),
            expires_at=int(claims["exp"]),
            extra=extra,
        )
