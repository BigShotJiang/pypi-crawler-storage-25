"""Structured logging configuration for MixLift Cloud.

Call ``configure_logging()`` once at server startup. When ``LOG_FORMAT=json``
the root logger emits compact JSON lines; otherwise Python's default format is
kept so local/CI output remains human-readable.

No third-party deps required: the JSON formatter is hand-rolled so that
``sentry-sdk`` and ``python-json-logger`` stay optional.
"""

from __future__ import annotations

import json
import logging
import os
import time
from contextvars import ContextVar
from typing import Any

# Populated by request_id middleware; read here for log enrichment.
# Imported lazily to avoid a circular-import if this module is loaded early.
_request_id_var: ContextVar[str | None] = ContextVar("_logging_request_id_var", default=None)

_CONFIGURED = False


class _JsonFormatter(logging.Formatter):
    """Emit each log record as a single JSON object on one line."""

    def format(self, record: logging.LogRecord) -> str:
        # Attempt to pull request_id from the canonical ContextVar in
        # request_id.py; fall back to the local var (set by the middleware via
        # configure_logging's injection hook).
        req_id: str | None = None
        try:
            from mixlift_mcp.request_id import request_id_var

            req_id = request_id_var.get(None)
        except Exception:
            req_id = _request_id_var.get(None)

        # Attempt to pull tenant hash from metering identity if available.
        tenant: str | None = None
        try:
            # The tenant hash is context-specific; expose a hook via a module-level var.
            from mixlift_mcp import logging_config as _self
            from mixlift_mcp._metering_identity import _extract_source_ip  # noqa: F401

            tenant = getattr(_self, "_current_tenant", None)
        except Exception:
            pass

        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "file": record.filename,
            "line": record.lineno,
        }
        if req_id is not None:
            payload["request_id"] = req_id
        if tenant is not None:
            payload["tenant"] = tenant
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def configure_logging() -> None:
    """Configure JSON logs when ``LOG_FORMAT=json``, else keep plain defaults.

    Idempotent: subsequent calls are no-ops.
    """
    global _CONFIGURED
    if _CONFIGURED:
        return
    _CONFIGURED = True

    fmt = os.environ.get("LOG_FORMAT", "").lower()
    if fmt != "json":
        return

    formatter = _JsonFormatter()
    root = logging.getLogger()
    if not root.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(formatter)
        root.addHandler(handler)
        root.setLevel(logging.INFO)
    else:
        for handler in root.handlers:
            handler.setFormatter(formatter)
