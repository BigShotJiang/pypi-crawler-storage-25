"""Metering for MixLift quota enforcement.

Public entry point: ``check_and_increment_remote`` (async).

On success, delegates to the shared store at api.mixlift.io. On any network
failure or non-2xx response, falls back transparently to the local
``~/.mixlift/usage.json`` file so legacy pip-install users are never broken.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

import httpx

logger = logging.getLogger(__name__)

USAGE_FILE = Path.home() / ".mixlift" / "usage.json"

# Env var already used by license.py; reuse here.
_LICENSE_API_URL = os.environ.get("LICENSE_API_URL", "https://api.mixlift.io")
_METERING_ENDPOINT = f"{_LICENSE_API_URL}/v1/metering/check_and_increment"
_HTTP_TIMEOUT = 2.0  # seconds


# --------------------------------------------------------------------------- #
# Local file fallback (legacy; also used when API is unreachable)
# --------------------------------------------------------------------------- #


def _local_file_fallback_check_and_increment(
    max_free_runs: int = 2,
) -> tuple[bool, str]:
    """Local file-based metering — used when API is unreachable.

    Maintains ``~/.mixlift/usage.json`` with ``{month, runs}`` structure.
    Returns ``(allowed, message)``.
    """
    current_month = datetime.now().strftime("%Y-%m")

    usage: dict = {"month": current_month, "runs": 0}
    try:
        if USAGE_FILE.exists():
            usage = json.loads(USAGE_FILE.read_text())
            if usage.get("month") != current_month:
                usage = {"month": current_month, "runs": 0}
    except Exception:
        usage = {"month": current_month, "runs": 0}

    if usage["runs"] >= max_free_runs:
        return False, (
            f"Free tier limit reached ({max_free_runs} analyses/month). "
            "Upgrade to Growth ($299/mo) for unlimited analyses at https://mixlift.io/pricing"
        )

    usage["runs"] += 1
    try:
        USAGE_FILE.parent.mkdir(parents=True, exist_ok=True)
        USAGE_FILE.write_text(json.dumps(usage))
    except Exception as exc:
        logger.warning("Could not save usage data: %s", exc)

    remaining = max_free_runs - usage["runs"]
    return True, (
        f"Free tier: {usage['runs']}/{max_free_runs} analyses used this month "
        f"({remaining} remaining)"
    )


# Keep the old name as an alias so existing imports in tests don't break
def check_and_increment(max_free_runs: int = 2) -> tuple[bool, str]:
    """Synchronous local-file check (legacy alias).

    New code should use ``check_and_increment_remote`` instead.
    """
    return _local_file_fallback_check_and_increment(max_free_runs)


# --------------------------------------------------------------------------- #
# Shared-store metering (async, with local fallback)
# --------------------------------------------------------------------------- #


def _current_period(daily: bool = False) -> str:
    """Return the current UTC period string: YYYY-MM-DD (daily) or YYYY-MM (monthly)."""
    now = datetime.now(timezone.utc)
    return now.strftime("%Y-%m-%d") if daily else now.strftime("%Y-%m")


async def check_and_increment_remote(
    identity_hash: str,
    limit: int,
    period: str | None = None,
    *,
    daily: bool = False,
) -> tuple[bool, int]:
    """Check quota and increment counter in the shared store on api.mixlift.io.

    Args:
        identity_hash: 64-char hex SHA-256 built by ``build_identity_hash()``.
        limit: Maximum allowed count for the period.
        period: Override the period string (defaults to current UTC month/day).
        daily: If True and period is None, use a daily window (YYYY-MM-DD).

    Returns:
        ``(allowed, count)`` — (True, new_count) on success or
        (False, current_count) when the limit is exhausted.

    On any network or API error, falls back to the local file helper and
    converts its ``(bool, str)`` result to ``(bool, int)`` by synthesising a
    count (0 or limit) so callers have a uniform interface.
    """
    effective_period = period if period is not None else _current_period(daily=daily)
    correlation_id = uuid.uuid4().hex

    try:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            response = await client.post(
                _METERING_ENDPOINT,
                json={
                    "identity_hash": identity_hash,
                    "period": effective_period,
                    "limit": limit,
                },
            )
            if response.status_code == 200:
                data = response.json()
                return data["allowed"], data["count"]

            # Non-2xx from API → fall through to local fallback
            logger.warning(
                "metering: API returned %d, falling back to local file (correlation_id=%s)",
                response.status_code,
                correlation_id,
            )
    except (httpx.TimeoutException, httpx.NetworkError, httpx.ConnectError) as exc:
        logger.warning(
            "metering: falling back to local file (reason=%s, correlation_id=%s)",
            type(exc).__name__,
            correlation_id,
        )
    except Exception as exc:
        logger.warning(
            "metering: unexpected error, falling back to local file (reason=%s, correlation_id=%s)",
            exc,
            correlation_id,
        )

    # Local fallback — convert (bool, str) → (bool, int)
    allowed, _msg = _local_file_fallback_check_and_increment(max_free_runs=limit)
    return allowed, (1 if allowed else limit)
