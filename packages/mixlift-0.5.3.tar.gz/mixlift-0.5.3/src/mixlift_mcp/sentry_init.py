"""Sentry initialisation for MixLift Cloud.

``init_sentry()`` is a no-op when ``SENTRY_DSN`` is unset, so dev/CI
installs without ``sentry-sdk`` work without changes.

PII scrubbing
-------------
``_scrub_pii`` removes:
- E-mail-like strings (``user@domain.tld``)
- MixLift license keys (``MIXLIFT-*``)

from ``event["request"]["data"]``, ``event["extra"]``, and each entry in
``event["breadcrumbs"]["values"]``.  Values are replaced with ``"[REDACTED]"``
or the masked form ``"MIXLIFT-***"``.  The scrub count is logged at DEBUG.
"""

from __future__ import annotations

import logging
import os
import re
from typing import Any

logger = logging.getLogger(__name__)

_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", re.ASCII)
_LICENSE_RE = re.compile(r"MIXLIFT-[A-Za-z0-9\-]+")


def _scrub_value(v: Any, counts: list[int]) -> Any:
    """Recursively scrub PII from a value; mutate ``counts[0]`` for each hit."""
    if isinstance(v, str):
        new_v = _EMAIL_RE.sub("[REDACTED]", v)
        new_v = _LICENSE_RE.sub("MIXLIFT-***", new_v)
        if new_v != v:
            counts[0] += 1
        return new_v
    if isinstance(v, dict):
        return {k: _scrub_value(val, counts) for k, val in v.items()}
    if isinstance(v, list):
        return [_scrub_value(item, counts) for item in v]
    return v


def _scrub_pii(event: dict[str, Any], hint: Any = None) -> dict[str, Any]:  # noqa: ARG001
    """Scrub PII from a Sentry event before it is sent."""
    counts: list[int] = [0]

    # event["request"]["data"]
    req = event.get("request")
    if isinstance(req, dict) and "data" in req:
        req["data"] = _scrub_value(req["data"], counts)

    # event["extra"]
    if "extra" in event:
        event["extra"] = _scrub_value(event["extra"], counts)

    # event["breadcrumbs"]["values"]
    breadcrumbs = event.get("breadcrumbs")
    if isinstance(breadcrumbs, dict):
        values = breadcrumbs.get("values")
        if isinstance(values, list):
            breadcrumbs["values"] = _scrub_value(values, counts)

    if counts[0]:
        logger.debug("sentry_pii_scrub: replaced %d value(s)", counts[0])

    return event


def init_sentry() -> None:
    """Initialise Sentry when ``SENTRY_DSN`` is set. No-op otherwise."""
    dsn = os.environ.get("SENTRY_DSN", "")
    if not dsn:
        return

    import sentry_sdk  # lazy import — not required in dev/CI
    from sentry_sdk.integrations.starlette import StarletteIntegration

    sentry_sdk.init(
        dsn=dsn,
        traces_sample_rate=float(os.environ.get("SENTRY_TRACES_SAMPLE_RATE", "0.1")),
        environment=os.environ.get("ENVIRONMENT", "production"),
        release=os.environ.get("MIXLIFT_VERSION", "unknown"),
        integrations=[StarletteIntegration()],
        before_send=_scrub_pii,
    )
    logger.info("Sentry initialised: environment=%s", os.environ.get("ENVIRONMENT", "production"))
