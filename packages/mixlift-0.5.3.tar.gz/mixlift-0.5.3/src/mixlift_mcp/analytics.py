"""GA4 Measurement Protocol client for the MCP server.

Used to fire the ``first_analyze`` milestone event the first time a given
identity calls ``mixlift_analyze``. Best-effort throughout — a 500 ms HTTP
timeout and per-call try/except guarantee analytics never block or break
the tool.

State lives at ``~/.mixlift/analytics_state.json`` alongside the metering
file; the single tracked field is ``first_analyze_fired`` (list of
identity hashes that have already fired).
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

import httpx

from mixlift_mcp._metering_identity import build_identity_hash

if TYPE_CHECKING:
    from mcp.server.fastmcp import Context

logger = logging.getLogger(__name__)

_STATE_FILE = Path.home() / ".mixlift" / "analytics_state.json"
_MP_ENDPOINT = "https://www.google-analytics.com/mp/collect"
_HTTP_TIMEOUT = 0.5  # never block a tool call on analytics


def _measurement_id() -> str:
    return os.environ.get("GA4_MEASUREMENT_ID", "G-NQ59GP2FD6")


def _api_secret() -> str:
    return os.environ.get("GA4_API_SECRET", "")


def _load_state() -> dict:
    try:
        if _STATE_FILE.exists():
            return json.loads(_STATE_FILE.read_text())
    except Exception:
        logger.debug("analytics state load failed", exc_info=True)
    return {"first_analyze_fired": []}


def _save_state(state: dict) -> None:
    try:
        _STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _STATE_FILE.write_text(json.dumps(state))
    except Exception:
        logger.debug("analytics state save failed", exc_info=True)


async def _send_event(name: str, params: dict, user_id: str) -> None:
    """POST a single event to GA4 Measurement Protocol. Best-effort."""
    secret = _api_secret()
    if not secret:
        logger.debug("GA4_API_SECRET unset — dropping event=%s", name)
        return
    url = f"{_MP_ENDPOINT}?measurement_id={_measurement_id()}&api_secret={secret}"
    payload = {
        "client_id": f"mcp.{user_id}",
        "user_id": user_id,
        "events": [{"name": name, "params": params}],
    }
    try:
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            await client.post(url, json=payload)
    except Exception:
        logger.debug("GA4 MP send failed: event=%s", name, exc_info=True)


async def maybe_fire_first_analyze(
    license_key: str,
    is_pro: bool,
    ctx: "Context | None" = None,
) -> None:
    """Fire ``first_analyze`` once per identity. Safe to await from a tool handler.

    Identity derivation matches the metering path (OAuth sub → license key →
    source IP), so a pro user who upgrades from free tier is tracked as a
    distinct "first" once authenticated.
    """
    try:
        identity_hash, _ = build_identity_hash(
            license_key=license_key, is_pro=is_pro, ctx=ctx
        )
    except Exception:
        logger.debug("build_identity_hash failed", exc_info=True)
        return

    state = _load_state()
    fired = state.get("first_analyze_fired", [])
    if identity_hash in fired:
        return

    # Persist before sending — prefer a missed fire over a duplicate.
    fired.append(identity_hash)
    state["first_analyze_fired"] = fired
    _save_state(state)

    await _send_event(
        "first_analyze",
        {"tier": "pro" if is_pro else "free"},
        user_id=identity_hash,
    )
