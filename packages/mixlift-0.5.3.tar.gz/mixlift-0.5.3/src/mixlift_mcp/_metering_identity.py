"""Build the opaque identity hash used for metering quota enforcement.

Priority order (mirrors api.mixlift.io design doc):
1. Validated OAuth bearer token present → sha256("user:" + sub)
2. ``license_key`` param present and non-empty → sha256("license:" + license_key)
3. Neither → sha256("ip:" + source_ip)

The FastMCP ``Context`` object's ``_request_context.request`` field holds the raw
Starlette ``Request`` when the server is running over HTTP/SSE transport (Fly Cloud
path). For the local stdio transport ``request`` is None, so we fall back to a
sentinel IP of ``"127.0.0.1"``.
"""

from __future__ import annotations

import hashlib
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mcp.server.fastmcp import Context

logger = logging.getLogger(__name__)


def _sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def _extract_source_ip(ctx: "Context | None") -> str:
    """Extract the source IP from the FastMCP request context.

    On Fly.io, the load balancer injects X-Forwarded-For before the request
    reaches the container. We read ``ctx._request_context.request`` (a Starlette
    ``Request``) and check that header first; fall back to
    ``request.client.host`` if the header is absent; fall back to ``"127.0.0.1"``
    if ctx is None or not on an HTTP transport.
    """
    if ctx is None:
        return "127.0.0.1"

    try:
        rc = ctx._request_context  # type: ignore[attr-defined]
        if rc is None:
            return "127.0.0.1"
        request = rc.request  # Starlette Request or None for stdio
        if request is None:
            return "127.0.0.1"

        # X-Forwarded-For: leftmost entry is the original client IP (Fly injects this)
        forwarded_for = request.headers.get("x-forwarded-for", "")
        if forwarded_for:
            ip = forwarded_for.split(",")[0].strip()
            if ip:
                return ip

        # Direct connection host
        client = request.client
        if client and client.host:
            return client.host
    except Exception as exc:
        logger.debug("_extract_source_ip failed: %s", exc)

    return "127.0.0.1"


def build_identity_hash(
    license_key: str,
    is_pro: bool,
    ctx: "Context | None" = None,
) -> tuple[str, bool]:
    """Return ``(identity_hash, is_paid_tier)`` for quota enforcement.

    Checks (in priority order):
    1. OAuth bearer token present in request context → ``sha256("user:" + sub)``.
    2. ``license_key`` non-empty → ``sha256("license:" + license_key)``.
    3. Fallback → ``sha256("ip:" + source_ip)``.

    The second return value indicates whether paid-tier limits apply (True)
    or free-tier limits apply (False).
    """
    # 1. OAuth bearer token path
    try:
        from mcp.server.auth.middleware.auth_context import get_access_token

        token = get_access_token()
        if token is not None:
            # ``client_id`` on AccessToken holds the user_id (the MCP subject)
            sub = getattr(token, "client_id", None) or str(token)
            return _sha256_hex(f"user:{sub}"), True
    except Exception:
        pass  # OAuth not enabled or not available

    # 2. Legacy license_key path
    if license_key:
        return _sha256_hex(f"license:{license_key}"), is_pro

    # 3. IP fallback
    source_ip = _extract_source_ip(ctx)
    return _sha256_hex(f"ip:{source_ip}"), False
