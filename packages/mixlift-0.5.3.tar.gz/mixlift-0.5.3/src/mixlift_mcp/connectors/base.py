"""Base connector interface and shared utilities."""

from __future__ import annotations

import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)

# Canonical columns from platform API data (long format)
CANONICAL_COLUMNS = ["date", "channel", "spend", "revenue"]


@dataclass
class DateRange:
    """A date range for API queries."""

    start: date
    end: date

    @classmethod
    def from_spec(cls, spec: str) -> DateRange:
        """Parse a date range specification.

        Supports:
        - "last_90_days", "last_180_days", "last_365_days"
        - "YYYY-MM-DD:YYYY-MM-DD" (explicit range)
        - "" (default: last 180 days)
        """
        spec = spec.strip().lower()
        today = date.today()

        if not spec or spec == "last_180_days":
            return cls(start=today - timedelta(days=180), end=today)

        if spec.startswith("last_"):
            try:
                days = int(spec.replace("last_", "").replace("_days", ""))
                return cls(start=today - timedelta(days=days), end=today)
            except ValueError:
                pass

        if ":" in spec:
            parts = spec.split(":")
            if len(parts) == 2:
                return cls(
                    start=date.fromisoformat(parts[0].strip()),
                    end=date.fromisoformat(parts[1].strip()),
                )

        raise ValueError(
            f"Invalid date range: '{spec}'. "
            f"Use 'last_90_days', 'last_180_days', or 'YYYY-MM-DD:YYYY-MM-DD'."
        )


@dataclass
class ConnectorResult:
    """Result of pulling data from a platform API."""

    platform: str
    df: pd.DataFrame  # canonical format: date, channel, spend, revenue
    date_range: DateRange
    channels_found: list[str]
    row_count: int


class BaseConnector(ABC):
    """Abstract base class for ad platform connectors."""

    platform: str = "unknown"

    def __init__(self, access_token: str) -> None:
        self.access_token = access_token

    @abstractmethod
    async def pull(
        self,
        account_id: str,
        date_range: DateRange,
        granularity: str = "platform",
    ) -> ConnectorResult:
        """Pull spend + revenue data from the platform API.

        Args:
            account_id: Platform-specific ad account identifier.
            date_range: Date range to pull.
            granularity: "platform" (aggregate all campaigns into one channel)
                         or "campaign" (each campaign is a separate channel).

        Returns:
            ConnectorResult with canonical DataFrame.
        """
        ...

    @abstractmethod
    async def validate_token(self) -> bool:
        """Check if the access token is valid."""
        ...


def to_wide_format(results: list[ConnectorResult]) -> pd.DataFrame:
    """Merge one or more ConnectorResults into wide-format DataFrame.

    Wide format has columns: date, {channel}_spend, revenue
    This is what mixlift_analyze expects.
    """
    # Combine all canonical DataFrames
    dfs = [r.df for r in results]
    combined = pd.concat(dfs, ignore_index=True)

    # Aggregate to daily by channel
    daily = (
        combined.groupby(["date", "channel"])
        .agg({"spend": "sum", "revenue": "sum"})
        .reset_index()
    )

    # Pivot spend columns
    spend_pivot = daily.pivot_table(
        index="date", columns="channel", values="spend", aggfunc="sum"
    ).fillna(0)
    spend_pivot.columns = [f"{c}_spend" for c in spend_pivot.columns]

    # Aggregate revenue across all channels per day
    revenue_daily = daily.groupby("date")["revenue"].sum().reset_index()

    # Merge
    wide = spend_pivot.reset_index().merge(revenue_daily, on="date", how="left")
    wide = wide.sort_values("date").reset_index(drop=True)

    # Clean channel names for column headers
    clean_cols: dict[str, str] = {}
    for col in wide.columns:
        if col.endswith("_spend"):
            channel_part = col[:-6]  # strip "_spend"
            clean = re.sub(r"[^a-z0-9]+", "_", channel_part.lower()).strip("_")
            clean_cols[col] = f"{clean}_spend"
        else:
            clean_cols[col] = col
    wide = wide.rename(columns=clean_cols)

    return wide


def save_wide_csv(wide_df: pd.DataFrame, output_dir: str, label: str = "connected") -> Path:
    """Save a wide-format DataFrame as CSV.

    Returns the path to the saved file.
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    filename = f"mixlift_{label}_{date.today().isoformat()}.csv"
    filepath = output_path / filename
    wide_df.to_csv(filepath, index=False)
    logger.info("Saved wide-format CSV: %s (%d rows)", filepath, len(wide_df))
    return filepath
