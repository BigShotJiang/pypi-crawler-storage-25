"""Meta (Facebook/Instagram) Ads API connector."""

from __future__ import annotations

import logging

import pandas as pd

from mixlift_mcp.connectors.base import BaseConnector, ConnectorResult, DateRange

logger = logging.getLogger(__name__)


def _require_sdk() -> tuple:
    """Lazy import of facebook_business SDK with clear error."""
    try:
        from facebook_business.adobjects.adaccount import AdAccount
        from facebook_business.api import FacebookAdsApi

        return FacebookAdsApi, AdAccount
    except ImportError:
        raise ImportError(
            "Meta Ads connector requires the facebook-business SDK. "
            "Install it with: pip install mixlift[connectors]"
        )


class MetaConnector(BaseConnector):
    """Pull spend + revenue data from Meta Marketing API."""

    platform = "meta"

    async def validate_token(self) -> bool:
        """Check if the access token is valid by making a lightweight API call."""
        fb_api_cls, _ = _require_sdk()
        try:
            api = fb_api_cls.init(access_token=self.access_token)
            me = api.call("GET", "/me", params={"fields": "id"})
            return me.status_code == 200
        except Exception:
            return False

    async def pull(
        self,
        account_id: str,
        date_range: DateRange,
        granularity: str = "platform",
    ) -> ConnectorResult:
        """Pull campaign insights from Meta Marketing API.

        Uses the /insights endpoint with daily time_increment.
        Extracts: spend, actions (purchase), action_values (purchase value).

        Args:
            account_id: Meta ad account ID (with or without "act_" prefix).
            date_range: Date range to pull.
            granularity: "platform" aggregates all campaigns into "Meta";
                         "campaign" keeps each campaign as a separate channel.

        Returns:
            ConnectorResult with canonical DataFrame (date, channel, spend, revenue).
        """
        fb_api_cls, ad_account_cls = _require_sdk()

        if not account_id.startswith("act_"):
            account_id = f"act_{account_id}"

        fb_api_cls.init(access_token=self.access_token)
        account = ad_account_cls(account_id)

        params = {
            "time_range": {
                "since": date_range.start.isoformat(),
                "until": date_range.end.isoformat(),
            },
            "time_increment": 1,  # daily granularity
            "level": "campaign" if granularity == "campaign" else "account",
            "fields": [
                "campaign_name",
                "spend",
                "impressions",
                "clicks",
                "actions",
                "action_values",
            ],
        }

        logger.info(
            "Pulling Meta data: account=%s, range=%s to %s, granularity=%s",
            account_id,
            date_range.start,
            date_range.end,
            granularity,
        )

        insights = account.get_insights(params=params)
        rows = []
        for insight in insights:
            row = {
                "date": insight.get("date_start"),
                "campaign": insight.get("campaign_name", "Meta"),
                "spend": float(insight.get("spend", 0)),
                "revenue": 0.0,
            }

            # Extract purchase revenue from action_values
            action_values = insight.get("action_values", [])
            for av in action_values:
                if av.get("action_type") in (
                    "purchase",
                    "omni_purchase",
                    "offsite_conversion.fb_pixel_purchase",
                ):
                    row["revenue"] += float(av.get("value", 0))

            rows.append(row)

        if not rows:
            logger.warning("No data returned from Meta API for %s", account_id)
            return ConnectorResult(
                platform="meta",
                df=pd.DataFrame(columns=["date", "channel", "spend", "revenue"]),
                date_range=date_range,
                channels_found=[],
                row_count=0,
            )

        df = pd.DataFrame(rows)
        df["date"] = pd.to_datetime(df["date"])

        if granularity == "platform":
            df = (
                df.groupby("date")
                .agg({"spend": "sum", "revenue": "sum"})
                .reset_index()
            )
            df["channel"] = "Meta"
        else:
            df = df.rename(columns={"campaign": "channel"})

        df = df[["date", "channel", "spend", "revenue"]]
        channels: list[str] = df["channel"].unique().tolist()

        logger.info(
            "Meta pull complete: %d rows, %d channels, %s to %s",
            len(df),
            len(channels),
            date_range.start,
            date_range.end,
        )

        return ConnectorResult(
            platform="meta",
            df=df,
            date_range=date_range,
            channels_found=channels,
            row_count=len(df),
        )
