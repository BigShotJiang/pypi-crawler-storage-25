"""Ad platform API connectors for MixLift.

Connectors pull marketing spend + revenue data from ad platform APIs
and produce wide-format CSVs compatible with mixlift_analyze.

Install connector dependencies: pip install mixlift[connectors]
"""

from mixlift_mcp.connectors.base import BaseConnector

__all__ = ["BaseConnector"]
