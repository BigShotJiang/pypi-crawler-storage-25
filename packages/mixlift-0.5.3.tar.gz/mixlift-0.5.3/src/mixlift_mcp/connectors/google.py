"""Google Ads API connector."""

from __future__ import annotations

import json
import logging

import pandas as pd

from mixlift_mcp.connectors.base import BaseConnector, ConnectorResult, DateRange

logger = logging.getLogger(__name__)


def _require_sdk() -> type:
    """Lazy import of google-ads SDK with clear error."""
    try:
        from google.ads.googleads.client import GoogleAdsClient

        return GoogleAdsClient
    except ImportError:
        raise ImportError(
            "Google Ads connector requires the google-ads SDK. "
            "Install it with: pip install mixlift[connectors]"
        )


class GoogleConnector(BaseConnector):
    """Pull spend + revenue data from Google Ads API.

    The access_token should be a JSON string with the following keys:
        developer_token   — required
        client_id         — required
        client_secret     — required
        refresh_token     — required
        login_customer_id — optional, for MCC (manager) accounts
    """

    platform = "google"

    def _get_client(self) -> object:
        """Initialize Google Ads client from token JSON."""
        google_ads_client_cls = _require_sdk()

        creds = json.loads(self.access_token)
        config: dict = {
            "developer_token": creds["developer_token"],
            "client_id": creds["client_id"],
            "client_secret": creds["client_secret"],
            "refresh_token": creds["refresh_token"],
            "use_proto_plus": True,
        }
        if creds.get("login_customer_id"):
            config["login_customer_id"] = creds["login_customer_id"]

        return google_ads_client_cls.load_from_dict(config)

    async def validate_token(self) -> bool:
        """Check if credentials are valid by attempting client initialization."""
        try:
            client = self._get_client()
            return client is not None
        except Exception:
            return False

    async def pull(
        self,
        account_id: str,
        date_range: DateRange,
        granularity: str = "platform",
    ) -> ConnectorResult:
        """Pull campaign metrics from Google Ads API via GAQL.

        Queries segments.date, campaign.name (when granularity="campaign"),
        metrics.cost_micros, and metrics.conversions_value.

        Args:
            account_id: Google Ads customer ID (dashes are stripped automatically).
            date_range: Date range to pull.
            granularity: "platform" aggregates all campaigns into "Google";
                         "campaign" keeps each campaign as a separate channel.

        Returns:
            ConnectorResult with canonical DataFrame (date, channel, spend, revenue).
        """
        client = self._get_client()

        # Google Ads customer IDs are numeric; strip dashes if formatted
        customer_id = account_id.replace("-", "")

        if granularity == "campaign":
            query = (
                "SELECT "
                "    segments.date, "
                "    campaign.name, "
                "    metrics.cost_micros, "
                "    metrics.conversions_value "
                "FROM campaign "
                f"WHERE segments.date BETWEEN '{date_range.start.isoformat()}' "
                f"    AND '{date_range.end.isoformat()}' "
                "ORDER BY segments.date"
            )
        else:
            query = (
                "SELECT "
                "    segments.date, "
                "    metrics.cost_micros, "
                "    metrics.conversions_value "
                "FROM customer "
                f"WHERE segments.date BETWEEN '{date_range.start.isoformat()}' "
                f"    AND '{date_range.end.isoformat()}' "
                "ORDER BY segments.date"
            )

        logger.info(
            "Pulling Google data: customer=%s, range=%s to %s, granularity=%s",
            customer_id,
            date_range.start,
            date_range.end,
            granularity,
        )

        ga_service = client.get_service("GoogleAdsService")
        response = ga_service.search_stream(customer_id=customer_id, query=query)

        rows = []
        for batch in response:
            for row in batch.results:
                r: dict = {
                    "date": row.segments.date,
                    "channel": row.campaign.name if granularity == "campaign" else "Google",
                    "spend": row.metrics.cost_micros / 1_000_000,  # micros to dollars
                    "revenue": row.metrics.conversions_value,
                }
                rows.append(r)

        if not rows:
            logger.warning("No data returned from Google Ads API for %s", customer_id)
            return ConnectorResult(
                platform="google",
                df=pd.DataFrame(columns=["date", "channel", "spend", "revenue"]),
                date_range=date_range,
                channels_found=[],
                row_count=0,
            )

        df = pd.DataFrame(rows)
        df["date"] = pd.to_datetime(df["date"])
        df = df[["date", "channel", "spend", "revenue"]]
        channels: list[str] = df["channel"].unique().tolist()

        logger.info(
            "Google pull complete: %d rows, %d channels, %s to %s",
            len(df),
            len(channels),
            date_range.start,
            date_range.end,
        )

        return ConnectorResult(
            platform="google",
            df=df,
            date_range=date_range,
            channels_found=channels,
            row_count=len(df),
        )
