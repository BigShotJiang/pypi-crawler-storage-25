"""TikTok Ads API connector."""

from __future__ import annotations

import logging

import httpx
import pandas as pd

from mixlift_mcp.connectors.base import BaseConnector, ConnectorResult, DateRange

logger = logging.getLogger(__name__)

TIKTOK_API_BASE = "https://business-api.tiktok.com/open_api/v1.3"


class TikTokConnector(BaseConnector):
    """Pull spend + revenue data from TikTok Business API.

    Uses the Integrated Report endpoint for campaign-level metrics.
    access_token is the TikTok Marketing API access token.
    """

    platform = "tiktok"

    def _headers(self) -> dict:
        return {
            "Access-Token": self.access_token,
            "Content-Type": "application/json",
        }

    async def validate_token(self) -> bool:
        """Check if the access token is valid."""
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    f"{TIKTOK_API_BASE}/user/info/",
                    headers=self._headers(),
                )
                data = resp.json()
                return data.get("code") == 0
        except Exception:
            return False

    async def pull(
        self,
        account_id: str,
        date_range: DateRange,
        granularity: str = "platform",
    ) -> ConnectorResult:
        """Pull campaign metrics from TikTok Integrated Report API.

        Extracts: spend, complete_payment (revenue proxy), impressions, clicks.
        """
        # Build report request
        dimensions = ["stat_time_day"]
        if granularity == "campaign":
            dimensions.append("campaign_id")

        metrics = [
            "spend",
            "impressions",
            "clicks",
            "complete_payment",            # number of purchases
            "total_complete_payment_rate",
            "value_per_complete_payment",  # avg order value
        ]

        body = {
            "advertiser_id": account_id,
            "report_type": "BASIC",
            "data_level": "AUCTION_CAMPAIGN" if granularity == "campaign" else "AUCTION_ADVERTISER",
            "dimensions": dimensions,
            "metrics": metrics,
            "start_date": date_range.start.isoformat(),
            "end_date": date_range.end.isoformat(),
            "page_size": 1000,
            "page": 1,
        }

        logger.info(
            "Pulling TikTok data: advertiser=%s, range=%s to %s, granularity=%s",
            account_id,
            date_range.start,
            date_range.end,
            granularity,
        )

        all_rows: list[dict] = []
        page = 1

        async with httpx.AsyncClient() as client:
            while True:
                body["page"] = page
                resp = await client.post(
                    f"{TIKTOK_API_BASE}/report/integrated/get/",
                    headers=self._headers(),
                    json=body,
                )
                data = resp.json()

                if data.get("code") != 0:
                    msg = data.get("message", "Unknown TikTok API error")
                    raise RuntimeError(f"TikTok API error: {msg} (code={data.get('code')})")

                rows = data.get("data", {}).get("list", [])
                if not rows:
                    break

                for row in rows:
                    dims = row.get("dimensions", {})
                    mets = row.get("metrics", {})

                    spend = float(mets.get("spend", 0))
                    purchases = int(float(mets.get("complete_payment", 0)))
                    avg_value = float(mets.get("value_per_complete_payment", 0))
                    revenue = purchases * avg_value

                    r: dict = {
                        "date": dims.get("stat_time_day"),
                        "spend": spend,
                        "revenue": revenue,
                    }

                    if granularity == "campaign":
                        r["channel"] = f"TikTok_{dims.get('campaign_id', 'unknown')}"
                    else:
                        r["channel"] = "TikTok"

                    all_rows.append(r)

                # Pagination
                page_info = data.get("data", {}).get("page_info", {})
                total_pages = page_info.get("total_page", 1)
                if page >= total_pages:
                    break
                page += 1

        if not all_rows:
            logger.warning("No data returned from TikTok API for %s", account_id)
            return ConnectorResult(
                platform="tiktok",
                df=pd.DataFrame(columns=["date", "channel", "spend", "revenue"]),
                date_range=date_range,
                channels_found=[],
                row_count=0,
            )

        df = pd.DataFrame(all_rows)
        df["date"] = pd.to_datetime(df["date"])
        df = df[["date", "channel", "spend", "revenue"]]
        channels = df["channel"].unique().tolist()

        logger.info(
            "TikTok pull complete: %d rows, %d channels, %s to %s",
            len(df),
            len(channels),
            date_range.start,
            date_range.end,
        )

        return ConnectorResult(
            platform="tiktok",
            df=df,
            date_range=date_range,
            channels_found=channels,
            row_count=len(df),
        )
