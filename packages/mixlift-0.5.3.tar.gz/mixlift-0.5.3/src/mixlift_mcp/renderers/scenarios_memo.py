"""Analyst-memo renderer for the multi-scenario comparison grid.

Pure stdlib only — no numpy, pandas, or jinja.
Distinct from scenario_memo.py (single-scenario renderer).
"""

from __future__ import annotations

import re

from mixlift_mcp.renderers._helpers import fmt_dollars

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_EMDASH = "\u2014"  # — (U+2014)
_MINUS = "\u2212"  # − (U+2212)


def _parse_mcmc_config(mcmc_config: str | dict) -> tuple[int | None, int | None]:
    """Extract chains and draws from an mcmc_config string or dict."""
    if isinstance(mcmc_config, dict):
        chains = mcmc_config.get("chains")
        draws = mcmc_config.get("draws")
        return (int(chains) if chains is not None else None,
                int(draws) if draws is not None else None)

    chains: int | None = None
    draws: int | None = None
    m_chains = re.search(r"(\d+)\s+chains?", str(mcmc_config))
    if m_chains:
        chains = int(m_chains.group(1))
    m_draws = re.search(r"(\d+)\s+draws?", str(mcmc_config))
    if m_draws:
        draws = int(m_draws.group(1))
    return chains, draws


def _fmt_compact(x: int | float) -> str:
    """Format a dollar value compactly: $498k or $498,000 depending on magnitude."""
    v = int(round(x))
    if abs(v) >= 1_000_000:
        return f"${v / 1_000_000:.1f}M"
    if abs(v) >= 1_000:
        return f"${abs(v) // 1_000}k" if v >= 0 else f"{_MINUS}${abs(v) // 1_000}k"
    return fmt_dollars(v)


def _fmt_delta_compact(x: int | float) -> str:
    """Format a signed delta compactly: +$18k or −$4k or —."""
    if x == 0:
        return _EMDASH
    v = int(round(x))
    sign = "+" if v > 0 else _MINUS
    abs_val = abs(v)
    if abs_val >= 1_000_000:
        return f"{sign}${abs_val / 1_000_000:.1f}M"
    if abs_val >= 1_000:
        return f"{sign}${abs_val // 1_000}k"
    return f"{sign}${abs_val:,}"


def _fmt_pct_delta(x: float) -> str:
    """Format a signed pct delta: +3.8% or −0.8% or —."""
    if x == 0.0:
        return _EMDASH
    sign = "+" if x > 0 else _MINUS
    return f"{sign}{abs(x):.1f}%"


def _fmt_ci_compact(low: int | float, high: int | float) -> str:
    """Format a CI as '$455k–$541k'."""
    return f"{_fmt_compact(low)}\u2013{_fmt_compact(high)}"


def _all_identical(scenarios: list[dict]) -> bool:
    """Return True if all scenarios have zero delta_vs_status_quo."""
    return all(abs(s.get("delta_vs_status_quo", 0)) < 1.0 for s in scenarios)


# ---------------------------------------------------------------------------
# Public renderer
# ---------------------------------------------------------------------------


def render_scenarios_memo(result: dict) -> str:
    """Render a Mock-C-aesthetic multi-scenario comparison memo.

    Args:
        result: The structured scenarios result dict as produced by the
            ``mixlift_scenarios`` tool.

    Returns:
        Markdown string. Empty string on critical field failure.
    """
    scenarios: list[dict] = result.get("scenarios", [])
    if not scenarios:
        return ""

    status_quo_revenue: float = float(result.get("status_quo_revenue", 0))

    data_window: str = result.get("data_window", "")
    mcmc_config = result.get("mcmc_config", {})

    lines: list[str] = []

    # ------------------------------------------------------------------
    # Section 1: Opening verdict
    # ------------------------------------------------------------------
    ranked = sorted(scenarios, key=lambda s: s.get("delta_vs_status_quo", 0), reverse=True)

    if _all_identical(scenarios):
        lines.append(
            "All scenarios produce ~equivalent revenue; no strong recommendation."
        )
        lines.append("")
    else:
        winner = ranked[0]
        winner_delta = winner.get("delta_vs_status_quo", 0)
        winner_pct = winner.get("delta_pct", 0.0)
        winner_revenue = winner.get("projected_revenue", status_quo_revenue)
        winner_ci = winner.get("projected_ci", [winner_revenue, winner_revenue])
        winner_ci_low = winner_ci[0] if winner_ci else winner_revenue
        winner_ci_high = winner_ci[1] if len(winner_ci) > 1 else winner_revenue

        winner_name = winner.get("name", "Best scenario")

        # Build opening lede
        delta_str = _fmt_delta_compact(winner_delta)
        if winner_delta > 0:
            h2 = f"## Best move: {winner_name} ({delta_str} projected)"
        else:
            h2 = f"## Best available: {winner_name} ({delta_str} vs status quo)"
        lines.append(h2)
        lines.append("")

        # Narrative sentence
        ci_str = _fmt_ci_compact(winner_ci_low, winner_ci_high)
        pct_str = _fmt_pct_delta(winner_pct)
        above_below = "above" if winner_pct >= 0 else "below"
        pct_abs = pct_str.lstrip(_MINUS).lstrip("+")
        narrative_parts = [
            f"Expected revenue lift: {fmt_dollars(int(winner_delta), signed=True)} "
            f"({pct_abs} {above_below} status quo). "
            f"Credible interval: {ci_str}."
        ]

        # Second-best callout (skip if second is identical to status quo)
        non_winner = [s for s in ranked[1:] if s.get("name", "") != winner.get("name", "")]
        if non_winner:
            second = non_winner[0]
            second_delta = second.get("delta_vs_status_quo", 0)
            if abs(second_delta) > 0:
                second_name = second.get("name", "")
                second_delta_str = _fmt_delta_compact(second_delta)
                narrative_parts.append(
                    f" Second-best: {second_name} ({second_delta_str} revenue delta)."
                )

        lines.append("".join(narrative_parts))
        lines.append("")

    # ------------------------------------------------------------------
    # Section 2: Ranked comparison table
    # ------------------------------------------------------------------
    lines.append("### Scenario comparison")
    lines.append("")

    col_rank = "Rank"
    col_scenario = "Scenario"
    col_projected = "Projected"
    col_ci = "CI"
    col_vs_sq = "vs SQ"
    col_pct = "%"

    header = (
        f"| {col_rank} | {col_scenario:<36} | {col_projected:>9}"
        f" | {col_ci:<19} | {col_vs_sq:>8} | {col_pct:>6} |"
    )
    sep = (
        "|------|" + "-" * 38 + "|----------:|---------------------|----------:|-------:|"
    )
    lines.append(header)
    lines.append(sep)

    for s in ranked:
        rank = s.get("rank", "")
        name = s.get("name", "")
        # Truncate long names to fit table
        if len(name) > 36:
            name = name[:33] + "..."
        proj_rev = s.get("projected_revenue", 0)
        s_ci = s.get("projected_ci", [proj_rev, proj_rev])
        s_ci_low = s_ci[0] if s_ci else proj_rev
        s_ci_high = s_ci[1] if len(s_ci) > 1 else proj_rev
        delta = s.get("delta_vs_status_quo", 0)
        delta_pct = s.get("delta_pct", 0.0)
        extrapolated = s.get("extrapolated", False)
        clipped = s.get("clipped", False)

        proj_str = _fmt_compact(proj_rev)
        ci_str = _fmt_ci_compact(s_ci_low, s_ci_high)
        delta_str = _fmt_delta_compact(delta)
        pct_str = _fmt_pct_delta(delta_pct)

        flag = ""
        if extrapolated:
            flag += " *"
        if clipped:
            flag += " \u2020"

        lines.append(
            f"| {rank!s:>4} | {name:<36}"
            f" | {proj_str:>9} | {ci_str:<19}"
            f" | {delta_str:>8} | {pct_str:>6} |{flag}"
        )

    lines.append("")

    # ------------------------------------------------------------------
    # Section 3: Per-scenario detail
    # ------------------------------------------------------------------
    lines.append("### Scenario details")
    lines.append("")

    for s in ranked:
        rank = s.get("rank", "")
        name = s.get("name", "")
        deltas_dict: dict = s.get("deltas", {})
        mode: str = s.get("mode", "percent")
        proj_rev = s.get("projected_revenue", 0)
        s_ci = s.get("projected_ci", [proj_rev, proj_rev])
        s_ci_low = s_ci[0] if s_ci else proj_rev
        s_ci_high = s_ci[1] if len(s_ci) > 1 else proj_rev
        delta = s.get("delta_vs_status_quo", 0)
        delta_pct = s.get("delta_pct", 0.0)
        extrapolated = s.get("extrapolated", False)
        clipped = s.get("clipped", False)

        lines.append(f"#### {rank}. {name}")

        # Delta description
        if deltas_dict:
            parts = []
            for ch, val in deltas_dict.items():
                if mode == "absolute":
                    parts.append(f"{ch} {fmt_dollars(int(val), signed=True)}")
                else:
                    pct_val = float(val) * 100.0
                    sign = "+" if pct_val >= 0 else ""
                    parts.append(f"{ch} {sign}{pct_val:.0f}%")
            lines.append(f"Delta applied: {', '.join(parts)}")
        else:
            lines.append("Delta applied: none (status quo)")

        lines.append(
            f"Projected: {fmt_dollars(int(proj_rev))} "
            f"(80% CI: {fmt_dollars(int(s_ci_low))}\u2013{fmt_dollars(int(s_ci_high))})"
        )

        if abs(delta) > 0:
            lines.append(
                f"vs Status Quo: {fmt_dollars(int(delta), signed=True)} "
                f"({_fmt_pct_delta(delta_pct)})"
            )
        else:
            lines.append("vs Status Quo: baseline")

        if extrapolated:
            lines.append(
                "*Extrapolation warning: one or more channels pushed outside observed spend range.*"
            )
        if clipped:
            lines.append(
                "*Channel spend clipped to $0 floor "
                "(absolute-mode delta would have gone negative).*"
            )

        lines.append("")

    # ------------------------------------------------------------------
    # Section 4: Footer
    # ------------------------------------------------------------------
    any_extrapolated = any(s.get("extrapolated", False) for s in scenarios)
    any_clipped = any(s.get("clipped", False) for s in scenarios)

    if any_extrapolated:
        lines.append(
            "\\* One or more scenarios push channels outside observed spend range; "
            "CIs may be optimistic."
        )
    if any_clipped:
        lines.append(
            "\u2020 One or more scenarios had channel spend clipped to $0 floor."
        )

    # MCMC + data window footer
    chains, draws = _parse_mcmc_config(mcmc_config)
    footer_parts: list[str] = []
    if data_window:
        footer_parts.append(f"Data window: {data_window}.")
    if chains is not None and draws is not None:
        footer_parts.append(f"Posterior: {chains} chains \u00d7 {draws} draws.")

    if footer_parts:
        lines.append("")
        lines.append(f"*{' '.join(footer_parts)}*")

    # Trim trailing blank lines then rejoin
    while lines and not lines[-1].strip():
        lines.pop()

    return "\n".join(lines)
