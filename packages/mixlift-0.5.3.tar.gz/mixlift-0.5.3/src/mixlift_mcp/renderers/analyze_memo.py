"""Mock-C analyst-memo renderer for MixLift MMM results.

Pure stdlib only — no numpy, pandas, or jinja.
"""

from __future__ import annotations

import logging
import re

from mixlift_mcp.renderers._helpers import (
    channel_display_name,
    fmt_dollars,
    fmt_roas,
    safe_dict,
    unicode_bar,
)

logger = logging.getLogger(__name__)


def render_analyze_memo(result: dict) -> str:
    """Render the Mock-C analyst memo from a MixLift result dict.

    Returns markdown string, or "" if critical fields are missing (never raises).
    Safe for both free-tier and paid-tier results.
    """
    try:
        return _render(result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_analyze_memo failed: %s", exc, exc_info=True)
        return ""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _is_free_tier(result: dict) -> bool:
    """Detect free tier from budget_optimization fields."""
    budget_opt = result.get("budget_optimization", {})
    current = budget_opt.get("current_allocation")
    if isinstance(current, str):
        return True
    optimal = budget_opt.get("optimal_allocation")
    if isinstance(optimal, str):
        return True
    total = budget_opt.get("total_budget")
    if isinstance(total, str):
        return True
    return False


def _parse_mcmc_config(mcmc_config: object) -> tuple[str | None, str | None]:
    """Return (chains_str, draws_str) from the mcmc_config value.

    Accepts either a dict like {"chains": 4, "draws": 250, ...} or a string
    like "4 chains, 250 draws, target_accept=0.90".
    Returns (None, None) when neither format is recognised.
    """
    if isinstance(mcmc_config, dict):
        chains = mcmc_config.get("chains")
        draws = mcmc_config.get("draws")
        if chains is not None and draws is not None:
            return str(chains), str(draws)
        return None, None

    if isinstance(mcmc_config, str):
        # Try "4 chains, 250 draws" pattern
        m_chains = re.search(r"(\d+)\s+chains?", mcmc_config, re.IGNORECASE)
        m_draws = re.search(r"(\d+)\s+draws?", mcmc_config, re.IGNORECASE)
        chains = m_chains.group(1) if m_chains else None
        draws = m_draws.group(1) if m_draws else None
        return chains, draws

    return None, None


# ---------------------------------------------------------------------------
# Section renderers
# ---------------------------------------------------------------------------


def _section_lede(result: dict) -> str:
    """Return the bold metadata lede line."""
    parts: list[str] = []

    weeks = result.get("model_info", {}).get("data_window", {}).get("weeks")
    if weeks is not None:
        parts.append(f"{int(round(weeks))} weeks")

    n_channels = result.get("data", {}).get("n_channels")
    if n_channels is not None:
        parts.append(f"{n_channels} channels")

    model_fit = result.get("model_fit", {})
    r2 = model_fit.get("r_squared") if isinstance(model_fit, dict) else None
    if r2 is not None:
        parts.append(f"R\u00b2 {float(r2):.2f}")

    mape = model_fit.get("mape") if isinstance(model_fit, dict) else None
    if mape is not None:
        parts.append(f"MAPE {float(mape):.1f}%")

    # Backtest MAPE pill — only when status is "success"
    backtest = result.get("backtest", {})
    if isinstance(backtest, dict) and backtest.get("status") == "success":
        agg = backtest.get("aggregate", {})
        bt_mape = agg.get("mape_mean")
        if bt_mape is not None:
            parts.append(f"Backtest MAPE {float(bt_mape):.1f}%")

    _sep = " \u00b7 "
    return f"**{_sep.join(parts)}**"


def _section_h2_thesis(result: dict, is_free: bool, roas_estimates: dict) -> str:
    """Return the H2 thesis sentence."""
    budget_opt = result.get("budget_optimization", {})
    lift_pct = budget_opt.get("expected_lift_pct")

    if not is_free:
        # Paid tier
        if lift_pct is not None and float(lift_pct) > 0.5:
            return f"## Your mix is leaving ~{float(lift_pct):.0f}% of revenue on the table."
        return "## Your allocation is close to optimal."

    # Free tier — insight-led, not upsell-led
    numeric_roas = {
        ch: v for ch, v in roas_estimates.items() if isinstance(v, (int, float))
    }
    if len(numeric_roas) >= 2:
        max_roas = max(numeric_roas.values())
        min_roas = min(numeric_roas.values())
        if min_roas > 0:
            ratio = round(max_roas / min_roas)
            return f"## Your mix is unbalanced; top and bottom channels differ by {ratio}\u00d7."

    return "## Your mix efficiency varies across channels."


def _section_narrative(
    result: dict,
    is_free: bool,
    roas_estimates: dict,
    sorted_channels: list[tuple[str, float]],
) -> str:
    """Return the programmatic narrative paragraph."""
    if len(sorted_channels) < 2:
        return ""

    budget_opt = result.get("budget_optimization", {})
    current_alloc = safe_dict(budget_opt.get("current_allocation"))
    lift_pct = budget_opt.get("expected_lift_pct")
    total_budget = budget_opt.get("total_budget")
    n_channels = result.get("data", {}).get("n_channels") or len(sorted_channels)

    top_ch, top_roas = sorted_channels[0]
    top_display = channel_display_name(top_ch)

    # bottom is last; second-bottom is second-to-last for two-channel comparison
    bottom_ch, _ = sorted_channels[-1]
    second_bottom_ch = sorted_channels[-2][0] if len(sorted_channels) >= 3 else bottom_ch

    bottom_display = channel_display_name(bottom_ch)
    second_bottom_display = channel_display_name(second_bottom_ch)

    top_spend_val = current_alloc.get(top_ch)
    bottom_spend_val = current_alloc.get(bottom_ch)
    second_spend_val = current_alloc.get(second_bottom_ch)

    if is_free:
        top_spend_str = "$XXX"
    else:
        top_spend_str = (
            fmt_dollars(top_spend_val) + "/wk" if top_spend_val is not None else "$\u2014/wk"
        )

    top_roas_str = fmt_roas(top_roas)

    # ratio: bottom spend / top spend (how many times larger is the bottom budget)
    ratio_str = ""
    if not is_free and top_spend_val and (bottom_spend_val or second_spend_val):
        combined = (bottom_spend_val or 0) + (
            second_spend_val if second_bottom_ch != bottom_ch else 0
        )
        if top_spend_val > 0 and combined > 0:
            ratio = round(combined / top_spend_val)
            ratio_str = f"{ratio}\u00d7"
        else:
            ratio_str = ""
    elif is_free:
        ratio_str = "many\u00d7"

    # flat reallocation amount
    if not is_free and total_budget and n_channels:
        try:
            flat_per_channel = fmt_dollars(int(float(total_budget) / n_channels)) + "/channel"
        except (ValueError, TypeError, ZeroDivisionError):
            flat_per_channel = "$—/channel"
    else:
        flat_per_channel = "$XXX/channel" if is_free else "$—/channel"

    lift_str = ""
    if lift_pct is not None:
        lift_str = f"**{float(lift_pct):+.1f}% revenue at equal total spend**"
    else:
        lift_str = "**improved revenue at equal total spend**"

    # Construct the two sentences
    if second_bottom_ch != bottom_ch:
        bottom_mention = f"{second_bottom_display} and {bottom_display}"
    else:
        bottom_mention = bottom_display

    if is_free:
        bottom_phrase = f"{bottom_mention} sit near 1\u00d7 ROAS at {ratio_str} the spend"
    else:
        bottom_phrase = f"{bottom_mention} earn roughly $1 per dollar at {ratio_str} the spend"

    para = (
        f"{top_display} earns **{top_roas_str} per dollar** at "
        f"{top_spend_str} \u2014 the highest ROAS in your mix, at the smallest budget. "
        f"{bottom_phrase}.\n\n"
        f"A flat reallocation to {flat_per_channel} projects {lift_str}."
    )
    return para


def _section_hero_table(
    result: dict,
    is_free: bool,
    sorted_channels: list[tuple[str, float]],
) -> str:
    """Return the '### Where your dollars are working' hero table."""
    if not sorted_channels:
        return ""

    budget_opt = result.get("budget_optimization", {})
    current_alloc = safe_dict(budget_opt.get("current_allocation"))
    optimal_alloc = safe_dict(budget_opt.get("optimal_allocation"))

    # Compute deltas for all channels
    deltas: dict[str, float | None] = {}
    for ch, _ in sorted_channels:
        cur = current_alloc.get(ch)
        opt = optimal_alloc.get(ch)
        if cur is not None and opt is not None:
            try:
                deltas[ch] = float(opt) - float(cur)
            except (TypeError, ValueError):
                deltas[ch] = None
        else:
            deltas[ch] = None

    numeric_deltas = [abs(v) for v in deltas.values() if v is not None]
    max_abs_delta = max(numeric_deltas) if numeric_deltas else 0.0

    top_ch = sorted_channels[0][0] if sorted_channels else None
    bottom_ch = sorted_channels[-1][0] if sorted_channels else None

    lines: list[str] = [
        "### Where your dollars are working",
        "",
        "| Channel | ROAS | Spend/wk | Change to optimal | |",
        "|:--------|-----:|---------:|------------------:|:--|",
    ]

    for ch, roas in sorted_channels:
        display = channel_display_name(ch)
        is_top = ch == top_ch
        is_bot = ch == bottom_ch
        bold = is_top or is_bot

        ch_cell = f"**{display}**" if bold else display

        roas_cell = fmt_roas(roas)

        # Spend cell
        spend_val = current_alloc.get(ch)
        if is_free:
            spend_cell = "$XXX"
        elif spend_val is not None:
            spend_cell = fmt_dollars(spend_val)
        else:
            spend_cell = "\u2014"

        # Delta cell
        delta = deltas.get(ch)
        if is_free:
            delta_cell = "$XXX"
            bar_cell = ""
        elif delta is not None:
            delta_str = fmt_dollars(delta, signed=True)
            delta_cell = f"**{delta_str}**" if bold else delta_str
            bar_cell = unicode_bar(abs(delta), max_abs_delta).rstrip()
        else:
            delta_cell = "\u2014"
            bar_cell = ""

        lines.append(
            f"| {ch_cell} | {roas_cell} | {spend_cell} | {delta_cell} | {bar_cell} |"
        )

    return "\n".join(lines)


def _section_platform_comparison(result: dict, is_free: bool) -> str:  # noqa: C901
    """Return the '### Platform attribution' section, or '' when data is absent."""
    pac = result.get("platform_attribution_comparison")
    if not pac or not isinstance(pac, dict):
        return ""
    channels: dict = pac.get("channels") or {}
    if not channels:
        return ""

    summary: dict = pac.get("summary") or {}
    over_claiming: list = summary.get("channels_over_claiming") or []
    under_claiming: list = summary.get("channels_under_claiming") or []
    most_egregious_info: dict | None = summary.get("most_egregious")

    # --- H3 title ---
    if over_claiming:
        top_claimer_ch = most_egregious_info["channel"] if most_egregious_info else over_claiming[0]
        top_claimer_display = channel_display_name(top_claimer_ch)
        h3 = f"### Platform attribution: where {top_claimer_display} is lying to you"
    elif under_claiming:
        h3 = "### Platform attribution: your pixels may be missing view-through"
    else:
        h3 = "### Platform attribution: your platforms are telling the truth"

    # --- Table ---
    # Sort: over-claiming (|gap| desc), then aligned, then under-claiming, unmeasured last
    def _sort_key(ch: str) -> tuple[int, float]:
        data = channels[ch]
        verdict = data.get("verdict", "")
        gap = abs(data.get("gap_pct") or 0.0)
        if verdict == "over_claiming":
            return (0, -gap)
        if verdict == "aligned":
            return (1, -gap)
        if verdict == "under_claiming":
            return (2, -gap)
        return (3, 0.0)

    sorted_chs = sorted(channels.keys(), key=_sort_key)

    all_gaps = [abs(channels[ch].get("gap_pct") or 0.0) for ch in sorted_chs]
    max_abs_gap = max(all_gaps) if all_gaps else 0.0

    most_egregious_ch = most_egregious_info["channel"] if most_egregious_info else None

    en_dash = "\u2013"   # –
    em_dash = "\u2014"   # —
    minus_sign = "\u2212"  # −
    mul_sign = "\u00d7"  # ×

    table_lines = [
        "| Channel | Platform reports | MixLift measures (95% CI) | Gap | |",
        "|:--------|:-----------------|:--------------------------|:----|:--|",
    ]
    for ch in sorted_chs:
        data = channels[ch]
        display = channel_display_name(ch)
        bold = ch == most_egregious_ch
        ch_cell = f"**{display}**" if bold else display

        p_roas = data.get("platform_roas")
        plat_cell = fmt_roas(p_roas) if p_roas is not None else em_dash

        mmm_r = data.get("mmm_roas")
        ci_lo = data.get("mmm_roas_ci_low")
        ci_hi = data.get("mmm_roas_ci_high")
        mmm_cell = (
            f"{fmt_roas(mmm_r)} ({fmt_roas(ci_lo)}{en_dash}{fmt_roas(ci_hi)})"
            if mmm_r is not None
            else em_dash
        )

        verdict = data.get("verdict", "")
        gap_pct = data.get("gap_pct") or 0.0
        abs_gap_pct_100 = abs(gap_pct) * 100
        if verdict == "over_claiming":
            gap_cell = f"**{minus_sign}{abs_gap_pct_100:.0f}%**"
        elif verdict == "aligned":
            gap_cell = f"\u00b1{abs_gap_pct_100:.0f}% (aligned)"
        elif verdict == "under_claiming":
            gap_cell = f"+{abs_gap_pct_100:.0f}%"
        else:
            gap_cell = em_dash

        if max_abs_gap > 0:
            bar_cell = unicode_bar(abs(gap_pct), max_abs_gap).rstrip()
        else:
            bar_cell = ""

        table_lines.append(
            f"| {ch_cell} | {plat_cell} | {mmm_cell} | {gap_cell} | {bar_cell} |"
        )

    # --- Narrative blockquote ---
    bq_lines: list[str] = []
    if over_claiming and most_egregious_info:
        eg_ch = most_egregious_info["channel"]
        eg_data = channels[eg_ch]
        eg_display = channel_display_name(eg_ch)
        abs_gap_pct_val = abs(eg_data.get("gap_pct") or 0.0) * 100
        plat_r = eg_data.get("platform_roas") or 0.0
        mmm_r_val = eg_data.get("mmm_roas") or 0.0
        ci_lo_val = eg_data.get("mmm_roas_ci_low") or 0.0
        ci_hi_val = eg_data.get("mmm_roas_ci_high") or 0.0
        incremental_pct = round(mmm_r_val / plat_r * 100) if plat_r else 0

        lead = (
            f"> **{eg_display} is over-claiming by {abs_gap_pct_val:.0f}%.** "
            f"{eg_display} reports **{fmt_roas(plat_r)}** ROAS; "
            f"MixLift measures **{fmt_roas(mmm_r_val)}** "
            f"(CI {fmt_roas(ci_lo_val)}{en_dash}{fmt_roas(ci_hi_val)}). "
            f"Roughly {incremental_pct}% of {eg_display}'s reported conversions are incremental "
            f"\u2014 the rest would have happened without the ad. "
            f"Reallocating against platform numbers is optimizing a lie."
        )
        bq_lines.append(lead)

        # Secondary over-claimers
        other_oc = [ch for ch in over_claiming if ch != eg_ch]
        if len(other_oc) >= 1:
            parts = []
            for och in other_oc:
                och_display = channel_display_name(och)
                och_gap = abs(channels[och].get("gap_pct") or 0.0) * 100
                parts.append((och_display, och_gap))
            if len(parts) == 1:
                other_line = (
                    f"> {parts[0][0]} shows the same pattern at smaller scale "
                    f"({parts[0][1]:.0f}% gap)."
                )
            else:
                gap_strs = " and ".join(f"{p[1]:.0f}%" for p in parts)
                names = " and ".join(p[0] for p in parts)
                other_line = (
                    f"> {names} show the same pattern at smaller scale ({gap_strs} gaps)."
                )
            bq_lines.append(">")
            bq_lines.append(other_line)

    elif under_claiming and not over_claiming:
        uc_ch = under_claiming[0]
        uc_data = channels[uc_ch]
        uc_display = channel_display_name(uc_ch)
        plat_r = uc_data.get("platform_roas") or 0.0
        mmm_r_val = uc_data.get("mmm_roas") or 0.0
        ci_lo_val = uc_data.get("mmm_roas_ci_low") or 0.0
        ci_hi_val = uc_data.get("mmm_roas_ci_high") or 0.0

        bq_lines.append(
            f"> **{uc_display} may be under-claiming.** "
            f"{uc_display} reports **{fmt_roas(plat_r)}**; "
            f"MixLift measures **{fmt_roas(mmm_r_val)}** "
            f"(CI {fmt_roas(ci_lo_val)}{en_dash}{fmt_roas(ci_hi_val)}). "
            f"Under-claiming is expected for brand channels where view-through and halo "
            f"effects aren\u2019t captured by the pixel. "
            f"Real return on {uc_display} is likely {mmm_r_val:.1f}{mul_sign} or higher "
            f"\u2014 you may be under-investing."
        )
    else:
        # Aligned-only
        bq_lines.append(
            "> **Your platform attribution is trustworthy.** "
            "All measured platforms report ROAS within MixLift\u2019s 95% confidence interval "
            "\u2014 the pixels are telling you something real. Plan budget at these numbers."
        )

    # --- Footnote ---
    footnote_lines: list[str] = []
    if len(sorted_chs) > 1:
        footnote_lines.append(
            "*Platforms also double-count each other \u2014 the total platform-reported revenue "
            "across your channels typically exceeds your actual revenue by 20\u201340%.*"
        )

    # --- Assemble ---
    parts: list[str] = [h3, "", "\n".join(table_lines)]
    if bq_lines:
        parts.append("\n".join(bq_lines))
    if footnote_lines:
        parts.append("\n".join(footnote_lines))

    return "\n\n".join(parts)


def _section_three_moves(result: dict, is_free: bool) -> str:
    """Return the '### Three moves for this week' blockquote section."""
    actions = result.get("recommendations", {}).get("actions", [])
    if not actions:
        return ""

    top3 = actions[:3]
    if not top3:
        return ""

    lines: list[str] = ["### Three moves for this week", ""]
    block_lines: list[str] = []

    for i, action in enumerate(top3, start=1):
        raw_action = action.get("action", "")
        verb = "Increase" if raw_action == "INCREASE" else "Decrease"

        ch = action.get("channel", "")
        ch_display = channel_display_name(ch)

        change_amount = action.get("change_amount")
        if is_free or not isinstance(change_amount, (int, float)):
            amount_str = "$XXX"
        else:
            amount_str = fmt_dollars(abs(change_amount), signed=False)

        reason = action.get("reason", "")

        block_lines.append(
            f"> **{i}. {verb} {ch_display} by {amount_str}/wk.** {reason}"
        )
        if i < len(top3):
            block_lines.append(">")

    lines.extend(block_lines)
    return "\n".join(lines)


def _backtest_narrative(backtest: dict, is_free: bool) -> str:
    """Build the interpretation narrative sentence for a successful backtest.

    Shared between the memo and the HTML report.  Returns a plain string
    (no markdown fences) so the caller can embed it anywhere.
    """
    agg = backtest.get("aggregate", {})
    interp = agg.get("interpretation", "poor")
    mape_mean = float(agg.get("mape_mean") or 0.0)
    coverage_mean = float(agg.get("coverage_80_mean") or 0.0)
    n_folds = int(backtest.get("n_folds") or 1)
    horizon_weeks = int(backtest.get("horizon_weeks") or 1)
    mode = backtest.get("mode", "walk_forward")

    # Single-holdout mode: pull MAPE from the single fold if available
    folds = backtest.get("folds") or []

    if mode == "single_holdout" and folds:
        fold_mape = float(folds[0].get("mape") or mape_mean)
        if interp == "great":
            quality_phrase = (
                "well-calibrated \u2014 treat the ROAS figures above as trustworthy."
            )
        elif interp == "acceptable":
            quality_phrase = (
                "acceptable for directional budget decisions \u2014 use the ROAS above to "
                "choose which channels to scale, but treat exact dollar lifts as ranges, "
                "not point estimates."
            )
        else:
            quality_phrase = (
                "higher than we\u2019d like \u2014 use directional findings "
                "(which channels are stronger vs weaker) but discount specific dollar "
                "recommendations."
            )
        return (
            f"We held back the most recent {horizon_weeks} weeks and predicted them from "
            f"everything before. Actual vs predicted: {fold_mape:.1f}% MAPE. {quality_phrase}"
        )

    # Walk-forward mode
    total_weeks = n_folds * horizon_weeks
    if interp == "great":
        base = (
            f"Your model would have predicted the last {total_weeks} weeks within "
            f"{mape_mean:.1f}% on average"
        )
        if not is_free:
            base += (
                f", and its 80% confidence intervals contained the actuals "
                f"{coverage_mean:.0%} of the time \u2014 well-calibrated."
            )
        else:
            base += " \u2014 well-calibrated."
        base += " Treat the ROAS figures above as trustworthy."
        return base
    elif interp == "acceptable":
        return (
            f"In holdout tests, this model hit within {mape_mean:.1f}% of actual weekly "
            f"revenue across {n_folds} rolling forecasts. That\u2019s acceptable for "
            f"directional budget decisions \u2014 use the ROAS above to choose which "
            f"channels to scale, but treat exact dollar lifts as ranges, not point estimates."
        )
    else:
        return (
            f"Holdout backtest MAPE was {mape_mean:.1f}% \u2014 higher than we\u2019d like. "
            f"The model captures broad patterns but missed {n_folds}-week windows by an "
            f"average of {mape_mean:.0f}%. Use directional findings (which channels are "
            f"stronger vs weaker) but discount specific dollar recommendations. More data or "
            f"an experiment-calibrated prior would tighten this substantially."
        )


def _section_backtest(result: dict, is_free: bool) -> str:
    """Return the '### How we know these numbers hold up' backtest section."""
    backtest = result.get("backtest")
    if not backtest or not isinstance(backtest, dict):
        return ""
    if backtest.get("status") != "success":
        return ""
    folds = backtest.get("folds") or []
    if not folds:
        return ""

    narrative = _backtest_narrative(backtest, is_free)
    lines: list[str] = [
        "### How we know these numbers hold up",
        "",
        narrative,
    ]

    # Paid tier: add per-fold table
    if not is_free:
        lines.append("")
        lines.append("| Fold | Period | Actual (avg/wk) | Predicted (avg/wk) | MAPE |")
        lines.append("|-----:|:-------|----------------:|-------------------:|-----:|")
        for fold in folds:
            fold_num = fold.get("fold", "")
            test_start = fold.get("test_start", "")
            test_end = fold.get("test_end", "")
            weekly_actual = fold.get("weekly_actual") or []
            weekly_pred_mean = fold.get("weekly_predicted_mean") or []
            fold_mape = fold.get("mape", 0.0)

            actual_avg = (
                sum(weekly_actual) / len(weekly_actual) if weekly_actual else 0.0
            )
            pred_avg = (
                sum(weekly_pred_mean) / len(weekly_pred_mean) if weekly_pred_mean else 0.0
            )

            en_dash = "\u2013"
            lines.append(
                f"| {fold_num} | {test_start}{en_dash}{test_end} "
                f"| ${actual_avg:,.0f} | ${pred_avg:,.0f} | {fold_mape:.1f}% |"
            )

    return "\n".join(lines)


def _section_footer(result: dict) -> str:
    """Return the italic footer line."""
    weeks = result.get("model_info", {}).get("data_window", {}).get("weeks")
    weeks_str = f"{int(round(weeks))} weeks" if weeks is not None else "N weeks"

    mcmc_config = result.get("model_info", {}).get("mcmc_config")
    chains_str, draws_str = _parse_mcmc_config(mcmc_config)

    if chains_str and draws_str:
        posterior_str = f"Posterior: {chains_str} chains \u00d7 {draws_str} draws"
    else:
        posterior_str = "Posterior converged."

    warnings = result.get("diagnostics", {}).get("convergence_warnings", [])
    if isinstance(warnings, list) and len(warnings) > 0:
        convergence_note = f"{len(warnings)} convergence warnings"
    else:
        convergence_note = "no divergences"

    footer = f"*Modeled on {weeks_str} of weekly data. {posterior_str}, {convergence_note}.*"

    cache_age = result.get("_cache_age_days")
    if cache_age is not None:
        footer = footer.rstrip("*").rstrip(".")
        footer += f". \u00b7 Cached from fit {cache_age} days ago.*"

    return footer


# ---------------------------------------------------------------------------
# Main render
# ---------------------------------------------------------------------------


def _render(result: dict) -> str:
    """Internal render — may raise; caller wraps in try/except."""
    if not result:
        return ""

    # Critical: ROAS estimates must be present to build the table
    roas_estimates = result.get("roas", {}).get("estimates", {})
    if not roas_estimates or not isinstance(roas_estimates, dict):
        return ""

    is_free = _is_free_tier(result)

    # Sort channels by ROAS descending (numeric values only)
    numeric_roas = {
        ch: float(v) for ch, v in roas_estimates.items() if isinstance(v, (int, float))
    }
    if not numeric_roas:
        return ""

    sorted_channels: list[tuple[str, float]] = sorted(
        numeric_roas.items(), key=lambda x: x[1], reverse=True
    )

    sections: list[str] = []

    # 1. Metadata lede
    sections.append(_section_lede(result))

    # 2. H2 thesis
    sections.append(_section_h2_thesis(result, is_free, numeric_roas))

    # 3. Narrative paragraph
    narrative = _section_narrative(result, is_free, numeric_roas, sorted_channels)
    if narrative:
        sections.append(narrative)

    # 4. Hero table
    hero_table = _section_hero_table(result, is_free, sorted_channels)
    if hero_table:
        sections.append(hero_table)

    # 5. Platform attribution comparison
    platform_cmp = _section_platform_comparison(result, is_free)
    if platform_cmp:
        sections.append(platform_cmp)

    # 6. Three moves
    moves = _section_three_moves(result, is_free)
    if moves:
        sections.append(moves)

    # 7. Backtest validation
    backtest_section = _section_backtest(result, is_free)
    if backtest_section:
        sections.append(backtest_section)

    # 8. Footer
    sections.append(_section_footer(result))

    return "\n\n".join(sections)
