"""Shared rendering primitives for Mock-C analyst-memo output format.

Pure stdlib only — no numpy, pandas, or jinja.
"""

from __future__ import annotations

import math

# Unicode glyphs used in bars and formatting
_FULL = "\u2588"  # █
_HALF = "\u258c"  # ▌
_THIN = "\u258f"  # ▏

# Sign/currency characters
_MINUS = "\u2212"  # − (U+2212, real minus sign)
_TIMES = "\u00d7"  # × (U+00D7, multiplication sign)
_EMDASH = "\u2014"  # — (U+2014, em dash)


def unicode_bar(magnitude: float, max_magnitude: float, width: int = 8) -> str:
    """Render a unicode block bar for a given magnitude.

    Args:
        magnitude: The value to represent. Sign is ignored; use abs().
        max_magnitude: The reference maximum for scaling.
        width: Total character width of the output (right-padded with spaces).

    Returns:
        A string of exactly ``width`` characters.
    """
    # Safe fallback: invalid max_magnitude
    if max_magnitude <= 0 or not math.isfinite(max_magnitude):
        return " " * width

    # Blank only when magnitude is exactly zero
    if magnitude == 0:
        return " " * width

    cells = abs(magnitude) / max_magnitude * width

    # Enforce minimum visible glyph for any nonzero magnitude
    if cells < (1 / 8):
        bar = _THIN
        return bar.ljust(width)

    whole = int(cells)
    # Cap whole blocks to width
    whole = min(whole, width)

    remainder = cells - whole

    bar = _FULL * whole
    if whole < width and remainder >= 0.375:
        bar += _HALF

    return bar.ljust(width)


def fmt_dollars(x: int | float | str, signed: bool = False) -> str:
    """Format a dollar value as a compact integer string.

    Args:
        x: Dollar amount. Strings are passed through unchanged (for
           upgrade-gated placeholder values).
        signed: If True, prefix with ``+`` for positives and ``−``
                (U+2212) for negatives.

    Returns:
        Formatted string, e.g. ``"$1,234"`` or ``"+$1,234"`` or
        ``"−$1,234"``.
    """
    if isinstance(x, str):
        return x

    value = int(x)
    abs_str = f"${abs(value):,}"

    if signed:
        if value < 0:
            return f"{_MINUS}{abs_str}"
        return f"+{abs_str}"

    return abs_str


def fmt_roas(x: float | None) -> str:
    """Format a ROAS value with the multiplication sign.

    Args:
        x: ROAS value, or None / non-numeric for missing data.

    Returns:
        ``"24.60\u00d7"`` on success, ``"\u2014"`` (em dash) on failure.
    """
    try:
        if x is None or not math.isfinite(float(x)):
            return _EMDASH
        return f"{float(x):.2f}{_TIMES}"
    except (TypeError, ValueError):
        return _EMDASH


def fmt_pct(x: float, precision: int = 1, signed: bool = True) -> str:
    """Format a percentage value.

    Args:
        x: Value as a decimal fraction (e.g. 0.121 for 12.1%) OR as a
           plain percentage (12.1 for 12.1%). The caller passes the
           display-ready percentage number directly (i.e. ``12.1``,
           not ``0.121``).
        precision: Decimal places in the output.
        signed: If True, prefix with ``+`` or ``\u2212``.

    Returns:
        e.g. ``"+12.1%"`` / ``"\u22123.5%"`` / ``"12.1%"``.
    """
    formatted = f"{abs(x):.{precision}f}%"

    if signed:
        if x < 0:
            return f"{_MINUS}{formatted}"
        return f"+{formatted}"

    return formatted


def channel_display_name(raw: str) -> str:
    """Return the canonical display name for a channel column.

    Delegates to ``mixlift.modeling.optimizer.format_channel_name``
    via a lazy import to avoid circular-import risk at module load time.

    Args:
        raw: Raw column name, e.g. ``"tiktok_spend"``.

    Returns:
        Human-readable display name, e.g. ``"TikTok"``.
    """
    from mixlift.modeling.optimizer import format_channel_name  # lazy

    return format_channel_name(raw)


def safe_dict(value: object) -> dict:
    """Return ``value`` if it is a dict, otherwise return ``{}``.

    Guards against free-tier paths where fields like
    ``budget_optimization.current_allocation`` contain a string
    (upgrade prompt) instead of a dict.

    Args:
        value: Any value.

    Returns:
        The original dict, or an empty dict.
    """
    if isinstance(value, dict):
        return value
    return {}
