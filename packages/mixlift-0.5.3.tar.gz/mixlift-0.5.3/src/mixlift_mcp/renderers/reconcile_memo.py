"""Platform-vs-MMM reconciliation analyst-memo renderer for MixLift.

Pure stdlib only — no numpy, pandas, or jinja.
Receives pre-computed reconcile result dicts; never fits a model.
"""

from __future__ import annotations

import logging
from typing import Any

from mixlift_mcp.renderers._helpers import (
    fmt_dollars,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Column alias normalisation
# ---------------------------------------------------------------------------

#: Accepted suffixes for platform-reported revenue columns.
#: Each entry maps an alias suffix → canonical ``_platform_reported_revenue``.
_PLATFORM_REVENUE_ALIASES: tuple[str, ...] = (
    "_platform_reported_revenue",  # canonical
    "_reported_revenue",
    "_platform_revenue",
)


def normalise_platform_revenue_columns(columns: list[str]) -> dict[str, str]:
    """Detect and normalise platform-reported revenue column names.

    Scans ``columns`` for any alias suffix (case-insensitive) and returns a
    mapping of ``{channel_name: canonical_column_name}`` where the canonical
    form is ``<channel>_platform_reported_revenue``.

    Example::

        normalise_platform_revenue_columns([
            "meta_spend",
            "meta_reported_revenue",          # alias → "meta_platform_reported_revenue"
            "google_search_platform_revenue", # alias → "google_search_platform_reported_revenue"
            "revenue",
        ])
        # → {"meta": "meta_platform_reported_revenue",
        #    "google_search": "google_search_platform_reported_revenue"}

    Args:
        columns: List of column names as they appear in the DataFrame.

    Returns:
        Dict mapping channel name → canonical column name.
    """
    result: dict[str, str] = {}
    for col in columns:
        col_lower = col.lower()
        for alias in _PLATFORM_REVENUE_ALIASES:
            if col_lower.endswith(alias):
                channel = col[: len(col) - len(alias)]
                canonical = f"{channel}_platform_reported_revenue"
                result[channel] = canonical
                break
    return result


# ---------------------------------------------------------------------------
# Verdict helpers
# ---------------------------------------------------------------------------

_VERDICT_OVER = "over_claiming"
_VERDICT_UNDER = "under_claiming"
_VERDICT_ALIGNED = "aligned"
_VERDICT_UNMEASURED = "unmeasured"

_GAP_THRESHOLD_PCT = 20.0


def _verdict(gap_pct: float | None) -> str:
    if gap_pct is None:
        return _VERDICT_UNMEASURED
    if gap_pct >= _GAP_THRESHOLD_PCT:
        return _VERDICT_OVER
    if gap_pct <= -_GAP_THRESHOLD_PCT:
        return _VERDICT_UNDER
    return _VERDICT_ALIGNED


def _verdict_display(verdict: str) -> str:
    return {
        _VERDICT_OVER: "Over-claiming",
        _VERDICT_UNDER: "Under-claiming",
        _VERDICT_ALIGNED: "Aligned",
        _VERDICT_UNMEASURED: "Unmeasured",
    }.get(verdict, verdict.capitalize())


# ---------------------------------------------------------------------------
# Memo section renderers
# ---------------------------------------------------------------------------


def _section_headline(result: dict) -> str:
    """Opening headline paragraph: total gap and biggest over-claimer."""
    total_platform = result.get("total_platform_reported")
    total_mmm = result.get("total_mmm_attributed", 0)
    total_gap = result.get("total_gap_dollars")
    period_label = result.get("period_label", "this period")

    # Strip date range for compact phrase
    period_phrase = period_label.split(" (")[0].lower() if period_label else "this period"

    if total_platform is None or total_gap is None:
        # No channels with platform data
        return (
            "## No platform-reported revenue data available\n\n"
            "Add `platform_reported_revenue` columns to your CSV to enable reconciliation."
        )

    headline = (
        f"## Your platforms report {fmt_dollars(total_gap)} more than MMM attributes\n\n"
        f"Platform dashboards claim {fmt_dollars(total_platform)} of {period_phrase} "
        f"revenue; MMM attributes {fmt_dollars(total_mmm)}."
    )

    # Identify biggest over-claimer
    channels = result.get("channels", [])
    over_claimers = [
        ch
        for ch in channels
        if ch.get("verdict") == _VERDICT_OVER and ch.get("gap_dollars") is not None
    ]
    if over_claimers:
        top = max(over_claimers, key=lambda c: c["gap_dollars"])
        name = top["name"]
        platform_rev = top.get("platform_reported_revenue", 0)
        mmm_rev = top.get("mmm_attributed_revenue", 0)
        gap = top.get("gap_dollars", 0)
        headline += (
            f" **{name} is the biggest over-claimer** — its dashboard reports "
            f"{fmt_dollars(platform_rev)} from a channel MMM credits at {fmt_dollars(mmm_rev)}. "
            f"The {fmt_dollars(gap)} gap is probably view-through double-count and "
            f"retargeting overlap on converters who would have purchased anyway."
        )

    # Special case: all channels aligned
    all_gap_pcts = [abs(ch.get("gap_pct", 0)) for ch in channels if ch.get("gap_pct") is not None]
    if all_gap_pcts and max(all_gap_pcts) < 5.0:
        headline = (
            "## Your reconciliation looks clean\n\n"
            "Platforms and MMM agree within 5%. Platform dashboards claim "
            f"{fmt_dollars(total_platform)} of {period_phrase} revenue; "
            f"MMM attributes {fmt_dollars(total_mmm)}. "
            "The gap is within normal measurement noise."
        )

    return headline


def _section_table(result: dict) -> str:
    """Reconciliation table: platform vs MMM vs gap."""
    channels = result.get("channels", [])
    if not channels:
        return ""

    def _fmt_opt(v: float | None, fn=fmt_dollars) -> str:
        return fn(v) if v is not None else "\u2014"

    def _fmt_gap_pct(v: float | None) -> str:
        if v is None:
            return "\u2014"
        sign = "+" if v >= 0 else ""
        return f"{sign}{v:.0f}%"

    lines: list[str] = [
        "| Channel       | Platform RPT  | MMM attrib.  | Gap ($)    | Gap (%)  | Verdict        |",
        "|---------------|---------------|--------------|------------|----------|----------------|",
    ]

    for ch in channels:
        name = ch["name"]
        platform = _fmt_opt(ch.get("platform_reported_revenue"))
        mmm = fmt_dollars(ch.get("mmm_attributed_revenue", 0))
        gap = _fmt_opt(ch.get("gap_dollars"))
        gap_pct = _fmt_gap_pct(ch.get("gap_pct"))
        verdict = _verdict_display(ch.get("verdict", ""))
        row = (
            f"| {name:<13} | {platform:<13} | {mmm:<12} | {gap:<10} | "
            f"{gap_pct:<8} | {verdict:<14} |"
        )
        lines.append(row)

    return "\n".join(lines)


def _likely_causes(channel: dict) -> list[str]:
    """Generate 2-3 likely-cause bullets for an over-claiming channel."""
    name = channel["name"].lower()
    gap_pct = channel.get("gap_pct", 0) or 0
    causes: list[str] = []

    if "meta" in name or "facebook" in name:
        causes.append("View-through attribution on converters exposed to other channels")
        causes.append("Retargeting credit for users already intending to purchase")
        if gap_pct > 100:
            causes.append("Click overlap with Email and Google (double-counted)")
    elif "google" in name or "search" in name:
        causes.append("Branded-search credit (purchases that would have happened organically)")
        causes.append("Last-click bias on converted-anyway traffic")
        if gap_pct > 50:
            causes.append("Cross-channel conversion duplication with Meta")
    elif "tiktok" in name or "snap" in name or "pinterest" in name:
        causes.append("View-through attribution on upper-funnel impressions")
        causes.append("Post-view windows extend far beyond purchase intent window")
    else:
        causes.append(
            "Attribution model discrepancy (platform uses deterministic; MMM uses causal inference)"
        )
        causes.append("Cross-channel conversion overlap with higher-spend channels")

    return causes[:3]


def _section_likely_causes(result: dict) -> str:
    """Why-the-gap section for top 3 over-claiming channels."""
    channels = result.get("channels", [])
    over_claimers = [
        ch
        for ch in channels
        if ch.get("verdict") == _VERDICT_OVER and ch.get("gap_dollars") is not None
    ]

    if not over_claimers:
        return ""

    # Top 3 by absolute gap
    top3 = sorted(over_claimers, key=lambda c: c["gap_dollars"], reverse=True)[:3]

    lines = ["### Why the gap?"]
    for ch in top3:
        name = ch["name"]
        gap = ch.get("gap_dollars", 0)
        gap_pct = ch.get("gap_pct", 0) or 0
        sign = "+" if gap >= 0 else ""
        lines.append("")
        lines.append(
            f"**{name} ({sign}{fmt_dollars(gap)}, {sign}{gap_pct:.0f}%):** Likely drivers \u2014"
        )
        for cause in _likely_causes(ch):
            lines.append(f"- {cause}")

    return "\n".join(lines)


def _section_footer() -> str:
    return (
        "*Reconciliation is directional. MMM uses posterior inference, platforms use "
        "deterministic attribution; both have error bars. MMM is conservative by design "
        "\u2014 it credits only incremental revenue.*"
    )


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def render_reconcile_memo(reconcile_result: dict) -> str:
    """Render the reconciliation analyst memo from a mixlift_reconcile result dict.

    Returns markdown string, or "" if critical fields are missing (never raises).
    """
    try:
        return _render(reconcile_result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_reconcile_memo failed: %s", exc, exc_info=True)
        return ""


def _render(result: dict) -> str:
    """Internal render — may raise; caller wraps in try/except."""
    if not result:
        return ""

    sections: list[str] = []

    # 1. Headline
    headline = _section_headline(result)
    if headline:
        sections.append(headline)

    # 2. Reconciliation table
    table = _section_table(result)
    if table:
        sections.append(table)

    # 3. Likely causes
    causes = _section_likely_causes(result)
    if causes:
        sections.append(causes)

    # 4. Footer
    sections.append(_section_footer())

    return "\n\n".join(sections)


# ---------------------------------------------------------------------------
# Structured data builder
# ---------------------------------------------------------------------------


def build_reconcile_result(
    period: str,
    period_weeks: int,
    period_label: str,
    data_window: str,
    mcmc_config: dict,
    channel_columns: list[str],
    means_dict: dict[str, float],
    cis_dict: dict[str, tuple[float, float]],
    spend_dict: dict[str, float],
    platform_revenue_dict: dict[str, float | None],
) -> dict[str, Any]:
    """Build the structured reconcile result dict matching the spec output shape.

    Args:
        period: Period string (e.g. ``"last_4_weeks"``).
        period_weeks: Number of weeks in the period.
        period_label: Human-readable label with date range.
        data_window: Full fit window description.
        mcmc_config: MCMC config dict.
        channel_columns: Ordered list of raw channel column names (e.g. ``"meta_spend"``).
        means_dict: ``{display_name: mmm_contribution_mean}`` scaled to period.
        cis_dict: ``{display_name: (ci_lo, ci_hi)}`` scaled to period.
        spend_dict: ``{display_name: total_spend}`` over the period.
        platform_revenue_dict: ``{display_name: platform_revenue | None}``.
            ``None`` means no platform-reported revenue column for that channel.

    Returns:
        Result dict matching the spec output shape (``memo_markdown`` is added
        by the caller after this function returns).
    """
    from mixlift.modeling.optimizer import format_channel_name

    channel_list: list[dict[str, Any]] = []

    for raw_col in channel_columns:
        display = format_channel_name(raw_col)
        mmm_rev = max(0.0, means_dict.get(display, 0.0))
        ci_raw = cis_dict.get(display, (0.0, 0.0))
        mmm_ci = [round(ci_raw[0], 0), round(ci_raw[1], 0)]
        spend = spend_dict.get(display, 0.0)
        platform_rev = platform_revenue_dict.get(display)  # None if not available

        gap_dollars: float | None
        gap_pct: float | None
        if platform_rev is not None:
            gap_dollars = round(platform_rev - mmm_rev, 0)
            gap_pct = round((gap_dollars / mmm_rev) * 100, 1) if mmm_rev > 0 else None
        else:
            gap_dollars = None
            gap_pct = None

        verdict = _verdict(gap_pct)

        platform_roas: float | None = (
            round(platform_rev / spend, 2) if (platform_rev is not None and spend > 0) else None
        )
        mmm_roas: float | None = round(mmm_rev / spend, 2) if spend > 0 else None

        entry: dict[str, Any] = {
            "name": display,
            "platform_reported_revenue": (
                round(platform_rev, 0) if platform_rev is not None else None
            ),
            "mmm_attributed_revenue": round(mmm_rev, 0),
            "mmm_ci": mmm_ci,
            "gap_dollars": gap_dollars,
            "gap_pct": gap_pct,
            "verdict": verdict,
            "spend": round(spend, 0),
            "platform_reported_roas": platform_roas,
            "mmm_roas": mmm_roas,
        }
        channel_list.append(entry)

    # Sort: measured channels by abs(gap_dollars) desc; unmeasured at end
    measured = [c for c in channel_list if c["gap_dollars"] is not None]
    unmeasured = [c for c in channel_list if c["gap_dollars"] is None]
    measured.sort(key=lambda c: abs(c["gap_dollars"]), reverse=True)
    channel_list = measured + unmeasured

    # Aggregate totals (only channels with platform data)
    total_platform: float | None = None
    total_mmm = sum(c["mmm_attributed_revenue"] for c in channel_list)
    total_gap: float | None = None
    total_gap_pct: float | None = None

    measured_platform_revs = [
        c["platform_reported_revenue"]
        for c in channel_list
        if c["platform_reported_revenue"] is not None
    ]
    if measured_platform_revs:
        total_platform = sum(measured_platform_revs)
        total_mmm_measured = sum(
            c["mmm_attributed_revenue"]
            for c in channel_list
            if c["platform_reported_revenue"] is not None
        )
        total_gap = round(total_platform - total_mmm_measured, 0)
        total_gap_pct = (
            round((total_gap / total_mmm_measured) * 100, 1) if total_mmm_measured > 0 else None
        )

    result: dict[str, Any] = {
        "tool": "mixlift_reconcile",
        "version": "0.5.3",
        "mcmc_config": mcmc_config,
        "data_window": data_window,
        "period_label": period_label,
        "period_weeks": period_weeks,
        "total_platform_reported": round(total_platform, 0) if total_platform is not None else None,
        "total_mmm_attributed": round(total_mmm, 0),
        "total_gap_dollars": total_gap,
        "total_gap_pct": total_gap_pct,
        "channels": channel_list,
    }

    return result
