"""Clean-tool analyst-memo renderer for MixLift.

Pure stdlib only — no numpy, pandas, or jinja.
Receives a mixlift_clean result dict; never reads files or fits models.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

_SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}


def render_clean_memo(result: dict) -> str:
    """Render the clean analyst memo from a mixlift_clean result dict.

    Returns markdown string, or "" if critical fields are missing (never raises).
    """
    try:
        return _render(result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_clean_memo failed: %s", exc, exc_info=True)
        return ""


# ---------------------------------------------------------------------------
# Section renderers
# ---------------------------------------------------------------------------


def _verdict_line(issues: list[dict]) -> str:
    """One-line verdict at the top of the memo."""
    if not issues:
        return "No fixes needed. Your file is clean."

    high_or_medium = [i for i in issues if i["severity"] in ("high", "medium")]
    auto_fixable = [i for i in issues if i.get("auto_applies")]
    needs_call = [
        i for i in issues if not i.get("auto_applies") and i["severity"] in ("high", "medium")
    ]

    n_total = len(high_or_medium)
    n_auto = len(auto_fixable)
    n_manual = len(needs_call)

    if n_total == 0:
        return "No fixes needed. Your file is clean."

    parts: list[str] = [f"Found {n_total} issue(s)."]
    if n_auto > 0:
        parts.append(f"{n_auto} auto-fix.")
    if n_manual > 0:
        parts.append(f"{n_manual} need(s) your call.")

    return " ".join(parts)


def _section_auto_fixable(issues: list[dict], applied: bool) -> str:
    """Auto-fixable items section."""
    auto = [i for i in issues if i.get("auto_applies")]
    if not auto:
        return ""

    verb = "Applied" if applied else "Will apply silently"
    lines = [f"### Auto-fixable ({verb})"]
    lines.append("")
    for issue in auto:
        desc = issue.get("proposed_fix") or issue.get("description", "")
        n = issue.get("affected_rows", 0)
        vals = issue.get("affected_values", [])
        # Format a compact bullet
        if vals and issue["kind"] == "channel_name_inconsistency":
            vals_str = " + ".join(f"`{v}`" for v in vals)
            canonical = _infer_canonical_from_fix(issue.get("proposed_fix", ""))
            if canonical:
                lines.append(f"- {vals_str} \u2192 `{canonical}` ({n} rows)")
            else:
                lines.append(f"- {desc} ({n} rows)")
        elif issue["kind"] == "currency_markers":
            col = vals[0] if vals else "spend"
            lines.append(f"- Strip currency markers from `{col}` column ({n} rows)")
        elif issue["kind"] in ("date_format_inconsistency",):
            lines.append(f"- Convert dates to ISO 8601 ({n} rows)")
        elif issue["kind"] == "aggregation_mismatch":
            lines.append(f"- Aggregate daily to weekly ({n} rows collapsed)")
        elif issue["kind"] == "duplicate_rows":
            lines.append(f"- Drop {n} exact duplicate row(s)")
        elif issue["kind"] == "duplicate_date_channel":
            lines.append(f"- Deduplicate {n} conflicting (date, channel) row(s)")
        elif issue["kind"] in ("whitespace_headers", "whitespace_values"):
            if n > 0:
                lines.append(f"- Strip whitespace ({n} values)")
            else:
                lines.append("- Strip whitespace from headers")
        elif issue["kind"] in ("empty_columns", "empty_rows"):
            lines.append(f"- Drop empty {issue['kind'].replace('empty_', '')} ({n} affected)")
        else:
            lines.append(f"- {desc}" + (f" ({n} rows)" if n > 0 else ""))

    return "\n".join(lines)


def _infer_canonical_from_fix(proposed_fix: str) -> str:
    """Extract canonical name from a proposed_fix string like \"Rename 'FB' → 'Meta'\"."""
    import re

    match = re.search(r"\u2192\s*'([^']+)'", proposed_fix)
    if match:
        return match.group(1)
    return ""


def _section_needs_call(issues: list[dict]) -> str:
    """Items requiring human judgment."""
    manual = [
        i for i in issues if not i.get("auto_applies") and i["severity"] in ("high", "medium")
    ]
    if not manual:
        return ""

    lines = ["### Needs your call"]
    lines.append("")
    for issue in manual:
        desc = issue.get("description", "")
        lines.append(f"- {desc}")

    return "\n".join(lines)


def _section_informational(result: dict, issues: list[dict]) -> str:
    """Informational section: summary stats + info-severity issues."""
    lines = ["### Informational"]
    lines.append("")

    summary = result.get("input_summary", {})
    if summary:
        rows = summary.get("rows", "?")
        channels = summary.get("channels", "?")
        date_range = summary.get("date_range", "?")
        week_count = summary.get("week_count", "?")
        lines.append(
            f"- {rows} rows across {channels} channel(s), {week_count} week(s) \u2014 {date_range}"
        )

    info_issues = [i for i in issues if i["severity"] == "info"]
    for issue in info_issues:
        desc = issue.get("description", "")
        lines.append(f"- {desc}")

    return "\n".join(lines)


def _section_output(result: dict) -> str:
    """Output summary when applied."""
    out_summary = result.get("output_summary")
    if not out_summary:
        return ""

    output_path = result.get("output_path", "")
    rows = out_summary.get("rows", "?")
    channels = out_summary.get("channels", "?")
    date_range = out_summary.get("date_range", "?")

    lines = ["### Output"]
    lines.append("")
    lines.append(f"- Cleaned file written to `{output_path}`")
    lines.append(f"- {rows} rows, {channels} channel(s), {date_range}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main render
# ---------------------------------------------------------------------------


def _render(result: dict) -> str:
    """Internal render — may raise; caller wraps in try/except."""
    if not result:
        return ""

    issues: list[dict] = result.get("issues", [])
    applied = result.get("applied", False)

    sections: list[str] = []

    # 1. Verdict line
    sections.append(_verdict_line(issues))

    # 2. Auto-fixable
    auto_section = _section_auto_fixable(issues, applied)
    if auto_section:
        sections.append(auto_section)

    # 3. Needs your call
    manual_section = _section_needs_call(issues)
    if manual_section:
        sections.append(manual_section)

    # 4. Informational
    info_section = _section_informational(result, issues)
    if info_section:
        sections.append(info_section)

    # 5. Output summary (when applied)
    output_section = _section_output(result)
    if output_section:
        sections.append(output_section)

    return "\n\n".join(sections)
