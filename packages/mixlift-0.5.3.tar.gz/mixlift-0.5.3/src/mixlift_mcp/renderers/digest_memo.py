"""Weekly digest analyst-memo renderer for MixLift.

Pure stdlib only — no numpy, pandas, or jinja.
Bundles WoW + saturation + pacing + 3-move recommendations into a single
Monday-morning memo for performance marketers.

Sibling tool modules (wow_memo, saturation_memo) are imported lazily with
graceful degradation: if a module is missing, that section is skipped and a
note is appended to the digest footer.
"""

from __future__ import annotations

import logging
from typing import Any

from mixlift_mcp.renderers._helpers import (
    fmt_dollars,
    fmt_pct,
    fmt_roas,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Valid include values
# ---------------------------------------------------------------------------

VALID_SECTIONS: tuple[str, ...] = ("wow", "saturation", "pacing", "moves")

# ---------------------------------------------------------------------------
# Condensed WoW section
# ---------------------------------------------------------------------------


def _condense_wow(wow_result: dict) -> str:
    """Render a condensed WoW section (~1/3 of the standalone memo)."""
    if not wow_result:
        return ""

    current_rev = wow_result.get("current_revenue", 0.0)
    delta = wow_result.get("delta", 0.0)
    delta_pct = wow_result.get("delta_pct", 0.0)
    period_label = wow_result.get("period_label", "")
    channels = wow_result.get("channels", [])

    period_phrase = period_label.split(" (")[0] if period_label else "Last week"

    lines: list[str] = [f"### {period_phrase}"]
    lines.append("")

    # Headline
    if abs(delta) < 1:
        lines.append(f"Revenue flat at {fmt_dollars(current_rev)}.")
    elif delta > 0:
        lines.append(
            f"Revenue {fmt_dollars(current_rev)}, "
            f"+{fmt_dollars(abs(delta))} vs prior ({fmt_pct(delta_pct)})."
        )
    else:
        lines.append(
            f"Revenue {fmt_dollars(current_rev)}, "
            f"\u2212{fmt_dollars(abs(delta))} vs prior ({fmt_pct(delta_pct)})."
        )

    # Top movers table (condensed — just delta column, top 3)
    active = [ch for ch in channels if abs(ch.get("delta", 0.0)) > 0]
    if active:
        sorted_channels = sorted(active, key=lambda c: abs(c.get("delta", 0.0)), reverse=True)[:3]
        lines.append("")
        lines.append("| Channel | Contribution | Prior | Delta | mROAS change |")
        lines.append("|---------|-------------|-------|-------|--------------|")
        for ch in sorted_channels:
            name = ch["name"]
            curr = fmt_dollars(ch.get("contribution_current", 0.0))
            prior = fmt_dollars(ch.get("contribution_prior", 0.0))
            d = ch.get("delta", 0.0)
            d_str = fmt_dollars(d, signed=True)
            mroas_curr = ch.get("marginal_roas_current")
            mroas_prior = ch.get("marginal_roas_prior")
            if mroas_curr is not None and mroas_prior is not None:
                mroas_str = f"{fmt_roas(mroas_prior)} \u2192 {fmt_roas(mroas_curr)}"
            else:
                mroas_str = "\u2014"
            lines.append(f"| {name} | {curr} | {prior} | {d_str} | {mroas_str} |")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Condensed saturation section
# ---------------------------------------------------------------------------


def _condense_saturation(sat_result: dict) -> str:
    """Render a condensed saturation section (comparison table + 1-liner per channel)."""
    if not sat_result:
        return ""

    channels = sat_result.get("channels", [])
    active = [ch for ch in channels if ch.get("current_spend_wk", 0) > 0]
    if not active:
        return ""

    lines: list[str] = ["### Response curves", ""]

    # Comparison table only (no per-channel increment tables)
    sorted_ch = sorted(active, key=lambda c: c["saturation_pct"], reverse=True)

    lines.append("| Channel | Spend/wk | Saturation | Next $5k ROAS | Status |")
    lines.append("|---------|---------|------------|---------------|--------|")

    _status_labels = {
        "room_to_scale": "Push hard",
        "approaching": "Approaching ceiling",
        "at_frontier": "At efficient frontier",
        "over_saturated": "Cut or hold",
    }

    for ch in sorted_ch:
        name = ch["name"]
        spend = fmt_dollars(ch["current_spend_wk"])
        sat_pct = f"{round(ch['saturation_pct'])}%"
        status = _status_labels.get(ch.get("status", ""), ch.get("status", ""))
        ndr = ch.get("next_dollar_returns", {})
        if "5000" in ndr:
            roas_cell = fmt_roas(ndr["5000"].get("roas"))
        elif ndr:
            first_key = next(iter(ndr))
            roas_cell = fmt_roas(ndr[first_key].get("roas"))
        else:
            roas_cell = "\u2014"
        lines.append(f"| {name} | {spend} | {sat_pct} | {roas_cell} | {status} |")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Condensed pacing section
# ---------------------------------------------------------------------------


def _condense_pacing(pacing_result: dict) -> str:
    """Render a condensed pacing section (summary table only).

    Expects pacing_result with the schema produced by build_pacing_result:
    channels[].{name, budget, spent, variance, variance_pct, status, projected_end}
    """
    if not pacing_result:
        return ""

    channels = pacing_result.get("channels", [])
    if not channels:
        return ""

    lines: list[str] = ["### Pacing", ""]

    # Check for on-track summary — uses variance_pct (> ±5% = off plan)
    off_plan = [
        ch for ch in channels if abs(ch.get("variance_pct", 0.0)) > 5.0
    ]
    if not off_plan:
        lines.append("Pacing on-track across all channels.")
        return "\n".join(lines)

    lines.append("| Channel | Budget | Spent | Projected | Variance | Status |")
    lines.append("|---------|-------:|------:|----------:|---------:|--------|")

    _status_labels = {"under": "Under", "on_track": "On Track", "over": "Over"}

    for ch in channels:
        name = ch.get("name", "")
        budget = fmt_dollars(ch.get("budget", 0.0))
        spent = fmt_dollars(ch.get("spent", 0.0))
        projected = fmt_dollars(ch.get("projected_end", 0.0))
        variance = ch.get("variance", 0.0)
        variance_str = fmt_dollars(variance, signed=True)
        status = _status_labels.get(ch.get("status", ""), ch.get("status", ""))
        lines.append(f"| {name} | {budget} | {spent} | {projected} | {variance_str} | {status} |")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Move synthesis
# ---------------------------------------------------------------------------


def _synthesize_moves(
    wow_result: dict | None,
    sat_result: dict | None,
    pacing_result: dict | None,
) -> list[dict[str, str]]:
    """Synthesize the top 3 recommended actions from available section data.

    Logic:
    - Move 1: biggest efficiency-declining channel (from WoW) → "pull back $X"
    - Move 2: most underfunded channel (highest marginal ROAS, lowest saturation) → "push +$Y"
    - Move 3: pacing adjustment (if pacing available and off-plan) OR second-best scale opportunity
    """
    moves: list[dict[str, str]] = []

    # --- Move 1: worst efficiency mover ---
    if wow_result:
        channels = wow_result.get("channels", [])
        # Channels with negative efficiency effect (efficiency declined)
        declining = [
            ch for ch in channels
            if ch.get("efficiency_effect", 0.0) < 0
            and not ch.get("zero_spend_period")
        ]
        if declining:
            worst = min(declining, key=lambda c: c.get("efficiency_effect", 0.0))
            name = worst["name"]
            eff_effect = abs(worst.get("efficiency_effect", 0.0))
            mroas_curr = worst.get("marginal_roas_current")
            mroas_prior = worst.get("marginal_roas_prior")
            spend_curr = worst.get("spend_current", 0.0)
            # Suggest pulling back ~10% of current spend
            pullback = round(spend_curr * 0.1 / 1000) * 1000
            pullback = max(pullback, 1000)

            mroas_phrase = ""
            if mroas_curr is not None and mroas_prior is not None:
                mroas_phrase = (
                    f" marginal ROAS fell from {fmt_roas(mroas_prior)} "
                    f"to {fmt_roas(mroas_curr)}"
                )
            moves.append(
                {
                    "channel": name,
                    "action": f"Pull back {name} by {fmt_dollars(pullback)}",
                    "rationale": (
                        f"Efficiency declined this week;{mroas_phrase}. "
                        f"Net efficiency loss: {fmt_dollars(eff_effect)}."
                    ),
                    "expected_impact": (
                        f"+{fmt_dollars(round(eff_effect * 0.3))} net at current efficiency"
                    ),
                }
            )

    # --- Move 2: most underfunded channel (saturation) ---
    if sat_result:
        channels = sat_result.get("channels", [])
        active = [ch for ch in channels if ch.get("current_spend_wk", 0) > 0]
        candidates = [ch for ch in active if ch.get("status") == "room_to_scale"]
        if not candidates:
            candidates = [ch for ch in active if ch.get("saturation_pct", 100) < 50]
        if candidates:
            # Highest marginal ROAS + lowest saturation
            best = max(candidates, key=lambda c: c.get("marginal_roas_current", 0.0))
            name = best["name"]
            mroas = best.get("marginal_roas_current")
            sat_pct = best.get("saturation_pct", 0.0)
            spend_curr = best.get("current_spend_wk", 0.0)
            push = round(spend_curr * 0.2 / 500) * 500
            push = max(push, 500)
            ndr = best.get("next_dollar_returns", {})
            rev_lift = 0.0
            if ndr:
                first_key = sorted(ndr.keys(), key=lambda k: int(k))[0]
                step_int = int(first_key)
                if step_int > 0:
                    rev_lift = ndr[first_key].get("revenue_lift", 0.0)
                    # Scale to push amount
                    rev_lift = rev_lift * (push / step_int)

            # Avoid suggesting same channel as move 1
            if moves and name in moves[0]["action"]:
                # Pick second-best
                candidates_excl = [c for c in candidates if c["name"] != name]
                if candidates_excl:
                    best = max(candidates_excl, key=lambda c: c.get("marginal_roas_current", 0.0))
                    name = best["name"]
                    mroas = best.get("marginal_roas_current")
                    sat_pct = best.get("saturation_pct", 0.0)
                    spend_curr = best.get("current_spend_wk", 0.0)
                    push = round(spend_curr * 0.2 / 500) * 500
                    push = max(push, 500)
                    ndr = best.get("next_dollar_returns", {})
                    rev_lift = 0.0
                    if ndr:
                        first_key = sorted(ndr.keys(), key=lambda k: int(k))[0]
                        step_int = int(first_key)
                        if step_int > 0:
                            rev_lift = ndr[first_key].get("revenue_lift", 0.0)
                            rev_lift = rev_lift * (push / step_int)

            moves.append(
                {
                    "channel": name,
                    "action": f"Push {name} to {fmt_dollars(spend_curr + push)}/wk",
                    "rationale": (
                        f"{fmt_roas(mroas)} marginal ROAS, "
                        f"{round(sat_pct)}% of its saturation curve. "
                        "Incremental spend compounds here."
                    ),
                    "expected_impact": (
                        f"+{fmt_dollars(round(rev_lift))} incremental revenue" if rev_lift > 0
                        else f"+{fmt_roas(mroas)} ROAS on incremental spend"
                    ),
                }
            )

    # --- Move 3: pacing adjustment OR second-best scale opportunity ---
    if pacing_result:
        channels = pacing_result.get("channels", [])
        # Off-plan = variance_pct > ±5% (uses build_pacing_result schema)
        off_plan = [
            ch for ch in channels
            if abs(ch.get("variance_pct", 0.0)) > 5.0
        ]
        if off_plan:
            worst_pacing = max(off_plan, key=lambda c: abs(c.get("variance", 0.0)))
            name = worst_pacing.get("name", "")
            variance = worst_pacing.get("variance", 0.0)  # positive = over; negative = under
            days_elapsed = pacing_result.get("days_elapsed", 15)
            days_remaining = max(1, pacing_result.get("days_remaining", 15))
            # Daily adjustment needed to get back on track
            daily_bump = round(abs(variance) / days_remaining / 100) * 100
            daily_bump = max(daily_bump, 100)

            # variance < 0 means projected < budget (under-pacing) → lift
            direction = "Lift" if variance < 0 else "Reduce"
            moves.append(
                {
                    "channel": name,
                    "action": f"{direction} {name} pacing by {fmt_dollars(daily_bump)}/day",
                    "rationale": (
                        f"{fmt_dollars(abs(variance))} projected "
                        f"{'short' if variance < 0 else 'over'} "
                        f"plan at day {days_elapsed}; "
                        f"on-track rate requires the adjustment."
                    ),
                    "expected_impact": "Hit monthly plan",
                }
            )
            return moves[:3]

    # If no pacing issue, use second-best saturation opportunity as move 3
    if sat_result and len(moves) < 3:
        channels = sat_result.get("channels", [])
        active = [ch for ch in channels if ch.get("current_spend_wk", 0) > 0]
        # Exclude channels already in moves 1 & 2 — use explicit channel field
        mentioned = {m["channel"] for m in moves if m}
        candidates = [ch for ch in active if ch["name"] not in mentioned]
        candidates = sorted(
            candidates,
            key=lambda c: c.get("marginal_roas_current", 0.0),
            reverse=True,
        )
        if candidates:
            best = candidates[0]
            name = best["name"]
            mroas = best.get("marginal_roas_current")
            spend_curr = best.get("current_spend_wk", 0.0)
            sat_pct = best.get("saturation_pct", 0.0)
            push = round(spend_curr * 0.15 / 500) * 500
            push = max(push, 500)
            moves.append(
                {
                    "channel": name,
                    "action": f"Scale {name} by {fmt_dollars(push)}/wk",
                    "rationale": (
                        f"Second-highest marginal ROAS ({fmt_roas(mroas)}), "
                        f"{round(sat_pct)}% saturated. "
                        "Efficiency compounds from here."
                    ),
                    "expected_impact": f"{fmt_roas(mroas)} ROAS on incremental spend",
                }
            )

    return moves[:3]


# ---------------------------------------------------------------------------
# Opening digest card
# ---------------------------------------------------------------------------


def _render_opening_card(
    digest_period: str,
    summary: dict[str, Any],
    moves: list[dict[str, str]],
) -> str:
    """Render the opening digest card matching the spec voice."""
    lines: list[str] = [f"## {digest_period}", ""]

    rev_current = summary.get("revenue_current", 0.0)
    delta_pct = summary.get("delta_pct", 0.0)
    biggest_winner = summary.get("biggest_winner", "")
    biggest_loser = summary.get("biggest_loser", "")

    # Headline line
    delta_str = fmt_pct(delta_pct)
    lines.append(f"**Revenue: {fmt_dollars(rev_current)}, {delta_str} vs prior week.**")

    # Contextual sentence
    context_parts: list[str] = []
    if biggest_loser:
        context_parts.append(f"{biggest_loser} took the biggest efficiency hit.")
    if biggest_winner:
        context_parts.append(f"{biggest_winner} remains the strongest compounder.")
    if context_parts:
        lines.append(" ".join(context_parts))

    if moves:
        lines.append("")
        lines.append("### Three moves this week")
        lines.append("")
        for i, move in enumerate(moves, 1):
            action = move.get("action", "")
            rationale = move.get("rationale", "")
            expected_impact = move.get("expected_impact", "")
            lines.append(f"**{i}. {action}** \u2014 {rationale}")
            if expected_impact:
                lines.append(f"Net gain: {expected_impact}.")
            lines.append("")

    return "\n".join(lines).rstrip()


# ---------------------------------------------------------------------------
# Summary computation
# ---------------------------------------------------------------------------


def _compute_summary(
    wow_result: dict | None,
    sat_result: dict | None,
) -> dict[str, Any]:
    """Compute top-level summary fields for the digest output."""
    summary: dict[str, Any] = {
        "revenue_current": 0.0,
        "revenue_prior": 0.0,
        "delta": 0.0,
        "delta_pct": 0.0,
        "biggest_winner": "",
        "biggest_loser": "",
    }

    if wow_result:
        summary["revenue_current"] = wow_result.get("current_revenue", 0.0)
        summary["revenue_prior"] = wow_result.get("prior_revenue", 0.0)
        summary["delta"] = wow_result.get("delta", 0.0)
        summary["delta_pct"] = wow_result.get("delta_pct", 0.0)

        channels = wow_result.get("channels", [])
        active = [ch for ch in channels if not ch.get("zero_spend_period")]

        # Biggest winner: largest positive efficiency effect
        winners = [ch for ch in active if ch.get("efficiency_effect", 0.0) > 0]
        if winners:
            top_winner = max(winners, key=lambda c: c.get("efficiency_effect", 0.0))
            eff = top_winner.get("efficiency_effect", 0.0)
            summary["biggest_winner"] = (
                f"{top_winner['name']} (+{fmt_dollars(round(eff))} efficiency)"
            )

        # Biggest loser: worst efficiency effect (most negative)
        losers = [ch for ch in active if ch.get("efficiency_effect", 0.0) < 0]
        if losers:
            top_loser = min(losers, key=lambda c: c.get("efficiency_effect", 0.0))
            eff = abs(top_loser.get("efficiency_effect", 0.0))
            summary["biggest_loser"] = (
                f"{top_loser['name']} (\u2212{fmt_dollars(round(eff))} efficiency)"
            )

    return summary


# ---------------------------------------------------------------------------
# Digest period label
# ---------------------------------------------------------------------------


def _compute_digest_period(wow_result: dict | None) -> str:
    """Extract a human-readable digest period from wow_result or fallback."""
    if wow_result:
        period_label = wow_result.get("period_label", "")
        # "Last week (2026-04-07 to 2026-04-14) vs prior ..."
        # Extract just the current date range
        import re

        m = re.search(r"\((\d{4}-\d{2}-\d{2}) to (\d{4}-\d{2}-\d{2})\)", period_label)
        if m:
            start_str, end_str = m.group(1), m.group(2)
            try:
                from datetime import date

                start_dt = date.fromisoformat(start_str)
                end_dt = date.fromisoformat(end_str)
                start_fmt = start_dt.strftime("%B %-d")
                end_fmt = end_dt.strftime("%B %-d")
                return f"Week of {start_fmt} \u2014 {end_fmt}"
            except Exception:
                return f"Week of {start_str} to {end_str}"
    return "Week digest"


# ---------------------------------------------------------------------------
# Footer
# ---------------------------------------------------------------------------


def _render_footer(
    fingerprint: str,
    mcmc_config: dict,
    sections_skipped: list[str],
) -> str:
    """Render digest footer."""
    fp_short = fingerprint[:8] if fingerprint else "unknown"

    if isinstance(mcmc_config, dict):
        chains = mcmc_config.get("chains")
        draws = mcmc_config.get("draws")
        if chains and draws:
            config_str = f"{chains} chains \u00d7 {draws} draws"
        else:
            config_str = "default MCMC"
    else:
        config_str = "default MCMC"

    lines: list[str] = [
        f"*\u2014 Generated from fit {fp_short}, {config_str}*",
        "*\u2014 Full reports: `mixlift_wow`, `mixlift_saturation`, `mixlift_pacing`*",
    ]

    if sections_skipped:
        skipped_str = ", ".join(sections_skipped)
        lines.append(
            f"*\u2014 Sections skipped (module unavailable): {skipped_str}*"
        )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def render_digest_memo(digest_result: dict) -> str:
    """Render the weekly digest memo from a build_digest_result dict.

    Returns markdown string. Never raises (logs and returns "" on failure).
    """
    try:
        return _render_digest(digest_result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_digest_memo failed: %s", exc, exc_info=True)
        return ""


def build_digest_result(
    csv_path: str,
    license_key: str | None,
    include: list[str],
    plan: dict[str, float] | None,
    mcmc_config: dict,
    data_window: str,
    fingerprint: str,
    wow_result: dict | None,
    sat_result: dict | None,
    pacing_result: dict | None,
    sections_skipped: list[str],
) -> dict[str, Any]:
    """Build the structured digest result dict matching the spec output shape.

    Args:
        csv_path: Path to the source CSV.
        license_key: License key used (may be None for free tier).
        include: Sections requested by the caller.
        plan: Budget plan dict (may be None).
        mcmc_config: MCMC config dict from the fitted model.
        data_window: Data window string.
        fingerprint: Model fingerprint hash.
        wow_result: Pre-built wow result dict, or None if unavailable.
        sat_result: Pre-built saturation result dict, or None if unavailable.
        pacing_result: Pre-built pacing result dict, or None if unavailable.
        sections_skipped: Section names that were skipped due to missing modules or data.

    Returns:
        Result dict matching the spec output shape.
    """
    digest_period = _compute_digest_period(wow_result)
    summary = _compute_summary(wow_result, sat_result)

    # Synthesize moves only if "moves" is in include
    moves: list[dict[str, str]] = []
    if "moves" in include:
        moves = _synthesize_moves(wow_result, sat_result, pacing_result)

    # Build per-section content
    sections_included = [s for s in include if s not in sections_skipped]
    sections_data: dict[str, Any] = {}

    if "wow" in sections_included and wow_result is not None:
        try:
            import mixlift_mcp.renderers.wow_memo  # noqa: F401 — guard for graceful degradation

            sections_data["wow"] = {
                "memo_markdown": _condense_wow(wow_result),
                "data": wow_result,
            }
        except ImportError:
            logger.warning("wow_memo not importable during section build")

    if "saturation" in sections_included and sat_result is not None:
        sections_data["saturation"] = {
            "memo_markdown": _condense_saturation(sat_result),
            "data": sat_result,
        }

    if "pacing" in sections_included and pacing_result is not None:
        sections_data["pacing"] = {
            "memo_markdown": _condense_pacing(pacing_result),
            "data": pacing_result,
        }

    if "moves" in sections_included:
        sections_data["moves"] = moves

    result: dict[str, Any] = {
        "tool": "mixlift_weekly_digest",
        "version": "0.5.3",
        "mcmc_config": mcmc_config,
        "data_window": data_window,
        "digest_period": digest_period,
        "sections_included": sections_included,
        "sections_skipped": sections_skipped,
        "summary": summary,
        "sections": sections_data,
        "memo_markdown": "",  # filled below
    }

    # Render memo
    result["memo_markdown"] = _render_digest(result)

    return result


# ---------------------------------------------------------------------------
# Internal render
# ---------------------------------------------------------------------------


def _render_digest(result: dict) -> str:
    """Internal render — may raise; called via render_digest_memo wrapper."""
    if not result:
        return ""

    digest_period = result.get("digest_period", "Week digest")
    summary = result.get("summary", {})
    sections = result.get("sections", {})
    sections_skipped = result.get("sections_skipped", [])
    mcmc_config = result.get("mcmc_config", {})

    # Fingerprint from nested wow data or top-level
    fingerprint = ""
    wow_data = sections.get("wow", {}).get("data", {})
    if not wow_data:
        sat_data = sections.get("saturation", {}).get("data", {})
        if sat_data:
            fingerprint = sat_data.get("fingerprint", "")
    else:
        fingerprint = wow_data.get("fingerprint", "")

    moves = sections.get("moves", [])

    parts: list[str] = []

    # 1. Opening digest card
    card = _render_opening_card(digest_period, summary, moves)
    if card:
        parts.append(card)

    # 2. WoW section
    wow_memo = sections.get("wow", {}).get("memo_markdown", "")
    if wow_memo:
        parts.append(wow_memo)
    elif "wow" in sections_skipped:
        parts.append("### Week-over-week\n\n*WoW data unavailable (tool not yet installed).*")

    # 3. Saturation section
    sat_memo = sections.get("saturation", {}).get("memo_markdown", "")
    if sat_memo:
        parts.append(sat_memo)
    elif "saturation" in sections_skipped:
        parts.append(
            "### Response curves\n\n*Saturation data unavailable (tool not yet installed).*"
        )

    # 4. Pacing section
    pacing_memo = sections.get("pacing", {}).get("memo_markdown", "")
    if pacing_memo:
        parts.append(pacing_memo)
    elif "pacing" in sections_skipped:
        parts.append("### Pacing\n\n*Pacing data unavailable (plan not provided).*")

    # 5. Footer
    parts.append(_render_footer(fingerprint, mcmc_config, sections_skipped))

    return "\n\n".join(parts)
