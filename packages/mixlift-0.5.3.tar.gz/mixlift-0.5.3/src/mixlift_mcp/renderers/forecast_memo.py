"""Mock-C analyst-memo renderer for mixlift_forecast output.

Pure stdlib only — no numpy, pandas, or jinja.
"""

from __future__ import annotations

import logging
import re

from mixlift_mcp.renderers._helpers import fmt_dollars

logger = logging.getLogger(__name__)


def render_forecast_memo(forecast_result: dict) -> str:
    """Render a Mock-C-aesthetic multi-week forecast memo.

    Returns markdown string, or "" if critical fields missing. Never raises.
    """
    try:
        return _render(forecast_result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_forecast_memo failed: %s", exc, exc_info=True)
        return ""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_MCMC_RE = re.compile(r"(\d+)\s+chains?\s*[x×]\s*(\d+)\s+draws?", re.IGNORECASE)


def _render(forecast_result: dict) -> str:
    if not isinstance(forecast_result, dict):
        return ""

    summary = forecast_result.get("summary")
    if not isinstance(summary, dict):
        return ""

    horizon = forecast_result.get("horizon_weeks")
    if horizon is None:
        return ""

    # Pull required revenue fields
    current_weekly_raw = summary.get("current_weekly_revenue")
    optimized_weekly_raw = summary.get("optimized_weekly_revenue")
    total_delta_raw = summary.get("total_delta")

    if any(v is None for v in (current_weekly_raw, optimized_weekly_raw, total_delta_raw)):
        return ""

    current_weekly = float(current_weekly_raw)
    optimized_weekly = float(optimized_weekly_raw)
    total_delta = float(total_delta_raw)
    weekly_delta = optimized_weekly - current_weekly

    # --- Section 1: Lede ---
    lede = f"**{horizon}-week forecast · current vs optimal allocation**"

    # --- Section 2: H2 thesis ---
    if total_delta > 0:
        h2 = (
            f"## Optimizing lifts revenue by "
            f"**{fmt_dollars(total_delta, signed=True)}** over {horizon} weeks."
        )
    else:
        h2 = (
            f"## Your current allocation already beats the naive optimum "
            f"over {horizon} weeks."
        )

    # --- Section 3: Narrative paragraph ---
    ci_block = summary.get("impact_ci_80", {})
    ci_pct_low = ci_block.get("low", 0.0) if isinstance(ci_block, dict) else 0.0
    ci_pct_high = ci_block.get("high", 0.0) if isinstance(ci_block, dict) else 0.0

    # CI bounds are % impact; convert to dollar lift over the full horizon
    total_current = current_weekly * horizon
    ci_low_dollars = total_current * (1 + float(ci_pct_low) / 100) - total_current
    ci_high_dollars = total_current * (1 + float(ci_pct_high) / 100) - total_current

    narrative = (
        f"At current allocation, you'd run {fmt_dollars(current_weekly)}/wk. "
        f"Optimized pushes this to {fmt_dollars(optimized_weekly)}/wk "
        f"— an extra {fmt_dollars(weekly_delta, signed=True)}/wk. "
        f"80% CI on total lift: {fmt_dollars(ci_low_dollars, signed=True)} "
        f"to {fmt_dollars(ci_high_dollars, signed=True)}."
    )

    # --- Section 4: Weekly trajectory table ---
    trajectory_section = _build_trajectory_section(forecast_result, horizon)

    # --- Section 5: Footer ---
    footer = _build_footer(forecast_result)

    parts = [lede, "", h2, "", narrative]
    if trajectory_section:
        parts += ["", trajectory_section]
    parts += ["", footer]

    return "\n".join(parts)


def _build_trajectory_section(forecast_result: dict, horizon: int) -> str:
    """Return the H3 + table string, or "" if trajectory data absent."""
    projections = forecast_result.get("weekly_projections")
    if not isinstance(projections, list) or not projections:
        return ""

    # Select which week indices to display
    if horizon <= 5:
        indices = list(range(len(projections)))
    else:
        # Weeks 1-4 (indices 0-3) + last week (index horizon-1)
        base = list(range(min(4, len(projections))))
        last = len(projections) - 1
        if last not in base:
            indices = base + [last]
        else:
            indices = base

    header = (
        "### Weekly trajectory\n\n"
        "| Week | Current | Optimized | \u0394 | Cumulative \u0394 |\n"
        "|-----:|--------:|----------:|----:|--------------:|"
    )

    rows = []
    for i in indices:
        row = projections[i]
        week_num = row.get("week", i + 1)
        cur = fmt_dollars(row.get("current_revenue", 0))
        opt = fmt_dollars(row.get("optimized_revenue", 0))
        delta = fmt_dollars(row.get("weekly_delta", 0), signed=True)
        cum_delta = fmt_dollars(row.get("cumulative_delta", 0), signed=True)
        rows.append(f"| {week_num} | {cur} | {opt} | {delta} | {cum_delta} |")

    return header + "\n" + "\n".join(rows)


def _build_footer(forecast_result: dict) -> str:
    """Return italicised posterior footer string."""
    # Attempt to parse MCMC config from model_info
    model_info = forecast_result.get("model_info", {})
    mcmc_config = ""
    if isinstance(model_info, dict):
        mcmc_config = str(model_info.get("mcmc_config", ""))

    horizon = forecast_result.get("horizon_weeks", "")
    match = _MCMC_RE.search(mcmc_config)
    if match:
        chains, draws = match.group(1), match.group(2)
        return (
            f"*Posterior: {chains} chains \u00d7 {draws} draws. "
            f"Forecast horizon: {horizon} weeks.*"
        )

    # Try individual chain/draw fields
    chains = model_info.get("chains") if isinstance(model_info, dict) else None
    draws = model_info.get("draws") if isinstance(model_info, dict) else None
    if chains is not None and draws is not None:
        return (
            f"*Posterior: {chains} chains \u00d7 {draws} draws. "
            f"Forecast horizon: {horizon} weeks.*"
        )

    return "*Posterior-based forecast.*"
