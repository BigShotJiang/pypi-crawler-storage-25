"""Revenue decomposition analyst-memo renderer for MixLift.

Pure stdlib only — no numpy, pandas, or jinja.
Receives pre-computed contribution dicts from extract_channel_contributions;
never fits a model.
"""

from __future__ import annotations

import logging
from typing import Any

from mixlift_mcp.renderers._helpers import (
    fmt_dollars,
    fmt_roas,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Period helpers
# ---------------------------------------------------------------------------

VALID_PERIODS = ("last_week", "last_4_weeks", "last_quarter", "full_period")

_PERIOD_WEEKS: dict[str, int | None] = {
    "last_week": 1,
    "last_4_weeks": 4,
    "last_quarter": 13,
    "full_period": None,  # resolved at call time
}

_PERIOD_DISPLAY: dict[str, str] = {
    "last_week": "Last week",
    "last_4_weeks": "Last 4 weeks",
    "last_quarter": "Last quarter",
    "full_period": "Full period",
}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def render_decompose_memo(decompose_result: dict) -> str:
    """Render the decomposition analyst memo from a mixlift_decompose result dict.

    Returns markdown string, or "" if critical fields are missing (never raises).
    """
    try:
        return _render(decompose_result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_decompose_memo failed: %s", exc, exc_info=True)
        return ""


# ---------------------------------------------------------------------------
# Section renderers
# ---------------------------------------------------------------------------


def _section_diagnosis(result: dict) -> str:
    """Two-paragraph opening: headline split and biggest paid driver."""
    total = result.get("total_revenue", 0)
    baseline = result.get("baseline", {})
    paid_total = result.get("paid_total", {})
    channels = result.get("channels", [])

    if not total or not baseline or not paid_total:
        return ""

    period_label = result.get("period_label", "")

    # Strip the date range suffix for a compact opening phrase
    # e.g. "Last 4 weeks (2026-03-17 to 2026-04-14)" → "Last 4 weeks"
    period_phrase = period_label.split(" (")[0].lower() if period_label else "this period"

    total_fmt = fmt_dollars(total)
    baseline_rev = baseline.get("revenue", 0)
    baseline_pct = round(baseline.get("pct_of_total", 0))
    paid_rev = paid_total.get("revenue", 0)
    paid_pct = round(paid_total.get("pct_of_total", 0))

    para1 = (
        f"Of {total_fmt} {period_phrase}, "
        f"{fmt_dollars(baseline_rev)} ({baseline_pct}%) was baseline "
        f"and {fmt_dollars(paid_rev)} ({paid_pct}%) was paid-attributable."
    )

    paras = [para1]

    # Para 2: biggest paid driver
    active_channels = [ch for ch in channels if ch.get("contribution", 0) > 0]
    if active_channels:
        top = max(active_channels, key=lambda c: c["contribution"])
        top_name = top["name"]
        top_contrib = fmt_dollars(top["contribution"])
        top_pct_paid = round(top.get("pct_of_paid", 0))
        top_roas = top.get("roas")

        roas_clause = f" at {fmt_roas(top_roas)} ROAS" if top_roas else ""
        para2 = f"{top_name} carried {top_contrib} — {top_pct_paid}% of paid revenue{roas_clause}."
        paras.append(para2)

    return "\n\n".join(paras)


def _section_decomposition_table(result: dict) -> str:
    """Decomposition table with baseline, paid total, and per-channel rows."""
    baseline = result.get("baseline", {})
    paid_total = result.get("paid_total", {})
    channels = result.get("channels", [])
    period_label = result.get("period_label", "")

    # Strip date range for table heading
    period_short = period_label.split(" (")[0].lower() if period_label else "period"

    def _ci_str(ci: list | tuple | None) -> str:
        if not ci or len(ci) < 2:
            return "\u2014"
        return f"{fmt_dollars(ci[0])}\u2013{fmt_dollars(ci[1])}"

    lines: list[str] = [
        f"### Revenue decomposition \u2014 {period_short}",
        "",
        "| Source              | Revenue    | % of total | Credible interval     |",
        "|---------------------|------------|------------|-----------------------|",
    ]

    # Baseline row
    b_rev = baseline.get("revenue", 0)
    b_pct = round(baseline.get("pct_of_total", 0))
    b_ci = _ci_str(baseline.get("ci"))
    lines.append(f"| Baseline            | {fmt_dollars(b_rev)} | {b_pct}% | {b_ci} |")

    # Paid total row (bold)
    p_rev = paid_total.get("revenue", 0)
    p_pct = round(paid_total.get("pct_of_total", 0))
    p_ci = _ci_str(paid_total.get("ci"))
    lines.append(f"| **Paid total**      | **{fmt_dollars(p_rev)}** | **{p_pct}%** | **{p_ci}** |")

    # Per-channel rows with tree prefix
    for i, ch in enumerate(channels):
        prefix = "\u2514\u2500\u2500" if i == len(channels) - 1 else "\u251c\u2500\u2500"
        name = ch["name"]
        rev = ch.get("contribution", 0)
        pct = round(ch.get("pct_of_total", 0))
        ch_ci = _ci_str(ch.get("ci"))
        lines.append(f"| {prefix} {name:<15} | {fmt_dollars(rev)} | {pct}% | {ch_ci} |")

    return "\n".join(lines)


def _section_channel_table(result: dict) -> str:
    """Per-channel contribution, spend, ROAS table."""
    channels = result.get("channels", [])
    if not channels:
        return ""

    def _ci_compact(ci: list | tuple | None) -> str:
        """Compact CI like '$288k–$352k'."""
        if not ci or len(ci) < 2:
            return "\u2014"
        lo, hi = ci[0], ci[1]

        def _k(v: float) -> str:
            if abs(v) >= 1_000:
                return f"${round(v / 1000)}k"
            return fmt_dollars(v)

        return f"{_k(lo)}\u2013{_k(hi)}"

    lines: list[str] = [
        "### By channel \u2014 contribution, spend, ROAS",
        "",
        "| Channel       | Contribution | Spend     | ROAS  | Credible interval |",
        "|---------------|--------------|-----------|-------|-------------------|",
    ]

    for ch in channels:
        name = ch["name"]
        contrib = fmt_dollars(ch.get("contribution", 0))
        spend = fmt_dollars(ch.get("spend", 0))
        roas = fmt_roas(ch.get("roas"))
        ci_str = _ci_compact(ch.get("ci"))
        floored_note = " †" if ch.get("floored") else ""
        lines.append(
            f"| {name}{floored_note:<13} | {contrib:<12} | {spend:<9} | {roas:<5} | {ci_str} |"
        )

    return "\n".join(lines)


def _section_footnotes(
    channels: list[dict],
    skipped: list[str],
) -> str:
    """Return footnotes for floored and skipped channels."""
    notes: list[str] = []

    floored = [ch["name"] for ch in channels if ch.get("floored")]
    if floored:
        joined = ", ".join(floored)
        notes.append(
            f"\u2020 {joined}: raw contribution was negative (weak/noisy signal) — "
            "floored to $0 in memo; true posterior value retained in structured output."
        )

    if skipped:
        joined = ", ".join(skipped)
        notes.append(
            f"Requested but not found in fit: {joined}. "
            "These channels were skipped \u2014 check column names in your CSV."
        )

    if not notes:
        return ""
    return "\n\n".join(f"*{n}*" for n in notes)


def _section_footer(result: dict) -> str:
    """Return the italic footer line."""
    data_window = result.get("data_window", "")
    mcmc_config = result.get("mcmc_config", {})

    if isinstance(mcmc_config, dict):
        chains = mcmc_config.get("chains")
        draws = mcmc_config.get("draws")
        if chains and draws:
            posterior_str = f"Posterior: {chains} chains \u00d7 {draws} draws"
        else:
            posterior_str = "Posterior converged."
    else:
        posterior_str = "Posterior converged."

    window_str = f"Data window: {data_window}." if data_window else ""
    scaling_note = (
        "Per-period channel contributions are proportionally scaled from the "
        "full-window posterior; total revenue is from observed data."
    )
    parts = [p for p in [window_str, posterior_str] if p]
    footer_line = f"*{' '.join(parts)}*"
    return f"{footer_line}\n\n*{scaling_note}*"


# ---------------------------------------------------------------------------
# Main render
# ---------------------------------------------------------------------------


def _render(result: dict) -> str:
    """Internal render — may raise; caller wraps in try/except."""
    if not result:
        return ""

    channels: list[dict] = result.get("channels", [])
    skipped: list[str] = result.get("_skipped_channels", [])

    sections: list[str] = []

    # 1. Two-paragraph diagnosis
    diagnosis = _section_diagnosis(result)
    if diagnosis:
        sections.append(diagnosis)

    # 2. Decomposition table
    sections.append(_section_decomposition_table(result))

    # 3. Per-channel ROAS table (only if at least one channel has spend)
    if any(ch.get("spend", 0) > 0 for ch in channels):
        ch_table = _section_channel_table(result)
        if ch_table:
            sections.append(ch_table)

    # 4. Footnotes
    footnotes = _section_footnotes(channels, skipped)
    if footnotes:
        sections.append(footnotes)

    # 5. Footer
    sections.append(_section_footer(result))

    return "\n\n".join(sections)


# ---------------------------------------------------------------------------
# Structured data builder (used by server.py)
# ---------------------------------------------------------------------------


def build_decompose_result(
    period: str,
    period_weeks: int,
    period_label: str,
    data_window: str,
    total_revenue: float,
    means_dict: dict[str, float],
    cis_dict: dict[str, tuple[float, float]],
    spend_dict: dict[str, float],
    channel_columns: list[str],
    mcmc_config: dict,
    skipped_channels: list[str],
) -> dict[str, Any]:
    """Build the structured decompose result dict matching the spec output shape.

    Args:
        period: Period string (e.g. "last_4_weeks").
        period_weeks: Number of weeks in the period.
        period_label: Human-readable period label with date range.
        data_window: Data window string (e.g. "2025-04-14 to 2026-04-07 (51 weeks)").
        total_revenue: Sum of actual revenue over the period.
        means_dict: {display_name: contribution_mean} from extract_channel_contributions.
        cis_dict: {display_name: (ci_lo, ci_hi)} from extract_channel_contributions.
        spend_dict: {display_name: total_spend} over the period.
        channel_columns: Ordered list of raw channel column names (after filter).
        mcmc_config: MCMC config dict.
        skipped_channels: List of column names that were requested but not found.

    Returns:
        Result dict matching the spec, with ``_skipped_channels`` included for
        the renderer (caller strips it before final JSON serialisation).
    """
    from mixlift.modeling.optimizer import format_channel_name

    channel_list: list[dict[str, Any]] = []

    for raw_col in channel_columns:
        display = format_channel_name(raw_col)
        raw_contrib = means_dict.get(display, 0.0)
        floored = raw_contrib < 0
        contrib = max(0.0, raw_contrib)

        ci_raw = cis_dict.get(display, (0.0, 0.0))
        ci = [round(ci_raw[0], 0), round(ci_raw[1], 0)]

        spend = spend_dict.get(display, 0.0)
        roas = (contrib / spend) if spend > 0 else None

        entry: dict[str, Any] = {
            "name": display,
            "contribution": round(contrib, 0),
            "pct_of_total": 0.0,  # filled below
            "pct_of_paid": 0.0,  # filled below
            "ci": ci,
            "spend": round(spend, 0),
            "roas": round(roas, 2) if roas is not None else None,
        }
        if floored:
            entry["floored"] = True
            entry["true_contribution"] = round(raw_contrib, 0)

        channel_list.append(entry)

    # Sort by contribution descending
    channel_list.sort(key=lambda c: c["contribution"], reverse=True)

    # Compute totals
    paid_rev = sum(ch["contribution"] for ch in channel_list)
    baseline_rev = max(0.0, total_revenue - paid_rev)

    paid_ci_lo = sum(
        max(0.0, cis_dict.get(format_channel_name(c), (0.0, 0.0))[0]) for c in channel_columns
    )
    paid_ci_hi = sum(
        max(0.0, cis_dict.get(format_channel_name(c), (0.0, 0.0))[1]) for c in channel_columns
    )

    baseline_ci_lo = max(0.0, total_revenue - paid_ci_hi)
    baseline_ci_hi = max(0.0, total_revenue - paid_ci_lo)

    # Fill pct columns
    for ch in channel_list:
        ch["pct_of_total"] = (
            round((ch["contribution"] / total_revenue * 100), 1) if total_revenue else 0.0
        )
        ch["pct_of_paid"] = round((ch["contribution"] / paid_rev * 100), 1) if paid_rev else 0.0

    result: dict[str, Any] = {
        "tool": "mixlift_decompose",
        "version": "0.5.3",
        "mcmc_config": mcmc_config,
        "data_window": data_window,
        "period_label": period_label,
        "period_weeks": period_weeks,
        "total_revenue": round(total_revenue, 0),
        "baseline": {
            "revenue": round(baseline_rev, 0),
            "pct_of_total": round(baseline_rev / total_revenue * 100, 1) if total_revenue else 0.0,
            "ci": [round(baseline_ci_lo, 0), round(baseline_ci_hi, 0)],
        },
        "paid_total": {
            "revenue": round(paid_rev, 0),
            "pct_of_total": round(paid_rev / total_revenue * 100, 1) if total_revenue else 0.0,
            "ci": [round(paid_ci_lo, 0), round(paid_ci_hi, 0)],
        },
        "channels": channel_list,
        "_skipped_channels": skipped_channels,
    }

    return result
