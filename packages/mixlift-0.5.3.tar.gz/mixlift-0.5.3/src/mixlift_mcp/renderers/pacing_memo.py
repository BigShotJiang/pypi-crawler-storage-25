"""Pacing analyst-memo renderer for MixLift.

Pure stdlib + pandas — no PyMC-Marketing, no model cache.
Receives a pre-computed pacing result dict; never fits a model.
"""

from __future__ import annotations

import calendar
import logging
from datetime import date, timedelta
from typing import Any

import pandas as pd

from mixlift_mcp.renderers._helpers import fmt_dollars

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_VERSION = "0.5.3"
_VALID_PERIODS = ("week", "month", "quarter")

# Status thresholds: pacing variance as fraction of budget
# under if < -5%, over if > 5%, on_track otherwise
_UNDER_THRESHOLD = -0.05
_OVER_THRESHOLD = 0.05


# ---------------------------------------------------------------------------
# Date / period helpers
# ---------------------------------------------------------------------------


def _parse_today(today_str: str | None) -> date | None:
    """Parse an ISO date string; return None on failure."""
    if today_str is None:
        return date.today()
    try:
        return date.fromisoformat(today_str)
    except ValueError:
        return None


def _period_bounds(today: date, plan_period: str) -> tuple[date, date]:
    """Return (period_start, period_end) for the period containing *today*.

    For "week":    Monday–Sunday of the ISO week.
    For "month":   1st–last day of the calendar month.
    For "quarter": 1st day of the quarter through last day.
    """
    if plan_period == "week":
        # ISO week: Monday=0
        start = today - timedelta(days=today.weekday())
        end = start + timedelta(days=6)
        return start, end

    if plan_period == "month":
        start = date(today.year, today.month, 1)
        last_day = calendar.monthrange(today.year, today.month)[1]
        end = date(today.year, today.month, last_day)
        return start, end

    # quarter
    quarter = (today.month - 1) // 3  # 0-indexed
    q_start_month = quarter * 3 + 1
    q_end_month = q_start_month + 2
    start = date(today.year, q_start_month, 1)
    last_day = calendar.monthrange(today.year, q_end_month)[1]
    end = date(today.year, q_end_month, last_day)
    return start, end


def _period_label(today: date, plan_period: str, period_start: date, period_end: date) -> str:
    """Human-readable period label, e.g. 'April 2026 (day 15 of 30)'."""
    total_days = (period_end - period_start).days + 1
    day_num = (today - period_start).days + 1
    day_num = max(1, min(day_num, total_days))  # clamp

    if plan_period == "month":
        label = today.strftime("%B %Y")
        return f"{label} (day {day_num} of {total_days})"
    if plan_period == "week":
        label = f"Week of {period_start.strftime('%b %d, %Y')}"
        return f"{label} (day {day_num} of {total_days})"
    # quarter
    quarter_num = (today.month - 1) // 3 + 1
    label = f"Q{quarter_num} {today.year}"
    return f"{label} (day {day_num} of {total_days})"


def _classify_status(variance_pct: float) -> str:
    """Return 'under', 'on_track', or 'over' based on variance_pct."""
    if variance_pct < _UNDER_THRESHOLD:
        return "under"
    if variance_pct > _OVER_THRESHOLD:
        return "over"
    return "on_track"


# ---------------------------------------------------------------------------
# CSV ingestion
# ---------------------------------------------------------------------------


def _load_spend_df(csv_path: str) -> pd.DataFrame | str:
    """Load a wide-format daily/weekly spend CSV.

    Returns a DataFrame with a DatetimeIndex-like 'date' column and one
    column per channel, or an error string if loading fails.

    Expects columns: date, [channel1], [channel2], ...
    Date column name is detected case-insensitively.
    """
    try:
        df = pd.read_csv(csv_path)
    except Exception as exc:
        return f"Cannot read CSV: {exc}"

    if df.empty or len(df.columns) == 0:
        return "CSV is empty."

    # Detect date column
    date_col: str | None = None
    for col in df.columns:
        if col.strip().lower() in ("date", "week", "day", "period", "week_start"):
            date_col = col
            break
    if date_col is None:
        return "No date column found. Expected a column named 'date', 'week', or similar."

    try:
        df[date_col] = pd.to_datetime(df[date_col])
    except Exception as exc:
        return f"Cannot parse date column '{date_col}': {exc}"

    df = df.rename(columns={date_col: "date"})
    df = df.sort_values("date").reset_index(drop=True)

    # All non-date columns are channel spend columns
    channel_cols = [c for c in df.columns if c != "date"]
    if not channel_cols:
        return "No channel columns found after the date column."

    # Validate spend values
    for col in channel_cols:
        try:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        except Exception:
            pass
        negatives = df[col].dropna()
        if (negatives < 0).any():
            return f"Negative spend values found in column '{col}'. Please fix the source data."

    return df


# ---------------------------------------------------------------------------
# Core pacing computation
# ---------------------------------------------------------------------------


def compute_pacing(
    df: pd.DataFrame,
    plan: dict[str, float],
    period_start: date,
    period_end: date,
    today: date,
) -> tuple[dict[str, Any], list[str], list[str]]:
    """Compute pacing metrics for each channel in the plan.

    Args:
        df:           Wide-format DataFrame with 'date' column and channel cols.
        plan:         {channel_name: budget_for_period}.
        period_start: First day of the billing period.
        period_end:   Last day of the billing period.
        today:        Reference date.

    Returns:
        (channel_rows, channels_not_in_data, channels_not_in_plan)
        channel_rows: list of per-channel dicts matching the spec.
        channels_not_in_data: plan channels with no matching data column.
        channels_not_in_plan: data channels absent from the plan.
    """
    total_days = (period_end - period_start).days + 1

    # days_elapsed = days from period_start through yesterday (data available through yesterday)
    # If today IS period_start, days_elapsed = 1 (spec: not 0)
    if today <= period_start:
        days_elapsed = 1
    elif today > period_end:
        days_elapsed = total_days
    else:
        days_elapsed = (today - period_start).days
        days_elapsed = max(1, days_elapsed)

    days_remaining = total_days - days_elapsed
    pct_elapsed = days_elapsed / total_days * 100.0

    # Filter DF to period rows (up to but not including today — "MTD actual")
    period_start_ts = pd.Timestamp(period_start)
    today_ts = pd.Timestamp(today)
    mask = (df["date"] >= period_start_ts) & (df["date"] < today_ts)
    period_df = df[mask]

    data_channels = [c for c in df.columns if c != "date"]
    channels_not_in_plan = [c for c in data_channels if c not in plan]
    channels_not_in_data = [c for c in plan if c not in data_channels]

    channel_rows: list[dict[str, Any]] = []

    for ch_name, budget in plan.items():
        if ch_name in data_channels:
            spent_raw = float(period_df[ch_name].sum()) if not period_df.empty else 0.0
        else:
            spent_raw = 0.0

        spent = round(spent_raw, 2)
        pct_used = round(spent / budget * 100.0, 1) if budget > 0 else 0.0

        # Projection: linear extrapolation from run-rate
        if pct_elapsed > 0:
            projected_end = round(spent / (pct_elapsed / 100.0), 0)
        else:
            projected_end = 0.0

        variance = round(projected_end - budget, 0)
        variance_pct = round((projected_end - budget) / budget * 100.0, 1) if budget > 0 else 0.0

        # days_elapsed is the number of data-days we actually have (same for all channels)
        actual_data_days = max(days_elapsed, 1)
        current_daily_avg = round(spent / actual_data_days, 0)

        required_daily = round((budget - spent) / days_remaining, 0) if days_remaining > 0 else 0.0

        status = _classify_status(variance_pct / 100.0)

        channel_rows.append(
            {
                "name": ch_name,
                "budget": budget,
                "spent": spent,
                "pct_used": pct_used,
                "projected_end": projected_end,
                "variance": variance,
                "variance_pct": variance_pct,
                "current_daily_avg": current_daily_avg,
                "required_daily_to_hit_plan": required_daily,
                "status": status,
            }
        )

    # Sort by abs(variance) descending
    channel_rows.sort(key=lambda c: abs(c["variance"]), reverse=True)

    return channel_rows, channels_not_in_data, channels_not_in_plan


# ---------------------------------------------------------------------------
# Memo renderer
# ---------------------------------------------------------------------------


def _fmt_signed_dollars(value: float) -> str:
    """Return e.g. '+$12,000' or '\u2212$7,357'."""
    minus = "\u2212"
    if value >= 0:
        return f"+{fmt_dollars(value)}"
    return f"{minus}{fmt_dollars(abs(value))}"


def _status_label(status: str) -> str:
    return {"under": "Under", "on_track": "On Track", "over": "Over"}.get(status, status.title())


def render_pacing_memo(result: dict) -> str:
    """Render the pacing analyst memo from a pacing result dict.

    Returns markdown string, or "" if critical fields are missing (never raises).
    """
    try:
        return _render(result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_pacing_memo failed: %s", exc, exc_info=True)
        return ""


def _render(result: dict) -> str:
    """Internal render — may raise; caller wraps in try/except."""
    if not result:
        return ""

    days_elapsed: int = result.get("days_elapsed", 0)
    days_total: int = result.get("days_total", 1)
    total: dict = result.get("total", {})
    channels: list[dict] = result.get("channels", [])
    footnotes: list[str] = result.get("_memo_footnotes", [])
    period_closed: bool = result.get("_period_closed", False)

    total_budget = total.get("budget", 0)
    total_spent = total.get("spent", 0)
    total_pct = total.get("pct_used", 0.0)
    total_proj = total.get("projected_end", 0)
    total_var = total.get("variance", 0)
    total_var_pct = total.get("variance_pct", 0.0)
    total_status = total.get("status", "on_track")

    sections: list[str] = []

    # --- Opening verdict ---
    spent_k = f"${total_spent / 1000:.0f}k" if total_spent < 1_000_000 else fmt_dollars(total_spent)
    budget_k = (
        f"${total_budget / 1000:.0f}k" if total_budget < 1_000_000 else fmt_dollars(total_budget)
    )

    header = f"## You are day {days_elapsed} of {days_total}, {spent_k} of {budget_k} planned"
    sections.append(header)

    if period_closed:
        verdict_para = (
            "**Period closed; actuals final.** "
            f"Final spend: {fmt_dollars(total_spent)} of {fmt_dollars(total_budget)} "
            f"planned ({total_pct:.0f}%)."
        )
    else:
        if total_status == "under":
            var_abs_pct = abs(total_var_pct)
            proj_k = (
                f"${total_proj / 1000:.0f}k" if total_proj < 1_000_000 else fmt_dollars(total_proj)
            )
            var_k = (
                f"${abs(total_var) / 1000:.0f}k"
                if abs(total_var) < 1_000_000
                else fmt_dollars(abs(total_var))
            )
            verdict_para = (
                f"**Under-pacing by {var_abs_pct:.0f}%.** "
                f"At current run-rate, you'll land at {proj_k} — "
                f"{var_k} short of plan."
            )
            # Suggest the two largest under-pacing channels
            under_channels = [
                c
                for c in channels
                if c["status"] == "under"
                and c["current_daily_avg"] < c["required_daily_to_hit_plan"]
            ]
            if under_channels:
                suggestions = []
                for c in under_channels[:2]:
                    suggestions.append(
                        f"{c['name']} needs {fmt_dollars(c['required_daily_to_hit_plan'])}/day "
                        f"(currently {fmt_dollars(c['current_daily_avg'])})"
                    )
                verdict_para += " To close the gap, " + " and ".join(suggestions) + "."
        elif total_status == "over":
            var_abs_pct = abs(total_var_pct)
            proj_k = (
                f"${total_proj / 1000:.0f}k" if total_proj < 1_000_000 else fmt_dollars(total_proj)
            )
            var_k = (
                f"${abs(total_var) / 1000:.0f}k"
                if abs(total_var) < 1_000_000
                else fmt_dollars(abs(total_var))
            )
            verdict_para = (
                f"**Over-pacing by {var_abs_pct:.0f}%.** "
                f"At current run-rate, you'll land at {proj_k} — "
                f"{var_k} over plan."
            )
        else:
            verdict_para = (
                f"**On track.** "
                f"At {total_pct:.0f}% of budget used with {days_elapsed / days_total * 100:.0f}% "
                "of the period elapsed — pacing within the ±5% band."
            )

    sections.append(verdict_para)

    # --- Pacing table ---
    pacing_lines: list[str] = [
        "| Channel | Budget | Spent | % | Projected | Variance | Status |",
        "|---------|-------:|------:|--:|----------:|---------:|--------|",
    ]

    for ch in channels:
        var_signed = _fmt_signed_dollars(ch["variance"])
        pacing_lines.append(
            f"| {ch['name']} "
            f"| {fmt_dollars(ch['budget'])} "
            f"| {fmt_dollars(ch['spent'])} "
            f"| {ch['pct_used']:.0f}% "
            f"| {fmt_dollars(ch['projected_end'])} "
            f"| {var_signed} "
            f"| {_status_label(ch['status'])} |"
        )

    # Total row
    total_var_signed = _fmt_signed_dollars(total_var)
    pacing_lines.append(
        f"| **Total** "
        f"| {fmt_dollars(total_budget)} "
        f"| {fmt_dollars(total_spent)} "
        f"| {total_pct:.0f}% "
        f"| {fmt_dollars(total_proj)} "
        f"| {total_var_signed} "
        f"| {_status_label(total_status)} |"
    )

    sections.append("\n".join(pacing_lines))

    # --- Adjustment table (only when period is open) ---
    if not period_closed:
        adjust_lines: list[str] = [
            "### To land on plan",
            "",
            "| Channel | Current daily | Required daily | Adjustment |",
            "|---------|--------------|----------------|------------|",
        ]
        for ch in channels:
            adj = ch["required_daily_to_hit_plan"] - ch["current_daily_avg"]
            adj_str = _fmt_signed_dollars(adj) + "/day"
            adjust_lines.append(
                f"| {ch['name']} "
                f"| {fmt_dollars(ch['current_daily_avg'])} "
                f"| {fmt_dollars(ch['required_daily_to_hit_plan'])} "
                f"| {adj_str} |"
            )

        sections.append("\n".join(adjust_lines))

    # --- Footnotes ---
    if footnotes:
        sections.append("\n\n".join(f"*{note}*" for note in footnotes))

    return "\n\n".join(sections)


# ---------------------------------------------------------------------------
# Public entry point: build full pacing result dict
# ---------------------------------------------------------------------------


def build_pacing_result(
    csv_path: str,
    plan: dict[str, float] | None,
    plan_period: str,
    today_str: str | None,
) -> dict[str, Any]:
    """Build the full pacing result dict from inputs.

    Returns either a result dict (with 'tool' key) or an error dict
    (with 'status': 'error').
    """
    # --- Validate plan_period ---
    if plan_period not in _VALID_PERIODS:
        return {
            "status": "error",
            "message": (
                f"Invalid plan_period '{plan_period}'. Valid options: {list(_VALID_PERIODS)}."
            ),
        }

    # --- Validate plan ---
    if plan is None or len(plan) == 0:
        return {
            "status": "error",
            "message": "Plan required. Pass {channel: monthly_budget} as `plan`.",
        }

    # --- Parse today ---
    if today_str is not None:
        parsed_today = _parse_today(today_str)
        if parsed_today is None:
            return {
                "status": "error",
                "message": f"Invalid date '{today_str}'. Expected ISO format YYYY-MM-DD.",
            }
    else:
        parsed_today = date.today()

    # --- Load CSV ---
    df_or_err = _load_spend_df(csv_path)
    if isinstance(df_or_err, str):
        return {"status": "error", "message": df_or_err}

    df: pd.DataFrame = df_or_err

    # Check for negative spend (redundant with _load_spend_df but explicit)
    channel_cols = [c for c in df.columns if c != "date"]
    for col in channel_cols:
        if (df[col].dropna() < 0).any():
            return {
                "status": "error",
                "message": (
                    f"Negative spend values found in column '{col}'. Please fix the source data."
                ),
            }

    # --- Period bounds ---
    # Use the data's last date to anchor the period when today is far ahead of the data.
    data_min = df["date"].min().date()
    data_max = df["date"].max().date()

    memo_footnotes: list[str] = []

    # Anchor period to the data's last date if today precedes or is far past data range
    anchor_date = parsed_today
    if data_max < _period_bounds(parsed_today, plan_period)[0]:
        # Today's period doesn't overlap data at all — anchor to data's last date
        memo_footnotes.append(
            f"Note: today ({parsed_today.isoformat()}) is outside the data range "
            f"({data_min.isoformat()} to {data_max.isoformat()}). "
            "Showing pacing based on latest available data date."
        )
        anchor_date = data_max

    period_start, period_end = _period_bounds(anchor_date, plan_period)

    # Determine if the period is closed (today is after the period ends)
    if parsed_today > period_end:
        period_closed = True
        effective_today = period_end + timedelta(days=1)  # fully elapsed
    else:
        period_closed = False
        effective_today = parsed_today

    # --- Calendar math ---
    total_days = (period_end - period_start).days + 1

    if period_closed:
        days_elapsed = total_days
    elif effective_today <= period_start:
        days_elapsed = 1
    else:
        days_elapsed = (effective_today - period_start).days
        days_elapsed = max(1, min(days_elapsed, total_days))

    days_remaining = total_days - days_elapsed
    pct_elapsed = round(days_elapsed / total_days * 100.0, 1)

    # --- Compute channel pacing ---
    channel_rows, channels_not_in_data, channels_not_in_plan = compute_pacing(
        df,
        plan,
        period_start,
        period_end,
        effective_today,
    )

    # --- Footnotes for missing channels ---
    if channels_not_in_data:
        joined = ", ".join(channels_not_in_data)
        memo_footnotes.append(f"Channels in plan but not in data (shown with $0 spend): {joined}.")

    if channels_not_in_plan:
        joined = ", ".join(channels_not_in_plan)
        memo_footnotes.append(
            f"Channels in data but not in plan (excluded from pacing table): {joined}."
        )

    # --- Totals ---
    total_budget = sum(plan.values())
    total_spent = sum(c["spent"] for c in channel_rows)
    total_pct_used = round(total_spent / total_budget * 100.0, 1) if total_budget > 0 else 0.0
    total_projected = round(total_spent / (pct_elapsed / 100.0), 0) if pct_elapsed > 0 else 0.0
    total_variance = round(total_projected - total_budget, 0)
    if total_budget > 0:
        total_variance_pct = round((total_projected - total_budget) / total_budget * 100.0, 1)
    else:
        total_variance_pct = 0.0
    total_status = _classify_status(total_variance_pct / 100.0)

    total_dict: dict[str, Any] = {
        "budget": total_budget,
        "spent": total_spent,
        "pct_used": total_pct_used,
        "projected_end": total_projected,
        "variance": total_variance,
        "variance_pct": total_variance_pct,
        "status": total_status,
    }

    # --- Period label ---
    label = _period_label(parsed_today, plan_period, period_start, period_end)

    result: dict[str, Any] = {
        "tool": "mixlift_pacing",
        "version": _VERSION,
        "plan_period": plan_period,
        "period_label": label,
        "today": parsed_today.isoformat(),
        "days_elapsed": days_elapsed,
        "days_total": total_days,
        "days_remaining": days_remaining,
        "pct_elapsed": pct_elapsed,
        "total": total_dict,
        "channels": channel_rows,
        "_memo_footnotes": memo_footnotes,
        "_period_closed": period_closed,
    }

    # --- Render memo ---
    try:
        result["memo_markdown"] = render_pacing_memo(result)
    except Exception as exc:
        logger.warning("render_pacing_memo failed: %s", exc)
        result["memo_markdown"] = ""

    return result
