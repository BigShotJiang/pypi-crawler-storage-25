"""Saturation-curve analyst-memo renderer for MixLift.

Pure stdlib only — no numpy, pandas, or jinja.
Receives pre-computed dicts from extract_saturation_curves /
extract_marginal_roas; never fits a model.
"""

from __future__ import annotations

import bisect
import logging
from typing import Any

from mixlift_mcp.renderers._helpers import (
    channel_display_name,
    fmt_dollars,
    fmt_roas,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Status thresholds (spec §Behavior)
# ---------------------------------------------------------------------------

_STATUS_BINS: list[tuple[float, str]] = [
    (50.0, "room_to_scale"),
    (90.0, "approaching"),
    (110.0, "at_frontier"),
    (float("inf"), "over_saturated"),
]

_STATUS_LABELS: dict[str, str] = {
    "room_to_scale": "Push hard",
    "approaching": "Approaching ceiling",
    "at_frontier": "At efficient frontier",
    "over_saturated": "Cut or hold",
}


def _classify_status(saturation_pct: float) -> str:
    for threshold, status in _STATUS_BINS:
        if saturation_pct < threshold:
            return status
    return "over_saturated"


# ---------------------------------------------------------------------------
# Curve math helpers
# ---------------------------------------------------------------------------


def _interpolate_response(
    spend_points: list[float],
    response_points: list[float],
    query_spend: float,
) -> float:
    """Linear interpolation of response at query_spend from curve points."""
    if not spend_points:
        return 0.0
    if query_spend <= spend_points[0]:
        return response_points[0]
    if query_spend >= spend_points[-1]:
        return response_points[-1]

    idx = bisect.bisect_left(spend_points, query_spend)
    x0, x1 = spend_points[idx - 1], spend_points[idx]
    y0, y1 = response_points[idx - 1], response_points[idx]
    t = (query_spend - x0) / (x1 - x0) if x1 != x0 else 0.0
    return y0 + t * (y1 - y0)


def _find_frontier_spend(
    spend_points: list[float],
    response_points: list[float],
) -> float | None:
    """Return the spend at which marginal ROAS first drops below 1.0×.

    Marginal ROAS at point i = (response[i] - response[i-1]) /
                                (spend[i] - spend[i-1]).

    Returns None when the curve never drops below 1.0 within the supplied
    range (i.e. up to 2× training_max_spend). The caller should treat None
    as an extrapolated frontier and use spend_points[-1] as a lower-bound
    fallback — not curve_end / 2.
    """
    for i in range(1, len(spend_points)):
        delta_spend = spend_points[i] - spend_points[i - 1]
        delta_response = response_points[i] - response_points[i - 1]
        if delta_spend <= 0:
            continue
        marginal = delta_response / delta_spend
        if marginal < 1.0:
            # Interpolate: find the spend where marginal == 1.0 linearly
            # between (spend[i-1], marginal_prev) and (spend[i], marginal)
            # For simplicity return the midpoint of the crossing segment.
            return (spend_points[i - 1] + spend_points[i]) / 2.0
    return None


def _compute_next_dollar_returns(
    current_spend: float,
    spend_points: list[float],
    response_points: list[float],
    steps: list[int],
) -> dict[str, dict[str, float]]:
    """Compute revenue lift and ROAS for each increment step."""
    base_response = _interpolate_response(spend_points, response_points, current_spend)
    result: dict[str, dict[str, float]] = {}
    for step in steps:
        new_spend = current_spend + step
        new_response = _interpolate_response(spend_points, response_points, new_spend)
        lift = new_response - base_response
        roas = lift / step if step > 0 else 0.0
        result[str(step)] = {
            "revenue_lift": round(lift, 0),
            "roas": round(roas, 2),
        }
    return result


def _compute_if_decrease_returns(
    current_spend: float,
    spend_points: list[float],
    response_points: list[float],
    steps: list[int],
) -> dict[str, dict[str, float]]:
    """Compute revenue kept and cost of cut for each decrement step."""
    base_response = _interpolate_response(spend_points, response_points, current_spend)
    result: dict[str, dict[str, float]] = {}
    for step in steps:
        new_spend = max(0.0, current_spend - step)
        new_response = _interpolate_response(spend_points, response_points, new_spend)
        revenue_lost = base_response - new_response
        revenue_kept = step - revenue_lost  # spend saved minus revenue lost
        result[f"-{step}"] = {
            "revenue_kept": round(revenue_kept, 0),
            "cost_of_cut": round(-revenue_lost, 0),
        }
    return result


# ---------------------------------------------------------------------------
# Per-channel data builder
# ---------------------------------------------------------------------------


def build_channel_saturation(
    channel_raw: str,
    current_spend_wk: float,
    curve: dict[str, list[float]],
    marginal_roas_mean: float,
    marginal_roas_ci: tuple[float, float],
    increment_steps: list[int],
    training_max_spend: float,
) -> dict[str, Any]:
    """Build the per-channel saturation dict matching the spec output shape.

    Args:
        channel_raw: Raw column name (e.g. ``"meta_spend"``).
        current_spend_wk: Average weekly spend for this channel.
        curve: ``{"spend": [...], "response": [...]}`` from extract_saturation_curves.
        marginal_roas_mean: Point estimate of marginal ROAS at current spend.
        marginal_roas_ci: (low, high) credible interval.
        increment_steps: Dollar increment steps for next_dollar_returns.
        training_max_spend: Max spend seen in training data (for extrapolation flag).

    Returns:
        Channel dict matching the spec output structure.
    """
    display = channel_display_name(channel_raw)
    spend_points: list[float] = curve.get("spend", [])
    response_points: list[float] = curve.get("response", [])

    frontier = _find_frontier_spend(spend_points, response_points)
    if frontier is None or frontier <= 0:
        # Never crosses 1× — use the end of the curve as ceiling
        frontier = spend_points[-1] if spend_points else max(current_spend_wk * 2, 1.0)

    saturation_pct_raw = (current_spend_wk / frontier) * 100.0 if frontier > 0 else 0.0
    saturation_pct = round(saturation_pct_raw, 1)
    status = _classify_status(saturation_pct)

    # Flags
    extrapolated = current_spend_wk > training_max_spend * 1.05
    low_confidence = current_spend_wk < 100.0

    next_dollar_returns = _compute_next_dollar_returns(
        current_spend_wk, spend_points, response_points, increment_steps
    )

    # Always emit both decrease keys; mark infeasible cuts as not_applicable
    if_decrease_returns: dict[str, dict] = {}
    for step in increment_steps:
        key = f"-{step}"
        if step >= current_spend_wk:
            if_decrease_returns[key] = {
                "revenue_kept": None,
                "cost_of_cut": None,
                "not_applicable": True,
                "reason": "cut exceeds current spend",
            }
        else:
            new_spend = max(0.0, current_spend_wk - step)
            base_response = _interpolate_response(spend_points, response_points, current_spend_wk)
            new_response = _interpolate_response(spend_points, response_points, new_spend)
            revenue_lost = base_response - new_response
            revenue_kept = step - revenue_lost
            if_decrease_returns[key] = {
                "revenue_kept": round(revenue_kept, 0),
                "cost_of_cut": round(-revenue_lost, 0),
                "not_applicable": False,
            }

    # Cap curve points at 2× training_max_spend (spec §Behavior)
    cap = 2.0 * training_max_spend
    curve_points = [
        {"spend": round(s, 2), "response": round(r, 4)}
        for s, r in zip(spend_points, response_points)
        if s <= cap + 1e-6  # +epsilon for float comparison
    ]

    # extrapolated_frontier: True when frontier was a fallback (MROAS never crossed 1×)
    frontier_raw = _find_frontier_spend(spend_points, response_points)
    extrapolated_frontier = frontier_raw is None or frontier_raw <= 0

    return {
        "name": display,
        "current_spend_wk": round(current_spend_wk, 0),
        "saturation_pct": saturation_pct,
        "status": status,
        "marginal_roas_current": round(marginal_roas_mean, 2),
        "marginal_roas_ci": [round(marginal_roas_ci[0], 2), round(marginal_roas_ci[1], 2)],
        "efficient_frontier_spend": round(frontier, 0),
        "next_dollar_returns": next_dollar_returns,
        "if_decrease_returns": if_decrease_returns,
        "curve_points": curve_points,
        "extrapolated": extrapolated,
        "extrapolated_frontier": extrapolated_frontier,
        "low_confidence": low_confidence,
    }


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def render_saturation_memo(saturation_result: dict) -> str:
    """Render the saturation analyst memo from a mixlift_saturation result dict.

    Returns markdown string, or "" if critical fields are missing (never raises).
    """
    try:
        return _render(saturation_result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_saturation_memo failed: %s", exc, exc_info=True)
        return ""


# ---------------------------------------------------------------------------
# Section renderers
# ---------------------------------------------------------------------------


def _section_header(result: dict) -> str:
    """Return the H2 section header."""
    return "## Where each channel sits on its curve"


def _section_diagnosis(channels: list[dict]) -> str:
    """Two-paragraph opening: most-saturated and most-underfunded channel."""
    active = [ch for ch in channels if ch.get("current_spend_wk", 0) > 0]
    if not active:
        return ""

    # Most saturated
    most_saturated = max(active, key=lambda c: c["saturation_pct"])
    # Most underfunded (lowest saturation pct)
    least_saturated = min(active, key=lambda c: c["saturation_pct"])

    paras: list[str] = []

    # Paragraph 1: most saturated
    ms_name = most_saturated["name"]
    ms_spend = fmt_dollars(most_saturated["current_spend_wk"])
    ms_pct = round(most_saturated["saturation_pct"])
    ms_status = most_saturated["status"]

    if ms_status == "over_saturated":
        verdict = f"**{ms_name} is over the top.**"
    elif ms_status == "at_frontier":
        verdict = f"**{ms_name} is at the efficient frontier.**"
    else:
        verdict = f"**{ms_name} is the most saturated channel.**"

    ms_5k_roas: float | None = None
    ndr = most_saturated.get("next_dollar_returns", {})
    if "5000" in ndr:
        ms_5k_roas = ndr["5000"].get("roas")
    elif ndr:
        first_key = next(iter(ndr))
        ms_5k_roas = ndr[first_key].get("roas")

    idr = most_saturated.get("if_decrease_returns", {})
    ms_cut_revenue: float | None = None
    ms_cut_label: str | None = None
    # Only show cut info for feasible (not_applicable=False) entries
    for _cut_key in ["-5000", "-1000"]:
        _entry = idr.get(_cut_key)
        if _entry and not _entry.get("not_applicable", True):
            ms_cut_revenue = abs(_entry.get("cost_of_cut", 0) or 0)
            ms_cut_label = _cut_key.replace("-", "$")
            break

    # Branch diagnosis copy on saturation level
    if ms_pct > 110:
        _frontier_phrase = f"you are {ms_pct - 100}% **past** the efficient frontier"
    elif ms_pct >= 90:
        _frontier_phrase = "you are **at** the efficient frontier"
    else:
        _frontier_phrase = f"you are {ms_pct}% **of the way to** the efficient frontier"

    para1_parts = [f"{verdict} At {ms_spend}/wk {_frontier_phrase}."]
    if ms_5k_roas is not None:
        para1_parts.append(f"The next $5k here earns a {fmt_roas(ms_5k_roas)} ROAS.")
    if ms_cut_revenue is not None and ms_cut_label:
        para1_parts.append(f"Cutting {ms_cut_label} loses only {fmt_dollars(ms_cut_revenue)}.")

    paras.append(" ".join(para1_parts))

    # Paragraph 2: least saturated (only if different channel)
    if least_saturated["name"] != most_saturated["name"]:
        ls_name = least_saturated["name"]
        ls_spend = fmt_dollars(least_saturated["current_spend_wk"])
        ls_pct = round(least_saturated["saturation_pct"])
        ls_status = least_saturated["status"]

        if ls_status == "room_to_scale":
            ls_verdict = f"**{ls_name} is nowhere near the top.**"
        else:
            ls_verdict = f"**{ls_name} has significant headroom.**"

        ls_5k: float | None = None
        ls_ndr = least_saturated.get("next_dollar_returns", {})
        if "5000" in ls_ndr:
            ls_5k = ls_ndr["5000"].get("roas")

        para2_parts = [f"{ls_verdict} At {ls_spend}/wk you are {ls_pct}% of the way up the curve."]
        if ls_5k is not None:
            para2_parts.append(f"The next $5k earns a {fmt_roas(ls_5k)} marginal ROAS.")
        if ls_pct < 30:
            para2_parts.append("Incremental spend compounds for multiple brackets from here.")

        paras.append(" ".join(para2_parts))

    return "\n\n".join(paras)


def _section_comparison_table(channels: list[dict]) -> str:
    """Comparison table sorted by saturation descending. Omitted for single channel."""
    active = [ch for ch in channels if ch.get("current_spend_wk", 0) > 0]
    if len(active) <= 1:
        return ""

    sorted_channels = sorted(active, key=lambda c: c["saturation_pct"], reverse=True)

    lines: list[str] = [
        "### By channel — what the next $5k earns",
        "",
        "| Channel | Current | Saturation | Next $5k ROAS | Verdict |",
        "|:--------|--------:|-----------:|:--------------|:--------|",
    ]

    for ch in sorted_channels:
        name = ch["name"]
        spend = fmt_dollars(ch["current_spend_wk"])
        sat_pct = f"{round(ch['saturation_pct'])}%"
        verdict = _STATUS_LABELS.get(ch["status"], ch["status"])

        ndr = ch.get("next_dollar_returns", {})
        if "5000" in ndr:
            roas_5k = ndr["5000"].get("roas")
            roas_cell = fmt_roas(roas_5k)
        elif ndr:
            first_key = next(iter(ndr))
            roas_5k = ndr[first_key].get("roas")
            roas_cell = fmt_roas(roas_5k) + f" (next ${first_key})"
        else:
            roas_cell = "\u2014"

        if ch.get("low_confidence"):
            name = f"{name}*"
        if ch.get("extrapolated"):
            name = f"{name}\u2020"

        lines.append(f"| {name} | {spend} | {sat_pct} | {roas_cell} | {verdict} |")

    return "\n".join(lines)


def _section_per_channel(ch: dict, increment_steps: list[int]) -> str:
    """Per-channel detail section with increment and decrease tables."""
    name = ch["name"]
    spend = fmt_dollars(ch["current_spend_wk"])
    sat_pct = f"{round(ch['saturation_pct'])}%"
    mroas = fmt_roas(ch["marginal_roas_current"])
    ci_lo = fmt_roas(ch["marginal_roas_ci"][0])
    ci_hi = fmt_roas(ch["marginal_roas_ci"][1])
    status_label = _STATUS_LABELS.get(ch["status"], ch["status"])

    flag_note = ""
    if ch.get("extrapolated"):
        flag_note += "\u2020"
    if ch.get("low_confidence"):
        flag_note += "*"

    lines: list[str] = [
        f"### {name}{flag_note} \u2014 {status_label.lower()}",
        f"Current: {spend}/wk \u00b7 Saturation: {sat_pct} \u00b7 "
        f"Marginal ROAS: {mroas} ({ci_lo}\u2013{ci_hi} CI)",
        "",
    ]

    # Increment table
    ndr = ch.get("next_dollar_returns", {})
    if ndr:
        lines += [
            "| If you add | Revenue lift | ROAS |",
            "|:-----------|-------------:|-----:|",
        ]
        for step_key in sorted(ndr.keys(), key=lambda k: int(k)):
            step_int = int(step_key)
            lift = ndr[step_key]["revenue_lift"]
            roas_val = ndr[step_key]["roas"]
            lines.append(
                f"| +{fmt_dollars(step_int)} | {fmt_dollars(lift)} | {fmt_roas(roas_val)} |"
            )
        lines.append("")

    # Decrease table — omit rows where not_applicable (infeasible cuts)
    idr = ch.get("if_decrease_returns", {})
    feasible_idr = {k: v for k, v in idr.items() if not v.get("not_applicable", True)}
    if feasible_idr:
        lines += [
            "| If you cut | Revenue lost | Net if cut |",
            "|:-----------|-------------:|:-----------|",
        ]
        for step_key in sorted(feasible_idr.keys(), key=lambda k: int(k[1:])):
            step_int = int(step_key[1:])
            revenue_lost = abs(feasible_idr[step_key]["cost_of_cut"])
            # Net if cut = spend_saved - revenue_lost
            # Positive = cut is net-positive P&L; negative = cut loses more than saves
            net = step_int - revenue_lost
            if net >= 0:
                net_cell = f"+{fmt_dollars(net)}"
            else:
                net_cell = f"\u2212{fmt_dollars(abs(net))}"
            lines.append(
                f"| \u2212{fmt_dollars(step_int)} | {fmt_dollars(revenue_lost)} | {net_cell} |"
            )

    # Strip trailing blank lines so sections with no decrease table don't emit extra whitespace
    return "\n".join(lines).rstrip()


def _section_footnotes(
    channels: list[dict],
    skipped: list[str],
) -> str:
    """Return footnotes for low-confidence, extrapolated, zero-spend, and skipped channels.

    Args:
        channels: Per-channel dicts already built.
        skipped: Raw column names of channels requested but absent from the fit
            (e.g. ``["podcast_spend"]``). Displayed verbatim so users can cross-check
            against their CSV header row.
    """
    notes: list[str] = []

    low_conf = [ch["name"] for ch in channels if ch.get("low_confidence")]
    extrapolated = [ch["name"] for ch in channels if ch.get("extrapolated")]
    zero_spend = [ch["name"] for ch in channels if ch.get("current_spend_wk", 0) == 0]

    if low_conf:
        joined = ", ".join(low_conf)
        notes.append(
            f"\\* {joined}: spend < $100/wk — marginal ROAS values reported but "
            "confidence is low; prior assumptions dominate at this spend level."
        )
    if extrapolated:
        joined = ", ".join(extrapolated)
        notes.append(
            f"\u2020 {joined}: current spend exceeds training range — "
            "curve is extrapolated beyond observed data; treat as directional only."
        )
    if zero_spend:
        joined = ", ".join(zero_spend)
        notes.append(
            f"{joined}: zero spend this period — curve data included in structured "
            "output but excluded from memo."
        )
    if skipped:
        joined = ", ".join(skipped)
        notes.append(
            f"Requested but not found in fit: {joined}. "
            "These channels were skipped — check column names in your CSV."
        )

    if not notes:
        return ""
    return "\n\n".join(f"*{n}*" for n in notes)


def _section_footer(result: dict) -> str:
    """Return the italic footer line."""
    data_window = result.get("data_window", "")
    mcmc_config = result.get("mcmc_config", {})

    if isinstance(mcmc_config, dict):
        chains = mcmc_config.get("chains")
        draws = mcmc_config.get("draws")
        if chains and draws:
            posterior_str = f"Posterior: {chains} chains \u00d7 {draws} draws"
        else:
            posterior_str = "Posterior converged."
    else:
        posterior_str = "Posterior converged."

    window_str = f"Data window: {data_window}." if data_window else ""
    parts = [p for p in [window_str, posterior_str] if p]
    return f"*{' '.join(parts)}*"


# ---------------------------------------------------------------------------
# Main render
# ---------------------------------------------------------------------------


def _render(result: dict) -> str:
    """Internal render — may raise; caller wraps in try/except."""
    if not result:
        return ""

    channels_data: list[dict] = result.get("channels", [])
    if not channels_data:
        return ""

    # Separate zero-spend channels from active ones
    active = [ch for ch in channels_data if ch.get("current_spend_wk", 0) > 0]
    skipped: list[str] = result.get("_skipped_channels", [])

    # Collect increment steps from the first channel's next_dollar_returns keys
    increment_steps: list[int] = []
    if active and active[0].get("next_dollar_returns"):
        increment_steps = sorted(int(k) for k in active[0]["next_dollar_returns"].keys())

    sections: list[str] = []

    # 1. H2 header
    sections.append(_section_header(result))

    # 2. Two-paragraph diagnosis (most/least saturated)
    diagnosis = _section_diagnosis(channels_data)
    if diagnosis:
        sections.append(diagnosis)

    # 3. Comparison table (omit for single channel)
    if len(active) > 1:
        table = _section_comparison_table(channels_data)
        if table:
            sections.append(table)

    # 4. Per-channel sections (active only; zero-spend noted in footnotes)
    for ch in sorted(active, key=lambda c: c["saturation_pct"], reverse=True):
        sections.append(_section_per_channel(ch, increment_steps))

    # 5. Footnotes
    footnotes = _section_footnotes(channels_data, skipped)
    if footnotes:
        sections.append(footnotes)

    # 6. Footer
    sections.append(_section_footer(result))

    return "\n\n".join(sections)
