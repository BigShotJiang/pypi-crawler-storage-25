"""Week-over-week revenue delta analyst-memo renderer for MixLift.

Pure stdlib only — no numpy, pandas, or jinja.
Receives a pre-computed wow result dict from build_wow_result (called by server.py);
never fits a model.
"""

from __future__ import annotations

import logging
from typing import Any

from mixlift_mcp.renderers._helpers import (
    fmt_dollars,
    fmt_pct,
    fmt_roas,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Period constants
# ---------------------------------------------------------------------------

VALID_PERIODS: tuple[str, ...] = ("week", "4_weeks", "quarter")

_PERIOD_WEEKS: dict[str, int] = {
    "week": 1,
    "4_weeks": 4,
    "quarter": 13,
}

_PERIOD_DISPLAY: dict[str, str] = {
    "week": "Last week",
    "4_weeks": "Last 4 weeks",
    "quarter": "Last quarter",
}

# How many data weeks are required for each period (2× the period length).
_PERIOD_MIN_WEEKS: dict[str, int] = {
    "week": 2,
    "4_weeks": 8,
    "quarter": 26,
}


# ---------------------------------------------------------------------------
# Public entry point (renderer)
# ---------------------------------------------------------------------------


def render_wow_memo(wow_result: dict) -> str:
    """Render the WoW analyst memo from a mixlift_wow result dict.

    Returns markdown string, or "" if critical fields are missing (never raises).
    """
    try:
        return _render(wow_result)
    except Exception as exc:  # noqa: BLE001
        logger.warning("render_wow_memo failed: %s", exc, exc_info=True)
        return ""


# ---------------------------------------------------------------------------
# Section renderers
# ---------------------------------------------------------------------------


def _section_verdict(result: dict) -> str:
    """Opening verdict paragraph: headline + primary driver."""
    delta = result.get("delta", 0.0)
    period_label = result.get("period_label", "")
    channels = result.get("channels", [])

    # Extract period description (e.g. "Last week") from the compound label
    # "Last week (2026-04-07 to 2026-04-14) vs prior (2026-03-31 to 2026-04-06)"
    period_phrase = period_label.split(" (")[0] if period_label else "This period"

    current_rev = result.get("current_revenue", 0.0)
    prior_rev = result.get("prior_revenue", 0.0)
    delta_pct = result.get("delta_pct", 0.0)

    abs_delta = abs(delta)

    if abs(delta) < 1:
        direction = "flat"
        headline = f"## Revenue flat {period_phrase.lower()}"
    elif delta > 0:
        direction = "up"
        headline = f"## Revenue was {fmt_dollars(abs_delta)} up {period_phrase.lower()}"
    else:
        direction = "down"
        headline = f"## Revenue was {fmt_dollars(abs_delta)} down {period_phrase.lower()}"

    summary_line = (
        f"{fmt_dollars(current_rev)} this period vs {fmt_dollars(prior_rev)} prior "
        f"({fmt_pct(delta_pct, precision=1)} change)."
    )

    paras = [headline, "", summary_line]

    # Primary driver: channel with largest abs(delta)
    active = [ch for ch in channels if abs(ch.get("delta", 0.0)) > 0]
    if active:
        top = max(active, key=lambda c: abs(c.get("delta", 0.0)))
        name = top["name"]
        ch_delta = top.get("delta", 0.0)
        contrib_current = top.get("contribution_current", 0.0)
        contrib_prior = top.get("contribution_prior", 0.0)
        spend_delta = top.get("spend_delta", 0.0)
        eff_effect = top.get("efficiency_effect", 0.0)
        mroas_curr = top.get("marginal_roas_current")
        mroas_prior = top.get("marginal_roas_prior")

        if direction != "flat":
            if ch_delta < 0:
                driver_verb = "drove the drop" if direction == "down" else "partially offset gains"
            else:
                driver_verb = "drove the gain" if direction == "up" else "partially offset losses"

            _contrib_curr_fmt = fmt_dollars(contrib_current)
            _contrib_prior_fmt = fmt_dollars(contrib_prior)
            _delta_fmt = fmt_dollars(abs(ch_delta))
            if ch_delta < 0:
                driver_line = (
                    f"**{name} {driver_verb}.** "
                    f"Contribution fell from {_contrib_prior_fmt} to {_contrib_curr_fmt} "
                    f"({_delta_fmt})."
                )
            else:
                driver_line = (
                    f"**{name} {driver_verb}.** "
                    f"Contribution rose from {_contrib_prior_fmt} to {_contrib_curr_fmt} "
                    f"(+{_delta_fmt})."
                )

            # Append spend/efficiency context when meaningful
            if top.get("zero_spend_period"):
                driver_line += " (Zero spend in one period — efficiency effect not applicable.)"
            elif mroas_curr is not None and mroas_prior is not None and spend_delta != 0:
                roas_pct_change = (
                    (mroas_curr - mroas_prior) / mroas_prior * 100 if mroas_prior != 0 else 0.0
                )
                spend_direction = "more" if spend_delta > 0 else "less"
                eff_direction = "fell" if eff_effect < 0 else "rose"
                _mroas_curr_fmt = fmt_roas(mroas_curr)
                _mroas_prior_fmt = fmt_roas(mroas_prior)
                driver_line += (
                    f"\nYou spent {fmt_dollars(abs(spend_delta))} {spend_direction} there "
                    f"but efficiency {eff_direction} from {_mroas_prior_fmt}"
                    f" to {_mroas_curr_fmt} "
                    f"— a {fmt_pct(roas_pct_change, precision=0)} marginal-ROAS change "
                    f"representing {fmt_dollars(abs(eff_effect))} in "
                    f"{'lost' if eff_effect < 0 else 'gained'} revenue."
                )
            paras.append(driver_line)

    return "\n".join(paras)


def _section_delta_table(result: dict) -> str:
    """Delta table: Total, Baseline, Paid, per-channel rows."""
    current_rev = result.get("current_revenue", 0.0)
    prior_rev = result.get("prior_revenue", 0.0)
    delta = result.get("delta", 0.0)

    baseline = result.get("baseline", {})
    paid_total = result.get("paid_total", {})
    channels = result.get("channels", [])

    def _pct_change(curr: float, prior: float) -> str:
        if prior == 0:
            return "—"
        return fmt_pct((curr - prior) / prior * 100, precision=1)

    def _signed_delta(d: float) -> str:
        return fmt_dollars(d, signed=True)

    lines: list[str] = [
        "### Revenue delta",
        "",
        "| Source          | This period | Prior    | Delta    | % change |",
        "|-----------------|-------------|----------|----------|----------|",
    ]

    # Total row
    lines.append(
        f"| Total           | {fmt_dollars(current_rev):<11} | "
        f"{fmt_dollars(prior_rev):<8} | "
        f"{_signed_delta(delta):<8} | "
        f"{_pct_change(current_rev, prior_rev)} |"
    )

    # Baseline row
    b_curr = baseline.get("current", 0.0)
    b_prior = baseline.get("prior", 0.0)
    b_delta = baseline.get("delta", 0.0)
    lines.append(
        f"| Baseline        | {fmt_dollars(b_curr):<11} | "
        f"{fmt_dollars(b_prior):<8} | "
        f"{_signed_delta(b_delta):<8} | "
        f"{_pct_change(b_curr, b_prior)} |"
    )

    # Paid total row
    p_curr = paid_total.get("current", 0.0)
    p_prior = paid_total.get("prior", 0.0)
    p_delta = paid_total.get("delta", 0.0)
    lines.append(
        f"| Paid            | {fmt_dollars(p_curr):<11} | "
        f"{fmt_dollars(p_prior):<8} | "
        f"{_signed_delta(p_delta):<8} | "
        f"{_pct_change(p_curr, p_prior)} |"
    )

    # Per-channel rows with tree prefix
    for i, ch in enumerate(channels):
        prefix = "\u2514 " if i == len(channels) - 1 else "\u251c "
        name = ch["name"]
        c_curr = ch.get("contribution_current", 0.0)
        c_prior = ch.get("contribution_prior", 0.0)
        c_delta = ch.get("delta", 0.0)
        lines.append(
            f"| {prefix}{name:<13} | {fmt_dollars(c_curr):<11} | "
            f"{fmt_dollars(c_prior):<8} | "
            f"{_signed_delta(c_delta):<8} | "
            f"{_pct_change(c_curr, c_prior)} |"
        )

    return "\n".join(lines)


def _section_decomp_table(result: dict) -> str:
    """Spend vs efficiency decomposition table."""
    channels = result.get("channels", [])
    if not channels:
        return ""

    lines: list[str] = [
        "### Spend vs efficiency decomposition",
        "",
        "| Channel         | Spend effect | Efficiency effect | Net delta |",
        "|-----------------|--------------|-------------------|-----------|",
    ]

    for ch in channels:
        name = ch["name"]
        spend_eff = ch.get("spend_effect", 0.0)
        eff_eff = ch.get("efficiency_effect", 0.0)
        net = ch.get("delta", 0.0)
        zero_flag = " *" if ch.get("zero_spend_period") else ""

        lines.append(
            f"| {name}{zero_flag:<13} | "
            f"{fmt_dollars(spend_eff, signed=True):<12} | "
            f"{fmt_dollars(eff_eff, signed=True):<17} | "
            f"{fmt_dollars(net, signed=True)} |"
        )

    if any(ch.get("zero_spend_period") for ch in channels):
        lines.append("")
        lines.append(
            "*\\* Zero spend in one period — efficiency effect not calculated for these channels.*"
        )

    return "\n".join(lines)


def _section_footer(result: dict) -> str:
    """Italic footer with scaling caveat + posterior info."""
    data_window = result.get("data_window", "")
    mcmc_config = result.get("mcmc_config", {})

    if isinstance(mcmc_config, dict):
        chains = mcmc_config.get("chains")
        draws = mcmc_config.get("draws")
        if chains and draws:
            posterior_str = f"Posterior: {chains} chains \u00d7 {draws} draws"
        else:
            posterior_str = "Posterior converged."
    else:
        posterior_str = "Posterior converged."

    window_str = f"Data window: {data_window}." if data_window else ""
    scaling_note = (
        "Per-period contributions proportionally scaled from full-window posterior; "
        "total revenue from observed data."
    )
    parts = [p for p in [window_str, posterior_str] if p]
    footer_line = f"*{' '.join(parts)}*"
    return f"{footer_line}\n\n*{scaling_note}*"


# ---------------------------------------------------------------------------
# Main render
# ---------------------------------------------------------------------------


def _render(result: dict) -> str:
    """Internal render — may raise; caller wraps in try/except."""
    if not result:
        return ""

    sections: list[str] = []

    # 1. Opening verdict paragraph
    verdict = _section_verdict(result)
    if verdict:
        sections.append(verdict)

    # 2. Delta table
    sections.append(_section_delta_table(result))

    # 3. Spend vs efficiency decomposition table
    decomp = _section_decomp_table(result)
    if decomp:
        sections.append(decomp)

    # 4. Footer
    sections.append(_section_footer(result))

    return "\n\n".join(sections)


# ---------------------------------------------------------------------------
# Structured data builder (used by server.py)
# ---------------------------------------------------------------------------


def build_wow_result(
    period: str,
    period_label: str,
    data_window: str,
    current_revenue: float,
    prior_revenue: float,
    current_means: dict[str, float],
    prior_means: dict[str, float],
    current_spend: dict[str, float],
    prior_spend: dict[str, float],
    channel_columns: list[str],
    mcmc_config: dict,
) -> dict[str, Any]:
    """Build the structured WoW result dict matching the spec output shape.

    Args:
        period: Period string ("week", "4_weeks", "quarter").
        period_label: Human-readable label with date ranges for both periods.
        data_window: Full data window string.
        current_revenue: Sum of y over the current period (from observed data).
        prior_revenue: Sum of y over the prior period (from observed data).
        current_means: {display_name: contribution} for current period.
        prior_means: {display_name: contribution} for prior period.
        current_spend: {display_name: spend} for current period.
        prior_spend: {display_name: spend} for prior period.
        channel_columns: Ordered raw channel column names.
        mcmc_config: MCMC config dict.

    Returns:
        Result dict matching the spec output shape.
    """
    from mixlift.modeling.optimizer import format_channel_name

    period_weeks = _PERIOD_WEEKS[period]
    delta = current_revenue - prior_revenue
    delta_pct = round((delta / prior_revenue * 100), 2) if prior_revenue != 0 else 0.0

    # Build per-channel entries
    channel_list: list[dict[str, Any]] = []

    for raw_col in channel_columns:
        display = format_channel_name(raw_col)
        contrib_curr = current_means.get(display, 0.0)
        contrib_prior = prior_means.get(display, 0.0)
        ch_delta = contrib_curr - contrib_prior

        spend_curr = current_spend.get(display, 0.0)
        spend_prior = prior_spend.get(display, 0.0)
        spend_delta_val = spend_curr - spend_prior

        zero_spend = spend_curr == 0 or spend_prior == 0

        # Marginal ROAS = contribution / spend (proxy; contribution proportionally scaled)
        mroas_curr = (contrib_curr / spend_curr) if spend_curr > 0 else None
        mroas_prior = (contrib_prior / spend_prior) if spend_prior > 0 else None

        # Decompose delta into spend effect + efficiency effect
        if zero_spend:
            spend_effect = 0.0
            efficiency_effect = 0.0
        else:
            # avg marginal ROAS across both periods
            avg_mroas = (mroas_curr + mroas_prior) / 2  # type: ignore[operator]
            spend_effect = spend_delta_val * avg_mroas
            efficiency_effect = spend_curr * (mroas_curr - mroas_prior)  # type: ignore[operator]

        entry: dict[str, Any] = {
            "name": display,
            "contribution_current": round(contrib_curr, 0),
            "contribution_prior": round(contrib_prior, 0),
            "delta": round(ch_delta, 0),
            "spend_current": round(spend_curr, 0),
            "spend_prior": round(spend_prior, 0),
            "spend_delta": round(spend_delta_val, 0),
            "spend_effect": round(spend_effect, 0),
            "efficiency_effect": round(efficiency_effect, 0),
            "marginal_roas_current": round(mroas_curr, 2) if mroas_curr is not None else None,
            "marginal_roas_prior": round(mroas_prior, 2) if mroas_prior is not None else None,
        }
        if zero_spend:
            entry["zero_spend_period"] = True

        channel_list.append(entry)

    # Sort by abs(delta) descending so biggest movers lead
    channel_list.sort(key=lambda c: abs(c["delta"]), reverse=True)

    # Paid totals
    paid_curr = sum(ch["contribution_current"] for ch in channel_list)
    paid_prior = sum(ch["contribution_prior"] for ch in channel_list)

    # Baseline = observed revenue − paid contributions
    baseline_curr = current_revenue - paid_curr
    baseline_prior = prior_revenue - paid_prior

    result: dict[str, Any] = {
        "tool": "mixlift_wow",
        "version": "0.5.3",
        "mcmc_config": mcmc_config,
        "data_window": data_window,
        "period_label": period_label,
        "period_weeks": period_weeks,
        "current_revenue": round(current_revenue, 0),
        "prior_revenue": round(prior_revenue, 0),
        "delta": round(delta, 0),
        "delta_pct": delta_pct,
        "baseline": {
            "current": round(baseline_curr, 0),
            "prior": round(baseline_prior, 0),
            "delta": round(baseline_curr - baseline_prior, 0),
        },
        "paid_total": {
            "current": round(paid_curr, 0),
            "prior": round(paid_prior, 0),
            "delta": round(paid_curr - paid_prior, 0),
        },
        "channels": channel_list,
    }

    return result
