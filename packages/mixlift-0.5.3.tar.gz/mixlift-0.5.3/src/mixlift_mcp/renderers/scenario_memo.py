"""Mock-C analyst-memo renderer for scenario results.

Pure stdlib only — no numpy, pandas, or jinja.
"""

from __future__ import annotations

import re

from mixlift_mcp.renderers._helpers import (
    channel_display_name,
    fmt_dollars,
)


def _parse_mcmc_config(mcmc_config: str) -> tuple[int | None, int | None]:
    """Extract chains and draws counts from an mcmc_config string.

    Expected format: "4 chains, 250 draws, target_accept=0.90"
    Returns (chains, draws), either may be None on parse failure.
    """
    chains: int | None = None
    draws: int | None = None

    m_chains = re.search(r"(\d+)\s+chains?", mcmc_config)
    if m_chains:
        chains = int(m_chains.group(1))

    m_draws = re.search(r"(\d+)\s+draws?", mcmc_config)
    if m_draws:
        draws = int(m_draws.group(1))

    return chains, draws


def _certainty_suffix(impact_pct: float, ci_low: float, ci_high: float) -> str:
    """Return the certainty suffix based on CI bounds and median magnitude."""
    # Both bounds same sign → near-certain
    if ci_low > 0 or ci_high < 0:
        return "Near-certain."

    ci_width = ci_high - ci_low
    # Median magnitude less than half the CI width → coin flip
    if ci_width > 0 and abs(impact_pct) < ci_width / 2:
        return "Coin flip."

    return "Likely."


def render_scenario_memo(
    scenario_result: dict,
    model_info: dict | None = None,
) -> str:
    """Render a Mock-C-aesthetic scenario memo.

    scenario_result contains the per-scenario payload (headline, changes,
    impact_ci_80, direction_note). model_info is the parent MMM result's
    model_info block (chains, draws).

    Returns markdown string, or "" if critical fields missing.
    """
    if not scenario_result:
        return ""

    # ------------------------------------------------------------------
    # Extract impact_pct — required field
    # ------------------------------------------------------------------
    impact_pct: float | None = scenario_result.get("projected_impact_pct")
    if impact_pct is None:
        return ""

    # ------------------------------------------------------------------
    # Section 1: Lede
    # ------------------------------------------------------------------
    scenario_input: str = scenario_result.get("scenario_input", "")
    if not scenario_input:
        headline = scenario_result.get("headline", "")
        scenario_input = headline[:80]
    if not scenario_input:
        return ""

    lines: list[str] = []
    lines.append(f"**Scenario \u00b7 {scenario_input}**")
    lines.append("")

    # ------------------------------------------------------------------
    # Section 2: H2 thesis
    # ------------------------------------------------------------------
    ci_block: dict = scenario_result.get("impact_ci_80", {})
    ci_low: float = float(ci_block.get("low", impact_pct))
    ci_high: float = float(ci_block.get("high", impact_pct))

    if impact_pct > 0.5:
        verb = "lift"
    elif impact_pct < -0.5:
        verb = "reduce"
    else:
        verb = "move"

    certainty = _certainty_suffix(impact_pct, ci_low, ci_high)
    thesis = (
        f"## This scenario would {verb} revenue by "
        f"~{abs(impact_pct):.1f}%. {certainty}"
    )
    lines.append(thesis)
    lines.append("")

    # ------------------------------------------------------------------
    # Section 3: Narrative paragraph (direction_note)
    # ------------------------------------------------------------------
    direction_note: str = scenario_result.get("direction_note", "").rstrip()
    if direction_note:
        lines.append(direction_note)
        lines.append("")

    # ------------------------------------------------------------------
    # Section 4: Budget shifts table
    # ------------------------------------------------------------------
    changes: list[dict] = scenario_result.get("changes", [])
    if changes:
        sorted_changes = sorted(
            changes,
            key=lambda c: abs(float(c.get("change", 0))),
            reverse=True,
        )

        lines.append("### Budget shifts")
        lines.append("")
        lines.append("| Channel | Before | After | \u0394 |")
        lines.append("|---------|-------:|------:|---:|")
        for row in sorted_changes:
            channel_raw: str = str(row.get("channel", ""))
            try:
                display = channel_display_name(channel_raw)
            except Exception:
                display = channel_raw

            before = fmt_dollars(row.get("current", 0))
            after = fmt_dollars(row.get("modified", row.get("current", 0)))
            delta = fmt_dollars(row.get("change", 0), signed=True)
            lines.append(f"| {display} | {before} | {after} | {delta} |")

        lines.append("")

    # ------------------------------------------------------------------
    # Section 5: Footer
    # ------------------------------------------------------------------
    footer_ci = f"80% CI: {ci_low:+.1f}% to {ci_high:+.1f}%."

    mcmc_suffix: str = ""
    if model_info is not None:
        mcmc_config_str: str = ""
        if isinstance(model_info, dict):
            mcmc_config_str = str(model_info.get("mcmc_config", ""))
        if mcmc_config_str:
            chains, draws = _parse_mcmc_config(mcmc_config_str)
            if chains is not None and draws is not None:
                mcmc_suffix = f" Modeled on {chains} chains \u00d7 {draws} draws posterior."

    if mcmc_suffix:
        footer = f"*{footer_ci}{mcmc_suffix}*"
    else:
        footer = "*Posterior-based scenario projection.*"

    lines.append(footer)

    return "\n".join(lines)
