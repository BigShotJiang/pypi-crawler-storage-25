"""Thread-safe bridge from sync engine code to async ctx.report_progress.

The modeling engine runs in a worker thread (via asyncio.to_thread). This module
provides ProgressReporter, which can be called from any thread and schedules
report_progress coroutines back onto the asyncio event loop that owns the MCP
context.

Usage (in the MCP handler, async context):

    loop = asyncio.get_running_loop()
    reporter = ProgressReporter(ctx, loop)

Usage (in the engine, sync context, any thread):

    reporter.phase("Building Bayesian model", progress=1, total=8)
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mcp.server.fastmcp import Context

logger = logging.getLogger(__name__)


class ProgressReporter:
    """Thread-safe bridge from sync engine code to async ctx.report_progress.

    Args:
        ctx: FastMCP Context, or None (when running headless / in tests without
             a real MCP session). All methods are no-ops when ctx is None.
        loop: The asyncio event loop that owns the MCP session. Must be provided
              when the reporter will be called from a background thread. If None
              and ctx is not None, calls are assumed to already be on the event
              loop (uncommon; mainly for unit tests).
    """

    def __init__(
        self,
        ctx: "Context | None",
        loop: "asyncio.AbstractEventLoop | None" = None,
    ) -> None:
        self._ctx = ctx
        self._loop = loop

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def phase(
        self,
        name: str,
        progress: float | None = None,
        total: float | None = None,
    ) -> None:
        """Emit a progress notification. Call from any thread. No-op if ctx is None.

        Args:
            name: Human-readable phase description shown in the Claude UI.
            progress: Optional numeric progress (e.g. draw index, step number).
            total: Optional total (e.g. total draws). Enables the progress bar.
        """
        if self._ctx is None:
            return
        coro = self._ctx.report_progress(
            progress=progress if progress is not None else 0,
            total=total,
            message=name,
        )
        self._schedule(coro, name)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _schedule(self, coro: "asyncio.Coroutine[object, object, object]", label: str) -> None:
        """Schedule *coro* on the event loop from any thread."""
        if self._loop is not None and self._loop.is_running():
            future = asyncio.run_coroutine_threadsafe(coro, self._loop)
            # Fire-and-forget — we don't block the sampling thread waiting for
            # the notification to be delivered. Swallow any send errors so a
            # disconnected client never aborts the model fit.
            future.add_done_callback(lambda f: _swallow(f, label))
            return

        # Fallback: try the running loop of the *current* thread (works when
        # called directly from an async context in tests).
        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None

        if running_loop is not None and running_loop.is_running():
            asyncio.ensure_future(coro, loop=running_loop)
        else:
            # No event loop at all — silently discard (e.g. dry-run tests).
            try:
                coro.close()
            except Exception:
                pass


def _swallow(future: "asyncio.Future[object]", label: str) -> None:
    """Callback that discards non-fatal send errors."""
    try:
        future.result()
    except Exception as exc:
        logger.debug("Progress notification for %r failed (ignored): %s", label, exc)
