"""MixLift Cloud — Remote MCP server for zero-install onboarding.

Runs the same MixLift MCP tools over Streamable HTTP transport instead of stdio.
Designed for deployment on Fly.io and connection via Claude Cowork marketplace.

Usage:
    python -m mixlift_mcp.remote          # Default: 0.0.0.0:8080
    PORT=3000 python -m mixlift_mcp.remote  # Custom port

The server exposes the same tools as the local MCP server:
    - mixlift_analyze: Full Bayesian MMM analysis (accepts csv_content for cloud)
    - mixlift_scenario: What-if budget change modeling
    - mixlift_forecast: 12-week revenue projection
    - mixlift_readout: Executive markdown deliverables
    - mixlift_connect: Pull data from ad platforms
    - mixlift_prepare: CSV format validation/preparation
"""

from __future__ import annotations

import logging
import os

from mixlift_mcp.logging_config import configure_logging
from mixlift_mcp.sentry_init import init_sentry

# Configure structured logging and Sentry before any other imports emit logs.
configure_logging()
init_sentry()

logger = logging.getLogger(__name__)


def _configure_oauth(mcp: "FastMCP") -> None:  # type: ignore[name-defined]  # noqa: F821
    """Attach OAuth 2.1 auth settings to *mcp* when ``OAUTH_ENABLED=true``.

    Uses post-construction mutation of ``mcp.settings.auth`` and
    ``mcp._token_verifier`` because the shared ``mcp`` object is created in
    ``server.py`` without auth (so the local pip-install path keeps working).

    FastMCP reads these two attributes inside ``streamable_http_app()`` /
    ``sse_app()`` — both called after ``main()`` configures them — so the
    ordering is safe.

    FastMCP auth API (verified against FastMCP 1.26.0 source):
    - Constructor kwargs: ``FastMCP(..., auth=AuthSettings(...),
      token_verifier=TokenVerifier(...))``
    - No ``.init()`` method exists.
    - Post-construction mutation (used here) works because:
      * ``mcp.settings`` is a Pydantic ``BaseSettings`` with mutable fields.
      * ``mcp._token_verifier`` is a plain attribute assigned in ``__init__``.
      * Auth middleware is wired lazily inside ``streamable_http_app()``; it
        reads both attributes at that point, after this function runs.

    Context → AccessToken extraction (verified against source):
    - FastMCP's ``AuthContextMiddleware`` stores the validated user in a
      ``contextvars.ContextVar`` (``auth_context_var``).
    - ``mcp.server.auth.middleware.auth_context.get_access_token()`` reads it.
    - No ``ctx`` parameter needed; works from anywhere inside a request.
    """
    from mcp.server.auth.settings import AuthSettings

    from mixlift_mcp.oauth_verifier import MixLiftTokenVerifier

    issuer = os.environ.get("OAUTH_ISSUER_URL", "https://api.mixlift.io")
    audience = os.environ.get("OAUTH_AUDIENCE", "https://mixlift-cloud.fly.dev")

    mcp.settings.auth = AuthSettings(
        issuer_url=issuer,  # type: ignore[arg-type]
        resource_server_url=audience,  # type: ignore[arg-type]
        required_scopes=["mcp:tools"],
    )
    mcp._token_verifier = MixLiftTokenVerifier(issuer=issuer, audience=audience)
    logger.info(
        "OAuth 2.1 enabled: issuer=%s audience=%s required_scopes=['mcp:tools']",
        issuer,
        audience,
    )


def main() -> None:
    """Start the MixLift remote MCP server."""
    # Import mcp object from the main server module — this registers all tools
    from mcp.server.transport_security import TransportSecuritySettings

    from mixlift_mcp.server import mcp

    # Wire OAuth when the feature flag is on.  Default is off so the current
    # PoC flow keeps working until we manually flip the flag in production.
    if os.environ.get("OAUTH_ENABLED", "false").lower() == "true":
        _configure_oauth(mcp)

    port = int(os.environ.get("PORT", "8080"))
    host = os.environ.get("HOST", "0.0.0.0")
    log_level = os.environ.get("LOG_LEVEL", "info")

    # Public hostnames allowed to reach this server.
    # ALLOWED_HOSTS env var accepts a comma-separated list.
    default_hosts = "mixlift-cloud.fly.dev,*.fly.dev,localhost:*,127.0.0.1:*"
    allowed_hosts = [
        h.strip()
        for h in os.environ.get("ALLOWED_HOSTS", default_hosts).split(",")
        if h.strip()
    ]

    default_origins = (
        "https://claude.ai,https://*.claude.ai,"
        "https://claude.com,https://*.claude.com,"
        "http://localhost:*,http://127.0.0.1:*"
    )
    allowed_origins = [
        o.strip()
        for o in os.environ.get("ALLOWED_ORIGINS", default_origins).split(",")
        if o.strip()
    ]

    # Configure the FastMCP settings for HTTP transport
    mcp._mcp_server.name = "mixlift-cloud"
    mcp.settings.host = host
    mcp.settings.port = port
    mcp.settings.log_level = log_level
    mcp.settings.transport_security = TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=allowed_hosts,
        allowed_origins=allowed_origins,
    )

    # Build the ASGI app manually so we can inject middleware before serving.
    import anyio
    import uvicorn

    from mixlift_mcp.request_id import RequestIdMiddleware

    starlette_app = mcp.streamable_http_app()
    # Wrap with RequestIdMiddleware — Starlette apps accept add_middleware().
    starlette_app.add_middleware(RequestIdMiddleware)  # type: ignore[attr-defined]

    async def _serve() -> None:
        config = uvicorn.Config(
            starlette_app,
            host=host,
            port=port,
            log_level=log_level.lower(),
        )
        server = uvicorn.Server(config)
        await server.serve()

    logger.info("Starting MixLift Cloud MCP on %s:%s", host, port)
    logger.info("Allowed hosts: %s", allowed_hosts)
    anyio.run(_serve)


if __name__ == "__main__":
    main()
