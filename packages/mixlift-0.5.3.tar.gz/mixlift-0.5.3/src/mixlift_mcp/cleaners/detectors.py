"""Detection rules for mixlift_clean.

Each function takes a DataFrame (and optional config) and returns a list of
Issue dataclasses. The DataFrame must have been minimally pre-processed
(column whitespace stripped, but values may still be messy).

No file I/O, no model interaction, pure pandas.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from mixlift_mcp.cleaners.aliases import canonicalize_channel

# ---------------------------------------------------------------------------
# Issue dataclass
# ---------------------------------------------------------------------------


@dataclass
class Issue:
    """Represents a single detected data quality issue."""

    kind: str
    severity: str  # "high" | "medium" | "low" | "info"
    description: str
    affected_rows: int
    affected_values: list[Any] = field(default_factory=list)
    proposed_fix: str = ""
    auto_applies: bool = False

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "severity": self.severity,
            "description": self.description,
            "affected_rows": self.affected_rows,
            "affected_values": self.affected_values,
            "proposed_fix": self.proposed_fix,
            "auto_applies": self.auto_applies,
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Regex matching currency markers: leading $, trailing USD, commas in numbers
_CURRENCY_RE = re.compile(r"^\s*\$|\bUSD\b|,(?=\d{3})")

# Regex for values that look numeric but have currency noise
_NOISY_NUMERIC_RE = re.compile(r"[\$,]|USD")


def _find_spend_col(df: pd.DataFrame) -> str | None:
    """Heuristic: find the spend/cost column."""
    for c in df.columns:
        cl = c.lower().strip()
        if any(kw in cl for kw in ("spend", "cost", "budget", "ad_spend", "media_spend")):
            return c
    return None


def _find_channel_col(df: pd.DataFrame) -> str | None:
    """Heuristic: find the channel/platform column."""
    for c in df.columns:
        cl = c.lower().strip()
        if any(kw in cl for kw in ("channel", "platform", "source", "medium", "network")):
            return c
    return None


def _find_date_col(df: pd.DataFrame) -> str | None:
    """Heuristic: find the date column."""
    for c in df.columns:
        cl = c.lower().strip()
        if any(kw in cl for kw in ("date", "day", "week", "period", "report_date")):
            return c
    return None


def _try_parse_dates(series: pd.Series) -> pd.Series | None:
    """Attempt to parse a series to datetime. Returns None if unparseable."""
    # Try infer_datetime_format first
    for dayfirst in (False, True):
        try:
            parsed = pd.to_datetime(series, dayfirst=dayfirst, errors="coerce")
            if parsed.notna().sum() > 0:
                return parsed
        except Exception:
            pass
    return None


def _is_ambiguous_date(val: str) -> bool:
    """Return True if the date string is ambiguous between US and EU formats.

    Ambiguous means both day and month could swap and both are valid:
    e.g. ``01/02/2024`` could be Jan 2 (US) or Feb 1 (EU).
    """
    for sep in ("/", "-"):
        parts = val.strip().split(sep)
        if len(parts) == 3:
            try:
                a, b, _ = int(parts[0]), int(parts[1]), parts[2]
                if 1 <= a <= 12 and 1 <= b <= 12 and a != b:
                    return True
            except (ValueError, IndexError):
                pass
    return False


def _strip_currency(val: Any) -> Any:
    """Strip currency markers from a value, returning the cleaned string."""
    if not isinstance(val, str):
        return val
    cleaned = val.strip()
    cleaned = cleaned.lstrip("$").rstrip()
    cleaned = re.sub(r"\bUSD\b", "", cleaned).strip()
    cleaned = cleaned.replace(",", "")
    return cleaned


def _to_numeric_safe(series: pd.Series) -> pd.Series:
    """Try to coerce a series to numeric, stripping currency markers first."""
    if pd.api.types.is_numeric_dtype(series):
        return series
    cleaned = series.apply(_strip_currency)
    return pd.to_numeric(cleaned, errors="coerce")


# ---------------------------------------------------------------------------
# Rule 1: Channel name inconsistency
# ---------------------------------------------------------------------------


def detect_channel_name_inconsistency(
    df: pd.DataFrame,
    user_map: dict[str, str] | None = None,
) -> list[Issue]:
    """Detect channel names that are aliases or near-duplicates of each other.

    Groups raw values by their canonical form (built-in aliases + user_map).
    Any group with more than one distinct raw value is flagged.
    """
    ch_col = _find_channel_col(df)
    if ch_col is None:
        return []

    raw_values: list[str] = df[ch_col].dropna().astype(str).str.strip().unique().tolist()
    if not raw_values:
        return []

    # Build map: canonical -> [raw values that map to it]
    canonical_to_raws: dict[str, list[str]] = {}
    for raw in raw_values:
        canon = canonicalize_channel(raw, user_map)
        canonical_to_raws.setdefault(canon, []).append(raw)

    issues: list[Issue] = []
    for canon, raws in canonical_to_raws.items():
        # Remove the canonical itself if it's already present as-is
        aliased = [r for r in raws if r != canon]
        if not aliased:
            continue
        # Count affected rows: rows whose channel value is one of the aliased forms
        mask = df[ch_col].astype(str).str.strip().isin(aliased)
        n_rows = int(mask.sum())
        if n_rows == 0:
            continue

        rename_parts = " + ".join(f"'{r}'" for r in aliased)
        issues.append(
            Issue(
                kind="channel_name_inconsistency",
                severity="high",
                description=(
                    f"{rename_parts} and '{canon}' look like the same channel "
                    f"({n_rows} rows affected)"
                ),
                affected_rows=n_rows,
                affected_values=aliased,
                proposed_fix=(", ".join(f"Rename '{r}' \u2192 '{canon}'" for r in aliased)),
                auto_applies=True,
            )
        )

    return issues


# ---------------------------------------------------------------------------
# Rule 2: Missing weeks
# ---------------------------------------------------------------------------


def detect_missing_weeks(df: pd.DataFrame) -> list[Issue]:
    """Detect gaps in the date column.

    Severity:
    - Gap <= 1 week: low
    - Gap 2–4 weeks: medium
    - Gap > 4 weeks: high
    """
    date_col = _find_date_col(df)
    if date_col is None:
        return []

    dates = _try_parse_dates(df[date_col].dropna().astype(str))
    if dates is None or dates.dropna().empty:
        return []

    unique_dates = sorted(dates.dropna().unique())
    if len(unique_dates) <= 1:
        return [
            Issue(
                kind="only_one_date",
                severity="high",
                description=(
                    "Only one unique date found. Need multiple weeks to validate structure."
                ),
                affected_rows=len(df),
                affected_values=[str(unique_dates[0]) if unique_dates else ""],
                proposed_fix="Add more weeks of data before cleaning.",
                auto_applies=False,
            )
        ]

    issues: list[Issue] = []
    # Detect the expected frequency from the most common gap
    gaps_days = [
        (pd.Timestamp(unique_dates[i]) - pd.Timestamp(unique_dates[i - 1])).days
        for i in range(1, len(unique_dates))
    ]
    freq_days = sorted(gaps_days)[len(gaps_days) // 2]  # median
    if freq_days == 0:
        freq_days = 7

    for i in range(1, len(unique_dates)):
        gap = (pd.Timestamp(unique_dates[i]) - pd.Timestamp(unique_dates[i - 1])).days
        if gap <= freq_days:
            continue
        missing_weeks = round((gap - freq_days) / max(freq_days, 1))
        if missing_weeks <= 0:
            continue

        after = pd.Timestamp(unique_dates[i - 1]).strftime("%Y-%m-%d")
        before = pd.Timestamp(unique_dates[i]).strftime("%Y-%m-%d")

        if missing_weeks <= 1:
            severity = "low"
            fix = "Zero-fill the gap"
        elif missing_weeks <= 4:
            severity = "medium"
            fix = "Zero-fill or interpolate the gap"
        else:
            severity = "high"
            fix = "Flag for review — gap may indicate data collection issue"

        issues.append(
            Issue(
                kind="missing_weeks",
                severity=severity,
                description=(
                    f"Gap of ~{missing_weeks} week(s) detected between {after} and {before}"
                ),
                affected_rows=0,
                affected_values=[after, before],
                proposed_fix=fix,
                auto_applies=(missing_weeks <= 4 and severity != "high"),
            )
        )

    return issues


# ---------------------------------------------------------------------------
# Rule 3: Outlier spikes
# ---------------------------------------------------------------------------


def detect_outlier_spikes(df: pd.DataFrame) -> list[Issue]:
    """Detect rows where spend is >5× the 90-day rolling median for that channel.

    Flags only — does NOT auto-fix.
    """
    spend_col = _find_spend_col(df)
    date_col = _find_date_col(df)
    ch_col = _find_channel_col(df)
    if spend_col is None or date_col is None:
        return []

    spend_num = _to_numeric_safe(df[spend_col])
    dates = _try_parse_dates(df[date_col].dropna().astype(str))
    if dates is None:
        return []

    work = df.copy()
    work["_spend_num"] = spend_num
    work["_date_parsed"] = dates

    issues: list[Issue] = []

    def _check_group(group: pd.DataFrame, channel_label: str) -> None:
        group = group.dropna(subset=["_spend_num", "_date_parsed"]).copy()
        if len(group) < 3:
            return
        group = group.sort_values("_date_parsed")
        # Rolling 90-day window (13-week ≈ 91 days → use 13 obs window)
        window = min(13, max(3, len(group) // 4))
        rolling_median = group["_spend_num"].rolling(window, min_periods=1).median()

        for idx, (row_idx, row) in enumerate(group.iterrows()):
            median = rolling_median.iloc[idx]
            spend_val = row["_spend_num"]
            if median <= 0 or pd.isna(median):
                continue
            ratio = spend_val / median
            if ratio > 5:
                date_str = row["_date_parsed"].strftime("%Y-%m-%d")
                issues.append(
                    Issue(
                        kind="outlier_spike",
                        severity="high",
                        description=(
                            f"Outlier spike on {date_str}: {channel_label} spend "
                            f"${spend_val:,.0f} ({ratio:.0f}\u00d7 rolling median "
                            f"of ${median:,.0f}). Leave as-is or investigate?"
                        ),
                        affected_rows=1,
                        affected_values=[date_str, channel_label],
                        proposed_fix="Manual review required — could be a real burst campaign.",
                        auto_applies=False,
                    )
                )

    if ch_col is not None:
        for channel, grp in work.groupby(ch_col):
            _check_group(grp, str(channel))
    else:
        _check_group(work, "spend")

    return issues


# ---------------------------------------------------------------------------
# Rule 4: Duplicate rows
# ---------------------------------------------------------------------------


def detect_duplicate_rows(df: pd.DataFrame) -> list[Issue]:
    """Detect duplicate (date, channel) rows or exact duplicate rows."""
    date_col = _find_date_col(df)
    ch_col = _find_channel_col(df)
    issues: list[Issue] = []

    # Exact duplicate rows
    exact_dupe_mask = df.duplicated(keep=False)
    if exact_dupe_mask.sum() > 0:
        dupes_to_drop = int(df.duplicated(keep="first").sum())
        issues.append(
            Issue(
                kind="duplicate_rows",
                severity="medium",
                description=f"Found {dupes_to_drop} exact duplicate row(s).",
                affected_rows=dupes_to_drop,
                affected_values=[],
                proposed_fix="Drop exact duplicate rows.",
                auto_applies=True,
            )
        )

    # (date, channel) duplicates with conflicting values
    if date_col is not None and ch_col is not None:
        key_cols = [date_col, ch_col]
        dupe_keys = df.duplicated(subset=key_cols, keep=False)
        # Subtract exact dupes already caught
        conflicting = dupe_keys & ~exact_dupe_mask
        if conflicting.sum() > 0:
            n_conf = int(conflicting.sum())
            issues.append(
                Issue(
                    kind="duplicate_date_channel",
                    severity="medium",
                    description=(
                        f"Found {n_conf} rows sharing the same (date, channel) key "
                        "with different values."
                    ),
                    affected_rows=n_conf,
                    affected_values=[],
                    proposed_fix=(
                        "Keep the row with the most non-null values per (date, channel) key."
                    ),
                    auto_applies=True,
                )
            )

    return issues


# ---------------------------------------------------------------------------
# Rule 5: Aggregation level mismatch
# ---------------------------------------------------------------------------


def detect_aggregation_mismatch(df: pd.DataFrame) -> list[Issue]:
    """Detect if data is daily when weekly is expected.

    If multiple rows share the same (channel, ISO week), the data is daily.
    """
    date_col = _find_date_col(df)
    ch_col = _find_channel_col(df)
    if date_col is None:
        return []

    dates = _try_parse_dates(df[date_col].dropna().astype(str))
    if dates is None or dates.dropna().empty:
        return []

    work = df.copy()
    work["_date_parsed"] = dates
    work = work.dropna(subset=["_date_parsed"])

    # Check min gap between consecutive dates
    all_dates = sorted(work["_date_parsed"].unique())
    if len(all_dates) < 2:
        return []

    gaps = [(all_dates[i] - all_dates[i - 1]).days for i in range(1, len(all_dates))]
    min_gap = min(gaps)

    if min_gap >= 6:
        # Already weekly or coarser
        return []

    # Daily (or sub-weekly) data detected
    # Count how many rows would collapse under weekly aggregation
    work["_iso_week"] = work["_date_parsed"].dt.to_period("W")
    if ch_col is not None:
        group_cols = [ch_col, "_iso_week"]
    else:
        group_cols = ["_iso_week"]

    n_groups = work.groupby(group_cols).ngroups
    n_current = len(work)
    rows_to_collapse = n_current - n_groups

    return [
        Issue(
            kind="aggregation_mismatch",
            severity="medium",
            description=(
                f"Data appears to be daily (min date gap: {min_gap} day(s)). "
                f"MixLift expects weekly. {rows_to_collapse} rows would be "
                "aggregated under weekly grouping."
            ),
            affected_rows=rows_to_collapse,
            affected_values=[f"min_gap={min_gap}d"],
            proposed_fix="Aggregate to weekly (sum spend, keep revenue).",
            auto_applies=True,
        )
    ]


# ---------------------------------------------------------------------------
# Rule 6: Currency markers
# ---------------------------------------------------------------------------


def detect_currency_markers(df: pd.DataFrame) -> list[Issue]:
    """Detect dollar signs, commas, trailing 'USD' in numeric-like columns."""
    issues: list[Issue] = []
    numeric_hints = {"spend", "cost", "revenue", "sales", "budget", "investment", "value"}

    for col in df.columns:
        cl = col.lower().strip()
        is_numeric_hint = any(kw in cl for kw in numeric_hints)
        if not is_numeric_hint:
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            continue
        col_str = df[col].dropna().astype(str)
        mask = col_str.str.contains(r"[\$,]|\bUSD\b", regex=True, na=False)
        n_affected = int(mask.sum())
        if n_affected > 0:
            issues.append(
                Issue(
                    kind="currency_markers",
                    severity="low",
                    description=(
                        f"Column '{col}' contains currency markers "
                        f"(e.g. '$', ',', 'USD') in {n_affected} rows."
                    ),
                    affected_rows=n_affected,
                    affected_values=[col],
                    proposed_fix=f"Strip currency markers from '{col}' column.",
                    auto_applies=True,
                )
            )

    return issues


# ---------------------------------------------------------------------------
# Rule 7: Whitespace
# ---------------------------------------------------------------------------


def detect_whitespace(df: pd.DataFrame) -> list[Issue]:
    """Detect leading/trailing whitespace in column headers, channel names, cell values."""
    issues: list[Issue] = []

    # Column headers
    bad_cols = [c for c in df.columns if c != c.strip()]
    if bad_cols:
        issues.append(
            Issue(
                kind="whitespace_headers",
                severity="low",
                description=f"Column header(s) have leading/trailing whitespace: {bad_cols}",
                affected_rows=0,
                affected_values=bad_cols,
                proposed_fix="Strip whitespace from column headers.",
                auto_applies=True,
            )
        )

    # String column values
    string_cols = df.select_dtypes(include="object").columns.tolist()
    total_affected = 0
    affected_cols: list[str] = []
    for col in string_cols:
        notnull = df[col].dropna().astype(str)
        mask = notnull != notnull.str.strip()
        n = int(mask.sum())
        if n > 0:
            total_affected += n
            affected_cols.append(col)

    if total_affected > 0:
        issues.append(
            Issue(
                kind="whitespace_values",
                severity="low",
                description=(
                    f"Found {total_affected} cell value(s) with leading/trailing "
                    f"whitespace across column(s): {affected_cols}"
                ),
                affected_rows=total_affected,
                affected_values=affected_cols,
                proposed_fix="Strip whitespace from all string cell values.",
                auto_applies=True,
            )
        )

    return issues


# ---------------------------------------------------------------------------
# Rule 8: Leading/trailing empty columns/rows
# ---------------------------------------------------------------------------


def detect_empty_columns_rows(df: pd.DataFrame) -> list[Issue]:
    """Detect leading/trailing all-null rows and all-null columns."""
    issues: list[Issue] = []

    # All-null columns
    null_cols = [c for c in df.columns if df[c].isna().all()]
    if null_cols:
        issues.append(
            Issue(
                kind="empty_columns",
                severity="low",
                description=f"Column(s) with all null values: {null_cols}",
                affected_rows=len(df),
                affected_values=null_cols,
                proposed_fix="Drop empty columns.",
                auto_applies=True,
            )
        )

    # All-null rows
    null_row_mask = df.isna().all(axis=1)
    n_null_rows = int(null_row_mask.sum())
    if n_null_rows > 0:
        issues.append(
            Issue(
                kind="empty_rows",
                severity="low",
                description=f"Found {n_null_rows} completely empty row(s).",
                affected_rows=n_null_rows,
                affected_values=[],
                proposed_fix="Drop empty rows.",
                auto_applies=True,
            )
        )

    return issues


# ---------------------------------------------------------------------------
# Rule 9: Date format inconsistency
# ---------------------------------------------------------------------------


def detect_date_format_inconsistency(df: pd.DataFrame) -> list[Issue]:
    """Detect non-ISO date formats and ambiguous date values.

    If dates are parseable but not already ISO (YYYY-MM-DD), proposes conversion.
    If ambiguous date values exist (e.g. 01/02/2024), requires user confirmation.
    """
    date_col = _find_date_col(df)
    if date_col is None:
        return []

    col_str = df[date_col].dropna().astype(str).str.strip()
    if col_str.empty:
        return []

    issues: list[Issue] = []

    # Check for ISO format
    iso_pattern = re.compile(r"^\d{4}-\d{2}-\d{2}$")
    non_iso = col_str[~col_str.str.match(iso_pattern)]

    if non_iso.empty:
        # Already ISO
        return []

    # Check for ambiguous values
    ambiguous = non_iso[non_iso.apply(_is_ambiguous_date)]
    if not ambiguous.empty:
        examples = ambiguous.unique()[:3].tolist()
        issues.append(
            Issue(
                kind="ambiguous_date_format",
                severity="high",
                description=(
                    f"Ambiguous date values found (e.g. {examples}). "
                    "Could be US (M/D/YYYY) or EU (D/M/YYYY) format. "
                    "Confirm format before auto-fixing."
                ),
                affected_rows=int(len(ambiguous)),
                affected_values=examples,
                proposed_fix="Confirm date format (US vs EU) before converting to ISO.",
                auto_applies=False,
            )
        )

    # Non-ambiguous non-ISO dates
    unambiguous_non_iso = non_iso[~non_iso.apply(_is_ambiguous_date)]
    if not unambiguous_non_iso.empty:
        n = len(unambiguous_non_iso)
        examples = unambiguous_non_iso.unique()[:3].tolist()
        issues.append(
            Issue(
                kind="date_format_inconsistency",
                severity="low",
                description=(
                    f"{n} date value(s) are not in ISO format (YYYY-MM-DD). Example(s): {examples}"
                ),
                affected_rows=n,
                affected_values=examples,
                proposed_fix="Convert all dates to ISO 8601 (YYYY-MM-DD).",
                auto_applies=True,
            )
        )

    return issues


# ---------------------------------------------------------------------------
# Rule 10: Zero-spend all-channel rows
# ---------------------------------------------------------------------------


def detect_all_zero_spend_rows(df: pd.DataFrame) -> list[Issue]:
    """Detect rows where all spend columns are zero. Informational — keep as valid data."""
    spend_col = _find_spend_col(df)
    if spend_col is None:
        # Wide format: find all *_spend columns
        spend_cols = [c for c in df.columns if c.lower().strip().endswith("_spend")]
        if not spend_cols:
            return []
    else:
        spend_cols = [spend_col]

    numeric_spends = pd.concat([_to_numeric_safe(df[c]) for c in spend_cols], axis=1)
    zero_mask = (numeric_spends.fillna(0) == 0).all(axis=1)
    n_zero = int(zero_mask.sum())
    if n_zero == 0:
        return []

    return [
        Issue(
            kind="zero_spend_rows",
            severity="info",
            description=f"{n_zero} row(s) have zero spend across all channels.",
            affected_rows=n_zero,
            affected_values=[],
            proposed_fix="Keep as-is — zero-spend weeks are valid data for MMM.",
            auto_applies=False,
        )
    ]


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


def run_all_detectors(
    df: pd.DataFrame,
    user_map: dict[str, str] | None = None,
) -> list[Issue]:
    """Run all 10 detection rules and return the combined list of issues."""
    issues: list[Issue] = []
    issues.extend(detect_channel_name_inconsistency(df, user_map))
    issues.extend(detect_missing_weeks(df))
    issues.extend(detect_outlier_spikes(df))
    issues.extend(detect_duplicate_rows(df))
    issues.extend(detect_aggregation_mismatch(df))
    issues.extend(detect_currency_markers(df))
    issues.extend(detect_whitespace(df))
    issues.extend(detect_empty_columns_rows(df))
    issues.extend(detect_date_format_inconsistency(df))
    issues.extend(detect_all_zero_spend_rows(df))
    return issues
