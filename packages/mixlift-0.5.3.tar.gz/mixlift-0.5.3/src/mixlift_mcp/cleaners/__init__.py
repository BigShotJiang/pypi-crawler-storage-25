"""MixLift cleaners package — detection and repair of messy marketer uploads."""

from mixlift_mcp.cleaners.aliases import CHANNEL_ALIASES, canonicalize_channel
from mixlift_mcp.cleaners.detectors import (
    Issue,
    detect_aggregation_mismatch,
    detect_all_zero_spend_rows,
    detect_channel_name_inconsistency,
    detect_currency_markers,
    detect_date_format_inconsistency,
    detect_duplicate_rows,
    detect_empty_columns_rows,
    detect_missing_weeks,
    detect_outlier_spikes,
    detect_whitespace,
    run_all_detectors,
)
from mixlift_mcp.cleaners.fixers import apply_all_fixes

__all__ = [
    "CHANNEL_ALIASES",
    "Issue",
    "apply_all_fixes",
    "canonicalize_channel",
    "detect_aggregation_mismatch",
    "detect_all_zero_spend_rows",
    "detect_channel_name_inconsistency",
    "detect_currency_markers",
    "detect_date_format_inconsistency",
    "detect_duplicate_rows",
    "detect_empty_columns_rows",
    "detect_missing_weeks",
    "detect_outlier_spikes",
    "detect_whitespace",
    "run_all_detectors",
]
