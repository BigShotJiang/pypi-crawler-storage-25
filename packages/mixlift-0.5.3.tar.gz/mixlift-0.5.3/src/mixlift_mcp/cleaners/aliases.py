"""Built-in channel alias table for mixlift_clean.

Maps known alias values (lowercase) to canonical channel names.
User-supplied ``channel_name_map`` takes precedence over this table.
"""

from __future__ import annotations

# Maps lowercase alias → canonical display name
# e.g. "fb" -> "Meta", "adwords" -> "Google"
CHANNEL_ALIASES: dict[str, str] = {
    # Meta
    "fb": "Meta",
    "facebook": "Meta",
    "meta ads": "Meta",
    "meta_ads": "Meta",
    "fb_ads": "Meta",
    "facebook ads": "Meta",
    "instagram": "Meta",
    # Google
    "google ads": "Google",
    "google_ads": "Google",
    "adwords": "Google",
    "google adwords": "Google",
    "google_search": "Google",
    "google_display": "Google",
    "google search": "Google",
    "google display": "Google",
    # TikTok
    "ttk": "TikTok",
    "tiktok_ads": "TikTok",
    "tiktok ads": "TikTok",
    # LinkedIn
    "li": "LinkedIn",
    "li_ads": "LinkedIn",
    "linkedin ads": "LinkedIn",
    # Snapchat
    "snap": "Snapchat",
    "snap_ads": "Snapchat",
    "snapchat ads": "Snapchat",
    # Pinterest
    "pin": "Pinterest",
    "pinterest_ads": "Pinterest",
    "pinterest ads": "Pinterest",
    # Twitter / X
    "x": "Twitter",
    "twitter_ads": "Twitter",
    "twitter ads": "Twitter",
    "twitter/x": "Twitter",
}


def canonicalize_channel(
    name: str,
    user_map: dict[str, str] | None = None,
) -> str:
    """Return canonical channel name, applying user_map first, then built-in aliases.

    Case-insensitive lookup. If no alias matches, returns the original name stripped.

    Args:
        name: Raw channel name from the CSV.
        user_map: Optional user-supplied overrides, e.g. ``{"FB": "Meta"}``.

    Returns:
        Canonical channel name.
    """
    stripped = name.strip()
    lower = stripped.lower()

    # User map takes precedence (case-insensitive key lookup)
    if user_map:
        for k, v in user_map.items():
            if k.strip().lower() == lower:
                return v.strip()

    # Built-in alias table
    if lower in CHANNEL_ALIASES:
        return CHANNEL_ALIASES[lower]

    return stripped
