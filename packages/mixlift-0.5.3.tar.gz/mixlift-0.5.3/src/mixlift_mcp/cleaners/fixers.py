"""Fix functions for mixlift_clean.

Each fixer takes a DataFrame and an Issue, returns a modified DataFrame
and a description of the change made.

No file I/O, no model interaction, pure pandas.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from mixlift_mcp.cleaners.aliases import canonicalize_channel
from mixlift_mcp.cleaners.detectors import (
    Issue,
    _find_channel_col,
    _find_date_col,
    _strip_currency,
    _try_parse_dates,
)

# ---------------------------------------------------------------------------
# Fix result type
# ---------------------------------------------------------------------------


def _fix_result(kind: str, description: str, rows_changed: int) -> dict:
    return {"kind": kind, "description": description, "rows_changed": rows_changed}


# ---------------------------------------------------------------------------
# Fixer: channel name inconsistency
# ---------------------------------------------------------------------------


def fix_channel_name_inconsistency(
    df: pd.DataFrame,
    user_map: dict[str, str] | None = None,
) -> tuple[pd.DataFrame, dict]:
    """Rename aliased channel names to their canonical forms."""
    ch_col = _find_channel_col(df)
    if ch_col is None:
        return df, _fix_result("channel_name_inconsistency", "No channel column found.", 0)

    df = df.copy()
    original = df[ch_col].astype(str).str.strip()
    canonicalized = original.apply(lambda v: canonicalize_channel(v, user_map))
    changed = (original != canonicalized).sum()
    df[ch_col] = canonicalized
    return df, _fix_result(
        "channel_name_inconsistency",
        "Renamed aliased channel names to canonical forms.",
        int(changed),
    )


# ---------------------------------------------------------------------------
# Fixer: duplicate rows
# ---------------------------------------------------------------------------


def fix_duplicate_rows(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Drop exact duplicate rows; keep row with most non-null values for (date, channel) dupes."""
    n_before = len(df)
    df = df.copy()

    # Drop exact duplicates first
    df = df.drop_duplicates()

    date_col = _find_date_col(df)
    ch_col = _find_channel_col(df)

    if date_col is not None and ch_col is not None:
        key_cols = [date_col, ch_col]
        if df.duplicated(subset=key_cols).any():
            # Keep the row with the most non-null values per key
            df["_nonnull_count"] = df.notna().sum(axis=1)
            df = df.sort_values("_nonnull_count", ascending=False).drop_duplicates(
                subset=key_cols, keep="first"
            )
            df = df.drop(columns=["_nonnull_count"])

    n_dropped = n_before - len(df)
    return df, _fix_result(
        "duplicate_rows",
        f"Dropped {n_dropped} duplicate row(s).",
        n_dropped,
    )


# ---------------------------------------------------------------------------
# Fixer: aggregation mismatch (daily → weekly)
# ---------------------------------------------------------------------------


def fix_aggregation_mismatch(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Aggregate daily data to weekly by summing spend and keeping revenue."""
    date_col = _find_date_col(df)
    ch_col = _find_channel_col(df)

    if date_col is None:
        return df, _fix_result("aggregation_mismatch", "No date column found.", 0)

    df = df.copy()
    parsed = _try_parse_dates(df[date_col].dropna().astype(str))
    if parsed is None:
        return df, _fix_result("aggregation_mismatch", "Could not parse dates.", 0)

    df["_date_parsed"] = parsed
    df["_week_start"] = df["_date_parsed"].dt.to_period("W").dt.start_time

    n_before = len(df)

    # Identify numeric columns to aggregate
    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    # Exclude internal helpers
    numeric_cols = [c for c in numeric_cols if not c.startswith("_")]

    # Revenue: keep last (or mean); spend: sum
    spend_keywords = {"spend", "cost", "budget", "investment", "ad_spend"}
    revenue_keywords = {"revenue", "sales", "value", "gmv", "income"}

    agg_dict: dict[str, Any] = {}
    for col in numeric_cols:
        cl = col.lower()
        if any(kw in cl for kw in spend_keywords):
            agg_dict[col] = "sum"
        elif any(kw in cl for kw in revenue_keywords):
            agg_dict[col] = "sum"
        else:
            agg_dict[col] = "sum"

    group_cols = ["_week_start"]
    if ch_col is not None:
        group_cols.append(ch_col)

    # For non-numeric, keep first value
    str_cols = [
        c
        for c in df.columns
        if c not in numeric_cols and c not in group_cols and not c.startswith("_") and c != date_col
    ]
    for col in str_cols:
        agg_dict[col] = "first"

    if not agg_dict:
        df = df.drop(columns=["_date_parsed", "_week_start"])
        return df, _fix_result("aggregation_mismatch", "Nothing to aggregate.", 0)

    aggregated = df.groupby(group_cols, as_index=False).agg(agg_dict)
    aggregated = aggregated.rename(columns={"_week_start": date_col})

    n_after = len(aggregated)
    rows_changed = n_before - n_after

    return aggregated, _fix_result(
        "aggregation_mismatch",
        f"Aggregated {n_before} daily rows to {n_after} weekly rows.",
        rows_changed,
    )


# ---------------------------------------------------------------------------
# Fixer: currency markers
# ---------------------------------------------------------------------------


def fix_currency_markers(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Strip currency markers ($, commas, USD) from numeric-like columns."""
    df = df.copy()
    numeric_hints = {"spend", "cost", "revenue", "sales", "budget", "investment", "value"}
    total_changed = 0
    affected_cols: list[str] = []

    for col in df.columns:
        cl = col.lower().strip()
        is_numeric_hint = any(kw in cl for kw in numeric_hints)
        if not is_numeric_hint:
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            continue
        col_str = df[col].astype(str)
        mask = col_str.str.contains(r"[\$,]|\bUSD\b", regex=True, na=False)
        if mask.sum() > 0:
            df[col] = pd.to_numeric(col_str.apply(_strip_currency), errors="coerce")
            total_changed += int(mask.sum())
            affected_cols.append(col)

    return df, _fix_result(
        "currency_markers",
        f"Stripped currency markers from column(s): {affected_cols}. "
        f"{total_changed} values cleaned.",
        total_changed,
    )


# ---------------------------------------------------------------------------
# Fixer: whitespace
# ---------------------------------------------------------------------------


def fix_whitespace(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Strip leading/trailing whitespace from column headers and string values."""
    df = df.copy()
    total_changed = 0

    # Column headers
    old_cols = list(df.columns)
    new_cols = [c.strip() for c in old_cols]
    if old_cols != new_cols:
        df.columns = new_cols
        total_changed += sum(1 for a, b in zip(old_cols, new_cols) if a != b)

    # String cell values
    for col in df.select_dtypes(include="object").columns:
        original = df[col].astype(str)
        stripped = original.str.strip()
        changed = (original != stripped) & df[col].notna()
        df.loc[changed, col] = stripped[changed]
        total_changed += int(changed.sum())

    return df, _fix_result(
        "whitespace",
        f"Stripped whitespace from headers and {total_changed} cell value(s).",
        total_changed,
    )


# ---------------------------------------------------------------------------
# Fixer: empty columns/rows
# ---------------------------------------------------------------------------


def fix_empty_columns_rows(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Drop all-null columns and all-null rows."""
    df = df.copy()
    n_cols_before = len(df.columns)
    n_rows_before = len(df)

    # Drop all-null columns
    null_cols = [c for c in df.columns if df[c].isna().all()]
    df = df.drop(columns=null_cols)

    # Drop all-null rows
    df = df.dropna(how="all")

    cols_dropped = n_cols_before - len(df.columns)
    rows_dropped = n_rows_before - len(df)
    total = cols_dropped + rows_dropped

    return df, _fix_result(
        "empty_columns_rows",
        f"Dropped {cols_dropped} empty column(s) and {rows_dropped} empty row(s).",
        total,
    )


# ---------------------------------------------------------------------------
# Fixer: date format
# ---------------------------------------------------------------------------


def fix_date_format(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Parse all date values and emit ISO YYYY-MM-DD format.

    Only applies when no ambiguous dates are present (ambiguous dates require
    user confirmation and are skipped here).
    """
    date_col = _find_date_col(df)
    if date_col is None:
        return df, _fix_result("date_format", "No date column found.", 0)

    df = df.copy()
    parsed = _try_parse_dates(df[date_col].astype(str))
    if parsed is None:
        return df, _fix_result("date_format", "Could not parse dates.", 0)

    iso_series = parsed.dt.strftime("%Y-%m-%d")
    changed = (df[date_col].astype(str).str.strip() != iso_series).sum()
    df[date_col] = iso_series

    return df, _fix_result(
        "date_format",
        f"Converted {changed} date value(s) to ISO 8601 (YYYY-MM-DD).",
        int(changed),
    )


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


def apply_all_fixes(
    df: pd.DataFrame,
    issues: list[Issue],
    user_map: dict[str, str] | None = None,
) -> tuple[pd.DataFrame, list[dict]]:
    """Apply all auto-fixable issues to the DataFrame.

    Args:
        df: Input DataFrame.
        issues: Issues from run_all_detectors.
        user_map: Optional user-supplied channel name overrides.

    Returns:
        (cleaned_df, list of fix result dicts)
    """
    applied: list[dict] = []
    auto_kinds = {i.kind for i in issues if i.auto_applies}

    if not auto_kinds:
        return df, applied

    # Order matters: whitespace before channel rename, empty cols before everything else
    if {"whitespace_headers", "whitespace_values"} & auto_kinds:
        df, result = fix_whitespace(df)
        if result["rows_changed"] > 0:
            applied.append(result)

    if "empty_columns" in auto_kinds or "empty_rows" in auto_kinds:
        df, result = fix_empty_columns_rows(df)
        if result["rows_changed"] > 0:
            applied.append(result)

    if "currency_markers" in auto_kinds:
        df, result = fix_currency_markers(df)
        if result["rows_changed"] > 0:
            applied.append(result)

    if "date_format_inconsistency" in auto_kinds:
        df, result = fix_date_format(df)
        if result["rows_changed"] > 0:
            applied.append(result)

    if "channel_name_inconsistency" in auto_kinds:
        df, result = fix_channel_name_inconsistency(df, user_map)
        if result["rows_changed"] > 0:
            applied.append(result)

    if "duplicate_rows" in auto_kinds or "duplicate_date_channel" in auto_kinds:
        df, result = fix_duplicate_rows(df)
        if result["rows_changed"] > 0:
            applied.append(result)

    if "aggregation_mismatch" in auto_kinds:
        df, result = fix_aggregation_mismatch(df)
        if result["rows_changed"] > 0:
            applied.append(result)

    return df, applied
