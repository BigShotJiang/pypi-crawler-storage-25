"""Persistent disk-backed cache for fitted MixLift MMM models.

Turns the ~110s first-fit into a true one-time cost per unique dataset+config:
after the first analysis, the fitted MMM posterior (InferenceData via NetCDF)
and companion artefacts are serialized to disk, and subsequent calls for the
same fingerprint load from disk instead of re-running MCMC.

Cache layout:

    $MIXLIFT_MODEL_CACHE_DIR/
      v{SCHEMA_VERSION}/
        {fingerprint}/
          mmm.nc            # PyMC-Marketing MMM.save() NetCDF (ArviZ InferenceData)
          X.parquet         # feature matrix
          result.json       # tool-response result dict
          meta.json         # channel_columns, created_at, schema_version, mcmc_config
        .lock               # per-fingerprint sentinel (touched before write, removed after)
        backtests/
          {fingerprint}.json  # backtest result dict (keyed by backtest fingerprint)
      index.json            # LRU tracking: {fingerprint: {last_accessed, created_at, size_bytes}}

Fingerprint formula (see compute_model_fingerprint()):
    SHA256(csv_bytes | sorted_channel_columns | mcmc_config_identity)[:16]

    Depends on: CSV content, channel selection, MCMC identity (chains/draws/tune/target_accept).
    Does NOT depend on: code git SHA, deploy timestamp, or anything else that changes
    on every deploy — so the cache survives fly deploy.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Schema / constants
# ---------------------------------------------------------------------------

SCHEMA_VERSION = 1
"""Bump when the stored layout changes (new mandatory fields in meta.json,
different serialisation format, etc.).  On load, version mismatch ⟹ evict.
"""

MAX_ENTRIES: int = int(os.environ.get("MIXLIFT_MODEL_CACHE_MAX", "20"))
"""Maximum number of fingerprint entries to keep on disk.  LRU eviction."""

_CACHE_DIR_ENV = "MIXLIFT_MODEL_CACHE_DIR"
_DEFAULT_LOCAL_CACHE = Path.home() / ".mixlift" / "model_cache"
_PRODUCTION_CACHE = Path("/cache/models")


# ---------------------------------------------------------------------------
# Directory helpers
# ---------------------------------------------------------------------------


def cache_dir() -> Path:
    """Return the versioned cache root, creating it if necessary.

    Priority:
    1. ``$MIXLIFT_MODEL_CACHE_DIR`` env var (explicit override)
    2. ``/cache/models`` when that path is writable (Fly volume on production)
    3. ``~/.mixlift/model_cache`` (local pip-install path)

    Raises ``RuntimeError`` if no writable directory can be found — callers
    should catch this and fall back to in-memory-only mode.
    """
    env_val = os.environ.get(_CACHE_DIR_ENV)
    if env_val:
        base = Path(env_val)
    elif _PRODUCTION_CACHE.parent.exists() and os.access(_PRODUCTION_CACHE.parent, os.W_OK):
        base = _PRODUCTION_CACHE
    else:
        base = _DEFAULT_LOCAL_CACHE

    versioned = base / f"v{SCHEMA_VERSION}"
    versioned.mkdir(parents=True, exist_ok=True)
    return versioned


def _entry_dir(fingerprint: str) -> Path:
    return cache_dir() / fingerprint


def _index_path() -> Path:
    return cache_dir().parent / "index.json"


# ---------------------------------------------------------------------------
# Fingerprint
# ---------------------------------------------------------------------------


def compute_model_fingerprint(
    csv_bytes: bytes,
    channel_columns: list[str],
    mcmc_config: dict[str, Any] | None = None,
    *,
    backtest_config: dict[str, Any] | None = None,
) -> str:
    """Compute a stable 16-char cache fingerprint.

    The fingerprint encodes exactly what makes two fits equivalent:
    - CSV content (byte-level hash, captures every row/column change)
    - Channel column selection (sorted for order-independence)
    - MCMC identity: chains, draws, tune, target_accept

    When ``backtest_config`` is provided the fingerprint is intentionally
    distinct from the plain model fingerprint so backtest results and model
    artefacts never collide.  The backtest suffix appended to the hash input
    (before hashing) is::

        |backtest=v1|n_folds={n_folds}|horizon={horizon}

    where ``n_folds`` and ``horizon`` come from ``backtest_config``.

    NOT included: code version, git SHA, deploy timestamp, model class name.
    This means the cache survives ``fly deploy`` as long as the CSV + channels
    + sampler config are the same.

    Args:
        csv_bytes: Raw bytes of the CSV file.
        channel_columns: Column names used as channels (raw, not display names).
        mcmc_config: Dict with keys chains/draws/tune/target_accept (optional;
            defaults from MCP_CONFIG are used when not provided).
        backtest_config: When present, produces a backtest-specific fingerprint.
            Recognised keys: ``n_folds`` (int), ``horizon`` (int).

    Returns:
        16-character hex string.
    """
    from mixlift.modeling.defaults import MCP_CONFIG

    cfg = {**MCP_CONFIG, **(mcmc_config or {})}
    config_identity = (
        f"chains={cfg.get('chains', 4)}"
        f"|draws={cfg.get('draws', 250)}"
        f"|tune={cfg.get('tune', 500)}"
        f"|target_accept={cfg.get('target_accept', 0.9)}"
    )
    sorted_channels = "|".join(sorted(channel_columns))
    prefix = f"{sorted_channels}|{config_identity}"
    if backtest_config is not None:
        n_folds = backtest_config.get("n_folds", "")
        horizon = backtest_config.get("horizon", "")
        prefix += f"|backtest=v1|n_folds={n_folds}|horizon={horizon}"
    raw = prefix.encode() + csv_bytes
    return hashlib.sha256(raw).hexdigest()[:16]


def compute_backtest_fingerprint(
    csv_bytes: bytes,
    channel_columns: list[str],
    mcmc_config: dict[str, Any] | None = None,
    n_folds: int = 0,
    horizon: int = 0,
) -> str:
    """Compute the backtest-specific fingerprint (wraps compute_model_fingerprint).

    Convenience helper so callers don't have to construct ``backtest_config``
    manually.

    Args:
        csv_bytes: Raw bytes of the CSV file.
        channel_columns: Column names used as channels.
        mcmc_config: MCMC config dict (same semantics as compute_model_fingerprint).
        n_folds: Number of backtest folds.
        horizon: Holdout horizon in weeks.

    Returns:
        16-character hex string distinct from the plain model fingerprint.
    """
    return compute_model_fingerprint(
        csv_bytes,
        channel_columns,
        mcmc_config,
        backtest_config={"n_folds": n_folds, "horizon": horizon},
    )


# ---------------------------------------------------------------------------
# Index (LRU tracking)
# ---------------------------------------------------------------------------


def _read_index() -> dict[str, dict]:
    path = _index_path()
    try:
        if path.exists():
            return json.loads(path.read_text())
    except Exception as exc:
        logger.warning(f"model_cache: could not read index ({exc}); starting fresh")
    return {}


def _write_index(index: dict[str, dict]) -> None:
    path = _index_path()
    try:
        path.write_text(json.dumps(index, indent=2, default=str))
    except Exception as exc:
        logger.warning(f"model_cache: could not write index ({exc})")


def _touch_index(fingerprint: str, *, created: bool = False, size_bytes: int = 0) -> None:
    """Update last_accessed (and optionally created_at/size_bytes) in the index."""
    index = _read_index()
    now = datetime.now(tz=timezone.utc).isoformat()
    if fingerprint not in index or created:
        index[fingerprint] = {
            "created_at": now,
            "last_accessed": now,
            "size_bytes": size_bytes,
        }
    else:
        index[fingerprint]["last_accessed"] = now
    _write_index(index)


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------


async def save_model(
    fingerprint: str,
    *,
    mmm: Any,
    X: pd.DataFrame,  # noqa: N803
    y: pd.Series | None = None,
    channel_columns: list[str],
    result: dict,
    mcmc_config: dict[str, Any] | None = None,
) -> None:
    """Persist a fitted model bundle to disk.  Idempotent on fingerprint.

    Serialisation strategy:
    - ``mmm.save(path)``  → ArviZ InferenceData as NetCDF (.nc), via
      ``pymc_marketing.model_builder.ModelBuilder.save()``.  This stores the
      full posterior + model config inside the NetCDF attrs so ``MMM.load()``
      can reconstruct the object without re-fitting.
    - ``X.to_parquet()``  → Parquet via pandas (preserves dtypes cleanly).
    - ``y.to_frame().to_parquet()``  → Parquet (numeric Series, revenue targets).
    - ``result``          → JSON (the dict returned to Claude).
    - ``meta.json``       → channel_columns, created_at, schema_version, mcmc_config.

    Falls back gracefully (logs a warning) if the cache directory is
    unwritable — the in-memory cache continues working normally.

    Args:
        fingerprint: Content-based fingerprint from ``compute_model_fingerprint()``.
        mmm: Fitted ``pymc_marketing.mmm.MMM`` instance.
        X: Feature DataFrame used for the fit.
        y: Revenue target Series aligned to X's index.
        channel_columns: Raw channel column names.
        result: The tool-response dict (what was returned to Claude).
        mcmc_config: MCMC config used for the fit (for meta.json).
    """
    try:
        entry = _entry_dir(fingerprint)
        lock = entry.parent / f"{fingerprint}.lock"

        # Skip if already fully written (idempotent)
        if (entry / "meta.json").exists() and not lock.exists():
            logger.debug(f"model_cache: {fingerprint} already on disk, skipping save")
            return

        # Touch lock before writing to guard against concurrent saves
        lock.touch()
        entry.mkdir(parents=True, exist_ok=True)

        # --- 1. MMM InferenceData via NetCDF ---
        mmm_path = entry / "mmm.nc"
        await asyncio.to_thread(mmm.save, str(mmm_path))

        # --- 2. Feature matrix ---
        x_path = entry / "X.parquet"
        await asyncio.to_thread(X.to_parquet, str(x_path), index=True)

        # --- 2b. Revenue target Series ---
        if y is not None:
            y_path = entry / "y.parquet"
            _y_df = y.to_frame(name="y") if hasattr(y, "to_frame") else pd.DataFrame({"y": y})
            await asyncio.to_thread(_y_df.to_parquet, str(y_path), index=True)

        # --- 3. Result dict ---
        result_path = entry / "result.json"
        result_path.write_text(json.dumps(result, default=str))

        # --- 4. Meta ---
        meta = {
            "schema_version": SCHEMA_VERSION,
            "created_at": datetime.now(tz=timezone.utc).isoformat(),
            "channel_columns": channel_columns,
            "mcmc_config": mcmc_config or {},
        }
        (entry / "meta.json").write_text(json.dumps(meta, indent=2, default=str))

        # Size estimate
        size = sum(f.stat().st_size for f in entry.iterdir() if f.is_file())
        _touch_index(fingerprint, created=True, size_bytes=size)

        # Remove lock after successful write
        lock.unlink(missing_ok=True)

        logger.info(
            f"model_cache: saved {fingerprint} "
            f"({size / 1_048_576:.1f} MB, {len(channel_columns)} channels)"
        )

        # Evict LRU entries if over limit
        evict_lru(MAX_ENTRIES)

    except Exception as exc:
        logger.warning(
            f"model_cache: save failed for {fingerprint} ({exc}); "
            "falling back to in-memory cache only"
        )
        # Remove partial entry to avoid corrupt loads
        try:
            entry_path = _entry_dir(fingerprint)
            if entry_path.exists():
                shutil.rmtree(entry_path, ignore_errors=True)
            lock_path = _entry_dir(fingerprint).parent / f"{fingerprint}.lock"
            lock_path.unlink(missing_ok=True)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------


async def load_model(fingerprint: str) -> dict | None:
    """Load a cached model bundle from disk.

    Returns the same shape dict as ``_MODEL_CACHE[fingerprint]``:
        {
            "mmm": MMM,
            "X": DataFrame,
            "y": Series | None,
            "channel_columns": list[str],
            "model_results": ModelResults,   # reconstructed
            "result": dict,
        }

    Returns ``None`` on miss, schema mismatch, corrupt file, or any error.
    On schema mismatch or corruption the entry is evicted.
    """
    entry = _entry_dir(fingerprint)
    meta_path = entry / "meta.json"

    if not meta_path.exists():
        return None  # Clean miss

    # Guard: lock present means a write is in progress — skip to avoid half-baked load
    lock = entry.parent / f"{fingerprint}.lock"
    if lock.exists():
        logger.debug(f"model_cache: {fingerprint} is being written, skipping load")
        return None

    try:
        meta = json.loads(meta_path.read_text())

        # Schema version check
        if meta.get("schema_version") != SCHEMA_VERSION:
            logger.info(
                f"model_cache: schema mismatch for {fingerprint} "
                f"(stored={meta.get('schema_version')}, expected={SCHEMA_VERSION}); evicting"
            )
            _evict_entry(fingerprint)
            return None

        channel_columns: list[str] = meta["channel_columns"]

        # --- Load MMM ---
        mmm_path = entry / "mmm.nc"
        if not mmm_path.exists():
            logger.warning(f"model_cache: mmm.nc missing for {fingerprint}; evicting")
            _evict_entry(fingerprint)
            return None

        import warnings as _warnings

        with _warnings.catch_warnings():
            _warnings.filterwarnings("ignore", category=FutureWarning)
            from pymc_marketing.mmm.mmm import MMM

        mmm = await asyncio.to_thread(MMM.load, str(mmm_path))

        # --- Load X ---
        x_path = entry / "X.parquet"
        X = await asyncio.to_thread(pd.read_parquet, str(x_path))  # noqa: N806

        # --- Load y Series (optional — may be absent in old cache entries) ---
        y_series: pd.Series | None = None
        y_path = entry / "y.parquet"
        if y_path.exists():
            try:
                _y_df = await asyncio.to_thread(pd.read_parquet, str(y_path))
                y_series = _y_df["y"]
            except Exception as _y_exc:
                logger.warning(f"model_cache: y.parquet load failed for {fingerprint} ({_y_exc})")
        # Fallback for old entries without y.parquet: use mmm.y attribute
        if y_series is None and hasattr(mmm, "y") and mmm.y is not None:
            try:
                _raw = mmm.y.values if hasattr(mmm.y, "values") else mmm.y
                y_series = pd.Series(_raw, index=X.index, name="y")
                logger.debug(f"model_cache: y reconstructed from mmm.y for {fingerprint}")
            except Exception as _mmm_y_exc:
                logger.warning(
                    f"model_cache: mmm.y fallback failed for {fingerprint} ({_mmm_y_exc})"
                )

        # --- Load result dict ---
        result_path = entry / "result.json"
        result = json.loads(result_path.read_text())

        # --- Reconstruct ModelResults ---
        # raw_contributions is recomputed (xarray, cheap from loaded posterior)
        model_results = _reconstruct_model_results(mmm, X, channel_columns)

        # Update LRU index
        _touch_index(fingerprint)

        logger.info(f"model_cache: loaded {fingerprint} from disk (hit)")
        return {
            "mmm": mmm,
            "X": X,
            "y": y_series,
            "channel_columns": channel_columns,
            "model_results": model_results,
            "result": result,
        }

    except Exception as exc:
        logger.warning(
            f"model_cache: load failed for {fingerprint} ({exc}); evicting corrupt entry"
        )
        _evict_entry(fingerprint)
        return None


# ---------------------------------------------------------------------------
# Backtest cache
# ---------------------------------------------------------------------------


def _backtest_dir() -> Path:
    """Return the backtest cache directory, creating it if necessary."""
    bt_dir = cache_dir() / "backtests"
    bt_dir.mkdir(parents=True, exist_ok=True)
    return bt_dir


def save_backtest(fingerprint: str, backtest: dict) -> None:
    """Persist a backtest result dict to disk under the given fingerprint.

    Overwrites any prior entry.  Silent no-op on write failure (logs warning).

    The file is stored as JSON at::

        {cache_root}/backtests/{fingerprint}.json

    Args:
        fingerprint: Backtest-specific fingerprint from
            ``compute_backtest_fingerprint()`` or
            ``compute_model_fingerprint(..., backtest_config=...)``.
        backtest: Plain dict (e.g. ``asdict(BacktestResult)``).
    """
    try:
        path = _backtest_dir() / f"{fingerprint}.json"
        path.write_text(json.dumps(backtest, default=str))
        logger.debug(f"model_cache: backtest saved for {fingerprint}")
    except Exception as exc:
        logger.warning(f"model_cache: backtest save failed for {fingerprint} ({exc})")


def load_backtest(fingerprint: str) -> dict | None:
    """Load a backtest result dict.  Returns None if not cached or corrupted.

    Must be fast — this is on the hot path for repeat mixlift_analyze calls.

    Args:
        fingerprint: The same fingerprint passed to ``save_backtest()``.

    Returns:
        The backtest dict, or ``None`` on miss or parse error.
    """
    path = _backtest_dir() / f"{fingerprint}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        logger.warning(f"model_cache: backtest load failed for {fingerprint} ({exc}); ignoring")
        return None


def _reconstruct_model_results(  # noqa: N803
    mmm: Any,
    X: pd.DataFrame,  # noqa: N803
    channel_columns: list[str],
) -> Any:
    """Reconstruct a ModelResults from a loaded MMM + X.

    We don't persist ModelResults directly because it holds the xarray
    raw_contributions DataArray (which is a derived quantity) and a reference
    to the MMM itself.  Both are cheap to recompute from the loaded posterior.

    The reconstructed ModelResults is functionally equivalent for all downstream
    tools (mixlift_scenario, mixlift_forecast).
    """
    from mixlift.modeling.engine import (
        ModelResults,
        extract_channel_contributions,
        extract_marginal_roas,
        extract_roas,
    )
    from mixlift.modeling.optimizer import format_channel_name

    raw_contributions = mmm.compute_channel_contribution_original_scale()
    contributions, contributions_ci = extract_channel_contributions(
        mmm, X, channel_columns, contributions=raw_contributions
    )
    roas, roas_ci = extract_roas(mmm, X, channel_columns, contributions=raw_contributions)
    marginal_roas, marginal_roas_ci = extract_marginal_roas(mmm, X, channel_columns)

    total_spend = {format_channel_name(ch): float(X[ch].sum()) for ch in channel_columns}

    return ModelResults(
        channel_contributions=contributions,
        channel_contributions_ci=contributions_ci,
        roas_estimates=roas,
        roas_ci=roas_ci,
        marginal_roas_estimates=marginal_roas,
        marginal_roas_ci=marginal_roas_ci,
        total_spend=total_spend,
        duration_secs=0.0,  # no MCMC was run
        mmm=mmm,
        convergence_warnings=[],  # already checked at fit time
        raw_contributions=raw_contributions,
        loo_cv={},
        intercept_decomposition={},
    )


# ---------------------------------------------------------------------------
# Eviction
# ---------------------------------------------------------------------------


def _evict_entry(fingerprint: str) -> None:
    """Remove a single cache entry from disk and index."""
    try:
        entry = _entry_dir(fingerprint)
        if entry.exists():
            shutil.rmtree(entry, ignore_errors=True)
        index = _read_index()
        index.pop(fingerprint, None)
        _write_index(index)
        logger.debug(f"model_cache: evicted {fingerprint}")
    except Exception as exc:
        logger.warning(f"model_cache: eviction error for {fingerprint}: {exc}")


def evict_lru(max_entries: int = MAX_ENTRIES) -> int:
    """Trim the cache to at most ``max_entries`` entries, evicting least-recently-used.

    Returns the count of entries evicted.
    """
    index = _read_index()
    if len(index) <= max_entries:
        return 0

    # Sort by last_accessed ascending (oldest first)
    ordered = sorted(
        index.items(),
        key=lambda kv: kv[1].get("last_accessed", ""),
    )
    to_evict = ordered[: len(index) - max_entries]
    for fp, _ in to_evict:
        _evict_entry(fp)
    logger.info(f"model_cache: LRU evicted {len(to_evict)} entries (max={max_entries})")
    return len(to_evict)


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------


def list_cached() -> list[dict]:
    """Return summary info for each cached entry, sorted by recency.

    Used by /status diagnostics.  Returns::

        [
          {
            "fingerprint": "a1b2c3d4...",
            "age_days": 2.3,
            "size_mb": 45.1,
            "created_at": "2026-04-13T10:00:00+00:00",
            "last_accessed": "2026-04-14T08:30:00+00:00",
          },
          ...
        ]
    """
    index = _read_index()
    now = datetime.now(tz=timezone.utc)
    rows = []
    for fp, info in index.items():
        try:
            created_str = info.get("created_at", "")
            created_dt = datetime.fromisoformat(created_str) if created_str else now
            age_days = (now - created_dt).total_seconds() / 86400
        except Exception:
            age_days = 0.0
        rows.append(
            {
                "fingerprint": fp,
                "age_days": round(age_days, 2),
                "size_mb": round(info.get("size_bytes", 0) / 1_048_576, 2),
                "created_at": info.get("created_at", ""),
                "last_accessed": info.get("last_accessed", ""),
            }
        )
    rows.sort(key=lambda r: r["last_accessed"], reverse=True)
    return rows
