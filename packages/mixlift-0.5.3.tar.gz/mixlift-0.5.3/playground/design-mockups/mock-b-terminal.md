```
MMM READOUT · 51W × 8CH · R²=0.84 · MAPE=3.9%
─────────────────────────────────────────────────────────────────

CHANNEL           ROAS    SPEND/WK      Δ OPTIMAL    MARGINAL
─────────────────────────────────────────────────────────────────
Email            24.60×   $    801     +$  7,135    ████████████
TikTok            1.21×   $  7,065     +$    871    ▌
Influencer        1.17×   $  3,349     +$  4,587    ▌
Google Search     1.10×   $ 13,539     −$  5,603    ▌
Meta              1.02×   $ 18,071     −$ 10,135    ▏
Google Display    0.92×   $  4,871     +$  3,065    ▏
Brand Campaigns   0.89×   $  9,643     −$  1,707    ▏
TV                0.47×   $  6,145     +$  1,791    ▏
─────────────────────────────────────────────────────────────────
TOTAL                     $ 63,484           $0

EXPECTED LIFT     +12.1%  revenue at equal spend
CONFIDENCE        high    R²=0.84 · MAPE=3.9% · R̂<1.01

MOVES
  01  META      −$10,135/wk   saturation >$8K, marginal $1.02
  02  EMAIL     +$ 7,135/wk   10× underfed, 24.6× ROAS
  03  GSEARCH   −$ 5,603/wk   low incrementality on brand terms
```

---
*4 chains · 250 draws · no divergences · full posterior attached*
