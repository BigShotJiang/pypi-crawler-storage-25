*Across 51 weeks and 8 channels. Model R² = 0.84, MAPE = 3.9%.*

## The thesis

Email earns **$24.60 per dollar** at the smallest budget in your mix. Meta and Google Search earn roughly $1 per dollar at 17× the spend. A flat reallocation projects **+12% revenue at equal total spend**.

## Channel performance

| Channel         |   ROAS | Weekly spend | Δ to optimal |
|-----------------|-------:|-------------:|-------------:|
| Email           | 24.60× |         $801 | **+$7,135**  |
| TikTok          |  1.21× |       $7,065 |         +$871 |
| Influencer      |  1.17× |       $3,349 |       +$4,587 |
| Google Search   |  1.10× |      $13,539 |       −$5,603 |
| Meta            |  1.02× |      $18,071 |  **−$10,135** |
| Google Display  |  0.92× |       $4,871 |       +$3,065 |
| Brand Campaigns |  0.89× |       $9,643 |       −$1,707 |
| TV              |  0.47× |       $6,145 |       +$1,791 |

*Sorted by marginal return. Total weekly spend held at $63,484.*

## What to do first

1. **Pull $10K/wk from Meta.** Saturation is evident past $8K; the marginal dollar returns $1.02.
2. **10× your email budget** from $800 → $8,000/wk. The list is the asset; the channel is under-fed.
3. **Cut Google Search brand defense by $5K/wk.** Incrementality at current spend is low.

---
*51 weeks · 8 channels · 4 chains · 250 draws · all R̂ < 1.01*
