**51 weeks · 8 channels · R² 0.84 · MAPE 3.9%**

## Your mix is leaving ~12% of revenue on the table.

Email earns **$24.60 per dollar** at $801/wk — the highest ROAS in your mix, at the smallest budget. Meta and Google Search earn roughly $1 per dollar at 17× the spend.

A flat reallocation to $7,936/channel projects **+12.1% revenue at equal total spend**.

### Where your dollars are working

| Channel         |   ROAS | Spend/wk | Change to optimal |          |
|-----------------|-------:|---------:|------------------:|:---------|
| **Email**       | 24.60× |     $801 |      **+$7,135**  | ████████ |
| TikTok          |  1.21× |   $7,065 |             +$871 | ▌        |
| Influencer      |  1.17× |   $3,349 |           +$4,587 | ███      |
| Google Search   |  1.10× |  $13,539 |           −$5,603 | ███▌     |
| Meta            |  1.02× |  $18,071 |     **−$10,135**  | ██████▌  |
| Google Display  |  0.92× |   $4,871 |           +$3,065 | ██       |
| Brand Campaigns |  0.89× |   $9,643 |           −$1,707 | █        |
| TV              |  0.47× |   $6,145 |           +$1,791 | █        |

### Three moves for this week

> **1. Pull $10K/wk from Meta.** Saturation is clear past $8K/wk; the marginal dollar is returning $1.02.
>
> **2. Multiply Email 10×**, from $800 → $8,000/wk. The list is your asset; the channel is under-fed.
>
> **3. Cut Google Search brand defense by $5K/wk.** Incrementality on brand terms is weak at current spend.

*Modeled on 51 weeks of weekly data. Posterior: 4 chains × 250 draws, all R̂ < 1.01, no divergences.*
