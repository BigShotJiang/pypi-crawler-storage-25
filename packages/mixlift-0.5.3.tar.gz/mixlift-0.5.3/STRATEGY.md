# MixLift Strategy

*Cross-Functional Phase 0-2 Synthesis | Updated March 7, 2026 | Confidential*

*This document synthesizes findings from two rounds of independent leadership audits (Engineering, Product, Strategy, Data Science, Marketing) conducted after Phase 0-1 implementation. Updated March 7 to reflect shipped infrastructure and codebase advances per OPERATING_PLAN.md Appendix C. Should be reviewed every Monday.*

---

## The North Star

**MixLift is the tool that turns every marketer's ad spend data into a dollar-denominated action plan they trust enough to act on -- delivered in minutes, for $299/month, inside the AI assistant they already use.**

The key words are *dollar-denominated*, *trust*, *act on*, and *already use*. If any part of the product fails one of those tests, it is not done.

---

# Section I: Executive Summary -- Phase 0-1 Results

## Execution Scorecard

| Phase | Deliverables | Shipped | Status |
|---|---|---|---|
| **Phase 0** | 10 | 10 | 100% -- all items shipped including infrastructure |
| **Phase 1A** | 7 | 7 | 100% -- all output quality features shipped, headless API ahead of schedule |
| **Total** | 17 | 17 | 100% completion rate |

**What changed (March 7 update):** All infrastructure blockers are resolved. v0.2.0 is on PyPI. License API is live at api.mixlift.io. Stripe webhooks are connected. A stranger can `pip install mixlift`, pay $299, and run an analysis today. Additionally, multiple Week 4-8 items shipped ahead of schedule: holiday controls, contextual memory, free tier metering, headless API license gate, posterior predictive, and 4-chain MCMC config.

**Execution grade: A.** Full code and infrastructure execution. The product is ready to sell. The constraint is now customers, not code.

### Phase 0 Detail

| Deliverable | Status | Notes |
|---|---|---|
| CI/CD pipeline | DONE | GitHub Actions, pytest+ruff, Python 3.11/3.12, tag-based PyPI release |
| Config lazy init | DONE | `ensure_directories()` no longer called on import |
| Secret key validation | DONE | Raises in production if default used |
| Channel display names | DONE | Centralized `format_channel_name()` in `optimizer.py:12-29` |
| Pricing correction | DONE | All messages say "$299/mo" and "Growth" |
| Free tier limits | DONE | 2 channels, 2,000 rows in `license.py` and `config.py` |
| MCP_FAST_CONFIG removal | DONE | 2 chains, 500 tune, 250 draws. No 1-chain config |
| PyMC-Marketing pin | DONE | `pymc-marketing>=0.9,<1.0` in `pyproject.toml` |
| Deploy license API | SHIPPED | api.mixlift.io is live. Health check passing. License validation operational. |
| Publish to PyPI | SHIPPED | v0.2.0 published. `pip install mixlift` works. |

### Phase 1A Detail

| Deliverable | Status | Location |
|---|---|---|
| Dollar-value headline | DONE | `server.py:486` -- Free shows %, paid shows $ |
| Saturation traffic lights | DONE | `server.py:282-337` -- green/yellow/red with interpolated % |
| Budget reallocation (% + $) | DONE | Plain English labels with percentages and dollars |
| Confidence explainer | DONE | `server.py:382-408` -- high/moderate/low per channel |
| Model fit summary | DONE | `server.py:412-445` -- R-squared, MAPE (see Section II, #8) |
| Headless Python API | DONE | `mixlift/api.py` (141 lines), exposed via `mixlift/__init__.py` |
| Scenario mode | DONE | `server.py:739-809` -- "cut X by Y%", "increase X by $Y", "move $Y from X to Z" |

---

# Section II: What We Learned

These findings emerged from cross-referencing all leadership audits against the actual codebase. They are the ground truth of where MixLift stands today.

### 1. Code velocity =/= deployment velocity

All code items shipped. Zero infrastructure items shipped. The sprint plan optimized for code velocity and had no explicit "deploy" phase. Deployment must be treated as its own workstream with its own timeline, not a line item in a feature sprint.

### 2. The output transformation worked

Dollar headlines ("MixLift found $47,000/week in budget optimization opportunity"), saturation traffic lights ("Meta is 78% saturated"), and confidence summaries make the product VP-of-Marketing readable. The free-to-paid gate (percentages vs. dollars) is more elegant than designed. **This is the moat layer.** Do not weaken the dollar-headline gate.

### 3. Tests now pass

Test assertions have been corrected for the updated display names (TikTok, TV, SEO) and tier limits. CI should pass once changes are committed and pushed.

### 4. The tier naming is a latent revenue-blocking bug (RESOLVED)

~~`license.py` line 52 checks for `data.get("tier") == "pro"` from the API response.~~ **SHIPPED:** `api.py:90` now accepts both "pro" and "growth" tier values.

### 5. The 180-day minimum was softened (RESOLVED)

Strategy Decision #9 specified: "Accept shorter time ranges with explicit accuracy caveats. 90 days minimum." This has been implemented: `server.py:164` now hard-blocks at 90 days instead of 180. `_check_date_range_warnings()` at `server.py:174-195` warns for 90-179 days with explicit accuracy caveats. **Note:** `ingest/service.py` still uses 180-day minimum for platform CSV path -- must be aligned to 90 days.

### 6. Free tier is unlimited in practice (RESOLVED)

~~No usage metering exists in the MCP server.~~ **SHIPPED:** `metering.py` enforces 2 runs/month on the MCP path with monthly reset.

### 7. The headless API has no license gate (RESOLVED)

~~`mixlift/api.py` has zero license validation.~~ **SHIPPED:** `api.py` now validates license, enforces tier limits, and redacts dollar values for free tier.

### 8. Model fit metrics silently return nothing (RESOLVED)

~~`_compute_model_fit()` depends on `posterior_predictive` samples, which PyMC-Marketing does not generate by default.~~ **SHIPPED:** `engine.py:127` now calls `sample_posterior_predictive()` during model fitting.

### 9. No seasonal or holiday controls (RESOLVED)

~~`add_control_columns()` in `preprocessing.py` only adds a linear trend.~~ **SHIPPED:** `preprocessing.py` now includes auto-detected US holidays via the `holidays` package, cyclical month encoding (sin/cos), and a Q4 indicator.

### 10. Free tier leaks dollar values (NEW)

The free tier suppresses dollar headlines but `budget_optimization.current_allocation` and `optimal_allocation` still show raw dollar amounts. A sophisticated user can calculate the exact dollar opportunity from the optimization data. The paywall gate is bypassed for anyone who reads the JSON.

### 11. Raw saturation curves are useless in MCP context (NEW)

`saturation_curves` dumps 100 spend/response data points per channel (1,600 points for 8 channels). Claude cannot render charts. This data inflates token usage and degrades summarization quality. Keep traffic lights, strip raw curves from MCP output.

### 12. MCMC config insufficient for reliable diagnostics (RESOLVED)

~~2 chains is the absolute minimum for R-hat computation.~~ **SHIPPED:** `defaults.py` now uses 4 chains x 250 draws with target_accept=0.90.

---

# Section III: Revised Risk Matrix

Merged and deduplicated from all leadership audits. Ordered by severity.

| # | Risk | Severity | Source | Mitigation |
|---|---|---|---|---|
| 1 | ~~Cannot charge anyone~~ | ~~CRITICAL~~ | -- | **RESOLVED.** License API live at api.mixlift.io. v0.2.0 on PyPI. Stripe connected. |
| 2 | ~~Tier naming mismatch~~ | ~~HIGH~~ | -- | **RESOLVED.** `api.py:90` accepts both "pro" and "growth". |
| 3 | ~~Tests broken~~ | ~~HIGH~~ | -- | **RESOLVED.** Tests passing. CI green. |
| 4 | ~~No retention mechanic (stateless)~~ | ~~HIGH~~ | -- | **RESOLVED.** Contextual memory shipped in `memory.py` + `server.py`. |
| 5 | ~~No seasonal/holiday controls~~ | ~~HIGH~~ | -- | **RESOLVED.** Auto-detected US holidays shipped in `preprocessing.py`. |
| 6 | ~~Free tier unlimited (no metering)~~ | ~~MEDIUM~~ | -- | **RESOLVED.** Local run counter shipped in `metering.py` (2 runs/month). |
| 7 | ~~Model fit silently empty~~ | ~~MEDIUM~~ | -- | **RESOLVED.** `sample_posterior_predictive()` added to `engine.py`. |
| 8 | **Scenario mode lacks confidence intervals** | MEDIUM | PM + DS | Point estimates without CI risk wrong recommendations. Add CIs Week 7-8. |
| 9 | ~~MCMC config insufficient~~ | ~~MEDIUM~~ | -- | **RESOLVED.** 4 chains x 250 draws, target_accept=0.90 in `defaults.py`. |
| 10 | ~~Headless API bypasses monetization~~ | ~~MEDIUM~~ | -- | **RESOLVED.** License gate shipped in `api.py`. |
| 11 | **Free tier dollar leak** | MEDIUM | PM | `budget_optimization` output shows dollar values, undermining paywall. Redact Week 4. |
| 12 | **MCMC timeout on large datasets** | MEDIUM | EM | Model caching for repeat runs. Reduce problem size for MCP path. |
| 13 | **Circular import fragility (engine <-> optimizer)** | LOW | EM | Move `format_channel_name()` to `mixlift/modeling/utils.py`. |
| 14 | **No data length warnings** | LOW | DS Manager | Analyses with <26 weeks treated same as 52+. Add "exploratory" badge. |

### Unchanged Strategic Risks

These risks from the original strategy remain valid and unchanged:

| Risk | Severity | Probability | Mitigation |
|---|---|---|---|
| **PyMC-Marketing ships a product** | HIGH | MEDIUM | Ship faster. Build moats they will not build: data normalization, memory, dollar-value output, agency features. |
| **Anthropic platform dependency** | HIGH | MEDIUM | Headless Python API already shipped. REST API in Phase 2. MCP is channel one, not the only channel. |
| **LLM hallucination erodes trust** | HIGH | HIGH | MixLift returns deterministic JSON. Add "verified by MixLift" markers. Add interpretation guidelines in tool description. |
| **High churn (>5% monthly)** | HIGH | HIGH | Build memory, comparison, scenario features. Make MixLift a monthly workflow, not a one-shot tool. |
| **Prescient/Paramark drops prices** | HIGH | LOW | Stay 3-5x cheaper. Emphasize zero-onboarding AI-native UX. |
| **Triple Whale deepens MMM** | HIGH | HIGH | Triple Whale has massive DTC distribution. If they ship real Bayesian MMM at $199/mo, we cannot compete on distribution. Speed is the defense. |
| **MCP marketplace does not gain traction** | MEDIUM | MEDIUM | Headless API + Python library as backup distribution. Direct content marketing to DTC communities. |

---

# Section IV: Revised Sprint Plan

## Week 3 -- "SHIP THE BUSINESS" (Infrastructure Only) -- COMPLETE

All items shipped. v0.2.0 on PyPI. License API live. Stripe connected. End-to-end stranger test passes.

| # | Deliverable | Status |
|---|---|---|
| 1 | Commit all pending changes, push to main | SHIPPED |
| 2 | Fix free tier limits in code | SHIPPED |
| 3 | Fix tier naming in `license.py` | SHIPPED |
| 4 | Fix all broken test assertions | SHIPPED |
| 5 | Deploy license API to `api.mixlift.io` on Render | SHIPPED |
| 6 | Connect Stripe webhooks, verify payment flow | SHIPPED |
| 7 | Publish to PyPI (v0.2.0) | SHIPPED |
| 8 | End-to-end stranger test | SHIPPED |

**Exit criteria met:** A stranger can `pip install mixlift`, pay $299, and run an analysis.

## Week 4-5 -- "Fix What We Found"

Quality, correctness, and conversion fixes from the Phase 0-1 audit. Many items shipped ahead of schedule.

| # | Deliverable | Effort | Priority | Status |
|---|---|---|---|---|
| 1 | Add `sample_posterior_predictive()` to `fit_model()` | M | P1 | SHIPPED |
| 2 | Add license gate to headless API (`analyze()`) | M | P1 | SHIPPED |
| 3 | Redact dollar values from optimization output for free tier | S | P1 | OPEN |
| 4 | Update MCMC config: 4 chains x 250 draws, target_accept=0.90 | S | P1 | SHIPPED |
| 5 | Auto-detect US holidays (add `holidays` package to controls) | M | P1 | SHIPPED |
| 6 | Add "Exploratory Analysis" badge for analyses with <26 weeks of data | S | P1 | OPEN |
| 7 | Basic usage metering: local run counter (MCP path) | S | P1 | SHIPPED |
| 8 | Strip raw saturation curves from MCP output (keep traffic lights) | S | P2 | OPEN |
| 9 | Extract shared CSV logic from `server.py` into `mixlift/ingest/loader.py` | M | P2 | SHIPPED |
| 10 | Align `ingest/service.py` date validation from 180 to 90 days | S | P1 | OPEN |
| 11 | Add unit tests for Phase 1A functions | M | P2 | OPEN |

## Week 5-6 -- "GET CUSTOMERS" (GTM Launch)

| # | Deliverable | Owner | Definition of Done |
|---|---|---|---|
| 1 | Record 2-minute demo video | Founder | Shows full flow: CSV drop -> Claude -> dollar-value result |
| 2 | Write 1 case study with real dollar numbers | Founder | Anonymized real data analysis. Published on landing page. |
| 3 | Build landing page at mixlift.io | Founder | Headline, demo video, pricing, install instructions, CTA |
| 4 | MCP marketplace listing | Founder | MixLift listed with description, screenshots, install instructions |
| 5 | Founder-led outreach: 20 DTC brands | Founder | Personalized LinkedIn DMs to Directors/VPs of Growth. Offer live demo on their data. |
| 6 | Concierge demos: 2+ per week | Founder | Sit on Zoom, run MixLift on their data live, show dollar-value output |
| 7 | Community seeding | Founder | 2-3 posts on r/dtc, r/PPC, Twitter sharing anonymized results |

**Target: 5 paying customers by end of Week 6.**

## Week 7-8 -- "RETAIN THEM"

| # | Deliverable | Owner | Priority |
|---|---|---|---|
| 1 | **Contextual memory v1** | Eng | SHIPPED -- `memory.py` + `server.py` integration. Fingerprinting, deltas, CI overlap heuristic. |
| 2 | Server-side usage metering | Eng | `analysis_runs` table in license API. MCP server reports usage. Monthly limits enforced. |
| 3 | License fallback decision: fail-closed with grace period | Eng + Strategy | Paid features fail-closed when API unreachable. 24-hour grace window for outages. |
| 4 | Add confidence intervals to scenario mode | Eng | Propagate posterior uncertainty through scenario projections. |
| 5 | Continue outreach, close to 10 customers | Founder | |

**Target: 10 paying customers by end of Week 8 (Day 56). Memory shipped before first billing renewal.**

## Week 9-10 -- "LEARN AND ITERATE"

| # | Deliverable | Owner |
|---|---|---|
| 1 | Churn analysis from first cohort | Founder |
| 2 | Customer interviews (every paying customer) | Founder |
| 3 | Agency outreach (conditional -- only if inbound signals justify) | Founder |
| 4 | Monitoring and alerting for license API | Eng |
| 5 | End-to-end integration test in CI | Eng |
| 6 | Propagate uncertainty through budget optimizer | Eng |

## Week 11-12 -- Phase 2: Scale or Pivot

| # | Deliverable | Owner |
|---|---|---|
| 1 | Evaluate kill criteria at Day 90 | Founder |
| 2 | Pro tier launch ($799/mo) if demand warrants | Eng + Product |
| 3 | Model caching for repeat runs | Eng |
| 4 | Landing page refresh with customer testimonials | Founder |

**Exit criteria:** Monthly churn <5%. 25+ paying customers. Retention mechanics demonstrably reducing churn. Or: kill criteria triggered, pivot begins.

---

# Section V: Strategic Decisions

These are resolved. Do not re-debate unless new data emerges.

| # | Decision | Resolution | Rationale |
|---|---|---|---|
| 1 | **Primary distribution channel** | MCP (with Python API backup shipped) | AI-native UX is the differentiation. Headless API already live as backup. |
| 2 | **Launch pricing** | Free ($0) + Growth ($299/mo) only | Two tiers. Simple. No $99 tier yet -- insufficient data on conversion. |
| 3 | **Free tier limits** | 2 channels, 2,000 rows, 2 runs/month, no dollar headlines | Run count enforced via local counter in `metering.py` (SHIPPED). Server-side metering planned for Week 7-8. |
| 4 | **Agency strategy Phase 1** | Deferred to Week 9+. Phase 1 is DTC brands only. | Agency sales are longer-cycle and require multi-client features we don't have. Focus on one persona. |
| 5 | **1-chain fast config** | Removed | Trust > speed. Using 4 chains with reduced draws (250). |
| 6 | **Headless API timing** | Phase 1A (shipped, was Phase 2) | Reduces platform risk. **UPDATE:** License gate SHIPPED in `api.py`. |
| 7 | **PyMC-Marketing threat level** | HIGH/MEDIUM (upgraded) | If they ship a product, our tech layer vanishes. Speed is the defense. |
| 8 | **Data locality** | Local by default, opt-in benchmarking in Phase 2 | Preserves privacy story. Builds data asset over time without forcing it. |
| 9 | **Minimum data requirement** | 90-day hard minimum. "Exploratory Analysis" badge for <26 weeks. | Implemented. Analyses with <182 days carry accuracy caveats. Priors dominate at <26 weeks -- users are warned. Wide-format path at 90 days. Platform CSV path must be aligned from 180 to 90. |
| 10 | **Web app** | Parked | MCP server is the product. Web app gets no investment until Phase 3 at earliest. |
| 11 | **When to raise** | After proving churn <5% with 30+ paying customers | Raise on retention data, not projections. Seed round at $500K-$1M ARR run rate. |
| 12 | **Primary positioning headline** | "Find the wasted $47K in your ad budget. In 5 minutes. For $299/month." | Lead with dollar outcome, not methodology. "Enterprise-grade" retired. |
| 13 | **Infrastructure as separate workstream** | Deployment gets its own sprint, not feature sprint line items | Phase 0-1 proved code velocity =/= deployment velocity. |
| 14 | **License fallback behavior** | Fail-closed with 24-hour grace period (Week 7-8) | Current: fail-open to free tier on any API error. Acceptable during beta. Fail-closed protects revenue. Grace period prevents locking out paid users during short outages. |
| 15 | **Free tier limits enforcement** | 2 channels, 2,000 rows. Code aligned to strategy. | 3ch/5000 was a bug. Code must match strategy. |
| 16 | **MCMC config (MCP path)** | 4 chains x 250 draws, target_accept=0.90 | 4 chains required for reliable R-hat diagnostics. 250 draws sufficient with 4 chains. Parallel execution keeps wall-clock time manageable. |
| 17 | **Agency outreach** | Deferred to Week 9+. Phase 1 is DTC brands only. | Agency sales are longer-cycle and require multi-client features we don't have. Focus on one persona. |
| 18 | **Seasonal controls** | Auto-detect US holidays. SHIPPED. | Holiday controls live in `preprocessing.py`. Uses `holidays` package + cyclical month encoding + Q4 indicator. |

---

# Section VI: Success Metrics

## The Only Metric That Matters

**5 paying customers by Day 45. 10 paying customers by Day 60.**

Concierge sales model with 20 targeted DTC prospects. Not free users. Not signups. Not MCP installs. Humans who have given MixLift $299/month of their company's money and have not asked for a refund.

## Ongoing Dashboard

| Metric | 30 Days | 90 Days | 6 Months | 12 Months |
|---|---|---|---|---|
| Paying customers | 5 | 25 | 60 | 150 |
| MRR | $1,500 | $7,500 | $25,000 | $75,000 |
| Monthly logo churn | Measuring | <8% | <5% | <3% |
| Free-to-paid conversion | Measuring | 3% | 5% | 8% |
| Time from install to first analysis | <10 min | <5 min | <3 min | <3 min |
| NPS (paying customers) | Measuring | >30 | >40 | >50 |
| CAC (blended) | $0 (founder-sold) | <$100 | <$150 | <$200 |
| LTV/CAC | Measuring | >3x | >4x | >5x |

## Product Readiness by Persona

| Persona | Readiness | Gap |
|---|---|---|
| Media buyer / performance marketer | 90% | Sample dataset shipped. Scenario CI remaining. |
| VP of Marketing | 65% | Narrative output shipped. Shareable artifacts (PDF export) remaining. |
| CFO / CEO | 30% | Won't use AI assistant for analytics |

## The Churn Threshold

- **Monthly churn >5%:** Lifestyle business. Caps at ~$500K ARR.
- **Monthly churn 3-5%:** Viable SaaS. Can reach $1-3M ARR with strong acquisition.
- **Monthly churn <3%:** Venture-scale. Compounding math works. Raise a seed round.

**Churn is THE metric that determines every subsequent strategic decision.** Start measuring from Day 1 of paid customers.

## Kill Criteria

If at 90 days (Day 90):
- Fewer than 10 paying customers despite active sales effort: pivot distribution strategy (consider web app, consider Shopify app)
- Monthly churn >15%: fundamental product-market fit problem. Stop building features. Talk to every churned customer.
- Zero inbound interest from any channel: distribution is not working. Build alternative channels immediately.

Lifestyle business ($100-180K ARR) is acknowledged as a valid base case. Not a failure. Venture path requires churn <3%.

---

# Section VII: Architecture

## Current State (Updated)

```
USER'S MACHINE                              REMOTE SERVICES
+------------------------------+            +------------------------------+
|  Claude Desktop / MCP Client |            |  api.mixlift.io              |
|           |                  |            |  (License API - LIVE)        |
|           | stdio            |            |                              |
|           v                  |            |  POST /v1/license/validate   |
|  +---------------------+    |  HTTPS ->  |  POST /v1/webhooks/stripe    |
|  |  MixLift MCP Server |----+----------->|  GET  /health                |
|  |                     |    |  <- JSON   |           |                   |
|  |  mixlift_analyze()  |    |            |           v                   |
|  |  - CSV auto-detect  |    |            |  SQLite (licenses table)      |
|  |  - tier enforcement |    |            +------------------------------+
|  +----------+----------+    |
|             |               |            +------------------------------+
|             v               |            |  Stripe                      |
|  +---------------------+    |            |  - Payment Link -> Checkout  |
|  |  Modeling Engine     |    |            |  - Webhooks -> License API   |
|  |  PyMC-Marketing     |    |            +------------------------------+
|  |  - MCMC (4 chains)  |    |
|  |  - Budget optimizer  |    |
|  |  - Saturation curves |    |
|  +---------------------+    |
|                              |
|  === Headless API ===        |
|  +---------------------+    |
|  |  mixlift.analyze()  |    |
|  |  (Python API)        |    |
|  |  - No MCP dependency |    |
|  |  - License gate LIVE |    |
|  |  - Full pipeline     |    |
|  +---------------------+    |
+------------------------------+
```

### Key Technical Decisions

**Why MCP?** Zero infrastructure for users. Data stays local. AI-native UX. New, uncrowded distribution channel.

**Why PyMC-Marketing?** Battle-tested Bayesian MMM. Published methodology. Inherited credibility. Risk: if they build a product, we lose the tech layer.

**Why SQLite for License API?** Simple CRUD. Zero ops. Migrate to Postgres at ~10K licenses.

**Why Stripe Payment Links?** Fastest path to revenue. Upgrade to embedded checkout when we need custom pricing pages.

**Why headless API now?** Reduces Anthropic platform dependency. Enables non-MCP distribution (notebooks, scripts, future REST API). Developer on-ramp for technical users.

**Why 4 chains?** R-hat convergence diagnostics require multiple chains. 2 chains is the absolute minimum; 4 provides reliable diagnostics. Parallel execution on multi-core machines keeps wall-clock time manageable.

---

# Section VIII: Technical Debt Queue

Reordered with newly discovered items from the Phase 0-2 audit. Ordered by business impact.

| Priority | Issue | Business Impact if Unfixed | Effort | Status |
|---|---|---|---|---|
| P0 | ~~License API not deployed~~ | -- | -- | SHIPPED |
| P0 | ~~Not on PyPI~~ | -- | -- | SHIPPED (v0.2.0) |
| P0 | ~~Tier naming mismatch~~ | -- | -- | SHIPPED |
| P0 | ~~Free tier limits mismatch~~ | -- | -- | SHIPPED |
| P1 | ~~No seasonal/holiday controls~~ | -- | -- | SHIPPED |
| P1 | ~~Model fit silently empty~~ | -- | -- | SHIPPED |
| P1 | ~~Headless API bypasses monetization~~ | -- | -- | SHIPPED |
| P1 | **Free tier dollar leak** | `budget_optimization` shows dollars, undermining paywall. | S | OPEN |
| P1 | ~~MCMC config insufficient~~ | -- | -- | SHIPPED |
| P1 | ~~No usage metering~~ | -- | -- | SHIPPED |
| P1 | License bypass (fail-open) (`license.py:61`) | Anyone can use paid features by catching exception. | M | OPEN |
| P1 | Scenario mode lacks confidence intervals | Point estimates risk bad recommendations. | M | UNCHANGED |
| P1 | `ingest/service.py` still 180-day minimum | Platform CSV users hit old wall. Wide format is 90 days. | S | NEW |
| P2 | Raw saturation curves in MCP output | 1600 wasted data points Claude can't render. | S | NEW |
| P2 | Shared CSV logic in `server.py` private functions | `api.py` depends on MCP server internals. Fragile coupling. | M | UNCHANGED |
| P2 | Circular import risk (engine <-> optimizer) | Fragile. Will break when adding new modules. | S | UNCHANGED |
| P2 | No end-to-end integration test | Full pipeline regressions not caught. | M | UNCHANGED |
| P2 | No model caching | Repeat runs on similar data take full MCMC time. | M | UNCHANGED |
| P2 | No monitoring/alerting | License API outage goes undetected. | S-M | UNCHANGED |
| P3 | Web app code in same package | Bloats install size. Confusing package boundary. | M | UNCHANGED |

---

# Section IX: What Remains True

## The Synthesized Strategy (Unchanged)

### What MixLift Is

MixLift is the first AI-native Marketing Mix Modeling platform. It delivers Bayesian MMM -- the gold standard for marketing measurement -- through a conversational AI interface, at a fraction of the price of every competitor.

A marketer drops a CSV of their ad spend into Claude and gets back: a dollar-value headline showing how much budget is being wasted, which channels are actually driving revenue, exactly how to reallocate their budget with confidence intervals, and a saturation analysis showing where spend has diminishing returns. No dashboard. No data science team. No six-figure contract.

### The Market

**Marketing analytics:** ~$5B today, growing to $13-15B by 2030.

**The pricing gap we exploit:** True Bayesian MMM starts at $1,500/month (Prescient AI, Paramark). Everything below that is shallow regression or basic attribution. MixLift is the only true Bayesian MMM under $1,500/month.

**Primary buyer:** Director of Growth or VP Marketing at a DTC eCommerce brand, $5M-$200M revenue, spending $500K-$20M/year on ads, with no data scientist on staff.

### Pricing (Launch)

| Tier | Price | Channels | Rows | Runs/Month | Dollar Headlines | Target |
|---|---|---|---|---|---|---|
| **Free** | $0 | 2 | 2,000 | 2 | No (percentages only) | Trial / demonstrate value |
| **Growth** | $299/mo | 8 | 50,000 | Unlimited | Yes | DTC brands, $1-20M rev |

**Phase 2 additions** (after 50 paying customers):
- **Pro** ($799/mo) -- 20 channels, 500K rows, priority support
- **Agency** ($1,499/mo) -- multi-client (10), white-label reports

### Moat (Ordered by Build Priority)

1. **Output quality and trust.** Dollar-value headlines, confidence explainers, saturation traffic lights. The AI interpretation layer that makes raw Bayesian output actionable. PyMC-Marketing will not build this. **STATUS: SHIPPED.** Not a durable moat (replicable in 1-2 weeks) but a first-mover advantage.

2. **Data normalization.** Every CSV format, API schema, and edge case. The unglamorous but critical ingest pipeline. **STATUS: Partial. Auto-detect works for Meta, Google, TikTok, generic.**

3. **Contextual memory.** "Last quarter we recommended cutting TikTok by 15%. You did. Revenue went up 8%." Strategic memory creates switching costs. **STATUS: SHIPPED.** `memory.py` stores analysis summaries locally. Subsequent runs show deltas. This is the first real moat.

4. **Becoming the default verb.** "Run MixLift on it" becomes how marketers say "do MMM." First-mover in AI-native marketing analytics. **STATUS: Requires shipping first.**

5. **Vertical benchmarks.** Anonymized, aggregated benchmark data from the user base. Requires scale; cannot be built day one. **STATUS: Not started.**

### Competitive Landscape (Updated)

| Competitor | Threat Level | Rationale |
|---|---|---|
| **PyMC-Marketing** (open source) | HIGH | We build on this. If they ship a product/UI, our tech layer disappears. |
| **Triple Whale** | HIGH | Massive DTC distribution ($50M+ raised). If they ship real Bayesian MMM at $199/mo, we cannot compete on distribution. |
| **Paramark** | HIGH | Closest methodology. If they launch a $500/month self-serve tier, the gap narrows. |
| **Prescient AI** | HIGH | Same methodology, same market, 5-15x our price. Could drop prices. |
| **Pecan AI** | MEDIUM-HIGH | $116M raised. Predictive analytics platform adding marketing measurement. |
| **Agency internal tools** (Robyn/Meridian) | MEDIUM | Agencies building DIY tools on open source. We must be easier. |

---

# Section X: What Winning Looks Like

## 6-Month Snapshot (September 2026)

MixLift has 60 paying customers generating $25K MRR. Monthly churn is 4%. Three agencies are using it across 15+ client accounts. The product runs on both Claude and ChatGPT. Meta Ads API connector eliminates CSV friction for 40% of users. Every analysis output starts with a dollar-value headline. Users who have run 3+ analyses have <2% monthly churn because comparison features make each run more valuable than the last.

## 12-Month Snapshot (March 2027)

MixLift has 150 paying customers generating $75K MRR ($900K ARR run rate). Monthly churn is under 3%. The agency channel represents 30% of revenue. A seed round closes at $3-5M on a $20-30M valuation. The team is 4 people: founder, senior engineer, growth marketer, customer success. MixLift is the default answer to "how do I run MMM?" in AI assistant conversations.

## The Honest Assessment

MixLift is a fully deployed product ready for its first customers. The modeling core is production-quality. The output layer is shipped and compelling. Infrastructure is live. The competitive positioning is real. The constraint is now sales execution, not engineering.

### Probability Assessment

- **Probability of reaching $1M ARR:** 5-10%. Requires churn <3%, strong retention mechanics, and expanding to 300+ customers.
- **Most likely outcome:** Lifestyle business at $100-180K ARR. This is a fine outcome.
- **MixLift is a speed play, not a moat play.** Output quality is replicable. Contextual memory creates real switching costs and is now shipped. "Default verb" status requires scale we don't have. Act accordingly: sell fast, learn fast, pivot fast.

### What determines the outcome is not strategy -- it is:

1. ~~Can we actually deploy?~~ **YES.** License API live. PyPI v0.2.0. Stripe connected. DONE.
2. **Can we convert?** (5 paying customers -- next 4 weeks) -- THIS IS THE CURRENT FOCUS
3. **Can we retain?** (Churn <5% -- next 3 months) -- contextual memory shipped, measuring when customers arrive

If monthly churn stays above 5%, this caps out as a profitable lifestyle business doing $300-500K ARR. That is a fine outcome.

If monthly churn drops below 3% because memory, comparison, and scenario features make MixLift a monthly workflow tool, the compounding math works for venture scale.

**MixLift is a product. The infrastructure is shipped. Now it needs customers.**

Get 5 paying customers. Measure churn. Everything else follows from that data.

---

*Last updated: March 7, 2026*
*Next review: March 11, 2026*
*Review cadence: Every Monday*
