# MixLift Cloud — Observability Setup

## Secrets to set via fly secrets

Run these once after deploying. Values are stored encrypted in Fly Vault.

```bash
# Sentry DSN (get from sentry.io → Settings → Projects → <project> → DSN)
fly secrets set SENTRY_DSN="https://<key>@o<org>.ingest.sentry.io/<project>" --app mixlift-cloud

# Optional: override sample rate (default 0.1 = 10% of transactions traced)
fly secrets set SENTRY_TRACES_SAMPLE_RATE="0.05" --app mixlift-cloud

# App version — helps correlate Sentry releases with deploys
fly secrets set MIXLIFT_VERSION="0.5.1" --app mixlift-cloud
```

`LOG_FORMAT=json` and `ENVIRONMENT=production` are already in `fly.toml [env]`
(plain text is fine; no secret value).

## Grafana dashboard import

1. Open Grafana → Dashboards → Import.
2. Upload `ops/grafana-dashboard-mixlift.json` (or paste its contents).
3. Select your Prometheus data source that scrapes the Fly metrics endpoint:
   `https://api.fly.io/prometheus/<org-slug>` (authenticate with a Fly API token).
4. Click Import.

The dashboard uid is `mixlift-cloud-obs-v1`; if you already have a dashboard
with that uid, change it before importing to avoid collision.

## Structured JSON log fields

Each log line emitted by the server includes:

| Field        | Example                          | Notes                              |
|--------------|----------------------------------|------------------------------------|
| `ts`         | `2026-04-14T01:00:00Z`          | UTC ISO-8601                       |
| `level`      | `INFO`                           |                                    |
| `logger`     | `mixlift_mcp.server`             |                                    |
| `msg`        | `Starting MixLift Cloud MCP...`  |                                    |
| `file`       | `remote.py`                      |                                    |
| `line`       | `42`                             |                                    |
| `request_id` | `a3f8c2...` (uuid4 hex)          | Present inside HTTP request scope  |
| `tenant`     | `sha256:a1b2...`                 | Present when identity hash is set  |

Query in Fly log explorer: `json.level = "ERROR"` to filter errors.

## Suggested alerts

Configure in Grafana Alerting → Alert Rules:

| Alert | PromQL | Threshold | Window |
|-------|--------|-----------|--------|
| P95 latency spike | `histogram_quantile(0.95, sum(rate(starlette_request_duration_seconds_bucket{app="mixlift-cloud", path="/mcp"}[5m])) by (le))` | > 240s | 5 min |
| High error rate | `sum(rate(starlette_requests_total{app="mixlift-cloud", status_code=~"5.."}[5m])) / sum(rate(starlette_requests_total{app="mixlift-cloud"}[5m]))` | > 0.05 (5%) | 5 min |
| No machines running | `count(fly_instance_up{app="mixlift-cloud"} == 1)` | == 0 | 2 min (during marketplace hours) |

Route all alerts to a Slack channel or PagerDuty via Grafana's Contact Points.
