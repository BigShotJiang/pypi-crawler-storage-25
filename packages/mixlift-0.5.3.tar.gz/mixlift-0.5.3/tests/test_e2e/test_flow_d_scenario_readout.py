"""Flow D: Scenario analysis -> Readout."""

from __future__ import annotations

import copy
from datetime import date

import pytest


@pytest.fixture(scope="session")
def e2e_scenario_result(e2e_model_components):
    """Run scenario analysis using the session-fitted model.

    Returns a (result_with_scenario, scenario_dict) tuple so callers can
    inspect both the full result and the raw scenario payload.
    """
    from mixlift_mcp.server import _run_scenario

    comps = e2e_model_components
    scenario_result = _run_scenario(
        "cut Meta by 20%",
        comps["optimization"],
        comps["model_results"],
        comps["X"],
        comps["channel_columns"],
    )

    result = copy.deepcopy(comps["result"])
    if scenario_result and "error" not in scenario_result:
        result["scenario"] = scenario_result
    return result, scenario_result


@pytest.fixture(scope="session")
def e2e_scenario_readout(e2e_scenario_result, tmp_path_factory):
    """Generate readout with scenario brief and return filename -> content dict."""
    from mixlift_mcp.readout import generate_readout

    result, _ = e2e_scenario_result
    out = tmp_path_factory.mktemp("scenario_readout")
    generate_readout(result, str(out))

    run_dir = out / "MixLift" / date.today().isoformat()
    return {md_file.name: md_file.read_text() for md_file in run_dir.glob("*.md")}


@pytest.mark.e2e
class TestScenarioAnalysis:
    def test_scenario_parsed(self, e2e_scenario_result):
        _, scenario = e2e_scenario_result
        assert scenario is not None, "Scenario parsing returned None"
        assert "projected_impact_pct" in scenario

    def test_scenario_impact_has_ci(self, e2e_scenario_result):
        _, scenario = e2e_scenario_result
        if scenario and "impact_ci_80" in scenario:
            ci = scenario["impact_ci_80"]
            assert "low" in ci and "high" in ci

    def test_scenario_direction_note(self, e2e_scenario_result):
        _, scenario = e2e_scenario_result
        if scenario and "direction_note" in scenario:
            assert len(scenario["direction_note"]) > 10

    def test_scenario_changes_include_meta(self, e2e_scenario_result):
        _, scenario = e2e_scenario_result
        if scenario and "changes" in scenario:
            channels = [c["channel"] for c in scenario["changes"]]
            has_meta = any("meta" in ch.lower() or "Meta" in ch for ch in channels)
            assert has_meta, f"No Meta in changes: {channels}"

    def test_scenario_budget_does_not_increase_total(self, e2e_scenario_result):
        """Cutting spend should not increase total budget."""
        _, scenario = e2e_scenario_result
        if scenario and "current_budget" in scenario and "modified_budget" in scenario:
            assert scenario["modified_budget"] <= scenario["current_budget"]

    def test_scenario_has_headline(self, e2e_scenario_result):
        _, scenario = e2e_scenario_result
        if scenario and "error" not in scenario:
            assert "headline" in scenario
            assert len(scenario["headline"]) > 10


@pytest.mark.e2e
class TestScenarioReadout:
    def test_scenario_brief_exists(self, e2e_scenario_readout):
        assert "scenario-brief.md" in e2e_scenario_readout

    def test_scenario_brief_yaml_valid(self, e2e_scenario_readout):
        from tests.test_e2e.test_obsidian_validation import validate_yaml_frontmatter

        if "scenario-brief.md" in e2e_scenario_readout:
            fm = validate_yaml_frontmatter(e2e_scenario_readout["scenario-brief.md"])
            assert fm["type"] == "mixlift/scenario-brief"

    def test_scenario_brief_no_jinja(self, e2e_scenario_readout):
        from tests.test_e2e.test_obsidian_validation import validate_no_jinja_artifacts

        if "scenario-brief.md" in e2e_scenario_readout:
            validate_no_jinja_artifacts(e2e_scenario_readout["scenario-brief.md"])

    def test_scenario_brief_has_scenario_input_in_frontmatter(self, e2e_scenario_readout):
        from tests.test_e2e.test_obsidian_validation import validate_yaml_frontmatter

        if "scenario-brief.md" in e2e_scenario_readout:
            fm = validate_yaml_frontmatter(e2e_scenario_readout["scenario-brief.md"])
            assert "scenario_input" in fm
            assert len(str(fm["scenario_input"])) > 0

    def test_standard_files_still_present_with_scenario(self, e2e_scenario_readout):
        """Scenario-brief is additional; standard files must still be written."""
        for required in ("budget-memo.md", "channel-scorecard.md", "sources.md"):
            assert required in e2e_scenario_readout, f"Missing {required}"

    def test_scenario_sources_wiki_links_resolve(self, e2e_scenario_readout):
        from tests.test_e2e.test_obsidian_validation import validate_wiki_links

        if "scenario-brief.md" in e2e_scenario_readout and "sources.md" in e2e_scenario_readout:
            validate_wiki_links(
                e2e_scenario_readout["scenario-brief.md"],
                e2e_scenario_readout["sources.md"],
            )
