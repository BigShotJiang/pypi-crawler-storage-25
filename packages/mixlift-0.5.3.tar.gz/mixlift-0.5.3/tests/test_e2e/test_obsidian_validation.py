"""Obsidian output validation for MixLift deliverables."""

from __future__ import annotations

import re

import pytest
import yaml

# ---------------------------------------------------------------------------
# Shared validators (used by other test files too)
# ---------------------------------------------------------------------------


def validate_yaml_frontmatter(md_content: str) -> dict:
    """Extract and validate YAML frontmatter from markdown."""
    parts = md_content.split("---", 2)
    assert len(parts) >= 3, "Missing YAML frontmatter delimiters"
    fm = yaml.safe_load(parts[1])
    assert isinstance(fm, dict), "Frontmatter is not a dict"
    return fm


def validate_markdown_tables(md_content: str) -> None:
    """Validate markdown tables have consistent column counts."""
    lines = md_content.split("\n")
    in_table = False
    expected_cols = 0
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("|") and stripped.endswith("|"):
            cols = stripped.count("|") - 1  # pipes minus outer ones
            if not in_table:
                in_table = True
                expected_cols = cols
            else:
                assert cols == expected_cols, (
                    f"Table column count mismatch: expected {expected_cols}, got {cols}\n"
                    f"Line: {stripped}"
                )
        else:
            in_table = False
            expected_cols = 0


def validate_wiki_links(deliverable: str, sources: str) -> None:
    """Validate all wiki-links in deliverable resolve to block IDs in sources."""
    # Extract [[sources#anchor]] links
    links = re.findall(r"\[\[sources#([\w-]+)\]\]", deliverable)
    # Extract ^anchor block IDs
    block_ids = set(re.findall(r"\^([\w-]+)", sources))

    missing = [link for link in links if link not in block_ids]
    assert not missing, f"Unresolved wiki-links: {missing}"


def validate_no_jinja_artifacts(md_content: str) -> None:
    """Ensure no Jinja2 template artifacts remain."""
    assert "{{" not in md_content, "Found Jinja2 {{ in output"
    assert "{%" not in md_content, "Found Jinja2 {% in output"
    assert "}}" not in md_content, "Found Jinja2 }} in output"


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.e2e
class TestObsidianValidation:
    def test_budget_memo_yaml_valid(self, e2e_readout_files):
        fm = validate_yaml_frontmatter(e2e_readout_files["budget-memo.md"])
        assert fm["type"] == "mixlift/budget-memo"

    def test_channel_scorecard_yaml_valid(self, e2e_readout_files):
        fm = validate_yaml_frontmatter(e2e_readout_files["channel-scorecard.md"])
        assert fm["type"] == "mixlift/channel-scorecard"

    def test_sources_yaml_valid(self, e2e_readout_files):
        fm = validate_yaml_frontmatter(e2e_readout_files["sources.md"])
        assert fm["type"] == "mixlift/sources"

    def test_diminishing_returns_yaml_valid(self, e2e_readout_files):
        if "diminishing-returns.md" in e2e_readout_files:
            fm = validate_yaml_frontmatter(e2e_readout_files["diminishing-returns.md"])
            assert fm["type"] == "mixlift/diminishing-returns"

    def test_budget_memo_tables_consistent(self, e2e_readout_files):
        validate_markdown_tables(e2e_readout_files["budget-memo.md"])

    def test_scorecard_tables_consistent(self, e2e_readout_files):
        validate_markdown_tables(e2e_readout_files["channel-scorecard.md"])

    def test_budget_memo_wiki_links_resolve(self, e2e_readout_files):
        validate_wiki_links(
            e2e_readout_files["budget-memo.md"],
            e2e_readout_files["sources.md"],
        )

    def test_scorecard_wiki_links_resolve(self, e2e_readout_files):
        validate_wiki_links(
            e2e_readout_files["channel-scorecard.md"],
            e2e_readout_files["sources.md"],
        )

    def test_budget_memo_dataview_fields(self, e2e_readout_files):
        fm = validate_yaml_frontmatter(e2e_readout_files["budget-memo.md"])
        assert "run_date" in fm
        assert "channels" in fm
        assert "n_channels" in fm

    def test_no_jinja_artifacts_in_any_file(self, e2e_readout_files):
        for name, content in e2e_readout_files.items():
            validate_no_jinja_artifacts(content)
