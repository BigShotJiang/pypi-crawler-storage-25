"""Flow B: Connect (synthetic multi-platform) -> Analyze -> Readout."""

from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd
import pytest

from tests.test_e2e.conftest import FAST_MCMC


@pytest.fixture(scope="session")
def e2e_connector_csv(tmp_path_factory):
    """Build a realistic multi-platform wide CSV as if from mixlift_connect_multi."""
    np.random.seed(43)
    tmp_dir = tmp_path_factory.mktemp("connector_data")

    dates = pd.date_range("2025-01-01", periods=26, freq="W-MON")
    df = pd.DataFrame({"date": dates})

    # Three platform channels
    df["meta_spend"] = np.random.uniform(3000, 8000, 26)
    df["google_spend"] = np.random.uniform(2000, 6000, 26)
    df["tiktok_spend"] = np.random.uniform(1000, 4000, 26)

    # Revenue with known relationship
    df["revenue"] = (
        60000  # baseline
        + df["meta_spend"] * 1.8
        + df["google_spend"] * 3.0
        + df["tiktok_spend"] * 2.0
        + np.random.normal(0, 5000, 26)  # noise
    )

    csv_path = tmp_dir / "multi_platform.csv"
    df.to_csv(csv_path, index=False)
    return str(csv_path)


@pytest.fixture(scope="session")
def e2e_connector_result(e2e_connector_csv):
    """Run real MCMC on the connector-derived CSV."""
    import pandas as pd

    from mixlift.ingest.loader import load_wide_format
    from mixlift.modeling.engine import extract_saturation_curves, run_full_pipeline
    from mixlift.modeling.optimizer import optimize_budget
    from mixlift_mcp.license import LicenseStatus
    from mixlift_mcp.server import _build_result

    df = pd.read_csv(e2e_connector_csv)
    X, y, channel_columns = load_wide_format(df)  # noqa: N806
    dates = pd.to_datetime(df["date"])
    data_weeks = (dates.max() - dates.min()).days / 7

    model_results = run_full_pipeline(X, y, channel_columns, mcmc_config=FAST_MCMC)
    optimization = optimize_budget(
        model_results.mmm,
        X,
        channel_columns,
        contributions=model_results.raw_contributions,
    )
    saturation_curves = extract_saturation_curves(model_results.mmm, X, channel_columns)

    result = _build_result(
        model_results=model_results,
        optimization=optimization,
        saturation_curves=saturation_curves,
        channel_columns=channel_columns,
        license_status=LicenseStatus(is_pro=True, max_channels=8, max_rows=50_000, message="Test"),
        csv_format="wide",
        data_weeks=data_weeks,
    )
    result["saturation_curves"] = saturation_curves
    result["memory"] = {"note": "First analysis."}
    return result


@pytest.mark.e2e
class TestConnectToReadout:
    def test_analyze_succeeds(self, e2e_connector_result):
        assert e2e_connector_result["status"] == "success"

    def test_three_channels(self, e2e_connector_result):
        assert e2e_connector_result["data"]["n_channels"] == 3

    def test_readout_generates_files(self, e2e_connector_result, tmp_path_factory):
        from mixlift_mcp.readout import generate_readout

        out = tmp_path_factory.mktemp("connector_readout")
        summary = generate_readout(e2e_connector_result, str(out))
        assert summary["status"] == "success"
        assert len(summary["files_written"]) >= 3

    def test_scorecard_has_all_platforms(self, e2e_connector_result, tmp_path_factory):
        from mixlift_mcp.readout import generate_readout

        out = tmp_path_factory.mktemp("connector_readout_2")
        generate_readout(e2e_connector_result, str(out))
        run_dir = out / "MixLift" / date.today().isoformat()
        scorecard = (run_dir / "channel-scorecard.md").read_text()
        # Channel names depend on format_channel_name() output
        for ch in e2e_connector_result["data"]["channels"]:
            assert ch in scorecard, f"Missing channel {ch} in scorecard"

    def test_sources_has_block_ids(self, e2e_connector_result, tmp_path_factory):
        from mixlift_mcp.readout import generate_readout

        out = tmp_path_factory.mktemp("connector_readout_3")
        generate_readout(e2e_connector_result, str(out))
        sources = (out / "MixLift" / date.today().isoformat() / "sources.md").read_text()
        assert "^" in sources  # has block IDs
