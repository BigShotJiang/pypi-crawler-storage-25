"""Flow F: Readout render layer -- direct function tests with session model."""

from __future__ import annotations

from datetime import date

import pytest

from tests.test_e2e.test_obsidian_validation import (
    validate_markdown_tables,
    validate_no_jinja_artifacts,
    validate_wiki_links,
    validate_yaml_frontmatter,
)


@pytest.mark.e2e
class TestRenderBudgetMemo:
    """render_budget_memo produces well-formed markdown with valid citations."""

    def test_renders_without_exception(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_budget_memo

        collector = SourceCollector()
        md = render_budget_memo(e2e_result, collector)
        assert len(md) > 200

    def test_frontmatter_has_expected_keys(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_budget_memo

        collector = SourceCollector()
        md = render_budget_memo(e2e_result, collector)
        fm = validate_yaml_frontmatter(md)
        for key in ("type", "run_date", "channels", "n_channels"):
            assert key in fm, f"Missing frontmatter key: {key}"

    def test_tables_consistent(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_budget_memo

        collector = SourceCollector()
        md = render_budget_memo(e2e_result, collector)
        validate_markdown_tables(md)

    def test_no_jinja_artifacts(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_budget_memo

        collector = SourceCollector()
        md = render_budget_memo(e2e_result, collector)
        validate_no_jinja_artifacts(md)

    def test_collector_has_citations_after_render(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_budget_memo

        collector = SourceCollector()
        render_budget_memo(e2e_result, collector)
        assert len(collector.refs) > 0, "No citations collected"


@pytest.mark.e2e
class TestRenderChannelScorecard:
    """render_channel_scorecard correctness."""

    def test_renders_without_exception(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_channel_scorecard

        collector = SourceCollector()
        md = render_channel_scorecard(e2e_result, collector)
        assert len(md) > 200

    def test_all_channels_appear(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_channel_scorecard

        collector = SourceCollector()
        md = render_channel_scorecard(e2e_result, collector)
        for ch in e2e_result["data"]["channels"]:
            assert ch in md, f"Channel {ch!r} missing from scorecard"

    def test_tables_consistent(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_channel_scorecard

        collector = SourceCollector()
        md = render_channel_scorecard(e2e_result, collector)
        validate_markdown_tables(md)

    def test_no_jinja_artifacts(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_channel_scorecard

        collector = SourceCollector()
        md = render_channel_scorecard(e2e_result, collector)
        validate_no_jinja_artifacts(md)


@pytest.mark.e2e
class TestRenderDiminishingReturns:
    """render_diminishing_returns is conditional on saturation_curves."""

    def test_renders_when_curves_present(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_diminishing_returns

        assert e2e_result.get("saturation_curves"), "Test requires saturation_curves"
        collector = SourceCollector()
        md = render_diminishing_returns(e2e_result, collector)
        assert md is not None
        assert len(md) > 100

    def test_returns_none_without_curves(self, e2e_result):
        import copy

        from mixlift_mcp.readout import SourceCollector, render_diminishing_returns

        result_no_curves = copy.deepcopy(e2e_result)
        result_no_curves.pop("saturation_curves", None)
        collector = SourceCollector()
        assert render_diminishing_returns(result_no_curves, collector) is None

    def test_no_jinja_artifacts(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_diminishing_returns

        collector = SourceCollector()
        md = render_diminishing_returns(e2e_result, collector)
        if md is not None:
            validate_no_jinja_artifacts(md)


@pytest.mark.e2e
class TestRenderSources:
    """render_sources emits valid Obsidian block IDs from accumulated refs."""

    def test_sources_has_block_ids(self, e2e_result):
        from mixlift_mcp.readout import (
            SourceCollector,
            render_budget_memo,
            render_channel_scorecard,
            render_sources,
        )

        collector = SourceCollector()
        render_budget_memo(e2e_result, collector)
        render_channel_scorecard(e2e_result, collector)
        sources_md = render_sources(collector)
        assert "^" in sources_md, "sources.md has no block IDs"

    def test_sources_wiki_links_resolve(self, e2e_result):
        from mixlift_mcp.readout import (
            SourceCollector,
            render_budget_memo,
            render_channel_scorecard,
            render_sources,
        )

        collector = SourceCollector()
        memo = render_budget_memo(e2e_result, collector)
        scorecard = render_channel_scorecard(e2e_result, collector)
        sources_md = render_sources(collector)
        validate_wiki_links(memo, sources_md)
        validate_wiki_links(scorecard, sources_md)

    def test_sources_frontmatter_type(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_budget_memo, render_sources

        collector = SourceCollector()
        render_budget_memo(e2e_result, collector)
        sources_md = render_sources(collector)
        fm = validate_yaml_frontmatter(sources_md)
        assert fm["type"] == "mixlift/sources"

    def test_sources_has_run_date(self, e2e_result):
        from mixlift_mcp.readout import SourceCollector, render_budget_memo, render_sources

        collector = SourceCollector()
        render_budget_memo(e2e_result, collector)
        sources_md = render_sources(collector)
        fm = validate_yaml_frontmatter(sources_md)
        assert fm["run_date"] == date.today().isoformat()


@pytest.mark.e2e
class TestGenerateReadoutOrchestration:
    """generate_readout writes the correct set of files in the correct directory."""

    def test_generate_readout_success(self, e2e_result, tmp_path):
        from mixlift_mcp.readout import generate_readout

        summary = generate_readout(e2e_result, str(tmp_path))
        assert summary["status"] == "success"

    def test_output_path_contains_today(self, e2e_result, tmp_path):
        from mixlift_mcp.readout import generate_readout

        summary = generate_readout(e2e_result, str(tmp_path))
        assert date.today().isoformat() in summary["output_path"]

    def test_files_written_count(self, e2e_result, tmp_path):
        from mixlift_mcp.readout import generate_readout

        summary = generate_readout(e2e_result, str(tmp_path))
        # budget-memo, channel-scorecard, diminishing-returns, sources = 4 minimum
        assert len(summary["files_written"]) >= 4

    def test_failed_result_returns_error(self, tmp_path):
        from mixlift_mcp.readout import generate_readout

        bad_result = {"status": "error", "message": "Something went wrong"}
        summary = generate_readout(bad_result, str(tmp_path))
        assert summary["status"] == "error"
        assert summary["files_written"] == []
