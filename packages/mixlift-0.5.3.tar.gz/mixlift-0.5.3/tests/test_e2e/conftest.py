"""End-to-end test fixtures with real MCMC model fitting.

Session-scoped fixtures run MCMC once per test session so the expensive
sampling (~12-30s) is paid only once regardless of how many test modules
import these fixtures.

The ``e2e_model_components`` fixture is the root; every other e2e fixture
derives from it so nothing is computed twice.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

FIXTURES_DIR = Path(__file__).parent.parent / "fixtures"
PROJECT_ROOT = Path(__file__).parent.parent.parent

# Reduced MCMC config for fast but real model fitting (~12-30s total)
FAST_MCMC: dict = {
    "chains": 2,
    "tune": 200,
    "draws": 100,
    "target_accept": 0.85,
    "random_seed": 42,
}


# ---------------------------------------------------------------------------
# Platform CSV generation — runs once at import time
# ---------------------------------------------------------------------------


def _generate_platform_csvs() -> None:
    """Generate realistic platform CSV exports if they don't exist."""
    FIXTURES_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(42)
    dates = pd.date_range("2025-07-01", periods=90, freq="D")

    # --- Meta Ads Manager export ---
    meta_path = FIXTURES_DIR / "meta_export.csv"
    if not meta_path.exists():
        rows = []
        for d in dates:
            for camp in ["DTC Prospecting", "Retargeting"]:
                spend = float(rng.uniform(50, 300))
                impr = int(rng.integers(3000, 15000))
                clicks = int(rng.integers(100, 500))
                purchases = int(rng.integers(5, 25))
                roas = float(rng.uniform(1.5, 2.5))
                rows.append(
                    {
                        "Date": d.strftime("%Y-%m-%d"),
                        "Campaign Name": camp,
                        "Amount Spent (USD)": round(spend, 2),
                        "Impressions": impr,
                        "Link Clicks": clicks,
                        "Purchases": purchases,
                        "Purchase Conversion Value": round(spend * roas, 2),
                    }
                )
        pd.DataFrame(rows).to_csv(meta_path, index=False)

    # --- Google Ads export ---
    google_path = FIXTURES_DIR / "google_export.csv"
    if not google_path.exists():
        google_dates = pd.date_range("2025-07-01", periods=91, freq="D")
        rows = []
        for d in google_dates:
            for camp in ["Search - Brand", "Search - Generic", "Shopping"]:
                cost = float(rng.uniform(30, 200))
                impr = int(rng.integers(2000, 10000))
                clicks = int(rng.integers(50, 400))
                convs = int(rng.integers(3, 20))
                roas = float(rng.uniform(2.0, 4.0))
                rows.append(
                    {
                        "Day": d.strftime("%Y-%m-%d"),
                        "Campaign": camp,
                        "Cost": round(cost, 2),
                        "Impressions": impr,
                        "Clicks": clicks,
                        "Conversions": convs,
                        "Conv. value": round(cost * roas, 2),
                    }
                )
        pd.DataFrame(rows).to_csv(google_path, index=False)


# Generate platform CSVs at import time (idempotent — skipped if files exist)
_generate_platform_csvs()


# ---------------------------------------------------------------------------
# Static fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def ground_truth() -> dict:
    """Load known ROAS and saturation parameters for ground-truth assertions."""
    with open(FIXTURES_DIR / "ground_truth.json") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Core MCMC fixture — expensive, runs once per session
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def e2e_model_components(tmp_path_factory):  # type: ignore[no-untyped-def]
    """Run real MCMC once and return all pipeline components.

    This is the expensive fixture (~12-30s).  All other e2e fixtures derive
    from this one so MCMC is never run more than once per session.

    Returned dict keys::

        result          – full result dict as returned by _build_result
        mmm             – fitted MMM object
        X               – feature DataFrame
        y               – target Series
        channel_columns – list of raw column names (e.g. "google_search_spend")
        model_results   – ModelResults dataclass
        optimization    – dict from optimize_budget
        saturation_curves – dict from extract_saturation_curves
        csv_path        – absolute path to the synthetic CSV used
        fingerprint     – 16-char hex fingerprint for _MODEL_CACHE
    """
    from mixlift.ingest.loader import load_wide_format as _load_wide_format  # noqa: PLC0415
    from mixlift.modeling.engine import (  # noqa: PLC0415
        extract_saturation_curves,
        run_full_pipeline,
    )
    from mixlift.modeling.optimizer import optimize_budget  # noqa: PLC0415
    from mixlift_mcp.license import LicenseStatus  # noqa: PLC0415
    from mixlift_mcp.memory import compute_fingerprint  # noqa: PLC0415
    from mixlift_mcp.server import _build_result  # noqa: PLC0415
    from scripts.generate_synthetic import generate_synthetic_data  # noqa: PLC0415

    # --- Generate 52-week synthetic data ---
    tmp_dir = tmp_path_factory.mktemp("e2e_data")
    csv_path = str(tmp_dir / "synthetic.csv")
    df = generate_synthetic_data(n_weeks=52, seed=42, output_path=csv_path)

    # --- Load into X, y, channel_columns ---
    X, y, channel_columns = _load_wide_format(df)  # noqa: N806

    dates = pd.to_datetime(df["date"])
    data_weeks = float((dates.max() - dates.min()).days / 7)

    # --- Fit model with real MCMC (reduced config for speed) ---
    model_results = run_full_pipeline(X, y, channel_columns, mcmc_config=FAST_MCMC)

    # --- Budget optimisation ---
    optimization = optimize_budget(
        model_results.mmm,
        X,
        channel_columns,
        contributions=model_results.raw_contributions,
    )

    # --- Saturation curves ---
    saturation_curves = extract_saturation_curves(model_results.mmm, X, channel_columns)

    # --- Build result dict (pro tier) ---
    license_status = LicenseStatus(
        is_pro=True,
        max_channels=8,
        max_rows=50_000,
        message="Test pro license",
    )
    result = _build_result(
        model_results=model_results,
        optimization=optimization,
        saturation_curves=saturation_curves,
        channel_columns=channel_columns,
        license_status=license_status,
        csv_format="wide",
        data_weeks=data_weeks,
    )

    # Attach saturation curves (pro tier — not included by default in MCP output)
    result["saturation_curves"] = saturation_curves

    # Memory note (first run — no deltas)
    result["memory"] = {"note": "First analysis for this dataset."}

    # Model fingerprint
    channel_names = list(model_results.roas_estimates.keys())
    fp = compute_fingerprint(channel_names, csv_path)
    result["model_fingerprint"] = fp

    return {
        "result": result,
        "mmm": model_results.mmm,
        "X": X,
        "y": y,
        "channel_columns": channel_columns,
        "model_results": model_results,
        "optimization": optimization,
        "saturation_curves": saturation_curves,
        "csv_path": csv_path,
        "fingerprint": fp,
    }


# ---------------------------------------------------------------------------
# Derived fixtures — zero additional MCMC cost
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def e2e_result(e2e_model_components) -> dict:  # type: ignore[no-untyped-def]
    """The full result dict from the 52-week session run."""
    return e2e_model_components["result"]


@pytest.fixture(scope="session")
def e2e_forecast_result(e2e_model_components) -> dict:  # type: ignore[no-untyped-def]
    """Forecast result dict computed from the cached fitted model.

    Replicates the logic of the ``mixlift_forecast`` MCP tool without
    hitting the MCP transport layer, making it suitable for unit-level
    assertions on forecast outputs.
    """
    from mixlift.modeling.optimizer import (  # noqa: PLC0415
        _estimate_response,
        estimate_scenario_impact_samples,
    )
    from mixlift_mcp.server import _MODEL_CACHE  # noqa: PLC0415

    comps = e2e_model_components
    result = comps["result"]
    fp = comps["fingerprint"]

    # Populate the in-process model cache so server helpers can reuse it
    _MODEL_CACHE[fp] = {
        "mmm": comps["mmm"],
        "X": comps["X"],
        "channel_columns": comps["channel_columns"],
        "model_results": comps["model_results"],
    }

    budget_opt = result.get("budget_optimization", {})
    current_alloc: dict = budget_opt.get("current_allocation", {})
    optimal_alloc: dict = budget_opt.get("optimal_allocation", {})

    current_weekly = _estimate_response(
        comps["mmm"], comps["X"], comps["channel_columns"], current_alloc
    )

    impact_samples = estimate_scenario_impact_samples(
        comps["mmm"],
        comps["X"],
        comps["channel_columns"],
        current_alloc,
        optimal_alloc,
    )

    impact_median = float(np.median(impact_samples)) if len(impact_samples) > 0 else 0.0
    impact_ci_low = float(np.percentile(impact_samples, 10)) if len(impact_samples) > 0 else 0.0
    impact_ci_high = float(np.percentile(impact_samples, 90)) if len(impact_samples) > 0 else 0.0

    optimal_weekly = current_weekly * (1 + impact_median / 100)
    weekly_delta = optimal_weekly - current_weekly
    horizon = 12

    weeks = []
    cum_current = 0.0
    cum_optimal = 0.0
    cum_delta = 0.0
    for w in range(1, horizon + 1):
        cum_current += current_weekly
        cum_optimal += optimal_weekly
        cum_delta += weekly_delta
        weeks.append(
            {
                "week": w,
                "current_revenue": round(current_weekly, 0),
                "optimized_revenue": round(optimal_weekly, 0),
                "weekly_delta": round(weekly_delta, 0),
                "cumulative_current": round(cum_current, 0),
                "cumulative_optimized": round(cum_optimal, 0),
                "cumulative_delta": round(cum_delta, 0),
            }
        )

    return {
        "status": "success",
        "analysis_type": "forecast",
        "horizon_weeks": horizon,
        "summary": {
            "current_weekly_revenue": round(current_weekly, 0),
            "optimized_weekly_revenue": round(optimal_weekly, 0),
            "weekly_delta": round(weekly_delta, 0),
            "total_current_revenue": round(current_weekly * horizon, 0),
            "total_optimized_revenue": round(optimal_weekly * horizon, 0),
            "total_delta": round(weekly_delta * horizon, 0),
            "impact_pct": round(impact_median, 1),
            "impact_ci_80": {
                "low": round(impact_ci_low, 1),
                "high": round(impact_ci_high, 1),
            },
        },
        "weekly_projections": weeks,
        "current_allocation": current_alloc,
        "optimal_allocation": optimal_alloc,
        "model_fingerprint": fp,
        "model_info": result.get("model_info", {}),
        "data": result.get("data", {}),
        "license": result.get("license", {}),
    }


@pytest.fixture(scope="session")
def e2e_readout_dir(e2e_result, tmp_path_factory):  # type: ignore[no-untyped-def]
    """Generate Obsidian readout files and return a dict with dir and summary.

    Also copies the output to ``{PROJECT_ROOT}/test_output/`` for manual
    inspection between runs (directory is overwritten each session).

    Returned dict keys: ``dir`` (Path), ``summary`` (dict).
    """
    from mixlift_mcp.readout import generate_readout  # noqa: PLC0415

    output_dir = tmp_path_factory.mktemp("e2e_readout")
    summary = generate_readout(e2e_result, str(output_dir))

    # Copy to a stable location for manual inspection
    inspect_dir = PROJECT_ROOT / "test_output"
    if inspect_dir.exists():
        shutil.rmtree(inspect_dir)
    shutil.copytree(output_dir, inspect_dir)

    return {"dir": output_dir, "summary": summary}


@pytest.fixture(scope="session")
def e2e_readout_files(e2e_readout_dir) -> dict[str, str]:  # type: ignore[no-untyped-def]
    """Read all .md files from today's readout run into a ``filename -> text`` dict."""
    from datetime import date  # noqa: PLC0415

    run_dir = e2e_readout_dir["dir"] / "MixLift" / date.today().isoformat()
    files: dict[str, str] = {}
    for md_file in run_dir.glob("*.md"):
        files[md_file.name] = md_file.read_text()
    return files


# ---------------------------------------------------------------------------
# Short-dataset fixture (exercises exploratory analysis badge)
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def e2e_short_result(tmp_path_factory) -> dict:  # type: ignore[no-untyped-def]
    """Run MCMC on a 15-week dataset.

    15 weeks is below the 26-week threshold so ``_build_result`` attaches
    an ``analysis_badge`` of type ``"exploratory"``.  Tests that assert on
    that badge should use this fixture rather than ``e2e_result``.
    """
    from mixlift.ingest.loader import load_wide_format as _load_wide_format  # noqa: PLC0415
    from mixlift.modeling.engine import (  # noqa: PLC0415
        extract_saturation_curves,
        run_full_pipeline,
    )
    from mixlift.modeling.optimizer import optimize_budget  # noqa: PLC0415
    from mixlift_mcp.license import LicenseStatus  # noqa: PLC0415
    from mixlift_mcp.server import _build_result  # noqa: PLC0415
    from scripts.generate_synthetic import generate_synthetic_data  # noqa: PLC0415

    tmp_dir = tmp_path_factory.mktemp("e2e_short")
    csv_path = str(tmp_dir / "short.csv")
    df = generate_synthetic_data(n_weeks=15, seed=99, output_path=csv_path)

    X, y, channel_columns = _load_wide_format(df)  # noqa: N806
    dates = pd.to_datetime(df["date"])
    data_weeks = float((dates.max() - dates.min()).days / 7)

    model_results = run_full_pipeline(X, y, channel_columns, mcmc_config=FAST_MCMC)
    optimization = optimize_budget(
        model_results.mmm,
        X,
        channel_columns,
        contributions=model_results.raw_contributions,
    )
    saturation_curves = extract_saturation_curves(model_results.mmm, X, channel_columns)

    license_status = LicenseStatus(
        is_pro=True,
        max_channels=8,
        max_rows=50_000,
        message="Test pro license",
    )
    result = _build_result(
        model_results=model_results,
        optimization=optimization,
        saturation_curves=saturation_curves,
        channel_columns=channel_columns,
        license_status=license_status,
        csv_format="wide",
        data_weeks=data_weeks,
    )
    result["saturation_curves"] = saturation_curves
    result["memory"] = {"note": "First analysis."}

    return result
