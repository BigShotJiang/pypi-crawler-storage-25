"""Flow E: Edge cases -- short dataset, exploratory badge."""

from __future__ import annotations

from datetime import date

import pytest


@pytest.mark.e2e
class TestShortDataset:
    def test_short_dataset_succeeds(self, e2e_short_result):
        assert e2e_short_result["status"] == "success"

    def test_exploratory_badge_present(self, e2e_short_result):
        badge = e2e_short_result.get("analysis_badge")
        assert badge is not None
        assert badge["type"] == "exploratory"

    def test_exploratory_badge_mentions_weeks(self, e2e_short_result):
        badge = e2e_short_result.get("analysis_badge", {})
        note = badge.get("note", "")
        assert "week" in note.lower()

    def test_short_roas_positive(self, e2e_short_result):
        estimates = e2e_short_result.get("roas", {}).get("estimates", {})
        # With very short data at least check they're not all zero
        assert any(v > 0 for v in estimates.values())

    def test_exploratory_callout_in_readout(self, e2e_short_result, tmp_path_factory):
        from mixlift_mcp.readout import generate_readout

        out = tmp_path_factory.mktemp("short_readout")
        generate_readout(e2e_short_result, str(out))
        memo = (out / "MixLift" / date.today().isoformat() / "budget-memo.md").read_text()
        assert "> [!warning]" in memo

    def test_exploratory_badge_in_frontmatter(self, e2e_short_result, tmp_path_factory):
        from mixlift_mcp.readout import generate_readout
        from tests.test_e2e.test_obsidian_validation import validate_yaml_frontmatter

        out = tmp_path_factory.mktemp("short_fm_readout")
        generate_readout(e2e_short_result, str(out))
        memo = (out / "MixLift" / date.today().isoformat() / "budget-memo.md").read_text()
        fm = validate_yaml_frontmatter(memo)
        assert fm.get("analysis_badge") == "exploratory"

    def test_short_result_has_three_channels(self, e2e_short_result):
        # generate_synthetic always produces 3 channels
        assert e2e_short_result["data"]["n_channels"] == 3

    def test_short_sources_written(self, e2e_short_result, tmp_path_factory):
        from mixlift_mcp.readout import generate_readout

        out = tmp_path_factory.mktemp("short_sources")
        summary = generate_readout(e2e_short_result, str(out))
        assert summary["status"] == "success"
        written_names = [p.split("/")[-1] for p in summary["files_written"]]
        assert "sources.md" in written_names
