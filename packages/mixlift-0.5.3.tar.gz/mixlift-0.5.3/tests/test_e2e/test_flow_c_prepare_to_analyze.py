"""Flow C: Prepare -> Analyze (platform CSV formats)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent.parent / "fixtures"


@pytest.mark.e2e
class TestPrepareMetaFormat:
    async def test_meta_format_detected(self):
        """mixlift_prepare detects and converts Meta CSV format."""
        from mixlift_mcp.server import mixlift_prepare

        meta_csv = str(FIXTURES_DIR / "meta_export.csv")
        # Meta Ads Manager uses "Campaign Name" and "Amount Spent (USD)" —
        # pass explicit overrides since these aren't in the generic candidate list
        result = await mixlift_prepare(
            csv_path=meta_csv,
            channel_col="Campaign Name",
            spend_col="Amount Spent (USD)",
            revenue_col="Purchase Conversion Value",
        )
        data = json.loads(result)
        assert data.get("status") in ("success", "already_wide"), data.get("message", "")

    async def test_google_format_detected(self):
        """mixlift_prepare detects and converts Google CSV format."""
        from mixlift_mcp.server import mixlift_prepare

        google_csv = str(FIXTURES_DIR / "google_export.csv")
        # Google Ads uses "Campaign" as channel column — pass explicit override
        result = await mixlift_prepare(
            csv_path=google_csv,
            channel_col="Campaign",
            spend_col="Cost",
            revenue_col="Conv. value",
        )
        data = json.loads(result)
        assert data.get("status") in ("success", "already_wide"), data.get("message", "")

    async def test_meta_prepare_output_is_readable(self, tmp_path):
        """Output CSV from Meta prepare is wide-format and readable by mixlift_analyze."""
        import pandas as pd

        from mixlift_mcp.server import mixlift_prepare

        meta_csv = str(FIXTURES_DIR / "meta_export.csv")
        result_raw = await mixlift_prepare(csv_path=meta_csv)
        data = json.loads(result_raw)

        if data["status"] == "success":
            out_path = data["output_path"]
            df = pd.read_csv(out_path)
            spend_cols = [c for c in df.columns if c.endswith("_spend")]
            assert len(spend_cols) >= 1, f"No spend columns in output: {list(df.columns)}"
            assert "date" in df.columns
        # already_wide case: fixture CSV isn't platform format — acceptable

    async def test_google_prepare_output_is_readable(self, tmp_path):
        """Output CSV from Google prepare is wide-format and readable by mixlift_analyze."""
        import pandas as pd

        from mixlift_mcp.server import mixlift_prepare

        google_csv = str(FIXTURES_DIR / "google_export.csv")
        result_raw = await mixlift_prepare(csv_path=google_csv)
        data = json.loads(result_raw)

        if data["status"] == "success":
            out_path = data["output_path"]
            df = pd.read_csv(out_path)
            spend_cols = [c for c in df.columns if c.endswith("_spend")]
            assert len(spend_cols) >= 1, f"No spend columns in output: {list(df.columns)}"
            assert "date" in df.columns
