"""Tests for platform_revenue ingestion layer (N9 Platform Attribution Comparison)."""

from __future__ import annotations

import math

import pandas as pd
import pytest

from mixlift.ingest.parsers.generic import parse_generic_csv
from mixlift.ingest.parsers.google import parse_google_csv
from mixlift.ingest.parsers.meta import parse_meta_csv
from mixlift.ingest.parsers.tiktok import parse_tiktok_csv
from mixlift.ingest.platform_revenue import (
    _parse_currency,
    detect_platform_revenue_columns,
    extract_platform_revenue,
    parse_revenue_series,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_dates(n: int = 10) -> pd.DatetimeIndex:
    return pd.date_range("2024-01-01", periods=n, freq="D")


# ---------------------------------------------------------------------------
# test_meta_extracts_revenue
# ---------------------------------------------------------------------------

class TestMetaExtractsRevenue:
    def test_meta_extracts_revenue(self):
        """Meta CSV with 'Purchases Conversion Value' column aggregates by channel."""
        df = pd.DataFrame({
            "Date": _make_dates(6),
            "Campaign Name": ["Prospecting"] * 3 + ["Retargeting"] * 3,
            "Amount Spent (USD)": [100.0] * 6,
            "Impressions": [5000] * 6,
            "Link Clicks": [200] * 6,
            "Purchases": [10] * 6,
            "Purchases Conversion Value": [500.0, 600.0, 700.0, 200.0, 300.0, 400.0],
        })
        result = parse_meta_csv(df)
        assert "platform_revenue" in result.columns
        totals = extract_platform_revenue(result, "meta")
        assert totals["Prospecting"] == pytest.approx(1800.0)
        assert totals["Retargeting"] == pytest.approx(900.0)

    def test_meta_revenue_absent_omits_column(self):
        """When no revenue column exists, platform_revenue is not added."""
        df = pd.DataFrame({
            "Date": _make_dates(3),
            "Campaign Name": ["Prospecting"] * 3,
            "Amount Spent (USD)": [100.0] * 3,
            "Impressions": [5000] * 3,
            "Link Clicks": [200] * 3,
            "Purchases": [10] * 3,
        })
        result = parse_meta_csv(df)
        assert "platform_revenue" not in result.columns

    def test_meta_revenue_case_insensitive(self):
        """'purchases conversion value' (lowercase) matches the alias."""
        df = pd.DataFrame({
            "Date": _make_dates(3),
            "Campaign Name": ["Prospecting"] * 3,
            "Amount Spent (USD)": [100.0] * 3,
            "Impressions": [5000] * 3,
            "Link Clicks": [200] * 3,
            "Purchases": [10] * 3,
            "purchases conversion value": [100.0, 200.0, 300.0],
        })
        result = parse_meta_csv(df)
        assert "platform_revenue" in result.columns
        assert result["platform_revenue"].sum() == pytest.approx(600.0)


# ---------------------------------------------------------------------------
# test_google_extracts_revenue
# ---------------------------------------------------------------------------

class TestGoogleExtractsRevenue:
    def test_google_extracts_revenue(self):
        """Google CSV with 'Conv. value' column aggregates by channel."""
        df = pd.DataFrame({
            "Date": _make_dates(4),
            "Campaign": ["Search"] * 2 + ["Shopping"] * 2,
            "Cost": [120.0] * 4,
            "Impressions": [8000] * 4,
            "Clicks": [300] * 4,
            "Conversions": [15] * 4,
            "Conv. value": [1000.0, 1100.0, 500.0, 600.0],
        })
        result = parse_google_csv(df)
        assert "platform_revenue" in result.columns
        totals = extract_platform_revenue(result, "google")
        assert totals["Search"] == pytest.approx(2100.0)
        assert totals["Shopping"] == pytest.approx(1100.0)

    def test_google_revenue_absent_omits_column(self):
        df = pd.DataFrame({
            "Date": _make_dates(2),
            "Campaign": ["Search"] * 2,
            "Cost": [120.0] * 2,
            "Impressions": [8000] * 2,
            "Clicks": [300] * 2,
        })
        result = parse_google_csv(df)
        assert "platform_revenue" not in result.columns


# ---------------------------------------------------------------------------
# test_tiktok_extracts_revenue
# ---------------------------------------------------------------------------

class TestTikTokExtractsRevenue:
    def test_tiktok_extracts_revenue(self):
        """TikTok CSV with 'Total complete payment value' aggregates by channel."""
        df = pd.DataFrame({
            "Date": _make_dates(4),
            "Campaign Name": ["Brand"] * 2 + ["Performance"] * 2,
            "Objective Type": ["REACH"] * 4,
            "Cost": [50.0] * 4,
            "Impression": [3000] * 4,
            "Click": [100] * 4,
            "Total Complete Payment": [5] * 4,
            "Total complete payment value": [250.0, 300.0, 100.0, 150.0],
        })
        result = parse_tiktok_csv(df)
        assert "platform_revenue" in result.columns
        totals = extract_platform_revenue(result, "tiktok")
        assert totals["Brand"] == pytest.approx(550.0)
        assert totals["Performance"] == pytest.approx(250.0)

    def test_tiktok_revenue_absent_omits_column(self):
        df = pd.DataFrame({
            "Date": _make_dates(2),
            "Campaign Name": ["Brand"] * 2,
            "Objective Type": ["REACH"] * 2,
            "Cost": [50.0] * 2,
            "Impression": [3000] * 2,
            "Click": [100] * 2,
        })
        result = parse_tiktok_csv(df)
        assert "platform_revenue" not in result.columns


# ---------------------------------------------------------------------------
# test_generic_extracts_revenue
# ---------------------------------------------------------------------------

class TestGenericExtractsRevenue:
    def test_generic_extracts_revenue(self):
        """Generic CSV with 'revenue' column is mapped to platform_revenue."""
        df = pd.DataFrame({
            "date": _make_dates(4),
            "channel": ["Email"] * 2 + ["Display"] * 2,
            "spend": [50.0] * 4,
            "revenue": [200.0, 300.0, 100.0, 150.0],
        })
        result = parse_generic_csv(df)
        assert "platform_revenue" in result.columns
        totals = extract_platform_revenue(result, "generic")
        assert totals["Email"] == pytest.approx(500.0)
        assert totals["Display"] == pytest.approx(250.0)

    def test_generic_platform_revenue_column(self):
        """'platform_revenue' column name also matches."""
        df = pd.DataFrame({
            "date": _make_dates(2),
            "channel": ["Email"] * 2,
            "spend": [50.0] * 2,
            "platform_revenue": [400.0, 600.0],
        })
        result = parse_generic_csv(df)
        assert "platform_revenue" in result.columns
        assert result["platform_revenue"].sum() == pytest.approx(1000.0)


# ---------------------------------------------------------------------------
# Currency parsing
# ---------------------------------------------------------------------------

class TestCurrencyStringParsed:
    def test_us_format(self):
        """'$1,234.56' → 1234.56"""
        assert _parse_currency("$1,234.56") == pytest.approx(1234.56)

    def test_no_symbol(self):
        assert _parse_currency("1234.56") == pytest.approx(1234.56)

    def test_integer_string(self):
        assert _parse_currency("500") == pytest.approx(500.0)

    def test_numeric_int(self):
        assert _parse_currency(500) == pytest.approx(500.0)

    def test_numeric_float(self):
        assert _parse_currency(1234.56) == pytest.approx(1234.56)

    def test_thousands_comma(self):
        assert _parse_currency("1,000.00") == pytest.approx(1000.0)


class TestEuropeanCurrencyString:
    def test_european_format_with_decimal(self):
        """'1.234,56' → 1234.56"""
        assert _parse_currency("1.234,56") == pytest.approx(1234.56)

    def test_european_format_no_decimal(self):
        """'1.234' — ambiguous (could be 1234 or 1.234); treated as integer thousands."""
        # Our regex matches 1.234 as European thousands → 1234.0
        result = _parse_currency("1.234")
        # Accept either 1234.0 (European) or NaN (ambiguous) — document either as valid
        assert result == pytest.approx(1234.0) or math.isnan(result)

    def test_european_large(self):
        """'2.500,00' → 2500.0"""
        assert _parse_currency("2.500,00") == pytest.approx(2500.0)


class TestNanHandled:
    def test_nan_cell_becomes_zero(self):
        """NaN cells → 0.0 after parse_revenue_series."""
        import numpy as np
        s = pd.Series([100.0, float("nan"), 200.0, np.nan])
        result = parse_revenue_series(s)
        assert result.tolist() == pytest.approx([100.0, 0.0, 200.0, 0.0])

    def test_blank_string_becomes_zero(self):
        s = pd.Series(["", "100.0"])
        result = parse_revenue_series(s)
        assert result.iloc[0] == pytest.approx(0.0)
        assert result.iloc[1] == pytest.approx(100.0)

    def test_none_becomes_zero(self):
        s = pd.Series([None, 50.0])
        result = parse_revenue_series(s)
        assert result.iloc[0] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# test_missing_column_returns_empty
# ---------------------------------------------------------------------------

class TestMissingColumnReturnsEmpty:
    def test_missing_column_returns_empty(self):
        """DataFrame without platform_revenue → empty dict."""
        df = pd.DataFrame({
            "date": _make_dates(3),
            "channel": ["Email"] * 3,
            "spend": [50.0] * 3,
            "impressions": [1000] * 3,
            "clicks": [50] * 3,
            "conversions": [5] * 3,
        })
        assert extract_platform_revenue(df, "generic") == {}

    def test_no_channel_column_returns_empty(self):
        """DataFrame without channel column → empty dict."""
        df = pd.DataFrame({
            "date": _make_dates(2),
            "platform_revenue": [100.0, 200.0],
        })
        assert extract_platform_revenue(df, "generic") == {}


# ---------------------------------------------------------------------------
# test_wide_format_detection
# ---------------------------------------------------------------------------

class TestWideFormatDetection:
    def test_wide_format_detection(self):
        """Detects meta_platform_revenue and google_platform_revenue columns."""
        df = pd.DataFrame({
            "date": _make_dates(3),
            "meta_spend": [100.0] * 3,
            "meta_platform_revenue": [500.0] * 3,
            "google_spend": [80.0] * 3,
            "google_platform_revenue": [400.0] * 3,
        })
        detected = detect_platform_revenue_columns(df)
        assert detected == {
            "meta": "meta_platform_revenue",
            "google": "google_platform_revenue",
        }

    def test_wide_format_no_matches(self):
        """DF without matching columns → empty dict."""
        df = pd.DataFrame({
            "date": _make_dates(2),
            "meta_spend": [100.0] * 2,
            "google_spend": [80.0] * 2,
            "revenue": [500.0] * 2,
        })
        assert detect_platform_revenue_columns(df) == {}

    def test_wide_format_case_insensitive_suffix(self):
        """Column ending in _platform_revenue (uppercase) is still detected."""
        df = pd.DataFrame({
            "Meta_Platform_Revenue": [100.0],
            "other_col": [1],
        })
        detected = detect_platform_revenue_columns(df)
        # The channel name is whatever precedes the suffix
        assert "Meta" in detected or "meta" in detected.get("Meta", "Meta_Platform_Revenue")


# ---------------------------------------------------------------------------
# test_aggregation_sums_across_dates
# ---------------------------------------------------------------------------

class TestAggregationSumsAcrossDates:
    def test_aggregation_sums_across_dates(self):
        """Multi-row CSV per channel → sums over all rows."""
        df = pd.DataFrame({
            "Date": _make_dates(6),
            "Campaign Name": ["Alpha"] * 3 + ["Beta"] * 3,
            "Amount Spent (USD)": [100.0] * 6,
            "Impressions": [5000] * 6,
            "Link Clicks": [200] * 6,
            "Purchases": [10] * 6,
            "Purchases Conversion Value": [100.0, 200.0, 300.0, 50.0, 75.0, 25.0],
        })
        canonical = parse_meta_csv(df)
        totals = extract_platform_revenue(canonical, "meta")
        assert totals["Alpha"] == pytest.approx(600.0)
        assert totals["Beta"] == pytest.approx(150.0)


# ---------------------------------------------------------------------------
# test_case_insensitive_column_match
# ---------------------------------------------------------------------------

class TestCaseInsensitiveColumnMatch:
    def test_case_insensitive_column_match(self):
        """Column 'PURCHASES CONVERSION VALUE' (all-caps) matches Meta alias."""
        df = pd.DataFrame({
            "Date": _make_dates(3),
            "Campaign Name": ["CampaignX"] * 3,
            "Amount Spent (USD)": [100.0] * 3,
            "Impressions": [5000] * 3,
            "Link Clicks": [200] * 3,
            "Purchases": [10] * 3,
            "PURCHASES CONVERSION VALUE": [111.0, 222.0, 333.0],
        })
        result = parse_meta_csv(df)
        assert "platform_revenue" in result.columns
        assert result["platform_revenue"].sum() == pytest.approx(666.0)

    def test_case_insensitive_google(self):
        """'CONV. VALUE' matches Google alias."""
        df = pd.DataFrame({
            "Date": _make_dates(2),
            "Campaign": ["Search"] * 2,
            "Cost": [120.0] * 2,
            "Impressions": [8000] * 2,
            "Clicks": [300] * 2,
            "CONV. VALUE": [500.0, 600.0],
        })
        result = parse_google_csv(df)
        assert "platform_revenue" in result.columns
        assert result["platform_revenue"].sum() == pytest.approx(1100.0)
