"""Unit tests for mixlift_mcp.cleaners.fixers — one test class per fixer."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.cleaners.detectors import Issue, run_all_detectors
from mixlift_mcp.cleaners.fixers import (
    apply_all_fixes,
    fix_aggregation_mismatch,
    fix_channel_name_inconsistency,
    fix_currency_markers,
    fix_date_format,
    fix_duplicate_rows,
    fix_empty_columns_rows,
    fix_whitespace,
)

# ---------------------------------------------------------------------------
# Shared helper
# ---------------------------------------------------------------------------


def _weekly_df(
    channels: list[str] | None = None,
    n_weeks: int = 20,
    start: str = "2025-01-06",
) -> pd.DataFrame:
    if channels is None:
        channels = ["Meta", "Google"]
    dates = pd.date_range(start, periods=n_weeks, freq="W-MON")
    rng = np.random.default_rng(42)
    rows = []
    for d in dates:
        for ch in channels:
            rows.append(
                {
                    "date": d.strftime("%Y-%m-%d"),
                    "channel": ch,
                    "spend": round(5000 + rng.uniform(-500, 500), 2),
                    "revenue": round(30000 + rng.uniform(-2000, 2000), 2),
                }
            )
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# fix_channel_name_inconsistency
# ---------------------------------------------------------------------------


class TestFixChannelNameInconsistency:
    def test_renames_fb_to_meta(self):
        df = _weekly_df()
        df.loc[df["channel"] == "Meta", "channel"] = "FB"
        fixed_df, result = fix_channel_name_inconsistency(df)
        assert "FB" not in fixed_df["channel"].values
        assert "Meta" in fixed_df["channel"].values

    def test_rows_changed_count(self):
        df = _weekly_df()
        n_fb = (df["channel"] == "Meta").sum()
        df.loc[df["channel"] == "Meta", "channel"] = "FB"
        _, result = fix_channel_name_inconsistency(df)
        assert result["rows_changed"] == n_fb

    def test_user_map_applied(self):
        df = _weekly_df()
        df.loc[df["channel"] == "Meta", "channel"] = "FBB"
        fixed_df, _ = fix_channel_name_inconsistency(df, user_map={"FBB": "Meta"})
        assert "FBB" not in fixed_df["channel"].values

    def test_no_channel_col_returns_unchanged(self):
        df = pd.DataFrame({"date": ["2025-01-06"], "spend": [100]})
        fixed_df, result = fix_channel_name_inconsistency(df)
        assert result["rows_changed"] == 0

    def test_fix_result_kind(self):
        df = _weekly_df()
        df.loc[0, "channel"] = "FB"
        _, result = fix_channel_name_inconsistency(df)
        assert result["kind"] == "channel_name_inconsistency"


# ---------------------------------------------------------------------------
# fix_duplicate_rows
# ---------------------------------------------------------------------------


class TestFixDuplicateRows:
    def test_removes_exact_duplicates(self):
        df = _weekly_df(n_weeks=4)
        n_before = len(df)
        row = df.iloc[0:1]
        df = pd.concat([df, row], ignore_index=True)
        fixed_df, result = fix_duplicate_rows(df)
        assert len(fixed_df) <= n_before
        assert result["rows_changed"] >= 1

    def test_keeps_row_with_more_non_null(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06", "2025-01-06"],
                "channel": ["Meta", "Meta"],
                "spend": [5000.0, None],
                "revenue": [30000.0, 30000.0],
            }
        )
        fixed_df, _ = fix_duplicate_rows(df)
        assert len(fixed_df) == 1
        # The row with spend=5000 should be kept
        assert fixed_df.iloc[0]["spend"] == 5000.0

    def test_no_dupes_unchanged(self):
        df = _weekly_df(n_weeks=4)
        n_before = len(df)
        fixed_df, result = fix_duplicate_rows(df)
        assert len(fixed_df) == n_before
        assert result["rows_changed"] == 0

    def test_fix_result_kind(self):
        df = _weekly_df(n_weeks=2)
        row = df.iloc[0:1]
        df = pd.concat([df, row], ignore_index=True)
        _, result = fix_duplicate_rows(df)
        assert result["kind"] == "duplicate_rows"


# ---------------------------------------------------------------------------
# fix_aggregation_mismatch
# ---------------------------------------------------------------------------


class TestFixAggregationMismatch:
    def test_collapses_daily_to_weekly(self):
        dates = pd.date_range("2025-01-01", periods=28, freq="D").strftime("%Y-%m-%d").tolist()
        df = pd.DataFrame(
            {
                "date": dates,
                "channel": ["Meta"] * len(dates),
                "spend": [200.0] * len(dates),
                "revenue": [1000.0] * len(dates),
            }
        )
        fixed_df, result = fix_aggregation_mismatch(df)
        assert len(fixed_df) < len(df)
        assert result["rows_changed"] > 0

    def test_spend_is_summed(self):
        dates = pd.date_range("2025-01-06", periods=7, freq="D").strftime("%Y-%m-%d").tolist()
        df = pd.DataFrame(
            {
                "date": dates,
                "channel": ["Meta"] * 7,
                "spend": [100.0] * 7,
                "revenue": [500.0] * 7,
            }
        )
        fixed_df, _ = fix_aggregation_mismatch(df)
        assert fixed_df["spend"].iloc[0] == pytest.approx(700.0, rel=0.01)

    def test_weekly_data_unchanged(self):
        df = _weekly_df(n_weeks=8)
        n_before = len(df)
        fixed_df, result = fix_aggregation_mismatch(df)
        # Weekly data should not be collapsed further
        assert len(fixed_df) <= n_before

    def test_no_date_col_unchanged(self):
        df = pd.DataFrame({"channel": ["Meta"] * 5, "spend": [100.0] * 5})
        fixed_df, result = fix_aggregation_mismatch(df)
        assert result["rows_changed"] == 0


# ---------------------------------------------------------------------------
# fix_currency_markers
# ---------------------------------------------------------------------------


class TestFixCurrencyMarkers:
    def test_strips_dollar_sign(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["$5,200"],
                "revenue": ["$32,000"],
            }
        )
        fixed_df, result = fix_currency_markers(df)
        assert pd.api.types.is_numeric_dtype(fixed_df["spend"])
        assert fixed_df["spend"].iloc[0] == pytest.approx(5200.0)

    def test_strips_commas(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["5,200"],
                "revenue": ["32,000"],
            }
        )
        fixed_df, _ = fix_currency_markers(df)
        assert fixed_df["spend"].iloc[0] == pytest.approx(5200.0)

    def test_strips_usd(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["5200 USD"],
                "revenue": [32000],
            }
        )
        fixed_df, _ = fix_currency_markers(df)
        assert fixed_df["spend"].iloc[0] == pytest.approx(5200.0)

    def test_numeric_columns_untouched(self):
        df = _weekly_df(n_weeks=2)
        fixed_df, result = fix_currency_markers(df)
        assert result["rows_changed"] == 0

    def test_fix_result_kind(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["$5,200"],
                "revenue": [32000],
            }
        )
        _, result = fix_currency_markers(df)
        assert result["kind"] == "currency_markers"


# ---------------------------------------------------------------------------
# fix_whitespace
# ---------------------------------------------------------------------------


class TestFixWhitespace:
    def test_strips_header_whitespace(self):
        df = pd.DataFrame(
            {
                " date ": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": [5200],
                "revenue": [32000],
            }
        )
        fixed_df, result = fix_whitespace(df)
        assert "date" in fixed_df.columns
        assert " date " not in fixed_df.columns

    def test_strips_value_whitespace(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["  Meta  "],
                "spend": [5200],
                "revenue": [32000],
            }
        )
        fixed_df, _ = fix_whitespace(df)
        assert fixed_df["channel"].iloc[0] == "Meta"

    def test_rows_changed_positive(self):
        df = pd.DataFrame(
            {
                "date": [" 2025-01-06 "],
                "channel": ["  Meta  "],
                "spend": [5200],
                "revenue": [32000],
            }
        )
        _, result = fix_whitespace(df)
        assert result["rows_changed"] > 0

    def test_clean_data_zero_changes(self):
        df = _weekly_df(n_weeks=2)
        _, result = fix_whitespace(df)
        assert result["rows_changed"] == 0


# ---------------------------------------------------------------------------
# fix_empty_columns_rows
# ---------------------------------------------------------------------------


class TestFixEmptyColumnsRows:
    def test_drops_null_column(self):
        df = _weekly_df(n_weeks=4)
        df["empty_col"] = None
        fixed_df, result = fix_empty_columns_rows(df)
        assert "empty_col" not in fixed_df.columns
        assert result["rows_changed"] > 0

    def test_drops_null_rows(self):
        df = _weekly_df(n_weeks=4)
        empty_row = pd.DataFrame([[None, None, None, None]], columns=df.columns)
        df = pd.concat([df, empty_row], ignore_index=True)
        n_before = len(df)
        fixed_df, result = fix_empty_columns_rows(df)
        assert len(fixed_df) == n_before - 1

    def test_clean_data_unchanged(self):
        df = _weekly_df(n_weeks=2)
        n_cols = len(df.columns)
        n_rows = len(df)
        fixed_df, result = fix_empty_columns_rows(df)
        assert len(fixed_df.columns) == n_cols
        assert len(fixed_df) == n_rows


# ---------------------------------------------------------------------------
# fix_date_format
# ---------------------------------------------------------------------------


class TestFixDateFormat:
    def test_converts_us_format_to_iso(self):
        df = pd.DataFrame(
            {
                "date": ["01/13/2025", "01/20/2025", "01/27/2025"],
                "channel": ["Meta"] * 3,
                "spend": [5200, 5100, 4900],
                "revenue": [32000, 31500, 30800],
            }
        )
        fixed_df, result = fix_date_format(df)
        assert all(fixed_df["date"].str.match(r"\d{4}-\d{2}-\d{2}"))

    def test_already_iso_zero_changes(self):
        df = _weekly_df(n_weeks=4)
        _, result = fix_date_format(df)
        assert result["rows_changed"] == 0

    def test_fix_result_kind(self):
        df = pd.DataFrame(
            {
                "date": ["01/13/2025"],
                "channel": ["Meta"],
                "spend": [5200],
                "revenue": [32000],
            }
        )
        _, result = fix_date_format(df)
        assert result["kind"] == "date_format"

    def test_no_date_col_unchanged(self):
        df = pd.DataFrame({"channel": ["Meta"], "spend": [100]})
        _, result = fix_date_format(df)
        assert result["rows_changed"] == 0


# ---------------------------------------------------------------------------
# apply_all_fixes orchestrator
# ---------------------------------------------------------------------------


class TestApplyAllFixes:
    def test_applies_channel_rename(self):
        df = _weekly_df()
        df.loc[df["channel"] == "Meta", "channel"] = "FB"
        issues = run_all_detectors(df)
        fixed_df, applied = apply_all_fixes(df, issues)
        assert "FB" not in fixed_df["channel"].values

    def test_no_auto_issues_returns_unchanged(self):
        df = _weekly_df()
        issues = [
            Issue(
                kind="outlier_spike",
                severity="high",
                description="manual only",
                affected_rows=1,
                auto_applies=False,
            )
        ]
        fixed_df, applied = apply_all_fixes(df, issues)
        assert applied == []
        assert len(fixed_df) == len(df)

    def test_returns_fix_list_with_kinds(self):
        df = _weekly_df()
        df.loc[0, "channel"] = "FB"
        issues = run_all_detectors(df)
        _, applied = apply_all_fixes(df, issues)
        kinds = {r["kind"] for r in applied}
        assert kinds  # at least one fix applied

    def test_fix_result_has_required_keys(self):
        df = _weekly_df()
        df.loc[0, "channel"] = "FB"
        issues = run_all_detectors(df)
        _, applied = apply_all_fixes(df, issues)
        for fix in applied:
            assert "kind" in fix
            assert "description" in fix
            assert "rows_changed" in fix

    def test_empty_issues_no_fixes(self):
        df = _weekly_df()
        fixed_df, applied = apply_all_fixes(df, [])
        assert applied == []
