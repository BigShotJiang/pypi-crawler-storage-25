"""Tests for mixlift_mcp.cleaners.aliases — channel alias canonicalization."""

from __future__ import annotations

from mixlift_mcp.cleaners.aliases import CHANNEL_ALIASES, canonicalize_channel


class TestBuiltinAliasTable:
    def test_fb_maps_to_meta(self):
        assert canonicalize_channel("FB") == "Meta"

    def test_facebook_maps_to_meta(self):
        assert canonicalize_channel("facebook") == "Meta"

    def test_meta_ads_maps_to_meta(self):
        assert canonicalize_channel("Meta Ads") == "Meta"

    def test_fb_ads_maps_to_meta(self):
        assert canonicalize_channel("fb_ads") == "Meta"

    def test_adwords_maps_to_google(self):
        assert canonicalize_channel("AdWords") == "Google"

    def test_google_ads_maps_to_google(self):
        assert canonicalize_channel("Google Ads") == "Google"

    def test_google_search_maps_to_google(self):
        assert canonicalize_channel("google_search") == "Google"

    def test_google_display_maps_to_google(self):
        assert canonicalize_channel("google_display") == "Google"

    def test_ttk_maps_to_tiktok(self):
        assert canonicalize_channel("TTK") == "TikTok"

    def test_tiktok_ads_maps_to_tiktok(self):
        assert canonicalize_channel("tiktok_ads") == "TikTok"

    def test_li_maps_to_linkedin(self):
        assert canonicalize_channel("LI") == "LinkedIn"

    def test_li_ads_maps_to_linkedin(self):
        assert canonicalize_channel("li_ads") == "LinkedIn"

    def test_snap_maps_to_snapchat(self):
        assert canonicalize_channel("Snap") == "Snapchat"

    def test_snap_ads_maps_to_snapchat(self):
        assert canonicalize_channel("snap_ads") == "Snapchat"

    def test_pin_maps_to_pinterest(self):
        assert canonicalize_channel("pin") == "Pinterest"

    def test_pinterest_ads_maps_to_pinterest(self):
        assert canonicalize_channel("pinterest_ads") == "Pinterest"

    def test_x_maps_to_twitter(self):
        assert canonicalize_channel("X") == "Twitter"

    def test_twitter_ads_maps_to_twitter(self):
        assert canonicalize_channel("twitter_ads") == "Twitter"


class TestCaseInsensitivity:
    def test_uppercase_fb(self):
        assert canonicalize_channel("FB") == "Meta"

    def test_lowercase_fb(self):
        assert canonicalize_channel("fb") == "Meta"

    def test_mixed_case_facebook(self):
        assert canonicalize_channel("FaCeBoOk") == "Meta"

    def test_meta_ads_titlecase(self):
        assert canonicalize_channel("Meta Ads") == "Meta"


class TestUnknownChannels:
    def test_unknown_returns_stripped(self):
        result = canonicalize_channel("MyCustomChannel")
        assert result == "MyCustomChannel"

    def test_unknown_with_whitespace_returns_stripped(self):
        result = canonicalize_channel("  CustomChannel  ")
        assert result == "CustomChannel"

    def test_already_canonical_meta_unchanged(self):
        result = canonicalize_channel("Meta")
        assert result == "Meta"

    def test_already_canonical_tiktok_unchanged(self):
        result = canonicalize_channel("TikTok")
        assert result == "TikTok"


class TestUserMapOverride:
    def test_user_map_takes_precedence_over_builtin(self):
        # If user maps "FB" -> "Facebook Brand" it should override the built-in
        result = canonicalize_channel("FB", user_map={"FB": "Facebook Brand"})
        assert result == "Facebook Brand"

    def test_user_map_case_insensitive(self):
        result = canonicalize_channel("fb", user_map={"FB": "Facebook Brand"})
        assert result == "Facebook Brand"

    def test_user_map_does_not_affect_other_values(self):
        result = canonicalize_channel("Google Ads", user_map={"FB": "Facebook Brand"})
        assert result == "Google"

    def test_user_map_none_falls_through_to_builtin(self):
        result = canonicalize_channel("FB", user_map=None)
        assert result == "Meta"

    def test_user_map_empty_falls_through_to_builtin(self):
        result = canonicalize_channel("FB", user_map={})
        assert result == "Meta"

    def test_user_map_value_is_stripped(self):
        result = canonicalize_channel("FB", user_map={"FB": " Meta Brand "})
        assert result == "Meta Brand"


class TestAliasTableCoverage:
    def test_alias_table_is_dict(self):
        assert isinstance(CHANNEL_ALIASES, dict)

    def test_alias_table_nonempty(self):
        assert len(CHANNEL_ALIASES) > 10

    def test_all_alias_keys_lowercase(self):
        for k in CHANNEL_ALIASES:
            assert k == k.lower(), f"Key '{k}' is not lowercase"

    def test_all_canonical_values_are_strings(self):
        for v in CHANNEL_ALIASES.values():
            assert isinstance(v, str)
