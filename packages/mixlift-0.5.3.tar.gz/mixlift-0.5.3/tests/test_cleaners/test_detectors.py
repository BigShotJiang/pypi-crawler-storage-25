"""Unit tests for mixlift_mcp.cleaners.detectors — one test class per detection rule."""

from __future__ import annotations

import numpy as np
import pandas as pd

from mixlift_mcp.cleaners.detectors import (
    Issue,
    detect_aggregation_mismatch,
    detect_all_zero_spend_rows,
    detect_channel_name_inconsistency,
    detect_currency_markers,
    detect_date_format_inconsistency,
    detect_duplicate_rows,
    detect_empty_columns_rows,
    detect_missing_weeks,
    detect_outlier_spikes,
    detect_whitespace,
    run_all_detectors,
)

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _weekly_df(
    channels: list[str] | None = None,
    n_weeks: int = 26,
    start: str = "2025-01-06",
    spend_base: float = 5000.0,
    revenue_base: float = 30000.0,
) -> pd.DataFrame:
    """Build a clean weekly DataFrame for use in tests."""
    if channels is None:
        channels = ["Meta", "Google"]
    dates = pd.date_range(start, periods=n_weeks, freq="W-MON")
    rows = []
    rng = np.random.default_rng(42)
    for d in dates:
        for ch in channels:
            rows.append(
                {
                    "date": d.strftime("%Y-%m-%d"),
                    "channel": ch,
                    "spend": spend_base + rng.uniform(-500, 500),
                    "revenue": revenue_base + rng.uniform(-2000, 2000),
                }
            )
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Rule 1: Channel name inconsistency
# ---------------------------------------------------------------------------


class TestDetectChannelNameInconsistency:
    def test_detects_fb_as_meta_alias(self):
        df = _weekly_df()
        df.loc[df["channel"] == "Meta", "channel"] = "FB"
        issues = detect_channel_name_inconsistency(df)
        kinds = [i.kind for i in issues]
        assert "channel_name_inconsistency" in kinds

    def test_detects_multiple_aliases_for_same_canonical(self):
        df = _weekly_df(channels=["Meta", "Meta", "Google"])
        df.loc[:5, "channel"] = "FB"
        df.loc[6:12, "channel"] = "facebook"
        issues = detect_channel_name_inconsistency(df)
        kinds = [i.kind for i in issues]
        assert "channel_name_inconsistency" in kinds

    def test_auto_applies_true(self):
        df = _weekly_df()
        df.loc[df["channel"] == "Meta", "channel"] = "FB"
        issues = detect_channel_name_inconsistency(df)
        assert all(i.auto_applies for i in issues if i.kind == "channel_name_inconsistency")

    def test_affected_values_contains_aliases(self):
        df = _weekly_df()
        df.loc[df["channel"] == "Meta", "channel"] = "fb"
        issues = detect_channel_name_inconsistency(df)
        cn_issues = [i for i in issues if i.kind == "channel_name_inconsistency"]
        assert cn_issues
        assert "fb" in cn_issues[0].affected_values

    def test_user_map_takes_precedence(self):
        # FB normally maps to Meta; user overrides it to "FacebookBrand"
        df = _weekly_df(channels=["FB", "Google"])
        issues = detect_channel_name_inconsistency(df, user_map={"fb": "FacebookBrand"})
        # The user_map should be used; if only "FB" exists (no "FacebookBrand" rows),
        # no inconsistency issue should fire for FB since it IS the canonical per user_map
        # — or it fires with proposed_fix pointing to "FacebookBrand"
        cn_issues = [i for i in issues if i.kind == "channel_name_inconsistency"]
        for issue in cn_issues:
            # proposed_fix must reference user_map canonical, not the built-in one
            assert "FacebookBrand" in issue.proposed_fix or "FB" not in issue.affected_values

    def test_no_false_positive_for_clean_data(self):
        df = _weekly_df(channels=["Meta", "Google", "TikTok"])
        issues = detect_channel_name_inconsistency(df)
        assert not any(i.kind == "channel_name_inconsistency" for i in issues)

    def test_no_channel_col_returns_empty(self):
        df = pd.DataFrame({"date": ["2025-01-06"], "spend": [100], "revenue": [500]})
        assert detect_channel_name_inconsistency(df) == []

    def test_severity_is_high(self):
        df = _weekly_df()
        df.loc[df["channel"] == "Meta", "channel"] = "FB"
        issues = detect_channel_name_inconsistency(df)
        for i in issues:
            if i.kind == "channel_name_inconsistency":
                assert i.severity == "high"


# ---------------------------------------------------------------------------
# Rule 2: Missing weeks
# ---------------------------------------------------------------------------


class TestDetectMissingWeeks:
    def test_detects_single_week_gap(self):
        dates = pd.date_range("2025-01-06", periods=10, freq="W-MON").strftime("%Y-%m-%d").tolist()
        dates.pop(4)  # remove one week
        n = len(dates)
        df = pd.DataFrame(
            {
                "date": dates * 2,
                "channel": ["Meta"] * n + ["Google"] * n,
                "spend": [100] * (n * 2),
                "revenue": [500] * (n * 2),
            }
        )
        issues = detect_missing_weeks(df)
        assert any(i.kind == "missing_weeks" for i in issues)

    def test_large_gap_has_high_severity(self):
        dates = (
            pd.date_range("2025-01-06", periods=6, freq="W-MON").strftime("%Y-%m-%d").tolist()
            + pd.date_range("2025-06-01", periods=6, freq="W-MON").strftime("%Y-%m-%d").tolist()
        )
        n = len(dates)
        df = pd.DataFrame(
            {
                "date": dates,
                "channel": ["Meta"] * n,
                "spend": [100] * n,
                "revenue": [500] * n,
            }
        )
        issues = detect_missing_weeks(df)
        high_issues = [i for i in issues if i.kind == "missing_weeks" and i.severity == "high"]
        assert high_issues

    def test_small_gap_has_low_severity(self):
        # Build a series with a 2-week gap (one missing week) → low severity
        # Use consecutive weekly dates with one week skipped
        dates = [
            "2025-01-06",
            "2025-01-13",
            # skip 2025-01-20 → 1 week gap
            "2025-01-27",
            "2025-02-03",
            "2025-02-10",
        ]
        df = pd.DataFrame(
            {
                "date": dates,
                "channel": ["Meta"] * len(dates),
                "spend": [100] * len(dates),
                "revenue": [500] * len(dates),
            }
        )
        issues = detect_missing_weeks(df)
        low_issues = [i for i in issues if i.kind == "missing_weeks" and i.severity == "low"]
        assert low_issues

    def test_no_gaps_no_issues(self):
        df = _weekly_df(n_weeks=12)
        issues = detect_missing_weeks(df)
        assert not any(i.kind == "missing_weeks" for i in issues)

    def test_only_one_date_returns_warning(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"] * 3,
                "channel": ["Meta", "Google", "TikTok"],
                "spend": [100, 200, 150],
                "revenue": [500, 600, 450],
            }
        )
        issues = detect_missing_weeks(df)
        assert any(i.kind == "only_one_date" for i in issues)

    def test_no_date_col_returns_empty(self):
        df = pd.DataFrame({"channel": ["Meta"], "spend": [100], "revenue": [500]})
        assert detect_missing_weeks(df) == []


# ---------------------------------------------------------------------------
# Rule 3: Outlier spikes
# ---------------------------------------------------------------------------


class TestDetectOutlierSpikes:
    def test_detects_large_spike(self):
        df = _weekly_df(channels=["Meta"], n_weeks=26)
        df.loc[12, "spend"] = 95000  # far above typical 5000
        issues = detect_outlier_spikes(df)
        assert any(i.kind == "outlier_spike" for i in issues)

    def test_auto_applies_false(self):
        df = _weekly_df(channels=["Meta"], n_weeks=26)
        df.loc[12, "spend"] = 95000
        issues = detect_outlier_spikes(df)
        for i in issues:
            if i.kind == "outlier_spike":
                assert i.auto_applies is False

    def test_severity_is_high(self):
        df = _weekly_df(channels=["Meta"], n_weeks=26)
        df.loc[12, "spend"] = 95000
        issues = detect_outlier_spikes(df)
        for i in issues:
            if i.kind == "outlier_spike":
                assert i.severity == "high"

    def test_no_spike_no_issue(self):
        df = _weekly_df(channels=["Meta"], n_weeks=26)
        issues = detect_outlier_spikes(df)
        assert not any(i.kind == "outlier_spike" for i in issues)

    def test_spike_description_includes_channel(self):
        df = _weekly_df(channels=["Meta"], n_weeks=26)
        df.loc[12, "spend"] = 100000
        issues = detect_outlier_spikes(df)
        spike_issues = [i for i in issues if i.kind == "outlier_spike"]
        assert spike_issues
        assert "Meta" in spike_issues[0].description

    def test_no_spend_col_returns_empty(self):
        df = pd.DataFrame({"date": ["2025-01-06"], "channel": ["Meta"], "revenue": [500]})
        assert detect_outlier_spikes(df) == []


# ---------------------------------------------------------------------------
# Rule 4: Duplicate rows
# ---------------------------------------------------------------------------


class TestDetectDuplicateRows:
    def test_detects_exact_duplicate(self):
        df = _weekly_df(n_weeks=4)
        row = df.iloc[0:1]
        df = pd.concat([df, row], ignore_index=True)
        issues = detect_duplicate_rows(df)
        assert any(i.kind == "duplicate_rows" for i in issues)

    def test_detects_conflicting_date_channel(self):
        df = _weekly_df(n_weeks=4)
        conflict = df.iloc[0:1].copy()
        conflict.loc[conflict.index[0], "spend"] = 99999  # different spend
        df = pd.concat([df, conflict], ignore_index=True)
        issues = detect_duplicate_rows(df)
        # Either exact or conflicting duplicate should be detected
        kinds = {i.kind for i in issues}
        assert kinds & {"duplicate_rows", "duplicate_date_channel"}

    def test_auto_applies_true(self):
        df = _weekly_df(n_weeks=4)
        row = df.iloc[0:1]
        df = pd.concat([df, row], ignore_index=True)
        issues = detect_duplicate_rows(df)
        for i in issues:
            assert i.auto_applies is True

    def test_no_dupes_no_issues(self):
        df = _weekly_df(n_weeks=8)
        assert detect_duplicate_rows(df) == []

    def test_affected_rows_count_is_positive(self):
        df = _weekly_df(n_weeks=4)
        row = df.iloc[0:1]
        df = pd.concat([df, row], ignore_index=True)
        issues = detect_duplicate_rows(df)
        for i in issues:
            assert i.affected_rows > 0


# ---------------------------------------------------------------------------
# Rule 5: Aggregation mismatch
# ---------------------------------------------------------------------------


class TestDetectAggregationMismatch:
    def test_detects_daily_data(self):
        dates = pd.date_range("2025-01-01", periods=60, freq="D").strftime("%Y-%m-%d").tolist()
        df = pd.DataFrame(
            {
                "date": dates,
                "channel": ["Meta"] * len(dates),
                "spend": [200.0] * len(dates),
                "revenue": [1000.0] * len(dates),
            }
        )
        issues = detect_aggregation_mismatch(df)
        assert any(i.kind == "aggregation_mismatch" for i in issues)

    def test_weekly_data_no_issue(self):
        df = _weekly_df(n_weeks=26)
        issues = detect_aggregation_mismatch(df)
        assert not any(i.kind == "aggregation_mismatch" for i in issues)

    def test_auto_applies_true(self):
        dates = pd.date_range("2025-01-01", periods=30, freq="D").strftime("%Y-%m-%d").tolist()
        df = pd.DataFrame(
            {
                "date": dates,
                "channel": ["Meta"] * len(dates),
                "spend": [200.0] * len(dates),
                "revenue": [1000.0] * len(dates),
            }
        )
        issues = detect_aggregation_mismatch(df)
        for i in issues:
            if i.kind == "aggregation_mismatch":
                assert i.auto_applies is True

    def test_no_date_col_returns_empty(self):
        df = pd.DataFrame({"channel": ["Meta"] * 10, "spend": [100] * 10, "revenue": [500] * 10})
        assert detect_aggregation_mismatch(df) == []

    def test_severity_is_medium(self):
        dates = pd.date_range("2025-01-01", periods=30, freq="D").strftime("%Y-%m-%d").tolist()
        df = pd.DataFrame(
            {
                "date": dates,
                "channel": ["Meta"] * len(dates),
                "spend": [200.0] * len(dates),
                "revenue": [1000.0] * len(dates),
            }
        )
        issues = detect_aggregation_mismatch(df)
        for i in issues:
            if i.kind == "aggregation_mismatch":
                assert i.severity == "medium"


# ---------------------------------------------------------------------------
# Rule 6: Currency markers
# ---------------------------------------------------------------------------


class TestDetectCurrencyMarkers:
    def test_detects_dollar_sign(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["$5,200"],
                "revenue": ["$32,000"],
            }
        )
        issues = detect_currency_markers(df)
        assert any(i.kind == "currency_markers" for i in issues)

    def test_detects_commas(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["5,200"],
                "revenue": ["32,000"],
            }
        )
        issues = detect_currency_markers(df)
        assert any(i.kind == "currency_markers" for i in issues)

    def test_detects_usd_suffix(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["5200 USD"],
                "revenue": ["32000"],
            }
        )
        issues = detect_currency_markers(df)
        assert any(i.kind == "currency_markers" for i in issues)

    def test_auto_applies_true(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["$5,200"],
                "revenue": ["$32,000"],
            }
        )
        issues = detect_currency_markers(df)
        for i in issues:
            if i.kind == "currency_markers":
                assert i.auto_applies is True

    def test_numeric_column_no_issue(self):
        df = _weekly_df(n_weeks=4)
        issues = detect_currency_markers(df)
        assert not any(i.kind == "currency_markers" for i in issues)

    def test_affected_values_contains_column_name(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": ["$5,200"],
                "revenue": [32000],
            }
        )
        issues = detect_currency_markers(df)
        cn_issues = [i for i in issues if i.kind == "currency_markers"]
        assert cn_issues
        assert "spend" in cn_issues[0].affected_values


# ---------------------------------------------------------------------------
# Rule 7: Whitespace
# ---------------------------------------------------------------------------


class TestDetectWhitespace:
    def test_detects_header_whitespace(self):
        df = pd.DataFrame(
            {
                " date ": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": [5200],
                "revenue": [32000],
            }
        )
        issues = detect_whitespace(df)
        assert any(i.kind == "whitespace_headers" for i in issues)

    def test_detects_value_whitespace(self):
        df = pd.DataFrame(
            {
                "date": ["2025-01-06"],
                "channel": ["  Meta  "],
                "spend": [5200],
                "revenue": [32000],
            }
        )
        issues = detect_whitespace(df)
        assert any(i.kind == "whitespace_values" for i in issues)

    def test_auto_applies_true(self):
        df = pd.DataFrame(
            {
                "date ": ["2025-01-06"],
                "channel": ["Meta"],
                "spend": [5200],
                "revenue": [32000],
            }
        )
        issues = detect_whitespace(df)
        for i in issues:
            assert i.auto_applies is True

    def test_clean_data_no_issue(self):
        df = _weekly_df(n_weeks=4)
        issues = detect_whitespace(df)
        assert not any(i.kind in ("whitespace_headers", "whitespace_values") for i in issues)


# ---------------------------------------------------------------------------
# Rule 8: Empty columns/rows
# ---------------------------------------------------------------------------


class TestDetectEmptyColumnsRows:
    def test_detects_all_null_column(self):
        df = _weekly_df(n_weeks=4)
        df["empty_col"] = None
        issues = detect_empty_columns_rows(df)
        assert any(i.kind == "empty_columns" for i in issues)

    def test_detects_all_null_row(self):
        df = _weekly_df(n_weeks=4)
        empty_row = pd.DataFrame([[None, None, None, None]], columns=df.columns)
        df = pd.concat([df, empty_row], ignore_index=True)
        issues = detect_empty_columns_rows(df)
        assert any(i.kind == "empty_rows" for i in issues)

    def test_auto_applies_true(self):
        df = _weekly_df(n_weeks=4)
        df["empty_col"] = None
        issues = detect_empty_columns_rows(df)
        for i in issues:
            assert i.auto_applies is True

    def test_clean_data_no_issue(self):
        df = _weekly_df(n_weeks=4)
        assert detect_empty_columns_rows(df) == []


# ---------------------------------------------------------------------------
# Rule 9: Date format inconsistency
# ---------------------------------------------------------------------------


class TestDetectDateFormatInconsistency:
    def test_detects_us_format(self):
        df = pd.DataFrame(
            {
                "date": ["01/06/2025", "01/13/2025", "01/20/2025"],
                "channel": ["Meta"] * 3,
                "spend": [5200, 5100, 4900],
                "revenue": [32000, 31500, 30800],
            }
        )
        issues = detect_date_format_inconsistency(df)
        assert any(i.kind == "date_format_inconsistency" for i in issues)

    def test_iso_format_no_issue(self):
        df = _weekly_df(n_weeks=4)
        issues = detect_date_format_inconsistency(df)
        assert not any(i.kind == "date_format_inconsistency" for i in issues)

    def test_ambiguous_date_detected(self):
        df = pd.DataFrame(
            {
                "date": ["01/02/2025", "02/03/2025", "03/04/2025"],
                "channel": ["Meta"] * 3,
                "spend": [5200, 5100, 4900],
                "revenue": [32000, 31500, 30800],
            }
        )
        issues = detect_date_format_inconsistency(df)
        assert any(i.kind == "ambiguous_date_format" for i in issues)

    def test_ambiguous_date_not_auto_applies(self):
        df = pd.DataFrame(
            {
                "date": ["01/02/2025", "02/03/2025"],
                "channel": ["Meta"] * 2,
                "spend": [5200, 5100],
                "revenue": [32000, 31500],
            }
        )
        issues = detect_date_format_inconsistency(df)
        for i in issues:
            if i.kind == "ambiguous_date_format":
                assert i.auto_applies is False

    def test_non_ambiguous_non_iso_auto_applies(self):
        # Month > 12 means unambiguous
        df = pd.DataFrame(
            {
                "date": ["13/06/2025", "20/06/2025"],
                "channel": ["Meta"] * 2,
                "spend": [5200, 5100],
                "revenue": [32000, 31500],
            }
        )
        issues = detect_date_format_inconsistency(df)
        for i in issues:
            if i.kind == "date_format_inconsistency":
                assert i.auto_applies is True

    def test_no_date_col_returns_empty(self):
        df = pd.DataFrame({"channel": ["Meta"], "spend": [100], "revenue": [500]})
        assert detect_date_format_inconsistency(df) == []


# ---------------------------------------------------------------------------
# Rule 10: Zero spend all-channel rows
# ---------------------------------------------------------------------------


class TestDetectAllZeroSpendRows:
    def test_detects_zero_spend_rows(self):
        df = _weekly_df(n_weeks=8)
        df.loc[3, "spend"] = 0.0
        issues = detect_all_zero_spend_rows(df)
        assert any(i.kind == "zero_spend_rows" for i in issues)

    def test_severity_is_info(self):
        df = _weekly_df(n_weeks=8)
        df.loc[3, "spend"] = 0.0
        issues = detect_all_zero_spend_rows(df)
        for i in issues:
            if i.kind == "zero_spend_rows":
                assert i.severity == "info"

    def test_auto_applies_false(self):
        df = _weekly_df(n_weeks=8)
        df.loc[3, "spend"] = 0.0
        issues = detect_all_zero_spend_rows(df)
        for i in issues:
            if i.kind == "zero_spend_rows":
                assert i.auto_applies is False

    def test_no_zero_rows_no_issue(self):
        df = _weekly_df(n_weeks=8)
        assert not any(i.kind == "zero_spend_rows" for i in detect_all_zero_spend_rows(df))

    def test_affected_row_count_is_accurate(self):
        df = _weekly_df(n_weeks=10)
        df.loc[2, "spend"] = 0.0
        df.loc[7, "spend"] = 0.0
        issues = detect_all_zero_spend_rows(df)
        zero_issues = [i for i in issues if i.kind == "zero_spend_rows"]
        assert zero_issues
        assert zero_issues[0].affected_rows == 2


# ---------------------------------------------------------------------------
# Issue dataclass
# ---------------------------------------------------------------------------


class TestIssueDataclass:
    def test_to_dict_has_required_keys(self):
        issue = Issue(
            kind="test_kind",
            severity="high",
            description="test",
            affected_rows=5,
        )
        d = issue.to_dict()
        required = {
            "kind",
            "severity",
            "description",
            "affected_rows",
            "affected_values",
            "proposed_fix",
            "auto_applies",
        }
        assert required == set(d.keys())

    def test_default_auto_applies_false(self):
        issue = Issue(kind="test", severity="low", description="d", affected_rows=0)
        assert issue.auto_applies is False

    def test_default_affected_values_empty_list(self):
        issue = Issue(kind="test", severity="low", description="d", affected_rows=0)
        assert issue.affected_values == []


# ---------------------------------------------------------------------------
# run_all_detectors orchestrator
# ---------------------------------------------------------------------------


class TestRunAllDetectors:
    def test_returns_list(self):
        df = _weekly_df(n_weeks=4)
        issues = run_all_detectors(df)
        assert isinstance(issues, list)

    def test_detects_multiple_issues_in_messy_data(self):
        df = _weekly_df(n_weeks=8)
        # Inject multiple issues
        df.loc[0, "channel"] = "FB"  # alias
        row = df.iloc[1:2].copy()  # take a row with unmodified channel
        df = pd.concat([df, row], ignore_index=True)  # exact dupe
        df.loc[len(df) - 1, "spend"] = 99000  # spike
        issues = run_all_detectors(df)
        kinds = {i.kind for i in issues}
        assert "channel_name_inconsistency" in kinds
        # Either exact duplicate or (date,channel) conflict is detected
        assert kinds & {"duplicate_rows", "duplicate_date_channel"}

    def test_passes_user_map_to_channel_detector(self):
        df = _weekly_df(channels=["MyBrand", "Google"])
        issues = run_all_detectors(df, user_map={"myb": "MyBrand"})
        # "MyBrand" should not trigger channel inconsistency since user_map doesn't alias it
        assert not any(
            i.kind == "channel_name_inconsistency" and "MyBrand" in i.affected_values
            for i in issues
        )
