"""Unit tests for mixlift_mcp.renderers.decompose_memo.

All tests feed pre-computed synthetic dicts to the renderer.
No PyMC-Marketing model is ever fitted.
"""

from __future__ import annotations

import os
import pathlib
import re

import pytest

from mixlift_mcp.renderers.decompose_memo import (
    _PERIOD_WEEKS,
    VALID_PERIODS,
    build_decompose_result,
    render_decompose_memo,
)

# ---------------------------------------------------------------------------
# Helpers: build synthetic decompose result dicts
# ---------------------------------------------------------------------------

_DEFAULT_MCMC_CONFIG = {"chains": 4, "draws": 250, "target_accept": 0.90}
_DEFAULT_DATA_WINDOW = "2025-12-15 to 2026-04-14 (17 weeks)"


def _make_decompose_result(
    channels: list[str] | None = None,
    contributions: dict[str, float] | None = None,
    cis: dict[str, tuple[float, float]] | None = None,
    spends: dict[str, float] | None = None,
    total_revenue: float = 1_920_000.0,
    period: str = "last_4_weeks",
    period_weeks: int = 4,
    period_label: str = "Last 4 weeks (2026-03-17 to 2026-04-14)",
    skipped: list[str] | None = None,
) -> dict:
    """Build a decompose result dict for render_decompose_memo."""
    if channels is None:
        channels = ["meta_spend", "google_search_spend", "tiktok_spend"]

    if contributions is None:
        contributions = {
            "Meta": 320_000.0,
            "Google Search": 180_000.0,
            "TikTok": 180_000.0,
        }

    if cis is None:
        cis = {
            "Meta": (288_000.0, 352_000.0),
            "Google Search": (162_000.0, 198_000.0),
            "TikTok": (162_000.0, 198_000.0),
        }

    if spends is None:
        spends = {
            "Meta": 72_280.0,
            "Google Search": 45_000.0,
            "TikTok": 30_000.0,
        }

    return build_decompose_result(
        period=period,
        period_weeks=period_weeks,
        period_label=period_label,
        data_window=_DEFAULT_DATA_WINDOW,
        total_revenue=total_revenue,
        means_dict=contributions,
        cis_dict=cis,
        spend_dict=spends,
        channel_columns=channels,
        mcmc_config=_DEFAULT_MCMC_CONFIG,
        skipped_channels=skipped or [],
    )


def _make_3ch_result(**kwargs) -> dict:
    return _make_decompose_result(**kwargs)


# ---------------------------------------------------------------------------
# Period mapping
# ---------------------------------------------------------------------------


class TestPeriodMapping:
    def test_valid_periods_set(self):
        assert set(VALID_PERIODS) == {"last_week", "last_4_weeks", "last_quarter", "full_period"}

    def test_last_week_is_1(self):
        assert _PERIOD_WEEKS["last_week"] == 1

    def test_last_4_weeks_is_4(self):
        assert _PERIOD_WEEKS["last_4_weeks"] == 4

    def test_last_quarter_is_13(self):
        assert _PERIOD_WEEKS["last_quarter"] == 13

    def test_full_period_is_none(self):
        assert _PERIOD_WEEKS["full_period"] is None


# ---------------------------------------------------------------------------
# build_decompose_result — structured output shape
# ---------------------------------------------------------------------------


class TestBuildDecomposeResult:
    def test_top_level_keys_match_spec(self):
        result = _make_3ch_result()
        required_keys = {
            "tool",
            "version",
            "mcmc_config",
            "data_window",
            "period_label",
            "period_weeks",
            "total_revenue",
            "baseline",
            "paid_total",
            "channels",
            "_skipped_channels",
        }
        assert required_keys.issubset(set(result.keys()))

    def test_tool_name_correct(self):
        result = _make_3ch_result()
        assert result["tool"] == "mixlift_decompose"

    def test_version_correct(self):
        result = _make_3ch_result()
        assert result["version"] == "0.5.3"

    def test_period_weeks_correct(self):
        result = _make_3ch_result(period_weeks=4)
        assert result["period_weeks"] == 4

    def test_total_revenue_preserved(self):
        result = _make_3ch_result(total_revenue=1_920_000.0)
        assert result["total_revenue"] == pytest.approx(1_920_000.0, abs=1)

    def test_channels_sorted_by_contribution_descending(self):
        result = _make_3ch_result(
            contributions={
                "Meta": 100_000.0,
                "Google Search": 200_000.0,
                "TikTok": 50_000.0,
            }
        )
        contribs = [ch["contribution"] for ch in result["channels"]]
        assert contribs == sorted(contribs, reverse=True)

    def test_channel_keys_match_spec(self):
        result = _make_3ch_result()
        required_ch_keys = {
            "name",
            "contribution",
            "pct_of_total",
            "pct_of_paid",
            "ci",
            "spend",
            "roas",
        }
        for ch in result["channels"]:
            missing = required_ch_keys - set(ch.keys())
            assert missing == set(), f"Missing keys: {missing}"

    def test_baseline_keys(self):
        result = _make_3ch_result()
        assert set(result["baseline"].keys()) == {"revenue", "pct_of_total", "ci"}

    def test_paid_total_keys(self):
        result = _make_3ch_result()
        assert set(result["paid_total"].keys()) == {"revenue", "pct_of_total", "ci"}

    def test_baseline_plus_paid_equals_total(self):
        result = _make_3ch_result(total_revenue=1_000_000.0)
        baseline_pct = result["baseline"]["pct_of_total"]
        paid_pct = result["paid_total"]["pct_of_total"]
        assert abs(baseline_pct + paid_pct - 100.0) < 1.0

    def test_pct_of_paid_sums_to_100(self):
        result = _make_3ch_result()
        total_pct = sum(ch["pct_of_paid"] for ch in result["channels"])
        assert abs(total_pct - 100.0) < 1.0

    def test_roas_computed_from_contribution_over_spend(self):
        result = _make_3ch_result(
            channels=["meta_spend"],
            contributions={"Meta": 400_000.0},
            cis={"Meta": (360_000.0, 440_000.0)},
            spends={"Meta": 100_000.0},
        )
        ch = result["channels"][0]
        assert abs(ch["roas"] - 4.0) < 0.01

    def test_roas_none_when_zero_spend(self):
        result = _make_3ch_result(
            channels=["meta_spend"],
            contributions={"Meta": 100_000.0},
            cis={"Meta": (80_000.0, 120_000.0)},
            spends={"Meta": 0.0},
        )
        ch = result["channels"][0]
        assert ch["roas"] is None

    def test_ci_is_list_of_two(self):
        result = _make_3ch_result()
        for ch in result["channels"]:
            assert isinstance(ch["ci"], list)
            assert len(ch["ci"]) == 2


# ---------------------------------------------------------------------------
# Edge case 2: zero contribution channel
# ---------------------------------------------------------------------------


class TestZeroContributionChannel:
    def test_zero_contribution_included(self):
        result = _make_3ch_result(
            contributions={
                "Meta": 320_000.0,
                "Google Search": 0.0,
                "TikTok": 180_000.0,
            }
        )
        names = [ch["name"] for ch in result["channels"]]
        assert "Google Search" in names

    def test_zero_contribution_shows_zero_in_memo(self):
        result = _make_3ch_result(
            contributions={
                "Meta": 320_000.0,
                "Google Search": 0.0,
                "TikTok": 180_000.0,
            }
        )
        memo = render_decompose_memo(result)
        assert "Google Search" in memo

    def test_zero_contribution_no_floored_flag(self):
        result = _make_3ch_result(
            contributions={
                "Meta": 320_000.0,
                "Google Search": 0.0,
                "TikTok": 180_000.0,
            }
        )
        for ch in result["channels"]:
            if ch["name"] == "Google Search":
                assert not ch.get("floored", False)


# ---------------------------------------------------------------------------
# Edge case 3: negative contribution — floor at $0 in memo, keep true value
# ---------------------------------------------------------------------------


class TestNegativeContributionChannel:
    def test_negative_contribution_floored_in_structured_output(self):
        result = _make_3ch_result(
            channels=["meta_spend", "tiktok_spend"],
            contributions={"Meta": 320_000.0, "TikTok": -5_000.0},
            cis={"Meta": (288_000.0, 352_000.0), "TikTok": (-10_000.0, 0.0)},
            spends={"Meta": 72_000.0, "TikTok": 30_000.0},
        )
        tiktok = next(ch for ch in result["channels"] if ch["name"] == "TikTok")
        assert tiktok["contribution"] == 0.0
        assert tiktok.get("floored") is True
        assert tiktok["true_contribution"] == pytest.approx(-5_000.0, abs=1)

    def test_negative_contribution_memo_shows_zero(self):
        result = _make_3ch_result(
            channels=["meta_spend", "tiktok_spend"],
            contributions={"Meta": 320_000.0, "TikTok": -5_000.0},
            cis={"Meta": (288_000.0, 352_000.0), "TikTok": (-10_000.0, 0.0)},
            spends={"Meta": 72_000.0, "TikTok": 30_000.0},
        )
        memo = render_decompose_memo(result)
        # Floored footnote must appear
        assert "floored" in memo.lower() or "negative" in memo.lower()

    def test_negative_contribution_floored_flag_in_channel_table(self):
        result = _make_3ch_result(
            channels=["meta_spend", "tiktok_spend"],
            contributions={"Meta": 320_000.0, "TikTok": -5_000.0},
            cis={"Meta": (288_000.0, 352_000.0), "TikTok": (-10_000.0, 0.0)},
            spends={"Meta": 72_000.0, "TikTok": 30_000.0},
        )
        memo = render_decompose_memo(result)
        # The dagger footnote symbol should appear for floored channels
        assert "\u2020" in memo


# ---------------------------------------------------------------------------
# Edge case 4: single channel
# ---------------------------------------------------------------------------


class TestSingleChannelDecompose:
    def test_single_channel_renders(self):
        result = _make_3ch_result(
            channels=["meta_spend"],
            contributions={"Meta": 320_000.0},
            cis={"Meta": (288_000.0, 352_000.0)},
            spends={"Meta": 72_280.0},
        )
        memo = render_decompose_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 100

    def test_single_channel_table_has_3_rows(self):
        result = _make_3ch_result(
            channels=["meta_spend"],
            contributions={"Meta": 320_000.0},
            cis={"Meta": (288_000.0, 352_000.0)},
            spends={"Meta": 72_280.0},
        )
        memo = render_decompose_memo(result)
        # Table must include: Baseline, Paid total, one channel row
        assert "Baseline" in memo
        assert "Paid total" in memo
        assert "Meta" in memo

    def test_single_channel_pct_of_paid_is_100(self):
        result = _make_3ch_result(
            channels=["meta_spend"],
            contributions={"Meta": 320_000.0},
            cis={"Meta": (288_000.0, 352_000.0)},
            spends={"Meta": 72_280.0},
        )
        ch = result["channels"][0]
        assert abs(ch["pct_of_paid"] - 100.0) < 0.1


# ---------------------------------------------------------------------------
# Edge case 5: channels filter with non-existent channel
# ---------------------------------------------------------------------------


class TestSkippedChannels:
    def test_skipped_channel_not_error(self):
        result = _make_3ch_result(skipped=["podcast_spend"])
        memo = render_decompose_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 100

    def test_skipped_channel_footnote_in_memo(self):
        result = _make_3ch_result(skipped=["podcast_spend"])
        memo = render_decompose_memo(result)
        assert "podcast_spend" in memo or "not found" in memo.lower()

    def test_multiple_skipped_channels_in_footnote(self):
        result = _make_3ch_result(skipped=["podcast_spend", "tv_spend"])
        memo = render_decompose_memo(result)
        assert "podcast_spend" in memo
        assert "tv_spend" in memo


# ---------------------------------------------------------------------------
# Edge case 7: invalid period string
# ---------------------------------------------------------------------------


class TestInvalidPeriod:
    def test_invalid_period_not_in_valid_set(self):
        assert "last_month" not in VALID_PERIODS
        assert "ytd" not in VALID_PERIODS

    def test_valid_periods_all_present(self):
        for p in ("last_week", "last_4_weeks", "last_quarter", "full_period"):
            assert p in VALID_PERIODS


# ---------------------------------------------------------------------------
# render_decompose_memo — structure
# ---------------------------------------------------------------------------


class TestRenderDecomposeMemoStructure:
    def test_returns_non_empty_string(self):
        result = _make_3ch_result()
        memo = render_decompose_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 100

    def test_decomposition_table_present(self):
        result = _make_3ch_result()
        memo = render_decompose_memo(result)
        assert "Revenue decomposition" in memo

    def test_channel_table_present(self):
        result = _make_3ch_result()
        memo = render_decompose_memo(result)
        assert "By channel" in memo

    def test_baseline_row_present(self):
        result = _make_3ch_result()
        memo = render_decompose_memo(result)
        assert "Baseline" in memo

    def test_paid_total_row_present(self):
        result = _make_3ch_result()
        memo = render_decompose_memo(result)
        assert "Paid total" in memo

    def test_footer_present(self):
        result = _make_3ch_result()
        memo = render_decompose_memo(result)
        assert "Posterior" in memo or "Data window" in memo

    def test_no_emojis(self):
        result = _make_3ch_result()
        memo = render_decompose_memo(result)
        emoji_pattern = re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(memo), "Emoji found in memo"

    def test_returns_empty_string_on_empty_result(self):
        memo = render_decompose_memo({})
        assert memo == ""

    def test_never_raises_on_malformed_input(self):
        memo = render_decompose_memo({"channels": None})
        assert isinstance(memo, str)

    def test_diagnosis_paragraph_present(self):
        result = _make_3ch_result(total_revenue=1_920_000.0)
        memo = render_decompose_memo(result)
        # Opening paragraph must mention total revenue and paid/baseline split
        assert (
            "$1,920,000" in memo
            or "1,920,000" in memo
            or "1920000" in memo
            or "baseline" in memo.lower()
        )

    def test_top_channel_mentioned_in_diagnosis(self):
        result = _make_3ch_result(
            contributions={
                "Meta": 320_000.0,
                "Google Search": 180_000.0,
                "TikTok": 180_000.0,
            }
        )
        memo = render_decompose_memo(result)
        assert "Meta" in memo


# ---------------------------------------------------------------------------
# Memo length constraint (<= 2500 tokens)
# ---------------------------------------------------------------------------


class TestMemoTokenLength:
    def test_8_channel_memo_under_2500_tokens(self):
        """Mock-driven 8-channel scenario must stay under 2500 tokens."""
        channels = [
            "meta_spend",
            "google_search_spend",
            "tiktok_spend",
            "email_spend",
            "youtube_spend",
            "bing_spend",
            "pinterest_spend",
            "snapchat_spend",
        ]
        contributions = {
            "Meta": 320_000.0,
            "Google Search": 180_000.0,
            "TikTok": 120_000.0,
            "Email": 60_000.0,
            "Youtube": 80_000.0,
            "Bing": 40_000.0,
            "Pinterest": 30_000.0,
            "Snapchat": 20_000.0,
        }
        cis = {name: (v * 0.9, v * 1.1) for name, v in contributions.items()}
        spends = {
            "Meta": 72_000.0,
            "Google Search": 45_000.0,
            "TikTok": 30_000.0,
            "Email": 10_000.0,
            "Youtube": 20_000.0,
            "Bing": 8_000.0,
            "Pinterest": 6_000.0,
            "Snapchat": 4_000.0,
        }
        result = build_decompose_result(
            period="last_4_weeks",
            period_weeks=4,
            period_label="Last 4 weeks (2026-03-17 to 2026-04-14)",
            data_window=_DEFAULT_DATA_WINDOW,
            total_revenue=2_400_000.0,
            means_dict=contributions,
            cis_dict=cis,
            spend_dict=spends,
            channel_columns=channels,
            mcmc_config=_DEFAULT_MCMC_CONFIG,
            skipped_channels=[],
        )
        memo = render_decompose_memo(result)
        estimated_tokens = len(memo) / 4
        assert estimated_tokens <= 2500, (
            f"Memo is too long: ~{estimated_tokens:.0f} estimated tokens "
            f"(limit 2500). Actual chars: {len(memo)}"
        )


# ---------------------------------------------------------------------------
# Snapshot test
# ---------------------------------------------------------------------------


def _make_snapshot_result() -> dict:
    """Canonical 3-channel mock result for snapshot testing (mirrors demo_e2e scenario)."""
    channels = ["meta_spend", "google_search_spend", "tiktok_spend"]
    contributions = {
        "Meta": 320_000.0,
        "Google Search": 180_000.0,
        "TikTok": 120_000.0,
    }
    cis = {
        "Meta": (288_000.0, 352_000.0),
        "Google Search": (162_000.0, 198_000.0),
        "TikTok": (108_000.0, 132_000.0),
    }
    spends = {
        "Meta": 72_280.0,
        "Google Search": 45_000.0,
        "TikTok": 30_000.0,
    }
    return build_decompose_result(
        period="last_4_weeks",
        period_weeks=4,
        period_label="Last 4 weeks (2026-03-17 to 2026-04-14)",
        data_window="2025-04-14 to 2026-04-07 (51 weeks)",
        total_revenue=1_920_000.0,
        means_dict=contributions,
        cis_dict=cis,
        spend_dict=spends,
        channel_columns=channels,
        mcmc_config={"chains": 4, "draws": 250, "target_accept": 0.90},
        skipped_channels=[],
    )


_SNAPSHOT_PATH = pathlib.Path(__file__).parent.parent / "snapshots" / "decompose_memo__demo_e2e.md"


class TestSnapshot:
    def test_snapshot_matches_committed(self):
        """Rendered memo must exactly match the committed snapshot.

        To regenerate after intentional changes:
            UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_decompose_memo.py
        """
        result = _make_snapshot_result()
        rendered_memo = render_decompose_memo(result)

        if os.environ.get("UPDATE_SNAPSHOTS") == "1":
            _SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _SNAPSHOT_PATH.write_text(rendered_memo)
            return  # regenerated — no assertion needed

        snapshot_text = _SNAPSHOT_PATH.read_text()
        assert rendered_memo == snapshot_text, (
            "Snapshot mismatch. To update: "
            "UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_decompose_memo.py"
        )

    def test_all_3_channels_renderable(self):
        """All channels in snapshot scenario must appear in memo."""
        result = _make_snapshot_result()
        memo = render_decompose_memo(result)
        for name in ["Meta", "Google Search", "TikTok"]:
            assert name in memo, f"Channel '{name}' not found in memo"

    def test_decomposition_table_sorted_contribution_descending(self):
        """Channels in the decomposition table must be sorted highest contribution first."""
        result = _make_snapshot_result()
        memo = render_decompose_memo(result)
        # Find the decomposition table section
        table_start = memo.find("### Revenue decomposition")
        assert table_start != -1
        table_section = memo[table_start:]
        # Extract dollar amounts from table rows (skip header and baseline/paid rows)
        amounts: list[float] = []
        for line in table_section.splitlines():
            if "├" in line or "└" in line:
                # Extract dollar amounts like "$320,000"
                matches = re.findall(r"\$([0-9,]+)", line)
                if matches:
                    val = float(matches[0].replace(",", ""))
                    amounts.append(val)
        assert len(amounts) >= 2
        for i in range(len(amounts) - 1):
            assert amounts[i] >= amounts[i + 1], f"Not sorted descending: {amounts}"
