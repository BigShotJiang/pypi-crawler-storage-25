"""Unit tests for mixlift_mcp.renderers.scenarios_memo.

All tests feed pre-computed synthetic dicts to the renderer.
No PyMC-Marketing model is ever fitted.
"""

from __future__ import annotations

import os
import pathlib

from mixlift_mcp.renderers.scenarios_memo import (
    _all_identical,
    _fmt_compact,
    _fmt_delta_compact,
    render_scenarios_memo,
)

# ---------------------------------------------------------------------------
# Helpers: build synthetic scenario result dicts
# ---------------------------------------------------------------------------

_DEFAULT_MCMC_CONFIG = {"chains": 4, "draws": 250, "target_accept": 0.90}
_DEFAULT_DATA_WINDOW = "2025-04-14 to 2026-04-07 (51 weeks)"

_SQ_REVENUE = 480_000.0
_SQ_CI = [440_000.0, 520_000.0]


def _make_scenario(
    name: str,
    deltas: dict,
    proj_rev: float,
    ci_low: float,
    ci_high: float,
    delta: float,
    rank: int,
    extrapolated: bool = False,
    clipped: bool = False,
    mode: str | None = None,
) -> dict:
    sc: dict = {
        "name": name,
        "deltas": deltas,
        "projected_revenue": proj_rev,
        "projected_ci": [ci_low, ci_high],
        "delta_vs_status_quo": delta,
        "delta_pct": round((delta / _SQ_REVENUE) * 100.0, 2) if _SQ_REVENUE > 0 else 0.0,
        "extrapolated": extrapolated,
        "clipped": clipped,
        "rank": rank,
    }
    if mode is not None:
        sc["mode"] = mode
    return sc


def _make_result(
    scenarios: list[dict] | None = None,
    status_quo_revenue: float = _SQ_REVENUE,
    status_quo_ci: list | None = None,
) -> dict:
    if scenarios is None:
        scenarios = _default_5_scenarios()
    if status_quo_ci is None:
        status_quo_ci = _SQ_CI

    return {
        "tool": "mixlift_scenarios",
        "version": "0.5.3",
        "mcmc_config": _DEFAULT_MCMC_CONFIG,
        "data_window": _DEFAULT_DATA_WINDOW,
        "status_quo_revenue": status_quo_revenue,
        "status_quo_ci": status_quo_ci,
        "scenarios": scenarios,
    }


def _default_5_scenarios() -> list[dict]:
    """5 canned scenarios, pre-ranked."""
    return [
        _make_scenario(
            "+20% budget to Email and Influencer",
            {"Email": 0.2, "Influencer": 0.2},
            498_000.0,
            455_000.0,
            541_000.0,
            18_000.0,
            rank=1,
        ),
        _make_scenario(
            "Status quo",
            {},
            480_000.0,
            440_000.0,
            520_000.0,
            0.0,
            rank=2,
        ),
        _make_scenario(
            "Shift 20% from Meta to Email",
            {"Meta": -0.2, "Email": 0.2},
            486_000.0,
            442_000.0,
            530_000.0,
            6_000.0,
            rank=3,
        ),
        _make_scenario(
            "Cut Meta 50%",
            {"Meta": -0.5},
            476_000.0,
            432_000.0,
            520_000.0,
            -4_000.0,
            rank=4,
        ),
        _make_scenario(
            "\u221220% total budget",
            {"Meta": -0.2, "Email": -0.2, "Influencer": -0.2},
            412_000.0,
            372_000.0,
            452_000.0,
            -68_000.0,
            rank=5,
        ),
    ]


# ---------------------------------------------------------------------------
# Helper function unit tests
# ---------------------------------------------------------------------------


class TestFmtCompact:
    def test_thousands(self):
        assert _fmt_compact(498_000) == "$498k"

    def test_millions(self):
        assert _fmt_compact(1_500_000) == "$1.5M"

    def test_small(self):
        assert _fmt_compact(500) == "$500"

    def test_negative(self):
        # Negative values: fmt_compact wraps sign separately
        result = _fmt_compact(-4_000)
        assert "4k" in result


class TestFmtDeltaCompact:
    def test_positive_thousands(self):
        assert _fmt_delta_compact(18_000) == "+$18k"

    def test_negative_thousands(self):
        result = _fmt_delta_compact(-4_000)
        assert "$4k" in result

    def test_zero_returns_emdash(self):
        assert _fmt_delta_compact(0) == "\u2014"

    def test_millions(self):
        assert _fmt_delta_compact(2_000_000) == "+$2.0M"


class TestAllIdentical:
    def test_all_zero_delta(self):
        scenarios = [{"delta_vs_status_quo": 0}, {"delta_vs_status_quo": 0.0}]
        assert _all_identical(scenarios) is True

    def test_nonzero_delta(self):
        scenarios = [{"delta_vs_status_quo": 0}, {"delta_vs_status_quo": 18_000}]
        assert _all_identical(scenarios) is False

    def test_sub_one_threshold(self):
        # Within floating-point rounding tolerance
        scenarios = [{"delta_vs_status_quo": 0.5}, {"delta_vs_status_quo": -0.3}]
        assert _all_identical(scenarios) is True


# ---------------------------------------------------------------------------
# Happy path: render_scenarios_memo
# ---------------------------------------------------------------------------


class TestRenderScenariosMemoHappyPath:
    def test_returns_string(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        assert isinstance(memo, str)

    def test_non_empty(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        assert len(memo) > 200

    def test_memo_under_2500_tokens(self):
        """Memo must not exceed ~2500 tokens (approx 4 chars/token)."""
        result = _make_result()
        memo = render_scenarios_memo(result)
        # 2500 tokens * ~4 chars/token = 10000 chars; use generous margin
        assert len(memo) <= 12_000, f"Memo too long: {len(memo)} chars"

    def test_winner_heading_present(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        # Opening section should name the winner or best move
        assert "Best move" in memo or "Best available" in memo

    def test_winner_name_in_memo(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        assert "+20% budget to Email and Influencer" in memo

    def test_ranked_table_headers_present(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        assert "Rank" in memo
        assert "Scenario" in memo
        assert "Projected" in memo

    def test_all_5_scenarios_appear(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        for sc in _default_5_scenarios():
            # Name may be truncated at 36 chars; check prefix
            assert sc["name"][:20] in memo, f"Missing scenario: {sc['name']}"

    def test_scenario_details_section_present(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        assert "Scenario details" in memo

    def test_footer_contains_data_window(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        assert "2025-04-14" in memo or "Data window" in memo

    def test_footer_contains_mcmc_info(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        assert "chains" in memo or "draws" in memo

    def test_delta_dollars_in_memo(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        # +$18k winner delta should appear
        assert "$18k" in memo or "18,000" in memo


# ---------------------------------------------------------------------------
# Edge case 1: empty scenarios list → no crash, empty string
# ---------------------------------------------------------------------------


class TestEmptyScenarios:
    def test_empty_list_returns_empty_string(self):
        result = _make_result(scenarios=[])
        memo = render_scenarios_memo(result)
        assert memo == ""

    def test_missing_scenarios_key_returns_empty_string(self):
        result = {
            "tool": "mixlift_scenarios",
            "version": "0.5.3",
            "status_quo_revenue": 480_000.0,
        }
        memo = render_scenarios_memo(result)
        assert memo == ""


# ---------------------------------------------------------------------------
# Edge case 5: all scenarios produce identical revenue
# ---------------------------------------------------------------------------


class TestAllIdenticalRevenue:
    def test_identical_revenue_memo_says_no_recommendation(self):
        scenarios = [
            _make_scenario(
                "Status quo", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=1
            ),
            _make_scenario(
                "Cut Meta 50%",
                {"Meta": -0.5},
                480_000.0,
                440_000.0,
                520_000.0,
                0.0,
                rank=2,
            ),
            _make_scenario(
                "+20% Email",
                {"Email": 0.2},
                480_000.0,
                440_000.0,
                520_000.0,
                0.0,
                rank=3,
            ),
        ]
        result = _make_result(scenarios=scenarios)
        memo = render_scenarios_memo(result)
        assert "equivalent revenue" in memo.lower() or "no strong recommendation" in memo.lower()

    def test_no_best_move_heading_when_identical(self):
        scenarios = [
            _make_scenario("Status quo", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=1),
            _make_scenario("Flat scenario", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=2),
        ]
        result = _make_result(scenarios=scenarios)
        memo = render_scenarios_memo(result)
        assert "Best move" not in memo


# ---------------------------------------------------------------------------
# Edge case 3: clipped scenario → flag present
# ---------------------------------------------------------------------------


class TestClippedScenario:
    def test_clipped_flag_renders(self):
        scenarios = [
            _make_scenario(
                "Status quo", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=1
            ),
            _make_scenario(
                "Extreme cut",
                {"TV": -2.0},
                475_000.0,
                430_000.0,
                520_000.0,
                -5_000.0,
                rank=2,
                clipped=True,
            ),
        ]
        result = _make_result(scenarios=scenarios)
        memo = render_scenarios_memo(result)
        assert "clipped" in memo.lower() or "\u2020" in memo or "†" in memo

    def test_clipped_detail_in_scenario_section(self):
        scenarios = [
            _make_scenario(
                "Status quo", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=1
            ),
            _make_scenario(
                "Negative budget",
                {"TV": -2.0},
                475_000.0,
                430_000.0,
                520_000.0,
                -5_000.0,
                rank=2,
                clipped=True,
            ),
        ]
        result = _make_result(scenarios=scenarios)
        memo = render_scenarios_memo(result)
        assert "floor" in memo.lower() or "clipped" in memo.lower()


# ---------------------------------------------------------------------------
# Edge case 7: extrapolated scenario → warning present
# ---------------------------------------------------------------------------


class TestExtrapolatedScenario:
    def test_extrapolated_flag_renders_table_marker(self):
        scenarios = [
            _make_scenario(
                "Status quo", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=1
            ),
            _make_scenario(
                "3x Email spend",
                {"Email": 2.0},
                510_000.0,
                465_000.0,
                555_000.0,
                30_000.0,
                rank=2,
                extrapolated=True,
            ),
        ]
        result = _make_result(scenarios=scenarios)
        memo = render_scenarios_memo(result)
        # Footer warning must appear
        assert "outside observed spend range" in memo

    def test_extrapolated_detail_in_scenario_section(self):
        scenarios = [
            _make_scenario(
                "Status quo", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=1
            ),
            _make_scenario(
                "Big spend", {"Email": 3.0}, 520_000.0, 470_000.0, 570_000.0, 40_000.0, rank=1,
                extrapolated=True,
            ),
        ]
        result = _make_result(scenarios=scenarios)
        memo = render_scenarios_memo(result)
        assert "Extrapolation warning" in memo or "extrapolation" in memo.lower()


# ---------------------------------------------------------------------------
# Edge case 4: single channel
# ---------------------------------------------------------------------------


class TestSingleChannelScenarios:
    def test_single_channel_renders_gracefully(self):
        scenarios = [
            _make_scenario("Status quo", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=1),
            _make_scenario(
                "Cut Meta 50%", {"Meta": -0.5}, 450_000.0, 410_000.0, 490_000.0, -30_000.0, rank=2
            ),
        ]
        result = _make_result(scenarios=scenarios)
        memo = render_scenarios_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 100

    def test_single_channel_winner_present(self):
        scenarios = [
            _make_scenario(
                "+10% Meta", {"Meta": 0.1}, 490_000.0, 450_000.0, 530_000.0, 10_000.0, rank=1
            ),
            _make_scenario("Status quo", {}, 480_000.0, 440_000.0, 520_000.0, 0.0, rank=2),
        ]
        result = _make_result(scenarios=scenarios)
        memo = render_scenarios_memo(result)
        assert "+10% Meta" in memo or "Best move" in memo


# ---------------------------------------------------------------------------
# Absolute-mode scenario rendering
# ---------------------------------------------------------------------------


class TestAbsoluteModeScenario:
    def test_absolute_mode_shows_dollar_sign_in_details(self):
        sc = _make_scenario(
            "Shift $10k from TV to Email",
            {"TV": -10_000, "Email": 10_000},
            486_000.0,
            442_000.0,
            530_000.0,
            6_000.0,
            rank=1,
            mode="absolute",
        )
        result = _make_result(scenarios=[sc])
        memo = render_scenarios_memo(result)
        # Absolute mode: delta shown as dollars
        assert "$" in memo
        assert "10,000" in memo or "$10k" in memo or "10k" in memo


# ---------------------------------------------------------------------------
# Snapshot test
# ---------------------------------------------------------------------------

_SNAPSHOT_PATH = (
    pathlib.Path(__file__).parent.parent / "snapshots" / "scenarios_memo__demo_e2e.md"
)


class TestSnapshot:
    def test_snapshot_matches_committed(self):
        """Rendered memo must exactly match the committed snapshot.

        To regenerate after intentional changes:
            UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_scenarios_memo.py
        """
        result = _make_result()
        rendered_memo = render_scenarios_memo(result)

        if os.environ.get("UPDATE_SNAPSHOTS") == "1":
            _SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _SNAPSHOT_PATH.write_text(rendered_memo)
            return  # regenerated — no assertion needed

        snapshot_text = _SNAPSHOT_PATH.read_text()
        assert rendered_memo == snapshot_text, (
            "Snapshot mismatch. To update: "
            "UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_scenarios_memo.py"
        )

    def test_snapshot_contains_comparison_table(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        assert "Rank" in memo
        assert "Projected" in memo
        assert "vs SQ" in memo

    def test_snapshot_opening_verdict(self):
        result = _make_result()
        memo = render_scenarios_memo(result)
        # Winner is the +20% scenario with +$18k
        assert "Best move" in memo
        assert "+20% budget to Email and Influencer" in memo
