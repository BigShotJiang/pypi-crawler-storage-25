"""Unit tests for mixlift_mcp.renderers.reconcile_memo.

All tests feed pre-computed synthetic dicts to the renderer.
No PyMC-Marketing model is ever fitted.
"""

from __future__ import annotations

import os
import pathlib
import re

import pytest

from mixlift_mcp.renderers.reconcile_memo import (
    build_reconcile_result,
    normalise_platform_revenue_columns,
    render_reconcile_memo,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_DEFAULT_MCMC_CONFIG = {"chains": 4, "draws": 250, "target_accept": 0.90}
_DEFAULT_DATA_WINDOW = "2025-09-22 to 2026-04-13 (30 weeks)"


def _make_reconcile_result(
    channels: list[str] | None = None,
    means: dict[str, float] | None = None,
    cis: dict[str, tuple[float, float]] | None = None,
    spends: dict[str, float] | None = None,
    platform_revenue: dict[str, float | None] | None = None,
    period: str = "last_4_weeks",
    period_weeks: int = 4,
    period_label: str = "Last 4 weeks (2026-03-17 to 2026-04-14)",
) -> dict:
    """Build a reconcile result dict for render_reconcile_memo."""
    if channels is None:
        channels = ["meta_spend", "google_search_spend", "tiktok_spend", "email_spend"]

    if means is None:
        means = {
            "Meta": 80_000.0,
            "Google Search": 130_000.0,
            "TikTok": 55_000.0,
            "Email": 25_000.0,
        }

    if cis is None:
        cis = {
            "Meta": (72_000.0, 88_000.0),
            "Google Search": (117_000.0, 143_000.0),
            "TikTok": (49_500.0, 60_500.0),
            "Email": (22_000.0, 28_000.0),
        }

    if spends is None:
        spends = {
            "Meta": 18_070.0,
            "Google Search": 16_000.0,
            "TikTok": 8_000.0,
            "Email": 800.0,
        }

    if platform_revenue is None:
        platform_revenue = {
            "Meta": 340_000.0,
            "Google Search": 180_000.0,
            "TikTok": 60_000.0,
            "Email": None,  # unmeasured
        }

    return build_reconcile_result(
        period=period,
        period_weeks=period_weeks,
        period_label=period_label,
        data_window=_DEFAULT_DATA_WINDOW,
        mcmc_config=_DEFAULT_MCMC_CONFIG,
        channel_columns=channels,
        means_dict=means,
        cis_dict=cis,
        spend_dict=spends,
        platform_revenue_dict=platform_revenue,
    )


# ---------------------------------------------------------------------------
# Column normalisation
# ---------------------------------------------------------------------------


class TestNormalisePlatformRevenueColumns:
    def test_canonical_suffix_detected(self):
        cols = ["meta_spend", "meta_platform_reported_revenue", "revenue"]
        result = normalise_platform_revenue_columns(cols)
        assert "meta" in result
        assert result["meta"] == "meta_platform_reported_revenue"

    def test_alias_reported_revenue(self):
        cols = ["meta_reported_revenue"]
        result = normalise_platform_revenue_columns(cols)
        assert "meta" in result
        assert result["meta"] == "meta_platform_reported_revenue"

    def test_alias_platform_revenue(self):
        cols = ["google_search_platform_revenue"]
        result = normalise_platform_revenue_columns(cols)
        assert "google_search" in result
        assert result["google_search"] == "google_search_platform_reported_revenue"

    def test_multiple_channels(self):
        cols = [
            "meta_platform_reported_revenue",
            "google_search_platform_revenue",
            "tiktok_reported_revenue",
        ]
        result = normalise_platform_revenue_columns(cols)
        assert len(result) == 3
        assert "meta" in result
        assert "google_search" in result
        assert "tiktok" in result

    def test_spend_col_not_detected(self):
        cols = ["meta_spend", "google_search_spend", "revenue"]
        result = normalise_platform_revenue_columns(cols)
        assert result == {}

    def test_empty_columns(self):
        result = normalise_platform_revenue_columns([])
        assert result == {}

    def test_case_insensitive(self):
        cols = ["Meta_Platform_Reported_Revenue"]
        result = normalise_platform_revenue_columns(cols)
        assert len(result) == 1


# ---------------------------------------------------------------------------
# build_reconcile_result — structured output shape
# ---------------------------------------------------------------------------


class TestBuildReconcileResult:
    def test_top_level_keys_match_spec(self):
        result = _make_reconcile_result()
        required_keys = {
            "tool",
            "version",
            "mcmc_config",
            "data_window",
            "period_label",
            "period_weeks",
            "total_platform_reported",
            "total_mmm_attributed",
            "total_gap_dollars",
            "total_gap_pct",
            "channels",
        }
        assert required_keys.issubset(set(result.keys()))

    def test_tool_name_correct(self):
        result = _make_reconcile_result()
        assert result["tool"] == "mixlift_reconcile"

    def test_version_correct(self):
        result = _make_reconcile_result()
        assert result["version"] == "0.5.3"

    def test_channel_keys_match_spec(self):
        result = _make_reconcile_result()
        required_ch_keys = {
            "name",
            "platform_reported_revenue",
            "mmm_attributed_revenue",
            "mmm_ci",
            "gap_dollars",
            "gap_pct",
            "verdict",
            "spend",
            "platform_reported_roas",
            "mmm_roas",
        }
        for ch in result["channels"]:
            missing = required_ch_keys - set(ch.keys())
            assert missing == set(), f"Missing keys in channel {ch['name']}: {missing}"

    def test_measured_channels_sorted_by_abs_gap_desc(self):
        result = _make_reconcile_result()
        measured = [c for c in result["channels"] if c["gap_dollars"] is not None]
        gaps = [abs(c["gap_dollars"]) for c in measured]
        assert gaps == sorted(gaps, reverse=True)

    def test_unmeasured_channels_at_end(self):
        result = _make_reconcile_result()
        verdicts = [c["verdict"] for c in result["channels"]]
        # All unmeasured must come after all measured
        last_measured_idx = -1
        first_unmeasured_idx = len(verdicts)
        for i, v in enumerate(verdicts):
            if v != "unmeasured":
                last_measured_idx = i
            elif first_unmeasured_idx == len(verdicts):
                first_unmeasured_idx = i
        assert last_measured_idx < first_unmeasured_idx

    def test_over_claiming_verdict(self):
        result = _make_reconcile_result()
        meta = next(c for c in result["channels"] if c["name"] == "Meta")
        # Meta: platform=340k, mmm=80k → gap=260k, 325% → over_claiming
        assert meta["verdict"] == "over_claiming"
        assert meta["gap_dollars"] == pytest.approx(260_000, abs=1)

    def test_aligned_verdict(self):
        result = _make_reconcile_result(
            channels=["tiktok_spend"],
            means={"TikTok": 55_000.0},
            cis={"TikTok": (49_500.0, 60_500.0)},
            spends={"TikTok": 8_000.0},
            platform_revenue={"TikTok": 60_000.0},  # 9% gap → aligned
        )
        ch = result["channels"][0]
        assert ch["verdict"] == "aligned"

    def test_unmeasured_verdict(self):
        result = _make_reconcile_result(
            channels=["email_spend"],
            means={"Email": 25_000.0},
            cis={"Email": (22_000.0, 28_000.0)},
            spends={"Email": 800.0},
            platform_revenue={"Email": None},
        )
        ch = result["channels"][0]
        assert ch["verdict"] == "unmeasured"
        assert ch["gap_dollars"] is None
        assert ch["gap_pct"] is None
        assert ch["platform_reported_revenue"] is None
        assert ch["platform_reported_roas"] is None

    def test_total_platform_sums_measured_only(self):
        result = _make_reconcile_result()
        # Meta=340k, Google=180k, TikTok=60k; Email=None
        expected = 340_000 + 180_000 + 60_000
        assert result["total_platform_reported"] == pytest.approx(expected, abs=1)

    def test_total_gap_dollars_correct(self):
        result = _make_reconcile_result()

        # total_platform_reported - sum(mmm for measured channels)
        def _mmm(name: str) -> float:
            return next(c for c in result["channels"] if c["name"] == name)[
                "mmm_attributed_revenue"
            ]

        expected_gap = (
            340_000 + 180_000 + 60_000 - (_mmm("Meta") + _mmm("Google Search") + _mmm("TikTok"))
        )
        assert result["total_gap_dollars"] == pytest.approx(expected_gap, abs=1)

    def test_mmm_ci_is_list_of_two(self):
        result = _make_reconcile_result()
        for ch in result["channels"]:
            assert isinstance(ch["mmm_ci"], list)
            assert len(ch["mmm_ci"]) == 2

    def test_roas_computed(self):
        result = _make_reconcile_result(
            channels=["meta_spend"],
            means={"Meta": 80_000.0},
            cis={"Meta": (72_000.0, 88_000.0)},
            spends={"Meta": 18_070.0},
            platform_revenue={"Meta": 340_000.0},
        )
        ch = result["channels"][0]
        assert ch["mmm_roas"] == pytest.approx(80_000 / 18_070, rel=0.01)
        assert ch["platform_reported_roas"] == pytest.approx(340_000 / 18_070, rel=0.01)


# ---------------------------------------------------------------------------
# render_reconcile_memo — structure
# ---------------------------------------------------------------------------


class TestRenderReconcileMemoStructure:
    def test_returns_non_empty_string(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 100

    def test_headline_present(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        assert "##" in memo

    def test_reconciliation_table_present(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        assert "Platform RPT" in memo or "MMM attrib" in memo

    def test_likely_causes_section_present(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        assert "Why the gap" in memo

    def test_footer_present(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        assert "incremental" in memo.lower() or "directional" in memo.lower()

    def test_no_emojis(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        emoji_pattern = re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(memo), "Emoji found in memo"

    def test_over_claiming_appears_in_table(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        assert "Over-claiming" in memo

    def test_unmeasured_appears_in_table(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        assert "Unmeasured" in memo

    def test_all_channels_mentioned(self):
        result = _make_reconcile_result()
        memo = render_reconcile_memo(result)
        for name in ["Meta", "Google Search", "TikTok", "Email"]:
            assert name in memo

    def test_never_raises_on_empty_result(self):
        memo = render_reconcile_memo({})
        assert isinstance(memo, str)

    def test_never_raises_on_malformed(self):
        memo = render_reconcile_memo({"channels": None})
        assert isinstance(memo, str)


# ---------------------------------------------------------------------------
# Edge case: all channels aligned (< 5% gap)
# ---------------------------------------------------------------------------


class TestAllChannelsAligned:
    def test_clean_reconciliation_headline(self):
        result = _make_reconcile_result(
            channels=["meta_spend", "tiktok_spend"],
            means={"Meta": 100_000.0, "TikTok": 50_000.0},
            cis={"Meta": (90_000.0, 110_000.0), "TikTok": (45_000.0, 55_000.0)},
            spends={"Meta": 20_000.0, "TikTok": 10_000.0},
            platform_revenue={"Meta": 103_000.0, "TikTok": 51_000.0},  # 3% and 2% gaps
        )
        memo = render_reconcile_memo(result)
        assert "clean" in memo.lower() or "5%" in memo or "agree" in memo.lower()


# ---------------------------------------------------------------------------
# Edge case: no platform columns → handled at tool level, memo shows fallback
# ---------------------------------------------------------------------------


class TestNoMeasuredChannels:
    def test_all_unmeasured_no_headline_gap(self):
        result = _make_reconcile_result(
            channels=["email_spend"],
            means={"Email": 25_000.0},
            cis={"Email": (22_000.0, 28_000.0)},
            spends={"Email": 800.0},
            platform_revenue={"Email": None},
        )
        # total_platform_reported should be None
        assert result["total_platform_reported"] is None

    def test_memo_still_renders(self):
        result = _make_reconcile_result(
            channels=["email_spend"],
            means={"Email": 25_000.0},
            cis={"Email": (22_000.0, 28_000.0)},
            spends={"Email": 800.0},
            platform_revenue={"Email": None},
        )
        memo = render_reconcile_memo(result)
        assert isinstance(memo, str)


# ---------------------------------------------------------------------------
# Memo token length constraint (<= 2500 tokens)
# ---------------------------------------------------------------------------


class TestMemoTokenLength:
    def test_8_channel_memo_under_2500_tokens(self):
        channels = [
            "meta_spend",
            "google_search_spend",
            "tiktok_spend",
            "email_spend",
            "youtube_spend",
            "bing_spend",
            "pinterest_spend",
            "snapchat_spend",
        ]
        means = {
            "Meta": 80_000.0,
            "Google Search": 130_000.0,
            "TikTok": 55_000.0,
            "Email": 25_000.0,
            "Youtube": 40_000.0,
            "Bing": 20_000.0,
            "Pinterest": 15_000.0,
            "Snapchat": 10_000.0,
        }
        cis = {name: (v * 0.9, v * 1.1) for name, v in means.items()}
        spends = {name: v / 4.0 for name, v in means.items()}
        platform_revenue = {
            "Meta": 320_000.0,
            "Google Search": 180_000.0,
            "TikTok": 60_000.0,
            "Email": None,
            "Youtube": 42_000.0,
            "Bing": None,
            "Pinterest": 17_000.0,
            "Snapchat": None,
        }
        result = build_reconcile_result(
            period="last_4_weeks",
            period_weeks=4,
            period_label="Last 4 weeks (2026-03-17 to 2026-04-14)",
            data_window=_DEFAULT_DATA_WINDOW,
            mcmc_config=_DEFAULT_MCMC_CONFIG,
            channel_columns=channels,
            means_dict=means,
            cis_dict=cis,
            spend_dict=spends,
            platform_revenue_dict=platform_revenue,
        )
        memo = render_reconcile_memo(result)
        estimated_tokens = len(memo) / 4
        assert estimated_tokens <= 2500, (
            f"Memo is too long: ~{estimated_tokens:.0f} estimated tokens "
            f"(limit 2500). Actual chars: {len(memo)}"
        )


# ---------------------------------------------------------------------------
# Snapshot test
# ---------------------------------------------------------------------------


def _make_snapshot_result() -> dict:
    """Canonical 4-channel mock result for snapshot testing."""
    channels = ["meta_spend", "google_search_spend", "tiktok_spend", "email_spend"]
    means = {
        "Meta": 80_000.0,
        "Google Search": 130_000.0,
        "TikTok": 55_000.0,
        "Email": 25_000.0,
    }
    cis = {
        "Meta": (72_000.0, 88_000.0),
        "Google Search": (117_000.0, 143_000.0),
        "TikTok": (49_500.0, 60_500.0),
        "Email": (22_000.0, 28_000.0),
    }
    spends = {
        "Meta": 18_070.0,
        "Google Search": 16_000.0,
        "TikTok": 8_000.0,
        "Email": 800.0,
    }
    platform_revenue = {
        "Meta": 340_000.0,
        "Google Search": 180_000.0,
        "TikTok": 60_000.0,
        "Email": None,
    }
    return build_reconcile_result(
        period="last_4_weeks",
        period_weeks=4,
        period_label="Last 4 weeks (2026-03-17 to 2026-04-14)",
        data_window=_DEFAULT_DATA_WINDOW,
        mcmc_config=_DEFAULT_MCMC_CONFIG,
        channel_columns=channels,
        means_dict=means,
        cis_dict=cis,
        spend_dict=spends,
        platform_revenue_dict=platform_revenue,
    )


_SNAPSHOT_PATH = (
    pathlib.Path(__file__).parent.parent / "snapshots" / "reconcile_memo__reconcile_input.md"
)


class TestSnapshot:
    def test_snapshot_matches_committed(self):
        """Rendered memo must exactly match the committed snapshot.

        To regenerate:
            UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_reconcile_memo.py
        """
        result = _make_snapshot_result()
        rendered_memo = render_reconcile_memo(result)

        if os.environ.get("UPDATE_SNAPSHOTS") == "1":
            _SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _SNAPSHOT_PATH.write_text(rendered_memo)
            return

        snapshot_text = _SNAPSHOT_PATH.read_text()
        assert rendered_memo == snapshot_text, (
            "Snapshot mismatch. To update: "
            "UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_reconcile_memo.py"
        )

    def test_headline_in_snapshot(self):
        result = _make_snapshot_result()
        memo = render_reconcile_memo(result)
        assert "##" in memo
        assert "Meta" in memo or "over" in memo.lower()

    def test_all_channels_in_snapshot(self):
        result = _make_snapshot_result()
        memo = render_reconcile_memo(result)
        for name in ["Meta", "Google Search", "TikTok", "Email"]:
            assert name in memo
