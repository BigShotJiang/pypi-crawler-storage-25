"""Unit tests for mixlift_mcp.renderers.pacing_memo.

All tests feed pre-computed dicts or invoke build_pacing_result with synthetic
fixtures. No PyMC-Marketing model is ever fitted.
"""

from __future__ import annotations

import os
import pathlib
import re

from mixlift_mcp.renderers.pacing_memo import (
    _classify_status,
    _parse_today,
    _period_bounds,
    _period_label,
    build_pacing_result,
    render_pacing_memo,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_FIXTURES = pathlib.Path(__file__).parent.parent / "fixtures"
_PACING_CSV = str(_FIXTURES / "pacing_input.csv")
_SNAPSHOT_PATH = pathlib.Path(__file__).parent.parent / "snapshots" / "pacing_memo__pacing_input.md"

_PLAN = {"Meta": 80000.0, "Google Search": 60000.0, "TikTok": 30000.0}
_TODAY = "2026-04-15"


def _make_result(today: str = _TODAY, plan: dict | None = None) -> dict:
    """Build a full pacing result from the standard fixture."""
    return build_pacing_result(
        csv_path=_PACING_CSV,
        plan=plan if plan is not None else _PLAN,
        plan_period="month",
        today_str=today,
    )


# ---------------------------------------------------------------------------
# _parse_today
# ---------------------------------------------------------------------------


class TestParseToday:
    def test_valid_iso_date(self):
        from datetime import date

        result = _parse_today("2026-04-15")
        assert result == date(2026, 4, 15)

    def test_none_returns_today(self):
        from datetime import date

        result = _parse_today(None)
        assert result == date.today()

    def test_invalid_returns_none(self):
        result = _parse_today("not-a-date")
        assert result is None

    def test_invalid_format_returns_none(self):
        result = _parse_today("04/15/2026")
        assert result is None


# ---------------------------------------------------------------------------
# _period_bounds
# ---------------------------------------------------------------------------


class TestPeriodBounds:
    def test_month_returns_first_and_last(self):
        from datetime import date

        start, end = _period_bounds(date(2026, 4, 15), "month")
        assert start == date(2026, 4, 1)
        assert end == date(2026, 4, 30)

    def test_february_leap_year(self):
        from datetime import date

        start, end = _period_bounds(date(2024, 2, 15), "month")
        assert start == date(2024, 2, 1)
        assert end == date(2024, 2, 29)  # 2024 is a leap year

    def test_week_returns_monday_to_sunday(self):
        from datetime import date

        # 2026-04-13 is a Monday
        start, end = _period_bounds(date(2026, 4, 15), "week")  # Wednesday
        assert start == date(2026, 4, 13)  # Monday
        assert end == date(2026, 4, 19)  # Sunday

    def test_quarter_q1(self):
        from datetime import date

        start, end = _period_bounds(date(2026, 2, 15), "quarter")
        assert start == date(2026, 1, 1)
        assert end == date(2026, 3, 31)

    def test_quarter_q2(self):
        from datetime import date

        start, end = _period_bounds(date(2026, 4, 15), "quarter")
        assert start == date(2026, 4, 1)
        assert end == date(2026, 6, 30)


# ---------------------------------------------------------------------------
# _classify_status
# ---------------------------------------------------------------------------


class TestClassifyStatus:
    def test_under_below_neg_5pct(self):
        assert _classify_status(-0.10) == "under"

    def test_on_track_within_band(self):
        assert _classify_status(0.03) == "on_track"
        assert _classify_status(-0.04) == "on_track"

    def test_over_above_5pct(self):
        assert _classify_status(0.12) == "over"

    def test_boundary_neg_5pct_is_on_track(self):
        # Exactly -5% → on_track (not strictly less than)
        assert _classify_status(-0.05) == "on_track"

    def test_boundary_5pct_is_on_track(self):
        # Exactly +5% → on_track
        assert _classify_status(0.05) == "on_track"


# ---------------------------------------------------------------------------
# _period_label
# ---------------------------------------------------------------------------


class TestPeriodLabel:
    def test_month_label(self):
        from datetime import date

        start, end = _period_bounds(date(2026, 4, 15), "month")
        label = _period_label(date(2026, 4, 15), "month", start, end)
        assert "April 2026" in label
        assert "day 15 of 30" in label

    def test_week_label(self):
        from datetime import date

        start, end = _period_bounds(date(2026, 4, 15), "week")
        label = _period_label(date(2026, 4, 15), "week", start, end)
        assert "day" in label

    def test_quarter_label(self):
        from datetime import date

        start, end = _period_bounds(date(2026, 4, 15), "quarter")
        label = _period_label(date(2026, 4, 15), "quarter", start, end)
        assert "Q2 2026" in label


# ---------------------------------------------------------------------------
# build_pacing_result — happy path
# ---------------------------------------------------------------------------


class TestBuildPacingResultHappyPath:
    def test_returns_dict_with_tool_key(self):
        result = _make_result()
        assert result.get("tool") == "mixlift_pacing"

    def test_version_field(self):
        result = _make_result()
        assert result.get("version") == "0.5.3"

    def test_plan_period_field(self):
        result = _make_result()
        assert result.get("plan_period") == "month"

    def test_today_field(self):
        result = _make_result()
        assert result.get("today") == _TODAY

    def test_days_total_is_30_for_april(self):
        result = _make_result()
        assert result["days_total"] == 30

    def test_days_elapsed_is_14(self):
        # today=2026-04-15 means 14 completed days (Apr 1–14 have data)
        result = _make_result()
        assert result["days_elapsed"] == 14

    def test_days_remaining_is_16(self):
        result = _make_result()
        assert result["days_remaining"] == 16

    def test_pct_elapsed_correct(self):
        result = _make_result()
        assert abs(result["pct_elapsed"] - 46.7) < 0.2

    def test_total_budget_sums_plan(self):
        result = _make_result()
        assert result["total"]["budget"] == sum(_PLAN.values())

    def test_total_spent_positive(self):
        result = _make_result()
        assert result["total"]["spent"] > 0

    def test_channels_list_has_three_entries(self):
        result = _make_result()
        assert len(result["channels"]) == 3

    def test_channel_keys_match_spec(self):
        result = _make_result()
        ch = result["channels"][0]
        required = {
            "name",
            "budget",
            "spent",
            "pct_used",
            "projected_end",
            "variance",
            "variance_pct",
            "current_daily_avg",
            "required_daily_to_hit_plan",
            "status",
        }
        assert required == set(ch.keys())

    def test_channels_sorted_by_abs_variance_desc(self):
        result = _make_result()
        variances = [abs(c["variance"]) for c in result["channels"]]
        assert variances == sorted(variances, reverse=True)

    def test_status_is_valid_value(self):
        result = _make_result()
        valid = {"under", "on_track", "over"}
        for ch in result["channels"]:
            assert ch["status"] in valid

    def test_memo_markdown_is_non_empty_string(self):
        result = _make_result()
        assert isinstance(result.get("memo_markdown"), str)
        assert len(result["memo_markdown"]) > 100

    def test_memo_contains_h2_verdict(self):
        result = _make_result()
        assert result["memo_markdown"].startswith("## You are day")

    def test_memo_contains_pacing_table(self):
        result = _make_result()
        assert "| Channel" in result["memo_markdown"]
        assert "| **Total**" in result["memo_markdown"]

    def test_memo_contains_adjustment_table(self):
        result = _make_result()
        assert "### To land on plan" in result["memo_markdown"]

    def test_no_emojis_in_memo(self):
        result = _make_result()
        emoji_pattern = re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(result["memo_markdown"]), "Emoji found in memo"

    def test_memo_under_2000_tokens(self):
        result = _make_result()
        # Crude estimate: ~4 chars per token
        estimated_tokens = len(result["memo_markdown"]) / 4
        assert estimated_tokens <= 2000, (
            f"Memo too long: ~{estimated_tokens:.0f} estimated tokens. "
            f"Actual chars: {len(result['memo_markdown'])}"
        )


# ---------------------------------------------------------------------------
# Edge case 1: no plan provided
# ---------------------------------------------------------------------------


class TestNoPlan:
    def test_none_plan_returns_error(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=None,
            plan_period="month",
            today_str=_TODAY,
        )
        assert result.get("status") == "error"
        assert "plan" in result["message"].lower()

    def test_empty_plan_returns_error(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan={},
            plan_period="month",
            today_str=_TODAY,
        )
        assert result.get("status") == "error"


# ---------------------------------------------------------------------------
# Edge case 2: today outside data range — warn and use latest data date
# ---------------------------------------------------------------------------


class TestTodayOutsideDataRange:
    def test_future_today_includes_footnote(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="month",
            today_str="2026-06-01",  # well after the data ends
        )
        # Should succeed (not error) but note the date mismatch
        assert "tool" in result or "status" in result
        if "tool" in result:
            notes = result.get("_memo_footnotes", [])
            assert any("outside" in n.lower() or "data range" in n.lower() for n in notes)


# ---------------------------------------------------------------------------
# Edge case 3: channel in plan but not in data → $0 spent
# ---------------------------------------------------------------------------


class TestChannelInPlanNotInData:
    def test_missing_data_channel_shows_zero_spend(self):
        plan_with_ghost = dict(_PLAN)
        plan_with_ghost["LinkedIn"] = 20000.0
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=plan_with_ghost,
            plan_period="month",
            today_str=_TODAY,
        )
        assert "tool" in result
        linkedin_ch = next((c for c in result["channels"] if c["name"] == "LinkedIn"), None)
        assert linkedin_ch is not None
        assert linkedin_ch["spent"] == 0.0
        assert linkedin_ch["current_daily_avg"] == 0.0

    def test_missing_data_channel_footnote(self):
        plan_with_ghost = dict(_PLAN)
        plan_with_ghost["LinkedIn"] = 20000.0
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=plan_with_ghost,
            plan_period="month",
            today_str=_TODAY,
        )
        assert "tool" in result
        footnotes = result.get("_memo_footnotes", [])
        assert any("LinkedIn" in fn for fn in footnotes)


# ---------------------------------------------------------------------------
# Edge case 4: channel in data but not in plan → excluded from table
# ---------------------------------------------------------------------------


class TestChannelInDataNotInPlan:
    def test_unlisted_channel_excluded_from_results(self):
        # Plan only covers Meta — Google Search and TikTok are in data but not plan
        single_plan = {"Meta": 80000.0}
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=single_plan,
            plan_period="month",
            today_str=_TODAY,
        )
        assert "tool" in result
        names = [c["name"] for c in result["channels"]]
        assert "Google Search" not in names
        assert "TikTok" not in names

    def test_unlisted_channels_footnote(self):
        single_plan = {"Meta": 80000.0}
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=single_plan,
            plan_period="month",
            today_str=_TODAY,
        )
        footnotes = result.get("_memo_footnotes", [])
        assert any("not in plan" in fn.lower() or "excluded" in fn.lower() for fn in footnotes)


# ---------------------------------------------------------------------------
# Edge case 5: today on day 1 of period — pct_elapsed = 1/N, no div-by-zero
# ---------------------------------------------------------------------------


class TestDayOneOfPeriod:
    def test_first_day_no_divide_by_zero(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="month",
            today_str="2026-04-01",  # day 1 of April
        )
        # Should not raise and should return a result dict
        assert isinstance(result, dict)
        # Either an error (no data before day 1) or a valid result with days_elapsed >= 1
        if "tool" in result:
            assert result["days_elapsed"] >= 1

    def test_first_day_pct_elapsed_nonzero(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="month",
            today_str="2026-04-01",
        )
        if "tool" in result:
            assert result["pct_elapsed"] > 0


# ---------------------------------------------------------------------------
# Edge case 6: today past period end — "Period closed" verdict
# ---------------------------------------------------------------------------


class TestPeriodClosed:
    def test_period_closed_verdict_in_memo(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="month",
            today_str="2026-05-05",  # May 5 — April is closed
        )
        if "tool" in result:
            memo = result.get("memo_markdown", "")
            assert "Period closed" in memo or "actuals final" in memo.lower()

    def test_period_closed_days_elapsed_equals_total(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="month",
            today_str="2026-05-05",
        )
        if "tool" in result:
            assert result["days_elapsed"] == result["days_total"]

    def test_period_closed_no_adjustment_table(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="month",
            today_str="2026-05-05",
        )
        if "tool" in result:
            memo = result.get("memo_markdown", "")
            assert "### To land on plan" not in memo


# ---------------------------------------------------------------------------
# Edge case 7: negative actuals → error JSON
# ---------------------------------------------------------------------------


class TestNegativeActuals:
    def test_negative_spend_returns_error(self, tmp_path):
        csv_path = tmp_path / "neg.csv"
        csv_path.write_text("date,Meta\n2026-04-01,-500.00\n2026-04-02,1000.00\n")
        result = build_pacing_result(
            csv_path=str(csv_path),
            plan={"Meta": 80000.0},
            plan_period="month",
            today_str=_TODAY,
        )
        assert result.get("status") == "error"
        assert "negative" in result["message"].lower()


# ---------------------------------------------------------------------------
# Edge case 8: empty CSV → error JSON
# ---------------------------------------------------------------------------


class TestEmptyCSV:
    def test_empty_file_returns_error(self, tmp_path):
        csv_path = tmp_path / "empty.csv"
        csv_path.write_text("")
        result = build_pacing_result(
            csv_path=str(csv_path),
            plan=_PLAN,
            plan_period="month",
            today_str=_TODAY,
        )
        assert result.get("status") == "error"

    def test_header_only_csv_returns_error(self, tmp_path):
        csv_path = tmp_path / "header_only.csv"
        csv_path.write_text("date,Meta,Google Search\n")
        result = build_pacing_result(
            csv_path=str(csv_path),
            plan=_PLAN,
            plan_period="month",
            today_str=_TODAY,
        )
        assert result.get("status") == "error"


# ---------------------------------------------------------------------------
# Edge case 9: invalid plan_period → error JSON
# ---------------------------------------------------------------------------


class TestInvalidPlanPeriod:
    def test_invalid_period_returns_error(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="fortnight",
            today_str=_TODAY,
        )
        assert result.get("status") == "error"
        assert "fortnight" in result["message"] or "valid" in result["message"].lower()

    def test_error_lists_valid_options(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="fortnight",
            today_str=_TODAY,
        )
        msg = result.get("message", "")
        # Should mention at least one valid option
        assert "week" in msg or "month" in msg or "quarter" in msg


# ---------------------------------------------------------------------------
# Edge case 10: invalid today ISO date → error JSON
# ---------------------------------------------------------------------------


class TestInvalidTodayDate:
    def test_invalid_date_returns_error(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="month",
            today_str="not-a-date",
        )
        assert result.get("status") == "error"
        assert "date" in result["message"].lower() or "invalid" in result["message"].lower()

    def test_american_format_returns_error(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="month",
            today_str="04/15/2026",
        )
        assert result.get("status") == "error"


# ---------------------------------------------------------------------------
# render_pacing_memo — robustness
# ---------------------------------------------------------------------------


class TestRenderPacingMemoRobustness:
    def test_empty_dict_returns_empty_string(self):
        assert render_pacing_memo({}) == ""

    def test_never_raises_on_malformed_input(self):
        memo = render_pacing_memo({"channels": None, "total": None})
        assert isinstance(memo, str)

    def test_period_closed_renders_final_verdict(self):
        result = _make_result()
        result["_period_closed"] = True
        result["days_elapsed"] = result["days_total"]
        memo = render_pacing_memo(result)
        assert "Period closed" in memo or "actuals final" in memo.lower()


# ---------------------------------------------------------------------------
# Quarterly plan_period
# ---------------------------------------------------------------------------


class TestQuarterlyPacing:
    def test_quarter_days_total(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="quarter",
            today_str=_TODAY,
        )
        if "tool" in result:
            # Q2 2026: Apr (30) + May (31) + Jun (30) = 91 days
            assert result["days_total"] == 91

    def test_quarter_period_label(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="quarter",
            today_str=_TODAY,
        )
        if "tool" in result:
            assert "Q2 2026" in result["period_label"]


# ---------------------------------------------------------------------------
# Weekly plan_period
# ---------------------------------------------------------------------------


class TestWeeklyPacing:
    def test_week_days_total_is_7(self):
        result = build_pacing_result(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="week",
            today_str=_TODAY,
        )
        if "tool" in result:
            assert result["days_total"] == 7


# ---------------------------------------------------------------------------
# Snapshot test
# ---------------------------------------------------------------------------


class TestSnapshot:
    def test_snapshot_matches_committed(self):
        """Rendered memo must exactly match the committed snapshot.

        To regenerate after intentional changes:
            UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_pacing_memo.py
        """
        result = _make_result()
        rendered_memo = result.get("memo_markdown", "")

        if os.environ.get("UPDATE_SNAPSHOTS") == "1":
            _SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _SNAPSHOT_PATH.write_text(rendered_memo)
            return  # regenerated — no assertion needed

        snapshot_text = _SNAPSHOT_PATH.read_text()
        assert rendered_memo == snapshot_text, (
            "Snapshot mismatch. To update: "
            "UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_pacing_memo.py"
        )
