"""Tests for mixlift_mcp.renderers.clean_memo."""

from __future__ import annotations

import os
import pathlib
import re

from mixlift_mcp.renderers.clean_memo import render_clean_memo

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_issue(
    kind: str = "channel_name_inconsistency",
    severity: str = "high",
    description: str = "'FB' and 'Meta' look like the same channel",
    affected_rows: int = 52,
    affected_values: list | None = None,
    proposed_fix: str = "Rename 'FB' \u2192 'Meta'",
    auto_applies: bool = True,
) -> dict:
    return {
        "kind": kind,
        "severity": severity,
        "description": description,
        "affected_rows": affected_rows,
        "affected_values": affected_values or ["FB", "facebook"],
        "proposed_fix": proposed_fix,
        "auto_applies": auto_applies,
    }


def _make_result(
    issues: list[dict] | None = None,
    applied: bool = False,
    output_path: str | None = None,
    output_summary: dict | None = None,
) -> dict:
    if issues is None:
        issues = [
            _make_issue(),
            _make_issue(
                kind="currency_markers",
                severity="low",
                description="Column 'spend' has currency markers",
                affected_rows=204,
                affected_values=["spend"],
                proposed_fix="Strip currency markers from 'spend' column.",
                auto_applies=True,
            ),
            _make_issue(
                kind="outlier_spike",
                severity="high",
                description=(
                    "Outlier spike on 2026-03-08: Meta spend $95,400 "
                    "(18\u00d7 rolling median of $5,260). Leave as-is or investigate?"
                ),
                affected_rows=1,
                affected_values=["2026-03-08", "Meta"],
                proposed_fix="Manual review required.",
                auto_applies=False,
            ),
            _make_issue(
                kind="ambiguous_date_format",
                severity="high",
                description=(
                    "Ambiguous date values found (e.g. ['01/02/2024']). Could be US or EU format."
                ),
                affected_rows=3,
                affected_values=["01/02/2024"],
                proposed_fix="Confirm date format (US vs EU) before converting to ISO.",
                auto_applies=False,
            ),
            _make_issue(
                kind="zero_spend_rows",
                severity="info",
                description="6 row(s) have zero spend across all channels.",
                affected_rows=6,
                affected_values=[],
                proposed_fix="Keep as-is.",
                auto_applies=False,
            ),
        ]
    return {
        "tool": "mixlift_clean",
        "version": "0.5.3",
        "input_path": "/path/to/data.csv",
        "output_path": output_path,
        "applied": applied,
        "input_summary": {
            "rows": 204,
            "channels": 8,
            "date_range": "2025-04-14 to 2026-04-07",
            "week_count": 52,
        },
        "issues": issues,
        "fixes_applied": [],
        "output_summary": output_summary,
    }


# ---------------------------------------------------------------------------
# Structure tests
# ---------------------------------------------------------------------------


class TestRenderCleanMemoStructure:
    def test_returns_string(self):
        result = _make_result()
        memo = render_clean_memo(result)
        assert isinstance(memo, str)

    def test_verdict_line_present(self):
        result = _make_result()
        memo = render_clean_memo(result)
        assert len(memo.splitlines()[0]) > 0

    def test_auto_fixable_section_present(self):
        result = _make_result()
        memo = render_clean_memo(result)
        assert "Auto-fixable" in memo

    def test_needs_your_call_section_present(self):
        result = _make_result()
        memo = render_clean_memo(result)
        assert "Needs your call" in memo

    def test_informational_section_present(self):
        result = _make_result()
        memo = render_clean_memo(result)
        assert "Informational" in memo

    def test_no_emojis(self):
        result = _make_result()
        memo = render_clean_memo(result)
        emoji_pattern = re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(memo), "Emoji found in clean memo"

    def test_returns_empty_string_on_empty_result(self):
        memo = render_clean_memo({})
        assert memo == ""

    def test_never_raises_on_malformed_input(self):
        memo = render_clean_memo({"issues": None})
        assert isinstance(memo, str)

    def test_clean_verdict_when_no_issues(self):
        result = _make_result(issues=[])
        memo = render_clean_memo(result)
        assert "clean" in memo.lower() or "no fixes" in memo.lower()

    def test_issue_counts_in_verdict(self):
        result = _make_result()
        memo = render_clean_memo(result)
        # Should mention number of issues
        assert any(char.isdigit() for char in memo.splitlines()[0])

    def test_output_section_when_applied(self):
        result = _make_result(
            applied=True,
            output_path="/path/to/data.cleaned.csv",
            output_summary={
                "rows": 198,
                "channels": 6,
                "date_range": "2025-04-14 to 2026-04-07",
                "week_count": 52,
            },
        )
        memo = render_clean_memo(result)
        assert "Output" in memo
        assert "data.cleaned.csv" in memo

    def test_no_output_section_when_dry_run(self):
        result = _make_result(applied=False, output_path=None)
        memo = render_clean_memo(result)
        # Should not show output section without a path
        assert "Cleaned file written" not in memo


# ---------------------------------------------------------------------------
# Memo length
# ---------------------------------------------------------------------------


class TestMemoTokenLength:
    def test_memo_under_1500_tokens(self):
        """Memo must be <= 1500 tokens (estimated at 4 chars/token)."""
        result = _make_result()
        memo = render_clean_memo(result)
        estimated_tokens = len(memo) / 4
        assert estimated_tokens <= 1500, (
            f"Memo too long: ~{estimated_tokens:.0f} estimated tokens "
            f"(limit 1500). Actual chars: {len(memo)}"
        )


# ---------------------------------------------------------------------------
# Snapshot test
# ---------------------------------------------------------------------------


_SNAPSHOT_PATH = pathlib.Path(__file__).parent.parent / "snapshots" / "clean_memo__messy_input.md"


def _make_snapshot_result() -> dict:
    """Canonical result dict for snapshot testing — mirrors messy_input.csv issues."""
    return _make_result(
        issues=[
            _make_issue(
                kind="channel_name_inconsistency",
                severity="high",
                description=(
                    "'FB' and 'facebook' look like the same channel (Meta) (6 rows affected)"
                ),
                affected_rows=6,
                affected_values=["FB", "facebook"],
                proposed_fix="Rename 'FB' \u2192 'Meta', Rename 'facebook' \u2192 'Meta'",
                auto_applies=True,
            ),
            _make_issue(
                kind="channel_name_inconsistency",
                severity="high",
                description=(
                    "'google_search' and 'AdWords' look like the same channel "
                    "(Google Ads) (4 rows affected)"
                ),
                affected_rows=4,
                affected_values=["google_search", "AdWords"],
                proposed_fix=(
                    "Rename 'google_search' \u2192 'Google', Rename 'AdWords' \u2192 'Google'"
                ),
                auto_applies=True,
            ),
            _make_issue(
                kind="channel_name_inconsistency",
                severity="high",
                description="'TTK' looks like the same channel as TikTok (2 rows affected)",
                affected_rows=2,
                affected_values=["TTK"],
                proposed_fix="Rename 'TTK' \u2192 'TikTok'",
                auto_applies=True,
            ),
            _make_issue(
                kind="currency_markers",
                severity="low",
                description="Column 'spend' contains currency markers in 78 rows.",
                affected_rows=78,
                affected_values=["spend"],
                proposed_fix="Strip currency markers from 'spend' column.",
                auto_applies=True,
            ),
            _make_issue(
                kind="outlier_spike",
                severity="high",
                description=(
                    "Outlier spike on 2025-03-31: TikTok spend $91,500 "
                    "(43\u00d7 rolling median of $2,100). Leave as-is or investigate?"
                ),
                affected_rows=1,
                affected_values=["2025-03-31", "TikTok"],
                proposed_fix="Manual review required \u2014 could be a real burst campaign.",
                auto_applies=False,
            ),
            _make_issue(
                kind="duplicate_rows",
                severity="medium",
                description="Found 2 exact duplicate row(s).",
                affected_rows=2,
                affected_values=[],
                proposed_fix="Drop exact duplicate rows.",
                auto_applies=True,
            ),
            _make_issue(
                kind="empty_rows",
                severity="low",
                description="Found 1 completely empty row(s).",
                affected_rows=1,
                affected_values=[],
                proposed_fix="Drop empty rows.",
                auto_applies=True,
            ),
            _make_issue(
                kind="whitespace_headers",
                severity="low",
                description=(
                    "Column header(s) have leading/trailing whitespace: "
                    "[' date ', 'channel ', 'spend ', 'revenue']"
                ),
                affected_rows=0,
                affected_values=[" date ", "channel ", "spend ", "revenue"],
                proposed_fix="Strip whitespace from column headers.",
                auto_applies=True,
            ),
            _make_issue(
                kind="zero_spend_rows",
                severity="info",
                description="0 row(s) have zero spend across all channels.",
                affected_rows=0,
                affected_values=[],
                proposed_fix="Keep as-is.",
                auto_applies=False,
            ),
        ],
        applied=False,
        output_path=None,
    )


class TestSnapshot:
    def test_snapshot_matches_committed(self):
        """Rendered memo must match committed snapshot.

        To regenerate:
            UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_clean_memo.py
        """
        result = _make_snapshot_result()
        rendered = render_clean_memo(result)

        if os.environ.get("UPDATE_SNAPSHOTS") == "1":
            _SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _SNAPSHOT_PATH.write_text(rendered)
            return

        snapshot_text = _SNAPSHOT_PATH.read_text()
        assert rendered == snapshot_text, (
            "Snapshot mismatch. To update: "
            "UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_clean_memo.py"
        )
