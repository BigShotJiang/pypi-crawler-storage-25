"""Unit tests for mixlift_mcp.renderers.wow_memo.

All tests feed pre-computed synthetic dicts to the renderer.
No PyMC-Marketing model is ever fitted.
"""

from __future__ import annotations

import os
import pathlib
import re

import pytest

from mixlift_mcp.renderers.wow_memo import (
    _PERIOD_MIN_WEEKS,
    _PERIOD_WEEKS,
    VALID_PERIODS,
    build_wow_result,
    render_wow_memo,
)

# ---------------------------------------------------------------------------
# Helpers: build synthetic wow result dicts
# ---------------------------------------------------------------------------

_DEFAULT_MCMC_CONFIG = {"chains": 4, "draws": 250, "target_accept": 0.90}
_DEFAULT_DATA_WINDOW = "2025-10-06 to 2026-04-14 (27 weeks)"


def _make_wow_result(
    channels: list[str] | None = None,
    current_means: dict[str, float] | None = None,
    prior_means: dict[str, float] | None = None,
    current_spend: dict[str, float] | None = None,
    prior_spend: dict[str, float] | None = None,
    current_revenue: float = 480_000.0,
    prior_revenue: float = 510_000.0,
    period: str = "week",
    period_label: str = (
        "Last week (2026-04-07 to 2026-04-14) vs prior (2026-03-31 to 2026-04-06)"
    ),
) -> dict:
    """Build a wow result dict for render_wow_memo."""
    if channels is None:
        channels = ["meta_spend", "google_search_spend", "tiktok_spend"]

    if current_means is None:
        current_means = {
            "Meta": 80_000.0,
            "Google Search": 60_000.0,
            "TikTok": 30_000.0,
        }
    if prior_means is None:
        prior_means = {
            "Meta": 92_000.0,
            "Google Search": 58_000.0,
            "TikTok": 35_000.0,
        }
    if current_spend is None:
        current_spend = {
            "Meta": 18_070.0,
            "Google Search": 15_000.0,
            "TikTok": 7_500.0,
        }
    if prior_spend is None:
        prior_spend = {
            "Meta": 16_500.0,
            "Google Search": 14_000.0,
            "TikTok": 8_000.0,
        }

    return build_wow_result(
        period=period,
        period_label=period_label,
        data_window=_DEFAULT_DATA_WINDOW,
        current_revenue=current_revenue,
        prior_revenue=prior_revenue,
        current_means=current_means,
        prior_means=prior_means,
        current_spend=current_spend,
        prior_spend=prior_spend,
        channel_columns=channels,
        mcmc_config=_DEFAULT_MCMC_CONFIG,
    )


# ---------------------------------------------------------------------------
# Period mapping
# ---------------------------------------------------------------------------


class TestPeriodMapping:
    def test_valid_periods_set(self):
        assert set(VALID_PERIODS) == {"week", "4_weeks", "quarter"}

    def test_week_is_1(self):
        assert _PERIOD_WEEKS["week"] == 1

    def test_4_weeks_is_4(self):
        assert _PERIOD_WEEKS["4_weeks"] == 4

    def test_quarter_is_13(self):
        assert _PERIOD_WEEKS["quarter"] == 13

    def test_week_min_is_2(self):
        assert _PERIOD_MIN_WEEKS["week"] == 2

    def test_4_weeks_min_is_8(self):
        assert _PERIOD_MIN_WEEKS["4_weeks"] == 8

    def test_quarter_min_is_26(self):
        assert _PERIOD_MIN_WEEKS["quarter"] == 26


# ---------------------------------------------------------------------------
# build_wow_result — structured output shape
# ---------------------------------------------------------------------------


class TestBuildWowResult:
    def test_top_level_keys_match_spec(self):
        result = _make_wow_result()
        required_keys = {
            "tool",
            "version",
            "mcmc_config",
            "data_window",
            "period_label",
            "period_weeks",
            "current_revenue",
            "prior_revenue",
            "delta",
            "delta_pct",
            "baseline",
            "paid_total",
            "channels",
        }
        assert required_keys.issubset(set(result.keys()))

    def test_tool_name_correct(self):
        result = _make_wow_result()
        assert result["tool"] == "mixlift_wow"

    def test_version_correct(self):
        result = _make_wow_result()
        assert result["version"] == "0.5.3"

    def test_period_weeks_correct(self):
        result = _make_wow_result(period="week")
        assert result["period_weeks"] == 1

    def test_period_weeks_4_weeks(self):
        result = _make_wow_result(period="4_weeks")
        assert result["period_weeks"] == 4

    def test_delta_computed_correctly(self):
        result = _make_wow_result(current_revenue=480_000.0, prior_revenue=510_000.0)
        assert result["delta"] == pytest.approx(-30_000.0, abs=1)

    def test_delta_pct_computed_correctly(self):
        result = _make_wow_result(current_revenue=480_000.0, prior_revenue=510_000.0)
        expected_pct = round((-30_000.0 / 510_000.0) * 100, 2)
        assert result["delta_pct"] == pytest.approx(expected_pct, abs=0.1)

    def test_baseline_keys(self):
        result = _make_wow_result()
        assert set(result["baseline"].keys()) == {"current", "prior", "delta"}

    def test_paid_total_keys(self):
        result = _make_wow_result()
        assert set(result["paid_total"].keys()) == {"current", "prior", "delta"}

    def test_channel_keys_match_spec(self):
        result = _make_wow_result()
        required_ch_keys = {
            "name",
            "contribution_current",
            "contribution_prior",
            "delta",
            "spend_current",
            "spend_prior",
            "spend_delta",
            "spend_effect",
            "efficiency_effect",
            "marginal_roas_current",
            "marginal_roas_prior",
        }
        for ch in result["channels"]:
            missing = required_ch_keys - set(ch.keys())
            assert missing == set(), f"Missing keys in channel {ch['name']}: {missing}"

    def test_channels_sorted_by_abs_delta_descending(self):
        result = _make_wow_result(
            channels=["meta_spend", "google_search_spend", "tiktok_spend"],
            current_means={"Meta": 80_000.0, "Google Search": 70_000.0, "TikTok": 30_000.0},
            prior_means={"Meta": 92_000.0, "Google Search": 60_000.0, "TikTok": 35_000.0},
        )
        abs_deltas = [abs(ch["delta"]) for ch in result["channels"]]
        assert abs_deltas == sorted(abs_deltas, reverse=True)

    def test_paid_total_current_sums_channel_contributions(self):
        result = _make_wow_result()
        expected = sum(ch["contribution_current"] for ch in result["channels"])
        assert result["paid_total"]["current"] == pytest.approx(expected, abs=1)

    def test_paid_total_prior_sums_channel_contributions(self):
        result = _make_wow_result()
        expected = sum(ch["contribution_prior"] for ch in result["channels"])
        assert result["paid_total"]["prior"] == pytest.approx(expected, abs=1)

    def test_baseline_current_equals_revenue_minus_paid(self):
        result = _make_wow_result()
        expected = result["current_revenue"] - result["paid_total"]["current"]
        assert result["baseline"]["current"] == pytest.approx(expected, abs=1)

    def test_marginal_roas_computed_from_contribution_over_spend(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 80_000.0},
            prior_means={"Meta": 40_000.0},
            current_spend={"Meta": 20_000.0},
            prior_spend={"Meta": 20_000.0},
            current_revenue=300_000.0,
            prior_revenue=300_000.0,
        )
        ch = result["channels"][0]
        assert ch["marginal_roas_current"] == pytest.approx(80_000.0 / 20_000.0, abs=0.01)
        assert ch["marginal_roas_prior"] == pytest.approx(40_000.0 / 20_000.0, abs=0.01)

    def test_marginal_roas_none_when_zero_spend(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 80_000.0},
            prior_means={"Meta": 40_000.0},
            current_spend={"Meta": 0.0},
            prior_spend={"Meta": 20_000.0},
            current_revenue=300_000.0,
            prior_revenue=300_000.0,
        )
        ch = result["channels"][0]
        assert ch["marginal_roas_current"] is None
        assert ch.get("zero_spend_period") is True


# ---------------------------------------------------------------------------
# Edge case 1: Data shorter than 2× period (tested at server level)
# ---------------------------------------------------------------------------
# This edge case is validated at the server/tool level (not the renderer).
# We test here that build_wow_result itself is robust to short-window data
# (the period slicing guard lives in server.py).


class TestEdgeCaseShortData:
    def test_build_result_accepts_any_period_string(self):
        """build_wow_result does not enforce data length — that's the server's job."""
        result = _make_wow_result(period="quarter")
        assert result["period_weeks"] == 13


# ---------------------------------------------------------------------------
# Edge case 2: Single channel
# ---------------------------------------------------------------------------


class TestSingleChannel:
    def test_single_channel_renders(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 80_000.0},
            prior_means={"Meta": 92_000.0},
            current_spend={"Meta": 18_070.0},
            prior_spend={"Meta": 16_500.0},
            current_revenue=380_000.0,
            prior_revenue=392_000.0,
        )
        memo = render_wow_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 100

    def test_single_channel_delta_table_has_expected_rows(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 80_000.0},
            prior_means={"Meta": 92_000.0},
            current_spend={"Meta": 18_070.0},
            prior_spend={"Meta": 16_500.0},
            current_revenue=380_000.0,
            prior_revenue=392_000.0,
        )
        memo = render_wow_memo(result)
        assert "Baseline" in memo
        assert "Paid" in memo
        assert "Meta" in memo

    def test_single_channel_decomp_table_present(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 80_000.0},
            prior_means={"Meta": 92_000.0},
            current_spend={"Meta": 18_070.0},
            prior_spend={"Meta": 16_500.0},
            current_revenue=380_000.0,
            prior_revenue=392_000.0,
        )
        memo = render_wow_memo(result)
        assert "Spend vs efficiency" in memo or "efficiency" in memo.lower()


# ---------------------------------------------------------------------------
# Edge case 3: Zero-delta week
# ---------------------------------------------------------------------------


class TestZeroDeltaWeek:
    def test_zero_delta_verdict_says_flat(self):
        result = _make_wow_result(
            current_revenue=500_000.0,
            prior_revenue=500_000.0,
            current_means={"Meta": 80_000.0, "Google Search": 60_000.0, "TikTok": 30_000.0},
            prior_means={"Meta": 80_000.0, "Google Search": 60_000.0, "TikTok": 30_000.0},
            current_spend={"Meta": 18_000.0, "Google Search": 15_000.0, "TikTok": 7_500.0},
            prior_spend={"Meta": 18_000.0, "Google Search": 15_000.0, "TikTok": 7_500.0},
        )
        memo = render_wow_memo(result)
        assert "flat" in memo.lower()

    def test_zero_delta_delta_field(self):
        result = _make_wow_result(
            current_revenue=500_000.0,
            prior_revenue=500_000.0,
            current_means={"Meta": 80_000.0, "Google Search": 60_000.0, "TikTok": 30_000.0},
            prior_means={"Meta": 80_000.0, "Google Search": 60_000.0, "TikTok": 30_000.0},
            current_spend={"Meta": 18_000.0, "Google Search": 15_000.0, "TikTok": 7_500.0},
            prior_spend={"Meta": 18_000.0, "Google Search": 15_000.0, "TikTok": 7_500.0},
        )
        assert result["delta"] == pytest.approx(0.0, abs=1)

    def test_zero_delta_decomp_table_still_renders(self):
        result = _make_wow_result(
            current_revenue=500_000.0,
            prior_revenue=500_000.0,
            current_means={"Meta": 80_000.0, "Google Search": 60_000.0, "TikTok": 30_000.0},
            prior_means={"Meta": 80_000.0, "Google Search": 60_000.0, "TikTok": 30_000.0},
            current_spend={"Meta": 18_000.0, "Google Search": 15_000.0, "TikTok": 7_500.0},
            prior_spend={"Meta": 18_000.0, "Google Search": 15_000.0, "TikTok": 7_500.0},
        )
        memo = render_wow_memo(result)
        assert "Revenue delta" in memo


# ---------------------------------------------------------------------------
# Edge case 4: Channel with zero spend in one period
# ---------------------------------------------------------------------------


class TestZeroSpendChannel:
    def test_zero_spend_current_sets_flag(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 0.0},
            prior_means={"Meta": 50_000.0},
            current_spend={"Meta": 0.0},
            prior_spend={"Meta": 15_000.0},
            current_revenue=350_000.0,
            prior_revenue=400_000.0,
        )
        ch = result["channels"][0]
        assert ch.get("zero_spend_period") is True

    def test_zero_spend_prior_sets_flag(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 50_000.0},
            prior_means={"Meta": 0.0},
            current_spend={"Meta": 15_000.0},
            prior_spend={"Meta": 0.0},
            current_revenue=400_000.0,
            prior_revenue=350_000.0,
        )
        ch = result["channels"][0]
        assert ch.get("zero_spend_period") is True

    def test_zero_spend_efficiency_effect_is_zero(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 0.0},
            prior_means={"Meta": 50_000.0},
            current_spend={"Meta": 0.0},
            prior_spend={"Meta": 15_000.0},
            current_revenue=350_000.0,
            prior_revenue=400_000.0,
        )
        ch = result["channels"][0]
        assert ch["efficiency_effect"] == 0.0
        assert ch["spend_effect"] == 0.0

    def test_zero_spend_marginal_roas_none(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 0.0},
            prior_means={"Meta": 50_000.0},
            current_spend={"Meta": 0.0},
            prior_spend={"Meta": 15_000.0},
            current_revenue=350_000.0,
            prior_revenue=400_000.0,
        )
        ch = result["channels"][0]
        assert ch["marginal_roas_current"] is None

    def test_zero_spend_memo_renders_without_error(self):
        result = _make_wow_result(
            channels=["meta_spend"],
            current_means={"Meta": 0.0},
            prior_means={"Meta": 50_000.0},
            current_spend={"Meta": 0.0},
            prior_spend={"Meta": 15_000.0},
            current_revenue=350_000.0,
            prior_revenue=400_000.0,
        )
        memo = render_wow_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 50


# ---------------------------------------------------------------------------
# Edge case 5: Negative prior revenue (guard — tested at render level)
# ---------------------------------------------------------------------------


class TestNegativePriorRevenue:
    def test_build_result_does_not_error_on_negative_prior(self):
        """build_wow_result itself is not the guard — server.py is.
        We verify the builder still returns a dict so the server guard can work."""
        result = _make_wow_result(
            current_revenue=100_000.0,
            prior_revenue=-50_000.0,
        )
        # The server would reject this; the builder should still return a dict
        assert isinstance(result, dict)
        assert result["prior_revenue"] == pytest.approx(-50_000.0, abs=1)


# ---------------------------------------------------------------------------
# Edge case 6: Invalid period string
# ---------------------------------------------------------------------------


class TestInvalidPeriod:
    def test_invalid_period_not_in_valid_set(self):
        assert "last_week" not in VALID_PERIODS
        assert "monthly" not in VALID_PERIODS
        assert "ytd" not in VALID_PERIODS

    def test_valid_periods_all_present(self):
        for p in ("week", "4_weeks", "quarter"):
            assert p in VALID_PERIODS


# ---------------------------------------------------------------------------
# render_wow_memo — structure
# ---------------------------------------------------------------------------


class TestRenderWowMemoStructure:
    def test_returns_non_empty_string(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 100

    def test_delta_table_present(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        assert "Revenue delta" in memo

    def test_decomp_table_present(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        assert "efficiency" in memo.lower()

    def test_baseline_row_present(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        assert "Baseline" in memo

    def test_paid_row_present(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        assert "Paid" in memo

    def test_all_channels_in_memo(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        for name in ["Meta", "Google Search", "TikTok"]:
            assert name in memo

    def test_footer_present(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        assert "Posterior" in memo or "Data window" in memo

    def test_scaling_note_present(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        assert "proportionally scaled" in memo

    def test_no_emojis(self):
        result = _make_wow_result()
        memo = render_wow_memo(result)
        emoji_pattern = re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(memo), "Emoji found in memo"

    def test_returns_empty_string_on_empty_result(self):
        memo = render_wow_memo({})
        assert memo == ""

    def test_never_raises_on_malformed_input(self):
        memo = render_wow_memo({"channels": None})
        assert isinstance(memo, str)

    def test_verdict_headline_present(self):
        result = _make_wow_result(current_revenue=480_000.0, prior_revenue=510_000.0)
        memo = render_wow_memo(result)
        assert "Revenue" in memo and "down" in memo

    def test_up_verdict_for_positive_delta(self):
        result = _make_wow_result(
            current_revenue=530_000.0,
            prior_revenue=510_000.0,
            current_means={"Meta": 100_000.0, "Google Search": 60_000.0, "TikTok": 35_000.0},
            prior_means={"Meta": 80_000.0, "Google Search": 58_000.0, "TikTok": 32_000.0},
        )
        memo = render_wow_memo(result)
        assert "up" in memo.lower()


# ---------------------------------------------------------------------------
# Memo length constraint (<= 2500 tokens)
# ---------------------------------------------------------------------------


class TestMemoTokenLength:
    def test_8_channel_memo_under_2500_tokens(self):
        """8-channel WoW memo must stay under 2500 tokens."""
        channels = [
            "meta_spend",
            "google_search_spend",
            "tiktok_spend",
            "email_spend",
            "youtube_spend",
            "bing_spend",
            "pinterest_spend",
            "snapchat_spend",
        ]
        curr_means = {
            "Meta": 80_000.0,
            "Google Search": 60_000.0,
            "TikTok": 30_000.0,
            "Email": 15_000.0,
            "Youtube": 20_000.0,
            "Bing": 10_000.0,
            "Pinterest": 8_000.0,
            "Snapchat": 5_000.0,
        }
        prior_means = {k: v * 1.05 for k, v in curr_means.items()}
        curr_spend = {
            "Meta": 18_000.0,
            "Google Search": 15_000.0,
            "TikTok": 7_500.0,
            "Email": 2_500.0,
            "Youtube": 5_000.0,
            "Bing": 2_000.0,
            "Pinterest": 1_500.0,
            "Snapchat": 1_000.0,
        }
        prior_spend = {k: v * 0.95 for k, v in curr_spend.items()}
        result = build_wow_result(
            period="week",
            period_label="Last week (2026-04-07 to 2026-04-14) vs prior (2026-03-31 to 2026-04-06)",
            data_window=_DEFAULT_DATA_WINDOW,
            current_revenue=480_000.0,
            prior_revenue=510_000.0,
            current_means=curr_means,
            prior_means=prior_means,
            current_spend=curr_spend,
            prior_spend=prior_spend,
            channel_columns=channels,
            mcmc_config=_DEFAULT_MCMC_CONFIG,
        )
        memo = render_wow_memo(result)
        estimated_tokens = len(memo) / 4
        assert estimated_tokens <= 2500, (
            f"Memo is too long: ~{estimated_tokens:.0f} estimated tokens "
            f"(limit 2500). Actual chars: {len(memo)}"
        )


# ---------------------------------------------------------------------------
# Snapshot test
# ---------------------------------------------------------------------------


def _make_snapshot_result() -> dict:
    """Canonical 3-channel mock result for snapshot testing (mirrors demo_e2e scenario)."""
    channels = ["meta_spend", "google_search_spend", "tiktok_spend"]
    current_means = {
        "Meta": 80_000.0,
        "Google Search": 60_000.0,
        "TikTok": 30_000.0,
    }
    prior_means = {
        "Meta": 92_000.0,
        "Google Search": 58_000.0,
        "TikTok": 35_000.0,
    }
    current_spend = {
        "Meta": 18_070.0,
        "Google Search": 15_000.0,
        "TikTok": 7_500.0,
    }
    prior_spend = {
        "Meta": 16_500.0,
        "Google Search": 14_000.0,
        "TikTok": 8_000.0,
    }
    return build_wow_result(
        period="week",
        period_label=("Last week (2026-04-07 to 2026-04-14) vs prior (2026-03-31 to 2026-04-06)"),
        data_window="2025-10-06 to 2026-04-14 (27 weeks)",
        current_revenue=480_000.0,
        prior_revenue=510_000.0,
        current_means=current_means,
        prior_means=prior_means,
        current_spend=current_spend,
        prior_spend=prior_spend,
        channel_columns=channels,
        mcmc_config={"chains": 4, "draws": 250, "target_accept": 0.90},
    )


_SNAPSHOT_PATH = pathlib.Path(__file__).parent.parent / "snapshots" / "wow_memo__demo_e2e.md"


class TestSnapshot:
    def test_snapshot_matches_committed(self):
        """Rendered memo must exactly match the committed snapshot.

        To regenerate after intentional changes:
            UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_wow_memo.py
        """
        result = _make_snapshot_result()
        rendered_memo = render_wow_memo(result)

        if os.environ.get("UPDATE_SNAPSHOTS") == "1":
            _SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _SNAPSHOT_PATH.write_text(rendered_memo)
            return  # regenerated — no assertion needed

        snapshot_text = _SNAPSHOT_PATH.read_text()
        assert rendered_memo == snapshot_text, (
            "Snapshot mismatch. To update: "
            "UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_wow_memo.py"
        )

    def test_all_3_channels_in_snapshot(self):
        result = _make_snapshot_result()
        memo = render_wow_memo(result)
        for name in ["Meta", "Google Search", "TikTok"]:
            assert name in memo

    def test_delta_table_sorted_abs_delta_descending(self):
        """Channels in delta table should appear in abs(delta) desc order."""
        result = _make_snapshot_result()
        memo = render_wow_memo(result)

        table_start = memo.find("### Revenue delta")
        assert table_start != -1
        table_section = memo[table_start:]

        # Extract per-channel delta values from tree-prefix rows
        abs_deltas: list[float] = []
        for line in table_section.splitlines():
            if "\u251c " in line or "\u2514 " in line:
                # Extract dollar amounts — find all $NNN,NNN patterns
                matches = re.findall(r"\$([0-9,]+)", line)
                if matches:
                    # The delta column is the third dollar amount (or we look for signed)
                    # Just grab the first absolute value found for ordering check
                    val = float(matches[0].replace(",", ""))
                    abs_deltas.append(val)

        # We have at least 2 channel rows to compare
        assert len(abs_deltas) >= 2
