"""Unit tests for mixlift_mcp.renderers.saturation_memo.

All tests feed pre-computed synthetic dicts to the renderer.
No PyMC-Marketing model is ever fitted.
"""

from __future__ import annotations

import os
import pathlib
import re
from typing import Any

import pytest

from mixlift_mcp.renderers.saturation_memo import (
    _classify_status,
    _compute_if_decrease_returns,
    _compute_next_dollar_returns,
    _find_frontier_spend,
    _interpolate_response,
    build_channel_saturation,
    render_saturation_memo,
)

# ---------------------------------------------------------------------------
# Helpers: plausible saturation curves
# ---------------------------------------------------------------------------


def _logistic_curve(
    lam: float,
    beta: float,
    n_points: int = 100,
    max_spend: float = 40000.0,
) -> dict[str, list[float]]:
    """Generate a synthetic logistic saturation curve matching the engine's formula."""
    import math

    spend = [max_spend * i / (n_points - 1) for i in range(n_points)]
    response = []
    for s in spend:
        exp_val = math.exp(-lam * s)
        resp = beta * (1 - exp_val) / (1 + exp_val)
        response.append(resp)
    return {"spend": spend, "response": response}


def _make_channel(
    name: str = "meta_spend",
    current_spend_wk: float = 8000.0,
    lam: float = 0.00012,
    beta: float = 80000.0,
    marginal_roas_mean: float = 0.8,
    marginal_roas_ci: tuple[float, float] = (0.4, 1.3),
    increment_steps: list[int] | None = None,
    training_max_spend: float = 20000.0,
) -> dict[str, Any]:
    """Build a channel dict as produced by build_channel_saturation."""
    if increment_steps is None:
        increment_steps = [1000, 5000, 10000, 25000]
    curve = _logistic_curve(lam, beta, n_points=100, max_spend=training_max_spend * 2)
    return build_channel_saturation(
        channel_raw=name,
        current_spend_wk=current_spend_wk,
        curve=curve,
        marginal_roas_mean=marginal_roas_mean,
        marginal_roas_ci=marginal_roas_ci,
        increment_steps=increment_steps,
        training_max_spend=training_max_spend,
    )


def _make_result(channels: list[dict[str, Any]], skipped: list[str] | None = None) -> dict:
    """Assemble a saturation result dict for render_saturation_memo."""
    return {
        "tool": "mixlift_saturation",
        "version": "0.5.3",
        "mcmc_config": {"chains": 4, "draws": 250, "target_accept": 0.90},
        "data_window": "2025-04-14 to 2026-04-07 (51 weeks)",
        "channels": channels,
        "_skipped_channels": skipped or [],
    }


# ---------------------------------------------------------------------------
# _interpolate_response
# ---------------------------------------------------------------------------


class TestInterpolateResponse:
    def test_at_first_point(self):
        assert _interpolate_response([0.0, 100.0], [0.0, 50.0], 0.0) == 0.0

    def test_at_last_point(self):
        assert _interpolate_response([0.0, 100.0], [0.0, 50.0], 100.0) == 50.0

    def test_beyond_max_clamps_to_last(self):
        assert _interpolate_response([0.0, 100.0], [0.0, 50.0], 200.0) == 50.0

    def test_midpoint_linear_interpolation(self):
        result = _interpolate_response([0.0, 100.0], [0.0, 100.0], 50.0)
        assert abs(result - 50.0) < 1e-6

    def test_empty_returns_zero(self):
        assert _interpolate_response([], [], 50.0) == 0.0


# ---------------------------------------------------------------------------
# _classify_status
# ---------------------------------------------------------------------------


class TestClassifyStatus:
    def test_room_to_scale_below_50(self):
        assert _classify_status(30.0) == "room_to_scale"

    def test_approaching_at_50(self):
        assert _classify_status(50.0) == "approaching"

    def test_approaching_below_90(self):
        assert _classify_status(80.0) == "approaching"

    def test_at_frontier_at_90(self):
        assert _classify_status(90.0) == "at_frontier"

    def test_at_frontier_below_110(self):
        assert _classify_status(100.0) == "at_frontier"

    def test_over_saturated_at_110(self):
        assert _classify_status(110.0) == "over_saturated"

    def test_over_saturated_above_110(self):
        assert _classify_status(150.0) == "over_saturated"


# ---------------------------------------------------------------------------
# _find_frontier_spend
# ---------------------------------------------------------------------------


class TestFindFrontierSpend:
    def test_returns_none_when_never_crosses_one(self):
        # Steep curve — marginal always > 1
        spend = [0.0, 1.0, 2.0, 3.0]
        response = [0.0, 5.0, 8.0, 10.0]
        # marginal[1] = 5/1 = 5, [2] = 3, [3] = 2 — never < 1
        result = _find_frontier_spend(spend, response)
        assert result is None

    def test_finds_crossing_point(self):
        # Marginal drops below 1 at i=2: delta_response=0.5, delta_spend=1 → 0.5 < 1
        spend = [0.0, 1.0, 2.0, 3.0]
        response = [0.0, 3.0, 3.5, 3.8]
        result = _find_frontier_spend(spend, response)
        assert result is not None
        assert 1.0 <= result <= 2.0

    def test_returns_midpoint_of_crossing_segment(self):
        spend = [0.0, 10.0, 20.0]
        response = [0.0, 15.0, 15.5]
        # marginal[2] = 0.5/10 = 0.05 — crosses at segment [10, 20]
        result = _find_frontier_spend(spend, response)
        assert result == pytest.approx(15.0)


# ---------------------------------------------------------------------------
# _compute_next_dollar_returns
# ---------------------------------------------------------------------------


class TestComputeNextDollarReturns:
    def test_keys_match_steps(self):
        spend = [0.0, 5000.0, 10000.0, 20000.0]
        response = [0.0, 4000.0, 7000.0, 11000.0]
        result = _compute_next_dollar_returns(5000.0, spend, response, [1000, 5000])
        assert "1000" in result
        assert "5000" in result

    def test_roas_is_lift_over_step(self):
        spend = [0.0, 10000.0, 20000.0]
        response = [0.0, 10000.0, 15000.0]
        # At 5000 spend, response ≈ 5000. At 6000, response ≈ 6000.
        # Marginal over +1000: lift=1000, roas=1.0
        result = _compute_next_dollar_returns(5000.0, spend, response, [1000])
        assert abs(result["1000"]["roas"] - 1.0) < 0.1

    def test_all_values_are_rounded(self):
        spend = [0.0, 10000.0]
        response = [0.0, 9000.0]
        result = _compute_next_dollar_returns(0.0, spend, response, [1000])
        assert isinstance(result["1000"]["revenue_lift"], float)
        assert isinstance(result["1000"]["roas"], float)


# ---------------------------------------------------------------------------
# _compute_if_decrease_returns
# ---------------------------------------------------------------------------


class TestComputeIfDecreaseReturns:
    def test_keys_are_negative_strings(self):
        spend = [0.0, 10000.0, 20000.0]
        response = [0.0, 8000.0, 14000.0]
        result = _compute_if_decrease_returns(10000.0, spend, response, [1000, 5000])
        assert "-1000" in result
        assert "-5000" in result

    def test_cost_of_cut_is_non_positive(self):
        spend = [0.0, 10000.0, 20000.0]
        response = [0.0, 8000.0, 14000.0]
        result = _compute_if_decrease_returns(10000.0, spend, response, [1000])
        assert result["-1000"]["cost_of_cut"] <= 0


class TestIfDecreaseReturnsAlwaysBothKeys:
    """Item 4: if_decrease_returns must always include -1000 and -5000."""

    def test_both_keys_present_when_spend_exceeds_steps(self):
        ch = _make_channel(current_spend_wk=8000.0, increment_steps=[1000, 5000])
        idr = ch["if_decrease_returns"]
        assert "-1000" in idr
        assert "-5000" in idr

    def test_both_keys_present_when_spend_below_5k(self):
        ch = _make_channel(current_spend_wk=3000.0, increment_steps=[1000, 5000])
        idr = ch["if_decrease_returns"]
        assert "-1000" in idr
        assert "-5000" in idr
        # $1k cut is feasible
        assert idr["-1000"]["not_applicable"] is False
        # $5k cut exceeds spend → not_applicable
        assert idr["-5000"]["not_applicable"] is True
        assert idr["-5000"]["revenue_kept"] is None

    def test_feasible_entries_have_not_applicable_false(self):
        ch = _make_channel(current_spend_wk=8000.0, increment_steps=[1000, 5000])
        idr = ch["if_decrease_returns"]
        assert idr["-1000"]["not_applicable"] is False
        assert idr["-5000"]["not_applicable"] is False


# ---------------------------------------------------------------------------
# build_channel_saturation
# ---------------------------------------------------------------------------


class TestBuildChannelSaturation:
    def test_output_keys_match_spec(self):
        ch = _make_channel()
        required_keys = {
            "name",
            "current_spend_wk",
            "saturation_pct",
            "status",
            "marginal_roas_current",
            "marginal_roas_ci",
            "efficient_frontier_spend",
            "next_dollar_returns",
            "if_decrease_returns",
            "curve_points",
            "extrapolated",
            "extrapolated_frontier",
            "low_confidence",
        }
        assert required_keys == set(ch.keys())

    def test_marginal_roas_ci_is_list_of_two(self):
        ch = _make_channel(marginal_roas_ci=(0.3, 1.1))
        assert len(ch["marginal_roas_ci"]) == 2
        assert ch["marginal_roas_ci"][0] == pytest.approx(0.3, abs=0.01)
        assert ch["marginal_roas_ci"][1] == pytest.approx(1.1, abs=0.01)

    def test_marginal_roas_current_matches_input(self):
        ch = _make_channel(marginal_roas_mean=1.42)
        assert ch["marginal_roas_current"] == pytest.approx(1.42, abs=0.01)

    def test_status_four_bins(self):
        statuses = {
            _make_channel(current_spend_wk=500.0)["status"],
            _make_channel(current_spend_wk=8000.0)["status"],
        }
        valid = {"room_to_scale", "approaching", "at_frontier", "over_saturated"}
        assert statuses.issubset(valid)

    def test_low_spend_flags_low_confidence(self):
        ch = _make_channel(current_spend_wk=50.0)
        assert ch["low_confidence"] is True

    def test_normal_spend_not_low_confidence(self):
        ch = _make_channel(current_spend_wk=5000.0)
        assert ch["low_confidence"] is False

    def test_extrapolated_flag_when_over_training_max(self):
        ch = _make_channel(
            current_spend_wk=25000.0,
            training_max_spend=10000.0,
        )
        assert ch["extrapolated"] is True

    def test_not_extrapolated_within_training(self):
        ch = _make_channel(
            current_spend_wk=5000.0,
            training_max_spend=10000.0,
        )
        assert ch["extrapolated"] is False

    def test_next_dollar_returns_keys_match_steps(self):
        ch = _make_channel(increment_steps=[1000, 5000])
        assert set(ch["next_dollar_returns"].keys()) == {"1000", "5000"}

    def test_curve_points_is_list_of_dicts(self):
        ch = _make_channel()
        assert isinstance(ch["curve_points"], list)
        assert len(ch["curve_points"]) > 0
        assert "spend" in ch["curve_points"][0]
        assert "response" in ch["curve_points"][0]

    def test_curve_points_capped_even_if_engine_returns_beyond_2x(self):
        """If the engine provides points at 3× training_max, renderer must cap at 2×."""
        training_max = 10000.0
        cap = training_max * 2
        # Build a curve that extends well past 2× training_max
        over_cap = cap * 1.5  # 3× training_max
        spend = [float(i * 500) for i in range(int(over_cap / 500) + 1)]
        import math

        lam, beta = 0.00012, 80000.0
        response = [beta * (1 - math.exp(-lam * s)) / (1 + math.exp(-lam * s)) for s in spend]
        curve = {"spend": spend, "response": response}
        ch = build_channel_saturation(
            channel_raw="meta_spend",
            current_spend_wk=5000.0,
            curve=curve,
            marginal_roas_mean=1.2,
            marginal_roas_ci=(0.8, 1.6),
            increment_steps=[1000, 5000],
            training_max_spend=training_max,
        )
        max_curve_spend = max(p["spend"] for p in ch["curve_points"])
        assert max_curve_spend <= cap + 1, f"Curve not capped: max={max_curve_spend} cap={cap}"

    def test_extrapolated_frontier_true_when_mroas_never_crosses_one(self):
        """extrapolated_frontier=True for channels whose MROAS never drops below 1.0×."""
        # A very steep curve where MROAS stays > 1 throughout training range
        training_max = 10000.0
        spend = [0.0, 20000.0]  # only 2 points, steep
        response = [0.0, 30000.0]  # MROAS = 1.5 throughout — never crosses 1.0
        ch = build_channel_saturation(
            channel_raw="meta_spend",
            current_spend_wk=5000.0,
            curve={"spend": spend, "response": response},
            marginal_roas_mean=1.5,
            marginal_roas_ci=(1.0, 2.0),
            increment_steps=[1000],
            training_max_spend=training_max,
        )
        assert ch["extrapolated_frontier"] is True

    def test_extrapolated_frontier_false_when_mroas_crosses_one(self):
        """extrapolated_frontier=False for channels where a real frontier is interpolated."""
        spend = [0.0, 1000.0, 2000.0, 5000.0]
        response = [0.0, 3000.0, 3500.0, 3600.0]  # marginal drops below 1 quickly
        ch = build_channel_saturation(
            channel_raw="meta_spend",
            current_spend_wk=500.0,
            curve={"spend": spend, "response": response},
            marginal_roas_mean=0.5,
            marginal_roas_ci=(0.2, 0.9),
            increment_steps=[1000],
            training_max_spend=5000.0,
        )
        assert ch["extrapolated_frontier"] is False

    def test_if_decrease_returns_marks_not_applicable_for_oversize_cut(self):
        ch = _make_channel(current_spend_wk=500.0, increment_steps=[1000, 5000])
        idr = ch["if_decrease_returns"]
        # Both keys must always be present
        assert "-1000" in idr
        assert "-5000" in idr
        # Both steps exceed current spend → not_applicable=True, numeric fields None
        assert idr["-1000"]["not_applicable"] is True
        assert idr["-1000"]["revenue_kept"] is None
        assert idr["-1000"]["cost_of_cut"] is None
        assert idr["-5000"]["not_applicable"] is True
        assert idr["-5000"]["revenue_kept"] is None
        assert idr["-5000"]["cost_of_cut"] is None


# ---------------------------------------------------------------------------
# render_saturation_memo — structure
# ---------------------------------------------------------------------------


class TestRenderSaturationMemoStructure:
    def test_returns_non_empty_string_for_valid_input(self):
        ch = _make_channel("meta_spend", current_spend_wk=18000.0, marginal_roas_mean=0.42)
        result = _make_result([ch])
        memo = render_saturation_memo(result)
        assert isinstance(memo, str)
        assert len(memo) > 100

    def test_h2_heading_present(self):
        ch = _make_channel()
        memo = render_saturation_memo(_make_result([ch]))
        assert "## Where each channel sits on its curve" in memo

    def test_comparison_table_present_for_multi_channel(self):
        chs = [
            _make_channel("meta_spend", current_spend_wk=18000.0),
            _make_channel("google_search_spend", current_spend_wk=5000.0),
        ]
        memo = render_saturation_memo(_make_result(chs))
        assert "### By channel" in memo

    def test_comparison_table_absent_for_single_channel(self):
        ch = _make_channel("meta_spend", current_spend_wk=5000.0)
        memo = render_saturation_memo(_make_result([ch]))
        # Edge case 1: single channel → no comparison table
        assert "### By channel" not in memo

    def test_per_channel_section_present(self):
        ch = _make_channel("meta_spend", current_spend_wk=10000.0)
        memo = render_saturation_memo(_make_result([ch]))
        # Display name should appear as a section header
        assert "### Meta" in memo

    def test_no_emojis(self):
        chs = [_make_channel("meta_spend"), _make_channel("google_search_spend")]
        memo = render_saturation_memo(_make_result(chs))
        emoji_pattern = re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(memo), "Emoji found in memo"

    def test_footer_present(self):
        ch = _make_channel()
        memo = render_saturation_memo(_make_result([ch]))
        assert "*" in memo  # italic footer

    def test_returns_empty_string_on_empty_result(self):
        memo = render_saturation_memo({})
        assert memo == ""

    def test_never_raises_on_malformed_input(self):
        # Should silently return "" rather than raising
        memo = render_saturation_memo({"channels": None})
        assert isinstance(memo, str)


# ---------------------------------------------------------------------------
# Edge case 1: single channel
# ---------------------------------------------------------------------------


class TestSingleChannelEdgeCase:
    def test_memo_renders_without_comparison_table(self):
        ch = _make_channel("meta_spend", current_spend_wk=8000.0)
        memo = render_saturation_memo(_make_result([ch]))
        assert memo != ""
        assert "### By channel" not in memo
        assert "### Meta" in memo

    def test_per_channel_section_has_increment_table(self):
        ch = _make_channel("meta_spend", current_spend_wk=15000.0)
        memo = render_saturation_memo(_make_result([ch]))
        assert "If you add" in memo


# ---------------------------------------------------------------------------
# Edge case 2: zero-spend channel
# ---------------------------------------------------------------------------


class TestZeroSpendChannel:
    def test_zero_spend_omitted_from_comparison_table(self):
        active = _make_channel("meta_spend", current_spend_wk=8000.0)
        zero = _make_channel("tiktok_spend", current_spend_wk=0.0)
        memo = render_saturation_memo(_make_result([active, zero]))
        # TikTok should appear in footnote, not in the per-channel H3
        assert "### TikTok" not in memo

    def test_zero_spend_noted_in_footnote(self):
        active = _make_channel("meta_spend", current_spend_wk=8000.0)
        zero = _make_channel("tiktok_spend", current_spend_wk=0.0)
        memo = render_saturation_memo(_make_result([active, zero]))
        assert "zero spend" in memo.lower()

    def test_zero_spend_channel_in_structured_output(self):
        zero = _make_channel("tiktok_spend", current_spend_wk=0.0)
        ch_dict = zero
        # curve_points must still be present in structured output
        assert len(ch_dict["curve_points"]) > 0


# ---------------------------------------------------------------------------
# Edge case 3: very-low-spend channel (<$100/wk)
# ---------------------------------------------------------------------------


class TestLowConfidenceChannel:
    def test_low_confidence_flag_set(self):
        ch = _make_channel("email_spend", current_spend_wk=50.0)
        assert ch["low_confidence"] is True

    def test_low_confidence_marker_in_memo(self):
        ch = _make_channel("email_spend", current_spend_wk=50.0)
        memo = render_saturation_memo(_make_result([ch]))
        # Low confidence footnote should mention the channel
        assert "Email" in memo
        assert "low" in memo.lower() or "confidence" in memo.lower()


# ---------------------------------------------------------------------------
# Edge case 4: channel at max of training spend (extrapolated)
# ---------------------------------------------------------------------------


class TestExtrapolatedChannel:
    def test_extrapolated_flag_set_above_training_max(self):
        ch = _make_channel(
            "google_search_spend",
            current_spend_wk=25000.0,
            training_max_spend=10000.0,
        )
        assert ch["extrapolated"] is True

    def test_extrapolated_footnote_in_memo(self):
        ch = _make_channel(
            "google_search_spend",
            current_spend_wk=25000.0,
            training_max_spend=10000.0,
        )
        memo = render_saturation_memo(_make_result([ch]))
        assert "extrapolated" in memo.lower() or "directional" in memo.lower()

    def test_curve_points_capped_at_2x_training_max(self):
        training_max = 10000.0
        ch = _make_channel(
            training_max_spend=training_max,
            current_spend_wk=5000.0,
        )
        max_curve_spend = max(p["spend"] for p in ch["curve_points"])
        assert max_curve_spend <= training_max * 2 + 1  # +1 for float rounding


# ---------------------------------------------------------------------------
# Edge case 5: unknown channel in filter → warn-and-skip
# ---------------------------------------------------------------------------


class TestSkippedChannels:
    def test_skipped_channels_in_footnote(self):
        ch = _make_channel("meta_spend", current_spend_wk=8000.0)
        result = _make_result([ch], skipped=["podcast_spend"])
        memo = render_saturation_memo(result)
        assert "podcast_spend" in memo or "not found" in memo.lower()


# ---------------------------------------------------------------------------
# Marginal ROAS tie-out
# ---------------------------------------------------------------------------


class TestMarginalRoasTieOut:
    def test_marginal_roas_current_matches_extractor_output(self):
        """The channel dict's marginal_roas_current must equal what extract_marginal_roas
        returned. We simulate the extractor here with a known value."""
        extractor_mean = 1.37
        ch = _make_channel(marginal_roas_mean=extractor_mean)
        assert ch["marginal_roas_current"] == pytest.approx(extractor_mean, abs=0.01)

    def test_marginal_roas_ci_bounds_match_extractor(self):
        lo, hi = 0.71, 2.14
        ch = _make_channel(marginal_roas_ci=(lo, hi))
        assert ch["marginal_roas_ci"][0] == pytest.approx(lo, abs=0.01)
        assert ch["marginal_roas_ci"][1] == pytest.approx(hi, abs=0.01)


# ---------------------------------------------------------------------------
# Memo length constraint (<= 2500 tokens)
# ---------------------------------------------------------------------------


class TestMemoTokenLength:
    def test_8_channel_memo_under_2500_tokens(self):
        """Mock-driven 8-channel scenario must stay under 2500 tokens."""
        channels = [
            _make_channel("meta_spend", current_spend_wk=18000.0, marginal_roas_mean=0.42),
            _make_channel("google_search_spend", current_spend_wk=5000.0, marginal_roas_mean=1.85),
            _make_channel("tiktok_spend", current_spend_wk=3000.0, marginal_roas_mean=2.10),
            _make_channel("email_spend", current_spend_wk=800.0, marginal_roas_mean=2.84),
            _make_channel("youtube_spend", current_spend_wk=4500.0, marginal_roas_mean=1.20),
            _make_channel("bing_spend", current_spend_wk=2000.0, marginal_roas_mean=1.55),
            _make_channel("pinterest_spend", current_spend_wk=1200.0, marginal_roas_mean=1.90),
            _make_channel("snapchat_spend", current_spend_wk=600.0, marginal_roas_mean=2.30),
        ]
        memo = render_saturation_memo(_make_result(channels))
        # Crude token estimate: ~4 chars per token
        estimated_tokens = len(memo) / 4
        assert estimated_tokens <= 2500, (
            f"Memo is too long: ~{estimated_tokens:.0f} estimated tokens "
            f"(limit 2500). Actual chars: {len(memo)}"
        )


# ---------------------------------------------------------------------------
# Snapshot test (8-channel mock-driven)
# ---------------------------------------------------------------------------


def _make_8ch_result() -> dict:
    """Canonical 8-channel mock result for snapshot testing."""
    channels = [
        _make_channel(
            "meta_prospecting_spend",
            current_spend_wk=18070.0,
            marginal_roas_mean=0.42,
            marginal_roas_ci=(0.18, 0.71),
            lam=0.0001,
            beta=90000.0,
            training_max_spend=25000.0,
        ),
        _make_channel(
            "google_search_spend",
            current_spend_wk=5000.0,
            marginal_roas_mean=1.85,
            marginal_roas_ci=(1.20, 2.60),
            lam=0.00008,
            beta=70000.0,
            training_max_spend=15000.0,
        ),
        _make_channel(
            "tiktok_spend",
            current_spend_wk=3000.0,
            marginal_roas_mean=2.10,
            marginal_roas_ci=(1.40, 2.90),
            lam=0.00015,
            beta=60000.0,
            training_max_spend=10000.0,
        ),
        _make_channel(
            "email_spend",
            current_spend_wk=800.0,
            marginal_roas_mean=2.84,
            marginal_roas_ci=(1.90, 3.90),
            lam=0.0002,
            beta=50000.0,
            training_max_spend=8000.0,
        ),
        _make_channel(
            "youtube_spend",
            current_spend_wk=4500.0,
            marginal_roas_mean=1.20,
            marginal_roas_ci=(0.80, 1.70),
            lam=0.00009,
            beta=65000.0,
            training_max_spend=12000.0,
        ),
        _make_channel(
            "bing_spend",
            current_spend_wk=2000.0,
            marginal_roas_mean=1.55,
            marginal_roas_ci=(1.00, 2.20),
            lam=0.00012,
            beta=55000.0,
            training_max_spend=8000.0,
        ),
        _make_channel(
            "pinterest_spend",
            current_spend_wk=1200.0,
            marginal_roas_mean=1.90,
            marginal_roas_ci=(1.20, 2.70),
            lam=0.00018,
            beta=45000.0,
            training_max_spend=6000.0,
        ),
        _make_channel(
            "snapchat_spend",
            current_spend_wk=600.0,
            marginal_roas_mean=2.30,
            marginal_roas_ci=(1.50, 3.20),
            lam=0.00025,
            beta=40000.0,
            training_max_spend=5000.0,
        ),
    ]
    return _make_result(
        channels,
        skipped=[],
    )


_SNAPSHOT_PATH = pathlib.Path(__file__).parent.parent / "snapshots" / "saturation_memo__demo_e2e.md"


class TestSnapshot:
    def test_snapshot_matches_committed(self):
        """Rendered memo must exactly match the committed snapshot.

        To regenerate after intentional changes:
            UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_saturation_memo.py
        """
        result = _make_8ch_result()
        rendered_memo = render_saturation_memo(result)

        if os.environ.get("UPDATE_SNAPSHOTS") == "1":
            _SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _SNAPSHOT_PATH.write_text(rendered_memo)
            return  # regenerated — no assertion needed

        snapshot_text = _SNAPSHOT_PATH.read_text()
        assert rendered_memo == snapshot_text, (
            "Snapshot mismatch. To update: "
            "UPDATE_SNAPSHOTS=1 pytest tests/test_renderers/test_saturation_memo.py"
        )

    def test_all_8_channels_renderable(self):
        """All 8 channels in demo_e2e.csv scenario must appear in memo."""
        result = _make_8ch_result()
        memo = render_saturation_memo(result)
        expected_names = [
            "Meta Prospecting",
            "Google Search",
            "TikTok",
            "Email",
            "Youtube",
            "Bing",
            "Pinterest",
            "Snapchat",
        ]
        for name in expected_names:
            assert name in memo, f"Channel '{name}' not found in memo"

    def test_comparison_table_sorted_saturation_descending(self):
        """Comparison table must list channels from highest to lowest saturation."""
        result = _make_8ch_result()
        memo = render_saturation_memo(result)
        table_start = memo.find("### By channel")
        assert table_start != -1
        table_section = memo[table_start:]
        # Find the lines that have saturation percentages
        sat_pcts: list[float] = []
        for line in table_section.splitlines():
            if "|" in line and "%" in line and "Saturation" not in line and "---" not in line:
                # Extract pct value
                parts = [p.strip() for p in line.split("|") if p.strip()]
                for part in parts:
                    if part.endswith("%"):
                        try:
                            sat_pcts.append(float(part.rstrip("%")))
                            break
                        except ValueError:
                            pass
        # Must be sorted descending
        assert len(sat_pcts) > 1
        for i in range(len(sat_pcts) - 1):
            assert sat_pcts[i] >= sat_pcts[i + 1], f"Saturation not sorted descending: {sat_pcts}"
