"""Tests for ProgressReporter and engine progress integration.

Five tests covering:
1. Happy path — reporter emits ordered messages through a mocked ctx.
2. ctx=None — engine runs identically, no error, no progress side-effects.
3. Thread safety — ProgressReporter.phase() called from a background thread
   successfully delivers notifications back to the asyncio event loop.
4. Throttling — 100 draws with throttle=25 emits exactly 4 notifications.
5. Error during sampling — reporter emits "Failed during..." before re-raise.
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from mixlift_mcp.progress import ProgressReporter  # noqa: E402

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_ctx() -> MagicMock:
    """Build a MagicMock ctx with a recording AsyncMock for report_progress."""
    ctx = MagicMock()
    ctx.report_progress = AsyncMock(return_value=None)
    return ctx


def _make_draw(chain: int, draw_idx: int, tuning: bool = False):
    """Minimal draw-like object matching PyMC's Draw namedtuple fields."""
    d = MagicMock()
    d.chain = chain
    d.draw_idx = draw_idx
    d.tuning = tuning
    d.is_last = False
    return d


# ---------------------------------------------------------------------------
# Test 1: Happy path — ordered phase messages via mocked ctx
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_progress_phases_emitted_in_order():
    """Phase messages emitted in the expected order during a full pipeline run."""
    ctx = _make_mock_ctx()
    loop = asyncio.get_running_loop()
    reporter = ProgressReporter(ctx, loop)

    phases = [
        "Building Bayesian model",
        "Compiling model (JIT)",
        "Computing posterior estimates",
        "Done",
    ]
    for i, phase in enumerate(phases):
        reporter.phase(phase, progress=float(i + 1), total=float(len(phases)))

    # Give scheduled coroutines a tick to run
    await asyncio.sleep(0)

    assert ctx.report_progress.call_count == len(phases)
    messages = [call.kwargs["message"] for call in ctx.report_progress.call_args_list]
    assert messages == phases


# ---------------------------------------------------------------------------
# Test 2: ctx=None — engine runs, no errors, no progress side-effects
# ---------------------------------------------------------------------------


def test_reporter_none_ctx_is_noop():
    """When ctx is None, all phase() calls are no-ops (backward compat)."""
    reporter = ProgressReporter(ctx=None, loop=None)
    # Should not raise, should not call anything
    reporter.phase("Building model", progress=1, total=8)
    reporter.phase("Sampling chain 1/4 (draw 25/250)", progress=25, total=250)
    reporter.phase("Done")


def test_run_full_pipeline_no_reporter_unchanged():
    """run_full_pipeline with reporter=None runs identically to before."""
    import numpy as np
    import pandas as pd

    from mixlift.modeling.engine import run_full_pipeline

    rng = np.random.default_rng(0)
    n = 20
    dates = pd.date_range("2023-01-01", periods=n, freq="W-MON")
    X = pd.DataFrame({
        "date": dates,
        "ch_a": rng.uniform(100, 500, n),
    })
    y = pd.Series(rng.uniform(1000, 5000, n), name="y")

    fast_cfg = {"chains": 1, "tune": 10, "draws": 10, "target_accept": 0.8}

    # reporter=None is the default — should work with no progress side-effects
    result = run_full_pipeline(
        X, y, ["ch_a"], mcmc_config=fast_cfg, reporter=None
    )
    assert "ch_a" in result.channel_contributions or "Ch A" in result.channel_contributions


# ---------------------------------------------------------------------------
# Test 3: Thread safety — phase() from background thread reaches the loop
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_reporter_phase_from_background_thread():
    """phase() called from asyncio.to_thread delivers notification to the loop."""
    ctx = _make_mock_ctx()
    loop = asyncio.get_running_loop()
    reporter = ProgressReporter(ctx, loop)

    async def run_in_thread():
        await asyncio.to_thread(reporter.phase, "Sampling chain 1/4 (draw 25/250)", 25.0, 250.0)

    await run_in_thread()
    # Allow fire-and-forget future to complete
    await asyncio.sleep(0.05)

    assert ctx.report_progress.call_count == 1
    call_kwargs = ctx.report_progress.call_args.kwargs
    assert "Sampling chain 1/4" in call_kwargs["message"]
    assert call_kwargs["total"] == 250.0


# ---------------------------------------------------------------------------
# Test 4: Throttling — 100 draws at throttle=25 → exactly 4 notifications
# ---------------------------------------------------------------------------


def test_pymc_callback_throttling():
    """_make_pymc_callback emits exactly 4 messages for 100 draws at throttle=25."""
    from mixlift.modeling.engine import _make_pymc_callback

    received: list[str] = []

    class MockReporter:
        def phase(self, name: str, progress=None, total=None) -> None:
            received.append(name)

    r = MockReporter()
    cb = _make_pymc_callback(reporter=r, n_chains=2, n_draws=100, draw_throttle=25)

    # Simulate 100 production draws on chain 0
    for i in range(1, 101):
        draw = _make_draw(chain=0, draw_idx=i + 1000, tuning=False)
        cb(trace=None, draw=draw)

    # Expect notifications at draw 25, 50, 75, 100
    assert len(received) == 4
    # All messages should reference chain 1 (0-indexed chain 0 → display "1/2")
    assert all("chain 1/2" in msg for msg in received)
    assert "draw 25/100" in received[0]
    assert "draw 100/100" in received[3]


def test_pymc_callback_skips_tuning_draws():
    """Tuning draws must not count toward progress notifications."""
    from mixlift.modeling.engine import _make_pymc_callback

    received: list[str] = []

    class MockReporter:
        def phase(self, name: str, progress=None, total=None) -> None:
            received.append(name)

    r = MockReporter()
    cb = _make_pymc_callback(reporter=r, n_chains=1, n_draws=10, draw_throttle=5)

    # Send 20 tuning draws — should produce zero notifications
    for i in range(20):
        draw = _make_draw(chain=0, draw_idx=i, tuning=True)
        cb(trace=None, draw=draw)

    assert received == []

    # Send 10 production draws — should produce 2 notifications (at 5 and 10)
    for i in range(1, 11):
        draw = _make_draw(chain=0, draw_idx=1000 + i, tuning=False)
        cb(trace=None, draw=draw)

    assert len(received) == 2


# ---------------------------------------------------------------------------
# Test 5: Error during sampling → "Failed during..." emitted before re-raise
# ---------------------------------------------------------------------------


def test_run_full_pipeline_emits_failure_phase_on_error():
    """If fit_model raises, run_full_pipeline reports failure before propagating."""
    import numpy as np
    import pandas as pd

    from mixlift.modeling.engine import run_full_pipeline

    received: list[str] = []

    class RecordingReporter:
        def phase(self, name: str, progress=None, total=None) -> None:
            received.append(name)

    rng = np.random.default_rng(1)
    n = 10
    dates = pd.date_range("2023-01-01", periods=n, freq="W-MON")
    X = pd.DataFrame({"date": dates, "ch_a": rng.uniform(100, 500, n)})
    y = pd.Series(rng.uniform(1000, 5000, n), name="y")

    reporter = RecordingReporter()

    with patch("mixlift.modeling.engine.fit_model", side_effect=RuntimeError("boom")):
        with pytest.raises(RuntimeError, match="boom"):
            run_full_pipeline(X, y, ["ch_a"], reporter=reporter)

    failure_phases = [p for p in received if "Failed" in p]
    assert failure_phases, f"Expected a 'Failed' phase, got: {received}"
    assert "MCMC" in failure_phases[0] or "sampling" in failure_phases[0].lower()


# ---------------------------------------------------------------------------
# Tests 6-11: New phase emissions wired in server.py
# ---------------------------------------------------------------------------


class _MockReporter:
    """Lightweight sync reporter that records phase calls for assertions."""

    def __init__(self) -> None:
        self.phases: list[tuple[str, float | None, float | None]] = []

    def phase(self, name: str, progress: float | None = None, total: float | None = None) -> None:
        self.phases.append((name, progress, total))

    def phase_names(self) -> list[str]:
        return [p[0] for p in self.phases]


# ---------------------------------------------------------------------------
# Test 6: CSV validation phase
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_phase_emitted_for_csv_validation():
    """mixlift_analyze emits a phase containing 'Validating' or 'CSV' before format detect."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from mixlift_mcp.server import mixlift_analyze

    mock_results = MagicMock()
    mock_results.roas_estimates = {"ch_a": 2.5}
    mock_results.roas_ci = {"ch_a": (1.5, 3.5)}
    mock_results.channel_contributions = {"ch_a": 50000.0}
    mock_results.channel_contributions_ci = {"ch_a": (40000.0, 60000.0)}
    mock_results.total_spend = {"ch_a": 20000.0}
    mock_results.duration_secs = 5.0
    mock_results.mmm = MagicMock()
    mock_results.marginal_roas_estimates = {"ch_a": 2.2}
    mock_results.marginal_roas_ci = {"ch_a": (1.2, 3.2)}
    mock_results.convergence_warnings = []
    mock_results.raw_contributions = None

    reporter = _MockReporter()

    _noop_opt = {
        "current_allocation": {}, "optimal_allocation": {},
        "total_budget": 0, "expected_lift_pct": 0,
    }
    with (
        patch("mixlift_mcp.server._resolve_license", new_callable=AsyncMock) as mock_lic,
        patch("mixlift_mcp.server._run_pipeline", return_value=mock_results),
        patch("mixlift_mcp.server._run_optimizer", return_value=_noop_opt),
        patch("mixlift_mcp.server._run_saturation", return_value={}),
        patch("mixlift_mcp.progress.ProgressReporter", return_value=reporter),
        patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
    ):
        from mixlift_mcp.license import LicenseStatus
        mock_lic.return_value = LicenseStatus(
            is_pro=True, max_channels=999, max_rows=999_999, message="Pro"
        )
        await mixlift_analyze(csv_path="", license_key="pro-key")

    csv_phases = [n for n in reporter.phase_names() if "Validating" in n or "CSV" in n]
    assert csv_phases, f"Expected a CSV/Validating phase, got: {reporter.phase_names()}"


# ---------------------------------------------------------------------------
# Test 7: Preprocess phase
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_phase_emitted_for_preprocess():
    """mixlift_analyze emits a phase containing 'Preprocessing' or 'aggregation'."""
    from unittest.mock import AsyncMock, MagicMock, patch

    from mixlift_mcp.server import mixlift_analyze

    mock_results = MagicMock()
    mock_results.roas_estimates = {"ch_a": 2.5}
    mock_results.roas_ci = {"ch_a": (1.5, 3.5)}
    mock_results.channel_contributions = {"ch_a": 50000.0}
    mock_results.channel_contributions_ci = {"ch_a": (40000.0, 60000.0)}
    mock_results.total_spend = {"ch_a": 20000.0}
    mock_results.duration_secs = 5.0
    mock_results.mmm = MagicMock()
    mock_results.marginal_roas_estimates = {"ch_a": 2.2}
    mock_results.marginal_roas_ci = {"ch_a": (1.2, 3.2)}
    mock_results.convergence_warnings = []
    mock_results.raw_contributions = None

    reporter = _MockReporter()

    _noop_opt2 = {
        "current_allocation": {}, "optimal_allocation": {},
        "total_budget": 0, "expected_lift_pct": 0,
    }
    with (
        patch("mixlift_mcp.server._resolve_license", new_callable=AsyncMock) as mock_lic,
        patch("mixlift_mcp.server._run_pipeline", return_value=mock_results),
        patch("mixlift_mcp.server._run_optimizer", return_value=_noop_opt2),
        patch("mixlift_mcp.server._run_saturation", return_value={}),
        patch("mixlift_mcp.progress.ProgressReporter", return_value=reporter),
        patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
    ):
        from mixlift_mcp.license import LicenseStatus
        mock_lic.return_value = LicenseStatus(
            is_pro=True, max_channels=999, max_rows=999_999, message="Pro"
        )
        await mixlift_analyze(csv_path="", license_key="pro-key")

    pre_phases = [
        n for n in reporter.phase_names()
        if "Preprocessing" in n or "aggregation" in n
    ]
    assert pre_phases, f"Expected a Preprocessing phase, got: {reporter.phase_names()}"


# ---------------------------------------------------------------------------
# Test 8: Optimizer phase
# ---------------------------------------------------------------------------


def test_phase_emitted_for_optimizer():
    """_run_optimizer emits 'Optimizing budget allocation' phase when reporter is given."""
    from unittest.mock import MagicMock, patch

    from mixlift_mcp.server import _run_optimizer

    reporter = _MockReporter()

    _opt_ret = {
        "current_allocation": {}, "optimal_allocation": {},
        "total_budget": 0, "expected_lift_pct": 0,
    }
    with patch("mixlift_mcp.server._run_optimizer", wraps=_run_optimizer):
        with patch("mixlift.modeling.optimizer.optimize_budget", return_value=_opt_ret):
            _run_optimizer(MagicMock(), MagicMock(), [], reporter=reporter)

    opt_phases = [n for n in reporter.phase_names() if "Optimizing" in n]
    assert opt_phases, f"Expected an Optimizing phase, got: {reporter.phase_names()}"


# ---------------------------------------------------------------------------
# Test 9: Saturation phase
# ---------------------------------------------------------------------------


def test_phase_emitted_for_saturation():
    """_run_saturation emits 'Analyzing saturation curves' phase when reporter is given."""
    from unittest.mock import MagicMock, patch

    from mixlift_mcp.server import _run_saturation

    reporter = _MockReporter()

    with patch("mixlift.modeling.engine.extract_saturation_curves", return_value={}):
        _run_saturation(MagicMock(), MagicMock(), [], reporter=reporter)

    sat_phases = [n for n in reporter.phase_names() if "saturation" in n.lower()]
    assert sat_phases, f"Expected a saturation phase, got: {reporter.phase_names()}"


# ---------------------------------------------------------------------------
# Tests 10-11: is_cache_hit flag on fresh and cached paths
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_is_cache_hit_false_on_fresh_fit():
    """Fresh fit sets is_cache_hit=False in the result returned to the caller."""
    import json
    from unittest.mock import AsyncMock, MagicMock, patch

    from mixlift_mcp.server import mixlift_analyze

    mock_results = MagicMock()
    mock_results.roas_estimates = {"ch_a": 2.5}
    mock_results.roas_ci = {"ch_a": (1.5, 3.5)}
    mock_results.channel_contributions = {"ch_a": 50000.0}
    mock_results.channel_contributions_ci = {"ch_a": (40000.0, 60000.0)}
    mock_results.total_spend = {"ch_a": 20000.0}
    mock_results.duration_secs = 5.0
    mock_results.mmm = MagicMock()
    mock_results.marginal_roas_estimates = {"ch_a": 2.2}
    mock_results.marginal_roas_ci = {"ch_a": (1.2, 3.2)}
    mock_results.convergence_warnings = []
    mock_results.raw_contributions = None

    _noop_opt3 = {
        "current_allocation": {}, "optimal_allocation": {},
        "total_budget": 0, "expected_lift_pct": 0,
    }
    with (
        patch("mixlift_mcp.server._resolve_license", new_callable=AsyncMock) as mock_lic,
        patch("mixlift_mcp.server._run_pipeline", return_value=mock_results),
        patch("mixlift_mcp.server._run_optimizer", return_value=_noop_opt3),
        patch("mixlift_mcp.server._run_saturation", return_value={}),
        patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
        patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock, return_value=None),
    ):
        from mixlift_mcp.license import LicenseStatus
        mock_lic.return_value = LicenseStatus(
            is_pro=True, max_channels=999, max_rows=999_999, message="Pro"
        )
        raw = await mixlift_analyze(csv_path="", license_key="pro-key")

    data = json.loads(raw)
    assert data["summary"]["is_cache_hit"] is False


@pytest.mark.asyncio
async def test_is_cache_hit_true_on_cache_hit():
    """Cache-hit path sets is_cache_hit=True and cache_age_days in summary."""
    import json
    from datetime import datetime, timezone
    from unittest.mock import AsyncMock, MagicMock, patch

    from mixlift_mcp.server import mixlift_analyze

    # Build a fake disk cache entry
    created_at = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc).isoformat()
    fake_entry = {
        "mmm": MagicMock(),
        "X": MagicMock(),
        "channel_columns": ["ch_a"],
        "result": {
            "status": "success",
            "license": {"tier": "pro"},
            "headline": "Test headline",
            "data": {
                "format_detected": "wide", "channels": ["ch_a"], "n_channels": 1,
            },
            "roas": {
                "estimates": {"ch_a": 2.5},
                "confidence_intervals": {"ch_a": {"low": 1.5, "high": 3.5}},
            },
            "confidence_summary": {},
            "channel_contributions": {},
            "saturation_analysis": {},
            "budget_optimization": {
                "current_allocation": {}, "optimal_allocation": {},
                "total_budget": 0, "expected_lift_pct": 0,
            },
            "recommendations": {"summary": "", "actions": []},
            "marginal_roas": {"estimates": {}, "confidence_intervals": {}},
            "model_fit": {},
            "analysis_badge": None,
            "memory": None,
            "model_info": {"duration_secs": 5.0, "total_spend": {}, "data_window": {"weeks": 52}},
            "model_fingerprint": "test-fp",
        },
    }

    fake_meta = json.dumps({"created_at": created_at})

    mock_meta_path = MagicMock()
    mock_meta_path.read_text.return_value = fake_meta

    mock_entry_dir_result = MagicMock()
    mock_entry_dir_result.__truediv__ = MagicMock(return_value=mock_meta_path)

    with (
        patch("mixlift_mcp.server._resolve_license", new_callable=AsyncMock) as mock_lic,
        patch(
            "mixlift_mcp.model_cache.load_model",
            new_callable=AsyncMock,
            return_value=fake_entry,
        ),
        patch("mixlift_mcp.model_cache._entry_dir", return_value=mock_entry_dir_result),
    ):
        from mixlift_mcp.license import LicenseStatus
        mock_lic.return_value = LicenseStatus(
            is_pro=True, max_channels=999, max_rows=999_999, message="Pro"
        )
        raw = await mixlift_analyze(csv_path="", license_key="pro-key")

    data = json.loads(raw)
    assert data["summary"]["is_cache_hit"] is True
    assert "cache_age_days" in data["summary"]
