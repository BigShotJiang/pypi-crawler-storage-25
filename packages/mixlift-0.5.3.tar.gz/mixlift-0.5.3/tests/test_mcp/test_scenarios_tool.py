"""Tool-level integration tests for mixlift_scenarios.

All tests mock _run_pipeline, _run_multi_scenario, and _run_marginal_roas
so no actual MCMC fit is executed.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.license import LicenseStatus
from mixlift_mcp.server import mixlift_scenarios

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def wide_csv_3ch(tmp_path):
    """3-channel wide-format CSV, 30 weeks."""
    n = 30
    dates = pd.date_range("2025-04-07", periods=n, freq="W-MON")
    rng = np.random.default_rng(42)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n),
            "email_spend": rng.uniform(3000, 10000, n),
            "tiktok_spend": rng.uniform(1000, 5000, n),
            "revenue": rng.uniform(50000, 150000, n),
        }
    )
    path = tmp_path / "wide_3ch.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def wide_csv_2ch(tmp_path):
    """2-channel wide-format CSV, 30 weeks. Usable by free tier."""
    n = 30
    dates = pd.date_range("2025-04-07", periods=n, freq="W-MON")
    rng = np.random.default_rng(99)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n),
            "email_spend": rng.uniform(3000, 10000, n),
            "revenue": rng.uniform(50000, 150000, n),
        }
    )
    path = tmp_path / "wide_2ch.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def single_channel_csv(tmp_path):
    """1-channel wide-format CSV, 30 weeks.

    Wide-format detection requires >= 2 _spend columns, so we add a zero
    placeholder second channel. The mock _run_marginal_roas and
    _run_multi_scenario use only ["meta_spend"], which simulates 1-channel.
    """
    n = 30
    dates = pd.date_range("2025-04-07", periods=n, freq="W-MON")
    rng = np.random.default_rng(7)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n),
            # placeholder so detect_csv_format returns "wide"
            "placeholder_spend": [0.0] * n,
            "revenue": rng.uniform(50000, 150000, n),
        }
    )
    path = tmp_path / "single_ch.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def mock_pro_license():
    return LicenseStatus(is_pro=True, max_channels=999, max_rows=999_999, message="Pro")


@pytest.fixture
def mock_free_license():
    return LicenseStatus(is_pro=False, max_channels=2, max_rows=2000, message="Free")


def _make_mock_model_results(channels=None):
    """Build a minimal ModelResults mock."""
    if channels is None:
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
    mr = MagicMock()
    mr.mmm = MagicMock()
    mr.roas_estimates = {c: 1.5 for c in channels}
    mr.roas_ci = {c: (0.8, 2.2) for c in channels}
    mr.marginal_roas_estimates = {c: 1.2 for c in channels}
    mr.marginal_roas_ci = {c: (0.6, 1.8) for c in channels}
    mr.channel_contributions = {c: 30000.0 for c in channels}
    mr.channel_contributions_ci = {c: (20000.0, 40000.0) for c in channels}
    mr.total_spend = {c: 10000.0 for c in channels}
    mr.duration_secs = 5.0
    mr.convergence_warnings = []
    mr.raw_contributions = MagicMock()
    mr.loo_cv = {}
    mr.intercept_decomposition = {}
    return mr


def _make_mock_marginal_roas(channel_columns):
    """Build synthetic marginal ROAS dicts for display names."""
    from mixlift.modeling.optimizer import format_channel_name

    means = {}
    cis = {}
    for col in channel_columns:
        display = format_channel_name(col)
        means[display] = 1.2
        cis[display] = (0.6, 1.8)
    return means, cis


def _patch_context(channel_columns, mock_mr):
    """Return a context manager tuple for patching all model-level calls."""
    mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)
    _pro = LicenseStatus(is_pro=True, max_channels=999, max_rows=999_999, message="Pro")
    return (
        patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=_pro,
        ),
        patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
        patch(
            "mixlift_mcp.server._run_marginal_roas",
            return_value=(mock_means, mock_cis),
        ),
        patch(
            "mixlift_mcp.server._run_multi_scenario",
            return_value=(480_000.0, 440_000.0, 520_000.0),
        ),
        patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
        patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
    )


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


class TestMixliftScenariosHappyPath:
    @pytest.mark.asyncio
    async def test_returns_json_string(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        assert isinstance(raw, str)
        result = json.loads(raw)
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_required_top_level_keys(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        result = json.loads(raw)
        required = {
            "tool",
            "version",
            "mcmc_config",
            "data_window",
            "status_quo_revenue",
            "status_quo_ci",
            "scenarios",
            "memo_markdown",
        }
        missing = required - set(result.keys())
        assert missing == set(), f"Missing keys: {missing}"

    @pytest.mark.asyncio
    async def test_tool_name_and_version(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        result = json.loads(raw)
        assert result["tool"] == "mixlift_scenarios"
        assert result["version"] == "0.5.3"

    @pytest.mark.asyncio
    async def test_scenarios_have_required_keys(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        result = json.loads(raw)
        required_sc_keys = {
            "name",
            "deltas",
            "projected_revenue",
            "projected_ci",
            "delta_vs_status_quo",
            "delta_pct",
            "extrapolated",
            "clipped",
            "rank",
        }
        for sc in result["scenarios"]:
            missing = required_sc_keys - set(sc.keys())
            assert missing == set(), f"Missing keys in scenario '{sc['name']}': {missing}"

    @pytest.mark.asyncio
    async def test_scenarios_ranked_desc(self, wide_csv_3ch):
        """Scenarios must be sorted by delta_vs_status_quo descending."""
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        result = json.loads(raw)
        deltas = [s["delta_vs_status_quo"] for s in result["scenarios"]]
        assert deltas == sorted(deltas, reverse=True), "Scenarios not sorted by delta desc"

    @pytest.mark.asyncio
    async def test_rank_field_matches_position(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        result = json.loads(raw)
        for i, sc in enumerate(result["scenarios"], start=1):
            assert sc["rank"] == i, f"Rank mismatch at position {i}: got {sc['rank']}"

    @pytest.mark.asyncio
    async def test_memo_markdown_non_empty(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        result = json.loads(raw)
        assert isinstance(result["memo_markdown"], str)
        assert len(result["memo_markdown"]) > 100

    @pytest.mark.asyncio
    async def test_5_canned_defaults_when_no_scenarios(self, wide_csv_3ch):
        """If scenarios=None, tool returns exactly 5 scenarios."""
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=None)
        result = json.loads(raw)
        assert len(result["scenarios"]) == 5

    @pytest.mark.asyncio
    async def test_status_quo_ci_is_list_of_two(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        result = json.loads(raw)
        assert isinstance(result["status_quo_ci"], list)
        assert len(result["status_quo_ci"]) == 2


# ---------------------------------------------------------------------------
# Edge case 1: empty scenarios list → use 5 canned defaults
# ---------------------------------------------------------------------------


class TestEmptyScenariosList:
    @pytest.mark.asyncio
    async def test_empty_list_triggers_canned_defaults(self, wide_csv_3ch):
        """Empty list [] should behave the same as None — use 5 canned defaults."""
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=[])
        result = json.loads(raw)
        assert len(result["scenarios"]) == 5


# ---------------------------------------------------------------------------
# Edge case 2: unknown channel in scenario deltas → error JSON
# ---------------------------------------------------------------------------


class TestUnknownChannel:
    @pytest.mark.asyncio
    async def test_unknown_channel_returns_error(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        bad_scenarios = [
            {"name": "Cut NonExistent 50%", "deltas": {"NonExistentChannel": -0.5}}
        ]
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=bad_scenarios)
        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "NonExistentChannel" in result.get("message", "") or \
               "NonExistentChannel" in str(result.get("valid_channels", ""))

    @pytest.mark.asyncio
    async def test_error_includes_valid_channel_list(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        bad_scenarios = [{"name": "Bad", "deltas": {"BadChannel": -0.1}}]
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=bad_scenarios)
        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "valid_channels" in result


# ---------------------------------------------------------------------------
# Edge case 3: absolute-mode scenario driving channel below $0 → clipped
# ---------------------------------------------------------------------------


class TestAbsoluteModeClipping:
    @pytest.mark.asyncio
    async def test_negative_absolute_delta_clips_to_zero(self, wide_csv_3ch):
        """Absolute mode: -$999999 on a channel with $5k average → clipped."""
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        scenarios = [
            {"name": "Obliterate Meta", "deltas": {"Meta": -999_999}, "mode": "absolute"}
        ]
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=scenarios)
        result = json.loads(raw)
        # Should not error; should have clipped=True
        assert result.get("status") != "error"
        sc = result["scenarios"][0]
        assert sc["clipped"] is True


# ---------------------------------------------------------------------------
# Edge case 4: single channel → canned scenarios degrade gracefully
# ---------------------------------------------------------------------------


class TestSingleChannelCannedScenarios:
    @pytest.mark.asyncio
    async def test_single_channel_returns_5_scenarios(self, single_channel_csv):
        # CSV has meta_spend + placeholder_spend (needed for wide-format detection)
        channel_columns = ["meta_spend", "placeholder_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)
        _pro = LicenseStatus(
            is_pro=True, max_channels=999, max_rows=999_999, message="Pro"
        )
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=_pro,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=(mock_means, mock_cis),
            ),
            patch(
                "mixlift_mcp.server._run_multi_scenario",
                return_value=(480_000.0, 440_000.0, 520_000.0),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_scenarios(csv_path=single_channel_csv, scenarios=None)
        result = json.loads(raw)
        assert result.get("status") != "error"
        assert len(result["scenarios"]) == 5

    @pytest.mark.asyncio
    async def test_single_channel_worst_equals_best(self, single_channel_csv):
        """With two channels (one placeholder), worst != best; scenarios valid."""
        channel_columns = ["meta_spend", "placeholder_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)
        _pro = LicenseStatus(
            is_pro=True, max_channels=999, max_rows=999_999, message="Pro"
        )
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=_pro,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=(mock_means, mock_cis),
            ),
            patch(
                "mixlift_mcp.server._run_multi_scenario",
                return_value=(480_000.0, 440_000.0, 520_000.0),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_scenarios(csv_path=single_channel_csv, scenarios=None)
        result = json.loads(raw)
        assert result.get("status") != "error"
        assert len(result["scenarios"]) == 5
        # Canned scenarios reference channel names
        all_delta_keys = set()
        for sc in result["scenarios"]:
            all_delta_keys.update(sc["deltas"].keys())
        # At least one scenario delta should reference Meta or Placeholder
        assert any(
            "Meta" in k or "Placeholder" in k for k in all_delta_keys
        ) or len(all_delta_keys) == 0  # status quo has empty deltas


# ---------------------------------------------------------------------------
# Edge case 6: malformed scenario dict → error JSON
# ---------------------------------------------------------------------------


class TestMalformedScenarioDicts:
    @pytest.mark.asyncio
    async def test_missing_name_key_returns_error(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        bad_scenarios = [{"deltas": {"Meta": -0.5}}]  # missing "name"
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=bad_scenarios)
        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "name" in result.get("message", "").lower()

    @pytest.mark.asyncio
    async def test_missing_deltas_key_returns_error(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        bad_scenarios = [{"name": "No deltas"}]  # missing "deltas"
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=bad_scenarios)
        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "deltas" in result.get("message", "").lower()

    @pytest.mark.asyncio
    async def test_error_names_the_bad_entry(self, wide_csv_3ch):
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        bad_scenarios = [
            {"name": "Good one", "deltas": {}},
            {"name": "Bad one"},  # missing deltas
        ]
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=bad_scenarios)
        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "Bad one" in result.get("message", "")


# ---------------------------------------------------------------------------
# Edge case 7: extrapolation flag set on >2× training max
# ---------------------------------------------------------------------------


class TestExtrapolationFlag:
    @pytest.mark.asyncio
    async def test_2x_spend_triggers_extrapolated_flag(self, wide_csv_3ch):
        """A +300% scenario on Meta should trigger extrapolated=True."""
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        scenarios = [{"name": "Huge Meta spend", "deltas": {"Meta": 3.0}}]
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=scenarios)
        result = json.loads(raw)
        assert result.get("status") != "error"
        sc = result["scenarios"][0]
        assert sc["extrapolated"] is True

    @pytest.mark.asyncio
    async def test_small_increase_not_extrapolated(self, wide_csv_3ch):
        """A +10% scenario should not trigger extrapolated=True."""
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        patches = _patch_context(channel_columns, mock_mr)
        scenarios = [{"name": "Small Meta bump", "deltas": {"Meta": 0.1}}]
        with patches[0], patches[1], patches[2], patches[3], patches[4], patches[5]:
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch, scenarios=scenarios)
        result = json.loads(raw)
        sc = result["scenarios"][0]
        assert sc["extrapolated"] is False


# ---------------------------------------------------------------------------
# Edge case 8: missing cached model → triggers fit
# ---------------------------------------------------------------------------


class TestMissingCachedModel:
    @pytest.mark.asyncio
    async def test_cold_start_triggers_pipeline(self, wide_csv_3ch):
        """When no cache hit, _run_pipeline must be called."""
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)
        pipeline_mock = MagicMock(return_value=mock_mr)
        _pro = LicenseStatus(
            is_pro=True, max_channels=999, max_rows=999_999, message="Pro"
        )
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=_pro,
            ),
            patch("mixlift_mcp.server._run_pipeline", pipeline_mock),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=(mock_means, mock_cis),
            ),
            patch(
                "mixlift_mcp.server._run_multi_scenario",
                return_value=(480_000.0, 440_000.0, 520_000.0),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
            # Also clear in-memory cache for this test
            patch("mixlift_mcp.server._MODEL_CACHE", {}),
        ):
            raw = await mixlift_scenarios(csv_path=wide_csv_3ch)
        result = json.loads(raw)
        assert result.get("status") != "error"
        pipeline_mock.assert_called_once()


# ---------------------------------------------------------------------------
# Edge case 9: free-tier user, >3 scenarios — NO paywall
# ---------------------------------------------------------------------------


class TestFreeTierNoPaywall:
    @pytest.mark.asyncio
    async def test_free_tier_runs_all_scenarios(self, wide_csv_2ch):
        """Free-tier users can run any number of scenarios (confirmed product decision).

        Uses wide_csv_2ch (2 channels) to stay within free-tier channel limit.
        """
        channel_columns = ["meta_spend", "email_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)
        many_scenarios = [
            {"name": f"Scenario {i}", "deltas": {}} for i in range(7)
        ]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=LicenseStatus(
                    is_pro=False, max_channels=2, max_rows=2000, message="Free"
                ),
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=(mock_means, mock_cis),
            ),
            patch(
                "mixlift_mcp.server._run_multi_scenario",
                return_value=(480_000.0, 440_000.0, 520_000.0),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_scenarios(
                csv_path=wide_csv_2ch,
                scenarios=many_scenarios,
            )
        result = json.loads(raw)
        # Must not return paywall error; must have all 7 scenarios
        assert result.get("status") != "error", f"Got error: {result.get('message')}"
        assert len(result["scenarios"]) == 7

    @pytest.mark.asyncio
    async def test_free_tier_5_default_scenarios(self, wide_csv_2ch):
        """Free-tier user with no scenarios specified gets 5 defaults, no paywall."""
        channel_columns = ["meta_spend", "email_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=LicenseStatus(
                    is_pro=False, max_channels=2, max_rows=2000, message="Free"
                ),
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=(mock_means, mock_cis),
            ),
            patch(
                "mixlift_mcp.server._run_multi_scenario",
                return_value=(480_000.0, 440_000.0, 520_000.0),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_scenarios(csv_path=wide_csv_2ch, scenarios=None)
        result = json.loads(raw)
        assert result.get("status") != "error", f"Got error: {result.get('message')}"
        assert len(result["scenarios"]) == 5
