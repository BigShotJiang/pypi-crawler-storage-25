"""OAuth 2.1 end-to-end integration test.

Exercises the full bearer-token flow across the resource server (mixlift) in a
single Python process:

  1. RSA keypair generated at collection time.
  2. Minimal aiohttp JWKS server on a random localhost port — real network I/O
     on 127.0.0.1 only, no mocking of PyJWKClient.
  3. MixLiftTokenVerifier pointed at the local JWKS URL.
  4. auth_context_var injected directly to test _resolve_license claim propagation.

Tests (5):
  T1 — verify_token happy path, real JWKS fetch, pro claims round-trip
  T2 — _resolve_license maps pro bearer token to LicenseStatus.is_pro=True
  T3 — _resolve_license falls back to legacy license_key when no bearer present
  T4 — free-tier bearer maps to is_pro=False, free-tier limits
  T5 — expired JWT rejected by verifier (real JWKS path, not mocked)
"""

from __future__ import annotations

import json
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any
from unittest.mock import AsyncMock, patch

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from mcp.server.auth.middleware.auth_context import auth_context_var
from mcp.server.auth.middleware.bearer_auth import AuthenticatedUser

from mixlift_mcp.license import (
    FREE_MAX_CHANNELS,
    FREE_MAX_ROWS,
    PRO_MAX_CHANNELS,
    PRO_MAX_ROWS,
    LicenseStatus,
)
from mixlift_mcp.oauth_verifier import MixLiftAccessToken, MixLiftTokenVerifier
from mixlift_mcp.server import _resolve_license

# ---------------------------------------------------------------------------
# Module-level RSA keypair — generated once per test session
# ---------------------------------------------------------------------------

_PRIVATE_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)
_PUBLIC_KEY = _PRIVATE_KEY.public_key()
_KID = "e2e-test-key-1"

# Produce the JWK dict from PyJWT's helper so it exactly matches what
# PyJWKClient expects on the other side (same library, consistent encoding).
_PUBLIC_JWK: dict[str, Any] = {
    **jwt.algorithms.RSAAlgorithm.to_jwk(_PUBLIC_KEY, as_dict=True),
    "kid": _KID,
    "alg": "RS256",
    "use": "sig",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _free_port() -> int:
    """Grab a free TCP port from the OS (bind then release — racy but fine for tests)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _sign_jwt(
    *,
    tier: str = "pro",
    license_key: str | None = "MIXLIFT-TEST-E2E-001",
    exp_offset: int = 3600,
    issuer: str,
    audience: str = "https://mixlift-cloud.fly.dev",
) -> str:
    """Sign a JWT with the module-level RSA private key."""
    from cryptography.hazmat.primitives import serialization

    pem = _PRIVATE_KEY.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    )
    now = int(time.time())
    payload: dict[str, Any] = {
        "iss": issuer,
        "sub": "42",
        "aud": audience,
        "iat": now,
        "exp": now + exp_offset,
        "scope": "mcp:tools",
        "tier": tier,
    }
    if license_key is not None:
        payload["license_key"] = license_key
    return jwt.encode(payload, pem, algorithm="RS256", headers={"kid": _KID})


# ---------------------------------------------------------------------------
# JWKS server fixture — aiohttp on a random localhost port
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def jwks_server():
    """Start a minimal stdlib HTTPServer serving /.well-known/jwks.json on localhost.

    Uses a background daemon thread so the async test loop is never blocked.
    Shuts down cleanly via server.shutdown() after the module finishes.
    """
    port = _free_port()
    base_url = f"http://127.0.0.1:{port}"
    jwks_url = f"{base_url}/.well-known/jwks.json"
    jwks_body = json.dumps({"keys": [_PUBLIC_JWK]}).encode()

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/.well-known/jwks.json":
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(jwks_body)))
                self.end_headers()
                self.wfile.write(jwks_body)
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, fmt: str, *args: Any) -> None:  # suppress access logs
            pass

    server = HTTPServer(("127.0.0.1", port), _Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()

    yield base_url, jwks_url

    server.shutdown()
    t.join(timeout=5)


def _make_verifier(jwks_url: str, issuer: str) -> MixLiftTokenVerifier:
    return MixLiftTokenVerifier(
        jwks_url=jwks_url,
        issuer=issuer,
        audience="https://mixlift-cloud.fly.dev",
    )


# ---------------------------------------------------------------------------
# T1 — verify_token happy path with real JWKS fetch
# ---------------------------------------------------------------------------


class TestVerifyTokenHappyPath:
    async def test_pro_claims_round_trip(self, jwks_server):
        """RS256 JWT signed locally → verified against local JWKS → correct claims."""
        base_url, jwks_url = jwks_server
        token = _sign_jwt(issuer=base_url)
        verifier = _make_verifier(jwks_url, base_url)

        result = await verifier.verify_token(token)

        assert result is not None, "Expected valid MixLiftAccessToken, got None"
        assert isinstance(result, MixLiftAccessToken)
        assert result.client_id == "42"
        assert "mcp:tools" in result.scopes
        assert result.extra["tier"] == "pro"
        assert result.extra["license_key"] == "MIXLIFT-TEST-E2E-001"
        assert result.expires_at is not None
        assert result.expires_at > int(time.time())


# ---------------------------------------------------------------------------
# T2 — _resolve_license with bearer token in ContextVar → pro tier
# ---------------------------------------------------------------------------


class TestResolveLicenseFromBearer:
    async def test_pro_bearer_maps_to_pro_license_status(self, jwks_server):
        """Pro bearer token in auth_context_var → LicenseStatus.is_pro=True."""
        base_url, jwks_url = jwks_server
        token = _sign_jwt(issuer=base_url)
        verifier = _make_verifier(jwks_url, base_url)

        access_token = await verifier.verify_token(token)
        assert access_token is not None

        auth_user = AuthenticatedUser(access_token)
        ctx_token = auth_context_var.set(auth_user)
        try:
            result = await _resolve_license("", ctx=None)
        finally:
            auth_context_var.reset(ctx_token)

        assert result.is_pro is True
        assert result.max_channels == PRO_MAX_CHANNELS
        assert result.max_rows == PRO_MAX_ROWS


# ---------------------------------------------------------------------------
# T3 — _resolve_license falls back to legacy license_key when no bearer
# ---------------------------------------------------------------------------


class TestResolveLicenseLegacyFallback:
    async def test_legacy_key_used_when_no_bearer(self):
        """No auth_context_var set → validate_license() called with the key param."""
        legacy_status = LicenseStatus(
            is_pro=True,
            max_channels=PRO_MAX_CHANNELS,
            max_rows=PRO_MAX_ROWS,
            message="legacy",
        )

        # Ensure no bearer token is in the contextvar
        ctx_token = auth_context_var.set(None)
        try:
            with patch(
                "mixlift_mcp.server.validate_license",
                new_callable=AsyncMock,
                return_value=legacy_status,
            ) as mock_vl:
                result = await _resolve_license("MIXLIFT-LEGACY-KEY", ctx=None)
                mock_vl.assert_awaited_once_with("MIXLIFT-LEGACY-KEY")
        finally:
            auth_context_var.reset(ctx_token)

        assert result.is_pro is True
        assert result.message == "legacy"


# ---------------------------------------------------------------------------
# T4 — free-tier bearer maps to free-tier LicenseStatus
# ---------------------------------------------------------------------------


class TestFreeTierBearer:
    async def test_free_bearer_maps_to_free_license_status(self, jwks_server):
        """Bearer token with tier=free → LicenseStatus.is_pro=False, free limits."""
        base_url, jwks_url = jwks_server
        token = _sign_jwt(issuer=base_url, tier="free", license_key=None)
        verifier = _make_verifier(jwks_url, base_url)

        access_token = await verifier.verify_token(token)
        assert access_token is not None
        assert access_token.extra["tier"] == "free"

        auth_user = AuthenticatedUser(access_token)
        ctx_token = auth_context_var.set(auth_user)
        try:
            result = await _resolve_license("", ctx=None)
        finally:
            auth_context_var.reset(ctx_token)

        assert result.is_pro is False
        assert result.max_channels == FREE_MAX_CHANNELS
        assert result.max_rows == FREE_MAX_ROWS


# ---------------------------------------------------------------------------
# T5 — expired JWT rejected on real JWKS path
# ---------------------------------------------------------------------------


class TestExpiredJwtRealJwks:
    async def test_expired_token_returns_none(self, jwks_server):
        """Expired JWT → verify_token returns None even when JWKS fetch succeeds."""
        base_url, jwks_url = jwks_server
        token = _sign_jwt(issuer=base_url, exp_offset=-5)  # 5 seconds in the past
        verifier = _make_verifier(jwks_url, base_url)

        result = await verifier.verify_token(token)

        assert result is None
