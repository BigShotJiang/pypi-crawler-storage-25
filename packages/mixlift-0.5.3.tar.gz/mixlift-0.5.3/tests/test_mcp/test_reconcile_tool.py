"""Tool-level integration tests for mixlift_reconcile.

All tests mock _run_pipeline and _run_channel_contributions so no MCMC fit
is executed.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.license import LicenseStatus
from mixlift_mcp.server import mixlift_reconcile

# ---------------------------------------------------------------------------
# Fixture: reconcile_input.csv (canonical 4-channel with platform revenue)
# ---------------------------------------------------------------------------

_FIXTURE_CSV = Path(__file__).parent.parent / "fixtures" / "reconcile_input.csv"


@pytest.fixture
def reconcile_csv():
    """Path to the canonical reconcile fixture CSV."""
    return str(_FIXTURE_CSV)


@pytest.fixture
def mock_pro_license():
    return LicenseStatus(is_pro=True, max_channels=999, max_rows=999_999, message="Pro")


def _make_mock_model_results(channels):
    mr = MagicMock()
    mr.mmm = MagicMock()
    mr.roas_estimates = {c: 1.5 for c in channels}
    mr.roas_ci = {c: (0.8, 2.2) for c in channels}
    mr.channel_contributions = {c: 30_000.0 for c in channels}
    mr.channel_contributions_ci = {c: (20_000.0, 40_000.0) for c in channels}
    mr.total_spend = {c: 10_000.0 for c in channels}
    mr.duration_secs = 5.0
    mr.convergence_warnings = []
    mr.raw_contributions = MagicMock()
    mr.loo_cv = {}
    mr.intercept_decomposition = {}
    return mr


def _make_mock_contributions(channel_columns):
    from mixlift.modeling.optimizer import format_channel_name

    means = {}
    cis = {}
    for col in channel_columns:
        display = format_channel_name(col)
        means[display] = 80_000.0
        cis[display] = (65_000.0, 95_000.0)
    return means, cis


def _patch_reconcile(mock_mr, mock_license, mock_means, mock_cis):
    """Return context managers for patching the reconcile call stack."""
    return (
        patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_license,
        ),
        patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
        patch(
            "mixlift_mcp.server._run_channel_contributions",
            return_value=(mock_means, mock_cis),
        ),
        patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
        patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
    )


# ---------------------------------------------------------------------------
# Edge case 1: No platform_reported_revenue columns → error JSON
# ---------------------------------------------------------------------------


class TestNoPlatformRevenueColumns:
    @pytest.mark.asyncio
    async def test_error_when_no_platform_cols(self, tmp_path, mock_pro_license):
        """CSV without any platform_reported_revenue columns → error JSON."""
        n = 30
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")
        rng = np.random.default_rng(42)
        df = pd.DataFrame(
            {
                "date": dates.strftime("%Y-%m-%d"),
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        path = tmp_path / "no_platform_rev.csv"
        df.to_csv(path, index=False)

        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            raw = await mixlift_reconcile(str(path))

        result = json.loads(raw)
        assert result["status"] == "error"
        assert "platform-reported revenue" in result["message"].lower()

    @pytest.mark.asyncio
    async def test_error_message_contains_how_to_add(self, tmp_path, mock_pro_license):
        """Error message should guide the user to add platform columns."""
        n = 30
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")
        rng = np.random.default_rng(42)
        df = pd.DataFrame(
            {
                "date": dates.strftime("%Y-%m-%d"),
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        path = tmp_path / "no_plat.csv"
        df.to_csv(path, index=False)

        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result = json.loads(await mixlift_reconcile(str(path)))

        assert "platform_reported_revenue" in result["message"] or "CSV" in result["message"]


# ---------------------------------------------------------------------------
# Edge case 9: Invalid period string → error JSON
# ---------------------------------------------------------------------------


class TestInvalidPeriod:
    @pytest.mark.asyncio
    async def test_invalid_period_returns_error(self, reconcile_csv, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result = json.loads(await mixlift_reconcile(reconcile_csv, period="last_month"))

        assert result["status"] == "error"
        assert "invalid period" in result["message"].lower()

    @pytest.mark.asyncio
    async def test_ytd_period_invalid(self, reconcile_csv, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result = json.loads(await mixlift_reconcile(reconcile_csv, period="ytd"))

        assert result["status"] == "error"


# ---------------------------------------------------------------------------
# Edge case 4: Negative platform_reported_revenue → error JSON
# ---------------------------------------------------------------------------


class TestNegativePlatformRevenue:
    @pytest.mark.asyncio
    async def test_negative_platform_revenue_error(self, tmp_path, mock_pro_license):
        n = 30
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")
        rng = np.random.default_rng(42)
        platform_rev = rng.uniform(5000, 20000, n)
        platform_rev[5] = -100.0  # inject a negative value
        df = pd.DataFrame(
            {
                "date": dates.strftime("%Y-%m-%d"),
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "meta_platform_reported_revenue": platform_rev,
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        path = tmp_path / "negative_platform.csv"
        df.to_csv(path, index=False)

        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result = json.loads(await mixlift_reconcile(str(path)))

        assert result["status"] == "error"
        assert "negative" in result["message"].lower()


# ---------------------------------------------------------------------------
# Edge case 6: Period longer than fit window → error JSON
# ---------------------------------------------------------------------------


class TestPeriodTooLong:
    @pytest.mark.asyncio
    async def test_period_longer_than_window_error(self, tmp_path, mock_pro_license):
        """last_quarter requires 13 weeks; use only 10 weeks of data.

        The error may come from load_wide_format (< 90 days minimum) or from
        the period vs window check — either way the response is an error JSON.
        """
        n = 10
        dates = pd.date_range("2026-01-01", periods=n, freq="W-MON")
        rng = np.random.default_rng(42)
        df = pd.DataFrame(
            {
                "date": dates.strftime("%Y-%m-%d"),
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "meta_platform_reported_revenue": rng.uniform(10000, 50000, n),
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        path = tmp_path / "short_window.csv"
        df.to_csv(path, index=False)

        channels = ["meta_spend", "google_search_spend"]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            result = json.loads(await mixlift_reconcile(str(path), period="last_quarter"))

        # Short window → error (from either 90-day validation or period>window check)
        assert result["status"] == "error"


# ---------------------------------------------------------------------------
# Edge case 2: Partial coverage (some channels have platform_rev, others don't)
# ---------------------------------------------------------------------------


class TestPartialCoverage:
    @pytest.mark.asyncio
    async def test_partial_coverage_runs(self, reconcile_csv, mock_pro_license):
        """Fixture has 3 channels with platform_rev + 1 without (email)."""
        channels = [
            "meta_spend",
            "google_search_spend",
            "tiktok_spend",
            "email_spend",
        ]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            raw = await mixlift_reconcile(reconcile_csv, period="last_4_weeks")

        result = json.loads(raw)
        assert "channels" in result or result.get("status") == "error"

        # If it ran successfully (not an error about period length, etc.)
        if "channels" in result:
            verdicts = {ch["name"]: ch["verdict"] for ch in result["channels"]}
            # Email should be unmeasured
            assert verdicts.get("Email") == "unmeasured"
            # At least one channel measured
            assert any(v != "unmeasured" for v in verdicts.values())

    @pytest.mark.asyncio
    async def test_unmeasured_channels_have_null_gap(self, reconcile_csv, mock_pro_license):
        """Email channel (no platform rev) must have null gap fields."""
        channels = [
            "meta_spend",
            "google_search_spend",
            "tiktok_spend",
            "email_spend",
        ]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            raw = await mixlift_reconcile(reconcile_csv, period="last_4_weeks")

        result = json.loads(raw)
        if "channels" in result:
            email = next((c for c in result["channels"] if c["name"] == "Email"), None)
            if email:
                assert email["gap_dollars"] is None
                assert email["gap_pct"] is None
                assert email["platform_reported_revenue"] is None


# ---------------------------------------------------------------------------
# Edge case 3: Platform revenue all-zero → warning in memo
# ---------------------------------------------------------------------------


class TestAllZeroPlatformRevenue:
    @pytest.mark.asyncio
    async def test_all_zero_platform_revenue_warning(self, tmp_path, mock_pro_license):
        n = 30
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")
        rng = np.random.default_rng(42)
        df = pd.DataFrame(
            {
                "date": dates.strftime("%Y-%m-%d"),
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "meta_platform_reported_revenue": [0.0] * n,  # all zero
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        path = tmp_path / "zero_platform.csv"
        df.to_csv(path, index=False)

        channels = ["meta_spend", "google_search_spend"]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            raw = await mixlift_reconcile(str(path), period="full_period")

        result = json.loads(raw)
        if "memo_markdown" in result:
            memo = result["memo_markdown"].lower()
            assert "zero" in memo or "warning" in memo


# ---------------------------------------------------------------------------
# Edge case 5: Channel in platform cols but not in fit → skip with warning
# ---------------------------------------------------------------------------


class TestPlatformColNotInFit:
    @pytest.mark.asyncio
    async def test_unknown_channel_skipped_with_warning(self, tmp_path, mock_pro_license):
        """Platform revenue for 'podcast' which has no spend col → skip gracefully."""
        n = 30
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")
        rng = np.random.default_rng(42)
        df = pd.DataFrame(
            {
                "date": dates.strftime("%Y-%m-%d"),
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "podcast_platform_reported_revenue": rng.uniform(1000, 5000, n),  # no podcast_spend
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        path = tmp_path / "unknown_channel.csv"
        df.to_csv(path, index=False)

        channels = ["meta_spend", "google_search_spend"]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            raw = await mixlift_reconcile(str(path), period="full_period")

        result = json.loads(raw)
        # Should not be an error — just a warning
        assert "channels" in result or result.get("status") == "error"
        if "memo_markdown" in result:
            # Should have a warning about the skipped channel
            memo = result["memo_markdown"].lower()
            assert "podcast" in memo or "warning" in memo


# ---------------------------------------------------------------------------
# Edge case 8: Missing cached model → triggers fit
# ---------------------------------------------------------------------------


class TestMissingCacheTriggersfit:
    @pytest.mark.asyncio
    async def test_cache_miss_triggers_pipeline(self, reconcile_csv, mock_pro_license):
        """When no cached model, _run_pipeline should be called."""
        import mixlift_mcp.server as _srv

        channels = [
            "meta_spend",
            "google_search_spend",
            "tiktok_spend",
            "email_spend",
        ]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        run_pipeline_mock = MagicMock(return_value=mock_mr)

        # Clear module-level model cache so we guarantee a cache miss
        _srv._MODEL_CACHE.clear()

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", run_pipeline_mock),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_reconcile(reconcile_csv, period="last_4_weeks")

        result = json.loads(raw)
        # Pipeline was called (cache miss)
        run_pipeline_mock.assert_called_once()
        # Result has channels or was a period-length error
        assert "channels" in result or result.get("status") == "error"


# ---------------------------------------------------------------------------
# Happy path: structured output shape
# ---------------------------------------------------------------------------


class TestReconcileHappyPath:
    @pytest.mark.asyncio
    async def test_output_keys_match_spec(self, reconcile_csv, mock_pro_license):
        channels = [
            "meta_spend",
            "google_search_spend",
            "tiktok_spend",
            "email_spend",
        ]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            raw = await mixlift_reconcile(reconcile_csv, period="last_4_weeks")

        result = json.loads(raw)
        if result.get("status") == "error":
            pytest.skip(f"Tool returned error (likely period > window): {result['message']}")

        required_keys = {
            "tool",
            "version",
            "mcmc_config",
            "data_window",
            "period_label",
            "period_weeks",
            "total_platform_reported",
            "total_mmm_attributed",
            "total_gap_dollars",
            "total_gap_pct",
            "channels",
            "memo_markdown",
        }
        assert required_keys.issubset(set(result.keys()))

    @pytest.mark.asyncio
    async def test_tool_name_in_output(self, reconcile_csv, mock_pro_license):
        channels = ["meta_spend", "google_search_spend", "tiktok_spend", "email_spend"]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            result = json.loads(await mixlift_reconcile(reconcile_csv, period="full_period"))

        if result.get("status") != "error":
            assert result["tool"] == "mixlift_reconcile"

    @pytest.mark.asyncio
    async def test_memo_markdown_present(self, reconcile_csv, mock_pro_license):
        channels = ["meta_spend", "google_search_spend", "tiktok_spend", "email_spend"]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            result = json.loads(await mixlift_reconcile(reconcile_csv, period="full_period"))

        if result.get("status") != "error":
            assert "memo_markdown" in result
            assert len(result["memo_markdown"]) > 50

    @pytest.mark.asyncio
    async def test_alias_column_accepted(self, tmp_path, mock_pro_license):
        """CSV with _platform_revenue suffix (alias) is accepted and normalised."""
        n = 30
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")
        rng = np.random.default_rng(42)
        df = pd.DataFrame(
            {
                "date": dates.strftime("%Y-%m-%d"),
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "meta_platform_revenue": rng.uniform(10000, 50000, n),  # alias suffix
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        path = tmp_path / "alias_col.csv"
        df.to_csv(path, index=False)

        channels = ["meta_spend", "google_search_spend"]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            result = json.loads(await mixlift_reconcile(str(path), period="full_period"))

        # Should not error on missing platform columns (alias was detected)
        if result.get("status") == "error":
            assert "platform-reported revenue" not in result["message"].lower(), (
                f"Alias column was not detected. Error: {result['message']}"
            )

    @pytest.mark.asyncio
    async def test_full_period_works(self, reconcile_csv, mock_pro_license):
        """full_period should not error on window size."""
        channels = ["meta_spend", "google_search_spend", "tiktok_spend", "email_spend"]
        mock_mr = _make_mock_model_results(channels)
        mock_means, mock_cis = _make_mock_contributions(channels)

        patches = _patch_reconcile(mock_mr, mock_pro_license, mock_means, mock_cis)
        with patches[0], patches[1], patches[2], patches[3], patches[4]:
            result = json.loads(await mixlift_reconcile(reconcile_csv, period="full_period"))

        assert result.get("status") != "error" or "week" not in result.get("message", "")

    @pytest.mark.asyncio
    async def test_file_not_found_error(self, mock_pro_license, tmp_path):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result = json.loads(await mixlift_reconcile(str(tmp_path / "nope.csv")))

        assert result["status"] == "error"
