"""Tests for Item 8 — structured logging, request-ID middleware, Sentry init, PII scrub."""

from __future__ import annotations

import json
import logging
from io import StringIO
from unittest.mock import MagicMock, patch

import pytest
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import PlainTextResponse
from starlette.routing import Route
from starlette.testclient import TestClient

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _reset_logging_config() -> None:
    """Force logging_config module to re-run configure_logging on next call."""
    import mixlift_mcp.logging_config as lc

    lc._CONFIGURED = False
    # Remove any JsonFormatter handlers added in a previous test run
    root = logging.getLogger()
    root.handlers = [
        h for h in root.handlers if not isinstance(h.formatter, lc._JsonFormatter)
    ]


# ---------------------------------------------------------------------------
# 1. JSON formatter emits valid JSON with request_id from ContextVar
# ---------------------------------------------------------------------------


class TestJsonFormatter:
    def test_json_output_structure(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """configure_logging(json) attaches a formatter that emits valid JSON."""
        monkeypatch.setenv("LOG_FORMAT", "json")
        _reset_logging_config()

        from mixlift_mcp.logging_config import _JsonFormatter, configure_logging

        configure_logging()

        buf = StringIO()
        handler = logging.StreamHandler(buf)
        formatter = _JsonFormatter()
        handler.setFormatter(formatter)

        test_logger = logging.getLogger("test.json_formatter")
        test_logger.addHandler(handler)
        test_logger.setLevel(logging.DEBUG)
        test_logger.propagate = False

        test_logger.info("hello json")
        output = buf.getvalue().strip()

        record = json.loads(output)
        assert record["msg"] == "hello json"
        assert record["level"] == "INFO"
        assert "ts" in record
        assert "logger" in record
        assert "file" in record
        assert "line" in record

        # Cleanup
        test_logger.removeHandler(handler)

    def test_json_includes_request_id_from_contextvar(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """JSON log records include request_id when the ContextVar is set."""
        monkeypatch.setenv("LOG_FORMAT", "json")
        _reset_logging_config()

        from mixlift_mcp.logging_config import _JsonFormatter
        from mixlift_mcp.request_id import request_id_var

        token = request_id_var.set("test-req-abc123")
        try:
            buf = StringIO()
            handler = logging.StreamHandler(buf)
            formatter = _JsonFormatter()
            handler.setFormatter(formatter)

            test_logger = logging.getLogger("test.json_request_id")
            test_logger.addHandler(handler)
            test_logger.setLevel(logging.DEBUG)
            test_logger.propagate = False

            test_logger.info("with request id")
            output = buf.getvalue().strip()

            record = json.loads(output)
            assert record.get("request_id") == "test-req-abc123"
        finally:
            request_id_var.reset(token)
            test_logger.removeHandler(handler)  # type: ignore[possibly-undefined]

    def test_plain_format_unchanged_without_env_var(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Without LOG_FORMAT=json, configure_logging() does not add JsonFormatter."""
        monkeypatch.delenv("LOG_FORMAT", raising=False)
        _reset_logging_config()

        from mixlift_mcp.logging_config import _JsonFormatter, configure_logging

        configure_logging()

        root = logging.getLogger()
        json_handlers = [h for h in root.handlers if isinstance(h.formatter, _JsonFormatter)]
        assert json_handlers == [], "JsonFormatter should not be added without LOG_FORMAT=json"


# ---------------------------------------------------------------------------
# 2. RequestIdMiddleware injects X-Request-Id
# ---------------------------------------------------------------------------


class TestRequestIdMiddleware:
    def _make_app(self) -> TestClient:
        from mixlift_mcp.request_id import RequestIdMiddleware

        async def homepage(request: Request) -> PlainTextResponse:
            return PlainTextResponse("ok")

        app = Starlette(routes=[Route("/", homepage)])
        app.add_middleware(RequestIdMiddleware)
        return TestClient(app, raise_server_exceptions=True)

    def test_response_includes_request_id_when_client_omits_header(self) -> None:
        """Middleware generates a UUID request-ID when client sends none."""
        client = self._make_app()
        response = client.get("/")
        assert response.status_code == 200
        header = response.headers.get("x-request-id")
        assert header is not None, "X-Request-Id missing from response"
        assert len(header) == 32, "uuid4 hex should be 32 chars"

    def test_response_echoes_client_request_id(self) -> None:
        """Middleware echoes back the X-Request-Id the client provides."""
        client = self._make_app()
        response = client.get("/", headers={"X-Request-Id": "my-custom-id-42"})
        assert response.headers.get("x-request-id") == "my-custom-id-42"

    def test_request_id_differs_across_requests(self) -> None:
        """Each request without a client-provided ID gets a unique UUID."""
        client = self._make_app()
        id1 = client.get("/").headers.get("x-request-id")
        id2 = client.get("/").headers.get("x-request-id")
        assert id1 != id2, "Two requests should get distinct request IDs"


# ---------------------------------------------------------------------------
# 3. init_sentry is no-op when SENTRY_DSN is unset
# ---------------------------------------------------------------------------


class TestSentryInit:
    def test_init_sentry_noop_without_dsn(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """init_sentry() must NOT call sentry_sdk.init when SENTRY_DSN is unset."""
        monkeypatch.delenv("SENTRY_DSN", raising=False)

        mock_sdk = MagicMock()
        # Place mock in sys.modules so any accidental lazy import would still be caught.
        with patch.dict("sys.modules", {"sentry_sdk": mock_sdk}):
            from mixlift_mcp.sentry_init import init_sentry

            init_sentry()

        mock_sdk.init.assert_not_called()

    def test_init_sentry_calls_init_with_dsn(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """init_sentry() calls sentry_sdk.init when SENTRY_DSN is set."""
        import sys

        monkeypatch.setenv("SENTRY_DSN", "https://fake@o123.ingest.sentry.io/456")
        monkeypatch.setenv("ENVIRONMENT", "test")

        mock_init = MagicMock()
        mock_starlette_integration = MagicMock()
        mock_sdk_module = MagicMock()
        mock_sdk_module.init = mock_init
        mock_integrations_starlette = MagicMock(StarletteIntegration=mock_starlette_integration)

        # Insert mocks at the sys.modules level without disturbing the rest of
        # the module namespace (avoids reload-related ImportError).
        original_sdk = sys.modules.get("sentry_sdk")
        original_starlette = sys.modules.get("sentry_sdk.integrations.starlette")
        sys.modules["sentry_sdk"] = mock_sdk_module  # type: ignore[assignment]
        sys.modules["sentry_sdk.integrations.starlette"] = mock_integrations_starlette  # type: ignore[assignment]
        try:
            from mixlift_mcp.sentry_init import init_sentry
            init_sentry()
        finally:
            if original_sdk is None:
                sys.modules.pop("sentry_sdk", None)
            else:
                sys.modules["sentry_sdk"] = original_sdk
            if original_starlette is None:
                sys.modules.pop("sentry_sdk.integrations.starlette", None)
            else:
                sys.modules["sentry_sdk.integrations.starlette"] = original_starlette

        mock_init.assert_called_once()
        call_kwargs = mock_init.call_args.kwargs
        assert call_kwargs["dsn"] == "https://fake@o123.ingest.sentry.io/456"
        assert call_kwargs["environment"] == "test"


# ---------------------------------------------------------------------------
# 4. PII scrubber masks license keys and email addresses
# ---------------------------------------------------------------------------


class TestScrubPii:
    def test_license_key_masked(self) -> None:
        """MIXLIFT-* strings are replaced with MIXLIFT-***."""
        from mixlift_mcp.sentry_init import _scrub_pii

        event: dict = {
            "request": {"data": {"key": "MIXLIFT-abc-123-xyz"}},
            "extra": {},
            "breadcrumbs": {"values": []},
        }
        result = _scrub_pii(event)
        assert result["request"]["data"]["key"] == "MIXLIFT-***"

    def test_email_redacted(self) -> None:
        """Email-like strings are replaced with [REDACTED]."""
        from mixlift_mcp.sentry_init import _scrub_pii

        event: dict = {
            "extra": {"user_info": "contact: alice@example.com for billing"},
            "breadcrumbs": {"values": []},
        }
        result = _scrub_pii(event)
        assert "alice@example.com" not in result["extra"]["user_info"]
        assert "[REDACTED]" in result["extra"]["user_info"]

    def test_breadcrumb_values_scrubbed(self) -> None:
        """PII in breadcrumb values is also scrubbed."""
        from mixlift_mcp.sentry_init import _scrub_pii

        event: dict = {
            "breadcrumbs": {
                "values": [
                    {"message": "license=MIXLIFT-secret-key, user=bob@test.org"}
                ]
            }
        }
        result = _scrub_pii(event)
        msg = result["breadcrumbs"]["values"][0]["message"]
        assert "MIXLIFT-secret-key" not in msg
        assert "bob@test.org" not in msg
        assert "MIXLIFT-***" in msg
        assert "[REDACTED]" in msg

    def test_clean_event_unchanged(self) -> None:
        """Events with no PII pass through unmodified."""
        from mixlift_mcp.sentry_init import _scrub_pii

        event: dict = {
            "request": {"data": {"action": "analyze", "rows": 52}},
            "extra": {"tenant": "sha256:abc"},
            "breadcrumbs": {"values": []},
        }
        result = _scrub_pii(event)
        assert result["request"]["data"]["action"] == "analyze"
        assert result["extra"]["tenant"] == "sha256:abc"

    def test_before_after_event_dict(self) -> None:
        """Document the exact before/after transformation for the sprint report."""
        from mixlift_mcp.sentry_init import _scrub_pii

        before: dict = {
            "request": {
                "data": {
                    "license_key": "MIXLIFT-abc-123",
                    "email": "founder@startup.io",
                }
            },
            "extra": {"raw": "key=MIXLIFT-xyz, contact=ops@co.com"},
            "breadcrumbs": {"values": [{"message": "user MIXLIFT-test logged in"}]},
        }
        after = _scrub_pii(before)

        assert after["request"]["data"]["license_key"] == "MIXLIFT-***"
        assert after["request"]["data"]["email"] == "[REDACTED]"
        assert "MIXLIFT-***" in after["extra"]["raw"]
        assert "[REDACTED]" in after["extra"]["raw"]
        assert "MIXLIFT-***" in after["breadcrumbs"]["values"][0]["message"]
