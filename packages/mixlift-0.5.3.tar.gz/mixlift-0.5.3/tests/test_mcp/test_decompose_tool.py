"""Tool-level integration tests for mixlift_decompose.

All tests mock _run_pipeline and _run_channel_contributions so no MCMC fit
is executed.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.license import LicenseStatus
from mixlift_mcp.server import mixlift_decompose

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def wide_csv_30w(tmp_path):
    """3-channel wide-format CSV, 30 weeks of data."""
    n = 30
    dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")
    rng = np.random.default_rng(42)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n),
            "google_search_spend": rng.uniform(3000, 10000, n),
            "tiktok_spend": rng.uniform(1000, 5000, n),
            "revenue": rng.uniform(50000, 150000, n),
        }
    )
    path = tmp_path / "wide_3ch_30w.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def mock_pro_license():
    return LicenseStatus(is_pro=True, max_channels=999, max_rows=999_999, message="Pro")


@pytest.fixture
def mock_free_license():
    return LicenseStatus(is_pro=False, max_channels=2, max_rows=2000, message="Free")


def _make_mock_model_results(channels=None):
    """Build a minimal ModelResults mock."""
    if channels is None:
        channels = ["meta_spend", "google_search_spend", "tiktok_spend"]
    mr = MagicMock()
    mr.mmm = MagicMock()
    mr.roas_estimates = {c: 1.5 for c in channels}
    mr.roas_ci = {c: (0.8, 2.2) for c in channels}
    mr.channel_contributions = {c: 30_000.0 for c in channels}
    mr.channel_contributions_ci = {c: (20_000.0, 40_000.0) for c in channels}
    mr.total_spend = {c: 10_000.0 for c in channels}
    mr.duration_secs = 5.0
    mr.convergence_warnings = []
    mr.raw_contributions = MagicMock()
    mr.loo_cv = {}
    mr.intercept_decomposition = {}
    return mr


def _make_mock_contributions(channel_columns):
    """Build synthetic contribution dicts for the given column names."""
    from mixlift.modeling.optimizer import format_channel_name

    means = {}
    cis = {}
    for col in channel_columns:
        display = format_channel_name(col)
        means[display] = 80_000.0
        cis[display] = (65_000.0, 95_000.0)
    return means, cis


def _patch_decompose(mock_mr, mock_pro_license, mock_means, mock_cis):
    """Return context managers for patching the decompose call stack."""
    return (
        patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ),
        patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
        patch(
            "mixlift_mcp.server._run_channel_contributions",
            return_value=(mock_means, mock_cis),
        ),
        patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
        patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
    )


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


class TestMixliftDecomposeHappyPath:
    @pytest.mark.asyncio
    async def test_returns_json_string(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w)

        assert isinstance(raw, str)
        result = json.loads(raw)
        assert result.get("tool") == "mixlift_decompose"

    @pytest.mark.asyncio
    async def test_required_top_level_keys_present(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w)

        result = json.loads(raw)
        required_keys = {
            "tool",
            "version",
            "mcmc_config",
            "data_window",
            "period_label",
            "period_weeks",
            "total_revenue",
            "baseline",
            "paid_total",
            "channels",
            "memo_markdown",
        }
        missing = required_keys - set(result.keys())
        assert missing == set(), f"Missing top-level keys: {missing}"

    @pytest.mark.asyncio
    async def test_channel_keys_match_spec(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w)

        result = json.loads(raw)
        required_ch_keys = {
            "name",
            "contribution",
            "pct_of_total",
            "pct_of_paid",
            "ci",
            "spend",
            "roas",
        }
        for ch in result["channels"]:
            missing = required_ch_keys - set(ch.keys())
            assert missing == set(), f"Missing channel keys for {ch.get('name')}: {missing}"

    @pytest.mark.asyncio
    async def test_memo_markdown_non_empty(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w)

        result = json.loads(raw)
        assert isinstance(result["memo_markdown"], str)
        assert len(result["memo_markdown"]) > 50

    @pytest.mark.asyncio
    async def test_version_is_053(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w)

        result = json.loads(raw)
        assert result["version"] == "0.5.3"

    @pytest.mark.asyncio
    async def test_default_period_is_last_4_weeks(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w)

        result = json.loads(raw)
        assert result["period_weeks"] == 4
        assert "Last 4 weeks" in result["period_label"]


# ---------------------------------------------------------------------------
# Edge case 1: period longer than fit window
# ---------------------------------------------------------------------------


def _make_short_window_df(n_weeks: int) -> tuple[pd.DataFrame, pd.Series, list[str]]:
    """Return a (X, y, channel_columns) tuple with n_weeks of weekly data.

    Used to mock _load_wide_format so the period-too-long check can be tested
    without the CSV ingest 90-day floor blocking short windows.
    """
    rng = np.random.default_rng(99)
    dates = pd.date_range("2026-02-02", periods=n_weeks, freq="W-MON")
    channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
    X = pd.DataFrame(  # noqa: N806
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n_weeks),
            "google_search_spend": rng.uniform(3000, 10000, n_weeks),
            "tiktok_spend": rng.uniform(1000, 5000, n_weeks),
            "revenue": rng.uniform(50000, 150000, n_weeks),
        }
    )
    y = X.pop("revenue")
    return X, y, channel_columns


class TestPeriodTooLong:
    @pytest.mark.asyncio
    async def test_last_quarter_on_8w_data_returns_error(self, wide_csv_30w, mock_pro_license):
        """last_quarter requires 13 weeks but the mocked loader provides 8 — error JSON."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)
        X_short, y_short, cols_short = _make_short_window_df(8)  # noqa: N806

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._detect_csv_format", return_value="wide"),
            patch(
                "mixlift_mcp.server._load_wide_format",
                return_value=(X_short, y_short, cols_short),
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w, period="last_quarter")

        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "13 weeks" in result["message"] or "last_quarter" in result["message"]
        assert "8 weeks" in result["message"] or "only" in result["message"]

    @pytest.mark.asyncio
    async def test_last_4_weeks_on_8w_data_succeeds(self, wide_csv_30w, mock_pro_license):
        """last_4_weeks requires 4 weeks and the mocked loader provides 8 — must succeed."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)
        X_short, y_short, cols_short = _make_short_window_df(8)  # noqa: N806

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._detect_csv_format", return_value="wide"),
            patch(
                "mixlift_mcp.server._load_wide_format",
                return_value=(X_short, y_short, cols_short),
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w, period="last_4_weeks")

        result = json.loads(raw)
        assert result.get("tool") == "mixlift_decompose"


# ---------------------------------------------------------------------------
# Edge case 6: cache hit skips pipeline
# ---------------------------------------------------------------------------


class TestCacheBehavior:
    @pytest.mark.asyncio
    async def test_cache_hit_skips_pipeline(self, wide_csv_30w, mock_pro_license):
        """When disk cache returns a model, _run_pipeline must not be called.

        X must NOT contain a 'revenue' column — the server should read revenue
        from the 'y' entry in the cache dict, not from X.
        """
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mmm = MagicMock()
        n = 30
        rng = np.random.default_rng(42)
        # X has no revenue column — this is the production shape
        x_cached = pd.DataFrame(
            {
                "date": pd.date_range("2025-09-22", periods=n, freq="W-MON"),
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "tiktok_spend": rng.uniform(1000, 5000, n),
            }
        )
        y_cached = pd.Series(rng.uniform(50000, 150000, n), name="y")

        disk_cache_entry = {
            "mmm": mock_mmm,
            "X": x_cached,
            "y": y_cached,
            "channel_columns": channel_columns,
            "model_results": _make_mock_model_results(channel_columns),
            "result": {},
        }

        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline") as mock_pipeline,
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch(
                "mixlift_mcp.model_cache.load_model",
                new_callable=AsyncMock,
                return_value=disk_cache_entry,
            ),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w)

        mock_pipeline.assert_not_called()
        result = json.loads(raw)
        assert result.get("tool") == "mixlift_decompose"


# ---------------------------------------------------------------------------
# Edge case 7: invalid period string
# ---------------------------------------------------------------------------


class TestInvalidPeriod:
    @pytest.mark.asyncio
    async def test_invalid_period_returns_error_json(self, wide_csv_30w, mock_pro_license):
        """An unrecognised period must return error JSON listing valid options."""
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w, period="last_month")

        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "last_month" in result["message"]
        for valid in ("last_week", "last_4_weeks", "last_quarter", "full_period"):
            assert valid in result["message"]

    @pytest.mark.asyncio
    async def test_all_valid_periods_accepted(self, wide_csv_30w, mock_pro_license):
        """Each valid period string must not trigger the invalid-period error."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        for period in ("last_week", "last_4_weeks", "full_period"):
            with (
                patch(
                    "mixlift_mcp.server._resolve_license",
                    new_callable=AsyncMock,
                    return_value=mock_pro_license,
                ),
                patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
                patch(
                    "mixlift_mcp.server._run_channel_contributions",
                    return_value=(mock_means, mock_cis),
                ),
                patch(
                    "mixlift_mcp.model_cache.load_model",
                    new_callable=AsyncMock,
                    return_value=None,
                ),
                patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
            ):
                raw = await mixlift_decompose(csv_path=wide_csv_30w, period=period)

            result = json.loads(raw)
            assert result.get("status") != "error", (
                f"Period '{period}' unexpectedly returned error: {result.get('message')}"
            )


# ---------------------------------------------------------------------------
# Channels filter: warn-and-skip
# ---------------------------------------------------------------------------


class TestChannelsFilter:
    @pytest.mark.asyncio
    async def test_unknown_channel_not_error(self, wide_csv_30w, mock_pro_license):
        """A channel filter with an unknown column name must not crash — warn-and-skip."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(
                csv_path=wide_csv_30w,
                channels=["meta_spend", "podcast_spend"],
            )

        result = json.loads(raw)
        # Must succeed, not error
        assert result.get("tool") == "mixlift_decompose"
        # Only meta_spend is valid
        assert len(result["channels"]) == 1

    @pytest.mark.asyncio
    async def test_all_unknown_channels_returns_error(self, wide_csv_30w, mock_pro_license):
        """When the channel filter resolves to empty, return an error."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(
                csv_path=wide_csv_30w,
                channels=["podcast_spend", "tv_spend"],
            )

        result = json.loads(raw)
        assert result.get("status") == "error"

    @pytest.mark.asyncio
    async def test_channels_sorted_by_contribution_descending(self, wide_csv_30w, mock_pro_license):
        """Channels in result must be sorted by contribution descending."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        from mixlift.modeling.optimizer import format_channel_name

        # Deliberately unequal contributions to test sort order
        mock_means = {
            format_channel_name("meta_spend"): 90_000.0,
            format_channel_name("google_search_spend"): 40_000.0,
            format_channel_name("tiktok_spend"): 60_000.0,
        }
        mock_cis = {
            format_channel_name("meta_spend"): (80_000.0, 100_000.0),
            format_channel_name("google_search_spend"): (35_000.0, 45_000.0),
            format_channel_name("tiktok_spend"): (55_000.0, 65_000.0),
        }

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w)

        result = json.loads(raw)
        contribs = [ch["contribution"] for ch in result["channels"]]
        assert contribs == sorted(contribs, reverse=True)


# ---------------------------------------------------------------------------
# Regression: total_revenue must come from y, never from fabricated X columns
# ---------------------------------------------------------------------------


class TestRevenueFromY:
    """Regression test for the G3/G4 critical bug.

    The old code scanned X_fit.columns for a 'revenue' column and fell back to
    paid_rev / scale when none was found.  In production X never has revenue,
    so the fallback produced a fabricated baseline.

    This test mocks _load_wide_format to return X WITHOUT a revenue column and
    y_known as a distinct Series, then asserts that total_revenue and baseline
    match y_known — not any column of X.
    """

    @pytest.mark.asyncio
    async def test_total_revenue_equals_y_sum_for_period(self, wide_csv_30w, mock_pro_license):
        """total_revenue must equal float(y_known[period_mask].sum()), not a fabrication."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        n = 30
        rng = np.random.default_rng(7)
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")

        # X has NO revenue column — this is production shape
        X_no_rev = pd.DataFrame(  # noqa: N806
            {
                "date": dates,
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "tiktok_spend": rng.uniform(1000, 5000, n),
            }
        )
        # Deliberately distinctive y values so a fabrication would differ
        y_known = pd.Series(rng.uniform(80000, 120000, n), name="y")

        mock_mr = _make_mock_model_results(channel_columns)
        mock_mr.mmm = MagicMock()
        # Ensure mmm.y is NOT available so the test exercises the y-thread path
        del mock_mr.mmm.y
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._detect_csv_format", return_value="wide"),
            patch(
                "mixlift_mcp.server._load_wide_format",
                return_value=(X_no_rev, y_known, channel_columns),
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
            # Clear in-memory cache so earlier tests cannot leak y from a prior run
            patch("mixlift_mcp.server._MODEL_CACHE", {}),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w, period="last_4_weeks")

        result = json.loads(raw)
        assert result.get("tool") == "mixlift_decompose", f"Unexpected error: {result}"

        # Compute expected total_revenue: last 4 weeks = last 4 rows of 30-week window
        # (rows where date > period_end - 4w, i.e. the most recent 4 rows)
        last_4_mask = dates > (dates[-1] - pd.Timedelta(weeks=4))
        expected_total = float(y_known[last_4_mask].sum())

        assert result["total_revenue"] == pytest.approx(expected_total, abs=1), (
            f"total_revenue {result['total_revenue']} != expected {expected_total}. "
            "Fabrication fallback must have been used."
        )

        # Baseline must be total - paid (not 0 or 12× paid)
        paid = result["paid_total"]["revenue"]
        baseline = result["baseline"]["revenue"]
        assert abs(baseline - (expected_total - paid)) <= 1.0, (
            f"baseline {baseline} != total - paid "
            f"({expected_total} - {paid} = {expected_total - paid})"
        )

    @pytest.mark.asyncio
    async def test_baseline_ci_propagates_from_paid_ci(self, wide_csv_30w, mock_pro_license):
        """baseline CI must be [total - paid_ci_hi, total - paid_ci_lo]."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        n = 30
        rng = np.random.default_rng(13)
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")

        X_no_rev = pd.DataFrame(  # noqa: N806
            {
                "date": dates,
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "tiktok_spend": rng.uniform(1000, 5000, n),
            }
        )
        y_known = pd.Series(rng.uniform(80000, 120000, n), name="y")

        mock_mr = _make_mock_model_results(channel_columns)
        mock_mr.mmm = MagicMock()
        del mock_mr.mmm.y

        # Known asymmetric CIs so we can verify orientation
        from mixlift.modeling.optimizer import format_channel_name

        mock_means = {format_channel_name(c): 10_000.0 for c in channel_columns}
        mock_cis = {
            format_channel_name("meta_spend"): (8_000.0, 12_000.0),
            format_channel_name("google_search_spend"): (7_000.0, 11_000.0),
            format_channel_name("tiktok_spend"): (6_000.0, 10_000.0),
        }

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._detect_csv_format", return_value="wide"),
            patch(
                "mixlift_mcp.server._load_wide_format",
                return_value=(X_no_rev, y_known, channel_columns),
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
            # Clear in-memory cache so earlier tests cannot leak y from a prior run
            patch("mixlift_mcp.server._MODEL_CACHE", {}),
        ):
            raw = await mixlift_decompose(csv_path=wide_csv_30w, period="last_4_weeks")

        result = json.loads(raw)
        assert result.get("tool") == "mixlift_decompose", f"Error: {result}"

        total = result["total_revenue"]
        paid_ci = result["paid_total"]["ci"]
        baseline_ci = result["baseline"]["ci"]

        # baseline_ci_lo = total - paid_ci_hi
        # baseline_ci_hi = total - paid_ci_lo
        assert baseline_ci[0] == pytest.approx(max(0.0, total - paid_ci[1]), abs=1), (
            "baseline CI lo must equal total - paid_ci_hi"
        )
        assert baseline_ci[1] == pytest.approx(max(0.0, total - paid_ci[0]), abs=1), (
            "baseline CI hi must equal total - paid_ci_lo"
        )
