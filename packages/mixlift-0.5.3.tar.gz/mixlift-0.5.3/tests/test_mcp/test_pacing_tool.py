"""Tool-level integration tests for mixlift_pacing MCP tool.

Tests cover: happy path, output structure, and all 10 spec edge cases.
No PyMC-Marketing involvement. Uses a fixed 'today' for determinism.
"""

from __future__ import annotations

import json
import pathlib

import pytest

from mixlift_mcp.server import mixlift_pacing

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_FIXTURES = pathlib.Path(__file__).parent.parent / "fixtures"
_PACING_CSV = str(_FIXTURES / "pacing_input.csv")

_PLAN = {"Meta": 80000.0, "Google Search": 60000.0, "TikTok": 30000.0}
_TODAY = "2026-04-15"


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


class TestHappyPath:
    @pytest.mark.asyncio
    async def test_returns_json_string(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            today=_TODAY,
        )
        result = json.loads(raw)
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_tool_field(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        assert result.get("tool") == "mixlift_pacing"

    @pytest.mark.asyncio
    async def test_version_field(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        assert result.get("version") == "0.5.3"

    @pytest.mark.asyncio
    async def test_plan_period_field(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        assert result.get("plan_period") == "month"

    @pytest.mark.asyncio
    async def test_today_field_echoed(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        assert result.get("today") == _TODAY

    @pytest.mark.asyncio
    async def test_top_level_keys_present(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        required_keys = {
            "tool",
            "version",
            "plan_period",
            "period_label",
            "today",
            "days_elapsed",
            "days_total",
            "days_remaining",
            "pct_elapsed",
            "total",
            "channels",
            "memo_markdown",
        }
        assert required_keys.issubset(set(result.keys()))

    @pytest.mark.asyncio
    async def test_total_subkeys_present(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        total = result["total"]
        required = {"budget", "spent", "pct_used", "projected_end", "variance", "variance_pct"}
        assert required.issubset(set(total.keys()))

    @pytest.mark.asyncio
    async def test_channel_subkeys_present(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        ch = result["channels"][0]
        required = {
            "name",
            "budget",
            "spent",
            "pct_used",
            "projected_end",
            "variance",
            "variance_pct",
            "current_daily_avg",
            "required_daily_to_hit_plan",
            "status",
        }
        assert required.issubset(set(ch.keys()))

    @pytest.mark.asyncio
    async def test_channels_sorted_abs_variance_desc(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        variances = [abs(c["variance"]) for c in result["channels"]]
        assert variances == sorted(variances, reverse=True)

    @pytest.mark.asyncio
    async def test_memo_markdown_non_empty(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        result = json.loads(raw)
        assert len(result.get("memo_markdown", "")) > 100

    @pytest.mark.asyncio
    async def test_deterministic_with_fixed_today(self):
        raw1 = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        raw2 = await mixlift_pacing(csv_path=_PACING_CSV, plan=_PLAN, today=_TODAY)
        assert raw1 == raw2


# ---------------------------------------------------------------------------
# Edge case 1: no plan
# ---------------------------------------------------------------------------


class TestEdgeCase1NoPlan:
    @pytest.mark.asyncio
    async def test_none_plan_is_error(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=None, today=_TODAY)
        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "plan" in result["message"].lower()

    @pytest.mark.asyncio
    async def test_error_message_instructs_user(self):
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=None, today=_TODAY)
        result = json.loads(raw)
        # Should tell the user how to supply a plan
        msg = result.get("message", "")
        has_plan = "plan" in msg.lower()
        has_instruction = "pass" in msg.lower() or "channel" in msg.lower() or "{" in msg
        assert has_plan and has_instruction


# ---------------------------------------------------------------------------
# Edge case 2: today outside data range
# ---------------------------------------------------------------------------


class TestEdgeCase2TodayOutsideRange:
    @pytest.mark.asyncio
    async def test_future_today_still_succeeds(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            today="2026-06-01",
        )
        result = json.loads(raw)
        # Should return a result (not error) with a footnote about the date mismatch
        # OR return a period-closed result — either is acceptable
        assert isinstance(result, dict)


# ---------------------------------------------------------------------------
# Edge case 3: channel in plan but not in data
# ---------------------------------------------------------------------------


class TestEdgeCase3PlanChannelMissingFromData:
    @pytest.mark.asyncio
    async def test_ghost_channel_shows_zero_spend(self):
        plan_with_ghost = dict(_PLAN)
        plan_with_ghost["LinkedIn"] = 20000.0
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=plan_with_ghost, today=_TODAY)
        result = json.loads(raw)
        assert result.get("tool") == "mixlift_pacing"
        linkedin = next((c for c in result["channels"] if c["name"] == "LinkedIn"), None)
        assert linkedin is not None
        assert linkedin["spent"] == 0.0


# ---------------------------------------------------------------------------
# Edge case 4: channel in data but not in plan
# ---------------------------------------------------------------------------


class TestEdgeCase4DataChannelMissingFromPlan:
    @pytest.mark.asyncio
    async def test_unlisted_channel_absent_from_results(self):
        single_plan = {"Meta": 80000.0}
        raw = await mixlift_pacing(csv_path=_PACING_CSV, plan=single_plan, today=_TODAY)
        result = json.loads(raw)
        names = [c["name"] for c in result.get("channels", [])]
        assert "Google Search" not in names
        assert "TikTok" not in names


# ---------------------------------------------------------------------------
# Edge case 5: today on day 1 of period
# ---------------------------------------------------------------------------


class TestEdgeCase5DayOneOfPeriod:
    @pytest.mark.asyncio
    async def test_day_one_no_error(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            today="2026-04-01",
        )
        result = json.loads(raw)
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_day_one_pct_elapsed_nonzero(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            today="2026-04-01",
        )
        result = json.loads(raw)
        if result.get("tool") == "mixlift_pacing":
            assert result["pct_elapsed"] > 0


# ---------------------------------------------------------------------------
# Edge case 6: today past period end
# ---------------------------------------------------------------------------


class TestEdgeCase6PeriodClosed:
    @pytest.mark.asyncio
    async def test_period_closed_verdict(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            today="2026-05-05",
        )
        result = json.loads(raw)
        if result.get("tool") == "mixlift_pacing":
            memo = result.get("memo_markdown", "")
            assert "Period closed" in memo or "actuals final" in memo.lower()

    @pytest.mark.asyncio
    async def test_period_closed_no_adjustment_table(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            today="2026-05-05",
        )
        result = json.loads(raw)
        if result.get("tool") == "mixlift_pacing":
            memo = result.get("memo_markdown", "")
            assert "### To land on plan" not in memo


# ---------------------------------------------------------------------------
# Edge case 7: negative actuals
# ---------------------------------------------------------------------------


class TestEdgeCase7NegativeActuals:
    @pytest.mark.asyncio
    async def test_negative_spend_is_error(self, tmp_path):
        csv_path = tmp_path / "neg.csv"
        csv_path.write_text("date,Meta\n2026-04-01,-500.00\n2026-04-02,1000.00\n")
        raw = await mixlift_pacing(
            csv_path=str(csv_path),
            plan={"Meta": 80000.0},
            today=_TODAY,
        )
        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "negative" in result["message"].lower()


# ---------------------------------------------------------------------------
# Edge case 8: empty CSV
# ---------------------------------------------------------------------------


class TestEdgeCase8EmptyCSV:
    @pytest.mark.asyncio
    async def test_empty_file_is_error(self, tmp_path):
        csv_path = tmp_path / "empty.csv"
        csv_path.write_text("")
        raw = await mixlift_pacing(
            csv_path=str(csv_path),
            plan=_PLAN,
            today=_TODAY,
        )
        result = json.loads(raw)
        assert result.get("status") == "error"

    @pytest.mark.asyncio
    async def test_header_only_is_error(self, tmp_path):
        csv_path = tmp_path / "hdr.csv"
        csv_path.write_text("date,Meta\n")
        raw = await mixlift_pacing(
            csv_path=str(csv_path),
            plan={"Meta": 80000.0},
            today=_TODAY,
        )
        result = json.loads(raw)
        assert result.get("status") == "error"


# ---------------------------------------------------------------------------
# Edge case 9: invalid plan_period
# ---------------------------------------------------------------------------


class TestEdgeCase9InvalidPlanPeriod:
    @pytest.mark.asyncio
    async def test_invalid_period_is_error(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="fortnight",
            today=_TODAY,
        )
        result = json.loads(raw)
        assert result.get("status") == "error"

    @pytest.mark.asyncio
    async def test_error_names_bad_value(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            plan_period="fortnight",
            today=_TODAY,
        )
        result = json.loads(raw)
        assert "fortnight" in result.get("message", "")


# ---------------------------------------------------------------------------
# Edge case 10: invalid today ISO date
# ---------------------------------------------------------------------------


class TestEdgeCase10InvalidTodayDate:
    @pytest.mark.asyncio
    async def test_invalid_date_is_error(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            today="not-a-date",
        )
        result = json.loads(raw)
        assert result.get("status") == "error"

    @pytest.mark.asyncio
    async def test_american_format_is_error(self):
        raw = await mixlift_pacing(
            csv_path=_PACING_CSV,
            plan=_PLAN,
            today="04/15/2026",
        )
        result = json.loads(raw)
        assert result.get("status") == "error"
