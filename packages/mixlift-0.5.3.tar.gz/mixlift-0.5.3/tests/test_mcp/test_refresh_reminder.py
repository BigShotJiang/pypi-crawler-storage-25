"""N8: Monthly refresh reminder tests.

Verifies that stale analyses are detected and surfaced via MCP resource.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from unittest.mock import patch

from mixlift_mcp.memory import check_stale_analyses
from mixlift_mcp.server import mixlift_status


class TestCheckStaleAnalyses:
    """Test memory scanning for stale analyses."""

    def test_no_memory_dir(self, tmp_path):
        nonexistent = tmp_path / "nonexistent"
        with patch("mixlift_mcp.memory.MEMORY_DIR", nonexistent):
            result = check_stale_analyses()
        assert result == []

    def test_empty_memory_dir(self, tmp_path):
        mem_dir = tmp_path / "memory"
        mem_dir.mkdir()
        with patch("mixlift_mcp.memory.MEMORY_DIR", mem_dir):
            result = check_stale_analyses()
        assert result == []

    def test_fresh_analysis_not_stale(self, tmp_path):
        mem_dir = tmp_path / "memory"
        mem_dir.mkdir()
        # Create a fresh analysis (today)
        data = {
            "fingerprint": "abc123",
            "dataset_label": "ads.csv",
            "analyses": [
                {
                    "timestamp": datetime.now().isoformat(),
                    "channels": ["Meta", "Google"],
                    "roas": {},
                }
            ],
        }
        (mem_dir / "abc123.json").write_text(json.dumps(data))

        with patch("mixlift_mcp.memory.MEMORY_DIR", mem_dir):
            result = check_stale_analyses(max_age_days=30)
        assert result == []

    def test_stale_analysis_detected(self, tmp_path):
        mem_dir = tmp_path / "memory"
        mem_dir.mkdir()
        # Create an analysis from 45 days ago
        old_date = datetime.now() - timedelta(days=45)
        data = {
            "fingerprint": "abc123",
            "dataset_label": "ads.csv",
            "analyses": [
                {
                    "timestamp": old_date.isoformat(),
                    "channels": ["Meta", "Google"],
                    "roas": {},
                }
            ],
        }
        (mem_dir / "abc123.json").write_text(json.dumps(data))

        with patch("mixlift_mcp.memory.MEMORY_DIR", mem_dir):
            result = check_stale_analyses(max_age_days=30)

        assert len(result) == 1
        assert result[0]["dataset"] == "ads.csv"
        assert result[0]["age_days"] >= 45

    def test_multiple_datasets_mixed_staleness(self, tmp_path):
        mem_dir = tmp_path / "memory"
        mem_dir.mkdir()

        # Fresh
        fresh = {
            "fingerprint": "fresh1",
            "dataset_label": "fresh.csv",
            "analyses": [{"timestamp": datetime.now().isoformat(), "channels": ["A"]}],
        }
        (mem_dir / "fresh1.json").write_text(json.dumps(fresh))

        # Stale
        old_date = datetime.now() - timedelta(days=60)
        stale = {
            "fingerprint": "stale1",
            "dataset_label": "stale.csv",
            "analyses": [{"timestamp": old_date.isoformat(), "channels": ["B", "C"]}],
        }
        (mem_dir / "stale1.json").write_text(json.dumps(stale))

        with patch("mixlift_mcp.memory.MEMORY_DIR", mem_dir):
            result = check_stale_analyses(max_age_days=30)

        assert len(result) == 1
        assert result[0]["dataset"] == "stale.csv"

    def test_uses_latest_analysis_timestamp(self, tmp_path):
        mem_dir = tmp_path / "memory"
        mem_dir.mkdir()
        # Multiple analyses — latest is fresh
        old_date = datetime.now() - timedelta(days=60)
        data = {
            "fingerprint": "abc123",
            "dataset_label": "ads.csv",
            "analyses": [
                {"timestamp": old_date.isoformat(), "channels": ["Meta"]},
                {"timestamp": datetime.now().isoformat(), "channels": ["Meta"]},
            ],
        }
        (mem_dir / "abc123.json").write_text(json.dumps(data))

        with patch("mixlift_mcp.memory.MEMORY_DIR", mem_dir):
            result = check_stale_analyses(max_age_days=30)
        assert result == []


class TestMixliftStatusResource:
    """Test the MCP resource that surfaces refresh reminders."""

    def test_no_stale_analyses(self, tmp_path):
        mem_dir = tmp_path / "memory"
        mem_dir.mkdir()
        with patch("mixlift_mcp.memory.MEMORY_DIR", mem_dir):
            result = mixlift_status()
        assert "up to date" in result

    def test_stale_analysis_surfaces(self, tmp_path):
        mem_dir = tmp_path / "memory"
        mem_dir.mkdir()
        old_date = datetime.now() - timedelta(days=35)
        data = {
            "fingerprint": "abc123",
            "dataset_label": "campaign_data.csv",
            "analyses": [
                {
                    "timestamp": old_date.isoformat(),
                    "channels": ["Meta", "Google"],
                }
            ],
        }
        (mem_dir / "abc123.json").write_text(json.dumps(data))

        with patch("mixlift_mcp.memory.MEMORY_DIR", mem_dir):
            result = mixlift_status()

        assert "campaign_data.csv" in result
        assert "re-analysis" in result
