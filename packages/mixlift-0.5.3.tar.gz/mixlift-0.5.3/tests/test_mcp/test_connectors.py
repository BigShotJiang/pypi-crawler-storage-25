"""Tests for MixLift ad platform connectors and utility functions."""

from __future__ import annotations

import json
from datetime import date
from unittest.mock import AsyncMock, MagicMock

import pandas as pd
import pytest

from mixlift_mcp.connectors.base import (
    ConnectorResult,
    DateRange,
    save_wide_csv,
    to_wide_format,
)
from mixlift_mcp.connectors.google import GoogleConnector
from mixlift_mcp.connectors.meta import MetaConnector
from mixlift_mcp.connectors.tiktok import TikTokConnector
from mixlift_mcp.license import free_tier

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_META_INSIGHTS = [
    {
        "date_start": "2024-06-01",
        "campaign_name": "Prospecting",
        "spend": "150.50",
        "impressions": "5000",
        "clicks": "200",
        "actions": [{"action_type": "purchase", "value": "15"}],
        "action_values": [{"action_type": "purchase", "value": "450.00"}],
    },
    {
        "date_start": "2024-06-02",
        "campaign_name": "Retargeting",
        "spend": "100.25",
        "impressions": "3000",
        "clicks": "150",
        "action_values": [{"action_type": "purchase", "value": "320.00"}],
    },
]

_TIKTOK_RESPONSE = {
    "code": 0,
    "data": {
        "list": [
            {
                "dimensions": {"stat_time_day": "2024-06-01"},
                "metrics": {
                    "spend": "150.50",
                    "impressions": "5000",
                    "clicks": "200",
                    "complete_payment": "15",
                    "value_per_complete_payment": "30.00",
                },
            },
        ],
        "page_info": {"total_page": 1, "page": 1},
    },
}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_meta_sdk(monkeypatch):
    """Mock the facebook_business SDK."""
    mock_api = MagicMock()
    mock_account_cls = MagicMock()

    monkeypatch.setattr(
        "mixlift_mcp.connectors.meta._require_sdk",
        lambda: (mock_api, mock_account_cls),
    )
    return mock_api, mock_account_cls


@pytest.fixture
def mock_google_sdk(monkeypatch):
    """Mock the google-ads SDK."""
    mock_cls = MagicMock()
    monkeypatch.setattr(
        "mixlift_mcp.connectors.google._require_sdk",
        lambda: mock_cls,
    )
    return mock_cls


@pytest.fixture
def mock_tiktok_api(monkeypatch):
    """Mock TikTok API responses via httpx.AsyncClient.

    Note: TikTokConnector calls resp.json() synchronously (not await), so
    mock_response.json must be a regular MagicMock, not an AsyncMock.
    """
    mock_response = MagicMock()
    mock_response.json = MagicMock(return_value=_TIKTOK_RESPONSE)

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.post = AsyncMock(return_value=mock_response)

    monkeypatch.setattr("httpx.AsyncClient", lambda **kwargs: mock_client)
    return mock_client


def _make_connector_result(
    channel: str, dates: list[str], spend: float, revenue: float
) -> ConnectorResult:
    """Build a minimal ConnectorResult for testing utility functions."""
    df = pd.DataFrame({
        "date": pd.to_datetime(dates),
        "channel": channel,
        "spend": spend,
        "revenue": revenue,
    })
    dr = DateRange(start=date.fromisoformat(dates[0]), end=date.fromisoformat(dates[-1]))
    return ConnectorResult(
        platform=channel.lower(),
        df=df,
        date_range=dr,
        channels_found=[channel],
        row_count=len(df),
    )


# ---------------------------------------------------------------------------
# TestDateRange
# ---------------------------------------------------------------------------


class TestDateRange:
    def test_empty_defaults_to_180_days(self):
        dr = DateRange.from_spec("")
        today = date.today()
        assert dr.end == today
        assert (dr.end - dr.start).days == 180

    def test_last_n_days(self):
        dr = DateRange.from_spec("last_90_days")
        today = date.today()
        assert dr.end == today
        assert (dr.end - dr.start).days == 90

    def test_explicit_range(self):
        dr = DateRange.from_spec("2024-01-01:2024-06-30")
        assert dr.start == date(2024, 1, 1)
        assert dr.end == date(2024, 6, 30)

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="Invalid date range"):
            DateRange.from_spec("foobar")


# ---------------------------------------------------------------------------
# TestToWideFormat
# ---------------------------------------------------------------------------


class TestToWideFormat:
    def test_single_platform(self):
        result = _make_connector_result("Meta", ["2024-06-01", "2024-06-02"], 100.0, 400.0)
        wide = to_wide_format([result])

        assert "meta_spend" in wide.columns
        assert "revenue" in wide.columns
        assert len(wide) == 2
        assert wide["meta_spend"].iloc[0] == pytest.approx(100.0)

    def test_multiple_platforms(self):
        meta = _make_connector_result("Meta", ["2024-06-01", "2024-06-02"], 100.0, 400.0)
        google = _make_connector_result("Google", ["2024-06-01", "2024-06-02"], 200.0, 600.0)
        wide = to_wide_format([meta, google])

        assert "meta_spend" in wide.columns
        assert "google_spend" in wide.columns
        assert "revenue" in wide.columns
        assert len(wide) == 2
        # Revenue is summed across platforms per day
        assert wide["revenue"].iloc[0] == pytest.approx(400.0 + 600.0)

    def test_handles_date_alignment(self):
        # Meta has 3 days, Google has 2 overlapping days — result should have 3 rows
        meta = _make_connector_result(
            "Meta", ["2024-06-01", "2024-06-02", "2024-06-03"], 100.0, 300.0
        )
        google = _make_connector_result("Google", ["2024-06-02", "2024-06-03"], 200.0, 500.0)
        wide = to_wide_format([meta, google])

        assert len(wide) == 3
        assert "meta_spend" in wide.columns
        assert "google_spend" in wide.columns
        # On 2024-06-01 Google has no spend — should be 0 (fillna)
        june1_row = wide[wide["date"] == pd.Timestamp("2024-06-01")]
        assert june1_row["google_spend"].iloc[0] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# TestSaveWideCsv
# ---------------------------------------------------------------------------


class TestSaveWideCsv:
    def test_creates_file(self, tmp_path):
        df = pd.DataFrame({
            "date": pd.to_datetime(["2024-06-01", "2024-06-02"]),
            "meta_spend": [100.0, 110.0],
            "revenue": [400.0, 420.0],
        })
        filepath = save_wide_csv(df, str(tmp_path), label="test")
        assert filepath.exists()

    def test_csv_readable(self, tmp_path):
        df = pd.DataFrame({
            "date": pd.to_datetime(["2024-06-01", "2024-06-02"]),
            "meta_spend": [100.0, 110.0],
            "revenue": [400.0, 420.0],
        })
        filepath = save_wide_csv(df, str(tmp_path), label="readable")
        loaded = pd.read_csv(filepath)
        assert set(loaded.columns) >= {"date", "meta_spend", "revenue"}
        assert len(loaded) == 2


# ---------------------------------------------------------------------------
# TestMetaConnector
# ---------------------------------------------------------------------------


class TestMetaConnector:
    async def test_pull_platform_granularity(self, mock_meta_sdk):
        mock_api, mock_account_cls = mock_meta_sdk

        # Configure mock account.get_insights to return our sample data
        mock_account = MagicMock()
        mock_account.get_insights.return_value = _META_INSIGHTS
        mock_account_cls.return_value = mock_account

        connector = MetaConnector(access_token="fake-token")
        dr = DateRange(start=date(2024, 6, 1), end=date(2024, 6, 2))
        result = await connector.pull(account_id="123456789", date_range=dr, granularity="platform")

        assert result.platform == "meta"
        assert result.row_count > 0
        assert result.channels_found == ["Meta"]
        assert set(result.df.columns) == {"date", "channel", "spend", "revenue"}
        assert result.df["spend"].sum() == pytest.approx(150.50 + 100.25)
        assert result.df["revenue"].sum() == pytest.approx(450.00 + 320.00)

    async def test_pull_empty_result(self, mock_meta_sdk):
        mock_api, mock_account_cls = mock_meta_sdk

        mock_account = MagicMock()
        mock_account.get_insights.return_value = []
        mock_account_cls.return_value = mock_account

        connector = MetaConnector(access_token="fake-token")
        dr = DateRange(start=date(2024, 6, 1), end=date(2024, 6, 2))
        result = await connector.pull(account_id="123456789", date_range=dr)

        assert result.row_count == 0
        assert result.channels_found == []
        assert len(result.df) == 0


# ---------------------------------------------------------------------------
# TestGoogleConnector
# ---------------------------------------------------------------------------


class TestGoogleConnector:
    def _make_google_creds(self) -> str:
        return json.dumps({
            "developer_token": "dev-token",
            "client_id": "client-id",
            "client_secret": "client-secret",
            "refresh_token": "refresh-token",
        })

    def _make_mock_row(
        self, date_str: str, cost_micros: int, conversions_value: float
    ) -> MagicMock:
        mock_row = MagicMock()
        mock_row.segments.date = date_str
        mock_row.metrics.cost_micros = cost_micros
        mock_row.metrics.conversions_value = conversions_value
        mock_row.campaign.name = "Search"
        return mock_row

    async def test_pull_platform_granularity(self, mock_google_sdk):
        mock_row = self._make_mock_row("2024-06-01", 150_500_000, 450.0)

        mock_batch = MagicMock()
        mock_batch.results = [mock_row]

        mock_service = MagicMock()
        mock_service.search_stream.return_value = [mock_batch]

        mock_client = MagicMock()
        mock_client.get_service.return_value = mock_service
        mock_google_sdk.load_from_dict.return_value = mock_client

        connector = GoogleConnector(access_token=self._make_google_creds())
        dr = DateRange(start=date(2024, 6, 1), end=date(2024, 6, 1))
        result = await connector.pull(
            account_id="123-456-7890", date_range=dr, granularity="platform"
        )

        assert result.platform == "google"
        assert result.row_count == 1
        assert result.channels_found == ["Google"]
        assert set(result.df.columns) == {"date", "channel", "spend", "revenue"}
        assert result.df["spend"].iloc[0] == pytest.approx(150.50)
        assert result.df["revenue"].iloc[0] == pytest.approx(450.0)

    async def test_pull_empty_result(self, mock_google_sdk):
        mock_batch = MagicMock()
        mock_batch.results = []

        mock_service = MagicMock()
        mock_service.search_stream.return_value = [mock_batch]

        mock_client = MagicMock()
        mock_client.get_service.return_value = mock_service
        mock_google_sdk.load_from_dict.return_value = mock_client

        connector = GoogleConnector(access_token=self._make_google_creds())
        dr = DateRange(start=date(2024, 6, 1), end=date(2024, 6, 1))
        result = await connector.pull(account_id="123-456-7890", date_range=dr)

        assert result.row_count == 0
        assert result.channels_found == []
        assert len(result.df) == 0


# ---------------------------------------------------------------------------
# TestTikTokConnector
# ---------------------------------------------------------------------------


class TestTikTokConnector:
    async def test_pull_platform_granularity(self, mock_tiktok_api):
        connector = TikTokConnector(access_token="fake-token")
        dr = DateRange(start=date(2024, 6, 1), end=date(2024, 6, 1))
        result = await connector.pull(account_id="987654321", date_range=dr, granularity="platform")

        assert result.platform == "tiktok"
        assert result.row_count == 1
        assert result.channels_found == ["TikTok"]
        assert set(result.df.columns) == {"date", "channel", "spend", "revenue"}
        assert result.df["spend"].iloc[0] == pytest.approx(150.50)
        # 15 purchases * $30.00 avg value = $450.00
        assert result.df["revenue"].iloc[0] == pytest.approx(450.00)

    async def test_pull_empty_result(self, mock_tiktok_api, monkeypatch):
        empty_response = MagicMock()
        empty_response.json = MagicMock(return_value={
            "code": 0,
            "data": {
                "list": [],
                "page_info": {"total_page": 1, "page": 1},
            },
        })

        mock_tiktok_api.post = AsyncMock(return_value=empty_response)

        connector = TikTokConnector(access_token="fake-token")
        dr = DateRange(start=date(2024, 6, 1), end=date(2024, 6, 1))
        result = await connector.pull(account_id="987654321", date_range=dr)

        assert result.row_count == 0
        assert result.channels_found == []
        assert len(result.df) == 0


# ---------------------------------------------------------------------------
# TestMixliftConnectTool
# ---------------------------------------------------------------------------


try:
    import importlib.util

    _CONNECT_AVAILABLE = importlib.util.find_spec("mixlift_mcp.server") is not None
    # Verify the symbol actually exists in the module
    from mixlift_mcp.server import mixlift_connect  # noqa: F401

    _CONNECT_AVAILABLE = True
except (ImportError, AttributeError):
    _CONNECT_AVAILABLE = False

_skip_connect = pytest.mark.skipif(
    not _CONNECT_AVAILABLE,
    reason="mixlift_connect tool not yet implemented in server.py",
)


@_skip_connect
class TestMixliftConnectTool:
    async def test_free_tier_rejected(self, monkeypatch):
        monkeypatch.setattr(
            "mixlift_mcp.server.validate_license",
            AsyncMock(return_value=free_tier("No license key provided")),
        )
        from mixlift_mcp.server import mixlift_connect

        result_json = await mixlift_connect(
            platform="meta",
            account_id="123456",
            access_token="fake-token",
            license_key="",
        )
        result = json.loads(result_json)
        assert result["status"] == "error"
        assert "free" in result["message"].lower() or "upgrade" in result["message"].lower()

    async def test_unsupported_platform(self, monkeypatch):
        from mixlift_mcp.license import _pro_tier

        monkeypatch.setattr(
            "mixlift_mcp.server.validate_license",
            AsyncMock(return_value=_pro_tier()),
        )
        from mixlift_mcp.server import mixlift_connect

        result_json = await mixlift_connect(
            platform="linkedin",
            account_id="123456",
            access_token="fake-token",
            license_key="pro-key",
        )
        result = json.loads(result_json)
        assert result["status"] == "error"
        assert "linkedin" in result["message"].lower() or "unsupported" in result["message"].lower()


# ---------------------------------------------------------------------------
# TestMixliftConnectMultiTool
# ---------------------------------------------------------------------------


try:
    from mixlift_mcp.server import mixlift_connect_multi  # noqa: F401

    _CONNECT_MULTI_AVAILABLE = True
except (ImportError, AttributeError):
    _CONNECT_MULTI_AVAILABLE = False

_skip_connect_multi = pytest.mark.skipif(
    not _CONNECT_MULTI_AVAILABLE,
    reason="mixlift_connect_multi tool not yet implemented in server.py",
)


@_skip_connect_multi
class TestMixliftConnectMultiTool:
    async def test_free_tier_rejected(self, monkeypatch):
        monkeypatch.setattr(
            "mixlift_mcp.server.validate_license",
            AsyncMock(return_value=free_tier("No license key provided")),
        )
        from mixlift_mcp.server import mixlift_connect_multi

        result_json = await mixlift_connect_multi(
            connections=json.dumps([
                {"platform": "meta", "account_id": "123", "access_token": "tok"}
            ]),
            license_key="",
        )
        result = json.loads(result_json)
        assert result["status"] == "error"
        assert "free" in result["message"].lower() or "upgrade" in result["message"].lower()

    async def test_invalid_connections_json(self, monkeypatch):
        from mixlift_mcp.license import _pro_tier

        monkeypatch.setattr(
            "mixlift_mcp.server.validate_license",
            AsyncMock(return_value=_pro_tier()),
        )
        from mixlift_mcp.server import mixlift_connect_multi

        result_json = await mixlift_connect_multi(
            connections="this is not valid json {{{",
            license_key="pro-key",
        )
        result = json.loads(result_json)
        assert result["status"] == "error"
