"""Tool-level integration tests for mixlift_saturation.

All tests mock _run_pipeline, _run_saturation_curves, and _run_marginal_roas
so no actual MCMC fit is executed.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.license import LicenseStatus
from mixlift_mcp.server import mixlift_saturation  # noqa: E402

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def wide_csv_3ch(tmp_path):
    """3-channel wide-format CSV, 30 weeks."""
    n = 30
    dates = pd.date_range("2025-04-07", periods=n, freq="W-MON")
    rng = np.random.default_rng(42)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n),
            "google_search_spend": rng.uniform(3000, 10000, n),
            "tiktok_spend": rng.uniform(1000, 5000, n),
            "revenue": rng.uniform(50000, 150000, n),
        }
    )
    path = tmp_path / "wide_3ch.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def mock_pro_license():
    return LicenseStatus(is_pro=True, max_channels=999, max_rows=999_999, message="Pro")


@pytest.fixture
def mock_free_license():
    return LicenseStatus(is_pro=False, max_channels=2, max_rows=2000, message="Free")


def _make_mock_model_results(channels=None):
    """Build a minimal ModelResults mock."""
    if channels is None:
        channels = ["meta_spend", "google_search_spend", "tiktok_spend"]
    mr = MagicMock()
    mr.mmm = MagicMock()
    mr.roas_estimates = {c: 1.5 for c in channels}
    mr.roas_ci = {c: (0.8, 2.2) for c in channels}
    mr.marginal_roas_estimates = {c: 1.2 for c in channels}
    mr.marginal_roas_ci = {c: (0.6, 1.8) for c in channels}
    mr.channel_contributions = {c: 30000.0 for c in channels}
    mr.channel_contributions_ci = {c: (20000.0, 40000.0) for c in channels}
    mr.total_spend = {c: 10000.0 for c in channels}
    mr.duration_secs = 5.0
    mr.convergence_warnings = []
    mr.raw_contributions = MagicMock()
    mr.loo_cv = {}
    mr.intercept_decomposition = {}
    return mr


def _make_mock_saturation_curves(channel_columns):
    """Build synthetic saturation curves for the given column names."""
    from mixlift.modeling.optimizer import format_channel_name

    curves = {}
    for col in channel_columns:
        display = format_channel_name(col)
        spend = [float(i * 500) for i in range(100)]
        response = [s * 0.9 * (1 - s / 50000.0) for s in spend]
        curves[display] = {"spend": spend, "response": response}
    return curves


def _make_mock_marginal_roas(channel_columns):
    """Build synthetic marginal ROAS dicts for the given column names."""
    from mixlift.modeling.optimizer import format_channel_name

    means = {}
    cis = {}
    for col in channel_columns:
        display = format_channel_name(col)
        means[display] = 1.2
        cis[display] = (0.6, 1.8)
    return means, cis


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


class TestMixliftSaturationHappyPath:
    @pytest.mark.asyncio
    async def test_returns_dict_with_required_keys(self, wide_csv_3ch, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_curves = _make_mock_saturation_curves(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch("mixlift_mcp.server._run_saturation_curves", return_value=mock_curves),
            patch("mixlift_mcp.server._run_marginal_roas", return_value=(mock_means, mock_cis)),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_saturation(csv_path=wide_csv_3ch)

        assert isinstance(raw, str)
        result = json.loads(raw)
        assert result.get("tool") == "mixlift_saturation"
        assert result.get("version") == "0.5.3"
        assert "channels" in result
        assert "memo_markdown" in result
        assert "data_window" in result

    @pytest.mark.asyncio
    async def test_channels_have_required_keys(self, wide_csv_3ch, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_curves = _make_mock_saturation_curves(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch("mixlift_mcp.server._run_saturation_curves", return_value=mock_curves),
            patch("mixlift_mcp.server._run_marginal_roas", return_value=(mock_means, mock_cis)),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_saturation(csv_path=wide_csv_3ch)

        result = json.loads(raw)
        required_ch_keys = {
            "name",
            "current_spend_wk",
            "saturation_pct",
            "status",
            "marginal_roas_current",
            "marginal_roas_ci",
            "efficient_frontier_spend",
            "next_dollar_returns",
            "if_decrease_returns",
            "curve_points",
            "extrapolated",
            "extrapolated_frontier",
            "low_confidence",
        }
        for ch in result["channels"]:
            missing = required_ch_keys - set(ch.keys())
            assert missing == set(), f"Missing keys in channel {ch['name']}: {missing}"

    @pytest.mark.asyncio
    async def test_memo_markdown_is_non_empty_string(self, wide_csv_3ch, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_curves = _make_mock_saturation_curves(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch("mixlift_mcp.server._run_saturation_curves", return_value=mock_curves),
            patch("mixlift_mcp.server._run_marginal_roas", return_value=(mock_means, mock_cis)),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_saturation(csv_path=wide_csv_3ch)

        result = json.loads(raw)
        assert isinstance(result["memo_markdown"], str)
        assert len(result["memo_markdown"]) > 50

    @pytest.mark.asyncio
    async def test_default_increment_steps_applied(self, wide_csv_3ch, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_curves = _make_mock_saturation_curves(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch("mixlift_mcp.server._run_saturation_curves", return_value=mock_curves),
            patch("mixlift_mcp.server._run_marginal_roas", return_value=(mock_means, mock_cis)),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_saturation(csv_path=wide_csv_3ch)

        result = json.loads(raw)
        for ch in result["channels"]:
            ndr_keys = set(ch["next_dollar_returns"].keys())
            # At least some of the default steps should be present
            assert ndr_keys & {"1000", "5000", "10000", "25000"}


# ---------------------------------------------------------------------------
# Cache behavior (edge case 6)
# ---------------------------------------------------------------------------


class TestCacheBehavior:
    @pytest.mark.asyncio
    async def test_cache_hit_skips_pipeline(self, wide_csv_3ch, mock_pro_license):
        """When disk cache returns a model, _run_pipeline must not be called."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mmm = MagicMock()
        n = 30
        rng = np.random.default_rng(42)
        x_cached = pd.DataFrame(
            {  # noqa: N806
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "tiktok_spend": rng.uniform(1000, 5000, n),
            }
        )

        disk_cache_entry = {
            "mmm": mock_mmm,
            "X": x_cached,
            "channel_columns": channel_columns,
            "model_results": _make_mock_model_results(channel_columns),
            "result": {},
        }

        mock_curves = _make_mock_saturation_curves(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline") as mock_pipeline,
            patch("mixlift_mcp.server._run_saturation_curves", return_value=mock_curves),
            patch("mixlift_mcp.server._run_marginal_roas", return_value=(mock_means, mock_cis)),
            patch(
                "mixlift_mcp.model_cache.load_model",
                new_callable=AsyncMock,
                return_value=disk_cache_entry,
            ),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_saturation(csv_path=wide_csv_3ch)

        mock_pipeline.assert_not_called()
        assert isinstance(raw, str)
        result = json.loads(raw)
        assert "channels" in result


# ---------------------------------------------------------------------------
# Error paths
# ---------------------------------------------------------------------------


class TestErrorPaths:
    @pytest.mark.asyncio
    async def test_missing_csv_returns_error(self, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            raw = await mixlift_saturation(csv_path="/nonexistent/path.csv")
        result = json.loads(raw)
        assert result.get("status") == "error"
        assert "not found" in result.get("message", "").lower()

    @pytest.mark.asyncio
    async def test_unknown_channel_filter_warns_and_skips(self, wide_csv_3ch, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_curves = _make_mock_saturation_curves(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch("mixlift_mcp.server._run_saturation_curves", return_value=mock_curves),
            patch("mixlift_mcp.server._run_marginal_roas", return_value=(mock_means, mock_cis)),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            # Pass channels including one that doesn't exist
            raw = await mixlift_saturation(
                csv_path=wide_csv_3ch,
                channels=["meta_spend", "podcast_spend"],  # podcast_spend not in CSV
            )

        # Should succeed, not error
        result = json.loads(raw)
        assert result.get("status") != "error"
        # Only meta_spend should appear
        channel_names = [ch["name"] for ch in result["channels"]]
        assert any("Meta" in n for n in channel_names)

    @pytest.mark.asyncio
    async def test_custom_increment_steps_used(self, wide_csv_3ch, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_curves = _make_mock_saturation_curves(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch("mixlift_mcp.server._run_saturation_curves", return_value=mock_curves),
            patch("mixlift_mcp.server._run_marginal_roas", return_value=(mock_means, mock_cis)),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_saturation(
                csv_path=wide_csv_3ch,
                increment_steps=[2000, 8000],
            )

        result = json.loads(raw)
        for ch in result["channels"]:
            ndr_keys = set(ch["next_dollar_returns"].keys())
            # Should have our custom steps
            assert "2000" in ndr_keys or "8000" in ndr_keys


# ---------------------------------------------------------------------------
# Version check
# ---------------------------------------------------------------------------


class TestVersionField:
    @pytest.mark.asyncio
    async def test_version_is_0_5_3(self, wide_csv_3ch, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_curves = _make_mock_saturation_curves(channel_columns)
        mock_means, mock_cis = _make_mock_marginal_roas(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch("mixlift_mcp.server._run_saturation_curves", return_value=mock_curves),
            patch("mixlift_mcp.server._run_marginal_roas", return_value=(mock_means, mock_cis)),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            raw = await mixlift_saturation(csv_path=wide_csv_3ch)

        result = json.loads(raw)
        assert result["version"] == "0.5.3"
