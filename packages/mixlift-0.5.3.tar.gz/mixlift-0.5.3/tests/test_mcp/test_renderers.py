"""Unit tests for mixlift_mcp.renderers._helpers and scenario_memo."""

from __future__ import annotations

import math
import re
from unittest.mock import patch

from mixlift_mcp.renderers._helpers import (
    channel_display_name,
    fmt_dollars,
    fmt_pct,
    fmt_roas,
    safe_dict,
    unicode_bar,
)
from mixlift_mcp.renderers.scenario_memo import render_scenario_memo

# ---------------------------------------------------------------------------
# unicode_bar
# ---------------------------------------------------------------------------

FULL = "\u2588"
HALF = "\u258c"
THIN = "\u258f"


class TestUnicodeBar:
    def test_full_magnitude_equals_max(self):
        result = unicode_bar(8, 8, width=8)
        assert result == FULL * 8

    def test_zero_magnitude_returns_spaces(self):
        result = unicode_bar(0, 8, width=8)
        assert result == " " * 8

    def test_max_zero_returns_spaces(self):
        result = unicode_bar(5, 0, width=8)
        assert result == " " * 8

    def test_max_negative_returns_spaces(self):
        result = unicode_bar(5, -10, width=8)
        assert result == " " * 8

    def test_max_nan_returns_spaces(self):
        result = unicode_bar(5, math.nan, width=8)
        assert result == " " * 8

    def test_tiny_positive_magnitude_shows_thin_glyph(self):
        # 0.0001 / 1.0 * 8 = 0.0008 cells — below 1/8 threshold, forced to thin
        result = unicode_bar(0.0001, 1.0, width=8)
        assert THIN in result
        assert len(result) == 8

    def test_exactly_half_filled(self):
        # 4/8 = 0.5 ratio → 4 full blocks, remainder 0 < 0.375, no half glyph
        result = unicode_bar(4, 8, width=8)
        assert result == FULL * 4 + " " * 4

    def test_4_5_over_8_includes_half_glyph(self):
        # 4.5/8 ratio → cells=4.5, whole=4, remainder=0.5 >= 0.375 → half glyph
        result = unicode_bar(4.5, 8, width=8)
        assert result == FULL * 4 + HALF + " " * 3

    def test_4_25_over_8_no_half_glyph(self):
        # 4.25/8 ratio → cells=4.25, whole=4, remainder=0.25 < 0.375 → no half
        result = unicode_bar(4.25, 8, width=8)
        assert result == FULL * 4 + " " * 4

    def test_negative_magnitude_uses_absolute_value(self):
        result_pos = unicode_bar(4, 8, width=8)
        result_neg = unicode_bar(-4, 8, width=8)
        assert result_pos == result_neg

    def test_output_length_always_equals_width(self):
        cases = [
            (0, 8),
            (1, 8),
            (8, 8),
            (0.0001, 1.0),
            (4.5, 8),
            (5, 0),
            (5, math.nan),
        ]
        for mag, mx in cases:
            result = unicode_bar(mag, mx, width=8)
            assert len(result) == 8, f"Failed for magnitude={mag}, max={mx}: {repr(result)}"

    def test_custom_width(self):
        result = unicode_bar(5, 5, width=12)
        assert len(result) == 12
        assert result == FULL * 12


# ---------------------------------------------------------------------------
# fmt_dollars
# ---------------------------------------------------------------------------

MINUS = "\u2212"


class TestFmtDollars:
    def test_int_unsigned(self):
        assert fmt_dollars(1234) == "$1,234"

    def test_float_truncated_no_decimals(self):
        assert fmt_dollars(1234.56) == "$1,234"

    def test_negative_signed(self):
        result = fmt_dollars(-1234, signed=True)
        assert result == f"{MINUS}$1,234"

    def test_positive_signed(self):
        result = fmt_dollars(1234, signed=True)
        assert result == "+$1,234"

    def test_string_passthrough(self):
        msg = "Upgrade to Growth"
        assert fmt_dollars(msg) == msg

    def test_zero_unsigned(self):
        assert fmt_dollars(0) == "$0"

    def test_zero_signed(self):
        # Zero is non-negative, so gets "+" prefix
        assert fmt_dollars(0, signed=True) == "+$0"

    def test_large_value_thousands_separator(self):
        assert fmt_dollars(1_000_000) == "$1,000,000"


# ---------------------------------------------------------------------------
# fmt_roas
# ---------------------------------------------------------------------------

TIMES = "\u00d7"
EMDASH = "\u2014"


class TestFmtRoas:
    def test_uses_times_sign_not_lowercase_x(self):
        result = fmt_roas(24.60)
        assert TIMES in result
        assert "x" not in result

    def test_two_decimal_places(self):
        assert fmt_roas(24.60) == f"24.60{TIMES}"

    def test_none_returns_emdash(self):
        assert fmt_roas(None) == EMDASH

    def test_nan_returns_emdash(self):
        assert fmt_roas(math.nan) == EMDASH

    def test_zero_renders(self):
        assert fmt_roas(0.0) == f"0.00{TIMES}"


# ---------------------------------------------------------------------------
# fmt_pct
# ---------------------------------------------------------------------------


class TestFmtPct:
    def test_signed_positive(self):
        result = fmt_pct(12.1)
        assert result == "+12.1%"

    def test_signed_negative_uses_real_minus(self):
        result = fmt_pct(-3.5)
        assert result == f"{MINUS}3.5%"
        assert "-" not in result  # no ASCII hyphen-minus

    def test_unsigned(self):
        result = fmt_pct(12.1, signed=False)
        assert result == "12.1%"

    def test_precision_parameter(self):
        result = fmt_pct(12.1234, precision=3)
        assert result == "+12.123%"

    def test_precision_zero(self):
        result = fmt_pct(12.7, precision=0)
        assert result == "+13%"


# ---------------------------------------------------------------------------
# channel_display_name
# ---------------------------------------------------------------------------


class TestChannelDisplayName:
    def test_delegates_to_format_channel_name(self):
        # The function uses a lazy import, so patch at the source module.
        with patch(
            "mixlift.modeling.optimizer.format_channel_name",
            return_value="MockChannel",
        ) as mock_fn:
            result = channel_display_name("some_spend")
            mock_fn.assert_called_once_with("some_spend")
        assert result == "MockChannel"

    def test_tiktok_override(self):
        # Real optimizer has a special-case override for "tiktok"
        result = channel_display_name("tiktok_spend")
        assert result == "TikTok"

    def test_title_case_fallback(self):
        # No override for "email_spend" → "Email"
        result = channel_display_name("email_spend")
        assert result == "Email"


# ---------------------------------------------------------------------------
# safe_dict
# ---------------------------------------------------------------------------


class TestSafeDict:
    def test_dict_returns_same_dict(self):
        d = {"a": 1, "b": 2}
        assert safe_dict(d) is d

    def test_string_returns_empty_dict(self):
        assert safe_dict("Upgrade to Growth ($299/mo) to see optimal spend") == {}

    def test_none_returns_empty_dict(self):
        assert safe_dict(None) == {}

    def test_int_returns_empty_dict(self):
        assert safe_dict(42) == {}

    def test_empty_dict_returns_empty_dict(self):
        assert safe_dict({}) == {}


# ---------------------------------------------------------------------------
# TestAnalyzeMemo
# ---------------------------------------------------------------------------

import re as _re  # noqa: E402

from mixlift_mcp.renderers.analyze_memo import render_analyze_memo  # noqa: E402


def _paid_result() -> dict:
    """Full paid-tier result with 4 channels and 3 recommendations."""
    return {
        "status": "success",
        "license": {"tier": "pro", "message": "Valid"},
        "headline": "MixLift found a +12.0% budget optimization opportunity worth $9,600/week.",
        "data": {
            "format_detected": "wide",
            "channels": ["email_spend", "meta_spend", "google_spend", "tiktok_spend"],
            "n_channels": 4,
        },
        "roas": {
            "estimates": {
                "email_spend": 24.60,
                "tiktok_spend": 1.21,
                "google_spend": 1.10,
                "meta_spend": 0.47,
            },
        },
        "budget_optimization": {
            "current_allocation": {
                "email_spend": 800,
                "tiktok_spend": 7000,
                "google_spend": 13000,
                "meta_spend": 6000,
            },
            "optimal_allocation": {
                "email_spend": 7935,
                "tiktok_spend": 7871,
                "google_spend": 7397,
                "meta_spend": 3597,
            },
            "total_budget": 26800,
            "expected_lift_pct": 12.0,
        },
        "recommendations": {
            "summary": "Reallocate toward Email.",
            "actions": [
                {
                    "rank": 1,
                    "action": "INCREASE",
                    "channel": "email_spend",
                    "change_amount": 7135.0,
                    "current_spend": 800.0,
                    "optimal_spend": 7935.0,
                    "roas": 24.60,
                    "reason": "Highest ROAS in your mix with headroom remaining.",
                },
                {
                    "rank": 2,
                    "action": "DECREASE",
                    "channel": "meta_spend",
                    "change_amount": 2403.0,
                    "current_spend": 6000.0,
                    "optimal_spend": 3597.0,
                    "roas": 0.47,
                    "reason": "Sub-$1 ROAS; reallocate to higher-performing channels.",
                },
                {
                    "rank": 3,
                    "action": "INCREASE",
                    "channel": "tiktok_spend",
                    "change_amount": 871.0,
                    "current_spend": 7000.0,
                    "optimal_spend": 7871.0,
                    "roas": 1.21,
                    "reason": "Moderate ROAS with saturation headroom.",
                },
            ],
        },
        "diagnostics": {
            "convergence_warnings": [],
            "tier_warnings": [],
        },
        "model_fit": {
            "label": "Strong (R\u00b2 = 0.84)",
            "r_squared": 0.84,
            "mape": 3.9,
        },
        "analysis_badge": None,
        "model_info": {
            "duration_secs": 40.0,
            "total_spend": 26800,
            "data_window": {"weeks": 51.0},
            "mcmc_config": {"chains": 4, "draws": 250, "target_accept": 0.90},
        },
    }


def _free_result() -> dict:
    """Free-tier result -- dollar fields are upgrade strings."""
    base = _paid_result()
    base["license"] = {"tier": "free", "message": "Free tier"}
    upgrade_msg = "Upgrade to Growth ($299/mo) to see dollar allocations"
    base["budget_optimization"]["current_allocation"] = upgrade_msg
    base["budget_optimization"]["optimal_allocation"] = upgrade_msg
    base["budget_optimization"]["total_budget"] = upgrade_msg
    for action in base["recommendations"]["actions"]:
        action["change_amount"] = "Upgrade to Growth ($299/mo)"
        action["current_spend"] = "Upgrade to Growth ($299/mo)"
        action["optimal_spend"] = "Upgrade to Growth ($299/mo)"
    return base


class TestAnalyzeMemo:
    def test_renders_all_six_sections_paid_tier(self):
        output = render_analyze_memo(_paid_result())
        assert output != ""
        # Lede: bold line with middle-dot separator
        assert " \u00b7 " in output
        # H2 heading
        assert "## " in output
        # Hero table
        assert "### Where your dollars are working" in output
        # Three moves
        assert "### Three moves for this week" in output
        # Footer
        assert "*Modeled on" in output

    def test_paid_tier_shows_dollar_amounts(self):
        output = render_analyze_memo(_paid_result())
        # Current spend for email_spend is $800
        assert "$800" in output
        # Optimal delta for email is +$7,135
        assert "+$7,135" in output

    def test_free_tier_uses_insight_led_h2(self):
        output = render_analyze_memo(_free_result())
        assert "differ by" in output
        assert "\u00d7" in output  # multiplication sign
        # Must NOT contain upsell language in H2
        h2_line = [ln for ln in output.splitlines() if ln.startswith("## ")][0]
        assert "upgrade" not in h2_line.lower()
        assert "$" not in h2_line

    def test_free_tier_redacts_dollars(self):
        output = render_analyze_memo(_free_result())
        # Table spend column should show $XXX
        assert "$XXX" in output
        # Raw allocation values must not appear
        assert "$800" not in output
        assert "$7,000" not in output

    def test_no_emojis_ever(self):
        paid_out = render_analyze_memo(_paid_result())
        free_out = render_analyze_memo(_free_result())
        emoji_pattern = _re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(paid_out), "Emoji found in paid output"
        assert not emoji_pattern.search(free_out), "Emoji found in free output"

    def test_sorted_by_roas_descending(self):
        output = render_analyze_memo(_paid_result())
        table_start = output.index("### Where your dollars are working")
        table_section = output[table_start:]
        email_pos = table_section.find("Email")
        meta_pos = table_section.find("Meta")
        assert email_pos < meta_pos, "Email (highest ROAS) should appear before Meta (lowest)"

    def test_top_and_bottom_bolded(self):
        output = render_analyze_memo(_paid_result())
        assert "**Email**" in output
        assert "**Meta**" in output

    def test_unicode_bar_column_present(self):
        output = render_analyze_memo(_paid_result())
        assert "\u2588" in output  # full-block glyph

    def test_three_moves_blockquote(self):
        output = render_analyze_memo(_paid_result())
        assert "> **1." in output
        assert "> **2." in output
        assert "> **3." in output

    def test_close_to_optimal_variant(self):
        result = _paid_result()
        result["budget_optimization"]["expected_lift_pct"] = 0.2
        output = render_analyze_memo(result)
        assert "close to optimal" in output

    def test_missing_model_fit_graceful(self):
        result = _paid_result()
        del result["model_fit"]
        output = render_analyze_memo(result)
        assert output != ""
        assert "weeks" in output
        assert "channels" in output
        assert "R\u00b2" not in output
        assert "MAPE" not in output

    def test_missing_recommendations_skips_moves_section(self):
        result = _paid_result()
        result["recommendations"]["actions"] = []
        output = render_analyze_memo(result)
        assert "### Three moves for this week" not in output

    def test_cache_age_footnote(self):
        result = _paid_result()
        result["_cache_age_days"] = 3
        output = render_analyze_memo(result)
        assert "Cached from fit 3 days ago" in output

    def test_returns_empty_on_critical_missing(self):
        assert render_analyze_memo({}) == ""

    def test_convergence_warnings_reflected(self):
        result = _paid_result()
        result["diagnostics"]["convergence_warnings"] = [
            "Chain 1 divergences: 5",
            "Chain 2 divergences: 3",
        ]
        output = render_analyze_memo(result)
        assert "2 convergence warnings" in output

    def test_lede_contains_correct_weeks_and_r2(self):
        output = render_analyze_memo(_paid_result())
        assert "51 weeks" in output
        assert "R\u00b2 0.84" in output
        assert "MAPE 3.9%" in output

    def test_footer_posterior_from_dict_config(self):
        output = render_analyze_memo(_paid_result())
        assert "4 chains" in output
        assert "250 draws" in output

    def test_footer_no_divergences_default(self):
        output = render_analyze_memo(_paid_result())
        assert "no divergences" in output

    def test_three_moves_verbs(self):
        output = render_analyze_memo(_paid_result())
        assert "Increase Email" in output
        assert "Decrease Meta" in output


# ---------------------------------------------------------------------------
# TestBacktestSection
# ---------------------------------------------------------------------------

from mixlift_mcp.renderers.analyze_memo import _section_backtest  # noqa: E402


def _make_fold(
    fold: int = 1,
    train_start: str = "2025-01-06",
    train_end: str = "2025-10-05",
    test_start: str = "2025-10-06",
    test_end: str = "2025-11-03",
    mape: float = 8.4,
    r_squared: float = 0.82,
    coverage_80: float = 0.85,
    n_weeks: int = 4,
    actual_avg: float = 50000.0,
    pred_avg: float = 54000.0,
) -> dict:
    weekly_actual = [actual_avg] * n_weeks
    weekly_predicted_mean = [pred_avg] * n_weeks
    weekly_predicted_low = [pred_avg * 0.8] * n_weeks
    weekly_predicted_high = [pred_avg * 1.2] * n_weeks
    return {
        "fold": fold,
        "train_start": train_start,
        "train_end": train_end,
        "test_start": test_start,
        "test_end": test_end,
        "mape": mape,
        "r_squared": r_squared,
        "coverage_80": coverage_80,
        "weekly_actual": weekly_actual,
        "weekly_predicted_mean": weekly_predicted_mean,
        "weekly_predicted_low": weekly_predicted_low,
        "weekly_predicted_high": weekly_predicted_high,
    }


def _make_backtest(
    mode: str = "walk_forward",
    status: str = "success",
    n_folds: int = 3,
    horizon_weeks: int = 4,
    train_weeks: int = 48,
    interpretation: str = "great",
    mape_mean: float = 8.5,
    coverage_mean: float = 0.83,
    folds: list | None = None,
) -> dict:
    if folds is None:
        folds = [
            _make_fold(fold=1, mape=8.4),
            _make_fold(fold=2, mape=7.2, test_start="2025-11-10", test_end="2025-12-08"),
            _make_fold(fold=3, mape=10.0, test_start="2025-12-15", test_end="2026-01-12"),
        ]
    return {
        "mode": mode,
        "status": status,
        "n_folds": n_folds,
        "horizon_weeks": horizon_weeks,
        "train_weeks": train_weeks,
        "folds": folds,
        "aggregate": {
            "mape_mean": mape_mean,
            "mape_median": mape_mean,
            "r_squared_mean": 0.82,
            "coverage_80_mean": coverage_mean,
            "interpretation": interpretation,
            "interpretation_label": f"Backtest interpretation: {interpretation}",
        },
        "compute_secs": 42.3,
        "note": "Walk-forward CV",
    }


def _paid_result_with_backtest(**kwargs: object) -> dict:
    result = _paid_result()
    result["backtest"] = _make_backtest(**kwargs)
    return result


def _free_result_with_backtest(**kwargs: object) -> dict:
    result = _free_result()
    result["backtest"] = _make_backtest(**kwargs)
    return result


class TestBacktestSection:
    def test_returns_empty_when_no_backtest(self):
        assert _section_backtest({}, is_free=False) == ""

    def test_returns_empty_when_status_not_success(self):
        bt = _make_backtest(status="insufficient_data")
        result = {"backtest": bt}
        assert _section_backtest(result, is_free=False) == ""

    def test_returns_empty_when_folds_empty(self):
        bt = _make_backtest(folds=[])
        result = {"backtest": bt}
        assert _section_backtest(result, is_free=False) == ""

    def test_great_interpretation_narrative(self):
        result = _paid_result_with_backtest(interpretation="great")
        output = _section_backtest(result, is_free=False)
        assert "well-calibrated" in output

    def test_acceptable_interpretation_narrative(self):
        result = _paid_result_with_backtest(interpretation="acceptable")
        output = _section_backtest(result, is_free=False)
        assert "acceptable for directional" in output

    def test_poor_interpretation_narrative(self):
        result = _paid_result_with_backtest(interpretation="poor")
        output = _section_backtest(result, is_free=False)
        assert "higher than we\u2019d like" in output

    def test_paid_tier_shows_fold_table(self):
        result = _paid_result_with_backtest()
        output = _section_backtest(result, is_free=False)
        # Table header pipe-delimited
        assert "| Fold |" in output
        # Three fold rows
        assert output.count("| 1 |") >= 1 or output.count("|1|") >= 1 or "1 |" in output
        lines_with_pipe = [ln for ln in output.splitlines() if ln.startswith("|") and "%" in ln]
        assert len(lines_with_pipe) == 3

    def test_free_tier_no_fold_table(self):
        result = _free_result_with_backtest()
        output = _section_backtest(result, is_free=True)
        # After the narrative there should be no table pipes
        lines = output.splitlines()
        # Skip heading and blank lines, remaining should have no pipe-delimited rows
        data_lines = [ln for ln in lines if ln.startswith("|")]
        assert len(data_lines) == 0

    def test_free_tier_no_coverage_in_narrative(self):
        result = _free_result_with_backtest(interpretation="great")
        output = _section_backtest(result, is_free=True)
        # Coverage clause "confidence intervals contained" should be absent
        assert "confidence intervals contained" not in output

    def test_lede_includes_backtest_mape_when_present(self):
        result = _paid_result_with_backtest(mape_mean=9.2)
        from mixlift_mcp.renderers.analyze_memo import _section_lede

        lede = _section_lede(result)
        assert "Backtest MAPE 9.2%" in lede

    def test_lede_omits_backtest_mape_when_skipped(self):
        result = _paid_result()
        result["backtest"] = {"status": "skipped", "mode": "skipped"}
        from mixlift_mcp.renderers.analyze_memo import _section_lede

        lede = _section_lede(result)
        assert "Backtest MAPE" not in lede

    def test_single_holdout_variant_narrative(self):
        single_fold = [_make_fold(fold=1, mape=11.5)]
        result = _paid_result_with_backtest(
            mode="single_holdout",
            n_folds=1,
            horizon_weeks=8,
            interpretation="acceptable",
            folds=single_fold,
        )
        output = _section_backtest(result, is_free=False)
        assert "most recent 8 weeks" in output
        assert "11.5% MAPE" in output

    def test_no_emoji(self):
        result = _paid_result_with_backtest()
        output = _section_backtest(result, is_free=False)
        emoji_pattern = _re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(output)

    def test_en_dash_in_date_range(self):
        result = _paid_result_with_backtest()
        output = _section_backtest(result, is_free=False)
        # Table rows contain en-dash between date ranges
        assert "\u2013" in output

    def test_full_memo_renders_with_backtest(self):
        result = _paid_result_with_backtest()
        output = render_analyze_memo(result)
        assert "How we know these numbers hold up" in output
        assert "Backtest MAPE" in output


# ---------------------------------------------------------------------------
# render_scenario_memo
# ---------------------------------------------------------------------------

_BASE_SCENARIO: dict = {
    "scenario_input": "cut Meta by 20%",
    "projected_impact_pct": -3.5,
    "impact_ci_80": {"low": -6.0, "high": -1.2},
    "direction_note": "This would almost certainly reduce revenue, likely by -6.0% to -1.2%.",
    "changes": [
        {"channel": "meta_spend", "current": 10000, "modified": 8000, "change": -2000},
    ],
}

_BASE_MODEL_INFO: dict = {
    "mcmc_config": "4 chains, 250 draws, target_accept=0.90",
}


def _make_scenario(**overrides: object) -> dict:
    result = dict(_BASE_SCENARIO)
    result.update(overrides)
    return result


class TestScenarioMemo:
    # ------------------------------------------------------------------
    # Certainty suffix cases
    # ------------------------------------------------------------------

    def test_positive_impact_wide_ci_likely(self):
        # CI spans zero but |median| >= half CI width → "Likely."
        # ci_low=-2, ci_high=8, width=10, half=5, |median|=5 → equals half, Likely
        result = render_scenario_memo(
            _make_scenario(
                projected_impact_pct=5.0,
                impact_ci_80={"low": -2.0, "high": 8.0},
            )
        )
        assert "Likely." in result

    def test_positive_impact_tight_ci_near_certain(self):
        # CI entirely above 0 → "Near-certain."
        result = render_scenario_memo(
            _make_scenario(
                projected_impact_pct=4.0,
                impact_ci_80={"low": 1.5, "high": 6.5},
            )
        )
        assert "Near-certain." in result

    def test_negative_impact_below_zero_ci_near_certain_reduce(self):
        # CI entirely below 0 → "Near-certain." and verb "reduce"
        result = render_scenario_memo(
            _make_scenario(
                projected_impact_pct=-3.5,
                impact_ci_80={"low": -6.0, "high": -1.2},
            )
        )
        assert "Near-certain." in result
        assert "reduce" in result

    def test_coin_flip(self):
        # |median| < half CI width → "Coin flip."
        # ci_low=-8, ci_high=8, width=16, half=8, |median|=0.3 < 8 → Coin flip
        result = render_scenario_memo(
            _make_scenario(
                projected_impact_pct=0.3,
                impact_ci_80={"low": -8.0, "high": 8.0},
            )
        )
        assert "Coin flip." in result

    # ------------------------------------------------------------------
    # Table ordering
    # ------------------------------------------------------------------

    def test_changes_table_sorted_by_abs_delta(self):
        result = render_scenario_memo(
            _make_scenario(
                changes=[
                    {"channel": "email_spend", "current": 800, "modified": 1600, "change": 800},
                    {"channel": "meta_spend", "current": 18000, "modified": 8000, "change": -10000},
                    {"channel": "tiktok_spend", "current": 7000, "modified": 9000, "change": 2000},
                ]
            )
        )
        # "Meta" row (delta -10000) must appear before "TikTok" (2000) and "Email" (800)
        meta_pos = result.index("Meta")
        tiktok_pos = result.index("TikTok")
        email_pos = result.index("Email")
        assert meta_pos < tiktok_pos < email_pos

    # ------------------------------------------------------------------
    # No emoji
    # ------------------------------------------------------------------

    def test_no_emoji(self):
        result = render_scenario_memo(_BASE_SCENARIO, _BASE_MODEL_INFO)
        # Detect any character in emoji Unicode ranges
        emoji_pattern = re.compile(
            "[\U0001F600-\U0001F64F"
            "\U0001F300-\U0001F5FF"
            "\U0001F680-\U0001F6FF"
            "\U0001F1E0-\U0001F1FF"
            "\U00002702-\U000027B0"
            "\U000024C2-\U0001F251]+",
            flags=re.UNICODE,
        )
        assert not emoji_pattern.search(result), "Emoji found in output"

    # ------------------------------------------------------------------
    # model_info fallback
    # ------------------------------------------------------------------

    def test_missing_model_info_falls_back_gracefully(self):
        result = render_scenario_memo(_BASE_SCENARIO)
        assert "Posterior-based scenario projection." in result
        # Should not raise and should still have thesis
        assert "## This scenario would" in result

    def test_model_info_present_shows_chains_and_draws(self):
        result = render_scenario_memo(_BASE_SCENARIO, _BASE_MODEL_INFO)
        assert "4 chains" in result
        assert "250 draws" in result
        assert "Posterior-based scenario projection." not in result

    # ------------------------------------------------------------------
    # direction_note
    # ------------------------------------------------------------------

    def test_missing_direction_note_skips_paragraph(self):
        scenario = _make_scenario(direction_note="")
        result = render_scenario_memo(scenario)
        # Should not have a blank paragraph where direction_note would be
        # The thesis line immediately followed by no dangling blank paragraph
        assert "almost certainly" not in result
        # Still produces valid output
        assert "## This scenario would" in result

    # ------------------------------------------------------------------
    # Empty changes
    # ------------------------------------------------------------------

    def test_empty_changes_skips_table(self):
        result = render_scenario_memo(_make_scenario(changes=[]))
        assert "### Budget shifts" not in result
        assert "|" not in result

    # ------------------------------------------------------------------
    # Critical field guard
    # ------------------------------------------------------------------

    def test_returns_empty_on_critical_missing(self):
        assert render_scenario_memo({}) == ""

    def test_returns_empty_when_impact_pct_absent(self):
        result = render_scenario_memo({"scenario_input": "cut Meta by 10%"})
        assert result == ""


# ---------------------------------------------------------------------------
# TestForecastMemo
# ---------------------------------------------------------------------------

from mixlift_mcp.renderers.forecast_memo import render_forecast_memo  # noqa: E402


def _make_forecast(
    horizon: int = 12,
    current_weekly: float = 50_000.0,
    optimized_weekly: float = 56_000.0,
    ci_low_pct: float = 5.0,
    ci_high_pct: float = 15.0,
    include_trajectory: bool = True,
    model_info: dict | None = None,
) -> dict:
    """Build a minimal forecast_result matching the server.py shape."""
    weekly_delta = optimized_weekly - current_weekly
    total_delta = weekly_delta * horizon

    weeks = []
    cum_delta = 0.0
    for w in range(1, horizon + 1):
        cum_delta += weekly_delta
        weeks.append(
            {
                "week": w,
                "current_revenue": round(current_weekly, 0),
                "optimized_revenue": round(optimized_weekly, 0),
                "weekly_delta": round(weekly_delta, 0),
                "cumulative_current": round(current_weekly * w, 0),
                "cumulative_optimized": round(optimized_weekly * w, 0),
                "cumulative_delta": round(cum_delta, 0),
            }
        )

    return {
        "status": "success",
        "analysis_type": "forecast",
        "horizon_weeks": horizon,
        "summary": {
            "current_weekly_revenue": round(current_weekly, 0),
            "optimized_weekly_revenue": round(optimized_weekly, 0),
            "weekly_delta": round(weekly_delta, 0),
            "total_current_revenue": round(current_weekly * horizon, 0),
            "total_optimized_revenue": round(optimized_weekly * horizon, 0),
            "total_delta": round(total_delta, 0),
            "impact_pct": round((weekly_delta / current_weekly) * 100, 1),
            "impact_ci_80": {
                "low": ci_low_pct,
                "high": ci_high_pct,
            },
        },
        "weekly_projections": weeks if include_trajectory else [],
        "model_info": model_info if model_info is not None else {
            "mcmc_config": "4 chains x 250 draws"
        },
    }


class TestForecastMemo:
    def test_renders_all_five_sections(self):
        result = _make_forecast()
        memo = render_forecast_memo(result)

        # Section 1: lede
        assert "12-week forecast · current vs optimal allocation" in memo
        # Section 2: H2 thesis
        assert memo.count("## ") >= 1
        assert "lifts revenue" in memo
        # Section 3: narrative paragraph
        assert "/wk" in memo
        assert "80% CI" in memo
        # Section 4: trajectory table
        assert "### Weekly trajectory" in memo
        assert "Week" in memo and "Cumulative" in memo
        # Section 5: footer
        assert memo.strip().endswith("*")
        assert "Posterior" in memo

    def test_trajectory_table_truncates_long_horizon(self):
        result = _make_forecast(horizon=26)
        memo = render_forecast_memo(result)

        # Extract data rows from the table (skip header and separator)
        table_rows = [
            line
            for line in memo.splitlines()
            if line.startswith("|") and not line.startswith("| Week") and "---" not in line
        ]
        # Should have exactly 5 rows: weeks 1-4 + week 26
        assert len(table_rows) == 5
        assert "| 1 |" in table_rows[0]
        assert "| 26 |" in table_rows[-1]

    def test_trajectory_table_shows_all_when_short(self):
        result = _make_forecast(horizon=4)
        memo = render_forecast_memo(result)

        table_rows = [
            line
            for line in memo.splitlines()
            if line.startswith("|") and not line.startswith("| Week") and "---" not in line
        ]
        assert len(table_rows) == 4

    def test_negative_total_delta_handled(self):
        # optimized_weekly < current_weekly → negative delta
        result = _make_forecast(current_weekly=60_000.0, optimized_weekly=55_000.0)
        memo = render_forecast_memo(result)

        assert "already beats the naive optimum" in memo
        assert "lifts revenue by" not in memo

    def test_no_emoji(self):
        result = _make_forecast()
        memo = render_forecast_memo(result)

        emoji_pattern = re.compile(
            "["
            "\U0001f600-\U0001f64f"
            "\U0001f300-\U0001f5ff"
            "\U0001f680-\U0001f6ff"
            "\U0001f700-\U0001f77f"
            "\U0001f780-\U0001f7ff"
            "\U0001f800-\U0001f8ff"
            "\U0001f900-\U0001f9ff"
            "\U0001fa00-\U0001fa6f"
            "\U0001fa70-\U0001faff"
            "\U00002702-\U000027b0"
            "\U000024c2-\U0001f251"
            "]+",
            flags=re.UNICODE,
        )
        assert not emoji_pattern.search(memo), f"Emoji found in memo: {memo!r}"

    def test_dollar_signs_formatted_correctly(self):
        result = _make_forecast(current_weekly=50_000.0, optimized_weekly=56_000.0)
        memo = render_forecast_memo(result)

        assert "$50,000" in memo
        assert "$56,000" in memo

    def test_missing_trajectory_skips_section(self):
        result = _make_forecast(include_trajectory=False)
        memo = render_forecast_memo(result)

        assert "### Weekly trajectory" not in memo
        # Other sections still render
        assert "week forecast" in memo
        assert "80% CI" in memo
        assert "Posterior" in memo

    def test_ci_bounds_in_narrative(self):
        # current=100k/wk, horizon=12
        # ci_low=5%  → total horizon revenue = 1,200,000; lift low = 1,200,000*0.05 = $60,000
        # ci_high=15% → lift high = 1,200,000*0.15 = $180,000
        result = _make_forecast(
            current_weekly=100_000.0,
            optimized_weekly=110_000.0,
            ci_low_pct=5.0,
            ci_high_pct=15.0,
            horizon=12,
        )
        memo = render_forecast_memo(result)

        assert "$60,000" in memo
        assert "$180,000" in memo

    def test_returns_empty_on_critical_missing(self):
        assert render_forecast_memo({}) == ""
        assert render_forecast_memo({"horizon_weeks": 12}) == ""
        assert render_forecast_memo({"summary": {}, "horizon_weeks": 12}) == ""

    def test_footer_parses_mcmc_config(self):
        result = _make_forecast(model_info={"mcmc_config": "4 chains x 250 draws"})
        memo = render_forecast_memo(result)

        assert "4 chains" in memo
        assert "250 draws" in memo

    def test_footer_fallback_when_no_mcmc_config(self):
        result = _make_forecast(model_info={})
        memo = render_forecast_memo(result)

        assert "Posterior-based forecast." in memo


# ---------------------------------------------------------------------------
# TestPlatformComparisonSection
# ---------------------------------------------------------------------------

from mixlift_mcp.renderers.analyze_memo import _section_platform_comparison  # noqa: E402


def _pac_over() -> dict:
    """One over-claimer (Meta), one aligned (Google), one under-claimer (TikTok)."""
    return {
        "platform_attribution_comparison": {
            "source": "mcp_argument",
            "channels": {
                "meta_spend": {
                    "platform_roas": 3.20,
                    "platform_revenue": 32000.0,
                    "mmm_roas": 1.05,
                    "mmm_roas_ci_low": 0.80,
                    "mmm_roas_ci_high": 1.30,
                    "spend": 10000.0,
                    "gap_pct": -0.672,
                    "verdict": "over_claiming",
                    "severity": "extreme",
                    "confidence": "high",
                    "one_liner": "meta_spend claims 3.20x; MixLift measures 1.05x. Gap 67%.",
                },
                "google_spend": {
                    "platform_roas": 1.10,
                    "platform_revenue": 13200.0,
                    "mmm_roas": 1.08,
                    "mmm_roas_ci_low": 0.90,
                    "mmm_roas_ci_high": 1.25,
                    "spend": 12000.0,
                    "gap_pct": -0.018,
                    "verdict": "aligned",
                    "severity": None,
                    "confidence": "high",
                    "one_liner": "google_spend: aligned.",
                },
                "tiktok_spend": {
                    "platform_roas": 0.80,
                    "platform_revenue": 5600.0,
                    "mmm_roas": 1.20,
                    "mmm_roas_ci_low": 1.00,
                    "mmm_roas_ci_high": 1.40,
                    "spend": 7000.0,
                    "gap_pct": 0.50,
                    "verdict": "under_claiming",
                    "severity": None,
                    "confidence": "medium",
                    "one_liner": "tiktok_spend: under-claiming.",
                },
            },
            "summary": {
                "channels_over_claiming": ["meta_spend"],
                "channels_aligned": ["google_spend"],
                "channels_under_claiming": ["tiktok_spend"],
                "most_egregious": {"channel": "meta_spend", "gap_pct": -0.672},
                "total_platform_revenue": 50800.0,
                "total_mmm_revenue": 30090.0,
                "phantom_revenue_pct": 0.407,
            },
            "excluded_channels": [],
        }
    }


def _pac_two_over() -> dict:
    """Two over-claimers."""
    base = _pac_over()
    # Add a second over-claimer
    base["platform_attribution_comparison"]["channels"]["email_spend"] = {
        "platform_roas": 2.00,
        "platform_revenue": 4000.0,
        "mmm_roas": 1.40,
        "mmm_roas_ci_low": 1.10,
        "mmm_roas_ci_high": 1.70,
        "spend": 2000.0,
        "gap_pct": -0.30,
        "verdict": "over_claiming",
        "severity": "significant",
        "confidence": "medium",
        "one_liner": "email_spend claims 2.00x.",
    }
    base["platform_attribution_comparison"]["summary"]["channels_over_claiming"] = [
        "meta_spend",
        "email_spend",
    ]
    return base


def _pac_aligned_only() -> dict:
    """All channels aligned."""
    return {
        "platform_attribution_comparison": {
            "source": "mcp_argument",
            "channels": {
                "meta_spend": {
                    "platform_roas": 1.10,
                    "platform_revenue": 11000.0,
                    "mmm_roas": 1.08,
                    "mmm_roas_ci_low": 0.90,
                    "mmm_roas_ci_high": 1.25,
                    "spend": 10000.0,
                    "gap_pct": -0.018,
                    "verdict": "aligned",
                    "severity": None,
                    "confidence": "high",
                    "one_liner": "aligned.",
                },
                "google_spend": {
                    "platform_roas": 1.05,
                    "platform_revenue": 12600.0,
                    "mmm_roas": 1.03,
                    "mmm_roas_ci_low": 0.85,
                    "mmm_roas_ci_high": 1.20,
                    "spend": 12000.0,
                    "gap_pct": -0.019,
                    "verdict": "aligned",
                    "severity": None,
                    "confidence": "high",
                    "one_liner": "aligned.",
                },
            },
            "summary": {
                "channels_over_claiming": [],
                "channels_aligned": ["meta_spend", "google_spend"],
                "channels_under_claiming": [],
                "most_egregious": None,
                "total_platform_revenue": 23600.0,
                "total_mmm_revenue": 23360.0,
                "phantom_revenue_pct": 0.010,
            },
            "excluded_channels": [],
        }
    }


def _pac_under_only() -> dict:
    """Only under-claimers."""
    return {
        "platform_attribution_comparison": {
            "source": "mcp_argument",
            "channels": {
                "tiktok_spend": {
                    "platform_roas": 0.80,
                    "platform_revenue": 5600.0,
                    "mmm_roas": 1.50,
                    "mmm_roas_ci_low": 1.20,
                    "mmm_roas_ci_high": 1.80,
                    "spend": 7000.0,
                    "gap_pct": 0.875,
                    "verdict": "under_claiming",
                    "severity": None,
                    "confidence": "medium",
                    "one_liner": "under.",
                },
                "meta_spend": {
                    "platform_roas": 0.90,
                    "platform_revenue": 9000.0,
                    "mmm_roas": 1.10,
                    "mmm_roas_ci_low": 0.95,
                    "mmm_roas_ci_high": 1.25,
                    "spend": 10000.0,
                    "gap_pct": 0.222,
                    "verdict": "under_claiming",
                    "severity": None,
                    "confidence": "high",
                    "one_liner": "under.",
                },
            },
            "summary": {
                "channels_over_claiming": [],
                "channels_aligned": [],
                "channels_under_claiming": ["tiktok_spend", "meta_spend"],
                "most_egregious": None,
                "total_platform_revenue": 14600.0,
                "total_mmm_revenue": 21500.0,
                "phantom_revenue_pct": None,
            },
            "excluded_channels": [],
        }
    }


def _pac_single_channel() -> dict:
    """One channel only — footnote should be omitted."""
    return {
        "platform_attribution_comparison": {
            "source": "mcp_argument",
            "channels": {
                "meta_spend": {
                    "platform_roas": 3.20,
                    "platform_revenue": 32000.0,
                    "mmm_roas": 1.05,
                    "mmm_roas_ci_low": 0.80,
                    "mmm_roas_ci_high": 1.30,
                    "spend": 10000.0,
                    "gap_pct": -0.672,
                    "verdict": "over_claiming",
                    "severity": "extreme",
                    "confidence": "high",
                    "one_liner": "meta_spend: over.",
                },
            },
            "summary": {
                "channels_over_claiming": ["meta_spend"],
                "channels_aligned": [],
                "channels_under_claiming": [],
                "most_egregious": {"channel": "meta_spend", "gap_pct": -0.672},
                "total_platform_revenue": 32000.0,
                "total_mmm_revenue": 10500.0,
                "phantom_revenue_pct": 0.672,
            },
            "excluded_channels": [],
        }
    }


class TestPlatformComparisonSection:
    def test_returns_empty_when_no_platform_data(self):
        assert _section_platform_comparison({}, False) == ""
        assert _section_platform_comparison({"platform_attribution_comparison": {}}, False) == ""
        assert (
            _section_platform_comparison(
                {"platform_attribution_comparison": {"channels": {}}}, False
            )
            == ""
        )

    def test_over_claiming_h3_title(self):
        out = _section_platform_comparison(_pac_over(), False)
        assert "lying to you" in out

    def test_aligned_h3_title(self):
        out = _section_platform_comparison(_pac_aligned_only(), False)
        assert "telling the truth" in out

    def test_under_claiming_h3_title(self):
        out = _section_platform_comparison(_pac_under_only(), False)
        assert "view-through" in out

    def test_table_columns_and_rows_present(self):
        out = _section_platform_comparison(_pac_over(), False)
        assert "Platform reports" in out
        assert "MixLift measures" in out
        assert "95% CI" in out
        assert "Gap" in out
        # All three channels should appear
        assert "Meta" in out
        assert "Google" in out
        assert "TikTok" in out

    def test_most_egregious_bolded(self):
        out = _section_platform_comparison(_pac_over(), False)
        assert "**Meta**" in out

    def test_multiple_over_claimers_footer_line(self):
        out = _section_platform_comparison(_pac_two_over(), False)
        # Secondary over-claimer (email) follow-up sentence should appear
        assert "same pattern at smaller scale" in out
        assert "Email" in out

    def test_incremental_pct_computed_in_narrative(self):
        # meta: mmm_roas=1.05, plat=3.20 → round(1.05/3.20*100) = round(32.8) = 33
        out = _section_platform_comparison(_pac_over(), False)
        assert "33%" in out
        assert "incremental" in out

    def test_uses_multiplication_sign_not_x(self):
        out = _section_platform_comparison(_pac_over(), False)
        times = "\u00d7"
        assert times in out
        # No bare lowercase x following a digit (ROAS like "3.20x" is forbidden)
        assert not re.search(r"\d\.?\d*x", out)

    def test_uses_en_dash_in_ci_range(self):
        out = _section_platform_comparison(_pac_over(), False)
        en_dash = "\u2013"
        assert en_dash in out

    def test_no_emoji(self):
        out = _section_platform_comparison(_pac_over(), False)
        emoji_pattern = re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]")
        assert not emoji_pattern.search(out)

    def test_free_tier_no_dollar_amounts(self):
        # Build a free-tier result by detecting via budget_optimization string
        result = _pac_over()
        result["budget_optimization"] = {
            "current_allocation": "Upgrade to Growth ($299/mo) to see dollar allocations"
        }
        # The section itself should have no raw dollar figures — platform_revenue
        # is internal to W2 and not emitted in the memo section.
        out = _section_platform_comparison(result, is_free=True)
        # No raw $NNNN pattern
        assert not re.search(r"\$\d+", out)

    def test_double_counting_footnote_when_multi_channel(self):
        out = _section_platform_comparison(_pac_over(), False)
        assert "double-count" in out
        assert "20" in out  # "20–40%"

    def test_double_counting_footnote_omitted_when_single_channel(self):
        out = _section_platform_comparison(_pac_single_channel(), False)
        assert "double-count" not in out
