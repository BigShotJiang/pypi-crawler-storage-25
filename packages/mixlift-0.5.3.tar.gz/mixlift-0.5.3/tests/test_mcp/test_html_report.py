"""N1: HTML report export tests.

Verifies that generate_html_report produces valid self-contained HTML
with all expected sections.
"""

from __future__ import annotations

import pathlib
import re

from mixlift_mcp.readout import generate_html_report

_EMOJI_RE = re.compile(
    "[\U0001F000-\U0001FFFF"
    "\U00002600-\U000027BF"
    "\U00002300-\U000023FF"
    "\U00002B00-\U00002BFF"
    "\U0001F300-\U0001F9FF"
    "\U0000FE00-\U0000FE0F]"
)
# Decimal HTML entities in the misc-symbols / emoji range: U+2600-U+27BF = 9728-10175
# (excludes geometric shapes U+25xx = 9632-9727, which are intentional UI glyphs)
_HTML_EMOJI_DEC_RE = re.compile(r"&#(97[2-9][0-9]|9[89][0-9]{2}|10[01][0-9]{2});")
# Hex HTML entities in the same range
_HTML_EMOJI_HEX_RE = re.compile(
    r"&#x(2[6-9A-Fa-f][0-9A-Fa-f]{2}|[1-9A-Fa-f][0-9A-Fa-f]{4,5});",
    re.IGNORECASE,
)


def _make_platform_comparison() -> dict:
    """Return a realistic platform_attribution_comparison dict (2 channels)."""
    return {
        "source": "mcp_argument",
        "channels": {
            "Meta": {
                "platform_roas": 3.20,
                "platform_revenue": 25600.0,
                "mmm_roas": 2.45,
                "mmm_roas_ci_low": 1.90,
                "mmm_roas_ci_high": 3.00,
                "spend": 8000.0,
                "gap_pct": -0.234,
                "verdict": "over_claiming",
                "severity": "significant",
                "confidence": "high",
                "one_liner": (
                    "Meta claims 3.20\u00d7 ROAS; MixLift measures 2.45\u00d7 "
                    "(CI 1.90\u20133.00\u00d7). Gap 23%."
                ),
            },
            "Google": {
                "platform_roas": 3.10,
                "platform_revenue": 15500.0,
                "mmm_roas": 3.20,
                "mmm_roas_ci_low": 2.50,
                "mmm_roas_ci_high": 3.90,
                "spend": 5000.0,
                "gap_pct": 0.032,
                "verdict": "aligned",
                "severity": None,
                "confidence": "high",
                "one_liner": (
                    "Google claims 3.10\u00d7 ROAS; MixLift measures 3.20\u00d7 "
                    "(CI 2.50\u20133.90\u00d7). Gap 3%."
                ),
            },
        },
        "summary": {
            "channels_over_claiming": ["Meta"],
            "channels_aligned": ["Google"],
            "channels_under_claiming": [],
            "most_egregious": {"channel": "Meta", "gap_pct": -0.234},
            "total_platform_revenue": 41100.0,
            "total_mmm_revenue": 35600.0,
            "phantom_revenue_pct": 0.134,
        },
        "excluded_channels": [],
    }


def _make_result() -> dict:
    """Build a realistic result dict for HTML report rendering."""
    return {
        "status": "success",
        "headline": "MixLift found $12,500/week in optimization opportunity (+12.5%)",
        "data": {"channels": ["Meta", "Google", "TikTok"], "n_channels": 3},
        "roas": {
            "estimates": {"Meta": 2.45, "Google": 3.20, "TikTok": 1.10},
            "confidence_intervals": {
                "Meta": {"low": 1.90, "high": 3.00},
                "Google": {"low": 2.50, "high": 3.90},
                "TikTok": {"low": 0.50, "high": 1.70},
            },
        },
        "saturation_analysis": {
            "Meta": {"saturation_pct": 42, "status": "green", "label": "Room to scale"},
            "Google": {"saturation_pct": 68, "status": "yellow", "label": "Approaching"},
            "TikTok": {"saturation_pct": 85, "status": "red", "label": "Diminishing"},
        },
        "marginal_roas": {
            "estimates": {"Meta": 2.10, "Google": 2.80, "TikTok": 0.70},
        },
        "budget_optimization": {
            "current_allocation": {"Meta": 8000, "Google": 5000, "TikTok": 3000},
            "optimal_allocation": {"Meta": 6000, "Google": 7000, "TikTok": 3000},
            "total_budget": 16000,
            "expected_lift_pct": 12.5,
        },
        "recommendations": {
            "summary": "Reallocating budget could improve results by 12.5%.",
            "actions": [
                {
                    "rank": 1,
                    "action": "INCREASE",
                    "channel": "Google",
                    "change_amount": 2000.0,
                    "current_spend": 5000.0,
                    "optimal_spend": 7000.0,
                    "roas": 3.20,
                },
                {
                    "rank": 2,
                    "action": "DECREASE",
                    "channel": "Meta",
                    "change_amount": 2000.0,
                    "current_spend": 8000.0,
                    "optimal_spend": 6000.0,
                    "roas": 2.45,
                },
            ],
        },
        "model_fit": {
            "r_squared": 0.85,
            "mape": 8.2,
            "label": "This model explains 85% of your revenue variation.",
        },
        "loo_cv": {"interpretation_label": "Good predictive accuracy"},
        "diagnostics": {"convergence_warnings": []},
        "model_info": {
            "data_window": {"weeks": 52},
            "mcmc_config": {"chains": 4, "tune": 500, "draws": 250, "target_accept": 0.90},
        },
        "memory": {},
        "analysis_badge": None,
    }


class TestGenerateHtmlReport:
    """Test HTML report file generation."""

    def test_generates_html_file(self, tmp_path):
        result = _make_result()
        out = tmp_path / "report.html"
        summary = generate_html_report(result, str(out))

        assert summary["status"] == "success"
        assert out.exists()

    def test_html_is_self_contained(self, tmp_path):
        result = _make_result()
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "<!DOCTYPE html>" in html
        assert "<style>" in html
        assert "MixLift" in html

    def test_html_contains_headline(self, tmp_path):
        result = _make_result()
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "$12,500/week" in html

    def test_html_contains_channels(self, tmp_path):
        result = _make_result()
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "Meta" in html
        assert "Google" in html
        assert "TikTok" in html

    def test_html_contains_actions(self, tmp_path):
        result = _make_result()
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "INCREASE" in html
        assert "DECREASE" in html

    def test_html_contains_model_quality(self, tmp_path):
        result = _make_result()
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "0.85" in html  # R-squared
        assert "8.2%" in html  # MAPE

    def test_html_contains_saturation_badges(self, tmp_path):
        result = _make_result()
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "sat-green" in html
        assert "sat-yellow" in html
        assert "sat-red" in html

    def test_html_with_badge(self, tmp_path):
        result = _make_result()
        result["analysis_badge"] = {
            "type": "exploratory",
            "label": "Exploratory Analysis",
            "note": "This analysis covers 18 weeks of data.",
        }
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "Exploratory Analysis" in html

    def test_html_with_convergence_warnings(self, tmp_path):
        result = _make_result()
        result["diagnostics"]["convergence_warnings"] = ["R-hat > 1.05 for Google"]
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "R-hat" in html

    def test_error_on_failed_result(self):
        result = {"status": "error", "message": "Analysis failed"}
        summary = generate_html_report(result, "/tmp/x.html")
        assert summary["status"] == "error"

    def test_creates_parent_dirs(self, tmp_path):
        result = _make_result()
        out = tmp_path / "deep" / "nested" / "report.html"
        summary = generate_html_report(result, str(out))

        assert summary["status"] == "success"
        assert out.exists()

    def test_html_print_ready(self, tmp_path):
        result = _make_result()
        out = tmp_path / "report.html"
        generate_html_report(result, str(out))

        html = out.read_text()
        assert "@media print" in html
        assert "8.5in 11in" in html

    def test_no_emoji_in_rendered_templates(self, tmp_path):
        """HTML template must contain no emoji code points or HTML emoji entities."""
        root = pathlib.Path(__file__).parent.parent.parent
        template_path = root / "src" / "mixlift_mcp" / "templates" / "report.html.j2"
        assert template_path.exists(), f"Template not found: {template_path}"
        content = template_path.read_text()

        literal_hits = _EMOJI_RE.findall(content)
        dec_hits = _HTML_EMOJI_DEC_RE.findall(content)
        hex_hits = _HTML_EMOJI_HEX_RE.findall(content)

        assert not literal_hits, f"Literal emoji in report.html.j2: {literal_hits}"
        assert not dec_hits, f"Decimal HTML emoji entities in report.html.j2: {dec_hits}"
        assert not hex_hits, f"Hex HTML emoji entities in report.html.j2: {hex_hits}"


class TestPlatformComparisonSection:
    """Tests for the Platform vs. MixLift Attribution section (N9)."""

    def _render(self, result: dict, tmp_path) -> str:
        out = tmp_path / "report.html"
        summary = generate_html_report(result, str(out))
        assert summary["status"] == "success"
        return out.read_text()

    def test_platform_comparison_section_rendered_when_present(self, tmp_path):
        result = _make_result()
        result["platform_attribution_comparison"] = _make_platform_comparison()
        html = self._render(result, tmp_path)
        assert "Platform vs. MixLift Attribution" in html

    def test_platform_comparison_omitted_when_empty(self, tmp_path):
        result = _make_result()
        # No key at all
        html = self._render(result, tmp_path)
        assert "Platform vs. MixLift Attribution" not in html

    def test_platform_comparison_omitted_when_channels_empty(self, tmp_path):
        result = _make_result()
        result["platform_attribution_comparison"] = {"channels": {}, "summary": {}}
        html = self._render(result, tmp_path)
        assert "Platform vs. MixLift Attribution" not in html

    def test_verdict_pills_rendered(self, tmp_path):
        result = _make_result()
        result["platform_attribution_comparison"] = _make_platform_comparison()
        html = self._render(result, tmp_path)
        assert 'class="verdict verdict-over_claiming"' in html
        assert 'class="verdict verdict-aligned"' in html
        assert "Over-claiming" in html
        assert "Aligned" in html

    def test_ci_range_uses_en_dash(self, tmp_path):
        result = _make_result()
        result["platform_attribution_comparison"] = _make_platform_comparison()
        html = self._render(result, tmp_path)
        # The CI range cell must contain an en dash (U+2013) rendered via &#x2013;
        # Jinja autoescape renders &#x2013; as the literal character in the output
        assert "\u2013" in html

    def test_gap_uses_minus_sign_for_over_claiming(self, tmp_path):
        result = _make_result()
        result["platform_attribution_comparison"] = _make_platform_comparison()
        html = self._render(result, tmp_path)
        # U+2212 minus sign must appear for over-claiming gap
        assert "\u2212" in html

    def test_free_tier_no_dollar_values_in_platform_section(self, tmp_path):
        result = _make_result()
        result["platform_attribution_comparison"] = _make_platform_comparison()
        result["license"] = {"tier": "free"}
        html = self._render(result, tmp_path)
        # Section must exist but platform_revenue dollar amounts must not appear
        assert "Platform vs. MixLift Attribution" in html
        pc_start = html.find("platform-comparison")
        pc_end = html.find("</section>", pc_start)
        section_html = html[pc_start:pc_end]
        # platform_revenue values were 25600 and 15500 — neither should appear
        assert "25600" not in section_html
        assert "15500" not in section_html

    def test_double_counting_footnote_shown_when_multi_channel(self, tmp_path):
        result = _make_result()
        result["platform_attribution_comparison"] = _make_platform_comparison()
        html = self._render(result, tmp_path)
        assert "double-count" in html

    def test_double_counting_footnote_hidden_when_single_channel(self, tmp_path):
        result = _make_result()
        pc = _make_platform_comparison()
        # Keep only Meta
        pc["channels"] = {"Meta": pc["channels"]["Meta"]}
        result["platform_attribution_comparison"] = pc
        html = self._render(result, tmp_path)
        assert "double-count" not in html

    def test_no_emoji_in_platform_section(self, tmp_path):
        result = _make_result()
        result["platform_attribution_comparison"] = _make_platform_comparison()
        html = self._render(result, tmp_path)
        pc_start = html.find("platform-comparison")
        pc_end = html.find("</section>", pc_start)
        section_html = html[pc_start:pc_end]
        assert not _EMOJI_RE.findall(section_html), "Emoji found in platform-comparison section"


# ---------------------------------------------------------------------------
# Backtest Validation section
# ---------------------------------------------------------------------------


def _make_fold_dict(
    fold: int = 1,
    test_start: str = "2025-10-06",
    test_end: str = "2025-11-03",
    mape: float = 8.4,
    coverage_80: float = 0.85,
    n_weeks: int = 4,
    actual_avg: float = 50000.0,
    pred_avg: float = 54000.0,
) -> dict:
    return {
        "fold": fold,
        "train_start": "2025-01-01",
        "train_end": "2025-10-05",
        "test_start": test_start,
        "test_end": test_end,
        "mape": mape,
        "r_squared": 0.82,
        "coverage_80": coverage_80,
        "weekly_actual": [actual_avg] * n_weeks,
        "weekly_predicted_mean": [pred_avg] * n_weeks,
        "weekly_predicted_low": [pred_avg * 0.8] * n_weeks,
        "weekly_predicted_high": [pred_avg * 1.2] * n_weeks,
    }


def _make_backtest_dict(
    status: str = "success",
    mode: str = "walk_forward",
    n_folds: int = 3,
    horizon_weeks: int = 4,
    interpretation: str = "great",
    mape_mean: float = 8.5,
    coverage_mean: float = 0.83,
    folds: list | None = None,
) -> dict:
    if folds is None:
        folds = [
            _make_fold_dict(fold=1),
            _make_fold_dict(fold=2, test_start="2025-11-10", test_end="2025-12-08"),
            _make_fold_dict(fold=3, test_start="2025-12-15", test_end="2026-01-12"),
        ]
    return {
        "mode": mode,
        "status": status,
        "n_folds": n_folds,
        "horizon_weeks": horizon_weeks,
        "train_weeks": 48,
        "folds": folds,
        "aggregate": {
            "mape_mean": mape_mean,
            "mape_median": mape_mean,
            "r_squared_mean": 0.82,
            "coverage_80_mean": coverage_mean,
            "interpretation": interpretation,
            "interpretation_label": f"Backtest: {interpretation}",
        },
        "compute_secs": 42.3,
        "note": "Walk-forward CV",
    }


class TestBacktestHtmlSection:
    """Tests for the Backtest Validation section in the HTML report."""

    def _render(self, result: dict, tmp_path) -> str:
        out = tmp_path / "report.html"
        summary = generate_html_report(result, str(out))
        assert summary["status"] == "success"
        return out.read_text()

    def test_backtest_section_rendered_when_success(self, tmp_path):
        result = _make_result()
        result["backtest"] = _make_backtest_dict()
        html = self._render(result, tmp_path)
        assert '<section class="backtest">' in html
        assert "<h2>Backtest Validation</h2>" in html

    def test_backtest_section_omitted_when_skipped(self, tmp_path):
        result = _make_result()
        result["backtest"] = _make_backtest_dict(status="skipped", folds=[])
        html = self._render(result, tmp_path)
        assert '<section class="backtest">' not in html

    def test_backtest_section_omitted_when_no_key(self, tmp_path):
        result = _make_result()
        # no backtest key at all — backward compat
        html = self._render(result, tmp_path)
        assert '<section class="backtest">' not in html

    def test_free_tier_no_coverage_column(self, tmp_path):
        result = _make_result()
        result["license"] = {"tier": "free"}
        result["backtest"] = _make_backtest_dict()
        html = self._render(result, tmp_path)
        assert "Backtest Validation" in html
        assert "<th>Coverage</th>" not in html

    def test_paid_tier_has_coverage_column(self, tmp_path):
        result = _make_result()
        result["license"] = {"tier": "pro"}
        result["backtest"] = _make_backtest_dict()
        html = self._render(result, tmp_path)
        assert "Coverage" in html

    def test_fold_rows_rendered_correct_count(self, tmp_path):
        result = _make_result()
        result["backtest"] = _make_backtest_dict(n_folds=3)
        html = self._render(result, tmp_path)
        # Count <tr> tags inside the .folds table by looking for the fold numbers
        assert html.count(">1<") >= 1 or "fold" in html.lower()
        # Three fold rows visible in output (test_start dates are distinct)
        assert "2025-10-06" in html
        assert "2025-11-10" in html
        assert "2025-12-15" in html

    def test_backtest_narrative_rendered(self, tmp_path):
        result = _make_result()
        result["backtest"] = _make_backtest_dict(interpretation="great")
        html = self._render(result, tmp_path)
        assert "well-calibrated" in html

    def test_backward_compat_no_backtest_key(self, tmp_path):
        """Results without a backtest key must not crash."""
        result = _make_result()
        assert "backtest" not in result
        html = self._render(result, tmp_path)
        assert "<!DOCTYPE html>" in html
