"""Tool-level integration tests for mixlift_weekly_digest.

All tests mock _run_pipeline, _run_saturation_curves, _run_marginal_roas,
and _run_wow_channel_contributions so no actual MCMC fit is executed.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.license import LicenseStatus
from mixlift_mcp.server import mixlift_weekly_digest

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def wide_csv_10w(tmp_path):
    """3-channel wide-format CSV, 10 weeks (less than 2 weeks for WoW short-data test)."""
    n = 10
    dates = pd.date_range("2026-02-02", periods=n, freq="W-MON")
    rng = np.random.default_rng(1)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n),
            "email_spend": rng.uniform(500, 1500, n),
            "revenue": rng.uniform(50000, 150000, n),
        }
    )
    path = tmp_path / "wide_10w.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def wide_csv_30w(tmp_path):
    """3-channel wide-format CSV, 30 weeks — sufficient for all sections."""
    n = 30
    dates = pd.date_range("2025-09-29", periods=n, freq="W-MON")
    rng = np.random.default_rng(42)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n),
            "email_spend": rng.uniform(500, 1500, n),
            "tiktok_spend": rng.uniform(1000, 5000, n),
            "revenue": rng.uniform(50000, 150000, n),
        }
    )
    path = tmp_path / "wide_30w.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def pacing_csv(tmp_path):
    """Spend CSV without revenue column (for pacing — daily-ish data)."""
    n = 30
    dates = pd.date_range("2026-04-01", periods=n, freq="D")
    rng = np.random.default_rng(7)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(1500, 3000, n),
            "email_spend": rng.uniform(80, 150, n),
        }
    )
    path = tmp_path / "pacing.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def mock_pro_license():
    return LicenseStatus(is_pro=True, max_channels=999, max_rows=999_999, message="Pro")


@pytest.fixture
def mock_free_license():
    return LicenseStatus(is_pro=False, max_channels=2, max_rows=2000, message="Free")


def _make_mock_model_results(channels=None):
    """Build a minimal ModelResults mock."""
    if channels is None:
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
    mr = MagicMock()
    mr.mmm = MagicMock()
    mr.roas_estimates = {c: 1.5 for c in channels}
    mr.roas_ci = {c: (0.8, 2.2) for c in channels}
    mr.marginal_roas_estimates = {c: 1.2 for c in channels}
    mr.marginal_roas_ci = {c: (0.6, 1.8) for c in channels}
    mr.channel_contributions = {c: 30_000.0 for c in channels}
    mr.channel_contributions_ci = {c: (20_000.0, 40_000.0) for c in channels}
    mr.total_spend = {c: 10_000.0 for c in channels}
    mr.duration_secs = 5.0
    mr.convergence_warnings = []
    mr.raw_contributions = MagicMock()
    mr.loo_cv = {}
    mr.intercept_decomposition = {}
    return mr


def _make_mock_saturation_curves(channel_columns):
    from mixlift.modeling.optimizer import format_channel_name

    curves = {}
    for col in channel_columns:
        display = format_channel_name(col)
        spend = [float(i * 500) for i in range(100)]
        response = [s * 0.9 * (1 - s / 50000.0) for s in spend]
        curves[display] = {"spend": spend, "response": response}
    return curves


def _make_mock_marginal_roas(channel_columns):
    from mixlift.modeling.optimizer import format_channel_name

    means = {}
    cis = {}
    for col in channel_columns:
        display = format_channel_name(col)
        means[display] = 1.2
        cis[display] = (0.6, 1.8)
    return means, cis


def _make_mock_wow_contributions(channel_columns):
    from mixlift.modeling.optimizer import format_channel_name

    means = {}
    cis = {}
    for col in channel_columns:
        display = format_channel_name(col)
        means[display] = 50_000.0
        cis[display] = (40_000.0, 60_000.0)
    return means, cis


def _patch_digest(mock_mr, mock_license, channel_columns=None):
    """Return context managers for patching the digest call stack."""
    if channel_columns is None:
        channel_columns = ["meta_spend", "email_spend", "tiktok_spend"]
    mock_curves = _make_mock_saturation_curves(channel_columns)
    mock_mroas_means, mock_mroas_cis = _make_mock_marginal_roas(channel_columns)
    mock_wow_means, mock_wow_cis = _make_mock_wow_contributions(channel_columns)

    return (
        patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_license,
        ),
        patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
        patch(
            "mixlift_mcp.server._run_saturation_curves",
            return_value=mock_curves,
        ),
        patch(
            "mixlift_mcp.server._run_marginal_roas",
            return_value=(mock_mroas_means, mock_mroas_cis),
        ),
        patch(
            "mixlift_mcp.server._run_wow_channel_contributions",
            return_value=(mock_wow_means, mock_wow_cis),
        ),
        patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
        patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
    )


# ---------------------------------------------------------------------------
# Basic smoke test
# ---------------------------------------------------------------------------


class TestDigestSmoke:
    @pytest.mark.asyncio
    async def test_returns_json(self, wide_csv_30w, mock_pro_license):
        mock_mr = _make_mock_model_results()
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(
                    ["meta_spend", "email_spend", "tiktok_spend"]
                ),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(
                    ["meta_spend", "email_spend", "tiktok_spend"]
                ),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(
                    ["meta_spend", "email_spend", "tiktok_spend"]
                ),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(csv_path=wide_csv_30w)
            data = json.loads(result_str)
            assert data["tool"] == "mixlift_weekly_digest"

    @pytest.mark.asyncio
    async def test_memo_markdown_present(self, wide_csv_30w, mock_pro_license):
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(csv_path=wide_csv_30w)
            data = json.loads(result_str)
            assert "memo_markdown" in data
            assert len(data["memo_markdown"]) > 50


# ---------------------------------------------------------------------------
# Edge case 4: empty include=[]
# ---------------------------------------------------------------------------


class TestEmptyInclude:
    @pytest.mark.asyncio
    async def test_empty_include_returns_error(self, wide_csv_30w, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_weekly_digest(
                csv_path=wide_csv_30w,
                include=[],
            )
            data = json.loads(result_str)
            assert data["status"] == "error"
            assert "empty" in data["message"].lower()


# ---------------------------------------------------------------------------
# Edge case 9: invalid include value
# ---------------------------------------------------------------------------


class TestInvalidInclude:
    @pytest.mark.asyncio
    async def test_invalid_include_returns_error(self, wide_csv_30w, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_weekly_digest(
                csv_path=wide_csv_30w,
                include=["wow", "bad_section"],
            )
            data = json.loads(result_str)
            assert data["status"] == "error"
            assert "Invalid" in data["message"]

    @pytest.mark.asyncio
    async def test_error_message_lists_valid_options(self, wide_csv_30w, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_weekly_digest(
                csv_path=wide_csv_30w,
                include=["not_valid"],
            )
            data = json.loads(result_str)
            assert "wow" in data["message"]
            assert "saturation" in data["message"]


# ---------------------------------------------------------------------------
# Edge case 2: plan=None with "pacing" in include
# ---------------------------------------------------------------------------


class TestPacingNoplan:
    @pytest.mark.asyncio
    async def test_pacing_skipped_when_no_plan(self, wide_csv_30w, mock_pro_license):
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(
                csv_path=wide_csv_30w,
                include=["wow", "saturation", "pacing", "moves"],
                plan=None,
            )
            data = json.loads(result_str)
            assert data["tool"] == "mixlift_weekly_digest"
            assert "pacing" in data["sections_skipped"]

    @pytest.mark.asyncio
    async def test_pacing_memo_placeholder_present(self, wide_csv_30w, mock_pro_license):
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(
                csv_path=wide_csv_30w,
                include=["pacing"],
                plan=None,
            )
            data = json.loads(result_str)
            memo = data.get("memo_markdown", "")
            assert "unavailable" in memo.lower() or "pacing" in data["sections_skipped"]


# ---------------------------------------------------------------------------
# Edge case 3: include=["moves"] only
# ---------------------------------------------------------------------------


class TestMovesOnly:
    @pytest.mark.asyncio
    async def test_moves_only_succeeds(self, wide_csv_30w, mock_pro_license):
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(
                csv_path=wide_csv_30w,
                include=["moves"],
            )
            data = json.loads(result_str)
            assert data["tool"] == "mixlift_weekly_digest"

    @pytest.mark.asyncio
    async def test_moves_only_sections_included(self, wide_csv_30w, mock_pro_license):
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(
                csv_path=wide_csv_30w,
                include=["moves"],
            )
            data = json.loads(result_str)
            assert data["sections_included"] == ["moves"]


# ---------------------------------------------------------------------------
# Edge case 5: data shorter than 2 weeks (wow gets skipped)
# ---------------------------------------------------------------------------


class TestShortDataWoW:
    @pytest.mark.asyncio
    async def test_short_data_wow_skipped(self, wide_csv_30w, mock_pro_license):
        """Test that WoW section is skipped when data weeks falls below minimum.

        We mock the _weeks_total to 1 (below the minimum of 2) by patching
        pd.Timedelta arithmetic indirectly via the WoW period check logic.
        The easiest approach: mock _run_wow_channel_contributions to raise,
        which forces the section into sections_skipped.
        """
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                side_effect=RuntimeError("simulated wow failure"),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(csv_path=wide_csv_30w)
            data = json.loads(result_str)
            assert data["tool"] == "mixlift_weekly_digest"
            assert "wow" in data["sections_skipped"]


# ---------------------------------------------------------------------------
# Edge case 8: missing cached model → triggers fit
# ---------------------------------------------------------------------------


class TestMissingCache:
    @pytest.mark.asyncio
    async def test_no_cache_triggers_fit(self, tmp_path, mock_pro_license):
        """Use a unique CSV so the in-memory cache never has a hit."""
        n = 30
        dates = pd.date_range("2025-09-29", periods=n, freq="W-MON")
        rng = np.random.default_rng(999)
        df = pd.DataFrame(
            {
                "date": dates,
                "meta_spend": rng.uniform(5000, 20000, n),
                "email_spend": rng.uniform(500, 1500, n),
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        csv_path = str(tmp_path / "unique_missing_cache.csv")
        df.to_csv(csv_path, index=False)

        mock_mr = _make_mock_model_results(["meta_spend", "email_spend"])
        channels = ["meta_spend", "email_spend"]

        import mixlift_mcp.server as _server

        # Clear in-memory cache to guarantee no hit
        original_cache = dict(_server._MODEL_CACHE)
        _server._MODEL_CACHE.clear()

        try:
            with (
                patch(
                    "mixlift_mcp.server._resolve_license",
                    new_callable=AsyncMock,
                    return_value=mock_pro_license,
                ),
                patch(
                    "mixlift_mcp.server._run_pipeline", return_value=mock_mr
                ) as mock_pipeline,
                patch(
                    "mixlift_mcp.server._run_saturation_curves",
                    return_value=_make_mock_saturation_curves(channels),
                ),
                patch(
                    "mixlift_mcp.server._run_marginal_roas",
                    return_value=_make_mock_marginal_roas(channels),
                ),
                patch(
                    "mixlift_mcp.server._run_wow_channel_contributions",
                    return_value=_make_mock_wow_contributions(channels),
                ),
                patch(
                    "mixlift_mcp.model_cache.load_model",
                    new_callable=AsyncMock,
                    return_value=None,
                ),
                patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
            ):
                result_str = await mixlift_weekly_digest(csv_path=csv_path)
                data = json.loads(result_str)
                assert data["tool"] == "mixlift_weekly_digest"
                mock_pipeline.assert_called_once()
        finally:
            _server._MODEL_CACHE.clear()
            _server._MODEL_CACHE.update(original_cache)


# ---------------------------------------------------------------------------
# Path / file validation
# ---------------------------------------------------------------------------


class TestPathValidation:
    @pytest.mark.asyncio
    async def test_nonexistent_file_returns_error(self, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_weekly_digest(csv_path="/nonexistent/path/data.csv")
            data = json.loads(result_str)
            assert data["status"] == "error"

    @pytest.mark.asyncio
    async def test_blocked_ssh_path_returns_error(self, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_weekly_digest(
                csv_path="/home/user/.ssh/known_hosts.csv"
            )
            data = json.loads(result_str)
            assert data["status"] == "error"


# ---------------------------------------------------------------------------
# Graceful degradation: sibling module missing (ImportError path)
# ---------------------------------------------------------------------------


class TestGracefulDegradation:
    @pytest.mark.asyncio
    async def test_wow_memo_import_error_skips_section(
        self, wide_csv_30w, mock_pro_license
    ):
        """Mock wow_memo ImportError; digest should still render with skipped section."""
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]

        import sys

        # Temporarily break wow_memo import
        original = sys.modules.get("mixlift_mcp.renderers.wow_memo")
        sys.modules["mixlift_mcp.renderers.wow_memo"] = None  # type: ignore[assignment]

        try:
            with (
                patch(
                    "mixlift_mcp.server._resolve_license",
                    new_callable=AsyncMock,
                    return_value=mock_pro_license,
                ),
                patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
                patch(
                    "mixlift_mcp.server._run_saturation_curves",
                    return_value=_make_mock_saturation_curves(channels),
                ),
                patch(
                    "mixlift_mcp.server._run_marginal_roas",
                    return_value=_make_mock_marginal_roas(channels),
                ),
                patch(
                    "mixlift_mcp.server._run_wow_channel_contributions",
                    return_value=_make_mock_wow_contributions(channels),
                ),
                patch(
                    "mixlift_mcp.model_cache.load_model",
                    new_callable=AsyncMock,
                    return_value=None,
                ),
                patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
            ):
                result_str = await mixlift_weekly_digest(csv_path=wide_csv_30w)
                data = json.loads(result_str)
                # wow section may be skipped due to broken import
                # but tool itself should not error
                assert "tool" in data
                assert data["tool"] == "mixlift_weekly_digest" or data.get("status") == "error"
        finally:
            if original is not None:
                sys.modules["mixlift_mcp.renderers.wow_memo"] = original
            elif "mixlift_mcp.renderers.wow_memo" in sys.modules:
                del sys.modules["mixlift_mcp.renderers.wow_memo"]

    @pytest.mark.asyncio
    async def test_sections_skipped_populated_on_failure(
        self, wide_csv_30w, mock_pro_license
    ):
        """When saturation computation fails, sections_skipped is populated."""
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                side_effect=RuntimeError("saturation failed"),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(csv_path=wide_csv_30w)
            data = json.loads(result_str)
            assert data["tool"] == "mixlift_weekly_digest"
            assert "saturation" in data["sections_skipped"]


# ---------------------------------------------------------------------------
# Sections included / structure
# ---------------------------------------------------------------------------


class TestSectionsStructure:
    @pytest.mark.asyncio
    async def test_sections_included_subset_of_valid(self, wide_csv_30w, mock_pro_license):
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(csv_path=wide_csv_30w)
            data = json.loads(result_str)
            from mixlift_mcp.renderers.digest_memo import VALID_SECTIONS

            assert all(s in VALID_SECTIONS for s in data["sections_included"])

    @pytest.mark.asyncio
    async def test_version_is_0_5_3(self, wide_csv_30w, mock_pro_license):
        mock_mr = _make_mock_model_results()
        channels = ["meta_spend", "email_spend", "tiktok_spend"]
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(csv_path=wide_csv_30w)
            data = json.loads(result_str)
            assert data["version"] == "0.5.3"


# ---------------------------------------------------------------------------
# Regression: Fix 1 — WoW section not silently dropped on RangeIndex X_fit
# ---------------------------------------------------------------------------
# BEFORE the fix: X_fit has a default RangeIndex (not DatetimeIndex) after
# _load_wide_format.  The old code did pd.to_datetime(X_fit.index), turning
# integer positions into nanosecond-epoch dates (~1970-01-01), so _total_weeks
# rounded to 0, a RuntimeError was raised, and the broad except caught it,
# silently appending "wow" to sections_skipped.
#
# AFTER the fix: X_fit["date"] is used directly.  This test MUST FAIL on the
# old code and PASS after the fix.
# ---------------------------------------------------------------------------


class TestWoWNotSkippedOnRangeIndex:
    @pytest.mark.asyncio
    async def test_wow_present_when_x_has_range_index(self, tmp_path, mock_pro_license):
        """WoW section must be present even when X_fit carries a RangeIndex.

        Reproduces the production scenario: _load_wide_format returns X with a
        default RangeIndex and a 'date' column.  The old code accessed X_fit.index
        (integer positions), producing nanosecond-epoch timestamps → _total_weeks=0
        → RuntimeError → section silently skipped.
        """
        # Build a 30-week wide CSV so the RangeIndex is clearly NOT dates
        n = 30
        dates = pd.date_range("2025-09-29", periods=n, freq="W-MON")
        rng = np.random.default_rng(99)
        df = pd.DataFrame(
            {
                "date": dates,
                "meta_spend": rng.uniform(5000, 20000, n),
                "email_spend": rng.uniform(500, 1500, n),
                "revenue": rng.uniform(50000, 150000, n),
            }
        )
        path = tmp_path / "range_index_test.csv"
        df.to_csv(path, index=False)

        channels = ["meta_spend", "email_spend"]
        mock_mr = _make_mock_model_results(channels)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_saturation_curves",
                return_value=_make_mock_saturation_curves(channels),
            ),
            patch(
                "mixlift_mcp.server._run_marginal_roas",
                return_value=_make_mock_marginal_roas(channels),
            ),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=_make_mock_wow_contributions(channels),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result_str = await mixlift_weekly_digest(csv_path=str(path))
            data = json.loads(result_str)

        assert data["tool"] == "mixlift_weekly_digest"
        # WoW section must NOT be silently dropped
        assert "wow" not in data["sections_skipped"], (
            "WoW was silently skipped — likely X_fit.index (RangeIndex) used instead "
            "of X_fit['date'].  See Fix 1 in G3 review."
        )
        assert "wow" in data["sections_included"]
        assert "sections" in data
        assert "wow" in data["sections"]
        wow_section = data["sections"]["wow"]
        assert wow_section.get("memo_markdown"), "WoW memo_markdown is empty"
