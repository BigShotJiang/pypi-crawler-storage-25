"""Tool-level integration tests for mixlift_wow.

All tests mock _run_pipeline and _run_wow_channel_contributions so no MCMC fit
is executed.
"""

from __future__ import annotations

import json
from contextlib import ExitStack
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.license import LicenseStatus
from mixlift_mcp.server import mixlift_wow

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


def _wide_csv(tmp_path, n_weeks: int = 30) -> str:
    """Create a wide-format CSV with n_weeks of data (3 channels)."""
    dates = pd.date_range("2025-09-22", periods=n_weeks, freq="W-MON")
    rng = np.random.default_rng(42)
    df = pd.DataFrame(
        {
            "date": dates,
            "meta_spend": rng.uniform(5000, 20000, n_weeks),
            "google_search_spend": rng.uniform(3000, 10000, n_weeks),
            "tiktok_spend": rng.uniform(1000, 5000, n_weeks),
            "revenue": rng.uniform(50000, 150000, n_weeks),
        }
    )
    path = tmp_path / f"wide_3ch_{n_weeks}w.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def wide_csv_30w(tmp_path):
    return _wide_csv(tmp_path, n_weeks=30)


@pytest.fixture
def wide_csv_1w(tmp_path):
    """Only 1 week — not enough for 'week' period (needs 2)."""
    return _wide_csv(tmp_path, n_weeks=1)


@pytest.fixture
def wide_csv_14w(tmp_path):
    """14 weeks — passes CSV validation but not enough for 'quarter' (needs 26)."""
    return _wide_csv(tmp_path, n_weeks=14)


@pytest.fixture
def mock_pro_license():
    return LicenseStatus(is_pro=True, max_channels=999, max_rows=999_999, message="Pro")


@pytest.fixture
def mock_free_license():
    return LicenseStatus(is_pro=False, max_channels=2, max_rows=2000, message="Free")


def _make_mock_model_results(channels=None):
    """Build a minimal ModelResults mock."""
    if channels is None:
        channels = ["meta_spend", "google_search_spend", "tiktok_spend"]
    mr = MagicMock()
    mr.mmm = MagicMock()
    mr.roas_estimates = {c: 1.5 for c in channels}
    mr.roas_ci = {c: (0.8, 2.2) for c in channels}
    mr.channel_contributions = {c: 30_000.0 for c in channels}
    mr.channel_contributions_ci = {c: (20_000.0, 40_000.0) for c in channels}
    mr.total_spend = {c: 10_000.0 for c in channels}
    mr.duration_secs = 5.0
    mr.convergence_warnings = []
    mr.raw_contributions = MagicMock()
    mr.loo_cv = {}
    mr.intercept_decomposition = {}
    return mr


def _make_mock_contributions(channel_columns, value: float = 80_000.0):
    """Build synthetic contribution dicts for the given column names."""
    from mixlift.modeling.optimizer import format_channel_name

    means = {}
    cis = {}
    for col in channel_columns:
        display = format_channel_name(col)
        means[display] = value
        cis[display] = (value * 0.8, value * 1.2)
    return means, cis


def _apply_wow_patches(stack: ExitStack, mock_mr, mock_license, mock_means, mock_cis):
    """Enter all wow patches into an ExitStack and return them."""
    stack.enter_context(
        patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_license,
        )
    )
    stack.enter_context(patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr))
    stack.enter_context(
        patch(
            "mixlift_mcp.server._run_wow_channel_contributions",
            return_value=(mock_means, mock_cis),
        )
    )
    stack.enter_context(
        patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None)
    )
    stack.enter_context(patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock))


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


class TestMixliftWowHappyPath:
    @pytest.mark.asyncio
    async def test_returns_json_string(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_mr),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            result = await mixlift_wow(wide_csv_30w, period="week")

        assert isinstance(result, str)
        parsed = json.loads(result)
        assert isinstance(parsed, dict)

    @pytest.mark.asyncio
    async def test_tool_field_is_mixlift_wow(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with ExitStack() as stack:
            _apply_wow_patches(stack, mock_mr, mock_pro_license, mock_means, mock_cis)
            result_str = await mixlift_wow(wide_csv_30w, period="week")

        parsed = json.loads(result_str)
        assert parsed["tool"] == "mixlift_wow"

    @pytest.mark.asyncio
    async def test_version_field(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with ExitStack() as stack:
            _apply_wow_patches(stack, mock_mr, mock_pro_license, mock_means, mock_cis)
            result_str = await mixlift_wow(wide_csv_30w, period="week")

        parsed = json.loads(result_str)
        assert parsed["version"] == "0.5.3"

    @pytest.mark.asyncio
    async def test_required_top_level_keys_present(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with ExitStack() as stack:
            _apply_wow_patches(stack, mock_mr, mock_pro_license, mock_means, mock_cis)
            result_str = await mixlift_wow(wide_csv_30w, period="week")

        parsed = json.loads(result_str)

        required = {
            "tool",
            "version",
            "mcmc_config",
            "data_window",
            "period_label",
            "period_weeks",
            "current_revenue",
            "prior_revenue",
            "delta",
            "delta_pct",
            "baseline",
            "paid_total",
            "channels",
            "memo_markdown",
        }
        assert required.issubset(set(parsed.keys()))

    @pytest.mark.asyncio
    async def test_period_weeks_for_week(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with ExitStack() as stack:
            _apply_wow_patches(stack, mock_mr, mock_pro_license, mock_means, mock_cis)
            result_str = await mixlift_wow(wide_csv_30w, period="week")

        parsed = json.loads(result_str)
        assert parsed["period_weeks"] == 1

    @pytest.mark.asyncio
    async def test_period_weeks_for_4_weeks(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with ExitStack() as stack:
            _apply_wow_patches(stack, mock_mr, mock_pro_license, mock_means, mock_cis)
            result_str = await mixlift_wow(wide_csv_30w, period="4_weeks")

        parsed = json.loads(result_str)
        assert parsed["period_weeks"] == 4

    @pytest.mark.asyncio
    async def test_memo_markdown_non_empty(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with ExitStack() as stack:
            _apply_wow_patches(stack, mock_mr, mock_pro_license, mock_means, mock_cis)
            result_str = await mixlift_wow(wide_csv_30w, period="week")

        parsed = json.loads(result_str)
        assert isinstance(parsed["memo_markdown"], str)
        assert len(parsed["memo_markdown"]) > 50

    @pytest.mark.asyncio
    async def test_channels_sorted_abs_delta_desc(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        # Give different contribution values so deltas differ
        from mixlift.modeling.optimizer import format_channel_name

        mock_means = {
            format_channel_name(c): v
            for c, v in zip(channel_columns, [120_000.0, 80_000.0, 40_000.0])
        }
        mock_cis = {k: (v * 0.8, v * 1.2) for k, v in mock_means.items()}

        with ExitStack() as stack:
            _apply_wow_patches(stack, mock_mr, mock_pro_license, mock_means, mock_cis)
            result_str = await mixlift_wow(wide_csv_30w, period="week")

        parsed = json.loads(result_str)
        abs_deltas = [abs(ch["delta"]) for ch in parsed["channels"]]
        assert abs_deltas == sorted(abs_deltas, reverse=True)

    @pytest.mark.asyncio
    async def test_use_y_sum_for_revenue_not_x_column(self, wide_csv_30w, mock_pro_license):
        """current_revenue and prior_revenue must come from y.sum(), not X column scan."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        with ExitStack() as stack:
            _apply_wow_patches(stack, mock_mr, mock_pro_license, mock_means, mock_cis)
            result_str = await mixlift_wow(wide_csv_30w, period="week")

        parsed = json.loads(result_str)
        # Revenue must be numeric, not a string or null
        assert isinstance(parsed["current_revenue"], (int, float))
        assert isinstance(parsed["prior_revenue"], (int, float))
        assert parsed["current_revenue"] > 0
        assert parsed["prior_revenue"] > 0


# ---------------------------------------------------------------------------
# Edge case 1: Data shorter than 2× period
# ---------------------------------------------------------------------------


class TestDataShortfall:
    @pytest.mark.asyncio
    async def test_14w_data_insufficient_for_quarter_period(self, wide_csv_14w, mock_pro_license):
        """14 weeks is not enough for 'quarter' period which requires 26 weeks."""
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_wow(wide_csv_14w, period="quarter")
        parsed = json.loads(result_str)
        assert parsed.get("status") == "error"
        assert "requires" in parsed["message"].lower() or "shortfall" in parsed["message"].lower()

    @pytest.mark.asyncio
    async def test_short_data_error_mentions_period(self, wide_csv_14w, mock_pro_license):
        """The error message should mention the period requirement."""
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_wow(wide_csv_14w, period="quarter")
        parsed = json.loads(result_str)
        assert "message" in parsed
        assert "quarter" in parsed["message"].lower() or "26" in parsed["message"]

    @pytest.mark.asyncio
    async def test_short_data_returns_valid_json(self, wide_csv_1w, mock_pro_license):
        """Any data length must return valid JSON, never crash."""
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_wow(wide_csv_1w, period="week")
        assert isinstance(json.loads(result_str), dict)


# ---------------------------------------------------------------------------
# Edge case 6: Invalid period string
# ---------------------------------------------------------------------------


class TestInvalidPeriod:
    @pytest.mark.asyncio
    async def test_invalid_period_returns_error(self, wide_csv_30w, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_wow(wide_csv_30w, period="last_month")
        parsed = json.loads(result_str)
        assert parsed.get("status") == "error"

    @pytest.mark.asyncio
    async def test_invalid_period_lists_valid_options(self, wide_csv_30w, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_wow(wide_csv_30w, period="monthly")
        parsed = json.loads(result_str)
        assert "week" in parsed["message"] or "4_weeks" in parsed["message"]

    @pytest.mark.asyncio
    async def test_invalid_period_does_not_fit_model(self, wide_csv_30w, mock_pro_license):
        """No MCMC fit should be triggered for an invalid period."""
        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline") as mock_fit,
        ):
            await mixlift_wow(wide_csv_30w, period="bad_period")
        mock_fit.assert_not_called()


# ---------------------------------------------------------------------------
# Edge case 7: Missing cached model triggers fit
# ---------------------------------------------------------------------------


class TestMissingCachedModel:
    @pytest.mark.asyncio
    async def test_cache_miss_triggers_pipeline(self, wide_csv_30w, mock_pro_license):
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        pipeline_called = []

        def _capture_pipeline(*args, **kwargs):
            pipeline_called.append(True)
            return mock_mr

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline", side_effect=_capture_pipeline),
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch("mixlift_mcp.model_cache.load_model", new_callable=AsyncMock, return_value=None),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
            # Clear the in-memory model cache so we always start from a cache miss
            patch("mixlift_mcp.server._MODEL_CACHE", {}),
        ):
            result_str = await mixlift_wow(wide_csv_30w, period="week")

        assert len(pipeline_called) == 1, "Pipeline should have been called once on cache miss"
        parsed = json.loads(result_str)
        assert parsed.get("status") != "error"

    @pytest.mark.asyncio
    async def test_cache_hit_skips_pipeline(self, wide_csv_30w, mock_pro_license):
        """When model is loaded from disk cache, _run_pipeline must NOT be called."""
        channel_columns = ["meta_spend", "google_search_spend", "tiktok_spend"]
        mock_mr = _make_mock_model_results(channel_columns)
        mock_means, mock_cis = _make_mock_contributions(channel_columns)

        # Build a fake y Series aligned to a 30-row date range
        n = 30
        dates = pd.date_range("2025-09-22", periods=n, freq="W-MON")
        fake_y = pd.Series([80_000.0] * n, index=range(n))

        # Build fake X with a date column
        rng = np.random.default_rng(99)
        fake_X = pd.DataFrame(  # noqa: N806
            {
                "date": dates,
                "meta_spend": rng.uniform(5000, 20000, n),
                "google_search_spend": rng.uniform(3000, 10000, n),
                "tiktok_spend": rng.uniform(1000, 5000, n),
            }
        )

        fake_cache_entry = {
            "mmm": mock_mr.mmm,
            "X": fake_X,
            "y": fake_y,
            "channel_columns": channel_columns,
            "model_results": mock_mr,
            "result": {},
        }

        with (
            patch(
                "mixlift_mcp.server._resolve_license",
                new_callable=AsyncMock,
                return_value=mock_pro_license,
            ),
            patch("mixlift_mcp.server._run_pipeline") as mock_fit,
            patch(
                "mixlift_mcp.server._run_wow_channel_contributions",
                return_value=(mock_means, mock_cis),
            ),
            patch(
                "mixlift_mcp.model_cache.load_model",
                new_callable=AsyncMock,
                return_value=fake_cache_entry,
            ),
            patch("mixlift_mcp.model_cache.save_model", new_callable=AsyncMock),
        ):
            await mixlift_wow(wide_csv_30w, period="week")

        mock_fit.assert_not_called()


# ---------------------------------------------------------------------------
# Error paths
# ---------------------------------------------------------------------------


class TestErrorPaths:
    @pytest.mark.asyncio
    async def test_missing_file_returns_error(self, mock_pro_license):
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_wow("/nonexistent/path/file.csv", period="week")
        parsed = json.loads(result_str)
        assert parsed.get("status") == "error"

    @pytest.mark.asyncio
    async def test_all_error_paths_return_json(self, mock_pro_license):
        """Every error path must return valid JSON, never raise."""
        with patch(
            "mixlift_mcp.server._resolve_license",
            new_callable=AsyncMock,
            return_value=mock_pro_license,
        ):
            result_str = await mixlift_wow("/tmp/does_not_exist.csv", period="week")
        # Must be valid JSON
        assert isinstance(json.loads(result_str), dict)
