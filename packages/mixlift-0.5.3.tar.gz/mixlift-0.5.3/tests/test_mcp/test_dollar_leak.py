"""N3: Verify that free-tier output contains no dollar amounts.

Free-tier users should see percentages only. Paid users see dollar values.
The main leak vector was channel_contributions exposing raw dollar amounts.
"""

from __future__ import annotations

import json
import re
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.license import (
    FREE_MAX_CHANNELS,
    FREE_MAX_ROWS,
    PRO_MAX_CHANNELS,
    PRO_MAX_ROWS,
    LicenseStatus,
)
from mixlift_mcp.server import (
    _build_result,
    _build_tiered_response,
    _gate_channel_contributions,
    mixlift_analyze,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_model_results(channels: list[str]):
    """Build a mock ModelResults with known dollar amounts."""
    results = MagicMock()
    results.roas_estimates = {"Meta": 2.5, "Google": 3.2}
    results.roas_ci = {"Meta": (1.8, 3.2), "Google": (2.5, 3.9)}
    results.channel_contributions = {"Meta": 45000.0, "Google": 30000.0}
    results.channel_contributions_ci = {
        "Meta": (36000.0, 54000.0),
        "Google": (24000.0, 36000.0),
    }
    results.marginal_roas_estimates = {"Meta": 2.0, "Google": 2.8}
    results.marginal_roas_ci = {"Meta": (1.5, 2.5), "Google": (2.2, 3.4)}
    results.total_spend = {"Meta": 18000.0, "Google": 12000.0}
    results.convergence_warnings = []
    results.duration_secs = 8.0
    results.mmm = MagicMock()
    results.loo_cv = None
    results.intercept_decomposition = None
    results.raw_contributions = MagicMock()
    return results


def _make_optimization():
    return {
        "current_allocation": {"Meta": 8000, "Google": 5000},
        "optimal_allocation": {"Meta": 6000, "Google": 7000},
        "total_budget": 13000,
        "expected_lift_pct": 12.5,
    }


def _make_saturation_curves():
    return {
        "Meta": {
            "spend": list(range(0, 5001, 500)),
            "response": [float(i * 0.6) for i in range(0, 5001, 500)],
        },
        "Google": {
            "spend": list(range(0, 5001, 500)),
            "response": [float(i * 0.8) for i in range(0, 5001, 500)],
        },
    }


FREE = LicenseStatus(False, FREE_MAX_CHANNELS, FREE_MAX_ROWS, "Free tier")
PRO = LicenseStatus(True, PRO_MAX_CHANNELS, PRO_MAX_ROWS, "Growth tier")


# ---------------------------------------------------------------------------
# Unit tests: _gate_channel_contributions
# ---------------------------------------------------------------------------


class TestGateChannelContributions:
    """Unit tests for the tier-gating function."""

    def test_paid_returns_dollar_amounts(self):
        contributions = {"Meta": 45000.0, "Google": 30000.0}
        ci = {"Meta": (36000.0, 54000.0), "Google": (24000.0, 36000.0)}

        result = _gate_channel_contributions(contributions, ci, is_paid=True)

        assert result["estimates"]["Meta"] == 45000.0
        assert result["estimates"]["Google"] == 30000.0
        assert result["confidence_intervals"]["Meta"]["low"] == 36000.0
        assert "unit" not in result
        assert "note" not in result

    def test_free_returns_percentages(self):
        contributions = {"Meta": 45000.0, "Google": 30000.0}
        ci = {"Meta": (36000.0, 54000.0), "Google": (24000.0, 36000.0)}
        total = 75000.0

        result = _gate_channel_contributions(contributions, ci, is_paid=False)

        assert result["unit"] == "percent"
        assert "note" in result
        assert result["estimates"]["Meta"] == round(45000.0 / total * 100, 1)
        assert result["estimates"]["Google"] == round(30000.0 / total * 100, 1)
        # Percentages should sum to ~100
        assert abs(sum(result["estimates"].values()) - 100.0) < 0.5

    def test_free_has_no_dollar_amounts(self):
        contributions = {"Meta": 45000.0, "Google": 30000.0}
        ci = {"Meta": (36000.0, 54000.0), "Google": (24000.0, 36000.0)}

        result = _gate_channel_contributions(contributions, ci, is_paid=False)

        # No value in the result should exceed 100 (all should be percentages)
        for v in result["estimates"].values():
            assert v <= 100.0, f"Value {v} looks like a dollar amount, not a percentage"
        for v in result["confidence_intervals"].values():
            assert v["high"] <= 200.0, f"CI high {v['high']} looks like a dollar amount"

    def test_free_handles_zero_total(self):
        contributions = {"Meta": 0.0, "Google": 0.0}
        ci = {"Meta": (0.0, 0.0), "Google": (0.0, 0.0)}

        result = _gate_channel_contributions(contributions, ci, is_paid=False)

        # Should not raise ZeroDivisionError
        assert result["estimates"]["Meta"] == 0.0


# ---------------------------------------------------------------------------
# Integration: _build_result free-tier output has no dollar leak
# ---------------------------------------------------------------------------


class TestBuildResultDollarLeak:
    """Verify _build_result gates all dollar amounts for free tier."""

    def _build_free_result(self):
        return _build_result(
            model_results=_make_model_results(["meta_spend", "google_spend"]),
            optimization=_make_optimization(),
            saturation_curves=_make_saturation_curves(),
            channel_columns=["meta_spend", "google_spend"],
            license_status=FREE,
            csv_format="wide",
        )

    def _build_pro_result(self):
        return _build_result(
            model_results=_make_model_results(["meta_spend", "google_spend"]),
            optimization=_make_optimization(),
            saturation_curves=_make_saturation_curves(),
            channel_columns=["meta_spend", "google_spend"],
            license_status=PRO,
            csv_format="wide",
        )

    def test_free_channel_contributions_are_percentages(self):
        result = self._build_free_result()
        cc = result["channel_contributions"]
        assert cc["unit"] == "percent"
        for v in cc["estimates"].values():
            assert v <= 100.0

    def test_pro_channel_contributions_are_dollars(self):
        result = self._build_pro_result()
        cc = result["channel_contributions"]
        assert "unit" not in cc
        # Dollar amounts should be large numbers
        assert result["channel_contributions"]["estimates"]["Meta"] == 45000.0

    def test_free_headline_has_no_dollar_sign(self):
        result = self._build_free_result()
        headline = result["headline"]
        assert "$" not in headline or "Upgrade" in headline or "$299" in headline

    def test_free_budget_optimization_gated(self):
        result = self._build_free_result()
        bo = result["budget_optimization"]
        assert isinstance(bo["current_allocation"], str)
        assert "Upgrade" in bo["current_allocation"]

    def test_free_total_spend_gated(self):
        result = self._build_free_result()
        assert isinstance(result["model_info"]["total_spend"], str)
        assert "Upgrade" in result["model_info"]["total_spend"]

    def test_free_recommendations_redacted(self):
        result = self._build_free_result()
        for action in result["recommendations"]["actions"]:
            assert isinstance(action["change_amount"], str)
            assert "Upgrade" in action["change_amount"]

    def test_free_no_raw_dollar_in_json(self):
        """Scan the entire free-tier JSON for dollar amounts that shouldn't be there."""
        import re

        result = self._build_free_result()
        result_json = json.dumps(result)

        # Find all dollar amounts in the JSON
        dollar_matches = re.findall(r"\$[\d,]+(?:\.\d+)?", result_json)

        # Filter out legitimate occurrences ($299 is the pricing mention, $XXX is redacted)
        leaks = [m for m in dollar_matches if m not in ("$299", "$XXX")]

        assert leaks == [], f"Dollar amounts leaked in free-tier output: {leaks}"


# ---------------------------------------------------------------------------
# E2E: Full mixlift_analyze with free tier
# ---------------------------------------------------------------------------


class TestAnalyzeFreeTierE2E:
    """Run mixlift_analyze with a free license and check for leaks."""

    @pytest.mark.asyncio
    async def test_free_tier_no_dollar_leak(self, tmp_path):
        import re

        model_results = _make_model_results(["meta_spend", "google_spend"])
        optimization = _make_optimization()
        saturation_curves = _make_saturation_curves()

        # Create a test CSV
        rng = np.random.default_rng(42)
        n = 52
        df = pd.DataFrame(
            {
                "date": pd.date_range("2023-01-01", periods=n, freq="W-MON"),
                "meta_spend": rng.uniform(1000, 5000, n),
                "google_spend": rng.uniform(2000, 8000, n),
                "revenue": rng.uniform(30000, 80000, n),
            }
        )
        csv_path = tmp_path / "test.csv"
        df.to_csv(csv_path, index=False)

        mem_dir = tmp_path / "memory"
        with (
            patch("mixlift_mcp.server.validate_license", new_callable=AsyncMock, return_value=FREE),
            patch("mixlift_mcp.server._run_pipeline", return_value=model_results),
            patch("mixlift_mcp.server._run_optimizer", return_value=optimization),
            patch("mixlift_mcp.server._run_saturation", return_value=saturation_curves),
            patch("mixlift_mcp.memory.MEMORY_DIR", mem_dir),
        ):
            result_json = await mixlift_analyze(csv_path=str(csv_path), license_key="")

        data = json.loads(result_json)
        assert data["status"] == "success"

        # Scan for dollar amount leaks (excluding pricing mentions)
        full_json = json.dumps(data)
        dollar_matches = re.findall(r"\$[\d,]+(?:\.\d+)?", full_json)
        leaks = [m for m in dollar_matches if m not in ("$299", "$XXX")]
        assert leaks == [], f"Dollar amounts leaked in free-tier E2E output: {leaks}"

        # Channel contributions should be percentages
        sd = data.get("structured_data", {})
        cc = sd.get("channel_contributions", {})
        if "unit" in cc:
            assert cc["unit"] == "percent"


# ---------------------------------------------------------------------------
# readout_markdown dollar-leak guards
# ---------------------------------------------------------------------------

def _make_tiered_free_result() -> dict:
    """Minimal _build_result-shaped free-tier dict for _build_tiered_response."""
    return {
        "status": "success",
        "license": {"tier": "free"},
        "headline": (
            "MixLift found a +12.5% budget optimization opportunity. "
            "Upgrade to Growth ($299/mo) to see exact dollar values."
        ),
        "data": {
            "format_detected": "wide",
            "channels": ["meta_spend", "google_spend"],
            "n_channels": 2,
        },
        "roas": {
            "estimates": {"meta_spend": 2.5, "google_spend": 3.2},
            "confidence_intervals": {
                "meta_spend": {"low": 1.8, "high": 3.2},
                "google_spend": {"low": 2.5, "high": 3.9},
            },
        },
        "confidence_summary": {},
        "channel_contributions": {
            "unit": "percent",
            "note": "Upgrade to Growth ($299/mo) to see dollar contributions.",
            "estimates": {"meta_spend": 60.0, "google_spend": 40.0},
            "confidence_intervals": {
                "meta_spend": {"low": 48.0, "high": 72.0},
                "google_spend": {"low": 32.0, "high": 48.0},
            },
        },
        "saturation_analysis": {},
        "budget_optimization": {
            "current_allocation": "Upgrade to Growth ($299/mo) to see dollar allocations",
            "optimal_allocation": "Upgrade to Growth ($299/mo) to see dollar allocations",
            "total_budget": "Upgrade to Growth ($299/mo) to see dollar allocations",
            "expected_lift_pct": 12.5,
        },
        "recommendations": {
            "summary": "Rebalance toward Google (higher ROAS).",
            "actions": [
                {
                    "rank": 1,
                    "action": "INCREASE",
                    "channel": "google_spend",
                    "change_amount": "Upgrade to Growth ($299/mo)",
                    "current_spend": "Upgrade to Growth ($299/mo)",
                    "optimal_spend": "Upgrade to Growth ($299/mo)",
                    "roas": 3.2,
                    "reason": "Highest ROAS in your mix.",
                },
            ],
        },
        "marginal_roas": {
            "estimates": {"meta_spend": 2.0, "google_spend": 2.8},
            "confidence_intervals": {
                "meta_spend": {"low": 1.5, "high": 2.5},
                "google_spend": {"low": 2.2, "high": 3.4},
            },
        },
        "model_fit": {
            "r_squared": 0.82,
            "mape": 7.1,
            "label": "Explains 82% of revenue variation.",
        },
        "analysis_badge": None,
        "memory": None,
        "model_info": {
            "duration_secs": 8.0,
            "total_spend": "Upgrade to Growth ($299/mo)",
            "data_window": {"weeks": 52},
            "mcmc_config": "4 chains, 250 draws, target_accept=0.90",
        },
        "model_fingerprint": "fp-leak-test",
    }


def _make_tiered_paid_result() -> dict:
    """Minimal _build_result-shaped paid-tier dict for _build_tiered_response."""
    result = _make_tiered_free_result()
    result["license"] = {"tier": "pro"}
    result["headline"] = "Google earns $3.20/dollar; shift $1,000/wk to capture +12.5% revenue."
    result["budget_optimization"] = {
        "current_allocation": {"meta_spend": 8000.0, "google_spend": 5000.0},
        "optimal_allocation": {"meta_spend": 6000.0, "google_spend": 7000.0},
        "total_budget": 13000.0,
        "expected_lift_pct": 12.5,
    }
    result["model_info"]["total_spend"] = {"meta_spend": 18000.0, "google_spend": 12000.0}
    result["channel_contributions"] = {
        "estimates": {"meta_spend": 45000.0, "google_spend": 30000.0},
        "confidence_intervals": {
            "meta_spend": {"low": 36000.0, "high": 54000.0},
            "google_spend": {"low": 24000.0, "high": 36000.0},
        },
    }
    result["recommendations"]["actions"] = [
        {
            "rank": 1,
            "action": "INCREASE",
            "channel": "google_spend",
            "change_amount": 2000.0,
            "current_spend": 5000.0,
            "optimal_spend": 7000.0,
            "roas": 3.2,
            "reason": "Highest ROAS; shift $2,000/wk here.",
        },
    ]
    return result


class TestReadoutMarkdownDollarLeak:
    """Critical guards: readout_markdown must not leak dollar amounts on free tier."""

    def test_readout_markdown_free_tier_no_dollar_leak(self):
        """JSON-dump the entire free-tier _build_tiered_response output and assert
        no dollar amounts appear. This is the canonical regression guard for the
        free-tier readout fix."""
        data = _build_tiered_response(_make_tiered_free_result())
        full_json = json.dumps(data)

        dollar_matches = re.findall(r"\$[\d,]+(?:\.\d+)?", full_json)
        leaks = [m for m in dollar_matches if m not in ("$299", "$XXX")]
        assert leaks == [], (
            f"Dollar amounts leaked into free-tier tiered response: {leaks}"
        )

    def test_readout_markdown_paid_tier_has_dollar_signs(self):
        """Positive-path sanity: paid-tier readout_markdown must contain '$'."""
        data = _build_tiered_response(_make_tiered_paid_result())
        rm = data["summary"]["readout_markdown"]
        assert "$" in rm, "Paid-tier readout_markdown should contain dollar signs"


# ---------------------------------------------------------------------------
# N9 Platform comparison dollar-leak guard
# ---------------------------------------------------------------------------


class TestPlatformComparisonDollarLeak:
    """Free-tier platform_attribution_comparison must not expose dollar amounts."""

    def _make_free_result_with_platform(self) -> dict:
        from mixlift_mcp.server import _gate_platform_comparison_for_tier

        result = _make_tiered_free_result()
        # Inject a realistic platform comparison (as if compute_platform_comparison ran)
        raw_comparison = {
            "source": "mcp_argument",
            "channels": {
                "Meta": {
                    "platform_roas": 3.2,
                    "platform_revenue": 64000.0,  # dollar amount — must be stripped
                    "mmm_roas": 1.05,
                    "mmm_roas_ci_low": 0.7,
                    "mmm_roas_ci_high": 1.4,
                    "spend": 20000.0,
                    "gap_pct": -0.672,
                    "verdict": "over_claiming",
                    "severity": "extreme",
                    "confidence": "medium",
                    "one_liner": "Meta claims 3.20x ROAS; MixLift measures 1.05x. Gap 67%.",
                },
                "Google": {
                    "platform_roas": 2.5,
                    "platform_revenue": 50000.0,  # dollar amount — must be stripped
                    "mmm_roas": 2.3,
                    "mmm_roas_ci_low": 1.8,
                    "mmm_roas_ci_high": 2.8,
                    "spend": 20000.0,
                    "gap_pct": -0.08,
                    "verdict": "aligned",
                    "severity": None,
                    "confidence": "high",
                    "one_liner": "Google claims 2.50x ROAS; MixLift measures 2.30x. Gap 8%.",
                },
            },
            "summary": {
                "channels_over_claiming": ["Meta"],
                "channels_aligned": ["Google"],
                "channels_under_claiming": [],
                "most_egregious": {"channel": "Meta", "gap_pct": -0.672},
                "total_platform_revenue": 114000.0,  # dollar — must be stripped
                "total_mmm_revenue": 67000.0,  # dollar — must be stripped
                "phantom_revenue_pct": 0.412,  # percentage — must survive
            },
            "excluded_channels": [],
        }
        result["platform_attribution_comparison"] = _gate_platform_comparison_for_tier(
            raw_comparison, is_paid=False
        )
        return result

    def test_platform_comparison_free_tier_no_dollar_leak(self):
        """Free-tier platform_attribution_comparison must not contain raw dollar amounts.

        Scans the full JSON for $NNN patterns; only $299 and $XXX are whitelisted.
        """
        result = self._make_free_result_with_platform()
        data = _build_tiered_response(result)
        full_json = json.dumps(data)

        dollar_matches = re.findall(r"\$[\d,]+(?:\.\d+)?", full_json)
        leaks = [m for m in dollar_matches if m not in ("$299", "$XXX")]
        assert leaks == [], (
            f"Dollar amounts leaked into free-tier platform comparison: {leaks}"
        )

    def test_platform_comparison_free_tier_percentages_visible(self):
        """Free-tier: gap_pct and phantom_revenue_pct remain as numbers."""
        result = self._make_free_result_with_platform()
        data = _build_tiered_response(result)
        sd = data["structured_data"]
        comp = sd.get("platform_attribution_comparison", {})

        # gap_pct should still be a number
        for ch, ch_data in comp.get("channels", {}).items():
            gap = ch_data.get("gap_pct")
            if gap is not None:
                assert isinstance(gap, (int, float)), (
                    f"{ch}: gap_pct must be numeric on free tier"
                )

        # phantom_revenue_pct should be numeric
        pct = comp.get("summary", {}).get("phantom_revenue_pct")
        if pct is not None:
            assert isinstance(pct, (int, float)), "phantom_revenue_pct must be numeric"

    def test_platform_comparison_free_tier_total_revenues_redacted(self):
        """Free-tier: total_platform_revenue and total_mmm_revenue are redacted strings."""
        result = self._make_free_result_with_platform()
        data = _build_tiered_response(result)
        sd = data["structured_data"]
        comp = sd.get("platform_attribution_comparison", {})
        summary = comp.get("summary", {})

        total_plat = summary.get("total_platform_revenue")
        total_mmm = summary.get("total_mmm_revenue")

        if total_plat is not None:
            assert isinstance(total_plat, str), "total_platform_revenue must be string on free tier"
            assert "Upgrade" in total_plat
        if total_mmm is not None:
            assert isinstance(total_mmm, str), "total_mmm_revenue must be string on free tier"
            assert "Upgrade" in total_mmm


# ---------------------------------------------------------------------------
# N7 Backtest dollar-leak guard
# ---------------------------------------------------------------------------


def _make_backtest_with_weekly_dollars() -> dict:
    """Build a realistic backtest dict containing weekly dollar arrays."""
    return {
        "mode": "walk_forward_cv",
        "status": "success",
        "n_folds": 3,
        "horizon_weeks": 4,
        "folds": [
            {
                "fold": 1,
                "test_start": "2023-10-02",
                "test_end": "2023-10-23",
                "mape": 8.4,
                "weekly_actual": [45000.0, 52000.0, 48000.0, 61000.0],
                "weekly_predicted_mean": [43200.0, 50100.0, 49800.0, 59500.0],
                "weekly_predicted_low": [38000.0, 44000.0, 43000.0, 53000.0],
                "weekly_predicted_high": [49000.0, 57000.0, 57000.0, 67000.0],
                "coverage_80": 0.75,
                "r_squared": 0.91,
            },
            {
                "fold": 2,
                "test_start": "2023-10-30",
                "test_end": "2023-11-20",
                "mape": 11.2,
                "weekly_actual": [55000.0, 63000.0, 71000.0, 80000.0],
                "weekly_predicted_mean": [52000.0, 60000.0, 68000.0, 76000.0],
                "weekly_predicted_low": [46000.0, 54000.0, 61000.0, 69000.0],
                "weekly_predicted_high": [58000.0, 66000.0, 75000.0, 83000.0],
                "coverage_80": 0.82,
                "r_squared": 0.88,
            },
            {
                "fold": 3,
                "test_start": "2023-11-27",
                "test_end": "2023-12-18",
                "mape": 9.7,
                "weekly_actual": [72000.0, 85000.0, 91000.0, 78000.0],
                "weekly_predicted_mean": [70000.0, 82000.0, 88000.0, 80000.0],
                "weekly_predicted_low": [63000.0, 74000.0, 79000.0, 72000.0],
                "weekly_predicted_high": [77000.0, 90000.0, 97000.0, 88000.0],
                "coverage_80": 0.80,
                "r_squared": 0.93,
            },
        ],
        "aggregate": {
            "mape_mean": 9.8,
            "coverage_80_mean": 0.79,
            "r_squared_mean": 0.91,
            "interpretation": (
                "Great fit: model would have predicted held-out weeks within 9.8% on average."
            ),
            "interpretation_label": "great",
        },
        "note": (
            "Walk-forward 3-fold CV. Each fold trains on all prior data,"
            " predicts 4 held-out weeks."
        ),
        "compute_secs": 47.3,
    }


class TestBacktestDollarLeak:
    """N7: free-tier backtest must not leak per-fold weekly revenue arrays."""

    def _make_free_result_with_backtest(self) -> dict:
        from mixlift_mcp.server import _gate_backtest_for_tier

        result = _make_tiered_free_result()
        result["backtest"] = _gate_backtest_for_tier(
            _make_backtest_with_weekly_dollars(), is_paid=False
        )
        return result

    def _make_paid_result_with_backtest(self) -> dict:
        from mixlift_mcp.server import _gate_backtest_for_tier

        result = _make_tiered_paid_result()
        result["backtest"] = _gate_backtest_for_tier(
            _make_backtest_with_weekly_dollars(), is_paid=True
        )
        return result

    def test_free_tier_backtest_no_dollar_leak(self):
        """Build a free-tier result with a populated backtest containing weekly
        revenue arrays. Serialize to JSON. Assert no $XXXX dollar strings leak.
        """
        result = self._make_free_result_with_backtest()
        data = _build_tiered_response(result)
        full_json = json.dumps(data)

        dollar_matches = re.findall(r"\$[\d,]+(?:\.\d+)?", full_json)
        leaks = [m for m in dollar_matches if m not in ("$299", "$XXX")]
        assert leaks == [], (
            f"Dollar amounts leaked into free-tier backtest output: {leaks}"
        )

    def test_free_tier_backtest_folds_stripped(self):
        """Free-tier fold dicts must not contain weekly_actual or coverage_80."""
        result = self._make_free_result_with_backtest()
        backtest = result["backtest"]
        for fold in backtest.get("folds", []):
            assert "weekly_actual" not in fold, "weekly_actual must be stripped on free tier"
            assert "weekly_predicted_mean" not in fold, "weekly_predicted_mean must be stripped"
            assert "weekly_predicted_low" not in fold, "weekly_predicted_low must be stripped"
            assert "weekly_predicted_high" not in fold, "weekly_predicted_high must be stripped"
            assert "coverage_80" not in fold, "coverage_80 must be stripped on free tier"
            assert "r_squared" not in fold, "r_squared must be stripped on free tier"
            # These should remain
            assert "fold" in fold
            assert "mape" in fold

    def test_free_tier_backtest_aggregate_stripped(self):
        """Free-tier aggregate must not contain coverage_80_mean or r_squared_mean."""
        result = self._make_free_result_with_backtest()
        agg = result["backtest"].get("aggregate", {})
        assert "coverage_80_mean" not in agg, "coverage_80_mean must be stripped on free tier"
        assert "r_squared_mean" not in agg, "r_squared_mean must be stripped on free tier"
        # mape_mean and interpretation must remain
        assert "mape_mean" in agg
        assert "interpretation" in agg

    def test_paid_tier_backtest_has_weekly_arrays(self):
        """Sanity: paid tier still has the full per-fold weekly data."""
        result = self._make_paid_result_with_backtest()
        folds = result["backtest"].get("folds", [])
        assert len(folds) > 0, "paid tier should have folds"
        first_fold = folds[0]
        assert isinstance(first_fold.get("weekly_actual"), list), (
            "paid tier fold must contain weekly_actual list"
        )
        assert all(isinstance(v, float) for v in first_fold["weekly_actual"]), (
            "weekly_actual must be floats"
        )
        agg = result["backtest"].get("aggregate", {})
        assert "coverage_80_mean" in agg, "paid tier aggregate must have coverage_80_mean"
        assert "r_squared_mean" in agg, "paid tier aggregate must have r_squared_mean"
