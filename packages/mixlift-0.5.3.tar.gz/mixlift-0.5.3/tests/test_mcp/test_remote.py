"""Tests for the remote MCP server (Cloud MCP PoC).

Verifies:
1. csv_content parameter works for inline CSV data
2. Remote server entry point imports and configures correctly
3. Tool list includes csv_content parameter
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.license import PRO_MAX_CHANNELS, PRO_MAX_ROWS, LicenseStatus
from mixlift_mcp.server import mcp, mixlift_analyze

PRO = LicenseStatus(True, PRO_MAX_CHANNELS, PRO_MAX_ROWS, "Growth tier")
FREE = LicenseStatus(False, 2, 2000, "Free tier")


def _make_model_results():
    results = MagicMock()
    results.roas_estimates = {"Meta": 2.5, "Google": 3.2}
    results.roas_ci = {"Meta": (1.8, 3.2), "Google": (2.5, 3.9)}
    results.channel_contributions = {"Meta": 45000.0, "Google": 30000.0}
    results.channel_contributions_ci = {
        "Meta": (36000.0, 54000.0),
        "Google": (24000.0, 36000.0),
    }
    results.marginal_roas_estimates = {"Meta": 2.0, "Google": 2.8}
    results.marginal_roas_ci = {"Meta": (1.5, 2.5), "Google": (2.2, 3.4)}
    results.total_spend = {"Meta": 18000.0, "Google": 12000.0}
    results.convergence_warnings = []
    results.duration_secs = 8.0
    results.mmm = MagicMock()
    results.loo_cv = None
    results.intercept_decomposition = None
    results.raw_contributions = MagicMock()
    return results


def _make_optimization():
    return {
        "current_allocation": {"Meta": 8000, "Google": 5000},
        "optimal_allocation": {"Meta": 6000, "Google": 7000},
        "total_budget": 13000,
        "expected_lift_pct": 12.5,
    }


def _make_saturation_curves():
    return {
        "Meta": {"spend": [0, 5000], "response": [0, 3000]},
        "Google": {"spend": [0, 5000], "response": [0, 4000]},
    }


def _make_csv_text() -> str:
    rng = np.random.default_rng(42)
    n = 52
    df = pd.DataFrame(
        {
            "date": pd.date_range("2023-01-01", periods=n, freq="W-MON"),
            "meta_spend": rng.uniform(1000, 5000, n),
            "google_spend": rng.uniform(2000, 8000, n),
            "revenue": rng.uniform(30000, 80000, n),
        }
    )
    return df.to_csv(index=False)


# ---------------------------------------------------------------------------
# csv_content parameter tests
# ---------------------------------------------------------------------------


class TestCsvContent:
    """Test inline CSV content parameter for remote/cloud usage."""

    @pytest.mark.asyncio
    async def test_csv_content_runs_analysis(self, tmp_path):
        """csv_content should work as an alternative to csv_path."""
        csv_text = _make_csv_text()

        with (
            patch("mixlift_mcp.server.validate_license", new_callable=AsyncMock, return_value=PRO),
            patch("mixlift_mcp.server._run_pipeline", return_value=_make_model_results()),
            patch("mixlift_mcp.server._run_optimizer", return_value=_make_optimization()),
            patch("mixlift_mcp.server._run_saturation", return_value=_make_saturation_curves()),
            patch("mixlift_mcp.memory.MEMORY_DIR", tmp_path / "memory"),
        ):
            result_json = await mixlift_analyze(csv_content=csv_text, license_key="pro-key")

        data = json.loads(result_json)
        assert data["status"] == "success"
        assert "structured_data" in data

    @pytest.mark.asyncio
    async def test_csv_content_takes_priority_over_demo(self, tmp_path):
        """When csv_content is provided, it should be used instead of demo data."""
        csv_text = _make_csv_text()

        with (
            patch("mixlift_mcp.server.validate_license", new_callable=AsyncMock, return_value=PRO),
            patch(
                "mixlift_mcp.server._run_pipeline", return_value=_make_model_results()
            ) as mock_pipeline,
            patch("mixlift_mcp.server._run_optimizer", return_value=_make_optimization()),
            patch("mixlift_mcp.server._run_saturation", return_value=_make_saturation_curves()),
            patch("mixlift_mcp.memory.MEMORY_DIR", tmp_path / "memory"),
        ):
            result_json = await mixlift_analyze(csv_content=csv_text, license_key="pro-key")

        # Pipeline should have been called (not short-circuited)
        assert mock_pipeline.called
        data = json.loads(result_json)
        assert data["status"] == "success"

    @pytest.mark.asyncio
    async def test_csv_content_bad_data_returns_error(self):
        """Invalid CSV content should return a parse error."""
        result_json = await mixlift_analyze(csv_content="not,valid\ncsv,data,extra")
        data = json.loads(result_json)
        # Either parse error or downstream validation error — not a crash
        assert data["status"] in ("success", "error")

    @pytest.mark.asyncio
    async def test_csv_content_empty_string_uses_demo(self, tmp_path):
        """Empty csv_content string should fall through to demo data."""
        with (
            patch("mixlift_mcp.server.validate_license", new_callable=AsyncMock, return_value=PRO),
            patch("mixlift_mcp.server._run_pipeline", return_value=_make_model_results()),
            patch("mixlift_mcp.server._run_optimizer", return_value=_make_optimization()),
            patch("mixlift_mcp.server._run_saturation", return_value=_make_saturation_curves()),
            patch("mixlift_mcp.memory.MEMORY_DIR", tmp_path / "memory"),
        ):
            result_json = await mixlift_analyze(csv_content="", csv_path="", license_key="pro-key")

        data = json.loads(result_json)
        assert data["status"] == "success"


# ---------------------------------------------------------------------------
# Remote entry point tests
# ---------------------------------------------------------------------------


class TestRemoteEntryPoint:
    """Test that the remote entry point configures correctly."""

    def test_import_remote_module(self):
        """remote.py should be importable without side effects."""
        import mixlift_mcp.remote  # noqa: F401

    def test_mcp_server_has_all_tools(self):
        """The shared mcp object should have all tools registered."""
        # Get the list of tools by inspecting the server
        tool_names = [t.name for t in mcp._tool_manager.list_tools()]
        expected = {
            "mixlift_analyze",
            "mixlift_readout",
            "mixlift_scenario",
            "mixlift_forecast",
            "mixlift_connect",
            "mixlift_connect_multi",
            "mixlift_prepare",
        }
        assert expected.issubset(set(tool_names)), f"Missing tools: {expected - set(tool_names)}"

    def test_analyze_tool_has_csv_content_param(self):
        """mixlift_analyze should expose csv_content in its schema."""
        tools = mcp._tool_manager.list_tools()
        analyze = next(t for t in tools if t.name == "mixlift_analyze")
        schema = analyze.parameters
        assert "csv_content" in schema.get("properties", {}), (
            "csv_content parameter not in mixlift_analyze schema"
        )
