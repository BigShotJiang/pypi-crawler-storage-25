"""Tests for MixLiftTokenVerifier (OAuth 2.1 bearer-token validation).

Uses a locally-generated RSA keypair to sign test tokens.  PyJWKClient is
mocked so no network calls are made.

Test matrix:
1.  Valid token  — tier=pro, license_key claim present
2.  Valid token  — tier=free, no license_key claim
3.  Expired token                              → None
4.  Wrong issuer                               → None
5.  Wrong audience                             → None
6.  Malformed / bad-signature token            → None
7.  Missing scope claim — scopes=[]            (enforcement is FastMCP's job)
8.  JWKS fetch failure (network error)         → None, logged
9.  (Step 5) _resolve_license — legacy license_key path
10. (Step 5) _resolve_license — no key → free tier
"""

from __future__ import annotations

import time
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import jwt
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from mixlift_mcp.oauth_verifier import MixLiftTokenVerifier

# ---------------------------------------------------------------------------
# Shared RSA keypair fixture — generated once per test session
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def rsa_keypair():
    """Generate a fresh RSA keypair for test token signing."""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    public_key = private_key.public_key()
    return private_key, public_key


@pytest.fixture(scope="module")
def private_key_pem(rsa_keypair):
    private_key, _ = rsa_keypair
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    )


@pytest.fixture(scope="module")
def public_key_obj(rsa_keypair):
    _, public_key = rsa_keypair
    return public_key


ISSUER = "https://api.mixlift.io"
AUDIENCE = "https://mixlift-cloud.fly.dev"


def _make_token(
    private_key_pem: bytes,
    *,
    sub: str = "user-123",
    iss: str = ISSUER,
    aud: str = AUDIENCE,
    exp_offset: int = 3600,
    scope: str = "mcp:tools",
    tier: str = "pro",
    license_key: str | None = "MIXLIFT-test-key-abc",
    kid: str = "test-key-1",
    extra_claims: dict[str, Any] | None = None,
) -> str:
    """Sign a JWT with the given RSA private key and claims."""
    now = int(time.time())
    payload: dict[str, Any] = {
        "iss": iss,
        "sub": sub,
        "aud": aud,
        "exp": now + exp_offset,
        "iat": now,
        "scope": scope,
        "tier": tier,
    }
    if license_key is not None:
        payload["license_key"] = license_key
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, private_key_pem, algorithm="RS256", headers={"kid": kid})


def _make_verifier_with_mock_jwks(public_key_obj) -> tuple[MixLiftTokenVerifier, MagicMock]:
    """Return a verifier whose PyJWKClient is patched to return *public_key_obj*."""
    verifier = MixLiftTokenVerifier(
        jwks_url="https://api.mixlift.io/.well-known/jwks.json",
        issuer=ISSUER,
        audience=AUDIENCE,
    )
    mock_signing_key = MagicMock()
    mock_signing_key.key = public_key_obj
    verifier._jwks_client = MagicMock()
    verifier._jwks_client.get_signing_key_from_jwt.return_value = mock_signing_key
    return verifier, verifier._jwks_client


# ---------------------------------------------------------------------------
# Test 1: Valid token — pro tier with license_key
# ---------------------------------------------------------------------------


class TestValidTokenPro:
    @pytest.mark.asyncio
    async def test_returns_access_token(self, private_key_pem, public_key_obj):
        token = _make_token(private_key_pem, tier="pro", license_key="MIXLIFT-abc")
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(token)

        assert result is not None
        assert result.client_id == "user-123"
        assert "mcp:tools" in result.scopes
        assert result.extra.get("tier") == "pro"
        assert result.extra.get("license_key") == "MIXLIFT-abc"

    @pytest.mark.asyncio
    async def test_expires_at_set(self, private_key_pem, public_key_obj):
        token = _make_token(private_key_pem, tier="pro")
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(token)

        assert result is not None
        assert result.expires_at is not None
        assert result.expires_at > int(time.time())


# ---------------------------------------------------------------------------
# Test 2: Valid token — free tier, no license_key
# ---------------------------------------------------------------------------


class TestValidTokenFree:
    @pytest.mark.asyncio
    async def test_free_tier_no_license_key(self, private_key_pem, public_key_obj):
        token = _make_token(private_key_pem, tier="free", license_key=None)
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(token)

        assert result is not None
        assert result.extra.get("tier") == "free"
        assert "license_key" not in result.extra

    @pytest.mark.asyncio
    async def test_missing_tier_defaults_to_free(self, private_key_pem, public_key_obj):
        """Tokens without a tier claim should default to free."""
        now = int(time.time())
        payload = {
            "iss": ISSUER,
            "sub": "user-notier",
            "aud": AUDIENCE,
            "exp": now + 3600,
            "iat": now,
            "scope": "mcp:tools",
            # no "tier" claim
        }
        notier_token = jwt.encode(
            payload, private_key_pem, algorithm="RS256", headers={"kid": "k1"}
        )
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(notier_token)

        assert result is not None
        assert result.extra.get("tier") == "free"


# ---------------------------------------------------------------------------
# Test 3: Expired token → None
# ---------------------------------------------------------------------------


class TestExpiredToken:
    @pytest.mark.asyncio
    async def test_expired_token_returns_none(self, private_key_pem, public_key_obj):
        token = _make_token(private_key_pem, exp_offset=-1)  # already expired
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(token)

        assert result is None


# ---------------------------------------------------------------------------
# Test 4: Wrong issuer → None
# ---------------------------------------------------------------------------


class TestWrongIssuer:
    @pytest.mark.asyncio
    async def test_wrong_issuer_returns_none(self, private_key_pem, public_key_obj):
        token = _make_token(private_key_pem, iss="https://evil.example.com")
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(token)

        assert result is None


# ---------------------------------------------------------------------------
# Test 5: Wrong audience → None
# ---------------------------------------------------------------------------


class TestWrongAudience:
    @pytest.mark.asyncio
    async def test_wrong_audience_returns_none(self, private_key_pem, public_key_obj):
        token = _make_token(private_key_pem, aud="https://other-service.fly.dev")
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(token)

        assert result is None


# ---------------------------------------------------------------------------
# Test 6: Malformed / bad-signature token → None
# ---------------------------------------------------------------------------


class TestMalformedToken:
    @pytest.mark.asyncio
    async def test_malformed_token_returns_none(self, public_key_obj):
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token("not.a.jwt")

        assert result is None

    @pytest.mark.asyncio
    async def test_tampered_signature_returns_none(self, private_key_pem, public_key_obj):
        """Flip the last character to produce a bad signature."""
        token = _make_token(private_key_pem, tier="pro")
        # Corrupt the signature segment
        parts = token.split(".")
        parts[-1] = parts[-1][:-4] + ("XXXX" if not parts[-1].endswith("XXXX") else "YYYY")
        bad_token = ".".join(parts)
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(bad_token)

        assert result is None


# ---------------------------------------------------------------------------
# Test 7: Missing scope claim → scopes=[]
# ---------------------------------------------------------------------------


class TestMissingScope:
    @pytest.mark.asyncio
    async def test_missing_scope_returns_empty_scopes(self, private_key_pem, public_key_obj):
        """No scope claim → AccessToken.scopes == []; enforcement is FastMCP's job."""
        now = int(time.time())
        payload = {
            "iss": ISSUER,
            "sub": "user-noscope",
            "aud": AUDIENCE,
            "exp": now + 3600,
            "iat": now,
            "tier": "pro",
            # no "scope" claim
        }
        noscope_token = jwt.encode(
            payload, private_key_pem, algorithm="RS256", headers={"kid": "k1"}
        )
        verifier, _ = _make_verifier_with_mock_jwks(public_key_obj)

        result = await verifier.verify_token(noscope_token)

        assert result is not None
        assert result.scopes == []


# ---------------------------------------------------------------------------
# Test 8: JWKS fetch failure → None, logged
# ---------------------------------------------------------------------------


class TestJwksFetchFailure:
    @pytest.mark.asyncio
    async def test_network_error_returns_none(self, private_key_pem):
        verifier = MixLiftTokenVerifier(
            jwks_url="https://api.mixlift.io/.well-known/jwks.json",
            issuer=ISSUER,
            audience=AUDIENCE,
        )
        # Simulate network error from PyJWKClient
        verifier._jwks_client = MagicMock()
        verifier._jwks_client.get_signing_key_from_jwt.side_effect = Exception(
            "Connection refused"
        )

        token = _make_token(private_key_pem, tier="pro")
        result = await verifier.verify_token(token)

        assert result is None

    @pytest.mark.asyncio
    async def test_network_error_is_logged(self, private_key_pem, caplog):
        import logging

        verifier = MixLiftTokenVerifier(
            jwks_url="https://api.mixlift.io/.well-known/jwks.json",
            issuer=ISSUER,
            audience=AUDIENCE,
        )
        verifier._jwks_client = MagicMock()
        verifier._jwks_client.get_signing_key_from_jwt.side_effect = Exception("Timeout")

        token = _make_token(private_key_pem, tier="pro")
        with caplog.at_level(logging.INFO, logger="mixlift_mcp.oauth_verifier"):
            await verifier.verify_token(token)

        assert any("JWKS key fetch failed" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Tests 9 + 10: _resolve_license backward compat (Step 5)
# ---------------------------------------------------------------------------


class TestResolveLicense:
    """Verify _resolve_license honors legacy license_key param when OAuth is off."""

    @pytest.mark.asyncio
    async def test_license_key_path_no_ctx(self):
        """No bearer token, valid license_key → calls validate_license(), returns pro."""
        from mixlift_mcp.license import PRO_MAX_CHANNELS, PRO_MAX_ROWS, LicenseStatus
        from mixlift_mcp.server import _resolve_license

        pro_status = LicenseStatus(True, PRO_MAX_CHANNELS, PRO_MAX_ROWS, "Pro license validated")

        with patch(
            "mixlift_mcp.server.validate_license",
            new_callable=AsyncMock,
            return_value=pro_status,
        ):
            # No contextvar set → _extract_access_token() returns None
            result = await _resolve_license("MIXLIFT-valid-key", ctx=None)

        assert result.is_pro is True
        assert result.max_channels == PRO_MAX_CHANNELS

    @pytest.mark.asyncio
    async def test_no_key_no_ctx_returns_free(self):
        """No bearer token, no license_key → free tier."""
        from mixlift_mcp.server import _resolve_license

        with patch("mixlift_mcp.server.validate_license", new_callable=AsyncMock) as mock_vl:
            from mixlift_mcp.license import free_tier
            mock_vl.return_value = free_tier("No license key provided")
            result = await _resolve_license("", ctx=None)

        assert result.is_pro is False
        assert result.max_channels == 2
