"""Tests for shared-store metering: check_and_increment_remote + build_identity_hash."""

from __future__ import annotations

import hashlib
import json
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


_METERING_URL = "https://api.mixlift.io/v1/metering/check_and_increment"


def _mock_http_client(status: int, json_body: dict | None = None, exc: Exception | None = None):
    """Return a context-manager mock that mimics httpx.AsyncClient."""
    mock_response = MagicMock(spec=httpx.Response)
    mock_response.status_code = status
    if json_body is not None:
        mock_response.json = MagicMock(return_value=json_body)

    mock_client = AsyncMock()
    if exc is not None:
        mock_client.post = AsyncMock(side_effect=exc)
    else:
        mock_client.post = AsyncMock(return_value=mock_response)

    # Support `async with httpx.AsyncClient(...) as client:`
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=mock_client)
    cm.__aexit__ = AsyncMock(return_value=False)
    return cm, mock_client


# --------------------------------------------------------------------------- #
# check_and_increment_remote
# --------------------------------------------------------------------------- #


@pytest.mark.real_metering
class TestCheckAndIncrementRemote:
    """Tests for the async shared-store metering function."""

    @pytest.mark.asyncio
    async def test_happy_path_api_success(self):
        """When API returns 200, parse and return (allowed, count)."""
        from mixlift_mcp.metering import check_and_increment_remote

        identity = _sha256("user:alice")
        api_response = {"allowed": True, "count": 1, "limit": 2, "period": "2026-04"}
        cm, _ = _mock_http_client(200, json_body=api_response)

        with patch("mixlift_mcp.metering.httpx.AsyncClient", return_value=cm):
            allowed, count = await check_and_increment_remote(
                identity_hash=identity,
                limit=2,
                period="2026-04",
            )

        assert allowed is True
        assert count == 1

    @pytest.mark.asyncio
    async def test_timeout_falls_back_to_local_file(self, tmp_path, monkeypatch):
        """On timeout, fall back to local file and return a valid result."""
        import mixlift_mcp.metering as metering_mod
        from mixlift_mcp.metering import check_and_increment_remote

        monkeypatch.setattr(metering_mod, "USAGE_FILE", tmp_path / "usage.json")
        cm, _ = _mock_http_client(0, exc=httpx.TimeoutException("timeout"))

        with patch("mixlift_mcp.metering.httpx.AsyncClient", return_value=cm):
            allowed, count = await check_and_increment_remote(
                identity_hash=_sha256("ip:1.2.3.4"),
                limit=2,
            )

        assert allowed is True  # local file starts at 0 — first call succeeds
        assert isinstance(count, int)

    @pytest.mark.asyncio
    async def test_network_error_falls_back_to_local_file(self, tmp_path, monkeypatch):
        """On network error, fall back to local file."""
        import mixlift_mcp.metering as metering_mod
        from mixlift_mcp.metering import check_and_increment_remote

        monkeypatch.setattr(metering_mod, "USAGE_FILE", tmp_path / "usage.json")
        cm, _ = _mock_http_client(0, exc=httpx.NetworkError("network down"))

        with patch("mixlift_mcp.metering.httpx.AsyncClient", return_value=cm):
            allowed, count = await check_and_increment_remote(
                identity_hash=_sha256("ip:1.2.3.4"),
                limit=2,
            )

        assert allowed is True

    @pytest.mark.asyncio
    async def test_5xx_falls_back_to_local_file(self, tmp_path, monkeypatch):
        """Non-2xx from API falls back to local file."""
        import mixlift_mcp.metering as metering_mod
        from mixlift_mcp.metering import check_and_increment_remote

        monkeypatch.setattr(metering_mod, "USAGE_FILE", tmp_path / "usage.json")
        cm, _ = _mock_http_client(503)

        with patch("mixlift_mcp.metering.httpx.AsyncClient", return_value=cm):
            allowed, count = await check_and_increment_remote(
                identity_hash=_sha256("ip:1.2.3.4"),
                limit=2,
            )

        assert allowed is True

    @pytest.mark.asyncio
    async def test_payload_shape_sent_to_api(self):
        """Verify the JSON body sent to the API has the expected shape."""
        from mixlift_mcp.metering import check_and_increment_remote

        identity = _sha256("license:MIXLIFT-abc123")
        api_response = {"allowed": True, "count": 1, "limit": 500, "period": "2026-04-13"}

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json = MagicMock(return_value=api_response)

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)

        # httpx.AsyncClient(timeout=...) is called as a constructor, so we
        # patch the class itself to return a CM that yields mock_client.
        cm = MagicMock()
        cm.__aenter__ = AsyncMock(return_value=mock_client)
        cm.__aexit__ = AsyncMock(return_value=False)

        with patch("mixlift_mcp.metering.httpx.AsyncClient", return_value=cm):
            await check_and_increment_remote(
                identity_hash=identity,
                limit=500,
                period="2026-04-13",
                daily=True,
            )

        mock_client.post.assert_called_once()
        call_kwargs = mock_client.post.call_args[1]
        body = call_kwargs.get("json", {})
        assert body["identity_hash"] == identity
        assert body["period"] == "2026-04-13"
        assert body["limit"] == 500


# --------------------------------------------------------------------------- #
# build_identity_hash — identity priority logic
# --------------------------------------------------------------------------- #


class TestBuildIdentityHash:
    """Tests for identity hash construction priority order."""

    def test_license_key_path(self):
        """Non-empty license_key produces sha256('license:<key>') hash."""
        from mixlift_mcp._metering_identity import build_identity_hash

        key = "MIXLIFT-test-key"
        identity, is_paid = build_identity_hash(license_key=key, is_pro=True, ctx=None)

        expected = _sha256(f"license:{key}")
        assert identity == expected
        assert is_paid is True

    def test_license_key_free_tier(self):
        """license_key with is_pro=False returns is_paid=False."""
        from mixlift_mcp._metering_identity import build_identity_hash

        identity, is_paid = build_identity_hash(
            license_key="MIXLIFT-free-key", is_pro=False, ctx=None
        )
        assert is_paid is False
        assert len(identity) == 64

    def test_ip_fallback_no_key_no_ctx(self):
        """No license_key and no ctx → sha256('ip:127.0.0.1') fallback."""
        from mixlift_mcp._metering_identity import build_identity_hash

        identity, is_paid = build_identity_hash(license_key="", is_pro=False, ctx=None)

        expected = _sha256("ip:127.0.0.1")
        assert identity == expected
        assert is_paid is False

    def test_ip_extracted_from_ctx_forwarded_for(self):
        """Source IP is taken from X-Forwarded-For header when ctx has a request."""
        from mixlift_mcp._metering_identity import build_identity_hash

        mock_request = MagicMock()
        mock_request.headers = {"x-forwarded-for": "203.0.113.5, 10.0.0.1"}
        mock_request.client = MagicMock()
        mock_request.client.host = "10.0.0.1"

        mock_rc = MagicMock()
        mock_rc.request = mock_request

        mock_ctx = MagicMock()
        mock_ctx._request_context = mock_rc

        identity, is_paid = build_identity_hash(
            license_key="", is_pro=False, ctx=mock_ctx
        )
        expected = _sha256("ip:203.0.113.5")
        assert identity == expected
        assert is_paid is False

    def test_oauth_token_path(self):
        """OAuth bearer token present → sha256('user:<sub>') and is_paid=True."""
        from mixlift_mcp._metering_identity import build_identity_hash

        mock_token = MagicMock()
        mock_token.client_id = "user-sub-42"

        with patch(
            "mcp.server.auth.middleware.auth_context.get_access_token",
            return_value=mock_token,
        ):
            identity, is_paid = build_identity_hash(
                license_key="", is_pro=False, ctx=None
            )

        expected = _sha256("user:user-sub-42")
        assert identity == expected
        assert is_paid is True
