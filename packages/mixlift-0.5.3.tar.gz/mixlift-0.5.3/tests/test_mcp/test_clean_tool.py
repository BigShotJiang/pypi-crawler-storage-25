"""Tool-level integration tests for mixlift_clean MCP tool.

Tests cover: dry-run, apply-fixes, edge cases, and all 10 spec edge cases.
No PyMC-Marketing involvement.
"""

from __future__ import annotations

import json
import pathlib

import numpy as np
import pandas as pd
import pytest

from mixlift_mcp.server import mixlift_clean

# Fixture directory
_FIXTURES = pathlib.Path(__file__).parent.parent / "fixtures"
_MESSY_CSV = _FIXTURES / "messy_input.csv"


# ---------------------------------------------------------------------------
# Helper: build a clean weekly CSV in tmp_path
# ---------------------------------------------------------------------------


def _write_weekly_csv(
    tmp_path: pathlib.Path,
    channels: list[str] | None = None,
    n_weeks: int = 26,
    fname: str = "test.csv",
) -> pathlib.Path:
    if channels is None:
        channels = ["Meta", "Google"]
    dates = pd.date_range("2025-01-06", periods=n_weeks, freq="W-MON")
    rng = np.random.default_rng(42)
    rows = []
    for d in dates:
        for ch in channels:
            rows.append(
                {
                    "date": d.strftime("%Y-%m-%d"),
                    "channel": ch,
                    "spend": round(5000 + rng.uniform(-500, 500), 2),
                    "revenue": round(30000 + rng.uniform(-2000, 2000), 2),
                }
            )
    path = tmp_path / fname
    pd.DataFrame(rows).to_csv(path, index=False)
    return path


# ---------------------------------------------------------------------------
# Basic dry-run
# ---------------------------------------------------------------------------


class TestDryRun:
    @pytest.mark.asyncio
    async def test_returns_json_string(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result_str = await mixlift_clean(str(path))
        result = json.loads(result_str)
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_tool_field_is_mixlift_clean(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert result["tool"] == "mixlift_clean"

    @pytest.mark.asyncio
    async def test_version_field(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert result["version"] == "0.5.3"

    @pytest.mark.asyncio
    async def test_applied_false_by_default(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert result["applied"] is False

    @pytest.mark.asyncio
    async def test_output_path_null_on_dry_run(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert result["output_path"] is None

    @pytest.mark.asyncio
    async def test_no_file_written_on_dry_run(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        await mixlift_clean(str(path))
        cleaned_path = path.with_suffix("").with_suffix(".cleaned.csv")
        assert not cleaned_path.exists()

    @pytest.mark.asyncio
    async def test_issues_is_list(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert isinstance(result["issues"], list)

    @pytest.mark.asyncio
    async def test_each_issue_has_required_keys(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        required_keys = {
            "kind",
            "severity",
            "description",
            "affected_rows",
            "affected_values",
            "proposed_fix",
            "auto_applies",
        }
        for issue in result["issues"]:
            assert required_keys <= set(issue.keys()), f"Issue missing keys: {issue}"

    @pytest.mark.asyncio
    async def test_input_summary_present(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        summary = result["input_summary"]
        assert "rows" in summary
        assert "channels" in summary
        assert "date_range" in summary
        assert "week_count" in summary

    @pytest.mark.asyncio
    async def test_memo_markdown_present(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert "memo_markdown" in result
        assert isinstance(result["memo_markdown"], str)
        assert len(result["memo_markdown"]) > 0

    @pytest.mark.asyncio
    async def test_messy_fixture_detects_issues(self):
        result = json.loads(await mixlift_clean(str(_MESSY_CSV)))
        assert len(result["issues"]) > 0


# ---------------------------------------------------------------------------
# Apply-fixes mode
# ---------------------------------------------------------------------------


class TestApplyFixes:
    @pytest.mark.asyncio
    async def test_creates_output_file(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        assert result["applied"] is True
        out = pathlib.Path(result["output_path"])
        assert out.exists()

    @pytest.mark.asyncio
    async def test_default_output_path_suffix(self, tmp_path):
        path = tmp_path / "mydata.csv"
        _write_weekly_csv(tmp_path, fname="mydata.csv")
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        assert result["output_path"].endswith(".cleaned.csv")

    @pytest.mark.asyncio
    async def test_custom_output_path_used(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        out_path = tmp_path / "custom_output.csv"
        result = json.loads(
            await mixlift_clean(str(path), apply_fixes=True, output_path=str(out_path))
        )
        assert pathlib.Path(result["output_path"]) == out_path
        assert out_path.exists()

    @pytest.mark.asyncio
    async def test_fixes_applied_is_list(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        assert isinstance(result["fixes_applied"], list)

    @pytest.mark.asyncio
    async def test_output_summary_present_when_applied(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        assert result["output_summary"] is not None
        assert "rows" in result["output_summary"]

    @pytest.mark.asyncio
    async def test_fixes_applied_empty_for_clean_data(self, tmp_path):
        """Edge case 4: clean data — write copy anyway, report no changes."""
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        # May have no fixes but should still write the file
        out = pathlib.Path(result["output_path"])
        assert out.exists()

    @pytest.mark.asyncio
    async def test_channel_aliases_fixed_in_output(self, tmp_path):
        """Channel aliases should be renamed in the written file."""
        df = pd.DataFrame(
            {
                "date": pd.date_range("2025-01-06", periods=10, freq="W-MON").strftime("%Y-%m-%d"),
                "channel": ["FB"] * 5 + ["Google"] * 5,
                "spend": [5000.0] * 10,
                "revenue": [30000.0] * 10,
            }
        )
        path = tmp_path / "alias_test.csv"
        df.to_csv(path, index=False)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        out_df = pd.read_csv(result["output_path"])
        assert "FB" not in out_df["channel"].values


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    @pytest.mark.asyncio
    async def test_edge1_empty_csv(self, tmp_path):
        """Edge case 1: empty CSV returns error."""
        path = tmp_path / "empty.csv"
        path.write_text("")
        result = json.loads(await mixlift_clean(str(path)))
        assert result.get("status") == "error"
        assert "empty" in result["message"].lower() or "unreadable" in result["message"].lower()

    @pytest.mark.asyncio
    async def test_edge2_missing_required_columns(self, tmp_path):
        """Edge case 2: missing required columns returns error listing them."""
        df = pd.DataFrame({"channel": ["Meta", "Google"], "clicks": [100, 200]})
        path = tmp_path / "no_date_no_spend.csv"
        df.to_csv(path, index=False)
        result = json.loads(await mixlift_clean(str(path)))
        assert result.get("status") == "error"
        assert "missing" in result["message"].lower() or "required" in result["message"].lower()

    @pytest.mark.asyncio
    async def test_edge3_apply_fixes_no_output_path_defaults(self, tmp_path):
        """Edge case 3: apply_fixes=True with no output_path defaults to .cleaned.csv."""
        path = tmp_path / "testdata.csv"
        _write_weekly_csv(tmp_path, fname="testdata.csv")
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        assert result["output_path"] is not None
        assert "testdata.cleaned.csv" in result["output_path"]

    @pytest.mark.asyncio
    async def test_edge4_apply_fixes_no_issues(self, tmp_path):
        """Edge case 4: apply_fixes=True but no issues — write copy anyway."""
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        out = pathlib.Path(result["output_path"])
        assert out.exists()

    @pytest.mark.asyncio
    async def test_edge5_all_zero_spend_rows_kept(self, tmp_path):
        """Edge case 5: all-zero spend rows are kept, emitted as info issue."""
        df = pd.DataFrame(
            {
                "date": ["2025-01-06", "2025-01-13", "2025-01-20"],
                "channel": ["Meta", "Meta", "Meta"],
                "spend": [0.0, 0.0, 0.0],
                "revenue": [0.0, 0.0, 0.0],
            }
        )
        path = tmp_path / "zero_spend.csv"
        df.to_csv(path, index=False)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        # Zero spend rows should be in info issues, not errors
        zero_issues = [i for i in result["issues"] if i["kind"] == "zero_spend_rows"]
        assert zero_issues
        assert zero_issues[0]["severity"] == "info"
        # File should still be written
        assert pathlib.Path(result["output_path"]).exists()

    @pytest.mark.asyncio
    async def test_edge6_channel_collision_under_canonicalization(self, tmp_path):
        """Edge case 6: 'Meta', 'meta', 'FB' all → Meta; report merged values."""
        df = pd.DataFrame(
            {
                "date": pd.date_range("2025-01-06", periods=12, freq="W-MON").strftime("%Y-%m-%d"),
                "channel": (["Meta"] * 4 + ["meta"] * 4 + ["FB"] * 4),
                "spend": [5000.0] * 12,
                "revenue": [30000.0] * 12,
            }
        )
        path = tmp_path / "collision.csv"
        df.to_csv(path, index=False)
        result = json.loads(await mixlift_clean(str(path)))
        cn_issues = [i for i in result["issues"] if i["kind"] == "channel_name_inconsistency"]
        assert cn_issues  # aliases should be flagged

    @pytest.mark.asyncio
    async def test_edge7_path_with_spaces(self, tmp_path):
        """Edge case 7: file path with spaces handled correctly."""
        spaced_dir = tmp_path / "my data files"
        spaced_dir.mkdir()
        path = spaced_dir / "test data.csv"
        df = pd.DataFrame(
            {
                "date": ["2025-01-06", "2025-01-13"],
                "channel": ["Meta", "Google"],
                "spend": [5000.0, 3000.0],
                "revenue": [30000.0, 20000.0],
            }
        )
        df.to_csv(path, index=False)
        result = json.loads(await mixlift_clean(str(path)))
        assert result.get("status") != "error" or "not found" not in result.get("message", "")
        # Should successfully load the file (not error on path)
        assert "issues" in result

    @pytest.mark.asyncio
    async def test_edge8_duplicate_with_conflicting_values(self, tmp_path):
        """Edge case 8: (date, channel) dupe with different spend — keep more non-null."""
        df = pd.DataFrame(
            {
                "date": ["2025-01-06", "2025-01-06", "2025-01-13"],
                "channel": ["Meta", "Meta", "Meta"],
                "spend": [5000.0, 4000.0, 5100.0],  # conflict on row 0,1
                "revenue": [30000.0, None, 31000.0],
            }
        )
        path = tmp_path / "conflict.csv"
        df.to_csv(path, index=False)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True))
        out_df = pd.read_csv(result["output_path"])
        # Should deduplicate — at most 2 rows (one per date)
        jan6_rows = out_df[out_df["date"] == "2025-01-06"]
        assert len(jan6_rows) == 1

    @pytest.mark.asyncio
    async def test_edge9_only_one_date_warns(self, tmp_path):
        """Edge case 9: single date → warn with 'only_one_date' issue."""
        df = pd.DataFrame(
            {
                "date": ["2025-01-06", "2025-01-06", "2025-01-06"],
                "channel": ["Meta", "Google", "TikTok"],
                "spend": [5000.0, 3000.0, 2000.0],
                "revenue": [30000.0, 20000.0, 15000.0],
            }
        )
        path = tmp_path / "one_date.csv"
        df.to_csv(path, index=False)
        result = json.loads(await mixlift_clean(str(path)))
        kinds = {i["kind"] for i in result["issues"]}
        assert "only_one_date" in kinds

    @pytest.mark.asyncio
    async def test_edge10_refuse_overwrite_input(self, tmp_path):
        """Edge case 10: output_path == input_path → refuse with error."""
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path), apply_fixes=True, output_path=str(path)))
        assert result.get("status") == "error"
        msg = result["message"].lower()
        assert "overwrite" in msg or "same file" in msg or "refusing" in msg


# ---------------------------------------------------------------------------
# Output structure compliance
# ---------------------------------------------------------------------------


class TestOutputStructure:
    @pytest.mark.asyncio
    async def test_all_required_top_level_keys(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        required = {
            "tool",
            "version",
            "input_path",
            "output_path",
            "applied",
            "input_summary",
            "issues",
            "fixes_applied",
            "output_summary",
            "memo_markdown",
        }
        assert required <= set(result.keys()), f"Missing keys: {required - set(result.keys())}"

    @pytest.mark.asyncio
    async def test_input_path_is_absolute(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert result["input_path"].startswith("/")

    @pytest.mark.asyncio
    async def test_severity_values_valid(self, tmp_path):
        path = _MESSY_CSV
        result = json.loads(await mixlift_clean(str(path)))
        valid = {"high", "medium", "low", "info"}
        for issue in result["issues"]:
            assert issue["severity"] in valid, f"Invalid severity: {issue['severity']}"

    @pytest.mark.asyncio
    async def test_fixes_applied_empty_on_dry_run(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert result["fixes_applied"] == []

    @pytest.mark.asyncio
    async def test_output_summary_null_on_dry_run(self, tmp_path):
        path = _write_weekly_csv(tmp_path)
        result = json.loads(await mixlift_clean(str(path)))
        assert result["output_summary"] is None

    @pytest.mark.asyncio
    async def test_channel_name_map_applied(self, tmp_path):
        """User-supplied channel_name_map renames are applied."""
        df = pd.DataFrame(
            {
                "date": pd.date_range("2025-01-06", periods=8, freq="W-MON").strftime("%Y-%m-%d"),
                "channel": ["FBBrand"] * 4 + ["Google"] * 4,
                "spend": [5000.0] * 8,
                "revenue": [30000.0] * 8,
            }
        )
        path = tmp_path / "custom_map.csv"
        df.to_csv(path, index=False)
        result = json.loads(
            await mixlift_clean(str(path), apply_fixes=True, channel_name_map={"FBBrand": "Meta"})
        )
        out_df = pd.read_csv(result["output_path"])
        assert "FBBrand" not in out_df["channel"].values
        assert "Meta" in out_df["channel"].values
