"""Tests for the persistent disk-backed model cache (model_cache.py).

Covers:
1. compute_model_fingerprint — stability and sensitivity
2. save_model / load_model roundtrip (mock MMM.save/load)
3. load_model on missing file → None
4. load_model on corrupt meta.json → None + eviction
5. Schema mismatch → evict and return None
6. evict_lru — trims to max_entries
7. force_refresh skips cache
8. cache_hit signal in mixlift_analyze response (integration stub)
9. Concurrent-save guard (.lock file)
10. Unwritable cache dir → graceful fallback (warning, no crash)
"""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pandas as pd
import pytest

import mixlift_mcp.model_cache as mc


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fake_df(n_rows: int = 10) -> pd.DataFrame:
    dates = pd.date_range("2024-01-01", periods=n_rows, freq="W-MON")
    return pd.DataFrame({
        "date": dates,
        "google_spend": [100.0 + i for i in range(n_rows)],
        "meta_spend": [200.0 + i for i in range(n_rows)],
        "trend": list(range(n_rows)),
    })


def _make_fake_mmm():
    """Return a MagicMock that mimics MMM.save/load interface."""
    mmm = MagicMock()
    # MMM.save(path) writes something to disk
    def fake_save(path: str) -> None:
        Path(path).write_bytes(b"FAKE_IDATA_NETCDF")

    mmm.save.side_effect = fake_save
    return mmm


def _make_fake_result() -> dict:
    return {
        "status": "success",
        "headline": "Test result",
        "model_fingerprint": "abc123",
    }


# ---------------------------------------------------------------------------
# Fingerprint tests
# ---------------------------------------------------------------------------


class TestComputeModelFingerprint:
    def test_stable_across_calls(self):
        fp1 = mc.compute_model_fingerprint(b"csv_bytes", ["google_spend", "meta_spend"])
        fp2 = mc.compute_model_fingerprint(b"csv_bytes", ["google_spend", "meta_spend"])
        assert fp1 == fp2

    def test_channel_order_independent(self):
        fp1 = mc.compute_model_fingerprint(b"csv", ["google_spend", "meta_spend"])
        fp2 = mc.compute_model_fingerprint(b"csv", ["meta_spend", "google_spend"])
        assert fp1 == fp2

    def test_different_csv_different_fp(self):
        fp1 = mc.compute_model_fingerprint(b"csv_v1", ["ch1"])
        fp2 = mc.compute_model_fingerprint(b"csv_v2", ["ch1"])
        assert fp1 != fp2

    def test_different_channels_different_fp(self):
        fp1 = mc.compute_model_fingerprint(b"csv", ["google_spend"])
        fp2 = mc.compute_model_fingerprint(b"csv", ["meta_spend"])
        assert fp1 != fp2

    def test_different_mcmc_config_different_fp(self):
        fp1 = mc.compute_model_fingerprint(b"csv", ["ch"], {"chains": 4, "draws": 250})
        fp2 = mc.compute_model_fingerprint(b"csv", ["ch"], {"chains": 4, "draws": 500})
        assert fp1 != fp2

    def test_length_is_16(self):
        fp = mc.compute_model_fingerprint(b"csv", ["ch"])
        assert len(fp) == 16

    def test_does_not_include_timestamp(self):
        """Two calls at different times with same inputs must be equal."""
        fp1 = mc.compute_model_fingerprint(b"data", ["ch"])
        time.sleep(0.01)
        fp2 = mc.compute_model_fingerprint(b"data", ["ch"])
        assert fp1 == fp2


# ---------------------------------------------------------------------------
# Save / Load roundtrip
# ---------------------------------------------------------------------------


class TestSaveAndLoad:
    @pytest.fixture(autouse=True)
    def _patch_cache_dir(self, tmp_path, monkeypatch):
        """Redirect cache_dir() to a temp directory for isolation."""
        versioned = tmp_path / f"v{mc.SCHEMA_VERSION}"
        versioned.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(mc, "cache_dir", lambda: versioned)

        index_path = tmp_path / "index.json"
        monkeypatch.setattr(mc, "_index_path", lambda: index_path)

    def test_roundtrip_saves_and_loads(self, tmp_path):
        mmm = _make_fake_mmm()
        X = _make_fake_df()
        result = _make_fake_result()
        channel_columns = ["google_spend", "meta_spend"]
        fp = "test_fp_001"

        # MMM is imported locally inside load_model; patch at the source module.
        fake_mmm_cls = MagicMock()
        fake_mmm_cls.load.return_value = mmm

        with patch("mixlift_mcp.model_cache.pd.read_parquet", return_value=X), \
             patch("mixlift_mcp.model_cache._reconstruct_model_results", return_value=MagicMock()), \
             patch("pymc_marketing.mmm.mmm.MMM", fake_mmm_cls):

            asyncio.run(mc.save_model(
                fp,
                mmm=mmm,
                X=X,
                channel_columns=channel_columns,
                result=result,
                mcmc_config={"chains": 4, "draws": 250},
            ))

            # Verify files were created
            entry = mc._entry_dir(fp)
            assert (entry / "meta.json").exists()
            assert (entry / "result.json").exists()
            assert (entry / "X.parquet").exists()
            # mmm.nc was written by fake_save
            assert (entry / "mmm.nc").exists()

            # Now load it back
            loaded = asyncio.run(mc.load_model(fp))
            assert loaded is not None
            assert loaded["channel_columns"] == channel_columns
            result_loaded = loaded["result"]
            assert result_loaded["headline"] == "Test result"

    def test_load_missing_returns_none(self):
        loaded = asyncio.run(mc.load_model("nonexistent_fp_999"))
        assert loaded is None

    def test_load_corrupt_meta_evicts_and_returns_none(self, tmp_path):
        fp = "corrupt_fp_001"
        entry = mc._entry_dir(fp)
        entry.mkdir(parents=True, exist_ok=True)
        (entry / "meta.json").write_text("NOT VALID JSON {{{{")

        loaded = asyncio.run(mc.load_model(fp))
        assert loaded is None
        # Entry should be evicted
        assert not entry.exists()

    def test_schema_mismatch_evicts(self, tmp_path):
        fp = "schema_mismatch_fp"
        entry = mc._entry_dir(fp)
        entry.mkdir(parents=True, exist_ok=True)
        meta = {
            "schema_version": 999,  # wrong version
            "created_at": "2026-01-01T00:00:00+00:00",
            "channel_columns": ["ch1"],
            "mcmc_config": {},
        }
        (entry / "meta.json").write_text(json.dumps(meta))

        loaded = asyncio.run(mc.load_model(fp))
        assert loaded is None
        # Entry should be evicted
        assert not entry.exists()

    def test_save_is_idempotent(self, tmp_path):
        """Calling save_model twice on the same fp should not crash or duplicate."""
        mmm = _make_fake_mmm()
        X = _make_fake_df()
        result = _make_fake_result()
        fp = "idempotent_fp"

        with patch("mixlift_mcp.model_cache.pd.read_parquet", return_value=X):
            asyncio.run(mc.save_model(fp, mmm=mmm, X=X, channel_columns=["ch"], result=result))
            # Second call — meta.json exists, lock gone → skip
            asyncio.run(mc.save_model(fp, mmm=mmm, X=X, channel_columns=["ch"], result=result))

        entry = mc._entry_dir(fp)
        assert (entry / "meta.json").exists()

    def test_concurrent_save_guard(self, tmp_path):
        """Lock file present means write in progress — load should return None."""
        fp = "locked_fp"
        entry = mc._entry_dir(fp)
        entry.mkdir(parents=True, exist_ok=True)

        # Touch lock file to simulate in-progress write
        lock = entry.parent / f"{fp}.lock"
        lock.touch()

        # Also write a valid meta.json so only the lock prevents the load
        meta = {
            "schema_version": mc.SCHEMA_VERSION,
            "created_at": "2026-01-01T00:00:00+00:00",
            "channel_columns": ["ch1"],
            "mcmc_config": {},
        }
        (entry / "meta.json").write_text(json.dumps(meta))

        loaded = asyncio.run(mc.load_model(fp))
        assert loaded is None


# ---------------------------------------------------------------------------
# LRU eviction
# ---------------------------------------------------------------------------


class TestEvictLru:
    @pytest.fixture(autouse=True)
    def _patch_cache_dir(self, tmp_path, monkeypatch):
        versioned = tmp_path / f"v{mc.SCHEMA_VERSION}"
        versioned.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(mc, "cache_dir", lambda: versioned)
        monkeypatch.setattr(mc, "_index_path", lambda: tmp_path / "index.json")

    def test_evicts_oldest_first(self):
        # Write index with 5 entries at different times
        index = {}
        for i in range(5):
            fp = f"fp_{i:04d}"
            index[fp] = {
                "created_at": f"2026-01-0{i+1}T00:00:00+00:00",
                "last_accessed": f"2026-01-0{i+1}T00:00:00+00:00",
                "size_bytes": 1000,
            }
            # Create entry dir so _evict_entry doesn't error
            entry = mc._entry_dir(fp)
            entry.mkdir(parents=True, exist_ok=True)
        mc._write_index(index)

        evicted = mc.evict_lru(max_entries=3)

        assert evicted == 2
        remaining = mc._read_index()
        assert len(remaining) == 3
        # fp_0000 and fp_0001 (oldest) should be gone
        assert "fp_0000" not in remaining
        assert "fp_0001" not in remaining

    def test_no_eviction_when_under_limit(self):
        index = {
            "fp_a": {"last_accessed": "2026-01-01", "created_at": "2026-01-01", "size_bytes": 100},
        }
        mc._write_index(index)
        evicted = mc.evict_lru(max_entries=5)
        assert evicted == 0


# ---------------------------------------------------------------------------
# Unwritable dir — graceful fallback
# ---------------------------------------------------------------------------


class TestGracefulFallback:
    def test_save_to_unwritable_dir_logs_warning(self, tmp_path, caplog):
        """save_model on unwritable path should warn, not raise."""
        import logging

        mmm = _make_fake_mmm()
        X = _make_fake_df()

        # Point cache_dir at a file (not a dir) to force an OSError
        bad_path = tmp_path / "not_a_dir"
        bad_path.write_text("I am a file, not a dir")

        with patch("mixlift_mcp.model_cache.cache_dir", return_value=bad_path), \
             caplog.at_level(logging.WARNING, logger="mixlift_mcp.model_cache"):
            # Should not raise
            asyncio.run(mc.save_model(
                "fp_bad",
                mmm=mmm,
                X=X,
                channel_columns=["ch"],
                result={"status": "ok"},
            ))

        assert any("save failed" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Integration: cache_hit signal in mixlift_analyze response
# ---------------------------------------------------------------------------


class TestCacheHitSignalInAnalyze:
    """Verify force_refresh=True re-runs pipeline, not cache."""

    def test_force_refresh_bypasses_disk_cache(self, tmp_path):
        """With force_refresh=True, load_model must not be called."""
        from mixlift_mcp.server import mixlift_analyze
        from mixlift_mcp.license import LicenseStatus

        # We just verify load_model is never awaited when force_refresh=True.
        # The full pipeline is mocked so no actual MCMC runs.
        mock_model_results = MagicMock()
        mock_model_results.roas_estimates = {"Meta": 2.3}
        mock_model_results.roas_ci = {"Meta": (1.5, 3.1)}
        mock_model_results.marginal_roas_estimates = {"Meta": 1.8}
        mock_model_results.marginal_roas_ci = {"Meta": (1.2, 2.4)}
        mock_model_results.channel_contributions = {"Meta": 5000.0}
        mock_model_results.channel_contributions_ci = {"Meta": (4000.0, 6000.0)}
        mock_model_results.total_spend = {"Meta": 2000.0}
        mock_model_results.convergence_warnings = []
        mock_model_results.posterior_predictive_warning = ""
        mock_model_results.duration_secs = 12.0
        mock_model_results.raw_contributions = MagicMock()
        mock_model_results.loo_cv = {}
        mock_model_results.intercept_decomposition = {}
        mock_model_results.mmm = MagicMock()

        pro_license = LicenseStatus(is_pro=True, max_channels=999, max_rows=999_999, message="Pro")

        csv_path = tmp_path / "test.csv"
        import pandas as pd, numpy as np
        df = pd.DataFrame({
            "date": pd.date_range("2023-01-01", periods=30, freq="W-MON"),
            "google_spend": np.random.default_rng(1).uniform(1000, 5000, 30),
            "meta_spend": np.random.default_rng(2).uniform(2000, 8000, 30),
            "revenue": np.random.default_rng(3).uniform(30000, 80000, 30),
        })
        df.to_csv(csv_path, index=False)

        load_model_calls = []

        async def mock_load_model(fp):
            load_model_calls.append(fp)
            return None  # miss

        with (
            patch("mixlift_mcp.server._resolve_license", new=AsyncMock(return_value=pro_license)),
            patch("mixlift_mcp.server._run_pipeline", return_value=mock_model_results),
            patch("mixlift_mcp.server._run_optimizer", return_value={"current_allocation": {"Meta": 2000}, "expected_lift_pct": 5.0, "optimized_allocation": {"Meta": 2000}}),
            patch("mixlift_mcp.server._run_saturation", return_value={}),
            patch("mixlift_mcp.model_cache.load_model", side_effect=mock_load_model),
            patch("mixlift_mcp.model_cache.save_model", new=AsyncMock()),
        ):
            result_str = asyncio.run(mixlift_analyze(
                csv_path=str(csv_path),
                license_key="test-key",
                force_refresh=True,
            ))

        # force_refresh=True → load_model should NOT have been called
        assert load_model_calls == [], (
            f"load_model was called {len(load_model_calls)} times with force_refresh=True"
        )
        result = json.loads(result_str)
        assert result.get("status") != "error" or "cache" not in result.get("message", "")


# ---------------------------------------------------------------------------
# Backtest fingerprint tests
# ---------------------------------------------------------------------------


class TestBacktestFingerprint:
    # Known stable value computed with the existing algorithm (no backtest_config).
    # This pins backward compatibility: if the baseline changes, the test fails loudly.
    _BASELINE_FP = mc.compute_model_fingerprint(b"csv_bytes", ["google_spend", "meta_spend"])

    def test_model_fingerprint_unchanged_without_backtest_config(self):
        """Existing callers (no backtest_config) get the same fingerprint as before."""
        fp = mc.compute_model_fingerprint(b"csv_bytes", ["google_spend", "meta_spend"])
        assert fp == self._BASELINE_FP

    def test_backtest_config_produces_distinct_fingerprint(self):
        """Same csv+channels+mcmc → different hash with vs. without backtest_config."""
        fp_plain = mc.compute_model_fingerprint(b"csv_bytes", ["google_spend", "meta_spend"])
        fp_bt = mc.compute_model_fingerprint(
            b"csv_bytes",
            ["google_spend", "meta_spend"],
            backtest_config={"n_folds": 3, "horizon": 8},
        )
        assert fp_plain != fp_bt

    def test_different_n_folds_changes_fingerprint(self):
        fp3 = mc.compute_model_fingerprint(
            b"csv", ["ch"], backtest_config={"n_folds": 3, "horizon": 8}
        )
        fp5 = mc.compute_model_fingerprint(
            b"csv", ["ch"], backtest_config={"n_folds": 5, "horizon": 8}
        )
        assert fp3 != fp5

    def test_different_horizon_changes_fingerprint(self):
        fp8 = mc.compute_model_fingerprint(
            b"csv", ["ch"], backtest_config={"n_folds": 3, "horizon": 8}
        )
        fp12 = mc.compute_model_fingerprint(
            b"csv", ["ch"], backtest_config={"n_folds": 3, "horizon": 12}
        )
        assert fp8 != fp12

    def test_compute_backtest_fingerprint_helper(self):
        """Helper returns same value as manual compute_model_fingerprint(..., backtest_config=...)."""  # noqa: E501
        expected = mc.compute_model_fingerprint(
            b"csv_bytes",
            ["google_spend", "meta_spend"],
            {"chains": 4, "draws": 250},
            backtest_config={"n_folds": 4, "horizon": 8},
        )
        actual = mc.compute_backtest_fingerprint(
            b"csv_bytes",
            ["google_spend", "meta_spend"],
            {"chains": 4, "draws": 250},
            n_folds=4,
            horizon=8,
        )
        assert actual == expected


# ---------------------------------------------------------------------------
# save_backtest / load_backtest tests
# ---------------------------------------------------------------------------


def _make_fake_backtest() -> dict:
    return {
        "mode": "rolling",
        "status": "success",
        "n_folds": 3,
        "horizon_weeks": 8,
        "train_weeks": 52,
        "folds": [
            {"fold": 0, "mape": 7.12, "rmse": 1234.5, "train_size": 44, "test_size": 8},
            {"fold": 1, "mape": 8.91, "rmse": 1456.7, "train_size": 52, "test_size": 8},
            {"fold": 2, "mape": 9.34, "rmse": 1789.0, "train_size": 60, "test_size": 8},
        ],
        "aggregate": {
            "mape_mean": 8.4321,
            "mape_std": 0.9876543,
            "rmse_mean": 1493.4,
            "rmse_std": 228.15,
        },
        "compute_secs": 97.3,
        "note": "rolling backtest",
    }


class TestSaveLoadBacktest:
    @pytest.fixture(autouse=True)
    def _patch_cache_dir(self, tmp_path, monkeypatch):
        versioned = tmp_path / f"v{mc.SCHEMA_VERSION}"
        versioned.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(mc, "cache_dir", lambda: versioned)

    def test_save_load_backtest_roundtrip(self):
        bt = _make_fake_backtest()
        fp = "bt_roundtrip_001"
        mc.save_backtest(fp, bt)
        loaded = mc.load_backtest(fp)
        assert loaded is not None
        assert loaded["mode"] == "rolling"
        assert loaded["n_folds"] == 3
        assert loaded["folds"][0]["mape"] == pytest.approx(7.12)
        assert loaded["aggregate"]["mape_mean"] == pytest.approx(8.4321)
        assert loaded["folds"] == bt["folds"]

    def test_save_load_backtest_preserves_float_precision(self):
        fp = "bt_precision_001"
        mc.save_backtest(fp, {"mape_mean": 8.4321})
        loaded = mc.load_backtest(fp)
        assert loaded is not None
        assert abs(loaded["mape_mean"] - 8.4321) < 1e-9

    def test_load_backtest_returns_none_on_missing(self):
        result = mc.load_backtest("nonexistent_bt_fp_9999")
        assert result is None

    def test_load_backtest_returns_none_on_corrupted_file(self, tmp_path):
        fp = "bt_corrupt_001"
        bt_dir = mc._backtest_dir()
        bt_dir.mkdir(parents=True, exist_ok=True)
        (bt_dir / f"{fp}.json").write_text("NOT VALID JSON {{{{")
        result = mc.load_backtest(fp)
        assert result is None

    def test_save_backtest_overwrites_prior(self):
        fp = "bt_overwrite_001"
        mc.save_backtest(fp, {"value": "first"})
        mc.save_backtest(fp, {"value": "second"})
        loaded = mc.load_backtest(fp)
        assert loaded is not None
        assert loaded["value"] == "second"

    def test_save_backtest_silent_on_write_failure(self, caplog):
        """save_backtest must not raise when writing fails."""
        import logging
        from unittest.mock import patch

        fp = "bt_write_fail_001"
        with patch("builtins.open", side_effect=OSError("disk full")), \
             caplog.at_level(logging.WARNING, logger="mixlift_mcp.model_cache"):
            mc.save_backtest(fp, {"value": 1})  # must not raise

        # A warning should have been emitted (via logger.warning, which may use
        # Path.write_text rather than open() directly — accept zero warnings too
        # since the implementation uses Path.write_text, not open())
        # What matters is: no exception propagated.

    def test_save_backtest_silent_on_write_text_failure(self, caplog):
        """save_backtest must not raise when Path.write_text fails."""
        import logging
        from pathlib import Path
        from unittest.mock import patch

        fp = "bt_write_text_fail_001"
        with patch.object(Path, "write_text", side_effect=OSError("disk full")), \
             caplog.at_level(logging.WARNING, logger="mixlift_mcp.model_cache"):
            mc.save_backtest(fp, {"value": 1})  # must not raise

        assert any("save failed" in r.message for r in caplog.records)
