## Where each channel sits on its curve

**Meta Prospecting is the most saturated channel.** At $18,070/wk you are 64% **of the way to** the efficient frontier. The next $5k here earns a 1.82× ROAS. Cutting $5000 loses only $12,957.

**Email is nowhere near the top.** At $800/wk you are 6% of the way up the curve. The next $5k earns a 4.43× marginal ROAS. Incremental spend compounds for multiple brackets from here.

### By channel — what the next $5k earns

| Channel | Current | Saturation | Next $5k ROAS | Verdict |
|:--------|--------:|-----------:|:--------------|:--------|
| Meta Prospecting | $18,070 | 64% | 1.82× | Approaching ceiling |
| Youtube | $4,500 | 19% | 2.64× | Push hard |
| Google Search | $5,000 | 18% | 2.56× | Push hard |
| TikTok | $3,000 | 16% | 3.79× | Push hard |
| Bing | $2,000 | 12% | 3.05× | Push hard |
| Pinterest | $1,200 | 10% | 3.59× | Push hard |
| Snapchat | $600 | 6% | 4.24× | Push hard |
| Email | $800 | 6% | 4.43× | Push hard |

### Meta Prospecting — approaching ceiling
Current: $18,070/wk · Saturation: 64% · Marginal ROAS: 0.42× (0.18×–0.71× CI)

| If you add | Revenue lift | ROAS |
|:-----------|-------------:|-----:|
| +$1,000 | $2,103 | 2.10× |
| +$5,000 | $9,082 | 1.82× |
| +$10,000 | $15,131 | 1.51× |
| +$25,000 | $22,990 | 0.92× |

| If you cut | Revenue lost | Net if cut |
|:-----------|-------------:|:-----------|
| −$1,000 | $2,259 | −$1,259 |
| −$5,000 | $12,957 | −$7,957 |
| −$10,000 | $30,152 | −$20,152 |

### Youtube — push hard
Current: $4,500/wk · Saturation: 19% · Marginal ROAS: 1.20× (0.80×–1.70× CI)

| If you add | Revenue lift | ROAS |
|:-----------|-------------:|-----:|
| +$1,000 | $2,781 | 2.78× |
| +$5,000 | $13,224 | 2.64× |
| +$10,000 | $24,282 | 2.43× |
| +$25,000 | $38,573 | 1.54× |

| If you cut | Revenue lost | Net if cut |
|:-----------|-------------:|:-----------|
| −$1,000 | $2,832 | −$1,832 |

### Google Search — push hard
Current: $5,000/wk · Saturation: 18% · Marginal ROAS: 1.85× (1.20×–2.60× CI)

| If you add | Revenue lift | ROAS |
|:-----------|-------------:|-----:|
| +$1,000 | $2,669 | 2.67× |
| +$5,000 | $12,781 | 2.56× |
| +$10,000 | $23,777 | 2.38× |
| +$25,000 | $44,540 | 1.78× |

| If you cut | Revenue lost | Net if cut |
|:-----------|-------------:|:-----------|
| −$1,000 | $2,711 | −$1,711 |

### TikTok — push hard
Current: $3,000/wk · Saturation: 16% · Marginal ROAS: 2.10× (1.40×–2.90× CI)

| If you add | Revenue lift | ROAS |
|:-----------|-------------:|-----:|
| +$1,000 | $4,202 | 4.20× |
| +$5,000 | $18,945 | 3.79× |
| +$10,000 | $31,776 | 3.18× |
| +$25,000 | $41,033 | 1.64× |

| If you cut | Revenue lost | Net if cut |
|:-----------|-------------:|:-----------|
| −$1,000 | $4,343 | −$3,343 |

### Bing — push hard
Current: $2,000/wk · Saturation: 12% · Marginal ROAS: 1.55× (1.00×–2.20× CI)

| If you add | Revenue lift | ROAS |
|:-----------|-------------:|-----:|
| +$1,000 | $3,226 | 3.23× |
| +$5,000 | $15,262 | 3.05× |
| +$10,000 | $27,361 | 2.74× |
| +$25,000 | $34,367 | 1.37× |

| If you cut | Revenue lost | Net if cut |
|:-----------|-------------:|:-----------|
| −$1,000 | $3,272 | −$2,272 |

### Pinterest — push hard
Current: $1,200/wk · Saturation: 10% · Marginal ROAS: 1.90× (1.20×–2.70× CI)

| If you add | Revenue lift | ROAS |
|:-----------|-------------:|-----:|
| +$1,000 | $3,954 | 3.95× |
| +$5,000 | $17,951 | 3.59× |
| +$10,000 | $29,580 | 2.96× |
| +$25,000 | $30,853 | 1.23× |

| If you cut | Revenue lost | Net if cut |
|:-----------|-------------:|:-----------|
| −$1,000 | $4,031 | −$3,031 |

### Snapchat — push hard
Current: $600/wk · Saturation: 6% · Marginal ROAS: 2.30× (1.50×–3.20× CI)

| If you add | Revenue lift | ROAS |
|:-----------|-------------:|-----:|
| +$1,000 | $4,900 | 4.90× |
| +$5,000 | $21,180 | 4.24× |
| +$10,000 | $30,937 | 3.09× |
| +$25,000 | $30,937 | 1.24× |

### Email — push hard
Current: $800/wk · Saturation: 6% · Marginal ROAS: 2.84× (1.90×–3.90× CI)

| If you add | Revenue lift | ROAS |
|:-----------|-------------:|-----:|
| +$1,000 | $4,912 | 4.91× |
| +$5,000 | $22,141 | 4.43× |
| +$10,000 | $35,668 | 3.57× |
| +$25,000 | $42,092 | 1.68× |

*Data window: 2025-04-14 to 2026-04-07 (51 weeks). Posterior: 4 chains × 250 draws*