## Best move: +20% budget to Email and Influencer (+$18k projected)

Expected revenue lift: +$18,000 (3.8% above status quo). Credible interval: $455k–$541k. Second-best: Shift 20% from Meta to Email (+$6k revenue delta).

### Scenario comparison

| Rank | Scenario                             | Projected | CI                  |    vs SQ |      % |
|------|--------------------------------------|----------:|---------------------|----------:|-------:|
|    1 | +20% budget to Email and Influencer  |     $498k | $455k–$541k         |    +$18k |  +3.8% |
|    3 | Shift 20% from Meta to Email         |     $486k | $442k–$530k         |     +$6k |  +1.2% |
|    2 | Status quo                           |     $480k | $440k–$520k         |        — |      — |
|    4 | Cut Meta 50%                         |     $476k | $432k–$520k         |     −$4k |  −0.8% |
|    5 | −20% total budget                    |     $412k | $372k–$452k         |    −$68k | −14.2% |

### Scenario details

#### 1. +20% budget to Email and Influencer
Delta applied: Email +20%, Influencer +20%
Projected: $498,000 (80% CI: $455,000–$541,000)
vs Status Quo: +$18,000 (+3.8%)

#### 3. Shift 20% from Meta to Email
Delta applied: Meta -20%, Email +20%
Projected: $486,000 (80% CI: $442,000–$530,000)
vs Status Quo: +$6,000 (+1.2%)

#### 2. Status quo
Delta applied: none (status quo)
Projected: $480,000 (80% CI: $440,000–$520,000)
vs Status Quo: baseline

#### 4. Cut Meta 50%
Delta applied: Meta -50%
Projected: $476,000 (80% CI: $432,000–$520,000)
vs Status Quo: −$4,000 (−0.8%)

#### 5. −20% total budget
Delta applied: Meta -20%, Email -20%, Influencer -20%
Projected: $412,000 (80% CI: $372,000–$452,000)
vs Status Quo: −$68,000 (−14.2%)


*Data window: 2025-04-14 to 2026-04-07 (51 weeks). Posterior: 4 chains × 250 draws.*