## You are day 14 of 30, $76k of $170k planned

**On track.** At 45% of budget used with 47% of the period elapsed — pacing within the ±5% band.

| Channel | Budget | Spent | % | Projected | Variance | Status |
|---------|-------:|------:|--:|----------:|---------:|--------|
| Meta | $80,000 | $30,000 | 38% | $64,286 | −$15,714 | Under |
| Google Search | $60,000 | $33,340 | 56% | $71,443 | +$11,443 | Over |
| TikTok | $30,000 | $12,560 | 42% | $26,914 | −$3,086 | Under |
| **Total** | $170,000 | $75,900 | 45% | $162,527 | −$7,473 | On Track |

### To land on plan

| Channel | Current daily | Required daily | Adjustment |
|---------|--------------|----------------|------------|
| Meta | $2,143 | $3,125 | +$982/day |
| Google Search | $2,381 | $1,666 | −$715/day |
| TikTok | $897 | $1,090 | +$193/day |