Of $1,920,000 last 4 weeks, $1,300,000 (68%) was baseline and $620,000 (32%) was paid-attributable.

Meta carried $320,000 — 52% of paid revenue at 4.43× ROAS.

### Revenue decomposition — last 4 weeks

| Source              | Revenue    | % of total | Credible interval     |
|---------------------|------------|------------|-----------------------|
| Baseline            | $1,300,000 | 68% | $1,238,000–$1,362,000 |
| **Paid total**      | **$620,000** | **32%** | **$558,000–$682,000** |
| ├── Meta            | $320,000 | 17% | $288,000–$352,000 |
| ├── Google Search   | $180,000 | 9% | $162,000–$198,000 |
| └── TikTok          | $120,000 | 6% | $108,000–$132,000 |

### By channel — contribution, spend, ROAS

| Channel       | Contribution | Spend     | ROAS  | Credible interval |
|---------------|--------------|-----------|-------|-------------------|
| Meta              | $320,000     | $72,280   | 4.43× | $288k–$352k |
| Google Search              | $180,000     | $45,000   | 4.00× | $162k–$198k |
| TikTok              | $120,000     | $30,000   | 4.00× | $108k–$132k |

*Data window: 2025-04-14 to 2026-04-07 (51 weeks). Posterior: 4 chains × 250 draws*

*Per-period channel contributions are proportionally scaled from the full-window posterior; total revenue is from observed data.*