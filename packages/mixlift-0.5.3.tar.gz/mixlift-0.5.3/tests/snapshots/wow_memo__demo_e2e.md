## Revenue was $30,000 down last week

$480,000 this period vs $510,000 prior (−5.9% change).
**Meta drove the drop.** Contribution fell from $92,000 to $80,000 ($12,000).
You spent $1,570 more there but efficiency fell from 5.58× to 4.43× — a −21% marginal-ROAS change representing $20,754 in lost revenue.

### Revenue delta

| Source          | This period | Prior    | Delta    | % change |
|-----------------|-------------|----------|----------|----------|
| Total           | $480,000    | $510,000 | −$30,000 | −5.9% |
| Baseline        | $310,000    | $325,000 | −$15,000 | −4.6% |
| Paid            | $170,000    | $185,000 | −$15,000 | −8.1% |
| ├ Meta          | $80,000     | $92,000  | −$12,000 | −13.0% |
| ├ TikTok        | $30,000     | $35,000  | −$5,000  | −14.3% |
| └ Google Search | $60,000     | $58,000  | +$2,000  | +3.4% |

### Spend vs efficiency decomposition

| Channel         | Spend effect | Efficiency effect | Net delta |
|-----------------|--------------|-------------------|-----------|
| Meta              | +$7,852      | −$20,754          | −$12,000 |
| TikTok              | −$2,094      | −$2,812           | −$5,000 |
| Google Search              | +$4,071      | −$2,143           | +$2,000 |

*Data window: 2025-10-06 to 2026-04-14 (27 weeks). Posterior: 4 chains × 250 draws*

*Per-period contributions proportionally scaled from full-window posterior; total revenue from observed data.*