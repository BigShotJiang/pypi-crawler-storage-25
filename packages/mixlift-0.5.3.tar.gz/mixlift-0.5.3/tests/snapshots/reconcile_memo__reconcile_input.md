## Your platforms report $315,000 more than MMM attributes

Platform dashboards claim $580,000 of last 4 weeks revenue; MMM attributes $290,000. **Meta is the biggest over-claimer** — its dashboard reports $340,000 from a channel MMM credits at $80,000. The $260,000 gap is probably view-through double-count and retargeting overlap on converters who would have purchased anyway.

| Channel       | Platform RPT  | MMM attrib.  | Gap ($)    | Gap (%)  | Verdict        |
|---------------|---------------|--------------|------------|----------|----------------|
| Meta          | $340,000      | $80,000      | $260,000   | +325%    | Over-claiming  |
| Google Search | $180,000      | $130,000     | $50,000    | +38%     | Over-claiming  |
| TikTok        | $60,000       | $55,000      | $5,000     | +9%      | Aligned        |
| Email         | —             | $25,000      | —          | —        | Unmeasured     |

### Why the gap?

**Meta (+$260,000, +325%):** Likely drivers —
- View-through attribution on converters exposed to other channels
- Retargeting credit for users already intending to purchase
- Click overlap with Email and Google (double-counted)

**Google Search (+$50,000, +38%):** Likely drivers —
- Branded-search credit (purchases that would have happened organically)
- Last-click bias on converted-anyway traffic

*Reconciliation is directional. MMM uses posterior inference, platforms use deterministic attribution; both have error bars. MMM is conservative by design — it credits only incremental revenue.*