## Week of April 7 — April 14

**Revenue: $480,000, −5.9% vs prior week.**
Meta (−$12,700 efficiency) took the biggest efficiency hit. Email (+$3,000 efficiency) remains the strongest compounder.

### Three moves this week

**1. Pull back Meta by $2,000** — Efficiency declined this week; marginal ROAS fell from 0.78× to 0.42×. Net efficiency loss: $12,700.
Net gain: +$3,810 net at current efficiency.

**2. Push Email to $1,300/wk** — 2.84× marginal ROAS, 6% of its saturation curve. Incremental spend compounds here.
Net gain: +$2,456 incremental revenue.

### Last week

Revenue $480,000, −$30,000 vs prior (−5.9%).

| Channel | Contribution | Prior | Delta | mROAS change |
|---------|-------------|-------|-------|--------------|
| Meta | $120,000 | $140,000 | −$20,000 | 0.78× → 0.42× |
| Email | $32,000 | $29,000 | +$3,000 | 2.50× → 2.84× |

### Response curves

| Channel | Spend/wk | Saturation | Next $5k ROAS | Status |
|---------|---------|------------|---------------|--------|
| Meta | $18,070 | 64% | 1.82× | Approaching ceiling |
| Email | $800 | 6% | 4.43× | Push hard |

*— Generated from fit unknown, 4 chains × 250 draws*
*— Full reports: `mixlift_wow`, `mixlift_saturation`, `mixlift_pacing`*