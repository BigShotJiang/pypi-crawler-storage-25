Found 5 issue(s). 7 auto-fix. 1 need(s) your call.

### Auto-fixable (Will apply silently)

- `FB` + `facebook` → `Meta` (6 rows)
- `google_search` + `AdWords` → `Google` (4 rows)
- `TTK` → `TikTok` (2 rows)
- Strip currency markers from `spend` column (78 rows)
- Drop 2 exact duplicate row(s)
- Drop empty rows (1 affected)
- Strip whitespace from headers

### Needs your call

- Outlier spike on 2025-03-31: TikTok spend $91,500 (43× rolling median of $2,100). Leave as-is or investigate?

### Informational

- 204 rows across 8 channel(s), 52 week(s) — 2025-04-14 to 2026-04-07
- 0 row(s) have zero spend across all channels.