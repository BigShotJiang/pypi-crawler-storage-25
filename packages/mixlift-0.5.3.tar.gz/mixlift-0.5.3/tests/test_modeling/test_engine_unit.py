"""Unit tests for engine math functions, saturation, adstock, and convergence diagnostics.

These tests do NOT require MCMC fitting and run fast.
"""

import numpy as np
import pytest


class TestLogisticSaturation:
    """Test that our logistic_saturation matches PyMC-Marketing's formula."""

    def test_zero_spend_gives_zero(self):
        from mixlift.modeling.engine import logistic_saturation

        result = logistic_saturation(np.array([0.0]), lam=1.0)
        assert result[0] == pytest.approx(0.0, abs=1e-10)

    def test_large_spend_approaches_one(self):
        from mixlift.modeling.engine import logistic_saturation

        result = logistic_saturation(np.array([100.0]), lam=1.0)
        assert result[0] == pytest.approx(1.0, abs=1e-6)

    def test_formula_matches_pymc_marketing(self):
        """Verify our NumPy formula matches PyMC-Marketing's PyTensor formula."""
        from mixlift.modeling.engine import logistic_saturation
        from pymc_marketing.mmm.transformers import (
            logistic_saturation as pymc_logistic_saturation,
        )

        test_values = np.array([0.0, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0])
        for lam in [0.25, 0.5, 1.0, 2.0, 4.0]:
            our_result = logistic_saturation(test_values, lam=lam)
            pymc_result = pymc_logistic_saturation(test_values, lam=lam).eval()
            np.testing.assert_allclose(
                our_result,
                pymc_result,
                rtol=1e-7,
                err_msg=f"Mismatch at lam={lam}",
            )

    def test_monotonically_increasing(self):
        from mixlift.modeling.engine import logistic_saturation

        spend = np.linspace(0, 10, 50)
        result = logistic_saturation(spend, lam=1.0)
        diffs = np.diff(result)
        assert np.all(diffs >= 0), "Saturation function should be monotonically increasing"

    def test_concave(self):
        """Second derivative should be negative (diminishing returns) for positive spend."""
        from mixlift.modeling.engine import logistic_saturation

        spend = np.linspace(0.1, 10, 50)
        result = logistic_saturation(spend, lam=1.0)
        second_diffs = np.diff(np.diff(result))
        assert np.all(second_diffs <= 1e-10), "Saturation function should be concave"

    def test_higher_lam_saturates_faster(self):
        from mixlift.modeling.engine import logistic_saturation

        spend = np.array([1.0])
        low_lam = logistic_saturation(spend, lam=0.5)[0]
        high_lam = logistic_saturation(spend, lam=2.0)[0]
        assert high_lam > low_lam, "Higher lambda should saturate faster"

    def test_vectorized(self):
        from mixlift.modeling.engine import logistic_saturation

        spend = np.array([0.0, 1.0, 2.0, 5.0])
        result = logistic_saturation(spend, lam=1.0)
        assert result.shape == (4,)


class TestGeometricAdstockNp:
    """Test that our NumPy adstock matches PyMC-Marketing's geometric adstock."""

    def test_no_decay_passes_through(self):
        """With alpha=0, no carryover, so output = input (if normalize=False)."""
        from mixlift.modeling.engine import geometric_adstock_np

        x = np.array([100.0, 200.0, 0.0, 50.0])
        result = geometric_adstock_np(x, alpha=0.0, l_max=4, normalize=False)
        np.testing.assert_allclose(result, x, rtol=1e-7)

    def test_full_decay_smooths_heavily(self):
        """With alpha close to 1, carryover should spread the effect."""
        from mixlift.modeling.engine import geometric_adstock_np

        x = np.array([100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        result = geometric_adstock_np(x, alpha=0.9, l_max=8, normalize=False)
        # The first value should be 100
        assert result[0] == pytest.approx(100.0, rel=1e-5)
        # Subsequent values should be decaying carryover
        assert result[1] > 0
        assert result[1] < result[0]
        # Each subsequent should decay
        for i in range(2, len(result)):
            assert result[i] < result[i - 1]

    def test_output_length_matches_input(self):
        from mixlift.modeling.engine import geometric_adstock_np

        x = np.array([10.0, 20.0, 30.0, 40.0, 50.0])
        result = geometric_adstock_np(x, alpha=0.5, l_max=4)
        assert len(result) == len(x)

    def test_normalized_weights_sum_to_one(self):
        """With normalized weights, a constant spend should yield approximately the same value."""
        from mixlift.modeling.engine import geometric_adstock_np

        # After enough time, a constant spend of 100 with normalized weights
        # should converge to 100 (since weights sum to 1)
        x = np.full(50, 100.0)
        result = geometric_adstock_np(x, alpha=0.5, l_max=8, normalize=True)
        # After the first l_max periods, should converge to 100
        np.testing.assert_allclose(result[-1], 100.0, rtol=0.01)

    def test_matches_pymc_marketing(self):
        """Verify our NumPy adstock matches PyMC-Marketing's geometric adstock."""
        from pymc_marketing.mmm.transformers import geometric_adstock as pymc_geometric

        from mixlift.modeling.engine import geometric_adstock_np

        x = np.array([100.0, 50.0, 200.0, 0.0, 75.0, 30.0, 150.0, 80.0, 0.0, 60.0])

        for alpha in [0.0, 0.3, 0.5, 0.7, 0.9]:
            for normalize in [True, False]:
                our_result = geometric_adstock_np(
                    x, alpha=alpha, l_max=8, normalize=normalize
                )
                pymc_result = pymc_geometric(
                    x, alpha=alpha, l_max=8, normalize=normalize
                ).eval()
                np.testing.assert_allclose(
                    our_result,
                    pymc_result,
                    rtol=1e-5,
                    err_msg=f"Mismatch at alpha={alpha}, normalize={normalize}",
                )


class TestCheckConvergence:
    """Test convergence diagnostic checks using mock inference data."""

    def _make_mock_mmm_with_idata(self, rhat_values, n_divergent=0):
        """Create a mock MMM with controlled R-hat and divergence data."""
        from unittest.mock import MagicMock

        import xarray as xr

        mmm = MagicMock()

        # Build a mock posterior with one variable
        posterior = xr.Dataset(
            {"param_a": xr.DataArray(rhat_values, dims=["chain", "draw"])}
        )

        # Build mock sample stats
        if n_divergent > 0:
            chains, draws = rhat_values.shape
            div = np.zeros((chains, draws), dtype=bool)
            div.flat[:n_divergent] = True
            sample_stats = xr.Dataset(
                {"diverging": xr.DataArray(div, dims=["chain", "draw"])}
            )
        else:
            chains, draws = rhat_values.shape
            sample_stats = xr.Dataset(
                {
                    "diverging": xr.DataArray(
                        np.zeros((chains, draws), dtype=bool), dims=["chain", "draw"]
                    )
                }
            )

        # Build InferenceData mock
        import arviz as az

        idata = az.InferenceData(posterior=posterior, sample_stats=sample_stats)
        mmm.idata = idata

        return mmm

    def test_good_convergence_no_warnings(self):
        from mixlift.modeling.engine import check_convergence

        # 2 chains, 100 draws, values drawn from similar distributions (good convergence)
        rng = np.random.default_rng(42)
        values = rng.normal(1.0, 0.1, size=(2, 100))
        mmm = self._make_mock_mmm_with_idata(values, n_divergent=0)

        warnings = check_convergence(mmm)
        # Good convergence should produce no R-hat warnings
        rhat_warnings = [w for w in warnings if "R-hat" in w]
        div_warnings = [w for w in warnings if "divergent" in w]
        assert len(rhat_warnings) == 0
        assert len(div_warnings) == 0

    def test_divergent_transitions_warned(self):
        from mixlift.modeling.engine import check_convergence

        rng = np.random.default_rng(42)
        values = rng.normal(1.0, 0.1, size=(2, 100))
        mmm = self._make_mock_mmm_with_idata(values, n_divergent=10)

        warnings = check_convergence(mmm)
        div_warnings = [w for w in warnings if "divergent" in w]
        assert len(div_warnings) == 1
        assert "10" in div_warnings[0]

    def test_bad_rhat_warned(self):
        from mixlift.modeling.engine import check_convergence

        # 2 chains with very different means (bad convergence)
        chain_1 = np.full(100, 0.0)
        chain_2 = np.full(100, 10.0)
        values = np.stack([chain_1, chain_2])
        mmm = self._make_mock_mmm_with_idata(values, n_divergent=0)

        warnings = check_convergence(mmm)
        rhat_warnings = [w for w in warnings if "R-hat" in w]
        assert len(rhat_warnings) >= 1


class TestComputeLooCv:
    """Test LOO-CV computation using mock inference data."""

    def _make_mock_mmm_with_log_likelihood(self, n_chains=2, n_draws=100, n_obs=52,
                                            high_k_count=0):
        """Create a mock MMM with log_likelihood group for LOO-CV testing."""
        from unittest.mock import MagicMock

        import xarray as xr

        mmm = MagicMock()

        rng = np.random.default_rng(42)

        # Build posterior
        posterior = xr.Dataset(
            {"param_a": xr.DataArray(
                rng.normal(1.0, 0.1, size=(n_chains, n_draws)),
                dims=["chain", "draw"],
            )}
        )

        # Build log_likelihood: shape (chains, draws, obs)
        # Normal-ish log-likelihood values
        ll_values = rng.normal(-2.0, 0.5, size=(n_chains, n_draws, n_obs))

        # If we want high-k observations, make some observations have very
        # variable log-likelihood across draws (one draw dominates)
        if high_k_count > 0:
            for i in range(min(high_k_count, n_obs)):
                ll_values[:, :, i] = rng.normal(-10.0, 5.0, size=(n_chains, n_draws))

        log_likelihood = xr.Dataset(
            {"y": xr.DataArray(ll_values, dims=["chain", "draw", "y_dim_0"])}
        )

        sample_stats = xr.Dataset(
            {"diverging": xr.DataArray(
                np.zeros((n_chains, n_draws), dtype=bool),
                dims=["chain", "draw"],
            )}
        )

        import arviz as az
        idata = az.InferenceData(
            posterior=posterior,
            log_likelihood=log_likelihood,
            sample_stats=sample_stats,
        )
        mmm.idata = idata
        return mmm

    def _make_mock_mmm_no_log_likelihood(self):
        """Create a mock MMM without log_likelihood group."""
        from unittest.mock import MagicMock

        import xarray as xr

        mmm = MagicMock()
        rng = np.random.default_rng(42)
        posterior = xr.Dataset(
            {"param_a": xr.DataArray(
                rng.normal(1.0, 0.1, size=(2, 100)),
                dims=["chain", "draw"],
            )}
        )

        import arviz as az
        idata = az.InferenceData(posterior=posterior)
        mmm.idata = idata
        return mmm

    def test_loo_cv_returns_valid_dict(self):
        from mixlift.modeling.engine import compute_loo_cv

        mmm = self._make_mock_mmm_with_log_likelihood()
        result = compute_loo_cv(mmm, n_data_points=52)

        assert "elpd_loo" in result
        assert "se" in result
        assert "p_loo" in result
        assert "interpretation" in result
        assert "interpretation_label" in result
        assert "warnings" in result
        assert "n_data_points" in result
        assert result["n_data_points"] == 52
        assert result["interpretation"] in ("good", "fair", "poor")

    def test_loo_cv_no_log_likelihood(self):
        from mixlift.modeling.engine import compute_loo_cv

        mmm = self._make_mock_mmm_no_log_likelihood()
        result = compute_loo_cv(mmm, n_data_points=52)

        assert "error" in result
        assert result["interpretation"] == "unavailable"

    def test_loo_cv_interpretation_types(self):
        """Verify that interpretation is always one of the expected values."""
        from mixlift.modeling.engine import compute_loo_cv

        mmm = self._make_mock_mmm_with_log_likelihood(n_obs=52)
        result = compute_loo_cv(mmm, n_data_points=52)
        assert result["interpretation"] in ("good", "fair", "poor", "unavailable")

    def test_loo_cv_elpd_is_negative(self):
        """ELPD-LOO should typically be negative (log-likelihood scale)."""
        from mixlift.modeling.engine import compute_loo_cv

        mmm = self._make_mock_mmm_with_log_likelihood()
        result = compute_loo_cv(mmm, n_data_points=52)

        if "error" not in result:
            assert result["elpd_loo"] < 0, "ELPD-LOO should be negative"

    def test_loo_cv_se_is_positive(self):
        from mixlift.modeling.engine import compute_loo_cv

        mmm = self._make_mock_mmm_with_log_likelihood()
        result = compute_loo_cv(mmm, n_data_points=52)

        if "error" not in result:
            assert result["se"] > 0, "Standard error should be positive"


class TestExtractIntercept:
    """Test intercept decomposition for baseline/organic revenue."""

    def _make_mock_mmm_with_intercept(self, intercept_mean=5000.0, intercept_std=500.0,
                                       var_name="intercept"):
        """Create a mock MMM with an intercept in the posterior."""
        from unittest.mock import MagicMock

        import xarray as xr

        mmm = MagicMock()
        rng = np.random.default_rng(42)

        intercept_samples = rng.normal(intercept_mean, intercept_std, size=(2, 100))
        posterior = xr.Dataset(
            {var_name: xr.DataArray(intercept_samples, dims=["chain", "draw"])}
        )

        import arviz as az
        idata = az.InferenceData(posterior=posterior)
        mmm.idata = idata
        return mmm

    def test_intercept_extraction_basic(self):
        from mixlift.modeling.engine import extract_intercept

        mmm = self._make_mock_mmm_with_intercept(intercept_mean=5000.0)
        result = extract_intercept(mmm, n_data_points=52)

        assert "error" not in result
        assert "weekly_organic_revenue" in result
        assert "annualized_organic_revenue" in result
        assert "weekly_ci" in result
        assert "annualized_ci" in result
        assert "label" in result

        # Annualized should be ~52x weekly
        assert abs(result["annualized_organic_revenue"] - result["weekly_organic_revenue"] * 52) < 1.0

    def test_intercept_ci_ordering(self):
        from mixlift.modeling.engine import extract_intercept

        mmm = self._make_mock_mmm_with_intercept(intercept_mean=5000.0)
        result = extract_intercept(mmm, n_data_points=52)

        assert result["weekly_ci"]["low"] < result["weekly_ci"]["high"]
        assert result["annualized_ci"]["low"] < result["annualized_ci"]["high"]

    def test_intercept_missing_variable(self):
        from mixlift.modeling.engine import extract_intercept

        # Create mock with a different variable name (no "intercept")
        mmm = self._make_mock_mmm_with_intercept(var_name="some_other_param")
        result = extract_intercept(mmm, n_data_points=52)

        assert "error" in result
        assert result["interpretation"] == "unavailable"

    def test_intercept_period_total(self):
        from mixlift.modeling.engine import extract_intercept

        mmm = self._make_mock_mmm_with_intercept(intercept_mean=5000.0)
        result = extract_intercept(mmm, n_data_points=52)

        # period_total should be weekly * n_data_points
        expected = result["weekly_organic_revenue"] * 52
        assert abs(result["period_total"] - expected) < 1.0

    def test_intercept_label_contains_dollar(self):
        from mixlift.modeling.engine import extract_intercept

        mmm = self._make_mock_mmm_with_intercept(intercept_mean=5000.0)
        result = extract_intercept(mmm, n_data_points=52)

        assert "$" in result["label"]
        assert "organic" in result["label"].lower() or "baseline" in result["label"].lower()
