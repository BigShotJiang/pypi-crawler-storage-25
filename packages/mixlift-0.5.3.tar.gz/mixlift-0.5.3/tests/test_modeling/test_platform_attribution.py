"""Tests for platform attribution comparison computation (N9)."""

import pytest

from mixlift.modeling.platform_attribution import compute_platform_comparison

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _single_channel(
    platform_roas_val: float = 3.2,
    mmm_roas_val: float = 1.05,
    ci: tuple[float, float] = (0.87, 1.24),
    spend: float = 150_000.0,
    platform_revenue: float | None = None,
) -> dict:
    """Return result for a single Meta channel with sensible defaults."""
    pr = {"Meta": platform_roas_val}
    rev = {"Meta": platform_revenue} if platform_revenue is not None else None
    return compute_platform_comparison(
        mmm_roas={"Meta": mmm_roas_val},
        mmm_ci={"Meta": ci},
        spend_by_channel={"Meta": spend},
        platform_roas=pr,
        platform_revenue=rev,
    )


# ---------------------------------------------------------------------------
# Verdict tests
# ---------------------------------------------------------------------------


class TestVerdict:
    def test_over_claiming_verdict(self):
        # plat=3.2 > ci_high=1.2 → over_claiming
        result = _single_channel(platform_roas_val=3.2, ci=(0.8, 1.2))
        assert result["channels"]["Meta"]["verdict"] == "over_claiming"

    def test_aligned_verdict(self):
        # plat=1.0 inside (0.8, 1.2)
        result = _single_channel(platform_roas_val=1.0, ci=(0.8, 1.2))
        assert result["channels"]["Meta"]["verdict"] == "aligned"

    def test_under_claiming_verdict(self):
        # plat=0.5 < ci_low=0.8
        result = _single_channel(platform_roas_val=0.5, ci=(0.8, 1.2))
        assert result["channels"]["Meta"]["verdict"] == "under_claiming"

    def test_boundary_at_ci_high_is_aligned(self):
        # plat exactly equals ci_high → NOT > ci_high → aligned
        result = _single_channel(platform_roas_val=1.2, ci=(0.8, 1.2))
        assert result["channels"]["Meta"]["verdict"] == "aligned"

    def test_boundary_just_over_ci_high_is_over_claiming(self):
        # plat=1.21 > ci_high=1.2
        result = _single_channel(platform_roas_val=1.21, ci=(0.8, 1.2))
        assert result["channels"]["Meta"]["verdict"] == "over_claiming"

    def test_boundary_at_ci_low_is_aligned(self):
        # plat exactly equals ci_low → NOT < ci_low → aligned
        result = _single_channel(platform_roas_val=0.8, ci=(0.8, 1.2))
        assert result["channels"]["Meta"]["verdict"] == "aligned"

    def test_unmeasured_verdict_when_mmm_roas_is_zero(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 0},
            mmm_ci={"Meta": (0.0, 0.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 2.5},
        )
        assert result["channels"]["Meta"]["verdict"] == "unmeasured"

    def test_unmeasured_verdict_when_mmm_roas_is_none(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": None},  # type: ignore[dict-item]
            mmm_ci={"Meta": (0.0, 0.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 2.5},
        )
        assert result["channels"]["Meta"]["verdict"] == "unmeasured"


# ---------------------------------------------------------------------------
# Gap pct sign
# ---------------------------------------------------------------------------


class TestGapPct:
    def test_gap_pct_sign_is_negative_when_over_claiming(self):
        # gap_pct = (mmm - plat) / plat; negative when plat > mmm (over-claiming).
        # Example from spec: plat=3.20, mmm=1.05 → (1.05-3.20)/3.20 = -0.672
        result = _single_channel(platform_roas_val=3.2, mmm_roas_val=1.05, ci=(0.87, 1.24))
        gap = result["channels"]["Meta"]["gap_pct"]
        assert gap < 0
        assert abs(gap - (-0.672)) < 0.01

    def test_gap_pct_positive_when_under_claiming(self):
        # plat=0.5, mmm=1.05 → (1.05-0.5)/0.5 = 1.1 → positive
        result = _single_channel(platform_roas_val=0.5, mmm_roas_val=1.05, ci=(0.87, 1.24))
        gap = result["channels"]["Meta"]["gap_pct"]
        assert gap > 0


# ---------------------------------------------------------------------------
# Small-channel filter
# ---------------------------------------------------------------------------


class TestSmallChannelFilter:
    def test_small_channel_filter_excludes_sub_2pct(self):
        # total spend 1M, Meta spend 15K → 1.5% < 2% → excluded
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.0, "Google": 2.0},
            mmm_ci={"Meta": (0.8, 1.2), "Google": (1.5, 2.5)},
            spend_by_channel={"Meta": 15_000.0, "Google": 985_000.0},
            platform_roas={"Meta": 3.0, "Google": 2.0},
        )
        excluded_channels = [e["channel"] for e in result["excluded_channels"]]
        assert "Meta" in excluded_channels
        meta_excl = next(e for e in result["excluded_channels"] if e["channel"] == "Meta")
        assert meta_excl["reason"] == "insufficient_spend"
        assert abs(meta_excl["spend_pct"] - 0.015) < 0.001

    def test_channel_at_exactly_2pct_is_not_excluded(self):
        # spend at exactly 2% threshold → included (strict <)
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.0, "Google": 2.0},
            mmm_ci={"Meta": (0.8, 1.2), "Google": (1.5, 2.5)},
            spend_by_channel={"Meta": 20_000.0, "Google": 980_000.0},
            platform_roas={"Meta": 3.0, "Google": 2.0},
        )
        assert "Meta" in result["channels"]


# ---------------------------------------------------------------------------
# Exclusion edge cases
# ---------------------------------------------------------------------------


class TestExclusions:
    def test_zero_spend_excluded(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.5},
            mmm_ci={"Meta": (1.0, 2.0)},
            spend_by_channel={"Meta": 0.0},
            platform_roas={"Meta": 3.0},
        )
        reasons = [e["reason"] for e in result["excluded_channels"]]
        assert "zero_spend" in reasons

    def test_negative_platform_roas_excluded(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.5},
            mmm_ci={"Meta": (1.0, 2.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": -1.0},
        )
        excl = {e["channel"]: e["reason"] for e in result["excluded_channels"]}
        assert excl.get("Meta") == "negative_platform_roas"

    def test_missing_mmm_channel_excluded_as_not_in_mmm(self):
        result = compute_platform_comparison(
            mmm_roas={"Google": 2.0},
            mmm_ci={"Google": (1.5, 2.5)},
            spend_by_channel={"Meta": 100_000.0, "Google": 100_000.0},
            platform_roas={"Meta": 3.0, "Google": 2.0},
        )
        excl = {e["channel"]: e["reason"] for e in result["excluded_channels"]}
        assert excl.get("Meta") == "not_in_mmm"


# ---------------------------------------------------------------------------
# Input resolution priority
# ---------------------------------------------------------------------------


class TestInputResolution:
    def test_platform_roas_wins_over_platform_revenue_when_both_passed(self):
        # platform_roas=2.0, platform_revenue would derive 3.0 (300k/100k)
        # platform_roas must win → roas in output is 2.0, not 3.0
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.5},
            mmm_ci={"Meta": (1.0, 2.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 2.0},
            platform_revenue={"Meta": 300_000.0},
        )
        ch = result["channels"]["Meta"]
        assert ch["platform_roas"] == pytest.approx(2.0)
        assert result["source"] == "mcp_argument"

    def test_platform_roas_only_sets_source_mcp_argument(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.5},
            mmm_ci={"Meta": (1.0, 2.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 2.0},
        )
        assert result["source"] == "mcp_argument"
        assert result["channels"]["Meta"]["platform_revenue"] is None

    def test_platform_revenue_only_derives_roas(self):
        # spend=100k, revenue=250k → ROAS=2.5
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.5},
            mmm_ci={"Meta": (1.0, 2.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_revenue={"Meta": 250_000.0},
        )
        assert result["source"] == "csv_revenue_column"
        assert result["channels"]["Meta"]["platform_roas"] == pytest.approx(2.5)

    def test_empty_inputs_returns_empty_dict(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.5},
            mmm_ci={"Meta": (1.0, 2.0)},
            spend_by_channel={"Meta": 100_000.0},
        )
        assert result == {}


# ---------------------------------------------------------------------------
# Severity
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "plat_roas,expected_severity",
    [
        # gap_pct = (mmm - plat) / plat; mmm_roas=1.0; abs(gap) = (plat-1)/plat
        # modest:  10% ≤ abs < 20% → (plat-1)/plat in [0.10, 0.20)
        #          plat = 1/(1-0.10) = 1.111...  → abs=0.10 exactly (boundary)
        #          plat = 1/(1-0.15) = 1.176...  → abs=0.15 (mid-band)
        (1.1111, "modest"),      # abs≈0.10 boundary
        (1.176, "modest"),       # abs≈0.15 mid-band
        # significant: 20% ≤ abs < 40% → (plat-1)/1 in [0.20, 0.40) → plat in [1.20, 1.40)
        (1.25, "significant"),   # abs=0.25 boundary-region
        (1.35, "significant"),   # abs=0.35 mid-band
        # severe: 40% ≤ abs < 100% → (plat-1)/1 in [0.40, 1.0) → plat in [1.40, 2.0)
        (1.667, "severe"),       # abs=0.667 mid-band
        (1.90, "severe"),        # abs=0.90 near-top
        # extreme: abs ≥ 100% → plat = 1/(1-1.0)=inf; use large value
        (100.0, "extreme"),      # abs≈0.99 → extreme
        (1000.0, "extreme"),     # clearly extreme
    ],
)
class TestSeverityBanding:
    def test_severity_banding_at_boundaries(self, plat_roas, expected_severity):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.0},
            mmm_ci={"Meta": (0.0, 0.5)},  # ci_high=0.5 ensures over_claiming for plat > 0.5
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": plat_roas},
        )
        ch = result["channels"]["Meta"]
        assert ch["verdict"] == "over_claiming", f"Expected over_claiming, got {ch['verdict']}"
        assert ch["severity"] == expected_severity, (
            f"plat={plat_roas}: expected {expected_severity}, got {ch['severity']}"
        )


class TestSeverityNoneWhenNotOverClaiming:
    def test_severity_none_for_aligned(self):
        result = _single_channel(platform_roas_val=1.0, ci=(0.8, 1.2))
        assert result["channels"]["Meta"]["severity"] is None

    def test_severity_none_for_under_claiming(self):
        result = _single_channel(platform_roas_val=0.5, ci=(0.8, 1.2))
        assert result["channels"]["Meta"]["severity"] is None


# ---------------------------------------------------------------------------
# Confidence
# ---------------------------------------------------------------------------


class TestConfidence:
    def test_confidence_high(self):
        # (ci_high - ci_low) / mmm_roas = (1.24 - 1.0) / 1.05 ≈ 0.229 < 0.3
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.05},
            mmm_ci={"Meta": (1.0, 1.24)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 3.0},
        )
        assert result["channels"]["Meta"]["confidence"] == "high"

    def test_confidence_medium(self):
        # (1.6 - 1.0) / 1.05 ≈ 0.571 → 0.3 ≤ x < 0.6 → medium
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.05},
            mmm_ci={"Meta": (1.0, 1.6)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 3.0},
        )
        assert result["channels"]["Meta"]["confidence"] == "medium"

    def test_confidence_low(self):
        # (2.0 - 0.5) / 1.05 ≈ 1.43 ≥ 0.6 → low
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.05},
            mmm_ci={"Meta": (0.5, 2.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 3.0},
        )
        assert result["channels"]["Meta"]["confidence"] == "low"

    def test_confidence_low_when_mmm_roas_zero(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 0},
            mmm_ci={"Meta": (0.0, 0.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 2.0},
        )
        assert result["channels"]["Meta"]["confidence"] == "low"


# ---------------------------------------------------------------------------
# Summary: most_egregious
# ---------------------------------------------------------------------------


class TestMostEgregious:
    def test_most_egregious_picks_largest_abs_gap_over_claimers(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.0, "TikTok": 1.0},
            mmm_ci={"Meta": (0.0, 0.5), "TikTok": (0.0, 0.5)},
            spend_by_channel={"Meta": 500_000.0, "TikTok": 500_000.0},
            platform_roas={"Meta": 4.0, "TikTok": 2.0},
        )
        # Meta has bigger gap (abs) → most egregious
        assert result["summary"]["most_egregious"]["channel"] == "Meta"

    def test_most_egregious_is_none_when_no_over_claimers(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.0},
            mmm_ci={"Meta": (0.8, 1.2)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 1.0},  # aligned
        )
        assert result["summary"]["most_egregious"] is None


# ---------------------------------------------------------------------------
# Summary: phantom revenue
# ---------------------------------------------------------------------------


class TestPhantomRevenue:
    def test_phantom_revenue_pct_computed(self):
        # Meta: plat_rev=480k, mmm_roas=1.05, spend=150k → mmm_rev=157.5k
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.05},
            mmm_ci={"Meta": (0.87, 1.24)},
            spend_by_channel={"Meta": 150_000.0},
            platform_roas={"Meta": 3.2},
            platform_revenue={"Meta": 480_000.0},
        )
        s = result["summary"]
        assert s["total_platform_revenue"] == pytest.approx(480_000.0)
        assert s["total_mmm_revenue"] == pytest.approx(1.05 * 150_000.0)
        expected_pct = (480_000.0 - 1.05 * 150_000.0) / 480_000.0
        assert s["phantom_revenue_pct"] == pytest.approx(expected_pct)

    def test_phantom_revenue_pct_none_when_platform_revenue_missing(self):
        # platform_roas only, no platform_revenue → totals None
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.05},
            mmm_ci={"Meta": (0.87, 1.24)},
            spend_by_channel={"Meta": 150_000.0},
            platform_roas={"Meta": 3.2},
        )
        s = result["summary"]
        assert s["total_platform_revenue"] is None
        assert s["phantom_revenue_pct"] is None


# ---------------------------------------------------------------------------
# One-liner formatting
# ---------------------------------------------------------------------------


class TestOneLiner:
    def test_one_liner_uses_multiplication_sign(self):
        result = _single_channel()
        one_liner = result["channels"]["Meta"]["one_liner"]
        assert "\u00d7" in one_liner, "Expected × (U+00D7), not 'x'"
        # ASCII 'x' must not appear as the ROAS multiplier suffix; the unicode × must be used.
        # We verify by ensuring the × character appears at least twice (once per ROAS figure).
        assert one_liner.count("\u00d7") >= 2

    def test_one_liner_uses_en_dash_in_ci(self):
        result = _single_channel()
        one_liner = result["channels"]["Meta"]["one_liner"]
        assert "\u2013" in one_liner, "Expected – (U+2013 en-dash) between CI bounds"

    def test_unmeasured_one_liner(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 0},
            mmm_ci={"Meta": (0.0, 0.0)},
            spend_by_channel={"Meta": 100_000.0},
            platform_roas={"Meta": 2.0},
        )
        one_liner = result["channels"]["Meta"]["one_liner"]
        assert "could not measure" in one_liner

    def test_one_liner_contains_gap_pct(self):
        result = _single_channel(platform_roas_val=3.2, mmm_roas_val=1.05, ci=(0.87, 1.24))
        one_liner = result["channels"]["Meta"]["one_liner"]
        # Gap ≈ 67%
        assert "67%" in one_liner


# ---------------------------------------------------------------------------
# Multi-channel integration
# ---------------------------------------------------------------------------


class TestMultiChannel:
    def test_multi_channel_summary_lists(self):
        result = compute_platform_comparison(
            mmm_roas={"Meta": 1.0, "Google": 2.0, "TikTok": 1.0},
            mmm_ci={
                "Meta": (0.0, 0.5),      # ci_high=0.5 → 3.2 > 0.5 → over
                "Google": (1.5, 2.5),    # ci=(1.5,2.5) → 2.0 inside → aligned
                "TikTok": (0.0, 0.5),    # 0.3 inside (0.0, 0.5) → aligned
            },
            spend_by_channel={"Meta": 400_000.0, "Google": 400_000.0, "TikTok": 200_000.0},
            platform_roas={"Meta": 3.2, "Google": 2.0, "TikTok": 0.3},
        )
        s = result["summary"]
        assert "Meta" in s["channels_over_claiming"]
        assert "Google" in s["channels_aligned"]
        # TikTok: plat=0.3, ci=(0.0, 0.5) → 0.3 inside → aligned
        assert "TikTok" in s["channels_aligned"]
