"""Tests for recommendation generation."""

import re

from mixlift.modeling.recommendations import (
    format_all_recommendations,
    format_recommendation,
    generate_recommendations,
)


class TestGenerateRecommendations:
    def test_basic_recommendations(self):
        current = {"Google Search": 5000, "Meta": 8000, "TikTok": 2000}
        optimal = {"Google Search": 7200, "Meta": 6200, "TikTok": 3600}
        roas = {"Google Search": 3.2, "Meta": 1.8, "TikTok": 2.1}

        recs, summary = generate_recommendations(current, optimal, roas, 12.5)

        assert len(recs) > 0
        assert any(r.action == "INCREASE" for r in recs)
        assert any(r.action == "DECREASE" for r in recs)
        assert all(r.rank > 0 for r in recs)
        assert "12.5%" in summary

    def test_no_recommendations_when_optimal(self):
        current = {"A": 1000, "B": 1000}
        optimal = {"A": 1020, "B": 980}  # Less than 5% change
        roas = {"A": 2.0, "B": 2.0}

        recs, summary = generate_recommendations(current, optimal, roas, 0.5)
        assert len(recs) == 0
        assert "close to optimal" in summary.lower()

    def test_recommendations_ranked_by_change_amount(self):
        current = {"A": 5000, "B": 3000, "C": 2000}
        optimal = {"A": 8000, "B": 1000, "C": 1000}
        roas = {"A": 3.0, "B": 1.2, "C": 1.1}

        recs, _ = generate_recommendations(current, optimal, roas, 15.0)

        # Should be ranked by absolute change amount
        for i in range(len(recs) - 1):
            assert recs[i].change_amount >= recs[i + 1].change_amount

    def test_increase_has_positive_reason(self):
        current = {"A": 2000}
        optimal = {"A": 5000}
        roas = {"A": 3.5}

        recs, _ = generate_recommendations(current, optimal, roas, 10.0)
        increase = [r for r in recs if r.action == "INCREASE"]
        assert len(increase) == 1
        assert "roas" in increase[0].reason.lower()

    def test_decrease_mentions_saturation(self):
        current = {"A": 10000}
        optimal = {"A": 5000}
        roas = {"A": 0.8}

        recs, _ = generate_recommendations(current, optimal, roas, 8.0)
        decrease = [r for r in recs if r.action == "DECREASE"]
        assert len(decrease) == 1
        assert "saturat" in decrease[0].reason.lower()


class TestIncreaseReason:
    def test_high_roas_underfed(self):
        current = {"A": 1000}
        optimal = {"A": 5000}
        roas = {"A": 3.5}

        recs, _ = generate_recommendations(current, optimal, roas, 10.0)
        reason = recs[0].reason
        assert "under-fed" in reason
        assert "compounds" in reason
        assert "3.50\u00d7" in reason

    def test_mid_roas_headroom(self):
        current = {"A": 1000}
        optimal = {"A": 5000}
        roas = {"A": 2.0}

        recs, _ = generate_recommendations(current, optimal, roas, 10.0)
        reason = recs[0].reason
        assert "headroom" in reason
        assert "2.00\u00d7" in reason

    def test_low_roas_modest_lift(self):
        current = {"A": 1000}
        optimal = {"A": 5000}
        roas = {"A": 1.2}

        recs, _ = generate_recommendations(current, optimal, roas, 10.0)
        reason = recs[0].reason
        assert "modest lift" in reason
        assert "1.20\u00d7" in reason


class TestDecreaseReason:
    def test_heavy_saturation(self):
        # pct_over > 30: current is 100% over optimal
        current = {"A": 10000}
        optimal = {"A": 5000}
        roas = {"A": 1.5}

        recs, _ = generate_recommendations(current, optimal, roas, 5.0)
        reason = recs[0].reason
        assert "Saturation past" in reason
        assert "efficient frontier" in reason

    def test_mild_saturation(self):
        # pct_over <= 30 and roas >= 1.0
        current = {"A": 6000}
        optimal = {"A": 5000}
        roas = {"A": 1.3}

        recs, _ = generate_recommendations(current, optimal, roas, 3.0)
        reason = recs[0].reason
        assert "Diminishing returns" in reason
        assert "Marginal dollar returns" in reason

    def test_low_roas_reallocation(self):
        # pct_over <= 30 and roas < 1.0
        current = {"A": 6000}
        optimal = {"A": 5000}
        roas = {"A": 0.7}

        recs, _ = generate_recommendations(current, optimal, roas, 3.0)
        reason = recs[0].reason
        assert "trails other channels" in reason
        assert "Reallocating" in reason


class TestSummary:
    def test_summary_both_directions(self):
        current = {"A": 2000, "B": 10000}
        optimal = {"A": 5000, "B": 5000}
        roas = {"A": 3.5, "B": 1.5}

        _, summary = generate_recommendations(current, optimal, roas, 12.5)
        assert "under-fed" in summary
        assert "past saturation" in summary
        assert "12.5%" in summary

    def test_summary_increase_only(self):
        current = {"A": 2000, "B": 3000}
        optimal = {"A": 5000, "B": 3100}
        roas = {"A": 3.5, "B": 2.0}

        _, summary = generate_recommendations(current, optimal, roas, 8.0)
        assert "under-fed" in summary
        assert "8.0%" in summary

    def test_summary_decrease_only(self):
        current = {"A": 10000, "B": 3000}
        optimal = {"A": 5000, "B": 3100}
        roas = {"A": 1.5, "B": 2.0}

        _, summary = generate_recommendations(current, optimal, roas, 5.0)
        assert "past saturation" in summary
        assert "5.0%" in summary


class TestFormatting:
    def test_format_recommendation(self):
        current = {"Google": 5000}
        optimal = {"Google": 7200}
        roas = {"Google": 3.2}

        recs, _ = generate_recommendations(current, optimal, roas, 10.0)
        formatted = format_recommendation(recs[0])
        assert "Google" in formatted
        assert "$" in formatted

    def test_format_all(self):
        current = {"A": 5000, "B": 3000}
        optimal = {"A": 7000, "B": 1000}
        roas = {"A": 3.0, "B": 1.0}

        recs, summary = generate_recommendations(current, optimal, roas, 12.0)
        report = format_all_recommendations(recs, summary)
        assert "BUDGET OPTIMIZATION" in report
        assert "#1" in report


class TestRegressionGuards:
    """Guard against regression to old hedging voice or banned formatting."""

    _CURRENT = {"A": 2000, "B": 10000}
    _OPTIMAL = {"A": 5000, "B": 5000}
    _ROAS = {"A": 3.5, "B": 1.5}

    def _build(self):
        recs, summary = generate_recommendations(
            self._CURRENT, self._OPTIMAL, self._ROAS, 12.5
        )
        all_text = summary + " " + " ".join(r.reason for r in recs)
        return recs, summary, all_text

    def test_no_hedging_phrases(self):
        """Guard against regression to hedging voice."""
        _, _, all_text = self._build()
        banned = ["Room to grow", "could improve", "should be profitable", "approximately"]
        for phrase in banned:
            assert phrase not in all_text, f"Banned phrase found: {phrase!r}"

    def test_summary_under_230_chars(self):
        """Summary must stay concise."""
        _, summary, _ = self._build()
        assert len(summary) < 230, f"Summary is {len(summary)} chars, expected < 230"

    def test_uses_multiplication_sign(self):
        """ROAS references must use \u00d7 (U+00D7), not plain 'x'."""
        _, _, all_text = self._build()
        # Confirm the multiplication sign is present
        assert "\u00d7" in all_text
        # Confirm no bare digit-x-digit pattern (e.g. "3.2x" or "3x")
        assert not re.search(r"\d\.?\d*x\b", all_text), (
            "Plain 'x' used for ROAS instead of \u00d7"
        )

    def test_no_emoji(self):
        """No emoji in summary or reasons."""
        _, _, all_text = self._build()
        # Match any char in the emoji unicode ranges
        emoji_pattern = re.compile(
            "["
            "\U0001f600-\U0001f64f"
            "\U0001f300-\U0001f5ff"
            "\U0001f680-\U0001f6ff"
            "\U0001f1e0-\U0001f1ff"
            "\U00002702-\U000027b0"
            "\U000024c2-\U0001f251"
            "]+",
            flags=re.UNICODE,
        )
        match = emoji_pattern.search(all_text)
        assert match is None, f"Emoji found in output: {match.group()!r}"
