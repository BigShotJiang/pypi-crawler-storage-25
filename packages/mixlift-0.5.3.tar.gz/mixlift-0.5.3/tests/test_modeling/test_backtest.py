"""Tests for mixlift.modeling.backtest — walk-forward holdout validation.

Fast (unit) tests run without MCMC and cover all metric helpers and
routing logic.  Slow (integration) tests run actual MCMC fits and are
guarded with @pytest.mark.slow.

Run fast tests only:
    pytest tests/test_modeling/test_backtest.py -v -m "not slow"

Run slow tests (5-10 min):
    pytest tests/test_modeling/test_backtest.py -v -m slow
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from mixlift.modeling.backtest import (
    BacktestResult,
    _aggregate_folds,
    _compute_fold_metrics,
    _interpret_aggregate,
    run_backtest,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_X_y(n_weeks: int, seed: int = 0) -> tuple[pd.DataFrame, pd.Series, list[str]]:
    """Generate minimal model-ready X / y / channel_columns for n_weeks."""
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2022-01-03", periods=n_weeks, freq="W-MON")

    X = pd.DataFrame({
        "date": dates,
        "google_search_spend": rng.uniform(3000, 7000, n_weeks),
        "meta_prospecting_spend": rng.uniform(4000, 10000, n_weeks),
        "trend": np.arange(n_weeks, dtype=float),
        "is_holiday_week": 0.0,
        "month_sin": np.sin(2 * np.pi * dates.month / 12),
        "month_cos": np.cos(2 * np.pi * dates.month / 12),
        "is_q4": (dates.month >= 10).astype(float),
    })
    channel_columns = ["google_search_spend", "meta_prospecting_spend"]

    # Simple linear-trend revenue with noise
    y = pd.Series(
        50_000 + np.arange(n_weeks) * 100 + rng.normal(0, 5000, n_weeks),
        name="y",
    )
    return X, y, channel_columns


# ---------------------------------------------------------------------------
# Unit tests: _compute_fold_metrics
# ---------------------------------------------------------------------------


class TestComputeFoldMetrics:
    def test_mape_basic(self):
        y_true = np.array([100.0, 200.0, 300.0, 400.0])
        y_pred = np.array([110.0, 190.0, 315.0, 380.0])
        metrics = _compute_fold_metrics(y_true, y_pred, y_pred, y_pred)
        # MAPE = mean(|error| / actual) * 100
        expected = float(np.mean(np.abs((y_true - y_pred) / y_true)) * 100)
        assert metrics["mape"] == pytest.approx(expected, rel=1e-6)

    def test_r_squared_perfect(self):
        y_true = np.array([1.0, 2.0, 3.0, 4.0])
        metrics = _compute_fold_metrics(y_true, y_true, y_true, y_true)
        assert metrics["r_squared"] == pytest.approx(1.0, abs=1e-10)

    def test_r_squared_known(self):
        y_true = np.array([1.0, 2.0, 3.0, 4.0])
        y_pred = np.array([2.0, 2.0, 3.0, 3.0])
        metrics = _compute_fold_metrics(y_true, y_pred, y_pred, y_pred)
        ss_res = np.sum((y_true - y_pred) ** 2)
        ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
        expected_r2 = 1 - ss_res / ss_tot
        assert metrics["r_squared"] == pytest.approx(expected_r2, rel=1e-6)

    def test_coverage_80_all_in_ci(self):
        y_true = np.array([5.0, 10.0, 15.0, 20.0])
        low = y_true - 1.0
        high = y_true + 1.0
        metrics = _compute_fold_metrics(y_true, y_true, low, high)
        assert metrics["coverage_80"] == pytest.approx(1.0)

    def test_coverage_80_none_in_ci(self):
        y_true = np.array([5.0, 10.0, 15.0, 20.0])
        # CI is entirely above actuals
        low = y_true + 10.0
        high = y_true + 20.0
        metrics = _compute_fold_metrics(y_true, y_true, low, high)
        assert metrics["coverage_80"] == pytest.approx(0.0)

    def test_coverage_80_half(self):
        y_true = np.array([5.0, 10.0, 50.0, 100.0])
        # First two inside, last two outside
        low = np.array([4.0, 9.0, 200.0, 300.0])
        high = np.array([6.0, 11.0, 400.0, 500.0])
        metrics = _compute_fold_metrics(y_true, y_true, low, high)
        assert metrics["coverage_80"] == pytest.approx(0.5)

    def test_zero_y_uses_smape(self):
        """When y_true contains a zero, SMAPE is used instead of MAPE (no divide-by-zero)."""
        y_true = np.array([0.0, 100.0, 200.0, 300.0])
        y_pred = np.array([10.0, 110.0, 190.0, 280.0])
        # Should not raise; result should be a finite positive float
        metrics = _compute_fold_metrics(y_true, y_pred, y_pred, y_pred)
        assert np.isfinite(metrics["mape"])
        assert metrics["mape"] > 0

    def test_r_squared_constant_y_returns_none(self):
        """When ss_tot == 0 (constant y_true), r_squared should be None."""
        y_true = np.array([5.0, 5.0, 5.0, 5.0])
        y_pred = np.array([4.0, 6.0, 5.0, 5.0])
        metrics = _compute_fold_metrics(y_true, y_pred, y_pred, y_pred)
        assert metrics["r_squared"] is None


# ---------------------------------------------------------------------------
# Unit tests: _aggregate_folds
# ---------------------------------------------------------------------------


class TestAggregateFolds:
    def _make_fold(self, mape: float, r2: float, cov: float) -> dict:
        return {
            "fold": 1,
            "train_start": "2022-01-03",
            "train_end": "2022-06-27",
            "test_start": "2022-07-04",
            "test_end": "2022-07-25",
            "mape": mape,
            "r_squared": r2,
            "coverage_80": cov,
            "weekly_actual": [],
            "weekly_predicted_mean": [],
            "weekly_predicted_low": [],
            "weekly_predicted_high": [],
        }

    def test_mean_aggregation(self):
        folds = [
            self._make_fold(mape=10.0, r2=0.8, cov=0.75),
            self._make_fold(mape=20.0, r2=0.6, cov=0.65),
            self._make_fold(mape=15.0, r2=0.7, cov=0.70),
        ]
        agg = _aggregate_folds(folds)
        assert agg["mape_mean"] == pytest.approx(15.0)
        assert agg["mape_median"] == pytest.approx(15.0)
        assert agg["r_squared_mean"] == pytest.approx(0.7, rel=1e-6)
        assert agg["coverage_80_mean"] == pytest.approx((0.75 + 0.65 + 0.70) / 3, rel=1e-6)

    def test_aggregate_skips_none_r2(self):
        folds = [
            self._make_fold(mape=5.0, r2=0.9, cov=0.80),
            {
                **self._make_fold(mape=5.0, r2=0.0, cov=0.80),
                "r_squared": None,
            },
        ]
        agg = _aggregate_folds(folds)
        # Only the first fold's r2 should be averaged
        assert agg["r_squared_mean"] == pytest.approx(0.9)


# ---------------------------------------------------------------------------
# Unit tests: _interpret_aggregate
# ---------------------------------------------------------------------------


class TestInterpretAggregate:
    def test_great(self):
        tag, label = _interpret_aggregate(mape_mean=8.0, coverage_80_mean=0.80)
        assert tag == "great"
        assert label == "well_calibrated"

    def test_acceptable(self):
        tag, label = _interpret_aggregate(mape_mean=15.0, coverage_80_mean=0.78)
        assert tag == "acceptable"
        assert label == "directional"

    def test_poor_high_mape(self):
        tag, label = _interpret_aggregate(mape_mean=25.0, coverage_80_mean=0.78)
        assert tag == "poor"
        assert label == "use_with_caution"

    def test_poor_coverage_too_low(self):
        """Low coverage kicks into poor even when MAPE is great."""
        tag, label = _interpret_aggregate(mape_mean=8.0, coverage_80_mean=0.40)
        assert tag == "poor"
        assert label == "use_with_caution"

    def test_poor_coverage_too_high_great_threshold(self):
        """Coverage above 0.90 fails the great band (overconfident)."""
        tag, label = _interpret_aggregate(mape_mean=8.0, coverage_80_mean=0.95)
        # Falls into acceptable band: MAPE<20 and coverage in [0.60, 0.95]
        assert tag == "acceptable"

    def test_poor_coverage_too_high_acceptable_threshold(self):
        """Coverage above 0.95 fails both bands."""
        tag, label = _interpret_aggregate(mape_mean=8.0, coverage_80_mean=0.99)
        assert tag == "poor"


# ---------------------------------------------------------------------------
# Unit tests: run_backtest routing (no MCMC)
# ---------------------------------------------------------------------------


class TestRunBacktestRouting:
    def test_insufficient_data_skipped(self):
        """N=20 weeks → skipped, insufficient_data."""
        X, y, cols = _make_X_y(n_weeks=20)
        result = run_backtest(X, y, cols, n_folds=3, horizon=4)
        assert isinstance(result, BacktestResult)
        assert result.mode == "skipped"
        assert result.status == "insufficient_data"
        assert result.n_folds == 0
        assert result.note is not None
        assert "30" in result.note  # mentions the threshold

    def test_exactly_at_skip_boundary(self):
        """N=29 weeks is still below threshold → skipped."""
        X, y, cols = _make_X_y(n_weeks=29)
        result = run_backtest(X, y, cols, n_folds=3, horizon=4)
        assert result.mode == "skipped"

    def test_at_30_weeks_triggers_single_holdout(self):
        """N=30 weeks >= 30 but < 38 required → should hit single_holdout path.
        We don't run MCMC here; instead, we verify the routing decision by
        patching fit_model and build_model.
        """
        from unittest.mock import MagicMock, patch

        X, y, cols = _make_X_y(n_weeks=30)

        # Mock the fitted MMM so no actual sampling happens
        mock_mmm = MagicMock()
        import xarray as xr

        # Build a fake posterior predictive DataArray with the right shape
        # combined=False → dims (chain, draw, date); n_combined = 30+4 = 34
        n_combined = 34
        fake_data = xr.DataArray(
            np.ones((2, 200, n_combined)) * 50_000.0,
            dims=["chain", "draw", "date"],
        )
        fake_dataset = xr.Dataset({"y": fake_data})
        mock_mmm.sample_posterior_predictive.return_value = fake_dataset

        with (
            patch("mixlift.modeling.backtest.build_model", return_value=mock_mmm),
            patch("mixlift.modeling.backtest.fit_model", return_value=(mock_mmm, "")),
        ):
            result = run_backtest(X, y, cols, n_folds=3, horizon=4)

        assert result.mode == "single_holdout"
        assert result.n_folds == 1
        assert result.status == "success"

    def test_walk_forward_routing_mocked(self):
        """N=52 weeks → walk_forward with 3 folds (mocked MCMC)."""
        from unittest.mock import MagicMock, patch

        import xarray as xr

        X, y, cols = _make_X_y(n_weeks=52)

        mock_mmm = MagicMock()

        def make_pp(X_combined, **kwargs):
            n = len(X_combined)
            fake_data = xr.DataArray(
                np.ones((2, 200, n)) * 60_000.0,
                dims=["chain", "draw", "date"],
            )
            return xr.Dataset({"y": fake_data})

        mock_mmm.sample_posterior_predictive.side_effect = make_pp

        with (
            patch("mixlift.modeling.backtest.build_model", return_value=mock_mmm),
            patch("mixlift.modeling.backtest.fit_model", return_value=(mock_mmm, "")),
        ):
            result = run_backtest(X, y, cols, n_folds=3, horizon=4)

        assert result.mode == "walk_forward"
        assert result.n_folds == 3
        assert result.status == "success"
        assert len(result.folds) == 3
        assert result.aggregate["mape_mean"] is not None


# ---------------------------------------------------------------------------
# Slow integration tests (real MCMC)
# ---------------------------------------------------------------------------


@pytest.mark.slow
def test_backtest_synthetic_linear_trend_sanity():
    """Full walk-forward backtest on 52 weeks of synthetic linear-trend data.

    Uses real MCMC with FAST_BACKTEST_CONFIG (2 chains, 300 tune, 200 draws).
    Asserts MAPE < 25 as a smoke-test that the pipeline produces reasonable
    OOS predictions.  Wall time: roughly 5-10 minutes.
    """
    X, y, channel_columns = _make_X_y(n_weeks=52, seed=7)

    result = run_backtest(
        X,
        y,
        channel_columns,
        n_folds=3,
        horizon=4,
    )

    assert result.status == "success", f"Backtest failed: {result.note}"
    assert result.mode == "walk_forward"
    assert result.n_folds == 3
    assert len(result.folds) == 3

    # Each fold should have the right number of weekly predictions
    for fold in result.folds:
        assert len(fold["weekly_actual"]) == 4
        assert len(fold["weekly_predicted_mean"]) == 4
        assert len(fold["weekly_predicted_low"]) == 4
        assert len(fold["weekly_predicted_high"]) == 4
        assert fold["mape"] >= 0
        assert 0.0 <= fold["coverage_80"] <= 1.0

    # Aggregate smoke-test: MAPE should be reasonable for a simple linear trend
    assert result.aggregate["mape_mean"] < 25, (
        f"MAPE too high for linear trend data: {result.aggregate['mape_mean']:.1f}%"
    )
    assert result.compute_secs > 0


@pytest.mark.slow
def test_backtest_single_holdout_fallback():
    """N=32 weeks falls back to single_holdout mode (real MCMC)."""
    X, y, channel_columns = _make_X_y(n_weeks=32, seed=13)

    result = run_backtest(
        X,
        y,
        channel_columns,
        n_folds=3,
        horizon=4,
    )

    assert result.status == "success"
    assert result.mode == "single_holdout"
    assert result.n_folds == 1
    assert len(result.folds) == 1

    fold = result.folds[0]
    assert len(fold["weekly_actual"]) == 4
    assert fold["mape"] >= 0
