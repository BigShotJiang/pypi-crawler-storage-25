"""DS Phase 1: ESS diagnostics and ROAS plausibility check tests."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np

from mixlift.modeling.engine import check_convergence, check_roas_plausibility

# ---------------------------------------------------------------------------
# ROAS plausibility checks
# ---------------------------------------------------------------------------


class TestCheckRoasPlausibility:
    """Test ROAS plausibility validation."""

    def test_normal_roas_no_warnings(self):
        roas = {"Meta": 2.5, "Google": 3.2, "TikTok": 1.1}
        ci = {"Meta": (1.5, 3.5), "Google": (2.0, 4.4), "TikTok": (0.5, 1.7)}
        warnings = check_roas_plausibility(roas, ci)
        assert warnings == []

    def test_extremely_high_roas_flagged(self):
        roas = {"Meta": 25.0, "Google": 3.0}
        ci = {"Meta": (20.0, 30.0), "Google": (2.0, 4.0)}
        warnings = check_roas_plausibility(roas, ci)
        assert len(warnings) == 1
        assert "Meta" in warnings[0]
        assert "25.0x" in warnings[0]

    def test_negative_roas_flagged(self):
        roas = {"Meta": -0.5, "Google": 3.0}
        ci = {"Meta": (-1.0, 0.0), "Google": (2.0, 4.0)}
        warnings = check_roas_plausibility(roas, ci)
        assert len(warnings) == 1
        assert "negative" in warnings[0]

    def test_all_low_roas_flagged(self):
        roas = {"Meta": 0.3, "Google": 0.4, "TikTok": 0.2}
        ci = {
            "Meta": (0.1, 0.5),
            "Google": (0.2, 0.6),
            "TikTok": (0.0, 0.4),
        }
        warnings = check_roas_plausibility(roas, ci)
        assert any("below 0.5x" in w for w in warnings)

    def test_wide_ci_flagged(self):
        roas = {"Meta": 2.0}
        ci = {"Meta": (0.0, 50.0)}  # Width = 50, estimate = 2 → ratio = 25
        warnings = check_roas_plausibility(roas, ci)
        assert any("wide confidence interval" in w for w in warnings)

    def test_wide_ci_not_flagged_if_reasonable(self):
        roas = {"Meta": 2.0}
        ci = {"Meta": (1.0, 3.0)}  # Width = 2, estimate = 2 → ratio = 1
        warnings = check_roas_plausibility(roas, ci)
        assert warnings == []

    def test_empty_roas(self):
        warnings = check_roas_plausibility({}, {})
        assert warnings == []

    def test_multiple_issues(self):
        roas = {"Meta": 25.0, "Google": -0.5}
        ci = {"Meta": (20.0, 30.0), "Google": (-1.0, 0.0)}
        warnings = check_roas_plausibility(roas, ci)
        assert len(warnings) == 2


# ---------------------------------------------------------------------------
# ESS diagnostics (within check_convergence)
# ---------------------------------------------------------------------------


class TestEssDiagnostics:
    """Test that check_convergence includes ESS warnings."""

    def _make_mmm_with_ess(self, ess_values: dict, n_chains: int = 4):
        """Build a mock MMM with controllable ESS values."""
        mmm = MagicMock()

        # Mock idata.posterior
        posterior = MagicMock()
        posterior.sizes = {"chain": n_chains}
        mmm.idata.posterior = posterior

        # Mock sample_stats (no divergences)
        sample_stats = MagicMock()
        divergent = MagicMock()
        divergent.values = np.zeros((n_chains, 100))
        sample_stats.get.return_value = divergent
        mmm.idata.sample_stats = sample_stats

        return mmm

    def test_low_ess_warned(self):
        mmm = self._make_mmm_with_ess({"beta_channel": 50.0})

        # Mock az.rhat to return clean values
        rhat_mock = MagicMock()
        rhat_mock.data_vars = ["beta"]
        rhat_mock.__getitem__ = lambda self, k: MagicMock(values=np.array([1.01]))

        # Mock az.ess to return low values
        ess_mock = MagicMock()
        ess_mock.data_vars = ["beta_channel"]
        ess_mock.__getitem__ = lambda self, k: MagicMock(values=np.array([50.0]))

        with (
            patch("mixlift.modeling.engine.az.rhat", return_value=rhat_mock),
            patch("mixlift.modeling.engine.az.ess", return_value=ess_mock),
        ):
            warnings = check_convergence(mmm)

        assert any("effective sample size" in w.lower() for w in warnings)

    def test_adequate_ess_no_warning(self):
        mmm = self._make_mmm_with_ess({"beta_channel": 500.0})

        rhat_mock = MagicMock()
        rhat_mock.data_vars = ["beta"]
        rhat_mock.__getitem__ = lambda self, k: MagicMock(values=np.array([1.01]))

        ess_mock = MagicMock()
        ess_mock.data_vars = ["beta_channel"]
        ess_mock.__getitem__ = lambda self, k: MagicMock(values=np.array([500.0]))

        with (
            patch("mixlift.modeling.engine.az.rhat", return_value=rhat_mock),
            patch("mixlift.modeling.engine.az.ess", return_value=ess_mock),
        ):
            warnings = check_convergence(mmm)

        assert not any("effective sample size" in w.lower() for w in warnings)
