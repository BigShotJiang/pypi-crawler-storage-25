"""remitmd framework integrations."""
