import base64
import json
import logging
import os
import random
import time
from hashlib import sha1
from typing import Any, Dict, List, MutableMapping, Optional

import requests
import urllib3

logger = logging.getLogger(__name__)


class LogicVeinAPIClient:
    """A class containing methods to interact with the LogicVein API.

    This class provides methods for authentication, creating devices, retrieving devices,
    and deleting devices from the LogicVein API.
    """

    # =====================================================
    # Core / Authentication
    # =====================================================

    def __init__(self, **kwargs) -> None:
        """Initialize the LogicVeinClient class with the provided configuration.

        Kwargs take precedence over environment variables when provided.

        Args:
            host (str): The LogicVein server hostname or IP address.
            username (str): The username to authenticate with.
            password (str): The password to authenticate with.
            api_token (str): The API token to authenticate with.
            verify (bool): Whether to verify the SSL certificate.
        """
        self._id = 0
        self._hasher = sha1()
        # If ignore_env_vars is True, ONLY use kwargs values (no env var fallback)
        ignore_env = kwargs.get("ignore_env_vars", False)

        if ignore_env:
            # Use kwargs values directly, no env var fallback
            self.host = kwargs.get("host", "localhost")
            self.username = kwargs.get("username", "")
            self.password = kwargs.get("password", "")
            self.api_token = kwargs.get("api_token", "")
            self.verify_ssl = bool(kwargs.get("verify", False))
            self.timeout = int(kwargs.get("timeout", 120))
        else:
            # Fall back to env vars if kwargs not provided or empty
            self.host = kwargs.get("host") or os.getenv("LVI_HOST", "localhost")
            self.username = kwargs.get("username") or os.getenv("LVI_USERNAME", "")
            self.password = kwargs.get("password") or os.getenv("LVI_PASSWORD", "")
            self.api_token = kwargs.get("api_token") or os.getenv("LVI_API_TOKEN", "")
            if "verify" in kwargs:
                self.verify_ssl = bool(kwargs.get("verify"))
            else:
                self.verify_ssl = os.getenv("LVI_VERIFY_SSL", "false").lower() == "true"
            self.timeout = int(kwargs.get("timeout") or os.getenv("LVI_TIMEOUT", "120"))

        if not self.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        logger.debug(
            f"LogicVeinAPIClient initialized: host={self.host}, username={self.username}, using_token={bool(self.api_token)}, ignore_env={ignore_env}"
        )
        self.base_url = f"https://{self.host}/rest"
        self.headers: MutableMapping[str, str | bytes] = {"Content-Type": "application/json"}
        if self.api_token:
            self.headers["Authorization"] = f"Bearer {self.api_token}"
        self.lvi_client = requests.Session()
        self.lvi_client.headers = self.headers
        self.lvi_client.verify = self.verify_ssl

        # Authenticate if using username/password (no API token)
        if not self.api_token and self.username and self.password:
            self.authenticate()

    def authenticate(
        self, username: Optional[str] = None, password: Optional[str] = None, **kwargs
    ) -> Optional[requests.Response]:
        """Authenticate with the LogicVein server with username and password.

        Args:
            username (str, optional): The username to authenticate with. If None, uses the instance username.
            password (str, optional): The password to authenticate with. If None, uses the instance password.
            **kwargs: Additional keyword arguments to pass to the requests.get() method.

        Returns:
            None if the authentication was successful, otherwise an error message.
        """
        if username is None:
            username = self.username
        if password is None:
            password = self.password
        if not username or not password:
            logger.error("Username and password are required for authentication.")
            raise ValueError("Username and password are required for authentication.")

        params = {
            "j_username": self.username,
            "j_password": self.password,
        }

        try:
            response = self.lvi_client.get(
                f"https://{self.host}/jsonrpc", params=params, timeout=self.timeout, **kwargs
            )
            response.raise_for_status()
        except requests.HTTPError as e:
            logger.error(f"Failed to authenticate with LogicVein: {e}")
            response = None
        except requests.exceptions.ConnectTimeout as e:
            logger.error(f"Connection timeout. Failed to authenticate with LogicVein: {e}")
            response = None

        return response

    def test_connection(self) -> bool:
        """Test the connection to the LogicVein server.

        Returns:
            bool: True if connection is successful, False otherwise.
        """
        try:
            # Try to get networks as a simple test
            networks = self.get_networks()
            # If we get a response (even empty list), connection works
            return networks is not None
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False

    def _next_id(self):
        """Generate the next request ID."""
        self._id += 1
        self._hasher.update(str(self._id).encode("utf-8"))
        self._hasher.update(time.ctime().encode("utf-8"))
        self._hasher.update(str(random.random).encode("utf-8"))

        return self._hasher.hexdigest()

    def call(self, method, _params=None, **kwargs):
        """Call a JSON-RPC method.

        Args:
            method (str): The method to call.
            _params: If provided, used directly as the JSON-RPC params value (list or dict).
                     Use this for APIs that require array params instead of a named dict.
            **kwargs: Named parameters passed as a dict when _params is not provided.

        Returns:
            The response from the JSON-RPC method.
        """
        payload = {
            "jsonrpc": "2.0",
            "id": self._next_id(),
            "method": method,
            "params": _params if _params is not None else kwargs,
        }
        response = self.lvi_client.post(self.base_url, data=json.dumps(payload), timeout=self.timeout)
        if not response.ok:
            logger.error(
                "LVI API error %s for method %s: %s",
                response.status_code,
                method,
                response.text[:500],
            )
        response.raise_for_status()

        try:
            results = response.json() if response else {}
        except ValueError:
            results = response.text if response else {}

        return results

    # =====================================================
    # Networks
    # =====================================================

    def get_networks(self, **kwargs) -> List[Any]:
        """Retrieve the network names from the LogicVein server.

        Returns:
            The network names if they exist, otherwise an empty list.
        """
        response = self.call("Networks.getManagedNetworkNames", **kwargs)

        if response and type(response) is dict and "result" in response:
            networks = response["result"]
        else:
            networks = []

        return networks

    # =====================================================
    # Inventory / Devices
    # =====================================================

    def search_devices_in_network(self, **kwargs) -> List[Any]:
        """Search for devices in one or more networks on the LogicVein server.

        Paginates automatically and returns all matching devices.

        Accepted keyword arguments:
            network (list): A list of the network(s). If empty, all networks are searched.
            query (str): A search query to filter devices. If empty, all devices are returned.
            page_size (int): Records per API call (default 500). Does not cap total results.
            sort_column (str): The column to sort the devices by.
            descending (bool): Whether to sort the devices in descending order.

        Returns:
            All matching devices, or an empty list.
        """
        network = kwargs.get("network", [])
        query = kwargs.get("query", "")
        page_size = kwargs.get("page_size", 500)
        sort_column = kwargs.get("sort_column", "ipAddress")
        descending = kwargs.get("descending", False)

        all_devices: List[Any] = []
        offset = 0

        while True:
            params = {
                "network": network,
                "query": query,
                "scheme": "tag",
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                },
                "sortColumn": sort_column,
                "descending": descending,
            }
            response = self.call("Inventory.search", **params)

            if response and type(response) is dict and "result" in response and "devices" in response["result"]:
                batch = response["result"]["devices"]
            else:
                break

            all_devices.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_devices

    def get_device_by_ip(self, ip_address: str, network: str = "Default") -> Optional[Dict[str, Any]]:
        """Retrieve a device from the LogicVein server.

        Args:
            ip_address (str): The IP address of the device to retrieve.
            network (str): The name of the network.

        Returns:
            The device dict if it exists, otherwise None.
        """
        response = self.call("Inventory.getDevice", network=network, ipAddress=ip_address)

        if response and type(response) is dict and "result" in response:
            device = response["result"]
        else:
            device = None

        return device

    def create_device(self, ip_address: str, adapter_id: str, network: str = "Default") -> Optional[Any]:
        """Create a device in the LogicVein server.

        Args:
            ip_address (str): The IP address of the device.
            adapter_id (str): The adapter ID of the device.
            network (str): The name of the network.

        Returns:
            None if the device was created successfully, otherwise an error message.
        """
        response = self.call("Inventory.createDevice", network=network, ipAddress=ip_address, adapterId=adapter_id)

        return response

    def delete_device(self, ip_address: str, network: str = "Default") -> Optional[Any]:
        """Delete a device from the LogicVein server.

        Args:
            network (str): The name of the network.
            ip_address (str): The IP address of the device to delete.

        Returns:
            None if the device was deleted successfully, otherwise an error message.
        """
        response = self.call("Inventory.deleteDevice", network=network, ipAddress=ip_address)

        return response

    def update_device(
        self,
        ip_address: str,
        network: str = "Default",
        hostname: Optional[str] = None,
        adapter_id: Optional[str] = None,
        custom_fields: Optional[Dict[str, str]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update a device in the LogicVein server.

        Args:
            ip_address (str): The IP address of the device to update.
            network (str): The name of the network. "Default" if not specified.
            hostname (str, optional): The new hostname for the device.
            adapter_id (str, optional): The new adapter ID for the device.
            custom_fields (dict, optional): Custom fields to update on the device.

        Returns:
            Dict[str, Any]: The updated device if successful, otherwise None.
        """
        device = self.get_device_by_ip(ip_address, network)
        if not device:
            logger.error(f"Device {ip_address} not found in network {network}")
            return None

        if hostname is not None:
            device["hostname"] = hostname
        if adapter_id is not None:
            device["adapterId"] = adapter_id
        if custom_fields is not None:
            for key, value in custom_fields.items():
                device[key] = value

        response = self.call("Inventory.updateDevice", device=device)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def update_devices(self, devices: List[Dict[str, Any]]) -> bool:
        """Update multiple devices in the LogicVein server.

        Args:
            devices (List[Dict[str, Any]]): A list of device dictionaries to update.

        Returns:
            bool: True if the devices were updated successfully, otherwise False.
        """
        response = self.call("Inventory.updateDevices", devices=devices)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def update_device_values(
        self,
        ip_address: str,
        network: str = "Default",
        adapter_id: Optional[str] = None,
        add_traits: Optional[List[str]] = None,
        remove_traits: Optional[List[str]] = None,
        identified_by_hostname: Optional[bool] = None,
    ) -> bool:
        """Update device values including adapter, traits, and identification settings.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network (default: "Default").
            adapter_id (str, optional): The adapter ID to set (e.g., "Cisco::IOS", "4RF::AprisaSR").
            add_traits (List[str], optional): List of traits to add. Valid traits:
                ap, aruba-ap, icmp, snmp, ssh, http, telnet, firewall, ncm, dhcp, agent-d, https
            remove_traits (List[str], optional): List of traits to remove.
            identified_by_hostname (bool, optional): Whether the device is identified by hostname.

        Returns:
            bool: True if the device values were updated successfully, otherwise False.
        """
        update_request: Dict[str, Any] = {}

        if adapter_id is not None:
            update_request["adapterId"] = adapter_id
        if add_traits is not None:
            update_request["addTraits"] = add_traits
        if remove_traits is not None:
            update_request["removeTraits"] = remove_traits
        if identified_by_hostname is not None:
            update_request["identifiedByHostname"] = identified_by_hostname

        response = self.call(
            "Inventory.updateDeviceValues",
            ipAddress=ip_address,
            network=network,
            updateRequest=update_request,
        )

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def update_custom_fields(
        self, ip_address: str, network: str = "Default", custom_fields: Dict[str, str] = {}
    ) -> bool:
        """Update custom fields for a device.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.
            custom_fields (Dict[str, str]): Custom fields to update (custom1-custom5).

        Returns:
            bool: True if the custom fields were updated successfully, otherwise False.
        """
        params = {
            "network": network,
            "ipAddress": ip_address,
            **custom_fields,
        }
        response = self.call("Inventory.updateCustomFields", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def update_device_hardware(
        self,
        ip_address: str,
        network: str = "Default",
        serial_number: Optional[str] = None,
        make: Optional[str] = None,
        model: Optional[str] = None,
        os_version: Optional[str] = None,
    ) -> bool:
        """Update hardware information for a device.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.
            serial_number (str, optional): The serial number to set.
            make (str, optional): The make/vendor to set.
            model (str, optional): The model to set.
            os_version (str, optional): The OS version to set.

        Returns:
            bool: True if the hardware was updated successfully, otherwise False.
        """
        params = {"network": network, "ipAddress": ip_address}
        if serial_number is not None:
            params["serialNumber"] = serial_number
        if make is not None:
            params["make"] = make
        if model is not None:
            params["model"] = model
        if os_version is not None:
            params["osVersion"] = os_version

        response = self.call("Inventory.updateDeviceHardware", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def update_end_of_dates(
        self,
        ip_address: str,
        network: str = "Default",
        end_of_sale: Optional[int] = None,
        end_of_sw_maintenance: Optional[int] = None,
        end_of_security_vul_support: Optional[int] = None,
        end_of_life: Optional[int] = None,
        end_of_service_contract_renewal: Optional[int] = None,
    ) -> bool:
        """Update end-of-life dates for a device.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.
            end_of_sale (int, optional): End of sale date (epoch timestamp).
            end_of_sw_maintenance (int, optional): End of SW maintenance date.
            end_of_security_vul_support (int, optional): End of security vulnerability support date.
            end_of_life (int, optional): End of life date.
            end_of_service_contract_renewal (int, optional): End of service contract renewal date.

        Returns:
            bool: True if the dates were updated successfully, otherwise False.
        """
        params: Dict[str, Any] = {"network": network, "ipAddress": ip_address}
        if end_of_sale is not None:
            params["endOfSale"] = end_of_sale
        if end_of_sw_maintenance is not None:
            params["endOfSwMaintenance"] = end_of_sw_maintenance
        if end_of_security_vul_support is not None:
            params["endOfSecurityVulSupport"] = end_of_security_vul_support
        if end_of_life is not None:
            params["endOfLife"] = end_of_life
        if end_of_service_contract_renewal is not None:
            params["endOfServiceContractRenewal"] = end_of_service_contract_renewal

        response = self.call("Inventory.updateEndOfDates", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    # =====================================================
    # Device Groups
    # =====================================================

    def get_all_groups(self, networks: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Retrieve all device groups for one or more networks.

        Args:
            networks (List[str]): List of network names to query. Defaults to ["Default"].

        Returns:
            List of device group dicts, each containing:
                "deviceGroupId" (str): UUID of the group.
                "name" (str): Display name of the group.
                "filter" (dict): Filter definition for the group.
                "parent" (str or None): Parent group ID, or None if top-level.
                "owner" (str): Username of the group owner.
                "shared" (bool): Whether the group is shared.
                "networkDeviceCounts" (dict): Device count per network.
            Returns an empty list on failure.
        """
        if networks is None:
            networks = ["Default"]

        response = self.call("DeviceGroup.getAllGroups", network=networks)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    # =====================================================
    # Adapters
    # =====================================================

    def get_available_adapters(self) -> List[Dict[str, Any]]:
        """Get all device adapters available on the LogicVein server.

        Returns:
            List of adapter dicts, each containing:
                "adapterId" (str): Adapter identifier (e.g. "Cisco::IOS").
                "shortName" (str): Display name (e.g. "Cisco IOS").
                "description" (str): Full description.
                "restoreValidationRegex" (str | None): Regex to validate restore files.
                "preferredPathsRegex" (str | None): Regex for preferred config paths.
                "contextCommands" (bool): Whether the adapter supports context commands.
                "jumphostSupported" (bool): Whether jumphost is supported.
                "makeIsSoftware" (bool): Whether the adapter is software-based.
                "managementLink" (str | None): Management URL template (may contain
                                               {device.host} placeholder).
            Returns an empty list if no data is found.
        """
        response = self.call("Adapters.getAvailableAdapters")

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    # =====================================================
    # Configuration
    # =====================================================

    def get_adapters_with_config_paths(self, networks: List[str] = []) -> List[Dict[str, Any]]:
        """Get adapters and their available configuration paths for one or more networks.

        Args:
            networks (List[str]): Network names to query. If empty, all networks are searched.

        Returns:
            List of dicts with keys:
                "adapterId" (str): Adapter identifier (e.g. "Cisco::IOS").
                "configurations" (list[str]): Config paths available for this adapter
                                              (e.g. ["/running-config", "/startup-config"]).
            Returns an empty list if no data is found.
        """
        if not networks:
            networks = self.get_networks()

        response = self.call("Configuration.getAdaptersWithConfigPaths", networks=networks)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def get_device_configuration_change_logs(
        self, ip_address: str, network: str = "Default", page_size: int = 500
    ) -> List[Dict[str, Any]]:
        """Retrieve all configuration change logs for a device from the LogicVein server.

        Paginates automatically and returns all entries.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.
            page_size (int): Records per API call (default 500). Does not cap total results.

        Returns:
            All change log entries, or an empty list.
        """
        if not ip_address:
            return []

        all_logs: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "network": network,
                "ipAddress": ip_address,
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                },
            }
            response = self.call("Configuration.retrieveSnapshotChangeLog", **params)

            if response and type(response) is dict and "result" in response and "changeLogs" in response["result"]:
                batch = response["result"]["changeLogs"]
            else:
                break

            all_logs.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_logs

    def get_device_configuration_revision(
        self,
        ip_address: str,
        network: str = "Default",
        config_path: str = "/running-config",
        timestamp: Optional[int] = None,
    ) -> str:
        """Get a specific configuration file revision of a device from the LogicVein server.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.
            config_path (str): The configuration path of the device.
            timestamp (int): The timestamp of the configuration revision. If None, the latest revision is retrieved.

        Returns:
            The configuration revision if it exists, otherwise an empty string.
        """
        if not ip_address:
            return ""

        params = {
            "network": network,
            "ipAddress": ip_address,
            "configPath": config_path,
            "timestamp": timestamp,
        }
        response = self.call("Configuration.retrieveRevision", **params)

        if (
            response
            and type(response) is dict
            and "result" in response
            and response["result"]
            and type(response["result"]) is dict
            and "content" in response["result"]
        ):
            config_revision_bytes = base64.b64decode(response["result"]["content"])
            config_revision = config_revision_bytes.decode("utf-8")
        else:
            config_revision = ""

        return config_revision

    def get_config_history(
        self,
        networks: Optional[List[str]] = None,
        data: str = "",
        descending: bool = True,
        scheme: str = "",
        sort_column: str = "session",
        page_size: int = 100,
    ) -> List[Dict[str, Any]]:
        """Retrieve configuration history entries from the LogicVein server.

        Paginates automatically and returns all entries.

        Args:
            networks (list): List of network names to query. Defaults to ["Default"].
            data (str): Filter string applied to the search (empty means no filter).
            descending (bool): Sort in descending order when True (default True).
            scheme (str): Configuration scheme filter (empty means no filter).
            sort_column (str): Column to sort results by (default "session").
            page_size (int): Records per API call (default 100). Does not cap total results.

        Returns:
            All config history items, or an empty list.
        """
        if networks is None:
            networks = ["Default"]

        all_items: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "data": data,
                "descending": descending,
                "networks": networks,
                "pageData": {
                    "configHistoryItems": [],
                    "offset": offset,
                    "pageSize": page_size,
                    "total": 0,
                },
                "scheme": scheme,
                "sortColumn": sort_column,
            }
            response = self.call("Configuration.retrieveConfigHistory", **params)

            if (
                response
                and type(response) is dict
                and "result" in response
                and type(response["result"]) is dict
                and "configHistoryItems" in response["result"]
            ):
                batch = response["result"]["configHistoryItems"]
            else:
                break

            all_items.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_items

    # =====================================================
    # Interfaces
    # =====================================================

    def get_device_interfaces(self, ip_address: str, network: str = "Default") -> List[Dict[str, Any]]:
        """Retrieve the interfaces for a device from the LogicVein server.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.

        Returns:
            The device interfaces if they exist, otherwise an empty list.
        """
        response = self.call("Inventory.getDeviceInterfaces", network=network, ipAddress=ip_address)

        if response and type(response) is dict and "result" in response:
            interfaces = response["result"]
        else:
            interfaces = []

        return interfaces

    def get_device_vlan_port_mappings(self, ip_address: str, network: str = "Default") -> List[Dict[str, Any]]:
        """Retrieve the VLAN port mappings for a device from the LogicVein server.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.

        Returns:
            The VLAN port mappings if they exist, otherwise an empty list.
        """
        response = self.call("Inventory.getDeviceVlanPortMappings", ipAddress=ip_address, network=network)

        if response and type(response) is dict and "result" in response:
            vlan_port_mappings = response["result"]
        else:
            vlan_port_mappings = []

        return vlan_port_mappings

    def search_device_interfaces(
        self,
        network: str = "Default",
        page_size: int = 500,
        sort_column: str = "ipAddress",
        descending: bool = False,
    ) -> List[Dict[str, Any]]:
        """Search for device interfaces on the LogicVein server.

        Paginates automatically and returns all matching interfaces.

        Args:
            network (str): The name of the network.
            page_size (int): Records per API call (default 500). Does not cap total results.
            sort_column (str): The column to sort the interfaces by.
            descending (bool): Whether to sort the interfaces in descending order.

        Returns:
            All matching interfaces, or an empty list.
        """
        queries = ['managedNetwork="' + network + '"']
        all_interfaces: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "descending": descending,
                "pageData": {
                    "interfaces": [],
                    "offset": offset,
                    "pageSize": page_size,
                    "total": 0,
                },
                "queries": queries,
                "sortColumn": sort_column,
            }
            response = self.call("Inventory.searchDeviceInterfaces", **params)

            if response and type(response) is dict and "result" in response and "interfaces" in response["result"]:
                batch = response["result"]["interfaces"]
            else:
                break

            all_interfaces.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_interfaces

    def get_device_hardware(self, ip_address: str, network: str = "Default") -> List[Dict[str, Any]]:
        """Retrieve the hardware information for a device from the LogicVein server.

        Accepted keyword arguments:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.

        Returns:
            List[Dict[str, Any]]: The hardware information if it exists, otherwise an empty list.
        """
        response = self.call("Inventory.getDeviceHardware", network=network, ipAddress=ip_address)

        if response and type(response) is dict and "result" in response:
            hardware = response["result"]
        else:
            hardware = []

        return hardware

    # =====================================================
    # Telemetry (ARP, MAC, Neighbors)
    # =====================================================

    def get_device_arp_table(
        self, ip_address: str, network: str = "Default", page_size: int = 500
    ) -> List[Dict[str, Any]]:
        """Retrieve all ARP table entries for a device from the LogicVein server.

        Paginates automatically and returns all entries.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.
            page_size (int): Records per API call (default 500). Does not cap total results.

        Returns:
            All ARP table entries, or an empty list.
        """
        all_entries: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                    "total": 0,
                },
                "managedNetwork": network,
                "sort": "ipAddress",
                "descending": False,
                "ipAddress": ip_address,
            }
            response = self.call("Telemetry.getArpTable", **params)

            if response and type(response) is dict and "result" in response and "arpEntries" in response["result"]:
                batch = response["result"]["arpEntries"]
            else:
                break

            all_entries.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_entries

    def get_arp_entries(
        self, network_address: str, networks: List[str] = [], page_size: int = 500
    ) -> List[Dict[str, Any]]:
        """Retrieve all ARP entries for a network address from the LogicVein server.

        Paginates automatically and returns all matching entries.

        Args:
            network_address (str): The network address to search for, in CIDR notation.
            networks (List[str]): A list of the network(s). If empty, all networks are searched.
            page_size (int): Records per API call (default 500). Does not cap total results.

        Returns:
            All matching ARP entries, or an empty list.
        """
        if not networks:
            networks = self.get_networks()

        if not networks or not isinstance(networks, list):
            return []

        all_entries: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                    "total": 0,
                },
                "networkAddress": network_address,
                "networks": networks,
                "sort": "ipAddress",
                "descending": False,
            }
            response = self.call("Telemetry.getArpEntries", **params)

            if response and type(response) is dict and "result" in response and "arpEntries" in response["result"]:
                batch = response["result"]["arpEntries"]
            else:
                break

            all_entries.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_entries

    def get_device_mac_table(
        self, ip_address: str, network: str = "Default", page_size: int = 500
    ) -> List[Dict[str, Any]]:
        """Retrieve all MAC table entries for a device from the LogicVein server.

        Paginates automatically and returns all entries.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.
            page_size (int): Records per API call (default 500). Does not cap total results.

        Returns:
            All MAC table entries, or an empty list.
        """
        all_entries: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                    "total": 0,
                },
                "managedNetwork": network,
                "sort": "macAddress",
                "descending": False,
                "ipAddress": ip_address,
            }
            response = self.call("Telemetry.getMacTable", **params)

            if response and type(response) is dict and "result" in response and "macEntries" in response["result"]:
                batch = response["result"]["macEntries"]
            else:
                break

            all_entries.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_entries

    def get_device_neighbors(self, ip_address: str, network: str = "Default") -> List[Dict[str, Any]]:
        """Retrieve the neighbors for a device from the LogicVein server.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.

        Returns:
            List[Dict[str, Any]]: The device neighbors if they exist, otherwise an empty list.
        """
        params = {"managedNetwork": network, "ipAddress": ip_address}
        response = self.call("Telemetry.getNeighbors", **params)

        if response and type(response) is dict and "result" in response:
            neighbors = response["result"]
        else:
            neighbors = []

        return neighbors

    def find_switch_port_for_host(self, host_ip: str, networks: List[str] = []) -> Optional[Dict[str, Any]]:
        """Find the switch port a host is connected to from the LogicVein server.

        Args:
            host_ip (str): The IP address of the host.
            networks (List[str], optional): A list of the network(s). If empty, all networks are searched.

        Returns:
            Dict[str, Any]: The switch port information if found, including hostIpAddress, hostMacAddress,
                           arpEntry, macEntry, and error fields. Returns None if not found.
        """
        if not networks:
            networks = self.get_networks()

        if networks and type(networks) is list:
            response = self.call("Telemetry.findSwitchPort", host=host_ip, networks=networks)
            if response and type(response) is dict and "result" in response:
                return response["result"]

        return None

    # =====================================================
    # Compliance (Rule Sets, Policies, Violations)
    # =====================================================

    def get_all_rule_sets(self, networks: List[str] = []) -> List[Dict[str, Any]]:
        """Retrieve all rule sets for one or more networks from the LogicVein server.

        Args:
            networks (List[str], optional): A list of the network(s). If empty, all networks are searched.

        Returns:
            List[Dict[str, Any]]: The rule sets if they exist, otherwise an empty list.
        """
        rule_sets = []

        if not networks:
            networks = self.get_networks()

        if networks and type(networks) is list:
            response = self.call("Compliance.getRuleSets", networks=networks)
            if response and type(response) is dict and "result" in response:
                rule_sets = response["result"]

        return rule_sets

    def get_rule_set(self, rule_set_id: int) -> Dict[str, Any]:
        """Retrieve a rule set from the LogicVein server.

        Args:
            rule_set_id (str): The ID of the rule set to retrieve.

        Returns:
            The rule set if it exists, otherwise an empty dictionary.
        """
        response = self.call("Compliance.getRuleSet", ruleSetId=rule_set_id)

        if response and type(response) is dict and "result" in response:
            rule_set = response["result"]
        else:
            rule_set = {}

        return rule_set

    def create_rule_set(
        self,
        rule_set_name: str,
        adapter_id: str,
        rule_set_xml: str = "",
        config_path: str = "/running-config",
        remediation_job_id: Optional[str] = None,
        category_id: Optional[str] = None,
        networks: Optional[List[str]] = None,
        read_only: bool = False,
        ootb: bool = False,
    ) -> bool:
        """Create a rule set in the LogicVein server.

        Args:
            rule_set_name (str): The name of the rule set to create.
            adapter_id (str): The adapter ID for the rule set. (e.g., Cisco::IOS)
            rule_set_xml (str): The XML content of the rule set. Defaults to a minimal valid skeleton if not provided.
            config_path (str): The configuration path for the rule set. (default: /running-config)
            remediation_job_id (str): The remediation job ID associated with the rule set. Pass None if unset.
            category_id (str): The category ID for the rule set. Pass None if unset.
            networks (List[str]): A list of the network(s) to associate with the rule set. Defaults to ["*"] (all networks).
            read_only (bool): Whether the rule set is read-only.
            ootb (bool): Whether the rule set is out-of-the-box.

        Returns:
            True if the rule set was created successfully, otherwise False.
        """
        if not rule_set_xml:
            rule_set_xml = f'<?xml version="1.0" encoding="UTF-8"?><RuleSet name="{rule_set_name}"></RuleSet>'

        rule_set = {
            "ruleSetName": rule_set_name,
            "adapterId": adapter_id,
            "configPath": config_path,
            "ruleSetXml": rule_set_xml,
            "remediationJobId": remediation_job_id or None,
            "categoryId": category_id or None,
            "networks": networks if networks is not None else ["*"],
            "readOnly": read_only,
            "ootb": ootb,
        }
        response = self.call("Compliance.saveRuleSet", ruleSet=rule_set)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def delete_rule_set(self, rule_set_id: int) -> bool:
        """Delete a rule set from the LogicVein server.

        Args:
            rule_set_id (int): The ID of the rule set to delete.

        Returns:
            True if the rule set was deleted successfully, otherwise False.
        """
        response = self.call("Compliance.deleteRuleSets", ruleSetIds=[rule_set_id])

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            result = True
        else:
            result = False

        return result

    def get_all_policies(self, network: str = "Default") -> List[Dict[str, Any]]:
        """Retrieve all policies for a network from the LogicVein server.

        Returns:
            List[Dict[str, Any]]: The policies if they exist, otherwise an empty list.
        """
        response = self.call("Compliance.getPolicies")

        if response and type(response) is dict and "result" in response:
            policies = response["result"]
        else:
            policies = []

        return policies

    def get_policy(self, policy_id: int) -> Dict[str, Any]:
        """Retrieve a policy from the LogicVein server.

        Args:
            policy_id (int): The ID of the policy to retrieve.

        Returns:
            The policy if it exists, otherwise an empty dictionary.
        """
        response = self.call("Compliance.getPolicy", policyId=policy_id)
        if response and type(response) is dict and "result" in response:
            policy = response["result"]
        else:
            policy = {}

        return policy

    def create_policy(
        self,
        policy_name: str,
        adapter_id: str,
        rule_set_mappings: List[Dict[str, Any]],
        config_path: str = "/running-config",
        network: str = "Default",
        resolution_data: str = "",
        resolution_scheme: str = "interfaceIpAddress",
        enabled: bool = False,
        policy_id: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """Create or update a policy in the LogicVein server.

        Args:
            policy_name (str): The name of the policy.
            adapter_id (str): The adapter ID for the policy.
            rule_set_mappings (List[Dict[str, Any]]): The rule set mappings for the policy.
            config_path (str): The configuration path for the policy.
            network (str): The name of the network.
            resolution_data (str): The resolution data for the policy.
            resolution_scheme (str): The resolution scheme for the policy.
            enabled (bool): Whether the policy is enabled.
            policy_id (int, optional): The policy ID for updates. Omit when creating.

        Returns:
            The saved policy dict if successful, otherwise None.
        """
        policy = {
            "policyName": policy_name,
            "adapterId": adapter_id,
            "configPath": config_path,
            "ruleSetMappings": rule_set_mappings,
            "network": network,
            "resolutionData": resolution_data,
            "resolutionScheme": resolution_scheme,
            "enabled": enabled,
        }
        if policy_id is not None:
            policy["policyId"] = policy_id

        response = self.call("Compliance.savePolicy", policy=policy)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def enable_policy(self, policy_id) -> bool:
        """Enable a policy in the LogicVein server.

        Accepted keyword arguments:
            policy_id (str): The ID of the policy to enable.

        Returns:
            bool: True if the policy was enabled successfully, otherwise False.
        """
        response = self.call("Compliance.setPoliciesEnablement", policyIds=[policy_id], enabled=True)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            result = True
        else:
            result = False

        return result

    def disable_policy(self, policy_id) -> bool:
        """Disable a policy in the LogicVein server.

        Accepted keyword arguments:
            policy_id (str): The ID of the policy to disable.

        Returns:
            bool: True if the policy was disabled successfully, otherwise False.
        """
        response = self.call("Compliance.setPoliciesEnablement", policyIds=[policy_id], enabled=False)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            result = True
        else:
            result = False

        return result

    def delete_policy(self, policy_id) -> bool:
        """Delete a policy from the LogicVein server.

        Accepted keyword arguments:
            policy_id (str): The ID of the policy to delete.

        Returns:
            bool: True if the policy was deleted successfully, otherwise False.
        """
        response = self.call("Compliance.deletePolicies", policyIds=[policy_id])

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            result = True
        else:
            result = False

        return result

    def get_rule_set_categories(self) -> List[Dict[str, Any]]:
        """Retrieve the rule set categories from the LogicVein server.

        Returns:
            List[Dict[str, Any]]: The rule set categories if they exist, otherwise an empty list.
        """
        response = self.call("Compliance.getRuleSetCategories")

        if response and type(response) is dict and "result" in response:
            catgories = response["result"]
        else:
            catgories = []

        return catgories

    def get_category_id_from_name(self, category_name: str) -> Optional[int]:
        """Get the category ID from a category name.

        Args:
            category_name (str): The category name.

        Returns:
            int: The category ID if found, otherwise None.
        """
        categories = self.get_rule_set_categories()

        for category in categories:
            if category["categoryName"] == category_name:
                return category["categoryId"]

        return None

    def create_rule_set_category(self, category_name: str, description: str = "") -> Optional[int]:
        """Create a rule set category in the LogicVein server.

        Args:
            category_name (str): The name of the category to create.
            description (str): The description of the category to create.

        Returns:
            int: The category ID if created, otherwise None.
        """
        response = self.call("Compliance.saveRuleSetCategories", categoryName=category_name, description=description)

        if (
            response
            and type(response) is dict
            and "result" in response
            and response["result"]
            and "categoryId" in response["result"][0]
        ):
            category_id = response["result"][0]["categoryId"]
        else:
            category_id = None

        return category_id

    def get_compliance_violations_for_device(self, ip_address: str, network: str = "Default") -> List[Dict[str, Any]]:
        """Get the compliance violations for a device by its IP address.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.

        Returns:
            List[Dict[str, Any]: The compliance violations if they exist, otherwise an empty list.
        """
        params = {"network": network, "ipAddress": ip_address}
        response = self.call("Compliance.getViolationsForDevice", **params)
        if response and type(response) is dict and "result" in response:
            violations = response["result"]
        else:
            violations = []

        return violations

    def get_compliance_violations_for_policy(self, policy_id: int) -> List[Dict[str, Any]]:
        """Get the compliance violations for a policy by its ID.
        Args:
            policy_id (int): The ID of the policy.

        Returns:
            List[Dict[str, Any]]: The compliance violations if they exist, otherwise an empty
        """
        params = {"policyId": policy_id}
        response = self.call("Compliance.getViolationsForPolicy", **params)
        if response and type(response) is dict and "result" in response:
            violations = response["result"]
        else:
            violations = []

        return violations

    def get_compliance_summary(self, networks: List[str] = []) -> Dict[str, Any]:
        """Get the compliance summary for one or more networks from the LogicVein server.

        Args:
            network (List[str]): The names of the networks. If empty, all networks are included.

        Returns:
            Dict[str, Any]: The compliance summary if it exists, otherwise an empty dictionary.
        """
        params = {"network": networks}
        response = self.call("Compliance.getComplianceSummary", **params)

        if response and type(response) is dict and "result" in response:
            summary = response["result"]
        else:
            summary = {}

        return summary

    def evaluate_compliance_rule_sets(
        self, rule_set_ids: List[int], ip_address: str, config_path: str = "/running-config", network: str = "Default"
    ) -> List[Dict[str, Any]]:
        """Evaluate compliance rule sets against a device configuration.

        Args:
            rule_set_ids (List[int]): A list of rule set IDs to evaluate.
            ip_address (str): The IP address of the device.
            config_path (str): The configuration path of the device. Defaults to "/running-config".
            network (str): The name of the network. Defaults to "Default".

        Returns:
            List[Dict[str, Any]]: The evaluation results if they exist, otherwise an empty list.
        """
        params = {
            "ruleSets": rule_set_ids,
            "configPath": config_path,
            "timestamp": None,
            "ipAddress": ip_address,
            "network": network,
            "isInteractiveMode": True,
        }
        response = self.call("Compliance.evaluateRuleSets", **params)

        if response and type(response) is dict and "result" in response:
            evaluation_results = response["result"]
        else:
            evaluation_results = []

        return evaluation_results

    def is_rule_set_name_unique(self, name: str, networks: List[str] = ["*"], rule_set_id: int = -1) -> bool:
        """Check if a rule set name is unique.

        Args:
            name (str): The rule set name to check.
            networks (List[str]): Networks to check against (default ["*"] for all).
            rule_set_id (int): ID of the rule set being edited (-1 for new rule sets).

        Returns:
            bool: True if the name is unique, otherwise False.
        """
        response = self.call(
            "Compliance.isRuleSetNameUnique",
            ruleSetName=name,
            networks=networks,
            ruleSetId=rule_set_id,
        )

        if response and type(response) is dict and "result" in response:
            return response["result"] is True
        return False

    def is_valid_regex(self, pattern: str) -> bool:
        """Validate a regex pattern for use in compliance rules.

        Args:
            pattern (str): The regex pattern to validate.

        Returns:
            bool: True if the pattern is valid, otherwise False.
        """
        result = self.call("Compliance.isValidRegex", _params=[pattern])

        if result and type(result) is dict and "result" in result:
            return result["result"] == ""
        return False

    def get_policies_for_rule_set(self, rule_set_id: int) -> List[Dict[str, Any]]:
        """Get policies that use a specific rule set.

        Args:
            rule_set_id (int): The ID of the rule set.

        Returns:
            List[Dict[str, Any]]: List of policies using the rule set.
        """
        response = self.call("Compliance.getPoliciesForRuleSet", ruleSetId=rule_set_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def save_incident(self, incident: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update an incident (status, priority, assignee, etc.).

        Calls Incidents.saveIncident. The response mirrors the input incident with the
        updated `modified` timestamp. Typically called with an existing incident object
        (from search_incidents) with fields edited as needed.

        The incident object has:
            {
                "incidentId": int - Incident ID,
                "isNew": bool - False for existing incidents,
                "network": str - Network name (e.g. "Default"),
                "policyId": int - Associated alert policy ID,
                "summary": str - Incident summary,
                "severity": str - "INFO", "WARNING", "ERROR", or "CRITICAL",
                "priority": str - "LOW", "MEDIUM", "HIGH", or "CRITICAL",
                "status": str - "OPEN", "WORKING", or "CLOSED",
                "resolution": str - "PENDING" or "RESOLVED",
                "assignee": str - Assigned username (empty string if unassigned),
                "labels": list[str] - Label tags,
                "emailFrequency": str - "minutely", "hourly", or "daily",
                "emailOnEdit": bool - Send email on edit,
                "emailTo": str - Email recipient (empty string if none),
                "clearState": str - "NOT_CLEARED" or "CLEARED",
                "created": int - Creation timestamp (ms),
                "modified": int - Last modified timestamp (ms),
                "resolved": int | null - Resolved timestamp (ms), or null,
                "nodes": int - Number of affected nodes,
                "triggers": int - Number of triggers,
                "occurrences": int - Number of occurrences,
                "traits": list[str] - Monitor trait tags (e.g. ["icmp"]),
                "clearedOccurrences": int - Count of cleared occurrences,
                "clearedTriggerIds": list - Cleared trigger IDs,
            }

        Args:
            incident (Dict[str, Any]): Incident object to save.

        Returns:
            Dict[str, Any]: The saved incident object, or None on failure.
        """
        response = self.call("Incidents.saveIncident", incident=incident)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    # =====================================================
    # Incidents
    # =====================================================

    def get_incident_by_id(self, incident_id: int) -> Dict[str, Any]:
        """Get an incident by its ID from the LogicVein server.

        Args:
            incident_id (int): The ID of the incident.

        Returns:
            Dict[str, Any]: The incident if it exists, otherwise an empty dictionary.
        """
        response = self.call("Incidents.getIncidentById", incidentId=incident_id)

        if response and type(response) is dict and "result" in response:
            incident = response["result"]
        else:
            incident = {}

        return incident

    def search_incidents(
        self,
        queries: List[str] = [],
        page_size: int = 500,
        sort_column: str = "modified",
        descending: bool = False,
    ) -> List[Dict[str, Any]]:
        """Search for incidents.

        Paginates automatically and returns all matching incidents.

        Args:
            queries (List[str]): List of search queries (e.g., ["severity==4", "status=OPEN,WORKING", "networks=\"Default\",\"Lab\""]).
            page_size (int): Records per API call (default 500). Does not cap total results.
            sort_column (str): The column to sort by.
            descending (bool): Whether to sort in descending order.

        Returns:
            All matching incidents, or an empty list.
        """
        all_incidents: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "queries": queries,
                "pageData": {
                    "incidents": [],
                    "offset": offset,
                    "pageSize": page_size,
                    "total": 0,
                },
                "sortColumn": sort_column,
                "descending": descending,
            }
            response = self.call("Incidents.searchIncidents", **params)

            if response and type(response) is dict and "result" in response and "incidents" in response["result"]:
                batch = response["result"]["incidents"]
            else:
                break

            all_incidents.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_incidents

    def get_webhook_templates(self) -> Dict[str, Any]:
        """Get available webhook templates for incidents.

        Returns:
            Dict[str, Any]: Webhook templates keyed by platform name (e.g. 'slack',
                'teams', 'mattermost', 'webex', 'line_works', 'pagerduty_raise',
                'pagerduty_resolve'). Each value has structure:
                {
                    "headers": list[dict] - HTTP headers (e.g. Content-Type)
                    "content": str - JSON template string with placeholders such as
                                    {message}, {severity}, {node}, {link}, {hash},
                                    {occurrences}, {violation_status}, {updated_at}
                }
        """
        response = self.call("Incidents.getWebhookTemplates")

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return {}

    def fill_webhook_replacements(self, template: str, trigger_event: Optional[Dict[str, Any]] = None) -> str:
        """Fill webhook template placeholders with actual incident data.

        Pass None for trigger_event to fill with representative sample values
        (useful for previewing a template). Pass an actual trigger event object
        to fill with live incident data.

        Args:
            template (str): Webhook template string containing placeholders such as
                            {message}, {severity}, {node}, {link}, {hash},
                            {occurrences}, {violation_status}, {node_label},
                            {severity_label}, {occurrences_label},
                            {violation_status_label}, {updated_at}.
            trigger_event (Optional[Dict[str, Any]]): Trigger event object with
                incident data. Pass None to fill with sample values.

        Returns:
            str: The template string with all placeholders replaced, or "" on error.
        """
        response = self.call("Incidents.fillWebhookReplacements", template=template, triggerEvent=trigger_event)

        if response and type(response) is dict and "result" in response and isinstance(response["result"], str):
            return response["result"]
        return ""

    # =====================================================
    # Credentials
    # =====================================================

    def get_all_credential_configs(self, network: str = "Default") -> List[Dict[str, Any]]:
        """Get all credential configs (i.e., address sets) for a network from the LogicVein server.

        Args:
            network (str): The name of the network.

        Returns:
            List[Dict[str, Any]]: The credentials if they exist, otherwise an empty list.
        """
        params = {"network": network}

        response = self.call("Credentials.getAllCredentialConfigs", **params)

        if response and type(response) is dict and "result" in response:
            credentials = response["result"]
        else:
            credentials = []

        return credentials

    def get_credential_config(self, config_name: str, network: str = "Default") -> Dict[str, Any]:
        """ "Get a specific credential config (i.e., address set) by its name from the LogicVein server.

        Args:
            config_name (str): The configuration name.
            network (str, optional): The network name. Defaults to "Default".

        Returns:
            Dict[str, Any]: The credential config if it exists, otherwise an empty dictionary.
        """
        params = {"network": network, "configName": config_name}
        response = self.call("Credentials.getCredentialConfig", **params)

        if response and type(response) is dict and "result" in response:
            credential_config = response["result"]
        else:
            credential_config = {}

        return credential_config

    def save_credential_config(
        self,
        network: str = "Default",
        old_config_name: str = "",
        config_name: str = "",
        addresses: List[str] = [],
        flat: bool = False,
        priority: int = 0,
    ) -> Optional[Dict[str, Any]]:
        """Creates a credential config (or 'Network Group') for a network in LogicVein.

        Args:
            network (str): The Network within LogicVein
            old_config_name (str): If renaming a network group, this is the old name. otherwise this should be the same as configname.
            config_name (str): The name of the new Network Group.
            addresses (list): List of IP, CIDR, Wildcard, and/or Ranges to import to LogicVein
            flat (bool): Whether to flatten the address set.
            priority (int): where to insert in the Network Groups list. 0=top

        Returns:
            Returns dictionary response from LogicVein

        Example addresses:
            [
                "192.168.1.0/24",
                "192.168.1.1"
            ]
        """
        if not old_config_name:
            old_config_name = config_name

        params = {
            "network": network,
            "oldConfigName": old_config_name,
            "credentialConfig": {
                "name": config_name,
                "addressSet": {"addresses": addresses},
                "flat": flat,
                "managedNetwork": network,
                "priority": priority,
            },
        }

        response = self.call("Credentials.saveCredentialConfig", **params)

        if response and type(response) is dict and "result" in response:
            result = response["result"]
        else:
            msg = "Save Credential Config failed"
            if response:
                msg = f"{msg}: {response}"
            logger.error(msg)
            result = None

        return result

    def delete_credential_config(self, config_name: str, network: str = "Default") -> bool:
        """Delete a credendial config (Network Group) for a network from the LogicVein server.

        Accepted keyword arguments:
            config_name (str): The name of the credential config (Network Group) to delete.
            network (str): The name of the network that the credential config belongs to.

        Returns:
            bool: True if the Network Group was deleted successfully, otherwise False.
        """
        params = {"network": network, "configName": config_name}
        response = self.call("Credentials.deleteCredentialConfig", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            result = True
        else:
            result = False

        return result

    def get_credential_sets(
        self,
        config_name: str,
        network: str = "Default",
        ip_or_cidr: Optional[str] = None,
        sort_column: str = "ipAddress",
        descending: bool = False,
        page_size: int = 500,
    ) -> List[Dict[str, Any]]:
        """Get all credential sets for a credential config from the LogicVein server.

        Paginates automatically and returns all matching credential sets.

        Args:
            config_name (str): The configuration name.
            network (str, optional): The network name. Defaults to "Default".
            ip_or_cidr (str, optional): The IP address or CIDR to filter credentials.
            sort_column (str, optional): Column to sort credentials by. Defaults to "ipAddress".
            descending (bool, optional): Whether to sort in descending order. Defaults to False.
            page_size (int, optional): Records per API call (default 500). Does not cap total results.

        Returns:
            All matching credential sets, or an empty list.
        """
        all_sets: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                    "total": 0,
                    "credentialSets": [],
                },
                "network": network,
                "configName": config_name,
                "ipOrCidr": ip_or_cidr,
                "sortColumn": sort_column,
                "descending": descending,
            }
            response = self.call("Credentials.getCredentialSets", **params)

            if response and type(response) is dict and "result" in response and "credentialSets" in response["result"]:
                batch = response["result"]["credentialSets"]
            else:
                break

            all_sets.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_sets

    def save_credential_sets(
        self, config_name: str = "", credential_sets: List[Dict[str, Any]] = [], network: str = "Default"
    ) -> bool:
        """Save list of credentials to {configname} Network group.

        Args:
            config_name (str): The name of the credential config to save the credential sets in.
            network (str): The name of the network that the credential config belongs to.
            credential_sets (list): a list of credential sets to import to the LogicVein server.

        Returns:
            bool: True if the credential sets were saved successfully, otherwise False.

        Example credential_sets:
            [
                {
                    "name": "NetMRI CLI-SNMP-SNMPv3 Set 1",
                    "priority": 1,
                    "username": "cisco",
                    "password": "cisco",
                    "enableUsername": "",
                    "enablePassword": "cisco",
                    "roCommunityString": "cisco",
                    "snmpUsername": "cisco",
                    "snmpAuthPassword": "cisco123",
                    "snmpPrivPassword": "cisco123"
                }
            ]
        """
        params = {"network": network, "configName": config_name, "credentialSets": credential_sets}
        response = self.call("Credentials.saveCredentialSets", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            result = True
        else:
            result = False

        return result

    def delete_credential_sets(self, config_name: str, credential_set_ids: List[int], network: str = "Default") -> bool:
        """Delete specific credential sets from a credential config.

        Args:
            config_name (str): The name of the credential config.
            credential_set_ids (List[int]): List of credential set IDs to delete.
            network (str): The name of the network.

        Returns:
            bool: True if the credential sets were deleted successfully, otherwise False.
        """
        params = {
            "network": network,
            "configName": config_name,
            "credentialSetIds": credential_set_ids,
        }
        response = self.call("Credentials.deleteCredentialSets", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def commit_credential_edits(self) -> bool:
        """Commit changes to a credential config (Network Group).

        Returns:
            True if the commit was successful, otherwise False.
        """
        response = self.call("Credentials.commitEdits")

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            result = True
        else:
            result = False

        return result

    def discard_credential_edits(self) -> bool:
        """Discard uncommitted credential edits.

        Returns:
            bool: True if the discard was successful, otherwise False.
        """
        response = self.call("Credentials.discardEdits")

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def get_last_successful_credential_mapping(
        self, ip_address: str, network: str = "Default"
    ) -> Optional[Dict[str, Any]]:
        """Get the last successful credential mapping for a device.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.

        Returns:
            Dict[str, Any]: The credential mapping if found, otherwise None.
        """
        params = {"network": network, "ipAddress": ip_address}
        response = self.call("Credentials.getLastSuccessfulCredentialMapping", **params)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    # =====================================================
    # Playbooks (Visual Scripts)
    # =====================================================

    def get_playbooks(self, networks: List[str] = [], page_size: int = 500) -> List[Dict[str, Any]]:
        """Retrieve all playbooks from the LogicVein server.

        Paginates automatically and returns all playbooks.

        Args:
            networks (List[str]): A list of the network(s). If empty, all networks are searched.
            page_size (int): Records per API call (default 500). Does not cap total results.

        Returns:
            All playbooks, or an empty list.
        """
        all_playbooks: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "queries": [],
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                },
                "networks": networks,
                "sortColumn": "name",
                "descending": False,
            }
            response = self.call("VisualScript.searchVisualScripts", **params)

            if response and type(response) is dict and "result" in response and "data" in response["result"]:
                batch = response["result"]["data"]
            else:
                break

            all_playbooks.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_playbooks

    def run_playbook(self, playbook_id: str) -> Optional[Dict[str, Any]]:
        """Run a playbook on the LogicVein server.

        Args:
            playbook_id (str): The ID of the playbook to run.

        Returns:
            Dict[str, Any]: The playbook run result if it exists, otherwise None.
        """
        response = self.call("VisualScript.runScript", scriptId=playbook_id)

        if response and type(response) is dict:
            if "result" in response:
                run_result = response["result"]
            elif "error" in response:
                run_result = response["error"]
        else:
            run_result = None

        return run_result

    def get_playbook(self, playbook_id: str, version: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """Get a specific playbook by ID from the LogicVein server.

        Args:
            playbook_id (str): The ID of the playbook to retrieve (visualScriptId UUID).
            version (Optional[int]): Specific version to retrieve, or None for latest.

        Returns:
            Dict[str, Any]: The playbook if found, otherwise None.
        """
        response = self.call("VisualScript.getVisualScript", id=playbook_id, version=version)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def delete_playbook(self, playbook_id: str) -> bool:
        """Delete a playbook from the LogicVein server.

        Args:
            playbook_id (str): The ID of the playbook to delete.

        Returns:
            bool: True if the playbook was deleted successfully, otherwise False.
        """
        response = self.call("VisualScript.deleteVisualScript", scriptId=playbook_id)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def get_playbook_available_nodes(self) -> List[Dict[str, Any]]:
        """Get available node types for the playbook editor.

        Calls VisualScript.getAvailableNodes (no params). Returns the result list directly.
        Each node definition has:
            {
                "name": str - Node type name (e.g. "backup_device", "run_code", "schedule"),
                "isStartNode": bool - True if this node can be a playbook entry point,
                "config": dict - Node config schema (keys are config field names, values have "type"),
                "requiredEntitlements": list[str] - Required platform entitlements,
                "requiredPermissions": list[str] - Required permission strings,
                "inputs": list[dict] - Input port definitions, each with:
                    {
                        "name": str,
                        "isOptional": bool,
                        "type": str,
                        "autowire": str,
                        "autowireOn": str,
                        "typeInference": str,
                        "inputUsage": str,
                    }
                "outputs": list[dict] - Output port definitions, each with:
                    {
                        "name": str,
                        "type": str,
                        "typeInference": str,
                        "typeInferenceMatchName": str,
                        "tags": list[str] - e.g. ["Error"] for error/failure outputs,
                    }
            }

        Known node names include: "and", "backup_device", "chat_webhook",
        "compliance_violation", "device_reduce", "device_search", "email",
        "incident", "load_config", "memo", "raise_compliance_violation",
        "regex_match", "ruleset", "run_code", "run_code_retry", "schedule",
        "set_variables", "sleep", "ssh_exec", "to_csv", "to_json", "upload_file".

        Returns:
            List[Dict[str, Any]]: List of available playbook node type definitions.
        """
        response = self.call("VisualScript.getAvailableNodes")

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def get_playbook_categories(self) -> List[Dict[str, Any]]:
        """Get playbook categories from the LogicVein server.

        Returns:
            List of category dicts, each containing:
                "categoryId" (str): UUID of the category.
                "categoryName" (str): Display name.
                "categoryImage" (str): Image filename (e.g. "playbook_default.svg").
                "categoryColor" (str): Hex colour string (e.g. "#1d31b8").
            Returns an empty list if no categories exist.
        """
        response = self.call("VisualScript.getCategories")

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def save_playbook(self, playbook: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create or update a playbook.

        Args:
            playbook (Dict[str, Any]): Playbook object with structure:
                {
                    "name": str - Playbook name
                    "description": str (optional) - Description
                    "categoryId": str (optional) - Category UUID
                    "managedNetworks": list[str] - Networks (e.g., ["Default"])
                    "nodes": list[dict] - Playbook nodes with type, nodeId, alias, nodeConfig, nodeProperties
                    "edges": list[dict] - Connections between nodes with fromNode, toNode, handles
                    "versionId": int (optional) - Version ID for updates
                }

        Returns:
            Dict[str, Any]: The saved playbook if successful, otherwise None.
        """
        results = self.call("VisualScript.saveVisualScript", _params=[playbook])

        if results and type(results) is dict and "result" in results:
            return results["result"]
        return None

    def add_playbook_category(
        self, name: str, color: str = "#1d31b8", image: str = "playbook_default.svg"
    ) -> Optional[str]:
        """Create a new playbook category.

        Calls VisualScript.addCategory. The API returns the full category object:
            {
                "categoryId": str - UUID of the new category,
                "categoryName": str - Name of the category,
                "categoryImage": str - Image filename (e.g. "playbook_default.svg"),
                "categoryColor": str - Hex color code (e.g. "#1d31b8"),
            }

        Args:
            name (str): The name of the category.
            color (str): Hex color code for the category (default: "#1d31b8").
            image (str): Image filename for the category (default: "playbook_default.svg").

        Returns:
            str: The categoryId UUID if created, otherwise None.
        """
        response = self.call("VisualScript.addCategory", name=name, color=color, image=image)

        if response and type(response) is dict and "result" in response and "categoryId" in response["result"]:
            return response["result"]["categoryId"]
        return None

    def remove_playbook_category(self, category_id: str) -> bool:
        """Delete a playbook category from the LogicVein server.

        Args:
            category_id (str): UUID of the category to delete.

        Returns:
            bool: True if deleted successfully, otherwise False.
        """
        response = self.call("VisualScript.removeCategory", categoryId=category_id)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    # =====================================================
    # Networks - Managed Network Methods
    # =====================================================

    def define_managed_network(self, network_name: str, bridge_name: str = "Default") -> bool:
        """Define a new managed network in the LogicVein server.

        Args:
            network_name (str): The name of the new managed network.
            bridge_name (str): The name of the bridge to associate with the network.

        Returns:
            bool: True if the network was created successfully, otherwise False.
        """
        response = self.call("Networks.defineManagedNetwork", networkName=network_name, bridgeName=bridge_name)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def get_managed_network(self, network_name: str) -> Optional[Dict[str, Any]]:
        """Get details of a managed network.

        Args:
            network_name (str): The name of the managed network.

        Returns:
            Dict[str, Any]: The network details if found, otherwise None.
        """
        response = self.call("Networks.getManagedNetwork", networkName=network_name)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def get_all_managed_networks(self) -> List[Dict[str, Any]]:
        """Get all managed networks with their full details.

        Returns:
            List[Dict[str, Any]]: List of managed networks, otherwise empty list.
        """
        response = self.call("Networks.getAllManagedNetworks")

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def delete_managed_network(self, network_name: str) -> bool:
        """Delete a managed network from the LogicVein server.

        Args:
            network_name (str): The name of the managed network to delete.

        Returns:
            bool: True if the network was deleted successfully, otherwise False.
        """
        response = self.call("Networks.deleteManagedNetwork", networkName=network_name)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def update_managed_network(
        self,
        network_name: str,
        new_name: Optional[str] = None,
        bridge_name: Optional[str] = None,
        online: Optional[bool] = None,
    ) -> bool:
        """Update a managed network.

        Args:
            network_name (str): The current name of the managed network.
            new_name (str, optional): The new name for the managed network.
            bridge_name (str, optional): The bridge to associate with the network.
            online (bool, optional): Whether the network is online.

        Returns:
            bool: True if the network was updated successfully, otherwise False.
        """
        network_obj: Dict[str, Any] = {"name": network_name}
        if new_name is not None:
            network_obj["name"] = new_name
        if bridge_name is not None:
            network_obj["bridgeName"] = bridge_name
        if online is not None:
            network_obj["online"] = online

        response = self.call("Networks.updateManagedNetwork", network=network_obj)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def get_all_bridges(self) -> List[Dict[str, Any]]:
        """Get all bridges.

        Returns:
            List[Dict[str, Any]]: List of bridges with their details.
        """
        response = self.call("Bridges.getAllBridges")

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    # =====================================================
    # Scheduler - Job Methods
    # =====================================================

    def run_job_now(
        self,
        job_name: str,
        job_type: str,
        managed_networks: List[str],
        job_parameters: Dict[str, Any],
        description: Optional[str] = None,
        sub_type: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Run a job immediately without saving it.

        Args:
            job_name (str): A name for the job (e.g., "Interactive Discovery").
            job_type (str): The type of job (e.g., "Script Tool Job", "Bulk Update").
            managed_networks (List[str]): List of network names to run the job on.
            job_parameters (Dict[str, Any]): Job-specific parameters.
            description (str, optional): A description for the job.

        Returns:
            Dict[str, Any]: The job execution result if successful, otherwise None.

        Example job_parameters for discovery:
            {
                "addresses": ",192.168.1.0/24",
                "includeUnknown": True,
                "ipResolutionScheme": "ipCsv",
                "ipResolutionData": ""
            }
        """
        job_data: Dict[str, Any] = {
            "jobName": job_name,
            "jobType": job_type,
            "managedNetworks": managed_networks,
            "jobParameters": job_parameters,
        }
        if sub_type:
            job_data["subType"] = sub_type
        if description:
            job_data["description"] = description
        else:
            job_data["description"] = job_type

        response = self.call("Scheduler.runNow", jobData=job_data)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def save_job(self, job_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Save a job to the scheduler.

        Args:
            job_data (Dict[str, Any]): The job definition including schedule, type, targets, etc.

        Returns:
            Dict[str, Any]: The saved job if successful, otherwise None.
        """
        job_data.setdefault("description", "")
        job_data.setdefault("managedNetworks", [])
        response = self.call("Scheduler.saveJob", jobData=job_data)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def delete_job(self, job_id: int) -> bool:
        """Delete a scheduled job.

        Args:
            job_id (int): The ID of the job to delete.

        Returns:
            bool: True if the job was deleted successfully, otherwise False.
        """
        response = self.call("Scheduler.deleteJob", jobId=job_id)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def get_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        """Get details of a scheduled job.

        Args:
            job_id (int): The ID of the job.

        Returns:
            Dict[str, Any]: The job details if found, otherwise None.
        """
        response = self.call("Scheduler.getJob", jobId=job_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def search_jobs(
        self,
        networks: List[str] = [],
        page_size: int = 500,
        sort_column: str = "",
        descending: bool = False,
    ) -> List[Dict[str, Any]]:
        """Search for scheduled jobs.

        Paginates automatically and returns all matching jobs.

        Args:
            networks (List[str]): List of networks to search in. Empty for all networks.
            page_size (int): Records per API call (default 500). Does not cap total results.
            sort_column (str): The column to sort by.
            descending (bool): Whether to sort in descending order.

        Returns:
            All matching jobs, or an empty list.
        """
        all_jobs: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "networks": networks,
                "pageData": {
                    "offset": offset,
                    "jobData": [],
                    "pageSize": page_size,
                    "total": 0,
                },
                "sortColumn": sort_column,
                "descending": descending,
            }
            response = self.call("Scheduler.searchJobs", **params)

            if response and type(response) is dict and "result" in response and "jobData" in response["result"]:
                batch = response["result"]["jobData"]
            else:
                break

            all_jobs.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_jobs

    def search_jobs_with_queries(
        self,
        networks: Optional[List[str]] = None,
        queries: Optional[List[Any]] = None,
        sort_column: str = "jobName",
        descending: bool = False,
        page_size: int = 100,
    ) -> List[Dict[str, Any]]:
        """Search for jobs using Scheduler.searchJobsWithQueries with auto-pagination.

        Args:
            networks (List[str]): Networks to search. Defaults to ["Default"].
            queries (List): Query filter list. Defaults to [] (all jobs).
            sort_column (str): Column to sort by. Defaults to "jobName".
            descending (bool): Sort descending when True. Defaults to False.
            page_size (int): Records per API call. Defaults to 100.

        Returns:
            All matching job dicts, or an empty list.
        """
        if networks is None:
            networks = ["Default"]
        if queries is None:
            queries = []

        all_jobs: List[Dict[str, Any]] = []
        offset = 0

        while True:
            page_data = {
                "offset": offset,
                "jobData": [],
                "pageSize": page_size,
                "total": 0,
            }
            response = self.call(
                "Scheduler.searchJobsWithQueries",
                pageData=page_data,
                sortColumn=sort_column,
                descending=descending,
                networks=networks,
                queries=queries,
            )

            if (
                response
                and type(response) is dict
                and "result" in response
                and type(response["result"]) is dict
                and "jobData" in response["result"]
            ):
                batch = response["result"]["jobData"]
            else:
                break

            all_jobs.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_jobs

    def run_existing_job_now(self, job_id: int) -> Optional[Dict[str, Any]]:
        """Run an existing scheduled job immediately.

        Args:
            job_id (int): The ID of the job to run.

        Returns:
            Dict[str, Any]: The execution result if successful, otherwise None.
        """
        response = self.call("Scheduler.runExistingJobNow", jobId=job_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def search_job_executions(
        self,
        scheme: str = "",
        data: str = "",
        page_size: int = 500,
        sort_column: str = "endTime",
        descending: bool = True,
    ) -> List[Dict[str, Any]]:
        """Search for job execution history.

        Paginates automatically and returns all matching executions.

        Args:
            scheme (str): Filter scheme (e.g., "network" to filter by network name).
            data (str): Filter data (e.g., network name when scheme is "network").
            page_size (int): Records per API call (default 500). Does not cap total results.
            sort_column (str): The column to sort by.
            descending (bool): Whether to sort in descending order.

        Returns:
            All matching job executions, or an empty list.
        """
        all_executions: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "scheme": scheme,
                "data": data,
                "pageData": {
                    "offset": offset,
                    "executionData": [],
                    "pageSize": page_size,
                    "total": 0,
                },
                "sortColumn": sort_column,
                "descending": descending,
            }
            response = self.call("Scheduler.searchExecutions", **params)

            if response and type(response) is dict and "result" in response and "executionData" in response["result"]:
                batch = response["result"]["executionData"]
            else:
                break

            all_executions.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_executions

    def save_trigger(
        self,
        job_id: int,
        trigger_name: str,
        cron_expression: str,
        time_zone: str = "Etc/GMT",
        paused: bool = False,
        filter_name: str = "",
    ) -> Optional[Dict[str, Any]]:
        """Schedule a trigger for an existing job.

        For a one-time run, pass an ISO datetime string as ``cron_expression``
        (e.g. ``"2026-03-17T09:00"``).  Standard cron syntax works for recurring
        schedules.

        Args:
            job_id (int): ID of the job to schedule (returned by :meth:`save_job`).
            trigger_name (str): Display name for the trigger.
            cron_expression (str): ISO datetime (one-time) or cron expression (recurring).
            time_zone (str): Timezone name (e.g. ``"America/Halifax"``).  Default ``"UTC"``.
            paused (bool): Whether to create the trigger in a paused state.
            filter_name (str): Optional filter name; pass empty string for none.

        Returns:
            Dict[str, Any]: The saved trigger record (contains ``triggerId``,
            ``nextExpectedFireTime``, etc.), or None on failure.
        """
        response = self.call(
            "Scheduler.saveTrigger",
            triggerData={
                "triggerName": trigger_name,
                "paused": paused,
                "cronExpression": cron_expression,
                "timeZone": time_zone,
                "filterName": filter_name,
                "jobId": job_id,
            },
        )
        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def create_command_runner_job(
        self,
        device_ip: str,
        network: str,
        commands: str,
        job_name: str = "Command Runner",
        backup_on_completion: bool = False,
        description: str = "",
    ) -> Optional[Dict[str, Any]]:
        """Create a Command Runner job definition without running it.

        Returns the saved job dict (contains ``jobId``) which can then be passed
        to :meth:`save_trigger` to schedule execution.

        Args:
            device_ip (str): IP address of the target device.
            network (str): LVI managed network the device belongs to.
            commands (str): CLI commands to run, one per line.
            job_name (str): Display name for the job.
            backup_on_completion (bool): If True, LVI backs up the device after the job runs.

        Returns:
            Dict[str, Any]: The saved job record (contains ``jobId``), or None on failure.
        """
        return self.save_job(
            {
                "jobId": 0,
                "jobName": job_name,
                "description": description or "Job scheduled by ServiceNow",
                "managedNetworks": [network],
                "jobType": "Script Tool Job",
                "subType": "org.ziptie.tools.scripts.commandRunner",
                "approvalRequired": False,
                "jobParameters": {
                    "ipResolutionScheme": '"interfaceIpAddress"',
                    "ipResolutionData": device_ip,
                    "input.commandList": commands,
                    "input.responseTimeout": "60",
                    "input.prompt": "",
                    "tool": "org.ziptie.tools.scripts.commandRunner",
                    "backupOnCompletion": "true" if backup_on_completion else "false",
                },
            }
        )

    def run_command_runner_job(
        self,
        device_ip: str,
        network: str,
        commands: str,
        job_name: str = "Command Runner",
        backup_on_completion: bool = False,
        description: str = "",
    ) -> Optional[Dict[str, Any]]:
        """Run a Command Runner (Script) job on a single device immediately.

        Wraps :meth:`run_job_now` with the job type and parameter format expected
        by the LVI Command Runner.

        .. note::
            Uses ``jobType="Script"`` — the LVI Scheduler job type for running
            CLI commands on devices.  If your LVI instance uses a different type
            name, adjust ``job_type`` in the :meth:`run_job_now` call.

        Args:
            device_ip (str): IP address of the target device.
            network (str): LVI managed network the device belongs to.
            commands (str): CLI commands to run, one per line.
            job_name (str): Display name for the job in the LVI scheduler.

        Returns:
            Dict[str, Any]: The job execution result dict from LVI (contains ``id``
            or ``executionId`` for polling), or None on failure.
        """
        return self.run_job_now(
            job_name=job_name,
            job_type="Script Tool Job",
            sub_type="org.ziptie.tools.scripts.commandRunner",
            managed_networks=[network],
            job_parameters={
                "ipResolutionScheme": '"interfaceIpAddress"',
                "ipResolutionData": device_ip,
                "input.commandList": commands,
                "input.responseTimeout": "60",
                "input.prompt": "",
                "tool": "org.ziptie.tools.scripts.commandRunner",
                "backupOnCompletion": "true" if backup_on_completion else "false",
            },
            description=description or "Job scheduled by ServiceNow",
        )

    # =====================================================
    # Bridges
    # =====================================================

    def define_bridge(
        self,
        bridge_name: str,
        hostname: str,
        port: int = 443,
        username: str = "",
        password: str = "",
    ) -> bool:
        """Define a new bridge connection.

        Args:
            bridge_name (str): The name for the bridge.
            hostname (str): The hostname or IP of the bridge.
            port (int): The port number (default 443).
            username (str): The username for authentication.
            password (str): The password for authentication.

        Returns:
            bool: True if the bridge was created successfully, otherwise False.
        """
        params = {
            "bridgeName": bridge_name,
            "hostname": hostname,
            "port": port,
            "username": username,
            "password": password,
        }
        response = self.call("Bridges.defineBridge", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def delete_bridge(self, bridge_name: str) -> bool:
        """Delete a bridge.

        Args:
            bridge_id (str): The ID of the bridge to delete.

        Returns:
            bool: True if the bridge was deleted successfully, otherwise False.
        """
        response = self.call("Bridges.deleteBridge", bridgeName=bridge_name)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def update_bridge(
        self,
        bridge_id: str,
        bridge_name: Optional[str] = None,
        hostname: Optional[str] = None,
        port: Optional[int] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ) -> bool:
        """Update a bridge configuration.

        Args:
            bridge_id (str): The ID of the bridge to update.
            bridge_name (str, optional): The new name for the bridge.
            hostname (str, optional): The new hostname or IP.
            port (int, optional): The new port number.
            username (str, optional): The new username.
            password (str, optional): The new password.

        Returns:
            bool: True if the bridge was updated successfully, otherwise False.
        """
        params: Dict[str, Any] = {"bridgeId": bridge_id}
        if bridge_name is not None:
            params["bridgeName"] = bridge_name
        if hostname is not None:
            params["hostname"] = hostname
        if port is not None:
            params["port"] = port
        if username is not None:
            params["username"] = username
        if password is not None:
            params["password"] = password

        response = self.call("Bridges.updateBridge", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    # =====================================================
    # Security (Users, Roles)
    # =====================================================

    def get_users(self) -> List[Dict[str, Any]]:
        """Get all users from the LogicVein server.

        Returns:
            List[Dict[str, Any]]: The list of users if they exist, otherwise an empty list.
        """
        response = self.call("Security.getUsers")

        if response and type(response) is dict and "result" in response:
            users = response["result"]
        else:
            users = []

        return users

    def get_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific user by their ID.

        Args:
            user_id (int): The ID of the user.

        Returns:
            Dict[str, Any]: The user if found, otherwise None.
        """
        response = self.call("Security.getUser", userId=user_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def get_user_by_name(self, username: str) -> Optional[Dict[str, Any]]:
        """Get a specific user by their username.

        Args:
            username (str): The username of the user.

        Returns:
            Dict[str, Any]: The user if found, otherwise None.
        """
        users = self.get_users()
        for user in users:
            if user.get("name") == username:
                return user
        return None

    def create_user(
        self,
        username: str,
        full_name: str,
        email: str,
        password: str,
        role_name: str = "Administrator",
        metadata: Optional[List[Dict[str, str]]] = None,
    ) -> bool:
        """Create a new user in the LogicVein server.

        Args:
            username (str): The username for the new user.
            full_name (str): The full name of the user.
            email (str): The email address of the user.
            password (str): The password for the user.
            role_name (str): The role name to assign (default: "Administrator").
            metadata (list, optional): List of metadata dicts with 'key' and 'value'. Defaults to a standard column visibility entry.

        Returns:
            bool: True if the user was created successfully, otherwise False.
        """
        if metadata is None:
            metadata = [{"key": "org.ziptie.provider.devices.columnVisibility", "value": "*"}]

        response = self.call(
            "Security.createUser",
            username=username,
            fullName=full_name,
            email=email,
            password=password,
            role=role_name,
            metadata=metadata,
        )

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def update_user(
        self,
        username: str,
        full_name: Optional[str] = None,
        email: Optional[str] = None,
        role_name: Optional[str] = None,
        metadata: Optional[List[Dict[str, str]]] = None,
    ) -> bool:
        """Update an existing user in the LogicVein server.

        Args:
            username (str): The username of the user to update.
            full_name (str, optional): The new full name.
            email (str, optional): The new email address.
            role_name (str, optional): The new role name.
            metadata (list, optional): List of metadata dicts with 'key' and 'value'.

        Returns:
            bool: True if the user was updated successfully, otherwise False.
        """
        params: Dict[str, Any] = {"username": username}
        if full_name is not None:
            params["fullName"] = full_name
        if email is not None:
            params["email"] = email
        if role_name is not None:
            params["role"] = role_name
        if metadata is not None:
            params["metadata"] = metadata

        response = self.call("Security.updateUser", **params)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def delete_user(self, username: str) -> bool:
        """Delete a user from the LogicVein server.

        Args:
            username (str): The username of the user to delete.

        Returns:
            bool: True if the user was deleted successfully, otherwise False.
        """
        response = self.call("Security.deleteUser", username=username)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def get_available_roles(self) -> List[Dict[str, Any]]:
        """Get all available roles from the LogicVein server.

        Returns:
            List[Dict[str, Any]]: The list of roles if they exist, otherwise an empty list.
        """
        response = self.call("Security.getAvailableRoles")

        if response and type(response) is dict and "result" in response:
            roles = response["result"]
        else:
            roles = []

        return roles

    def get_role_by_name(self, role_name: str) -> Optional[Dict[str, Any]]:
        """Get a specific role by name.

        Args:
            role_name (str): The name of the role.

        Returns:
            Dict[str, Any]: The role if found, otherwise None.
        """
        roles = self.get_available_roles()
        for role in roles:
            if role.get("name") == role_name:
                return role
        return None

    def create_role(
        self,
        role_name: str,
        permissions: List[str],
        tools: Optional[List[str]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Create a new role in the LogicVein server.

        Args:
            role_name (str): The name for the new role.
            permissions (List[str]): List of permission strings.
            tools (List[str], optional): List of tool permissions.

        Returns:
            Dict[str, Any]: The created role if successful, otherwise None.
        """
        role_data = {
            "name": role_name,
            "permissions": permissions,
            "tools": tools,
        }
        response = self.call("Security.saveRole", role=role_data)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def update_role(
        self,
        role_name: str,
        permissions: Optional[List[str]] = None,
        tools: Optional[List[str]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Update an existing role in the LogicVein server.

        Args:
            role_name (str): The name of the role to update.
            permissions (List[str], optional): New list of permission strings.
            tools (List[str], optional): New list of tool permissions.

        Returns:
            Dict[str, Any]: The updated role if successful, otherwise None.
        """
        role = self.get_role_by_name(role_name)
        if not role:
            logger.error(f"Role {role_name} not found")
            return None

        if permissions is not None:
            role["permissions"] = permissions
        if tools is not None:
            role["tools"] = tools

        response = self.call("Security.saveRole", role=role)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def delete_role(self, role_name: str) -> bool:
        """Delete a role from the LogicVein server.

        Args:
            role_name (str): The name of the role to delete.

        Returns:
            bool: True if the role was deleted successfully, otherwise False.
        """
        response = self.call("Security.deleteRole", roleName=role_name)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    # =====================================================
    # Jumphosts
    # =====================================================

    def get_jumphost_for_network(self, network: str = "Default") -> Optional[Dict[str, Any]]:
        """Get the jumphost configuration for a network.

        Args:
            network (str): The name of the network.

        Returns:
            Dict[str, Any]: The jumphost configuration if found, otherwise None.
        """
        response = self.call("Jumphost.getJumphostForNetwork", network=network)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def save_jumphost(
        self,
        network: str,
        enabled: bool = False,
        adapter: str = "Cisco::IOS",
        host: str = "",
        username: str = "",
        password: str = "",
        max_connections: int = 0,
        nat_return_address: Optional[str] = None,
        override_port: bool = False,
        port: Optional[int] = None,
    ) -> bool:
        """Save a jumphost configuration for a network.

        Args:
            network (str): The name of the network.
            enabled (bool): Whether the jumphost is enabled.
            adapter (str): The adapter type (e.g., "Cisco::IOS").
            host (str): The hostname or IP of the jumphost.
            username (str): The username for authentication.
            password (str): The password for authentication.
            max_connections (int): Maximum number of connections.
            nat_return_address (str, optional): NAT return address.
            override_port (bool): Whether to override the default port.
            port (int, optional): The port number to use when override_port is True.

        Returns:
            bool: True if the jumphost was saved successfully, otherwise False.
        """
        properties = {
            "enabled": str(enabled).lower(),
            "adapter": adapter,
            "host": host,
            "username": username,
            "password": password,
            "maxConnections": max_connections,
            "natReturnAddress": nat_return_address,
            "overridePort": str(override_port).lower(),
            "port": port,
        }
        response = self.call("Jumphost.saveJumphost", network=network, properties=properties)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    # =====================================================
    # Terminal Logs
    # =====================================================

    def search_term_logs(
        self,
        networks: List[str] = [],
        queries: List[str] = [],
        page_size: int = 500,
        sort_column: str = "timestamp",
        descending: bool = True,
    ) -> List[Dict[str, Any]]:
        """Search for terminal logs.

        Paginates automatically and returns all matching logs.

        Args:
            networks (List[str]): List of networks to search in. Empty for all networks.
            queries (List[str]): List of search queries.
            page_size (int): Records per API call (default 500). Does not cap total results.
            sort_column (str): The column to sort by.
            descending (bool): Whether to sort in descending order.

        Returns:
            All matching terminal logs, or an empty list.
        """
        all_logs: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "networks": networks,
                "queries": queries,
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                },
                "sortColumn": sort_column,
                "descending": descending,
            }
            response = self.call("TermLogs.search", **params)

            if response and type(response) is dict and "result" in response and "termLogs" in response["result"]:
                batch = response["result"]["termLogs"]
            else:
                break

            all_logs.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_logs

    # =====================================================
    # Mibs
    # =====================================================

    def find_mib_children(self, oid: str) -> List[Dict[str, Any]]:
        """Get the direct children of an OID node in the MIB tree.

        Calls Mibs.findChildren. Returns the result list directly (not paginated).
        Each node in the list has:
            {
                "name": str - OID node name,
                "oid": str - Dotted OID string (e.g. "1.3"),
                "mib": str - MIB file the node is defined in,
                "type": str - Data type (empty string if not a leaf),
                "typeRestriction": dict | null - Enum value map if applicable,
                "syntax": str | null - Syntax definition,
                "macroType": str - SNMP macro type (e.g. "OBJECT IDENTIFIER", "OBJECT-TYPE"),
                "leaf": bool - True if the node is a leaf (scalar/table column),
                "revision": str - Last revision timestamp,
                "parentPath": str - Name of the parent node,
                "description": str - MIB description text,
                "messageFormat": str | null - Alert message format if configured,
            }

        Args:
            oid (str): Dotted OID string to find children of (e.g. "1.3").

        Returns:
            List[Dict[str, Any]]: Direct children of the given OID node.
        """
        response = self.call("Mibs.findChildren", oid=oid)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def find_mib_nodes_by_oid(self, oid: str) -> List[Dict[str, Any]]:
        """Find MIB nodes matching an OID prefix.

        Calls Mibs.findNodesByOid. Returns nodes with the same structure as
        find_mib_children(). Returns an empty list if no nodes match the OID.

        Args:
            oid (str): The OID string to search for (e.g. "1.3.6.1.2.1.1").

        Returns:
            List[Dict[str, Any]]: List of matching MIB nodes, or [] if none found.
        """
        response = self.call("Mibs.findNodesByOid", oid=oid)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    # =====================================================
    # Collection (Monitor Sets, Alert Policies)
    # =====================================================

    def get_monitor_set(self, set_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific monitor set by ID.

        Calls Collection.getMonitorSet. The result has:
            {
                "setId": int - Monitor set ID,
                "setName": str - Monitor set name,
                "smartSet": bool - True if the set is a smart (dynamic) set,
                "managedNetworks": list[str] - Networks the set belongs to,
            }

        Args:
            set_id (int): The ID of the monitor set to retrieve.

        Returns:
            Dict[str, Any]: The monitor set if found, otherwise None.
        """
        response = self.call("Collection.getMonitorSet", setId=set_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def get_monitors_for_set(self, set_id: int) -> List[Dict[str, Any]]:
        """Get monitors within a specific monitor set.

        Calls Collection.getMonitorsForSet. Returns the result list directly (not paginated).
        Each monitor in the list has:
            {
                "setId": int - Monitor set ID,
                "monitorId": int - Monitor ID,
                "monitorName": str - Display name,
                "monitorType": str - Type (e.g. "snmp"),
                "retentionPolicy": str - Data retention policy (e.g. "THREE_MONTHS"),
                "fingerprint": str - Short hash identifying the monitor config,
                "disabled": bool - Whether the monitor is disabled,
                "managedNetworks": list[str] - Networks the monitor belongs to,
                "json": dict - Monitor-type-specific configuration (OIDs, tables, triggers, etc.),
                "triggerAssociationJson": list - Trigger associations,
                "isHostSpecific": bool - Whether the monitor is host-specific,
            }

        Args:
            set_id (int): The ID of the monitor set.

        Returns:
            List[Dict[str, Any]]: List of monitors in the set.
        """
        response = self.call("Collection.getMonitorsForSet", setId=set_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def get_actions_for_alert_policy(self, policy_id: int) -> List[Dict[str, Any]]:
        """Get actions configured for an alert policy.

        Calls Collection.getActionsForPolicy. Returns the result list directly (not paginated).
        Each action has:
            {
                "actionId": int - Action ID,
                "actionType": str - One of: "exec", "run-playbook", "dns-resolve", "email",
                    "trap", "incident", "runjob", "webhook",
                "policyId": int - Parent alert policy ID,
                "username": str - Username that owns the action,
                "json": dict - Action-type-specific configuration,
            }

        Args:
            policy_id (int): The ID of the alert policy.

        Returns:
            List[Dict[str, Any]]: List of actions for the policy.
        """
        response = self.call("Collection.getActionsForPolicy", policyId=policy_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def save_alert_actions(self, actions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Save (create or update) alert actions for an alert policy.

        Calls Collection.saveAlertActions. The policyId is embedded in each action object.
        Returns the saved actions with assigned actionIds (new actions use -1 as input id,
        which is replaced with the assigned ID in the response).

        Each action object should have:
            {
                "actionId": int - Use -1 for new actions,
                "actionType": str - One of: "exec", "run-playbook", "dns-resolve", "email",
                    "trap", "incident", "runjob", "webhook",
                "policyId": int - Alert policy ID this action belongs to,
                "username": str - Username that owns the action,
                "json": dict - Action-type-specific config. Known shapes by type:
                    "exec":         {"command": str, "username": str, "password": str, "targetAddress": str}
                    "run-playbook": {"playbookId": str, "ignoreCLEARING": bool}
                    "dns-resolve":  {}
                    "email":        {"language": str, "emailFrequency": str,
                                     "emailRecipients": str, "emailCcRecipients": str}
                    "trap":         {"community": str, "targetAddress": str}
                    "incident":     {"assignee": str, "language": str, "priority": str,
                                     "emailOnEdit": bool, "emailFrequency": str,
                                     "emailRecipients": str, "emailCcRecipients": str}
                    "runjob":       (see get_actions_for_alert_policy for structure)
                    "webhook":      (see get_actions_for_alert_policy for structure)
            }

        Args:
            actions (List[Dict[str, Any]]): List of action objects to save.

        Returns:
            List[Dict[str, Any]]: List of saved action objects with assigned actionIds.
        """
        response = self.call("Collection.saveAlertActions", actions=actions)

        if response and type(response) is dict and "result" in response and isinstance(response["result"], list):
            return response["result"]
        return []

    def search_monitor_sets(
        self,
        queries: List[str] = [],
        sort_column: str = "setName",
        descending: bool = False,
        managed_networks: List[str] = [],
        require_all_networks: bool = False,
        page_size: int = 500,
    ) -> List[Dict[str, Any]]:
        """Search and list available monitor sets.

        Calls Collection.searchMonitorSet with pagination. Each monitor set in the result has:
            {
                "setId": int - Monitor set ID,
                "setName": str - Monitor set name,
                "smartSet": bool - Whether the set is a smart (dynamic) set,
                "managedNetworks": list[str] - Networks the set belongs to,
            }

        Args:
            queries (List[str]): Search filter queries (default: [] for all).
            sort_column (str): Column to sort by (default: "setName").
            descending (bool): Sort descending if True (default: False).
            managed_networks (List[str]): Networks to search in (default: [] for all).
            require_all_networks (bool): Require devices in all networks (default: False).
            page_size (int): Number of results per page (default: 500).

        Returns:
            List[Dict[str, Any]]: List of monitor sets matching the search criteria.
        """
        all_sets: List[Any] = []
        offset = 0
        while True:
            response = self.call(
                "Collection.searchMonitorSet",
                pageData={"offset": offset, "pageSize": page_size, "total": 0, "monitorSets": []},
                queries=queries,
                sortColumn=sort_column,
                descending=descending,
                managedNetworks=managed_networks,
                requireAllNetworks=require_all_networks,
            )
            if not (response and type(response) is dict and "result" in response):
                break
            batch = response["result"].get("monitorSets", [])
            all_sets.extend(batch)
            if len(batch) < page_size:
                break
            offset += page_size
        return all_sets

    def associate_monitor_set(self, set_id: int, host_queries: List[str]) -> bool:
        """Associate a monitor set with device(s).

        Calls Collection.associateMonitorSet. Returns null on success.

        Args:
            set_id (int): The ID of the monitor set to associate.
            host_queries (List[str]): List of host query strings in format 'ipCsv=IP@NetworkName'.
                Example: ['ipCsv=192.168.1.6@Default']

        Returns:
            bool: True if successful (result is null), otherwise False.
        """
        response = self.call("Collection.associateMonitorSet", setId=set_id, hostQueries=host_queries)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def add_monitors_to_set(self, monitors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Add monitors to a monitor set.

        Calls Collection.addMonitorsToSet. The setId is embedded in each monitor object,
        not passed as a top-level parameter. Returns the saved monitors with assigned IDs.

        Each monitor object should have:
            {
                "monitorId": int - Use -1 for new monitors; assigned ID returned in response,
                "monitorName": str - Monitor name,
                "setId": int - The monitor set ID to add to,
                "monitorType": str - Type (e.g. "snmp", "tcp", "icmp", "telegraf", "web", "catchalltrap"),
                "disabled": bool - Whether the monitor is disabled,
                "hostSpecific": bool - Whether the monitor is host-specific,
                "managedNetworks": list[str] - Networks the monitor belongs to,
                "retentionPolicy": str - Data retention (e.g. "THREE_MONTHS"),
                "json": dict - Monitor-type-specific config (OIDs, pollingPeriod, table, triggers, etc.),
            }

        The response mirrors get_monitors_for_set() entries, with the assigned monitorId
        populated and fingerprint set to "" for newly created monitors.

        Args:
            monitors (List[Dict[str, Any]]): List of monitor objects to add/update.

        Returns:
            List[Dict[str, Any]]: List of saved monitor objects with assigned monitorIds.
        """
        response = self.call("Collection.addMonitorsToSet", monitors=monitors)

        if response and type(response) is dict and "result" in response and isinstance(response["result"], list):
            return response["result"]
        return []

    def dissociate_monitors(self, monitor_ids: List[int], network: str, device_uuid: str) -> bool:
        """Dissociate monitors from a specific device.

        Calls Collection.dissociateMonitors. Removes the monitor associations from a device
        identified by UUID, without removing the monitors from their set. Returns null on success.

        Args:
            monitor_ids (List[int]): List of monitor IDs to dissociate (e.g. [3, 4, 5]).
            network (str): Network name the device belongs to (e.g. "Default").
            device_uuid (str): UUID of the device to dissociate monitors from.

        Returns:
            bool: True if successful (result is null), otherwise False.
        """
        response = self.call("Collection.dissociateMonitors", monitorIds=monitor_ids, network=network, uuid=device_uuid)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def remove_monitors_from_set(self, monitors: List[Dict[str, Any]]) -> bool:
        """Remove monitors from a monitor set.

        Calls Collection.removeMonitorsFromSet. Takes the full monitor objects (as returned
        by get_monitors_for_set or add_monitors_to_set) and removes them from the set.
        Returns null on success.

        Args:
            monitors (List[Dict[str, Any]]): List of monitor objects to remove. Each object
                must include at minimum "monitorId" and "setId". Passing the full object
                as returned by get_monitors_for_set() is recommended.

        Returns:
            bool: True if successful (result is null), otherwise False.
        """
        response = self.call("Collection.removeMonitorsFromSet", monitors=monitors)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def search_alert_policies(
        self,
        managed_networks: List[str] = [],
        queries: List[str] = [],
        sort_column: str = "policyName",
        descending: bool = False,
        page_size: int = 500,
    ) -> List[Dict[str, Any]]:
        """Search and list alert policies.

        Calls Collection.searchAlertPolicies with pagination. Each policy in the result has:
            {
                "policyId": int - Alert policy ID,
                "policyName": str - Alert policy name,
                "actionTypes": list[str] - Action types configured on the policy
                    (e.g. "incident", "webhook", "exec", "run-playbook", "dns-resolve",
                    "email", "trap", "runjob"),
                "managedNetworks": list[str] - Networks the policy belongs to,
            }

        Args:
            managed_networks (List[str]): Networks to search (e.g. ["Default"]). Empty for all.
            queries (List[str]): Query filters (default: [] for all).
            sort_column (str): Column to sort by (default: "policyName").
            descending (bool): Sort descending if True (default: False).
            page_size (int): Records per API call (default: 500).

        Returns:
            List[Dict[str, Any]]: All matching alert policies.
        """
        all_policies: List[Dict[str, Any]] = []
        offset = 0

        while True:
            params = {
                "managedNetworks": managed_networks,
                "queries": queries,
                "sortColumn": sort_column,
                "descending": descending,
                "pageData": {
                    "offset": offset,
                    "pageSize": page_size,
                    "total": 0,
                    "policies": [],
                },
            }
            response = self.call("Collection.searchAlertPolicies", **params)

            if response and type(response) is dict and "result" in response and "policies" in response["result"]:
                batch = response["result"]["policies"]
            else:
                break

            all_policies.extend(batch)

            if len(batch) < page_size:
                break

            offset += page_size

        return all_policies

    def save_alert_policy(self, policy: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create or update an alert policy.

        Calls Collection.saveAlertPolicy. The response mirrors the input policy object.
        Use policyId=-1 (or omit) to create a new policy; provide an existing policyId to update.

        The policy object has:
            {
                "policyId": int - Policy ID (-1 for new),
                "policyName": str - Policy name,
                "actionTypes": list[str] - Action types on the policy (e.g. ["webhook", "email",
                    "trap", "exec", "run-playbook", "dns-resolve", "incident", "runjob"]),
                "managedNetworks": list[str] - Networks this policy applies to (e.g. ["Default"]),
            }

        Args:
            policy (Dict[str, Any]): Alert policy object to save.

        Returns:
            Dict[str, Any]: The saved policy object, or None on failure.
        """
        response = self.call("Collection.saveAlertPolicy", policy=policy)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    # =====================================================
    # Maps / Topology
    # =====================================================

    def get_map(self, map_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific map by ID.

        Calls Maps.getMap. The result has:
            {
                "mapId": int - Map ID,
                "name": str - Map name,
                "mapType": str - Map type (e.g. "device"),
                "nodes": list - Map node objects,
                "managedNetworks": list[str] - Networks the map belongs to,
                "props": dict - Additional map properties,
            }

        Args:
            map_id (int): The ID of the map to retrieve.

        Returns:
            Dict[str, Any]: The map object if found, otherwise None.
        """
        response = self.call("Maps.getMap", mapId=map_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def get_map_tree(self) -> Optional[Dict[str, Any]]:
        """Get the full map tree structure.

        Calls Maps.getMapTree (no params). The result has:
            {
                "maps": list[dict] - All maps, each with:
                    {
                        "mapId": int - Map ID,
                        "name": str - Map name,
                        "mapType": str - Map type (e.g. "device"),
                        "networks": list[str] - Networks the map belongs to,
                    }
                "edges": list - Map relationship edges,
                "mapStates": dict - Current state info keyed by mapId,
            }

        Returns:
            Dict[str, Any]: The map tree result dict, or None on failure.
        """
        response = self.call("Maps.getMapTree")

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def delete_maps(self, map_ids: List[int], recurse: bool = False) -> bool:
        """Delete one or more maps.

        Calls Maps.deleteMaps. Returns true (bool) on success.

        Args:
            map_ids (List[int]): List of map IDs to delete.
            recurse (bool): Whether to recursively delete child maps (default: False).

        Returns:
            bool: True if the maps were deleted successfully, otherwise False.
        """
        response = self.call("Maps.deleteMaps", mapIds=map_ids, recurse=recurse)

        if response and type(response) is dict and "result" in response and response["result"] is True:
            return True
        return False

    def save_map(self, map_obj: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create or update a network topology map.

        Calls Maps.saveMap. The response mirrors the input map object.
        Use an existing mapId to update or a new mapId to create.

        The map object has:
            {
                "mapId": int - Map ID,
                "name": str - Map name,
                "mapType": str - Map type (e.g. "device"),
                "nodes": list[dict] - Node objects, each with:
                    {
                        "nodeType": str - Node type (e.g. "device"),
                        "nodeId": {
                            "uuid": str - Device UUID,
                            "network": str - Network name (e.g. "Default"),
                        },
                        "props": {"x": int, "y": int} - Canvas position,
                    }
                "managedNetworks": list[str] - Networks the map belongs to,
                "props": dict - Map-level properties (e.g. {"links": []}),
            }

        Args:
            map_obj (Dict[str, Any]): Map object to save.

        Returns:
            Dict[str, Any]: The saved map object, or None on failure.
        """
        response = self.call("Maps.saveMap", map=map_obj)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    # =====================================================
    # Dashboard
    # =====================================================

    def get_all_dashboards(self) -> List[Dict[str, Any]]:
        """Get all dashboards.

        Calls Dashboard.getAllDashboards (no params). Returns the result list directly
        (not paginated). Each dashboard has:
            {
                "dashboardId": int - Dashboard ID,
                "owner": str - Username of the owner,
                "shared": bool - Whether the dashboard is shared,
                "dashboardName": str - Dashboard name,
                "managedNetworks": list[str] - Networks the dashboard belongs to,
                "definition": {
                    "rows": list[dict] - Each row has:
                        {
                            "rowHeight": int (optional) - Row height in pixels,
                            "widgets": list[dict] - Each widget has:
                                {
                                    "id": str - Widget ID (sequential, e.g. "0"),
                                    "type": str - Widget type: "text", "inventory",
                                        "violations", "map",
                                    "title": str - Widget title,
                                    "config": dict - Widget-type-specific config,
                                }
                        }
                }
            }

        Returns:
            List[Dict[str, Any]]: List of all dashboards.
        """
        response = self.call("Dashboard.getAllDashboards")

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return []

    def delete_dashboard(self, dashboard_id: int) -> bool:
        """Delete a dashboard.

        Calls Dashboard.deleteDashboard. Returns null on success.

        Args:
            dashboard_id (int): The ID of the dashboard to delete.

        Returns:
            bool: True if successful (result is null), otherwise False.
        """
        response = self.call("Dashboard.deleteDashboard", dashboardId=dashboard_id)

        if response and type(response) is dict and "result" in response and response["result"] in (None, "None"):
            return True
        return False

    def save_dashboard(self, dashboard: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create or update a dashboard.

        Calls Dashboard.saveDashboard. The response mirrors the input dashboard object.
        See get_all_dashboards() for the full dashboard structure.

        Args:
            dashboard (Dict[str, Any]): Dashboard object to save. Key fields:
                {
                    "dashboardId": int - Dashboard ID (-1 for new),
                    "dashboardName": str - Dashboard name,
                    "owner": str - Username of the owner,
                    "shared": bool - Whether the dashboard is shared,
                    "managedNetworks": list[str] - Networks (e.g. ["Default"]),
                    "definition": {"rows": [...]} - Widget layout (see get_all_dashboards),
                }

        Returns:
            Dict[str, Any]: The saved dashboard object, or None on failure.
        """
        response = self.call("Dashboard.saveDashboard", dashboard=dashboard)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    # =====================================================
    # FileStore
    # =====================================================

    def get_device_file_store_entries(
        self,
        ip_address: str,
        network: str = "Default",
        offset: int = 0,
        page_size: int = 1000,
    ) -> List[Dict[str, Any]]:
        """Get file store entries for a device.

        Args:
            ip_address (str): The IP address of the device.
            network (str): The name of the network.
            offset (int): The offset for pagination.
            page_size (int): The number of entries per page.

        Returns:
            List[Dict[str, Any]]: List of file store entries.
        """
        params = {
            "network": network,
            "ipAddress": ip_address,
            "pageData": {
                "offset": offset,
                "pageSize": page_size,
            },
        }
        response = self.call("FileStore.getDeviceFileStoreEntries", **params)

        if response and type(response) is dict and "result" in response and "entries" in response["result"]:
            return response["result"]["entries"]
        return []

    # =====================================================
    # Plugins/Execution
    # =====================================================

    def get_execution_details(self, execution_id: int) -> List[Dict[str, Any]]:
        """Get details of a job execution.

        Args:
            execution_id (int): The ID of the execution.

        Returns:
            List[Dict[str, Any]]: List of ToolRunDetails records (one per device), otherwise empty list.
        """
        response = self.call("Plugins.getExecutionDetails", executionId=execution_id)

        if response and type(response) is dict and "result" in response:
            result = response["result"]
            if isinstance(result, list):
                return result
        return []

    def get_execution_record(self, execution_id: int) -> Optional[Dict[str, Any]]:
        """Get the execution record for a job execution.

        Args:
            execution_id (int): The ID of the execution.

        Returns:
            Dict[str, Any]: The execution record if found, otherwise None.
        """
        response = self.call("Plugins.getExecutionRecord", executionId=execution_id)

        if response and type(response) is dict and "result" in response:
            return response["result"]
        return None

    def get_execution_output(self, execution_id: int, record_id: int) -> str:
        """Fetch the raw command output for a single device execution record.

        The JSON-RPC ``Plugins.getExecutionDetails`` response contains a
        ``gridData`` field that holds a status summary (e.g. ``"OK,ip,0\\n"``)
        and NOT the actual command output text.  The real output is served by
        the LVI web servlet at::

            GET /servlet/pluginDetail?executionId=<id>&recordId=<id>

        where ``recordId`` is the ``id`` field from a ``getExecutionDetails``
        record.

        Args:
            execution_id: The execution ID (``executionId`` from the job result).
            record_id: The per-device record ID (``id`` from ``getExecutionDetails``).

        Returns:
            The raw output text, or an empty string if the request fails.
        """
        url = f"https://{self.host}/servlet/pluginDetail"
        params = {"executionId": execution_id, "recordId": record_id}
        try:
            response = self.lvi_client.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            return response.text
        except Exception as exc:
            logger.warning(
                "get_execution_output failed for executionId=%s recordId=%s: %s",
                execution_id,
                record_id,
                exc,
            )
            return ""

    # =====================================================
    # ZeroTouch
    # =====================================================

    def search_zero_touch_history(
        self,
        networks: List[str] = [],
        queries: List[str] = [],
        offset: int = 0,
        page_size: int = 1000,
        sort_column: str = "timestamp",
        descending: bool = True,
    ) -> List[Dict[str, Any]]:
        """Search for ZeroTouch provisioning history.

        Args:
            networks (List[str]): List of networks to search in. Empty for all networks.
            queries (List[str]): List of search queries.
            offset (int): The offset for pagination.
            page_size (int): The number of entries per page.
            sort_column (str): The column to sort by.
            descending (bool): Whether to sort in descending order.

        Returns:
            List[Dict[str, Any]]: List of ZeroTouch history entries.
        """
        params = {
            "networks": networks,
            "queries": queries,
            "pageData": {
                "offset": offset,
                "pageSize": page_size,
            },
            "sortColumn": sort_column,
            "descending": descending,
        }
        response = self.call("ZeroTouch.searchHistory", **params)

        if response and type(response) is dict and "result" in response and "history" in response["result"]:
            return response["result"]["history"]
        return []
