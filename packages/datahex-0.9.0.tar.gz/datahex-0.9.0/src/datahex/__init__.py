from importlib.metadata import version

__version__ = version("datahex")

__all__ = [
    "set_server",
    "get_data",
    "get_history",
    "ask",
    "get_catalog",
    "get_info",
    "get_timeseries",
]

from .hub import (
    set_server,
    get_data,
    get_history,
)

from .hex import (
    ask,
    get_catalog,
    get_info,
    get_timeseries,
)
