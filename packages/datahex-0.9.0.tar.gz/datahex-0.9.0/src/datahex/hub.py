import ipynbname
import io
import json
import os
import pandas as pd
import requests
import sys
import time

TIME_WAIT = 0.5

_DEFAULT_HOST = 'http://gis.db-asset.com/datahub'
_server_path = None


def set_server(path='main'):
    global _server_path
    _server_path = None if path == 'main' else path


def _get_userfile():
    try:
        return f'[notebook] {ipynbname.path()}'.encode('utf-8')
    except Exception:
        argv = ' '.join(sys.argv)
        return f'[command] {argv}'.encode('utf-8')


def _get_host():
    base = os.environ.get('DATAHUB_HOST', _DEFAULT_HOST)
    if _server_path:
        return f'{base}/{_server_path}'
    return base


def get_data(tickers, fields='close', **kwargs):
    host = _get_host()
    path = 'get_data/df'
    url = f'{host}/{path}'
    headers = {
        'userfile': _get_userfile(),
        'pid': str(os.getpid()),
        'Content-Type':'application/json',
        'charset':'UTF-8',
        'Accept':'*/*'
    }
    data = {
        'tickers': tickers,
        'fields': fields,
        'overs': kwargs
    }
    response = requests.post(url, headers=headers, data=json.dumps(data, ensure_ascii=False, indent='\t'))
    time.sleep(TIME_WAIT)
    if response.status_code != 200:
        raise ValueError(response.content.decode('utf-8'))
    byte_parquet = io.BytesIO(response.content)
    result = pd.read_parquet(byte_parquet)
    return result


def get_history(tickers, fields='close', start_date='1900-01-01', end_date='2199-12-31', **kwargs):
    host = _get_host()
    path = 'get_history/df'
    url = f'{host}/{path}'
    headers = {
        'userfile': _get_userfile(),
        'pid': str(os.getpid()),
        'Content-Type':'application/json',
        'charset':'UTF-8',
        'Accept':'*/*'
    }
    data = {
        'tickers': tickers,
        'fields': fields,
        'start_date': start_date,
        'end_date': end_date,
        'overs': kwargs
    }
    response = requests.post(url, headers=headers, data=json.dumps(data, ensure_ascii=False, indent='\t'))
    time.sleep(TIME_WAIT)
    if response.status_code != 200:
        raise ValueError(response.content.decode('utf-8'))
    byte_parquet = io.BytesIO(response.content)
    result = pd.read_parquet(byte_parquet)
    return result
