import json
import os
import pandas as pd
import requests

_DEFAULT_HOST = 'http://gis.db-asset.com/datahex'


def _get_host():
    return os.environ.get('DATAHEX_HOST', _DEFAULT_HOST)


def _post_json(path, data):
    """POST JSON to a tool endpoint and return the parsed response."""
    host = _get_host()
    url = f'{host}/{path}'
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, headers=headers, data=json.dumps(data, ensure_ascii=False))
    if response.status_code != 200:
        raise ValueError(response.content.decode('utf-8'))
    return response.json()


def _unwrap(result):
    """Extract data from server response envelope."""
    data = result.get('data', result)
    if isinstance(data, str):
        data = json.loads(data)
    return data


def ask(query):
    """Ask a natural language question about financial data.

    Args:
        query: Natural language query (e.g. 'S&P 500 인덱스 찾아줘')

    Returns:
        str: Response text from the Gemini-powered data chat.
    """
    host = _get_host()
    url = f'{host}/mcp/'
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    data = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'tools/call',
        'params': {
            'name': 'ask',
            'arguments': {'query': query},
        },
    }
    response = requests.post(url, headers=headers, data=json.dumps(data, ensure_ascii=False))
    if response.status_code != 200:
        raise ValueError(response.content.decode('utf-8'))
    result = response.json().get('result', {})
    content = result.get('content', [])
    return content[0]['text'] if content else ''


def get_catalog(category='all'):
    """Get the data catalog as a DataFrame.

    Columns: category, symbol, role, base_item, options, description.
    Items have role='primary' or 'secondary'. Secondary items include
    base_item (the primary item they derive from) and options (price type).

    Args:
        category: 'all', 'item', or 'entity'.

    Returns:
        pd.DataFrame with one row per symbol.
    """
    result = _post_json('tools/catalog', {'category': category, 'output_format': 'json'})
    data = _unwrap(result)
    frames = []
    for key, records in data.items():
        df = pd.DataFrame(records)
        df['category'] = key
        frames.append(df)
    df = pd.concat(frames, ignore_index=True) if len(frames) > 1 else frames[0]
    cols = ['category'] + [c for c in df.columns if c != 'category']
    return df[cols].where(df[cols].notna(), None)


def get_info(symbols):
    """Get detailed information about symbol(s).

    For a single symbol string, returns its metadata dict directly (or None).
    For a list, returns {symbol: metadata_dict} for each symbol.

    Item metadata includes all item_info fields (name, kind, pr_ntr_tr, etc.)
    for primary items, or {base_item, price_type, description} for secondary.
    Entity metadata includes all entity_info fields (name, pit, source, etc.).

    Args:
        symbols: Symbol string or list (e.g. 'SPX Index' or ['SPX Index', 'TOTALSL']).

    Returns:
        dict (single) or dict of dicts (list). None if symbol not found.
    """
    singular = isinstance(symbols, str)
    result = _post_json('tools/symbol_info', {'symbols': symbols})
    data = _unwrap(result)
    if singular:
        return next(iter(data.values())) if data else None
    return data


def get_timeseries(symbols, price_type=None, start=None, end=None, as_of=None, subset=None):
    """Get time series data for symbol(s) as a DataFrame.

    Args:
        symbols: Symbol string or list (e.g. 'SPX Index' or ['SPX Index', 'TOTALSL']).
        price_type: 'pr' (price), 'tr' (total return), or 'ntr' (net total return).
            Uses symbol's default if None. Cannot be set for secondary tickers.
        start: Start date (YYYY-MM-DD). Defaults to full history if None.
        end: End date (YYYY-MM-DD). Defaults to latest available if None.
        as_of: Point-in-time cutoff date (YYYY-MM-DD) for PIT entities.
            Defaults to today. Only valid for entities with pit=1.
        subset: 'pit_raw' to get full PIT revision history (dt, as_of, value).
            Only valid for PIT entities.

    Returns:
        pd.DataFrame with dt index and one column per symbol.
        If subset='pit_raw': dict of {symbol: [{dt, as_of, value}, ...]}.
    """
    req = {'symbols': symbols}
    if price_type:
        req['price_type'] = price_type
    req['start_date'] = start or '1900-01-01'
    if end:
        req['end_date'] = end
    if as_of:
        req['as_of'] = as_of
    if subset:
        req['subset'] = subset
    result = _post_json('tools/timeseries', req)
    data = _unwrap(result)
    if subset == 'pit_raw':
        if isinstance(symbols, list) and len(symbols) > 1:
            raise ValueError("subset='pit_raw' supports only a single symbol.")
        key = symbols if isinstance(symbols, str) else symbols[0]
        records = data.get(key, [])
        df = pd.DataFrame(records)
        if not df.empty:
            df['dt'] = pd.to_datetime(df['dt'])
            df['as_of'] = pd.to_datetime(df['as_of'])
            df = df.set_index('dt').sort_index()
            df.index.name = 'dt'
        return df
    df = pd.DataFrame(data).sort_index()
    df.index = pd.to_datetime(df.index)
    df.index.name = 'dt'
    return df
