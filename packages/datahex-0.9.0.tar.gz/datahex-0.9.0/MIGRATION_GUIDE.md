# Migration Guide: datahub → datahex

`datahub` 패키지는 `datahex`로 통합되었습니다. 
최대한 기존 코드에서 import 부분만 수정하면 되도록 맞췄습니다. 
부득이하게 일부 변경사항이 있으므로 아래 내용을 참고하여 수정하시기 바랍니다.

## 패키지 설치

```bash
pip install datahex
```

## Import

```python
# Before
import datahub as dh

# After
import datahex as dh
```

## 변경사항

- get_timeseries 결과 데이터프레임 칼럼명 변경

```python
# Before
dh.get_timeseries('OEUSKLAC Index')
# returns dataframe [ref_dt, val]

dh.get_timeseries('OEUSKLAC Index', subset='full')
# returns dataframe [ref_dt, val, get_dt]

# After
dh.get_timeseries('OEUSKLAC Index')
# returns dataframe [dt, value]

dh.get_timeseries('OEUSKLAC Index', subset='pit_raw')
# returns dataframe [dt, value, as_of]
```

