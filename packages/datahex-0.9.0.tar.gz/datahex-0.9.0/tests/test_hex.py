"""Tests for datahex client functions."""

from unittest.mock import patch
import pytest

from datahex.hex import get_catalog, get_info, get_timeseries


# -- get_info ----------------------------------------------------------------

class TestGetInfo:
    """Test get_info with real symbol structures."""

    def test_item_primary(self):
        """SPX Index — primary item with full item_info row."""
        server_response = {'data': {'SPX Index': {
            'category': 'item',
            'role': 'primary',
            'name': 'S&P 500 Index',
            'kind': 'index',
            'class': '선진국주식',
            'currency': 'USD',
            'pr_ntr_tr': 'pr',
            'pr_param': '{"method": "load_bloomberg"}',
            'ntr_param': '{"method": "load_bloomberg", "ticker": "SPTR500N Index"}',
            'tr_param': '{"method": "load_bloomberg", "ticker": "SPTR Index"}',
        }}}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info('SPX Index')
        assert result['category'] == 'item'
        assert result['role'] == 'primary'
        assert result['name'] == 'S&P 500 Index'
        assert result['pr_ntr_tr'] == 'pr'
        assert 'item' not in result

    def test_item_secondary(self):
        """SPNASEUN Index — secondary ticker of SPNASEUP Index."""
        server_response = {'data': {'SPNASEUN Index': {
            'category': 'item',
            'role': 'secondary',
            'base_item': 'SPNASEUP Index',
            'price_type': 'ntr',
            'description': 'S&P North American Expanded Technology Software Index. NTR of SPNASEUP Index. index',
        }}}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info('SPNASEUN Index')
        assert result['role'] == 'secondary'
        assert result['base_item'] == 'SPNASEUP Index'
        assert result['price_type'] == 'ntr'

    def test_entity_fred(self):
        """TOTALSL — FRED-sourced entity with PIT."""
        server_response = {'data': {'TOTALSL': {
            'category': 'entity',
            'name': 'Federal Reserve Consumer Credit Outstanding Amount Total SA',
            'pit': 1,
            'source': 'fred',
            'unit': 'Millions of U.S. Dollars',
        }}}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info('TOTALSL')
        assert result['category'] == 'entity'
        assert result['pit'] == 1
        assert result['source'] == 'fred'
        assert 'entity' not in result

    def test_entity_gis(self):
        """TOTALSL YOY — GIS-derived entity."""
        server_response = {'data': {'TOTALSL YOY': {
            'category': 'entity',
            'name': 'Federal Reserve Consumer Credit Outstanding Amount Total YoY SA',
            'pit': 1,
            'source': 'gis',
            'unit': 'Percent',
        }}}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info('TOTALSL YOY')
        assert result['source'] == 'gis'
        assert result['unit'] == 'Percent'

    def test_entity_bloomberg(self):
        """LEI YOY Index — Bloomberg-sourced entity."""
        server_response = {'data': {'LEI YOY Index': {
            'category': 'entity',
            'name': None,
            'pit': 1,
            'source': 'bloomberg',
        }}}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info('LEI YOY Index')
        assert result['source'] == 'bloomberg'
        assert result['name'] is None

    def test_singular_returns_value(self):
        server_response = {'data': {'e0055': {'category': 'entity'}}}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info('e0055')
        assert result == {'category': 'entity'}

    def test_singular_not_found(self):
        server_response = {'data': {'NOSYMBOL': None}}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info('NOSYMBOL')
        assert result is None

    def test_list_returns_dict(self):
        server_response = {'data': {
            'SPX Index': {'category': 'item', 'role': 'primary'},
            'TOTALSL': {'category': 'entity'},
        }}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info(['SPX Index', 'TOTALSL'])
        assert isinstance(result, dict)
        assert 'SPX Index' in result
        assert 'TOTALSL' in result

    def test_singular_empty_data(self):
        server_response = {'data': {}}
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_info('e0055')
        assert result is None


# -- get_catalog -------------------------------------------------------------

class TestGetCatalog:
    def test_returns_df_with_category_column(self):
        server_response = {
            'data': {
                'item': [{'symbol': 'SPX Index', 'role': 'primary'}],
                'entity': [{'symbol': 'TOTALSL'}],
            }
        }
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_catalog()
        assert 'category' in result.columns
        assert 'symbol' in result.columns
        assert set(result['category']) == {'item', 'entity'}

    def test_handles_string_data(self):
        server_response = {
            'data': '{"item": [{"symbol": "SPX Index"}]}'
        }
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_catalog(category='item')
        assert 'category' in result.columns
        assert result.iloc[0]['category'] == 'item'

    def test_single_category(self):
        server_response = {
            'data': {
                'item': [{'symbol': 'SPX Index', 'role': 'primary', 'options': 'pr | ntr | tr'}],
            }
        }
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_catalog(category='item')
        assert len(result) == 1
        assert result.iloc[0]['category'] == 'item'


# -- get_timeseries ----------------------------------------------------------

class TestGetTimeseries:
    def test_returns_df(self):
        server_response = {
            'data': {
                'SPX Index': {'2024-01-02': 4769.83, '2024-01-03': 4704.81}
            }
        }
        with patch('datahex.hex._post_json', return_value=server_response):
            result = get_timeseries('SPX Index', start='2024-01-01')
        assert result.index.name == 'dt'
        assert 'SPX Index' in result.columns
        assert result.loc['2024-01-02', 'SPX Index'] == 4769.83

    def test_passes_price_type(self):
        with patch('datahex.hex._post_json', return_value={'data': {}}) as mock:
            get_timeseries('SPX Index', price_type='tr', start='2024-01-01')
        call_args = mock.call_args[0][1]
        assert call_args['price_type'] == 'tr'

    def test_passes_as_of(self):
        with patch('datahex.hex._post_json', return_value={'data': {}}) as mock:
            get_timeseries('TOTALSL', as_of='2024-06-01', start='2024-01-01')
        call_args = mock.call_args[0][1]
        assert call_args['as_of'] == '2024-06-01'


# -- Integration tests (require live server) ---------------------------------

@pytest.mark.integration
class TestIntegration:
    """Run with: pytest -m integration"""

    def test_get_info_item_primary(self):
        result = get_info('SPX Index')
        assert result['category'] == 'item'
        assert result['role'] == 'primary'
        assert result['name'] == 'S&P 500 Index'
        assert result['pr_ntr_tr'] == 'pr'
        assert 'item' not in result

    def test_get_info_item_secondary(self):
        result = get_info('SPNASEUN Index')
        assert result['category'] == 'item'
        assert result['role'] == 'secondary'
        assert result['base_item'] == 'SPNASEUP Index'
        assert result['price_type'] == 'ntr'

    def test_get_info_entity_fred(self):
        result = get_info('TOTALSL')
        assert result['category'] == 'entity'
        assert result['source'] == 'fred'
        assert result['pit'] == 1
        assert 'entity' not in result

    def test_get_info_entity_gis(self):
        result = get_info('TOTALSL YOY')
        assert result['category'] == 'entity'
        assert result['source'] == 'gis'
        assert result['pit'] == 1

    def test_get_info_entity_bloomberg(self):
        result = get_info('LEI YOY Index')
        assert result['category'] == 'entity'
        assert result['source'] == 'bloomberg'
        assert result['pit'] == 1

    def test_get_info_not_found(self):
        result = get_info('NOSYMBOL_XYZ')
        assert result is None

    def test_get_info_list(self):
        result = get_info(['SPX Index', 'TOTALSL'])
        assert 'SPX Index' in result
        assert 'TOTALSL' in result
        assert result['SPX Index']['category'] == 'item'
        assert result['TOTALSL']['category'] == 'entity'

    def test_get_catalog_has_category_column(self):
        result = get_catalog()
        assert 'category' in result.columns
        assert 'symbol' in result.columns
        assert set(result['category'].unique()) == {'item', 'entity'}
        assert len(result) > 0

    def test_get_catalog_item_has_role(self):
        result = get_catalog(category='item')
        assert 'role' in result.columns
        roles = set(result['role'].dropna().unique())
        assert 'primary' in roles
        assert 'secondary' in roles

    def test_get_timeseries_item(self):
        result = get_timeseries('SPX Index', start='2024-01-01', end='2024-01-31')
        assert 'SPX Index' in result.columns
        assert len(result) > 0

    def test_get_timeseries_secondary_item(self):
        result = get_timeseries('SPNASEUN Index', start='2024-01-01', end='2024-01-31')
        assert 'SPNASEUN Index' in result.columns
        assert len(result) > 0

    def test_get_timeseries_secondary_rejects_price_type(self):
        with pytest.raises(ValueError, match='secondary ticker'):
            get_timeseries('SPNASEUN Index', price_type='pr', start='2024-01-01', end='2024-01-31')

    def test_get_timeseries_entity(self):
        result = get_timeseries('TOTALSL', start='2024-01-01', end='2024-12-31')
        assert 'TOTALSL' in result.columns
        assert len(result) > 0
