# @Time    : 2026/4/6 15:12
# @Author  : YQ Tsui
# @File    : utility.py
# @Purpose :

import re
import sys
import subprocess
import importlib.metadata as importlib_metadata


def hidden_subprocess_kwargs() -> dict:
    """Return subprocess kwargs that suppress console windows on Windows."""
    if sys.platform != "win32":
        return {}

    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startupinfo.wShowWindow = getattr(subprocess, "SW_HIDE", 0)
    return {
        "creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0),
        "startupinfo": startupinfo,
    }


def get_remote_commit_hash(remote_url, tag="HEAD", short=False) -> str:
    try:
        result = subprocess.run(
            ["git", "ls-remote", remote_url, "HEAD"],
            capture_output=True,
            text=True,
            check=True,
            encoding="utf-8",
            **hidden_subprocess_kwargs(),
        )
        commit_hash = result.stdout.strip().split("\t")[0]
        if short:
            return commit_hash[:7]
        return commit_hash
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to get remote commit hash: {e.stderr}") from e


def get_latest_tag_from_remote(remote_url) -> tuple[str, str]:
    """
    Get the latest tag and its commit hash from a remote Git repository.
    Args:
        remote_url (str): The URL of the remote Git repository.
    Returns:
        tuple[str, str]: A tuple containing the latest tag and its commit hash.
    """

    result = subprocess.run(
        ["git", "ls-remote", "--tags", remote_url],
        capture_output=True,
        text=True,
        check=True,
        encoding="utf-8",
        **hidden_subprocess_kwargs(),
    )

    def compare_tag_string(tag1: str, tag2: str) -> int:
        """
        Compare two tag strings.
        Returns:
            -1 if tag1 < tag2, 0 if tag1 == tag2, 1 if tag1 > tag2
        """
        # Remove 'v' prefix and split by '.' to compare version parts
        if tag1 == tag2:
            return 0
        if tag1 == "":
            return -1
        if tag2 == "":
            return 1

        parts1 = tag1.lstrip("v").split(".")
        parts2 = tag2.lstrip("v").split(".")

        # Compare each part numerically
        for p1, p2 in zip(parts1, parts2, strict=False):
            if p1.isdigit() and p2.isdigit():
                if int(p1) < int(p2):
                    return -1
                elif int(p1) > int(p2):
                    return 1
            else:
                if p1 < p2:
                    return -1
                elif p1 > p2:
                    return 1

        # If all compared parts are equal, check lengths
        return len(parts1) - len(parts2)

    latest_version = ""
    latest_commit_hash = ""
    for line in result.stdout.strip().split("\n"):
        obj = re.match(r"([0-9a-f]+)\s+refs/tags/v?(\d+(\.\d+)+)", line)
        if obj:
            commit_hash, tag, *_ = obj.groups()
            if compare_tag_string(tag, latest_version) > 0:
                latest_version = tag
                latest_commit_hash = commit_hash
    return latest_version, latest_commit_hash


def get_remote_version(remote_url, tag="HEAD", major=False) -> str:
    latest_tag, tag_commit_hash = get_latest_tag_from_remote(remote_url)
    if not bool(latest_tag):
        return "0.0.0"
    if major:
        return latest_tag
    try:
        commit_hash = get_remote_commit_hash(remote_url, tag)
    except RuntimeError:
        commit_hash = "unknown"
    if commit_hash == "":
        commit_hash = "unknown"
    if commit_hash == tag_commit_hash:
        return latest_tag
    match = re.match(r"(.*?)(\d+)$", latest_tag)
    prefix, tail = match.groups()
    return f"{prefix}{int(tail) + 1}+git.{commit_hash[:8]}"


def _candidate_distribution_names(module_name: str) -> list[str]:
    candidates = []
    seen = set()

    def add(name: str) -> None:
        if name and name not in seen:
            seen.add(name)
            candidates.append(name)

    add(module_name)
    add(module_name.replace("_", "-"))
    add(module_name.replace("-", "_"))

    normalized = re.sub(r"[-_.]+", "-", module_name)
    add(normalized)
    add(normalized.replace("-", "_"))

    return candidates


def get_local_version(module_name: str) -> str:
    for dist_name in _candidate_distribution_names(module_name):
        try:
            return importlib_metadata.version(dist_name)
        except importlib_metadata.PackageNotFoundError:
            continue
        except Exception:
            continue
    return "--"
