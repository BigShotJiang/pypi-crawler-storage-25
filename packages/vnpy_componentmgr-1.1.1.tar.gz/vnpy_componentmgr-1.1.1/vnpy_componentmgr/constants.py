# @Time    : 2026/4/6 14:21
# @Author  : YQ Tsui
# @File    : constants.py
# @Purpose :

VNPY_URL = "ssh://git@gitee.com/arb513330/vnpy.git"

AVAILABLE_GATEWAY = {
    "Ctp": "ssh://git@gitee.com/arb513330/vnpy_ctp.git",
    "Sopt": "ssh://git@gitee.com/arb513330/vnpy_sopt.git",
    "Xt": "ssh://git@gitee.com/arb513330/vnpy_xt.git",
    "XtRedisOrder": "ssh://git@gitee.com/arb513330/vnpy_xtredisorder.git",
}

AVAILABLE_APP = {
    "TradePanels": "ssh://git@gitee.com/arb513330/vnpy_tradepanels.git",
}
