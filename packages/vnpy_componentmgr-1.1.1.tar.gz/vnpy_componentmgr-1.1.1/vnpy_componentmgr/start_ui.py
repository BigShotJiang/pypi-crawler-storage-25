# @Time    : 2026/4/6 20:56
# @Author  : YQ Tsui
# @File    : start_ui.py
# @Purpose :

import traceback

from vnpy.trader.ui import QtWidgets, create_qapp


def run_module_manager() -> int:
    qapp = create_qapp("")

    if not qapp:
        print("Failed to create QApplication.")
        return 1

    try:
        from .componentmgr import ComponentManagementDialog  # noqa: E402,PLC0415

        dialog = ComponentManagementDialog()
        dialog.show()
        return qapp.exec()
    except Exception:
        QtWidgets.QMessageBox.critical(None, "错误", "启动组件管理器失败:\n\n" + traceback.format_exc())
        return 1
