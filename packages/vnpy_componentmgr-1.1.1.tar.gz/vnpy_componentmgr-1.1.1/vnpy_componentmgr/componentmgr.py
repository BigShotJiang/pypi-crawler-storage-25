# @Time    : 2026/4/6 15:07
# @Author  : YQ Tsui
# @File    : componentmgr.py
# @Purpose :

from functools import partial
from vnpy.trader.utility import (
    load_json,
    save_json,
)
from vnpy.trader.ui import QtWidgets, Qt, QtCore
from vnpy.trader.locale import _

from . import __version__
from .constants import AVAILABLE_APP, AVAILABLE_GATEWAY, VNPY_URL
from .widgets import LoadingPlaceholder, UpdatingProgressBar
from .utility import get_local_version, get_remote_version


class _VersionLoadSignals(QtCore.QObject):
    finished = QtCore.Signal(int, str, str)


class _VersionLoadTask(QtCore.QRunnable):
    def __init__(self, row: int, module_name: str, git_url: str) -> None:
        super().__init__()
        self.row = row
        self.module_name = module_name
        self.git_url = git_url
        self.signals = _VersionLoadSignals()

    def run(self) -> None:
        try:
            local_version = get_local_version(self.module_name)
        except Exception:
            local_version = "--"

        try:
            remote_version = get_remote_version(self.git_url)
        except Exception:
            remote_version = "--"

        self.signals.finished.emit(self.row, local_version, remote_version)


class ComponentManagementDialog(QtWidgets.QDialog):
    def __init__(self, parent=None) -> None:
        """"""
        super().__init__(parent)
        self.row_mapping = {}
        self.row_buttons = {}
        self.row_states = {}
        self.loading_rows = set()
        self.version_tasks = {}
        self.dialog_closing = False
        self.update_progress = None
        self.selected_modules = load_json("vnpy_selectmodules.json")
        self.version_thread_pool = QtCore.QThreadPool(self)
        self.version_thread_pool.setMaxThreadCount(8)
        self.init_ui()

    def init_ui(self) -> None:
        """"""
        self.setWindowTitle(_(f"模块管理 - 选择要启用的模块和更新模块 (v{__version__})"))

        self.select_module_at_start_checkbox = QtWidgets.QCheckBox(_("启动vnpy时选择模块？"))
        self.select_module_at_start_checkbox.setChecked(self.selected_modules.get("select_at_start_up", True))

        self.modules_grid = QtWidgets.QTableWidget()
        self.modules_grid.setColumnCount(6)
        self.modules_grid.setColumnWidth(0, 100)
        self.modules_grid.setColumnWidth(1, 200)
        self.modules_grid.setColumnWidth(2, 150)
        self.modules_grid.setColumnWidth(3, 150)
        self.modules_grid.setColumnWidth(4, 75)
        self.modules_grid.setColumnWidth(5, 40)
        self.modules_grid.setHorizontalHeaderLabels(
            [_("模块"), _("Python包"), _("本地版本"), _("最新版本"), _("更新"), _("启用")]
        )
        self.modules_grid.setRowCount(0)
        self.modules_grid.verticalHeader().setVisible(False)
        self.modules_grid.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)
        self.modules_grid.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        button_box = QtWidgets.QDialogButtonBox()
        ok_button = button_box.addButton(_("保存并退出"), QtWidgets.QDialogButtonBox.AcceptRole)
        ok_button.clicked.connect(self.accept)
        cancel_button = button_box.addButton(_("取消"), QtWidgets.QDialogButtonBox.RejectRole)
        cancel_button.clicked.connect(self.reject)
        self.modules_grid.setCellWidget(0, 4, button_box)

        total_height = self.modules_grid.frameWidth() * 2 + self.modules_grid.horizontalHeader().height()

        self._add_row(_("核心"), "vnpy", VNPY_URL, True)
        total_height += self.modules_grid.rowHeight(0)

        for appname, giturl in AVAILABLE_APP.items():
            selected = appname in self.selected_modules.get("APPs", [])
            self._add_row(appname, f"vnpy_{appname.lower()}", giturl, selected)
            total_height += self.modules_grid.rowHeight(self.modules_grid.rowCount() - 1)

        for gwname, giturl in AVAILABLE_GATEWAY.items():
            selected = gwname in self.selected_modules.get("Gateways", [])
            self._add_row(gwname, f"vnpy_{gwname.lower()}", giturl, selected)
            total_height += self.modules_grid.rowHeight(self.modules_grid.rowCount() - 1)

        self.modules_grid.setFixedSize(720, min(900, total_height + 8))

        self.vbox: QtWidgets.QVBoxLayout = QtWidgets.QVBoxLayout()
        self.vbox.addWidget(self.select_module_at_start_checkbox)
        self.vbox.addWidget(self.modules_grid)
        self.vbox.addWidget(button_box)

        self.setLayout(self.vbox)
        self.setFixedWidth(self.sizeHint().width())

    def _add_row(self, app_or_gw_name: str, module_name: str, git_url: str, selected=False, style=None) -> None:
        """
        Add a row to the modules grid.
        """
        row = self.modules_grid.rowCount()
        self.modules_grid.insertRow(row)
        self.row_mapping[app_or_gw_name] = row
        cell_name = QtWidgets.QTableWidgetItem(app_or_gw_name)  # app or gateway name
        self.modules_grid.setItem(row, 0, cell_name)
        cell_module_name = QtWidgets.QTableWidgetItem(module_name)  # module name
        self.modules_grid.setItem(row, 1, cell_module_name)
        self.row_mapping[module_name] = row

        cell_local = QtWidgets.QTableWidgetItem("")  # local version
        cell_local.setTextAlignment(Qt.AlignCenter)
        self.modules_grid.setItem(row, 2, cell_local)
        self.modules_grid.setCellWidget(row, 2, self._create_loading_placeholder())

        cell_latest = QtWidgets.QTableWidgetItem("")
        cell_latest.setTextAlignment(Qt.AlignCenter)
        self.modules_grid.setItem(row, 3, cell_latest)
        self.modules_grid.setCellWidget(row, 3, self._create_loading_placeholder())

        button = QtWidgets.QPushButton(_("更新"))
        button.setObjectName(app_or_gw_name)
        button.setEnabled(False)
        button.clicked.connect(partial(self.update_module, row_idx=row, git_url=git_url))
        self.row_buttons[row] = button
        self.modules_grid.setCellWidget(row, 4, self._create_loading_placeholder(compact=True))

        self.row_states[row] = {
            "module_name": module_name,
            "git_url": git_url,
            "local_version": "--",
            "remote_version": "--",
            "status": "loading",
        }
        self.loading_rows.add(row)
        self._start_version_loading(row, module_name, git_url)

        cell_selected = QtWidgets.QTableWidgetItem()
        cell_selected.setCheckState(Qt.Checked if selected else Qt.Unchecked)
        if app_or_gw_name == _("核心"):
            cell_selected.setFlags(~Qt.ItemIsUserCheckable & Qt.ItemIsEnabled)
        self.modules_grid.setItem(row, 5, cell_selected)

    @staticmethod
    def _create_loading_placeholder(compact: bool = False) -> LoadingPlaceholder:
        return LoadingPlaceholder(compact=compact)

    def _show_action_button(self, row: int) -> QtWidgets.QPushButton | None:
        button = self.row_buttons.get(row)
        if button is None:
            return None

        current_widget = self.modules_grid.cellWidget(row, 4)
        if current_widget is button:
            return button

        if current_widget is not None:
            self.modules_grid.removeCellWidget(row, 4)
            current_widget.deleteLater()

        self.modules_grid.setCellWidget(row, 4, button)
        return button

    def _clear_loading_cell(self, row: int, column: int) -> None:
        widget = self.modules_grid.cellWidget(row, column)
        if widget is None:
            return

        self.modules_grid.removeCellWidget(row, column)
        widget.deleteLater()

    def _start_version_loading(self, row: int, module_name: str, git_url: str) -> None:
        task = _VersionLoadTask(row, module_name, git_url)
        task.signals.finished.connect(self._on_versions_loaded)
        self.version_tasks[row] = task
        self.version_thread_pool.start(task)

    def _on_versions_loaded(self, row: int, local_version: str, remote_version: str) -> None:
        self.version_tasks.pop(row, None)

        if self.dialog_closing:
            return

        state = self.row_states.get(row)
        if state is None:
            return

        state["local_version"] = local_version
        state["remote_version"] = remote_version
        state["status"] = "ready"
        self.loading_rows.discard(row)

        self._clear_loading_cell(row, 2)
        cell_local = self.modules_grid.item(row, 2)
        if cell_local is not None:
            cell_local.setText(local_version)

        self._clear_loading_cell(row, 3)
        cell_latest = self.modules_grid.item(row, 3)
        if cell_latest is not None:
            cell_latest.setText(remote_version)

        self.set_button_status(row)

    def set_button_status(self, row_num: int) -> None:
        state = self.row_states.get(row_num, {})
        status = state.get("status", "loading")

        if status == "loading":
            return

        button = self._show_action_button(row_num)
        if button is None:
            return

        local_version = state.get("local_version", "--")
        remote_version = state.get("remote_version", "--")

        button.setText(_("安装") if local_version in {"--", ""} else _("更新"))

        button.setEnabled(
            status == "ready"
            and bool(remote_version)
            and remote_version not in {"--", local_version}
        )

    def update_module(self, row_idx: int, git_url: str) -> None:
        if self._has_running_update():
            return

        related_module_name = self.modules_grid.item(row_idx, 1).text().strip()
        if not related_module_name:
            QtWidgets.QMessageBox.warning(self, _("错误"), _("无法获取模块名称，无法更新"))
            return
        for row in range(self.modules_grid.rowCount()):
            button = self.row_buttons.get(row)
            if button is not None:
                button.setEnabled(False)
        self.update_progress = UpdatingProgressBar(related_module_name, git_url, self)
        self.vbox.insertWidget(0, self.update_progress)
        QtWidgets.QApplication.processEvents()
        local_version = self.modules_grid.item(row_idx, 2).text().strip()
        install_or_update = _("安装") if local_version in {"--", ""} else _("更新")
        self.update_progress.label.setText(install_or_update)
        self.update_progress.run_update(partial(self.on_update_completed, text=install_or_update))

    def _has_running_update(self) -> bool:
        return self.update_progress is not None and self.update_progress.is_running()

    def _show_update_running_message(self) -> None:
        QtWidgets.QMessageBox.information(self, _("请稍候"), _("模块正在安装或更新，请等待当前任务完成。"))

    def on_update_completed(self, progressor: UpdatingProgressBar, text: str) -> None:
        row = self.row_mapping[progressor.module_name]
        cell = self.modules_grid.item(row, 2)
        state = self.row_states.setdefault(row, {})
        if progressor.error_flag:
            QtWidgets.QMessageBox.critical(self, _(f"{text}失败"), progressor.error_reason + "\n")
            cell.setText(_(f"{text}失败，联系管理员修复。"))
            state["status"] = "error"
        else:
            cell.setText(_(f"已{text}，重启vnpy生效"))
            state["status"] = "restart_required"
        for row_num in range(self.modules_grid.rowCount()):
            self.set_button_status(row_num)
        self.vbox.removeWidget(progressor)
        self.update_progress = None
        for row_num in range(self.modules_grid.rowCount()):
            self.set_button_status(row_num)

    def closeEvent(self, event) -> None:
        if self._has_running_update():
            self._show_update_running_message()
            event.ignore()
            return

        self.dialog_closing = True
        self.loading_rows.clear()
        super().closeEvent(event)

    def save_selection(self):
        select_at_start_up = self.select_module_at_start_checkbox.isChecked()
        selected_apps = []
        selected_gateways = []
        for row in range(self.modules_grid.rowCount()):
            module_name = self.modules_grid.item(row, 0).text()
            if self.modules_grid.item(row, 5).checkState() == Qt.Checked:
                if module_name in AVAILABLE_APP:
                    selected_apps.append(module_name)
                elif module_name in AVAILABLE_GATEWAY:
                    selected_gateways.append(module_name)
        self.selected_modules["select_at_start_up"] = select_at_start_up
        self.selected_modules["APPs"] = selected_apps
        self.selected_modules["Gateways"] = selected_gateways
        save_json("vnpy_selectmodules.json", self.selected_modules)

    def accept(self, /):
        if self._has_running_update():
            self._show_update_running_message()
            return

        self.save_selection()
        super().accept()

    def reject(self) -> None:
        if self._has_running_update():
            self._show_update_running_message()
            return

        super().reject()

