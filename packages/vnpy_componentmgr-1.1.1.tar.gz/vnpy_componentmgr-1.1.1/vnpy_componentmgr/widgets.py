# @Time    : 2026/4/6 21:16
# @Author  : YQ Tsui
# @File    : widgets.py
# @Purpose :

import os
import sys
import subprocess
from collections.abc import Callable

from vnpy.trader.ui import QtWidgets, Qt, QtCore
from vnpy.trader.locale import _

from .utility import hidden_subprocess_kwargs


class LoadingPlaceholder(QtWidgets.QWidget):
    def __init__(self, text: str = "", compact: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.compact = compact
        self.label: QtWidgets.QLabel | None = None
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(8 if compact else 8)
        self.progress_bar.setFixedWidth(25 if compact else 36)
        self.progress_bar.setStyleSheet(
            "QProgressBar {"
            "background-color: #eceff3;"
            "border: 1px solid #d8dde6;"
            "border-radius: 3px;"
            "}"
            "QProgressBar::chunk {"
            "background-color: #c2c8d0;"
            "border-radius: 3px;"
            "}"
        )

        layout = QtWidgets.QHBoxLayout()
        layout.setContentsMargins(6, 2, 6, 2)
        layout.setSpacing(6 if not compact else 0)
        layout.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.progress_bar, alignment=Qt.AlignCenter)

        display_text = text or _("加载中")
        if not compact:
            self.label = QtWidgets.QLabel(display_text)
            self.label.setAlignment(Qt.AlignCenter)
            self.label.setStyleSheet("color: #98a2ad; font-size: 12px;")
            layout.addWidget(self.label, alignment=Qt.AlignCenter)

        self.setLayout(layout)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)


class _UpdateWorker(QtCore.QObject):
    progress = QtCore.Signal(str)
    finished = QtCore.Signal(bool, str)

    def __init__(self, module_name: str, git_url: str) -> None:
        super().__init__()
        self.module_name = module_name
        self.git_url = git_url

    @QtCore.Slot()
    def run(self) -> None:
        pip_url = f"git+{self.git_url}"
        env = os.environ.copy()
        python_dir = os.path.dirname(sys.executable)
        scripts_dir = os.path.join(python_dir, "Scripts")
        env["PATH"] = f"{python_dir};{scripts_dir};{env.get('PATH', '')}"
        # In Windows 11, if using python -m pip xxx, CMD window will repeatedly pop up and disappear.
        # Using pip.exe directly can avoid this issue for unknown reason.
        pip_path = os.path.join(scripts_dir, "pip.exe" if os.name == "nt" else "pip")

        output_lines: list[str] = []
        error_lines: list[str] = []

        try:
            with subprocess.Popen(
                [pip_path, "install", "--upgrade", pip_url],
                text=True,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                encoding="utf-8",
                shell=False,
                env=env,
                **hidden_subprocess_kwargs(),
            ) as process:
                if process.stdout is not None:
                    for line in process.stdout:
                        output_lines.append(line.rstrip())
                        if "ERROR" in line or "error" in line:
                            error_lines.append(line.rstrip())
                        self.progress.emit(line)

                return_code = process.wait()
        except Exception as exc:
            self.finished.emit(False, str(exc))
            return

        if return_code != 0:
            message_lines = error_lines or [line for line in output_lines if line][-10:]
            self.finished.emit(False, "\n".join(message_lines) or _("更新失败，请检查安装日志。"))
            return

        self.finished.emit(True, "")


class UpdatingProgressBar(QtWidgets.QFrame):
    def __init__(self, module_name: str, git_url: str, parent=None):
        super().__init__(parent)
        self.module_name: str = module_name
        self.git_url: str = git_url
        self.error_flag = False
        self.error_reason = ""
        self._thread: QtCore.QThread | None = None
        self._worker: _UpdateWorker | None = None
        self._on_completed: Callable[["UpdatingProgressBar"], None] | None = None
        self._delete_when_finished = False
        self.init_ui()

    def init_ui(self):
        self.setMaximumHeight(100)
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setValue(0)
        self.progress_bar.setAlignment(Qt.AlignCenter)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setStyleSheet(
            "QProgressBar {text-align: center;} QProgressBar::chunk {background-color: #37a0f4;}"
        )
        self.label = QtWidgets.QLabel(_("初始化更新"))
        self.label.setAlignment(Qt.AlignCenter)
        vbox: QtWidgets.QVBoxLayout = QtWidgets.QVBoxLayout()
        vbox.addWidget(self.label)
        vbox.addWidget(self.progress_bar)
        self.setLayout(vbox)

    def run_update(self, on_completed: Callable[["UpdatingProgressBar"], None] = None):
        if self._thread is not None:
            return

        self.error_flag = False
        self.error_reason = ""
        self._on_completed = on_completed
        self._delete_when_finished = False

        self._thread = QtCore.QThread()
        self._worker = _UpdateWorker(self.module_name, self.git_url)
        self._worker.moveToThread(self._thread)

        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self.update_progress)
        self._worker.finished.connect(self._on_update_finished)
        self._worker.finished.connect(self._thread.quit)
        self._worker.finished.connect(self._worker.deleteLater)
        self._thread.finished.connect(self._on_thread_finished)
        self._thread.finished.connect(self._thread.deleteLater)

        self._thread.start()

    def is_running(self) -> bool:
        return self._thread is not None and self._thread.isRunning()

    @QtCore.Slot(bool, str)
    def _on_update_finished(self, succeeded: bool, error_reason: str) -> None:
        self.error_flag = not succeeded
        self.error_reason = error_reason

        if self._on_completed is not None:
            self._on_completed(self)
            self._on_completed = None

        self._delete_when_finished = True

    @QtCore.Slot()
    def _on_thread_finished(self) -> None:
        self._worker = None
        self._thread = None

        if self._delete_when_finished:
            self.deleteLater()

    def update_progress(self, line: str):
        if "Collecting" in line:
            self.label.setText(_("更新中：下载……"))
        if "dependen" in line or "Requirement" in line:
            self.label.setText(_("更新中：安装依赖……"))
        if "Building wheels" in line:
            self.label.setText(_("更新中：构建……"))
        if "Found existing installation" in line or "Uninstalling" in line:
            self.label.setText(_("更新中：发现旧版本，卸载……"))
        if "Successfully installed" in line:
            self.label.setText(_("更新完成"))
