# @Time    : 2026/4/6 14:19
# @Author  : YQ Tsui
# @File    : __init__.py.py
# @Purpose :

import importlib.metadata as importlib_metadata

try:
    __version__ = importlib_metadata.version("vnpy_componentmgr")
except importlib_metadata.PackageNotFoundError:
    __version__ = "dev"

__all__ = ["ComponentManagementDialog"]
