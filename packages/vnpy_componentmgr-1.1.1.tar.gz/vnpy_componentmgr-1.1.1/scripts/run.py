# @Time    : 2026/4/7 13:57
# @Author  : YQ Tsui
# @File    : run.py
# @Purpose :

import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from vnpy_componentmgr.start_ui import run_module_manager  # noqa: E402


if __name__ == "__main__":
    run_module_manager()
