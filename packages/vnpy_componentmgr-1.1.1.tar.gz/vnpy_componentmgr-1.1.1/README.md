
<h1 style="text-align: center;">VeighNa框架的模块管理器</h1>

***

<p style="text-align: center;">
    <img src ="https://img.shields.io/badge/version-1.0.3-blueviolet.svg" alt=""/>
    <img src ="https://img.shields.io/badge/platform-windows|linux-yellow.svg" alt=""/>
    <img src ="https://img.shields.io/badge/python-3.11|3.12|3.13-blue.svg" alt=""/>
    <img src ="https://img.shields.io/github/license/vnpy/vnpy.svg?color=orange" alt=""/>
</p>

## 说明

管理vnpy模块的安装/更新和加载。

## 安装

安装环境推荐基于4.3.0.5版本以上的【[**VeighNa Studio**](https://www.vnpy.com)】。

直接使用pip命令：

```
pip install vnpy_componentmgr
```

或者下载源代码后，解压后在cmd中运行：

```
pip install .
```
