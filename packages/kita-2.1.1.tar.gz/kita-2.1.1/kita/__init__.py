"""
Kita Document Processing SDK

A Python client library for the Kita Document Processing API.

Example:
    from kita import KitaClient

    client = KitaClient(api_key="kita_prod_...")
    result = client.process("document.pdf", "bank_statement")
    print(result)
"""

import requests
import time
import os
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Dict, Any, List, Iterator, Union
from pathlib import Path
import json


class _Spinner:
    """Simple spinner for CLI progress indication"""

    FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']

    def __init__(self, message: str = "Processing"):
        self.message = message
        self._stop_event = threading.Event()
        self._thread = None

    def _spin(self):
        idx = 0
        while not self._stop_event.is_set():
            frame = self.FRAMES[idx % len(self.FRAMES)]
            sys.stdout.write(f'\r{frame} {self.message}...')
            sys.stdout.flush()
            idx += 1
            time.sleep(0.1)

    def start(self):
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()

    def stop(self, final_message: str = None):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=0.5)
        # Clear the line
        sys.stdout.write('\r' + ' ' * 50 + '\r')
        if final_message:
            print(final_message)
        sys.stdout.flush()


class _ProgressBar:
    """Simple progress bar for batch processing"""

    def __init__(self, total: int, prefix: str = "Processing"):
        self.total = total
        self.prefix = prefix
        self.current = 0

    def update(self, current: int, status: str = ""):
        self.current = current
        filled = int(30 * current / self.total) if self.total > 0 else 0
        bar = '█' * filled + '░' * (30 - filled)
        percent = (current / self.total * 100) if self.total > 0 else 0
        status_text = f" - {status}" if status else ""
        sys.stdout.write(f'\r{self.prefix}: [{bar}] {current}/{self.total} ({percent:.0f}%){status_text}')
        sys.stdout.flush()

    def finish(self, message: str = None):
        sys.stdout.write('\r' + ' ' * 80 + '\r')
        if message:
            print(message)
        sys.stdout.flush()


__version__ = "2.1.1"

# Production API URL - override with KITA_API_URL environment variable
DEFAULT_API_URL = "https://portal.usekita.com"


class KitaError(Exception):
    """Base exception for Kita SDK errors"""
    pass


class KitaAPIError(KitaError):
    """API returned an error response"""
    def __init__(self, status_code: int, message: str, details: Any = None):
        self.status_code = status_code
        self.message = message
        self.details = details
        super().__init__(f"API Error {status_code}: {message}")


class KitaAuthenticationError(KitaAPIError):
    """Authentication failed"""
    pass


class KitaRateLimitError(KitaAPIError):
    """Rate limit exceeded"""
    def __init__(self, status_code: int, message: str, retry_after: int = None, details: Any = None):
        super().__init__(status_code, message, details)
        self.retry_after = retry_after


class DocumentResult:
    """Represents a processed document result with dict-like access"""

    def __init__(self, data: Dict[str, Any]):
        self._data = data

    # Dict-like access
    def __getitem__(self, key: str) -> Any:
        """Allow dict-like access: result['metadata']"""
        return self._data[key]

    def __contains__(self, key: str) -> bool:
        """Allow 'in' operator: 'metadata' in result"""
        return key in self._data

    def get(self, key: str, default: Any = None) -> Any:
        """Dict-like get with default"""
        return self._data.get(key, default)

    def keys(self):
        """Return available keys"""
        return self._data.keys()

    @property
    def status(self) -> str:
        return self._data.get('status', 'unknown')

    @property
    def document_id(self) -> Optional[int]:
        """Get document ID (needed for export downloads)"""
        val = (
            self._data.get('documentId')
            or self._data.get('document_id')
            or self._data.get('id')
        )
        return int(val) if val is not None else None

    @property
    def document_type(self) -> str:
        return self._data.get('document_type', '')

    @property
    def metadata(self) -> Dict[str, Any]:
        return self._data.get('metadata', {})

    # -- Extracted data (standard wrapper in v2) --

    @property
    def extracted_data(self) -> Dict[str, Any]:
        """Get extracted data container (all document types in v2)"""
        return self._data.get('extracted_data', {})

    def _from_extracted(self, key: str, default: Any = None) -> Any:
        """Look up a key in extracted_data first, then fall back to top-level."""
        ed = self._data.get('extracted_data')
        if isinstance(ed, dict) and key in ed:
            return ed[key]
        val = self._data.get(key)
        return val if val is not None else default

    # -- Bank statement / passbook / credit card statement --

    @property
    def transactions(self) -> List[Dict[str, Any]]:
        """Get transactions (bank statements, passbooks, credit card statements)"""
        return self._from_extracted('transactions', [])

    @property
    def metrics(self) -> Dict[str, Any]:
        """Get metrics (bank statements, credit reports)"""
        return self._from_extracted('metrics', {})

    @property
    def fraud_detection(self) -> Optional[Dict[str, Any]]:
        """Get fraud detection results"""
        return self._data.get('fraud_detection')

    @property
    def suspicious_accounts(self) -> Optional[Dict[str, Any]]:
        """Get suspicious account patterns (outlier transactions, frequent descriptions, circular transfers)"""
        return self._from_extracted('suspicious_accounts')

    # -- Payslip --

    @property
    def employment_info(self) -> Optional[Dict[str, Any]]:
        """Get employment info (payslips)"""
        return self._from_extracted('employment_info')

    @property
    def year_to_date(self) -> Optional[Dict[str, Any]]:
        """Get year-to-date totals (payslips, only present when non-null)"""
        return self._from_extracted('year_to_date')

    @property
    def payslips(self) -> List[Dict[str, Any]]:
        """Get payslips array (each has earnings, deductions, totals, pay_period)"""
        return self._from_extracted('payslips', [])

    @property
    def payslip_count(self) -> Optional[int]:
        """Get number of payslips detected in document"""
        return self._from_extracted('payslip_count')

    @property
    def fraud_score(self) -> Optional[Any]:
        """Get fraud score (payslips, sales invoices)"""
        return self._from_extracted('fraud_score')

    # -- Bill --

    @property
    def bill_fields(self) -> Dict[str, Any]:
        """Get bill extracted fields"""
        return self._from_extracted('bill_fields', {})

    @property
    def signals(self) -> Any:
        """Get signals (payslips: list of lender signals, bills: list of bill signals)"""
        return self._from_extracted('signals', [])

    @property
    def signal_summary(self) -> Dict[str, Any]:
        """Get signal summary (bills)"""
        return self._from_extracted('signal_summary', {})

    # -- Sales invoice --

    @property
    def invoice_signals(self) -> Dict[str, Any]:
        """Get invoice signals (sales invoices)"""
        return self._data.get('invoice_signals', {})

    # -- Credit report --

    @property
    def credit_report_data(self) -> Dict[str, Any]:
        """Get credit report data (accounts, KYC, summaries)"""
        return self._from_extracted('credit_report_data', {})

    # -- Audited Financial Statement (AFS) --

    @property
    def financial_statements(self) -> Dict[str, Any]:
        """Get AFS financial statements (balance_sheet, income_statement, cash_flow) keyed by year.

        Example:
            result.financial_statements['balance_sheet']['years']['2025']['total_assets']
            result.financial_statements['income_statement']['years']['2024']['revenue']
        """
        ed = self.extracted_data
        return {
            'balance_sheet': ed.get('balance_sheet', {}),
            'income_statement': ed.get('income_statement', {}),
            'cash_flow': ed.get('cash_flow', {}),
        }

    @property
    def company_info(self) -> Dict[str, Any]:
        """Get AFS company information (name, TIN, SEC registration, industry, address)"""
        return self._from_extracted('company', {})

    @property
    def audit_info(self) -> Dict[str, Any]:
        """Get AFS audit information (auditor, opinion, going concern, report date)"""
        return self._from_extracted('audit_info', {})

    @property
    def officers(self) -> Dict[str, Any]:
        """Get AFS corporate officers (chairman, president, CEO, CFO, treasurer, corporate secretary)"""
        return self._from_extracted('officers', {})

    @property
    def qualitative_data(self) -> Dict[str, Any]:
        """Get AFS qualitative/text-based data (business description, shareholders,
        equity structure, tax details, risk management, capital management, subsequent events,
        supplementary information, accounting policies).

        Example:
            result.qualitative_data['shareholders']  # List of shareholders
            result.qualitative_data['equity_structure']['authorized_capital_stock']
            result.qualitative_data['risk_management']['credit_risk']
        """
        return self._from_extracted('qualitative', {})

    @property
    def shareholders(self) -> List[Dict[str, Any]]:
        """Get AFS shareholders list (name, nationality, ownership_percentage, number_of_shares, share_class)"""
        qual = self._from_extracted('qualitative', {})
        return qual.get('shareholders', [])

    @property
    def equity_structure(self) -> Dict[str, Any]:
        """Get AFS equity structure (authorized/subscribed/paid-up capital, par value, treasury shares)"""
        qual = self._from_extracted('qualitative', {})
        return qual.get('equity_structure', {})

    @property
    def risk_management(self) -> Dict[str, Any]:
        """Get AFS risk management disclosures (credit_risk, liquidity_risk, market_risk)"""
        qual = self._from_extracted('qualitative', {})
        return qual.get('risk_management', {})

    @property
    def financial_ratios(self) -> Dict[str, Any]:
        """Get AFS computed financial ratios (liquidity, leverage, profitability, efficiency, cash_flow_quality, growth).

        Example:
            result.financial_ratios['liquidity']['current_ratio']
            result.financial_ratios['profitability']['net_margin']
            result.financial_ratios['growth']['revenue_growth']
        """
        return self._data.get('metrics', {})

    @property
    def risk_flags(self) -> List[Dict[str, Any]]:
        """Get AFS risk flags (going concern, negative equity, low liquidity, etc.)

        Each flag has: code, severity ('high'|'medium'|'low'), message
        """
        return self._from_extracted('risk_flags', [])

    @property
    def completeness(self) -> Dict[str, Any]:
        """Get AFS data completeness scores (overall_score 0-100, per-section breakdown)"""
        return self._data.get('completeness', {})

    @property
    def notes(self) -> Dict[str, Any]:
        """Get AFS notes to financial statements (borrowings, related_party_transactions,
        receivables_aging, contingent_liabilities, ppe_schedule, lease_commitments, revenue_segments)"""
        return self._from_extracted('notes', {})

    @property
    def statements_found(self) -> Dict[str, bool]:
        """Get which AFS statements were found (balance_sheet, income_statement, cash_flow_statement, audit_opinion)"""
        return self._data.get('statements_found', {})

    # -- General Information Sheet (GIS) --

    @property
    def gis_company(self) -> Dict[str, Any]:
        """Get GIS company information (name, SEC registration, TIN, address, industry, primary purpose).

        Example:
            result.gis_company['company_name']
            result.gis_company['sec_registration_number']
            result.gis_company['principal_office_address']
        """
        return self._from_extracted('company', {})

    @property
    def filing_info(self) -> Dict[str, Any]:
        """Get GIS filing information (fiscal year, annual meeting date, submission date, amendments).

        Example:
            result.filing_info['fiscal_year']
            result.filing_info['date_of_annual_meeting']
        """
        return self._from_extracted('filing_info', {})

    @property
    def capital_structure(self) -> Dict[str, Any]:
        """Get GIS capital structure (authorized/subscribed/paid-up capital, shares, par value, share classes).

        Example:
            result.capital_structure['authorized_capital_stock']
            result.capital_structure['paid_up_capital']
            result.capital_structure['share_classes']  # List of share class details
        """
        return self._from_extracted('capital_structure', {})

    @property
    def stockholders(self) -> List[Dict[str, Any]]:
        """Get GIS stockholders list (name, nationality, shares, ownership %, amount paid, TIN).

        Example:
            for sh in result.stockholders:
                print(f"{sh['name']}: {sh['ownership_percentage']}%")
        """
        return self._from_extracted('stockholders', [])

    @property
    def directors(self) -> List[Dict[str, Any]]:
        """Get GIS directors list (name, nationality, board type, independent flag, meetings attended, TIN).

        Example:
            independent = [d for d in result.directors if 'independent' in d.get('board', '').lower()]
        """
        return self._from_extracted('directors', [])

    @property
    def gis_officers(self) -> List[Dict[str, Any]]:
        """Get GIS officers list (name, position, nationality, TIN).

        Example:
            president = next((o for o in result.gis_officers if 'president' in o['position'].lower()), None)
        """
        return self._from_extracted('officers', [])

    @property
    def beneficial_owners(self) -> List[Dict[str, Any]]:
        """Get GIS beneficial owners (name, nationality, % of capital, category).

        Example:
            for bo in result.beneficial_owners:
                print(f"{bo['name']}: {bo['percentage_of_capital']}%")
        """
        return self._from_extracted('beneficial_owners', [])

    @property
    def intercompany_relationships(self) -> List[Dict[str, Any]]:
        """Get GIS intercompany relationships (parent, subsidiary, affiliate companies).

        Example:
            for rel in result.intercompany_relationships:
                print(f"{rel['company_name']} ({rel['relationship']})")
        """
        return self._from_extracted('intercompany_relationships', [])

    @property
    def external_auditor(self) -> Dict[str, Any]:
        """Get GIS external auditor information (firm, accreditation, contact, date engaged)."""
        return self._from_extracted('external_auditor', {})

    @property
    def compliance_info(self) -> Dict[str, Any]:
        """Get GIS compliance information (compliance officer, report submissions, pending cases).

        Example:
            result.compliance_info['compliance_officer']
            result.compliance_info['pending_cases']
        """
        return self._from_extracted('compliance_info', {})

    @property
    def gis_risk_signals(self) -> List[Dict[str, Any]]:
        """Get GIS risk signals (concentration risk, thin capitalization, governance gaps, etc.).

        Each signal has: code, severity ('high'|'medium'|'info'), message, details

        Example:
            high_risks = [s for s in result.gis_risk_signals if s['severity'] == 'high']
        """
        m = self._data.get('metrics', {})
        return m.get('risk_signals', self._from_extracted('risk_flags', []))

    @property
    def gis_summary(self) -> Dict[str, Any]:
        """Get GIS summary metrics (stockholder count, director count, foreign ownership %, capital figures).

        Example:
            result.gis_summary['stockholder_count']
            result.gis_summary['foreign_ownership_pct']
        """
        m = self._data.get('metrics', {})
        return m.get('summary', {})

    # -- Other / generic document --

    @property
    def general_signals(self) -> Optional[Dict[str, Any]]:
        """Get general document signals"""
        ed = self._data.get('extracted_data')
        if isinstance(ed, dict) and 'general_signals' in ed:
            return ed['general_signals']
        return self._data.get('general_signals')

    # -- Common --

    @property
    def raw(self) -> Dict[str, Any]:
        """Get raw response data"""
        return self._data

    def to_dict(self) -> Dict[str, Any]:
        return self._data

    def to_json(self, indent: int = 2) -> str:
        """Return result as formatted JSON string"""
        return json.dumps(self._data, indent=indent, default=str)

    def save_json(self, file_path: str, indent: int = 2) -> None:
        """
        Save result to a JSON file

        Args:
            file_path: Path to save JSON file
            indent: JSON indentation (default: 2)
        """
        with open(file_path, 'w') as f:
            json.dump(self._data, f, indent=indent, default=str)

    def __repr__(self):
        return f"DocumentResult(status={self.status}, type={self.document_type})"


class Batch:
    """
    Represents a batch processing job.

    Usage:
        batch = client.batch_process("/docs", "bank_statement")
        results = batch.results()  # Returns {filepath: DocumentResult}

        # Access by filepath
        results['/docs/statement1.pdf']['metadata']

        # Iterate
        for filepath, result in results.items():
            result.save_json(f"{filepath}.json")
    """

    def __init__(self, batch_id: str, client: 'KitaClient', show_progress: bool = True):
        self.id = batch_id
        self._client = client
        self._show_progress = show_progress
        self._uploads = []  # List of {doc_id, filepath, response}
        self._results = {}  # filepath -> result response

    def _poll_results(self, poll_interval: int = 2, timeout: int = 600, max_workers: int = 10):
        """Poll for all results to complete (with parallel polling)"""
        start_time = time.time()
        total = len(self._uploads)
        progress = _ProgressBar(total, "Processing") if self._show_progress else None

        # Filter out upload failures
        pending = {u['_filepath']: u for u in self._uploads if u.get('status') != 'upload_failed'}
        lock = threading.Lock()

        def check_status(filepath: str, upload: Dict) -> tuple:
            """Check status of a single document"""
            doc_id = upload.get('documentId') or upload.get('document_id')
            if not doc_id:
                return filepath, None, 'no_doc_id'

            try:
                response = self._client._request('GET', f'/api/results/{doc_id}')
                status = response.get('status') or response.get('processing_status', 'pending')
                response['_filepath'] = filepath
                return filepath, response, status
            except Exception:
                return filepath, None, 'pending'

        while pending:
            # Parallel status checks
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(check_status, fp, up) for fp, up in pending.items()]
                for future in as_completed(futures):
                    filepath, response, status = future.result()
                    if status in ['completed', 'failed']:
                        with lock:
                            self._results[filepath] = response
                            if filepath in pending:
                                del pending[filepath]

            if progress:
                done = len(self._results)
                failed = sum(1 for r in self._results.values() if r.get('status') == 'failed')
                progress.update(done, f"{done - failed} completed, {failed} failed")

            if not pending:
                break

            if time.time() - start_time > timeout:
                if progress:
                    progress.finish(f"✗ Batch timed out: {len(self._results)}/{total} completed")
                raise KitaError(f"Batch {self.id} timeout after {timeout}s")

            time.sleep(poll_interval)

        if progress:
            failed = sum(1 for r in self._results.values() if r.get('status') == 'failed')
            succeeded = len(self._results) - failed
            progress.finish(f"✓ Batch complete: {succeeded} succeeded, {failed} failed")

    def results(self, poll_interval: int = 2, timeout: int = 600) -> Dict[str, 'DocumentResult']:
        """
        Wait for batch to complete and return results as a dictionary.

        Returns:
            Dict mapping filepath -> DocumentResult

        Example:
            results = batch.results()
            results['/path/to/doc.pdf']['metadata']

            for filepath, result in results.items():
                result.save_json(f"{filepath}_output.json")
        """
        if not self._results or len(self._results) < len(self._uploads):
            self._poll_results(poll_interval, timeout)

        return {
            filepath: DocumentResult(result)
            for filepath, result in self._results.items()
        }

    @property
    def status(self) -> Dict[str, Any]:
        """Get current batch status"""
        total = len(self._uploads)
        completed = sum(1 for r in self._results.values()
                       if r.get('status') == 'completed' or r.get('processing_status') == 'completed')
        failed = sum(1 for r in self._results.values() if r.get('status') == 'failed')
        pending = total - len(self._results)

        return {
            'total': total,
            'completed': completed,
            'failed': failed,
            'pending': pending
        }

    def __len__(self):
        return len(self._uploads)


class KitaClient:
    """
    Kita Document Processing API Client

    Example:
        from kita import KitaClient

        # Initialize with API key (uses production URL by default)
        client = KitaClient(api_key="kita_prod_...")

        # Process single document
        result = client.process("paystub.pdf", "payslip")
        print(result.metadata)
        print(result.transactions)

        # Save as JSON
        result.save_json("output.json")

        # Download custom Excel export
        client.download_export(result.document_id, "output.xlsx")

        # Batch process folder
        batch = client.batch_process("/folder", "bank_statement")
        results = batch.results()
        for filepath, doc in results.items():
            print(doc.metadata)

    Environment Variables:
        KITA_API_KEY: Default API key (optional)
        KITA_API_URL: Override default API URL (optional)
    """

    # Supported document types
    DOCUMENT_TYPES = [
        'bank_statement',
        'passbook',
        'credit_card_statement',
        'payslip',
        'bill',
        'credit_report',
        'sales_invoice',
        'audited_financial_statement',
        'bir_2303',
        'bir_2307',
        'secretarys_certificate',
        'certificate_of_employment',
        'government_id',
        'income_tax_return',
        'general_document',
        'other_document',
    ]

    def __init__(
        self,
        api_key: str = None,
        base_url: str = None,
        timeout: int = 60
    ):
        """
        Initialize Kita client

        Args:
            api_key: Your Kita API key. Can also be set via KITA_API_KEY env var.
            base_url: API base URL. Defaults to production (https://portal.usekita.com).
                      Can also be set via KITA_API_URL env var.
            timeout: Request timeout in seconds
        """
        # Get API key from parameter or environment
        self.api_key = api_key or os.environ.get('KITA_API_KEY')

        if not self.api_key:
            raise KitaError(
                "API key required. Pass api_key parameter or set KITA_API_KEY environment variable. "
                "Get your API key at https://portal.usekita.com/api-keys.html"
            )

        if not self.api_key.startswith('kita_'):
            raise KitaError("Invalid API key format. Must start with 'kita_'")

        # Get base URL from parameter, environment, or default
        self.base_url = (base_url or os.environ.get('KITA_API_URL') or DEFAULT_API_URL).rstrip('/')
        self.timeout = timeout

        # Region auto-discovery state
        self._discovery_base = self.base_url  # original URL for discovery calls
        self._region_url: Optional[str] = None
        self._region_url_expires: float = 0

        # Setup session with auth headers
        self._session = requests.Session()
        self._session.headers.update({
            'Authorization': f'Bearer {self.api_key}',
            'User-Agent': f'kita-python-sdk/{__version__}',
            'Accept': 'application/json'
        })

    def _ensure_region_url(self) -> None:
        """Auto-discover regional API URL via /api/v1/documents/region.

        Caches the result based on the TTL returned by the server.
        Fails open — if the discovery call errors, the original base_url is kept.
        """
        if time.time() < self._region_url_expires:
            return  # cached result still valid

        try:
            resp = self._session.get(
                f"{self._discovery_base}/api/v1/documents/region",
                timeout=5,
            )
            if resp.status_code == 200:
                data = resp.json()
                ttl = data.get('ttl', 3600)
                api_url = data.get('api_url')
                if api_url:
                    self._region_url = api_url.rstrip('/')
                    self.base_url = self._region_url
                else:
                    self._region_url = None
                    self.base_url = self._discovery_base
                self._region_url_expires = time.time() + ttl
        except Exception:
            # Fail open — keep current base_url
            self._region_url_expires = time.time() + 60  # retry in 1 min

    def _request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """Make HTTP request to API and return JSON response"""
        self._ensure_region_url()
        url = f"{self.base_url}{endpoint}"
        kwargs.setdefault('timeout', self.timeout)

        try:
            response = self._session.request(method, url, **kwargs)

            # Handle non-JSON responses
            try:
                data = response.json()
            except json.JSONDecodeError:
                data = {'raw': response.text}

            # Handle errors
            if response.status_code == 401:
                raise KitaAuthenticationError(
                    response.status_code,
                    data.get('message', 'Authentication failed'),
                    data
                )

            if response.status_code == 429:
                retry_after = response.headers.get('Retry-After')
                raise KitaRateLimitError(
                    response.status_code,
                    data.get('message', 'Rate limit exceeded'),
                    int(retry_after) if retry_after else None,
                    data
                )

            if response.status_code >= 400:
                raise KitaAPIError(
                    response.status_code,
                    data.get('message', data.get('error', 'Unknown error')),
                    data
                )

            return data

        except requests.RequestException as e:
            raise KitaError(f"Request failed: {str(e)}")

    def _request_binary(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> requests.Response:
        """Make HTTP request and return raw Response (for binary downloads)."""
        self._ensure_region_url()
        url = f"{self.base_url}{endpoint}"
        kwargs.setdefault('timeout', self.timeout)
        kwargs['stream'] = True

        try:
            response = self._session.request(method, url, **kwargs)

            if response.status_code == 401:
                raise KitaAuthenticationError(401, 'Authentication failed')
            if response.status_code == 429:
                retry_after = response.headers.get('Retry-After')
                raise KitaRateLimitError(429, 'Rate limit exceeded',
                                         int(retry_after) if retry_after else None)
            if response.status_code >= 400:
                # Try to parse error JSON
                try:
                    data = response.json()
                    msg = data.get('message', data.get('error', 'Unknown error'))
                except json.JSONDecodeError:
                    msg = response.text or 'Unknown error'
                raise KitaAPIError(response.status_code, msg)

            return response

        except requests.RequestException as e:
            raise KitaError(f"Request failed: {str(e)}")

    def process(
        self,
        file_path: str,
        document_type: str,
        wait: bool = True,
        poll_interval: int = 2,
        timeout: int = 600,
        password: str = None,
        show_progress: bool = True,
        webhook_url: str = None
    ) -> DocumentResult:
        """
        Process a single document

        Args:
            file_path: Path to document file (PDF, PNG, JPG, etc.)
            document_type: Type of document (e.g. 'bank_statement', 'credit_report',
                'payslip', 'government_id', etc.). See KitaClient.DOCUMENT_TYPES for full list.
            wait: If True, wait for processing to complete (default: True)
            poll_interval: Seconds between status checks (if wait=True)
            timeout: Maximum seconds to wait (if wait=True)
            password: PDF password if document is encrypted
            show_progress: If True, show spinner while processing (default: True)
            webhook_url: Optional URL to receive a POST callback when processing completes

        Returns:
            DocumentResult object with parsed data

        Example:
            result = client.process("statement.pdf", "bank_statement")
            print(result.metadata)
            for tx in result.transactions:
                print(tx['date'], tx['description'], tx['amount'])

            # Save as JSON
            result.save_json("output.json")

            # With webhook (fire-and-forget)
            client.process("statement.pdf", "bank_statement",
                          wait=False, webhook_url="https://your-server.com/webhook")
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise KitaError(f"File not found: {file_path}")

        # Normalize document type
        doc_type = document_type.lower().replace(' ', '_').replace('-', '_')

        # Upload file
        with open(file_path, 'rb') as f:
            files = {'file': (file_path.name, f, self._get_mime_type(file_path))}
            data = {'document_type': doc_type}

            if password:
                data['password'] = password
            if webhook_url:
                data['webhook_url'] = webhook_url

            # Use async endpoint for better handling
            response = self._request('POST', '/api/process-async', files=files, data=data)

        if not wait:
            return DocumentResult(response)

        # Poll for completion
        document_id = response.get('documentId') or response.get('document_id')
        if not document_id:
            # Synchronous processing completed
            return DocumentResult(response)

        return self._wait_for_document(document_id, poll_interval, timeout, show_progress, file_path.name)

    def process_base64(
        self,
        file_base64: str,
        filename: str,
        document_type: str,
        wait: bool = True,
        poll_interval: int = 2,
        timeout: int = 600,
        password: str = None,
        show_progress: bool = True,
        webhook_url: str = None
    ) -> DocumentResult:
        """
        Process a document from a base64-encoded string.

        Args:
            file_base64: Base64-encoded file contents. May include a data URI
                prefix (e.g. "data:application/pdf;base64,...") which is stripped
                automatically.
            filename: Filename with extension (e.g. "statement.pdf"). The
                extension determines how the file is processed.
            document_type: Type of document (e.g. 'bank_statement', 'payslip').
            wait: If True, wait for processing to complete (default: True)
            poll_interval: Seconds between status checks (if wait=True)
            timeout: Maximum seconds to wait (if wait=True)
            password: PDF password if document is encrypted
            show_progress: If True, show spinner while processing (default: True)
            webhook_url: Optional URL to receive a POST callback when processing completes

        Returns:
            DocumentResult object with parsed data

        Example:
            import base64

            with open("statement.pdf", "rb") as f:
                b64 = base64.b64encode(f.read()).decode()

            result = client.process_base64(b64, "statement.pdf", "bank_statement")
            print(result.metadata)
        """
        doc_type = document_type.lower().replace(' ', '_').replace('-', '_')

        payload = {
            'file_base64': file_base64,
            'filename': filename,
            'document_type': doc_type,
        }
        if password:
            payload['password'] = password
        if webhook_url:
            payload['webhook_url'] = webhook_url

        response = self._request('POST', '/api/process-async', json=payload)

        if not wait:
            return DocumentResult(response)

        document_id = response.get('documentId') or response.get('document_id')
        if not document_id:
            return DocumentResult(response)

        return self._wait_for_document(document_id, poll_interval, timeout, show_progress, filename)

    def process_url(
        self,
        file_url: str,
        document_type: str,
        filename: str = None,
        wait: bool = True,
        poll_interval: int = 3,
        timeout: int = 600,
        show_progress: bool = True,
        webhook_url: str = None
    ) -> DocumentResult:
        """
        Process a document from a URL (S3 presigned URL, public URL, etc.).
        The file is downloaded server-side — no local download needed.

        Args:
            file_url: URL to the document file (S3 presigned URL, public HTTP/HTTPS)
            document_type: Type of document (e.g. 'bank_statement', 'credit_report')
            filename: Optional filename override (auto-detected from URL if omitted)
            wait: If True, wait for processing to complete (default: True)
            poll_interval: Seconds between status checks (if wait=True)
            timeout: Maximum seconds to wait (if wait=True)
            show_progress: If True, show spinner while processing (default: True)
            webhook_url: Optional URL to receive a POST callback when processing completes

        Returns:
            DocumentResult object with parsed data

        Example:
            # From S3 presigned URL
            result = client.process_url(
                "https://my-bucket.s3.amazonaws.com/doc.pdf?X-Amz-...",
                "bank_statement"
            )
            print(result.metadata)

            # Fire-and-forget with webhook
            client.process_url(
                "https://my-bucket.s3.amazonaws.com/doc.pdf?X-Amz-...",
                "bank_statement",
                wait=False,
                webhook_url="https://your-server.com/webhook"
            )
        """
        doc_type = document_type.lower().replace(' ', '_').replace('-', '_')

        payload = {
            'file_url': file_url,
            'document_type': doc_type,
        }
        if filename:
            payload['filename'] = filename
        if webhook_url:
            payload['webhook_url'] = webhook_url

        # Use single document endpoint (supports file_url)
        response = self._request('POST', '/api/v1/documents', json=payload)

        document_id = response.get('document_id')
        if not document_id:
            raise KitaError("Failed to create processing job from URL")

        if not wait:
            return DocumentResult(response)

        display_name = filename or file_url.split('/')[-1].split('?')[0] or 'document'
        return self._wait_for_document(document_id, poll_interval, timeout, show_progress, display_name)

    def custom_export(
        self,
        document_id: Union[str, int],
        output_path: str,
        export_type: str = 'custom'
    ) -> str:
        """
        Download a processed document as a custom Excel export.

        Args:
            document_id: The document ID (from result.document_id)
            output_path: Path to save the Excel file (e.g. 'output.xlsx')
            export_type: Export type:
                - 'custom' (default) — org-configured Excel format
                - 'credit_report' — multi-sheet credit report Excel
                - 'schema' — schema-driven export (AFS, SLIK, credit reports)

        Returns:
            The output file path

        Example:
            # Org-configured custom export
            client.custom_export(result.document_id, "report.xlsx")

            # Credit report multi-sheet export
            client.custom_export(result.document_id, "credit.xlsx", export_type="credit_report")

            # Schema-driven export (AFS 17-sheet workbook, SLIK, etc.)
            client.custom_export(result.document_id, "afs.xlsx", export_type="schema")
        """
        if export_type == 'credit_report':
            endpoint = f'/api/documents/{document_id}/credit-report-export'
        elif export_type == 'schema':
            endpoint = f'/api/v1/documents/{document_id}/export'
        else:
            endpoint = f'/api/documents/{document_id}/custom-export'

        response = self._request_binary('GET', endpoint)

        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        return output_path

    def _get_mime_type(self, file_path: Path) -> str:
        """Get MIME type based on file extension"""
        ext = file_path.suffix.lower()
        mime_types = {
            '.pdf': 'application/pdf',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.tiff': 'image/tiff',
            '.tif': 'image/tiff',
            '.bmp': 'image/bmp',
            '.gif': 'image/gif',
            '.webp': 'image/webp',
            '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            '.xls': 'application/vnd.ms-excel',
            '.csv': 'text/csv',
            '.txt': 'text/plain',
        }
        return mime_types.get(ext, 'application/octet-stream')

    def _wait_for_document(
        self,
        document_id: str,
        poll_interval: int,
        timeout: int,
        show_progress: bool = True,
        filename: str = None
    ) -> DocumentResult:
        """Wait for a document to be processed"""
        start_time = time.time()
        spinner = None

        if show_progress:
            msg = f"Processing {filename}" if filename else "Processing document"
            spinner = _Spinner(msg)
            spinner.start()

        try:
            while True:
                try:
                    response = self._request('GET', f'/api/results/{document_id}')

                    status = response.get('status') or response.get('processing_status')

                    if status == 'completed':
                        if spinner:
                            spinner.stop(f"✓ {filename or 'Document'} processed successfully")
                        return DocumentResult(response)

                    if status == 'failed':
                        if spinner:
                            spinner.stop(f"✗ {filename or 'Document'} processing failed")
                        error_msg = response.get('error_message', 'Processing failed')
                        raise KitaError(f"Document processing failed: {error_msg}")

                except KitaAPIError as e:
                    if e.status_code != 404:
                        if spinner:
                            spinner.stop()
                        raise
                    # Document not ready yet, continue polling

                if time.time() - start_time > timeout:
                    if spinner:
                        spinner.stop(f"✗ {filename or 'Document'} timed out")
                    raise KitaError(f"Document {document_id} timeout after {timeout}s")

                time.sleep(poll_interval)
        except Exception:
            if spinner:
                spinner.stop()
            raise

    def batch_process(
        self,
        folder_path: str,
        document_type: str,
        extensions: List[str] = None,
        recursive: bool = False,
        max_workers: int = 5,
        show_progress: bool = True
    ) -> 'Batch':
        """
        Process multiple documents from a folder (with parallel uploads)

        Args:
            folder_path: Path to folder containing documents
            document_type: Type of documents (all must be same type)
            extensions: File extensions to include (default: ['.pdf', '.png', '.jpg', '.jpeg'])
            recursive: If True, search subdirectories
            max_workers: Number of parallel upload threads (default: 5)
            show_progress: If True, show progress bars (default: True)

        Returns:
            Batch object - call batch.results() to get {filepath: DocumentResult}

        Example:
            batch = client.batch_process("/docs", "bank_statement")
            results = batch.results()  # {filepath: DocumentResult}

            for filepath, result in results.items():
                result.save_json(f"{filepath}_output.json")
        """
        folder = Path(folder_path)

        if not folder.is_dir():
            raise KitaError(f"Folder not found: {folder_path}")

        if extensions is None:
            extensions = ['.pdf', '.png', '.jpg', '.jpeg', '.txt', '.csv', '.xlsx', '.xls']

        # Collect files
        files = []
        for ext in extensions:
            pattern = f'**/*{ext}' if recursive else f'*{ext}'
            files.extend(folder.glob(pattern))

        if not files:
            raise KitaError(f"No files with extensions {extensions} found in {folder_path}")

        # Normalize document type
        doc_type = document_type.lower().replace(' ', '_').replace('-', '_')

        total_files = len(files)
        progress = _ProgressBar(total_files, "Uploading") if show_progress else None
        completed_count = 0
        lock = threading.Lock()

        def upload_file(file_path: Path) -> Dict[str, Any]:
            """Upload a single file and return response with filepath"""
            nonlocal completed_count
            with open(file_path, 'rb') as f:
                upload_files = {'file': (file_path.name, f, self._get_mime_type(file_path))}
                upload_data = {'document_type': doc_type}
                response = self._request('POST', '/api/process-async', files=upload_files, data=upload_data)
                response['_filepath'] = str(file_path)

            with lock:
                completed_count += 1
                if progress:
                    progress.update(completed_count, file_path.name)

            return response

        # Parallel upload with ThreadPoolExecutor
        file_uploads = []
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(upload_file, fp): fp for fp in files}
            for future in as_completed(futures):
                try:
                    result = future.result()
                    file_uploads.append(result)
                except Exception as e:
                    filepath = futures[future]
                    file_uploads.append({
                        '_filepath': str(filepath),
                        '_error': str(e),
                        'status': 'upload_failed'
                    })

        if progress:
            progress.finish(f"✓ Uploaded {total_files} documents")

        # Create batch
        batch_id = f"batch_{int(time.time())}_{len(files)}"
        batch = Batch(batch_id, self, show_progress=show_progress)
        batch._uploads = file_uploads

        return batch

    def batch_process_urls(
        self,
        documents: List[Dict[str, str]],
        wait: bool = True,
        poll_interval: int = 3,
        timeout: int = 600,
        show_progress: bool = True
    ) -> Dict[str, Any]:
        """
        Process multiple documents from URLs via the batch API.

        Args:
            documents: List of dicts with 'file_url', 'document_type', and optional 'filename'
            wait: If True, wait for all processing to complete
            poll_interval: Seconds between status checks
            timeout: Maximum seconds to wait
            show_progress: If True, show progress bar

        Returns:
            Dict with batch_id and documents list (each with document_id, status, result)

        Example:
            results = client.batch_process_urls([
                {"file_url": "https://example.com/stmt1.pdf", "document_type": "bank_statement"},
                {"file_url": "https://example.com/stmt2.pdf", "document_type": "bank_statement"},
            ])
            for doc in results['documents']:
                if doc['status'] == 'completed':
                    print(doc['result']['metadata'])
        """
        # Validate
        for i, doc in enumerate(documents):
            if 'file_url' not in doc:
                raise KitaError(f"Missing 'file_url' at index {i}")
            if 'document_type' not in doc:
                raise KitaError(f"Missing 'document_type' at index {i}")

        response = self._request('POST', '/api/v1/batch', json={'documents': documents})
        batch_id = response.get('batch_id')

        if not wait:
            return response

        # Poll for completion
        progress = None
        total = response.get('total_documents', len(documents))
        if show_progress:
            progress = _ProgressBar(total, "Processing")

        start_time = time.time()
        while True:
            batch_status = self._request('GET', f'/api/v1/batch/{batch_id}')
            completed = batch_status.get('completed', 0)
            failed = batch_status.get('failed', 0)
            status = batch_status.get('status', 'processing')

            if progress:
                progress.update(completed + failed, f"{completed} done, {failed} failed")

            if status in ('completed', 'failed') or (completed + failed >= total):
                if progress:
                    progress.finish(f"✓ Batch complete: {completed} succeeded, {failed} failed")
                # Fetch full results
                return self._request('GET', f'/api/v1/batch/{batch_id}/results')

            if time.time() - start_time > timeout:
                if progress:
                    progress.finish(f"✗ Batch timed out: {completed}/{total} completed")
                raise KitaError(f"Batch {batch_id} timeout after {timeout}s")

            time.sleep(poll_interval)

    def batch_process_base64(
        self,
        documents: List[Dict[str, str]],
        wait: bool = True,
        poll_interval: int = 3,
        timeout: int = 600,
        show_progress: bool = True
    ) -> Dict[str, Any]:
        """
        Process multiple documents from base64-encoded content via the batch API.

        Args:
            documents: List of dicts with 'file_base64', 'filename', 'document_type',
                       and optional 'password'
            wait: If True, wait for all processing to complete
            poll_interval: Seconds between status checks
            timeout: Maximum seconds to wait
            show_progress: If True, show progress bar

        Returns:
            Dict with batch_id and documents list

        Example:
            import base64
            docs = []
            for f in ["stmt1.pdf", "stmt2.pdf"]:
                with open(f, "rb") as fh:
                    docs.append({
                        "file_base64": base64.b64encode(fh.read()).decode(),
                        "filename": f,
                        "document_type": "bank_statement"
                    })
            results = client.batch_process_base64(docs)
        """
        for i, doc in enumerate(documents):
            if 'file_base64' not in doc:
                raise KitaError(f"Missing 'file_base64' at index {i}")
            if 'filename' not in doc:
                raise KitaError(f"Missing 'filename' at index {i}")
            if 'document_type' not in doc:
                raise KitaError(f"Missing 'document_type' at index {i}")

        response = self._request('POST', '/api/v1/batch', json={'documents': documents})
        batch_id = response.get('batch_id')

        if not wait:
            return response

        # Poll for completion (same as batch_process_urls)
        progress = None
        total = response.get('total_documents', len(documents))
        if show_progress:
            progress = _ProgressBar(total, "Processing")

        start_time = time.time()
        while True:
            batch_status = self._request('GET', f'/api/v1/batch/{batch_id}')
            completed = batch_status.get('completed', 0)
            failed = batch_status.get('failed', 0)
            status = batch_status.get('status', 'processing')

            if progress:
                progress.update(completed + failed, f"{completed} done, {failed} failed")

            if status in ('completed', 'failed') or (completed + failed >= total):
                if progress:
                    progress.finish(f"✓ Batch complete: {completed} succeeded, {failed} failed")
                return self._request('GET', f'/api/v1/batch/{batch_id}/results')

            if time.time() - start_time > timeout:
                if progress:
                    progress.finish(f"✗ Batch timed out: {completed}/{total} completed")
                raise KitaError(f"Batch {batch_id} timeout after {timeout}s")

            time.sleep(poll_interval)

    def merge_documents(
        self,
        files: List[Dict[str, str]],
        document_type: str,
        output_filename: str = None,
        wait: bool = True,
        poll_interval: int = 2,
        timeout: int = 600,
        password: str = None,
        show_progress: bool = True
    ) -> DocumentResult:
        """
        Merge multiple files (PDFs, images) into a single document and process it.

        Combines separate pages/files into one PDF before processing. Useful for
        multi-page documents scanned as separate images.

        Args:
            files: List of file sources. Each dict must have one of:
                - 'file_url': Public URL to download from
                - 'file_base64' + 'filename': Base64-encoded file content
                - 'file_path' + optional 'filename': Local file path (auto-encoded)
            document_type: Document type for processing
            output_filename: Optional filename for the merged document
            wait: If True, wait for processing to complete
            poll_interval: Seconds between status checks
            timeout: Maximum seconds to wait
            password: Optional PDF password for encrypted documents
            show_progress: If True, show progress bar

        Returns:
            DocumentResult if wait=True, otherwise dict with document_id and status

        Example:
            # From URLs
            result = client.merge_documents(
                files=[
                    {"file_url": "https://example.com/page1.png"},
                    {"file_url": "https://example.com/page2.png"},
                ],
                document_type="bank_statement"
            )

            # From local files
            result = client.merge_documents(
                files=[
                    {"file_path": "/path/to/page1.jpg"},
                    {"file_path": "/path/to/page2.jpg"},
                    {"file_path": "/path/to/appendix.pdf"},
                ],
                document_type="bank_statement"
            )
        """
        # Convert local file paths to base64
        import base64 as _b64
        prepared_files = []
        for i, f in enumerate(files):
            if 'file_path' in f:
                file_path = f['file_path']
                if not os.path.exists(file_path):
                    raise KitaError(f"File not found at index {i}: {file_path}")
                with open(file_path, 'rb') as fh:
                    content = _b64.b64encode(fh.read()).decode()
                filename = f.get('filename', os.path.basename(file_path))
                prepared_files.append({
                    'file_base64': content,
                    'filename': filename
                })
            elif 'file_url' in f:
                prepared_files.append({'file_url': f['file_url'], 'filename': f.get('filename')})
            elif 'file_base64' in f:
                if 'filename' not in f:
                    raise KitaError(f"Missing 'filename' at index {i} when using file_base64")
                prepared_files.append({'file_base64': f['file_base64'], 'filename': f['filename']})
            else:
                raise KitaError(f"Each file must have 'file_path', 'file_url', or 'file_base64' (index {i})")

        payload = {
            'files': prepared_files,
            'document_type': document_type,
        }
        if output_filename:
            payload['output_filename'] = output_filename
        if password:
            payload['password'] = password

        response = self._request('POST', '/api/v1/documents/merge', json=payload)
        document_id = response.get('document_id')

        if not wait:
            return response

        # Poll for completion
        if show_progress:
            pages = response.get('pages', '?')
            print(f"  Merged {len(files)} files into {pages} pages, processing...")

        start_time = time.time()
        while True:
            try:
                result = self._request('GET', f'/api/results/{document_id}')
                if result.get('status') == 'completed' or result.get('processing_status') == 'completed':
                    if show_progress:
                        print(f"  ✓ Document {document_id} processed successfully")
                    return DocumentResult(result)
                if result.get('status') == 'failed' or result.get('processing_status') == 'failed':
                    raise KitaError(f"Document {document_id} processing failed: {result.get('error_message', 'Unknown error')}")
            except KitaAPIError as e:
                if e.status_code != 404:
                    raise

            if time.time() - start_time > timeout:
                raise KitaError(f"Document {document_id} processing timeout after {timeout}s")

            time.sleep(poll_interval)

    def edit_transactions(
        self,
        document_id: Union[str, int],
        transactions: List[Dict[str, Any]],
        revalidate: bool = False
    ) -> Dict[str, Any]:
        """
        Update transactions for a document and optionally re-run validation.

        The original transactions are preserved as an immutable backup on first edit.
        Subsequent edits increment the version number in edit_history.

        Args:
            document_id: The document ID
            transactions: Updated transactions array. Each transaction should include
                fields like date, description, amount, debit, credit, balance, category.
            revalidate: Whether to re-run full Python validation after editing (default: False).
                JS-side balance checks and metrics recomputation always run regardless.

        Returns:
            Dict with updated metrics, balance_checks, and edit_history

        Example:
            result = client.get_result(12345)
            txns = result.transactions

            # Fix a miscategorized transaction
            txns[3]['category'] = 'income'
            txns[3]['description'] = 'SALARY CREDIT - CORRECTED'

            updated = client.edit_transactions(12345, txns)
            print(f"Version: {updated['edit_history']['version']}")
        """
        return self._request('PUT', f'/api/documents/{document_id}/transactions', json={
            'transactions': transactions,
            'revalidate': revalidate
        })

    def revert_transactions(self, document_id: Union[str, int]) -> Dict[str, Any]:
        """
        Revert transactions to the original extraction results.

        Restores the immutable backup created on first edit. Only works if
        the transactions have been edited at least once.

        Args:
            document_id: The document ID

        Returns:
            Dict with restored transactions and confirmation message

        Example:
            reverted = client.revert_transactions(12345)
            print(reverted['message'])  # "Transactions reverted to original"
        """
        return self._request('POST', f'/api/documents/{document_id}/transactions/revert')

    def revalidate_transactions(self, document_id: Union[str, int]) -> Dict[str, Any]:
        """
        Re-run balance validation on current transactions without making changes.

        Useful after external edits or to refresh validation results.

        Args:
            document_id: The document ID

        Returns:
            Dict with revalidated transactions, metrics, and balance_checks

        Example:
            result = client.revalidate_transactions(12345)
            print(f"Balance checks: {result['balance_checks']}")
        """
        return self._request('POST', f'/api/documents/{document_id}/transactions/revalidate')

    def get_result(self, document_id: Union[str, int]) -> DocumentResult:
        """
        Get the full processed result for a document by ID.

        Args:
            document_id: The document ID

        Returns:
            DocumentResult object with all data (transactions, metrics, metadata, etc.)

        Example:
            result = client.get_result(12345)
            print(result.metadata)
            result.save_json("output.json")
        """
        response = self._request('GET', f'/api/results/{document_id}')
        return DocumentResult(response)

    def get_summary(
        self,
        document_id: Union[str, int],
        format: str = 'json'
    ) -> Union[Dict[str, Any], str]:
        """
        Get a bank statement summary (key-value metrics without transactions).

        Returns the same data as the web portal's "Download Summary CSV" —
        account info, flow metrics, balance metrics, transaction counts,
        annualized figures, and category spend percentages.

        Only works for bank_statement and passbook documents.

        Args:
            document_id: The document ID (from result.document_id)
            format: 'json' (default) returns a dict, 'csv' returns a CSV string

        Returns:
            Dict of summary metrics (if format='json') or CSV string (if format='csv')

        Example:
            result = client.process("statement.pdf", "bank_statement")
            summary = client.get_summary(result.document_id)
            print(summary['total_inflow'])
            print(summary['average_daily_balance'])

            # Get as CSV string
            csv_data = client.get_summary(result.document_id, format='csv')
            with open('summary.csv', 'w') as f:
                f.write(csv_data)
        """
        if format == 'csv':
            response = self._request_binary(
                'GET',
                f'/api/documents/{document_id}/summary',
                params={'format': 'csv'}
            )
            return response.text
        else:
            return self._request('GET', f'/api/documents/{document_id}/summary')

    def list_documents(
        self,
        limit: int = 100,
        offset: int = 0,
        status: Optional[str] = None,
        document_type: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List processed documents

        Args:
            limit: Maximum results to return
            offset: Pagination offset
            status: Filter by status (pending, processing, completed, failed)
            document_type: Filter by document type

        Returns:
            Dictionary with 'documents' list and pagination info
        """
        params = {'limit': limit, 'offset': offset}
        if status:
            params['status'] = status
        if document_type:
            params['document_type'] = document_type.lower()

        return self._request('GET', '/api/documents', params=params)


# Convenience function for quick processing
def process(
    file_path: str,
    document_type: str,
    api_key: str = None,
    **kwargs
) -> DocumentResult:
    """
    Quick function to process a single document

    Args:
        file_path: Path to document
        document_type: Type of document
        api_key: API key (or set KITA_API_KEY env var)
        **kwargs: Additional arguments passed to KitaClient.process()

    Returns:
        DocumentResult object

    Example:
        from kita import process
        result = process("doc.pdf", "bank_statement")
    """
    client = KitaClient(api_key=api_key)
    return client.process(file_path, document_type, **kwargs)


from kita.credit import CreditClient, CreditError, CreditAPIError, verify_webhook_signature

__all__ = [
    'KitaClient',
    'DocumentResult',
    'Batch',
    'KitaError',
    'KitaAPIError',
    'KitaAuthenticationError',
    'KitaRateLimitError',
    'process',
    'CreditClient',
    'CreditError',
    'CreditAPIError',
    'verify_webhook_signature',
]
