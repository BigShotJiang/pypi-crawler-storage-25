"""
Kita Credit Agent SDK

Python client for the Kita Credit Agent API — full programmatic interaction
with the lending platform: applications, documents, status transitions,
stipulations, collection, messaging, and webhooks.

Example:
    from kita.credit import CreditClient

    client = CreditClient(api_key="kt_...")
    app = client.create_application(
        product_id="...",
        first_name="Jane",
        last_name="Doe",
        email="jane@example.com",
    )
    print(app.status)  # 'submitted'
"""

import hashlib
import hmac
import json
import os
import time
from typing import Any, Dict, List, Optional, Union

import requests


# =============================================================================
# Errors
# =============================================================================


class CreditError(Exception):
    """Base error for all Credit SDK errors."""
    pass


class CreditAPIError(CreditError):
    """Raised when the API returns a non-2xx response."""

    def __init__(self, status_code: int, message: str, details: Optional[Dict] = None):
        self.status_code = status_code
        self.message = message
        self.details = details or {}
        super().__init__(f"[{status_code}] {message}")


class CreditAuthenticationError(CreditAPIError):
    """Raised on 401 Unauthorized."""

    def __init__(self, message: str = "Authentication failed"):
        super().__init__(401, message)


class CreditRateLimitError(CreditAPIError):
    """Raised on 429 Too Many Requests."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: Optional[int] = None):
        self.retry_after = retry_after
        super().__init__(429, message)


# =============================================================================
# Result wrappers
# =============================================================================


class _ResultBase:
    """Dict-like wrapper around API response data."""

    def __init__(self, raw: Dict[str, Any]):
        self._raw = raw

    @property
    def raw(self) -> Dict[str, Any]:
        return self._raw

    def to_dict(self) -> Dict[str, Any]:
        return dict(self._raw)

    def to_json(self, **kwargs) -> str:
        return json.dumps(self._raw, default=str, **kwargs)

    def __getitem__(self, key: str) -> Any:
        return self._raw[key]

    def __contains__(self, key: str) -> bool:
        return key in self._raw

    def get(self, key: str, default: Any = None) -> Any:
        return self._raw.get(key, default)

    def __repr__(self) -> str:
        cls = self.__class__.__name__
        ident = self._raw.get("id", "?")
        return f"<{cls} id={ident}>"


class ApplicationResult(_ResultBase):
    """Wrapper for application API responses."""

    @property
    def id(self) -> str:
        return self._raw.get("id", "")

    @property
    def application_number(self) -> Optional[str]:
        return self._raw.get("applicationNumber")

    @property
    def status(self) -> str:
        return self._raw.get("status", "")

    @property
    def applicant(self) -> Optional[Dict]:
        return self._raw.get("applicant")


class CreditDocumentResult(_ResultBase):
    """Wrapper for document API responses."""

    @property
    def id(self) -> str:
        return self._raw.get("id", "")

    @property
    def document_type(self) -> Optional[str]:
        return self._raw.get("documentType")

    @property
    def processing_status(self) -> Optional[str]:
        return self._raw.get("processingStatus")

    @property
    def ai_analysis_result(self) -> Optional[Dict]:
        return self._raw.get("aiAnalysisResult")

    @property
    def discrepancies(self) -> List:
        return self._raw.get("discrepancies", [])


class StipulationResult(_ResultBase):
    """Wrapper for stipulation API responses."""

    @property
    def id(self) -> str:
        return self._raw.get("id", "")

    @property
    def title(self) -> str:
        return self._raw.get("title", "")

    @property
    def status(self) -> str:
        return self._raw.get("status", "")

    @property
    def stipulation_type(self) -> Optional[str]:
        return self._raw.get("stipulationType")


# =============================================================================
# Client
# =============================================================================


class CreditClient:
    """
    Client for the Kita Credit Agent API.

    Args:
        api_key: Tenant API key (must start with ``kt_``). Falls back to
            the ``KITA_CREDIT_API_KEY`` environment variable.
        base_url: API base URL. Defaults to ``https://api.usekita.com``.
        timeout: Default request timeout in seconds.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 30,
    ):
        self.api_key = api_key or os.environ.get("KITA_CREDIT_API_KEY", "")
        if not self.api_key:
            raise CreditError(
                "API key is required. Pass api_key or set KITA_CREDIT_API_KEY."
            )
        if not self.api_key.startswith("kt_"):
            raise CreditError("API key must start with 'kt_'")

        self.base_url = (base_url or os.environ.get("KITA_CREDIT_BASE_URL", "https://api.usekita.com")).rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"ApiKey {self.api_key}",
            "Content-Type": "application/json",
        })

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self.base_url}/api/v1/loan/api{path}"

    def _request(
        self,
        method: str,
        path: str,
        json_body: Optional[Dict] = None,
        params: Optional[Dict] = None,
        files: Optional[Dict] = None,
        data: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        url = self._url(path)
        kwargs: Dict[str, Any] = {"timeout": self.timeout}
        if params:
            kwargs["params"] = {k: v for k, v in params.items() if v is not None}

        if files:
            # Multipart upload — temporarily remove Content-Type from session
            # so requests can set the correct multipart boundary
            saved_ct = self._session.headers.pop("Content-Type", None)
            kwargs["files"] = files
            if data:
                kwargs["data"] = data
            try:
                resp = self._session.request(method, url, **kwargs)
            finally:
                if saved_ct:
                    self._session.headers["Content-Type"] = saved_ct
            # Skip the normal request call below
            return self._handle_response(resp)
        elif json_body is not None:
            kwargs["json"] = json_body

        resp = self._session.request(method, url, **kwargs)
        return self._handle_response(resp)

    def _handle_response(self, resp: requests.Response) -> Dict[str, Any]:
        if resp.status_code == 401:
            raise CreditAuthenticationError()
        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After")
            raise CreditRateLimitError(
                retry_after=int(retry_after) if retry_after else None
            )
        if resp.status_code >= 400:
            try:
                body = resp.json()
            except Exception:
                body = {}
            raise CreditAPIError(
                resp.status_code,
                body.get("message", resp.text),
                body,
            )

        if resp.status_code == 204:
            return {}
        return resp.json()

    # -------------------------------------------------------------------------
    # Applications
    # -------------------------------------------------------------------------

    def create_application(
        self,
        product_id: str,
        first_name: str,
        last_name: str,
        email: str,
        phone: Optional[str] = None,
        requested_amount: Optional[float] = None,
        requested_term_months: Optional[int] = None,
        loan_purpose: Optional[str] = None,
        auto_submit: bool = True,
    ) -> ApplicationResult:
        """Create a new loan application."""
        payload: Dict[str, Any] = {
            "productId": product_id,
            "firstName": first_name,
            "lastName": last_name,
            "email": email,
            "autoSubmit": auto_submit,
        }
        if phone is not None:
            payload["phone"] = phone
        if requested_amount is not None:
            payload["requestedAmount"] = requested_amount
        if requested_term_months is not None:
            payload["requestedTermMonths"] = requested_term_months
        if loan_purpose is not None:
            payload["loanPurpose"] = loan_purpose

        resp = self._request("POST", "/applications", json_body=payload)
        return ApplicationResult(resp.get("data", resp))

    def list_applications(
        self,
        status: Optional[str] = None,
        page: int = 1,
        limit: int = 20,
    ) -> List[ApplicationResult]:
        """List applications for the tenant."""
        resp = self._request(
            "GET", "/applications",
            params={"status": status, "page": page, "limit": limit},
        )
        return [ApplicationResult(a) for a in resp.get("data", [])]

    def get_application(self, app_id: str) -> ApplicationResult:
        """Get a single application by ID."""
        resp = self._request("GET", f"/applications/{app_id}")
        return ApplicationResult(resp.get("data", resp))

    def update_application(self, app_id: str, **fields: Any) -> ApplicationResult:
        """Update application fields (requestedAmount, requestedTermMonths, loanPurpose)."""
        payload = {}
        if "requested_amount" in fields:
            payload["requestedAmount"] = fields["requested_amount"]
        if "requested_term_months" in fields:
            payload["requestedTermMonths"] = fields["requested_term_months"]
        if "loan_purpose" in fields:
            payload["loanPurpose"] = fields["loan_purpose"]
        # Also accept camelCase keys directly
        for key in ("requestedAmount", "requestedTermMonths", "loanPurpose"):
            if key in fields:
                payload[key] = fields[key]

        resp = self._request("PATCH", f"/applications/{app_id}", json_body=payload)
        return ApplicationResult(resp.get("data", resp))

    def transition_status(
        self,
        app_id: str,
        status: str,
        status_reason: Optional[str] = None,
        offer: Optional[Dict] = None,
    ) -> ApplicationResult:
        """Transition an application to a new status via the state machine."""
        payload: Dict[str, Any] = {"status": status}
        if status_reason is not None:
            payload["statusReason"] = status_reason
        if offer is not None:
            payload["offer"] = offer
        resp = self._request("PATCH", f"/applications/{app_id}/status", json_body=payload)
        return ApplicationResult(resp.get("data", resp))

    def get_valid_transitions(self, app_id: str) -> List[Dict]:
        """Get valid next status transitions for an application."""
        resp = self._request("GET", f"/applications/{app_id}/valid-transitions")
        data = resp.get("data", {})
        return data.get("transitions", [])

    # -------------------------------------------------------------------------
    # Documents
    # -------------------------------------------------------------------------

    def list_documents(self, app_id: str) -> List[CreditDocumentResult]:
        """List all documents for an application with AI analysis."""
        resp = self._request("GET", f"/applications/{app_id}/documents")
        return [CreditDocumentResult(d) for d in resp.get("data", [])]

    def get_document(self, app_id: str, doc_id: str) -> CreditDocumentResult:
        """Get a single document with full analysis details."""
        resp = self._request("GET", f"/applications/{app_id}/documents/{doc_id}")
        return CreditDocumentResult(resp.get("data", resp))

    def upload_document(
        self,
        app_id: str,
        file_path: str,
        document_type: str = "other",
        document_category: str = "other",
    ) -> CreditDocumentResult:
        """Upload a document file to an application."""
        with open(file_path, "rb") as f:
            resp = self._request(
                "POST",
                f"/applications/{app_id}/documents",
                files={"file": (os.path.basename(file_path), f)},
                data={
                    "documentType": document_type,
                    "documentCategory": document_category,
                },
            )
        return CreditDocumentResult(resp.get("data", resp))

    # -------------------------------------------------------------------------
    # Stipulations
    # -------------------------------------------------------------------------

    def list_stipulations(self, app_id: str, **filters: Any) -> List[StipulationResult]:
        """List stipulations for an application (filterable by type, status, source)."""
        params: Dict[str, Any] = {}
        if "type" in filters:
            params["type"] = filters["type"]
        if "status" in filters:
            params["status"] = filters["status"]
        if "source" in filters:
            params["source"] = filters["source"]
        resp = self._request("GET", f"/applications/{app_id}/stipulations", params=params)
        return [StipulationResult(s) for s in resp.get("data", [])]

    def create_stipulation(
        self,
        app_id: str,
        title: str,
        stipulation_type: str,
        description: Optional[str] = None,
        instructions: Optional[str] = None,
        document_id: Optional[str] = None,
        expires_at: Optional[str] = None,
    ) -> StipulationResult:
        """Create a new stipulation on an application."""
        payload: Dict[str, Any] = {
            "stipulationType": stipulation_type,
            "title": title,
        }
        if description is not None:
            payload["description"] = description
        if instructions is not None:
            payload["instructions"] = instructions
        if document_id is not None:
            payload["documentId"] = document_id
        if expires_at is not None:
            payload["expiresAt"] = expires_at

        resp = self._request("POST", f"/applications/{app_id}/stipulations", json_body=payload)
        return StipulationResult(resp.get("data", resp))

    def update_stipulation(self, stip_id: str, **fields: Any) -> StipulationResult:
        """Update stipulation fields."""
        resp = self._request("PATCH", f"/stipulations/{stip_id}", json_body=fields)
        return StipulationResult(resp.get("data", resp))

    def waive_stipulation(self, stip_id: str, reason: str) -> StipulationResult:
        """Waive a stipulation with a reason."""
        resp = self._request("POST", f"/stipulations/{stip_id}/waive", json_body={"reason": reason})
        return StipulationResult(resp.get("data", resp))

    def review_stipulation(self, stip_id: str, status: str) -> StipulationResult:
        """Mark a stipulation as satisfied or under_review."""
        resp = self._request("POST", f"/stipulations/{stip_id}/review", json_body={"status": status})
        return StipulationResult(resp.get("data", resp))

    def delete_stipulation(self, stip_id: str) -> bool:
        """Delete a stipulation. Returns True on success."""
        self._request("DELETE", f"/stipulations/{stip_id}")
        return True

    def get_stipulation_clearance(self, app_id: str) -> Dict:
        """Check stipulation clearance for all lifecycle gates."""
        resp = self._request("GET", f"/applications/{app_id}/stipulations/clearance")
        return resp.get("data", {})

    # -------------------------------------------------------------------------
    # Collection
    # -------------------------------------------------------------------------

    def get_collection(self, app_id: str) -> Dict:
        """Get collection run status, completeness, missing docs."""
        resp = self._request("GET", f"/applications/{app_id}/collection")
        return resp.get("data", {})

    def trigger_outreach(
        self,
        app_id: str,
        channel: str = "whatsapp",
        document_types: Optional[List[str]] = None,
        message: Optional[str] = None,
    ) -> Dict:
        """Trigger outreach to the borrower."""
        payload: Dict[str, Any] = {"channel": channel}
        if document_types is not None:
            payload["documentTypes"] = document_types
        if message is not None:
            payload["message"] = message
        resp = self._request("POST", f"/applications/{app_id}/collection/outreach", json_body=payload)
        return resp

    def instruct_agent(
        self,
        app_id: str,
        instructions: str,
        channel: str = "whatsapp",
    ) -> Dict:
        """Send AI-composed outreach from natural language instructions."""
        payload = {"instructions": instructions, "channel": channel}
        resp = self._request("POST", f"/applications/{app_id}/collection/instruct", json_body=payload)
        return resp.get("data", {})

    # -------------------------------------------------------------------------
    # Messages
    # -------------------------------------------------------------------------

    def get_thread(self, app_id: str) -> Dict:
        """Get the collaboration thread and messages for an application."""
        resp = self._request("GET", f"/applications/{app_id}/thread")
        return resp.get("data") or {}

    def send_thread_message(self, app_id: str, body: str) -> Dict:
        """Add a message to the collaboration thread."""
        resp = self._request("POST", f"/applications/{app_id}/thread/messages", json_body={"body": body})
        return resp.get("data", {})

    def send_message(
        self,
        app_id: str,
        channel: str,
        message: str,
        subject: Optional[str] = None,
    ) -> Dict:
        """Send a WhatsApp or email message directly to the borrower."""
        payload: Dict[str, Any] = {"channel": channel, "message": message}
        if subject is not None:
            payload["subject"] = subject
        resp = self._request("POST", f"/applications/{app_id}/messages", json_body=payload)
        return resp

    # -------------------------------------------------------------------------
    # Timeline
    # -------------------------------------------------------------------------

    def get_timeline(
        self,
        app_id: str,
        cursor: Optional[str] = None,
        limit: int = 50,
    ) -> Dict:
        """Get the unified timeline for an application (cursor-based pagination)."""
        resp = self._request(
            "GET", f"/applications/{app_id}/timeline",
            params={"cursor": cursor, "limit": limit},
        )
        return resp.get("data", {})

    # -------------------------------------------------------------------------
    # Webhooks
    # -------------------------------------------------------------------------

    def register_webhook(self, url: str, secret: Optional[str] = None) -> Dict:
        """Register or update the tenant webhook URL. Returns URL and secret."""
        payload: Dict[str, Any] = {"url": url}
        if secret is not None:
            payload["secret"] = secret
        resp = self._request("POST", "/webhooks", json_body=payload)
        return resp.get("data", {})

    def get_webhook(self) -> Dict:
        """Get the current webhook configuration (URL + hasSecret)."""
        resp = self._request("GET", "/webhooks")
        return resp.get("data", {})

    def test_webhook(self) -> Dict:
        """Send a test ping event to the configured webhook URL."""
        return self._request("POST", "/webhooks/test")

    # -------------------------------------------------------------------------
    # Polling helpers
    # -------------------------------------------------------------------------

    def wait_for_analysis(
        self,
        app_id: str,
        doc_id: str,
        poll_interval: int = 3,
        timeout: int = 300,
    ) -> CreditDocumentResult:
        """
        Poll a document until its processing is complete (or timeout).

        Returns the final CreditDocumentResult once processingStatus
        is no longer 'pending' or 'processing'.
        """
        deadline = time.time() + timeout
        terminal_statuses = {"completed", "failed", "error"}

        while time.time() < deadline:
            doc = self.get_document(app_id, doc_id)
            if doc.processing_status in terminal_statuses:
                return doc
            time.sleep(poll_interval)

        raise CreditError(
            f"Document {doc_id} did not finish processing within {timeout}s"
        )

    def wait_for_status(
        self,
        app_id: str,
        target_status: Union[str, List[str]],
        poll_interval: int = 5,
        timeout: int = 600,
    ) -> ApplicationResult:
        """
        Poll an application until it reaches the target status (or timeout).

        ``target_status`` can be a single status string or a list of statuses
        to match against.
        """
        targets = {target_status} if isinstance(target_status, str) else set(target_status)
        deadline = time.time() + timeout

        while time.time() < deadline:
            app = self.get_application(app_id)
            if app.status in targets:
                return app
            time.sleep(poll_interval)

        raise CreditError(
            f"Application {app_id} did not reach status {target_status} within {timeout}s"
        )


# =============================================================================
# Standalone helpers
# =============================================================================


def verify_webhook_signature(payload: str, signature: str, secret: str) -> bool:
    """
    Verify that a webhook payload was signed by Kita.

    Args:
        payload: The raw request body as a string.
        signature: The value of the ``X-Kita-Signature`` header (e.g. ``sha256=abcdef...``).
        secret: The webhook secret configured for your tenant.

    Returns:
        True if the signature is valid.
    """
    if not signature.startswith("sha256="):
        return False

    expected = hmac.HMAC(
        secret.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    received = signature[len("sha256="):]
    return hmac.compare_digest(expected, received)
