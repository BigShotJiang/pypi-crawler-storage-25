# Root-Seed API Reference v1.0

> **Framework:** Root-Seed — A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design  
> **Author:** Fardin Sabid  
> **License:** MIT

---

## Table of Contents

1. [Tensor API](#1-tensor-api)
2. [Neural Network API](#2-neural-network-api)
3. [Optimizer API](#3-optimizer-api)
4. [Data Pipeline API](#4-data-pipeline-api)
5. [Distributed API](#5-distributed-api)
6. [Random API (Aleam)](#6-random-api-aleam)
7. [Serialization API (.rs)](#7-serialization-api-rs)
8. [UI Dashboard API](#8-ui-dashboard-api)

---

## 1. Tensor API

### Creation

| Function | Description |
|:---|:---|
| `rs.Tensor(data, shape, dtype, device, requires_grad)` | Create tensor from list/array |
| `rs.tensor(data)` | Alias for Tensor creation |
| `rs.zeros(*shape)` | Tensor filled with zeros |
| `rs.ones(*shape)` | Tensor filled with ones |
| `rs.randn(*shape)` | True random from N(0,1) via Aleam |
| `rs.rand(*shape)` | True random from U(0,1) via Aleam |

### Properties

| Property | Returns |
|:---|:---|
| `.shape` | Tuple of dimensions |
| `.dtype` | `'float32'`, `'float16'`, `'int32'`, etc. |
| `.device` | `'cpu'`, `'cuda:0'`, `'rocm:0'`, etc. |
| `.requires_grad` | `bool` |
| `.grad` | Gradient tensor or `None` |

### Operations

| Method | Description |
|:---|:---|
| `.matmul(other)` | Matrix multiplication |
| `.add(other)` | Element-wise addition with broadcasting |
| `.sub(other)` | Subtraction |
| `.mul(scalar)` | Multiply by scalar |
| `.div(other)` | Division |
| `.transpose(dim0, dim1)` | Transpose dimensions |
| `.reshape(*shape)` | Reshape tensor |
| `.sum()` | Sum all elements |
| `.backward()` | Compute gradients |

### Device Transfer

| Method | Description |
|:---|:---|
| `.to(device)` | Move to specified device |
| `.cpu()` | Move to CPU |
| `.cuda()` | Move to CUDA GPU |
| `.numpy()` | Convert to numpy array |

---

## 2. Neural Network API

### Layers

| Class | Description |
|:---|:---|
| `nn.Linear(in_features, out_features)` | Fully connected: y = x @ W^T + b |
| `nn.Conv2D(in_ch, out_ch, kernel, stride, pad)` | 2D Convolution |
| `nn.Conv1D(in_ch, out_ch, kernel, stride, pad)` | 1D Convolution |
| `nn.MultiHeadAttention(d_model, num_heads)` | Scaled dot-product attention |
| `nn.TransformerEncoderLayer(d_model, num_heads)` | Self-attention + FFN block |
| `nn.TransformerEncoder(num_layers, d_model, num_heads)` | Stack of encoder layers |

### Activations

| Factory | Function |
|:---|:---|
| `nn.ReLU()` | f(x) = max(0, x) |
| `nn.GELU()` | Gaussian Error Linear Unit |
| `nn.SiLU()` | SiLU / Swish |
| `nn.Tanh()` | Hyperbolic tangent |
| `nn.Sigmoid()` | Logistic sigmoid |

### Normalization

| Class | Description |
|:---|:---|
| `nn.LayerNorm(normalized_shape)` | Layer normalization |
| `nn.RMSNorm(normalized_shape)` | RMS normalization (LLaMA-style) |
| `nn.BatchNorm1D(num_features)` | Batch normalization |
| `nn.GroupNorm(num_groups, num_channels)` | Group normalization |

### Regularization

| Class | Description |
|:---|:---|
| `nn.Dropout(keep_prob)` | True random dropout via Aleam |

### Mixture of Experts

| Class | Description |
|:---|:---|
| `nn.MoELayer(d_model, num_experts, top_k)` | Full MoE block |
| `nn.Router(d_model, num_experts, top_k)` | Top-K gating with Aleam noise |
| `nn.Expert(d_model, d_ff)` | Single expert FFN |

### Containers

| Class | Description |
|:---|:---|
| `nn.Sequential(*layers)` | Sequential layer stack |

### Base Class

| Method | Description |
|:---|:---|
| `module.forward(input)` | Compute output |
| `module.parameters()` | List of trainable parameters |
| `module.train()` | Set training mode |
| `module.eval()` | Set evaluation mode |
| `module.state_dict()` | Dict of parameter names → tensors |
| `module.load_state_dict(state)` | Load from state dict |
| `module.to(device)` | Move all parameters to device |

---

## 3. Optimizer API

| Class | Description |
|:---|:---|
| `optim.SGD(params, lr, momentum, weight_decay)` | Stochastic Gradient Descent |
| `optim.Adam(params, lr, betas, eps, weight_decay)` | Adam (Section 6.4) |
| `optim.AdamW(params, lr, betas, eps, weight_decay)` | Adam with decoupled weight decay |
| `optim.Lion(params, lr, betas, weight_decay)` | EvoLved Sign Momentum |

### Schedulers

| Class | Description |
|:---|:---|
| `optim.StepLR(optimizer, step_size, gamma)` | Step decay |
| `optim.CosineAnnealingLR(optimizer, T_max)` | Cosine annealing |
| `optim.ReduceLROnPlateau(optimizer, patience)` | Reduce on metric plateau |

### Common Methods

| Method | Description |
|:---|:---|
| `optimizer.step()` | Update parameters |
| `optimizer.zero_grad()` | Zero all gradients |
| `optimizer.set_lr(lr)` | Set learning rate |

---

## 4. Data Pipeline API

| Class | Description |
|:---|:---|
| `data.TensorDataset(data, labels)` | Dataset from tensors |
| `data.DataLoader(dataset, batch_size, shuffle)` | Batched iteration |

### Samplers

| Class | Description |
|:---|:---|
| `data.SequentialSampler()` | In-order indices |
| `data.RandomSampler(replacement)` | True random sampling (Aleam) |
| `data.BatchSampler(sampler, batch_size)` | Batched indices |

### Transforms

| Class | Description |
|:---|:---|
| `data.Compose(transforms)` | Chain transforms |
| `data.Normalize(mean, std)` | (x - mean) / std |
| `data.RandomCrop(h, w)` | Random crop (Aleam) |
| `data.RandomFlip(prob)` | Random flip (Aleam) |

---

## 5. Distributed API

| Class | Description |
|:---|:---|
| `distributed.ProcessGroup.create(backend, world_size, rank)` | Communication group |
| `distributed.CollectiveOps(process_group)` | Tensor collectives |
| `distributed.DistributedDataParallel(model, ops)` | DDP wrapper |
| `distributed.ExpertParallel(moe_layer, ops, start, end)` | Expert sharding |

### Collectives

| Method | Description |
|:---|:---|
| `all_reduce(tensor)` | Sum across ranks |
| `broadcast(tensor, src)` | Broadcast from source |
| `all_gather(tensor)` | Gather from all ranks |
| `barrier()` | Synchronize ranks |

---

## 6. Random API (Aleam)

```python
from rootseed.random import get_rng, has_hardware_entropy

rng = get_rng()
```

| Method | Description |
|:---|:---|
| `rng.random()` | True random float in [0,1) |
| `rng.uniform(low, high)` | Uniform distribution |
| `rng.gauss(mu, sigma)` | Normal distribution |
| `rng.randint(a, b)` | Random integer |
| `rng.shuffle(list)` | Shuffle in-place |
| `rng.dropout_mask(shape, keep_prob)` | Dropout mask |
| `rng.kaiming_uniform(shape, fan_in)` | Kaiming init weights |
| `rng.moe_load_balancing_noise(n)` | MoE router noise |

**No pseudorandom fallback exists. All methods use Aleam hardware entropy exclusively.**

---

## 7. Serialization API (.rs)

| Class | Description |
|:---|:---|
| `serial.RSWriter(metadata_json)` | Write .rs files |
| `serial.RSReader(filepath)` | Read .rs files (mmap) |

### Writer

| Method | Description |
|:---|:---|
| `add_tensor(name, tensor)` | Add a tensor |
| `write(filepath, compress, sign)` | Write file to disk |

### Reader

| Method | Description |
|:---|:---|
| `tensor_names()` | List tensor names |
| `load_tensor(name)` | Load single tensor (lazy) |
| `load_all_tensors()` | Load all tensors |
| `verify_signature()` | Check Ed25519 signature |

---

## 8. UI Dashboard API

| Class | Description |
|:---|:---|
| `ui.Dashboard()` | Terminal training dashboard |

### Methods

| Method | Description |
|:---|:---|
| `init(total_steps, refresh_ms)` | Initialize display |
| `update(metrics)` | Push new metrics |
| `render()` | Redraw display |
| `finish()` | Show final summary |

### Data Structures

```python
metrics = ui.TrainingMetrics()
metrics.epoch = 1
metrics.step = 100
metrics.loss = 0.342
metrics.accuracy = 0.873
metrics.lr = 1e-4
metrics.samples_per_second = 12500.0
metrics.world_size = 1

device = ui.DeviceMetrics()
device.name = "NVIDIA H100"
device.type = "CUDA"
device.memory_used_mb = 78000
device.memory_total_mb = 81500
device.utilization_pct = 95.7
metrics.devices.append(device)
```

---

**See also:**
- [Architecture Overview](ARCHITECTURE.md)
- [Backend Support Matrix](BACKENDS.md)
- [Performance Characteristics](PERFORMANCE.md)
- [Research Paper](RESEARCH_PAPER.md)