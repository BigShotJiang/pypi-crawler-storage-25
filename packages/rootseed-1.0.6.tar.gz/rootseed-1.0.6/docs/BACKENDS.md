# Root-Seed Backend Support Matrix v1.0

> **Framework:** Root-Seed — Extreme Hardware-Software Co-Design  
> **Section:** 15 — Backend Support Matrix  
> **Author:** Fardin Sabid

---

## Supported Backends

| Priority | Backend | Hardware | Status | AKD Tiers |
|:---|:---|:---|:---|:---|
| 1 | **CUDA** | NVIDIA GPUs (Volta+) | ✅ Production | 5-6 |
| 2 | **ROCm** | AMD GPUs (MI200+) | ✅ Production | 7 |
| 3 | **Vulkan** | Cross-vendor GPU | ✅ Production | 10-11 |
| 4 | **TPU** | Google Cloud TPU / Coral Edge | ✅ Production | 8 |
| 5 | **NPU** | Qualcomm Hexagon / Apple ANE | ✅ Production | 9 |
| 6 | **XNNPACK** | ARM/x86 Optimized CPU | ✅ Production | 12-14 |
| 7 | **Reference** | Universal CPU Fallback | ✅ Production | 15 |

---

## Hardware Detection

All backends are detected at runtime via DRE (Section 3). No user configuration required.

| Backend | Detection Method | Library |
|:---|:---|:---|
| CUDA | `dlopen(libcudart.so)` | libcudart.so |
| ROCm | `dlopen(libamdhip64.so)` | libamdhip64.so |
| Vulkan | `dlopen(libvulkan.so)` | libvulkan.so |
| Cloud TPU | `dlopen(libtpu.so)` | libtpu.so |
| Edge TPU | `dlopen(libedgetpu.so)` | libedgetpu.so |
| NPU (Qualcomm) | `dlopen(libhexagon.so)` | libhexagon.so |
| NPU (Apple) | CoreML framework | Metal.framework |

---

## Capability Matrix

| Capability | CUDA | ROCm | Vulkan | TPU | NPU | CPU |
|:---|:---|:---|:---|:---|:---|:---|
| Tensor/Matrix Cores | ✅ CC≥7.0 | ✅ gfx90a+ | ❌ | ❌ | ❌ | ❌ |
| FP8 | ✅ CC≥8.9 | ❌ | ❌ | ❌ | ❌ | ❌ |
| FP16 | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ |
| BF16 | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ |
| INT8 | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| Sparse MM (2:4) | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Subgroup Ops | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ |
| Unified Memory | ✅ | ❌ | ❌ | ❌ | ✅ | ✅ |
| Pinned Memory | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |

---

## Dependency Matrix by Platform

| Environment | CPU Backend | GPU Backend | Distributed | Random |
|:---|:---|:---|:---|:---|
| NVIDIA DGX H100 | XNNPACK | CUDA | NCCL | Aleam |
| AMD MI300X | XNNPACK | ROCm | RCCL | Aleam |
| Cross-Vendor GPU | XNNPACK | Vulkan | — | Aleam |
| Google TPU Pod | XNNPACK | TPU | TPU Runtime | Aleam |
| Snapdragon 8 Gen 3 | XNNPACK | NPU (Hexagon) | — | Aleam |
| Apple M3 Max | XNNPACK | Metal + ANE | — | Aleam |
| ARM Server (Graviton) | XNNPACK | — | — | Aleam |
| x86_64 Fallback | Reference | — | — | Aleam |

---

## Graceful Degradation

If no accelerator is detected, Root-Seed falls back in priority order:

```
CUDA → ROCm → Vulkan → TPU → NPU → XNNPACK → Reference (CPU)
```

The Reference backend is **always available** — pure C++ standard library, zero external dependencies.