# ============================================================================
# Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
# random/__init__.py — Aleam True Random Number System (Section 8)
# Root-Seed contains NO pseudorandom number generation. No PRNG. No fallback.
# All stochastic operations flow EXCLUSIVELY through Aleam hardware entropy.
# Copyright (c) 2026 Fardin Sabid
# ============================================================================

import math
import aleam as al
from typing import List, Optional, Tuple

# ---------------------------------------------------------------------------
# Verify Aleam hardware entropy at import time
# If this fails, Root-Seed cannot operate — no PRNG fallback exists.
# ---------------------------------------------------------------------------
_verify_rng = al.Aleam()
try:
    _verify_value = _verify_rng.random()
    _HAS_HARDWARE_ENTROPY = True
except Exception as e:
    _HAS_HARDWARE_ENTROPY = False
    raise RuntimeError(
        "Root-Seed: Aleam hardware entropy verification FAILED.\n"
        "Root-Seed requires true hardware entropy for ALL random operations.\n"
        "No pseudorandom fallback exists by design (Section 8, Research Paper).\n"
        f"Error: {e}\n"
        "Please verify:\n"
        "  1. aleam>=1.0.3 is installed: pip install aleam\n"
        "  2. Your hardware entropy sources are functional\n"
        "  3. You have sufficient system entropy available"
    ) from e


class RandomGenerator:
    """
    Root-Seed's exclusive random number source.

    All stochastic operations in the framework — weight initialization,
    dropout masks, DataLoader shuffling, MoE load balancing noise,
    gradient noise — flow through this class.

    Architecture (Section 8):
        Hardware Entropy → ChaCha20 Conditioning → Distribution Generators
        ↑
        Aleam exclusively. No PRNG. No Mersenne Twister. No Philox.
    """

    def __init__(self):
        """
        Create a new Aleam true random generator.
        Each instance is stateless — no seed, no state vector, no recurrence.
        Every call to random() produces an independent true random value.
        """
        if not _HAS_HARDWARE_ENTROPY:
            raise RuntimeError(
                "Root-Seed: Cannot create RandomGenerator — "
                "Aleam hardware entropy is unavailable."
            )
        self._rng = al.Aleam()

    # ========================================================================
    # Core Random Primitives
    # ========================================================================

    def random(self) -> float:
        """
        True random float in [0, 1).
        Uses hardware entropy via Aleam's Ψ(t) = BLAKE2s((Φ × Ξ(t)) ⊕ τ(t)).
        """
        return self._rng.random()

    def random_uint64(self) -> int:
        """True random 64-bit unsigned integer."""
        return self._rng.random_uint64()

    def uniform(self, low: float = 0.0, high: float = 1.0) -> float:
        """True random float uniformly distributed in [low, high)."""
        return self._rng.uniform(low, high)

    def gauss(self, mu: float = 0.0, sigma: float = 1.0) -> float:
        """True random float from normal distribution N(mu, sigma)."""
        return self._rng.gauss(mu, sigma)

    def randint(self, a: int, b: int) -> int:
        """True random integer in [a, b]."""
        return self._rng.randint(a, b)

    def choice(self, seq: list):
        """True random element from a sequence."""
        return self._rng.choice(seq)

    def shuffle(self, lst: list) -> None:
        """Shuffle a list in-place using true random numbers."""
        self._rng.shuffle(lst)

    def sample(self, population: list, k: int) -> list:
        """Sample k unique elements from population using true randomness."""
        return self._rng.sample(population, k)

    def random_bytes(self, n: int) -> list:
        """Generate n true random bytes (returned as list of ints 0-255)."""
        return self._rng.random_bytes(n)

    # ========================================================================
    # Batch Operations — generate multiple random values efficiently
    # ========================================================================

    def uniform_batch(self, n: int, low: float = 0.0, high: float = 1.0) -> List[float]:
        """Generate n true random floats uniformly in [low, high)."""
        return [self._rng.uniform(low, high) for _ in range(n)]

    def gauss_batch(self, n: int, mu: float = 0.0, sigma: float = 1.0) -> List[float]:
        """Generate n true random floats from N(mu, sigma)."""
        return [self._rng.gauss(mu, sigma) for _ in range(n)]

    # ========================================================================
    # AI/ML Specialized Generators (Section 8.3)
    # ========================================================================

    def weight_initialization(self, shape: Tuple[int, ...],
                               method: str = "kaiming_uniform",
                               fan_in: int = -1,
                               fan_out: int = -1) -> List[float]:
        """
        Generate initial weights using true random numbers.

        Methods:
            kaiming_uniform — y = rand * sqrt(6/fan_in) * 2 - bound
            kaiming_normal  — y = randn * sqrt(2/fan_in)
            xavier_uniform  — bound = sqrt(6/(fan_in+fan_out))
            xavier_normal   — std = sqrt(2/(fan_in+fan_out))
        """
        n = 1
        for d in shape:
            n *= d

        if method == "kaiming_uniform":
            if fan_in <= 0:
                raise ValueError("kaiming_uniform requires fan_in > 0")
            bound = math.sqrt(6.0 / fan_in)
            return [self._rng.uniform(-bound, bound) for _ in range(n)]

        elif method == "kaiming_normal":
            if fan_in <= 0:
                raise ValueError("kaiming_normal requires fan_in > 0")
            std = math.sqrt(2.0 / fan_in)
            return [self._rng.gauss(0.0, std) for _ in range(n)]

        elif method == "xavier_uniform":
            if fan_in <= 0 or fan_out <= 0:
                raise ValueError("xavier_uniform requires fan_in > 0 and fan_out > 0")
            bound = math.sqrt(6.0 / (fan_in + fan_out))
            return [self._rng.uniform(-bound, bound) for _ in range(n)]

        elif method == "xavier_normal":
            if fan_in <= 0 or fan_out <= 0:
                raise ValueError("xavier_normal requires fan_in > 0 and fan_out > 0")
            std = math.sqrt(2.0 / (fan_in + fan_out))
            return [self._rng.gauss(0.0, std) for _ in range(n)]

        else:
            raise ValueError(f"Unknown initialization method: {method}")

    def dropout_mask(self, shape: Tuple[int, ...], keep_prob: float) -> List[float]:
        """
        Generate a dropout mask using true random numbers.

        Each element has probability 'keep_prob' of being 1.0 (keep)
        and (1 - keep_prob) of being 0.0 (drop).
        Elements are scaled by 1/keep_prob for variance preservation.

        Returns:
            List of floats (0.0 or 1.0/keep_prob) of length numel(shape).
        """
        if not (0.0 < keep_prob <= 1.0):
            raise ValueError(f"keep_prob must be in (0, 1], got {keep_prob}")

        n = 1
        for d in shape:
            n *= d

        scale = 1.0 / keep_prob
        return [
            scale if self._rng.random() < keep_prob else 0.0
            for _ in range(n)
        ]

    def mini_batch_indices(self, n: int, batch_size: int) -> List[int]:
        """
        Sample batch_size unique indices from [0, n) using true randomness.
        Used by DataLoader for epoch shuffling (Section 14.1).
        """
        if batch_size > n:
            raise ValueError(f"batch_size ({batch_size}) cannot exceed n ({n})")
        population = list(range(n))
        return self._rng.sample(population, batch_size)

    def shuffle_indices(self, n: int) -> List[int]:
        """
        Return a true random permutation of indices [0, n).
        Used by DataLoader for full dataset shuffling.
        """
        indices = list(range(n))
        self._rng.shuffle(indices)
        return indices

    def moe_load_balancing_noise(self, num_experts: int,
                                  noise_std: float = 0.01) -> List[float]:
        """
        Generate small Gaussian noise for Mixture of Experts load balancing.
        Added to router logits to prevent deterministic expert collapse.

        Section 6.2: G(x) = Softmax(TopK(W_g · x + noise, k))
        """
        return [self._rng.gauss(0.0, noise_std) for _ in range(num_experts)]

    def gradient_noise(self, scale: float = 0.0) -> float:
        """
        Generate noise for gradient noise injection (Section 5, optimizers).
        Returns 0.0 if scale is 0 (no noise).
        """
        if scale <= 0.0:
            return 0.0
        return self._rng.gauss(0.0, scale)


# ============================================================================
# Global RandomGenerator instance (created once, shared across framework)
# ============================================================================
_GLOBAL_RNG: Optional[RandomGenerator] = None


def get_rng() -> RandomGenerator:
    """
    Returns the global RandomGenerator singleton.
    All Root-Seed components use this single entry point for randomness.
    No other random source exists in the framework.
    """
    global _GLOBAL_RNG
    if _GLOBAL_RNG is None:
        _GLOBAL_RNG = RandomGenerator()
    return _GLOBAL_RNG


def has_hardware_entropy() -> bool:
    """Returns True if Aleam hardware entropy is verified and available."""
    return _HAS_HARDWARE_ENTROPY