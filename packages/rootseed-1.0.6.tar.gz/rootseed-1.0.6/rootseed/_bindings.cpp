// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// _bindings.cpp — pybind11 Python Bindings for Root-Seed Core
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>

#include "core/tensor.h"
#include "core/shape.h"
#include "core/dtype.h"
#include "hal/device.h"
#include "dre/detect.h"

namespace py = pybind11;
using namespace rootseed::core;
using namespace rootseed::hal;

// ============================================================================
// Helper: parse device string
// ============================================================================

static Device parse_device(const std::string& s) {
    if (s == "cpu" || s == "CPU") return Device{DeviceType::CPU, 0};
    if (s.find("cuda") == 0) return Device{DeviceType::CUDA, 0};
    if (s.find("rocm") == 0) return Device{DeviceType::ROCm, 0};
    if (s == "vulkan") return Device{DeviceType::Vulkan, 0};
    return Device{DeviceType::CPU, 0};
}

// ============================================================================
// Python-facing Tensor wrapper
// ============================================================================

class PyTensor {
public:
    PyTensor() : tensor_(std::make_shared<Tensor>()) {}
    explicit PyTensor(std::shared_ptr<Tensor> t) : tensor_(t) {}

    std::shared_ptr<Tensor> impl() { return tensor_; }

    // Shape
    std::vector<int64_t> shape() const {
        auto& s = tensor_->shape();
        std::vector<int64_t> result(s.ndim());
        for (size_t i = 0; i < s.ndim(); ++i) result[i] = s[i];
        return result;
    }

    // DType
    std::string dtype() const {
        return std::string(dtype_name(tensor_->dtype()));
    }

    // Device
    std::string device() const {
        return tensor_->device().to_string();
    }

    // Gradient
    bool requires_grad() const { return tensor_->requires_grad(); }
    void set_requires_grad(bool v) { tensor_->set_requires_grad(v); }

    PyTensor grad() const {
        if (tensor_->grad().numel() > 0) {
            return PyTensor(std::make_shared<Tensor>(tensor_->grad()));
        }
        return PyTensor();
    }

    // Operations
    PyTensor matmul(const PyTensor& other) {
        return PyTensor(std::make_shared<Tensor>(tensor_->matmul(*other.tensor_)));
    }

    PyTensor add(const PyTensor& other) {
        return PyTensor(std::make_shared<Tensor>(tensor_->add(*other.tensor_)));
    }

    PyTensor sub(const PyTensor& other) {
        return PyTensor(std::make_shared<Tensor>(tensor_->sub(*other.tensor_)));
    }

    PyTensor mul(const PyTensor& other) {
        return PyTensor(std::make_shared<Tensor>(tensor_->mul(*other.tensor_)));
    }

    PyTensor mul_scalar(float s) {
        return PyTensor(std::make_shared<Tensor>(tensor_->mul(s)));
    }

    PyTensor div(const PyTensor& other) {
        return PyTensor(std::make_shared<Tensor>(tensor_->div(*other.tensor_)));
    }

    PyTensor transpose(int dim0, int dim1) {
        return PyTensor(std::make_shared<Tensor>(tensor_->transpose(dim0, dim1)));
    }

    PyTensor reshape(const std::vector<int64_t>& new_shape) {
        Shape s(new_shape);
        return PyTensor(std::make_shared<Tensor>(tensor_->reshape(s)));
    }

    // Gradient
    void backward() { tensor_->backward(); }

    // Device transfer
    PyTensor to(const std::string& dev_str) {
        Device dev = parse_device(dev_str);
        return PyTensor(std::make_shared<Tensor>(tensor_->to(dev)));
    }

    PyTensor cpu() {
        return PyTensor(std::make_shared<Tensor>(tensor_->cpu()));
    }

    PyTensor cuda() {
        return PyTensor(std::make_shared<Tensor>(tensor_->cuda()));
    }

    // Numpy conversion
    py::array to_numpy() const {
        auto s = shape();
        std::vector<ssize_t> npy_shape(s.begin(), s.end());
        py::array result(py::dtype::of<float>(), npy_shape);

        float* buf = static_cast<float*>(result.request().ptr);
        for (int64_t i = 0; i < tensor_->numel(); ++i) {
            buf[i] = tensor_->item(i);
        }
        return result;
    }

    // Element access
    float item() const {
        if (tensor_->numel() == 1) {
            return tensor_->item(0);
        }
        throw std::runtime_error("item() only works on scalar tensors");
    }

private:
    std::shared_ptr<Tensor> tensor_;
};

// ============================================================================
// Module factory functions
// ============================================================================

static PyTensor tensor_from_numpy(py::array arr, const std::string& dtype_str,
                                   const std::vector<int64_t>& shape_vec,
                                   const std::string& device_str,
                                   bool requires_grad) {
    Shape shape(shape_vec);
    DType dtype = dtype_from_string(dtype_str);
    Device dev = parse_device(device_str);

    std::vector<float> data(arr.size());
    float* buf = static_cast<float*>(arr.request().ptr);
    for (size_t i = 0; i < arr.size(); ++i) {
        data[i] = buf[i];
    }

    Tensor t = Tensor::from_vector(data, shape, dtype, dev);
    t.set_requires_grad(requires_grad);
    return PyTensor(std::make_shared<Tensor>(t));
}

static PyTensor zeros(const std::vector<int64_t>& shape_vec,
                       const std::string& dtype_str,
                       const std::string& device_str,
                       bool requires_grad) {
    Shape shape(shape_vec);
    DType dtype = dtype_from_string(dtype_str);
    Device dev = parse_device(device_str);

    Tensor t = Tensor::zeros(shape, dtype, dev);
    t.set_requires_grad(requires_grad);
    return PyTensor(std::make_shared<Tensor>(t));
}

static PyTensor ones(const std::vector<int64_t>& shape_vec,
                      const std::string& dtype_str,
                      const std::string& device_str,
                      bool requires_grad) {
    Shape shape(shape_vec);
    DType dtype = dtype_from_string(dtype_str);
    Device dev = parse_device(device_str);

    Tensor t = Tensor::ones(shape, dtype, dev);
    t.set_requires_grad(requires_grad);
    return PyTensor(std::make_shared<Tensor>(t));
}

static std::string get_device_info() {
    auto sys = rootseed::dre::detect_system();
    return rootseed::dre::system_summary(sys);
}

// ============================================================================
// Module definition
// ============================================================================

PYBIND11_MODULE(_rootseed, m) {
    m.doc() = "Root-Seed: Extreme Hardware-Software Co-Design Deep Learning Framework";

    // Tensor class
    py::class_<PyTensor>(m, "Tensor")
        .def(py::init<>())
        .def("shape", &PyTensor::shape)
        .def("dtype", &PyTensor::dtype)
        .def("device", &PyTensor::device)
        .def("requires_grad", &PyTensor::requires_grad)
        .def("set_requires_grad", &PyTensor::set_requires_grad)
        .def("grad", &PyTensor::grad)
        .def("matmul", &PyTensor::matmul)
        .def("add", &PyTensor::add)
        .def("sub", &PyTensor::sub)
        .def("mul", &PyTensor::mul)
        .def("mul_scalar", &PyTensor::mul_scalar)
        .def("div", &PyTensor::div)
        .def("transpose", &PyTensor::transpose)
        .def("reshape", &PyTensor::reshape)
        .def("backward", &PyTensor::backward)
        .def("to", &PyTensor::to)
        .def("cpu", &PyTensor::cpu)
        .def("cuda", &PyTensor::cuda)
        .def("to_numpy", &PyTensor::to_numpy)
        .def("item", &PyTensor::item);

    // Factory functions
    m.def("tensor_from_numpy", &tensor_from_numpy,
          py::arg("arr"), py::arg("dtype"), py::arg("shape"),
          py::arg("device") = "cpu", py::arg("requires_grad") = false);
    m.def("zeros", &zeros,
          py::arg("shape"), py::arg("dtype") = "float32",
          py::arg("device") = "cpu", py::arg("requires_grad") = false);
    m.def("ones", &ones,
          py::arg("shape"), py::arg("dtype") = "float32",
          py::arg("device") = "cpu", py::arg("requires_grad") = false);
    m.def("get_device", &get_device_info);
}