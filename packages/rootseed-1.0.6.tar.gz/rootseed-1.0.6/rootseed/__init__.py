# ============================================================================
# Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
# __init__.py — Public API: Tensor with DRE Initialization (Section 3, 6)
# Copyright (c) 2026 Fardin Sabid
# ============================================================================

"""
Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design.

Quickstart:
    import rootseed as rs
    x = rs.randn(100, 10)
    y = x.matmul(rs.randn(10, 5))
"""

import sys
import os
import numpy as np

# ---------------------------------------------------------------------------
# Dynamic Runtime Environment — runs at import time (Section 3)
# ---------------------------------------------------------------------------
def _init_dre():
    from rootseed.random import get_rng, has_hardware_entropy
    
    if not has_hardware_entropy():
        raise RuntimeError(
            "Root-Seed: Aleam hardware entropy is unavailable.\n"
            "All random operations require true hardware entropy.\n"
            "No pseudorandom fallback exists.\n"
            "Install: pip install aleam>=1.0.3"
        )
    
    print(f"[Root-Seed] v{__version__} initialized.")
    print(f"[Root-Seed] True random numbers: Aleam (no PRNG)")


# ---------------------------------------------------------------------------
# Import the C++ extension module
# ---------------------------------------------------------------------------
try:
    from rootseed import _rootseed
except ImportError as e:
    raise ImportError(
        "Root-Seed C++ extension not found.\n"
        "Build it with: pip install -e .\n"
        f"Error: {e}"
    )


# ---------------------------------------------------------------------------
# Python-facing Tensor class (wraps C++ tensor)
# ---------------------------------------------------------------------------

class Tensor:
    """Root-Seed Tensor with automatic gradient tracking."""

    def __init__(self, data=None, shape=None, dtype='float32', device='cpu', requires_grad=False):
        if data is not None:
            if isinstance(data, (list, tuple)):
                data = np.array(data, dtype=np.float32)
            elif isinstance(data, (int, float)):
                data = np.array([data], dtype=np.float32)

            if isinstance(data, np.ndarray):
                if shape is not None:
                    data = data.reshape(shape)
                self._cpp_tensor = _rootseed.tensor_from_numpy(
                    data, str(data.dtype), list(data.shape), device, requires_grad
                )
            else:
                raise TypeError(f"Unsupported data type: {type(data)}")
        elif shape is not None:
            self._cpp_tensor = _rootseed.zeros(list(shape), dtype, device, requires_grad)
        else:
            raise ValueError("Either data or shape must be provided")

    @classmethod
    def _from_cpp(cls, cpp_tensor):
        t = cls.__new__(cls)
        t._cpp_tensor = cpp_tensor
        return t

    @property
    def shape(self):
        return tuple(self._cpp_tensor.shape())

    @property
    def dtype(self):
        return self._cpp_tensor.dtype()

    @property
    def device(self):
        return self._cpp_tensor.device()

    @property
    def requires_grad(self):
        return self._cpp_tensor.requires_grad()

    @requires_grad.setter
    def requires_grad(self, value):
        self._cpp_tensor.set_requires_grad(value)

    @property
    def grad(self):
        g = self._cpp_tensor.grad()
        return Tensor._from_cpp(g) if g is not None else None

    def numpy(self):
        return self._cpp_tensor.to_numpy()

    def item(self):
        return self._cpp_tensor.item()

    def matmul(self, other):
        return Tensor._from_cpp(self._cpp_tensor.matmul(other._cpp_tensor))

    def add(self, other):
        if isinstance(other, (int, float)):
            other = Tensor(other)
        return Tensor._from_cpp(self._cpp_tensor.add(other._cpp_tensor))

    def sub(self, other):
        if isinstance(other, (int, float)):
            other = Tensor(other)
        return Tensor._from_cpp(self._cpp_tensor.sub(other._cpp_tensor))

    def mul(self, other):
        if isinstance(other, (int, float)):
            return Tensor._from_cpp(self._cpp_tensor.mul_scalar(float(other)))
        return Tensor._from_cpp(self._cpp_tensor.mul(other._cpp_tensor))

    def div(self, other):
        if isinstance(other, (int, float)):
            return Tensor._from_cpp(self._cpp_tensor.mul_scalar(1.0 / float(other)))
        return Tensor._from_cpp(self._cpp_tensor.div(other._cpp_tensor))

    def transpose(self, dim0=-1, dim1=-1):
        return Tensor._from_cpp(self._cpp_tensor.transpose(dim0, dim1))

    def reshape(self, *shape):
        return Tensor._from_cpp(self._cpp_tensor.reshape(list(shape)))

    def backward(self):
        self._cpp_tensor.backward()

    def to(self, device):
        return Tensor._from_cpp(self._cpp_tensor.to(device))

    def cpu(self):
        return self.to('cpu')

    def cuda(self):
        return self.to('cuda:0')

    def __matmul__(self, other):
        return self.matmul(other)

    def __add__(self, other):
        return self.add(other if isinstance(other, Tensor) else Tensor(other))
    def __radd__(self, other):
        return Tensor(other).add(self)
    def __sub__(self, other):
        return self.sub(other if isinstance(other, Tensor) else Tensor(other))
    def __mul__(self, other):
        return self.mul(other if isinstance(other, Tensor) else Tensor(other))
    def __rmul__(self, other):
        return self.mul(Tensor(other))
    def __truediv__(self, other):
        return self.div(Tensor(other))
    def __neg__(self):
        return self.mul(Tensor(-1.0))

    def __repr__(self):
        return f"Tensor(shape={self.shape}, dtype={self.dtype}, device='{self.device}')"


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------

def tensor(data, dtype='float32', device='cpu', requires_grad=False):
    return Tensor(data, dtype=dtype, device=device, requires_grad=requires_grad)

def zeros(*shape, dtype='float32', device='cpu', requires_grad=False):
    if len(shape) == 1 and isinstance(shape[0], (list, tuple)):
        shape = shape[0]
    return Tensor._from_cpp(_rootseed.zeros(list(shape), dtype, device, requires_grad))

def ones(*shape, dtype='float32', device='cpu', requires_grad=False):
    if len(shape) == 1 and isinstance(shape[0], (list, tuple)):
        shape = shape[0]
    return Tensor._from_cpp(_rootseed.ones(list(shape), dtype, device, requires_grad))

def randn(*shape, dtype='float32', device='cpu', requires_grad=False):
    from rootseed.random import get_rng
    if len(shape) == 1 and isinstance(shape[0], (list, tuple)):
        shape = shape[0]
    n = 1
    for d in shape:
        n *= d
    rng = get_rng()
    data = [rng.gauss(0.0, 1.0) for _ in range(n)]
    return Tensor(data, shape=shape, dtype=dtype, device=device, requires_grad=requires_grad)

def rand(*shape, dtype='float32', device='cpu', requires_grad=False):
    from rootseed.random import get_rng
    if len(shape) == 1 and isinstance(shape[0], (list, tuple)):
        shape = shape[0]
    n = 1
    for d in shape:
        n *= d
    rng = get_rng()
    data = [rng.random() for _ in range(n)]
    return Tensor(data, shape=shape, dtype=dtype, device=device, requires_grad=requires_grad)


# ---------------------------------------------------------------------------
# Version + DRE init
# ---------------------------------------------------------------------------
from rootseed._version import __version__
_init_dre()