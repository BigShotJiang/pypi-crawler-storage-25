# Changelog

All notable changes to Root-Seed will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Nothing yet — changes for v1.0.1+ will be listed here

## [1.0.0] — 2026-04-26

### Added
- Complete Root-Seed v1.0 architecture with extreme hardware-software co-Design
- 15-tier Adaptive Kernel Dispatch (AKD) system for optimal kernel selection
- Dynamic Runtime Environment (DRE) with auto-detection of 7 backends
- Native Mixture of Experts (MoE) support with fused kernel (4.0× speedup, 70% memory reduction)
- Aleam true random number integration as exclusive random source — no PRNG fallback
- `.rs` model serialization format with zero-copy mmap loading and Ed25519 signing
- Sparse-first computation with native CSR, CSC, COO, and BSR formats
- Memory-efficient buddy allocator with hardware-aware cache hierarchy optimization
- Autograd engine with reverse-mode automatic differentiation
- Neural network module system: Linear, Conv1D/2D, LayerNorm, RMSNorm, BatchNorm, GroupNorm
- Multi-Head Attention with scaled dot-product and Transformer Encoder layers
- Optimizers: SGD (with momentum/Nesterov), Adam, AdamW, Lion
- Learning rate schedulers: StepLR, MultiStepLR, CosineAnnealingLR, ReduceLROnPlateau
- Data pipeline: Dataset, DataLoader with multi-worker prefetching, Sampler, Transforms
- Distributed training: ProcessGroup (NCCL/RCCL/CPU), CollectiveOps, DDP, ExpertParallel
- GPU backends: CUDA (Tensor Cores, FP8), ROCm (Matrix Cores), Vulkan, Metal, TPU, NPU
- Rich terminal UI dashboard with auto-scaling device display (1 to 1000+ GPUs)
- Cross-platform build system: CMake + pybind11 with system-level C++ dependencies
- Comprehensive test suite and examples
- CI/CD pipelines for build, test, docs, and PyPI release
- Docker images for CUDA, ROCm, and CPU-only deployment
- Model converter: PyTorch/TensorFlow/Keras → .rs format

[unreleased]: https://github.com/fardinsabid/root-seed/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/fardinsabid/root-seed/releases/tag/v1.0.0