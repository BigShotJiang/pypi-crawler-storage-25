// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// rocm_device.cpp — AMD ROCm GPU Device Implementation (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "hal/rocm/rocm_device.h"
#include "utils/log.h"

#include <cstdlib>
#include <cstring>
#include <dlfcn.h>

namespace rootseed {
namespace hal {
namespace rocm {

struct HIPAPI {
    void* (*malloc)(size_t) = nullptr;
    void (*free)(void*) = nullptr;
    void (*memcpy)(void*, const void*, size_t, int) = nullptr;
    void (*stream_create)(void**) = nullptr;
    void (*stream_destroy)(void*) = nullptr;
    void (*stream_sync)(void*) = nullptr;
    void (*device_sync)() = nullptr;
    void (*mem_get_info)(size_t*, size_t*) = nullptr;
    bool loaded = false;
};

static HIPAPI hip;

static void load_hip() {
    if (hip.loaded) return;

    void* lib = dlopen("libamdhip64.so", RTLD_LAZY);
    if (!lib) lib = dlopen("libhiprtc.so", RTLD_LAZY);
    if (!lib) {
        RS_LOG_DEBUG("ROCm not available: HIP library not found");
        return;
    }

    hip.malloc        = (decltype(hip.malloc))        dlsym(lib, "hipMalloc");
    hip.free          = (decltype(hip.free))          dlsym(lib, "hipFree");
    hip.memcpy        = (decltype(hip.memcpy))        dlsym(lib, "hipMemcpy");
    hip.stream_create = (decltype(hip.stream_create)) dlsym(lib, "hipStreamCreate");
    hip.stream_destroy= (decltype(hip.stream_destroy))dlsym(lib, "hipStreamDestroy");
    hip.stream_sync   = (decltype(hip.stream_sync))   dlsym(lib, "hipStreamSynchronize");
    hip.device_sync   = (decltype(hip.device_sync))   dlsym(lib, "hipDeviceSynchronize");
    hip.mem_get_info  = (decltype(hip.mem_get_info))  dlsym(lib, "hipMemGetInfo");

    hip.loaded = (hip.malloc && hip.free && hip.memcpy);
}

ROCmDevice::ROCmDevice(int device_index)
    : AbstractDevice(make_device_info(device_index))
    , device_index_(device_index) {

    load_hip();
    rocm_available_ = hip.loaded;

    RS_LOG_INFO(rocm_available_ ? "ROCmDevice: HIP available" : "ROCmDevice: HIP not available — CPU fallback");
}

DeviceInfo ROCmDevice::make_device_info(int index) {
    DeviceInfo info;
    info.device = Device{DeviceType::ROCm, index};
    info.name = "AMD ROCm GPU";
    info.vendor = "AMD";
    info.capabilities = DeviceCapability::TensorCores | DeviceCapability::FP16 |
                        DeviceCapability::BF16 | DeviceCapability::SparseMM;
    return info;
}

ROCmDevice::~ROCmDevice() {
    for (auto* s : streams_) {
        if (hip.stream_destroy) hip.stream_destroy(s);
    }
}

void* ROCmDevice::allocate(size_t size, AllocFlags) {
    if (!rocm_available_) return std::aligned_alloc(64, size);
    void* ptr = nullptr;
    if (hip.malloc) hip.malloc(&ptr, size);
    return ptr;
}

void ROCmDevice::deallocate(void* ptr) {
    if (!ptr) return;
    if (rocm_available_ && hip.free) hip.free(ptr);
    else std::free(ptr);
}

void ROCmDevice::memcpy(void* dst, const void* src, size_t size, int kind) {
    if (rocm_available_ && hip.memcpy) hip.memcpy(dst, src, size, kind);
    else std::memcpy(dst, src, size);
}

void ROCmDevice::synchronize() {
    if (rocm_available_ && hip.device_sync) hip.device_sync();
}

void* ROCmDevice::create_stream() {
    if (!rocm_available_) return nullptr;
    void* stream = nullptr;
    if (hip.stream_create) hip.stream_create(&stream);
    if (stream) streams_.push_back(stream);
    return stream;
}

void ROCmDevice::destroy_stream(void* stream) {
    if (rocm_available_ && hip.stream_destroy) hip.stream_destroy(stream);
}

void ROCmDevice::stream_synchronize(void* stream) {
    if (rocm_available_ && hip.stream_sync) hip.stream_sync(stream);
}

size_t ROCmDevice::total_memory() const {
    if (rocm_available_ && hip.mem_get_info) { size_t f, t; hip.mem_get_info(&f, &t); return t; }
    return info_.total_memory;
}

size_t ROCmDevice::available_memory() const {
    if (rocm_available_ && hip.mem_get_info) { size_t f, t; hip.mem_get_info(&f, &t); return f; }
    return info_.available_memory;
}

} // namespace rocm
} // namespace hal
} // namespace rootseed