// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// rocm_device.h — AMD ROCm GPU Device Backend (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "hal/device.h"

namespace rootseed {
namespace hal {
namespace rocm {

class ROCmDevice : public AbstractDevice {
public:
    explicit ROCmDevice(int device_index = 0);
    ~ROCmDevice() override;

    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    void memcpy(void* dst, const void* src, size_t size, int kind = 0) override;
    void synchronize() override;

    void* create_stream() override;
    void destroy_stream(void* stream) override;
    void stream_synchronize(void* stream) override;

    size_t total_memory() const override;
    size_t available_memory() const override;
    uint32_t max_threads_per_block() const override { return 1024; }
    size_t max_shared_memory() const override { return 64 * 1024; }

    bool is_available() const noexcept { return rocm_available_; }

private:
    bool rocm_available_ = false;
    int device_index_;
    std::vector<void*> streams_;
};

} // namespace rocm
} // namespace hal
} // namespace rootseed