// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// tpu_device.h — Google TPU Backend: Cloud TPU and Edge TPU (Coral) (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "hal/device.h"

namespace rootseed {
namespace hal {
namespace tpu {

// ============================================================================
// TPUType — distinguishes Cloud TPU from Edge TPU
// ============================================================================

enum class TPUType {
    Cloud,    // Google Cloud TPU (v2, v3, v4, v5) — accessed via libtpu.so
    Edge,     // Coral Edge TPU — accessed via libedgetpu.so
    Unknown,
};

// ============================================================================
// TPUDevice — Google TPU backend
//
// Cloud TPU:
//   - Accessed via libtpu.so runtime (XLA-compiled models)
//   - Supports bfloat16 natively
//   - MXU (Matrix Multiply Unit) for massive matmul throughput
//   - High-bandwidth memory (HBM)
//
// Edge TPU (Coral):
//   - USB/PCIe/M.2 form factor
//   - INT8 quantized inference
//   - Accessed via libedgetpu.so
// ============================================================================

class TPUDevice : public AbstractDevice {
public:
    explicit TPUDevice(int device_index = 0, TPUType tpu_type = TPUType::Cloud);
    ~TPUDevice() override;

    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    void memcpy(void* dst, const void* src, size_t size, int kind = 0) override;
    void synchronize() override;

    void* create_stream() override;
    void destroy_stream(void* stream) override;
    void stream_synchronize(void* stream) override;

    size_t total_memory() const override;
    size_t available_memory() const override;
    uint32_t max_threads_per_block() const override { return 1; }
    size_t max_shared_memory() const override { return 0; }

    bool is_available() const noexcept { return tpu_available_; }
    TPUType tpu_type() const noexcept { return tpu_type_; }
    bool is_cloud() const noexcept { return tpu_type_ == TPUType::Cloud; }
    bool is_edge()  const noexcept { return tpu_type_ == TPUType::Edge; }

private:
    bool tpu_available_ = false;
    TPUType tpu_type_;
    int device_index_;
};

} // namespace tpu
} // namespace hal
} // namespace rootseed