// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// tpu_device.cpp — Google TPU Device Implementation: libtpu / libedgetpu Runtime (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "hal/tpu/tpu_device.h"
#include "utils/log.h"

#include <cstdlib>
#include <cstring>
#include <dlfcn.h>

namespace rootseed {
namespace hal {
namespace tpu {

struct TPUAPI {
    void* (*allocate)(size_t) = nullptr;
    void  (*deallocate)(void*) = nullptr;
    void  (*synchronize)() = nullptr;
    bool loaded = false;
};

static TPUAPI tpu_api;
static TPUAPI edge_api;

static void load_tpu_runtime() {
    if (tpu_api.loaded) return;

    // Try Cloud TPU runtime
    void* lib = dlopen("libtpu.so", RTLD_LAZY);
    if (lib) {
        tpu_api.allocate    = (decltype(tpu_api.allocate))    dlsym(lib, "tpu_allocate");
        tpu_api.deallocate  = (decltype(tpu_api.deallocate))  dlsym(lib, "tpu_deallocate");
        tpu_api.synchronize = (decltype(tpu_api.synchronize)) dlsym(lib, "tpu_synchronize");
        tpu_api.loaded = (tpu_api.allocate != nullptr);
        if (tpu_api.loaded) {
            RS_LOG_INFO("TPU: Cloud TPU runtime loaded (libtpu.so)");
        }
    }

    // Try Edge TPU runtime
    void* edge_lib = dlopen("libedgetpu.so", RTLD_LAZY);
    if (edge_lib) {
        edge_api.allocate    = (decltype(edge_api.allocate))    dlsym(edge_lib, "edgetpu_allocate");
        edge_api.deallocate  = (decltype(edge_api.deallocate))  dlsym(edge_lib, "edgetpu_deallocate");
        edge_api.synchronize = (decltype(edge_api.synchronize)) dlsym(edge_lib, "edgetpu_synchronize");
        edge_api.loaded = (edge_api.allocate != nullptr);
        if (edge_api.loaded) {
            RS_LOG_INFO("TPU: Edge TPU runtime loaded (libedgetpu.so) — Coral");
        }
    }
}

TPUDevice::TPUDevice(int device_index, TPUType tpu_type)
    : AbstractDevice(make_device_info(device_index, tpu_type))
    , tpu_type_(tpu_type)
    , device_index_(device_index) {

    load_tpu_runtime();

    if (tpu_type_ == TPUType::Cloud) {
        tpu_available_ = tpu_api.loaded;
    } else {
        tpu_available_ = edge_api.loaded;
    }

    RS_LOG_INFO(tpu_available_ ? "TPUDevice: " + std::string(tpu_type_ == TPUType::Cloud ? "Cloud" : "Edge") + " TPU available"
                                : "TPUDevice: TPU not available — CPU fallback");
}

DeviceInfo TPUDevice::make_device_info(int index, TPUType type) {
    DeviceInfo info;
    info.device = Device{DeviceType::TPU, index};
    info.vendor = "Google";

    if (type == TPUType::Cloud) {
        info.name = "Google Cloud TPU";
        info.capabilities = DeviceCapability::BF16 | DeviceCapability::INT8 |
                            DeviceCapability::SparseMM;
    } else {
        info.name = "Google Coral Edge TPU";
        info.capabilities = DeviceCapability::INT8;
    }
    return info;
}

TPUDevice::~TPUDevice() {}

void* TPUDevice::allocate(size_t size, AllocFlags) {
    if (!tpu_available_) return std::aligned_alloc(64, size);

    if (tpu_type_ == TPUType::Cloud && tpu_api.allocate) {
        return tpu_api.allocate(size);
    } else if (tpu_type_ == TPUType::Edge && edge_api.allocate) {
        return edge_api.allocate(size);
    }
    return std::aligned_alloc(64, size);
}

void TPUDevice::deallocate(void* ptr) {
    if (!ptr) return;
    if (tpu_available_) {
        if (tpu_type_ == TPUType::Cloud && tpu_api.deallocate) { tpu_api.deallocate(ptr); return; }
        if (tpu_type_ == TPUType::Edge && edge_api.deallocate) { edge_api.deallocate(ptr); return; }
    }
    std::free(ptr);
}

void TPUDevice::memcpy(void* dst, const void* src, size_t size, int) {
    if (dst && src && size > 0) std::memcpy(dst, src, size);
}

void TPUDevice::synchronize() {
    if (tpu_available_) {
        if (tpu_type_ == TPUType::Cloud && tpu_api.synchronize) { tpu_api.synchronize(); return; }
        if (tpu_type_ == TPUType::Edge && edge_api.synchronize) { edge_api.synchronize(); return; }
    }
}

void* TPUDevice::create_stream() { return nullptr; }
void TPUDevice::destroy_stream(void*) {}
void TPUDevice::stream_synchronize(void*) {}

size_t TPUDevice::total_memory() const { return info_.total_memory; }
size_t TPUDevice::available_memory() const { return info_.available_memory; }

} // namespace tpu
} // namespace hal
} // namespace rootseed