// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// vulkan_device.h — Vulkan Compute GPU Backend (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "hal/device.h"

namespace rootseed {
namespace hal {
namespace vulkan {

// ============================================================================
// VulkanDevice — cross-vendor GPU backend via Vulkan Compute
//
// Provides:
//   - vkAllocateMemory / vkFreeMemory for GPU memory
//   - VkCommandBuffer for asynchronous compute dispatch
//   - Subgroup operations for efficient reduction (Tier 10 in AKD)
//   - SPIR-V shader compilation
// ============================================================================

class VulkanDevice : public AbstractDevice {
public:
    explicit VulkanDevice(int device_index = 0);
    ~VulkanDevice() override;

    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    void memcpy(void* dst, const void* src, size_t size, int kind = 0) override;
    void synchronize() override;

    void* create_stream() override;
    void destroy_stream(void* stream) override;
    void stream_synchronize(void* stream) override;

    size_t total_memory() const override;
    size_t available_memory() const override;
    uint32_t max_threads_per_block() const override { return subgroup_size_; }
    size_t max_shared_memory() const override { return 32 * 1024; }

    bool is_available() const noexcept { return vulkan_available_; }
    uint32_t subgroup_size() const noexcept { return subgroup_size_; }
    bool has_subgroup_ops() const noexcept { return has_subgroup_ops_; }
    bool has_fp16() const noexcept { return has_fp16_; }

private:
    bool vulkan_available_ = false;
    int device_index_;
    uint32_t subgroup_size_ = 32;
    bool has_subgroup_ops_ = false;
    bool has_fp16_ = false;
    std::vector<void*> streams_;
};

} // namespace vulkan
} // namespace hal
} // namespace rootseed