// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// device.h — Hardware Abstraction Layer: Device Interface and Manager (Section 5.1, 10)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/memory.h"   // Device struct, AllocFlags
#include "dre/context.h"   // HardwareContextProvider

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>
#include <memory>
#include <mutex>
#include <unordered_map>

namespace rootseed {
namespace hal {

using core::Device;
using core::DeviceType;
using core::AllocFlags;

// ============================================================================
// DeviceCapability — bitmask of optional hardware features
// ============================================================================

enum class DeviceCapability : uint64_t {
    None            = 0,
    TensorCores     = 1ULL << 0,   // NVIDIA Tensor Cores / AMD Matrix Cores
    FP8             = 1ULL << 1,   // FP8 native support (Hopper/Ada)
    FP16            = 1ULL << 2,   // FP16 half-precision
    BF16            = 1ULL << 3,   // BFloat16
    INT8            = 1ULL << 4,   // INT8 dot product acceleration
    UnifiedMemory   = 1ULL << 5,   // GPU unified memory (CPU+GPU share address space)
    SubgroupOps     = 1ULL << 6,   // Vulkan subgroup operations
    CooperativeGroups = 1ULL << 7, // CUDA cooperative groups (SM 6.0+)
    SparseMM        = 1ULL << 8,   // Native sparse matrix multiply (2:4 structured)
    HardwareRNG     = 1ULL << 9,   // Hardware random number generator (via Aleam)
    PinnedMemory    = 1ULL << 10,  // Page-locked memory for fast CPU↔GPU transfer
    HugePages       = 1ULL << 11,  // Hugepage memory support
    NUMA            = 1ULL << 12,  // Non-uniform memory access awareness
};

inline DeviceCapability operator|(DeviceCapability a, DeviceCapability b) {
    return static_cast<DeviceCapability>(static_cast<uint64_t>(a) | static_cast<uint64_t>(b));
}
inline DeviceCapability operator&(DeviceCapability a, DeviceCapability b) {
    return static_cast<DeviceCapability>(static_cast<uint64_t>(a) & static_cast<uint64_t>(b));
}
inline bool has_capability(DeviceCapability caps, DeviceCapability cap) {
    return (static_cast<uint64_t>(caps) & static_cast<uint64_t>(cap)) != 0;
}

// ============================================================================
// DeviceInfo — descriptive information about a physical device
// ============================================================================

struct DeviceInfo {
    Device device;
    std::string name;
    std::string vendor;
    DeviceCapability capabilities = DeviceCapability::None;
    size_t total_memory = 0;       // Total device memory in bytes
    size_t available_memory = 0;   // Currently free memory
    uint32_t compute_units = 0;    // SM / CU / core count
    uint32_t max_threads_per_block = 1024;
    size_t max_shared_memory = 48 * 1024;  // Per-block shared memory (48KB default)
    bool is_active = false;
};

// ============================================================================
// AbstractDevice — base class for all hardware backends
//
// Every backend (CUDA, ROCm, Vulkan, TPU, NPU, XNNPACK, Reference)
// implements this interface. The AKD system dispatches through
// DeviceManager which routes to the correct concrete device.
// ============================================================================

class AbstractDevice {
public:
    explicit AbstractDevice(const DeviceInfo& info) : info_(info) {}
    virtual ~AbstractDevice() = default;

    // ---- Identity ----
    const DeviceInfo& info() const noexcept { return info_; }
    DeviceType type() const noexcept { return info_.device.type; }
    int index() const noexcept { return info_.device.index; }
    std::string name() const { return info_.name; }
    DeviceCapability capabilities() const noexcept { return info_.capabilities; }
    bool has_capability(DeviceCapability cap) const noexcept {
        return hal::has_capability(info_.capabilities, cap);
    }

    // ---- Memory Management ----
    virtual void* allocate(size_t size, AllocFlags flags = AllocFlags::None) = 0;
    virtual void deallocate(void* ptr) = 0;
    virtual void memcpy(void* dst, const void* src, size_t size, int kind = 0) = 0;
    virtual void synchronize() = 0;
    virtual void* create_stream() { return nullptr; }
    virtual void destroy_stream(void* /*stream*/) {}
    virtual void stream_synchronize(void* /*stream*/) {}

    // ---- Device Properties ----
    virtual size_t total_memory() const { return info_.total_memory; }
    virtual size_t available_memory() const { return info_.available_memory; }
    virtual uint32_t max_threads_per_block() const { return info_.max_threads_per_block; }
    virtual size_t max_shared_memory() const { return info_.max_shared_memory; }

    // ---- Live Stats for UI Dashboard (Section 15) ----
    /// Returns current device utilization (0-100%). Override for real GPU stats.
    virtual float utilization_pct() const { return 0.0f; }

    /// Returns currently allocated memory in bytes (total - available).
    virtual size_t memory_used() const {
        return info_.total_memory - info_.available_memory;
    }

    /// Returns true if this device is actively being used for compute.
    virtual bool is_active() const { return info_.is_active; }

    /// Returns a short type string: "CUDA", "ROCm", "Vulkan", "TPU", "NPU", "CPU", "Metal"
    virtual std::string type_string() const {
        switch (info_.device.type) {
            case DeviceType::CUDA:   return "CUDA";
            case DeviceType::ROCm:   return "ROCm";
            case DeviceType::Vulkan: return "Vulkan";
            case DeviceType::TPU:    return "TPU";
            case DeviceType::NPU:    return "NPU";
            case DeviceType::Metal:  return "Metal";
            default:                 return "CPU";
        }
    }

protected:
    DeviceInfo info_;
};

// ============================================================================
// DeviceManager — singleton managing all detected devices
// ============================================================================

class DeviceManager {
public:
    static DeviceManager& instance();
    void initialize();
    void register_device(std::unique_ptr<AbstractDevice> device);
    AbstractDevice* get_device(DeviceType type, int index = 0);
    AbstractDevice* get_default_device();
    AbstractDevice* get_cpu_device();
    const std::vector<AbstractDevice*>& all_devices() const { return device_list_; }
    size_t device_count() const noexcept { return device_list_.size(); }
    bool has_gpu() const noexcept;
    void print_summary() const;

private:
    DeviceManager() = default;
    ~DeviceManager();
    DeviceManager(const DeviceManager&) = delete;
    DeviceManager& operator=(const DeviceManager&) = delete;

    std::vector<std::unique_ptr<AbstractDevice>> owned_devices_;
    std::vector<AbstractDevice*> device_list_;
    std::unordered_map<Device, AbstractDevice*,
        std::function<size_t(const Device&)>> device_map_;
    mutable std::mutex mutex_;
    bool initialized_ = false;
};

} // namespace hal
} // namespace rootseed