// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// npu_device.h — Neural Processing Unit Backend: Qualcomm Hexagon, Apple ANE (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "hal/device.h"

namespace rootseed {
namespace hal {
namespace npu {

// ============================================================================
// NPUVendor — distinguishes Qualcomm from Apple NPU
// ============================================================================

enum class NPUVendor {
    Qualcomm,   // Snapdragon Hexagon DSP
    Apple,      // Apple Neural Engine (accessed via CoreML/ANE)
    Unknown,
};

// ============================================================================
// NPUDevice — dedicated Neural Processing Unit for low-power ML inference
//
// Qualcomm Hexagon:
//   - Accessed via libhexagon.so (Hexagon DSP runtime)
//   - INT8/FP16 optimized inference
//   - HVX (Hexagon Vector eXtensions) for SIMD acceleration
//   - Found on Snapdragon mobile platforms
//
// Apple Neural Engine:
//   - Accessed via CoreML framework
//   - INT8/FP16 inference acceleration
//   - Low-power always-on processing
//   - See metal/metal_ane.cpp for Apple-specific implementation
// ============================================================================

class NPUDevice : public AbstractDevice {
public:
    explicit NPUDevice(int device_index = 0, NPUVendor vendor = NPUVendor::Qualcomm);
    ~NPUDevice() override;

    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    void memcpy(void* dst, const void* src, size_t size, int kind = 0) override;
    void synchronize() override;

    void* create_stream() override;
    void destroy_stream(void* stream) override;
    void stream_synchronize(void* stream) override;

    size_t total_memory() const override;
    size_t available_memory() const override;
    uint32_t max_threads_per_block() const override { return 1; }
    size_t max_shared_memory() const override { return 0; }

    bool is_available() const noexcept { return npu_available_; }
    NPUVendor vendor() const noexcept { return vendor_; }
    bool has_hvx() const noexcept { return has_hvx_; }

private:
    static DeviceInfo make_device_info(int index, NPUVendor vendor);
    bool npu_available_ = false;
    NPUVendor vendor_;
    bool has_hvx_ = false;
    int device_index_;
};

} // namespace npu
} // namespace hal
} // namespace rootseed