// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// npu_device.cpp — NPU Device Implementation: Qualcomm Hexagon, Apple ANE (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "hal/npu/npu_device.h"
#include "utils/log.h"

#include <cstdlib>
#include <cstring>
#include <dlfcn.h>

namespace rootseed {
namespace hal {
namespace npu {

struct NPUAPI {
    void* (*allocate)(size_t) = nullptr;
    void  (*deallocate)(void*) = nullptr;
    void  (*synchronize)() = nullptr;
    bool  (*has_hvx)() = nullptr;
    bool loaded = false;
};

static NPUAPI hexagon_api;

static void load_npu_runtime() {
    if (hexagon_api.loaded) return;

    // Try Qualcomm Hexagon DSP runtime
    void* lib = dlopen("libhexagon.so", RTLD_LAZY);
    if (!lib) lib = dlopen("libhexagon_skel.so", RTLD_LAZY);

    if (lib) {
        hexagon_api.allocate    = (decltype(hexagon_api.allocate))    dlsym(lib, "hexagon_allocate");
        hexagon_api.deallocate  = (decltype(hexagon_api.deallocate))  dlsym(lib, "hexagon_deallocate");
        hexagon_api.synchronize = (decltype(hexagon_api.synchronize)) dlsym(lib, "hexagon_synchronize");
        hexagon_api.has_hvx     = (decltype(hexagon_api.has_hvx))     dlsym(lib, "hexagon_has_hvx");
        hexagon_api.loaded = (hexagon_api.allocate != nullptr);

        if (hexagon_api.loaded) {
            RS_LOG_INFO("NPU: Qualcomm Hexagon DSP runtime loaded (libhexagon.so)");
        }
    } else {
        RS_LOG_DEBUG("NPU: Qualcomm Hexagon DSP not available");
    }

    // Apple Neural Engine is detected via Metal framework (see metal_ane.cpp).
    // No separate library needed — ANE is integrated into MPS/CoreML on Apple Silicon.
}

NPUDevice::NPUDevice(int device_index, NPUVendor vendor)
    : AbstractDevice(make_device_info(device_index, vendor))
    , vendor_(vendor)
    , device_index_(device_index) {

    load_npu_runtime();

    if (vendor_ == NPUVendor::Qualcomm) {
        npu_available_ = hexagon_api.loaded;
        if (npu_available_ && hexagon_api.has_hvx) {
            has_hvx_ = hexagon_api.has_hvx();
        }
    } else if (vendor_ == NPUVendor::Apple) {
        // ANE availability checked in metal_ane.cpp — stub here
        npu_available_ = false;
    }

    RS_LOG_INFO(npu_available_ ? "NPUDevice: " + std::string(vendor_ == NPUVendor::Qualcomm ? "Hexagon" : "ANE") + " available"
                                : "NPUDevice: NPU not available — CPU fallback");
}

DeviceInfo NPUDevice::make_device_info(int index, NPUVendor vendor) {
    DeviceInfo info;
    info.device = Device{DeviceType::NPU, index};
    info.vendor = (vendor == NPUVendor::Qualcomm) ? "Qualcomm" : "Apple";

    if (vendor == NPUVendor::Qualcomm) {
        info.name = "Qualcomm Hexagon NPU";
        info.capabilities = DeviceCapability::INT8 | DeviceCapability::FP16;
    } else {
        info.name = "Apple Neural Engine";
        info.capabilities = DeviceCapability::INT8 | DeviceCapability::FP16;
    }
    return info;
}

NPUDevice::~NPUDevice() {}

void* NPUDevice::allocate(size_t size, AllocFlags) {
    if (!npu_available_) return std::aligned_alloc(64, size);
    if (vendor_ == NPUVendor::Qualcomm && hexagon_api.allocate) {
        return hexagon_api.allocate(size);
    }
    return std::aligned_alloc(64, size);
}

void NPUDevice::deallocate(void* ptr) {
    if (!ptr) return;
    if (npu_available_ && vendor_ == NPUVendor::Qualcomm && hexagon_api.deallocate) {
        hexagon_api.deallocate(ptr);
        return;
    }
    std::free(ptr);
}

void NPUDevice::memcpy(void* dst, const void* src, size_t size, int) {
    if (dst && src && size > 0) std::memcpy(dst, src, size);
}

void NPUDevice::synchronize() {
    if (npu_available_ && vendor_ == NPUVendor::Qualcomm && hexagon_api.synchronize) {
        hexagon_api.synchronize();
    }
}

void* NPUDevice::create_stream() { return nullptr; }
void NPUDevice::destroy_stream(void*) {}
void NPUDevice::stream_synchronize(void*) {}

size_t NPUDevice::total_memory() const { return info_.total_memory; }
size_t NPUDevice::available_memory() const { return info_.available_memory; }

} // namespace npu
} // namespace hal
} // namespace rootseed