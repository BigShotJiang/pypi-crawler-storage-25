// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// metal_device.mm — Apple Metal GPU Device Implementation (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "hal/metal/metal_device.h"
#include "utils/log.h"

#ifdef __APPLE__
#import <Metal/Metal.h>
#import <Foundation/Foundation.h>
#endif

#include <cstdlib>
#include <cstring>

namespace rootseed {
namespace hal {
namespace metal {

MetalDevice::MetalDevice(int device_index)
    : AbstractDevice(make_device_info(device_index))
    , device_index_(device_index) {

#ifdef __APPLE__
    @autoreleasepool {
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        if (device) {
            metal_available_ = true;
            unified_memory_ = [device hasUnifiedMemory];
            RS_LOG_INFO("MetalDevice: " + std::string([[device name] UTF8String]) +
                        " (unified memory: " + (unified_memory_ ? "yes" : "no") + ")");
        } else {
            RS_LOG_INFO("MetalDevice: Metal not available — CPU fallback");
        }
    }
#else
    RS_LOG_INFO("MetalDevice: not on Apple platform — CPU fallback");
#endif
}

DeviceInfo MetalDevice::make_device_info(int index) {
    DeviceInfo info;
    info.device = Device{DeviceType::Metal, index};
    info.name = "Apple Metal GPU";
    info.vendor = "Apple";
    info.capabilities = DeviceCapability::FP16 | DeviceCapability::BF16 |
                        DeviceCapability::UnifiedMemory;
    return info;
}

MetalDevice::~MetalDevice() {}

void* MetalDevice::allocate(size_t size, AllocFlags) {
    if (!metal_available_) return std::aligned_alloc(64, size);

#ifdef __APPLE__
    // MTLBuffer would be created here — unified memory means no transfer needed
    return std::aligned_alloc(64, size);
#else
    return std::aligned_alloc(64, size);
#endif
}

void MetalDevice::deallocate(void* ptr) {
    std::free(ptr);
}

void MetalDevice::memcpy(void* dst, const void* src, size_t size, int) {
    if (unified_memory_) {
        // Unified memory: no copy needed — both CPU and GPU see the same memory
        return;
    }
    std::memcpy(dst, src, size);
}

void MetalDevice::synchronize() {
#ifdef __APPLE__
    // [commandBuffer waitUntilCompleted] equivalent
#endif
}

void* MetalDevice::create_stream() { return nullptr; }
void MetalDevice::destroy_stream(void*) {}
void MetalDevice::stream_synchronize(void*) {}

size_t MetalDevice::total_memory() const {
#ifdef __APPLE__
    return info_.total_memory;  // os_proc_available_memory() in production
#endif
    return info_.total_memory;
}

size_t MetalDevice::available_memory() const {
    return info_.available_memory;
}

} // namespace metal
} // namespace hal
} // namespace rootseed