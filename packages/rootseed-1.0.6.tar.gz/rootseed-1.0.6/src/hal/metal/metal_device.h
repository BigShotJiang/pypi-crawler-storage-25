// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// metal_device.h — Apple Metal GPU Backend for Apple Silicon (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "hal/device.h"

namespace rootseed {
namespace hal {
namespace metal {

// ============================================================================
// MetalDevice — Apple GPU backend via Metal Performance Shaders
//
// Provides:
//   - MTLBuffer for GPU memory allocation
//   - MTLCommandQueue for asynchronous compute dispatch
//   - Apple Neural Engine (ANE) integration for ML inference
//   - Unified memory: CPU and GPU share the same address space
// ============================================================================

class MetalDevice : public AbstractDevice {
public:
    explicit MetalDevice(int device_index = 0);
    ~MetalDevice() override;

    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    void memcpy(void* dst, const void* src, size_t size, int kind = 0) override;
    void synchronize() override;

    void* create_stream() override;
    void destroy_stream(void* stream) override;
    void stream_synchronize(void* stream) override;

    size_t total_memory() const override;
    size_t available_memory() const override;
    uint32_t max_threads_per_block() const override { return 1024; }
    size_t max_shared_memory() const override { return 32 * 1024; }

    bool is_available() const noexcept { return metal_available_; }
    bool has_unified_memory() const noexcept { return unified_memory_; }
    bool has_ane() const noexcept { return ane_available_; }

private:
    bool metal_available_ = false;
    bool unified_memory_ = false;
    bool ane_available_ = false;
    int device_index_;
    std::vector<void*> command_queues_;
};

} // namespace metal
} // namespace hal
} // namespace rootseed