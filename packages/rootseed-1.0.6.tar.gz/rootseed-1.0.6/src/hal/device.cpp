// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// device.cpp — Device Manager Implementation (Section 5.1, 10)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "device.h"
#include "utils/log.h"
#include "utils/exception.h"

#include <algorithm>
using namespace rootseed::utils;

namespace rootseed {
namespace hal {

// ============================================================================
// DeviceManager
// ============================================================================

DeviceManager& DeviceManager::instance() {
    static DeviceManager s_instance;
    return s_instance;
}

DeviceManager::~DeviceManager() {
    // owned_devices_ auto-destroys, device_list_ and device_map_ are non-owning
}

void DeviceManager::initialize() {
    std::lock_guard<std::mutex> lock(mutex_);
    
    if (initialized_) return;
    
    RS_LOG_INFO("Initializing DeviceManager...");
    
    // Ensure hardware context is available
    auto& ctx = dre::HardwareContextProvider::instance();
    if (!ctx.is_initialized()) {
        ctx.initialize();
    }

    // Device objects are registered by HAL backends (reference, xnnpack, cuda, etc.)
    // during their own initialization. For now, we ensure the CPU reference
    // device is always available (created by the first HAL backend init).
    
    initialized_ = true;
    
    RS_LOG_INFO("DeviceManager initialized.");
    print_summary();
}

void DeviceManager::register_device(std::unique_ptr<AbstractDevice> device) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    Device dev = device->info().device;
    
    // Check for duplicate
    auto it = device_map_.find(dev);
    if (it != device_map_.end()) {
        RS_LOG_WARN("Device already registered: " + dev.to_string() + ". Replacing.");
        // Remove old from list
        device_list_.erase(
            std::remove(device_list_.begin(), device_list_.end(), it->second),
            device_list_.end()
        );
    }
    
    AbstractDevice* raw_ptr = device.get();
    device_map_[dev] = raw_ptr;
    device_list_.push_back(raw_ptr);
    owned_devices_.push_back(std::move(device));
    
    RS_LOG_INFO("Registered device: " + dev.to_string() + " (" + raw_ptr->name() + ")");
}

AbstractDevice* DeviceManager::get_device(DeviceType type, int index) {
    std::lock_guard<std::mutex> lock(mutex_);
    
    Device dev{type, index};
    auto it = device_map_.find(dev);
    if (it != device_map_.end()) {
        return it->second;
    }
    
    // Fallback: try CPU device
    if (type != DeviceType::CPU) {
        RS_LOG_WARN("Device " + dev.to_string() + " not found. Falling back to CPU.");
        return get_cpu_device();
    }
    
    RS_THROW(ErrorCode::HardwareUnsupported, "No device available for: " + dev.to_string());
}

AbstractDevice* DeviceManager::get_default_device() {
    std::lock_guard<std::mutex> lock(mutex_);
    
    // Priority: CUDA → ROCm → Vulkan → TPU → NPU → CPU
    static const DeviceType priority[] = {
        DeviceType::CUDA, DeviceType::ROCm, DeviceType::Vulkan,
        DeviceType::TPU,  DeviceType::NPU,  DeviceType::CPU
    };
    
    for (auto type : priority) {
        Device dev{type, 0};
        auto it = device_map_.find(dev);
        if (it != device_map_.end()) {
            return it->second;
        }
    }
    
    RS_THROW(ErrorCode::HardwareUnsupported, "No devices registered at all.");
}

AbstractDevice* DeviceManager::get_cpu_device() {
    std::lock_guard<std::mutex> lock(mutex_);
    
    Device cpu{DeviceType::CPU, 0};
    auto it = device_map_.find(cpu);
    if (it != device_map_.end()) {
        return it->second;
    }
    
    RS_THROW(ErrorCode::HardwareUnsupported, "CPU device not registered.");
}

bool DeviceManager::has_gpu() const noexcept {
    for (const auto* dev : device_list_) {
        if (dev->info().device.is_gpu()) return true;
    }
    return false;
}

void DeviceManager::print_summary() const {
    RS_LOG_INFO("=== Registered Devices ===");
    for (const auto* dev : device_list_) {
        const auto& info = dev->info();
        std::string caps;
        if (hal::has_capability(info.capabilities, DeviceCapability::TensorCores)) caps += " TensorCores";
        if (hal::has_capability(info.capabilities, DeviceCapability::FP8))         caps += " FP8";
        if (hal::has_capability(info.capabilities, DeviceCapability::FP16))        caps += " FP16";
        if (hal::has_capability(info.capabilities, DeviceCapability::BF16))        caps += " BF16";
        if (caps.empty()) caps = " (base)";
        
        RS_LOG_INFO("  " + info.device.to_string() + ": " + info.name +
                    " [" + std::to_string(info.total_memory / (1024*1024)) + " MB]" +
                    caps);
    }
}

} // namespace hal
} // namespace rootseed