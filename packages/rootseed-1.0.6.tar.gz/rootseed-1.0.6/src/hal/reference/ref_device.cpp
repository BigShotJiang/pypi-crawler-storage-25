// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// ref_device.cpp — Reference CPU Device Implementation (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "ref_device.h"
#include "hal/device.h"
#include "dre/context.h"
#include "utils/log.h"

#include <cstdlib>
#include <cstring>
#include <thread>
#include <sys/sysinfo.h>

namespace rootseed {
namespace hal {
namespace reference {

// ============================================================================
// ReferenceDevice
// ============================================================================

ReferenceDevice::ReferenceDevice(int index)
    : AbstractDevice(make_device_info(index))
    , num_threads_(std::thread::hardware_concurrency()) {
    
    if (num_threads_ == 0) num_threads_ = 1;
}

ReferenceDevice::~ReferenceDevice() = default;

DeviceInfo ReferenceDevice::make_device_info(int index) {
    DeviceInfo info;
    info.device = Device{DeviceType::CPU, index};
    
    auto& ctx = dre::HardwareContextProvider::instance();
    if (ctx.is_initialized()) {
        info.name = ctx.cpu_info().brand;
        info.vendor = ctx.cpu_info().vendor;
        info.total_memory = ctx.total_ram();
        info.compute_units = ctx.num_cores();
    } else {
        info.name = "CPU (Reference Fallback)";
        info.vendor = "Unknown";
        struct sysinfo si;
        if (sysinfo(&si) == 0) {
            info.total_memory = si.totalram * si.mem_unit;
        }
        info.compute_units = std::thread::hardware_concurrency();
    }
    
    info.available_memory = info.total_memory;  // CPU: all RAM is "available"
    info.max_threads_per_block = 1;             // CPU is scalar per thread
    info.max_shared_memory = 0;                  // No shared memory concept
    
    // Reference CPU has basic capabilities
    info.capabilities = DeviceCapability::None;
    // FP16/FP32/FP64 always available via software
    info.is_active = true;
    
    return info;
}

// ============================================================================
// Memory Management
// ============================================================================

void* ReferenceDevice::allocate(size_t size, AllocFlags flags) {
    void* ptr = nullptr;
    
    if (has_flag(flags, AllocFlags::HugePages)) {
        // Hugepage allocation via mmap (handled by core::CPUAllocator)
        // For reference device, we delegate to the memory manager
        ptr = std::aligned_alloc(4096, size);
    } else {
        ptr = std::aligned_alloc(64, size);  // Cache-line aligned
    }
    
    if (!ptr) {
        RS_LOG_ERROR("ReferenceDevice: allocation of " + std::to_string(size) + " bytes failed");
    }
    
    if (ptr && has_flag(flags, AllocFlags::ZeroInit)) {
        std::memset(ptr, 0, size);
    }
    
    return ptr;
}

void ReferenceDevice::deallocate(void* ptr) {
    if (ptr) {
        std::free(ptr);
    }
}

void ReferenceDevice::memcpy(void* dst, const void* src, size_t size, int /*kind*/) {
    // On CPU, all memory is the same device — kind is ignored
    if (dst && src && size > 0) {
        std::memcpy(dst, src, size);
    }
}

void ReferenceDevice::synchronize() {
    // CPU operations are synchronous — no-op
}

// ============================================================================
// Device Properties
// ============================================================================

size_t ReferenceDevice::total_memory() const {
    struct sysinfo si;
    if (sysinfo(&si) == 0) {
        return si.totalram * si.mem_unit;
    }
    return info_.total_memory;
}

size_t ReferenceDevice::available_memory() const {
    struct sysinfo si;
    if (sysinfo(&si) == 0) {
        return si.freeram * si.mem_unit;
    }
    return info_.available_memory;
}

// ============================================================================
// Factory
// ============================================================================

std::unique_ptr<ReferenceDevice> create_reference_device(int index) {
    auto device = std::make_unique<ReferenceDevice>(index);
    
    RS_LOG_INFO("Created ReferenceDevice[" + std::to_string(index) + "]: " + device->name());
    
    // Register with DeviceManager
    DeviceManager::instance().register_device(
        std::make_unique<ReferenceDevice>(index)
    );
    
    return device;
}

} // namespace reference
} // namespace hal
} // namespace rootseed