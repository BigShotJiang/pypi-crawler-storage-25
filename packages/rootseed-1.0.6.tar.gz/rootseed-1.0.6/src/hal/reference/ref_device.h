// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// ref_device.h — Reference CPU Device: Pure C++ Fallback Backend (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "hal/device.h"

namespace rootseed {
namespace hal {
namespace reference {

// ============================================================================
// ReferenceDevice — universal CPU fallback using pure C++ standard library
//
// This is the guaranteed-always-available backend (Tier 15 in AKD).
// Uses std::aligned_alloc for memory, std::memcpy for transfers.
// No external dependencies beyond the C++ standard library.
// ============================================================================

class ReferenceDevice : public AbstractDevice {
public:
    explicit ReferenceDevice(int index = 0);
    ~ReferenceDevice() override;

    // ---- Memory Management (Section 11) ----
    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    void memcpy(void* dst, const void* src, size_t size, int kind = 0) override;

    // ---- Synchronization ----
    void synchronize() override;

    // ---- Streams (no-op for CPU) ----
    void* create_stream() override { return nullptr; }
    void destroy_stream(void* /*stream*/) override {}
    void stream_synchronize(void* /*stream*/) override {}

    // ---- Device Properties ----
    size_t total_memory() const override;
    size_t available_memory() const override;
    uint32_t max_threads_per_block() const override { return 1; }
    size_t max_shared_memory() const override { return 0; }

    // ---- CPU-Specific ----
    uint32_t num_threads() const noexcept { return num_threads_; }
    void set_num_threads(uint32_t n) { num_threads_ = n; }

private:
    static DeviceInfo make_device_info(int index);
    uint32_t num_threads_;
};

/// Factory: create and register the Reference CPU device with DeviceManager.
std::unique_ptr<ReferenceDevice> create_reference_device(int index = 0);

} // namespace reference
} // namespace hal
} // namespace rootseed