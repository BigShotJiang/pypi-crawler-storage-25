// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// xnnpack_device.h — XNNPACK Optimized CPU Backend (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "hal/device.h"

// Forward declarations for XNNPACK types (opaque handles)
struct xnn_runtime;
struct pthreadpool;

namespace rootseed {
namespace hal {
namespace xnnpack {

// ============================================================================
// XNNPACKDevice — Google XNNPACK backend for optimized CPU inference
//
// Tiers 12-14 in the AKD system (Section 4):
//   Tier 12: ARM + XNNPACK + SVE
//   Tier 13: ARM + XNNPACK + NEON
//   Tier 14: CPU + XNNPACK + SIMD
// ============================================================================

class XNNPACKDevice : public AbstractDevice {
public:
    explicit XNNPACKDevice(int index = 0);
    ~XNNPACKDevice() override;

    // ---- Memory Management ----
    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    void memcpy(void* dst, const void* src, size_t size, int kind = 0) override;

    // ---- Synchronization ----
    void synchronize() override;

    // ---- Streams ----
    void* create_stream() override;
    void destroy_stream(void* stream) override;
    void stream_synchronize(void* stream) override;

    // ---- XNNPACK-Specific ----
    void* create_runtime();
    void delete_runtime(void* runtime);
    void* pthreadpool_handle() const noexcept { return pthreadpool_; }
    void set_num_threads(uint32_t n);
    uint32_t num_threads() const noexcept { return num_threads_; }

private:
    static DeviceInfo make_device_info(int index);
    void* pthreadpool_;
    uint32_t num_threads_;
    bool xnnpack_available_;
};

/// Factory: create and register an XNNPACK device.
std::unique_ptr<XNNPACKDevice> create_xnnpack_device(int index = 0);

} // namespace xnnpack
} // namespace hal
} // namespace rootseed