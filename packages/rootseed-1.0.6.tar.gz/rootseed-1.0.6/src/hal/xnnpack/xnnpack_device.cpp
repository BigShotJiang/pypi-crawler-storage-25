// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// xnnpack_device.cpp — XNNPACK Optimized CPU Backend Implementation (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "xnnpack_device.h"
#include "hal/device.h"
#include "dre/context.h"
#include "utils/log.h"

#include <cstdlib>
#include <cstring>
#include <thread>

// XNNPACK is conditionally included
#ifdef RS_HAS_XNNPACK
#include <xnnpack.h>
#include <pthreadpool.h>
#endif

namespace rootseed {
namespace hal {
namespace xnnpack {

// ============================================================================
// XNNPACKDevice
// ============================================================================

XNNPACKDevice::XNNPACKDevice(int index)
    : AbstractDevice(make_device_info(index))
    , pthreadpool_(nullptr)
    , num_threads_(std::thread::hardware_concurrency())
    , xnnpack_available_(false) {
    
    if (num_threads_ == 0) num_threads_ = 1;

#ifdef RS_HAS_XNNPACK
    // Initialize XNNPACK
    xnn_status status = xnn_initialize(nullptr);
    if (status == xnn_status_success) {
        xnnpack_available_ = true;
        
        // Create thread pool
        pthreadpool_ = pthreadpool_create(num_threads_);
        
        RS_LOG_INFO("XNNPACK initialized with " + std::to_string(num_threads_) + " threads");
    } else {
        RS_LOG_WARN("XNNPACK initialization failed (status=" + std::to_string(status) + ")");
        xnnpack_available_ = false;
    }
#else
    RS_LOG_INFO("XNNPACK not compiled in — using reference CPU fallback for XNNPACK device");
    xnnpack_available_ = false;
#endif
}

XNNPACKDevice::~XNNPACKDevice() {
#ifdef RS_HAS_XNNPACK
    if (pthreadpool_) {
        pthreadpool_destroy(static_cast<pthreadpool*>(pthreadpool_));
    }
    if (xnnpack_available_) {
        xnn_deinitialize();
    }
#endif
}

DeviceInfo XNNPACKDevice::make_device_info(int index) {
    DeviceInfo info;
    info.device = Device{DeviceType::CPU, index};
    
    auto& ctx = dre::HardwareContextProvider::instance();
    if (ctx.is_initialized()) {
        info.name = ctx.cpu_info().brand + " (XNNPACK)";
        info.vendor = ctx.cpu_info().vendor;
        info.total_memory = ctx.total_ram();
        info.compute_units = ctx.num_cores();
    } else {
        info.name = "CPU (XNNPACK)";
        info.vendor = "Unknown";
        info.compute_units = std::thread::hardware_concurrency();
    }
    
    info.available_memory = info.total_memory;
    info.max_threads_per_block = info.compute_units;  // Treat cores as "threads per block"
    info.max_shared_memory = 32 * 1024;  // L1 cache as "shared memory"
    
    // XNNPACK capabilities
    info.capabilities = DeviceCapability::FP16;
    
    // NEON/SVE capabilities from CPU features
    if (ctx.is_initialized()) {
        if (ctx.has_neon()) info.capabilities = info.capabilities | DeviceCapability::INT8;
        if (ctx.has_sve())  info.capabilities = info.capabilities | DeviceCapability::FP16;
    }
    
    info.is_active = true;
    
    return info;
}

// ============================================================================
// Memory Management (delegates to standard allocator)
// ============================================================================

void* XNNPACKDevice::allocate(size_t size, AllocFlags flags) {
    void* ptr = std::aligned_alloc(64, size);
    if (ptr && has_flag(flags, AllocFlags::ZeroInit)) {
        std::memset(ptr, 0, size);
    }
    return ptr;
}

void XNNPACKDevice::deallocate(void* ptr) {
    std::free(ptr);
}

void XNNPACKDevice::memcpy(void* dst, const void* src, size_t size, int /*kind*/) {
    if (dst && src && size > 0) {
        std::memcpy(dst, src, size);
    }
}

void XNNPACKDevice::synchronize() {
    // CPU operations are synchronous
}

// ============================================================================
// Streams
// ============================================================================

void* XNNPACKDevice::create_stream() {
    return nullptr;  // No stream concept on CPU
}

void XNNPACKDevice::destroy_stream(void* /*stream*/) {}

void XNNPACKDevice::stream_synchronize(void* /*stream*/) {}

// ============================================================================
// XNNPACK-Specific Operations
// ============================================================================

void* XNNPACKDevice::create_runtime() {
#ifdef RS_HAS_XNNPACK
    if (!xnnpack_available_) return nullptr;
    xnn_runtime* runtime = nullptr;
    // Runtime is created from a subgraph — handled by AKD
    return runtime;
#else
    return nullptr;
#endif
}

void XNNPACKDevice::delete_runtime(void* runtime) {
#ifdef RS_HAS_XNNPACK
    if (runtime) {
        xnn_delete_runtime(static_cast<xnn_runtime*>(runtime));
    }
#endif
}

void XNNPACKDevice::set_num_threads(uint32_t n) {
    num_threads_ = n;
#ifdef RS_HAS_XNNPACK
    if (pthreadpool_) {
        pthreadpool_destroy(static_cast<pthreadpool*>(pthreadpool_));
        pthreadpool_ = pthreadpool_create(num_threads_);
    }
#endif
}

// ============================================================================
// Factory
// ============================================================================

std::unique_ptr<XNNPACKDevice> create_xnnpack_device(int index) {
    auto device = std::make_unique<XNNPACKDevice>(index);
    
    DeviceManager::instance().register_device(
        std::make_unique<XNNPACKDevice>(index)
    );
    
    RS_LOG_INFO("Created XNNPACKDevice[" + std::to_string(index) + "]: " + device->name());
    
    return device;
}

} // namespace xnnpack
} // namespace hal
} // namespace rootseed