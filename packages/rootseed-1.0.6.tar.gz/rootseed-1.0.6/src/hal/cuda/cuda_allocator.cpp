// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// cuda_allocator.cpp — CUDA Caching Memory Allocator (Section 11)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "hal/cuda/cuda_device.h"
#include "utils/log.h"

#include <unordered_map>
#include <mutex>
#include <queue>

namespace rootseed {
namespace hal {
namespace cuda {

// ============================================================================
// CachingAllocator — reduces cudaMalloc/cudaFree calls via a memory pool
//
// Caches freed allocations by size, reusing them for future requests.
// This reduces GPU memory fragmentation and allocation overhead.
// ============================================================================

class CachingAllocator {
public:
    static CachingAllocator& instance();

    void* allocate(size_t size);
    void deallocate(void* ptr);
    void release_unused();

private:
    CachingAllocator() = default;
    std::mutex mutex_;
    std::unordered_map<size_t, std::queue<void*>> free_blocks_;
    std::unordered_map<void*, size_t> active_blocks_;
};

CachingAllocator& CachingAllocator::instance() {
    static CachingAllocator s_instance;
    return s_instance;
}

void* CachingAllocator::allocate(size_t size) {
    std::lock_guard<std::mutex> lock(mutex_);

    // Check if we have a cached block of appropriate size
    auto it = free_blocks_.find(size);
    if (it != free_blocks_.end() && !it->second.empty()) {
        void* ptr = it->second.front();
        it->second.pop();
        active_blocks_[ptr] = size;
        return ptr;
    }

    // Allocate new block via CUDA
    void* ptr = nullptr;
    // cudaMalloc would be called here — using aligned_alloc as fallback
    ptr = std::aligned_alloc(256, size);  // 256-byte alignment for GPU
    if (ptr) {
        active_blocks_[ptr] = size;
    }
    return ptr;
}

void CachingAllocator::deallocate(void* ptr) {
    if (!ptr) return;

    std::lock_guard<std::mutex> lock(mutex_);
    auto it = active_blocks_.find(ptr);
    if (it != active_blocks_.end()) {
        free_blocks_[it->second].push(ptr);
        active_blocks_.erase(it);
    }
}

void CachingAllocator::release_unused() {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& [size, queue] : free_blocks_) {
        while (!queue.empty()) {
            std::free(queue.front());
            queue.pop();
        }
    }
    free_blocks_.clear();
}

} // namespace cuda
} // namespace hal
} // namespace rootseed