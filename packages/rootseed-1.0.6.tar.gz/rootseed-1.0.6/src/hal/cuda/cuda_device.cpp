// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// cuda_device.cpp — CUDA GPU Device Implementation (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "hal/cuda/cuda_device.h"
#include "utils/log.h"

#include <cstdlib>
#include <cstring>
#include <dlfcn.h>

namespace rootseed {
namespace hal {
namespace cuda {

// CUDA function pointers (loaded dynamically via dlopen)
struct CUDAAPI {
    cudaError_t (*malloc)(void**, size_t) = nullptr;
    void (*free)(void*) = nullptr;
    void (*memcpy)(void*, const void*, size_t, int) = nullptr;
    void (*stream_create)(void**) = nullptr;
    void (*stream_destroy)(void*) = nullptr;
    void (*stream_sync)(void*) = nullptr;
    void (*device_sync)() = nullptr;
    void (*mem_get_info)(size_t*, size_t*) = nullptr;
    bool loaded = false;
};

static CUDAAPI cuda;

static void load_cuda() {
    if (cuda.loaded) return;

    void* lib = dlopen("libcudart.so", RTLD_LAZY);
    if (!lib) {
        RS_LOG_DEBUG("CUDA not available: libcudart.so not found");
        return;
    }

    cuda.malloc       = (decltype(cuda.malloc))       dlsym(lib, "cudaMalloc");
    cuda.free         = (decltype(cuda.free))         dlsym(lib, "cudaFree");
    cuda.memcpy       = (decltype(cuda.memcpy))       dlsym(lib, "cudaMemcpy");
    cuda.stream_create= (decltype(cuda.stream_create))dlsym(lib, "cudaStreamCreate");
    cuda.stream_destroy=(decltype(cuda.stream_destroy))dlsym(lib, "cudaStreamDestroy");
    cuda.stream_sync  = (decltype(cuda.stream_sync))  dlsym(lib, "cudaStreamSynchronize");
    cuda.device_sync  = (decltype(cuda.device_sync))  dlsym(lib, "cudaDeviceSynchronize");
    cuda.mem_get_info = (decltype(cuda.mem_get_info)) dlsym(lib, "cudaMemGetInfo");

    cuda.loaded = (cuda.malloc && cuda.free && cuda.memcpy);
}

CUDADevice::CUDADevice(int device_index)
    : AbstractDevice(make_device_info(device_index))
    , device_index_(device_index) {

    load_cuda();
    cuda_available_ = cuda.loaded;

    if (cuda_available_) {
        RS_LOG_INFO("CUDADevice[" + std::to_string(device_index) + "]: CUDA available");
    } else {
        RS_LOG_INFO("CUDADevice: CUDA not available — falling back to CPU");
    }
}

DeviceInfo CUDADevice::make_device_info(int index) {
    DeviceInfo info;
    info.device = Device{DeviceType::CUDA, index};
    info.name = "NVIDIA CUDA GPU";
    info.vendor = "NVIDIA";
    info.capabilities = DeviceCapability::TensorCores | DeviceCapability::FP16 |
                        DeviceCapability::BF16 | DeviceCapability::FP8 |
                        DeviceCapability::SparseMM | DeviceCapability::PinnedMemory;
    return info;
}

CUDADevice::~CUDADevice() {
    for (auto* stream : streams_) {
        if (cuda.stream_destroy) cuda.stream_destroy(stream);
    }
}

void* CUDADevice::allocate(size_t size, AllocFlags /*flags*/) {
    if (!cuda_available_) return std::aligned_alloc(64, size);

    void* ptr = nullptr;
    if (cuda.malloc) cuda.malloc(&ptr, size);
    return ptr;
}

void CUDADevice::deallocate(void* ptr) {
    if (!ptr) return;
    if (cuda_available_ && cuda.free) {
        cuda.free(ptr);
    } else {
        std::free(ptr);
    }
}

void CUDADevice::memcpy(void* dst, const void* src, size_t size, int kind) {
    if (cuda_available_ && cuda.memcpy) {
        cuda.memcpy(dst, src, size, kind);
    } else {
        std::memcpy(dst, src, size);
    }
}

void CUDADevice::synchronize() {
    if (cuda_available_ && cuda.device_sync) cuda.device_sync();
}

void* CUDADevice::create_stream() {
    if (!cuda_available_) return nullptr;
    void* stream = nullptr;
    if (cuda.stream_create) cuda.stream_create(&stream);
    if (stream) streams_.push_back(stream);
    return stream;
}

void CUDADevice::destroy_stream(void* stream) {
    if (cuda_available_ && cuda.stream_destroy) cuda.stream_destroy(stream);
}

void CUDADevice::stream_synchronize(void* stream) {
    if (cuda_available_ && cuda.stream_sync) cuda.stream_sync(stream);
}

size_t CUDADevice::total_memory() const {
    if (cuda_available_ && cuda.mem_get_info) {
        size_t free_mem, total_mem;
        cuda.mem_get_info(&free_mem, &total_mem);
        return total_mem;
    }
    return info_.total_memory;
}

size_t CUDADevice::available_memory() const {
    if (cuda_available_ && cuda.mem_get_info) {
        size_t free_mem, total_mem;
        cuda.mem_get_info(&free_mem, &total_mem);
        return free_mem;
    }
    return info_.available_memory;
}

} // namespace cuda
} // namespace hal
} // namespace rootseed