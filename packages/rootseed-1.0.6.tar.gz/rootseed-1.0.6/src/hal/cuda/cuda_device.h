// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// cuda_device.h — NVIDIA CUDA GPU Device Backend (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "hal/device.h"

namespace rootseed {
namespace hal {
namespace cuda {

// ============================================================================
// CUDADevice — NVIDIA GPU backend via CUDA
//
// Provides:
//   - cudaMalloc / cudaFree for GPU memory
//   - cudaMemcpy for CPU↔GPU transfers
//   - CUDA streams for asynchronous execution
//   - Tensor Core acceleration (Tier 5 in AKD)
// ============================================================================

class CUDADevice : public AbstractDevice {
public:
    explicit CUDADevice(int device_index = 0);
    ~CUDADevice() override;

    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    void memcpy(void* dst, const void* src, size_t size, int kind = 0) override;
    void synchronize() override;

    void* create_stream() override;
    void destroy_stream(void* stream) override;
    void stream_synchronize(void* stream) override;

    size_t total_memory() const override;
    size_t available_memory() const override;
    uint32_t max_threads_per_block() const override { return 1024; }
    size_t max_shared_memory() const override { return 48 * 1024; }

    bool is_available() const noexcept { return cuda_available_; }

private:
    static DeviceInfo make_device_info(int index);
    bool cuda_available_ = false;
    int device_index_;
    // Opaque handles to CUDA objects (cudaStream_t, etc.)
    std::vector<void*> streams_;
};

} // namespace cuda
} // namespace hal
} // namespace rootseed