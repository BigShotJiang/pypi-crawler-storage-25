// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// expert_parallel.h — Expert Parallelism for MoE: Distribute Experts Across Ranks (Section 13)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/moe/moe_layer.h"
#include "distributed/collective_ops.h"

#include <memory>
#include <vector>

namespace rootseed {
namespace distributed {

// ============================================================================
// ExpertParallel — distributes MoE experts across multiple ranks
//
// Each rank owns a subset of experts.
// Tokens are routed to the appropriate rank for expert computation.
// Router runs on all ranks (identical gating).
// Expert outputs are all-to-all communicated back.
// ============================================================================

class ExpertParallel {
public:
    /// Create expert-parallel wrapper for a MoE layer.
    /// @param moe_layer      The local MoE layer (with subset of experts)
    /// @param collective_ops  Communication handler
    /// @param expert_start   First expert index owned by this rank
    /// @param expert_end     One past the last expert index owned by this rank
    ExpertParallel(std::shared_ptr<nn::moe::MoELayer> moe_layer,
                   std::shared_ptr<CollectiveOps> collective_ops,
                   int expert_start, int expert_end);

    /// Forward pass with cross-rank token routing.
    core::Tensor forward(const core::Tensor& input);

    /// Returns the number of experts owned by this rank.
    int num_local_experts() const noexcept { return expert_end_ - expert_start_; }

private:
    std::shared_ptr<nn::moe::MoELayer> moe_layer_;
    std::shared_ptr<CollectiveOps> comm_;
    int expert_start_;
    int expert_end_;
    int total_experts_;
};

} // namespace distributed
} // namespace rootseed