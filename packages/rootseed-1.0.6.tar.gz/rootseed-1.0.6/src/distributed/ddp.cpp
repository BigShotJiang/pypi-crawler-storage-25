// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// ddp.cpp — DistributedDataParallel Implementation (Section 13)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "distributed/ddp.h"
#include "utils/log.h"

#include <algorithm>

namespace rootseed {
namespace distributed {

DistributedDataParallel::DistributedDataParallel(
    std::shared_ptr<nn::Module> model,
    std::shared_ptr<CollectiveOps> collective_ops,
    size_t bucket_size)
    : model_(std::move(model))
    , comm_(std::move(collective_ops))
    , bucket_size_(bucket_size) {

    set_name("DDP(" + model_->name() + ")");
    RS_LOG_INFO("DDP created: " + std::to_string(comm_->process_group()->world_size()) + " ranks");
}

core::Tensor DistributedDataParallel::forward(const core::Tensor& input) {
    // Forward pass runs independently on each rank
    return model_->forward(input);
}

void DistributedDataParallel::sync_gradients() {
    auto params = model_->parameters();
    if (params.empty()) return;

    int world_size = comm_->process_group()->world_size();
    if (world_size <= 1) return;

    // All-reduce gradients in buckets
    std::vector<float> gradient_buffer;
    size_t current_bucket = 0;

    for (auto& p : params) {
        auto& grad = p->grad();
        if (grad.numel() == 0) continue;

        int64_t n = grad.numel();

        // Average gradients: divide by world_size after all-reduce
        for (int64_t i = 0; i < n; ++i) {
            grad.set_item(i, grad.item(i) / static_cast<float>(world_size));
        }

        // All-reduce this parameter's gradient
        // (In production, bucketed together for efficiency)
        float* data = static_cast<float*>(grad.data_ptr());
        comm_->process_group()->all_reduce(data, n, ReduceOp::SUM);

        current_bucket++;
    }

    RS_LOG_DEBUG("DDP sync: " + std::to_string(current_bucket) + " parameters synchronized");
}

void DistributedDataParallel::sync_parameters() {
    auto params = model_->parameters();
    int rank = comm_->process_group()->rank();

    for (auto& p : params) {
        auto& data = p->data();
        if (data.numel() == 0) continue;

        // Broadcast parameters from rank 0
        float* d = static_cast<float*>(data.data_ptr());
        comm_->process_group()->broadcast(d, data.numel(), 0);
    }

    RS_LOG_DEBUG("DDP: parameters broadcast from rank 0");
}

} // namespace distributed
} // namespace rootseed