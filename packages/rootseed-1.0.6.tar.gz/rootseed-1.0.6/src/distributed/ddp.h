// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// ddp.h — DistributedDataParallel: Gradient Bucketing and Sync (Section 13)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "distributed/collective_ops.h"

#include <memory>
#include <vector>

namespace rootseed {
namespace distributed {

// ============================================================================
// DistributedDataParallel — wraps a model for multi-GPU training
//
// - Each rank has a copy of the model
// - Forward pass runs independently on each rank
// - Backward pass computes gradients locally
// - Gradients are all-reduced across ranks after backward
// - Parameters stay synchronized via gradient averaging
// ============================================================================

class DistributedDataParallel : public nn::Module {
public:
    /// Wrap a model for distributed training.
    /// @param model         The local model replica
    /// @param collective_ops  Communication handler
    /// @param bucket_size   Max number of parameters per gradient bucket
    DistributedDataParallel(std::shared_ptr<nn::Module> model,
                            std::shared_ptr<CollectiveOps> collective_ops,
                            size_t bucket_size = 256);

    core::Tensor forward(const core::Tensor& input) override;

    /// Synchronize gradients across all ranks.
    void sync_gradients();

    /// Synchronize parameters (broadcast from rank 0).
    void sync_parameters();

    /// Access the underlying model.
    std::shared_ptr<nn::Module> model() { return model_; }

private:
    std::shared_ptr<nn::Module> model_;
    std::shared_ptr<CollectiveOps> comm_;
    size_t bucket_size_;
};

} // namespace distributed
} // namespace rootseed