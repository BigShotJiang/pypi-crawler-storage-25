// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// collective_ops.cpp — Tensor Collective Operation Implementations (Section 13)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "distributed/collective_ops.h"

#include <cstring>

namespace rootseed {
namespace distributed {

CollectiveOps::CollectiveOps(std::shared_ptr<ProcessGroup> pg)
    : pg_(std::move(pg)) {}

void CollectiveOps::all_reduce(core::Tensor& tensor, ReduceOp op) {
    if (!tensor.data_ptr() || tensor.numel() == 0) return;

    float* data = static_cast<float*>(tensor.data_ptr());
    pg_->all_reduce(data, tensor.numel(), op);
}

void CollectiveOps::broadcast(core::Tensor& tensor, int src) {
    if (!tensor.data_ptr() || tensor.numel() == 0) return;

    float* data = static_cast<float*>(tensor.data_ptr());
    pg_->broadcast(data, tensor.numel(), src);
}

std::vector<core::Tensor> CollectiveOps::all_gather(const core::Tensor& tensor) {
    std::vector<float> output;
    const float* input = static_cast<const float*>(tensor.data_ptr());
    pg_->all_gather(output, input, tensor.numel());

    // Reconstruct tensors from gathered data
    std::vector<core::Tensor> result;
    size_t per_rank = tensor.numel();
    for (int r = 0; r < pg_->world_size(); ++r) {
        core::Tensor t = core::Tensor::zeros(tensor.shape(), tensor.dtype(), tensor.device());
        std::memcpy(t.data_ptr(), output.data() + r * per_rank, per_rank * sizeof(float));
        result.push_back(t);
    }
    return result;
}

core::Tensor CollectiveOps::reduce_scatter(const core::Tensor& tensor,
                                             const std::vector<size_t>& recv_counts) {
    core::Tensor result = core::Tensor::zeros(tensor.shape(), tensor.dtype(), tensor.device());

    const float* input = static_cast<const float*>(tensor.data_ptr());
    float* output = static_cast<float*>(result.data_ptr());

    pg_->reduce_scatter(output, input, recv_counts.data(), tensor.numel());
    return result;
}

void CollectiveOps::barrier() {
    pg_->barrier();
}

} // namespace distributed
} // namespace rootseed