// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// collective_ops.h — High-Level Collective Operations (Section 13)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "distributed/process_group.h"
#include "core/tensor.h"

#include <memory>

namespace rootseed {
namespace distributed {

// ============================================================================
// CollectiveOps — convenience wrappers around ProcessGroup for tensors
// ============================================================================

class CollectiveOps {
public:
    explicit CollectiveOps(std::shared_ptr<ProcessGroup> pg);

    /// All-reduce a tensor in-place.
    void all_reduce(core::Tensor& tensor, ReduceOp op = ReduceOp::SUM);

    /// Broadcast a tensor from src rank.
    void broadcast(core::Tensor& tensor, int src = 0);

    /// All-gather tensors from all ranks.
    std::vector<core::Tensor> all_gather(const core::Tensor& tensor);

    /// Reduce-scatter across ranks.
    core::Tensor reduce_scatter(const core::Tensor& tensor, const std::vector<size_t>& recv_counts);

    /// Barrier synchronization.
    void barrier();

    const std::shared_ptr<ProcessGroup>& process_group() const noexcept { return pg_; }

private:
    std::shared_ptr<ProcessGroup> pg_;
};

} // namespace distributed
} // namespace rootseed