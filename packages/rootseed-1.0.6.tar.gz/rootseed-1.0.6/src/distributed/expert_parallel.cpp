// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// expert_parallel.cpp — Expert Parallelism: Cross-Rank Token Routing (Section 13)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "distributed/expert_parallel.h"
#include "utils/log.h"

#include <algorithm>

namespace rootseed {
namespace distributed {

ExpertParallel::ExpertParallel(
    std::shared_ptr<nn::moe::MoELayer> moe_layer,
    std::shared_ptr<CollectiveOps> collective_ops,
    int expert_start, int expert_end)
    : moe_layer_(std::move(moe_layer))
    , comm_(std::move(collective_ops))
    , expert_start_(expert_start)
    , expert_end_(expert_end)
    , total_experts_(moe_layer_->num_experts()) {

    RS_LOG_INFO("ExpertParallel: rank " + std::to_string(comm_->process_group()->rank()) +
                " owns experts [" + std::to_string(expert_start_) + "-" +
                std::to_string(expert_end_ - 1) + "] of " + std::to_string(total_experts_));
}

core::Tensor ExpertParallel::forward(const core::Tensor& input) {
    // In expert-parallel mode:
    // 1. Router runs locally on all ranks (identical gating)
    // 2. Tokens are dispatched to ranks owning the assigned experts
    //    (all-to-all communication)
    // 3. Each rank computes its local experts
    // 4. Results are all-to-all communicated back
    // 5. Combine happens with full expert outputs

    // Simplified: delegate to local MoE layer (works when all experts are local)
    // Full cross-rank token dispatch requires all-to-all collectives (future work)

    return moe_layer_->forward(input);
}

} // namespace distributed
} // namespace rootseed