// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// process_group.h — Distributed Process Group Abstraction (Section 13)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <string>
#include <memory>
#include <vector>

namespace rootseed {
namespace distributed {

// ============================================================================
// ReduceOp — reduction operations for collective communication
// ============================================================================

enum class ReduceOp : uint8_t {
    SUM = 0,
    PROD = 1,
    MAX = 2,
    MIN = 3,
};

// ============================================================================
// ProcessGroup — abstract interface for distributed communication
//
// Backends:
//   NCCL  — NVIDIA GPUs
//   RCCL  — AMD GPUs
//   CPU   — CPU-only (using threads or MPI-like messaging)
// ============================================================================

class ProcessGroup {
public:
    enum class Backend { NCCL, RCCL, CPU };

    virtual ~ProcessGroup() = default;

    /// Initialize the process group.
    /// @param backend     Communication backend
    /// @param world_size  Total number of processes
    /// @param rank        This process's rank (0-based)
    /// @param init_method Connection string (e.g., "tcp://host:port" or "env://")
    static std::shared_ptr<ProcessGroup> create(
        Backend backend, int world_size, int rank,
        const std::string& init_method = "env://");

    // ---- Core collectives ----

    /// Sum gradients across all ranks. Result is written to tensor.
    virtual void all_reduce(float* data, size_t count, ReduceOp op = ReduceOp::SUM) = 0;

    /// Broadcast tensor from src rank to all others.
    virtual void broadcast(float* data, size_t count, int src) = 0;

    /// Gather tensors from all ranks into output.
    virtual void all_gather(std::vector<float>& output, const float* input, size_t count) = 0;

    /// Reduce and scatter across ranks.
    virtual void reduce_scatter(float* output, const float* input,
                                 const size_t* recv_counts, size_t count) = 0;

    /// Point-to-point send.
    virtual void send(const float* data, size_t count, int dst) = 0;

    /// Point-to-point receive.
    virtual void recv(float* data, size_t count, int src) = 0;

    /// Synchronize all ranks (barrier).
    virtual void barrier() = 0;

    // ---- Info ----
    int rank()       const noexcept { return rank_; }
    int world_size() const noexcept { return world_size_; }
    Backend backend() const noexcept { return backend_; }

protected:
    ProcessGroup(Backend backend, int world_size, int rank)
        : backend_(backend), world_size_(world_size), rank_(rank) {}

    Backend backend_;
    int world_size_;
    int rank_;
};

} // namespace distributed
} // namespace rootseed