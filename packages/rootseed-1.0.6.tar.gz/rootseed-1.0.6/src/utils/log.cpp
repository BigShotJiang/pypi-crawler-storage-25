// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// log.cpp — Logger Singleton Implementation with spdlog Backend (Section 5)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "log.h"

// spdlog is bundled in third_party/spdlog
#include <spdlog/spdlog.h>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/sinks/rotating_file_sink.h>
#include <spdlog/async.h>
#include <spdlog/async_logger.h>

#include <filesystem>
#include <stdexcept>
#include <iostream>

namespace rootseed {
namespace utils {

Logger& Logger::instance() {
    static Logger s_instance;
    return s_instance;
}

void Logger::init(std::string_view name, std::string_view log_dir, bool async_mode) {
    if (initialized_) {
        return;  // Already initialized — idempotent
    }

    // Ensure log directory exists
    std::filesystem::create_directories(log_dir);

    // Build log file path: <log_dir>/<name>.log
    std::string log_file = std::string(log_dir) + "/" + std::string(name) + ".log";

    // Console sink: colorized output to stdout
    auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
    console_sink->set_level(spdlog::level::info);

    // Rotating file sink: max 10MB per file, keep 3 rotated files
    auto file_sink = std::make_shared<spdlog::sinks::rotating_file_sink_mt>(
        log_file, 10 * 1024 * 1024, 3);
    file_sink->set_level(spdlog::level::trace);  // File captures everything

    std::vector<spdlog::sink_ptr> sinks = {console_sink, file_sink};

    if (async_mode) {
        // Async logger: non-blocking — critical for training loop performance
        spdlog::init_thread_pool(8192, 1);  // 8K queue, 1 background thread
        logger_ = std::make_shared<spdlog::async_logger>(
            std::string(name), sinks.begin(), sinks.end(),
            spdlog::thread_pool(),
            spdlog::async_overflow_policy::block);
    } else {
        logger_ = std::make_shared<spdlog::logger>(
            std::string(name), sinks.begin(), sinks.end());
    }

    logger_->set_level(spdlog::level::info);
    spdlog::register_logger(logger_);
    logger_->flush_on(spdlog::level::err);  // Auto-flush on error

    initialized_ = true;

    logger_->info("Root-Seed logging initialized. Log file: {}", log_file);
}

Logger::~Logger() {
    if (logger_) {
        logger_->flush();
    }
}

void Logger::flush() {
    if (logger_) {
        logger_->flush();
    }
}

void Logger::info(std::string_view msg) {
    if (logger_) logger_->info(msg);
}

void Logger::warn(std::string_view msg) {
    if (logger_) logger_->warn(msg);
}

void Logger::error(std::string_view msg) {
    if (logger_) logger_->error(msg);
}

void Logger::debug(std::string_view msg) {
    if (logger_) logger_->debug(msg);
}

void Logger::trace(std::string_view msg) {
    if (logger_) logger_->trace(msg);
}

void Logger::set_level(int level) {
    if (logger_) {
        logger_->set_level(static_cast<spdlog::level::level_enum>(level));
    }
}

} // namespace utils
} // namespace rootseed