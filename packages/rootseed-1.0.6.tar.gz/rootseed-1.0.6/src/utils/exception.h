// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// exception.h — Structured Exception System with Error Codes (Section 5)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <cstdint>
#include <string>
#include <string_view>
#include <stdexcept>
#include <source_location>
#include <sstream>

namespace rootseed {
namespace utils {

// ============================================================================
// ErrorCode — Covers all failure domains in Root-Seed
// ============================================================================

enum class ErrorCode : std::uint32_t {
    // General
    Ok = 0,

    // Tensor errors (Section 6)
    TensorShapeMismatch = 1001,
    TensorDTypeMismatch = 1002,
    TensorOutOfMemory = 1003,
    TensorIndexOutOfBounds = 1004,
    TensorBroadcastError = 1005,
    TensorNotContiguous = 1006,

    // Sparse tensor errors (Section 2)
    SparseFormatError = 1101,
    SparseConversionError = 1102,
    SparseDimensionMismatch = 1103,

    // Autograd errors (Section 6.3)
    AutogradGraphError = 2001,
    AutogradBackwardError = 2002,
    AutogradDoubleBackward = 2003,
    AutogradLeafVariable = 2004,

    // Hardware errors (Section 3, 10, 15)
    HardwareDetectionFailed = 3001,
    HardwareUnsupported = 3002,
    HardwareBackendLoadFailed = 3003,
    HardwareCUDAError = 3004,
    HardwareROCmError = 3005,
    HardwareVulkanError = 3006,
    HardwareTPUError = 3007,
    HardwareNPUError = 3008,

    // Random errors — Aleam exclusive (Section 8)
    RandomEntropyUnavailable = 4001,
    RandomGenerationFailed = 4002,

    // I/O and serialization errors (Section 9, 12)
    IOFileNotFound = 5001,
    IOFormatError = 5002,
    IOSerializationError = 5003,
    IODeserializationError = 5004,
    IOCryptographicError = 5005,

    // Distributed errors (Section 13)
    DistributedInitError = 6001,
    DistributedCommunicationError = 6002,
    DistributedRankMismatch = 6003,

    // Internal / assertion errors
    InternalError = 9999,
};

/// Returns a human-readable name for an ErrorCode.
std::string_view error_code_name(ErrorCode code);

// ============================================================================
// Exception — base exception class for all Root-Seed errors
// ============================================================================

class Exception : public std::runtime_error {
public:
    Exception(ErrorCode code,
              std::string_view message,
              std::source_location loc = std::source_location::current())
        : std::runtime_error(format_message(code, message, loc))
        , code_(code)
        , location_(loc)
    {}

    ErrorCode code() const noexcept { return code_; }
    const std::source_location& location() const noexcept { return location_; }

    /// Returns the error code as a string.
    std::string_view code_name() const { return error_code_name(code_); }

private:
    static std::string format_message(ErrorCode code,
                                       std::string_view message,
                                       const std::source_location& loc) {
        std::ostringstream oss;
        oss << "[" << error_code_name(code) << "] "
            << message
            << " (" << loc.file_name() << ":" << loc.line() << ")"
            << " [" << loc.function_name() << "]";
        return oss.str();
    }

    ErrorCode code_;
    std::source_location location_;
};

// ============================================================================
// Convenience macros for throwing exceptions with source location
// ============================================================================

#define RS_THROW(code, msg) \
    throw ::rootseed::utils::Exception((code), (msg))

#define RS_THROW_IF(cond, code, msg) \
    do { if (cond) { RS_THROW((code), (msg)); } } while(0)

} // namespace utils
} // namespace rootseed