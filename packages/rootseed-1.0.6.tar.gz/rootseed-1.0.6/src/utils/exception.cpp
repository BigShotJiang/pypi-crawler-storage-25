// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// exception.cpp — Error Code Names and Exception Implementation (Section 5)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "exception.h"

namespace rootseed {
namespace utils {

std::string_view error_code_name(ErrorCode code) {
    switch (code) {
        case ErrorCode::Ok:
            return "Ok";

        // Tensor
        case ErrorCode::TensorShapeMismatch:    return "TensorShapeMismatch";
        case ErrorCode::TensorDTypeMismatch:    return "TensorDTypeMismatch";
        case ErrorCode::TensorOutOfMemory:      return "TensorOutOfMemory";
        case ErrorCode::TensorIndexOutOfBounds: return "TensorIndexOutOfBounds";
        case ErrorCode::TensorBroadcastError:   return "TensorBroadcastError";
        case ErrorCode::TensorNotContiguous:    return "TensorNotContiguous";

        // Sparse
        case ErrorCode::SparseFormatError:       return "SparseFormatError";
        case ErrorCode::SparseConversionError:   return "SparseConversionError";
        case ErrorCode::SparseDimensionMismatch: return "SparseDimensionMismatch";

        // Autograd
        case ErrorCode::AutogradGraphError:     return "AutogradGraphError";
        case ErrorCode::AutogradBackwardError:   return "AutogradBackwardError";
        case ErrorCode::AutogradDoubleBackward:  return "AutogradDoubleBackward";
        case ErrorCode::AutogradLeafVariable:    return "AutogradLeafVariable";

        // Hardware
        case ErrorCode::HardwareDetectionFailed:    return "HardwareDetectionFailed";
        case ErrorCode::HardwareUnsupported:        return "HardwareUnsupported";
        case ErrorCode::HardwareBackendLoadFailed:  return "HardwareBackendLoadFailed";
        case ErrorCode::HardwareCUDAError:          return "HardwareCUDAError";
        case ErrorCode::HardwareROCmError:          return "HardwareROCmError";
        case ErrorCode::HardwareVulkanError:        return "HardwareVulkanError";
        case ErrorCode::HardwareTPUError:           return "HardwareTPUError";
        case ErrorCode::HardwareNPUError:           return "HardwareNPUError";

        // Random
        case ErrorCode::RandomEntropyUnavailable: return "RandomEntropyUnavailable";
        case ErrorCode::RandomGenerationFailed:    return "RandomGenerationFailed";

        // I/O
        case ErrorCode::IOFileNotFound:          return "IOFileNotFound";
        case ErrorCode::IOFormatError:           return "IOFormatError";
        case ErrorCode::IOSerializationError:    return "IOSerializationError";
        case ErrorCode::IODeserializationError:  return "IODeserializationError";
        case ErrorCode::IOCryptographicError:    return "IOCryptographicError";

        // Distributed
        case ErrorCode::DistributedInitError:            return "DistributedInitError";
        case ErrorCode::DistributedCommunicationError:   return "DistributedCommunicationError";
        case ErrorCode::DistributedRankMismatch:         return "DistributedRankMismatch";

        // Internal
        case ErrorCode::InternalError: return "InternalError";
    }

    return "UnknownError";
}

} // namespace utils
} // namespace rootseed