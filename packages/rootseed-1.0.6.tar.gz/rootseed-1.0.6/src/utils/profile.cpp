// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// profile.cpp — Profiler Singleton and JSON Export with Hardware Counters
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "profile.h"

#include <sstream>
#include <iomanip>
#include <thread>
#include <fstream>
#include <iostream>

// Linux perf_event for hardware counter access (optional)
#if defined(__linux__) && defined(RS_USE_PERF)
#include <linux/perf_event.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
#include <unistd.h>
#endif

namespace rootseed {
namespace utils {

// ============================================================================
// Profiler singleton
// ============================================================================

Profiler& Profiler::instance() {
    static Profiler s_instance;
    return s_instance;
}

void Profiler::record(ProfileRecord&& rec) {
    std::lock_guard<std::mutex> lock(mutex_);
    records_.emplace_back(std::move(rec));
}

void Profiler::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    records_.clear();
}

size_t Profiler::count() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return records_.size();
}

std::string Profiler::to_json() const {
    std::lock_guard<std::mutex> lock(mutex_);

    std::ostringstream oss;
    oss << "{\n";
    oss << "  \"profiler\": \"Root-Seed\",\n";
    oss << "  \"total_records\": " << records_.size() << ",\n";
    oss << "  \"records\": [\n";

    for (size_t i = 0; i < records_.size(); ++i) {
        const auto& r = records_[i];
        oss << "    {\n";
        oss << "      \"name\": \"" << r.name << "\",\n";
        oss << "      \"file\": \"" << r.file << "\",\n";
        oss << "      \"line\": " << r.line << ",\n";
        oss << "      \"elapsed_ms\": " << std::fixed << std::setprecision(6) << r.elapsed_ms << ",\n";
        oss << "      \"thread_id\": " << r.thread_id << "\n";
        oss << "    }";
        if (i < records_.size() - 1) oss << ",";
        oss << "\n";
    }

    oss << "  ]\n";
    oss << "}\n";
    return oss.str();
}

// ============================================================================
// Profiler JSON export utility
// ============================================================================

// Export profiler data to a JSON file.
// Can be called at program exit or periodically during training.
void export_profile(const std::string& filepath) {
    std::ofstream file(filepath);
    if (file.is_open()) {
        file << Profiler::instance().to_json();
        file.close();
    }
}

} // namespace utils
} // namespace rootseed