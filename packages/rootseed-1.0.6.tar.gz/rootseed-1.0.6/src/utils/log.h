// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// log.h — Asynchronous Logging System via spdlog (Section 5, Layer 7)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <memory>
#include <string>
#include <string_view>

// Forward declare spdlog types to keep header lightweight
namespace spdlog {
class logger;
namespace level {
enum level_enum : int;
}
}

namespace rootseed {
namespace utils {

// ============================================================================
// Logger: thread-safe singleton wrapping spdlog
// Provides console output + rotating file sink + async flush on error
// ============================================================================

class Logger {
public:
    /// Returns the global Logger singleton, initialized on first call.
    static Logger& instance();

    /// Initialize the logger system.
    /// Must be called once before any logging output.
    /// @param name        Logger name (shown in output)
    /// @param log_dir     Directory for rotating log files
    /// @param async_mode  If true, use spdlog async factory (non-blocking)
    void init(std::string_view name = "rootseed",
              std::string_view log_dir = "logs",
              bool async_mode = true);

    /// Flush all pending log messages (called automatically on error/crash).
    void flush();

    // ---- Convenience methods ----
    void info(std::string_view msg);
    void warn(std::string_view msg);
    void error(std::string_view msg);
    void debug(std::string_view msg);
    void trace(std::string_view msg);

    /// Sets the minimum log level globally.
    void set_level(int level);

    /// Returns true if the logger has been initialized.
    bool is_initialized() const noexcept { return initialized_; }

private:
    Logger() = default;
    ~Logger();

    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    std::shared_ptr<spdlog::logger> logger_;
    bool initialized_ = false;
};

// ============================================================================
// Convenience macros — zero-cost when log level is disabled
// ============================================================================

// Info: general operational messages
#define RS_LOG_INFO(msg) \
    do { if (::rootseed::utils::Logger::instance().is_initialized()) \
         ::rootseed::utils::Logger::instance().info(msg); } while(0)

// Warning: non-critical issues
#define RS_LOG_WARN(msg) \
    do { if (::rootseed::utils::Logger::instance().is_initialized()) \
         ::rootseed::utils::Logger::instance().warn(msg); } while(0)

// Error: critical failures — auto-flushes
#define RS_LOG_ERROR(msg) \
    do { \
        ::rootseed::utils::Logger::instance().error(msg); \
        ::rootseed::utils::Logger::instance().flush(); \
    } while(0)

// Debug: detailed diagnostic info (disabled in release builds)
#ifdef RS_DEBUG
#define RS_LOG_DEBUG(msg) \
    do { if (::rootseed::utils::Logger::instance().is_initialized()) \
         ::rootseed::utils::Logger::instance().debug(msg); } while(0)
#else
#define RS_LOG_DEBUG(msg) ((void)0)
#endif

// Trace: very fine-grained tracing
#ifdef RS_TRACE
#define RS_LOG_TRACE(msg) \
    do { if (::rootseed::utils::Logger::instance().is_initialized()) \
         ::rootseed::utils::Logger::instance().trace(msg); } while(0)
#else
#define RS_LOG_TRACE(msg) ((void)0)
#endif

} // namespace utils
} // namespace rootseed