// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// profile.h — Performance Profiling with RAII Scopes and Hardware Counters
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <chrono>
#include <string>
#include <string_view>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <memory>
#include <source_location>

namespace rootseed {
namespace utils {

// ============================================================================
// Timer — high-resolution wall-clock timer
// ============================================================================

class Timer {
public:
    using Clock = std::chrono::high_resolution_clock;
    using TimePoint = Clock::time_point;
    using Duration = Clock::duration;

    Timer() : start_(Clock::now()) {}

    /// Reset the timer to the current time.
    void reset() { start_ = Clock::now(); }

    /// Returns elapsed time in seconds since construction or last reset.
    double elapsed_seconds() const {
        auto dur = Clock::now() - start_;
        return std::chrono::duration<double>(dur).count();
    }

    /// Returns elapsed time in milliseconds.
    double elapsed_ms() const { return elapsed_seconds() * 1000.0; }

    /// Returns elapsed time in microseconds.
    double elapsed_us() const { return elapsed_seconds() * 1e6; }

private:
    TimePoint start_;
};

// ============================================================================
// ProfileRecord — a single timed event
// ============================================================================

struct ProfileRecord {
    std::string name;
    std::string file;
    int line;
    double elapsed_ms;
    uint64_t thread_id;
};

// ============================================================================
// Profiler — singleton collecting timed scopes
// ============================================================================

class Profiler {
public:
    static Profiler& instance();

    /// Record a completed scope.
    void record(ProfileRecord&& rec);

    /// Export all recorded data as a JSON string.
    std::string to_json() const;

    /// Clear all recorded data.
    void clear();

    /// Number of recorded scopes.
    size_t count() const;

private:
    Profiler() = default;
    mutable std::mutex mutex_;
    std::vector<ProfileRecord> records_;
};

// ============================================================================
// ProfileScope — RAII scope that records elapsed time in Profiler
// ============================================================================

class ProfileScope {
public:
    explicit ProfileScope(std::string_view name,
                          std::source_location loc = std::source_location::current())
        : name_(name)
        , file_(loc.file_name())
        , line_(loc.line())
        , timer_()
    {}

    ~ProfileScope() {
        Profiler::instance().record({
            name_,
            file_,
            line_,
            timer_.elapsed_ms(),
            /*thread_id=*/0  // TODO: std::hash<std::thread::id>{}(std::this_thread::get_id())
        });
    }

    ProfileScope(const ProfileScope&) = delete;
    ProfileScope& operator=(const ProfileScope&) = delete;

private:
    std::string name_;
    std::string file_;
    int line_;
    Timer timer_;
};

// ============================================================================
// Convenience macro — names the scope using the current function name
// ============================================================================

#define RS_PROFILE_SCOPE() \
    ::rootseed::utils::ProfileScope _rs_profile_scope(__func__)

#define RS_PROFILE_SCOPE_NAMED(name) \
    ::rootseed::utils::ProfileScope _rs_profile_scope(name)

} // namespace utils
} // namespace rootseed