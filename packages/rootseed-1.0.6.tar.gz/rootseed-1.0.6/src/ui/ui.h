// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// ui.h — Rich Terminal UI Dashboard: Auto-Scaling to Any Number of Devices
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <string>
#include <vector>
#include <chrono>
#include <mutex>
#include <memory>
#include <unordered_map>

namespace rootseed {
namespace ui {

// ============================================================================
// DeviceMetrics — per-device stats, auto-populated from DeviceManager
// ============================================================================

struct DeviceMetrics {
    std::string name;             // "NVIDIA H100", "Google TPU v5", "Qualcomm NPU"
    std::string type;             // "CUDA", "ROCm", "Vulkan", "TPU", "NPU", "CPU"
    int index = 0;                // Device index within its type
    size_t memory_used_mb = 0;    // Currently allocated
    size_t memory_total_mb = 0;   // Total available
    float utilization_pct = 0.0f; // 0-100 (where available)
    bool is_active = true;        // Currently in use
};

// ============================================================================
// TrainingMetrics — complete snapshot of training progress
// ============================================================================

struct TrainingMetrics {
    int epoch = 0;
    int step = 0;
    int total_steps = 0;
    float loss = 0.0f;
    float accuracy = 0.0f;
    float lr = 0.0f;
    double elapsed_seconds = 0.0;
    double samples_per_second = 0.0;
    int world_size = 1;                              // Distributed: total ranks
    std::vector<DeviceMetrics> devices;               // Auto-populated, unbounded
};

// ============================================================================
// Dashboard — auto-scaling terminal UI for any hardware topology
// ============================================================================

class Dashboard {
public:
    static Dashboard& instance();

    void init(int total_steps, int refresh_ms = 200);
    void update(const TrainingMetrics& metrics);
    void render();
    void finish();
    void set_enabled(bool enabled) { enabled_ = enabled; }
    bool is_enabled() const noexcept { return enabled_; }

private:
    Dashboard() = default;

    // Rendering helpers
    std::string render_device_summary(const std::vector<DeviceMetrics>& devices) const;
    std::string render_device_detail(const DeviceMetrics& d, int bar_width = 30) const;
    std::string render_devices_grouped(const std::vector<DeviceMetrics>& devices) const;
    std::string format_progress_bar(int step, int total, int width = 40) const;
    std::string format_memory_bar(size_t used, size_t total, int width = 30) const;
    std::string format_time(double seconds) const;
    std::string format_memory(size_t bytes) const;
    std::string format_loss_chart(const std::vector<float>& losses, int width, int height) const;
    void clear_screen() const;

    int total_steps_ = 0;
    int refresh_ms_ = 200;
    bool enabled_ = true;
    bool initialized_ = false;

    TrainingMetrics current_;
    std::vector<float> loss_history_;
    std::chrono::steady_clock::time_point start_time_;
    std::chrono::steady_clock::time_point last_render_;
    mutable std::mutex mutex_;
};

} // namespace ui
} // namespace rootseed