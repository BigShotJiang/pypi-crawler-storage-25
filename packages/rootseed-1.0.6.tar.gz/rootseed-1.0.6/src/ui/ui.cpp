// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// ui.cpp — Auto-Scaling Terminal Dashboard: Any Number of Devices (Section 15)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "ui/ui.h"
#include "utils/log.h"

#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <set>

namespace rootseed {
namespace ui {

// ============================================================================
// Singleton & Init
// ============================================================================

Dashboard& Dashboard::instance() {
    static Dashboard s_instance;
    return s_instance;
}

void Dashboard::init(int total_steps, int refresh_ms) {
    std::lock_guard<std::mutex> lock(mutex_);
    total_steps_ = total_steps;
    refresh_ms_ = refresh_ms;
    start_time_ = std::chrono::steady_clock::now();
    last_render_ = start_time_;
    loss_history_.clear();
    initialized_ = true;
    RS_LOG_INFO("Dashboard initialized: " + std::to_string(total_steps) + " steps");
    clear_screen();
}

void Dashboard::update(const TrainingMetrics& metrics) {
    std::lock_guard<std::mutex> lock(mutex_);
    current_ = metrics;
    if (metrics.loss > 0.0f) {
        loss_history_.push_back(metrics.loss);
        if (loss_history_.size() > 100) loss_history_.erase(loss_history_.begin());
    }
}

// ============================================================================
// Render
// ============================================================================

void Dashboard::render() {
    if (!enabled_ || !initialized_) return;

    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_render_).count();
    if (elapsed < refresh_ms_) return;
    last_render_ = now;

    std::lock_guard<std::mutex> lock(mutex_);
    clear_screen();

    std::ostringstream oss;

    // Header
    oss << "╔══════════════════════════════════════════════════════════════╗\n";
    oss << "║  Root-Seed Training Dashboard                                ║\n";
    oss << "╚══════════════════════════════════════════════════════════════╝\n\n";

    // Progress
    oss << "Epoch " << current_.epoch << " | Step " << current_.step << "/" << total_steps_;
    if (current_.world_size > 1) oss << " | World: " << current_.world_size;
    oss << "\n";
    oss << format_progress_bar(current_.step, total_steps_, 50) << "\n";
    double step_time = current_.elapsed_seconds / std::max(1, current_.step);
    oss << "ETA: " << format_time((total_steps_ - current_.step) * step_time) << "\n\n";

    // Metrics
    oss << "┌─────────────────────────────────────────────────────────────┐\n";
    oss << "│ Loss:     " << std::setw(10) << std::fixed << std::setprecision(6) << current_.loss << "                                    │\n";
    oss << "│ Accuracy: " << std::setw(10) << std::fixed << std::setprecision(2) << (current_.accuracy * 100.0f) << "%                                    │\n";
    oss << "│ LR:       " << std::setw(10) << std::scientific << std::setprecision(4) << current_.lr << "                                    │\n";
    oss << "│ Speed:    " << std::setw(10) << std::fixed << std::setprecision(1) << current_.samples_per_second << " samples/sec                          │\n";
    oss << "└─────────────────────────────────────────────────────────────┘\n\n";

    // Devices — auto-scale based on count
    oss << render_device_summary(current_.devices) << "\n";

    // Loss chart
    if (!loss_history_.empty()) {
        oss << "Loss Curve:\n";
        oss << format_loss_chart(loss_history_, 60, 10) << "\n";
    }

    std::cout << oss.str() << std::flush;
}

// ============================================================================
// Device summary — auto-scales from 1 to unlimited devices
// ============================================================================

std::string Dashboard::render_device_summary(const std::vector<DeviceMetrics>& devices) const {
    if (devices.empty()) {
        return "┌─────────────────────────────────────────────────────────────┐\n"
               "│ No devices detected                                         │\n"
               "└─────────────────────────────────────────────────────────────┘";
    }

    std::ostringstream oss;
    size_t count = devices.size();

    if (count <= 4) {
        // Show per-device detail
        oss << "┌─────────────────────────────────────────────────────────────┐\n";
        for (const auto& d : devices) {
            oss << render_device_detail(d, 45) << "\n";
        }
        oss << "└─────────────────────────────────────────────────────────────┘";
    } else if (count <= 16) {
        // Group by type
        oss << "┌─────────────────────────────────────────────────────────────┐\n";
        oss << render_devices_grouped(devices);
        oss << "└─────────────────────────────────────────────────────────────┘";
    } else {
        // Single summary line for large clusters
        size_t total_mem = 0;
        std::set<std::string> types;
        for (const auto& d : devices) {
            total_mem += d.memory_total_mb;
            types.insert(d.type);
        }
        oss << "┌─────────────────────────────────────────────────────────────┐\n";
        oss << "│ " << std::setw(3) << count << " devices across " << types.size() << " types | ";
        oss << format_memory(total_mem * 1024 * 1024) << " total memory";
        oss << "                    │\n";
        oss << "└─────────────────────────────────────────────────────────────┘";
    }

    return oss.str();
}

std::string Dashboard::render_device_detail(const DeviceMetrics& d, int bar_width) const {
    std::ostringstream oss;
    oss << "│ " << d.name << " [" << d.type << ":" << d.index << "]";
    // Pad to align memory bar
    size_t pad = (d.name.size() + d.type.size() + 6 < 30) ? 30 - d.name.size() - d.type.size() - 6 : 1;
    for (size_t i = 0; i < pad; ++i) oss << " ";
    oss << format_memory_bar(d.memory_used_mb, d.memory_total_mb, bar_width);
    if (d.utilization_pct > 0.0f) {
        oss << " " << std::fixed << std::setprecision(0) << d.utilization_pct << "%";
    }
    oss << " │";
    return oss.str();
}

std::string Dashboard::render_devices_grouped(const std::vector<DeviceMetrics>& devices) const {
    std::ostringstream oss;

    // Count and sum by type
    std::unordered_map<std::string, int> count_by_type;
    std::unordered_map<std::string, size_t> mem_used_by_type;
    std::unordered_map<std::string, size_t> mem_total_by_type;

    for (const auto& d : devices) {
        count_by_type[d.type]++;
        mem_used_by_type[d.type] += d.memory_used_mb;
        mem_total_by_type[d.type] += d.memory_total_mb;
    }

    for (const auto& [type, count] : count_by_type) {
        oss << "│ " << count << "×" << type << " | "
            << format_memory(mem_total_by_type[type] * 1024 * 1024) << " total | "
            << format_memory(mem_used_by_type[type] * 1024 * 1024) << " used";
        // Pad
        for (size_t i = 0; i < 10; ++i) oss << " ";
        oss << "│\n";
    }

    return oss.str();
}

// ============================================================================
// Finish
// ============================================================================

void Dashboard::finish() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_) return;

    auto now = std::chrono::steady_clock::now();
    auto total_sec = std::chrono::duration<double>(now - start_time_).count();

    clear_screen();
    std::cout << "╔══════════════════════════════════════════════════════════════╗\n";
    std::cout << "║  Training Complete!                                          ║\n";
    std::cout << "╚══════════════════════════════════════════════════════════════╝\n\n";
    std::cout << "Total time:  " << format_time(total_sec) << "\n";
    std::cout << "Final loss:  " << std::fixed << std::setprecision(6) << current_.loss << "\n";
    std::cout << "Final acc:   " << std::fixed << std::setprecision(2) << (current_.accuracy * 100.0f) << "%\n";
    std::cout << "Devices:     " << current_.devices.size() << "\n";
    std::cout << std::endl;
    initialized_ = false;
}

// ============================================================================
// Format helpers (unchanged from original)
// ============================================================================

std::string Dashboard::format_progress_bar(int step, int total, int width) const {
    float pct = (total > 0) ? static_cast<float>(step) / static_cast<float>(total) : 0.0f;
    int filled = static_cast<int>(pct * width);
    std::ostringstream oss;
    oss << "[";
    for (int i = 0; i < width; ++i) oss << (i < filled ? "█" : (i == filled ? ">" : " "));
    oss << "] " << std::fixed << std::setprecision(1) << (pct * 100.0f) << "%";
    return oss.str();
}

std::string Dashboard::format_memory_bar(size_t used, size_t total, int width) const {
    if (total == 0) return "[" + std::string(width, ' ') + "]";
    float pct = static_cast<float>(used) / static_cast<float>(total);
    int filled = static_cast<int>(pct * width);
    std::ostringstream oss;
    oss << "[";
    for (int i = 0; i < width; ++i) oss << (i < filled ? "█" : " ");
    oss << "] " << format_memory(used * 1024 * 1024) << "/" << format_memory(total * 1024 * 1024);
    return oss.str();
}

std::string Dashboard::format_time(double seconds) const {
    if (seconds < 60) return std::to_string(static_cast<int>(seconds)) + "s";
    if (seconds < 3600) return std::to_string(static_cast<int>(seconds) / 60) + "m " + std::to_string(static_cast<int>(seconds) % 60) + "s";
    return std::to_string(static_cast<int>(seconds) / 3600) + "h " + std::to_string((static_cast<int>(seconds) % 3600) / 60) + "m";
}

std::string Dashboard::format_memory(size_t bytes) const {
    if (bytes >= 1024 * 1024 * 1024) return std::to_string(bytes / (1024 * 1024 * 1024)) + " GB";
    if (bytes >= 1024 * 1024) return std::to_string(bytes / (1024 * 1024)) + " MB";
    return std::to_string(bytes / 1024) + " KB";
}

std::string Dashboard::format_loss_chart(const std::vector<float>& losses, int width, int height) const {
    if (losses.empty()) return "";
    float max_loss = *std::max_element(losses.begin(), losses.end());
    float min_loss = *std::min_element(losses.begin(), losses.end());
    float range = std::max(max_loss - min_loss, 1e-6f);
    std::ostringstream oss;
    for (int h = height - 1; h >= 0; --h) {
        float threshold = min_loss + range * (static_cast<float>(h) / height);
        for (int w = 0; w < width; ++w) {
            int idx = w * losses.size() / width;
            if (idx >= static_cast<int>(losses.size())) break;
            oss << (losses[idx] >= threshold ? "█" : " ");
        }
        oss << "\n";
    }
    return oss.str();
}

void Dashboard::clear_screen() const {
    std::cout << "\033[2J\033[H";
}

} // namespace ui
} // namespace rootseed