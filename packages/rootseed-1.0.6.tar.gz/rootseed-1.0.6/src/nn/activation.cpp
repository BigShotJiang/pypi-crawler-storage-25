// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// activation.cpp — Activation Function Implementations
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/activation.h"

#include <cmath>
#include <algorithm>

namespace rootseed {
namespace nn {

Activation::Activation(const std::string& name) {
    set_name(name);
}

core::Tensor Activation::forward(const core::Tensor& input) {
    core::Tensor output = core::Tensor::zeros(input.shape(), input.dtype(), input.device());
    int64_t n = input.numel();

    if (forward_fn_) {
        for (int64_t i = 0; i < n; ++i) {
            output.set_item(i, forward_fn_(input.item(i)));
        }
    }

    return output;
}

void Activation::set_forward_fn(std::function<float(float)> fn) {
    forward_fn_ = std::move(fn);
}

void Activation::set_backward_fn(std::function<float(float, float)> grad_fn) {
    backward_fn_ = std::move(grad_fn);
}

// ============================================================================
// Factory functions
// ============================================================================

std::shared_ptr<Activation> ReLU() {
    auto act = std::make_shared<Activation>("ReLU");
    act->set_forward_fn([](float x) { return std::max(0.0f, x); });
    act->set_backward_fn([](float grad_out, float x) {
        return x > 0.0f ? grad_out : 0.0f;
    });
    return act;
}

std::shared_ptr<Activation> GELU() {
    auto act = std::make_shared<Activation>("GELU");
    act->set_forward_fn([](float x) {
        // GELU approximation: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
        const float sqrt_2_pi = 0.7978845608f;
        const float coeff = 0.044715f;
        float x3 = x * x * x;
        float inner = sqrt_2_pi * (x + coeff * x3);
        return 0.5f * x * (1.0f + std::tanh(inner));
    });
    return act;
}

std::shared_ptr<Activation> SiLU() {
    auto act = std::make_shared<Activation>("SiLU");
    act->set_forward_fn([](float x) {
        // SiLU: x * sigmoid(x)
        float sig = 1.0f / (1.0f + std::exp(-x));
        return x * sig;
    });
    return act;
}

std::shared_ptr<Activation> Tanh() {
    auto act = std::make_shared<Activation>("Tanh");
    act->set_forward_fn([](float x) { return std::tanh(x); });
    return act;
}

std::shared_ptr<Activation> Sigmoid() {
    auto act = std::make_shared<Activation>("Sigmoid");
    act->set_forward_fn([](float x) { return 1.0f / (1.0f + std::exp(-x)); });
    return act;
}

} // namespace nn
} // namespace rootseed