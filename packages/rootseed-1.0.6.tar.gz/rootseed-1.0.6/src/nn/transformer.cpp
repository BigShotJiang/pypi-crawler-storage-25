// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// transformer.cpp — Transformer Encoder Layer Implementation
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/transformer.h"

namespace rootseed {
namespace nn {

// ============================================================================
// TransformerEncoderLayer
// ============================================================================

TransformerEncoderLayer::TransformerEncoderLayer(int64_t d_model, int64_t num_heads,
                                                   int64_t d_ff, float dropout,
                                                   const std::string& activation,
                                                   bool use_rmsnorm,
                                                   const core::Device& device)
    : d_model_(d_model)
    , dropout_(dropout) {

    if (d_ff <= 0) d_ff = 4 * d_model;
    set_name("TransformerEncoderLayer");

    // Normalization
    if (use_rmsnorm) {
        norm1_ = std::make_shared<RMSNorm>(d_model, 1e-6f, true, device);
        norm2_ = std::make_shared<RMSNorm>(d_model, 1e-6f, true, device);
    } else {
        norm1_ = std::make_shared<LayerNorm>(d_model, 1e-5f, true, device);
        norm2_ = std::make_shared<LayerNorm>(d_model, 1e-5f, true, device);
    }

    // Attention
    attention_ = std::make_shared<MultiHeadAttention>(d_model, num_heads, dropout, true, device);

    // Dropout
    dropout1_ = std::make_shared<Dropout>(1.0f - dropout);
    dropout2_ = std::make_shared<Dropout>(1.0f - dropout);

    // FFN: Linear → Activation → Linear
    ffn_linear1_ = std::make_shared<Linear>(d_model, d_ff, true, device);
    ffn_linear2_ = std::make_shared<Linear>(d_ff, d_model, true, device);

    if (activation == "gelu") {
        activation_ = GELU();
    } else if (activation == "relu") {
        activation_ = ReLU();
    } else if (activation == "silu") {
        activation_ = SiLU();
    } else {
        activation_ = GELU();  // Default
    }

    // Register submodules
    register_module("norm1", norm1_);
    register_module("norm2", norm2_);
    register_module("attention", attention_);
    register_module("dropout1", dropout1_);
    register_module("dropout2", dropout2_);
    register_module("ffn_linear1", ffn_linear1_);
    register_module("ffn_linear2", ffn_linear2_);
}

core::Tensor TransformerEncoderLayer::forward(const core::Tensor& input) {
    // Self-attention block with residual
    core::Tensor residual = input;
    core::Tensor x = norm1_->forward(input);
    x = attention_->forward(x);
    x = dropout1_->forward(x);
    x = x.add(residual);  // Residual connection

    // FFN block with residual
    residual = x;
    x = norm2_->forward(x);
    x = ffn_linear1_->forward(x);
    x = activation_->forward(x);
    x = ffn_linear2_->forward(x);
    x = dropout2_->forward(x);
    x = x.add(residual);  // Residual connection

    return x;
}

// ============================================================================
// TransformerEncoder (stack of layers)
// ============================================================================

TransformerEncoder::TransformerEncoder(int64_t num_layers, int64_t d_model, int64_t num_heads,
                                         int64_t d_ff, float dropout,
                                         const std::string& activation,
                                         bool use_rmsnorm,
                                         const core::Device& device) {
    set_name("TransformerEncoder");

    for (int64_t i = 0; i < num_layers; ++i) {
        auto layer = std::make_shared<TransformerEncoderLayer>(
            d_model, num_heads, d_ff, dropout, activation, use_rmsnorm, device);
        layers_.push_back(layer);
        register_module("layer_" + std::to_string(i), layer);
    }
}

core::Tensor TransformerEncoder::forward(const core::Tensor& input) {
    core::Tensor x = input;
    for (auto& layer : layers_) {
        x = layer->forward(x);
    }
    return x;
}

std::shared_ptr<TransformerEncoderLayer> TransformerEncoder::layer(int64_t idx) {
    if (idx >= 0 && idx < static_cast<int64_t>(layers_.size())) {
        return layers_[idx];
    }
    return nullptr;
}

} // namespace nn
} // namespace rootseed