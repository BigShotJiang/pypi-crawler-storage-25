// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// norm.cpp — Normalization Layer Implementations (LayerNorm, RMSNorm, BatchNorm, GroupNorm)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/norm.h"

#include <cmath>
#include <algorithm>

namespace rootseed {
namespace nn {

// ============================================================================
// LayerNorm
// ============================================================================

LayerNorm::LayerNorm(int64_t normalized_shape, float eps, bool elementwise_affine,
                     const core::Device& device)
    : normalized_shape_(normalized_shape)
    , eps_(eps)
    , elementwise_affine_(elementwise_affine) {
    set_name("LayerNorm");

    if (elementwise_affine_) {
        core::Shape param_shape({normalized_shape});
        auto gamma = Parameter::kaiming_uniform(param_shape, normalized_shape,
                                                  core::DType::Float32, device);
        auto beta  = Parameter::zeros(param_shape, core::DType::Float32, device);
        register_parameter("gamma", gamma);
        register_parameter("beta", beta);
    }
}

core::Tensor LayerNorm::forward(const core::Tensor& input) {
    // Assume input is 2D: (batch, normalized_shape)
    int64_t batch = input.shape().ndim() > 0 ? input.shape()[0] : 1;
    int64_t dim = normalized_shape_;

    core::Tensor output = core::Tensor::zeros(input.shape(), input.dtype(), input.device());

    for (int64_t b = 0; b < batch; ++b) {
        // Compute mean
        float mean = 0.0f;
        for (int64_t i = 0; i < dim; ++i) {
            mean += input.item(b, i);
        }
        mean /= static_cast<float>(dim);

        // Compute variance
        float var = 0.0f;
        for (int64_t i = 0; i < dim; ++i) {
            float diff = input.item(b, i) - mean;
            var += diff * diff;
        }
        var /= static_cast<float>(dim);

        // Normalize
        float inv_std = 1.0f / std::sqrt(var + eps_);
        for (int64_t i = 0; i < dim; ++i) {
            float normalized = (input.item(b, i) - mean) * inv_std;

            if (elementwise_affine_) {
                float gamma = get_parameter("gamma")->data().item(i);
                float beta  = get_parameter("beta")->data().item(i);
                normalized = normalized * gamma + beta;
            }

            output.set_item(b, i, normalized);
        }
    }

    return output;
}

// ============================================================================
// RMSNorm — y = x / sqrt(E[x^2] + eps) * gamma
// ============================================================================

RMSNorm::RMSNorm(int64_t normalized_shape, float eps, bool elementwise_affine,
                 const core::Device& device)
    : normalized_shape_(normalized_shape)
    , eps_(eps)
    , elementwise_affine_(elementwise_affine) {
    set_name("RMSNorm");

    if (elementwise_affine_) {
        core::Shape param_shape({normalized_shape});
        auto gamma = Parameter::kaiming_uniform(param_shape, normalized_shape,
                                                  core::DType::Float32, device);
        register_parameter("gamma", gamma);
    }
}

core::Tensor RMSNorm::forward(const core::Tensor& input) {
    int64_t batch = input.shape().ndim() > 0 ? input.shape()[0] : 1;
    int64_t dim = normalized_shape_;

    core::Tensor output = core::Tensor::zeros(input.shape(), input.dtype(), input.device());

    for (int64_t b = 0; b < batch; ++b) {
        // Compute RMS
        float sum_sq = 0.0f;
        for (int64_t i = 0; i < dim; ++i) {
            float val = input.item(b, i);
            sum_sq += val * val;
        }
        float rms = std::sqrt(sum_sq / static_cast<float>(dim) + eps_);

        // Normalize
        for (int64_t i = 0; i < dim; ++i) {
            float normalized = input.item(b, i) / rms;

            if (elementwise_affine_) {
                float gamma = get_parameter("gamma")->data().item(i);
                normalized *= gamma;
            }

            output.set_item(b, i, normalized);
        }
    }

    return output;
}

// ============================================================================
// BatchNorm1D
// ============================================================================

BatchNorm1D::BatchNorm1D(int64_t num_features, float eps, float momentum,
                         bool affine, const core::Device& device)
    : num_features_(num_features)
    , eps_(eps)
    , momentum_(momentum)
    , affine_(affine) {
    set_name("BatchNorm1D");

    if (affine_) {
        core::Shape param_shape({num_features});
        auto gamma = Parameter::kaiming_uniform(param_shape, num_features,
                                                  core::DType::Float32, device);
        auto beta  = Parameter::zeros(param_shape, core::DType::Float32, device);
        register_parameter("gamma", gamma);
        register_parameter("beta", beta);
    }
}

core::Tensor BatchNorm1D::forward(const core::Tensor& input) {
    // input: (batch, features)
    int64_t batch = input.shape().ndim() > 0 ? input.shape()[0] : 1;
    int64_t feats = num_features_;

    core::Tensor output = core::Tensor::zeros(input.shape(), input.dtype(), input.device());

    for (int64_t f = 0; f < feats; ++f) {
        // Compute mean over batch
        float mean = 0.0f;
        for (int64_t b = 0; b < batch; ++b) {
            mean += input.item(b, f);
        }
        mean /= static_cast<float>(batch);

        // Compute variance
        float var = 0.0f;
        for (int64_t b = 0; b < batch; ++b) {
            float diff = input.item(b, f) - mean;
            var += diff * diff;
        }
        var /= static_cast<float>(batch);

        float inv_std = 1.0f / std::sqrt(var + eps_);

        for (int64_t b = 0; b < batch; ++b) {
            float normalized = (input.item(b, f) - mean) * inv_std;

            if (affine_) {
                float gamma = get_parameter("gamma")->data().item(f);
                float beta  = get_parameter("beta")->data().item(f);
                normalized = normalized * gamma + beta;
            }

            output.set_item(b, f, normalized);
        }
    }

    return output;
}

// ============================================================================
// GroupNorm
// ============================================================================

GroupNorm::GroupNorm(int64_t num_groups, int64_t num_channels, float eps,
                     bool affine, const core::Device& device)
    : num_groups_(num_groups)
    , num_channels_(num_channels)
    , eps_(eps)
    , affine_(affine) {
    set_name("GroupNorm");

    if (affine_) {
        core::Shape param_shape({num_channels});
        auto gamma = Parameter::kaiming_uniform(param_shape, num_channels,
                                                  core::DType::Float32, device);
        auto beta  = Parameter::zeros(param_shape, core::DType::Float32, device);
        register_parameter("gamma", gamma);
        register_parameter("beta", beta);
    }
}

core::Tensor GroupNorm::forward(const core::Tensor& input) {
    // input: (batch, channels, H, W) — simplified for (batch, channels)
    int64_t batch = input.shape().ndim() > 0 ? input.shape()[0] : 1;
    int64_t ch_per_group = num_channels_ / num_groups_;

    core::Tensor output = core::Tensor::zeros(input.shape(), input.dtype(), input.device());

    for (int64_t b = 0; b < batch; ++b) {
        for (int64_t g = 0; g < num_groups_; ++g) {
            int64_t ch_start = g * ch_per_group;
            int64_t ch_end = ch_start + ch_per_group;
            int64_t group_n = ch_per_group;

            // Mean
            float mean = 0.0f;
            for (int64_t c = ch_start; c < ch_end; ++c) {
                mean += input.item(b, c);
            }
            mean /= static_cast<float>(group_n);

            // Variance
            float var = 0.0f;
            for (int64_t c = ch_start; c < ch_end; ++c) {
                float diff = input.item(b, c) - mean;
                var += diff * diff;
            }
            var /= static_cast<float>(group_n);

            float inv_std = 1.0f / std::sqrt(var + eps_);

            for (int64_t c = ch_start; c < ch_end; ++c) {
                float normalized = (input.item(b, c) - mean) * inv_std;

                if (affine_) {
                    float gamma = get_parameter("gamma")->data().item(c);
                    float beta  = get_parameter("beta")->data().item(c);
                    normalized = normalized * gamma + beta;
                }

                output.set_item(b, c, normalized);
            }
        }
    }

    return output;
}

} // namespace nn
} // namespace rootseed