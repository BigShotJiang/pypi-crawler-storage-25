// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// module.h — Base Module Class for Neural Network Layers (Section 5)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"
#include "nn/parameter.h"

#include <string>
#include <vector>
#include <memory>
#include <unordered_map>

namespace rootseed {
namespace nn {

// ============================================================================
// Module — base class for all neural network components
//
// Mirrors PyTorch's nn.Module API:
//   - forward() defines the computation
//   - parameters() returns all trainable parameters
//   - train() / eval() toggle training mode (affects dropout, batchnorm, etc.)
//   - state_dict() / load_state_dict() for serialization
// ============================================================================

class Module {
public:
    Module() = default;
    virtual ~Module() = default;

    // ---- Forward pass ----
    /// Compute the output of this module given an input tensor.
    /// Must be overridden by subclasses.
    virtual core::Tensor forward(const core::Tensor& input) = 0;

    /// Convenience: call forward via operator()
    core::Tensor operator()(const core::Tensor& input) {
        return forward(input);
    }

    // ---- Parameters ----
    /// Returns all trainable parameters of this module and its submodules.
    std::vector<std::shared_ptr<Parameter>> parameters();

    /// Returns all submodules (for recursive parameter collection).
    std::vector<Module*> modules();

    /// Register a parameter (weight, bias, etc.) with this module.
    void register_parameter(const std::string& name, std::shared_ptr<Parameter> param);

    /// Register a submodule with this module.
    void register_module(const std::string& name, std::shared_ptr<Module> module);

    /// Look up a parameter by name.
    std::shared_ptr<Parameter> get_parameter(const std::string& name) const;

    /// Look up a submodule by name.
    std::shared_ptr<Module> get_module(const std::string& name) const;

    // ---- Training mode ----
    /// Set module to training mode (affects dropout, batchnorm, etc.).
    virtual void train(bool mode = true);

    /// Set module to evaluation mode.
    void eval() { train(false); }

    /// Returns true if module is in training mode.
    bool is_training() const noexcept { return training_; }

    // ---- Device ----
    /// Move all parameters to a different device.
    virtual void to(const core::Device& device);

    // ---- Serialization helpers ----
    /// Return a dictionary of parameter names → tensors.
    std::unordered_map<std::string, core::Tensor> state_dict() const;

    /// Load parameters from a state dictionary.
    void load_state_dict(const std::unordered_map<std::string, core::Tensor>& state);

    // ---- Metadata ----
    void set_name(const std::string& name) { name_ = name; }
    const std::string& name() const noexcept { return name_; }

protected:
    std::string name_;
    bool training_ = true;

    // Named parameters and submodules
    std::unordered_map<std::string, std::shared_ptr<Parameter>> parameters_;
    std::unordered_map<std::string, std::shared_ptr<Module>> modules_;

    // Ordered list for deterministic iteration
    std::vector<std::string> parameter_order_;
    std::vector<std::string> module_order_;
};

} // namespace nn
} // namespace rootseed