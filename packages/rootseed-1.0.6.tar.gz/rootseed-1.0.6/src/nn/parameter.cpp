// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// parameter.cpp — Parameter Implementation with Aleam Random Initialization (Section 5, 8)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/parameter.h"

#include <cmath>

namespace rootseed {
namespace nn {

Parameter::Parameter(const core::Shape& shape, core::DType dtype, const core::Device& device)
    : tensor_(core::Tensor::zeros(shape, dtype, device)) {
    tensor_.set_requires_grad(true);
}

Parameter::Parameter(const core::Tensor& tensor)
    : tensor_(tensor) {
    tensor_.set_requires_grad(true);
}

std::shared_ptr<Parameter> Parameter::zeros(const core::Shape& shape,
                                              core::DType dtype,
                                              const core::Device& device) {
    auto p = std::make_shared<Parameter>(shape, dtype, device);
    return p;
}

std::shared_ptr<Parameter> Parameter::kaiming_uniform(const core::Shape& shape,
                                                        int64_t fan_in,
                                                        core::DType dtype,
                                                        const core::Device& device) {
    // Kaiming uniform initialization: U(-sqrt(6/fan_in), sqrt(6/fan_in))
    // Uses Aleam true random numbers via rootseed.random module.
    // For C++-side initialization, we use a deterministic fallback that
    // gets overridden by Python-side Aleam init.

    float bound = std::sqrt(6.0f / static_cast<float>(fan_in));
    auto param = std::make_shared<Parameter>(shape, dtype, device);

    // Fill with pseudo-random values in [-bound, bound]
    // In production, Python rootseed.random.get_rng().kaiming_uniform() is called
    // which uses Aleam hardware entropy.
    int64_t n = shape.numel();
    for (int64_t i = 0; i < n; ++i) {
        // Simple hash-based fill (will be replaced by Aleam from Python)
        float val = (static_cast<float>(i * 2654435761ULL % 10000) / 10000.0f) * 2.0f * bound - bound;
        param->data().set_item(i, val);
    }

    return param;
}

} // namespace nn
} // namespace rootseed