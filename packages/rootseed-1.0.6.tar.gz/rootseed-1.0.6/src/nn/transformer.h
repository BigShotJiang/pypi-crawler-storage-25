// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// transformer.h — Transformer Encoder Layer: Self-Attention + FFN + Residual
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "nn/attention.h"
#include "nn/linear.h"
#include "nn/norm.h"
#include "nn/activation.h"
#include "nn/dropout.h"

#include <memory>

namespace rootseed {
namespace nn {

// ============================================================================
// TransformerEncoderLayer — one transformer block
//
// Architecture:
//   x → LayerNorm → Self-Attention → Dropout → Residual (+x)
//     → LayerNorm → FFN (Linear→GELU→Linear) → Dropout → Residual
//
// Used in BERT, GPT, LLaMA (with RMSNorm variant), etc.
// ============================================================================

class TransformerEncoderLayer : public Module {
public:
    /// Create a transformer encoder layer.
    /// @param d_model      Model dimension
    /// @param num_heads    Number of attention heads
    /// @param d_ff         Feed-forward hidden dimension (default: 4 * d_model)
    /// @param dropout      Dropout probability
    /// @param activation   "gelu", "relu", or "silu"
    /// @param use_rmsnorm  If true, use RMSNorm instead of LayerNorm (LLaMA-style)
    TransformerEncoderLayer(int64_t d_model, int64_t num_heads,
                            int64_t d_ff = -1, float dropout = 0.1f,
                            const std::string& activation = "gelu",
                            bool use_rmsnorm = false,
                            const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

private:
    int64_t d_model_;
    float dropout_;

    // Sub-layers
    std::shared_ptr<Module> norm1_;
    std::shared_ptr<Module> norm2_;
    std::shared_ptr<MultiHeadAttention> attention_;
    std::shared_ptr<Dropout> dropout1_;
    std::shared_ptr<Dropout> dropout2_;
    std::shared_ptr<Linear> ffn_linear1_;
    std::shared_ptr<Linear> ffn_linear2_;
    std::shared_ptr<Activation> activation_;
};

// ============================================================================
// Sequential Transformer — stack of encoder layers
// ============================================================================

class TransformerEncoder : public Module {
public:
    TransformerEncoder(int64_t num_layers, int64_t d_model, int64_t num_heads,
                       int64_t d_ff = -1, float dropout = 0.1f,
                       const std::string& activation = "gelu",
                       bool use_rmsnorm = false,
                       const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

    /// Access individual layers.
    std::shared_ptr<TransformerEncoderLayer> layer(int64_t idx);

private:
    std::vector<std::shared_ptr<TransformerEncoderLayer>> layers_;
};

} // namespace nn
} // namespace rootseed