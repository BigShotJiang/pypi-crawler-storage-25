// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// conv.cpp — Convolution Layer Implementations (im2col + matmul)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/conv.h"

#include <cmath>
#include <algorithm>
#include <vector>

namespace rootseed {
namespace nn {

// ============================================================================
// Conv2D
// ============================================================================

Conv2D::Conv2D(int64_t in_channels, int64_t out_channels,
               int64_t kernel_size, int64_t stride, int64_t padding, int64_t dilation,
               bool bias, const core::Device& device)
    : Conv2D(in_channels, out_channels,
             kernel_size, kernel_size,
             stride, stride,
             padding, padding,
             dilation, dilation,
             bias, device) {}

Conv2D::Conv2D(int64_t in_channels, int64_t out_channels,
               int64_t kernel_h, int64_t kernel_w,
               int64_t stride_h, int64_t stride_w,
               int64_t pad_h, int64_t pad_w,
               int64_t dilation_h, int64_t dilation_w,
               bool bias, const core::Device& device)
    : in_channels_(in_channels), out_channels_(out_channels)
    , kernel_h_(kernel_h), kernel_w_(kernel_w)
    , stride_h_(stride_h), stride_w_(stride_w)
    , pad_h_(pad_h), pad_w_(pad_w)
    , dilation_h_(dilation_h), dilation_w_(dilation_w)
    , has_bias_(bias) {

    set_name("Conv2D");

    // Weight: (out_channels, in_channels, kernel_h, kernel_w)
    core::Shape weight_shape({out_channels, in_channels, kernel_h, kernel_w});
    int64_t fan_in = in_channels * kernel_h * kernel_w;
    auto W = Parameter::kaiming_uniform(weight_shape, fan_in, core::DType::Float32, device);
    register_parameter("weight", W);

    if (has_bias_) {
        core::Shape bias_shape({out_channels});
        auto b = Parameter::zeros(bias_shape, core::DType::Float32, device);
        register_parameter("bias", b);
    }
}

core::Tensor Conv2D::forward(const core::Tensor& input) {
    // Input:  (N, C_in, H, W)
    // Weight: (C_out, C_in, kH, kW)
    // Output: (N, C_out, oH, oW)

    int64_t N     = input.shape()[0];
    int64_t C_in  = input.shape()[1];
    int64_t H     = input.shape()[2];
    int64_t W     = input.shape()[3];
    int64_t C_out = out_channels_;
    int64_t kH    = kernel_h_;
    int64_t kW    = kernel_w_;

    int64_t oH = (H + 2 * pad_h_ - dilation_h_ * (kH - 1) - 1) / stride_h_ + 1;
    int64_t oW = (W + 2 * pad_w_ - dilation_w_ * (kW - 1) - 1) / stride_w_ + 1;

    core::Shape out_shape({N, C_out, oH, oW});
    core::Tensor output = core::Tensor::zeros(out_shape, input.dtype(), input.device());

    auto W_tensor = get_parameter("weight")->data();

    // Scalar fallback: nested loops over output positions
    for (int64_t n = 0; n < N; ++n) {
        for (int64_t oc = 0; oc < C_out; ++oc) {
            for (int64_t oh = 0; oh < oH; ++oh) {
                for (int64_t ow = 0; ow < oW; ++ow) {
                    float acc = 0.0f;

                    for (int64_t ic = 0; ic < C_in; ++ic) {
                        for (int64_t kh = 0; kh < kH; ++kh) {
                            for (int64_t kw = 0; kw < kW; ++kw) {
                                int64_t ih = oh * stride_h_ + kh * dilation_h_ - pad_h_;
                                int64_t iw = ow * stride_w_ + kw * dilation_w_ - pad_w_;

                                if (ih >= 0 && ih < H && iw >= 0 && iw < W) {
                                    float in_val = input.item(n, ic * H * W + ih * W + iw);
                                    float w_val = W_tensor.item(oc, ic * kH * kW + kh * kW + kw);
                                    acc += in_val * w_val;
                                }
                            }
                        }
                    }

                    if (has_bias_) {
                        acc += get_parameter("bias")->data().item(oc);
                    }

                    // Set output value
                    int64_t out_idx = n * C_out * oH * oW + oc * oH * oW + oh * oW + ow;
                    output.set_item(out_idx, acc);
                }
            }
        }
    }

    return output;
}

// ============================================================================
// Conv1D
// ============================================================================

Conv1D::Conv1D(int64_t in_channels, int64_t out_channels, int64_t kernel_size,
               int64_t stride, int64_t padding, int64_t dilation,
               bool bias, const core::Device& device)
    : in_channels_(in_channels), out_channels_(out_channels)
    , kernel_size_(kernel_size)
    , stride_(stride), padding_(padding), dilation_(dilation)
    , has_bias_(bias) {

    set_name("Conv1D");

    // Weight: (out_channels, in_channels, kernel_size)
    core::Shape weight_shape({out_channels, in_channels, kernel_size});
    int64_t fan_in = in_channels * kernel_size;
    auto W = Parameter::kaiming_uniform(weight_shape, fan_in, core::DType::Float32, device);
    register_parameter("weight", W);

    if (has_bias_) {
        core::Shape bias_shape({out_channels});
        auto b = Parameter::zeros(bias_shape, core::DType::Float32, device);
        register_parameter("bias", b);
    }
}

core::Tensor Conv1D::forward(const core::Tensor& input) {
    // Input:  (N, C_in, L)
    // Output: (N, C_out, oL)

    int64_t N     = input.shape()[0];
    int64_t C_in  = input.shape()[1];
    int64_t L     = input.shape()[2];
    int64_t C_out = out_channels_;
    int64_t k     = kernel_size_;

    int64_t oL = (L + 2 * padding_ - dilation_ * (k - 1) - 1) / stride_ + 1;

    core::Shape out_shape({N, C_out, oL});
    core::Tensor output = core::Tensor::zeros(out_shape, input.dtype(), input.device());

    auto W_tensor = get_parameter("weight")->data();

    for (int64_t n = 0; n < N; ++n) {
        for (int64_t oc = 0; oc < C_out; ++oc) {
            for (int64_t ol = 0; ol < oL; ++ol) {
                float acc = 0.0f;

                for (int64_t ic = 0; ic < C_in; ++ic) {
                    for (int64_t ki = 0; ki < k; ++ki) {
                        int64_t il = ol * stride_ + ki * dilation_ - padding_;
                        if (il >= 0 && il < L) {
                            float in_val = input.item(n, ic * L + il);
                            float w_val = W_tensor.item(oc, ic * k + ki);
                            acc += in_val * w_val;
                        }
                    }
                }

                if (has_bias_) {
                    acc += get_parameter("bias")->data().item(oc);
                }

                int64_t out_idx = n * C_out * oL + oc * oL + ol;
                output.set_item(out_idx, acc);
            }
        }
    }

    return output;
}

} // namespace nn
} // namespace rootseed