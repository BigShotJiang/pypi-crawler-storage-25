// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// linear.h — Linear (Fully Connected) Layer: y = x @ W.T + b (Section 6.1)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "nn/parameter.h"

#include <memory>

namespace rootseed {
namespace nn {

// ============================================================================
// Linear — fully connected layer
//
// Applies a linear transformation: y = x @ W^T + b
//
// Shape:
//   Input:  (batch, in_features)
//   Weight: (out_features, in_features)
//   Bias:   (out_features,)
//   Output: (batch, out_features)
// ============================================================================

class Linear : public Module {
public:
    /// Create a Linear layer.
    /// @param in_features   Number of input features
    /// @param out_features  Number of output features
    /// @param bias          If true, adds a learnable bias term
    /// @param device        Device to place parameters on
    Linear(int64_t in_features, int64_t out_features, bool bias = true,
           const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

    // ---- Access ----
    std::shared_ptr<Parameter> weight() { return get_parameter("weight"); }
    std::shared_ptr<Parameter> bias()   { return get_parameter("bias"); }

    int64_t in_features()  const noexcept { return in_features_; }
    int64_t out_features() const noexcept { return out_features_; }

private:
    int64_t in_features_;
    int64_t out_features_;
    bool has_bias_;
};

} // namespace nn
} // namespace rootseed