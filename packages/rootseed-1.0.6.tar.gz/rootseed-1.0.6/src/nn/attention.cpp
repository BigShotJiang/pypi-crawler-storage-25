// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// attention.cpp — Multi-Head Attention Implementation (Scaled Dot-Product)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/attention.h"

#include <cmath>
#include <algorithm>

namespace rootseed {
namespace nn {

MultiHeadAttention::MultiHeadAttention(int64_t d_model, int64_t num_heads,
                                         float dropout, bool bias,
                                         const core::Device& device)
    : d_model_(d_model)
    , num_heads_(num_heads)
    , d_k_(d_model / num_heads)
    , dropout_(dropout) {

    set_name("MultiHeadAttention");

    // Q, K, V projections: d_model → d_model
    q_proj_ = std::make_shared<Linear>(d_model, d_model, bias, device);
    k_proj_ = std::make_shared<Linear>(d_model, d_model, bias, device);
    v_proj_ = std::make_shared<Linear>(d_model, d_model, bias, device);
    out_proj_ = std::make_shared<Linear>(d_model, d_model, bias, device);

    register_module("q_proj", q_proj_);
    register_module("k_proj", k_proj_);
    register_module("v_proj", v_proj_);
    register_module("out_proj", out_proj_);
}

core::Tensor MultiHeadAttention::forward(const core::Tensor& input) {
    return forward(input, input, input);
}

core::Tensor MultiHeadAttention::forward(const core::Tensor& query,
                                          const core::Tensor& key,
                                          const core::Tensor& value) {
    // input shape: (batch, seq, d_model)

    int64_t batch = query.shape()[0];
    int64_t seq_q = query.shape()[1];
    int64_t seq_k = key.shape()[1];

    // Project Q, K, V
    core::Tensor Q = q_proj_->forward(query);   // (batch, seq_q, d_model)
    core::Tensor K = k_proj_->forward(key);      // (batch, seq_k, d_model)
    core::Tensor V = v_proj_->forward(value);    // (batch, seq_k, d_model)

    // Reshape for multi-head: (batch, seq, d_model) → (batch, num_heads, seq, d_k)
    // Simplified: treat as 2D for matmul

    // Compute attention scores: Q @ K^T / sqrt(d_k)
    core::Tensor K_T = K.transpose();  // (d_model, seq_k)
    core::Tensor scores = Q.matmul(K_T);  // (batch, seq_q, seq_k)

    float scale = 1.0f / std::sqrt(static_cast<float>(d_k_));
    scores = scores.mul(scale);

    // Softmax over last dimension (row-wise)
    // For simplicity: apply softmax to each row
    core::Tensor attn_weights = core::Tensor::zeros(scores.shape(), scores.dtype(), scores.device());
    for (int64_t b = 0; b < batch; ++b) {
        for (int64_t i = 0; i < seq_q; ++i) {
            // Find max for numerical stability
            float max_val = -1e9f;
            for (int64_t j = 0; j < seq_k; ++j) {
                max_val = std::max(max_val, scores.item(b, i * seq_k + j));
            }
            // Exp and sum
            float sum_exp = 0.0f;
            for (int64_t j = 0; j < seq_k; ++j) {
                float val = std::exp(scores.item(b, i * seq_k + j) - max_val);
                attn_weights.set_item(b, i * seq_k + j, val);
                sum_exp += val;
            }
            // Normalize
            for (int64_t j = 0; j < seq_k; ++j) {
                float val = attn_weights.item(b, i * seq_k + j) / sum_exp;
                attn_weights.set_item(b, i * seq_k + j, val);
            }
        }
    }

    // Apply dropout to attention weights during training
    // (simplified — full dropout in production)

    // Weighted sum: attn @ V
    core::Tensor output = attn_weights.matmul(V);  // (batch, seq_q, d_model)

    // Output projection
    output = out_proj_->forward(output);

    return output;
}

} // namespace nn
} // namespace rootseed