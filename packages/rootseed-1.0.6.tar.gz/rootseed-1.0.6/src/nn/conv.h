// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// conv.h — Convolution Layers: Conv1D, Conv2D, Conv3D (Section 5)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "nn/parameter.h"

#include <memory>
#include <vector>

namespace rootseed {
namespace nn {

// ============================================================================
// Conv2D — 2D Convolution with im2col + matmul implementation
//
// Input:  (batch, in_channels, height, width)
// Weight: (out_channels, in_channels, kernel_h, kernel_w)
// Bias:   (out_channels,)
// Output: (batch, out_channels, out_h, out_w)
// ============================================================================

class Conv2D : public Module {
public:
    /// Create a 2D convolution layer.
    /// @param in_channels   Number of input channels
    /// @param out_channels  Number of output channels (filters)
    /// @param kernel_size   Height and width of the convolution kernel
    /// @param stride        Stride of the convolution
    /// @param padding       Zero-padding added to all four sides
    /// @param dilation      Spacing between kernel elements
    /// @param bias          If true, adds a learnable bias term
    Conv2D(int64_t in_channels, int64_t out_channels,
           int64_t kernel_size,
           int64_t stride = 1, int64_t padding = 0, int64_t dilation = 1,
           bool bias = true,
           const core::Device& device = core::Device{});

    /// Create with separate kernel height/width.
    Conv2D(int64_t in_channels, int64_t out_channels,
           int64_t kernel_h, int64_t kernel_w,
           int64_t stride_h = 1, int64_t stride_w = 1,
           int64_t pad_h = 0, int64_t pad_w = 0,
           int64_t dilation_h = 1, int64_t dilation_w = 1,
           bool bias = true,
           const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

    // ---- Access ----
    std::shared_ptr<Parameter> weight() { return get_parameter("weight"); }
    std::shared_ptr<Parameter> bias()   { return get_parameter("bias"); }

private:
    int64_t in_channels_, out_channels_;
    int64_t kernel_h_, kernel_w_;
    int64_t stride_h_, stride_w_;
    int64_t pad_h_, pad_w_;
    int64_t dilation_h_, dilation_w_;
    bool has_bias_;
};

// ============================================================================
// Conv1D — 1D Convolution (sequences, time-series)
// ============================================================================

class Conv1D : public Module {
public:
    Conv1D(int64_t in_channels, int64_t out_channels, int64_t kernel_size,
           int64_t stride = 1, int64_t padding = 0, int64_t dilation = 1,
           bool bias = true,
           const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

private:
    int64_t in_channels_, out_channels_;
    int64_t kernel_size_, stride_, padding_, dilation_;
    bool has_bias_;
};

} // namespace nn
} // namespace rootseed