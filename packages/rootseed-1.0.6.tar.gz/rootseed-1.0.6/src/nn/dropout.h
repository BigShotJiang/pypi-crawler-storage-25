// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dropout.h — Dropout Layer with Aleam True Random Mask Generation (Section 8.3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"

#include <memory>

namespace rootseed {
namespace nn {

// ============================================================================
// Dropout — randomly zeros elements during training
//
// During training: each element is kept with probability keep_prob,
// scaled by 1/keep_prob to preserve expected values.
// During eval: identity (no dropout).
//
// Section 8.3: Mask is generated using Aleam hardware entropy exclusively.
// No pseudorandom fallback.
// ============================================================================

class Dropout : public Module {
public:
    /// Create a Dropout layer.
    /// @param keep_prob  Probability of keeping an element (0 < keep_prob <= 1)
    explicit Dropout(float keep_prob = 0.5f);

    core::Tensor forward(const core::Tensor& input) override;

    // Override: no trainable parameters
    std::vector<std::shared_ptr<Parameter>> parameters() { return {}; }

    float keep_prob() const noexcept { return keep_prob_; }
    void set_keep_prob(float p) { keep_prob_ = p; }

private:
    float keep_prob_;
};

} // namespace nn
} // namespace rootseed