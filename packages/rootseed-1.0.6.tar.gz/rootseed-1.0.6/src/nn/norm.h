// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// norm.h — Normalization Layers: LayerNorm, RMSNorm, BatchNorm, GroupNorm
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "nn/parameter.h"

#include <memory>

namespace rootseed {
namespace nn {

// ============================================================================
// LayerNorm — normalizes over the last dimension
//
// y = (x - E[x]) / sqrt(Var[x] + eps) * gamma + beta
//
// Shape:
//   Input:  (batch, ..., normalized_shape)
//   gamma:  (normalized_shape,)
//   beta:   (normalized_shape,)
//   Output: same as input
// ============================================================================

class LayerNorm : public Module {
public:
    /// @param normalized_shape  Size of the last dimension(s) to normalize
    /// @param eps               Small epsilon for numerical stability
    /// @param elementwise_affine If true, learn gamma and beta
    LayerNorm(int64_t normalized_shape, float eps = 1e-5f, bool elementwise_affine = true,
              const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

    float epsilon() const noexcept { return eps_; }

private:
    int64_t normalized_shape_;
    float eps_;
    bool elementwise_affine_;
};

// ============================================================================
// RMSNorm — root mean square normalization (used in LLaMA, Mixtral)
//
// y = x / sqrt(E[x^2] + eps) * gamma
//
// Faster than LayerNorm — no mean subtraction, no beta parameter.
// ============================================================================

class RMSNorm : public Module {
public:
    RMSNorm(int64_t normalized_shape, float eps = 1e-6f, bool elementwise_affine = true,
            const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

private:
    int64_t normalized_shape_;
    float eps_;
    bool elementwise_affine_;
};

// ============================================================================
// BatchNorm1D — batch normalization for 1D inputs (batch, features)
//
// y = (x - running_mean) / sqrt(running_var + eps) * gamma + beta
//
// During training: uses batch statistics, updates running estimates.
// During eval: uses running estimates.
// ============================================================================

class BatchNorm1D : public Module {
public:
    BatchNorm1D(int64_t num_features, float eps = 1e-5f, float momentum = 0.1f,
                bool affine = true, const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

private:
    int64_t num_features_;
    float eps_;
    float momentum_;
    bool affine_;
};

// ============================================================================
// GroupNorm — divides channels into groups, normalizes within each group
//
// Useful for small batch sizes where BatchNorm is unstable.
// ============================================================================

class GroupNorm : public Module {
public:
    /// @param num_groups    Number of groups to split channels into
    /// @param num_channels  Total number of channels (must be divisible by num_groups)
    GroupNorm(int64_t num_groups, int64_t num_channels, float eps = 1e-5f,
              bool affine = true, const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

private:
    int64_t num_groups_;
    int64_t num_channels_;
    float eps_;
    bool affine_;
};

} // namespace nn
} // namespace rootseed