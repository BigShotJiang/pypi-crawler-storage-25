// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// module.cpp — Base Module Implementation: Parameter Registration, State Dict (Section 5)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/module.h"
#include "utils/log.h"

#include <algorithm>

namespace rootseed {
namespace nn {

// ============================================================================
// Parameter registration
// ============================================================================

void Module::register_parameter(const std::string& name, std::shared_ptr<Parameter> param) {
    if (parameters_.find(name) != parameters_.end()) {
        RS_LOG_WARN("Module '" + name_ + "': overwriting parameter '" + name + "'");
    }
    parameters_[name] = param;
    parameter_order_.push_back(name);
    param->set_requires_grad(true);  // Parameters always require gradients
}

void Module::register_module(const std::string& name, std::shared_ptr<Module> module) {
    if (modules_.find(name) != modules_.end()) {
        RS_LOG_WARN("Module '" + name_ + "': overwriting submodule '" + name + "'");
    }
    modules_[name] = module;
    module_order_.push_back(name);
    module->set_name(name);
}

// ============================================================================
// Parameter collection (recursive)
// ============================================================================

std::vector<std::shared_ptr<Parameter>> Module::parameters() {
    std::vector<std::shared_ptr<Parameter>> result;

    // Collect own parameters in registration order
    for (const auto& name : parameter_order_) {
        result.push_back(parameters_[name]);
    }

    // Recursively collect submodule parameters
    for (const auto& name : module_order_) {
        auto sub_params = modules_[name]->parameters();
        result.insert(result.end(), sub_params.begin(), sub_params.end());
    }

    return result;
}

std::vector<Module*> Module::modules() {
    std::vector<Module*> result;
    result.push_back(this);

    for (const auto& name : module_order_) {
        auto sub = modules_[name]->modules();
        result.insert(result.end(), sub.begin(), sub.end());
    }

    return result;
}

// ============================================================================
// Parameter / Module lookup
// ============================================================================

std::shared_ptr<Parameter> Module::get_parameter(const std::string& name) const {
    auto it = parameters_.find(name);
    if (it != parameters_.end()) {
        return it->second;
    }
    // Search submodules
    for (const auto& [mod_name, mod] : modules_) {
        auto p = mod->get_parameter(name);
        if (p) return p;
    }
    return nullptr;
}

std::shared_ptr<Module> Module::get_module(const std::string& name) const {
    auto it = modules_.find(name);
    if (it != modules_.end()) {
        return it->second;
    }
    return nullptr;
}

// ============================================================================
// Training mode
// ============================================================================

void Module::train(bool mode) {
    training_ = mode;
    // Propagate to submodules
    for (const auto& [name, mod] : modules_) {
        mod->train(mode);
    }
}

// ============================================================================
// Device transfer
// ============================================================================

void Module::to(const core::Device& device) {
    for (const auto& name : parameter_order_) {
        auto& param = parameters_[name];
        param->data() = param->data().to(device);
    }
    for (const auto& name : module_order_) {
        modules_[name]->to(device);
    }
}

// ============================================================================
// Serialization helpers
// ============================================================================

std::unordered_map<std::string, core::Tensor> Module::state_dict() const {
    std::unordered_map<std::string, core::Tensor> state;

    // Collect own parameters
    for (const auto& name : parameter_order_) {
        state[name] = parameters_.at(name)->data();
    }

    // Collect submodule parameters with prefix
    for (const auto& mod_name : module_order_) {
        auto sub_state = modules_.at(mod_name)->state_dict();
        for (const auto& [key, tensor] : sub_state) {
            state[mod_name + "." + key] = tensor;
        }
    }

    return state;
}

void Module::load_state_dict(const std::unordered_map<std::string, core::Tensor>& state) {
    for (const auto& name : parameter_order_) {
        auto it = state.find(name);
        if (it != state.end()) {
            parameters_[name]->data() = it->second;
        }
    }

    for (const auto& mod_name : module_order_) {
        // Extract submodule keys (prefix "mod_name.")
        std::unordered_map<std::string, core::Tensor> sub_state;
        std::string prefix = mod_name + ".";
        for (const auto& [key, tensor] : state) {
            if (key.find(prefix) == 0) {
                sub_state[key.substr(prefix.size())] = tensor;
            }
        }
        if (!sub_state.empty()) {
            modules_[mod_name]->load_state_dict(sub_state);
        }
    }
}

} // namespace nn
} // namespace rootseed