// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// activation.h — Activation Functions: ReLU, GELU, SiLU, Tanh, Sigmoid
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"

#include <string>
#include <functional>

namespace rootseed {
namespace nn {

// ============================================================================
// Activation — base class for activation functions (no learnable parameters)
// ============================================================================

class Activation : public Module {
public:
    explicit Activation(const std::string& name = "Activation");
    core::Tensor forward(const core::Tensor& input) override;

    /// Set the function used for forward computation.
    void set_forward_fn(std::function<float(float)> fn);

    /// Set the function used for backward (gradient) computation.
    void set_backward_fn(std::function<float(float, float)> grad_fn);

    // Override: activation functions don't have trainable parameters,
    // but forward still participates in autograd.
    std::vector<std::shared_ptr<Parameter>> parameters() { return {}; }

private:
    std::function<float(float)> forward_fn_;
    std::function<float(float, float)> backward_fn_;  // grad_output, input → grad_input
};

// ============================================================================
// Convenience factory functions for common activations
// ============================================================================

/// ReLU: f(x) = max(0, x)
std::shared_ptr<Activation> ReLU();

/// GELU: f(x) = x * Φ(x)  (Gaussian Error Linear Unit)
std::shared_ptr<Activation> GELU();

/// SiLU / Swish: f(x) = x * sigmoid(x)
std::shared_ptr<Activation> SiLU();

/// Tanh: f(x) = tanh(x)
std::shared_ptr<Activation> Tanh();

/// Sigmoid: f(x) = 1 / (1 + exp(-x))
std::shared_ptr<Activation> Sigmoid();

} // namespace nn
} // namespace rootseed