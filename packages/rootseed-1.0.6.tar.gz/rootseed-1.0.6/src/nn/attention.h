// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// attention.h — Multi-Head Attention with QKV Projection and Scaled Dot-Product
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "nn/parameter.h"
#include "nn/linear.h"

#include <memory>

namespace rootseed {
namespace nn {

// ============================================================================
// MultiHeadAttention — scaled dot-product attention with multiple heads
//
// Attention(Q, K, V) = softmax(Q @ K^T / sqrt(d_k)) @ V
//
// If qkv_proj is provided, Q, K, V are derived from a single input.
// Otherwise, separate Q, K, V inputs are used (cross-attention).
// ============================================================================

class MultiHeadAttention : public Module {
public:
    /// Create a multi-head attention layer.
    /// @param d_model     Total model dimension
    /// @param num_heads   Number of attention heads (d_model must be divisible)
    /// @param dropout     Dropout probability applied to attention weights
    /// @param bias        If true, include bias in QKV and output projections
    MultiHeadAttention(int64_t d_model, int64_t num_heads,
                       float dropout = 0.0f, bool bias = true,
                       const core::Device& device = core::Device{});

    /// Forward pass with a single input (self-attention).
    core::Tensor forward(const core::Tensor& input) override;

    /// Forward pass with separate Q, K, V (cross-attention).
    core::Tensor forward(const core::Tensor& query,
                         const core::Tensor& key,
                         const core::Tensor& value);

    // ---- Access ----
    int64_t d_model()   const noexcept { return d_model_; }
    int64_t num_heads() const noexcept { return num_heads_; }
    int64_t d_k()       const noexcept { return d_k_; }

private:
    int64_t d_model_;
    int64_t num_heads_;
    int64_t d_k_;         // d_model / num_heads
    float dropout_;

    // Projections
    std::shared_ptr<Linear> q_proj_;
    std::shared_ptr<Linear> k_proj_;
    std::shared_ptr<Linear> v_proj_;
    std::shared_ptr<Linear> out_proj_;
};

} // namespace nn
} // namespace rootseed