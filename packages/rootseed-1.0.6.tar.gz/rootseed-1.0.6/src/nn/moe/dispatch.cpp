// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dispatch.cpp — Sparse Dispatch: Gather/Scatter for Token-to-Expert Routing (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/moe/dispatch.h"

#include <algorithm>

namespace rootseed {
namespace nn {
namespace moe {

std::vector<std::vector<int64_t>> Dispatch::build_dispatch(
    const core::Tensor& router_indices, int64_t num_experts) {

    int64_t total_tokens = router_indices.shape()[0];
    int64_t top_k = router_indices.shape()[1];

    std::vector<std::vector<int64_t>> expert_tokens(num_experts);

    for (int64_t t = 0; t < total_tokens; ++t) {
        for (int64_t k = 0; k < top_k; ++k) {
            int64_t expert_idx = static_cast<int64_t>(router_indices.item(t, k));
            if (expert_idx >= 0 && expert_idx < num_experts) {
                expert_tokens[expert_idx].push_back(t);
            }
        }
    }

    return expert_tokens;
}

core::Tensor Dispatch::gather(const core::Tensor& input,
                               const std::vector<int64_t>& token_indices) {
    int64_t d_model = input.shape()[1];
    int64_t num_tokens = token_indices.size();

    core::Shape out_shape({num_tokens, d_model});
    core::Tensor output = core::Tensor::zeros(out_shape, input.dtype(), input.device());

    for (int64_t i = 0; i < num_tokens; ++i) {
        int64_t src_idx = token_indices[i];
        for (int64_t d = 0; d < d_model; ++d) {
            output.set_item(i, d, input.item(src_idx, d));
        }
    }

    return output;
}

void Dispatch::scatter_add(const core::Tensor& expert_output,
                            const std::vector<int64_t>& token_indices,
                            core::Tensor& output) {
    int64_t d_model = expert_output.shape()[1];
    int64_t num_tokens = token_indices.size();

    for (int64_t i = 0; i < num_tokens; ++i) {
        int64_t dst_idx = token_indices[i];
        for (int64_t d = 0; d < d_model; ++d) {
            float current = output.item(dst_idx, d);
            output.set_item(dst_idx, d, current + expert_output.item(i, d));
        }
    }
}

} // namespace moe
} // namespace nn
} // namespace rootseed