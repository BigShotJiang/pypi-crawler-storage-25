// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// moe_layer.cpp — MoE Layer: Router→Dispatch→Experts→Combine Forward Pass (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/moe/moe_layer.h"
#include "utils/log.h"

namespace rootseed {
namespace nn {
namespace moe {

MoELayer::MoELayer(int64_t d_model, int64_t num_experts, int64_t top_k,
                   int64_t d_ff, const std::string& activation,
                   float noise_std, const core::Device& device)
    : d_model_(d_model)
    , num_experts_(num_experts)
    , top_k_(top_k)
    , noise_std_(noise_std) {

    if (d_ff <= 0) d_ff = 4 * d_model;
    set_name("MoELayer");

    // Create router
    router_ = std::make_shared<Router>(d_model, num_experts, top_k, noise_std, device);
    register_module("router", router_);

    // Create experts
    for (int64_t i = 0; i < num_experts; ++i) {
        auto expert = std::make_shared<Expert>(d_model, d_ff, activation, device);
        experts_.push_back(expert);
        register_module("expert_" + std::to_string(i), expert);
    }

    RS_LOG_INFO("MoELayer created: " + std::to_string(num_experts) + " experts, top_k=" + std::to_string(top_k));
}

core::Tensor MoELayer::forward(const core::Tensor& input) {
    // input: (batch, seq, d_model)
    int64_t batch = input.shape()[0];
    int64_t seq   = input.shape()[1];
    int64_t total_tokens = batch * seq;

    // Step 1: Router — compute gating weights and expert assignments
    core::Tensor router_weights, router_indices;
    router_->route(input, router_weights, router_indices);

    // Step 2: Dispatch — build sparse token-to-expert mapping
    auto dispatch_lists = Dispatch::build_dispatch(router_indices, num_experts_);

    // Step 3: Experts — each expert processes its assigned tokens
    std::vector<core::Tensor> expert_outputs(num_experts_);
    for (int64_t e = 0; e < num_experts_; ++e) {
        if (dispatch_lists[e].empty()) {
            // No tokens assigned to this expert — output empty tensor
            core::Shape empty_shape({0, d_model_});
            expert_outputs[e] = core::Tensor::zeros(empty_shape, input.dtype(), input.device());
        } else {
            // Gather tokens for this expert
            core::Tensor expert_input = Dispatch::gather(input, dispatch_lists[e]);
            // Run expert FFN
            expert_outputs[e] = experts_[e]->forward(expert_input);
        }
    }

    // Step 4: Combine — weighted sum of expert outputs
    core::Tensor output = Combine::combine(
        expert_outputs, router_weights, router_indices,
        dispatch_lists, d_model_, input.device());

    return output;
}

std::shared_ptr<Expert> MoELayer::expert(int64_t idx) {
    if (idx >= 0 && idx < static_cast<int64_t>(experts_.size())) {
        return experts_[idx];
    }
    return nullptr;
}

} // namespace moe
} // namespace nn
} // namespace rootseed