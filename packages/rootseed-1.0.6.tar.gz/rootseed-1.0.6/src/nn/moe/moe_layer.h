// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// moe_layer.h — Complete Mixture of Experts Block: Router→Dispatch→Experts→Combine (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "nn/moe/router.h"
#include "nn/moe/expert.h"
#include "nn/moe/dispatch.h"
#include "nn/moe/combine.h"

#include <vector>
#include <memory>

namespace rootseed {
namespace nn {
namespace moe {

// ============================================================================
// MoELayer — complete Mixture of Experts block
//
// Architecture:
//   x → Router (Top-K gating with Aleam noise)
//     → Dispatch (tokens → experts)
//     → Experts (FFN per expert, in parallel)
//     → Combine (weighted sum of expert outputs)
//
// Section 4.2: Fused kernel pattern "Router→Dispatch→Experts→Combine"
// achieves 4.0x speedup and 70% memory reduction.
// ============================================================================

class MoELayer : public Module {
public:
    /// Create a Mixture of Experts layer.
    /// @param d_model       Input/output dimension
    /// @param num_experts   Total number of expert FFNs
    /// @param top_k         Number of experts per token
    /// @param d_ff          Expert hidden dimension (default: 4 * d_model)
    /// @param activation    Expert activation function
    /// @param noise_std     Load-balancing noise standard deviation
    MoELayer(int64_t d_model, int64_t num_experts, int64_t top_k = 2,
             int64_t d_ff = -1,
             const std::string& activation = "gelu",
             float noise_std = 0.01f,
             const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

    // ---- Access ----
    std::shared_ptr<Router> router() { return router_; }
    std::shared_ptr<Expert> expert(int64_t idx);

    int64_t num_experts() const noexcept { return num_experts_; }
    int64_t top_k()       const noexcept { return top_k_; }

private:
    int64_t d_model_;
    int64_t num_experts_;
    int64_t top_k_;
    float noise_std_;

    std::shared_ptr<Router> router_;
    std::vector<std::shared_ptr<Expert>> experts_;
};

} // namespace moe
} // namespace nn
} // namespace rootseed