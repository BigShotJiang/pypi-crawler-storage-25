// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dispatch.h — Sparse Token-to-Expert Dispatch (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

#include <vector>
#include <cstdint>

namespace rootseed {
namespace nn {
namespace moe {

// ============================================================================
// Dispatch — routes tokens to their assigned experts
//
// Builds a sparse index mapping:
//   expert → [list of token indices assigned to that expert]
//
// This enables efficient batched expert computation:
//   - Tokens for each expert are gathered into a contiguous buffer
//   - Expert FFN processes the buffer in one forward pass
//   - Outputs are scattered back to original token positions
// ============================================================================

class Dispatch {
public:
    /// Build dispatch mapping from router indices.
    /// @param router_indices  (total_tokens, top_k) — expert index per token
    /// @param num_experts     Total number of experts
    /// @return                Vector of expert→token index mappings
    static std::vector<std::vector<int64_t>> build_dispatch(
        const core::Tensor& router_indices, int64_t num_experts);

    /// Gather token embeddings for a specific expert.
    /// @param input          (total_tokens, d_model) — all token embeddings
    /// @param token_indices  List of token indices assigned to this expert
    /// @return               (num_tokens_for_expert, d_model)
    static core::Tensor gather(const core::Tensor& input,
                                const std::vector<int64_t>& token_indices);

    /// Scatter expert outputs back to original token positions.
    /// @param expert_output  (num_tokens, d_model) — expert's output
    /// @param token_indices  List of token indices to scatter to
    /// @param output         (total_tokens, d_model) — full output buffer (modified in-place)
    static void scatter_add(const core::Tensor& expert_output,
                             const std::vector<int64_t>& token_indices,
                             core::Tensor& output);
};

} // namespace moe
} // namespace nn
} // namespace rootseed