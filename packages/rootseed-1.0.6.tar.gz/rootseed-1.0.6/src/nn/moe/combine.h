// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// combine.h — Weighted Combination of Expert Outputs: y = sum_i G_i(x) * E_i(x) (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

#include <vector>

namespace rootseed {
namespace nn {
namespace moe {

// ============================================================================
// Combine — blends expert outputs using router weights
//
// Equation:
//   y = Σᵢ G_i(x) · E_i(x)
//
// Where:
//   - G_i(x) are the router weights (softmax over top-k)
//   - E_i(x) are the expert outputs
//   - The sum is over the k selected experts per token
// ============================================================================

class Combine {
public:
    /// Combine expert outputs using router weights.
    /// @param expert_outputs  Vector of (num_tokens_for_expert, d_model) per expert
    /// @param router_weights  (total_tokens, top_k) — routing weights
    /// @param router_indices  (total_tokens, top_k) — expert indices
    /// @param dispatch_lists  expert → [token indices] mapping
    /// @param d_model         Model dimension
    /// @return                (total_tokens, d_model) combined output
    static core::Tensor combine(
        const std::vector<core::Tensor>& expert_outputs,
        const core::Tensor& router_weights,
        const core::Tensor& router_indices,
        const std::vector<std::vector<int64_t>>& dispatch_lists,
        int64_t d_model,
        const core::Device& device);
};

} // namespace moe
} // namespace nn
} // namespace rootseed