// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// combine.cpp — Weighted Expert Output Blending Implementation (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/moe/combine.h"

namespace rootseed {
namespace nn {
namespace moe {

core::Tensor Combine::combine(
    const std::vector<core::Tensor>& expert_outputs,
    const core::Tensor& router_weights,
    const core::Tensor& router_indices,
    const std::vector<std::vector<int64_t>>& dispatch_lists,
    int64_t d_model,
    const core::Device& device) {

    int64_t total_tokens = router_weights.shape()[0];
    int64_t top_k = router_weights.shape()[1];
    int64_t num_experts = expert_outputs.size();

    core::Shape out_shape({total_tokens, d_model});
    core::Tensor output = core::Tensor::zeros(out_shape, core::DType::Float32, device);

    // For each expert, its output tokens are in dispatch order
    // We need to map back: expert_output[expert][local_idx] → output[global_token_idx]

    // Build position tracker per expert
    std::vector<int64_t> expert_pos(num_experts, 0);

    for (int64_t t = 0; t < total_tokens; ++t) {
        for (int64_t k = 0; k < top_k; ++k) {
            int64_t expert_idx = static_cast<int64_t>(router_indices.item(t, k));
            float weight = router_weights.item(t, k);

            if (expert_idx < 0 || expert_idx >= num_experts) continue;

            int64_t local_idx = expert_pos[expert_idx];
            expert_pos[expert_idx]++;

            if (local_idx >= static_cast<int64_t>(dispatch_lists[expert_idx].size())) continue;

            // Accumulate weighted expert output
            const auto& exp_out = expert_outputs[expert_idx];
            for (int64_t d = 0; d < d_model; ++d) {
                float current = output.item(t, d);
                float contribution = exp_out.item(local_idx, d) * weight;
                output.set_item(t, d, current + contribution);
            }
        }
    }

    return output;
}

} // namespace moe
} // namespace nn
} // namespace rootseed