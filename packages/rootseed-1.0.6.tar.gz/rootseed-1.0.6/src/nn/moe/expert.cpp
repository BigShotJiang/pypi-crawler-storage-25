// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// expert.cpp — Expert FFN Implementation (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/moe/expert.h"

namespace rootseed {
namespace nn {
namespace moe {

Expert::Expert(int64_t d_model, int64_t d_ff,
               const std::string& activation,
               const core::Device& device)
    : d_model_(d_model)
    , d_ff_(d_ff > 0 ? d_ff : 4 * d_model) {

    set_name("Expert");

    linear1_ = std::make_shared<Linear>(d_model_, d_ff_, true, device);
    linear2_ = std::make_shared<Linear>(d_ff_, d_model_, true, device);

    if (activation == "gelu") {
        activation_ = GELU();
    } else if (activation == "relu") {
        activation_ = ReLU();
    } else if (activation == "silu") {
        activation_ = SiLU();
    } else {
        activation_ = GELU();
    }

    register_module("linear1", linear1_);
    register_module("linear2", linear2_);
}

core::Tensor Expert::forward(const core::Tensor& input) {
    core::Tensor x = linear1_->forward(input);
    x = activation_->forward(x);
    x = linear2_->forward(x);
    return x;
}

} // namespace moe
} // namespace nn
} // namespace rootseed