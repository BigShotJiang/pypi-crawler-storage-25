// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// expert.h — Expert FFN: Linear → Activation → Linear (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "nn/linear.h"
#include "nn/activation.h"

#include <memory>

namespace rootseed {
namespace nn {
namespace moe {

// ============================================================================
// Expert — a single feed-forward network in the Mixture of Experts
//
// Architecture:
//   x → Linear(d_model, d_ff) → Activation → Linear(d_ff, d_model)
//
// Each expert is a standard FFN. Multiple experts form the MoE layer.
// During training, each token is routed to top-k experts.
// ============================================================================

class Expert : public Module {
public:
    /// @param d_model     Input/output dimension
    /// @param d_ff        Hidden dimension (feed-forward)
    /// @param activation  "gelu", "relu", or "silu"
    Expert(int64_t d_model, int64_t d_ff = -1,
           const std::string& activation = "gelu",
           const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

    int64_t d_model() const noexcept { return d_model_; }
    int64_t d_ff()    const noexcept { return d_ff_; }

private:
    int64_t d_model_;
    int64_t d_ff_;

    std::shared_ptr<Linear> linear1_;
    std::shared_ptr<Linear> linear2_;
    std::shared_ptr<Activation> activation_;
};

} // namespace moe
} // namespace nn
} // namespace rootseed