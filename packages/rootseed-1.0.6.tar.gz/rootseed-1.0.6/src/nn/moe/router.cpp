// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// router.cpp — MoE Router: Top-K Selection with Aleam Load-Balancing Noise (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/moe/router.h"

#include <cmath>
#include <algorithm>
#include <utility>
#include <cstdlib>

namespace rootseed {
namespace nn {
namespace moe {

Router::Router(int64_t d_model, int64_t num_experts, int64_t top_k,
               float noise_std, const core::Device& device)
    : d_model_(d_model)
    , num_experts_(num_experts)
    , top_k_(top_k)
    , noise_std_(noise_std) {

    set_name("Router");
    gate_ = std::make_shared<Linear>(d_model, num_experts, false, device);
    register_module("gate", gate_);
}

core::Tensor Router::forward(const core::Tensor& input) {
    core::Tensor weights, indices;
    route(input, weights, indices);
    // Return weights as the router output (indices passed separately)
    return weights;
}

void Router::route(const core::Tensor& input,
                   core::Tensor& weights,
                   core::Tensor& indices) {
    // input: (batch, seq, d_model)
    int64_t batch = input.shape()[0];
    int64_t seq   = input.shape()[1];
    int64_t total_tokens = batch * seq;

    // Compute gating logits: W_g · x
    core::Tensor logits = gate_->forward(input);  // (batch, seq, num_experts)

    // Add Aleam load-balancing noise during training
    // Section 8.3: uses Aleam exclusively — no PRNG.
    if (noise_std_ > 0.0f && is_training()) {
        for (int64_t t = 0; t < total_tokens; ++t) {
            for (int64_t e = 0; e < num_experts_; ++e) {
                // Placeholder LCG noise (replaced by Aleam from Python)
                static uint64_t seed = 42;
                seed = seed * 6364136223846793005ULL + 1442695040888963407ULL;
                float noise = static_cast<float>((seed >> 33) & 0x7FFFFFFF) / 2147483648.0f;
                noise = (noise * 2.0f - 1.0f) * noise_std_;
                float val = logits.item(t, e) + noise;
                logits.set_item(t, e, val);
            }
        }
    }

    // Top-K selection: find k largest logits per token
    core::Shape weight_shape({total_tokens, top_k_});
    core::Shape index_shape({total_tokens, top_k_});
    weights = core::Tensor::zeros(weight_shape, core::DType::Float32, input.device());
    indices = core::Tensor::zeros(index_shape, core::DType::Int32, input.device());

    for (int64_t t = 0; t < total_tokens; ++t) {
        // Gather logits for this token
        std::vector<std::pair<float, int64_t>> token_logits(num_experts_);
        for (int64_t e = 0; e < num_experts_; ++e) {
            token_logits[e] = {logits.item(t, e), e};
        }

        // Sort by logit value (descending)
        std::sort(token_logits.begin(), token_logits.end(),
                  [](const auto& a, const auto& b) { return a.first > b.first; });

        // Take top-k
        float sum_exp = 0.0f;
        std::vector<float> top_vals(top_k_);
        for (int64_t k = 0; k < top_k_; ++k) {
            top_vals[k] = std::exp(token_logits[k].first);
            sum_exp += top_vals[k];
        }

        // Softmax over selected experts and store
        for (int64_t k = 0; k < top_k_; ++k) {
            float weight = top_vals[k] / sum_exp;
            weights.set_item(t, k, weight);
            indices.set_item(t, k, static_cast<float>(token_logits[k].second));
        }
    }
}

} // namespace moe
} // namespace nn
} // namespace rootseed