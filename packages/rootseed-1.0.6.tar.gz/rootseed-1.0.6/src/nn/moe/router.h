// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// router.h — Mixture of Experts Router: G(x) = Softmax(TopK(W_g · x)) (Section 6.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/module.h"
#include "nn/linear.h"
#include "nn/parameter.h"

#include <vector>
#include <memory>

namespace rootseed {
namespace nn {
namespace moe {

// ============================================================================
// Router — gating network that routes tokens to experts
//
// Equation (Section 6.2):
//   G(x) = Softmax( TopK( W_g · x + noise, k ) )
//
// Where:
//   - W_g is the gating weight matrix (d_model × num_experts)
//   - noise is Aleam true random load-balancing noise
//   - k is the number of experts selected per token
// ============================================================================

class Router : public Module {
public:
    /// @param d_model       Input dimension
    /// @param num_experts   Total number of experts
    /// @param top_k         Number of experts to route each token to
    /// @param noise_std     Standard deviation of load-balancing noise (0 = disabled)
    Router(int64_t d_model, int64_t num_experts, int64_t top_k = 2,
           float noise_std = 0.01f, const core::Device& device = core::Device{});

    core::Tensor forward(const core::Tensor& input) override;

    /// Returns the routing weights (post-softmax) and expert indices for each token.
    /// @param input   Input tensor: (batch, seq, d_model)
    /// @param weights Output: routing weights (batch*seq, top_k)
    /// @param indices Output: expert indices (batch*seq, top_k)
    void route(const core::Tensor& input,
               core::Tensor& weights,
               core::Tensor& indices);

    int64_t num_experts() const noexcept { return num_experts_; }
    int64_t top_k()       const noexcept { return top_k_; }

private:
    int64_t d_model_;
    int64_t num_experts_;
    int64_t top_k_;
    float noise_std_;

    std::shared_ptr<Linear> gate_;  // W_g: d_model → num_experts
};

} // namespace moe
} // namespace nn
} // namespace rootseed