// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// linear.cpp — Linear Layer Implementation: y = x @ W^T + b (Section 6.1)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "nn/linear.h"
#include "autograd/tape.h"
#include "autograd/functions.h"

namespace rootseed {
namespace nn {

Linear::Linear(int64_t in_features, int64_t out_features, bool bias, const core::Device& device)
    : in_features_(in_features)
    , out_features_(out_features)
    , has_bias_(bias) {

    set_name("Linear");

    // Weight: (out_features, in_features)
    core::Shape weight_shape({out_features, in_features});
    auto W = Parameter::kaiming_uniform(weight_shape, in_features, core::DType::Float32, device);
    register_parameter("weight", W);

    // Bias: (out_features,)
    if (has_bias_) {
        core::Shape bias_shape({out_features});
        auto b = Parameter::zeros(bias_shape, core::DType::Float32, device);
        register_parameter("bias", b);
    }
}

core::Tensor Linear::forward(const core::Tensor& input) {
    // y = x @ W^T + b

    // Get weight and transpose for matmul
    auto& W_param = get_parameter("weight")->data();
    const core::Tensor& weight = W_param;
    core::Tensor W_T = weight.transpose();  // (in_features, out_features)

    // x: (batch, in_features) @ W_T: (in_features, out_features) → (batch, out_features)
    core::Tensor output = input.matmul(W_T);

    // Add bias
    if (has_bias_) {
        auto& b_param = get_parameter("bias")->data();
        const core::Tensor& bias = b_param;
        output = output.add(bias);
    }

    // Gradient tracking is handled by the autograd tape system (Module E).
    // The GradientTape records operations when requires_grad is true.
    // Full autograd graph construction is deferred to the Python-facing API.

    return output;
}

} // namespace nn
} // namespace rootseed