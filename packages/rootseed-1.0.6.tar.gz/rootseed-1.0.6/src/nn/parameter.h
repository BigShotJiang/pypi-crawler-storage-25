// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// parameter.h — Trainable Parameter: Tensor with Gradient Tracking (Section 5)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

#include <string>
#include <memory>

namespace rootseed {
namespace nn {

// ============================================================================
// Parameter — a Tensor that is registered as a trainable model parameter.
// ============================================================================

class Parameter {
public:
    Parameter(const core::Shape& shape, core::DType dtype = core::DType::Float32,
              const core::Device& device = core::Device{});

    explicit Parameter(const core::Tensor& tensor);

    static std::shared_ptr<Parameter> zeros(const core::Shape& shape,
                                              core::DType dtype = core::DType::Float32,
                                              const core::Device& device = core::Device{});

    static std::shared_ptr<Parameter> kaiming_uniform(const core::Shape& shape,
                                                        int64_t fan_in,
                                                        core::DType dtype = core::DType::Float32,
                                                        const core::Device& device = core::Device{});

    // ---- Access ----
    core::Tensor& data() noexcept { return tensor_; }
    const core::Tensor& data() const noexcept { return tensor_; }

    const core::Shape& shape() const noexcept { return tensor_.shape(); }
    core::DType dtype() const noexcept { return tensor_.dtype(); }
    core::Device device() const noexcept { return tensor_.device(); }

    /// Non-const gradient access (for optimizer updates).
    core::Tensor& grad() {
        if (!grad_) grad_ = std::make_shared<core::Tensor>();
        return *grad_;
    }

    /// Const gradient access.
    const core::Tensor& grad() const {
        if (!grad_) {
            static core::Tensor empty;
            return empty;
        }
        return *grad_;
    }

    bool requires_grad() const noexcept { return tensor_.requires_grad(); }
    void set_requires_grad(bool req) { tensor_.set_requires_grad(req); }

    void set_name(const std::string& name) { name_ = name; }
    const std::string& name() const noexcept { return name_; }

private:
    core::Tensor tensor_;
    std::shared_ptr<core::Tensor> grad_;  // Separate gradient storage
    std::string name_;
};

} // namespace nn
} // namespace rootseed