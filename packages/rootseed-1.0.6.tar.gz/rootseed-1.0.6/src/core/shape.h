// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// shape.h — Tensor Shape and Strides with Small-Vector Optimization (Section 2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <cstddef>
#include <cstdint>
#include <array>
#include <vector>
#include <initializer_list>
#include <string>
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <numeric>

namespace rootseed {
namespace core {

// ============================================================================
// Section 2: Shape — tensor dimensions with small-vector optimization
// ============================================================================
//
// Most tensors have ≤8 dimensions. We store up to 8 dims inline (no heap
// allocation) and fall back to std::vector for higher-dimensional tensors.
// This is part of the hardware-aware memory hierarchy optimization (Section 2.3)
// keeping small dimension metadata in L1 cache.
// ============================================================================

class Shape {
public:
    static constexpr size_t kSmallVectorSize = 8;

    // ---- Constructors ----
    Shape() : dims_{}, ndim_(0), is_small_(true) {}

    Shape(std::initializer_list<int64_t> il) {
        ndim_ = il.size();
        if (ndim_ <= kSmallVectorSize) {
            is_small_ = true;
            std::copy(il.begin(), il.end(), dims_.begin());
        } else {
            is_small_ = false;
            large_dims_ = std::vector<int64_t>(il);
        }
    }

    explicit Shape(const std::vector<int64_t>& dims) {
        ndim_ = dims.size();
        if (ndim_ <= kSmallVectorSize) {
            is_small_ = true;
            std::copy(dims.begin(), dims.end(), dims_.begin());
        } else {
            is_small_ = false;
            large_dims_ = dims;
        }
    }

    // ---- Access ----
    size_t ndim() const noexcept { return ndim_; }

    int64_t operator[](size_t i) const {
        if (i >= ndim_) throw std::out_of_range("Shape index out of range");
        return is_small_ ? dims_[i] : large_dims_[i];
    }

    int64_t& operator[](size_t i) {
        if (i >= ndim_) throw std::out_of_range("Shape index out of range");
        return is_small_ ? dims_[i] : large_dims_[i];
    }

    /// Total number of elements (product of all dimensions).
    int64_t numel() const noexcept {
        if (ndim_ == 0) return 0;
        int64_t n = 1;
        for (size_t i = 0; i < ndim_; ++i) {
            n *= (*this)[i];
        }
        return n;
    }

    /// Iterator support for range-based loops.
    const int64_t* begin() const { return is_small_ ? dims_.data() : large_dims_.data(); }
    const int64_t* end()   const { return begin() + ndim_; }

    // ---- Comparison ----
    bool operator==(const Shape& other) const noexcept {
        if (ndim_ != other.ndim_) return false;
        for (size_t i = 0; i < ndim_; ++i) {
            if ((*this)[i] != other[i]) return false;
        }
        return true;
    }
    bool operator!=(const Shape& other) const noexcept { return !(*this == other); }

    // ---- String representation ----
    std::string to_string() const {
        std::ostringstream oss;
        oss << "(";
        for (size_t i = 0; i < ndim_; ++i) {
            if (i > 0) oss << ", ";
            oss << (*this)[i];
        }
        oss << ")";
        return oss.str();
    }

private:
    std::array<int64_t, kSmallVectorSize> dims_;   // Inline storage for ≤8 dims
    std::vector<int64_t> large_dims_;               // Heap storage for >8 dims
    size_t ndim_;
    bool is_small_;
};

// ============================================================================
// Strides — describes memory layout of a tensor
// ============================================================================

class Strides {
public:
    Strides() : strides_{}, ndim_(0), is_small_(true) {}

    explicit Strides(const Shape& shape, bool row_major = true) {
        ndim_ = shape.ndim();
        if (ndim_ == 0) {
            is_small_ = true;
            return;
        }
        is_small_ = (ndim_ <= Shape::kSmallVectorSize);

        int64_t stride = 1;
        if (row_major) {
            // Row-major: last dimension has stride 1
            for (int64_t i = static_cast<int64_t>(ndim_) - 1; i >= 0; --i) {
                set(i, stride);
                stride *= shape[i];
            }
        } else {
            // Column-major: first dimension has stride 1
            for (size_t i = 0; i < ndim_; ++i) {
                set(i, stride);
                stride *= shape[i];
            }
        }
    }

    size_t ndim() const noexcept { return ndim_; }

    int64_t operator[](size_t i) const {
        if (i >= ndim_) throw std::out_of_range("Strides index out of range");
        return is_small_ ? strides_[i] : large_strides_[i];
    }

    /// Returns true if the layout is contiguous (row-major dense).
    bool is_contiguous(const Shape& shape) const noexcept {
        if (ndim_ == 0) return true;
        int64_t expected = 1;
        for (int64_t i = static_cast<int64_t>(ndim_) - 1; i >= 0; --i) {
            if ((*this)[i] != expected) return false;
            expected *= shape[i];
        }
        return true;
    }

private:
    void set(size_t i, int64_t stride) {
        if (is_small_) {
            strides_[i] = stride;
        } else {
            large_strides_[i] = stride;
        }
    }

    std::array<int64_t, Shape::kSmallVectorSize> strides_;
    std::vector<int64_t> large_strides_;
    size_t ndim_;
    bool is_small_;
};

// ============================================================================
// Broadcasting utilities
// ============================================================================

/// Returns true if two shapes are broadcastable.
inline bool broadcastable(const Shape& a, const Shape& b) {
    size_t ndim = std::max(a.ndim(), b.ndim());
    for (size_t i = 0; i < ndim; ++i) {
        int64_t da = (i < a.ndim()) ? a[a.ndim() - 1 - i] : 1;
        int64_t db = (i < b.ndim()) ? b[b.ndim() - 1 - i] : 1;
        if (da != db && da != 1 && db != 1) {
            return false;
        }
    }
    return true;
}

/// Returns the resulting Shape from broadcasting two shapes together.
/// Throws std::invalid_argument if not broadcastable.
inline Shape broadcast_shape(const Shape& a, const Shape& b) {
    if (!broadcastable(a, b)) {
        throw std::invalid_argument(
            "Cannot broadcast shapes " + a.to_string() + " and " + b.to_string());
    }

    size_t ndim = std::max(a.ndim(), b.ndim());
    std::vector<int64_t> result(ndim);
    for (size_t i = 0; i < ndim; ++i) {
        int64_t da = (i < a.ndim()) ? a[a.ndim() - 1 - i] : 1;
        int64_t db = (i < b.ndim()) ? b[b.ndim() - 1 - i] : 1;
        result[ndim - 1 - i] = std::max(da, db);
    }
    return Shape(result);
}

} // namespace core
} // namespace rootseed