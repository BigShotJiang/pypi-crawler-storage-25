// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dtype.h — Core Data Type Enumeration and Compile-Time Properties (Section 6)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <stdexcept>
#include <array>

namespace rootseed {
namespace core {

// ============================================================================
// Section 6: Data Type System
// All primitive types supported by Root-Seed tensors.
// ============================================================================

enum class DType : uint8_t {
    // Floating point
    Float32 = 0,
    Float64 = 1,
    Float16 = 2,
    BFloat16 = 3,
    Float8  = 4,   // FP8 (E4M3 or E5M2 — determined by context)

    // Signed integers
    Int8  = 10,
    Int16 = 11,
    Int32 = 12,
    Int64 = 13,

    // Unsigned integers
    UInt8  = 20,
    // UInt16 = 21,  // Reserved
    // UInt32 = 22,
    // UInt64 = 23,

    // Special
    Bool  = 30,
    Index = 31,     // Platform-native size type (int64 on 64-bit)
};

// ============================================================================
// Compile-time dtype properties
// ============================================================================

/// Returns the size in bytes for a given DType.
constexpr size_t dtype_size(DType dtype) noexcept {
    switch (dtype) {
        case DType::Float32:  return 4;
        case DType::Float64:  return 8;
        case DType::Float16:  return 2;
        case DType::BFloat16: return 2;
        case DType::Float8:   return 1;
        case DType::Int8:     return 1;
        case DType::Int16:    return 2;
        case DType::Int32:    return 4;
        case DType::Int64:    return 8;
        case DType::UInt8:    return 1;
        case DType::Bool:     return 1;
        case DType::Index:    return sizeof(int64_t);
    }
    return 0;  // Unreachable — all cases covered
}

/// True if the dtype represents a floating-point type.
constexpr bool is_floating(DType dtype) noexcept {
    switch (dtype) {
        case DType::Float32:
        case DType::Float64:
        case DType::Float16:
        case DType::BFloat16:
        case DType::Float8:
            return true;
        default:
            return false;
    }
}

/// True if the dtype is a signed integer type.
constexpr bool is_signed(DType dtype) noexcept {
    switch (dtype) {
        case DType::Int8:
        case DType::Int16:
        case DType::Int32:
        case DType::Int64:
            return true;
        default:
            return false;
    }
}

/// True if the dtype is an unsigned integer type.
constexpr bool is_unsigned(DType dtype) noexcept {
    switch (dtype) {
        case DType::UInt8:
            return true;
        default:
            return false;
    }
}

/// True if the dtype is an integral type (signed or unsigned or index).
constexpr bool is_integral(DType dtype) noexcept {
    return is_signed(dtype) || is_unsigned(dtype) || dtype == DType::Index;
}

/// True if the dtype is Bool.
constexpr bool is_boolean(DType dtype) noexcept {
    return dtype == DType::Bool;
}

// ============================================================================
// Promotion rules
// ============================================================================

/// Returns the "larger" of two dtypes for mixed-type operations.
/// Rule precedence: Float64 > Float32 > Float16 > BFloat16 > Float8
///                  > Int64 > Index > Int32 > Int16 > Int8 > UInt8 > Bool
constexpr DType promote_types(DType a, DType b) noexcept {
    // Give each dtype a numeric rank; higher = wider type
    auto rank = [](DType t) -> int {
        switch (t) {
            case DType::Bool:     return 0;
            case DType::UInt8:    return 1;
            case DType::Int8:     return 2;
            case DType::Int16:    return 3;
            case DType::Int32:    return 4;
            case DType::Index:    return 5;
            case DType::Int64:    return 6;
            case DType::Float8:   return 7;
            case DType::BFloat16: return 8;
            case DType::Float16:  return 9;
            case DType::Float32:  return 10;
            case DType::Float64:  return 11;
        }
        return -1;
    };
    return (rank(a) >= rank(b)) ? a : b;
}

// ============================================================================
// Runtime queries (implemented in .cpp)
// ============================================================================

/// Parse a DType from its string representation.
/// e.g., "float32" -> DType::Float32, "fp16" -> DType::Float16
DType dtype_from_string(std::string_view name);

/// Human-readable name of a DType.
std::string_view dtype_name(DType dtype) noexcept;

} // namespace core
} // namespace rootseed