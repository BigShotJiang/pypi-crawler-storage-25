// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// tensor.h — Tensor Class with Dense and Sparse Storage (Section 6.1)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/dtype.h"
#include "core/shape.h"
#include "core/memory.h"
#include "hal/device.h"

#include <memory>
#include <vector>
#include <string>
#include <stdexcept>
#include <cstring>
#include <functional>

namespace rootseed {
namespace core {

// Forward declarations
class Tensor;
class GradientTape;

// ============================================================================
// TensorStorage — base for dense (strided) tensor data
// ============================================================================

struct TensorStorage {
    void* data = nullptr;           // Raw data pointer (device-specific)
    size_t size_bytes = 0;          // Total allocated bytes
    Device device;                  // Device where data resides
    DType dtype = DType::Float32;
    bool owns_data = true;          // True if this storage is responsible for freeing data

    ~TensorStorage();
    TensorStorage() = default;
    TensorStorage(const TensorStorage&) = delete;
    TensorStorage& operator=(const TensorStorage&) = delete;
    TensorStorage(TensorStorage&& other) noexcept;
    TensorStorage& operator=(TensorStorage&& other) noexcept;

    /// Allocate storage for the given number of bytes.
    void allocate(size_t bytes, AllocFlags flags = AllocFlags::None);

    /// Free allocated storage.
    void release();
};

// ============================================================================
// Sparse Storage Formats (Section 2.2)
// ============================================================================

struct CSRStorage {
    std::vector<int64_t> row_ptr;    // Row pointers (size = num_rows + 1)
    std::vector<int64_t> col_idx;    // Column indices (size = nnz)
    std::vector<float>   values;     // Non-zero values (size = nnz)
    int64_t num_rows = 0;
    int64_t num_cols = 0;
    int64_t nnz = 0;
    bool is_empty() const noexcept { return nnz == 0; }
};

struct COOStorage {
    std::vector<int64_t> row_idx;    // Row indices (size = nnz)
    std::vector<int64_t> col_idx;    // Column indices (size = nnz)
    std::vector<float>   values;     // Non-zero values (size = nnz)
    int64_t num_rows = 0;
    int64_t num_cols = 0;
    int64_t nnz = 0;
};

// ============================================================================
// Tensor — the fundamental data structure of Root-Seed
//
// A Tensor wraps a multi-dimensional array (dense or sparse) with
// optional gradient tracking for automatic differentiation.
//
// Equation (Section 6.1):
//   Dense:  y = W · x + b
//   Sparse: y_j = Σ_{i ∈ nonzero(j)} W_ij · x_i + b_j
// ============================================================================

class Tensor {
public:
    // ---- Constructors ----
    Tensor();
    Tensor(const Shape& shape, DType dtype = DType::Float32, const Device& device = Device{});

    /// Create a dense tensor from a flat list of floats.
    static Tensor from_vector(const std::vector<float>& data, const Shape& shape,
                               DType dtype = DType::Float32, const Device& device = Device{});

    /// Create a tensor filled with zeros.
    static Tensor zeros(const Shape& shape, DType dtype = DType::Float32, const Device& device = Device{});

    /// Create a tensor filled with ones.
    static Tensor ones(const Shape& shape, DType dtype = DType::Float32, const Device& device = Device{});

    /// Create a sparse CSR tensor.
    static Tensor csr(const CSRStorage& csr, const Shape& shape,
                       DType dtype = DType::Float32, const Device& device = Device{});

    /// Create a sparse COO tensor.
    static Tensor coo(const COOStorage& coo, const Shape& shape,
                       DType dtype = DType::Float32, const Device& device = Device{});

    ~Tensor();

    // Move semantics
    Tensor(Tensor&& other) noexcept;
    Tensor& operator=(Tensor&& other) noexcept;
    Tensor(const Tensor& other);
    Tensor& operator=(const Tensor& other);

    // ---- Properties ----
    const Shape& shape() const noexcept { return shape_; }
    const Strides& strides() const noexcept { return strides_; }
    DType dtype() const noexcept { return dtype_; }
    Device device() const noexcept { return storage_ ? storage_->device : Device{}; }
    size_t ndim() const noexcept { return shape_.ndim(); }
    int64_t numel() const noexcept { return shape_.numel(); }
    size_t nbytes() const noexcept { return storage_ ? storage_->size_bytes : 0; }
    bool is_contiguous() const noexcept { return strides_.is_contiguous(shape_); }

    /// Raw data pointer (valid for dense tensors only).
    void* data_ptr() { return storage_ ? storage_->data : nullptr; }
    const void* data_ptr() const { return storage_ ? storage_->data : nullptr; }

    /// Access a single element (float32 dense only, for debugging).
    float item(int64_t index) const;
    float item(int64_t row, int64_t col) const;

    /// Set a single element (float32 dense only).
    void set_item(int64_t index, float value);
    void set_item(int64_t row, int64_t col, float value);

    // ---- Sparsity ----
    bool is_sparse() const noexcept { return is_sparse_; }
    int64_t nnz() const noexcept { return csr_data_ ? csr_data_->nnz : 0; }
    const CSRStorage* csr() const { return csr_data_.get(); }
    const COOStorage* coo() const { return coo_data_.get(); }

    // ---- Gradient Tracking ----
    bool requires_grad() const noexcept { return requires_grad_; }
    void set_requires_grad(bool req) { requires_grad_ = req; }
    const Tensor& grad() const;
    void set_grad(const Tensor& g);

    /// Backward pass: computes gradients of this tensor w.r.t. graph leaves.
    void backward();

    // ---- Operations (Section 6.1) ----
    /// Matrix multiplication: y = W · x
    Tensor matmul(const Tensor& other) const;

    /// Element-wise addition with broadcasting: y = x + b
    Tensor add(const Tensor& other) const;

    /// Subtract: y = x - other
    Tensor sub(const Tensor& other) const;

    /// Element-wise multiplication: y = x ⊙ other
    Tensor mul(const Tensor& other) const;

    /// Multiply by scalar: y = x * scalar
    Tensor mul(float scalar) const;

    /// Element-wise division: y = x / other
    Tensor div(const Tensor& other) const;

    /// Transpose (last two dimensions): y = x^T
    Tensor transpose(int dim0 = -1, int dim1 = -1) const;

    /// Reshape to new dimensions.
    Tensor reshape(const Shape& new_shape) const;

    /// Cast to a different dtype.
    Tensor cast(DType new_dtype) const;

    // ---- Operators ----
    Tensor operator+(const Tensor& other) const { return add(other); }
    Tensor operator-(const Tensor& other) const { return sub(other); }
    Tensor operator*(const Tensor& other) const { return mul(other); }
    Tensor operator*(float scalar) const { return mul(scalar); }
    Tensor operator/(const Tensor& other) const { return div(other); }

    // ---- Device Transfer ----
    /// Move tensor to a different device.
    Tensor to(const Device& device) const;

    /// Move tensor to CPU.
    Tensor cpu() const;

    /// Move tensor to default GPU (if available).
    Tensor cuda() const;

    // ---- Serialization ----
    std::string to_string() const;

private:
    friend class GradientTape;

    Shape shape_;
    Strides strides_;
    DType dtype_ = DType::Float32;
    std::shared_ptr<TensorStorage> storage_;  // Shared for efficient copy semantics

    // Sparse storage (if is_sparse_)
    bool is_sparse_ = false;
    std::shared_ptr<CSRStorage> csr_data_;
    std::shared_ptr<COOStorage> coo_data_;

    // Gradient tracking
    bool requires_grad_ = false;
    std::shared_ptr<Tensor> grad_;  // Gradient accumulator

    // Computation graph (for autograd)
    struct GraphNode;
    std::shared_ptr<GraphNode> graph_node_;

    // ---- Internal helpers ----
    void allocate_storage();
    Tensor dense_matmul(const Tensor& other) const;
    Tensor sparse_matmul(const Tensor& other) const;
    void check_same_device(const Tensor& other) const;
};

} // namespace core
} // namespace rootseed