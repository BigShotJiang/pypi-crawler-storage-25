// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dtype.cpp — Run-Time Data Type Utilities and Hardware-Aware Promotion Rules (Section 6)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "dtype.h"

#include <string>
#include <string_view>
#include <unordered_map>
#include <limits>
#include <cstdint>

namespace rootseed {
namespace core {

// ============================================================================
// String <-> DType conversion
// ============================================================================

DType dtype_from_string(std::string_view name) {
    // Canonical names
    static const std::unordered_map<std::string_view, DType> map = {
        {"float32", DType::Float32},
        {"float64", DType::Float64},
        {"float16", DType::Float16},
        {"bfloat16", DType::BFloat16},
        {"float8", DType::Float8},
        {"fp32", DType::Float32},
        {"fp64", DType::Float64},
        {"fp16", DType::Float16},
        {"bf16", DType::BFloat16},
        {"fp8", DType::Float8},
        {"int8", DType::Int8},
        {"int16", DType::Int16},
        {"int32", DType::Int32},
        {"int64", DType::Int64},
        {"uint8", DType::UInt8},
        {"bool", DType::Bool},
        {"index", DType::Index},
    };

    auto it = map.find(name);
    if (it != map.end()) {
        return it->second;
    }
    throw std::invalid_argument(std::string("Unknown dtype: ") + std::string(name));
}

std::string_view dtype_name(DType dtype) noexcept {
    switch (dtype) {
        case DType::Float32:  return "float32";
        case DType::Float64:  return "float64";
        case DType::Float16:  return "float16";
        case DType::BFloat16: return "bfloat16";
        case DType::Float8:   return "float8";
        case DType::Int8:     return "int8";
        case DType::Int16:    return "int16";
        case DType::Int32:    return "int32";
        case DType::Int64:    return "int64";
        case DType::UInt8:    return "uint8";
        case DType::Bool:     return "bool";
        case DType::Index:    return "int64";
    }
    return "unknown";
}

// ============================================================================
// Runtime dtype min/max values
// ============================================================================

// Note: These are host-side utilities primarily for checking bounds.
// For FP8, we return the E4M3 representable range as a reasonable default.

double dtype_min_value(DType dtype) {
    switch (dtype) {
        case DType::Float32:  return -3.402823e+38;
        case DType::Float64:  return -1.7976931348623157e+308;
        case DType::Float16:  return -65504.0;
        case DType::BFloat16: return -3.38953139e+38;
        case DType::Float8:   return -448.0;   // E4M3 max
        case DType::Int8:     return -128.0;
        case DType::Int16:    return -32768.0;
        case DType::Int32:    return -2147483648.0;
        case DType::Int64:    return -9.223372036854776e+18;
        case DType::UInt8:    return 0.0;
        case DType::Bool:     return 0.0;
        case DType::Index:    return -9.223372036854776e+18;
    }
    return 0.0;
}

double dtype_max_value(DType dtype) {
    switch (dtype) {
        case DType::Float32:  return 3.402823e+38;
        case DType::Float64:  return 1.7976931348623157e+308;
        case DType::Float16:  return 65504.0;
        case DType::BFloat16: return 3.38953139e+38;
        case DType::Float8:   return 448.0;    // E4M3 max
        case DType::Int8:     return 127.0;
        case DType::Int16:    return 32767.0;
        case DType::Int32:    return 2147483647.0;
        case DType::Int64:    return 9.223372036854776e+18;
        case DType::UInt8:    return 255.0;
        case DType::Bool:     return 1.0;
        case DType::Index:    return 9.223372036854776e+18;
    }
    return 0.0;
}

} // namespace core
} // namespace rootseed