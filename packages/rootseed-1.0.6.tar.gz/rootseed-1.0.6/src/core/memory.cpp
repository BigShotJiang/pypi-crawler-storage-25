// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// memory.cpp — Hardware-Aware Memory Allocator and Buddy Pool Implementation (Section 2.3, 11)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "memory.h"

#include <algorithm>
#include <cstring>
#include <fstream>
#include <sstream>
#include <iostream>
#include <sys/mman.h>
#include <sys/sysinfo.h>
#include <unistd.h>
#include <cmath>

namespace rootseed {
namespace core {

// ============================================================================
// Device to_string
// ============================================================================

std::string Device::to_string() const {
    static const char* type_names[] = {"CPU", "CUDA", "ROCm", "Vulkan", "TPU", "NPU", "Metal"};
    auto name = (static_cast<uint8_t>(type) < 7) ? type_names[static_cast<uint8_t>(type)] : "Unknown";
    return std::string(name) + ":" + std::to_string(index);
}

// ============================================================================
// Hardware Detection (Section 10 — sysfs parsing)
// ============================================================================

HardwareMemoryInfo detect_hardware_memory() {
    HardwareMemoryInfo info;
    info.detected = true;

    // ---- Physical memory ----
    struct sysinfo si;
    if (sysinfo(&si) == 0) {
        info.physical_memory = si.totalram * si.mem_unit;
    }

    // ---- Page size ----
    info.page_size = sysconf(_SC_PAGESIZE);

    // ---- Cache sizes via sysfs ----
    auto read_sysfs_int = [](const std::string& path) -> size_t {
        std::ifstream f(path);
        if (f.is_open()) {
            size_t val = 0;
            f >> val;
            return val;
        }
        return 0;
    };

    auto read_sysfs_line = [](const std::string& path) -> std::string {
        std::ifstream f(path);
        if (f.is_open()) {
            std::string line;
            std::getline(f, line);
            return line;
        }
        return "";
    };

    // Iterate through CPU cache directories
    for (int cpu = 0; ; ++cpu) {
        std::string base = "/sys/devices/system/cpu/cpu" + std::to_string(cpu) + "/cache/";
        std::ifstream test(base + "index0/type");
        if (!test.is_open()) break;

        for (int idx = 0; ; ++idx) {
            std::string prefix = base + "index" + std::to_string(idx) + "/";
            std::string type = read_sysfs_line(prefix + "type");
            if (type.empty()) break;

            std::string level_str = read_sysfs_line(prefix + "level");
            int level = level_str.empty() ? 0 : std::stoi(level_str);

            size_t cache_size = read_sysfs_int(prefix + "size") * 1024;  // sysfs reports in KB
            size_t line_size = read_sysfs_int(prefix + "coherency_line_size");

            if (level == 1 && type.find("Data") != std::string::npos) {
                info.l1_cache_size = std::max(info.l1_cache_size, cache_size);
                info.l1_cache_line_size = line_size;
            } else if (level == 2) {
                info.l2_cache_size = std::max(info.l2_cache_size, cache_size);
                info.l2_cache_line_size = line_size;
            } else if (level == 3) {
                info.l3_cache_size = std::max(info.l3_cache_size, cache_size);
                info.l3_cache_line_size = line_size;
            }
        }
        break;  // Only need first CPU — caches are shared at L2/L3
    }

    // ---- Hugepages ----
    std::ifstream hp_file("/proc/meminfo");
    if (hp_file.is_open()) {
        std::string line;
        while (std::getline(hp_file, line)) {
            if (line.find("Hugepagesize:") == 0) {
                std::istringstream iss(line);
                std::string label;
                size_t size_kb;
                iss >> label >> size_kb;
                info.hugepage_size = size_kb * 1024;
            }
            if (line.find("HugePages_Total:") == 0) {
                std::istringstream iss(line);
                std::string label;
                size_t total;
                iss >> label >> total;
                info.hugepages_available = (total > 0);
            }
        }
    }

    // ---- NUMA ----
    std::ifstream numa_file("/sys/devices/system/node/online");
    if (numa_file.is_open()) {
        info.numa_available = true;
        std::string nodes;
        numa_file >> nodes;
        // Count nodes: "0-3" or "0,1,2,3"
        info.numa_node_count = std::count(nodes.begin(), nodes.end(), '-') +
                               std::count(nodes.begin(), nodes.end(), ',') + 1;
        if (info.numa_node_count == 0) info.numa_node_count = 1;
    }

    // ---- SIMD width (detected by compiler defines) ----
#if defined(__AVX512F__)
    info.max_simd_width = 512;
#elif defined(__AVX2__) || defined(__ARM_FEATURE_SVE)
    info.max_simd_width = 256;
#elif defined(__SSE__) || defined(__ARM_NEON)
    info.max_simd_width = 128;
#else
    info.max_simd_width = 64;
#endif

    return info;
}

// ============================================================================
// CPUAllocator
// ============================================================================

CPUAllocator::CPUAllocator(const HardwareMemoryInfo& info)
    : hw_info_(info) {}

void* CPUAllocator::allocate(size_t size, AllocFlags flags) {
    std::lock_guard<std::mutex> lock(mutex_);

    void* ptr = nullptr;

    if (has_flag(flags, AllocFlags::HugePages) && hw_info_.hugepages_available) {
        ptr = allocate_hugepage(size);
    } else if (has_flag(flags, AllocFlags::Pinned)) {
        ptr = allocate_pinned(size);
    } else {
        ptr = allocate_standard(size);
    }

    if (ptr && has_flag(flags, AllocFlags::ZeroInit)) {
        std::memset(ptr, 0, size);
    }

    if (ptr) {
        active_allocations_[ptr] = size;
    }

    return ptr;
}

void* CPUAllocator::allocate_standard(size_t size) {
    // Align to 64 bytes (cache line)
    void* ptr = nullptr;
    int ret = posix_memalign(&ptr, 64, size);
    if (ret != 0) return nullptr;
    return ptr;
}

void* CPUAllocator::allocate_hugepage(size_t size) {
    // Round up to hugepage size
    size_t aligned = ((size + hw_info_.hugepage_size - 1) / hw_info_.hugepage_size) * hw_info_.hugepage_size;
    void* ptr = mmap(nullptr, aligned, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS | MAP_HUGETLB, -1, 0);
    if (ptr == MAP_FAILED) {
        // Fallback to standard allocation
        return allocate_standard(size);
    }
    return ptr;
}

void* CPUAllocator::allocate_pinned(size_t size) {
    // Page-locked memory: use mlock after allocation
    void* ptr = allocate_standard(size);
    if (ptr) {
        mlock(ptr, size);  // Pin in RAM — prevents swapping for fast GPU transfers
    }
    return ptr;
}

void CPUAllocator::deallocate(void* ptr) {
    std::lock_guard<std::mutex> lock(mutex_);

    auto it = active_allocations_.find(ptr);
    if (it != active_allocations_.end()) {
        size_t size = it->second;
        // Try to un-pin if it was pinned
        munlock(ptr, size);
        active_allocations_.erase(it);
    }

    // Check if this is a hugepage allocation (aligned to 2MB)
    size_t addr = reinterpret_cast<size_t>(ptr);
    if (addr % hw_info_.hugepage_size == 0) {
        // Attempt hugepage unmap — if it wasn't hugepage, munmap fails silently
        munmap(ptr, 0);  // We don't track the exact size for hugepages, use posix_memalign free
    }

    std::free(ptr);
}

size_t CPUAllocator::allocated_size(void* ptr) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = active_allocations_.find(ptr);
    if (it != active_allocations_.end()) {
        return it->second;
    }
    return 0;
}

// ============================================================================
// MemoryPool — Buddy Allocator
// ============================================================================

struct MemoryPool::Block {
    size_t size_class;
    bool free;
    Block* buddy;
};

struct MemoryPool::FreeList {
    Block* head = nullptr;
    size_t count = 0;
};

struct MemoryPool::SizeClass {
    size_t block_size;
    FreeList free_list;
};

MemoryPool::MemoryPool(size_t initial_pool_size)
    : pool_size_(initial_pool_size) {

    // Initialize size classes: 256, 512, 1024, 2048, ... 64MB
    size_classes_.resize(kNumSizeClasses);
    size_t size = kMinBlockSize;
    for (size_t i = 0; i < kNumSizeClasses; ++i) {
        size_classes_[i].block_size = size;
        size *= 2;
    }

    // Allocate the backing memory pool
    pool_memory_ = std::aligned_alloc(64, pool_size_);
}

MemoryPool::~MemoryPool() {
    std::free(pool_memory_);
    pool_memory_ = nullptr;
}

size_t MemoryPool::size_to_index(size_t size) const {
    if (size <= kMinBlockSize) return 0;
    // Find smallest power-of-2 >= size
    size_t idx = static_cast<size_t>(std::ceil(std::log2(size))) -
                 static_cast<size_t>(std::ceil(std::log2(kMinBlockSize)));
    if (idx >= kNumSizeClasses) idx = kNumSizeClasses - 1;
    return idx;
}

size_t MemoryPool::index_to_size(size_t idx) const {
    return size_classes_[idx].block_size;
}

void* MemoryPool::allocate(size_t size) {
    std::lock_guard<std::mutex> lock(mutex_);

    size_t idx = size_to_index(size);
    size_t req_size = index_to_size(idx);

    // Find the smallest available block >= req_size
    size_t alloc_idx = idx;
    while (alloc_idx < kNumSizeClasses && size_classes_[alloc_idx].free_list.head == nullptr) {
        alloc_idx++;
    }

    if (alloc_idx >= kNumSizeClasses) {
        // No block available — allocate from OS
        return allocate_raw(size);
    }

    // Pop from free list
    Block* block = size_classes_[alloc_idx].free_list.head;
    size_classes_[alloc_idx].free_list.head = block->buddy;
    size_classes_[alloc_idx].free_list.count--;
    block->free = false;

    // Split if the block is larger than needed
    while (alloc_idx > idx) {
        alloc_idx--;
        Block* buddy = reinterpret_cast<Block*>(
            reinterpret_cast<char*>(block) + index_to_size(alloc_idx));
        buddy->size_class = alloc_idx;
        buddy->free = true;
        buddy->buddy = size_classes_[alloc_idx].free_list.head;
        size_classes_[alloc_idx].free_list.head = buddy;
        size_classes_[alloc_idx].free_list.count++;
    }

    block->size_class = idx;
    block_map_[block] = block;
    return reinterpret_cast<void*>(block + 1);
}

void MemoryPool::deallocate(void* ptr) {
    if (!ptr) return;

    std::lock_guard<std::mutex> lock(mutex_);

    auto it = block_map_.find(ptr);
    if (it == block_map_.end()) {
        // Not from pool — deallocate from OS
        deallocate_raw(ptr);
        return;
    }

    Block* block = it->second;
    block_map_.erase(it);

    size_t idx = block->size_class;
    block->free = true;
    block->buddy = size_classes_[idx].free_list.head;
    size_classes_[idx].free_list.head = block;
    size_classes_[idx].free_list.count++;

    // Coalesce with buddy if possible
    coalesce(block);
}

MemoryPool::Block* MemoryPool::coalesce(Block* block) {
    // Buddy system coalescing — merge with adjacent free block
    // Simplified: just return to free list, no coalescing in this initial impl
    (void)block;
    return nullptr;
}

void MemoryPool::release_unused() {
    std::lock_guard<std::mutex> lock(mutex_);
    // Return all free blocks to OS
    for (size_t i = 0; i < kNumSizeClasses; ++i) {
        Block* block = size_classes_[i].free_list.head;
        while (block) {
            Block* next = block->buddy;
            block_map_.erase(block + 1);
            block = next;
        }
        size_classes_[i].free_list.head = nullptr;
        size_classes_[i].free_list.count = 0;
    }
}

void* MemoryPool::allocate_raw(size_t size) {
    return std::aligned_alloc(64, size);
}

void MemoryPool::deallocate_raw(void* ptr) {
    std::free(ptr);
}

size_t MemoryPool::total_allocated() const {
    return block_map_.size();
}

size_t MemoryPool::total_reserved() const {
    return pool_size_;
}

size_t MemoryPool::free_count() const {
    size_t count = 0;
    for (size_t i = 0; i < kNumSizeClasses; ++i) {
        count += size_classes_[i].free_list.count;
    }
    return count;
}

// ============================================================================
// MemoryManager singleton
// ============================================================================

MemoryManager& MemoryManager::instance() {
    static MemoryManager s_instance;
    return s_instance;
}

void MemoryManager::init() {
    std::lock_guard<std::mutex> lock(mutex_);

    if (initialized_) return;

    // Detect hardware
    hw_info_ = detect_hardware_memory();

    // Create CPU allocator
    cpu_allocator_ = std::make_unique<CPUAllocator>(hw_info_);

    // Create default CPU memory pool
    Device cpu{DeviceType::CPU, 0};
    pools_[cpu] = std::make_unique<MemoryPool>();

    initialized_ = true;
}

MemoryManager::~MemoryManager() {
    release_unused();
}

void* MemoryManager::allocate(size_t size, const Device& device, AllocFlags flags) {
    if (!initialized_) init();

    std::lock_guard<std::mutex> lock(mutex_);

    if (device.is_cpu()) {
        if (has_flag(flags, AllocFlags::NoCache)) {
            return cpu_allocator_->allocate(size, flags);
        } else {
            // Use memory pool
            auto it = pools_.find(device);
            if (it == pools_.end()) {
                pools_[device] = std::make_unique<MemoryPool>();
                it = pools_.find(device);
            }
            return it->second->allocate(size);
        }
    }

    // GPU/other devices — handled by HAL (Module C)
    return cpu_allocator_->allocate(size, flags);
}

void MemoryManager::deallocate(void* ptr, const Device& device) {
    if (!ptr) return;

    std::lock_guard<std::mutex> lock(mutex_);

    if (device.is_cpu()) {
        auto it = pools_.find(device);
        if (it != pools_.end()) {
            it->second->deallocate(ptr);
        } else {
            cpu_allocator_->deallocate(ptr);
        }
    } else {
        cpu_allocator_->deallocate(ptr);
    }
}

MemoryPool& MemoryManager::pool(const Device& device) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = pools_.find(device);
    if (it == pools_.end()) {
        pools_[device] = std::make_unique<MemoryPool>();
        return *pools_[device];
    }
    return *it->second;
}

void MemoryManager::release_unused() {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& [dev, pool] : pools_) {
        pool->release_unused();
    }
}

} // namespace core
} // namespace rootseed