// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// shape.cpp — Shape and Strides Non-Inline Implementations (Section 2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "shape.h"

#include <stdexcept>
#include <algorithm>

namespace rootseed {
namespace core {

// ============================================================================
// Most Shape and Strides logic is inline in the header (small-vector opt).
// This file provides any larger / non-inline implementations.
// ============================================================================

// Shape::numel is constexpr-compatible; defined inline in header.
// Strides::is_contiguous is defined inline in header.
// broadcastable and broadcast_shape are defined inline in header.

} // namespace core
} // namespace rootseed