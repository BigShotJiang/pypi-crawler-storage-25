// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// memory.h — Hardware-Aware Memory Allocation and Pool Management (Section 2.3, 11)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <memory>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <functional>

namespace rootseed {
namespace core {

// ============================================================================
// Device — physical hardware target for memory
// ============================================================================

enum class DeviceType : uint8_t {
    CPU = 0,
    CUDA = 1,
    ROCm = 2,
    Vulkan = 3,
    TPU = 4,
    NPU = 5,
    Metal = 6,
};

struct Device {
    DeviceType type = DeviceType::CPU;
    int index = 0;  // Device index (e.g., GPU 0, GPU 1)

    bool is_cpu()   const noexcept { return type == DeviceType::CPU; }
    bool is_gpu()   const noexcept { return type == DeviceType::CUDA || type == DeviceType::ROCm || type == DeviceType::Vulkan || type == DeviceType::Metal; }
    bool is_cuda()  const noexcept { return type == DeviceType::CUDA; }
    bool is_rocm()  const noexcept { return type == DeviceType::ROCm; }
    bool is_tpu()   const noexcept { return type == DeviceType::TPU; }
    bool is_npu()   const noexcept { return type == DeviceType::NPU; }

    bool operator==(const Device& other) const noexcept { return type == other.type && index == other.index; }
    bool operator!=(const Device& other) const noexcept { return !(*this == other); }

    std::string to_string() const;
};

// ============================================================================
// AllocFlags — allocation modifiers
// ============================================================================

enum class AllocFlags : uint32_t {
    None       = 0,
    Pinned     = 1 << 0,  // Page-locked memory (for fast CPU↔GPU transfer)
    HugePages  = 1 << 1,  // Use hugepages (2MB/1GB)
    NoCache    = 1 << 2,  // Bypass memory pool — allocate directly
    ZeroInit   = 1 << 3,  // Zero-initialize after allocation
};

inline AllocFlags operator|(AllocFlags a, AllocFlags b) {
    return static_cast<AllocFlags>(static_cast<uint32_t>(a) | static_cast<uint32_t>(b));
}
inline AllocFlags operator&(AllocFlags a, AllocFlags b) {
    return static_cast<AllocFlags>(static_cast<uint32_t>(a) & static_cast<uint32_t>(b));
}
inline bool has_flag(AllocFlags flags, AllocFlags flag) {
    return (static_cast<uint32_t>(flags) & static_cast<uint32_t>(flag)) != 0;
}

// ============================================================================
// HardwareMemoryInfo — cache and memory topology (detected at runtime)
// ============================================================================

struct HardwareMemoryInfo {
    // Cache hierarchy
    size_t l1_cache_size = 32 * 1024;       // Default: 32KB
    size_t l1_cache_line_size = 64;
    size_t l2_cache_size = 256 * 1024;      // Default: 256KB
    size_t l2_cache_line_size = 64;
    size_t l3_cache_size = 8 * 1024 * 1024; // Default: 8MB
    size_t l3_cache_line_size = 64;

    // Memory
    size_t physical_memory = 0;
    size_t page_size = 4096;
    size_t hugepage_size = 2 * 1024 * 1024;  // Default: 2MB
    bool hugepages_available = false;

    // NUMA
    bool numa_available = false;
    int numa_node_count = 1;

    // SIMD
    size_t max_simd_width = 256;  // bits (256 = AVX2, 512 = AVX512)

    // Whether this info has been populated
    bool detected = false;
};

// ============================================================================
// Allocator — abstract interface for memory allocation
// ============================================================================

class Allocator {
public:
    virtual ~Allocator() = default;

    virtual void* allocate(size_t size, AllocFlags flags = AllocFlags::None) = 0;
    virtual void deallocate(void* ptr) = 0;
    virtual size_t allocated_size(void* ptr) const = 0;
    virtual std::string name() const = 0;
};

// ============================================================================
// CPUAllocator — heap allocator with optional hugepage/pinned support
// ============================================================================

class CPUAllocator : public Allocator {
public:
    explicit CPUAllocator(const HardwareMemoryInfo& info);

    void* allocate(size_t size, AllocFlags flags = AllocFlags::None) override;
    void deallocate(void* ptr) override;
    size_t allocated_size(void* ptr) const override;
    std::string name() const override { return "CPUAllocator"; }

private:
    void* allocate_standard(size_t size);
    void* allocate_hugepage(size_t size);
    void* allocate_pinned(size_t size);

    HardwareMemoryInfo hw_info_;
    std::unordered_map<void*, size_t> active_allocations_;
    mutable std::mutex mutex_;
};

// ============================================================================
// MemoryPool — Buddy allocator for efficient tensor memory reuse
// ============================================================================

class MemoryPool {
public:
    static constexpr size_t kMinBlockSize = 256;           // 256 bytes
    static constexpr size_t kMaxBlockSize = 64 * 1024 * 1024;  // 64MB
    static constexpr size_t kNumSizeClasses = 19;          // 2^8 to 2^26

    explicit MemoryPool(size_t initial_pool_size = 1024 * 1024 * 1024ULL);  // 1GB default
    ~MemoryPool();

    void* allocate(size_t size);
    void deallocate(void* ptr);
    void release_unused();

    size_t total_allocated() const;
    size_t total_reserved() const;
    size_t free_count() const;

private:
    struct Block;
    struct FreeList;
    struct SizeClass;

    size_t size_to_index(size_t size) const;
    size_t index_to_size(size_t idx) const;
    void* allocate_raw(size_t size);
    void deallocate_raw(void* ptr);
    void split_block(Block* block, size_t target_size);
    Block* coalesce(Block* block);

    std::vector<SizeClass> size_classes_;
    std::unordered_map<void*, Block*> block_map_;
    void* pool_memory_;
    size_t pool_size_;
    mutable std::mutex mutex_;
};

// ============================================================================
// MemoryManager — singleton orchestrating all memory allocation
// ============================================================================

class MemoryManager {
public:
    static MemoryManager& instance();

    /// Initialize with hardware detection.
    void init();

    /// Allocate memory on a specific device using the optimal strategy.
    void* allocate(size_t size, const Device& device = Device{},
                   AllocFlags flags = AllocFlags::None);

    /// Deallocate memory previously allocated by this manager.
    void deallocate(void* ptr, const Device& device = Device{});

    /// Get the hardware memory info (cache sizes, NUMA, etc.).
    const HardwareMemoryInfo& hardware_info() const noexcept { return hw_info_; }

    /// Get the memory pool for a given device.
    MemoryPool& pool(const Device& device);

    /// Release all unused memory across all pools.
    void release_unused();

private:
    MemoryManager() = default;
    ~MemoryManager();

    MemoryManager(const MemoryManager&) = delete;
    MemoryManager& operator=(const MemoryManager&) = delete;

    HardwareMemoryInfo hw_info_;
    std::unique_ptr<CPUAllocator> cpu_allocator_;
    std::unordered_map<Device, std::unique_ptr<MemoryPool>, std::function<size_t(const Device&)>> pools_;
    mutable std::mutex mutex_;
    bool initialized_ = false;
};

// ============================================================================
// Utility: detect hardware memory topology
// ============================================================================

HardwareMemoryInfo detect_hardware_memory();

} // namespace core
} // namespace rootseed