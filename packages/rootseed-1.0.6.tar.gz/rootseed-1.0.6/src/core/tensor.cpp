// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// tensor.cpp — Tensor Implementation: Operations, Gradients, Sparse Conversion (Section 6.1, 6.3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "core/tensor.h"
#include "utils/log.h"
#include "utils/exception.h"
using namespace rootseed::utils;

#include <algorithm>
#include <cmath>
#include <sstream>
#include <cstring>

namespace rootseed {
namespace core {

// ============================================================================
// TensorStorage
// ============================================================================

TensorStorage::~TensorStorage() {
    release();
}

TensorStorage::TensorStorage(TensorStorage&& other) noexcept
    : data(other.data), size_bytes(other.size_bytes), device(other.device),
      dtype(other.dtype), owns_data(other.owns_data) {
    other.data = nullptr;
    other.size_bytes = 0;
}

TensorStorage& TensorStorage::operator=(TensorStorage&& other) noexcept {
    if (this != &other) {
        release();
        data = other.data;
        size_bytes = other.size_bytes;
        device = other.device;
        dtype = other.dtype;
        owns_data = other.owns_data;
        other.data = nullptr;
        other.size_bytes = 0;
    }
    return *this;
}

void TensorStorage::allocate(size_t bytes, AllocFlags flags) {
    release();
    auto* device_ptr = hal::DeviceManager::instance().get_device(device.type, device.index);
    if (device_ptr) {
        data = device_ptr->allocate(bytes, flags);
        size_bytes = bytes;
        owns_data = true;
    } else {
        // Fallback: direct CPU allocation
        data = std::aligned_alloc(64, bytes);
        size_bytes = bytes;
        owns_data = true;
    }
}

void TensorStorage::release() {
    if (data && owns_data) {
        auto* device_ptr = hal::DeviceManager::instance().get_device(device.type, device.index);
        if (device_ptr) {
            device_ptr->deallocate(data);
        } else {
            std::free(data);
        }
        data = nullptr;
        size_bytes = 0;
    }
}

// ============================================================================
// GraphNode (lightweight computation graph for autograd)
// ============================================================================

struct Tensor::GraphNode {
    std::string op_name;
    std::vector<std::shared_ptr<Tensor>> inputs;
    std::vector<std::shared_ptr<Tensor>> outputs;
    std::function<void()> backward_fn;
};

// ============================================================================
// Tensor Constructors
// ============================================================================

Tensor::Tensor() : shape_(), strides_(), dtype_(DType::Float32), is_sparse_(false) {}

Tensor::Tensor(const Shape& shape, DType dtype, const Device& device)
    : shape_(shape), strides_(shape, true), dtype_(dtype), is_sparse_(false) {
    storage_ = std::make_shared<TensorStorage>();
    storage_->device = device;
    storage_->dtype = dtype;
    allocate_storage();
}

Tensor Tensor::from_vector(const std::vector<float>& data, const Shape& shape,
                            DType dtype, const Device& device) {
    int64_t expected = shape.numel();
    if (static_cast<int64_t>(data.size()) != expected) {
        RS_THROW(ErrorCode::TensorShapeMismatch,
                 "Data size " + std::to_string(data.size()) +
                 " does not match shape " + shape.to_string() +
                 " (" + std::to_string(expected) + " elements)");
    }

    Tensor t(shape, dtype, device);
    size_t elem_size = dtype_size(dtype);
    for (int64_t i = 0; i < expected; ++i) {
        float val = data[i];
        void* dst = static_cast<char*>(t.storage_->data) + i * elem_size;
        if (dtype == DType::Float32) {
            *static_cast<float*>(dst) = val;
        } else if (dtype == DType::Float64) {
            *static_cast<double*>(dst) = static_cast<double>(val);
        } else if (dtype == DType::Float16) {
            // Truncate to half precision (simplified — use proper half conversion in production)
            *static_cast<uint16_t*>(dst) = static_cast<uint16_t>(val * 100) / 100;
        }
    }
    return t;
}

Tensor Tensor::zeros(const Shape& shape, DType dtype, const Device& device) {
    Tensor t(shape, dtype, device);
    if (t.storage_ && t.storage_->data) {
        std::memset(t.storage_->data, 0, t.storage_->size_bytes);
    }
    return t;
}

Tensor Tensor::ones(const Shape& shape, DType dtype, const Device& device) {
    Tensor t = zeros(shape, dtype, device);
    int64_t n = shape.numel();
    size_t elem_size = dtype_size(dtype);
    // Fill with 1.0
    float one = 1.0f;
    for (int64_t i = 0; i < n; ++i) {
        void* dst = static_cast<char*>(t.storage_->data) + i * elem_size;
        if (dtype == DType::Float32) {
            *static_cast<float*>(dst) = one;
        }
    }
    return t;
}

Tensor Tensor::csr(const CSRStorage& csr, const Shape& shape, DType dtype, const Device& /*device*/) {
    Tensor t;
    t.shape_ = shape;
    t.dtype_ = dtype;
    t.is_sparse_ = true;
    t.csr_data_ = std::make_shared<CSRStorage>(csr);
    return t;
}

Tensor Tensor::coo(const COOStorage& coo, const Shape& shape, DType dtype, const Device& /*device*/) {
    Tensor t;
    t.shape_ = shape;
    t.dtype_ = dtype;
    t.is_sparse_ = true;
    t.coo_data_ = std::make_shared<COOStorage>(coo);
    return t;
}

Tensor::~Tensor() = default;

Tensor::Tensor(Tensor&& other) noexcept
    : shape_(std::move(other.shape_)), strides_(std::move(other.strides_)),
      dtype_(other.dtype_), storage_(std::move(other.storage_)),
      is_sparse_(other.is_sparse_), csr_data_(std::move(other.csr_data_)),
      coo_data_(std::move(other.coo_data_)),
      requires_grad_(other.requires_grad_), grad_(std::move(other.grad_)),
      graph_node_(std::move(other.graph_node_)) {
    // other left in valid empty state (destructor-safe)
}

Tensor& Tensor::operator=(Tensor&& other) noexcept {
    if (this != &other) {
        shape_ = std::move(other.shape_);
        strides_ = std::move(other.strides_);
        dtype_ = other.dtype_;
        storage_ = std::move(other.storage_);
        is_sparse_ = other.is_sparse_;
        csr_data_ = std::move(other.csr_data_);
        coo_data_ = std::move(other.coo_data_);
        requires_grad_ = other.requires_grad_;
        grad_ = std::move(other.grad_);
        graph_node_ = std::move(other.graph_node_);
    }
    return *this;
}

Tensor::Tensor(const Tensor& other)
    : shape_(other.shape_), strides_(other.strides_), dtype_(other.dtype_),
      is_sparse_(other.is_sparse_), requires_grad_(other.requires_grad_) {
    // Copy storage (shallow copy for shared_ptr, deep copy for data if needed)
    storage_ = other.storage_;
    csr_data_ = other.csr_data_;
    coo_data_ = other.coo_data_;
    grad_ = other.grad_;
    graph_node_ = other.graph_node_;
}

Tensor& Tensor::operator=(const Tensor& other) {
    if (this != &other) {
        shape_ = other.shape_;
        strides_ = other.strides_;
        dtype_ = other.dtype_;
        storage_ = other.storage_;
        is_sparse_ = other.is_sparse_;
        csr_data_ = other.csr_data_;
        coo_data_ = other.coo_data_;
        requires_grad_ = other.requires_grad_;
        grad_ = other.grad_;
        graph_node_ = other.graph_node_;
    }
    return *this;
}

// ============================================================================
// Allocation
// ============================================================================

void Tensor::allocate_storage() {
    if (!storage_) return;
    size_t elem_size = dtype_size(dtype_);
    size_t total = shape_.numel() * elem_size;
    if (total > 0) {
        storage_->allocate(total);
    }
}

// ============================================================================
// Element Access
// ============================================================================

float Tensor::item(int64_t index) const {
    if (is_sparse_) RS_THROW(ErrorCode::TensorDTypeMismatch, "item() not supported on sparse tensors");
    if (!storage_ || !storage_->data) RS_THROW(ErrorCode::TensorShapeMismatch, "Tensor has no storage");
    if (index >= shape_.numel()) RS_THROW(ErrorCode::TensorIndexOutOfBounds, "Index out of bounds");
    size_t elem_size = dtype_size(dtype_);
    void* src = static_cast<char*>(storage_->data) + index * elem_size;
    return *static_cast<float*>(src);
}

float Tensor::item(int64_t row, int64_t col) const {
    int64_t index = row * shape_[1] + col;  // Assumes 2D
    return item(index);
}

void Tensor::set_item(int64_t index, float value) {
    if (is_sparse_) RS_THROW(ErrorCode::TensorDTypeMismatch, "set_item() not supported on sparse tensors");
    if (!storage_ || !storage_->data) RS_THROW(ErrorCode::TensorShapeMismatch, "Tensor has no storage");
    size_t elem_size = dtype_size(dtype_);
    void* dst = static_cast<char*>(storage_->data) + index * elem_size;
    *static_cast<float*>(dst) = value;
}

void Tensor::set_item(int64_t row, int64_t col, float value) {
    int64_t index = row * shape_[1] + col;
    set_item(index, value);
}

// ============================================================================
// Gradient
// ============================================================================

const Tensor& Tensor::grad() const {
    if (!grad_) {
        RS_THROW(ErrorCode::AutogradBackwardError, "Gradient not computed yet");
    }
    return *grad_;
}

void Tensor::set_grad(const Tensor& g) {
    grad_ = std::make_shared<Tensor>(g);
}

void Tensor::backward() {
    if (!graph_node_) {
        RS_THROW(ErrorCode::AutogradGraphError, "No computation graph — cannot backward");
    }
    // Seed gradient with ones (∂L/∂y = 1 for scalar loss)
    grad_ = std::make_shared<Tensor>(Tensor::ones(shape_, dtype_));
    
    // Traverse graph in reverse topological order
    // Simplified: just call the backward function if it exists
    if (graph_node_->backward_fn) {
        graph_node_->backward_fn();
    }
}

// ============================================================================
// Operations: matmul (Section 6.1)
// ============================================================================

Tensor Tensor::matmul(const Tensor& other) const {
    check_same_device(other);
    
    if (is_sparse_ || other.is_sparse_) {
        return sparse_matmul(other);
    }
    return dense_matmul(other);
}

Tensor Tensor::dense_matmul(const Tensor& other) const {
    // y = W · x
    // Shape: (M, K) @ (K, N) → (M, N)
    if (ndim() != 2 || other.ndim() != 2) {
        RS_THROW(ErrorCode::TensorShapeMismatch,
                 "matmul requires 2D tensors, got " + shape_.to_string() +
                 " and " + other.shape_.to_string());
    }

    int64_t M = shape_[0];
    int64_t K = shape_[1];
    int64_t K2 = other.shape_[0];
    int64_t N = other.shape_[1];

    if (K != K2) {
        RS_THROW(ErrorCode::TensorShapeMismatch,
                 "matmul inner dimensions mismatch: " + std::to_string(K) +
                 " vs " + std::to_string(K2));
    }

    Shape result_shape({M, N});
    Tensor result = Tensor::zeros(result_shape, promote_types(dtype_, other.dtype_), device());

    // Triple-loop CPU matmul (fallback — AKD dispatches to optimized kernels)
    for (int64_t i = 0; i < M; ++i) {
        for (int64_t j = 0; j < N; ++j) {
            float sum = 0.0f;
            for (int64_t k = 0; k < K; ++k) {
                sum += item(i, k) * other.item(k, j);
            }
            result.set_item(i, j, sum);
        }
    }

    // Set up gradient tracking
    if (requires_grad_ || other.requires_grad()) {
        result.set_requires_grad(true);
        result.graph_node_ = std::make_shared<Tensor::GraphNode>();
        result.graph_node_->op_name = "matmul";
        result.graph_node_->inputs = {
            std::make_shared<Tensor>(*this),
            std::make_shared<Tensor>(other)
        };
        // Backward: dA = grad @ B^T, dB = A^T @ grad (handled by autograd module)
    }

    return result;
}

Tensor Tensor::sparse_matmul(const Tensor& /*other*/) const {
    // CSR sparse-dense matmul — delegated to AKD (Module F)
    RS_THROW(ErrorCode::SparseFormatError, "Sparse matmul not yet implemented — pending AKD integration");
}

// ============================================================================
// Operations: add, sub, mul, div
// ============================================================================

Tensor Tensor::add(const Tensor& other) const {
    check_same_device(other);

    Shape result_shape = broadcast_shape(shape_, other.shape_);
    Tensor result = Tensor::zeros(result_shape, promote_types(dtype_, other.dtype_), device());

    // Simplified: broadcast both to result shape and add
    int64_t n = result_shape.numel();
    for (int64_t i = 0; i < n; ++i) {
        // Compute broadcast indices (simplified for 1D/2D)
        float a = (i < shape_.numel()) ? item(i) : item(i % shape_.numel());
        float b = (i < other.shape_.numel()) ? other.item(i) : other.item(i % other.shape_.numel());
        result.set_item(i, a + b);
    }

    if (requires_grad_ || other.requires_grad()) {
        result.set_requires_grad(true);
    }

    return result;
}

void Tensor::check_same_device(const Tensor& other) const {
    if (device() != other.device()) {
        RS_THROW(ErrorCode::HardwareUnsupported,
                 "Cannot operate on tensors on different devices: " +
                 device().to_string() + " vs " + other.device().to_string());
    }
}

Tensor Tensor::sub(const Tensor& other) const {
    return add(other.mul(-1.0f));
}

Tensor Tensor::mul(const Tensor& other) const {
    check_same_device(other);
    Shape result_shape = broadcast_shape(shape_, other.shape_);
    Tensor result = Tensor::zeros(result_shape, promote_types(dtype_, other.dtype_), device());
    int64_t n = result_shape.numel();
    for (int64_t i = 0; i < n; ++i) {
        float a = item(i % shape_.numel());
        float b = other.item(i % other.shape_.numel());
        result.set_item(i, a * b);
    }
    if (requires_grad_ || other.requires_grad()) result.set_requires_grad(true);
    return result;
}

Tensor Tensor::mul(float scalar) const {
    Tensor result = Tensor::zeros(shape_, dtype_, device());
    int64_t n = shape_.numel();
    for (int64_t i = 0; i < n; ++i) {
        result.set_item(i, item(i) * scalar);
    }
    return result;
}

Tensor Tensor::div(const Tensor& other) const {
    return mul(Tensor::ones(other.shape_, other.dtype_, other.device()).mul(1.0f / other.item(0)));
}

// ============================================================================
// Manipulation
// ============================================================================

Tensor Tensor::transpose(int dim0, int dim1) const {
    if (ndim() < 2) return *this;  // Scalar/1D — no change
    
    if (dim0 < 0) dim0 += ndim();
    if (dim1 < 0) dim1 += ndim();
    
    if (dim0 == dim1) return *this;

    std::vector<int64_t> new_dims(ndim());
    for (size_t i = 0; i < ndim(); ++i) new_dims[i] = shape_[i];
    std::swap(new_dims[dim0], new_dims[dim1]);

    Shape new_shape(new_dims);
    Tensor result(new_shape, dtype_, device());
    
    // Copy with transposition (last two dims simplification)
    int64_t rows = shape_[0], cols = shape_[1];
    for (int64_t i = 0; i < rows; ++i) {
        for (int64_t j = 0; j < cols; ++j) {
            result.set_item(j, i, item(i, j));
        }
    }

    return result;
}

Tensor Tensor::reshape(const Shape& new_shape) const {
    if (new_shape.numel() != shape_.numel()) {
        RS_THROW(ErrorCode::TensorShapeMismatch,
                 "Cannot reshape from " + shape_.to_string() + " to " + new_shape.to_string());
    }
    Tensor result = *this;
    result.shape_ = new_shape;
    result.strides_ = Strides(new_shape, true);
    return result;
}

Tensor Tensor::cast(DType new_dtype) const {
    if (new_dtype == dtype_) return *this;
    Tensor result(shape_, new_dtype, device());
    int64_t n = shape_.numel();
    for (int64_t i = 0; i < n; ++i) {
        result.set_item(i, item(i));
    }
    return result;
}

// ============================================================================
// Device Transfer
// ============================================================================

Tensor Tensor::to(const Device& device) const {
    if (device == this->device()) return *this;
    Tensor result(shape_, dtype_, device);
    if (storage_ && storage_->data && result.storage_ && result.storage_->data) {
        auto* src_dev = hal::DeviceManager::instance().get_device(this->device().type, this->device().index);
        auto* dst_dev = hal::DeviceManager::instance().get_device(device.type, device.index);
        if (src_dev && dst_dev) {
            dst_dev->memcpy(result.storage_->data, storage_->data, storage_->size_bytes, 0);
        } else {
            std::memcpy(result.storage_->data, storage_->data, storage_->size_bytes);
        }
    }
    return result;
}

Tensor Tensor::cpu() const {
    return to(Device{DeviceType::CPU, 0});
}

Tensor Tensor::cuda() const {
    return to(Device{DeviceType::CUDA, 0});
}

// ============================================================================
// String
// ============================================================================

std::string Tensor::to_string() const {
    std::ostringstream oss;
    oss << "Tensor(" << shape_.to_string() << ", " << dtype_name(dtype_)
        << ", device=" << device().to_string();
    if (is_sparse_) {
        oss << ", sparse, nnz=" << nnz();
    }
    oss << ")";
    return oss.str();
}

} // namespace core
} // namespace rootseed