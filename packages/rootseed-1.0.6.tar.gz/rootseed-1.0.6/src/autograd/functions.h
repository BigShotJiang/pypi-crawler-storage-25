// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// functions.h — Gradient Functions for Common Tensor Operations (Section 6.3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

namespace rootseed {
namespace autograd {

// ============================================================================
// Gradient functions for common operations.
// Each struct implements static apply() which modifies gradients in-place.
//
// These are called by the tensor operations (matmul, add, relu, etc.)
// when requires_grad is true and the tape is recording.
// ============================================================================

/// Gradient for matrix multiplication: y = A @ B
///
/// Equations:
///   dL/dA = dL/dy @ B^T
///   dL/dB = A^T @ dL/dy
struct MatmulBackward {
    /// @param grad_output  dL/dy — gradient of loss w.r.t. matmul output
    /// @param A            Left input tensor (saved from forward)
    /// @param B            Right input tensor (saved from forward)
    /// @param grad_A        Output: accumulated gradient for A (modified in-place)
    /// @param grad_B        Output: accumulated gradient for B (modified in-place)
    static void apply(const core::Tensor& grad_output,
                      const core::Tensor& A,
                      const core::Tensor& B,
                      core::Tensor& grad_A,
                      core::Tensor& grad_B);
};

/// Gradient for element-wise addition: y = A + B
///
/// Addition broadcasts gradients to match input shapes.
///   dL/dA = sum_over_broadcast_dims(dL/dy)
///   dL/dB = sum_over_broadcast_dims(dL/dy)
struct AddBackward {
    static void apply(const core::Tensor& grad_output,
                      const core::Tensor& A,
                      const core::Tensor& B,
                      core::Tensor& grad_A,
                      core::Tensor& grad_B);
};

/// Gradient for ReLU activation: y = max(0, x)
///
///   dL/dx = dL/dy  if x > 0, else 0
struct ReluBackward {
    static void apply(const core::Tensor& grad_output,
                      const core::Tensor& input,
                      core::Tensor& grad_input);
};

/// Gradient for element-wise multiplication: y = A ⊙ B
///
///   dL/dA = dL/dy ⊙ B
///   dL/dB = dL/dy ⊙ A
struct MulBackward {
    static void apply(const core::Tensor& grad_output,
                      const core::Tensor& A,
                      const core::Tensor& B,
                      core::Tensor& grad_A,
                      core::Tensor& grad_B);
};

/// Gradient for sum reduction: y = sum(x)
///
///   dL/dx = dL/dy (broadcast to x.shape)
struct SumBackward {
    static void apply(const core::Tensor& grad_output,
                      const core::Tensor& input,
                      core::Tensor& grad_input);
};

} // namespace autograd
} // namespace rootseed