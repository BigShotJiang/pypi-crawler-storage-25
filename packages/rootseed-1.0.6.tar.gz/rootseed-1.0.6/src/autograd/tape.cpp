// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// tape.cpp — Gradient Tape Implementation with Reverse-Mode Autodiff (Section 6.3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "autograd/tape.h"
#include "utils/log.h"
#include "utils/exception.h"

#include <algorithm>
#include <queue>
#include <stack>

using namespace rootseed::utils;

namespace rootseed {
namespace autograd {

// ============================================================================
// Thread-local instance
// ============================================================================

thread_local GradientTape GradientTape::instance_;

GradientTape& GradientTape::instance() {
    return instance_;
}

// ============================================================================
// Enable / Disable
// ============================================================================

void GradientTape::enable() {
    enabled_ = true;
    RS_LOG_DEBUG("GradientTape enabled");
}

void GradientTape::disable() {
    enabled_ = false;
    RS_LOG_DEBUG("GradientTape disabled");
}

// ============================================================================
// Record operation
// ============================================================================

Node* GradientTape::record_operation(
    const std::string& op_name,
    const std::vector<std::shared_ptr<core::Tensor>>& inputs,
    const std::vector<std::shared_ptr<core::Tensor>>& outputs,
    std::function<void()> backward_fn) {

    if (!enabled_) return nullptr;

    auto node = std::make_unique<Node>(op_name);
    node->inputs = inputs;
    node->outputs = outputs;
    node->backward_fn = std::move(backward_fn);

    Node* raw_ptr = node.get();
    nodes_.push_back(std::move(node));
    needs_reorder_ = true;

    return raw_ptr;
}

// ============================================================================
// Backward pass
// ============================================================================

void GradientTape::backward(const core::Tensor& seed) {
    if (nodes_.empty()) {
        RS_LOG_DEBUG("GradientTape: empty graph, nothing to backward");
        return;
    }

    RS_LOG_DEBUG("GradientTape: starting backward pass (" +
                 std::to_string(nodes_.size()) + " nodes)");

    // Find the output node (last node in the graph)
    Node* output_node = nodes_.back().get();

    // Seed the output gradient
    // For scalar loss, seed = 1.0 (∂L/∂L = 1)
    if (output_node->outputs.size() == 1) {
        auto& out = output_node->outputs[0];
        if (out) {
            // Set gradient of output to seed
            auto grad = std::make_shared<core::Tensor>(seed);
            out->set_grad(*grad);
        }
    }

    // Build reverse topological order
    auto order = build_topological_order(output_node);

    // Execute each node's backward function in reverse topo order
    for (auto* node : order) {
        if (node->backward_fn && !node->backward_called) {
            node->backward_fn();
            node->backward_called = true;
        }
    }

    // Accumulate gradients from output node back to leaves
    // For each node, propagate its output gradient to its inputs
    for (auto it = order.rbegin(); it != order.rend(); ++it) {
        Node* node = *it;
        if (!node->backward_fn) continue;

        // The backward_fn was already called above; now accumulate
        // gradients flowing from this node's outputs to its inputs
        for (size_t i = 0; i < node->outputs.size(); ++i) {
            auto& out = node->outputs[i];
            if (!out || out->grad().numel() == 0) continue;

            // For single-output ops, the gradient flows directly
            if (node->outputs.size() == 1 && node->inputs.size() == 1) {
                auto& in = node->inputs[0];
                if (in && in->requires_grad()) {
                    if (in->grad().numel() == 0) {
                        in->set_grad(out->grad());
                    } else {
                        in->set_grad(in->grad().add(out->grad()));
                    }
                }
            }
        }
    }

    RS_LOG_DEBUG("GradientTape: backward complete");
}

// ============================================================================
// Topological ordering (Kahn's algorithm)
// ============================================================================

std::vector<Node*> GradientTape::build_topological_order(Node* output_node) {
    std::vector<Node*> result;

    if (!output_node) {
        // Just return all nodes in insertion order
        for (auto& n : nodes_) {
            result.push_back(n.get());
        }
        return result;
    }

    // Build reverse edges and compute in-degree (ref_count)
    for (auto& n : nodes_) {
        n->ref_count = 0;
        n->next.clear();
    }

    // For now, we assume a linear chain (each node feeds into the next).
    // Full graph traversal would require tracking tensor→node dependencies,
    // which is handled by Tensor::graph_node_ in a more complete implementation.
    //
    // Simplified: nodes are already in forward order; reverse for backward.
    for (auto& n : nodes_) {
        result.push_back(n.get());
    }
    std::reverse(result.begin(), result.end());

    return result;
}

// ============================================================================
// Reset
// ============================================================================

void GradientTape::reset() {
    nodes_.clear();
    topo_order_.clear();
    needs_reorder_ = true;
    RS_LOG_DEBUG("GradientTape reset");
}

} // namespace autograd
} // namespace rootseed