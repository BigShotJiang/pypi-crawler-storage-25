// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// tape.h — Gradient Tape for Automatic Differentiation (Section 6.3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

#include <vector>
#include <memory>
#include <string>
#include <functional>
#include <unordered_set>

namespace rootseed {
namespace autograd {

// ============================================================================
// GraphNode — a single operation in the computation graph
//
// Each node stores:
//   - The operation name (for debugging)
//   - Input tensors that participated in the operation
//   - A backward function that computes gradients for all inputs
// ============================================================================

class GradientTape;

struct Node {
    std::string op_name;                              // "matmul", "add", "relu", etc.
    std::vector<std::shared_ptr<core::Tensor>> inputs;  // Tensors that were inputs to this op
    std::vector<std::shared_ptr<core::Tensor>> outputs; // Tensors produced by this op
    std::function<void()> backward_fn;                 // Gradient computation for this op
    bool backward_called = false;                      // Guard against double-backward

    // For topological ordering
    std::vector<Node*> next;   // Edges: this node's output → consumed by these nodes
    int ref_count = 0;         // Number of pending backward dependencies

    Node() = default;
    explicit Node(const std::string& name) : op_name(name) {}
};

// ============================================================================
// GradientTape — thread-local computation graph recorder
//
// Records operations as they execute. When backward() is called,
// traverses the graph in reverse topological order, calling each
// node's backward function exactly once.
//
// Equation (Section 6.3):
//   For matmul y = W · x:
//     dL/dW = dL/dy · x^T
//     dL/dx = W^T · dL/dy
// ============================================================================

class GradientTape {
public:
    /// Returns the thread-local GradientTape instance.
    static GradientTape& instance();

    /// Start recording operations. Called when a tensor with requires_grad=true
    /// is created or when entering a training scope.
    void enable();

    /// Stop recording operations.
    void disable();

    /// Returns true if the tape is currently recording.
    bool is_enabled() const noexcept { return enabled_; }

    /// Record a new operation node. Returns the node pointer for linking.
    Node* record_operation(const std::string& op_name,
                           const std::vector<std::shared_ptr<core::Tensor>>& inputs,
                           const std::vector<std::shared_ptr<core::Tensor>>& outputs,
                           std::function<void()> backward_fn);

    /// Execute backpropagation: traverse graph in reverse topological order
    /// and call each node's backward function. Seeds output gradients with
    /// the given seed (typically 1.0 for scalar loss).
    void backward(const core::Tensor& seed);

    /// Release all recorded nodes and reset the graph.
    void reset();

    /// Number of recorded operations in the graph.
    size_t node_count() const noexcept { return nodes_.size(); }

    /// Returns true if the graph is empty.
    bool is_empty() const noexcept { return nodes_.empty(); }

private:
    GradientTape() = default;

    /// Build a reverse topological ordering of nodes.
    std::vector<Node*> build_topological_order(Node* output_node);

    static thread_local GradientTape instance_;

    std::vector<std::unique_ptr<Node>> nodes_;  // Owns all nodes
    std::vector<Node*> topo_order_;             // Cached topological order
    bool enabled_ = false;
    bool needs_reorder_ = true;
};

} // namespace autograd
} // namespace rootseed