// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// functions.cpp — Gradient Function Implementations (Section 6.3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "autograd/functions.h"
#include "autograd/tape.h"

#include <algorithm>

namespace rootseed {
namespace autograd {

// ============================================================================
// MatmulBackward: dL/dA = dL/dy @ B^T,  dL/dB = A^T @ dL/dy
// ============================================================================

void MatmulBackward::apply(const core::Tensor& grad_output,
                            const core::Tensor& A,
                            const core::Tensor& B,
                            core::Tensor& grad_A,
                            core::Tensor& grad_B) {
    // dL/dA = grad_output @ B^T
    core::Tensor B_T = B.transpose();
    core::Tensor dA = grad_output.matmul(B_T);

    // Accumulate into grad_A
    if (grad_A.numel() == 0) {
        grad_A = dA;
    } else {
        grad_A = grad_A.add(dA);
    }

    // dL/dB = A^T @ grad_output
    core::Tensor A_T = A.transpose();
    core::Tensor dB = A_T.matmul(grad_output);

    // Accumulate into grad_B
    if (grad_B.numel() == 0) {
        grad_B = dB;
    } else {
        grad_B = grad_B.add(dB);
    }
}

// ============================================================================
// AddBackward: passes gradient through (addition distributes gradients)
// ============================================================================

void AddBackward::apply(const core::Tensor& grad_output,
                         const core::Tensor& /*A*/,
                         const core::Tensor& /*B*/,
                         core::Tensor& grad_A,
                         core::Tensor& grad_B) {
    // For simple element-wise add without broadcasting,
    // gradient passes through unchanged to both inputs.
    // Broadcasting is handled by the caller.

    if (grad_A.numel() == 0) {
        grad_A = grad_output;
    } else {
        grad_A = grad_A.add(grad_output);
    }

    if (grad_B.numel() == 0) {
        grad_B = grad_output;
    } else {
        grad_B = grad_B.add(grad_output);
    }
}

// ============================================================================
// ReluBackward: dL/dx = dL/dy  if x > 0, else 0
// ============================================================================

void ReluBackward::apply(const core::Tensor& grad_output,
                          const core::Tensor& input,
                          core::Tensor& grad_input) {
    // ReLU: y = max(0, x)
    // dL/dx_i = dL/dy_i  if x_i > 0
    //         = 0        if x_i <= 0

    core::Tensor relu_grad = core::Tensor::zeros(input.shape(), input.dtype(), input.device());

    int64_t n = input.numel();
    for (int64_t i = 0; i < n; ++i) {
        if (input.item(i) > 0.0f) {
            relu_grad.set_item(i, grad_output.item(i));
        }
    }

    if (grad_input.numel() == 0) {
        grad_input = relu_grad;
    } else {
        grad_input = grad_input.add(relu_grad);
    }
}

// ============================================================================
// MulBackward: dL/dA = dL/dy ⊙ B,  dL/dB = dL/dy ⊙ A
// ============================================================================

void MulBackward::apply(const core::Tensor& grad_output,
                         const core::Tensor& A,
                         const core::Tensor& B,
                         core::Tensor& grad_A,
                         core::Tensor& grad_B) {
    // dL/dA = grad_output * B
    core::Tensor dA = grad_output.mul(B);
    if (grad_A.numel() == 0) {
        grad_A = dA;
    } else {
        grad_A = grad_A.add(dA);
    }

    // dL/dB = grad_output * A
    core::Tensor dB = grad_output.mul(A);
    if (grad_B.numel() == 0) {
        grad_B = dB;
    } else {
        grad_B = grad_B.add(dB);
    }
}

// ============================================================================
// SumBackward: broadcasts scalar gradient to full input shape
// ============================================================================

void SumBackward::apply(const core::Tensor& grad_output,
                         const core::Tensor& input,
                         core::Tensor& grad_input) {
    // y = sum(x) → dL/dx_i = dL/dy for all i
    // The gradient is broadcast from scalar to input shape.

    // grad_output should be scalar (or we take its sum)
    float grad_val = 0.0f;
    int64_t n_out = grad_output.numel();
    for (int64_t i = 0; i < n_out; ++i) {
        grad_val += grad_output.item(i);
    }

    core::Tensor broadcast_grad = core::Tensor::ones(input.shape(), input.dtype(), input.device());
    int64_t n = input.numel();
    for (int64_t i = 0; i < n; ++i) {
        broadcast_grad.set_item(i, grad_val);
    }

    if (grad_input.numel() == 0) {
        grad_input = broadcast_grad;
    } else {
        grad_input = grad_input.add(broadcast_grad);
    }
}

} // namespace autograd
} // namespace rootseed