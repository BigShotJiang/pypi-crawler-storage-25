// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// kernels_cpu.h — SIMD-Optimized CPU Microkernels for Tiers 3-4, 12-14 (Section 4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

#include <cstddef>
#include <cstdint>

namespace rootseed {
namespace akd {
namespace cpu {

// ============================================================================
// CPU microkernel functions for common operations.
// These are dispatched to by AKD Tiers 3-4 (tiny tensors) and 12-14 (XNNPACK).
// ============================================================================

/// Matrix multiply: C = A @ B  (MxK @ KxN → MxN)
/// Optimized with register blocking for small matrices.
void matmul_small(const core::Tensor& A, const core::Tensor& B, core::Tensor& C);

/// ReLU activation: y = max(0, x)
void relu_inplace(core::Tensor& x);

/// Convolution 2D: out = conv2d(input, weight)
/// Im2col + matmul fallback for CPU.
void conv2d_small(const core::Tensor& input, const core::Tensor& weight,
                   core::Tensor& output,
                   int stride_h, int stride_w,
                   int pad_h, int pad_w);

/// Element-wise addition: y = A + B (with broadcasting)
void add_broadcast(const core::Tensor& A, const core::Tensor& B, core::Tensor& C);

} // namespace cpu
} // namespace akd
} // namespace rootseed