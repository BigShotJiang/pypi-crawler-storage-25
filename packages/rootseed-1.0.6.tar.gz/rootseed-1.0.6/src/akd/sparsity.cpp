// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// sparsity.cpp — Fast Sparsity Detection Implementation (Section 4.1)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "akd/sparsity.h"

#include <cmath>

namespace rootseed {
namespace akd {

float SparsityAnalyzer::compute_sparsity(const core::Tensor& tensor) {
    int64_t total = tensor.numel();
    if (total == 0) return 0.0f;

    int64_t zeros = count_zeros(tensor);
    return (static_cast<float>(zeros) / static_cast<float>(total)) * 100.0f;
}

bool SparsityAnalyzer::exceeds_sparsity(const core::Tensor& tensor, float threshold_pct) {
    int64_t total = tensor.numel();
    if (total == 0) return false;

    int64_t max_zeros_needed = static_cast<int64_t>(std::ceil(total * threshold_pct / 100.0f));
    int64_t zeros_found = 0;
    int64_t checked = 0;

    for (int64_t i = 0; i < total; ++i) {
        float val = tensor.item(i);
        if (std::abs(val) < 1e-8f) {
            zeros_found++;
        }
        checked++;

        // Early exit: can we still reach the threshold?
        int64_t max_possible_zeros = zeros_found + (total - checked);
        if (max_possible_zeros < max_zeros_needed) {
            return false;  // Threshold unreachable
        }
        // Early success: already reached threshold
        if (zeros_found >= max_zeros_needed) {
            return true;
        }
    }

    return zeros_found >= max_zeros_needed;
}

bool SparsityAnalyzer::is_structured_2_4(const core::Tensor& tensor) {
    int64_t total = tensor.numel();
    if (total < 4) return false;

    // Check every group of 4 elements: exactly 2 must be zero
    for (int64_t i = 0; i < total; i += 4) {
        int zeros = 0;
        int end = std::min(i + 4, total);
        int group_size = end - i;
        if (group_size < 4) break;  // Partial group at end — skip

        for (int j = i; j < i + 4; ++j) {
            if (std::abs(tensor.item(j)) < 1e-8f) zeros++;
        }
        if (zeros != 2) return false;
    }

    return true;
}

int64_t SparsityAnalyzer::count_nonzero(const core::Tensor& tensor) {
    int64_t count = 0;
    int64_t total = tensor.numel();
    for (int64_t i = 0; i < total; ++i) {
        if (std::abs(tensor.item(i)) >= 1e-8f) count++;
    }
    return count;
}

int64_t SparsityAnalyzer::count_zeros(const core::Tensor& tensor) {
    int64_t total = tensor.numel();
    return total - count_nonzero(tensor);
}

} // namespace akd
} // namespace rootseed