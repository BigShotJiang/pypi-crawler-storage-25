// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// cache.cpp — LRU Kernel Cache Implementation (Section 4.1)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "akd/cache.h"

#include <sstream>
#include <cstdint>

namespace rootseed {
namespace akd {

KernelCache::KernelCache(size_t max_entries)
    : max_entries_(max_entries) {}

const KernelDescriptor* KernelCache::get(const std::string& key) const {
    std::lock_guard<std::mutex> lock(mutex_);

    auto it = cache_.find(key);
    if (it != cache_.end()) {
        touch(key);
        return &it->second;
    }
    return nullptr;
}

void KernelCache::put(const std::string& key, const KernelDescriptor& desc) {
    std::lock_guard<std::mutex> lock(mutex_);

    // If key already exists, update and touch
    auto it = cache_.find(key);
    if (it != cache_.end()) {
        it->second = desc;
        touch(key);
        return;
    }

    // Evict oldest if at capacity
    if (cache_.size() >= max_entries_) {
        auto& oldest = access_list_.back();
        cache_.erase(oldest);
        iter_map_.erase(oldest);
        access_list_.pop_back();
    }

    // Insert new entry
    cache_[key] = desc;
    access_list_.push_front(key);
    iter_map_[key] = access_list_.begin();
}

void KernelCache::evict(const std::string& key) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = cache_.find(key);
    if (it != cache_.end()) {
        auto iter_it = iter_map_.find(key);
        if (iter_it != iter_map_.end()) {
            access_list_.erase(iter_it->second);
            iter_map_.erase(iter_it);
        }
        cache_.erase(it);
    }
}

void KernelCache::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    cache_.clear();
    access_list_.clear();
    iter_map_.clear();
}

size_t KernelCache::size() const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    return cache_.size();
}

void KernelCache::touch(const std::string& key) const {
    auto iter_it = iter_map_.find(key);
    if (iter_it != iter_map_.end()) {
        access_list_.splice(access_list_.begin(), access_list_, iter_it->second);
    }
}

std::string KernelCache::make_key(const DispatchContext& ctx) {
    std::ostringstream oss;
    oss << static_cast<int>(ctx.op_type) << "|"
        << ctx.shape_a.to_string() << "|"
        << ctx.shape_b.to_string() << "|"
        << static_cast<int>(ctx.dtype) << "|"
        << ctx.device.to_string() << "|"
        << std::fixed << ctx.sparsity_pct << "|"
        << (ctx.is_structured_2_4 ? "1" : "0") << "|"
        << ctx.fusion_pattern << "|"
        << (ctx.has_tensor_cores ? "1" : "0") << "|"
        << (ctx.has_avx512 ? "1" : "0") << "|"
        << (ctx.has_sve ? "1" : "0");
    return oss.str();
}

} // namespace akd
} // namespace rootseed