// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// sparsity.h — Sparsity Analysis for Kernel Selection (Section 4.1)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

#include <cstdint>
#include <cstddef>

namespace rootseed {
namespace akd {

// ============================================================================
// SparsityAnalyzer — detects sparsity patterns in tensors
//
// Used by AKD dispatcher to route to sparse kernels (Tiers 0-2) when:
//   - Sparsity > 70%  → CSR (2-200x speedup)
//   - Sparsity > 95%  → CSR with block optimization
//   - Sparsity > 98%  → BSR (100-500x speedup)
//   - Structured 2:4  → NVIDIA sparse tensor cores
// ============================================================================

class SparsityAnalyzer {
public:
    /// Compute the sparsity percentage of a tensor.
    /// Returns 0.0 (fully dense) to 100.0 (completely sparse).
    static float compute_sparsity(const core::Tensor& tensor);

    /// Quickly check if a tensor exceeds a sparsity threshold.
    /// Stops scanning early if threshold is unreachable.
    static bool exceeds_sparsity(const core::Tensor& tensor, float threshold_pct);

    /// Detect NVIDIA 2:4 structured sparsity pattern.
    /// Two out of every four consecutive elements must be exactly zero.
    static bool is_structured_2_4(const core::Tensor& tensor);

    /// Count non-zero elements (might be needed for sparse conversion).
    static int64_t count_nonzero(const core::Tensor& tensor);

    /// Count zeros in a tensor.
    static int64_t count_zeros(const core::Tensor& tensor);
};

} // namespace akd
} // namespace rootseed