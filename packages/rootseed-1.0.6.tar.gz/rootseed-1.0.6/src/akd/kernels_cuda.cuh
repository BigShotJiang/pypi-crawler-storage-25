// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// kernels_cuda.cuh — CUDA Kernel Headers: matmul, conv, relu, fused ops (Section 4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#ifdef __CUDACC__
#include <cuda_runtime.h>

namespace rootseed {
namespace akd {
namespace cuda {

// ============================================================================
// CUDA kernel declarations
// These kernels are dispatched to by AKD Tiers 5-6 (cuBLAS/TensorCores).
// ============================================================================

/// Matrix multiply kernel: C = A @ B
/// @param A    (M, K) input matrix
/// @param B    (K, N) input matrix
/// @param C    (M, N) output matrix
/// @param M, N, K  Dimensions
__global__ void matmul_kernel(const float* A, const float* B, float* C,
                               int M, int N, int K);

/// ReLU activation: y = max(0, x) — in-place
__global__ void relu_kernel(float* x, int n);

/// Convolution 2D forward: im2col + matmul approach
__global__ void conv2d_kernel(const float* input, const float* weight, float* output,
                               int N, int C_in, int H, int W,
                               int C_out, int kH, int kW,
                               int oH, int oW,
                               int stride_h, int stride_w,
                               int pad_h, int pad_w);

/// Fused Linear→ReLU kernel: output = ReLU(input @ W^T + b)
__global__ void fused_linear_relu_kernel(const float* input, const float* weight,
                                          const float* bias, float* output,
                                          int batch, int in_features, int out_features);

/// Fused Conv→BatchNorm→ReLU kernel
__global__ void fused_conv_bn_relu_kernel(const float* input, const float* weight,
                                           const float* bn_gamma, const float* bn_beta,
                                           float* output,
                                           int N, int C, int H, int W, int kH, int kW);

} // namespace cuda
} // namespace akd
} // namespace rootseed

#endif // __CUDACC__