// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// fusion.h — Operator Fusion Pattern Matching for Memory Optimization (Section 4.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <string>
#include <vector>
#include <string_view>

namespace rootseed {
namespace akd {

// ============================================================================
// FusionPattern — a recognized operation sequence that can be fused
//
// Section 4.2 lists 11 fused patterns:
//   Linear→ReLU→Dropout, Conv2D→BatchNorm→ReLU, QKV→Attention→Output,
//   Router→Dispatch→Experts→Combine (MoE), etc.
// ============================================================================

struct FusionPattern {
    std::string name;             // e.g., "fused_linear_relu_dropout"
    std::vector<std::string> ops; // Sequence: ["Linear", "ReLU", "Dropout"]
    double memory_reduction_pct;  // e.g., 67.0 for Linear→ReLU→Dropout
    double expected_speedup;      // e.g., 3.0x
};

// ============================================================================
// FusionMatcher — identifies fusion opportunities in op sequences
// ============================================================================

class FusionMatcher {
public:
    /// Returns the singleton instance with all registered patterns.
    static FusionMatcher& instance();

    /// Register a fusion pattern.
    void register_pattern(const FusionPattern& pattern);

    /// Given a sequence of operation names, return the best fusion pattern
    /// that matches (if any). Returns nullptr if no match.
    const FusionPattern* match(const std::vector<std::string>& op_sequence) const;

    /// Check if a specific 3-op sequence matches any known fusion pattern.
    bool is_fusable(const std::string& op1, const std::string& op2, const std::string& op3) const;

    /// Returns all registered patterns.
    const std::vector<FusionPattern>& patterns() const noexcept { return patterns_; }

private:
    FusionMatcher();
    std::vector<FusionPattern> patterns_;
};

} // namespace akd
} // namespace rootseed