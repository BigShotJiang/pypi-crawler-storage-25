// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dispatcher.h — Adaptive Kernel Dispatch: 15-Tier Kernel Selection (Section 4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"
#include "core/shape.h"
#include "dre/context.h"
#include "core/shape.h"

#include <string>
#include <functional>

namespace rootseed {
namespace akd {
using core::Shape;

// ============================================================================
// KernelTier — the 15 dispatch tiers (Section 4.1)
// ============================================================================

enum class KernelTier : uint8_t {
    // Sparse tiers (0-2): Extreme sparsity
    Tier0_BSR       = 0,   // Sparsity > 98% — Block Sparse Row
    Tier1_CSR_Block = 1,   // Sparsity > 95% — CSR with block optimization
    Tier2_CSR       = 2,   // Sparsity > 70% — CSR Matmul

    // Tiny tensor tiers (3-4): Bypass BLAS overhead
    Tier3_Micro     = 3,   // M,N,K < 32  — Hand-rolled SIMD microkernel
    Tier4_SIMD      = 4,   // M,N,K < 128 — SIMD with register blocking

    // GPU tiers (5-8): Dedicated accelerators
    Tier5_CuBLAS_TC = 5,   // CUDA + Tensor Cores
    Tier6_CuBLAS    = 6,   // CUDA + cuBLAS standard
    Tier7_MIOpen    = 7,   // ROCm + MIOpen
    Tier8_TPU       = 8,   // Google TPU XLA-compiled
    Tier9_NPU       = 9,   // Qualcomm/Apple NPU

    // Vulkan tiers (10-11): Cross-vendor GPU
    Tier10_VkSubgroup = 10, // Vulkan + subgroup operations
    Tier11_Vulkan      = 11, // Vulkan compute

    // CPU tiers (12-14): Optimized CPU
    Tier12_XNN_SVE  = 12,  // ARM + XNNPACK + SVE
    Tier13_XNN_NEON = 13,  // ARM + XNNPACK + NEON
    Tier14_XNN_SIMD = 14,  // CPU + XNNPACK + SIMD

    // Fallback (15): Always available
    Tier15_Reference = 15, // Reference CPU fallback
};

// ============================================================================
// Operation type
// ============================================================================

enum class OpType : uint8_t {
    Matmul,
    Conv2D,
    Add,
    Relu,
    Gelu,
    Silu,
    Dropout,
    LayerNorm,
    Softmax,
    Attention,
    Custom,
};

// ============================================================================
// Dispatch context — all information needed to select a kernel
// ============================================================================

struct DispatchContext {
    OpType op_type = OpType::Matmul;
    Shape shape_a;              // Shape of first operand
    Shape shape_b;              // Shape of second operand (for binary ops)
    Shape shape_out;            // Expected output shape
    core::DType dtype = core::DType::Float32;
    core::Device device;        // Target device

    // Sparsity information (populated by SparsityAnalyzer)
    float sparsity_pct = 0.0f;  // 0.0 = dense, 95.0 = 95% zeros
    bool is_structured_2_4 = false;

    // Fusion hint
    std::string fusion_pattern; // e.g., "linear_gelu_dropout"

    // Hardware context (cached from DRE)
    bool has_tensor_cores = false;
    bool has_fp8 = false;
    bool has_avx512 = false;
    bool has_sve = false;
    bool has_neon = false;
    size_t l1_cache_size = 0;
    size_t l2_cache_size = 0;
};

// ============================================================================
// Kernel descriptor — the selected kernel implementation
// ============================================================================

struct KernelDescriptor {
    KernelTier tier = KernelTier::Tier15_Reference;
    std::string name;
    std::string backend;       // e.g., "CUDA", "XNNPACK", "Reference"
    bool is_sparse = false;
    bool uses_fusion = false;
    double expected_speedup = 1.0;  // Relative to reference

    // Callable — executes the kernel on the given tensors
    std::function<void(core::Tensor&, const core::Tensor&, const core::Tensor&)> execute;
};

// ============================================================================
// Adaptive Kernel Dispatch
// ============================================================================

class AdaptiveKernelDispatch {
public:
    static AdaptiveKernelDispatch& instance();

    /// Initialize AKD with hardware context.
    void initialize();

    /// Select the optimal kernel for a given operation and context.
    KernelDescriptor select_kernel(const DispatchContext& ctx);

    /// Select tier based on sparsity alone.
    KernelTier tier_for_sparsity(float sparsity_pct) const;

    /// Select tier based on matrix dimensions.
    KernelTier tier_for_dimensions(int64_t M, int64_t N, int64_t K) const;

    /// Select tier based on hardware capabilities.
    KernelTier tier_for_hardware(const core::Device& device) const;

    /// Returns the full priority order of tiers.
    std::string tier_name(KernelTier tier) const;

private:
    AdaptiveKernelDispatch() = default;

    bool initialized_ = false;
    const dre::HardwareContextProvider* hw_ctx_;
};

} // namespace akd
} // namespace rootseed