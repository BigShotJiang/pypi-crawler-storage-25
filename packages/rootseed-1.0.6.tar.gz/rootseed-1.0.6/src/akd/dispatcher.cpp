// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dispatcher.cpp — 15-Tier Kernel Selection Logic (Section 4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "akd/dispatcher.h"
#include "utils/log.h"

#include <algorithm>
#include <cmath>

namespace rootseed {
namespace akd {

AdaptiveKernelDispatch& AdaptiveKernelDispatch::instance() {
    static AdaptiveKernelDispatch s_instance;
    return s_instance;
}

void AdaptiveKernelDispatch::initialize() {
    hw_ctx_ = &dre::HardwareContextProvider::instance();
    initialized_ = true;
    RS_LOG_INFO("AdaptiveKernelDispatch initialized");
}

// ============================================================================
// Main dispatch: analyze context → select optimal tier
// ============================================================================

KernelDescriptor AdaptiveKernelDispatch::select_kernel(const DispatchContext& ctx) {
    KernelDescriptor desc;

    // Priority 1: Extreme sparsity (Tiers 0-2)
    if (ctx.sparsity_pct > 98.0f) {
        desc.tier = KernelTier::Tier0_BSR;
        desc.is_sparse = true;
        desc.expected_speedup = 100.0;
    } else if (ctx.sparsity_pct > 95.0f) {
        desc.tier = KernelTier::Tier1_CSR_Block;
        desc.is_sparse = true;
        desc.expected_speedup = 50.0;
    } else if (ctx.sparsity_pct > 70.0f) {
        desc.tier = KernelTier::Tier2_CSR;
        desc.is_sparse = true;
        desc.expected_speedup = 10.0;
    }
    // Priority 2: Tiny dimensions (Tiers 3-4)
    else if (ctx.shape_a.numel() < 128 && ctx.shape_out.numel() < 128) {
        int64_t M = ctx.shape_a.ndim() > 0 ? ctx.shape_a[0] : 1;
        int64_t N = ctx.shape_out.ndim() > 0 ? ctx.shape_out[0] : 1;
        int64_t K = ctx.shape_a.ndim() > 1 ? ctx.shape_a[1] : 1;
        if (M < 32 && N < 32 && K < 32) {
            desc.tier = KernelTier::Tier3_Micro;
            desc.expected_speedup = 5.0;
        } else {
            desc.tier = KernelTier::Tier4_SIMD;
            desc.expected_speedup = 3.0;
        }
    }
    // Priority 3: GPU available (Tiers 5-9)
    else if (ctx.device.is_cuda()) {
        if (ctx.has_tensor_cores) {
            desc.tier = KernelTier::Tier5_CuBLAS_TC;
            desc.expected_speedup = 50.0;
        } else {
            desc.tier = KernelTier::Tier6_CuBLAS;
            desc.expected_speedup = 20.0;
        }
    } else if (ctx.device.is_rocm()) {
        desc.tier = KernelTier::Tier7_MIOpen;
        desc.expected_speedup = 18.0;
    } else if (ctx.device.is_tpu()) {
        desc.tier = KernelTier::Tier8_TPU;
        desc.expected_speedup = 30.0;
    } else if (ctx.device.is_npu()) {
        desc.tier = KernelTier::Tier9_NPU;
        desc.expected_speedup = 10.0;
    }
    // Priority 4: Vulkan (Tiers 10-11)
    else if (ctx.device.type == core::DeviceType::Vulkan) {
        desc.tier = KernelTier::Tier10_VkSubgroup;
        desc.expected_speedup = 8.0;
    }
    // Priority 5: CPU with XNNPACK (Tiers 12-14)
    else if (ctx.has_sve) {
        desc.tier = KernelTier::Tier12_XNN_SVE;
        desc.expected_speedup = 4.0;
    } else if (ctx.has_neon) {
        desc.tier = KernelTier::Tier13_XNN_NEON;
        desc.expected_speedup = 3.0;
    } else if (ctx.has_avx512) {
        desc.tier = KernelTier::Tier14_XNN_SIMD;
        desc.expected_speedup = 3.5;
    }
    // Fallback (Tier 15): Reference CPU
    else {
        desc.tier = KernelTier::Tier15_Reference;
        desc.expected_speedup = 1.0;
    }

    // Set human-readable name and backend
    desc.name = tier_name(desc.tier);

    switch (desc.tier) {
        case KernelTier::Tier0_BSR:        case KernelTier::Tier1_CSR_Block:
        case KernelTier::Tier2_CSR:        desc.backend = "Sparse";    break;
        case KernelTier::Tier3_Micro:      case KernelTier::Tier4_SIMD:
        case KernelTier::Tier14_XNN_SIMD:  desc.backend = "CPU";       break;
        case KernelTier::Tier5_CuBLAS_TC:  case KernelTier::Tier6_CuBLAS:
                                            desc.backend = "CUDA";      break;
        case KernelTier::Tier7_MIOpen:      desc.backend = "ROCm";      break;
        case KernelTier::Tier8_TPU:         desc.backend = "TPU";       break;
        case KernelTier::Tier9_NPU:         desc.backend = "NPU";       break;
        case KernelTier::Tier10_VkSubgroup: case KernelTier::Tier11_Vulkan:
                                            desc.backend = "Vulkan";    break;
        case KernelTier::Tier12_XNN_SVE:   case KernelTier::Tier13_XNN_NEON:
                                            desc.backend = "XNNPACK";   break;
        default:                            desc.backend = "Reference"; break;
    }

    return desc;
}

// ============================================================================
// Tier selection helpers
// ============================================================================

KernelTier AdaptiveKernelDispatch::tier_for_sparsity(float sparsity_pct) const {
    if (sparsity_pct > 98.0f)  return KernelTier::Tier0_BSR;
    if (sparsity_pct > 95.0f)  return KernelTier::Tier1_CSR_Block;
    if (sparsity_pct > 70.0f)  return KernelTier::Tier2_CSR;
    return KernelTier::Tier15_Reference;
}

KernelTier AdaptiveKernelDispatch::tier_for_dimensions(int64_t M, int64_t N, int64_t K) const {
    if (M < 32 && N < 32 && K < 32)  return KernelTier::Tier3_Micro;
    if (M < 128 && N < 128 && K < 128) return KernelTier::Tier4_SIMD;
    return KernelTier::Tier15_Reference;
}

KernelTier AdaptiveKernelDispatch::tier_for_hardware(const core::Device& device) const {
    if (device.is_cuda())   return KernelTier::Tier6_CuBLAS;
    if (device.is_rocm())   return KernelTier::Tier7_MIOpen;
    if (device.is_tpu())    return KernelTier::Tier8_TPU;
    if (device.is_npu())    return KernelTier::Tier9_NPU;
    return KernelTier::Tier15_Reference;
}

std::string AdaptiveKernelDispatch::tier_name(KernelTier tier) const {
    switch (tier) {
        case KernelTier::Tier0_BSR:         return "Tier0_BSR (>98% sparse)";
        case KernelTier::Tier1_CSR_Block:   return "Tier1_CSR_Block (>95% sparse)";
        case KernelTier::Tier2_CSR:         return "Tier2_CSR (>70% sparse)";
        case KernelTier::Tier3_Micro:       return "Tier3_Micro (M,N,K<32)";
        case KernelTier::Tier4_SIMD:        return "Tier4_SIMD (M,N,K<128)";
        case KernelTier::Tier5_CuBLAS_TC:   return "Tier5_CuBLAS_TensorCore";
        case KernelTier::Tier6_CuBLAS:      return "Tier6_CuBLAS";
        case KernelTier::Tier7_MIOpen:      return "Tier7_MIOpen";
        case KernelTier::Tier8_TPU:         return "Tier8_TPU";
        case KernelTier::Tier9_NPU:         return "Tier9_NPU";
        case KernelTier::Tier10_VkSubgroup: return "Tier10_Vulkan_Subgroup";
        case KernelTier::Tier11_Vulkan:     return "Tier11_Vulkan";
        case KernelTier::Tier12_XNN_SVE:    return "Tier12_XNNPACK_SVE";
        case KernelTier::Tier13_XNN_NEON:   return "Tier13_XNNPACK_NEON";
        case KernelTier::Tier14_XNN_SIMD:   return "Tier14_XNNPACK_SIMD";
        case KernelTier::Tier15_Reference:  return "Tier15_Reference";
    }
    return "Unknown";
}

} // namespace akd
} // namespace rootseed