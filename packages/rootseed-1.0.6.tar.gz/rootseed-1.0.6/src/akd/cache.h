// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// cache.h — LRU Kernel Cache for Compiled Kernels (Section 4.1, Step 4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "akd/dispatcher.h"

#include <string>
#include <unordered_map>
#include <list>
#include <mutex>

namespace rootseed {
namespace akd {

// ============================================================================
// KernelCache — thread-safe LRU cache for kernel descriptors
//
// Key = hash of (op_type, shapes, sparsity, fusion_pattern, hardware caps)
// Value = KernelDescriptor (including the compiled execute function)
//
// Caches the result of select_kernel() to avoid repeated dispatch analysis.
// ============================================================================

class KernelCache {
public:
    static constexpr size_t kDefaultMaxEntries = 1024;

    explicit KernelCache(size_t max_entries = kDefaultMaxEntries);

    /// Look up a kernel by key. Returns nullptr if not cached.
    const KernelDescriptor* get(const std::string& key) const;

    /// Store a kernel descriptor in the cache.
    void put(const std::string& key, const KernelDescriptor& desc);

    /// Remove a specific entry.
    void evict(const std::string& key);

    /// Clear all cached entries.
    void clear();

    /// Current number of cached entries.
    size_t size() const noexcept;

    /// Maximum cache capacity.
    size_t capacity() const noexcept { return max_entries_; }

    /// Build a cache key from a dispatch context.
    static std::string make_key(const DispatchContext& ctx);

private:
    mutable std::mutex mutex_;
    size_t max_entries_;

    // LRU: list stores keys in access order (most recent at front)
    mutable std::list<std::string> access_list_;
    std::unordered_map<std::string, KernelDescriptor> cache_;
    std::unordered_map<std::string, std::list<std::string>::iterator> iter_map_;

    void touch(const std::string& key) const;
};

} // namespace akd
} // namespace rootseed