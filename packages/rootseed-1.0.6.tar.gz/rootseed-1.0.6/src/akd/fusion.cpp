// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// fusion.cpp — Fusion Pattern Registry and Matching (Section 4.2)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "akd/fusion.h"

#include <algorithm>

namespace rootseed {
namespace akd {

FusionMatcher& FusionMatcher::instance() {
    static FusionMatcher s_instance;
    return s_instance;
}

FusionMatcher::FusionMatcher() {
    // Register all 11 fused patterns from Section 4.2
    patterns_ = {
        {"fused_linear_relu_dropout",      {"Linear", "ReLU", "Dropout"},        67.0, 3.0},
        {"fused_linear_gelu_dropout",      {"Linear", "GELU", "Dropout"},        67.0, 3.0},
        {"fused_linear_silu_dropout",      {"Linear", "SiLU", "Dropout"},        67.0, 3.0},
        {"fused_conv_bn_relu",             {"Conv2D", "BatchNorm", "ReLU"},      60.0, 2.5},
        {"fused_conv_bn_silu",             {"Conv2D", "BatchNorm", "SiLU"},      60.0, 2.5},
        {"fused_transformer_block",        {"LayerNorm", "Attention", "Residual"}, 50.0, 2.0},
        {"fused_llama_block",              {"RMSNorm", "Attention", "Residual"},  50.0, 2.0},
        {"fused_qkv_projection",           {"QKV", "Projection"},                66.0, 2.5},
        {"fused_attention_full",           {"QKV", "Attention", "Output"},       75.0, 3.5},
        {"fused_embedding_block",          {"Embedding", "LayerNorm", "Dropout"}, 50.0, 2.0},
        {"fused_moe_block",                {"Router", "Dispatch", "Experts", "Combine"}, 70.0, 4.0},
    };
}

void FusionMatcher::register_pattern(const FusionPattern& pattern) {
    patterns_.push_back(pattern);
}

const FusionPattern* FusionMatcher::match(const std::vector<std::string>& op_sequence) const {
    if (op_sequence.empty()) return nullptr;

    // Find the longest matching pattern
    const FusionPattern* best = nullptr;
    size_t best_len = 0;

    for (const auto& pattern : patterns_) {
        if (pattern.ops.size() > op_sequence.size()) continue;

        // Check if the pattern matches the end of the sequence
        bool matches = true;
        size_t offset = op_sequence.size() - pattern.ops.size();
        for (size_t i = 0; i < pattern.ops.size(); ++i) {
            if (op_sequence[offset + i] != pattern.ops[i]) {
                matches = false;
                break;
            }
        }

        if (matches && pattern.ops.size() > best_len) {
            best = &pattern;
            best_len = pattern.ops.size();
        }
    }

    return best;
}

bool FusionMatcher::is_fusable(const std::string& op1, const std::string& op2, const std::string& op3) const {
    std::vector<std::string> seq = {op1, op2, op3};
    return match(seq) != nullptr;
}

} // namespace akd
} // namespace rootseed