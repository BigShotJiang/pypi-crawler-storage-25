// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// kernels_metal.metal — Metal Shaders for Apple GPU: matmul, conv, relu (Section 4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include <metal_stdlib>
using namespace metal;

// ---- Matmul kernel ----
kernel void matmul_kernel(
    device const float* A [[buffer(0)]],
    device const float* B [[buffer(1)]],
    device float* C       [[buffer(2)]],
    constant int& M       [[buffer(3)]],
    constant int& N       [[buffer(4)]],
    constant int& K       [[buffer(5)]],
    uint2 gid             [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint col = gid.x;

    if (row < M && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
            sum += A[row * K + k] * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}

// ---- ReLU kernel ----
kernel void relu_kernel(
    device float* x [[buffer(0)]],
    constant int& n [[buffer(1)]],
    uint idx        [[thread_position_in_grid]])
{
    if (idx < n) {
        x[idx] = fmax(0.0f, x[idx]);
    }
}

// ---- Conv2D kernel ----
kernel void conv2d_kernel(
    device const float* input  [[buffer(0)]],
    device const float* weight [[buffer(1)]],
    device float* output       [[buffer(2)]],
    constant int& C_in         [[buffer(3)]],
    constant int& H            [[buffer(4)]],
    constant int& W            [[buffer(5)]],
    constant int& C_out        [[buffer(6)]],
    constant int& kH           [[buffer(7)]],
    constant int& kW           [[buffer(8)]],
    constant int& oH           [[buffer(9)]],
    constant int& oW           [[buffer(10)]],
    constant int& stride_h     [[buffer(11)]],
    constant int& stride_w     [[buffer(12)]],
    constant int& pad_h        [[buffer(13)]],
    constant int& pad_w        [[buffer(14)]],
    uint3 gid                  [[thread_position_in_grid]])
{
    uint ow = gid.x;
    uint oh = gid.y;
    uint oc = gid.z;

    if (oc >= C_out || oh >= oH || ow >= oW) return;

    float acc = 0.0f;
    for (int ic = 0; ic < C_in; ++ic) {
        for (int kh = 0; kh < kH; ++kh) {
            for (int kw = 0; kw < kW; ++kw) {
                int ih = (int)oh * stride_h + kh - pad_h;
                int iw = (int)ow * stride_w + kw - pad_w;
                if (ih >= 0 && ih < H && iw >= 0 && iw < W) {
                    acc += input[ic * H * W + ih * W + iw] *
                           weight[oc * C_in * kH * kW + ic * kH * kW + kh * kW + kw];
                }
            }
        }
    }
    output[oc * oH * oW + oh * oW + ow] = acc;
}

// ---- Fused Linear→ReLU kernel ----
kernel void fused_linear_relu_kernel(
    device const float* input  [[buffer(0)]],
    device const float* weight [[buffer(1)]],
    device const float* bias   [[buffer(2)]],
    device float* output       [[buffer(3)]],
    constant int& batch        [[buffer(4)]],
    constant int& in_features  [[buffer(5)]],
    constant int& out_features [[buffer(6)]],
    uint2 gid                  [[thread_position_in_grid]])
{
    uint b = gid.x;
    uint oc = gid.y;

    if (b >= batch || oc >= out_features) return;

    float sum = (bias != nullptr) ? bias[oc] : 0.0f;
    for (int ic = 0; ic < in_features; ++ic) {
        sum += input[b * in_features + ic] * weight[oc * in_features + ic];
    }
    output[b * out_features + oc] = fmax(0.0f, sum);
}