// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// loader.h — DataLoader with Multi-Worker Prefetching and Aleam Shuffling (Section 14.1)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "data/dataset.h"
#include "data/sampler.h"

#include <vector>
#include <memory>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <atomic>

namespace rootseed {
namespace data {

// ============================================================================
// DataLoader — iterates over a Dataset in batches
//
// Features:
//   - Multi-worker prefetching (parallel data loading)
//   - Aleam-based true random shuffling (no PRNG)
//   - Optional pin_memory for fast CPU→GPU transfer
//   - Batch collation with stacking
// ============================================================================

class DataLoader {
public:
    /// Create a DataLoader.
    /// @param dataset      Source dataset
    /// @param batch_size   Number of samples per batch
    /// @param shuffle      If true, shuffle indices each epoch (Aleam true random)
    /// @param num_workers  Number of prefetch worker threads (0 = single-threaded)
    /// @param pin_memory   If true, pin memory for fast GPU transfer
    /// @param drop_last    If true, drop incomplete last batch
    DataLoader(std::shared_ptr<Dataset> dataset,
               int64_t batch_size,
               bool shuffle = true,
               size_t num_workers = 0,
               bool pin_memory = false,
               bool drop_last = false);

    ~DataLoader();

    /// Returns the total number of batches per epoch.
    int64_t num_batches() const;

    /// Get the next batch. Returns empty vector when epoch is complete.
    std::vector<core::Tensor> next_batch();

    /// Reset to the beginning of the dataset (with reshuffling if enabled).
    void reset();

    size_t batch_size() const noexcept { return batch_size_; }
    int64_t dataset_size() const noexcept { return dataset_->size(); }

private:
    void generate_indices();
    void worker_loop(size_t worker_id);

    std::shared_ptr<Dataset> dataset_;
    int64_t batch_size_;
    bool shuffle_;
    size_t num_workers_;
    bool pin_memory_;
    bool drop_last_;

    std::vector<int64_t> indices_;
    int64_t current_index_ = 0;

    // Prefetching
    std::vector<std::thread> workers_;
    std::queue<std::vector<core::Tensor>> prefetch_queue_;
    std::mutex queue_mutex_;
    std::condition_variable queue_cv_;
    std::atomic<bool> stop_workers_{false};
};

} // namespace data
} // namespace rootseed