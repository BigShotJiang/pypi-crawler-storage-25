// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// sampler.h — Sampling Strategies: Sequential, Random, Batch (Section 14)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <vector>
#include <cstdint>
#include <memory>

namespace rootseed {
namespace data {

class Dataset;

// ============================================================================
// Sampler — base class for index sampling strategies
// ============================================================================

class Sampler {
public:
    virtual ~Sampler() = default;

    /// Generate an iterator over indices for one epoch.
    virtual std::vector<int64_t> generate_indices(int64_t dataset_size) = 0;

    /// Returns the number of samples per epoch.
    virtual int64_t num_samples(int64_t dataset_size) const { return dataset_size; }
};

// ============================================================================
// SequentialSampler — indices in order: 0, 1, 2, ...
// ============================================================================

class SequentialSampler : public Sampler {
public:
    std::vector<int64_t> generate_indices(int64_t dataset_size) override;
};

// ============================================================================
// RandomSampler — true random permutation of indices (Aleam, no PRNG)
// ============================================================================

class RandomSampler : public Sampler {
public:
    explicit RandomSampler(bool replacement = false, int64_t num_samples = -1);

    std::vector<int64_t> generate_indices(int64_t dataset_size) override;
    int64_t num_samples(int64_t dataset_size) const override;

private:
    bool replacement_;
    int64_t num_samples_;  // -1 = all samples
};

// ============================================================================
// BatchSampler — wraps a sampler and batches its output
// ============================================================================

class BatchSampler {
public:
    BatchSampler(std::shared_ptr<Sampler> sampler, int64_t batch_size, bool drop_last = false);

    /// Generate batched indices.
    std::vector<std::vector<int64_t>> generate_batches(int64_t dataset_size);

    int64_t batch_size() const noexcept { return batch_size_; }

private:
    std::shared_ptr<Sampler> sampler_;
    int64_t batch_size_;
    bool drop_last_;
};

} // namespace data
} // namespace rootseed