// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// loader.cpp — DataLoader Implementation with Aleam Shuffling (Section 14.1)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "data/loader.h"

#include <algorithm>
#include <cstdlib>
#include <ctime>

namespace rootseed {
namespace data {

DataLoader::DataLoader(std::shared_ptr<Dataset> dataset,
                       int64_t batch_size,
                       bool shuffle,
                       size_t num_workers,
                       bool pin_memory,
                       bool drop_last)
    : dataset_(std::move(dataset))
    , batch_size_(batch_size)
    , shuffle_(shuffle)
    , num_workers_(num_workers > 0 ? num_workers : 1)
    , pin_memory_(pin_memory)
    , drop_last_(drop_last) {

    generate_indices();

    // Start worker threads for prefetching
    for (size_t i = 0; i < num_workers_; ++i) {
        workers_.emplace_back(&DataLoader::worker_loop, this, i);
    }
}

DataLoader::~DataLoader() {
    stop_workers_ = true;
    queue_cv_.notify_all();
    for (auto& w : workers_) {
        if (w.joinable()) w.join();
    }
}

void DataLoader::generate_indices() {
    int64_t n = dataset_->size();
    indices_.resize(n);
    for (int64_t i = 0; i < n; ++i) {
        indices_[i] = i;
    }

    if (shuffle_) {
        // Aleam true random shuffle (Section 8.3).
        // In production, this calls rootseed.random.get_rng().shuffle(indices_).
        // Placeholder: Fisher-Yates with simple hash for deterministic fallback.
        uint64_t seed = static_cast<uint64_t>(std::time(nullptr));
        for (int64_t i = n - 1; i > 0; --i) {
            seed = seed * 6364136223846793005ULL + 1442695040888963407ULL;
            int64_t j = static_cast<int64_t>((seed >> 33) % (i + 1));
            std::swap(indices_[i], indices_[j]);
        }
    }
}

int64_t DataLoader::num_batches() const {
    int64_t n = dataset_->size();
    int64_t batches = n / batch_size_;
    if (n % batch_size_ != 0 && !drop_last_) {
        batches++;
    }
    return batches;
}

std::vector<core::Tensor> DataLoader::next_batch() {
    if (current_index_ >= static_cast<int64_t>(indices_.size())) {
        return {};  // Epoch complete
    }

    int64_t end = std::min(current_index_ + batch_size_, static_cast<int64_t>(indices_.size()));
    if (end - current_index_ < batch_size_ && drop_last_) {
        return {};  // Drop incomplete batch
    }

    std::vector<int64_t> batch_indices(indices_.begin() + current_index_,
                                        indices_.begin() + end);
    current_index_ = end;

    return dataset_->get_batch(batch_indices);
}

void DataLoader::reset() {
    current_index_ = 0;
    generate_indices();  // Reshuffle
}

void DataLoader::worker_loop(size_t /*worker_id*/) {
    // Background prefetch worker — loads next batches ahead of time.
    // Simplification: workers are started but batch loading is on-demand.
    // Full implementation would populate prefetch_queue_ with pre-loaded batches.
}

} // namespace data
} // namespace rootseed