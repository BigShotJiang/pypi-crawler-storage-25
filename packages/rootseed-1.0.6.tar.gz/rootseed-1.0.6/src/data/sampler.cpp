// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// sampler.cpp — Sampling Strategy Implementations
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "data/sampler.h"

#include <algorithm>
#include <cstdlib>
#include <ctime>

namespace rootseed {
namespace data {

// ============================================================================
// SequentialSampler
// ============================================================================

std::vector<int64_t> SequentialSampler::generate_indices(int64_t dataset_size) {
    std::vector<int64_t> indices(dataset_size);
    for (int64_t i = 0; i < dataset_size; ++i) {
        indices[i] = i;
    }
    return indices;
}

// ============================================================================
// RandomSampler
// ============================================================================

RandomSampler::RandomSampler(bool replacement, int64_t num_samples)
    : replacement_(replacement)
    , num_samples_(num_samples) {}

std::vector<int64_t> RandomSampler::generate_indices(int64_t dataset_size) {
    int64_t n = (num_samples_ > 0) ? num_samples_ : dataset_size;
    std::vector<int64_t> indices(n);

    if (replacement_) {
        // Sample with replacement
        uint64_t seed = static_cast<uint64_t>(std::time(nullptr));
        for (int64_t i = 0; i < n; ++i) {
            seed = seed * 6364136223846793005ULL + 1442695040888963407ULL;
            indices[i] = static_cast<int64_t>((seed >> 33) % dataset_size);
        }
    } else {
        // Permutation
        indices = SequentialSampler().generate_indices(dataset_size);
        if (n < dataset_size) {
            indices.resize(n);
        }
        // Fisher-Yates shuffle
        uint64_t seed = static_cast<uint64_t>(std::time(nullptr));
        for (int64_t i = static_cast<int64_t>(indices.size()) - 1; i > 0; --i) {
            seed = seed * 6364136223846793005ULL + 1442695040888963407ULL;
            int64_t j = static_cast<int64_t>((seed >> 33) % (i + 1));
            std::swap(indices[i], indices[j]);
        }
    }

    return indices;
}

int64_t RandomSampler::num_samples(int64_t dataset_size) const {
    return (num_samples_ > 0) ? num_samples_ : dataset_size;
}

// ============================================================================
// BatchSampler
// ============================================================================

BatchSampler::BatchSampler(std::shared_ptr<Sampler> sampler, int64_t batch_size, bool drop_last)
    : sampler_(std::move(sampler))
    , batch_size_(batch_size)
    , drop_last_(drop_last) {}

std::vector<std::vector<int64_t>> BatchSampler::generate_batches(int64_t dataset_size) {
    auto indices = sampler_->generate_indices(dataset_size);
    std::vector<std::vector<int64_t>> batches;

    int64_t n = indices.size();
    int64_t num_batches = n / batch_size_;
    if (n % batch_size_ != 0 && !drop_last_) num_batches++;

    for (int64_t b = 0; b < num_batches; ++b) {
        int64_t start = b * batch_size_;
        int64_t end = std::min(start + batch_size_, n);
        if (end - start < batch_size_ && drop_last_) break;
        batches.emplace_back(indices.begin() + start, indices.begin() + end);
    }

    return batches;
}

} // namespace data
} // namespace rootseed