// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dataset.cpp — Dataset Implementations
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "data/dataset.h"

#include <stdexcept>

namespace rootseed {
namespace data {

// ============================================================================
// Dataset base
// ============================================================================

std::vector<core::Tensor> Dataset::get_batch(const std::vector<int64_t>& indices) const {
    std::vector<core::Tensor> batch;
    for (auto idx : indices) {
        batch.push_back(get(idx));
    }
    return batch;
}

// ============================================================================
// TensorDataset
// ============================================================================

TensorDataset::TensorDataset(const core::Tensor& data, const core::Tensor& labels)
    : data_(data)
    , labels_(labels)
    , has_labels_(labels.numel() > 0) {}

int64_t TensorDataset::size() const {
    return data_.shape().ndim() > 0 ? data_.shape()[0] : 0;
}

core::Tensor TensorDataset::get(int64_t index) const {
    if (index < 0 || index >= size()) {
        throw std::out_of_range("TensorDataset index out of range: " + std::to_string(index));
    }
    return data_;  // Simplified: return single element slice in production
}

std::vector<core::Tensor> TensorDataset::get_batch(const std::vector<int64_t>& indices) const {
    // Stack data samples
    int64_t batch_size = indices.size();
    auto sample = get(indices[0]);
    int64_t sample_size = sample.numel();

    core::Shape batch_shape({batch_size});
    // Append sample dims
    // Simplified: flatten all samples into (batch, total_elements)
    core::Tensor batch_data = core::Tensor::zeros(
        core::Shape({batch_size, sample_size}), sample.dtype(), sample.device());

    for (int64_t i = 0; i < batch_size; ++i) {
        auto s = get(indices[i]);
        for (int64_t j = 0; j < sample_size; ++j) {
            batch_data.set_item(i, j, s.item(j));
        }
    }

    return {batch_data};
}

// ============================================================================
// MapDataset
// ============================================================================

MapDataset::MapDataset(std::shared_ptr<Dataset> source, TransformFn transform)
    : source_(std::move(source))
    , transform_(std::move(transform)) {}

int64_t MapDataset::size() const {
    return source_->size();
}

core::Tensor MapDataset::get(int64_t index) const {
    return transform_(source_->get(index));
}

} // namespace data
} // namespace rootseed