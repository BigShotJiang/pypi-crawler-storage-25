// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// dataset.h — Dataset Abstraction: TensorDataset, MapDataset (Section 14)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

#include <vector>
#include <memory>
#include <string>
#include <functional>

namespace rootseed {
namespace data {

// ============================================================================
// Dataset — abstract base for all datasets
// ============================================================================

class Dataset {
public:
    virtual ~Dataset() = default;

    /// Return the number of samples in the dataset.
    virtual int64_t size() const = 0;

    /// Return a single sample as a tensor or pair of tensors (data, label).
    virtual core::Tensor get(int64_t index) const = 0;

    /// Return a batch of samples as stacked tensors.
    virtual std::vector<core::Tensor> get_batch(const std::vector<int64_t>& indices) const;
};

// ============================================================================
// TensorDataset — dataset wrapping tensors (data and optional labels)
// ============================================================================

class TensorDataset : public Dataset {
public:
    /// Create from data tensors (and optional labels).
    TensorDataset(const core::Tensor& data, const core::Tensor& labels = core::Tensor());

    int64_t size() const override;
    core::Tensor get(int64_t index) const override;
    std::vector<core::Tensor> get_batch(const std::vector<int64_t>& indices) const override;

    const core::Tensor& data()   const noexcept { return data_; }
    const core::Tensor& labels() const noexcept { return labels_; }

private:
    core::Tensor data_;
    core::Tensor labels_;
    bool has_labels_;
};

// ============================================================================
// MapDataset — dataset from a custom transform function
// ============================================================================

class MapDataset : public Dataset {
public:
    using TransformFn = std::function<core::Tensor(const core::Tensor&)>;

    MapDataset(std::shared_ptr<Dataset> source, TransformFn transform);

    int64_t size() const override;
    core::Tensor get(int64_t index) const override;

private:
    std::shared_ptr<Dataset> source_;
    TransformFn transform_;
};

} // namespace data
} // namespace rootseed