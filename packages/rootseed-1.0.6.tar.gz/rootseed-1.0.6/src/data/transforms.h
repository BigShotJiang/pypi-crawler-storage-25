// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// transforms.h — Data Augmentation Transforms: Normalize, RandomCrop, RandomFlip
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "core/tensor.h"

#include <vector>
#include <memory>
#include <functional>

namespace rootseed {
namespace data {

// ============================================================================
// Transform — base functor for data transformations
// ============================================================================

using TransformFn = std::function<core::Tensor(const core::Tensor&)>;

// ============================================================================
// Compose — chains multiple transforms sequentially
// ============================================================================

class Compose {
public:
    explicit Compose(const std::vector<TransformFn>& transforms);

    core::Tensor operator()(const core::Tensor& input) const;

private:
    std::vector<TransformFn> transforms_;
};

// ============================================================================
// Normalize — (x - mean) / std
// ============================================================================

class Normalize {
public:
    Normalize(float mean, float std);

    core::Tensor operator()(const core::Tensor& input) const;

private:
    float mean_;
    float std_;
};

// ============================================================================
// RandomCrop — randomly crop a patch from the input tensor
// ============================================================================

class RandomCrop {
public:
    RandomCrop(int64_t crop_height, int64_t crop_width);

    core::Tensor operator()(const core::Tensor& input) const;

private:
    int64_t crop_h_, crop_w_;
};

// ============================================================================
// RandomFlip — randomly flip tensor horizontally/vertically
// ============================================================================

class RandomFlip {
public:
    explicit RandomFlip(float prob = 0.5f, bool horizontal = true, bool vertical = false);

    core::Tensor operator()(const core::Tensor& input) const;

private:
    float prob_;
    bool horizontal_;
    bool vertical_;
};

} // namespace data
} // namespace rootseed