// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// adamw.h — AdamW Optimizer with Decoupled Weight Decay
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "optim/optimizer.h"

namespace rootseed {
namespace optim {

// ============================================================================
// AdamW — Adam with decoupled weight decay
//
// Unlike Adam, weight decay is applied directly to weights, not via gradient:
//   W_t = W_{t-1} - lr * (m̂_t / (√v̂_t + ε) + weight_decay * W_{t-1})
// ============================================================================

class AdamW : public Optimizer {
public:
    AdamW(float lr = 0.001f, float beta1 = 0.9f, float beta2 = 0.999f,
          float eps = 1e-8f, float weight_decay = 0.01f);

    void step() override;

private:
    float beta1_;
    float beta2_;
    float eps_;
    float weight_decay_;
};

} // namespace optim
} // namespace rootseed