// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// optimizer.h — Base Optimizer Class: step(), zero_grad(), param_groups (Section 6.4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "nn/parameter.h"

#include <vector>
#include <memory>
#include <string>
#include <unordered_map>

namespace rootseed {
namespace optim {

// ============================================================================
// ParamGroup — a group of parameters with shared hyperparameters
// ============================================================================

struct ParamGroup {
    std::vector<std::shared_ptr<nn::Parameter>> params;
    float lr = 0.001f;
    float weight_decay = 0.0f;
    // Optimizer-specific state stored per parameter (e.g., momentum, velocity)
    std::unordered_map<void*, std::vector<float>> state;
};

// ============================================================================
// Optimizer — base class for all optimization algorithms
// ============================================================================

class Optimizer {
public:
    explicit Optimizer(float lr = 0.001f);
    virtual ~Optimizer() = default;

    /// Add a parameter group.
    void add_param_group(const std::vector<std::shared_ptr<nn::Parameter>>& params,
                         float lr = -1.0f, float weight_decay = 0.0f);

    /// Perform one optimization step for all registered parameters.
    virtual void step() = 0;

    /// Zero all gradients for all registered parameters.
    void zero_grad();

    /// Set the learning rate for all parameter groups.
    void set_lr(float lr);

    /// Returns all registered parameters across all groups.
    std::vector<std::shared_ptr<nn::Parameter>> all_parameters() const;

    /// Returns the current learning rate (of the first group).
    float lr() const noexcept;

    /// Number of parameter groups.
    size_t group_count() const noexcept { return param_groups_.size(); }

protected:
    std::vector<ParamGroup> param_groups_;
    float default_lr_;
    int step_count_ = 0;  // Number of step() calls
};

} // namespace optim
} // namespace rootseed