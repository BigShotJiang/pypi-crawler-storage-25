// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// lion.h — Lion Optimizer (EvoLved Sign Momentum)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "optim/optimizer.h"

namespace rootseed {
namespace optim {

// ============================================================================
// Lion — EvoLved Sign Momentum
//
// Update rule:
//   c_t = β₁ * m_{t-1} + (1 - β₁) * g_t
//   m_t = β₂ * m_{t-1} + (1 - β₂) * g_t
//   W_t = W_{t-1} - lr * (sign(c_t) + weight_decay * W_{t-1})
// ============================================================================

class Lion : public Optimizer {
public:
    Lion(float lr = 1e-4f, float beta1 = 0.9f, float beta2 = 0.99f,
         float weight_decay = 0.0f);

    void step() override;

private:
    float beta1_;
    float beta2_;
    float weight_decay_;
};

} // namespace optim
} // namespace rootseed