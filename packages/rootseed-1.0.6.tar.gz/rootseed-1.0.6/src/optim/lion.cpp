// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// lion.cpp — Lion Optimizer Implementation
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "optim/lion.h"

#include <cmath>
#include <algorithm>

namespace rootseed {
namespace optim {

Lion::Lion(float lr, float beta1, float beta2, float weight_decay)
    : Optimizer(lr)
    , beta1_(beta1)
    , beta2_(beta2)
    , weight_decay_(weight_decay) {}

void Lion::step() {
    step_count_++;

    for (auto& group : param_groups_) {
        float lr = group.lr;

        for (size_t i = 0; i < group.params.size(); ++i) {
            auto& p = group.params[i];
            core::Tensor& param_data = p->data();
            core::Tensor& grad = p->grad();

            if (grad.numel() == 0) continue;

            int64_t n = param_data.numel();

            void* key = p.get();
            auto& state = group.state[key];
            if (state.empty()) {
                state.resize(n, 0.0f);  // momentum m
            }

            float* m = state.data();

            for (int64_t j = 0; j < n; ++j) {
                float g = grad.item(j);

                // c = β₁ * m + (1 - β₁) * g  (update direction)
                float c = beta1_ * m[j] + (1.0f - beta1_) * g;

                // m = β₂ * m + (1 - β₂) * g  (new momentum)
                m[j] = beta2_ * m[j] + (1.0f - beta2_) * g;

                // Update: sign(c)
                float update = (c > 0.0f) ? lr : ((c < 0.0f) ? -lr : 0.0f);

                // Weight decay
                float w_decay = lr * weight_decay_ * param_data.item(j);

                param_data.set_item(j, param_data.item(j) - update - w_decay);
            }
        }
    }
}

} // namespace optim
} // namespace rootseed