// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// sgd.cpp — SGD Optimizer Implementation
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "optim/sgd.h"

#include <cmath>

namespace rootseed {
namespace optim {

SGD::SGD(float lr, float momentum, float dampening, float weight_decay, bool nesterov)
    : Optimizer(lr)
    , momentum_(momentum)
    , dampening_(dampening)
    , weight_decay_(weight_decay)
    , nesterov_(nesterov) {}

void SGD::step() {
    step_count_++;

    for (auto& group : param_groups_) {
        float lr = group.lr;

        for (size_t i = 0; i < group.params.size(); ++i) {
            auto& p = group.params[i];
            core::Tensor& param_data = p->data();
            core::Tensor& grad = p->grad();

            if (grad.numel() == 0) continue;

            int64_t n = param_data.numel();

            // Get or create momentum buffer for this parameter
            void* key = p.get();
            auto& state = group.state[key];
            if (state.empty()) {
                state.resize(n, 0.0f);  // Initialize momentum to zero
            }

            // Apply weight decay
            if (weight_decay_ > 0.0f) {
                for (int64_t j = 0; j < n; ++j) {
                    grad.set_item(j, grad.item(j) + weight_decay_ * param_data.item(j));
                }
            }

            // Momentum update
            if (momentum_ > 0.0f) {
                for (int64_t j = 0; j < n; ++j) {
                    float g = grad.item(j);
                    // v = momentum * v + dampening * g
                    state[j] = momentum_ * state[j] + (1.0f - dampening_) * g;

                    float update = state[j];
                    if (nesterov_) {
                        // Nesterov: g = g + momentum * v
                        update = g + momentum_ * state[j];
                    }
                    param_data.set_item(j, param_data.item(j) - lr * update);
                }
            } else {
                // Vanilla SGD
                for (int64_t j = 0; j < n; ++j) {
                    param_data.set_item(j, param_data.item(j) - lr * grad.item(j));
                }
            }
        }
    }
}

} // namespace optim
} // namespace rootseed