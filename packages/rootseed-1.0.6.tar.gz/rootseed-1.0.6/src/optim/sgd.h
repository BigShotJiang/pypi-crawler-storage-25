// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// sgd.h — Stochastic Gradient Descent with Momentum and Nesterov
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "optim/optimizer.h"

namespace rootseed {
namespace optim {

// ============================================================================
// SGD — Stochastic Gradient Descent
//
// Update rule:
//   v_t = momentum * v_{t-1} + dampening * g_t
//   if nesterov: g_t = g_t + momentum * v_t
//   w_t = w_{t-1} - lr * (g_t + weight_decay * w_{t-1})
// ============================================================================

class SGD : public Optimizer {
public:
    SGD(float lr = 0.01f, float momentum = 0.0f, float dampening = 0.0f,
        float weight_decay = 0.0f, bool nesterov = false);

    void step() override;

private:
    float momentum_;
    float dampening_;
    float weight_decay_;
    bool nesterov_;
};

} // namespace optim
} // namespace rootseed