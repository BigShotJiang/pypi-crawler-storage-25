// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// adam.cpp — Adam Optimizer Implementation with Bias Correction (Section 6.4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "optim/adam.h"

#include <cmath>

namespace rootseed {
namespace optim {

Adam::Adam(float lr, float beta1, float beta2, float eps, float weight_decay)
    : Optimizer(lr)
    , beta1_(beta1)
    , beta2_(beta2)
    , eps_(eps)
    , weight_decay_(weight_decay) {}

void Adam::step() {
    step_count_++;

    float bias_correction1 = 1.0f - std::pow(beta1_, step_count_);
    float bias_correction2 = 1.0f - std::pow(beta2_, step_count_);

    for (auto& group : param_groups_) {
        float lr = group.lr;

        for (size_t i = 0; i < group.params.size(); ++i) {
            auto& p = group.params[i];
            core::Tensor& param_data = p->data();
            core::Tensor& grad = p->grad();

            if (grad.numel() == 0) continue;

            int64_t n = param_data.numel();

            // Get or create state buffers (m and v)
            void* key = p.get();
            auto& state = group.state[key];
            if (state.empty()) {
                state.resize(n * 2, 0.0f);  // First n: m, next n: v
            }

            float* m = state.data();
            float* v = state.data() + n;

            for (int64_t j = 0; j < n; ++j) {
                float g = grad.item(j);

                // Weight decay
                if (weight_decay_ > 0.0f) {
                    g += weight_decay_ * param_data.item(j);
                }

                // Adam update: m_t = β₁ * m + (1-β₁) * g
                m[j] = beta1_ * m[j] + (1.0f - beta1_) * g;

                // v_t = β₂ * v + (1-β₂) * g²
                v[j] = beta2_ * v[j] + (1.0f - beta2_) * g * g;

                // Bias correction
                float m_hat = m[j] / bias_correction1;
                float v_hat = v[j] / bias_correction2;

                // Update: W = W - lr * m_hat / (√v_hat + ε)
                float update = lr * m_hat / (std::sqrt(v_hat) + eps_);
                param_data.set_item(j, param_data.item(j) - update);
            }
        }
    }
}

} // namespace optim
} // namespace rootseed