// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// scheduler.cpp — Learning Rate Scheduler Implementations
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "optim/scheduler.h"

#include <cmath>
#include <algorithm>
#include <limits>

namespace rootseed {
namespace optim {

// ============================================================================
// LRScheduler base
// ============================================================================

LRScheduler::LRScheduler(std::shared_ptr<Optimizer> optimizer)
    : optimizer_(optimizer)
    , base_lr_(optimizer->lr()) {}

void LRScheduler::step() {
    step_count_++;
}

float LRScheduler::get_lr() const noexcept {
    return optimizer_->lr();
}

// ============================================================================
// StepLR
// ============================================================================

StepLR::StepLR(std::shared_ptr<Optimizer> optimizer, int step_size, float gamma)
    : LRScheduler(optimizer)
    , step_size_(step_size)
    , gamma_(gamma) {}

void StepLR::step() {
    LRScheduler::step();
    if (step_count_ % step_size_ == 0) {
        float new_lr = get_lr() * gamma_;
        optimizer_->set_lr(new_lr);
    }
}

// ============================================================================
// MultiStepLR
// ============================================================================

MultiStepLR::MultiStepLR(std::shared_ptr<Optimizer> optimizer,
                         const std::vector<int>& milestones, float gamma)
    : LRScheduler(optimizer)
    , milestones_(milestones)
    , gamma_(gamma) {
    std::sort(milestones_.begin(), milestones_.end());
}

void MultiStepLR::step() {
    LRScheduler::step();
    for (int m : milestones_) {
        if (step_count_ == m) {
            float new_lr = get_lr() * gamma_;
            optimizer_->set_lr(new_lr);
            break;
        }
    }
}

// ============================================================================
// CosineAnnealingLR
// ============================================================================

CosineAnnealingLR::CosineAnnealingLR(std::shared_ptr<Optimizer> optimizer,
                                       int T_max, float eta_min)
    : LRScheduler(optimizer)
    , T_max_(T_max)
    , eta_min_(eta_min) {}

void CosineAnnealingLR::step() {
    LRScheduler::step();
    float progress = static_cast<float>(step_count_ % T_max_) / static_cast<float>(T_max_);
    float cos_val = std::cos(M_PI * progress);
    float new_lr = eta_min_ + 0.5f * (base_lr_ - eta_min_) * (1.0f + cos_val);
    optimizer_->set_lr(new_lr);
}

// ============================================================================
// ReduceLROnPlateau
// ============================================================================

ReduceLROnPlateau::ReduceLROnPlateau(std::shared_ptr<Optimizer> optimizer,
                                       const std::string& mode,
                                       float factor, int patience,
                                       float threshold)
    : LRScheduler(optimizer)
    , mode_(mode)
    , factor_(factor)
    , patience_(patience)
    , threshold_(threshold)
    , best_metric_(mode == "min" ? std::numeric_limits<float>::max()
                                 : std::numeric_limits<float>::lowest()) {}

bool ReduceLROnPlateau::step(float metric) {
    LRScheduler::step();

    if (is_better(metric)) {
        best_metric_ = metric;
        num_bad_epochs_ = 0;
        return false;
    }

    num_bad_epochs_++;

    if (num_bad_epochs_ >= patience_) {
        float new_lr = get_lr() * factor_;
        optimizer_->set_lr(new_lr);
        num_bad_epochs_ = 0;
        return true;
    }

    return false;
}

bool ReduceLROnPlateau::is_better(float current) const {
    if (mode_ == "min") {
        return current < best_metric_ - threshold_;
    } else {
        return current > best_metric_ + threshold_;
    }
}

} // namespace optim
} // namespace rootseed