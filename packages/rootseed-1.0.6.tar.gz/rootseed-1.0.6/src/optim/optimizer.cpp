// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// optimizer.cpp — Base Optimizer Implementation
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "optim/optimizer.h"

#include <algorithm>

namespace rootseed {
namespace optim {

Optimizer::Optimizer(float lr) : default_lr_(lr) {}

void Optimizer::add_param_group(const std::vector<std::shared_ptr<nn::Parameter>>& params,
                                 float lr, float weight_decay) {
    ParamGroup group;
    group.params = params;
    group.lr = (lr > 0.0f) ? lr : default_lr_;
    group.weight_decay = weight_decay;
    param_groups_.push_back(group);
}

void Optimizer::zero_grad() {
    for (auto& group : param_groups_) {
        for (auto& p : group.params) {
            // Reset the gradient to zeros
            if (p->grad().numel() > 0) {
                core::Tensor zero_grad = core::Tensor::zeros(p->shape(), p->dtype(), p->device());
                p->grad() = zero_grad;
            }
        }
    }
}

void Optimizer::set_lr(float lr) {
    default_lr_ = lr;
    for (auto& group : param_groups_) {
        group.lr = lr;
    }
}

std::vector<std::shared_ptr<nn::Parameter>> Optimizer::all_parameters() const {
    std::vector<std::shared_ptr<nn::Parameter>> result;
    for (const auto& group : param_groups_) {
        result.insert(result.end(), group.params.begin(), group.params.end());
    }
    return result;
}

float Optimizer::lr() const noexcept {
    if (!param_groups_.empty()) {
        return param_groups_[0].lr;
    }
    return default_lr_;
}

} // namespace optim
} // namespace rootseed