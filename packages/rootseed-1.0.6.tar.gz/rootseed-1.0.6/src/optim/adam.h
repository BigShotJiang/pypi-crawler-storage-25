// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// adam.h — Adam Optimizer: m_t = β₁m_{t-1} + (1-β₁)g_t; v_t = β₂v_{t-1} + (1-β₂)g_t² (Section 6.4)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "optim/optimizer.h"

namespace rootseed {
namespace optim {

// ============================================================================
// Adam — Adaptive Moment Estimation
//
// Equations (Section 6.4):
//   m_t = β₁ * m_{t-1} + (1 - β₁) * g_t
//   v_t = β₂ * v_{t-1} + (1 - β₂) * g_t²
//   m̂_t = m_t / (1 - β₁^t)
//   v̂_t = v_t / (1 - β₂^t)
//   W_{t+1} = W_t - η * m̂_t / (√v̂_t + ε)
// ============================================================================

class Adam : public Optimizer {
public:
    Adam(float lr = 0.001f, float beta1 = 0.9f, float beta2 = 0.999f,
         float eps = 1e-8f, float weight_decay = 0.0f);

    void step() override;

private:
    float beta1_;
    float beta2_;
    float eps_;
    float weight_decay_;
};

} // namespace optim
} // namespace rootseed