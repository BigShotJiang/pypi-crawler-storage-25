// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// scheduler.h — Learning Rate Schedulers: StepLR, CosineAnnealingLR, ReduceLROnPlateau
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "optim/optimizer.h"

#include <memory>
#include <string>

namespace rootseed {
namespace optim {

// ============================================================================
// LRScheduler — base class for learning rate scheduling
// ============================================================================

class LRScheduler {
public:
    explicit LRScheduler(std::shared_ptr<Optimizer> optimizer);
    virtual ~LRScheduler() = default;

    /// Step the scheduler (call after optimizer.step()).
    virtual void step();

    /// Returns the current learning rate.
    float get_lr() const noexcept;

protected:
    std::shared_ptr<Optimizer> optimizer_;
    int step_count_ = 0;
    float base_lr_;
};

// ============================================================================
// StepLR — decays lr by gamma every step_size steps
// ============================================================================

class StepLR : public LRScheduler {
public:
    StepLR(std::shared_ptr<Optimizer> optimizer, int step_size, float gamma = 0.1f);
    void step() override;

private:
    int step_size_;
    float gamma_;
};

// ============================================================================
// MultiStepLR — decays lr at specific milestone epochs
// ============================================================================

class MultiStepLR : public LRScheduler {
public:
    MultiStepLR(std::shared_ptr<Optimizer> optimizer,
                const std::vector<int>& milestones, float gamma = 0.1f);
    void step() override;

private:
    std::vector<int> milestones_;
    float gamma_;
};

// ============================================================================
// CosineAnnealingLR — cosine decay from base_lr to 0
// ============================================================================

class CosineAnnealingLR : public LRScheduler {
public:
    CosineAnnealingLR(std::shared_ptr<Optimizer> optimizer, int T_max, float eta_min = 0.0f);
    void step() override;

private:
    int T_max_;
    float eta_min_;
};

// ============================================================================
// ReduceLROnPlateau — reduce lr when metric stops improving
// ============================================================================

class ReduceLROnPlateau : public LRScheduler {
public:
    ReduceLROnPlateau(std::shared_ptr<Optimizer> optimizer,
                      const std::string& mode = "min",
                      float factor = 0.1f, int patience = 10,
                      float threshold = 1e-4f);

    /// Call with the current metric value. Returns true if lr was reduced.
    bool step(float metric);

private:
    std::string mode_;
    float factor_;
    int patience_;
    float threshold_;
    float best_metric_;
    int num_bad_epochs_ = 0;
    bool is_better(float current) const;
};

} // namespace optim
} // namespace rootseed