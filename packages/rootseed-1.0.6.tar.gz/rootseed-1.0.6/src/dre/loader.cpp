// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// loader.cpp — Backend Library Loading with Graceful Degradation (Section 3.3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "loader.h"
#include "utils/log.h"
#include "utils/exception.h"

#include <algorithm>
#include <cstdlib>

namespace rootseed {
namespace dre {

// ============================================================================
// DynamicLibrary
// ============================================================================

DynamicLibrary::DynamicLibrary(const std::string& path, int flags)
    : path_(path) {
    handle_ = dlopen(path.c_str(), flags);
    if (!handle_) {
        error_ = dlerror();
    }
}

DynamicLibrary::~DynamicLibrary() {
    if (handle_) {
        dlclose(handle_);
    }
}

DynamicLibrary::DynamicLibrary(DynamicLibrary&& other) noexcept
    : handle_(other.handle_)
    , path_(std::move(other.path_))
    , error_(std::move(other.error_)) {
    other.handle_ = nullptr;
}

DynamicLibrary& DynamicLibrary::operator=(DynamicLibrary&& other) noexcept {
    if (this != &other) {
        if (handle_) dlclose(handle_);
        handle_ = other.handle_;
        path_ = std::move(other.path_);
        error_ = std::move(other.error_);
        other.handle_ = nullptr;
    }
    return *this;
}

// ============================================================================
// BackendLoader
// ============================================================================

BackendLoader& BackendLoader::instance() {
    static BackendLoader s_instance;
    return s_instance;
}

BackendLoader::BackendLoader() {
    // Initialize status for all backends (descending priority)
    statuses_ = {
        { BackendType::CUDA,    "CUDA",    "libcudart.so",   false, false, "" },
        { BackendType::ROCm,    "ROCm",    "libhiprtc.so",   false, false, "" },
        { BackendType::Vulkan,  "Vulkan",  "libvulkan.so",   false, false, "" },
        { BackendType::TPU,     "TPU",     "libtpu.so",      false, false, "" },
        { BackendType::NPU,     "NPU",     "libhexagon.so",  false, false, "" },
        { BackendType::XNNPACK, "XNNPACK", "libXNNPACK.so",  false, false, "" },
        { BackendType::Reference, "Reference", "",            true,  true,  "" },
    };
}

BackendLoader::~BackendLoader() = default;

BackendType BackendLoader::load_best_backend() {
    RS_LOG_INFO("Probing acceleration backends...");

    // Probe in priority order: CUDA → ROCm → Vulkan → TPU → NPU → XNNPACK → Reference

    if (probe_cuda()) {
        active_ = BackendType::CUDA;
        RS_LOG_INFO("Backend: CUDA (NVIDIA GPU)");
        return active_;
    }

    if (probe_rocm()) {
        active_ = BackendType::ROCm;
        RS_LOG_INFO("Backend: ROCm (AMD GPU)");
        return active_;
    }

    if (probe_vulkan()) {
        active_ = BackendType::Vulkan;
        RS_LOG_INFO("Backend: Vulkan (Cross-vendor GPU)");
        return active_;
    }

    if (probe_tpu()) {
        active_ = BackendType::TPU;
        RS_LOG_INFO("Backend: TPU (Google)");
        return active_;
    }

    if (probe_npu()) {
        active_ = BackendType::NPU;
        RS_LOG_INFO("Backend: NPU (Qualcomm/Apple)");
        return active_;
    }

    if (probe_xnnpack()) {
        active_ = BackendType::XNNPACK;
        RS_LOG_INFO("Backend: XNNPACK (Optimized CPU)");
        return active_;
    }

    // Always fall back to Reference
    active_ = BackendType::Reference;
    RS_LOG_INFO("Backend: Reference (CPU) — no accelerators available");
    return active_;
}

std::string_view BackendLoader::active_backend_name() const {
    for (const auto& s : statuses_) {
        if (s.type == active_) return s.name;
    }
    return "Unknown";
}

bool BackendLoader::is_available(BackendType type) const {
    for (const auto& s : statuses_) {
        if (s.type == type) return s.loaded;
    }
    return false;
}

BackendType BackendLoader::degrade() {
    switch (active_) {
        case BackendType::CUDA:
            if (probe_rocm()) { active_ = BackendType::ROCm; return active_; }
            [[fallthrough]];
        case BackendType::ROCm:
            if (probe_vulkan()) { active_ = BackendType::Vulkan; return active_; }
            [[fallthrough]];
        case BackendType::Vulkan:
            if (probe_tpu()) { active_ = BackendType::TPU; return active_; }
            [[fallthrough]];
        case BackendType::TPU:
            if (probe_npu()) { active_ = BackendType::NPU; return active_; }
            [[fallthrough]];
        case BackendType::NPU:
            if (probe_xnnpack()) { active_ = BackendType::XNNPACK; return active_; }
            [[fallthrough]];
        default:
            active_ = BackendType::Reference;
            RS_LOG_WARN("Degraded to Reference (CPU) backend");
            return active_;
    }
}

// ============================================================================
// Backend probes
// ============================================================================

bool BackendLoader::probe_cuda() {
    // Try common locations for libcudart.so
    const char* paths[] = {
        "libcudart.so",
        "libcudart.so.12",
        "libcudart.so.11",
        "/usr/local/cuda/lib64/libcudart.so",
        "/usr/lib/x86_64-linux-gnu/libcudart.so",
        nullptr
    };

    for (int i = 0; paths[i] != nullptr; ++i) {
        cuda_lib_ = std::make_unique<DynamicLibrary>(paths[i], RTLD_LAZY);
        if (cuda_lib_->is_loaded()) {
            statuses_[0].loaded = true;
            statuses_[0].available = true;
            return true;
        }
    }

    statuses_[0].available = false;
    statuses_[0].error_message = "libcudart.so not found";
    return false;
}

bool BackendLoader::probe_rocm() {
    const char* paths[] = {
        "libhiprtc.so",
        "libhiprtc.so.5",
        "libhiprtc.so.6",
        "/opt/rocm/lib/libhiprtc.so",
        "/usr/lib/libhiprtc.so",
        nullptr
    };

    for (int i = 0; paths[i] != nullptr; ++i) {
        rocm_lib_ = std::make_unique<DynamicLibrary>(paths[i], RTLD_LAZY);
        if (rocm_lib_->is_loaded()) {
            statuses_[1].loaded = true;
            statuses_[1].available = true;
            return true;
        }
    }

    statuses_[1].available = false;
    statuses_[1].error_message = "libhiprtc.so not found";
    return false;
}

bool BackendLoader::probe_vulkan() {
    const char* paths[] = {
        "libvulkan.so",
        "libvulkan.so.1",
        "/usr/lib/libvulkan.so",
        nullptr
    };

    for (int i = 0; paths[i] != nullptr; ++i) {
        vulkan_lib_ = std::make_unique<DynamicLibrary>(paths[i], RTLD_LAZY);
        if (vulkan_lib_->is_loaded()) {
            statuses_[2].loaded = true;
            statuses_[2].available = true;
            return true;
        }
    }

    statuses_[2].available = false;
    statuses_[2].error_message = "libvulkan.so not found";
    return false;
}

bool BackendLoader::probe_tpu() {
    const char* paths[] = {
        "libtpu.so",
        "/usr/lib/libtpu.so",
        "/usr/local/lib/libtpu.so",
        // Also check for Edge TPU
        "libedgetpu.so",
        "/usr/lib/libedgetpu.so",
        nullptr
    };

    for (int i = 0; paths[i] != nullptr; ++i) {
        tpu_lib_ = std::make_unique<DynamicLibrary>(paths[i], RTLD_LAZY);
        if (tpu_lib_->is_loaded()) {
            statuses_[3].loaded = true;
            statuses_[3].available = true;
            return true;
        }
    }

    statuses_[3].available = false;
    statuses_[3].error_message = "libtpu.so / libedgetpu.so not found";
    return false;
}

bool BackendLoader::probe_npu() {
    const char* paths[] = {
        "libhexagon.so",       // Qualcomm Hexagon DSP
        "/vendor/lib64/libhexagon.so",
        "/vendor/lib/libhexagon.so",
        nullptr
    };

    for (int i = 0; paths[i] != nullptr; ++i) {
        npu_lib_ = std::make_unique<DynamicLibrary>(paths[i], RTLD_LAZY);
        if (npu_lib_->is_loaded()) {
            statuses_[4].loaded = true;
            statuses_[4].available = true;
            return true;
        }
    }

    statuses_[4].available = false;
    statuses_[4].error_message = "libhexagon.so not found (Qualcomm/Apple NPU not available)";
    return false;
}

bool BackendLoader::probe_xnnpack() {
    const char* paths[] = {
        "libXNNPACK.so",
        "/usr/lib/libXNNPACK.so",
        "/usr/local/lib/libXNNPACK.so",
        nullptr
    };

    for (int i = 0; paths[i] != nullptr; ++i) {
        auto lib = std::make_unique<DynamicLibrary>(paths[i], RTLD_LAZY);
        if (lib->is_loaded()) {
            statuses_[5].loaded = true;
            statuses_[5].available = true;
            return true;
        }
    }

    // XNNPACK not found as shared lib — it may be compiled into the binary
    // Check if we can find it from the build system
    statuses_[5].available = true;  // Assume available if cpuinfo is present
    statuses_[5].error_message = "libXNNPACK.so not found as standalone library";
    return false;  // Don't load as primary if not standalone
}

} // namespace dre
} // namespace rootseed