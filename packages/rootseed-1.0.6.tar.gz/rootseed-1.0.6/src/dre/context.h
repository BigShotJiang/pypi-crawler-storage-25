// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// context.h — Hardware Context Provider Singleton (Section 3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "detect.h"
#include "core/memory.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <mutex>

namespace rootseed {
namespace dre {

// ============================================================================
// HardwareContextProvider — singleton caching all hardware properties
//
// Provides AKD (Adaptive Kernel Dispatch) with the information needed
// to select optimal kernels at runtime:
//   - Cache sizes for memory layout optimization (Section 2.3)
//   - SIMD width for microkernel selection (Tiers 3-4, 12-14)
//   - Tensor Core availability for GPU kernel selection (Tiers 5-6)
// ============================================================================

class HardwareContextProvider {
public:
    static HardwareContextProvider& instance();

    /// Initialize hardware detection and cache all results.
    /// Called once at framework startup by DRE.
    void initialize();

    /// Returns true if hardware has been detected and cached.
    bool is_initialized() const noexcept { return initialized_; }

    // ---- CPU Info ----
    const CPUInfo& cpu_info() const { return sysinfo_.cpu; }
    
    size_t l1_cache_size()    const noexcept { return sysinfo_.cpu.l1_data_cache; }
    size_t l2_cache_size()    const noexcept { return sysinfo_.cpu.l2_cache; }
    size_t l3_cache_size()    const noexcept { return sysinfo_.cpu.l3_cache; }
    size_t l1_cache_line()    const noexcept { return sysinfo_.cpu.l1_cache_line; }
    size_t max_simd_width()   const noexcept { return sysinfo_.cpu.max_simd_width; }
    size_t num_cores()        const noexcept { return sysinfo_.cpu.num_cores; }
    size_t num_threads()      const noexcept { return sysinfo_.cpu.num_threads; }

    // ---- GPU Info ----
    const std::vector<GPUInfo>& gpu_info() const { return sysinfo_.gpus; }
    bool has_gpu()            const noexcept { return !sysinfo_.gpus.empty(); }
    bool has_cuda()           const noexcept { return sysinfo_.has_cuda; }
    bool has_rocm()           const noexcept { return sysinfo_.has_rocm; }
    bool has_vulkan()         const noexcept { return sysinfo_.has_vulkan; }
    bool has_tensor_cores()   const noexcept;
    
    /// Returns the best GPU device for computation.
    const GPUInfo* primary_gpu() const;

    // ---- System Info ----
    const SystemInfo& system_info() const noexcept { return sysinfo_; }
    const std::string& recommended_backend() const noexcept { return sysinfo_.recommended_backend; }
    size_t total_ram()        const noexcept { return sysinfo_.total_ram; }
    bool hugepages_available() const noexcept { return sysinfo_.hugepages_available; }
    bool numa_available()      const noexcept { return sysinfo_.numa_available; }
    int numa_node_count()     const noexcept { return sysinfo_.numa_node_count; }

    // ---- SIMD feature queries (used by AKD) ----
    bool has_avx2()           const noexcept { return sysinfo_.cpu.has_avx2; }
    bool has_avx512()         const noexcept { return sysinfo_.cpu.has_avx512f; }
    bool has_neon()           const noexcept { return sysinfo_.cpu.has_neon; }
    bool has_sve()            const noexcept { return sysinfo_.cpu.has_sve; }

    // ---- Memory Manager Access ----
    core::HardwareMemoryInfo memory_info() const { return meminfo_; }

private:
    HardwareContextProvider() = default;
    
    SystemInfo sysinfo_;
    core::HardwareMemoryInfo meminfo_;
    bool initialized_ = false;
    mutable std::mutex mutex_;
};

} // namespace dre
} // namespace rootseed