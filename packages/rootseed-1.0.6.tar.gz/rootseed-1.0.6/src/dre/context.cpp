// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// context.cpp — Hardware Context Provider Implementation (Section 3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "context.h"
#include "utils/log.h"

namespace rootseed {
namespace dre {

HardwareContextProvider& HardwareContextProvider::instance() {
    static HardwareContextProvider s_instance;
    return s_instance;
}

void HardwareContextProvider::initialize() {
    std::lock_guard<std::mutex> lock(mutex_);
    
    if (initialized_) return;
    
    RS_LOG_INFO("Detecting hardware...");
    
    // Detect complete system
    sysinfo_ = detect_system();
    meminfo_ = core::detect_hardware_memory();
    
    initialized_ = true;
    
    RS_LOG_INFO(system_summary(sysinfo_));
}

bool HardwareContextProvider::has_tensor_cores() const noexcept {
    for (const auto& gpu : sysinfo_.gpus) {
        if (gpu.has_tensor_cores) return true;
    }
    return false;
}

const GPUInfo* HardwareContextProvider::primary_gpu() const {
    if (sysinfo_.gpus.empty()) return nullptr;
    
    // Return the first NVIDIA GPU, or the first GPU found
    for (const auto& gpu : sysinfo_.gpus) {
        if (gpu.vendor == GPUVendor::NVIDIA) return &gpu;
    }
    return &sysinfo_.gpus[0];
}

} // namespace dre
} // namespace rootseed