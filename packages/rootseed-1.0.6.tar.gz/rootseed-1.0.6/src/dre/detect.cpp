// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// detect.cpp — CPU and GPU Hardware Detection Implementation (Section 3.2, 10)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "detect.h"
#include "core/memory.h"   // for detect_hardware_memory()

#if __has_include(<cpuinfo.h>)
#include <cpuinfo.h>
#define RS_HAS_CPUINFO
#endif
#include <fstream>
#include <sstream>
#include <iostream>
#include <cstring>
#include <dirent.h>
#include <unistd.h>

namespace rootseed {
namespace dre {

// ============================================================================
// CPU Detection (using cpuinfo library)
// ============================================================================

CPUInfo detect_cpu() {
    CPUInfo info;
    
    // Initialize cpuinfo if not already done
    if (!cpuinfo_initialize()) {
        info.detected = false;
        return info;
    }
    
    // Get first processor (most systems are homogeneous)
    const struct cpuinfo_processor* processor = cpuinfo_get_processor(0);
    if (!processor) {
        info.detected = false;
        return info;
    }
    
    const struct cpuinfo_package* package = processor->package;
    // core pointer retained for future use
    
    // Architecture detection
#if defined(__x86_64__) || defined(__i386__)
    info.architecture = "x86_64";
#elif defined(__aarch64__) || defined(__arm__)
    info.architecture = "aarch64";
#elif defined(__riscv)
    info.architecture = "riscv64";
#else
    info.architecture = "unknown";
#endif
    
    // Vendor
    info.vendor = package->name;
    
    // Brand string (from cpuid on x86, from /proc/cpuinfo on ARM)
    if (package->name && strlen(package->name) > 0) {
        // cpuinfo doesn't always expose brand cleanly; try /proc/cpuinfo
        std::ifstream cpuinfo_file("/proc/cpuinfo");
        if (cpuinfo_file.is_open()) {
            std::string line;
            while (std::getline(cpuinfo_file, line)) {
                if (line.find("model name") != std::string::npos ||
                    line.find("Model") != std::string::npos) {
                    auto pos = line.find(": ");
                    if (pos != std::string::npos) {
                        info.brand = line.substr(pos + 2);
                    }
                    break;
                }
            }
        }
    }
    if (info.brand.empty()) {
        info.brand = info.vendor + " " + info.architecture;
    }
    
    // Core counts
    info.num_cores = cpuinfo_get_cores_count();
    info.num_threads = cpuinfo_get_processors_count();
    
    // Cache info
    const struct cpuinfo_cache* l1 = cpuinfo_get_l1d_cache(0);
    if (l1) {
        info.l1_data_cache = l1->size;
        info.l1_cache_line = l1->line_size;
    }
    
    const struct cpuinfo_cache* l2 = cpuinfo_get_l2_cache(0);
    if (l2) {
        info.l2_cache = l2->size;
    }
    
    const struct cpuinfo_cache* l3 = cpuinfo_get_l3_cache(0);
    if (l3) {
        info.l3_cache = l3->size;
    }
    
    // x86 feature flags
    if (cpuinfo_has_x86_mmx())      info.has_mmx = true;
    if (cpuinfo_has_x86_sse())      info.has_sse = true;
    if (cpuinfo_has_x86_sse2())     info.has_sse2 = true;
    if (cpuinfo_has_x86_sse3())     info.has_sse3 = true;
    if (cpuinfo_has_x86_ssse3())    info.has_ssse3 = true;
    if (cpuinfo_has_x86_sse4_1())   info.has_sse4_1 = true;
    if (cpuinfo_has_x86_sse4_2())   info.has_sse4_2 = true;
    if (cpuinfo_has_x86_avx())      info.has_avx = true;
    if (cpuinfo_has_x86_avx2())     info.has_avx2 = true;
    if (cpuinfo_has_x86_avx512f())  info.has_avx512f = true;
    if (cpuinfo_has_x86_avx512bw()) info.has_avx512bw = true;
    if (cpuinfo_has_x86_avx512dq()) info.has_avx512dq = true;
    if (cpuinfo_has_x86_avx512vl()) info.has_avx512vl = true;
    if (cpuinfo_has_x86_avx512vnni()) info.has_avx512vnni = true;
    if (cpuinfo_has_x86_avx512bf16()) info.has_avx512bf16 = true;
    
    // ARM feature flags
    info.has_neon    = cpuinfo_has_arm_neon();
    info.has_fp16    = cpuinfo_has_arm_fp16_arith();
    info.has_dotprod = cpuinfo_has_arm_neon_dot();
    info.has_sve     = cpuinfo_has_arm_sve();
    info.has_sve2    = cpuinfo_has_arm_sve2();
    
    // Determine max SIMD width
    if (info.has_avx512f)        info.max_simd_width = 512;
    else if (info.has_sve)       info.max_simd_width = 256;  // SVE is variable, typical 256
    else if (info.has_avx2)      info.max_simd_width = 256;
    else if (info.has_avx)       info.max_simd_width = 256;
    else if (info.has_sse)       info.max_simd_width = 128;
    else if (info.has_neon)      info.max_simd_width = 128;
    else                         info.max_simd_width = 64;
    
    info.detected = true;
    return info;
}

// ============================================================================
// GPU Detection
// ============================================================================

/// Helper: check if a file exists
static bool file_exists(const std::string& path) {
    return access(path.c_str(), F_OK) == 0;
}

/// Helper: read first line of a file
static std::string read_first_line(const std::string& path) {
    std::ifstream f(path);
    if (f.is_open()) {
        std::string line;
        std::getline(f, line);
        return line;
    }
    return "";
}

/// Detect NVIDIA GPUs via /proc/driver/nvidia
static std::vector<GPUInfo> detect_nvidia_gpus() {
    std::vector<GPUInfo> gpus;
    
    // Check if NVIDIA driver is loaded
    if (!file_exists("/proc/driver/nvidia/version")) {
        return gpus;
    }
    
    // Try to run nvidia-smi for detailed info
    FILE* pipe = popen("nvidia-smi --query-gpu=index,name,memory.total,compute_cap --format=csv,noheader 2>/dev/null", "r");
    if (!pipe) return gpus;
    
    char buffer[512];
    int index = 0;
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        std::string line(buffer);
        // Remove trailing newline
        if (!line.empty() && line.back() == '\n') line.pop_back();
        
        // Parse: "0, NVIDIA GeForce RTX 4090, 24564 MiB, 8.9"
        std::istringstream ss(line);
        std::string idx_str, name, mem_str, cc_str;
        
        std::getline(ss, idx_str, ',');
        std::getline(ss, name, ',');
        std::getline(ss, mem_str, ',');
        std::getline(ss, cc_str, ',');
        
        // Trim whitespace
        auto trim = [](std::string& s) {
            s.erase(0, s.find_first_not_of(" \t"));
            s.erase(s.find_last_not_of(" \t") + 1);
        };
        trim(name);
        trim(mem_str);
        trim(cc_str);
        
        GPUInfo gpu;
        gpu.name = name;
        gpu.vendor = GPUVendor::NVIDIA;
        gpu.driver = GPUDriver::CUDA;
        gpu.index = index++;
        
        // Parse memory: "24564 MiB"
        size_t mem_val = 0;
        std::istringstream mem_ss(mem_str);
        mem_ss >> mem_val;
        gpu.total_memory = mem_val * 1024 * 1024;  // Convert MiB to bytes
        
        // Parse compute capability: "8.9"
        size_t dot_pos = cc_str.find('.');
        if (dot_pos != std::string::npos) {
            gpu.compute_capability_major = std::stoi(cc_str.substr(0, dot_pos));
            gpu.compute_capability_minor = std::stoi(cc_str.substr(dot_pos + 1));
        }
        
        // Tensor Cores: CC >= 7.0
        gpu.has_tensor_cores = (gpu.compute_capability_major >= 7);
        // FP8: CC >= 8.9 (Ada Lovelace / Hopper)
        gpu.has_fp8 = (gpu.compute_capability_major > 8) ||
                      (gpu.compute_capability_major == 8 && gpu.compute_capability_minor >= 9);
        
        gpu.detected = true;
        gpus.push_back(gpu);
    }
    pclose(pipe);
    
    return gpus;
}

/// Detect AMD GPUs via /sys/class/drm
static std::vector<GPUInfo> detect_amd_gpus() {
    std::vector<GPUInfo> gpus;
    
    std::string drm_path = "/sys/class/drm";
    DIR* dir = opendir(drm_path.c_str());
    if (!dir) return gpus;
    
    int index = 0;
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;
        // AMD GPU cards: card0, card1, etc.
        if (name.find("card") != 0) continue;
        if (name.find("card") == 0 && name.size() > 4 && isdigit(name[4])) {
            // Read GPU name from the device
            std::string device_path = drm_path + "/" + name + "/device/vendor";
            std::string vendor_id = read_first_line(device_path);
            
            // AMD vendor ID is 0x1002
            if (vendor_id.find("0x1002") != std::string::npos || vendor_id == "0x1002") {
                GPUInfo gpu;
                gpu.vendor = GPUVendor::AMD;
                gpu.driver = GPUDriver::ROCm;
                gpu.index = index++;
                
                // Try to read product name
                std::string product_path = drm_path + "/" + name + "/device/product_name";
                gpu.name = read_first_line(product_path);
                if (gpu.name.empty()) {
                    gpu.name = "AMD GPU " + std::to_string(gpu.index);
                }
                
                // Try rocminfo for detailed info
                FILE* pipe = popen("rocminfo 2>/dev/null | grep -E 'Name|Marketing Name' | head -1", "r");
                if (pipe) {
                    char buf[256];
                    if (fgets(buf, sizeof(buf), pipe)) {
                        std::string rocm_name(buf);
                        auto pos = rocm_name.find(": ");
                        if (pos != std::string::npos) {
                            gpu.name = rocm_name.substr(pos + 2);
                            if (!gpu.name.empty() && gpu.name.back() == '\n') gpu.name.pop_back();
                        }
                    }
                    pclose(pipe);
                }
                
                gpu.detected = true;
                gpus.push_back(gpu);
            }
        }
    }
    closedir(dir);
    
    return gpus;
}

/// Detect GPUs via Vulkan
static std::vector<GPUInfo> detect_vulkan_gpus() {
    std::vector<GPUInfo> gpus;
    
    // Check if vulkaninfo is available
    FILE* pipe = popen("vulkaninfo --summary 2>/dev/null | grep deviceName", "r");
    if (!pipe) return gpus;
    
    char buffer[512];
    int index = 0;
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        std::string line(buffer);
        auto pos = line.find("deviceName = ");
        if (pos != std::string::npos) {
            GPUInfo gpu;
            gpu.name = line.substr(pos + 14);
            // Trim
            gpu.name.erase(0, gpu.name.find_first_not_of(" \t"));
            gpu.name.erase(gpu.name.find_last_not_of(" \t\n") + 1);
            gpu.vendor = GPUVendor::Unknown;
            gpu.driver = GPUDriver::Vulkan;
            gpu.index = index++;
            gpu.detected = true;
            gpus.push_back(gpu);
        }
    }
    pclose(pipe);
    
    return gpus;
}

std::vector<GPUInfo> detect_gpus() {
    std::vector<GPUInfo> gpus;
    
    // Try NVIDIA first (most detailed info)
    auto nvidia_gpus = detect_nvidia_gpus();
    gpus.insert(gpus.end(), nvidia_gpus.begin(), nvidia_gpus.end());
    
    // Try AMD (skip if NVIDIA already found, avoid double-counting Vulkan devices)
    if (gpus.empty()) {
        auto amd_gpus = detect_amd_gpus();
        gpus.insert(gpus.end(), amd_gpus.begin(), amd_gpus.end());
    }
    
    // Try Vulkan for any remaining GPUs
    if (gpus.empty()) {
        auto vk_gpus = detect_vulkan_gpus();
        gpus.insert(gpus.end(), vk_gpus.begin(), vk_gpus.end());
    }
    
    return gpus;
}

// ============================================================================
// Complete System Detection
// ============================================================================

SystemInfo detect_system() {
    SystemInfo info;
    
    info.cpu = detect_cpu();
    info.gpus = detect_gpus();
    
    // Memory info
    auto mem_info = core::detect_hardware_memory();
    info.total_ram = mem_info.physical_memory;
    info.page_size = mem_info.page_size;
    info.hugepages_available = mem_info.hugepages_available;
    info.numa_available = mem_info.numa_available;
    info.numa_node_count = mem_info.numa_node_count;
    
    // Determine available backends
    for (const auto& gpu : info.gpus) {
        if (gpu.vendor == GPUVendor::NVIDIA && gpu.driver == GPUDriver::CUDA)
            info.has_cuda = true;
        if (gpu.vendor == GPUVendor::AMD && gpu.driver == GPUDriver::ROCm)
            info.has_rocm = true;
        if (gpu.driver == GPUDriver::Vulkan)
            info.has_vulkan = true;
    }
    
    // TODO: TPU/NPU detection (Module J5/J6)
    
    // Recommend best backend
    if (info.has_cuda)      info.recommended_backend = "CUDA";
    else if (info.has_rocm) info.recommended_backend = "ROCm";
    else if (info.has_vulkan) info.recommended_backend = "Vulkan";
    else                    info.recommended_backend = "XNNPACK (CPU)";
    
    info.detected = true;
    return info;
}

std::string system_summary(const SystemInfo& info) {
    std::ostringstream oss;
    
    oss << "CPU: " << info.cpu.brand << " (" << info.cpu.num_cores << " cores, "
        << info.cpu.num_threads << " threads)\n";
    oss << "SIMD: " << info.cpu.max_simd_width << "-bit\n";
    oss << "Cache: L1=" << info.cpu.l1_data_cache / 1024 << "KB, "
        << "L2=" << info.cpu.l2_cache / 1024 << "KB, "
        << "L3=" << info.cpu.l3_cache / (1024*1024) << "MB\n";
    oss << "RAM: " << info.total_ram / (1024*1024*1024) << " GB\n";
    
    if (!info.gpus.empty()) {
        for (size_t i = 0; i < info.gpus.size(); ++i) {
            const auto& gpu = info.gpus[i];
            oss << "GPU[" << i << "]: " << gpu.name << " ("
                << gpu.total_memory / (1024*1024*1024) << " GB";
            if (gpu.vendor == GPUVendor::NVIDIA) {
                oss << ", CC=" << gpu.compute_capability_major << "."
                    << gpu.compute_capability_minor;
                if (gpu.has_tensor_cores) oss << ", TensorCores";
                if (gpu.has_fp8) oss << ", FP8";
            }
            oss << ")\n";
        }
    } else {
        oss << "GPU: None detected (CPU-only mode)\n";
    }
    
    oss << "Backend: " << info.recommended_backend << "\n";
    
    return oss.str();
}

} // namespace dre
} // namespace rootseed