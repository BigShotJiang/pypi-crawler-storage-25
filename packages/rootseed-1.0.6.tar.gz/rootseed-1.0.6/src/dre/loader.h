// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// loader.h — Dynamic Library Loader and Backend Activation (Section 3.3)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <string>
#include <string_view>
#include <memory>
#include <functional>
#include <vector>
#include <dlfcn.h>

namespace rootseed {
namespace dre {

// ============================================================================
// DynamicLibrary — RAII wrapper around dlopen/dlclose
// ============================================================================

class DynamicLibrary {
public:
    explicit DynamicLibrary(const std::string& path, int flags = RTLD_LAZY);
    ~DynamicLibrary();

    DynamicLibrary(const DynamicLibrary&) = delete;
    DynamicLibrary& operator=(const DynamicLibrary&) = delete;
    DynamicLibrary(DynamicLibrary&& other) noexcept;
    DynamicLibrary& operator=(DynamicLibrary&& other) noexcept;

    /// Returns true if the library was loaded successfully.
    bool is_loaded() const noexcept { return handle_ != nullptr; }

    /// Get a symbol address from the library.
    template<typename T>
    T* symbol(const std::string& name) const {
        if (!handle_) return nullptr;
        return reinterpret_cast<T*>(dlsym(handle_, name.c_str()));
    }

    /// Returns the library path.
    const std::string& path() const noexcept { return path_; }

    /// Returns the last dlerror message.
    std::string error() const { return error_; }

private:
    void* handle_ = nullptr;
    std::string path_;
    std::string error_;
};

// ============================================================================
// BackendLoader — orchestrates loading of acceleration backends
//
// Priority order (Section 3.3):
//   CUDA → ROCm → Vulkan → TPU → NPU → XNNPACK → Reference
//
// Each backend is probed at runtime. If not found, the loader gracefully
// degrades to the next available backend. The Reference backend is always
// available (pure C++ CPU fallback).
// ============================================================================

enum class BackendType : uint8_t {
    Reference = 0,   // Always available — pure C++ CPU
    XNNPACK   = 1,   // Optimized CPU inference
    NPU       = 2,   // Qualcomm/Apple Neural Engine
    TPU       = 3,   // Google TPU
    Vulkan    = 4,   // Cross-vendor GPU
    ROCm      = 5,   // AMD GPU
    CUDA      = 6,   // NVIDIA GPU
};

struct BackendStatus {
    BackendType type;
    std::string name;
    std::string library_path;
    bool loaded = false;
    bool available = true;
    std::string error_message;
};

class BackendLoader {
public:
    static BackendLoader& instance();

    /// Probe all backends and load the highest-priority available one.
    /// Returns the active backend type.
    BackendType load_best_backend();

    /// Returns the currently active backend.
    BackendType active_backend() const noexcept { return active_; }

    /// Returns human-readable name of the active backend.
    std::string_view active_backend_name() const;

    /// Returns true if a specific backend is available.
    bool is_available(BackendType type) const;

    /// Get the status of all backends.
    const std::vector<BackendStatus>& all_status() const noexcept { return statuses_; }

    /// Gracefully degrade to the next available backend.
    BackendType degrade();

private:
    BackendLoader();
    ~BackendLoader();

    BackendLoader(const BackendLoader&) = delete;
    BackendLoader& operator=(const BackendLoader&) = delete;

    bool probe_cuda();
    bool probe_rocm();
    bool probe_vulkan();
    bool probe_tpu();
    bool probe_npu();
    bool probe_xnnpack();
    // Reference backend is always available — no probe needed.

    std::vector<BackendStatus> statuses_;
    BackendType active_ = BackendType::Reference;
    std::unique_ptr<DynamicLibrary> cuda_lib_;
    std::unique_ptr<DynamicLibrary> rocm_lib_;
    std::unique_ptr<DynamicLibrary> vulkan_lib_;
    std::unique_ptr<DynamicLibrary> tpu_lib_;
    std::unique_ptr<DynamicLibrary> npu_lib_;
};

} // namespace dre
} // namespace rootseed