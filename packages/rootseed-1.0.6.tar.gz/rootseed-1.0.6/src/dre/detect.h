// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// detect.h — Hardware Detection Structures and Functions (Section 3.2, 10)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

namespace rootseed {
namespace dre {

// ============================================================================
// CPUInfo — processor architecture and feature flags
// ============================================================================

struct CPUInfo {
    std::string vendor;           // "GenuineIntel", "AuthenticAMD", "ARM", etc.
    std::string brand;            // "Intel(R) Core(TM) i7-13700K", etc.
    std::string architecture;     // "x86_64", "aarch64", "riscv64"
    
    uint32_t num_cores = 0;       // Physical cores
    uint32_t num_threads = 0;     // Logical threads (with SMT)
    
    // x86 feature flags
    bool has_mmx      = false;
    bool has_sse      = false;
    bool has_sse2     = false;
    bool has_sse3     = false;
    bool has_ssse3    = false;
    bool has_sse4_1   = false;
    bool has_sse4_2   = false;
    bool has_avx      = false;
    bool has_avx2     = false;
    bool has_avx512f  = false;
    bool has_avx512bw = false;
    bool has_avx512dq = false;
    bool has_avx512vl = false;
    bool has_avx512vnni = false;
    bool has_avx512bf16 = false;
    bool has_amx      = false;    // Advanced Matrix Extensions (Sapphire Rapids+)
    
    // ARM feature flags
    bool has_neon     = false;
    bool has_vfpv3    = false;
    bool has_vfpv4    = false;
    bool has_fp16     = false;    // ARM FP16 scalar
    bool has_dotprod  = false;    // ARM dot product
    bool has_i8mm     = false;    // ARM integer matrix multiply
    bool has_sve      = false;    // Scalable Vector Extension
    bool has_sve2     = false;    // SVE version 2
    bool has_sme      = false;    // Scalable Matrix Extension
    bool has_bf16     = false;    // ARM BFloat16
    
    // RISC-V feature flags
    bool has_rvv      = false;    // RISC-V Vector Extension
    
    // Cache sizes (bytes)
    size_t l1_data_cache  = 32 * 1024;
    size_t l2_cache       = 256 * 1024;
    size_t l3_cache       = 8 * 1024 * 1024;
    size_t l1_cache_line  = 64;
    
    // SIMD register width (bits)
    size_t max_simd_width = 128;
    
    bool detected = false;
};

// ============================================================================
// GPUInfo — discrete or integrated GPU
// ============================================================================

enum class GPUVendor {
    Unknown,
    NVIDIA,
    AMD,
    Intel,
    ARM_Mali,
    Qualcomm_Adreno,
    Apple,
    Imagination_PowerVR,
    Broadcom_VideoCore,
};

enum class GPUDriver {
    Unknown,
    CUDA,       // NVIDIA proprietary
    ROCm,       // AMD open compute
    Vulkan,     // Cross-vendor
    Metal,      // Apple
    OpenCL,     // Cross-vendor
};

struct GPUInfo {
    std::string name;            // "NVIDIA GeForce RTX 4090"
    GPUVendor vendor = GPUVendor::Unknown;
    GPUDriver driver = GPUDriver::Unknown;
    int index = 0;               // Device index in system
    
    size_t total_memory = 0;     // VRAM in bytes
    uint32_t compute_units = 0;  // SM / CU / Xe Core count
    uint32_t max_frequency_mhz = 0;
    
    // NVIDIA-specific
    int compute_capability_major = 0;
    int compute_capability_minor = 0;
    bool has_tensor_cores = false;
    bool has_fp8 = false;
    bool has_nvlink = false;
    
    // AMD-specific
    std::string gfx_arch;        // "gfx90a", "gfx942", etc.
    bool has_matrix_cores = false;
    
    // Vulkan-specific
    bool has_vulkan_subgroups = false;
    uint32_t vulkan_subgroup_size = 32;
    bool has_vulkan_fp16 = false;
    
    bool detected = false;
    bool is_integrated = false;
};

// ============================================================================
// SystemInfo — complete hardware snapshot
// ============================================================================

struct SystemInfo {
    CPUInfo cpu;
    std::vector<GPUInfo> gpus;
    
    size_t total_ram = 0;
    size_t page_size = 4096;
    bool hugepages_available = false;
    bool numa_available = false;
    int numa_node_count = 1;
    
    // Optimal backend determined by priority
    std::string recommended_backend;
    bool has_cuda = false;
    bool has_rocm = false;
    bool has_vulkan = false;
    bool has_tpu = false;
    bool has_npu = false;
    
    bool detected = false;
};

// ============================================================================
// Detection functions
// ============================================================================

/// Detect CPU features using cpuinfo library + sysfs on Linux.
CPUInfo detect_cpu();

/// Detect all GPUs in the system.
/// Checks: NVIDIA (nvidia-smi, /proc/driver/nvidia), 
///         AMD (/sys/class/drm, rocminfo),
///         Vulkan devices,
///         integrated GPUs via sysfs.
std::vector<GPUInfo> detect_gpus();

/// Detect the complete system hardware profile.
SystemInfo detect_system();

/// Print a human-readable summary of detected hardware.
std::string system_summary(const SystemInfo& info);

} // namespace dre
} // namespace rootseed