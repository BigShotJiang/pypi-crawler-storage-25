// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// rs_format.h — .rs File Format: Magic, Version, Flags, Timestamp (Section 9, 12)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

namespace rootseed {
namespace serial {

// ============================================================================
// .rs Format Constants (Section 9.1)
// ============================================================================

// Magic: ".rs\0\0\0\0\0" (8 bytes, little-endian)
constexpr uint64_t RS_MAGIC = 0x000000000073722EULL;

// Current format version
constexpr uint16_t RS_VERSION_MAJOR = 1;
constexpr uint16_t RS_VERSION_MINOR = 0;

// Framework identifier
constexpr const char* RS_FRAMEWORK_ID = "ROOTSEED";

// Header size (up to tensor index)
constexpr size_t RS_HEADER_SIZE = 0x40;  // 64 bytes

// Alignment for tensor data
constexpr size_t RS_TENSOR_ALIGNMENT = 64;

// ============================================================================
// Flags (2 bytes)
// ============================================================================

enum class RSFlags : uint16_t {
    None        = 0,
    Compressed  = 1 << 0,   // ZSTD compression enabled
    Encrypted   = 1 << 1,   // Encrypted payload
    Sharded     = 1 << 2,   // Model split across multiple files
    Signed      = 1 << 3,   // Ed25519 signature present
};

inline RSFlags operator|(RSFlags a, RSFlags b) {
    return static_cast<RSFlags>(static_cast<uint16_t>(a) | static_cast<uint16_t>(b));
}
inline bool has_flag(RSFlags flags, RSFlags flag) {
    return (static_cast<uint16_t>(flags) & static_cast<uint16_t>(flag)) != 0;
}

// ============================================================================
// RSHeader — the 64-byte file header
// ============================================================================

#pragma pack(push, 1)
struct RSHeader {
    uint64_t magic;              // 0x00: ".rs\0\0\0\0\0"
    uint16_t version_major;      // 0x08
    uint16_t version_minor;      // 0x0A
    uint16_t flags;              // 0x0C
    uint64_t created;            // 0x10: Unix timestamp
    char framework_id[16];       // 0x18: "ROOTSEED" + padding
    uint8_t reserved[26];        // 0x28: Future expansion
};
#pragma pack(pop)

static_assert(sizeof(RSHeader) == 64, "RSHeader must be exactly 64 bytes");

// ============================================================================
// TensorEntry — index entry describing one stored tensor
// ============================================================================

#pragma pack(push, 1)
struct RSTensorEntry {
    uint64_t name_offset;        // Offset into metadata string table
    uint32_t name_length;
    uint32_t dtype;              // DType enum value
    uint32_t ndim;
    uint64_t data_offset;        // Offset from file start to tensor data
    uint64_t data_size;          // Size of tensor data in bytes
    uint64_t uncompressed_size;  // Original size before compression
    // Followed by: int64_t shape[ndim]
};
#pragma pack(pop)

// ============================================================================
// Format utilities
// ============================================================================

/// Validate that a buffer starts with the .rs magic number.
bool validate_magic(const uint8_t* data, size_t size);

/// Create a new RSHeader with current version and timestamp.
RSHeader make_header(RSFlags flags = RSFlags::None);

/// Convert a DType to its uint32_t serialized representation.
uint32_t dtype_to_serialized(const std::string& dtype_name);

/// Convert a serialized dtype back to a string.
std::string serialized_to_dtype(uint32_t dtype_code);

} // namespace serial
} // namespace rootseed