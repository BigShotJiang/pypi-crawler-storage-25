// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// rs_writer.h — .rs Model Writer with ZSTD Compression and Ed25519 Signing (Section 9, 12)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "serial/rs_format.h"
#include "core/tensor.h"

#include <string>
#include <vector>
#include <unordered_map>

namespace rootseed {
namespace serial {

// ============================================================================
// RSWriter — writes model parameters to the .rs format
//
// Features:
//   - ZSTD compression for tensor data
//   - Ed25519 cryptographic signature
//   - Lazy tensor index construction
//   - 64-byte alignment for GPU direct transfer
// ============================================================================

class RSWriter {
public:
    /// Create a writer for a model.
    /// @param metadata_json  Model architecture, hyperparameters, etc.
    explicit RSWriter(const std::string& metadata_json = "{}");
    ~RSWriter();

    /// Add a tensor to the model.
    void add_tensor(const std::string& name, const core::Tensor& tensor);

    /// Set a signing key for Ed25519 signature (optional).
    void set_signing_key(const std::vector<uint8_t>& private_key);

    /// Write the .rs file to disk.
    /// @param filepath      Output file path
    /// @param compress      If true, apply ZSTD compression
    /// @param sign          If true, append Ed25519 signature
    /// @return              true on success
    bool write(const std::string& filepath, bool compress = true, bool sign = false);

    /// Returns the number of tensors added.
    size_t tensor_count() const noexcept { return tensors_.size(); }

private:
    struct TensorRecord {
        std::string name;
        core::Tensor tensor;
    };

    std::string metadata_json_;
    std::vector<TensorRecord> tensors_;
    std::vector<uint8_t> signing_key_;
    bool has_signing_key_ = false;
};

} // namespace serial
} // namespace rootseed