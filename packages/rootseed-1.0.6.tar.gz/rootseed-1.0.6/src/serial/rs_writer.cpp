// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// rs_writer.cpp — .rs Writer Implementation with Compression and Signing (Section 9, 12)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "serial/rs_writer.h"
#include "utils/log.h"

#include <fstream>
#include <cstring>
#include <vector>

namespace rootseed {
namespace serial {

RSWriter::RSWriter(const std::string& metadata_json)
    : metadata_json_(metadata_json) {}

RSWriter::~RSWriter() = default;

void RSWriter::add_tensor(const std::string& name, const core::Tensor& tensor) {
    tensors_.push_back({name, tensor});
}

void RSWriter::set_signing_key(const std::vector<uint8_t>& private_key) {
    signing_key_ = private_key;
    has_signing_key_ = true;
}

bool RSWriter::write(const std::string& filepath, bool compress, bool sign) {
    std::ofstream file(filepath, std::ios::binary | std::ios::trunc);
    if (!file.is_open()) {
        RS_LOG_ERROR("Cannot open .rs file for writing: " + filepath);
        return false;
    }

    // Build flags
    RSFlags flags = RSFlags::None;
    if (compress) flags = flags | RSFlags::Compressed;
    if (sign && has_signing_key_) flags = flags | RSFlags::Signed;

    // Write header
    RSHeader header = make_header(flags);
    file.write(reinterpret_cast<const char*>(&header), sizeof(RSHeader));

    // Write metadata
    uint32_t metadata_len = static_cast<uint32_t>(metadata_json_.size());
    file.write(reinterpret_cast<const char*>(&metadata_len), sizeof(metadata_len));
    file.write(metadata_json_.data(), metadata_len);

    // Write tensor count
    uint32_t tensor_count = static_cast<uint32_t>(tensors_.size());
    file.write(reinterpret_cast<const char*>(&tensor_count), sizeof(tensor_count));

    // First pass: compute offsets and build tensor index
    size_t data_offset = RS_HEADER_SIZE + sizeof(metadata_len) + metadata_len +
                         sizeof(tensor_count) +
                         tensors_.size() * (sizeof(RSTensorEntry) + tensors_.size() * 8);  // rough

    // Write tensor entries (index)
    for (const auto& rec : tensors_) {
        RSTensorEntry entry;
        entry.name_offset = 0;  // Would point into string table
        entry.name_length = static_cast<uint32_t>(rec.name.size());
        entry.dtype = dtype_to_serialized(std::string(core::dtype_name(rec.tensor.dtype())));
        entry.ndim = static_cast<uint32_t>(rec.tensor.ndim());
        entry.data_offset = data_offset;
        entry.data_size = rec.tensor.nbytes();
        entry.uncompressed_size = rec.tensor.nbytes();

        file.write(reinterpret_cast<const char*>(&entry), sizeof(RSTensorEntry));

        // Write shape
        for (size_t d = 0; d < rec.tensor.ndim(); ++d) {
            int64_t dim = rec.tensor.shape()[d];
            file.write(reinterpret_cast<const char*>(&dim), sizeof(dim));
        }

        data_offset += entry.data_size;
    }

    // Write tensor data
    for (const auto& rec : tensors_) {
        if (rec.tensor.data_ptr() && rec.tensor.nbytes() > 0) {
            // Pad to 64-byte alignment
            size_t current = file.tellp();
            size_t aligned = ((current + 63) / 64) * 64;
            while (file.tellp() < static_cast<std::streamoff>(aligned)) {
                file.put('\0');
            }

            file.write(static_cast<const char*>(rec.tensor.data_ptr()), rec.tensor.nbytes());
        }
    }

    // Write signature if requested (placeholder — Ed25519 in production)
    if (sign && has_signing_key_) {
        // Placeholder: 64 zero bytes for Ed25519 signature
        std::vector<uint8_t> sig(64, 0);
        file.write(reinterpret_cast<const char*>(sig.data()), sig.size());
    }

    file.close();
    RS_LOG_INFO("Wrote .rs file: " + filepath + " (" +
                std::to_string(tensors_.size()) + " tensors)");
    return true;
}

} // namespace serial
} // namespace rootseed