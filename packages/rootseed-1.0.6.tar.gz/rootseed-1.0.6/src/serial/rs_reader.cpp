// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// rs_reader.cpp — .rs Reader with mmap and Lazy Tensor Loading (Section 9, 12)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "serial/rs_reader.h"
#include "utils/log.h"

#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>

namespace rootseed {
namespace serial {

RSReader::RSReader(const std::string& filepath)
    : filepath_(filepath) {

    // Open file
    fd_ = open(filepath.c_str(), O_RDONLY);
    if (fd_ < 0) {
        RS_LOG_ERROR("Cannot open .rs file: " + filepath);
        return;
    }

    // Get file size
    struct stat st;
    if (fstat(fd_, &st) != 0) {
        close(fd_);
        return;
    }
    mapped_size_ = st.st_size;

    // Memory-map the file (zero-copy)
    mapped_data_ = mmap(nullptr, mapped_size_, PROT_READ, MAP_PRIVATE, fd_, 0);
    if (mapped_data_ == MAP_FAILED) {
        RS_LOG_ERROR("mmap failed for .rs file: " + filepath);
        close(fd_);
        return;
    }

    // Validate magic
    auto* data = static_cast<uint8_t*>(mapped_data_);
    if (!validate_magic(data, mapped_size_)) {
        RS_LOG_ERROR("Invalid .rs file magic: " + filepath);
        munmap(mapped_data_, mapped_size_);
        close(fd_);
        return;
    }

    // Parse header
    std::memcpy(&header_, data, sizeof(RSHeader));

    // Parse tensor index
    parse_tensor_index();

    valid_ = true;
    RS_LOG_INFO("Loaded .rs file: " + filepath + " (" +
                std::to_string(tensor_entries_.size()) + " tensors)");
}

RSReader::~RSReader() {
    if (mapped_data_ && mapped_data_ != MAP_FAILED) {
        munmap(mapped_data_, mapped_size_);
    }
    if (fd_ >= 0) {
        close(fd_);
    }
}

void RSReader::parse_tensor_index() {
    auto* data = static_cast<uint8_t*>(mapped_data_);

    // Metadata starts at offset 0x40 (after header)
    size_t offset = RS_HEADER_SIZE;

    // Read metadata length (4 bytes)
    uint32_t metadata_len;
    std::memcpy(&metadata_len, data + offset, sizeof(metadata_len));
    offset += sizeof(metadata_len);

    // Read metadata JSON
    metadata_json_ = std::string(reinterpret_cast<char*>(data + offset), metadata_len);
    offset += metadata_len;

    // Read tensor count (4 bytes)
    uint32_t tensor_count;
    std::memcpy(&tensor_count, data + offset, sizeof(tensor_count));
    offset += sizeof(tensor_count);

    // Read each tensor entry
    for (uint32_t i = 0; i < tensor_count; ++i) {
        RSTensorEntry entry;
        std::memcpy(&entry, data + offset, sizeof(RSTensorEntry));
        offset += sizeof(RSTensorEntry);

        // Read shape
        std::vector<int64_t> shape(entry.ndim);
        for (uint32_t d = 0; d < entry.ndim; ++d) {
            int64_t dim;
            std::memcpy(&dim, data + offset, sizeof(int64_t));
            offset += sizeof(int64_t);
            shape[d] = dim;
            tensor_shapes_.push_back(dim);
        }

        tensor_entries_.push_back(entry);

        // Read tensor name from metadata string table
        std::string name(reinterpret_cast<char*>(data + entry.name_offset), entry.name_length);
        tensor_names_.push_back(name);
    }
}

std::string RSReader::metadata() const {
    return metadata_json_;
}

std::vector<std::string> RSReader::tensor_names() const {
    return tensor_names_;
}

core::Tensor RSReader::load_tensor(const std::string& name) {
    for (size_t i = 0; i < tensor_names_.size(); ++i) {
        if (tensor_names_[i] == name) {
            const auto& entry = tensor_entries_[i];
            auto* data = static_cast<uint8_t*>(mapped_data_);

            // Get shape from tensor_shapes_
            // (Simplified: construct shape from stored dims)
            core::Shape shape;  // Would reconstruct from tensor_shapes_

            std::string dtype = serialized_to_dtype(entry.dtype);

            // Create tensor pointing to mmap'd data (zero-copy)
            // In production, this wraps the mmap'd pointer directly
            core::Tensor tensor = core::Tensor::zeros(shape,
                core::dtype_from_string(dtype));

            // Copy data into tensor (or use the mmap'd pointer directly)
            std::memcpy(tensor.data_ptr(), data + entry.data_offset, entry.data_size);

            return tensor;
        }
    }

    RS_LOG_WARN("Tensor not found in .rs file: " + name);
    return core::Tensor();
}

std::unordered_map<std::string, core::Tensor> RSReader::load_all_tensors() {
    std::unordered_map<std::string, core::Tensor> result;
    for (const auto& name : tensor_names_) {
        result[name] = load_tensor(name);
    }
    return result;
}

} // namespace serial
} // namespace rootseed