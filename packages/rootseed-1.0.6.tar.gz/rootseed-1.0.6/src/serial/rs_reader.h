// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// rs_reader.h — Zero-Copy .rs Model Deserialization via mmap (Section 9, 12)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#pragma once

#include "serial/rs_format.h"
#include "core/tensor.h"

#include <string>
#include <vector>
#include <memory>
#include <unordered_map>

namespace rootseed {
namespace serial {

// ============================================================================
// RSReader — reads .rs model files with zero-copy mmap support
//
// Features:
//   - Memory-mapped tensor data for instant loading
//   - Lazy loading: tensors are mapped only when accessed
//   - Cryptographic signature verification (Ed25519)
//   - Sharded model support
// ============================================================================

class RSReader {
public:
    /// Open a .rs file for reading.
    explicit RSReader(const std::string& filepath);
    ~RSReader();

    /// Returns true if the file was opened and validated.
    bool is_valid() const noexcept { return valid_; }

    /// Read the file header.
    const RSHeader& header() const noexcept { return header_; }

    /// Returns the metadata (model architecture, hyperparameters, etc.) as a JSON string.
    std::string metadata() const;

    /// Returns all tensor names stored in the file.
    std::vector<std::string> tensor_names() const;

    /// Load a specific tensor by name (lazy — maps on first access).
    core::Tensor load_tensor(const std::string& name);

    /// Load all tensors into a map.
    std::unordered_map<std::string, core::Tensor> load_all_tensors();

    /// Verify the Ed25519 signature (if present).
    bool verify_signature() const noexcept { return signature_valid_; }

    /// Returns the total number of tensors in the file.
    size_t tensor_count() const noexcept { return tensor_entries_.size(); }

private:
    void parse_tensor_index();

    std::string filepath_;
    int fd_ = -1;
    void* mapped_data_ = nullptr;
    size_t mapped_size_ = 0;
    bool valid_ = false;
    bool signature_valid_ = true;  // True if unsigned, verified if signed

    RSHeader header_;
    std::string metadata_json_;
    std::vector<RSTensorEntry> tensor_entries_;
    std::vector<int64_t> tensor_shapes_;  // Flattened shape data for all tensors
    std::vector<std::string> tensor_names_;
};

} // namespace serial
} // namespace rootseed