// ============================================================================
// Root-Seed: A Fully Dynamic Deep Learning Framework with Extreme Hardware-Software Co-Design
// rs_format.cpp — .rs Format Header Parsing and Validation (Section 9, 12)
// Copyright (c) 2026 Fardin Sabid
// ============================================================================

#include "serial/rs_format.h"

#include <cstring>
#include <ctime>
#include <stdexcept>

namespace rootseed {
namespace serial {

bool validate_magic(const uint8_t* data, size_t size) {
    if (size < 8) return false;
    uint64_t magic;
    std::memcpy(&magic, data, sizeof(magic));
    return magic == RS_MAGIC;
}

RSHeader make_header(RSFlags flags) {
    RSHeader header;
    header.magic = RS_MAGIC;
    header.version_major = RS_VERSION_MAJOR;
    header.version_minor = RS_VERSION_MINOR;
    header.flags = static_cast<uint16_t>(flags);
    header.created = static_cast<uint64_t>(std::time(nullptr));

    // Fill framework ID
    std::memset(header.framework_id, 0, sizeof(header.framework_id));
    std::memcpy(header.framework_id, RS_FRAMEWORK_ID, 8);

    // Zero reserved
    std::memset(header.reserved, 0, sizeof(header.reserved));

    return header;
}

uint32_t dtype_to_serialized(const std::string& dtype_name) {
    if (dtype_name == "float32")  return 0;
    if (dtype_name == "float16")  return 1;
    if (dtype_name == "bfloat16") return 2;
    if (dtype_name == "float64")  return 3;
    if (dtype_name == "int8")     return 4;
    if (dtype_name == "uint8")    return 5;
    if (dtype_name == "int16")    return 6;
    if (dtype_name == "int32")    return 7;
    if (dtype_name == "int64")    return 8;
    if (dtype_name == "bool")     return 9;
    return 0;  // Default: float32
}

std::string serialized_to_dtype(uint32_t dtype_code) {
    switch (dtype_code) {
        case 0:  return "float32";
        case 1:  return "float16";
        case 2:  return "bfloat16";
        case 3:  return "float64";
        case 4:  return "int8";
        case 5:  return "uint8";
        case 6:  return "int16";
        case 7:  return "int32";
        case 8:  return "int64";
        case 9:  return "bool";
        default: return "float32";
    }
}

} // namespace serial
} // namespace rootseed