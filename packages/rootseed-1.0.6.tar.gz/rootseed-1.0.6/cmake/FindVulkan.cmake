# FindVulkan.cmake — Root-Seed Vulkan detection
# Detects: Vulkan SDK, subgroup operations, FP16 support, compute queue
#
# Provides:
#   VULKAN_FOUND               - Vulkan SDK available
#   VULKAN_HAS_SUBGROUP        - Subgroup operations supported
#   VULKAN_HAS_FP16            - FP16 storage/intermediate supported
#   VULKAN_HAS_INT8            - INT8 dot product supported
#   VULKAN_SUBGROUP_SIZE       - Subgroup size (e.g., 32 for NVIDIA/AMD, 4 for ARM Mali)
#
# Usage:
#   find_package(Vulkan REQUIRED)
#   if(VULKAN_HAS_SUBGROUP)
#       target_compile_definitions(my_target PRIVATE RS_VULKAN_SUBGROUP)
#   endif()

# ---- Locate Vulkan SDK ----
find_package(Vulkan QUIET)

if(NOT Vulkan_FOUND)
    set(VULKAN_FOUND FALSE)
    return()
endif()

set(VULKAN_FOUND TRUE)

# ---- Probe device capabilities via a small Vulkan info program ----
# We compile and run a small C program that queries physical device properties
set(_vulkan_probe_source
"#include <vulkan/vulkan.h>
#include <stdio.h>
int main() {
    VkInstance instance;
    VkApplicationInfo ai = {VK_STRUCTURE_TYPE_APPLICATION_INFO,0,\"probe\",1,\"none\",1,VK_API_VERSION_1_2};
    VkInstanceCreateInfo ci = {VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,0,0,0,0,0,&ai,0,0,0};
    if(vkCreateInstance(&ci,0,&instance)!=VK_SUCCESS) return 1;
    uint32_t dc=0; vkEnumeratePhysicalDevices(instance,&dc,0);
    if(dc==0) return 2;
    VkPhysicalDevice d; vkEnumeratePhysicalDevices(instance,&dc,&d);
    VkPhysicalDeviceSubgroupProperties sg={VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SUBGROUP_PROPERTIES,0,0,0,0};
    VkPhysicalDeviceFloat16Int8FeaturesKHR f16i8={VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FLOAT16_INT8_FEATURES_KHR,0,0,0};
    VkPhysicalDeviceFeatures2 f2={VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2,&f16i8,0};
    vkGetPhysicalDeviceFeatures2(d,&f2);
    sg.pNext = f2.pNext; f2.pNext = &sg;
    vkGetPhysicalDeviceFeatures2(d,&f2);
    printf(\"SUBGROUP_SIZE:%u\\n\",sg.subgroupSize);
    printf(\"SUBGROUP_OPS:%u\\n\",sg.supportedOperations&VK_SUBGROUP_FEATURE_BASIC_BIT&&sg.supportedStages&VK_SHADER_STAGE_COMPUTE_BIT?1:0);
    printf(\"FP16:%u\\n\",f16i8.shaderFloat16?1:0);
    printf(\"INT8:%u\\n\",f16i8.shaderInt8?1:0);
    vkDestroyInstance(instance,0);
    return 0;
}"
)

file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/vulkan_probe.c" "${_vulkan_probe_source}")

try_run(
    VULKAN_PROBE_RUN VULKAN_PROBE_COMPILE
    "${CMAKE_CURRENT_BINARY_DIR}"
    "${CMAKE_CURRENT_BINARY_DIR}/vulkan_probe.c"
    LINK_LIBRARIES Vulkan::Vulkan
    CMAKE_FLAGS "-DCMAKE_C_STANDARD=11"
    RUN_OUTPUT_VARIABLE _probe_output
)

if(VULKAN_PROBE_COMPILE AND VULKAN_PROBE_RUN EQUAL 0 AND _probe_output)
    string(REGEX MATCH "SUBGROUP_SIZE:([0-9]+)" _ "${_probe_output}")
    set(VULKAN_SUBGROUP_SIZE ${CMAKE_MATCH_1})

    string(REGEX MATCH "SUBGROUP_OPS:([0-9]+)" _ "${_probe_output}")
    set(VULKAN_HAS_SUBGROUP ${CMAKE_MATCH_1})

    string(REGEX MATCH "FP16:([0-9]+)" _ "${_probe_output}")
    set(VULKAN_HAS_FP16 ${CMAKE_MATCH_1})

    string(REGEX MATCH "INT8:([0-9]+)" _ "${_probe_output}")
    set(VULKAN_HAS_INT8 ${CMAKE_MATCH_1})
else()
    # Safe defaults for build (will be probed at runtime by DRE)
    set(VULKAN_SUBGROUP_SIZE 32)
    set(VULKAN_HAS_SUBGROUP TRUE)
    set(VULKAN_HAS_FP16 TRUE)
    set(VULKAN_HAS_INT8 TRUE)
endif()

# ---- Report ----
include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(Vulkan
    REQUIRED_VARS VULKAN_FOUND
    HANDLE_COMPONENTS
)

if(VULKAN_FOUND)
    message(STATUS "Vulkan: subgroup_size=${VULKAN_SUBGROUP_SIZE}")
    message(STATUS "  Subgroup Ops: ${VULKAN_HAS_SUBGROUP}")
    message(STATUS "  FP16:         ${VULKAN_HAS_FP16}")
    message(STATUS "  INT8:         ${VULKAN_HAS_INT8}")
endif()