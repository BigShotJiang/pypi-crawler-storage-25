# FindTPU.cmake — Root-Seed Google TPU detection
# Detects: libtpu.so (Cloud TPU) and libedgetpu.so (Coral Edge TPU)
#
# Provides:
#   TPU_FOUND         - TPU runtime library available
#   TPU_IS_CLOUD      - Cloud TPU (libtpu.so)
#   TPU_IS_EDGE       - Coral/Edge TPU (libedgetpu.so)
#
# Usage:
#   find_package(TPU)
#   if(TPU_FOUND)
#       target_link_libraries(my_target PRIVATE tpu_runtime)
#   endif()

set(TPU_FOUND FALSE)
set(TPU_IS_CLOUD FALSE)
set(TPU_IS_EDGE FALSE)

# ---- Detect Cloud TPU (libtpu.so) ----
find_library(TPU_CLOUD_LIBRARY
    NAMES tpu
    PATHS
        /usr/lib
        /usr/local/lib
        /usr/lib/x86_64-linux-gnu
        /usr/lib/aarch64-linux-gnu
    DOC "Google Cloud TPU runtime library"
)

if(TPU_CLOUD_LIBRARY)
    set(TPU_FOUND TRUE)
    set(TPU_IS_CLOUD TRUE)
    
    add_library(tpu_runtime SHARED IMPORTED)
    set_target_properties(tpu_runtime PROPERTIES
        IMPORTED_LOCATION "${TPU_CLOUD_LIBRARY}"
    )
    message(STATUS "TPU: Cloud TPU runtime detected (libtpu.so)")
endif()

# ---- Detect Edge TPU (libedgetpu.so) ----
find_library(TPU_EDGE_LIBRARY
    NAMES edgetpu
    PATHS
        /usr/lib
        /usr/local/lib
        /usr/lib/arm-linux-gnueabihf
        /usr/lib/aarch64-linux-gnu
    DOC "Google Coral Edge TPU runtime library"
)

if(TPU_EDGE_LIBRARY)
    set(TPU_FOUND TRUE)
    set(TPU_IS_EDGE TRUE)
    
    if(NOT TARGET tpu_runtime)
        add_library(tpu_runtime SHARED IMPORTED)
    endif()
    set_target_properties(tpu_runtime PROPERTIES
        IMPORTED_LOCATION "${TPU_EDGE_LIBRARY}"
    )
    message(STATUS "TPU: Edge TPU runtime detected (libedgetpu.so)")
endif()

# ---- Report ----
include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(TPU
    REQUIRED_VARS TPU_FOUND
    HANDLE_COMPONENTS
)

if(TPU_FOUND)
    if(TPU_IS_CLOUD AND TPU_IS_EDGE)
        message(STATUS "TPU: Both Cloud and Edge TPU runtimes available")
    elseif(TPU_IS_CLOUD)
        message(STATUS "TPU: Cloud TPU only")
    elseif(TPU_IS_EDGE)
        message(STATUS "TPU: Edge TPU only")
    endif()
else()
    message(STATUS "TPU: Not found (will skip TPU backend)")
endif()