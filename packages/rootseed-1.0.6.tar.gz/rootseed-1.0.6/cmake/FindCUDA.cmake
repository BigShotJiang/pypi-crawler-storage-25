# FindCUDA.cmake — Root-Seed NVIDIA CUDA detection
# Detects: nvcc, cuBLAS, cuDNN, cuSPARSE, NCCL, Tensor Cores, FP8 support
#
# Provides:
#   CUDA_FOUND              - System has CUDA
#   CUDA_COMPUTE_CAPABILITY - e.g., "8.0", "8.9", "9.0"
#   CUDA_HAS_TENSOR_CORES   - Compute Capability >= 7.0
#   CUDA_HAS_FP8            - Compute Capability >= 8.9 (Ada/Hopper)
#   CUDA_HAS_NCCL           - NCCL library available
#
# Usage:
#   find_package(CUDA)
#   if(CUDA_FOUND AND CUDA_HAS_TENSOR_CORES)
#       target_compile_definitions(my_target PRIVATE RS_CUDA_TENSOR_CORES)
#   endif()

# ---- Locate CUDA Toolkit ----
find_package(CUDAToolkit QUIET)

if(NOT CUDAToolkit_FOUND)
    set(CUDA_FOUND FALSE)
    return()
endif()

set(CUDA_FOUND TRUE)

# ---- Detect Compute Capability ----
# Try nvidia-smi first, then deviceQuery fallback
set(CUDA_COMPUTE_CAPABILITY "")

# Query first GPU's compute capability via nvidia-smi
execute_process(
    COMMAND nvidia-smi --query-gpu=compute_cap --format=csv,noheader
    OUTPUT_VARIABLE _cuda_cc_output
    ERROR_QUIET
    OUTPUT_STRIP_TRAILING_WHITESPACE
)

if(_cuda_cc_output)
    # Take first line (first GPU)
    string(REGEX REPLACE "\n.*" "" CUDA_COMPUTE_CAPABILITY "${_cuda_cc_output}")
    string(STRIP "${CUDA_COMPUTE_CAPABILITY}" CUDA_COMPUTE_CAPABILITY)
else()
    # Fallback: attempt to compile and run a small deviceQuery
    message(STATUS "CUDA: nvidia-smi not available, checking via CUDA runtime")
    # Assume a reasonable default for build purposes
    set(CUDA_COMPUTE_CAPABILITY "7.5")
endif()

# ---- Parse Major.Minor ----
string(REGEX MATCH "^([0-9]+)\\.([0-9]+)$" _ "${CUDA_COMPUTE_CAPABILITY}")
set(CUDA_CC_MAJOR ${CMAKE_MATCH_1})
set(CUDA_CC_MINOR ${CMAKE_MATCH_2})

# Tensor Cores: SM 7.0+ (Volta, Turing, Ampere, Ada, Hopper)
if(CUDA_CC_MAJOR GREATER_EQUAL 7)
    set(CUDA_HAS_TENSOR_CORES TRUE)
else()
    set(CUDA_HAS_TENSOR_CORES FALSE)
endif()

# FP8 natively: SM 8.9+ (Ada Lovelace / Hopper)
if(CUDA_CC_MAJOR GREATER 8 OR (CUDA_CC_MAJOR EQUAL 8 AND CUDA_CC_MINOR GREATER_EQUAL 9))
    set(CUDA_HAS_FP8 TRUE)
else()
    set(CUDA_HAS_FP8 FALSE)
endif()

# ---- Locate cuDNN ----
find_library(CUDNN_LIBRARY cudnn HINTS ${CUDAToolkit_LIBRARY_DIR})
find_path(CUDNN_INCLUDE_DIR cudnn.h HINTS ${CUDAToolkit_INCLUDE_DIRS})
if(CUDNN_LIBRARY AND CUDNN_INCLUDE_DIR)
    set(CUDA_HAS_CUDNN TRUE)
    add_library(cudnn SHARED IMPORTED)
    set_target_properties(cudnn PROPERTIES
        IMPORTED_LOCATION "${CUDNN_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${CUDNN_INCLUDE_DIR}"
    )
else()
    set(CUDA_HAS_CUDNN FALSE)
endif()

# ---- Locate cuBLAS ----
find_library(CUBLAS_LIBRARY cublas HINTS ${CUDAToolkit_LIBRARY_DIR})
if(CUBLAS_LIBRARY)
    set(CUDA_HAS_CUBLAS TRUE)
else()
    set(CUDA_HAS_CUBLAS FALSE)
endif()

# ---- Locate cuSPARSE ----
find_library(CUSPARSE_LIBRARY cusparse HINTS ${CUDAToolkit_LIBRARY_DIR})
if(CUSPARSE_LIBRARY)
    set(CUDA_HAS_CUSPARSE TRUE)
else()
    set(CUDA_HAS_CUSPARSE FALSE)
endif()

# ---- Locate NCCL ----
find_library(NCCL_LIBRARY nccl HINTS ${CUDAToolkit_LIBRARY_DIR})
find_path(NCCL_INCLUDE_DIR nccl.h HINTS ${CUDAToolkit_INCLUDE_DIRS})
if(NCCL_LIBRARY AND NCCL_INCLUDE_DIR)
    set(CUDA_HAS_NCCL TRUE)
else()
    set(CUDA_HAS_NCCL FALSE)
endif()

# ---- Report ----
include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(CUDA
    REQUIRED_VARS CUDA_FOUND
    VERSION_VAR CUDA_COMPUTE_CAPABILITY
    HANDLE_COMPONENTS
)

if(CUDA_FOUND)
    message(STATUS "CUDA Compute Capability: ${CUDA_COMPUTE_CAPABILITY}")
    message(STATUS "  Tensor Cores: ${CUDA_HAS_TENSOR_CORES}")
    message(STATUS "  FP8 Native:   ${CUDA_HAS_FP8}")
    message(STATUS "  cuDNN:        ${CUDA_HAS_CUDNN}")
    message(STATUS "  cuBLAS:       ${CUDA_HAS_CUBLAS}")
    message(STATUS "  cuSPARSE:     ${CUDA_HAS_CUSPARSE}")
    message(STATUS "  NCCL:         ${CUDA_HAS_NCCL}")
endif()