# FindROCm.cmake — Root-Seed AMD ROCm detection
# Detects: hip, rocBLAS, MIOpen, rocSPARSE, RCCL, Matrix Cores (gfx90a+)
#
# Provides:
#   ROCM_FOUND            - System has ROCm
#   ROCM_GFX_ARCH         - e.g., "gfx90a", "gfx942"
#   ROCM_HAS_MATRIX_CORES - gfx90a+ (MI200/MI300 series)
#   ROCM_HAS_MIOPEN       - MIOpen available
#   ROCM_HAS_ROCBLAS      - rocBLAS available
#   ROCM_HAS_ROCSPARSE    - rocSPARSE available
#   ROCM_HAS_RCCL         - RCCL available (multi-GPU)
#
# Usage:
#   find_package(ROCm)
#   if(ROCM_FOUND AND ROCM_HAS_MATRIX_CORES)
#       target_compile_definitions(my_target PRIVATE RS_ROCM_MATRIX_CORES)
#   endif()

# ---- Locate HIP ----
find_package(hip QUIET)

if(NOT hip_FOUND)
    set(ROCM_FOUND FALSE)
    return()
endif()

set(ROCM_FOUND TRUE)

# ---- Detect GPU Architecture ----
execute_process(
    COMMAND rocminfo
    OUTPUT_VARIABLE _rocminfo_output
    ERROR_QUIET
)

if(_rocminfo_output)
    # Extract gfx architecture string
    string(REGEX MATCH "gfx[0-9a-z]+" ROCM_GFX_ARCH "${_rocminfo_output}")
    if(ROCM_GFX_ARCH)
        message(STATUS "ROCm GPU Architecture: ${ROCM_GFX_ARCH}")
    endif()
endif()

# Default to gfx90a if detection fails
if(NOT ROCM_GFX_ARCH)
    set(ROCM_GFX_ARCH "gfx90a")
endif()

# Matrix Cores: gfx90a (MI200) and gfx94x (MI300) families
if(ROCM_GFX_ARCH MATCHES "^gfx9[0-9a-z]")
    # gfx90a, gfx940, gfx941, gfx942
    set(ROCM_HAS_MATRIX_CORES TRUE)
elseif(ROCM_GFX_ARCH MATCHES "^gfx1[0-9]")
    # Future architectures
    set(ROCM_HAS_MATRIX_CORES TRUE)
else()
    set(ROCM_HAS_MATRIX_CORES FALSE)
endif()

# ---- Locate rocBLAS ----
find_library(ROCBLAS_LIBRARY rocblas HINTS ${ROCM_PATH}/lib)
if(ROCBLAS_LIBRARY)
    set(ROCM_HAS_ROCBLAS TRUE)
else()
    set(ROCM_HAS_ROCBLAS FALSE)
endif()

# ---- Locate MIOpen ----
find_library(MIOPEN_LIBRARY MIOpen HINTS ${ROCM_PATH}/lib)
find_path(MIOPEN_INCLUDE_DIR miopen/miopen.h HINTS ${ROCM_PATH}/include)
if(MIOPEN_LIBRARY AND MIOPEN_INCLUDE_DIR)
    set(ROCM_HAS_MIOPEN TRUE)
else()
    set(ROCM_HAS_MIOPEN FALSE)
endif()

# ---- Locate rocSPARSE ----
find_library(ROCSPARSE_LIBRARY rocsparse HINTS ${ROCM_PATH}/lib)
if(ROCSPARSE_LIBRARY)
    set(ROCM_HAS_ROCSPARSE TRUE)
else()
    set(ROCM_HAS_ROCSPARSE FALSE)
endif()

# ---- Locate RCCL ----
find_library(RCCL_LIBRARY rccl HINTS ${ROCM_PATH}/lib)
find_path(RCCL_INCLUDE_DIR rccl.h HINTS ${ROCM_PATH}/include)
if(RCCL_LIBRARY AND RCCL_INCLUDE_DIR)
    set(ROCM_HAS_RCCL TRUE)
else()
    set(ROCM_HAS_RCCL FALSE)
endif()

# ---- Report ----
include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(ROCm
    REQUIRED_VARS ROCM_FOUND
    VERSION_VAR ROCM_GFX_ARCH
    HANDLE_COMPONENTS
)

if(ROCM_FOUND)
    message(STATUS "ROCm GPU Architecture: ${ROCM_GFX_ARCH}")
    message(STATUS "  Matrix Cores: ${ROCM_HAS_MATRIX_CORES}")
    message(STATUS "  MIOpen:       ${ROCM_HAS_MIOPEN}")
    message(STATUS "  rocBLAS:      ${ROCM_HAS_ROCBLAS}")
    message(STATUS "  rocSPARSE:    ${ROCM_HAS_ROCSPARSE}")
    message(STATUS "  RCCL:         ${ROCM_HAS_RCCL}")
endif()