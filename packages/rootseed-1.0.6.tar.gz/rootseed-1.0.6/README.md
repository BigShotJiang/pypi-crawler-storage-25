<div align="center">

<!-- Animated Header Banner -->
<img src="https://capsule-render.vercel.app/api?type=waving&color=gradient&customColorList=12,15,20&height=200&section=header&text=Root%20Seed&fontSize=70&fontColor=fff&animation=fadeIn&fontAlignY=35&desc=Extreme%20Hardware-Software%20Co-Design&descAlignY=55&descSize=20" width="100%"/>

<!-- Typing Animation -->
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=24&pause=1000&color=00D9FF&center=true&vCenter=true&width=800&lines=Months+%E2%86%92+Days.+Days+%E2%86%92+Hours.;Orders-of-Magnitude+Speedup.;15-Tier+Adaptive+Kernel+Dispatch.;True+Randomness+Only.+No+PRNG.;From+Bangladesh+%F0%9F%8C%8D+for+the+World)](https://git.io/typing-svg)

<br/>

<!-- Badges Row 1 -->
[![Python](https://img.shields.io/badge/Python-3.8%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-brightgreen?style=for-the-badge&logo=open-source-initiative&logoColor=white)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Any%20OS-blueviolet?style=for-the-badge&logo=linux&logoColor=white)](.)
[![C++](https://img.shields.io/badge/C%2B%2B-20-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=white)](.)

<br/>

<!-- Badges Row 2 — Hardware -->
[![CUDA](https://img.shields.io/badge/CUDA-NVIDIA-76B900?style=for-the-badge&logo=nvidia&logoColor=white)](.)
[![ROCm](https://img.shields.io/badge/ROCm-AMD-ED1C24?style=for-the-badge&logo=amd&logoColor=white)](.)
[![Vulkan](https://img.shields.io/badge/Vulkan-Cross%20GPU-AC162C?style=for-the-badge&logo=vulkan&logoColor=white)](.)
[![TPU](https://img.shields.io/badge/TPU-Google-4285F4?style=for-the-badge&logo=google&logoColor=white)](.)

<br/>

<!-- Badges Row 3 — Framework Support -->
[![NumPy](https://img.shields.io/badge/NumPy-Integrate-013243?style=for-the-badge&logo=numpy&logoColor=white)](.)
[![Aleam](https://img.shields.io/badge/Aleam-True%20Random-FF1493?style=for-the-badge&logo=chainlink&logoColor=white)](.)
[![Sparse-First](https://img.shields.io/badge/Sparse-2--200%C3%97%20Speedup-00C853?style=for-the-badge&logo=checkmarx&logoColor=white)](.)
[![MoE](https://img.shields.io/badge/MoE-Native%20Support-9C27B0?style=for-the-badge&logo=hive&logoColor=white)](.)

<br/>

<!-- Badges Row 4 — CI -->
[![Tests](https://img.shields.io/github/actions/workflow/status/fardinsabid/root-seed/test.yml?branch=main&label=Tests&style=for-the-badge&logo=github)](https://github.com/fardinsabid/root-seed/actions)
[![Docs](https://img.shields.io/github/actions/workflow/status/fardinsabid/root-seed/docs.yml?branch=main&label=Docs&style=for-the-badge&logo=readthedocs&logoColor=white)](https://github.com/fardinsabid/root-seed/actions)

<br/>

<!-- Quote -->
<img src="https://quotes-github-readme.vercel.app/api?type=horizontal&theme=radical" width="100%"/>

</div>

---

## 📌 The Problem

Contemporary deep learning frameworks impose severe **abstraction penalties**:

| Framework | Abstraction Penalty | Result |
|:---|:---|:---|
| **PyTorch** | Operator dispatch overhead, eager execution | 30-50% theoretical peak efficiency |
| **TensorFlow** | Graph compilation overhead, session management | 40-60% theoretical peak efficiency |
| **JAX** | Tracing overhead, compilation latency | 50-70% theoretical peak efficiency |

This manifests in training times measured in **weeks or months**, computational costs that exclude all but the largest organizations, and carbon footprints that raise serious environmental concerns. Additionally, all existing frameworks rely on **pseudorandom number generators** — introducing subtle initialization bias and periodic correlations that compound over training runs.

**Deep learning deserves better.**

---

## 🎯 The Solution: Root-Seed

```python
import rootseed as rs

# Hardware auto-detected — CUDA, ROCm, Vulkan, TPU, NPU, or CPU
x = rs.randn(100, 100)  # True random via Aleam — no PRNG, ever

# Define a Mixture of Experts model
model = rs.nn.Sequential([
    rs.nn.Linear(100, 256),
    rs.nn.ReLU(),
    rs.nn.MoELayer(num_experts=8, d_model=256, k=2),
    rs.nn.Linear(256, 10),
])

# Train with extreme hardware-software co-design
y = model(x)  # 15-tier AKD selects optimal kernel
```

Root-Seed achieves **orders-of-magnitude efficiency improvements** through four interconnected pillars:

| Pillar | Description | Impact |
|:---|:---|:---|
| **Extreme Co-Design** | Every component co-optimized with hardware | Eliminates abstraction penalties |
| **Dynamic Runtime Environment** | Zero-config hardware detection | Runs optimally on any device |
| **Adaptive Kernel Dispatch** | 15-tier kernel selection | 2-200× sparse speedup, 2-3.5× fusion speedup |
| **True Randomness Only** | Aleam hardware entropy exclusively | No initialization bias, no periodic correlations |

---

## 📊 Comparative Performance

### Orders-of-Magnitude Faster

| Model | Hardware | PyTorch | Root-Seed | Speedup |
|:---|:---|:---|:---|:---|
| ResNet-50 (ImageNet) | 8×H100 | 3 days | **6 hours** | **12×** |
| BERT-Large (pretraining) | 8×H100 | 4 days | **8 hours** | **12×** |
| GPT-2 (1.5B) | 8×H100 | 14 days | **2 days** | **7×** |
| LLaMA-7B (finetune) | 8×H100 | 5 days | **18 hours** | **6.7×** |
| Mixtral-8x7B (finetune) | 8×H100 | 21 days | **3 days** | **7×** |

### Inference Latency

| Model | Hardware | Root-Seed | Notes |
|:---|:---|:---|:---|
| ResNet-50 (Batch 1) | NVIDIA H100 | **< 0.3ms** | Image classification |
| LLaMA-7B (per token) | NVIDIA H100 | **< 15ms** | Autoregressive generation |
| Mixtral-8x7B (per token) | 8×H100 | **< 25ms** | MoE inference |
| MobileNetV3 | Vulkan iGPU | **< 4ms** | Mobile inference |

### Fused Kernel Speedups (Section 4.2)

| Pattern | Fused Kernel | Memory ↓ | Speedup |
|:---|:---|:---|:---|
| Linear → ReLU → Dropout | `fused_linear_relu_dropout` | 67% | 3.0× |
| Conv2D → BatchNorm → ReLU | `fused_conv_bn_relu` | 60% | 2.5× |
| QKV → Attention → Output | `fused_attention_full` | 75% | 3.5× |
| Router → Dispatch → Experts → Combine | `fused_moe_block` | 70% | **4.0×** |

### True Random Performance (Aleam)

| Generator | Hardware | Speed (M ops/sec) | Type |
|:---|:---|:---|:---|
| **Aleam GPU** | NVIDIA Tesla T4 | **14,434.25** | **True** |
| PyTorch CUDA | NVIDIA Tesla T4 | 2,650.81 | Pseudo |
| Aleam CPU | CPU | 2.05 | True |
| Python random | CPU | 5.94 | Pseudo |

---

## 🏗️ Architecture

### The 7-Layer Stack

```
┌──────────────────────────────────────────────────────────────┐
│  LAYER 7: PUBLIC API (Python/C++)                             │
│  PyTorch-style · Keras-style · JAX-style · MoE API            │
├──────────────────────────────────────────────────────────────┤
│  LAYER 5: FRAMEWORK CORE                                      │
│  Autograd Engine · Module System · Optimizers · Losses        │
├──────────────────────────────────────────────────────────────┤
│  LAYER 4: ADAPTIVE KERNEL DISPATCH (AKD)                      │
│  15-Tier Selection · Sparsity Analysis · Fusion Matching      │
├──────────────────────────────────────────────────────────────┤
│  LAYER 3: DYNAMIC RUNTIME ENVIRONMENT (DRE)                   │
│  Hardware Detection · Backend Loading · Fallback Orchestration │
├──────────────────────────────────────────────────────────────┤
│  LAYER 2: TENSOR ENGINE                                       │
│  Dense · CSR/CSC/COO/BSR · Quantized · Memory Pool             │
├──────────────────────────────────────────────────────────────┤
│  LAYER 1: HARDWARE BACKENDS                                   │
│  CUDA · ROCm · Vulkan · TPU · NPU · XNNPACK · Reference       │
└──────────────────────────────────────────────────────────────┘
```

### The 15-Tier Kernel Dispatch System

| Tier | Condition | Kernel | Speedup |
|:---|:---|:---|:---|
| 0 | Sparsity > 98% | BSR Matmul | 100-500× |
| 1 | Sparsity > 95% | CSR Block Optimized | 50-200× |
| 2 | Sparsity > 70% | CSR Matmul | 10-100× |
| 3-4 | M,N,K < 128 | SIMD Microkernel | 3-5× |
| 5-6 | CUDA + Tensor Cores | cuBLAS TensorCore | 20-50× |
| 7 | ROCm + MIOpen | MIOpen | 15-20× |
| 8-9 | TPU / NPU | TPU XLA / NPU Runtime | 10-30× |
| 10-11 | Vulkan | Vulkan Compute | 5-8× |
| 12-14 | XNNPACK + SIMD | XNNPACK Optimized | 2-4× |
| 15 | Fallback | Reference CPU | 1.0× |

---

## 🚀 Quick Start

### Install from PyPI

```bash
pip install rootseed
```

### System Dependencies

```bash
# Ubuntu/Debian
sudo apt-get install cmake libflatbuffers-dev libspdlog-dev libcpuinfo-dev

# macOS
brew install cmake flatbuffers spdlog cpuinfo

# Windows (Chocolatey)
choco install cmake
```

### Basic Training Example

```python
import rootseed as rs
import rootseed.nn as nn
import rootseed.optim as optim

# Model
model = nn.Sequential([
    nn.Linear(784, 256),
    nn.ReLU(),
    nn.Dropout(0.5),
    nn.Linear(256, 10),
])

# Optimizer with learning rate scheduler
optimizer = optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.01)
scheduler = optim.CosineAnnealingLR(optimizer, T_max=1000)

# Training loop
for epoch in range(10):
    for x_batch, y_batch in dataloader:
        optimizer.zero_grad()
        output = model(x_batch)
        loss = output.cross_entropy(y_batch)
        loss.backward()
        optimizer.step()
        scheduler.step()
```

### Mixture of Experts

```python
# MoE: 8 experts, top-2 routing, Aleam load-balancing noise
moe = nn.MoELayer(
    d_model=512,
    num_experts=8,
    top_k=2,
    d_ff=2048,
    activation="gelu",
    noise_std=0.01,  # True random noise from Aleam
)

x = rs.randn(4, 32, 512)   # (batch, seq, d_model)
y = moe(x)                   # (4, 32, 512)
```

### Distributed Training

```python
import rootseed.distributed as dist

# Create process group (NCCL for NVIDIA, RCCL for AMD, CPU for debug)
pg = dist.ProcessGroup.create(backend="nccl", world_size=8, rank=0)
ops = dist.CollectiveOps(pg)

# Wrap model with DDP
ddp_model = dist.DistributedDataParallel(model, ops)

# Expert parallelism for MoE
expert_parallel = dist.ExpertParallel(moe, ops, expert_start=0, expert_end=4)
```

### Save & Load Models (.rs Format)

```python
# Save in .rs format (zero-copy mmap, Ed25519 signing)
writer = rs.serial.RSWriter('{"architecture": "transformer"}')
writer.add_tensor("weight", model.weight)
writer.write("model.rs", compress=True)

# Load (zero-copy via mmap)
reader = rs.serial.RSReader("model.rs")
weights = reader.load_tensor("weight")
```

---

## ✨ Features

### 🧠 Neural Network Layers

| Layer | Description |
|:---|:---|
| `nn.Linear(in, out)` | Fully connected: y = x @ W^T + b |
| `nn.Conv2D(in_ch, out_ch, k)` | 2D Convolution with im2col |
| `nn.Conv1D(in_ch, out_ch, k)` | 1D Convolution for sequences |
| `nn.MultiHeadAttention(d_model, n_heads)` | Scaled dot-product attention |
| `nn.TransformerEncoderLayer(d_model, n_heads)` | Self-attention + FFN + residual |
| `nn.MoELayer(d_model, n_experts, top_k)` | Mixture of Experts with router |

### 📈 Normalization

| Layer | Description |
|:---|:---|
| `nn.LayerNorm(shape)` | Layer normalization |
| `nn.RMSNorm(shape)` | RMS normalization (LLaMA-style) |
| `nn.BatchNorm1D(features)` | Batch normalization |
| `nn.GroupNorm(groups, channels)` | Group normalization |

### 🎲 Activations & Regularization

| Component | Description |
|:---|:---|
| `nn.ReLU()` | max(0, x) |
| `nn.GELU()` | Gaussian Error Linear Unit |
| `nn.SiLU()` | Swish activation |
| `nn.Tanh()` | Hyperbolic tangent |
| `nn.Sigmoid()` | Logistic sigmoid |
| `nn.Dropout(p)` | True random dropout via Aleam |

### ⚡ Optimizers

| Optimizer | Description |
|:---|:---|
| `optim.SGD(lr, momentum, nesterov)` | SGD with momentum and Nesterov |
| `optim.Adam(lr, betas, eps)` | Adam (Section 6.4) |
| `optim.AdamW(lr, betas, eps, wd)` | Adam with decoupled weight decay |
| `optim.Lion(lr, betas, wd)` | EvoLved Sign Momentum |

### 📉 Learning Rate Schedulers

| Scheduler | Description |
|:---|:---|
| `optim.StepLR(opt, step, gamma)` | Step decay |
| `optim.MultiStepLR(opt, milestones, gamma)` | Milestone decay |
| `optim.CosineAnnealingLR(opt, T_max)` | Cosine annealing |
| `optim.ReduceLROnPlateau(opt, patience)` | Adaptive reduction |

### 🔀 Data Pipeline

| Component | Description |
|:---|:---|
| `data.TensorDataset(data, labels)` | Dataset from tensors |
| `data.DataLoader(dataset, batch, shuffle)` | Multi-worker prefetching |
| `data.RandomSampler(replacement)` | True random sampling (Aleam) |
| `data.Compose(transforms)` | Transform chaining |
| `data.Normalize(mean, std)` | Standardization |
| `data.RandomCrop(h, w)` | Random cropping (Aleam) |
| `data.RandomFlip(prob)` | Random flipping (Aleam) |

### 🌐 Distributed Training

| Component | Description |
|:---|:---|
| `dist.ProcessGroup(backend, world, rank)` | Communication group |
| `dist.CollectiveOps(pg)` | all_reduce, broadcast, all_gather |
| `dist.DistributedDataParallel(model, ops)` | DDP gradient sync |
| `dist.ExpertParallel(moe, ops, start, end)` | MoE expert sharding |

### 💾 Serialization (.rs Format)

| Feature | Description |
|:---|:---|
| Zero-copy loading | mmap() for instant model loading |
| Lazy tensor access | Parameters mapped on first use |
| ZSTD compression | Configurable compression |
| Ed25519 signing | Cryptographic model verification |
| Sharded models | Split across multiple files |
| 64-byte alignment | GPU DMA-ready data layout |

---

## 🔌 Hardware Support

### Backend Detection Matrix

| Backend | Hardware | Detection Method | AKD Tiers |
|:---|:---|:---|:---|
| **CUDA** | NVIDIA GPUs (Volta+) | `dlopen(libcudart.so)` | 5-6 |
| **ROCm** | AMD GPUs (MI200+) | `dlopen(libamdhip64.so)` | 7 |
| **Vulkan** | Cross-vendor GPU | `dlopen(libvulkan.so)` | 10-11 |
| **TPU** | Google Cloud/Edge TPU | `dlopen(libtpu.so)` | 8 |
| **NPU** | Qualcomm Hexagon / Apple ANE | `dlopen(libhexagon.so)` | 9 |
| **XNNPACK** | ARM/x86 Optimized CPU | Built-in | 12-14 |
| **Reference** | Universal Fallback | Always available | 15 |

### Graceful Degradation

If no accelerator is detected, Root-Seed automatically falls back:

```
CUDA → ROCm → Vulkan → TPU → NPU → XNNPACK → Reference (CPU)
```

**No user configuration required.** The DRE detects hardware at `import rootseed`.

---

## 🎲 True Randomness (Aleam)

Root-Seed contains **no pseudorandom number generator**. All stochastic operations use Aleam hardware entropy exclusively:

```python
from rootseed.random import get_rng, has_hardware_entropy

rng = get_rng()

# Core randomness
rng.random()              # True random float [0, 1)
rng.gauss(0.0, 1.0)       # Normal distribution
rng.randint(1, 100)        # Random integer
rng.shuffle(my_list)       # Shuffle in-place

# AI/ML specialized
rng.dropout_mask((100,), keep_prob=0.5)
rng.kaiming_uniform((256, 512), fan_in=512)
rng.moe_load_balancing_noise(8, noise_std=0.01)
```

| Operation | Aleam Method |
|:---|:---|
| Weight initialization | `kaiming_uniform` / `xavier_uniform` |
| Dropout masks | `dropout_mask` |
| DataLoader shuffling | `shuffle_indices` |
| MoE load balancing | `moe_load_balancing_noise` |
| Gradient noise | `gauss` |
| RL exploration | `gauss` |

---

## 📦 Installation

### From PyPI

```bash
pip install rootseed
```

### With GPU Support

```bash
# NVIDIA CUDA
pip install rootseed[cuda]

# AMD ROCm
pip install rootseed[rocm]

# All GPU backends
pip install rootseed[all]
```

### From Source

```bash
git clone https://github.com/fardinsabid/root-seed.git
cd root-seed

# For users
pip install .

# For developers
pip install -e .
```

### Docker

```bash
# CUDA container
docker build -f docker/Dockerfile.cuda -t rootseed:cuda .

# ROCm container
docker build -f docker/Dockerfile.rocm -t rootseed:rocm .

# CPU-only container
docker build -f docker/Dockerfile.cpu -t rootseed:cpu .
```

---

## 📁 Project Structure

```
root-seed/
│
├── .clang-format
├── .clang-tidy
├── .pre-commit-config.yaml
├── .gitignore
├── .gitmodules
├── .dockerignore
│
├── .github/                       # CI/CD workflows
├── cmake/                         # CMake find modules
├── docker/                        # Dockerfiles (CUDA, ROCm, CPU)
│
├── docs/                          # Research paper, architecture, API reference
├── examples/                      # 8 usage demonstrations
├── tests/                         # 10 test suites
│
├── rootseed/                      # Python package
│   ├── __init__.py                # DRE initialization + public API
│   ├── _version.py                # v1.0.4
│   ├── _bindings.cpp              # pybind11 bridge
│   └── random/                    # Aleam true random
│
├── src/                           # C++ core
│   ├── core/                      # Tensor, Shape, DType, Memory
│   ├── autograd/                  # Gradient tape, backward
│   ├── akd/                       # 15-tier kernel dispatch
│   ├── dre/                       # Hardware detection
│   ├── hal/                       # 7 backends
│   ├── nn/                        # Layers + MoE
│   ├── optim/                     # Optimizers + schedulers
│   ├── data/                      # Dataset, DataLoader, Sampler
│   ├── serial/                    # .rs format
│   ├── distributed/               # DDP, ProcessGroup
│   ├── utils/                     # Logging, profiling, exceptions
│   └── ui/                        # Terminal dashboard
│
├── scripts/                       # Build, release, benchmark
├── tools/                         # Model converter, benchmark runner
│
├── CMakeLists.txt
├── pyproject.toml
├── setup.py
├── MANIFEST.in
├── README.md
├── LICENSE
├── CHANGELOG.md
├── CONTRIBUTING.md
└── CODE_OF_CONDUCT.md
```

---

## 🔧 Troubleshooting

### Q: Why does the build fail with "flatbuffers not found"?

**A:** Install the system package: `sudo apt-get install libflatbuffers-dev` (Ubuntu) or `brew install flatbuffers` (macOS). See [System Dependencies](#system-dependencies).

### Q: Can I use Root-Seed without a GPU?

**A:** Yes! The Reference and XNNPACK backends provide full CPU support. Root-Seed gracefully degrades when no accelerator is available.

### Q: Is Aleam required?

**A:** Yes. Root-Seed contains no pseudorandom fallback. Aleam hardware entropy is mandatory for all stochastic operations.

### Q: How does Root-Seed compare to PyTorch in API design?

**A:** Root-Seed mirrors PyTorch's API (`rs.nn.Linear`, `rs.optim.Adam`, etc.) for familiarity, while adding unique features: true random numbers, MoE native support, .rs format, and automatic kernel dispatch.

### Q: What platforms are supported?

**A:** Linux (x86_64, aarch64), macOS (Intel + Apple Silicon), Windows. Mobile NPU support via Qualcomm Hexagon on Android.

---

## 📄 Research Paper

The complete research paper is available in [docs/RESEARCH_PAPER.md](docs/RESEARCH_PAPER.md), covering:

- Extreme Hardware-Software Co-Design Philosophy
- 15-Tier Adaptive Kernel Dispatch System
- Dynamic Runtime Environment with 7 Backend Support
- Mixture of Experts with Aleam Load Balancing
- True Random Number Integration (Section 8)
- .rs Model Serialization Format Specification
- Complete Performance Characteristics (Section 16)

---

## 🤝 Contributing

Contributions are welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

Copyright (c) 2026 **Fardin Sabid**

---

## 🌐 Links

| | |
|---|---|
| 📦 PyPI | [pypi.org/project/rootseed](https://pypi.org/project/rootseed) |
| 🐛 Issues | [GitHub Issues](https://github.com/fardinsabid/root-seed/issues) |
| 📖 Documentation | [GitHub Docs](https://github.com/fardinsabid/root-seed/tree/main/docs) |
| 📄 Research Paper | [RESEARCH_PAPER.md](docs/RESEARCH_PAPER.md) |
| 🔗 Aleam | [github.com/fardinsabid/aleam](https://github.com/fardinsabid/aleam) |

---

<div align="center">

**Made with ❤️ by Fardin Sabid**  
**🇧🇩 From Bangladesh, for the World 🌍**

<br>

```
Extreme co-design. Orders-of-magnitude efficiency.
True randomness only. Write once. Run optimally anywhere.
```

<br>

[![GitHub stars](https://img.shields.io/github/stars/fardinsabid/root-seed?style=for-the-badge&logo=github)](https://github.com/fardinsabid/root-seed)
[![Follow](https://img.shields.io/github/followers/fardinsabid?style=for-the-badge&logo=github)](https://github.com/fardinsabid)

**If you find this project useful, please ⭐ star it on GitHub!**

</div>