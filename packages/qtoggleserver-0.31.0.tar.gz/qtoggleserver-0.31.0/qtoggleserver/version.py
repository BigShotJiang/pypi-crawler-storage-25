VERSION = "0.31.0"
VENDOR = "qtoggle/qtoggleserver"
