# qig-compute

Fast compute engine for QIG geometry — analytical QFI, GPU contractions, observable governance.

## Install

```bash
pip install qig-compute              # numpy only
pip install qig-compute[tenpy]       # + TeNPy for MPS-QFI
pip install qig-compute[gpu]         # + CuPy for GPU acceleration
pip install qig-compute[full]        # everything
```

## Usage

```python
from qig_compute.qfi_analytical import qfi_analytical, qfi_with_governance

# Compute QFI from a single MPS ground state (zero DMRG loops)
F = qfi_analytical(psi_mps, L=6, sites=pruned_sites)

# With governance checks (warns about blindspots, auto-fills cheap measurements)
F, report = qfi_with_governance(psi_mps, L=6, h=1.0, J=1.0)
print(report.summary())
```

## Observable Governance

Built-in blindspot detection warns when:
- Results only tested in one regime
- Observable amplitude collapses (wrong channel)
- FFT frequency at resolution floor
- DMRG bond dimension at limit
- Energy gap not measured (auto-fills if cheap)
