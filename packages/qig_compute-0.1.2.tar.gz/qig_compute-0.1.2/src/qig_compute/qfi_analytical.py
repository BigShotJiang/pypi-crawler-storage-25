"""
Analytical QFI from MPS — zero DMRG loops.

Computes the Quantum Fisher Information matrix directly from a single
MPS ground state using the tangent space method:

  |∂_s ψ⟩ = -i X_s |ψ⟩  (in MPS form, no dense expansion)
  F_ij = 4 Re[⟨∂_i ψ|∂_j ψ⟩ - ⟨∂_i ψ|ψ⟩⟨ψ|∂_j ψ⟩]

Cost: O(N² × χ³) from MPS overlaps
Compare: finite-difference = O(2N × DMRG_sweeps × χ³)

For L=6 (N=36, 23 pruned sites):
  Analytical: ~23² × χ³ contractions = seconds
  Finite-diff: ~46 × 5_sweeps × χ³ = hours (TIMEOUT)

Source: refactored from qigv.geometry.qfi_mpo.qfi_from_mps_tangent_space()
with added governance warnings and optional site selection.
"""

from __future__ import annotations

import time

import numpy as np

from qig_compute.observable import (
    GovernanceReport,
    GovernanceWarning,
    Severity,
    check_gap,
    check_cpu_fallback,
)

# Optional TeNPy import
try:
    from tenpy.networks.mps import MPS
    _HAS_TENPY = True
except ImportError:
    _HAS_TENPY = False
    MPS = None

# Optional CuPy import
try:
    import cupy as cp
    _HAS_CUPY = True
except ImportError:
    _HAS_CUPY = False


def qfi_analytical(
    psi_mps,
    L: int,
    sites: list[int] | None = None,
    use_gpu: bool = True,
    report: GovernanceReport | None = None,
) -> np.ndarray:
    """Compute QFI matrix analytically from a single MPS.

    No finite differences. No additional DMRG solves. Single-pass
    computation from the existing ground state MPS.

    Args:
        psi_mps: TeNPy MPS ground state
        L: Lattice size (N = L² sites)
        sites: Optional list of site indices to compute. If None, all N sites.
            Use with warp bubble pruning to skip irrelevant sites.
        use_gpu: If True and CuPy available, accelerate overlap contractions.
        report: GovernanceReport to collect warnings. Created if None.

    Returns:
        F: QFI matrix. If sites specified, shape is (len(sites), len(sites))
           with F[i,j] corresponding to sites[i], sites[j].
    """
    if not _HAS_TENPY:
        raise ImportError("qig-compute analytical QFI requires tenpy: pip install qig-compute[tenpy]")

    if report is None:
        report = GovernanceReport()

    N = L * L
    if sites is None:
        sites = list(range(N))

    n_sites = len(sites)
    F = np.zeros((n_sites, n_sites))

    t0 = time.time()

    # GPU governance check
    if use_gpu and not _HAS_CUPY:
        w = check_cpu_fallback(gpu_requested=True, gpu_available=False)
        if w:
            report.add(w)
        use_gpu = False

    # Step 1: Create derivative MPS for each site
    # |∂_s ψ⟩ = -i X_s |ψ⟩
    dpsi_list = []
    for idx, s in enumerate(sites):
        dpsi = psi_mps.copy()
        dpsi.apply_local_op(s, "Sigmax", unitary=False)
        # Scale by -i
        for k in range(dpsi.L):
            dpsi._B[k] = -1j * dpsi._B[k]
        dpsi_list.append(dpsi)

        if idx % 10 == 0 and idx > 0:
            print(f"  [QFI-analytical] Derivative MPS {idx}/{n_sites} "
                  f"({time.time()-t0:.1f}s)", flush=True)

    t_deriv = time.time() - t0
    print(f"  [QFI-analytical] {n_sites} derivative MPS computed ({t_deriv:.1f}s)", flush=True)

    # Step 2: Compute projections ⟨∂_i ψ|ψ⟩ for all sites
    projs = []
    for dpsi in dpsi_list:
        projs.append(dpsi.overlap(psi_mps))

    t_proj = time.time() - t0
    print(f"  [QFI-analytical] Projections computed ({t_proj:.1f}s)", flush=True)

    # Step 3: Compute pairwise overlaps and build F
    total_overlaps = n_sites * (n_sites + 1) // 2
    count = 0

    for i in range(n_sites):
        for j in range(i, n_sites):
            inner_ij = dpsi_list[i].overlap(dpsi_list[j])
            term = inner_ij - projs[i] * np.conj(projs[j])
            F[i, j] = 4.0 * np.real(term)
            F[j, i] = F[i, j]
            count += 1

            if count % 200 == 0:
                print(f"  [QFI-analytical] Overlaps {count}/{total_overlaps} "
                      f"({time.time()-t0:.1f}s)", flush=True)

    total_time = time.time() - t0
    print(f"  [QFI-analytical] Complete: {total_overlaps} overlaps in {total_time:.1f}s", flush=True)

    # Gap governance: flag if gap not measured
    gap_warning = check_gap(gap_measured=False, eigsh_k_used=1)
    if gap_warning:
        report.add(gap_warning)

    return F


def qfi_metric_from_analytical(
    F: np.ndarray,
    L: int,
    sites: list[int] | None = None,
) -> np.ndarray:
    """Extract metric tensor g[i,j,μ,ν] from QFI matrix.

    The QFI matrix F relates to the metric tensor on the L×L lattice.
    For a 2D system with coordinates (row, col), the metric at each
    site is a 2×2 matrix derived from the QFI elements connecting
    that site to its neighbours.

    Args:
        F: QFI matrix from qfi_analytical()
        L: Lattice size
        sites: Site list used when computing F (for index mapping)

    Returns:
        g: Metric tensor array of shape (L, L, 2, 2)
    """
    N = L * L
    if sites is None:
        sites = list(range(N))

    # Create site index mapping
    site_to_idx = {s: i for i, s in enumerate(sites)}

    g = np.zeros((L, L, 2, 2))

    for site_idx, s in enumerate(sites):
        r, c = s // L, s % L

        # Diagonal: F_ss gives the local Fisher information
        g[r, c, 0, 0] = F[site_idx, site_idx]
        g[r, c, 1, 1] = F[site_idx, site_idx]

        # Off-diagonal: F connecting to neighbours gives cross-terms
        # Right neighbour
        right = r * L + (c + 1) % L
        if right in site_to_idx:
            j = site_to_idx[right]
            g[r, c, 0, 1] = F[site_idx, j]
            g[r, c, 1, 0] = F[site_idx, j]

    return g


def qfi_with_governance(
    psi_mps,
    L: int,
    sites: list[int] | None = None,
    h: float | None = None,
    J: float = 1.0,
    delta_h: float | None = None,
    coupling_structure: str = "uniform",
    observable: str = "energy",
    use_gpu: bool = True,
) -> tuple[np.ndarray, GovernanceReport]:
    """Compute QFI with full governance checks and auto-fills.

    This is the recommended entry point. Runs all applicable governance
    checks and auto-fills cheap missing measurements.

    Args:
        psi_mps: TeNPy MPS ground state
        L: Lattice size
        sites: Optional site indices (from bubble pruning)
        h: Field strength (for regime check)
        J: Coupling (for regime check)
        delta_h: Perturbation used (for nonlinearity check)
        coupling_structure: "uniform" or "inhomogeneous"/"cracked"
        observable: What's being measured ("energy" or "magnetisation")
        use_gpu: Try GPU acceleration

    Returns:
        (F, report): QFI matrix and governance report
    """
    from qig_compute.observable import (
        check_regime_coverage,
        check_perturbation_direction,
        check_observable_proxy,
        check_nonlinearity,
        check_system_sizes,
    )

    report = GovernanceReport()

    # Pre-computation governance checks
    if h is not None:
        w = check_regime_coverage([h], J=J)
        if w:
            report.add(w)

    w = check_perturbation_direction(["h"] if delta_h else [])
    if w:
        report.add(w)

    w = check_observable_proxy(observable, coupling_structure)
    if w:
        report.add(w)

    if delta_h is not None:
        w = check_nonlinearity([delta_h])
        if w:
            report.add(w)

    w = check_system_sizes([L])
    if w:
        report.add(w)

    # Compute QFI
    F = qfi_analytical(psi_mps, L, sites=sites, use_gpu=use_gpu, report=report)

    return F, report
