"""
Observable Governance — blindspot detection + auto-fill.

Detects measurement blindspots during computation and either:
  - WARNS if the blindspot can't be fixed cheaply
  - AUTO-FILLS if the fix is within compute budget

Warnings are collected into a GovernanceReport that qig-bench consumes.

Source: 2026-04-10 sweep findings — regime blindness, channel blindness,
resolution floor, chi limits, perturbation direction, gap unknown.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class Severity(Enum):
    INFO = "info"           # Auto-filled, no action needed
    WARNING = "warning"     # Could affect results, can't auto-fix
    CRITICAL = "critical"   # Likely invalidates results


@dataclass
class GovernanceWarning:
    """A single governance warning or auto-fill notification."""
    id: str
    severity: Severity
    message: str
    auto_filled: bool = False
    auto_fill_cost_s: float = 0.0
    metadata: dict = field(default_factory=dict)


@dataclass
class GovernanceReport:
    """Collected warnings from a computation run."""
    warnings: list[GovernanceWarning] = field(default_factory=list)
    auto_fills_performed: int = 0
    auto_fill_total_cost_s: float = 0.0

    def add(self, warning: GovernanceWarning):
        self.warnings.append(warning)
        if warning.auto_filled:
            self.auto_fills_performed += 1
            self.auto_fill_total_cost_s += warning.auto_fill_cost_s

    @property
    def has_critical(self) -> bool:
        return any(w.severity == Severity.CRITICAL for w in self.warnings)

    @property
    def has_warnings(self) -> bool:
        return any(w.severity == Severity.WARNING for w in self.warnings)

    def summary(self) -> str:
        lines = []
        critical = [w for w in self.warnings if w.severity == Severity.CRITICAL]
        warns = [w for w in self.warnings if w.severity == Severity.WARNING]
        infos = [w for w in self.warnings if w.severity == Severity.INFO]

        if critical:
            lines.append(f"CRITICAL ({len(critical)}):")
            for w in critical:
                lines.append(f"  [{w.id}] {w.message}")

        if warns:
            lines.append(f"WARNING ({len(warns)}):")
            for w in warns:
                lines.append(f"  [{w.id}] {w.message}")

        if infos:
            lines.append(f"AUTO-FILLED ({len(infos)}):")
            for w in infos:
                cost = f" ({w.auto_fill_cost_s:.1f}s)" if w.auto_fill_cost_s > 0 else ""
                lines.append(f"  [{w.id}] {w.message}{cost}")

        if not self.warnings:
            lines.append("No governance warnings.")

        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════
# CHECK FUNCTIONS — call during computation
# ═══════════════════════════════════════════════════════════════

def check_amplitude(values: list[float] | dict, threshold_ratio: float = 10.0) -> GovernanceWarning | None:
    """Check if observable amplitude varies too much across domain.

    Detects the magnetisation-on-inhomogeneous failure mode.
    """
    if isinstance(values, dict):
        vals = list(values.values())
    else:
        vals = list(values)

    if not vals or all(v == 0 for v in vals):
        return None

    vals_abs = [abs(v) for v in vals if v != 0]
    if len(vals_abs) < 2:
        return None

    ratio = max(vals_abs) / min(vals_abs) if min(vals_abs) > 0 else float("inf")

    if ratio > threshold_ratio:
        return GovernanceWarning(
            id="AMPLITUDE_COLLAPSE",
            severity=Severity.CRITICAL if ratio > 100 else Severity.WARNING,
            message=f"Amplitude varies {ratio:.0f}× across domain. "
                    f"Zero-crossing metrics unreliable in low-amplitude region. "
                    f"Consider energy channel.",
            metadata={"ratio": ratio, "max": max(vals_abs), "min": min(vals_abs)},
        )
    return None


def check_resolution_floor(omega: float, t_max: float) -> GovernanceWarning | None:
    """Check if measured frequency is at the FFT resolution floor."""
    import numpy as np
    floor = 2 * np.pi / t_max
    if abs(omega - floor) / floor < 0.05:  # within 5% of floor
        return GovernanceWarning(
            id="RESOLUTION_FLOOR",
            severity=Severity.WARNING,
            message=f"ω={omega:.4f} is at FFT floor (2π/t_max={floor:.4f}). "
                    f"Oscillation period may exceed observation window. "
                    f"Increase t_max.",
            metadata={"omega": omega, "floor": floor, "t_max": t_max},
        )
    return None


def check_chi_limit(chi_used: int, chi_max: int,
                    energy_at_chi: float | None = None,
                    energy_at_half_chi: float | None = None) -> GovernanceWarning | None:
    """Check if DMRG bond dimension hit the limit."""
    if chi_used < chi_max:
        return None

    if energy_at_chi is not None and energy_at_half_chi is not None:
        energy_diff = abs(energy_at_chi - energy_at_half_chi)
        if energy_diff < 1e-6:
            return GovernanceWarning(
                id="CHI_LIMIT",
                severity=Severity.INFO,
                message=f"χ at limit ({chi_used}/{chi_max}) but energy converged "
                        f"(ΔE={energy_diff:.2e}). Results likely reliable.",
                auto_filled=True,
                metadata={"chi_used": chi_used, "chi_max": chi_max,
                          "energy_diff": energy_diff},
            )
    return GovernanceWarning(
        id="CHI_LIMIT",
        severity=Severity.WARNING,
        message=f"χ at limit ({chi_used}/{chi_max}). Convergence unverified. "
                f"Compare energy at χ and χ/2.",
        metadata={"chi_used": chi_used, "chi_max": chi_max},
    )


def check_regime_coverage(h_values_tested: list[float], J: float = 1.0,
                          h_c_ratio: float = 3.044) -> GovernanceWarning | None:
    """Check if results span multiple regimes or only one."""
    if not h_values_tested:
        return None

    h_c = h_c_ratio * J
    regimes_seen = set()
    for h in h_values_tested:
        ratio = h / J if J > 0 else 0
        if ratio < 0.8 * h_c_ratio:
            regimes_seen.add("ordered")
        elif ratio > 1.2 * h_c_ratio:
            regimes_seen.add("disordered")
        else:
            regimes_seen.add("critical")

    if len(regimes_seen) == 1:
        regime = list(regimes_seen)[0]
        return GovernanceWarning(
            id="REGIME_SINGLE",
            severity=Severity.WARNING,
            message=f"Only tested in {regime} regime (h/J = "
                    f"{min(h_values_tested)/J:.1f}–{max(h_values_tested)/J:.1f}, "
                    f"h_c/J ≈ {h_c_ratio:.1f}). Generalisation unvalidated.",
            metadata={"regimes": list(regimes_seen), "h_values": h_values_tested},
        )
    return None


def check_perturbation_direction(directions_tested: list[str]) -> GovernanceWarning | None:
    """Check if constitutive law tested with multiple perturbation directions."""
    if len(directions_tested) <= 1:
        tested = directions_tested[0] if directions_tested else "none"
        return GovernanceWarning(
            id="PERTURBATION_SINGLE",
            severity=Severity.WARNING,
            message=f"Constitutive law tested with {tested}-perturbation only. "
                    f"J-perturbation not validated (EXP-080 registered).",
            metadata={"directions": directions_tested},
        )
    return None


def check_gap(gap_measured: bool, eigsh_k_used: int = 1) -> GovernanceWarning | None:
    """Check if energy gap was measured."""
    if not gap_measured and eigsh_k_used <= 1:
        return GovernanceWarning(
            id="GAP_UNKNOWN",
            severity=Severity.INFO,
            message="Energy gap not measured. Auto-fill: compute eigsh k=2 "
                    "to get gap Δ (one extra eigenvalue, minimal cost).",
            metadata={"eigsh_k": eigsh_k_used, "can_auto_fill": True},
        )
    return None


def check_system_sizes(L_values_tested: list[int]) -> GovernanceWarning | None:
    """Check if result is at single system size."""
    if len(L_values_tested) <= 1:
        return GovernanceWarning(
            id="SINGLE_L",
            severity=Severity.WARNING,
            message=f"Result at L={L_values_tested[0] if L_values_tested else '?'} only. "
                    f"Finite-size effects not characterised.",
            metadata={"L_values": L_values_tested},
        )
    return None


def check_observable_proxy(observable: str, coupling_structure: str) -> GovernanceWarning | None:
    """Check if using magnetisation on inhomogeneous system."""
    if observable.lower() in ("x", "magnetisation", "magnetization", "spin") and \
       coupling_structure.lower() in ("inhomogeneous", "cracked", "crack", "two-region"):
        return GovernanceWarning(
            id="OBSERVABLE_PROXY",
            severity=Severity.CRITICAL,
            message="Magnetisation observable on inhomogeneous lattice. "
                    "Energy channel (local Hamiltonian density) is the "
                    "governing observable for cracked dynamics (Track 2, 2026-04-10).",
            metadata={"observable": observable, "coupling": coupling_structure},
        )
    return None


def check_cpu_fallback(gpu_requested: bool, gpu_available: bool,
                       estimated_slowdown: float = 200.0) -> GovernanceWarning | None:
    """Check for silent CPU fallback."""
    if gpu_requested and not gpu_available:
        return GovernanceWarning(
            id="CPU_FALLBACK",
            severity=Severity.CRITICAL,
            message=f"GPU requested but unavailable. Using CPU fallback. "
                    f"Expected {estimated_slowdown:.0f}× slowdown.",
            metadata={"gpu_requested": gpu_requested, "gpu_available": gpu_available,
                      "slowdown": estimated_slowdown},
        )
    return None


def check_nonlinearity(delta_h_values_tested: list[float]) -> GovernanceWarning | None:
    """Check if constitutive linearity tested at multiple perturbation strengths."""
    if len(delta_h_values_tested) <= 1:
        dh = delta_h_values_tested[0] if delta_h_values_tested else 0
        return GovernanceWarning(
            id="NONLINEARITY_UNTESTED",
            severity=Severity.INFO,
            message=f"Linearity tested at δh={dh} only. "
                    f"Auto-fill: run at δh={dh/2} to verify linearity.",
            metadata={"delta_h_tested": delta_h_values_tested, "can_auto_fill": True},
        )
    return None
