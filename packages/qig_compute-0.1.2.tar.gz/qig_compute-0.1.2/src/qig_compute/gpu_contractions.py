"""
GPU-accelerated MPS tensor contractions.

Bypasses TeNPy's CPU-only MPS.overlap() with direct CuPy contractions.
Falls back to NumPy if CuPy unavailable (with governance warning).

MPS overlap ⟨ψ_a|ψ_b⟩:
  Transfer matrix at site k: T_k[α,β] = Σ_s A_k[α,s,α'] * conj(B_k[β,s,β'])
  Overlap = Tr(T_0 · T_1 · ... · T_{N-1})

Cost: O(N × χ³ × d) where N=sites, χ=bond dimension, d=physical dim.

For L=6 (N=36, χ=512, d=2):
  CPU (TeNPy): ~1-5s per overlap
  GPU (CuPy): ~0.01-0.1s per overlap (estimated 10-100× speedup)
  Total N² overlaps: 23² ≈ 529 → CPU: ~30min, GPU: ~1min
"""

from __future__ import annotations

import numpy as np

from qig_compute.observable import GovernanceWarning, Severity

# GPU availability
try:
    import cupy as cp
    _HAS_CUPY = True
except ImportError:
    _HAS_CUPY = False


def mps_overlap_gpu(psi_a, psi_b, use_gpu: bool = True) -> complex:
    """Compute ⟨ψ_a|ψ_b⟩ via transfer matrix contraction.

    Works with TeNPy MPS objects. Extracts tensors and contracts
    on GPU (CuPy) or CPU (NumPy) fallback.

    Args:
        psi_a, psi_b: TeNPy MPS objects
        use_gpu: If True and CuPy available, use GPU

    Returns:
        Complex overlap ⟨ψ_a|ψ_b⟩
    """
    xp = cp if (use_gpu and _HAS_CUPY) else np
    N = psi_a.L
    assert psi_b.L == N

    # Extract first site tensors
    A = xp.asarray(psi_a.get_B(0, form='B').to_ndarray())  # (chi_L, d, chi_R)
    B = xp.asarray(psi_b.get_B(0, form='B').to_ndarray())

    # Initial transfer matrix: T[α', β'] = Σ_{α,s} A[α,s,α'] * conj(B[α,s,β'])
    # For first site, chi_L=1 typically, so T is (chi_R_a, chi_R_b)
    T = xp.einsum('asc,asd->cd', A, xp.conj(B))

    # Contract through remaining sites
    for k in range(1, N):
        A = xp.asarray(psi_a.get_B(k, form='B').to_ndarray())
        B = xp.asarray(psi_b.get_B(k, form='B').to_ndarray())

        # T_new[c', d'] = Σ_{c,d,s} T[c,d] * A[c,s,c'] * conj(B[d,s,d'])
        T = xp.einsum('cd,cse,dsf->ef', T, A, xp.conj(B))

    # Final: trace (for PBC) or single element (for OBC)
    result = xp.trace(T) if T.shape[0] > 1 else T[0, 0]

    if _HAS_CUPY and use_gpu:
        return complex(result.get())
    return complex(result)


def mps_overlap_batch_gpu(psi_list_a, psi_list_b,
                          use_gpu: bool = True) -> np.ndarray:
    """Compute all pairwise overlaps ⟨ψ_a[i]|ψ_b[j]⟩.

    Args:
        psi_list_a: List of MPS objects (length M)
        psi_list_b: List of MPS objects (length N)
        use_gpu: Use GPU if available

    Returns:
        Complex array of shape (M, N) with overlaps
    """
    M = len(psi_list_a)
    N = len(psi_list_b)
    result = np.zeros((M, N), dtype=complex)

    for i in range(M):
        for j in range(N):
            result[i, j] = mps_overlap_gpu(psi_list_a[i], psi_list_b[j],
                                           use_gpu=use_gpu)
    return result


def qfi_analytical_gpu(
    psi_mps,
    L: int,
    sites: list[int] | None = None,
    use_gpu: bool = True,
) -> np.ndarray:
    """Compute QFI using GPU-accelerated MPS overlaps.

    Same algorithm as qfi_analytical but uses CuPy for the
    transfer matrix contractions instead of TeNPy's CPU overlap.

    Args:
        psi_mps: TeNPy MPS ground state
        L: Lattice size
        sites: Optional site indices (from bubble pruning)
        use_gpu: Use GPU if available

    Returns:
        F: QFI matrix
    """
    import time

    N = L * L
    if sites is None:
        sites = list(range(N))
    n_sites = len(sites)

    backend = "CuPy GPU" if (use_gpu and _HAS_CUPY) else "NumPy CPU"
    print(f"  [QFI-GPU] Computing {n_sites} sites on {backend}", flush=True)
    t0 = time.time()

    # Step 1: Create derivative MPS
    dpsi_list = []
    for s in sites:
        dpsi = psi_mps.copy()
        dpsi.apply_local_op(s, "Sigmax", unitary=False)
        for k in range(dpsi.L):
            dpsi._B[k] = -1j * dpsi._B[k]
        dpsi_list.append(dpsi)

    t_deriv = time.time() - t0
    print(f"  [QFI-GPU] {n_sites} derivatives ({t_deriv:.1f}s)", flush=True)

    # Step 2: Projections ⟨∂_i ψ|ψ⟩
    projs = np.array([
        mps_overlap_gpu(dpsi, psi_mps, use_gpu=use_gpu)
        for dpsi in dpsi_list
    ])

    t_proj = time.time() - t0
    print(f"  [QFI-GPU] Projections ({t_proj:.1f}s)", flush=True)

    # Step 3: Pairwise overlaps → QFI matrix
    F = np.zeros((n_sites, n_sites))
    total = n_sites * (n_sites + 1) // 2
    count = 0

    for i in range(n_sites):
        for j in range(i, n_sites):
            inner = mps_overlap_gpu(dpsi_list[i], dpsi_list[j], use_gpu=use_gpu)
            term = inner - projs[i] * np.conj(projs[j])
            F[i, j] = 4.0 * np.real(term)
            F[j, i] = F[i, j]
            count += 1

    total_time = time.time() - t0
    per_overlap = total_time / total if total > 0 else 0
    print(f"  [QFI-GPU] Complete: {total} overlaps in {total_time:.1f}s "
          f"({per_overlap*1000:.1f}ms/overlap on {backend})", flush=True)

    return F


def check_gpu_available() -> tuple[bool, GovernanceWarning | None]:
    """Check GPU availability and return governance warning if unavailable."""
    if _HAS_CUPY:
        try:
            dev = cp.cuda.Device(0)
            mem = dev.mem_info
            return True, None
        except Exception:
            pass

    return False, GovernanceWarning(
        id="CPU_FALLBACK",
        severity=Severity.CRITICAL,
        message="GPU unavailable. MPS contractions will use CPU (NumPy). "
                "Expected 10-100× slower for L≥5.",
        metadata={"cupy_installed": _HAS_CUPY},
    )
