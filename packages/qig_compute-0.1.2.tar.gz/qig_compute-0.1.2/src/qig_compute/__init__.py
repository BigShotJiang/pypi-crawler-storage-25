"""
qig-compute v0.1.0a1 — Fast Compute Engine for QIG Geometry

Analytical QFI, GPU tensor contractions, observable governance.
Separated from qig-verification (physics experiments) and qig-core
(geometry definitions).

Three responsibilities:
  1. Compute fast — analytical MPS-QFI, GPU contractions
  2. Compute correctly — governance warnings detect blindspots
  3. Compute smart — auto-fill cheap missing measurements

Modules:
  qfi_analytical  — QFI from single MPS via transfer matrix (no DMRG loops)
  gpu_contractions — CuPy tensor network contractions
  observable       — blindspot detection + auto-fill
  screening_pipeline — push site-pruning inside QFI computation
"""

__version__ = "0.1.2"

from qig_compute.observable import (
    GovernanceWarning,
    GovernanceReport,
    Severity,
    check_amplitude,
    check_resolution_floor,
    check_chi_limit,
    check_regime_coverage,
    check_perturbation_direction,
    check_gap,
    check_system_sizes,
    check_observable_proxy,
    check_cpu_fallback,
    check_nonlinearity,
)
from qig_compute.qfi_analytical import (
    qfi_analytical,
    qfi_with_governance,
)
from qig_compute.gpu_contractions import (
    mps_overlap_gpu,
    qfi_analytical_gpu,
    check_gpu_available,
)
from qig_compute.screening_pipeline import (
    screening_aware_qfi,
)
