"""See README.md."""

from importlib.metadata import version

__version__ = version("oi-tools")
