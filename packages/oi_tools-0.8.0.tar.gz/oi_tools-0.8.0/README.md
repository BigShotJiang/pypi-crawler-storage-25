# oi-tools

[![PyPI version](https://img.shields.io/pypi/v/oi-tools)](https://pypi.org/project/oi-tools/)
[![docs](https://img.shields.io/badge/docs-latest-blue)](https://opportunityinsights.github.io/oi-tools)
[![Lint, type check, and test](https://github.com/OpportunityInsights/oi-tools/actions/workflows/tests.yml/badge.svg)](https://github.com/OpportunityInsights/oi-tools/actions/workflows/tests.yml)

This package has two main parts:

1. Python helper functions for common tasks at Opportunity Insights and
2. A CLI (`oi --help`) for submitting and monitoring PBS jobs and viewing the package documentation while offline.

See [the documentation](https://opportunityinsights.github.io/oi-tools) for more info about each of these.

## Installation

To install the most recent version of the package from PyPI:

```bash
# using uv (recommended)
uv add oi-tools

# using pip
pip install oi-tools
```
To install the most-recent development version from git:

```bash
uv add git+https://github.com/OpportunityInsights/oi-tools
pip install git+https://github.com/OpportunityInsights/oi-tools
```

To include the optional plotnine dependency, install `oi-tools[plotnine]`.
At the moment, we support Python 3.9 and newer.

## Contributing

We welcome contributions in the form of bug reports, feature requests, and PRs.
See [the contribution guidelines](https://opportunityinsights.github.io/oi-tools/contributing.html) for info about PR contributions.

