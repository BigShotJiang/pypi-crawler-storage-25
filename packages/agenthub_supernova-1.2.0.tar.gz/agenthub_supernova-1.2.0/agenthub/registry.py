"""AgentRegistry client — register, discover, and manage agents."""

from dataclasses import dataclass
from typing import Optional

from multiversx_sdk import Address

from .base import BaseClient, validate_bech32_address


@dataclass
class AgentProfile:
    """Parsed agent profile from the registry."""
    name: str
    description: str
    endpoint_url: str
    services: list[str]
    status: str  # "Active" or "Inactive"
    registered_at: int
    updated_at: int


class RegistryClient:
    """High-level client for the AgentRegistry smart contract."""

    def __init__(self, base: BaseClient, contract_address: str):
        self.base = base
        self.contract = contract_address

    def register(
        self,
        name: str,
        description: str,
        endpoint_url: str,
        services: list[str],
        wait: bool = True,
    ) -> str:
        """
        Register a new agent on the registry.

        Args:
            name: Agent display name
            description: Short description of the agent
            endpoint_url: HTTP endpoint where the agent listens
            services: List of service types the agent offers (1-5)
            wait: If True, wait for the transaction to be confirmed

        Returns:
            Transaction hash
        """
        # Validate inputs
        if not name or not name.strip():
            raise ValueError("Agent name cannot be empty")
        if not endpoint_url or not endpoint_url.strip():
            raise ValueError("Endpoint URL cannot be empty")
        if not services or len(services) == 0:
            raise ValueError("Must declare at least one service")
        if len(services) > 5:
            raise ValueError(f"Maximum 5 services allowed, got {len(services)}")

        args = [name.encode(), description.encode(), endpoint_url.encode()]
        for svc in services:
            args.append(svc.encode())

        tx_hash = self.base.call(
            contract=self.contract,
            function="registerAgent",
            arguments=args,
        )

        if wait:
            result = self.base.wait_for_tx(tx_hash)
            if result.get("status") != "success":
                raise RuntimeError(f"Registration failed: {result.get('status')}")

        return tx_hash

    def update(
        self,
        name: str,
        description: str,
        endpoint_url: str,
        services: list[str],
    ) -> str:
        """Update the caller's agent profile."""
        args = [name.encode(), description.encode(), endpoint_url.encode()]
        for svc in services:
            args.append(svc.encode())

        return self.base.call(
            contract=self.contract,
            function="updateAgent",
            arguments=args,
        )

    def deregister(self, agent_address: str) -> str:
        """Deregister an agent (caller must be the agent or the contract owner)."""
        return self.base.call(
            contract=self.contract,
            function="deregisterAgent",
            arguments=[Address.new_from_bech32(agent_address)],
        )

    def set_status(self, active: bool) -> str:
        """Set the caller's agent status to active or inactive."""
        return self.base.call(
            contract=self.contract,
            function="setStatus",
            arguments=[active],
        )

    def get_agent(self, address: str) -> Optional[AgentProfile]:
        """Query an agent's profile by address."""
        result = self.base.query(
            contract=self.contract,
            function="getAgent",
            arguments=[Address.new_from_bech32(address)],
        )
        if not result or not result[0]:
            return None
        return self._parse_profile(result[0])

    def get_count(self) -> int:
        """Get the total number of registered agents."""
        result = self.base.query(
            contract=self.contract,
            function="getAgentCount",
        )
        if not result or not result[0]:
            return 0
        return int.from_bytes(result[0], "big")

    def list_agents(self) -> list[str]:
        """List all registered agent addresses."""
        result = self.base.query(
            contract=self.contract,
            function="listAgents",
        )
        return [Address(part, "erd").to_bech32() for part in result if part]

    def find_by_service(self, service: str) -> list[str]:
        """Find active agents that offer a specific service."""
        result = self.base.query(
            contract=self.contract,
            function="findAgentsByService",
            arguments=[service.encode()],
        )
        return [Address(part, "erd").to_bech32() for part in result if part]

    def is_registered(self, address: str) -> bool:
        """Check if an address is registered as an agent."""
        result = self.base.query(
            contract=self.contract,
            function="isRegistered",
            arguments=[Address.new_from_bech32(address)],
        )
        if not result or not result[0]:
            return False
        return result[0] != b'\x00' and result[0] != b''

    def _parse_profile(self, raw: bytes) -> AgentProfile:
        """Parse raw bytes into an AgentProfile. Basic top-decode parsing."""
        # This is a simplified parser — the exact byte layout depends on
        # the MultiversX top-encoding format for the AgentProfile struct.
        # For production, use the ABI-based decoder from the SDK.
        # For now, return raw hex for debugging.
        return AgentProfile(
            name="(raw)",
            description="(raw)",
            endpoint_url="(raw)",
            services=[],
            status="Active",
            registered_at=0,
            updated_at=0,
        )
