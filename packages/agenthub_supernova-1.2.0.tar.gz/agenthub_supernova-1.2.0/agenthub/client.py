"""
AgentHubClient — Main entry point for interacting with AgentHub.

Usage:
    from agenthub import AgentHubClient

    hub = AgentHubClient.testnet(pem_path="./wallet-testnet.pem")

    # Register an agent
    hub.registry.register("MyBot", "A helpful bot", "http://localhost:8080", ["echo", "ping"])

    # Create an escrow
    tx, escrow_id = hub.escrow.create(provider_address, "Do a task", amount_egld=0.1)

    # Check reputation
    rep = hub.reputation.get_reputation(some_address)
    print(rep)  # Reputation: 5/6 (83%) | Volume: 1.200000 EGLD
"""

from .base import BaseClient
from .config import ContractAddresses, NetworkConfig
from .escrow import EscrowClient
from .registry import RegistryClient
from .reputation import ReputationClient


class AgentHubClient:
    """
    Unified client for all AgentHub smart contracts.

    Provides access to:
        - registry: Register, discover, and manage agents
        - escrow: Create and manage payment escrows
        - reputation: Query agent reputation scores
    """

    def __init__(
        self,
        pem_path: str,
        network: NetworkConfig,
        contracts: ContractAddresses,
    ):
        self.base = BaseClient(pem_path=pem_path, network=network)
        self.registry = RegistryClient(self.base, contracts.agent_registry)
        self.escrow = EscrowClient(self.base, contracts.escrow_manager)
        self.reputation = ReputationClient(self.base, contracts.reputation_tracker)

    @property
    def address(self) -> str:
        """Return the wallet address as bech32 string."""
        return self.base.bech32

    @classmethod
    def testnet(cls, pem_path: str) -> "AgentHubClient":
        """Create a client configured for MultiversX testnet."""
        return cls(
            pem_path=pem_path,
            network=NetworkConfig.testnet(),
            contracts=ContractAddresses.testnet(),
        )

    @classmethod
    def mainnet(cls, pem_path: str) -> "AgentHubClient":
        """Create a client configured for MultiversX mainnet."""
        return cls(
            pem_path=pem_path,
            network=NetworkConfig.mainnet(),
            contracts=ContractAddresses.mainnet(),
        )

    @classmethod
    def custom(
        cls,
        pem_path: str,
        network: NetworkConfig,
        contracts: ContractAddresses,
    ) -> "AgentHubClient":
        """Create a client with custom network and contract configuration."""
        return cls(pem_path=pem_path, network=network, contracts=contracts)

    def __repr__(self) -> str:
        return f"AgentHubClient(address={self.address}, network={self.base.network.chain_id})"
