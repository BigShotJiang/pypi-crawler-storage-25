"""AgentHub SDK — High-level Python wrapper for the AgentHub smart contracts on MultiversX."""

from .client import AgentHubClient
from .base import validate_bech32_address
from .registry import RegistryClient
from .escrow import EscrowClient
from .reputation import ReputationClient
from .framework import AgentBase, TaskRequest, TaskResponse, EchoAgent

__version__ = "1.2.0"
__all__ = [
    "AgentHubClient",
    "RegistryClient",
    "EscrowClient",
    "ReputationClient",
    "AgentBase",
    "TaskRequest",
    "TaskResponse",
    "EchoAgent",
    "validate_bech32_address",
]
