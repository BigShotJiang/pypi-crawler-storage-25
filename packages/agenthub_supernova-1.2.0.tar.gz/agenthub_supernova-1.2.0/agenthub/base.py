"""Base client for interacting with MultiversX smart contracts."""

import logging
import re
import threading
import time
from pathlib import Path
from typing import Any

from multiversx_sdk import (
    Account,
    Address,
    ProxyNetworkProvider,
    SmartContractTransactionsFactory,
    Transaction,
    TransactionsFactoryConfig,
    SmartContractQuery,
)

from .config import NetworkConfig

logger = logging.getLogger("agenthub.base")

# Default gas limit for contract calls
DEFAULT_GAS_LIMIT = 60_000_000

# Retry configuration
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1.0  # seconds

# bech32 address pattern
BECH32_PATTERN = re.compile(r"^erd1[a-z0-9]{58}$")


def validate_bech32_address(address: str) -> None:
    """Validate a MultiversX bech32 address format."""
    if not isinstance(address, str):
        raise ValueError(f"Address must be a string, got {type(address).__name__}")
    if not BECH32_PATTERN.match(address):
        raise ValueError(
            f"Invalid bech32 address format: {address[:20]}... "
            f"(must start with 'erd1' and be 62 characters)"
        )


class BaseClient:
    """Low-level client wrapping MultiversX SDK operations."""

    def __init__(self, pem_path: str, network: NetworkConfig):
        # Validate PEM file exists and is readable
        pem_file = Path(pem_path)
        if not pem_file.exists():
            raise FileNotFoundError(f"PEM file not found: {pem_path}")
        if not pem_file.is_file():
            raise ValueError(f"PEM path is not a file: {pem_path}")

        self.network = network
        self.account = Account.new_from_pem(pem_file)
        self.proxy = ProxyNetworkProvider(network.proxy_url)
        self.factory_config = TransactionsFactoryConfig(chain_id=network.chain_id)
        self.sc_factory = SmartContractTransactionsFactory(self.factory_config)

        # Thread lock for nonce management — prevents race conditions
        # when multiple threads send transactions concurrently
        self._nonce_lock = threading.Lock()

    @property
    def address(self) -> Address:
        """Return the wallet address."""
        return self.account.address

    @property
    def bech32(self) -> str:
        """Return the wallet address as bech32 string."""
        return self.account.address.to_bech32()

    def _refresh_nonce(self):
        """Fetch and set the current account nonce from the network."""
        account_on_network = self.proxy.get_account(self.account.address)
        self.account.nonce = account_on_network.nonce

    def _retry_request(self, func, *args, **kwargs):
        """Execute a function with exponential backoff retry."""
        last_error = None
        for attempt in range(MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_error = e
                if attempt < MAX_RETRIES - 1:
                    wait_time = RETRY_BACKOFF_BASE * (2 ** attempt)
                    logger.warning(
                        f"Request failed (attempt {attempt + 1}/{MAX_RETRIES}): {e}. "
                        f"Retrying in {wait_time:.1f}s..."
                    )
                    time.sleep(wait_time)
        raise last_error

    def call(
        self,
        contract: str,
        function: str,
        arguments: list[Any] | None = None,
        value: int = 0,
        gas_limit: int = DEFAULT_GAS_LIMIT,
    ) -> str:
        """
        Execute a smart contract call (transaction).
        Returns the transaction hash.

        Thread-safe: uses a lock around nonce management.
        """
        # Validate inputs
        validate_bech32_address(contract)
        if not function or not isinstance(function, str):
            raise ValueError("Function name must be a non-empty string")
        if value < 0:
            raise ValueError(f"Value must be non-negative, got {value}")

        with self._nonce_lock:
            self._retry_request(self._refresh_nonce)

            tx = self.sc_factory.create_transaction_for_execute(
                sender=self.account.address,
                contract=Address.new_from_bech32(contract),
                function=function,
                gas_limit=gas_limit,
                arguments=arguments or [],
                native_transfer_amount=value,
            )
            tx.nonce = self.account.get_nonce_then_increment()
            tx.signature = self.account.sign_transaction(tx)

            tx_hash = self._retry_request(self.proxy.send_transaction, tx)
        return tx_hash

    def query(
        self,
        contract: str,
        function: str,
        arguments: list[Any] | None = None,
    ) -> list[bytes]:
        """
        Execute a smart contract query (read-only, no transaction).
        Returns raw response data parts.

        Includes retry with backoff for transient network errors.
        """
        # Validate contract address
        validate_bech32_address(contract)
        if not function or not isinstance(function, str):
            raise ValueError("Function name must be a non-empty string")

        # Convert arguments to bytes — the VM query expects bytes, not Address objects
        raw_args = []
        for arg in (arguments or []):
            if isinstance(arg, Address):
                raw_args.append(arg.get_public_key())
            elif isinstance(arg, bytes):
                raw_args.append(arg)
            elif isinstance(arg, str):
                raw_args.append(arg.encode())
            elif isinstance(arg, int):
                byte_len = max(1, (arg.bit_length() + 7) // 8)
                raw_args.append(arg.to_bytes(byte_len, "big"))
            else:
                raw_args.append(bytes(arg))

        query = SmartContractQuery(
            contract=Address.new_from_bech32(contract),
            function=function,
            arguments=raw_args,
        )
        response = self._retry_request(self.proxy.query_contract, query)
        return response.return_data_parts

    def wait_for_tx(self, tx_hash: str, timeout: int = 30, poll_interval: float = 1.0) -> dict:
        """
        Wait for a transaction to be processed.
        Returns the transaction data from the API.
        """
        import requests

        api_url = self.network.proxy_url.replace("gateway", "api")
        deadline = time.time() + timeout

        while time.time() < deadline:
            try:
                resp = requests.get(f"{api_url}/transactions/{tx_hash}", timeout=5)
                if resp.status_code == 200:
                    data = resp.json()
                    status = data.get("status", "")
                    if status in ("success", "fail", "invalid"):
                        return data
            except requests.RequestException:
                pass
            time.sleep(poll_interval)

        raise TimeoutError(f"Transaction {tx_hash} not finalized within {timeout}s")
