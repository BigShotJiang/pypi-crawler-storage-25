"""ReputationTracker client — query agent reputation data."""

from dataclasses import dataclass

from multiversx_sdk import Address

from .base import BaseClient

# 1 EGLD = 10^18 wei
EGLD_DECIMALS = 10**18


@dataclass
class ReputationData:
    """Parsed reputation data for an agent."""
    success_count: int
    total_count: int
    total_volume_wei: int

    @property
    def total_volume_egld(self) -> float:
        """Total volume in EGLD."""
        return self.total_volume_wei / EGLD_DECIMALS

    @property
    def success_ratio(self) -> float:
        """Success ratio between 0.0 and 1.0."""
        if self.total_count == 0:
            return 0.0
        return self.success_count / self.total_count

    @property
    def success_percentage(self) -> float:
        """Success ratio as percentage (0-100)."""
        return self.success_ratio * 100

    def __str__(self) -> str:
        return (
            f"Reputation: {self.success_count}/{self.total_count} "
            f"({self.success_percentage:.0f}%) | "
            f"Volume: {self.total_volume_egld:.6f} EGLD"
        )


class ReputationClient:
    """High-level client for the ReputationTracker smart contract."""

    def __init__(self, base: BaseClient, contract_address: str):
        self.base = base
        self.contract = contract_address

    def get_reputation(self, address: str) -> ReputationData:
        """
        Get full reputation data for an agent.

        Args:
            address: Agent's bech32 address

        Returns:
            ReputationData with success_count, total_count, total_volume
        """
        result = self.base.query(
            contract=self.contract,
            function="getReputation",
            arguments=[Address.new_from_bech32(address)],
        )

        if not result or not result[0] or result[0] == b'\x00' * 20:
            return ReputationData(success_count=0, total_count=0, total_volume_wei=0)

        return self._parse_reputation(result[0])

    def get_success_ratio(self, address: str) -> tuple[int, int]:
        """
        Get success ratio as (success_count, total_count).

        Returns:
            Tuple of (successes, total)
        """
        result = self.base.query(
            contract=self.contract,
            function="getSuccessRatio",
            arguments=[Address.new_from_bech32(address)],
        )

        if not result or len(result) < 2:
            return (0, 0)

        success = int.from_bytes(result[0], "big") if result[0] else 0
        total = int.from_bytes(result[1], "big") if result[1] else 0
        return (success, total)

    def get_total_volume(self, address: str) -> int:
        """Get the total volume transacted by an agent (in wei)."""
        result = self.base.query(
            contract=self.contract,
            function="getTotalVolume",
            arguments=[Address.new_from_bech32(address)],
        )

        if not result or not result[0]:
            return 0
        return int.from_bytes(result[0], "big")

    def _parse_reputation(self, raw: bytes) -> ReputationData:
        """
        Parse raw bytes into ReputationData.
        Layout (top-encoded): u64 success + u64 total + BigUint volume
        """
        if len(raw) < 16:
            return ReputationData(success_count=0, total_count=0, total_volume_wei=0)

        success = int.from_bytes(raw[0:8], "big")
        total = int.from_bytes(raw[8:16], "big")

        # BigUint is encoded as: 4 bytes length + N bytes value
        volume = 0
        if len(raw) > 16:
            vol_len = int.from_bytes(raw[16:20], "big")
            if vol_len > 0 and len(raw) >= 20 + vol_len:
                volume = int.from_bytes(raw[20:20 + vol_len], "big")

        return ReputationData(
            success_count=success,
            total_count=total,
            total_volume_wei=volume,
        )
