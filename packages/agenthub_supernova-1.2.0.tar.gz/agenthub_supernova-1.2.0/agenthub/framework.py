"""
AgentHub Framework — Build agents in minutes.

Usage:
    from agenthub.framework import AgentBase

    class PriceOracle(AgentBase):
        name = "PriceOracle"
        description = "Real-time EGLD/USD price feed"
        services = ["price_feed", "oracle"]
        port = 8082

        def handle_task(self, task: dict) -> dict:
            price = get_egld_price()
            return {"status": "success", "result": {"egld_usd": price}}

    if __name__ == "__main__":
        oracle = PriceOracle(pem_path="./wallet.pem")
        oracle.run()
"""

import json
import logging
import signal
import sys
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Any, Optional

from .client import AgentHubClient
from .config import ContractAddresses, NetworkConfig

logger = logging.getLogger("agenthub.framework")


@dataclass
class TaskRequest:
    """Incoming task request from a consumer."""
    escrow_id: Optional[int] = None
    consumer: Optional[str] = None
    payload: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "TaskRequest":
        return cls(
            escrow_id=data.get("escrow_id"),
            consumer=data.get("consumer"),
            payload=data.get("payload", data),
        )


@dataclass
class TaskResponse:
    """Response from the agent after processing a task."""
    status: str  # "success" or "error"
    result: Any = None
    error: Optional[str] = None

    def to_dict(self) -> dict:
        d = {"status": self.status}
        if self.result is not None:
            d["result"] = self.result
        if self.error is not None:
            d["error"] = self.error
        return d


class AgentBase(ABC):
    """
    Base class for AgentHub agents.

    Subclass this and implement `handle_task()` to create an agent.
    The framework handles registration, HTTP server, health checks,
    and graceful shutdown automatically.

    Class attributes to override:
        name: str           — Agent display name
        description: str    — Short description
        services: list[str] — List of services offered (1-5)
        port: int           — HTTP port to listen on (default 8080)
        host: str           — Host to bind to (default "0.0.0.0")
    """

    # ── Override these in your subclass ──
    name: str = "MyAgent"
    description: str = "An AgentHub agent"
    services: list[str] = ["default"]
    port: int = 8080
    host: str = "0.0.0.0"

    def __init__(
        self,
        pem_path: str,
        network: str = "testnet",
        endpoint_url: Optional[str] = None,
        auto_register: bool = True,
        custom_network: Optional[NetworkConfig] = None,
        custom_contracts: Optional[ContractAddresses] = None,
    ):
        """
        Initialize the agent.

        Args:
            pem_path: Path to the wallet PEM file
            network: "testnet" or "mainnet"
            endpoint_url: Override the auto-detected endpoint URL
            auto_register: If True, register on the blockchain at startup
            custom_network: Custom NetworkConfig (overrides network param)
            custom_contracts: Custom ContractAddresses
        """
        if network == "mainnet":
            self.hub = AgentHubClient.mainnet(pem_path)
        elif custom_network and custom_contracts:
            self.hub = AgentHubClient.custom(pem_path, custom_network, custom_contracts)
        else:
            self.hub = AgentHubClient.testnet(pem_path)

        self.endpoint_url = endpoint_url or f"http://localhost:{self.port}/task"
        self.auto_register = auto_register
        self._server: Optional[HTTPServer] = None
        self._running = False

    @abstractmethod
    def handle_task(self, task: TaskRequest) -> dict:
        """
        Process an incoming task. Override this in your subclass.

        Args:
            task: The incoming task request

        Returns:
            A dict with the result. Will be wrapped in a TaskResponse.
            Return {"status": "success", "result": ...} for success.
            Return {"status": "error", "error": "..."} for errors.
        """
        ...

    def on_startup(self):
        """Called after registration, before the HTTP server starts. Override for custom setup."""
        pass

    def on_shutdown(self):
        """Called during graceful shutdown. Override for custom cleanup."""
        pass

    def health_check(self) -> dict:
        """Health check endpoint. Override for custom health logic."""
        return {
            "status": "healthy",
            "agent": self.name,
            "address": self.hub.address,
            "services": self.services,
            "uptime_seconds": int(time.time() - self._start_time) if self._running else 0,
        }

    # ── Registration ──────────────────────────────────────────

    def register(self) -> str:
        """Register or update the agent on the AgentRegistry."""
        if self.hub.registry.is_registered(self.hub.address):
            logger.info(f"Agent already registered, updating profile...")
            tx_hash = self.hub.registry.update(
                name=self.name,
                description=self.description,
                endpoint_url=self.endpoint_url,
                services=self.services,
            )
            logger.info(f"Profile updated (tx: {tx_hash})")
            return tx_hash
        else:
            logger.info(f"Registering agent '{self.name}' on-chain...")
            tx_hash = self.hub.registry.register(
                name=self.name,
                description=self.description,
                endpoint_url=self.endpoint_url,
                services=self.services,
            )
            logger.info(f"Registered (tx: {tx_hash})")
            return tx_hash

    # ── HTTP Server ───────────────────────────────────────────

    def _create_handler(agent_instance: "AgentBase"):
        """Create an HTTP request handler bound to this agent."""

        class Handler(BaseHTTPRequestHandler):
            agent = agent_instance

            def do_GET(self):
                if self.path == "/health" or self.path == "/":
                    self._json_response(200, self.agent.health_check())
                elif self.path == "/info":
                    self._json_response(200, {
                        "name": self.agent.name,
                        "description": self.agent.description,
                        "services": self.agent.services,
                        "address": self.agent.hub.address,
                        "endpoint": self.agent.endpoint_url,
                    })
                else:
                    self._json_response(404, {"error": "Not found"})

            def do_POST(self):
                if self.path == "/task":
                    try:
                        content_length = int(self.headers.get("Content-Length", 0))
                        body = self.rfile.read(content_length)
                        data = json.loads(body) if body else {}

                        task = TaskRequest.from_dict(data)
                        result = self.agent.handle_task(task)

                        if isinstance(result, dict):
                            response = TaskResponse(
                                status=result.get("status", "success"),
                                result=result.get("result", result),
                                error=result.get("error"),
                            )
                        else:
                            response = TaskResponse(status="success", result=result)

                        self._json_response(200, response.to_dict())
                    except Exception as e:
                        logger.exception(f"Error handling task: {e}")
                        self._json_response(500, TaskResponse(
                            status="error",
                            error=str(e),
                        ).to_dict())
                else:
                    self._json_response(404, {"error": "Not found"})

            def _json_response(self, code: int, data: dict):
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())

            def log_message(self, format, *args):
                logger.debug(f"{self.address_string()} - {format % args}")

        return Handler

    # ── Run ───────────────────────────────────────────────────

    def run(self):
        """
        Start the agent: register on-chain, launch HTTP server, handle signals.
        This is a blocking call — use Ctrl+C to stop.
        """
        logging.basicConfig(
            level=logging.INFO,
            format=f"%(asctime)s [{self.name}] %(levelname)s %(message)s",
            datefmt="%H:%M:%S",
        )

        logger.info(f"Starting {self.name}...")
        logger.info(f"  Address:  {self.hub.address}")
        logger.info(f"  Services: {', '.join(self.services)}")
        logger.info(f"  Endpoint: {self.endpoint_url}")

        # Register on-chain
        if self.auto_register:
            try:
                self.register()
            except Exception as e:
                logger.error(f"Registration failed: {e}")
                logger.warning("Continuing without registration...")

        # Custom startup hook
        self.on_startup()

        # Start HTTP server
        handler_class = AgentBase._create_handler(self)
        self._server = HTTPServer((self.host, self.port), handler_class)
        self._running = True
        self._start_time = time.time()

        # Graceful shutdown on SIGINT/SIGTERM
        def shutdown_handler(signum, frame):
            logger.info("Shutting down...")
            self._running = False
            self.on_shutdown()
            if self._server:
                threading.Thread(target=self._server.shutdown).start()

        signal.signal(signal.SIGINT, shutdown_handler)
        signal.signal(signal.SIGTERM, shutdown_handler)

        logger.info(f"Listening on {self.host}:{self.port}")
        logger.info("Press Ctrl+C to stop")

        try:
            self._server.serve_forever()
        finally:
            self._running = False
            logger.info(f"{self.name} stopped.")


class EchoAgent(AgentBase):
    """Built-in echo agent for testing. Returns whatever you send it."""
    name = "EchoAgent"
    description = "Echoes back the input — useful for testing"
    services = ["echo", "ping"]
    port = 8080

    def handle_task(self, task: TaskRequest) -> dict:
        return {
            "status": "success",
            "result": {
                "echo": task.payload,
                "agent": self.name,
                "address": self.hub.address,
            },
        }
