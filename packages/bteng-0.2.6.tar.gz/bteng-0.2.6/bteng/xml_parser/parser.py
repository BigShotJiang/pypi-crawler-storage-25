"""XML tree parser for BTEng.

Supported format::

    <BTEng format_version="1.0">
      <Tree ID="main_tree">
        <Sequence name="root">
          <Condition ID="IsReady"/>
          <Action ID="Move" target="{goal}"/>
          <Node type="CustomNode" param="value"/>
          <SubTree ID="pick" target="{goal}"/>
        </Sequence>
      </Tree>

      <Tree ID="pick">
        <Sequence name="pick_seq">
          <Action ID="Grasp" target="{target}"/>
        </Sequence>
      </Tree>

      <!-- Optional: explicit port declarations -->
      <TreeNodesModel>
        <Action ID="Move">
          <input_port name="target"/>
        </Action>
        <Action ID="Grasp">
          <input_port name="target"/>
        </Action>
      </TreeNodesModel>
    </BTEng>

Port remapping:
  - ``attr="{key}"``  → blackboard lookup / write of *key*
  - ``attr="value"``  → static parameter

Extensibility:
  - Any tag not recognised as a built-in control/decorator is looked up in
    the NodeFactory registry.  This means new node types need zero parser changes.
  - ``<Node type="Foo" .../>`` is an explicit generic form.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional, Tuple

from bteng.blackboard.blackboard import Blackboard
from bteng.core.node import NodeConfig, TreeNode
from bteng.factory.factory import NodeFactory

# Built-in tag → factory key mapping
_CONTROL_TAGS = {
    "Sequence", "Fallback", "Selector",
    "Parallel", "ReactiveSequence", "ReactiveFallback",
}
_DECORATOR_TAGS = {
    "Inverter", "Retry", "Timeout", "RateController",
    "ForceSuccess", "ForceFailure",
}
_SUBTREE_TAG = "SubTree"
_GENERIC_TAG = "Node"

# Attributes that are XML meta (not node ports/params)
_META_ATTRS = {"name", "ID", "type"}

_BB_REF_RE = re.compile(r"^\{(\w+)\}$")


def _parse_attr(value: str) -> Tuple[str, bool]:
    """Returns (key_or_value, is_blackboard_ref)."""
    m = _BB_REF_RE.match(value)
    if m:
        return m.group(1), True
    return value, False


class XMLTreeParser:
    """Parse a BTEng XML file into a live TreeNode hierarchy."""

    def __init__(self, factory: Optional[NodeFactory] = None) -> None:
        self._factory = factory or NodeFactory.get_instance()
        self._port_model: Dict[str, Dict[str, str]] = {}  # node_id → {port: direction}
        self._tree_roots: Dict[str, ET.Element] = {}
        self._building_stack: List[str] = []  # cycle detection for subtree references

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse_file(
        self,
        path: str,
        tree_id: Optional[str] = None,
        blackboard: Optional[Blackboard] = None,
    ) -> TreeNode:
        tree = ET.parse(path)
        return self._parse_root(tree.getroot(), tree_id=tree_id, blackboard=blackboard)

    def parse_string(
        self,
        xml_str: str,
        tree_id: Optional[str] = None,
        blackboard: Optional[Blackboard] = None,
    ) -> TreeNode:
        root_el = ET.fromstring(xml_str)
        return self._parse_root(root_el, tree_id=tree_id, blackboard=blackboard)

    def parse_file_to_registry(
        self,
        path: str,
        blackboard: Optional[Blackboard] = None,
    ) -> "Any":
        """Parse all trees from a file and return a populated TreeRegistry.

        Each <Tree ID="..."> becomes a standalone Tree in the registry,
        sharing the supplied blackboard (or a fresh one if omitted).
        """
        tree = ET.parse(path)
        return self._parse_all_to_registry(tree.getroot(), blackboard)

    def parse_string_to_registry(
        self,
        xml_str: str,
        blackboard: Optional[Blackboard] = None,
    ) -> "Any":
        """Parse all trees from an XML string and return a populated TreeRegistry."""
        root_el = ET.fromstring(xml_str)
        return self._parse_all_to_registry(root_el, blackboard)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _parse_all_to_registry(
        self,
        root_el: ET.Element,
        blackboard: Optional[Blackboard],
    ) -> "Any":
        from bteng.core.tree import Tree, TreeMetadata, TreeRegistry

        bb = blackboard or Blackboard.create()
        model_el = root_el.find("TreeNodesModel")
        if model_el is not None:
            self._load_port_model(model_el)
        for tree_el in root_el.findall("Tree"):
            tid = tree_el.get("ID")
            if tid:
                self._tree_roots[tid] = tree_el

        registry = TreeRegistry()
        for tree_id, tree_el in self._tree_roots.items():
            children = [c for c in tree_el if not self._is_whitespace(c)]
            if len(children) != 1:
                continue
            try:
                child_bb = bb.create_child_scope(tree_id)
                root_node = self._build_node(children[0], child_bb)
                tree = Tree(TreeMetadata(id=tree_id), root_node, child_bb)
                registry.register_tree(tree)
            except Exception:
                pass  # skip malformed individual trees; caller can inspect registry

        return registry

    def _parse_root(
        self,
        root_el: ET.Element,
        tree_id: Optional[str],
        blackboard: Optional[Blackboard],
    ) -> TreeNode:
        bb = blackboard or Blackboard.create()

        # Collect TreeNodesModel for port metadata
        model_el = root_el.find("TreeNodesModel")
        if model_el is not None:
            self._load_port_model(model_el)

        # Index all tree definitions
        for tree_el in root_el.findall("Tree"):
            tid = tree_el.get("ID")
            if tid:
                self._tree_roots[tid] = tree_el

        # Determine which tree to run
        if tree_id:
            target_id = tree_id
        else:
            main_attr = root_el.get("main_tree_to_execute")
            if main_attr:
                target_id = main_attr
            elif self._tree_roots:
                target_id = next(iter(self._tree_roots))
            else:
                raise ValueError("No <Tree> found in XML")

        if target_id not in self._tree_roots:
            raise KeyError(f"Tree ID '{target_id}' not found in XML")

        tree_el = self._tree_roots[target_id]
        children = [c for c in tree_el if not self._is_whitespace(c)]
        if len(children) != 1:
            raise ValueError(f"Tree '{target_id}' must have exactly one root child node")

        return self._build_node(children[0], bb)

    def _load_port_model(self, model_el: ET.Element) -> None:
        for node_el in model_el:
            node_id = node_el.get("ID", "")
            ports: Dict[str, str] = {}
            for port_el in node_el:
                name = port_el.get("name", "")
                direction = port_el.tag  # "input_port" or "output_port"
                ports[name] = direction
            self._port_model[node_id] = ports

    def _build_node(self, el: ET.Element, bb: Blackboard) -> TreeNode:
        tag = el.tag
        node_name = el.get("name", tag)
        node_id = el.get("ID", tag)

        # ------ SubTree ------------------------------------------------
        if tag == _SUBTREE_TAG:
            return self._build_subtree(el, bb)

        # ------ Generic <Node type="..."> ------------------------------
        if tag == _GENERIC_TAG:
            node_type = el.get("type")
            if not node_type:
                raise ValueError("<Node> element missing 'type' attribute")
            return self._build_generic(node_type, node_name, el, bb)

        # ------ Control nodes -----------------------------------------
        if tag in _CONTROL_TAGS:
            children = [self._build_node(c, bb) for c in el if not self._is_whitespace(c)]
            config = self._make_config(node_id, el, bb, output_ports={})
            kwargs = self._control_kwargs(tag, el)
            return self._factory.create_control(tag, node_name, children, config, **kwargs)

        # ------ Decorator nodes ----------------------------------------
        if tag in _DECORATOR_TAGS:
            child_els = [c for c in el if not self._is_whitespace(c)]
            if len(child_els) != 1:
                raise ValueError(f"Decorator '{tag}' must have exactly one child")
            child = self._build_node(child_els[0], bb)
            config = self._make_config(node_id, el, bb)
            kwargs = self._decorator_kwargs(tag, el)
            return self._factory.create_decorator(tag, node_name, child, config, **kwargs)

        # ------ Leaf nodes (Action, Condition, or custom registered) ---
        if self._factory.is_registered(node_id):
            return self._build_generic(node_id, node_name, el, bb)

        # ------ Unknown — try factory with tag name --------------------
        if self._factory.is_registered(tag):
            return self._build_generic(tag, node_name, el, bb)

        raise ValueError(
            f"Unknown node tag <{tag} ID={node_id!r}>. "
            "Register the node type via NodeFactory or use <Node type='...'/>."
        )

    def _build_subtree(self, el: ET.Element, parent_bb: Blackboard) -> TreeNode:
        subtree_id = el.get("ID")
        if not subtree_id:
            raise ValueError("<SubTree> missing 'ID' attribute")
        if subtree_id not in self._tree_roots:
            raise KeyError(f"SubTree ID '{subtree_id}' not defined")
        if subtree_id in self._building_stack:
            cycle = " → ".join(self._building_stack) + f" → {subtree_id}"
            raise ValueError(f"Cyclic subtree reference detected: {cycle}")

        # Build port remapping: attr="{key}" → remap local attr → parent key
        remapping: Dict[str, str] = {}
        static_vals: Dict[str, Any] = {}
        for attr, val in el.attrib.items():
            if attr in _META_ATTRS:
                continue
            bb_key, is_ref = _parse_attr(val)
            if is_ref:
                remapping[attr] = bb_key
            else:
                static_vals[attr] = val

        child_bb = Blackboard.create_child(parent_bb, remapping)
        for k, v in static_vals.items():
            child_bb.set(k, v)

        tree_el = self._tree_roots[subtree_id]
        children = [c for c in tree_el if not self._is_whitespace(c)]
        if len(children) != 1:
            raise ValueError(f"SubTree '{subtree_id}' must have exactly one root child")

        self._building_stack.append(subtree_id)
        try:
            subtree_root = self._build_node(children[0], child_bb)
        finally:
            self._building_stack.pop()

        name = el.get("name", subtree_id)
        from bteng.nodes.subtree import SubTree

        return SubTree(name=name, child=subtree_root)

    def _build_generic(
        self, node_type: str, name: str, el: ET.Element, bb: Blackboard
    ) -> TreeNode:
        port_meta = self._port_model.get(node_type, {})
        input_ports: Dict[str, str] = {}
        output_ports: Dict[str, str] = {}
        params: Dict[str, Any] = {}

        # Seed params from declared InputPort defaults so XML attributes override
        manifest = self._factory.manifest(node_type)
        if manifest:
            for port in manifest.ports:
                if port.is_input() and port.default is not None:
                    params[port.name] = port.default

        for attr, val in el.attrib.items():
            if attr in _META_ATTRS:
                continue
            bb_key, is_ref = _parse_attr(val)
            if is_ref:
                direction = port_meta.get(attr, "input_port")
                if direction == "output_port":
                    output_ports[attr] = bb_key
                else:
                    input_ports[attr] = bb_key
            else:
                params[attr] = val

        config = NodeConfig(
            blackboard=bb,
            input_ports=input_ports,
            output_ports=output_ports,
            params=params,
        )
        return self._factory.create_leaf(node_type, name, config)

    def _make_config(
        self,
        node_id: str,
        el: ET.Element,
        bb: Blackboard,
        output_ports: Optional[Dict[str, str]] = None,
    ) -> NodeConfig:
        params: Dict[str, Any] = {}
        for attr, val in el.attrib.items():
            if attr in _META_ATTRS:
                continue
            params[attr] = val
        return NodeConfig(blackboard=bb, params=params, output_ports=output_ports or {})

    @staticmethod
    def _control_kwargs(tag: str, el: ET.Element) -> Dict[str, Any]:
        kwargs: Dict[str, Any] = {}
        if tag == "Parallel":
            st = el.get("success_threshold")
            ft = el.get("failure_threshold")
            if st is not None:
                kwargs["success_threshold"] = int(st)
            if ft is not None:
                kwargs["failure_threshold"] = int(ft)
        return kwargs

    @staticmethod
    def _decorator_kwargs(tag: str, el: ET.Element) -> Dict[str, Any]:
        kwargs: Dict[str, Any] = {}
        if tag == "Retry":
            v = el.get("max_attempts") or el.get("num_attempts")
            if v:
                kwargs["max_attempts"] = int(v)
        elif tag == "Timeout":
            if el.get("msec") is not None:
                kwargs["duration"] = float(el.get("msec")) / 1000.0
            elif el.get("duration") is not None:
                kwargs["duration"] = float(el.get("duration"))
        elif tag == "RateController":
            v = el.get("hz")
            if v:
                kwargs["hz"] = float(v)
        return kwargs

    @staticmethod
    def _is_whitespace(el: ET.Element) -> bool:
        return el.tag is ET.Comment  # type: ignore[comparison-overlap]
