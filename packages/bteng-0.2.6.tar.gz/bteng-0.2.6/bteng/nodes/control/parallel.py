"""Parallel control node."""
from __future__ import annotations

from enum import Enum
from typing import List, Optional

from bteng.core.node import ControlNode, NodeStatus, TreeNode


# ── ParallelPolicy ────────────────────────────────────────────────────────────

class ParallelPolicy(Enum):
    """Controls when ParallelNode decides to return SUCCESS or FAILURE.

    REQUIRE_ALL_SUCCESS   — Return SUCCESS only when every child has succeeded.
    REQUIRE_ONE_SUCCESS   — Return SUCCESS as soon as any single child succeeds.
    REQUIRE_ALL_COMPLETE  — Wait for every child to finish; use success_threshold
                            to determine the final result (0 = all must succeed).
    """
    REQUIRE_ALL_SUCCESS  = "require_all_success"
    REQUIRE_ONE_SUCCESS  = "require_one_success"
    REQUIRE_ALL_COMPLETE = "require_all_complete"


# ── ParallelNode ──────────────────────────────────────────────────────────────

class ParallelNode(ControlNode):
    """Tick ALL children every tick simultaneously.

    Args:
        success_threshold:
            How many children must succeed for overall SUCCESS.
            -1 (default) means all children (recomputed each tick from
            the live child count, so dynamic INSERT/REMOVE is safe).
            Ignored when policy=REQUIRE_ONE_SUCCESS.
        failure_threshold:
            How many children must fail for overall FAILURE. Default = 1.
        policy:
            ParallelPolicy enum controlling result computation.
            When provided, overrides threshold semantics.
    """

    def __init__(
        self,
        name:               str                         = "Parallel",
        children:           Optional[List[TreeNode]]   = None,
        config=None,
        success_threshold:  int                         = -1,
        failure_threshold:  int                         = 1,
        policy:             Optional[ParallelPolicy]   = None,
    ) -> None:
        super().__init__(name, children or [], config)
        self._policy                = policy
        self._failure_threshold     = failure_threshold
        # Store the raw threshold; -1 means "use all children" (resolved lazily in tick()).
        # This avoids stale threshold when children are added/removed after construction.
        self._raw_success_threshold = success_threshold

    def _effective_success_threshold(self) -> int:
        """Compute the success threshold from current child count each tick."""
        n = len(self._children)
        if self._policy == ParallelPolicy.REQUIRE_ONE_SUCCESS:
            return 1
        if self._policy in (ParallelPolicy.REQUIRE_ALL_SUCCESS,
                            ParallelPolicy.REQUIRE_ALL_COMPLETE):
            return n
        return n if self._raw_success_threshold < 0 else self._raw_success_threshold

    def tick(self) -> NodeStatus:
        success_count = 0
        failure_count = 0
        threshold = self._effective_success_threshold()

        for child in self._children:
            if child.status == NodeStatus.SUCCESS:
                success_count += 1
                continue
            if child.status == NodeStatus.FAILURE:
                failure_count += 1
                continue

            child_status = child.execute_tick()
            if child_status == NodeStatus.SUCCESS:
                success_count += 1
            elif child_status == NodeStatus.FAILURE:
                failure_count += 1

        if success_count >= threshold:
            self._halt_running_children()
            self._reset_children_status()
            return NodeStatus.SUCCESS

        if failure_count >= self._failure_threshold:
            self._halt_running_children()
            self._reset_children_status()
            return NodeStatus.FAILURE

        return NodeStatus.RUNNING

    def halt(self) -> None:
        if self._status == NodeStatus.RUNNING:
            self._on_halt()
        self._halt_running_children()
        self._reset_children_status()
        self._status = NodeStatus.IDLE

    def _halt_running_children(self) -> None:
        for child in self._children:
            if child.status == NodeStatus.RUNNING:
                child.halt()

    def _reset_children_status(self) -> None:
        """Reset completed (non-RUNNING) children to IDLE for next activation."""
        for child in self._children:
            if child.status != NodeStatus.RUNNING:
                # Call reset_node() so subclasses (e.g. SequenceNode) also clear
                # internal state (like _current_idx) in addition to status.
                if child.status != NodeStatus.IDLE:
                    child._on_reset()
                child._status = NodeStatus.IDLE

    @classmethod
    def provided_ports(cls):
        from bteng.core.node import InputPort
        return [InputPort("success_threshold", "Min successes for overall SUCCESS (0=all)")]
