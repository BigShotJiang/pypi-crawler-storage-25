"""Retry decorator."""

from __future__ import annotations

from bteng.core.node import DecoratorNode, NodeStatus


class Retry(DecoratorNode):
    """Re-try child on FAILURE up to *max_attempts* times.

    Returns RUNNING between attempts so the parent keeps ticking.
    Returns SUCCESS immediately when child succeeds.
    Returns FAILURE after exhausting all attempts.
    """

    def __init__(
        self,
        name: str = "Retry",
        child=None,
        config=None,
        max_attempts: int = 3,
    ):
        super().__init__(name, child, config)
        self._max_attempts = max_attempts
        self._attempts: int = 0

    def tick(self) -> NodeStatus:
        # Fresh start detected when our own status is not RUNNING
        if self._status != NodeStatus.RUNNING:
            self._attempts = 0

        child_status = self._child.execute_tick()

        if child_status == NodeStatus.SUCCESS:
            self._attempts = 0
            return NodeStatus.SUCCESS

        if child_status == NodeStatus.FAILURE:
            self._attempts += 1
            if self._attempts >= self._max_attempts:
                self._child.halt()
                return NodeStatus.FAILURE
            # Reset child for next attempt
            self._child.halt()
            return NodeStatus.RUNNING

        return NodeStatus.RUNNING  # child still running

    def _on_halt(self) -> None:
        self._attempts = 0
