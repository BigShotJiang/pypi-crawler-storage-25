"""Timeout decorator."""

from __future__ import annotations

import time
from typing import Optional

from bteng.core.node import DecoratorNode, NodeStatus


class Timeout(DecoratorNode):
    """Halt child and return FAILURE if it runs longer than *duration* seconds."""

    def __init__(
        self,
        name: str = "Timeout",
        child=None,
        config=None,
        duration: float = 1.0,
    ):
        super().__init__(name, child, config)
        self._duration = duration
        self._start_time: Optional[float] = None

    def tick(self) -> NodeStatus:
        # Start timer on first tick of each activation
        if self._status != NodeStatus.RUNNING:
            self._start_time = time.monotonic()

        if time.monotonic() - self._start_time > self._duration:  # type: ignore[operator]
            self._child.halt()
            return NodeStatus.FAILURE

        return self._child.execute_tick()

    def _on_halt(self) -> None:
        self._start_time = None
