"""RateController decorator."""

from __future__ import annotations

import time
from typing import Optional

from bteng.core.node import DecoratorNode, NodeStatus


class RateController(DecoratorNode):
    """Limit how often the child is re-ticked (in Hz).

    Between allowed ticks, returns the last known status without re-ticking.
    """

    def __init__(
        self,
        name: str = "RateController",
        child=None,
        config=None,
        hz: float = 1.0,
    ):
        super().__init__(name, child, config)
        self._period = 1.0 / hz
        self._last_tick: Optional[float] = None
        self._last_status: NodeStatus = NodeStatus.IDLE

    def tick(self) -> NodeStatus:
        now = time.monotonic()
        if self._last_tick is None or (now - self._last_tick) >= self._period:
            self._last_tick = now
            self._last_status = self._child.execute_tick()
        return self._last_status

    def _on_halt(self) -> None:
        self._last_tick = None
        self._last_status = NodeStatus.IDLE
