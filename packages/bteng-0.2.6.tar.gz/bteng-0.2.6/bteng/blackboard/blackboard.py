"""Scoped, observable key-value store for inter-node communication."""
from __future__ import annotations

import sys
import threading
import time
from collections import deque
from copy import copy
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

from bteng.core.node import PortDirection


# ── Sentinel for "no value set" (distinct from storing None explicitly) ───────

class _Unset:
    """Singleton sentinel distinguishing 'key not set' from 'key set to None'."""
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    def __repr__(self) -> str:
        return "<UNSET>"

_UNSET = _Unset()


# ── History record ────────────────────────────────────────────────────────────

@dataclass
class BlackboardHistoryRecord:
    """Snapshot of a previous value before it was overwritten."""
    value:     Any
    writer:    str   # NodeID that wrote the previous value
    timestamp: float  # time.monotonic() when it was written


# ── Blackboard entry ──────────────────────────────────────────────────────────

@dataclass
class BlackboardEntry:
    """Internal storage cell for one blackboard key."""
    value:       Any          = field(default_factory=_Unset)
    type_name:   str          = ""
    last_writer: str          = ""   # NodeID
    last_write_time: float    = 0.0
    history:     Deque[BlackboardHistoryRecord] = field(default_factory=deque)
    MAX_HISTORY: int = field(default=32, repr=False)

    def has_value(self) -> bool:
        return self.value is not _UNSET


# ── Port schema ───────────────────────────────────────────────────────────────

@dataclass
class PortSchema:
    """Optional schema entry for validating blackboard keys."""
    name:        str
    type_hint:   Optional[type] = None
    direction:   PortDirection  = PortDirection.INPUT
    required:    bool           = False
    description: str            = ""


# ── Blackboard ────────────────────────────────────────────────────────────────

class Blackboard:
    """Scoped, observable key-value store for inter-node communication.

    Key design decisions:

    SCOPED HIERARCHY:
        Child scopes fall through to their parent for unknown keys.
        Subtrees get their own scope (via create_child_scope) so their internal
        keys don't pollute the parent tree's namespace.

    PROVENANCE HISTORY:
        Every write records a ring buffer (max 32 entries) of past values
        along with the writer's NodeID and timestamp.  Supports replay debugging.

    CHANGE SUBSCRIPTIONS:
        Callers may subscribe to any key write.  Used by the reactive execution
        model to trigger re-evaluation when condition-related values change.

    THREAD SAFETY:
        Protected by a reentrant lock.  Multiple nodes may read concurrently
        under the same tick since Python's GIL provides implicit protection.
    """

    MAX_HISTORY = 32

    _global_instances: Dict[str, "Blackboard"] = {}
    _global_lock = threading.Lock()

    def __init__(
        self,
        scope_name: str = "root",
        parent: Optional["Blackboard"] = None,
        remapping: Optional[Dict[str, str]] = None,
    ) -> None:
        self._scope_name  = scope_name
        self._parent      = parent
        self._remapping:  Dict[str, str]           = remapping or {}
        self._entries:    Dict[str, BlackboardEntry]  = {}
        self._schema:     Dict[str, PortSchema]    = {}
        self._callbacks:  Dict[int, Callable[[str, Any], None]] = {}
        self._next_cb_id: int = 0
        self._lock        = threading.RLock()

    # ── Class-level factory ───────────────────────────────────────────────────

    @classmethod
    def create(cls, name: str = "__global__") -> "Blackboard":
        with cls._global_lock:
            if name not in cls._global_instances:
                cls._global_instances[name] = cls(scope_name=name)
            return cls._global_instances[name]

    @classmethod
    def reset(cls, name: str = "__global__") -> None:
        """Clear a named global blackboard (useful between test runs).

        Clears entries, callbacks, and port schema so tests that share a
        blackboard name do not poison each other with stale state.
        """
        with cls._global_lock:
            if name in cls._global_instances:
                bb = cls._global_instances[name]
                with bb._lock:
                    bb._entries.clear()
                    bb._callbacks.clear()
                    bb._schema.clear()

    @classmethod
    def create_child(
        cls,
        parent: "Blackboard",
        remapping: Optional[Dict[str, str]] = None,
    ) -> "Blackboard":
        """Create a child scope with port remapping (legacy API)."""
        return cls(scope_name="child", parent=parent, remapping=remapping)

    def create_child_scope(
        self,
        scope_name: str,
        remapping: Optional[Dict[str, str]] = None,
    ) -> "Blackboard":
        """Create a named child scope.

        Keys in remapping are redirected to this blackboard's keys.
        All other key reads fall through to this (parent) scope.
        Used when entering a subtree.
        """
        return Blackboard(scope_name=scope_name, parent=self, remapping=remapping)

    # ── Core read/write ───────────────────────────────────────────────────────

    def set(self, key: str, value: Any, writer: str = "") -> None:
        """Write a value to the blackboard.

        Stores the previous value in the history buffer (max 32 entries).
        Notifies all change subscribers after releasing the lock.
        """
        with self._lock:
            actual_key = self._remapping.get(key)
            if actual_key is not None and self._parent is not None:
                self._parent.set(actual_key, value, writer=writer)
                return

            entry = self._entries.setdefault(key, BlackboardEntry())

            # Archive current value into history before overwriting
            if entry.has_value():
                rec = BlackboardHistoryRecord(
                    value=entry.value,
                    writer=entry.last_writer,
                    timestamp=entry.last_write_time,
                )
                entry.history.append(rec)
                if len(entry.history) > self.MAX_HISTORY:
                    entry.history.popleft()

            entry.value          = value
            entry.type_name      = type(value).__name__
            entry.last_writer    = writer
            entry.last_write_time = time.monotonic()

            # Copy callbacks before firing to avoid holding lock during callbacks
            cbs = list(self._callbacks.items())

        for _, cb in cbs:
            try:
                cb(key, value)
            except Exception as exc:
                print(f"[bteng] Blackboard subscriber raised: {exc}", file=sys.stderr)

    def get(self, key: str, default: Any = None) -> Any:
        """Read a value from the blackboard.

        Falls through to the parent scope if the key is not found locally.
        """
        with self._lock:
            actual_key = self._remapping.get(key)
            if actual_key is not None and self._parent is not None:
                return self._parent.get(actual_key, default)
            if key in self._entries and self._entries[key].has_value():
                return self._entries[key].value
            # Fall through to parent for unknown keys (subtree → parent lookup)
            if self._parent is not None:
                return self._parent.get(key, default)
            return default

    def get_or_default(self, key: str, default: Any) -> Any:
        """Read a value, returning default if absent."""
        return self.get(key, default)

    def has(self, key: str) -> bool:
        with self._lock:
            actual_key = self._remapping.get(key)
            if actual_key is not None and self._parent is not None:
                return self._parent.has(actual_key)
            if key in self._entries and self._entries[key].has_value():
                return True
            if self._parent is not None:
                return self._parent.has(key)
            return False

    def remove(self, key: str) -> None:
        with self._lock:
            self._entries.pop(key, None)

    # backward-compat alias
    def delete(self, key: str) -> None:
        self.remove(key)

    def clear(self) -> None:
        """Remove all entries from this scope (does not affect parent)."""
        with self._lock:
            self._entries.clear()

    # ── Entry inspection ──────────────────────────────────────────────────────

    def entry(self, key: str) -> Optional[BlackboardEntry]:
        """Return a snapshot copy of the entry for a key, or None if absent.

        Returns a copy so callers cannot mutate internal state outside the lock.
        The history is returned as a new deque (shared items, not a deep copy).
        """
        with self._lock:
            e = self._entries.get(key)
            if e is None:
                return None
            snapshot = BlackboardEntry(
                value=e.value,
                type_name=e.type_name,
                last_writer=e.last_writer,
                last_write_time=e.last_write_time,
                history=deque(e.history),
            )
            return snapshot

    def keys(self) -> List[str]:
        """All keys in this scope (not parent)."""
        with self._lock:
            return list(self._entries.keys())

    def snapshot(self) -> Dict[str, Any]:
        """Current values of all keys in this scope."""
        with self._lock:
            return {k: e.value for k, e in self._entries.items() if e.has_value()}

    @property
    def scope_name(self) -> str:
        return self._scope_name

    # ── Change subscriptions ──────────────────────────────────────────────────

    def subscribe(self, callback: Callable[[str, Any], None]) -> int:
        """Register a listener for any key write.

        Returns a subscription ID for later removal via unsubscribe().
        Callbacks are invoked after the write lock is released with
        (key, new_value) arguments.
        """
        with self._lock:
            cb_id = self._next_cb_id
            self._next_cb_id += 1
            self._callbacks[cb_id] = callback
            return cb_id

    def unsubscribe(self, callback_id: int) -> None:
        with self._lock:
            self._callbacks.pop(callback_id, None)

    # ── Port schema ───────────────────────────────────────────────────────────

    def register_port_schema(self, schema: PortSchema) -> None:
        """Register an expected port for validation."""
        with self._lock:
            self._schema[schema.name] = schema

    def validate_against_schema(self) -> Tuple[bool, str]:
        """Check that all required schema keys are present.

        Returns (True, "") on success or (False, error_message) on failure.
        """
        with self._lock:
            for name, schema in self._schema.items():
                if schema.required:
                    if name not in self._entries or not self._entries[name].has_value():
                        return False, f"Required blackboard key '{name}' is missing"
                    if schema.type_hint is not None:
                        val = self._entries[name].value
                        if not isinstance(val, schema.type_hint):
                            return False, (
                                f"Key '{name}' expected {schema.type_hint.__name__}, "
                                f"got {type(val).__name__}"
                            )
        return True, ""

    # ── Debug ─────────────────────────────────────────────────────────────────

    def debug_string(self) -> str:
        """Human-readable dump of all entries in this scope."""
        with self._lock:
            lines = [f"Blackboard[{self._scope_name}]"]
            for key, entry in sorted(self._entries.items()):
                if entry.has_value():
                    lines.append(
                        f"  {key!r:30s} = {entry.value!r:40s} "
                        f"(type={entry.type_name}, writer={entry.last_writer!r})"
                    )
            return "\n".join(lines)

    def __repr__(self) -> str:
        return f"Blackboard(scope={self._scope_name!r}, keys={self.keys()})"
