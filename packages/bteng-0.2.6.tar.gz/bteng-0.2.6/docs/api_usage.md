# BTEng API Usage

## Installation

```bash
# Debian/Ubuntu: always use a virtualenv (PEP 668 blocks system-wide pip)
python3 -m venv .venv && source .venv/bin/activate

pip install -e .           # development install
pip install bteng          # (once published)

# Optional extras
pip install bteng[zmq]     # ZMQ publisher (requires pyzmq>=24)
pip install bteng[viz]     # Graphviz export
```

---

## Quick Start

### Programmatic tree

```python
from bteng import (
    NodeStatus, NodeConfig, Blackboard,
    SequenceNode, ConditionNode, ActionNode,
    BehaviorTreeEngine,
)

class IsReady(ConditionNode):
    def tick(self):
        return NodeStatus.SUCCESS if self.blackboard.get("ready") else NodeStatus.FAILURE

class DoWork(ActionNode):
    def tick(self):
        print("working!")
        return NodeStatus.SUCCESS

bb = Blackboard.create("robot_state")
bb.set("ready", True)
cfg = NodeConfig(blackboard=bb)

root = SequenceNode("root", children=[IsReady("check", cfg), DoWork("work", cfg)])
engine = BehaviorTreeEngine(root, blackboard=bb)
status = engine.run_until_complete()
print(status)  # NodeStatus.SUCCESS
```

### XML tree

```python
from bteng import BehaviorTreeEngine, Blackboard, register_node, ActionNode, NodeStatus

@register_node()
class MyAction(ActionNode):
    def tick(self): return NodeStatus.SUCCESS

bb = Blackboard.create("demo")
engine = BehaviorTreeEngine.from_xml("my_tree.xml", blackboard=bb, hz=10.0)
status = engine.run_until_complete()
```

---

## Engine API

### Legacy engine (`BehaviorTreeEngine`)

```python
engine = BehaviorTreeEngine(
    root,
    blackboard=bb,     # optional, creates global bb if omitted
    tracer=tracer,     # optional ExecutionTracer
    hz=10.0,           # optional tick rate
)

engine.tick_once()               # → NodeStatus
engine.run_until_complete(
    max_ticks=1000,              # stop after N ticks
    interval=0.05,               # sleep between ticks (sec)
)
engine.halt()                    # stop tree

engine.tick_count                # how many ticks ran
engine.blackboard                # the Blackboard
engine.root                      # root TreeNode
```

### New executor (`TreeExecutor`)

Preferred for production use — richer API, event loop, pause/resume, Inspector, Logger.

```python
from bteng import TreeExecutor, ExecutorConfig, Tree, TreeMetadata

executor = TreeExecutor(ExecutorConfig(
    tick_interval=0.02,    # seconds
    thread_pool_size=4,
    halt_on_completion=True,
))

executor.set_tree(tree)

# Manual mode
status = executor.tick_until_result(max_ticks=1000)

# Event-loop mode (background thread)
executor.start_event_loop()
executor.on_completion(lambda s: print("Done:", s))
# ... executor runs in background ...
executor.stop_event_loop()

# Flow control
executor.pause()
executor.resume()
executor.halt_tree()
executor.reset_tree()
```

**Setup order does not matter** — `set_tree()`, `set_inspector()`, `set_logger()`, and
`set_thread_pool()` can be called in any order. The executor wires everything up lazily.

---

## Blackboard

```python
from bteng import Blackboard

bb = Blackboard.create("robot_state")  # named global instance (shared across modules)
bb.set("key", 42)
bb.set("flag", None)   # None is a valid value — has("flag") returns True
bb.get("key")          # 42
bb.get("flag")         # None  (not the default — the stored value)
bb.get("missing", "default")  # "default"
bb.has("key")          # True
bb.has("flag")         # True  (None stored explicitly)
bb.remove("key")
bb.snapshot()          # dict copy of all set keys

Blackboard.reset("robot_state")  # clear all entries (useful between tests)

# Scoped child blackboard (for SubTree port isolation)
child = Blackboard.create_child(bb, remapping={"local": "global_key"})
child.set("local", 99)   # writes bb["global_key"]
child.get("local")       # reads bb["global_key"]

# Change subscriptions
sub_id = bb.subscribe(lambda key, val: print(f"Changed: {key} = {val}"))
bb.set("speed", 1.5)    # triggers callback
bb.unsubscribe(sub_id)
```

> **Note:** `Blackboard.create(name)` returns a shared singleton per name. Two calls
> with the same name return the same object. Call `Blackboard.reset(name)` between tests
> to avoid state leakage.

---

## Custom Nodes

### Simple subclass

```python
from bteng import ActionNode, NodeStatus, InputPort, OutputPort

class Grasp(ActionNode):
    @classmethod
    def provided_ports(cls):
        return [
            InputPort("target", default="center"),  # default applied when XML omits attr
            OutputPort("result"),
        ]

    def tick(self):
        target = self.get_input("target")           # "center" if not mapped in XML
        cfg    = self.config                        # NodeConfig — ports, params, blackboard
        self.set_output("result", "grasped")
        return NodeStatus.SUCCESS
```

`self.config` exposes the node's `NodeConfig` (blackboard reference, port mappings,
static params). `self.blackboard` is a shortcut to `self.config.blackboard`.

### Stateful node

```python
from bteng import StatefulActionNode, NodeStatus

class Navigate(StatefulActionNode):
    def on_start(self):
        self._distance = float(self.get_input("distance", 1.0))
        return NodeStatus.RUNNING

    def on_running(self):
        self._distance -= 0.1
        if self._distance <= 0:
            return NodeStatus.SUCCESS
        return NodeStatus.RUNNING

    def on_halted(self):
        print("Navigation cancelled")
```

### Async node

```python
import time
from bteng import AsyncActionNode, CancellationToken, NodeStatus

class SlowScan(AsyncActionNode):
    def execute_async(self, token: CancellationToken) -> NodeStatus:
        for i in range(10):
            if token.is_cancelled():
                return NodeStatus.FAILURE
            time.sleep(0.1)
        return NodeStatus.SUCCESS
```

`execute_async(token)` runs in a background thread. The executor auto-injects a shared
`ThreadPool` into every `AsyncActionNode` in the tree when `set_tree()` or
`set_thread_pool()` is called — no manual wiring required.

---

## Node Registration & Factory

```python
from bteng import NodeFactory, register_node

# Decorator style
@register_node()              # name = class name
class MyNode(ActionNode): ...

@register_node("my_alias")    # custom name
class Another(ActionNode): ...

# Manual
factory = NodeFactory.get_instance()
factory.register(MyNode)
factory.register(MyNode, name="alt_name")

# Plugin file (auto-discovers or uses BTENG_NODES list)
factory.load_plugin("/path/to/my_nodes.py")
factory.load_module("my_package.bt_nodes")
```

---

## Inspector & Logger

`Inspector` collects per-node tick statistics and maintains a real-time active-path view.
`Logger` records structured state-transition logs with pluggable sinks.

When both are attached to an executor they are **automatically wired together** — no
extra subscription code needed.

```python
from bteng import Inspector, Logger, LogLevel, TreeExecutor, ExecutorConfig

inspector = Inspector.create()

logger = Logger.create()
logger.add_console_sink(colored=True)
logger.add_json_file_sink("/tmp/bt_run.jsonl")
logger.set_min_level(LogLevel.DEBUG)

executor = TreeExecutor(ExecutorConfig(tick_interval=0.02))
executor.set_tree(tree)
executor.set_inspector(inspector)   # wires Inspector into every node
executor.set_logger(logger)         # auto-subscribes logger to inspector events

executor.tick_until_result()

# Query per-node stats
for uid, stats in inspector.all_stats().items():
    print(uid, stats.tick_count, f"{stats.total_duration*1000:.1f}ms")

# Query full execution history
for record in inspector.execution_history(max_entries=100):
    print(record.name, record.old_status.value, "->", record.status.value)

# Query active (currently RUNNING) nodes
print(inspector.running_nodes())
print(inspector.active_path())
```

`Logger` and `Inspector` can also be used independently without an executor.

---

## ZMQ Publisher

Stream inspector events to external monitoring tools (dashboards, Groot-like
visualisers) via a ZMQ PUB socket. Requires `pip install bteng[zmq]`.

```python
from bteng.introspection import Inspector, ZmqPublisher

inspector = Inspector.create()

pub = ZmqPublisher(port=1667)   # default port matches BTCPP convention
pub.attach(inspector)
pub.start()

# ... run tree with executor.set_inspector(inspector) ...

pub.stop()
```

### Subscriber (separate process)

```python
import zmq, json

ctx  = zmq.Context()
sock = ctx.socket(zmq.SUB)
sock.connect("tcp://localhost:1667")
sock.setsockopt(zmq.SUBSCRIBE, b"bteng")

while True:
    raw  = sock.recv()
    data = json.loads(raw[len(b"bteng "):])
    # data keys: ts, uid, name, type, status, dur_ms, reason
    print(data)
```

### Message format

```json
{
  "ts":     1234.567,
  "uid":    "a1b2c3d4",
  "name":   "Navigate",
  "type":   "action",
  "status": "SUCCESS",
  "dur_ms": 12.3,
  "reason": ""
}
```

Topic prefix is `bteng ` (with trailing space). The publisher uses a background thread
with a bounded queue (1 000 entries); oldest records are dropped if the queue fills —
suitable for real-time display, no backpressure.

---

## TreeBuilder (fluent API)

```python
from bteng import TreeBuilder, Blackboard, NodeStatus, TreeExecutor, ExecutorConfig

bb = Blackboard.create("demo")
tree = (
    TreeBuilder(blackboard=bb)
    .tree_id("Demo")
    .sequence("root")
        .condition("Check", lambda: bb.get("ready", False))
        .action("Work",  lambda: NodeStatus.SUCCESS)
        .fallback("Recover")
            .retry(max_attempts=3)
                .action("Retry", lambda: NodeStatus.SUCCESS)
            .end()                        # close retry
            .action("Fallback", lambda: NodeStatus.FAILURE)
        .end()                            # close fallback
    .end()                                # close sequence
    .build()
)
```

**Rules:**
- Every `sequence()` / `fallback()` / `parallel()` / decorator call opens a scope.
- Every scope **must** be closed with `end()`.
- Decorator scopes (`inverter()`, `retry()`, `timeout()`, …) require exactly one child
  before `end()` — a `RuntimeError` is raised if the child is missing.
- `build()` raises `RuntimeError` if any scopes remain unclosed.

Port mapping immediately after a leaf:

```python
.action("Move", lambda: NodeStatus.SUCCESS)
    .map("target", "current_goal")     # input port → blackboard key
    .map_output("arrived", "done")     # output port → blackboard key
    .literal("speed", 1.05)            # static param
```

---

## Execution Tracing

```python
from bteng import ExecutionTracer, BehaviorTreeEngine

tracer = ExecutionTracer()
engine = BehaviorTreeEngine(root, tracer=tracer)
engine.run_until_complete()

tracer.print_summary()           # human-readable
tracer.save("run.json")          # JSON log
events = tracer.events()         # List[TransitionEvent]
```

With `TreeExecutor`:

```python
from bteng import ExecutionTracer, TreeExecutor

tracer = ExecutionTracer()
executor = TreeExecutor()
executor.set_tree(tree)
executor.set_tracer(tracer)
executor.tick_until_result()

tracer.export_json("run.json")
```

---

## EventBus

```python
from bteng import EventBus, BehaviorEvent, TreeExecutor

bus = EventBus.create()
bus.subscribe("goal_reached", lambda e: print("Goal:", e.payload))
bus.subscribe("*", lambda e: print("Any event:", e.name))

executor = TreeExecutor()
executor.set_tree(tree)
executor.set_event_bus(bus)
executor.start_event_loop()
```

Nodes publish events via `self._config.blackboard` callbacks or by holding a reference
to the bus passed through `NodeConfig.params`.

---

## Unit Testing

```python
from bteng import (
    MockActionNode, MockConditionNode, BehaviorTreeTest,
    NodeStatus, SequenceNode, Tree, TreeMetadata,
)

mock = MockActionNode("Navigate")
mock.set_ticks_to_complete(3)

root = SequenceNode("root", children=[mock])
tree = Tree(TreeMetadata(id="test"), root)

result = (
    BehaviorTreeTest(tree)
    .expect_final_status(NodeStatus.SUCCESS)
    .set_max_ticks(10)
    .run()
)
assert result, result.error_message
```

---

## Python DSL (functional)

```python
from bteng import action, condition, NodeStatus
from bteng import SequenceNode, FallbackNode, Inverter

is_ok = condition("is_ok",  lambda n: n.blackboard.get("ok"))
do_it = action("do_it",    lambda n: NodeStatus.SUCCESS)
fail  = action("always_fail", lambda n: NodeStatus.FAILURE)

root = FallbackNode("root", children=[
    SequenceNode("try", children=[is_ok, do_it]),
    Inverter("inv", child=fail),
])
```
