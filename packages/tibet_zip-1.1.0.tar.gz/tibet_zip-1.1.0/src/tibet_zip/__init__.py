"""tibet-zip — Alias package for tbz (TIBET-zip block-level authenticated compression)."""

__version__ = "1.0.2"

# Re-export everything from tbz
try:
    from tbz import *  # noqa: F401,F403
except ImportError:
    pass
