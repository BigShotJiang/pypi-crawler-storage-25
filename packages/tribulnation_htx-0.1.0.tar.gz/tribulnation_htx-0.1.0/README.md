# Tribulnation Htx SDK

> An SDK to connect Htx with the Tribulnation ecosystem.

🚧 Under construction.