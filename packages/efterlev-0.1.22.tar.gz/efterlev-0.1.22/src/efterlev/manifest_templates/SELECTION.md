# Manifest Starter Pack — KSI Selection

This file documents which KSIs are in the starter pack and why.
Selection criteria locked in DECISIONS 2026-05-06 "Tier 1 #3 design:
Evidence Manifest starter pack".

## Selection criteria

**Hybrid theme + control-family.** A KSI is included if EITHER:

1. It belongs to one of the 3 entirely-procedural FRMR themes
   (AFR, CED, INR — see CLAUDE.md "What's deferred").
2. Its mapped 800-53 controls fall ONLY into procedural-only
   families: AT-* (training), PL-* (planning), PS-* (personnel security),
   PM-* (program management), or large parts of CA-* (assessment).

## Included KSIs

- **KSI-AFR-ADS** — Authorization Data Sharing
- **KSI-AFR-CCM** — Collaborative Continuous Monitoring
- **KSI-AFR-FSI** — FedRAMP Security Inbox
- **KSI-AFR-ICP** — Incident Communications Procedures
- **KSI-AFR-MAS** — Minimum Assessment Scope
- **KSI-AFR-PVA** — Persistent Validation and Assessment
- **KSI-AFR-SCG** — Secure Configuration Guide
- **KSI-AFR-SCN** — Significant Change Notifications
- **KSI-AFR-UCM** — Using Cryptographic Modules
- **KSI-AFR-VDR** — Vulnerability Detection and Response
- **KSI-CED-DET** — Reviewing Development and Engineering Training
- **KSI-CED-RGT** — Reviewing General Training
- **KSI-CED-RRT** — Reviewing Response and Recovery Training
- **KSI-CED-RST** — Reviewing Role-Specific Training
- **KSI-INR-AAR** — Generating After Action Reports
- **KSI-INR-RIR** — Reviewing Incident Response Procedures
- **KSI-INR-RPI** — Reviewing Past Incidents
- **KSI-PIY-RES** — Reviewing Executive Support
- **KSI-PIY-RIS** — Reviewing Investments in Security
- **KSI-PIY-RSD** — Reviewing Security in the SDLC
- **KSI-PIY-RVD** — Reviewing Vulnerability Disclosures
- **KSI-CMT-RVP** — Reviewing Change Procedures
- **KSI-RPL-RRO** — Reviewing Recovery Objectives
- **KSI-SVC-PRR** — Preventing Residual Risk

## Excluded by design

- All other KSIs are detector-evidenceable (or partially so);
  attestation templates would compete with scanner output.
  See `efterlev detectors list` for what ships today.
- KSI-PIY-GIV (Generating Inventories) — IS scanner-evidenceable
  via the `aws.terraform_inventory` detector; excluded from the
  starter pack despite being in the PIY theme.
