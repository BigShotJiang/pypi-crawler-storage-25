# v0.1.10 fixture: the canonical Terraform pattern — IAM policy whose
# rendered JSON comes from an `aws_iam_policy_document` data source.
# Pre-v0.1.10 the detector flagged this as `unparseable` because it
# couldn't resolve `${data.aws_iam_policy_document.X.json}`. v0.1.10
# walks the data source's `statement {}` blocks and finds the MFA
# condition on the HCL `condition { variable = "aws:..." }` form.

data "aws_iam_policy_document" "platform_admin" {
  statement {
    sid    = "AdminWithMfa"
    effect = "Allow"
    actions = [
      "ec2:*",
      "ecs:*",
      "rds:*",
    ]
    resources = ["*"]

    condition {
      test     = "Bool"
      variable = "aws:MultiFactorAuthPresent"
      values   = ["true"]
    }
  }
}

resource "aws_iam_policy" "platform_admin" {
  name        = "platform-admin"
  description = "Admin actions gated on MFA"
  policy      = data.aws_iam_policy_document.platform_admin.json
}
