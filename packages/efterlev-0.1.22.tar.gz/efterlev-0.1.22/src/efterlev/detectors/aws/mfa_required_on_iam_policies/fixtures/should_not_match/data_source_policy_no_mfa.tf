# v0.1.10 fixture: data-source-driven IAM policy whose statements DO
# NOT carry an MFA condition. v0.1.10 should report `mfa_required:
# absent` (the policy is fully resolvable; just doesn't enforce MFA).

data "aws_iam_policy_document" "readonly_auditor" {
  statement {
    sid    = "ReadOnlyAudit"
    effect = "Allow"
    actions = [
      "ec2:Describe*",
      "rds:Describe*",
      "iam:Get*",
    ]
    resources = ["*"]
    # Deliberately no condition block — auditor reads should be
    # available without MFA per the legacy access policy.
  }
}

resource "aws_iam_policy" "readonly_auditor" {
  name   = "readonly-auditor"
  policy = data.aws_iam_policy_document.readonly_auditor.json
}
