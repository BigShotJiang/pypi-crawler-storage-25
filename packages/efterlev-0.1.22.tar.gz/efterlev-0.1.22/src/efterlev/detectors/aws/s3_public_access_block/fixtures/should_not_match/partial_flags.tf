resource "aws_s3_bucket_public_access_block" "loose" {
  bucket                  = "some-bucket"
  block_public_acls       = true
  ignore_public_acls      = true
  block_public_policy     = false
  restrict_public_buckets = false
}
