"""Per-model pricing snapshot for the end-of-run cost summary (Tier 1 #2a, v0.1.19).

Hardcoded table over a YAML config because (a) the table is small enough
that a Python dict is the right tool, (b) we want compile-time visibility
into "what models are priced," and (c) `as_of` dates encode honest
snapshot freshness without a separate file's load step. See DECISIONS
2026-05-06 "Tier 1 #2a design: end-of-run cost summary on agent commands"
for the alternatives considered.

Pricing source: Anthropic's published rates as of `as_of` per entry.
Anthropic occasionally adjusts prices and adds discounts; the
end-of-run summary uses the `~` prefix on the dollar estimate to signal
approximation. Bedrock backend uses the same rates as a proxy because
AWS Bedrock pricing varies by region and discount tier — the summary
adds a clarifying suffix in that case.

When you add a new model to the codebase (e.g. Sonnet 4.7 ships, the
factory switches), add an entry here in the same PR. `lookup()` returns
None for unregistered models, which the cost summary handles gracefully
(tokens-only, no dollar estimate).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelPrice:
    """Anthropic-published per-MTok pricing for one model.

    `input_per_mtok_usd` and `output_per_mtok_usd` are USD per million
    tokens of input / output. `as_of` is the ISO date the snapshot was
    taken — a maintainer reading this six months from now should suspect
    the price may have changed and re-check anthropic.com/pricing.
    """

    model_id: str
    input_per_mtok_usd: float
    output_per_mtok_usd: float
    as_of: str  # ISO date


# Model-ID → ModelPrice. Aliases (Bedrock IDs) point at the same
# Anthropic rate as their Anthropic-API counterpart; the cost summary
# qualifies bedrock-backed costs with a "via bedrock" suffix at the
# call site.
_PRICING: dict[str, ModelPrice] = {
    # Anthropic API IDs.
    "claude-opus-4-7": ModelPrice(
        model_id="claude-opus-4-7",
        input_per_mtok_usd=15.00,
        output_per_mtok_usd=75.00,
        as_of="2026-05-06",
    ),
    "claude-sonnet-4-6": ModelPrice(
        model_id="claude-sonnet-4-6",
        input_per_mtok_usd=3.00,
        output_per_mtok_usd=15.00,
        as_of="2026-05-06",
    ),
    # Bedrock model IDs alias to the same Anthropic rate as proxies.
    # AWS Bedrock pricing varies by region and discount tier; the cost
    # summary surfaces the proxy nature in a suffix.
    "us.anthropic.claude-opus-4-7-v1:0": ModelPrice(
        model_id="us.anthropic.claude-opus-4-7-v1:0",
        input_per_mtok_usd=15.00,
        output_per_mtok_usd=75.00,
        as_of="2026-05-06",
    ),
    "us.anthropic.claude-sonnet-4-6-v1:0": ModelPrice(
        model_id="us.anthropic.claude-sonnet-4-6-v1:0",
        input_per_mtok_usd=3.00,
        output_per_mtok_usd=15.00,
        as_of="2026-05-06",
    ),
}


def lookup(model_id: str) -> ModelPrice | None:
    """Return the pricing entry for `model_id`, or None if unregistered.

    The cost summary's caller treats None as "skip the dollar estimate,
    show tokens-only." Don't raise on unregistered models — a future
    Anthropic release might land in a customer's wheel before this table
    is updated, and crashing the agent's success-path output over a
    missing pricing entry would be the wrong trade.
    """
    return _PRICING.get(model_id)


def estimate_cost_usd(
    model_id: str,
    input_tokens: int,
    output_tokens: int,
) -> float | None:
    """Return USD cost estimate, or None if `model_id` isn't registered."""
    price = lookup(model_id)
    if price is None:
        return None
    return (
        input_tokens * price.input_per_mtok_usd / 1_000_000
        + output_tokens * price.output_per_mtok_usd / 1_000_000
    )


def is_bedrock_model(model_id: str) -> bool:
    """True for Bedrock model IDs (which carry the `via bedrock` suffix
    in the cost summary). Bedrock IDs are dotted with provider/region
    prefixes (e.g. `us.anthropic.claude-...`)."""
    return model_id.startswith(("us.anthropic.", "anthropic."))
