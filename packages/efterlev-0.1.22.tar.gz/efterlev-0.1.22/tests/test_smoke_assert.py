"""Tests for tests/smoke/assert.py — the post-install matrix assertion.

This file exists because the smoke assertion silently failed across
v0.1.20 + v0.1.21: it queried the wrong table name (`records` instead
of `provenance_records`) and asserted a `reports/` dir that the
workflow's command sequence (`init` + `scan` only, no `report run`)
never produces. Two release cycles where the entire matrix was red
without anyone noticing — the workflow_run row in `gh run list`
showed "queued" while individual matrix cells failed.

These tests pin down the contract:
- The script accepts a store dir + exits 0 when a real evidence
  record is present in the `provenance_records` table.
- The script exits 1 when the table is empty.
- The script exits 1 when the SQLite DB is missing.
- The script exits 1 when the table name regresses (no fall-through
  to false-positive PASS).
- The script exits 1 when the store dir doesn't exist at all.
- Importantly: the script does NOT assert a `reports/` directory.
  The smoke workflow runs `init` + `scan` (no `report run`), so
  asserting `reports/` is a category error — the reports pipeline
  is exercised by the E2E smoke that runs on every PR. This test
  locks the assertion against accidentally re-introducing a
  reports/ requirement.
"""

from __future__ import annotations

import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

ASSERT_SCRIPT = Path(__file__).resolve().parent / "smoke" / "assert.py"


def _make_store(
    store_dir: Path, *, with_evidence: bool, table_name: str = "provenance_records"
) -> Path:
    """Create a `<store_dir>/store.db` matching the prod schema; optionally seed an evidence row."""
    store_dir.mkdir(parents=True, exist_ok=True)
    db_path = store_dir / "store.db"
    conn = sqlite3.connect(db_path)
    conn.execute(f"""
        CREATE TABLE {table_name} (
            record_id    TEXT PRIMARY KEY,
            record_type  TEXT NOT NULL,
            content_ref  TEXT NOT NULL,
            derived_from TEXT NOT NULL,
            primitive    TEXT,
            agent        TEXT,
            model        TEXT,
            prompt_hash  TEXT,
            timestamp    TEXT NOT NULL,
            metadata     TEXT NOT NULL
        )
    """)
    if with_evidence:
        conn.execute(
            f"""INSERT INTO {table_name}
                (record_id, record_type, content_ref, derived_from, timestamp, metadata)
                VALUES (?, ?, ?, ?, ?, ?)""",
            ("rec-1", "evidence", "sha256:abc", "[]", "2026-05-07T00:00:00Z", "{}"),
        )
    conn.commit()
    conn.close()
    return db_path


def _run_assert(store_dir: Path) -> tuple[int, str]:
    proc = subprocess.run(  # nosemgrep
        [sys.executable, str(ASSERT_SCRIPT), str(store_dir)],
        capture_output=True,
        text=True,
        check=False,
    )
    return proc.returncode, proc.stdout + proc.stderr


def test_assert_passes_with_seeded_evidence(tmp_path: Path) -> None:
    """Happy path: a store with one evidence record satisfies the assertion."""
    store = tmp_path / "store"
    _make_store(store, with_evidence=True)
    code, out = _run_assert(store)
    assert code == 0, f"expected exit 0; got {code}. Output:\n{out}"
    assert "PASS" in out
    assert "evidence_records=1" in out


def test_assert_fails_when_db_missing(tmp_path: Path) -> None:
    store = tmp_path / "store"
    store.mkdir()
    # No store.db file.
    code, out = _run_assert(store)
    assert code == 1
    assert "SQLite DB missing" in out


def test_assert_fails_when_store_dir_missing(tmp_path: Path) -> None:
    code, out = _run_assert(tmp_path / "does-not-exist")
    assert code == 1
    assert "store dir" in out and "does not exist" in out


def test_assert_fails_when_table_present_but_empty(tmp_path: Path) -> None:
    """Store exists, schema correct, but no evidence rows → fail.
    Locks the no-evidence-records path that pre-v0.1.22 was masked
    by the wrong-table-name bug."""
    store = tmp_path / "store"
    _make_store(store, with_evidence=False)
    code, out = _run_assert(store)
    assert code == 1
    assert "no evidence records in provenance_records" in out


def test_assert_does_not_require_reports_dir(tmp_path: Path) -> None:
    """The smoke workflow runs `init` + `scan` (no `report run`). The
    assertion must NOT require a `reports/` dir — that requirement
    silently failed every matrix cell across v0.1.20 + v0.1.21.

    This test locks the contract: with a valid store and no reports/
    dir at all, the assertion passes."""
    store = tmp_path / "store"
    _make_store(store, with_evidence=True)
    assert not (store / "reports").exists()
    code, out = _run_assert(store)
    assert code == 0, f"reports/ should not be required; got exit {code}:\n{out}"


def test_assert_queries_provenance_records_not_records(tmp_path: Path) -> None:
    """If a future schema rename creates a `records` table without
    `provenance_records`, the smoke assertion must fail (not silently
    pass against the wrong table).

    Lock: when only a `records` table exists and `provenance_records`
    does not, the assertion fails with a clear sqlite error.
    """
    store = tmp_path / "store"
    _make_store(store, with_evidence=True, table_name="records")
    code, out = _run_assert(store)
    assert code == 1
    assert "sqlite error" in out and "provenance_records" in out


def test_assert_usage_message_on_wrong_argc() -> None:
    proc = subprocess.run(  # nosemgrep
        [sys.executable, str(ASSERT_SCRIPT)],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 1
    assert "Usage:" in proc.stderr


def test_assert_script_is_executable_and_locatable() -> None:
    """Sanity: the script lives at its documented path."""
    assert ASSERT_SCRIPT.is_file(), f"smoke assertion script missing at {ASSERT_SCRIPT}"
    body = ASSERT_SCRIPT.read_text(encoding="utf-8")
    # Pin the corrected query string so a careless edit reverting the
    # table name immediately breaks this test.
    assert "FROM provenance_records" in body
    assert "FROM records WHERE" not in body


@pytest.mark.parametrize("evidence_count", [1, 2, 5])
def test_assert_passes_with_multiple_records(tmp_path: Path, evidence_count: int) -> None:
    """Realistic scans produce many evidence records; lock the count path."""
    store = tmp_path / "store"
    db_path = _make_store(store, with_evidence=False)
    conn = sqlite3.connect(db_path)
    for i in range(evidence_count):
        conn.execute(
            """INSERT INTO provenance_records
               (record_id, record_type, content_ref, derived_from, timestamp, metadata)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (f"rec-{i}", "evidence", f"sha256:{i:064x}", "[]", "2026-05-07T00:00:00Z", "{}"),
        )
    conn.commit()
    conn.close()
    code, out = _run_assert(store)
    assert code == 0, f"expected exit 0; got {code}:\n{out}"
    assert f"evidence_records={evidence_count}" in out
