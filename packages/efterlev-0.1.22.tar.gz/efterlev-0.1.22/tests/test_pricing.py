"""Tests for `efterlev.llm.pricing` (Tier 1 #2a, v0.1.19).

Locks the pricing table's shape and behavior. Numeric pricing values
themselves drift over time as Anthropic adjusts rates; tests assert
the structure (lookup behavior, bedrock-detection, cost arithmetic)
not the dollar amounts so a future pricing update doesn't break tests
that just need the table updated.
"""

from __future__ import annotations

from efterlev.llm.pricing import (
    ModelPrice,
    estimate_cost_usd,
    is_bedrock_model,
    lookup,
)


def test_lookup_returns_modelprice_for_known_anthropic_models() -> None:
    """The two model IDs the codebase actually invokes are registered."""
    for model_id in ("claude-opus-4-7", "claude-sonnet-4-6"):
        price = lookup(model_id)
        assert price is not None, f"{model_id} should be in the pricing table"
        assert isinstance(price, ModelPrice)
        assert price.input_per_mtok_usd > 0
        assert price.output_per_mtok_usd > 0
        # Output should always cost more than input for Anthropic frontier models.
        assert price.output_per_mtok_usd > price.input_per_mtok_usd
        # `as_of` is an ISO date string.
        assert len(price.as_of) == 10
        assert price.as_of[4] == "-" and price.as_of[7] == "-"


def test_lookup_returns_modelprice_for_known_bedrock_models() -> None:
    """Bedrock IDs are aliased to the same Anthropic rate (we use it as
    a proxy and qualify with `via bedrock` in the cost summary suffix)."""
    for model_id in (
        "us.anthropic.claude-opus-4-7-v1:0",
        "us.anthropic.claude-sonnet-4-6-v1:0",
    ):
        price = lookup(model_id)
        assert price is not None
        assert price.model_id == model_id


def test_lookup_returns_none_for_unregistered_model() -> None:
    """Unregistered models don't crash — the cost summary falls back
    to tokens-only with a `pricing not registered` suffix. Test the
    contract: lookup returns None."""
    assert lookup("claude-future-model") is None
    assert lookup("") is None
    assert lookup("gpt-5") is None


def test_estimate_cost_usd_arithmetic() -> None:
    """1M input + 1M output tokens on a known model equals
    input_per_mtok + output_per_mtok in dollars."""
    price = lookup("claude-sonnet-4-6")
    assert price is not None
    cost = estimate_cost_usd("claude-sonnet-4-6", 1_000_000, 1_000_000)
    assert cost is not None
    assert abs(cost - (price.input_per_mtok_usd + price.output_per_mtok_usd)) < 0.001


def test_estimate_cost_usd_returns_none_for_unregistered_model() -> None:
    """Unregistered model → no cost. Tested separately from lookup
    because callers use this as the single-call API."""
    assert estimate_cost_usd("unknown-model", 1000, 1000) is None


def test_is_bedrock_model_recognizes_aws_prefix() -> None:
    """AWS Bedrock model IDs carry a `us.anthropic.` or `anthropic.`
    prefix; the cost summary uses this signal to decide whether to
    append the `via bedrock` clarifier."""
    assert is_bedrock_model("us.anthropic.claude-opus-4-7-v1:0")
    assert is_bedrock_model("us.anthropic.claude-sonnet-4-6-v1:0")
    assert is_bedrock_model("anthropic.claude-3-haiku-20240307-v1:0")
    # Anthropic API IDs are NOT bedrock.
    assert not is_bedrock_model("claude-opus-4-7")
    assert not is_bedrock_model("claude-sonnet-4-6")
    assert not is_bedrock_model("")
