# Changelog

All notable changes to Efterlev will be tracked here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) loosely.

## [0.1.22] — 2026-05-07

CI repair + observability lift. release-smoke had been silently
failing across every matrix cell on v0.1.20 + v0.1.21 (and probably
earlier — these are the two cycles I checked back) without anyone
noticing: the workflow_run row in `gh run list` collapsed to a
single "queued" status while individual matrix jobs failed on a
stale assertion script. v0.1.22 fixes the assertion AND adds T7 to
the post-release-triage report so silent matrix failures cannot
recur.

### Fixed

- **`tests/smoke/assert.py`** — the post-install matrix assertion
  had two bugs that made it impossible to pass against a real
  install:
  - Wrong table name: `FROM records` → `FROM provenance_records`
    (actual table per `src/efterlev/provenance/store.py:32`). The
    `OperationalError: no such table: records` was caught by the
    bare `sqlite3.Error` handler and surfaced one line down in
    the FAILED list as "sqlite error querying store: no such
    table: records".
  - Wrong expectation: the script asserted `<store>/reports/`
    exists, but the smoke workflow runs `efterlev init` +
    `efterlev scan` only — never `efterlev report run`, which is
    what generates HTML reports. The `reports/` requirement was a
    category error against the workflow's actual command sequence
    and would have failed every matrix cell on v0.1.20 + v0.1.21
    even without the SQLite bug.

### Added

- **`tests/test_smoke_assert.py`** (11 tests) — unit-tests the
  smoke assertion against an in-memory fixture store. Locks the
  contract so this can't silently break again: happy path with
  seeded evidence passes, missing DB / missing store dir fails,
  empty `provenance_records` table fails with a clear message,
  presence of a `records` table without `provenance_records`
  also fails (no false-positive PASS path), reports/ dir is NOT
  required (the test specifically asserts the script passes
  against a store with no reports/ dir at all).

- **T7 release-smoke matrix** in `scripts/triage.sh` — surfaces
  the release-smoke matrix conclusion on the GitHub Release
  page, alongside the existing T1-T6 deterministic checks.
  Queries the GH Actions API for the release-smoke workflow run
  matching the tag and reports per-cell failure detail when red.
  PENDING is a valid status when triage fires before smoke
  completes; the workflow now reruns triage on release-smoke
  completion to repopulate.

- **`.github/workflows/post-release-triage.yml`** — added
  `release-smoke` to the `workflow_run` trigger list so triage
  reruns when the matrix finishes (~10 min after tag), repopulating
  T7 with real data after the initial release-container-triggered
  run (~4 min after tag) showed T7 PENDING. Added
  `actions: read` permission so triage can query the GH Actions
  API for matrix conclusion. Dropped the prior
  `conclusion == 'success'` gate: triage now fires regardless of
  upstream success/failure so the Release page surfaces actual
  state instead of staying blank when something went wrong.

### Internal

- Test count: 1120 → 1131 (+11 from the new
  `tests/test_smoke_assert.py`). Source files: unchanged at 178.
  Detector count: unchanged at 45.
- `scripts/triage.sh` phase numbering documented in the file
  header. PENDING gets a ⏳ marker in the Release table.

### Cross-references

- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  surfacing silent failures via T7" — full design rationale,
  alternatives considered (separate workflow vs. T7-in-triage),
  and the decision to make the GH Release page the single
  observable surface for release-quality data.
- LIMITATIONS.md "Lessons learned: silent matrix failures
  v0.1.20–v0.1.21" — a callout flagging the prior gap.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — Tier 1 #1–#3
  shipped; Tier 1 #4 (detector gap analysis) still on the
  roadmap. v0.1.22 is an unscheduled CI repair, not a Tier 1
  item.

## [0.1.21] — 2026-05-06

Tier 1 #3 of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #3 design"). Ships the Evidence Manifest
starter pack — the biggest single coverage lift available per
LIMITATIONS' "scanner + manifests can approach 80%+" claim. Closes
the procedural-KSI gap that detectors structurally can't reach.

### Added

- **`efterlev manifests init --starter-pack`** — new subcommand tree
  (`efterlev manifests`) for Evidence Manifest content management.
  When `--starter-pack` is set, copies 24 bundled
  `<KSI-ID>.template.yml` files + a `README.md` workflow guide + a
  `SELECTION.md` audit trail into `.efterlev/manifests/starter-pack/`.
  Subdir lands OUTSIDE the manifest loader's pickup glob — templates
  are physically present (the user can read, copy from, version-
  control them) but invisible to the attestation pipeline until
  explicitly moved to the parent `.efterlev/manifests/` dir.
  `--force` required to overwrite an existing subdir.

- **24 hand-authored manifest templates** under
  `src/efterlev/manifest_templates/`. Bundled in the wheel via
  `importlib.resources`. Selection criteria locked in DECISIONS
  2026-05-06: hybrid theme + control-family check produces 17 KSIs
  from the 3 entirely-procedural FRMR themes (AFR/CED/INR) + 7 from
  detector-covered themes whose mapped 800-53 controls are
  procedural-only families (PIY/CMT/RPL/SVC). Each template:
  - `ksi: KSI-XXX-XXX` + `name: "..."`
  - `_template_help.description` (2-3 sentences from FRMR + audit framing)
  - `_template_help.questions` (3-7 hand-authored questions per KSI)
  - `evidence[0]` attestation skeleton with explicit `DRAFT —`
    placeholders for `statement`, `attested_by`, `attested_at`,
    `reviewed_at`, `next_review`, `supporting_docs`
  - Inline DRAFT example showing realistic attestation shape

- **`scripts/generate_starter_pack.py`** — source of truth for the 24
  templates. Re-run when FRMR adds a new KSI matching the selection
  criteria, or when maintainer-curated `_template_help` content changes.

### Changed

- `efterlev.manifests.loader.discover_manifest_files` now skips
  `*.template.yml` files. Defense-in-depth: even if a user
  accidentally copies `KSI-XXX.template.yml` directly to
  `.efterlev/manifests/` without dropping the suffix, the loader
  excludes it from the attestation pipeline. One-line filter
  addition; behavior preserved for all real `*.yml` / `*.yaml`
  manifests.

- `LIMITATIONS.md` adds a Tier 1 #3 shipped marker; updated
  `next_review` recommendation in templates is "6-month cadence".

### Internal

- `tests/test_manifest_starter_pack.py` (11 tests) covers: 24-template
  count lock, README + SELECTION presence, every KSI ID exists in
  FRMR catalog, every template has ≥3 hand-authored questions, every
  fillable field carries a `DRAFT` placeholder, loader skip filter
  excludes `*.template.yml`, CLI happy path copies all templates,
  CLI refuses overwrite without `--force`, CLI overwrites cleanly
  with `--force`, CLI refuses without `--starter-pack` flag, CLI
  refuses against an uninitialized workspace.
- Test count: 1109 → 1120 (+11). Source files: 177 → 178
  (`manifest_templates/` package marker). CLI commands: 25 → 27
  (added `manifests` subcommand tree + `manifests init`).
- Wheel build verified to include all 24 `*.template.yml` files +
  README.md + SELECTION.md under `efterlev/manifest_templates/`.

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #3 design: Evidence Manifest starter
  pack" — full design rationale, selection criteria, alternatives
  considered, locked-not-open decisions per "never lazy" directive.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — this is Tier 1 #3.
  Tier 1 progress: #1 (quickstart, v0.1.18), #2a (cost summary,
  v0.1.19), #2b (--dry-run, v0.1.20), #3 (this) shipped; #4
  (detector gap analysis) remains.
- LIMITATIONS.md "scanner + manifests can approach 80%+" — what the
  starter pack enables in practice.
- `src/efterlev/manifest_templates/SELECTION.md` — per-KSI selection
  audit trail.

## [0.1.20] — 2026-05-06

Tier 1 #2b of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #2b design"). Adds `--dry-run` and
`--dump-prompt PATH` to every agent command — the audit-credibility
primitive a 3PAO needs to verify exactly what the LLM was sent.
Pairs with v0.1.19's end-of-run cost summary to complete the
"cost + prompt visibility" Tier 1 #2 work.

### Added

- **`--dry-run` and `--dump-prompt PATH` flags on `efterlev agent
  {gap, document, remediate}`.** When set, the command builds every
  assembled prompt the agent would send, surfaces them as a JSON array
  of literal Anthropic API request envelopes (model + system + messages
  + max_tokens), augmented with `_efterlev` metadata (per-prompt
  iteration index, label, token estimate, dollar cost estimate from
  v0.1.19's pricing table), and exits 0 without invoking the LLM. No
  network call, no Claim records written, no `receipts.log` lines —
  zero side effects on `.efterlev/`. Per-run nonced fences are present
  in every dumped prompt — exactly what Anthropic would have seen.
  Implementation via context-var pattern (matches `active_redaction_ledger`
  / `active_store`); `Agent._invoke_llm` checks
  `active_dry_run_session.get()` and short-circuits with a per-agent
  structurally-valid stub output. (DECISIONS 2026-05-06 "Tier 1 #2b
  design")

- **`--force` flag on `--dump-prompt PATH`.** Refuses to overwrite
  an existing PATH unless `--force` also passed. Standard CLI hygiene
  for the regulated context this command targets — clobbering an
  audit packet is a real harm. Initial design draft of this entry
  rejected `--force` as "friction without real benefit"; revised on
  re-reading per the maintainer's "never lazy" directive.

- **`scripts/triage.sh` T2 doctor-shape unchanged** but `efterlev
  agent {gap,document,remediate} --help` now lists the three new
  flags. Manual smoke after PR lands: `efterlev agent gap
  --target . --dry-run | jq '.[0]._efterlev'` shows the per-prompt
  metadata.

### Changed

- `Agent._invoke_llm` (in `efterlev.agents.base`) gained a
  `dry_run_label: str | None = None` parameter (used for the captured
  prompt's label field). Backwards-compatible default; existing
  callers unchanged.
- `ProvenanceStore.write_record` short-circuits early when a
  `DryRunSession` is active in the context var, returning a
  structurally-valid sentinel `ProvenanceRecord` without touching
  SQLite, the blob store, or `receipts.log`.
- Each agent class (`GapAgent`, `DocumentationAgent`,
  `RemediationAgent`) declares a `_dry_run_stub_output()` factory
  that returns an empty `output_model` instance. The base class's
  default raises if a subclass forgets to implement.
- LIMITATIONS.md adds Tier 1 #2b under "Aspirational / roadmap" as
  shipped at v0.1.20.

### Internal

- `tests/test_dry_run.py` (12 tests) covers session capture +
  serialization, context-var lifecycle, `_invoke_llm`
  short-circuit (asserted via a `FailIfCalledClient` stub),
  `ProvenanceStore.write_record` no-op contract (zero side effects
  on the workspace), CLI flag validation (`--force` requires
  `--dump-prompt`), end-to-end agent-gap dry-run via subprocess,
  `--dump-prompt` file-write semantics, overwrite refusal without
  `--force`, force-overwrite, and the "no new store rows" contract.
- Test count: 1097 → 1109 (+12). Source files: 176 → 177
  (`agents/dry_run.py`).
- The dry-run path is ready for v0.2's vendored Anthropic
  tokenizer follow-up: today the `_efterlev.token_estimate` is a
  4-chars-per-token approximation flagged honestly via the
  `token_estimate_method` field. When precision matters more than
  it does today (real customer feedback), swap in the official
  tokenizer; the surface is one function in `agents/dry_run.py`.

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #2b design" — full design rationale,
  alternatives considered, the "never lazy" revision note that drove
  the all-prompts / API-envelope / `--force` decisions.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — meta-decision; #2b
  closes the "cost + prompt visibility" pair.
- v0.1.19 cost summary (PR #144) — sister feature; together they
  give pre-run AND post-run cost visibility.

## [0.1.19] — 2026-05-06

Tier 1 #2a of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #2a design: end-of-run cost summary on
agent commands"). Adds per-run cost visibility to every agent command
without changing the agent API or scanner output.

### Added

- **End-of-run cost summary on `efterlev agent {gap, document,
  remediate}`.** Each command prints one line at the end of its
  success path:
  ```
  LLM cost: 38,201 in / 8,455 out tokens on claude-sonnet-4-6 (~$0.24)
  ```
  Sums tokens by model from `.efterlev/receipts.log` (filtered to
  this invocation's window via `started_at`), looks up pricing in
  `src/efterlev/llm/pricing.py`, prints. Bedrock backend appends
  `(via bedrock; AWS region pricing may differ)`. Unregistered
  models surface tokens-only with a `pricing for <model> not
  registered` hint instead of crashing. Multi-model runs (e.g. Opus
  → Sonnet fallback fired mid-run) sum correctly and use a short-name
  comma-joined display. Reads from receipts.log rather than collecting
  per-agent — no agent API change, the data is already captured.
  (DECISIONS 2026-05-06 "Tier 1 #2a design"; agents/cost_summary.py
  + llm/pricing.py + 3-line CLI hook in each agent command)

### Changed

- `LIMITATIONS.md` adds a new "Cost estimates are best-effort" note
  documenting the snapshot-pricing posture, Bedrock proxy caveat, and
  the unregistered-model fallback. Tier 1 #2a flips from
  "aspirational" to "shipped at v0.1.19" in the Aspirational/roadmap
  section.

### Internal

- `tests/test_cost_summary.py` (8 tests) covers single-model run,
  multi-model run, Bedrock suffix, unregistered-model fallback,
  mixed priced+unpriced run, started_at timestamp filter excluding
  prior-run entries, no-receipts-file case, no-LLM-entries case
  (StubLLMClient). `tests/test_pricing.py` (6 tests) locks the
  pricing-table API behavior independent of dollar amounts (which
  drift over time as Anthropic adjusts rates).
- Test count: 1083 → 1097 (+14). Source file count: 174 → 176
  (`pricing.py` + `cost_summary.py`).
- 2b (`--dry-run` / `--dump-prompt` flags) gets its own DECISIONS
  entry next, then implementation. Tier 1 sequence:
  1 (quickstart, v0.1.18) ✓ → 2a (cost summary, this) ✓ → 2b →
  3 (manifest starter pack) → 4 (detector gap analysis).

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #2a design" — full design rationale,
  open questions, alternatives considered.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — meta-decision sequencing.
- v0.1.9 token-usage telemetry — the data layer this presentation reads.

## [0.1.18] — 2026-05-06

Tier 1 #1 of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 0/1 sequencing"). Ships the first ICP-aligned
feature after the v0.1.16/17 auto-triage infrastructure landed:
**`efterlev quickstart`** — a one-command activation demo for the
ICP A day-one experience.

### Added

- **`efterlev quickstart`** lays down a bundled synthetic Terraform
  + Evidence Manifest fixture in a temp workspace under the
  platform-appropriate user cache dir (`~/Library/Caches/efterlev/`
  on macOS, `~/.cache/efterlev/` on Linux, `%LOCALAPPDATA%\efterlev\`
  on Windows via `platformdirs`), runs `init → scan → agent gap →
  agent document` end-to-end against it, and prints a 5-line summary
  with workspace path, scan stats, classification breakdown, and a
  next-steps line pointing at the user's own repo. Realistic wall
  time: 60–180s with `ANTHROPIC_API_KEY` set (~$0.30 on Sonnet);
  honors `EFTERLEV_E2E_MODEL` for backend/model override.
  (DECISIONS 2026-05-06 "Tier 1 #1 design"; cli/main.py +
  src/efterlev/quickstart/)

- **Graceful no-key degradation.** When `ANTHROPIC_API_KEY` is unset,
  the deterministic phases (init + scan) still run and produce real
  detector evidence; the agent stages skip with a clear "set the key
  and re-run for AI-driven KSI classification + draft attestation"
  hint. ICP A users without a Claude account yet get actionable output
  rather than a stack trace. The summary surfaces real scan stats
  (resources / evidence records / detectors fired) on this path.

- **`python -m efterlev` entry point** (`src/efterlev/__main__.py`).
  Lets `quickstart` shell out to the CLI without depending on the
  `efterlev` script being on PATH at the time the subprocess starts.
  No user-visible change for the standard pipx / uv-tool installs;
  the script-on-PATH invocation continues to work.

### Changed

- **Bundled fixture moved to `src/efterlev/quickstart/`** so
  `efterlev quickstart` and `scripts/e2e_smoke.py` share the same
  source of truth. Growing the fixture for new detector coverage
  in either consumer benefits both automatically. The CI E2E smoke
  gate continues to use the same fixture; no behavior change for
  the harness.

- **`platformdirs>=4.0,<5`** added to dependencies. Tiny dep with no
  transitives; same library pip / uv / ruff use for cross-platform
  cache-dir resolution.

### Internal

- 8 new regression tests in `tests/test_quickstart.py`: fixture
  shape lock; terraform-writer skips manifests; manifest-writer
  skips terraform; cache-root resolves under user HOME; scan-output
  parser extracts the right fields; gap-summary returns None on
  no-report path; e2e_smoke imports the same FIXTURE object as
  quickstart (asserts the shared-source refactor); end-to-end
  no-key path runs clean and produces the expected summary.
- Test count: 1075 → 1083. Source file count: 172 → 174 (added
  `__main__.py` + `quickstart/__init__.py`).

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #1 design: efterlev quickstart" —
  full design rationale, alternatives considered, scope of v0.1.18.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing for v0.1.18+
  post-auto-triage-landing" — the meta-decision sequencing this
  as Tier 1 #1.
- `CLAUDE.md` "Path forward (v0.1.18+)" — Tier 1 #1 entry.
- `LIMITATIONS.md` "Aspirational / roadmap" — Tier 1 #1 flips from
  "aspirational" to "shipped at v0.1.18" in the same PR.

## [0.1.17] — 2026-05-06

Triage-driven patch from the v0.1.16 first-of-kind auto-triage. Two
findings, both in the v0.1.16 triage infrastructure itself (not in the
v0.1.16 release artifacts, which are 4/4 cryptographically clean):

1. The `post-release-triage.yml` workflow used the default
   `sigstore/cosign-installer@v3` (cosign 2.5.2), which doesn't
   auto-discover OCI 1.1 referrer attestations. Pinned to cosign **2.6.3**
   (the latest 2.x; cosign 3.0.x can't be installed by the action because
   it dropped legacy `.sig` files for `.sigstore.json` bundles). Landed in
   PRs #136 + #137 ahead of v0.1.17.
2. `scripts/triage.sh`'s T6 ("cosign tree visibility") was a redundant
   lightweight inventory check that produced false-negatives on cosign
   2.6.x — `cosign tree` doesn't enumerate OCI 1.1 referrer attestations
   even when they're present. T4 (`verify-release.sh`) already
   cryptographically verifies both attestation presence and validity via
   `cosign verify-attestation --type slsaprovenance1`. **v0.1.17 drops T6.**

The auto-triage methodology is working as designed: caught the issue in
the first auto-triage run for v0.1.16, surfaced both findings, and
v0.1.17 closes them via the standard release loop. v0.1.16's GitHub
Release page has been updated with a clarifying note explaining the
T6 false-negative and pointing at v0.1.17 as the structural fix.

### Changed

- **`scripts/triage.sh` drops T6** ("cosign tree visibility"). The 6
  remaining phases (T1 install + version sanity, T2 doctor shape, T3
  detector count, T4 verify-release.sh, T5 container manifest, T6
  check-docs against tagged source — renumbered from T7) cover the
  release-correctness surface that produced findings F1–H1. T4's
  `cosign verify-attestation` is now the single canonical check for
  "is the SLSA attestation attached and valid" — no separate inventory
  check needed.

### Internal

- `verify-release.sh` example version bumped from v0.1.16 to v0.1.17.
- The `post-release-triage.yml` cosign 2.6.3 pin (PR #137) carries
  forward unchanged.
- v0.1.17 will be the second release with an auto-generated GH Release
  page. Expected outcome: 6/6 PASS, no findings, no manual notes
  required.

## [0.1.16] — 2026-05-06

Infrastructure release. Adds `scripts/triage.sh <tag>` — a deterministic,
zero-LLM post-release validator — and a workflow that runs it after every
tag publish, attaching the triage report as the GitHub Release notes body.
This codifies the manual triage methodology that surfaced findings F1–H1
across v0.1.12–v0.1.15 (each cut catching paper cuts the prior cut's fix
introduced) into automation that runs without human prompting. Side
benefit: auto-creates the GitHub Release pages that have been missing
since v0.1.5 (the team never wrote release notes manually).

No scanner-output behavior change. v0.1.15's 4/4 cryptographic
verification carries forward unchanged.

### Added

- **`scripts/triage.sh <tag>`** runs T1–T7 deterministically:
  - T1: pipx-install the published wheel from PyPI, confirm `--version`
  - T2: confirm `efterlev doctor` returns the expected 7-check shape
  - T3: confirm `efterlev detectors list` reports the expected count
  - T4: invoke `scripts/verify-release.sh` (4/4 PEP 740 + cosign + SLSA v1)
  - T5: confirm container manifest has linux/amd64 + linux/arm64 via
        the OCI registry API (no Docker daemon needed)
  - T6: confirm `cosign tree` shows signature + SLSA v1 attestation
  - T7: run `scripts/check-docs.py` against the tagged source

  Output: GitHub-Flavored Markdown report. Exit 0 = clean; exit 1 =
  findings. Runnable locally for ad-hoc triage of any prior tag.

- **`.github/workflows/post-release-triage.yml`** triggers on
  `release-container.yml` completion (the longer of the two release
  workflows). On the first run for a tag, creates the GitHub Release
  for that tag with the triage report as the body. On reruns
  (`workflow_dispatch`), edits the existing notes. Job exits non-zero
  when triage reports findings, so the Actions UI flags release-quality
  regressions visibly.

- **DECISIONS 2026-05-06** documents the architectural choice — why
  triage runs decoupled from `release-container.yml`, why the report
  attaches to the GH Release rather than a `docs/triage/` directory,
  and which alternatives were considered (full backfill, daily cron,
  external validation framework).

### Internal

- Triage script smoke-tested against v0.1.15 → 7/7 PASS; fail-path
  verified by injecting a synthetic detector-count mismatch (exit 1,
  finding surfaced in the report's Findings section).
- v0.1.16 will be the first release with an auto-generated GH Release
  page. The page body becomes the per-version triage landing page,
  giving 3PAOs and external auditors a documented post-publish
  validation trail without per-release manual effort.

## [0.1.15] — 2026-05-06

Triage-driven patch from the v0.1.14 deterministic validation. Closes the
single finding (H1): the v0.1.14 `install_uniqueness` doctor check walked
PATH only, which missed the dominant parallel-install footgun. Real
repro this session: `pipx install efterlev` venv at
`~/.local/pipx/venvs/efterlev/`, `uv tool install efterlev` venv at
`~/.local/share/uv/tools/efterlev/`, single PATH symlink at
`~/.local/bin/efterlev` pointing into the uv-tool venv. The user runs
`pipx upgrade efterlev`, sees "upgraded", but `efterlev --version`
keeps returning the OLD version because the PATH symlink belongs to uv
tool. v0.1.14's check returned PASS on this state; v0.1.15's catches it.

### Changed

- **`efterlev doctor` install_uniqueness check now walks package-manager
  metadata dirs in addition to PATH.** The PATH walk (G2 in v0.1.14)
  catches the case of two custom installs both on PATH; the new
  manager-metadata walk catches the dominant case of two managers
  fighting over a single PATH symlink. Detected manager dirs:
  - `~/.local/pipx/venvs/efterlev/` → pipx
  - `~/.local/share/uv/tools/efterlev/` → uv tool
  - `~/Library/Python/<v>/lib/python/site-packages/efterlev/` (macOS user pip)
  - `~/.local/lib/python<v>/site-packages/efterlev/` (linux user pip)

  When ≥2 distinct installations are detected by either strategy, the
  warning names each path + the matching uninstall command. PATH
  binaries that resolve under a known manager dir aren't double-counted
  (otherwise a single pipx install + its `~/.local/bin` shim would
  false-positive). The green-case detail also names which manager
  owns the install — useful diagnostic for "where IS efterlev installed?"
  (H1 from v0.1.14 triage; cli/doctor.py)

### Internal

- Test count: 1073 → 1075 (+2: `detects_pipx_and_uv_tool_managers`
  asserts the dominant H1 footgun fires the warn; `does_not_double_
  count_path_under_manager` guards against the false-positive case
  where a single pipx install plus its PATH shim would otherwise
  read as two installs). The existing 3 install_uniqueness tests
  carry forward unchanged in semantics; one was renamed for clarity.

## [0.1.14] — 2026-05-06

Triage-driven patch from the deterministic, zero-LLM post-release validation
of v0.1.13 (the same methodology that produced the v0.1.12 patch). Two
paper-cut findings closed; no scanner-output behavior change. v0.1.13's
4/4 cryptographic verification carries forward unchanged.

### Fixed

- **`docs/index.md` carried two stale current-version references to
  v0.1.11** — one at line 67 (*"45 ship today (v0.1.11)"*) and one at
  line 77 (*"v0.1.11 ... thirteen patch releases..."*). The
  drift slipped through every prior release because the existing
  `check-docs.py` rules cover test/detector/indicator/source-file
  counts and CLI-verb references, but not "current version" prose.
  Both lines now read v0.1.14. (G1 from v0.1.13 triage)
- **`scripts/check-docs.py` gains a `current_version_claim` rule.**
  Scans every `.md` repo-wide for `vX.Y.Z is current` / `vX.Y.Z current`
  patterns and asserts the version matches `efterlev.__version__`.
  Past-tense references ("v0.1.11 closed five findings", "since v0.1.0")
  deliberately don't match — those are historical, not current-state
  claims. The rule caught three additional v0.1.13 stragglers in
  README + CLAUDE.md during the v0.1.14 cut, plus a stale 1070 → 1073
  test-count claim. The doc/code agreement now stays tight by
  construction. (G1 from v0.1.13 triage; scripts/check-docs.py)

### Added

- **`efterlev doctor` warns when multiple `efterlev` binaries sit on
  PATH.** When `pipx install efterlev` and `uv tool install efterlev`
  both exist, PATH ordering picks the winner silently — `pipx upgrade`
  / `uv tool upgrade` against the loser reports success but
  `efterlev --version` still returns the older install. Real repro
  from the v0.1.13 triage: pipx 0.1.13, uv tool 0.1.11, PATH found uv
  first, "upgraded but version unchanged" with no obvious cause. The
  new `install_uniqueness` check walks PATH (resolving symlinks so
  `/usr/local/bin → /opt/bin` doesn't false-positive), names every
  `efterlev` binary it finds, identifies the PATH winner, and points
  at the matching uninstall command. Pre-flight surfaces the
  parallel-install state before the user hits the version-mismatch
  confusion. (G2 from v0.1.13 triage; cli/doctor.py)

### Internal

- Test count: 1070 → 1073 (3 new per-fix regression tests for
  `install_uniqueness`: warns-on-multiple, passes-on-single, and
  dedups-symlinked-paths to prevent the false-positive case).
- `verify-release.sh` example version bumped from v0.1.13 to v0.1.14.

## [0.1.13] — 2026-05-06

Permissions-fix patch on top of v0.1.12. The v0.1.12
`actions/attest-build-provenance@v2` step added to `release-container.yml`
failed at runtime with `Resource not accessible by integration` because
the workflow's `permissions:` block was missing `attestations: write`.
Result: v0.1.12 published with a cosign-signed container but no SLSA
cosign-verifiable attestation, leaving `verify-release.sh v0.1.12` at
3/4 passed (the same posture as v0.1.10 + v0.1.11). v0.1.13 adds the
missing permission and re-fires the full sign + attest path, taking
`verify-release.sh v0.1.13` to 4/4.

### Fixed

- **`release-container.yml` carries `attestations: write`** so the v0.1.12
  `actions/attest-build-provenance@v2` step can call the GitHub
  attestations API. The step's docs list the required permissions but
  the workflow comment that named the related `id-token: write` permission
  obscured the omission. v0.1.13 ships nothing else; the v0.1.12 changes
  (PEP 740 verifier, F2/F3/F4 fixes) all carry forward.

### Internal

- `scripts/verify-release.sh` failure message updated: pre-v0.1.13
  releases are now disambiguated as either "buildx-only provenance"
  (v0.1.10 + v0.1.11) or "attest step misconfigured" (v0.1.12).

## [0.1.12] — 2026-05-06

Triage-driven patch from a deterministic, zero-LLM post-release validation
of v0.1.11 (the first such validation against published wheel + container
artifacts). Four findings closed; no scanner-output behavior change. The
biggest piece is `verify-release.sh` going from 0/4 passed to 4/4 passed
on v0.1.12+ — the script's PyPI check was hitting a 404 because PyPI
moved Trusted-Publishing attestations from `<url>.sigstore` sidecars to
the PEP 740 `/integrity` endpoint, and the container SLSA check was
failing because buildx's in-OCI-manifest provenance was never wrapped as
a cosign-verifiable attestation. Both are wired correctly now; the
project's "verify the release" claim is no longer aspirational.

### Fixed

- **`scripts/verify-release.sh` rewritten for PEP 740 + drops `docker
  buildx` hard-dep.** The PyPI check now fetches each artifact's
  Sigstore bundle from `https://pypi.org/integrity/{project}/{version}/{filename}/provenance`,
  reshapes the PEP 740 attestation into a Sigstore v0.3 bundle (snake_case
  → camelCase, certificate string → `{rawBytes:...}`, envelope DSSE
  reshape), and verifies with `python -m sigstore verify identity`. The
  cosign signature check uses `cosign verify <tag>` directly (cosign
  resolves tag→digest internally; the previous `docker buildx imagetools
  inspect` step was unneeded). The SLSA check (#3 below) now finds a
  cosign-verifiable attestation on v0.1.12+ container images. Pre-v0.1.12
  releases still fail check 3 by design — the script's failure message
  names the upgrade path so users aren't left guessing. (F1 from v0.1.11
  triage; DECISIONS 2026-05-05)
- **`actions/attest-build-provenance@v2` wired into `release-container.yml`.**
  Produces a cosign-verifiable SLSA v1 build-provenance attestation
  pushed to GHCR alongside the image. v0.1.10 + v0.1.11 had buildx-emitted
  SLSA v0.2 provenance attached to the OCI image manifest only
  (verifiable via `docker buildx imagetools inspect --format '{{ json
  .Provenance }}'`); the absence of a separate cosign attestation made
  `cosign verify-attestation --type slsaprovenance` fail. From v0.1.12
  onward, cosign discovers the attestation via the OCI 1.1 referrers
  API. (F1 from v0.1.11 triage)
- **`efterlev scan` warns when `--target` sits below a `.github/workflows/`
  ancestor.** Real customer repos with `infra/terraform/`-style layouts
  routinely run `efterlev scan --target infra/terraform/` and silently
  drop every GitHub-source detector (4 in v0.1.x — sbom-action, codeql,
  dependency-review, ci_validation_gates). The new warning surfaces the
  ancestor path and recommends scanning from the repo root. Walks parents
  of `--target` until it finds `.github/workflows/` or hits the git repo
  root. Documented v0.1.x footgun, no in-tool mitigation pre-v0.1.12.
  (F2 from v0.1.11 triage; cli/main.py)
- **`efterlev scan` surfaces a plan-JSON hint when ≥1 evidence record
  contains an `unparseable` attribute value.** The dominant case is
  `aws_iam_policy { policy = jsonencode({...}) }` — python-hcl2 doesn't
  evaluate Terraform function calls, so the policy comes through as
  `mfa_required="unparseable"` (or equivalents in other detectors).
  Pre-v0.1.12 the unparseable status was buried inside individual
  Evidence records; users who didn't grep the JSON sidecar never saw
  the recommendation to switch to `--plan plan.json` mode (which gives
  Terraform-resolved values). The hint is suppressed in plan-JSON mode
  itself. (F4 from v0.1.11 triage; cli/main.py)
- **Two doc-drift fixes for `.efterlev/reports/<subdir>/` paths, plus a
  `check-docs.py` rule that catches the pattern.** `docs/ai-quickstart-prompt.md:288`
  cited a non-existent gap-report subdir; the actual gap-report path is
  flat (`.efterlev/reports/gap-<ts>.json`). The opposite drift in
  `docs/reference/poam-markdown-shape.md:5` said POA&M lands flat; the
  actual path is `.efterlev/reports/poam/poam-<ts>.md`. The new
  check-docs rule scans every repo `.md` for the
  `.efterlev/reports/<subdir>/` shape and asserts the subdir is in the
  allowlist (currently `{"poam"}` — gap, scan, attestation, documentation
  are flat). When a new subdir is added in code, the check fails until
  the allowlist is bumped, forcing the doc/code agreement to stay tight.
  (F3 from v0.1.11 triage; scripts/check-docs.py)

### Internal

- Test count: 1066 → 1070 (4 new per-fix regression tests for F2/F4 — F3
  is covered by the new check-docs rule).

## [0.1.11] — 2026-05-06

3PAO-finding patch from the v0.1.10 blinded review. A FedRAMP-accredited
3PAO ran a paper review against a clean v0.1.10 govnotes-demo run and
returned an Accept-with-conditions disposition with five findings the
tool's own automation couldn't catch. This release closes the four
artifact-credibility findings and disambiguates the misleading walker
message that drove the highest-severity finding.

No behavior changes for scanner output or LLM-call costs — every fix
lands at the rendering / display / persistence layer.

### Fixed

- **Agent-drafted narratives carry an injected `DRAFT — requires human
  review.` marker** regardless of what the LLM returned. v0.1.10
  shipped the marker hardcoded into the `deterministic_template`
  branch but missing from `agent_drafted` entries when the model
  declined to emit it; the asymmetry made some attestations look
  finalized when they were not. The marker is now structural —
  injected post-response — and the persisted Claim payload, the
  rendered HTML narrative, and the FRMR artifact entry agree.
  Idempotent: a model that already produced the prefix doesn't get
  a doubled marker. (3PAO HIGH; agents/documentation.py)
- **`AttestationDraft` carries `controls_mapped`** so the doc HTML
  and JSON sidecar render the FRMR-mapped 800-53 control split
  alongside `controls_evidenced`. The HTML report now shows the
  mapping explicitly per attestation; the JSON schema bumps to v1.1
  with `controls_mapped` + `boundary_state` fields. Empty case is
  surfaced explicitly for the 9 procedural KSIs in the FRMR catalog
  (KSI-AFR-CCM, FSI, ICP, …) that ship without any `controls` field
  — the renderer now prints "this KSI is procedural in the FRMR
  catalog (no per-control 800-53 attribution)" rather than rendering
  an unexplained blank that read as a tool bug to the 3PAO.
  Uppercase-normalized to NIST canonical form to match
  `generate_frmr_attestation`. (3PAO MEDIUM)
- **Aggregate boundary state rendered per attestation in the doc HTML**
  alongside the existing mode pill. New `AggregateBoundaryState`
  type extends the per-evidence three-valued state with two
  draft-level cases: `mixed` (cited evidence spans in/out-of-
  boundary — variance signal worth flagging by design per DECISIONS
  2026-05-04, but reviewers should see the mix) and `no_evidence`
  (procedural / not_implemented KSIs with no citations). The
  `boundary_state` field is now part of the JSON sidecar schema and
  renders as a pill ("in boundary" / "out of boundary" / "boundary
  mixed" / "boundary undeclared" / "no evidence") with title-text
  explaining each case. (3PAO MEDIUM)
- **`provenance show <evidence_id>` surfaces both `record_id` and
  `evidence_id`** when the resolved record is an Evidence record.
  The dual-key reality (envelope hash on the SQLite row vs. content
  hash inside the payload) was previously hidden behind the prefix-
  resolution banner, which confused the 3PAO trying to verify that
  POA&M citations matched what the walker walked. New output shape
  prints both lines so reviewers can match either citation form
  against the walked record. (3PAO HIGH; cli/main.py)
- **Walker leaf message disambiguated by `record_type`.** A `Claim`
  record with empty `derived_from` is legitimate when the underlying
  classification was `not_implemented` or `evidence_layer_inapplicable`
  with no cited evidence — but the bare "(leaf — no derived_from)"
  message read as a traceability break to the v0.1.10 3PAO. The
  walker now prints `(scanner-emitted leaf — Evidence is derived
  directly from source files; no further derived_from edges by
  design)` for Evidence leaves and a parallel "claim with empty
  derived_from — typical for not_implemented…; not a traceability
  break" message for Claim leaves. No semantic change — only output
  text clarification. (3PAO HIGH; provenance/walker.py)

### Tests

- Ten new regression tests pinned to the v0.1.11 fixes (DRAFT marker
  injection idempotency, `controls_mapped` inheritance through both
  agent_drafted and deterministic_template paths, empty
  `controls_mapped` for procedural KSIs, mixed boundary aggregation,
  no_evidence aggregation, dual-key CLI display, claim-leaf
  disambiguated output, HTML pill rendering, HTML procedural empty
  surfacing). Total suite at 1066 tests; CI E2E smoke gate continues
  to run on every PR.

### Changed (internal)

- `AttestationDraft.controls_mapped: list[str]` (default `[]`).
- `AttestationDraft.boundary_state: AggregateBoundaryState`
  (default `"no_evidence"`).
- Documentation report JSON schema_version 1.0 → 1.1.
- New `aggregate_boundary_state(evidence)` helper in
  `primitives.generate.generate_frmr_skeleton`.

## [0.1.10] — 2026-05-05

Detector-coverage patch closing the v0.1.5–0.1.9 carry-forward Bug A:
`aws.mfa_required_on_iam_policies` now resolves the canonical
`aws_iam_policy_document` data-source pattern. Pre-v0.1.10 every
realistic Terraform repo (most policies in production codebases come
from data sources, not literal JSON) classified KSI-IAM-MFA as
`not_implemented` even when the policies DID enforce MFA. v0.1.10
walks the data source's HCL `statement {}` / `condition {}` blocks
and reports `present` / `absent` with the same fidelity as the
literal-JSON path.

### Fixed

- **`aws.mfa_required_on_iam_policies` resolves data-source policy
  references.** When an `aws_iam_policy` (or sibling) sets `policy =
  data.aws_iam_policy_document.NAME.json`, the detector now looks up
  the matching `data "aws_iam_policy_document" "NAME"` block and walks
  its statements + conditions. Detects the HCL `condition { variable =
  "aws:MultiFactorAuthPresent" values = ["true"] }` form (camelCase /
  list-shape — different from the JSON Condition dict). Emits a new
  `resolved_via_data_source` field on the evidence content so reviewers
  can navigate back to the source statement.
- **Terraform parser emits `data` blocks alongside `resource` blocks.**
  `TerraformResource` gains a `kind: Literal["resource", "data"]`
  field (default `"resource"` for backwards compat). The parser walks
  both `parsed["resource"]` and `parsed["data"]` lists, line-tracking
  via a 3-tuple key. Detectors that iterate `r.type in {...}` keep
  working unchanged (they just see additional resources whose types
  don't match their lists). Detectors that need cross-references
  (this one; potentially future ones) opt into reading data sources
  via `r.kind == "data"`.

### Notes

- Limitations carried into v0.2 prompt-tuning territory:
  `jsonencode(...)` policies and composed `source_policy_documents`
  remain unparseable. Real-world impact is small (most teams use
  `aws_iam_policy_document`); tracked in `docs/followups.md` for
  v0.2.
- This is the first v0.1.x patch shipped through the new CI E2E smoke
  gate (PR #125, v0.1.10). Required-check posture means this PR's CI
  exercises the full pipeline before merge.

## [0.1.9] — 2026-05-05

UX + audit-credibility patch from the v0.1.8 govnotes-demo Bedrock
shakedown. Five fixes: the manifest-out-of-boundary trap, missing
token telemetry on records, `boundary set` defaulting to append (the
verb-vs-behavior surprise), uv-vs-pipx install hint mis-targeting,
and two new DECISIONS entries codifying the boundary-rationale
behavior so 3PAOs can read it explicitly.

### Fixed

- **Evidence Manifests are always in-boundary.** Customer-authored
  Evidence Manifests at `.efterlev/manifests/*.yml` can't structurally
  be out-of-scope, but pre-v0.1.9 they got swept up by tight include
  patterns (`infra/terraform/**` / `.github/workflows/**`) that didn't
  cover the manifest path. The doc-agent drafted narratives but the
  POAM silently excluded them. v0.1.9 special-cases manifest paths
  in `compute_boundary_state` so they're unconditionally `in_boundary`,
  regardless of include/exclude config. Encoding the rule is more
  honest than relying on users to remember a third include pattern
  (see DECISIONS 2026-05-05).
- **Token usage telemetry on Claim records and `receipts.log`.** The
  Anthropic SDK and Bedrock Converse both return `usage.input_tokens`
  / `usage.output_tokens` on every completion. Pre-v0.1.9 these were
  dropped — only `model` and `prompt_hash` made it to the store, so
  post-hoc cost auditing required CloudWatch / Anthropic billing
  dashboards. v0.1.9 captures usage on `LLMResponse`, plumbs it
  through every agent's `metadata` dict, and surfaces both numbers as
  top-level fields on the receipt-log JSONL line. Operators can now
  sum a run's spend with one `jq` invocation.
- **`boundary set` defaults to replace.** v0.1.0 through v0.1.8
  `boundary set` appended by default — surprising because "set" reads
  as "set, replacing what was there." v0.1.9 flips the default:
  `set` replaces; new `--append` flag opts into the old accumulating
  behavior. `--replace` is kept as a deprecated no-op so pre-v0.1.9
  scripts continue to work; surfaces a one-line deprecation note on
  stderr. Surfaced 2026-05-04.
- **Doctor + runbook detect uv vs pipx installer.** The boto3-missing
  hint pointed at `pipx inject efterlev boto3`, but `uv tool install`
  users found pipx commands silently failed against the wrong venv.
  v0.1.9 reads `sys.executable` to detect the installer (uv / pipx /
  pip), then surfaces the right fix-up command:
  `uv tool install --reinstall 'efterlev[bedrock]'` for uv users,
  `pipx install 'efterlev[bedrock]'` for pipx, `pip install` for the
  rest. README runbook Step 2b.3 also splits the install instructions
  by installer.

### Decisions

- **Manifests are always in-boundary** (DECISIONS 2026-05-05). The
  rule is encoded as a pre-config short-circuit in
  `compute_boundary_state`. Other `.efterlev/`-internal paths
  (cache, store) still follow normal config — they're machine-
  generated runtime state, not customer intent.
- **Doc-agent narratives may carry variance-signal references to OOB
  resources** (DECISIONS 2026-05-05). Narratives inherit the gap-
  rationale freedom codified 2026-05-04. The POA&M output is still
  strictly scope-filtered (items with all-OOB evidence are dropped),
  but narratives that survive into in-boundary POA&M items may name
  OOB resources for variance-signal context. Documented explicitly
  so 3PAOs see this as intended, not a leak.

### Notes

- Carry-forward bugs still observed (deferred to v0.2 prompt-tuning):
  KSI-SVC-PRR over/under-classification of CMK posture, IAM
  `aws_iam_policy_document` data-source parsing, sha256-prefix-only
  citations in 30 of 60 narratives, F5 manifest cross-wiring (PagerDuty
  quoted in AFR-FSI narrative instead of INR-RIR's). These want
  prompt iteration + a real-customer corpus.
- v0.1.8's `max_tokens=32768` Bedrock default cleanly cured the
  Sonnet 4.6 truncation in the v0.1.8 verification run.

## [0.1.8] — 2026-05-04

Release-blocker patch from the v0.1.7 govnotes shakedown. Three new
HIGH-severity bugs surfaced; v0.1.8 closes all three plus three smaller
ergonomics fixes.

### Fixed

- **Doc agent dual-emission (60 KSIs → 120 attestations).** Append-only
  store + multi-run `agent gap` (e.g. retry after a max_tokens error,
  A/B-testing prompts) accumulates one Claim per KSI per run.
  `reconstruct_classifications_from_store` returned every Claim, so
  doc-agent processed each KSI N times and emitted N attestations
  with potentially contradictory status. v0.1.8 dedups latest-wins
  (timestamp ascending order from the store, last occurrence per
  ksi_id keeps). Affects `agent document`, `agent remediate`, and
  `efterlev poam`. Each command now prints a one-line stderr note
  when dedup fired (`note: deduped N duplicate classification(s)
  from prior agent gap runs`). Pass `keep_all=True` to
  `reconstruct_classifications_from_store` for run-diffing use cases.
- **Boundary state propagation evidence→KSI on stale-evidence.**
  When the boundary is set AFTER an initial scan (or after
  `agent gap` writes classifications referencing pre-boundary
  evidence), classifications cite a mix of newer (correctly
  out_of_boundary) and older (stale boundary_undeclared) evidence.
  Pre-v0.1.8 the resolver collapsed any non-uniform mix to
  `boundary_undeclared`, leaving the POA&M filter unable to drop
  out-of-scope items. v0.1.8 treats stale-undeclared + at-least-one-
  out_of_boundary (in a workspace with a declared boundary) as
  out_of_boundary, mirroring the user's intent.
- **Configurable max_tokens with backend-aware default.** Sonnet 4.6
  on Bedrock hard-blocked by `max_tokens=20480` (set in v0.1.2 to
  duck Anthropic's 10-min streaming threshold; doesn't apply on
  Bedrock). Adds `LLMConfig.max_tokens` field; default is 20480 on
  Anthropic API, 32768 on Bedrock. Each agent's `_resolve_max_tokens`
  helper picks the right value.
- **Doctor reads AWS config-file region.** v0.1.3 doctor only checked
  env vars; users with `aws configure set region us-east-1` (writes
  to `~/.aws/config`) got false-warned "no region configured" even
  though the runtime worked. v0.1.8 mirrors boto3's full chain —
  `Session.region_name` resolves the config file alongside env.
- **`efterlev poam` always prints out-of-boundary count.** Pre-v0.1.8
  the line was conditional on `count > 0`; users couldn't tell
  whether the boundary had been considered or not. Now prints
  unconditionally; `0` is a useful signal.

### Improved

- **Runbook reality-check on plan-JSON fallback.** `terraform
  -refresh=false` doesn't always bypass `terraform { backend "s3" {} }`
  blocks; the runbook now says "drop straight to HCL if you see
  'Backend initialization required.'"
- **Runbook boundary-pattern guidance.** When users declare
  `--include 'infra/terraform/**'`, all workflow evidence becomes
  out_of_boundary because workflows aren't under that path. The
  Step 5 brief now explicitly mentions the two-pattern fix:
  `--include 'infra/terraform/**' --include '.github/workflows/**'`.

### Notes

- Agent-quality misclassifications surfaced in the v0.1.7 shakedown
  (KSI-SVC-PRR over-classifying as `evidence_layer_inapplicable`,
  KSI-MLA-LET missing retention variance, KSI-SCR-MIT mapping
  "mixed" to `not_implemented`) are tracked as v0.2 prompt-tuning
  work in `docs/followups.md` — they want a real-customer corpus to
  validate against.
- Carry-forward bugs still observed (deferred): IAM
  `aws_iam_policy_document` data-source parsing (`docs/followups.md`),
  rationales citing by sha256 hash without resource name
  (`docs/followups.md`).

## [0.1.7] — 2026-05-04

Detector-coverage + UX patch release. Closes a false-negative finding
on KSI-SCR-MON surfaced by the v0.1.6 terraform-aws-vpc / govnotes-demo
shakedown (the supply-chain-monitoring detector didn't recognize the
canonical `anchore/sbom-action`), plus a POAM artifact gap, a runbook
overhaul to halve the friction on first-run, and an explicit decision
on out-of-boundary evidence visibility.

### Fixed

- **`github.supply_chain_monitoring` recognizes modern action ecosystem**
  (false-negative on KSI-SCR-MON). The detector's action registry was
  too narrow — `anchore/sbom-action` (the canonical post-2023 SBOM
  emitter, the modern replacement for the deprecated `anchore/syft-
  action`) wasn't in the map, so workflows using it surfaced
  `sbom_tools_detected: []` and got classified as `not_implemented`.
  v0.1.7 adds: `anchore/sbom-action`, `aquasecurity/tfsec-action`,
  `step-security/harden-runner`, `google/osv-scanner-action`,
  `anchore/grype-action`, the CycloneDX language-action family
  (`gh-node-module-cyclonedx`, `gh-gomod-generate-sbom`,
  `gh-dotnet-cyclonedx`, `gh-python-generate-sbom`), and per-language
  Snyk action variants. Run-command registry adds: `cdxgen`,
  `spdx-sbom-generator` (SBOM); `dependency-check` (OWASP),
  `bundle-audit`, `govulncheck`, `trivy config` (CVE/scan).
- **POA&M markdown header surfaces out-of-boundary excluded count.**
  v0.1.4's boundary filter drops POA&M items whose cited evidence is
  entirely out-of-boundary; v0.1.5+ surfaced the count to stdout but
  the markdown body was silent on disk. v0.1.7 adds an `Excluded as
  out-of-boundary: N item(s)` bullet to the POA&M header so reviewers
  see the scope drop when reading the artifact later. Header omits
  the bullet when zero items were excluded (avoids visual clutter for
  boundary-undeclared workspaces).

### Improved

- **README AI-quickstart prompt — major UX overhaul.** Six structural
  changes informed by three rounds of real first-run shakedown reports:
  - **Step 0 (new):** repo-root verification before any scan, with a
    heuristic check (`.git/` + at least one of `.tf` or
    `.github/workflows/`) and an explicit confirm-vs-subdir prompt.
    Closes the silent 20%-coverage-loss footgun where a Terraform-only
    subdir gets named instead of the repo root.
  - **Step 1:** backend decision tree. Each option carries an explicit
    "RECOMMEND if…" rationale (credit card → Anthropic API; AWS
    already → Bedrock). Default fallback is Anthropic API since
    first-run friction differential is real.
  - **Step 2b.0 (new):** model family question (Claude / OpenAI /
    other). Honest about Claude-only support today; OpenAI + others
    on the v0.3+ roadmap.
  - **Step 2b.2:** tier picker is a recommendation (Sonnet latest) with
    concrete cost ratios, not a multiple-choice question. Opus / Haiku
    presented as overrides with use-case framing.
  - **Step 3:** `--force` is the default (manifests preserved, cache
    regenerates fresh defaults). Skip-force is the exception.
  - **Step 4:** explicit `terraform init -backend=false` fallback for
    the very-common missing-remote-state case (S3 backend, Terraform
    Cloud) — plus the throwaway-`.tfvars` fallback for missing
    required variables.
  - **Step 5:** proactive brief after gap. Reads the gap-report JSON
    and surfaces the classification breakdown, workspace boundary
    state, top 3 KSIs to focus on (biased toward SVC + IAM hot spots),
    and 2 partial KSIs flagged as best `agent remediate` targets.
    After document/poam: mode breakdown + POA&M counts.

### Decisions

- **Out-of-boundary evidence visibility codified
  (DECISIONS 2026-05-04):** the boundary filter scopes the POA&M
  output, not the gap-report rationales. Agents may cite any evidence
  in the active store when reasoning; only the POA&M renderer drops
  items whose cited evidence is entirely out of scope. The v0.1.6
  shakedown surfaced this as ambiguous (KSI-RPL-ABO citing
  out-of-boundary `dev_scratch` instances) — codifying the variance-
  signal interpretation rather than the redaction interpretation.
  See DECISIONS 2026-05-04 for the full rationale.

### Notes

- Per-classification `confidence` field on `KsiClassification` (vs the
  current hardcoded `Claim.confidence="medium"`) is tracked in
  `docs/followups.md` as v0.2 work — needs prompt-template change +
  schema bump and wants real-customer corpus to calibrate against.
- `govnotes-demo` separately ships a doc-only fix for KSI naming drift
  in DELIBERATE_GAPS.md (v0.9.43-beta uses `KSI-SVC-PRR` /
  `KSI-CNA-MAT` / `KSI-MLA-LET`, not the `CMT-CKM` / `CNA-IAS` /
  `MLA-RTN` ids the Tier 1 doc cited).

## [0.1.6] — 2026-05-04

Provenance-integrity patch release. Closes the three issues surfaced by
the v0.1.5 terraform-aws-vpc shakedown plus a v0.1.5 messaging miss.
The headline finding ("Gap Agent fabricates evidence IDs") was a
false alarm — the IDs were real `Evidence.evidence_id` values that
v0.1.5's prefix-resolver couldn't reach because it only matched
`record_id`. Fixing the resolver makes the chain walkable from any
POAM-shown prefix.

### Fixed

- **`provenance show <prefix>` resolves evidence_ids, not just
  record_ids** — POA&Ms and rationales print 8-char prefixes of
  `Evidence.evidence_id` (the content hash the model sees in fences).
  v0.1.5's `resolve_record_id_prefix` only matched against
  `provenance_records.record_id` (the envelope hash). Pasting a
  POAM-shown prefix returned "no record matches" even though the full
  evidence_id walked correctly. Extends the resolver with a Step 2
  payload-scan that mirrors `resolve_to_record`'s dual-key lookup,
  with collision detection across both id spaces.
- **POA&M output lands under `.efterlev/reports/poam/`** — pre-v0.1.6
  wrote flat `.efterlev/reports/poam-<ts>.md`, but the runbook docs
  pointed at the subdir form. Aligns the writer with the docs and
  clusters per-report-type artifacts. Pass `--output` to override.
- **Plan-JSON trade-off note also fires when `--plan` IS used** —
  v0.1.5 added the line-numbers caveat but only in the
  recommend-plan-JSON branch. Users who were already in plan-JSON
  mode never saw the explanation for their `source_lines: null`
  citations. Now prints the trade-off any time plan-JSON is in use.
- **GitHub-workflow detectors emit file-level line ranges instead of
  null** — workflow files are conceptually single units (one Evidence
  per file), but v0.1.5 left `source_ref.line_start`/`line_end`
  as None, making the audit trail unnecessarily weak. v0.1.6 sets
  `line_start=1, line_end=<file_total_lines>`. Per-step line
  numbers (e.g. `uses:` step lines) are tracked as a v0.2 enhancement.
- **`provenance verify` adds derived_from referential-integrity
  check** — pre-v0.1.6 only verified blob hashes match content_refs.
  Now also walks every record's envelope `derived_from` and confirms
  each cited id resolves via the dual-key path. Catches anything
  that ever bypasses the write-time validator (future tooling, manual
  DB writes, migrations).

## [0.1.5] — 2026-05-03

Honesty-and-ergonomics patch release. Closes three issues surfaced by
the v0.1.4 fully-private-cluster shakedown: a CLI dead-end, a misleading
metadata field, and a marketing claim that didn't survive contact with
plan-JSON mode.

### Fixed

- **`provenance show` accepts truncated SHA prefixes** — POA&Ms,
  rationales, and attestation report tables print 8-char prefixes for
  readability, and users naturally pasted those into `provenance show`
  expecting them to resolve. Earlier versions matched only the full
  64-hex form, so the prefix was a dead end. Now the CLI prefix-resolves
  via `record_id LIKE 'sha256:<prefix>%'` and prints the resolution
  banner (`resolved sha256:81fffc53 → sha256:81fffc53...full`). Refuses
  prefixes shorter than 4 hex chars (collision risk) and raises
  `ProvenanceError` on prefix collisions instead of silently picking the
  first match.
- **Attestation `mode` field stops lying about deterministic
  narratives** — v0.1.4 introduced a no-LLM template path for
  `evidence_layer_inapplicable` KSIs, but kept stamping the resulting
  drafts as `mode="agent_drafted"`. That hid the cost-saving from
  reviewers AND broke the field's contract as a "what produced this
  prose?" signal — downstream tooling could no longer tell template-
  filled entries apart from LLM-drafted ones. Adds a third literal
  `deterministic_template` to `AttestationMode` and threads it through
  the artifact serializer, the JSON sidecar (`mode` field), and the
  HTML report (a new mode-pill badge alongside the status pill).
- **README + scan output drop the "cited source lines" claim on
  plan-JSON mode** — `terraform show -json` output doesn't preserve HCL
  line numbers, so plan-JSON Evidence records carry `source_lines:
  null` on every citation. The README, the AI-quickstart prompt, and
  the scan-mode-recommendation message now state the trade-off
  explicitly ("plan-JSON gives full module coverage but citations land
  at file-level only until line recovery lands in v0.2"). Line recovery
  is tracked in `docs/followups.md` as the leading v0.2.0 item.

## [0.1.4] — 2026-05-01

First-run UX patch release. Closes the friction items surfaced by a real
v0.1.3 Bedrock first-run report against govnotes-demo. Each fix maps to
a specific report number; bundled so the next first-run is dramatically
quieter and cheaper.

### Fixed

- **`agent document` runs deterministic narratives on
  `evidence_layer_inapplicable` KSIs by default** (report #5). On a
  typical 60-KSI baseline, 25-45 KSIs are procedural-only — earlier
  versions generated full Sonnet narratives for each that were
  essentially boilerplate ("scanner cannot evidence; reviewer must
  corroborate procedurally"). Now those entries get a deterministic
  narrative built from the Gap Agent's already-produced rationale + the
  KSI's underlying 800-53 controls, with no LLM call. The FRMR
  attestation completeness is preserved — all 60 KSIs still get an
  entry. Pass `--include-inapplicable-narratives` to opt back into
  LLM-drafted prose for these. **Saves ~70% of Sonnet spend on
  documentation runs.**
- **`doctor` warns when boundary scope is undeclared** (report #3).
  Earlier doctor runs reported "5 pass, 0 warn, 0 fail" while the gap
  report header showed `workspace_boundary_state: boundary_undeclared`.
  Now reads `[boundary]` from `.efterlev/config.toml` and surfaces a
  warn-level check with a remediation hint pointing at
  `efterlev boundary set --include 'boundary/**'`. The check is
  informational; running outside a formal authorization boundary stays
  permitted.
- **SHA256 record-ID dumps moved behind `--verbose`** (report #6) on
  `efterlev scan` and `efterlev agent gap`. Default output now prints
  a one-line summary ("N record(s) written to .efterlev/store.db; pass
  --verbose..."). Forensics still available; first-time users no longer
  get a flood of hashes.
- **Absolute paths for printed report files** (report #7). `efterlev
  scan`, `agent gap`, `agent document`, `agent remediate`, and
  `report diff` all now print fully-resolved paths for HTML/JSON
  outputs. Earlier mix of relative and absolute (within the same
  block on `agent document`) is fixed.
- **"Next steps" footers** on `agent gap` and `agent document` outputs
  (report #8). Each surfaces the right follow-on commands with their
  typical cost — `agent document`, `poam`, `agent remediate --ksi <id>`.
- **`init` creates `.efterlev/manifests/` with a README** (report #10)
  on first run. Earlier versions created the directory lazily (only
  when a manifest was loaded), leaving the gap between docs ("commit
  manifests under `.efterlev/manifests/`") and on-disk state unbridged.
  README inside the new dir explains the format with a worked example.
- **README AI-quickstart prompt clarifies "repo root" vs "Terraform
  path"** — silent root cause of the prior shakedown's two anomalies
  (3 manifests not loading, 4 GitHub-workflow detectors not firing,
  ~20% of detector coverage disappeared). Repo-root scoping is now
  explicit with a one-paragraph note on what subdir-scoping skips.

### Notes

- Cost-summary at end of agent runs (report #4) and `--llm-tier=opus|
  sonnet|haiku` shorthand for Bedrock (report #9) are tracked as
  v0.2.0 features in `docs/followups.md` — both want token-counting
  + price-model design that's bigger than a patch release.
- terraform-init-failure → cleaner scan-mode message (report #2)
  tracked in followups.

## [0.1.3] — 2026-04-30

Patch release closing the Bedrock-onboarding cliff surfaced in a real
first-run test against AWS Bedrock (`us-east-1`). Each fix matches a
reproducible failure mode the user hit; bundled to ship together so a
single `pipx install efterlev[bedrock]` works end-to-end.

### Fixed

- **Bedrock client used the boto3 default 60s read_timeout.** Gap Agent
  prompts (60 KSIs × ~75 evidence records) routinely take longer on
  Opus 4.7. Three retries multiplied 60s into ~3× wasted cost before
  surfacing failure. Now sets `read_timeout=600`, `connect_timeout=10`,
  and `retries={"max_attempts": 1}` on the boto client (Efterlev has
  its own retry loop; the boto layer's was redundant).
- **Agents crashed when LLMs wrapped output in ` ```json ` fences.**
  Opus 4.6 (and occasionally Sonnet 4.6 on Bedrock) wraps structured
  output in markdown fences despite system-prompt instructions to
  return raw JSON. Added defensive fence-stripping before
  `json.loads` in `agents/base.py._invoke_llm`.
- **`init --llm-backend=bedrock` defaulted to a model ID that doesn't
  exist in most accounts.** v0.1.x had `us.anthropic.claude-opus-4-7-v1:0`
  hardcoded. Now probes the user's account via
  `bedrock.list_inference_profiles(typeEquals="SYSTEM_DEFINED")` and
  picks the latest available Anthropic Opus profile when `--llm-model`
  isn't passed. Falls back to the hardcoded default with a clear warning
  when the probe fails (no perms, no boto, no profiles).
- **`doctor` only checked AWS credentials in env vars,** false-warning
  users whose creds came from `~/.aws/credentials`, `AWS_PROFILE`, IMDS,
  or SSO. Now uses `boto3.Session().get_credentials()` (the full
  credential chain) — matches what the runtime client actually consults.
- **`doctor` now pings `InvokeModel` end-to-end** when the workspace is
  configured for Bedrock. 1-token throwaway prompt validates that the
  configured model is reachable, the credentials work, and access is
  granted — catches stale defaults, missing inference-profile access,
  and expired SSO sessions before the user spends API budget on a
  doomed agent run.
- **`doctor`'s ANTHROPIC_API_KEY check skips when backend is bedrock.**
  Earlier versions warned about a missing key on workspaces where the
  key is irrelevant.

### Notes

- Streaming refactor of the Anthropic clients (deferred from v0.1.2)
  remains queued for v0.2.0. The Bedrock-side `read_timeout=600` makes
  long completions practical without it; the structural fix is still
  the right destination.

## [0.1.2] — 2026-04-30

Patch release closing two real-CI bugs surfaced by the govnotes-demo
deep-dive shakedown — the canonical Evidence Manifest pattern (commit
manifests, gitignore cache) didn't survive a fresh clone, and v0.1.1's
bumped `max_tokens=32768` tripped Anthropic's streaming-required
threshold and prevented the gap agent from running at all.

### Fixed

- **`report run` skipped init when `.efterlev/manifests/` was the only
  thing in the workspace dir.** The detection looked at the dir, not
  the FRMR cache file scan needs. Fresh clones with manifests
  committed but the cache gitignored hit "FRMR cache missing"
  immediately. `report run` now detects the cache (the actual
  artifact) and passes `--force` to its sub-init step when the dir
  exists but the cache is missing — regenerates cache + provenance
  store while preserving customer-authored manifests. Regression
  test added.
- **Gap Agent `max_tokens=32768` raised "streaming required" on real
  workloads.** Anthropic's `messages.create()` (non-streaming) path
  rejects requests whose `max_tokens` could plausibly take >10
  minutes. Reduced to **20480** — enough headroom over the v0.1.0
  truncation site (~16384) for the full 60-KSI baseline with
  substantive rationales, but well below the streaming threshold.
  If real workloads need more, the right move is the streaming
  refactor (`client.messages.stream()`), not chasing the cap.
- **README + CLAUDE.md test count drift** (1019 → 1020 after PR #104
  added a regression test for the half-init pattern).

### Notes

- Streaming refactor of the Anthropic client is queued as a
  v0.2.0-targeted item — the right structural fix when output budget
  needs to grow further. The fake-client surface in
  `tests/test_anthropic_retry_fallback.py` would need rewiring for a
  streaming context manager.

## [0.1.1] — 2026-04-29

Patch release closing three v0.1.0 bugs surfaced in a deep-dive shakedown
test against `terraform-aws-modules/terraform-aws-iam` and a synthetic
ground-truth target.

### Fixed

- **Gap Agent `max_tokens` truncation.** The cap was 16384, which truncated
  mid-JSON on real-world full-baseline runs (60 KSIs each with substantive
  rationales). Bumped to 32768 — Claude Opus 4.7's output ceiling. The
  agent's own error message ("increase the max_tokens argument") is now
  acted on; full-baseline runs complete without truncation.
- **Confusing LLM-invocation transcript record.** `agents.base._invoke_llm`
  used to write a per-run transcript record with `record_type="claim"`,
  payload `{user_message, response_text, parsed}`, and empty `derived_from`.
  It looked like a malformed Claim to anyone listing claim records or
  walking provenance — and triggered tester confusion about whether the
  retry path was corrupting state. Removed; per-claim records (per KSI for
  Gap, per narrative for Documentation, per remediation for Remediation)
  already carry `model`, `prompt_hash`, and properly-populated
  `derived_from`. No information loss.
- **`efterlev --version` reported stale `0.0.1` from the published 0.1.0
  wheel.** `pyproject.toml` had a version literal `"0.1.0"` while
  `src/efterlev/__init__.py` had `__version__ = "0.0.1"` — two sources of
  truth, drifted. Switched to hatch dynamic versioning
  (`[tool.hatch.version] path = "src/efterlev/__init__.py"`) so pyproject
  reads from the source file. Added a CI-time regression test
  (`test_in_source_version_matches_package_metadata`) so future drift is
  caught before release.

### Notes

- Bug #5 from the shakedown report (gap/remediate disagreement on
  KSI-AFR-UCM scope: gap classified `partial` citing FIPS-TLS evidence, but
  remediate refused with "no Terraform surface to remediate") deferred to
  `docs/followups.md`. Root cause is design-level: the Gap Agent has
  freedom to cite any prompt-visible Evidence in its rationale, while
  remediate's CLI gate strictly filters by `Evidence.ksis_evidenced`. The
  fix needs a design call between trusting the Gap Agent's citations vs.
  enforcing detector-level KSI mapping at remediate time. Not a regression;
  present in v0.1.0.
- Prompt-tuning concerns from the shakedown (systematic leniency, rationale
  reuse across thematically-adjacent KSIs) are v0.2.0 work — they want a
  real-customer evidence corpus to tune against rather than synthetic
  dogfood.

## [0.1.0] — 2026-04-29

First public release. The work in this section closes Priorities 1, 2,
and 3 of `docs/v1-readiness-plan.md` plus the post-launch-prep
walkback / audit / new-detector arc. 51 PRs landed 2026-04-27 →
2026-04-29 (#36 → #96).

### Priority 1 — Detector breadth (✅ complete; lifted post-floor)

Coverage moved from 14 → 31 KSIs / 5 → 8 themes / 38 → 45 detectors.
The plan's ≥30 KSI / ≥8 theme floor was reached at PR #51; post-walkback
work (PRs #88, #89, #92) lifted coverage to 31 / 8 / 45.

- **Added detectors:**
  - `aws.terraform_inventory` — KSI-PIY-GIV (PR #39)
  - `aws.s3_lifecycle_policies` — KSI-SVC-RUD (PR #40)
  - `aws.federated_identity_providers` — KSI-IAM-APM (PR #41)
  - `aws.iam_managed_via_terraform` — KSI-IAM-AAM (PR #42)
  - `aws.cloudfront_viewer_protocol_https` — KSI-SVC-VCM (PR #47)
  - `aws.ec2_imdsv2_required` — KSI-CNA-IBP (PR #48); cross-mapped to KSI-CNA-DFP via CM-2 (PR #51)
  - `aws.backup_restore_testing` — KSI-RPL-TRC (PR #49)
  - `aws.suspicious_activity_response` — KSI-IAM-SUS (PR #50)
  - `aws.vpc_logical_segmentation` — KSI-CNA-ULN (PR #36)
  - `github.ci_validation_gates` — KSI-CMT-VTD (PR #37)
  - `github.supply_chain_monitoring` — KSI-SCR-MON (PR #38)
  - `github.immutable_deploy_patterns` — KSI-CMT-RMV (PR #44)
  - `github.action_pinning` — KSI-SCR-MIT (PR #46)

- **Cross-mappings** (existing detectors gained additional KSI attributions
  via FRMR control overlap, not invented attribution):
  - `aws.cloudtrail_audit_logging` → +KSI-CMT-LMC via AU-2 (PR #43)
  - `aws.iam_admin_policy_usage`, `aws.iam_inline_policies_audit` → +KSI-IAM-JIT via AC-6 (PR #45)
  - `aws.ec2_imdsv2_required` → +KSI-CNA-DFP via CM-2 (PR #51)

### Priority 2 — HTML report overhaul (✅ complete)

All 9 acceptance items closed. 11 PRs (#52 → #62 + #63 doc).

- **JSON sidecars on all 3 reports** — `gap-{ts}.json`, `documentation-{ts}.json`,
  `remediation-{ksi}-{ts}.json`. Schema-versioned; suitable for tool integration.
  PRs #52, #53, #54.
- **Coverage matrix** — single-page heatmap of all 11 themes × 60 KSIs at the
  top of the gap report. KSIs the agent didn't classify render as `unclassified`.
  Click any cell to scroll to the per-KSI classification card. PR #55.
- **Filter by status** — single-click pills above the classification list.
  Inline vanilla JS, no framework. PR #56.
- **Free-text search** — debounced input, live match count, additive with
  the status filter. PR #57.
- **Print stylesheet** — interactive bits hide; cards don't split across
  pages; out-of-boundary `<details>` expand on paper. PR #58.
- **Sort controls** — by KSI / severity / evidence count. PR #59.
- **Drill-down** — per-classification `<details>` listing each cited
  evidence's `source_file:line_range`. JSON sidecar gains
  `cited_evidence_refs[]`. PR #60.
- **Diff view** — `efterlev report diff PRIOR CURRENT` writes both
  `gap-diff-{ts}.html` and `gap-diff-{ts}.json`. CI-gateable: exits 2 on
  regression. PRs #61 (compute), #62 (CLI + HTML).

All Priority-2 features are self-contained (no external CDN, no fonts beyond
system-default, no analytics) and degrade gracefully without JavaScript
(filter/sort show all results in input order).

### Post-launch-prep walkback + audit (✅ complete)

Triggered by AWS's 2026-04-27 FedRAMP 20x deep-dive blog and a
maintainer review pass. 12 PRs landed 2026-04-28 → 2026-04-29
(#80 → #92), plus the dependency unblock #93.

**Detector additions:**
- `aws.nacl_restrictiveness` — KSI-CNA-RNT (PR #88). Per-NACL
  posture summary (restrictive / partially_restrictive / permissive
  / empty); emits Evidence even on clean NACLs so positive evidence
  flows to the Gap Agent.
- `aws.centralized_log_aggregation` — KSI-MLA-OSM (PR #89). Workspace-
  scoped summary of log producers + aggregators; closes the
  "no SIEM aggregation primitives visible" agent narrative gap.

**Detector reclassifications:**
- `aws.iam_user_access_keys` (PR #92): primary mapping
  KSI-IAM-MFA → **KSI-IAM-SNU** (Securing Non-User Authentication);
  KSI-IAM-MFA preserved as cross-mapping. Adds KSI-IAM-SNU to the
  covered set (30 → 31 KSIs).

**Mapping audits + partial-coverage discipline:**
- PR #83: SVC-RUD and SVC-VCM downgraded to partial cross-mappings
  with explicit notes (scheduled-vs-on-request, viewer-edge-vs-S2S).
- PR #91: 6 detectors gained explicit `coverage: partial` notes
  (cloudtrail_log_file_validation, cloudwatch_alarms_critical,
  guardduty_enabled, elb_access_logs, vpc_flow_logs_enabled,
  access_analyzer_enabled).
- PR #90: systematic audit of all 34 remaining KSI-mapped detectors
  (`docs/detector-mapping-audit.md`). 23 direct fits, 9 partial
  cross-mappings, 2 reclassification candidates.

**Real bug fixes:**
- PR #82: FRMR loader now reads `varies_by_level.{level}.statement`
  with fallback to top-level. 5 KSIs (KSI-CNA-EIS, KSI-MLA-ALA,
  KSI-SVC-PRR, KSI-SVC-RUD, KSI-SVC-VCM) were silently statement-
  less; the Gap Agent had been classifying them blind.
- PR #81: report path display uses the user-supplied form (e.g.
  `/tmp/...`) instead of canonical (`/private/tmp/...`); macOS
  symlink paper-cut surfaced by a real local run.

**CSX-SUM / CSX-ORD gap closures:**
- PR #84: `validation_cadence` field added to documentation artifact
  (closes the CSX-SUM cadence-field-gap acknowledged in csx-mapping.md).
- PR #85: `efterlev poam --sort csx-ord` mode (closes the CSX-ORD
  prescribed-sequence-sort gap).

**Init-time UX:**
- PR #86: catalog freshness warning at `efterlev init` (180-day
  staleness + post-CR26-window heuristics).

**Framing walkback:**
- PR #80: walked back overclaims in csx-mapping.md / aws-coexistence.md
  / release-notes-v0.1.0-draft.md / README.md / aws-ksi-blog-analysis.md.
  "shaped to satisfy CSX-SUM" instead of "IS the artifact 3PAOs
  consume" (pending Priority 5 empirical validation).

**Documentation + upstream:**
- PR #87: drafts of two FRMR upstream feedback issues (file post-tag).
- PR #93: pathspec upper bound widened `<1` → `<2` to unblock
  Dependabot resolver.

**Dependabot bulk-merge:**
- 7 minor/major version bumps merged (#3, #4, #5, #6, #7, #9, #10).
  Python 3.14 (#2) and mypy 1.20 (#8) deferred to v0.1.x.

### Priority 3 — UX during install and usage (✅ complete)

All 6 acceptance items closed. 6 PRs (#64 → #69 + #70 doc).

- **`efterlev doctor`** — five pre-flight checks (Python, .efterlev workspace,
  FRMR cache freshness, ANTHROPIC_API_KEY shape, AWS Bedrock credentials)
  with per-check pass/warn/fail and remediation hints. No network calls.
  PR #64.
- **Friendly errors** — all 8 typed `anthropic.APIError` subclasses mapped to
  one-line messages + remediation hints at the agent CLI boundary. PR #65.
- **`efterlev report run`** — one-command pipeline (init → scan → agent gap
  → agent document → poam) with per-stage `--skip-*` flags. PR #66.
- **First-run wizard** — TTY-gated, credential-aware intro at `efterlev init`.
  Auto-skips on non-TTY (CI-safe); never modifies config silently. PR #67.
- **Progress indicators** — Documentation Agent emits
  `[idx/total] KSI-XXX ✓` per narrative to stderr. PR #68.
- **`--watch` mode** — `efterlev report run --watch` polls the target for
  `.tf`/`.tfvars`/`.yml`/`.yaml`/`.json` changes (debounced 2s) and re-runs
  the pipeline. Polling-based, no `watchdog` dependency. PR #69.

### Catalog stats (post-session)

- 1018 tests passing
- 172 source files
- 24 CLI commands
- 45 detectors (38 KSI-mapped + 7 supplementary 800-53-only)
- 31 KSIs covered across 8 themes
- mypy strict / ruff check / ruff format clean

### Documentation

- `docs/v1-readiness-plan.md` updated to mark Priorities 1, 2, 3 complete
  with PR pointers per acceptance item (PRs #51, #63, #70).

### Out of scope this session

- Priority 4 (boundary scoping): already shipped pre-session.
- Priority 5 (real customer dogfood + 3PAO touchpoint): calendar-time
  work outside the code surface — needs maintainer outreach.
- Priority 6 (honesty pass on `ksis=[]` detectors): already done
  pre-session.

The remaining gates to v0.1.0 are: maintainer security-review §8 sign-off,
24-hour fresh-eyes pause, optional GovCloud walkthrough, then `git push
origin v0.1.0`.
