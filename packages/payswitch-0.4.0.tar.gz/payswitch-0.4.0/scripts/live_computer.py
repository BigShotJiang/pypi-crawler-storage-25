"""Keep a visible Pay-Switch browser session alive on the noVNC display."""

from __future__ import annotations

import asyncio
import os
import signal
from pathlib import Path

from payswitch.browser.controller import BrowserController


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() not in {"0", "false", "no", "off"}


async def main() -> None:
    display = os.getenv("PAYSWITCH_DISPLAY") or os.getenv("DISPLAY") or ":99"
    url = os.getenv("PAYSWITCH_LIVE_URL", "http://127.0.0.1:8787/")
    profile_dir = Path(
        os.getenv(
            "PAYSWITCH_LIVE_PROFILE",
            str(Path.home() / ".payswitch" / "profiles" / "live-computer"),
        )
    )
    engine = os.getenv("PAYSWITCH_BROWSER_ENGINE", "cloakbrowser")
    humanize = _env_bool("PAYSWITCH_BROWSER_HUMANIZE", True)
    human_preset = os.getenv("PAYSWITCH_BROWSER_HUMAN_PRESET", "careful")

    controller = BrowserController()
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:
            pass

    await controller.launch(
        profile_dir=profile_dir,
        headless=False,
        display=display,
        engine=engine,
        humanize=humanize,
        human_preset=human_preset,
    )
    await controller.navigate(url)
    print(
        f"Pay-Switch live computer is open: display={display} "
        f"engine={engine} humanize={humanize} url={url}",
        flush=True,
    )

    try:
        await stop.wait()
    finally:
        await controller.close()


if __name__ == "__main__":
    asyncio.run(main())
