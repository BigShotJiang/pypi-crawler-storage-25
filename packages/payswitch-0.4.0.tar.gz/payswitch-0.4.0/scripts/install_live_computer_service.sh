#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SYSTEMD_USER_DIR="${HOME}/.config/systemd/user"
SERVICE_PATH="${SYSTEMD_USER_DIR}/payswitch-live-computer.service"
ENV_FILE="${PAYSWITCH_ENV_FILE:-$HOME/.payswitch/server.env}"
PORT="${PAYSWITCH_PORT:-8787}"
ENABLE_STANDBY_BROWSER="${PAYSWITCH_ENABLE_STANDBY_BROWSER:-false}"

mkdir -p "${SYSTEMD_USER_DIR}"
mkdir -p "$(dirname "${ENV_FILE}")"
touch "${ENV_FILE}"
chmod 600 "${ENV_FILE}"

cat >"${SERVICE_PATH}" <<EOF
[Unit]
Description=Pay-Switch live computer browser (CloakBrowser on noVNC display)
After=payswitch-display.service payswitch-agent.service
Wants=payswitch-display.service payswitch-agent.service

[Service]
Type=simple
WorkingDirectory=${ROOT_DIR}
EnvironmentFile=${ENV_FILE}
Environment=PAYSWITCH_BROWSER_ENGINE=cloakbrowser
Environment=PAYSWITCH_BROWSER_HUMANIZE=true
Environment=PAYSWITCH_BROWSER_HUMAN_PRESET=careful
Environment=PAYSWITCH_LIVE_URL=http://127.0.0.1:${PORT}/
ExecStart=${ROOT_DIR}/.venv/bin/python ${ROOT_DIR}/scripts/live_computer.py
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
if [[ "${ENABLE_STANDBY_BROWSER}" == "1" || "${ENABLE_STANDBY_BROWSER}" == "true" ]]; then
  systemctl --user enable --now payswitch-live-computer.service
  systemctl --user restart payswitch-live-computer.service
  echo "Installed and started ${SERVICE_PATH}"
  systemctl --user --no-pager --full status payswitch-live-computer.service
else
  systemctl --user disable --now payswitch-live-computer.service 2>/dev/null || true
  echo "Installed ${SERVICE_PATH}, but standby browser is disabled."
  echo "Set PAYSWITCH_ENABLE_STANDBY_BROWSER=true to keep a placeholder browser open."
fi
