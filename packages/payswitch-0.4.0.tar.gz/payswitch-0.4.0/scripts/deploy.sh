#!/usr/bin/env bash
# payswitch 云端服务部署脚本
#
# 在服务器上执行: bash scripts/deploy.sh
# 前提: 已通过 SSH 登录服务器，项目代码已 clone

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

echo "=== payswitch 云端服务部署 ==="
echo "项目目录: $PROJECT_DIR"
echo ""

# 1. 拉取最新代码
echo "[1/5] 拉取最新代码..."
git pull --rebase || { echo "git pull 失败"; exit 1; }

# 2. 构建沙箱镜像
echo "[2/5] 构建浏览器沙箱镜像..."
docker build -f server/Dockerfile -t payswitch-sandbox:latest . || {
    echo "沙箱镜像构建失败"
    exit 1
}

# 3. 创建 Docker 网络（如果不存在）
echo "[3/5] 确保 Docker 网络存在..."
docker network create payswitch-net 2>/dev/null || true

# 4. 启动服务
echo "[4/5] 启动 Redis + API Server..."
docker compose up -d redis payswitch-server

# 5. 等待服务就绪
echo "[5/5] 等待服务就绪..."
BASE_URL="${PAYSWITCH_BASE_URL:-http://localhost:8000}"
MAX_RETRIES=30
for i in $(seq 1 $MAX_RETRIES); do
    if curl -sf "$BASE_URL/health" > /dev/null 2>&1; then
        echo ""
        echo "=== 部署成功 ==="
        curl -s "$BASE_URL/health" | python3 -m json.tool 2>/dev/null || curl -s "$BASE_URL/health"
        echo ""
        docker compose ps
        exit 0
    fi
    printf "."
    sleep 1
done

echo ""
echo "=== 部署失败: 服务未在 ${MAX_RETRIES}s 内就绪 ==="
docker compose logs --tail=50 payswitch-server
exit 1
