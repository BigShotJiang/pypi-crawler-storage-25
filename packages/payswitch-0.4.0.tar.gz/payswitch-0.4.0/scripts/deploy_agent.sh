#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${PAYSWITCH_ROOT:-/home/bobo/payswitch}"
PORT="${PAYSWITCH_PORT:-8787}"
HOST="${PAYSWITCH_HOST:-0.0.0.0}"
ENV_FILE="${PAYSWITCH_ENV_FILE:-$HOME/.payswitch/server.env}"
SERVICE_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SERVICE_DIR/payswitch-agent.service"

ensure_env_line() {
  local key="$1"
  local value="$2"
  if ! grep -q "^${key}=" "$ENV_FILE" 2>/dev/null; then
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
  fi
}

cd "$ROOT_DIR"

python3 -m venv .venv
".venv/bin/pip" install --upgrade pip
".venv/bin/pip" install -e ".[smart,stripe,remote]"

if [ -d frontend ]; then
  (cd frontend && npm ci && npm run build)
fi

mkdir -p "$(dirname "$ENV_FILE")"
if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<EOF
PAYSWITCH_HOST=$HOST
PAYSWITCH_PORT=$PORT
PAYSWITCH_AGENT_TOKEN=psw_$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(32))
PY
)
PAYSWITCH_AI_PROVIDER=${PAYSWITCH_AI_PROVIDER:-github}
PAYSWITCH_AI_MODEL=${PAYSWITCH_AI_MODEL:-openai/gpt-4o-mini}
PAYSWITCH_FRONTEND_DIST=$ROOT_DIR/frontend/dist
EOF
fi

ensure_env_line DISPLAY "${DISPLAY:-:99}"
ensure_env_line PAYSWITCH_DISPLAY "${PAYSWITCH_DISPLAY:-:99}"
ensure_env_line PAYSWITCH_NOVNC_HOST "${PAYSWITCH_NOVNC_HOST:-0.0.0.0}"
ensure_env_line PAYSWITCH_NOVNC_PORT "${PAYSWITCH_NOVNC_PORT:-6080}"
ensure_env_line PAYSWITCH_NOVNC_WEB "${PAYSWITCH_NOVNC_WEB:-/usr/share/novnc}"
ensure_env_line PAYSWITCH_FRONTEND_DIST "$ROOT_DIR/frontend/dist"

chmod 600 "$ENV_FILE"
chmod +x "$ROOT_DIR/bin/payswitch-agent"

mkdir -p "$SERVICE_DIR"
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Pay-Switch Agent HTTP/A2A service
After=network-online.target

[Service]
Type=simple
WorkingDirectory=$ROOT_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$ROOT_DIR/.venv/bin/python -m payswitch.cli serve --host $HOST --port $PORT
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable --now payswitch-agent.service
systemctl --user --no-pager status payswitch-agent.service
