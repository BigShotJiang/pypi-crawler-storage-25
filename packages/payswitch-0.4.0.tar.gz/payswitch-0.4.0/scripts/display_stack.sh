#!/usr/bin/env bash
set -euo pipefail

DISPLAY_ID="${PAYSWITCH_DISPLAY:-:99}"
SCREEN_SIZE="${PAYSWITCH_SCREEN_SIZE:-1440x900x24}"
VNC_PORT="${PAYSWITCH_VNC_PORT:-5900}"
NOVNC_HOST="${PAYSWITCH_NOVNC_HOST:-0.0.0.0}"
NOVNC_PORT="${PAYSWITCH_NOVNC_PORT:-6080}"
NOVNC_WEB="${PAYSWITCH_NOVNC_WEB:-/usr/share/novnc}"

cleanup() {
  jobs -pr | xargs -r kill 2>/dev/null || true
}
trap cleanup EXIT INT TERM

if [ -e "/tmp/.X${DISPLAY_ID#:}-lock" ] && ! pgrep -f "Xvfb ${DISPLAY_ID}" >/dev/null; then
  rm -f "/tmp/.X${DISPLAY_ID#:}-lock"
fi

echo "[display] starting Xvfb ${DISPLAY_ID} (${SCREEN_SIZE})"
Xvfb "${DISPLAY_ID}" -screen 0 "${SCREEN_SIZE}" -ac +extension GLX +render -noreset &
sleep 1

export DISPLAY="${DISPLAY_ID}"
echo "[display] starting openbox"
openbox >/tmp/payswitch-openbox.log 2>&1 &
sleep 1

echo "[display] starting x11vnc on ${VNC_PORT}"
x11vnc -display "${DISPLAY_ID}" -forever -shared -nopw -rfbport "${VNC_PORT}" -quiet &
sleep 1

echo "[display] starting noVNC on ${NOVNC_HOST}:${NOVNC_PORT}"
exec websockify --web "${NOVNC_WEB}" "${NOVNC_HOST}:${NOVNC_PORT}" "localhost:${VNC_PORT}"
