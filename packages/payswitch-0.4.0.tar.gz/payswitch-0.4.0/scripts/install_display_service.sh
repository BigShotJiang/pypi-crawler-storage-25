#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${PAYSWITCH_ROOT:-/home/bobo/payswitch}"
SERVICE_DIR="$HOME/.config/systemd/user"
SERVICE_FILE="$SERVICE_DIR/payswitch-display.service"
ENV_FILE="${PAYSWITCH_ENV_FILE:-$HOME/.payswitch/server.env}"

ensure_env_line() {
  local key="$1"
  local value="$2"
  if ! grep -q "^${key}=" "$ENV_FILE" 2>/dev/null; then
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
  fi
}

mkdir -p "$SERVICE_DIR"
mkdir -p "$(dirname "$ENV_FILE")"
touch "$ENV_FILE"
ensure_env_line DISPLAY "${DISPLAY:-:99}"
ensure_env_line PAYSWITCH_DISPLAY "${PAYSWITCH_DISPLAY:-:99}"
ensure_env_line PAYSWITCH_NOVNC_HOST "${PAYSWITCH_NOVNC_HOST:-0.0.0.0}"
ensure_env_line PAYSWITCH_NOVNC_PORT "${PAYSWITCH_NOVNC_PORT:-6080}"
ensure_env_line PAYSWITCH_NOVNC_WEB "${PAYSWITCH_NOVNC_WEB:-/usr/share/novnc}"
chmod 600 "$ENV_FILE"
chmod +x "$ROOT_DIR/scripts/display_stack.sh"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Pay-Switch live computer display (Xvfb + x11vnc + noVNC)
After=network-online.target

[Service]
Type=simple
WorkingDirectory=$ROOT_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$ROOT_DIR/scripts/display_stack.sh
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable --now payswitch-display.service
systemctl --user restart payswitch-display.service
systemctl --user --no-pager status payswitch-display.service
