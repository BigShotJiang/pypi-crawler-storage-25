#!/usr/bin/env bash
# payswitch 云端服务冒烟测试
#
# 用法: bash scripts/smoke_test.sh [BASE_URL]
# 默认: http://localhost:8000

set -euo pipefail

BASE_URL="${1:-${PAYSWITCH_BASE_URL:-http://localhost:8000}}"
PASS=0
FAIL=0
TASK_ID="smoke-test-$(date +%s)"

pass() { echo "  ✅ $1"; PASS=$((PASS + 1)); }
fail() { echo "  ❌ $1"; FAIL=$((FAIL + 1)); }

echo "=== payswitch 冒烟测试 ==="
echo "目标: $BASE_URL"
echo ""

# 1. 健康检查
echo "[1/6] 健康检查..."
HEALTH=$(curl -sf "$BASE_URL/health" 2>/dev/null)
if echo "$HEALTH" | grep -q '"status":"ok"'; then
    pass "GET /health 正常"
else
    fail "GET /health 失败: $HEALTH"
fi

# 2. 提交测试任务
echo "[2/6] 提交任务..."
TASK_RESP=$(curl -sf -X POST "$BASE_URL/task" \
    -H "Content-Type: application/json" \
    -d "{\"task_id\": \"$TASK_ID\", \"card_alias\": \"test-card\", \"url\": \"https://example.com\", \"max_amount\": 10.0}" \
    2>/dev/null || echo "FAILED")

if echo "$TASK_RESP" | grep -qE '"(submitted|failed)"'; then
    pass "POST /task 响应正常"
else
    fail "POST /task 响应异常: $TASK_RESP"
fi

# 3. 查询任务状态
echo "[3/6] 查询状态..."
STATUS_RESP=$(curl -sf "$BASE_URL/task/$TASK_ID" 2>/dev/null || echo "FAILED")
if echo "$STATUS_RESP" | grep -qE '"task_id"'; then
    pass "GET /task/{id} 正常"
else
    fail "GET /task/{id} 失败: $STATUS_RESP"
fi

# 4. SSE 事件流（读取 2 秒）
echo "[4/6] SSE 事件流..."
SSE_RESP=$(timeout 2 curl -sf "$BASE_URL/task/$TASK_ID/events" 2>/dev/null || true)
if [ -n "$SSE_RESP" ]; then
    pass "GET /task/{id}/events 有响应"
else
    pass "GET /task/{id}/events 空响应（无 Redis 时正常）"
fi

# 5. 幂等性测试（重复提交同一 task_id）
echo "[5/6] 幂等性测试..."
IDEM_RESP=$(curl -sf -X POST "$BASE_URL/task" \
    -H "Content-Type: application/json" \
    -d "{\"task_id\": \"$TASK_ID\", \"card_alias\": \"test-card\", \"url\": \"https://example.com\", \"max_amount\": 10.0}" \
    2>/dev/null || echo "FAILED")

if echo "$IDEM_RESP" | grep -qE '"task_id"'; then
    pass "幂等性: 重复提交有响应"
else
    fail "幂等性测试失败: $IDEM_RESP"
fi

# 6. 沙箱状态
echo "[6/6] 沙箱状态..."
SANDBOX_RESP=$(curl -sf "$BASE_URL/sandbox/status" 2>/dev/null || echo "FAILED")
if echo "$SANDBOX_RESP" | grep -qE '"(available|count)"'; then
    pass "GET /sandbox/status 正常"
else
    fail "GET /sandbox/status 失败: $SANDBOX_RESP"
fi

# 汇总
echo ""
echo "=== 测试报告 ==="
echo "通过: $PASS"
echo "失败: $FAIL"
echo ""

if [ "$FAIL" -gt 0 ]; then
    echo "❌ 冒烟测试未全部通过"
    exit 1
else
    echo "✅ 冒烟测试全部通过"
    exit 0
fi
