"""Runtime-owned display route registry for scoped noVNC handoff."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta


def _now() -> datetime:
    return datetime.now(UTC)


def _iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def _stable_id(prefix: str, raw: str) -> str:
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"{prefix}_{digest[:16]}"


@dataclass(frozen=True)
class DisplayRouteRecord:
    route_id: str
    route_token: str
    task_id: str
    user_id: str
    workspace_id: str
    runtime_id: str
    display_surface_id: str | None
    novnc_route_key: str | None
    created_at: str
    expires_at: str

    def is_expired(self, *, now: datetime | None = None) -> bool:
        current = now or _now()
        return current >= datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))


class DisplayRouteRegistry:
    def __init__(self, *, ttl_seconds: float = 300.0) -> None:
        if ttl_seconds <= 0:
            raise ValueError("display route ttl_seconds must be positive")
        self._ttl_seconds = ttl_seconds
        self._routes_by_token: dict[str, DisplayRouteRecord] = {}
        self._routes_by_session: dict[str, str] = {}
        self._routes_by_workspace: dict[str, str] = {}

    @property
    def ttl_seconds(self) -> float:
        return self._ttl_seconds

    def register(
        self,
        *,
        route_token: str,
        task_id: str,
        user_id: str,
        workspace_id: str,
        runtime_id: str,
        display_surface_id: str | None,
        novnc_route_key: str | None,
    ) -> DisplayRouteRecord:
        self.revoke_session(task_id)
        self.revoke_workspace(workspace_id)
        now = _now()
        created_at = _iso(now)
        expires_at = _iso(now + timedelta(seconds=self._ttl_seconds))
        record = DisplayRouteRecord(
            route_id=_stable_id("droute", f"{workspace_id}:{task_id}:{route_token}:{created_at}"),
            route_token=route_token,
            task_id=task_id,
            user_id=user_id,
            workspace_id=workspace_id,
            runtime_id=runtime_id,
            display_surface_id=display_surface_id,
            novnc_route_key=novnc_route_key,
            created_at=created_at,
            expires_at=expires_at,
        )
        self._routes_by_token[route_token] = record
        self._routes_by_session[task_id] = route_token
        self._routes_by_workspace[workspace_id] = route_token
        return record

    def revoke_session(self, task_id: str) -> None:
        token = self._routes_by_session.pop(task_id, None)
        if token is None:
            return
        record = self._routes_by_token.pop(token, None)
        if record is not None and self._routes_by_workspace.get(record.workspace_id) == token:
            self._routes_by_workspace.pop(record.workspace_id, None)

    def revoke_workspace(self, workspace_id: str) -> None:
        token = self._routes_by_workspace.pop(workspace_id, None)
        if token is None:
            return
        record = self._routes_by_token.pop(token, None)
        if record is not None and self._routes_by_session.get(record.task_id) == token:
            self._routes_by_session.pop(record.task_id, None)

    def get_session_route(self, task_id: str) -> DisplayRouteRecord | None:
        token = self._routes_by_session.get(task_id)
        if token is None:
            return None
        record = self._routes_by_token.get(token)
        if record is None:
            self._routes_by_session.pop(task_id, None)
            return None
        if record.is_expired():
            self.revoke_session(task_id)
            return None
        return record

    def resolve(
        self,
        *,
        route_token: str,
        task_id: str,
        user_id: str,
        workspace_id: str,
    ) -> DisplayRouteRecord | None:
        record = self._routes_by_token.get(route_token)
        if record is None:
            return None
        if record.is_expired():
            self.revoke_session(record.task_id)
            return None
        if (
            record.task_id != task_id
            or record.user_id != user_id
            or record.workspace_id != workspace_id
        ):
            return None
        return record
