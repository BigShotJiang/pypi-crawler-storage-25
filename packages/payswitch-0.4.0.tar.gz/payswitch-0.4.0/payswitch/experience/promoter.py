"""Background promotion primitives for ready recovery recipe patches."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass
from datetime import UTC, datetime

from payswitch.experience.store import ExperienceStore


@dataclass(slots=True)
class ReadyPatchPromotionCycleResult:
    """One polling cycle of the ready-patch promotion runner."""

    promoted: int
    dry_run: bool
    items: list[dict[str, object]]


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


class ReadyPatchPromotionRunner:
    """Run ready recovery patch promotion through a bounded background loop."""

    def __init__(
        self,
        store: ExperienceStore,
        *,
        basis: str | None = None,
        min_shadow_runs: int = 1,
        platform: str | None = None,
        flow: str | None = None,
        source: str | None = None,
        poll_interval_seconds: float = 5.0,
        batch_limit: int = 10,
        max_idle_polls: int = 3,
        sleep_fn: Callable[[float], None] = time.sleep,
        ) -> None:
        if basis not in {None, "reviewed", "shadow_run_success"}:
            raise ValueError("basis must be one of: reviewed, shadow_run_success")
        if min_shadow_runs < 1:
            raise ValueError("min_shadow_runs must be >= 1")
        if batch_limit < 1:
            raise ValueError("batch_limit must be >= 1")
        if max_idle_polls < 1:
            raise ValueError("max_idle_polls must be >= 1")
        if poll_interval_seconds < 0:
            raise ValueError("poll_interval_seconds must be >= 0")
        self._store = store
        self._basis = basis
        self._min_shadow_runs = min_shadow_runs
        self._platform = platform
        self._flow = flow
        self._source = source
        self._poll_interval_seconds = poll_interval_seconds
        self._batch_limit = batch_limit
        self._max_idle_polls = max_idle_polls
        self._sleep_fn = sleep_fn

    def run_once(
        self,
        *,
        actor: str,
        note: str | None = None,
        dry_run: bool = False,
    ) -> ReadyPatchPromotionCycleResult:
        items = self._store.promote_ready_patches(
            platform=self._platform,
            flow=self._flow,
            source=self._source,
            basis=self._basis,
            min_shadow_runs=self._min_shadow_runs,
            actor=actor,
            note=note,
            limit=self._batch_limit,
            dry_run=dry_run,
        )
        return ReadyPatchPromotionCycleResult(
            promoted=len(items),
            dry_run=dry_run,
            items=items,
        )

    def run_loop(
        self,
        *,
        actor: str,
        note: str | None = None,
        dry_run: bool = False,
        max_cycles: int | None = None,
    ) -> dict[str, object]:
        if max_cycles is not None and max_cycles < 1:
            raise ValueError("max_cycles must be >= 1")

        cycles = 0
        idle_polls = 0
        history: list[dict[str, object]] = []

        while True:
            cycle = self.run_once(actor=actor, note=note, dry_run=dry_run)
            cycles += 1
            if cycle.promoted == 0:
                idle_polls += 1
            else:
                idle_polls = 0
            history.append(asdict(cycle))

            if max_cycles is not None and cycles >= max_cycles:
                break
            if idle_polls >= self._max_idle_polls:
                break
            if cycle.promoted == 0 and self._poll_interval_seconds > 0:
                self._sleep_fn(self._poll_interval_seconds)

        return {
            "cycles": cycles,
            "idle_polls": idle_polls,
            "basis": self._basis,
            "min_shadow_runs": self._min_shadow_runs,
            "platform": self._platform,
            "flow": self._flow,
            "source": self._source,
            "poll_interval_seconds": self._poll_interval_seconds,
            "batch_limit": self._batch_limit,
            "max_idle_polls": self._max_idle_polls,
            "dry_run": dry_run,
            "total_promoted": sum(int(entry["promoted"]) for entry in history),
            "history": history,
        }


class ReadyPatchPromotionSupervisor:
    """Service-owned supervisor for ready recovery patch promotion."""

    def __init__(
        self,
        store: ExperienceStore,
        *,
        actor: str,
        note: str | None = None,
        basis: str | None = None,
        min_shadow_runs: int = 1,
        platform: str | None = None,
        flow: str | None = None,
        source: str | None = None,
        poll_interval_seconds: float = 30.0,
        batch_limit: int = 10,
        dry_run: bool = False,
    ) -> None:
        actor_name = actor.strip()
        if not actor_name:
            raise ValueError("actor must not be empty")
        self._runner = ReadyPatchPromotionRunner(
            store,
            basis=basis,
            min_shadow_runs=min_shadow_runs,
            platform=platform,
            flow=flow,
            source=source,
            poll_interval_seconds=poll_interval_seconds,
            batch_limit=batch_limit,
            max_idle_polls=1,
        )
        self._actor = actor_name
        self._note = note
        self._basis = basis
        self._min_shadow_runs = min_shadow_runs
        self._platform = platform
        self._flow = flow
        self._source = source
        self._dry_run = dry_run
        self._poll_interval_seconds = poll_interval_seconds
        self._batch_limit = batch_limit
        self._stop_event = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._cycles = 0
        self._total_promoted = 0
        self._last_started_at: str | None = None
        self._last_finished_at: str | None = None
        self._last_error: str | None = None

    async def start(self) -> None:
        if self._task is not None and not self._task.done():
            return
        self._stop_event = asyncio.Event()
        self._task = asyncio.create_task(self._run(), name="ready-patch-promotion-supervisor")

    async def stop(self) -> None:
        if self._task is None:
            return
        self._stop_event.set()
        await self._task
        self._task = None

    def snapshot(self) -> dict[str, object]:
        running = self._task is not None and not self._task.done()
        return {
            "enabled": True,
            "running": running,
            "actor": self._actor,
            "note": self._note,
            "basis": self._basis,
            "min_shadow_runs": self._min_shadow_runs,
            "platform": self._platform,
            "flow": self._flow,
            "source": self._source,
            "dry_run": self._dry_run,
            "poll_interval_seconds": self._poll_interval_seconds,
            "batch_limit": self._batch_limit,
            "cycles": self._cycles,
            "total_promoted": self._total_promoted,
            "last_started_at": self._last_started_at,
            "last_finished_at": self._last_finished_at,
            "last_error": self._last_error,
        }

    async def _run(self) -> None:
        while not self._stop_event.is_set():
            self._last_started_at = _utc_now()
            try:
                result = await asyncio.to_thread(
                    self._runner.run_once,
                    actor=self._actor,
                    note=self._note,
                    dry_run=self._dry_run,
                )
                self._cycles += 1
                self._total_promoted += result.promoted
                self._last_error = None
            except Exception as exc:  # pragma: no cover - defensive telemetry path
                self._last_error = str(exc)
            finally:
                self._last_finished_at = _utc_now()

            if self._stop_event.is_set():
                break
            if self._poll_interval_seconds <= 0:
                await asyncio.sleep(0)
                continue
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self._poll_interval_seconds,
                )
            except TimeoutError:
                continue
