"""Registry of built-in checkout recipes and mainline overrides."""

from __future__ import annotations

from payswitch.experience.models import (
    ExperienceRecipe,
    RecipeExpectation,
    RecipeWaypoint,
)
from payswitch.experience.store import ExperienceStore
from payswitch.models.types import StepCategory

_BUILTIN_RECIPES: dict[tuple[str, str], ExperienceRecipe] = {
    (
        "qwen",
        "topup_alipay_qr",
    ): ExperienceRecipe(
        recipe_id="qwen.topup_alipay_qr",
        platform="qwen",
        flow="topup_alipay_qr",
        version="1.0.0",
        confidence=0.84,
        start_urls=[
            "https://tongyi.aliyun.com/recharge",
            "https://bailian.aliyun.com/",
        ],
        learned_from=(
            "Promoted from the stable Qwen recharge path that opens the recharge "
            "surface, selects an amount, keeps Alipay as the payment method, and "
            "stops at the QR handoff."
        ),
        selectors={
            "amount_exact": [
                "button:has-text('¥{amount_int}')",
                "button:has-text('¥ {amount_int}')",
                "button:has-text('{amount_int}元')",
                "button:has-text('{amount_int} 元')",
                "[class*='amount']:has-text('{amount_int}')",
                "[class*='package']:has-text('{amount_int}')",
                ".ant-card:has-text('{amount_int}')",
                "[data-amount='{amount_int}']",
            ],
            "custom_amount_input": [
                "input[placeholder*='金额']",
                "input[placeholder*='充值']",
                "input[type='number']",
                "input[inputmode='decimal']",
            ],
            "payment_method_alipay": [
                "button:has-text('支付宝')",
                "label:has-text('支付宝')",
                ".ant-radio-wrapper:has-text('支付宝')",
                "[class*='alipay']",
            ],
            "confirm": [
                "button:has-text('确认充值')",
                "button:has-text('去支付')",
                "button:has-text('立即充值')",
                "button:has-text('立即支付')",
                "button:has-text('确认支付')",
                "button:has-text('Pay')",
                ".ant-btn-primary:has-text('充值')",
                ".ant-btn-primary:has-text('支付')",
            ],
            "qr": [
                "img[class*='qr']",
                "img[class*='qrcode']",
                "canvas[class*='qr']",
                "canvas[class*='qrcode']",
                "[class*='qrcode']",
                ".ant-modal:has(img)",
            ],
        },
        texts={
            "topup_ready": [
                "充值",
                "支付宝",
                "支付方式",
            ],
            "payment_surface": [
                "支付宝",
                "支付方式",
                "确认充值",
                "去支付",
                "立即支付",
            ],
            "success": [
                "扫码",
                "二维码",
            ],
        },
        notes=[
            (
                "Qwen often keeps Alipay preselected, so payment-method selection may "
                "degrade to a visible-wait step instead of an explicit click."
            ),
            (
                "The amount surface can be preset chips or a custom amount input, so "
                "the recipe keeps amount selection as a semantic action."
            ),
        ],
        waypoints=[
            RecipeWaypoint(
                id="open_topup_page",
                intent="打开通义千问充值页",
                action="navigate",
                description="打开通义千问充值页",
                url="https://tongyi.aliyun.com/recharge",
                category=StepCategory.nav,
            ),
            RecipeWaypoint(
                id="verify_login_state",
                intent="检查通义千问登录状态",
                action="semantic",
                semantic_action="ensure_logged_in",
                description="检查通义千问登录状态",
                category=StepCategory.identity,
            ),
            RecipeWaypoint(
                id="select_topup_amount",
                intent="选择通义千问充值金额",
                action="semantic",
                semantic_action="select_amount",
                description="选择通义千问充值金额",
                category=StepCategory.checkout_prep,
                expected=RecipeExpectation(any_texts=["支付宝", "支付方式"]),
            ),
            RecipeWaypoint(
                id="ensure_payment_method",
                intent="确认通义千问支付方式",
                action="semantic",
                semantic_action="select_payment_method",
                description="确认通义千问支付方式",
                category=StepCategory.checkout_prep,
            ),
            RecipeWaypoint(
                id="confirm_topup_checkout",
                intent="确认进入通义千问收银台",
                action="semantic",
                semantic_action="click_confirm",
                description="点击通义千问确认充值，进入支付流程",
                category=StepCategory.final_authorization,
                synchronous_policy_checkpoint=True,
                expected=RecipeExpectation(
                    any_selectors=[
                        "img[class*='qr']",
                        "canvas[class*='qr']",
                        "[class*='qrcode']",
                    ]
                ),
            ),
            RecipeWaypoint(
                id="wait_for_qr",
                intent="到达通义千问二维码支付闸口",
                action="semantic",
                semantic_action="wait_for_qr",
                description="等待通义千问二维码支付界面",
                category=StepCategory.final_authorization,
                expected=RecipeExpectation(
                    any_selectors=[
                        "img[class*='qr']",
                        "canvas[class*='qr']",
                        "[class*='qrcode']",
                    ]
                ),
            ),
        ],
    ),
    (
        "volcano",
        "topup_alipay_qr",
    ): ExperienceRecipe(
        recipe_id="volcano.topup_alipay_qr",
        platform="volcano",
        flow="topup_alipay_qr",
        version="1.0.0",
        confidence=0.83,
        start_urls=[
            "https://console.volcengine.com/finance/fund/recharge",
        ],
        learned_from=(
            "Promoted from the stable Volcano recharge path that sets the amount, "
            "continues to the payment surface, confirms the payment method, and "
            "stops at the QR or external payment handoff."
        ),
        selectors={
            "amount_input": [
                "input[type='number']",
                "input[inputmode='numeric']",
                "input[placeholder*='金额']",
                "input[placeholder*='充值']",
            ],
            "amount_exact": [
                "button:has-text('{amount_text}')",
                "label:has-text('{amount_text}')",
                "[class*='amount']:has-text('{amount_text}')",
                "[class*='price']:has-text('{amount_text}')",
                "[data-amount='{amount_text}']",
                "[data-price='{amount_text}']",
            ],
            "continue": [
                "button:has-text('下一步')",
                "button:has-text('确定')",
                "button:has-text('提交')",
                "button:has-text('Next')",
                "button:has-text('Continue')",
                ".arco-btn-primary",
                ".ant-btn-primary",
            ],
            "payment_method_alipay": [
                "button:has-text('支付宝')",
                "label:has-text('支付宝')",
                "[class*='alipay']",
                "[data-method='alipay']",
            ],
            "payment_method_wechat": [
                "button:has-text('微信')",
                "label:has-text('微信')",
                "[class*='wechat']",
                "[data-method='wechat']",
            ],
            "payment_method_bank": [
                "button:has-text('网银')",
                "label:has-text('网银')",
                "button:has-text('银行')",
                "label:has-text('银行')",
                "[class*='bank']",
                "[data-method='bank']",
            ],
            "confirm": [
                "button:has-text('去支付')",
                "button:has-text('确认订单')",
                "button:has-text('提交订单')",
                "button:has-text('下一步')",
                "button:has-text('Pay')",
                ".arco-btn-primary",
                ".ant-btn-primary",
            ],
            "qr": [
                "img[class*='qr']",
                "img[class*='qrcode']",
                "canvas[class*='qr']",
                "canvas[class*='qrcode']",
                "[class*='qr-code']",
                "[class*='qrcode']",
                "[class*='pay-qr']",
            ],
        },
        texts={
            "topup_ready": [
                "充值",
                "下一步",
                "支付方式",
            ],
            "payment_surface": [
                "支付宝",
                "微信",
                "网银",
                "支付方式",
                "去支付",
                "确认订单",
            ],
        },
        notes=[
            (
                "Volcano can hand off either to a visible QR surface or to an "
                "external payment redirect, so the fast path stops at the payment gate."
            ),
        ],
        waypoints=[
            RecipeWaypoint(
                id="open_topup_page",
                intent="打开 Volcano 充值页",
                action="navigate",
                description="打开 Volcano 充值页",
                url="https://console.volcengine.com/finance/fund/recharge",
                category=StepCategory.nav,
            ),
            RecipeWaypoint(
                id="verify_login_state",
                intent="检查 Volcano 登录状态",
                action="semantic",
                semantic_action="ensure_logged_in",
                description="检查 Volcano 登录状态",
                category=StepCategory.identity,
            ),
            RecipeWaypoint(
                id="select_topup_amount",
                intent="选择 Volcano 充值金额",
                action="semantic",
                semantic_action="select_amount",
                description="选择 Volcano 充值金额",
                category=StepCategory.checkout_prep,
                expected=RecipeExpectation(any_texts=["下一步", "支付方式"]),
            ),
            RecipeWaypoint(
                id="continue_to_payment_surface",
                intent="从金额页进入 Volcano 支付方式页",
                action="semantic",
                semantic_action="click_next",
                description="进入 Volcano 支付方式页",
                category=StepCategory.checkout_prep,
            ),
            RecipeWaypoint(
                id="ensure_payment_method",
                intent="确认 Volcano 支付方式",
                action="semantic",
                semantic_action="select_payment_method",
                description="确认 Volcano 支付方式",
                category=StepCategory.checkout_prep,
            ),
            RecipeWaypoint(
                id="confirm_topup_checkout",
                intent="确认进入 Volcano 收银台",
                action="semantic",
                semantic_action="click_confirm",
                description="点击 Volcano 去支付，进入支付流程",
                category=StepCategory.final_authorization,
                synchronous_policy_checkpoint=True,
            ),
            RecipeWaypoint(
                id="wait_for_qr",
                intent="到达 Volcano 支付闸口",
                action="semantic",
                semantic_action="wait_for_qr",
                description="等待 Volcano 二维码或支付跳转",
                category=StepCategory.final_authorization,
            ),
        ],
    ),
    (
        "jimeng",
        "topup_alipay_qr",
    ): ExperienceRecipe(
        recipe_id="jimeng.topup_alipay_qr",
        platform="jimeng",
        flow="topup_alipay_qr",
        version="1.0.0",
        confidence=0.81,
        start_urls=[
            "https://jimeng.jianying.com/ai-tool/home",
        ],
        learned_from=(
            "Promoted from the visible Jimeng path that opens the membership or "
            "points checkout surface, selects the package, confirms the payment "
            "method, and stops at the QR handoff."
        ),
        selectors={
            "checkout_entry": [
                "button:has-text('购买积分')",
                "text=购买积分",
                "button:has-text('积分')",
                "text=积分详情",
                "a[href*='pay']",
                "a[href*='billing']",
                "a[href*='member']",
                "a[href*='vip']",
            ],
            "amount_exact": [
                "text=¥{amount_decimal}",
                "text=￥{amount_decimal}",
                "text=¥{amount_text}",
                "text=￥{amount_text}",
                "[data-amount='{amount_text}']",
                "[data-price='{amount_text}']",
            ],
            "amount_input": [
                "input[type='number']",
                "input[inputmode='numeric']",
                "input[placeholder*='金额']",
                "input[placeholder*='充值']",
            ],
            "payment_method_alipay": [
                "button:has-text('支付宝')",
                "label:has-text('支付宝')",
                "[class*='alipay']",
                "[data-method='alipay']",
            ],
            "payment_method_wechat": [
                "button:has-text('微信')",
                "label:has-text('微信')",
                "[class*='wechat']",
                "[data-method='wechat']",
            ],
            "confirm": [
                "button:has-text('同意并支付')",
                "button:has-text('去支付')",
                "button:has-text('确认订单')",
                "button:has-text('提交订单')",
                "button:has-text('下一步')",
                "button:has-text('购买')",
                "button:has-text('Pay')",
            ],
            "qr": [
                "img[class*='qr']",
                "img[class*='qrcode']",
                "canvas[class*='qr']",
                "canvas[class*='qrcode']",
                "[class*='qr-code']",
                "[class*='qrcode']",
                "[class*='pay-qr']",
            ],
        },
        texts={
            "checkout_ready": [
                "购买积分",
                "积分",
                "会员",
                "支付",
            ],
            "payment_surface": [
                "支付宝",
                "微信",
                "同意并支付",
                "去支付",
                "确认订单",
                "购买",
            ],
        },
        notes=[
            (
                "Jimeng can expose points purchase through several different entry "
                "surfaces, so checkout entry remains a semantic step."
            ),
        ],
        waypoints=[
            RecipeWaypoint(
                id="open_homepage",
                intent="打开 Jimeng 首页",
                action="navigate",
                description="打开 Jimeng 首页",
                url="https://jimeng.jianying.com/ai-tool/home",
                category=StepCategory.nav,
            ),
            RecipeWaypoint(
                id="verify_login_state",
                intent="检查 Jimeng 登录状态",
                action="semantic",
                semantic_action="ensure_logged_in",
                description="检查 Jimeng 登录状态",
                category=StepCategory.identity,
            ),
            RecipeWaypoint(
                id="enter_checkout_surface",
                intent="进入 Jimeng 购买页",
                action="semantic",
                semantic_action="enter_checkout",
                description="进入 Jimeng 购买页",
                category=StepCategory.checkout_prep,
                expected=RecipeExpectation(any_texts=["购买", "支付", "会员"]),
            ),
            RecipeWaypoint(
                id="select_topup_amount",
                intent="选择 Jimeng 金额或套餐",
                action="semantic",
                semantic_action="select_amount",
                description="选择 Jimeng 金额或套餐",
                category=StepCategory.checkout_prep,
            ),
            RecipeWaypoint(
                id="ensure_payment_method",
                intent="确认 Jimeng 支付方式",
                action="semantic",
                semantic_action="select_payment_method",
                description="确认 Jimeng 支付方式",
                category=StepCategory.checkout_prep,
            ),
            RecipeWaypoint(
                id="confirm_topup_checkout",
                intent="确认进入 Jimeng 收银台",
                action="semantic",
                semantic_action="click_confirm",
                description="点击 Jimeng 去支付，进入支付流程",
                category=StepCategory.final_authorization,
                synchronous_policy_checkpoint=True,
            ),
            RecipeWaypoint(
                id="wait_for_qr",
                intent="到达 Jimeng 支付闸口",
                action="semantic",
                semantic_action="wait_for_qr",
                description="等待 Jimeng 二维码支付界面",
                category=StepCategory.final_authorization,
            ),
        ],
    ),
    (
        "nineemail",
        "product_alipay_qr",
    ): ExperienceRecipe(
        recipe_id="nineemail.product_alipay_qr",
        platform="nineemail",
        flow="product_alipay_qr",
        version="1.0.0",
        confidence=0.8,
        start_urls=[
            "https://www.nineemail.com/buy/14",
        ],
        learned_from=(
            "Promoted from the stable NineEmail product purchase path that opens "
            "the product page, fills quantity/email/search password, submits the "
            "order, and stops at the Alipay QR handoff."
        ),
        selectors={
            "product_page": [
                "#orderNumber",
                "input[name='email']",
                "input[name='search_pwd']",
            ],
            "submit_order": [
                "text=下单",
                "button:has-text('下单')",
            ],
            "confirm": [
                "text=立即支付",
                "button:has-text('立即支付')",
            ],
            "qr": [
                "img[src^='data:image/png;base64,']",
                "img[src*='base64']",
                "text=扫码支付",
            ],
        },
        texts={
            "order_ready": [
                "支付宝",
                "下单",
                "邮箱",
            ],
            "payment_surface": [
                "立即支付",
                "支付宝",
                "确认订单",
                "扫码支付",
            ],
        },
        notes=[
            (
                "NineEmail uses generated email/search-password values on the order "
                "form, so the form-fill step remains a semantic action."
            ),
        ],
        waypoints=[
            RecipeWaypoint(
                id="open_product_page",
                intent="打开 NineEmail 商品页",
                action="navigate",
                description="打开 NineEmail 商品页",
                url="https://www.nineemail.com/buy/14",
                category=StepCategory.nav,
            ),
            RecipeWaypoint(
                id="prepare_order_form",
                intent="填写 NineEmail 订单表单",
                action="semantic",
                semantic_action="fill_order_form",
                description="填写 NineEmail 订单表单",
                category=StepCategory.checkout_prep,
                expected=RecipeExpectation(any_texts=["支付宝", "下单"]),
            ),
            RecipeWaypoint(
                id="submit_order",
                intent="提交 NineEmail 订单",
                action="semantic",
                semantic_action="submit_order",
                description="提交 NineEmail 订单",
                category=StepCategory.checkout_prep,
            ),
            RecipeWaypoint(
                id="confirm_topup_checkout",
                intent="确认进入 NineEmail 支付页",
                action="semantic",
                semantic_action="click_confirm",
                description="点击 NineEmail 立即支付，进入支付流程",
                category=StepCategory.final_authorization,
                synchronous_policy_checkpoint=True,
            ),
            RecipeWaypoint(
                id="wait_for_qr",
                intent="到达 NineEmail 二维码支付闸口",
                action="semantic",
                semantic_action="wait_for_qr",
                description="等待 NineEmail 二维码支付界面",
                category=StepCategory.final_authorization,
            ),
        ],
    ),
    (
        "deepseek",
        "topup_alipay_qr",
    ): ExperienceRecipe(
        recipe_id="deepseek.topup_alipay_qr",
        platform="deepseek",
        flow="topup_alipay_qr",
        version="1.0.0",
        confidence=0.91,
        start_urls=[
            "https://platform.deepseek.com/",
            "https://platform.deepseek.com/usage",
            "https://platform.deepseek.com/top_up",
        ],
        learned_from=(
            "Promoted from the successful external Computer Use replay that navigated "
            "Usage -> Top up -> amount chip -> Next step -> QR -> Billing success."
        ),
        selectors={
            "top_up_entry": [
                "div:has-text('Top up')",
                "a:has-text('Top up')",
            ],
            "amount_exact": [
                "label:has-text('¥{amount_int}')",
                "label:has-text('¥ {amount_int}')",
                "[class*='radio-button']:has-text('¥{amount_int}')",
                "[class*='amount']:has-text('{amount_int}')",
            ],
            "custom_amount_toggle": [
                "label:has-text('Custom')",
                "[class*='radio-button']:has-text('Custom')",
            ],
            "custom_amount_input": [
                "input[placeholder*='Amount']",
                "input[placeholder*='金额']",
                "input[type='number']",
                "input[type='text'][inputmode='decimal']",
            ],
            "payment_method_default": [
                "text=Payment method",
                "div:has-text('Online recharge')",
            ],
            "confirm": [
                "div.ds-button.ds-button--primary:has-text('Next step')",
                "div[class*='button'][class*='primary']:has-text('Next step')",
                "div:has-text('Next step')",
                "button:has-text('Next step')",
                "text=Next step",
                "button:has-text('Pay')",
            ],
            "qr": [
                "text=Scan QR code to pay",
                "text=The QR code is valid for 15 minutes",
                "[class*='qrcode']",
                "img[class*='qr']",
            ],
            "billing_success": [
                "text=Success",
                "text=Topped-up",
            ],
        },
        texts={
            "login_blockers": [
                "Sign in",
                "Login",
            ],
            "identity_verification": [
                "Please complete real-name verification",
                "Real Name (Chinese Characters Only)",
                "ID Number",
                "Verify",
            ],
            "topup_ready": [
                "Amount",
                "Payment method",
                "Next step",
            ],
            "payment_surface": [
                "Payment method",
                "Online recharge",
                "Next step",
            ],
            "success": [
                "Status",
                "Success",
            ],
        },
        notes=[
            (
                "DeepSeek top-up currently defaults to QR checkout without exposing "
                "an explicit Alipay picker on the top-up page."
            ),
            (
                "When identity verification is incomplete, the page shows Verify plus "
                "Real Name and ID Number requirements before Next step can advance."
            ),
            (
                "For known preset amounts, the radio-button labels are currently more "
                "stable than generic button selectors."
            ),
            (
                "The confirm action is currently rendered as a primary div button on the "
                "top-up page, so recipe selectors should prefer primary-button classes "
                "before generic text matches."
            ),
        ],
        waypoints=[
            RecipeWaypoint(
                id="open_topup_page",
                intent="打开 DeepSeek 充值页",
                action="navigate",
                description="打开 DeepSeek 充值页",
                url="https://platform.deepseek.com/top_up",
                category=StepCategory.nav,
            ),
            RecipeWaypoint(
                id="verify_login_state",
                intent="检查 DeepSeek 登录状态",
                action="semantic",
                semantic_action="ensure_logged_in",
                description="检查 DeepSeek 登录状态",
                category=StepCategory.identity,
            ),
            RecipeWaypoint(
                id="verify_identity_gate",
                intent="确认实名认证门槛已解除",
                action="semantic",
                semantic_action="ensure_identity_ready",
                description="确认 DeepSeek 实名认证门槛已解除",
                category=StepCategory.identity,
            ),
            RecipeWaypoint(
                id="select_topup_amount",
                intent="选择 DeepSeek 充值金额",
                action="semantic",
                semantic_action="select_amount",
                description="选择 DeepSeek 充值金额",
                category=StepCategory.checkout_prep,
                expected=RecipeExpectation(any_texts=["Payment method", "Next step"]),
            ),
            RecipeWaypoint(
                id="ensure_payment_method",
                intent="确认默认在线充值支付区块可见",
                action="semantic",
                semantic_action="select_payment_method",
                description="确认 DeepSeek 默认在线充值支付区块",
                category=StepCategory.checkout_prep,
            ),
            RecipeWaypoint(
                id="confirm_topup_checkout",
                intent="确认进入 DeepSeek 收银台",
                action="semantic",
                semantic_action="click_confirm",
                description="点击 DeepSeek Next step，进入支付流程",
                category=StepCategory.final_authorization,
                synchronous_policy_checkpoint=True,
                expected=RecipeExpectation(
                    any_texts=["Scan QR code to pay", "The QR code is valid for 15 minutes"]
                ),
            ),
            RecipeWaypoint(
                id="wait_for_qr",
                intent="到达 DeepSeek 二维码支付闸口",
                action="semantic",
                semantic_action="wait_for_qr",
                description="等待 DeepSeek 二维码支付界面",
                category=StepCategory.final_authorization,
                expected=RecipeExpectation(
                    any_selectors=[
                        "text=Scan QR code to pay",
                        "text=The QR code is valid for 15 minutes",
                    ]
                ),
            ),
        ],
    ),
    (
        "kimi",
        "membership_monthly_qr",
    ): ExperienceRecipe(
        recipe_id="kimi.membership_monthly_qr",
        platform="kimi",
        flow="membership_monthly_qr",
        version="1.0.0",
        confidence=0.86,
        start_urls=[
            "https://www.kimi.com",
            "https://www.kimi.com/membership/pricing?from=pay_switch",
        ],
        learned_from=(
            "Promoted from the visible Kimi membership checkout flow that opens the "
            "homepage first, enters pricing, selects Monthly / Andante, accepts "
            "Continue, and stops at the Alipay/WeChat QR surface."
        ),
        selectors={
            "entry": [
                "a:has-text('Upgrade your plan')",
                "button:has-text('Upgrade your plan')",
                "a:has-text('Subscribe')",
                "button:has-text('Subscribe')",
                "a:has-text('会员')",
                "button:has-text('会员')",
            ],
            "pricing_surface": [
                "text=Monthly",
                "text=Subscribe",
                "text=月付",
                "text=会员",
            ],
            "payment_surface": [
                "text=Agree to Kimi's Agreements",
                "text=Pay with Alipay / WeChat",
                "text=Use Alipay for large payments",
            ],
            "qr": [
                "text=Pay with Alipay / WeChat",
                "text=Use Alipay for large payments",
                "[class*='qrcode']",
                "canvas[class*='qr']",
                "img[class*='qr']",
            ],
        },
        texts={
            "login_blockers": [
                "登录以同步历史会话",
                "Log in to sync chat history",
                "扫码登录",
            ],
            "pricing_surface": [
                "Monthly",
                "Subscribe",
                "月付",
                "会员",
            ],
            "payment_surface": [
                "Pay with Alipay / WeChat",
                "Use Alipay for large payments",
                "Agree to Kimi's Agreements",
            ],
        },
        notes=[
            "Kimi fast path must open the homepage first so operators can see the real path.",
            "Pricing flow should prefer monthly membership before the Subscribe CTA.",
            "Login prompts are only valid when visible; hidden templates must be ignored.",
        ],
        waypoints=[
            RecipeWaypoint(
                id="open_homepage",
                intent="打开 Kimi 官网首页并进入真实入口",
                action="navigate",
                description="打开 Kimi 官网首页",
                url="https://www.kimi.com",
                category=StepCategory.nav,
            ),
            RecipeWaypoint(
                id="verify_login_state",
                intent="检查 Kimi 登录状态",
                action="semantic",
                semantic_action="ensure_logged_in",
                description="检查 Kimi 登录状态",
                category=StepCategory.identity,
            ),
            RecipeWaypoint(
                id="reach_pricing_surface",
                intent="进入 Kimi 会员订阅页",
                action="semantic",
                semantic_action="ensure_checkout_page",
                description="进入 Kimi 会员套餐页",
                category=StepCategory.checkout_prep,
                expected=RecipeExpectation(any_texts=["Monthly", "月付", "会员"]),
            ),
            RecipeWaypoint(
                id="select_monthly_plan",
                intent="选择月付会员套餐",
                action="semantic",
                semantic_action="select_plan",
                description="选择 Kimi 月付会员套餐",
                category=StepCategory.checkout_prep,
                expected=RecipeExpectation(
                    any_texts=["Pay with Alipay / WeChat", "Agree to Kimi's Agreements"]
                ),
            ),
            RecipeWaypoint(
                id="ensure_payment_method",
                intent="确认默认支付方式已准备好",
                action="semantic",
                semantic_action="select_payment_method",
                description="确认默认支付宝/微信二维码支付方式",
                category=StepCategory.checkout_prep,
            ),
            RecipeWaypoint(
                id="confirm_membership_checkout",
                intent="确认进入收银台",
                action="semantic",
                semantic_action="click_confirm",
                description="点击 Continue 或确认支付",
                category=StepCategory.final_authorization,
                synchronous_policy_checkpoint=True,
                expected=RecipeExpectation(
                    any_texts=["Pay with Alipay / WeChat", "Use Alipay for large payments"]
                ),
            ),
            RecipeWaypoint(
                id="wait_for_qr",
                intent="到达二维码支付闸口",
                action="semantic",
                semantic_action="wait_for_qr",
                description="等待 Kimi 二维码支付界面",
                category=StepCategory.final_authorization,
                expected=RecipeExpectation(any_selectors=["text=Pay with Alipay / WeChat"]),
            ),
        ],
    ),
}


def get_recipe(
    platform: str,
    flow: str = "topup_alipay_qr",
    *,
    store: ExperienceStore | None = None,
) -> ExperienceRecipe | None:
    """Return a built-in experience recipe when one is available."""

    if store is not None:
        override = store.load_mainline_recipe(platform=platform, flow=flow)
        if override is not None:
            return override
    return _BUILTIN_RECIPES.get((platform, flow))


def list_recipes(platform: str | None = None) -> list[ExperienceRecipe]:
    """List registered experience recipes, optionally filtered by platform."""

    recipes = list(_BUILTIN_RECIPES.values())
    if platform is None:
        return recipes
    return [recipe for recipe in recipes if recipe.platform == platform]
