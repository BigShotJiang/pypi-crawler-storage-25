"""Structured recipe models for fast adapter execution."""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field

from payswitch.models.types import StepCategory, StepRisk


class RecipePatchState(StrEnum):
    """Lifecycle states for recovery-generated recipe patches."""

    candidate = "candidate"
    shadow_run = "shadow_run"
    reviewed = "reviewed"
    mainline = "mainline"


class RecoveryImprovementStatus(StrEnum):
    """Lifecycle states for recovery improvement artifacts."""

    open = "open"
    accepted = "accepted"
    dismissed = "dismissed"
    applied = "applied"


class RecipeExpectation(BaseModel):
    """Post-waypoint assertions used by the recipe runner."""

    any_selectors: list[str] = Field(default_factory=list)
    any_texts: list[str] = Field(default_factory=list)
    url_contains: list[str] = Field(default_factory=list)


class RecipeWaypoint(BaseModel):
    """Single waypoint in a recipe-backed fast path."""

    id: str
    intent: str
    action: str
    description: str = ""
    url: str | None = None
    selector_key: str | None = None
    selectors: list[str] = Field(default_factory=list)
    text_key: str | None = None
    texts: list[str] = Field(default_factory=list)
    semantic_action: str | None = None
    category: StepCategory = StepCategory.nav
    risk: StepRisk = StepRisk.low
    requires_human_authorization: bool = False
    synchronous_policy_checkpoint: bool = False
    expected: RecipeExpectation = Field(default_factory=RecipeExpectation)
    forbidden_texts: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ExperienceRecipe(BaseModel):
    """Structured knowledge captured from prior successful checkout runs."""

    recipe_id: str
    platform: str
    flow: str
    version: str = "1.0.0"
    confidence: float = 1.0
    start_urls: list[str] = Field(default_factory=list)
    learned_from: str = ""
    selectors: dict[str, list[str]] = Field(default_factory=dict)
    texts: dict[str, list[str]] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=list)
    waypoints: list[RecipeWaypoint] = Field(default_factory=list)
