"""Background processor for accepted recovery improvements."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass
from datetime import UTC, datetime

from payswitch.experience.store import ExperienceStore


@dataclass(slots=True)
class RecoveryImprovementCycleResult:
    """One polling cycle of the recovery improvement runner."""

    processed: int
    reviewed_patches: int
    already_reviewed: int
    already_mainline: int
    dry_run: bool
    items: list[dict[str, object]]


class RecoveryImprovementRunner:
    """Run accepted recovery improvements through a bounded background loop."""

    def __init__(
        self,
        store: ExperienceStore,
        *,
        poll_interval_seconds: float = 5.0,
        batch_limit: int = 10,
        max_idle_polls: int = 3,
        sleep_fn: Callable[[float], None] = time.sleep,
    ) -> None:
        if batch_limit < 1:
            raise ValueError("batch_limit must be >= 1")
        if max_idle_polls < 1:
            raise ValueError("max_idle_polls must be >= 1")
        if poll_interval_seconds < 0:
            raise ValueError("poll_interval_seconds must be >= 0")
        self._store = store
        self._poll_interval_seconds = poll_interval_seconds
        self._batch_limit = batch_limit
        self._max_idle_polls = max_idle_polls
        self._sleep_fn = sleep_fn

    def run_once(
        self,
        *,
        reviewer: str,
        note: str | None = None,
        platform: str | None = None,
        flow: str | None = None,
        dry_run: bool = False,
    ) -> RecoveryImprovementCycleResult:
        items = self._store.process_accepted_recovery_improvements(
            reviewer=reviewer,
            note=note,
            platform=platform,
            flow=flow,
            limit=self._batch_limit,
            dry_run=dry_run,
        )
        return RecoveryImprovementCycleResult(
            processed=len(items),
            reviewed_patches=sum(
                1 for item in items if item["action"] == "review_patch"
            ),
            already_reviewed=sum(
                1 for item in items if item["action"] == "already_reviewed"
            ),
            already_mainline=sum(
                1 for item in items if item["action"] == "already_mainline"
            ),
            dry_run=dry_run,
            items=items,
        )

    def run_loop(
        self,
        *,
        reviewer: str,
        note: str | None = None,
        platform: str | None = None,
        flow: str | None = None,
        dry_run: bool = False,
        max_cycles: int | None = None,
    ) -> dict[str, object]:
        if max_cycles is not None and max_cycles < 1:
            raise ValueError("max_cycles must be >= 1")

        cycles = 0
        idle_polls = 0
        history: list[dict[str, object]] = []

        while True:
            cycle = self.run_once(
                reviewer=reviewer,
                note=note,
                platform=platform,
                flow=flow,
                dry_run=dry_run,
            )
            cycles += 1
            if cycle.processed == 0:
                idle_polls += 1
            else:
                idle_polls = 0
            history.append(asdict(cycle))

            if max_cycles is not None and cycles >= max_cycles:
                break
            if idle_polls >= self._max_idle_polls:
                break
            if cycle.processed == 0 and self._poll_interval_seconds > 0:
                self._sleep_fn(self._poll_interval_seconds)

        return {
            "cycles": cycles,
            "idle_polls": idle_polls,
            "poll_interval_seconds": self._poll_interval_seconds,
            "batch_limit": self._batch_limit,
            "max_idle_polls": self._max_idle_polls,
            "dry_run": dry_run,
            "total_processed": sum(
                int(entry["processed"]) for entry in history
            ),
            "total_reviewed_patches": sum(
                int(entry["reviewed_patches"]) for entry in history
            ),
            "history": history,
        }


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


class RecoveryImprovementSupervisor:
    """Service-owned supervisor for accepted recovery improvements."""

    def __init__(
        self,
        store: ExperienceStore,
        *,
        reviewer: str,
        note: str | None = None,
        platform: str | None = None,
        flow: str | None = None,
        auto_accept_basis: str | None = None,
        min_shadow_runs: int = 1,
        poll_interval_seconds: float = 30.0,
        batch_limit: int = 10,
        dry_run: bool = False,
    ) -> None:
        reviewer_name = reviewer.strip()
        if not reviewer_name:
            raise ValueError("reviewer must not be empty")
        if poll_interval_seconds < 0:
            raise ValueError("poll_interval_seconds must be >= 0")
        if batch_limit < 1:
            raise ValueError("batch_limit must be >= 1")
        if auto_accept_basis not in {None, "reviewed", "shadow_run_success"}:
            raise ValueError(
                "auto_accept_basis must be one of: reviewed, shadow_run_success"
            )
        if min_shadow_runs < 1:
            raise ValueError("min_shadow_runs must be >= 1")

        self._store = store
        self._runner = RecoveryImprovementRunner(
            store,
            poll_interval_seconds=poll_interval_seconds,
            batch_limit=batch_limit,
            max_idle_polls=1,
        )
        self._reviewer = reviewer_name
        self._note = note
        self._platform = platform
        self._flow = flow
        self._auto_accept_basis = auto_accept_basis
        self._min_shadow_runs = min_shadow_runs
        self._dry_run = dry_run
        self._poll_interval_seconds = poll_interval_seconds
        self._batch_limit = batch_limit
        self._stop_event = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._cycles = 0
        self._total_auto_accepted = 0
        self._total_processed = 0
        self._total_reviewed_patches = 0
        self._last_started_at: str | None = None
        self._last_finished_at: str | None = None
        self._last_error: str | None = None

    async def start(self) -> None:
        if self._task is not None and not self._task.done():
            return
        self._stop_event = asyncio.Event()
        self._task = asyncio.create_task(self._run(), name="recovery-improvement-supervisor")

    async def stop(self) -> None:
        if self._task is None:
            return
        self._stop_event.set()
        await self._task
        self._task = None

    def snapshot(self) -> dict[str, object]:
        running = self._task is not None and not self._task.done()
        return {
            "enabled": True,
            "running": running,
            "reviewer": self._reviewer,
            "note": self._note,
            "platform": self._platform,
            "flow": self._flow,
            "auto_accept_basis": self._auto_accept_basis,
            "min_shadow_runs": self._min_shadow_runs,
            "dry_run": self._dry_run,
            "poll_interval_seconds": self._poll_interval_seconds,
            "batch_limit": self._batch_limit,
            "cycles": self._cycles,
            "total_auto_accepted": self._total_auto_accepted,
            "total_processed": self._total_processed,
            "total_reviewed_patches": self._total_reviewed_patches,
            "last_started_at": self._last_started_at,
            "last_finished_at": self._last_finished_at,
            "last_error": self._last_error,
        }

    async def _run(self) -> None:
        while not self._stop_event.is_set():
            self._last_started_at = _utc_now()
            try:
                if self._auto_accept_basis is not None:
                    accepted = await asyncio.to_thread(
                        self._store.accept_open_recovery_improvements,
                        reviewer=self._reviewer,
                        note=self._note,
                        platform=self._platform,
                        flow=self._flow,
                        limit=self._batch_limit,
                        basis=self._auto_accept_basis,
                        min_shadow_runs=self._min_shadow_runs,
                        dry_run=self._dry_run,
                    )
                    self._total_auto_accepted += sum(
                        1 for entry in accepted if entry["action"] == "accepted"
                    )
                result = await asyncio.to_thread(
                    self._runner.run_once,
                    reviewer=self._reviewer,
                    note=self._note,
                    platform=self._platform,
                    flow=self._flow,
                    dry_run=self._dry_run,
                )
                self._cycles += 1
                self._total_processed += result.processed
                self._total_reviewed_patches += result.reviewed_patches
                self._last_error = None
            except Exception as exc:  # pragma: no cover - defensive telemetry path
                self._last_error = str(exc)
            finally:
                self._last_finished_at = _utc_now()

            if self._stop_event.is_set():
                break
            if self._poll_interval_seconds <= 0:
                await asyncio.sleep(0)
                continue
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self._poll_interval_seconds,
                )
            except TimeoutError:
                continue
