"""Durable storage for recipe outcomes and patch lifecycle."""

from __future__ import annotations

import json
import sqlite3
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from payswitch.experience.models import (
    ExperienceRecipe,
    RecipePatchState,
    RecoveryImprovementStatus,
)


class ExperienceStore:
    """Persist recipe outcomes and controlled patch promotion state."""

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path.expanduser().resolve()
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with closing(self._connect()) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS recipe_outcomes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    platform TEXT NOT NULL,
                    flow TEXT NOT NULL,
                    recipe_id TEXT NOT NULL,
                    recipe_version TEXT NOT NULL,
                    succeeded INTEGER NOT NULL,
                    confidence REAL NOT NULL,
                    details_json TEXT NOT NULL,
                    recorded_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS recipe_patches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    platform TEXT NOT NULL,
                    flow TEXT NOT NULL,
                    state TEXT NOT NULL,
                    source TEXT NOT NULL,
                    shadow_run_success INTEGER NOT NULL DEFAULT 0,
                    shadow_run_count INTEGER NOT NULL DEFAULT 0,
                    recipe_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS recovery_improvements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    patch_id INTEGER NOT NULL,
                    tx_id TEXT NOT NULL,
                    platform TEXT NOT NULL,
                    flow TEXT NOT NULL,
                    status TEXT NOT NULL,
                    artifact_path TEXT NOT NULL,
                    summary_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(patch_id, tx_id)
                )
                """
            )
            columns = {
                row["name"]
                for row in conn.execute("PRAGMA table_info(recipe_patches)").fetchall()
            }
            if "shadow_run_count" not in columns:
                conn.execute(
                    """
                    ALTER TABLE recipe_patches
                    ADD COLUMN shadow_run_count INTEGER NOT NULL DEFAULT 0
                    """
                )
                conn.execute(
                    """
                    UPDATE recipe_patches
                    SET shadow_run_count = CASE
                        WHEN shadow_run_success = 1 THEN 1
                        ELSE 0
                    END
                    """
                )
            conn.commit()

    def record_outcome(
        self,
        *,
        platform: str,
        flow: str,
        recipe_id: str,
        recipe_version: str,
        succeeded: bool,
        confidence: float,
        details: dict[str, Any] | None = None,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        payload = json.dumps(details or {}, ensure_ascii=False, sort_keys=True)
        with closing(self._connect()) as conn:
            conn.execute(
                """
                INSERT INTO recipe_outcomes (
                    platform, flow, recipe_id, recipe_version, succeeded,
                    confidence, details_json, recorded_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    platform,
                    flow,
                    recipe_id,
                    recipe_version,
                    1 if succeeded else 0,
                    confidence,
                    payload,
                    now,
                ),
            )
            conn.commit()

    def list_outcomes(self, *, platform: str, flow: str) -> list[dict[str, Any]]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                """
                SELECT platform, flow, recipe_id, recipe_version, succeeded,
                       confidence, details_json, recorded_at
                FROM recipe_outcomes
                WHERE platform = ? AND flow = ?
                ORDER BY id ASC
                """,
                (platform, flow),
            ).fetchall()
        return [
            {
                "platform": row["platform"],
                "flow": row["flow"],
                "recipe_id": row["recipe_id"],
                "recipe_version": row["recipe_version"],
                "succeeded": bool(row["succeeded"]),
                "confidence": float(row["confidence"]),
                "details": json.loads(row["details_json"]),
                "recorded_at": row["recorded_at"],
            }
            for row in rows
        ]

    def register_patch(
        self,
        *,
        recipe: ExperienceRecipe,
        source: str,
        state: RecipePatchState = RecipePatchState.candidate,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            cursor = conn.execute(
                """
                INSERT INTO recipe_patches (
                    platform, flow, state, source, shadow_run_count,
                    recipe_json, metadata_json, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    recipe.platform,
                    recipe.flow,
                    state.value,
                    source,
                    1 if state == RecipePatchState.shadow_run else 0,
                    recipe.model_dump_json(),
                    json.dumps(metadata or {}, ensure_ascii=False, sort_keys=True),
                    now,
                    now,
                ),
            )
            conn.commit()
            return int(cursor.lastrowid)

    def update_patch_recipe(
        self,
        patch_id: int,
        *,
        recipe: ExperienceRecipe,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        current = self.get_patch(patch_id)
        merged_metadata = dict(current["metadata"])
        if metadata:
            merged_metadata.update(metadata)
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            conn.execute(
                """
                UPDATE recipe_patches
                SET recipe_json = ?, metadata_json = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    recipe.model_dump_json(),
                    json.dumps(merged_metadata, ensure_ascii=False, sort_keys=True),
                    now,
                    patch_id,
                ),
            )
            conn.commit()

    def update_patch_state(
        self,
        patch_id: int,
        *,
        state: RecipePatchState,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        current = self.get_patch(patch_id)
        shadow_run_success = 1 if current["shadow_run_success"] else 0
        if (
            state == RecipePatchState.mainline
            and current["state"] != RecipePatchState.reviewed.value
            and not shadow_run_success
        ):
            raise ValueError(
                "candidate patch cannot become mainline before review or shadow-run success"
            )
        merged_metadata = dict(current["metadata"])
        if metadata:
            merged_metadata.update(metadata)
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            conn.execute(
                """
                UPDATE recipe_patches
                SET state = ?, metadata_json = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    state.value,
                    json.dumps(merged_metadata, ensure_ascii=False, sort_keys=True),
                    now,
                    patch_id,
                ),
            )
            conn.commit()

    def review_patch(
        self,
        patch_id: int,
        *,
        reviewer: str,
        note: str | None = None,
    ) -> None:
        metadata: dict[str, Any] = {"reviewed_by": reviewer}
        if note:
            metadata["review_note"] = note
        self.update_patch_state(
            patch_id,
            state=RecipePatchState.reviewed,
            metadata=metadata,
        )

    def mark_shadow_run_success(
        self,
        patch_id: int,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        current = self.get_patch(patch_id)
        merged_metadata = dict(current["metadata"])
        merged_metadata["shadow_run_success"] = True
        if metadata:
            merged_metadata.update(metadata)
        now = datetime.now(UTC).isoformat()
        shadow_run_count = int(current.get("shadow_run_count", 0)) + 1
        with closing(self._connect()) as conn:
            conn.execute(
                """
                UPDATE recipe_patches
                SET state = ?, shadow_run_success = 1, shadow_run_count = ?,
                    metadata_json = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    RecipePatchState.shadow_run.value,
                    shadow_run_count,
                    json.dumps(merged_metadata, ensure_ascii=False, sort_keys=True),
                    now,
                    patch_id,
                ),
            )
            conn.commit()

    def get_patch(self, patch_id: int) -> dict[str, Any]:
        with closing(self._connect()) as conn:
            row = conn.execute(
                """
                SELECT id, platform, flow, state, source, shadow_run_success,
                       shadow_run_count,
                       recipe_json, metadata_json, created_at, updated_at
                FROM recipe_patches
                WHERE id = ?
                """,
                (patch_id,),
            ).fetchone()
        if row is None:
            raise KeyError(f"patch {patch_id} not found")
        return {
            "id": int(row["id"]),
            "platform": row["platform"],
            "flow": row["flow"],
            "state": row["state"],
            "source": row["source"],
            "shadow_run_success": bool(row["shadow_run_success"]),
            "shadow_run_count": self._shadow_run_count_from_row(row),
            "recipe": ExperienceRecipe.model_validate_json(row["recipe_json"]),
            "metadata": json.loads(row["metadata_json"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def list_patches(
        self,
        *,
        platform: str | None = None,
        flow: str | None = None,
        state: RecipePatchState | None = None,
        source: str | None = None,
    ) -> list[dict[str, Any]]:
        filters: list[str] = []
        values: list[Any] = []
        if platform is not None:
            filters.append("platform = ?")
            values.append(platform)
        if flow is not None:
            filters.append("flow = ?")
            values.append(flow)
        if state is not None:
            filters.append("state = ?")
            values.append(state.value)
        if source is not None:
            filters.append("source = ?")
            values.append(source)
        where_clause = ""
        if filters:
            where_clause = "WHERE " + " AND ".join(filters)
        with closing(self._connect()) as conn:
            rows = conn.execute(
                f"""
                SELECT id
                FROM recipe_patches
                {where_clause}
                ORDER BY id ASC
                """,
                tuple(values),
            ).fetchall()
        return [self.get_patch(int(row["id"])) for row in rows]

    def list_patch_queue(
        self,
        *,
        platform: str | None = None,
        flow: str | None = None,
        source: str | None = None,
        ready_only: bool = False,
        min_shadow_runs: int = 1,
    ) -> list[dict[str, Any]]:
        if min_shadow_runs < 1:
            raise ValueError("min_shadow_runs must be >= 1")
        entries: list[dict[str, Any]] = []
        for patch in self.list_patches(
            platform=platform,
            flow=flow,
            source=source,
        ):
            readiness = self._patch_promotion_readiness(
                patch,
                min_shadow_runs=min_shadow_runs,
            )
            if ready_only and not readiness["promotion_ready"]:
                continue
            entries.append(
                {
                    "id": patch["id"],
                    "platform": patch["platform"],
                    "flow": patch["flow"],
                    "state": patch["state"],
                    "source": patch["source"],
                    "shadow_run_success": patch["shadow_run_success"],
                    "shadow_run_count": patch["shadow_run_count"],
                    "recipe_id": patch["recipe"].recipe_id,
                    "recipe_version": patch["recipe"].version,
                    "updated_at": patch["updated_at"],
                    "min_shadow_runs": min_shadow_runs,
                    **readiness,
                }
            )
        return entries

    def promote_ready_patches(
        self,
        *,
        platform: str | None = None,
        flow: str | None = None,
        source: str | None = None,
        basis: str | None = None,
        actor: str,
        note: str | None = None,
        limit: int | None = None,
        dry_run: bool = False,
        min_shadow_runs: int = 1,
    ) -> list[dict[str, Any]]:
        if limit is not None and limit < 1:
            raise ValueError("limit must be >= 1")
        if basis is not None and basis not in {"reviewed", "shadow_run_success"}:
            raise ValueError("basis must be reviewed or shadow_run_success")
        if min_shadow_runs < 1:
            raise ValueError("min_shadow_runs must be >= 1")

        queue = self.list_patch_queue(
            platform=platform,
            flow=flow,
            source=source,
            ready_only=True,
            min_shadow_runs=min_shadow_runs,
        )
        batch_time = datetime.now(UTC).isoformat()
        batch_id = f"promotion-{batch_time}"
        promoted: list[dict[str, Any]] = []
        for entry in queue:
            if basis is not None and entry["promotion_basis"] != basis:
                continue
            if limit is not None and len(promoted) >= limit:
                break
            metadata: dict[str, Any] = {
                "promotion_basis": entry["promotion_basis"],
                "promotion_batch_id": batch_id,
                "promoted_at": batch_time,
                "promoted_by": actor,
                "promoted_via": "queue_auto",
            }
            if note:
                metadata["promotion_note"] = note
            if not dry_run:
                self.update_patch_state(
                    entry["id"],
                    state=RecipePatchState.mainline,
                    metadata=metadata,
                )
                state = RecipePatchState.mainline.value
            else:
                state = entry["state"]
            promoted.append(
                {
                    "id": entry["id"],
                    "platform": entry["platform"],
                    "flow": entry["flow"],
                    "source": entry["source"],
                    "state": state,
                    "promotion_basis": entry["promotion_basis"],
                    "shadow_run_count": entry["shadow_run_count"],
                    "min_shadow_runs": min_shadow_runs,
                    "dry_run": dry_run,
                    "metadata": metadata,
                }
            )
        return promoted

    def record_recovery_improvement(
        self,
        *,
        patch_id: int,
        tx_id: str,
        platform: str,
        flow: str,
        artifact_path: str,
        summary: dict[str, Any],
    ) -> int:
        now = datetime.now(UTC).isoformat()
        summary_payload = json.dumps(summary, ensure_ascii=False, sort_keys=True)
        metadata_payload = json.dumps({}, ensure_ascii=False, sort_keys=True)
        with closing(self._connect()) as conn:
            existing = conn.execute(
                """
                SELECT id
                FROM recovery_improvements
                WHERE patch_id = ? AND tx_id = ?
                """,
                (patch_id, tx_id),
            ).fetchone()
            if existing is None:
                cursor = conn.execute(
                    """
                    INSERT INTO recovery_improvements (
                        patch_id, tx_id, platform, flow, status, artifact_path,
                        summary_json, metadata_json, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        patch_id,
                        tx_id,
                        platform,
                        flow,
                        RecoveryImprovementStatus.open.value,
                        artifact_path,
                        summary_payload,
                        metadata_payload,
                        now,
                        now,
                    ),
                )
                conn.commit()
                return int(cursor.lastrowid)

            improvement_id = int(existing["id"])
            conn.execute(
                """
                UPDATE recovery_improvements
                SET artifact_path = ?, summary_json = ?, updated_at = ?
                WHERE id = ?
                """,
                (artifact_path, summary_payload, now, improvement_id),
            )
            conn.commit()
            return improvement_id

    def get_recovery_improvement(self, improvement_id: int) -> dict[str, Any]:
        with closing(self._connect()) as conn:
            row = conn.execute(
                """
                SELECT id, patch_id, tx_id, platform, flow, status, artifact_path,
                       summary_json, metadata_json, created_at, updated_at
                FROM recovery_improvements
                WHERE id = ?
                """,
                (improvement_id,),
            ).fetchone()
        if row is None:
            raise KeyError(f"recovery improvement {improvement_id} not found")
        return {
            "id": int(row["id"]),
            "patch_id": int(row["patch_id"]),
            "tx_id": row["tx_id"],
            "platform": row["platform"],
            "flow": row["flow"],
            "status": row["status"],
            "artifact_path": row["artifact_path"],
            "summary": json.loads(row["summary_json"]),
            "metadata": json.loads(row["metadata_json"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def list_recovery_improvements(
        self,
        *,
        status: RecoveryImprovementStatus | None = None,
        platform: str | None = None,
        flow: str | None = None,
    ) -> list[dict[str, Any]]:
        filters: list[str] = []
        values: list[Any] = []
        if status is not None:
            filters.append("status = ?")
            values.append(status.value)
        if platform is not None:
            filters.append("platform = ?")
            values.append(platform)
        if flow is not None:
            filters.append("flow = ?")
            values.append(flow)
        where_clause = ""
        if filters:
            where_clause = "WHERE " + " AND ".join(filters)
        with closing(self._connect()) as conn:
            rows = conn.execute(
                f"""
                SELECT id
                FROM recovery_improvements
                {where_clause}
                ORDER BY id ASC
                """,
                tuple(values),
            ).fetchall()
        return [self.get_recovery_improvement(int(row["id"])) for row in rows]

    def update_recovery_improvement_status(
        self,
        improvement_id: int,
        *,
        status: RecoveryImprovementStatus,
        reviewer: str,
        note: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        current = self.get_recovery_improvement(improvement_id)
        merged_metadata = dict(current["metadata"])
        merged_metadata.update(
            {
                "reviewed_by": reviewer,
                "reviewed_status": status.value,
                "reviewed_at": datetime.now(UTC).isoformat(),
            }
        )
        if note:
            merged_metadata["review_note"] = note
        if metadata:
            merged_metadata.update(metadata)
        now = datetime.now(UTC).isoformat()
        with closing(self._connect()) as conn:
            conn.execute(
                """
                UPDATE recovery_improvements
                SET status = ?, metadata_json = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    status.value,
                    json.dumps(merged_metadata, ensure_ascii=False, sort_keys=True),
                    now,
                    improvement_id,
                ),
            )
            conn.commit()

    def accept_open_recovery_improvements(
        self,
        *,
        reviewer: str,
        note: str | None = None,
        platform: str | None = None,
        flow: str | None = None,
        limit: int | None = None,
        basis: str = "shadow_run_success",
        dry_run: bool = False,
        min_shadow_runs: int = 1,
    ) -> list[dict[str, Any]]:
        if limit is not None and limit < 1:
            raise ValueError("limit must be >= 1")
        if basis not in {"reviewed", "shadow_run_success"}:
            raise ValueError("basis must be one of: reviewed, shadow_run_success")
        if min_shadow_runs < 1:
            raise ValueError("min_shadow_runs must be >= 1")

        results: list[dict[str, Any]] = []
        open_items = self.list_recovery_improvements(
            status=RecoveryImprovementStatus.open,
            platform=platform,
            flow=flow,
        )
        for entry in open_items:
            if limit is not None and len(results) >= limit:
                break

            patch = self.get_patch(entry["patch_id"])
            readiness = self._patch_promotion_readiness(
                patch,
                min_shadow_runs=min_shadow_runs,
            )
            eligible = bool(readiness["promotion_ready"]) and (
                str(readiness["promotion_basis"]) == basis
            )
            action = "accepted" if eligible else "blocked"
            next_status = (
                RecoveryImprovementStatus.accepted.value
                if eligible
                else RecoveryImprovementStatus.open.value
            )
            blocking_reasons = [] if eligible else list(readiness["blocking_reasons"])

            if not dry_run and eligible:
                accept_note = note or f"auto accepted via {basis}"
                self.update_recovery_improvement_status(
                    entry["id"],
                    status=RecoveryImprovementStatus.accepted,
                    reviewer=reviewer,
                    note=accept_note,
                    metadata={
                        "accepted_via": "open_queue_acceptor",
                        "accepted_basis": basis,
                        "accepted_patch_state": patch["state"],
                    },
                )

            results.append(
                {
                    "improvement_id": entry["id"],
                    "patch_id": patch["id"],
                    "platform": entry["platform"],
                    "flow": entry["flow"],
                    "action": action,
                    "basis": basis,
                    "patch_state": patch["state"],
                    "shadow_run_count": patch["shadow_run_count"],
                    "min_shadow_runs": min_shadow_runs,
                    "promotion_basis": readiness["promotion_basis"],
                    "blocking_reasons": blocking_reasons,
                    "improvement_status_before": entry["status"],
                    "improvement_status_after": next_status,
                    "dry_run": dry_run,
                }
            )
        return results

    def process_accepted_recovery_improvements(
        self,
        *,
        reviewer: str,
        note: str | None = None,
        platform: str | None = None,
        flow: str | None = None,
        limit: int | None = None,
        dry_run: bool = False,
    ) -> list[dict[str, Any]]:
        if limit is not None and limit < 1:
            raise ValueError("limit must be >= 1")

        results: list[dict[str, Any]] = []
        accepted = self.list_recovery_improvements(
            status=RecoveryImprovementStatus.accepted,
            platform=platform,
            flow=flow,
        )
        for entry in accepted:
            if limit is not None and len(results) >= limit:
                break

            patch = self.get_patch(entry["patch_id"])
            current_state = str(patch["state"])
            action = "review_patch"
            next_patch_state = RecipePatchState.reviewed.value
            if current_state == RecipePatchState.mainline.value:
                action = "already_mainline"
                next_patch_state = current_state
            elif current_state == RecipePatchState.reviewed.value:
                action = "already_reviewed"
                next_patch_state = current_state

            patch_metadata = {
                "improvement_id": entry["id"],
                "improvement_tx_id": entry["tx_id"],
                "improvement_artifact_path": entry["artifact_path"],
                "improvement_summary": entry["summary"],
                "improvement_applied_by": reviewer,
                "improvement_applied_via": "accepted_queue_processor",
            }
            if note:
                patch_metadata["improvement_apply_note"] = note

            if not dry_run and action == "review_patch":
                self.update_patch_state(
                    patch["id"],
                    state=RecipePatchState.reviewed,
                    metadata=patch_metadata,
                )

            improvement_note = note or f"{action} for patch#{patch['id']}"
            if not dry_run:
                self.update_recovery_improvement_status(
                    entry["id"],
                    status=RecoveryImprovementStatus.applied,
                    reviewer=reviewer,
                    note=improvement_note,
                )

            results.append(
                {
                    "improvement_id": entry["id"],
                    "patch_id": patch["id"],
                    "platform": entry["platform"],
                    "flow": entry["flow"],
                    "action": action,
                    "patch_state_before": current_state,
                    "patch_state_after": next_patch_state,
                    "dry_run": dry_run,
                }
            )
        return results

    def _patch_promotion_readiness(
        self,
        patch: dict[str, Any],
        *,
        min_shadow_runs: int = 1,
    ) -> dict[str, Any]:
        state = str(patch["state"])
        shadow_run_count = int(patch.get("shadow_run_count", 0))
        if state == RecipePatchState.mainline.value:
            return {
                "promotion_ready": False,
                "promotion_basis": "already_mainline",
                "blocking_reasons": ["already_mainline"],
            }
        if state == RecipePatchState.reviewed.value:
            return {
                "promotion_ready": True,
                "promotion_basis": "reviewed",
                "blocking_reasons": [],
            }
        if shadow_run_count >= min_shadow_runs:
            return {
                "promotion_ready": True,
                "promotion_basis": "shadow_run_success",
                "blocking_reasons": [],
            }
        if bool(patch["shadow_run_success"]):
            return {
                "promotion_ready": False,
                "promotion_basis": "not_ready",
                "blocking_reasons": [
                    f"needs_more_shadow_runs:{shadow_run_count}/{min_shadow_runs}"
                ],
            }
        return {
            "promotion_ready": False,
            "promotion_basis": "not_ready",
            "blocking_reasons": ["needs_review_or_shadow_run"],
        }

    @staticmethod
    def _shadow_run_count_from_row(row: sqlite3.Row) -> int:
        count = row["shadow_run_count"] if "shadow_run_count" in row.keys() else None
        if count is None:
            return 1 if bool(row["shadow_run_success"]) else 0
        return int(count)

    def load_mainline_recipe(self, *, platform: str, flow: str) -> ExperienceRecipe | None:
        with closing(self._connect()) as conn:
            row = conn.execute(
                """
                SELECT recipe_json
                FROM recipe_patches
                WHERE platform = ? AND flow = ? AND state = ?
                ORDER BY id DESC
                LIMIT 1
                """,
                (platform, flow, RecipePatchState.mainline.value),
            ).fetchone()
        if row is None:
            return None
        return ExperienceRecipe.model_validate_json(row["recipe_json"])
