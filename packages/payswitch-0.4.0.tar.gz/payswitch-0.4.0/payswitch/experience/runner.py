"""Recipe-backed fast-path runner for payment adapters."""

from __future__ import annotations

import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from payswitch.experience.models import ExperienceRecipe, RecipeWaypoint
from payswitch.models.types import PaymentMethod
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore
from payswitch.security.screenshot_budget import TransactionScreenshotBudget

TelemetryCallback = Callable[[dict[str, Any]], Awaitable[None]]
SemanticAction = Callable[["RecipeRunContext"], Awaitable[None]]
StepRecorder = Callable[[Any], Awaitable[None]]
PolicyCheckpoint = Callable[["RecipeRunContext"], Awaitable[None]]


class RecipeExecutionError(Exception):
    """Structured recipe-runner failure that carries assertion evidence."""

    def __init__(self, message: str, *, failure_context: dict[str, Any]) -> None:
        super().__init__(message)
        self.failure_context = failure_context


@dataclass(slots=True)
class RecipeRunContext:
    recipe: ExperienceRecipe
    waypoint: RecipeWaypoint
    page: Any
    amount: float
    method: PaymentMethod | None
    steps: list[Any]
    record_step: StepRecorder

    def selectors_for(self, key: str | None = None) -> list[str]:
        selectors = list(self.waypoint.selectors)
        if key:
            selectors.extend(self.recipe.selectors.get(key, []))
        if self.waypoint.selector_key:
            selectors.extend(self.recipe.selectors.get(self.waypoint.selector_key, []))
        return selectors

    def texts_for(self, key: str | None = None) -> list[str]:
        texts = list(self.waypoint.texts)
        if key:
            texts.extend(self.recipe.texts.get(key, []))
        if self.waypoint.text_key:
            texts.extend(self.recipe.texts.get(self.waypoint.text_key, []))
        return texts


class RecipeRunner:
    """Execute a recipe with built-in actions and adapter semantic hooks."""

    def __init__(
        self,
        *,
        recipe: ExperienceRecipe,
        semantic_actions: dict[str, SemanticAction],
        telemetry_callback: TelemetryCallback | None = None,
        policy_checkpoint_callback: PolicyCheckpoint | None = None,
        evidence_dir: Path | None = None,
        artifact_store: ArtifactStore | None = None,
        screenshot_budget: TransactionScreenshotBudget | None = None,
    ) -> None:
        self._recipe = recipe
        self._semantic_actions = semantic_actions
        self._telemetry_callback = telemetry_callback
        self._policy_checkpoint_callback = policy_checkpoint_callback
        self._evidence_dir = evidence_dir
        self._artifact_store = artifact_store
        self._screenshot_budget = screenshot_budget

    async def run(
        self,
        *,
        page: Any,
        amount: float,
        method: PaymentMethod | None,
        steps: list[Any],
        record_step: StepRecorder,
    ) -> None:
        for waypoint in self._recipe.waypoints:
            context = RecipeRunContext(
                recipe=self._recipe,
                waypoint=waypoint,
                page=page,
                amount=amount,
                method=method,
                steps=steps,
                record_step=record_step,
            )
            await self._emit(
                kind="waypoint.started",
                waypoint=waypoint,
                page=page,
                extra={},
            )
            try:
                if waypoint.synchronous_policy_checkpoint:
                    await self._emit(
                        kind="waypoint.policy_checkpoint",
                        waypoint=waypoint,
                        page=page,
                        extra={"synchronous_policy_checkpoint": True},
                    )
                    await self._run_policy_checkpoint(context)
                await self._execute_waypoint(context)
                await self._assert_waypoint(context)
            except Exception as exc:
                failure_context = await self._capture_failure_context(context, exc)
                await self._emit(
                    kind="waypoint.failed",
                    waypoint=waypoint,
                    page=page,
                    extra=failure_context,
                )
                raise RecipeExecutionError(
                    f"recipe waypoint failed: {waypoint.id}",
                    failure_context=failure_context,
                ) from exc
            await self._emit(
                kind="waypoint.succeeded",
                waypoint=waypoint,
                page=page,
                extra={},
            )

    async def _run_policy_checkpoint(self, context: RecipeRunContext) -> None:
        from payswitch.adapters.base import ScriptStep

        if self._policy_checkpoint_callback is None:
            raise RuntimeError(
                "recipe waypoint requires synchronous policy checkpoint "
                "but no callback is registered"
            )
        await self._policy_checkpoint_callback(context)
        await context.record_step(
            ScriptStep(
                description=(
                    "同步策略检查通过："
                    f"{context.waypoint.description or context.waypoint.intent}"
                ),
                action="policy_checkpoint",
                category=context.waypoint.category,
                risk=context.waypoint.risk,
                requires_human_authorization=context.waypoint.requires_human_authorization,
            )
        )

    async def _execute_waypoint(self, context: RecipeRunContext) -> None:
        waypoint = context.waypoint
        if waypoint.action == "navigate":
            await self._navigate(context)
            return
        if waypoint.action == "click_first_visible":
            await self._click_first_visible(context)
            return
        if waypoint.action == "wait_for_any":
            await self._wait_for_any(context)
            return
        if waypoint.action == "semantic":
            action_name = waypoint.semantic_action
            if not action_name or action_name not in self._semantic_actions:
                raise RuntimeError(
                    f"recipe semantic action not registered: {action_name or '<missing>'}"
                )
            await self._semantic_actions[action_name](context)
            return
        raise RuntimeError(f"unsupported recipe action: {waypoint.action}")

    async def _navigate(self, context: RecipeRunContext) -> None:
        from payswitch.adapters.base import ScriptStep

        waypoint = context.waypoint
        if not waypoint.url:
            raise RuntimeError(f"recipe navigate waypoint {waypoint.id} is missing url")
        await context.record_step(
            ScriptStep(
                description=waypoint.description or waypoint.intent,
                action="navigate",
                url=waypoint.url,
                category=waypoint.category,
                risk=waypoint.risk,
                requires_human_authorization=waypoint.requires_human_authorization,
            )
        )
        await context.page.goto(waypoint.url, wait_until="domcontentloaded", timeout=15_000)
        wait_for_load_state = getattr(context.page, "wait_for_load_state", None)
        if wait_for_load_state is not None:
            try:
                await wait_for_load_state("networkidle", timeout=5_000)
            except Exception:
                pass

    async def _click_first_visible(self, context: RecipeRunContext) -> None:
        from payswitch.adapters.base import ScriptStep

        selectors = context.selectors_for()
        if not selectors:
            raise RuntimeError(
                f"recipe click waypoint {context.waypoint.id} has no selectors"
            )
        for selector in selectors:
            try:
                element = await context.page.wait_for_selector(selector, timeout=2_000)
                if not element:
                    continue
                await context.record_step(
                    ScriptStep(
                        description=context.waypoint.description or context.waypoint.intent,
                        action="click",
                        selector=selector,
                        category=context.waypoint.category,
                        risk=context.waypoint.risk,
                        requires_human_authorization=(
                            context.waypoint.requires_human_authorization
                        ),
                    )
                )
                await element.click(timeout=15_000)
                return
            except Exception:
                continue
        raise RuntimeError(
            f"recipe click waypoint {context.waypoint.id} could not find a visible selector"
        )

    async def _wait_for_any(self, context: RecipeRunContext) -> None:
        from payswitch.adapters.base import ScriptStep

        selectors = context.selectors_for()
        selectors.extend(f"text={text}" for text in context.texts_for())
        if not selectors:
            raise RuntimeError(
                f"recipe wait waypoint {context.waypoint.id} has no selectors or texts"
            )
        for selector in selectors:
            try:
                await context.page.wait_for_selector(selector, timeout=4_000)
                await context.record_step(
                    ScriptStep(
                        description=context.waypoint.description or context.waypoint.intent,
                        action="wait",
                        selector=selector,
                        category=context.waypoint.category,
                        risk=context.waypoint.risk,
                        requires_human_authorization=(
                            context.waypoint.requires_human_authorization
                        ),
                    )
                )
                return
            except Exception:
                continue
        raise RuntimeError(
            f"recipe wait waypoint {context.waypoint.id} did not observe any expected selector"
        )

    async def _assert_waypoint(self, context: RecipeRunContext) -> None:
        expected = context.waypoint.expected
        failures: dict[str, Any] = {}
        current_url = str(getattr(context.page, "url", ""))
        if expected.url_contains and not any(
            token in current_url for token in expected.url_contains
        ):
            failures["url_contains"] = expected.url_contains

        visible_text = await self._visible_text_summary(context.page)
        if expected.any_texts and not any(text in visible_text for text in expected.any_texts):
            failures["any_texts"] = expected.any_texts
        if context.waypoint.forbidden_texts:
            matched = [text for text in context.waypoint.forbidden_texts if text in visible_text]
            if matched:
                failures["forbidden_texts"] = matched

        if expected.any_selectors:
            matched_selector = False
            for selector in expected.any_selectors:
                if await self._selector_exists(context.page, selector):
                    matched_selector = True
                    break
            if not matched_selector:
                failures["any_selectors"] = expected.any_selectors

        if failures:
            raise RuntimeError(
                f"waypoint assertion failed for {context.waypoint.id}: {failures}"
            )

    async def _capture_failure_context(
        self,
        context: RecipeRunContext,
        exc: Exception,
    ) -> dict[str, Any]:
        try:
            from payswitch.adapters.base import LoginRequiredError
        except Exception:  # pragma: no cover - defensive import fallback
            LoginRequiredError = type("_LoginRequiredError", (), {})
        screenshot_path = await self._capture_screenshot(context.page, context.waypoint.id)
        return {
            "recipe_id": self._recipe.recipe_id,
            "recipe_version": self._recipe.version,
            "waypoint_id": context.waypoint.id,
            "waypoint_intent": context.waypoint.intent,
            "waypoint_category": context.waypoint.category.value,
            "waypoint_risk": context.waypoint.risk.value,
            "current_url": str(getattr(context.page, "url", "")),
            "reason": str(exc),
            "login_required": isinstance(exc, LoginRequiredError),
            "synchronous_policy_checkpoint": context.waypoint.synchronous_policy_checkpoint,
            "failed_assertion": context.waypoint.expected.model_dump(),
            "dom_summary": await self._dom_summary(context.page),
            "visible_text_summary": await self._visible_text_summary(context.page),
            "screenshot_path": str(screenshot_path) if screenshot_path is not None else None,
        }

    async def _capture_screenshot(self, page: Any, waypoint_id: str) -> Path | None:
        if self._evidence_dir is None:
            return None
        screenshot = getattr(page, "screenshot", None)
        if screenshot is None:
            return None
        self._evidence_dir.mkdir(parents=True, exist_ok=True)
        path = self._evidence_dir / (
            f"{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%f')}-{waypoint_id}.png"
        )
        try:
            result = await screenshot()
            if isinstance(result, bytes | bytearray):
                self._persist_screenshot_bytes(path, bytes(result), waypoint_id=waypoint_id)
            else:
                return None
        except TypeError:
            result = await screenshot(path=path)
            if isinstance(result, bytes | bytearray) and not path.exists():
                self._persist_screenshot_bytes(path, bytes(result), waypoint_id=waypoint_id)
            else:
                return None
        except Exception:
            return None
        return path if path.exists() else None

    def _persist_screenshot_bytes(self, path: Path, payload: bytes, *, waypoint_id: str) -> None:
        if self._screenshot_budget is not None:
            decision = self._screenshot_budget.register_capture(
                artifact_kind="recipe_waypoint_screenshot",
                capture_reason=f"recipe waypoint failure screenshot ({waypoint_id})",
                artifact_path=path,
            )
            if not decision.allowed:
                return
        if self._artifact_store is not None:
            self._artifact_store.write_bytes(
                path,
                payload,
                artifact_kind="recipe_waypoint_screenshot",
                sensitivity=ArtifactSensitivity.sensitive,
                content_type="image/png",
                metadata={
                    "recipe_id": self._recipe.recipe_id,
                    "waypoint_id": waypoint_id,
                },
            )
            return
        path.write_bytes(payload)

    async def _emit(
        self,
        *,
        kind: str,
        waypoint: RecipeWaypoint,
        page: Any,
        extra: dict[str, Any],
    ) -> None:
        if self._telemetry_callback is None:
            return
        await self._telemetry_callback(
            {
                "kind": kind,
                "summary": waypoint.intent,
                "message": waypoint.description or waypoint.intent,
                "path": ["Pay-Switch", "Recipe Runner", self._recipe.platform],
                "risk": waypoint.risk.value,
                "target": self._recipe.platform,
                "extra": {
                    "recipe_id": self._recipe.recipe_id,
                    "recipe_version": self._recipe.version,
                    "waypoint_id": waypoint.id,
                    "waypoint_intent": waypoint.intent,
                    "current_url": str(getattr(page, "url", "")),
                    **extra,
                },
            }
        )
        if (
            self._screenshot_budget is not None
            and kind == "waypoint.failed"
            and self._screenshot_budget.snapshot().exhausted
        ):
            state = self._screenshot_budget.snapshot().model_dump(mode="json")
            await self._telemetry_callback(
                {
                    "kind": "artifact.budget_exhausted",
                    "summary": "截图预算已耗尽",
                    "message": state.get("exhaustion_reason")
                    or "recipe failure screenshot budget exhausted",
                    "path": ["Pay-Switch", "Recipe Runner", self._recipe.platform, "Artifacts"],
                    "risk": "medium",
                    "target": self._recipe.platform,
                    "extra": {
                        "recipe_id": self._recipe.recipe_id,
                        "recipe_version": self._recipe.version,
                        "waypoint_id": waypoint.id,
                        "current_url": str(getattr(page, "url", "")),
                        "budget_state": {"screenshots": state},
                    },
                }
            )

    async def _selector_exists(self, page: Any, selector: str) -> bool:
        try:
            locator = page.locator(selector)
            count = getattr(locator, "count", None)
            if count is None:
                return False
            result = count()
            if isinstance(result, Awaitable):
                result = await result
            return int(result) > 0
        except Exception:
            return False

    async def _dom_summary(self, page: Any) -> str:
        try:
            html = await page.evaluate(
                "() => document.body ? document.body.innerHTML.slice(0, 4000) : ''"
            )
        except Exception:
            return ""
        return self._compact_text(str(html))

    async def _visible_text_summary(self, page: Any) -> str:
        try:
            text = await page.evaluate(
                "() => document.body ? (document.body.innerText || '').slice(0, 2000) : ''"
            )
        except Exception:
            return ""
        return self._compact_text(str(text))

    @staticmethod
    def _compact_text(value: str) -> str:
        return re.sub(r"\s+", " ", value).strip()
