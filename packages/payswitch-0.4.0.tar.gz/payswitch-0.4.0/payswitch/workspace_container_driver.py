"""Container driver abstractions for user-scoped workspace runtimes."""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal, Protocol, runtime_checkable

logger = logging.getLogger(__name__)

ContainerDriverKind = Literal["in_memory", "docker"]
ContainerStatus = Literal["running", "stopped", "destroyed"]


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stable_id(prefix: str, raw: str) -> str:
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"{prefix}_{digest[:16]}"


@dataclass(frozen=True)
class WorkspaceContainerSpec:
    workspace_id: str
    user_id: str
    runtime_id: str
    container_image: str
    profile_volume_name: str
    labels: dict[str, str] = field(default_factory=dict)
    environment: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class WorkspaceContainerRecord:
    container_id: str
    container_name: str
    workspace_id: str
    user_id: str
    image: str
    profile_volume_name: str
    status: ContainerStatus
    created_at: str
    started_at: str | None = None
    stopped_at: str | None = None
    labels: dict[str, str] = field(default_factory=dict)


@runtime_checkable
class WorkspaceContainerDriver(Protocol):
    driver_kind: ContainerDriverKind

    @property
    def available(self) -> bool: ...

    @property
    def availability_reason(self) -> str | None: ...

    def start_workspace(
        self,
        *,
        spec: WorkspaceContainerSpec,
        existing: WorkspaceContainerRecord | None = None,
    ) -> WorkspaceContainerRecord: ...

    def stop_workspace(self, record: WorkspaceContainerRecord) -> WorkspaceContainerRecord: ...

    def destroy_workspace(self, record: WorkspaceContainerRecord) -> None: ...


class InMemoryWorkspaceContainerDriver:
    """Lightweight driver used for local tests and non-Docker environments."""

    driver_kind: ContainerDriverKind = "in_memory"

    def __init__(self) -> None:
        self._records: dict[str, WorkspaceContainerRecord] = {}

    @property
    def available(self) -> bool:
        return True

    @property
    def availability_reason(self) -> str | None:
        return None

    def start_workspace(
        self,
        *,
        spec: WorkspaceContainerSpec,
        existing: WorkspaceContainerRecord | None = None,
    ) -> WorkspaceContainerRecord:
        now = _now()
        current = existing or self._records.get(spec.workspace_id)
        if current is None:
            current = WorkspaceContainerRecord(
                container_id=_stable_id("ctr", spec.workspace_id),
                container_name=_stable_id("cname", spec.workspace_id),
                workspace_id=spec.workspace_id,
                user_id=spec.user_id,
                image=spec.container_image,
                profile_volume_name=spec.profile_volume_name,
                status="running",
                created_at=now,
                started_at=now,
                labels=dict(spec.labels),
            )
        else:
            current = WorkspaceContainerRecord(
                container_id=current.container_id,
                container_name=current.container_name,
                workspace_id=current.workspace_id,
                user_id=current.user_id,
                image=spec.container_image,
                profile_volume_name=current.profile_volume_name,
                status="running",
                created_at=current.created_at,
                started_at=now,
                stopped_at=None,
                labels=dict(spec.labels),
            )
        self._records[spec.workspace_id] = current
        return current

    def stop_workspace(self, record: WorkspaceContainerRecord) -> WorkspaceContainerRecord:
        stopped = WorkspaceContainerRecord(
            container_id=record.container_id,
            container_name=record.container_name,
            workspace_id=record.workspace_id,
            user_id=record.user_id,
            image=record.image,
            profile_volume_name=record.profile_volume_name,
            status="stopped",
            created_at=record.created_at,
            started_at=record.started_at,
            stopped_at=_now(),
            labels=dict(record.labels),
        )
        self._records[record.workspace_id] = stopped
        return stopped

    def destroy_workspace(self, record: WorkspaceContainerRecord) -> None:
        self._records.pop(record.workspace_id, None)


class DockerWorkspaceContainerDriver:
    """Docker-backed container driver for one user workspace per runtime."""

    driver_kind: ContainerDriverKind = "docker"

    def __init__(
        self,
        *,
        network_name: str = "payswitch-net",
        runtime_user: str = "911:911",
        memory_limit: str = "2g",
        cpu_quota: int = 100000,
        profile_mount_path: str = "/workspace/profile",
    ) -> None:
        self._network_name = network_name
        self._runtime_user = runtime_user
        self._memory_limit = memory_limit
        self._cpu_quota = cpu_quota
        self._profile_mount_path = profile_mount_path
        self._client: Any = None
        self._availability_reason: str | None = None
        self._initialize()

    @property
    def available(self) -> bool:
        return self._client is not None

    @property
    def availability_reason(self) -> str | None:
        return self._availability_reason

    def _initialize(self) -> None:
        try:
            import docker

            client = docker.from_env()
            client.ping()
            self._client = client
            self._availability_reason = None
        except ImportError:
            self._availability_reason = "docker_sdk_not_installed"
            self._client = None
        except Exception as exc:
            self._availability_reason = f"docker_unavailable:{exc.__class__.__name__}"
            self._client = None

    def _require_client(self) -> Any:
        if self._client is None:
            reason = self._availability_reason or "docker_unavailable"
            raise RuntimeError(f"Docker workspace driver unavailable: {reason}")
        return self._client

    def _ensure_volume(self, name: str) -> None:
        client = self._require_client()
        try:
            client.volumes.get(name)
        except Exception:
            client.volumes.create(name=name, labels={"managed-by": "payswitch"})

    def start_workspace(
        self,
        *,
        spec: WorkspaceContainerSpec,
        existing: WorkspaceContainerRecord | None = None,
    ) -> WorkspaceContainerRecord:
        client = self._require_client()
        self._ensure_volume(spec.profile_volume_name)
        container_name = (
            existing.container_name if existing is not None
            else _stable_id("cname", spec.workspace_id)
        )

        try:
            if existing is not None:
                container = client.containers.get(existing.container_id)
                container.reload()
                if container.status != "running":
                    container.start()
                    container.reload()
                return WorkspaceContainerRecord(
                    container_id=container.id,
                    container_name=container.name,
                    workspace_id=spec.workspace_id,
                    user_id=spec.user_id,
                    image=spec.container_image,
                    profile_volume_name=spec.profile_volume_name,
                    status="running",
                    created_at=existing.created_at,
                    started_at=_now(),
                    labels=dict(spec.labels),
                )
        except Exception:
            logger.info(
                "Workspace container missing or not reusable; creating a new one for %s",
                spec.workspace_id,
            )

        container = client.containers.run(
            image=spec.container_image,
            detach=True,
            auto_remove=False,
            name=container_name,
            command=["sleep", "infinity"],
            mem_limit=self._memory_limit,
            cpu_quota=self._cpu_quota,
            network=self._network_name,
            user=self._runtime_user,
            environment=dict(spec.environment),
            labels={
                "managed-by": "payswitch",
                "workspace-id": spec.workspace_id,
                "user-id": spec.user_id,
                "runtime-id": spec.runtime_id,
                **spec.labels,
            },
            volumes={
                spec.profile_volume_name: {
                    "bind": self._profile_mount_path,
                    "mode": "rw",
                }
            },
        )
        return WorkspaceContainerRecord(
            container_id=container.id,
            container_name=container.name,
            workspace_id=spec.workspace_id,
            user_id=spec.user_id,
            image=spec.container_image,
            profile_volume_name=spec.profile_volume_name,
            status="running",
            created_at=_now(),
            started_at=_now(),
            labels=dict(spec.labels),
        )

    def stop_workspace(self, record: WorkspaceContainerRecord) -> WorkspaceContainerRecord:
        client = self._require_client()
        try:
            container = client.containers.get(record.container_id)
            container.stop(timeout=5)
        except Exception as exc:
            raise RuntimeError(f"failed to stop workspace container: {exc}") from exc
        return WorkspaceContainerRecord(
            container_id=record.container_id,
            container_name=record.container_name,
            workspace_id=record.workspace_id,
            user_id=record.user_id,
            image=record.image,
            profile_volume_name=record.profile_volume_name,
            status="stopped",
            created_at=record.created_at,
            started_at=record.started_at,
            stopped_at=_now(),
            labels=dict(record.labels),
        )

    def destroy_workspace(self, record: WorkspaceContainerRecord) -> None:
        client = self._require_client()
        try:
            container = client.containers.get(record.container_id)
            try:
                container.stop(timeout=5)
            except Exception:
                pass
            container.remove(force=True)
        except Exception as exc:
            logger.warning(
                "Failed to destroy workspace container %s: %s",
                record.container_id,
                exc,
            )


def build_workspace_container_driver(kind: ContainerDriverKind) -> WorkspaceContainerDriver:
    if kind == "docker":
        return DockerWorkspaceContainerDriver()
    return InMemoryWorkspaceContainerDriver()
