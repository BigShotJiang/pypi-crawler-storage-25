"""Small AI planning layer for the Pay-Switch server.

The planner is intentionally narrow: it turns a normalized payment intent into
human-readable routing guidance and a machine-readable plan. Execution remains
inside Pay-Switch guardrails and never inside the model.
"""

from __future__ import annotations

import json
import os
from typing import Any

from pydantic import BaseModel, Field

from payswitch.agent_language import PaymentIntent, to_psl


class PaymentPlan(BaseModel):
    """AI or fallback plan attached to a payment task."""

    mode: str = "rules_fallback"
    provider: str = "local"
    model: str = "deterministic"
    summary: str
    route: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    next_steps: list[str] = Field(default_factory=list)
    psl: str
    raw_response: str | None = None
    error: str | None = None


class PaymentPlanner:
    """Call a configured chat-completion provider, with a deterministic fallback."""

    def __init__(self) -> None:
        self.provider = os.getenv("PAYSWITCH_AI_PROVIDER", "").strip().lower()
        self.model = os.getenv("PAYSWITCH_AI_MODEL", "").strip()
        self.base_url = os.getenv("PAYSWITCH_AI_BASE_URL", "").strip()
        self.api_key = os.getenv("PAYSWITCH_AI_TOKEN", "").strip()

        if not self.provider:
            if os.getenv("OPENAI_API_KEY"):
                self.provider = "openai"
            elif os.getenv("GITHUB_TOKEN"):
                self.provider = "github"
            else:
                self.provider = "local"

        if self.provider == "openai":
            self.api_key = self.api_key or os.getenv("OPENAI_API_KEY", "").strip()
            self.model = self.model or "gpt-4o-mini"
            self.base_url = self.base_url or "https://api.openai.com/v1/chat/completions"
        elif self.provider == "github":
            self.api_key = self.api_key or os.getenv("GITHUB_TOKEN", "").strip()
            self.model = self.model or "openai/gpt-4o-mini"
            self.base_url = (
                self.base_url or "https://models.github.ai/inference/chat/completions"
            )
        else:
            self.provider = "local"
            self.model = "deterministic"

    async def plan(self, intent: PaymentIntent) -> PaymentPlan:
        """Return an AI-generated plan when possible, otherwise fallback guidance."""

        if self.provider == "local" or not self.api_key:
            return self._fallback(intent, error=None)

        try:
            import httpx

            payload = {
                "model": self.model,
                "temperature": 0.2,
                "messages": [
                    {
                        "role": "system",
                        "content": (
                            "You are Pay-Switch's payment routing planner. "
                            "Return strict JSON only. You do not authorize payment; "
                            "you explain route, risk, and human-gate requirements."
                        ),
                    },
                    {
                        "role": "user",
                        "content": json.dumps(
                            {
                                "intent": intent.model_dump(mode="json"),
                                "required_schema": {
                                    "summary": "short Chinese summary",
                                    "route": [
                                        "Guard",
                                        "Protocol or Adapter",
                                        "Human Gate",
                                        "Ledger",
                                    ],
                                    "risks": ["short risk labels"],
                                    "next_steps": ["short actionable steps"],
                                },
                            },
                            ensure_ascii=False,
                        ),
                    },
                ],
            }
            async with httpx.AsyncClient(timeout=25) as client:
                response = await client.post(
                    self.base_url,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )
            if response.status_code >= 400:
                return self._fallback(
                    intent,
                    error=f"{self.provider} returned HTTP {response.status_code}",
                )
            data = response.json()
            text = _extract_chat_text(data)
            parsed = _parse_json_object(text)
            return PaymentPlan(
                mode="ai",
                provider=self.provider,
                model=self.model,
                summary=str(parsed.get("summary") or text[:240]),
                route=[str(item) for item in parsed.get("route", [])],
                risks=[str(item) for item in parsed.get("risks", [])],
                next_steps=[str(item) for item in parsed.get("next_steps", [])],
                psl=to_psl(intent),
                raw_response=text,
            )
        except Exception as exc:  # pragma: no cover - network/provider dependent
            return self._fallback(intent, error=str(exc))

    def _fallback(self, intent: PaymentIntent, *, error: str | None) -> PaymentPlan:
        method = intent.method.value
        route = [
            "Guard / idempotency",
            "A2A payment intent normalization",
            "Protocol connector or site adapter",
            "Human gate for QR/CVV/OTP/final authorization",
            "Ledger evidence write",
        ]
        risks = [
            "final authorization stays human-gated",
            "amount and payee are auditable",
        ]
        if not intent.dry_run:
            risks.append("live execution may open a browser/noVNC session")
        return PaymentPlan(
            mode="rules_fallback",
            provider="local",
            model="deterministic",
            summary=(
                f"准备向 {intent.payee} 发起 {intent.currency} {intent.amount:g} "
                f"支付请求，方式={method}。"
            ),
            route=route,
            risks=risks,
            next_steps=[
                "run spending guard",
                "select payment capability",
                "emit SSE/A2A task events",
                "wait for human authorization when required",
            ],
            psl=to_psl(intent),
            error=error,
        )


def _extract_chat_text(data: dict[str, Any]) -> str:
    choices = data.get("choices")
    if isinstance(choices, list) and choices:
        message = choices[0].get("message") if isinstance(choices[0], dict) else None
        if isinstance(message, dict) and isinstance(message.get("content"), str):
            return message["content"].strip()
    output = data.get("output")
    if isinstance(output, str):
        return output.strip()
    return json.dumps(data, ensure_ascii=False)


def _parse_json_object(text: str) -> dict[str, Any]:
    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            try:
                parsed = json.loads(text[start : end + 1])
                return parsed if isinstance(parsed, dict) else {}
            except json.JSONDecodeError:
                return {}
    return {}
