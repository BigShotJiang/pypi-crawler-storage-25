"""External-agent driven checkout runner.

The external runner is the concrete `computer_use_driver=external` path:
the caller supplies page decisions as structured actions, while Payswitch owns
the browser context, safety gates, payment-state detection, human gate, and
ledger updates.
"""

from __future__ import annotations

import asyncio
import base64
import logging
import re
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field

from payswitch.browser.controller import BrowserController, BrowserControllerError
from payswitch.browser.detector import DetectionResult, DetectorPipeline
from payswitch.browser.display import DisplayManager
from payswitch.browser.profiles import ProfileManager
from payswitch.browser.runtime import build_browser_runtime_plan
from payswitch.engine.events import RuntimeEventSink
from payswitch.engine.guard import SpendingGuard
from payswitch.engine.ledger import Ledger
from payswitch.engine.risk import RiskGate
from payswitch.engine.selector import (
    PaymentMethodResolver,
    detect_available_methods_from_page_state,
)
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import HumanAction, StepRecord, Transaction
from payswitch.models.types import (
    DisplayMode,
    ExecutionMode,
    PaymentMethod,
    StepCategory,
    StepRisk,
    TransactionStatus,
)
from payswitch.security.artifacts import (
    ArtifactSensitivity,
    ArtifactStore,
    decode_data_url_payload,
)
from payswitch.security.redaction import redact_sensitive_data
from payswitch.security.screenshot_budget import TransactionScreenshotBudget

logger = logging.getLogger(__name__)

_ACTIVE_VISIBLE_BROWSERS: dict[str, BrowserController] = {}


class ExternalAction(BaseModel):
    """One bounded browser action proposed by an external agent."""

    type: Literal[
        "observe",
        "navigate",
        "fill",
        "fill_card",
        "set_value",
        "click_text",
        "click_index",
        "wait",
        "scan",
        "ack_human_gate",
    ]
    description: str = ""
    url: str | None = None
    selector: str | None = None
    value: str | None = None
    secret_ref: str | None = None
    text: str | None = None
    exact: bool = False
    index: int | None = None
    seconds: float = Field(default=1.0, ge=0.0, le=30.0)
    include_screenshot_base64: bool = False
    observe_limit: int = Field(default=80, ge=1, le=200)
    text_limit: int = Field(default=80, ge=1, le=200)
    category: StepCategory = StepCategory.checkout_prep
    risk: StepRisk = StepRisk.low
    detect_after: bool = True


class ExternalStepResult(BaseModel):
    """Result returned after one external-agent action."""

    transaction: Transaction
    action_result: Any = None
    detection: DetectionResult | None = None
    resumed_url: str | None = None
    current_url: str | None = None


class ExternalCheckoutRunner:
    """Run an externally reasoned checkout inside Payswitch guardrails."""

    def __init__(self, config: PaySwitchConfig) -> None:
        self._config = config
        self._ledger = Ledger(config.data_dir / "payswitch.db")
        self._guard = SpendingGuard(config, self._ledger)
        self._profile_manager = ProfileManager(config.data_dir / "profiles")
        self._display_manager = DisplayManager(config.display_mode)
        self._detector_pipeline = DetectorPipeline()
        self._risk_gate = RiskGate(config)
        self._method_resolver = PaymentMethodResolver(config)
        self._events = RuntimeEventSink(config)
        self._artifact_store = ArtifactStore(
            config.data_dir,
            public_retention_hours=config.artifact_public_retention_hours,
            internal_retention_hours=config.artifact_internal_retention_hours,
            sensitive_retention_hours=config.artifact_sensitive_retention_hours,
        )

    async def run(
        self,
        *,
        amount: float,
        payee: str,
        actions: list[ExternalAction],
        reason: str = "",
        method: PaymentMethod = PaymentMethod.auto,
        idempotency_key: str | None = None,
        stop_on_human: bool = False,
    ) -> Transaction:
        """Execute a caller-supplied external action plan."""
        guard_result = self._guard.check(
            amount=amount,
            payee=payee,
            idempotency_key=idempotency_key,
        )
        if guard_result.existing_tx is not None:
            return guard_result.existing_tx

        if not guard_result.allowed:
            now = datetime.now(UTC)
            return Transaction(
                amount=amount,
                payee=payee,
                reason=reason,
                payment_method=method if method != PaymentMethod.auto else None,
                execution_mode=ExecutionMode.computer_use,
                status=TransactionStatus.failed,
                completed_at=now,
                error=guard_result.reason,
            )

        tx = Transaction(
            amount=amount,
            payee=payee,
            reason=reason,
            payment_method=method if method != PaymentMethod.auto else None,
            idempotency_key=idempotency_key,
            execution_mode=ExecutionMode.computer_use,
            status=TransactionStatus.pending,
        )
        screenshot_budget = TransactionScreenshotBudget.from_transaction(
            tx,
            limit=self._config.transaction_max_screenshots,
        )
        tx = screenshot_budget.apply(tx)
        self._ledger.record(tx)
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            execution_mode=ExecutionMode.computer_use,
        )
        tx = tx.model_copy(update={"status": TransactionStatus.executing})
        self._emit_event(
            tx,
            "intent.received",
            "收到外部 Agent 支付意图",
            f"{payee} {amount:.2f} {self._config.default_currency} | {reason}",
            source="codex",
            path=["External Agent", "Pay-Switch"],
            target=payee,
        )
        self._emit_event(
            tx,
            "guard.passed",
            "安全检查通过",
            guard_result.reason or "额度、白名单和幂等检查已通过。",
            path=["External Agent", "Pay-Switch", "Guard"],
            risk="low",
            target=payee,
        )
        self._emit_event(
            tx,
            "route.selected",
            "进入 external Computer Use 执行路径",
            "外部 Agent 负责观察和提议动作，Pay-Switch 负责执行、拦截、留证和人工闸门。",
            path=["External Agent", "Pay-Switch", "External Computer Use"],
            risk="low",
            target=payee,
        )

        browser: BrowserController | None = None
        try:
            browser = await self._acquire_browser(tx.payee, tx.tx_id)

            for action in actions:
                tx = await self._run_action(
                    browser,
                    tx,
                    action,
                    screenshot_budget=screenshot_budget,
                )
                if not action.detect_after:
                    continue
                detection = await self._detector_pipeline.scan(browser.page)
                if detection is None:
                    continue
                self._emit_detection_event(tx, detection)

                if detection.action_type == "completed":
                    tx = self._complete(tx)
                    return tx

                if self._requires_human(detection):
                    tx = await self._handle_human_detection(
                        browser=browser,
                        detection=detection,
                        tx=tx,
                        stop_on_human=stop_on_human,
                    )
                    return tx

            return tx
        except Exception as exc:
            error = f"external checkout failed: {type(exc).__name__}: {exc}"
            if isinstance(exc, BrowserControllerError):
                logger.warning("External checkout browser failed for %s: %s", tx.tx_id, exc)
            else:
                logger.exception("External checkout failed for %s", tx.tx_id)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(UTC),
                execution_mode=ExecutionMode.computer_use,
                error=error,
                steps=tx.steps,
                budget_state=tx.budget_state,
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(UTC),
                    "error": error,
                }
            )
            return tx
        finally:
            if browser is not None:
                await self._release_browser(tx, browser)

    async def act(
        self,
        *,
        tx_id: str,
        action: ExternalAction,
        start_url: str | None = None,
        stop_on_human: bool = True,
    ) -> ExternalStepResult:
        """Execute one external-agent action against an existing transaction.

        This is the step-by-step external Computer Use loop: the outside agent
        observes a page, chooses a bounded action, and Pay-Switch executes that
        action under RiskGate, detector, human-gate, and ledger controls.
        """
        tx = self._ledger.get(tx_id)
        if tx is None:
            raise ValueError(f"交易不存在：{tx_id}")
        screenshot_budget = TransactionScreenshotBudget.from_transaction(
            tx,
            limit=self._config.transaction_max_screenshots,
        )
        tx = screenshot_budget.apply(tx)
        if tx.is_terminal():
            raise ValueError(f"交易已处于终态：{tx.status.value}")
        prior_blocking_hint = self._last_blocking_interaction_hint(tx)
        if prior_blocking_hint is not None and action.type == "ack_human_gate":
            return self._ack_blocking_interaction_hint(
                hint=prior_blocking_hint,
                tx=tx,
                action=action,
            )
        if prior_blocking_hint is not None and action.type != "observe":
            blocked_tx = await self._handle_blocking_interaction_hint(
                hint=prior_blocking_hint,
                tx=tx,
            )
            return ExternalStepResult(
                transaction=blocked_tx,
                action_result={
                    "kind": "blocked_by_interaction_hint",
                    "interaction_hint": prior_blocking_hint,
                    "message": "当前页面存在未解除的人类闸门，请先完成用户操作后重新 observe。",
                },
                resumed_url=None,
                current_url=self._last_evidence_url(tx),
            )

        browser: BrowserController | None = None
        try:
            browser = await self._acquire_browser(tx.payee, tx.tx_id)
            current_url_before = await browser.get_current_url()
            resumed_url = None
            explicit_start_url = start_url is not None
            if start_url is None and action.type != "navigate":
                start_url = self._last_evidence_url(tx)
            if start_url:
                should_navigate = (
                    explicit_start_url
                    or not browser.reused_existing_page
                    or current_url_before in ("", "about:blank")
                )
                if should_navigate:
                    resumed_url = start_url
                    await browser.navigate(start_url)
                    await self._settle(browser.page)
                else:
                    resumed_url = current_url_before or start_url

            tx, action_result, current_url = await self._run_action_with_result(
                browser,
                tx,
                action,
                screenshot_budget=screenshot_budget,
            )
            detection = None
            if action.detect_after:
                detection = await self._detector_pipeline.scan(browser.page)
                if detection is not None:
                    self._emit_detection_event(tx, detection)
                    if detection.action_type == "completed":
                        tx = self._complete(tx)
                    elif self._requires_human(detection):
                        tx = await self._handle_human_detection(
                            browser=browser,
                            detection=detection,
                            tx=tx,
                            stop_on_human=stop_on_human,
                        )

            return ExternalStepResult(
                transaction=tx,
                action_result=action_result,
                detection=detection,
                resumed_url=resumed_url,
                current_url=current_url,
            )
        except Exception as exc:
            error = f"external action failed: {type(exc).__name__}: {exc}"
            if isinstance(exc, BrowserControllerError):
                logger.warning("External action browser failed for %s: %s", tx.tx_id, exc)
            else:
                logger.exception("External action failed for %s", tx.tx_id)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                execution_mode=ExecutionMode.computer_use,
                completed_at=datetime.now(UTC),
                error=error,
                steps=tx.steps,
                budget_state=tx.budget_state,
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(UTC),
                    "error": error,
                }
            )
            return ExternalStepResult(transaction=tx)
        finally:
            if browser is not None:
                await self._release_browser(tx, browser)

    async def _run_action(
        self,
        browser: BrowserController,
        tx: Transaction,
        action: ExternalAction,
        *,
        screenshot_budget: TransactionScreenshotBudget,
    ) -> Transaction:
        updated_tx, _, _ = await self._run_action_with_result(
            browser,
            tx,
            action,
            screenshot_budget=screenshot_budget,
        )
        return updated_tx

    async def _run_action_with_result(
        self,
        browser: BrowserController,
        tx: Transaction,
        action: ExternalAction,
        *,
        screenshot_budget: TransactionScreenshotBudget,
    ) -> tuple[Transaction, Any, str | None]:
        decision = self._risk_gate.can_run_autonomously(
            category=action.category,
            risk=action.risk,
        )
        self._emit_event(
            tx,
            "action.proposed",
            action.description or self._describe_action(action),
            f"category={action.category.value}, risk={action.risk.value}",
            source="codex",
            path=["External Agent", "Pay-Switch", "RiskGate"],
            risk=self._event_risk(action.risk),
            target=self._action_target(action),
        )
        if not decision.allowed:
            self._emit_event(
                tx,
                "action.blocked",
                "动作被 RiskGate 拦截",
                decision.reason,
                path=["External Agent", "Pay-Switch", "RiskGate"],
                risk=self._event_risk(action.risk),
                target=self._action_target(action),
            )
            raise RuntimeError(f"action blocked by RiskGate: {decision.reason}")

        now = datetime.now(UTC)
        step = StepRecord(
            step_index=len(tx.steps),
            description=action.description or self._describe_action(action),
            status="pending",
            started_at=now,
            category=action.category,
            risk=action.risk,
        )
        tx = tx.model_copy(
            update={
                "status": TransactionStatus.executing,
                "execution_mode": ExecutionMode.computer_use,
                "steps": [*tx.steps, step],
            }
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            execution_mode=ExecutionMode.computer_use,
            steps=tx.steps,
        )

        current_url = await browser.get_current_url()
        result = await self._execute_action(
            browser=browser,
            action=action,
            tx=tx,
            step_index=step.step_index,
            current_url=current_url,
            screenshot_budget=screenshot_budget,
        )
        tx = screenshot_budget.apply(tx)
        if isinstance(result, dict):
            display_url = self._visible_display_url()
            if display_url:
                result.setdefault("display_url", display_url)
            result.setdefault(
                "budget_state",
                tx.budget_state.model_dump(mode="json") if tx.budget_state is not None else None,
            )
        current_url = await browser.get_current_url()
        evidence_path = self._write_action_evidence(
            tx=tx,
            step_index=step.step_index,
            action=action,
            action_result=result,
            current_url=current_url,
        )

        completed = step.model_copy(
            update={
                "status": "success",
                "completed_at": datetime.now(UTC),
                "evidence_path": str(evidence_path),
            }
        )
        tx = tx.model_copy(update={"steps": [*tx.steps[:-1], completed]})
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            execution_mode=ExecutionMode.computer_use,
            steps=tx.steps,
            budget_state=tx.budget_state,
        )
        event_kind = "observe" if action.type == "observe" else "action.allowed"
        visual_payload = self._action_result_event_payload(result)
        visual_payload.setdefault("current_url", current_url)
        self._emit_event(
            tx,
            event_kind,
            completed.description,
            f"Browser 已执行，证据已写入 {evidence_path}",
            path=["External Agent", "Pay-Switch", "Browser", tx.payee],
            risk=self._event_risk(action.risk),
            target=self._action_target(action) or current_url,
            evidence_path=str(evidence_path),
            **visual_payload,
        )
        return tx, result, current_url

    async def _execute_action(
        self,
        *,
        browser: BrowserController,
        action: ExternalAction,
        tx: Transaction,
        step_index: int,
        current_url: str,
        screenshot_budget: TransactionScreenshotBudget,
    ) -> Any:
        page = browser.page
        if action.type == "observe":
            return await self._observe_page(
                browser=browser,
                action=action,
                tx=tx,
                step_index=step_index,
                current_url=current_url,
                screenshot_budget=screenshot_budget,
            )
        if action.type == "navigate":
            if not action.url:
                raise ValueError("navigate action requires url")
            await browser.navigate(action.url)
            await self._settle(page)
            return None
        if action.type == "fill":
            if not action.selector or action.value is None:
                raise ValueError("fill action requires selector and value")
            await page.locator(action.selector).fill(action.value, timeout=15_000)
            return None
        if action.type == "set_value":
            if not action.selector or action.value is None:
                raise ValueError("set_value action requires selector and value")
            await page.locator(action.selector).evaluate(
                """(el, value) => {
                  el.value = value;
                  el.dispatchEvent(new Event('input', { bubbles: true }));
                  el.dispatchEvent(new Event('change', { bubbles: true }));
                }""",
                action.value,
            )
            return None
        if action.type == "click_text":
            if not action.text:
                raise ValueError("click_text action requires text")
            await browser.list_clickable_elements()
            await browser.click_clickable_text(action.text, exact=action.exact)
            await self._settle(page)
            return None
        if action.type == "click_index":
            if action.index is None:
                raise ValueError("click_index action requires index")
            await browser.list_clickable_elements()
            await browser.click_clickable_index(action.index)
            await self._settle(page)
            return None
        if action.type == "wait":
            await asyncio.sleep(action.seconds)
            return None
        if action.type == "fill_card":
            if not action.secret_ref:
                raise ValueError("fill_card action requires secret_ref")
            from payswitch.engine.card_filler import CardFormFiller

            filler = CardFormFiller()
            fill_result = await filler.detect_and_fill(page, action.secret_ref)
            return {
                "filled_fields": fill_result.filled_fields,
                "human_fields": fill_result.human_fields,
                "needs_human_gate": fill_result.needs_human_gate,
                "processor": fill_result.processor,
            }
        if action.type == "scan":
            return None
        raise ValueError(f"unsupported external action: {action.type}")

    async def _observe_page(
        self,
        *,
        browser: BrowserController,
        action: ExternalAction,
        tx: Transaction,
        step_index: int,
        current_url: str,
        screenshot_budget: TransactionScreenshotBudget,
    ) -> dict[str, Any]:
        screenshot_path = self._screenshot_path(tx.tx_id, step_index)
        decision = screenshot_budget.register_capture(
            artifact_kind="external_observation_screenshot",
            capture_reason=f"external observe screenshot (step {step_index})",
            artifact_path=screenshot_path,
        )
        screenshot_base64 = None
        screenshot_path_value: str | None = None
        if decision.allowed:
            screenshot_bytes = await browser.screenshot()
            self._artifact_store.write_bytes(
                screenshot_path,
                screenshot_bytes,
                artifact_kind="external_observation_screenshot",
                sensitivity=ArtifactSensitivity.sensitive,
                content_type="image/png",
                metadata={"tx_id": tx.tx_id, "step_index": step_index},
            )
            screenshot_path_value = str(screenshot_path)
            if action.include_screenshot_base64:
                screenshot_base64 = base64.b64encode(screenshot_bytes).decode("ascii")
        page_state = await browser.inspect_page_state(
            clickable_limit=action.observe_limit,
            text_limit=action.text_limit,
        )
        observation: dict[str, Any] = {
            "kind": "page_observation",
            "current_url": current_url,
            "screenshot_path": screenshot_path_value,
            "budget_state": {"screenshots": decision.state.model_dump(mode="json")},
            **page_state,
        }
        if not decision.allowed:
            observation["budget_exhausted"] = True
            observation["budget_exhaustion_reason"] = decision.reason
        available_methods = detect_available_methods_from_page_state(page_state)
        if available_methods:
            resolution = self._method_resolver.resolve(
                available_methods=available_methods,
                requested_method=tx.payment_method or PaymentMethod.auto,
            )
            observation["detected_payment_methods"] = [method.value for method in available_methods]
            observation["payment_method_resolution"] = resolution.model_dump(mode="json")
        interaction_hints = self._derive_interaction_hints(
            current_url=current_url,
            page_state=page_state,
            tx=tx,
        )
        if interaction_hints:
            observation["interaction_hints"] = interaction_hints
        if screenshot_base64 is not None:
            observation["screenshot_base64"] = screenshot_base64
        return observation

    def _derive_interaction_hints(
        self,
        *,
        current_url: str,
        page_state: dict[str, Any],
        tx: Transaction,
    ) -> list[dict[str, Any]]:
        """Summarize what the caller agent should ask the user right now."""
        visible_text = [
            str(item).strip() for item in page_state.get("visible_text", []) if str(item).strip()
        ]
        clickables = page_state.get("clickables", [])
        inputs = page_state.get("inputs", [])
        click_texts = [
            str(item.get("text", "")).strip()
            for item in clickables
            if str(item.get("text", "")).strip()
        ]

        all_text = " ".join([current_url, *visible_text, *click_texts]).lower()
        hints: list[dict[str, Any]] = []

        login_terms = [
            "log in",
            "login",
            "sign in",
            "sign_in",
            "password",
            "verification code",
            "scan with wechat to login",
            "手机号登录",
            "验证码登录",
            "登录",
        ]
        if any(term in all_text for term in login_terms):
            required_fields = self._describe_inputs(inputs)
            hints.append(
                {
                    "kind": "requires_login",
                    "blocking": True,
                    "summary": "站点当前处于登录闸门，用户需要先在真实浏览器里完成登录。",
                    "user_message": (
                        "请先完成登录。登录完成后，Agent 应重新观察页面，"
                        "确认是否进入已登录的购买/充值路径。"
                    ),
                    "details": {
                        "current_url": current_url,
                        "required_fields": required_fields,
                    },
                    "suggested_questions": [
                        "请在当前浏览器完成登录后告诉我继续。",
                    ],
                }
            )

        verification_terms = [
            "real-name verification",
            "实名认证",
            "real name",
            "id number",
            "type of id",
            "证件号",
            "实名",
        ]
        verify_button_present = any(text.lower() == "verify" for text in click_texts)
        if any(term in all_text for term in verification_terms) or verify_button_present:
            required_fields = self._describe_inputs(inputs)
            if any(field for field in required_fields) or verify_button_present:
                hints.append(
                    {
                        "kind": "requires_identity_verification",
                        "blocking": True,
                        "summary": "支付前命中了实名/身份验证闸门，必须由用户先补齐身份信息。",
                        "user_message": (
                            "请先完成实名验证。完成后 Agent 再继续推进到下一步支付或授权页面。"
                        ),
                        "details": {
                            "current_url": current_url,
                            "required_fields": required_fields,
                            "entrypoint": "Verify" if verify_button_present else None,
                        },
                        "suggested_questions": [
                            "请在当前浏览器完成实名验证后告诉我继续。",
                        ],
                    }
                )

        cycle_terms = {"monthly", "annually", "annual", "business", "enterprise"}
        plan_question_options = self._dedupe_preserve_order(
            [
                text
                for text in click_texts
                if text.lower() in cycle_terms
                or bool(re.search(r"(subscribe|upgrade your plan)", text, re.I))
            ]
        )
        if len([text for text in plan_question_options if text.lower() in cycle_terms]) >= 2 or any(
            "subscribe" in text.lower() for text in click_texts
        ):
            hints.append(
                {
                    "kind": "requires_plan_confirmation",
                    "blocking": True,
                    "summary": "页面存在多档套餐/计费周期，继续点击前应先和用户确认买哪一种。",
                    "user_message": (
                        "请先确认购买意图，再继续点击套餐。至少要确认周期（月付/年付）、对象（个人/企业）以及具体档位。"
                    ),
                    "details": {
                        "current_url": current_url,
                        "options": plan_question_options[:12],
                        "requested_amount": f"¥{tx.amount:.2f}",
                    },
                    "suggested_questions": [
                        "你要月付还是年付？",
                        "买个人版还是 Business/Enterprise？",
                        "要指定套餐名，还是按最低价格来？",
                    ],
                }
            )

        topup_terms = ["top up", "recharge", "amount", "充值"]
        amount_options = self._dedupe_preserve_order(
            [
                text
                for item in clickables
                for text in [str(item.get("text", "")).strip()]
                if text and re.fullmatch(r"[¥$]\s?\d+(?:\.\d{1,2})?", text)
            ]
        )
        selected_amounts = self._dedupe_preserve_order(
            [
                str(item.get("text", "")).strip()
                for item in clickables
                if str(item.get("text", "")).strip()
                and re.fullmatch(r"[¥$]\s?\d+(?:\.\d{1,2})?", str(item.get("text", "")).strip())
                and any(
                    marker in str(item.get("selector", "")).lower()
                    for marker in ("--active", "--selected", "active", "selected")
                )
            ]
        )
        if len(amount_options) >= 2 and any(term in all_text for term in topup_terms):
            hints.append(
                {
                    "kind": "requires_amount_confirmation",
                    "blocking": False,
                    "summary": "页面提供多档充值金额；如果用户没有明确金额，应先确认再继续。",
                    "user_message": (
                        "请确认本次要充值的具体金额。若用户已经明确金额，则保持当前匹配选项继续执行。"
                    ),
                    "details": {
                        "current_url": current_url,
                        "options": amount_options[:12],
                        "selected": selected_amounts[:4],
                        "requested_amount": f"¥{tx.amount:.2f}",
                    },
                    "suggested_questions": [
                        "这次要充哪一档金额？",
                    ],
                }
            )

        return self._dedupe_hints(hints)

    def _describe_inputs(self, inputs: list[dict[str, Any]]) -> list[str]:
        fields: list[str] = []
        for item in inputs:
            label = (
                item.get("label")
                or item.get("placeholder")
                or item.get("aria_label")
                or item.get("name")
                or item.get("type")
            )
            if label:
                fields.append(str(label).strip())
        return self._dedupe_preserve_order([field for field in fields if field])

    def _dedupe_preserve_order(self, values: list[str]) -> list[str]:
        seen: set[str] = set()
        ordered: list[str] = []
        for value in values:
            normalized = value.strip()
            if not normalized:
                continue
            key = normalized.lower()
            if key in seen:
                continue
            seen.add(key)
            ordered.append(normalized)
        return ordered

    def _dedupe_hints(self, hints: list[dict[str, Any]]) -> list[dict[str, Any]]:
        seen: set[str] = set()
        ordered: list[dict[str, Any]] = []
        for hint in hints:
            kind = str(hint.get("kind", "")).strip().lower()
            if not kind or kind in seen:
                continue
            seen.add(kind)
            ordered.append(hint)
        return ordered

    def _screenshot_path(self, tx_id: str, step_index: int) -> Path:
        evidence_dir = self._config.data_dir / "evidence" / "external"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        return evidence_dir / f"{tx_id}-step-{step_index}.png"

    def _browser_recording_dir(self, tx_id: str) -> Path:
        recording_dir = self._config.data_dir / "evidence" / "external-recordings-raw" / tx_id
        recording_dir.mkdir(parents=True, exist_ok=True)
        return recording_dir

    def _browser_recording_artifact_path(self, tx_id: str, source_path: Path) -> Path:
        artifact_dir = self._config.data_dir / "evidence" / "external-media" / tx_id
        artifact_dir.mkdir(parents=True, exist_ok=True)
        suffix = source_path.suffix if source_path.suffix else ".webm"
        return artifact_dir / f"{source_path.stem}{suffix}"

    @staticmethod
    def _browser_recording_artifact_id(source_path: Path, *, index: int) -> str:
        base = re.sub(r"[^a-zA-Z0-9]+", "_", source_path.name).strip("_").lower()
        if base:
            return base
        return f"external_recording_{index}"

    @staticmethod
    def _browser_recording_capture_engine(recording_source: str) -> str:
        if recording_source == "observation_screenshots":
            return "ffmpeg_replay"
        return "playwright_video"

    def _probe_browser_recording_duration_seconds(self, source_path: Path) -> float | None:
        ffprobe = shutil.which("ffprobe")
        if ffprobe is None:
            return None
        command = [
            ffprobe,
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(source_path),
        ]
        try:
            completed = subprocess.run(command, check=True, capture_output=True)
        except (OSError, subprocess.CalledProcessError):
            logger.debug("ffprobe 读取浏览器录屏时长失败：%s", source_path, exc_info=True)
            return None
        raw = completed.stdout.decode("utf-8", errors="ignore").strip()
        if not raw:
            return None
        try:
            duration = float(raw)
        except ValueError:
            return None
        if duration < 0:
            return None
        return duration

    def _browser_recording_duration_seconds(
        self,
        *,
        source_path: Path,
        recording_source: str,
        tx: Transaction | None,
    ) -> float | None:
        if recording_source == "observation_screenshots" and tx is not None:
            screenshot_count = len(self._collect_observation_screenshots(tx))
            if screenshot_count > 0:
                return float(screenshot_count)
        return self._probe_browser_recording_duration_seconds(source_path)

    def _probe_browser_recording_frame_rate(self, source_path: Path) -> float | None:
        ffprobe = shutil.which("ffprobe")
        if ffprobe is None:
            return None
        command = [
            ffprobe,
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=avg_frame_rate",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(source_path),
        ]
        try:
            completed = subprocess.run(command, check=True, capture_output=True)
        except (OSError, subprocess.CalledProcessError):
            logger.debug("ffprobe 读取浏览器录屏帧率失败：%s", source_path, exc_info=True)
            return None
        raw = completed.stdout.decode("utf-8", errors="ignore").strip()
        if not raw:
            return None
        if "/" in raw:
            numerator_raw, denominator_raw = raw.split("/", 1)
            try:
                numerator = float(numerator_raw)
                denominator = float(denominator_raw)
            except ValueError:
                return None
            if denominator <= 0:
                return None
            frame_rate = numerator / denominator
        else:
            try:
                frame_rate = float(raw)
            except ValueError:
                return None
        if frame_rate < 0:
            return None
        return frame_rate

    def _browser_recording_frame_rate(
        self,
        *,
        source_path: Path,
        recording_source: str,
    ) -> float | None:
        if recording_source == "observation_screenshots":
            return 1.0
        return self._probe_browser_recording_frame_rate(source_path)

    def _probe_browser_recording_frame_dimensions(
        self,
        source_path: Path,
    ) -> tuple[int, int] | tuple[None, None]:
        ffprobe = shutil.which("ffprobe")
        if ffprobe is None:
            return (None, None)
        command = [
            ffprobe,
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=width,height",
            "-of",
            "csv=p=0:s=x",
            str(source_path),
        ]
        try:
            completed = subprocess.run(command, check=True, capture_output=True)
        except (OSError, subprocess.CalledProcessError):
            logger.debug("ffprobe 读取浏览器录屏分辨率失败：%s", source_path, exc_info=True)
            return (None, None)
        raw = completed.stdout.decode("utf-8", errors="ignore").strip()
        if "x" not in raw:
            return (None, None)
        width_raw, height_raw = raw.split("x", 1)
        try:
            width = int(width_raw)
            height = int(height_raw)
        except ValueError:
            return (None, None)
        if width < 0 or height < 0:
            return (None, None)
        return (width, height)

    def _probe_browser_recording_bit_rate(self, source_path: Path) -> int | None:
        ffprobe = shutil.which("ffprobe")
        if ffprobe is None:
            return None
        command = [
            ffprobe,
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=bit_rate",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(source_path),
        ]
        try:
            completed = subprocess.run(command, check=True, capture_output=True)
        except (OSError, subprocess.CalledProcessError):
            logger.debug("ffprobe 读取浏览器录屏码率失败：%s", source_path, exc_info=True)
            return None
        raw = completed.stdout.decode("utf-8", errors="ignore").strip()
        if not raw:
            return None
        try:
            bit_rate = int(raw)
        except ValueError:
            return None
        if bit_rate < 0:
            return None
        return bit_rate

    def _probe_browser_recording_codec_name(self, source_path: Path) -> str | None:
        ffprobe = shutil.which("ffprobe")
        if ffprobe is None:
            return None
        command = [
            ffprobe,
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=codec_name",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(source_path),
        ]
        try:
            completed = subprocess.run(command, check=True, capture_output=True)
        except (OSError, subprocess.CalledProcessError):
            logger.debug("ffprobe 读取浏览器录屏编码失败：%s", source_path, exc_info=True)
            return None
        raw = completed.stdout.decode("utf-8", errors="ignore").strip().lower()
        return raw or None

    def _qr_artifact_path(self, tx_id: str, *, content_type: str) -> Path:
        evidence_dir = self._config.data_dir / "evidence" / "qr"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        suffix = {
            "image/png": ".png",
            "image/jpeg": ".jpg",
            "image/webp": ".webp",
            "image/svg+xml": ".svg",
        }.get(content_type, ".bin")
        timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%f")
        return evidence_dir / f"{tx_id}-{timestamp}-qr{suffix}"

    def _persist_qr_artifact(self, *, tx: Transaction, detection: DetectionResult) -> Path | None:
        qr_src = str(detection.data.get("qr_src") or "").strip()
        if not qr_src.startswith("data:"):
            return None
        decoded = decode_data_url_payload(qr_src)
        if decoded is None:
            return None
        content_type, payload = decoded
        artifact_path = self._qr_artifact_path(tx.tx_id, content_type=content_type)
        self._artifact_store.write_bytes(
            artifact_path,
            payload,
            artifact_kind="payment_qr_payload",
            sensitivity=ArtifactSensitivity.sensitive,
            content_type=content_type,
            metadata={
                "tx_id": tx.tx_id,
                "detector_name": detection.detector_name,
                "action_type": detection.action_type,
                "qr_type": detection.data.get("qr_type"),
            },
        )
        return artifact_path

    def _last_evidence_url(self, tx: Transaction) -> str | None:
        """Return the latest URL recorded by a previous external action."""
        for step in reversed(tx.steps):
            if not step.evidence_path:
                continue
            try:
                data = self._read_evidence_payload(Path(step.evidence_path))
            except Exception:
                continue
            current_url = data.get("current_url")
            if isinstance(current_url, str) and current_url:
                return current_url
        return None

    def _write_action_evidence(
        self,
        *,
        tx: Transaction,
        step_index: int,
        action: ExternalAction,
        action_result: Any,
        current_url: str,
    ) -> Path:
        evidence_dir = self._config.data_dir / "evidence" / "external"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        evidence_path = evidence_dir / f"{tx.tx_id}-step-{step_index}.json"
        payload = {
            "tx_id": tx.tx_id,
            "step_index": step_index,
            "current_url": current_url,
            "action": action.model_dump(mode="json"),
            "action_result": action_result,
            "recorded_at": datetime.now(UTC).isoformat(),
        }
        payload = redact_sensitive_data(payload)
        self._artifact_store.write_json(
            evidence_path,
            payload,
            artifact_kind="external_action",
            sensitivity=ArtifactSensitivity.sensitive,
            metadata={"tx_id": tx.tx_id, "step_index": step_index, "action_type": action.type},
        )
        return evidence_path

    def _blocking_interaction_hint(self, action_result: Any) -> dict[str, Any] | None:
        if not isinstance(action_result, dict):
            return None
        hints = action_result.get("interaction_hints")
        if not isinstance(hints, list):
            return None
        for hint in hints:
            if isinstance(hint, dict) and hint.get("blocking") is True:
                return hint
        return None

    def _last_blocking_interaction_hint(self, tx: Transaction) -> dict[str, Any] | None:
        """Return the latest unresolved blocking hint from action evidence.

        A caller must clear this by asking Pay-Switch to observe again after the
        user has completed the requested human operation. Non-observe actions
        remain blocked so external agents cannot click past login, identity, or
        plan-selection gates.
        """
        for step in reversed(tx.steps):
            if not step.evidence_path:
                continue
            try:
                data = self._read_evidence_payload(Path(step.evidence_path))
            except Exception:
                continue
            hint = self._blocking_interaction_hint(data.get("action_result"))
            if hint is not None:
                return hint
            break
        return None

    def _read_evidence_payload(self, path: Path) -> dict[str, Any]:
        payload = self._artifact_store.read_json(path)
        return payload if isinstance(payload, dict) else {}

    def _ack_blocking_interaction_hint(
        self,
        *,
        hint: dict[str, Any],
        tx: Transaction,
        action: ExternalAction,
    ) -> ExternalStepResult:
        """Record that the user approved a blocking non-payment decision gate."""
        now = datetime.now(UTC)
        details = hint.get("details") if isinstance(hint.get("details"), dict) else {}
        current_url = str(details.get("current_url") or self._last_evidence_url(tx) or "")
        action_result = {
            "kind": "human_gate_acknowledged",
            "message": action.description or "用户已确认当前人工闸门。",
            "acknowledged_hint": hint,
        }
        step_index = len(tx.steps)
        evidence_path = self._write_action_evidence(
            tx=tx,
            step_index=step_index,
            action=action,
            action_result=action_result,
            current_url=current_url,
        )
        next_steps = [
            *tx.steps,
            StepRecord(
                step_index=step_index,
                description=action.description or "用户确认继续执行",
                status="success",
                started_at=now,
                completed_at=now,
                category=StepCategory.identity,
                risk=StepRisk.low,
                evidence_path=str(evidence_path),
            ),
        ]
        completed_human_action = (
            tx.human_action.model_copy(update={"completed_at": now})
            if tx.human_action and tx.human_action.completed_at is None
            else tx.human_action
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            execution_mode=ExecutionMode.computer_use,
            human_action=completed_human_action,
            steps=next_steps,
        )
        next_tx = tx.model_copy(
            update={
                "status": TransactionStatus.executing,
                "steps": next_steps,
                "human_action": completed_human_action,
            }
        )
        self._emit_event(
            next_tx,
            "human.confirmed",
            str(hint.get("summary") or "用户确认继续"),
            action.description or "用户已确认当前人工闸门。",
            source="human",
            path=["User", "Pay-Switch", "External Agent"],
            risk="low",
            target=str(hint.get("kind") or "human_gate"),
            current_url=current_url,
            interaction_hint=hint,
        )
        return ExternalStepResult(
            transaction=next_tx,
            action_result=action_result,
            current_url=current_url,
            resumed_url=current_url,
        )

    async def _settle(self, page: Any) -> None:
        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass

    async def _acquire_browser(self, payee: str, tx_id: str) -> BrowserController:
        browser = _ACTIVE_VISIBLE_BROWSERS.get(tx_id)
        if browser is not None:
            try:
                await browser.get_current_url()
                await self._focus_browser(browser)
                return browser
            except Exception:
                logger.info("交易浏览器已失效，重新拉起可视窗口：%s", tx_id)
                _ACTIVE_VISIBLE_BROWSERS.pop(tx_id, None)
                await self._close_browser_quietly(browser)
                self._persist_browser_recordings(
                    tx_id=tx_id,
                    payee=payee,
                    browser=browser,
                )

        browser = BrowserController()
        await browser.launch(
            profile_dir=self._profile_dir(payee),
            headless=self._browser_should_launch_headless(),
            display=self._browser_display(),
            session_key=tx_id,
            record_video_dir=self._browser_recording_dir(tx_id),
            **self._chrome_launch_kwargs(),
        )
        await self._focus_browser(browser)
        return browser

    async def _release_browser(self, tx: Transaction, browser: BrowserController) -> None:
        if self._should_keep_browser_open(tx):
            _ACTIVE_VISIBLE_BROWSERS[tx.tx_id] = browser
            await self._focus_browser(browser)
            return
        _ACTIVE_VISIBLE_BROWSERS.pop(tx.tx_id, None)
        await self._close_browser_quietly(browser)
        persisted = self._persist_browser_recordings(tx=tx, browser=browser)
        if persisted:
            self._emit_event(
                tx,
                "media.persisted",
                f"已持久化 {len(persisted)} 个浏览器录屏产物",
                "external Computer Use 浏览器录屏已写入 artifact store。",
                source="browser",
                path=["External Agent", "Pay-Switch", "Browser", "Recording"],
                risk="low",
                target=tx.payee,
                media_artifacts=persisted,
            )

    async def _close_browser_quietly(self, browser: BrowserController) -> None:
        try:
            await browser.close()
        except Exception:
            logger.debug("关闭交易浏览器失败（可忽略）", exc_info=True)

    def _collect_observation_screenshots(self, tx: Transaction) -> list[Path]:
        seen: set[str] = set()
        screenshots: list[Path] = []
        for step in tx.steps:
            if not step.evidence_path:
                continue
            try:
                payload = self._read_evidence_payload(Path(step.evidence_path))
            except Exception:
                continue
            action_result = payload.get("action_result")
            if not isinstance(action_result, dict):
                continue
            raw_path = action_result.get("screenshot_path")
            if not isinstance(raw_path, str) or not raw_path.strip():
                continue
            screenshot_path = Path(raw_path).expanduser()
            normalized = str(screenshot_path)
            if normalized in seen or not screenshot_path.exists():
                continue
            seen.add(normalized)
            screenshots.append(screenshot_path)
        return screenshots

    def _synthesize_browser_recording_from_screenshots(
        self,
        *,
        tx: Transaction,
        record_dir: Path,
    ) -> list[Path]:
        ffmpeg = shutil.which("ffmpeg")
        if ffmpeg is None:
            logger.info("ffmpeg 不可用，跳过观察截图回放合成：%s", tx.tx_id)
            return []

        screenshot_paths = self._collect_observation_screenshots(tx)
        if not screenshot_paths:
            return []

        frame_dir = record_dir / "synth-input"
        frame_dir.mkdir(parents=True, exist_ok=True)
        for index, screenshot_path in enumerate(screenshot_paths):
            frame_path = frame_dir / f"frame-{index:04d}.png"
            frame_path.write_bytes(self._artifact_store.read_bytes(screenshot_path))

        output_path = record_dir / "observation-replay.mp4"
        command = [
            ffmpeg,
            "-y",
            "-framerate",
            "1",
            "-i",
            str(frame_dir / "frame-%04d.png"),
            "-vf",
            "pad=ceil(iw/2)*2:ceil(ih/2)*2",
            "-c:v",
            "mpeg4",
            "-q:v",
            "5",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            str(output_path),
        ]
        try:
            subprocess.run(command, check=True, capture_output=True)
        except (OSError, subprocess.CalledProcessError):
            logger.warning("观察截图回放合成失败：%s", tx.tx_id, exc_info=True)
            output_path.unlink(missing_ok=True)
            return []
        if not output_path.exists() or output_path.stat().st_size == 0:
            output_path.unlink(missing_ok=True)
            return []
        return [output_path]

    def _persist_browser_recordings(
        self,
        *,
        tx: Transaction | None = None,
        tx_id: str | None = None,
        payee: str | None = None,
        browser: BrowserController,
    ) -> list[dict[str, Any]]:
        resolved_tx_id = tx.tx_id if tx is not None else tx_id
        resolved_payee = tx.payee if tx is not None else payee
        if not resolved_tx_id or not resolved_payee:
            return []
        raw_recordings: list[tuple[Path, str]] = [
            (path, "native_browser_video") for path in browser.recorded_video_files()
        ]
        record_dir = browser.record_video_dir
        if not raw_recordings and record_dir is not None and tx is not None:
            raw_recordings = [
                (path, "observation_screenshots")
                for path in self._synthesize_browser_recording_from_screenshots(
                    tx=tx,
                    record_dir=record_dir,
                )
            ]
        if not raw_recordings:
            return []
        persisted: list[dict[str, Any]] = []
        for index, (raw_path, recording_source) in enumerate(raw_recordings, start=1):
            payload = raw_path.read_bytes()
            if not payload:
                raw_path.unlink(missing_ok=True)
                continue
            size_bytes = len(payload)
            artifact_id = self._browser_recording_artifact_id(raw_path, index=index)
            capture_engine = self._browser_recording_capture_engine(recording_source)
            duration_seconds = self._browser_recording_duration_seconds(
                source_path=raw_path,
                recording_source=recording_source,
                tx=tx,
            )
            frame_rate = self._browser_recording_frame_rate(
                source_path=raw_path,
                recording_source=recording_source,
            )
            source_screenshot_count = None
            if recording_source == "observation_screenshots" and tx is not None:
                source_screenshot_count = len(self._collect_observation_screenshots(tx))
            frame_width, frame_height = self._probe_browser_recording_frame_dimensions(raw_path)
            bit_rate = self._probe_browser_recording_bit_rate(raw_path)
            codec_name = self._probe_browser_recording_codec_name(raw_path)
            content_type = {
                ".webm": "video/webm",
                ".mp4": "video/mp4",
            }.get(raw_path.suffix.lower(), "application/octet-stream")
            artifact_path = self._browser_recording_artifact_path(resolved_tx_id, raw_path)
            self._artifact_store.write_bytes(
                artifact_path,
                payload,
                artifact_kind="external_browser_recording",
                sensitivity=ArtifactSensitivity.sensitive,
                content_type=content_type,
                metadata={
                    "tx_id": resolved_tx_id,
                    "payee": resolved_payee,
                    "artifact_id": artifact_id,
                    "size_bytes": size_bytes,
                    "recording_index": index,
                    "capture_engine": capture_engine,
                    "duration_seconds": duration_seconds,
                    "frame_rate": frame_rate,
                    "source_screenshot_count": source_screenshot_count,
                    "frame_width": frame_width,
                    "frame_height": frame_height,
                    "bit_rate": bit_rate,
                    "codec_name": codec_name,
                    "recording_source": recording_source,
                    "source_filename": raw_path.name,
                },
            )
            persisted.append(
                {
                    "artifact_id": artifact_id,
                    "artifactId": artifact_id,
                    "recording_index": index,
                    "recordingIndex": index,
                    "artifact_path": str(artifact_path),
                    "content_type": content_type,
                    "name": raw_path.name,
                    "kind": "external_browser_recording",
                    "size_bytes": size_bytes,
                    "sizeBytes": size_bytes,
                    "capture_engine": capture_engine,
                    "captureEngine": capture_engine,
                    "duration_seconds": duration_seconds,
                    "durationSeconds": duration_seconds,
                    "frame_rate": frame_rate,
                    "frameRate": frame_rate,
                    "source_screenshot_count": source_screenshot_count,
                    "sourceScreenshotCount": source_screenshot_count,
                    "frame_width": frame_width,
                    "frameWidth": frame_width,
                    "frame_height": frame_height,
                    "frameHeight": frame_height,
                    "bit_rate": bit_rate,
                    "bitRate": bit_rate,
                    "codec_name": codec_name,
                    "codecName": codec_name,
                    "recording_source": recording_source,
                }
            )
            raw_path.unlink(missing_ok=True)

        if record_dir is not None and record_dir.exists():
            for child in sorted(record_dir.rglob("*"), reverse=True):
                if child.is_file():
                    child.unlink(missing_ok=True)
                else:
                    child.rmdir()
            record_dir.rmdir()
        return persisted

    async def _focus_browser(self, browser: BrowserController) -> None:
        if not self._uses_visible_browser():
            return
        try:
            await browser.page.bring_to_front()
        except Exception:
            logger.debug("前置交易浏览器失败（可忽略）", exc_info=True)

    def _uses_visible_browser(self) -> bool:
        return self._display_manager.mode in {DisplayMode.headed, DisplayMode.novnc}

    def _browser_should_launch_headless(self) -> bool:
        return not self._uses_visible_browser()

    def _browser_display(self) -> str | None:
        if self._display_manager.mode != DisplayMode.novnc:
            return None
        display = self._display_manager.get_display_info().get("display")
        return str(display) if display else ":99"

    def _should_keep_browser_open(self, tx: Transaction) -> bool:
        return self._uses_visible_browser() and not tx.is_terminal()

    def _visible_display_url(self) -> str | None:
        if self._display_manager.mode != DisplayMode.novnc:
            return None
        url = self._display_manager.get_display_info().get("url")
        return str(url) if url else None

    def _complete(self, tx: Transaction) -> Transaction:
        now = datetime.now(UTC)
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.completed,
            execution_mode=ExecutionMode.computer_use,
            completed_at=now,
            steps=tx.steps,
        )
        self._emit_event(
            tx,
            "completed",
            "支付完成并写入 ledger",
            f"交易 {tx.tx_id} 已完成。",
            source="ledger",
            path=["External Agent", "Pay-Switch", "Ledger"],
            risk="low",
            target=tx.payee,
        )
        return tx.model_copy(
            update={"status": TransactionStatus.completed, "completed_at": now}
        )

    async def _handle_blocking_interaction_hint(
        self,
        *,
        hint: dict[str, Any],
        tx: Transaction,
    ) -> Transaction:
        action_type = str(hint.get("kind") or "takeover")
        guidance = str(
            hint.get("user_message")
            or hint.get("summary")
            or "当前步骤需要用户先完成操作。"
        )
        details = hint.get("details") if isinstance(hint.get("details"), dict) else {}
        human_action = HumanAction(
            action_type=action_type,
            requested_at=datetime.now(UTC),
            display_mode=self._display_manager.mode,
            novnc_url=self._display_manager.get_display_info().get("url"),
            guidance=guidance,
            details={
                **details,
                "tx_id": tx.tx_id,
                "amount": f"¥{tx.amount:.2f}",
                "payee": tx.payee,
                "hint": hint,
            },
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=ExecutionMode.computer_use,
            human_action=human_action,
            steps=tx.steps,
        )
        self._emit_event(
            tx,
            "human.gate",
            str(hint.get("summary") or "需要人工介入"),
            guidance,
            source="human",
            path=["External Agent", "Pay-Switch", "Human Gate"],
            risk="high",
            target=action_type,
            current_url=details.get("current_url") if isinstance(details, dict) else None,
            display_url=human_action.novnc_url,
            interaction_hint=hint,
        )
        await self._display_manager.notify_human(
            message=guidance,
            action_type=action_type,
            details=human_action.details or {},
        )
        return tx.model_copy(
            update={
                "status": TransactionStatus.human_action_required,
                "human_action": human_action,
            }
        )

    async def _handle_human_detection(
        self,
        *,
        browser: BrowserController,
        detection: DetectionResult,
        tx: Transaction,
        stop_on_human: bool,
    ) -> Transaction:
        await self._focus_browser(browser)

        details = {
            **detection.data,
            "tx_id": tx.tx_id,
            "amount": f"¥{tx.amount:.2f}",
            "payee": tx.payee,
        }
        qr_artifact_path = self._persist_qr_artifact(tx=tx, detection=detection)
        if qr_artifact_path is not None:
            details["qr_artifact_path"] = str(qr_artifact_path)

        human_action = HumanAction(
            action_type=detection.action_type,
            requested_at=datetime.now(UTC),
            display_mode=self._display_manager.mode,
            novnc_url=self._display_manager.get_display_info().get("url"),
            guidance=detection.description,
            details=details,
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=ExecutionMode.computer_use,
            human_action=human_action,
            steps=tx.steps,
        )
        self._emit_event(
            tx,
            "human.gate",
            detection.description,
            f"{detection.detector_name}:{detection.action_type}",
            source="human",
            path=["External Agent", "Pay-Switch", "Human Gate"],
            risk="high",
            target=detection.action_type,
            display_url=human_action.novnc_url,
            detection_data=details,
        )

        await self._display_manager.notify_human(
            message=detection.description,
            action_type=detection.action_type,
            details={
                **(human_action.details or {}),
            },
        )

        if stop_on_human:
            return tx.model_copy(
                update={
                    "status": TransactionStatus.human_action_required,
                    "human_action": human_action,
                }
            )

        async def _completion_callback() -> bool:
            for detector in self._detector_pipeline._detectors:
                if detector.name == detection.detector_name:
                    return await detector.detect_completion(browser.page)
            return False

        success = await self._display_manager.wait_for_completion(
            detector_callback=_completion_callback,
            timeout=self._config.transaction_timeout,
        )
        if success:
            completed_action = human_action.model_copy(update={"completed_at": datetime.now(UTC)})
            completed_tx = self._complete(tx)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.completed,
                execution_mode=ExecutionMode.computer_use,
                completed_at=completed_tx.completed_at,
                human_action=completed_action,
                steps=tx.steps,
            )
            return completed_tx.model_copy(update={"human_action": completed_action})

        now = datetime.now(UTC)
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.timeout,
            execution_mode=ExecutionMode.computer_use,
            completed_at=now,
            error="等待人工操作超时",
            human_action=human_action,
            steps=tx.steps,
        )
        return tx.model_copy(
            update={
                "status": TransactionStatus.timeout,
                "completed_at": now,
                "error": "等待人工操作超时",
                "human_action": human_action,
            }
        )

    def _requires_human(self, detection: DetectionResult) -> bool:
        for detector in self._detector_pipeline._detectors:
            if detector.name == detection.detector_name:
                return detector.requires_human()
        return True

    def _profile_dir(self, payee: str) -> Path | None:
        if self._uses_user_chrome_context():
            return None
        return self._profile_manager.get_profile_dir(payee)

    def _uses_user_chrome_context(self) -> bool:
        return build_browser_runtime_plan(
            self._config,
            validate_identity=False,
            ensure_cdp=False,
        ).uses_user_chrome

    def _chrome_launch_kwargs(self) -> dict[str, Any]:
        # 已有匹配 CDP 则复用；没有则按绑定 profile 启动真实 Chrome CDP 窗口。
        return build_browser_runtime_plan(
            self._config,
            preflight_occupancy=True,
            ensure_cdp=True,
        ).launch_kwargs

    def _validate_user_chrome_identity(self) -> None:
        build_browser_runtime_plan(self._config, ensure_cdp=True)

    def _emit_detection_event(self, tx: Transaction, detection: DetectionResult) -> None:
        self._emit_event(
            tx,
            "detection",
            detection.description,
            f"{detection.detector_name}:{detection.action_type}",
            source="browser",
            path=["External Agent", "Pay-Switch", "Detector"],
            risk="medium" if self._requires_human(detection) else "low",
            target=detection.action_type,
        )

    def _emit_event(
        self,
        tx: Transaction,
        event_type: str,
        summary: str,
        message: str = "",
        *,
        source: str = "pay_switch",
        path: list[str] | str | None = None,
        risk: str | None = None,
        target: str | None = None,
        **extra: Any,
    ) -> None:
        try:
            self._events.emit(
                tx.tx_id,
                event_type,
                summary,
                message,
                source=source,
                path=path,
                risk=risk,
                target=target,
                payee=tx.payee,
                amount=tx.amount,
                currency=self._config.default_currency,
                **{key: value for key, value in extra.items() if value is not None},
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("Failed to emit runtime event for %s: %s", tx.tx_id, exc)

    @staticmethod
    def _action_result_event_payload(action_result: Any) -> dict[str, Any]:
        if not isinstance(action_result, dict):
            return {}
        payload: dict[str, Any] = {}
        for key in (
            "current_url",
            "screenshot_path",
            "media_artifacts",
            "detected_payment_methods",
            "payment_method_resolution",
            "interaction_hints",
            "budget_state",
            "budget_exhausted",
            "budget_exhaustion_reason",
        ):
            value = action_result.get(key)
            if value is not None:
                payload[key] = value
        return payload

    @staticmethod
    def _event_risk(risk: StepRisk) -> str:
        if risk in {StepRisk.high, StepRisk.human_required}:
            return "high"
        if risk == StepRisk.medium:
            return "medium"
        return "low"

    @staticmethod
    def _action_target(action: ExternalAction) -> str | None:
        if action.type == "navigate":
            return action.url
        if action.type in {"fill", "set_value"}:
            return action.selector
        if action.type == "click_text":
            return action.text
        if action.type == "click_index":
            return str(action.index) if action.index is not None else None
        if action.type == "wait":
            return f"{action.seconds:.1f}s"
        return None

    @staticmethod
    def _describe_action(action: ExternalAction) -> str:
        if action.type == "navigate":
            return f"外部 Agent 导航到 {action.url}"
        if action.type == "fill":
            return f"外部 Agent 填写 {action.selector}"
        if action.type == "set_value":
            return f"外部 Agent 设置 {action.selector}"
        if action.type == "click_text":
            return f"外部 Agent 点击文本 {action.text}"
        if action.type == "click_index":
            return f"外部 Agent 点击元素索引 {action.index}"
        if action.type == "wait":
            return f"外部 Agent 等待 {action.seconds:.1f}s"
        if action.type == "scan":
            return "外部 Agent 请求支付状态检测"
        return "外部 Agent 观察页面"

    def close(self) -> None:
        self._ledger.close()
