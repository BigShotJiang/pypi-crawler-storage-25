"""支付方式路由选择器。

根据用户全局配置的优先级和站点适配器的能力，确定本次支付的最佳执行路径。
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

from payswitch.models.types import PaymentMethod

if TYPE_CHECKING:
    from payswitch.adapters.base import SiteAdapter
    from payswitch.models.config import PaySwitchConfig

logger = logging.getLogger(__name__)


class PaymentMethodResolution(BaseModel):
    """A concrete payment-method routing decision."""

    selected_method: PaymentMethod | None = None
    fallback_methods: list[PaymentMethod] = Field(default_factory=list)
    available_methods: list[PaymentMethod] = Field(default_factory=list)
    requested_method: PaymentMethod = PaymentMethod.auto
    reason: str = ""


def detect_available_methods_from_page_state(
    page_state: dict,
) -> list[PaymentMethod]:
    """Infer payment methods that are visible in an external observation."""
    visible_text = [
        str(item).strip()
        for item in page_state.get("visible_text", [])
        if str(item).strip()
    ]
    click_texts = [
        str(item.get("text", "")).strip()
        for item in page_state.get("clickables", [])
        if str(item.get("text", "")).strip()
    ]
    input_texts = []
    for item in page_state.get("inputs", []):
        input_texts.extend(
            str(item.get(key, "")).strip()
            for key in ("type", "name", "label", "placeholder", "aria_label")
            if str(item.get(key, "")).strip()
        )
    all_text = " ".join([*visible_text, *click_texts, *input_texts]).lower()

    methods: list[PaymentMethod] = []
    if any(term in all_text for term in ("支付宝", "alipay", "蚂蚁")):
        methods.append(PaymentMethod.alipay_qr)
    if any(term in all_text for term in ("微信", "wechat", "wxpay", "tenpay")):
        methods.append(PaymentMethod.wechat_qr)
    if any(
        term in all_text
        for term in (
            "card number",
            "card-number",
            "cardnumber",
            "credit card",
            "debit card",
            "银行卡",
            "信用卡",
            "借记卡",
            "卡号",
            "pan",
        )
    ):
        methods.append(PaymentMethod.card_number_only)
    if any(term in all_text for term in ("stripe", "link by stripe", "stripe checkout")):
        methods.append(PaymentMethod.stripe)

    return _dedupe_methods(methods)


def _dedupe_methods(methods: list[PaymentMethod]) -> list[PaymentMethod]:
    seen: set[PaymentMethod] = set()
    ordered: list[PaymentMethod] = []
    for method in methods:
        if method in seen:
            continue
        seen.add(method)
        ordered.append(method)
    return ordered


class PaymentMethodResolver:
    """Resolve the safest configured method from requested and available methods."""

    def __init__(self, config: PaySwitchConfig) -> None:
        self._config = config

    def resolve(
        self,
        *,
        available_methods: list[PaymentMethod],
        requested_method: PaymentMethod = PaymentMethod.auto,
    ) -> PaymentMethodResolution:
        disabled = set(self._config.disabled_payment_methods)
        available = [
            method for method in _dedupe_methods(available_methods)
            if method not in disabled
        ]
        if (
            PaymentMethod.card_number_only in available
            and not self._config.allow_card_number_only
        ):
            available = [
                method for method in available
                if method != PaymentMethod.card_number_only
            ]

        if requested_method != PaymentMethod.auto:
            if requested_method in disabled:
                return PaymentMethodResolution(
                    available_methods=available,
                    requested_method=requested_method,
                    reason=f"requested method {requested_method.value} is disabled",
                )
            if (
                requested_method == PaymentMethod.card_number_only
                and not self._config.allow_card_number_only
            ):
                return PaymentMethodResolution(
                    available_methods=available,
                    requested_method=requested_method,
                    reason="card_number_only is not enabled in config",
                )
            if requested_method in available:
                return PaymentMethodResolution(
                    selected_method=requested_method,
                    available_methods=available,
                    requested_method=requested_method,
                    reason="requested method is available",
                )
            return PaymentMethodResolution(
                available_methods=available,
                requested_method=requested_method,
                reason=f"requested method {requested_method.value} is not visible on page",
            )

        priority = [
            method for method in self._config.payment_priority
            if method not in disabled
        ]
        if not self._config.allow_card_number_only:
            priority = [
                method for method in priority
                if method != PaymentMethod.card_number_only
            ]
        ranked = [method for method in priority if method in available]
        if not ranked:
            return PaymentMethodResolution(
                available_methods=available,
                requested_method=requested_method,
                reason="no available method matches configured priority",
            )
        return PaymentMethodResolution(
            selected_method=ranked[0],
            fallback_methods=ranked[1:],
            available_methods=available,
            requested_method=requested_method,
            reason="selected by configured payment priority",
        )


class ChannelSelector(PaymentMethodResolver):
    """通道选择器，负责在多个可用支付方式之间进行路由。"""

    def get_ordered_methods(
        self,
        adapter: SiteAdapter | None,
        requested_method: PaymentMethod = PaymentMethod.auto,
    ) -> list[PaymentMethod]:
        """返回本次交易的有序支付方式列表。

        排序逻辑：
        1. 如果指定了明确的 method (非 auto)，则该 method 优先级最高。
        2. 如果有适配器，则取 (用户优先级 ∩ 适配器支持列表) 的交集，保持用户优先级顺序。
        3. 如果无适配器，则返回用户优先级列表。
        """
        # 情况 1：明确指定了某种方式
        if requested_method != PaymentMethod.auto:
            logger.debug("路由选择：用户指定了明确方式 %s", requested_method)
            return [requested_method]

        user_priority = [
            method for method in self._config.payment_priority
            if method not in self._config.disabled_payment_methods
        ]
        if not self._config.allow_card_number_only:
            user_priority = [
                method for method in user_priority
                if method != PaymentMethod.card_number_only
            ]

        # 情况 2：有适配器，进行交集计算
        if adapter is not None:
            supported = getattr(adapter, "supported_methods", [])
            # 过滤出适配器支持的，并保持用户配置的顺序
            ordered = [m for m in user_priority if m in supported]

            # 如果交集为空（适配器声明支持的都不在用户列表里），则回退到适配器默认
            if not ordered and supported:
                logger.warning(
                    "路由选择：用户优先级与适配器支持列表无交集，回退到适配器首选 %s",
                    supported[0],
                )
                return supported

            logger.debug("路由选择：适配器匹配路径 %s", ordered)
            return ordered

        # 情况 3：无适配器（Smart 模式），返回完整用户优先级
        logger.debug("路由选择：无适配器，返回全局优先级 %s", user_priority)
        return user_priority
