"""Pay-Switch 支付流程编排引擎。

PaymentOrchestrator 是整个系统的大脑，负责将所有子系统（守卫、账本、浏览器、
检测器、适配器）串联为完整的支付流程。

执行流程：
  guard.check → 幂等去重 → dry_run → 创建交易 → 加载 Profile → 启动浏览器
  → 脚本模式 or 智能模式 → 步骤检测 → 人类介入（按需）→ 完成 → 关闭浏览器
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from collections.abc import Awaitable, Callable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from payswitch.adapters import AdapterRegistry, LoginRequiredError, ScriptExecutionError, ScriptStep
from payswitch.browser.controller import BrowserController, BrowserControllerError
from payswitch.browser.detector import DetectionResult, DetectorPipeline
from payswitch.browser.display import DisplayManager
from payswitch.browser.profiles import ProfileManager
from payswitch.browser.runtime import build_browser_runtime_plan
from payswitch.engine.guard import SpendingGuard
from payswitch.engine.ledger import Ledger
from payswitch.engine.selector import ChannelSelector
from payswitch.engine.watchdog import RecoveryDecision, RecoveryWatchdog
from payswitch.experience import ExperienceRecipe, RecipePatchState, get_recipe
from payswitch.experience.store import ExperienceStore
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import HumanAction, StepRecord, Transaction
from payswitch.models.types import (
    ComputerUseDriver,
    DisplayMode,
    ExecutionMode,
    PaymentMethod,
    StepCategory,
    StepRisk,
    TransactionStatus,
)
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore
from payswitch.security.screenshot_budget import TransactionScreenshotBudget

logger = logging.getLogger(__name__)

_ACTIVE_VISIBLE_BROWSERS: dict[str, BrowserController] = {}
ProgressSink = Callable[[dict[str, Any]], Awaitable[None]]


# ---------------------------------------------------------------------------
# 自定义异常
# ---------------------------------------------------------------------------


class PaySwitchError(Exception):
    """Pay-Switch 通用异常。

    用于封装各子系统抛出的异常，统一对外接口。
    """


class SmartModeError(Exception):
    """智能模式执行失败异常。"""

    def __init__(self, message: str, *, failure_context: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.failure_context = failure_context


# ---------------------------------------------------------------------------
# 主类：PaymentOrchestrator
# ---------------------------------------------------------------------------


class PaymentOrchestrator:
    """支付流程编排引擎——Pay-Switch 的大脑。

    负责将 SpendingGuard、Ledger、BrowserController、ProfileManager、
    DisplayManager、DetectorPipeline 和各 SiteAdapter 串联为完整的支付流程。

    使用示例::

        config = PaySwitchConfig.load()
        orchestrator = PaymentOrchestrator(config)
        tx = await orchestrator.spend(amount=100.0, payee="deepseek")
        print(tx.status)  # completed / human_action_required / failed
        orchestrator.close()
    """

    def __init__(
        self,
        config: PaySwitchConfig,
        *,
        wait_for_human_completion: bool = True,
        progress_sink: ProgressSink | None = None,
    ) -> None:
        """初始化所有子系统。

        Args:
            config: Pay-Switch 全局配置，含限额、超时、路径等设置
            wait_for_human_completion: 为 True 时在人工闸口等待完成；为 False 时
                通知并持久化 human gate 后立即返回给调用方。
        """
        self._config = config
        self._wait_for_human_completion = wait_for_human_completion
        self._progress_sink = progress_sink

        # 初始化账本（SQLite 持久化）
        db_path = config.data_dir / "payswitch.db"
        self._ledger = Ledger(db_path=db_path)
        logger.debug("账本已初始化：%s", db_path)

        # 初始化安全守卫（依赖 ledger 查询日累计额）
        self._guard = SpendingGuard(config=config, ledger=self._ledger)
        logger.debug("安全守卫已初始化")

        # 初始化 Profile 管理器（浏览器登录状态）
        profiles_dir = config.data_dir / "profiles"
        self._profile_manager = ProfileManager(data_dir=profiles_dir)
        logger.debug("Profile 管理器已初始化：%s", profiles_dir)

        # 初始化显示管理器（headed / noVNC 模式选择）
        self._display_manager = DisplayManager(mode=config.display_mode)
        logger.debug("显示管理器已初始化，模式：%s", self._display_manager.mode)

        # 初始化检测器流水线（按优先级：完成 → QR → 敏感表单 → 确认按钮）
        self._detector_pipeline = DetectorPipeline()
        logger.debug("检测器流水线已初始化")

        # 初始化支付通道选择器
        self._selector = ChannelSelector(config)
        logger.debug("支付通道选择器已初始化")

        # 初始化 recipe outcome / patch 生命周期存储
        self._experience_store = ExperienceStore(config.data_dir / "experience" / "recipes.db")
        logger.debug("Experience store 已初始化")
        self._artifact_store = ArtifactStore(
            config.data_dir,
            public_retention_hours=config.artifact_public_retention_hours,
            internal_retention_hours=config.artifact_internal_retention_hours,
            sensitive_retention_hours=config.artifact_sensitive_retention_hours,
        )
        self._recovery_watchdog = RecoveryWatchdog(
            max_attempts=config.recovery_max_attempts,
            context_ttl_seconds=config.recovery_context_ttl_seconds,
            telemetry_buffer_size=config.recovery_telemetry_buffer_size,
        )

    async def _emit_progress(
        self,
        *,
        kind: str,
        summary: str,
        message: str,
        path: list[str],
        risk: str = "medium",
        target: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        if self._progress_sink is None:
            return
        payload = {
            "kind": kind,
            "summary": summary,
            "message": message,
            "path": path,
            "risk": risk,
            "target": target,
            "extra": extra or {},
        }
        try:
            await self._progress_sink(payload)
        except Exception:
            logger.exception("实时进度事件发送失败")

    def _current_display_url(self) -> str | None:
        display_url = self._display_manager.get_display_info().get("url")
        return str(display_url) if display_url else None

    # ------------------------------------------------------------------
    # 核心公开接口
    # ------------------------------------------------------------------

    async def spend(
        self,
        amount: float,
        payee: str,
        reason: str = "",
        method: PaymentMethod = PaymentMethod.auto,
        idempotency_key: str | None = None,
        url: str | None = None,
        dry_run: bool = False,
        mode: ExecutionMode | None = None,
    ) -> Transaction:
        """执行一次完整的支付编排流程。

        这是 Pay-Switch 的核心入口，调用方只需提供金额和收款方，
        编排引擎负责完成从安全检查到支付确认的全部流程。

        Args:
            amount:          支付金额（元，必须 > 0）
            payee:           收款方平台标识，如 deepseek / kimi
            reason:          支付原因（记录用，非必填）
            method:          指定支付方式，默认 auto（由适配器自选）
            idempotency_key: 幂等键，相同 key 在 48 小时内不重复支付
            url:             智能模式时的目标 URL（无适配器时必须提供）
            dry_run:         试运行模式，通过安全检查后不启动浏览器，直接返回模拟结果

        Returns:
            Transaction 对象，含最终状态（completed / failed / timeout 等）

        Raises:
            不抛出异常：所有错误均通过 Transaction.status 和 Transaction.error 反映
        """
        logger.info(
            "开始支付编排：payee=%s，amount=%.2f，method=%s，dry_run=%s",
            payee,
            amount,
            method,
            dry_run,
        )

        # ---- 第一步：安全检查（guard.check）----
        guard_result = self._guard.check(
            amount=amount,
            payee=payee,
            idempotency_key=idempotency_key,
        )

        # 安全检查未通过 → 构造被拒绝的交易记录并返回
        if not guard_result.allowed:
            logger.warning("安全检查拒绝：%s", guard_result.reason)
            rejected_tx = Transaction(
                amount=amount,
                payee=payee,
                reason=reason,
                payment_method=method,
                idempotency_key=idempotency_key,
                status=TransactionStatus.failed,
                completed_at=datetime.now(UTC),
                error=guard_result.reason,
            )
            # 拒绝记录同样写入账本，保留审计痕迹
            self._ledger.record(rejected_tx)
            return rejected_tx

        # ---- 第二步：幂等命中 → 直接返回已有交易 ----
        if guard_result.existing_tx is not None:
            logger.info("幂等命中，返回已有交易：%s", guard_result.existing_tx.tx_id)
            return guard_result.existing_tx

        # ---- 第三步：dry_run 模式 → 模拟结果，不启动浏览器 ----
        if dry_run:
            adapter = AdapterRegistry.get(payee)
            simulated_mode = ExecutionMode.script if adapter is not None else ExecutionMode.smart
            simulated_executor = "支付脚本" if adapter is not None else "Computer Use 兜底探索"
            # 显示将执行的操作摘要（让用户清楚 dry_run 会走哪些步骤）
            logger.info("========== dry_run 模式：以下为模拟执行计划 ==========")
            logger.info("[步骤 1/4] 安全检查（guard.check）：已通过")
            logger.info(
                "[步骤 2/4] 查找平台适配器：payee=%s（%s）",
                payee,
                "已注册适配器" if adapter is not None else "无适配器，将使用 Computer Use 兜底",
            )
            logger.info(
                "[步骤 3/4] 将启动浏览器并导航到充值页面，执行%s（amount=%.2f，method=%s）",
                simulated_executor,
                amount,
                method.value if method else "auto",
            )
            logger.info("[步骤 4/4] 等待支付确认（扫码 / 密码 / 点击确认）")
            logger.info("========== dry_run 模式结束：不启动浏览器，不执行实际支付 ==========")

            # 记录各模拟步骤，让 CLI 可以展示执行计划
            now = datetime.now(UTC)
            sim_tx = Transaction(
                amount=amount,
                payee=payee,
                reason=reason,
                payment_method=method,
                idempotency_key=idempotency_key,
                execution_mode=simulated_mode,
                status=TransactionStatus.completed,
                completed_at=now,
                steps=[
                    StepRecord(
                        step_index=0,
                        description="[dry_run] 安全检查通过",
                        status="success",
                        started_at=now,
                        completed_at=now,
                    ),
                    StepRecord(
                        step_index=1,
                        description=(
                            f"[dry_run] 查找适配器：{payee} — "
                            + (
                                f"找到适配器 {adapter.__class__.__name__}"
                                if adapter is not None
                                else "无适配器，将使用 Computer Use 兜底"
                            )
                        ),
                        status="success",
                        started_at=now,
                        completed_at=now,
                    ),
                    StepRecord(
                        step_index=2,
                        description=(
                            f"[dry_run] 模拟{simulated_executor}"
                            f"（金额={amount:.2f}，方式={method.value if method else 'auto'}）"
                        ),
                        status="success",
                        started_at=now,
                        completed_at=now,
                    ),
                    StepRecord(
                        step_index=3,
                        description="[dry_run] 模拟支付完成确认",
                        status="success",
                        started_at=now,
                        completed_at=now,
                    ),
                ],
            )
            # dry_run 结果不写入账本（避免污染真实数据）
            return sim_tx

        # ---- 第四步：创建正式交易记录 ----
        tx = Transaction(
            amount=amount,
            payee=payee,
            reason=reason,
            payment_method=method if method != PaymentMethod.auto else None,
            idempotency_key=idempotency_key,
            status=TransactionStatus.pending,
        )
        screenshot_budget = TransactionScreenshotBudget.from_transaction(
            tx,
            limit=self._config.transaction_max_screenshots,
        )
        tx = screenshot_budget.apply(tx)
        self._ledger.record(tx)
        logger.info("交易已创建：%s", tx.tx_id)

        # ---- Stripe 特殊分支：不需要浏览器，直接调用 API ----
        if method == PaymentMethod.stripe:
            logger.info("检测到 Stripe 支付方式，走 API 分支（无需浏览器）")
            try:
                tx = await self._execute_stripe_mode(
                    tx=tx,
                    amount=amount,
                    method=method,
                )
                return tx
            except Exception as exc:
                error_msg = f"Stripe 支付失败：{type(exc).__name__}: {exc}"
                logger.exception("Stripe 支付执行异常")
                self._ledger.update_status(
                    tx.tx_id,
                    TransactionStatus.failed,
                    completed_at=datetime.now(UTC),
                    error=error_msg,
                    steps=tx.steps,
                )
                return tx.model_copy(
                    update={
                        "status": TransactionStatus.failed,
                        "completed_at": datetime.now(UTC),
                        "error": error_msg,
                    }
                )

        # ---- 第五步：加载浏览器上下文 ----
        # 默认使用 Pay-Switch 自管 profile；若配置了用户 Chrome/CDP，则使用用户
        # 指定的真实 Chrome 上下文，不再强制要求 ~/.payswitch/profiles 下存在同名 profile。
        uses_user_chrome = self._uses_user_chrome_context()
        profile = self._profile_manager.get_profile(payee)
        if profile is None and not uses_user_chrome:
            # Profile 不存在：可能用户从未登录过该平台
            error_msg = (
                f"平台 '{payee}' 的 Profile 不存在，请先执行 'payswitch login {payee}' 完成登录"
            )
            logger.error(error_msg)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(UTC),
                error=error_msg,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(UTC),
                    "error": error_msg,
                }
            )

        profile_dir: Path | None = None
        if uses_user_chrome:
            logger.info(
                "使用用户 Chrome 上下文执行：cdp=%s user_data_dir=%s profile=%s",
                self._config.chrome_cdp_url or "<未设置>",
                self._config.chrome_user_data_dir or "<未设置>",
                self._config.chrome_profile_directory or "<default>",
            )
        else:
            profile_dir = self._profile_manager.get_profile_dir(payee)
            logger.info("已加载 Pay-Switch 自管 Profile：%s（目录=%s）", payee, profile_dir)

        # ---- 第六步：启动浏览器 ----
        browser = BrowserController()
        try:
            headless = self._browser_should_launch_headless()
            await browser.launch(
                profile_dir=profile_dir,
                headless=headless,
                display=self._browser_display(),
                session_key=tx.tx_id,
                **self._chrome_launch_kwargs(),
            )
            await self._focus_browser(browser)
            logger.info(
                "浏览器已启动（headless=%s, display=%s）",
                headless,
                self._browser_display(),
            )

            # 更新交易状态为执行中
            self._ledger.update_status(tx.tx_id, TransactionStatus.executing)
            tx = tx.model_copy(update={"status": TransactionStatus.executing})

            adapter = AdapterRegistry.get(payee)
            preflight_url = url
            if preflight_url is None and adapter is not None:
                adapter_preflight_url = getattr(adapter, "preflight_url", None)
                preflight_url = (
                    adapter_preflight_url
                    if isinstance(adapter_preflight_url, str) and adapter_preflight_url
                    else adapter.top_up_url or adapter.login_url
                )

            if mode == ExecutionMode.human_takeover:
                await self._prepare_handoff_page(browser, preflight_url or url)
                tx = await self._human_takeover(browser=browser, tx=tx)
                return tx

            tx = await self._run_access_preflight(
                browser=browser,
                tx=tx,
                payee=payee,
                adapter=adapter,
                url=preflight_url,
            )
            if tx.is_terminal():
                return tx

            # ---- 第七步：执行支付脚本 ----

            if adapter is not None:
                # --- 脚本模式 ---
                logger.info("找到适配器 %s，使用脚本模式", adapter.__class__.__name__)
                tx = tx.model_copy(update={"execution_mode": ExecutionMode.script})
                try:
                    tx = await self._execute_script_mode(
                        adapter=adapter,
                        browser=browser,
                        tx=tx,
                        amount=amount,
                        method=method,
                        screenshot_budget=screenshot_budget,
                    )
                except LoginRequiredError as exc:
                    logger.warning("脚本执行中检测到登录态失效（%s），切换到登录闸门", exc)
                    tx = await self._script_login_handoff(
                        browser=browser,
                        tx=tx,
                        payee=payee,
                        reason=str(exc),
                    )
                    return tx
                except ScriptExecutionError as exc:
                    # 脚本模式失败 → 按恢复策略决定是否继续回退
                    logger.warning("脚本模式失败（%s），进入恢复决策", exc)
                    tx = screenshot_budget.apply(tx)
                    failure_context = self._collect_script_failure_context(
                        tx=tx,
                        exc=exc,
                        adapter=adapter,
                        payee=payee,
                    )
                    decision = self._recovery_watchdog.register_script_failure(
                        tx_id=tx.tx_id,
                        failure_context=failure_context,
                    )
                    failure_context["watchdog_classification"] = decision.classification
                    failure_context["watchdog_recommended_action"] = (
                        decision.recommended_action
                    )

                    # 记录脚本失败步骤
                    fail_step = StepRecord(
                        step_index=len(tx.steps),
                        description=(
                            "脚本模式失败"
                            f"（{decision.classification}），准备进入恢复决策：{exc}"
                        ),
                        status="failed",
                        started_at=datetime.now(UTC),
                        completed_at=datetime.now(UTC),
                    )
                    tx = tx.model_copy(update={"steps": [*tx.steps, fail_step]})
                    tx = await self._checkpoint_script_recovery(
                        browser=browser,
                        tx=tx,
                        adapter=adapter,
                        failure_context=failure_context,
                        decision=decision,
                        screenshot_budget=screenshot_budget,
                    )
                    recovery_patch_id = self._register_recovery_candidate_patch(
                        adapter=adapter,
                        tx=tx,
                        failure_context=failure_context,
                    )

                    if decision.recommended_action == "login_human_gate":
                        logger.info(
                            "脚本失败被分类为登录恢复（%s），要求显式登录闸门",
                            failure_context.get("waypoint_id")
                            or failure_context.get("recipe_id")
                            or "unknown",
                        )
                        return await self._script_login_handoff(
                            browser=browser,
                            tx=tx,
                            payee=payee,
                            reason=str(exc),
                            classification=decision.classification,
                        )

                    if decision.requires_human_gate:
                        if getattr(adapter, "allow_smart_fallback", True):
                            logger.info(
                                "脚本失败要求显式人工接管（classification=%s, waypoint=%s）",
                                decision.classification,
                                failure_context.get("waypoint_id")
                                or failure_context.get("recipe_id")
                                or "unknown",
                            )
                        return await self._script_recovery_handoff(
                            browser=browser,
                            tx=tx,
                            payee=payee,
                            reason=str(exc),
                            classification=decision.classification,
                            failure_context=failure_context,
                        )

                    smart_url = url or adapter.top_up_url
                    if not getattr(adapter, "allow_smart_fallback", True):
                        handoff_step = StepRecord(
                            step_index=len(tx.steps),
                            description=(
                                "脚本模式失败，平台已禁用 Computer Use 自动兜底，"
                                f"切换到人类接管：{exc}"
                            ),
                            status="success",
                            started_at=datetime.now(UTC),
                            completed_at=datetime.now(UTC),
                        )
                        tx = tx.model_copy(update={"steps": [*tx.steps, handoff_step]})
                        self._ledger.update_status(
                            tx.tx_id,
                            TransactionStatus.executing,
                            steps=tx.steps,
                        )
                        # Preserve the partially prepared checkout page. For
                        # these adapters, reloading the top-up URL can discard
                        # the exact modal or QR surface the script already found.
                        return await self._human_takeover(browser=browser, tx=tx)

                    if decision.requires_resync:
                        synced_tx = await self._run_access_preflight(
                            browser=browser,
                            tx=tx,
                            payee=payee,
                            adapter=adapter,
                            url=smart_url,
                        )
                        if synced_tx.is_terminal():
                            return synced_tx
                        tx = await self._resynchronize_recovery_state(
                            browser=browser,
                            tx=synced_tx,
                            failure_context=failure_context,
                            screenshot_budget=screenshot_budget,
                        )

                    # 确定 Computer Use 所用 URL：优先 url 参数，其次适配器的 top_up_url
                    try:
                        self._recovery_watchdog.mark_checkpoint(tx_id=tx.tx_id)
                        tx = await self._execute_computer_use_fallback(
                            browser=browser,
                            tx=tx,
                            amount=amount,
                            payee=payee,
                            method=method,
                            url=smart_url,
                            recovery_patch_id=recovery_patch_id,
                            failure_context=failure_context,
                        )
                    except SmartModeError as smart_exc:
                        # Computer Use 也失败 → 人类接管
                        logger.warning(
                            "Computer Use 兜底失败（%s），切换到人类接管模式",
                            smart_exc,
                        )
                        await self._prepare_handoff_page(browser, smart_url)
                        tx = await self._human_takeover(browser=browser, tx=tx)

            elif url is not None:
                # --- 无适配器 + 有 url → Computer Use 兜底 ---
                logger.info("未找到适配器，使用 Computer Use 兜底，目标 URL=%s", url)
                try:
                    tx = await self._execute_computer_use_fallback(
                        browser=browser,
                        tx=tx,
                        amount=amount,
                        payee=payee,
                        method=method,
                        url=url,
                    )
                except SmartModeError as smart_exc:
                    logger.warning(
                        "Computer Use 兜底失败（%s），切换到人类接管模式",
                        smart_exc,
                    )
                    await self._prepare_handoff_page(browser, url)
                    tx = await self._human_takeover(browser=browser, tx=tx)

            else:
                # --- 无适配器 无 url → 报错 ---
                error_msg = (
                    f"平台 '{payee}' 未找到适配器，且未提供 url 参数，"
                    f"无法执行支付。请注册适配器或通过 --url 参数指定充值页面。"
                )
                logger.error(error_msg)
                self._ledger.update_status(
                    tx.tx_id,
                    TransactionStatus.failed,
                    completed_at=datetime.now(UTC),
                    error=error_msg,
                    steps=tx.steps,
                )
                return tx.model_copy(
                    update={
                        "status": TransactionStatus.failed,
                        "completed_at": datetime.now(UTC),
                        "error": error_msg,
                    }
                )

        except TimeoutError:
            # 全局超时处理
            timeout_msg = f"交易超时（>{self._config.transaction_timeout}s）"
            logger.error("交易 %s 超时", tx.tx_id)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.timeout,
                completed_at=datetime.now(UTC),
                error=timeout_msg,
                steps=tx.steps,
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.timeout,
                    "completed_at": datetime.now(UTC),
                    "error": timeout_msg,
                }
            )

        except Exception as exc:
            # 其他未预期异常 → 标记为 failed
            error_msg = f"支付流程异常终止：{type(exc).__name__}: {exc}"
            if isinstance(exc, BrowserControllerError):
                logger.warning("交易 %s 浏览器启动/控制失败：%s", tx.tx_id, exc)
            else:
                logger.exception("交易 %s 执行时发生未预期异常", tx.tx_id)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(UTC),
                error=error_msg,
                steps=tx.steps,
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(UTC),
                    "error": error_msg,
                }
            )

        finally:
            if tx.is_terminal():
                self._recovery_watchdog.clear(tx.tx_id)
            await self._release_browser(tx, browser)

        logger.info("支付编排完成：tx_id=%s，status=%s", tx.tx_id, tx.status)
        return tx

    async def _release_browser(self, tx: Transaction, browser: BrowserController) -> None:
        if self._should_keep_browser_open(tx):
            _ACTIVE_VISIBLE_BROWSERS[tx.tx_id] = browser
            await self._focus_browser(browser)
            logger.info("保留可见交易浏览器等待人工操作（交易 %s）", tx.tx_id)
            return
        _ACTIVE_VISIBLE_BROWSERS.pop(tx.tx_id, None)
        logger.info("关闭浏览器（交易 %s）", tx.tx_id)
        await self._close_browser_quietly(browser)

    async def _close_browser_quietly(self, browser: BrowserController) -> None:
        try:
            await browser.close()
        except Exception:
            logger.debug("关闭交易浏览器失败（可忽略）", exc_info=True)

    async def _focus_browser(self, browser: BrowserController) -> None:
        if not self._uses_visible_browser():
            return
        try:
            await browser.page.bring_to_front()
        except Exception:
            logger.debug("前置交易浏览器失败（可忽略）", exc_info=True)

    async def _script_login_handoff(
        self,
        *,
        browser: BrowserController,
        tx: Transaction,
        payee: str,
        reason: str,
        classification: str = "login_required",
        execution_mode: ExecutionMode = ExecutionMode.script,
    ) -> Transaction:
        """Turn a mid-checkout login failure into an explicit human gate."""
        await self._focus_browser(browser)
        now = datetime.now(UTC)
        current_url = str(getattr(browser.page, "url", ""))
        display_info = self._display_manager.get_display_info()
        novnc_url: str | None = display_info.get("url")
        step = StepRecord(
            step_index=len(tx.steps),
            description=f"脚本执行中检测到 {payee} 登录态失效：{reason}",
            status="pending",
            started_at=now,
            category=StepCategory.identity,
            risk=StepRisk.low,
        )
        guidance = (
            f"{reason}\n"
            f"请在可见浏览器中完成 {payee} 登录，然后重新发起或继续该付款任务。"
        )
        human_action = HumanAction(
            action_type="login",
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=novnc_url,
            guidance=guidance,
            details={
                "tx_id": tx.tx_id,
                "payee": payee,
                "current_url": current_url,
                "classification": classification,
                "execution_mode": execution_mode.value,
                "next_step": "Complete platform login in the visible browser.",
            },
        )
        tx = tx.model_copy(
            update={
                "status": TransactionStatus.human_action_required,
                "execution_mode": execution_mode,
                "steps": [*tx.steps, step],
                "human_action": human_action,
            }
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=execution_mode,
            steps=tx.steps,
            human_action=human_action,
        )
        await self._display_manager.notify_human(
            message=guidance,
            action_type="login",
            details={**(human_action.details or {})},
        )
        return tx

    def _collect_script_failure_context(
        self,
        *,
        tx: Transaction,
        exc: ScriptExecutionError,
        adapter: Any,
        payee: str,
    ) -> dict[str, Any]:
        """Build a compact, JSON-serializable context for recovery decision and trace."""
        failure_context: dict[str, Any] = {}
        raw_context = getattr(exc, "failure_context", None)
        if isinstance(raw_context, Mapping):
            failure_context.update(self._normalize_recovery_payload(raw_context))

        failure_context.setdefault("failure_type", "script")
        failure_context.setdefault("failure_reason", str(exc))
        failure_context.setdefault("failure_class", exc.__class__.__name__)
        failure_context.setdefault("payee", payee)
        failure_context.setdefault("tx_id", tx.tx_id)
        failure_context.setdefault("amount", tx.amount)
        failure_context.setdefault("currency", tx.currency)
        failure_context.setdefault(
            "payment_method", tx.payment_method.value if tx.payment_method else None
        )
        failure_context.setdefault("steps_executed", len(tx.steps))
        if adapter is not None:
            failure_context.setdefault(
                "adapter",
                getattr(adapter, "name", adapter.__class__.__name__),
            )
            failure_context.setdefault("adapter_class", adapter.__class__.__name__)

        return self._normalize_recovery_payload(failure_context)

    def _normalize_smart_failure_context(
        self,
        failure_context: Mapping[str, Any] | None,
    ) -> dict[str, Any] | None:
        if not isinstance(failure_context, Mapping):
            return None
        normalized = self._normalize_recovery_payload(dict(failure_context))
        normalized.setdefault("failure_type", "computer_use_recovery")
        normalized.setdefault("execution_mode", ExecutionMode.smart.value)
        return normalized

    async def _checkpoint_script_recovery(
        self,
        *,
        browser: BrowserController,
        tx: Transaction,
        adapter: Any,
        failure_context: dict[str, Any],
        decision: RecoveryDecision,
        screenshot_budget: TransactionScreenshotBudget,
    ) -> Transaction:
        """Persist a recovery checkpoint step and optional evidence artifact."""
        now = datetime.now(UTC)
        checkpoint_point = {
            "tx_id": tx.tx_id,
            "payee": tx.payee,
            "decision": decision.reason,
            "classification": decision.classification,
            "recommended_action": decision.recommended_action,
            "requires_resync": decision.requires_resync,
            "stale_buffer_discarded": decision.stale_buffer_discarded,
            "requires_human_gate": decision.requires_human_gate,
            "attempts_remaining": decision.attempts_remaining,
            "failure_context": failure_context,
            "watchdog_state": self._recovery_watchdog.describe_state(tx.tx_id),
        }
        evidence_path = await self._write_recovery_checkpoint_artifact(
            tx_id=tx.tx_id,
            checkpoint=checkpoint_point,
        )
        try:
            tx, screenshot_path = await self._capture_recovery_screenshot(
                browser=browser,
                tx=tx,
                screenshot_budget=screenshot_budget,
                capture_reason="recovery checkpoint screenshot",
            )
        except Exception:
            logger.debug("恢复检查点截图失败（忽略，不影响主流程）", exc_info=True)
            screenshot_path = None

        detail = failure_context.get("waypoint_id") or failure_context.get("recipe_id")
        decision_hint = (
            "将尝试回退到 Computer Use 兜底"
            if not decision.requires_human_gate
            else "将进入人工恢复"
        )
        checkpoint_desc = (
            "脚本模式恢复检查点（"
            f"{detail or '未知节点'}，{decision.classification}，{decision_hint}）"
        )
        if decision.requires_resync:
            checkpoint_desc += "；检测点过期，已触发重预检"
        if decision.stale_buffer_discarded:
            checkpoint_desc += "，旧遥测已丢弃"
        checkpoint_step = StepRecord(
            step_index=len(tx.steps),
            description=checkpoint_desc,
            status="success",
            started_at=now,
            completed_at=now,
            category=StepCategory.checkout_prep,
            risk=StepRisk.medium if not decision.is_high_risk else StepRisk.high,
            evidence_path=str(screenshot_path or evidence_path),
        )
        tx = tx.model_copy(update={"steps": [*tx.steps, checkpoint_step]})
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            execution_mode=ExecutionMode.script,
            steps=tx.steps,
            budget_state=tx.budget_state,
        )
        return tx

    def _register_recovery_candidate_patch(
        self,
        *,
        adapter: Any,
        tx: Transaction,
        failure_context: dict[str, Any],
    ) -> int | None:
        """Register a candidate recipe patch for later review/retry workflows."""
        recipe = self._pick_recovery_recipe(
            adapter=adapter,
            failure_context=failure_context,
        )
        if recipe is None:
            logger.debug("未匹配到可用于恢复补丁的 recipe：tx_id=%s", tx.tx_id)
            return None

        candidate = recipe.model_copy(deep=True)
        failure_text = failure_context.get("failure_reason", "")
        candidate.notes.append(
            f"脚本恢复候选：tx={tx.tx_id}，失败：{failure_text}".strip()
        )
        patch_id = self._experience_store.register_patch(
            recipe=candidate,
            source="script_recovery",
            metadata={
                "tx_id": tx.tx_id,
                "failure_context": self._normalize_recovery_payload(failure_context),
                "decision": {
                    "adapter": failure_context.get("adapter"),
                    "payee": tx.payee,
                    "recipe_id": candidate.recipe_id,
                },
            },
        )
        logger.debug(
            "已记录脚本失败恢复候选补丁：tx_id=%s patch_id=%s recipe_id=%s",
            tx.tx_id,
            patch_id,
            recipe.recipe_id,
        )
        return patch_id

    async def _record_successful_recovery_patch(
        self,
        *,
        browser: BrowserController,
        tx: Transaction,
        patch_id: int | None,
        failure_context: dict[str, Any] | None,
        outcome: str,
        computer_use_steps: list[StepRecord],
        detection: DetectionResult | None,
    ) -> Transaction:
        """Update a recovery patch candidate after Computer Use reaches a valid surface."""
        if patch_id is None or not failure_context:
            return tx

        patch = self._experience_store.get_patch(patch_id)
        recipe = patch["recipe"].model_copy(deep=True)
        waypoint_id = str(failure_context.get("waypoint_id") or "")
        target_waypoint = next(
            (item for item in recipe.waypoints if item.id == waypoint_id),
            None,
        )
        final_url = await browser.get_current_url()
        visible_text_summary = await self._capture_page_text_snapshot(browser.page)
        suggested_texts = self._extract_recovery_patch_markers(
            visible_text_summary=visible_text_summary,
            detection=detection,
        )
        expected_url_tokens: list[str] = []
        parsed_url = urlparse(final_url)
        if parsed_url.path and parsed_url.path != "/":
            expected_url_tokens.append(parsed_url.path)

        if final_url and final_url not in recipe.start_urls:
            recipe.start_urls.append(final_url)

        if target_waypoint is not None:
            merged_expected_texts = list(target_waypoint.expected.any_texts)
            for text in suggested_texts:
                if text not in merged_expected_texts:
                    merged_expected_texts.append(text)
            target_waypoint.expected.any_texts = merged_expected_texts

            merged_url_tokens = list(target_waypoint.expected.url_contains)
            for token in expected_url_tokens:
                if token not in merged_url_tokens:
                    merged_url_tokens.append(token)
            target_waypoint.expected.url_contains = merged_url_tokens

            metadata = dict(target_waypoint.metadata)
            metadata["recovery_candidate"] = {
                "patch_id": patch_id,
                "tx_id": tx.tx_id,
                "outcome": outcome,
                "final_url": final_url,
                "suggested_texts": suggested_texts,
            }
            target_waypoint.metadata = metadata

        step_summaries = [
            {
                "description": step.description,
                "status": step.status,
                "category": step.category.value,
                "risk": step.risk.value,
            }
            for step in computer_use_steps
        ]
        review_payload = {
            "patch_id": patch_id,
            "tx_id": tx.tx_id,
            "payee": tx.payee,
            "outcome": outcome,
            "failure_context": self._normalize_recovery_payload(failure_context),
            "final_url": final_url,
            "suggested_texts": suggested_texts,
            "computer_use_steps": step_summaries,
            "detection": {
                "action_type": getattr(detection, "action_type", None),
                "description": getattr(detection, "description", None),
                "data": self._normalize_recovery_payload(
                    getattr(detection, "data", {}) or {}
                ),
            }
            if detection is not None
            else None,
        }
        recovery_note = (
            f"恢复成功候选：tx={tx.tx_id}，outcome={outcome}，"
            f"waypoint={waypoint_id or 'unknown'}"
        )
        if recovery_note not in recipe.notes:
            recipe.notes.append(recovery_note)

        self._experience_store.update_patch_recipe(
            patch_id,
            recipe=recipe,
            metadata={
                "recovery_outcome": outcome,
                "recovery_final_url": final_url,
                "recovery_waypoint_id": waypoint_id,
                "recovery_suggested_texts": suggested_texts,
            },
        )
        auto_shadow_run = patch["state"] == RecipePatchState.candidate.value
        patch_state_after_recovery = patch["state"]
        if auto_shadow_run:
            self._experience_store.mark_shadow_run_success(
                patch_id,
                metadata={
                    "shadow_run_tx_id": tx.tx_id,
                    "shadow_run_outcome": outcome,
                    "shadow_run_waypoint_id": waypoint_id,
                    "shadow_run_source": "bounded_computer_use_recovery",
                },
            )
            patch_state_after_recovery = RecipePatchState.shadow_run.value

        review_payload["auto_shadow_run_success"] = auto_shadow_run
        review_payload["patch_state_after_recovery"] = patch_state_after_recovery
        artifact_path = self._write_recovery_patch_review_artifact(
            tx_id=tx.tx_id,
            patch_id=patch_id,
            payload=review_payload,
        )
        self._experience_store.record_recovery_improvement(
            patch_id=patch_id,
            tx_id=tx.tx_id,
            platform=recipe.platform,
            flow=recipe.flow,
            artifact_path=str(artifact_path),
            summary={
                "outcome": outcome,
                "waypoint_id": waypoint_id,
                "final_url": final_url,
                "classification": failure_context.get("watchdog_classification"),
                "recommended_action": failure_context.get(
                    "watchdog_recommended_action"
                ),
            },
        )
        self._experience_store.update_patch_recipe(
            patch_id,
            recipe=recipe,
            metadata={
                "recovery_artifact_path": str(artifact_path),
            },
        )
        review_step = StepRecord(
            step_index=len(tx.steps),
            description=(
                (
                    "恢复成功后生成 recipe patch 候选并自动记为 shadow_run"
                    if auto_shadow_run
                    else "恢复成功后更新 recipe patch"
                )
                + f"（patch#{patch_id}，{waypoint_id or 'unknown'}，{outcome}）"
            ),
            status="success",
            started_at=datetime.now(UTC),
            completed_at=datetime.now(UTC),
            category=StepCategory.checkout_prep,
            risk=StepRisk.medium,
            evidence_path=str(artifact_path),
        )
        tx = tx.model_copy(update={"steps": [*tx.steps, review_step]})
        self._ledger.update_status(
            tx.tx_id,
            tx.status,
            execution_mode=tx.execution_mode,
            steps=tx.steps,
        )
        return tx

    async def _capture_page_text_snapshot(self, page: Any) -> str:
        evaluate = getattr(page, "evaluate", None)
        if evaluate is None:
            return ""
        try:
            result = await evaluate(
                """
                () => (document.body?.innerText || "")
                    .split("\\n")
                    .map((line) => line.trim())
                    .filter(Boolean)
                    .slice(0, 20)
                    .join("\\n")
                """
            )
        except Exception:
            return ""
        return str(result or "")

    async def _capture_page_dom_summary(self, page: Any) -> dict[str, Any]:
        evaluate = getattr(page, "evaluate", None)
        if evaluate is None:
            return {}
        try:
            result = await evaluate(
                """
                () => {
                    const pick = (selector, limit = 6) =>
                        Array.from(document.querySelectorAll(selector))
                            .map((node) => (node.textContent || "").trim())
                            .filter(Boolean)
                            .slice(0, limit);
                    return {
                        title: document.title || "",
                        headings: pick("h1, h2, h3"),
                        buttons: pick("button, [role='button'], input[type='submit']"),
                        forms: Array.from(document.forms || [])
                            .map((form) => (
                                (form.getAttribute("id") || form.getAttribute("name") || "").trim()
                            ))
                            .filter(Boolean)
                            .slice(0, 6),
                    };
                }
                """
            )
        except Exception:
            return {}
        return self._normalize_recovery_payload(result) if isinstance(result, Mapping) else {}

    async def _resynchronize_recovery_state(
        self,
        *,
        browser: BrowserController,
        tx: Transaction,
        failure_context: dict[str, Any],
        screenshot_budget: TransactionScreenshotBudget,
    ) -> Transaction:
        now = datetime.now(UTC)
        try:
            current_url = await browser.get_current_url()
        except Exception:
            current_url = str(getattr(browser.page, "url", "") or "")
        visible_text_summary = await self._capture_page_text_snapshot(browser.page)
        dom_summary = await self._capture_page_dom_summary(browser.page)
        try:
            tx, screenshot_path = await self._capture_recovery_screenshot(
                browser=browser,
                tx=tx,
                screenshot_budget=screenshot_budget,
                capture_reason="recovery resynchronization screenshot",
            )
        except Exception:
            logger.debug("恢复重同步截图失败（忽略，不影响主流程）", exc_info=True)
            screenshot_path = None

        failure_context["resync_snapshot"] = self._normalize_recovery_payload(
            {
                "recorded_at": now.isoformat(),
                "current_url": current_url,
                "visible_text_summary": visible_text_summary,
                "dom_summary": dom_summary,
                "watchdog_state": self._recovery_watchdog.describe_state(tx.tx_id),
                "screenshot_path": str(screenshot_path) if screenshot_path else None,
            }
        )
        detail = failure_context.get("waypoint_id") or failure_context.get("recipe_id")
        step = StepRecord(
            step_index=len(tx.steps),
            description=(
                "恢复上下文已重同步（"
                f"{detail or '未知节点'}，当前页：{current_url or 'about:blank'}）"
            ),
            status="success",
            started_at=now,
            completed_at=now,
            category=StepCategory.checkout_prep,
            risk=StepRisk.medium,
            evidence_path=str(screenshot_path) if screenshot_path else None,
        )
        tx = tx.model_copy(update={"steps": [*tx.steps, step]})
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            execution_mode=ExecutionMode.script,
            steps=tx.steps,
            budget_state=tx.budget_state,
        )
        return tx

    def _extract_recovery_patch_markers(
        self,
        *,
        visible_text_summary: str,
        detection: DetectionResult | None,
    ) -> list[str]:
        candidates: list[str] = []
        if detection is not None:
            description = getattr(detection, "description", None)
            if isinstance(description, str) and description.strip():
                candidates.append(description.strip())
        for line in visible_text_summary.splitlines():
            text = line.strip()
            if not text or len(text) > 80:
                continue
            if text not in candidates:
                candidates.append(text)
            if len(candidates) >= 4:
                break
        return candidates

    def _write_recovery_patch_review_artifact(
        self,
        *,
        tx_id: str,
        patch_id: int,
        payload: dict[str, Any],
    ) -> Path:
        evidence_dir = self._config.data_dir / "experience" / "patch_reviews"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        artifact_path = evidence_dir / f"{tx_id}-patch-{patch_id}.json"
        self._artifact_store.write_json(
            artifact_path,
            payload,
            artifact_kind="recovery_patch_review",
            sensitivity=ArtifactSensitivity.sensitive,
            metadata={"tx_id": tx_id, "patch_id": patch_id},
        )
        return artifact_path

    async def _script_recovery_handoff(
        self,
        *,
        browser: BrowserController,
        tx: Transaction,
        payee: str,
        reason: str,
        classification: str | None = None,
        failure_context: dict[str, Any] | None = None,
        execution_mode: ExecutionMode = ExecutionMode.script,
    ) -> Transaction:
        """Create a human recovery gate for high-risk script failures."""
        current_url = await browser.get_current_url()
        await self._prepare_handoff_page(browser, current_url)
        now = datetime.now(UTC)
        display_info = self._display_manager.get_display_info()
        novnc_url: str | None = display_info.get("url")
        mode_label = "脚本" if execution_mode == ExecutionMode.script else "Computer Use"
        guidance = (
            f"{payee} {mode_label} 执行出现高风险失败，已要求人工恢复。\n"
            "请在当前页面继续手动完成支付步骤，并在确认后执行 payswitch confirm。"
        )
        human_action = HumanAction(
            action_type="recovery",
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=novnc_url,
            guidance=guidance,
            details={
                "tx_id": tx.tx_id,
                "payee": payee,
                "current_url": current_url,
                "reason": reason,
                "classification": classification,
                "execution_mode": execution_mode.value,
                "failure_context": self._normalize_recovery_payload(failure_context),
                "next_step": "complete task manually and then confirm.",
            },
        )
        handoff_step = StepRecord(
            step_index=len(tx.steps),
            description=(
                f"{mode_label} 失败进入人工恢复："
                f"{payee}（{classification or 'unclassified'}，{reason}）"
            ),
            status="pending",
            started_at=now,
            category=StepCategory.final_authorization,
            risk=StepRisk.human_required,
        )
        tx = tx.model_copy(
            update={
                "status": TransactionStatus.human_action_required,
                "execution_mode": ExecutionMode.human_takeover,
                "steps": [*tx.steps, handoff_step],
                "human_action": human_action,
            }
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=ExecutionMode.human_takeover,
            steps=tx.steps,
            human_action=human_action,
        )
        await self._display_manager.notify_human(
            message=guidance,
            action_type="recovery",
            details={**(human_action.details or {})},
        )

        if not self._wait_for_human_completion:
            return tx

        async def _completion_callback() -> bool:
            refreshed = self._ledger.get(tx.tx_id)
            return (
                refreshed is not None
                and refreshed.status
                not in {TransactionStatus.human_action_required, TransactionStatus.executing}
            )

        completed = await self._display_manager.wait_for_completion(
            detector_callback=_completion_callback,
            timeout=self._config.transaction_timeout,
        )
        if completed:
            refreshed = self._ledger.get(tx.tx_id)
            if refreshed is not None:
                return refreshed

        timeout_tx = tx.model_copy(
            update={
                "status": TransactionStatus.timeout,
                "completed_at": datetime.now(UTC),
                "error": "脚本恢复人工接管超时",
            }
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.timeout,
            completed_at=datetime.now(UTC),
            error="脚本恢复人工接管超时",
            steps=tx.steps,
        )
        return timeout_tx

    def _uses_visible_browser(self) -> bool:
        return self._display_manager.mode in {DisplayMode.headed, DisplayMode.novnc}

    def _browser_should_launch_headless(self) -> bool:
        return not self._uses_visible_browser()

    def _browser_display(self) -> str | None:
        if self._display_manager.mode != DisplayMode.novnc:
            return None
        display = self._display_manager.get_display_info().get("display")
        return str(display) if display else ":99"

    def _should_keep_browser_open(self, tx: Transaction) -> bool:
        return self._uses_visible_browser() and not tx.is_terminal()

    def _uses_user_chrome_context(self) -> bool:
        """Return whether execution should use the user's real Chrome context."""
        return build_browser_runtime_plan(
            self._config,
            validate_identity=False,
            ensure_cdp=False,
        ).uses_user_chrome

    async def _prepare_handoff_page(
        self,
        browser: BrowserController,
        url: str | None,
    ) -> None:
        """Navigate to the best known checkout URL before human takeover."""
        if not url:
            return
        try:
            logger.info("人类接管前导航到候选页面：%s", url)
            await browser.navigate(url)
        except Exception as exc:
            logger.warning("人类接管前导航失败，保留当前页面：%s", exc)

    def _chrome_launch_kwargs(self) -> dict:
        """Build BrowserController kwargs for real Chrome/CDP execution.

        启用 CDP ensure：已打开则复用匹配 profile 的端口，未打开则按
        绑定 profile 启动一个真实 Chrome CDP 窗口。
        """
        return build_browser_runtime_plan(
            self._config,
            preflight_occupancy=True,
            ensure_cdp=True,
        ).launch_kwargs

    async def _write_recovery_checkpoint_artifact(
        self,
        *,
        tx_id: str,
        checkpoint: dict[str, Any],
    ) -> Path:
        """Persist recovery context snapshot for audit and troubleshooting."""
        evidence_dir = self._config.data_dir / "evidence" / "recovery"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        path = (
            evidence_dir
            / f"{tx_id}-recovery-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%f')}.json"
        )
        self._artifact_store.write_json(
            path,
            {
                "tx_id": tx_id,
                "recorded_at": datetime.now(UTC).isoformat(),
                **self._normalize_recovery_payload(checkpoint),
            },
            artifact_kind="recovery_checkpoint",
            sensitivity=ArtifactSensitivity.sensitive,
            metadata={"tx_id": tx_id},
        )
        return path

    async def _capture_recovery_screenshot(
        self,
        *,
        browser: BrowserController,
        tx: Transaction,
        screenshot_budget: TransactionScreenshotBudget,
        capture_reason: str,
    ) -> tuple[Transaction, Path | None]:
        evidence_dir = self._config.data_dir / "evidence" / "recovery" / tx.tx_id
        evidence_dir.mkdir(parents=True, exist_ok=True)
        screenshot_path = (
            evidence_dir / f"{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%f')}-before-recovery.png"
        )
        decision = screenshot_budget.register_capture(
            artifact_kind="recovery_screenshot",
            capture_reason=capture_reason,
            artifact_path=screenshot_path,
        )
        tx = screenshot_budget.apply(tx)
        if not decision.allowed:
            await self._emit_progress(
                kind="artifact.budget_exhausted",
                summary="截图预算已耗尽",
                message=decision.reason,
                path=["Pay-Switch", "Artifacts", "Recovery"],
                risk="medium",
                target=tx.payee,
                extra={
                    "tx_id": tx.tx_id,
                    "budget_state": tx.budget_state.model_dump(mode="json")
                    if tx.budget_state is not None
                    else None,
                },
            )
            return tx, None
        screenshot_bytes = await browser.screenshot()
        self._artifact_store.write_bytes(
            screenshot_path,
            screenshot_bytes,
            artifact_kind="recovery_screenshot",
            sensitivity=ArtifactSensitivity.sensitive,
            content_type="image/png",
            metadata={"tx_id": tx.tx_id},
        )
        return tx, screenshot_path if screenshot_path.exists() else None

    def _pick_recovery_recipe(
        self,
        *,
        adapter: Any,
        failure_context: dict[str, Any],
    ) -> ExperienceRecipe | None:
        adapter_recipe = getattr(adapter, "recipe", None)
        if isinstance(adapter_recipe, ExperienceRecipe):
            return adapter_recipe

        recipe_id = failure_context.get("recipe_id")
        if isinstance(recipe_id, str) and "." in recipe_id:
            platform, flow = recipe_id.split(".", 1)
            return get_recipe(platform, flow, store=self._experience_store)

        platform = failure_context.get("platform")
        flow = failure_context.get("flow")
        if isinstance(platform, str) and isinstance(flow, str):
            return get_recipe(platform, flow, store=self._experience_store)

        return None

    def _normalize_recovery_payload(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        """Normalize recipe/failure context values for JSON-safe persistence."""
        normalized: dict[str, Any] = {}
        for key, value in payload.items():
            str_key = str(key)
            if isinstance(value, Mapping):
                normalized[str_key] = self._normalize_recovery_payload(value)
            elif isinstance(value, list | tuple | set):
                normalized[str_key] = [
                    self._normalize_recovery_payload(v)
                    if isinstance(v, Mapping)
                    else self._safe_scalar(v)
                    for v in value
                ]
            elif isinstance(value, Path):
                normalized[str_key] = str(value)
            else:
                normalized[str_key] = self._safe_scalar(value)
        return normalized

    def _safe_scalar(self, value: Any) -> Any:
        if isinstance(value, str | int | float | bool) or value is None:
            return value
        try:
            json.dumps(value)
            return value
        except Exception:
            return str(value)

    def _validate_user_chrome_identity(self) -> None:
        """Fail closed when configured Chrome identity does not match."""
        build_browser_runtime_plan(self._config, ensure_cdp=True)

    async def _run_access_preflight(
        self,
        *,
        browser: BrowserController,
        tx: Transaction,
        payee: str,
        adapter,
        url: str | None,
    ) -> Transaction:
        """Run the fixed access/login gate before adapter or fallback execution."""
        if not url:
            return tx

        start_at = datetime.now(UTC)
        step_index = len(tx.steps)
        pending_step = StepRecord(
            step_index=step_index,
            description=f"访问预检：检查 {payee} 的登录态与支付入口",
            status="pending",
            started_at=start_at,
            category=StepCategory.identity,
            risk=StepRisk.low,
        )
        tx = tx.model_copy(update={"steps": [*tx.steps, pending_step]})
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            steps=tx.steps,
        )

        try:
            await browser.navigate(url)
            try:
                await browser.page.wait_for_load_state("networkidle", timeout=5_000)
            except Exception:
                pass

            if adapter is not None and getattr(adapter, "requires_login", True):
                login_result = adapter.ensure_logged_in(browser.page)
                if inspect.isawaitable(login_result):
                    await login_result

            completed_step = pending_step.model_copy(
                update={
                    "status": "success",
                    "description": f"访问预检通过：已进入 {payee} 的可执行支付页面",
                    "completed_at": datetime.now(UTC),
                }
            )
            tx = tx.model_copy(update={"steps": [*tx.steps[:-1], completed_step]})
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.executing,
                steps=tx.steps,
            )
            return tx
        except LoginRequiredError as exc:
            requested_at = datetime.now(UTC)
            login_step = pending_step.model_copy(
                update={
                    "status": "pending",
                    "description": f"Access preflight requires login: {exc}",
                }
            )

            await self._focus_browser(browser)
            display_info = self._display_manager.get_display_info()
            novnc_url: str | None = display_info.get("url")
            current_url = str(getattr(browser.page, "url", url or ""))
            guidance = (
                f"{exc}\n"
                f"Complete {payee} login in the visible browser. "
                "Pay-Switch will continue only after the authenticated session is detected."
            )
            human_action = HumanAction(
                action_type="login",
                requested_at=requested_at,
                display_mode=self._display_manager.mode,
                novnc_url=novnc_url,
                guidance=guidance,
                details={
                    "tx_id": tx.tx_id,
                    "payee": payee,
                    "current_url": current_url,
                    "next_step": "Complete platform login, then keep the browser open.",
                },
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.human_action_required,
                    "steps": [*tx.steps[:-1], login_step],
                    "human_action": human_action,
                }
            )
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.human_action_required,
                steps=tx.steps,
                human_action=human_action,
            )
            await self._display_manager.notify_human(
                message=guidance,
                action_type="login",
                details={**(human_action.details or {})},
            )

            async def _login_completion_callback() -> bool:
                try:
                    login_result = adapter.ensure_logged_in(browser.page)
                    if inspect.isawaitable(login_result):
                        await login_result
                    return True
                except LoginRequiredError:
                    return False
                except Exception:
                    logger.debug("Login preflight callback failed", exc_info=True)
                    return False

            if await self._display_manager.wait_for_completion(
                detector_callback=_login_completion_callback,
                timeout=self._config.transaction_timeout,
            ):
                completed_at = datetime.now(UTC)
                completed_step = login_step.model_copy(
                    update={
                        "status": "success",
                        "description": f"Access preflight passed after {payee} login",
                        "completed_at": completed_at,
                    }
                )
                completed_action = human_action.model_copy(update={"completed_at": completed_at})
                tx = tx.model_copy(
                    update={
                        "status": TransactionStatus.executing,
                        "steps": [*tx.steps[:-1], completed_step],
                        "human_action": completed_action,
                    }
                )
                self._ledger.update_status(
                    tx.tx_id,
                    TransactionStatus.executing,
                    steps=tx.steps,
                    human_action=completed_action,
                )
                return tx

            timed_out_at = datetime.now(UTC)
            timeout_msg = f"Login preflight timed out for {payee}; payment was not attempted."
            timeout_step = login_step.model_copy(
                update={"status": "failed", "completed_at": timed_out_at}
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.timeout,
                    "completed_at": timed_out_at,
                    "error": timeout_msg,
                    "steps": [*tx.steps[:-1], timeout_step],
                }
            )
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.timeout,
                completed_at=timed_out_at,
                error=timeout_msg,
                steps=tx.steps,
                human_action=human_action,
            )
            return tx

    # ------------------------------------------------------------------
    # 脚本模式执行
    # ------------------------------------------------------------------

    async def _execute_script_mode(
        self,
        adapter,
        browser: BrowserController,
        tx: Transaction,
        amount: float,
        method: PaymentMethod,
        screenshot_budget: TransactionScreenshotBudget,
    ) -> Transaction:
        """脚本模式执行：调用适配器的 execute_topup，逐步处理支付环节。

        Args:
            adapter:  已实例化的 SiteAdapter 子类
            browser:  已启动的 BrowserController
            tx:       当前交易对象
            amount:   支付金额
            method:   支付方式

        Returns:
            更新后的 Transaction 对象

        Raises:
            ScriptExecutionError: 适配器内部失败，上层捕获后回退智能模式
        """
        logger.info("脚本模式启动：adapter=%s，amount=%.2f", adapter.__class__.__name__, amount)

        # 记录脚本模式开始步骤
        start_step = StepRecord(
            step_index=len(tx.steps),
            description=f"脚本模式启动（适配器：{adapter.__class__.__name__}）",
            status="success",
            started_at=datetime.now(UTC),
            completed_at=datetime.now(UTC),
        )
        tx = tx.model_copy(
            update={
                "execution_mode": ExecutionMode.script,
                "steps": [*tx.steps, start_step],
            }
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            execution_mode=ExecutionMode.script,
            steps=tx.steps,
        )
        allow_detector_completion = getattr(adapter, "allow_detector_completion", True)
        display_url = self._current_display_url()
        await self._emit_progress(
            kind="observe",
            summary="真实浏览器已接管",
            message="Pay-Switch 已启动可见浏览器，后续 adapter 操作会在该窗口执行。",
            path=["Pay-Switch", "Browser"],
            risk="medium",
            target=adapter.name,
            extra={
                "display_url": display_url,
                "novnc_url": display_url,
                "current_url": getattr(browser.page, "url", None),
                "execution_mode": "script",
            },
        )

        async def _stream_adapter_step(script_step: ScriptStep) -> None:
            action = script_step.action
            kind = "detection" if action == "detect_payment" else (
                "action.allowed" if action in {"click", "fill"} else "observe"
            )
            risk = "high" if script_step.risk == StepRisk.high else (
                "medium" if script_step.risk == StepRisk.medium else "low"
            )
            await self._emit_progress(
                kind=kind,
                summary=script_step.description,
                message=f"{adapter.display_name} adapter 执行步骤：{script_step.action}",
                path=["Pay-Switch", "Browser", adapter.display_name],
                risk=risk,
                target=adapter.name,
                extra={
                    "display_url": self._current_display_url(),
                    "novnc_url": self._current_display_url(),
                    "current_url": getattr(browser.page, "url", None),
                    "selector": script_step.selector,
                    "action": script_step.action,
                    "url": script_step.url,
                },
            )

        async def _stream_adapter_telemetry(payload: dict[str, Any]) -> None:
            extra = dict(payload.get("extra") or {})
            extra.setdefault("display_url", self._current_display_url())
            extra.setdefault("novnc_url", self._current_display_url())
            extra.setdefault("current_url", getattr(browser.page, "url", None))
            await self._emit_progress(
                kind=str(payload.get("kind") or "observe"),
                summary=str(payload.get("summary") or "recipe waypoint update"),
                message=str(payload.get("message") or ""),
                path=list(payload.get("path") or ["Pay-Switch", "Recipe Runner", adapter.name]),
                risk=str(payload.get("risk") or "medium"),
                target=str(payload.get("target") or adapter.name),
                extra=extra,
            )

        # 调用适配器执行充值脚本
        # ScriptExecutionError 不在此处捕获，交由 spend() 的外层处理
        previous_progress_callback = getattr(adapter, "progress_callback", None)
        previous_telemetry_callback = getattr(adapter, "telemetry_callback", None)
        previous_evidence_dir = getattr(adapter, "recipe_evidence_dir", None)
        previous_recipe_store = getattr(adapter, "recipe_store", None)
        previous_recipe_artifact_store = getattr(adapter, "recipe_artifact_store", None)
        previous_recipe_screenshot_budget = getattr(adapter, "recipe_screenshot_budget", None)
        adapter.progress_callback = _stream_adapter_step
        adapter.telemetry_callback = _stream_adapter_telemetry
        adapter.recipe_evidence_dir = self._config.data_dir / "evidence" / "recipes" / tx.tx_id
        adapter.recipe_store = self._experience_store
        adapter.recipe_artifact_store = self._artifact_store
        adapter.recipe_screenshot_budget = screenshot_budget
        try:
            script_steps: list = await adapter.execute_topup(
                page=browser.page,
                amount=amount,
                method=method if method != PaymentMethod.auto else None,
            )
        finally:
            adapter.progress_callback = previous_progress_callback
            adapter.telemetry_callback = previous_telemetry_callback
            adapter.recipe_evidence_dir = previous_evidence_dir
            adapter.recipe_store = previous_recipe_store
            adapter.recipe_artifact_store = previous_recipe_artifact_store
            adapter.recipe_screenshot_budget = previous_recipe_screenshot_budget
        tx = screenshot_budget.apply(tx)
        logger.info("适配器脚本执行完毕，共 %d 个步骤", len(script_steps))

        # 将适配器返回的 ScriptStep 列表转换为 StepRecord 并追加到交易
        for i, script_step in enumerate(script_steps):
            step_record = StepRecord(
                step_index=len(tx.steps),
                description=script_step.description,
                status="success",
                started_at=datetime.now(UTC),
                completed_at=datetime.now(UTC),
            )
            tx = tx.model_copy(update={"steps": [*tx.steps, step_record]})

            # 每个步骤后实时更新账本
            self._ledger.update_status(tx.tx_id, TransactionStatus.executing, steps=tx.steps)

            # ---- 第八步：每个步骤后运行检测器流水线 ----
            detection = await self._detector_pipeline.scan(browser.page)

            if detection is not None:
                logger.info(
                    "检测器命中：%s（action_type=%s）",
                    detection.detector_name,
                    detection.action_type,
                )

                # 检测到支付已完成 → 直接标记成功
                if detection.action_type == "completed":
                    if not allow_detector_completion:
                        logger.info(
                            "检测器报告 completed，但 %s 禁止脚本期自动完成，忽略该信号",
                            adapter.__class__.__name__,
                        )
                        continue
                    logger.info("检测到支付完成状态，标记交易成功")
                    now = datetime.now(UTC)
                    self._ledger.update_status(
                        tx.tx_id,
                        TransactionStatus.completed,
                        completed_at=now,
                        steps=tx.steps,
                    )
                    return tx.model_copy(
                        update={
                            "status": TransactionStatus.completed,
                            "completed_at": now,
                        }
                    )

                # ---- 第九步：检测到需要人类介入的支付环节 ----
                if self._requires_human(detection):
                    logger.info("检测到需要人类介入：%s", detection.action_type)
                    # ---- 第十步：等待人类完成 ----
                    human_success = await self._handle_human_interaction(
                        browser=browser,
                        detection=detection,
                        tx=tx,
                    )

                    # 从账本重新加载最新状态（_handle_human_interaction 已更新）
                    refreshed = self._ledger.get(tx.tx_id)
                    if refreshed is not None:
                        tx = refreshed

                    if human_success is None:
                        return tx

                    if human_success:
                        logger.info("人类操作完成，检测支付结果")
                        # 再次扫描，确认支付完成
                        final_detection = await self._detector_pipeline.scan(browser.page)
                        if (
                            final_detection is not None
                            and final_detection.action_type == "completed"
                        ):
                            now = datetime.now(UTC)
                            self._ledger.update_status(
                                tx.tx_id,
                                TransactionStatus.completed,
                                completed_at=now,
                                steps=tx.steps,
                            )
                            return tx.model_copy(
                                update={
                                    "status": TransactionStatus.completed,
                                    "completed_at": now,
                                }
                            )
                        else:
                            # 人类操作完成但未检测到明确的完成状态
                            # 根据 guard 配置决定是否自动确认
                            logger.info(
                                "人类操作已完成，未检测到明确完成状态，视为完成（用户手动确认）"
                            )
                            now = datetime.now(UTC)
                            self._ledger.update_status(
                                tx.tx_id,
                                TransactionStatus.completed,
                                completed_at=now,
                                steps=tx.steps,
                            )
                            return tx.model_copy(
                                update={
                                    "status": TransactionStatus.completed,
                                    "completed_at": now,
                                }
                            )
                    else:
                        # 人类操作超时
                        timeout_msg = "等待人类操作超时"
                        logger.warning("交易 %s：%s", tx.tx_id, timeout_msg)
                        self._ledger.update_status(
                            tx.tx_id,
                            TransactionStatus.timeout,
                            completed_at=datetime.now(UTC),
                            error=timeout_msg,
                            steps=tx.steps,
                        )
                        return tx.model_copy(
                            update={
                                "status": TransactionStatus.timeout,
                                "completed_at": datetime.now(UTC),
                                "error": timeout_msg,
                            }
                        )

        if getattr(adapter, "requires_payment_gate", False):
            reached_payment_gate = any(
                (
                    getattr(script_step, "requires_human_authorization", False)
                    or getattr(script_step, "category", None) == StepCategory.final_authorization
                )
                for script_step in script_steps
            )
            if not reached_payment_gate:
                raise ScriptExecutionError(
                    f"{adapter.__class__.__name__} script finished without reaching "
                    "a payment gate or explicit human authorization step"
                )
            return await self._payment_gate_handoff(
                browser=browser,
                tx=tx,
                adapter_name=adapter.__class__.__name__,
            )

        # 所有脚本步骤执行完毕，最终检测一次
        final_detection = await self._detector_pipeline.scan(browser.page)
        if final_detection is not None and final_detection.action_type == "completed":
            if not allow_detector_completion:
                logger.info(
                    "最终检测报告 completed，但 %s 禁止脚本期自动完成，保持未完成",
                    adapter.__class__.__name__,
                )
                return tx
            now = datetime.now(UTC)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.completed,
                completed_at=now,
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.completed,
                    "completed_at": now,
                }
            )

        # 脚本执行完毕但状态不明确：保持 executing，由 spend() 上层处理
        logger.info("脚本模式执行完毕，当前状态待最终确认")
        return tx

    # ------------------------------------------------------------------
    # 虚拟卡全字段填写
    # ------------------------------------------------------------------

    async def _fill_card_on_page(
        self,
        browser: BrowserController,
        tx: Transaction,
        secret_ref: str,
    ) -> Transaction:
        """在当前页面检测并填写虚拟卡全字段。

        通常在脚本/CU 导航到支付页面后调用。
        """
        from payswitch.engine.card_filler import CardFormFiller, CardFormNotFoundError

        filler = CardFormFiller()
        try:
            result = await filler.detect_and_fill(browser.page, secret_ref)
        except CardFormNotFoundError:
            logger.info("当前页面未检测到卡表单，跳过卡填写")
            return tx

        # 记录填写步骤
        step = StepRecord(
            step_index=len(tx.steps),
            description=f"虚拟卡填写完成：{', '.join(result.filled_fields)}",
            status="success",
            started_at=datetime.now(UTC),
            completed_at=datetime.now(UTC),
        )
        tx = tx.model_copy(update={"steps": [*tx.steps, step]})
        self._ledger.update_status(tx.tx_id, TransactionStatus.executing, steps=tx.steps)

        if result.needs_human_gate:
            human_action = HumanAction(
                action_type="dynamic_challenge",
                description=f"请完成：{', '.join(result.human_fields)}",
                requested_at=datetime.now(UTC),
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.human_action_required,
                    "human_actions": [*tx.human_actions, human_action],
                }
            )
            self._ledger.update_status(
                tx.tx_id, TransactionStatus.human_action_required, steps=tx.steps
            )
            logger.info("卡填写完成但需要人类处理：%s", result.human_fields)
        else:
            logger.info("虚拟卡全字段填写完成，等待确认")

        return tx

    # ------------------------------------------------------------------
    # Computer Use 智能探索（内部复用 SkyvernEngine）
    # ------------------------------------------------------------------

    async def _execute_computer_use_fallback(
        self,
        browser: BrowserController,
        tx: Transaction,
        amount: float,
        payee: str,
        method: PaymentMethod,
        url: str | None,
        recovery_patch_id: int | None = None,
        failure_context: dict[str, Any] | None = None,
    ) -> Transaction:
        """Dispatch adapter/no-adapter fallback through the configured CU driver."""
        from payswitch.browser.computer_use import ComputerUseRecoveryBudget

        recovery_budget = ComputerUseRecoveryBudget.from_config(self._config)
        driver = self._config.computer_use_driver

        if driver == ComputerUseDriver.external:
            return await self._external_computer_use_handoff(
                browser=browser,
                tx=tx,
                amount=amount,
                payee=payee,
                method=method,
                url=url,
                reason="固定适配器不可用或过时，等待外部 Agent 通过 Computer Use 接力探索",
                recovery_budget=recovery_budget,
                failure_context=failure_context,
            )

        if driver == ComputerUseDriver.hybrid:
            try:
                return await self._execute_smart_mode(
                    browser=browser,
                    tx=tx,
                    amount=amount,
                    payee=payee,
                    method=method,
                    url=url,
                    recovery_budget=recovery_budget,
                    recovery_patch_id=recovery_patch_id,
                    failure_context=failure_context,
                )
            except SmartModeError as exc:
                routed = await self._handle_internal_computer_use_failure(
                    browser=browser,
                    tx=tx,
                    amount=amount,
                    payee=payee,
                    method=method,
                    url=url,
                    recovery_budget=recovery_budget,
                    exc=exc,
                    allow_external_fallback=True,
                )
                if routed is not None:
                    return routed
                logger.warning(
                    "内部 Computer Use 失败（%s），切换到 external Agent 接力",
                    exc,
                )
                handoff_note = StepRecord(
                    step_index=len(tx.steps),
                    description=(
                        "内部 Computer Use 恢复失败，切换到 external 接力："
                        f"{exc}"
                    ),
                    status="failed",
                    started_at=datetime.now(UTC),
                    completed_at=datetime.now(UTC),
                    category=StepCategory.checkout_prep,
                    risk=StepRisk.medium,
                )
                tx = tx.model_copy(update={"steps": [*tx.steps, handoff_note]})
                self._ledger.update_status(
                    tx.tx_id,
                    TransactionStatus.executing,
                    execution_mode=ExecutionMode.smart,
                    steps=tx.steps,
                )
                return await self._external_computer_use_handoff(
                    browser=browser,
                    tx=tx,
                    amount=amount,
                    payee=payee,
                    method=method,
                    url=url,
                    reason=(
                        "内部 Computer Use 不可用，等待外部 Agent 通过 Computer Use "
                        f"接力探索：{exc}"
                    ),
                    recovery_budget=recovery_budget,
                    failure_context=self._normalize_smart_failure_context(exc.failure_context),
                )

        try:
            return await self._execute_smart_mode(
                browser=browser,
                tx=tx,
                amount=amount,
                payee=payee,
                method=method,
                url=url,
                recovery_budget=recovery_budget,
                recovery_patch_id=recovery_patch_id,
                failure_context=failure_context,
            )
        except SmartModeError as exc:
            routed = await self._handle_internal_computer_use_failure(
                browser=browser,
                tx=tx,
                amount=amount,
                payee=payee,
                method=method,
                url=url,
                recovery_budget=recovery_budget,
                exc=exc,
                allow_external_fallback=False,
            )
            if routed is not None:
                return routed
            raise

    async def _handle_internal_computer_use_failure(
        self,
        *,
        browser: BrowserController,
        tx: Transaction,
        amount: float,
        payee: str,
        method: PaymentMethod,
        url: str | None,
        recovery_budget: Any,
        exc: SmartModeError,
        allow_external_fallback: bool,
    ) -> Transaction | None:
        failure_context = self._normalize_smart_failure_context(exc.failure_context)
        if not failure_context:
            return None
        decision = self._recovery_watchdog.register_script_failure(
            tx.tx_id,
            failure_context,
        )
        if decision.recommended_action == "login_human_gate":
            return await self._script_login_handoff(
                browser=browser,
                tx=tx,
                payee=payee,
                reason=str(exc),
                classification=decision.classification,
                execution_mode=ExecutionMode.smart,
            )
        if decision.requires_human_gate:
            return await self._script_recovery_handoff(
                browser=browser,
                tx=tx,
                payee=payee,
                reason=str(exc),
                classification=decision.classification,
                failure_context=failure_context,
                execution_mode=ExecutionMode.smart,
            )
        if not allow_external_fallback:
            return None
        return await self._external_computer_use_handoff(
            browser=browser,
            tx=tx,
            amount=amount,
            payee=payee,
            method=method,
            url=url,
            reason=(
                "内部 Computer Use 遇到可恢复页面漂移，等待外部 Agent 通过 "
                f"Computer Use 接力探索：{exc}"
            ),
            recovery_budget=recovery_budget,
            failure_context=failure_context,
        )

    async def _external_computer_use_handoff(
        self,
        browser: BrowserController,
        tx: Transaction,
        amount: float,
        payee: str,
        method: PaymentMethod,
        url: str | None,
        reason: str,
        recovery_budget: Any,
        failure_context: dict[str, Any] | None = None,
    ) -> Transaction:
        """Stop in a CU-ready handoff state before full human takeover.

        In external mode, Pay-Switch does not supply the reasoning model. The
        caller agent is expected to observe the browser and submit governed
        actions through the external runner/control surface. This is still a
        Computer Use fallback, not a final human takeover.
        """
        if not self._config.computer_use_enabled:
            raise SmartModeError("Computer Use 已关闭，无法进入 external 兜底")

        await self._prepare_handoff_page(browser, url)
        current_url = await browser.get_current_url()
        now = datetime.now(UTC)
        display_info = self._display_manager.get_display_info()
        novnc_url: str | None = display_info.get("url")
        step_index = len(tx.steps)
        evidence_path = self._write_external_handoff_evidence(
            tx_id=tx.tx_id,
            step_index=step_index,
            current_url=current_url,
            reason=reason,
            payee=payee,
            amount=amount,
            method=method.value if method else PaymentMethod.auto.value,
            recovery_budget=recovery_budget.as_dict(),
            failure_context=failure_context,
        )

        human_action = HumanAction(
            action_type="external_computer_use",
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=novnc_url,
            guidance=(
                "固定流程失败，已进入 external Computer Use 兜底。"
                "请由外部 Agent 继续探索；遇到扫码、支付密码、OTP "
                "或最终确认时必须停下来和用户沟通。"
            ),
            details={
                "tx_id": tx.tx_id,
                "amount": f"¥{amount:.2f}",
                "payee": payee,
                "method": method.value if method else PaymentMethod.auto.value,
                "current_url": current_url,
                "driver": ComputerUseDriver.external.value,
                "boundary": self._config.computer_use_max_autonomous_category.value,
                "budget": recovery_budget.as_dict(),
                "failure_context": failure_context,
                "next": "外部 Agent 应继续 observe/受控点击；需要用户授权时再升级",
            },
        )
        handoff_step = StepRecord(
            step_index=step_index,
            description=(
                "进入 external Computer Use 兜底：等待外部 Agent 探索页面，"
                "Pay-Switch 继续执行风控、人类闸门和账本留痕"
            ),
            status="pending",
            started_at=now,
            category=StepCategory.checkout_prep,
            risk=StepRisk.medium,
            evidence_path=str(evidence_path),
        )
        tx = tx.model_copy(
            update={
                "status": TransactionStatus.human_action_required,
                "execution_mode": ExecutionMode.computer_use,
                "steps": [*tx.steps, handoff_step],
                "human_action": human_action,
                "error": reason,
            }
        )

        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=ExecutionMode.computer_use,
            error=reason,
            human_action=human_action,
            steps=tx.steps,
        )
        await self._display_manager.notify_human(
            message=(
                "固定流程失败，已进入 external Computer Use 兜底。"
                "请由外部 Agent 继续探索到支付前状态；遇到扫码、CVV、OTP、"
                "支付密码或最终确认时必须暂停给用户授权。"
            ),
            action_type="external_computer_use",
            details={
                **(human_action.details or {}),
            },
        )
        logger.info("交易 %s 进入 external Computer Use 兜底：%s", tx.tx_id, current_url)
        return tx

    def _write_external_handoff_evidence(
        self,
        *,
        tx_id: str,
        step_index: int,
        current_url: str,
        reason: str,
        payee: str,
        amount: float,
        method: str,
        recovery_budget: dict[str, int],
        failure_context: dict[str, Any] | None = None,
    ) -> Path:
        """Persist the browser state where external Computer Use should resume."""
        evidence_dir = self._config.data_dir / "evidence" / "external"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        evidence_path = evidence_dir / f"{tx_id}-step-{step_index}-handoff.json"
        payload = {
            "tx_id": tx_id,
            "step_index": step_index,
            "kind": "external_computer_use_handoff",
            "current_url": current_url,
            "reason": reason,
            "payee": payee,
            "amount": amount,
            "method": method,
            "budget": recovery_budget,
            "failure_context": failure_context,
            "recorded_at": datetime.now(UTC).isoformat(),
        }
        self._artifact_store.write_json(
            evidence_path,
            payload,
            artifact_kind="external_computer_use_handoff",
            sensitivity=ArtifactSensitivity.sensitive,
            metadata={"tx_id": tx_id, "step_index": step_index},
        )
        return evidence_path

    async def _execute_smart_mode(
        self,
        browser: BrowserController,
        tx: Transaction,
        amount: float,
        payee: str,
        method: PaymentMethod,
        url: str | None,
        recovery_budget: Any,
        recovery_patch_id: int | None = None,
        failure_context: dict[str, Any] | None = None,
    ) -> Transaction:
        """Computer Use 兜底探索（内部复用 SkyvernEngine）。

        使用受控 ComputerUseExplorer 替代固定选择器脚本，
        通过模型视觉能力探索未知/变更站点的 checkout 路径。
        该模式只应推进到支付前或人类接管点，不应自主完成最终付款。

        执行流程：
        1. 检查 ComputerUseExplorer 是否可用（LLM 已配置且 openai 已安装）
        2. 构建受控探索任务
        3. 调用 ComputerUseExplorer.explore_checkout() 执行任务
        4. 将 Computer Use 返回的步骤合并到交易记录
        5. 执行最终检测，确认支付状态

        Args:
            browser: 已启动的 BrowserController
            tx:      当前交易对象
            amount:  支付金额
            payee:   收款方平台标识
            method:  期望支付方式
            url:     智能模式目标 URL（无适配器时必须提供）

        Returns:
            更新后的 Transaction 对象

        Raises:
            SmartModeError: Computer Use 不可用或探索失败
        """
        from payswitch.browser.computer_use import ComputerUseExplorer

        logger.info(
            "Computer Use 兜底探索启动：url=%s，amount=%.2f，payee=%s",
            url,
            amount,
            payee,
        )
        budget = recovery_budget

        # ---- 检查 Computer Use 是否可用 ----
        explorer = ComputerUseExplorer(self._config)
        if not explorer.is_available():
            raise SmartModeError(
                "Computer Use 兜底探索不可用：LLM 未配置、openai 未安装或 computer_use 已关闭。"
                "请在配置文件中设置 llm.api_key，"
                "并安装智能模式依赖：uv pip install 'payswitch[smart]'"
            )

        # ---- 记录 Computer Use 启动步骤 ----
        smart_start_step = StepRecord(
            step_index=len(tx.steps),
            description=(
                "Computer Use 兜底探索启动"
                f"（目标：{url}，steps<={budget.effective_max_steps}，"
                f"tokens<={budget.max_model_tokens}，"
                f"wall_time<={budget.max_wall_time_seconds}s）"
            ),
            status="pending",
            started_at=datetime.now(UTC),
        )
        tx = tx.model_copy(
            update={
                "execution_mode": ExecutionMode.smart,
                "steps": [*tx.steps, smart_start_step],
            }
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            execution_mode=ExecutionMode.smart,
            steps=tx.steps,
        )

        # ---- 调用 Computer Use 执行受控探索 ----
        try:
            async with asyncio.timeout(budget.max_wall_time_seconds):
                computer_use_steps = await explorer.explore_checkout(
                    page=browser.page,
                    payee=payee,
                    amount=amount,
                    method=(method.value if method else PaymentMethod.auto.value),
                    url=url,
                    budget=budget,
                    recovery_context=failure_context,
                )
        except TimeoutError as exc:
            logger.warning(
                "Computer Use 恢复超时（budget=%ss）",
                budget.max_wall_time_seconds,
            )
            failed_start_step = smart_start_step.model_copy(
                update={
                    "status": "failed",
                    "completed_at": datetime.now(UTC),
                }
            )
            tx = tx.model_copy(update={"steps": [*tx.steps[:-1], failed_start_step]})
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.executing,
                steps=tx.steps,
            )
            raise SmartModeError(
                "Computer Use 恢复超时："
                f"wall_time>{budget.max_wall_time_seconds}s"
            ) from exc
        except Exception as exc:
            # Computer Use 执行失败：更新启动步骤状态，抛出 SmartModeError
            logger.warning("Computer Use 探索失败：%s", exc)
            failed_start_step = smart_start_step.model_copy(
                update={
                    "status": "failed",
                    "completed_at": datetime.now(UTC),
                }
            )
            tx = tx.model_copy(update={"steps": [*tx.steps[:-1], failed_start_step]})
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.executing,
                steps=tx.steps,
            )
            raise SmartModeError(
                f"Computer Use 探索失败：{type(exc).__name__}: {exc}",
                failure_context=self._normalize_smart_failure_context(
                    getattr(exc, "failure_context", None)
                ),
            ) from exc

        # ---- 将 Computer Use 返回的步骤合并到交易记录 ----
        # 先将启动步骤标记为成功
        success_start_step = smart_start_step.model_copy(
            update={
                "status": "success",
                "completed_at": datetime.now(UTC),
            }
        )
        tx = tx.model_copy(update={"steps": [*tx.steps[:-1], success_start_step]})

        # 追加 Computer Use 各执行步骤
        for computer_use_step in computer_use_steps:
            # 重新编号 step_index 以保持连续性
            indexed_step = computer_use_step.model_copy(update={"step_index": len(tx.steps)})
            tx = tx.model_copy(update={"steps": [*tx.steps, indexed_step]})

            # 实时同步账本（每步更新，便于监控进度）
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.executing,
                steps=tx.steps,
            )

        logger.info("Computer Use 探索完毕，共 %d 个步骤", len(computer_use_steps))

        # ---- 最终检测：确认支付状态 ----
        final_detection = await self._detector_pipeline.scan(browser.page)
        if final_detection is not None and final_detection.action_type == "completed":
            # 检测到支付成功完成
            now = datetime.now(UTC)
            logger.info("Computer Use：检测到支付完成状态")
            tx = await self._record_successful_recovery_patch(
                browser=browser,
                tx=tx,
                patch_id=recovery_patch_id,
                failure_context=failure_context,
                outcome="completed",
                computer_use_steps=computer_use_steps,
                detection=final_detection,
            )
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.completed,
                completed_at=now,
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.completed,
                    "completed_at": now,
                }
            )

        if final_detection is not None and self._requires_human(final_detection):
            # 检测到需要人类介入（如支付宝二维码等待扫码）
            logger.info(
                "Computer Use：检测到需要人类介入（%s），移交人类处理",
                final_detection.action_type,
            )
            tx = await self._record_successful_recovery_patch(
                browser=browser,
                tx=tx,
                patch_id=recovery_patch_id,
                failure_context=failure_context,
                outcome=final_detection.action_type,
                computer_use_steps=computer_use_steps,
                detection=final_detection,
            )
            human_success = await self._handle_human_interaction(
                browser=browser,
                detection=final_detection,
                tx=tx,
            )

            # 重新加载交易（_handle_human_interaction 已更新账本）
            refreshed = self._ledger.get(tx.tx_id)
            if refreshed is not None:
                tx = refreshed

            if human_success is None:
                return tx

            if human_success:
                now = datetime.now(UTC)
                self._ledger.update_status(
                    tx.tx_id,
                    TransactionStatus.completed,
                    completed_at=now,
                    steps=tx.steps,
                )
                return tx.model_copy(
                    update={
                        "status": TransactionStatus.completed,
                        "completed_at": now,
                    }
                )
            else:
                # 等待人类操作超时
                timeout_msg = "Computer Use：等待人类操作超时"
                logger.warning(timeout_msg)
                raise SmartModeError(timeout_msg)

        # Computer Use 执行完毕，但状态未明确（交由上层处理）
        logger.info("Computer Use 探索完毕，当前状态待最终确认")
        return tx

    # ------------------------------------------------------------------
    # Stripe API 模式（无需浏览器）
    # ------------------------------------------------------------------

    async def _execute_stripe_mode(
        self,
        tx: Transaction,
        amount: float,
        method: PaymentMethod,
    ) -> Transaction:
        """执行 Stripe API 支付流程（无需浏览器自动化）。

        Stripe 与其他浏览器自动化适配器不同，它直接调用 Stripe REST API
        创建 hosted checkout session，
        用户通过返回的 URL 或二维码完成支付，webhook 监听器负责更新交易状态。

        执行流程：
        1. 获取 StripeAdapter 实例
        2. 调用 adapter.execute_topup 创建 checkout session
        3. 从返回的 steps 提取 checkout URL
        4. 更新交易状态为 human_action_required
        5. 通过 display_manager 通知用户（输出 URL 和二维码）
        6. 返回交易（状态为 human_action_required，webhook 将异步更新状态）

        Args:
            tx: 当前交易对象
            amount: 支付金额
            method: 支付方式（应为 PaymentMethod.stripe）

        Returns:
            更新后的 Transaction 对象（状态为 human_action_required）

        Raises:
            ScriptExecutionError: Stripe API 调用失败
        """
        logger.info("Stripe API 模式启动：amount=%.2f, method=%s", amount, method)

        # 记录 Stripe 模式启动步骤
        start_step = StepRecord(
            step_index=len(tx.steps),
            description="Stripe API 模式启动（无需浏览器）",
            status="success",
            started_at=datetime.now(UTC),
            completed_at=datetime.now(UTC),
        )
        tx = tx.model_copy(
            update={
                "execution_mode": ExecutionMode.script,  # Stripe 也算脚本模式（确定性 API 调用）
                "steps": [*tx.steps, start_step],
            }
        )
        self._ledger.update_status(tx.tx_id, TransactionStatus.executing, steps=tx.steps)

        # 获取 StripeAdapter
        adapter = AdapterRegistry.get("stripe")
        if adapter is None:
            raise ScriptExecutionError("Stripe 适配器未注册。请确保已安装 payswitch[stripe] 依赖。")

        # 调用 adapter 创建 checkout session（不需要 page 参数）
        try:
            # 从配置读取默认货币
            currency = self._config.stripe_default_currency or "usd"
            product_name = tx.reason or f"Pay-Switch 支付 - {amount} {currency.upper()}"

            script_steps = await adapter.execute_topup(
                page=None,  # Stripe 不需要浏览器
                amount=amount,
                method=method,
                currency=currency,
                product_name=product_name,
                tx_id=tx.tx_id,  # 传递交易 ID，用于 webhook 关联
            )
            logger.info("Stripe checkout session 已创建，共 %d 个步骤", len(script_steps))
        except ScriptExecutionError as exc:
            # Stripe API 调用失败
            logger.error("Stripe API 调用失败：%s", exc)
            fail_step = StepRecord(
                step_index=len(tx.steps),
                description=f"Stripe API 调用失败：{exc}",
                status="failed",
                started_at=datetime.now(UTC),
                completed_at=datetime.now(UTC),
            )
            tx = tx.model_copy(update={"steps": [*tx.steps, fail_step]})
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(UTC),
                error=str(exc),
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(UTC),
                    "error": str(exc),
                }
            )

        # 将 adapter 返回的步骤追加到交易记录
        for script_step in script_steps:
            step_record = StepRecord(
                step_index=len(tx.steps),
                description=script_step.description,
                status="success",
                started_at=datetime.now(UTC),
                completed_at=datetime.now(UTC),
            )
            tx = tx.model_copy(update={"steps": [*tx.steps, step_record]})

        # 提取 checkout URL（从 steps 中查找 action="payment_url_ready" 的步骤）
        checkout_url: str | None = None
        for script_step in script_steps:
            if script_step.action == "payment_url_ready" and script_step.url:
                checkout_url = script_step.url
                break

        if not checkout_url:
            # 未找到 checkout URL，标记失败
            error_msg = "Stripe checkout session 创建成功，但未返回支付 URL"
            logger.error(error_msg)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(UTC),
                error=error_msg,
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(UTC),
                    "error": error_msg,
                }
            )

        # 创建 HumanAction 记录（Stripe 支付通过外部 URL 完成）
        now = datetime.now(UTC)
        human_action = HumanAction(
            action_type="stripe_checkout",
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=checkout_url,  # 复用 novnc_url 字段存储 checkout URL
        )

        # 更新交易状态为 human_action_required
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=ExecutionMode.human_takeover,
            human_action=human_action,
            steps=tx.steps,
        )
        logger.info("交易 %s 进入人类确认状态（Stripe checkout）：%s", tx.tx_id, checkout_url)

        # 通知终端用户（CLI 输出 URL 和二维码）
        await self._display_manager.notify_human(
            message=f"请访问以下 Stripe checkout 链接完成支付（{amount} {currency.upper()}）",
            action_type="stripe_checkout",
            details={
                "tx_id": tx.tx_id,
                "amount": f"{amount} {currency.upper()}",
                "checkout_url": checkout_url,
                "说明": "支付完成后，webhook 将自动更新交易状态",
            },
        )

        logger.info("Stripe 支付 URL 已生成，等待 webhook 通知支付结果：%s", checkout_url)

        # 返回交易（状态为 human_action_required）
        # webhook 监听器将异步更新状态为 completed 或 failed
        return tx.model_copy(
            update={
                "status": TransactionStatus.human_action_required,
                "human_action": human_action,
            }
        )

    # ------------------------------------------------------------------
    # 人类介入处理
    # ------------------------------------------------------------------

    async def _payment_gate_handoff(
        self,
        browser: BrowserController,
        tx: Transaction,
        *,
        adapter_name: str,
    ) -> Transaction:
        """Persist a scripted adapter handoff at a real payment gate."""
        now = datetime.now(UTC)
        await self._focus_browser(browser)
        current_url = await browser.get_current_url()
        display_info = self._display_manager.get_display_info()
        novnc_url: str | None = display_info.get("url")

        guidance = (
            f"{adapter_name} reached the payment authorization gate. "
            "Complete the payment in the visible browser, then confirm the "
            "session with ledger and artifact evidence."
        )
        human_action = HumanAction(
            action_type="payment_authorization",
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=novnc_url,
            guidance=guidance,
            details={
                "tx_id": tx.tx_id,
                "amount": f"{tx.amount:.2f} {tx.currency}",
                "payee": tx.payee,
                "payment_method": (
                    tx.payment_method.value if tx.payment_method is not None else None
                ),
                "adapter": adapter_name,
                "current_url": current_url,
                "instruction": (
                    "After real payment, confirm via the session confirm API "
                    f"or run payswitch confirm {tx.tx_id}."
                ),
            },
        )

        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=ExecutionMode.script,
            human_action=human_action,
            steps=tx.steps,
        )

        await self._display_manager.notify_human(
            message=guidance,
            action_type="payment_authorization",
            details={**(human_action.details or {})},
        )

        if not self._wait_for_human_completion:
            refreshed = self._ledger.get(tx.tx_id)
            return refreshed if refreshed is not None else tx.model_copy(
                update={
                    "status": TransactionStatus.human_action_required,
                    "execution_mode": ExecutionMode.script,
                    "human_action": human_action,
                }
            )

        async def _gate_completion_callback() -> bool:
            refreshed = self._ledger.get(tx.tx_id)
            return refreshed is not None and refreshed.status == TransactionStatus.completed

        success = await self._display_manager.wait_for_completion(
            detector_callback=_gate_completion_callback,
            timeout=self._config.transaction_timeout,
        )
        refreshed = self._ledger.get(tx.tx_id)
        if success and refreshed is not None:
            return refreshed

        timeout_msg = "Payment gate authorization timed out"
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.timeout,
            execution_mode=ExecutionMode.script,
            completed_at=datetime.now(UTC),
            error=timeout_msg,
            human_action=human_action,
            steps=tx.steps,
        )
        refreshed = self._ledger.get(tx.tx_id)
        return refreshed if refreshed is not None else tx.model_copy(
            update={
                "status": TransactionStatus.timeout,
                "completed_at": datetime.now(UTC),
                "error": timeout_msg,
                "execution_mode": ExecutionMode.script,
                "human_action": human_action,
            }
        )

    async def _handle_human_interaction(
        self,
        browser: BrowserController,
        detection: DetectionResult,
        tx: Transaction,
    ) -> bool | None:
        """处理需要人类介入的支付环节。

        流程：
        1. 更新交易状态为 human_action_required
        2. 创建 HumanAction 记录（含显示模式和 noVNC URL）
        3. 通过 display.notify_human 通知终端用户
        4. 等待检测器报告操作完成（带倒计时 spinner）
        5. 返回是否成功完成

        Args:
            browser:   已启动的 BrowserController
            detection: 检测器扫描结果，包含操作类型和描述
            tx:        当前交易对象

        Returns:
            True 表示人类操作在超时前完成；False 表示等待超时；
            None 表示调用方要求在人工闸口处立即返回。
        """
        now = datetime.now(UTC)

        await self._focus_browser(browser)

        # ---- 构建显示信息（headed / noVNC URL）----
        display_info = self._display_manager.get_display_info()
        novnc_url: str | None = display_info.get("url")

        # ---- 创建 HumanAction 记录 ----
        human_action = HumanAction(
            action_type=detection.action_type,
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=novnc_url,
            guidance=detection.description,
            details={
                **detection.data,
                "tx_id": tx.tx_id,
                "amount": f"¥{tx.amount:.2f}",
                "payee": tx.payee,
            },
        )

        # ---- 更新交易状态：human_action_required ----
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=ExecutionMode.human_takeover,
            human_action=human_action,
            steps=tx.steps,
        )
        logger.info("交易 %s 进入人类介入状态：%s", tx.tx_id, detection.action_type)

        # ---- 通知终端用户 ----
        await self._display_manager.notify_human(
            message=detection.description,
            action_type=detection.action_type,
            details={
                **(human_action.details or {}),
            },
        )

        if not self._wait_for_human_completion:
            return None

        # ---- 等待检测器报告完成（使用 display.wait_for_completion）----
        # 构建与 DetectorPipeline.wait_for_completion 对应的异步回调
        async def _completion_callback() -> bool:
            """轮询检测器，检测人类操作是否完成。"""
            # 找到对应检测器并调用 detect_completion
            for detector in self._detector_pipeline._detectors:
                if detector.name == detection.detector_name:
                    return await detector.detect_completion(browser.page)
            return False

        success = await self._display_manager.wait_for_completion(
            detector_callback=_completion_callback,
            timeout=self._config.transaction_timeout,
        )

        # ---- 更新 HumanAction 完成时间 ----
        if success:
            completed_action = human_action.model_copy(update={"completed_at": datetime.now(UTC)})
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.human_action_required,
                human_action=completed_action,
                steps=tx.steps,
            )
            logger.info("人类操作已完成（action_type=%s）", detection.action_type)
        else:
            logger.warning(
                "等待人类操作超时（action_type=%s，timeout=%ds）",
                detection.action_type,
                self._config.transaction_timeout,
            )

        return success

    # ------------------------------------------------------------------
    # 人类完全接管模式
    # ------------------------------------------------------------------

    async def _human_takeover(
        self,
        browser: BrowserController,
        tx: Transaction,
    ) -> Transaction:
        """人类完全接管模式：通知用户直接操控浏览器完成支付。

        当脚本模式和智能模式均失败时调用此方法。
        浏览器已导航到某个页面，用户需要手动完成剩余操作。

        Args:
            browser: 已启动的 BrowserController
            tx:      当前交易对象

        Returns:
            更新后的 Transaction 对象
        """
        logger.info("进入人类接管模式（交易 %s）", tx.tx_id)
        await self._focus_browser(browser)

        # 构建接管说明文本
        current_url = await browser.get_current_url()
        takeover_message = (
            f"Automation could not finish checkout; complete payment in the browser.\n"
            f"Current page: {current_url}\n"
            f"After real payment, run: payswitch confirm {tx.tx_id}"
        )

        # 创建接管 HumanAction 记录
        now = datetime.now(UTC)
        display_info = self._display_manager.get_display_info()
        novnc_url: str | None = display_info.get("url")

        human_action = HumanAction(
            action_type="takeover",
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=novnc_url,
            guidance=takeover_message,
            details={
                "tx_id": tx.tx_id,
                "amount": f"¥{tx.amount:.2f}",
                "payee": tx.payee,
                "current_url": current_url,
                "instruction": (
                    f"After real payment, run payswitch confirm {tx.tx_id}. "
                    "Takeover mode never auto-completes from page text alone."
                ),
            },
        )

        # 追加接管步骤记录
        takeover_step = StepRecord(
            step_index=len(tx.steps),
            description="自动化失败，进入人类接管模式",
            status="pending",
            started_at=now,
        )
        tx = tx.model_copy(
            update={
                "execution_mode": ExecutionMode.human_takeover,
                "steps": [*tx.steps, takeover_step],
                "human_action": human_action,
            }
        )

        # 更新数据库：状态设为 human_action_required
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            execution_mode=ExecutionMode.human_takeover,
            human_action=human_action,
            steps=tx.steps,
        )

        # 通知终端用户接管
        await self._display_manager.notify_human(
            message=takeover_message,
            action_type="takeover",
            details={
                **(human_action.details or {}),
            },
        )

        if not self._wait_for_human_completion:
            refreshed = self._ledger.get(tx.tx_id)
            return refreshed if refreshed is not None else tx.model_copy(
                update={
                    "status": TransactionStatus.human_action_required,
                    "human_action": human_action,
                }
            )

        # Human takeover accepts only explicit confirmation to avoid false ledger completion.
        async def _takeover_completion_callback() -> bool:
            """Only explicit payswitch confirm/API confirmation completes takeover payment."""
            refreshed = self._ledger.get(tx.tx_id)
            return refreshed is not None and refreshed.status == TransactionStatus.completed

        success = await self._display_manager.wait_for_completion(
            detector_callback=_takeover_completion_callback,
            timeout=self._config.transaction_timeout,
        )

        now = datetime.now(UTC)
        if success:
            # 人类接管后支付完成
            completed_action = human_action.model_copy(update={"completed_at": now})
            completed_step = takeover_step.model_copy(
                update={"status": "success", "completed_at": now}
            )
            updated_steps = [*tx.steps[:-1], completed_step]

            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.completed,
                execution_mode=ExecutionMode.human_takeover,
                completed_at=now,
                human_action=completed_action,
                steps=updated_steps,
            )
            logger.info("人类接管完成，交易 %s 支付成功", tx.tx_id)
            return tx.model_copy(
                update={
                    "status": TransactionStatus.completed,
                    "completed_at": now,
                    "human_action": completed_action,
                    "steps": updated_steps,
                }
            )
        else:
            # 接管超时
            timeout_msg = "人类接管超时，用户未在规定时间内完成支付"
            failed_step = takeover_step.model_copy(update={"status": "failed", "completed_at": now})
            updated_steps = [*tx.steps[:-1], failed_step]

            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.timeout,
                execution_mode=ExecutionMode.human_takeover,
                completed_at=now,
                error=timeout_msg,
                steps=updated_steps,
            )
            logger.warning("交易 %s 人类接管超时", tx.tx_id)
            return tx.model_copy(
                update={
                    "status": TransactionStatus.timeout,
                    "completed_at": now,
                    "error": timeout_msg,
                    "steps": updated_steps,
                }
            )

    # ------------------------------------------------------------------
    # 辅助方法
    # ------------------------------------------------------------------

    def _requires_human(self, detection: DetectionResult) -> bool:
        """根据检测结果判断是否需要暂停等待人类介入。

        通过检测器名称找到对应检测器实例，调用其 requires_human() 方法。
        若找不到对应检测器，则保守地返回 True（触发人类介入）。

        Args:
            detection: 检测器扫描结果

        Returns:
            True 表示需要暂停等待人类；False 表示可继续自动执行
        """
        for detector in self._detector_pipeline._detectors:
            if detector.name == detection.detector_name:
                return detector.requires_human()
        # 未知检测器：保守处理，触发人类介入
        logger.warning("未找到检测器 %s，保守处理为需要人类介入", detection.detector_name)
        return True

    # ------------------------------------------------------------------
    # 手动确认与状态查询
    # ------------------------------------------------------------------

    async def confirm(self, tx_id: str) -> Transaction:
        """人类手动确认支付完成。

        适用于检测器未能自动识别完成状态的情况，
        用户通过 CLI 或 API 手动告知系统支付已完成。

        Args:
            tx_id: 要确认的交易 ID

        Returns:
            更新状态为 completed 的 Transaction 对象

        Raises:
            PaySwitchError: 交易不存在或已处于终态
        """
        tx = self._ledger.get(tx_id)
        if tx is None:
            raise PaySwitchError(f"交易不存在：{tx_id}")

        if tx.is_terminal() and tx.status != TransactionStatus.human_action_required:
            raise PaySwitchError(f"交易 {tx_id} 已处于终态（{tx.status}），无法再次确认")

        now = datetime.now(UTC)

        # 若有 HumanAction 记录，更新其完成时间
        updated_human_action: HumanAction | None = None
        if tx.human_action is not None and tx.human_action.completed_at is None:
            updated_human_action = tx.human_action.model_copy(update={"completed_at": now})

        self._ledger.update_status(
            tx_id,
            TransactionStatus.completed,
            completed_at=now,
            human_action=updated_human_action,
            steps=tx.steps,
        )

        self._recovery_watchdog.clear(tx_id)

        logger.info("交易 %s 已手动确认为完成", tx_id)

        return tx.model_copy(
            update={
                "status": TransactionStatus.completed,
                "completed_at": now,
                "human_action": updated_human_action or tx.human_action,
            }
        )

    async def get_status(self, tx_id: str) -> Transaction:
        """查询交易当前状态。

        Args:
            tx_id: 交易 ID

        Returns:
            对应的 Transaction 对象

        Raises:
            PaySwitchError: 交易不存在
        """
        tx = self._ledger.get(tx_id)
        if tx is None:
            raise PaySwitchError(f"交易不存在：{tx_id}")
        return tx

    def close(self) -> None:
        """清理资源，关闭数据库连接。

        编排器使用完毕后必须调用此方法，否则 SQLite 连接不会被释放。
        通常在 CLI 入口或 FastAPI 应用生命周期结束时调用。
        """
        self._ledger.close()
        logger.info("PaymentOrchestrator 已关闭，所有资源已释放")

    # ------------------------------------------------------------------
    # 上下文管理器支持（async with 语法）
    # ------------------------------------------------------------------

    async def __aenter__(self) -> PaymentOrchestrator:
        """支持 async with 语句。"""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """退出 async with 块时自动调用 close()。"""
        self.close()
