"""Recovery watchdog for bounded script failure fallback and recovery context."""

from __future__ import annotations

from collections import deque
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

from pydantic import BaseModel

RECOVERY_CLASS_RETRYABLE_DRIFT = "retryable_drift"
RECOVERY_CLASS_LOGIN_REQUIRED = "login_required"
RECOVERY_CLASS_SENSITIVE_ACTION = "sensitive_action"
RECOVERY_CLASS_UNSUPPORTED_PAGE = "unsupported_page"
RECOVERY_CLASS_HARD_FAILURE = "hard_failure"

RECOVERY_ACTION_COMPUTER_USE = "computer_use_recovery"
RECOVERY_ACTION_LOGIN_GATE = "login_human_gate"
RECOVERY_ACTION_HUMAN_GATE = "human_recovery_gate"


class RecoveryDecision(BaseModel):
    """Result of evaluating a script failure recovery opportunity."""

    allow_recovery: bool
    requires_human_gate: bool
    requires_resync: bool
    register_candidate_patch: bool
    attempts_remaining: int
    reason: str
    is_high_risk: bool
    stale_buffer_discarded: bool
    classification: str
    recommended_action: str


@dataclass(slots=True)
class RecoveryState:
    """In-memory recovery state keyed by tx_id."""

    attempts: int = 0
    last_failure_at: datetime | None = None
    last_checkpoint_at: datetime | None = None
    telemetry_buffer: deque[dict[str, Any]] = field(default_factory=deque)
    stale_resync_count: int = 0
    last_classification: str | None = None
    last_recommended_action: str | None = None


class RecoveryWatchdog:
    """Guarded recovery coordinator for script-mode failures."""

    def __init__(
        self,
        *,
        max_attempts: int = 2,
        context_ttl_seconds: int = 900,
        telemetry_buffer_size: int = 12,
    ) -> None:
        self._max_attempts = max_attempts
        self._context_ttl_seconds = context_ttl_seconds
        self._context_ttl = timedelta(seconds=context_ttl_seconds)
        self._telemetry_buffer_size = telemetry_buffer_size
        self._states: dict[str, RecoveryState] = {}

    def register_script_failure(
        self,
        tx_id: str,
        failure_context: Mapping[str, Any] | None,
        *,
        now: datetime | None = None,
    ) -> RecoveryDecision:
        """Register one script failure and return a bounded recovery decision."""
        context = self._normalize_context(failure_context)
        state = self._states.setdefault(tx_id, RecoveryState())
        now = now or datetime.now(UTC)
        stale = self._is_stale(state, now=now)
        if stale:
            state.telemetry_buffer.clear()
            state.stale_resync_count += 1
        state.attempts += 1
        state.last_failure_at = now
        state.telemetry_buffer.append(context)
        while len(state.telemetry_buffer) > self._telemetry_buffer_size:
            state.telemetry_buffer.popleft()

        classification = self._classify_failure(context)
        recommended_action = self._recommended_action(classification)
        state.last_classification = classification
        state.last_recommended_action = recommended_action
        if recommended_action != RECOVERY_ACTION_COMPUTER_USE:
            return RecoveryDecision(
                allow_recovery=False,
                requires_human_gate=True,
                requires_resync=False,
                register_candidate_patch=True,
                attempts_remaining=max(0, self._max_attempts - state.attempts),
                reason=self._classification_reason(classification),
                is_high_risk=classification == RECOVERY_CLASS_SENSITIVE_ACTION,
                stale_buffer_discarded=stale,
                classification=classification,
                recommended_action=recommended_action,
            )

        remaining = self._max_attempts - state.attempts
        if remaining < 0:
            return RecoveryDecision(
                allow_recovery=False,
                requires_human_gate=True,
                requires_resync=stale,
                register_candidate_patch=True,
                attempts_remaining=0,
                reason=f"recovery attempt budget exhausted after {classification}",
                is_high_risk=False,
                stale_buffer_discarded=stale,
                classification=classification,
                recommended_action=RECOVERY_ACTION_HUMAN_GATE,
            )

        return RecoveryDecision(
            allow_recovery=True,
            requires_human_gate=False,
            requires_resync=stale,
            register_candidate_patch=True,
            attempts_remaining=remaining,
            reason=self._classification_reason(classification),
            is_high_risk=False,
            stale_buffer_discarded=stale,
            classification=classification,
            recommended_action=recommended_action,
        )

    def mark_checkpoint(self, tx_id: str, *, now: datetime | None = None) -> None:
        """Update checkpoint time for the recovery state."""
        state = self._states.setdefault(tx_id, RecoveryState())
        state.last_checkpoint_at = now or datetime.now(UTC)

    def get_telemetry_buffer(self, tx_id: str) -> list[dict[str, Any]]:
        """Return a copy of latest structured failure context for tx_id."""
        state = self._states.get(tx_id)
        return list(state.telemetry_buffer) if state else []

    def describe_state(self, tx_id: str) -> dict[str, Any] | None:
        """Return a structured snapshot for recovery evidence and debugging."""
        state = self._states.get(tx_id)
        if state is None:
            return None
        return {
            "attempts": state.attempts,
            "last_failure_at": self._iso(state.last_failure_at),
            "last_checkpoint_at": self._iso(state.last_checkpoint_at),
            "telemetry_ttl_seconds": self._context_ttl_seconds,
            "telemetry_buffer": list(state.telemetry_buffer),
            "stale_resync_count": state.stale_resync_count,
            "last_classification": state.last_classification,
            "last_recommended_action": state.last_recommended_action,
        }

    def clear(self, tx_id: str) -> None:
        """Clear a tx_id recovery state from memory."""
        self._states.pop(tx_id, None)

    def _is_stale(self, state: RecoveryState, *, now: datetime) -> bool:
        if state.last_checkpoint_at is None:
            return False
        return now - state.last_checkpoint_at > self._context_ttl

    def _classify_failure(self, context: dict[str, Any]) -> str:
        if self._is_login_required(context):
            return RECOVERY_CLASS_LOGIN_REQUIRED
        if self._is_sensitive_action(context):
            return RECOVERY_CLASS_SENSITIVE_ACTION
        if self._is_unsupported_page(context):
            return RECOVERY_CLASS_UNSUPPORTED_PAGE
        if self._is_hard_failure(context):
            return RECOVERY_CLASS_HARD_FAILURE
        return RECOVERY_CLASS_RETRYABLE_DRIFT

    def _recommended_action(self, classification: str) -> str:
        if classification == RECOVERY_CLASS_LOGIN_REQUIRED:
            return RECOVERY_ACTION_LOGIN_GATE
        if classification in {
            RECOVERY_CLASS_SENSITIVE_ACTION,
            RECOVERY_CLASS_HARD_FAILURE,
        }:
            return RECOVERY_ACTION_HUMAN_GATE
        return RECOVERY_ACTION_COMPUTER_USE

    def _classification_reason(self, classification: str) -> str:
        return f"failure classified as {classification}"

    def _is_sensitive_action(self, context: dict[str, Any]) -> bool:
        if self._truthy(context, "requires_human_authorization", "requires_human_gate"):
            return True
        if self._truthy(context, "synchronous_policy_checkpoint"):
            return True
        waypoint_risk = str(context.get("waypoint_risk", "")).lower()
        if waypoint_risk in {"high", "human_required"}:
            return True

        category = str(context.get("waypoint_category", "")).lower()
        action = str(context.get("action_type", "")).lower()
        if category in {"sensitive", "final_authorization"}:
            return True
        if action in {"payment_gate", "payment_authorization", "confirm"}:
            return True

        return False

    def _is_login_required(self, context: dict[str, Any]) -> bool:
        if self._truthy(
            context,
            "login_required",
            "requires_login",
            "auth_required",
            "authentication_required",
        ):
            return True
        failure_class = str(context.get("failure_class", "")).lower()
        if failure_class == "loginrequirederror":
            return True
        text = self._context_text(context)
        return self._contains_any(
            text,
            (
                "login required",
                "sign in",
                "sign-in",
                "not authenticated",
                "authentication required",
                "session expired",
                "登录",
                "未登录",
                "登录态失效",
                "会话失效",
            ),
        )

    def _is_unsupported_page(self, context: dict[str, Any]) -> bool:
        if self._truthy(context, "unsupported_page", "unsupported_surface"):
            return True
        if self._explicit_false(context, "page_supported", "surface_supported"):
            return True
        text = self._context_text(context)
        return self._contains_any(
            text,
            (
                "unsupported page",
                "unsupported surface",
                "page not supported",
                "页面不支持",
                "当前页面不支持",
                "支付区块",
            ),
        )

    def _is_hard_failure(self, context: dict[str, Any]) -> bool:
        if self._truthy(
            context,
            "hard_failure",
            "terminal_failure",
            "policy_blocked",
            "config_error",
            "non_retryable",
        ):
            return True
        if self._explicit_false(context, "is_retryable", "retryable"):
            return True
        failure_type = str(context.get("failure_type", "")).lower()
        if failure_type in {
            "config",
            "configuration",
            "validation",
            "policy",
            "unsupported_method",
            "provider",
        }:
            return True
        text = self._context_text(context)
        return self._contains_any(
            text,
            (
                "未配置",
                "未注册",
                "配置错误",
                "invalid amount",
                "must be >=",
                "must be > 0",
                "必须大于 0",
                "sdk 未安装",
                "unsupported payment method",
            ),
        )

    def _normalize_context(self, context: Mapping[str, Any] | None) -> dict[str, Any]:
        if context is None:
            return {}
        return dict(context)

    def _truthy(self, context: Mapping[str, Any], *keys: str) -> bool:
        return any(bool(context.get(key)) for key in keys)

    def _explicit_false(self, context: Mapping[str, Any], *keys: str) -> bool:
        return any(key in context and context.get(key) is False for key in keys)

    def _context_text(self, context: Mapping[str, Any]) -> str:
        parts = [
            str(context.get("failure_reason", "")),
            str(context.get("failure_message", "")),
            str(context.get("message", "")),
            str(context.get("waypoint_id", "")),
            str(context.get("waypoint_category", "")),
            str(context.get("action_type", "")),
        ]
        return " ".join(part for part in parts if part).lower()

    def _contains_any(self, text: str, patterns: tuple[str, ...]) -> bool:
        return any(pattern in text for pattern in patterns)

    def _iso(self, value: datetime | None) -> str | None:
        if value is None:
            return None
        return value.isoformat().replace("+00:00", "Z")
