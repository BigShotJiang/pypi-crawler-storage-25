"""卡表单检测与全字段自动填写引擎。

核心组件：
- CardFormDetector: 多层级字段匹配引擎（Bitwarden 算法移植 + Stripe iframe 穿透）
- CardFormFiller: 全字段填写引擎（卡号+有效期+CVV+姓名+地址）
- is_field_match: 字段属性匹配函数（移植自 Bitwarden isFieldMatch）
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from playwright.async_api import Locator, Page

logger = logging.getLogger(__name__)

# ============================================================================
# 异常类
# ============================================================================


class CardFormNotFoundError(RuntimeError):
    """未能在页面上检测到卡表单。"""


# ============================================================================
# 字段匹配核心算法（移植自 Bitwarden isFieldMatch）
# ============================================================================


def is_field_match(
    value: str,
    options: list[str],
    contains_options: list[str] | None = None,
) -> bool:
    """判断字段属性值是否匹配关键词列表。

    标准化规则（和 Bitwarden 完全一致）：
    - 输入值：strip() → lower() → 去除所有非字母数字字符
    - 选项：lower() → 去除连字符
    - 匹配：精确匹配 OR 子串匹配（受 contains_options 控制）

    Args:
        value: 待检测的属性值（name/id/placeholder 等）
        options: 完整关键词列表（精确匹配）
        contains_options: 允许子串匹配的关键词子集；None 表示全部允许子串
    """
    normalized = re.sub(r"[^a-zA-Z0-9]", "", value.strip().lower())
    if not normalized:
        return False

    for option in options:
        norm_option = option.lower().replace("-", "")
        check_contains = contains_options is None or option in contains_options
        if normalized == norm_option:
            return True
        if check_contains and norm_option in normalized:
            return True

    return False


# ============================================================================
# 关键词常量（直接移植自 Bitwarden autofill-constants.ts）
# ============================================================================

# ---- 卡号 ----
CARD_NUMBER_OPTIONS = [
    "cc-number",
    "cc-num",
    "card-number",
    "card-num",
    "number",
    "cc",
    "cc-no",
    "card-no",
    "credit-card",
    "numero-carte",
    "carte",
    "carte-credit",
    "num-carte",
    "cb-num",
    "card-pan",
]
CARD_NUMBER_CONTAINS = [
    "cc-number",
    "cc-num",
    "card-number",
    "card-num",
    "cc-no",
    "card-no",
    "numero-carte",
    "num-carte",
    "cb-num",
]

# ---- CVV/CVC ----
CVV_OPTIONS = [
    "cvv",
    "cvc",
    "cvv2",
    "cc-csc",
    "cc-cvv",
    "card-csc",
    "card-cvv",
    "cvd",
    "cid",
    "cvc2",
    "cnv",
    "cvn2",
    "cc-code",
    "card-code",
    "code-securite",
    "security-code",
    "crypto",
    "card-verif",
    "verification-code",
    "csc",
    "ccv",
]

# ---- 有效期（合并） ----
EXPIRY_OPTIONS = [
    "cc-exp",
    "card-exp",
    "cc-expiration",
    "card-expiration",
    "cc-ex",
    "card-ex",
    "card-expire",
    "card-expiry",
    "validite",
    "expiration",
    "expiry",
    "mm-yy",
    "mm-yyyy",
    "yy-mm",
    "yyyy-mm",
    "expiration-date",
    "payment-card-expiration",
    "payment-cc-date",
]
EXPIRY_CONTAINS = [
    "mm-yy",
    "mm-yyyy",
    "yy-mm",
    "yyyy-mm",
    "expiration-date",
    "payment-card-expiration",
]

# ---- 有效期（月） ----
EXPIRY_MONTH_OPTIONS = [
    "exp-month",
    "cc-exp-month",
    "cc-month",
    "card-month",
    "cc-mo",
    "card-mo",
    "exp-mo",
    "card-exp-mo",
    "cc-exp-mo",
    "card-expiration-month",
    "expiration-month",
    "cc-mm",
    "cc-m",
    "card-mm",
    "card-m",
    "card-exp-mm",
    "cc-exp-mm",
    "exp-mm",
    "exp-m",
    "expire-month",
    "expire-mo",
    "expiry-month",
    "expiry-mo",
    "card-expire-month",
    "card-expire-mo",
    "card-expiry-month",
    "card-expiry-mo",
    "mois-validite",
    "mois-expiration",
    "m-validite",
    "m-expiration",
    "expiry-date-field-month",
    "expiration-date-month",
    "expiration-date-mm",
    "exp-mon",
    "validity-mo",
    "exp-date-mo",
    "cb-date-mois",
    "date-m",
]

# ---- 有效期（年） ----
EXPIRY_YEAR_OPTIONS = [
    "exp-year",
    "cc-exp-year",
    "cc-year",
    "card-year",
    "cc-yr",
    "card-yr",
    "exp-yr",
    "card-exp-yr",
    "cc-exp-yr",
    "card-expiration-year",
    "expiration-year",
    "cc-yy",
    "cc-y",
    "card-yy",
    "card-y",
    "card-exp-yy",
    "cc-exp-yy",
    "exp-yy",
    "exp-y",
    "cc-yyyy",
    "card-yyyy",
    "card-exp-yyyy",
    "cc-exp-yyyy",
    "expire-year",
    "expire-yr",
    "expiry-year",
    "expiry-yr",
    "card-expire-year",
    "card-expire-yr",
    "card-expiry-year",
    "card-expiry-yr",
    "an-validite",
    "an-expiration",
    "annee-validite",
    "annee-expiration",
    "expiry-date-field-year",
    "expiration-date-year",
    "cb-date-ann",
    "expiration-date-yy",
    "expiration-date-yyyy",
    "validity-year",
    "exp-date-year",
    "date-y",
]

# ---- 持卡人姓名 ----
CARDHOLDER_OPTIONS = [
    "accountholdername",
    "cc-name",
    "card-name",
    "cardholder-name",
    "cardholder",
    "name",
    "nom",
]
CARDHOLDER_CONTAINS = [
    "accountholdername",
    "cc-name",
    "card-name",
    "cardholder-name",
    "cardholder",
    "tbName",
]

# ---- 账单地址 ----
BILLING_ADDRESS_OPTIONS = [
    "billing-address",
    "billing-address-line-1",
    "address-line1",
    "address-line-1",
    "street-address",
    "address1",
    "address",
    "billing-street",
    "addressLine1",
]
BILLING_CITY_OPTIONS = [
    "billing-city",
    "city",
    "locality",
    "address-level2",
]
BILLING_STATE_OPTIONS = [
    "billing-state",
    "state",
    "province",
    "region",
    "administrativeArea",
    "address-level1",
]
BILLING_POSTAL_OPTIONS = [
    "billing-zip",
    "billing-postal",
    "postal-code",
    "zip-code",
    "zip",
    "postalCode",
    "billingPostalCode",
]
BILLING_COUNTRY_OPTIONS = [
    "billing-country",
    "country",
    "country-name",
    "billingCountry",
]

# ---- 中文补充关键词 ----
CN_CARD_NUMBER = ["卡号", "信用卡号", "银行卡号"]
CN_EXPIRY = ["有效期", "到期日", "有效日期"]
CN_CVV = ["安全码", "验证码"]
CN_CARDHOLDER = ["持卡人", "持卡人姓名"]
CN_ADDRESS = ["账单地址", "地址", "街道"]
CN_CITY = ["城市"]
CN_POSTAL = ["邮编", "邮政编码"]

# 排除的 input 类型
_EXCLUDED_INPUT_TYPES = frozenset(
    ["radio", "checkbox", "hidden", "file", "button", "image", "reset", "search"]
)

# ============================================================================
# Stripe iframe 配置常量
# ============================================================================

STRIPE_CUSTOM_ELEMENTS = {
    "iframe_selector": 'iframe[name*="__privateStripeFrame"]',
    "fields": {
        "card_number": 'input[name="cardnumber"]',
        "expiry": 'input[name="exp-date"]',
        "cvv": 'input[name="cvc"]',
        "postal": 'input[name="postal"]',
    },
    "wait_timeout": 30000,
}

STRIPE_PAYMENT_ELEMENT = {
    "iframe_selector": ('form iframe[title*="payment input"][src*="elements-inner-payment"]'),
    "card_tab_selector": '[data-testid="card"], [data-value="card"]',
    "fields": {
        "card_number": 'input[name="number"]',
        "expiry": 'input[name="expiry"]',
        "cvv": 'input[name="cvc"]',
        "postal": 'input[name="postalCode"]',
        "country": 'select[name="country"]',
    },
    "wait_timeout": 30000,
}

STRIPE_CHECKOUT_SESSIONS = {
    "payment_iframe": ('#payment-element iframe[title="Secure payment input frame"]'),
    "address_iframe": ('#address-element iframe[title="Secure address input frame"]'),
    "fields": {
        "card_number": 'input[name="number"]',
        "expiry": 'input[name="expiry"]',
        "cvv": 'input[name="cvc"]',
        "name": 'input[name="name"]',
        "address": 'input[name="addressLine1"]',
        "postal": 'input[name="postalCode"]',
        "country": 'select[name="country"]',
        "state": 'select[name="administrativeArea"]',
        "city": '[name="locality"]',
    },
    "card_tab_selector": '[data-value="card"]',
    "wait_timeout": 30000,
}

STRIPE_PREBUILT_CHECKOUT = {
    "iframe_selector": None,
    "fields": {
        "email": 'input[name="email"]',
        "card_number": 'input[name="cardNumber"]',
        "expiry": 'input[name="cardExpiry"]',
        "cvv": 'input[name="CVC"]',
        "name": 'input[name="billingName"]',
        "country": 'select[name="billingCountry"]',
        "postal": 'input[name="billingPostalCode"]',
    },
    "card_accordion": '[data-testid="card-accordion-item"]',
    "wait_timeout": 30000,
}


# ============================================================================
# 数据模型
# ============================================================================


@dataclass
class CardFormFields:
    """检测到的卡表单字段集合（所有字段都可以自动填写）。"""

    # 卡片核心字段
    card_number: Locator | None = None
    expiry: Locator | None = None
    expiry_month: Locator | None = None
    expiry_year: Locator | None = None
    cvv: Locator | None = None
    cardholder_name: Locator | None = None

    # 账单地址字段
    billing_address: Locator | None = None
    billing_city: Locator | None = None
    billing_state: Locator | None = None
    billing_postal: Locator | None = None
    billing_country: Locator | None = None

    # 元信息
    is_iframe: bool = False
    processor: str | None = None
    stripe_mode: str | None = None
    confidence: float = 0.0
    detection_level: int = 0


@dataclass
class CardFillResult:
    """卡表单填写结果。"""

    filled_fields: list[str] = field(default_factory=list)
    human_fields: list[str] = field(default_factory=list)
    needs_human_gate: bool = False
    processor: str | None = None
    stripe_mode: str | None = None
    detection_level: int = 0


# ============================================================================
# Stripe 模式检测
# ============================================================================


async def detect_stripe_mode(page: Page) -> str | None:
    """检测当前页面使用的 Stripe 集成模式。"""
    # 1. Stripe 托管 Checkout 页面
    if "checkout.stripe.com" in page.url:
        return "prebuilt_checkout"
    # 2. Checkout Sessions + Elements
    if await page.locator('#payment-element iframe[title="Secure payment input frame"]').count():
        return "checkout_sessions"
    # 3. Payment Element
    if await page.locator(
        'form iframe[title*="payment input"][src*="elements-inner-payment"]'
    ).count():
        return "payment_element"
    # 4. Custom Elements
    if await page.locator('iframe[name*="__privateStripeFrame"]').count():
        return "custom_elements"
    return None


# ============================================================================
# CardFormDetector — 多层级字段检测引擎
# ============================================================================


class CardFormDetector:
    """多层级卡表单字段检测器。

    检测层级（优先级从高到低）：
    - Level 0: Stripe iframe 穿透（4 种模式）
    - Level 1: HTML 属性匹配（autocomplete/name/id/placeholder 等）
    - Level 2: Label/Placeholder 文本匹配（含中文）
    """

    async def detect(self, page: Page) -> CardFormFields:
        """在页面上检测卡表单字段。"""
        # Level 0: Stripe iframe 穿透
        stripe_mode = await detect_stripe_mode(page)
        if stripe_mode:
            logger.info("检测到 Stripe 模式：%s", stripe_mode)
            return await self._detect_stripe(page, stripe_mode)

        # Level 1: HTML 属性匹配
        result = await self._detect_by_attributes(page)
        if result.card_number:
            result.detection_level = 1
            return result

        # Level 2: Label/Placeholder 文本匹配
        result = await self._detect_by_labels(page)
        if result.card_number:
            result.detection_level = 2
        return result

    async def _detect_by_attributes(self, page: Page) -> CardFormFields:
        """Level 1: 通过 HTML 属性匹配字段类型。"""
        result = CardFormFields()
        # 获取所有可见的 input 和 select 元素
        inputs = await page.locator(
            'input:not([type="radio"]):not([type="checkbox"])'
            ':not([type="hidden"]):not([type="file"])'
            ':not([type="button"]):not([type="image"])'
            ':not([type="reset"]):not([type="search"])'
        ).all()
        selects = await page.locator("select").all()

        all_elements = inputs + selects

        for el in all_elements:
            if not await el.is_visible():
                continue

            # 按优先级获取属性值
            attrs = await self._get_field_attributes(el)

            # 按字段类型检测顺序逐一匹配
            for attr_val in attrs:
                if not attr_val:
                    continue

                if result.cardholder_name is None and is_field_match(
                    attr_val, CARDHOLDER_OPTIONS, CARDHOLDER_CONTAINS
                ):
                    result.cardholder_name = el
                    break
                if result.card_number is None and is_field_match(
                    attr_val, CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS
                ):
                    result.card_number = el
                    break
                if result.expiry is None and is_field_match(
                    attr_val, EXPIRY_OPTIONS, EXPIRY_CONTAINS
                ):
                    result.expiry = el
                    break
                if result.expiry_month is None and is_field_match(attr_val, EXPIRY_MONTH_OPTIONS):
                    result.expiry_month = el
                    break
                if result.expiry_year is None and is_field_match(attr_val, EXPIRY_YEAR_OPTIONS):
                    result.expiry_year = el
                    break
                if result.cvv is None and is_field_match(attr_val, CVV_OPTIONS):
                    result.cvv = el
                    break
                # 账单地址字段
                if result.billing_address is None and is_field_match(
                    attr_val, BILLING_ADDRESS_OPTIONS
                ):
                    result.billing_address = el
                    break
                if result.billing_city is None and is_field_match(attr_val, BILLING_CITY_OPTIONS):
                    result.billing_city = el
                    break
                if result.billing_state is None and is_field_match(attr_val, BILLING_STATE_OPTIONS):
                    result.billing_state = el
                    break
                if result.billing_postal is None and is_field_match(
                    attr_val, BILLING_POSTAL_OPTIONS
                ):
                    result.billing_postal = el
                    break
                if result.billing_country is None and is_field_match(
                    attr_val, BILLING_COUNTRY_OPTIONS
                ):
                    result.billing_country = el
                    break

        if result.card_number:
            result.confidence = 0.8
        return result

    async def _detect_by_labels(self, page: Page) -> CardFormFields:
        """Level 2: 通过 label 文本和 placeholder 匹配（含中文）。"""
        result = CardFormFields()
        inputs = await page.locator(
            'input:not([type="radio"]):not([type="checkbox"])'
            ':not([type="hidden"]):not([type="file"])'
            ':not([type="button"]):not([type="image"])'
            ':not([type="reset"]):not([type="search"])'
        ).all()

        for el in inputs:
            if not await el.is_visible():
                continue

            placeholder = (await el.get_attribute("placeholder")) or ""
            # 尝试获取关联 label 文本
            el_id = (await el.get_attribute("id")) or ""
            label_text = ""
            if el_id:
                label_el = page.locator(f'label[for="{el_id}"]')
                if await label_el.count():
                    label_text = (await label_el.first.inner_text()).strip()

            texts = [placeholder, label_text]

            for text in texts:
                if not text:
                    continue
                # 中文 + 英文关键词匹配
                if result.card_number is None and _cn_match(text, CN_CARD_NUMBER):
                    result.card_number = el
                    break
                if result.expiry is None and _cn_match(text, CN_EXPIRY):
                    result.expiry = el
                    break
                if result.cvv is None and _cn_match(text, CN_CVV):
                    result.cvv = el
                    break
                if result.cardholder_name is None and _cn_match(text, CN_CARDHOLDER):
                    result.cardholder_name = el
                    break
                if result.billing_address is None and _cn_match(text, CN_ADDRESS):
                    result.billing_address = el
                    break
                if result.billing_city is None and _cn_match(text, CN_CITY):
                    result.billing_city = el
                    break
                if result.billing_postal is None and _cn_match(text, CN_POSTAL):
                    result.billing_postal = el
                    break

        if result.card_number:
            result.confidence = 0.6
        return result

    async def _detect_stripe(self, page: Page, mode: str) -> CardFormFields:
        """Level 0: Stripe iframe 穿透检测。"""
        result = CardFormFields(
            is_iframe=mode != "prebuilt_checkout",
            processor=f"stripe_{mode}",
            stripe_mode=mode,
            detection_level=0,
            confidence=0.95,
        )

        if mode == "prebuilt_checkout":
            return await self._detect_stripe_prebuilt(page, result)
        elif mode == "checkout_sessions":
            return await self._detect_stripe_checkout_sessions(page, result)
        elif mode == "payment_element":
            return await self._detect_stripe_payment_element(page, result)
        elif mode == "custom_elements":
            return await self._detect_stripe_custom_elements(page, result)
        return result

    async def _detect_stripe_prebuilt(self, page: Page, result: CardFormFields) -> CardFormFields:
        """Stripe Prebuilt Checkout（无 iframe，checkout.stripe.com 页面）。"""
        cfg = STRIPE_PREBUILT_CHECKOUT
        # 尝试展开卡片区域
        accordion = cfg.get("card_accordion", "")
        if accordion:
            acc_el = page.locator(accordion)
            if await acc_el.count():
                await acc_el.first.click()

        fields = cfg["fields"]
        result.card_number = page.locator(fields["card_number"])
        result.expiry = page.locator(fields["expiry"])
        result.cvv = page.locator(fields["cvv"])
        if "name" in fields:
            result.cardholder_name = page.locator(fields["name"])
        if "country" in fields:
            result.billing_country = page.locator(fields["country"])
        if "postal" in fields:
            result.billing_postal = page.locator(fields["postal"])
        return result

    async def _detect_stripe_payment_element(
        self, page: Page, result: CardFormFields
    ) -> CardFormFields:
        """Stripe Payment Element（新版统一元素）。"""
        cfg = STRIPE_PAYMENT_ELEMENT
        iframe_sel = cfg["iframe_selector"]
        await page.wait_for_selector(iframe_sel, timeout=cfg["wait_timeout"])

        # 尝试点击卡支付 tab
        tab_sel = cfg.get("card_tab_selector", "")
        if tab_sel:
            tab = page.locator(tab_sel)
            if await tab.count():
                await tab.first.click()

        frame = page.frame_locator(iframe_sel)
        fields = cfg["fields"]
        result.card_number = frame.locator(fields["card_number"])
        result.expiry = frame.locator(fields["expiry"])
        result.cvv = frame.locator(fields["cvv"])
        if "postal" in fields:
            result.billing_postal = frame.locator(fields["postal"])
        if "country" in fields:
            result.billing_country = frame.locator(fields["country"])
        return result

    async def _detect_stripe_custom_elements(
        self, page: Page, result: CardFormFields
    ) -> CardFormFields:
        """Stripe Custom Elements（旧版独立元素）。"""
        cfg = STRIPE_CUSTOM_ELEMENTS
        iframe_sel = cfg["iframe_selector"]
        await page.wait_for_selector(iframe_sel, timeout=cfg["wait_timeout"])

        frame = page.frame_locator(iframe_sel)
        fields = cfg["fields"]
        result.card_number = frame.locator(fields["card_number"])
        result.expiry = frame.locator(fields["expiry"])
        result.cvv = frame.locator(fields["cvv"])
        if "postal" in fields:
            result.billing_postal = frame.locator(fields["postal"])
        return result

    async def _detect_stripe_checkout_sessions(
        self, page: Page, result: CardFormFields
    ) -> CardFormFields:
        """Stripe Checkout Sessions + Elements（双 iframe）。"""
        cfg = STRIPE_CHECKOUT_SESSIONS
        pay_iframe_sel = cfg["payment_iframe"]
        addr_iframe_sel = cfg["address_iframe"]

        await page.wait_for_selector(pay_iframe_sel, timeout=cfg["wait_timeout"])

        # 尝试点击卡支付 tab
        tab_sel = cfg.get("card_tab_selector", "")
        if tab_sel:
            tab = page.locator(tab_sel)
            if await tab.count():
                await tab.first.click()

        # 支付 iframe 中的字段
        pay_frame = page.frame_locator(pay_iframe_sel)
        fields = cfg["fields"]
        result.card_number = pay_frame.locator(fields["card_number"])
        result.expiry = pay_frame.locator(fields["expiry"])
        result.cvv = pay_frame.locator(fields["cvv"])

        # 地址 iframe 中的字段（如果存在）
        if await page.locator(addr_iframe_sel).count():
            addr_frame = page.frame_locator(addr_iframe_sel)
            if "name" in fields:
                result.cardholder_name = addr_frame.locator(fields["name"])
            if "address" in fields:
                result.billing_address = addr_frame.locator(fields["address"])
            if "city" in fields:
                result.billing_city = addr_frame.locator(fields["city"])
            if "state" in fields:
                result.billing_state = addr_frame.locator(fields["state"])
            if "postal" in fields:
                result.billing_postal = addr_frame.locator(fields["postal"])
            if "country" in fields:
                result.billing_country = addr_frame.locator(fields["country"])
        return result

    async def _get_field_attributes(self, el: Locator) -> list[str]:
        """按 Bitwarden 10 级优先级获取字段属性值。"""
        attrs = []
        for attr_name in [
            "autocomplete",
            "data-stripe",
            "name",
            "id",
            "title",
            "placeholder",
            "data-recurly",
        ]:
            val = await el.get_attribute(attr_name)
            if val:
                attrs.append(val)
        return attrs


# ============================================================================
# CardFormFiller — 全字段填写引擎
# ============================================================================


class CardFormFiller:
    """卡表单全字段填写引擎。

    填写顺序：卡号 → 有效期 → CVV → 持卡人姓名 → 账单地址
    仅在遇到 OTP/3DS/CAPTCHA 时触发 Human Gate。
    """

    def __init__(self) -> None:
        self.detector = CardFormDetector()

    async def detect_and_fill(
        self,
        page: Page,
        secret_ref: str,
        *,
        dry_run: bool = False,
    ) -> CardFillResult:
        """检测表单并填写全部卡字段。"""
        from payswitch.security.card_vault import (
            CardVaultError,
            VirtualCardData,
            load_card_number,
            load_virtual_card,
        )
        from payswitch.security.redaction import mask_cvv, mask_expiry, mask_pan

        # 1. 检测表单所有字段
        fields = await self.detector.detect(page)
        if fields.card_number is None:
            raise CardFormNotFoundError("未检测到卡号输入框")

        # 2. 从 Keyring 加载虚拟卡完整数据
        card = load_virtual_card(secret_ref)
        if card is None:
            # 向后兼容：尝试旧的 card_number_only 格式
            pan = load_card_number(secret_ref)
            if pan is None:
                raise CardVaultError("未找到已存储的虚拟卡")
            card = VirtualCardData(card_number=pan)

        filled: list[str] = []

        if dry_run:
            # dry_run 模式：只返回检测结果，不实际填写
            if card.card_number:
                filled.append("card_number")
            if card.expiry_month and (fields.expiry or fields.expiry_month):
                filled.append("expiry")
            if card.cvv and fields.cvv:
                filled.append("cvv")
            if card.holder_name and fields.cardholder_name:
                filled.append("cardholder_name")
            if card.billing_address and fields.billing_address:
                filled.append("billing_address")
            human_fields = await self._detect_dynamic_challenges(page)
            return CardFillResult(
                filled_fields=filled,
                human_fields=human_fields,
                needs_human_gate=bool(human_fields),
                processor=fields.processor,
                stripe_mode=fields.stripe_mode,
                detection_level=fields.detection_level,
            )

        # 3. 填入卡号
        await self._fill_field(
            fields.card_number,
            card.card_number,
            is_iframe=fields.is_iframe,
            processor=fields.processor,
        )
        filled.append("card_number")
        logger.info("已填入卡号：%s", mask_pan(card.card_number))

        # 4. 填入有效期
        if fields.expiry and card.expiry_month:
            expiry_str = f"{card.expiry_month}/{card.expiry_year}"
            await self._fill_field(
                fields.expiry,
                expiry_str,
                is_iframe=fields.is_iframe,
                processor=fields.processor,
            )
            filled.append("expiry")
            logger.info("已填入有效期：%s", mask_expiry(card.expiry_month, card.expiry_year))
        elif fields.expiry_month and card.expiry_month:
            await self._fill_field(
                fields.expiry_month,
                card.expiry_month,
                is_iframe=fields.is_iframe,
                processor=fields.processor,
            )
            if fields.expiry_year and card.expiry_year:
                await self._fill_field(
                    fields.expiry_year,
                    card.expiry_year,
                    is_iframe=fields.is_iframe,
                    processor=fields.processor,
                )
            filled.append("expiry")
            logger.info("已填入有效期：%s", mask_expiry(card.expiry_month, card.expiry_year))

        # 5. 填入 CVV（虚拟卡场景，自动填写）
        if fields.cvv and card.cvv:
            await self._fill_field(
                fields.cvv,
                card.cvv,
                is_iframe=fields.is_iframe,
                processor=fields.processor,
            )
            filled.append("cvv")
            logger.info("已填入安全码：%s", mask_cvv(card.cvv))

        # 6. 填入持卡人姓名
        if fields.cardholder_name and card.holder_name:
            await self._fill_field(
                fields.cardholder_name,
                card.holder_name,
                is_iframe=fields.is_iframe,
                processor=fields.processor,
            )
            filled.append("cardholder_name")
            logger.info("已填入持卡人：%s", card.holder_name)

        # 7. 填入账单地址
        if card.billing_address:
            addr = card.billing_address
            if fields.billing_country and addr.country:
                await self._select_or_fill(fields.billing_country, addr.country)
                filled.append("billing_country")
            if fields.billing_address and addr.line1:
                await self._fill_field(
                    fields.billing_address,
                    addr.line1,
                    is_iframe=fields.is_iframe,
                    processor=fields.processor,
                )
                # 地址自动补全弹窗：按 Escape 关闭，再 Tab 到下一个字段
                await fields.billing_address.press("Escape")
                await fields.billing_address.press("Tab")
                filled.append("billing_address")
            if fields.billing_city and addr.city:
                await self._fill_field(
                    fields.billing_city,
                    addr.city,
                    is_iframe=fields.is_iframe,
                    processor=fields.processor,
                )
                filled.append("billing_city")
            if fields.billing_state and addr.state:
                await self._select_or_fill(fields.billing_state, addr.state)
                filled.append("billing_state")
            if fields.billing_postal and addr.postal_code:
                await self._fill_field(
                    fields.billing_postal,
                    addr.postal_code,
                    is_iframe=fields.is_iframe,
                    processor=fields.processor,
                )
                filled.append("billing_postal")
            logger.info("已填入账单地址")

        # 8. 检测动态安全挑战
        human_fields = await self._detect_dynamic_challenges(page)

        return CardFillResult(
            filled_fields=filled,
            human_fields=human_fields,
            needs_human_gate=bool(human_fields),
            processor=fields.processor,
            stripe_mode=fields.stripe_mode,
            detection_level=fields.detection_level,
        )

    async def _fill_field(
        self,
        locator: Locator,
        value: str,
        *,
        is_iframe: bool = False,
        processor: str | None = None,
    ) -> None:
        """智能填入：Stripe iframe 用逐字符输入，普通字段用 fill()。"""
        if is_iframe and processor and "stripe" in processor:
            await locator.press_sequentially(value, delay=50)
        else:
            await locator.fill(value)

    async def _select_or_fill(self, locator: Locator, value: str) -> None:
        """智能选择：如果是 <select> 用 select_option，否则用 fill。"""
        tag = await locator.evaluate("el => el.tagName.toLowerCase()")
        if tag == "select":
            await locator.select_option(value=value)
        else:
            await locator.fill(value)

    async def _detect_dynamic_challenges(self, page: Page) -> list[str]:
        """检测页面上的动态安全挑战（OTP/3DS/CAPTCHA）。"""
        challenges: list[str] = []

        # OTP 输入框
        otp_indicators = [
            'input[autocomplete="one-time-code"]',
            'input[name*="otp"]',
            'input[name*="verification"]',
            'input[id*="otp"]',
            'input[placeholder*="验证码"]',
        ]
        for sel in otp_indicators:
            if await page.locator(sel).count():
                challenges.append("OTP 验证码")
                break

        # 3DS iframe
        tds_indicators = [
            'iframe[name*="3ds"]',
            'iframe[src*="3ds"]',
            'iframe[title*="3D Secure"]',
        ]
        for sel in tds_indicators:
            if await page.locator(sel).count():
                challenges.append("3DS 安全验证")
                break

        # CAPTCHA
        captcha_indicators = [
            'iframe[src*="recaptcha"]',
            'iframe[src*="hcaptcha"]',
            '[class*="captcha"]',
        ]
        for sel in captcha_indicators:
            if await page.locator(sel).count():
                challenges.append("CAPTCHA 验证")
                break

        return challenges


# ============================================================================
# 辅助函数
# ============================================================================


def _cn_match(text: str, keywords: list[str]) -> bool:
    """中文关键词子串匹配。"""
    for kw in keywords:
        if kw in text:
            return True
    return False
