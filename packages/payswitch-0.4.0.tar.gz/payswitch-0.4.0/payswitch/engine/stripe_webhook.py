"""Stripe Webhook 监听器。

通过 FastAPI 提供一个 HTTP 端点，接收 Stripe 发送的 webhook 事件通知，
验证签名后更新 Pay-Switch 账本中对应交易的状态。

支持的事件类型：
- checkout.session.completed: 支付成功 → TransactionStatus.completed
- checkout.session.expired: 会话过期 → TransactionStatus.cancelled
- payment_intent.payment_failed: 支付失败 → TransactionStatus.failed

使用示例::

    # 启动 webhook 监听器（独立进程）
    payswitch stripe listen --port 4242

    # 或在代码中手动启动
    import uvicorn
    from payswitch.engine.stripe_webhook import app
    uvicorn.run(app, host="0.0.0.0", port=4242)
"""

from __future__ import annotations

import logging
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# FastAPI 和 Stripe SDK 是可选依赖（需要 payswitch[stripe]）
try:
    import stripe
    from fastapi import FastAPI, HTTPException, Request, status
    from fastapi.responses import JSONResponse
    _DEPS_AVAILABLE = True
except ImportError:
    _DEPS_AVAILABLE = False
    logger.warning(
        "FastAPI 或 Stripe SDK 未安装，Stripe webhook 监听器不可用。"
        "请运行：uv pip install 'payswitch[stripe]' 或 pip install stripe fastapi uvicorn"
    )


def create_webhook_app(
    ledger_db_path: Path | None = None,
    webhook_secret: str | None = None,
) -> Any:  # Returns FastAPI app if available, else None
    """创建 FastAPI webhook 监听器应用。

    Args:
        ledger_db_path: Pay-Switch 账本数据库路径，默认 ~/.payswitch/payswitch.db
        webhook_secret: Stripe Webhook Signing Secret（whsec_...），用于验证签名

    Returns:
        FastAPI app 实例（若依赖未安装则返回 None）
    """
    if not _DEPS_AVAILABLE:
        logger.error("FastAPI 或 Stripe SDK 未安装，无法创建 webhook 监听器")
        return None

    # 初始化 FastAPI app
    app = FastAPI(
        title="Pay-Switch Stripe Webhook",
        description="接收 Stripe webhook 事件并更新交易状态",
        version="1.0.0",
    )

    # 从环境变量或参数读取 webhook secret
    if webhook_secret is None:
        webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET", "")

    if not webhook_secret:
        # 尝试从 PaySwitch 配置读取
        from payswitch.models.config import PaySwitchConfig
        config = PaySwitchConfig.load()
        webhook_secret = config.get_stripe_webhook_secret()

    if not webhook_secret:
        logger.warning(
            "Stripe Webhook Secret 未配置。Webhook 签名验证将被跳过（不安全）。"
            "请设置环境变量 STRIPE_WEBHOOK_SECRET 或运行 payswitch settings stripe 配置。"
        )

    # 初始化 Ledger（从数据库加载）
    if ledger_db_path is None:
        from payswitch.models.config import PaySwitchConfig
        config = PaySwitchConfig.load()
        ledger_db_path = config.data_dir / "payswitch.db"

    from payswitch.engine.ledger import Ledger
    ledger = Ledger(db_path=ledger_db_path)
    logger.info("Stripe webhook 监听器已初始化，账本路径：%s", ledger_db_path)

    @app.get("/health")
    async def health_check() -> dict:
        """健康检查端点。"""
        return {
            "status": "ok",
            "service": "payswitch-stripe-webhook",
            "timestamp": datetime.now(UTC).isoformat(),
        }

    @app.post("/webhook")
    async def stripe_webhook_handler(request: Request) -> JSONResponse:
        """Stripe webhook 事件处理端点。

        接收 Stripe 发送的 POST 请求，验证签名后根据事件类型更新交易状态。

        Returns:
            200 OK: 事件处理成功
            400 Bad Request: 签名验证失败或事件格式错误
            404 Not Found: 交易 ID 不存在
            500 Internal Server Error: 处理异常
        """
        # 读取原始请求体（签名验证需要）
        payload = await request.body()
        sig_header = request.headers.get("Stripe-Signature")

        if not sig_header:
            logger.warning("收到无签名的 webhook 请求，拒绝处理")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Missing Stripe-Signature header"
            )

        # 验证签名并解析事件
        try:
            if webhook_secret:
                event = stripe.Webhook.construct_event(
                    payload=payload,
                    sig_header=sig_header,
                    secret=webhook_secret,
                )
            else:
                # 无 secret 配置时跳过验证（不安全，仅用于开发测试）
                import json
                event = json.loads(payload)
                logger.warning("Webhook secret 未配置，跳过签名验证（不安全）")

        except ValueError:
            # 无效的 payload 格式
            logger.error("Webhook payload 格式无效")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid payload"
            )
        except Exception as exc:
            # 签名验证失败或其他异常
            # 检查是否是 SignatureVerificationError（避免直接捕获可能不存在的类）
            if "SignatureVerificationError" in type(exc).__name__:
                logger.error("Webhook 签名验证失败")
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid signature"
                )
            # 其他未知异常
            logger.exception("Webhook 事件解析失败")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to parse webhook event: {exc}"
            )

        # 提取事件类型和数据
        event_type: str = event.get("type", "")
        event_data: dict = event.get("data", {}).get("object", {})
        event_id: str = event.get("id", "unknown")

        logger.info("收到 Stripe webhook 事件：type=%s, id=%s", event_type, event_id)

        # 从 metadata 提取 Pay-Switch 交易 ID
        metadata: dict = event_data.get("metadata", {})
        tx_id: str = metadata.get("payswitch_tx_id", "")

        if not tx_id:
            # 无关联交易 ID，可能是非 Pay-Switch 创建的 session
            logger.warning(
                "Webhook 事件 %s 无 Pay-Switch 交易 ID，忽略", event_id
            )
            return JSONResponse(
                status_code=status.HTTP_200_OK,
                content={"received": True, "note": "No payswitch_tx_id in metadata"}
            )

        # 查询交易是否存在
        tx = ledger.get(tx_id)
        if tx is None:
            logger.error("交易不存在：%s（来自 webhook 事件 %s）", tx_id, event_id)
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Transaction {tx_id} not found"
            )

        # 根据事件类型更新交易状态
        from payswitch.models.types import TransactionStatus
        now = datetime.now(UTC)

        try:
            if event_type == "checkout.session.completed":
                # 支付成功
                logger.info("交易 %s 支付成功（Stripe session completed）", tx_id)

                # 更新 HumanAction 完成时间（如果存在）
                updated_human_action = None
                if tx.human_action is not None and tx.human_action.completed_at is None:
                    updated_human_action = tx.human_action.model_copy(
                        update={"completed_at": now}
                    )

                ledger.update_status(
                    tx_id,
                    TransactionStatus.completed,
                    completed_at=now,
                    human_action=updated_human_action,
                    steps=tx.steps,
                )
                logger.info("交易 %s 状态已更新为 completed", tx_id)

            elif event_type == "checkout.session.expired":
                # 会话过期（24 小时内未支付）
                logger.info("交易 %s Stripe session 已过期", tx_id)
                ledger.update_status(
                    tx_id,
                    TransactionStatus.cancelled,
                    completed_at=now,
                    error="Stripe checkout session expired (24h timeout)",
                    steps=tx.steps,
                )
                logger.info("交易 %s 状态已更新为 cancelled", tx_id)

            elif event_type == "payment_intent.payment_failed":
                # 支付失败（如卡被拒等）
                logger.info("交易 %s 支付失败（payment_intent.payment_failed）", tx_id)
                failure_reason = (
                    event_data.get("last_payment_error", {}).get("message", "Unknown error")
                )
                ledger.update_status(
                    tx_id,
                    TransactionStatus.failed,
                    completed_at=now,
                    error=f"Stripe payment failed: {failure_reason}",
                    steps=tx.steps,
                )
                logger.info("交易 %s 状态已更新为 failed", tx_id)

            else:
                # 其他事件类型（如 payment_intent.succeeded 等）暂不处理
                logger.debug("忽略 Stripe 事件类型：%s", event_type)
                return JSONResponse(
                    status_code=status.HTTP_200_OK,
                    content={"received": True, "note": f"Event type {event_type} ignored"}
                )

        except Exception as exc:
            # 更新状态时发生异常
            logger.exception("处理 webhook 事件 %s 时发生异常", event_id)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to update transaction: {exc}"
            )

        # 返回成功响应
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "received": True,
                "event_id": event_id,
                "event_type": event_type,
                "tx_id": tx_id,
                "updated_status": tx.status if tx else None,
            }
        )

    return app


# 创建默认 app 实例（供 uvicorn 直接运行）
app = create_webhook_app()
