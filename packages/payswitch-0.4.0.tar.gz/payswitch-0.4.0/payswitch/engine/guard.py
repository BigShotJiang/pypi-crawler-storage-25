"""Pay-Switch 支付安全守卫模块。

在每次 spend 请求落地前执行一组有序的安全检查，守卫模块本身
是纯同步、无副作用的——它只读取配置和账本数据，不产生任何写操作。

检查顺序（短路语义，遇到第一个拒绝即停止）：
  1. 幂等去重   —— 同一 idempotency_key 在 48 小时内已存在 → 直接返回原交易
  2. 单笔限额   —— amount 超过 max_per_transaction 时拒绝
  3. 日累计限额 —— 今日已消费 + amount 超过 daily_limit 时拒绝
  4. 商户白名单 —— whitelist 非空且 payee 不在列表中时拒绝
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pydantic import BaseModel

# 运行时需要 Transaction 类来让 Pydantic 解析 GuardResult
from payswitch.models.transaction import Transaction  # noqa: F401

if TYPE_CHECKING:
    from payswitch.engine.ledger import Ledger
    from payswitch.models.config import PaySwitchConfig

logger = logging.getLogger(__name__)


class GuardResult(BaseModel):
    """安全检查结果。

    allowed=True  表示本次支付请求通过所有安全检查，可以继续执行。
    allowed=False 表示被某项检查拦截，reason 字段包含中文拒绝原因。

    幂等命中属于特殊的"通过"情形：allowed=True，existing_tx 非 None，
    调用方应直接返回已有交易而非重新发起支付。
    """

    # 是否允许本次支付（幂等命中也视为允许）
    allowed: bool
    # 拒绝原因（中文），仅 allowed=False 时有值
    reason: str | None = None
    # 幂等命中时返回已存在的交易，否则为 None
    existing_tx: Transaction | None = None

    model_config = {"arbitrary_types_allowed": True}


class SpendingGuard:
    """支付安全守卫，每次 spend 前调用 check() 执行全量检查。

    设计原则：
    - 无副作用：只读取 ledger/config，不写入任何数据
    - 短路求值：遇到第一个拦截条件立即返回，不继续后续检查
    - 中文报错：所有拒绝原因使用中文，且包含具体数值，方便用户理解
    """

    def __init__(self, config: PaySwitchConfig, ledger: Ledger) -> None:
        """初始化守卫，注入配置和账本依赖。

        Args:
            config: Pay-Switch 全局配置，包含所有限额和白名单设置
            ledger: 交易账本，用于查询历史数据（日总额、幂等记录）
        """
        self._config = config
        self._ledger = ledger

    # ------------------------------------------------------------------
    # 公开入口
    # ------------------------------------------------------------------

    def check(
        self,
        amount: float,
        payee: str,
        idempotency_key: str | None = None,
    ) -> GuardResult:
        """执行所有安全检查，返回统一的 GuardResult。

        检查顺序：幂等 → 单笔限额 → 日限额 → 白名单。
        遇到第一个拒绝条件即短路返回，不继续后续检查。

        Args:
            amount: 本次支付金额（元，必须 > 0）
            payee: 收款方平台标识（如 deepseek / kimi）
            idempotency_key: 调用方提供的幂等键，None 表示不做幂等检查

        Returns:
            GuardResult 实例，allowed 字段指示是否放行
        """
        # ---- 第一步：幂等检查 ----
        existing = self._check_idempotency(idempotency_key)
        if existing is not None:
            # 幂等命中：直接返回原交易，不再执行后续检查
            logger.info(
                "幂等命中，复用已有交易 %s（key=%s）",
                existing.tx_id,
                idempotency_key,
            )
            return GuardResult(allowed=True, existing_tx=existing)

        # ---- 第二步：单笔限额检查 ----
        deny_reason = self._check_per_transaction_limit(amount)
        if deny_reason is not None:
            logger.warning("单笔限额拦截：%s", deny_reason)
            return GuardResult(allowed=False, reason=deny_reason)

        # ---- 第三步：日累计限额检查 ----
        deny_reason = self._check_daily_limit(amount)
        if deny_reason is not None:
            logger.warning("日限额拦截：%s", deny_reason)
            return GuardResult(allowed=False, reason=deny_reason)

        # ---- 第四步：商户白名单检查 ----
        deny_reason = self._check_whitelist(payee)
        if deny_reason is not None:
            logger.warning("白名单拦截：%s", deny_reason)
            return GuardResult(allowed=False, reason=deny_reason)

        # 全部检查通过
        logger.debug(
            "安全检查通过：payee=%s，amount=%.2f，key=%s",
            payee,
            amount,
            idempotency_key,
        )
        return GuardResult(allowed=True)

    # ------------------------------------------------------------------
    # 私有检查方法（每个方法只负责一项规则）
    # ------------------------------------------------------------------

    def _check_per_transaction_limit(self, amount: float) -> str | None:
        """单笔限额检查。

        当 max_per_transaction > 0 且 amount 超出限额时拒绝。
        配置值为 0 表示不限制，直接通过。

        Args:
            amount: 本次支付金额（元）

        Returns:
            拒绝原因字符串（中文），通过时返回 None
        """
        limit = self._config.max_per_transaction
        # 0 表示不限制，跳过检查
        if limit <= 0:
            return None

        if amount > limit:
            return (
                f"单笔限额 ¥{limit:.2f}，本次支付 ¥{amount:.2f}，"
                f"超出 ¥{amount - limit:.2f}，请调低金额或提高限额后重试"
            )
        return None

    def _check_daily_limit(self, amount: float) -> str | None:
        """日累计限额检查。

        当 daily_limit > 0 且今日已消费总额 + 本次金额超出限额时拒绝。
        配置值为 0 表示不限制，直接通过。
        仅统计 completed 状态的交易（与 ledger.get_daily_total 一致）。

        Args:
            amount: 本次支付金额（元）

        Returns:
            拒绝原因字符串（中文），通过时返回 None
        """
        limit = self._config.daily_limit
        # 0 表示不限制，跳过检查
        if limit <= 0:
            return None

        daily_total = self._ledger.get_daily_total()
        projected_total = daily_total + amount

        if projected_total > limit:
            remaining = max(limit - daily_total, 0.0)
            return (
                f"日累计限额 ¥{limit:.2f}，今日已消费 ¥{daily_total:.2f}，"
                f"本次支付 ¥{amount:.2f}，预计超出 ¥{projected_total - limit:.2f}，"
                f"今日剩余可用额度 ¥{remaining:.2f}"
            )
        return None

    def _check_whitelist(self, payee: str) -> str | None:
        """商户白名单检查。

        当 whitelist 非空时，payee 必须在白名单中；
        whitelist 为空列表表示不限制任何商户，直接通过。

        Args:
            payee: 收款方平台标识（如 deepseek / kimi）

        Returns:
            拒绝原因字符串（中文），通过时返回 None
        """
        whitelist = self._config.whitelist
        # 白名单为空表示不限制
        if not whitelist:
            return None

        if payee not in whitelist:
            allowed_list = "、".join(whitelist)
            return (
                f"收款方 '{payee}' 不在商户白名单中，"
                f"当前白名单：{allowed_list}"
            )
        return None

    def _check_idempotency(self, key: str | None) -> Transaction | None:
        """幂等去重检查。

        若 key 为 None 则跳过检查（调用方未提供幂等键）。
        否则查询账本，返回 48 小时内已存在的同 key 交易；
        若不存在则返回 None，表示本次为新请求。

        Args:
            key: 幂等键，None 表示不检查

        Returns:
            已存在的 Transaction（幂等命中），或 None（未命中）
        """
        if key is None:
            return None

        return self._ledger.check_idempotency(key)
