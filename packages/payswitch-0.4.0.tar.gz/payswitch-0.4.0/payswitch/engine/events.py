"""Runtime event bridge for the frontend control plane."""

from __future__ import annotations

import json
import re
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from payswitch.models.config import PaySwitchConfig
from payswitch.security.redaction import redact_sensitive_data

_SAFE_SESSION_RE = re.compile(r"[^A-Za-z0-9_.-]+")


def safe_session_id(session_id: str) -> str:
    """Return a filesystem-safe session identifier."""
    sanitized = _SAFE_SESSION_RE.sub("_", session_id.strip())
    return sanitized or "unknown"


class RuntimeEventSink:
    """Append-only event sink consumed by the UI SSE endpoint.

    The sink deliberately writes JSONL files instead of requiring a resident
    web server in the checkout path. CLI, MCP, and test harnesses can emit the
    same events, while ``payswitch ui-events`` tails them for the frontend.
    """

    def __init__(self, config: PaySwitchConfig) -> None:
        self._events_dir = config.data_dir / "events"

    def event_log_path(self, session_id: str) -> Path:
        return self._events_dir / f"{safe_session_id(session_id)}.jsonl"

    def emit(
        self,
        session_id: str,
        event_type: str,
        summary: str,
        message: str = "",
        *,
        source: str = "pay_switch",
        path: list[str] | str | None = None,
        risk: str | None = None,
        target: str | None = None,
        **extra: Any,
    ) -> dict[str, Any]:
        """Append one redacted event and return the emitted payload."""
        now = datetime.now(UTC)
        payload: dict[str, Any] = {
            "id": f"evt_{uuid.uuid4().hex}",
            "session_id": session_id,
            "ts": now.isoformat(),
            "type": event_type,
            "summary": summary,
            "message": message,
            "source": source,
            "path": path or ["Codex", "Pay-Switch"],
        }
        if risk:
            payload["risk"] = risk
        if target:
            payload["target"] = target
        payload.update(extra)

        redacted = redact_sensitive_data(payload)
        self._events_dir.mkdir(parents=True, exist_ok=True)
        with self.event_log_path(session_id).open("a", encoding="utf-8") as file:
            file.write(json.dumps(redacted, ensure_ascii=False, default=str))
            file.write("\n")
        return redacted
