"""User workspace and subagent session orchestration."""

from __future__ import annotations

import asyncio
import hashlib
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from payswitch.agent_language import PaymentIntent
from payswitch.display_route_registry import DisplayRouteRecord, DisplayRouteRegistry
from payswitch.profile_manager import (
    ProfileBinding,
    ProfileVaultManager,
    resolve_profile_schema_version,
)
from payswitch.workspace_runtime import RuntimePolicy, WorkspaceRuntime, WorkspaceRuntimeFactory


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stable_id(prefix: str, raw: str) -> str:
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"{prefix}_{digest[:16]}"


def _metadata_text(metadata: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = metadata.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def _runtime_overlay(runtime: dict[str, Any] | None) -> dict[str, Any]:
    current = runtime or {}
    return {
        "runtime_id": current.get("runtime_id"),
        "runtime_backend": current.get("runtime_backend"),
        "runtime_status": current.get("runtime_status", "offline"),
        "display_state": current.get("display_state", "no_runtime"),
        "display_ready": current.get("display_ready", False),
        "display_reason": current.get("display_reason", "no_live_runtime"),
        "display_surface_id": current.get("display_surface_id"),
        "display_owner_task_id": current.get("display_owner_task_id"),
        "display_route_token": current.get("display_route_token"),
        "display_selected_at": current.get("display_selected_at"),
        "display_route_id": current.get("display_route_id"),
        "display_route_expires_at": current.get("display_route_expires_at"),
        "novnc_route_key": current.get("novnc_route_key"),
        "browser_manager_state": current.get("browser_manager_state"),
        "active_browser_context_id": current.get("active_browser_context_id"),
        "active_browser_tab_id": current.get("active_browser_tab_id"),
        "active_browser_window_id": current.get("active_browser_window_id"),
        "active_browser_task_id": current.get("active_browser_task_id"),
        "display_focus_lock_id": current.get("display_focus_lock_id"),
        "display_focus_lock_task_id": current.get("display_focus_lock_task_id"),
        "display_focus_lock_action": current.get("display_focus_lock_action"),
        "display_focus_lock_acquired_at": current.get("display_focus_lock_acquired_at"),
        "display_focus_z_order_token": current.get("display_focus_z_order_token"),
        "display_focus_foreground_lease_id": current.get("display_focus_foreground_lease_id"),
        "browser_selection_reason": current.get("browser_selection_reason"),
        "browser_selected_at": current.get("browser_selected_at"),
    }


@dataclass(frozen=True)
class TaskIdentity:
    user_id: str
    site_id: str
    workspace_id: str
    subagent_session_id: str
    site_lock_id: str
    profile_id: str
    browser_context_id: str


@dataclass
class UserWorkspace:
    workspace_id: str
    user_id: str
    status: str
    created_at: str
    updated_at: str
    active_sessions: set[str]
    runtime_id: str | None = None


@dataclass
class SubagentSession:
    task_id: str
    session_id: str
    user_id: str
    site_id: str
    workspace_id: str
    profile_id: str
    browser_context_id: str
    site_lock_id: str
    status: str
    created_at: str
    updated_at: str
    queued_reason: str | None = None
    foreground_lease_id: str | None = None
    workspace_capacity_acquired: bool = False
    runtime_id: str | None = None


class SubagentLease:
    def __init__(self, manager: AgentWorkspaceManager, session: SubagentSession) -> None:
        self._manager = manager
        self._session = session
        self.released = False

    @property
    def user_id(self) -> str:
        return self._session.user_id

    @property
    def workspace_id(self) -> str:
        return self._session.workspace_id

    @property
    def site_lock_id(self) -> str:
        return self._session.site_lock_id

    @property
    def status(self) -> str:
        return self._session.status

    async def release(self, *, final_status: str = "completed") -> None:
        if self.released:
            return
        self.released = True
        await self._manager.release_session(self._session.task_id, final_status=final_status)


class ForegroundLease:
    def __init__(
        self,
        manager: AgentWorkspaceManager,
        *,
        lease_id: str,
        task_id: str,
        workspace_id: str,
        reason: str,
    ) -> None:
        self._manager = manager
        self.lease_id = lease_id
        self.task_id = task_id
        self.workspace_id = workspace_id
        self.reason = reason
        self.released = False

    async def release(self) -> None:
        if self.released:
            return
        self.released = True
        await self._manager.release_foreground(self.task_id, lease_id=self.lease_id)


def resolve_task_identity(intent: PaymentIntent, *, task_id: str | None = None) -> TaskIdentity:
    metadata = intent.metadata or {}
    user_id = (
        _metadata_text(
            metadata,
            "user_id",
            "userId",
            "owner_id",
            "ownerId",
            "account_id",
            "accountId",
        )
        or intent.source_agent.strip()
        or "anonymous"
    )
    site_id = (
        _metadata_text(metadata, "site_id", "siteId", "provider", "payee")
        or intent.payee.strip()
        or "unknown"
    ).lower()
    profile_id = (_metadata_text(metadata, "profile_id", "profileId") or site_id).lower()
    session_seed = task_id or _metadata_text(metadata, "session_id", "sessionId") or "pending"
    workspace_id = _stable_id("uws", user_id)
    return TaskIdentity(
        user_id=user_id,
        site_id=site_id,
        workspace_id=workspace_id,
        subagent_session_id=_stable_id("sag", f"{session_seed}:{user_id}:{site_id}"),
        site_lock_id=_stable_id("slk", f"{user_id}:{profile_id}:{site_id}"),
        profile_id=profile_id,
        browser_context_id=_stable_id("bctx", f"{session_seed}:{user_id}:{profile_id}:{site_id}"),
    )


class AgentWorkspaceManager:
    """Concurrency gate plus runtime registry for user workspaces."""

    def __init__(
        self,
        *,
        max_active_sessions_per_workspace: int | None = None,
        max_active_workspaces: int | None = None,
        max_warm_workspaces: int | None = None,
        runtime_idle_seconds: float = 300.0,
        runtime_memory_mb: int = 256,
        max_host_memory_mb: int | None = None,
        profile_manager: ProfileVaultManager | None = None,
        profile_binding_provider: Callable[[], ProfileBinding] | None = None,
        runtime_factory: WorkspaceRuntimeFactory | None = None,
        display_route_ttl_seconds: float = 300.0,
    ) -> None:
        if (
            max_active_sessions_per_workspace is not None
            and max_active_sessions_per_workspace < 1
        ):
            raise ValueError("max_active_sessions_per_workspace must be at least 1")
        if max_active_workspaces is not None and max_active_workspaces < 1:
            raise ValueError("max_active_workspaces must be at least 1")
        if max_warm_workspaces is not None and max_warm_workspaces < 0:
            raise ValueError("max_warm_workspaces must be at least 0")
        if max_host_memory_mb is not None and max_host_memory_mb < 1:
            raise ValueError("max_host_memory_mb must be at least 1")
        self._guard = asyncio.Lock()
        self._admission = asyncio.Condition(self._guard)
        self._runtime_policy = RuntimePolicy(
            runtime_idle_seconds=runtime_idle_seconds,
            runtime_memory_mb=runtime_memory_mb,
        )
        self._runtime_factory = runtime_factory or WorkspaceRuntimeFactory()
        self._display_routes = DisplayRouteRegistry(ttl_seconds=display_route_ttl_seconds)
        self._profile_manager = profile_manager or ProfileVaultManager()
        self._profile_binding_provider = profile_binding_provider or self._default_profile_binding
        self._max_active_sessions_per_workspace = max_active_sessions_per_workspace
        self._max_active_workspaces = max_active_workspaces
        self._max_warm_workspaces = max_warm_workspaces
        self._max_host_memory_mb = max_host_memory_mb
        self._workspace_capacity: dict[str, asyncio.Semaphore] = {}
        self._workspace_foreground_locks: dict[str, asyncio.Lock] = {}
        self._site_locks: dict[str, asyncio.Lock] = {}
        self._workspaces: dict[str, UserWorkspace] = {}
        self._sessions: dict[str, SubagentSession] = {}
        self._runtimes: dict[str, WorkspaceRuntime] = {}
        self._runtime_sleep_tasks: dict[str, asyncio.Task[None]] = {}
        self._admission_waiters: set[str] = set()

    @staticmethod
    def _default_profile_binding() -> ProfileBinding:
        browser_engine = "playwright"
        return ProfileBinding(
            browser_engine=browser_engine,
            schema_version=resolve_profile_schema_version(browser_engine),
        )

    def _profile_binding(self) -> ProfileBinding:
        current = self._profile_binding_provider()
        if isinstance(current, ProfileBinding):
            if current.schema_version.strip():
                return current
            return ProfileBinding(
                browser_engine=current.browser_engine,
                schema_version=resolve_profile_schema_version(current.browser_engine),
            )
        browser_engine = str(getattr(current, "browser_engine", "") or "playwright")
        schema_version = str(
            getattr(current, "schema_version", "")
            or resolve_profile_schema_version(browser_engine)
        )
        return ProfileBinding(browser_engine=browser_engine, schema_version=schema_version)

    @property
    def runtime_backend(self) -> str:
        return self._runtime_factory.backend

    @property
    def container_driver_kind(self) -> str | None:
        if self._runtime_factory.backend != "container":
            return None
        return self._runtime_factory.container_driver.driver_kind

    @property
    def display_route_ttl_seconds(self) -> float:
        return self._display_routes.ttl_seconds

    async def start_session(self, task_id: str, intent: PaymentIntent) -> SubagentLease:
        identity = resolve_task_identity(intent, task_id=task_id)
        now = _now()
        session = SubagentSession(
            task_id=task_id,
            session_id=identity.subagent_session_id,
            user_id=identity.user_id,
            site_id=identity.site_id,
            workspace_id=identity.workspace_id,
            profile_id=identity.profile_id,
            browser_context_id=identity.browser_context_id,
            site_lock_id=identity.site_lock_id,
            status="queued",
            created_at=now,
            updated_at=now,
            queued_reason="workspace_admission",
        )
        runtime: WorkspaceRuntime | None = None
        async with self._admission:
            workspace = self._workspaces.get(identity.workspace_id)
            if workspace is None:
                workspace = UserWorkspace(
                    workspace_id=identity.workspace_id,
                    user_id=identity.user_id,
                    status="queued",
                    created_at=now,
                    updated_at=now,
                    active_sessions=set(),
                )
                self._workspaces[identity.workspace_id] = workspace
            self._sessions[task_id] = session
            self._site_locks.setdefault(identity.site_lock_id, asyncio.Lock())
            self._workspace_foreground_locks.setdefault(identity.workspace_id, asyncio.Lock())
            if self._max_active_sessions_per_workspace is not None:
                self._workspace_capacity.setdefault(
                    identity.workspace_id,
                    asyncio.Semaphore(self._max_active_sessions_per_workspace),
                )
                session.queued_reason = "workspace_capacity"
                session.updated_at = _now()
            while True:
                current = self._sessions.get(task_id)
                if current is None or current.status in {"cancelled", "deleted"}:
                    raise RuntimeError(
                        f"subagent session {task_id} was {current.status if current else 'deleted'}"
                    )
                runtime = self._runtimes.get(identity.workspace_id)
                self._reclaim_warm_runtimes_locked(exclude_workspace_id=identity.workspace_id)
                if self._can_activate_runtime_locked(runtime):
                    try:
                        runtime = self._activate_runtime_locked(identity)
                    except Exception:
                        session.status = "failed"
                        session.queued_reason = "workspace_runtime_failed"
                        session.updated_at = _now()
                        workspace.status = "failed"
                        workspace.updated_at = session.updated_at
                        self._admission.notify_all()
                        raise
                    session.runtime_id = runtime.runtime_id
                    workspace.runtime_id = runtime.runtime_id
                    workspace.status = runtime.status
                    workspace.updated_at = _now()
                    session.queued_reason = (
                        "workspace_capacity"
                        if self._max_active_sessions_per_workspace is not None
                        else "site_lock"
                    )
                    session.updated_at = _now()
                    break
                self._admission_waiters.add(task_id)
                session.queued_reason = "workspace_admission"
                session.updated_at = _now()
                await self._admission.wait()
                self._admission_waiters.discard(task_id)

        capacity = self._workspace_capacity.get(identity.workspace_id)
        lock = self._site_locks[identity.site_lock_id]
        try:
            if capacity is not None:
                await capacity.acquire()
                async with self._admission:
                    current = self._sessions.get(task_id)
                    if current is None or current.status in {"cancelled", "deleted"}:
                        capacity.release()
                        raise RuntimeError(
                            f"subagent session {task_id} was "
                            f"{current.status if current else 'deleted'}"
                        )
                    current.workspace_capacity_acquired = True
                    current.queued_reason = "site_lock"
                    current.updated_at = _now()
            await lock.acquire()
        except BaseException:
            async with self._admission:
                current = self._sessions.get(task_id)
                if current is not None:
                    current.status = "cancelled" if current.status != "deleted" else current.status
                    current.updated_at = _now()
                self._demote_runtime_if_idle_locked(identity.workspace_id)
                self._admission.notify_all()
            raise

        try:
            await self._profile_manager.prepare_task_profile(
                user_id=identity.user_id,
                site_id=identity.site_id,
                profile_id=identity.profile_id,
                task_id=task_id,
                binding=self._profile_binding(),
            )
        except BaseException:
            release_capacity = False
            async with self._admission:
                current = self._sessions.get(task_id)
                if current is not None:
                    current.status = "failed" if current.status != "deleted" else current.status
                    current.queued_reason = "profile_prepare_failed"
                    current.updated_at = _now()
                    release_capacity = current.workspace_capacity_acquired
                    current.workspace_capacity_acquired = False
                self._demote_runtime_if_idle_locked(identity.workspace_id)
                self._admission.notify_all()
            if lock.locked():
                lock.release()
            if release_capacity and capacity is not None:
                capacity.release()
            raise

        async with self._admission:
            current = self._sessions.get(task_id)
            if current is None or current.status in {"cancelled", "deleted"}:
                lock.release()
                if (
                    capacity is not None
                    and current is not None
                    and current.workspace_capacity_acquired
                ):
                    current.workspace_capacity_acquired = False
                    capacity.release()
                raise RuntimeError(
                    f"subagent session {task_id} was {current.status if current else 'deleted'}"
                )
            current.status = "running"
            current.queued_reason = None
            current.updated_at = _now()
            runtime = self._runtimes[identity.workspace_id]
            self._cancel_sleep_task_locked(identity.workspace_id)
            runtime.attach_session(task_id, current.browser_context_id)
            current.runtime_id = runtime.runtime_id
            workspace = self._workspaces[identity.workspace_id]
            workspace.active_sessions.add(task_id)
            workspace.runtime_id = runtime.runtime_id
            workspace.status = runtime.status
            workspace.updated_at = runtime.updated_at
            self._sessions[task_id] = current
            self._admission.notify_all()
            session = current
        return SubagentLease(self, session)

    async def promote_task_profile(self, task_id: str) -> dict[str, Any]:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                raise KeyError(f"subagent session not found: {task_id}")
        snapshot = await self._profile_manager.promote_task_profile(
            user_id=session.user_id,
            site_id=session.site_id,
            profile_id=session.profile_id,
            task_id=task_id,
            binding=self._profile_binding(),
        )
        async with self._guard:
            refreshed = self._sessions.get(task_id)
            if refreshed is not None:
                refreshed.updated_at = _now()
        return snapshot

    async def discard_task_profile(self, task_id: str, *, reason: str) -> dict[str, Any]:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                raise KeyError(f"subagent session not found: {task_id}")
        snapshot = await self._profile_manager.discard_task_profile(
            user_id=session.user_id,
            site_id=session.site_id,
            profile_id=session.profile_id,
            task_id=task_id,
            binding=self._profile_binding(),
            reason=reason,
        )
        async with self._guard:
            refreshed = self._sessions.get(task_id)
            if refreshed is not None:
                refreshed.updated_at = _now()
        return snapshot

    async def describe_profile_session(self, task_id: str) -> dict[str, Any] | None:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                return None
        return await self._profile_manager.describe_profile(
            user_id=session.user_id,
            site_id=session.site_id,
            profile_id=session.profile_id,
            task_id=task_id,
            binding=self._profile_binding(),
        )

    async def release_session(self, task_id: str, *, final_status: str = "completed") -> None:
        lock: asyncio.Lock | None = None
        capacity: asyncio.Semaphore | None = None
        foreground_lock: asyncio.Lock | None = None
        async with self._admission:
            session = self._sessions.get(task_id)
            if session is None:
                return
            was_running = session.status == "running"
            had_capacity = session.workspace_capacity_acquired
            session.status = final_status
            session.updated_at = _now()
            if session.foreground_lease_id:
                foreground_lock = self._workspace_foreground_locks.get(session.workspace_id)
                session.foreground_lease_id = None
            workspace = self._workspaces.get(session.workspace_id)
            if workspace is not None:
                workspace.active_sessions.discard(task_id)
                workspace.updated_at = session.updated_at
            runtime = self._runtimes.get(session.workspace_id)
            if runtime is not None:
                runtime.detach_session(task_id)
            self._display_routes.revoke_session(task_id)
            if was_running:
                lock = self._site_locks.get(session.site_lock_id)
            if had_capacity:
                session.workspace_capacity_acquired = False
                capacity = self._workspace_capacity.get(session.workspace_id)
            self._demote_runtime_if_idle_locked(session.workspace_id)
            self._admission.notify_all()
        if foreground_lock is not None and foreground_lock.locked():
            foreground_lock.release()
        if lock is not None and lock.locked():
            lock.release()
        if capacity is not None:
            capacity.release()

    async def acquire_foreground(self, task_id: str, *, reason: str) -> ForegroundLease:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                raise KeyError(f"subagent session not found: {task_id}")
            lock = self._workspace_foreground_locks.setdefault(session.workspace_id, asyncio.Lock())

        await lock.acquire()

        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None or session.status in {"cancelled", "deleted", "completed", "failed"}:
                lock.release()
                raise RuntimeError(f"subagent session {task_id} is not foregroundable")
            lease_id = _stable_id("fg", f"{task_id}:{session.workspace_id}:{reason}:{_now()}")
            session.foreground_lease_id = lease_id
            session.updated_at = _now()
            runtime = self._runtimes.get(session.workspace_id)
            if runtime is not None:
                runtime.assign_display_surface(
                    task_id,
                    state="human_gate_open",
                    ready=True,
                    reason=reason,
                    foreground_lease_id=lease_id,
                    browser_context_id=session.browser_context_id,
                )
                self._sync_display_route_locked(session, runtime)
            self._sessions[task_id] = session
            return ForegroundLease(
                self,
                lease_id=lease_id,
                task_id=task_id,
                workspace_id=session.workspace_id,
                reason=reason,
            )

    async def release_foreground(self, task_id: str, *, lease_id: str | None = None) -> None:
        lock: asyncio.Lock | None = None
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                return
            if lease_id is not None and session.foreground_lease_id != lease_id:
                return
            if session.foreground_lease_id is None:
                return
            session.foreground_lease_id = None
            session.updated_at = _now()
            runtime = self._runtimes.get(session.workspace_id)
            if runtime is not None and runtime.display_owner_task_id == task_id:
                if session.status in {"running", "working"}:
                    runtime.assign_display_surface(
                        task_id,
                        state="visible_surface_ready",
                        ready=True,
                        reason="foreground_released_runtime_still_visible",
                        browser_context_id=session.browser_context_id,
                    )
                    self._sync_display_route_locked(session, runtime)
                else:
                    runtime.clear_display_surface(
                        reason="foreground_released",
                        state=(
                            "pending_scoped_display_route"
                            if runtime.active_sessions
                            else "idle_no_scoped_display"
                        ),
                    )
                    self._display_routes.revoke_session(task_id)
            self._sessions[task_id] = session
            lock = self._workspace_foreground_locks.get(session.workspace_id)
        if lock is not None and lock.locked():
            lock.release()

    async def select_display_session(
        self,
        task_id: str,
        *,
        reason: str = "operator_select",
    ) -> dict[str, Any]:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                return {
                    "task_id": task_id,
                    "runtime_status": "offline",
                    "display_state": "no_runtime",
                    "display_ready": False,
                    "display_reason": "no_live_runtime",
                }
            runtime = self._runtimes.get(session.workspace_id)
            if runtime is None or runtime.status in {"destroyed"}:
                return {
                    **_runtime_overlay(None),
                    "task_id": task_id,
                    "foreground_lease_id": session.foreground_lease_id,
                }
            blocker = next(
                (
                    other
                    for other in self._sessions.values()
                    if other.workspace_id == session.workspace_id
                    and other.task_id != task_id
                    and other.foreground_lease_id
                ),
                None,
            )
            if blocker is not None:
                runtime.assign_display_surface(
                    blocker.task_id,
                    state="waiting_for_foreground",
                    ready=False,
                    reason=f"foreground_owned_by_{blocker.task_id}",
                    foreground_lease_id=blocker.foreground_lease_id,
                    browser_context_id=blocker.browser_context_id,
                )
                self._display_routes.revoke_workspace(session.workspace_id)
            elif session.status in {"completed", "failed", "deleted", "cancelled"}:
                runtime.assign_display_surface(
                    task_id,
                    state="visible_adapter_not_available",
                    ready=False,
                    reason="session_not_live",
                    browser_context_id=session.browser_context_id,
                )
                self._display_routes.revoke_workspace(session.workspace_id)
            else:
                target_state = (
                    "human_gate_open"
                    if session.status == "input-required"
                    else "visible_surface_ready"
                )
                runtime.assign_display_surface(
                    task_id,
                    state=target_state,
                    ready=True,
                    reason=reason,
                    foreground_lease_id=session.foreground_lease_id,
                    browser_context_id=session.browser_context_id,
                )
                self._sync_display_route_locked(session, runtime)
            return {
                **runtime.snapshot(),
                "task_id": task_id,
                "foreground_lease_id": session.foreground_lease_id,
                **self._display_route_overlay_locked(session.task_id),
            }

    async def verify_visible_action(self, task_id: str, *, action: str) -> dict[str, Any]:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                return {
                    "allowed": False,
                    "display_state": "no_runtime",
                    "display_reason": "no_live_runtime",
                    "action": action,
                }
            runtime = self._runtimes.get(session.workspace_id)
            if runtime is None or runtime.status not in {"starting", "active"}:
                return {
                    "allowed": False,
                    "display_state": "no_runtime",
                    "display_reason": "runtime_not_active",
                    "action": action,
                }
            blocker = next(
                (
                    other
                    for other in self._sessions.values()
                    if other.workspace_id == session.workspace_id
                    and other.task_id != task_id
                    and other.foreground_lease_id
                ),
                None,
            )
            if blocker is not None:
                return {
                    "allowed": False,
                    "display_state": "waiting_for_foreground",
                    "display_reason": f"foreground_owned_by_{blocker.task_id}",
                    "action": action,
                    "display_owner_task_id": blocker.task_id,
                }
            if runtime.display_owner_task_id != task_id:
                return {
                    "allowed": False,
                    "display_state": runtime.display_state,
                    "display_reason": "session_not_selected_for_display",
                    "action": action,
                    "display_owner_task_id": runtime.display_owner_task_id,
                }
            if not runtime.display_ready:
                return {
                    "allowed": False,
                    "display_state": runtime.display_state,
                    "display_reason": runtime.display_reason,
                    "action": action,
                }
            browser = runtime.verify_visible_action(
                task_id,
                browser_context_id=session.browser_context_id,
                action=action,
                foreground_lease_id=session.foreground_lease_id,
            )
            if not bool(browser.get("allowed")):
                return {
                    "allowed": False,
                    "display_state": runtime.display_state,
                    "display_reason": str(browser.get("reason") or runtime.display_reason),
                    "action": action,
                    **{
                        k: v
                        for k, v in browser.items()
                        if k not in {"allowed", "action", "reason"}
                    },
                }
            return {
                "allowed": True,
                "display_state": runtime.display_state,
                "display_reason": runtime.display_reason,
                "action": action,
                "display_route_token": runtime.display_route_token,
                **{k: v for k, v in browser.items() if k not in {"allowed", "action", "reason"}},
                **self._display_route_overlay_locked(task_id),
            }

    async def begin_visible_action(self, task_id: str, *, action: str) -> dict[str, Any]:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                return {
                    "allowed": False,
                    "display_state": "no_runtime",
                    "display_reason": "no_live_runtime",
                    "action": action,
                }
            runtime = self._runtimes.get(session.workspace_id)
            if runtime is None or runtime.status not in {"starting", "active"}:
                return {
                    "allowed": False,
                    "display_state": "no_runtime",
                    "display_reason": "runtime_not_active",
                    "action": action,
                }
            blocker = next(
                (
                    other
                    for other in self._sessions.values()
                    if other.workspace_id == session.workspace_id
                    and other.task_id != task_id
                    and other.foreground_lease_id
                ),
                None,
            )
            if blocker is not None:
                return {
                    "allowed": False,
                    "display_state": "waiting_for_foreground",
                    "display_reason": f"foreground_owned_by_{blocker.task_id}",
                    "action": action,
                    "display_owner_task_id": blocker.task_id,
                }
            if runtime.display_owner_task_id != task_id:
                return {
                    "allowed": False,
                    "display_state": runtime.display_state,
                    "display_reason": "session_not_selected_for_display",
                    "action": action,
                    "display_owner_task_id": runtime.display_owner_task_id,
                }
            if not runtime.display_ready:
                return {
                    "allowed": False,
                    "display_state": runtime.display_state,
                    "display_reason": runtime.display_reason,
                    "action": action,
                }
            browser = runtime.begin_visible_action(
                task_id,
                browser_context_id=session.browser_context_id,
                action=action,
                foreground_lease_id=session.foreground_lease_id,
            )
            if not bool(browser.get("allowed")):
                return {
                    "allowed": False,
                    "display_state": runtime.display_state,
                    "display_reason": str(browser.get("reason") or runtime.display_reason),
                    "action": action,
                    **{
                        k: v
                        for k, v in browser.items()
                        if k not in {"allowed", "action", "reason"}
                    },
                }
            return {
                "allowed": True,
                "display_state": runtime.display_state,
                "display_reason": runtime.display_reason,
                "action": action,
                "display_route_token": runtime.display_route_token,
                **{k: v for k, v in browser.items() if k not in {"allowed", "action", "reason"}},
                **self._display_route_overlay_locked(task_id),
            }

    async def finish_visible_action(
        self,
        task_id: str,
        *,
        focus_lock_id: str | None,
    ) -> None:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                return
            runtime = self._runtimes.get(session.workspace_id)
            if runtime is None:
                return
            runtime.end_visible_action(lock_id=focus_lock_id)

    async def get_session(self, task_id: str) -> SubagentSession | None:
        async with self._guard:
            return self._sessions.get(task_id)

    def _display_overlay_for_session_locked(
        self,
        session: SubagentSession,
        runtime: WorkspaceRuntime | None,
    ) -> dict[str, Any]:
        if runtime is None:
            return {
                **_runtime_overlay(None),
                "foreground_lease_id": session.foreground_lease_id,
                **self._display_route_overlay_locked(session.task_id),
            }
        snapshot = runtime.snapshot()
        owner_task_id = snapshot.get("display_owner_task_id")
        if owner_task_id == session.task_id:
            return {
                **_runtime_overlay(snapshot),
                "foreground_lease_id": session.foreground_lease_id,
                **self._display_route_overlay_locked(session.task_id),
            }
        if owner_task_id:
            return {
                "runtime_id": snapshot.get("runtime_id"),
                "runtime_backend": snapshot.get("runtime_backend"),
                "runtime_status": snapshot.get("runtime_status", "offline"),
                "display_state": "waiting_for_foreground",
                "display_ready": False,
                "display_reason": f"foreground_owned_by_{owner_task_id}",
                "display_surface_id": snapshot.get("display_surface_id"),
                "display_owner_task_id": owner_task_id,
                "display_route_token": None,
                "display_selected_at": snapshot.get("display_selected_at"),
                "foreground_lease_id": session.foreground_lease_id,
                "display_route_id": None,
                "display_route_expires_at": None,
                "novnc_route_key": snapshot.get("novnc_route_key"),
                "browser_manager_state": snapshot.get("browser_manager_state"),
                "active_browser_context_id": snapshot.get("active_browser_context_id"),
                "active_browser_tab_id": snapshot.get("active_browser_tab_id"),
                "active_browser_window_id": snapshot.get("active_browser_window_id"),
                "active_browser_task_id": snapshot.get("active_browser_task_id"),
                "display_focus_lock_id": snapshot.get("display_focus_lock_id"),
                "display_focus_lock_task_id": snapshot.get("display_focus_lock_task_id"),
                "display_focus_lock_action": snapshot.get("display_focus_lock_action"),
                "display_focus_lock_acquired_at": snapshot.get("display_focus_lock_acquired_at"),
                "display_focus_z_order_token": snapshot.get("display_focus_z_order_token"),
                "display_focus_foreground_lease_id": snapshot.get(
                    "display_focus_foreground_lease_id"
                ),
                "browser_selection_reason": snapshot.get("browser_selection_reason"),
                "browser_selected_at": snapshot.get("browser_selected_at"),
            }
        return {
            "runtime_id": snapshot.get("runtime_id"),
            "runtime_backend": snapshot.get("runtime_backend"),
            "runtime_status": snapshot.get("runtime_status", "offline"),
            "display_state": "pending_scoped_display_route",
            "display_ready": False,
            "display_reason": "operator_select_required",
            "display_surface_id": snapshot.get("display_surface_id"),
            "display_owner_task_id": None,
            "display_route_token": None,
            "display_selected_at": None,
            "foreground_lease_id": session.foreground_lease_id,
            "display_route_id": None,
            "display_route_expires_at": None,
            "novnc_route_key": snapshot.get("novnc_route_key"),
            "browser_manager_state": snapshot.get("browser_manager_state"),
            "active_browser_context_id": snapshot.get("active_browser_context_id"),
            "active_browser_tab_id": snapshot.get("active_browser_tab_id"),
            "active_browser_window_id": snapshot.get("active_browser_window_id"),
            "active_browser_task_id": snapshot.get("active_browser_task_id"),
            "display_focus_lock_id": snapshot.get("display_focus_lock_id"),
            "display_focus_lock_task_id": snapshot.get("display_focus_lock_task_id"),
            "display_focus_lock_action": snapshot.get("display_focus_lock_action"),
            "display_focus_lock_acquired_at": snapshot.get("display_focus_lock_acquired_at"),
            "display_focus_z_order_token": snapshot.get("display_focus_z_order_token"),
            "display_focus_foreground_lease_id": snapshot.get("display_focus_foreground_lease_id"),
            "browser_selection_reason": snapshot.get("browser_selection_reason"),
            "browser_selected_at": snapshot.get("browser_selected_at"),
        }

    async def describe_display_session(self, task_id: str) -> dict[str, Any] | None:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                return None
            runtime = self._runtimes.get(session.workspace_id)
            return {
                "task_id": session.task_id,
                "workspace_id": session.workspace_id,
                "user_id": session.user_id,
                **self._display_overlay_for_session_locked(session, runtime),
            }

    async def resolve_display_route(
        self,
        task_id: str,
        *,
        user_id: str,
        route_token: str,
    ) -> dict[str, Any] | None:
        async with self._guard:
            session = self._sessions.get(task_id)
            if session is None:
                return None
            route = self._display_routes.resolve(
                route_token=route_token,
                task_id=task_id,
                user_id=user_id,
                workspace_id=session.workspace_id,
            )
            if route is None:
                return None
            runtime = self._runtimes.get(session.workspace_id)
            if runtime is None:
                return None
            snapshot = runtime.snapshot()
            return {
                "task_id": session.task_id,
                "user_id": session.user_id,
                "workspace_id": session.workspace_id,
                "runtime_id": route.runtime_id,
                "display_surface_id": route.display_surface_id,
                "novnc_route_key": route.novnc_route_key,
                "display_route_id": route.route_id,
                "display_route_token": route.route_token,
                "display_route_expires_at": route.expires_at,
                "runtime_backend": snapshot.get("runtime_backend"),
            }

    async def list_sessions(self, *, user_id: str | None = None) -> list[dict[str, Any]]:
        async with self._guard:
            sessions = list(self._sessions.values())
            runtimes = dict(self._runtimes)
        if user_id:
            sessions = [session for session in sessions if session.user_id == user_id]
        rows = []
        for session in sessions:
            profile = await self._profile_manager.describe_profile(
                user_id=session.user_id,
                site_id=session.site_id,
                profile_id=session.profile_id,
                task_id=session.task_id,
                binding=self._profile_binding(),
            )
            rows.append(
                {
                    **self._display_overlay_for_session_locked(
                        session,
                        runtimes.get(session.workspace_id),
                    ),
                    **profile,
                    "task_id": session.task_id,
                    "session_id": session.session_id,
                    "user_id": session.user_id,
                    "site_id": session.site_id,
                    "workspace_id": session.workspace_id,
                    "profile_id": session.profile_id,
                    "browser_context_id": session.browser_context_id,
                    "site_lock_id": session.site_lock_id,
                    "runtime_id": session.runtime_id
                    or (
                        runtimes.get(session.workspace_id).runtime_id
                        if runtimes.get(session.workspace_id)
                        else None
                    ),
                    "status": session.status,
                    "queued_reason": session.queued_reason,
                    "created_at": session.created_at,
                    "updated_at": session.updated_at,
                }
            )
        return rows

    async def list_workspaces(self, *, user_id: str | None = None) -> list[dict[str, Any]]:
        async with self._guard:
            workspaces = list(self._workspaces.values())
            runtimes = {
                workspace_id: runtime.snapshot()
                for workspace_id, runtime in self._runtimes.items()
            }
        if user_id:
            workspaces = [workspace for workspace in workspaces if workspace.user_id == user_id]
        rows = []
        for workspace in workspaces:
            runtime = runtimes.get(workspace.workspace_id, {})
            profile_summary = await self._profile_manager.summarize_user_profiles(workspace.user_id)
            rows.append(
                {
                    "workspace_id": workspace.workspace_id,
                    "user_id": workspace.user_id,
                    "status": workspace.status,
                    "created_at": workspace.created_at,
                    "updated_at": workspace.updated_at,
                    "active_sessions": len(workspace.active_sessions),
                    "runtime_id": workspace.runtime_id or runtime.get("runtime_id"),
                    "runtime_backend": runtime.get("runtime_backend"),
                    "runtime_status": runtime.get("runtime_status", "offline"),
                    "display_state": runtime.get("display_state", "no_runtime"),
                    "display_ready": runtime.get("display_ready", False),
                    "display_surface_id": runtime.get("display_surface_id"),
                    "runtime_memory_mb": runtime.get("runtime_memory_mb", 0),
                    "runtime_memory_budget_mb": runtime.get(
                        "runtime_memory_budget_mb", self._runtime_policy.runtime_memory_mb
                    ),
                    "sleep_after_seconds": runtime.get(
                        "sleep_after_seconds", self._runtime_policy.runtime_idle_seconds
                    ),
                    "last_active_at": runtime.get("last_active_at"),
                    "last_sleep_at": runtime.get("last_sleep_at"),
                    "runtime_status_reason": runtime.get(
                        "runtime_status_reason", "no_live_runtime"
                    ),
                    **profile_summary,
                }
            )
        return rows

    async def runtime_health(self, *, user_id: str | None = None) -> dict[str, Any]:
        async with self._guard:
            snapshots = [runtime.snapshot() for runtime in self._runtimes.values()]
            if user_id:
                snapshots = [item for item in snapshots if item["user_id"] == user_id]
            active = self._active_runtime_count_locked()
            warm = self._count_runtime_status_locked("warm")
            sleeping = self._count_runtime_status_locked("sleeping")
            destroyed = self._count_runtime_status_locked("destroyed")
            memory = self._estimated_host_memory_locked()
            queued = len(self._admission_waiters)
        capacity_status = "ok"
        if self._max_active_workspaces is not None and active >= self._max_active_workspaces:
            capacity_status = "active_capacity_reached"
        if self._max_host_memory_mb is not None and memory >= self._max_host_memory_mb:
            capacity_status = "memory_capacity_reached"
        return {
            "host": {
                "max_active_workspaces": self._max_active_workspaces,
                "max_warm_workspaces": self._max_warm_workspaces,
                "max_host_memory_mb": self._max_host_memory_mb,
                "runtime_memory_budget_mb": self._runtime_policy.runtime_memory_mb,
                "runtime_idle_seconds": self._runtime_policy.runtime_idle_seconds,
                "active_workspaces": active,
                "warm_workspaces": warm,
                "sleeping_workspaces": sleeping,
                "destroyed_workspaces": destroyed,
                "queued_admissions": queued,
                "estimated_memory_mb": memory,
                "capacity_status": capacity_status,
            },
            "runtimes": snapshots,
        }

    async def reset(self) -> None:
        await self._profile_manager.reset()
        async with self._admission:
            for task in self._runtime_sleep_tasks.values():
                task.cancel()
            self._runtime_sleep_tasks.clear()
            for runtime in list(self._runtimes.values()):
                self._destroy_runtime_locked(runtime, reason="workspace_manager_reset")
            self._site_locks.clear()
            self._workspace_capacity.clear()
            self._workspace_foreground_locks.clear()
            self._workspaces.clear()
            self._sessions.clear()
            self._runtimes.clear()
            self._admission_waiters.clear()
            self._admission.notify_all()

    def _activate_runtime_locked(self, identity: TaskIdentity) -> WorkspaceRuntime:
        runtime = self._runtimes.get(identity.workspace_id)
        if runtime is None:
            runtime = self._runtime_factory.create_runtime(
                workspace_id=identity.workspace_id,
                user_id=identity.user_id,
                policy=self._runtime_policy,
            )
            self._runtimes[identity.workspace_id] = runtime
            runtime.wake()
        elif runtime.status not in {"starting", "active"}:
            runtime.wake()
        self._cancel_sleep_task_locked(identity.workspace_id)
        return runtime

    def _demote_runtime_if_idle_locked(self, workspace_id: str) -> None:
        runtime = self._runtimes.get(workspace_id)
        workspace = self._workspaces.get(workspace_id)
        if runtime is None or runtime.active_sessions:
            return
        runtime.mark_warm()
        self._display_routes.revoke_workspace(workspace_id)
        if workspace is not None:
            workspace.status = "warm"
            workspace.updated_at = runtime.updated_at
        self._schedule_sleep_task_locked(workspace_id)
        self._reclaim_warm_runtimes_locked()

    def _schedule_sleep_task_locked(self, workspace_id: str) -> None:
        self._cancel_sleep_task_locked(workspace_id)
        self._runtime_sleep_tasks[workspace_id] = asyncio.create_task(
            self._sleep_runtime_after_idle(workspace_id)
        )

    def _cancel_sleep_task_locked(self, workspace_id: str) -> None:
        task = self._runtime_sleep_tasks.pop(workspace_id, None)
        if task is not None:
            task.cancel()

    async def _sleep_runtime_after_idle(self, workspace_id: str) -> None:
        try:
            await asyncio.sleep(self._runtime_policy.runtime_idle_seconds)
        except asyncio.CancelledError:
            return
        async with self._admission:
            runtime = self._runtimes.get(workspace_id)
            workspace = self._workspaces.get(workspace_id)
            if runtime is None or runtime.active_sessions or runtime.status != "warm":
                return
            runtime.mark_sleeping()
            self._display_routes.revoke_workspace(workspace_id)
            if workspace is not None:
                workspace.status = runtime.status
                workspace.updated_at = runtime.updated_at
            self._admission.notify_all()

    def _active_runtime_count_locked(self) -> int:
        return sum(
            1
            for runtime in self._runtimes.values()
            if runtime.status in {"starting", "active"}
        )

    def _count_runtime_status_locked(self, status: str) -> int:
        return sum(1 for runtime in self._runtimes.values() if runtime.status == status)

    def _estimated_host_memory_locked(self) -> int:
        return sum(runtime.current_memory_mb() for runtime in self._runtimes.values())

    def _can_activate_runtime_locked(
        self, runtime: WorkspaceRuntime | None
    ) -> bool:
        active_delta = 0
        memory_delta = 0
        if runtime is None:
            active_delta = 1
            memory_delta = self._runtime_policy.runtime_memory_mb
        elif runtime.status not in {"starting", "active"}:
            active_delta = 1
            memory_delta = max(
                0, self._runtime_policy.runtime_memory_mb - runtime.current_memory_mb()
            )
        if (
            self._max_active_workspaces is not None
            and self._active_runtime_count_locked() + active_delta > self._max_active_workspaces
        ):
            return False
        if (
            self._max_host_memory_mb is not None
            and self._estimated_host_memory_locked() + memory_delta > self._max_host_memory_mb
        ):
            return False
        return True

    def _reclaim_warm_runtimes_locked(self, *, exclude_workspace_id: str | None = None) -> None:
        while True:
            too_many_warm = (
                self._max_warm_workspaces is not None
                and self._count_runtime_status_locked("warm") > self._max_warm_workspaces
            )
            memory_exceeded = (
                self._max_host_memory_mb is not None
                and self._estimated_host_memory_locked() > self._max_host_memory_mb
            )
            if not too_many_warm and not memory_exceeded:
                return
            candidates = sorted(
                (
                    runtime
                    for runtime in self._runtimes.values()
                    if runtime.status == "warm"
                    and runtime.workspace_id != exclude_workspace_id
                ),
                key=lambda item: item.updated_at,
            )
            if not candidates:
                return
            self._destroy_runtime_locked(candidates[0], reason="warm_runtime_reclaimed")

    def _destroy_runtime_locked(
        self, runtime: WorkspaceRuntime, *, reason: str
    ) -> None:
        self._cancel_sleep_task_locked(runtime.workspace_id)
        self._display_routes.revoke_workspace(runtime.workspace_id)
        runtime.mark_destroyed(reason=reason)
        workspace = self._workspaces.get(runtime.workspace_id)
        if workspace is not None:
            workspace.status = "destroyed"
            workspace.updated_at = runtime.updated_at

    def _display_route_overlay_locked(self, task_id: str) -> dict[str, Any]:
        route = self._display_routes.get_session_route(task_id)
        if route is None:
            return {
                "display_route_id": None,
                "display_route_expires_at": None,
            }
        return {
            "display_route_id": route.route_id,
            "display_route_expires_at": route.expires_at,
            "novnc_route_key": route.novnc_route_key,
        }

    def _sync_display_route_locked(
        self,
        session: SubagentSession,
        runtime: WorkspaceRuntime,
    ) -> DisplayRouteRecord | None:
        snapshot = runtime.snapshot()
        route_token = str(snapshot.get("display_route_token") or "")
        if not snapshot.get("display_ready") or not route_token:
            self._display_routes.revoke_session(session.task_id)
            return None
        return self._display_routes.register(
            route_token=route_token,
            task_id=session.task_id,
            user_id=session.user_id,
            workspace_id=session.workspace_id,
            runtime_id=str(snapshot.get("runtime_id") or runtime.runtime_id),
            display_surface_id=snapshot.get("display_surface_id"),
            novnc_route_key=snapshot.get("novnc_route_key"),
        )
