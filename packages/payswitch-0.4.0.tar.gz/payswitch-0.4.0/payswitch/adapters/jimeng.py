"""Jimeng AI payment adapter.

The adapter follows the same conservative boundary as the other browser
adapters: it may navigate and prepare checkout, but QR scan, password, OTP,
3DS, CAPTCHA, and final authorization remain human-gated.
"""

from __future__ import annotations

from typing import Any

from payswitch.adapters import AdapterRegistry
from payswitch.adapters.base import ScriptExecutionError, ScriptStep, SiteAdapter
from payswitch.experience import ExperienceRecipe
from payswitch.experience.registry import get_recipe
from payswitch.experience.runner import RecipeExecutionError, RecipeRunContext, RecipeRunner
from payswitch.experience.store import ExperienceStore
from payswitch.models.types import PaymentMethod, StepCategory, StepRisk

_TIMEOUT_MS = 15_000
_MIN_AMOUNT = 50.0


def _amount_text(amount: float) -> str:
    return str(int(amount)) if amount == int(amount) else str(amount)


@AdapterRegistry.register
class JimengAdapter(SiteAdapter):
    """Adapter for Jimeng AI image/video credit or membership payment."""

    name = "jimeng"
    display_name = "Jimeng AI"
    top_up_url = "https://jimeng.jianying.com/ai-tool/home"
    login_url = "https://jimeng.jianying.com/ai-tool/home"
    supported_methods = [PaymentMethod.alipay_qr, PaymentMethod.wechat_qr]
    allow_smart_fallback = False
    allow_detector_completion = False
    requires_payment_gate = True
    recipe_flow = "topup_alipay_qr"

    @property
    def recipe(self) -> ExperienceRecipe:
        recipe = get_recipe(self.name, self.recipe_flow, store=self.recipe_store)
        if recipe is None:
            raise RuntimeError("Jimeng experience recipe is not registered")
        return recipe

    async def validate_amount(self, amount: float) -> bool:
        return amount >= _MIN_AMOUNT

    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        if not await self.validate_amount(amount):
            raise ScriptExecutionError(f"jimeng amount must be >= {_MIN_AMOUNT:g}")

        steps: list[ScriptStep] = []
        recipe = self.recipe

        async def record_step(step: ScriptStep) -> None:
            await self._record_step(steps, step)

        runner = RecipeRunner(
            recipe=recipe,
            semantic_actions={
                "ensure_logged_in": self._recipe_ensure_logged_in,
                "enter_checkout": self._recipe_enter_checkout,
                "select_amount": self._recipe_select_amount,
                "select_payment_method": self._recipe_select_payment_method,
                "click_confirm": self._recipe_click_confirm,
                "wait_for_qr": self._recipe_wait_for_qr,
            },
            telemetry_callback=self.telemetry_callback,
            policy_checkpoint_callback=self._recipe_policy_checkpoint,
            evidence_dir=self.recipe_evidence_dir,
            artifact_store=self.recipe_artifact_store,
            screenshot_budget=self.recipe_screenshot_budget,
        )

        try:
            await runner.run(
                page=page,
                amount=amount,
                method=method,
                steps=steps,
                record_step=record_step,
            )
        except RecipeExecutionError as exc:
            store = self._experience_store()
            if store is not None:
                store.record_outcome(
                    platform=self.name,
                    flow=recipe.flow,
                    recipe_id=recipe.recipe_id,
                    recipe_version=recipe.version,
                    succeeded=False,
                    confidence=recipe.confidence,
                    details=exc.failure_context,
                )
            raise ScriptExecutionError(
                str(exc),
                failure_context=exc.failure_context,
            ) from exc

        store = self._experience_store()
        if store is not None:
            store.record_outcome(
                platform=self.name,
                flow=recipe.flow,
                recipe_id=recipe.recipe_id,
                recipe_version=recipe.version,
                succeeded=True,
                confidence=recipe.confidence,
                details={
                    "step_count": len(steps),
                    "current_url": str(getattr(page, "url", "")),
                },
            )

        return steps

    async def check_login_state(self, page: Any) -> tuple[bool, str | None]:
        current_url = str(getattr(page, "url", "")).lower()
        if any(signal in current_url for signal in ("login", "passport", "sso", "auth")):
            return False, (
                "Jimeng profile is not authenticated. Run "
                "'payswitch login jimeng' and complete login in the browser."
            )

        login_selectors = (
            "text=Log in",
            "text=Login",
            "text=Sign in",
            "text=\u767b\u5f55",
            "text=\u767b\u9304",
        )
        for selector in login_selectors:
            try:
                locator = page.locator(selector)
                if await locator.count() > 0 and await locator.first.is_visible():
                    return False, (
                        "Jimeng login prompt is visible. Run "
                        "'payswitch login jimeng' and complete login in the browser."
                    )
            except Exception:
                continue
        return True, None

    def _experience_store(self) -> ExperienceStore | None:
        store = getattr(self, "recipe_store", None)
        if isinstance(store, ExperienceStore):
            return store
        return None

    async def _recipe_ensure_logged_in(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)

    async def _recipe_enter_checkout(self, context: RecipeRunContext) -> None:
        await self._enter_checkout(context.page, context.steps)

    async def _recipe_select_amount(self, context: RecipeRunContext) -> None:
        await self._select_amount(context.page, context.amount, context.steps)

    async def _recipe_select_payment_method(self, context: RecipeRunContext) -> None:
        await self._select_payment_method(
            context.page,
            context.method or PaymentMethod.alipay_qr,
            context.steps,
        )

    async def _recipe_click_confirm(self, context: RecipeRunContext) -> None:
        await self._click_checkout(
            context.page,
            context.steps,
            context.method or PaymentMethod.alipay_qr,
        )

    async def _recipe_wait_for_qr(self, context: RecipeRunContext) -> None:
        await self._wait_for_human_payment_gate(context.page, context.steps)

    async def _recipe_policy_checkpoint(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)
        if context.waypoint.id != "confirm_topup_checkout":
            return

        visible_text = await self._visible_text_snapshot(context.page)
        required_markers = [
            *context.recipe.texts.get("checkout_ready", []),
            *context.recipe.texts.get("payment_surface", []),
            "去支付",
            "同意并支付",
        ]
        if any(marker in visible_text for marker in required_markers):
            return
        raise RuntimeError(
            "policy checkpoint blocked confirm_topup_checkout: "
            "missing visible Jimeng payment markers"
        )

    async def _navigate(self, page: Any, steps: list[ScriptStep]) -> None:
        steps.append(
            ScriptStep(
                description="Navigate to Jimeng AI",
                action="navigate",
                url=self.top_up_url,
            )
        )
        try:
            await page.goto(self.top_up_url, wait_until="domcontentloaded", timeout=_TIMEOUT_MS)
            try:
                await page.wait_for_load_state("networkidle", timeout=_TIMEOUT_MS)
            except Exception:
                pass
        except Exception as exc:
            raise ScriptExecutionError(f"failed to open Jimeng AI: {exc}") from exc

    async def _enter_checkout(self, page: Any, steps: list[ScriptStep]) -> None:
        if self._looks_like_checkout(page.url):
            return

        points_selectors = (
            "button:has-text('购买积分')",
            "text=购买积分",
            "button:has-text('积分')",
            "text=积分详情",
        )
        account_selectors = (
            "text=高级会员",
            "text=基础会员",
            "text=标准会员",
            "text=会员",
            "[class*='user']",
            "[class*='avatar']",
            "[class*='profile']",
        )

        for selector in points_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=1_500)
                if not element:
                    continue
                await element.click(timeout=_TIMEOUT_MS)
                steps.append(
                    ScriptStep(
                        description="Open Jimeng points purchase",
                        action="click",
                        selector=selector,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                return
            except Exception:
                continue

        for selector in account_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=1_500)
                if not element:
                    continue
                await element.click(timeout=_TIMEOUT_MS)
                steps.append(
                    ScriptStep(
                        description="Open Jimeng account billing surface",
                        action="click",
                        selector=selector,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                try:
                    await page.wait_for_timeout(800)
                except Exception:
                    pass
                for nested_selector in points_selectors:
                    try:
                        nested = await page.wait_for_selector(nested_selector, timeout=1_500)
                        if not nested:
                            continue
                        await nested.click(timeout=_TIMEOUT_MS)
                        steps.append(
                            ScriptStep(
                                description="Open Jimeng points purchase",
                                action="click",
                                selector=nested_selector,
                                category=StepCategory.checkout_prep,
                                risk=StepRisk.medium,
                            )
                        )
                        return
                    except Exception:
                        continue
            except Exception:
                continue

        selectors = (
            "a[href*='pay']",
            "a[href*='billing']",
            "a[href*='member']",
            "a[href*='vip']",
            "button:has-text('VIP')",
            "button:has-text('Pro')",
            "button:has-text('\u5145\u503c')",
            "button:has-text('\u4f1a\u5458')",
            "button:has-text('\u4ed8\u8d39')",
            "button:has-text('\u8d2d\u4e70')",
            "button:has-text('\u5347\u7ea7')",
            "button:has-text('\u5f00\u901a')",
            "[class*='recharge']",
            "[class*='member']",
            "[class*='vip']",
            "[class*='billing']",
        )
        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=2_000)
                if not element:
                    continue
                steps.append(
                    ScriptStep(
                        description="Enter Jimeng checkout or membership page",
                        action="click",
                        selector=selector,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                await element.click(timeout=_TIMEOUT_MS)
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=_TIMEOUT_MS)
                except Exception:
                    pass
                return
            except Exception:
                continue

        raise ScriptExecutionError(
            "Jimeng checkout entry was not found. The page may have changed; "
            "Computer Use fallback or human takeover is required."
        )

    def _looks_like_checkout(self, url: str) -> bool:
        lowered = str(url).lower()
        return any(signal in lowered for signal in ("pay", "billing", "member", "vip", "recharge"))

    async def _select_amount(self, page: Any, amount: float, steps: list[ScriptStep]) -> None:
        amount_value = _amount_text(amount)
        price_texts = (
            f"\u00a5{amount:.2f}",
            f"\uffe5{amount:.2f}",
            f"\u00a5{amount_value}",
            f"\uffe5{amount_value}",
        )
        for price_text in price_texts:
            try:
                element = await page.wait_for_selector(f"text={price_text}", timeout=2_000)
                if not element:
                    continue
                await element.click(timeout=_TIMEOUT_MS)
                steps.append(
                    ScriptStep(
                        description=f"Select Jimeng package priced {price_text}",
                        action="click",
                        selector=f"text={price_text}",
                        value=price_text,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                return
            except Exception:
                continue

        selectors = (
            f"[data-amount='{amount_value}']",
            f"[data-price='{amount_value}']",
            "input[type='number']",
            "input[inputmode='numeric']",
            "input[placeholder*='\u91d1\u989d']",
            "input[placeholder*='\u5145\u503c']",
        )
        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=2_000)
                if not element:
                    continue
                if selector.startswith("input"):
                    await element.click(timeout=_TIMEOUT_MS)
                    await element.fill(amount_value, timeout=_TIMEOUT_MS)
                    action = "fill"
                else:
                    await element.click(timeout=_TIMEOUT_MS)
                    action = "click"
                steps.append(
                    ScriptStep(
                        description=f"Select Jimeng amount {amount_value}",
                        action=action,
                        selector=selector,
                        value=amount_value if action == "fill" else None,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                return
            except Exception:
                continue
        raise ScriptExecutionError(f"Jimeng amount selector was not found for {amount_value}")

    async def _select_payment_method(
        self,
        page: Any,
        method: PaymentMethod,
        steps: list[ScriptStep],
    ) -> None:
        if method == PaymentMethod.wechat_qr:
            selectors = (
                "button:has-text('\u5fae\u4fe1')",
                "label:has-text('\u5fae\u4fe1')",
                "[class*='wechat']",
                "[data-method='wechat']",
                "[data-payment='wechat']",
            )
            method_name = "WeChat Pay"
        else:
            selectors = (
                "button:has-text('\u652f\u4ed8\u5b9d')",
                "label:has-text('\u652f\u4ed8\u5b9d')",
                "[class*='alipay']",
                "[data-method='alipay']",
                "[data-payment='alipay']",
            )
            method_name = "Alipay"

        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=2_000)
                if not element:
                    continue
                await element.click(timeout=_TIMEOUT_MS)
                steps.append(
                    ScriptStep(
                        description=f"Select Jimeng payment method: {method_name}",
                        action="click",
                        selector=selector,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                return
            except Exception:
                continue

        steps.append(
            ScriptStep(
                description=f"Jimeng payment method assumed/defaulted: {method_name}",
                action="wait",
                category=StepCategory.checkout_prep,
                risk=StepRisk.medium,
            )
        )

    async def _click_checkout(
        self,
        page: Any,
        steps: list[ScriptStep],
        method: PaymentMethod = PaymentMethod.alipay_qr,
    ) -> None:
        method_markers = {
            PaymentMethod.wechat_qr: ("微信", "WeChat"),
            PaymentMethod.alipay_qr: ("支付宝", "Alipay"),
        }.get(method, ("支付",))
        await self._enforce_synchronous_policy_checkpoint(
            page,
            checkpoint_id="confirm_jimeng_checkout",
            marker_groups=[
                (
                    *method_markers,
                    "同意并支付",
                    "去支付",
                    "确认订单",
                    "提交订单",
                    "下一步",
                    "购买",
                )
            ],
            extra_context={"payment_method": method.value},
        )

        selectors = (
            "button:has-text('\u540c\u610f\u5e76\u652f\u4ed8')",
            "text=\u540c\u610f\u5e76\u652f\u4ed8",
            "button:has-text('\u53bb\u652f\u4ed8')",
            "button:has-text('\u786e\u8ba4\u8ba2\u5355')",
            "button:has-text('\u63d0\u4ea4\u8ba2\u5355')",
            "button:has-text('\u4e0b\u4e00\u6b65')",
            "button:has-text('\u8d2d\u4e70')",
            "button:has-text('Pay')",
            "[type='submit']",
            "[class*='submit'][class*='pay']",
        )
        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if not element:
                    continue
                await element.click(timeout=_TIMEOUT_MS)
                steps.append(
                    ScriptStep(
                        description="Prepare Jimeng payment handoff",
                        action="click",
                        selector=selector,
                        category=StepCategory.final_authorization,
                        risk=StepRisk.high,
                    )
                )
                return
            except Exception:
                continue
        raise ScriptExecutionError("Jimeng checkout confirmation button was not found")

    async def _wait_for_human_payment_gate(self, page: Any, steps: list[ScriptStep]) -> None:
        selectors = (
            "img[class*='qr']",
            "img[class*='qrcode']",
            "canvas[class*='qr']",
            "canvas[class*='qrcode']",
            "[class*='qr-code']",
            "[class*='qrcode']",
            "[class*='pay-qr']",
            "[class*='modal']:has(img)",
            "[class*='dialog']:has(img)",
        )
        for selector in selectors:
            try:
                await page.wait_for_selector(selector, timeout=8_000)
                steps.append(
                    ScriptStep(
                        description=(
                            "Detected Jimeng QR/payment gate; waiting for user authorization"
                        ),
                        action="detect_payment",
                        selector=selector,
                        category=StepCategory.final_authorization,
                        risk=StepRisk.human_required,
                        requires_human_authorization=True,
                    )
                )
                return
            except Exception:
                continue

        current_url = str(getattr(page, "url", ""))
        if any(signal in current_url.lower() for signal in ("pay", "alipay", "wechat", "wxpay")):
            steps.append(
                ScriptStep(
                    description=(
                        "Jimeng redirected to external payment page; "
                        "waiting for user authorization"
                    ),
                    action="detect_payment",
                    url=current_url,
                    category=StepCategory.final_authorization,
                    risk=StepRisk.human_required,
                    requires_human_authorization=True,
                )
            )
            return

        raise ScriptExecutionError("Jimeng payment QR or redirect was not detected")
