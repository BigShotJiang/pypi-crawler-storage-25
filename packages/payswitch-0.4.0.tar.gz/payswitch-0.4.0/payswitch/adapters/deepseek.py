"""DeepSeek 平台充值适配器。

封装 DeepSeek 开放平台（platform.deepseek.com）充值页的完整操作流程，
支持支付宝扫码支付。当页面结构发生变更导致选择器失效时，
会抛出 ScriptExecutionError，由上层引擎自动回退至 Skyvern 智能模式。
"""

from __future__ import annotations

from typing import Any

from payswitch.adapters import AdapterRegistry
from payswitch.adapters.base import ScriptExecutionError, ScriptStep, SiteAdapter
from payswitch.experience import ExperienceRecipe
from payswitch.experience.registry import get_recipe
from payswitch.experience.runner import RecipeExecutionError, RecipeRunContext, RecipeRunner
from payswitch.experience.store import ExperienceStore
from payswitch.models.types import PaymentMethod, StepCategory

# DeepSeek 平台预设充值套餐（人民币元），按从小到大排列
# 实际套餐以页面展示为准，此列表仅用于金额匹配优先级排序
_PRESET_AMOUNTS: list[float] = [10, 20, 50, 100, 200, 500, 1000, 2000]

# Playwright 操作默认超时（毫秒）
_TIMEOUT_MS = 15_000


def _find_closest_preset(amount: float) -> float:
    """从预设套餐中找到与目标金额最接近的面值。

    Args:
        amount: 用户期望的充值金额（人民币元）。

    Returns:
        与 amount 差值绝对值最小的预设金额；若差值相同，优先返回较大金额。
    """
    return min(_PRESET_AMOUNTS, key=lambda p: (abs(p - amount), -p))


def _amount_string(amount: float) -> str:
    return str(int(amount)) if amount == int(amount) else str(amount)


@AdapterRegistry.register
class DeepSeekAdapter(SiteAdapter):
    """DeepSeek 开放平台充值适配器。

    支持通过支付宝扫码完成人民币充值。执行流程：
    1. 导航到充值页
    2. 选择预设套餐金额（优先精确匹配，次选最接近面值）
    3. 若无预设匹配，尝试填写自定义金额
    4. 选择支付宝支付方式
    5. 点击确认充值，等待二维码出现
    6. 返回 detect_payment 步骤，由检测器暂停并引导用户扫码

    选择器失效时抛出 ScriptExecutionError，触发 Skyvern 智能模式回退。
    """

    name = "deepseek"
    display_name = "DeepSeek"
    top_up_url = "https://platform.deepseek.com/top_up"
    login_url = "https://platform.deepseek.com/sign_in"
    supported_methods = [PaymentMethod.alipay_qr]
    recipe_flow = "topup_alipay_qr"

    @property
    def recipe(self) -> ExperienceRecipe:
        recipe = get_recipe(self.name, self.recipe_flow, store=self.recipe_store)
        if recipe is None:
            raise RuntimeError("DeepSeek experience recipe is not registered")
        return recipe

    async def validate_amount(self, amount: float) -> bool:
        """DeepSeek 最低充值金额为 10 元。"""
        return amount >= 10

    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        """执行 DeepSeek 充值完整脚本。

        Args:
            page: Playwright Page 对象。
            amount: 充值金额（人民币元，须 >= 10）。
            method: 指定支付方式；None 时默认使用支付宝扫码。

        Returns:
            按执行顺序排列的 ScriptStep 列表。

        Raises:
            ScriptExecutionError: 任意步骤无法定位元素或操作超时时抛出。
        """
        steps: list[ScriptStep] = []
        recipe = self.recipe

        async def record_step(step: ScriptStep) -> None:
            await self._record_step(steps, step)

        runner = RecipeRunner(
            recipe=recipe,
            semantic_actions={
                "ensure_logged_in": self._recipe_ensure_logged_in,
                "ensure_identity_ready": self._recipe_ensure_identity_ready,
                "select_amount": self._recipe_select_amount,
                "select_payment_method": self._recipe_select_payment_method,
                "click_confirm": self._recipe_click_confirm,
                "wait_for_qr": self._recipe_wait_for_qr,
            },
            telemetry_callback=self.telemetry_callback,
            policy_checkpoint_callback=self._recipe_policy_checkpoint,
            evidence_dir=self.recipe_evidence_dir,
            artifact_store=self.recipe_artifact_store,
            screenshot_budget=self.recipe_screenshot_budget,
        )

        try:
            await runner.run(
                page=page,
                amount=amount,
                method=method,
                steps=steps,
                record_step=record_step,
            )
        except RecipeExecutionError as exc:
            store = self._experience_store()
            if store is not None:
                store.record_outcome(
                    platform=self.name,
                    flow=recipe.flow,
                    recipe_id=recipe.recipe_id,
                    recipe_version=recipe.version,
                    succeeded=False,
                    confidence=recipe.confidence,
                    details=exc.failure_context,
                )
            raise ScriptExecutionError(
                str(exc),
                failure_context=exc.failure_context,
            ) from exc

        store = self._experience_store()
        if store is not None:
            store.record_outcome(
                platform=self.name,
                flow=recipe.flow,
                recipe_id=recipe.recipe_id,
                recipe_version=recipe.version,
                succeeded=True,
                confidence=recipe.confidence,
                details={
                    "step_count": len(steps),
                    "current_url": str(getattr(page, "url", "")),
                },
            )

        return steps

    def _experience_store(self) -> ExperienceStore | None:
        store = getattr(self, "recipe_store", None)
        if isinstance(store, ExperienceStore):
            return store
        return None

    async def _recipe_ensure_logged_in(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)

    async def _recipe_ensure_identity_ready(self, context: RecipeRunContext) -> None:
        await self._ensure_identity_gate_cleared(context.page)

    async def _recipe_select_amount(self, context: RecipeRunContext) -> None:
        amount_selected = await self._select_amount(context.page, context.amount, context.steps)
        if not amount_selected:
            await self._fill_custom_amount(context.page, context.amount, context.steps)

    async def _recipe_select_payment_method(self, context: RecipeRunContext) -> None:
        await self._select_payment_method(context.page, context.steps)

    async def _recipe_click_confirm(self, context: RecipeRunContext) -> None:
        await self._click_confirm(context.page, context.steps)

    async def _recipe_wait_for_qr(self, context: RecipeRunContext) -> None:
        await self._wait_for_qr(context.page, context.steps)

    async def _recipe_policy_checkpoint(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)
        await self._ensure_identity_gate_cleared(context.page)
        if context.waypoint.id != "confirm_topup_checkout":
            return

        visible_text = await self._visible_text_snapshot(context.page)
        required_markers = [
            *context.recipe.texts.get("topup_ready", []),
            *context.recipe.texts.get("payment_surface", []),
            "Next step",
        ]
        if any(marker in visible_text for marker in required_markers):
            return
        raise RuntimeError(
            "policy checkpoint blocked confirm_topup_checkout: "
            "missing visible DeepSeek payment markers"
        )

    async def _visible_text_snapshot(self, page: Any) -> str:
        evaluate = getattr(page, "evaluate", None)
        if evaluate is None:
            return ""
        try:
            result = await evaluate(
                """
                () => (document.body?.innerText || "")
                    .split("\\n")
                    .map((line) => line.trim())
                    .filter(Boolean)
                    .slice(0, 20)
                    .join("\\n")
                """
            )
        except Exception:
            return ""
        return str(result or "")

    # ------------------------------------------------------------------
    # 私有辅助方法
    # ------------------------------------------------------------------

    async def check_login_state(self, page: Any) -> tuple[bool, str | None]:
        current_url = page.url.lower()
        if "sign_in" in current_url or "login" in current_url:
            return (
                False,
                "检测到未登录状态，请先执行 'payswitch login deepseek' 完成登录。"
                f"当前 URL：{page.url}",
            )
        return True, None

    async def _wait_for_topup_ready(self, page: Any) -> None:
        for signal in self.recipe.texts.get("topup_ready", []):
            try:
                await page.wait_for_selector(f"text={signal}", timeout=4_000)
                return
            except Exception:
                continue
        await page.wait_for_timeout(800)

    async def _ensure_identity_gate_cleared(self, page: Any) -> None:
        visible_text = " ".join(self.recipe.texts.get("identity_verification", []))
        verification_signals = self.recipe.texts.get("identity_verification", [])
        matched_signal = await self._first_text_signal(page, verification_signals)
        if matched_signal is None:
            return
        raise ScriptExecutionError(
            "DeepSeek 当前仍要求先完成实名认证后才能继续充值。"
            f"命中的页面信号：{matched_signal}。"
            "请先在当前浏览器完成实名认证，再重试或让 external Computer Use 接力。"
            f"（参考信号：{visible_text}）"
        )

    async def _select_amount(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> bool:
        """尝试在预设套餐列表中点击匹配的金额按钮。

        先尝试精确匹配，再尝试最接近的预设面值。

        Returns:
            True 表示成功点击了某个预设按钮；False 表示未找到任何预设按钮。
        """
        amount_button_selectors = self._render_recipe_selectors(
            "amount_exact",
            amount_int=f"{amount:.0f}",
        )

        # 尝试精确金额匹配
        for selector in amount_button_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if element:
                        step = ScriptStep(
                            description=f"点击预设套餐金额 ¥{amount:.0f}",
                            action="click",
                            selector=selector,
                            expected_texts=[f"¥{amount:.0f}"],
                        )
                        steps.append(step)
                        await element.click(timeout=_TIMEOUT_MS)
                        return True
            except Exception:
                # 选择器未命中，继续尝试下一个
                continue

        # 精确匹配失败，尝试最接近的预设金额
        closest = _find_closest_preset(amount)
        if closest != amount:
            closest_selectors = self._render_recipe_selectors(
                "amount_exact",
                amount_int=f"{closest:.0f}",
            )
            for selector in closest_selectors:
                try:
                    element = await page.wait_for_selector(selector, timeout=3_000)
                    if element:
                        step = ScriptStep(
                            description=(
                                f"精确金额 ¥{amount:.0f} 无匹配套餐，"
                                f"改选最接近预设金额 ¥{closest:.0f}"
                            ),
                            action="click",
                            selector=selector,
                            expected_texts=[f"¥{closest:.0f}"],
                        )
                        steps.append(step)
                        await element.click(timeout=_TIMEOUT_MS)
                        return True
                except Exception:
                    continue

        return False

    async def _fill_custom_amount(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> None:
        """在自定义金额输入框中填写目标金额。

        Raises:
            ScriptExecutionError: 找不到自定义金额输入框时抛出。
        """
        custom_toggle_selectors = self.recipe.selectors.get("custom_amount_toggle", [])
        for selector in custom_toggle_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=2_000)
                if element:
                    await element.click(timeout=_TIMEOUT_MS)
                    break
            except Exception:
                continue

        custom_input_selectors = self.recipe.selectors.get("custom_amount_input", [])

        for selector in custom_input_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if element:
                    # 先点击激活输入框，清空已有内容，再填入金额
                    await element.click(timeout=_TIMEOUT_MS)
                    await element.fill("", timeout=_TIMEOUT_MS)
                    amount_str = _amount_string(amount)
                    await element.fill(amount_str, timeout=_TIMEOUT_MS)

                    step = ScriptStep(
                        description=f"在自定义金额输入框中填写 {amount_str} 元",
                        action="fill",
                        selector=selector,
                        value=amount_str,
                        expected_texts=[amount_str],
                    )
                    steps.append(step)
                    return
            except Exception:
                continue

        # 所有选择器均失败
        raise ScriptExecutionError(
            f"未找到预设套餐金额 ¥{amount:.0f} 的按钮，"
            "且自定义金额输入框也无法定位，"
            "页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _select_payment_method(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """选择支付宝支付方式。

        Raises:
            ScriptExecutionError: 找不到支付宝选项时抛出。
        """
        # 当前 DeepSeek 充值页在实测中直接使用默认在线充值通道，
        # 页面不会稳定暴露一个显式的“支付宝”选项，因此这里确认
        # 默认支付面板存在即可，避免把真实的无选项页面误判为失败。
        for selector in self.recipe.selectors.get("payment_method_default", []):
            try:
                await page.wait_for_selector(selector, timeout=3_000)
                steps.append(
                    ScriptStep(
                        description="确认当前使用默认在线充值支付路径",
                        action="wait",
                        selector=selector,
                        expected_texts=["Payment method"],
                    )
                )
                return
            except Exception:
                continue

        raise ScriptExecutionError("未检测到 DeepSeek 默认在线充值支付区块，无法继续。")

    async def _click_confirm(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """点击确认充值/去支付按钮。

        Raises:
            ScriptExecutionError: 找不到确认按钮时抛出。
        """
        confirm_selectors = self.recipe.selectors.get("confirm", [])

        for selector in confirm_selectors:
            try:
                locator = page.locator(selector)
                count = await locator.count()
                if count > 0:
                    target = locator.nth(count - 1)
                    step = ScriptStep(
                        description="点击 Next step，触发支付流程",
                        action="click",
                        selector=selector,
                        expected_texts=["Next step"],
                    )
                    steps.append(step)
                    await target.click(timeout=_TIMEOUT_MS)
                    return
            except Exception:
                pass

            try:
                element = await page.wait_for_selector(selector, timeout=4_000)
                if element:
                    step = ScriptStep(
                        description="点击 Next step，触发支付流程",
                        action="click",
                        selector=selector,
                        expected_texts=["Next step"],
                    )
                    steps.append(step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return
            except Exception:
                continue

        raise ScriptExecutionError(
            "未找到 DeepSeek 的 Next step / 支付确认入口，页面结构可能已变更。"
        )

    async def _wait_for_qr(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """等待支付二维码出现，记录 detect_payment 步骤。

        二维码出现后，检测器将接管并暂停脚本，等待用户扫码。

        Raises:
            ScriptExecutionError: 超时后仍未检测到二维码时抛出。
        """
        qr_selectors = self.recipe.selectors.get("qr", [])

        qr_selector_found: str | None = None
        for selector in qr_selectors:
            try:
                await page.wait_for_selector(selector, timeout=8_000)
                qr_selector_found = selector
                break
            except Exception:
                continue

        if qr_selector_found is None:
            raise ScriptExecutionError(
                "等待支付二维码超时，未在页面上检测到二维码元素，"
                "触发 Skyvern 回退以智能定位二维码。"
            )

        # 记录 detect_payment 步骤，通知检测器接管
        steps.append(
            ScriptStep(
                description="检测到支付宝二维码，等待用户扫码完成支付",
                action="detect_payment",
                selector=qr_selector_found,
                category=self._detect_payment_category(),
                expected_texts=["Scan QR code to pay"],
                requires_human_authorization=True,
            )
        )

    def _render_recipe_selectors(self, key: str, **values: str) -> list[str]:
        selectors = self.recipe.selectors.get(key, [])
        return [selector.format(**values) for selector in selectors]

    async def _first_text_signal(self, page: Any, signals: list[str]) -> str | None:
        for signal in signals:
            try:
                locator = page.locator(f"text={signal}")
                count = await locator.count()
                if count > 0:
                    return signal
            except Exception:
                continue
        return None

    def _detect_payment_category(self) -> StepCategory:
        return StepCategory.final_authorization
