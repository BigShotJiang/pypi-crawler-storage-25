"""站点适配器基类定义。

所有平台适配器必须继承 SiteAdapter 并实现 execute_topup 方法。
ScriptStep 描述单个页面操作步骤，供执行引擎记录和回放。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from payswitch.models.types import PaymentMethod, StepCategory, StepRisk


class ScriptStep(BaseModel):
    """单个脚本步骤的结构化定义。

    执行引擎将每个操作封装为 ScriptStep，
    便于日志记录、调试和失败回放。
    """

    # 步骤描述，使用中文说明该步骤的意图
    description: str
    # 操作类型：navigate / click / fill / wait / detect_payment
    action: str
    # CSS 选择器或 XPath，navigate 和 detect_payment 步骤可为空
    selector: str | None = None
    # fill 动作填入的值，其他动作可为空
    value: str | None = None
    # navigate 动作的目标 URL
    url: str | None = None
    # 步骤类别：默认当作普通导航，适配器可将高风险步骤标为 checkout_prep/final_authorization
    category: StepCategory = StepCategory.nav
    # 风险等级：financial/sensitive 步骤应显式升级
    risk: StepRisk = StepRisk.low
    # 执行前后应出现的文本信号（最小版本先用文本断言表达）
    expected_texts: list[str] = Field(default_factory=list)
    # 执行前后不应出现的文本信号，如自动续费/订阅等
    forbidden_texts: list[str] = Field(default_factory=list)
    # 是否必须用户授权后才允许执行
    requires_human_authorization: bool = False


class ScriptExecutionError(Exception):
    """脚本执行失败异常。

    当适配器在固定脚本模式下遇到无法处理的情况时抛出此异常，
    执行引擎捕获后将自动回退到 Skyvern 智能模式重试。
    """

    def __init__(self, message: str, *, failure_context: dict[str, object] | None = None):
        super().__init__(message)
        self.failure_context = failure_context


class LoginRequiredError(ScriptExecutionError):
    """Raised when the target platform requires an authenticated session."""


class SiteAdapter(ABC):
    """站点脚本适配器基类。

    每个平台实现一个子类，并通过 @AdapterRegistry.register 注册。
    子类必须声明类属性 name / display_name / top_up_url / login_url /
    supported_methods，并实现 execute_topup 抽象方法。

    示例::

        @AdapterRegistry.register
        class DeepSeekAdapter(SiteAdapter):
            name = "deepseek"
            display_name = "DeepSeek"
            top_up_url = "https://platform.deepseek.com/top_up"
            login_url = "https://platform.deepseek.com/sign_in"
            supported_methods = [PaymentMethod.alipay_qr]

            async def execute_topup(self, page, amount, method=None):
                ...
    """

    # 平台唯一标识符（小写英文），用作注册表的键
    name: str
    # 平台展示名称（用于 CLI 输出和日志）
    display_name: str
    # 充值页面 URL
    top_up_url: str
    # 登录页面 URL
    login_url: str
    # 该平台支持的支付方式列表
    supported_methods: list[PaymentMethod]
    # 支付前是否必须校验登录态
    requires_login: bool = True
    # Whether a fixed adapter failure may be retried by the Computer Use fallback.
    # Some sites expose adjacent paid actions in one surface, so guessing after a
    # partial script failure is riskier than handing control back to the user.
    allow_smart_fallback: bool = True
    # Whether page-level "success" detection may complete the transaction while
    # the adapter is still running deterministic script steps.
    allow_detector_completion: bool = True
    # Require the script to produce an explicit final authorization/payment-gate
    # step before it can leave script mode.
    requires_payment_gate: bool = False
    progress_callback: Callable[[ScriptStep], Awaitable[None]] | None = None
    telemetry_callback: Callable[[dict[str, Any]], Awaitable[None]] | None = None
    recipe_evidence_dir: Path | None = None
    recipe_store: Any | None = None
    recipe_artifact_store: Any | None = None
    recipe_screenshot_budget: Any | None = None

    async def _record_step(self, steps: list[ScriptStep], step: ScriptStep) -> None:
        """Append a script step and optionally stream it to the orchestrator."""
        steps.append(step)
        if self.progress_callback is not None:
            await self.progress_callback(step)

    @abstractmethod
    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        """执行充值脚本，返回本次执行的步骤列表。

        实现者应按顺序完成以下工作：
        1. 导航到充值页（如尚未在该页）
        2. 填写金额
        3. 选择支付方式
        4. 触发支付二维码或跳转（最后一步应包含 detect_payment 动作）

        遇到页面结构变更或无法定位元素时，应抛出 ScriptExecutionError，
        由上层引擎决定是否回退到 Skyvern。

        Args:
            page: Playwright 的 Page 对象（使用 Any 类型避免强依赖 playwright）。
            amount: 充值金额（人民币元）。
            method: 指定支付方式；为 None 时由适配器自行选择默认方式。

        Returns:
            按执行顺序排列的 ScriptStep 列表，用于日志和审计。

        Raises:
            ScriptExecutionError: 脚本执行失败，触发上层回退逻辑。
        """

    async def validate_amount(self, amount: float) -> bool:
        """验证充值金额是否在平台支持的范围内。

        子类可覆盖此方法以添加平台特定的金额限制，
        例如最小充值额或特定面额限制。

        Args:
            amount: 待验证的充值金额（人民币元）。

        Returns:
            True 表示金额合法，False 表示不合法。
        """
        return amount > 0

    def get_login_url(self) -> str:
        """获取平台登录页 URL。

        Returns:
            登录页面的完整 URL 字符串。
        """
        return self.login_url

    def get_top_up_url(self) -> str:
        """获取平台充值页 URL。

        Returns:
            充值页面的完整 URL 字符串。
        """
        return self.top_up_url

    async def check_login_state(self, page: Any) -> tuple[bool, str | None]:
        """Return whether the current page reflects an authenticated session.

        Subclasses should override this when the platform has stronger signals
        than a plain login URL redirect.
        """
        current_url = str(getattr(page, "url", "")).lower()
        login_signals = ("login", "sign_in", "signin", "passport", "auth")
        if any(signal in current_url for signal in login_signals):
            return (
                False,
                f"检测到未登录状态，请先执行 'payswitch login {self.name}' 完成登录。"
                f"当前 URL：{getattr(page, 'url', current_url)}",
            )
        return True, None

    async def ensure_logged_in(self, page: Any) -> None:
        """Raise ``LoginRequiredError`` when the current browser session is not usable."""
        logged_in, reason = await self.check_login_state(page)
        if logged_in:
            return
        raise LoginRequiredError(
            reason or f"检测到 {self.display_name} 未登录，请先执行 'payswitch login {self.name}'。"
        )

    async def _visible_text_snapshot(self, page: Any, *, line_limit: int = 30) -> str:
        """Return a compact text snapshot of the current page for policy checks."""
        evaluate = getattr(page, "evaluate", None)
        if evaluate is None:
            return ""
        try:
            result = await evaluate(
                f"""
                () => (document.body?.innerText || "")
                    .split("\\n")
                    .map((line) => line.trim())
                    .filter(Boolean)
                    .slice(0, {line_limit})
                    .join("\\n")
                """
            )
        except Exception:
            return ""
        return str(result or "")

    async def _enforce_synchronous_policy_checkpoint(
        self,
        page: Any,
        *,
        checkpoint_id: str,
        marker_groups: Sequence[Sequence[str]],
        action_type: str = "confirm",
        waypoint_category: str = "final_authorization",
        waypoint_risk: str = "high",
        extra_context: Mapping[str, object] | None = None,
    ) -> str:
        """Fail closed when a high-risk transition lacks visible payment markers."""
        await self.ensure_logged_in(page)
        visible_text = await self._visible_text_snapshot(page)
        visible_text_lower = visible_text.lower()

        missing_groups: list[list[str]] = []
        for group in marker_groups:
            normalized_group = [marker.strip() for marker in group if marker and marker.strip()]
            if not normalized_group:
                continue
            if any(marker.lower() in visible_text_lower for marker in normalized_group):
                continue
            missing_groups.append(normalized_group)

        if not missing_groups:
            return visible_text

        failure_context: dict[str, object] = {
            "failure_type": "script",
            "requires_human_gate": True,
            "synchronous_policy_checkpoint": True,
            "waypoint_id": checkpoint_id,
            "waypoint_category": waypoint_category,
            "waypoint_risk": waypoint_risk,
            "action_type": action_type,
            "current_url": str(getattr(page, "url", "")),
            "required_marker_groups": missing_groups,
            "visible_text_excerpt": visible_text[:500],
        }
        if extra_context is not None:
            failure_context.update(dict(extra_context))

        raise ScriptExecutionError(
            f"policy checkpoint blocked {checkpoint_id}: missing visible payment markers",
            failure_context=failure_context,
        )
