"""Kimi（Moonshot AI）平台充值适配器。

当前 Kimi 已统一到 kimi.com 域名，旧版 /recharge 入口可能重定向到首页。
本适配器会先进行登录态判断，再尝试发现并进入订阅/充值入口，最后执行支付流程。
"""

from __future__ import annotations

import inspect
from typing import Any

from payswitch.adapters import AdapterRegistry
from payswitch.adapters.base import (
    ScriptExecutionError,
    ScriptStep,
    SiteAdapter,
)
from payswitch.experience.models import ExperienceRecipe
from payswitch.experience.registry import get_recipe
from payswitch.experience.runner import RecipeExecutionError, RecipeRunContext, RecipeRunner
from payswitch.experience.store import ExperienceStore
from payswitch.models.types import PaymentMethod

# Kimi 会员套餐（人民币元/月），按从小到大排列。
# 实际套餐以页面展示为准，此列表仅用于金额匹配优先级排序。
_PRESET_AMOUNTS: list[float] = [49, 99]

# Playwright 操作默认超时（毫秒）
_TIMEOUT_MS = 15_000


def _find_closest_preset(amount: float) -> float:
    """从预设套餐中找到与目标金额最接近的面值。

    Args:
        amount: 用户期望的充值金额（人民币元）。

    Returns:
        与 amount 差值绝对值最小的预设金额；若差值相同，优先返回较大金额。
    """
    return min(_PRESET_AMOUNTS, key=lambda p: (abs(p - amount), -p))


@AdapterRegistry.register
class KimiAdapter(SiteAdapter):
    """Kimi（Moonshot AI）平台充值适配器。

    支持通过支付宝扫码完成人民币充值。执行流程：
    1. 导航到充值页
    2. 选择预设套餐金额（优先精确匹配，次选最接近面值）
    3. 若无预设匹配，尝试填写自定义金额
    4. 选择支付宝支付方式
    5. 点击确认充值，等待二维码出现
    6. 返回 detect_payment 步骤，由检测器暂停并引导用户扫码

    选择器失效时抛出 ScriptExecutionError，触发 Skyvern 智能模式回退。
    """

    name = "kimi"
    display_name = "Kimi (Moonshot)"
    # Kimi 新版会员购买页。旧版 /recharge 会回到首页，容易让脚本卡在空转。
    top_up_url = "https://www.kimi.com/membership/pricing?from=pay_switch"
    login_url = "https://www.kimi.com"
    preflight_url = login_url
    supported_methods = [PaymentMethod.alipay_qr]
    recipe_flow = "membership_monthly_qr"

    @property
    def recipe(self) -> ExperienceRecipe:
        recipe = get_recipe(self.name, self.recipe_flow, store=self.recipe_store)
        if recipe is None:
            raise RuntimeError("Kimi experience recipe is not registered")
        return recipe

    async def validate_amount(self, amount: float) -> bool:
        """Kimi 最低充值金额为 10 元。"""
        return amount >= 10

    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        """执行 Kimi 充值完整脚本。

        Args:
            page: Playwright Page 对象。
            amount: 充值金额（人民币元，须 >= 10）。
            method: 指定支付方式；None 时默认使用支付宝扫码。

        Returns:
            按执行顺序排列的 ScriptStep 列表。

        Raises:
            ScriptExecutionError: 任意步骤无法定位元素或操作超时时抛出。
        """
        steps: list[ScriptStep] = []
        recipe = self.recipe

        async def record_step(step: ScriptStep) -> None:
            await self._record_step(steps, step)

        runner = RecipeRunner(
            recipe=recipe,
            semantic_actions={
                "ensure_logged_in": self._recipe_ensure_logged_in,
                "ensure_checkout_page": self._recipe_ensure_checkout_page,
                "select_plan": self._recipe_select_plan,
                "select_payment_method": self._recipe_select_payment_method,
                "click_confirm": self._recipe_click_confirm,
                "wait_for_qr": self._recipe_wait_for_qr,
            },
            telemetry_callback=self.telemetry_callback,
            policy_checkpoint_callback=self._recipe_policy_checkpoint,
            evidence_dir=self.recipe_evidence_dir,
            artifact_store=self.recipe_artifact_store,
            screenshot_budget=self.recipe_screenshot_budget,
        )

        try:
            await runner.run(
                page=page,
                amount=amount,
                method=method,
                steps=steps,
                record_step=record_step,
            )
        except RecipeExecutionError as exc:
            store = self._experience_store()
            if store is not None:
                store.record_outcome(
                    platform=self.name,
                    flow=recipe.flow,
                    recipe_id=recipe.recipe_id,
                    recipe_version=recipe.version,
                    succeeded=False,
                    confidence=recipe.confidence,
                    details=exc.failure_context,
                )
            raise ScriptExecutionError(
                str(exc),
                failure_context=exc.failure_context,
            ) from exc

        store = self._experience_store()
        if store is not None:
            store.record_outcome(
                platform=self.name,
                flow=recipe.flow,
                recipe_id=recipe.recipe_id,
                recipe_version=recipe.version,
                succeeded=True,
                confidence=recipe.confidence,
                details={
                    "step_count": len(steps),
                    "current_url": str(getattr(page, "url", "")),
                },
            )

        return steps

    def _experience_store(self) -> ExperienceStore | None:
        store = getattr(self, "recipe_store", None)
        if isinstance(store, ExperienceStore):
            return store
        return None

    async def _recipe_ensure_logged_in(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)

    async def _recipe_ensure_checkout_page(self, context: RecipeRunContext) -> None:
        await self._ensure_checkout_page(context.page, context.steps)

    async def _recipe_select_plan(self, context: RecipeRunContext) -> None:
        amount_selected = await self._select_amount(context.page, context.amount, context.steps)
        if not amount_selected:
            await self._fill_custom_amount(context.page, context.amount, context.steps)
        await self.ensure_logged_in(context.page)

    async def _recipe_select_payment_method(self, context: RecipeRunContext) -> None:
        await self._select_payment_method(context.page, context.steps)

    async def _recipe_click_confirm(self, context: RecipeRunContext) -> None:
        await self._click_confirm(context.page, context.steps)

    async def _recipe_wait_for_qr(self, context: RecipeRunContext) -> None:
        await self._wait_for_qr(context.page, context.steps)

    async def _recipe_policy_checkpoint(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)
        if context.waypoint.id != "confirm_membership_checkout":
            return

        visible_text = await self._visible_text_snapshot(context.page)
        required_markers = [
            *context.recipe.texts.get("pricing_surface", []),
            *context.recipe.texts.get("payment_surface", []),
            "Continue",
        ]
        if any(marker in visible_text for marker in required_markers):
            return
        raise RuntimeError(
            "policy checkpoint blocked confirm_membership_checkout: "
            "missing visible pricing/payment markers"
        )

    async def _visible_text_snapshot(self, page: Any) -> str:
        evaluate = getattr(page, "evaluate", None)
        if evaluate is None:
            return ""
        try:
            result = await evaluate(
                """
                () => (document.body?.innerText || "")
                    .split("\\n")
                    .map((line) => line.trim())
                    .filter(Boolean)
                    .slice(0, 20)
                    .join("\\n")
                """
            )
        except Exception:
            return ""
        return str(result or "")

    async def check_login_state(self, page: Any) -> tuple[bool, str | None]:
        """检测 Kimi 登录态，返回明确的未登录原因。"""
        current_url = page.url.lower()
        login_url_signals = ("login", "sign_in", "signin", "passport")
        if any(sig in current_url for sig in login_url_signals):
            return (
                False,
                "检测到未登录状态，请先执行 'payswitch login kimi' 完成登录。"
                f"当前 URL：{page.url}",
            )

        # 新版 Kimi 未登录首页可能展示中英文登录提示；会员页也可能
        # 在点击 Subscribe 后以内嵌弹窗要求登录，URL 不一定变化。
        # 这里必须只认“可见”的登录提示。Kimi 页面会保留隐藏登录模板，
        # 如果只用 count() 判断，会把已登录账号误判成未登录。
        login_prompt_selectors = (
            "text=登录以同步历史会话",
            "text=Log in to sync chat history",
            "[role='dialog']:has-text('登录')",
            "[role='dialog']:has-text('扫码登录')",
            "[role='dialog']:has-text('手机号登录')",
            "[role='dialog']:has-text('手机验证码登录')",
            "[role='dialog']:has-text('Log in')",
            "[role='dialog']:has-text('Sign in')",
            "button:has-text('登录')",
            "button:has-text('Log in')",
            "a:has-text('登录')",
            "a:has-text('Log in')",
        )
        for selector in login_prompt_selectors:
            if await self._is_visible(page, selector):
                return (
                    False,
                    f"检测到 Kimi 未登录或登录态失效（命中 {selector}）。"
                    "请先执行 'payswitch login kimi'。",
                )
        return True, None

    async def _is_visible(self, page: Any, selector: str) -> bool:
        """Return True only when a selector resolves to a visible element."""
        try:
            locator = page.locator(selector)
            target = getattr(locator, "first", locator)
            visible_call = getattr(target, "is_visible", None)
            if visible_call is None:
                visible_call = getattr(locator, "is_visible", None)
            if visible_call is None:
                return False

            visible = visible_call()
            if inspect.isawaitable(visible):
                visible = await visible
            return visible is True
        except Exception:
            return False

    async def _ensure_checkout_page(self, page: Any, steps: list[ScriptStep]) -> None:
        """确保页面进入可执行充值/订阅的区域。"""
        if self._looks_like_checkout_url(page.url):
            return
        if await self._looks_like_checkout_surface(page):
            return

        # 若当前还在首页，尝试点击订阅/升级入口。
        entry_selectors = [
            "a:has-text('Upgrade your plan')",
            "button:has-text('Upgrade your plan')",
            "[role='button']:has-text('Upgrade your plan')",
            "text=Upgrade your plan",
            "a:has-text('Upgrade')",
            "button:has-text('Upgrade')",
            "[role='button']:has-text('Upgrade')",
            "a:has-text('Subscribe')",
            "button:has-text('Subscribe')",
            "[role='button']:has-text('Subscribe')",
            "a:has-text('充值')",
            "button:has-text('充值')",
            "a:has-text('订阅')",
            "button:has-text('订阅')",
            "a:has-text('会员')",
            "button:has-text('会员')",
            "a:has-text('升级')",
            "button:has-text('升级')",
            "a[href*='recharge']",
            "a[href*='billing']",
            "a[href*='subscription']",
            "a[href*='pay']",
        ]
        for selector in entry_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=2_000)
                if not element:
                    continue

                await self._record_step(
                    steps,
                    ScriptStep(
                        description="从 Kimi 首页进入订阅/充值入口",
                        action="click",
                        selector=selector,
                    )
                )
                await element.click(timeout=_TIMEOUT_MS)
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=5_000)
                except Exception:
                    pass
                has_checkout_url = self._looks_like_checkout_url(page.url)
                has_checkout_surface = await self._looks_like_checkout_surface(page)
                if has_checkout_url or has_checkout_surface:
                    return
            except Exception:
                continue

        # 最后才用稳定 pricing URL 兜底。这样 WebUI/noVNC 能先看到
        # “官网首页 -> 检查登录 -> 找入口”的真实流程，而不是一上来跳付款页。
        try:
            await self._record_step(
                steps,
                ScriptStep(
                    description="未找到首页订阅入口，直接进入 Kimi 会员套餐页",
                    action="navigate",
                    url=self.top_up_url,
                )
            )
            await page.goto(self.top_up_url, wait_until="domcontentloaded", timeout=_TIMEOUT_MS)
            try:
                await page.wait_for_load_state("networkidle", timeout=5_000)
            except Exception:
                pass
            if self._looks_like_checkout_url(page.url) or await self._looks_like_checkout_surface(
                page
            ):
                return
        except Exception:
            pass

        # 给出可执行的人类动作提示，避免误报为“金额选择失败”。
        raise ScriptExecutionError(
            "已登录但未发现 Kimi 的订阅/充值入口。"
            "请先在浏览器中手动打开 Kimi 的订阅页面，再重试 spend。"
        )

    def _looks_like_checkout_url(self, url: str) -> bool:
        """判断当前 URL 是否接近充值/订阅页。"""
        lowered = url.lower()
        signals = (
            "recharge",
            "billing",
            "subscription",
            "member",
            "membership",
            "pricing",
            "payment",
            "pay",
        )
        return any(signal in lowered for signal in signals)

    async def _looks_like_checkout_surface(self, page: Any) -> bool:
        """判断当前页面或弹窗是否已经显示会员/套餐购买内容。"""
        surface_selectors = (
            "[role='dialog']:has-text('Monthly')",
            "[role='dialog']:has-text('Subscribe')",
            "[role='dialog']:has-text('Upgrade')",
            "[role='dialog']:has-text('月付')",
            "[role='dialog']:has-text('订阅')",
            "[role='dialog']:has-text('会员')",
            "[class*='modal']:has-text('Monthly')",
            "[class*='modal']:has-text('Subscribe')",
            "[class*='modal']:has-text('月付')",
            "[class*='dialog']:has-text('Monthly')",
            "[class*='dialog']:has-text('Subscribe')",
            "[class*='dialog']:has-text('月付')",
            "text=Monthly",
            "text=Annually",
            "text=Subscribe",
            "text=月付",
            "text=年付",
            "text=套餐",
            "text=会员",
        )
        for selector in surface_selectors:
            try:
                if await page.locator(selector).count() > 0:
                    return True
            except Exception:
                continue
        return False

    # ------------------------------------------------------------------
    # 私有辅助方法
    # ------------------------------------------------------------------

    async def _select_amount(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> bool:
        """尝试在预设套餐列表中点击匹配的金额按钮。

        先尝试精确匹配，再尝试最接近的预设面值。

        Returns:
            True 表示成功点击了某个预设按钮；False 表示未找到任何预设按钮。
        """
        if await self._select_kimi_monthly_plan(page, amount, steps):
            return True

        # Kimi 充值页套餐金额按钮的候选选择器策略（按优先级排列）
        # 基于 React SPA 的通用模式推断，实际 DOM 结构可能不同
        amount_button_selectors = [
            # 策略 A：包含人民币符号和数字的按钮
            f"button:has-text('¥{amount:.0f}')",
            f"button:has-text('¥ {amount:.0f}')",
            f"button:has-text('{amount:.0f}元')",
            # 策略 B：套餐卡片或选项，class 含 amount/package/recharge 关键词
            f"[class*='amount']:has-text('{amount:.0f}')",
            f"[class*='package']:has-text('{amount:.0f}')",
            f"[class*='recharge']:has-text('{amount:.0f}')",
            f"[class*='plan']:has-text('{amount:.0f}')",
            # 策略 C：data 属性匹配
            f"[data-amount='{amount:.0f}']",
            f"[data-value='{amount:.0f}']",
            f"[data-price='{amount:.0f}']",
        ]

        # 尝试精确金额匹配
        for selector in amount_button_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if element:
                    step = ScriptStep(
                        description=f"点击预设套餐金额 ¥{amount:.0f}",
                        action="click",
                        selector=selector,
                    )
                    await self._record_step(steps, step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return True
            except Exception:
                # 选择器未命中，继续尝试下一个
                continue

        # 精确匹配失败，尝试最接近的预设金额
        closest = _find_closest_preset(amount)
        if closest != amount:
            closest_selectors = [
                f"button:has-text('¥{closest:.0f}')",
                f"button:has-text('¥ {closest:.0f}')",
                f"button:has-text('{closest:.0f}元')",
                f"[class*='amount']:has-text('{closest:.0f}')",
                f"[class*='package']:has-text('{closest:.0f}')",
                f"[data-amount='{closest:.0f}']",
            ]
            for selector in closest_selectors:
                try:
                    element = await page.wait_for_selector(selector, timeout=3_000)
                    if element:
                        step = ScriptStep(
                            description=(
                                f"精确金额 ¥{amount:.0f} 无匹配套餐，"
                                f"改选最接近预设金额 ¥{closest:.0f}"
                            ),
                            action="click",
                            selector=selector,
                        )
                        await self._record_step(steps, step)
                        await element.click(timeout=_TIMEOUT_MS)
                        return True
                except Exception:
                    continue

        return False

    async def _select_kimi_monthly_plan(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> bool:
        """选择新版 Kimi pricing 页的月付会员套餐并点击 Subscribe。

        实测新版 Kimi 页默认可能停在年付，最低月付套餐为 Andante / ¥49。
        这里用 DOM 坐标点击可见元素，绕开 CloakBrowser 对部分 React 文本
        locator 的 humanized click 滚动失败问题。
        """

        if not (
            self._looks_like_checkout_url(page.url)
            or await self._looks_like_checkout_surface(page)
        ):
            return False

        await self._click_visible_by_script(
            page,
            """
            () => {
              const isVisible = (el) => {
                const r = el.getBoundingClientRect();
                const s = window.getComputedStyle(el);
                return r.width > 4 && r.height > 4 &&
                  r.bottom > 0 && r.right > 0 &&
                  r.left < window.innerWidth && r.top < window.innerHeight &&
                  s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
              };
              const candidates = Array.from(document.querySelectorAll(
                '.pricing-cycles div, .pricing-cycles span'
              ));
              const node = candidates.find((el) =>
                isVisible(el) && (el.innerText || el.textContent || '').trim() === 'Monthly'
              );
              if (!node) return null;
              const clickable = node.closest('div') || node;
              const r = clickable.getBoundingClientRect();
              return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
            }
            """,
        )
        await page.wait_for_timeout(500)

        amount_text = f"¥{int(amount)}" if amount == int(amount) else f"¥{amount}"
        clicked = await self._click_visible_by_script(
            page,
            """
            (amountText) => {
              const isVisible = (el) => {
                const r = el.getBoundingClientRect();
                const s = window.getComputedStyle(el);
                return r.width > 4 && r.height > 4 &&
                  r.bottom > 0 && r.right > 0 &&
                  r.left < window.innerWidth && r.top < window.innerHeight &&
                  s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
              };
              const buttons = Array.from(document.querySelectorAll(
                'button, [role="button"]'
              )).filter((el) =>
                isVisible(el) && /subscribe/i.test(el.innerText || el.textContent || '')
              );
              const exact = buttons.find((button) => {
                const plan = button.closest('.plan-container, .plan') || button.parentElement;
                const text = (plan?.innerText || plan?.textContent || '').replace(/\\s+/g, ' ');
                return text.includes(amountText) && /month/i.test(text);
              });
              const fallback = buttons.find((button) => {
                const plan = button.closest('.plan-container, .plan') || button.parentElement;
                const text = (plan?.innerText || plan?.textContent || '').replace(/\\s+/g, ' ');
                return /month/i.test(text);
              }) || buttons[0];
              const target = exact || fallback;
              if (!target) return null;
              const r = target.getBoundingClientRect();
              return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
            }
            """,
            amount_text,
        )
        if not clicked:
            return False
        await self._record_step(
            steps,
            ScriptStep(
                description=f"选择 Kimi 月付会员套餐 {amount_text} 并点击 Subscribe",
                action="click",
                selector="button.plan-button",
            )
        )
        await page.wait_for_timeout(1_500)
        return True

    async def _click_visible_by_script(
        self,
        page: Any,
        script: str,
        arg: Any = None,
    ) -> bool:
        """Evaluate JS that returns a visible coordinate and click it."""
        point = await page.evaluate(script, arg)
        if not isinstance(point, dict):
            return False
        x = point.get("x")
        y = point.get("y")
        if not isinstance(x, int | float) or not isinstance(y, int | float):
            return False
        await page.mouse.click(float(x), float(y))
        return True

    async def _fill_custom_amount(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> None:
        """在自定义金额输入框中填写目标金额。

        Raises:
            ScriptExecutionError: 找不到自定义金额输入框时抛出。
        """
        # 自定义金额输入框的候选选择器（Kimi 可能有此功能）
        custom_input_selectors = [
            "input[placeholder*='自定义']",
            "input[placeholder*='金额']",
            "input[placeholder*='请输入']",
            "input[placeholder*='充值']",
            "input[type='number'][class*='amount']",
            "input[type='number'][class*='recharge']",
            "input[type='text'][class*='amount']",
            # 通用兜底：充值区域内的数字输入框
            "[class*='recharge'] input[type='number']",
            "form input[type='number']",
        ]

        for selector in custom_input_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if element:
                    # 先点击激活输入框，清空已有内容，再填入金额
                    await element.click(timeout=_TIMEOUT_MS)
                    await element.fill("", timeout=_TIMEOUT_MS)
                    amount_str = str(int(amount)) if amount == int(amount) else str(amount)
                    await element.fill(amount_str, timeout=_TIMEOUT_MS)

                    step = ScriptStep(
                        description=f"在自定义金额输入框中填写 {amount_str} 元",
                        action="fill",
                        selector=selector,
                        value=amount_str,
                    )
                    await self._record_step(steps, step)
                    return
            except Exception:
                continue

        # 所有选择器均失败，触发 Skyvern 回退
        raise ScriptExecutionError(
            f"未找到预设套餐金额 ¥{amount:.0f} 的按钮，"
            "且自定义金额输入框也无法定位，"
            "Kimi 页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _select_payment_method(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """选择支付宝支付方式。

        Raises:
            ScriptExecutionError: 找不到支付宝选项时抛出。
        """
        # 支付宝选项的候选选择器（覆盖多种 DOM 结构模式）
        alipay_selectors = [
            # 文本匹配（最通用）
            "[class*='payment']:has-text('支付宝')",
            "[class*='method']:has-text('支付宝')",
            "[class*='pay']:has-text('支付宝')",
            "button:has-text('支付宝')",
            "label:has-text('支付宝')",
            "li:has-text('支付宝')",
            # 图标 alt 或 aria-label
            "[aria-label*='支付宝']",
            "[alt='支付宝']",
            # data 属性
            "[data-method='alipay']",
            "[data-payment='alipay']",
            "[data-type='alipay']",
            # 通用含 alipay 关键词的可点击元素
            "[class*='alipay']",
        ]

        for selector in alipay_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=4_000)
                if element:
                    step = ScriptStep(
                        description="选择支付宝扫码支付方式",
                        action="click",
                        selector=selector,
                    )
                    await self._record_step(steps, step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return
            except Exception:
                continue

        # 若支付宝为唯一/默认方式（无需主动选择），静默跳过
        try:
            await page.wait_for_selector("text=支付宝", timeout=2_000)
            await self._record_step(
                steps,
                ScriptStep(
                    description="支付宝已为默认支付方式，无需主动选择",
                    action="wait",
                    selector="text=支付宝",
                )
            )
            return
        except Exception:
            pass

        # Kimi 新版会员页在协议确认后直接展示 “Pay with Alipay / WeChat”
        # 合并二维码；协议弹窗阶段则由下一步 _click_confirm 点击 Continue。
        kimi_default_payment_selectors = (
            "text=Agree to Kimi's Agreements",
            "text=Pay with Alipay / WeChat",
            "text=Use Alipay for large payments",
        )
        for selector in kimi_default_payment_selectors:
            try:
                await page.wait_for_selector(selector, timeout=1_500)
                await self._record_step(
                    steps,
                    ScriptStep(
                        description="Kimi 使用默认支付宝/微信二维码支付方式",
                        action="wait",
                        selector=selector,
                    )
                )
                return
            except Exception:
                continue

        raise ScriptExecutionError(
            "无法定位 Kimi 页面的支付宝支付选项，"
            "页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _click_confirm(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """点击确认充值/去支付按钮。

        Raises:
            ScriptExecutionError: 找不到确认按钮时抛出。
        """
        # 确认充值按钮的候选选择器（中文文案优先）
        confirm_selectors = [
            "button:has-text('Continue')",
            "button:has-text('确认充值')",
            "button:has-text('去支付')",
            "button:has-text('立即充值')",
            "button:has-text('立即支付')",
            "button:has-text('确认支付')",
            "button:has-text('充值')",
            "button:has-text('支付')",
            "button:has-text('Pay')",
            "button:has-text('Confirm')",
            "text=Continue",
            # 通用提交/确认按钮
            "[type='submit']:has-text('充值')",
            "[class*='confirm']:has-text('充值')",
            "[class*='submit'][class*='pay']",
            "[class*='btn-primary']:has-text('充值')",
        ]

        for selector in confirm_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=4_000)
                if element:
                    # 等待按钮可点击（非 disabled 状态）
                    await element.wait_for_element_state("enabled", timeout=_TIMEOUT_MS)
                    step = ScriptStep(
                        description="点击确认充值按钮，触发 Kimi 支付流程",
                        action="click",
                        selector=selector,
                    )
                    await self._record_step(steps, step)
                    if selector in {"button:has-text('Continue')", "text=Continue"}:
                        clicked = await self._click_visible_by_script(
                            page,
                            """
                            () => {
                              const isVisible = (el) => {
                                const r = el.getBoundingClientRect();
                                const s = window.getComputedStyle(el);
                                return r.width > 4 && r.height > 4 &&
                                  r.bottom > 0 && r.right > 0 &&
                                  r.left < window.innerWidth &&
                                  r.top < window.innerHeight &&
                                  s.display !== 'none' &&
                                  s.visibility !== 'hidden' &&
                                  s.opacity !== '0';
                              };
                              const nodes = Array.from(document.querySelectorAll(
                                'button, [role="button"]'
                              ));
                              const target = nodes.find((el) =>
                                isVisible(el) &&
                                (el.innerText || el.textContent || '').trim() === 'Continue'
                              );
                              if (!target) return null;
                              const r = target.getBoundingClientRect();
                              return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
                            }
                            """,
                        )
                        if not clicked:
                            await element.click(timeout=_TIMEOUT_MS)
                    else:
                        await element.click(timeout=_TIMEOUT_MS)
                    await page.wait_for_timeout(2_000)
                    return
            except Exception:
                continue

        raise ScriptExecutionError(
            "未找到 Kimi 充值确认按钮，"
            "页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _wait_for_qr(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """等待支付二维码出现，记录 detect_payment 步骤。

        二维码出现后，检测器将接管并暂停脚本，等待用户扫码。

        Raises:
            ScriptExecutionError: 超时后仍未检测到二维码时抛出。
        """
        # 支付二维码的候选选择器（canvas / img / svg 均有可能）
        qr_selectors = [
            # 二维码图片（src 或 class 含 qr/qrcode 关键词）
            "img[class*='qr']",
            "img[class*='qrcode']",
            "img[alt*='二维码']",
            "img[alt*='qr']",
            # Canvas 渲染的二维码（常见于 qrcode.js）
            "canvas[class*='qr']",
            "canvas[class*='qrcode']",
            # SVG 格式
            "svg[class*='qr']",
            # 包含二维码的容器
            "[class*='qrcode']",
            "[class*='qr-code']",
            "[class*='pay-qr']",
            # 通用弹窗/对话框（支付页面通常以弹窗形式展示）
            "[class*='modal']:has(img)",
            "[class*='dialog']:has(img)",
            "[class*='popup']:has(img)",
            # Kimi 可能使用的支付弹窗类名
            "[class*='pay-dialog']",
            "[class*='recharge-modal']",
            # Kimi 新版会员收银台：二维码图片没有稳定 qr class，但弹窗文案稳定。
            "text=Pay with Alipay / WeChat",
            "text=Use Alipay for large payments",
        ]

        qr_selector_found: str | None = None
        for selector in qr_selectors:
            try:
                await page.wait_for_selector(selector, timeout=8_000)
                qr_selector_found = selector
                break
            except Exception:
                continue

        if qr_selector_found is None:
            raise ScriptExecutionError(
                "等待 Kimi 支付二维码超时，未在页面上检测到二维码元素，"
                "触发 Skyvern 回退以智能定位二维码。"
            )

        # 记录 detect_payment 步骤，通知检测器接管
        await self._record_step(
            steps,
            ScriptStep(
                description="检测到支付宝二维码（Kimi），等待用户扫码完成充值",
                action="detect_payment",
                selector=qr_selector_found,
            )
        )
