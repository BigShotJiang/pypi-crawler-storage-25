"""Stripe 支付通道适配器。

Stripe 与其他浏览器自动化适配器不同，它直接调用 Stripe REST API 创建 hosted checkout session，
不需要 Playwright 浏览器。用户通过返回的 URL 或二维码完成支付。

执行流程：
1. 调用 Stripe API 创建 checkout session
2. 返回 session URL（用户扫码或点击链接）
3. Webhook 监听 checkout.session.completed 事件更新交易状态

使用示例::

    payswitch spend 10 --method stripe --currency usd --product-name "API Credits"
"""

from __future__ import annotations

import logging
import os
from datetime import UTC, datetime
from typing import Any

from payswitch.adapters import AdapterRegistry
from payswitch.adapters.base import ScriptExecutionError, ScriptStep, SiteAdapter
from payswitch.models.types import PaymentMethod

logger = logging.getLogger(__name__)

# Stripe SDK 是可选依赖，只在用户安装 payswitch[stripe] 时可用
try:
    import stripe
    _STRIPE_AVAILABLE = True
except ImportError:
    _STRIPE_AVAILABLE = False
    logger.warning(
        "Stripe SDK 未安装，Stripe 适配器不可用。请运行：uv add stripe 或 pip install stripe"
    )


@AdapterRegistry.register
class StripeAdapter(SiteAdapter):
    """Stripe hosted checkout 适配器。

    不需要浏览器自动化，直接调用 Stripe API 创建支付会话。
    用户通过返回的 URL 完成支付，webhook 监听支付完成事件。
    """

    name = "stripe"
    display_name = "Stripe"
    top_up_url = "https://checkout.stripe.com"  # Stripe checkout 基础 URL
    login_url = ""  # Stripe 不需要登录
    supported_methods = [PaymentMethod.stripe, PaymentMethod.bankcard]

    def __init__(self) -> None:
        """初始化 Stripe 适配器，从环境变量或配置加载 API Key。"""
        super().__init__()

        if not _STRIPE_AVAILABLE:
            raise ScriptExecutionError(
                "Stripe SDK 未安装。"
                "请运行：uv pip install 'payswitch[stripe]' 或 pip install stripe"
            )

        # 从环境变量读取 Stripe Secret Key（优先级最高）
        self.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
        if not self.api_key:
            # 尝试从 PaySwitch 配置读取
            from payswitch.models.config import PaySwitchConfig
            config = PaySwitchConfig.load()
            self.api_key = config.get_stripe_secret_key()

        if not self.api_key:
            logger.warning(
                "Stripe Secret Key 未配置。请设置环境变量 STRIPE_SECRET_KEY "
                "或运行 payswitch settings stripe 配置。"
            )
        else:
            stripe.api_key = self.api_key
            logger.debug("Stripe API Key 已加载")

    async def execute_topup(
        self,
        page: Any,  # Stripe 不需要浏览器，此参数为兼容基类签名
        amount: float,
        method: PaymentMethod | None = None,
        currency: str = "usd",
        product_name: str | None = None,
        **kwargs: Any,
    ) -> list[ScriptStep]:
        """创建 Stripe checkout session 并返回支付 URL。

        Args:
            page: Playwright Page 对象（Stripe 不使用，保留以兼容基类）
            amount: 支付金额（单位由 currency 决定，如 USD 为美元）
            method: 支付方式（Stripe 忽略此参数）
            currency: ISO 4217 货币代码（usd/cny/hkd 等），默认 usd
            product_name: 商品描述，用于 Stripe checkout 页面展示
            **kwargs: 其他可选参数（如 success_url, cancel_url）

        Returns:
            包含 checkout session URL 的 ScriptStep 列表

        Raises:
            ScriptExecutionError: Stripe API 调用失败或配置错误
        """
        if not _STRIPE_AVAILABLE:
            raise ScriptExecutionError("Stripe SDK 未安装")

        if not self.api_key:
            raise ScriptExecutionError(
                "Stripe Secret Key 未配置。请设置环境变量 STRIPE_SECRET_KEY "
                "或运行 payswitch settings stripe 配置 API Key。"
            )

        steps: list[ScriptStep] = []

        # 验证金额
        if amount <= 0:
            raise ScriptExecutionError(f"支付金额必须大于 0，当前值：{amount}")

        # Stripe 金额单位为最小货币单位（如美元的 cents）
        # amount 参数是用户输入的主货币单位（如 10.00 美元）
        # 需要转换为 cents（1000）
        amount_cents = int(amount * 100)

        # 商品名称默认值
        if not product_name:
            product_name = f"Pay-Switch 支付 - {amount} {currency.upper()}"

        # 记录创建 session 步骤
        create_step = ScriptStep(
            description=f"创建 Stripe checkout session（金额：{amount} {currency.upper()}）",
            action="api_call",
            url=None,
        )
        steps.append(create_step)

        try:
            # 调用 Stripe API 创建 checkout session
            logger.info(
                "创建 Stripe checkout session：amount=%d %s, product=%s",
                amount_cents, currency.upper(), product_name
            )

            session = stripe.checkout.Session.create(
                payment_method_types=["card"],  # 支持信用卡/借记卡
                line_items=[
                    {
                        "price_data": {
                            "currency": currency.lower(),
                            "product_data": {
                                "name": product_name,
                            },
                            "unit_amount": amount_cents,
                        },
                        "quantity": 1,
                    }
                ],
                mode="payment",  # 一次性支付（非订阅）
                # 成功/取消回调 URL（可从 kwargs 读取，或使用默认值）
                success_url=kwargs.get("success_url", "https://payswitch.local/success"),
                cancel_url=kwargs.get("cancel_url", "https://payswitch.local/cancel"),
                # 元数据：记录 Pay-Switch 交易 ID，用于 webhook 关联
                metadata={
                    "payswitch_tx_id": kwargs.get("tx_id", ""),
                    "payswitch_amount": str(amount),
                    "payswitch_currency": currency.upper(),
                    "created_by": "payswitch",
                },
                # 自动失效时间（24 小时）
                expires_at=int(datetime.now(UTC).timestamp() + 86400),
            )

            checkout_url = session.url
            session_id = session.id

            logger.info(
                "Stripe checkout session 已创建：session_id=%s, url=%s",
                session_id, checkout_url
            )

            # 记录成功步骤
            success_step = ScriptStep(
                description=f"Stripe checkout session 已创建（ID: {session_id}）",
                action="payment_url_ready",
                url=checkout_url,
            )
            steps.append(success_step)

            # 添加等待支付步骤（类似扫码等待）
            wait_step = ScriptStep(
                description="等待用户在 Stripe checkout 页面完成支付",
                action="detect_payment",
            )
            steps.append(wait_step)

            return steps

        except stripe.error.StripeError as exc:
            # Stripe API 错误
            error_msg = f"Stripe API 调用失败：{type(exc).__name__}: {exc}"
            logger.error(error_msg)
            raise ScriptExecutionError(error_msg) from exc

        except Exception as exc:
            # 其他未预期错误
            error_msg = f"创建 Stripe checkout session 时发生异常：{type(exc).__name__}: {exc}"
            logger.exception(error_msg)
            raise ScriptExecutionError(error_msg) from exc

    async def validate_amount(self, amount: float) -> bool:
        """验证金额是否在 Stripe 支持的范围内。

        Stripe 最小金额因货币而异，如 USD 最小 0.50 美元。

        Args:
            amount: 待验证的金额

        Returns:
            True 表示金额合法，False 表示不合法
        """
        # 简化验证：金额必须 > 0 且不超过合理上限（避免用户误输入）
        return 0 < amount < 1_000_000

    def get_checkout_url(self) -> str:
        """获取 Stripe checkout 基础 URL。

        Returns:
            Stripe checkout URL
        """
        return self.top_up_url
