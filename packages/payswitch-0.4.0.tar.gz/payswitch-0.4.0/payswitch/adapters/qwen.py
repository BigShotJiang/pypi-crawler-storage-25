"""通义千问（Qwen / 阿里云百炼）平台充值适配器。

封装通义千问开放平台（tongyi.aliyun.com / bailian.aliyun.com）充值页的
完整操作流程，支持支付宝扫码支付。当页面结构发生变更导致选择器失效时，
会抛出 ScriptExecutionError，由上层引擎自动回退至 Skyvern 智能模式。

注意：
- 通义千问的充值入口可能在阿里云控制台或百炼平台，此处以通义千问官网为主
- 阿里系产品常使用支付宝作为默认支付方式，无需额外选择
- 选择器基于合理推断，实际以页面为准，Skyvern 为兜底保障
"""

from __future__ import annotations

from typing import Any

from payswitch.adapters import AdapterRegistry
from payswitch.adapters.base import ScriptExecutionError, ScriptStep, SiteAdapter
from payswitch.experience import ExperienceRecipe
from payswitch.experience.registry import get_recipe
from payswitch.experience.runner import RecipeExecutionError, RecipeRunContext, RecipeRunner
from payswitch.experience.store import ExperienceStore
from payswitch.models.types import PaymentMethod, StepCategory, StepRisk

# 通义千问平台预设充值套餐（人民币元），按从小到大排列
# 阿里云 Token 充值通常以较大面额为主，此列表为合理推断
_PRESET_AMOUNTS: list[float] = [10, 20, 50, 100, 200, 500, 1000, 2000]

# Playwright 操作默认超时（毫秒）
_TIMEOUT_MS = 15_000


def _find_closest_preset(amount: float) -> float:
    """从预设套餐中找到与目标金额最接近的面值。

    Args:
        amount: 用户期望的充值金额（人民币元）。

    Returns:
        与 amount 差值绝对值最小的预设金额；若差值相同，优先返回较大金额。
    """
    return min(_PRESET_AMOUNTS, key=lambda p: (abs(p - amount), -p))


@AdapterRegistry.register
class QwenAdapter(SiteAdapter):
    """通义千问（Qwen）平台充值适配器。

    支持通过支付宝扫码完成人民币充值。执行流程：
    1. 导航到充值页（通义千问 / 百炼平台）
    2. 选择预设套餐金额（优先精确匹配，次选最接近面值）
    3. 若无预设匹配，尝试填写自定义金额
    4. 选择支付宝支付方式（阿里系默认支付宝，通常已预选）
    5. 点击确认充值，等待二维码或跳转支付宝页面
    6. 返回 detect_payment 步骤，由检测器暂停并引导用户扫码

    选择器失效时抛出 ScriptExecutionError，触发 Skyvern 智能模式回退。
    """

    name = "qwen"
    display_name = "通义千问 (Qwen)"
    # 通义千问充值页 URL（基于合理推断，实际以官方为准）
    # 备选：https://bailian.aliyun.com/ （百炼平台，API 充值通道）
    top_up_url = "https://tongyi.aliyun.com/recharge"
    login_url = "https://tongyi.aliyun.com"
    supported_methods = [PaymentMethod.alipay_qr]
    recipe_flow = "topup_alipay_qr"

    @property
    def recipe(self) -> ExperienceRecipe:
        recipe = get_recipe(self.name, self.recipe_flow, store=self.recipe_store)
        if recipe is None:
            raise RuntimeError("Qwen experience recipe is not registered")
        return recipe

    async def validate_amount(self, amount: float) -> bool:
        """通义千问最低充值金额为 10 元。"""
        return amount >= 10

    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        """执行通义千问充值完整脚本。

        Args:
            page: Playwright Page 对象。
            amount: 充值金额（人民币元，须 >= 10）。
            method: 指定支付方式；None 时默认使用支付宝扫码。

        Returns:
            按执行顺序排列的 ScriptStep 列表。

        Raises:
            ScriptExecutionError: 任意步骤无法定位元素或操作超时时抛出。
        """
        steps: list[ScriptStep] = []
        recipe = self.recipe

        async def record_step(step: ScriptStep) -> None:
            await self._record_step(steps, step)

        runner = RecipeRunner(
            recipe=recipe,
            semantic_actions={
                "ensure_logged_in": self._recipe_ensure_logged_in,
                "select_amount": self._recipe_select_amount,
                "select_payment_method": self._recipe_select_payment_method,
                "click_confirm": self._recipe_click_confirm,
                "wait_for_qr": self._recipe_wait_for_qr,
            },
            telemetry_callback=self.telemetry_callback,
            policy_checkpoint_callback=self._recipe_policy_checkpoint,
            evidence_dir=self.recipe_evidence_dir,
            artifact_store=self.recipe_artifact_store,
            screenshot_budget=self.recipe_screenshot_budget,
        )

        try:
            await runner.run(
                page=page,
                amount=amount,
                method=method,
                steps=steps,
                record_step=record_step,
            )
        except RecipeExecutionError as exc:
            store = self._experience_store()
            if store is not None:
                store.record_outcome(
                    platform=self.name,
                    flow=recipe.flow,
                    recipe_id=recipe.recipe_id,
                    recipe_version=recipe.version,
                    succeeded=False,
                    confidence=recipe.confidence,
                    details=exc.failure_context,
                )
            raise ScriptExecutionError(
                str(exc),
                failure_context=exc.failure_context,
            ) from exc

        store = self._experience_store()
        if store is not None:
            store.record_outcome(
                platform=self.name,
                flow=recipe.flow,
                recipe_id=recipe.recipe_id,
                recipe_version=recipe.version,
                succeeded=True,
                confidence=recipe.confidence,
                details={
                    "step_count": len(steps),
                    "current_url": str(getattr(page, "url", "")),
                },
            )

        return steps

    # ------------------------------------------------------------------
    # 私有辅助方法
    # ------------------------------------------------------------------

    async def check_login_state(self, page: Any) -> tuple[bool, str | None]:
        current_url = page.url.lower()
        login_indicators = [
            "login.aliyun.com",
            "account.aliyun.com",
            "auth.aliyun.com",
            "signin",
            "login",
            "sign_in",
        ]
        if any(indicator in current_url for indicator in login_indicators):
            return (
                False,
                "检测到未登录状态，请先执行 'payswitch login qwen' 完成阿里云账号登录。"
                f"当前 URL：{page.url}",
            )
        return True, None

    def _experience_store(self) -> ExperienceStore | None:
        store = getattr(self, "recipe_store", None)
        if isinstance(store, ExperienceStore):
            return store
        return None

    async def _recipe_ensure_logged_in(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)

    async def _recipe_select_amount(self, context: RecipeRunContext) -> None:
        amount_selected = await self._select_amount(context.page, context.amount, context.steps)
        if not amount_selected:
            await self._fill_custom_amount(context.page, context.amount, context.steps)

    async def _recipe_select_payment_method(self, context: RecipeRunContext) -> None:
        await self._select_payment_method(context.page, context.steps)

    async def _recipe_click_confirm(self, context: RecipeRunContext) -> None:
        await self._click_confirm(context.page, context.steps)

    async def _recipe_wait_for_qr(self, context: RecipeRunContext) -> None:
        await self._wait_for_qr(context.page, context.steps)

    async def _recipe_policy_checkpoint(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)
        if context.waypoint.id != "confirm_topup_checkout":
            return

        visible_text = await self._visible_text_snapshot(context.page)
        required_markers = [
            *context.recipe.texts.get("topup_ready", []),
            *context.recipe.texts.get("payment_surface", []),
            "确认充值",
            "去支付",
        ]
        if any(marker in visible_text for marker in required_markers):
            return
        raise RuntimeError(
            "policy checkpoint blocked confirm_topup_checkout: "
            "missing visible Qwen payment markers"
        )

    async def _select_amount(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> bool:
        """尝试在预设套餐列表中点击匹配的金额按钮。

        先尝试精确匹配，再尝试最接近的预设面值。

        Returns:
            True 表示成功点击了某个预设按钮；False 表示未找到任何预设按钮。
        """
        # 通义千问充值页套餐金额按钮的候选选择器策略（按优先级排列）
        # 阿里云系产品常用 ant-design 或阿里云自研组件库，class 命名有规律
        amount_button_selectors = [
            # 策略 A：包含人民币符号和数字的按钮
            f"button:has-text('¥{amount:.0f}')",
            f"button:has-text('¥ {amount:.0f}')",
            f"button:has-text('{amount:.0f}元')",
            f"button:has-text('{amount:.0f} 元')",
            # 策略 B：套餐卡片，常见 class 含 amount/package/recharge/token 关键词
            f"[class*='amount']:has-text('{amount:.0f}')",
            f"[class*='package']:has-text('{amount:.0f}')",
            f"[class*='recharge']:has-text('{amount:.0f}')",
            f"[class*='quota']:has-text('{amount:.0f}')",
            # 策略 C：阿里云 ant-design 卡片或 Radio 选项
            f".ant-card:has-text('{amount:.0f}')",
            f".ant-radio-wrapper:has-text('{amount:.0f}')",
            f".ant-checkbox-wrapper:has-text('{amount:.0f}')",
            # 策略 D：data 属性匹配
            f"[data-amount='{amount:.0f}']",
            f"[data-value='{amount:.0f}']",
            f"[data-price='{amount:.0f}']",
        ]

        # 尝试精确金额匹配
        for selector in amount_button_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if element:
                    step = ScriptStep(
                        description=f"点击预设套餐金额 ¥{amount:.0f}",
                        action="click",
                        selector=selector,
                    )
                    steps.append(step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return True
            except Exception:
                # 选择器未命中，继续尝试下一个
                continue

        # 精确匹配失败，尝试最接近的预设金额
        closest = _find_closest_preset(amount)
        if closest != amount:
            closest_selectors = [
                f"button:has-text('¥{closest:.0f}')",
                f"button:has-text('¥ {closest:.0f}')",
                f"button:has-text('{closest:.0f}元')",
                f"[class*='amount']:has-text('{closest:.0f}')",
                f"[class*='package']:has-text('{closest:.0f}')",
                f".ant-card:has-text('{closest:.0f}')",
                f"[data-amount='{closest:.0f}']",
            ]
            for selector in closest_selectors:
                try:
                    element = await page.wait_for_selector(selector, timeout=3_000)
                    if element:
                        step = ScriptStep(
                            description=(
                                f"精确金额 ¥{amount:.0f} 无匹配套餐，"
                                f"改选最接近预设金额 ¥{closest:.0f}"
                            ),
                            action="click",
                            selector=selector,
                        )
                        steps.append(step)
                        await element.click(timeout=_TIMEOUT_MS)
                        return True
                except Exception:
                    continue

        return False

    async def _fill_custom_amount(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> None:
        """在自定义金额输入框中填写目标金额。

        Raises:
            ScriptExecutionError: 找不到自定义金额输入框时抛出。
        """
        # 自定义金额输入框的候选选择器（阿里云 ant-design input 为主）
        custom_input_selectors = [
            "input[placeholder*='自定义']",
            "input[placeholder*='金额']",
            "input[placeholder*='请输入']",
            "input[placeholder*='充值']",
            "input[placeholder*='其他金额']",
            # ant-design input 组件
            ".ant-input[type='number']",
            ".ant-input[type='text']",
            # 充值区域内的数字输入框
            "[class*='recharge'] input[type='number']",
            "[class*='amount'] input[type='number']",
            "form input[type='number']",
        ]

        for selector in custom_input_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if element:
                    # 先点击激活输入框，清空已有内容，再填入金额
                    await element.click(timeout=_TIMEOUT_MS)
                    await element.fill("", timeout=_TIMEOUT_MS)
                    amount_str = str(int(amount)) if amount == int(amount) else str(amount)
                    await element.fill(amount_str, timeout=_TIMEOUT_MS)

                    step = ScriptStep(
                        description=f"在自定义金额输入框中填写 {amount_str} 元",
                        action="fill",
                        selector=selector,
                        value=amount_str,
                    )
                    steps.append(step)
                    return
            except Exception:
                continue

        # 所有选择器均失败，触发 Skyvern 回退
        raise ScriptExecutionError(
            f"未找到预设套餐金额 ¥{amount:.0f} 的按钮，"
            "且自定义金额输入框也无法定位，"
            "通义千问页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _select_payment_method(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """选择支付宝支付方式。

        阿里系产品默认使用支付宝，若页面已默认选中则静默跳过。

        Raises:
            ScriptExecutionError: 找不到支付宝选项且页面无支付宝标识时抛出。
        """
        # 支付宝选项的候选选择器（覆盖阿里云 ant-design 和通义千问自研组件）
        alipay_selectors = [
            # 文本匹配（最通用）
            "[class*='payment']:has-text('支付宝')",
            "[class*='method']:has-text('支付宝')",
            "[class*='pay']:has-text('支付宝')",
            "button:has-text('支付宝')",
            "label:has-text('支付宝')",
            "li:has-text('支付宝')",
            # ant-design Radio 组件中的支付宝选项
            ".ant-radio-wrapper:has-text('支付宝')",
            ".ant-radio-button-wrapper:has-text('支付宝')",
            # 图标 alt 或 aria-label
            "[aria-label*='支付宝']",
            "[alt='支付宝']",
            # data 属性
            "[data-method='alipay']",
            "[data-payment='alipay']",
            "[data-type='alipay']",
            # 通用含 alipay 关键词的可点击元素
            "[class*='alipay']",
        ]

        for selector in alipay_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=4_000)
                if element:
                    step = ScriptStep(
                        description="选择支付宝扫码支付方式",
                        action="click",
                        selector=selector,
                    )
                    steps.append(step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return
            except Exception:
                continue

        # 阿里系产品通常默认支付宝，检测页面是否已有支付宝标识
        try:
            await page.wait_for_selector("text=支付宝", timeout=2_000)
            steps.append(
                ScriptStep(
                    description="支付宝已为默认支付方式（阿里系产品），无需主动选择",
                    action="wait",
                    selector="text=支付宝",
                )
            )
            return
        except Exception:
            pass

        raise ScriptExecutionError(
            "无法定位通义千问页面的支付宝支付选项，"
            "页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _click_confirm(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """点击确认充值/去支付按钮。

        Raises:
            ScriptExecutionError: 找不到确认按钮时抛出。
        """
        await self._enforce_synchronous_policy_checkpoint(
            page,
            checkpoint_id="confirm_qwen_checkout",
            marker_groups=[
                (
                    "支付宝",
                    "Alipay",
                    "支付方式",
                    "确认充值",
                    "去支付",
                    "立即充值",
                    "立即支付",
                    "确认支付",
                    "Pay",
                )
            ],
            extra_context={"payment_method": PaymentMethod.alipay_qr.value},
        )

        # 确认充值按钮的候选选择器（中文文案优先，兼顾 ant-design 主按钮）
        confirm_selectors = [
            "button:has-text('确认充值')",
            "button:has-text('去支付')",
            "button:has-text('立即充值')",
            "button:has-text('立即支付')",
            "button:has-text('确认支付')",
            "button:has-text('充值')",
            "button:has-text('支付')",
            "button:has-text('Pay')",
            # ant-design 主按钮（蓝色大按钮通常是主操作）
            ".ant-btn-primary:has-text('充值')",
            ".ant-btn-primary:has-text('支付')",
            # 通用提交按钮
            "[type='submit']:has-text('充值')",
            "[class*='confirm']:has-text('充值')",
            "[class*='submit'][class*='pay']",
        ]

        for selector in confirm_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=4_000)
                if element:
                    # 等待按钮可点击（非 disabled 状态）
                    await element.wait_for_element_state("enabled", timeout=_TIMEOUT_MS)
                    step = ScriptStep(
                        description="点击确认充值按钮，触发通义千问支付流程",
                        action="click",
                        selector=selector,
                        category=StepCategory.final_authorization,
                        risk=StepRisk.high,
                    )
                    steps.append(step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return
            except Exception:
                continue

        raise ScriptExecutionError(
            "未找到通义千问充值确认按钮，"
            "页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _wait_for_qr(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """等待支付二维码出现，记录 detect_payment 步骤。

        阿里云支付有两种模式：
        1. 页面内嵌二维码（canvas/img）
        2. 跳转至支付宝 H5 页面（URL 变化）

        Raises:
            ScriptExecutionError: 超时后仍未检测到二维码时抛出。
        """
        # 支付二维码的候选选择器（覆盖多种渲染方式）
        qr_selectors = [
            # 二维码图片（src 或 class 含 qr/qrcode 关键词）
            "img[class*='qr']",
            "img[class*='qrcode']",
            "img[alt*='二维码']",
            "img[alt*='qr']",
            # Canvas 渲染的二维码（常见于 qrcode.js）
            "canvas[class*='qr']",
            "canvas[class*='qrcode']",
            # SVG 格式
            "svg[class*='qr']",
            # 包含二维码的容器
            "[class*='qrcode']",
            "[class*='qr-code']",
            "[class*='pay-qr']",
            # 阿里云 ant-design 弹窗（支付通常以 Modal 形式展示）
            ".ant-modal:has(img)",
            ".ant-modal-body:has(img)",
            # 通用弹窗
            "[class*='modal']:has(img)",
            "[class*='dialog']:has(img)",
            "[class*='popup']:has(img)",
            # 阿里云支付相关 class
            "[class*='alipay-qr']",
            "[class*='payment-qr']",
        ]

        qr_selector_found: str | None = None
        for selector in qr_selectors:
            try:
                await page.wait_for_selector(selector, timeout=8_000)
                qr_selector_found = selector
                break
            except Exception:
                continue

        # 检查是否跳转至支付宝网页（URL 变化也视为进入支付环节）
        if qr_selector_found is None:
            current_url: str = page.url
            if "alipay.com" in current_url or "pay" in current_url.lower():
                # 跳转至支付宝页面，记录特殊步骤后返回
                steps.append(
                    ScriptStep(
                        description="已跳转至支付宝支付页面，等待用户完成扫码或确认",
                        action="detect_payment",
                        url=current_url,
                    )
                )
                return

            raise ScriptExecutionError(
                "等待通义千问支付二维码超时，未在页面上检测到二维码元素，"
                "触发 Skyvern 回退以智能定位二维码。"
            )

        # 记录 detect_payment 步骤，通知检测器接管
        steps.append(
            ScriptStep(
                description="检测到支付宝二维码（通义千问），等待用户扫码完成充值",
                action="detect_payment",
                selector=qr_selector_found,
            )
        )
