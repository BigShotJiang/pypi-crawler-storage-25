"""Volcano Engine payment adapter.

This adapter targets the Volcano Engine finance recharge path. It stops at
the payment handoff state and keeps QR scan, bank authentication, password,
OTP, CAPTCHA, and final payment confirmation as human-gated actions.
"""

from __future__ import annotations

from typing import Any

from payswitch.adapters import AdapterRegistry
from payswitch.adapters.base import ScriptExecutionError, ScriptStep, SiteAdapter
from payswitch.experience import ExperienceRecipe
from payswitch.experience.registry import get_recipe
from payswitch.experience.runner import RecipeExecutionError, RecipeRunContext, RecipeRunner
from payswitch.experience.store import ExperienceStore
from payswitch.models.types import PaymentMethod, StepCategory, StepRisk

_TIMEOUT_MS = 15_000
_MIN_AMOUNT = 1.0


def _amount_text(amount: float) -> str:
    return str(int(amount)) if amount == int(amount) else str(amount)


@AdapterRegistry.register
class VolcanoAdapter(SiteAdapter):
    """Adapter for Volcano Engine account or Ark recharge."""

    name = "volcano"
    display_name = "Volcano Engine"
    top_up_url = "https://console.volcengine.com/finance/fund/recharge"
    login_url = "https://console.volcengine.com"
    supported_methods = [
        PaymentMethod.alipay_qr,
        PaymentMethod.wechat_qr,
        PaymentMethod.bankcard,
    ]
    recipe_flow = "topup_alipay_qr"

    @property
    def recipe(self) -> ExperienceRecipe:
        recipe = get_recipe(self.name, self.recipe_flow, store=self.recipe_store)
        if recipe is None:
            raise RuntimeError("Volcano experience recipe is not registered")
        return recipe

    async def validate_amount(self, amount: float) -> bool:
        return amount >= _MIN_AMOUNT

    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        if not await self.validate_amount(amount):
            raise ScriptExecutionError(f"volcano amount must be >= {_MIN_AMOUNT:g}")

        steps: list[ScriptStep] = []
        recipe = self.recipe

        async def record_step(step: ScriptStep) -> None:
            await self._record_step(steps, step)

        runner = RecipeRunner(
            recipe=recipe,
            semantic_actions={
                "ensure_logged_in": self._recipe_ensure_logged_in,
                "select_amount": self._recipe_select_amount,
                "click_next": self._recipe_click_next,
                "select_payment_method": self._recipe_select_payment_method,
                "click_confirm": self._recipe_click_confirm,
                "wait_for_qr": self._recipe_wait_for_qr,
            },
            telemetry_callback=self.telemetry_callback,
            policy_checkpoint_callback=self._recipe_policy_checkpoint,
            evidence_dir=self.recipe_evidence_dir,
            artifact_store=self.recipe_artifact_store,
            screenshot_budget=self.recipe_screenshot_budget,
        )

        try:
            await runner.run(
                page=page,
                amount=amount,
                method=method,
                steps=steps,
                record_step=record_step,
            )
        except RecipeExecutionError as exc:
            store = self._experience_store()
            if store is not None:
                store.record_outcome(
                    platform=self.name,
                    flow=recipe.flow,
                    recipe_id=recipe.recipe_id,
                    recipe_version=recipe.version,
                    succeeded=False,
                    confidence=recipe.confidence,
                    details=exc.failure_context,
                )
            raise ScriptExecutionError(
                str(exc),
                failure_context=exc.failure_context,
            ) from exc

        store = self._experience_store()
        if store is not None:
            store.record_outcome(
                platform=self.name,
                flow=recipe.flow,
                recipe_id=recipe.recipe_id,
                recipe_version=recipe.version,
                succeeded=True,
                confidence=recipe.confidence,
                details={
                    "step_count": len(steps),
                    "current_url": str(getattr(page, "url", "")),
                },
            )

        return steps

    async def check_login_state(self, page: Any) -> tuple[bool, str | None]:
        current_url = str(getattr(page, "url", "")).lower()
        if any(signal in current_url for signal in ("login", "signin", "passport", "auth")):
            return False, (
                "Volcano profile is not authenticated. Run "
                "'payswitch login volcano' and complete login in the browser."
            )

        login_selectors = (
            "text=Log in",
            "text=Login",
            "text=Sign in",
            "text=\u767b\u5f55",
            "text=\u767b\u9304",
        )
        for selector in login_selectors:
            try:
                if await page.locator(selector).count() > 0:
                    return False, (
                        "Volcano login prompt is visible. Run "
                        "'payswitch login volcano' and complete login in the browser."
                    )
            except Exception:
                continue
        return True, None

    def _experience_store(self) -> ExperienceStore | None:
        store = getattr(self, "recipe_store", None)
        if isinstance(store, ExperienceStore):
            return store
        return None

    async def _recipe_ensure_logged_in(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)

    async def _recipe_select_amount(self, context: RecipeRunContext) -> None:
        await self._select_amount(context.page, context.amount, context.steps)

    async def _recipe_click_next(self, context: RecipeRunContext) -> None:
        await self._click_next(context.page, context.steps)

    async def _recipe_select_payment_method(self, context: RecipeRunContext) -> None:
        await self._select_payment_method(
            context.page,
            context.method or PaymentMethod.alipay_qr,
            context.steps,
        )

    async def _recipe_click_confirm(self, context: RecipeRunContext) -> None:
        await self._click_pay(
            context.page,
            context.steps,
            context.method or PaymentMethod.alipay_qr,
        )

    async def _recipe_wait_for_qr(self, context: RecipeRunContext) -> None:
        await self._wait_for_human_payment_gate(context.page, context.steps)

    async def _recipe_policy_checkpoint(self, context: RecipeRunContext) -> None:
        await self.ensure_logged_in(context.page)
        if context.waypoint.id != "confirm_topup_checkout":
            return

        visible_text = await self._visible_text_snapshot(context.page)
        required_markers = [
            *context.recipe.texts.get("topup_ready", []),
            *context.recipe.texts.get("payment_surface", []),
            "去支付",
            "确认订单",
        ]
        if any(marker in visible_text for marker in required_markers):
            return
        raise RuntimeError(
            "policy checkpoint blocked confirm_topup_checkout: "
            "missing visible Volcano payment markers"
        )

    async def _navigate(self, page: Any, steps: list[ScriptStep]) -> None:
        steps.append(
            ScriptStep(
                description="Navigate to Volcano Engine recharge",
                action="navigate",
                url=self.top_up_url,
            )
        )
        try:
            await page.goto(self.top_up_url, wait_until="domcontentloaded", timeout=_TIMEOUT_MS)
            try:
                await page.wait_for_load_state("networkidle", timeout=_TIMEOUT_MS)
            except Exception:
                pass
        except Exception as exc:
            raise ScriptExecutionError(f"failed to open Volcano recharge: {exc}") from exc

    async def _select_amount(self, page: Any, amount: float, steps: list[ScriptStep]) -> None:
        amount_value = _amount_text(amount)
        selectors = (
            "input[type='number']",
            "input[inputmode='numeric']",
            "input[placeholder*='\u91d1\u989d']",
            "input[placeholder*='\u5145\u503c']",
            f"button:has-text('{amount_value}')",
            f"label:has-text('{amount_value}')",
            f"[class*='amount']:has-text('{amount_value}')",
            f"[class*='price']:has-text('{amount_value}')",
            f"[data-amount='{amount_value}']",
            f"[data-price='{amount_value}']",
        )
        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if not element:
                    continue
                if selector.startswith("input"):
                    await element.click(timeout=_TIMEOUT_MS)
                    await element.fill(amount_value, timeout=_TIMEOUT_MS)
                    action = "fill"
                else:
                    await element.click(timeout=_TIMEOUT_MS)
                    action = "click"
                steps.append(
                    ScriptStep(
                        description=f"Set Volcano recharge amount {amount_value}",
                        action=action,
                        selector=selector,
                        value=amount_value if action == "fill" else None,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                return
            except Exception:
                continue
        raise ScriptExecutionError(f"Volcano amount field was not found for {amount_value}")

    async def _click_next(self, page: Any, steps: list[ScriptStep]) -> None:
        selectors = (
            "button:has-text('\u4e0b\u4e00\u6b65')",
            "button:has-text('\u786e\u5b9a')",
            "button:has-text('\u63d0\u4ea4')",
            "button:has-text('Next')",
            "button:has-text('Continue')",
            ".arco-btn-primary",
            ".ant-btn-primary",
        )
        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if not element:
                    continue
                await element.click(timeout=_TIMEOUT_MS)
                steps.append(
                    ScriptStep(
                        description="Continue from Volcano amount page",
                        action="click",
                        selector=selector,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=_TIMEOUT_MS)
                except Exception:
                    pass
                return
            except Exception:
                continue
        raise ScriptExecutionError("Volcano next/submit button was not found")

    async def _select_payment_method(
        self,
        page: Any,
        method: PaymentMethod,
        steps: list[ScriptStep],
    ) -> None:
        if method == PaymentMethod.wechat_qr:
            selectors = (
                "button:has-text('\u5fae\u4fe1')",
                "label:has-text('\u5fae\u4fe1')",
                "[class*='wechat']",
                "[data-method='wechat']",
                "[data-payment='wechat']",
            )
            method_name = "WeChat Pay"
        elif method == PaymentMethod.bankcard:
            selectors = (
                "button:has-text('\u7f51\u94f6')",
                "label:has-text('\u7f51\u94f6')",
                "button:has-text('\u94f6\u884c')",
                "label:has-text('\u94f6\u884c')",
                "[class*='bank']",
                "[data-method='bank']",
                "[data-payment='bank']",
            )
            method_name = "bank card / online banking"
        else:
            selectors = (
                "button:has-text('\u652f\u4ed8\u5b9d')",
                "label:has-text('\u652f\u4ed8\u5b9d')",
                "[class*='alipay']",
                "[data-method='alipay']",
                "[data-payment='alipay']",
            )
            method_name = "Alipay"

        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if not element:
                    continue
                await element.click(timeout=_TIMEOUT_MS)
                steps.append(
                    ScriptStep(
                        description=f"Select Volcano payment method: {method_name}",
                        action="click",
                        selector=selector,
                        category=StepCategory.checkout_prep,
                        risk=StepRisk.medium,
                    )
                )
                return
            except Exception:
                continue

        steps.append(
            ScriptStep(
                description=f"Volcano payment method assumed/defaulted: {method_name}",
                action="wait",
                category=StepCategory.checkout_prep,
                risk=StepRisk.medium,
            )
        )

    async def _click_pay(
        self,
        page: Any,
        steps: list[ScriptStep],
        method: PaymentMethod = PaymentMethod.alipay_qr,
    ) -> None:
        method_markers = {
            PaymentMethod.wechat_qr: ("微信", "WeChat"),
            PaymentMethod.bankcard: ("网银", "银行", "Bank"),
            PaymentMethod.alipay_qr: ("支付宝", "Alipay"),
        }.get(method, ("支付",))
        await self._enforce_synchronous_policy_checkpoint(
            page,
            checkpoint_id="confirm_volcano_checkout",
            marker_groups=[
                (
                    *method_markers,
                    "去支付",
                    "确认订单",
                    "提交订单",
                    "下一步",
                    "支付方式",
                    "Pay",
                )
            ],
            extra_context={"payment_method": method.value},
        )

        selectors = (
            "button:has-text('\u53bb\u652f\u4ed8')",
            "button:has-text('\u786e\u8ba4\u8ba2\u5355')",
            "button:has-text('\u63d0\u4ea4\u8ba2\u5355')",
            "button:has-text('\u4e0b\u4e00\u6b65')",
            "button:has-text('Pay')",
            "[type='submit']",
            ".arco-btn-primary",
            ".ant-btn-primary",
        )
        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if not element:
                    continue
                await element.click(timeout=_TIMEOUT_MS)
                steps.append(
                    ScriptStep(
                        description="Prepare Volcano payment handoff",
                        action="click",
                        selector=selector,
                        category=StepCategory.final_authorization,
                        risk=StepRisk.high,
                    )
                )
                return
            except Exception:
                continue
        raise ScriptExecutionError("Volcano pay button was not found")

    async def _wait_for_human_payment_gate(self, page: Any, steps: list[ScriptStep]) -> None:
        selectors = (
            "img[class*='qr']",
            "img[class*='qrcode']",
            "canvas[class*='qr']",
            "canvas[class*='qrcode']",
            "[class*='qr-code']",
            "[class*='qrcode']",
            "[class*='pay-qr']",
            "[class*='modal']:has(img)",
            "[class*='dialog']:has(img)",
        )
        for selector in selectors:
            try:
                await page.wait_for_selector(selector, timeout=8_000)
                steps.append(
                    ScriptStep(
                        description=(
                            "Detected Volcano QR/payment gate; waiting for user authorization"
                        ),
                        action="detect_payment",
                        selector=selector,
                        category=StepCategory.final_authorization,
                        risk=StepRisk.human_required,
                        requires_human_authorization=True,
                    )
                )
                return
            except Exception:
                continue

        current_url = str(getattr(page, "url", ""))
        if any(
            signal in current_url.lower()
            for signal in ("pay", "alipay", "wechat", "wxpay", "bank")
        ):
            steps.append(
                ScriptStep(
                    description=(
                        "Volcano redirected to external payment page; "
                        "waiting for user authorization"
                    ),
                    action="detect_payment",
                    url=current_url,
                    category=StepCategory.final_authorization,
                    risk=StepRisk.human_required,
                    requires_human_authorization=True,
                )
            )
            return

        raise ScriptExecutionError("Volcano payment QR or redirect was not detected")
