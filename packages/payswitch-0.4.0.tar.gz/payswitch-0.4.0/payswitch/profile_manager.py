"""Durable profile vault lifecycle for Pay-Switch user workspaces."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import shutil
import tempfile
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

_PROFILE_METADATA_NAME = ".payswitch-profile.json"
_PROMOTION_AUDIT_NAME = "promotion_audit.jsonl"
_LOCK_FILE_NAMES = {
    "SingletonLock",
    "SingletonCookie",
    "LOCK",
    ".payswitch-browser-lock",
}


def _default_profile_vault_root() -> Path:
    override = os.getenv("PAYSWITCH_PROFILE_VAULT_DIR", "").strip()
    if override:
        return Path(override).expanduser()
    if "pytest" in os.getenv("PYTEST_CURRENT_TEST", ""):
        return Path(tempfile.gettempdir()) / "payswitch-profile-vault-tests"
    return Path.home() / ".payswitch" / "profiles"


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def resolve_profile_schema_version(browser_engine: str) -> str:
    engine = browser_engine.strip().lower() or "playwright"
    return f"pay-switch.profile.{engine}.v1"


@dataclass(frozen=True)
class ProfileBinding:
    browser_engine: str
    schema_version: str


class ProfileCompatibilityError(RuntimeError):
    """Raised when a stable profile is incompatible with the current runtime."""


class ProfilePromotionError(RuntimeError):
    """Raised when task-profile promotion or discard cannot complete safely."""


class ProfileVaultManager:
    """Own stable profile, task profile, promotion, and rollback lifecycle."""

    def __init__(self, root_dir: str | Path | None = None) -> None:
        self.root_dir = (
            Path(root_dir).expanduser()
            if root_dir is not None
            else _default_profile_vault_root()
        )
        self._locks: dict[str, asyncio.Lock] = {}
        self._guard = asyncio.Lock()
        self.root_dir.mkdir(parents=True, exist_ok=True)

    async def prepare_task_profile(
        self,
        *,
        user_id: str,
        site_id: str,
        profile_id: str,
        task_id: str,
        binding: ProfileBinding,
    ) -> dict[str, Any]:
        root = self._profile_root(user_id, site_id, profile_id)
        stable_path = root / "stable"
        task_path = root / "tasks" / task_id
        backups_path = root / "backups"
        audit_path = root / _PROMOTION_AUDIT_NAME
        root.mkdir(parents=True, exist_ok=True)
        backups_path.mkdir(parents=True, exist_ok=True)
        (root / "tasks").mkdir(parents=True, exist_ok=True)

        stable_meta = self._ensure_stable_profile(
            stable_path,
            binding=binding,
            user_id=user_id,
            site_id=site_id,
            profile_id=profile_id,
        )
        compatibility = self._compatibility_state(stable_meta, binding)
        if compatibility["profile_state"] == "schema_incompatible":
            raise ProfileCompatibilityError(str(compatibility["profile_reason"]))

        if task_path.exists():
            shutil.rmtree(task_path)
        shutil.copytree(
            stable_path,
            task_path,
            ignore=shutil.ignore_patterns(*_LOCK_FILE_NAMES),
        )
        task_meta = {
            **stable_meta,
            "kind": "task",
            "state": "task_profile_prepared",
            "source_stable_hash": self._tree_hash(stable_path),
            "source_task_id": task_id,
            "prepared_at": _now(),
            "updated_at": _now(),
        }
        self._write_metadata(task_path, task_meta)
        self._append_audit(
            audit_path,
            {
                "ts": _now(),
                "action": "prepare",
                "status": "prepared",
                "user_id": user_id,
                "site_id": site_id,
                "profile_id": profile_id,
                "task_id": task_id,
                "stable_path": str(stable_path),
                "task_path": str(task_path),
                "stable_hash": self._tree_hash(stable_path),
            },
        )
        return await self.describe_profile(
            user_id=user_id,
            site_id=site_id,
            profile_id=profile_id,
            task_id=task_id,
            binding=binding,
        )

    async def promote_task_profile(
        self,
        *,
        user_id: str,
        site_id: str,
        profile_id: str,
        task_id: str,
        binding: ProfileBinding,
        graceful_shutdown: Callable[[], Any | Awaitable[Any]] | None = None,
        force_shutdown: Callable[[], Any | Awaitable[Any]] | None = None,
        verify: Callable[[Path], bool] | None = None,
    ) -> dict[str, Any]:
        root = self._profile_root(user_id, site_id, profile_id)
        stable_path = root / "stable"
        task_path = root / "tasks" / task_id
        audit_path = root / _PROMOTION_AUDIT_NAME
        if not task_path.exists():
            raise ProfilePromotionError(f"task profile not found: {task_id}")
        lock = await self._promotion_lock(root)
        if lock.locked():
            raise ProfilePromotionError("profile promotion already in progress")

        await lock.acquire()
        try:
            stable_meta = self._ensure_stable_profile(
                stable_path,
                binding=binding,
                user_id=user_id,
                site_id=site_id,
                profile_id=profile_id,
            )
            compatibility = self._compatibility_state(stable_meta, binding)
            if compatibility["profile_state"] == "schema_incompatible":
                raise ProfileCompatibilityError(str(compatibility["profile_reason"]))

            await self._ensure_quiescent(
                stable_path=stable_path,
                task_path=task_path,
                graceful_shutdown=graceful_shutdown,
                force_shutdown=force_shutdown,
            )
            previous_hash = self._tree_hash(stable_path)
            next_hash = self._tree_hash(task_path)
            backup_path = root / "backups" / (
                f"{task_id}-{datetime.now(UTC).strftime('%Y%m%d%H%M%S%f')}"
            )
            promoted_at = _now()
            rollback_performed = False
            try:
                if backup_path.exists():
                    shutil.rmtree(backup_path)
                stable_path.rename(backup_path)
                task_path.rename(stable_path)
                stable_meta = self._read_metadata(stable_path) or {}
                stable_meta.update(
                    {
                        "kind": "stable",
                        "state": "stable_ready",
                        "user_id": user_id,
                        "site_id": site_id,
                        "profile_id": profile_id,
                        "browser_engine": binding.browser_engine,
                        "schema_version": binding.schema_version,
                        "last_promoted_at": promoted_at,
                        "last_promotion_task_id": task_id,
                        "stable_hash": next_hash,
                        "updated_at": promoted_at,
                    }
                )
                self._write_metadata(stable_path, stable_meta)
                if verify is not None and not verify(stable_path):
                    raise ProfilePromotionError("profile promotion verification failed")
                if backup_path.exists():
                    shutil.rmtree(backup_path)
            except BaseException as exc:
                rollback_performed = True
                if stable_path.exists():
                    shutil.rmtree(stable_path)
                if backup_path.exists():
                    backup_path.rename(stable_path)
                self._append_audit(
                    audit_path,
                    {
                        "ts": _now(),
                        "action": "promote",
                        "status": "rolled_back",
                        "user_id": user_id,
                        "site_id": site_id,
                        "profile_id": profile_id,
                        "task_id": task_id,
                        "reason": str(exc),
                        "rollback_performed": True,
                        "previous_hash": previous_hash,
                        "next_hash": next_hash,
                    },
                )
                raise
            finally:
                if task_path.exists():
                    shutil.rmtree(task_path)

            self._append_audit(
                audit_path,
                {
                    "ts": promoted_at,
                    "action": "promote",
                    "status": "promoted",
                    "user_id": user_id,
                    "site_id": site_id,
                    "profile_id": profile_id,
                    "task_id": task_id,
                    "rollback_performed": rollback_performed,
                    "previous_hash": previous_hash,
                    "next_hash": next_hash,
                },
            )
            return await self.describe_profile(
                user_id=user_id,
                site_id=site_id,
                profile_id=profile_id,
                binding=binding,
            )
        finally:
            lock.release()

    async def discard_task_profile(
        self,
        *,
        user_id: str,
        site_id: str,
        profile_id: str,
        task_id: str,
        binding: ProfileBinding,
        reason: str,
    ) -> dict[str, Any]:
        root = self._profile_root(user_id, site_id, profile_id)
        task_path = root / "tasks" / task_id
        audit_path = root / _PROMOTION_AUDIT_NAME
        if task_path.exists():
            shutil.rmtree(task_path)
        self._append_audit(
            audit_path,
            {
                "ts": _now(),
                "action": "discard",
                "status": "discarded",
                "user_id": user_id,
                "site_id": site_id,
                "profile_id": profile_id,
                "task_id": task_id,
                "reason": reason,
            },
        )
        return await self.describe_profile(
            user_id=user_id,
            site_id=site_id,
            profile_id=profile_id,
            binding=binding,
        )

    async def describe_profile(
        self,
        *,
        user_id: str,
        site_id: str,
        profile_id: str,
        task_id: str | None = None,
        binding: ProfileBinding | None = None,
    ) -> dict[str, Any]:
        root = self._profile_root(user_id, site_id, profile_id)
        stable_path = root / "stable"
        task_path = root / "tasks" / task_id if task_id else None
        stable_meta = self._read_metadata(stable_path) or {}
        state = "profile_not_initialized"
        reason = "stable_profile_missing"
        if stable_path.exists():
            state = "stable_ready"
            reason = "stable_profile_ready"
        if binding is not None:
            compatibility = self._compatibility_state(stable_meta, binding)
            state = compatibility["profile_state"]
            reason = compatibility["profile_reason"]
        task_exists = bool(task_path and task_path.exists())
        if task_exists:
            state = "task_profile_prepared"
            reason = "task_profile_ready"
        return {
            "profile_state": state,
            "profile_reason": reason,
            "profile_stable_path": str(stable_path) if stable_path.exists() else None,
            "profile_task_path": str(task_path) if task_exists else None,
            "profile_browser_engine": stable_meta.get("browser_engine"),
            "profile_schema_version": stable_meta.get("schema_version"),
            "profile_last_promoted_at": stable_meta.get("last_promoted_at"),
            "profile_last_promotion_task_id": stable_meta.get("last_promotion_task_id"),
            "profile_has_backup": (
                any((root / "backups").iterdir()) if (root / "backups").exists() else False
            ),
            "profile_task_exists": task_exists,
        }

    async def summarize_user_profiles(self, user_id: str) -> dict[str, int]:
        user_root = self.root_dir / user_id
        if not user_root.exists():
            return {
                "profiles_total": 0,
                "profiles_incompatible": 0,
                "active_task_profiles": 0,
            }
        total = 0
        incompatible = 0
        active_task_profiles = 0
        for site_root in user_root.iterdir():
            if not site_root.is_dir():
                continue
            for profile_root in site_root.iterdir():
                if not profile_root.is_dir():
                    continue
                total += 1
                stable_meta = self._read_metadata(profile_root / "stable") or {}
                if stable_meta.get("state") == "schema_incompatible":
                    incompatible += 1
                tasks_root = profile_root / "tasks"
                if tasks_root.exists():
                    active_task_profiles += sum(
                        1 for child in tasks_root.iterdir() if child.is_dir()
                    )
        return {
            "profiles_total": total,
            "profiles_incompatible": incompatible,
            "active_task_profiles": active_task_profiles,
        }

    async def reset(self) -> None:
        if self.root_dir.exists():
            shutil.rmtree(self.root_dir)
        self.root_dir.mkdir(parents=True, exist_ok=True)
        async with self._guard:
            self._locks.clear()

    async def _promotion_lock(self, root: Path) -> asyncio.Lock:
        key = str(root)
        async with self._guard:
            return self._locks.setdefault(key, asyncio.Lock())

    def _profile_root(self, user_id: str, site_id: str, profile_id: str) -> Path:
        return self.root_dir / user_id / site_id / profile_id

    def _ensure_stable_profile(
        self,
        stable_path: Path,
        *,
        binding: ProfileBinding,
        user_id: str,
        site_id: str,
        profile_id: str,
    ) -> dict[str, Any]:
        stable_path.mkdir(parents=True, exist_ok=True)
        metadata = self._read_metadata(stable_path)
        if metadata is None:
            non_meta_entries = [
                child
                for child in stable_path.iterdir()
                if child.name != _PROFILE_METADATA_NAME
            ]
            if non_meta_entries:
                raise ProfileCompatibilityError(
                    "stable profile metadata missing; migration is required before opening it"
                )
            metadata = {
                "kind": "stable",
                "state": "stable_ready",
                "user_id": user_id,
                "site_id": site_id,
                "profile_id": profile_id,
                "browser_engine": binding.browser_engine,
                "schema_version": binding.schema_version,
                "created_at": _now(),
                "updated_at": _now(),
            }
            self._write_metadata(stable_path, metadata)
            return metadata
        compatibility = self._compatibility_state(metadata, binding)
        if compatibility["profile_state"] == "schema_incompatible":
            metadata = {
                **metadata,
                "state": "schema_incompatible",
                "updated_at": _now(),
            }
            self._write_metadata(stable_path, metadata)
            raise ProfileCompatibilityError(str(compatibility["profile_reason"]))
        metadata["state"] = "stable_ready"
        metadata["updated_at"] = _now()
        self._write_metadata(stable_path, metadata)
        return metadata

    def _compatibility_state(
        self,
        metadata: dict[str, Any],
        binding: ProfileBinding,
    ) -> dict[str, str]:
        if not metadata:
            return {
                "profile_state": "profile_not_initialized",
                "profile_reason": "stable_profile_missing",
            }
        if metadata.get("browser_engine") != binding.browser_engine:
            return {
                "profile_state": "schema_incompatible",
                "profile_reason": (
                    "browser_engine_mismatch: "
                    "expected "
                    f"{binding.browser_engine}, got "
                    f"{metadata.get('browser_engine') or '<missing>'}"
                ),
            }
        if metadata.get("schema_version") != binding.schema_version:
            return {
                "profile_state": "schema_incompatible",
                "profile_reason": (
                    "profile_schema_mismatch: "
                    "expected "
                    f"{binding.schema_version}, got "
                    f"{metadata.get('schema_version') or '<missing>'}"
                ),
            }
        return {
            "profile_state": "stable_ready",
            "profile_reason": "stable_profile_ready",
        }

    async def _ensure_quiescent(
        self,
        *,
        stable_path: Path,
        task_path: Path,
        graceful_shutdown: Callable[[], Any | Awaitable[Any]] | None,
        force_shutdown: Callable[[], Any | Awaitable[Any]] | None,
    ) -> None:
        if graceful_shutdown is not None:
            await self._maybe_await(graceful_shutdown())
        if self._residual_lock_files(stable_path) or self._residual_lock_files(task_path):
            if force_shutdown is not None:
                await self._maybe_await(force_shutdown())
            if self._residual_lock_files(stable_path) or self._residual_lock_files(task_path):
                raise ProfilePromotionError(
                    "profile promotion refused because browser lock files remain after quiescence"
                )

    async def _maybe_await(self, value: Any) -> Any:
        if asyncio.iscoroutine(value) or isinstance(value, Awaitable):
            return await value
        return value

    def _residual_lock_files(self, root: Path) -> list[Path]:
        if not root.exists():
            return []
        return [
            path
            for path in root.rglob("*")
            if path.is_file() and path.name in _LOCK_FILE_NAMES
        ]

    def _metadata_path(self, root: Path) -> Path:
        return root / _PROFILE_METADATA_NAME

    def _read_metadata(self, root: Path) -> dict[str, Any] | None:
        path = self._metadata_path(root)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None

    def _write_metadata(self, root: Path, payload: dict[str, Any]) -> None:
        root.mkdir(parents=True, exist_ok=True)
        self._metadata_path(root).write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    def _append_audit(self, audit_path: Path, payload: dict[str, Any]) -> None:
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        with audit_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False, sort_keys=True))
            handle.write("\n")

    def _tree_hash(self, root: Path) -> str:
        digest = hashlib.sha256()
        if not root.exists():
            digest.update(b"<missing>")
            return digest.hexdigest()
        for path in sorted(root.rglob("*")):
            if path.name == _PROMOTION_AUDIT_NAME:
                continue
            if path.name == _PROFILE_METADATA_NAME:
                # metadata participates in the hash because it captures schema/version state
                pass
            digest.update(str(path.relative_to(root)).encode("utf-8"))
            if path.is_file():
                digest.update(path.read_bytes())
        return digest.hexdigest()
