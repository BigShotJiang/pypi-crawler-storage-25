"""Ephemeral CDP mirror support.

This backend is intentionally different from Playwright persistent-context
launching. It creates a transaction-scoped temporary Chrome User Data mirror,
starts Google Chrome itself with a remote-debugging port, and lets the normal
BrowserController attach over CDP.
"""

from __future__ import annotations

import json
import logging
import platform
import re
import shutil
import socket
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_MIRROR_ROOT_NAME = "payswitch-cdp-mirrors"
_METADATA_FILE = ".payswitch-cdp-mirror.json"
_CHROME_APP_PATH = "/Applications/Google Chrome.app"
_CHROME_BIN_PATH = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
_PROFILE_DIR_RE = re.compile(r"[^A-Za-z0-9_.-]+")


class CdpMirrorError(RuntimeError):
    """Raised when an ephemeral CDP mirror cannot be prepared or launched."""


@dataclass(frozen=True)
class CdpMirrorInstance:
    """Prepared transaction-scoped CDP mirror instance."""

    source_user_data_dir: Path
    mirror_user_data_dir: Path
    profile_directory: str
    cdp_port: int
    cdp_url: str
    log_path: Path


def prepare_ephemeral_cdp_mirror(
    *,
    source_user_data_dir: Path,
    profile_directory: str,
    session_key: str | None,
    browser_channel: str = "chrome",
    timeout_seconds: float = 20.0,
) -> CdpMirrorInstance:
    """Create or reuse a temporary mirrored Chrome instance and expose CDP."""
    cleanup_stale_ephemeral_cdp_mirrors()
    source_root = source_user_data_dir.expanduser().resolve()
    if not source_root.exists():
        raise CdpMirrorError(f"Chrome User Data 目录不存在：{source_root}")

    profile = profile_directory.strip() or "Default"
    source_profile = source_root / profile
    if not source_profile.exists():
        raise CdpMirrorError(f"Chrome profile 目录不存在：{source_profile}")

    mirror_root = _mirror_root_for_session(session_key)
    mirror_root.mkdir(parents=True, exist_ok=True)
    mirror_root.chmod(0o700)
    metadata = _read_metadata(mirror_root)
    cdp_port = int(metadata.get("cdp_port") or 0)
    if (
        cdp_port > 0
        and metadata.get("source_user_data_dir") == str(source_root)
        and metadata.get("profile_directory") == profile
        and _port_ready(cdp_port)
    ):
        return _instance(
            source_root=source_root,
            mirror_root=mirror_root,
            profile=profile,
            cdp_port=cdp_port,
        )

    cdp_port = _find_free_port()
    _sync_profile_snapshot(source_root=source_root, mirror_root=mirror_root, profile=profile)
    _enable_remote_debugging_consent(mirror_root)
    _write_metadata(
        mirror_root,
        {
            "source_user_data_dir": str(source_root),
            "profile_directory": profile,
            "cdp_port": cdp_port,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
    )
    instance = _instance(
        source_root=source_root,
        mirror_root=mirror_root,
        profile=profile,
        cdp_port=cdp_port,
    )
    _launch_chrome(instance, browser_channel=browser_channel)
    _wait_for_port(cdp_port, timeout_seconds=timeout_seconds)
    logger.info(
        "已启动临时 CDP 镜像 Chrome：profile=%s mirror=%s cdp=%s",
        profile,
        mirror_root,
        instance.cdp_url,
    )
    return instance


def cleanup_ephemeral_cdp_mirror(session_key: str | None) -> None:
    """Best-effort cleanup for a transaction-scoped mirror directory."""
    mirror_root = _mirror_root_for_session(session_key)
    if not _is_safe_mirror_path(mirror_root):
        raise CdpMirrorError(f"拒绝清理非 Pay-Switch 临时镜像目录：{mirror_root}")
    shutil.rmtree(mirror_root, ignore_errors=True)


def cleanup_stale_ephemeral_cdp_mirrors(*, max_age_seconds: float = 86_400.0) -> None:
    """Remove old inactive mirror folders from the Pay-Switch temp root."""
    root = Path(tempfile.gettempdir()) / _MIRROR_ROOT_NAME
    if not root.exists():
        return

    now = time.time()
    for candidate in root.iterdir():
        if not candidate.is_dir() or not _is_safe_mirror_path(candidate):
            continue
        metadata = _read_metadata(candidate)
        cdp_port = int(metadata.get("cdp_port") or 0)
        if cdp_port > 0 and _port_ready(cdp_port):
            continue
        try:
            age_seconds = now - candidate.stat().st_mtime
        except OSError:
            continue
        if age_seconds >= max_age_seconds:
            shutil.rmtree(candidate, ignore_errors=True)


def _mirror_root_for_session(session_key: str | None) -> Path:
    key = _safe_session_key(session_key)
    return Path(tempfile.gettempdir()) / _MIRROR_ROOT_NAME / key


def _safe_session_key(session_key: str | None) -> str:
    raw = (session_key or "adhoc").strip() or "adhoc"
    return _PROFILE_DIR_RE.sub("-", raw)[:120]


def _instance(
    *,
    source_root: Path,
    mirror_root: Path,
    profile: str,
    cdp_port: int,
) -> CdpMirrorInstance:
    return CdpMirrorInstance(
        source_user_data_dir=source_root,
        mirror_user_data_dir=mirror_root,
        profile_directory=profile,
        cdp_port=cdp_port,
        cdp_url=f"http://127.0.0.1:{cdp_port}",
        log_path=mirror_root / "payswitch-cdp-chrome.log",
    )


def _sync_profile_snapshot(*, source_root: Path, mirror_root: Path, profile: str) -> None:
    mirror_root.mkdir(parents=True, exist_ok=True)
    _copy_file_if_exists(source_root / "Local State", mirror_root / "Local State")
    source_profile = source_root / profile
    mirror_profile = mirror_root / profile
    if mirror_profile.exists():
        shutil.rmtree(mirror_profile)
    shutil.copytree(
        source_profile,
        mirror_profile,
        symlinks=True,
        ignore=_ignore_profile_entries,
        copy_function=_copy_profile_file,
        ignore_dangling_symlinks=True,
    )
    _remove_runtime_files(mirror_root)


def _copy_file_if_exists(source: Path, destination: Path) -> None:
    if source.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


def _copy_profile_file(source: str, destination: str) -> str:
    try:
        shutil.copy2(source, destination)
    except OSError as exc:
        logger.debug("跳过临时镜像中无法复制的运行态文件：%s | %s", source, exc)
    return destination


def _ignore_profile_entries(directory: str, names: list[str]) -> set[str]:
    ignored: set[str] = set()
    blocked_exact = {
        "SingletonLock",
        "SingletonCookie",
        "SingletonSocket",
        "DevToolsActivePort",
        "Cache",
        "Code Cache",
        "GPUCache",
        "GrShaderCache",
        "DawnGraphiteCache",
        "DawnWebGPUCache",
        "blob_storage",
        "VideoDecodeStats",
        "Crashpad",
    }
    blocked_suffix = {"-journal", "-wal", "-shm"}
    for name in names:
        if name in blocked_exact or name.startswith("Singleton"):
            ignored.add(name)
            continue
        if any(name.endswith(suffix) for suffix in blocked_suffix):
            ignored.add(name)
            continue
        if Path(directory).name == "Service Worker" and name == "CacheStorage":
            ignored.add(name)
    return ignored


def _remove_runtime_files(mirror_root: Path) -> None:
    for pattern in ("Singleton*", "DevToolsActivePort"):
        for path in mirror_root.glob(pattern):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                logger.debug("清理临时镜像运行态文件失败（可忽略）：%s", path)


def _enable_remote_debugging_consent(mirror_root: Path) -> None:
    local_state_path = mirror_root / "Local State"
    try:
        data = json.loads(local_state_path.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    devtools = data.setdefault("devtools", {})
    remote_debugging = devtools.setdefault("remote_debugging", {})
    remote_debugging["user-enabled"] = True
    local_state_path.write_text(
        json.dumps(data, ensure_ascii=False),
        encoding="utf-8",
    )


def _launch_chrome(instance: CdpMirrorInstance, *, browser_channel: str) -> None:
    instance.mirror_user_data_dir.mkdir(parents=True, exist_ok=True)
    args = [
        f"--user-data-dir={instance.mirror_user_data_dir}",
        f"--profile-directory={instance.profile_directory}",
        "--remote-debugging-address=127.0.0.1",
        f"--remote-debugging-port={instance.cdp_port}",
        "--no-first-run",
        "--no-default-browser-check",
        "about:blank",
    ]
    if platform.system() == "Darwin":
        command = ["open", "-na", _chrome_app_path(browser_channel), "--args", *args]
    else:
        command = [_chrome_bin_path(browser_channel), *args]
    try:
        with instance.log_path.open("ab") as log_file:
            subprocess.Popen(  # noqa: S603
                command,
                stdout=log_file,
                stderr=log_file,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
    except OSError as exc:
        raise CdpMirrorError(f"启动临时 CDP Chrome 失败：{exc}") from exc


def _chrome_app_path(browser_channel: str) -> str:
    if browser_channel.lower() == "chromium":
        return "/Applications/Chromium.app"
    return _CHROME_APP_PATH


def _chrome_bin_path(browser_channel: str) -> str:
    if browser_channel.lower() == "chromium":
        return "chromium"
    return _CHROME_BIN_PATH


def _wait_for_port(port: int, *, timeout_seconds: float) -> None:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if _port_ready(port):
            return
        time.sleep(0.25)
    raise CdpMirrorError(f"临时 CDP Chrome 未在超时内暴露端口：{port}")


def _port_ready(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _read_metadata(mirror_root: Path) -> dict[str, Any]:
    try:
        return json.loads((mirror_root / _METADATA_FILE).read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_metadata(mirror_root: Path, data: dict[str, Any]) -> None:
    (mirror_root / _METADATA_FILE).write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _is_safe_mirror_path(path: Path) -> bool:
    try:
        resolved = path.resolve()
        expected = (Path(tempfile.gettempdir()) / _MIRROR_ROOT_NAME).resolve()
        return resolved == expected or expected in resolved.parents
    except OSError:
        return False
