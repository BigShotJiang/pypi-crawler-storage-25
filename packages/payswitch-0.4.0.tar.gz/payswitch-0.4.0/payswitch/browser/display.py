"""Pay-Switch 人类交互显示模块。

根据运行环境自动选择合适的人机交互方式：
- 有图形界面的本地系统（Windows / macOS / Linux+DISPLAY）→ headed 模式
- 无图形界面的远程服务器 → novnc 模式

使用 Rich 库美化终端输出，提供清晰的操作引导和等待动画。
"""

from __future__ import annotations

import asyncio
import inspect
import os
import platform
import time
from collections.abc import Awaitable, Callable
from typing import Any

from rich.columns import Columns
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.text import Text

from payswitch.models.types import DisplayMode

# 全局 Rich 控制台实例，stderr=False 确保输出到 stdout
console = Console()


def detect_display_mode() -> DisplayMode:
    """自动检测部署环境，选择人类交互方式。

    检测逻辑（优先级从高到低）：
    1. Windows → headed（本地有头浏览器）
    2. macOS → headed（本地有头浏览器）
    3. Linux + DISPLAY 环境变量存在 → headed（X11 图形环境）
    4. 其他（Linux 无 DISPLAY、容器等）→ novnc（远程可视化）

    Returns:
        DisplayMode: 检测到的最适合当前环境的显示模式。
    """
    system = platform.system()

    if system == "Windows":
        return DisplayMode.headed

    if system == "Darwin":
        # macOS 始终有图形界面
        return DisplayMode.headed

    if system == "Linux":
        # 检查 X11 DISPLAY 环境变量，判断是否有图形桌面
        display_env = os.environ.get("DISPLAY", "").strip()
        if display_env:
            return DisplayMode.headed
        # 也检查 Wayland
        wayland_env = os.environ.get("WAYLAND_DISPLAY", "").strip()
        if wayland_env:
            return DisplayMode.headed

    # 其余情况（无图形环境的 Linux、BSD、容器等）→ noVNC 远程访问
    return DisplayMode.novnc


class DisplayManager:
    """管理人类交互方式（弹窗 / noVNC）。

    支持两种模式：
    - headed：本地有头浏览器，浏览器窗口直接可见，通过终端输出引导用户操作。
    - novnc：无头浏览器 + noVNC 远程访问，输出 VNC URL 供用户通过浏览器查看。

    使用示例：
        manager = DisplayManager()
        await manager.start_novnc()
        await manager.notify_human("请扫描二维码完成支付", "qr_scan")
        success = await manager.wait_for_completion(my_detector, timeout=120)
        await manager.stop()
    """

    # noVNC 默认监听端口
    _NOVNC_DEFAULT_PORT: int = 6080
    # noVNC 默认主机（本地回环或容器内可访问地址）
    _NOVNC_DEFAULT_HOST: str = "localhost"

    def __init__(self, mode: DisplayMode | None = None) -> None:
        """初始化 DisplayManager。

        Args:
            mode: 指定显示模式。为 None 时调用 detect_display_mode() 自动检测。
        """
        if mode is None:
            self._mode = detect_display_mode()
        else:
            self._mode = mode

        # noVNC 访问地址（仅 novnc 模式下有效）
        self._novnc_host: str = os.environ.get(
            "PAYSWITCH_NOVNC_HOST", self._NOVNC_DEFAULT_HOST
        )
        self._novnc_port: int = int(
            os.environ.get("PAYSWITCH_NOVNC_PORT", str(self._NOVNC_DEFAULT_PORT))
        )

        # NoVNCManager 实例（仅 novnc 模式下创建，延迟导入避免在 Windows 上报错）
        self._novnc_manager = None
        if self._mode == DisplayMode.novnc:
            # 延迟导入：NoVNCManager 依赖 Linux 专有工具（Xvfb、x11vnc、novnc），
            # 仅在实际需要时才引入，防止 Windows/macOS 启动时因缺少依赖而崩溃
            from payswitch.browser.novnc import NoVNCManager  # noqa: PLC0415

            self._novnc_manager = NoVNCManager(
                host=self._novnc_host,
                port=self._novnc_port,
            )

    # ------------------------------------------------------------------
    # 公开接口
    # ------------------------------------------------------------------

    @property
    def mode(self) -> DisplayMode:
        """返回当前显示模式。"""
        return self._mode

    def get_display_info(self) -> dict[str, Any]:
        """返回当前显示配置信息。

        Returns:
            headed 模式: {"mode": "headed"}
            novnc 模式:  {"mode": "novnc", "url": "http://...", "display": ":99"}
                         url 优先从 NoVNCManager 获取（确保与实际运行端口一致）；
                         display 为 Xvfb 虚拟显示编号，供 BrowserController 设置 DISPLAY 使用。
        """
        if self._mode == DisplayMode.headed:
            return {"mode": "headed"}

        # novnc 模式：优先从 NoVNCManager 获取实际运行信息
        if self._novnc_manager is not None:
            info = self._novnc_manager.get_info()
            return {
                "mode": "novnc",
                "url": info.get("url", f"http://{self._novnc_host}:{self._novnc_port}/vnc.html"),
                "display": info.get("display", ":99"),
            }

        # NoVNCManager 未创建时回退到静态拼接
        url = f"http://{self._novnc_host}:{self._novnc_port}/vnc.html"
        return {"mode": "novnc", "url": url, "display": ":99"}

    async def start_novnc(self) -> None:
        """启动 noVNC 服务（含 Xvfb 虚拟显示和 VNC 桥接）。

        - novnc 模式：调用 NoVNCManager.start()，启动 Xvfb + x11vnc + noVNC websockify。
          启动成功后，可通过 get_display_info() 获取 noVNC 访问 URL 和 DISPLAY 编号。
        - headed 模式：直接返回，不做任何操作（本地已有真实显示器）。
        """
        if self._mode != DisplayMode.novnc:
            # headed 模式无需启动虚拟显示
            return

        if self._novnc_manager is None:
            # 防御性检查：正常情况下 __init__ 已创建，此处不应为 None
            return

        await self._novnc_manager.start()

    async def stop(self) -> None:
        """停止 noVNC 服务并释放相关资源。

        - novnc 模式：调用 NoVNCManager.stop()，依次终止 websockify、x11vnc、Xvfb 进程。
        - headed 模式：直接返回，无需处理。
        - 安全：多次调用不会报错。
        """
        if self._mode != DisplayMode.novnc:
            return

        if self._novnc_manager is None:
            return

        await self._novnc_manager.stop()

    async def notify_human(
        self,
        message: str,
        action_type: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """通知人类需要介入，并给出操作引导。

        根据当前显示模式，以不同方式提示用户：
        - headed 模式：直接在终端输出引导信息（浏览器窗口已在屏幕上可见）。
        - novnc 模式：输出 noVNC 访问 URL，引导用户通过浏览器远程查看并操作。

        所有输出均通过 Rich Panel 美化，确保在复杂终端环境下清晰可读。

        Args:
            message: 主要提示信息，例如"请扫描二维码完成支付"。
            action_type: 操作类型标识，例如 "qr_scan"、"sms_verify"、"captcha"。
            details: 可选的额外信息字典，会以键值对形式展示在面板中。
        """
        # 构建面板标题（含操作类型标签）
        title = f"[bold yellow]需要人工介入[/bold yellow]  [dim]({action_type})[/dim]"

        # 构建面板正文
        body_lines: list[str] = [
            f"[bold white]{message}[/bold white]",
            "",  # 空行分隔
        ]

        if self._mode == DisplayMode.novnc:
            # novnc 模式：从 get_display_info() 获取 URL（优先使用 NoVNCManager 的实际地址）
            info = self.get_display_info()
            vnc_url = info.get("url", "")
            body_lines += [
                "[cyan]请通过浏览器访问以下地址查看并操作：[/cyan]",
                f"  [bold blue underline]{vnc_url}[/bold blue underline]",
                "",
            ]
        else:
            # headed 模式：浏览器窗口已在本地屏幕上可见
            body_lines += [
                "[cyan]浏览器窗口已在本地显示，请直接在浏览器中完成操作。[/cyan]",
                "",
            ]

        # 附加 details 键值对
        if details:
            body_lines.append("[dim]── 附加信息 ──[/dim]")
            for key, value in details.items():
                body_lines.append(f"  [green]{key}[/green]: {value}")

        body = "\n".join(body_lines)

        # 使用 Rich Panel 输出
        panel = Panel(
            body,
            title=title,
            border_style="yellow",
            padding=(1, 2),
        )
        console.print(panel)

    async def wait_for_completion(
        self,
        detector_callback: Callable[[], bool | Awaitable[bool]],
        timeout: int = 300,
    ) -> bool:
        """等待人类操作完成。

        以 2 秒为间隔轮询 detector_callback，检测页面状态是否发生预期变化。
        同时使用 Rich Live 显示 spinner 动画和剩余倒计时，提供实时反馈。

        Args:
            detector_callback: 异步或同步回调函数，返回 True 表示操作已完成。
                               签名：async def callback() -> bool
            timeout: 最长等待秒数，超时后返回 False。默认 300 秒（5 分钟）。

        Returns:
            True  —— 检测到操作完成。
            False —— 超时，操作未完成。
        """
        # 轮询间隔（秒）
        poll_interval: float = 2.0
        # 记录开始时间
        start_time = time.monotonic()
        deadline = start_time + timeout

        spinner = Spinner("dots", style="cyan")

        def _build_status_text(remaining: int) -> Text:
            """构建倒计时状态文本。"""
            minutes, seconds = divmod(remaining, 60)
            time_str = f"{minutes:02d}:{seconds:02d}"
            text = Text()
            text.append("等待人工操作完成", style="bold white")
            text.append("  ", style="")
            text.append(f"剩余时间：{time_str}", style="yellow")
            return text

        with Live(console=console, refresh_per_second=4) as live:
            while True:
                # 计算剩余时间
                elapsed = time.monotonic() - start_time
                remaining = max(0, int(timeout - elapsed))

                # 更新 Live 展示内容（spinner + 倒计时）
                status_text = _build_status_text(remaining)
                live.update(Columns([spinner, status_text]))

                # 检测是否已完成
                try:
                    result_or_awaitable = detector_callback()
                    if inspect.isawaitable(result_or_awaitable):
                        result = await result_or_awaitable
                    else:
                        result = result_or_awaitable

                    if result:
                        # 操作完成：退出 Live 并输出成功提示
                        live.stop()
                        console.print(
                            Panel(
                                "[bold green]人工操作已完成，继续执行...[/bold green]",
                                border_style="green",
                                padding=(0, 2),
                            )
                        )
                        return True

                except Exception as exc:  # noqa: BLE001
                    # 检测回调异常不应中断等待，记录日志后继续轮询
                    console.print(
                        f"[dim red]检测回调发生异常（已忽略）：{exc}[/dim red]"
                    )

                # 检查是否超时
                if time.monotonic() >= deadline:
                    live.stop()
                    console.print(
                        Panel(
                            f"[bold red]等待超时（{timeout} 秒），人工操作未完成。[/bold red]",
                            border_style="red",
                            padding=(0, 2),
                        )
                    )
                    return False

                # 等待下次轮询
                await asyncio.sleep(poll_interval)
