"""Skyvern 智能执行引擎——基于 LLM 视觉驱动的浏览器自动化。

原理：截图 → LLM 视觉分析 → 返回操作指令（JSON） → Playwright 执行 → 循环
支持 OpenAI 多模态 API（gpt-4o 等视觉模型）。

由于 Skyvern 本身较重且可能不可用，此模块实现一个轻量级等效方案：
直接通过 LLM 视觉能力理解页面截图，指导 Playwright 执行动作。
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import Any

from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import StepRecord

# 尝试导入 openai，未安装时降级处理
try:
    import openai as _openai_module

    _OPENAI_AVAILABLE = True
except ImportError:
    _openai_module = None  # type: ignore[assignment]
    _OPENAI_AVAILABLE = False

logger = logging.getLogger(__name__)

PreActionCallback = Callable[[Any, dict[str, Any], int, list[str]], Awaitable[None]]

_OPENAI_CHAT_COMPLETIONS_URL = "https://api.openai.com/v1/chat/completions"
_GITHUB_CHAT_COMPLETIONS_URL = "https://models.github.ai/inference/chat/completions"

# -----------------------------------------------------------------------
# 自定义异常
# -----------------------------------------------------------------------


class SmartModeError(Exception):
    """智能模式执行失败时抛出。

    常见原因：
    - LLM API Key 未配置
    - openai 库未安装
    - 达到最大步骤数仍未完成任务
    - 连续多次 LLM 调用无有效操作
    """


# -----------------------------------------------------------------------
# 系统提示词（中文）
# -----------------------------------------------------------------------

_SYSTEM_PROMPT = """你是一个专业的支付助手，擅长通过分析网页截图来指导用户完成在线支付流程。

你的职责：
1. 分析用户发送的网页截图
2. 理解当前页面的状态和内容
3. 根据任务描述，决定下一步应执行的操作
4. 以 JSON 格式返回操作指令

操作指令格式（严格遵守）：
{
  "action": "click" | "fill" | "scroll" | "wait" | "done",
  "selector": "CSS 选择器或元素的文本内容描述",
  "value": "填写的值（fill 动作时使用，其他动作留空字符串）",
  "description": "本次操作的中文描述，例如：点击「立即充值」按钮",
  "reasoning": "选择此操作的原因，例如：页面显示充值入口，需要点击进入充值页"
}

操作类型说明：
- click：点击指定元素（按钮、链接、选项卡等）
- fill：在输入框中填写内容（金额、邮箱等非敏感信息）
- scroll：滚动页面以查看更多内容
- wait：等待页面加载或动画完成
- done：任务已完成或已到达支付环节，停止执行

重要规则：
- 遇到需要填写密码、银行卡号、支付密码等敏感信息时，立即返回 action=done
- 遇到二维码支付页面时，立即返回 action=done
- 遇到支付确认按钮（如「确认支付」「立即支付」）时，立即返回 action=done
- 遇到支付成功页面时，立即返回 action=done
- selector 字段尽量使用精确的 CSS 选择器，无法确定时使用元素的可见文本内容
- 只返回 JSON，不要有任何额外说明文字"""

_USER_PROMPT_TEMPLATE = """任务描述：{task}

已执行步骤：
{history}

请分析上面的截图，返回下一步操作的 JSON 指令。"""


# -----------------------------------------------------------------------
# SkyvernEngine 主类
# -----------------------------------------------------------------------


class SkyvernEngine:
    """智能执行引擎——LLM 视觉驱动的浏览器自动化。

    原理：截图 → LLM 视觉分析 → 返回操作指令 → Playwright 执行 → 循环
    不依赖 Skyvern 服务，直接调用 OpenAI 多模态 API 实现等效能力。
    """

    def __init__(self, config: PaySwitchConfig) -> None:
        """初始化引擎，检查 LLM 配置。

        Args:
            config: Pay-Switch 全局配置，需包含有效的 llm_api_key 和 llm_model。
        """
        self._config = config
        self._provider, self._model, self._api_key, self._base_url = (
            self._resolve_llm_settings(config)
        )

        # 懒加载 openai 客户端（调用时才创建）
        self._client: Any | None = None

        logger.debug(
            "SkyvernEngine 初始化：provider=%s, model=%s, api_key_set=%s",
            self._provider,
            self._model,
            bool(self._api_key),
        )

    # ------------------------------------------------------------------
    # 公开接口
    # ------------------------------------------------------------------

    def is_available(self) -> bool:
        """检查智能引擎是否可用。

        必须同时满足：
        1. openai 库已安装
        2. LLM API Key 已配置（非空）

        Returns:
            True 表示可用，False 表示不可用（将回退到普通模式）。
        """
        if not _OPENAI_AVAILABLE:
            logger.debug("SkyvernEngine 不可用：openai 库未安装")
            return False
        if not self._api_key:
            logger.debug("SkyvernEngine 不可用：LLM API Key 未配置")
            return False
        return True

    @staticmethod
    def _resolve_llm_settings(config: PaySwitchConfig) -> tuple[str, str, str, str]:
        """Resolve Computer Use model settings from config, then server AI env."""
        provider = config.llm_provider.strip().lower() or "openai"
        model = config.llm_model.strip() or "gpt-4o"
        api_key = config.get_llm_api_key()
        base_url = ""

        env_provider = os.getenv("PAYSWITCH_AI_PROVIDER", "").strip().lower()
        env_model = os.getenv("PAYSWITCH_AI_MODEL", "").strip()
        env_base_url = os.getenv("PAYSWITCH_AI_BASE_URL", "").strip()
        env_token = os.getenv("PAYSWITCH_AI_TOKEN", "").strip()

        if not api_key and (
            env_token or os.getenv("OPENAI_API_KEY") or os.getenv("GITHUB_TOKEN")
        ):
            provider = env_provider or provider
            if provider == "openai":
                api_key = env_token or os.getenv("OPENAI_API_KEY", "").strip()
                model = env_model or "gpt-4o-mini"
                base_url = env_base_url or _OPENAI_CHAT_COMPLETIONS_URL
            elif provider == "github":
                api_key = env_token or os.getenv("GITHUB_TOKEN", "").strip()
                model = env_model or "openai/gpt-4o-mini"
                base_url = env_base_url or _GITHUB_CHAT_COMPLETIONS_URL
            elif env_token:
                api_key = env_token
                model = env_model or model
                base_url = env_base_url

        return provider, model, api_key, base_url

    async def execute_task(
        self,
        page: Any,
        task_description: str,
        url: str | None = None,
        max_steps: int = 10,
        max_output_tokens: int = 1000,
        pre_action_callback: PreActionCallback | None = None,
    ) -> list[StepRecord]:
        """使用 LLM 视觉执行任务，直至到达支付环节或任务完成。

        流程：
        1. 如果有 url，先导航到该页面
        2. 截图当前页面
        3. 发送截图 + 任务描述给 LLM
        4. LLM 返回下一步操作（JSON 格式）
        5. 执行操作（click/fill/scroll/wait）
        6. 运行 DetectorPipeline 检测支付环节
        7. 检测到支付环节 → 返回当前步骤列表
        8. 未检测到 → 重复 2-7，最多 max_steps 次
        9. 达到 max_steps 仍未完成 → 抛出 SmartModeError

        Args:
            page:             Playwright 页面实例（Any 类型避免导入依赖）。
            task_description: 任务描述，如"导航到 DeepSeek 充值页并填写 100 元"。
            url:              可选，先导航到此 URL。
            max_steps:        最大执行步骤数，超出则抛出异常。
            max_output_tokens: 每一步 LLM 响应允许的最大 token。

        Returns:
            已执行的 StepRecord 列表。

        Raises:
            SmartModeError: 引擎不可用，或达到最大步骤数，或连续多次无效操作。
        """
        if not self.is_available():
            raise SmartModeError(
                "智能引擎不可用：请安装 openai 库并配置 LLM API Key"
                "（运行 payswitch config set-llm-key）"
            )

        steps: list[StepRecord] = []
        history: list[str] = []
        # 连续无有效操作计数器
        consecutive_no_op = 0
        # 连续无有效操作的最大容忍次数
        max_no_op = 3

        # 延迟导入，避免在 openai 未安装时报错
        from payswitch.browser.detector import DetectorPipeline

        detector = DetectorPipeline()

        try:
            # 步骤 0：如果提供了 URL，先导航
            if url:
                nav_step = self._make_step(
                    index=len(steps),
                    description=f"导航到目标页面：{url}",
                )
                logger.info("[SkyvernEngine] 导航到：%s", url)
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                # 等待页面稳定
                await asyncio.sleep(1.5)
                nav_step = nav_step.model_copy(
                    update={"status": "success", "completed_at": _utc_now()}
                )
                steps.append(nav_step)
                history.append(f"已导航到 {url}")

            # 主循环：最多执行 max_steps 步
            for step_num in range(max_steps):
                logger.info(
                    "[SkyvernEngine] 执行第 %d/%d 步…", step_num + 1, max_steps
                )

                # ---- 1. 截图当前页面 ----
                screenshot_b64 = await self._take_screenshot(page)

                # ---- 2. 调用 LLM 分析页面 ----
                try:
                    action = await self._call_llm(
                        screenshot_base64=screenshot_b64,
                        task=task_description,
                        history=history,
                        max_output_tokens=max_output_tokens,
                    )
                except SmartModeError as e:
                    logger.error("[SkyvernEngine] LLM 调用失败：%s", e)
                    raise

                logger.info(
                    "[SkyvernEngine] LLM 指令：action=%s, selector=%r, desc=%s",
                    action.get("action"),
                    action.get("selector", ""),
                    action.get("description", ""),
                )

                # ---- 3. 创建步骤记录 ----
                step_desc = action.get(
                    "description", f"执行 {action.get('action', 'unknown')} 操作"
                )
                current_step = self._make_step(
                    index=len(steps), description=step_desc
                )

                # ---- 4. 如果 LLM 返回 done，表示到达支付环节或任务完成 ----
                if action.get("action") == "done":
                    logger.info(
                        "[SkyvernEngine] LLM 判断任务完成，原因：%s",
                        action.get("reasoning", ""),
                    )
                    current_step = current_step.model_copy(
                        update={"status": "success", "completed_at": _utc_now()}
                    )
                    steps.append(current_step)
                    history.append(f"任务完成：{step_desc}")
                    return steps

                # ---- 5. 执行 LLM 指令 ----
                if pre_action_callback is not None:
                    await pre_action_callback(page, action, len(steps), history)
                action_success = await self._execute_llm_action(page, action)

                if action_success:
                    current_step = current_step.model_copy(
                        update={"status": "success", "completed_at": _utc_now()}
                    )
                    consecutive_no_op = 0
                    history.append(f"成功：{step_desc}（{action.get('reasoning', '')}）")
                else:
                    current_step = current_step.model_copy(
                        update={"status": "failed", "completed_at": _utc_now()}
                    )
                    consecutive_no_op += 1
                    history.append(f"失败：{step_desc}")
                    logger.warning(
                        "[SkyvernEngine] 操作执行失败，连续无效次数：%d/%d",
                        consecutive_no_op,
                        max_no_op,
                    )

                steps.append(current_step)

                # ---- 6. 连续无效操作超限，放弃 ----
                if consecutive_no_op >= max_no_op:
                    raise SmartModeError(
                        f"连续 {max_no_op} 次 LLM 操作均无法执行，任务中止。"
                        f"最后一次操作：{step_desc}"
                    )

                # ---- 7. 等待页面响应 ----
                await asyncio.sleep(1.0)

                # ---- 8. 运行检测器，判断是否到达支付环节 ----
                detection = await detector.scan(page)
                if detection is not None:
                    logger.info(
                        "[SkyvernEngine] 检测到支付环节：%s（%s），停止智能执行",
                        detection.action_type,
                        detection.description,
                    )
                    # 添加一个检测到支付环节的记录步骤
                    detect_step = self._make_step(
                        index=len(steps),
                        description=f"检测到支付环节：{detection.description}",
                    )
                    detect_step = detect_step.model_copy(
                        update={"status": "success", "completed_at": _utc_now()}
                    )
                    steps.append(detect_step)
                    return steps

            # 达到最大步骤数
            raise SmartModeError(
                f"已执行 {max_steps} 步，仍未到达支付环节，任务中止。"
                f"请检查任务描述是否准确，或增大 max_steps 参数。"
            )

        except SmartModeError:
            raise
        except Exception as e:
            # 捕获意外异常并包装为 SmartModeError
            logger.exception("[SkyvernEngine] 意外错误：%s", e)
            raise SmartModeError(f"智能执行过程中发生意外错误：{e}") from e

    async def navigate_and_act(
        self,
        page: Any,
        prompt: str,
        *,
        pre_action_callback: PreActionCallback | None = None,
    ) -> bool:
        """执行单个智能动作（轻量接口）。

        截图当前页面，调用 LLM 分析并执行一个操作。
        适用于需要单步智能辅助的场景。

        Args:
            page:   Playwright 页面实例。
            prompt: 任务描述或动作提示。

        Returns:
            True 表示操作成功，False 表示操作失败或无需操作。

        Raises:
            SmartModeError: 引擎不可用时抛出。
        """
        if not self.is_available():
            raise SmartModeError("智能引擎不可用：请安装 openai 库并配置 LLM API Key")

        screenshot_b64 = await self._take_screenshot(page)
        action = await self._call_llm(
            screenshot_base64=screenshot_b64,
            task=prompt,
            history=[],
            max_output_tokens=1000,
        )

        if action.get("action") == "done":
            logger.info("[SkyvernEngine] navigate_and_act：LLM 判断无需操作")
            return False

        if pre_action_callback is not None:
            await pre_action_callback(page, action, 0, [])
        return await self._execute_llm_action(page, action)

    # ------------------------------------------------------------------
    # 内部方法：LLM 调用
    # ------------------------------------------------------------------

    async def _call_llm(
        self,
        screenshot_base64: str,
        task: str,
        history: list[str],
        max_output_tokens: int,
    ) -> dict[str, Any]:
        """调用 LLM API 分析截图并返回操作指令。

        使用 OpenAI 多模态 API（或兼容接口），将截图和任务描述发送给 LLM，
        要求返回 JSON 格式的操作指令。

        Args:
            screenshot_base64: 页面截图的 base64 编码字符串。
            task:              任务描述文本。
            history:           已执行步骤的描述列表，用于提供上下文。

        Returns:
            包含 action/selector/value/description/reasoning 字段的字典。

        Raises:
            SmartModeError: API 调用失败或返回无效 JSON 时抛出。
        """
        # 构建历史记录文本
        if history:
            history_text = "\n".join(
                f"  {i + 1}. {step}" for i, step in enumerate(history)
            )
        else:
            history_text = "  （无已执行步骤）"

        user_prompt = _USER_PROMPT_TEMPLATE.format(
            task=task,
            history=history_text,
        )

        # 构建多模态消息（文字 + 图片）
        messages = [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/png;base64,{screenshot_base64}",
                            "detail": "high",  # 使用高分辨率分析，提高定位精度
                        },
                    },
                ],
            },
        ]

        logger.debug(
            "[SkyvernEngine] 调用 LLM：model=%s, history_len=%d",
            self._model,
            len(history),
        )

        # 在线程池中运行同步 openai 调用，避免阻塞事件循环
        try:
            response_text = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._call_openai_sync(
                    messages,
                    max_output_tokens=max_output_tokens,
                ),
            )
        except Exception as e:
            logger.error("[SkyvernEngine] LLM API 调用失败：%s", e)
            raise SmartModeError(f"LLM API 调用失败：{e}") from e

        # 解析 JSON 响应
        return self._parse_llm_response(response_text)

    def _call_openai_sync(
        self,
        messages: list[dict],
        *,
        max_output_tokens: int,
    ) -> str:
        """同步调用 OpenAI API（在线程池中执行）。

        Args:
            messages: 符合 OpenAI Chat API 格式的消息列表。

        Returns:
            LLM 返回的文本内容。

        Raises:
            SmartModeError: openai 库未安装或 API 调用失败。
        """
        if not _OPENAI_AVAILABLE or _openai_module is None:
            raise SmartModeError("openai 库未安装，请运行：pip install openai")

        # 懒加载客户端（避免重复初始化）
        if self._client is None:
            client_kwargs: dict[str, Any] = {"api_key": self._api_key}
            if self._base_url:
                client_kwargs["base_url"] = self._openai_base_url(self._base_url)
            self._client = _openai_module.OpenAI(**client_kwargs)

        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=messages,  # type: ignore[arg-type]
                response_format={"type": "json_object"},
                max_tokens=max_output_tokens,
                temperature=0.1,  # 低随机性，确保指令稳定一致
            )
            content = response.choices[0].message.content or ""
            logger.debug(
                "[SkyvernEngine] LLM 原始响应（前 200 字）：%s", content[:200]
            )
            return content
        except _openai_module.AuthenticationError as e:
            raise SmartModeError(f"LLM API Key 无效或已过期：{e}") from e
        except _openai_module.RateLimitError as e:
            raise SmartModeError(f"LLM API 调用频率超限，请稍后重试：{e}") from e
        except _openai_module.APIConnectionError as e:
            raise SmartModeError(f"无法连接到 LLM API，请检查网络：{e}") from e
        except Exception as e:
            raise SmartModeError(f"LLM API 调用失败：{e}") from e

    @staticmethod
    def _openai_base_url(chat_completions_url: str) -> str:
        """Convert a chat-completions endpoint into an OpenAI SDK base_url."""
        normalized = chat_completions_url.rstrip("/")
        suffix = "/chat/completions"
        if normalized.endswith(suffix):
            return normalized[: -len(suffix)]
        return normalized

    def _parse_llm_response(self, response_text: str) -> dict[str, Any]:
        """解析 LLM 返回的 JSON 操作指令。

        Args:
            response_text: LLM 返回的 JSON 字符串。

        Returns:
            解析后的操作指令字典，包含规范化的字段。

        Raises:
            SmartModeError: JSON 解析失败或缺少必要字段时抛出。
        """
        try:
            data = json.loads(response_text)
        except json.JSONDecodeError as e:
            logger.error(
                "[SkyvernEngine] LLM 返回非 JSON 内容：%r", response_text[:300]
            )
            raise SmartModeError(
                f"LLM 返回格式错误（非 JSON）：{e}\n原始内容：{response_text[:200]}"
            ) from e

        # 校验必要字段
        action = data.get("action", "").strip().lower()
        valid_actions = {"click", "fill", "scroll", "wait", "done"}
        if action not in valid_actions:
            logger.warning(
                "[SkyvernEngine] LLM 返回无效 action：%r，强制设为 done", action
            )
            action = "done"

        return {
            "action": action,
            "selector": str(data.get("selector", "")),
            "value": str(data.get("value", "")),
            "description": str(data.get("description", action)),
            "reasoning": str(data.get("reasoning", "")),
        }

    # ------------------------------------------------------------------
    # 内部方法：执行操作
    # ------------------------------------------------------------------

    async def _execute_llm_action(self, page: Any, action: dict[str, Any]) -> bool:
        """根据 LLM 返回的操作指令执行 Playwright 动作。

        支持的动作类型：
        - click：尝试多种方式定位并点击元素
        - fill：在输入框中填写内容
        - scroll：滚动页面
        - wait：等待指定时间

        Args:
            page:   Playwright 页面实例。
            action: LLM 返回的操作指令字典。

        Returns:
            True 表示操作成功执行，False 表示操作失败（找不到元素等）。
        """
        action_type = action.get("action", "")
        selector = action.get("selector", "")
        value = action.get("value", "")
        description = action.get("description", "")

        logger.info(
            "[SkyvernEngine] 执行动作：%s | selector=%r | value=%r",
            action_type,
            selector,
            value,
        )

        try:
            if action_type == "click":
                return await self._do_click(page, selector, description)

            elif action_type == "fill":
                return await self._do_fill(page, selector, value, description)

            elif action_type == "scroll":
                # 滚动页面一屏（向下）
                await page.evaluate("window.scrollBy(0, window.innerHeight * 0.8)")
                logger.debug("[SkyvernEngine] 已向下滚动页面")
                return True

            elif action_type == "wait":
                # 等待 2 秒，让页面加载或动画完成
                await asyncio.sleep(2.0)
                logger.debug("[SkyvernEngine] 已等待 2 秒")
                return True

            elif action_type == "done":
                # done 由 execute_task 主循环处理，此处不应被调用
                logger.debug("[SkyvernEngine] 收到 done 指令（由主循环处理）")
                return True

            else:
                logger.warning("[SkyvernEngine] 未知动作类型：%r", action_type)
                return False

        except Exception as e:
            logger.warning(
                "[SkyvernEngine] 执行动作 %s 时发生异常：%s", action_type, e
            )
            return False

    async def _do_click(self, page: Any, selector: str, description: str) -> bool:
        """尝试多种策略定位并点击元素。

        策略优先级：
        1. 直接使用 CSS/XPath 选择器
        2. 使用文本内容定位（适用于 selector 是文字描述的情况）
        3. 模糊匹配（contains text）

        Args:
            page:        Playwright 页面实例。
            selector:    CSS 选择器或元素文本描述。
            description: 操作描述（用于日志）。

        Returns:
            True 表示点击成功，False 表示找不到元素。
        """
        # 策略 1：直接用 selector 点击（CSS 选择器或精确文本）
        if selector:
            try:
                await page.click(selector, timeout=5000)
                logger.debug("[SkyvernEngine] 点击成功（CSS 选择器）：%r", selector)
                return True
            except Exception:
                logger.debug(
                    "[SkyvernEngine] CSS 选择器点击失败，尝试文本定位：%r", selector
                )

            # 策略 2：用文本内容定位（精确匹配）
            try:
                await page.get_by_text(selector, exact=True).first.click(timeout=5000)
                logger.debug("[SkyvernEngine] 点击成功（精确文本）：%r", selector)
                return True
            except Exception:
                logger.debug(
                    "[SkyvernEngine] 精确文本点击失败，尝试模糊匹配：%r", selector
                )

            # 策略 3：文本模糊匹配
            try:
                await page.get_by_text(selector).first.click(timeout=5000)
                logger.debug("[SkyvernEngine] 点击成功（模糊文本）：%r", selector)
                return True
            except Exception:
                logger.debug(
                    "[SkyvernEngine] 所有点击策略均失败：%r", selector
                )

            # 策略 4：使用 role 定位按钮/链接
            try:
                await page.get_by_role("button", name=selector).first.click(
                    timeout=3000
                )
                logger.debug("[SkyvernEngine] 点击成功（button role）：%r", selector)
                return True
            except Exception:
                pass

            try:
                await page.get_by_role("link", name=selector).first.click(
                    timeout=3000
                )
                logger.debug("[SkyvernEngine] 点击成功（link role）：%r", selector)
                return True
            except Exception:
                pass

        logger.warning(
            "[SkyvernEngine] 无法找到可点击元素：selector=%r, desc=%s",
            selector,
            description,
        )
        return False

    async def _do_fill(
        self, page: Any, selector: str, value: str, description: str
    ) -> bool:
        """在输入框中填写内容。

        Args:
            page:        Playwright 页面实例。
            selector:    目标输入框的 CSS 选择器或 placeholder 文本。
            value:       要填写的值。
            description: 操作描述（用于日志）。

        Returns:
            True 表示填写成功，False 表示找不到输入框。
        """
        if not value:
            logger.warning("[SkyvernEngine] fill 动作但 value 为空，跳过")
            return False

        # 策略 1：直接用 selector 定位输入框
        if selector:
            try:
                await page.fill(selector, value, timeout=5000)
                logger.debug(
                    "[SkyvernEngine] 填写成功（CSS 选择器）：%r = %r", selector, value
                )
                return True
            except Exception:
                logger.debug(
                    "[SkyvernEngine] CSS 选择器填写失败，尝试 placeholder：%r", selector
                )

            # 策略 2：用 placeholder 定位
            try:
                await page.get_by_placeholder(selector).first.fill(value, timeout=5000)
                logger.debug(
                    "[SkyvernEngine] 填写成功（placeholder）：%r = %r",
                    selector,
                    value,
                )
                return True
            except Exception:
                logger.debug(
                    "[SkyvernEngine] placeholder 填写失败，尝试 label：%r", selector
                )

            # 策略 3：用 label 文本定位
            try:
                await page.get_by_label(selector).first.fill(value, timeout=5000)
                logger.debug(
                    "[SkyvernEngine] 填写成功（label）：%r = %r", selector, value
                )
                return True
            except Exception:
                pass

        logger.warning(
            "[SkyvernEngine] 无法找到输入框：selector=%r, value=%r, desc=%s",
            selector,
            value,
            description,
        )
        return False

    # ------------------------------------------------------------------
    # 工具方法
    # ------------------------------------------------------------------

    @staticmethod
    async def _take_screenshot(page: Any) -> str:
        """截取当前页面并返回 base64 编码的 PNG 图像。

        Args:
            page: Playwright 页面实例。

        Returns:
            base64 编码的截图字符串（不含 data URI 前缀）。
        """
        # 截取全屏 PNG（bytes）
        screenshot_bytes: bytes = await page.screenshot(
            type="png",
            full_page=False,  # 仅截取可视区域，减少图像大小
        )
        # 编码为 base64 字符串
        return base64.b64encode(screenshot_bytes).decode("ascii")

    @staticmethod
    def _make_step(index: int, description: str) -> StepRecord:
        """创建一个初始状态为 pending 的 StepRecord。

        Args:
            index:       步骤序号（从 0 开始）。
            description: 步骤描述（中文）。

        Returns:
            新创建的 StepRecord 实例。
        """
        return StepRecord(
            step_index=index,
            description=description,
            status="pending",
            started_at=_utc_now(),
        )


# -----------------------------------------------------------------------
# 模块级工具函数
# -----------------------------------------------------------------------


def _utc_now() -> datetime:
    """返回当前 UTC 时间（含时区信息）。"""
    return datetime.now(UTC)
