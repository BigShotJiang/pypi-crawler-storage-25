"""noVNC 会话管理模块。

在无桌面环境（Linux 服务器 / Docker 容器）下，通过 noVNC 让人类
远程查看和操作 Playwright 控制的浏览器。

技术栈：
    Xvfb（虚拟显示）→ x11vnc（VNC 服务）→ websockify + noVNC（Web 客户端）

典型部署流程：
    1. Xvfb 在 :99 上创建一个 1280x800 的虚拟帧缓冲区
    2. x11vnc 将 :99 的画面通过 VNC 协议暴露到 5900 端口
    3. websockify 将 VNC TCP 流量桥接为 WebSocket，同时托管 noVNC 静态文件
    4. 用户通过浏览器访问 http://host:6080/vnc.html 即可看到远程画面
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import secrets
import shutil
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    # asyncio.subprocess.Process 在运行时可通过 asyncio.create_subprocess_exec 获得，
    # 仅用于类型标注时导入，避免 TYPE_CHECKING 以外的开销
    from asyncio.subprocess import Process

logger = logging.getLogger(__name__)

# noVNC 静态文件在常见 Linux 发行版中的默认安装路径
_NOVNC_WEB_PATHS: list[str] = [
    "/usr/share/novnc",
    "/usr/share/noVNC",
    "/opt/novnc",
    "/opt/noVNC",
]

# 需要检测的系统可执行文件
_REQUIRED_BINARIES: list[str] = ["Xvfb", "x11vnc", "websockify"]


class NoVNCError(Exception):
    """noVNC 会话管理基础异常"""


class NoVNCNotSupportedError(NoVNCError):
    """当前平台不支持 noVNC（如 Windows / macOS）"""


class NoVNCDependencyError(NoVNCError):
    """缺少必要的系统依赖"""


class NoVNCManager:
    """noVNC 会话管理（远程 / Docker 场景）。

    在无桌面环境（Linux 服务器 / Docker 容器）下，通过 noVNC 让人类
    远程查看和操作 Playwright 控制的浏览器。

    技术栈：Xvfb（虚拟显示）→ x11vnc（VNC 服务）→ websockify + noVNC（Web 客户端）

    使用示例::

        manager = NoVNCManager(port=6080)
        url = await manager.start()
        print(f"请打开浏览器访问：{url}")
        # ... 业务逻辑 ...
        await manager.stop()

    也可配合 async with 使用（目前不直接支持，建议在 try/finally 中调用 stop）。
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6080,
        vnc_port: int = 5900,
        display: str = ":99",
    ) -> None:
        """初始化 NoVNCManager。

        Args:
            host:     noVNC 监听主机名或 IP，用于构造访问 URL。默认 "localhost"。
            port:     noVNC Web 端口，用户通过浏览器访问此端口。默认 6080。
            vnc_port: VNC 协议端口，x11vnc 监听此端口，websockify 连接此端口。默认 5900。
            display:  X11 虚拟显示编号，传给 Xvfb 和 x11vnc。默认 ":99"。
        """
        self._host = host
        self._port = port
        self._vnc_port = vnc_port
        self._display = display

        # 启动的子进程列表，stop() 时统一终止
        self._processes: list[Process] = []

        # 每次 start() 生成一个随机令牌，可附加到 URL 作为简单的访问控制标识
        # 注意：当前实现不强制 websockify 校验此令牌，仅用于 URL 携带标识
        self._session_token: str = secrets.token_urlsafe(16)

        # 标记服务栈是否已启动
        self._running: bool = False

    # ------------------------------------------------------------------
    # 公开接口
    # ------------------------------------------------------------------

    async def start(self) -> str:
        """启动 noVNC 服务栈，返回访问 URL。

        按顺序执行：
        1. 平台检测 —— Windows / macOS 不支持，直接返回提示信息
        2. 依赖检测 —— 检查 Xvfb、x11vnc、websockify 是否已安装
        3. 启动 Xvfb 虚拟显示
        4. 等待 Xvfb 就绪（短暂延迟）
        5. 启动 x11vnc
        6. 启动 websockify（含 noVNC 静态文件服务）
        7. 设置 DISPLAY 环境变量，供后续 Playwright 进程使用
        8. 返回 noVNC 访问 URL

        Returns:
            str: noVNC 访问 URL（格式：http://host:port/vnc.html?...）；
                 若平台不支持，返回说明字符串。

        Raises:
            NoVNCDependencyError: 缺少必要的系统可执行文件。
            NoVNCError: 子进程启动失败。
        """
        # 1. 平台检测：Windows 和 macOS 上没有 Xvfb / x11vnc
        system = platform.system()
        if system in ("Windows", "Darwin"):
            msg = (
                f"[noVNC] 当前平台为 {system}，不支持 Xvfb + x11vnc 方案。\n"
                "请在 Linux 服务器或 Docker 容器中使用 noVNC 功能。\n"
                "本地开发请使用有头浏览器模式（DisplayMode.headed）。"
            )
            logger.warning(msg)
            return msg

        if self._running:
            logger.warning("[noVNC] 服务已在运行中，跳过重复启动")
            return self.get_url(self._session_token)

        # 2. 依赖检测
        missing = self._check_dependencies()
        if missing:
            raise NoVNCDependencyError(
                f"[noVNC] 缺少以下系统依赖，请先安装：{', '.join(missing)}\n"
                "Ubuntu/Debian 示例：\n"
                "  apt-get install -y xvfb x11vnc novnc websockify"
            )

        # 3. 启动 Xvfb 虚拟显示
        logger.info("[noVNC] 正在启动 Xvfb（display=%s）…", self._display)
        xvfb_proc = await self._spawn(
            "Xvfb",
            self._display,
            "-screen", "0", "1280x800x24",
            # 不捕获输出，让日志直接流向父进程 stderr
        )
        self._processes.append(xvfb_proc)
        logger.info("[noVNC] Xvfb 已启动（PID=%d）", xvfb_proc.pid)

        # 4. 等待 Xvfb 完成初始化（通常 < 1 秒）
        await asyncio.sleep(1.0)

        # 5. 启动 x11vnc，将虚拟显示画面通过 VNC 协议暴露出去
        logger.info("[noVNC] 正在启动 x11vnc（rfbport=%d）…", self._vnc_port)
        x11vnc_proc = await self._spawn(
            "x11vnc",
            "-display", self._display,
            "-forever",        # 客户端断开后不退出
            "-nopw",           # 不要求密码（内网 / 容器场景）
            "-rfbport", str(self._vnc_port),
            "-quiet",          # 减少噪声日志
        )
        self._processes.append(x11vnc_proc)
        logger.info("[noVNC] x11vnc 已启动（PID=%d）", x11vnc_proc.pid)

        # x11vnc 建立 VNC 监听需要短暂时间
        await asyncio.sleep(0.5)

        # 6. 查找 noVNC 静态文件目录
        novnc_web = self._find_novnc_web_path()
        logger.info("[noVNC] noVNC 静态文件路径：%s", novnc_web)

        # 启动 websockify，将 VNC TCP 流桥接为 WebSocket，并托管 noVNC 静态文件
        logger.info(
            "[noVNC] 正在启动 websockify（web_port=%d → vnc_port=%d）…",
            self._port,
            self._vnc_port,
        )
        websockify_args: list[str] = [
            "websockify",
            "--web", novnc_web,
            str(self._port),
            f"localhost:{self._vnc_port}",
        ]
        websockify_proc = await self._spawn(*websockify_args)
        self._processes.append(websockify_proc)
        logger.info("[noVNC] websockify 已启动（PID=%d）", websockify_proc.pid)

        # 7. 将 DISPLAY 写入当前进程环境变量，后续通过 subprocess 启动的程序会继承
        os.environ["DISPLAY"] = self._display
        logger.info("[noVNC] 已设置环境变量 DISPLAY=%s", self._display)

        self._running = True

        # 8. 构造并返回访问 URL
        url = self.get_url(self._session_token)
        logger.info("[noVNC] 服务栈启动完成，访问地址：%s", url)
        return url

    async def stop(self) -> None:
        """停止所有子进程并清理资源。

        按照启动顺序的逆序终止：先停 websockify，再停 x11vnc，最后停 Xvfb。
        每个进程先发送 SIGTERM，等待 3 秒后若仍在运行则强制 SIGKILL。
        安全：多次调用不会报错。
        """
        if not self._running and not self._processes:
            logger.debug("[noVNC] 服务未在运行，无需停止")
            return

        logger.info("[noVNC] 正在停止所有子进程（共 %d 个）…", len(self._processes))

        # 逆序终止，避免依赖链问题（websockify 先停，Xvfb 最后停）
        for proc in reversed(self._processes):
            await self._terminate_process(proc)

        self._processes.clear()
        self._running = False
        logger.info("[noVNC] 所有子进程已停止")

    def get_url(self, session_token: str | None = None) -> str:
        """构造并返回 noVNC 访问 URL。

        URL 格式：
            http://localhost:{port}/vnc.html?autoconnect=true&resize=scale

        若提供 session_token，会附加到 URL 的 hash 部分（不影响实际连接，
        仅作为会话标识供调用方记录和展示）。

        Args:
            session_token: 可选的会话令牌字符串。

        Returns:
            完整的 noVNC 访问 URL 字符串。
        """
        base = f"http://{self._host}:{self._port}/vnc.html?autoconnect=true&resize=scale"
        if session_token:
            # 将令牌附加到 URL fragment，不影响 websockify 路由
            return f"{base}#{session_token}"
        return base

    def get_info(self) -> dict:
        """返回当前 noVNC 服务的运行信息。

        供 DisplayManager 获取实际运行的地址和 DISPLAY 编号。

        Returns:
            包含 url、display、running 等键的字典。
        """
        return {
            "url": self.get_url(self._session_token),
            "display": self._display,
            "running": self._running,
            "host": self._host,
            "port": self._port,
        }

    def is_running(self) -> bool:
        """检查 noVNC 服务栈是否已启动并在运行中。

        Returns:
            True 表示服务正在运行；False 表示未启动或已停止。
        """
        return self._running

    def get_display(self) -> str:
        """获取当前配置的 X11 DISPLAY 环境变量值。

        Returns:
            如 ":99" 格式的显示编号字符串。
        """
        return self._display

    def _check_dependencies(self) -> list[str]:
        """检查系统依赖是否已安装，返回缺失的依赖列表。

        通过 shutil.which() 检测可执行文件是否在 PATH 中可找到。
        同时检查 noVNC 静态文件目录是否存在。

        Returns:
            缺失的依赖名称列表；若所有依赖都满足则返回空列表。
        """
        missing: list[str] = []

        # 检查三个核心可执行文件
        for binary in _REQUIRED_BINARIES:
            if shutil.which(binary) is None:
                missing.append(binary)
                logger.debug("[noVNC] 未找到可执行文件：%s", binary)

        # 检查 noVNC 静态文件目录
        novnc_web = self._find_novnc_web_path()
        if novnc_web is None:
            missing.append("novnc-web-files")
            logger.debug(
                "[noVNC] 未找到 noVNC 静态文件目录（已检查路径：%s）",
                _NOVNC_WEB_PATHS,
            )

        return missing

    # ------------------------------------------------------------------
    # 内部辅助方法
    # ------------------------------------------------------------------

    @staticmethod
    async def _spawn(*args: str) -> Process:
        """使用 asyncio.create_subprocess_exec 启动子进程。

        将 stdout / stderr 重定向到 /dev/null，避免子进程输出污染父进程日志。
        如需调试，可临时改为 asyncio.subprocess.PIPE。

        Args:
            *args: 可执行文件路径及其参数，第一个元素为可执行文件名。

        Returns:
            已启动的 asyncio.subprocess.Process 对象。

        Raises:
            NoVNCError: 子进程启动失败（如可执行文件不存在）。
        """
        try:
            proc = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            return proc
        except FileNotFoundError as exc:
            raise NoVNCError(
                f"[noVNC] 启动子进程失败，找不到可执行文件：{args[0]}"
            ) from exc
        except OSError as exc:
            raise NoVNCError(
                f"[noVNC] 启动子进程时发生系统错误：{exc}"
            ) from exc

    @staticmethod
    async def _terminate_process(proc: Process) -> None:
        """优雅终止单个子进程。

        流程：
        1. 尝试 proc.terminate()（发送 SIGTERM）
        2. 等待最多 3 秒
        3. 若进程仍未退出，强制 proc.kill()（发送 SIGKILL）

        Args:
            proc: 要终止的子进程对象。
        """
        if proc.returncode is not None:
            # 进程已经自然退出，无需操作
            logger.debug("[noVNC] 进程（PID=%d）已退出，跳过终止", proc.pid)
            return

        logger.debug("[noVNC] 正在终止进程（PID=%d）…", proc.pid)
        try:
            # 先发 SIGTERM，给进程机会做清理
            proc.terminate()
        except ProcessLookupError:
            # 进程在 terminate() 之前已退出，忽略
            logger.debug("[noVNC] 进程（PID=%d）已不存在", proc.pid)
            return

        try:
            # 等待进程退出，最多 3 秒
            await asyncio.wait_for(proc.wait(), timeout=3.0)
            logger.debug("[noVNC] 进程（PID=%d）已正常退出", proc.pid)
        except TimeoutError:
            # SIGTERM 超时，改用 SIGKILL 强制终止
            logger.warning("[noVNC] 进程（PID=%d）未响应 SIGTERM，强制 kill", proc.pid)
            try:
                proc.kill()
                await proc.wait()
            except ProcessLookupError:
                # kill 时进程已退出，忽略
                pass

    @staticmethod
    def _find_novnc_web_path() -> str | None:
        """在已知路径中查找 noVNC 静态文件目录。

        Returns:
            找到的第一个有效路径字符串；若均不存在则返回 None。
        """
        for path in _NOVNC_WEB_PATHS:
            if os.path.isdir(path):
                return path
        return None
