"""浏览器 Profile 管理模块。

负责管理多平台的 Playwright persistent context 目录及其元数据，
包括创建、读取、更新和删除操作。

存储约定：
  {data_dir}/{platform}/metadata.json   — Profile 元数据（JSON）
  {data_dir}/{platform}/browser_data/   — Playwright persistent context 数据
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Literal

from payswitch.models.profile import PlatformProfile

# 会话过期阈值：超过该天数未使用则视为 expired
_SESSION_EXPIRY_DAYS = 7

# 元数据文件名约定
_METADATA_FILENAME = "metadata.json"

# Playwright persistent context 子目录名
_BROWSER_DATA_DIRNAME = "browser_data"


class ProfileManager:
    """管理多平台的浏览器 Profile（登录状态）。

    每个平台对应 data_dir 下的一个子目录，子目录名即为平台标识符。
    目录内存放 metadata.json（Profile 元数据）和 browser_data/（Playwright 会话数据）。
    """

    def __init__(self, data_dir: Path) -> None:
        """初始化 ProfileManager。

        Args:
            data_dir: 所有 Profile 的根目录，通常为 ~/.payswitch/profiles/
        """
        self._data_dir = Path(data_dir).expanduser()
        # 确保根目录存在
        self._data_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # 内部辅助方法
    # ------------------------------------------------------------------

    def _platform_dir(self, platform: str) -> Path:
        """返回指定平台的根目录路径。"""
        return self._data_dir / platform

    def _metadata_path(self, platform: str) -> Path:
        """返回指定平台元数据文件的路径。"""
        return self._platform_dir(platform) / _METADATA_FILENAME

    # ------------------------------------------------------------------
    # 公开接口
    # ------------------------------------------------------------------

    def get_profile(self, platform: str) -> PlatformProfile | None:
        """获取指定平台的 Profile 元数据。

        Args:
            platform: 平台标识符，如 "deepseek"。

        Returns:
            已解析的 PlatformProfile 实例；若 Profile 不存在则返回 None。
        """
        metadata_path = self._metadata_path(platform)
        if not metadata_path.exists():
            return None
        return self._load_profile(metadata_path)

    def list_profiles(self) -> list[PlatformProfile]:
        """列出所有已保存的 Profile。

        遍历 data_dir 下所有子目录，读取其中的 metadata.json。
        无法解析的元数据文件将被跳过。

        Returns:
            按平台标识符字母顺序排列的 PlatformProfile 列表。
        """
        profiles: list[PlatformProfile] = []
        for platform_dir in sorted(self._data_dir.iterdir()):
            if not platform_dir.is_dir():
                continue
            metadata_path = platform_dir / _METADATA_FILENAME
            if not metadata_path.exists():
                continue
            try:
                profiles.append(self._load_profile(metadata_path))
            except Exception:
                # 损坏的元数据文件跳过，不影响其他 Profile 的列举
                continue
        return profiles

    def create_profile(
        self,
        platform: str,
        display_name: str,
        top_up_url: str | None = None,
    ) -> PlatformProfile:
        """创建新的 Profile 目录结构和元数据。

        若同名 Platform 已存在，则直接返回现有的 Profile，不做覆盖。

        Args:
            platform:     平台标识符（小写字母+数字+下划线），如 "deepseek"。
            display_name: 平台展示名称，如 "DeepSeek"。
            top_up_url:   充值页面 URL（可选）。

        Returns:
            新建或已存在的 PlatformProfile 实例。
        """
        # 如果 Profile 已存在，直接返回，避免意外覆盖登录状态
        existing = self.get_profile(platform)
        if existing is not None:
            return existing

        # 创建平台目录及 Playwright 数据子目录
        platform_dir = self._platform_dir(platform)
        browser_data_dir = platform_dir / _BROWSER_DATA_DIRNAME
        browser_data_dir.mkdir(parents=True, exist_ok=True)

        # 构造新 Profile 元数据
        profile = PlatformProfile(
            platform=platform,
            display_name=display_name,
            profile_dir=browser_data_dir,
            top_up_url=top_up_url,
            status="unknown",
        )

        self.save_profile(profile)
        return profile

    def get_profile_dir(self, platform: str) -> Path:
        """获取 Profile 的 Playwright persistent context 目录。

        该目录用于 playwright.chromium.launch_persistent_context(user_data_dir=...) 。
        即使 Profile 元数据不存在，也会返回约定路径（目录可能尚未创建）。

        Args:
            platform: 平台标识符。

        Returns:
            Playwright persistent context 数据目录路径。
        """
        return self._platform_dir(platform) / _BROWSER_DATA_DIRNAME

    def update_login_time(self, platform: str) -> None:
        """更新指定平台 Profile 的登录时间和使用时间，并将状态置为 active。

        Args:
            platform: 平台标识符。

        Raises:
            FileNotFoundError: 若对应 Profile 不存在。
        """
        profile = self._require_profile(platform)
        now = datetime.now(UTC)
        updated = profile.model_copy(
            update={
                "logged_in_at": now,
                "last_used_at": now,
                "status": "active",
            }
        )
        self.save_profile(updated)

    def check_session(self, platform: str) -> Literal["active", "expired", "unknown"]:
        """检查登录状态是否可能已过期。

        判断策略：
          - 若 Profile 不存在，返回 "unknown"。
          - 若 last_used_at 距今超过 7 天，将状态更新为 "expired" 并返回。
          - 否则返回 Profile 中记录的 status 字段值。

        Args:
            platform: 平台标识符。

        Returns:
            "active" / "expired" / "unknown" 之一。
        """
        profile = self.get_profile(platform)
        if profile is None:
            return "unknown"

        # 若有明确的最近使用时间，以此判断是否过期
        if profile.last_used_at is not None:
            expiry_threshold = datetime.now(UTC) - timedelta(
                days=_SESSION_EXPIRY_DAYS
            )
            if profile.last_used_at < expiry_threshold:
                # 将磁盘上的状态同步更新为 expired
                expired_profile = profile.model_copy(update={"status": "expired"})
                self.save_profile(expired_profile)
                return "expired"

        return profile.status

    def delete_profile(self, platform: str) -> None:
        """删除 Profile（退出登录），移除该平台的所有本地数据。

        若 Profile 不存在，静默返回不报错。

        Args:
            platform: 平台标识符。
        """
        import shutil

        platform_dir = self._platform_dir(platform)
        if platform_dir.exists():
            shutil.rmtree(platform_dir)

    def save_profile(self, profile: PlatformProfile) -> None:
        """将 Profile 元数据序列化后写入磁盘。

        使用 Pydantic model_dump 生成可 JSON 序列化的字典，
        Path 对象和 datetime 对象统一转换为字符串。

        Args:
            profile: 要持久化的 PlatformProfile 实例。
        """
        metadata_path = self._metadata_path(profile.platform)
        # 确保平台目录存在（create_profile 之外的调用场景也能正常写入）
        metadata_path.parent.mkdir(parents=True, exist_ok=True)

        # mode="json" 确保 Path / datetime 等类型被序列化为 JSON 兼容格式
        data = profile.model_dump(mode="json")

        metadata_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # ------------------------------------------------------------------
    # 私有辅助
    # ------------------------------------------------------------------

    def _load_profile(self, metadata_path: Path) -> PlatformProfile:
        """从磁盘读取并反序列化 PlatformProfile。

        Args:
            metadata_path: metadata.json 文件的完整路径。

        Returns:
            反序列化后的 PlatformProfile 实例。

        Raises:
            json.JSONDecodeError: 文件内容不是合法 JSON。
            pydantic.ValidationError: JSON 结构与模型不匹配。
        """
        raw = json.loads(metadata_path.read_text(encoding="utf-8"))
        return PlatformProfile.model_validate(raw)

    def _require_profile(self, platform: str) -> PlatformProfile:
        """获取 Profile，若不存在则抛出 FileNotFoundError。

        Args:
            platform: 平台标识符。

        Returns:
            已存在的 PlatformProfile 实例。

        Raises:
            FileNotFoundError: Profile 不存在。
        """
        profile = self.get_profile(platform)
        if profile is None:
            raise FileNotFoundError(
                f"平台 {platform!r} 的 Profile 不存在，"
                f"请先调用 create_profile() 创建。"
            )
        return profile
