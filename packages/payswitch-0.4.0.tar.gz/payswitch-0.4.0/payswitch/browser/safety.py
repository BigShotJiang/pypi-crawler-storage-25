"""浏览器安全层——保护敏感支付操作。

在 AI Agent 自动操作浏览器时，对即将访问的 URL、当前页面内容进行安全检查，
防止访问钓鱼网站、误操作敏感输入框，并在需要人工确认时主动标记。
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

from pydantic import BaseModel

if TYPE_CHECKING:
    # 仅在类型检查阶段导入，运行时不引入 playwright 依赖
    pass

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 敏感字段关键词（字段 type 或 name/id 属性中出现即视为敏感）
# ---------------------------------------------------------------------------
_SENSITIVE_FIELD_KEYWORDS: frozenset[str] = frozenset(
    [
        "password",
        "cvv",
        "cvc",
        "card_number",
        "card-number",
        "cardnumber",
        "expiry",
        "exp_month",
        "exp_year",
        "支付密码",
        "银行卡号",
    ]
)

# ---------------------------------------------------------------------------
# 敏感域名模式——域名中包含这些关键词时，仅发出告警，不阻断导航
# ---------------------------------------------------------------------------
_SENSITIVE_DOMAIN_PATTERNS: tuple[str, ...] = ("bank", "pay", "checkout")

# ---------------------------------------------------------------------------
# 已知钓鱼/恶意域名黑名单（示例列表，生产环境应接入实时威胁情报）
# ---------------------------------------------------------------------------
_PHISHING_DOMAIN_BLACKLIST: frozenset[str] = frozenset(
    [
        "paypa1.com",          # 伪装成 PayPal
        "paypai.com",          # 伪装成 PayPal
        "secure-paypal.net",   # 伪装成 PayPal 安全页面
        "alipay-verify.com",   # 伪装成支付宝验证
        "wechatpay-help.com",  # 伪装成微信支付帮助页
        "bank0fchina.com",     # 伪装成中国银行（0 替换 o）
        "icbc-secure.net",     # 伪装成工商银行安全页
    ]
)

# ---------------------------------------------------------------------------
# 合法 URL scheme 白名单（其他 scheme 一律拒绝）
# ---------------------------------------------------------------------------
_ALLOWED_SCHEMES: frozenset[str] = frozenset(["https", "http"])


class SafetyCheckResult(BaseModel):
    """安全检查结果。"""

    safe: bool
    reason: str | None = None       # 拒绝/告警原因（中文），安全时为 None
    requires_human: bool = False    # 是否需要人工介入确认


class BrowserSafety:
    """浏览器安全层，保护敏感的支付/表单操作。

    在导航前调用 ``check_navigation`` 验证目标 URL；
    在页面加载后调用 ``check_page_safety`` 检测敏感元素。

    用法示例::

        safety = BrowserSafety(domain_whitelist=["alipay.com", "pay.weixin.qq.com"])

        result = await safety.check_navigation("https://alipay.com/login")
        if not result.safe:
            raise RuntimeError(result.reason)

        result = await safety.check_page_safety(page)
        if result.requires_human:
            await human_confirm(result.reason)
    """

    def __init__(self, domain_whitelist: list[str] | None = None) -> None:
        """初始化安全层。

        Args:
            domain_whitelist: 允许访问的域名列表。传入空列表或 ``None`` 表示不限制域名。
                匹配规则：目标域名等于白名单项，或以 ``.白名单项`` 结尾（支持子域名）。
                示例：``["alipay.com"]`` 同时允许 ``www.alipay.com``、``auth.alipay.com``。
        """
        # 空列表与 None 均视为"不限制"
        self._whitelist: list[str] = domain_whitelist if domain_whitelist else []
        logger.debug(
            "BrowserSafety 初始化 | 白名单域名数：%d",
            len(self._whitelist),
        )

    # ------------------------------------------------------------------
    # 公开接口
    # ------------------------------------------------------------------

    async def check_navigation(self, url: str) -> SafetyCheckResult:
        """检查即将访问的 URL 是否安全。

        检查顺序：
        1. URL 格式合法性（必须是合法的 http/https URL）
        2. 钓鱼域名黑名单
        3. 域名白名单（若已配置）

        Args:
            url: 即将导航的目标 URL。

        Returns:
            ``SafetyCheckResult``，``safe=False`` 时应中止导航。
        """
        # --- 步骤 1：URL 格式检查 ---
        format_result = self._check_url_format(url)
        if not format_result.safe:
            logger.warning("URL 格式检查失败：%s | 原因：%s", url, format_result.reason)
            return format_result

        # 解析域名（此时 urlparse 已经验证过格式，可放心使用）
        parsed = urlparse(url)
        domain = parsed.netloc.lower()

        # 去掉端口号（如 example.com:8080 → example.com）
        domain = domain.split(":")[0]

        # --- 步骤 2：钓鱼域名黑名单检查 ---
        phishing_result = self._check_phishing_blacklist(domain)
        if not phishing_result.safe:
            logger.warning("钓鱼域名拦截：%s | 原因：%s", domain, phishing_result.reason)
            return phishing_result

        # --- 步骤 3：域名白名单检查 ---
        whitelist_result = self._check_whitelist(domain)
        if not whitelist_result.safe:
            logger.warning("域名不在白名单：%s", domain)
            return whitelist_result

        # --- 敏感域名告警（不阻断，仅记录日志）---
        if any(pattern in domain for pattern in _SENSITIVE_DOMAIN_PATTERNS):
            logger.info("访问敏感域名（仅告警）：%s", domain)

        logger.debug("URL 安全检查通过：%s", url)
        return SafetyCheckResult(safe=True)

    async def check_page_safety(self, page: Any) -> SafetyCheckResult:
        """检查当前页面是否包含敏感元素，决定是否需要人工介入。

        检测逻辑（通过 JavaScript 在页面内执行）：
        - 页面中存在 ``type="password"`` 输入框 → 标记 ``requires_human=True``
        - 页面中存在 CVV / 卡号等敏感 name/id 属性的输入框 → 标记 ``requires_human=True``
        - 页面 URL 或 title 包含银行/支付关键词 → 标记 ``requires_human=True``

        Args:
            page: Playwright 的 ``Page`` 对象（运行时传入，不在本模块 import）。

        Returns:
            ``SafetyCheckResult``，``requires_human=True`` 时 Agent 应暂停并等待人工确认。
        """
        # 用 JS 在页面上下文中收集敏感信号，避免多次 round-trip
        js_snippet = """
        (() => {
            const signals = [];

            // 检测 type="password" 输入框
            const passwordInputs = document.querySelectorAll('input[type="password"]');
            if (passwordInputs.length > 0) {
                signals.push('password_field');
            }

            // 检测敏感 name/id 属性（不区分大小写）
            const sensitiveAttrs = [
                'cvv', 'cvc', 'card_number', 'card-number', 'cardnumber',
                'expiry', 'exp_month', 'exp_year', '支付密码', '银行卡号'
            ];
            const allInputs = document.querySelectorAll('input, select, textarea');
            for (const input of allInputs) {
                const nameAttr = (input.name || '').toLowerCase();
                const idAttr   = (input.id   || '').toLowerCase();
                for (const keyword of sensitiveAttrs) {
                    if (nameAttr.includes(keyword) || idAttr.includes(keyword)) {
                        signals.push('sensitive_field:' + keyword);
                        break;
                    }
                }
            }

            // 检测页面标题或 URL 中的银行/支付关键词
            const bankKeywords = ['bank', 'pay', 'checkout', '银行', '支付', '结算', '付款'];
            const titleAndUrl  = (document.title + ' ' + window.location.href).toLowerCase();
            for (const kw of bankKeywords) {
                if (titleAndUrl.includes(kw)) {
                    signals.push('bank_or_payment_page');
                    break;
                }
            }

            return signals;
        })()
        """

        try:
            # page 来自调用方（Playwright Page 对象），此处用 Any 类型接收
            signals: list[str] = await page.evaluate(js_snippet)
        except Exception as exc:  # noqa: BLE001
            # JS 执行失败时保守处理：要求人工确认
            logger.warning("页面安全 JS 执行失败，保守标记需要人工介入：%s", exc)
            return SafetyCheckResult(
                safe=True,
                reason="页面安全检测脚本执行失败，建议人工确认后继续",
                requires_human=True,
            )

        if not signals:
            logger.debug("页面安全检查通过，未发现敏感元素")
            return SafetyCheckResult(safe=True)

        # 根据信号构建原因说明
        reasons: list[str] = []
        for signal in signals:
            if signal == "password_field":
                reasons.append("检测到密码输入框")
            elif signal.startswith("sensitive_field:"):
                keyword = signal.split(":", 1)[1]
                reasons.append(f"检测到敏感字段（{keyword}）")
            elif signal == "bank_or_payment_page":
                reasons.append("检测到银行/支付页面特征")

        reason_text = "；".join(reasons)
        logger.info("页面安全检查：需要人工介入 | 原因：%s", reason_text)

        return SafetyCheckResult(
            safe=True,            # 页面本身不一定"不安全"，只是需要人工确认
            reason=reason_text,
            requires_human=True,
        )

    def is_sensitive_field(self, field_type: str, field_name: str) -> bool:
        """判断表单字段是否为敏感字段。

        Args:
            field_type: 字段的 HTML type 属性值，如 ``"password"``、``"text"``。
            field_name: 字段的 name 或 id 属性值。

        Returns:
            ``True`` 表示该字段是敏感字段，Agent 不应自动填写。
        """
        # type="password" 直接判定为敏感
        if field_type.lower() == "password":
            return True

        # name/id 属性中包含任意敏感关键词则判定为敏感
        field_name_lower = field_name.lower()
        return any(keyword in field_name_lower for keyword in _SENSITIVE_FIELD_KEYWORDS)

    def is_domain_allowed(self, domain: str) -> bool:
        """检查域名是否在白名单中。

        白名单为空时允许所有域名。支持子域名匹配：
        白名单项 ``alipay.com`` 同时允许 ``www.alipay.com``。

        Args:
            domain: 待检查的域名（不含端口号和协议前缀）。

        Returns:
            ``True`` 表示该域名被允许访问。
        """
        if not self._whitelist:
            # 未配置白名单，放行所有域名
            return True

        domain_lower = domain.lower()
        for allowed in self._whitelist:
            allowed_lower = allowed.lower()
            # 精确匹配（如 alipay.com）
            if domain_lower == allowed_lower:
                return True
            # 子域名匹配（如 www.alipay.com 匹配白名单项 alipay.com）
            if domain_lower.endswith("." + allowed_lower):
                return True

        return False

    # ------------------------------------------------------------------
    # 内部辅助方法
    # ------------------------------------------------------------------

    def _check_url_format(self, url: str) -> SafetyCheckResult:
        """验证 URL 格式是否合法。

        Args:
            url: 待验证的 URL 字符串。

        Returns:
            ``SafetyCheckResult``。
        """
        if not url or not isinstance(url, str):
            return SafetyCheckResult(safe=False, reason="URL 不能为空")

        url = url.strip()

        try:
            parsed = urlparse(url)
        except Exception:  # noqa: BLE001
            return SafetyCheckResult(safe=False, reason=f"URL 格式无法解析：{url}")

        # 检查 scheme
        if parsed.scheme not in _ALLOWED_SCHEMES:
            return SafetyCheckResult(
                safe=False,
                reason=(
                    f"不支持的协议 '{parsed.scheme}'，仅允许 http/https"
                    if parsed.scheme
                    else "URL 缺少协议前缀（http:// 或 https://）"
                ),
            )

        # 检查 netloc（域名）不能为空
        if not parsed.netloc:
            return SafetyCheckResult(safe=False, reason="URL 缺少域名部分")

        # 简单校验域名格式：只允许字母、数字、连字符、点、冒号（用于端口）
        domain_with_port = parsed.netloc
        if not re.match(r"^[a-zA-Z0-9.\-:]+$", domain_with_port):
            return SafetyCheckResult(
                safe=False,
                reason=f"URL 域名包含非法字符：{domain_with_port}",
            )

        return SafetyCheckResult(safe=True)

    def _check_phishing_blacklist(self, domain: str) -> SafetyCheckResult:
        """检查域名是否在已知钓鱼黑名单中。

        Args:
            domain: 不含端口号的域名（已转小写）。

        Returns:
            ``SafetyCheckResult``，``safe=False`` 表示命中黑名单。
        """
        # 精确匹配或子域名匹配（防止 sub.paypa1.com 绕过）
        for blocked in _PHISHING_DOMAIN_BLACKLIST:
            if domain == blocked or domain.endswith("." + blocked):
                return SafetyCheckResult(
                    safe=False,
                    reason=f"域名 '{domain}' 已被列入钓鱼网站黑名单，拒绝访问",
                )

        return SafetyCheckResult(safe=True)

    def _check_whitelist(self, domain: str) -> SafetyCheckResult:
        """检查域名是否通过白名单验证。

        Args:
            domain: 不含端口号的域名（已转小写）。

        Returns:
            ``SafetyCheckResult``，``safe=False`` 表示域名不在白名单中。
        """
        if self.is_domain_allowed(domain):
            return SafetyCheckResult(safe=True)

        return SafetyCheckResult(
            safe=False,
            reason=(
                f"域名 '{domain}' 不在允许访问的白名单中，"
                f"当前白名单：{', '.join(self._whitelist)}"
            ),
        )
