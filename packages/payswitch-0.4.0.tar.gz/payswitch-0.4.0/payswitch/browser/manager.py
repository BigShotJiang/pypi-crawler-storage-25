"""Runtime-local browser/display ownership model for visible Pay-Switch actions."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import UTC, datetime


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stable_id(prefix: str, raw: str) -> str:
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"{prefix}_{digest[:16]}"


@dataclass(frozen=True)
class BrowserSessionHandle:
    task_id: str
    browser_context_id: str
    tab_id: str
    window_id: str
    attached_at: str


@dataclass(frozen=True)
class DisplayFocusLock:
    lock_id: str
    task_id: str
    browser_context_id: str
    action: str
    foreground_lease_id: str | None
    z_order_token: str
    acquired_at: str


class RuntimeBrowserManager:
    """Track which session owns the visible browser surface inside one runtime."""

    def __init__(self, *, workspace_id: str) -> None:
        self.workspace_id = workspace_id
        self._window_id = _stable_id("bwin", workspace_id)
        self._sessions: dict[str, BrowserSessionHandle] = {}
        self._selected_task_id: str | None = None
        self._selected_browser_context_id: str | None = None
        self._selected_tab_id: str | None = None
        self._selected_at: str | None = None
        self._selected_foreground_lease_id: str | None = None
        self._selection_reason: str = "no_visible_session"
        self._z_order_token: str | None = None
        self._focus_lock: DisplayFocusLock | None = None

    def register_session(self, task_id: str, browser_context_id: str) -> BrowserSessionHandle:
        current = _now()
        handle = BrowserSessionHandle(
            task_id=task_id,
            browser_context_id=browser_context_id,
            tab_id=_stable_id("btab", f"{self.workspace_id}:{task_id}:{browser_context_id}"),
            window_id=self._window_id,
            attached_at=current,
        )
        self._sessions[task_id] = handle
        return handle

    def unregister_session(self, task_id: str) -> None:
        self._sessions.pop(task_id, None)
        if self._focus_lock is not None and self._focus_lock.task_id == task_id:
            self._focus_lock = None
        if self._selected_task_id == task_id:
            self.clear_selection(reason="selected_session_detached")

    def select_session(
        self,
        task_id: str,
        *,
        browser_context_id: str,
        foreground_lease_id: str | None,
        reason: str,
    ) -> BrowserSessionHandle | None:
        handle = self._sessions.get(task_id)
        if handle is None:
            return None
        if handle.browser_context_id != browser_context_id:
            handle = self.register_session(task_id, browser_context_id)
        selected_at = _now()
        self._selected_task_id = task_id
        self._selected_browser_context_id = handle.browser_context_id
        self._selected_tab_id = handle.tab_id
        self._selected_at = selected_at
        self._selected_foreground_lease_id = foreground_lease_id
        self._selection_reason = reason
        self._z_order_token = _stable_id(
            "zord",
            f"{self.workspace_id}:{task_id}:{foreground_lease_id or 'none'}:{selected_at}",
        )
        if self._focus_lock is not None and self._focus_lock.task_id != task_id:
            self._focus_lock = None
        return handle

    def clear_selection(self, *, reason: str) -> None:
        self._selected_task_id = None
        self._selected_browser_context_id = None
        self._selected_tab_id = None
        self._selected_at = None
        self._selected_foreground_lease_id = None
        self._selection_reason = reason
        self._z_order_token = None
        self._focus_lock = None

    def verify_visible_action(
        self,
        task_id: str,
        *,
        browser_context_id: str,
        action: str,
        foreground_lease_id: str | None,
    ) -> dict[str, object]:
        handle = self._sessions.get(task_id)
        if handle is None:
            return {"allowed": False, "action": action, "reason": "no_browser_session"}
        if self._selected_task_id != task_id:
            return {
                "allowed": False,
                "action": action,
                "reason": "session_not_visible_owner",
                "display_owner_task_id": self._selected_task_id,
            }
        if self._selected_browser_context_id != browser_context_id:
            return {
                "allowed": False,
                "action": action,
                "reason": "browser_context_mismatch",
                "expected_browser_context_id": self._selected_browser_context_id,
                "actual_browser_context_id": browser_context_id,
            }
        if (
            self._selected_foreground_lease_id is not None
            and self._selected_foreground_lease_id != foreground_lease_id
        ):
            return {
                "allowed": False,
                "action": action,
                "reason": "foreground_lease_mismatch",
                "expected_foreground_lease_id": self._selected_foreground_lease_id,
                "actual_foreground_lease_id": foreground_lease_id,
            }
        if self._z_order_token is None:
            return {"allowed": False, "action": action, "reason": "visible_target_not_frontmost"}
        if self._focus_lock is not None and self._focus_lock.task_id != task_id:
            return {
                "allowed": False,
                "action": action,
                "reason": f"visible_action_locked_by_{self._focus_lock.task_id}",
                "display_focus_lock_id": self._focus_lock.lock_id,
                "display_focus_lock_task_id": self._focus_lock.task_id,
            }
        return {
            "allowed": True,
            "action": action,
            "reason": "visible_target_verified",
            "active_browser_context_id": self._selected_browser_context_id,
            "active_browser_tab_id": self._selected_tab_id,
            "active_browser_window_id": self._window_id,
            "display_focus_z_order_token": self._z_order_token,
            "display_focus_lock_id": self._focus_lock.lock_id if self._focus_lock else None,
            "display_focus_lock_task_id": self._focus_lock.task_id if self._focus_lock else None,
            "display_focus_lock_action": self._focus_lock.action if self._focus_lock else None,
        }

    def begin_visible_action(
        self,
        task_id: str,
        *,
        browser_context_id: str,
        action: str,
        foreground_lease_id: str | None,
    ) -> dict[str, object]:
        verified = self.verify_visible_action(
            task_id,
            browser_context_id=browser_context_id,
            action=action,
            foreground_lease_id=foreground_lease_id,
        )
        if not bool(verified.get("allowed")):
            return verified
        if self._focus_lock is not None and self._focus_lock.task_id == task_id:
            return {
                **verified,
                "allowed": False,
                "reason": "visible_action_already_locked",
                "display_focus_lock_id": self._focus_lock.lock_id,
                "display_focus_lock_task_id": self._focus_lock.task_id,
                "display_focus_lock_action": self._focus_lock.action,
            }
        acquired_at = _now()
        lock = DisplayFocusLock(
            lock_id=_stable_id(
                "vlock",
                f"{self.workspace_id}:{task_id}:{browser_context_id}:{action}:{acquired_at}",
            ),
            task_id=task_id,
            browser_context_id=browser_context_id,
            action=action,
            foreground_lease_id=foreground_lease_id,
            z_order_token=str(self._z_order_token),
            acquired_at=acquired_at,
        )
        self._focus_lock = lock
        return {
            **verified,
            "display_focus_lock_id": lock.lock_id,
            "display_focus_lock_task_id": lock.task_id,
            "display_focus_lock_action": lock.action,
            "display_focus_lock_acquired_at": lock.acquired_at,
        }

    def end_visible_action(self, *, lock_id: str | None) -> None:
        if self._focus_lock is None:
            return
        if lock_id is not None and self._focus_lock.lock_id != lock_id:
            return
        self._focus_lock = None

    def snapshot(self) -> dict[str, object]:
        state = "idle"
        if self._selected_task_id is not None:
            state = "selected"
        if self._focus_lock is not None:
            state = "focus_locked"
        return {
            "browser_manager_state": state,
            "active_browser_context_id": self._selected_browser_context_id,
            "active_browser_tab_id": self._selected_tab_id,
            "active_browser_window_id": self._window_id if self._selected_task_id else None,
            "active_browser_task_id": self._selected_task_id,
            "display_focus_lock_id": self._focus_lock.lock_id if self._focus_lock else None,
            "display_focus_lock_task_id": self._focus_lock.task_id if self._focus_lock else None,
            "display_focus_lock_action": self._focus_lock.action if self._focus_lock else None,
            "display_focus_lock_acquired_at": (
                self._focus_lock.acquired_at if self._focus_lock else None
            ),
            "display_focus_z_order_token": self._z_order_token,
            "display_focus_foreground_lease_id": self._selected_foreground_lease_id,
            "browser_selection_reason": self._selection_reason,
            "browser_selected_at": self._selected_at,
        }
