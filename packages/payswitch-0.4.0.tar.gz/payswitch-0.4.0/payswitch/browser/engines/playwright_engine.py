"""Playwright 原生 engine 实现（默认）。

保持 payswitch v0.2.x 之前的行为：原生 ``async_playwright()`` 启动
Chromium，加几个表层 anti-detection flag。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

    from playwright.async_api import Browser, BrowserContext, Playwright


class PlaywrightEngine:
    """原生 Playwright Chromium engine。"""

    name = "playwright"

    async def launch_stateless(
        self,
        playwright: Playwright,
        *,
        headless: bool,
        args: list[str],
        user_agent: str,
        viewport: dict[str, int],
        humanize: bool = False,
        human_preset: str | None = None,
        proxy: str | None = None,
        record_video_dir: Path | None = None,
    ) -> tuple[Browser, BrowserContext]:
        """启动无状态 Chromium。

        ``humanize`` / ``human_preset`` 在原生 Playwright 下无效（仅 CloakBrowser
        支持），被忽略以保持接口统一。
        """
        launch_kwargs: dict[str, Any] = {
            "headless": headless,
            "args": args,
            "ignore_default_args": ["--enable-automation"],
        }
        if proxy:
            launch_kwargs["proxy"] = {"server": proxy}

        browser = await playwright.chromium.launch(**launch_kwargs)
        context = await browser.new_context(
            viewport=viewport,
            user_agent=user_agent,
            record_video_dir=str(record_video_dir) if record_video_dir is not None else None,
            record_video_size=viewport if record_video_dir is not None else None,
        )
        return browser, context

    async def launch_persistent(
        self,
        playwright: Playwright,
        *,
        user_data_dir: Path,
        headless: bool,
        args: list[str],
        user_agent: str,
        viewport: dict[str, int],
        humanize: bool = False,
        human_preset: str | None = None,
        proxy: str | None = None,
        record_video_dir: Path | None = None,
    ) -> BrowserContext:
        """启动持久化 Profile Chromium。"""
        launch_kwargs: dict[str, Any] = {
            "headless": headless,
            "args": args,
            "viewport": viewport,
            "user_agent": user_agent,
            "ignore_default_args": ["--enable-automation"],
        }
        if proxy:
            launch_kwargs["proxy"] = {"server": proxy}
        if record_video_dir is not None:
            launch_kwargs["record_video_dir"] = str(record_video_dir)
            launch_kwargs["record_video_size"] = viewport

        context = await playwright.chromium.launch_persistent_context(
            str(user_data_dir),
            **launch_kwargs,
        )
        return context


__all__ = ["PlaywrightEngine"]
