"""浏览器 engine 抽象层。

BrowserController 通过 ``get_engine(name)`` 选择具体的启动实现。
默认 ``playwright`` 使用原生 Playwright Chromium（向后兼容）。
可选 ``cloakbrowser`` 使用 CloakBrowser（Chromium 源码级指纹 patch，
过 Cloudflare Turnstile / reCAPTCHA v3 / FingerprintJS 等反爬检测）。

Engine 层只负责"怎么把浏览器拉起来"，下游的 BrowserContext / Page API
因为两个引擎都兼容 Playwright，adapter / orchestrator 完全不用改。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from pathlib import Path

    from playwright.async_api import Browser, BrowserContext, Playwright

SUPPORTED_ENGINES: tuple[str, ...] = ("playwright", "cloakbrowser")


@runtime_checkable
class BrowserEngine(Protocol):
    """浏览器启动引擎协议。

    所有 engine 必须实现 ``launch_stateless`` 和 ``launch_persistent``，
    返回跟 Playwright 兼容的 Browser / BrowserContext 对象。
    """

    name: str

    async def launch_stateless(
        self,
        playwright: Playwright,
        *,
        headless: bool,
        args: list[str],
        user_agent: str,
        viewport: dict[str, int],
        humanize: bool = False,
        human_preset: str | None = None,
        proxy: str | None = None,
        record_video_dir: Path | None = None,
    ) -> tuple[Browser, BrowserContext]:
        """启动无状态浏览器，返回 ``(browser, context)``。"""
        ...

    async def launch_persistent(
        self,
        playwright: Playwright,
        *,
        user_data_dir: Path,
        headless: bool,
        args: list[str],
        user_agent: str,
        viewport: dict[str, int],
        humanize: bool = False,
        human_preset: str | None = None,
        proxy: str | None = None,
        record_video_dir: Path | None = None,
    ) -> BrowserContext:
        """启动持久化 Profile 浏览器，返回 ``context``。"""
        ...


def get_engine(name: str) -> BrowserEngine:
    """工厂：按名字返回 engine 实例。

    Args:
        name: ``"playwright"`` 或 ``"cloakbrowser"``

    Raises:
        ValueError: 当 name 不在 SUPPORTED_ENGINES 中
    """
    if name == "playwright":
        from payswitch.browser.engines.playwright_engine import PlaywrightEngine

        return PlaywrightEngine()
    if name == "cloakbrowser":
        from payswitch.browser.engines.cloakbrowser_engine import CloakBrowserEngine

        return CloakBrowserEngine()
    raise ValueError(
        f"不支持的 browser engine: {name!r}，可选值：{SUPPORTED_ENGINES}"
    )


__all__ = ["BrowserEngine", "SUPPORTED_ENGINES", "get_engine"]
