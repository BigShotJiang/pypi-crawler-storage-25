"""CloakBrowser engine 实现（opt-in）。

CloakBrowser 是 Chromium 源码级指纹 patch 的 Playwright drop-in 替换，
能过 Cloudflare Turnstile、reCAPTCHA v3（score 0.9）、FingerprintJS 等反爬检测。

**开启方式**::

    pip install 'payswitch[cloak]'
    payswitch config browser_engine cloakbrowser
    payswitch config browser_humanize true

**注意事项**：

- 首次启动会自动下载 ~200MB 的 patched Chromium binary（SHA-256 校验）
- MIT 协议，免费
- 只解决"被识别为 bot"这一关，**不解决**"交易风控认为你异常"
- 2FA / OTP / 最终确认按钮仍必须走 payswitch 的 Human Gate
- 绕开检测 ≠ 合规，生产使用前请确认目标站点 TOS
"""

from __future__ import annotations

import hashlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

    from playwright.async_api import Browser, BrowserContext, Playwright


_MISSING_DEP_MSG = (
    "CloakBrowser 未安装。请执行："
    "\n    pip install 'payswitch[cloak]'"
    "\n或手动安装："
    "\n    pip install cloakbrowser"
    "\n首次使用会自动下载 ~200MB 的 patched Chromium binary。"
)


def _import_cloakbrowser() -> Any:
    """延迟导入 cloakbrowser，未安装时抛友好错误。"""
    try:
        import cloakbrowser  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover - depends on env
        raise ImportError(_MISSING_DEP_MSG) from exc
    return cloakbrowser


def _stable_profile_fingerprint_arg(user_data_dir: Path) -> str:
    """Return a stable CloakBrowser fingerprint seed for a persistent profile."""
    normalized = str(user_data_dir.expanduser().resolve())
    digest = hashlib.sha256(normalized.encode("utf-8")).digest()
    seed = int.from_bytes(digest[:8], "big") % 90_000 + 10_000
    return f"--fingerprint={seed}"


def _with_stable_profile_fingerprint(args: list[str], user_data_dir: Path) -> list[str]:
    if any(arg.startswith("--fingerprint=") for arg in args):
        return args
    return [*args, _stable_profile_fingerprint_arg(user_data_dir)]


class CloakBrowserEngine:
    """CloakBrowser Chromium engine（C++ 源码级指纹 patch）。

    API 兼容 Playwright，下游使用方式跟 PlaywrightEngine 一致。
    额外支持 ``humanize`` / ``human_preset`` 配置人类行为模拟。
    """

    name = "cloakbrowser"

    async def launch_stateless(
        self,
        playwright: Playwright,
        *,
        headless: bool,
        args: list[str],
        user_agent: str,
        viewport: dict[str, int],
        humanize: bool = False,
        human_preset: str | None = None,
        proxy: str | None = None,
        record_video_dir: Path | None = None,
    ) -> tuple[Browser, BrowserContext]:
        """启动无状态 CloakBrowser。

        ``playwright`` 参数会被忽略（CloakBrowser 自带运行时），保留参数以满足
        BrowserEngine 协议。

        使用 ``launch_context_async`` 而非 ``launch_async + new_context``，
        确保 humanize patch 正确应用到 context 中的所有 page。
        """
        cloak = _import_cloakbrowser()

        launch_kwargs: dict[str, Any] = {
            "headless": headless,
            "humanize": humanize,
            "user_agent": user_agent,
            "viewport": viewport,
            # 默认启用 stealth_args（CloakBrowser 自带反爬参数）+ 调用方额外 args
            "args": list(args) if args else None,
        }
        if human_preset:
            launch_kwargs["human_preset"] = human_preset
        if proxy:
            launch_kwargs["proxy"] = proxy
            # 过代理时自动对齐 timezone / locale / WebRTC IP，避免 fingerprint 不一致
            launch_kwargs["geoip"] = True
        if record_video_dir is not None:
            launch_kwargs["record_video_dir"] = str(record_video_dir)
            launch_kwargs["record_video_size"] = viewport

        # launch_context_async 内部会做 launch_async → new_context → patch_context，
        # humanize 在 context 层正确生效；close() 时连带关闭底层 browser
        context = await cloak.launch_context_async(**launch_kwargs)
        # BrowserEngine 协议要求返回 (Browser, BrowserContext)
        browser = context.browser
        return browser, context

    async def launch_persistent(
        self,
        playwright: Playwright,
        *,
        user_data_dir: Path,
        headless: bool,
        args: list[str],
        user_agent: str,
        viewport: dict[str, int],
        humanize: bool = False,
        human_preset: str | None = None,
        proxy: str | None = None,
        record_video_dir: Path | None = None,
    ) -> BrowserContext:
        """启动持久化 Profile CloakBrowser。"""
        cloak = _import_cloakbrowser()

        launch_args = _with_stable_profile_fingerprint(
            list(args) if args else [],
            user_data_dir,
        )

        launch_kwargs: dict[str, Any] = {
            "headless": headless,
            "humanize": humanize,
            "user_agent": user_agent,
            "viewport": viewport,
            "args": launch_args,
        }
        if human_preset:
            launch_kwargs["human_preset"] = human_preset
        if proxy:
            launch_kwargs["proxy"] = proxy
            launch_kwargs["geoip"] = True
        if record_video_dir is not None:
            launch_kwargs["record_video_dir"] = str(record_video_dir)
            launch_kwargs["record_video_size"] = viewport

        context = await cloak.launch_persistent_context_async(
            str(user_data_dir),
            **launch_kwargs,
        )
        return context


__all__ = ["CloakBrowserEngine"]
