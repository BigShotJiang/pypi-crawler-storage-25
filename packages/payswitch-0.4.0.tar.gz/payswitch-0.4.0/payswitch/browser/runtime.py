"""Browser runtime planning for Pay-Switch.

This module is the single place that translates user configuration into an
actual browser-control backend. It keeps the external-agent "brain" separate
from the browser "hand": external/internal/hybrid decides who reasons, while
this module decides whether the hand is CDP, a real profile, or a managed test
profile.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from payswitch.browser.cdp_attach import (
    CdpAttachError,
    ensure_profile_cdp_url,
    is_cdp_url_ready,
)
from payswitch.browser.chrome_profiles import (
    ChromeProfileIdentity,
    find_active_chrome_user_data_process,
    find_matching_chrome_debugging_process,
    identity_matches_email,
    is_known_isolated_user_data_dir,
    resolve_cdp_profile_identity,
    resolve_profile_identity,
)
from payswitch.models.config import PaySwitchConfig
from payswitch.models.types import BrowserControlBackend


class BrowserRuntimeConfigError(RuntimeError):
    """Raised when browser backend configuration is internally inconsistent."""


@dataclass(frozen=True)
class BrowserRuntimePlan:
    """Resolved browser-control plan for one Pay-Switch run."""

    backend: BrowserControlBackend
    launch_kwargs: dict[str, Any]
    uses_user_chrome: bool
    uses_managed_profile: bool
    identity: ChromeProfileIdentity | None = None
    occupied: bool = False
    remote_debugging_port: str = ""


def resolve_browser_backend(config: PaySwitchConfig) -> BrowserControlBackend:
    """Resolve the effective browser backend from config.

    auto 模式下的选择顺序：
    1. 有 cdp_url → cdp
    2. 有 user_data_dir/profile → cdp（复用或启动真实 profile 的 CDP 端口）
    3. 都没有 → managed_profile
    """
    configured = config.browser_control_backend
    if configured != BrowserControlBackend.auto:
        return configured
    if config.chrome_cdp_url.strip():
        return BrowserControlBackend.cdp
    if config.chrome_user_data_dir.strip():
        return BrowserControlBackend.cdp
    return BrowserControlBackend.managed_profile


def build_browser_runtime_plan(
    config: PaySwitchConfig,
    *,
    validate_identity: bool = True,
    preflight_occupancy: bool = False,
    ensure_cdp: bool = False,
) -> BrowserRuntimePlan:
    """Build BrowserController launch kwargs for the effective backend."""
    backend = resolve_browser_backend(config)
    expected_email = config.chrome_expected_profile_email.strip()
    browser_channel = config.browser_channel.strip() or "chrome"
    launch_kwargs: dict[str, Any] = {}
    identity = None
    occupied = False
    remote_debugging_port = ""

    if backend == BrowserControlBackend.cdp:
        cdp_url = config.chrome_cdp_url.strip()
        user_data_dir = config.chrome_user_data_dir.strip()
        profile_directory = config.chrome_profile_directory.strip() or "Default"
        if user_data_dir:
            _reject_isolated_user_data_dir(user_data_dir, backend)
        if cdp_url and is_cdp_url_ready(cdp_url):
            launch_kwargs["chrome_cdp_url"] = cdp_url
            identity = resolve_cdp_profile_identity(cdp_url)
            _reject_isolated_identity(identity, backend)
            if ensure_cdp and expected_email and identity is None and user_data_dir:
                try:
                    cdp_url = ensure_profile_cdp_url(
                        user_data_dir=Path(user_data_dir).expanduser(),
                        profile_directory=profile_directory,
                        expected_email=expected_email,
                        browser_channel=browser_channel,
                    )
                except CdpAttachError as exc:
                    raise BrowserRuntimeConfigError(str(exc)) from exc
                launch_kwargs["chrome_cdp_url"] = cdp_url
                identity = resolve_cdp_profile_identity(cdp_url)
                _reject_isolated_identity(identity, backend)
        elif cdp_url and not ensure_cdp:
            raise BrowserRuntimeConfigError(
                f"已配置的 chrome_cdp_url 不可连接：{cdp_url}。"
                "请重新运行 payswitch settings cdp-profile --ensure，"
                "或清空 chrome_cdp_url 后重试。"
            )
        elif user_data_dir:
            if ensure_cdp:
                try:
                    cdp_url = ensure_profile_cdp_url(
                        user_data_dir=Path(user_data_dir).expanduser(),
                        profile_directory=profile_directory,
                        expected_email=expected_email,
                        browser_channel=browser_channel,
                    )
                except CdpAttachError as exc:
                    raise BrowserRuntimeConfigError(str(exc)) from exc
                launch_kwargs["chrome_cdp_url"] = cdp_url
                identity = resolve_cdp_profile_identity(cdp_url)
                _reject_isolated_identity(identity, backend)
            else:
                active_cdp = find_matching_chrome_debugging_process(
                    user_data_dir,
                    profile_directory,
                    expected_email=expected_email,
                    browser=browser_channel,
                )
                if active_cdp is not None:
                    cdp_url = f"http://127.0.0.1:{active_cdp.remote_debugging_port}"
                    launch_kwargs["chrome_cdp_url"] = cdp_url
                    identity = resolve_cdp_profile_identity(cdp_url)
                    _reject_isolated_identity(identity, backend)
                    remote_debugging_port = active_cdp.remote_debugging_port
                else:
                    identity = resolve_profile_identity(
                        user_data_dir,
                        profile_directory,
                    )
                    if preflight_occupancy:
                        active_process = find_active_chrome_user_data_process(
                            user_data_dir,
                            browser_channel,
                        )
                        if active_process is not None:
                            occupied = True
                            remote_debugging_port = active_process.remote_debugging_port
        else:
            raise BrowserRuntimeConfigError(
                "browser_control_backend=cdp 需要配置 chrome_cdp_url，"
                "或先绑定 chrome_user_data_dir + chrome_profile_directory。"
            )

    elif backend == BrowserControlBackend.ephemeral_cdp_mirror:
        user_data_dir = config.chrome_user_data_dir.strip()
        if not user_data_dir:
            raise BrowserRuntimeConfigError(
                "browser_control_backend=ephemeral_cdp_mirror "
                "需要先配置 chrome_user_data_dir。"
            )
        profile_directory = config.chrome_profile_directory.strip() or "Default"
        launch_kwargs["ephemeral_cdp_mirror_source_user_data_dir"] = Path(
            user_data_dir
        ).expanduser()
        launch_kwargs["ephemeral_cdp_mirror_profile_directory"] = profile_directory
        identity = resolve_profile_identity(user_data_dir, profile_directory)

    elif backend == BrowserControlBackend.user_profile:
        user_data_dir = config.chrome_user_data_dir.strip()
        if not user_data_dir:
            raise BrowserRuntimeConfigError(
                "browser_control_backend=user_profile 需要先配置 chrome_user_data_dir。"
            )
        _reject_isolated_user_data_dir(user_data_dir, backend)
        launch_kwargs["chrome_user_data_dir"] = Path(user_data_dir).expanduser()
        if config.chrome_profile_directory.strip():
            launch_kwargs["chrome_profile_directory"] = (
                config.chrome_profile_directory.strip()
            )
        identity = resolve_profile_identity(
            user_data_dir,
            config.chrome_profile_directory or "Default",
        )
        if preflight_occupancy:
            active_process = find_active_chrome_user_data_process(
                user_data_dir,
                browser_channel,
            )
            if active_process is not None:
                occupied = True
                remote_debugging_port = active_process.remote_debugging_port

    elif backend == BrowserControlBackend.managed_profile:
        pass
    else:
        raise BrowserRuntimeConfigError(f"不支持的浏览器控制后端：{backend}")

    if backend in {
        BrowserControlBackend.cdp,
        BrowserControlBackend.ephemeral_cdp_mirror,
        BrowserControlBackend.user_profile,
    }:
        launch_kwargs["browser_channel"] = browser_channel

    if validate_identity and expected_email and backend != BrowserControlBackend.managed_profile:
        if not identity_matches_email(identity, expected_email):
            actual = "<unknown>"
            if identity is not None:
                actual = (
                    f"{identity.user_name or '<empty>'} "
                    f"({identity.profile_directory}, {identity.user_data_dir})"
                )
            raise BrowserRuntimeConfigError(
                "Chrome profile identity mismatch: "
                f"expected {expected_email}, got {actual}. "
                "Refusing to continue to avoid spending from the wrong browser profile."
            )

    return BrowserRuntimePlan(
        backend=backend,
        launch_kwargs=launch_kwargs,
        uses_user_chrome=backend
        in {
            BrowserControlBackend.cdp,
            BrowserControlBackend.ephemeral_cdp_mirror,
            BrowserControlBackend.user_profile,
        },
        uses_managed_profile=backend == BrowserControlBackend.managed_profile,
        identity=identity,
        occupied=occupied,
        remote_debugging_port=remote_debugging_port,
    )


def _reject_isolated_identity(
    identity: ChromeProfileIdentity | None,
    backend: BrowserControlBackend,
) -> None:
    if identity is None:
        return
    _reject_isolated_user_data_dir(identity.user_data_dir, backend)


def _reject_isolated_user_data_dir(
    user_data_dir: str | Path,
    backend: BrowserControlBackend,
) -> None:
    if not is_known_isolated_user_data_dir(user_data_dir):
        return
    raise BrowserRuntimeConfigError(
        "当前浏览器上下文指向隔离/镜像 Chrome profile，不是真实用户 Chrome："
        f"{Path(user_data_dir).expanduser()}。"
        f"backend={backend.value} 不能用于真实支付链路连接这种目录；"
        "请在 settings profile 绑定正式 Chrome User Data，或仅在明确隔离探索时使用 "
        "ephemeral_cdp_mirror / managed_profile。"
    )
