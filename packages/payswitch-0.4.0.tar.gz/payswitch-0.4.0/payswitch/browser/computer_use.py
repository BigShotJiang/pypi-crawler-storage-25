"""Controlled Computer Use explorer for unknown checkout flows.

This module is intentionally a thin wrapper around the existing SkyvernEngine.
It gives the current architecture a clearer product boundary: Skyvern is the
LLM vision driver, while ComputerUseExplorer is the payment-aware explorer that
must stop before sensitive input or final authorization.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any

from payswitch.browser import skyvern as skyvern_module
from payswitch.browser.skyvern import SmartModeError
from payswitch.engine.risk import RiskGate
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import StepRecord
from payswitch.models.types import StepCategory, StepRisk

logger = logging.getLogger(__name__)


class ComputerUseUnavailableError(SmartModeError):
    """Raised when the controlled Computer Use explorer cannot run."""


class RecoveryStateVerificationError(SmartModeError):
    """Raised when recovery state verification blocks an autonomous action."""

    def __init__(self, message: str, *, failure_context: dict[str, Any]) -> None:
        super().__init__(message)
        self.failure_context = failure_context


ActionVerificationCallback = Callable[[Any, dict[str, Any], int, list[str]], Awaitable[None]]


@dataclass(slots=True)
class ComputerUseRecoveryBudget:
    """Bounded recovery envelope for Computer Use fallback."""

    max_steps: int
    max_screenshots: int
    max_model_tokens: int
    max_step_output_tokens: int
    max_wall_time_seconds: int

    @classmethod
    def from_config(cls, config: PaySwitchConfig) -> ComputerUseRecoveryBudget:
        return cls(
            max_steps=config.recovery_max_computer_use_steps,
            max_screenshots=config.recovery_max_computer_use_screenshots,
            max_model_tokens=config.recovery_max_computer_use_model_tokens,
            max_step_output_tokens=config.recovery_max_computer_use_step_output_tokens,
            max_wall_time_seconds=config.recovery_max_computer_use_wall_time_seconds,
        )

    @property
    def effective_max_steps(self) -> int:
        token_bounded_steps = max(
            1,
            self.max_model_tokens // self.max_step_output_tokens,
        )
        return min(self.max_steps, self.max_screenshots, token_bounded_steps)

    def as_dict(self) -> dict[str, int]:
        return {
            "max_steps": self.max_steps,
            "effective_max_steps": self.effective_max_steps,
            "max_screenshots": self.max_screenshots,
            "max_model_tokens": self.max_model_tokens,
            "max_step_output_tokens": self.max_step_output_tokens,
            "max_wall_time_seconds": self.max_wall_time_seconds,
        }


class ComputerUseExplorer:
    """Payment-aware wrapper for model-driven browser exploration.

    The explorer is allowed to discover and prepare checkout paths, but the
    prompt and returned metadata make the boundary explicit: sensitive fields
    and final payment authorization belong to HumanGate / VerifiedExecutor.
    """

    def __init__(self, config: PaySwitchConfig) -> None:
        self._config = config
        self._engine = skyvern_module.SkyvernEngine(config)
        self._risk_gate = RiskGate(config)

    def is_available(self) -> bool:
        """Return whether the internal model-backed Computer Use path can run."""
        return self._config.computer_use_enabled and self._engine.is_available()

    async def explore_checkout(
        self,
        page: Any,
        *,
        payee: str,
        amount: float,
        method: str,
        url: str | None,
        budget: ComputerUseRecoveryBudget | None = None,
        recovery_context: Mapping[str, Any] | None = None,
        pre_action_callback: ActionVerificationCallback | None = None,
    ) -> list[StepRecord]:
        """Explore an unknown or changed checkout flow until a handoff point."""
        if not self._config.computer_use_enabled:
            raise ComputerUseUnavailableError("Computer Use 已在配置中关闭")

        if not self._engine.is_available():
            raise ComputerUseUnavailableError(
                "Computer Use 需要可用的 LLM 后端：请配置 llm_api_key 并安装 smart 依赖"
            )

        decision = self._risk_gate.can_run_autonomously(
            category=StepCategory.checkout_prep,
            risk=StepRisk.medium,
        )
        if not decision.allowed:
            raise ComputerUseUnavailableError(
                f"Computer Use 当前配置不允许自动推进到 checkout_prep：{decision.reason}"
            )
        budget = budget or ComputerUseRecoveryBudget.from_config(self._config)

        task_description = self._build_task_description(
            payee=payee,
            amount=amount,
            method=method,
            recovery_context=recovery_context,
        )
        logger.info(
            "Computer Use 探索启动：payee=%s amount=%.2f method=%s url=%s",
            payee,
            amount,
            method,
            url,
        )
        steps = await self._engine.execute_task(
            page=page,
            task_description=task_description,
            url=url,
            max_steps=budget.effective_max_steps,
            max_output_tokens=budget.max_step_output_tokens,
            pre_action_callback=pre_action_callback
            or (
                lambda active_page, action, step_index, history: self._verify_recovery_action(
                    active_page,
                    action,
                    step_index,
                    history,
                    recovery_context=recovery_context,
                )
            ),
        )
        return [
            step.model_copy(
                update={
                    "category": StepCategory.checkout_prep,
                    "risk": StepRisk.medium,
                }
            )
            for step in steps
        ]

    def _build_task_description(
        self,
        *,
        payee: str,
        amount: float,
        method: str,
        recovery_context: Mapping[str, Any] | None = None,
    ) -> str:
        """Build a bounded prompt for checkout discovery, not final payment."""
        task = (
            f"目标：在 {payee} 页面中探索并推进到付款前的 checkout 候选状态。"
            f"期望金额为 {amount:.2f}，期望支付方式为 {method}。"
            "你可以检查登录态、寻找充值/会员/购买入口、关闭普通弹窗、选择套餐候选、"
            "进入订单或收银台页面。"
            "严格边界：遇到 CVV、银行卡号、短信验证码、支付密码、支付宝/微信确认、"
            "最终 Pay/Subscribe/确认付款按钮、自动续费或协议确认时，必须返回 done，"
            "不要填写敏感信息，不要提交最终付款，不要勾选协议。"
            "到达二维码、支付确认页、CVV/OTP 页面或最终付款按钮可见时，也返回 done。"
        )
        recovery_brief = self._build_recovery_context_brief(recovery_context)
        if recovery_brief:
            task += (
                "恢复上下文："
                f"{recovery_brief}"
                "你必须先根据这份最新快照判断当前页面是否仍与失败节点相关；"
                "如果已回到登录页、跳到无关页面，或已经进入高风险支付边界，立即返回 done。"
            )
        return task

    async def _verify_recovery_action(
        self,
        page: Any,
        action: dict[str, Any],
        step_index: int,
        history: list[str],
        *,
        recovery_context: Mapping[str, Any] | None = None,
    ) -> None:
        del history  # reserved for future richer verifier signals
        action_type = str(action.get("action", "")).strip().lower()
        selector = str(action.get("selector", "")).strip()
        description = str(action.get("description", "")).strip()
        reasoning = str(action.get("reasoning", "")).strip()
        current_url = str(getattr(page, "url", "") or "")
        visible_text = await self._visible_text_snapshot(page)
        lowered_surface = f"{current_url}\n{visible_text}".lower()
        lowered_action = " ".join(
            part.lower() for part in (selector, description, reasoning) if part
        )

        if self._contains_any(lowered_surface, _LOGIN_MARKERS):
            raise RecoveryStateVerificationError(
                "recovery verification blocked action: login required",
                failure_context={
                    "failure_type": "computer_use_recovery",
                    "failure_reason": "recovery verification blocked action: login required",
                    "failure_class": "RecoveryStateVerificationError",
                    "verification_stage": "pre_action",
                    "login_required": True,
                    "current_url": current_url,
                    "visible_text_summary": visible_text,
                    "action_type": action_type,
                    "action_selector": selector,
                    "action_description": description,
                    "step_index": step_index,
                    **self._project_recovery_context(recovery_context),
                },
            )

        if action_type == "fill" and self._contains_any(lowered_action, _SENSITIVE_INPUT_MARKERS):
            raise RecoveryStateVerificationError(
                "recovery verification blocked sensitive fill action",
                failure_context={
                    "failure_type": "computer_use_recovery",
                    "failure_reason": "recovery verification blocked sensitive fill action",
                    "failure_class": "RecoveryStateVerificationError",
                    "verification_stage": "pre_action",
                    "requires_human_gate": True,
                    "synchronous_policy_checkpoint": True,
                    "waypoint_category": StepCategory.sensitive.value,
                    "waypoint_risk": StepRisk.high.value,
                    "current_url": current_url,
                    "visible_text_summary": visible_text,
                    "action_type": action_type,
                    "action_selector": selector,
                    "action_description": description,
                    "step_index": step_index,
                    **self._project_recovery_context(recovery_context),
                },
            )

        if action_type in {"click", "fill"} and (
            self._contains_any(lowered_surface, _PAYMENT_BOUNDARY_MARKERS)
            or self._contains_any(lowered_action, _PAYMENT_BOUNDARY_MARKERS)
        ):
            raise RecoveryStateVerificationError(
                "recovery verification blocked high-risk payment boundary action",
                failure_context={
                    "failure_type": "computer_use_recovery",
                    "failure_reason": (
                        "recovery verification blocked high-risk payment boundary action"
                    ),
                    "failure_class": "RecoveryStateVerificationError",
                    "verification_stage": "pre_action",
                    "requires_human_gate": True,
                    "synchronous_policy_checkpoint": True,
                    "waypoint_category": StepCategory.final_authorization.value,
                    "waypoint_risk": StepRisk.high.value,
                    "current_url": current_url,
                    "visible_text_summary": visible_text,
                    "action_type": "confirm"
                    if action_type == "click"
                    else action_type,
                    "action_selector": selector,
                    "action_description": description,
                    "step_index": step_index,
                    **self._project_recovery_context(recovery_context),
                },
            )

    def _build_recovery_context_brief(
        self,
        recovery_context: Mapping[str, Any] | None,
    ) -> str:
        if not isinstance(recovery_context, Mapping):
            return ""

        parts: list[str] = []
        waypoint = str(
            recovery_context.get("waypoint_id")
            or recovery_context.get("recipe_id")
            or recovery_context.get("failure_reason")
            or ""
        ).strip()
        if waypoint:
            parts.append(f"\n- 失败节点：{self._truncate_text(waypoint, 120)}")

        snapshot = recovery_context.get("resync_snapshot")
        if not isinstance(snapshot, Mapping):
            return "".join(parts)

        current_url = str(snapshot.get("current_url") or "").strip()
        if current_url:
            parts.append(f"\n- 当前 URL：{self._truncate_text(current_url, 160)}")

        visible_text = str(snapshot.get("visible_text_summary") or "").strip()
        if visible_text:
            compact_visible_text = visible_text.replace("\n", " / ")
            parts.append(
                "\n- 最新可见文本："
                f"{self._truncate_text(compact_visible_text, 240)}"
            )

        dom_summary = snapshot.get("dom_summary")
        if isinstance(dom_summary, Mapping):
            title = str(dom_summary.get("title") or "").strip()
            if title:
                parts.append(f"\n- 页面标题：{self._truncate_text(title, 120)}")
            headings = self._join_summary_values(dom_summary.get("headings"))
            if headings:
                parts.append(f"\n- 标题摘要：{self._truncate_text(headings, 180)}")
            buttons = self._join_summary_values(dom_summary.get("buttons"))
            if buttons:
                parts.append(f"\n- 按钮摘要：{self._truncate_text(buttons, 180)}")

        return "".join(parts)

    def _project_recovery_context(
        self,
        recovery_context: Mapping[str, Any] | None,
    ) -> dict[str, Any]:
        if not isinstance(recovery_context, Mapping):
            return {}
        projected: dict[str, Any] = {}
        for key in ("waypoint_id", "recipe_id", "failure_reason"):
            value = recovery_context.get(key)
            if value is not None:
                projected[key] = value
        snapshot = recovery_context.get("resync_snapshot")
        if isinstance(snapshot, Mapping):
            projected["resync_snapshot"] = {
                "current_url": snapshot.get("current_url"),
                "visible_text_summary": snapshot.get("visible_text_summary"),
                "dom_summary": snapshot.get("dom_summary"),
            }
        return projected

    def _join_summary_values(self, value: Any) -> str:
        if not isinstance(value, list | tuple):
            return ""
        return " / ".join(str(item).strip() for item in value if str(item).strip())

    def _truncate_text(self, value: str, limit: int) -> str:
        if len(value) <= limit:
            return value
        return value[: max(0, limit - 1)].rstrip() + "…"

    async def _visible_text_snapshot(self, page: Any) -> str:
        evaluate = getattr(page, "evaluate", None)
        if evaluate is None:
            return ""
        try:
            result = await evaluate(
                """
                () => (document.body?.innerText || "")
                    .split("\\n")
                    .map((line) => line.trim())
                    .filter(Boolean)
                    .slice(0, 30)
                    .join("\\n")
                """
            )
        except Exception:
            return ""
        return str(result or "")

    def _contains_any(self, text: str, patterns: tuple[str, ...]) -> bool:
        return any(pattern in text for pattern in patterns)


_LOGIN_MARKERS = (
    "login",
    "sign in",
    "sign-in",
    "passport",
    "authentication required",
    "session expired",
    "登录",
    "登录后",
    "请先登录",
    "未登录",
    "会话失效",
)

_SENSITIVE_INPUT_MARKERS = (
    "password",
    "pay password",
    "cvv",
    "otp",
    "sms code",
    "verification code",
    "银行卡",
    "card number",
    "验证码",
    "支付密码",
    "短信验证码",
)

_PAYMENT_BOUNDARY_MARKERS = tuple(
    token.lower()
    for token in (
        "Confirm payment",
        "Continue",
        "Subscribe",
        "Place order",
        "Pay now",
        "Pay with",
        "Agree",
        "Agreement",
        "Auto renew",
        "QR Code",
        "Scan to pay",
        "确认支付",
        "立即支付",
        "订阅",
        "开通",
        "同意",
        "协议",
        "自动续费",
        "二维码",
        "扫码",
    )
)
