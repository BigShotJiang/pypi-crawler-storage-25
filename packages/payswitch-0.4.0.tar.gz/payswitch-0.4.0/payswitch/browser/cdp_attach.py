"""Direct CDP attachment for the user's configured Chrome profile.

This path does not copy or mirror the user's profile. It either reuses an
already-running Chrome process that exposes a matching remote-debugging port,
or starts Chrome against the configured real profile with a new local CDP port.
"""

from __future__ import annotations

import platform
import socket
import subprocess
import tempfile
import time
from pathlib import Path

from payswitch.browser.chrome_profiles import (
    find_active_chrome_user_data_process,
    find_matching_chrome_debugging_process,
    identity_matches_email,
    is_known_isolated_user_data_dir,
    resolve_cdp_profile_identity,
)

_CHROME_APP_PATH = "/Applications/Google Chrome.app"
_CHROME_BIN_PATH = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"


class CdpAttachError(RuntimeError):
    """Raised when Pay-Switch cannot obtain a verified CDP endpoint."""


def find_profile_cdp_url(
    *,
    user_data_dir: Path,
    profile_directory: str,
    expected_email: str = "",
    browser_channel: str = "chrome",
) -> str | None:
    """Return an existing verified CDP URL for the configured profile."""
    _reject_isolated_user_data_dir(user_data_dir)
    process = find_matching_chrome_debugging_process(
        user_data_dir,
        profile_directory,
        expected_email=expected_email,
        browser=browser_channel,
    )
    if process is None or not process.remote_debugging_port:
        return None
    cdp_url = f"http://127.0.0.1:{process.remote_debugging_port}"
    if not is_cdp_url_ready(cdp_url):
        return None
    return cdp_url


def is_cdp_url_ready(cdp_url: str) -> bool:
    """Return whether a CDP HTTP endpoint currently accepts connections."""
    try:
        port = int(cdp_url.rsplit(":", 1)[1])
    except (IndexError, ValueError):
        return False
    return _port_ready(port)


def ensure_profile_cdp_url(
    *,
    user_data_dir: Path,
    profile_directory: str,
    expected_email: str = "",
    browser_channel: str = "chrome",
    timeout_seconds: float = 10.0,
) -> str:
    """Ensure a verified local CDP URL exists for the real Chrome profile.

    The lookup is identity-first: Pay-Switch refuses to return a CDP endpoint
    unless the process command line points at the configured profile and the
    profile metadata matches the expected email when one is configured.
    """
    root = user_data_dir.expanduser()
    profile = profile_directory.strip() or "Default"
    _reject_isolated_user_data_dir(root)

    existing = find_profile_cdp_url(
        user_data_dir=root,
        profile_directory=profile,
        expected_email=expected_email,
        browser_channel=browser_channel,
    )
    if existing:
        return existing

    matching_process = find_matching_chrome_debugging_process(
        root,
        profile,
        expected_email=expected_email,
        browser=browser_channel,
    )
    if matching_process is not None and matching_process.remote_debugging_port:
        raise CdpAttachError(
            "已找到当前绑定 profile 的 Chrome CDP 进程，但端口不可连接："
            f"http://127.0.0.1:{matching_process.remote_debugging_port}。"
            "Pay-Switch 不会给同一真实 User Data 强行再开第二个端口，"
            "以免造成登录态/窗口状态混乱。请关闭所有使用该 User Data 的 Chrome，"
            "再运行 payswitch settings cdp-profile --ensure；长期方案应使用 Extension Relay。"
        )

    if not root.exists():
        raise CdpAttachError(f"Chrome User Data 目录不存在：{root}")
    if not (root / profile).exists():
        raise CdpAttachError(f"Chrome profile 目录不存在：{root / profile}")

    active_process = find_active_chrome_user_data_process(root, browser_channel)
    if active_process is not None:
        if active_process.remote_debugging_port:
            detail = (
                f"当前端口 http://127.0.0.1:{active_process.remote_debugging_port} "
                f"属于 {active_process.profile_directory}，不是 {profile}。"
            )
        else:
            detail = f"当前活动 profile 是 {active_process.profile_directory}。"
        raise CdpAttachError(
            "真实 Chrome User Data 目录已被一个不匹配的 Chrome 实例接管，"
            "Pay-Switch 不会再尝试给同一目录强行打开第二个 CDP 端口，"
            f"以免造成登录态/窗口状态混乱。{detail} "
            "请先关闭所有使用该 User Data 的 Chrome，再运行 "
            "payswitch settings cdp-profile --ensure；长期方案应使用 Extension Relay。"
        )

    port = _find_free_port()
    cdp_url = f"http://127.0.0.1:{port}"
    _launch_chrome_with_cdp(
        user_data_dir=root,
        profile_directory=profile,
        browser_channel=browser_channel,
        port=port,
    )
    return _wait_for_verified_cdp(
        cdp_url=cdp_url,
        expected_email=expected_email,
        timeout_seconds=timeout_seconds,
    )


def _launch_chrome_with_cdp(
    *,
    user_data_dir: Path,
    profile_directory: str,
    browser_channel: str,
    port: int,
) -> None:
    args = [
        f"--user-data-dir={user_data_dir.expanduser()}",
        f"--profile-directory={profile_directory}",
        "--remote-debugging-address=127.0.0.1",
        f"--remote-debugging-port={port}",
        "--no-first-run",
        "--no-default-browser-check",
        "about:blank",
    ]
    if platform.system() == "Darwin":
        command = ["open", "-na", _chrome_app_path(browser_channel), "--args", *args]
    else:
        command = [_chrome_bin_path(browser_channel), *args]

    log_path = Path(tempfile.gettempdir()) / f"payswitch-cdp-attach-{port}.log"
    try:
        with log_path.open("ab") as log_file:
            subprocess.Popen(  # noqa: S603
                command,
                stdout=log_file,
                stderr=log_file,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
    except OSError as exc:
        raise CdpAttachError(f"启动真实 profile 的 CDP Chrome 失败：{exc}") from exc


def _wait_for_verified_cdp(
    *,
    cdp_url: str,
    expected_email: str,
    timeout_seconds: float,
) -> str:
    deadline = time.monotonic() + timeout_seconds
    last_error = ""
    while time.monotonic() < deadline:
        port = int(cdp_url.rsplit(":", 1)[1])
        if not _port_ready(port):
            time.sleep(0.25)
            continue
        identity = resolve_cdp_profile_identity(cdp_url)
        if identity_matches_email(identity, expected_email):
            return cdp_url
        if identity is None:
            last_error = "CDP 端口已打开，但暂时无法从本地进程识别对应 profile。"
        else:
            last_error = (
                "CDP 端口身份不匹配："
                f"{identity.user_name or '<empty>'} "
                f"({identity.profile_directory}, {identity.user_data_dir})"
            )
        time.sleep(0.25)

    detail = f" {last_error}" if last_error else ""
    raise CdpAttachError(
        "未能为真实 Chrome profile 获得可校验的 CDP 端口。"
        f"{detail} 请确认目标 profile 没有被错误的 Chrome 实例接管，"
        "或先手动用 --remote-debugging-port 启动该 profile。"
    )


def _chrome_app_path(browser_channel: str) -> str:
    if browser_channel.lower() == "chromium":
        return "/Applications/Chromium.app"
    return _CHROME_APP_PATH


def _chrome_bin_path(browser_channel: str) -> str:
    if browser_channel.lower() == "chromium":
        return "chromium"
    return _CHROME_BIN_PATH


def _port_ready(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _reject_isolated_user_data_dir(user_data_dir: Path) -> None:
    if not is_known_isolated_user_data_dir(user_data_dir):
        return
    raise CdpAttachError(
        "当前 Chrome User Data 指向隔离/镜像 profile，不是真实用户 Chrome："
        f"{user_data_dir.expanduser()}。"
        "Pay-Switch 不会把这种目录固化为真实支付 CDP；请重新绑定正式 Chrome profile。"
    )
