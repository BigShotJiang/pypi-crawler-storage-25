"""Playwright 浏览器控制器。

提供统一的浏览器操作接口，支持持久化 Profile（复用登录状态）、
无头/有头模式、反检测参数、以及完善的错误处理。
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from playwright.async_api import (
    Browser,
    BrowserContext,
    Page,
    Playwright,
    async_playwright,
)
from playwright.async_api import (
    Error as PlaywrightError,
)
from playwright.async_api import (
    TimeoutError as PlaywrightTimeoutError,
)

logger = logging.getLogger(__name__)

# 默认视口尺寸
_DEFAULT_VIEWPORT_WIDTH = 1280
_DEFAULT_VIEWPORT_HEIGHT = 800

# 模拟真实桌面浏览器的 User-Agent（Chrome 124 on Windows）
_DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

# 传给 Chromium 的反自动化检测启动参数
_ANTI_DETECTION_ARGS: list[str] = [
    "--disable-blink-features=AutomationControlled",
    "--disable-infobars",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-extensions-except=",
    "--disable-popup-blocking",
]

# 使用用户真实 Chrome profile 时保持浏览器尽量接近日常环境，不强行禁用扩展。
_USER_CHROME_ARGS: list[str] = [
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-blink-features=AutomationControlled",
]

# Docker 容器内 Chromium 必需的额外启动参数（无 GPU、无沙箱）
_CHROME_DOCKER_ARGS: list[str] = [
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--no-zygote",
    "--disable-gpu-sandbox",
    "--disable-setuid-sandbox",
    "--disable-site-isolation-trials",
]


def is_running_in_docker() -> bool:
    """检测当前是否在 Docker 容器内运行。

    按优先级检查：
    1. IN_DOCKER 环境变量（sandbox_entry 设置）
    2. /.dockerenv 文件（Docker 标准标记）
    3. /proc/1/cgroup 包含 "docker"（Linux cgroup 检测）
    """
    # 方式 1：环境变量（最可靠，sandbox 启动时由 Dockerfile 设置）
    if os.environ.get("IN_DOCKER", "").lower() in ("true", "1", "yes"):
        return True

    # 方式 2：Docker 在容器根目录创建的标记文件
    if Path("/.dockerenv").exists():
        return True

    # 方式 3：Linux cgroup 检测
    cgroup_path = Path("/proc/1/cgroup")
    if cgroup_path.exists():
        try:
            content = cgroup_path.read_text(encoding="utf-8")
            if "docker" in content:
                return True
        except OSError:
            pass

    return False


def _cleanup_chromium_singletons(profile_dir: Path) -> None:
    """移除 Chromium profile 中的残留锁，防止误判为已有会话占用。

    - Linux/macOS: 清理 SingletonLock / SingletonCookie / SingletonSocket 文件
    - Windows: 清理 lockfile (Windows 上 Chromium 使用 lockfile 而非 Unix 符号链接)
    """
    import platform

    # Unix: 符号链接形式的 singleton 锁
    for name in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
        lock_path = profile_dir / name
        if lock_path.exists() or lock_path.is_symlink():
            try:
                lock_path.unlink(missing_ok=True)
                logger.warning("已清理残留浏览器锁文件：%s", lock_path)
            except OSError as exc:
                logger.debug("清理锁文件失败（可忽略）：%s | %s", lock_path, exc)

    # Windows: Chromium 使用 lockfile 而非 Unix 符号链接
    if platform.system() == "Windows":
        lockfile = profile_dir / "lockfile"
        if lockfile.exists():
            try:
                lockfile.unlink(missing_ok=True)
                logger.warning("已清理 Windows 残留浏览器锁文件：%s", lockfile)
            except OSError as exc:
                logger.debug(
                    "清理 Windows 锁文件失败（可能被占用）：%s | %s", lockfile, exc
                )


class BrowserControllerError(Exception):
    """BrowserController 基础异常类"""


class BrowserNotLaunchedError(BrowserControllerError):
    """浏览器尚未启动时访问 page/context 抛出此异常"""


class BrowserController:
    """Playwright 浏览器控制器，提供统一的浏览器操作接口。

    支持两种模式：
    - 普通模式：``profile_dir=None``，每次启动全新的无状态浏览器。
    - 持久化模式：提供 ``profile_dir``，通过 ``launch_persistent_context``
      复用登录 Cookie / LocalStorage，避免重复登录。

    用法示例::

        # 方式一：直接调用 launch / close
        ctrl = BrowserController()
        await ctrl.launch(profile_dir=Path("~/.payswitch/profiles/alipay"))
        await ctrl.navigate("https://www.alipay.com")
        await ctrl.close()

        # 方式二：异步上下文管理器
        async with BrowserController() as ctrl:
            await ctrl.navigate("https://www.alipay.com")
            png = await ctrl.screenshot()
    """

    def __init__(self) -> None:
        # Playwright 实例（async_playwright() 的返回值）
        self._playwright: Playwright | None = None

        # 普通模式下的 Browser 对象；持久化模式下为 None
        self._browser: Browser | None = None

        # BrowserContext：普通模式由 _browser 创建；持久化模式直接由
        # launch_persistent_context 返回
        self._context: BrowserContext | None = None

        # 当前活跃 Page
        self._page: Page | None = None

        # 记录当前是否为持久化模式
        self._persistent: bool = False

        # 是否连接到用户已经打开的 Chrome。该模式关闭时只断开 Playwright，
        # 不关闭用户浏览器，也不关闭其默认 context。
        self._attached_cdp: bool = False

        # 最近一次识别到的可点击元素快照（供按索引点击）
        self._last_clickables: list[dict[str, Any]] = []

        # 交易级页面复用标记。用于 external Computer Use 在连接已有 Chrome
        # 时找回同一个受控标签页，而不是每步都新开 tab。
        self._session_key: str | None = None
        self._reused_existing_page: bool = False

        # Playwright video recording 原始输出目录。仅对由 Pay-Switch 启动的
        # context 有效；连接现有 CDP 浏览器时无法录制。
        self._record_video_dir: Path | None = None
        self._video_recording_enabled: bool = False

    # ------------------------------------------------------------------
    # 公开接口
    # ------------------------------------------------------------------

    async def launch(
        self,
        profile_dir: Path | None = None,
        headless: bool = False,
        display: str | None = None,
        chrome_cdp_url: str | None = None,
        ephemeral_cdp_mirror_source_user_data_dir: Path | None = None,
        ephemeral_cdp_mirror_profile_directory: str | None = None,
        chrome_user_data_dir: Path | None = None,
        chrome_profile_directory: str | None = None,
        browser_channel: str | None = None,
        session_key: str | None = None,
        engine: str | None = None,
        humanize: bool | None = None,
        human_preset: str | None = None,
        record_video_dir: Path | None = None,
    ) -> None:
        """启动浏览器。

        Args:
            profile_dir: 持久化 Profile 目录。若为 ``None``，使用普通无状态模式。
                目录不存在时 Playwright 会自动创建。
            headless: 是否无头模式。noVNC 场景下设为 ``False`` + 外部 Xvfb 驱动。
            display: X11 虚拟显示编号，例如 ":99"。提供时会在启动前设置
                ``DISPLAY`` 环境变量，使 Playwright 使用 Xvfb 的虚拟显示。
                noVNC 模式下由 DisplayManager 提供此值；headed 模式下保持 None。
            chrome_cdp_url: 已开启 remote-debugging 的 Chrome 地址。设置后连接现有
                Chrome，不启动新浏览器进程。
            ephemeral_cdp_mirror_source_user_data_dir: 若提供，先从该真实 Chrome
                User Data 根目录创建交易级 /tmp 临时镜像，再启动独立 CDP Chrome。
            ephemeral_cdp_mirror_profile_directory: 临时 CDP 镜像所使用的 profile 子目录。
            chrome_user_data_dir: 用户指定的真实 Chrome User Data 根目录。设置后用
                系统 Chrome 打开该 profile，而不是使用 Pay-Switch 自管 profile。
            chrome_profile_directory: 真实 Chrome User Data 下的 profile 子目录名，
                例如 Default / Profile 1。
            browser_channel: Playwright 浏览器 channel，例如 chrome / chromium。
            session_key: 交易级会话标识。连接已有 Chrome 时会尝试复用同一个 tab。
            engine: 浏览器 engine。``None``（默认）时从 ``PaySwitchConfig.browser_engine``
                读取；可显式传 ``"playwright"`` / ``"cloakbrowser"`` 覆盖。
            humanize: 是否启用人类行为模拟。``None`` 时从 config 读取。
            human_preset: CloakBrowser humanize 预设。``None`` 时从 config 读取。
            record_video_dir: Playwright context 级视频录制原始输出目录。仅对
                Pay-Switch 自己拉起的浏览器有效，CDP attach 到用户现有 Chrome
                时会自动忽略。
        """
        # 从全局 config 解析未显式传入的浏览器 engine / humanize 参数
        if engine is None or humanize is None or human_preset is None:
            try:
                from payswitch.models.config import PaySwitchConfig

                _cfg = PaySwitchConfig.load()
            except Exception:  # noqa: BLE001
                _cfg = None
            if engine is None:
                engine = _cfg.browser_engine if _cfg is not None else "playwright"
            if humanize is None:
                humanize = _cfg.browser_humanize if _cfg is not None else False
            if human_preset is None:
                human_preset = (
                    _cfg.browser_human_preset if _cfg is not None else "default"
                )

        if self._playwright is not None:
            logger.warning("浏览器已启动，请先调用 close() 再重新 launch()")
            return

        # 若提供了虚拟显示编号，在启动 Playwright 前设置 DISPLAY 环境变量，
        # 确保 Chromium 渲染到正确的 Xvfb 虚拟显示（而非真实显示器或报错退出）
        if display is not None:
            os.environ["DISPLAY"] = display
            logger.info("已设置 DISPLAY=%s（Xvfb 虚拟显示）", display)

        if ephemeral_cdp_mirror_source_user_data_dir is not None:
            from payswitch.browser.cdp_mirror import (
                CdpMirrorError,
                prepare_ephemeral_cdp_mirror,
            )

            try:
                mirror = prepare_ephemeral_cdp_mirror(
                    source_user_data_dir=ephemeral_cdp_mirror_source_user_data_dir,
                    profile_directory=(
                        ephemeral_cdp_mirror_profile_directory
                        or chrome_profile_directory
                        or "Default"
                    ),
                    session_key=session_key,
                    browser_channel=browser_channel or "chrome",
                )
            except CdpMirrorError as exc:
                raise BrowserControllerError(str(exc)) from exc
            chrome_cdp_url = mirror.cdp_url
            chrome_user_data_dir = None
            logger.info(
                "使用临时 CDP 镜像连接 Chrome：mirror=%s cdp=%s",
                mirror.mirror_user_data_dir,
                mirror.cdp_url,
            )

        logger.info(
            "正在启动浏览器 | headless=%s | profile_dir=%s | display=%s",
            headless,
            profile_dir,
            display,
        )

        user_chrome_active_process = None
        if chrome_user_data_dir is not None:
            chrome_user_data_dir = chrome_user_data_dir.expanduser().resolve()
            if not chrome_user_data_dir.exists():
                raise BrowserControllerError(
                    f"Chrome User Data 目录不存在：{chrome_user_data_dir}"
                )

            channel = browser_channel or "chrome"
            from payswitch.browser.chrome_profiles import (
                find_active_chrome_user_data_process,
            )

            user_chrome_active_process = find_active_chrome_user_data_process(
                chrome_user_data_dir,
                channel,
            )
            if user_chrome_active_process is not None:
                cdp_hint = ""
                if user_chrome_active_process.remote_debugging_port:
                    cdp_hint = (
                        "\n检测到这个 Chrome 已开启 remote debugging，可直接配置："
                        "\n  uv run payswitch config chrome_cdp_url "
                        f"http://127.0.0.1:"
                        f"{user_chrome_active_process.remote_debugging_port}"
                    )
                raise BrowserControllerError(
                    "当前绑定的是用户真实 Chrome profile，但同一个 Chrome User Data "
                    "目录已经在运行，Pay-Switch 不能再用 Playwright 重新打开并接管它。"
                    "\n原因：Chrome profile 只能被一个浏览器主进程拥有；普通 Chrome "
                    "已经占用了这个目录。"
                    "\n可选处理："
                    "\n1. 推荐：使用 chrome_cdp_url 连接一个从启动时就带 "
                    "--remote-debugging-port 的 Chrome。"
                    "\n2. 或者：完全退出所有 Chrome 窗口后再运行，"
                    "让 Pay-Switch 启动该 profile。"
                    "\n3. 或者：清空 chrome_user_data_dir，"
                    "改用 Pay-Switch 自管 profile 做隔离测试。"
                    f"{cdp_hint}"
                )

        # Docker 环境自动合并容器必需的 Chrome 参数
        _in_docker = is_running_in_docker()
        if _in_docker:
            logger.info("检测到 Docker 容器环境，自动追加 CHROME_DOCKER_ARGS")

        # 启动 Playwright 运行时
        self._playwright = await async_playwright().start()
        self._session_key = session_key
        self._reused_existing_page = False
        self._record_video_dir = (
            record_video_dir.expanduser().resolve() if record_video_dir is not None else None
        )
        self._video_recording_enabled = False
        if self._record_video_dir is not None:
            self._record_video_dir.mkdir(parents=True, exist_ok=True)

        if chrome_cdp_url:
            logger.info("连接已有 Chrome CDP：%s", chrome_cdp_url)
            self._browser = await self._playwright.chromium.connect_over_cdp(
                chrome_cdp_url
            )
            if self._browser.contexts:
                self._context = self._browser.contexts[0]
            else:
                self._context = await self._browser.new_context()
            self._page = await self._resolve_attached_page(session_key)
            self._page.on("crash", self._on_page_crash)
            self._attached_cdp = True
            if self._reused_existing_page:
                logger.info("已连接用户现有 Chrome，并复用受控标签页")
            else:
                logger.info("已连接用户现有 Chrome，并创建受控标签页")
            if self._record_video_dir is not None:
                logger.info("CDP attach 模式不支持本地视频录制，已忽略 record_video_dir")
            return

        if chrome_user_data_dir is not None:
            channel = browser_channel or "chrome"
            args = list(_USER_CHROME_ARGS)
            if _in_docker:
                args.extend(_CHROME_DOCKER_ARGS)
            if chrome_profile_directory:
                args.append(f"--profile-directory={chrome_profile_directory}")

            launch_kwargs: dict[str, Any] = {
                "headless": headless,
                "args": args,
                "ignore_default_args": ["--enable-automation"],
            }
            if channel and channel != "chromium":
                launch_kwargs["channel"] = channel
            if self._record_video_dir is not None:
                launch_kwargs["record_video_dir"] = str(self._record_video_dir)
                launch_kwargs["record_video_size"] = {
                    "width": _DEFAULT_VIEWPORT_WIDTH,
                    "height": _DEFAULT_VIEWPORT_HEIGHT,
                }

            logger.info(
                "使用用户 Chrome profile | user_data_dir=%s | profile=%s | channel=%s",
                chrome_user_data_dir,
                chrome_profile_directory or "<default>",
                channel,
            )
            try:
                self._context = await self._playwright.chromium.launch_persistent_context(
                    str(chrome_user_data_dir),
                    **launch_kwargs,
                )
            except PlaywrightError as exc:
                raise BrowserControllerError(
                    "无法打开用户 Chrome profile。请确认该 profile 未被普通 Chrome 占用，"
                    "或改用 chrome_cdp_url 连接一个已用 --remote-debugging-port 启动的 Chrome。"
                    f" 原始错误：{exc}"
                ) from exc
            self._persistent = True

        elif profile_dir is not None:
            # 持久化模式：复用已有 Profile（Cookie / Storage 等）
            profile_dir = profile_dir.expanduser().resolve()
            profile_dir.mkdir(parents=True, exist_ok=True)
            logger.info(
                "持久化 Profile 目录：%s | engine=%s | humanize=%s",
                profile_dir,
                engine,
                humanize,
            )

            from payswitch.browser.engines import get_engine

            engine_impl = get_engine(engine)
            viewport = {
                "width": _DEFAULT_VIEWPORT_WIDTH,
                "height": _DEFAULT_VIEWPORT_HEIGHT,
            }

            # Docker 环境追加容器必需参数
            _launch_args = list(_ANTI_DETECTION_ARGS)
            if _in_docker:
                _launch_args.extend(_CHROME_DOCKER_ARGS)

            # 先按正常路径启动；若命中"已有会话占用"类错误，则清理残留锁并重试一次。
            try:
                self._context = await engine_impl.launch_persistent(
                    self._playwright,
                    user_data_dir=profile_dir,
                    headless=headless,
                    args=_launch_args,
                    user_agent=_DEFAULT_USER_AGENT,
                    viewport=viewport,
                    humanize=humanize,
                    human_preset=human_preset,
                    record_video_dir=self._record_video_dir,
                )
            except PlaywrightError as exc:
                err_text = str(exc)
                lock_like_error = (
                    "Target page, context or browser has been closed" in err_text
                    or "正在现有的浏览器会话中打开" in err_text
                    or "Opening in existing browser session" in err_text
                )
                if not lock_like_error:
                    raise

                logger.warning(
                    "检测到疑似 profile 锁冲突，清理 singleton 后重试一次：%s",
                    err_text,
                )
                _cleanup_chromium_singletons(profile_dir)
                self._context = await engine_impl.launch_persistent(
                    self._playwright,
                    user_data_dir=profile_dir,
                    headless=headless,
                    args=_launch_args,
                    user_agent=_DEFAULT_USER_AGENT,
                    viewport=viewport,
                    humanize=humanize,
                    human_preset=human_preset,
                    record_video_dir=self._record_video_dir,
                )
            self._persistent = True
            # 持久化模式下 _browser 保持 None
        else:
            # 普通模式：无状态浏览器
            logger.info(
                "无状态模式 | engine=%s | humanize=%s", engine, humanize
            )
            from payswitch.browser.engines import get_engine

            engine_impl = get_engine(engine)
            _stateless_args = list(_ANTI_DETECTION_ARGS)
            if _in_docker:
                _stateless_args.extend(_CHROME_DOCKER_ARGS)
            self._browser, self._context = await engine_impl.launch_stateless(
                self._playwright,
                headless=headless,
                args=_stateless_args,
                user_agent=_DEFAULT_USER_AGENT,
                viewport={
                    "width": _DEFAULT_VIEWPORT_WIDTH,
                    "height": _DEFAULT_VIEWPORT_HEIGHT,
                },
                humanize=humanize,
                human_preset=human_preset,
                record_video_dir=self._record_video_dir,
            )
            self._persistent = False

        self._video_recording_enabled = self._record_video_dir is not None

        # 注入 JS，在每个新页面打开时抹掉 webdriver 特征
        await self._context.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        )

        # 打开初始页面
        self._page = await self._context.new_page()

        # 监听页面崩溃事件
        self._page.on("crash", self._on_page_crash)

        logger.info("浏览器已启动")

    async def navigate(self, url: str) -> None:
        """导航到指定 URL。

        Args:
            url: 目标地址（需含协议前缀，如 ``https://``）。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动。
            PlaywrightTimeoutError: 页面加载超时。
        """
        page = await self._require_live_page()
        logger.info("导航至：%s", url)
        try:
            await page.goto(url, wait_until="domcontentloaded")
        except PlaywrightTimeoutError:
            logger.error("导航超时：%s", url)
            raise
        except PlaywrightError as exc:
            logger.error("导航失败：%s | 错误：%s", url, exc)
            raise

    async def screenshot(self, path: Path | None = None) -> bytes:
        """截取当前页面截图。

        Args:
            path: 若提供，同时将截图保存到该文件路径。

        Returns:
            PNG 格式的截图字节流。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动。
        """
        page = await self._require_live_page()
        kwargs: dict[str, Any] = {"type": "png", "full_page": False}
        if path is not None:
            kwargs["path"] = str(path.expanduser().resolve())

        png_bytes: bytes = await page.screenshot(**kwargs)
        logger.debug("截图完成，大小：%d bytes", len(png_bytes))
        return png_bytes

    async def get_page_content(self) -> str:
        """获取当前页面的完整 HTML 内容。

        Returns:
            页面 HTML 字符串。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动。
        """
        page = await self._require_live_page()
        content = await page.content()
        logger.debug("已获取页面内容，长度：%d chars", len(content))
        return content

    async def click(self, selector: str) -> None:
        """点击页面中匹配 ``selector`` 的元素。

        Args:
            selector: CSS / XPath / Playwright 文本选择器。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动。
            PlaywrightTimeoutError: 等待元素超时。
        """
        page = await self._require_live_page()
        logger.debug("点击元素：%s", selector)
        try:
            await page.click(selector)
        except PlaywrightTimeoutError:
            logger.error("点击超时，找不到元素：%s", selector)
            raise
        except PlaywrightError as exc:
            logger.error("点击失败：%s | 错误：%s", selector, exc)
            raise

    async def fill(self, selector: str, value: str) -> None:
        """清空并填写输入框。

        Args:
            selector: 目标输入框选择器。
            value: 填写的文本内容。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动。
            PlaywrightTimeoutError: 等待元素超时。
        """
        page = await self._require_live_page()
        logger.debug("填写输入框 %s，内容长度：%d", selector, len(value))
        try:
            await page.fill(selector, value)
        except PlaywrightTimeoutError:
            logger.error("填写超时，找不到元素：%s", selector)
            raise
        except PlaywrightError as exc:
            logger.error("填写失败：%s | 错误：%s", selector, exc)
            raise

    async def wait_for_selector(
        self,
        selector: str,
        timeout: float = 30.0,
    ) -> bool:
        """等待元素出现在 DOM 中。

        Args:
            selector: 目标元素选择器。
            timeout: 最长等待时间（秒），默认 30 秒。

        Returns:
            元素出现返回 ``True``；超时返回 ``False``（不抛异常）。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动。
        """
        page = await self._require_live_page()
        logger.debug("等待元素：%s（超时 %.1fs）", selector, timeout)
        try:
            # Playwright API 的 timeout 单位为毫秒
            await page.wait_for_selector(selector, timeout=timeout * 1000)
            logger.debug("元素已出现：%s", selector)
            return True
        except PlaywrightTimeoutError:
            logger.warning("等待元素超时：%s", selector)
            return False
        except PlaywrightError as exc:
            logger.error("等待元素出错：%s | 错误：%s", selector, exc)
            return False

    async def execute_script(self, script: str) -> Any:
        """在当前页面上下文中执行 JavaScript。

        Args:
            script: 合法的 JavaScript 表达式或函数体字符串。
                示例：``"document.title"`` 或 ``"() => window.scrollY"``

        Returns:
            脚本执行结果（由 Playwright 自动序列化为 Python 对象）。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动。
            PlaywrightError: 脚本执行错误。
        """
        page = await self._require_live_page()
        logger.debug("执行 JS（前 80 字符）：%s", script[:80])
        try:
            result = await page.evaluate(script)
            return result
        except PlaywrightError as exc:
            logger.error("JS 执行失败 | 错误：%s", exc)
            raise

    async def list_clickable_elements(self, limit: int = 80) -> list[dict[str, Any]]:
        """识别当前页面可交互元素（轻量 computer-use 能力）。

        Returns:
            元素列表。每项包含 index/text/tag/selector/position 等字段。
        """
        page = await self._require_live_page()
        bounded_limit = max(1, min(limit, 200))
        script = """
(maxItems) => {
  const safeMax = maxItems ?? 80;
  const selectors = [
    "button",
    "a[href]",
    "input:not([type='hidden'])",
    "select",
    "textarea",
    "[role='button']",
    "[onclick]",
    "[tabindex]:not([tabindex='-1'])"
  ];
  const interactiveSelector = selectors.join(",");
  const isVisible = (el) => {
    const rect = el.getBoundingClientRect();
    if (rect.width < 6 || rect.height < 6) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
      return false;
    }
    return el.getClientRects().length > 0;
  };
  const isClickableCandidate = (el) => {
    if (!(el instanceof Element)) return false;
    if (el.matches(interactiveSelector)) return true;
    const style = window.getComputedStyle(el);
    if (style.cursor === "pointer") return true;
    if ((el.getAttribute("role") || "").toLowerCase() === "link") return true;
    if (el.getAttribute("data-testid") || el.getAttribute("data-test")) return true;
    return false;
  };
  const nearestClickable = (el) => {
    let current = el;
    let depth = 0;
    while (current && depth < 6) {
      if (isClickableCandidate(current) && isVisible(current)) {
        return current;
      }
      current = current.parentElement;
      depth += 1;
    }
    return null;
  };
  const directNodes = Array.from(document.querySelectorAll(interactiveSelector));
  const textBackedNodes = Array.from(document.querySelectorAll("body *"))
    .filter((el) => {
      const text = (el.innerText || el.textContent || "").replace(/\\s+/g, " ").trim();
      return text.length > 0 && text.length <= 160;
    })
    .map((el) => nearestClickable(el))
    .filter(Boolean);
  const deduped = [];
  const seen = new Set();
  for (const node of [...directNodes, ...textBackedNodes]) {
    if (!(node instanceof Element)) continue;
    const rect = node.getBoundingClientRect();
    const key = [
      node.tagName,
      node.id || "",
      node.className || "",
      Math.round(rect.left),
      Math.round(rect.top),
      Math.round(rect.width),
      Math.round(rect.height),
    ].join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(node);
  }
  const rendered = deduped.filter((el) => isVisible(el));

  const visible = rendered.filter((el) => {
    const rect = el.getBoundingClientRect();
    return rect.bottom > 0 && rect.right > 0 &&
      rect.left < window.innerWidth && rect.top < window.innerHeight;
  });
  const chosen = visible.length > 0 ? visible : rendered;

  const toSelector = (el) => {
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 5) {
      let part = current.tagName.toLowerCase();
      if (current.classList && current.classList.length > 0) {
        part += "." + Array.from(current.classList).slice(0, 2).map((c) => CSS.escape(c)).join(".");
      }
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter((s) => s.tagName === current.tagName);
        if (siblings.length > 1) {
          part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
        }
      }
      parts.unshift(part);
      current = current.parentElement;
    }
    return parts.join(" > ");
  };

  return chosen
    .map((el, i) => {
      const rect = el.getBoundingClientRect();
      const text = (el.innerText || el.textContent || el.getAttribute("aria-label") || "")
        .replace(/\\s+/g, " ")
        .trim()
        .slice(0, 120);
      return {
        index: i,
        tag: el.tagName.toLowerCase(),
        type: el.getAttribute("type") || null,
        text,
        selector: toSelector(el),
        x: Math.round(rect.left + rect.width / 2),
        y: Math.round(rect.top + rect.height / 2),
        width: Math.round(rect.width),
        height: Math.round(rect.height),
      };
    })
    .slice(0, safeMax);
}
"""
        raw_items = await page.evaluate(script, bounded_limit)
        items = raw_items if isinstance(raw_items, list) else []
        self._last_clickables = items
        logger.info("识别到可点击元素：%d 个（limit=%d）", len(items), bounded_limit)
        return items

    async def inspect_page_state(
        self,
        *,
        clickable_limit: int = 80,
        text_limit: int = 80,
    ) -> dict[str, Any]:
        """Return structured page context for an external Computer Use agent.

        The output intentionally avoids dumping raw HTML. It gives the caller
        enough perception to reason about the page alongside a screenshot while
        keeping evidence compact and readable.
        """
        page = await self._require_live_page()
        clickables = await self.list_clickable_elements(limit=clickable_limit)
        bounded_text_limit = max(1, min(text_limit, 200))
        script = """
(maxTextItems) => {
  const isVisible = (el) => {
    const rect = el.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
      return false;
    }
    return el.getClientRects().length > 0 &&
      rect.bottom > 0 && rect.right > 0 &&
      rect.left < window.innerWidth && rect.top < window.innerHeight;
  };

  const toSelector = (el) => {
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 5) {
      let part = current.tagName.toLowerCase();
      if (current.classList && current.classList.length > 0) {
        part += "." + Array.from(current.classList).slice(0, 2).map((c) => CSS.escape(c)).join(".");
      }
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter((s) => s.tagName === current.tagName);
        if (siblings.length > 1) {
          part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
        }
      }
      parts.unshift(part);
      current = current.parentElement;
    }
    return parts.join(" > ");
  };

  const redactValue = (el) => {
    const type = (el.getAttribute("type") || "").toLowerCase();
    const nameParts = [
      el.getAttribute("name") || "",
      el.getAttribute("autocomplete") || "",
    ];
    const name = nameParts.join(" ").toLowerCase();
    const sensitive = type === "password" ||
      name.includes("password") || name.includes("passwd") ||
      name.includes("cvv") || name.includes("cvc") ||
      name.includes("security-code") || name.includes("otp") ||
      name.includes("sms") || name.includes("pin");
    if (sensitive) return null;
    const value = "value" in el ? String(el.value || "") : "";
    return value.slice(0, 80);
  };

  const controls = Array.from(document.querySelectorAll(
    "input:not([type='hidden']), textarea, select"
  ))
    .filter(isVisible)
    .map((el, index) => {
      const rect = el.getBoundingClientRect();
      return {
        index,
        tag: el.tagName.toLowerCase(),
        type: el.getAttribute("type") || null,
        name: el.getAttribute("name") || null,
        label: el.labels && el.labels.length > 0
          ? Array.from(el.labels)
              .map((label) => label.innerText || label.textContent || "")
              .join(" ")
              .replace(/\\s+/g, " ")
              .trim()
              .slice(0, 120)
          : null,
        placeholder: el.getAttribute("placeholder") || null,
        aria_label: el.getAttribute("aria-label") || null,
        value_preview: redactValue(el),
        has_value: Boolean("value" in el && el.value),
        disabled: Boolean(el.disabled || el.getAttribute("aria-disabled") === "true"),
        readonly: Boolean(el.readOnly),
        selector: toSelector(el),
        x: Math.round(rect.left + rect.width / 2),
        y: Math.round(rect.top + rect.height / 2),
        width: Math.round(rect.width),
        height: Math.round(rect.height),
      };
    });

  const textNodes = Array.from(document.body ? document.body.querySelectorAll("body *") : [])
    .filter(isVisible)
    .map((el) => (el.innerText || el.textContent || "").replace(/\\s+/g, " ").trim())
    .filter((text) => text.length > 0 && text.length <= 300)
    .filter((text, index, arr) => arr.indexOf(text) === index)
    .slice(0, maxTextItems);

  return {
    title: document.title || "",
    viewport: {
      width: window.innerWidth,
      height: window.innerHeight,
      scroll_x: Math.round(window.scrollX),
      scroll_y: Math.round(window.scrollY),
    },
    inputs: controls,
    visible_text: textNodes,
  };
}
"""
        raw_state = await page.evaluate(script, bounded_text_limit)
        state = raw_state if isinstance(raw_state, dict) else {}
        return {
            "title": state.get("title", ""),
            "viewport": state.get("viewport", {}),
            "clickables": clickables,
            "inputs": state.get("inputs", []),
            "visible_text": state.get("visible_text", []),
        }

    async def click_clickable_index(self, index: int) -> dict[str, Any]:
        """点击最近一次识别结果中的指定元素。"""
        page = await self._require_live_page()
        prior_pages = self._open_pages_snapshot()
        if not self._last_clickables:
            raise BrowserControllerError(
                "没有可点击元素缓存，请先调用 list_clickable_elements()"
            )
        if index < 0 or index >= len(self._last_clickables):
            raise BrowserControllerError(f"index 超出范围：{index}")

        target = self._last_clickables[index]
        selector = target.get("selector")
        if selector:
            try:
                await page.click(selector, timeout=5_000)
            except PlaywrightError:
                # selector 失效时回退坐标点击
                await page.mouse.click(float(target["x"]), float(target["y"]))
        else:
            await page.mouse.click(float(target["x"]), float(target["y"]))

        await self._adopt_new_page_if_opened(prior_pages)
        logger.info(
            "已按索引点击元素 index=%d tag=%s text=%s",
            index,
            target.get("tag"),
            target.get("text"),
        )
        return target

    async def click_clickable_text(self, keyword: str, exact: bool = False) -> dict[str, Any]:
        """按文本匹配点击可交互元素。

        两级匹配策略：
        1. 白名单元素匹配（标准 button/a/input 等，优先）
        2. Playwright locator 兜底（覆盖 React/Vue 等非标准组件）
        """
        if not keyword.strip():
            raise BrowserControllerError("keyword 不能为空")

        if not self._last_clickables:
            await self.list_clickable_elements()

        # Level 1：白名单元素匹配
        needle = keyword.strip().lower()
        for item in self._last_clickables:
            text = str(item.get("text") or "").strip()
            if not text:
                continue
            hay = text.lower()
            matched = hay == needle if exact else needle in hay
            if matched:
                return await self.click_clickable_index(int(item["index"]))

        # Level 2：Playwright locator 兜底（处理非标准可点击元素）
        page = self.page
        try:
            locator = page.get_by_text(keyword.strip(), exact=exact)
            target = locator.first
            await target.wait_for(state="visible", timeout=5000)
            await target.click()
            logger.info(
                "Locator 兜底点击成功 | keyword=%s | exact=%s",
                keyword,
                exact,
            )
            return {"text": keyword, "tag": "locator_fallback", "index": -1}
        except Exception as exc:
            raise BrowserControllerError(
                f"未找到匹配文本的可点击元素：{keyword}（白名单和 locator 均未命中）"
            ) from exc

    async def get_current_url(self) -> str:
        """获取当前页面的完整 URL。

        Returns:
            当前页面 URL 字符串。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动。
        """
        page = await self._require_live_page()
        url = page.url
        logger.debug("当前 URL：%s", url)
        return url

    async def close(self) -> None:
        """关闭浏览器并释放所有资源。

        持久化模式下会在关闭前保存 context（Playwright 自动处理）。
        安全：多次调用不会报错。
        """
        if self._context is not None:
            if self._attached_cdp:
                logger.info("跳过关闭用户 Chrome context，仅断开控制连接")
                self._context = None
                self._page = None
            else:
                logger.info("正在关闭浏览器 context …")
                try:
                    await self._context.close()
                except PlaywrightError as exc:
                    # context 已经关闭时会抛出，忽略即可
                    logger.debug("关闭 context 时出现可忽略错误：%s", exc)
                finally:
                    self._context = None
                    self._page = None

        if self._browser is not None and not self._attached_cdp:
            try:
                await self._browser.close()
            except PlaywrightError as exc:
                logger.debug("关闭 browser 时出现可忽略错误：%s", exc)
            finally:
                self._browser = None
        elif self._browser is not None:
            self._browser = None

        if self._playwright is not None:
            try:
                await self._playwright.stop()
            except Exception as exc:  # noqa: BLE001
                logger.debug("停止 playwright 时出现可忽略错误：%s", exc)
            finally:
                self._playwright = None
                self._attached_cdp = False

        logger.info("浏览器已完全关闭")

    @property
    def page(self) -> Page:
        """获取当前 Page 对象，供高级操作（如监听网络请求）使用。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动或 page 尚未初始化。
        """
        return self._require_page()

    @property
    def reused_existing_page(self) -> bool:
        """Return whether launch() attached to an existing tagged tab."""
        return self._reused_existing_page

    @property
    def record_video_dir(self) -> Path | None:
        """Return the raw recording output directory when enabled."""
        return self._record_video_dir

    @property
    def video_recording_enabled(self) -> bool:
        """Return whether this browser lifecycle is recording video."""
        return self._video_recording_enabled

    def recorded_video_files(self) -> list[Path]:
        """Return finalized recording files currently present on disk."""
        if self._record_video_dir is None or not self._record_video_dir.exists():
            return []
        return sorted(
            path
            for path in self._record_video_dir.rglob("*")
            if path.is_file() and path.suffix.lower() in {".webm", ".mp4"}
        )

    # ------------------------------------------------------------------
    # 异步上下文管理器支持
    # ------------------------------------------------------------------

    async def __aenter__(self) -> BrowserController:
        """进入 ``async with`` 块时自动 launch（无持久化 Profile）。"""
        await self.launch()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """退出 ``async with`` 块时自动 close。"""
        await self.close()

    # ------------------------------------------------------------------
    # 内部辅助方法
    # ------------------------------------------------------------------

    def _require_page(self) -> Page:
        """断言浏览器已启动并返回当前 Page。

        Raises:
            BrowserNotLaunchedError: 浏览器未启动或 Page 不可用。
        """
        if self._page is None:
            raise BrowserNotLaunchedError(
                "浏览器未启动，请先调用 await controller.launch()"
            )
        return self._page

    async def _require_live_page(self) -> Page:
        """Return the active page, recovering a replacement tab when needed."""
        page = self._page
        if page is not None and not page.is_closed():
            return page
        return await self._recover_active_page()

    async def _resolve_attached_page(self, session_key: str | None) -> Page:
        """Pick or create the controlled page when attached to existing Chrome."""
        context = self._context
        if context is None:
            raise BrowserNotLaunchedError("浏览器上下文不存在，无法选择受控标签页")

        marker = self._session_marker(session_key)
        if marker:
            existing = await self._find_tagged_page(marker)
            if existing is not None:
                self._reused_existing_page = True
                try:
                    await existing.bring_to_front()
                except PlaywrightError:
                    logger.debug("复用标签页前置失败（可忽略）")
                return existing

        page = await context.new_page()
        if marker:
            await self._tag_page(page, marker)
        return page

    async def _recover_active_page(self) -> Page:
        """Recover a usable page from the active browser context."""
        context = self._context
        if context is None:
            raise BrowserNotLaunchedError("浏览器上下文不存在，无法恢复页面")

        marker = self._session_marker(self._session_key)
        candidate: Page | None = None
        if marker:
            candidate = await self._find_tagged_page(marker)

        if candidate is None:
            for page in reversed(context.pages):
                if page.is_closed():
                    continue
                candidate = page
                break

        if candidate is None:
            raise BrowserNotLaunchedError("当前没有可恢复的浏览器页面")

        self._page = candidate
        if marker:
            await self._tag_page(candidate, marker)
        try:
            await candidate.bring_to_front()
        except PlaywrightError:
            logger.debug("恢复页面前置失败（可忽略）")
        candidate.on("crash", self._on_page_crash)
        logger.info("已自动恢复可控页面：%s", candidate.url)
        return candidate

    def _open_pages_snapshot(self) -> set[int]:
        """Capture currently open pages so click handlers can detect popups/new tabs."""
        context = self._context
        if context is None:
            return set()
        return {
            id(page)
            for page in context.pages
            if not page.is_closed()
        }

    async def _adopt_new_page_if_opened(self, prior_pages: set[int]) -> None:
        """Switch control to a popup/new tab opened by the last interaction."""
        context = self._context
        if context is None:
            return

        candidate: Page | None = None
        for page in reversed(context.pages):
            if page.is_closed() or id(page) in prior_pages:
                continue
            candidate = page
            break

        if candidate is None:
            return

        self._page = candidate
        marker = self._session_marker(self._session_key)
        if marker:
            await self._tag_page(candidate, marker)
        try:
            await candidate.bring_to_front()
        except PlaywrightError:
            logger.debug("切换到新页面前置失败（可忽略）")
        candidate.on("crash", self._on_page_crash)
        logger.info("检测到点击后打开新页面，已切换受控页：%s", candidate.url)

    async def _find_tagged_page(self, marker: str) -> Page | None:
        """Find an existing tab that belongs to the same Pay-Switch session."""
        context = self._context
        if context is None:
            return None

        for page in context.pages:
            if page.is_closed():
                continue
            try:
                page_marker = await page.evaluate("() => window.name || ''")
            except Exception:
                continue
            if page_marker == marker:
                return page
        return None

    async def _tag_page(self, page: Page, marker: str) -> None:
        """Mark the tab so later CDP attaches can recover the same page."""
        try:
            await page.evaluate("(marker) => { window.name = marker; }", marker)
        except Exception as exc:
            logger.debug("写入页面会话标记失败（可忽略）：%s", exc)

    def _session_marker(self, session_key: str | None) -> str | None:
        """Encode a transaction-scoped session marker stored in window.name."""
        if not session_key:
            return None
        return f"payswitch:{session_key}"

    def _on_page_crash(self, page: Page) -> None:  # noqa: ARG002
        """页面崩溃事件回调。记录日志，供外部监控系统感知。"""
        logger.error(
            "页面崩溃！当前 URL：%s",
            page.url if not page.is_closed() else "<已关闭>",
        )
        # 将内部 page 引用置空，后续操作会抛 BrowserNotLaunchedError
        self._page = None
