"""Pay-Switch agent language and payment-intent normalization.

The service accepts structured JSON, A2A messages, and a compact text language
called PSL (Pay-Switch Language). All inputs normalize to ``PaymentIntent`` so
the CLI, HTTP API, and A2A transport share one execution contract.
"""

from __future__ import annotations

import json
import re
from typing import Any

from pydantic import BaseModel, Field, field_validator

from payswitch.models.types import PaymentMethod


class PaymentIntent(BaseModel):
    """A normalized request for Pay-Switch to prepare or execute a payment."""

    amount: float = Field(gt=0)
    payee: str = Field(min_length=1)
    reason: str = ""
    currency: str = "CNY"
    method: PaymentMethod = PaymentMethod.auto
    idempotency_key: str | None = None
    callback_url: str | None = None
    dry_run: bool = False
    source_agent: str = "external"
    product: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("currency")
    @classmethod
    def _normalize_currency(cls, value: str) -> str:
        return value.strip().upper()

    @field_validator("payee")
    @classmethod
    def _normalize_payee(cls, value: str) -> str:
        return value.strip()

    @field_validator("reason")
    @classmethod
    def _normalize_reason(cls, value: str) -> str:
        return value.strip()


_PSL_RE = re.compile(
    r"""
    ^\s*
    PAY\s+(?P<amount>\d+(?:\.\d+)?)\s+(?P<currency>[A-Za-z]{3})
    \s+TO\s+(?P<payee>[A-Za-z0-9_.:@/-]+)
    (?:\s+FOR\s+"(?P<reason>[^"]*)")?
    (?:\s+VIA\s+(?P<method>[A-Za-z0-9_]+))?
    (?:\s+IDEMPOTENCY\s+"(?P<idempotency_key>[^"]+)")?
    (?:\s+(?P<mode>DRY_RUN|EXECUTE))?
    \s*$
    """,
    re.IGNORECASE | re.VERBOSE,
)


def quote_psl(value: str) -> str:
    """Quote a string for PSL."""

    return value.replace("\\", "\\\\").replace('"', '\\"')


def to_psl(intent: PaymentIntent) -> str:
    """Render an intent as stable Pay-Switch Language."""

    parts = [
        "PAY",
        f"{intent.amount:g}",
        intent.currency,
        "TO",
        intent.payee,
    ]
    if intent.reason:
        parts.extend(["FOR", f'"{quote_psl(intent.reason)}"'])
    if intent.method != PaymentMethod.auto:
        parts.extend(["VIA", intent.method.value])
    if intent.idempotency_key:
        parts.extend(["IDEMPOTENCY", f'"{quote_psl(intent.idempotency_key)}"'])
    parts.append("DRY_RUN" if intent.dry_run else "EXECUTE")
    return " ".join(parts)


def parse_psl(text: str, *, source_agent: str = "external") -> PaymentIntent:
    """Parse Pay-Switch Language into a payment intent."""

    match = _PSL_RE.match(text)
    if not match:
        raise ValueError(
            'Invalid PSL. Example: PAY 200 CNY TO deepseek FOR "API top-up" VIA alipay_qr'
        )
    data = match.groupdict()
    method = data.get("method") or PaymentMethod.auto.value
    mode = (data.get("mode") or "EXECUTE").upper()
    return PaymentIntent(
        amount=float(data["amount"]),
        currency=data["currency"],
        payee=data["payee"],
        reason=data.get("reason") or "",
        method=PaymentMethod(method),
        idempotency_key=data.get("idempotency_key"),
        dry_run=mode == "DRY_RUN",
        source_agent=source_agent,
    )


def intent_from_mapping(
    payload: dict[str, Any],
    *,
    source_agent: str = "external",
) -> PaymentIntent:
    """Normalize common JSON field shapes to ``PaymentIntent``."""

    data = dict(payload)
    if "merchant" in data and "payee" not in data:
        data["payee"] = data.pop("merchant")
    if "target" in data and "payee" not in data:
        data["payee"] = data.pop("target")
    if "idempotencyKey" in data and "idempotency_key" not in data:
        data["idempotency_key"] = data.pop("idempotencyKey")
    if "callbackUrl" in data and "callback_url" not in data:
        data["callback_url"] = data.pop("callbackUrl")
    data.setdefault("source_agent", source_agent)
    return PaymentIntent.model_validate(data)


def intent_from_text(text: str, *, source_agent: str = "external") -> PaymentIntent:
    """Parse an intent from JSON or PSL text."""

    stripped = text.strip()
    if not stripped:
        raise ValueError("Payment intent text is empty")
    if stripped.startswith("{"):
        return intent_from_mapping(json.loads(stripped), source_agent=source_agent)
    return parse_psl(stripped, source_agent=source_agent)


def intent_from_a2a_message(message: dict[str, Any]) -> PaymentIntent:
    """Extract a payment intent from an A2A-style message body."""

    source_agent = str(message.get("metadata", {}).get("source_agent") or "a2a")
    parts = message.get("parts")
    if not isinstance(parts, list):
        raise ValueError("A2A message must include parts")

    for part in parts:
        if not isinstance(part, dict):
            continue
        data = part.get("data")
        if isinstance(data, dict):
            if "payment" in data and isinstance(data["payment"], dict):
                return intent_from_mapping(data["payment"], source_agent=source_agent)
            if {"amount", "payee"} <= set(data):
                return intent_from_mapping(data, source_agent=source_agent)

    text_chunks = [
        str(part.get("text", "")).strip()
        for part in parts
        if isinstance(part, dict) and str(part.get("text", "")).strip()
    ]
    if text_chunks:
        return intent_from_text("\n".join(text_chunks), source_agent=source_agent)

    raise ValueError("A2A message did not contain a payment intent")
