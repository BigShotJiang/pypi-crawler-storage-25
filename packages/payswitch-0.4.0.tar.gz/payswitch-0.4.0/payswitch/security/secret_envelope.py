"""Encrypted A2A secret delivery for post-purchase API keys.

The receiving agent keeps the X25519 private key locally and sends only the raw
public key to Pay-Switch. Pay-Switch encrypts API keys into an authenticated
envelope that the receiving agent can decrypt with its local decoder.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from datetime import UTC, datetime
from typing import Any

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

SECRET_ENVELOPE_SCHEMA = "pay-switch.secret-envelope.v1"
SECRET_INBOX_SCHEMA = "pay-switch.secret-inbox.v1"
SECRET_ENVELOPE_ALGORITHM = "X25519-HKDF-SHA256-AES-256-GCM"
_HKDF_INFO = b"pay-switch.secret-envelope.v1"


class SecretEnvelopeError(ValueError):
    """Raised when an encrypted secret envelope cannot be processed."""


def b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _canonical_json(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode(
        "utf-8"
    )


def _public_key_from_b64(public_key: str) -> x25519.X25519PublicKey:
    try:
        return x25519.X25519PublicKey.from_public_bytes(b64url_decode(public_key))
    except (ValueError, TypeError) as exc:
        raise SecretEnvelopeError("invalid recipient public key") from exc


def _private_key_from_b64(private_key: str) -> x25519.X25519PrivateKey:
    try:
        return x25519.X25519PrivateKey.from_private_bytes(b64url_decode(private_key))
    except (ValueError, TypeError) as exc:
        raise SecretEnvelopeError("invalid recipient private key") from exc


def _raw_public_key(public_key: x25519.X25519PublicKey) -> str:
    return b64url_encode(
        public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
    )


def _raw_private_key(private_key: x25519.X25519PrivateKey) -> str:
    return b64url_encode(
        private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )


def public_key_fingerprint(public_key: str) -> str:
    digest = hashlib.sha256(public_key.encode("ascii")).digest()
    return b64url_encode(digest[:12])


def generate_secret_inbox(*, created_at: str | None = None) -> dict[str, Any]:
    private_key = x25519.X25519PrivateKey.generate()
    public_key = _raw_public_key(private_key.public_key())
    return {
        "schema": SECRET_INBOX_SCHEMA,
        "algorithm": SECRET_ENVELOPE_ALGORITHM,
        "created_at": created_at or _now(),
        "private_key": _raw_private_key(private_key),
        "public_key": public_key,
        "recipient_id": public_key_fingerprint(public_key),
    }


def _derive_key(shared_secret: bytes, salt: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        info=_HKDF_INFO,
    ).derive(shared_secret)


def encrypt_secret(
    secret: str | bytes,
    *,
    recipient_public_key: str,
    provider: str,
    secret_type: str = "api_key",
    key_name: str | None = None,
    metadata: dict[str, Any] | None = None,
    created_at: str | None = None,
) -> dict[str, Any]:
    """Encrypt a secret for the receiving agent's public key."""

    if not recipient_public_key:
        raise SecretEnvelopeError("recipient_public_key is required")
    provider = provider.strip()
    if not provider:
        raise SecretEnvelopeError("provider is required")

    recipient = _public_key_from_b64(recipient_public_key)
    ephemeral = x25519.X25519PrivateKey.generate()
    salt = os.urandom(16)
    nonce = os.urandom(12)
    shared_secret = ephemeral.exchange(recipient)
    aes_key = _derive_key(shared_secret, salt)

    if isinstance(secret, str):
        plaintext = secret.encode("utf-8")
    else:
        plaintext = secret

    envelope: dict[str, Any] = {
        "schema": SECRET_ENVELOPE_SCHEMA,
        "algorithm": SECRET_ENVELOPE_ALGORITHM,
        "provider": provider,
        "secret_type": secret_type or "api_key",
        "key_name": key_name,
        "created_at": created_at or _now(),
        "recipient_public_key": recipient_public_key,
        "recipient_id": public_key_fingerprint(recipient_public_key),
        "ephemeral_public_key": _raw_public_key(ephemeral.public_key()),
        "salt": b64url_encode(salt),
        "nonce": b64url_encode(nonce),
        "metadata": dict(metadata or {}),
    }
    aad = _canonical_json(envelope)
    ciphertext = AESGCM(aes_key).encrypt(nonce, plaintext, aad)
    envelope["ciphertext"] = b64url_encode(ciphertext)
    return envelope


def decrypt_secret(envelope: dict[str, Any], *, recipient_private_key: str) -> bytes:
    """Decrypt an envelope with the receiving agent's private key."""

    if envelope.get("schema") != SECRET_ENVELOPE_SCHEMA:
        raise SecretEnvelopeError("unsupported secret envelope schema")
    if envelope.get("algorithm") != SECRET_ENVELOPE_ALGORITHM:
        raise SecretEnvelopeError("unsupported secret envelope algorithm")
    private_key = _private_key_from_b64(recipient_private_key)
    recipient_public_key = str(envelope.get("recipient_public_key") or "")
    if not recipient_public_key:
        raise SecretEnvelopeError("missing envelope field: recipient_public_key")
    actual_public_key = _raw_public_key(private_key.public_key())
    if not hmac.compare_digest(recipient_public_key, actual_public_key):
        raise SecretEnvelopeError("recipient public key mismatch")
    recipient_id = str(envelope.get("recipient_id") or "")
    if recipient_id and not hmac.compare_digest(
        recipient_id,
        public_key_fingerprint(actual_public_key),
    ):
        raise SecretEnvelopeError("recipient id mismatch")
    try:
        ephemeral = _public_key_from_b64(str(envelope["ephemeral_public_key"]))
        salt = b64url_decode(str(envelope["salt"]))
        nonce = b64url_decode(str(envelope["nonce"]))
        ciphertext = b64url_decode(str(envelope["ciphertext"]))
    except KeyError as exc:
        raise SecretEnvelopeError(f"missing envelope field: {exc.args[0]}") from exc

    aad_payload = dict(envelope)
    aad_payload.pop("ciphertext", None)
    aad = _canonical_json(aad_payload)
    shared_secret = private_key.exchange(ephemeral)
    aes_key = _derive_key(shared_secret, salt)
    try:
        return AESGCM(aes_key).decrypt(nonce, ciphertext, aad)
    except Exception as exc:  # cryptography raises InvalidTag without useful text
        raise SecretEnvelopeError("secret envelope authentication failed") from exc


def decrypt_secret_text(envelope: dict[str, Any], *, recipient_private_key: str) -> str:
    return decrypt_secret(envelope, recipient_private_key=recipient_private_key).decode("utf-8")
