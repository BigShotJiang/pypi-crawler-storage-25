"""OS-backed storage for card instruments.

支持两种存储格式：
- card-number-only（旧版）：仅存 PAN 字符串
- virtual-card（新版）：存完整虚拟卡 JSON blob（卡号+有效期+CVV+姓名+地址）
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass

from payswitch.security.redaction import mask_pan

SERVICE_NAME = "payswitch-card-number-only"
VIRTUAL_CARD_SERVICE = "payswitch-virtual-card"


@dataclass
class BillingAddress:
    """账单地址。"""

    line1: str = ""
    line2: str = ""
    city: str = ""
    state: str = ""
    postal_code: str = ""
    country: str = "US"


@dataclass
class VirtualCardData:
    """虚拟卡完整数据，存储在 OS Keyring 中。"""

    card_number: str  # Luhn 校验后的纯数字
    expiry_month: str = ""  # "04"
    expiry_year: str = ""  # "31" 或 "2031"
    cvv: str = ""  # "625"
    holder_name: str = ""  # "Loki White"
    billing_address: BillingAddress | None = None


class CardVaultError(RuntimeError):
    """Raised when the local card vault cannot complete an operation."""


def normalize_pan(card_number: str) -> str:
    """Normalize and validate a card number for local storage."""
    digits = re.sub(r"\D", "", card_number)
    if len(digits) < 13 or len(digits) > 19:
        raise ValueError("卡号长度应为 13-19 位数字")
    if not _luhn_valid(digits):
        raise ValueError("卡号未通过 Luhn 校验")
    return digits


def store_card_number(secret_ref: str, card_number: str) -> str:
    """Store a card number in OS keyring and return its masked display value."""
    pan = normalize_pan(card_number)
    keyring = _load_keyring()
    try:
        keyring.set_password(SERVICE_NAME, secret_ref, pan)
    except Exception as exc:  # pragma: no cover - backend-specific
        raise CardVaultError(f"写入 OS keyring 失败：{exc}") from exc
    return mask_pan(pan)


def load_card_number(secret_ref: str) -> str | None:
    """Load a card number from OS keyring."""
    keyring = _load_keyring()
    try:
        return keyring.get_password(SERVICE_NAME, secret_ref)
    except Exception as exc:  # pragma: no cover - backend-specific
        raise CardVaultError(f"读取 OS keyring 失败：{exc}") from exc


def delete_card_number(secret_ref: str) -> None:
    """Delete a card number from OS keyring."""
    keyring = _load_keyring()
    try:
        keyring.delete_password(SERVICE_NAME, secret_ref)
    except Exception:
        # keyring backends differ when the entry does not exist. Removing config
        # metadata should still be possible if the secret was already absent.
        return


def store_virtual_card(secret_ref: str, card: VirtualCardData) -> str:
    """存储虚拟卡完整信息到 OS Keyring，返回脱敏显示。"""
    # 卡号仍然做 Luhn 校验
    card.card_number = normalize_pan(card.card_number)
    keyring = _load_keyring()
    blob = json.dumps(asdict(card), ensure_ascii=False)
    try:
        keyring.set_password(VIRTUAL_CARD_SERVICE, secret_ref, blob)
    except Exception as exc:  # pragma: no cover - backend-specific
        raise CardVaultError(f"写入 OS keyring 失败：{exc}") from exc
    return mask_pan(card.card_number)


def load_virtual_card(secret_ref: str) -> VirtualCardData | None:
    """从 OS Keyring 加载虚拟卡完整信息。"""
    keyring = _load_keyring()
    try:
        secret = keyring.get_password(VIRTUAL_CARD_SERVICE, secret_ref)
    except Exception as exc:  # pragma: no cover - backend-specific
        raise CardVaultError(f"读取 OS keyring 失败：{exc}") from exc
    if secret is None:
        return None
    data = json.loads(secret)
    # 重建 BillingAddress（如果存在）
    addr_data = data.pop("billing_address", None)
    addr = BillingAddress(**addr_data) if addr_data else None
    return VirtualCardData(**data, billing_address=addr)


def delete_virtual_card(secret_ref: str) -> None:
    """从 OS Keyring 删除虚拟卡。"""
    keyring = _load_keyring()
    try:
        keyring.delete_password(VIRTUAL_CARD_SERVICE, secret_ref)
    except Exception:
        return


def _load_keyring():
    try:
        import keyring  # type: ignore[import-not-found]
    except Exception as exc:  # pragma: no cover - exercised when dependency missing
        raise CardVaultError(
            "未安装 keyring，无法安全保存卡号。请先安装依赖或运行 uv sync。"
        ) from exc
    return keyring


def _luhn_valid(value: str) -> bool:
    digits = [int(ch) for ch in value if ch.isdigit()]
    total = 0
    parity = len(digits) % 2
    for index, digit in enumerate(digits):
        if index % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0
