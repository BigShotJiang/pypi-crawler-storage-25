"""Background cleanup primitives for expired artifact metadata."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass
from datetime import UTC, datetime

from payswitch.security.artifacts import ArtifactStore


@dataclass(slots=True)
class ArtifactCleanupCycleResult:
    """One cleanup cycle over expired artifacts."""

    cleaned: int
    deleted: int
    metadata_only: int
    dry_run: bool
    items: list[dict[str, object]]


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


class ArtifactCleanupRunner:
    """Run artifact cleanup through a bounded background loop."""

    def __init__(
        self,
        store: ArtifactStore,
        *,
        poll_interval_seconds: float = 5.0,
        batch_limit: int = 25,
        max_idle_polls: int = 3,
        sleep_fn: Callable[[float], None] = time.sleep,
    ) -> None:
        if batch_limit < 1:
            raise ValueError("batch_limit must be >= 1")
        if max_idle_polls < 1:
            raise ValueError("max_idle_polls must be >= 1")
        if poll_interval_seconds < 0:
            raise ValueError("poll_interval_seconds must be >= 0")
        self._store = store
        self._poll_interval_seconds = poll_interval_seconds
        self._batch_limit = batch_limit
        self._max_idle_polls = max_idle_polls
        self._sleep_fn = sleep_fn

    def run_once(self, *, dry_run: bool = False) -> ArtifactCleanupCycleResult:
        items = self._store.cleanup_expired(limit=self._batch_limit, dry_run=dry_run)
        return ArtifactCleanupCycleResult(
            cleaned=len(items),
            deleted=sum(1 for item in items if item["action"] in {"deleted", "would_delete"}),
            metadata_only=sum(
                1
                for item in items
                if item["action"] in {"deleted_metadata_only", "would_delete_metadata_only"}
            ),
            dry_run=dry_run,
            items=items,
        )

    def run_loop(
        self,
        *,
        dry_run: bool = False,
        max_cycles: int | None = None,
    ) -> dict[str, object]:
        if max_cycles is not None and max_cycles < 1:
            raise ValueError("max_cycles must be >= 1")

        cycles = 0
        idle_polls = 0
        history: list[dict[str, object]] = []

        while True:
            cycle = self.run_once(dry_run=dry_run)
            cycles += 1
            if cycle.cleaned == 0:
                idle_polls += 1
            else:
                idle_polls = 0
            history.append(asdict(cycle))

            if max_cycles is not None and cycles >= max_cycles:
                break
            if idle_polls >= self._max_idle_polls:
                break
            if cycle.cleaned == 0 and self._poll_interval_seconds > 0:
                self._sleep_fn(self._poll_interval_seconds)

        return {
            "cycles": cycles,
            "idle_polls": idle_polls,
            "poll_interval_seconds": self._poll_interval_seconds,
            "batch_limit": self._batch_limit,
            "max_idle_polls": self._max_idle_polls,
            "dry_run": dry_run,
            "total_cleaned": sum(int(entry["cleaned"]) for entry in history),
            "total_deleted": sum(int(entry["deleted"]) for entry in history),
            "total_metadata_only": sum(int(entry["metadata_only"]) for entry in history),
            "history": history,
        }


class ArtifactCleanupSupervisor:
    """Service-owned supervisor for expired artifact cleanup."""

    def __init__(
        self,
        store: ArtifactStore,
        *,
        poll_interval_seconds: float = 300.0,
        batch_limit: int = 25,
        dry_run: bool = False,
    ) -> None:
        self._runner = ArtifactCleanupRunner(
            store,
            poll_interval_seconds=poll_interval_seconds,
            batch_limit=batch_limit,
            max_idle_polls=1,
        )
        self._dry_run = dry_run
        self._poll_interval_seconds = poll_interval_seconds
        self._batch_limit = batch_limit
        self._stop_event = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._cycles = 0
        self._total_cleaned = 0
        self._total_deleted = 0
        self._total_metadata_only = 0
        self._last_started_at: str | None = None
        self._last_finished_at: str | None = None
        self._last_error: str | None = None

    async def start(self) -> None:
        if self._task is not None and not self._task.done():
            return
        self._stop_event = asyncio.Event()
        self._task = asyncio.create_task(self._run(), name="artifact-cleanup-supervisor")

    async def stop(self) -> None:
        if self._task is None:
            return
        self._stop_event.set()
        await self._task
        self._task = None

    def snapshot(self) -> dict[str, object]:
        running = self._task is not None and not self._task.done()
        return {
            "enabled": True,
            "running": running,
            "dry_run": self._dry_run,
            "poll_interval_seconds": self._poll_interval_seconds,
            "batch_limit": self._batch_limit,
            "cycles": self._cycles,
            "total_cleaned": self._total_cleaned,
            "total_deleted": self._total_deleted,
            "total_metadata_only": self._total_metadata_only,
            "last_started_at": self._last_started_at,
            "last_finished_at": self._last_finished_at,
            "last_error": self._last_error,
        }

    async def _run(self) -> None:
        while not self._stop_event.is_set():
            self._last_started_at = _utc_now()
            try:
                result = await asyncio.to_thread(
                    self._runner.run_once,
                    dry_run=self._dry_run,
                )
                self._cycles += 1
                self._total_cleaned += result.cleaned
                self._total_deleted += result.deleted
                self._total_metadata_only += result.metadata_only
                self._last_error = None
            except Exception as exc:  # pragma: no cover - defensive telemetry path
                self._last_error = str(exc)
            finally:
                self._last_finished_at = _utc_now()

            if self._stop_event.is_set():
                break
            if self._poll_interval_seconds <= 0:
                await asyncio.sleep(0)
                continue
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self._poll_interval_seconds,
                )
            except TimeoutError:
                continue


@dataclass(slots=True)
class ArtifactBudgetEnforcementCycleResult:
    """One storage-budget enforcement cycle."""

    triggered: bool
    cleaned: int
    deleted: int
    metadata_only: int
    reclaimed_bytes: int
    budget_bytes: int
    target_bytes: int
    projected_total_bytes: int
    projected_over_budget: bool
    within_target: bool
    dry_run: bool
    include_sensitive: bool
    items: list[dict[str, object]]


class ArtifactBudgetEnforcementRunner:
    """Run bounded artifact budget enforcement over stored evidence."""

    def __init__(
        self,
        store: ArtifactStore,
        *,
        budget_bytes: int,
        target_ratio: float = 0.9,
        poll_interval_seconds: float = 5.0,
        batch_limit: int = 25,
        max_idle_polls: int = 3,
        include_sensitive: bool = False,
        sleep_fn: Callable[[float], None] = time.sleep,
    ) -> None:
        if budget_bytes < 1:
            raise ValueError("budget_bytes must be >= 1")
        if not 0 < target_ratio <= 1:
            raise ValueError("target_ratio must be in (0, 1]")
        if batch_limit < 1:
            raise ValueError("batch_limit must be >= 1")
        if max_idle_polls < 1:
            raise ValueError("max_idle_polls must be >= 1")
        if poll_interval_seconds < 0:
            raise ValueError("poll_interval_seconds must be >= 0")
        self._store = store
        self._budget_bytes = budget_bytes
        self._target_ratio = target_ratio
        self._target_bytes = int(budget_bytes * target_ratio)
        self._poll_interval_seconds = poll_interval_seconds
        self._batch_limit = batch_limit
        self._max_idle_polls = max_idle_polls
        self._include_sensitive = include_sensitive
        self._sleep_fn = sleep_fn

    def run_once(self, *, dry_run: bool = False) -> ArtifactBudgetEnforcementCycleResult:
        payload = self._store.enforce_budget(
            budget_bytes=self._budget_bytes,
            target_bytes=self._target_bytes,
            limit=self._batch_limit,
            dry_run=dry_run,
            include_sensitive=self._include_sensitive,
        )
        return ArtifactBudgetEnforcementCycleResult(
            triggered=bool(payload["triggered"]),
            cleaned=int(payload["cleaned"]),
            deleted=int(payload["deleted"]),
            metadata_only=int(payload["metadata_only"]),
            reclaimed_bytes=int(payload["reclaimed_bytes"]),
            budget_bytes=int(payload["budget_bytes"]),
            target_bytes=int(payload["target_bytes"]),
            projected_total_bytes=int(payload["projected_total_bytes"]),
            projected_over_budget=bool(payload["projected_over_budget"]),
            within_target=bool(payload["within_target"]),
            dry_run=bool(payload["dry_run"]),
            include_sensitive=bool(payload["include_sensitive"]),
            items=list(payload["items"]),
        )

    def run_loop(
        self,
        *,
        dry_run: bool = False,
        max_cycles: int | None = None,
    ) -> dict[str, object]:
        if max_cycles is not None and max_cycles < 1:
            raise ValueError("max_cycles must be >= 1")

        cycles = 0
        idle_polls = 0
        history: list[dict[str, object]] = []

        while True:
            cycle = self.run_once(dry_run=dry_run)
            cycles += 1
            if not cycle.triggered or cycle.cleaned == 0:
                idle_polls += 1
            else:
                idle_polls = 0
            history.append(asdict(cycle))

            if max_cycles is not None and cycles >= max_cycles:
                break
            if idle_polls >= self._max_idle_polls:
                break
            if (not cycle.triggered or cycle.cleaned == 0) and self._poll_interval_seconds > 0:
                self._sleep_fn(self._poll_interval_seconds)

        return {
            "cycles": cycles,
            "idle_polls": idle_polls,
            "poll_interval_seconds": self._poll_interval_seconds,
            "batch_limit": self._batch_limit,
            "max_idle_polls": self._max_idle_polls,
            "budget_bytes": self._budget_bytes,
            "target_ratio": self._target_ratio,
            "target_bytes": self._target_bytes,
            "dry_run": dry_run,
            "include_sensitive": self._include_sensitive,
            "total_triggered": sum(1 for entry in history if entry["triggered"]),
            "total_cleaned": sum(int(entry["cleaned"]) for entry in history),
            "total_deleted": sum(int(entry["deleted"]) for entry in history),
            "total_metadata_only": sum(int(entry["metadata_only"]) for entry in history),
            "total_reclaimed_bytes": sum(int(entry["reclaimed_bytes"]) for entry in history),
            "history": history,
        }


class ArtifactBudgetEnforcementSupervisor:
    """Service-owned supervisor for artifact storage-budget enforcement."""

    def __init__(
        self,
        store: ArtifactStore,
        *,
        budget_bytes: int,
        target_ratio: float = 0.9,
        poll_interval_seconds: float = 300.0,
        batch_limit: int = 25,
        include_sensitive: bool = False,
        dry_run: bool = False,
    ) -> None:
        self._runner = ArtifactBudgetEnforcementRunner(
            store,
            budget_bytes=budget_bytes,
            target_ratio=target_ratio,
            poll_interval_seconds=poll_interval_seconds,
            batch_limit=batch_limit,
            max_idle_polls=1,
            include_sensitive=include_sensitive,
        )
        self._dry_run = dry_run
        self._budget_bytes = budget_bytes
        self._target_ratio = target_ratio
        self._target_bytes = int(budget_bytes * target_ratio)
        self._poll_interval_seconds = poll_interval_seconds
        self._batch_limit = batch_limit
        self._include_sensitive = include_sensitive
        self._stop_event = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._cycles = 0
        self._total_triggered = 0
        self._total_cleaned = 0
        self._total_deleted = 0
        self._total_metadata_only = 0
        self._total_reclaimed_bytes = 0
        self._last_started_at: str | None = None
        self._last_finished_at: str | None = None
        self._last_error: str | None = None

    async def start(self) -> None:
        if self._task is not None and not self._task.done():
            return
        self._stop_event = asyncio.Event()
        self._task = asyncio.create_task(
            self._run(),
            name="artifact-budget-enforcement-supervisor",
        )

    async def stop(self) -> None:
        if self._task is None:
            return
        self._stop_event.set()
        await self._task
        self._task = None

    def snapshot(self) -> dict[str, object]:
        running = self._task is not None and not self._task.done()
        return {
            "enabled": True,
            "running": running,
            "dry_run": self._dry_run,
            "budget_bytes": self._budget_bytes,
            "target_ratio": self._target_ratio,
            "target_bytes": self._target_bytes,
            "include_sensitive": self._include_sensitive,
            "poll_interval_seconds": self._poll_interval_seconds,
            "batch_limit": self._batch_limit,
            "cycles": self._cycles,
            "total_triggered": self._total_triggered,
            "total_cleaned": self._total_cleaned,
            "total_deleted": self._total_deleted,
            "total_metadata_only": self._total_metadata_only,
            "total_reclaimed_bytes": self._total_reclaimed_bytes,
            "last_started_at": self._last_started_at,
            "last_finished_at": self._last_finished_at,
            "last_error": self._last_error,
        }

    async def _run(self) -> None:
        while not self._stop_event.is_set():
            self._last_started_at = _utc_now()
            try:
                result = await asyncio.to_thread(
                    self._runner.run_once,
                    dry_run=self._dry_run,
                )
                self._cycles += 1
                if result.triggered:
                    self._total_triggered += 1
                self._total_cleaned += result.cleaned
                self._total_deleted += result.deleted
                self._total_metadata_only += result.metadata_only
                self._total_reclaimed_bytes += result.reclaimed_bytes
                self._last_error = None
            except Exception as exc:  # pragma: no cover - defensive telemetry path
                self._last_error = str(exc)
            finally:
                self._last_finished_at = _utc_now()

            if self._stop_event.is_set():
                break
            if self._poll_interval_seconds <= 0:
                await asyncio.sleep(0)
                continue
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self._poll_interval_seconds,
                )
            except TimeoutError:
                continue
