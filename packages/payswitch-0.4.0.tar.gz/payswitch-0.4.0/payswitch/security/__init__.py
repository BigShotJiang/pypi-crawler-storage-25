"""Security helpers for local payment instruments and evidence redaction."""
