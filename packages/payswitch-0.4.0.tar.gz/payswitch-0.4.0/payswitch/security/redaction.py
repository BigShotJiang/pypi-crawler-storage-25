"""Redaction helpers for payment-sensitive data."""

from __future__ import annotations

import re
from typing import Any

_PAN_CANDIDATE_RE = re.compile(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)")


def _luhn_valid(value: str) -> bool:
    digits = [int(ch) for ch in value if ch.isdigit()]
    if len(digits) < 13 or len(digits) > 19:
        return False
    total = 0
    parity = len(digits) % 2
    for index, digit in enumerate(digits):
        if index % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0


def mask_cvv(value: str) -> str:
    """CVV 脱敏，固定返回三个星号（不管 CVV 是 3 位还是 4 位）。"""
    return "***"


def mask_expiry(month: str, year: str) -> str:
    """有效期脱敏，返回 ``**/**``。"""
    return "**/**"


def mask_pan(value: str) -> str:
    """Return a display-safe PAN mask."""
    digits = "".join(ch for ch in value if ch.isdigit())
    if len(digits) < 8:
        return "****"
    return f"{digits[:6]}******{digits[-4:]}"


def redact_sensitive_text(value: str) -> str:
    """Redact Luhn-valid card-number-like substrings from text."""

    def replace(match: re.Match[str]) -> str:
        candidate = match.group(0)
        digits = "".join(ch for ch in candidate if ch.isdigit())
        if not _luhn_valid(digits):
            return candidate
        return f"[REDACTED_PAN:{mask_pan(digits)}]"

    return _PAN_CANDIDATE_RE.sub(replace, value)


def redact_sensitive_data(value: Any) -> Any:
    """Recursively redact PAN-like values before logging or writing evidence."""
    if isinstance(value, str):
        return redact_sensitive_text(value)
    if isinstance(value, list):
        return [redact_sensitive_data(item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_sensitive_data(item) for item in value)
    if isinstance(value, dict):
        return {key: redact_sensitive_data(item) for key, item in value.items()}
    return value
