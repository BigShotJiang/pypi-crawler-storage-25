"""Artifact storage helpers with sensitivity classification and local encryption."""

from __future__ import annotations

import base64
import binascii
import json
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from pathlib import Path
from typing import Any
from urllib.parse import unquote_to_bytes

from payswitch.security.secret_envelope import (
    SECRET_ENVELOPE_ALGORITHM,
    decrypt_secret,
    encrypt_secret,
    generate_secret_inbox,
)

ARTIFACT_ENVELOPE_SCHEMA = "pay-switch.artifact-envelope.v1"
ARTIFACT_HANDOFF_SCHEMA = "pay-switch.artifact-handoff.v1"
ARTIFACT_METADATA_SCHEMA = "pay-switch.artifact-metadata.v1"


def decode_data_url_payload(data_url: str) -> tuple[str, bytes] | None:
    if not data_url.startswith("data:"):
        return None
    try:
        header, payload = data_url.split(",", 1)
    except ValueError:
        return None
    meta = header[5:]
    parts = [part for part in meta.split(";") if part]
    content_type = parts[0] if parts else "text/plain"
    is_base64 = any(part == "base64" for part in parts[1:] if parts)
    try:
        raw = base64.b64decode(payload) if is_base64 else unquote_to_bytes(payload)
    except (binascii.Error, ValueError):
        return None
    return content_type, raw


class ArtifactSensitivity(StrEnum):
    public = "public"
    internal = "internal"
    sensitive = "sensitive"


class ArtifactStore:
    """Persist artifacts with sidecar metadata and optional local encryption."""

    def __init__(
        self,
        data_dir: Path,
        *,
        public_retention_hours: int = 24,
        internal_retention_hours: int = 168,
        sensitive_retention_hours: int = 72,
    ) -> None:
        self._data_dir = data_dir.expanduser().resolve()
        self._security_dir = self._data_dir / "security"
        self._inbox_path = self._security_dir / "artifact-inbox.json"
        self._public_retention_hours = public_retention_hours
        self._internal_retention_hours = internal_retention_hours
        self._sensitive_retention_hours = sensitive_retention_hours
        self._cached_inbox: dict[str, Any] | None = None

    def write_json(
        self,
        path: Path,
        payload: Any,
        *,
        artifact_kind: str,
        sensitivity: ArtifactSensitivity,
        retention_hours: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Path:
        path = path.expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        content = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, default=str)
        record = self._artifact_record(
            path=path,
            artifact_kind=artifact_kind,
            sensitivity=sensitivity,
            content_type="application/json",
            retention_hours=retention_hours,
            metadata=metadata,
            encrypted=sensitivity == ArtifactSensitivity.sensitive,
        )
        if sensitivity == ArtifactSensitivity.sensitive:
            envelope = encrypt_secret(
                content.encode("utf-8"),
                recipient_public_key=self._local_inbox()["public_key"],
                provider="pay-switch",
                secret_type="artifact",
                key_name=path.name,
                metadata={
                    "artifact_kind": artifact_kind,
                    "content_type": "application/json",
                    "path": str(path),
                },
            )
            wrapped_payload = {
                "schema": ARTIFACT_ENVELOPE_SCHEMA,
                "artifact": record,
                "envelope": envelope,
            }
            path.write_text(
                json.dumps(wrapped_payload, ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8",
            )
        else:
            path.write_text(content, encoding="utf-8")
        self._write_metadata(path, record)
        return path

    def write_bytes(
        self,
        path: Path,
        payload: bytes,
        *,
        artifact_kind: str,
        sensitivity: ArtifactSensitivity,
        content_type: str,
        retention_hours: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Path:
        path = path.expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        record = self._artifact_record(
            path=path,
            artifact_kind=artifact_kind,
            sensitivity=sensitivity,
            content_type=content_type,
            retention_hours=retention_hours,
            metadata=metadata,
            encrypted=sensitivity == ArtifactSensitivity.sensitive,
        )
        if sensitivity == ArtifactSensitivity.sensitive:
            envelope = encrypt_secret(
                payload,
                recipient_public_key=self._local_inbox()["public_key"],
                provider="pay-switch",
                secret_type="artifact",
                key_name=path.name,
                metadata={
                    "artifact_kind": artifact_kind,
                    "content_type": content_type,
                    "path": str(path),
                },
            )
            wrapped_payload = {
                "schema": ARTIFACT_ENVELOPE_SCHEMA,
                "artifact": record,
                "envelope": envelope,
            }
            path.write_text(
                json.dumps(wrapped_payload, ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8",
            )
        else:
            path.write_bytes(payload)
        self._write_metadata(path, record)
        return path

    def read_json(self, path: Path) -> Any:
        path = path.expanduser()
        payload = json.loads(path.read_text(encoding="utf-8"))
        if self.is_encrypted_artifact_payload(payload):
            envelope = payload["envelope"]
            plaintext = decrypt_secret(
                envelope,
                recipient_private_key=self._local_inbox()["private_key"],
            ).decode("utf-8")
            return json.loads(plaintext)
        return payload

    def read_bytes(self, path: Path) -> bytes:
        path = path.expanduser()
        raw = path.read_bytes()
        payload = self._parse_encrypted_artifact_bytes(raw)
        if payload is None:
            return raw
        return decrypt_secret(
            payload["envelope"],
            recipient_private_key=self._local_inbox()["private_key"],
        )

    def read_metadata(self, path: Path) -> dict[str, Any]:
        metadata_path = self.metadata_path(path)
        payload = json.loads(metadata_path.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}

    def read_content_type(self, path: Path) -> str | None:
        metadata = self.read_metadata(path)
        content_type = metadata.get("content_type")
        return content_type if isinstance(content_type, str) and content_type.strip() else None

    def local_inbox_summary(self, *, include_public_key: bool = False) -> dict[str, Any]:
        inbox = self._local_inbox()
        payload: dict[str, Any] = {
            "algorithm": str(inbox.get("algorithm") or ""),
            "created_at": str(inbox.get("created_at") or ""),
            "recipient_id": str(inbox.get("recipient_id") or ""),
        }
        if include_public_key:
            payload["public_key"] = str(inbox.get("public_key") or "")
        return payload

    def rotate_local_inbox(
        self,
        *,
        reencrypt_existing: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        old_inbox = dict(self._local_inbox())
        new_inbox = generate_secret_inbox()
        rotated_at = datetime.now(UTC).isoformat()
        encrypted_items = self._encrypted_artifact_items()
        summary = {
            "dry_run": dry_run,
            "old_recipient_id": str(old_inbox.get("recipient_id") or ""),
            "new_recipient_id": str(new_inbox.get("recipient_id") or ""),
            "reencrypt_existing": reencrypt_existing,
            "encrypted_artifacts": len(encrypted_items),
            "rotated_artifacts": 0,
            "blocked": bool(encrypted_items) and not reencrypt_existing,
            "reason": "encrypted_artifacts_present"
            if encrypted_items and not reencrypt_existing
            else "",
            "backup_inbox_path": "",
            "items": [
                {
                    "path": str(item["path"]),
                    "artifact_kind": item["artifact_kind"],
                    "content_type": item["content_type"],
                    "sensitivity": item["sensitivity"],
                }
                for item in encrypted_items
            ],
        }
        if summary["blocked"]:
            if dry_run:
                return summary
            raise ValueError(
                "encrypted artifacts exist; rerun with reencrypt_existing=True"
            )
        if dry_run:
            return summary

        rotation_id = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%f")
        backup_inbox_path = self._security_dir / f"artifact-inbox.{rotation_id}.bak.json"
        summary["backup_inbox_path"] = str(backup_inbox_path)
        staged_items = [
            self._stage_rotated_artifact(
                item,
                old_inbox=old_inbox,
                new_inbox=new_inbox,
                rotated_at=rotated_at,
                rotation_id=rotation_id,
            )
            for item in encrypted_items
        ]
        committed_items: list[dict[str, Any]] = []
        inbox_replaced = False
        try:
            self._security_dir.mkdir(parents=True, exist_ok=True)
            backup_inbox_path.write_text(
                json.dumps(old_inbox, ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8",
            )
            for staged in staged_items:
                target_path = staged["path"]
                metadata_path = staged["metadata_path"]
                backup_path = staged["backup_path"]
                backup_metadata_path = staged["backup_metadata_path"]
                target_path.replace(backup_path)
                metadata_path.replace(backup_metadata_path)
                staged["staged_path"].replace(target_path)
                staged["staged_metadata_path"].replace(metadata_path)
                committed_items.append(staged)

            self._inbox_path.write_text(
                json.dumps(new_inbox, ensure_ascii=False, indent=2, sort_keys=True),
                encoding="utf-8",
            )
            self._cached_inbox = new_inbox
            inbox_replaced = True

            for staged in committed_items:
                staged["backup_path"].unlink(missing_ok=True)
                staged["backup_metadata_path"].unlink(missing_ok=True)
                staged["staged_path"].unlink(missing_ok=True)
                staged["staged_metadata_path"].unlink(missing_ok=True)

            stage_root = self._security_dir / "artifact-rotation-stage" / rotation_id
            if stage_root.exists():
                stage_root.rmdir()
                if stage_root.parent.exists() and not any(stage_root.parent.iterdir()):
                    stage_root.parent.rmdir()

            summary["rotated_artifacts"] = len(committed_items)
            return summary
        except Exception:
            if inbox_replaced:
                self._inbox_path.write_text(
                    json.dumps(old_inbox, ensure_ascii=False, indent=2, sort_keys=True),
                    encoding="utf-8",
                )
            self._cached_inbox = old_inbox
            for staged in reversed(committed_items):
                target_path = staged["path"]
                metadata_path = staged["metadata_path"]
                backup_path = staged["backup_path"]
                backup_metadata_path = staged["backup_metadata_path"]
                if target_path.exists():
                    target_path.unlink(missing_ok=True)
                if metadata_path.exists():
                    metadata_path.unlink(missing_ok=True)
                if backup_path.exists():
                    backup_path.replace(target_path)
                if backup_metadata_path.exists():
                    backup_metadata_path.replace(metadata_path)
            for staged in staged_items:
                staged["staged_path"].unlink(missing_ok=True)
                staged["staged_metadata_path"].unlink(missing_ok=True)
                staged["backup_path"].unlink(missing_ok=True)
                staged["backup_metadata_path"].unlink(missing_ok=True)
            backup_inbox_path.unlink(missing_ok=True)
            stage_root = self._security_dir / "artifact-rotation-stage" / rotation_id
            if stage_root.exists():
                for child in stage_root.glob("*"):
                    child.unlink(missing_ok=True)
                stage_root.rmdir()
                if stage_root.parent.exists() and not any(stage_root.parent.iterdir()):
                    stage_root.parent.rmdir()
            raise

    def export_handoff_bundle(
        self,
        path: Path,
        *,
        recipient_public_key: str,
    ) -> dict[str, Any]:
        path = path.expanduser().resolve()
        record = self.read_metadata(path)
        artifact_kind = str(record.get("artifact_kind") or "").strip()
        content_type = str(record.get("content_type") or "").strip()
        if not artifact_kind:
            raise ValueError("artifact metadata missing artifact_kind")
        if not content_type:
            raise ValueError("artifact metadata missing content_type")
        sensitivity = ArtifactSensitivity(
            str(record.get("sensitivity") or ArtifactSensitivity.internal)
        )
        payload = self.read_bytes(path)
        source_inbox = self.local_inbox_summary()
        metadata = dict(record.get("metadata") or {})
        metadata.update(
            {
                "source_path": str(path),
                "source_recipient_id": source_inbox["recipient_id"],
                "source_created_at": record.get("created_at"),
            }
        )
        envelope = encrypt_secret(
            payload,
            recipient_public_key=recipient_public_key,
            provider="pay-switch",
            secret_type="artifact_handoff",
            key_name=path.name,
            metadata={
                "artifact_kind": artifact_kind,
                "content_type": content_type,
                "path": str(path),
            },
        )
        return {
            "schema": ARTIFACT_HANDOFF_SCHEMA,
            "created_at": datetime.now(UTC).isoformat(),
            "source": source_inbox,
            "artifact": {
                "path": str(path),
                "artifact_kind": artifact_kind,
                "sensitivity": sensitivity.value,
                "content_type": content_type,
                "retention_hours": record.get("retention_hours"),
                "metadata": metadata,
            },
            "envelope": envelope,
        }

    def import_handoff_bundle(
        self,
        bundle: dict[str, Any],
        *,
        target_path: Path | None = None,
    ) -> Path:
        if bundle.get("schema") != ARTIFACT_HANDOFF_SCHEMA:
            raise ValueError("unsupported artifact handoff schema")
        artifact = bundle.get("artifact")
        envelope = bundle.get("envelope")
        if not isinstance(artifact, dict) or not isinstance(envelope, dict):
            raise ValueError("artifact handoff bundle is missing artifact or envelope")
        path_value = target_path or Path(str(artifact.get("path") or ""))
        if not str(path_value).strip():
            raise ValueError("artifact handoff bundle is missing target path")
        path = Path(path_value).expanduser().resolve()
        artifact_kind = str(artifact.get("artifact_kind") or "").strip()
        content_type = str(artifact.get("content_type") or "").strip()
        if not artifact_kind:
            raise ValueError("artifact handoff bundle is missing artifact_kind")
        if not content_type:
            raise ValueError("artifact handoff bundle is missing content_type")
        retention_value = artifact.get("retention_hours")
        retention_hours = (
            retention_value
            if isinstance(retention_value, int) and retention_value > 0
            else None
        )
        metadata = dict(artifact.get("metadata") or {})
        source = bundle.get("source")
        if isinstance(source, dict):
            metadata.setdefault("handoff_source_recipient_id", source.get("recipient_id"))
            metadata.setdefault("handoff_source_created_at", source.get("created_at"))
        metadata["handoff_imported_at"] = datetime.now(UTC).isoformat()
        payload = decrypt_secret(
            envelope,
            recipient_private_key=self._local_inbox()["private_key"],
        )
        return self.write_bytes(
            path,
            payload,
            artifact_kind=artifact_kind,
            sensitivity=ArtifactSensitivity(
                str(artifact.get("sensitivity") or ArtifactSensitivity.internal)
            ),
            content_type=content_type,
            retention_hours=retention_hours,
            metadata=metadata,
        )

    def list_expired(
        self,
        *,
        now: datetime | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        effective_now = now or datetime.now(UTC)
        expired: list[dict[str, Any]] = []
        for metadata_path in self._metadata_paths():
            record = self._read_metadata_record(metadata_path)
            if record is None:
                continue
            expires_at = self._parse_datetime(record.get("expires_at"))
            if expires_at is None or expires_at > effective_now:
                continue
            primary_path = Path(str(record.get("path") or "")).expanduser()
            expired.append(
                {
                    **record,
                    "metadata_path": str(metadata_path),
                    "primary_exists": primary_path.exists(),
                }
            )
        expired.sort(
            key=lambda entry: (
                str(entry.get("expires_at") or ""),
                str(entry.get("path") or ""),
            )
        )
        if limit is not None:
            return expired[:limit]
        return expired

    def cleanup_expired(
        self,
        *,
        now: datetime | None = None,
        limit: int | None = None,
        dry_run: bool = False,
    ) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for entry in self.list_expired(now=now, limit=limit):
            primary_path = Path(str(entry["path"])).expanduser()
            metadata_path = Path(str(entry["metadata_path"])).expanduser()
            primary_exists = primary_path.exists()
            metadata_exists = metadata_path.exists()
            if dry_run:
                action = "would_delete" if primary_exists else "would_delete_metadata_only"
            else:
                if primary_exists:
                    primary_path.unlink(missing_ok=True)
                if metadata_exists:
                    metadata_path.unlink(missing_ok=True)
                action = "deleted" if primary_exists else "deleted_metadata_only"
            results.append(
                {
                    "path": str(primary_path),
                    "metadata_path": str(metadata_path),
                    "artifact_kind": entry.get("artifact_kind"),
                    "sensitivity": entry.get("sensitivity"),
                    "expires_at": entry.get("expires_at"),
                    "encrypted": entry.get("encrypted"),
                    "action": action,
                    "dry_run": dry_run,
                }
            )
        return results

    def list_budget_reclaim_candidates(
        self,
        *,
        now: datetime | None = None,
        include_sensitive: bool = False,
    ) -> list[dict[str, Any]]:
        effective_now = now or datetime.now(UTC)
        candidates: list[dict[str, Any]] = []
        for metadata_path in self._metadata_paths():
            record = self._read_metadata_record(metadata_path)
            if record is None:
                continue
            sensitivity = str(record.get("sensitivity") or "unknown")
            if sensitivity == ArtifactSensitivity.sensitive.value and not include_sensitive:
                continue
            primary_path = Path(str(record.get("path") or "")).expanduser()
            primary_exists = primary_path.exists()
            primary_bytes = primary_path.stat().st_size if primary_exists else 0
            metadata_bytes = metadata_path.stat().st_size if metadata_path.exists() else 0
            total_bytes = primary_bytes + metadata_bytes
            if total_bytes <= 0:
                continue
            expires_at = self._parse_datetime(record.get("expires_at"))
            created_at = self._parse_datetime(record.get("created_at"))
            expired = expires_at is not None and expires_at <= effective_now
            candidates.append(
                {
                    **record,
                    "metadata_path": str(metadata_path),
                    "primary_exists": primary_exists,
                    "primary_bytes": primary_bytes,
                    "metadata_bytes": metadata_bytes,
                    "total_bytes": total_bytes,
                    "expired": expired,
                    "created_at_dt": created_at,
                    "expires_at_dt": expires_at,
                }
            )
        candidates.sort(
            key=lambda entry: (
                0 if bool(entry.get("expired")) else 1,
                self._budget_sensitivity_rank(str(entry.get("sensitivity") or "unknown")),
                entry.get("created_at_dt") or datetime.max.replace(tzinfo=UTC),
                str(entry.get("path") or ""),
            )
        )
        return candidates

    def enforce_budget(
        self,
        *,
        budget_bytes: int,
        target_bytes: int | None = None,
        now: datetime | None = None,
        limit: int | None = None,
        dry_run: bool = False,
        include_sensitive: bool = False,
    ) -> dict[str, Any]:
        if budget_bytes < 1:
            raise ValueError("budget_bytes must be >= 1")
        effective_target = budget_bytes if target_bytes is None else target_bytes
        if effective_target < 0:
            raise ValueError("target_bytes must be >= 0")
        if effective_target > budget_bytes:
            raise ValueError("target_bytes must be <= budget_bytes")

        effective_now = now or datetime.now(UTC)
        initial = self.inventory(now=effective_now, budget_bytes=budget_bytes)
        initial_total_bytes = int(initial["total_bytes"])
        projected_total_bytes = initial_total_bytes
        candidates = self.list_budget_reclaim_candidates(
            now=effective_now,
            include_sensitive=include_sensitive,
        )
        items: list[dict[str, Any]] = []

        if initial_total_bytes > budget_bytes:
            for entry in candidates[:limit]:
                if projected_total_bytes <= effective_target:
                    break
                primary_path = Path(str(entry["path"])).expanduser()
                metadata_path = Path(str(entry["metadata_path"])).expanduser()
                primary_exists = primary_path.exists()
                metadata_exists = metadata_path.exists()
                if dry_run:
                    action = (
                        "would_delete"
                        if primary_exists
                        else "would_delete_metadata_only"
                    )
                else:
                    if primary_exists:
                        primary_path.unlink(missing_ok=True)
                    if metadata_exists:
                        metadata_path.unlink(missing_ok=True)
                    action = "deleted" if primary_exists else "deleted_metadata_only"
                reclaimed_bytes = int(entry["total_bytes"])
                projected_total_bytes = max(0, projected_total_bytes - reclaimed_bytes)
                items.append(
                    {
                        "path": str(primary_path),
                        "metadata_path": str(metadata_path),
                        "artifact_kind": entry.get("artifact_kind"),
                        "sensitivity": entry.get("sensitivity"),
                        "expired": entry.get("expired"),
                        "encrypted": entry.get("encrypted"),
                        "created_at": entry.get("created_at"),
                        "expires_at": entry.get("expires_at"),
                        "reclaimed_bytes": reclaimed_bytes,
                        "action": action,
                        "dry_run": dry_run,
                    }
                )

        final = initial if dry_run else self.inventory(now=effective_now, budget_bytes=budget_bytes)
        total_reclaimed_bytes = sum(int(item["reclaimed_bytes"]) for item in items)
        final_total_bytes = (
            projected_total_bytes if dry_run else int(final["total_bytes"])
        )
        projected_usage_ratio = final_total_bytes / budget_bytes if budget_bytes > 0 else None
        return {
            "budget_bytes": budget_bytes,
            "target_bytes": effective_target,
            "dry_run": dry_run,
            "include_sensitive": include_sensitive,
            "triggered": initial_total_bytes > budget_bytes,
            "initial_total_bytes": initial_total_bytes,
            "projected_total_bytes": final_total_bytes,
            "projected_usage_ratio": projected_usage_ratio,
            "projected_over_budget": final_total_bytes > budget_bytes,
            "within_target": final_total_bytes <= effective_target,
            "cleaned": len(items),
            "deleted": sum(
                1 for item in items if item["action"] in {"deleted", "would_delete"}
            ),
            "metadata_only": sum(
                1
                for item in items
                if item["action"] in {"deleted_metadata_only", "would_delete_metadata_only"}
            ),
            "reclaimed_bytes": total_reclaimed_bytes,
            "items": items,
            "inventory_before": initial,
            "inventory_after": final,
        }

    def inventory(
        self,
        *,
        now: datetime | None = None,
        budget_bytes: int | None = None,
    ) -> dict[str, Any]:
        effective_now = now or datetime.now(UTC)
        by_sensitivity: dict[str, dict[str, int]] = {}
        by_kind: dict[str, dict[str, int]] = {}
        summary = {
            "artifacts": 0,
            "expired_artifacts": 0,
            "encrypted_artifacts": 0,
            "orphaned_metadata": 0,
            "primary_bytes": 0,
            "metadata_bytes": 0,
            "total_bytes": 0,
            "expired_bytes": 0,
            "by_sensitivity": by_sensitivity,
            "by_kind": by_kind,
        }
        for metadata_path in self._metadata_paths():
            record = self._read_metadata_record(metadata_path)
            if record is None:
                continue
            primary_path = Path(str(record.get("path") or "")).expanduser()
            primary_exists = primary_path.exists()
            primary_bytes = primary_path.stat().st_size if primary_exists else 0
            metadata_bytes = metadata_path.stat().st_size if metadata_path.exists() else 0
            total_bytes = primary_bytes + metadata_bytes
            expires_at = self._parse_datetime(record.get("expires_at"))
            expired = expires_at is not None and expires_at <= effective_now
            sensitivity = str(record.get("sensitivity") or "unknown")
            artifact_kind = str(record.get("artifact_kind") or "unknown")

            summary["artifacts"] += 1
            summary["primary_bytes"] += primary_bytes
            summary["metadata_bytes"] += metadata_bytes
            summary["total_bytes"] += total_bytes
            if expired:
                summary["expired_artifacts"] += 1
                summary["expired_bytes"] += total_bytes
            if bool(record.get("encrypted")):
                summary["encrypted_artifacts"] += 1
            if not primary_exists:
                summary["orphaned_metadata"] += 1

            sensitivity_bucket = by_sensitivity.setdefault(
                sensitivity,
                {"artifacts": 0, "bytes": 0, "expired_artifacts": 0},
            )
            sensitivity_bucket["artifacts"] += 1
            sensitivity_bucket["bytes"] += total_bytes
            if expired:
                sensitivity_bucket["expired_artifacts"] += 1

            kind_bucket = by_kind.setdefault(
                artifact_kind,
                {"artifacts": 0, "bytes": 0, "expired_artifacts": 0},
            )
            kind_bucket["artifacts"] += 1
            kind_bucket["bytes"] += total_bytes
            if expired:
                kind_bucket["expired_artifacts"] += 1

        budget_mb = None if budget_bytes is None else budget_bytes / (1024 * 1024)
        usage_ratio = None
        over_budget = False
        if budget_bytes is not None and budget_bytes > 0:
            usage_ratio = summary["total_bytes"] / budget_bytes
            over_budget = summary["total_bytes"] > budget_bytes

        return {
            **summary,
            "budget_bytes": budget_bytes,
            "budget_mb": budget_mb,
            "usage_ratio": usage_ratio,
            "over_budget": over_budget,
        }

    @staticmethod
    def metadata_path(path: Path) -> Path:
        return path.with_name(f"{path.name}.meta.json")

    @staticmethod
    def is_encrypted_artifact_payload(payload: Any) -> bool:
        return (
            isinstance(payload, dict)
            and payload.get("schema") == ARTIFACT_ENVELOPE_SCHEMA
            and isinstance(payload.get("envelope"), dict)
        )

    def _default_retention_hours(self, sensitivity: ArtifactSensitivity) -> int:
        if sensitivity == ArtifactSensitivity.public:
            return self._public_retention_hours
        if sensitivity == ArtifactSensitivity.internal:
            return self._internal_retention_hours
        return self._sensitive_retention_hours

    @staticmethod
    def _budget_sensitivity_rank(sensitivity: str) -> int:
        if sensitivity == ArtifactSensitivity.public.value:
            return 0
        if sensitivity == ArtifactSensitivity.internal.value:
            return 1
        if sensitivity == ArtifactSensitivity.sensitive.value:
            return 2
        return 3

    def _artifact_record(
        self,
        *,
        path: Path,
        artifact_kind: str,
        sensitivity: ArtifactSensitivity,
        content_type: str,
        retention_hours: int | None,
        metadata: dict[str, Any] | None,
        encrypted: bool,
    ) -> dict[str, Any]:
        created_at = datetime.now(UTC)
        effective_retention = retention_hours
        if effective_retention is None:
            effective_retention = self._default_retention_hours(sensitivity)
        expires_at = created_at + timedelta(hours=effective_retention)
        return {
            "schema": ARTIFACT_METADATA_SCHEMA,
            "path": str(path),
            "artifact_kind": artifact_kind,
            "sensitivity": sensitivity.value,
            "content_type": content_type,
            "encrypted": encrypted,
            "retention_hours": effective_retention,
            "created_at": created_at.isoformat(),
            "expires_at": expires_at.isoformat(),
            "metadata": dict(metadata or {}),
            "encryption_algorithm": SECRET_ENVELOPE_ALGORITHM if encrypted else None,
        }

    def _encrypted_artifact_items(self) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for metadata_path in self._metadata_paths():
            record = self._read_metadata_record(metadata_path)
            if record is None or not bool(record.get("encrypted")):
                continue
            path = Path(str(record.get("path") or "")).expanduser()
            if not path.exists():
                continue
            items.append(
                {
                    "path": path,
                    "metadata_path": metadata_path,
                    "artifact_kind": str(record.get("artifact_kind") or ""),
                    "content_type": str(record.get("content_type") or ""),
                    "sensitivity": str(record.get("sensitivity") or ""),
                    "record": dict(record),
                }
            )
        return items

    def _stage_rotated_artifact(
        self,
        item: dict[str, Any],
        *,
        old_inbox: dict[str, Any],
        new_inbox: dict[str, Any],
        rotated_at: str,
        rotation_id: str,
    ) -> dict[str, Any]:
        path = Path(item["path"])
        metadata_path = Path(item["metadata_path"])
        raw = path.read_bytes()
        payload = self._parse_encrypted_artifact_bytes(raw)
        if payload is None:
            raise ValueError(f"encrypted artifact payload missing for {path}")

        record = dict(item["record"])
        plaintext = decrypt_secret(
            payload["envelope"],
            recipient_private_key=str(old_inbox["private_key"]),
        )
        new_record = dict(record)
        new_record["recipient_id"] = str(new_inbox["recipient_id"])
        new_record["rotated_at"] = rotated_at
        new_record["rotation_source_recipient_id"] = str(old_inbox["recipient_id"])
        envelope = encrypt_secret(
            plaintext,
            recipient_public_key=str(new_inbox["public_key"]),
            provider="pay-switch",
            secret_type="artifact",
            key_name=path.name,
            metadata={
                "artifact_kind": str(record.get("artifact_kind") or ""),
                "content_type": str(record.get("content_type") or ""),
                "path": str(path),
            },
        )
        wrapped_payload = {
            "schema": ARTIFACT_ENVELOPE_SCHEMA,
            "artifact": new_record,
            "envelope": envelope,
        }

        stage_dir = self._security_dir / "artifact-rotation-stage" / rotation_id
        stage_dir.mkdir(parents=True, exist_ok=True)
        stage_path = stage_dir / f"{path.name}.payload"
        stage_metadata_path = stage_dir / f"{metadata_path.name}.metadata"
        stage_path.write_text(
            json.dumps(wrapped_payload, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        stage_metadata_path.write_text(
            json.dumps(new_record, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        backup_path = path.with_name(f"{path.name}.rotate-bak-{rotation_id}")
        backup_metadata_path = metadata_path.with_name(
            f"{metadata_path.name}.rotate-bak-{rotation_id}"
        )
        return {
            "path": path,
            "metadata_path": metadata_path,
            "staged_path": stage_path,
            "staged_metadata_path": stage_metadata_path,
            "backup_path": backup_path,
            "backup_metadata_path": backup_metadata_path,
        }

    def _local_inbox(self) -> dict[str, Any]:
        if self._cached_inbox is not None:
            return self._cached_inbox
        self._security_dir.mkdir(parents=True, exist_ok=True)
        if self._inbox_path.exists():
            self._cached_inbox = json.loads(self._inbox_path.read_text(encoding="utf-8"))
            return self._cached_inbox
        inbox = generate_secret_inbox()
        self._inbox_path.write_text(
            json.dumps(inbox, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        self._cached_inbox = inbox
        return inbox

    def _write_metadata(self, path: Path, record: dict[str, Any]) -> None:
        metadata_path = self.metadata_path(path)
        metadata_path.write_text(
            json.dumps(record, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    def _metadata_paths(self) -> list[Path]:
        paths = sorted(self._data_dir.rglob("*.meta.json"))
        stage_root = self._security_dir / "artifact-rotation-stage"
        if stage_root.exists():
            paths = [path for path in paths if not path.is_relative_to(stage_root)]
        return paths

    def _read_metadata_record(self, metadata_path: Path) -> dict[str, Any] | None:
        try:
            payload = json.loads(metadata_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        if not isinstance(payload, dict):
            return None
        if payload.get("schema") != ARTIFACT_METADATA_SCHEMA:
            return None
        return payload

    @staticmethod
    def _parse_datetime(value: Any) -> datetime | None:
        if not isinstance(value, str) or not value.strip():
            return None
        normalized = value.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError:
            return None
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=UTC)
        return parsed.astimezone(UTC)

    @classmethod
    def _parse_encrypted_artifact_bytes(cls, raw: bytes) -> dict[str, Any] | None:
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None
        return payload if cls.is_encrypted_artifact_payload(payload) else None
