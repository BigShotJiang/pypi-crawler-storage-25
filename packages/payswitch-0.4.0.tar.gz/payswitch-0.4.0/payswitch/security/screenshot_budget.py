"""Transaction-level screenshot budget accounting."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from payswitch.models.transaction import (
    ScreenshotBudgetState,
    Transaction,
    TransactionBudgetState,
)


def _utc_now() -> datetime:
    return datetime.now(UTC)


@dataclass(slots=True, frozen=True)
class ScreenshotBudgetDecision:
    """Result of one screenshot capture attempt."""

    allowed: bool
    state: ScreenshotBudgetState
    reason: str


class TransactionScreenshotBudget:
    """Mutable screenshot budget controller for one transaction."""

    def __init__(
        self,
        *,
        tx_id: str,
        limit: int,
        initial_state: ScreenshotBudgetState | None = None,
    ) -> None:
        effective_limit = max(1, int(initial_state.limit if initial_state is not None else limit))
        if initial_state is None:
            self._state = ScreenshotBudgetState(
                limit=effective_limit,
                used=0,
                remaining=effective_limit,
            )
        else:
            used = max(0, min(int(initial_state.used), effective_limit))
            remaining = max(0, effective_limit - used)
            exhausted = bool(initial_state.exhausted or remaining == 0)
            self._state = initial_state.model_copy(
                update={
                    "limit": effective_limit,
                    "used": used,
                    "remaining": remaining,
                    "exhausted": exhausted,
                }
            )
        self._tx_id = tx_id

    @classmethod
    def from_transaction(
        cls,
        tx: Transaction,
        *,
        limit: int,
    ) -> TransactionScreenshotBudget:
        initial = (
            tx.budget_state.screenshots
            if tx.budget_state is not None and tx.budget_state.screenshots is not None
            else None
        )
        return cls(tx_id=tx.tx_id, limit=limit, initial_state=initial)

    @property
    def tx_id(self) -> str:
        return self._tx_id

    def snapshot(self) -> ScreenshotBudgetState:
        return self._state.model_copy(deep=True)

    def register_capture(
        self,
        *,
        artifact_kind: str,
        capture_reason: str,
        artifact_path: Path | None = None,
    ) -> ScreenshotBudgetDecision:
        now = _utc_now()
        used = int(self._state.used)
        limit = int(self._state.limit)
        path_str = str(artifact_path) if artifact_path is not None else None
        if used >= limit:
            reason = (
                f"screenshot budget exhausted before {capture_reason}: "
                f"{used}/{limit} persisted for {self._tx_id}"
            )
            self._state = self._state.model_copy(
                update={
                    "remaining": 0,
                    "exhausted": True,
                    "exhausted_at": self._state.exhausted_at or now,
                    "exhaustion_reason": reason,
                    "last_capture_reason": capture_reason,
                    "last_artifact_kind": artifact_kind,
                    "last_artifact_path": path_str,
                }
            )
            return ScreenshotBudgetDecision(
                allowed=False,
                state=self.snapshot(),
                reason=reason,
            )

        used += 1
        remaining = max(0, limit - used)
        exhausted = remaining == 0
        exhaustion_reason = self._state.exhaustion_reason
        if exhausted:
            exhaustion_reason = (
                f"screenshot budget exhausted after {capture_reason}: "
                f"{used}/{limit} persisted for {self._tx_id}"
            )
        self._state = self._state.model_copy(
            update={
                "used": used,
                "remaining": remaining,
                "exhausted": exhausted,
                "exhausted_at": now if exhausted else self._state.exhausted_at,
                "exhaustion_reason": exhaustion_reason,
                "last_capture_reason": capture_reason,
                "last_artifact_kind": artifact_kind,
                "last_artifact_path": path_str,
            }
        )
        return ScreenshotBudgetDecision(
            allowed=True,
            state=self.snapshot(),
            reason=exhaustion_reason or capture_reason,
        )

    def apply(self, tx: Transaction) -> Transaction:
        budget_state = (
            tx.budget_state.model_copy(deep=True)
            if tx.budget_state is not None
            else TransactionBudgetState()
        )
        budget_state = budget_state.model_copy(update={"screenshots": self.snapshot()})
        return tx.model_copy(update={"budget_state": budget_state})
