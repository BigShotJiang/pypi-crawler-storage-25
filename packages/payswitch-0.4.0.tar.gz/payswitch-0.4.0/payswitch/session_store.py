"""Durable task/session store for the Pay-Switch control plane."""

from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import sys
from collections import defaultdict
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from payswitch.agent_language import PaymentIntent, to_psl
from payswitch.agent_workspace import resolve_task_identity
from payswitch.subagent_harness import redact_sensitive_payload

_CREATE_TASKS_SQL = """
CREATE TABLE IF NOT EXISTS sessions (
    id                  TEXT PRIMARY KEY,
    context_id          TEXT NOT NULL,
    user_id             TEXT NOT NULL,
    workspace_id        TEXT NOT NULL,
    subagent_session_id TEXT NOT NULL,
    site_id             TEXT NOT NULL,
    site_lock_id        TEXT NOT NULL,
    profile_id          TEXT NOT NULL,
    browser_context_id  TEXT NOT NULL,
    status              TEXT NOT NULL,
    created_at          TEXT NOT NULL,
    updated_at          TEXT NOT NULL,
    intent_json         TEXT NOT NULL,
    psl                 TEXT NOT NULL,
    plan_json           TEXT,
    event_sequence      INTEGER NOT NULL DEFAULT 0,
    result_json         TEXT,
    tx_id               TEXT,
    error               TEXT
);
"""

_CREATE_EVENTS_SQL = """
CREATE TABLE IF NOT EXISTS session_events (
    task_id      TEXT NOT NULL,
    sequence     INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    PRIMARY KEY (task_id, sequence),
    FOREIGN KEY (task_id) REFERENCES sessions(id) ON DELETE CASCADE
);
"""

_CREATE_INDEXES_SQL = [
    "CREATE INDEX IF NOT EXISTS idx_sessions_updated_at ON sessions(updated_at DESC);",
    "CREATE INDEX IF NOT EXISTS idx_sessions_user_updated ON sessions(user_id, updated_at DESC);",
    "CREATE INDEX IF NOT EXISTS idx_sessions_tx_id ON sessions(tx_id);",
]


def _default_session_store_path() -> str | Path:
    override = os.getenv("PAYSWITCH_SESSION_STORE_PATH", "").strip()
    if override:
        return override
    if "pytest" in sys.modules:
        return ":memory:"
    return Path.home() / ".payswitch" / "session_store.db"


class AgentTask(BaseModel):
    """Durable A2A task/session state."""

    id: str
    context_id: str
    user_id: str
    workspace_id: str
    subagent_session_id: str
    site_id: str
    site_lock_id: str
    profile_id: str
    browser_context_id: str
    status: str = "submitted"
    created_at: str
    updated_at: str
    intent: dict[str, Any]
    psl: str
    plan: dict[str, Any] | None = None
    events: list[dict[str, Any]] = Field(default_factory=list)
    event_sequence: int = 0
    result: dict[str, Any] | None = None
    error: str | None = None


class TaskStore:
    """SQLite-backed session store with replayable in-process subscriptions."""

    def __init__(
        self,
        db_path: str | Path | None = None,
        *,
        task_event_factory: Callable[[AgentTask], dict[str, Any]] | None = None,
    ) -> None:
        self.lock = asyncio.Lock()
        self.subscribers: dict[str, set[asyncio.Queue[dict[str, Any]]]] = defaultdict(set)
        self._last_now: datetime | None = None
        self._task_event_factory = task_event_factory or self.default_task_event
        resolved = db_path if db_path is not None else _default_session_store_path()
        self._db_path = str(resolved)
        if self._db_path != ":memory:":
            Path(self._db_path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys=ON;")
        self._conn.execute("PRAGMA journal_mode=WAL;")
        self._conn.execute("PRAGMA synchronous=NORMAL;")
        self._init_schema()

    @property
    def db_path(self) -> str:
        return self._db_path

    def close(self) -> None:
        self._conn.close()

    def _init_schema(self) -> None:
        with self._conn:
            self._conn.execute(_CREATE_TASKS_SQL)
            self._conn.execute(_CREATE_EVENTS_SQL)
            for statement in _CREATE_INDEXES_SQL:
                self._conn.execute(statement)

    def _now(self) -> str:
        current = datetime.now(UTC)
        if self._last_now is not None and current <= self._last_now:
            current = self._last_now + timedelta(microseconds=1)
        self._last_now = current
        return current.isoformat().replace("+00:00", "Z")

    @staticmethod
    def _dumps(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False)

    @staticmethod
    def _loads(value: str | None) -> Any:
        if not value:
            return None
        return json.loads(value)

    def _task_from_row(self, row: sqlite3.Row) -> AgentTask:
        event_rows = self._conn.execute(
            "SELECT payload_json FROM session_events WHERE task_id = ? ORDER BY sequence ASC",
            (row["id"],),
        ).fetchall()
        return AgentTask(
            id=row["id"],
            context_id=row["context_id"],
            user_id=row["user_id"],
            workspace_id=row["workspace_id"],
            subagent_session_id=row["subagent_session_id"],
            site_id=row["site_id"],
            site_lock_id=row["site_lock_id"],
            profile_id=row["profile_id"],
            browser_context_id=row["browser_context_id"],
            status=row["status"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            intent=self._loads(row["intent_json"]) or {},
            psl=row["psl"],
            plan=self._loads(row["plan_json"]),
            events=[self._loads(event_row["payload_json"]) for event_row in event_rows],
            event_sequence=int(row["event_sequence"] or 0),
            result=self._loads(row["result_json"]),
            error=row["error"],
        )

    def _upsert_task(self, task: AgentTask) -> None:
        result = task.result if isinstance(task.result, dict) else {}
        tx_id = str(result.get("tx_id") or "").strip() or None
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO sessions (
                    id, context_id, user_id, workspace_id, subagent_session_id,
                    site_id, site_lock_id, profile_id, browser_context_id,
                    status, created_at, updated_at, intent_json, psl,
                    plan_json, event_sequence, result_json, tx_id, error
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    context_id=excluded.context_id,
                    user_id=excluded.user_id,
                    workspace_id=excluded.workspace_id,
                    subagent_session_id=excluded.subagent_session_id,
                    site_id=excluded.site_id,
                    site_lock_id=excluded.site_lock_id,
                    profile_id=excluded.profile_id,
                    browser_context_id=excluded.browser_context_id,
                    status=excluded.status,
                    created_at=excluded.created_at,
                    updated_at=excluded.updated_at,
                    intent_json=excluded.intent_json,
                    psl=excluded.psl,
                    plan_json=excluded.plan_json,
                    event_sequence=excluded.event_sequence,
                    result_json=excluded.result_json,
                    tx_id=excluded.tx_id,
                    error=excluded.error
                """,
                (
                    task.id,
                    task.context_id,
                    task.user_id,
                    task.workspace_id,
                    task.subagent_session_id,
                    task.site_id,
                    task.site_lock_id,
                    task.profile_id,
                    task.browser_context_id,
                    task.status,
                    task.created_at,
                    task.updated_at,
                    self._dumps(task.intent),
                    task.psl,
                    self._dumps(task.plan) if task.plan is not None else None,
                    task.event_sequence,
                    self._dumps(task.result) if task.result is not None else None,
                    tx_id,
                    task.error,
                ),
            )

    def _get_row(self, task_id: str, *, user_id: str | None = None) -> sqlite3.Row | None:
        if user_id:
            return self._conn.execute(
                "SELECT * FROM sessions WHERE id = ? AND user_id = ?",
                (task_id, user_id),
            ).fetchone()
        return self._conn.execute("SELECT * FROM sessions WHERE id = ?", (task_id,)).fetchone()

    async def create(self, intent: PaymentIntent) -> AgentTask:
        now = self._now()
        task_id = f"psw_{os.urandom(8).hex()}"
        identity = resolve_task_identity(intent, task_id=task_id)
        task = AgentTask(
            id=task_id,
            context_id=f"ctx_{os.urandom(6).hex()}",
            user_id=identity.user_id,
            workspace_id=identity.workspace_id,
            subagent_session_id=identity.subagent_session_id,
            site_id=identity.site_id,
            site_lock_id=identity.site_lock_id,
            profile_id=identity.profile_id,
            browser_context_id=identity.browser_context_id,
            created_at=now,
            updated_at=now,
            intent=intent.model_dump(mode="json"),
            psl=to_psl(intent),
        )
        async with self.lock:
            self._upsert_task(task)
        return task

    async def get(self, task_id: str | None, *, user_id: str | None = None) -> AgentTask | None:
        if task_id is None:
            return None
        async with self.lock:
            row = self._get_row(task_id, user_id=user_id)
            return self._task_from_row(row) if row else None

    async def latest(self, *, user_id: str | None = None) -> AgentTask | None:
        async with self.lock:
            if user_id:
                row = self._conn.execute(
                    "SELECT * FROM sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1",
                    (user_id,),
                ).fetchone()
            else:
                row = self._conn.execute(
                    "SELECT * FROM sessions ORDER BY updated_at DESC LIMIT 1"
                ).fetchone()
            return self._task_from_row(row) if row else None

    async def list(self, *, user_id: str | None = None) -> list[AgentTask]:
        async with self.lock:
            if user_id:
                rows = self._conn.execute(
                    "SELECT * FROM sessions WHERE user_id = ? ORDER BY updated_at DESC",
                    (user_id,),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM sessions ORDER BY updated_at DESC"
                ).fetchall()
            return [self._task_from_row(row) for row in rows]

    async def list_workspaces(self, *, user_id: str | None = None) -> list[dict[str, Any]]:
        sessions = await self.list(user_id=user_id)
        workspaces: dict[str, dict[str, Any]] = {}
        active_statuses = {"submitted", "queued", "running", "working", "input-required"}
        for session in sessions:
            current = workspaces.get(session.workspace_id)
            if current is None:
                current = {
                    "workspace_id": session.workspace_id,
                    "user_id": session.user_id,
                    "status": "active",
                    "created_at": session.created_at,
                    "updated_at": session.updated_at,
                    "active_sessions": 0,
                }
                workspaces[session.workspace_id] = current
            current["created_at"] = min(str(current["created_at"]), session.created_at)
            current["updated_at"] = max(str(current["updated_at"]), session.updated_at)
            if session.status in active_statuses:
                current["active_sessions"] += 1
        return sorted(
            workspaces.values(),
            key=lambda workspace: str(workspace["updated_at"]),
            reverse=True,
        )

    async def list_subagents(self, *, user_id: str | None = None) -> list[dict[str, Any]]:
        sessions = await self.list(user_id=user_id)
        return [
            {
                "task_id": session.id,
                "session_id": session.subagent_session_id,
                "user_id": session.user_id,
                "site_id": session.site_id,
                "workspace_id": session.workspace_id,
                "profile_id": session.profile_id,
                "browser_context_id": session.browser_context_id,
                "site_lock_id": session.site_lock_id,
                "status": session.status,
                "queued_reason": None,
                "foreground_lease_id": None,
                "created_at": session.created_at,
                "updated_at": session.updated_at,
            }
            for session in sessions
        ]

    async def find_by_tx_id(
        self,
        tx_id: str | None,
        *,
        user_id: str | None = None,
    ) -> AgentTask | None:
        if not tx_id:
            return None
        async with self.lock:
            if user_id:
                row = self._conn.execute(
                    (
                        "SELECT * FROM sessions WHERE tx_id = ? AND user_id = ? "
                        "ORDER BY updated_at DESC LIMIT 1"
                    ),
                    (tx_id, user_id),
                ).fetchone()
            else:
                row = self._conn.execute(
                    "SELECT * FROM sessions WHERE tx_id = ? ORDER BY updated_at DESC LIMIT 1",
                    (tx_id,),
                ).fetchone()
            return self._task_from_row(row) if row else None

    async def update(
        self,
        task_id: str,
        *,
        status: str | None = None,
        plan: dict[str, Any] | None = None,
        result: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> AgentTask:
        async with self.lock:
            row = self._get_row(task_id)
            if row is None:
                raise KeyError(f"session not found: {task_id}")
            task = self._task_from_row(row)
            if status is not None:
                task.status = status
            if plan is not None:
                task.plan = plan
            if result is not None:
                task.result = result
            if error is not None:
                task.error = error
            task.updated_at = self._now()
            self._upsert_task(task)
        if self._task_event_factory is not None:
            await self.emit(task_id, self._task_event_factory(task))
        return await self.get(task_id) or task

    async def emit(self, task_id: str, event: dict[str, Any]) -> None:
        async with self.lock:
            row = self._get_row(task_id)
            if row is None:
                raise KeyError(f"session not found: {task_id}")
            task = self._task_from_row(row)
            task.event_sequence += 1
            event_payload = redact_sensitive_payload(event)
            event_payload["sequence"] = task.event_sequence
            task.events.append(event_payload)
            task.updated_at = self._now()
            self._upsert_task(task)
            with self._conn:
                self._conn.execute(
                    """
                    INSERT OR REPLACE INTO session_events (task_id, sequence, payload_json)
                    VALUES (?, ?, ?)
                    """,
                    (task.id, task.event_sequence, self._dumps(event_payload)),
                )
        await self.publish(task_id, event_payload)

    async def publish(self, task_id: str, payload: dict[str, Any]) -> None:
        queues = list(self.subscribers.get(task_id, set()))
        for queue in queues:
            await queue.put(payload)

    async def subscribe(
        self,
        task_id: str,
        *,
        after_sequence: int | None = None,
        replay: bool = True,
    ) -> asyncio.Queue[dict[str, Any]]:
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        async with self.lock:
            self.subscribers[task_id].add(queue)
            row = self._get_row(task_id)
            task = self._task_from_row(row) if row and replay else None
            replay_events = list(task.events) if task else []
        if after_sequence is not None:
            replay_events = [
                event
                for event in replay_events
                if int(event.get("sequence") or 0) > after_sequence
            ]
        for event in replay_events:
            await queue.put(event)
        return queue

    async def unsubscribe(self, task_id: str, queue: asyncio.Queue[dict[str, Any]]) -> None:
        async with self.lock:
            self.subscribers.get(task_id, set()).discard(queue)

    async def delete(self, task_id: str, *, user_id: str | None = None) -> bool:
        async with self.lock:
            row = self._get_row(task_id, user_id=user_id)
            if row is None:
                return False
            with self._conn:
                self._conn.execute("DELETE FROM session_events WHERE task_id = ?", (task_id,))
                self._conn.execute("DELETE FROM sessions WHERE id = ?", (task_id,))
            self.subscribers.pop(task_id, None)
        return True

    async def clear(self, *, user_id: str | None = None) -> list[str]:
        async with self.lock:
            if user_id:
                rows = self._conn.execute(
                    "SELECT id FROM sessions WHERE user_id = ?",
                    (user_id,),
                ).fetchall()
            else:
                rows = self._conn.execute("SELECT id FROM sessions").fetchall()
            ids = [str(row["id"]) for row in rows]
            if not ids:
                return []
            with self._conn:
                if user_id:
                    self._conn.execute(
                        (
                            "DELETE FROM session_events WHERE task_id IN "
                            "(SELECT id FROM sessions WHERE user_id = ?)"
                        ),
                        (user_id,),
                    )
                    self._conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
                else:
                    self._conn.execute("DELETE FROM session_events")
                    self._conn.execute("DELETE FROM sessions")
            for task_id in ids:
                self.subscribers.pop(task_id, None)
        return ids

    @staticmethod
    def default_task_event(task: AgentTask) -> dict[str, Any]:
        return {
            "type": "observe",
            "summary": f"Session {task.id} status -> {task.status}",
            "message": f"Pay-Switch session status changed to {task.status}.",
            "status": task.status,
            "user_id": task.user_id,
            "workspace_id": task.workspace_id,
            "subagent_session_id": task.subagent_session_id,
            "site_id": task.site_id,
            "site_lock_id": task.site_lock_id,
            "profile_id": task.profile_id,
            "browser_context_id": task.browser_context_id,
            "ts": task.updated_at,
        }
