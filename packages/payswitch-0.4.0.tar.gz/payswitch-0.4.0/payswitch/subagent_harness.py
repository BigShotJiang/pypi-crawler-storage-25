"""Subagent orchestration harness helpers.

The runtime owns scheduling, but these helpers keep the shared safety and
review rules in one small module: event redaction, plaintext-secret detection,
and adversarial invariant checks for session snapshots.
"""

from __future__ import annotations

import re
from typing import Any

SENSITIVE_EVENT_KEYS = {
    "api_key",
    "apikey",
    "access_key",
    "access_token",
    "auth_token",
    "client_secret",
    "cookie",
    "cvv",
    "cvc",
    "password",
    "payment_password",
    "plaintext_secret",
    "refresh_token",
    "secret",
    "secret_value",
    "session_cookie",
    "session_token",
    "token",
}

SECRET_VALUE_RE = re.compile(
    r"(?i)\b(?:sk|rk|pk|ak|rt|at|sess|key|token)[-_][a-z0-9][a-z0-9._-]{5,}\b"
)


def _normalized_key(key: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(key).lower())


def _is_sensitive_key(key: object) -> bool:
    normalized = _normalized_key(key)
    return normalized in {_normalized_key(item) for item in SENSITIVE_EVENT_KEYS}


def _contains_secret_like_value(value: Any) -> bool:
    if isinstance(value, str):
        return bool(SECRET_VALUE_RE.search(value))
    if isinstance(value, dict):
        return any(
            _is_sensitive_key(key) or _contains_secret_like_value(item)
            for key, item in value.items()
        )
    if isinstance(value, list):
        return any(_contains_secret_like_value(item) for item in value)
    return False


def redact_sensitive_payload(value: Any) -> Any:
    """Return a copy of value with secret-looking fields redacted."""
    if isinstance(value, dict):
        redacted: dict[str, Any] = {}
        for key, item in value.items():
            if _is_sensitive_key(key):
                redacted[str(key)] = "[REDACTED]"
            else:
                redacted[str(key)] = redact_sensitive_payload(item)
        return redacted
    if isinstance(value, list):
        return [redact_sensitive_payload(item) for item in value]
    if isinstance(value, str) and SECRET_VALUE_RE.search(value):
        return SECRET_VALUE_RE.sub("[REDACTED]", value)
    return value


def review_harness_snapshot(*, sessions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    workspace_users: dict[str, set[str]] = {}
    workspace_foreground: dict[str, list[str]] = {}
    required = {"task_id", "session_id", "user_id", "workspace_id"}

    for session in sessions:
        missing = sorted(field for field in required if not session.get(field))
        if missing:
            findings.append(
                {
                    "severity": "high",
                    "code": "missing_session_identity",
                    "message": "session is missing required identity fields",
                    "task_id": session.get("task_id"),
                    "missing": missing,
                }
            )
            continue

        workspace_id = str(session["workspace_id"])
        user_id = str(session["user_id"])
        workspace_users.setdefault(workspace_id, set()).add(user_id)
        if session.get("foreground_lease_id"):
            workspace_foreground.setdefault(workspace_id, []).append(str(session["task_id"]))

    for workspace_id, users in workspace_users.items():
        if len(users) > 1:
            findings.append(
                {
                    "severity": "critical",
                    "code": "workspace_user_conflict",
                    "message": "one workspace contains sessions from multiple users",
                    "workspace_id": workspace_id,
                    "users": sorted(users),
                }
            )

    for workspace_id, task_ids in workspace_foreground.items():
        if len(task_ids) > 1:
            findings.append(
                {
                    "severity": "critical",
                    "code": "multiple_foreground_leases",
                    "message": "workspace has more than one foreground human-gate lease",
                    "workspace_id": workspace_id,
                    "task_ids": task_ids,
                }
            )

    return findings


def review_harness_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for index, event in enumerate(events):
        if _contains_secret_like_value(event):
            findings.append(
                {
                    "severity": "critical",
                    "code": "plaintext_secret_event",
                    "message": "event payload contains plaintext secret-like data",
                    "event_index": index,
                }
            )
    return findings
