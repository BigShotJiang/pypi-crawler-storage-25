"""Workspace runtime abstractions for user-scoped Pay-Switch execution."""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal, Protocol, runtime_checkable

from payswitch.browser.manager import RuntimeBrowserManager
from payswitch.workspace_container_driver import (
    InMemoryWorkspaceContainerDriver,
    WorkspaceContainerDriver,
    WorkspaceContainerRecord,
    WorkspaceContainerSpec,
    build_workspace_container_driver,
)


def _now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def _stable_id(prefix: str, raw: str) -> str:
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"{prefix}_{digest[:16]}"


RuntimeBackend = Literal["in_process", "container"]


@dataclass(frozen=True)
class RuntimePolicy:
    runtime_idle_seconds: float = 300.0
    runtime_memory_mb: int = 256

    def __post_init__(self) -> None:
        if self.runtime_idle_seconds <= 0:
            raise ValueError("runtime_idle_seconds must be positive")
        if self.runtime_memory_mb <= 0:
            raise ValueError("runtime_memory_mb must be positive")


@runtime_checkable
class WorkspaceRuntime(Protocol):
    runtime_id: str
    workspace_id: str
    user_id: str
    status: str
    display_state: str
    display_ready: bool
    active_sessions: set[str]
    runtime_backend: RuntimeBackend

    def attach_session(self, task_id: str, browser_context_id: str) -> None: ...

    def detach_session(self, task_id: str) -> None: ...

    def wake(self) -> None: ...

    def mark_warm(self) -> None: ...

    def mark_sleeping(self) -> None: ...

    def mark_destroyed(self, *, reason: str) -> None: ...

    def assign_display_surface(
        self,
        task_id: str,
        *,
        state: str,
        ready: bool,
        reason: str,
        foreground_lease_id: str | None = None,
    ) -> str | None: ...

    def clear_display_surface(self, *, reason: str, state: str) -> None: ...

    def begin_visible_action(
        self,
        task_id: str,
        *,
        browser_context_id: str,
        action: str,
        foreground_lease_id: str | None = None,
    ) -> dict[str, Any]: ...

    def verify_visible_action(
        self,
        task_id: str,
        *,
        browser_context_id: str,
        action: str,
        foreground_lease_id: str | None = None,
    ) -> dict[str, Any]: ...

    def end_visible_action(self, *, lock_id: str | None) -> None: ...

    def current_memory_mb(self) -> int: ...

    def snapshot(self) -> dict[str, Any]: ...


@dataclass
class BaseWorkspaceRuntime:
    """Common lifecycle/state model shared by runtime backends."""

    workspace_id: str
    user_id: str
    policy: RuntimePolicy
    runtime_backend: RuntimeBackend
    runtime_id_prefix: str = "urt"
    display_surface_prefix: str = "runtime"
    runtime_id: str = field(init=False)
    status: str = field(init=False, default="starting")
    display_state: str = field(init=False, default="pending_scoped_display_route")
    display_ready: bool = field(init=False, default=False)
    created_at: str = field(init=False)
    updated_at: str = field(init=False)
    last_active_at: str | None = field(init=False, default=None)
    last_sleep_at: str | None = field(init=False, default=None)
    last_destroyed_at: str | None = field(init=False, default=None)
    last_status_reason: str = field(init=False, default="runtime_created")
    active_sessions: set[str] = field(default_factory=set)
    display_owner_task_id: str | None = field(init=False, default=None)
    display_route_token: str | None = field(init=False, default=None)
    display_selected_at: str | None = field(init=False, default=None)
    display_foreground_lease_id: str | None = field(init=False, default=None)
    display_reason: str = field(init=False, default="runtime_created")
    browser_manager: RuntimeBrowserManager = field(init=False, repr=False)

    def __post_init__(self) -> None:
        now = _now()
        self.runtime_id = _stable_id(self.runtime_id_prefix, self.workspace_id)
        self.created_at = now
        self.updated_at = now
        self.browser_manager = RuntimeBrowserManager(workspace_id=self.workspace_id)

    def attach_session(self, task_id: str, browser_context_id: str) -> None:
        self.browser_manager.register_session(task_id, browser_context_id)
        self.active_sessions.add(task_id)
        self.status = "active"
        if self.display_owner_task_id is None:
            self.display_state = "pending_scoped_display_route"
            self.display_ready = False
            self.display_reason = "operator_select_required"
        self.last_active_at = _now()
        self.updated_at = self.last_active_at
        self.last_status_reason = "task_running"

    def detach_session(self, task_id: str) -> None:
        self.browser_manager.unregister_session(task_id)
        self.active_sessions.discard(task_id)
        if self.display_owner_task_id == task_id:
            self.clear_display_surface(
                reason="selected_session_detached",
                state=(
                    "pending_scoped_display_route"
                    if self.active_sessions
                    else "idle_no_scoped_display"
                ),
            )
        self.updated_at = _now()

    def wake(self) -> None:
        self.status = "starting"
        self.display_state = "pending_scoped_display_route"
        self.display_ready = False
        self.display_reason = "runtime_wake"
        self.updated_at = _now()
        self.last_status_reason = "runtime_wake"

    def mark_warm(self) -> None:
        self.status = "warm"
        self.display_state = "idle_no_scoped_display"
        self.display_ready = False
        self.display_reason = "idle_no_selected_session"
        self.updated_at = _now()
        self.last_status_reason = "idle_waiting_for_sleep"

    def mark_sleeping(self) -> None:
        self.status = "sleeping"
        self.display_state = "runtime_sleeping"
        self.display_ready = False
        self.display_reason = "runtime_sleeping"
        self.last_sleep_at = _now()
        self.updated_at = self.last_sleep_at
        self.last_status_reason = "idle_sleep"

    def mark_destroyed(self, *, reason: str) -> None:
        self.status = "destroyed"
        self.display_state = "no_runtime"
        self.display_ready = False
        self.display_reason = reason
        self.display_owner_task_id = None
        self.display_route_token = None
        self.display_selected_at = None
        self.display_foreground_lease_id = None
        self.last_destroyed_at = _now()
        self.updated_at = self.last_destroyed_at
        self.last_status_reason = reason

    def assign_display_surface(
        self,
        task_id: str,
        *,
        state: str,
        ready: bool,
        reason: str,
        foreground_lease_id: str | None = None,
        browser_context_id: str | None = None,
    ) -> str | None:
        selected_at = _now()
        self.display_owner_task_id = task_id
        self.display_selected_at = selected_at
        self.display_foreground_lease_id = foreground_lease_id
        self.display_state = state
        self.display_ready = ready
        self.display_reason = reason
        self.updated_at = selected_at
        if browser_context_id is not None:
            self.browser_manager.select_session(
                task_id,
                browser_context_id=browser_context_id,
                foreground_lease_id=foreground_lease_id,
                reason=reason,
            )
        else:
            self.browser_manager.clear_selection(reason=reason)
        if ready:
            self.display_route_token = _stable_id(
                "dsp",
                f"{self.runtime_id}:{task_id}:{foreground_lease_id or 'none'}:{selected_at}",
            )
        else:
            self.display_route_token = None
        return self.display_route_token

    def clear_display_surface(self, *, reason: str, state: str) -> None:
        self.display_owner_task_id = None
        self.display_route_token = None
        self.display_selected_at = None
        self.display_foreground_lease_id = None
        self.display_state = state
        self.display_ready = False
        self.display_reason = reason
        self.updated_at = _now()
        self.browser_manager.clear_selection(reason=reason)

    def begin_visible_action(
        self,
        task_id: str,
        *,
        browser_context_id: str,
        action: str,
        foreground_lease_id: str | None = None,
    ) -> dict[str, Any]:
        return self.browser_manager.begin_visible_action(
            task_id,
            browser_context_id=browser_context_id,
            action=action,
            foreground_lease_id=foreground_lease_id,
        )

    def verify_visible_action(
        self,
        task_id: str,
        *,
        browser_context_id: str,
        action: str,
        foreground_lease_id: str | None = None,
    ) -> dict[str, Any]:
        return self.browser_manager.verify_visible_action(
            task_id,
            browser_context_id=browser_context_id,
            action=action,
            foreground_lease_id=foreground_lease_id,
        )

    def end_visible_action(self, *, lock_id: str | None) -> None:
        self.browser_manager.end_visible_action(lock_id=lock_id)

    def current_memory_mb(self) -> int:
        if self.status in {"destroyed", "sleeping"}:
            return 0
        return self.policy.runtime_memory_mb

    def snapshot(self) -> dict[str, Any]:
        return {
            "runtime_id": self.runtime_id,
            "runtime_backend": self.runtime_backend,
            "workspace_id": self.workspace_id,
            "user_id": self.user_id,
            "runtime_status": self.status,
            "display_state": self.display_state,
            "display_ready": self.display_ready,
            "display_reason": self.display_reason,
            "display_surface_id": f"{self.display_surface_prefix}:{self.runtime_id}",
            "display_owner_task_id": self.display_owner_task_id,
            "display_route_token": self.display_route_token,
            "display_selected_at": self.display_selected_at,
            "display_foreground_lease_id": self.display_foreground_lease_id,
            "active_sessions": len(self.active_sessions),
            "runtime_memory_mb": self.current_memory_mb(),
            "runtime_memory_budget_mb": self.policy.runtime_memory_mb,
            "sleep_after_seconds": self.policy.runtime_idle_seconds,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "last_active_at": self.last_active_at,
            "last_sleep_at": self.last_sleep_at,
            "last_destroyed_at": self.last_destroyed_at,
            "runtime_status_reason": self.last_status_reason,
            "novnc_route_key": getattr(
                self,
                "novnc_route_key",
                _stable_id("vroute", self.workspace_id),
            ),
            **self.browser_manager.snapshot(),
        }


@dataclass
class InProcessWorkspaceRuntime(BaseWorkspaceRuntime):
    """Single-process runtime placeholder for one user workspace."""

    runtime_backend: RuntimeBackend = field(init=False, default="in_process")
    runtime_id_prefix: str = field(init=False, default="urt")
    display_surface_prefix: str = field(init=False, default="runtime")


@dataclass
class ContainerWorkspaceRuntime(BaseWorkspaceRuntime):
    """Container-backed runtime skeleton for one user workspace.

    This is the backend boundary only. Container launch, proxy registration,
    and profile-volume mounting are implemented in later milestones.
    """

    container_image: str = "ghcr.io/arxchibobo/payswitch-workspace:latest"
    container_driver: WorkspaceContainerDriver = field(
        default_factory=InMemoryWorkspaceContainerDriver,
        repr=False,
    )
    runtime_backend: RuntimeBackend = field(init=False, default="container")
    runtime_id_prefix: str = field(init=False, default="ucrt")
    display_surface_prefix: str = field(init=False, default="container-runtime")
    container_id: str | None = field(init=False, default=None)
    container_name: str | None = field(init=False, default=None)
    container_status: str = field(init=False, default="pending")
    profile_volume_name: str = field(init=False)
    novnc_route_key: str = field(init=False)
    last_container_error: str | None = field(init=False, default=None)
    container_started_at: str | None = field(init=False, default=None)
    container_stopped_at: str | None = field(init=False, default=None)

    def __post_init__(self) -> None:
        super().__post_init__()
        self.profile_volume_name = _stable_id("uvol", self.workspace_id)
        self.novnc_route_key = _stable_id("vroute", self.workspace_id)

    def _container_spec(self) -> WorkspaceContainerSpec:
        return WorkspaceContainerSpec(
            workspace_id=self.workspace_id,
            user_id=self.user_id,
            runtime_id=self.runtime_id,
            container_image=self.container_image,
            profile_volume_name=self.profile_volume_name,
            labels={
                "runtime-backend": self.runtime_backend,
                "workspace-id": self.workspace_id,
                "user-id": self.user_id,
            },
            environment={
                "PAYSWITCH_WORKSPACE_ID": self.workspace_id,
                "PAYSWITCH_USER_ID": self.user_id,
                "PAYSWITCH_RUNTIME_ID": self.runtime_id,
            },
        )

    def _container_record(self) -> WorkspaceContainerRecord | None:
        if self.container_id is None or self.container_name is None:
            return None
        return WorkspaceContainerRecord(
            container_id=self.container_id,
            container_name=self.container_name,
            workspace_id=self.workspace_id,
            user_id=self.user_id,
            image=self.container_image,
            profile_volume_name=self.profile_volume_name,
            status="running" if self.container_status == "running" else "stopped",
            created_at=self.created_at,
            started_at=self.container_started_at,
            stopped_at=self.container_stopped_at,
            labels={
                "runtime-backend": self.runtime_backend,
                "workspace-id": self.workspace_id,
                "user-id": self.user_id,
            },
        )

    def _sync_container_record(self, record: WorkspaceContainerRecord) -> None:
        self.container_id = record.container_id
        self.container_name = record.container_name
        self.container_status = record.status
        self.container_started_at = record.started_at
        self.container_stopped_at = record.stopped_at
        self.last_container_error = None

    def wake(self) -> None:
        super().wake()
        try:
            record = self.container_driver.start_workspace(
                spec=self._container_spec(),
                existing=self._container_record(),
            )
        except Exception as exc:
            self.status = "destroyed"
            self.display_state = "no_runtime"
            self.display_ready = False
            self.display_reason = "container_runtime_start_failed"
            self.last_status_reason = "container_runtime_start_failed"
            self.last_container_error = str(exc)
            self.updated_at = _now()
            raise
        self._sync_container_record(record)
        self.last_status_reason = "container_runtime_wake"

    def mark_sleeping(self) -> None:
        record = self._container_record()
        if record is None:
            super().mark_sleeping()
            self.container_status = "stopped"
            return
        try:
            stopped = self.container_driver.stop_workspace(record)
        except Exception as exc:
            self.last_container_error = str(exc)
            self.last_status_reason = "container_runtime_stop_failed"
            self.updated_at = _now()
            return
        self._sync_container_record(stopped)
        super().mark_sleeping()

    def mark_destroyed(self, *, reason: str) -> None:
        record = self._container_record()
        if record is not None:
            try:
                self.container_driver.destroy_workspace(record)
            except Exception as exc:
                self.last_container_error = str(exc)
        super().mark_destroyed(reason=reason)
        self.container_status = "destroyed"

    def snapshot(self) -> dict[str, Any]:
        return {
            **super().snapshot(),
            "container_id": self.container_id,
            "container_name": self.container_name,
            "container_status": self.container_status,
            "container_image": self.container_image,
            "container_driver": self.container_driver.driver_kind,
            "container_driver_available": self.container_driver.available,
            "container_driver_reason": self.container_driver.availability_reason,
            "profile_volume_name": self.profile_volume_name,
            "novnc_route_key": self.novnc_route_key,
            "container_started_at": self.container_started_at,
            "container_stopped_at": self.container_stopped_at,
            "last_container_error": self.last_container_error,
        }


@dataclass(frozen=True)
class WorkspaceRuntimeFactory:
    """Create the configured runtime backend for a user workspace."""

    backend: RuntimeBackend = "in_process"
    container_image: str = "ghcr.io/arxchibobo/payswitch-workspace:latest"
    container_driver: WorkspaceContainerDriver = field(
        default_factory=InMemoryWorkspaceContainerDriver,
        repr=False,
    )

    def create_runtime(
        self,
        *,
        workspace_id: str,
        user_id: str,
        policy: RuntimePolicy,
    ) -> WorkspaceRuntime:
        if self.backend not in {"in_process", "container"}:
            raise ValueError(f"unsupported workspace runtime backend: {self.backend}")
        if self.backend == "container":
            return ContainerWorkspaceRuntime(
                workspace_id=workspace_id,
                user_id=user_id,
                policy=policy,
                container_image=self.container_image,
                container_driver=self.container_driver,
            )
        return InProcessWorkspaceRuntime(
            workspace_id=workspace_id,
            user_id=user_id,
            policy=policy,
        )

    @classmethod
    def from_env(cls) -> WorkspaceRuntimeFactory:
        backend = (
            os.getenv("PAYSWITCH_WORKSPACE_RUNTIME_BACKEND", "in_process").strip()
            or "in_process"
        )
        container_image = (
            os.getenv(
                "PAYSWITCH_WORKSPACE_CONTAINER_IMAGE",
                "ghcr.io/arxchibobo/payswitch-workspace:latest",
            ).strip()
            or "ghcr.io/arxchibobo/payswitch-workspace:latest"
        )
        driver_kind = (
            os.getenv("PAYSWITCH_WORKSPACE_CONTAINER_DRIVER", "docker").strip() or "docker"
        )
        if backend == "container":
            container_driver = build_workspace_container_driver(driver_kind)  # type: ignore[arg-type]
            return cls(
                backend="container",
                container_image=container_image,
                container_driver=container_driver,
            )
        return cls(backend="in_process", container_image=container_image)
