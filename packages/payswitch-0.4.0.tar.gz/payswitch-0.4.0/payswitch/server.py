"""Pay-Switch HTTP/A2A server.

This module turns the existing CLI-first product into a deployable service:

* REST endpoint for direct product integrations.
* A2A-compatible message/task endpoints.
* SSE event stream consumed by the frontend control plane.
* Static serving for the compiled frontend bundle.
"""

from __future__ import annotations

import asyncio
import base64
import binascii
import hmac
import io
import json
import mimetypes
import os
import re
import secrets
import shutil
import zipfile
from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, quote, urlencode, urlsplit, urlunsplit

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    Response,
    StreamingResponse,
)
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

from payswitch import __version__
from payswitch.agent_language import (
    PaymentIntent,
    intent_from_a2a_message,
    intent_from_mapping,
    intent_from_text,
    to_psl,
)
from payswitch.agent_workspace import AgentWorkspaceManager
from payswitch.ai_planner import PaymentPlanner
from payswitch.engine.ledger import Ledger
from payswitch.engine.orchestrator import PaymentOrchestrator, PaySwitchError
from payswitch.experience import (
    ExperienceStore,
    ReadyPatchPromotionSupervisor,
    RecoveryImprovementSupervisor,
)
from payswitch.models.config import PaySwitchConfig
from payswitch.models.types import PaymentMethod, TransactionStatus
from payswitch.profile_manager import (
    ProfileBinding,
    ProfileVaultManager,
    resolve_profile_schema_version,
)
from payswitch.security.artifacts import (
    ArtifactSensitivity,
    ArtifactStore,
    decode_data_url_payload,
)
from payswitch.security.cleanup import (
    ArtifactBudgetEnforcementSupervisor,
    ArtifactCleanupSupervisor,
)
from payswitch.security.secret_envelope import (
    SECRET_ENVELOPE_SCHEMA,
    SecretEnvelopeError,
    encrypt_secret,
)
from payswitch.session_store import AgentTask, TaskStore
from payswitch.workspace_runtime import WorkspaceRuntimeFactory

ENV_FILE = Path.home() / ".payswitch" / "server.env"
DEFAULT_FRONTEND_DIST = Path(__file__).resolve().parents[1] / "frontend" / "dist"
PLUGIN_ROOT = Path(__file__).resolve().parents[1] / "plugins" / "pay-switch-agent"
PLUGIN_ARCHIVE_PREFIX = "payswitch-main/plugins/pay-switch-agent/"
PLUGIN_INSTALL_FALLBACK_ZIP_URL = (
    "https://github.com/Arxchibobo/payswitch/archive/refs/heads/main.zip"
)
PAYAGENT_TOKEN_PREFIX = "psw_agent_"
PAYAGENT_TOKEN_SCOPE = "payagent:human-gated"
_LAST_NOW: datetime | None = None


def load_server_env(path: Path = ENV_FILE) -> None:
    """Load simple KEY=VALUE lines without overriding existing environment."""

    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


load_server_env()


@asynccontextmanager
async def _app_lifespan(application: FastAPI):
    improvement_supervisor = build_recovery_improvement_supervisor_from_env()
    promotion_supervisor = build_ready_patch_promotion_supervisor_from_env()
    artifact_cleanup_supervisor = build_artifact_cleanup_supervisor_from_env()
    artifact_budget_enforcement_supervisor = (
        build_artifact_budget_enforcement_supervisor_from_env()
    )
    application.state.recovery_improvement_supervisor = improvement_supervisor
    application.state.ready_patch_promotion_supervisor = promotion_supervisor
    application.state.artifact_cleanup_supervisor = artifact_cleanup_supervisor
    application.state.artifact_budget_enforcement_supervisor = (
        artifact_budget_enforcement_supervisor
    )
    if improvement_supervisor is not None:
        await improvement_supervisor.start()
    if promotion_supervisor is not None:
        await promotion_supervisor.start()
    if artifact_cleanup_supervisor is not None:
        await artifact_cleanup_supervisor.start()
    if artifact_budget_enforcement_supervisor is not None:
        await artifact_budget_enforcement_supervisor.start()
    try:
        yield
    finally:
        if artifact_budget_enforcement_supervisor is not None:
            await artifact_budget_enforcement_supervisor.stop()
        if artifact_cleanup_supervisor is not None:
            await artifact_cleanup_supervisor.stop()
        if promotion_supervisor is not None:
            await promotion_supervisor.stop()
        if improvement_supervisor is not None:
            await improvement_supervisor.stop()
        application.state.recovery_improvement_supervisor = None
        application.state.ready_patch_promotion_supervisor = None
        application.state.artifact_cleanup_supervisor = None
        application.state.artifact_budget_enforcement_supervisor = None


app = FastAPI(
    title="Pay-Switch Agent",
    version=__version__,
    description="Payment control plane for agent-to-agent commerce requests.",
    lifespan=_app_lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("PAYSWITCH_CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class PaymentCreateRequest(BaseModel):
    """REST request shape accepted by /api/payments."""

    model_config = ConfigDict(populate_by_name=True)

    amount: float = Field(gt=0)
    payee: str
    reason: str = ""
    currency: str = "CNY"
    method: PaymentMethod = PaymentMethod.auto
    idempotency_key: str | None = Field(default=None, alias="idempotencyKey")
    callback_url: str | None = Field(default=None, alias="callbackUrl")
    dry_run: bool = Field(default=False, alias="dryRun")
    source_agent: str = Field(default="rest", alias="sourceAgent")
    product: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class SecretEnvelopeCreateRequest(BaseModel):
    """Request shape for encrypting a provisioned API key for an agent inbox."""

    model_config = ConfigDict(populate_by_name=True)

    provider: str = Field(min_length=1)
    secret: str = Field(min_length=1)
    recipient_public_key: str = Field(alias="recipientPublicKey", min_length=1)
    secret_type: str = Field(default="api_key", alias="secretType")
    key_name: str | None = Field(default=None, alias="keyName")
    metadata: dict[str, Any] = Field(default_factory=dict)


class SessionConfirmRequest(BaseModel):
    """Confirm a Human Gate session and attach post-payment artifacts."""

    model_config = ConfigDict(populate_by_name=True)

    success: bool = True
    api_key: str | None = Field(default=None, alias="apiKey")
    secret: str | None = None
    secret_type: str = Field(default="api_key", alias="secretType")
    key_name: str | None = Field(default=None, alias="keyName")
    evidence_artifacts: list[dict[str, Any]] = Field(
        default_factory=list,
        alias="evidenceArtifacts",
    )
    generated_outputs: list[dict[str, Any]] = Field(
        default_factory=list,
        alias="generatedOutputs",
    )
    media_artifacts: list[dict[str, Any]] = Field(
        default_factory=list,
        alias="mediaArtifacts",
    )
    note: str | None = None


def _current_profile_binding() -> ProfileBinding:
    config = PaySwitchConfig.load()
    browser_engine = config.browser_engine.strip() or "playwright"
    return ProfileBinding(
        browser_engine=browser_engine,
        schema_version=resolve_profile_schema_version(browser_engine),
    )


def build_workspace_manager_from_env(
    *,
    profile_manager_override: ProfileVaultManager | None = None,
) -> AgentWorkspaceManager:
    profile_manager = profile_manager_override or ProfileVaultManager()
    return AgentWorkspaceManager(
        profile_manager=profile_manager,
        profile_binding_provider=_current_profile_binding,
        runtime_factory=WorkspaceRuntimeFactory.from_env(),
    )


store = TaskStore(task_event_factory=lambda task: _task_event(task))
profile_manager = ProfileVaultManager()
workspace_manager = build_workspace_manager_from_env(
    profile_manager_override=profile_manager,
)
app.state.recovery_improvement_supervisor = None
app.state.ready_patch_promotion_supervisor = None
app.state.artifact_cleanup_supervisor = None
app.state.artifact_budget_enforcement_supervisor = None


def _experience_store_from_config(
    *,
    config_override: PaySwitchConfig | None = None,
) -> ExperienceStore:
    config = config_override or PaySwitchConfig.load()
    return ExperienceStore(config.data_dir / "experience" / "recipes.db")


def _artifact_store_from_config(
    *,
    config_override: PaySwitchConfig | None = None,
) -> ArtifactStore:
    config = config_override or PaySwitchConfig.load()
    return ArtifactStore(
        config.data_dir,
        public_retention_hours=config.artifact_public_retention_hours,
        internal_retention_hours=config.artifact_internal_retention_hours,
        sensitive_retention_hours=config.artifact_sensitive_retention_hours,
    )


def _env_flag(name: str) -> bool:
    return os.getenv(name, "").strip().lower() in {"1", "true", "yes", "on"}


def _artifact_budget_bytes_from_env() -> int | None:
    raw = os.getenv("PAYSWITCH_ARTIFACT_STORAGE_BUDGET_MB", "").strip()
    if not raw:
        return None
    return int(float(raw) * 1024 * 1024)


def build_recovery_improvement_supervisor_from_env(
    *,
    config_override: PaySwitchConfig | None = None,
) -> RecoveryImprovementSupervisor | None:
    if not _env_flag("PAYSWITCH_RECOVERY_IMPROVER_ENABLED"):
        return None

    config = config_override or PaySwitchConfig.load()
    reviewer = (
        os.getenv("PAYSWITCH_RECOVERY_IMPROVER_REVIEWER", "").strip()
        or "recovery-improver"
    )
    note = os.getenv("PAYSWITCH_RECOVERY_IMPROVER_NOTE", "").strip() or None
    platform = os.getenv("PAYSWITCH_RECOVERY_IMPROVER_PLATFORM", "").strip() or None
    flow = os.getenv("PAYSWITCH_RECOVERY_IMPROVER_FLOW", "").strip() or None
    auto_accept_basis = (
        os.getenv("PAYSWITCH_RECOVERY_IMPROVER_AUTO_ACCEPT_BASIS", "").strip() or None
    )
    min_shadow_runs = int(os.getenv("PAYSWITCH_RECOVERY_IMPROVER_MIN_SHADOW_RUNS", "1"))
    poll_interval_seconds = float(
        os.getenv("PAYSWITCH_RECOVERY_IMPROVER_POLL_INTERVAL_SECONDS", "30")
    )
    batch_limit = int(os.getenv("PAYSWITCH_RECOVERY_IMPROVER_BATCH_LIMIT", "10"))
    dry_run = _env_flag("PAYSWITCH_RECOVERY_IMPROVER_DRY_RUN")
    return RecoveryImprovementSupervisor(
        _experience_store_from_config(config_override=config),
        reviewer=reviewer,
        note=note,
        platform=platform,
        flow=flow,
        auto_accept_basis=auto_accept_basis,
        min_shadow_runs=min_shadow_runs,
        poll_interval_seconds=poll_interval_seconds,
        batch_limit=batch_limit,
        dry_run=dry_run,
    )


def build_ready_patch_promotion_supervisor_from_env(
    *,
    config_override: PaySwitchConfig | None = None,
) -> ReadyPatchPromotionSupervisor | None:
    if not _env_flag("PAYSWITCH_READY_PATCH_PROMOTER_ENABLED"):
        return None

    config = config_override or PaySwitchConfig.load()
    actor = (
        os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_ACTOR", "").strip()
        or "ready-patch-promoter"
    )
    note = os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_NOTE", "").strip() or None
    basis = os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_BASIS", "").strip() or None
    min_shadow_runs = int(os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_MIN_SHADOW_RUNS", "1"))
    platform = os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_PLATFORM", "").strip() or None
    flow = os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_FLOW", "").strip() or None
    source = os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_SOURCE", "").strip() or None
    poll_interval_seconds = float(
        os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_POLL_INTERVAL_SECONDS", "30")
    )
    batch_limit = int(os.getenv("PAYSWITCH_READY_PATCH_PROMOTER_BATCH_LIMIT", "10"))
    dry_run = _env_flag("PAYSWITCH_READY_PATCH_PROMOTER_DRY_RUN")
    return ReadyPatchPromotionSupervisor(
        _experience_store_from_config(config_override=config),
        actor=actor,
        note=note,
        basis=basis,
        min_shadow_runs=min_shadow_runs,
        platform=platform,
        flow=flow,
        source=source,
        poll_interval_seconds=poll_interval_seconds,
        batch_limit=batch_limit,
        dry_run=dry_run,
    )


def build_artifact_cleanup_supervisor_from_env(
    *,
    config_override: PaySwitchConfig | None = None,
) -> ArtifactCleanupSupervisor | None:
    if not _env_flag("PAYSWITCH_ARTIFACT_CLEANUP_ENABLED"):
        return None

    config = config_override or PaySwitchConfig.load()
    poll_interval_seconds = float(
        os.getenv("PAYSWITCH_ARTIFACT_CLEANUP_POLL_INTERVAL_SECONDS", "300")
    )
    batch_limit = int(os.getenv("PAYSWITCH_ARTIFACT_CLEANUP_BATCH_LIMIT", "25"))
    dry_run = _env_flag("PAYSWITCH_ARTIFACT_CLEANUP_DRY_RUN")
    return ArtifactCleanupSupervisor(
        _artifact_store_from_config(config_override=config),
        poll_interval_seconds=poll_interval_seconds,
        batch_limit=batch_limit,
        dry_run=dry_run,
    )


def build_artifact_budget_enforcement_supervisor_from_env(
    *,
    config_override: PaySwitchConfig | None = None,
) -> ArtifactBudgetEnforcementSupervisor | None:
    if not _env_flag("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_ENABLED"):
        return None
    budget_bytes = _artifact_budget_bytes_from_env()
    if budget_bytes is None or budget_bytes < 1:
        return None

    config = config_override or PaySwitchConfig.load()
    poll_interval_seconds = float(
        os.getenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_POLL_INTERVAL_SECONDS", "300")
    )
    batch_limit = int(os.getenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_BATCH_LIMIT", "25"))
    target_ratio = float(os.getenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_TARGET_RATIO", "0.9"))
    dry_run = _env_flag("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_DRY_RUN")
    include_sensitive = _env_flag("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_INCLUDE_SENSITIVE")
    return ArtifactBudgetEnforcementSupervisor(
        _artifact_store_from_config(config_override=config),
        budget_bytes=budget_bytes,
        target_ratio=target_ratio,
        poll_interval_seconds=poll_interval_seconds,
        batch_limit=batch_limit,
        include_sensitive=include_sensitive,
        dry_run=dry_run,
    )


def _now() -> str:
    global _LAST_NOW
    current = datetime.now(UTC)
    if _LAST_NOW is not None and current <= _LAST_NOW:
        current = _LAST_NOW + timedelta(microseconds=1)
    _LAST_NOW = current
    return current.isoformat().replace("+00:00", "Z")


def _event(
    *,
    task: AgentTask,
    kind: str,
    summary: str,
    message: str,
    source: str = "pay_switch",
    path: list[str] | None = None,
    risk: str = "low",
    target: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    intent = task.intent
    payload = {
        "id": f"evt_{len(task.events) + 1}_{secrets.token_hex(3)}",
        "ts": _now(),
        "type": kind,
        "summary": summary,
        "message": message,
        "source": source,
        "path": path or ["External Agent", "Pay-Switch"],
        "risk": risk,
        "target": target or intent.get("payee"),
        "merchant": intent.get("payee"),
        "amount": intent.get("amount"),
        "currency": intent.get("currency"),
        "reason": intent.get("reason"),
        "user_id": task.user_id,
        "workspace_id": task.workspace_id,
        "subagent_session_id": task.subagent_session_id,
        "site_id": task.site_id,
    }
    if extra:
        payload.update(extra)
    return payload


def _task_event(task: AgentTask) -> dict[str, Any]:
    payload = {
        "id": f"evt_task_{secrets.token_hex(3)}",
        "ts": _now(),
        "type": "observe",
        "summary": f"Task {task.status}",
        "message": f"Pay-Switch task {task.id} is {task.status}.",
        "source": "pay_switch",
        "path": ["External Agent", "Pay-Switch"],
        "risk": "low",
        "target": task.intent.get("payee"),
        "merchant": task.intent.get("payee"),
        "amount": task.intent.get("amount"),
        "currency": task.intent.get("currency"),
        "reason": task.intent.get("reason"),
        "user_id": task.user_id,
        "workspace_id": task.workspace_id,
        "subagent_session_id": task.subagent_session_id,
        "site_id": task.site_id,
    }
    if task.result:
        human_action = task.result.get("human_action")
        if isinstance(human_action, dict):
            display_url = _public_novnc_url(str(human_action.get("novnc_url") or ""))
            if display_url:
                payload["display_url"] = display_url
    return payload


def _public_novnc_url(raw_url: str | None = None, request: Request | None = None) -> str:
    request_host = request.url.hostname if request is not None else "127.0.0.1"
    request_scheme = request.url.scheme if request is not None else "http"
    host = os.getenv("PAYSWITCH_PUBLIC_HOST", request_host or "127.0.0.1")
    scheme = os.getenv("PAYSWITCH_PUBLIC_SCHEME", request_scheme or "http")
    port = int(os.getenv("PAYSWITCH_NOVNC_PORT", "6080"))
    public_url = _novnc_url(scheme=scheme, host=host, port=port)
    raw = (raw_url or "").strip()
    if not raw:
        return public_url

    parsed = urlsplit(raw)
    public = urlsplit(public_url)
    public_query = dict(parse_qsl(public.query, keep_blank_values=True))
    public_query.setdefault("autoconnect", "true")
    public_query.setdefault("resize", "scale")
    public_query.setdefault("reconnect", "true")

    if parsed.hostname in {"0.0.0.0", "127.0.0.1", "localhost", None}:
        return urlunsplit(
            (
                public.scheme,
                public.netloc,
                public.path,
                urlencode(public_query),
                parsed.fragment,
            )
        )

    if parsed.scheme == "http" and public.scheme == "https":
        return urlunsplit(
            (
                public.scheme,
                public.netloc,
                public.path,
                urlencode(public_query),
                parsed.fragment,
            )
        )

    return raw


def _merge_url_query(raw_url: str, params: dict[str, str | None]) -> str:
    parsed = urlsplit(raw_url)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    for key, value in params.items():
        if value is None or value == "":
            query.pop(key, None)
        else:
            query[key] = value
    return urlunsplit(
        (
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            urlencode(query, doseq=True),
            parsed.fragment,
        )
    )


def _token_secret() -> str:
    return os.getenv("PAYSWITCH_AGENT_TOKEN", "").strip()


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64url_decode(raw: str) -> bytes:
    padding = "=" * (-len(raw) % 4)
    return base64.urlsafe_b64decode(raw + padding)


def _client_token_ttl_seconds() -> int:
    raw = os.getenv("PAYSWITCH_PAYAGENT_TOKEN_TTL_SECONDS", "").strip()
    if not raw:
        return 180 * 24 * 60 * 60
    try:
        return max(300, int(raw))
    except ValueError:
        return 180 * 24 * 60 * 60


def _issue_payagent_client_token() -> dict[str, Any]:
    secret = _token_secret()
    if not secret:
        return {
            "token": "",
            "scope": PAYAGENT_TOKEN_SCOPE,
            "expires_at": None,
            "token_required": False,
        }
    now = int(datetime.now(UTC).timestamp())
    expires_at = now + _client_token_ttl_seconds()
    payload = {
        "scope": PAYAGENT_TOKEN_SCOPE,
        "iat": now,
        "exp": expires_at,
        "jti": secrets.token_urlsafe(12),
    }
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    encoded_payload = _b64url_encode(payload_bytes)
    signature = hmac.new(secret.encode("utf-8"), encoded_payload.encode("ascii"), "sha256")
    token = f"{PAYAGENT_TOKEN_PREFIX}{encoded_payload}.{_b64url_encode(signature.digest())}"
    return {
        "token": token,
        "scope": PAYAGENT_TOKEN_SCOPE,
        "expires_at": datetime.fromtimestamp(expires_at, UTC).isoformat().replace("+00:00", "Z"),
        "token_required": True,
    }


def _valid_payagent_client_token(token: str) -> bool:
    secret = _token_secret()
    if not secret or not token.startswith(PAYAGENT_TOKEN_PREFIX):
        return False
    try:
        body, signature = token.removeprefix(PAYAGENT_TOKEN_PREFIX).split(".", 1)
        expected = hmac.new(secret.encode("utf-8"), body.encode("ascii"), "sha256")
        if not hmac.compare_digest(signature, _b64url_encode(expected.digest())):
            return False
        payload = json.loads(_b64url_decode(body).decode("utf-8"))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return False
    if payload.get("scope") != PAYAGENT_TOKEN_SCOPE:
        return False
    try:
        expires_at = int(payload.get("exp", 0))
    except (TypeError, ValueError):
        return False
    return expires_at >= int(datetime.now(UTC).timestamp())


async def require_agent_token(request: Request) -> None:
    expected = _token_secret()
    if not expected:
        return
    header = request.headers.get("authorization", "")
    bearer = header.removeprefix("Bearer ").strip() if header.lower().startswith("bearer ") else ""
    query_token = request.query_params.get("token", "")
    if secrets.compare_digest(bearer, expected) or secrets.compare_digest(query_token, expected):
        return
    if _valid_payagent_client_token(bearer) or _valid_payagent_client_token(query_token):
        return
    raise HTTPException(status_code=401, detail="missing or invalid Pay-Switch agent token")


async def _run_task(task_id: str) -> None:
    task = await store.get(task_id)
    if task is None:
        return
    intent = PaymentIntent.model_validate(task.intent)
    lease = None
    try:
        lease = await workspace_manager.start_session(task_id, intent)
        await store.update(task_id, status="working")
        task = await store.get(task_id) or task
        await store.emit(
            task_id,
            _event(
                task=task,
                kind="workspace.acquired",
                summary="User workspace acquired",
                message=(
                    f"Subagent {task.subagent_session_id} is running in "
                    f"workspace {task.workspace_id}."
                ),
                path=[intent.source_agent, "Pay-Switch", "Workspace"],
                risk="low",
                target=intent.payee,
                extra={
                    "workspace_id": task.workspace_id,
                    "subagent_session_id": task.subagent_session_id,
                    "site_id": task.site_id,
                    "site_lock_id": task.site_lock_id,
                },
            ),
        )
        await store.emit(
            task_id,
            _event(
                task=task,
                kind="intent.received",
                summary="收到支付意图",
                message=(
                    f"{intent.source_agent} requested {intent.currency} "
                    f"{intent.amount:g} for {intent.payee}."
                ),
                source=intent.source_agent,
                path=[intent.source_agent, "Pay-Switch"],
                target=intent.payee,
            ),
        )

        planner = PaymentPlanner()
        plan = await planner.plan(intent)
        await store.update(task_id, plan=plan.model_dump(mode="json"))
        await store.emit(
            task_id,
            _event(
                task=task,
                kind="route.selected",
                summary="支付能力路由已生成",
                message=plan.summary,
                path=[intent.source_agent, "Pay-Switch", "Router"],
                risk="medium" if not intent.dry_run else "low",
                target=intent.payee,
            ),
        )

        await store.emit(
            task_id,
            _event(
                task=task,
                kind="guard.passed",
                summary="进入 Pay-Switch 风控与账本检查",
                message="限额、幂等键和支付边界会在执行器中统一校验。",
                path=[intent.source_agent, "Pay-Switch", "Guard"],
                risk="low",
                target=intent.payee,
            ),
        )

        config = PaySwitchConfig.load()
        initial_display_url = _public_novnc_url()
        await store.emit(
            task_id,
            _event(
                task=task,
                kind="action.allowed",
                summary="编排器开始执行",
                message="PaymentOrchestrator 已接管请求，敏感字段与最终授权保持人工闸口。",
                path=[intent.source_agent, "Pay-Switch", "Browser"],
                risk="medium",
                target=intent.payee,
                extra={
                    "display_url": initial_display_url,
                    "novnc_url": initial_display_url,
                },
            ),
        )

        async def emit_progress(progress: dict[str, Any]) -> None:
            latest = await store.get(task_id)
            if latest is None:
                return
            extra = dict(progress.get("extra") or {})
            display_url = _public_novnc_url(
                str(extra.get("display_url") or extra.get("novnc_url") or "")
            )
            if display_url:
                extra["display_url"] = display_url
                extra["novnc_url"] = display_url
            await store.emit(
                task_id,
                _event(
                    task=latest,
                    kind=str(progress.get("kind") or "observe"),
                    summary=str(progress.get("summary") or "浏览器步骤更新"),
                    message=str(progress.get("message") or ""),
                    path=list(progress.get("path") or [intent.source_agent, "Pay-Switch"]),
                    risk=str(progress.get("risk") or "medium"),
                    target=str(progress.get("target") or intent.payee),
                    extra=extra,
                ),
            )

        orchestrator = PaymentOrchestrator(
            config,
            wait_for_human_completion=False,
            progress_sink=emit_progress,
        )
        try:
            tx = await orchestrator.spend(
                amount=intent.amount,
                payee=intent.payee,
                reason=intent.reason,
                method=intent.method,
                idempotency_key=intent.idempotency_key,
                url=str(intent.metadata.get("url") or "") or None,
                dry_run=intent.dry_run,
            )
        finally:
            orchestrator.close()

        result = _maybe_encrypt_result_secret(tx.model_dump(mode="json"), intent)
        if tx.status == TransactionStatus.human_action_required:
            await workspace_manager.promote_task_profile(task_id)
            await store.update(task_id, status="input-required", result=result)
            human_action = tx.human_action
            human_extra: dict[str, Any] = {}
            if human_action is not None:
                display_url = _public_novnc_url(human_action.novnc_url)
                if display_url:
                    human_extra["display_url"] = display_url
                    human_extra["novnc_url"] = display_url
                if human_action.details:
                    human_extra.update(
                        {
                            "current_url": human_action.details.get("current_url"),
                            "details": human_action.details,
                        }
                    )
            await store.emit(
                task_id,
                _event(
                    task=task,
                    kind="human.gate",
                    summary=_human_action_title(
                        human_action.action_type if human_action is not None else "human_action"
                    ),
                    message=(
                        tx.human_action.guidance
                        if tx.human_action
                        else "需要用户完成支付授权。"
                    ),
                    path=[intent.source_agent, "Pay-Switch", "Human Gate"],
                    risk="high",
                    target=intent.payee,
                    extra=human_extra,
                ),
            )
            return

        if tx.status == TransactionStatus.completed:
            await workspace_manager.promote_task_profile(task_id)
            await store.update(task_id, status="completed", result=result)
            await store.emit(
                task_id,
                _event(
                    task=task,
                    kind="completed",
                    summary="支付任务完成",
                    message=f"交易 {tx.tx_id} 已完成并写入 ledger。",
                    path=[intent.source_agent, "Pay-Switch", "Ledger"],
                    risk="low",
                    target=intent.payee,
                ),
            )
            return

        await workspace_manager.discard_task_profile(
            task_id,
            reason=tx.error or tx.status.value,
        )
        await store.update(
            task_id,
            status="failed",
            result=result,
            error=tx.error or tx.status.value,
        )
        await store.emit(
            task_id,
            _event(
                task=task,
                kind="action.blocked",
                summary="支付任务未完成",
                message=tx.error or f"交易状态：{tx.status.value}",
                path=[intent.source_agent, "Pay-Switch", "Guard"],
                risk="high",
                target=intent.payee,
            ),
        )
    except Exception as exc:
        if lease is not None:
            try:
                await workspace_manager.discard_task_profile(task_id, reason=str(exc))
            except Exception:
                pass
        await store.update(task_id, status="failed", error=str(exc))
        latest = await store.get(task_id)
        if latest is not None:
            await store.emit(
                task_id,
                _event(
                    task=latest,
                    kind="action.blocked",
                    summary="后端执行失败",
                    message=str(exc),
                    path=[intent.source_agent, "Pay-Switch"],
                    risk="high",
                    target=intent.payee,
                ),
            )
    finally:
        if lease is not None:
            latest = await store.get(task_id)
            final_status = latest.status if latest is not None else "unknown"
            await lease.release(final_status=final_status)


_SENSITIVE_RESULT_KEYS = {
    "api_key",
    "apikey",
    "apiKey",
    "secret",
    "secret_value",
    "secretValue",
    "plaintext_secret",
    "plaintextSecret",
    "provisioned_secret",
    "provisionedSecret",
    "access_token",
    "accessToken",
    "refresh_token",
    "refreshToken",
    "id_token",
    "idToken",
    "client_secret",
    "clientSecret",
    "private_key",
    "privateKey",
    "password",
    "payment_password",
    "paymentPassword",
    "cvv",
    "cvc",
    "otp",
    "sms_code",
    "smsCode",
    "verification_code",
    "verificationCode",
    "card_number",
    "cardNumber",
    "pan",
}
_RESULT_LOCAL_PATH_KEYS = {
    "artifact_path",
    "artifactPath",
    "qr_artifact_path",
    "qrArtifactPath",
    "screenshot_path",
    "screenshotPath",
}

_SECRET_TYPE_BY_RESULT_KEY = {
    "api_key": "api_key",
    "apikey": "api_key",
    "apiKey": "api_key",
    "secret": "secret",
    "secret_value": "secret",
    "secretValue": "secret",
    "plaintext_secret": "secret",
    "plaintextSecret": "secret",
    "provisioned_secret": "secret",
    "provisionedSecret": "secret",
    "access_token": "access_token",
    "accessToken": "access_token",
    "refresh_token": "refresh_token",
    "refreshToken": "refresh_token",
    "id_token": "id_token",
    "idToken": "id_token",
    "client_secret": "client_secret",
    "clientSecret": "client_secret",
    "private_key": "private_key",
    "privateKey": "private_key",
}


def _is_sensitive_result_key(key: str) -> bool:
    if key.endswith("_ref") or key.endswith("Ref"):
        return False
    return key in _SENSITIVE_RESULT_KEYS or key.lower() in _SENSITIVE_RESULT_KEYS


def _secret_type_for_result_key(key: str, default_secret_type: str) -> str:
    return (
        _SECRET_TYPE_BY_RESULT_KEY.get(key)
        or _SECRET_TYPE_BY_RESULT_KEY.get(key.lower())
        or default_secret_type
        or "secret"
    )


def _secret_delivery_request(intent: PaymentIntent) -> dict[str, Any] | None:
    metadata = intent.metadata or {}
    raw_delivery = metadata.get("secret_delivery")
    delivery = raw_delivery if isinstance(raw_delivery, dict) else {}
    recipient_public_key = str(
        delivery.get("recipient_public_key")
        or delivery.get("recipientPublicKey")
        or metadata.get("secret_recipient_public_key")
        or metadata.get("recipient_public_key")
        or ""
    ).strip()
    requested = bool(
        delivery.get("requested")
        or metadata.get("request_api_key")
        or metadata.get("api_key_return")
        or recipient_public_key
    )
    if not requested:
        return None
    return {
        "recipient_public_key": recipient_public_key,
        "secret_type": str(
            delivery.get("secret_type")
            or delivery.get("secretType")
            or metadata.get("secret_type")
            or "api_key"
        ),
        "key_name": delivery.get("key_name") or delivery.get("keyName") or metadata.get("key_name"),
        "metadata": {
            "intent_payee": intent.payee,
            "product": intent.product,
            "idempotency_key": intent.idempotency_key,
        },
    }


def _pop_secret_values(
    result: dict[str, Any],
    *,
    default_secret_type: str,
) -> list[dict[str, str]]:
    secrets_to_encrypt: list[dict[str, str]] = []

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            for key in list(value.keys()):
                item = value.get(key)
                key_text = str(key)
                if isinstance(item, str) and item and _is_sensitive_result_key(key_text):
                    secrets_to_encrypt.append(
                        {
                            "value": item,
                            "secret_type": _secret_type_for_result_key(
                                key_text,
                                default_secret_type,
                            ),
                            "key_name": key_text,
                        }
                    )
                    value.pop(key, None)
                    continue
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)

    visit(result)
    return secrets_to_encrypt


def _maybe_encrypt_result_secret(result: dict[str, Any], intent: PaymentIntent) -> dict[str, Any]:
    delivery = _secret_delivery_request(intent)
    if delivery is None:
        return result

    default_secret_type = str(delivery.get("secret_type") or "api_key")
    secret_values = _pop_secret_values(result, default_secret_type=default_secret_type)
    if not secret_values:
        result.setdefault(
            "secret_delivery",
            {
                "requested": True,
                "status": "pending_adapter_secret",
                "schema": SECRET_ENVELOPE_SCHEMA,
            },
        )
        return result

    recipient_public_key = str(delivery.get("recipient_public_key") or "").strip()
    if not recipient_public_key:
        result["secret_delivery"] = {
            "requested": True,
            "status": "missing_recipient_public_key",
            "schema": SECRET_ENVELOPE_SCHEMA,
            "secret_count": len(secret_values),
        }
        return result

    provider = str(result.get("payee") or intent.payee)
    envelopes: list[dict[str, Any]] = []
    try:
        for item in secret_values:
            envelope = encrypt_secret(
                item["value"],
                recipient_public_key=recipient_public_key,
                provider=provider,
                secret_type=item.get("secret_type") or default_secret_type,
                key_name=delivery.get("key_name") or item.get("key_name"),
                metadata=(
                    delivery.get("metadata")
                    if isinstance(delivery.get("metadata"), dict)
                    else {}
                ),
            )
            envelopes.append(envelope)
    except SecretEnvelopeError as exc:
        result["secret_delivery"] = {
            "requested": True,
            "status": "encryption_failed",
            "error": str(exc),
            "schema": SECRET_ENVELOPE_SCHEMA,
            "secret_count": len(secret_values),
        }
        return result

    result.setdefault("secret_envelopes", []).extend(envelopes)
    result["secret_delivery"] = {
        "requested": True,
        "status": "encrypted",
        "schema": SECRET_ENVELOPE_SCHEMA,
        "recipient_id": envelopes[0].get("recipient_id"),
        "secret_type": envelopes[0].get("secret_type") if len(envelopes) == 1 else "multiple",
        "provider": envelopes[0].get("provider"),
        "secret_count": len(envelopes),
    }
    return result


def _redact_sensitive_result(value: Any) -> Any:
    if isinstance(value, dict):
        if value.get("schema") == SECRET_ENVELOPE_SCHEMA and "ciphertext" in value:
            return dict(value)
        redacted: dict[str, Any] = {}
        for key, item in value.items():
            if _is_sensitive_result_key(str(key)):
                redacted[key] = "[redacted:encrypted_delivery_required]"
            elif str(key) in _RESULT_LOCAL_PATH_KEYS:
                redacted[key] = "[redacted:download_via_artifact_metadata]"
            else:
                redacted[key] = _redact_sensitive_result(item)
        return redacted
    if isinstance(value, list):
        return [_redact_sensitive_result(item) for item in value]
    return value


def _secret_envelopes_from_result(result: dict[str, Any] | None) -> list[dict[str, Any]]:
    envelopes: list[dict[str, Any]] = []
    seen: set[str] = set()

    def collect(value: Any) -> None:
        if isinstance(value, dict):
            if value.get("schema") == SECRET_ENVELOPE_SCHEMA and "ciphertext" in value:
                key = str(value.get("ciphertext") or id(value))
                if key not in seen:
                    seen.add(key)
                    envelopes.append(value)
                return
            for item in value.values():
                collect(item)
        elif isinstance(value, list):
            for item in value:
                collect(item)

    if isinstance(result, dict):
        collect(result)
    return envelopes


def _secret_envelope_artifacts(result: dict[str, Any] | None) -> list[dict[str, Any]]:
    artifacts: list[dict[str, Any]] = []
    for index, envelope in enumerate(_secret_envelopes_from_result(result), start=1):
        provider = envelope.get("provider") or "provider"
        secret_type = envelope.get("secret_type") or "secret"
        artifacts.append(
            {
                "artifactId": f"encrypted_secret_{index}",
                "name": f"Encrypted {provider} {secret_type}",
                "parts": [{"kind": "data", "data": envelope}],
                "metadata": {
                    "schema": SECRET_ENVELOPE_SCHEMA,
                    "delivery": "encrypted_a2a",
                    "decoder": "payagent secret decrypt --in <envelope.json>",
                },
            }
        )
    return artifacts


def _evidence_items_from_result(result: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not isinstance(result, dict):
        return []
    items: list[dict[str, Any]] = []
    for key in ("evidence_artifacts", "generated_outputs", "media_artifacts"):
        value = result.get(key)
        if isinstance(value, list):
            items.extend(item for item in value if isinstance(item, dict))
    return items


_CONFIRM_ARTIFACT_INLINE_KEYS = frozenset(
    {
        "content",
        "contentBase64",
        "contentType",
        "content_base64",
        "content_type",
        "dataUrl",
        "data_url",
        "downloadUrl",
        "download_url",
        "jsonPayload",
        "json_payload",
        "text",
        "artifactPath",
        "artifact_path",
    }
)
_CONFIRM_ARTIFACT_ID_PATTERN = re.compile(r"[^A-Za-z0-9._-]+")


def _confirm_artifact_download_url(
    session_id: str,
    artifact_id: str,
    *,
    user_id: str | None = None,
) -> str:
    url = (
        f"/api/sessions/{quote(session_id, safe='')}/artifacts/{quote(artifact_id, safe='')}"
    )
    if user_id:
        url = f"{url}?user_id={quote(user_id, safe='')}"
    return url


def _confirm_artifact_id(item: dict[str, Any], *, fallback: str) -> str:
    raw = str(item.get("artifact_id") or item.get("artifactId") or fallback).strip()
    normalized = _CONFIRM_ARTIFACT_ID_PATTERN.sub("-", raw).strip(".-_")
    return normalized or fallback


def _confirm_artifact_name(item: dict[str, Any], *, artifact_id: str) -> str:
    raw = str(item.get("name") or item.get("label") or artifact_id).strip()
    return raw or artifact_id


def _confirm_artifact_content_type(item: dict[str, Any], *, default: str) -> str:
    content_type = str(item.get("content_type") or item.get("contentType") or default).strip()
    return content_type or default


def _artifact_non_negative_int(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value >= 0 else None
    if isinstance(value, float):
        if value.is_integer() and value >= 0:
            return int(value)
        return None
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        try:
            parsed = int(raw)
        except ValueError:
            return None
        return parsed if parsed >= 0 else None
    return None


def _artifact_non_negative_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        parsed = float(value)
        return parsed if parsed >= 0 else None
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        try:
            parsed = float(raw)
        except ValueError:
            return None
        return parsed if parsed >= 0 else None
    return None


def _confirm_artifact_suffix(*, name: str, content_type: str) -> str:
    suffix = Path(name).suffix.lower()
    if suffix:
        return suffix
    guessed = mimetypes.guess_extension(content_type.split(";", 1)[0].strip())
    if guessed == ".jpe":
        return ".jpg"
    return guessed or ""


def _confirm_artifact_path(
    session_id: str,
    *,
    collection: str,
    artifact_id: str,
    name: str,
    content_type: str,
) -> Path:
    safe_collection = _CONFIRM_ARTIFACT_ID_PATTERN.sub("-", collection).strip(".-_") or "artifact"
    suffix = _confirm_artifact_suffix(name=name, content_type=content_type)
    return (
        PaySwitchConfig.load().data_dir
        / "evidence"
        / "session-confirm"
        / session_id
        / f"{safe_collection}-{artifact_id}{suffix}"
    )


def _confirm_artifact_sensitivity(item: dict[str, Any]) -> ArtifactSensitivity:
    raw = str(item.get("sensitivity") or ArtifactSensitivity.internal).strip().lower()
    try:
        return ArtifactSensitivity(raw)
    except ValueError:
        return ArtifactSensitivity.internal


def _confirm_artifact_payload(item: dict[str, Any]) -> tuple[bytes, str] | None:
    data_url = item.get("data_url") or item.get("dataUrl")
    if isinstance(data_url, str) and data_url.strip():
        decoded = decode_data_url_payload(data_url.strip())
        if decoded is None:
            raise HTTPException(status_code=422, detail="invalid confirm artifact data URL payload")
        return decoded

    raw_base64 = item.get("content_base64") or item.get("contentBase64") or item.get("content")
    if isinstance(raw_base64, str) and raw_base64.strip():
        try:
            payload = base64.b64decode(raw_base64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(
                status_code=422,
                detail="invalid confirm artifact base64 payload",
            ) from exc
        content_type = _confirm_artifact_content_type(item, default="application/octet-stream")
        return payload, content_type

    text_payload = item.get("text")
    if isinstance(text_payload, str):
        content_type = _confirm_artifact_content_type(item, default="text/plain; charset=utf-8")
        return text_payload.encode("utf-8"), content_type

    json_payload = item.get("json_payload") or item.get("jsonPayload")
    if json_payload is not None:
        content_type = _confirm_artifact_content_type(item, default="application/json")
        payload = json.dumps(
            json_payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=str,
        ).encode("utf-8")
        return (
            payload,
            content_type,
        )
    return None


def _artifact_item_public_metadata(
    session_id: str,
    item: dict[str, Any],
    *,
    user_id: str | None = None,
) -> dict[str, Any]:
    artifact_id = str(item.get("artifact_id") or item.get("artifactId") or "").strip()
    recording_index = _artifact_non_negative_int(
        item.get("recording_index") or item.get("recordingIndex")
    )
    raw_path = str(item.get("artifact_path") or item.get("artifactPath") or "").strip()
    download_url = str(item.get("download_url") or item.get("downloadUrl") or "").strip()
    content_type = str(item.get("content_type") or item.get("contentType") or "").strip()
    size_bytes = _artifact_non_negative_int(item.get("size_bytes") or item.get("sizeBytes"))
    duration_seconds = _artifact_non_negative_float(
        item.get("duration_seconds") or item.get("durationSeconds")
    )
    frame_rate = _artifact_non_negative_float(item.get("frame_rate") or item.get("frameRate"))
    source_screenshot_count = _artifact_non_negative_int(
        item.get("source_screenshot_count") or item.get("sourceScreenshotCount")
    )
    bit_rate = _artifact_non_negative_int(item.get("bit_rate") or item.get("bitRate"))
    frame_width = _artifact_non_negative_int(item.get("frame_width") or item.get("frameWidth"))
    frame_height = _artifact_non_negative_int(
        item.get("frame_height") or item.get("frameHeight")
    )
    codec_name = str(item.get("codec_name") or item.get("codecName") or "").strip().lower()
    if raw_path and artifact_id and not download_url:
        download_url = _confirm_artifact_download_url(session_id, artifact_id, user_id=user_id)
    if raw_path and (
        not content_type
        or size_bytes is None
        or frame_rate is None
        or bit_rate is None
        or frame_width is None
        or frame_height is None
        or not codec_name
    ):
        artifact_path = Path(raw_path).expanduser()
        metadata_record: dict[str, Any] | None = None
        try:
            store = _artifact_store_from_config()
            if not content_type:
                content_type = store.read_content_type(artifact_path) or ""
            metadata_record = store.read_metadata(artifact_path)
        except (OSError, ValueError):
            if not content_type:
                content_type = ""
            metadata_record = None
        metadata_payload = {}
        if isinstance(metadata_record, dict):
            metadata_value = metadata_record.get("metadata")
            if isinstance(metadata_value, dict):
                metadata_payload = metadata_value
        if size_bytes is None:
            size_bytes = _artifact_non_negative_int(
                metadata_payload.get("size_bytes") or metadata_payload.get("sizeBytes")
            )
        if recording_index is None:
            recording_index = _artifact_non_negative_int(
                metadata_payload.get("recording_index") or metadata_payload.get("recordingIndex")
            )
        if frame_rate is None:
            frame_rate = _artifact_non_negative_float(
                metadata_payload.get("frame_rate") or metadata_payload.get("frameRate")
            )
        if source_screenshot_count is None:
            source_screenshot_count = _artifact_non_negative_int(
                metadata_payload.get("source_screenshot_count")
                or metadata_payload.get("sourceScreenshotCount")
            )
        if bit_rate is None:
            bit_rate = _artifact_non_negative_int(
                metadata_payload.get("bit_rate") or metadata_payload.get("bitRate")
            )
        if frame_width is None:
            frame_width = _artifact_non_negative_int(
                metadata_payload.get("frame_width") or metadata_payload.get("frameWidth")
            )
        if frame_height is None:
            frame_height = _artifact_non_negative_int(
                metadata_payload.get("frame_height") or metadata_payload.get("frameHeight")
            )
        if not codec_name:
            codec_name = str(
                metadata_payload.get("codec_name") or metadata_payload.get("codecName") or ""
            ).strip().lower()
        if not content_type:
            content_type = mimetypes.guess_type(str(artifact_path))[0] or ""
        if size_bytes is None:
            try:
                if not bool(metadata_record and metadata_record.get("encrypted")):
                    size_bytes = artifact_path.stat().st_size
            except OSError:
                size_bytes = None
    return {
        "artifact_id": artifact_id or None,
        "recording_index": recording_index,
        "download_url": download_url or None,
        "content_type": content_type or None,
        "size_bytes": size_bytes,
        "duration_seconds": duration_seconds,
        "frame_rate": frame_rate,
        "source_screenshot_count": source_screenshot_count,
        "bit_rate": bit_rate,
        "frame_width": frame_width,
        "frame_height": frame_height,
        "codec_name": codec_name or None,
        "persisted": bool(raw_path and artifact_id),
    }


def _confirm_artifact_public_item(
    session_id: str,
    item: dict[str, Any],
    *,
    user_id: str | None = None,
) -> dict[str, Any]:
    public_item = {
        key: value for key, value in item.items() if key not in {"artifact_path", "artifactPath"}
    }
    if "artifactId" not in public_item and "artifact_id" in public_item:
        public_item["artifactId"] = public_item["artifact_id"]
    recording_index = _artifact_non_negative_int(
        public_item.get("recording_index") or public_item.get("recordingIndex")
    )
    if recording_index is not None:
        public_item.setdefault("recording_index", recording_index)
        public_item.setdefault("recordingIndex", recording_index)
    size_bytes = _artifact_non_negative_int(
        public_item.get("size_bytes") or public_item.get("sizeBytes")
    )
    if size_bytes is not None:
        public_item.setdefault("size_bytes", size_bytes)
        public_item.setdefault("sizeBytes", size_bytes)
    duration_seconds = _artifact_non_negative_float(
        public_item.get("duration_seconds") or public_item.get("durationSeconds")
    )
    if duration_seconds is not None:
        public_item.setdefault("duration_seconds", duration_seconds)
        public_item.setdefault("durationSeconds", duration_seconds)
    frame_rate = _artifact_non_negative_float(
        public_item.get("frame_rate") or public_item.get("frameRate")
    )
    if frame_rate is not None:
        public_item.setdefault("frame_rate", frame_rate)
        public_item.setdefault("frameRate", frame_rate)
    source_screenshot_count = _artifact_non_negative_int(
        public_item.get("source_screenshot_count") or public_item.get("sourceScreenshotCount")
    )
    if source_screenshot_count is not None:
        public_item.setdefault("source_screenshot_count", source_screenshot_count)
        public_item.setdefault("sourceScreenshotCount", source_screenshot_count)
    bit_rate = _artifact_non_negative_int(public_item.get("bit_rate") or public_item.get("bitRate"))
    if bit_rate is not None:
        public_item.setdefault("bit_rate", bit_rate)
        public_item.setdefault("bitRate", bit_rate)
    frame_width = _artifact_non_negative_int(
        public_item.get("frame_width") or public_item.get("frameWidth")
    )
    if frame_width is not None:
        public_item.setdefault("frame_width", frame_width)
        public_item.setdefault("frameWidth", frame_width)
    frame_height = _artifact_non_negative_int(
        public_item.get("frame_height") or public_item.get("frameHeight")
    )
    if frame_height is not None:
        public_item.setdefault("frame_height", frame_height)
        public_item.setdefault("frameHeight", frame_height)
    codec_name = (
        str(public_item.get("codec_name") or public_item.get("codecName") or "")
        .strip()
        .lower()
    )
    if codec_name:
        public_item.setdefault("codec_name", codec_name)
        public_item.setdefault("codecName", codec_name)
    capture_engine = (
        str(public_item.get("capture_engine") or public_item.get("captureEngine") or "").strip()
    )
    if capture_engine:
        public_item.setdefault("capture_engine", capture_engine)
        public_item.setdefault("captureEngine", capture_engine)
    recording_source = (
        str(public_item.get("recording_source") or public_item.get("recordingSource") or "").strip()
    )
    if recording_source:
        public_item.setdefault("recording_source", recording_source)
        public_item.setdefault("recordingSource", recording_source)
    storage = _artifact_item_public_metadata(session_id, item, user_id=user_id)
    if (
        storage["download_url"]
        and "download_url" not in public_item
        and "downloadUrl" not in public_item
    ):
        public_item["download_url"] = storage["download_url"]
        public_item["downloadUrl"] = storage["download_url"]
    if (
        storage["content_type"]
        and "content_type" not in public_item
        and "contentType" not in public_item
    ):
        public_item["content_type"] = storage["content_type"]
        public_item["contentType"] = storage["content_type"]
    if storage["recording_index"] is not None:
        public_item.setdefault("recording_index", storage["recording_index"])
        public_item.setdefault("recordingIndex", storage["recording_index"])
    if storage["size_bytes"] is not None:
        public_item.setdefault("size_bytes", storage["size_bytes"])
        public_item.setdefault("sizeBytes", storage["size_bytes"])
    if storage["duration_seconds"] is not None:
        public_item.setdefault("duration_seconds", storage["duration_seconds"])
        public_item.setdefault("durationSeconds", storage["duration_seconds"])
    if storage["frame_rate"] is not None:
        public_item.setdefault("frame_rate", storage["frame_rate"])
        public_item.setdefault("frameRate", storage["frame_rate"])
    if storage["source_screenshot_count"] is not None:
        public_item.setdefault("source_screenshot_count", storage["source_screenshot_count"])
        public_item.setdefault("sourceScreenshotCount", storage["source_screenshot_count"])
    if storage["bit_rate"] is not None:
        public_item.setdefault("bit_rate", storage["bit_rate"])
        public_item.setdefault("bitRate", storage["bit_rate"])
    if storage["frame_width"] is not None:
        public_item.setdefault("frame_width", storage["frame_width"])
        public_item.setdefault("frameWidth", storage["frame_width"])
    if storage["frame_height"] is not None:
        public_item.setdefault("frame_height", storage["frame_height"])
        public_item.setdefault("frameHeight", storage["frame_height"])
    if storage["codec_name"]:
        public_item.setdefault("codec_name", storage["codec_name"])
        public_item.setdefault("codecName", storage["codec_name"])
    if storage["persisted"] and "persisted" not in public_item:
        public_item["persisted"] = True
    return public_item


def _normalize_confirm_artifact_item(
    session_id: str,
    item: dict[str, Any],
    *,
    collection: str,
    index: int,
    user_id: str | None = None,
) -> dict[str, Any]:
    artifact_id = _confirm_artifact_id(item, fallback=f"{collection}_{index}")
    name = _confirm_artifact_name(item, artifact_id=artifact_id)
    normalized = {
        key: value for key, value in item.items() if key not in _CONFIRM_ARTIFACT_INLINE_KEYS
    }
    normalized.pop("artifact_id", None)
    normalized.pop("artifactId", None)
    normalized["artifact_id"] = artifact_id
    normalized["artifactId"] = artifact_id
    normalized["name"] = name
    normalized["session_id"] = session_id
    normalized["sessionId"] = session_id

    payload = _confirm_artifact_payload(item)
    if payload is None:
        return normalized

    raw_bytes, detected_content_type = payload
    content_type = _confirm_artifact_content_type(item, default=detected_content_type)
    artifact_path = _confirm_artifact_path(
        session_id,
        collection=collection,
        artifact_id=artifact_id,
        name=name,
        content_type=content_type,
    )
    metadata = {
        "artifact_id": artifact_id,
        "collection": collection,
        "name": name,
        "provider": item.get("provider"),
        "kind": item.get("kind") or item.get("type"),
        "session_id": session_id,
    }
    retention_hours = item.get("retention_hours") or item.get("retentionHours")
    if retention_hours is not None:
        try:
            retention_hours = int(retention_hours)
        except (TypeError, ValueError) as exc:
            raise HTTPException(
                status_code=422,
                detail="invalid confirm artifact retention hours",
            ) from exc
    _artifact_store_from_config().write_bytes(
        artifact_path,
        raw_bytes,
        artifact_kind=str(item.get("kind") or item.get("type") or collection),
        sensitivity=_confirm_artifact_sensitivity(item),
        content_type=content_type,
        retention_hours=retention_hours,
        metadata=metadata,
    )
    normalized.update(
        {
            "artifact_path": str(artifact_path),
            "artifactPath": str(artifact_path),
            "content_type": content_type,
            "contentType": content_type,
            "size_bytes": len(raw_bytes),
            "sizeBytes": len(raw_bytes),
            "download_url": _confirm_artifact_download_url(
                session_id,
                artifact_id,
                user_id=user_id,
            ),
            "downloadUrl": _confirm_artifact_download_url(
                session_id,
                artifact_id,
                user_id=user_id,
            ),
            "delivery": "persisted_artifact",
        }
    )
    return normalized


def _find_session_artifact_item(
    result: dict[str, Any] | None,
    artifact_id: str,
) -> dict[str, Any] | None:
    for item in _evidence_items_from_result(result):
        current_id = str(item.get("artifact_id") or item.get("artifactId") or "").strip()
        if current_id == artifact_id:
            return item
    return None


def _evidence_artifacts_from_result(
    session_id: str,
    result: dict[str, Any] | None,
    *,
    user_id: str | None = None,
) -> list[dict[str, Any]]:
    artifacts: list[dict[str, Any]] = []
    for index, item in enumerate(_evidence_items_from_result(result), start=1):
        name = str(item.get("name") or item.get("label") or f"Evidence {index}")
        kind = str(item.get("kind") or item.get("type") or "evidence")
        artifact_id = str(item.get("artifact_id") or item.get("artifactId") or f"evidence_{index}")
        storage = _artifact_item_public_metadata(session_id, item, user_id=user_id)
        artifacts.append(
            {
                "artifactId": artifact_id,
                "name": name,
                "parts": [
                    {
                        "kind": "data",
                        "data": _confirm_artifact_public_item(session_id, item, user_id=user_id),
                    }
                ],
                "metadata": {
                    "kind": kind,
                    "provider": item.get("provider"),
                    "session_id": item.get("session_id") or item.get("sessionId"),
                    "content_type": storage["content_type"],
                    "download_url": storage["download_url"],
                    "persisted": storage["persisted"],
                },
            }
        )
    return artifacts


def _public_task_result(task: AgentTask) -> dict[str, Any]:
    result = task.result or {}
    redacted = _redact_sensitive_result(result)
    if not isinstance(redacted, dict):
        return {}
    for key in ("evidence_artifacts", "generated_outputs", "media_artifacts"):
        value = redacted.get(key)
        if not isinstance(value, list):
            continue
        source_items = _result_list(result, key)
        enriched_items: list[dict[str, Any]] = []
        for index, item in enumerate(value):
            if not isinstance(item, dict):
                continue
            source_item = source_items[index] if index < len(source_items) else item
            enriched_items.append(
                _confirm_artifact_public_item(
                    task.id,
                    source_item,
                    user_id=_explicit_session_user_id(task),
                )
            )
        redacted[key] = enriched_items
    return redacted


def _public_event_payload(task: AgentTask, event: dict[str, Any]) -> dict[str, Any]:
    projected = dict(event)
    media_items = event.get("media_artifacts")
    if isinstance(media_items, list):
        projected["media_artifacts"] = [
            _confirm_artifact_public_item(
                task.id,
                item,
                user_id=_explicit_session_user_id(task),
            )
            for item in media_items
            if isinstance(item, dict)
        ]
    return projected


def _as_a2a_task(task: AgentTask) -> dict[str, Any]:
    state = {
        "submitted": "submitted",
        "working": "working",
        "input-required": "input-required",
        "completed": "completed",
        "failed": "failed",
    }.get(task.status, "working")
    artifacts = [
        {
            "artifactId": "pay_switch_intent",
            "name": "Normalized Payment Intent",
            "parts": [{"kind": "data", "data": task.intent}],
        },
        {
            "artifactId": "pay_switch_psl",
            "name": "Pay-Switch Language",
            "parts": [{"kind": "text", "text": task.psl}],
        },
    ]
    if task.plan:
        artifacts.append(
            {
                "artifactId": "pay_switch_plan",
                "name": "AI Payment Plan",
                "parts": [{"kind": "data", "data": task.plan}],
            }
        )
    if task.result:
        artifacts.append(
            {
                "artifactId": "pay_switch_result",
                "name": "Pay-Switch Result",
                "parts": [{"kind": "data", "data": _public_task_result(task)}],
            }
        )
        artifacts.extend(_secret_envelope_artifacts(task.result))
        artifacts.extend(
            _evidence_artifacts_from_result(
                task.id,
                task.result,
                user_id=_explicit_session_user_id(task),
            )
        )
    return {
        "id": task.id,
        "contextId": task.context_id,
        "status": {
            "state": state,
            "timestamp": task.updated_at,
            "message": {
                "role": "agent",
                "parts": [{"kind": "text", "text": task.error or f"Pay-Switch task is {state}."}],
            },
        },
        "artifacts": artifacts,
        "metadata": {
            "psl": task.psl,
            "eventsUrl": f"/events?session_id={task.id}",
            "user_id": task.user_id,
            "workspace_id": task.workspace_id,
            "subagent_session_id": task.subagent_session_id,
            "site_id": task.site_id,
            "site_lock_id": task.site_lock_id,
        },
    }


async def _sse_generator(
    task_id: str,
    *,
    after_sequence: int | None = None,
    replay: bool = True,
):
    task = await store.get(task_id)
    if task is None:
        yield _sse({"type": "action.blocked", "summary": "session not found", "message": task_id})
        return
    queue = await store.subscribe(task_id, after_sequence=after_sequence, replay=replay)
    try:
        if not task.events:
            yield _sse(
                {
                    "id": "evt_waiting",
                    "ts": _now(),
                    "type": "observe",
                    "summary": "等待支付任务事件",
                    "message": f"Session {task_id} is connected.",
                    "source": "pay_switch",
                    "path": ["Dashboard", "Pay-Switch"],
                    "risk": "low",
                    "target": task.intent.get("payee"),
                    "merchant": task.intent.get("payee"),
                    "amount": task.intent.get("amount"),
                    "currency": task.intent.get("currency"),
                    "reason": task.intent.get("reason"),
                }
            )
        while True:
            payload = await queue.get()
            if isinstance(payload, dict):
                yield _sse(_public_event_payload(task, payload))
            else:
                yield _sse(payload)
    finally:
        await store.unsubscribe(task_id, queue)


async def _empty_dashboard_sse_generator(session_id: str | None):
    yield _sse(
        {
            "id": "evt_no_active_session",
            "ts": _now(),
            "type": "observe",
            "summary": "没有可用 Session",
            "message": "等待外部产品通过 REST 或 A2A 发起支付请求。",
            "source": "dashboard",
            "path": ["Dashboard", "Pay-Switch"],
            "risk": "low",
            "target": "payswitch",
            "merchant": "payswitch",
            "amount": 0,
            "currency": "CNY",
            "reason": "Unknown session" if session_id else "No active session",
        }
    )


def _sse(payload: dict[str, Any]) -> str:
    event_id = payload.get("sequence") or payload.get("id")
    id_line = f"id: {event_id}\n" if event_id is not None else ""
    return f"{id_line}data: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _novnc_url(*, scheme: str, host: str, port: int) -> str:
    public_url = os.getenv("PAYSWITCH_PUBLIC_NOVNC_URL", "").strip()
    if public_url:
        return public_url

    path = os.getenv("PAYSWITCH_NOVNC_PATH", "/vnc.html").strip() or "/vnc.html"
    prefix = "" if path.startswith("/") else "/"
    query = "" if "?" in path else "?autoconnect=true&resize=scale"
    return f"{scheme}://{host}:{port}{prefix}{path}{query}"


def _public_base_url(request: Request | None = None) -> str:
    configured = (
        os.getenv("PAYSWITCH_PUBLIC_BASE_URL", "").strip()
        or os.getenv("PAYSWITCH_PUBLIC_URL", "").strip()
    )
    if configured:
        return configured.rstrip("/")

    if os.getenv("PAYSWITCH_PUBLIC_HOST"):
        scheme = os.getenv("PAYSWITCH_PUBLIC_SCHEME", "http")
        return f"{scheme}://{os.environ['PAYSWITCH_PUBLIC_HOST'].strip()}".rstrip("/")

    if request is not None:
        return str(request.base_url).rstrip("/")
    return "http://127.0.0.1:8787"


@app.get("/api/health")
async def health(request: Request) -> dict[str, Any]:
    return _health_payload(request)


@app.get("/api/recovery-improvements/health")
async def recovery_improver_health() -> dict[str, Any]:
    return _recovery_improver_health_payload()


@app.get("/api/recovery-patch-promoter/health")
async def ready_patch_promotion_health() -> dict[str, Any]:
    return _ready_patch_promotion_health_payload()


@app.get("/api/artifact-cleanup/health")
async def artifact_cleanup_health() -> dict[str, Any]:
    return _artifact_cleanup_health_payload()


@app.get("/api/artifact-budget-enforcement/health")
async def artifact_budget_enforcement_health() -> dict[str, Any]:
    return _artifact_budget_enforcement_health_payload()


@app.get("/api/artifact-inventory/health")
async def artifact_inventory_health() -> dict[str, Any]:
    return _artifact_inventory_health_payload()


@app.get("/api/artifact-inbox/health")
async def artifact_inbox_health() -> dict[str, Any]:
    return _artifact_inbox_health_payload()


@app.get("/api/sessions/latest")
async def latest_session(request: Request, user_id: str | None = None) -> dict[str, Any]:
    tasks = [
        task
        for task in await store.list(user_id=user_id)
        if not _is_dashboard_placeholder(task)
    ]
    _assert_user_scope_for_latest_session(tasks, user_id=user_id)
    task = tasks[0] if tasks else None
    return {"session": await _session_snapshot(task, request=request) if task else None}


@app.get("/api/sessions")
async def sessions_list(request: Request, user_id: str | None = None) -> dict[str, Any]:
    tasks = [
        task
        for task in await store.list(user_id=user_id)
        if not _is_dashboard_placeholder(task)
    ]
    _assert_user_scope_for_shared_sessions(
        tasks,
        user_id=user_id,
        route_name="sessions list",
    )
    return {"sessions": [await _session_snapshot(task, request=request) for task in tasks]}


@app.get("/api/workspaces")
async def workspaces_list(user_id: str | None = None) -> dict[str, Any]:
    persisted = await store.list_workspaces(user_id=user_id)
    _assert_user_scope_for_user_bound_records(
        persisted,
        user_id=user_id,
        route_name="workspaces list",
    )
    live = {
        workspace["workspace_id"]: workspace
        for workspace in await workspace_manager.list_workspaces(user_id=user_id)
    }
    workspaces = []
    for workspace in persisted:
        live_workspace = live.get(str(workspace["workspace_id"]))
        profile_summary = await profile_manager.summarize_user_profiles(str(workspace["user_id"]))
        if live_workspace:
            workspace = {**workspace, **live_workspace, **profile_summary}
        else:
            workspace = {
                **workspace,
                "runtime_status": "offline",
                "display_state": "no_runtime",
                "display_ready": False,
                "display_surface_id": None,
                "runtime_id": None,
                "runtime_memory_mb": 0,
                "last_active_at": None,
                "last_sleep_at": None,
                "runtime_status_reason": "no_live_runtime",
                **profile_summary,
            }
        workspaces.append(workspace)
    return {"workspaces": workspaces}


@app.get("/api/subagents")
async def subagents_list(user_id: str | None = None) -> dict[str, Any]:
    persisted = await store.list_subagents(user_id=user_id)
    _assert_user_scope_for_user_bound_records(
        persisted,
        user_id=user_id,
        route_name="subagents list",
    )
    live = {
        session["task_id"]: session
        for session in await workspace_manager.list_sessions(user_id=user_id)
    }
    subagents = []
    for session in persisted:
        live_session = live.get(str(session["task_id"]))
        profile = await profile_manager.describe_profile(
            user_id=str(session["user_id"]),
            site_id=str(session["site_id"]),
            profile_id=str(session["profile_id"]),
            task_id=str(session["task_id"]),
            binding=_current_profile_binding(),
        )
        if live_session:
            session = {**session, **live_session, **profile}
        else:
            session = {
                **session,
                "runtime_status": "offline",
                "display_state": "no_runtime",
                "display_ready": False,
                "runtime_id": None,
                **profile,
            }
        subagents.append(session)
    return {"subagents": subagents}


@app.get("/api/workspace-runtimes/health")
async def workspace_runtime_health(user_id: str | None = None) -> dict[str, Any]:
    persisted = await store.list_workspaces(user_id=user_id)
    _assert_user_scope_for_user_bound_records(
        persisted,
        user_id=user_id,
        route_name="workspace runtime health",
    )
    return await workspace_manager.runtime_health(user_id=user_id)


def _is_dashboard_placeholder(task: AgentTask) -> bool:
    return (
        task.intent.get("source_agent") == "dashboard"
        and task.intent.get("payee") == "payswitch"
        and task.intent.get("reason") == "Dashboard live connection"
    )


def _assert_user_scope_for_shared_sessions(
    tasks: list[AgentTask],
    *,
    user_id: str | None,
    route_name: str,
) -> None:
    if user_id is not None:
        return
    owners = {task.user_id for task in tasks if task.user_id}
    if len(owners) > 1:
        raise HTTPException(
            status_code=409,
            detail=(
                f"{route_name} is ambiguous without user_id; provide user_id explicitly"
            ),
        )


def _assert_user_scope_for_user_bound_records(
    records: list[dict[str, Any]],
    *,
    user_id: str | None,
    route_name: str,
) -> None:
    if user_id is not None:
        return
    owners = {
        str(record.get("user_id")).strip()
        for record in records
        if str(record.get("user_id") or "").strip()
    }
    if len(owners) > 1:
        raise HTTPException(
            status_code=409,
            detail=(
                f"{route_name} is ambiguous without user_id; provide user_id explicitly"
            ),
        )


def _assert_user_scope_for_latest_session(
    tasks: list[AgentTask],
    *,
    user_id: str | None,
) -> None:
    if user_id is not None:
        return
    if any(_explicit_session_user_id(task) is not None for task in tasks):
        raise HTTPException(
            status_code=409,
            detail="latest session requires user_id when scoped sessions exist",
        )


def _assert_user_scope_for_session_clear(
    tasks: list[AgentTask],
    *,
    user_id: str | None,
) -> None:
    if user_id is not None:
        return
    if any(_explicit_session_user_id(task) is not None for task in tasks):
        raise HTTPException(
            status_code=409,
            detail="session clear requires user_id when scoped sessions exist",
        )


def _explicit_session_user_id(task: AgentTask) -> str | None:
    metadata = task.intent.get("metadata") if isinstance(task.intent, dict) else None
    if not isinstance(metadata, dict):
        return None
    for key in ("user_id", "userId", "owner_id", "ownerId", "account_id", "accountId"):
        raw = metadata.get(key)
        if raw is None:
            continue
        value = str(raw).strip()
        if value:
            return value
    return None


def _assert_user_scope_for_scoped_session(
    task: AgentTask,
    *,
    user_id: str | None,
    route_name: str,
) -> None:
    if user_id is not None or _explicit_session_user_id(task) is None:
        return
    raise HTTPException(
        status_code=409,
        detail=f"{route_name} requires user_id for scoped session access",
    )


@app.get("/api/sessions/{session_id}")
async def session_get(
    session_id: str,
    request: Request,
    user_id: str | None = None,
) -> dict[str, Any]:
    task = await store.get(session_id, user_id=user_id)
    if task is None:
        task = await store.find_by_tx_id(session_id, user_id=user_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"session not found: {session_id}")
    _assert_user_scope_for_scoped_session(
        task,
        user_id=user_id,
        route_name="session detail",
    )
    return {"session": await _session_snapshot(task, request=request)}


@app.post("/api/sessions/{session_id}:display/select")
async def session_display_select(
    session_id: str,
    request: Request,
    user_id: str | None = None,
) -> dict[str, Any]:
    task = await store.get(session_id, user_id=user_id)
    if task is None:
        task = await store.find_by_tx_id(session_id, user_id=user_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"session not found: {session_id}")
    _assert_user_scope_for_scoped_session(
        task,
        user_id=user_id,
        route_name="session display selection",
    )
    await workspace_manager.select_display_session(task.id, reason="operator_select")
    refreshed = await store.get(task.id, user_id=task.user_id) or task
    return {"session": await _session_snapshot(refreshed, request=request)}


@app.get("/api/sessions/{session_id}/display/view")
async def session_display_view(
    session_id: str,
    request: Request,
    token: str | None = None,
    user_id: str | None = None,
) -> Response:
    task = await store.get(session_id, user_id=user_id)
    if task is None:
        task = await store.find_by_tx_id(session_id, user_id=user_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"session not found: {session_id}")
    _assert_user_scope_for_scoped_session(
        task,
        user_id=user_id,
        route_name="session display view",
    )
    display = await workspace_manager.describe_display_session(task.id)
    if not display or not display.get("display_ready"):
        reason = str((display or {}).get("display_reason") or "display_not_ready")
        state = str((display or {}).get("display_state") or "no_runtime")
        return HTMLResponse(
            _display_waiting_html(
                title="等待当前 Session 接管链接",
                detail=f"display_state={state} reason={reason}",
            ),
            status_code=409,
        )
    expected = str(display.get("display_route_token") or "")
    if not expected or token != expected:
        return HTMLResponse(
            _display_waiting_html(
                title="当前 Session 接管链接已失效",
                detail="请回到控制面重新选择 Session。",
            ),
            status_code=409,
        )
    route = await workspace_manager.resolve_display_route(
        task.id,
        user_id=task.user_id,
        route_token=token,
    )
    if route is None:
        return HTMLResponse(
            _display_waiting_html(
                title="当前 Session 显示路由不可用",
                detail="请回到控制面重新选择 Session。",
            ),
            status_code=409,
        )
    return RedirectResponse(_scoped_novnc_display_url(route, request=request), status_code=307)


@app.delete("/api/sessions/{session_id}")
async def session_delete(session_id: str, user_id: str | None = None) -> dict[str, Any]:
    """删除指定 session。"""
    task = await store.get(session_id, user_id=user_id)
    if task is None:
        task = await store.find_by_tx_id(session_id, user_id=user_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"session not found: {session_id}")
    _assert_user_scope_for_scoped_session(
        task,
        user_id=user_id,
        route_name="session delete",
    )
    deleted = await store.delete(task.id, user_id=task.user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"session not found: {session_id}")
    await workspace_manager.release_session(task.id, final_status="deleted")
    return {"deleted": task.id}


@app.delete("/api/sessions")
async def session_clear(user_id: str | None = None) -> dict[str, Any]:
    """清除全部或指定用户的 session。"""
    tasks = [
        task
        for task in await store.list(user_id=user_id)
        if not _is_dashboard_placeholder(task)
    ]
    _assert_user_scope_for_session_clear(tasks, user_id=user_id)
    deleted_ids = await store.clear(user_id=user_id)
    if user_id:
        for session_id in deleted_ids:
            await workspace_manager.release_session(session_id, final_status="deleted")
    else:
        await workspace_manager.reset()
    return {"cleared": len(deleted_ids)}


@app.get(
    "/api/sessions/{session_id}/artifacts/{artifact_id}",
    dependencies=[Depends(require_agent_token)],
)
async def session_artifact_download(
    session_id: str,
    artifact_id: str,
    user_id: str | None = None,
) -> Response:
    task = await store.get(session_id, user_id=user_id)
    if task is None:
        task = await store.find_by_tx_id(session_id, user_id=user_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"session not found: {session_id}")
    _assert_user_scope_for_scoped_session(
        task,
        user_id=user_id,
        route_name="session artifact download",
    )

    item = _find_session_artifact_item(task.result, artifact_id)
    if item is None:
        raise HTTPException(status_code=404, detail=f"artifact not found: {artifact_id}")

    raw_path = str(item.get("artifact_path") or item.get("artifactPath") or "").strip()
    if not raw_path:
        raise HTTPException(
            status_code=404,
            detail=f"artifact payload not persisted: {artifact_id}",
        )

    config = PaySwitchConfig.load()
    artifact_path = Path(raw_path).expanduser().resolve()
    data_root = config.data_dir.expanduser().resolve()
    if not artifact_path.is_relative_to(data_root):
        raise HTTPException(
            status_code=409,
            detail=f"artifact path escapes data root: {artifact_id}",
        )
    if not artifact_path.exists():
        raise HTTPException(status_code=404, detail=f"artifact file missing: {artifact_id}")

    artifact_store = _artifact_store_from_config()
    content_type = str(
        item.get("content_type")
        or item.get("contentType")
        or artifact_store.read_content_type(artifact_path)
        or mimetypes.guess_type(str(artifact_path))[0]
        or "application/octet-stream"
    )
    filename = str(item.get("name") or artifact_path.name or artifact_id).strip() or artifact_id
    headers = {
        "Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename, safe='')}",
    }
    return Response(
        content=artifact_store.read_bytes(artifact_path),
        media_type=content_type,
        headers=headers,
    )


@app.post("/api/sessions/{session_id}:confirm", dependencies=[Depends(require_agent_token)])
async def session_confirm(
    session_id: str,
    payload: SessionConfirmRequest,
    request: Request,
    user_id: str | None = None,
) -> dict[str, Any]:
    task = await store.get(session_id, user_id=user_id)
    if task is None:
        task = await store.find_by_tx_id(session_id, user_id=user_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"session not found: {session_id}")
    _assert_user_scope_for_scoped_session(
        task,
        user_id=user_id,
        route_name="session confirm",
    )
    updated = await _confirm_task_from_ledger(task, payload)
    return {
        "session": await _session_snapshot(updated, request=request),
        "a2a_task": _as_a2a_task(updated),
    }


def _recovery_improver_health_payload() -> dict[str, Any]:
    supervisor = getattr(app.state, "recovery_improvement_supervisor", None)
    if supervisor is None:
        return {
            "enabled": False,
            "running": False,
            "reviewer": None,
            "note": None,
            "platform": None,
            "flow": None,
            "auto_accept_basis": None,
            "min_shadow_runs": 1,
            "dry_run": False,
            "poll_interval_seconds": None,
            "batch_limit": None,
            "cycles": 0,
            "total_auto_accepted": 0,
            "total_processed": 0,
            "total_reviewed_patches": 0,
            "last_started_at": None,
            "last_finished_at": None,
            "last_error": None,
        }
    return supervisor.snapshot()


def _ready_patch_promotion_health_payload() -> dict[str, Any]:
    supervisor = getattr(app.state, "ready_patch_promotion_supervisor", None)
    if supervisor is None:
        return {
            "enabled": False,
            "running": False,
            "actor": None,
            "note": None,
            "basis": None,
            "min_shadow_runs": 1,
            "platform": None,
            "flow": None,
            "source": None,
            "dry_run": False,
            "poll_interval_seconds": None,
            "batch_limit": None,
            "cycles": 0,
            "total_promoted": 0,
            "last_started_at": None,
            "last_finished_at": None,
            "last_error": None,
        }
    return supervisor.snapshot()


def _artifact_cleanup_health_payload() -> dict[str, Any]:
    supervisor = getattr(app.state, "artifact_cleanup_supervisor", None)
    if supervisor is None:
        return {
            "enabled": False,
            "running": False,
            "dry_run": False,
            "poll_interval_seconds": None,
            "batch_limit": None,
            "cycles": 0,
            "total_cleaned": 0,
            "total_deleted": 0,
            "total_metadata_only": 0,
            "last_started_at": None,
            "last_finished_at": None,
            "last_error": None,
        }
    return supervisor.snapshot()


def _artifact_budget_enforcement_health_payload() -> dict[str, Any]:
    supervisor = getattr(app.state, "artifact_budget_enforcement_supervisor", None)
    if supervisor is None:
        return {
            "enabled": False,
            "running": False,
            "dry_run": False,
            "budget_bytes": None,
            "target_ratio": None,
            "target_bytes": None,
            "include_sensitive": False,
            "poll_interval_seconds": None,
            "batch_limit": None,
            "cycles": 0,
            "total_triggered": 0,
            "total_cleaned": 0,
            "total_deleted": 0,
            "total_metadata_only": 0,
            "total_reclaimed_bytes": 0,
            "last_started_at": None,
            "last_finished_at": None,
            "last_error": None,
        }
    return supervisor.snapshot()


def _artifact_inventory_health_payload() -> dict[str, Any]:
    return _artifact_store_from_config().inventory(
        budget_bytes=_artifact_budget_bytes_from_env(),
    )


def _artifact_inbox_health_payload() -> dict[str, Any]:
    return {
        "available": True,
        **_artifact_store_from_config().local_inbox_summary(),
    }


def _health_payload(request: Request | None = None) -> dict[str, Any]:
    planner = PaymentPlanner()
    config = PaySwitchConfig.load()
    request_host = request.url.hostname if request is not None else "127.0.0.1"
    request_scheme = request.url.scheme if request is not None else "http"
    host = os.getenv("PAYSWITCH_PUBLIC_HOST", request_host or "127.0.0.1")
    scheme = os.getenv("PAYSWITCH_PUBLIC_SCHEME", request_scheme or "http")
    novnc_port = int(os.getenv("PAYSWITCH_NOVNC_PORT", "6080"))
    novnc_web = Path(os.getenv("PAYSWITCH_NOVNC_WEB", "/usr/share/novnc"))
    return {
        "ok": True,
        "service": "payswitch-agent",
        "version": __version__,
        "time": _now(),
        "public_url": _public_base_url(request),
        "ai": {
            "provider": planner.provider,
            "model": planner.model,
            "configured": bool(planner.api_key),
        },
        "auth": {
            "agent_token_configured": bool(_token_secret()),
            "payagent_bootstrap_enabled": True,
            "payagent_token_scope": PAYAGENT_TOKEN_SCOPE,
        },
        "secret_delivery": {
            "schema": SECRET_ENVELOPE_SCHEMA,
            "delivery": "encrypted_a2a",
            "requires_recipient_public_key": True,
        },
        "recovery_improver": _recovery_improver_health_payload(),
        "recovery_patch_promoter": _ready_patch_promotion_health_payload(),
        "artifact_cleanup": _artifact_cleanup_health_payload(),
        "artifact_budget_enforcement": _artifact_budget_enforcement_health_payload(),
        "artifact_inventory": _artifact_inventory_health_payload(),
        "artifact_inbox": _artifact_inbox_health_payload(),
        "computer_use": {
            "display": os.getenv("PAYSWITCH_DISPLAY") or os.getenv("DISPLAY", ""),
            "novnc_url": _novnc_url(scheme=scheme, host=host, port=novnc_port),
            "novnc_dependencies": {
                "Xvfb": bool(shutil.which("Xvfb")),
                "x11vnc": bool(shutil.which("x11vnc")),
                "websockify": bool(shutil.which("websockify")),
                "novnc_web": novnc_web.exists(),
            },
            "browser_engine": config.browser_engine,
            "humanize": config.browser_humanize,
        },
    }


def _session_display_view_url(
    task: AgentTask,
    *,
    route_token: str | None,
    request: Request | None = None,
) -> str | None:
    token = str(route_token or "").strip()
    if not token:
        return None
    base = _public_base_url(request)
    query = {"token": token}
    if task.user_id:
        query["user_id"] = task.user_id
    return (
        f"{base}/api/sessions/{task.id}/display/view?"
        f"{urlencode(query, doseq=True)}"
    )


def _scoped_novnc_display_url(
    display_route: dict[str, Any],
    *,
    request: Request | None = None,
) -> str:
    return _merge_url_query(
        _public_novnc_url(request=request),
        {
            "route": str(display_route.get("novnc_route_key") or ""),
            "workspace_id": str(display_route.get("workspace_id") or ""),
            "session_id": str(display_route.get("task_id") or ""),
            "runtime_id": str(display_route.get("runtime_id") or ""),
            "display_route_id": str(display_route.get("display_route_id") or ""),
        },
    )


async def _session_snapshot(task: AgentTask, *, request: Request | None = None) -> dict[str, Any]:
    intent = task.intent
    events = [
        _public_event_payload(task, event)
        for event in task.events
        if isinstance(event, dict)
    ]
    result = task.result or {}
    display = await workspace_manager.describe_display_session(task.id)
    profile = await profile_manager.describe_profile(
        user_id=task.user_id,
        site_id=task.site_id,
        profile_id=task.profile_id,
        task_id=task.id,
        binding=_current_profile_binding(),
    )
    display_ready = bool(display and display.get("display_ready"))
    display_route_token = str((display or {}).get("display_route_token") or "")
    display_url = _session_display_view_url(
        task,
        route_token=display_route_token,
        request=request,
    )
    human_event = _human_gate_event_from_result(
        task,
        request=request,
        display_url_override=display_url if display_ready else None,
        expose_display_url=display_ready,
    )
    if human_event:
        for event in reversed(events):
            if event.get("type") != "human.gate":
                continue
            event.setdefault("display_url", human_event.get("display_url"))
            event.setdefault("novnc_url", human_event.get("novnc_url"))
            event.setdefault("details", human_event.get("details"))
            break
        else:
            events.append(human_event)
    return {
        "id": task.id,
        "agent": _session_agent_label(str(intent.get("source_agent") or "")),
        "merchant": intent.get("payee") or "Pay-Switch",
        "amount": intent.get("amount") or 0,
        "currency": intent.get("currency") or "CNY",
        "reason": intent.get("reason") or "",
        "status": _session_status(task.status),
        "startedAt": task.created_at,
        "user_id": task.user_id,
        "workspace_id": task.workspace_id,
        "subagent_session_id": task.subagent_session_id,
        "site_id": task.site_id,
        "site_lock_id": task.site_lock_id,
        "profile_id": task.profile_id,
        "browser_context_id": task.browser_context_id,
        **profile,
        "runtime_status": (display or {}).get("runtime_status", "offline"),
        "display_state": (display or {}).get("display_state", "no_runtime"),
        "display_ready": display_ready,
        "display_reason": (display or {}).get("display_reason", "no_live_runtime"),
        "display_surface_id": (display or {}).get("display_surface_id"),
        "display_owner_task_id": (display or {}).get("display_owner_task_id"),
        "display_route_token": display_route_token or None,
        "display_route_id": (display or {}).get("display_route_id"),
        "display_route_expires_at": (display or {}).get("display_route_expires_at"),
        "novnc_route_key": (display or {}).get("novnc_route_key"),
        "display_selected_at": (display or {}).get("display_selected_at"),
        "browser_manager_state": (display or {}).get("browser_manager_state"),
        "active_browser_context_id": (display or {}).get("active_browser_context_id"),
        "active_browser_tab_id": (display or {}).get("active_browser_tab_id"),
        "active_browser_window_id": (display or {}).get("active_browser_window_id"),
        "active_browser_task_id": (display or {}).get("active_browser_task_id"),
        "display_focus_lock_id": (display or {}).get("display_focus_lock_id"),
        "display_focus_lock_task_id": (display or {}).get("display_focus_lock_task_id"),
        "display_focus_lock_action": (display or {}).get("display_focus_lock_action"),
        "display_focus_lock_acquired_at": (display or {}).get("display_focus_lock_acquired_at"),
        "display_focus_z_order_token": (display or {}).get("display_focus_z_order_token"),
        "display_focus_foreground_lease_id": (
            display or {}
        ).get("display_focus_foreground_lease_id"),
        "browser_selection_reason": (display or {}).get("browser_selection_reason"),
        "browser_selected_at": (display or {}).get("browser_selected_at"),
        "display_url": display_url if display_ready else None,
        "budget_state": result.get("budget_state") if isinstance(result, dict) else None,
        "events": events,
    }


def _session_agent_label(source_agent: str) -> str:
    return "Claude Code" if source_agent.lower().startswith("claude") else "Codex"


def _session_status(status: str) -> str:
    return {
        "submitted": "submitted",
        "queued": "submitted",
        "working": "running",
        "input-required": "waiting_human",
        "completed": "completed",
        "failed": "failed",
    }.get(status, "running")


def _human_gate_event_from_result(
    task: AgentTask,
    *,
    request: Request | None = None,
    display_url_override: str | None = None,
    expose_display_url: bool = False,
) -> dict[str, Any] | None:
    result = task.result or {}
    human_action = result.get("human_action")
    if not isinstance(human_action, dict):
        return None
    details = human_action.get("details")
    if not isinstance(details, dict):
        details = {}
    action_type = str(human_action.get("action_type") or "human_action")
    display_url = display_url_override if expose_display_url else None
    novnc_url = _public_novnc_url(str(human_action.get("novnc_url") or ""), request)
    return {
        "id": f"{task.id}-human-{action_type}",
        "ts": human_action.get("requested_at") or task.updated_at,
        "type": "human.gate",
        "summary": _human_action_title(action_type),
        "message": human_action.get("guidance") or "请在真实浏览器中完成人工操作后继续。",
        "source": "human",
        "path": [task.intent.get("source_agent") or "External Agent", "Pay-Switch", "Human Gate"],
        "risk": "high",
        "target": action_type,
        "merchant": task.intent.get("payee"),
        "amount": task.intent.get("amount"),
        "currency": task.intent.get("currency"),
        "reason": task.intent.get("reason"),
        **({"display_url": display_url} if display_url else {}),
        "novnc_url": novnc_url,
        "details": details,
    }


def _display_waiting_html(*, title: str, detail: str) -> str:
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>Pay-Switch Display</title>"
        "<style>"
        "body{margin:0;background:#0f1918;color:#d7ece8;font:14px/1.5 "
        "-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;"
        "display:grid;place-items:center;min-height:100vh}"
        ".card{max-width:520px;padding:28px 32px;border:1px solid "
        "rgba(128,185,172,.22);border-radius:12px;background:rgba(17,32,30,.92)}"
        "h1{margin:0 0 10px;font-size:22px}p{margin:0;color:#9bb7b1}"
        "</style>"
        f"</head><body><div class='card'><h1>{title}</h1><p>{detail}</p></div></body></html>"
    )


def _human_action_title(action_type: str) -> str:
    if action_type == "payment_authorization":
        return "等待付款授权"
    return {
        "requires_login": "需要登录后继续",
        "requires_identity_verification": "需要完成身份校验",
        "requires_plan_confirmation": "需要确认购买方案",
        "scan_qr": "已交付扫码付款",
        "confirm": "已交付最终付款确认",
        "takeover": "已交付人工接管",
    }.get(action_type, "已交付人工操作")


def _result_list(result: dict[str, Any], key: str) -> list[dict[str, Any]]:
    value = result.get(key)
    return [item for item in value if isinstance(item, dict)] if isinstance(value, list) else []


async def _confirm_task_from_ledger(
    task: AgentTask,
    payload: SessionConfirmRequest,
) -> AgentTask:
    tx_id = str((task.result or {}).get("tx_id") or "").strip()
    if not tx_id:
        raise HTTPException(status_code=409, detail="session has no linked ledger transaction")

    config = PaySwitchConfig.load()
    ledger = Ledger(db_path=config.data_dir / "payswitch.db")
    try:
        tx = ledger.get(tx_id)
        if tx is None:
            raise HTTPException(status_code=404, detail=f"ledger transaction not found: {tx_id}")
        if payload.success:
            orchestrator = PaymentOrchestrator(config)
            try:
                try:
                    updated_tx = await orchestrator.confirm(tx_id)
                except PaySwitchError as exc:
                    raise HTTPException(status_code=409, detail=str(exc)) from exc
            finally:
                orchestrator.close()
        else:
            now = datetime.now(UTC)
            ledger.update_status(
                tx_id,
                TransactionStatus.failed,
                completed_at=now,
                error=payload.note or "Human Gate was marked failed.",
                steps=tx.steps,
                human_action=tx.human_action,
            )
            updated_tx = ledger.get(tx_id)
            if updated_tx is None:
                raise HTTPException(
                    status_code=404,
                    detail=f"ledger transaction not found: {tx_id}",
                )
    finally:
        ledger.close()

    result = updated_tx.model_dump(mode="json")
    existing = task.result or {}
    if payload.evidence_artifacts:
        result["evidence_artifacts"] = [
            *_result_list(existing, "evidence_artifacts"),
            *[
                _normalize_confirm_artifact_item(
                    task.id,
                    item,
                    collection="evidence",
                    index=index,
                    user_id=_explicit_session_user_id(task),
                )
                for index, item in enumerate(payload.evidence_artifacts, start=1)
            ],
        ]
    if payload.generated_outputs:
        result["generated_outputs"] = [
            *_result_list(existing, "generated_outputs"),
            *[
                _normalize_confirm_artifact_item(
                    task.id,
                    item,
                    collection="generated",
                    index=index,
                    user_id=_explicit_session_user_id(task),
                )
                for index, item in enumerate(payload.generated_outputs, start=1)
            ],
        ]
    if payload.media_artifacts:
        result["media_artifacts"] = [
            *_result_list(existing, "media_artifacts"),
            *[
                _normalize_confirm_artifact_item(
                    task.id,
                    item,
                    collection="media",
                    index=index,
                    user_id=_explicit_session_user_id(task),
                )
                for index, item in enumerate(payload.media_artifacts, start=1)
            ],
        ]
    secret_value = payload.api_key or payload.secret
    if secret_value:
        result["api_key"] = secret_value
        result.setdefault("secret_delivery", {})
        result["secret_delivery"].update(
            {
                "requested": True,
                "secret_type": payload.secret_type,
                "key_name": payload.key_name,
            }
        )
    if payload.note:
        result["confirmation_note"] = payload.note

    intent = PaymentIntent.model_validate(task.intent)
    result = _maybe_encrypt_result_secret(result, intent)
    status = "completed" if payload.success else "failed"
    latest = await store.update(
        task.id,
        status=status,
        result=result,
        error=None if payload.success else result.get("error") or payload.note,
    )
    await store.emit(
        task.id,
        _event(
            task=latest,
            kind="completed" if payload.success else "action.blocked",
            summary="Human Gate 已确认" if payload.success else "Human Gate 标记失败",
            message=(
                f"交易 {tx_id} 已确认完成并写入 ledger。"
                if payload.success
                else f"交易 {tx_id} 已标记失败。"
            ),
            path=[task.intent.get("source_agent") or "External Agent", "Pay-Switch", "Ledger"],
            risk="low" if payload.success else "high",
            target=task.intent.get("payee"),
        ),
    )
    if _secret_envelopes_from_result(result):
        await store.emit(
            task.id,
            _event(
                task=latest,
                kind="secret.delivered",
                summary="API key 已加密回传",
                message="Pay-Switch 已生成 encrypted_a2a secret envelope，接收 agent 可本地解码。",
                path=[
                    task.intent.get("source_agent") or "External Agent",
                    "Pay-Switch",
                    "Encrypted Secret Delivery",
                ],
                risk="low",
                target=task.intent.get("payee"),
                extra={"secret_envelope_schema": SECRET_ENVELOPE_SCHEMA},
            ),
        )
    return latest


@app.get("/.well-known/agent-card.json")
@app.get("/.well-known/agent.json")
async def agent_card(request: Request) -> dict[str, Any]:
    base = _public_base_url(request)
    security = []
    security_schemes = {}
    if os.getenv("PAYSWITCH_AGENT_TOKEN"):
        security_schemes = {"agentToken": {"type": "http", "scheme": "bearer"}}
        security = [{"agentToken": []}]
    return {
        "protocolVersion": "0.3.0",
        "name": "Pay-Switch Agent",
        "description": (
            "Accepts agent payment intents and converts them into guarded "
            "Pay-Switch executions."
        ),
        "url": base,
        "version": __version__,
        "preferredTransport": "HTTP+JSON",
        "capabilities": {"streaming": True, "pushNotifications": False},
        "defaultInputModes": ["text/plain", "application/json"],
        "defaultOutputModes": ["application/json", "text/event-stream"],
        "securitySchemes": security_schemes,
        "security": security,
        "skills": [
            {
                "id": "payment_intent",
                "name": "Guarded Payment Intent Execution",
                "description": (
                    "Normalize a payment request, run AI routing, enforce "
                    "Pay-Switch guardrails, and return task events."
                ),
                "tags": ["payment", "checkout", "a2a", "agent-commerce"],
                "examples": [
                    (
                        'PAY 50 CNY TO jimeng FOR "Jimeng points top-up for image '
                        'and video generation" VIA alipay_qr'
                    ),
                    (
                        '{"amount":50,"currency":"CNY","payee":"jimeng",'
                        '"reason":"Jimeng points top-up for image and video generation",'
                        '"method":"alipay_qr"}'
                    ),
                ],
            }
        ],
        "metadata": {
            "psl": 'PAY <amount> <currency> TO <payee> FOR "<reason>" VIA <method> EXECUTE',
            "rest": f"{base}/api/payments",
            "sse": f"{base}/events",
            "payagent_install": f"{base}/api/payagent/install.py",
            "payagent_plugin_zip": f"{base}/api/payagent/plugin.zip",
            "payagent_bootstrap": f"{base}/api/payagent/bootstrap",
            "payagent_config": f"{base}/api/payagent/config",
            "secret_encrypt": f"{base}/api/secrets/encrypt",
            "session_confirm": f"{base}/api/sessions/{{session_id}}:confirm",
            "sessions": f"{base}/api/sessions",
            "workspaces": f"{base}/api/workspaces",
            "subagents": f"{base}/api/subagents",
            "secret_envelope_schema": SECRET_ENVELOPE_SCHEMA,
            "secret_delivery": {
                "mode": "encrypted_a2a",
                "recipient_key": "submit metadata.secret_delivery.recipient_public_key",
                "decoder": "payagent secret decrypt --in <envelope.json>",
            },
        },
    }


@app.post("/api/secrets/encrypt", dependencies=[Depends(require_agent_token)])
async def secret_encrypt(payload: SecretEnvelopeCreateRequest) -> dict[str, Any]:
    try:
        envelope = encrypt_secret(
            payload.secret,
            recipient_public_key=payload.recipient_public_key,
            provider=payload.provider,
            secret_type=payload.secret_type,
            key_name=payload.key_name,
            metadata=payload.metadata,
        )
    except SecretEnvelopeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {
        "schema": "pay-switch.secret-delivery.v1",
        "delivery": "encrypted_a2a",
        "envelope": envelope,
        "decoder": "payagent secret decrypt --in <envelope.json>",
    }


@app.post("/api/payments", dependencies=[Depends(require_agent_token)])
async def create_payment(payload: PaymentCreateRequest) -> dict[str, Any]:
    intent = intent_from_mapping(
        payload.model_dump(by_alias=False),
        source_agent=payload.source_agent,
    )
    task = await store.create(intent)
    asyncio.create_task(_run_task(task.id))
    return {
        "task_id": task.id,
        "session_id": task.id,
        "status": task.status,
        "psl": task.psl,
        "events_url": f"/events?session_id={task.id}",
        "workspace_id": task.workspace_id,
        "subagent_session_id": task.subagent_session_id,
        "site_id": task.site_id,
        "user_id": task.user_id,
        "a2a_task": _as_a2a_task(task),
    }


@app.post("/message:send", dependencies=[Depends(require_agent_token)])
async def message_send(payload: dict[str, Any]) -> dict[str, Any]:
    message = payload.get("message", payload)
    intent = intent_from_a2a_message(message)
    task = await store.create(intent)
    asyncio.create_task(_run_task(task.id))
    return _as_a2a_task(task)


@app.post("/message:stream", dependencies=[Depends(require_agent_token)])
async def message_stream(payload: dict[str, Any]) -> StreamingResponse:
    message = payload.get("message", payload)
    intent = intent_from_a2a_message(message)
    task = await store.create(intent)
    asyncio.create_task(_run_task(task.id))
    return StreamingResponse(_sse_generator(task.id), media_type="text/event-stream")


@app.get("/tasks/{task_id}", dependencies=[Depends(require_agent_token)])
async def task_get(task_id: str) -> dict[str, Any]:
    task = await store.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="task not found")
    return _as_a2a_task(task)


@app.post("/tasks/{task_id}:subscribe", dependencies=[Depends(require_agent_token)])
async def task_subscribe(
    task_id: str,
    after: int | None = None,
    replay: str | None = None,
) -> StreamingResponse:
    if await store.get(task_id) is None:
        raise HTTPException(status_code=404, detail="task not found")
    return StreamingResponse(
        _sse_generator(task_id, after_sequence=after, replay=replay != "0"),
        media_type="text/event-stream",
    )


@app.post("/a2a", dependencies=[Depends(require_agent_token)])
async def json_rpc_compat(payload: dict[str, Any]) -> JSONResponse:
    method = str(payload.get("method", ""))
    request_id = payload.get("id")
    params = payload.get("params") or {}
    try:
        if method in {"message/send", "tasks/send"}:
            message = params.get("message", params)
            intent = intent_from_a2a_message(message)
            task = await store.create(intent)
            asyncio.create_task(_run_task(task.id))
            result = _as_a2a_task(task)
        elif method in {"tasks/get", "task/get"}:
            task_id = params.get("id") or params.get("taskId")
            task = await store.get(task_id)
            if task is None:
                raise ValueError("task not found")
            result = _as_a2a_task(task)
        else:
            raise ValueError(f"unsupported method: {method}")
        return JSONResponse({"jsonrpc": "2.0", "id": request_id, "result": result})
    except Exception as exc:
        return JSONResponse(
            {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32602, "message": str(exc)},
            },
            status_code=400,
        )


@app.post("/psl:parse", dependencies=[Depends(require_agent_token)])
async def psl_parse(payload: dict[str, Any]) -> dict[str, Any]:
    intent = intent_from_text(str(payload.get("text", "")), source_agent="psl")
    return {"intent": intent.model_dump(mode="json"), "psl": to_psl(intent)}


@app.get("/events")
async def events(
    session_id: str | None = None,
    user_id: str | None = None,
    after: int | None = None,
    replay: str | None = None,
) -> StreamingResponse:
    if not session_id:
        return StreamingResponse(
            _empty_dashboard_sse_generator(session_id),
            media_type="text/event-stream",
        )
    task = await store.get(session_id, user_id=user_id)
    if task is None:
        task = await store.find_by_tx_id(session_id, user_id=user_id)
    if task is not None:
        _assert_user_scope_for_scoped_session(
            task,
            user_id=user_id,
            route_name="events stream",
        )
        return StreamingResponse(
            _sse_generator(task.id, after_sequence=after, replay=replay != "0"),
            media_type="text/event-stream",
        )
    scoped_candidate = await store.get(session_id)
    if scoped_candidate is None:
        scoped_candidate = await store.find_by_tx_id(session_id)
    if scoped_candidate is None:
        return StreamingResponse(
            _empty_dashboard_sse_generator(session_id),
            media_type="text/event-stream",
        )
    _assert_user_scope_for_scoped_session(
        scoped_candidate,
        user_id=user_id,
        route_name="events stream",
    )
    raise HTTPException(status_code=404, detail=f"session not found: {session_id}")


def _payagent_plugin_files() -> list[Path]:
    if not PLUGIN_ROOT.exists():
        raise HTTPException(status_code=404, detail="PayAgent plugin is not installed on server")
    ignored_dirs = {"__pycache__", ".pytest_cache", "dist", "build"}
    files: list[Path] = []
    for path in sorted(PLUGIN_ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(PLUGIN_ROOT)
        if any(part in ignored_dirs for part in rel.parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        files.append(path)
    return files


@app.get("/api/payagent/install.py")
async def payagent_install_script(request: Request) -> Response:
    install_path = PLUGIN_ROOT / "install.py"
    if not install_path.exists():
        raise HTTPException(status_code=404, detail="PayAgent installer is not installed on server")
    plugin_zip_url = f"{_public_base_url(request)}/api/payagent/plugin.zip"
    bootstrap_url = f"{_public_base_url(request)}/api/payagent/bootstrap"
    text = install_path.read_text(encoding="utf-8").replace(
        f'REPO_ZIP_URL = "{PLUGIN_INSTALL_FALLBACK_ZIP_URL}"',
        f'REPO_ZIP_URL = "{plugin_zip_url}"',
    ).replace(
        'DEFAULT_CONFIG_URL = "https://clawhunt.store/api/pay-switch/config"',
        f'DEFAULT_CONFIG_URL = "{_public_base_url(request)}/api/payagent/config"',
    ).replace(
        'DEFAULT_PANEL_URL = "https://clawhunt.store/pay-switch"',
        f'DEFAULT_PANEL_URL = "{_public_base_url(request)}"',
    ).replace(
        'DEFAULT_BOOTSTRAP_URL = ""',
        f'DEFAULT_BOOTSTRAP_URL = "{bootstrap_url}"',
    )
    return Response(
        text,
        media_type="text/x-python; charset=utf-8",
        headers={"Cache-Control": "no-store"},
    )


@app.post("/api/payagent/bootstrap")
async def payagent_bootstrap(request: Request) -> dict[str, Any]:
    base = _public_base_url(request)
    token_payload = _issue_payagent_client_token()
    return {
        "schema": "pay-switch.payagent.bootstrap.v1",
        "issued_at": _now(),
        "public_url": base,
        "health_url": f"{base}/api/health",
        "rest_endpoint": f"{base}/api/payments",
        "a2a_endpoint": f"{base}/a2a",
        "events_url": f"{base}/events",
        "sessions_endpoint": f"{base}/api/sessions",
        "workspaces_endpoint": f"{base}/api/workspaces",
        "subagents_endpoint": f"{base}/api/subagents",
        "workspace_runtime_health_endpoint": f"{base}/api/workspace-runtimes/health",
        "secret_encrypt_endpoint": f"{base}/api/secrets/encrypt",
        "session_confirm_endpoint": f"{base}/api/sessions/{{session_id}}:confirm",
        "secret_envelope_schema": SECRET_ENVELOPE_SCHEMA,
        "human_gate_required": True,
        "token": token_payload["token"],
        "token_scope": token_payload["scope"],
        "token_expires_at": token_payload["expires_at"],
        "token_required": token_payload["token_required"],
    }


@app.get("/api/payagent/config")
async def payagent_config(request: Request) -> dict[str, Any]:
    base = _public_base_url(request)
    return {
        "public_url": base,
        "health_url": f"{base}/api/health",
        "a2a_endpoint": f"{base}/a2a",
        "rest_endpoint": f"{base}/api/payments",
        "agent_card_url": f"{base}/.well-known/agent-card.json",
        "events_url": f"{base}/events",
        "sessions_endpoint": f"{base}/api/sessions",
        "workspaces_endpoint": f"{base}/api/workspaces",
        "subagents_endpoint": f"{base}/api/subagents",
        "workspace_runtime_health_endpoint": f"{base}/api/workspace-runtimes/health",
        "novnc_url": _novnc_url(
            scheme=urlsplit(base).scheme or "http",
            host=urlsplit(base).hostname or "127.0.0.1",
            port=int(os.getenv("PAYSWITCH_NOVNC_PORT", "6080")),
        ),
        "payagent_bootstrap_url": f"{base}/api/payagent/bootstrap",
        "payagent_install_url": f"{base}/api/payagent/install.py",
        "payagent_plugin_zip_url": f"{base}/api/payagent/plugin.zip",
        "secret_encrypt_endpoint": f"{base}/api/secrets/encrypt",
        "session_confirm_endpoint": f"{base}/api/sessions/{{session_id}}:confirm",
        "secret_envelope_schema": SECRET_ENVELOPE_SCHEMA,
    }


@app.get("/api/payagent/plugin.zip")
async def payagent_plugin_zip() -> Response:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in _payagent_plugin_files():
            rel = path.relative_to(PLUGIN_ROOT).as_posix()
            zf.write(path, PLUGIN_ARCHIVE_PREFIX + rel)
    return Response(
        buffer.getvalue(),
        media_type="application/zip",
        headers={
            "Cache-Control": "no-store",
            "Content-Disposition": 'attachment; filename="pay-switch-agent.zip"',
        },
    )


_frontend_dist = Path(os.getenv("PAYSWITCH_FRONTEND_DIST", str(DEFAULT_FRONTEND_DIST))).resolve()
if _frontend_dist.exists():
    assets_dir = _frontend_dist / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")


@app.get("/")
async def index() -> Any:
    index_file = _frontend_dist / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return _health_payload()


@app.get("/{path:path}")
async def spa_fallback(path: str) -> Any:
    if path.startswith(("api/", "tasks/", ".well-known/")):
        raise HTTPException(status_code=404, detail="not found")
    target = _frontend_dist / path
    if target.exists() and target.is_file():
        return FileResponse(target)
    index_file = _frontend_dist / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    raise HTTPException(status_code=404, detail="frontend bundle not built")
