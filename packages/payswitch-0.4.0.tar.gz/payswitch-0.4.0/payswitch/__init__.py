"""Pay-Switch — AI Agent 支付编排工具。

让 AI Agent 学会花钱：自动完成支付流程，在关键步骤请人类确认。
"""

__version__ = "0.4.0"
