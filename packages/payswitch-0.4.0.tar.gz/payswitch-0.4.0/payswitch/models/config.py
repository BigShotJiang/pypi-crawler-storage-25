"""Pay-Switch 全局配置模型。

配置文件存储在 ~/.payswitch/config.json，首次运行自动创建默认配置。
LLM API Key 使用 base64 编码存储（MVP 阶段，后续升级为 keyring）。
"""

from __future__ import annotations

import base64
import json
import logging
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator

from payswitch.models.types import (
    BrowserControlBackend,
    ComputerUseDriver,
    DisplayMode,
    PaymentMethod,
    StepCategory,
)

logger = logging.getLogger(__name__)

# 默认配置文件目录和路径
_DEFAULT_CONFIG_DIR = Path.home() / ".payswitch"
_DEFAULT_CONFIG_FILE = _DEFAULT_CONFIG_DIR / "config.json"


class CardIdentity(BaseModel):
    """信用卡/银行卡身份信息（加密存储）。"""

    alias: str = Field(..., description="卡片别名，如 'My Visa'")
    holder_name: str = Field("", description="持卡人姓名")
    card_number: str = Field(..., description="卡号")
    expiry_month: str = Field("", description="过期月份 (MM)")
    expiry_year: str = Field("", description="过期年份 (YY/YYYY)")
    # CVV 不存储，必须由人类在支付时手动输入或现场授权


class IdentityVault(BaseModel):
    """身份凭证库，存储加密的支付信息。"""

    cards: list[CardIdentity] = Field(default_factory=list)
    # 后续可扩展支付宝/微信账号别名等


class CardInstrument(BaseModel):
    """卡号代填配置元数据。

    卡号明文不进入 config.json；这里只保存可审计、可展示的元数据。
    """

    id: str = Field(..., description="本地卡片 ID，例如 personal_visa")
    label: str = Field(..., description="展示名称，例如 Personal Visa ending 4242")
    storage: str = Field(default="keyring", description="密钥存储后端")
    secret_ref: str = Field(..., description="OS keyring/Keychain 中的 secret 引用")
    autofill_level: str = Field(default="full", description="自动填写级别：full / number_only")
    has_expiry: bool = Field(default=False, description="是否存储了有效期")
    has_cvv: bool = Field(default=False, description="是否存储了 CVV")
    has_holder_name: bool = Field(default=False, description="是否存储了持卡人姓名")
    has_billing_address: bool = Field(default=False, description="是否存储了账单地址")
    allowed_payees: list[str] = Field(default_factory=list, description="允许使用的收款方")
    max_per_transaction: float = Field(default=0.0, ge=0.0, description="单卡单笔限额")
    currency_allowlist: list[str] = Field(default_factory=list, description="允许货币列表")


class PaySwitchConfig(BaseModel):
    """Pay-Switch 全局配置，存储在 ~/.payswitch/config.json。

    所有金额单位为人民币元（CNY），超时单位为秒。
    """

    # ---- 安全限额 ----
    max_per_transaction: float = Field(
        default=500.0,
        ge=0.0,
        description="单笔交易限额（元），0 表示不限制",
    )
    daily_limit: float = Field(
        default=2000.0,
        ge=0.0,
        description="每日累计消费限额（元），0 表示不限制",
    )
    whitelist: list[str] = Field(
        default_factory=list,
        description="商户白名单（平台标识列表），空列表表示不限制",
    )
    auto_confirm_threshold: float = Field(
        default=0.0,
        ge=0.0,
        description="自动确认阈值（元），低于此金额时自动确认，0 表示关闭自动确认",
    )

    # ---- 支付策略 ----
    payment_priority: list[PaymentMethod] = Field(
        default_factory=lambda: [
            PaymentMethod.alipay_qr,
            PaymentMethod.wechat_qr,
            PaymentMethod.card_number_only,
            PaymentMethod.virtual_card,
            PaymentMethod.stripe,
        ],
        description="支付方式优先级列表，从前到后尝试",
    )
    disabled_payment_methods: list[PaymentMethod] = Field(
        default_factory=list,
        description="全局禁用的支付方式",
    )
    allow_card_number_only: bool = Field(
        default=False,
        description="是否允许 Pay-Switch 在人工确认后仅代填卡号",
    )
    allow_virtual_card: bool = Field(
        default=False,
        description="是否允许虚拟卡全字段自动填写",
    )
    require_human_for_expiry: bool = Field(
        default=False,
        description="有效期是否必须由用户填写（虚拟卡场景默认自动填）",
    )
    require_human_for_cvv: bool = Field(
        default=False,
        description="CVV/CVC 是否必须由用户填写（虚拟卡场景默认自动填）",
    )
    require_human_for_otp: bool = Field(
        default=True,
        description="短信/邮箱 OTP 和 3DS 必须由用户处理",
    )
    require_human_for_final_confirm: bool = Field(
        default=True,
        description="最终付款确认必须由用户完成",
    )
    card_instruments: list[CardInstrument] = Field(
        default_factory=list,
        description="已配置的卡号代填工具元数据，不含卡号明文",
    )

    # ---- 身份凭证（加密存储） ----
    vault: IdentityVault = Field(
        default_factory=IdentityVault,
        description="身份凭证库（加密存储，读取时需解密）",
    )

    # ---- 货币与语言 ----
    default_currency: str = Field(
        default="CNY",
        description="默认结算货币（ISO 4217 代码）",
    )

    # ---- LLM 后端（smart 模式使用） ----
    llm_provider: str = Field(
        default="openai",
        description="LLM 服务提供商标识（openai / anthropic 等）",
    )
    llm_api_key: str = Field(
        default="",
        description="LLM API Key（base64 编码存储，读取时自动解码）",
    )
    llm_model: str = Field(
        default="gpt-4o",
        description="LLM 模型名称",
    )

    # ---- Stripe 支付通道配置 ----
    stripe_secret_key: str = Field(
        default="",
        description="Stripe Secret Key（base64 编码存储，sk_test_... 或 sk_live_...）",
    )
    stripe_webhook_secret: str = Field(
        default="",
        description="Stripe Webhook Signing Secret（base64 编码存储，whsec_...）",
    )
    stripe_webhook_port: int = Field(
        default=4242,
        ge=1024,
        le=65535,
        description="Stripe Webhook 监听端口",
    )
    stripe_default_currency: str = Field(
        default="usd",
        description="Stripe 默认货币（ISO 4217 代码，如 usd / cny / hkd）",
    )

    # ---- Computer Use（未知站点兜底探索）----
    computer_use_enabled: bool = Field(
        default=True,
        description="是否启用 Computer Use 作为未知站点/脚本失败时的兜底探索能力",
    )
    computer_use_driver: ComputerUseDriver = Field(
        default=ComputerUseDriver.hybrid,
        description="Computer Use 推理来源：external / internal / hybrid",
    )
    computer_use_max_autonomous_category: StepCategory = Field(
        default=StepCategory.checkout_prep,
        description="Computer Use 可自动推进的最高步骤类别，敏感/最终授权必须交给人类闸门",
    )
    browser_control_backend: BrowserControlBackend = Field(
        default=BrowserControlBackend.auto,
        description=(
            "浏览器控制后端：auto / cdp / ephemeral_cdp_mirror / "
            "user_profile / managed_profile。"
            "auto 会优先连接 CDP；绑定真实 profile 时会复用匹配 CDP，"
            "未被其他 Chrome 接管时才启动该 profile 的 CDP，最后使用自管 profile。"
        ),
    )

    # ---- 用户 Chrome 上下文（真实日常 Profile / 已打开浏览器）----
    chrome_cdp_url: str = Field(
        default="",
        description=(
            "已有 Chrome 的 remote-debugging 地址。设置后 Payswitch 将连接该浏览器，"
            "而不是启动自管 Chromium；未设置但已绑定 profile 时，运行时会自动复用或"
            "启动匹配 profile 的 CDP。示例：http://127.0.0.1:9222"
        ),
    )
    chrome_user_data_dir: str = Field(
        default="",
        description=(
            "Chrome User Data 目录。推荐使用 Pay-Switch 专用持久目录 "
            "~/.payswitch/browser/chrome-user-data；也可以显式绑定用户日常 "
            "Chrome profile 根目录。"
        ),
    )
    chrome_profile_directory: str = Field(
        default="",
        description="Chrome profile 子目录名，例如 Default / Profile 1 / Profile 2。",
    )
    chrome_expected_profile_email: str = Field(
        default="",
        description="期望使用的 Chrome profile 登录邮箱。设置后启动前会校验，避免接错 profile。",
    )
    browser_channel: str = Field(
        default="chrome",
        description="Playwright 浏览器 channel。真实 Chrome profile 默认使用 chrome。",
    )

    # ---- 浏览器 Engine（playwright 或 cloakbrowser）----
    browser_engine: str = Field(
        default="playwright",
        description=(
            "浏览器 engine：“playwright”（默认，原生 Chromium）或 “cloakbrowser”。"
            "CloakBrowser 是 Chromium 源码级指纹 patch，能过 Cloudflare Turnstile / "
            "reCAPTCHA v3 / FingerprintJS 等反爬检测，需 pip install 'payswitch[cloak]'。"
        ),
    )
    browser_humanize: bool = Field(
        default=False,
        description=(
            "是否启用人类行为模拟（贝塞尔鼠标曲线 + 真人键盘节奏 + 自然滚动）。"
            "仅 browser_engine=cloakbrowser 时有效。"
        ),
    )
    browser_human_preset: str = Field(
        default="default",
        description=(
            "CloakBrowser humanize 预设：“default”或 “careful”（更慢更深思熟虑，"
            "适合高额支付场景）。仅 browser_humanize=True 时有效。"
        ),
    )

    # ---- 显示与远程访问 ----
    display_mode: DisplayMode | None = Field(
        default=None,
        description="浏览器显示模式，None 表示自动检测（有显示器用 headed，否则用 novnc）",
    )
    novnc_port: int = Field(
        default=6080,
        ge=1024,
        le=65535,
        description="noVNC Web 界面监听端口",
    )

    # ---- 超时与重试 ----
    transaction_timeout: int = Field(
        default=300,
        ge=30,
        description="单笔交易最大等待时间（秒）",
    )
    recovery_max_attempts: int = Field(
        default=2,
        ge=0,
        description="脚本失败后允许进入恢复路径的最大次数（含首次失败）",
    )
    recovery_context_ttl_seconds: int = Field(
        default=300,
        ge=30,
        description="恢复上下文保留时长（秒，默认 5 分钟）；超过后丢弃旧遥测并触发同步检查点",
    )
    recovery_telemetry_buffer_size: int = Field(
        default=12,
        ge=1,
        description="每个交易保留的最近失败上下文数量（用于恢复与回溯）",
    )
    recovery_max_computer_use_steps: int = Field(
        default=8,
        ge=1,
        description="单次恢复可执行的 Computer Use 最大步骤数",
    )
    recovery_max_computer_use_screenshots: int = Field(
        default=3,
        ge=1,
        description="单次恢复允许保留的最大截图数量",
    )
    recovery_max_computer_use_model_tokens: int = Field(
        default=4000,
        ge=256,
        description="单次恢复允许消耗的模型输出 token 上限（上界估算）",
    )
    recovery_max_computer_use_step_output_tokens: int = Field(
        default=500,
        ge=64,
        description="Computer Use 每一步允许请求的最大模型输出 token",
    )
    recovery_max_computer_use_wall_time_seconds: int = Field(
        default=90,
        ge=1,
        description="单次恢复允许占用的最大 wall time（秒）",
    )
    transaction_max_screenshots: int = Field(
        default=5,
        ge=1,
        description="单笔交易允许持久化的最大截图数量（跨 adapter/recovery/external 共享）",
    )
    artifact_public_retention_hours: int = Field(
        default=24,
        ge=1,
        description="public 级 artifact 的默认保留时长（小时）",
    )
    artifact_internal_retention_hours: int = Field(
        default=168,
        ge=1,
        description="internal 级 artifact 的默认保留时长（小时）",
    )
    artifact_sensitive_retention_hours: int = Field(
        default=72,
        ge=1,
        description="sensitive 级 artifact 的默认保留时长（小时）",
    )

    # ---- 数据存储 ----
    data_dir: Path = Field(
        default_factory=lambda: _DEFAULT_CONFIG_DIR,
        description="数据目录，存放数据库和浏览器 Profile",
    )

    @field_validator("data_dir", mode="before")
    @classmethod
    def _coerce_data_dir(cls, v: Any) -> Path:
        """将字符串路径转换为 Path 对象，并展开用户目录 (~)。"""
        return Path(v).expanduser() if not isinstance(v, Path) else v.expanduser()

    @field_validator("browser_engine", mode="before")
    @classmethod
    def _validate_browser_engine(cls, v: Any) -> str:
        """限制 browser_engine 只能是 playwright / cloakbrowser。"""
        if not isinstance(v, str):
            raise ValueError(f"browser_engine 必须是字符串，当前：{type(v).__name__}")
        normalized = v.strip().lower()
        if normalized not in {"playwright", "cloakbrowser"}:
            raise ValueError(f"browser_engine 不支持 {v!r}，可选值：playwright / cloakbrowser")
        return normalized

    @field_validator("browser_human_preset", mode="before")
    @classmethod
    def _validate_browser_human_preset(cls, v: Any) -> str:
        """CloakBrowser humanize preset 只支持 default / careful。"""
        if not isinstance(v, str):
            raise ValueError(f"browser_human_preset 必须是字符串，当前：{type(v).__name__}")
        normalized = v.strip().lower()
        if normalized not in {"default", "careful"}:
            raise ValueError(f"browser_human_preset 不支持 {v!r}，可选值：default / careful")
        return normalized

    @field_validator("payment_priority", "disabled_payment_methods", mode="before")
    @classmethod
    def _coerce_legacy_payment_methods(cls, v: Any) -> Any:
        """兼容旧配置中的 cc_autofill 命名，同时映射到 card_number_only 和 virtual_card。"""
        if isinstance(v, list):
            result: list[str] = []
            for item in v:
                if item == "cc_autofill":
                    result.append(PaymentMethod.card_number_only.value)
                    if PaymentMethod.virtual_card.value not in result:
                        result.append(PaymentMethod.virtual_card.value)
                else:
                    result.append(item)
            return result
        return v

    # ------------------------------------------------------------------
    # 类方法：加载 / 保存 / 更新
    # ------------------------------------------------------------------

    @classmethod
    def load(cls, config_path: Path = _DEFAULT_CONFIG_FILE) -> PaySwitchConfig:
        """从 JSON 文件加载配置。

        若文件不存在，自动创建包含默认值的配置文件并返回默认配置。

        Args:
            config_path: 配置文件路径，默认 ~/.payswitch/config.json

        Returns:
            PaySwitchConfig 实例
        """
        if not config_path.exists():
            logger.info("配置文件不存在，创建默认配置：%s", config_path)
            instance = cls()
            instance.save(config_path)
            return instance

        try:
            raw = json.loads(config_path.read_text(encoding="utf-8"))
            return cls.model_validate(raw)
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning("配置文件解析失败（%s），使用默认配置：%s", e, config_path)
            return cls()

    def save(self, config_path: Path = _DEFAULT_CONFIG_FILE) -> None:
        """将当前配置序列化为 JSON 并写入文件。

        自动创建父目录（若不存在）。

        Args:
            config_path: 配置文件路径，默认 ~/.payswitch/config.json
        """
        config_path.parent.mkdir(parents=True, exist_ok=True)
        # 将 Path 对象转换为字符串以便 JSON 序列化
        data = self.model_dump(mode="json")
        data["data_dir"] = str(self.data_dir)
        config_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        logger.debug("配置已保存：%s", config_path)

    def update(self, **kwargs: Any) -> PaySwitchConfig:
        """返回一个更新了指定字段的新配置实例，同时写入磁盘。

        Args:
            **kwargs: 要更新的字段名及新值

        Returns:
            更新后的新 PaySwitchConfig 实例
        """
        data = self.model_dump(mode="python")
        data.update(kwargs)
        updated = type(self).model_validate(data)
        updated.save()
        return updated

    # ------------------------------------------------------------------
    # API Key 辅助方法（base64 编解码）
    # ------------------------------------------------------------------

    def get_llm_api_key(self) -> str:
        """解码并返回明文 LLM API Key。

        Returns:
            明文 API Key 字符串，若未设置则返回空字符串
        """
        if not self.llm_api_key:
            return ""
        try:
            return base64.b64decode(self.llm_api_key.encode()).decode("utf-8")
        except Exception:
            # 若解码失败，可能是旧版明文存储，直接返回
            return self.llm_api_key

    def set_llm_api_key(self, plaintext_key: str) -> PaySwitchConfig:
        """编码 API Key 并保存配置。

        Args:
            plaintext_key: 明文 API Key

        Returns:
            更新后的新 PaySwitchConfig 实例
        """
        encoded = base64.b64encode(plaintext_key.encode("utf-8")).decode("ascii")
        return self.update(llm_api_key=encoded)

    # ------------------------------------------------------------------
    # Stripe API Key 辅助方法
    # ------------------------------------------------------------------

    def get_stripe_secret_key(self) -> str:
        """解码并返回明文 Stripe Secret Key。

        Returns:
            明文 Stripe Secret Key，若未设置则返回空字符串
        """
        if not self.stripe_secret_key:
            return ""
        try:
            return base64.b64decode(self.stripe_secret_key.encode()).decode("utf-8")
        except Exception:
            # 若解码失败，可能是旧版明文存储，直接返回
            return self.stripe_secret_key

    def set_stripe_secret_key(self, plaintext_key: str) -> PaySwitchConfig:
        """编码 Stripe Secret Key 并保存配置。

        Args:
            plaintext_key: 明文 Stripe Secret Key

        Returns:
            更新后的新 PaySwitchConfig 实例
        """
        encoded = base64.b64encode(plaintext_key.encode("utf-8")).decode("ascii")
        return self.update(stripe_secret_key=encoded)

    def get_stripe_webhook_secret(self) -> str:
        """解码并返回明文 Stripe Webhook Secret。

        Returns:
            明文 Webhook Secret，若未设置则返回空字符串
        """
        if not self.stripe_webhook_secret:
            return ""
        try:
            return base64.b64decode(self.stripe_webhook_secret.encode()).decode("utf-8")
        except Exception:
            return self.stripe_webhook_secret

    def set_stripe_webhook_secret(self, plaintext_secret: str) -> PaySwitchConfig:
        """编码 Stripe Webhook Secret 并保存配置。

        Args:
            plaintext_secret: 明文 Webhook Secret

        Returns:
            更新后的新 PaySwitchConfig 实例
        """
        encoded = base64.b64encode(plaintext_secret.encode("utf-8")).decode("ascii")
        return self.update(stripe_webhook_secret=encoded)
