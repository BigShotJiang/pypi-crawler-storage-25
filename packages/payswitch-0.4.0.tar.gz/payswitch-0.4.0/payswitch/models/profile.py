"""Pay-Switch 平台 Profile 元数据模型。

每个已登录的支付平台对应一个 PlatformProfile，
记录浏览器持久化目录路径、登录时间和当前状态。
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class PlatformProfile(BaseModel):
    """已登录平台的 Profile 元数据。

    Profile 数据持久化存储在 ~/.payswitch/profiles/<platform>/metadata.json，
    浏览器会话数据存储在 profile_dir 指定的目录下。
    """

    # ---- 平台标识 ----
    platform: str = Field(
        description="平台唯一标识符（小写字母+数字），如 deepseek / kimi / zhipu",
    )
    display_name: str = Field(
        description="平台展示名称，如 DeepSeek / Kimi / 智谱 AI",
    )

    # ---- 文件系统路径 ----
    profile_dir: Path = Field(
        description="Playwright persistent context 数据目录路径",
    )

    # ---- 时间戳 ----
    logged_in_at: datetime | None = Field(
        default=None,
        description="最近一次成功登录的 UTC 时间",
    )
    last_used_at: datetime | None = Field(
        default=None,
        description="最近一次使用该 Profile 的 UTC 时间",
    )

    # ---- 状态 ----
    status: Literal["active", "expired", "unknown"] = Field(
        default="unknown",
        description="Profile 当前状态：active=有效 / expired=已过期 / unknown=未验证",
    )

    # ---- 平台特定配置 ----
    top_up_url: str | None = Field(
        default=None,
        description="平台充值页面 URL，供适配器导航使用",
    )

    @field_validator("profile_dir", mode="before")
    @classmethod
    def _coerce_profile_dir(cls, v: object) -> Path:
        """将字符串路径转换为 Path 对象并展开用户目录。"""
        return Path(str(v)).expanduser()

    @field_validator("platform")
    @classmethod
    def _validate_platform(cls, v: str) -> str:
        """确保平台标识符只包含小写字母、数字和下划线。"""
        import re
        if not re.match(r"^[a-z0-9_]+$", v):
            raise ValueError(
                f"平台标识符只能包含小写字母、数字和下划线，当前值：{v!r}"
            )
        return v

    def is_active(self) -> bool:
        """返回该 Profile 是否处于有效状态。"""
        return self.status == "active"

    def mark_used(self) -> PlatformProfile:
        """返回更新了 last_used_at 的新实例。"""
        return self.model_copy(update={"last_used_at": datetime.now(UTC)})

    def mark_expired(self) -> PlatformProfile:
        """返回标记为已过期状态的新实例。"""
        return self.model_copy(update={"status": "expired"})
