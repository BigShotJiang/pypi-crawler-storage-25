"""Pay-Switch 交易记录数据模型。

Transaction 是一次完整支付编排的记录，包含执行步骤（StepRecord）
和人类介入记录（HumanAction）。所有时间字段使用 UTC。
"""

from __future__ import annotations

import secrets
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from payswitch.models.types import (
    DisplayMode,
    ExecutionMode,
    PaymentMethod,
    StepCategory,
    StepRisk,
    TransactionStatus,
)


def _generate_tx_id() -> str:
    """生成唯一交易 ID，格式：txn_ + 12 位随机十六进制字符串。"""
    return f"txn_{secrets.token_hex(6)}"


def _utc_now() -> datetime:
    """返回当前 UTC 时间（含时区信息）。"""
    return datetime.now(UTC)


class ScreenshotBudgetState(BaseModel):
    """Transaction-level screenshot budget state."""

    limit: int = Field(ge=1, description="单笔交易允许持久化的最大截图数量")
    used: int = Field(default=0, ge=0, description="当前已持久化的截图数量")
    remaining: int = Field(default=0, ge=0, description="当前剩余可持久化的截图数量")
    exhausted: bool = Field(default=False, description="截图预算是否已耗尽")
    exhausted_at: datetime | None = Field(
        default=None,
        description="截图预算耗尽时间（UTC）",
    )
    exhaustion_reason: str | None = Field(
        default=None,
        description="截图预算耗尽或阻断时的人类可读原因",
    )
    last_capture_reason: str | None = Field(
        default=None,
        description="最近一次截图写入或拦截的业务原因",
    )
    last_artifact_kind: str | None = Field(
        default=None,
        description="最近一次截图对应的 artifact kind",
    )
    last_artifact_path: str | None = Field(
        default=None,
        description="最近一次截图对应的 artifact 路径",
    )


class TransactionBudgetState(BaseModel):
    """Budget state persisted alongside a transaction."""

    screenshots: ScreenshotBudgetState | None = Field(
        default=None,
        description="截图预算状态",
    )


class StepRecord(BaseModel):
    """单个执行步骤的记录。

    按顺序记录支付流程中每一个自动化操作步骤的执行情况。
    """

    # 步骤序号（从 0 开始）
    step_index: int = Field(ge=0, description="步骤序号，从 0 开始递增")
    description: str = Field(description="步骤描述（中文），如 '导航到充值页面'")
    status: Literal["pending", "success", "failed", "skipped"] = Field(
        default="pending",
        description="步骤执行状态",
    )

    # 时间记录
    started_at: datetime | None = Field(default=None, description="步骤开始时间（UTC）")
    completed_at: datetime | None = Field(default=None, description="步骤完成时间（UTC）")

    # 调试信息
    screenshot_path: str | None = Field(
        default=None,
        description="该步骤截图的本地文件路径（用于调试和审计）",
    )
    category: StepCategory = Field(
        default=StepCategory.nav,
        description="步骤类别，用于标记导航、身份、付款准备、敏感信息或最终授权",
    )
    risk: StepRisk = Field(
        default=StepRisk.low,
        description="步骤风险等级，用于决定是否允许 Computer Use 自动执行",
    )
    evidence_path: str | None = Field(
        default=None,
        description="该步骤的结构化证据文件路径（json/jsonl），用于复盘和经验沉淀",
    )

    def duration_seconds(self) -> float | None:
        """计算步骤执行耗时（秒），若未完成则返回 None。"""
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


class HumanAction(BaseModel):
    """人类介入操作的记录。

    当支付流程需要人类完成敏感操作时（如扫码、输入密码），
    创建此记录并等待人类确认。
    """

    # 介入类型
    action_type: str = Field(
        description=(
            "人类需要执行的操作类型：\n"
            "  scan_qr       — 扫描支付二维码\n"
            "  fill_form     — 填写敏感表单（卡号/密码）\n"
            "  confirm       — 确认支付金额\n"
            "  takeover      — 完全接管浏览器操作"
        ),
    )

    # 时间记录
    requested_at: datetime = Field(description="请求人类介入的时间（UTC）")
    completed_at: datetime | None = Field(
        default=None,
        description="人类完成操作的时间（UTC）",
    )

    # 可视化支持
    display_mode: DisplayMode | None = Field(
        default=None,
        description="浏览器显示模式（headed=本地窗口 / novnc=远程网页）",
    )
    novnc_url: str | None = Field(
        default=None,
        description="noVNC 访问 URL（display_mode=novnc 时有效）",
    )
    guidance: str | None = Field(
        default=None,
        description="给用户的直接操作说明，尽量说明当前阻塞点和下一步该做什么",
    )
    details: dict[str, Any] | None = Field(
        default=None,
        description="结构化附加信息，例如 required_fields / options / current_url",
    )

    def is_completed(self) -> bool:
        """返回人类介入是否已完成。"""
        return self.completed_at is not None

    def waiting_seconds(self) -> float | None:
        """计算等待人类操作的耗时（秒）。"""
        if self.requested_at and self.completed_at:
            return (self.completed_at - self.requested_at).total_seconds()
        return None


class Transaction(BaseModel):
    """一次支付编排的完整记录。

    append-only 设计：创建后不允许删除，只能更新状态字段。
    tx_id 在创建时自动生成，格式为 txn_xxxxxxxxxxxx。
    """

    # ---- 唯一标识 ----
    tx_id: str = Field(
        default_factory=_generate_tx_id,
        description="交易唯一 ID，格式：txn_xxxxxxxxxxxx（自动生成）",
    )

    # ---- 支付基本信息 ----
    amount: float = Field(gt=0, description="支付金额（单位：元，必须大于 0）")
    currency: str = Field(default="CNY", description="货币代码（ISO 4217）")
    payee: str = Field(description="收款方平台标识，如 deepseek / kimi")
    reason: str = Field(default="", description="支付原因（记录用途，非必填）")

    # ---- 支付方式与执行模式 ----
    payment_method: PaymentMethod | None = Field(
        default=None,
        description="支付方式，None 表示由系统自动选择",
    )
    execution_mode: ExecutionMode | None = Field(
        default=None,
        description="执行模式，None 表示由系统自动选择",
    )

    # ---- 状态与幂等 ----
    status: TransactionStatus = Field(
        default=TransactionStatus.pending,
        description="当前交易状态",
    )
    idempotency_key: str | None = Field(
        default=None,
        description="幂等键（由调用方提供），用于防止重复支付",
    )

    # ---- 执行详情 ----
    steps: list[StepRecord] = Field(
        default_factory=list,
        description="按顺序排列的执行步骤记录列表",
    )
    human_action: HumanAction | None = Field(
        default=None,
        description="当前等待的人类介入记录（若有）",
    )
    budget_state: TransactionBudgetState | None = Field(
        default=None,
        description="交易预算状态，如截图预算消耗与耗尽原因",
    )

    # ---- 时间记录 ----
    created_at: datetime = Field(
        default_factory=_utc_now,
        description="交易创建时间（UTC）",
    )
    completed_at: datetime | None = Field(
        default=None,
        description="交易完成时间（UTC），成功或失败时设置",
    )

    # ---- 错误信息 ----
    error: str | None = Field(
        default=None,
        description="失败原因描述（status=failed 时有值）",
    )

    @field_validator("tx_id")
    @classmethod
    def _validate_tx_id(cls, v: str) -> str:
        """验证交易 ID 格式。"""
        if not v.startswith("txn_"):
            raise ValueError(f"交易 ID 必须以 'txn_' 开头，当前值：{v!r}")
        return v

    @field_validator("currency")
    @classmethod
    def _validate_currency(cls, v: str) -> str:
        """将货币代码统一转为大写。"""
        return v.upper()

    def is_terminal(self) -> bool:
        """返回当前状态是否为终态（不再变化）。"""
        return self.status in (
            TransactionStatus.completed,
            TransactionStatus.failed,
            TransactionStatus.cancelled,
            TransactionStatus.timeout,
        )

    def is_waiting_human(self) -> bool:
        """返回交易是否正在等待人类操作。"""
        return self.status == TransactionStatus.human_action_required

    def duration_seconds(self) -> float | None:
        """计算交易总耗时（秒），若未完成则返回 None。"""
        if self.created_at and self.completed_at:
            return (self.completed_at - self.created_at).total_seconds()
        return None

    def add_step(self, description: str) -> Transaction:
        """返回追加了一个新步骤的新 Transaction 实例。

        Args:
            description: 步骤描述文本（中文）

        Returns:
            包含新步骤的 Transaction 副本
        """
        new_step = StepRecord(
            step_index=len(self.steps),
            description=description,
        )
        return self.model_copy(update={"steps": [*self.steps, new_step]})
