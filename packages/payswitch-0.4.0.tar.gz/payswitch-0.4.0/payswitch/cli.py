"""Pay-Switch CLI 入口模块。

基于 Typer 定义所有命令行子命令，提供 AI Agent 支付编排的完整 CLI 接口。
"""

from __future__ import annotations

import asyncio
import io
import json
import logging
import mimetypes
import os
import subprocess
import sys
import time
from datetime import UTC
from pathlib import Path
from typing import Annotated, Any

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from payswitch import __version__
from payswitch.security.artifacts import ArtifactStore

# ---------------------------------------------------------------------------
# 在 Windows 非 UTF-8 终端下将 stdin/stdout/stderr 重新包装为 UTF-8 编码，
# 以支持 Unicode 字符（中文、符号等）正常输出。
# 必须在创建 Rich Console 之前执行。
# ---------------------------------------------------------------------------
_NON_UTF8_ENCODINGS = frozenset(
    {
        "gbk",
        "cp936",
        "cp950",
        "cp932",
        "latin-1",
        "ascii",
    }
)


def _is_non_utf8(stream) -> bool:
    """判断流的编码是否为非 UTF-8。"""
    return bool(
        stream
        and hasattr(stream, "encoding")
        and stream.encoding
        and stream.encoding.lower() in _NON_UTF8_ENCODINGS
    )


if _is_non_utf8(sys.stdout):
    sys.stdout = io.TextIOWrapper(
        sys.stdout.buffer,
        encoding="utf-8",
        errors="replace",
        line_buffering=True,
    )
if _is_non_utf8(sys.stderr):
    sys.stderr = io.TextIOWrapper(
        sys.stderr.buffer,
        encoding="utf-8",
        errors="replace",
        line_buffering=True,
    )
if hasattr(sys.stdin, "buffer") and _is_non_utf8(sys.stdin):
    sys.stdin = io.TextIOWrapper(
        sys.stdin.buffer,
        encoding="utf-8",
        errors="replace",
    )

# ---------------------------------------------------------------------------
# 全局 Rich 控制台（stderr 用于状态输出，stdout 用于结构化数据）
# ---------------------------------------------------------------------------
console = Console(stderr=False)
err_console = Console(stderr=True)

_SETTINGS_API_EVIDENCE_IMAGE_SUFFIXES = frozenset(
    {".png", ".jpg", ".jpeg", ".webp", ".svg"}
)
_SETTINGS_API_EVIDENCE_PREVIEW_SUFFIXES = (
    _SETTINGS_API_EVIDENCE_IMAGE_SUFFIXES | frozenset({".webm", ".mp4"})
)


# ---------------------------------------------------------------------------
# 全局状态容器（通过 Typer callback 注入）
# ---------------------------------------------------------------------------
class AppState:
    """保存顶级全局选项的运行时状态。"""

    json_output: bool = False
    verbose: bool = False


_state = AppState()

# ---------------------------------------------------------------------------
# 主 app
# ---------------------------------------------------------------------------
app = typer.Typer(
    name="payswitch",
    help="Pay-Switch：让 AI Agent 学会花钱的支付编排工具。",
    no_args_is_help=True,
    rich_markup_mode="rich",
    add_completion=True,
)
settings_app = typer.Typer(
    help="交互式配置浏览器 profile、Computer Use 驱动等运行时设置。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
app.add_typer(settings_app, name="settings")
payment_settings_app = typer.Typer(
    help="配置支付方式优先级和卡号代填工具。",
    no_args_is_help=False,
    rich_markup_mode="rich",
)
payment_card_app = typer.Typer(
    help="管理 card_number_only 本地卡号工具。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
payment_settings_app.add_typer(payment_card_app, name="card")
settings_app.add_typer(payment_settings_app, name="payment")

stripe_app = typer.Typer(
    help="Stripe 支付通道相关命令（启动 webhook 监听器等）。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
app.add_typer(stripe_app, name="stripe")
agent_app = typer.Typer(
    help="Pay-Switch Agent 服务、A2A 接入和 PSL 语言工具。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
app.add_typer(agent_app, name="agent")
experience_app = typer.Typer(
    help="经验配方与 recovery recipe patch 审查命令。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
experience_patch_app = typer.Typer(
    help="列出、审查、影子验证和提升 recovery recipe patch。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
experience_improvement_app = typer.Typer(
    help="查看与处理 recovery improvement queue。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
experience_app.add_typer(experience_patch_app, name="patch")
experience_app.add_typer(experience_improvement_app, name="improvement")
app.add_typer(experience_app, name="experience")
artifact_app = typer.Typer(
    help="查看和执行 artifact retention cleanup。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
app.add_typer(artifact_app, name="artifact")


def _version_callback(value: bool) -> None:
    """打印版本号后退出。"""
    if value:
        console.print(f"payswitch {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    ctx: typer.Context,
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-V",
            callback=_version_callback,
            is_eager=True,
            help="显示版本号并退出。",
        ),
    ] = None,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="以 JSON 格式输出结果（适合 Agent 程序解析）。",
            is_eager=False,
        ),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-v",
            help="启用详细日志输出（显示调试信息）。",
        ),
    ] = False,
) -> None:
    """[bold cyan]Pay-Switch[/bold cyan] — AI Agent 支付编排工具。

    让 Agent 自动完成支付流程，在关键步骤请人类确认。

    [dim]更多信息请访问：https://github.com/your-org/pay-switch[/dim]
    """
    _state.json_output = json_output
    _state.verbose = verbose

    # --verbose 时输出所有 DEBUG 及以上日志，方便排查问题；
    # 普通用户默认只看到 WARNING 及以上，减少日志噪音。
    log_level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        # 若 basicConfig 已被调用过，force=True 可强制覆盖已有配置
        force=True,
    )


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------


def _print_json(data: object) -> None:
    """将数据序列化为 JSON 并直接写入 stdout（绕过 Rich 的 Windows 渲染器）。
    使用 ensure_ascii=True 确保在任何终端编码下均可安全输出。
    """
    sys.stdout.write(json.dumps(data, ensure_ascii=True, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def _print_json_str(json_str: str) -> None:
    """将已序列化的 JSON 字符串直接写入 stdout。
    将字符串重新序列化为 ASCII-safe 格式以兼容 Windows GBK 终端。
    """
    # 重新解析并以 ASCII-safe 格式输出
    try:
        data = json.loads(json_str)
        sys.stdout.write(json.dumps(data, ensure_ascii=True, indent=2))
    except (json.JSONDecodeError, TypeError):
        sys.stdout.write(json_str)
    sys.stdout.write("\n")
    sys.stdout.flush()


def _print_error(message: str) -> None:
    """统一输出错误信息到 stderr。"""
    if _state.json_output:
        _print_json({"error": message})
    else:
        err_console.print(f"[bold red]错误：[/bold red]{message}")


def _get_status_style(status: str) -> str:
    """根据交易状态返回对应的 Rich 样式颜色。"""
    styles = {
        "completed": "green",
        "failed": "red",
        "pending": "yellow",
        "executing": "cyan",
        "human_action_required": "magenta",
        "cancelled": "dim",
        "timeout": "red",
    }
    return styles.get(status, "white")


def _get_status_label(status: str) -> str:
    """将交易状态值转换为中文标签。"""
    labels = {
        "completed": "已完成",
        "failed": "失败",
        "pending": "待处理",
        "executing": "执行中",
        "human_action_required": "等待人工",
        "cancelled": "已取消",
        "timeout": "超时",
    }
    return labels.get(status, status)


def _format_amount(amount: float, currency: str = "CNY") -> str:
    """格式化金额显示。CNY 使用 CNY 前缀（避免 Windows GBK 终端编码问题）。"""
    if currency == "CNY":
        return f"CNY {amount:.2f}"
    return f"{amount:.2f} {currency}"


def _format_datetime(dt) -> str:
    """将 datetime 对象格式化为本地时间字符串，None 时返回 '-'。"""
    if dt is None:
        return "-"
    # 转换为本地时间显示
    try:
        local_dt = dt.astimezone()
        return local_dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(dt)


def _experience_store_from_config():
    from payswitch.experience.store import ExperienceStore
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    return ExperienceStore(config.data_dir / "experience" / "recipes.db")


def _artifact_store_from_config() -> ArtifactStore:
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    return ArtifactStore(
        config.data_dir,
        public_retention_hours=config.artifact_public_retention_hours,
        internal_retention_hours=config.artifact_internal_retention_hours,
        sensitive_retention_hours=config.artifact_sensitive_retention_hours,
    )


def _resolve_patch_state(name: str | None):
    if name is None:
        return None
    from payswitch.experience.models import RecipePatchState

    try:
        return RecipePatchState(name)
    except ValueError as exc:
        allowed = ", ".join(item.value for item in RecipePatchState)
        raise typer.BadParameter(f"state must be one of: {allowed}") from exc


def _resolve_promotion_basis(name: str | None) -> str | None:
    if name is None:
        return None
    allowed = {"reviewed", "shadow_run_success"}
    if name not in allowed:
        raise typer.BadParameter(
            f"basis must be one of: {', '.join(sorted(allowed))}"
        )
    return name


def _resolve_improvement_status(name: str | None):
    if name is None:
        return None
    from payswitch.experience.models import RecoveryImprovementStatus

    try:
        return RecoveryImprovementStatus(name)
    except ValueError as exc:
        allowed = ", ".join(item.value for item in RecoveryImprovementStatus)
        raise typer.BadParameter(f"status must be one of: {allowed}") from exc


def _resolve_improvement_acceptance_basis(name: str) -> str:
    allowed = {"reviewed", "shadow_run_success"}
    if name not in allowed:
        raise typer.BadParameter(
            f"basis must be one of: {', '.join(sorted(allowed))}"
        )
    return name


# ---------------------------------------------------------------------------
# settings — 交互式配置真实浏览器上下文和 Computer Use 模式
# ---------------------------------------------------------------------------
@settings_app.command("wizard")
def settings_wizard(
    browser: Annotated[
        str | None,
        typer.Option(
            "--browser",
            help=(
                "浏览器类型：chrome / chromium / firefox。"
                "当前 profile 发现主路径支持 chrome/chromium。"
            ),
        ),
    ] = None,
    profile_query: Annotated[
        str | None,
        typer.Option(
            "--profile-query",
            "-q",
            help="按邮箱、昵称、用户名或 profile 目录过滤。",
        ),
    ] = None,
    profile_index: Annotated[
        int | None,
        typer.Option(
            "--profile-index",
            min=1,
            help="非交互选择第 N 个过滤后的 profile。",
        ),
    ] = None,
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="使用推荐默认值：第一个匹配 profile、external、checkout_prep。",
        ),
    ] = False,
    clear_cdp: Annotated[
        bool,
        typer.Option(
            "--clear-cdp",
            help="清空已有 chrome_cdp_url；默认保留，适合继续连接已打开的 Chrome。",
        ),
    ] = False,
) -> None:
    """配置引导页：先选浏览器，再选 profile，然后设置 Computer Use。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import (
        BrowserControlBackend,
        ComputerUseDriver,
        StepCategory,
    )

    config = PaySwitchConfig.load()

    if not _state.json_output:
        _print_wizard_intro()

    selected_browser = browser.strip().lower() if browser else None
    if selected_browser is None:
        if yes:
            selected_browser = "chrome"
        else:
            _print_browser_explainer()
            default_browser = (
                config.browser_channel
                if config.browser_channel in {"chrome", "chromium"}
                else "chrome"
            )
            selected_browser = _prompt_choice(
                "选择要启用的浏览器",
                ["chrome", "chromium", "firefox"],
                default=default_browser,
            )
    _validate_profile_browser(selected_browser)

    selected_profile_query = profile_query
    if selected_profile_query is None and not yes:
        _print_profile_explainer(selected_browser, config.chrome_expected_profile_email)
        selected_profile_query = (
            typer.prompt(
                "可选：输入关键词缩小列表，直接回车显示全部",
                default="",
                show_default=False,
            ).strip()
            or None
        )

    selected_index = profile_index
    if selected_index is None and yes:
        selected_index = 1

    settings_profile(
        browser=selected_browser,
        user_data_dir=None,
        list_only=False,
        query=selected_profile_query,
        index=selected_index,
        keep_cdp=not clear_cdp,
    )

    config = PaySwitchConfig.load()
    if yes:
        backend = BrowserControlBackend.auto.value
    else:
        _print_browser_backend_explainer()
        backend = _prompt_choice(
            "浏览器接管方式",
            [item.value for item in BrowserControlBackend],
            default=config.browser_control_backend.value,
        )
    settings_browser_backend(backend=backend)

    config = PaySwitchConfig.load()
    if yes:
        driver = ComputerUseDriver.external.value
        max_category = StepCategory.checkout_prep.value
        enable = True
    else:
        _print_computer_use_explainer()
        driver = _prompt_choice(
            "页面操作由谁驱动",
            [item.value for item in ComputerUseDriver],
            default=config.computer_use_driver.value,
        )
        _print_autonomy_explainer()
        max_category = _prompt_choice(
            "允许自动走到哪一步",
            [item.value for item in StepCategory],
            default=config.computer_use_max_autonomous_category.value,
        )
        enable = typer.confirm(
            "是否启用 Computer Use 兜底能力？",
            default=config.computer_use_enabled,
        )

    settings_computer_use(
        driver=driver,
        max_category=max_category,
        enable=enable,
        disable=not enable,
    )

    updated = PaySwitchConfig.load()
    if _state.json_output:
        _print_json(
            {
                "browser": selected_browser,
                "chrome_user_data_dir": updated.chrome_user_data_dir,
                "chrome_profile_directory": updated.chrome_profile_directory,
                "chrome_expected_profile_email": updated.chrome_expected_profile_email,
                "chrome_cdp_url": updated.chrome_cdp_url,
                "browser_control_backend": updated.browser_control_backend.value,
                "computer_use_enabled": updated.computer_use_enabled,
                "computer_use_driver": updated.computer_use_driver.value,
                "computer_use_max_autonomous_category": (
                    updated.computer_use_max_autonomous_category.value
                ),
            }
        )
        return

    console.print(
        Panel(
            "[green]配置引导完成[/green]\n\n"
            f"Browser: {selected_browser}\n"
            f"Profile: {updated.chrome_expected_profile_email or '<未识别邮箱>'} "
            f"({updated.chrome_profile_directory or '<未设置>'})\n"
            f"Browser Backend: {updated.browser_control_backend.value}\n"
            f"Computer Use: {updated.computer_use_driver.value} / "
            f"{updated.computer_use_max_autonomous_category.value}\n\n"
            "下一步可运行：\n"
            "  uv run payswitch spend 1 nineemail --reason "
            '"smoke dry run checkout" --dry-run --method alipay_qr\n\n'
            "[dim]这条命令只做模拟，不会真实支付。真正付款前，"
            "Pay-Switch 会在二维码、CVV、验证码、付款确认等位置停下来等你。[/dim]",
            title="Ready",
            border_style="green",
        )
    )


@settings_app.command("profile")
def settings_profile(
    browser: Annotated[
        str,
        typer.Option(
            "--browser",
            help="浏览器类型：chrome / chromium。目前主路径是 chrome。",
        ),
    ] = "chrome",
    user_data_dir: Annotated[
        Path | None,
        typer.Option(
            "--user-data-dir",
            help="Chrome User Data 根目录；留空则自动扫描本机默认目录。",
        ),
    ] = None,
    list_only: Annotated[
        bool,
        typer.Option("--list-only", help="只列出可选 profile，不写入配置。"),
    ] = False,
    query: Annotated[
        str | None,
        typer.Option(
            "--query",
            "-q",
            help="按邮箱、昵称、用户名或 profile 目录过滤。",
        ),
    ] = None,
    index: Annotated[
        int | None,
        typer.Option(
            "--index",
            min=1,
            help="非交互选择第 N 个 profile，适合脚本/测试。",
        ),
    ] = None,
    keep_cdp: Annotated[
        bool,
        typer.Option(
            "--keep-cdp",
            help="保留已有 chrome_cdp_url；默认选择真实 profile 后清空 CDP 地址。",
        ),
    ] = False,
) -> None:
    """发现本机 Chrome profiles，并选择一个作为真实支付浏览器上下文。

    这个命令会同时展示 Chrome 的 profile 子目录名、邮箱、昵称/用户名。
    保存后，Pay-Switch 运行浏览器链路时会优先使用这个用户指定的真实
    Chrome profile，而不是新建空白 Chromium。
    """
    from payswitch.browser.chrome_profiles import (
        discover_chrome_user_data_dirs,
        find_active_chrome_user_data_process,
        list_profile_identities,
    )
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import BrowserControlBackend

    browser = browser.strip().lower()
    _validate_profile_browser(browser)

    roots = (
        [Path(user_data_dir).expanduser()]
        if user_data_dir
        else (discover_chrome_user_data_dirs(browser))
    )
    profiles = []
    for root in roots:
        profiles.extend(list_profile_identities(root))
    if query:
        needle = query.strip().lower()
        profiles = [
            profile
            for profile in profiles
            if needle in profile.profile_directory.lower()
            or needle in profile.user_name.lower()
            or needle in profile.name.lower()
            or needle in profile.gaia_name.lower()
            or needle in profile.gaia_given_name.lower()
        ]

    if _state.json_output:
        _print_json(
            [
                {
                    "index": position,
                    "user_data_dir": str(profile.user_data_dir),
                    "profile_directory": profile.profile_directory,
                    "email": profile.user_name,
                    "name": profile.name,
                    "gaia_name": profile.gaia_name,
                    "gaia_given_name": profile.gaia_given_name,
                    "is_consented_primary_account": (profile.is_consented_primary_account),
                    "active_time": profile.active_time,
                }
                for position, profile in enumerate(profiles, start=1)
            ]
        )
        if list_only:
            return

    if not profiles:
        searched = ", ".join(str(root) for root in roots) or "默认 Chrome 目录"
        _print_error(f"没有发现可用 Chrome profile。已搜索：{searched}")
        raise typer.Exit(code=1)

    if not _state.json_output:
        _print_profile_table(profiles, browser)

    if list_only:
        return

    selected_index = index
    if selected_index is None:
        selected_index = typer.prompt(
            "请选择要绑定的 profile 序号",
            type=int,
            default=1,
        )

    if selected_index < 1 or selected_index > len(profiles):
        _print_error(f"profile 序号超出范围：{selected_index}")
        raise typer.Exit(code=1)

    selected = profiles[selected_index - 1]
    updates = {
        "browser_control_backend": BrowserControlBackend.cdp.value,
        "browser_channel": "chrome" if browser == "chrome" else browser,
        "chrome_user_data_dir": str(selected.user_data_dir),
        "chrome_profile_directory": selected.profile_directory,
        "chrome_expected_profile_email": selected.user_name,
    }
    if not keep_cdp:
        updates["chrome_cdp_url"] = ""

    config = PaySwitchConfig.load().update(**updates)

    if _state.json_output:
        _print_json(
            {
                "updated": updates,
                "selected": {
                    "user_data_dir": str(selected.user_data_dir),
                    "profile_directory": selected.profile_directory,
                    "email": selected.user_name,
                    "name": selected.name,
                    "gaia_name": selected.gaia_name,
                },
                "chrome_cdp_url": config.chrome_cdp_url,
            }
        )
        return

    console.print("[green]OK[/green] 已绑定真实 Chrome profile：")
    console.print(f"  [bold]目录[/bold] {selected.user_data_dir} / {selected.profile_directory}")
    console.print(
        f"  [bold]身份[/bold] "
        f"{selected.user_name or selected.gaia_name or selected.name or '未识别'}"
    )
    if keep_cdp and config.chrome_cdp_url:
        console.print(f"  [bold]CDP[/bold] 保留 {config.chrome_cdp_url}")
    elif not keep_cdp:
        console.print("  [bold]CDP[/bold] 已清空，后续将按所选 profile 启动/校验。")
    console.print("  [bold]后端[/bold] 已设为 cdp（复用或启动真实 profile 的 CDP 端口）")
    if not selected.user_name:
        console.print("[yellow]提示：[/yellow]这个 profile 没有读到邮箱，运行时只能校验目录名。")
    active_process = find_active_chrome_user_data_process(
        selected.user_data_dir,
        browser,
    )
    if active_process is not None and not config.chrome_cdp_url:
        console.print(
            "[yellow]注意：[/yellow]检测到这个 Chrome User Data 目录当前已经被 Chrome 使用。"
        )
        console.print(
            "  Pay-Switch 会优先寻找匹配该 profile 的 CDP 端口；没有则尝试按该 "
            "profile 启动一个带 remote-debugging-port 的真实 Chrome。若同一 "
            "User Data 已被其他 profile 接管，则会停止并提示处理。"
        )


@settings_app.command("project-profile")
def settings_project_profile(
    user_data_dir: Annotated[
        Path | None,
        typer.Option(
            "--user-data-dir",
            help=(
                "Pay-Switch 专用 Chrome User Data 根目录；默认使用 "
                "~/.payswitch/browser/chrome-user-data。"
            ),
        ),
    ] = None,
    profile_directory: Annotated[
        str,
        typer.Option(
            "--profile-directory",
            help="专用 Chrome profile 子目录。默认 Default。",
        ),
    ] = "Default",
    browser: Annotated[
        str,
        typer.Option("--browser", help="浏览器类型：chrome / chromium。"),
    ] = "chrome",
    expected_email: Annotated[
        str,
        typer.Option(
            "--expected-email",
            help=(
                "可选：Chrome profile 邮箱校验。专用项目 profile 通常不需要设置，"
                "站点账号由各网站自己登录。"
            ),
        ),
    ] = "",
    ensure: Annotated[
        bool,
        typer.Option(
            "--ensure",
            help="配置后立即启动/复用这个专用 profile 的 CDP 端口。",
        ),
    ] = False,
    timeout: Annotated[
        float,
        typer.Option("--timeout", help="--ensure 时等待 CDP 就绪的秒数。"),
    ] = 10.0,
) -> None:
    """配置 Pay-Switch 专用、持久、隔离的项目浏览器 profile。"""
    from payswitch.browser.cdp_attach import CdpAttachError, ensure_profile_cdp_url
    from payswitch.browser.chrome_profiles import (
        default_project_chrome_user_data_dir,
        ensure_project_chrome_profile,
    )
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import BrowserControlBackend

    browser = browser.strip().lower()
    _validate_profile_browser(browser)
    config = PaySwitchConfig.load()
    root = Path(user_data_dir).expanduser() if user_data_dir else (
        default_project_chrome_user_data_dir(config.data_dir)
    )
    profile = profile_directory.strip() or "Default"
    ensure_project_chrome_profile(root, profile)

    cdp_url = ""
    if ensure:
        try:
            cdp_url = ensure_profile_cdp_url(
                user_data_dir=root,
                profile_directory=profile,
                expected_email=expected_email.strip(),
                browser_channel=browser,
                timeout_seconds=timeout,
            )
        except CdpAttachError as exc:
            _print_error(str(exc))
            raise typer.Exit(code=1)

    updates = {
        "browser_control_backend": BrowserControlBackend.cdp.value,
        "browser_channel": "chrome" if browser == "chrome" else browser,
        "chrome_user_data_dir": str(root),
        "chrome_profile_directory": profile,
        "chrome_expected_profile_email": expected_email.strip(),
        "chrome_cdp_url": cdp_url,
    }
    updated = config.update(**updates)

    if _state.json_output:
        _print_json(
            {
                "chrome_user_data_dir": updated.chrome_user_data_dir,
                "chrome_profile_directory": updated.chrome_profile_directory,
                "chrome_expected_profile_email": updated.chrome_expected_profile_email,
                "chrome_cdp_url": updated.chrome_cdp_url,
                "browser_control_backend": updated.browser_control_backend.value,
                "browser_channel": updated.browser_channel,
                "created": True,
            }
        )
        return

    console.print("[green]OK[/green] 已配置 Pay-Switch 专用项目 Chrome profile：")
    console.print(f"  [bold]User Data[/bold] {updated.chrome_user_data_dir}")
    console.print(f"  [bold]Profile[/bold] {updated.chrome_profile_directory}")
    console.print("  [bold]用途[/bold] 只给 Pay-Switch 登录和操作各站点账号")
    console.print("  [bold]隔离[/bold] 不复用你的日常 Chrome profile，也不是临时镜像")
    console.print("  [bold]后端[/bold] cdp")
    if updated.chrome_cdp_url:
        console.print(f"  [bold]CDP[/bold] {updated.chrome_cdp_url}")
    else:
        console.print(
            "  [bold]CDP[/bold] 未启动；需要打开登录窗口时运行 "
            "uv run payswitch settings cdp-profile --ensure"
        )
    console.print(
        "[dim]后续 Kimi/DeepSeek/Seedance 等账号都在这个专用浏览器里登录。"
        "换机器或清理这个目录会丢失这些站点登录态。[/dim]"
    )


@settings_app.command("browser-doctor")
def settings_browser_doctor() -> None:
    """检查当前浏览器/profile 配置是否能被 Pay-Switch 正确接管。"""
    from payswitch.browser.runtime import (
        BrowserRuntimeConfigError,
        build_browser_runtime_plan,
        resolve_browser_backend,
    )
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    expected_email = config.chrome_expected_profile_email.strip()
    cdp_url = config.chrome_cdp_url.strip()
    user_data_dir = config.chrome_user_data_dir.strip()
    profile_directory = config.chrome_profile_directory.strip() or "Default"
    browser = config.browser_channel.strip() or "chrome"
    launch_mode = resolve_browser_backend(config).value
    identity = None
    active_process = None
    remote_debugging_port = ""
    has_matching_cdp = bool(cdp_url)
    runnable = True
    problems: list[str] = []
    recommendations: list[str] = []
    try:
        plan = build_browser_runtime_plan(
            config,
            validate_identity=True,
            preflight_occupancy=True,
            ensure_cdp=False,
        )
        identity = plan.identity
        has_matching_cdp = bool(plan.launch_kwargs.get("chrome_cdp_url"))
        if plan.occupied:
            active_process = True
            remote_debugging_port = plan.remote_debugging_port
    except BrowserRuntimeConfigError as exc:
        runnable = False
        problems.append(str(exc))

    if launch_mode == "cdp" and user_data_dir and not cdp_url:
        if has_matching_cdp and remote_debugging_port:
            recommendations.append(
                "已发现匹配 profile 的 CDP 端口；可运行 "
                f"uv run payswitch settings cdp-profile --ensure 固化为 http://127.0.0.1:{remote_debugging_port}"
            )
        elif active_process is not None and remote_debugging_port:
            runnable = False
            problems.append("同一 User Data 已有 CDP，但不是当前绑定 profile 的可校验端口")
            recommendations.append(
                "检测到同一 User Data 下已有 CDP 端口，但不是当前绑定 profile 的"
                "可校验端口；不要直接配置该端口，先运行 "
                "uv run payswitch settings cdp-profile --ensure。"
            )
        elif active_process is not None:
            runnable = False
            problems.append("真实 Chrome User Data 目录正在被普通 Chrome 占用，且没有匹配 CDP")
            recommendations.append(
                "检测到普通 Chrome 正在使用该 User Data。运行时会先尝试复用匹配 CDP；"
                "没有且同一 User Data 未被其他 profile 接管时，才按绑定 profile "
                "启动一个带 remote-debugging-port 的真实 Chrome。"
            )
        else:
            recommendations.append(
                "当前没有已开启 CDP 的匹配 profile。若同一 User Data 未被其他 "
                "Chrome 接管，运行交易时会自动启动；"
                "也可先运行 uv run payswitch settings cdp-profile --ensure。"
            )

    if launch_mode == "user_profile" and active_process is not None and not cdp_url:
        runnable = False
        problems.append("真实 Chrome User Data 目录正在被普通 Chrome 占用")
        recommendations.append(
            "真实支付主路径建议改为 CDP：uv run payswitch settings browser-backend "
            "--backend cdp，然后运行 uv run payswitch settings cdp-profile --ensure。"
        )

    if launch_mode == "ephemeral_cdp_mirror":
        recommendations.append(
            "将为每笔交易创建 /tmp 下的临时 CDP 镜像并启动独立 Chrome；"
            "适合流程探索，但登录态可能因站点风控或本机密钥绑定而要求重新验证。"
        )

    if not cdp_url and not user_data_dir:
        recommendations.append(
            "当前会使用 Pay-Switch 自管 profile，适合隔离测试；真实支付建议先运行 "
            "uv run payswitch settings wizard"
        )

    if _state.json_output:
        _print_json(
            {
                "launch_mode": launch_mode,
                "configured_backend": config.browser_control_backend.value,
                "runnable": runnable,
                "browser_channel": browser,
                "chrome_cdp_url": cdp_url,
                "chrome_user_data_dir": user_data_dir,
                "chrome_profile_directory": profile_directory,
                "expected_email": expected_email,
                "resolved_email": identity.user_name if identity else "",
                "active_process": (
                    {
                        "user_data_dir": user_data_dir,
                        "profile_directory": profile_directory,
                        "remote_debugging_port": remote_debugging_port,
                    }
                    if active_process
                    else None
                ),
                "problems": problems,
                "recommendations": recommendations,
            }
        )
        return

    table = Table(title="Browser Doctor", border_style="cyan")
    table.add_column("检查项", style="bold cyan", no_wrap=True)
    table.add_column("结果")
    table.add_row("配置后端", config.browser_control_backend.value)
    table.add_row("启动模式", launch_mode)
    table.add_row("浏览器", browser)
    table.add_row("CDP", cdp_url or "未配置")
    table.add_row("User Data", user_data_dir or "未配置")
    table.add_row("Profile", profile_directory)
    table.add_row("期望邮箱", expected_email or "未配置")
    table.add_row("识别邮箱", identity.user_name if identity else "未识别")
    if launch_mode == "ephemeral_cdp_mirror":
        table.add_row("临时镜像", "/tmp/payswitch-cdp-mirrors/<tx_id>")
    table.add_row(
        "目录占用",
        "是" if active_process is not None else "否/未检测到",
    )
    table.add_row("可直接运行", "是" if runnable else "否")
    console.print(table)

    if problems:
        console.print("[bold red]需要处理：[/bold red]")
        for problem in problems:
            console.print(f"  - {problem}")
    if recommendations:
        console.print("[bold yellow]建议：[/bold yellow]")
        for recommendation in recommendations:
            console.print(f"  - {recommendation}")


@settings_app.command("cdp-profile")
def settings_cdp_profile(
    ensure: Annotated[
        bool,
        typer.Option(
            "--ensure",
            help=(
                "没有匹配 CDP 端口且同一 User Data 未被其他 profile 接管时，"
                "按当前绑定 profile 启动一个真实 Chrome CDP 窗口。"
            ),
        ),
    ] = False,
    timeout: Annotated[
        float,
        typer.Option("--timeout", help="等待 CDP 端口就绪和身份校验的秒数。"),
    ] = 10.0,
) -> None:
    """检查或配置当前绑定真实 Chrome profile 的 CDP 接管端口。"""
    from pathlib import Path

    from payswitch.browser.cdp_attach import (
        CdpAttachError,
        ensure_profile_cdp_url,
        find_profile_cdp_url,
    )
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import BrowserControlBackend

    config = PaySwitchConfig.load()
    user_data_dir = config.chrome_user_data_dir.strip()
    profile_directory = config.chrome_profile_directory.strip() or "Default"
    expected_email = config.chrome_expected_profile_email.strip()
    browser = config.browser_channel.strip() or "chrome"
    if not user_data_dir:
        _print_error("还没有绑定 Chrome profile。请先运行 payswitch settings wizard。")
        raise typer.Exit(code=1)

    try:
        if ensure:
            cdp_url = ensure_profile_cdp_url(
                user_data_dir=Path(user_data_dir),
                profile_directory=profile_directory,
                expected_email=expected_email,
                browser_channel=browser,
                timeout_seconds=timeout,
            )
        else:
            cdp_url = find_profile_cdp_url(
                user_data_dir=Path(user_data_dir),
                profile_directory=profile_directory,
                expected_email=expected_email,
                browser_channel=browser,
            )
    except CdpAttachError as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1)

    if not cdp_url:
        message = (
            "没有找到已开启 remote-debugging 的匹配 Chrome profile。"
            "需要启动时请加 --ensure；如果同一 User Data 已被其他 profile 接管，"
            "Pay-Switch 会停止而不是强行再开端口。"
        )
        if _state.json_output:
            _print_json({"ok": False, "cdp_url": "", "message": message})
            return
        console.print(f"[yellow]{message}[/yellow]")
        return

    updated = config.update(
        browser_control_backend=BrowserControlBackend.cdp.value,
        chrome_cdp_url=cdp_url,
    )

    if _state.json_output:
        _print_json(
            {
                "ok": True,
                "cdp_url": updated.chrome_cdp_url,
                "browser_control_backend": updated.browser_control_backend.value,
                "chrome_user_data_dir": updated.chrome_user_data_dir,
                "chrome_profile_directory": updated.chrome_profile_directory,
                "expected_email": updated.chrome_expected_profile_email,
            }
        )
        return

    console.print("[green]OK[/green] 已配置真实 profile 的 CDP 接管：")
    console.print(f"  profile = {user_data_dir} / {profile_directory}")
    console.print(f"  identity = {expected_email or '未配置'}")
    console.print(f"  cdp = {updated.chrome_cdp_url}")
    console.print("  backend = cdp")


@settings_app.command("browser-backend")
def settings_browser_backend(
    backend: Annotated[
        str | None,
        typer.Option(
            "--backend",
            help="浏览器接管方式：auto / cdp / user_profile / managed_profile。",
        ),
    ] = None,
) -> None:
    """配置浏览器执行后端，避免 external 模式和 browser 控制方式混淆。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import BrowserControlBackend

    config = PaySwitchConfig.load()
    if backend is None:
        _print_browser_backend_explainer()
        backend = _prompt_choice(
            "浏览器接管方式",
            [item.value for item in BrowserControlBackend],
            default=config.browser_control_backend.value,
        )
    try:
        parsed = BrowserControlBackend(backend)
    except ValueError:
        _print_error(f"不支持的浏览器接管方式：{backend}")
        raise typer.Exit(code=1)

    updated = config.update(browser_control_backend=parsed.value)
    if _state.json_output:
        _print_json({"browser_control_backend": updated.browser_control_backend.value})
        return

    console.print("[green]OK[/green] 浏览器接管方式已更新：")
    console.print(f"  backend = {updated.browser_control_backend.value}")


@settings_app.command("computer-use")
def settings_computer_use(
    driver: Annotated[
        str | None,
        typer.Option(
            "--driver",
            help="Computer Use 驱动：external / internal / hybrid。",
        ),
    ] = None,
    max_category: Annotated[
        str | None,
        typer.Option(
            "--max-category",
            help=(
                "Computer Use 可自治推进的最高步骤：nav / identity / "
                "checkout_prep / sensitive / final_authorization / result。"
            ),
        ),
    ] = None,
    enable: Annotated[
        bool,
        typer.Option("--enable", help="启用 Computer Use 兜底能力。"),
    ] = False,
    disable: Annotated[
        bool,
        typer.Option("--disable", help="禁用 Computer Use 兜底能力。"),
    ] = False,
) -> None:
    """配置 external / internal / hybrid 的 Computer Use 推理模式。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import ComputerUseDriver, StepCategory

    if enable and disable:
        _print_error("--enable 和 --disable 不能同时使用")
        raise typer.Exit(code=1)

    config = PaySwitchConfig.load()
    updates = {}

    if driver is None and max_category is None and not enable and not disable:
        driver = _prompt_choice(
            "Computer Use 驱动",
            [item.value for item in ComputerUseDriver],
            default=config.computer_use_driver.value,
        )
        max_category = _prompt_choice(
            "可自治推进的最高步骤",
            [item.value for item in StepCategory],
            default=config.computer_use_max_autonomous_category.value,
        )
        enabled = typer.confirm(
            "是否启用 Computer Use 兜底能力？",
            default=config.computer_use_enabled,
        )
        updates["computer_use_enabled"] = enabled

    if driver is not None:
        try:
            updates["computer_use_driver"] = ComputerUseDriver(driver).value
        except ValueError:
            _print_error(f"不支持的 Computer Use driver：{driver}")
            raise typer.Exit(code=1)

    if max_category is not None:
        try:
            updates["computer_use_max_autonomous_category"] = StepCategory(max_category).value
        except ValueError:
            _print_error(f"不支持的步骤类别：{max_category}")
            raise typer.Exit(code=1)

    if enable:
        updates["computer_use_enabled"] = True
    if disable:
        updates["computer_use_enabled"] = False

    if not updates:
        _print_error("没有可更新的配置")
        raise typer.Exit(code=1)

    updated = config.update(**updates)

    if _state.json_output:
        _print_json(
            {
                "updated": updates,
                "computer_use_enabled": updated.computer_use_enabled,
                "computer_use_driver": updated.computer_use_driver.value,
                "computer_use_max_autonomous_category": (
                    updated.computer_use_max_autonomous_category.value
                ),
            }
        )
        return

    console.print("[green]OK[/green] Computer Use 配置已更新：")
    console.print(f"  enabled = {updated.computer_use_enabled}")
    console.print(f"  driver = {updated.computer_use_driver.value}")
    console.print(f"  max_category = {updated.computer_use_max_autonomous_category.value}")


@settings_app.command("stripe")
def settings_stripe(
    secret_key: Annotated[
        str | None,
        typer.Option(
            "--secret-key",
            help="Stripe Secret Key（sk_test_... 或 sk_live_...）",
        ),
    ] = None,
    webhook_secret: Annotated[
        str | None,
        typer.Option(
            "--webhook-secret",
            help="Stripe Webhook Signing Secret（whsec_...）",
        ),
    ] = None,
    webhook_port: Annotated[
        int | None,
        typer.Option(
            "--webhook-port",
            help="Webhook 监听端口（默认 4242）",
        ),
    ] = None,
    currency: Annotated[
        str | None,
        typer.Option(
            "--currency",
            help="默认货币（ISO 4217 代码，如 usd / cny / hkd）",
        ),
    ] = None,
) -> None:
    """配置 Stripe 支付通道（API Key、Webhook Secret、默认货币等）。"""
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    updates = {}

    # 交互式配置（未提供参数时）
    if secret_key is None and webhook_secret is None and webhook_port is None and currency is None:
        console.print("[bold cyan]Stripe 配置向导[/bold cyan]\n")

        # Secret Key
        current_key = config.get_stripe_secret_key()
        if current_key:
            console.print(f"当前 Secret Key: {current_key[:16]}...（已配置）")
        else:
            console.print("当前 Secret Key: [dim]未配置[/dim]")

        new_key = typer.prompt(
            "请输入 Stripe Secret Key（留空跳过）",
            default="",
            show_default=False,
        )
        if new_key.strip():
            updates["stripe_secret_key"] = new_key.strip()

        # Webhook Secret
        current_webhook = config.get_stripe_webhook_secret()
        if current_webhook:
            console.print(f"当前 Webhook Secret: {current_webhook[:16]}...（已配置）")
        else:
            console.print("当前 Webhook Secret: [dim]未配置[/dim]")

        new_webhook = typer.prompt(
            "请输入 Webhook Signing Secret（留空跳过）",
            default="",
            show_default=False,
        )
        if new_webhook.strip():
            updates["stripe_webhook_secret"] = new_webhook.strip()

        # Webhook Port
        new_port = typer.prompt(
            "Webhook 监听端口",
            default=config.stripe_webhook_port,
        )
        if new_port != config.stripe_webhook_port:
            updates["stripe_webhook_port"] = new_port

        # Default Currency
        new_currency = (
            typer.prompt(
                "默认货币（ISO 4217 代码）",
                default=config.stripe_default_currency,
            )
            .strip()
            .lower()
        )
        if new_currency != config.stripe_default_currency:
            updates["stripe_default_currency"] = new_currency

    else:
        # 命令行参数配置
        if secret_key is not None:
            updates["stripe_secret_key"] = secret_key
        if webhook_secret is not None:
            updates["stripe_webhook_secret"] = webhook_secret
        if webhook_port is not None:
            updates["stripe_webhook_port"] = webhook_port
        if currency is not None:
            updates["stripe_default_currency"] = currency.lower()

    if not updates:
        console.print("[yellow]未修改任何配置[/yellow]")
        return

    # 对 secret key 和 webhook secret 进行编码存储
    if "stripe_secret_key" in updates:
        config = config.set_stripe_secret_key(updates.pop("stripe_secret_key"))
    if "stripe_webhook_secret" in updates:
        config = config.set_stripe_webhook_secret(updates.pop("stripe_webhook_secret"))

    # 更新其他字段
    if updates:
        config = config.update(**updates)

    if _state.json_output:
        _print_json(
            {
                "updated": True,
                "stripe_secret_key_set": bool(config.get_stripe_secret_key()),
                "stripe_webhook_secret_set": bool(config.get_stripe_webhook_secret()),
                "webhook_port": config.stripe_webhook_port,
                "default_currency": config.stripe_default_currency,
            }
        )
        return

    console.print("[green]OK[/green] Stripe 配置已更新：")
    if config.get_stripe_secret_key():
        console.print(f"  secret_key = {config.get_stripe_secret_key()[:16]}...（已配置）")
    else:
        console.print("  secret_key = [dim]未配置[/dim]")
    if config.get_stripe_webhook_secret():
        console.print(f"  webhook_secret = {config.get_stripe_webhook_secret()[:16]}...（已配置）")
    else:
        console.print("  webhook_secret = [dim]未配置[/dim]")
    console.print(f"  webhook_port = {config.stripe_webhook_port}")
    console.print(f"  default_currency = {config.stripe_default_currency}")


# ---------------------------------------------------------------------------
# Stripe 子命令组
# ---------------------------------------------------------------------------


@stripe_app.command("listen")
def stripe_listen(
    port: Annotated[
        int | None,
        typer.Option(
            "--port",
            "-p",
            help="Webhook 监听端口（默认从配置读取，通常为 4242）",
        ),
    ] = None,
    host: Annotated[
        str,
        typer.Option(
            "--host",
            help="监听地址（默认 0.0.0.0）",
        ),
    ] = "0.0.0.0",
) -> None:
    """启动 Stripe webhook 监听器（接收支付完成事件并更新交易状态）。

    使用示例：
      payswitch stripe listen              # 使用配置文件中的端口
      payswitch stripe listen --port 8080  # 使用指定端口
      payswitch stripe listen --host 127.0.0.1  # 仅本地监听

    注意：
    - 需要先配置 Stripe Webhook Secret：payswitch settings stripe
    - 生产环境需要配置 Stripe Dashboard 的 webhook URL
    - 本地测试可使用 Stripe CLI 的 webhook 转发功能
    """
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()

    # 确定监听端口
    listen_port = port if port is not None else config.stripe_webhook_port

    # 检查 Stripe 依赖是否安装
    try:
        from payswitch.engine.stripe_webhook import create_webhook_app
    except ImportError:
        _print_error(
            "Stripe 依赖未安装。请运行：uv pip install 'payswitch[stripe]' "
            "或 pip install stripe fastapi uvicorn"
        )
        raise typer.Exit(code=1)

    # 创建 webhook app
    app = create_webhook_app()
    if app is None:
        _print_error("无法创建 webhook 监听器，请检查依赖安装")
        raise typer.Exit(code=1)

    # 输出启动信息
    console.print("[bold cyan]Stripe Webhook 监听器启动中...[/bold cyan]")
    console.print(f"  监听地址: {host}:{listen_port}")
    console.print(f"  Webhook URL: http://{host}:{listen_port}/webhook")
    console.print(f"  健康检查: http://{host}:{listen_port}/health")

    webhook_secret = config.get_stripe_webhook_secret()
    if not webhook_secret:
        console.print("[yellow]警告：[/yellow] Webhook Secret 未配置，签名验证将被跳过（不安全）")
        console.print("  请运行 [cyan]payswitch settings stripe[/cyan] 配置 Webhook Secret")

    console.print("\n按 Ctrl+C 停止监听器\n")

    # 启动 uvicorn 服务器
    try:
        import uvicorn

        uvicorn.run(app, host=host, port=listen_port, log_level="info")
    except KeyboardInterrupt:
        console.print("\n[yellow]监听器已停止[/yellow]")
    except Exception as exc:
        _print_error(f"启动监听器失败：{exc}")
        raise typer.Exit(code=1)


@payment_settings_app.callback(invoke_without_command=True)
def settings_payment_overview(ctx: typer.Context) -> None:
    """显示支付策略配置入口。"""
    if ctx.invoked_subcommand is not None:
        return

    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    if _state.json_output:
        _print_json(
            {
                "payment_priority": [method.value for method in config.payment_priority],
                "disabled_payment_methods": [
                    method.value for method in config.disabled_payment_methods
                ],
                "allow_card_number_only": config.allow_card_number_only,
                "card_instruments": [
                    instrument.model_dump(mode="json") for instrument in config.card_instruments
                ],
            }
        )
        return

    _print_payment_explainer()
    table = Table(title="当前支付策略", border_style="cyan")
    table.add_column("配置项", style="bold cyan", no_wrap=True)
    table.add_column("当前值")
    table.add_column("说明", style="dim")
    table.add_row(
        "payment_priority",
        " -> ".join(method.value for method in config.payment_priority),
        "自动支付方式选择顺序",
    )
    table.add_row(
        "disabled_payment_methods",
        ", ".join(method.value for method in config.disabled_payment_methods) or "（空）",
        "即使页面支持也不使用",
    )
    table.add_row(
        "allow_card_number_only",
        str(config.allow_card_number_only),
        "是否允许人工确认后仅代填卡号",
    )
    table.add_row(
        "card_instruments",
        str(len(config.card_instruments)),
        "本地已配置的卡号工具数量",
    )
    console.print(table)
    console.print(
        "\n[dim]常用命令：[/dim]\n"
        "  payswitch settings payment priority\n"
        "  payswitch settings payment card add\n"
        "  payswitch settings payment card list"
    )


@payment_settings_app.command("priority")
def settings_payment_priority(
    methods: Annotated[
        str | None,
        typer.Option(
            "--methods",
            "-m",
            help="逗号分隔支付顺序，例如 alipay_qr,wechat_qr,card_number_only,stripe。",
        ),
    ] = None,
) -> None:
    """配置自动支付方式优先级。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import PaymentMethod

    config = PaySwitchConfig.load()
    choices = [
        PaymentMethod.alipay_qr,
        PaymentMethod.wechat_qr,
        PaymentMethod.card_number_only,
        PaymentMethod.stripe,
        PaymentMethod.bankcard,
    ]
    if methods is None:
        _print_payment_explainer()
        default = ",".join(method.value for method in config.payment_priority)
        methods = typer.prompt(
            "支付优先级（逗号分隔）",
            default=default,
        )

    try:
        parsed = _parse_payment_methods(methods, choices)
    except ValueError as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1)

    updated = config.update(payment_priority=[method.value for method in parsed])
    if _state.json_output:
        _print_json({"payment_priority": [method.value for method in updated.payment_priority]})
        return
    console.print("[green]OK[/green] 支付优先级已更新：")
    console.print("  " + " -> ".join(method.value for method in updated.payment_priority))


@payment_settings_app.command("disable")
def settings_payment_disable(
    methods: Annotated[
        str,
        typer.Argument(help="逗号分隔要禁用的支付方式。"),
    ],
) -> None:
    """禁用一个或多个支付方式。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import PaymentMethod

    try:
        parsed = _parse_payment_methods(methods, list(PaymentMethod))
    except ValueError as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1)
    config = PaySwitchConfig.load()
    updated = config.update(disabled_payment_methods=[method.value for method in parsed])
    if _state.json_output:
        _print_json(
            {"disabled_payment_methods": [m.value for m in updated.disabled_payment_methods]}
        )
        return
    console.print("[green]OK[/green] 已更新禁用支付方式：")
    console.print("  " + (", ".join(m.value for m in updated.disabled_payment_methods) or "（空）"))


@payment_card_app.command("add")
def settings_payment_card_add(
    card_id: Annotated[
        str | None,
        typer.Option("--id", help="本地卡片 ID，例如 personal_visa。"),
    ] = None,
    label: Annotated[
        str | None,
        typer.Option("--label", help="展示名称，例如 Personal Visa。"),
    ] = None,
    card_number: Annotated[
        str | None,
        typer.Option(
            "--card-number",
            help="测试用：直接传入卡号。交互使用时会隐藏输入。",
        ),
    ] = None,
    expiry: Annotated[
        str | None,
        typer.Option("--expiry", help="有效期 MM/YY 或 MM/YYYY 格式。"),
    ] = None,
    cvv: Annotated[
        str | None,
        typer.Option("--cvv", help="CVV/CVC（hidden input）。"),
    ] = None,
    holder_name: Annotated[
        str | None,
        typer.Option("--holder-name", help="持卡人全名。"),
    ] = None,
    address_line1: Annotated[
        str | None,
        typer.Option("--address-line1", help="账单地址第一行。"),
    ] = None,
    city: Annotated[
        str | None,
        typer.Option("--city", help="城市。"),
    ] = None,
    state: Annotated[
        str | None,
        typer.Option("--state", help="州/省。"),
    ] = None,
    postal_code: Annotated[
        str | None,
        typer.Option("--postal-code", help="邮编。"),
    ] = None,
    country: Annotated[
        str,
        typer.Option("--country", help="国家代码，默认 US。"),
    ] = "US",
    payees: Annotated[
        str | None,
        typer.Option("--payees", help="允许使用的收款方，逗号分隔；留空表示不限制。"),
    ] = None,
    max_per_transaction: Annotated[
        float,
        typer.Option("--max-per-transaction", help="单卡单笔限额，0 表示不限制。"),
    ] = 0.0,
    currencies: Annotated[
        str | None,
        typer.Option("--currencies", help="允许货币，逗号分隔；留空表示不限制。"),
    ] = None,
) -> None:
    """安全保存一张虚拟卡（支持全字段或仅卡号）。"""
    from payswitch.models.config import CardInstrument, PaySwitchConfig
    from payswitch.security.card_vault import (
        BillingAddress,
        CardVaultError,
        VirtualCardData,
        store_card_number,
        store_virtual_card,
    )

    config = PaySwitchConfig.load()
    card_id = (card_id or typer.prompt("卡片 ID，例如 personal_visa")).strip()
    if not card_id:
        _print_error("卡片 ID 不能为空")
        raise typer.Exit(code=1)
    if any(item.id == card_id for item in config.card_instruments):
        _print_error(f"卡片 ID 已存在：{card_id}")
        raise typer.Exit(code=1)

    label = (label or typer.prompt("展示名称，例如 Personal Visa")).strip()
    if not label:
        _print_error("展示名称不能为空")
        raise typer.Exit(code=1)

    # 卡号输入（hidden）
    if card_number is None:
        card_number = typer.prompt("卡号（输入会隐藏）", hide_input=True)

    # 交互式收集可选字段（仅在未通过命令行参数提供时询问）
    if expiry is None:
        expiry = typer.prompt("有效期 MM/YY（可选，直接回车跳过）", default="")
    if cvv is None:
        cvv = typer.prompt("CVV/CVC（可选，直接回车跳过）", hide_input=True, default="")
    if holder_name is None:
        holder_name = typer.prompt("持卡人全名（可选，直接回车跳过）", default="")

    # 解析有效期
    exp_month, exp_year = "", ""
    if expiry:
        parts = expiry.strip().split("/")
        if len(parts) == 2:
            exp_month = parts[0].strip().zfill(2)
            exp_year = parts[1].strip()
        else:
            _print_error("有效期格式错误，应为 MM/YY 或 MM/YYYY")
            raise typer.Exit(code=1)

    # 判断是否有额外字段（超出仅卡号）
    has_extra = bool(exp_month or cvv or holder_name or address_line1)

    secret_ref = f"payswitch/card/{card_id}/pan"

    if has_extra:
        # 构建账单地址（如果提供了任意地址字段）
        addr = None
        if address_line1:
            addr = BillingAddress(
                line1=address_line1 or "",
                city=city or "",
                state=state or "",
                postal_code=postal_code or "",
                country=country,
            )
        card_data = VirtualCardData(
            card_number=card_number,
            expiry_month=exp_month,
            expiry_year=exp_year,
            cvv=cvv or "",
            holder_name=holder_name or "",
            billing_address=addr,
        )
        try:
            masked = store_virtual_card(secret_ref, card_data)
        except (ValueError, CardVaultError) as exc:
            _print_error(str(exc))
            raise typer.Exit(code=1)
        autofill_level = "full"
    else:
        # 仅卡号模式（向后兼容）
        try:
            masked = store_card_number(secret_ref, card_number)
        except (ValueError, CardVaultError) as exc:
            _print_error(str(exc))
            raise typer.Exit(code=1)
        autofill_level = "number_only"

    instrument = CardInstrument(
        id=card_id,
        label=f"{label} ending {masked[-4:]}",
        storage="keyring",
        secret_ref=secret_ref,
        autofill_level=autofill_level,
        has_expiry=bool(exp_month),
        has_cvv=bool(cvv),
        has_holder_name=bool(holder_name),
        has_billing_address=bool(address_line1),
        allowed_payees=_split_csv(payees),
        max_per_transaction=max_per_transaction,
        currency_allowlist=[item.upper() for item in _split_csv(currencies)],
    )
    updated = config.update(
        allow_card_number_only=True,
        allow_virtual_card=has_extra,
        card_instruments=[
            item.model_dump(mode="json") for item in [*config.card_instruments, instrument]
        ],
    )

    if _state.json_output:
        _print_json(
            {
                "added": instrument.model_dump(mode="json"),
                "allow_card_number_only": updated.allow_card_number_only,
                "allow_virtual_card": updated.allow_virtual_card,
            }
        )
        return
    level_display = "全字段" if autofill_level == "full" else "仅卡号"
    console.print(f"[green]OK[/green] 已添加卡片（{level_display}）：")
    console.print(f"  id = {instrument.id}")
    console.print(f"  label = {instrument.label}")
    console.print("  保存位置 = OS keyring / Keychain")
    if autofill_level == "full":
        console.print("  自动填写 = 卡号 + 有效期 + CVV + 姓名 + 地址")
        console.print("  人工边界 = OTP、3DS、CAPTCHA、最终确认按钮")
    else:
        console.print("  人工边界 = 有效期、CVV、OTP、3DS、最终确认都由用户完成")


@payment_card_app.command("list")
def settings_payment_card_list() -> None:
    """列出已配置的卡片工具元数据。"""
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    if _state.json_output:
        _print_json(
            {
                "allow_card_number_only": config.allow_card_number_only,
                "allow_virtual_card": config.allow_virtual_card,
                "card_instruments": [
                    item.model_dump(mode="json") for item in config.card_instruments
                ],
            }
        )
        return

    table = Table(title="卡片工具", border_style="cyan")
    table.add_column("ID", style="bold cyan")
    table.add_column("展示名称")
    table.add_column("完整度")
    table.add_column("允许收款方")
    table.add_column("单笔限额")
    table.add_column("货币")
    for item in config.card_instruments:
        # 根据 has_* 标志判断完整度
        if item.autofill_level == "full":
            completeness = "[green]全字段 ✓[/green]"
        else:
            completeness = "[yellow]仅卡号[/yellow]"
        table.add_row(
            item.id,
            item.label,
            completeness,
            ", ".join(item.allowed_payees) or "不限制",
            str(item.max_per_transaction or "不限制"),
            ", ".join(item.currency_allowlist) or "不限制",
        )
    console.print(table)
    if not config.card_instruments:
        console.print("[dim]还没有配置卡片。运行 payswitch settings payment card add。[/dim]")


@payment_card_app.command("remove")
def settings_payment_card_remove(
    card_id: Annotated[str, typer.Argument(help="要删除的卡片 ID。")],
) -> None:
    """删除本地卡片（同时清理新旧两种格式的 Keyring 数据）。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.security.card_vault import delete_card_number, delete_virtual_card

    config = PaySwitchConfig.load()
    target = next((item for item in config.card_instruments if item.id == card_id), None)
    if target is None:
        _print_error(f"未找到卡片 ID：{card_id}")
        raise typer.Exit(code=1)
    # 同时删除新格式和旧格式
    delete_virtual_card(target.secret_ref)
    delete_card_number(target.secret_ref)
    remaining = [item for item in config.card_instruments if item.id != card_id]
    updated = config.update(
        card_instruments=[item.model_dump(mode="json") for item in remaining],
        allow_card_number_only=bool(remaining) and config.allow_card_number_only,
    )
    if _state.json_output:
        _print_json(
            {
                "removed": card_id,
                "card_instruments": [
                    item.model_dump(mode="json") for item in updated.card_instruments
                ],
            }
        )
        return
    console.print(f"[green]OK[/green] 已删除卡片：{card_id}")


@payment_card_app.command("upgrade")
def settings_payment_card_upgrade(
    card_id: Annotated[str, typer.Argument(help="要升级的卡片 ID。")],
) -> None:
    """为已有的 number_only 卡补充完整信息，升级为全字段。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.security.card_vault import (
        BillingAddress,
        CardVaultError,
        VirtualCardData,
        load_card_number,
        store_virtual_card,
    )

    config = PaySwitchConfig.load()
    target = next((item for item in config.card_instruments if item.id == card_id), None)
    if target is None:
        _print_error(f"未找到卡片 ID：{card_id}")
        raise typer.Exit(code=1)
    if target.autofill_level == "full":
        _print_error(f"卡片 {card_id} 已经是全字段模式")
        raise typer.Exit(code=1)

    # 读取已有卡号
    pan = load_card_number(target.secret_ref)
    if pan is None:
        _print_error(f"未找到卡片 {card_id} 的卡号数据")
        raise typer.Exit(code=1)

    # 交互式收集额外字段
    expiry = typer.prompt("有效期 MM/YY（可选，直接回车跳过）", default="")
    cvv = typer.prompt("CVV/CVC（可选，直接回车跳过）", hide_input=True, default="")
    holder_name = typer.prompt("持卡人全名（可选，直接回车跳过）", default="")
    address_line1 = typer.prompt("账单地址（可选，直接回车跳过）", default="")

    exp_month, exp_year = "", ""
    if expiry:
        parts = expiry.strip().split("/")
        if len(parts) == 2:
            exp_month = parts[0].strip().zfill(2)
            exp_year = parts[1].strip()
        else:
            _print_error("有效期格式错误，应为 MM/YY 或 MM/YYYY")
            raise typer.Exit(code=1)

    addr = None
    if address_line1:
        city = typer.prompt("城市", default="")
        state = typer.prompt("州/省", default="")
        postal_code = typer.prompt("邮编", default="")
        country = typer.prompt("国家代码", default="US")
        addr = BillingAddress(
            line1=address_line1,
            city=city,
            state=state,
            postal_code=postal_code,
            country=country,
        )

    card_data = VirtualCardData(
        card_number=pan,
        expiry_month=exp_month,
        expiry_year=exp_year,
        cvv=cvv,
        holder_name=holder_name,
        billing_address=addr,
    )
    try:
        store_virtual_card(target.secret_ref, card_data)
    except (ValueError, CardVaultError) as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1)

    # 更新 CardInstrument 元数据
    instruments = []
    for item in config.card_instruments:
        if item.id == card_id:
            data = item.model_dump(mode="json")
            data.update(
                autofill_level="full",
                has_expiry=bool(exp_month),
                has_cvv=bool(cvv),
                has_holder_name=bool(holder_name),
                has_billing_address=bool(address_line1),
            )
            instruments.append(data)
        else:
            instruments.append(item.model_dump(mode="json"))
    config.update(
        allow_virtual_card=True,
        card_instruments=instruments,
    )

    if _state.json_output:
        _print_json({"upgraded": card_id, "autofill_level": "full"})
        return
    console.print(f"[green]OK[/green] 卡片 {card_id} 已升级为全字段模式")


def _print_profile_table(profiles, browser: str) -> None:
    table = Table(
        title=f"{browser} profiles",
        border_style="cyan",
        show_lines=False,
    )
    table.add_column("#", justify="right", style="bold cyan", no_wrap=True)
    table.add_column("Profile 目录", style="bold", no_wrap=True)
    table.add_column("邮箱", overflow="fold")
    table.add_column("昵称 / 用户名", overflow="fold")
    table.add_column("User Data", style="dim", overflow="fold")

    for position, profile in enumerate(profiles, start=1):
        display_name = profile.gaia_name or profile.gaia_given_name or profile.name or "-"
        if profile.is_consented_primary_account:
            display_name = f"{display_name} [green](primary)[/green]"
        table.add_row(
            str(position),
            profile.profile_directory,
            profile.user_name or "[dim]未识别[/dim]",
            display_name,
            str(profile.user_data_dir),
        )

    console.print(table)


def _print_wizard_intro() -> None:
    console.print(
        Panel(
            "[bold]Pay-Switch 配置引导[/bold]\n\n"
            "推荐先使用 Pay-Switch 专用项目 profile：它是一个持久 Chrome "
            "User Data 目录，专门用来登录 Kimi、DeepSeek、Seedance 等付款账号，"
            "和你的日常 Chrome 隔离，也不是一次性镜像。\n\n"
            "配置流程：\n"
            "1. 选择专用项目 profile 或已有 Chrome profile\n"
            "2. 配置 CDP/browser 接管方式\n"
            "3. 设置 Computer Use 的思考/执行边界\n"
            "4. 给出下一步测试命令",
            title="Settings Wizard",
            border_style="cyan",
        )
    )


def _print_browser_explainer() -> None:
    table = Table(title="Step 1: 选择浏览器", border_style="cyan")
    table.add_column("选项", style="bold", no_wrap=True)
    table.add_column("说明")
    table.add_column("当前状态", style="dim")
    table.add_row(
        "chrome",
        "你平时使用的 Google Chrome。推荐用于真实支付测试。",
        "支持读取 profile",
    )
    table.add_row(
        "chromium",
        "Chromium 用户目录。适合开发机或非 Google Chrome 环境。",
        "支持读取 profile",
    )
    table.add_row(
        "firefox",
        "Firefox。后续可以扩展，但当前还没有 profile 读取实现。",
        "路线图",
    )
    console.print(table)
    console.print(
        "[dim]为什么先选浏览器：不同浏览器的 profile 存储位置和格式不同，"
        "必须先确定浏览器，才能正确列出可选身份。[/dim]\n"
    )


def _print_profile_explainer(browser: str, current_email: str) -> None:
    current = current_email or "未设置"
    console.print(
        Panel(
            f"[bold]Step 2: 选择 {browser} profile[/bold]\n\n"
            "profile 可以理解成 Chrome 右上角的那个用户身份。"
            "它保存了网站登录态、Cookie、设备信任、历史风控状态等信息。"
            "付款成功率往往取决于这里选得对不对。\n\n"
            "表格里的含义：\n"
            "- Profile 目录：机器真正使用的目录名，例如 Default / Profile 6\n"
            "- 邮箱：Chrome Local State 里读到的账号邮箱\n"
            "- 昵称 / 用户名：Chrome 显示名或 GAIA 名称\n\n"
            f"当前已绑定邮箱：{current}\n\n"
            "如果 profile 很多，可以输入邮箱、昵称或 Profile 目录的一部分来过滤；"
            "也可以直接回车看全部。",
            title="Profile Guide",
            border_style="cyan",
        )
    )


def _print_computer_use_explainer() -> None:
    table = Table(title="Step 3: Computer Use 驱动模式", border_style="cyan")
    table.add_column("模式", style="bold", no_wrap=True)
    table.add_column("谁来思考")
    table.add_column("适合场景")
    table.add_row(
        "external",
        "外部 Agent 思考；Pay-Switch 只做受控点击、校验、记录和人工闸门。",
        "推荐。适合把 Pay-Switch 当成 MCP/工具交给你的 Agent 使用。",
    )
    table.add_row(
        "internal",
        "Pay-Switch 自己调用配置的模型理解页面。",
        "本地 demo 或没有外部 Agent 时使用，需要额外配置模型。",
    )
    table.add_row(
        "hybrid",
        "外部 Agent 给目标，Pay-Switch 内部模型做局部页面理解。",
        "未来用于适配器失效后的自愈。",
    )
    console.print(table)
    console.print("[dim]推荐 external：你的 Agent 当大脑，Pay-Switch 当手、刹车和账本。[/dim]\n")


def _print_browser_backend_explainer() -> None:
    table = Table(title="浏览器接管方式", border_style="cyan")
    table.add_column("方式", style="bold", no_wrap=True)
    table.add_column("含义")
    table.add_column("什么时候用")
    table.add_row(
        "auto",
        "自动选择：有 CDP 就连接 CDP；否则有真实 profile 就尝试独占启动；否则自管 profile。",
        "推荐默认，适合大多数用户。",
    )
    table.add_row(
        "cdp",
        "连接已经用 --remote-debugging-port 启动的 Chrome。",
        "你要接管已有真实浏览器上下文时使用。",
    )
    table.add_row(
        "ephemeral_cdp_mirror",
        "每笔交易从所选 profile 同步 /tmp 临时镜像，再启动独立 CDP Chrome。",
        "普通 Chrome 已打开但想先探索流程；不适合作为最终真实 profile 等价替代。",
    )
    table.add_row(
        "user_profile",
        "Pay-Switch 独占启动你选择的真实 Chrome profile。",
        "必须先关闭普通 Chrome，否则会冲突。",
    )
    table.add_row(
        "managed_profile",
        "使用 ~/.payswitch 下的自管 profile。",
        "隔离测试、首次学习；不等于你的日常登录态。",
    )
    console.print(table)
    console.print(
        "[dim]推荐真实项目运行使用：uv run payswitch settings project-profile。"
        "它会创建 ~/.payswitch/browser/chrome-user-data，后续所有站点登录态都放在那里。[/dim]\n"
        "[dim]注意：external/internal/hybrid 决定谁思考；这里决定浏览器这只手怎么接管。"
        " 两者不是一回事。[/dim]\n"
    )


def _print_autonomy_explainer() -> None:
    table = Table(title="Computer Use 可以自动推进到哪一步", border_style="cyan")
    table.add_column("步骤", style="bold", no_wrap=True)
    table.add_column("含义")
    table.add_column("建议")
    table.add_row("nav", "打开页面、滚动、找入口、关普通弹窗。", "安全")
    table.add_row("identity", "检查是否登录、点登录入口。密码/2FA 仍要人来。", "通常可用")
    table.add_row("checkout_prep", "选择套餐、进入收银台、准备付款前信息。", "推荐默认")
    table.add_row("sensitive", "CVV、验证码、支付密码、银行卡等。", "不要自动")
    table.add_row("final_authorization", "确认付款、订阅、开通自动续费。", "必须人确认")
    table.add_row("result", "支付后读取结果页、收据、订单状态。", "后续确认")
    console.print(table)
    console.print(
        "[dim]建议保持 checkout_prep：系统可以帮你走到付款前，"
        "但真正付钱、扫码、输密码、点最终确认时停下来等你。[/dim]\n"
    )


def _print_payment_explainer() -> None:
    table = Table(title="支付方式策略", border_style="cyan")
    table.add_column("方式", style="bold", no_wrap=True)
    table.add_column("Pay-Switch 做什么")
    table.add_column("必须由用户做什么")
    table.add_row(
        "alipay_qr",
        "识别支付宝二维码/收银台，等待扫码结果。",
        "在支付宝 App 扫码或确认。",
    )
    table.add_row(
        "wechat_qr",
        "识别微信支付二维码/收银台，等待扫码结果。",
        "在微信 App 扫码或确认。",
    )
    table.add_row(
        "card_number_only",
        "在确认后只填写卡号，卡号存放在 OS keyring/Keychain。",
        "填写有效期、CVV、OTP/3DS，并最终确认付款。",
    )
    table.add_row(
        "stripe",
        "识别 Hosted Checkout 或 Stripe 页面入口。",
        "按页面要求完成授权、3DS 或卡片敏感信息。",
    )
    console.print(table)
    console.print(
        "[dim]推荐中国默认顺序：alipay_qr -> wechat_qr -> card_number_only -> stripe。[/dim]\n"
    )


def _parse_payment_methods(raw: str, choices: list) -> list:
    from payswitch.models.types import PaymentMethod

    alias = {"cc_autofill": PaymentMethod.card_number_only.value}
    valid = {item.value: item for item in choices}
    parsed = []
    for item in _split_csv(raw):
        value = alias.get(item, item)
        if value not in valid:
            raise ValueError(f"不支持的支付方式：{item}。可选：{', '.join(valid.keys())}")
        if valid[value] not in parsed:
            parsed.append(valid[value])
    if not parsed:
        raise ValueError("至少需要保留一种支付方式")
    return parsed


def _split_csv(raw: str | None) -> list[str]:
    if raw is None:
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]


def _prompt_choice(label: str, choices: list[str], default: str) -> str:
    choices_text = " / ".join(choices)
    while True:
        value = typer.prompt(
            f"{label} ({choices_text})",
            default=default,
        ).strip()
        if value in choices:
            return value
        console.print(f"[yellow]请输入以下选项之一：[/yellow]{choices_text}")


def _validate_profile_browser(browser: str) -> None:
    if browser == "firefox":
        _print_error(
            "Firefox profile 发现还没有实现。当前引导支持 chrome/chromium；"
            "多浏览器与多 profile 选择会放入后续路线图。"
        )
        raise typer.Exit(code=1)
    if browser not in {"chrome", "chromium"}:
        _print_error(f"不支持的浏览器：{browser}。可选：chrome / chromium")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# 浏览器检测辅助函数（供 setup 使用）
# ---------------------------------------------------------------------------


def _detect_system_browser() -> str | None:
    """检测系统是否安装了 Chrome 或 Edge，返回 Playwright channel 名称或 None。

    按优先级检测：Chrome > Edge。
    支持 Windows / macOS / Linux。
    """
    import platform as _platform
    import shutil

    system = _platform.system()

    if system == "Windows":
        # Windows：检查常见安装路径
        chrome_paths = [
            Path("C:/Program Files/Google/Chrome/Application/chrome.exe"),
            Path("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"),
        ]
        edge_paths = [
            Path("C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"),
            Path("C:/Program Files/Microsoft/Edge/Application/msedge.exe"),
        ]
        for p in chrome_paths:
            if p.exists():
                return "chrome"
        for p in edge_paths:
            if p.exists():
                return "msedge"

    elif system == "Darwin":
        # macOS：检查 Applications 目录
        if Path("/Applications/Google Chrome.app").exists():
            return "chrome"
        if Path("/Applications/Microsoft Edge.app").exists():
            return "msedge"

    else:
        # Linux：使用 which 检测
        if shutil.which("google-chrome") or shutil.which("google-chrome-stable"):
            return "chrome"
        if shutil.which("chromium-browser") or shutil.which("chromium"):
            return "chromium"
        if shutil.which("microsoft-edge"):
            return "msedge"

    return None


def _detect_playwright_chromium() -> bool:
    """检查 Playwright 的 Chromium 是否已下载到本地缓存目录。"""
    import platform as _platform

    system = _platform.system()
    home = Path.home()

    if system == "Windows":
        cache_dir = home / "AppData" / "Local" / "ms-playwright"
    elif system == "Darwin":
        cache_dir = home / "Library" / "Caches" / "ms-playwright"
    else:
        cache_dir = home / ".cache" / "ms-playwright"

    if not cache_dir.exists():
        return False

    # 查找 chromium-* 子目录
    return any(d.name.startswith("chromium-") for d in cache_dir.iterdir() if d.is_dir())


# ---------------------------------------------------------------------------
# serve / agent — HTTP service, A2A, and Pay-Switch Language
# ---------------------------------------------------------------------------


@experience_patch_app.command("list")
def experience_patch_list(
    platform: Annotated[
        str | None,
        typer.Option("--platform", help="按平台过滤，如 kimi / deepseek。"),
    ] = None,
    flow: Annotated[
        str | None,
        typer.Option("--flow", help="按 flow 过滤，如 membership_monthly_qr。"),
    ] = None,
    state: Annotated[
        str | None,
        typer.Option("--state", help="按状态过滤：candidate/shadow_run/reviewed/mainline。"),
    ] = None,
    source: Annotated[
        str | None,
        typer.Option("--source", help="按 source 过滤，如 script_recovery。"),
    ] = None,
) -> None:
    """列出 recovery recipe patch。"""
    store = _experience_store_from_config()
    patch_state = _resolve_patch_state(state)
    patches = store.list_patches(
        platform=platform,
        flow=flow,
        state=patch_state,
        source=source,
    )
    if _state.json_output:
        _print_json(
            [
                {
                    "id": patch["id"],
                    "platform": patch["platform"],
                    "flow": patch["flow"],
                    "state": patch["state"],
                    "source": patch["source"],
                    "shadow_run_success": patch["shadow_run_success"],
                    "recipe_id": patch["recipe"].recipe_id,
                    "recipe_version": patch["recipe"].version,
                    "metadata": patch["metadata"],
                    "updated_at": patch["updated_at"],
                }
                for patch in patches
            ]
        )
        return

    table = Table(title="Recovery Recipe Patches")
    table.add_column("ID", justify="right")
    table.add_column("Platform")
    table.add_column("Flow")
    table.add_column("State")
    table.add_column("Source")
    table.add_column("Recipe")
    table.add_column("Updated")
    for patch in patches:
        table.add_row(
            str(patch["id"]),
            patch["platform"],
            patch["flow"],
            patch["state"],
            patch["source"],
            f'{patch["recipe"].recipe_id}@{patch["recipe"].version}',
            patch["updated_at"],
        )
    console.print(table)


@experience_patch_app.command("queue")
def experience_patch_queue(
    platform: Annotated[
        str | None,
        typer.Option("--platform", help="按平台过滤，如 kimi。"),
    ] = None,
    flow: Annotated[
        str | None,
        typer.Option("--flow", help="按 flow 过滤，如 membership_monthly_qr。"),
    ] = None,
    source: Annotated[
        str | None,
        typer.Option("--source", help="按 source 过滤，如 script_recovery。"),
    ] = None,
    ready_only: Annotated[
        bool,
        typer.Option("--ready-only", help="仅显示已可提升到 mainline 的 patch。"),
    ] = False,
    min_shadow_runs: Annotated[
        int,
        typer.Option("--min-shadow-runs", min=1, help="shadow-run 提升所需最小成功次数。"),
    ] = 1,
) -> None:
    """列出 patch promotion queue 与 readiness。"""
    store = _experience_store_from_config()
    entries = store.list_patch_queue(
        platform=platform,
        flow=flow,
        source=source,
        ready_only=ready_only,
        min_shadow_runs=min_shadow_runs,
    )
    if _state.json_output:
        _print_json(entries)
        return

    table = Table(title="Recovery Patch Promotion Queue")
    table.add_column("ID", justify="right")
    table.add_column("Platform")
    table.add_column("Flow")
    table.add_column("State")
    table.add_column("Shadow")
    table.add_column("Ready")
    table.add_column("Basis")
    table.add_column("Blocking")
    for entry in entries:
        table.add_row(
            str(entry["id"]),
            entry["platform"],
            entry["flow"],
            entry["state"],
            str(entry["shadow_run_count"]),
            "yes" if entry["promotion_ready"] else "no",
            entry["promotion_basis"],
            ", ".join(entry["blocking_reasons"]) or "-",
        )
    console.print(table)


@experience_patch_app.command("show")
def experience_patch_show(
    patch_id: Annotated[int, typer.Argument(help="要查看的 patch ID。")],
) -> None:
    """查看单个 recovery recipe patch 详情。"""
    store = _experience_store_from_config()
    patch = store.get_patch(patch_id)
    payload = {
        "id": patch["id"],
        "platform": patch["platform"],
        "flow": patch["flow"],
        "state": patch["state"],
        "source": patch["source"],
        "shadow_run_success": patch["shadow_run_success"],
        "shadow_run_count": patch["shadow_run_count"],
        "metadata": patch["metadata"],
        "recipe": patch["recipe"].model_dump(mode="json"),
        "created_at": patch["created_at"],
        "updated_at": patch["updated_at"],
    }
    if _state.json_output:
        _print_json(payload)
        return
    console.print_json(data=payload)


@experience_patch_app.command("review")
def experience_patch_review(
    patch_id: Annotated[int, typer.Argument(help="要标记 reviewed 的 patch ID。")],
    reviewer: Annotated[
        str,
        typer.Option("--reviewer", prompt=True, help="审查人标识。"),
    ],
    note: Annotated[
        str | None,
        typer.Option("--note", help="可选的审查说明。"),
    ] = None,
) -> None:
    """将 patch 标记为 reviewed。"""
    store = _experience_store_from_config()
    store.review_patch(patch_id, reviewer=reviewer, note=note)
    patch = store.get_patch(patch_id)
    _print_json({"id": patch_id, "state": patch["state"], "metadata": patch["metadata"]})


@experience_patch_app.command("shadow-pass")
def experience_patch_shadow_pass(
    patch_id: Annotated[int, typer.Argument(help="要标记 shadow-run success 的 patch ID。")],
    note: Annotated[
        str | None,
        typer.Option("--note", help="可选的 shadow-run 说明。"),
    ] = None,
) -> None:
    """记录 patch 已通过 shadow-run。"""
    store = _experience_store_from_config()
    metadata = {"shadow_run_note": note} if note else None
    store.mark_shadow_run_success(patch_id, metadata=metadata)
    patch = store.get_patch(patch_id)
    _print_json(
        {
            "id": patch_id,
            "state": patch["state"],
            "shadow_run_success": patch["shadow_run_success"],
            "metadata": patch["metadata"],
        }
    )


@experience_patch_app.command("promote")
def experience_patch_promote(
    patch_id: Annotated[int, typer.Argument(help="要提升到 mainline 的 patch ID。")],
) -> None:
    """将已 reviewed 或 shadow-run 成功的 patch 提升为 mainline。"""
    from payswitch.experience.models import RecipePatchState

    store = _experience_store_from_config()
    store.update_patch_state(patch_id, state=RecipePatchState.mainline)
    patch = store.get_patch(patch_id)
    _print_json({"id": patch_id, "state": patch["state"], "metadata": patch["metadata"]})


@experience_patch_app.command("promote-ready")
def experience_patch_promote_ready(
    platform: Annotated[
        str | None,
        typer.Option("--platform", help="按平台过滤，如 kimi。"),
    ] = None,
    flow: Annotated[
        str | None,
        typer.Option("--flow", help="按 flow 过滤，如 membership_monthly_qr。"),
    ] = None,
    source: Annotated[
        str | None,
        typer.Option("--source", help="按 source 过滤，如 script_recovery。"),
    ] = None,
    basis: Annotated[
        str | None,
        typer.Option(
            "--basis",
            help="仅提升特定 readiness basis：reviewed 或 shadow_run_success。",
        ),
    ] = None,
    actor: Annotated[
        str,
        typer.Option("--actor", prompt=True, help="执行本次提升的人或系统标识。"),
    ] = "operator",
    note: Annotated[
        str | None,
        typer.Option("--note", help="本次批量提升说明。"),
    ] = None,
    limit: Annotated[
        int | None,
        typer.Option("--limit", min=1, help="最多提升多少条 ready patch。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="仅预览将要提升的 patch，不写入 mainline。"),
    ] = False,
    min_shadow_runs: Annotated[
        int,
        typer.Option("--min-shadow-runs", min=1, help="shadow-run 提升所需最小成功次数。"),
    ] = 1,
) -> None:
    """按 promotion queue readiness 批量提升 patch 到 mainline。"""
    store = _experience_store_from_config()
    resolved_basis = _resolve_promotion_basis(basis)
    promoted = store.promote_ready_patches(
        platform=platform,
        flow=flow,
        source=source,
        basis=resolved_basis,
        actor=actor,
        note=note,
        limit=limit,
        dry_run=dry_run,
        min_shadow_runs=min_shadow_runs,
    )
    if _state.json_output:
        _print_json(promoted)
        return

    table = Table(title="Recovery Patch Ready Promotion")
    table.add_column("ID", justify="right")
    table.add_column("Platform")
    table.add_column("Flow")
    table.add_column("Basis")
    table.add_column("Result")
    table.add_column("Actor")
    for entry in promoted:
        table.add_row(
            str(entry["id"]),
            entry["platform"],
            entry["flow"],
            entry["promotion_basis"],
            "dry-run" if entry["dry_run"] else entry["state"],
            entry["metadata"]["promoted_by"],
        )
    console.print(table)


@experience_patch_app.command("run-promoter")
def experience_patch_run_promoter(
    actor: Annotated[
        str,
        typer.Option("--actor", prompt=True, help="执行后台 promoter 的人或系统标识。"),
    ],
    note: Annotated[
        str | None,
        typer.Option("--note", help="本次后台提升说明。"),
    ] = None,
    platform: Annotated[
        str | None,
        typer.Option("--platform", help="按平台过滤，如 kimi。"),
    ] = None,
    flow: Annotated[
        str | None,
        typer.Option("--flow", help="按 flow 过滤，如 membership_monthly_qr。"),
    ] = None,
    source: Annotated[
        str | None,
        typer.Option("--source", help="按 patch source 过滤，如 script_recovery。"),
    ] = None,
    basis: Annotated[
        str | None,
        typer.Option("--basis", help="按 reviewed 或 shadow_run_success 过滤。"),
    ] = None,
    batch_limit: Annotated[
        int,
        typer.Option("--batch-limit", min=1, help="每轮最多提升多少条 ready patch。"),
    ] = 10,
    poll_interval_seconds: Annotated[
        float,
        typer.Option("--poll-interval-seconds", min=0.0, help="空转轮询间隔秒数。"),
    ] = 5.0,
    max_idle_polls: Annotated[
        int,
        typer.Option("--max-idle-polls", min=1, help="连续多少轮空转后退出。"),
    ] = 3,
    max_cycles: Annotated[
        int | None,
        typer.Option("--max-cycles", min=1, help="最多执行多少轮轮询。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="仅预览后台 promoter 的处理结果。"),
    ] = False,
    once: Annotated[
        bool,
        typer.Option("--once", help="只执行一轮，不进入空转轮询。"),
    ] = False,
    min_shadow_runs: Annotated[
        int,
        typer.Option("--min-shadow-runs", min=1, help="shadow-run 提升所需最小成功次数。"),
    ] = 1,
) -> None:
    """运行 ready patch promotion 的后台执行循环。"""
    from payswitch.experience import ReadyPatchPromotionRunner

    store = _experience_store_from_config()
    runner = ReadyPatchPromotionRunner(
        store,
        basis=_resolve_promotion_basis(basis),
        min_shadow_runs=min_shadow_runs,
        platform=platform,
        flow=flow,
        source=source,
        poll_interval_seconds=poll_interval_seconds,
        batch_limit=batch_limit,
        max_idle_polls=max_idle_polls,
    )
    if once:
        result = runner.run_once(
            actor=actor,
            note=note,
            dry_run=dry_run,
        )
        payload = {
            "promoted": result.promoted,
            "dry_run": result.dry_run,
            "items": result.items,
        }
        if _state.json_output:
            _print_json(payload)
            return
        console.print_json(data=payload)
        return

    summary = runner.run_loop(
        actor=actor,
        note=note,
        dry_run=dry_run,
        max_cycles=max_cycles,
    )
    if _state.json_output:
        _print_json(summary)
        return
    console.print_json(data=summary)


@experience_improvement_app.command("list")
def experience_improvement_list(
    status: Annotated[
        str | None,
        typer.Option("--status", help="按状态过滤：open/accepted/dismissed/applied。"),
    ] = None,
    platform: Annotated[
        str | None,
        typer.Option("--platform", help="按平台过滤，如 kimi。"),
    ] = None,
    flow: Annotated[
        str | None,
        typer.Option("--flow", help="按 flow 过滤，如 membership_monthly_qr。"),
    ] = None,
) -> None:
    """列出 recovery improvement queue。"""
    store = _experience_store_from_config()
    improvement_status = _resolve_improvement_status(status)
    entries = store.list_recovery_improvements(
        status=improvement_status,
        platform=platform,
        flow=flow,
    )
    if _state.json_output:
        _print_json(entries)
        return

    table = Table(title="Recovery Improvement Queue")
    table.add_column("ID", justify="right")
    table.add_column("Patch", justify="right")
    table.add_column("Platform")
    table.add_column("Flow")
    table.add_column("Status")
    table.add_column("Outcome")
    table.add_column("Waypoint")
    for entry in entries:
        table.add_row(
            str(entry["id"]),
            str(entry["patch_id"]),
            entry["platform"],
            entry["flow"],
            entry["status"],
            str(entry["summary"].get("outcome") or "-"),
            str(entry["summary"].get("waypoint_id") or "-"),
        )
    console.print(table)


@experience_improvement_app.command("show")
def experience_improvement_show(
    improvement_id: Annotated[int, typer.Argument(help="要查看的 improvement ID。")],
) -> None:
    """查看单个 recovery improvement 详情。"""
    store = _experience_store_from_config()
    entry = store.get_recovery_improvement(improvement_id)
    if _state.json_output:
        _print_json(entry)
        return
    console.print_json(data=entry)


@experience_improvement_app.command("accept")
def experience_improvement_accept(
    improvement_id: Annotated[int, typer.Argument(help="要标记 accepted 的 improvement ID。")],
    reviewer: Annotated[
        str,
        typer.Option("--reviewer", prompt=True, help="处理该 improvement 的人。"),
    ],
    note: Annotated[
        str | None,
        typer.Option("--note", help="可选说明。"),
    ] = None,
) -> None:
    """将 recovery improvement 标记为 accepted。"""
    from payswitch.experience.models import RecoveryImprovementStatus

    store = _experience_store_from_config()
    store.update_recovery_improvement_status(
        improvement_id,
        status=RecoveryImprovementStatus.accepted,
        reviewer=reviewer,
        note=note,
    )
    entry = store.get_recovery_improvement(improvement_id)
    _print_json(entry)


@experience_improvement_app.command("dismiss")
def experience_improvement_dismiss(
    improvement_id: Annotated[int, typer.Argument(help="要标记 dismissed 的 improvement ID。")],
    reviewer: Annotated[
        str,
        typer.Option("--reviewer", prompt=True, help="处理该 improvement 的人。"),
    ],
    note: Annotated[
        str | None,
        typer.Option("--note", help="可选说明。"),
    ] = None,
) -> None:
    """将 recovery improvement 标记为 dismissed。"""
    from payswitch.experience.models import RecoveryImprovementStatus

    store = _experience_store_from_config()
    store.update_recovery_improvement_status(
        improvement_id,
        status=RecoveryImprovementStatus.dismissed,
        reviewer=reviewer,
        note=note,
    )
    entry = store.get_recovery_improvement(improvement_id)
    _print_json(entry)


@experience_improvement_app.command("accept-open")
def experience_improvement_accept_open(
    reviewer: Annotated[
        str,
        typer.Option("--reviewer", prompt=True, help="执行 open-queue acceptor 的人或系统标识。"),
    ],
    note: Annotated[
        str | None,
        typer.Option("--note", help="本次自动 acceptance 说明。"),
    ] = None,
    platform: Annotated[
        str | None,
        typer.Option("--platform", help="按平台过滤，如 kimi。"),
    ] = None,
    flow: Annotated[
        str | None,
        typer.Option("--flow", help="按 flow 过滤，如 membership_monthly_qr。"),
    ] = None,
    limit: Annotated[
        int | None,
        typer.Option("--limit", min=1, help="最多处理多少条 open improvement。"),
    ] = None,
    basis: Annotated[
        str,
        typer.Option(
            "--basis",
            help="自动 acceptance 依据：reviewed 或 shadow_run_success。",
        ),
    ] = "shadow_run_success",
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="仅预览 open improvement acceptor 的结果。"),
    ] = False,
    min_shadow_runs: Annotated[
        int,
        typer.Option("--min-shadow-runs", min=1, help="shadow-run acceptance 所需最小成功次数。"),
    ] = 1,
) -> None:
    """按确定性策略将 open recovery improvements 推进到 accepted。"""
    store = _experience_store_from_config()
    resolved_basis = _resolve_improvement_acceptance_basis(basis)
    results = store.accept_open_recovery_improvements(
        reviewer=reviewer,
        note=note,
        platform=platform,
        flow=flow,
        limit=limit,
        basis=resolved_basis,
        dry_run=dry_run,
        min_shadow_runs=min_shadow_runs,
    )
    if _state.json_output:
        _print_json(results)
        return

    table = Table(title="Recovery Improvement Open-Queue Acceptor")
    table.add_column("Improvement", justify="right")
    table.add_column("Patch", justify="right")
    table.add_column("Platform")
    table.add_column("Flow")
    table.add_column("Action")
    table.add_column("Basis")
    table.add_column("Status")
    for entry in results:
        table.add_row(
            str(entry["improvement_id"]),
            str(entry["patch_id"]),
            entry["platform"],
            entry["flow"],
            "dry-run" if entry["dry_run"] else entry["action"],
            str(entry["promotion_basis"]),
            (
                f'{entry["improvement_status_before"]} -> '
                f'{entry["improvement_status_after"]}'
            ),
        )
    console.print(table)


@experience_improvement_app.command("process")
def experience_improvement_process(
    reviewer: Annotated[
        str,
        typer.Option("--reviewer", prompt=True, help="执行该 processor 的人或系统标识。"),
    ],
    note: Annotated[
        str | None,
        typer.Option("--note", help="本次批处理说明。"),
    ] = None,
    platform: Annotated[
        str | None,
        typer.Option("--platform", help="按平台过滤，如 kimi。"),
    ] = None,
    flow: Annotated[
        str | None,
        typer.Option("--flow", help="按 flow 过滤，如 membership_monthly_qr。"),
    ] = None,
    limit: Annotated[
        int | None,
        typer.Option("--limit", min=1, help="最多处理多少条 accepted improvement。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="仅预览 accepted improvement processor 的结果。"),
    ] = False,
) -> None:
    """处理 accepted recovery improvements 并推进 patch review 状态。"""
    store = _experience_store_from_config()
    results = store.process_accepted_recovery_improvements(
        reviewer=reviewer,
        note=note,
        platform=platform,
        flow=flow,
        limit=limit,
        dry_run=dry_run,
    )
    if _state.json_output:
        _print_json(results)
        return

    table = Table(title="Recovery Improvement Processor")
    table.add_column("Improvement", justify="right")
    table.add_column("Patch", justify="right")
    table.add_column("Platform")
    table.add_column("Flow")
    table.add_column("Action")
    table.add_column("Patch State")
    for entry in results:
        table.add_row(
            str(entry["improvement_id"]),
            str(entry["patch_id"]),
            entry["platform"],
            entry["flow"],
            "dry-run" if entry["dry_run"] else entry["action"],
            f'{entry["patch_state_before"]} -> {entry["patch_state_after"]}',
        )
    console.print(table)


@experience_improvement_app.command("run-loop")
def experience_improvement_run_loop(
    reviewer: Annotated[
        str,
        typer.Option("--reviewer", prompt=True, help="执行后台 improver 的人或系统标识。"),
    ],
    note: Annotated[
        str | None,
        typer.Option("--note", help="本次后台执行说明。"),
    ] = None,
    platform: Annotated[
        str | None,
        typer.Option("--platform", help="按平台过滤，如 kimi。"),
    ] = None,
    flow: Annotated[
        str | None,
        typer.Option("--flow", help="按 flow 过滤，如 membership_monthly_qr。"),
    ] = None,
    batch_limit: Annotated[
        int,
        typer.Option("--batch-limit", min=1, help="每轮最多处理多少条 accepted improvement。"),
    ] = 10,
    poll_interval_seconds: Annotated[
        float,
        typer.Option("--poll-interval-seconds", min=0.0, help="空转轮询间隔秒数。"),
    ] = 5.0,
    max_idle_polls: Annotated[
        int,
        typer.Option("--max-idle-polls", min=1, help="连续多少轮空转后退出。"),
    ] = 3,
    max_cycles: Annotated[
        int | None,
        typer.Option("--max-cycles", min=1, help="最多执行多少轮轮询。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="仅预览后台 improver 的处理结果。"),
    ] = False,
    once: Annotated[
        bool,
        typer.Option("--once", help="只执行一轮，不进入空转轮询。"),
    ] = False,
) -> None:
    """运行 accepted recovery improvements 的后台执行循环。"""
    from payswitch.experience import RecoveryImprovementRunner

    store = _experience_store_from_config()
    runner = RecoveryImprovementRunner(
        store,
        poll_interval_seconds=poll_interval_seconds,
        batch_limit=batch_limit,
        max_idle_polls=max_idle_polls,
    )
    if once:
        result = runner.run_once(
            reviewer=reviewer,
            note=note,
            platform=platform,
            flow=flow,
            dry_run=dry_run,
        )
        payload = {
            "processed": result.processed,
            "reviewed_patches": result.reviewed_patches,
            "already_reviewed": result.already_reviewed,
            "already_mainline": result.already_mainline,
            "dry_run": result.dry_run,
            "items": result.items,
        }
        if _state.json_output:
            _print_json(payload)
            return
        console.print_json(data=payload)
        return

    summary = runner.run_loop(
        reviewer=reviewer,
        note=note,
        platform=platform,
        flow=flow,
        dry_run=dry_run,
        max_cycles=max_cycles,
    )
    if _state.json_output:
        _print_json(summary)
        return
    console.print_json(data=summary)


@artifact_app.command("cleanup")
def artifact_cleanup(
    batch_limit: Annotated[
        int,
        typer.Option("--batch-limit", min=1, help="每轮最多清理多少个过期 artifact。"),
    ] = 25,
    poll_interval_seconds: Annotated[
        float,
        typer.Option("--poll-interval-seconds", min=0.0, help="空转轮询间隔秒数。"),
    ] = 5.0,
    max_idle_polls: Annotated[
        int,
        typer.Option("--max-idle-polls", min=1, help="连续多少轮空转后退出。"),
    ] = 3,
    max_cycles: Annotated[
        int | None,
        typer.Option("--max-cycles", min=1, help="最多执行多少轮轮询。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="仅预览 cleanup 结果，不实际删除文件。"),
    ] = False,
    once: Annotated[
        bool,
        typer.Option("--once", help="只执行一轮，不进入空转轮询。"),
    ] = False,
) -> None:
    """执行 artifact retention cleanup。"""
    from payswitch.security.cleanup import ArtifactCleanupRunner

    runner = ArtifactCleanupRunner(
        _artifact_store_from_config(),
        poll_interval_seconds=poll_interval_seconds,
        batch_limit=batch_limit,
        max_idle_polls=max_idle_polls,
    )
    if once:
        result = runner.run_once(dry_run=dry_run)
        payload = {
            "cleaned": result.cleaned,
            "deleted": result.deleted,
            "metadata_only": result.metadata_only,
            "dry_run": result.dry_run,
            "items": result.items,
        }
        if _state.json_output:
            _print_json(payload)
            return
        console.print_json(data=payload)
        return

    summary = runner.run_loop(
        dry_run=dry_run,
        max_cycles=max_cycles,
    )
    if _state.json_output:
        _print_json(summary)
        return
    console.print_json(data=summary)


@artifact_app.command("stats")
def artifact_stats(
    budget_mb: Annotated[
        float | None,
        typer.Option("--budget-mb", min=0.0, help="可选的 artifact 磁盘预算（MB）。"),
    ] = None,
) -> None:
    """查看当前 artifact inventory 和 budget 信号。"""
    budget_bytes = None if budget_mb is None else int(budget_mb * 1024 * 1024)
    payload = _artifact_store_from_config().inventory(budget_bytes=budget_bytes)
    if _state.json_output:
        _print_json(payload)
        return
    console.print_json(data=payload)


@artifact_app.command("inbox")
def artifact_inbox(
    include_public_key: Annotated[
        bool,
        typer.Option("--include-public-key", help="输出本机 artifact inbox 的 public key。"),
    ] = False,
) -> None:
    """查看当前主机的 artifact inbox 信息。"""
    payload = _artifact_store_from_config().local_inbox_summary(
        include_public_key=include_public_key
    )
    if _state.json_output:
        _print_json(payload)
        return
    console.print_json(data=payload)


@artifact_app.command("rotate-inbox")
def artifact_rotate_inbox(
    reencrypt_existing: Annotated[
        bool,
        typer.Option(
            "--reencrypt-existing",
            help="存在加密 artifact 时，先重加密再切换本机 inbox key。",
        ),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="仅预览 inbox rotation 结果，不实际写入。"),
    ] = False,
) -> None:
    """轮换当前主机的 artifact inbox key。"""
    store = _artifact_store_from_config()
    try:
        payload = store.rotate_local_inbox(
            reencrypt_existing=reencrypt_existing,
            dry_run=dry_run,
        )
    except ValueError as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1) from exc
    if _state.json_output:
        _print_json(payload)
        return
    console.print_json(data=payload)


@artifact_app.command("export")
def artifact_export(
    path: Annotated[
        Path,
        typer.Option(
            "--path",
            exists=True,
            dir_okay=False,
            resolve_path=True,
            help="要导出的 artifact 路径。",
        ),
    ],
    recipient_public_key: Annotated[
        str,
        typer.Option(
            "--recipient-public-key",
            help="接收端 host 的 artifact inbox public key。",
        ),
    ],
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            dir_okay=False,
            resolve_path=True,
            help="可选：将 handoff bundle 写入文件。",
        ),
    ] = None,
) -> None:
    """导出跨主机 handoff bundle。"""
    payload = _artifact_store_from_config().export_handoff_bundle(
        path,
        recipient_public_key=recipient_public_key,
    )
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        result: dict[str, Any] = {
            "bundle_path": str(output),
            "recipient_id": payload["envelope"].get("recipient_id"),
            "artifact_path": payload["artifact"].get("path"),
        }
    else:
        result = payload
    if _state.json_output:
        _print_json(result)
        return
    console.print_json(data=result)


@artifact_app.command("import")
def artifact_import(
    bundle: Annotated[
        Path,
        typer.Option(
            "--bundle",
            exists=True,
            dir_okay=False,
            resolve_path=True,
            help="artifact handoff bundle JSON 文件。",
        ),
    ],
    path: Annotated[
        Path | None,
        typer.Option(
            "--path",
            dir_okay=False,
            resolve_path=True,
            help="可选：覆盖导入目标路径。",
        ),
    ] = None,
) -> None:
    """导入跨主机 handoff bundle。"""
    payload = json.loads(bundle.read_text(encoding="utf-8"))
    store = _artifact_store_from_config()
    imported = store.import_handoff_bundle(payload, target_path=path)
    result = {
        "imported_path": str(imported),
        "content_type": store.read_content_type(imported),
        "metadata": store.read_metadata(imported).get("metadata", {}),
    }
    if _state.json_output:
        _print_json(result)
        return
    console.print_json(data=result)


@artifact_app.command("enforce-budget")
def artifact_enforce_budget(
    budget_mb: Annotated[
        float | None,
        typer.Option(
            "--budget-mb",
            min=0.0,
            help="artifact 磁盘预算（MB）。未提供时回退到 PAYSWITCH_ARTIFACT_STORAGE_BUDGET_MB。",
        ),
    ] = None,
    target_ratio: Annotated[
        float,
        typer.Option("--target-ratio", min=0.01, max=1.0, help="回收到预算的比例阈值。"),
    ] = 0.9,
    batch_limit: Annotated[
        int,
        typer.Option("--batch-limit", min=1, help="每轮最多处理多少个 artifact。"),
    ] = 25,
    poll_interval_seconds: Annotated[
        float,
        typer.Option("--poll-interval-seconds", min=0.0, help="空转轮询间隔秒数。"),
    ] = 5.0,
    max_idle_polls: Annotated[
        int,
        typer.Option("--max-idle-polls", min=1, help="连续多少轮无动作后退出。"),
    ] = 3,
    max_cycles: Annotated[
        int | None,
        typer.Option("--max-cycles", min=1, help="最多执行多少轮轮询。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="仅预览 budget enforcement，不实际删除文件。"),
    ] = False,
    once: Annotated[
        bool,
        typer.Option("--once", help="只执行一轮，不进入空转轮询。"),
    ] = False,
    include_sensitive: Annotated[
        bool,
        typer.Option("--include-sensitive", help="允许回收 sensitive artifact。"),
    ] = False,
) -> None:
    """执行 artifact storage-budget enforcement。"""
    from payswitch.security.cleanup import ArtifactBudgetEnforcementRunner

    effective_budget_mb = budget_mb
    if effective_budget_mb is None:
        raw = os.getenv("PAYSWITCH_ARTIFACT_STORAGE_BUDGET_MB", "").strip()
        if raw:
            effective_budget_mb = float(raw)
    if effective_budget_mb is None or effective_budget_mb <= 0:
        _print_error(
            "缺少 artifact budget，请传入 --budget-mb 或配置 "
            "PAYSWITCH_ARTIFACT_STORAGE_BUDGET_MB。"
        )
        raise typer.Exit(code=1)

    runner = ArtifactBudgetEnforcementRunner(
        _artifact_store_from_config(),
        budget_bytes=int(effective_budget_mb * 1024 * 1024),
        target_ratio=target_ratio,
        poll_interval_seconds=poll_interval_seconds,
        batch_limit=batch_limit,
        max_idle_polls=max_idle_polls,
        include_sensitive=include_sensitive,
    )
    if once:
        result = runner.run_once(dry_run=dry_run)
        payload = {
            "triggered": result.triggered,
            "cleaned": result.cleaned,
            "deleted": result.deleted,
            "metadata_only": result.metadata_only,
            "reclaimed_bytes": result.reclaimed_bytes,
            "budget_bytes": result.budget_bytes,
            "target_bytes": result.target_bytes,
            "projected_total_bytes": result.projected_total_bytes,
            "projected_over_budget": result.projected_over_budget,
            "within_target": result.within_target,
            "dry_run": result.dry_run,
            "include_sensitive": result.include_sensitive,
            "items": result.items,
        }
        if _state.json_output:
            _print_json(payload)
            return
        console.print_json(data=payload)
        return

    summary = runner.run_loop(
        dry_run=dry_run,
        max_cycles=max_cycles,
    )
    if _state.json_output:
        _print_json(summary)
        return
    console.print_json(data=summary)


@app.command("serve")
def serve(
    host: Annotated[
        str,
        typer.Option("--host", help="监听地址。生产部署通常使用 0.0.0.0。"),
    ] = "0.0.0.0",
    port: Annotated[
        int,
        typer.Option("--port", help="监听端口。"),
    ] = 8787,
    reload: Annotated[
        bool,
        typer.Option("--reload", help="开发模式：代码变更时自动重启。"),
    ] = False,
) -> None:
    """启动 Pay-Switch Agent HTTP/A2A 服务。"""

    try:
        import uvicorn
    except ImportError as exc:
        _print_error("缺少 uvicorn/fastapi 依赖，请安装：pip install 'payswitch[stripe]'")
        raise typer.Exit(code=1) from exc

    if not _state.json_output:
        console.print(
            Panel(
                f"[bold]Dashboard[/bold] http://{host}:{port}\n"
                f"[bold]REST[/bold]      POST /api/payments\n"
                f"[bold]A2A[/bold]       /.well-known/agent-card.json, /message:send\n"
                f"[bold]SSE[/bold]       /events?session_id=<task_id>",
                title="[cyan]Pay-Switch Agent[/cyan]",
                border_style="cyan",
            )
        )

    uvicorn.run("payswitch.server:app", host=host, port=port, reload=reload)


@agent_app.command("psl")
def agent_psl(
    amount: Annotated[float, typer.Argument(help="支付金额。")],
    payee: Annotated[str, typer.Argument(help="收款方/平台标识，如 deepseek。")],
    reason: Annotated[
        str,
        typer.Option("--reason", "-r", help="支付原因。"),
    ] = "",
    currency: Annotated[
        str,
        typer.Option("--currency", "-c", help="货币代码。"),
    ] = "CNY",
    method: Annotated[
        str,
        typer.Option("--method", "-m", help="支付方式：auto/alipay_qr/wechat_qr/stripe 等。"),
    ] = "auto",
    idempotency_key: Annotated[
        str | None,
        typer.Option("--idempotency-key", help="幂等键。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="生成 dry-run PSL。"),
    ] = False,
) -> None:
    """生成一条稳定的 Pay-Switch Language 指令。"""

    from payswitch.agent_language import PaymentIntent, to_psl
    from payswitch.models.types import PaymentMethod

    intent = PaymentIntent(
        amount=amount,
        payee=payee,
        reason=reason,
        currency=currency,
        method=PaymentMethod(method),
        idempotency_key=idempotency_key,
        dry_run=dry_run,
        source_agent="cli",
    )
    if _state.json_output:
        _print_json({"psl": to_psl(intent), "intent": intent.model_dump(mode="json")})
    else:
        console.print(to_psl(intent))


@agent_app.command("send")
def agent_send(
    text: Annotated[
        str,
        typer.Argument(help='PSL 或 JSON 意图，例如：PAY 200 CNY TO deepseek FOR "API top-up"'),
    ],
    server: Annotated[
        str,
        typer.Option("--server", help="Pay-Switch Agent 服务地址。"),
    ] = "http://127.0.0.1:8787",
    token: Annotated[
        str | None,
        typer.Option("--token", envvar="PAYSWITCH_AGENT_TOKEN", help="服务 Bearer token。"),
    ] = None,
) -> None:
    """把 PSL/JSON 支付意图发送给本机或远端 Pay-Switch Agent 服务。"""

    from payswitch.agent_language import intent_from_text

    try:
        import httpx
    except ImportError as exc:
        _print_error("缺少 httpx 依赖，请安装当前项目依赖后重试。")
        raise typer.Exit(code=1) from exc

    intent = intent_from_text(text, source_agent="cli")
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    try:
        response = httpx.post(
            f"{server.rstrip('/')}/api/payments",
            headers=headers,
            json=intent.model_dump(mode="json"),
            timeout=30,
        )
        response.raise_for_status()
    except Exception as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1) from exc

    data = response.json()
    if _state.json_output:
        _print_json(data)
        return
    console.print(
        Panel(
            f"[bold]task_id[/bold] {data.get('task_id')}\n"
            f"[bold]psl[/bold]     {data.get('psl')}\n"
            f"[bold]events[/bold]  {server.rstrip('/')}{data.get('events_url')}",
            title="[green]Pay-Switch request submitted[/green]",
            border_style="green",
        )
    )


@agent_app.command("card")
def agent_card(
    server: Annotated[
        str,
        typer.Option("--server", help="Pay-Switch Agent 服务地址。"),
    ] = "http://127.0.0.1:8787",
) -> None:
    """读取并打印 A2A Agent Card。"""

    try:
        import httpx

        response = httpx.get(f"{server.rstrip('/')}/.well-known/agent-card.json", timeout=15)
        response.raise_for_status()
        _print_json(response.json())
    except Exception as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1) from exc


# ---------------------------------------------------------------------------
# setup — 初始化环境
# ---------------------------------------------------------------------------
@app.command("setup")
def setup(
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="强制重新初始化，覆盖已有配置。"),
    ] = False,
) -> None:
    """初始化 Pay-Switch 运行环境。

    安装 Playwright 浏览器、创建配置目录 (~/.payswitch/)，
    并引导完成首次配置（限额、LLM API Key 等）。

    示例：
      payswitch setup
      payswitch setup --force
    """
    from payswitch.browser.display import detect_display_mode
    from payswitch.models.config import PaySwitchConfig

    # 加载或创建配置
    config_path = Path.home() / ".payswitch" / "config.json"
    config = PaySwitchConfig.load()

    # 检测是否已完成 setup（配置文件存在且有 API Key）
    already_configured = config_path.exists() and bool(config.llm_api_key)

    if already_configured and not force:
        console.print(
            Panel(
                "[green]Pay-Switch 已完成初始化配置。[/green]\n"
                "使用 [bold]--force[/bold] 选项重新配置。",
                title="[cyan]初始化状态[/cyan]",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    console.print(
        Panel(
            "[bold cyan]Pay-Switch 初始化向导[/bold cyan]\n[dim]将引导您完成三步配置流程[/dim]",
            border_style="cyan",
            padding=(1, 2),
        )
    )

    # ----------------------------------------------------------------
    # 步骤 1：检测/配置浏览器
    # 三级 fallback：系统 Chrome/Edge → 已有 Playwright Chromium → 下载
    # ----------------------------------------------------------------
    console.print("\n[bold yellow]步骤 1/3[/bold yellow]  检测浏览器环境")

    browser_ready = False

    if not force:
        # Level 1：检测系统 Chrome / Edge
        system_browser = _detect_system_browser()
        if system_browser:
            config.browser_channel = system_browser
            config.save()
            console.print(
                f"  [green]OK[/green] 检测到系统 {system_browser}，将直接使用（无需下载 Chromium）"
            )
            browser_ready = True

        # Level 2：检测已有 Playwright Chromium
        if not browser_ready and _detect_playwright_chromium():
            console.print("  [green]OK[/green] Playwright Chromium 已安装，跳过下载")
            browser_ready = True

    # Level 3：都没有（或 --force），下载 Playwright Chromium
    if not browser_ready:
        console.print("  正在下载并安装 Chromium，请稍候...")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "playwright", "install", "chromium"],
                capture_output=not _state.verbose,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=300,
            )
            if result.returncode == 0:
                console.print("  [green]OK[/green] Chromium 安装成功")
            else:
                error_detail = result.stderr if result.stderr else "未知错误"
                _print_error(f"Chromium 安装失败：{error_detail}")
                raise typer.Exit(code=1)
        except subprocess.TimeoutExpired:
            _print_error("Chromium 安装超时（超过 5 分钟），请检查网络连接后重试")
            raise typer.Exit(code=1)
        except FileNotFoundError:
            _print_error("未找到 Python 解释器，请确认 Playwright 已通过 pip 安装")
            raise typer.Exit(code=1)

    # ----------------------------------------------------------------
    # 步骤 2：配置 LLM 后端
    # ----------------------------------------------------------------
    console.print("\n[bold yellow]步骤 2/3[/bold yellow]  配置 Skyvern LLM 后端")

    # 若已有配置且非 force 模式，询问是否跳过
    if config.llm_api_key and not force:
        skip = typer.confirm(
            "  已检测到已有 LLM 配置，是否跳过重新配置？",
            default=True,
        )
        if skip:
            console.print("  [green]OK[/green] 跳过 LLM 配置（使用已有配置）")
        else:
            config = _configure_llm(config)
    else:
        config = _configure_llm(config)

    # ----------------------------------------------------------------
    # 步骤 3：检测运行环境
    # ----------------------------------------------------------------
    console.print("\n[bold yellow]步骤 3/3[/bold yellow]  检测运行环境")

    display_mode = detect_display_mode()
    mode_desc = {
        "headed": "本地有头浏览器（有图形界面）",
        "novnc": "noVNC 远程访问（无图形界面服务器）",
    }.get(display_mode.value, display_mode.value)

    console.print(f"  [green]OK[/green] 检测到运行环境：[bold]{mode_desc}[/bold]")

    # 将检测到的 display_mode 保存到配置
    config = config.update(display_mode=display_mode)

    # 完成提示
    console.print(
        Panel(
            "[bold green]Pay-Switch 初始化完成！[/bold green]\n\n"
            "接下来您可以：\n"
            "  [cyan]payswitch login <platform>[/cyan]   — 登录支付平台\n"
            "  [cyan]payswitch spend <amount> <payee>[/cyan] — 发起支付\n"
            "  [cyan]payswitch --help[/cyan]             — 查看完整帮助",
            title="[green]初始化成功[/green]",
            border_style="green",
            padding=(1, 2),
        )
    )


def _configure_llm(config) -> object:
    """引导用户配置 LLM 后端，返回更新后的配置。"""
    console.print("  请选择 LLM Provider：")
    console.print("    [bold]1[/bold] OpenAI（GPT-4o）")
    console.print("    [bold]2[/bold] Anthropic（Claude）")
    console.print("    [bold]3[/bold] Google（Gemini）")
    console.print("    [bold]4[/bold] 本地（Ollama / LM Studio）")

    provider_choice = typer.prompt(
        "  请输入选项编号",
        default="1",
    )

    provider_map = {
        "1": ("openai", "gpt-4o"),
        "2": ("anthropic", "claude-3-5-sonnet-20241022"),
        "3": ("google", "gemini-1.5-pro"),
        "4": ("local", "llama3"),
    }

    if provider_choice not in provider_map:
        console.print(f"  [yellow]无效选项 '{provider_choice}'，使用默认 OpenAI[/yellow]")
        provider_choice = "1"

    provider_name, default_model = provider_map[provider_choice]

    if provider_choice == "4":
        # 本地模型不需要 API Key
        api_key_plain = ""
        console.print("  [dim]本地模式无需 API Key[/dim]")
    else:
        api_key_plain = typer.prompt(
            f"  请输入 {provider_name.title()} API Key",
            hide_input=True,
        )
        if not api_key_plain.strip():
            console.print("  [yellow]警告：未输入 API Key，智能模式将无法使用[/yellow]")

    # 允许用户自定义模型名称
    model_name = typer.prompt(
        "  模型名称",
        default=default_model,
    )

    # 保存配置
    config = config.update(llm_provider=provider_name, llm_model=model_name)
    if api_key_plain.strip():
        config = config.set_llm_api_key(api_key_plain.strip())

    console.print(
        f"  [green]OK[/green] LLM 配置已保存："
        f"[bold]{provider_name}[/bold] / [bold]{model_name}[/bold]"
    )
    return config


# ---------------------------------------------------------------------------
# login — 登录平台
# ---------------------------------------------------------------------------
@app.command("login")
def login(
    platform: Annotated[
        str | None,
        typer.Argument(help="平台标识，如 deepseek / kimi / zhipu。"),
    ] = None,
    headed: Annotated[
        bool,
        typer.Option("--headed", help="强制使用有头浏览器（默认自动检测）。"),
    ] = False,
    list_profiles: Annotated[
        bool,
        typer.Option("--list", "-l", help="列出所有已登录的 Profile。"),
    ] = False,
    logout: Annotated[
        bool,
        typer.Option("--logout", help="退出登录（删除指定平台的 Profile）。"),
    ] = False,
    non_interactive: Annotated[
        bool,
        typer.Option(
            "--non-interactive",
            help="非交互模式：不需要按 Enter，用户关闭浏览器窗口即完成登录。"
            " Agent 环境下自动启用。",
        ),
    ] = False,
    login_url: Annotated[
        str | None,
        typer.Option("--url", help="手动指定登录 URL（跳过适配器查找和 URL 输入提示）。"),
    ] = None,
    timeout: Annotated[
        int,
        typer.Option("--timeout", help="非交互模式下的超时时间（秒）。"),
    ] = 300,
) -> None:
    """登录并保存指定平台的浏览器 Profile。

    打开浏览器引导你完成登录，登录状态会持久化保存，
    后续支付操作无需重新登录。

    示例：
      payswitch login deepseek
      payswitch login kimi --headed
      payswitch login --list
      payswitch login deepseek --logout
      payswitch login minimax --non-interactive --url https://platform.minimaxi.com/login
    """
    from payswitch.browser.profiles import ProfileManager
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    profiles_dir = config.data_dir / "profiles"
    profile_manager = ProfileManager(data_dir=profiles_dir)

    # --list 模式：列出所有 Profile
    if list_profiles:
        _login_list_profiles(profile_manager)
        return

    # platform 参数对于 --logout 和正常登录都是必须的
    if platform is None:
        _print_error("请指定平台标识，例如：payswitch login deepseek")
        raise typer.Exit(code=1)

    # --logout 模式：删除指定平台的 Profile
    if logout:
        _login_logout(platform, profile_manager)
        return

    # 自动检测：stdin 不可用时自动进入非交互模式
    use_non_interactive = non_interactive or not sys.stdin.isatty()

    # 正常登录流程
    asyncio.run(
        _login_browser(
            platform,
            headed,
            config,
            profile_manager,
            non_interactive=use_non_interactive,
            login_url=login_url,
            timeout=timeout,
        )
    )


def _login_list_profiles(profile_manager) -> None:
    """列出所有已保存的 Profile。"""
    profiles = profile_manager.list_profiles()

    if _state.json_output:
        data = [
            {
                "platform": p.platform,
                "display_name": p.display_name,
                "status": p.status,
                "logged_in_at": str(p.logged_in_at) if p.logged_in_at else None,
                "last_used_at": str(p.last_used_at) if p.last_used_at else None,
            }
            for p in profiles
        ]
        _print_json(data)
        return

    if not profiles:
        console.print("[dim]暂无已登录的平台 Profile。[/dim]")
        console.print("使用 [bold cyan]payswitch login <platform>[/bold cyan] 登录平台。")
        return

    table = Table(title="已登录的平台 Profile", border_style="cyan")
    table.add_column("平台标识", style="bold cyan")
    table.add_column("展示名称")
    table.add_column("状态")
    table.add_column("登录时间")
    table.add_column("最近使用")

    for profile in profiles:
        status_style = {
            "active": "green",
            "expired": "yellow",
            "unknown": "dim",
        }.get(profile.status, "white")

        status_label = {
            "active": "活跃",
            "expired": "已过期",
            "unknown": "未知",
        }.get(profile.status, profile.status)

        table.add_row(
            profile.platform,
            profile.display_name,
            f"[{status_style}]{status_label}[/{status_style}]",
            _format_datetime(profile.logged_in_at),
            _format_datetime(profile.last_used_at),
        )

    console.print(table)


def _login_logout(platform: str, profile_manager) -> None:
    """退出登录，删除指定平台 Profile。"""
    existing = profile_manager.get_profile(platform)
    if existing is None:
        _print_error(f"平台 '{platform}' 的 Profile 不存在，无需退出登录")
        raise typer.Exit(code=1)

    confirmed = typer.confirm(
        f"确认退出 '{platform}' 的登录？此操作将删除本地保存的登录状态。",
        default=False,
    )
    if not confirmed:
        console.print("[dim]已取消退出登录操作。[/dim]")
        return

    profile_manager.delete_profile(platform)

    if _state.json_output:
        _print_json({"success": True, "platform": platform})
    else:
        console.print(f"[green]OK[/green] 已退出 [bold]{platform}[/bold] 的登录。")


async def _login_browser(
    platform: str,
    headed: bool,
    config,
    profile_manager,
    *,
    non_interactive: bool = False,
    login_url: str | None = None,
    timeout: int = 300,
) -> None:
    """启动浏览器引导用户完成登录。

    支持两种模式：
    - 交互模式（默认）：等待用户按 Enter 确认
    - 非交互模式：监听浏览器关闭事件或超时自动保存
    """
    from payswitch.adapters import AdapterRegistry
    from payswitch.browser.controller import BrowserController
    from payswitch.browser.display import detect_display_mode

    # 确定登录 URL：命令行参数 > 适配器预设 > 用户手动输入
    adapter = AdapterRegistry.get(platform)
    display_name = platform

    if login_url:
        # 用户通过 --url 指定了登录 URL，直接使用
        if adapter is not None:
            display_name = adapter.__class__.display_name
    elif adapter is not None:
        login_url = adapter.__class__.login_url
        display_name = adapter.__class__.display_name
    elif non_interactive:
        # 非交互模式下没有适配器也没有 --url，无法继续
        _print_error(
            f"未找到平台 '{platform}' 的适配器，非交互模式下请通过 --url 参数提供登录页面 URL。"
        )
        raise typer.Exit(code=1)
    else:
        # 交互模式：提示用户输入
        console.print(
            f"[yellow]未找到平台 '{platform}' 的适配器，请手动输入登录页面 URL。[/yellow]"
        )
        login_url = typer.prompt("请输入登录页面 URL")

    if not login_url:
        _print_error("登录 URL 为空，无法继续")
        raise typer.Exit(code=1)

    # 创建或获取 Profile
    profile_manager.create_profile(
        platform=platform,
        display_name=display_name,
        top_up_url=adapter.__class__.top_up_url if adapter else None,
    )
    profile_dir = profile_manager.get_profile_dir(platform)

    # 非交互模式下强制使用有头浏览器（用户需要看到窗口才能手动登录）
    if non_interactive:
        use_headless = False
    elif headed:
        use_headless = False
    else:
        detected_mode = detect_display_mode()
        from payswitch.models.types import DisplayMode

        use_headless = detected_mode != DisplayMode.headed

    mode_label = "非交互" if non_interactive else "交互"
    from payswitch.browser.runtime import (
        BrowserRuntimeConfigError,
        build_browser_runtime_plan,
    )

    try:
        browser_plan = build_browser_runtime_plan(config, ensure_cdp=True)
    except BrowserRuntimeConfigError as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1)
    uses_user_chrome = browser_plan.uses_user_chrome
    profile_dir = None if uses_user_chrome else profile_manager.get_profile_dir(platform)
    chrome_kwargs = browser_plan.launch_kwargs

    console.print(
        Panel(
            f"[bold]平台：[/bold]{display_name}\n"
            f"[bold]登录页面：[/bold]{login_url}\n"
            f"[bold]浏览器模式：[/bold]{'有头（可见窗口）' if not use_headless else '无头'}\n"
            f"[bold]交互模式：[/bold]{mode_label}\n"
            f"[bold]浏览器上下文：[/bold]"
            f"{'用户绑定的真实 Chrome profile' if uses_user_chrome else 'Pay-Switch 自管 profile'}",
            title="[cyan]准备登录[/cyan]",
            border_style="cyan",
        )
    )

    browser = BrowserController()
    try:
        console.print("[dim]正在启动浏览器...[/dim]")
        await browser.launch(
            profile_dir=profile_dir,
            headless=use_headless,
            **chrome_kwargs,
        )

        console.print(f"[dim]正在导航到登录页面：{login_url}[/dim]")
        await browser.navigate(login_url)

        if non_interactive:
            # 非交互模式：监听浏览器关闭事件或超时
            console.print(
                Panel(
                    f"[bold yellow]请在浏览器中完成 {display_name} 的登录操作[/bold yellow]\n\n"
                    f"完成后 [bold]直接关闭浏览器窗口[/bold] 即可保存登录状态。\n"
                    f"超时时间：{timeout} 秒",
                    title="[yellow]等待登录（非交互模式）[/yellow]",
                    border_style="yellow",
                    padding=(1, 2),
                )
            )
            await _wait_for_browser_close_or_timeout(browser, timeout)
        else:
            # 交互模式：等待用户按 Enter
            console.print(
                Panel(
                    f"[bold yellow]请在浏览器中完成 {display_name} 的登录操作"
                    "[/bold yellow]\n\n"
                    "完成登录后，返回此终端并按 [bold]Enter[/bold] 键确认保存登录状态。",
                    title="[yellow]等待登录[/yellow]",
                    border_style="yellow",
                    padding=(1, 2),
                )
            )
            typer.prompt("按 Enter 键确认已完成登录", default="", show_default=False)

        # 登录确认后做一次轻量校验（浏览器已关闭的情况下跳过校验）
        page = browser.page
        if page and not page.is_closed():
            if not await _verify_login_state(page, platform):
                console.print(
                    f"[yellow]提示：未检测到 {display_name} 的明确登录态，"
                    "但仍已保存浏览器状态。[/yellow]"
                )

        # 保存 Profile：更新登录时间和状态
        profile_manager.update_login_time(platform)

        if _state.json_output:
            _print_json(
                {
                    "success": True,
                    "platform": platform,
                    "display_name": display_name,
                    "status": "active",
                    "non_interactive": non_interactive,
                }
            )
        else:
            console.print(f"[green]OK[/green] 已成功保存 [bold]{display_name}[/bold] 的登录状态。")

    except Exception as exc:
        _print_error(f"登录过程中发生错误：{exc}")
        raise typer.Exit(code=1)
    finally:
        await browser.close()


async def _wait_for_browser_close_or_timeout(
    browser,
    timeout: int,
) -> None:
    """等待浏览器被用户关闭或超时自动退出。

    非交互模式的核心等待逻辑：
    - 用户关闭浏览器窗口 → 视为登录完成
    - 超时 → 自动保存当前状态并退出
    """
    page = browser.page
    if page is None:
        return

    closed = asyncio.Event()

    def _on_close():
        closed.set()

    page.on("close", _on_close)

    try:
        await asyncio.wait_for(closed.wait(), timeout=timeout)
        console.print("[dim]浏览器已关闭，保存登录状态...[/dim]")
    except TimeoutError:
        console.print(f"[yellow]登录等待超时（{timeout} 秒），自动保存当前状态。[/yellow]")


async def _verify_login_state(page, platform: str) -> bool:
    """在用户按 Enter 后做一次轻量登录态校验。"""
    current_url = page.url.lower()
    if any(token in current_url for token in ("login", "sign_in", "signin", "passport")):
        return False

    if platform == "kimi":
        login_prompt_selectors = (
            "text=登录以同步历史会话",
            "text=Log in to sync chat history",
            "text=Log In",
        )
        for selector in login_prompt_selectors:
            if await page.locator(selector).count() > 0:
                return False
        return True

    return True


# ---------------------------------------------------------------------------
# browser-lite — 轻量浏览器识别/点击（本地 computer-use 能力）
# ---------------------------------------------------------------------------
@app.command("browser-lite")
def browser_lite(
    platform: Annotated[
        str,
        typer.Argument(help="平台标识（用于复用本地登录 Profile），如 kimi / deepseek。"),
    ],
    url: Annotated[
        str,
        typer.Option("--url", help="目标页面 URL。"),
    ],
    click_index: Annotated[
        int | None,
        typer.Option("--click-index", help="识别后按索引点击（0-based）。"),
    ] = None,
    click_text: Annotated[
        str | None,
        typer.Option("--click-text", help="识别后按文本匹配点击（模糊匹配）。"),
    ] = None,
    exact: Annotated[
        bool,
        typer.Option("--exact", help="与 --click-text 搭配，启用精确匹配。"),
    ] = False,
    limit: Annotated[
        int,
        typer.Option("--limit", help="最多输出多少个可点击元素。"),
    ] = 40,
    wait_seconds: Annotated[
        float,
        typer.Option("--wait-seconds", help="导航完成后额外等待多少秒再识别。"),
    ] = 2.0,
    headed: Annotated[
        bool,
        typer.Option("--headed", help="强制使用有头浏览器。"),
    ] = False,
) -> None:
    """轻量 browser control 调试命令：识别可点击元素并执行一次点击。"""
    from payswitch.browser.profiles import ProfileManager
    from payswitch.browser.runtime import (
        BrowserRuntimeConfigError,
        build_browser_runtime_plan,
    )
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    profile_manager = ProfileManager(data_dir=config.data_dir / "profiles")
    profile = profile_manager.get_profile(platform)
    try:
        browser_plan = build_browser_runtime_plan(
            config,
            validate_identity=False,
            ensure_cdp=False,
        )
    except BrowserRuntimeConfigError as exc:
        _print_error(str(exc))
        raise typer.Exit(code=1)
    uses_user_chrome = browser_plan.uses_user_chrome
    if profile is None and not uses_user_chrome:
        _print_error(f"平台 '{platform}' 的 Profile 不存在，请先执行 payswitch login {platform}")
        raise typer.Exit(code=1)

    asyncio.run(
        _browser_lite_run(
            platform=platform,
            url=url,
            headed=headed,
            limit=limit,
            wait_seconds=wait_seconds,
            click_index=click_index,
            click_text=click_text,
            exact=exact,
            config=config,
            profile_manager=profile_manager,
        )
    )


async def _browser_lite_run(
    platform: str,
    url: str,
    headed: bool,
    limit: int,
    wait_seconds: float,
    click_index: int | None,
    click_text: str | None,
    exact: bool,
    config,
    profile_manager,
) -> None:
    from payswitch.browser.controller import BrowserController, BrowserControllerError
    from payswitch.browser.display import detect_display_mode
    from payswitch.browser.runtime import (
        BrowserRuntimeConfigError,
        build_browser_runtime_plan,
    )
    from payswitch.models.types import DisplayMode

    try:
        browser_plan = build_browser_runtime_plan(config, ensure_cdp=True)
    except BrowserRuntimeConfigError as exc:
        raise BrowserControllerError(str(exc)) from exc
    profile_dir = (
        None if browser_plan.uses_user_chrome else profile_manager.get_profile_dir(platform)
    )
    use_headless = not headed and (detect_display_mode() != DisplayMode.headed)
    chrome_kwargs = browser_plan.launch_kwargs

    browser = BrowserController()
    try:
        await browser.launch(
            profile_dir=profile_dir,
            headless=use_headless,
            **chrome_kwargs,
        )
        await browser.navigate(url)
        try:
            await browser.page.wait_for_load_state("networkidle", timeout=5_000)
        except Exception:
            pass
        if wait_seconds > 0:
            await browser.page.wait_for_timeout(wait_seconds * 1000)
        clickables = await browser.list_clickable_elements(limit=limit)

        clicked_payload = None
        if click_index is not None and click_text:
            raise BrowserControllerError("--click-index 与 --click-text 不能同时使用")
        if click_index is not None:
            clicked_payload = await browser.click_clickable_index(click_index)
        elif click_text:
            clicked_payload = await browser.click_clickable_text(click_text, exact=exact)

        if _state.json_output:
            _print_json(
                {
                    "platform": platform,
                    "url": await browser.get_current_url(),
                    "count": len(clickables),
                    "clicked": clicked_payload,
                    "clickables": clickables,
                }
            )
            return

        console.print(
            Panel(
                f"[bold]平台：[/bold]{platform}\n"
                f"[bold]URL：[/bold]{await browser.get_current_url()}\n"
                f"[bold]识别结果：[/bold]{len(clickables)} 个可点击元素",
                title="[cyan]Browser Lite[/cyan]",
                border_style="cyan",
            )
        )
        table = Table(title="可点击元素（前 N 项）", border_style="cyan")
        table.add_column("Index", style="bold cyan")
        table.add_column("Tag", style="magenta")
        table.add_column("Text")
        table.add_column("Selector", overflow="fold")
        for item in clickables:
            table.add_row(
                str(item.get("index")),
                str(item.get("tag")),
                str(item.get("text") or ""),
                str(item.get("selector") or ""),
            )
        console.print(table)
        if clicked_payload is not None:
            console.print(
                f"[green]OK[/green] 已点击 index={clicked_payload.get('index')} "
                f"text={clicked_payload.get('text')!r}"
            )

    except Exception as exc:
        _print_error(f"browser-lite 执行失败：{exc}")
        raise typer.Exit(code=1)
    finally:
        await browser.close()


# ---------------------------------------------------------------------------
# external-run — 外部 Agent 驱动的受控 checkout
# ---------------------------------------------------------------------------
@app.command("external-run")
def external_run(
    amount: Annotated[float, typer.Argument(help="支付金额（单位：元）。")],
    payee: Annotated[str, typer.Argument(help="收款方标识。")],
    actions: Annotated[
        Path,
        typer.Option("--actions", help="外部 Agent 动作 JSON 文件。"),
    ],
    reason: Annotated[
        str,
        typer.Option("--reason", "-r", help="支付原因（记录用途）。"),
    ] = "",
    method: Annotated[
        str | None,
        typer.Option(
            "--method",
            "-m",
            help="支付方式：alipay_qr / wechat_qr / card_number_only / stripe / auto。",
        ),
    ] = None,
    idempotency_key: Annotated[
        str | None,
        typer.Option("--idempotency-key", "-k", help="幂等键（防止重复支付）。"),
    ] = None,
    stop_on_human: Annotated[
        bool,
        typer.Option("--stop-on-human", help="检测到二维码/敏感/确认时通知后立即返回。"),
    ] = False,
) -> None:
    """由外部 Agent 提供动作，Payswitch 执行、检测、通知、记账。"""
    from payswitch.engine.external_runner import ExternalAction, ExternalCheckoutRunner
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import PaymentMethod

    if amount <= 0:
        _print_error(f"支付金额必须大于 0，当前值：{amount}")
        raise typer.Exit(code=1)
    if not actions.exists():
        _print_error(f"动作文件不存在：{actions}")
        raise typer.Exit(code=1)

    payment_method = PaymentMethod.auto
    if method:
        try:
            payment_method = PaymentMethod(method)
        except ValueError:
            valid_methods = [m.value for m in PaymentMethod]
            _print_error(f"不支持的支付方式：'{method}'，有效选项：{', '.join(valid_methods)}")
            raise typer.Exit(code=1)

    try:
        raw_actions = json.loads(actions.read_text(encoding="utf-8"))
        action_items = [ExternalAction.model_validate(item) for item in raw_actions]
    except Exception as exc:
        _print_error(f"动作文件解析失败：{type(exc).__name__}: {exc}")
        raise typer.Exit(code=1)

    config = PaySwitchConfig.load()
    runner = ExternalCheckoutRunner(config)
    try:
        tx = asyncio.run(
            runner.run(
                amount=amount,
                payee=payee,
                actions=action_items,
                reason=reason,
                method=payment_method,
                idempotency_key=idempotency_key,
                stop_on_human=stop_on_human,
            )
        )
    finally:
        runner.close()

    _spend_print_result(tx, dry_run=False)


@app.command("external-act")
def external_act(
    tx_id: Annotated[str, typer.Argument(help="已有交易 ID。")],
    action_json: Annotated[
        str | None,
        typer.Option(
            "--action",
            help='单步动作 JSON，例如 \'{"type":"observe"}\'。',
        ),
    ] = None,
    action_file: Annotated[
        Path | None,
        typer.Option("--action-file", help="单步动作 JSON 文件。"),
    ] = None,
    start_url: Annotated[
        str | None,
        typer.Option("--start-url", help="执行动作前先导航到该 URL。"),
    ] = None,
    stop_on_human: Annotated[
        bool,
        typer.Option("--stop-on-human/--wait-on-human", help="命中人类闸门时立即返回。"),
    ] = True,
) -> None:
    """外部 Agent 对已有交易提交一个受控 Computer Use 动作。"""
    from payswitch.engine.external_runner import ExternalAction, ExternalCheckoutRunner
    from payswitch.models.config import PaySwitchConfig

    if bool(action_json) == bool(action_file):
        _print_error("必须且只能提供 --action 或 --action-file 之一。")
        raise typer.Exit(code=1)

    try:
        if action_file is not None:
            if not action_file.exists():
                _print_error(f"动作文件不存在：{action_file}")
                raise typer.Exit(code=1)
            raw_action = json.loads(action_file.read_text(encoding="utf-8"))
        else:
            raw_action = json.loads(action_json or "{}")
        action = ExternalAction.model_validate(raw_action)
    except Exception as exc:
        _print_error(f"动作解析失败：{type(exc).__name__}: {exc}")
        raise typer.Exit(code=1)

    config = PaySwitchConfig.load()
    runner = ExternalCheckoutRunner(config)
    try:
        result = asyncio.run(
            runner.act(
                tx_id=tx_id,
                action=action,
                start_url=start_url,
                stop_on_human=stop_on_human,
            )
        )
    finally:
        runner.close()

    _print_json(json.loads(result.model_dump_json()))


# ---------------------------------------------------------------------------
# ui-events — 前端控制台实时事件流
# ---------------------------------------------------------------------------
@app.command("ui-events")
def ui_events(
    host: Annotated[
        str,
        typer.Option("--host", help="SSE 服务监听地址。"),
    ] = "127.0.0.1",
    port: Annotated[
        int,
        typer.Option("--port", help="SSE 服务监听端口。"),
    ] = 8787,
    poll_interval: Annotated[
        float,
        typer.Option("--poll-interval", help="事件文件轮询间隔（秒）。"),
    ] = 0.5,
) -> None:
    """启动给 frontend 使用的 Pay-Switch runtime SSE 事件流。

    前端连接地址示例：
    ``VITE_PAYSWITCH_EVENTS_URL=http://127.0.0.1:8787/events``，
    页面 URL 使用 ``?session_id=<tx_id>`` 指定要观察的交易。
    """
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from urllib.parse import parse_qs, quote, urlparse

    from payswitch.engine.events import RuntimeEventSink
    from payswitch.engine.ledger import Ledger
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    sink = RuntimeEventSink(config)
    evidence_root = (config.data_dir / "evidence").expanduser().resolve()

    class EventRequestHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt: str, *args) -> None:  # noqa: ANN001
            if _state.verbose:
                err_console.print(fmt % args)

        def do_OPTIONS(self) -> None:  # noqa: N802
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, PATCH, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/api/settings":
                self._handle_settings_request()
                return
            if parsed.path == "/api/sessions/latest":
                self._handle_latest_session_request()
                return
            if parsed.path.startswith("/api/sessions/"):
                tx_id = parsed.path.removeprefix("/api/sessions/").strip("/")
                self._handle_session_request(tx_id)
                return
            if parsed.path == "/api/browser/profiles":
                query = parse_qs(parsed.query)
                self._handle_browser_profiles_request(query)
                return
            if parsed.path == "/api/browser/doctor":
                self._handle_browser_doctor_request()
                return
            if parsed.path == "/evidence":
                self._handle_evidence_request(parsed.query)
                return
            if parsed.path != "/events":
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(
                    b"Pay-Switch UI events endpoint: /events?session_id=<tx_id>\n"
                )
                return

            session_id = parse_qs(parsed.query).get("session_id", [""])[0].strip()
            replay = parse_qs(parsed.query).get("replay", ["1"])[0].strip()
            if not session_id:
                self.send_response(400)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(b"missing session_id\n")
                return

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            log_path = sink.event_log_path(session_id)
            offset = (
                log_path.stat().st_size
                if replay in {"0", "false", "no"} and log_path.exists()
                else 0
            )
            last_heartbeat = 0.0
            try:
                while True:
                    if log_path.exists():
                        with log_path.open("r", encoding="utf-8") as file:
                            file.seek(offset)
                            for line in file:
                                stripped = line.strip()
                                if stripped:
                                    payload = self._event_payload_for_stream(stripped)
                                    self.wfile.write(
                                        (
                                            "data: "
                                            f"{json.dumps(payload, ensure_ascii=False)}\n\n"
                                        ).encode()
                                    )
                                    self.wfile.flush()
                            offset = file.tell()
                    now = time.monotonic()
                    if now - last_heartbeat >= 15:
                        self.wfile.write(b": heartbeat\n\n")
                        self.wfile.flush()
                        last_heartbeat = now
                    time.sleep(max(0.1, poll_interval))
            except (BrokenPipeError, ConnectionResetError):
                return

        def do_PATCH(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/api/settings":
                self._handle_settings_update()
                return
            if parsed.path == "/api/browser/profile":
                self._handle_browser_profile_update()
                return
            self._send_json({"error": "unknown API endpoint"}, status=404)

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/api/browser/project-profile":
                self._handle_browser_project_profile()
                return
            if parsed.path == "/api/browser/cdp-profile/ensure":
                self._handle_browser_cdp_profile_ensure()
                return
            self._send_json({"error": "unknown API endpoint"}, status=404)

        def _handle_settings_request(self) -> None:
            current = PaySwitchConfig.load()
            self._send_json(_settings_api_config_payload(current))

        def _handle_latest_session_request(self) -> None:
            with Ledger(config.data_dir / "payswitch.db") as ledger:
                latest = ledger.list_transactions(limit=1)
            session = (
                _settings_api_transaction_session_payload(
                    latest[0],
                    evidence_root=evidence_root,
                    request_base_url=self._request_base_url(),
                )
                if latest
                else None
            )
            self._send_json({"session": session})

        def _handle_session_request(self, tx_id: str) -> None:
            if not tx_id:
                self._send_json({"error": "missing transaction id"}, status=400)
                return
            with Ledger(config.data_dir / "payswitch.db") as ledger:
                tx = ledger.get(tx_id)
            if tx is None:
                self._send_json({"error": f"transaction not found: {tx_id}"}, status=404)
                return
            self._send_json(
                {
                    "session": _settings_api_transaction_session_payload(
                        tx,
                        evidence_root=evidence_root,
                        request_base_url=self._request_base_url(),
                    )
                }
            )

        def _handle_settings_update(self) -> None:
            current = PaySwitchConfig.load()
            try:
                body = self._read_json_body()
                updates = _settings_api_validate_config_updates(current, body)
                updated = current.update(**updates)
            except Exception as exc:
                self._send_json({"error": str(exc)}, status=400)
                return
            self._send_json(
                {
                    "updated": sorted(updates),
                    **_settings_api_config_payload(updated),
                }
            )

        def _handle_browser_profiles_request(self, query: dict[str, list[str]]) -> None:
            browser = query.get("browser", ["chrome"])[0].strip() or "chrome"
            profile_query = query.get("query", [""])[0].strip() or None
            raw_user_data_dir = query.get("user_data_dir", [""])[0].strip()
            user_data_dir = Path(raw_user_data_dir) if raw_user_data_dir else None
            try:
                profiles = _settings_api_discover_profiles(
                    browser=browser,
                    query=profile_query,
                    user_data_dir=user_data_dir,
                )
            except Exception as exc:
                self._send_json({"error": str(exc)}, status=400)
                return
            self._send_json({"profiles": profiles})

        def _handle_browser_profile_update(self) -> None:
            current = PaySwitchConfig.load()
            try:
                body = self._read_json_body()
                if not isinstance(body, dict):
                    raise ValueError("profile update body must be a JSON object")
                updates = _settings_api_select_profile_updates(
                    browser=str(body.get("browser") or "chrome"),
                    user_data_dir=str(body.get("user_data_dir") or ""),
                    profile_directory=str(body.get("profile_directory") or ""),
                    keep_cdp=bool(body.get("keep_cdp", False)),
                )
                updated = current.update(**updates)
            except Exception as exc:
                self._send_json({"error": str(exc)}, status=400)
                return
            self._send_json(
                {
                    "updated": sorted(updates),
                    **_settings_api_config_payload(updated),
                }
            )

        def _handle_browser_project_profile(self) -> None:
            current = PaySwitchConfig.load()
            try:
                body = self._read_json_body()
                if body and not isinstance(body, dict):
                    raise ValueError("project profile body must be a JSON object")
                request = body if isinstance(body, dict) else {}
                updates = _settings_api_project_profile_updates(
                    current,
                    user_data_dir=str(request.get("user_data_dir") or ""),
                    profile_directory=str(request.get("profile_directory") or "Default"),
                    browser=str(request.get("browser") or "chrome"),
                    expected_email=str(request.get("expected_email") or ""),
                    ensure=bool(request.get("ensure", False)),
                    timeout=float(request.get("timeout") or 10.0),
                )
                updated = current.update(**updates)
            except Exception as exc:
                self._send_json({"error": str(exc)}, status=400)
                return
            self._send_json(
                {
                    "updated": sorted(updates),
                    "project_profile": {
                        "user_data_dir": updated.chrome_user_data_dir,
                        "profile_directory": updated.chrome_profile_directory,
                        "chrome_cdp_url": updated.chrome_cdp_url,
                    },
                    **_settings_api_config_payload(updated),
                }
            )

        def _handle_browser_cdp_profile_ensure(self) -> None:
            current = PaySwitchConfig.load()
            try:
                body = self._read_json_body()
                if body and not isinstance(body, dict):
                    raise ValueError("cdp ensure body must be a JSON object")
                request = body if isinstance(body, dict) else {}
                updates = _settings_api_ensure_cdp_profile_updates(
                    current,
                    timeout=float(request.get("timeout") or 10.0),
                )
                updated = current.update(**updates)
            except Exception as exc:
                self._send_json({"error": str(exc)}, status=400)
                return
            self._send_json(
                {
                    "updated": sorted(updates),
                    "cdp_url": updated.chrome_cdp_url,
                    **_settings_api_config_payload(updated),
                }
            )

        def _handle_browser_doctor_request(self) -> None:
            current = PaySwitchConfig.load()
            try:
                payload = _settings_api_browser_doctor_payload(current)
            except Exception as exc:
                self._send_json({"error": str(exc)}, status=400)
                return
            self._send_json({"doctor": payload})

        def _event_payload_for_stream(self, line: str) -> dict[str, object] | str:
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                return line
            if not isinstance(payload, dict):
                return line

            screenshot_path = payload.get("screenshot_path")
            if isinstance(screenshot_path, str):
                resolved = self._resolve_evidence_path(screenshot_path)
                if resolved is not None:
                    payload["screenshot_url"] = (
                        f"{self._request_base_url()}/evidence?path={quote(str(resolved))}"
                    )
            media_artifacts = _settings_api_project_media_artifacts(
                payload.get("media_artifacts"),
                evidence_root=evidence_root,
                request_base_url=self._request_base_url(),
            )
            if media_artifacts:
                payload["media_artifacts"] = media_artifacts
            return payload

        def _handle_evidence_request(self, query: str) -> None:
            raw_path = parse_qs(query).get("path", [""])[0].strip()
            resolved = self._resolve_evidence_path(raw_path)
            if resolved is None or not resolved.exists() or not resolved.is_file():
                self.send_response(404)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(b"evidence not found\n")
                return

            payload = _settings_api_read_evidence_bytes(str(resolved))
            if payload is None:
                self.send_response(404)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(b"evidence not found\n")
                return
            data, content_type = payload
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(data)

        def _resolve_evidence_path(self, raw_path: str) -> Path | None:
            if not raw_path:
                return None
            try:
                resolved = Path(raw_path).expanduser().resolve()
            except OSError:
                return None
            if not resolved.is_relative_to(evidence_root):
                return None
            if resolved.suffix.lower() not in _SETTINGS_API_EVIDENCE_PREVIEW_SUFFIXES:
                return None
            return resolved

        def _request_base_url(self) -> str:
            request_host = self.headers.get("Host") or f"{host}:{port}"
            return f"http://{request_host}"

        def _read_json_body(self) -> object:
            content_length = int(self.headers.get("Content-Length") or "0")
            if content_length <= 0:
                return {}
            raw = self.rfile.read(content_length)
            if not raw:
                return {}
            return json.loads(raw.decode("utf-8"))

        def _send_json(self, payload: object, *, status: int = 200) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer((host, port), EventRequestHandler)
    console.print(
        f"[green]OK[/green] Pay-Switch UI events: http://{host}:{port}/events"
    )
    console.print(
        "前端示例：VITE_PAYSWITCH_EVENTS_URL="
        f"http://{host}:{port}/events npm run dev --prefix frontend"
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        console.print("已停止 Pay-Switch UI events 服务。")
    finally:
        server.server_close()


# ---------------------------------------------------------------------------
# spend — 发起支付（核心命令）
# ---------------------------------------------------------------------------
@app.command("spend")
def spend(
    amount: Annotated[float, typer.Argument(help="支付金额（单位：元）。")],
    payee: Annotated[str, typer.Argument(help="收款方标识，如 deepseek / kimi。")],
    reason: Annotated[
        str,
        typer.Option("--reason", "-r", help="支付原因（记录用途）。"),
    ] = "",
    method: Annotated[
        str | None,
        typer.Option(
            "--method",
            "-m",
            help="指定支付方式：alipay_qr / wechat_qr / card_number_only / stripe / auto。",
        ),
    ] = None,
    mode: Annotated[
        str | None,
        typer.Option("--mode", help="执行模式：script / smart / human_takeover。"),
    ] = None,
    idempotency_key: Annotated[
        str | None,
        typer.Option("--idempotency-key", "-k", help="幂等键（防止重复支付）。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="模拟执行，不实际发起支付。"),
    ] = False,
    url: Annotated[
        str | None,
        typer.Option("--url", help="智能模式目标 URL（无适配器时需要提供）。"),
    ] = None,
) -> None:
    """发起一笔支付请求。

    Agent 调用此命令后，Pay-Switch 自动完成支付流程的 80-90%，
    在需要人类确认时暂停等待（扫码/输密码/点确认）。

    示例：
      payswitch spend 200 deepseek --reason "充值 API 额度"
      payswitch spend 50 kimi --method alipay_qr
      payswitch spend 100 deepseek --idempotency-key task-abc-123
      payswitch spend 200 deepseek --dry-run
    """
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import ExecutionMode, PaymentMethod

    # 金额校验
    if amount <= 0:
        _print_error(f"支付金额必须大于 0，当前值：{amount}")
        raise typer.Exit(code=1)

    # 解析支付方式
    payment_method = PaymentMethod.auto
    if method:
        try:
            payment_method = PaymentMethod(method)
        except ValueError:
            valid_methods = [m.value for m in PaymentMethod]
            _print_error(f"不支持的支付方式：'{method}'，有效选项：{', '.join(valid_methods)}")
            raise typer.Exit(code=1)

    # 加载配置
    execution_mode: ExecutionMode | None = None
    if mode:
        try:
            execution_mode = ExecutionMode(mode)
        except ValueError:
            valid_modes = [m.value for m in ExecutionMode]
            _print_error(
                f"Unsupported execution mode: {mode!r}; "
                f"valid options: {', '.join(valid_modes)}"
            )
            raise typer.Exit(code=1)

    config = PaySwitchConfig.load()

    # 非 JSON 模式：显示支付计划面板
    if not _state.json_output:
        plan_lines = [
            f"[bold]收款方：[/bold]{payee}",
            f"[bold]金额：[/bold][yellow]{_format_amount(amount)}[/yellow]",
        ]
        if reason:
            plan_lines.append(f"[bold]用途：[/bold]{reason}")
        if method:
            plan_lines.append(f"[bold]支付方式：[/bold]{method}")
        if idempotency_key:
            plan_lines.append(f"[bold]幂等键：[/bold]{idempotency_key}")
        if dry_run:
            plan_lines.append(
                "[bold yellow]模式：[/bold yellow][yellow]模拟执行（不实际支付）[/yellow]"
            )
        if url:
            plan_lines.append(f"[bold]目标 URL：[/bold]{url}")

        console.print(
            Panel(
                "\n".join(plan_lines),
                title="[cyan]支付计划[/cyan]",
                border_style="cyan",
            )
        )
        console.print("\n[bold]正在执行...[/bold]")

    # 执行支付
    tx = asyncio.run(
        _spend_execute(
            amount=amount,
            payee=payee,
            reason=reason,
            payment_method=payment_method,
            idempotency_key=idempotency_key,
            dry_run=dry_run,
            url=url,
            mode=execution_mode,
            config=config,
        )
    )

    # 显示结果
    _spend_print_result(tx, dry_run)


async def _spend_execute(
    amount: float,
    payee: str,
    reason: str,
    payment_method,
    idempotency_key: str | None,
    dry_run: bool,
    url: str | None,
    mode,
    config,
):
    """异步执行支付编排，返回 Transaction 对象。"""
    from payswitch.engine.orchestrator import PaymentOrchestrator

    orchestrator = PaymentOrchestrator(config)
    try:
        tx = await orchestrator.spend(
            amount=amount,
            payee=payee,
            reason=reason,
            method=payment_method,
            idempotency_key=idempotency_key,
            dry_run=dry_run,
            url=url,
            mode=mode,
        )
        return tx
    finally:
        orchestrator.close()


def _spend_print_result(tx, dry_run: bool) -> None:
    """显示支付结果。"""
    from payswitch.models.types import TransactionStatus

    if _state.json_output:
        _print_json_str(tx.model_dump_json(indent=2))
        return

    # 根据状态显示不同的结果面板
    if tx.status == TransactionStatus.completed:
        if dry_run:
            # dry_run 模式：展示模拟执行计划（步骤摘要）
            title = "[yellow]dry-run 模拟执行完成[/yellow]"

            # 显示每个模拟步骤（[dry_run] 前缀步骤）
            if tx.steps:
                total = len(tx.steps)
                console.print(f"\n[bold yellow]模拟执行计划（共 {total} 步）：[/bold yellow]")
                for i, step in enumerate(tx.steps):
                    step_icon = {
                        "success": "[green]OK[/green]",
                        "failed": "[red]FAIL[/red]",
                        "pending": "[yellow]WAIT[/yellow]",
                        "skipped": "[dim]SKIP[/dim]",
                    }.get(step.status, "•")
                    console.print(f"  {step_icon} {i + 1}/{total}：{step.description}")

            result_lines = [
                f"[bold]交易 ID（模拟）：[/bold]{tx.tx_id}",
                f"[bold]金额：[/bold][yellow]{_format_amount(tx.amount, tx.currency)}[/yellow]",
                f"[bold]收款方：[/bold]{tx.payee}",
            ]
            if tx.reason:
                result_lines.append(f"[bold]用途：[/bold]{tx.reason}")
            result_lines.append(
                "\n[bold yellow]注意：以上为模拟执行，未启动浏览器，未发起真实支付。[/bold yellow]"
            )
            result_lines.append("[dim]去掉 --dry-run 选项后重新运行即可执行真实支付。[/dim]")

            console.print(
                Panel(
                    "\n".join(result_lines),
                    title=title,
                    border_style="yellow",
                    padding=(1, 2),
                )
            )
        else:
            # 真实支付完成：显示步骤列表
            if tx.steps:
                total = len(tx.steps)
                for i, step in enumerate(tx.steps):
                    step_icon = {
                        "success": "[green]OK[/green]",
                        "failed": "[red]FAIL[/red]",
                        "pending": "[yellow]WAIT[/yellow]",
                        "skipped": "[dim]SKIP[/dim]",
                    }.get(step.status, "•")
                    console.print(f"  {step_icon} 步骤 {i + 1}/{total}：{step.description}")

            result_lines = [
                f"[bold]交易 ID：[/bold]{tx.tx_id}",
                f"[bold]金额：[/bold][green]{_format_amount(tx.amount, tx.currency)}[/green]",
                f"[bold]收款方：[/bold]{tx.payee}",
            ]
            if tx.completed_at:
                result_lines.append(f"[bold]完成时间：[/bold]{_format_datetime(tx.completed_at)}")

            console.print(
                Panel(
                    "\n".join(result_lines),
                    title="[green]支付完成[/green]",
                    border_style="green",
                    padding=(1, 2),
                )
            )

    elif tx.status == TransactionStatus.human_action_required:
        # 需要人类介入
        action_desc = ""
        detail_lines: list[str] = []
        if tx.human_action:
            action_type_labels = {
                "scan_qr": "请在弹出的浏览器窗口中扫码支付",
                "fill_form": "请在浏览器中填写支付信息",
                "confirm": "请在浏览器中确认支付",
                "takeover": "请在浏览器中手动完成支付",
                "external_computer_use": "请让外部 Agent 继续探索页面，并在关键闸门前停下",
            }
            action_desc = tx.human_action.guidance or action_type_labels.get(
                tx.human_action.action_type,
                f"请完成操作：{tx.human_action.action_type}",
            )
            if tx.human_action.details:
                detail_lines = [
                    f"[bold]{key}：[/bold]{value}"
                    for key, value in tx.human_action.details.items()
                    if value not in (None, "", [], {})
                ]

        console.print(
            Panel(
                f"[bold magenta]需要人工操作[/bold magenta]\n\n"
                f"{action_desc}\n\n"
                f"[bold]交易 ID：[/bold]{tx.tx_id}\n"
                f"[bold]金额：[/bold]{_format_amount(tx.amount, tx.currency)}\n"
                + (("\n" + "\n".join(detail_lines) + "\n") if detail_lines else "\n")
                + "\n"
                f"[dim]操作完成后，运行以下命令确认：[/dim]\n"
                f"  [cyan]payswitch confirm {tx.tx_id}[/cyan]",
                title="[magenta]等待人工操作[/magenta]",
                border_style="magenta",
                padding=(1, 2),
            )
        )

    elif tx.status == TransactionStatus.failed:
        error_msg = tx.error or "未知错误"
        console.print(
            Panel(
                f"[bold red]支付失败[/bold red]\n\n"
                f"[bold]原因：[/bold]{error_msg}\n\n"
                f"[bold]交易 ID：[/bold]{tx.tx_id}",
                title="[red]支付失败[/red]",
                border_style="red",
                padding=(1, 2),
            )
        )
        raise typer.Exit(code=1)

    elif tx.status == TransactionStatus.timeout:
        console.print(
            Panel(
                f"[bold red]支付超时[/bold red]\n\n"
                f"[bold]交易 ID：[/bold]{tx.tx_id}\n"
                f"操作在规定时间内未完成，请检查后重试。",
                title="[red]超时[/red]",
                border_style="red",
                padding=(1, 2),
            )
        )
        raise typer.Exit(code=1)

    else:
        # 其他状态
        status_label = _get_status_label(tx.status.value)
        console.print(
            Panel(
                f"[bold]交易 ID：[/bold]{tx.tx_id}\n[bold]当前状态：[/bold]{status_label}",
                title=f"[cyan]交易状态：{status_label}[/cyan]",
                border_style="cyan",
            )
        )


# ---------------------------------------------------------------------------
# confirm — 确认人类操作已完成
# ---------------------------------------------------------------------------
@app.command("confirm")
def confirm(
    tx_id: Annotated[str, typer.Argument(help="交易 ID（格式：txn_xxxxxxxx）。")],
    success: Annotated[
        bool,
        typer.Option("--success/--failed", help="确认操作是否成功（默认成功）。"),
    ] = True,
) -> None:
    """确认人类介入操作已完成，恢复支付流程。

    当 Pay-Switch 等待人类操作（如扫码支付）时，
    人类完成操作后运行此命令通知 Pay-Switch 继续。

    示例：
      payswitch confirm txn_abc123ef
      payswitch confirm txn_abc123ef --failed
    """
    from payswitch.engine.orchestrator import PaymentOrchestrator, PaySwitchError
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import TransactionStatus

    config = PaySwitchConfig.load()

    # 先查询交易是否存在
    db_path = config.data_dir / "payswitch.db"
    from payswitch.engine.ledger import Ledger

    ledger = Ledger(db_path=db_path)

    try:
        tx = ledger.get(tx_id)
        if tx is None:
            _print_error(f"交易不存在：{tx_id}")
            raise typer.Exit(code=1)

        # 显示待确认信息
        if not _state.json_output:
            console.print(
                Panel(
                    f"[bold]交易 ID：[/bold]{tx_id}\n"
                    f"[bold]金额：[/bold]{_format_amount(tx.amount, tx.currency)}\n"
                    f"[bold]收款方：[/bold]{tx.payee}\n"
                    f"[bold]当前状态：[/bold]{_get_status_label(tx.status.value)}\n"
                    f"[bold]操作：[/bold]{'确认成功' if success else '标记失败'}",
                    title="[cyan]确认交易[/cyan]",
                    border_style="cyan",
                )
            )

        if not success:
            # 标记为失败
            from datetime import datetime

            ledger.update_status(
                tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(UTC),
                error="用户确认：操作失败",
                steps=tx.steps,
            )
            updated_tx = ledger.get(tx_id)
            if _state.json_output:
                _print_json_str(updated_tx.model_dump_json(indent=2) if updated_tx else "{}")
            else:
                console.print(f"[red]FAIL[/red] 交易 [bold]{tx_id}[/bold] 已标记为失败。")
            return

        # 调用 orchestrator.confirm() 确认成功
        orchestrator = PaymentOrchestrator(config)
        try:
            updated_tx = asyncio.run(orchestrator.confirm(tx_id))
        except PaySwitchError as exc:
            _print_error(str(exc))
            raise typer.Exit(code=1)
        finally:
            orchestrator.close()

        if _state.json_output:
            _print_json_str(updated_tx.model_dump_json(indent=2))
        else:
            console.print(
                Panel(
                    f"[bold]交易 ID：[/bold]{updated_tx.tx_id}\n"
                    f"[bold]金额：[/bold][green]"
                    f"{_format_amount(updated_tx.amount, updated_tx.currency)}[/green]\n"
                    f"[bold]状态：[/bold][green]"
                    f"{_get_status_label(updated_tx.status.value)}[/green]\n"
                    f"[bold]完成时间：[/bold]{_format_datetime(updated_tx.completed_at)}",
                    title="[green]交易已确认[/green]",
                    border_style="green",
                    padding=(1, 2),
                )
            )
    finally:
        ledger.close()


# ---------------------------------------------------------------------------
# status — 查询交易状态
# ---------------------------------------------------------------------------
@app.command("status")
def status(
    tx_id: Annotated[str, typer.Argument(help="交易 ID（格式：txn_xxxxxxxx）。")],
    watch: Annotated[
        bool,
        typer.Option("--watch", "-w", help="持续监控交易状态直到终态。"),
    ] = False,
    interval: Annotated[
        int,
        typer.Option("--interval", help="--watch 模式下的轮询间隔（秒）。"),
    ] = 3,
) -> None:
    """查询指定交易的当前状态。

    显示交易的完整执行步骤、当前状态和错误信息（如有）。

    示例：
      payswitch status txn_abc123ef
      payswitch status txn_abc123ef --watch
      payswitch status txn_abc123ef --watch --interval 5
    """
    from payswitch.engine.ledger import Ledger
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import TransactionStatus

    config = PaySwitchConfig.load()
    db_path = config.data_dir / "payswitch.db"
    ledger = Ledger(db_path=db_path)

    # 终态集合：达到这些状态后不再轮询
    terminal_statuses = {
        TransactionStatus.completed,
        TransactionStatus.failed,
        TransactionStatus.cancelled,
        TransactionStatus.timeout,
    }

    try:
        if not watch:
            # 单次查询
            tx = ledger.get(tx_id)
            if tx is None:
                _print_error(f"交易不存在：{tx_id}")
                raise typer.Exit(code=1)
            _status_print_tx(tx)
        else:
            # --watch 模式：循环轮询直到终态
            if not _state.json_output:
                console.print(f"[dim]正在监控交易 {tx_id}，按 Ctrl+C 停止...[/dim]")

            try:
                while True:
                    tx = ledger.get(tx_id)
                    if tx is None:
                        _print_error(f"交易不存在：{tx_id}")
                        raise typer.Exit(code=1)

                    _status_print_tx(tx)

                    if tx.status in terminal_statuses:
                        break

                    if not _state.json_output:
                        console.print(f"[dim]等待 {interval} 秒后重新查询...[/dim]")
                    time.sleep(interval)

            except KeyboardInterrupt:
                if not _state.json_output:
                    console.print("\n[dim]已停止监控。[/dim]")
    finally:
        ledger.close()


def _status_print_tx(tx) -> None:
    """将交易详情打印到终端。"""
    if _state.json_output:
        _print_json_str(tx.model_dump_json(indent=2))
        return

    # 状态样式
    status_style = _get_status_style(tx.status.value)
    status_label = _get_status_label(tx.status.value)

    # 构建基本信息
    info_lines = [
        f"[bold]交易 ID：[/bold]{tx.tx_id}",
        f"[bold]收款方：[/bold]{tx.payee}",
        f"[bold]金额：[/bold]{_format_amount(tx.amount, tx.currency)}",
        f"[bold]状态：[/bold][{status_style}]{status_label}[/{status_style}]",
        f"[bold]创建时间：[/bold]{_format_datetime(tx.created_at)}",
    ]

    if tx.reason:
        info_lines.append(f"[bold]用途：[/bold]{tx.reason}")
    if tx.payment_method:
        info_lines.append(f"[bold]支付方式：[/bold]{tx.payment_method.value}")
    if tx.execution_mode:
        mode_labels = {
            "script": "脚本模式",
            "smart": "智能模式",
            "human_takeover": "人类接管",
        }
        info_lines.append(
            "[bold]执行模式：[/bold]"
            f"{mode_labels.get(tx.execution_mode.value, tx.execution_mode.value)}"
        )
    if tx.completed_at:
        info_lines.append(f"[bold]完成时间：[/bold]{_format_datetime(tx.completed_at)}")
    if tx.error:
        info_lines.append(f"[bold red]错误信息：[/bold red]{tx.error}")
    if tx.idempotency_key:
        info_lines.append(f"[bold]幂等键：[/bold]{tx.idempotency_key}")

    console.print(
        Panel(
            "\n".join(info_lines),
            title=f"[{status_style}]交易状态[/{status_style}]",
            border_style=status_style,
            padding=(1, 2),
        )
    )

    # 显示执行步骤
    if tx.steps:
        console.print(f"\n[bold]执行步骤（共 {len(tx.steps)} 步）：[/bold]")
        for step in tx.steps:
            step_icon = {
                "success": "[green]OK[/green]",
                "failed": "[red]FAIL[/red]",
                "pending": "[yellow]WAIT[/yellow]",
                "skipped": "[dim]SKIP[/dim]",
            }.get(step.status, "•")
            duration = step.duration_seconds()
            dur_str = f" [dim]({duration:.1f}s)[/dim]" if duration else ""
            console.print(f"  {step_icon} [{step.step_index + 1}] {step.description}{dur_str}")

    # 若正在等待人类操作，显示提示
    if tx.human_action and not tx.human_action.is_completed():
        action_label = {
            "scan_qr": "扫码支付",
            "fill_form": "填写表单",
            "confirm": "确认支付",
            "takeover": "手动操作",
            "external_computer_use": "外部 Agent 探索中",
        }.get(tx.human_action.action_type, tx.human_action.action_type)
        guidance = tx.human_action.guidance or f"正在等待人工操作：{action_label}"
        detail_block = ""
        if tx.human_action.details:
            detail_lines = [
                f"[bold]{key}：[/bold]{value}"
                for key, value in tx.human_action.details.items()
                if value not in (None, "", [], {})
            ]
            if detail_lines:
                detail_block = "\n\n" + "\n".join(detail_lines)

        console.print(
            Panel(
                f"[yellow]{guidance}[/yellow]"
                f"{detail_block}\n\n"
                f"完成后请运行：[cyan]payswitch confirm {tx.tx_id}[/cyan]",
                border_style="yellow",
                padding=(0, 2),
            )
        )


# ---------------------------------------------------------------------------
# history — 查看历史交易
# ---------------------------------------------------------------------------
@app.command("history")
def history(
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="最多显示的记录数。"),
    ] = 10,
    offset: Annotated[
        int,
        typer.Option("--offset", help="分页偏移量。"),
    ] = 0,
    payee: Annotated[
        str | None,
        typer.Option("--payee", help="按收款方过滤。"),
    ] = None,
    status_filter: Annotated[
        str | None,
        typer.Option("--status", help="按状态过滤：pending / completed / failed 等。"),
    ] = None,
    export_csv: Annotated[
        str | None,
        typer.Option("--export-csv", help="导出为 CSV 文件（指定文件路径）。"),
    ] = None,
) -> None:
    """查看历史支付记录。

    以表格形式展示交易历史，支持按收款方、状态过滤，
    也可导出为 CSV 文件。

    示例：
      payswitch history
      payswitch history --limit 20 --payee deepseek
      payswitch history --status completed --export-csv ./records.csv
    """
    from payswitch.engine.ledger import Ledger
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import TransactionStatus

    config = PaySwitchConfig.load()
    db_path = config.data_dir / "payswitch.db"
    ledger = Ledger(db_path=db_path)

    # 解析状态过滤参数
    status_enum = None
    if status_filter:
        try:
            status_enum = TransactionStatus(status_filter)
        except ValueError:
            valid_statuses = [s.value for s in TransactionStatus]
            _print_error(
                f"无效的状态过滤值：'{status_filter}'，有效选项：{', '.join(valid_statuses)}"
            )
            ledger.close()
            raise typer.Exit(code=1)

    try:
        # 导出 CSV 模式
        if export_csv:
            csv_path = Path(export_csv)
            count = ledger.export_csv(
                filepath=csv_path,
                status=status_enum,
                payee=payee,
            )
            if _state.json_output:
                _print_json(
                    {
                        "success": True,
                        "exported_count": count,
                        "file": str(csv_path.resolve()),
                    }
                )
            else:
                if count > 0:
                    console.print(
                        f"[green]OK[/green] 已导出 [bold]{count}[/bold] 条记录到："
                        f"[bold]{csv_path.resolve()}[/bold]"
                    )
                else:
                    console.print("[yellow]没有匹配的记录，CSV 文件未创建。[/yellow]")
            return

        # 查询交易列表
        transactions = ledger.list_transactions(
            limit=limit,
            offset=offset,
            status=status_enum,
            payee=payee,
        )

        if _state.json_output:
            data = [json.loads(tx.model_dump_json()) for tx in transactions]
            _print_json(data)
            return

        if not transactions:
            console.print("[dim]暂无匹配的交易记录。[/dim]")
            return

        # 构建表格
        filter_desc = []
        if payee:
            filter_desc.append(f"收款方={payee}")
        if status_filter:
            filter_desc.append(f"状态={status_filter}")
        filter_str = f"（过滤：{', '.join(filter_desc)}）" if filter_desc else ""

        table = Table(
            title=f"历史交易记录{filter_str}",
            border_style="cyan",
            show_lines=False,
        )
        table.add_column("交易 ID", style="dim", no_wrap=True)
        table.add_column("收款方", style="bold")
        table.add_column("金额", justify="right")
        table.add_column("状态")
        table.add_column("用途", max_width=20)
        table.add_column("创建时间", no_wrap=True)

        for tx in transactions:
            status_style = _get_status_style(tx.status.value)
            status_label = _get_status_label(tx.status.value)

            table.add_row(
                tx.tx_id,
                tx.payee,
                _format_amount(tx.amount, tx.currency),
                f"[{status_style}]{status_label}[/{status_style}]",
                tx.reason or "-",
                _format_datetime(tx.created_at),
            )

        console.print(table)
        console.print(
            f"[dim]显示 {len(transactions)} 条记录（偏移量 {offset}），"
            f"使用 --limit / --offset 分页[/dim]"
        )

    finally:
        ledger.close()


# ---------------------------------------------------------------------------
# config — 查看和修改配置
# ---------------------------------------------------------------------------
@app.command("config")
def config_cmd(
    key: Annotated[
        str | None,
        typer.Argument(help="配置项名称（留空则显示全部配置）。"),
    ] = None,
    value: Annotated[
        str | None,
        typer.Argument(help="要设置的新值（留空则显示当前值）。"),
    ] = None,
    reset: Annotated[
        bool,
        typer.Option("--reset", help="重置为默认配置。"),
    ] = False,
) -> None:
    """查看或修改 Pay-Switch 配置。

    不带参数时显示全部配置；指定 KEY 显示单项；
    指定 KEY VALUE 更新配置项。

    示例：
      payswitch config
      payswitch config max_per_transaction
      payswitch config max_per_transaction 1000
      payswitch config --reset
    """
    from payswitch.models.config import PaySwitchConfig

    config_path = Path.home() / ".payswitch" / "config.json"

    # --reset 模式：重置为默认值
    if reset:
        confirmed = typer.confirm(
            "确认将所有配置重置为默认值？此操作不可撤销。",
            default=False,
        )
        if not confirmed:
            console.print("[dim]已取消重置操作。[/dim]")
            return

        default_config = PaySwitchConfig()
        default_config.save(config_path)

        if _state.json_output:
            _print_json(json.loads(default_config.model_dump_json()))
        else:
            console.print("[green]OK[/green] 配置已重置为默认值。")
        return

    config = PaySwitchConfig.load(config_path)

    # 显示单项配置
    if key is not None and value is None:
        config_dict = json.loads(config.model_dump_json())
        if key not in config_dict:
            _print_error(f"不存在的配置项：'{key}'，使用 'payswitch config' 查看所有可用配置项")
            raise typer.Exit(code=1)

        if _state.json_output:
            _print_json({key: config_dict[key]})
        else:
            console.print(f"[bold]{key}[/bold] = {config_dict[key]}")
        return

    # 更新配置项
    if key is not None and value is not None:
        config_dict = json.loads(config.model_dump_json())
        if key not in config_dict:
            _print_error(f"不存在的配置项：'{key}'，使用 'payswitch config' 查看所有可用配置项")
            raise typer.Exit(code=1)

        # 类型推断与转换
        original_value = config_dict[key]
        try:
            converted_value = _coerce_config_value(key, value, original_value)
        except (ValueError, TypeError) as exc:
            _print_error(f"配置值格式错误：{exc}")
            raise typer.Exit(code=1) from exc

        try:
            config = config.update(**{key: converted_value})
        except Exception as exc:
            # Pydantic ValidationError 或其他下游校验失败
            _print_error(f"配置值被拒绝：{exc}")
            raise typer.Exit(code=1) from exc

        if _state.json_output:
            _print_json({key: converted_value})
        else:
            console.print(f"[green]OK[/green] 配置已更新：[bold]{key}[/bold] = {converted_value}")
        return

    # 显示全部配置
    config_dict = json.loads(config.model_dump_json())

    if _state.json_output:
        _print_json(config_dict)
        return

    # 配置项中文描述映射
    config_descriptions = {
        "max_per_transaction": ("单笔限额（元）", "安全限额"),
        "daily_limit": ("日累计限额（元）", "安全限额"),
        "whitelist": ("商户白名单", "安全限额"),
        "auto_confirm_threshold": ("自动确认阈值（元）", "安全限额"),
        "payment_priority": ("自动支付方式优先级", "支付策略"),
        "disabled_payment_methods": ("禁用支付方式", "支付策略"),
        "allow_card_number_only": ("允许人工确认后仅代填卡号", "支付策略"),
        "require_human_for_expiry": ("有效期必须人工填写", "支付策略"),
        "require_human_for_cvv": ("CVV/CVC 必须人工填写", "支付策略"),
        "require_human_for_otp": ("OTP/3DS 必须人工处理", "支付策略"),
        "require_human_for_final_confirm": ("最终付款必须人工确认", "支付策略"),
        "card_instruments": ("卡号代填工具元数据", "支付策略"),
        "vault": ("旧版身份凭证库（不推荐存卡号）", "支付策略"),
        "default_currency": ("默认货币", "货币"),
        "llm_provider": ("LLM 服务商", "LLM 配置"),
        "llm_api_key": ("LLM API Key（已加密）", "LLM 配置"),
        "llm_model": ("LLM 模型", "LLM 配置"),
        "computer_use_enabled": ("是否启用 Computer Use 兜底", "Computer Use"),
        "computer_use_driver": ("Computer Use 驱动：external/internal/hybrid", "Computer Use"),
        "computer_use_max_autonomous_category": (
            "Computer Use 可自治推进的最高步骤类别",
            "Computer Use",
        ),
        "browser_control_backend": (
            "浏览器接管方式：auto/cdp/ephemeral_cdp_mirror/user_profile/managed_profile",
            "浏览器上下文",
        ),
        "chrome_cdp_url": ("已有 Chrome remote-debugging 地址", "浏览器上下文"),
        "chrome_user_data_dir": ("用户 Chrome User Data 根目录", "浏览器上下文"),
        "chrome_profile_directory": ("Chrome profile 子目录名", "浏览器上下文"),
        "chrome_expected_profile_email": ("期望 Chrome profile 登录邮箱", "浏览器上下文"),
        "browser_channel": ("Playwright 浏览器 channel", "浏览器上下文"),
        "browser_engine": (
            "浏览器 engine：playwright / cloakbrowser",
            "浏览器上下文",
        ),
        "browser_humanize": (
            "是否启用人类行为模拟（仅 cloakbrowser）",
            "浏览器上下文",
        ),
        "browser_human_preset": (
            "humanize 预设：default / careful",
            "浏览器上下文",
        ),
        "display_mode": ("浏览器显示模式", "显示配置"),
        "novnc_port": ("noVNC 端口", "显示配置"),
        "transaction_timeout": ("交易超时时间（秒）", "超时配置"),
        "data_dir": ("数据目录", "存储配置"),
    }

    table = Table(title="Pay-Switch 当前配置", border_style="cyan")
    table.add_column("配置项", style="bold cyan", no_wrap=True)
    table.add_column("当前值")
    table.add_column("说明", style="dim")
    table.add_column("分类", style="dim")

    for cfg_key, cfg_value in config_dict.items():
        desc, category = config_descriptions.get(cfg_key, (cfg_key, "其他"))

        # 对 API Key 进行脱敏处理
        display_value = cfg_value
        if cfg_key == "llm_api_key" and cfg_value:
            display_value = "***已设置***"
        elif cfg_key == "card_instruments" and isinstance(cfg_value, list):
            display_value = f"{len(cfg_value)} 张卡（不显示卡号）"
        elif cfg_key == "vault":
            display_value = "[dim]（已隐藏）[/dim]"
        elif cfg_value is None:
            display_value = "[dim]（未设置）[/dim]"
        elif isinstance(cfg_value, list):
            display_value = ", ".join(cfg_value) if cfg_value else "[dim]（空）[/dim]"

        table.add_row(cfg_key, str(display_value), desc, category)

    console.print(table)
    console.print("\n[dim]使用 [bold]payswitch config <key> <value>[/bold] 修改配置项[/dim]")


def _coerce_config_value(key: str, value_str: str, original) -> object:
    """将字符串配置值转换为与原始值类型匹配的 Python 对象。"""
    if isinstance(original, bool):
        return value_str.lower() in ("true", "1", "yes", "on")
    elif isinstance(original, int):
        return int(value_str)
    elif isinstance(original, float):
        return float(value_str)
    elif isinstance(original, list):
        # 列表类型：逗号分隔的字符串
        if value_str.strip() == "":
            return []
        return [item.strip() for item in value_str.split(",") if item.strip()]
    elif original is None:
        # None 类型：尝试解析数字，否则保持字符串
        try:
            return int(value_str)
        except ValueError:
            try:
                return float(value_str)
            except ValueError:
                return value_str
    else:
        return value_str


# ---------------------------------------------------------------------------
# Web UI settings API helpers
# ---------------------------------------------------------------------------
_SETTINGS_API_WRITABLE_KEYS = frozenset(
    {
        "max_per_transaction",
        "daily_limit",
        "whitelist",
        "auto_confirm_threshold",
        "payment_priority",
        "disabled_payment_methods",
        "allow_card_number_only",
        "allow_virtual_card",
        "require_human_for_expiry",
        "require_human_for_cvv",
        "require_human_for_otp",
        "require_human_for_final_confirm",
        "default_currency",
        "llm_provider",
        "llm_model",
        "stripe_webhook_port",
        "stripe_default_currency",
        "computer_use_enabled",
        "computer_use_driver",
        "computer_use_max_autonomous_category",
        "browser_control_backend",
        "chrome_cdp_url",
        "browser_channel",
        "browser_engine",
        "browser_humanize",
        "browser_human_preset",
        "display_mode",
        "novnc_port",
        "transaction_timeout",
    }
)

_SETTINGS_API_SECRET_KEYS = frozenset(
    {
        "llm_api_key",
        "stripe_secret_key",
        "stripe_webhook_secret",
        "vault",
    }
)


def _settings_api_options() -> dict[str, list[str]]:
    """Return stable option lists for the Web settings console."""
    from payswitch.models.types import (
        BrowserControlBackend,
        ComputerUseDriver,
        DisplayMode,
        PaymentMethod,
        StepCategory,
    )

    return {
        "browser_channels": ["chrome", "chromium"],
        "browser_control_backends": [item.value for item in BrowserControlBackend],
        "computer_use_drivers": [item.value for item in ComputerUseDriver],
        "step_categories": [item.value for item in StepCategory],
        "display_modes": ["", *[item.value for item in DisplayMode]],
        "payment_methods": [item.value for item in PaymentMethod],
        "browser_engines": ["playwright", "cloakbrowser"],
        "browser_human_presets": ["default", "careful"],
    }


def _settings_api_public_config(config) -> dict[str, Any]:  # noqa: ANN001
    """Return config safe for the local Web UI.

    The browser settings UI may show local paths because it runs on localhost for
    the operator, but secrets and legacy vault content are never returned.
    """
    data = config.model_dump(mode="json")
    for key in _SETTINGS_API_SECRET_KEYS:
        data.pop(key, None)
    data["secrets"] = {
        "llm_api_key": bool(config.get_llm_api_key()),
        "stripe_secret_key": bool(config.get_stripe_secret_key()),
        "stripe_webhook_secret": bool(config.get_stripe_webhook_secret()),
        "legacy_vault_cards": len(config.vault.cards),
    }
    data["card_instruments"] = [
        {
            "id": card.id,
            "label": card.label,
            "storage": card.storage,
            "autofill_level": card.autofill_level,
            "has_expiry": card.has_expiry,
            "has_cvv": card.has_cvv,
            "has_holder_name": card.has_holder_name,
            "has_billing_address": card.has_billing_address,
            "allowed_payees": card.allowed_payees,
            "max_per_transaction": card.max_per_transaction,
            "currency_allowlist": card.currency_allowlist,
        }
        for card in config.card_instruments
    ]
    return data


def _settings_api_config_payload(config) -> dict[str, Any]:  # noqa: ANN001
    return {
        "config": _settings_api_public_config(config),
        "options": _settings_api_options(),
        "writable_keys": sorted(_SETTINGS_API_WRITABLE_KEYS),
    }


def _settings_api_validate_config_updates(config, updates: object) -> dict[str, Any]:  # noqa: ANN001
    """Validate a Web UI config patch without writing it to disk."""
    if not isinstance(updates, dict):
        raise ValueError("settings update body must be a JSON object")

    rejected = sorted(
        key
        for key in updates
        if key not in _SETTINGS_API_WRITABLE_KEYS or key in _SETTINGS_API_SECRET_KEYS
    )
    if rejected:
        raise ValueError(f"unsupported or protected setting(s): {', '.join(rejected)}")

    if not updates:
        raise ValueError("settings update body is empty")

    data = config.model_dump(mode="python")
    data.update(updates)
    validated = type(config).model_validate(data)
    validated_data = validated.model_dump(mode="python")
    return {key: validated_data[key] for key in updates}


def _settings_api_profile_matches(profile, query: str | None) -> bool:  # noqa: ANN001
    if not query:
        return True
    needle = query.strip().lower()
    return (
        needle in profile.profile_directory.lower()
        or needle in profile.user_name.lower()
        or needle in profile.name.lower()
        or needle in profile.gaia_name.lower()
        or needle in profile.gaia_given_name.lower()
    )


def _settings_api_profile_payload(profile, index: int) -> dict[str, Any]:  # noqa: ANN001
    identity = profile.user_name or profile.gaia_name or profile.name or "未识别"
    user_data_dir = Path(profile.user_data_dir).as_posix()
    return {
        "index": index,
        "id": f"{user_data_dir}::{profile.profile_directory}",
        "user_data_dir": user_data_dir,
        "profile_directory": profile.profile_directory,
        "email": profile.user_name,
        "name": profile.name,
        "gaia_name": profile.gaia_name,
        "gaia_given_name": profile.gaia_given_name,
        "identity_label": identity,
        "is_consented_primary_account": profile.is_consented_primary_account,
        "active_time": profile.active_time,
    }


def _settings_api_discover_profiles(
    *,
    browser: str = "chrome",
    query: str | None = None,
    user_data_dir: Path | None = None,
) -> list[dict[str, Any]]:
    """Discover selectable browser profiles for the Web settings console."""
    from payswitch.browser.chrome_profiles import (
        discover_chrome_user_data_dirs,
        list_profile_identities,
    )

    browser = browser.strip().lower()
    _validate_profile_browser(browser)

    discovered_roots = discover_chrome_user_data_dirs(browser)
    if user_data_dir:
        selected_root = Path(user_data_dir).expanduser().resolve()
        allowed_roots = {root.expanduser().resolve() for root in discovered_roots}
        if selected_root not in allowed_roots:
            raise ValueError("user_data_dir must be one of the discovered browser roots")
        roots = [selected_root]
    else:
        roots = discovered_roots
    profiles = []
    for root in roots:
        profiles.extend(list_profile_identities(root))

    filtered = [
        profile for profile in profiles if _settings_api_profile_matches(profile, query)
    ]
    return [
        _settings_api_profile_payload(profile, index)
        for index, profile in enumerate(filtered, start=1)
    ]


def _settings_api_select_profile_updates(
    *,
    browser: str,
    user_data_dir: str,
    profile_directory: str,
    keep_cdp: bool = False,
) -> dict[str, Any]:
    """Validate a browser profile selection and return config updates."""
    browser = browser.strip().lower()
    _validate_profile_browser(browser)

    selected_root = Path(user_data_dir).expanduser().resolve()
    selected_profile = profile_directory.strip()
    if not selected_profile:
        raise ValueError("profile_directory is required")

    profiles = _settings_api_discover_profiles(
        browser=browser,
        user_data_dir=selected_root,
    )
    selected = next(
        (
            profile
            for profile in profiles
            if Path(profile["user_data_dir"]).expanduser().resolve() == selected_root
            and profile["profile_directory"] == selected_profile
        ),
        None,
    )
    if selected is None:
        raise ValueError("selected profile was not discovered on this machine")

    updates: dict[str, Any] = {
        "browser_channel": "chrome" if browser == "chrome" else browser,
        "chrome_user_data_dir": selected["user_data_dir"],
        "chrome_profile_directory": selected["profile_directory"],
        "chrome_expected_profile_email": selected["email"],
    }
    if not keep_cdp:
        updates["chrome_cdp_url"] = ""
    return updates


def _settings_api_project_profile_updates(
    config,  # noqa: ANN001
    *,
    user_data_dir: str = "",
    profile_directory: str = "Default",
    browser: str = "chrome",
    expected_email: str = "",
    ensure: bool = False,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Create/bind Pay-Switch's dedicated persistent browser profile."""
    from payswitch.browser.cdp_attach import ensure_profile_cdp_url
    from payswitch.browser.chrome_profiles import (
        default_project_chrome_user_data_dir,
        ensure_project_chrome_profile,
    )
    from payswitch.models.types import BrowserControlBackend

    browser = browser.strip().lower() or "chrome"
    _validate_profile_browser(browser)
    root = (
        Path(user_data_dir).expanduser()
        if user_data_dir.strip()
        else default_project_chrome_user_data_dir(config.data_dir)
    )
    profile = profile_directory.strip() or "Default"
    ensure_project_chrome_profile(root, profile)

    cdp_url = ""
    if ensure:
        cdp_url = ensure_profile_cdp_url(
            user_data_dir=root,
            profile_directory=profile,
            expected_email=expected_email.strip(),
            browser_channel=browser,
            timeout_seconds=timeout,
        )

    return {
        "browser_control_backend": BrowserControlBackend.cdp.value,
        "browser_channel": "chrome" if browser == "chrome" else browser,
        "chrome_user_data_dir": str(root),
        "chrome_profile_directory": profile,
        "chrome_expected_profile_email": expected_email.strip(),
        "chrome_cdp_url": cdp_url,
    }


def _settings_api_ensure_cdp_profile_updates(
    config,  # noqa: ANN001
    *,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Start or reuse CDP Chrome for the currently configured profile."""
    from payswitch.browser.cdp_attach import ensure_profile_cdp_url
    from payswitch.models.types import BrowserControlBackend

    user_data_dir = config.chrome_user_data_dir.strip()
    if not user_data_dir:
        raise ValueError("还没有配置 Chrome profile，请先配置项目专用 profile。")

    profile_directory = config.chrome_profile_directory.strip() or "Default"
    browser = config.browser_channel.strip() or "chrome"
    cdp_url = ensure_profile_cdp_url(
        user_data_dir=Path(user_data_dir).expanduser(),
        profile_directory=profile_directory,
        expected_email=config.chrome_expected_profile_email.strip(),
        browser_channel=browser,
        timeout_seconds=timeout,
    )
    return {
        "browser_control_backend": BrowserControlBackend.cdp.value,
        "chrome_cdp_url": cdp_url,
    }


def _settings_api_browser_doctor_payload(config) -> dict[str, Any]:  # noqa: ANN001
    """Return Browser Doctor diagnostics as structured data for Web UI."""
    from payswitch.browser.runtime import (
        BrowserRuntimeConfigError,
        build_browser_runtime_plan,
        resolve_browser_backend,
    )

    expected_email = config.chrome_expected_profile_email.strip()
    cdp_url = config.chrome_cdp_url.strip()
    user_data_dir = config.chrome_user_data_dir.strip()
    profile_directory = config.chrome_profile_directory.strip() or "Default"
    browser = config.browser_channel.strip() or "chrome"
    launch_mode = resolve_browser_backend(config).value
    identity = None
    active_process = None
    remote_debugging_port = ""
    has_matching_cdp = bool(cdp_url)
    runnable = True
    problems: list[str] = []
    recommendations: list[str] = []

    try:
        plan = build_browser_runtime_plan(
            config,
            validate_identity=True,
            preflight_occupancy=True,
            ensure_cdp=False,
        )
        identity = plan.identity
        has_matching_cdp = bool(plan.launch_kwargs.get("chrome_cdp_url"))
        if plan.occupied:
            active_process = True
            remote_debugging_port = plan.remote_debugging_port
    except BrowserRuntimeConfigError as exc:
        runnable = False
        problems.append(str(exc))

    if launch_mode == "cdp" and user_data_dir and not cdp_url:
        if has_matching_cdp and remote_debugging_port:
            recommendations.append(
                "已发现匹配 profile 的 CDP 端口；可运行 "
                f"uv run payswitch settings cdp-profile --ensure 固化为 http://127.0.0.1:{remote_debugging_port}"
            )
        elif active_process is not None and remote_debugging_port:
            runnable = False
            problems.append("同一 User Data 已有 CDP，但不是当前绑定 profile 的可校验端口")
            recommendations.append(
                "检测到同一 User Data 下已有 CDP 端口，但不是当前绑定 profile 的"
                "可校验端口；不要直接配置该端口，先运行 "
                "uv run payswitch settings cdp-profile --ensure。"
            )
        elif active_process is not None:
            runnable = False
            problems.append("真实 Chrome User Data 目录正在被普通 Chrome 占用，且没有匹配 CDP")
            recommendations.append(
                "检测到普通 Chrome 正在使用该 User Data。运行时会先尝试复用匹配 CDP；"
                "没有且同一 User Data 未被其他 profile 接管时，才按绑定 profile "
                "启动一个带 remote-debugging-port 的真实 Chrome。"
            )
        else:
            recommendations.append(
                "当前没有已开启 CDP 的匹配 profile。若同一 User Data 未被其他 "
                "Chrome 接管，运行交易时会自动启动；"
                "也可先运行 uv run payswitch settings cdp-profile --ensure。"
            )

    if launch_mode == "user_profile" and active_process is not None and not cdp_url:
        runnable = False
        problems.append("真实 Chrome User Data 目录正在被普通 Chrome 占用")
        recommendations.append(
            "真实支付主路径建议改为 CDP：uv run payswitch settings browser-backend "
            "--backend cdp，然后运行 uv run payswitch settings cdp-profile --ensure。"
        )

    if launch_mode == "ephemeral_cdp_mirror":
        recommendations.append(
            "将为当前 Chrome profile 复用 /tmp 下的临时 CDP 镜像并启动独立 Chrome；"
            "适合流程探索，但登录态可能因站点风控或本机密钥绑定而要求重新验证。"
        )

    if not cdp_url and not user_data_dir:
        recommendations.append(
            "当前会使用 Pay-Switch 自管 profile，适合隔离测试；真实支付建议先绑定 profile。"
        )

    return {
        "launch_mode": launch_mode,
        "configured_backend": config.browser_control_backend.value,
        "runnable": runnable,
        "browser_channel": browser,
        "chrome_cdp_url": cdp_url,
        "chrome_user_data_dir": user_data_dir,
        "chrome_profile_directory": profile_directory,
        "expected_email": expected_email,
        "resolved_email": identity.user_name if identity else "",
        "active_process": (
            {
                "user_data_dir": user_data_dir,
                "profile_directory": profile_directory,
                "remote_debugging_port": remote_debugging_port,
            }
            if active_process
            else None
        ),
        "problems": problems,
        "recommendations": recommendations,
    }


def _settings_api_transaction_session_payload(
    tx,  # noqa: ANN001
    *,
    evidence_root: Path,
    request_base_url: str,
) -> dict[str, Any]:
    """Project one ledger transaction into the Web runtime session model."""
    from payswitch.models.types import TransactionStatus

    events = [_settings_api_intent_event(tx)]
    for step in tx.steps:
        events.append(
            _settings_api_step_event(
                tx,
                step,
                evidence_root=evidence_root,
                request_base_url=request_base_url,
            )
        )

    if tx.human_action and tx.human_action.completed_at is None:
        events.append(
            _settings_api_human_action_event(
                tx,
                evidence_root=evidence_root,
                request_base_url=request_base_url,
            )
        )

    if tx.status == TransactionStatus.completed:
        events.append(
            {
                "id": f"{tx.tx_id}-completed",
                "ts": _settings_api_iso(tx.completed_at or tx.created_at),
                "type": "completed",
                "summary": "交易完成",
                "message": f"{tx.payee} 已完成入账。",
                "source": "ledger",
                "path": ["External Agent", "Pay-Switch", "Ledger"],
                "risk": "low",
                "target": tx.payee,
            }
        )

    return {
        "id": tx.tx_id,
        "agent": "Codex",
        "merchant": tx.payee,
        "amount": tx.amount,
        "currency": tx.currency,
        "reason": tx.reason,
        "status": _settings_api_session_status(tx.status),
        "startedAt": _settings_api_time_label(tx.created_at),
        "events": events,
    }


def _settings_api_intent_event(tx) -> dict[str, Any]:  # noqa: ANN001
    payment_method = tx.payment_method.value if tx.payment_method else "auto"
    return {
        "id": f"{tx.tx_id}-intent",
        "ts": _settings_api_iso(tx.created_at),
        "type": "intent.received",
        "summary": f"收到 {tx.payee} 支付请求",
        "message": f"{tx.currency} {tx.amount:.2f}，方式：{payment_method}。{tx.reason}",
        "source": "codex",
        "path": ["External Agent", "Pay-Switch"],
        "risk": "low",
        "target": tx.payee,
    }


def _settings_api_step_event(
    tx,  # noqa: ANN001
    step,  # noqa: ANN001
    *,
    evidence_root: Path,
    request_base_url: str,
) -> dict[str, Any]:
    evidence = _settings_api_read_step_evidence(step.evidence_path)
    action = evidence.get("action") if isinstance(evidence.get("action"), dict) else {}
    action_result = (
        evidence.get("action_result") if isinstance(evidence.get("action_result"), dict) else {}
    )
    action_type = str(action.get("type") or "")
    event_type = _settings_api_step_event_type(step.status, action_type, action_result)
    current_url = _settings_api_string(
        action_result.get("current_url") or evidence.get("current_url")
    )
    screenshot_path = _settings_api_string(
        action_result.get("screenshot_path") or step.screenshot_path
    )
    interaction_hints = action_result.get("interaction_hints")
    payment_methods = action_result.get("detected_payment_methods")

    payload: dict[str, Any] = {
        "id": f"{tx.tx_id}-step-{step.step_index}",
        "ts": _settings_api_iso(step.completed_at or step.started_at or tx.created_at),
        "type": event_type,
        "summary": step.description,
        "message": _settings_api_step_message(step),
        "source": "pay_switch",
        "path": ["External Agent", "Pay-Switch", "Browser", tx.payee],
        "risk": step.risk.value,
        "target": step.category.value,
    }
    if current_url:
        payload["current_url"] = current_url
    if screenshot_path:
        payload["screenshot_path"] = screenshot_path
        screenshot_url = _settings_api_evidence_image_url(
            screenshot_path,
            evidence_root=evidence_root,
            request_base_url=request_base_url,
        )
        if screenshot_url:
            payload["screenshot_url"] = screenshot_url
    qr_artifact_path = _settings_api_string(action_result.get("qr_artifact_path"))
    if qr_artifact_path:
        payload["qr_artifact_path"] = qr_artifact_path
        qr_artifact_url = _settings_api_evidence_image_url(
            qr_artifact_path,
            evidence_root=evidence_root,
            request_base_url=request_base_url,
        )
        if qr_artifact_url:
            payload["qr_artifact_url"] = qr_artifact_url
    media_artifacts = _settings_api_project_media_artifacts(
        action_result.get("media_artifacts"),
        evidence_root=evidence_root,
        request_base_url=request_base_url,
    )
    if media_artifacts:
        payload["media_artifacts"] = media_artifacts
    if isinstance(interaction_hints, list) and interaction_hints:
        payload["interaction_hints"] = interaction_hints
    if isinstance(payment_methods, list) and payment_methods:
        payload["detected_payment_methods"] = payment_methods
    return payload


def _settings_api_human_action_event(
    tx,  # noqa: ANN001
    *,
    evidence_root: Path,
    request_base_url: str,
) -> dict[str, Any]:
    human_action = tx.human_action
    details = human_action.details if human_action and human_action.details else {}
    current_url = _settings_api_string(details.get("current_url"))
    latest_visual = _settings_api_latest_visual_event_extra(
        tx,
        evidence_root=evidence_root,
        request_base_url=request_base_url,
    )
    payload: dict[str, Any] = {
        "id": f"{tx.tx_id}-human-{human_action.action_type if human_action else 'action'}",
        "ts": _settings_api_iso(human_action.requested_at if human_action else tx.created_at),
        "type": "human.gate",
        "summary": _settings_api_human_action_title(human_action.action_type),
        "message": human_action.guidance or "请在真实浏览器中完成人工操作后继续。",
        "source": "human",
        "path": ["External Agent", "Pay-Switch", "Human Gate"],
        "risk": "high",
        "target": human_action.action_type,
        "details": details,
    }
    if current_url:
        payload["current_url"] = current_url
    if human_action.novnc_url:
        payload["display_url"] = human_action.novnc_url
    qr_artifact_path = _settings_api_string(details.get("qr_artifact_path"))
    if qr_artifact_path:
        payload["qr_artifact_path"] = qr_artifact_path
        qr_artifact_url = _settings_api_evidence_image_url(
            qr_artifact_path,
            evidence_root=evidence_root,
            request_base_url=request_base_url,
        )
        if qr_artifact_url:
            payload["qr_artifact_url"] = qr_artifact_url
    payload.update({key: value for key, value in latest_visual.items() if key not in payload})
    return payload


def _settings_api_latest_visual_event_extra(
    tx,  # noqa: ANN001
    *,
    evidence_root: Path,
    request_base_url: str,
) -> dict[str, Any]:
    for step in reversed(tx.steps):
        evidence = _settings_api_read_step_evidence(step.evidence_path)
        action_result = (
            evidence.get("action_result")
            if isinstance(evidence.get("action_result"), dict)
            else {}
        )
        screenshot_path = _settings_api_string(
            action_result.get("screenshot_path") or step.screenshot_path
        )
        current_url = _settings_api_string(
            action_result.get("current_url") or evidence.get("current_url")
        )
        if not screenshot_path and not current_url:
            continue
        extra: dict[str, Any] = {}
        if current_url:
            extra["current_url"] = current_url
        if screenshot_path:
            extra["screenshot_path"] = screenshot_path
            screenshot_url = _settings_api_evidence_image_url(
                screenshot_path,
                evidence_root=evidence_root,
                request_base_url=request_base_url,
            )
            if screenshot_url:
                extra["screenshot_url"] = screenshot_url
        media_artifacts = _settings_api_project_media_artifacts(
            action_result.get("media_artifacts"),
            evidence_root=evidence_root,
            request_base_url=request_base_url,
        )
        if media_artifacts:
            extra["media_artifacts"] = media_artifacts
        return extra
    return {}


def _settings_api_step_event_type(
    status: str,
    action_type: str,
    action_result: dict[str, Any],
) -> str:
    if action_type == "observe" or action_result.get("kind") == "page_observation":
        return "observe"
    if status == "failed":
        return "action.blocked"
    if status == "pending":
        return "route.selected"
    return "action.allowed"


def _settings_api_step_message(step) -> str:  # noqa: ANN001
    duration = step.duration_seconds()
    if duration is None:
        return step.status
    return f"{step.status}，耗时 {duration:.1f}s"


def _settings_api_human_action_title(action_type: str) -> str:
    return {
        "requires_login": "需要登录后继续",
        "requires_identity_verification": "需要完成身份校验",
        "requires_plan_confirmation": "需要确认购买方案",
        "scan_qr": "等待扫码付款",
        "confirm": "等待最终付款确认",
        "takeover": "等待人工接管",
    }.get(action_type, "等待人工操作")


def _settings_api_session_status(status) -> str:  # noqa: ANN001
    from payswitch.models.types import TransactionStatus

    if status == TransactionStatus.completed:
        return "completed"
    if status == TransactionStatus.human_action_required:
        return "waiting_human"
    return "running"


def _settings_api_read_step_evidence(evidence_path: str | None) -> dict[str, Any]:
    if not evidence_path:
        return {}
    try:
        from payswitch.models.config import PaySwitchConfig

        config = PaySwitchConfig.load()
        path = Path(evidence_path).expanduser()
        if path.suffix.lower() != ".json" or not path.exists():
            return {}
        data = ArtifactStore(config.data_dir).read_json(path)
    except (OSError, json.JSONDecodeError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _settings_api_read_evidence_bytes(raw_path: str) -> tuple[bytes, str] | None:
    if not raw_path:
        return None
    try:
        from payswitch.models.config import PaySwitchConfig

        config = PaySwitchConfig.load()
        path = Path(raw_path).expanduser()
        if not path.exists():
            return None
        store = ArtifactStore(config.data_dir)
        try:
            content_type = store.read_content_type(path)
        except (OSError, ValueError):
            content_type = None
        if not content_type:
            content_type = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        return store.read_bytes(path), content_type
    except (OSError, ValueError):
        return None


def _settings_api_evidence_image_url(
    raw_path: str,
    *,
    evidence_root: Path,
    request_base_url: str,
) -> str:
    from urllib.parse import quote

    try:
        resolved = Path(raw_path).expanduser().resolve()
    except OSError:
        return ""
    if not resolved.is_relative_to(evidence_root):
        return ""
    if resolved.suffix.lower() not in _SETTINGS_API_EVIDENCE_IMAGE_SUFFIXES:
        return ""
    return f"{request_base_url}/evidence?path={quote(str(resolved))}"


def _settings_api_evidence_preview_url(
    raw_path: str,
    *,
    evidence_root: Path,
    request_base_url: str,
) -> str:
    from urllib.parse import quote

    try:
        resolved = Path(raw_path).expanduser().resolve()
    except OSError:
        return ""
    if not resolved.is_relative_to(evidence_root):
        return ""
    if resolved.suffix.lower() not in _SETTINGS_API_EVIDENCE_PREVIEW_SUFFIXES:
        return ""
    return f"{request_base_url}/evidence?path={quote(str(resolved))}"


def _settings_api_project_media_artifacts(
    value: object,
    *,
    evidence_root: Path,
    request_base_url: str,
) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    projected: list[dict[str, Any]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        artifact = dict(item)
        recording_index = _settings_api_non_negative_int(
            item.get("recording_index") or item.get("recordingIndex")
        )
        recording_source = _settings_api_string(
            item.get("recording_source") or item.get("recordingSource")
        )
        if recording_index is not None:
            artifact.setdefault("recording_index", recording_index)
            artifact.setdefault("recordingIndex", recording_index)
        if recording_source:
            artifact.setdefault("recording_source", recording_source)
            artifact.setdefault("recordingSource", recording_source)
        capture_engine = _settings_api_string(
            item.get("capture_engine") or item.get("captureEngine")
        )
        if capture_engine:
            artifact.setdefault("capture_engine", capture_engine)
            artifact.setdefault("captureEngine", capture_engine)
        size_bytes = _settings_api_non_negative_int(item.get("size_bytes") or item.get("sizeBytes"))
        duration_seconds = _settings_api_non_negative_float(
            item.get("duration_seconds") or item.get("durationSeconds")
        )
        frame_rate = _settings_api_non_negative_float(
            item.get("frame_rate") or item.get("frameRate")
        )
        source_screenshot_count = _settings_api_non_negative_int(
            item.get("source_screenshot_count") or item.get("sourceScreenshotCount")
        )
        bit_rate = _settings_api_non_negative_int(item.get("bit_rate") or item.get("bitRate"))
        frame_width = _settings_api_non_negative_int(
            item.get("frame_width") or item.get("frameWidth")
        )
        frame_height = _settings_api_non_negative_int(
            item.get("frame_height") or item.get("frameHeight")
        )
        codec_name = _settings_api_string(item.get("codec_name") or item.get("codecName"))
        raw_path = _settings_api_string(item.get("artifact_path") or item.get("artifactPath"))
        if raw_path:
            preview_url = _settings_api_evidence_preview_url(
                raw_path,
                evidence_root=evidence_root,
                request_base_url=request_base_url,
            )
            if preview_url:
                artifact.setdefault("download_url", preview_url)
                artifact.setdefault("downloadUrl", preview_url)
            if size_bytes is None:
                try:
                    size_bytes = Path(raw_path).expanduser().stat().st_size
                except OSError:
                    size_bytes = None
        if size_bytes is not None:
            artifact.setdefault("size_bytes", size_bytes)
            artifact.setdefault("sizeBytes", size_bytes)
        if duration_seconds is not None:
            artifact.setdefault("duration_seconds", duration_seconds)
            artifact.setdefault("durationSeconds", duration_seconds)
        if frame_rate is not None:
            artifact.setdefault("frame_rate", frame_rate)
            artifact.setdefault("frameRate", frame_rate)
        if source_screenshot_count is not None:
            artifact.setdefault("source_screenshot_count", source_screenshot_count)
            artifact.setdefault("sourceScreenshotCount", source_screenshot_count)
        if bit_rate is not None:
            artifact.setdefault("bit_rate", bit_rate)
            artifact.setdefault("bitRate", bit_rate)
        if frame_width is not None:
            artifact.setdefault("frame_width", frame_width)
            artifact.setdefault("frameWidth", frame_width)
        if frame_height is not None:
            artifact.setdefault("frame_height", frame_height)
            artifact.setdefault("frameHeight", frame_height)
        if codec_name:
            artifact.setdefault("codec_name", codec_name.lower())
            artifact.setdefault("codecName", codec_name.lower())
        projected.append(artifact)
    return projected


def _settings_api_iso(value) -> str:  # noqa: ANN001
    return value.isoformat() if value else ""


def _settings_api_time_label(value) -> str:  # noqa: ANN001
    return value.strftime("%H:%M:%S") if value else ""


def _settings_api_string(value: object) -> str:
    return value if isinstance(value, str) and value.strip() else ""


def _settings_api_non_negative_int(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value >= 0 else None
    if isinstance(value, float):
        if value.is_integer() and value >= 0:
            return int(value)
        return None
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        try:
            parsed = int(raw)
        except ValueError:
            return None
        return parsed if parsed >= 0 else None
    return None


def _settings_api_non_negative_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        parsed = float(value)
        return parsed if parsed >= 0 else None
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        try:
            parsed = float(raw)
        except ValueError:
            return None
        return parsed if parsed >= 0 else None
    return None


# ---------------------------------------------------------------------------
# platforms — 管理已登录的平台
# ---------------------------------------------------------------------------
@app.command("platforms")
def platforms(
    action: Annotated[
        str,
        typer.Argument(help="操作：list / remove / refresh。"),
    ] = "list",
    platform: Annotated[
        str | None,
        typer.Argument(help="平台标识（remove/refresh 操作需要）。"),
    ] = None,
) -> None:
    """管理已登录的支付平台。

    列出所有已保存的平台 Profile、删除指定平台登录状态，
    或刷新 Profile 的有效性检测。

    示例：
      payswitch platforms list
      payswitch platforms remove deepseek
      payswitch platforms refresh kimi
    """
    from payswitch.adapters import AdapterRegistry
    from payswitch.browser.profiles import ProfileManager
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    profiles_dir = config.data_dir / "profiles"
    profile_manager = ProfileManager(data_dir=profiles_dir)

    if action == "list":
        _platforms_list(profile_manager, AdapterRegistry)

    elif action == "remove":
        if platform is None:
            _print_error("remove 操作需要指定平台标识，例如：payswitch platforms remove deepseek")
            raise typer.Exit(code=1)
        _platforms_remove(platform, profile_manager)

    elif action == "refresh":
        if platform is None:
            _print_error("refresh 操作需要指定平台标识，例如：payswitch platforms refresh deepseek")
            raise typer.Exit(code=1)
        _platforms_refresh(platform, profile_manager)

    else:
        _print_error(f"未知操作：'{action}'，有效操作：list / remove / refresh")
        raise typer.Exit(code=1)


def _platforms_list(profile_manager, adapter_registry) -> None:
    """列出所有已注册适配器和已登录 Profile 状态。"""
    # 获取所有已注册适配器信息
    registered_adapters = adapter_registry.list_platforms()

    # 获取所有已登录的 Profile
    profiles = profile_manager.list_profiles()
    profile_by_platform = {p.platform: p for p in profiles}

    # 合并：已注册适配器 + 已登录但无适配器的 Profile
    all_platforms = {}
    for adapter_info in registered_adapters:
        name = adapter_info["name"]
        all_platforms[name] = {
            "name": name,
            "display_name": adapter_info["display_name"],
            "has_adapter": True,
            "login_url": adapter_info.get("login_url", ""),
            "top_up_url": adapter_info.get("top_up_url", ""),
            "supported_methods": adapter_info.get("supported_methods", []),
            "profile": profile_by_platform.get(name),
        }

    # 已登录但未注册适配器的平台
    for p_name, profile in profile_by_platform.items():
        if p_name not in all_platforms:
            all_platforms[p_name] = {
                "name": p_name,
                "display_name": profile.display_name,
                "has_adapter": False,
                "login_url": "",
                "top_up_url": "",
                "supported_methods": [],
                "profile": profile,
            }

    if _state.json_output:
        data = []
        for p_info in all_platforms.values():
            profile = p_info["profile"]
            data.append(
                {
                    "name": p_info["name"],
                    "display_name": p_info["display_name"],
                    "has_adapter": p_info["has_adapter"],
                    "supported_methods": p_info["supported_methods"],
                    "logged_in": profile is not None,
                    "status": profile.status if profile else None,
                    "logged_in_at": (
                        str(profile.logged_in_at) if profile and profile.logged_in_at else None
                    ),
                }
            )
        _print_json(data)
        return

    if not all_platforms:
        console.print("[dim]暂无已注册的平台或已登录的 Profile。[/dim]")
        return

    table = Table(title="支付平台列表", border_style="cyan")
    table.add_column("平台标识", style="bold cyan", no_wrap=True)
    table.add_column("展示名称")
    table.add_column("适配器")
    table.add_column("支付方式")
    table.add_column("登录状态")
    table.add_column("最近登录")

    for p_info in sorted(all_platforms.values(), key=lambda x: x["name"]):
        profile = p_info["profile"]

        adapter_badge = (
            "[green]✓ 已注册[/green]" if p_info["has_adapter"] else "[dim]无适配器[/dim]"
        )
        methods_str = ", ".join(p_info["supported_methods"]) if p_info["supported_methods"] else "-"

        if profile is None:
            login_status = "[dim]未登录[/dim]"
            login_time = "-"
        else:
            status_colors = {"active": "green", "expired": "yellow", "unknown": "dim"}
            status_labels = {"active": "已登录", "expired": "已过期", "unknown": "状态未知"}
            s_color = status_colors.get(profile.status, "white")
            s_label = status_labels.get(profile.status, profile.status)
            login_status = f"[{s_color}]{s_label}[/{s_color}]"
            login_time = _format_datetime(profile.logged_in_at)

        table.add_row(
            p_info["name"],
            p_info["display_name"],
            adapter_badge,
            methods_str,
            login_status,
            login_time,
        )

    console.print(table)
    console.print("\n[dim]使用 [bold]payswitch login <platform>[/bold] 登录平台[/dim]")


def _platforms_remove(platform: str, profile_manager) -> None:
    """删除指定平台的 Profile。"""
    existing = profile_manager.get_profile(platform)
    if existing is None:
        _print_error(f"平台 '{platform}' 的 Profile 不存在")
        raise typer.Exit(code=1)

    if not _state.json_output:
        confirmed = typer.confirm(
            f"确认删除 '{platform}' 的登录状态？",
            default=False,
        )
        if not confirmed:
            console.print("[dim]已取消删除操作。[/dim]")
            return

    profile_manager.delete_profile(platform)

    if _state.json_output:
        _print_json({"success": True, "platform": platform})
    else:
        console.print(f"[green]OK[/green] 已删除 [bold]{platform}[/bold] 的登录状态。")


def _platforms_refresh(platform: str, profile_manager) -> None:
    """刷新指定平台 Profile 的有效性检测。"""
    session_status = profile_manager.check_session(platform)

    if session_status == "unknown":
        _print_error(f"平台 '{platform}' 的 Profile 不存在，请先运行 payswitch login {platform}")
        raise typer.Exit(code=1)

    if _state.json_output:
        _print_json(
            {
                "platform": platform,
                "session_status": session_status,
            }
        )
        return

    status_info = {
        "active": ("[green]活跃[/green]", "登录状态有效，无需重新登录"),
        "expired": (
            "[yellow]已过期[/yellow]",
            f"登录状态已超过 7 天，建议运行 payswitch login {platform} 重新登录",
        ),
    }

    status_label, status_desc = status_info.get(session_status, (session_status, "状态未知"))

    console.print(
        Panel(
            f"[bold]平台：[/bold]{platform}\n"
            f"[bold]会话状态：[/bold]{status_label}\n"
            f"[dim]{status_desc}[/dim]",
            title="[cyan]会话状态检测[/cyan]",
            border_style="cyan",
        )
    )


# ---------------------------------------------------------------------------
# 主入口（开发调试用）
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app()
