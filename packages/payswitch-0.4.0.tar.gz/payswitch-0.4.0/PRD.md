# Pay-Switch — 产品需求文档

> 让 AI Agent 学会花钱的支付编排工具

---

## 1. 概述

### 1.1 背景

2026 年，AI Agent（Claude Code、OpenClaw、Hermes 等）已经能写代码、操作浏览器、调用 API。但它们有一个关键能力缺失：**不会花钱**。

当 Agent 需要购买 DeepSeek API 额度、充值 Kimi Token、订阅 SaaS 工具时，它只能停下来说"请你去充值"——所有操作中断，人类不得不手动完成整个支付流程。

现有的解决方案要么偏向加密货币（Coinbase AgentKit、x402），要么需要预充值到钱包（传统支付网关），要么功能太单一（只做策略控制或只做某个支付通道）。**没有人做出一个完整的、面向法币、无需预充值的 Agent 支付编排工具。**

### 1.2 产品定位

**Pay-Switch 是一个支付编排工具（Payment Orchestration Tool），不是钱包，不是充值系统。**

它的核心价值：AI Agent 接入 Pay-Switch 后，自动获得**花钱的能力**——知道怎么走完一个支付流程，在关键步骤请人类确认，完成支付后继续执行任务。

类比：Pay-Switch 是支付世界的 GPS 导航。Agent 按导航走，到了收费站（支付确认）让司机（人类）自己刷卡。

### 1.3 核心原则

- **不充值、不预存**：用户不需要往 Pay-Switch 里存钱，用自己的支付方式（支付宝/银行卡）直接付
- **Agent 准备，人类确认**：Agent 完成 80-90% 的操作（填表、选品、到达支付页），人类完成最后 10%（扫码/输卡号/点确认）
- **不碰敏感信息**：Agent 永远不持有信用卡号、支付密码等敏感数据
- **不做加密货币**：只做法币支付（支付宝、银行卡、信用卡等）
- **独立部署**：通用网关，任何 Agent 框架都可接入，后续再与 ClawHunt 联动

### 1.4 目标用户

| 用户角色 | 描述 | 核心需求 |
|---------|------|---------|
| **Agent 开发者** | 使用 Claude Code / OpenClaw / Hermes / LangChain 等框架的开发者 | 给自己的 Agent 加上支付能力，几行代码接入 |
| **Agent 最终用户** | 使用 Agent 完成日常任务的人 | Agent 帮我走完支付流程，我只需要最后确认一下 |

### 1.5 成功标准

- Agent 开发者 **5 分钟内**完成接入（`pip install payswitch` → `payswitch login deepseek` → `payswitch spend 200 deepseek`）
- 任何能执行 shell 命令的 Agent **无需额外集成代码**，直接通过 CLI 使用 Pay-Switch
- 支持至少 **2 个支付通道**（支付宝 + 银行卡/Stripe）
- 完整跑通 **1 个端到端场景**（Agent 自动充值 DeepSeek API）

---

## 2. 核心概念

### 2.1 支付编排模型

```
传统模式（人类自己干所有事）：
  人类搜索 → 人类选品 → 人类加购 → 人类填表 → 人类付款

Pay-Switch 模式（Agent 干大部分，人类只确认）：
  Agent 搜索 → Agent 选品 → Agent 加购 → Agent 填表 → Agent 到达支付页
      → 暂停 → 展示给人类 → 人类扫码/填卡号/确认 → Agent 验证完成
```

### 2.2 两种支付交互模式

| 模式 | 触发条件 | 人类参与方式 | 典型场景 |
|------|---------|-------------|---------|
| **扫码模式** | 支付页出现 QR 码 | Agent 展示 QR 码，人类用手机扫码支付 | 支付宝、微信支付 |
| **填卡模式** | 支付页出现表单 | Agent 定位表单字段，人类输入卡号等信息并确认 | 银行卡、信用卡、Stripe |

### 2.3 Pay-Switch 的三层能力

```
┌─────────────────────────────────────────────┐
│  能力一：认钱（Know）                         │
│  "这个支付页长什么样？要填哪些字段？"          │
│  → 识别支付页面类型、支付方式、必填字段         │
│  → 返回结构化的支付步骤指引                    │
└─────────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────┐
│  能力二：会花（Execute）                      │
│  "怎么一步步走完这个支付流程？"                │
│  → 自动填写非敏感字段（地址、数量、优惠码）     │
│  → 到达支付环节时暂停，请求人类介入              │
│  → 每种支付方式对应一个 Adapter                │
└─────────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────┐
│  能力三：敢花（Guard）                        │
│  "这笔钱该不该花？要不要先问主人？"            │
│  → 基础限额检查（单笔/日/月）                  │
│  → 商户白名单验证                              │
│  → 幂等去重（防止重复扣款）                     │
│  → 超额时通知人类审批                          │
└─────────────────────────────────────────────┘
```

---

## 3. 浏览器执行环境

### 3.0 为什么需要浏览器

现实中付款几乎都离不开浏览器：
- 你得先**登录**目标平台（DeepSeek/Kimi/淘宝），才能看到充值页
- 登录状态保存在 **Cookie/Session** 里，纯 API 拿不到
- 很多平台**没有开放 API**，只能通过网页操作
- 支付宝 QR 码是**动态渲染**在网页上的，不是一个固定链接

**结论：Pay-Switch 必须包含或集成浏览器控制能力。**

### 3.0.1 浏览器架构选择：四层可插拔方案

Pay-Switch 采用**四层浏览器架构**，每一层解决不同的问题：

```
┌──────────────────────────────────────────────────────────────┐
│                    Pay-Switch 浏览器层                           │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Layer 1: 智能执行引擎（双模式）                         │  │
│  │                                                        │  │
│  │  模式 A — 脚本模式（Playwright 直接执行）                │  │
│  │    用于已知的、稳定的网站，快速、便宜、确定性高            │  │
│  │    page.click("#top-up-btn")                            │  │
│  │    page.fill("input[name='amount']", "200")            │  │
│  │                                                        │  │
│  │  模式 B — 智能模式（Skyvern = Playwright + LLM 视觉）   │  │
│  │    用于未知网站、脚本失败后的回退                         │  │
│  │    page.act(prompt="选择 200 元的充值套餐")              │  │
│  │    page.act(prompt="选择支付宝支付方式")                 │  │
│  │    AI 看截图理解页面语义，不依赖 CSS 选择器               │  │
│  │    网站改版也能继续工作                                  │  │
│  │                                                        │  │
│  │  回退链：脚本模式 → 失败 → 智能模式 → 还是失败 → 人类接管 │  │
│  └────────────────────────────────────────────────────────┘  │
│                          ↕ 连接                               │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Layer 2: Profile 隔离层（可选 AdsPower / 内置）         │  │
│  │  管理多个浏览器 Profile，每个 Profile 独立隔离             │  │
│  │                                                        │  │
│  │  方案 A（MVP）：Playwright 内置 persistent context      │  │
│  │    └─ 简单直接，适合个人使用，无反检测能力                │  │
│  │                                                        │  │
│  │  方案 B（推荐）：AdsPower 指纹浏览器                     │  │
│  │    └─ 50+ 参数指纹伪装，不被平台检测为自动化              │  │
│  │    └─ Local API（端口 50325）启动 Profile                │  │
│  │    └─ Playwright 通过 chromium.connect_over_cdp() 连接   │  │
│  │    └─ 每个商户一个 Profile，Cookie/登录状态完全隔离       │  │
│  │    └─ 免费版 2 个 Profile，付费版无限                    │  │
│  │                                                        │  │
│  │  方案 C（扩展）：第三方远程浏览器                         │  │
│  │    └─ Browserbase / Anchor / Bright Data / Hyperbrowser │  │
│  │    └─ 云端运行，适合服务器部署场景                        │  │
│  └────────────────────────────────────────────────────────┘  │
│                          ↕ 展示画面                            │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Layer 3: 人类交互层（自动适配部署环境）                   │  │
│  │  让人类实时看到并操作 Agent 控制的浏览器                    │  │
│  │                                                        │  │
│  │  本地桌面（Windows/macOS）→ 直接弹 Chrome 窗口            │  │
│  │    └─ Playwright headless=False，最简单直接               │  │
│  │    └─ 用户在弹出的窗口里操作，和平时用浏览器一样           │  │
│  │                                                        │  │
│  │  远程服务器 / Docker → noVNC                             │  │
│  │    └─ Xvfb + x11vnc + websockify + noVNC                │  │
│  │    └─ 用户通过 URL 在任意设备浏览器中观看和操作            │  │
│  │    └─ 无需安装客户端，支持手机/iframe 嵌入                │  │
│  │                                                        │  │
│  │  自动检测：Pay-Switch 启动时判断是否有桌面环境               │  │
│  │    有桌面 → 弹窗模式 | 无桌面 → noVNC 模式                │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Layer 4: Safety Layer（浏览器安全层）                    │  │
│  │                                                        │  │
│  │  • 敏感页面检测 → 自动暂停 + 弹窗/推送 noVNC 链接        │  │
│  │  • 密码/CVV 输入框 → Agent 不看，等待人类输入             │  │
│  │  • 域名白名单 → 只允许访问可信站点                       │  │
│  │  • noVNC 认证 → 防止未授权访问浏览器会话                  │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**四层各自解决什么问题？**

| 问题 | 纯 Playwright 脚本的缺陷 | Pay-Switch 的解决方案 |
|------|------------------------|-------------------|
| 网站改版了怎么办？ | CSS 选择器失效，脚本报废 | **Skyvern 智能模式**：AI 看截图理解页面，不依赖选择器 |
| 未知网站怎么支付？ | 没有预写适配器，无法操作 | **Skyvern 智能模式**：自然语言描述任务，理论上支持任意网站 |
| 人类怎么看到和操作？ | 只能弹本地窗口，服务器不行 | **本地弹窗 + noVNC**：自动适配部署环境 |
| 支付平台检测自动化？ | Playwright 指纹容易被识别和封禁 | **AdsPower**：真实指纹伪装，不可检测 |
| 多账户登录状态串了？ | 手动管理 context 目录，容易出错 | **AdsPower**：每个 Profile 完全隔离 |

**Skyvern 是什么？**

Skyvern（GitHub 21.5k ★，AGPL-3.0 开源）是 Playwright 的智能扩展。底层还是 Playwright 驱动浏览器，但上层加了 LLM 视觉模型——AI 通过截图"看"网页，用自然语言理解页面元素，不依赖任何 CSS 选择器。

```python
# 脚本模式 vs 智能模式对比

# 脚本模式（传统 Playwright）—— 快、便宜、但脆弱
await page.click("#top-up-btn")                    # 网站改了 id 就挂
await page.fill("input[name='amount']", "200")     # 网站换了 name 也挂

# 智能模式（Skyvern）—— 通用、抗改版、但需要 LLM 费用
await page.act(prompt="选择 200 元的充值套餐")      # 不管按钮长啥样，AI 看得懂
await page.act(prompt="选择支付宝支付方式")          # 网站改版了？AI 重新看就行
```

**双模式回退策略**：
```
执行支付任务
    │
    ├─ 有预写的脚本（已知网站）？
    │   ├─ 是 → 脚本模式执行（快、便宜）
    │   │       └─ 脚本执行失败？→ 自动切换到智能模式
    │   └─ 否 → 直接用智能模式
    │
    ├─ 智能模式执行
    │   └─ 智能模式也失败？→ 人类通过弹窗/noVNC 接管
    │
    └─ 人类完成操作 → Agent 恢复
```

**AdsPower + Playwright 连接方式：**

```python
# 1. 通过 AdsPower Local API 启动 Profile
import requests
resp = requests.get("http://localhost:50325/api/v1/browser/start",
                     params={"serial_number": "1"})
ws_endpoint = resp.json()["data"]["ws"]["puppeteer"]

# 2. Playwright 连接到 AdsPower 的反检测 Profile
from playwright.async_api import async_playwright
async with async_playwright() as p:
    browser = await p.chromium.connect_over_cdp(ws_endpoint)
    context = browser.contexts[0]  # AdsPower 管理的上下文
    page = context.pages[0]
    await page.goto("https://platform.deepseek.com/top_up")
```

### 3.0.2 浏览器 Profile 管理

Pay-Switch 支持两种 Profile 管理方式，可根据部署场景选择：

**方式 A：内置 Playwright persistent context（MVP 默认）**

```
① 用户运行 payswitch login deepseek
② Pay-Switch 弹出 Chrome 窗口（本地桌面）或生成 noVNC 链接（服务器）
③ 用户手动登录 DeepSeek（输入账号密码、扫码等）
④ 登录成功后，Pay-Switch 保存 Playwright persistent context
⑤ 后续 Agent 使用此 context 时自动带上登录状态
```

**方式 B：AdsPower Profile（推荐，反检测场景）**

```
① 用户在 AdsPower 中创建 Profile（配置指纹 + 代理）
② 用户运行 payswitch login deepseek --provider adspower --profile-id "xxx"
③ Pay-Switch 通过 Local API 启动该 Profile → Playwright 连接
④ 用户通过 noVNC 手动登录 → AdsPower 自动保存登录状态
⑤ 后续 Agent 使用同一 Profile，指纹一致，不触发风控
```

**后续使用**（Agent 自动，两种方式通用）：

```
Agent 调用 spend(payee="deepseek")
→ Pay-Switch 加载对应 Profile（Playwright context 或 AdsPower Profile）
→ 打开已登录的浏览器
→ 直接跳转到充值页（无需再登录）
→ 优先脚本模式执行，失败则切换智能模式（Skyvern）
→ 到达支付环节 → 弹窗（本地）或推送 noVNC 链接（远程）
```

**Session 过期处理**：

```
Pay-Switch 检测到登录已过期
→ 暂停任务
→ 通知用户："DeepSeek 登录已过期，请重新登录"
→ 弹窗（本地）或推送 noVNC 链接（远程），用户重新登录
→ Profile 自动更新
→ 恢复任务
```

### 3.0.3 浏览器运行模式：自动适配部署环境

Pay-Switch 根据运行环境自动选择最合适的人类交互方式：

**本地桌面模式（Windows / macOS / Linux 桌面）**

```
用户在自己电脑上用 CLI / Agent 调用 Pay-Switch
→ Pay-Switch 检测到有桌面环境
→ 直接弹出 Chrome 窗口（Playwright headless=False）
→ 用户在弹出的窗口里看到和操作，跟平时用浏览器一样

最简单、最自然、零配置。
```

**远程/Docker 模式（无桌面的服务器环境）**

```
Pay-Switch 部署在远程服务器或 Docker 容器里
→ Pay-Switch 检测到无桌面环境
→ 启动 Xvfb 虚拟显示 + noVNC
→ 生成 Web 链接（如 http://payswitch:6080/vnc.html?session=xxx）
→ 用户在任意设备的浏览器打开链接，即可看到和操作

支持远程、手机、iframe 嵌入。
```

**环境检测逻辑**：

```python
import os, sys

def detect_display_mode() -> str:
    """自动检测部署环境，选择人类交互方式"""
    if sys.platform == "win32":
        return "headed"             # Windows 始终有桌面
    elif sys.platform == "darwin":
        return "headed"             # macOS 始终有桌面
    elif os.environ.get("DISPLAY"):
        return "headed"             # Linux 有 DISPLAY 环境变量 = 有桌面
    else:
        return "novnc"              # 无桌面，启用 noVNC
```

**对比**：

| 维度 | 本地弹窗（headed） | noVNC（远程） |
|------|------------------|-------------|
| 适用环境 | Windows/macOS/Linux 桌面 | 服务器/Docker/无桌面 |
| 用户体验 | 最自然，就像打开浏览器 | 通过网页链接访问，略有延迟 |
| 配置复杂度 | 零配置 | 需要 Xvfb + x11vnc + websockify |
| 远程访问 | ❌ 只能本机 | ✅ 任何设备 |
| 嵌入 Web UI | ❌ | ✅ iframe 嵌入 |
| 多人观看 | ❌ | ✅ |
| MVP 阶段 | ✅ 优先支持 | 后续支持 |

---

## 3. 功能需求（续）

### 3.1 核心功能 A：支付流程编排引擎

**描述**：Pay-Switch 的大脑。接收 Agent 的"我要花钱买 X"请求，驱动浏览器走完整个支付流程，在需要人类介入时暂停并通知。

**用户故事**：作为 Agent 开发者，我希望 Agent 调用 `pg.spend()` 后，自动走完支付流程并在需要时请人类帮忙，以便我的 Agent 能自主完成购买任务。

**双模式执行**：

```
Agent 调用 spend(amount=200, payee="deepseek", reason="充值API")
    │
    ├─ 已知网站（有预写脚本）？
    │   │
    │   ├─ 是 → 脚本模式：按预定义步骤执行
    │   │   step 1: navigate → platform.deepseek.com/top_up
    │   │   step 2: click → "¥200 套餐"
    │   │   step 3: click → "支付宝支付"
    │   │   step 4: 检测到 QR 码 → 暂停，请人类扫码
    │   │
    │   └─ 脚本执行失败（网站改版等）？→ 自动切换智能模式
    │
    ├─ 未知网站 / 回退 → 智能模式（Skyvern）：
    │   AI 看截图，自然语言执行：
    │   "打开 DeepSeek 充值页，选择 200 元套餐，选支付宝"
    │   → Skyvern 自动识别页面元素并操作
    │   → 检测到支付环节（QR 码/密码框）→ 暂停，请人类介入
    │
    └─ 返回执行状态：
       {
         "plan_id": "plan_xxx",
         "status": "human_action_required",
         "execution_mode": "script" | "smart",
         "current_step": {
           "action": "scan_qr",
           "description": "请用支付宝扫码支付 ¥200"
         },
         "display": {
           "mode": "headed" | "novnc",
           "novnc_url": "http://..."     // 仅远程模式
         }
       }
```

**验收标准**：
- [x] 脚本模式：能为至少 3 个目标站点（DeepSeek、Kimi、Qwen）执行正确的支付流程
- [x] 智能模式：能用自然语言描述走通未预写脚本的网站的支付流程
- [x] 脚本失败时能自动切换到智能模式
- [x] 正确检测支付环节（QR 码/密码框/CVV）并暂停请求人类介入
- [x] 支持扫码模式和填卡模式

---

### 3.2 核心功能 B：支付检测与通道适配

**描述**：检测当前页面处于哪种支付环节，决定是否暂停让人类介入。

在双模式架构下，适配器的职责发生了变化：

```
旧方案：Adapter 负责"怎么操作"（硬编码每个步骤）
新方案：Adapter 只负责"检测支付环节" + "判断是否需要人类"
        "怎么操作"交给脚本模式或 Skyvern 智能模式
```

**支付检测器（MVP）**：

| 检测器 | 检测什么 | 人类参与方式 | 优先级 |
|--------|---------|-------------|--------|
| `QRCodeDetector` | 页面出现 QR 码（支付宝/微信） | 暂停，展示 QR 码让人类扫码 | P0 |
| `SensitiveFormDetector` | 页面出现密码/CVV/卡号输入框 | 暂停，让人类在弹窗/noVNC 中填写 | P0 |
| `PaymentConfirmDetector` | 页面出现"确认支付"等最终确认按钮 | 暂停，让人类做最终确认 | P0 |
| `CompletionDetector` | 页面显示"支付成功"等完成标识 | 不暂停，自动识别支付已完成 | P0 |

**统一检测接口**：

```python
class PaymentDetector:
    def detect(self, page_context) -> DetectionResult | None:
        """检测当前页面是否触发本检测器"""

    def requires_human(self) -> bool:
        """是否需要人类介入"""

    def detect_completion(self, page_context) -> bool:
        """检测操作是否完成（人类扫码后、填卡后）"""
```

**脚本模式的站点适配器**（已知网站专用，可选）：

```python
class SiteAdapter:
    """已知网站的快速脚本，用于跳过 Skyvern 的 LLM 调用"""
    site: str               # 如 "deepseek", "kimi", "qwen"
    top_up_url: str          # 充值页 URL
    steps: list[ScriptStep]  # 预定义的操作步骤

    async def execute(self, page) -> None:
        """按预定义步骤执行，直到触发支付检测器"""
```

**验收标准**：
- [x] QR 码检测器能正确识别支付宝/微信 QR 码并暂停
- [x] 敏感表单检测器能识别密码/CVV/卡号字段并暂停
- [x] 支付完成检测器能识别"支付成功"页面
- [x] 检测器可插拔，新增支付方式只需实现统一接口
- [x] 至少 3 个站点（DeepSeek/Kimi/Qwen）有预写的脚本适配器

---

### 3.3 核心功能 C：人类协作界面（HITL）

**描述**：当 Agent 到达需要人类介入的步骤时，通过此模块与人类沟通。

**交互方式（双通道）**：

```
方式一：浏览器直接操作（主要方式）
  Pay-Switch 弹出浏览器窗口（本地）或推送 noVNC 链接（远程）
  → 人类直接在浏览器里操作：扫码 / 填卡号 / 点确认
  → Pay-Switch 检测到操作完成 → Agent 继续

方式二：结构化数据返回（补充方式）
  Pay-Switch 返回结构化确认请求给 Agent
  → Agent 通过自身 UI 展示给用户（如聊天界面展示 QR 码图片）
  → 用户确认后 Agent 回调 Pay-Switch

两种方式可以同时使用：浏览器弹窗给用户看完整页面，
同时返回结构化数据（QR 码 URL、金额摘要）给 Agent 展示在聊天里。
```

**确认请求数据结构**：

```json
{
  "type": "human_confirmation_required",
  "action": "scan_qr",
  "summary": "请用支付宝扫码支付 ¥200 给 DeepSeek",
  "details": {
    "merchant": "DeepSeek",
    "amount": 200,
    "currency": "CNY",
    "purpose": "充值 API 额度"
  },
  "qr_code_data": "https://qr.alipay.com/xxx",
  "screenshot_url": "https://...",
  "timeout_seconds": 300,
  "actions": ["confirm_paid", "cancel"]
}
```

**验收标准**：
- [x] 生成的确认请求包含足够的上下文（金额、商户、用途）
- [x] 支持超时机制（5 分钟无响应自动取消）
- [x] 人类确认后 Agent 能正确收到回调继续执行

---

### 3.4 核心功能 D：基础安全守卫

**描述**：简单但必要的安全检查，防止 Agent 失控消费。

**规则（MVP 阶段用简单 if 判断，不需要规则引擎）**：

| 规则 | 默认值 | 说明 |
|------|-------|------|
| 单笔限额 | ¥500 | 超过需人类额外确认 |
| 日累计限额 | ¥2000 | 当日消费达上限后拒绝 |
| 商户白名单 | 可选 | 只允许向白名单商户支付 |
| 幂等去重 | 强制 | 同一 idempotency_key 不重复执行 |

**验收标准**：
- [x] 单笔超限时返回明确拒绝原因
- [x] 日累计超限时正确阻断
- [x] 相同 idempotency_key 的重复请求不会重复触发支付流程

---

### 3.5 核心功能 E：交易记录与审计

**描述**：记录每一次支付编排的完整过程，用于追溯和审计。

**记录内容**：

```json
{
  "transaction_id": "txn_xxx",
  "agent_id": "agent_xxx",
  "timestamp": "2026-05-07T10:30:00Z",
  "amount": 200,
  "currency": "CNY",
  "payee": "DeepSeek",
  "purpose": "充值 API 额度",
  "payment_method": "alipay_qr",
  "steps_executed": [...],
  "human_confirmation": {
    "requested_at": "...",
    "confirmed_at": "...",
    "method": "qr_scan"
  },
  "status": "completed",
  "idempotency_key": "task-abc-step-3"
}
```

**验收标准**：
- [x] 每次 spend() 调用都生成完整的交易记录
- [x] 支持按 agent_id / 时间 / 状态查询历史
- [x] 记录不可篡改（append-only）

---

## 4. 接入方式

### 4.0 设计哲学：一个产品只有一个主入口

Pay-Switch 不是一堆零散的 API 函数，而是一个**完整的支付技能**。Agent 需要理解的不是"有哪些函数可以调"，而是"怎么走完一个花钱的流程"。

**为什么选 CLI 做主入口？**

| 对比维度 | MCP（一堆函数） | CLI（一套框架） |
|---------|---------------|---------------|
| Agent 理解全貌 | 只看到零散的函数名和参数 | `--help` 一次理解整体架构和流程 |
| 流程编排 | Agent 要自己猜先后顺序 | 命令天然有流程感（login → spend → confirm） |
| 人类交互 | 协议里没有"弹浏览器让人操作"的概念 | 天然支持交互式（弹窗口、等输入、打印二维码） |
| 状态管理 | 每次调用无状态 | 可以维护 session/配置文件 |
| 自文档化 | 靠 JSON Schema（Agent 经常看不懂） | `--help`、错误提示都是自然语言 |
| 开发者调试 | 还要写代码 | 直接在终端手动跑 |
| 通用性 | 需要 Agent 支持 MCP 协议 | **任何能跑 shell 命令的 Agent 都能用** |

### 4.1 接入架构

```
┌──────────────────────────────────────────────────────────┐
│                   任何 AI Agent                          │
│  Claude Code / Cursor / OpenClaw / LangChain / 自建      │
│                                                          │
│  Agent 只需要能执行 shell 命令，就能使用 Pay-Switch           │
│  第一步：运行 payswitch --help，理解全部能力                  │
│  第二步：按需调用子命令                                    │
└──────────────────────┬───────────────────────────────────┘
                       │ shell 调用
                       ▼
┌──────────────────────────────────────────────────────────┐
│                  payswitch CLI                              │
│               （产品的唯一入口）                            │
│                                                          │
│  payswitch setup                 首次运行引导                 │
│  payswitch login <platform>     登录目标平台                 │
│  payswitch spend <amount> <payee> [--reason ...]  发起支付  │
│  payswitch confirm <tx_id>      人类确认支付                 │
│  payswitch status <tx_id>       查看支付状态                 │
│  payswitch history              查看消费记录                 │
│  payswitch config               查看/修改配置                │
│  payswitch platforms            列出支持的平台                │
└──────────────────────┬───────────────────────────────────┘
                       │ 内部调用
                       ▼
┌──────────────────────────────────────────────────────────┐
│               Pay-Switch 核心引擎（内部）                     │
│                                                          │
│  REST API（内部通信协议，不是产品功能）                      │
│  ├── POST /v1/spend                                      │
│  ├── POST /v1/confirm                                    │
│  ├── GET  /v1/status/:id                                 │
│  ├── GET  /v1/transactions                               │
│  └── GET/PUT /v1/config                                  │
│                                                          │
│  浏览器引擎 / 策略引擎 / 账本                               │
└──────────────────────────────────────────────────────────┘
```

**REST API 是引擎，CLI 是方向盘。** 就像 Docker 一样——`docker run` 是主入口，Docker Engine API 是内核。用户不需要知道 REST API 的存在。

### 4.2 CLI 命令详细设计

#### `payswitch setup` — 首次运行引导

```bash
$ payswitch setup
🔧 Pay-Switch 首次配置

  步骤 1/3: 下载浏览器引擎...
  ✅ Chromium 已安装

  步骤 2/3: 配置 Skyvern 智能模式
  请选择 LLM 后端：
    [1] OpenAI (GPT-4o)       ← 推荐
    [2] Anthropic (Claude)
    [3] Google (Gemini)
    [4] 本地模型 (Ollama)
  > 1
  请输入 API Key: sk-xxx...
  ✅ Skyvern 已配置

  步骤 3/3: 检测运行环境
  ✅ 检测到 Windows 桌面环境，将使用弹窗模式

🎉 配置完成！运行 payswitch login <platform> 开始使用。
```

#### `payswitch login <platform>` — 登录目标平台

```bash
# 首次登录：弹出浏览器，人类手动登录，Pay-Switch 保存登录状态
$ payswitch login deepseek
🌐 正在打开浏览器，请登录 DeepSeek...
   如果浏览器没有自动打开，请访问: http://localhost:9222
✅ 登录成功！已保存 DeepSeek 的登录状态。

# 查看已登录的平台
$ payswitch login --list
已登录平台：
  deepseek    ✅ 有效（上次登录：2026-05-07）
  kimi        ⚠️ 已过期（需要重新登录）

# 退出登录
$ payswitch login deepseek --logout
```

#### `payswitch spend <amount> <payee>` — 发起支付

```bash
# 基本用法
$ payswitch spend 200 deepseek --reason "充值API额度"
📋 支付计划 [txn_a1b2c3]
   商户: DeepSeek
   金额: ¥200.00
   方式: 支付宝扫码
   步骤: 打开充值页 → 选择套餐 → 选择支付宝 → 人类扫码

🚀 正在执行...
   ✅ 步骤 1/4: 已打开充值页
   ✅ 步骤 2/4: 已选择 ¥200 套餐
   ✅ 步骤 3/4: 已选择支付宝
   ⏸️ 步骤 4/4: 需要人类扫码

🔔 请在弹出的浏览器窗口中用支付宝扫码支付 ¥200
   等待确认中... (超时: 5分钟)

# 人类扫码后
✅ 支付完成！
   交易ID: txn_a1b2c3
   金额: ¥200.00
   商户: DeepSeek

# 更多选项
$ payswitch spend 200 deepseek --dry-run          # 模拟执行，不真正付款
$ payswitch spend 200 deepseek --method bankcard   # 指定支付方式
$ payswitch spend 200 deepseek --budget 500        # 设置本次预算上限
$ payswitch spend 200 deepseek --auto-confirm      # 小额自动确认（需预设阈值）
$ payswitch spend 100 new-site --url "https://new-site.com/billing"  # 未知网站，指定入口 URL
```

#### `payswitch confirm <tx_id>` — 人类确认

```bash
# 当 Agent 在后台运行时，人类通过这个命令确认
$ payswitch confirm txn_a1b2c3
📋 待确认支付：
   商户: DeepSeek | 金额: ¥200.00 | 方式: 支付宝扫码

   [Y] 已完成支付  [N] 取消  [O] 打开浏览器查看
> Y
✅ 已确认。
```

#### `payswitch status <tx_id>` — 查看状态

```bash
$ payswitch status txn_a1b2c3
交易 txn_a1b2c3:
  状态: ✅ 已完成
  商户: DeepSeek
  金额: ¥200.00
  方式: 支付宝扫码
  耗时: 2分34秒
  时间: 2026-05-08 10:30:00
```

#### `payswitch history` — 消费记录

```bash
$ payswitch history
最近 10 笔交易：
  txn_a1b2c3  ✅ ¥200.00  DeepSeek   支付宝  2026-05-08 10:30
  txn_d4e5f6  ✅ ¥100.00  Kimi       银行卡  2026-05-07 15:20
  txn_g7h8i9  ❌ ¥500.00  Qwen       -      2026-05-07 09:00 (超出日限额)

$ payswitch history --json    # JSON 格式输出（给程序用）
$ payswitch history --csv     # CSV 格式导出
```

#### `payswitch config` — 配置管理

```bash
$ payswitch config
当前配置：
  单笔限额:  ¥500.00
  日累计限额: ¥2000.00
  白名单:    deepseek, kimi, qwen
  自动确认阈值: ¥0（关闭）

$ payswitch config --set max-per-transaction 1000
$ payswitch config --set daily-limit 5000
$ payswitch config --add-whitelist openai
```

#### `payswitch platforms` — 支持的平台

```bash
$ payswitch platforms
已支持平台：
  deepseek    DeepSeek API 充值        支付宝/银行卡
  kimi        Kimi (Moonshot) 充值     支付宝/银行卡
  qwen        通义千问充值              支付宝

  共 3 个平台。运行 payswitch login <platform> 开始使用。
```

### 4.3 Agent 实际使用示例

**Claude Code 使用 Pay-Switch**：

```
用户: "帮我充值 DeepSeek ¥200"

Claude Code 的思考过程:
  1. 先了解 Pay-Switch 能做什么
     → 执行: payswitch --help
  2. 检查 DeepSeek 是否已登录
     → 执行: payswitch login --list
     → 发现 DeepSeek 已登录且有效
  3. 发起支付
     → 执行: payswitch spend 200 deepseek --reason "充值API额度"
     → Pay-Switch 自动执行前 3 步，到扫码时暂停
  4. 通知用户
     → "请在弹出的浏览器窗口扫码支付 ¥200"
  5. 等待确认
     → 执行: payswitch status txn_a1b2c3
     → 确认支付完成
  6. 回复用户
     → "充值完成！DeepSeek 余额已更新。"
```

**LangChain Agent 使用 Pay-Switch**：

```python
import subprocess

# Agent 工具：调用 Pay-Switch CLI
def payswitch_spend(amount: int, payee: str, reason: str) -> str:
    """通过 Pay-Switch 支付网关发起支付"""
    result = subprocess.run(
        ["payswitch", "spend", str(amount), payee,
         "--reason", reason, "--json"],
        capture_output=True, text=True
    )
    return result.stdout
```

**任何 Agent 框架**——只要能跑 shell 命令，就能用 Pay-Switch。不需要安装 SDK，不需要写集成代码，不需要理解 REST API。

### 4.4 为什么不用 MCP / SDK / Plugins 做主入口

| 方式 | 问题 | Pay-Switch 的定位 |
|------|------|---------------|
| **MCP Server** | MCP 暴露的是零散函数，Agent 不了解整个花钱流程和规则。支付是有状态、有流程的，MCP 的无状态模型不匹配 | 后续可选：社区有需求再做 |
| **Python/TS SDK** | 需要 Agent 的宿主环境安装特定语言的包。不同框架的集成方式各异，维护负担重 | 后续可选：SDK 封装 CLI，给需要编程集成的开发者 |
| **Plugins** | 平台锁定（ChatGPT Plugins 已废弃），不通用 | 不做 |
| **REST API** | 对用户不友好，需要理解端点、认证、请求体格式 | 内部使用：CLI 的后端引擎，不对外暴露为产品功能 |
| **CLI** | ✅ 通用（任何 Agent 都能跑 shell）、自文档化（--help）、有状态、交互式 | **主入口** |

### 4.5 未来协议兼容性预留

Pay-Switch 的架构设计应对以下新兴协议保持兼容，但 MVP 不实现：

#### MPP（Machine Payments Protocol）— 自动付费的收费站

Stripe + Tempo 于 2026 年 3 月发布的协议。当 Agent 调用付费 API 时，服务器返回 HTTP 402 + 支付要求，Agent 自动完成支付后重试。

```
应用场景：Agent 按次付费调用 DeepSeek API
  Agent → 调 API → 返回 HTTP 402 "请付 ¥0.01"
  → Agent 通过 Pay-Switch 自动支付 → 带凭证重试 → 拿到结果

类比：高速公路 ETC，车到收费站自动扣费通过。
```

**预留方式**：CLI 增加 `payswitch pay-402 <url>` 子命令，处理 HTTP 402 挑战-响应流程。需要 API 提供方也支持 MPP，短期内国内厂商尚未接入。

#### AP2（Agent Payments Protocol）— 签字授权书

Google 主导的协议。核心概念是 **Mandate（授权委托书）**：人类签署一份密码学签名的授权，规定 Agent 的消费范围（限额、商户、用途），Agent 拿着授权书去消费。

```
应用场景：企业给 AI 助手设定消费权限
  CTO 签署 Mandate："允许 Agent 在 DeepSeek/Kimi/Qwen 上消费，
                      单笔≤¥200，总额≤¥1000/月"
  → Agent 拿着这个授权书去消费 → 超过限额自动拒绝 → 全程可审计

类比：公司的财务审批流程。员工不能随便花钱，
      要有领导签字的审批单，上面写了限额和用途范围。
```

**预留方式**：Pay-Switch 的 `payswitch config` 配置机制已经实现了 AP2 的核心思想（限额/白名单/审批）。未来可升级为标准 AP2 Mandate 格式，实现跨系统互认。

---

## 5. 用户流程

### 5.1 开发者接入流程

```
① 安装 Pay-Switch
   pip install payswitch

② 首次配置（下载浏览器 + 配置 Skyvern LLM）
   payswitch setup

③ 登录目标平台（每个平台只需做一次）
   payswitch login deepseek
   → 弹出浏览器（本地）或生成 noVNC 链接（远程）
   → 手动登录 → 登录状态自动保存

④ 配置安全规则（可选）
   payswitch config --set max-per-transaction 500
   payswitch config --set daily-limit 2000

⑤ 在 Agent 中使用（零集成代码）
   Agent 直接执行 shell 命令：payswitch spend 200 deepseek

⑥ 测试
   payswitch spend 200 deepseek --dry-run（模拟执行，不真正付款）
```

### 5.2 最终用户使用流程

```
用户："帮我充值 DeepSeek ¥200"
  │
  ▼
Agent 执行 payswitch spend 200 deepseek --reason "充值API额度"
  │
  ▼
Pay-Switch 安全检查 → 通过 → 加载 DeepSeek Profile → 打开浏览器
  → 脚本模式执行：打开充值页 → 选 ¥200 套餐 → 选支付宝
  │
  ▼
检测到 QR 码 → 暂停自动化
  → 弹出浏览器窗口（本地桌面）让用户看到支付页
  → CLI 输出："🔔 请在弹出的浏览器窗口中用支付宝扫码支付 ¥200"
  │
  ▼
用户在弹出的浏览器窗口看到 QR 码 → 手机扫码 → 支付完成
  │
  ▼
Pay-Switch 检测到支付成功页面 → 记录交易
  → CLI 输出："✅ 支付完成！交易ID: txn_a1b2c3"
  │
  ▼
Agent 读取 CLI 输出 → 回复用户："充值完成！DeepSeek 余额已更新。"
```

### 5.3 异常流程

| 异常 | 处理方式 |
|------|---------|
| 支付超时（5分钟未确认） | 自动取消，CLI 输出超时原因 |
| 金额超限 | 拒绝并返回原因，Agent 可通知用户调整限额 |
| 脚本执行失败（网站改版） | 自动切换 Skyvern 智能模式重试 |
| Skyvern 也失败 | 提示人类通过弹窗/noVNC 手动接管 |
| 人类取消支付 | 标记为 cancelled，CLI 输出取消信息 |
| 登录过期 | 暂停任务，提示用户重新 `payswitch login` |
| 网络中断 | 支持断点续传，通过 tx_id 恢复 |
| LLM 配额不足（Skyvern） | 回退到人类接管模式，不阻塞支付流程 |

---

## 6. 技术要求

### 6.1 技术栈

| 层级 | 技术 | 理由 |
|------|------|------|
| **CLI 框架** | Python + Click/Typer | 成熟的 CLI 框架，支持子命令、帮助文档、交互式输入 |
| **浏览器自动化** | Playwright (Python) | 跨平台、支持 Chromium/Firefox/WebKit、Profile 管理完善 |
| **智能执行引擎** | Skyvern (Python) | LLM 视觉驱动，不依赖选择器，网站改版不影响 |
| **人类远程交互** | noVNC (HTML5) | 远程/Docker 场景下让人类看到并操作浏览器 |
| **数据库** | SQLite | 单文件数据库，零配置，CLI 进程间通过文件共享状态 |
| **容器化** | Docker + Docker Compose | 一键部署，内含 Xvfb + noVNC + Playwright + Skyvern |
| **打包分发** | pip install payswitch | 一条命令安装，自带 CLI 入口点 |

**注意：不需要独立的服务进程（如 FastAPI）。** CLI 直接调用引擎，SQLite 做持久化。就像 `git` 一样——没有 git server 在本地跑，所有命令直接操作文件系统。后续如需 Web Dashboard 再引入 FastAPI。

### 6.2 项目结构（初步）

```
pay-switch/
├── payswitch/                   # Python 包（pip install payswitch）
│   ├── __init__.py
│   ├── cli.py                # CLI 入口（Click/Typer，所有子命令）
│   ├── engine/               # 核心引擎（无独立服务进程，CLI 直接调用）
│   │   ├── orchestrator.py   # 支付流程编排（脚本模式 + 智能模式调度）
│   │   ├── guard.py          # 安全守卫（限额/白名单/去重）
│   │   └── ledger.py         # 交易记录（SQLite）
│   ├── browser/              # 浏览器控制层
│   │   ├── controller.py     # Playwright 控制器（统一接口）
│   │   ├── skyvern.py        # Skyvern 智能执行引擎（LLM 视觉模式）
│   │   ├── profiles.py       # Profile 管理（Playwright persistent context）
│   │   ├── display.py        # 人类交互层（自动检测：本地弹窗 / noVNC）
│   │   ├── novnc.py          # noVNC 会话管理（远程/Docker 场景）
│   │   ├── detector.py       # 支付环节检测（QR/表单/确认/完成）
│   │   └── safety.py         # 浏览器安全层
│   ├── adapters/             # 站点脚本适配器（已知网站的快速路径）
│   │   ├── base.py           # 适配器基类
│   │   ├── deepseek.py       # DeepSeek 充值脚本
│   │   ├── kimi.py           # Kimi 充值脚本
│   │   └── qwen.py           # Qwen 充值脚本
│   └── models/               # 数据模型
├── docker/                    # Docker 部署（一键启动，含 noVNC）
│   ├── Dockerfile            # 包含 Xvfb + x11vnc + noVNC + Playwright
│   └── docker-compose.yml    # 服务编排
├── tests/
├── pyproject.toml             # 包配置 + CLI 入口点
├── PRD.md
└── README.md
```

**两种安装方式**：
```bash
# 方式一：本地安装（Windows/macOS 桌面用户）
pip install payswitch          # 安装
payswitch setup                # 首次运行：下载 Playwright 浏览器 + 配置 Skyvern LLM
payswitch --help               # Agent 从这里开始理解 Pay-Switch

# 方式二：Docker 部署（服务器/远程用户）
docker compose up -d         # 一键启动，内含 noVNC
# 访问 http://localhost:6080 查看浏览器画面
# 在容器内执行 payswitch 命令
```

### 6.3 非功能需求

| 需求 | 标准 |
|------|------|
| CLI 启动速度 | < 2 秒（不含浏览器启动时间）|
| 支付步骤超时 | 单步最长 5 分钟，整体最长 15 分钟 |
| 幂等性 | 同一 idempotency_key 48 小时内不重复 |
| 日志 | 所有操作不可篡改，支持审计追溯（SQLite append-only）|
| 沙箱模式 | `--dry-run` 测试模式，不产生真实支付 |
| 跨平台 | Windows / macOS / Linux（Docker）|
| LLM 配置 | Skyvern 支持多种 LLM 后端（GPT-4o / Claude / Gemini / 本地模型）|

---

## 7. MVP 范围

### 7.1 MVP 包含

**接入层**
- [x] **CLI 工具**（主入口：setup / login / spend / confirm / status / history / config / platforms）
- [x] `--json` 输出模式（给 Agent 程序化解析）
- [x] `--dry-run` 沙箱测试模式
- [x] `--verbose` 调试输出

**浏览器执行层（完整的四层架构）**
- [x] Playwright 浏览器控制（脚本模式，已知网站快速路径）
- [x] **Skyvern 智能模式**（LLM 视觉执行，未知网站 + 脚本失败自动回退）
- [x] **双模式回退链**：脚本 → Skyvern → 人类接管
- [x] 浏览器 Profile 管理（Playwright persistent context）
- [x] 支付环节检测（QR 码/敏感表单/确认按钮/支付完成）
- [x] 浏览器安全层（敏感页暂停/域名白名单/Agent 不碰密码框）

**人类交互层（完整覆盖本地和远程）**
- [x] 本地桌面弹窗（Windows/macOS，Playwright headed 模式）
- [x] **noVNC 远程交互**（服务器/Docker 场景，生成 Web 链接）
- [x] **自动环境检测**：有桌面 → 弹窗 | 无桌面 → noVNC

**支付能力**
- [x] 站点脚本适配器（DeepSeek / Kimi / Qwen）
- [x] 基础限额检查（单笔 + 日累计）
- [x] 商户白名单
- [x] 幂等去重
- [x] 交易记录（SQLite，append-only）

**部署**
- [x] pip install payswitch（本地桌面用户）
- [x] **Docker Compose 一键部署**（内含 Xvfb + noVNC + Playwright）
- [x] `payswitch setup` 首次引导（下载浏览器 + 配置 LLM）

### 7.2 MVP 不包含（后续迭代）

**接入方式扩展**
- [ ] MCP Server（社区有需求再做，封装 CLI 能力）
- [ ] Python SDK（封装 CLI 调用，给需要编程集成的开发者）
- [ ] TypeScript SDK
- [ ] REST API（引入 FastAPI，给 Web Dashboard 和 SDK 做后端）

**协议兼容**
- [ ] MPP 兼容（HTTP 402 自动付费协议）
- [ ] AP2 Mandate 标准格式（跨系统授权互认）

**浏览器增强**
- [ ] AdsPower 指纹浏览器集成（Profile 隔离 + 反检测）
- [ ] 云端远程浏览器（Anchor / Bright Data / Hyperbrowser）

**支付通道扩展**
- [ ] Stripe 适配器（国际信用卡）
- [ ] 更多站点适配器

**产品功能**
- [ ] Web 控制台 / Dashboard（可嵌入 noVNC iframe）
- [ ] 多用户 / 多 Agent 管理
- [ ] 高级策略引擎（YAML/OPA）
- [ ] 与 ClawHunt 集成
- [ ] Webhook 通知
- [ ] 实时余额监控

### 7.3 MVP 验证场景

**场景一：本地桌面 + 脚本模式（最基础）**

```
环境：Windows/macOS 桌面
前置：pip install payswitch && payswitch setup && payswitch login deepseek

  1. Agent 执行 payswitch spend 200 deepseek --reason "充值API额度"
  2. Pay-Switch 用脚本模式执行（已知网站快速路径）
  3. 到达扫码步骤 → 弹出浏览器窗口 + CLI 暂停提示
  4. 用户在弹出窗口扫码 → Pay-Switch 检测完成 → CLI 输出成功

验证点：脚本模式 + 本地弹窗 + 支付检测
```

**场景二：本地桌面 + 智能模式（Skyvern 回退）**

```
环境：Windows/macOS 桌面
模拟：DeepSeek 网站改版，脚本执行失败

  1. Agent 执行 payswitch spend 200 deepseek --reason "充值API额度"
  2. Pay-Switch 先尝试脚本模式 → 执行失败（选择器找不到）
  3. 自动切换 Skyvern 智能模式 → AI 看截图理解新版页面 → 继续执行
  4. 到达扫码步骤 → 弹窗 → 用户扫码 → 完成

验证点：双模式回退链 + Skyvern 视觉理解 + 网站改版容错
```

**场景三：Docker 部署 + noVNC（远程场景）**

```
环境：Linux 服务器，无桌面，Docker 部署
用户通过 SSH 操作

  1. docker compose up -d（一键启动 Pay-Switch）
  2. 在容器内执行 payswitch login deepseek
     → CLI 输出："🌐 请在浏览器打开 http://your-server:6080/vnc.html 进行登录"
  3. 用户在手机/电脑浏览器打开 noVNC 链接 → 看到 Chrome → 手动登录 DeepSeek
  4. Agent 执行 payswitch spend 200 deepseek
  5. 到达扫码步骤 → CLI 输出 noVNC 链接
  6. 用户在 noVNC 页面看到 QR 码 → 手机扫码 → 完成

验证点：Docker 部署 + noVNC 远程交互 + 环境自动检测
```

**场景四：未知网站（纯 Skyvern 智能模式）**

```
环境：任意
目标：一个没有预写脚本适配器的新网站

  1. 用户先登录：payswitch login some-new-platform
  2. Agent 执行 payswitch spend 100 some-new-platform --reason "购买服务" --url "https://new-platform.com/billing"
  3. Pay-Switch 发现没有脚本适配器 → 直接用 Skyvern 智能模式
  4. Skyvern 看截图理解页面 → 自动导航到支付页 → 暂停让人确认

验证点：Skyvern 处理未知网站 + --url 参数指定入口
```

---

## 8. 开放问题

- [x] ~~支付步骤的知识库怎么维护？~~ → **双模式解决：已知网站用脚本（快速路径），未知/变更网站用 Skyvern 智能模式（LLM 视觉理解，不依赖选择器）**
- [x] ~~Agent 操作浏览器的能力是 Pay-Switch 提供还是 Agent 框架自带？~~ → **Pay-Switch 内置 Playwright，自己管浏览器**
- [x] ~~反爬对抗：目标网站的验证码（CAPTCHA）、反自动化检测怎么处理？~~ → **MVP 用 Playwright stealth 插件 + Skyvern 视觉识别；后续可集成 AdsPower 指纹浏览器做深度反检测**
- [x] ~~是否支持"第三方浏览器"模式？~~ → **是。架构设计为可插拔：内置 Playwright（MVP）→ AdsPower（反检测）→ Browserbase/Steel/Bug0（云端）**
- [x] ~~人类怎么远程操作 Agent 的浏览器？~~ → **通过 noVNC，生成 Web 链接，任何设备浏览器打开即可看到和操作**
- [ ] 多语言/多币种的优先级？先做 CNY 还是同时支持 USD？
- [ ] 是否需要提供 Agent 测试用例库？（预录制的支付流程回放，给开发者做集成测试）
- [ ] 商业模式：开源免费？按交易收费？SaaS 订阅？
- [ ] Profile 安全：浏览器 Profile 包含登录态，加密存储方案待定（AdsPower 有内置加密云同步）
- [ ] noVNC 安全：会话认证机制待定（密码/Token/OAuth？）

---

## 参考资料

- `reference/Agent Pay Switch.md` — 产品原始规划
- `reference/ClawHunt 扩张方案.md` — 生态背景
- `reference/生态规划书.md` — 三层架构定位
- `reference/search/` — 市场调研与技术搜索结果（14 份文档）
  - `10-noVNC远程浏览器方案.md` — noVNC + Docker + HITL 方案详解
  - `11-AdsPower指纹浏览器方案.md` — AdsPower 指纹隔离 + Playwright 集成
  - `12-浏览器方案全景对比.md` — AI Agent 浏览器方案全景对比
  - `13-Skyvern智能浏览器引擎.md` — Skyvern LLM 视觉执行引擎详解
  - `14-Agent接入模式与协议全景.md` — MCP/REST/CLI/SDK 对比 + MPP/AP2/ACP 新兴协议分析
- `reference/agentwallet/` — JackD720/agentwallet 参考项目
- `reference/haldir/` — ExposureGuard/haldir 参考项目
- `reference/OpenAgentPay/` — alokemajumder/OpenAgentPay 参考项目

### 浏览器方案关键外部参考

**智能执行引擎**
- **Skyvern**: https://github.com/Skyvern-AI/skyvern — LLM 视觉驱动浏览器自动化（21.5k ★，AGPL-3.0）
- **Skyvern 文档**: https://www.skyvern.com/developers — Python SDK / REST API

**人类交互层**
- **noVNC**: https://github.com/novnc/noVNC — 纯 HTML5 VNC 客户端（远程场景）
- **auto-browser**: https://github.com/LvcidPsyche/auto-browser — MCP 原生 HITL 浏览器 Agent

**Profile 隔离/反检测**
- **AdsPower**: https://www.adspower.com/ — 指纹浏览器，免费 2 Profile
- **AdsPower Local API**: https://localapi-doc-en.adspower.com/docs/K4IsTq — 编程控制文档

**支付协议（架构预留）**
- **MPP (Machine Payments Protocol)**: https://stripe.com/blog/machine-payments-protocol — HTTP 402 自动付费协议（Stripe + Tempo）
- **AP2 (Agent Payments Protocol)**: https://ap2-protocol.org/ — 密码学签名的 Agent 授权委托协议（Google）
- **ACP (Agentic Commerce Protocol)**: https://developers.openai.com/commerce — Agent 电商协议（OpenAI + Stripe）
- **Visa MCP Server**: https://corporate.visa.com/en/sites/visa-perspectives/innovation/visa-mcp-server-agent-acceptance-toolkit.html
- **Stripe Agent Toolkit**: https://docs.stripe.com/agents — Stripe 官方 Agent 集成

**云端浏览器**
- **Anchor Browser**: https://anchorbrowser.io/ — headful 云端 Chrome，CAPTCHA 自动解决
- **Bright Data Agent Browser**: https://brightdata.com/ai/agent-browser — 企业级代理+反封锁
- **Hyperbrowser**: https://www.hyperbrowser.ai/ — 按需云浏览器 API
