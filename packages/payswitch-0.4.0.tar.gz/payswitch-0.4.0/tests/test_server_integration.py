"""payswitch 云端服务集成测试。

测试 FastAPI 端点的基本功能。
标记 @pytest.mark.docker 的测试需要 Docker + Redis 环境。
"""

from __future__ import annotations

import pytest
from httpx import ASGITransport, AsyncClient

from server.app import app
from server.models import TaskStatus

# ─── 不需要 Docker/Redis 的基础测试 ─────────────────────────


@pytest.fixture
async def client():
    """httpx 异步客户端（不触发 lifespan）。"""
    async with AsyncClient(
        transport=ASGITransport(app=app, raise_app_exceptions=False),
        base_url="http://test",
    ) as c:
        yield c


class TestHealthCheck:
    """健康检查端点测试。"""

    async def test_health_returns_ok(self, client: AsyncClient) -> None:
        r = await client.get("/health")
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "ok"
        assert "version" in data

    async def test_health_includes_component_status(self, client: AsyncClient) -> None:
        r = await client.get("/health")
        data = r.json()
        # 没有 lifespan 时 redis/docker 应为 disconnected/unavailable
        assert "redis" in data
        assert "docker" in data


class TestTaskEndpoints:
    """任务端点测试（无 lifespan 时返回 503）。"""

    async def test_submit_task_without_lifespan(self, client: AsyncClient) -> None:
        """lifespan 未就绪时应返回 503。"""
        r = await client.post("/task", json={
            "card_alias": "test",
            "url": "https://example.com",
            "max_amount": 10.0,
        })
        assert r.status_code == 503

    async def test_get_task_status_without_lifespan(self, client: AsyncClient) -> None:
        r = await client.get("/task/test-123")
        assert r.status_code == 503

    async def test_cancel_task_without_lifespan(self, client: AsyncClient) -> None:
        r = await client.post("/task/test-123/cancel")
        assert r.status_code == 503


class TestSandboxEndpoint:
    """沙箱管理端点测试。"""

    async def test_sandbox_status_without_docker(self, client: AsyncClient) -> None:
        """Docker 不可用时应返回降级信息。"""
        r = await client.get("/sandbox/status")
        assert r.status_code == 200
        data = r.json()
        assert data["available"] is False
        assert data["count"] == 0


class TestSSEEndpoint:
    """SSE 事件流端点测试。"""

    async def test_sse_without_redis(self, client: AsyncClient) -> None:
        """Redis 未连接时返回错误事件。"""
        r = await client.get("/task/test-123/events")
        assert r.status_code == 200
        assert "text/event-stream" in r.headers["content-type"]


class TestA2AEndpoint:
    """A2A 端点基本测试。"""

    async def test_a2a_requires_valid_payload(self, client: AsyncClient) -> None:
        """POST /a2a 缺少 body 应返回 422。"""
        r = await client.post("/a2a")
        assert r.status_code == 422

    async def test_a2a_with_payload_without_lifespan(self, client: AsyncClient) -> None:
        """POST /a2a 有合法 payload 但 lifespan 未就绪时返回 503。"""
        r = await client.post("/a2a", json={
            "task": {
                "id": "test",
                "message": {"role": "user", "parts": [{"type": "text", "text": "test"}]},
                "metadata": {"card_alias": "test", "max_amount": 10.0},
            }
        })
        assert r.status_code == 503


# ─── 模型测试 ────────────────────────────────────────────────


class TestModels:
    """API 模型验证。"""

    def test_task_status_values(self) -> None:
        assert TaskStatus.SUBMITTED.value == "submitted"
        assert TaskStatus.WORKING.value == "working"
        assert TaskStatus.COMPLETED.value == "completed"
        assert TaskStatus.FAILED.value == "failed"
        assert TaskStatus.CANCELED.value == "canceled"
        assert TaskStatus.INPUT_REQUIRED.value == "input_required"
        assert TaskStatus.AUTH_REQUIRED.value == "auth_required"

    def test_task_request_validation(self) -> None:
        from server.models import TaskRequest

        req = TaskRequest(
            card_alias="my-visa",
            url="https://example.com",
            max_amount=50.0,
        )
        assert req.card_alias == "my-visa"
        assert req.currency == "USD"
        assert req.require_human_confirmation is True
        assert req.task_id is None

    def test_generate_task_id(self) -> None:
        from server.models import generate_task_id

        tid = generate_task_id()
        assert tid.startswith("task-")
        assert len(tid) == 17  # "task-" + 12 hex chars


# ─── Redis + IdempotencyManager 单元测试（无需真实 Redis）────

class TestIdempotencyManager:
    """幂等性管理器测试（不连接 Redis）。"""

    async def test_degraded_mode_allows_execution(self) -> None:
        """Redis 不可用时应放行（降级模式）。"""
        from server.idempotency import IdempotencyManager, IdempotencyStatus

        mgr = IdempotencyManager()
        # 不调用 connect()，模拟 Redis 不可用
        result = await mgr.check_and_lock("test-task")
        assert result.status == IdempotencyStatus.LOCKED

    async def test_store_and_release_noop_without_redis(self) -> None:
        """Redis 不可用时 store/release 不报错。"""
        from server.idempotency import IdempotencyManager

        mgr = IdempotencyManager()
        await mgr.store_result("test", "completed", {"ok": True})
        await mgr.release_lock("test")


class TestRedisBridge:
    """Redis 通信桥测试（不连接 Redis）。"""

    async def test_publish_without_connection(self) -> None:
        """未连接时 publish 不报错。"""
        from server.redis_bridge import RedisBridge

        bridge = RedisBridge()
        await bridge.publish_event("test", {"type": "test"})

    async def test_subscribe_without_connection(self) -> None:
        """未连接时 subscribe 立即返回。"""
        from server.redis_bridge import RedisBridge

        bridge = RedisBridge()
        events = []
        async for event in bridge.subscribe_events("test"):
            events.append(event)
        assert events == []


class TestDockerPool:
    """Docker 容器池测试（不连接 Docker）。"""

    def test_pool_without_docker(self) -> None:
        from server.config import ServerConfig
        from server.docker_pool import DockerPool

        pool = DockerPool(ServerConfig())
        assert pool.available is False
        assert pool.active_count == 0

    async def test_create_sandbox_without_docker(self) -> None:
        from server.config import ServerConfig
        from server.docker_pool import DockerPool

        pool = DockerPool(ServerConfig())
        with pytest.raises(RuntimeError, match="Docker daemon 不可用"):
            await pool.create_sandbox("test-task")
