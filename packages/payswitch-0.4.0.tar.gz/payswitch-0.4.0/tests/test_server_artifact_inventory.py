from __future__ import annotations

from fastapi.testclient import TestClient

from payswitch.models.config import PaySwitchConfig
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore
from payswitch.server import app


def test_artifact_inventory_health_reports_budget_signal(
    monkeypatch,
    tmp_path,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    ArtifactStore(config.data_dir).write_bytes(
        tmp_path / "evidence" / "external" / "shot.png",
        b"\x89PNG\r\nfake",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
    )
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_STORAGE_BUDGET_MB", "0.00001")

    with TestClient(app) as client:
        inventory = client.get("/api/artifact-inventory/health")
        health = client.get("/api/health")

        assert inventory.status_code == 200
        payload = inventory.json()
        assert payload["artifacts"] == 1
        assert payload["encrypted_artifacts"] == 1
        assert payload["over_budget"] is True

        assert health.status_code == 200
        health_payload = health.json()
        assert health_payload["artifact_inventory"]["artifacts"] == 1
        assert health_payload["artifact_inventory"]["over_budget"] is True
