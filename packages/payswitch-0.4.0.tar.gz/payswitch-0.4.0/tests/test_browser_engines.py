"""Browser engines 测试：get_engine 工厂 + PlaywrightEngine / CloakBrowserEngine 轻量单测。"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from payswitch.browser.engines import (
    SUPPORTED_ENGINES,
    BrowserEngine,
    get_engine,
)
from payswitch.browser.engines.cloakbrowser_engine import (
    _MISSING_DEP_MSG,
    CloakBrowserEngine,
    _stable_profile_fingerprint_arg,
)
from payswitch.browser.engines.playwright_engine import PlaywrightEngine

# ---------------------------------------------------------------------------
# 工厂函数
# ---------------------------------------------------------------------------


def test_get_engine_playwright_returns_playwright_engine() -> None:
    engine = get_engine("playwright")
    assert isinstance(engine, PlaywrightEngine)
    assert engine.name == "playwright"


def test_get_engine_cloakbrowser_returns_cloakbrowser_engine() -> None:
    engine = get_engine("cloakbrowser")
    assert isinstance(engine, CloakBrowserEngine)
    assert engine.name == "cloakbrowser"


def test_get_engine_invalid_raises_value_error() -> None:
    with pytest.raises(ValueError, match="不支持的 browser engine"):
        get_engine("firefox")


def test_supported_engines_contains_both() -> None:
    assert "playwright" in SUPPORTED_ENGINES
    assert "cloakbrowser" in SUPPORTED_ENGINES


def test_both_engines_satisfy_protocol() -> None:
    """PlaywrightEngine / CloakBrowserEngine 必须具备 BrowserEngine 协议方法。"""
    for engine in (PlaywrightEngine(), CloakBrowserEngine()):
        assert hasattr(engine, "launch_stateless")
        assert hasattr(engine, "launch_persistent")
        assert hasattr(engine, "name")
        # Protocol 检查（结构型）
        assert isinstance(engine, BrowserEngine)


# ---------------------------------------------------------------------------
# CloakBrowserEngine 依赖缺失的友好报错
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cloakbrowser_launch_stateless_without_dep_raises_friendly() -> None:
    """未装 cloakbrowser 时 launch_stateless 应抑报友好提示。"""
    engine = CloakBrowserEngine()

    # 强制让 import cloakbrowser 失败
    with patch.dict(sys.modules, {"cloakbrowser": None}):
        with pytest.raises(ImportError) as exc_info:
            await engine.launch_stateless(
                playwright=MagicMock(),
                headless=True,
                args=[],
                user_agent="UA",
                viewport={"width": 1280, "height": 800},
            )

    err_msg = str(exc_info.value)
    assert "pip install" in err_msg
    assert "payswitch[cloak]" in err_msg
    # 非空友好提示
    assert "CloakBrowser 未安装" in err_msg


@pytest.mark.asyncio
async def test_cloakbrowser_launch_persistent_without_dep_raises_friendly(
    tmp_path,
) -> None:
    engine = CloakBrowserEngine()
    with patch.dict(sys.modules, {"cloakbrowser": None}):
        with pytest.raises(ImportError, match="pip install"):
            await engine.launch_persistent(
                playwright=MagicMock(),
                user_data_dir=tmp_path / "profile",
                headless=True,
                args=[],
                user_agent="UA",
                viewport={"width": 1280, "height": 800},
            )


def test_missing_dep_msg_is_actionable() -> None:
    """友好提示必须包含安装指令。"""
    assert "pip install" in _MISSING_DEP_MSG
    assert "payswitch[cloak]" in _MISSING_DEP_MSG


# ---------------------------------------------------------------------------
# CloakBrowserEngine 在 cloakbrowser 被 mock 安装时的行为
# ---------------------------------------------------------------------------


def _make_fake_cloakbrowser_module():
    """Mock cloakbrowser module，捕获 launch_context_async 等调用。"""
    mod = MagicMock()
    fake_browser = MagicMock()
    # launch_context_async 返回的 context，其 .browser 属性指向 fake_browser
    fake_context = MagicMock(name="context")
    fake_context.browser = fake_browser
    mod.launch_context_async = AsyncMock(return_value=fake_context)
    mod.launch_persistent_context_async = AsyncMock(
        return_value=MagicMock(name="persistent_context")
    )
    return mod, fake_browser


@pytest.mark.asyncio
async def test_cloakbrowser_launch_stateless_passes_humanize_flags() -> None:
    fake_mod, fake_browser = _make_fake_cloakbrowser_module()
    engine = CloakBrowserEngine()

    with patch.dict(sys.modules, {"cloakbrowser": fake_mod}):
        browser, context = await engine.launch_stateless(
            playwright=MagicMock(),
            headless=False,
            args=["--fake-arg"],
            user_agent="TestUA",
            viewport={"width": 1920, "height": 1080},
            humanize=True,
            human_preset="careful",
            proxy="http://proxy:8080",
        )

    assert browser is fake_browser
    # 现在走 launch_context_async（humanize 在 context 层正确生效）
    fake_mod.launch_context_async.assert_awaited_once()
    call_kwargs = fake_mod.launch_context_async.await_args.kwargs
    assert call_kwargs["headless"] is False
    assert call_kwargs["humanize"] is True
    assert call_kwargs["human_preset"] == "careful"
    assert call_kwargs["proxy"] == "http://proxy:8080"
    assert call_kwargs["user_agent"] == "TestUA"
    assert call_kwargs["viewport"] == {"width": 1920, "height": 1080}
    # 走代理时自动打开 geoip
    assert call_kwargs["geoip"] is True


@pytest.mark.asyncio
async def test_cloakbrowser_launch_persistent_passes_kwargs(tmp_path) -> None:
    fake_mod, _ = _make_fake_cloakbrowser_module()
    engine = CloakBrowserEngine()

    with patch.dict(sys.modules, {"cloakbrowser": fake_mod}):
        context = await engine.launch_persistent(
            playwright=MagicMock(),
            user_data_dir=tmp_path / "profile",
            headless=True,
            args=[],
            user_agent="UA2",
            viewport={"width": 1280, "height": 800},
            humanize=False,
        )

    assert context is not None
    fake_mod.launch_persistent_context_async.assert_awaited_once()
    call_args = fake_mod.launch_persistent_context_async.await_args
    assert call_args.args[0] == str(tmp_path / "profile")
    call_kwargs = call_args.kwargs
    assert call_kwargs["headless"] is True
    assert call_kwargs["humanize"] is False
    assert call_kwargs["user_agent"] == "UA2"
    assert call_kwargs["args"] == [
        _stable_profile_fingerprint_arg(tmp_path / "profile")
    ]
    # 无 proxy 时不应自动打开 geoip
    assert "geoip" not in call_kwargs or call_kwargs["geoip"] is False


@pytest.mark.asyncio
async def test_cloakbrowser_launch_persistent_preserves_explicit_fingerprint(
    tmp_path,
) -> None:
    fake_mod, _ = _make_fake_cloakbrowser_module()
    engine = CloakBrowserEngine()

    with patch.dict(sys.modules, {"cloakbrowser": fake_mod}):
        await engine.launch_persistent(
            playwright=MagicMock(),
            user_data_dir=tmp_path / "profile",
            headless=True,
            args=["--fingerprint=12345", "--fake-arg"],
            user_agent="UA2",
            viewport={"width": 1280, "height": 800},
            humanize=False,
        )

    call_kwargs = fake_mod.launch_persistent_context_async.await_args.kwargs
    assert call_kwargs["args"] == ["--fingerprint=12345", "--fake-arg"]


def test_stable_profile_fingerprint_is_stable_per_profile(tmp_path) -> None:
    profile_a = tmp_path / "a"
    profile_b = tmp_path / "b"

    assert _stable_profile_fingerprint_arg(profile_a) == (
        _stable_profile_fingerprint_arg(profile_a)
    )
    assert _stable_profile_fingerprint_arg(profile_a) != (
        _stable_profile_fingerprint_arg(profile_b)
    )
    seed = int(_stable_profile_fingerprint_arg(profile_a).split("=", 1)[1])
    assert 10_000 <= seed <= 99_999


# ---------------------------------------------------------------------------
# PlaywrightEngine 基本行为
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_playwright_engine_launch_stateless_uses_chromium() -> None:
    engine = PlaywrightEngine()
    fake_browser = MagicMock()
    fake_context = MagicMock(name="context")
    fake_browser.new_context = AsyncMock(return_value=fake_context)

    fake_playwright = MagicMock()
    fake_playwright.chromium = MagicMock()
    fake_playwright.chromium.launch = AsyncMock(return_value=fake_browser)

    browser, context = await engine.launch_stateless(
        playwright=fake_playwright,
        headless=True,
        args=["--disable-blink-features=AutomationControlled"],
        user_agent="PW-UA",
        viewport={"width": 1280, "height": 800},
        record_video_dir=Path("/tmp/payswitch-recordings"),
    )

    assert browser is fake_browser
    assert context is fake_context
    fake_playwright.chromium.launch.assert_awaited_once()
    kwargs = fake_playwright.chromium.launch.await_args.kwargs
    assert kwargs["headless"] is True
    assert "--enable-automation" in kwargs["ignore_default_args"]
    context_kwargs = fake_browser.new_context.await_args.kwargs
    assert context_kwargs["record_video_dir"] == "/tmp/payswitch-recordings"
    assert context_kwargs["record_video_size"] == {"width": 1280, "height": 800}


@pytest.mark.asyncio
async def test_playwright_engine_launch_persistent_uses_launch_persistent_context(
    tmp_path,
) -> None:
    engine = PlaywrightEngine()
    fake_context = MagicMock(name="persistent")

    fake_playwright = MagicMock()
    fake_playwright.chromium = MagicMock()
    fake_playwright.chromium.launch_persistent_context = AsyncMock(
        return_value=fake_context
    )

    profile = tmp_path / "profile"
    profile.mkdir()

    context = await engine.launch_persistent(
        playwright=fake_playwright,
        user_data_dir=profile,
        headless=True,
        args=[],
        user_agent="UA",
        viewport={"width": 1280, "height": 800},
        record_video_dir=tmp_path / "recordings",
    )

    assert context is fake_context
    fake_playwright.chromium.launch_persistent_context.assert_awaited_once()
    call = fake_playwright.chromium.launch_persistent_context.await_args
    assert call.args[0] == str(profile)
    # humanize / human_preset 在 Playwright engine 上不会被透传（应被忽略）
    assert "humanize" not in call.kwargs
    assert "human_preset" not in call.kwargs
    assert call.kwargs["record_video_dir"] == str(tmp_path / "recordings")
    assert call.kwargs["record_video_size"] == {"width": 1280, "height": 800}
