from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from payswitch.cli import app
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore


def test_artifact_cleanup_cli_once_dry_run_and_delete(
    tmp_path: Path,
    monkeypatch,
) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "external" / "tx-1.json"
    store.write_json(
        artifact_path,
        {"tx_id": "txn_cli_cleanup_1"},
        artifact_kind="external_debug",
        sensitivity=ArtifactSensitivity.internal,
        retention_hours=0,
    )
    monkeypatch.setattr("payswitch.cli._artifact_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["--json", "artifact", "cleanup", "--once", "--dry-run"],
    )
    assert result.exit_code == 0
    preview = json.loads(result.stdout)
    assert preview["cleaned"] == 1
    assert preview["deleted"] == 1
    assert preview["items"][0]["action"] == "would_delete"
    assert artifact_path.exists()

    result = runner.invoke(
        app,
        ["--json", "artifact", "cleanup", "--once"],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["cleaned"] == 1
    assert payload["deleted"] == 1
    assert payload["items"][0]["action"] == "deleted"
    assert not artifact_path.exists()
    assert not store.metadata_path(artifact_path).exists()
