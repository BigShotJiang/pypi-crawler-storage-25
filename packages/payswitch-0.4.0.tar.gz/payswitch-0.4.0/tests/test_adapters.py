"""Pay-Switch 适配器（AdapterRegistry + 各平台适配器）单元测试。

覆盖范围：
- AdapterRegistry.register：注册装饰器正常工作 / 重名覆盖警告
- AdapterRegistry.get：返回正确适配器实例 / 未注册时返回 None
- AdapterRegistry.has：已注册返回 True / 未注册返回 False
- AdapterRegistry.list_platforms：列出所有已注册平台的基本信息
- DeepSeekAdapter / KimiAdapter / QwenAdapter：
    - 已在 registry 中注册且可正常获取实例
    - name / display_name / top_up_url / login_url / supported_methods 属性正确
    - validate_amount 的合法/非法金额校验
- SiteAdapter ABC：
    - 未实现抽象方法时不能实例化
- ScriptStep 数据模型：
    - 基本创建与字段验证
"""

from __future__ import annotations

import warnings
from unittest.mock import AsyncMock, MagicMock

import pytest

from payswitch.adapters import (
    AdapterRegistry,
    ScriptExecutionError,
    ScriptStep,
    SiteAdapter,
)
from payswitch.adapters.deepseek import DeepSeekAdapter
from payswitch.adapters.jimeng import JimengAdapter
from payswitch.adapters.kimi import KimiAdapter
from payswitch.adapters.nineemail import NineEmailAdapter
from payswitch.adapters.qwen import QwenAdapter
from payswitch.adapters.volcano import VolcanoAdapter
from payswitch.experience import ExperienceStore, RecipeRunContext, get_recipe
from payswitch.models.types import PaymentMethod

# ===========================================================================
# AdapterRegistry 测试
# ===========================================================================


def _build_wait_selector_page(
    *,
    visible_text: str,
    selector_element_map: dict[str, MagicMock],
    url: str = "https://example.com/checkout",
) -> MagicMock:
    page = MagicMock()
    page.url = url
    page.evaluate = AsyncMock(return_value=visible_text)

    async def wait_for_selector(selector: str, timeout: int | None = None):
        del timeout
        element = selector_element_map.get(selector)
        if element is None:
            raise RuntimeError(f"selector not found: {selector}")
        return element

    page.wait_for_selector = AsyncMock(side_effect=wait_for_selector)
    return page


def _mock_clickable_element(*, needs_enabled_state: bool = False) -> MagicMock:
    element = MagicMock()
    element.click = AsyncMock()
    if needs_enabled_state:
        element.wait_for_element_state = AsyncMock()
    return element


class TestAdapterRegistry:
    """AdapterRegistry 注册表测试。"""

    def test_get_deepseek返回DeepSeekAdapter实例(self):
        """AdapterRegistry.get('deepseek') 应返回 DeepSeekAdapter 实例。"""
        adapter = AdapterRegistry.get("deepseek")
        assert adapter is not None
        assert isinstance(adapter, DeepSeekAdapter)

    def test_get_kimi返回KimiAdapter实例(self):
        """AdapterRegistry.get('kimi') 应返回 KimiAdapter 实例。"""
        adapter = AdapterRegistry.get("kimi")
        assert adapter is not None
        assert isinstance(adapter, KimiAdapter)

    def test_get_qwen返回QwenAdapter实例(self):
        """AdapterRegistry.get('qwen') 应返回 QwenAdapter 实例。"""
        adapter = AdapterRegistry.get("qwen")
        assert adapter is not None
        assert isinstance(adapter, QwenAdapter)

    def test_get_jimeng_returns_adapter_instance(self):
        adapter = AdapterRegistry.get("jimeng")
        assert adapter is not None
        assert isinstance(adapter, JimengAdapter)

    def test_get_volcano_returns_adapter_instance(self):
        adapter = AdapterRegistry.get("volcano")
        assert adapter is not None
        assert isinstance(adapter, VolcanoAdapter)

    def test_get_不存在的平台返回None(self):
        """查询未注册平台时，get 应返回 None。"""
        result = AdapterRegistry.get("nonexistent_platform")
        assert result is None

    def test_get_空字符串返回None(self):
        """查询空字符串时，get 应返回 None。"""
        result = AdapterRegistry.get("")
        assert result is None

    def test_has_已注册平台返回True(self):
        """has('deepseek') 对已注册平台应返回 True。"""
        assert AdapterRegistry.has("deepseek") is True
        assert AdapterRegistry.has("kimi") is True
        assert AdapterRegistry.has("qwen") is True
        assert AdapterRegistry.has("jimeng") is True
        assert AdapterRegistry.has("volcano") is True

    def test_has_未注册平台返回False(self):
        """has 对未注册平台应返回 False。"""
        assert AdapterRegistry.has("ghost_platform") is False

    def test_list_platforms包含3个平台(self):
        """list_platforms 应至少包含 3 个已注册平台（deepseek / kimi / qwen）。"""
        platforms = AdapterRegistry.list_platforms()
        names = [p["name"] for p in platforms]
        assert "deepseek" in names
        assert "kimi" in names
        assert "qwen" in names
        assert "jimeng" in names
        assert "volcano" in names

    def test_list_platforms每项包含必要字段(self):
        """list_platforms 每项应包含基本平台元数据和支持的支付方式。"""
        platforms = AdapterRegistry.list_platforms()
        for platform in platforms:
            assert "name" in platform
            assert "display_name" in platform
            assert "top_up_url" in platform
            assert "login_url" in platform
            assert "supported_methods" in platform
            # supported_methods 是字符串列表（StrEnum 序列化为值）
            assert isinstance(platform["supported_methods"], list)

    def test_register_重名时发出警告(self):
        """重复注册同名平台时，应发出 UserWarning 警告。"""
        # 创建一个临时的重复适配器类用于测试，不污染全局注册表
        original_adapters = dict(AdapterRegistry._adapters)
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")

                @AdapterRegistry.register
                class _TempAdapter(SiteAdapter):
                    name = "deepseek"  # 与已注册的 DeepSeekAdapter 重名
                    display_name = "Temp"
                    top_up_url = "https://temp.example.com"
                    login_url = "https://temp.example.com/login"
                    supported_methods = [PaymentMethod.alipay_qr]

                    async def execute_topup(self, page, amount, method=None):
                        return []

            # 应有警告被触发
            assert len(caught) >= 1
            assert any(issubclass(w.category, UserWarning) for w in caught)
        finally:
            # 恢复注册表，避免污染其他测试
            AdapterRegistry._adapters = original_adapters

    def test_register_返回原适配器类(self):
        """register 装饰器应原样返回适配器类（保持装饰器语义）。"""
        original_adapters = dict(AdapterRegistry._adapters)
        try:
            class _NewAdapter(SiteAdapter):
                name = "test_register_return"
                display_name = "Test"
                top_up_url = "https://test.example.com"
                login_url = "https://test.example.com/login"
                supported_methods = [PaymentMethod.alipay_qr]

                async def execute_topup(self, page, amount, method=None):
                    return []

            result = AdapterRegistry.register(_NewAdapter)
            assert result is _NewAdapter
        finally:
            AdapterRegistry._adapters = original_adapters

    def test_get_每次返回新实例(self):
        """get 每次调用应返回新实例，不共享状态。"""
        adapter1 = AdapterRegistry.get("deepseek")
        adapter2 = AdapterRegistry.get("deepseek")
        assert adapter1 is not adapter2


# ===========================================================================
# DeepSeekAdapter 测试
# ===========================================================================


class TestDeepSeekAdapter:
    """DeepSeekAdapter 属性和方法测试。"""

    def test_name属性(self):
        """name 属性应为 'deepseek'。"""
        assert DeepSeekAdapter.name == "deepseek"

    def test_display_name属性(self):
        """display_name 应为 'DeepSeek'。"""
        assert DeepSeekAdapter.display_name == "DeepSeek"

    def test_top_up_url属性(self):
        """top_up_url 应指向 DeepSeek 充值页。"""
        assert "deepseek.com" in DeepSeekAdapter.top_up_url
        assert DeepSeekAdapter.top_up_url.startswith("https://")

    def test_login_url属性(self):
        """login_url 应指向 DeepSeek 登录页。"""
        assert "deepseek.com" in DeepSeekAdapter.login_url
        assert DeepSeekAdapter.login_url.startswith("https://")

    def test_supported_methods包含alipay_qr(self):
        """DeepSeek 适配器应支持支付宝扫码支付。"""
        assert PaymentMethod.alipay_qr in DeepSeekAdapter.supported_methods

    async def test_validate_amount_合法金额(self):
        """金额 >= 10 时，validate_amount 应返回 True。"""
        adapter = DeepSeekAdapter()
        assert await adapter.validate_amount(10.0) is True
        assert await adapter.validate_amount(100.0) is True
        assert await adapter.validate_amount(1000.0) is True

    async def test_validate_amount_非法金额(self):
        """金额 < 10 时，validate_amount 应返回 False。"""
        adapter = DeepSeekAdapter()
        assert await adapter.validate_amount(9.99) is False
        assert await adapter.validate_amount(0.0) is False
        assert await adapter.validate_amount(-1.0) is False

    def test_get_login_url(self):
        """get_login_url 应返回 login_url 属性值。"""
        adapter = DeepSeekAdapter()
        assert adapter.get_login_url() == DeepSeekAdapter.login_url

    def test_get_top_up_url(self):
        """get_top_up_url 应返回 top_up_url 属性值。"""
        adapter = DeepSeekAdapter()
        assert adapter.get_top_up_url() == DeepSeekAdapter.top_up_url

    def test_recipe已注册并包含关键选择器(self):
        """DeepSeek 应该有可复用的 experience recipe。"""
        recipe = get_recipe("deepseek")
        assert recipe is not None
        assert recipe.recipe_id == "deepseek.topup_alipay_qr"
        assert "label:has-text('¥{amount_int}')" in recipe.selectors["amount_exact"]
        assert (
            "div.ds-button.ds-button--primary:has-text('Next step')"
            in recipe.selectors["confirm"]
        )
        assert "text=Scan QR code to pay" in recipe.selectors["qr"]
        assert [waypoint.id for waypoint in recipe.waypoints] == [
            "open_topup_page",
            "verify_login_state",
            "verify_identity_gate",
            "select_topup_amount",
            "ensure_payment_method",
            "confirm_topup_checkout",
            "wait_for_qr",
        ]

    @pytest.mark.asyncio
    async def test_select_amount优先使用经验库中的金额标签(self):
        """DeepSeek 金额选择应命中经验库中的 label 选择器。"""
        adapter = DeepSeekAdapter()
        page = MagicMock()
        element = MagicMock()
        element.click = AsyncMock()

        async def wait_for_selector(selector: str, timeout: int | None = None):
            if selector == "label:has-text('¥10')":
                return element
            raise RuntimeError(f"no match: {selector}")

        page.wait_for_selector = AsyncMock(side_effect=wait_for_selector)
        steps: list[ScriptStep] = []

        selected = await adapter._select_amount(page, 10.0, steps)

        assert selected is True
        assert steps[-1].selector == "label:has-text('¥10')"
        element.click.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_select_payment_method接受默认在线充值布局(self):
        """DeepSeek 在默认在线充值布局下无需显式点支付宝。"""
        adapter = DeepSeekAdapter()
        page = MagicMock()

        async def wait_for_selector(selector: str, timeout: int | None = None):
            if selector == "text=Payment method":
                return MagicMock()
            raise RuntimeError(f"no match: {selector}")

        page.wait_for_selector = AsyncMock(side_effect=wait_for_selector)
        steps: list[ScriptStep] = []

        await adapter._select_payment_method(page, steps)

        assert steps[-1].action == "wait"
        assert steps[-1].selector == "text=Payment method"

    @pytest.mark.asyncio
    async def test_click_confirm支持_next_step_div(self):
        """DeepSeek 当前真实页面使用 Next step div 作为确认入口。"""
        adapter = DeepSeekAdapter()
        page = MagicMock()
        element = MagicMock()
        element.click = AsyncMock()

        async def wait_for_selector(selector: str, timeout: int | None = None):
            if selector == "div:has-text('Next step')":
                return element
            raise RuntimeError(f"no match: {selector}")

        page.wait_for_selector = AsyncMock(side_effect=wait_for_selector)
        steps: list[ScriptStep] = []

        await adapter._click_confirm(page, steps)

        assert steps[-1].selector == "div:has-text('Next step')"
        element.click.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_click_confirm优先使用最后一个经验库locator(self):
        """DeepSeek 在多处出现 Next step 文本时应点击最后一个 recipe 命中的主按钮。"""
        adapter = DeepSeekAdapter()
        page = MagicMock()
        target = MagicMock()
        target.click = AsyncMock()
        other = MagicMock()
        locator = MagicMock()
        locator.count = AsyncMock(return_value=2)

        def nth_side_effect(index: int):
            return target if index == 1 else other

        locator.nth.side_effect = nth_side_effect

        def locator_side_effect(selector: str):
            if selector == "div.ds-button.ds-button--primary:has-text('Next step')":
                return locator
            raise RuntimeError(f"no locator: {selector}")

        page.locator.side_effect = locator_side_effect
        page.wait_for_selector = AsyncMock(side_effect=RuntimeError("should not be used"))
        steps: list[ScriptStep] = []

        await adapter._click_confirm(page, steps)

        assert (
            steps[-1].selector
            == "div.ds-button.ds-button--primary:has-text('Next step')"
        )
        target.click.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_wait_for_qr接受二维码文本信号(self):
        """DeepSeek 二维码页可通过文本信号而非图片元素识别。"""
        adapter = DeepSeekAdapter()
        page = MagicMock()
        page.wait_for_selector = AsyncMock(return_value=MagicMock())
        steps: list[ScriptStep] = []

        await adapter._wait_for_qr(page, steps)

        assert steps[-1].action == "detect_payment"
        assert steps[-1].selector == "text=Scan QR code to pay"
        assert steps[-1].requires_human_authorization is True

    @pytest.mark.asyncio
    async def test_ensure_identity_gate_cleared提示先做实名认证(self):
        """DeepSeek 仍有实名门槛时应给出明确错误。"""
        adapter = DeepSeekAdapter()
        page = MagicMock()

        def locator_side_effect(selector: str):
            locator = MagicMock()
            if selector == "text=Please complete real-name verification":
                locator.count = AsyncMock(return_value=1)
            else:
                locator.count = AsyncMock(return_value=0)
            return locator

        page.locator.side_effect = locator_side_effect

        with pytest.raises(ScriptExecutionError, match="实名认证"):
            await adapter._ensure_identity_gate_cleared(page)

    @pytest.mark.asyncio
    async def test_execute_topup_records_recipe_outcome(self, tmp_path):
        adapter = DeepSeekAdapter()
        adapter.recipe_store = ExperienceStore(tmp_path / "experience" / "recipes.db")
        page = MagicMock()
        page.url = DeepSeekAdapter.top_up_url
        page.goto = AsyncMock(side_effect=lambda url, **kwargs: setattr(page, "url", url))
        page.wait_for_selector = AsyncMock(return_value=MagicMock())
        page.locator.return_value.count = AsyncMock(return_value=1)
        page.evaluate = AsyncMock(
            return_value="Amount\nPayment method\nNext step\nScan QR code to pay"
        )

        adapter.ensure_logged_in = AsyncMock()
        adapter._ensure_identity_gate_cleared = AsyncMock()
        adapter._select_amount = AsyncMock(return_value=True)
        adapter._select_payment_method = AsyncMock()
        adapter._click_confirm = AsyncMock()
        adapter._wait_for_qr = AsyncMock()

        steps = await adapter.execute_topup(page, 20.0)

        outcomes = adapter.recipe_store.list_outcomes(
            platform="deepseek",
            flow="topup_alipay_qr",
        )
        assert steps[0].action == "navigate"
        assert outcomes[-1]["succeeded"] is True
        assert outcomes[-1]["details"]["step_count"] == len(steps)

    @pytest.mark.asyncio
    async def test_deepseek_recipe_policy_checkpoint_blocks_missing_markers(self):
        adapter = DeepSeekAdapter()
        adapter.ensure_logged_in = AsyncMock()
        adapter._ensure_identity_gate_cleared = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="Random content only")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[5],
            page=page,
            amount=20.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        with pytest.raises(RuntimeError, match="policy checkpoint blocked"):
            await adapter._recipe_policy_checkpoint(context)

    @pytest.mark.asyncio
    async def test_deepseek_recipe_policy_checkpoint_accepts_visible_markers(self):
        adapter = DeepSeekAdapter()
        adapter.ensure_logged_in = AsyncMock()
        adapter._ensure_identity_gate_cleared = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="Amount\nPayment method\nNext step")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[5],
            page=page,
            amount=20.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        await adapter._recipe_policy_checkpoint(context)


# ===========================================================================
# KimiAdapter 测试
# ===========================================================================


class TestKimiAdapter:
    """KimiAdapter 属性和方法测试。"""

    def test_name属性(self):
        """name 属性应为 'kimi'。"""
        assert KimiAdapter.name == "kimi"

    def test_display_name属性(self):
        """display_name 应包含 Kimi 标识。"""
        assert "Kimi" in KimiAdapter.display_name

    def test_top_up_url属性(self):
        """top_up_url 应指向 Kimi 充值页。"""
        assert "moonshot" in KimiAdapter.top_up_url or "kimi" in KimiAdapter.top_up_url
        assert KimiAdapter.top_up_url.startswith("https://")

    def test_supported_methods包含alipay_qr(self):
        """Kimi 适配器应支持支付宝扫码支付。"""
        assert PaymentMethod.alipay_qr in KimiAdapter.supported_methods

    def test_recipe已注册并包含关键waypoints(self):
        recipe = get_recipe("kimi", "membership_monthly_qr")
        assert recipe is not None
        assert recipe.recipe_id == "kimi.membership_monthly_qr"
        assert [waypoint.id for waypoint in recipe.waypoints] == [
            "open_homepage",
            "verify_login_state",
            "reach_pricing_surface",
            "select_monthly_plan",
            "ensure_payment_method",
            "confirm_membership_checkout",
            "wait_for_qr",
        ]

    async def test_validate_amount_合法金额(self):
        """金额 >= 10 时，validate_amount 应返回 True。"""
        adapter = KimiAdapter()
        assert await adapter.validate_amount(10.0) is True
        assert await adapter.validate_amount(500.0) is True

    async def test_validate_amount_非法金额(self):
        """金额 < 10 时，validate_amount 应返回 False。"""
        adapter = KimiAdapter()
        assert await adapter.validate_amount(9.0) is False
        assert await adapter.validate_amount(0.01) is False

    @pytest.mark.asyncio
    async def test_check_login_state检测未登录提示(self):
        """Kimi 应能根据首页登录提示识别未登录状态。"""
        adapter = KimiAdapter()
        page = MagicMock()
        page.url = "https://www.kimi.com"
        locator = MagicMock()
        locator.first.is_visible = AsyncMock(return_value=True)
        page.locator.return_value = locator

        logged_in, reason = await adapter.check_login_state(page)

        assert logged_in is False
        assert reason is not None
        assert "payswitch login kimi" in reason

    @pytest.mark.asyncio
    async def test_check_login_state检测英文未登录提示(self):
        """Kimi 英文界面的登录提示也应被识别为未登录。"""
        adapter = KimiAdapter()
        page = MagicMock()
        page.url = "https://www.kimi.com/"

        def locator_side_effect(selector: str):
            locator = MagicMock()
            if selector == "text=Log in to sync chat history":
                locator.first.is_visible = AsyncMock(return_value=True)
            else:
                locator.first.is_visible = AsyncMock(return_value=False)
            return locator

        page.locator.side_effect = locator_side_effect

        logged_in, reason = await adapter.check_login_state(page)

        assert logged_in is False
        assert reason is not None
        assert "payswitch login kimi" in reason

    @pytest.mark.asyncio
    async def test_check_login_state检测会员页登录弹窗(self):
        """Kimi 会员页内嵌登录弹窗也应被识别为未登录。"""
        adapter = KimiAdapter()
        page = MagicMock()
        page.url = "https://www.kimi.com/membership/pricing?from=pay_switch"

        def locator_side_effect(selector: str):
            locator = MagicMock()
            locator.first.is_visible = AsyncMock(
                return_value=selector == "[role='dialog']:has-text('扫码登录')"
            )
            return locator

        page.locator.side_effect = locator_side_effect

        logged_in, reason = await adapter.check_login_state(page)

        assert logged_in is False
        assert reason is not None
        assert "登录态失效" in reason

    @pytest.mark.asyncio
    async def test_ensure_checkout_page_navigates_to_pricing_entry(self):
        """Kimi 新版首页在找不到入口时才使用稳定 pricing 兜底。"""
        adapter = KimiAdapter()
        page = MagicMock()
        page.url = "https://www.kimi.com/"
        page.wait_for_load_state = AsyncMock()
        page.goto = AsyncMock()

        def locator_side_effect(selector: str):
            locator = MagicMock()
            locator.count = AsyncMock(
                return_value=1 if selector == "text=Monthly" and page.goto.await_count else 0
            )
            return locator

        page.wait_for_selector = AsyncMock(side_effect=TimeoutError)
        page.locator.side_effect = locator_side_effect

        steps: list[ScriptStep] = []
        await adapter._ensure_checkout_page(page, steps)

        page.goto.assert_awaited_once_with(
            KimiAdapter.top_up_url,
            wait_until="domcontentloaded",
            timeout=15_000,
        )
        assert steps[-1].url == KimiAdapter.top_up_url

    @pytest.mark.asyncio
    async def test_check_login_state_忽略隐藏登录模板(self):
        """隐藏登录模板不应把已登录 Kimi 账号误判为未登录。"""
        adapter = KimiAdapter()
        page = MagicMock()
        page.url = "https://www.kimi.com/"

        locator = MagicMock()
        locator.first.is_visible = AsyncMock(return_value=False)
        page.locator.return_value = locator

        logged_in, reason = await adapter.check_login_state(page)

        assert logged_in is True
        assert reason is None

    @pytest.mark.asyncio
    async def test_ensure_checkout_page_clicks_homepage_entry_before_pricing_fallback(self):
        """Kimi 应先从官网首页点击订阅入口，而不是一开始直跳 pricing。"""
        adapter = KimiAdapter()
        page = MagicMock()
        page.url = "https://www.kimi.com/"
        page.goto = AsyncMock()
        page.wait_for_load_state = AsyncMock()
        page.locator.return_value.count = AsyncMock(return_value=0)

        entry = MagicMock()
        entry.click = AsyncMock(side_effect=lambda *args, **kwargs: setattr(
            page,
            "url",
            KimiAdapter.top_up_url,
        ))

        async def wait_for_selector(selector: str, *args, **kwargs):
            if selector == "a:has-text('Upgrade your plan')":
                return entry
            raise TimeoutError(selector)

        page.wait_for_selector = AsyncMock(side_effect=wait_for_selector)

        steps: list[ScriptStep] = []
        await adapter._ensure_checkout_page(page, steps)

        page.goto.assert_not_awaited()
        entry.click.assert_awaited_once()
        assert steps[-1].description == "从 Kimi 首页进入订阅/充值入口"

    @pytest.mark.asyncio
    async def test_select_kimi_monthly_plan_clicks_visible_coordinates(self):
        """新版 pricing 页应先选 Monthly，再点目标金额的 Subscribe。"""
        adapter = KimiAdapter()
        page = MagicMock()
        page.url = "https://www.kimi.com/membership/pricing?from=pay_switch"
        page.wait_for_timeout = AsyncMock()
        page.mouse.click = AsyncMock()
        page.locator.return_value.count = AsyncMock(return_value=0)
        page.evaluate = AsyncMock(
            side_effect=[
                {"x": 520, "y": 234},
                {"x": 320, "y": 514},
            ]
        )

        steps: list[ScriptStep] = []
        selected = await adapter._select_kimi_monthly_plan(page, 49.0, steps)

        assert selected is True
        assert page.mouse.click.await_args_list[0].args == (520.0, 234.0)
        assert page.mouse.click.await_args_list[1].args == (320.0, 514.0)
        assert steps[-1].selector == "button.plan-button"

    @pytest.mark.asyncio
    async def test_select_payment_method_accepts_kimi_agreement_stage(self):
        """Kimi 协议弹窗阶段应视为默认二维码支付方式已选。"""
        adapter = KimiAdapter()
        page = MagicMock()

        async def wait_for_selector(selector: str, *args, **kwargs):
            if selector == "text=Agree to Kimi's Agreements":
                return MagicMock()
            raise TimeoutError(selector)

        page.wait_for_selector = AsyncMock(side_effect=wait_for_selector)

        steps: list[ScriptStep] = []
        await adapter._select_payment_method(page, steps)

        assert steps[-1].selector == "text=Agree to Kimi's Agreements"

    @pytest.mark.asyncio
    async def test_ensure_checkout_page_accepts_existing_membership_surface(self):
        """已打开会员弹窗时，不应再次寻找或点击入口。"""
        adapter = KimiAdapter()
        page = MagicMock()
        page.url = "https://www.kimi.com/"
        page.wait_for_selector = AsyncMock()

        def locator_side_effect(selector: str):
            locator = MagicMock()
            locator.count = AsyncMock(
                return_value=1 if selector == "text=Monthly" else 0
            )
            return locator

        page.locator.side_effect = locator_side_effect

        steps: list[ScriptStep] = []
        await adapter._ensure_checkout_page(page, steps)

        page.wait_for_selector.assert_not_called()
        assert steps == []

    @pytest.mark.asyncio
    async def test_execute_topup_records_recipe_outcome(self, tmp_path):
        adapter = KimiAdapter()
        adapter.recipe_store = ExperienceStore(tmp_path / "experience" / "recipes.db")
        page = MagicMock()
        page.url = "https://www.kimi.com/"
        page.goto = AsyncMock(side_effect=lambda url, **kwargs: setattr(page, "url", url))
        page.wait_for_load_state = AsyncMock()
        page.wait_for_timeout = AsyncMock()
        page.evaluate = AsyncMock(return_value="Monthly Pay with Alipay / WeChat")
        page.locator.return_value.count = AsyncMock(return_value=1)

        adapter.ensure_logged_in = AsyncMock()
        adapter._ensure_checkout_page = AsyncMock()
        adapter._select_amount = AsyncMock(return_value=True)
        adapter._select_payment_method = AsyncMock()
        adapter._click_confirm = AsyncMock()
        adapter._wait_for_qr = AsyncMock()

        steps = await adapter.execute_topup(page, 49.0)

        outcomes = adapter.recipe_store.list_outcomes(
            platform="kimi",
            flow="membership_monthly_qr",
        )
        assert steps[0].action == "navigate"
        assert outcomes[-1]["succeeded"] is True
        assert outcomes[-1]["details"]["step_count"] == len(steps)

    @pytest.mark.asyncio
    async def test_recipe_policy_checkpoint_blocks_missing_markers(self):
        adapter = KimiAdapter()
        adapter.ensure_logged_in = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="Random content only")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[5],
            page=page,
            amount=49.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        with pytest.raises(RuntimeError, match="policy checkpoint blocked"):
            await adapter._recipe_policy_checkpoint(context)

    @pytest.mark.asyncio
    async def test_recipe_policy_checkpoint_accepts_visible_agreement_marker(self):
        adapter = KimiAdapter()
        adapter.ensure_logged_in = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="Agree to Kimi's Agreements\nContinue")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[5],
            page=page,
            amount=49.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        await adapter._recipe_policy_checkpoint(context)


# ===========================================================================
# QwenAdapter 测试
# ===========================================================================


class TestQwenAdapter:
    """QwenAdapter 属性和方法测试。"""

    def test_name属性(self):
        """name 属性应为 'qwen'。"""
        assert QwenAdapter.name == "qwen"

    def test_display_name属性(self):
        """display_name 应包含 Qwen 或通义千问标识。"""
        assert "Qwen" in QwenAdapter.display_name or "通义" in QwenAdapter.display_name

    def test_top_up_url属性(self):
        """top_up_url 应指向阿里云相关充值页。"""
        assert QwenAdapter.top_up_url.startswith("https://")

    def test_supported_methods包含alipay_qr(self):
        """Qwen 适配器应支持支付宝扫码支付。"""
        assert PaymentMethod.alipay_qr in QwenAdapter.supported_methods

    def test_recipe_metadata(self):
        adapter = QwenAdapter()
        recipe = get_recipe("qwen", adapter.recipe_flow)

        assert recipe is not None
        assert recipe.recipe_id == "qwen.topup_alipay_qr"
        assert [waypoint.id for waypoint in recipe.waypoints] == [
            "open_topup_page",
            "verify_login_state",
            "select_topup_amount",
            "ensure_payment_method",
            "confirm_topup_checkout",
            "wait_for_qr",
        ]

    async def test_validate_amount_合法金额(self):
        """金额 >= 10 时，validate_amount 应返回 True。"""
        adapter = QwenAdapter()
        assert await adapter.validate_amount(10.0) is True
        assert await adapter.validate_amount(2000.0) is True

    async def test_validate_amount_非法金额(self):
        """金额 < 10 时，validate_amount 应返回 False。"""
        adapter = QwenAdapter()
        assert await adapter.validate_amount(5.0) is False
        assert await adapter.validate_amount(0.0) is False

    @pytest.mark.asyncio
    async def test_click_confirm_blocks_missing_payment_markers(self):
        adapter = QwenAdapter()
        page = MagicMock()
        page.url = adapter.top_up_url
        page.evaluate = AsyncMock(return_value="Random content only")
        steps: list[ScriptStep] = []

        with pytest.raises(ScriptExecutionError, match="policy checkpoint blocked"):
            await adapter._click_confirm(page, steps)

    @pytest.mark.asyncio
    async def test_click_confirm_records_high_risk_final_authorization_step(self):
        adapter = QwenAdapter()
        button = _mock_clickable_element(needs_enabled_state=True)
        page = _build_wait_selector_page(
            visible_text="支付宝\n支付方式\n确认充值",
            selector_element_map={"button:has-text('确认充值')": button},
            url=adapter.top_up_url,
        )
        steps: list[ScriptStep] = []

        await adapter._click_confirm(page, steps)

        assert steps[-1].selector == "button:has-text('确认充值')"
        assert steps[-1].category.value == "final_authorization"
        assert steps[-1].risk.value == "high"
        button.wait_for_element_state.assert_awaited_once_with("enabled", timeout=15_000)
        button.click.assert_awaited_once_with(timeout=15_000)

    @pytest.mark.asyncio
    async def test_execute_topup_records_recipe_outcome(self, tmp_path):
        adapter = QwenAdapter()
        adapter.recipe_store = ExperienceStore(tmp_path / "experience" / "recipes.db")
        page = MagicMock()
        page.url = QwenAdapter.top_up_url
        page.goto = AsyncMock(side_effect=lambda url, **kwargs: setattr(page, "url", url))
        page.wait_for_load_state = AsyncMock()
        page.wait_for_selector = AsyncMock(return_value=MagicMock())
        page.evaluate = AsyncMock(return_value="支付宝\n支付方式\n确认充值\n二维码")

        adapter.ensure_logged_in = AsyncMock()
        adapter._select_amount = AsyncMock(return_value=True)
        adapter._select_payment_method = AsyncMock()
        adapter._click_confirm = AsyncMock()
        adapter._wait_for_qr = AsyncMock()

        steps = await adapter.execute_topup(page, 20.0)

        outcomes = adapter.recipe_store.list_outcomes(
            platform="qwen",
            flow="topup_alipay_qr",
        )
        assert steps[0].action == "navigate"
        assert outcomes[-1]["succeeded"] is True
        assert outcomes[-1]["details"]["step_count"] == len(steps)

    @pytest.mark.asyncio
    async def test_qwen_recipe_policy_checkpoint_blocks_missing_markers(self):
        adapter = QwenAdapter()
        adapter.ensure_logged_in = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="Random content only")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[4],
            page=page,
            amount=20.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        with pytest.raises(RuntimeError, match="policy checkpoint blocked"):
            await adapter._recipe_policy_checkpoint(context)

    @pytest.mark.asyncio
    async def test_qwen_recipe_policy_checkpoint_accepts_visible_markers(self):
        adapter = QwenAdapter()
        adapter.ensure_logged_in = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="支付宝\n支付方式\n确认充值")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[4],
            page=page,
            amount=20.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        await adapter._recipe_policy_checkpoint(context)


class TestJimengAdapter:
    def test_name(self):
        assert JimengAdapter.name == "jimeng"

    def test_urls(self):
        assert JimengAdapter.top_up_url.startswith("https://")
        assert "jimeng" in JimengAdapter.top_up_url
        assert JimengAdapter.login_url.startswith("https://")

    def test_supported_methods(self):
        assert PaymentMethod.alipay_qr in JimengAdapter.supported_methods
        assert PaymentMethod.wechat_qr in JimengAdapter.supported_methods

    def test_recipe_metadata(self):
        adapter = JimengAdapter()
        recipe = get_recipe("jimeng", adapter.recipe_flow)

        assert recipe is not None
        assert recipe.recipe_id == "jimeng.topup_alipay_qr"
        assert [waypoint.id for waypoint in recipe.waypoints] == [
            "open_homepage",
            "verify_login_state",
            "enter_checkout_surface",
            "select_topup_amount",
            "ensure_payment_method",
            "confirm_topup_checkout",
            "wait_for_qr",
        ]

    async def test_validate_amount(self):
        adapter = JimengAdapter()
        assert await adapter.validate_amount(50.0) is True
        assert await adapter.validate_amount(10.0) is False
        assert await adapter.validate_amount(0.0) is False

    @pytest.mark.asyncio
    async def test_click_checkout_blocks_missing_payment_markers(self):
        adapter = JimengAdapter()
        page = MagicMock()
        page.url = adapter.top_up_url
        page.evaluate = AsyncMock(return_value="Workspace overview")
        steps: list[ScriptStep] = []

        with pytest.raises(ScriptExecutionError, match="policy checkpoint blocked"):
            await adapter._click_checkout(page, steps, PaymentMethod.alipay_qr)

    @pytest.mark.asyncio
    async def test_click_checkout_records_high_risk_final_authorization_step(self):
        adapter = JimengAdapter()
        button = _mock_clickable_element()
        page = _build_wait_selector_page(
            visible_text="支付宝\n确认订单\n去支付",
            selector_element_map={"button:has-text('去支付')": button},
            url=adapter.top_up_url,
        )
        steps: list[ScriptStep] = []

        await adapter._click_checkout(page, steps, PaymentMethod.alipay_qr)

        assert steps[-1].selector == "button:has-text('去支付')"
        assert steps[-1].category.value == "final_authorization"
        assert steps[-1].risk.value == "high"
        button.click.assert_awaited_once_with(timeout=15_000)

    @pytest.mark.asyncio
    async def test_execute_topup_records_recipe_outcome(self, tmp_path):
        adapter = JimengAdapter()
        adapter.recipe_store = ExperienceStore(tmp_path / "experience" / "recipes.db")
        page = MagicMock()
        page.url = JimengAdapter.top_up_url
        page.goto = AsyncMock(side_effect=lambda url, **kwargs: setattr(page, "url", url))
        page.wait_for_load_state = AsyncMock()
        page.wait_for_selector = AsyncMock(return_value=MagicMock())
        page.wait_for_timeout = AsyncMock()
        page.evaluate = AsyncMock(return_value="支付宝\n购买积分\n去支付")

        adapter.ensure_logged_in = AsyncMock()
        adapter._enter_checkout = AsyncMock()
        adapter._select_amount = AsyncMock()
        adapter._select_payment_method = AsyncMock()
        adapter._click_checkout = AsyncMock()
        adapter._wait_for_human_payment_gate = AsyncMock()

        steps = await adapter.execute_topup(page, 50.0)

        outcomes = adapter.recipe_store.list_outcomes(
            platform="jimeng",
            flow="topup_alipay_qr",
        )
        assert steps[0].action == "navigate"
        assert outcomes[-1]["succeeded"] is True
        assert outcomes[-1]["details"]["step_count"] == len(steps)

    @pytest.mark.asyncio
    async def test_jimeng_recipe_policy_checkpoint_blocks_missing_markers(self):
        adapter = JimengAdapter()
        adapter.ensure_logged_in = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="Workspace overview")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[5],
            page=page,
            amount=50.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        with pytest.raises(RuntimeError, match="policy checkpoint blocked"):
            await adapter._recipe_policy_checkpoint(context)

    @pytest.mark.asyncio
    async def test_jimeng_recipe_policy_checkpoint_accepts_visible_markers(self):
        adapter = JimengAdapter()
        adapter.ensure_logged_in = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="支付宝\n购买积分\n去支付")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[5],
            page=page,
            amount=50.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        await adapter._recipe_policy_checkpoint(context)


class TestVolcanoAdapter:
    def test_name(self):
        assert VolcanoAdapter.name == "volcano"

    def test_urls(self):
        assert VolcanoAdapter.top_up_url.startswith("https://")
        assert "volcengine.com" in VolcanoAdapter.top_up_url
        assert VolcanoAdapter.login_url.startswith("https://")

    def test_supported_methods(self):
        assert PaymentMethod.alipay_qr in VolcanoAdapter.supported_methods
        assert PaymentMethod.wechat_qr in VolcanoAdapter.supported_methods
        assert PaymentMethod.bankcard in VolcanoAdapter.supported_methods

    def test_recipe_metadata(self):
        adapter = VolcanoAdapter()
        recipe = get_recipe("volcano", adapter.recipe_flow)

        assert recipe is not None
        assert recipe.recipe_id == "volcano.topup_alipay_qr"
        assert [waypoint.id for waypoint in recipe.waypoints] == [
            "open_topup_page",
            "verify_login_state",
            "select_topup_amount",
            "continue_to_payment_surface",
            "ensure_payment_method",
            "confirm_topup_checkout",
            "wait_for_qr",
        ]

    async def test_validate_amount(self):
        adapter = VolcanoAdapter()
        assert await adapter.validate_amount(1.0) is True
        assert await adapter.validate_amount(0.0) is False

    @pytest.mark.asyncio
    async def test_click_pay_blocks_missing_payment_markers(self):
        adapter = VolcanoAdapter()
        page = MagicMock()
        page.url = adapter.top_up_url
        page.evaluate = AsyncMock(return_value="Random page")
        steps: list[ScriptStep] = []

        with pytest.raises(ScriptExecutionError, match="policy checkpoint blocked"):
            await adapter._click_pay(page, steps, PaymentMethod.alipay_qr)

    @pytest.mark.asyncio
    async def test_click_pay_records_high_risk_final_authorization_step(self):
        adapter = VolcanoAdapter()
        button = _mock_clickable_element()
        page = _build_wait_selector_page(
            visible_text="支付宝\n支付方式\n去支付",
            selector_element_map={"button:has-text('去支付')": button},
            url=adapter.top_up_url,
        )
        steps: list[ScriptStep] = []

        await adapter._click_pay(page, steps, PaymentMethod.alipay_qr)

        assert steps[-1].selector == "button:has-text('去支付')"
        assert steps[-1].category.value == "final_authorization"
        assert steps[-1].risk.value == "high"
        button.click.assert_awaited_once_with(timeout=15_000)

    @pytest.mark.asyncio
    async def test_execute_topup_records_recipe_outcome(self, tmp_path):
        adapter = VolcanoAdapter()
        adapter.recipe_store = ExperienceStore(tmp_path / "experience" / "recipes.db")
        page = MagicMock()
        page.url = VolcanoAdapter.top_up_url
        page.goto = AsyncMock(side_effect=lambda url, **kwargs: setattr(page, "url", url))
        page.wait_for_load_state = AsyncMock()
        page.wait_for_selector = AsyncMock(return_value=MagicMock())
        page.evaluate = AsyncMock(return_value="支付宝\n支付方式\n去支付")

        adapter.ensure_logged_in = AsyncMock()
        adapter._select_amount = AsyncMock()
        adapter._click_next = AsyncMock()
        adapter._select_payment_method = AsyncMock()
        adapter._click_pay = AsyncMock()
        adapter._wait_for_human_payment_gate = AsyncMock()

        steps = await adapter.execute_topup(page, 20.0)

        outcomes = adapter.recipe_store.list_outcomes(
            platform="volcano",
            flow="topup_alipay_qr",
        )
        assert steps[0].action == "navigate"
        assert outcomes[-1]["succeeded"] is True
        assert outcomes[-1]["details"]["step_count"] == len(steps)

    @pytest.mark.asyncio
    async def test_volcano_recipe_policy_checkpoint_blocks_missing_markers(self):
        adapter = VolcanoAdapter()
        adapter.ensure_logged_in = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="Random page")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[5],
            page=page,
            amount=20.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        with pytest.raises(RuntimeError, match="policy checkpoint blocked"):
            await adapter._recipe_policy_checkpoint(context)

    @pytest.mark.asyncio
    async def test_volcano_recipe_policy_checkpoint_accepts_visible_markers(self):
        adapter = VolcanoAdapter()
        adapter.ensure_logged_in = AsyncMock()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="支付宝\n支付方式\n去支付")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[5],
            page=page,
            amount=20.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        await adapter._recipe_policy_checkpoint(context)


class TestNineEmailAdapter:
    def test_name(self):
        assert NineEmailAdapter.name == "nineemail"

    def test_urls(self):
        assert NineEmailAdapter.top_up_url.startswith("https://")
        assert NineEmailAdapter.login_url.startswith("https://")

    def test_recipe_metadata(self):
        adapter = NineEmailAdapter()
        recipe = get_recipe("nineemail", adapter.recipe_flow)

        assert recipe is not None
        assert recipe.recipe_id == "nineemail.product_alipay_qr"
        assert [waypoint.id for waypoint in recipe.waypoints] == [
            "open_product_page",
            "prepare_order_form",
            "submit_order",
            "confirm_topup_checkout",
            "wait_for_qr",
        ]

    @pytest.mark.asyncio
    async def test_click_pay_now_blocks_missing_payment_markers(self):
        adapter = NineEmailAdapter()
        page = MagicMock()
        page.url = adapter.top_up_url
        page.evaluate = AsyncMock(return_value="Order detail")
        page.get_by_text.return_value.click = AsyncMock()
        page.wait_for_url = AsyncMock()
        steps: list[ScriptStep] = []

        with pytest.raises(ScriptExecutionError, match="policy checkpoint blocked"):
            await adapter._click_pay_now(page, steps)

    @pytest.mark.asyncio
    async def test_click_pay_now_records_high_risk_final_authorization_step(self):
        adapter = NineEmailAdapter()
        page = MagicMock()
        page.url = adapter.top_up_url
        page.evaluate = AsyncMock(return_value="确认订单\n支付宝\n立即支付")
        page.get_by_text.return_value.click = AsyncMock()
        page.wait_for_url = AsyncMock()
        steps: list[ScriptStep] = []

        await adapter._click_pay_now(page, steps)

        assert steps[-1].selector == "text=立即支付"
        assert steps[-1].category.value == "final_authorization"
        assert steps[-1].risk.value == "high"
        page.get_by_text.return_value.click.assert_awaited_once_with(timeout=15_000)

    @pytest.mark.asyncio
    async def test_execute_topup_records_recipe_outcome(self, tmp_path):
        adapter = NineEmailAdapter()
        adapter.recipe_store = ExperienceStore(tmp_path / "experience" / "recipes.db")
        page = MagicMock()
        page.url = NineEmailAdapter.top_up_url
        page.goto = AsyncMock(side_effect=lambda url, **kwargs: setattr(page, "url", url))
        page.wait_for_load_state = AsyncMock()
        page.wait_for_selector = AsyncMock(return_value=MagicMock())
        page.evaluate = AsyncMock(return_value="支付宝\n下单\n立即支付")

        adapter._open_product_page = AsyncMock(return_value=10.0)
        adapter._fill_order_form = AsyncMock()
        adapter._submit_order = AsyncMock()
        adapter._click_pay_now = AsyncMock()
        adapter._wait_for_qr = AsyncMock()

        steps = await adapter.execute_topup(page, 20.0)

        outcomes = adapter.recipe_store.list_outcomes(
            platform="nineemail",
            flow="product_alipay_qr",
        )
        assert steps[0].action == "navigate"
        assert outcomes[-1]["succeeded"] is True
        assert outcomes[-1]["details"]["step_count"] == len(steps)

    @pytest.mark.asyncio
    async def test_nineemail_recipe_policy_checkpoint_blocks_missing_markers(self):
        adapter = NineEmailAdapter()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="Order detail")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[3],
            page=page,
            amount=20.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        with pytest.raises(RuntimeError, match="policy checkpoint blocked"):
            await adapter._recipe_policy_checkpoint(context)

    @pytest.mark.asyncio
    async def test_nineemail_recipe_policy_checkpoint_accepts_visible_markers(self):
        adapter = NineEmailAdapter()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="支付宝\n下单\n立即支付")
        context = RecipeRunContext(
            recipe=adapter.recipe,
            waypoint=adapter.recipe.waypoints[3],
            page=page,
            amount=20.0,
            method=PaymentMethod.alipay_qr,
            steps=[],
            record_step=AsyncMock(),
        )

        await adapter._recipe_policy_checkpoint(context)


# ===========================================================================
# SiteAdapter 抽象类测试
# ===========================================================================


class TestSiteAdapterABC:
    """SiteAdapter 抽象基类测试。"""

    def test_未实现execute_topup时不能实例化(self):
        """未实现 execute_topup 抽象方法的子类不应能被实例化。"""
        class IncompleteAdapter(SiteAdapter):
            name = "incomplete"
            display_name = "Incomplete"
            top_up_url = "https://example.com"
            login_url = "https://example.com/login"
            supported_methods = [PaymentMethod.alipay_qr]
            # 故意不实现 execute_topup

        with pytest.raises(TypeError):
            IncompleteAdapter()

    def test_完整实现可以实例化(self):
        """实现了所有抽象方法的子类应能正常实例化。"""
        class CompleteAdapter(SiteAdapter):
            name = "complete"
            display_name = "Complete"
            top_up_url = "https://example.com"
            login_url = "https://example.com/login"
            supported_methods = [PaymentMethod.alipay_qr]

            async def execute_topup(self, page, amount, method=None):
                return []

        adapter = CompleteAdapter()
        assert adapter is not None

    async def test_validate_amount默认实现_正数通过(self):
        """SiteAdapter 基类的 validate_amount 默认实现：amount > 0 返回 True。"""
        class MinimalAdapter(SiteAdapter):
            name = "minimal"
            display_name = "Minimal"
            top_up_url = "https://example.com"
            login_url = "https://example.com/login"
            supported_methods = []

            async def execute_topup(self, page, amount, method=None):
                return []

        adapter = MinimalAdapter()
        assert await adapter.validate_amount(0.01) is True
        assert await adapter.validate_amount(100.0) is True
        assert await adapter.validate_amount(0.0) is False


# ===========================================================================
# ScriptStep 测试
# ===========================================================================


class TestScriptStep:
    """ScriptStep 数据模型测试。"""

    def test_基本创建_navigate类型(self):
        """navigate 类型的 ScriptStep 应能正确创建。"""
        step = ScriptStep(
            description="导航到充值页",
            action="navigate",
            url="https://example.com/recharge",
        )
        assert step.description == "导航到充值页"
        assert step.action == "navigate"
        assert step.url == "https://example.com/recharge"
        assert step.selector is None
        assert step.value is None

    def test_基本创建_click类型(self):
        """click 类型的 ScriptStep 应能正确创建。"""
        step = ScriptStep(
            description="点击充值按钮",
            action="click",
            selector="button:has-text('充值')",
        )
        assert step.action == "click"
        assert step.selector == "button:has-text('充值')"

    def test_基本创建_fill类型(self):
        """fill 类型的 ScriptStep 应能携带 selector 和 value。"""
        step = ScriptStep(
            description="填写金额",
            action="fill",
            selector="input[name='amount']",
            value="100",
        )
        assert step.action == "fill"
        assert step.selector == "input[name='amount']"
        assert step.value == "100"

    def test_基本创建_detect_payment类型(self):
        """detect_payment 类型的 ScriptStep 用于通知检测器接管。"""
        step = ScriptStep(
            description="等待扫码",
            action="detect_payment",
            selector="[class*='qrcode']",
        )
        assert step.action == "detect_payment"

    def test_model_dump序列化(self):
        """model_dump 应返回包含所有字段的字典。"""
        step = ScriptStep(
            description="测试步骤",
            action="wait",
            selector="text=支付宝",
        )
        data = step.model_dump()
        assert "description" in data
        assert "action" in data
        assert "selector" in data
        assert "value" in data
        assert "url" in data


# ===========================================================================
# ScriptExecutionError 测试
# ===========================================================================


class TestScriptExecutionError:
    """ScriptExecutionError 异常类测试。"""

    def test_可以正常抛出和捕获(self):
        """ScriptExecutionError 应能被正常抛出并被 Exception 捕获。"""
        with pytest.raises(ScriptExecutionError, match="选择器失效"):
            raise ScriptExecutionError("选择器失效，触发回退")

    def test_携带错误消息(self):
        """ScriptExecutionError 应能携带具体错误描述信息。"""
        error_msg = "充值页 DOM 结构已变更，无法定位金额按钮"
        try:
            raise ScriptExecutionError(error_msg)
        except ScriptExecutionError as e:
            assert str(e) == error_msg

    def test_是Exception的子类(self):
        """ScriptExecutionError 应继承自 Exception。"""
        assert issubclass(ScriptExecutionError, Exception)
