import asyncio
from pathlib import Path

import pytest

from payswitch.profile_manager import (
    ProfileBinding,
    ProfileCompatibilityError,
    ProfilePromotionError,
    ProfileVaultManager,
    resolve_profile_schema_version,
)


def _binding(browser_engine: str = "playwright") -> ProfileBinding:
    return ProfileBinding(
        browser_engine=browser_engine,
        schema_version=resolve_profile_schema_version(browser_engine),
    )


def _run(coro):
    return asyncio.run(coro)


def test_promoted_profile_persists_into_next_task_profile(tmp_path: Path) -> None:
    manager = ProfileVaultManager(tmp_path / "profiles")
    binding = _binding()

    first = _run(
        manager.prepare_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_a",
            binding=binding,
        )
    )
    Path(first["profile_task_path"]).joinpath("cookies.json").write_text(
        '{"loggedIn": true}',
        encoding="utf-8",
    )
    _run(
        manager.promote_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_a",
            binding=binding,
        )
    )

    second = _run(
        manager.prepare_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_b",
            binding=binding,
        )
    )

    assert second["profile_state"] == "task_profile_prepared"
    cookies_path = Path(second["profile_task_path"]) / "cookies.json"
    assert cookies_path.read_text(encoding="utf-8") == '{"loggedIn": true}'


def test_discarded_task_profile_does_not_pollute_stable_profile(tmp_path: Path) -> None:
    manager = ProfileVaultManager(tmp_path / "profiles")
    binding = _binding()

    first = _run(
        manager.prepare_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_a",
            binding=binding,
        )
    )
    Path(first["profile_task_path"]).joinpath("transient.json").write_text(
        '{"transient": true}',
        encoding="utf-8",
    )
    _run(
        manager.discard_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_a",
            binding=binding,
            reason="task_failed",
        )
    )
    second = _run(
        manager.prepare_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_b",
            binding=binding,
        )
    )

    assert not Path(second["profile_task_path"]).joinpath("transient.json").exists()


def test_promotion_failure_rolls_back_previous_stable_profile(tmp_path: Path) -> None:
    manager = ProfileVaultManager(tmp_path / "profiles")
    binding = _binding()

    first = _run(
        manager.prepare_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="seed",
            binding=binding,
        )
    )
    Path(first["profile_task_path"]).joinpath("stable.txt").write_text("stable", encoding="utf-8")
    _run(
        manager.promote_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="seed",
            binding=binding,
        )
    )

    second = _run(
        manager.prepare_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="candidate",
            binding=binding,
        )
    )
    candidate_path = Path(second["profile_task_path"])
    candidate_path.joinpath("stable.txt").write_text("candidate", encoding="utf-8")
    with pytest.raises(ProfilePromotionError, match="verification failed"):
        _run(
            manager.promote_task_profile(
                user_id="alice",
                site_id="kimi",
                profile_id="kimi",
                task_id="candidate",
                binding=binding,
                verify=lambda _: False,
            )
        )

    stable_path = tmp_path / "profiles" / "alice" / "kimi" / "kimi" / "stable"
    assert stable_path.joinpath("stable.txt").read_text(encoding="utf-8") == "stable"


def test_prepare_task_profile_fails_closed_on_schema_mismatch(tmp_path: Path) -> None:
    manager = ProfileVaultManager(tmp_path / "profiles")
    stable_path = tmp_path / "profiles" / "alice" / "kimi" / "kimi" / "stable"
    stable_path.mkdir(parents=True)
    stable_path.joinpath(".payswitch-profile.json").write_text(
        '{"browser_engine":"cloakbrowser","schema_version":"pay-switch.profile.cloakbrowser.v1"}',
        encoding="utf-8",
    )

    with pytest.raises(ProfileCompatibilityError, match="browser_engine_mismatch"):
        _run(
            manager.prepare_task_profile(
                user_id="alice",
                site_id="kimi",
                profile_id="kimi",
                task_id="task_a",
                binding=_binding("playwright"),
            )
        )


def test_promotion_requires_lock_files_to_clear_before_swap(tmp_path: Path) -> None:
    manager = ProfileVaultManager(tmp_path / "profiles")
    binding = _binding()
    _run(
        manager.prepare_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_a",
            binding=binding,
        )
    )
    stable_path = tmp_path / "profiles" / "alice" / "kimi" / "kimi" / "stable"
    lock_path = stable_path / "SingletonLock"
    lock_path.write_text("locked", encoding="utf-8")

    with pytest.raises(ProfilePromotionError, match="lock files remain"):
        _run(
            manager.promote_task_profile(
                user_id="alice",
                site_id="kimi",
                profile_id="kimi",
                task_id="task_a",
                binding=binding,
                graceful_shutdown=lambda: None,
            )
        )

    second = _run(
        manager.prepare_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_b",
            binding=binding,
        )
    )
    (stable_path / "SingletonLock").write_text("locked", encoding="utf-8")
    Path(second["profile_task_path"]).joinpath("cookies.json").write_text("{}", encoding="utf-8")
    promoted = _run(
        manager.promote_task_profile(
            user_id="alice",
            site_id="kimi",
            profile_id="kimi",
            task_id="task_b",
            binding=binding,
            graceful_shutdown=lambda: None,
            force_shutdown=lambda: lock_path.unlink(missing_ok=True),
        )
    )

    assert promoted["profile_state"] == "stable_ready"
    assert not lock_path.exists()


@pytest.mark.asyncio
async def test_same_profile_cannot_promote_concurrently(tmp_path: Path) -> None:
    manager = ProfileVaultManager(tmp_path / "profiles")
    binding = _binding()
    await manager.prepare_task_profile(
        user_id="alice",
        site_id="kimi",
        profile_id="kimi",
        task_id="task_a",
        binding=binding,
    )
    root = tmp_path / "profiles" / "alice" / "kimi" / "kimi"
    lock = await manager._promotion_lock(root)
    await lock.acquire()
    try:
        with pytest.raises(ProfilePromotionError, match="already in progress"):
            await manager.promote_task_profile(
                user_id="alice",
                site_id="kimi",
                profile_id="kimi",
                task_id="task_a",
                binding=binding,
            )
    finally:
        lock.release()
