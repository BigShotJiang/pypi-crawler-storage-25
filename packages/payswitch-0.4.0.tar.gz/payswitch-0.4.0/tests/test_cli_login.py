from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from payswitch.cli import _verify_login_state


@pytest.mark.asyncio
async def test_verify_login_state_kimi_detects_chinese_prompt() -> None:
    page = MagicMock()
    page.url = "https://www.kimi.com/"

    def locator_side_effect(selector: str):
        locator = MagicMock()
        if selector == "text=登录以同步历史会话":
            locator.count = AsyncMock(return_value=1)
        else:
            locator.count = AsyncMock(return_value=0)
        return locator

    page.locator.side_effect = locator_side_effect

    assert await _verify_login_state(page, "kimi") is False


@pytest.mark.asyncio
async def test_verify_login_state_kimi_detects_english_prompt() -> None:
    page = MagicMock()
    page.url = "https://www.kimi.com/"

    def locator_side_effect(selector: str):
        locator = MagicMock()
        if selector == "text=Log in to sync chat history":
            locator.count = AsyncMock(return_value=1)
        else:
            locator.count = AsyncMock(return_value=0)
        return locator

    page.locator.side_effect = locator_side_effect

    assert await _verify_login_state(page, "kimi") is False


@pytest.mark.asyncio
async def test_verify_login_state_non_login_page_passes() -> None:
    page = MagicMock()
    page.url = "https://www.kimi.com/pay"
    page.locator.return_value.count = AsyncMock(return_value=0)

    assert await _verify_login_state(page, "kimi") is True
