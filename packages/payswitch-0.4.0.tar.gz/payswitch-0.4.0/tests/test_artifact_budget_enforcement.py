from __future__ import annotations

from pathlib import Path

from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore
from payswitch.security.cleanup import ArtifactBudgetEnforcementRunner


def test_enforce_budget_dry_run_prefers_expired_then_public_and_skips_sensitive(
    tmp_path: Path,
) -> None:
    store = ArtifactStore(tmp_path)
    expired_path = tmp_path / "evidence" / "recovery" / "expired.json"
    public_path = tmp_path / "evidence" / "preview" / "public.png"
    internal_path = tmp_path / "evidence" / "debug" / "internal.json"
    sensitive_path = tmp_path / "evidence" / "checkout" / "sensitive.png"
    store.write_json(
        expired_path,
        {"tx_id": "txn_expired_budget"},
        artifact_kind="recovery_checkpoint",
        sensitivity=ArtifactSensitivity.internal,
        retention_hours=0,
    )
    store.write_bytes(
        public_path,
        b"public-preview",
        artifact_kind="public_preview",
        sensitivity=ArtifactSensitivity.public,
        content_type="image/png",
    )
    store.write_json(
        internal_path,
        {"debug": True},
        artifact_kind="external_debug",
        sensitivity=ArtifactSensitivity.internal,
    )
    store.write_bytes(
        sensitive_path,
        b"sensitive-checkout",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
    )

    result = store.enforce_budget(
        budget_bytes=1,
        target_bytes=0,
        limit=2,
        dry_run=True,
    )

    assert result["triggered"] is True
    assert result["cleaned"] == 2
    assert result["items"][0]["path"] == str(expired_path)
    assert result["items"][0]["expired"] is True
    assert result["items"][1]["path"] == str(public_path)
    assert result["items"][1]["sensitivity"] == ArtifactSensitivity.public.value
    assert sensitive_path.exists()


def test_enforce_budget_deletes_until_target(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path)
    public_path = tmp_path / "evidence" / "preview" / "public.png"
    internal_path = tmp_path / "evidence" / "debug" / "internal.json"
    store.write_bytes(
        public_path,
        b"public-preview",
        artifact_kind="public_preview",
        sensitivity=ArtifactSensitivity.public,
        content_type="image/png",
    )
    store.write_json(
        internal_path,
        {"debug": True},
        artifact_kind="external_debug",
        sensitivity=ArtifactSensitivity.internal,
    )
    initial = store.inventory()
    candidates = store.list_budget_reclaim_candidates()
    expected_first = candidates[0]

    result = store.enforce_budget(
        budget_bytes=int(initial["total_bytes"]) - 1,
        target_bytes=int(initial["total_bytes"]) - int(expected_first["total_bytes"]),
    )

    assert result["triggered"] is True
    assert result["cleaned"] == 1
    assert result["within_target"] is True
    assert Path(result["items"][0]["path"]) == public_path
    assert not public_path.exists()
    assert not store.metadata_path(public_path).exists()
    assert internal_path.exists()


def test_artifact_budget_enforcement_runner_stops_after_idle_polls(
    tmp_path: Path,
) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "preview" / "public.png"
    store.write_bytes(
        artifact_path,
        b"public-preview",
        artifact_kind="public_preview",
        sensitivity=ArtifactSensitivity.public,
        content_type="image/png",
    )
    sleep_calls: list[float] = []
    runner = ArtifactBudgetEnforcementRunner(
        store,
        budget_bytes=1,
        target_ratio=0.9,
        poll_interval_seconds=0.0,
        batch_limit=10,
        max_idle_polls=2,
        sleep_fn=sleep_calls.append,
    )

    summary = runner.run_loop()

    assert summary["cycles"] == 3
    assert summary["idle_polls"] == 2
    assert summary["total_triggered"] == 1
    assert summary["total_cleaned"] == 1
    assert summary["total_deleted"] == 1
    assert summary["total_reclaimed_bytes"] >= 1
    assert sleep_calls == []
