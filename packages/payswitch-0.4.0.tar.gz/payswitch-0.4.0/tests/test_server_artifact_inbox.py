from __future__ import annotations

from fastapi.testclient import TestClient

from payswitch.models.config import PaySwitchConfig
from payswitch.server import app


def test_artifact_inbox_health_reports_recipient_identity(
    monkeypatch,
    tmp_path,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))

    with TestClient(app) as client:
        inbox = client.get("/api/artifact-inbox/health")
        health = client.get("/api/health")

        assert inbox.status_code == 200
        payload = inbox.json()
        assert payload["available"] is True
        assert payload["recipient_id"]
        assert payload["algorithm"]

        assert health.status_code == 200
        health_payload = health.json()
        assert health_payload["artifact_inbox"]["available"] is True
        assert health_payload["artifact_inbox"]["recipient_id"] == payload["recipient_id"]
