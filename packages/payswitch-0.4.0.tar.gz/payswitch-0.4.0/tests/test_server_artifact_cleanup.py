from __future__ import annotations

from fastapi.testclient import TestClient

from payswitch.models.config import PaySwitchConfig
from payswitch.server import app, build_artifact_cleanup_supervisor_from_env


def test_build_artifact_cleanup_supervisor_from_env_defaults_disabled(
    monkeypatch,
) -> None:
    monkeypatch.delenv("PAYSWITCH_ARTIFACT_CLEANUP_ENABLED", raising=False)

    supervisor = build_artifact_cleanup_supervisor_from_env()

    assert supervisor is None


def test_build_artifact_cleanup_supervisor_from_env_supports_enabled_config(
    monkeypatch,
    tmp_path,
) -> None:
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_CLEANUP_ENABLED", "1")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_CLEANUP_POLL_INTERVAL_SECONDS", "2.5")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_CLEANUP_BATCH_LIMIT", "4")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_CLEANUP_DRY_RUN", "true")

    supervisor = build_artifact_cleanup_supervisor_from_env(
        config_override=PaySwitchConfig(data_dir=tmp_path),
    )

    assert supervisor is not None
    snapshot = supervisor.snapshot()
    assert snapshot["enabled"] is True
    assert snapshot["running"] is False
    assert snapshot["poll_interval_seconds"] == 2.5
    assert snapshot["batch_limit"] == 4
    assert snapshot["dry_run"] is True


def test_artifact_cleanup_health_endpoint_reports_service_supervision(
    monkeypatch,
    tmp_path,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_CLEANUP_ENABLED", "1")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_CLEANUP_POLL_INTERVAL_SECONDS", "0.01")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_CLEANUP_BATCH_LIMIT", "3")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_CLEANUP_DRY_RUN", "1")

    with TestClient(app) as client:
        cleanup = client.get("/api/artifact-cleanup/health")
        health = client.get("/api/health")

        assert cleanup.status_code == 200
        payload = cleanup.json()
        assert payload["enabled"] is True
        assert payload["running"] is True
        assert payload["batch_limit"] == 3
        assert payload["dry_run"] is True

        assert health.status_code == 200
        health_payload = health.json()
        assert health_payload["artifact_cleanup"]["enabled"] is True
        assert health_payload["artifact_cleanup"]["running"] is True
        assert health_payload["artifact_cleanup"]["batch_limit"] == 3
