"""Pay-Switch 集成测试——PRD 7.3 四大场景验证。

覆盖范围：
  场景一：本地桌面 + 脚本模式（mock 浏览器）
  场景二：脚本模式 → Skyvern 智能模式回退
  场景三：Docker + noVNC（配置正确性验证）
  场景四：未知网站 + Skyvern 直接智能模式

所有涉及真实浏览器的操作均通过 unittest.mock 注入，
测试无需启动 Chromium、Xvfb 或 Docker。

运行方式：
    python -m pytest tests/test_integration.py -v
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import payswitch.engine.orchestrator  # noqa: F401
from payswitch.adapters.base import LoginRequiredError, ScriptExecutionError, ScriptStep
from payswitch.engine.watchdog import RecoveryDecision
from payswitch.experience import ExperienceStore
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import StepRecord, Transaction
from payswitch.models.types import (
    ComputerUseDriver,
    DisplayMode,
    ExecutionMode,
    PaymentMethod,
    StepCategory,
    StepRisk,
    TransactionStatus,
)

# ===========================================================================
# 共用 Fixtures 与辅助函数
# ===========================================================================


def _make_test_config(tmp_path: Path, **overrides) -> PaySwitchConfig:
    """创建测试用配置，data_dir 指向临时目录以避免污染用户数据。"""
    defaults: dict = {
        "max_per_transaction": 500.0,
        "daily_limit": 2000.0,
        "whitelist": [],
        "display_mode": DisplayMode.headed,
        "transaction_timeout": 60,
        "llm_api_key": "",
    }
    defaults.update(overrides)
    cfg = PaySwitchConfig(data_dir=tmp_path, **defaults)
    return cfg


def _make_mock_profile(platform: str = "deepseek") -> MagicMock:
    """创建模拟的 Profile 对象（代表已登录的浏览器 Profile）。"""
    profile = MagicMock()
    profile.platform = platform
    profile.status = "active"
    return profile


def _make_script_steps(count: int = 2) -> list[ScriptStep]:
    """创建若干个模拟脚本步骤，供适配器 execute_topup 返回。"""
    steps = []
    for i in range(count):
        steps.append(
            ScriptStep(
                description=f"脚本步骤 {i + 1}：模拟操作",
                action="click",
                selector=f"#btn-{i}",
            )
        )
    return steps


def _make_skyvern_steps(count: int = 2) -> list[StepRecord]:
    """创建若干个模拟 Skyvern 步骤记录，供 SkyvernEngine.execute_task 返回。"""
    now = datetime.now(UTC)
    steps = []
    for i in range(count):
        steps.append(
            StepRecord(
                step_index=i,
                description=f"Skyvern 步骤 {i + 1}：LLM 视觉操作",
                status="success",
                started_at=now,
                completed_at=now,
            )
        )
    return steps


def _make_mock_browser(current_url: str = "https://example.com") -> MagicMock:
    """创建带异步导航能力的浏览器 mock，适配访问预检流程。"""
    browser = MagicMock()
    browser.launch = AsyncMock()
    browser.close = AsyncMock()
    browser.navigate = AsyncMock()
    browser.get_current_url = AsyncMock(return_value=current_url)
    browser.page = MagicMock()
    browser.page.wait_for_load_state = AsyncMock()
    return browser


# ===========================================================================
# 场景一：本地桌面 + 脚本模式
# ===========================================================================


class TestScenario1_LocalDesktopScriptMode:
    """场景一：本地桌面 + 脚本模式（可 mock 浏览器）。

    模拟 payswitch spend 200 deepseek 的完整流程，验证：
    - guard 安全检查通过
    - 创建正式交易记录（pending → executing）
    - 脚本模式调用适配器 execute_topup
    - 检测器确认支付完成
    - 最终状态更新为 completed
    """

    @pytest.mark.asyncio
    async def test_完整脚本模式流程_状态变为completed(self, tmp_path: Path):
        """
        主流程：guard 通过 → 创建交易 → 脚本模式执行 → 状态 completed。
        通过 patch 注入 mock，避免启动真实浏览器。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        # ---- mock Profile 管理器：返回已有 Profile ----
        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        # ---- mock 浏览器控制器：异步启动/关闭不操作真实进程 ----
        mock_browser = _make_mock_browser()

        # ---- mock 适配器：execute_topup 成功返回脚本步骤 ----
        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = "https://platform.deepseek.com/top_up"
        mock_adapter.requires_login = False
        mock_adapter.requires_payment_gate = False
        script_steps = _make_script_steps(count=2)
        mock_adapter.execute_topup = AsyncMock(return_value=script_steps)

        # ---- mock 检测器流水线：脚本步骤执行完后返回"支付完成"检测结果 ----
        mock_detection_result = MagicMock()
        mock_detection_result.action_type = "completed"
        mock_detection_result.detector_name = "completion_detector"
        mock_detection_result.description = "检测到支付成功页面"
        mock_detection_result.data = {}

        # 让 scan 方法：前两次（每步后检测）返回 None，最后一次（最终检测）返回完成状态
        mock_detector_pipeline = MagicMock()
        mock_detector_pipeline.scan = AsyncMock(
            side_effect=[None, None, mock_detection_result]
        )

        # ---- mock DisplayManager：headed 模式，不启动 noVNC ----
        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock(return_value=True)

        with (
            # patch 在 orchestrator 模块内的 import 路径
            patch(
                "payswitch.engine.orchestrator.ProfileManager"
            ) as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch(
                "payswitch.engine.orchestrator.AdapterRegistry"
            ) as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_detector_pipeline,
            ),
        ):
            # 配置 ProfileManager mock
            mock_pm_instance = MagicMock()
            mock_pm_instance.get_profile.return_value = mock_profile
            mock_pm_instance.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm_instance

            # 配置 AdapterRegistry mock：返回 deepseek 适配器
            MockRegistry.get.return_value = mock_adapter

            # 引入被测模块（在 patch 上下文内）
            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(
                    amount=200.0,
                    payee="deepseek",
                    reason="充值 API 额度",
                )
            finally:
                orchestrator.close()

        # ---- 断言：最终状态为 completed ----
        assert tx.status == TransactionStatus.completed, (
            f"期望 completed，实际为 {tx.status}（error={tx.error}）"
        )
        # 验证执行模式为脚本模式
        assert tx.execution_mode == ExecutionMode.script, (
            f"期望 script 模式，实际为 {tx.execution_mode}"
        )
        # 验证交易已完成（有完成时间）
        assert tx.completed_at is not None, "completed_at 不应为 None"
        # 验证 payee 和 amount
        assert tx.payee == "deepseek"
        assert tx.amount == 200.0

    @pytest.mark.asyncio
    async def test_完成交易时会清理recovery状态(self, tmp_path: Path):
        """
        交易结束在终态时应清理内存中的 recovery watchdog 状态，防止同 tx_id
        的历史失败上下文污染下一次重试决策。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = "https://platform.deepseek.com/top_up"
        mock_adapter.requires_login = False
        mock_adapter.requires_payment_gate = False
        mock_adapter.execute_topup = AsyncMock(return_value=_make_script_steps(count=2))

        mock_detection_result = MagicMock()
        mock_detection_result.action_type = "completed"
        mock_detection_result.detector_name = "completion_detector"
        mock_detection_result.description = "检测到支付成功页面"
        mock_detection_result.data = {}

        mock_detector_pipeline = MagicMock()
        mock_detector_pipeline.scan = AsyncMock(
            side_effect=[None, None, mock_detection_result]
        )

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock(return_value=True)

        mock_watchdog = MagicMock()

        with (
            patch(
                "payswitch.engine.orchestrator.ProfileManager"
            ) as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch(
                "payswitch.engine.orchestrator.AdapterRegistry"
            ) as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_detector_pipeline,
            ),
            patch("payswitch.engine.orchestrator.RecoveryWatchdog", return_value=mock_watchdog),
        ):
            mock_pm_instance = MagicMock()
            mock_pm_instance.get_profile.return_value = mock_profile
            mock_pm_instance.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm_instance
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(amount=200.0, payee="deepseek")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.completed
        mock_watchdog.clear.assert_called_once_with(tx.tx_id)

    @pytest.mark.asyncio
    async def test_确认后清理recovery状态(self, tmp_path: Path):
        """
        交易从 human_action_required 转为 confirm 完成时应清理 recovery state。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("jimeng")
        mock_profile_dir = tmp_path / "profiles" / "jimeng"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        payment_url = "https://jimeng.jianying.com/pay"
        mock_browser = _make_mock_browser(current_url=payment_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "JimengAdapter"
        mock_adapter.top_up_url = "https://jimeng.jianying.com/ai-tool/home"
        mock_adapter.requires_login = False
        mock_adapter.requires_payment_gate = True
        mock_adapter.allow_detector_completion = False
        mock_adapter.execute_topup = AsyncMock(
            return_value=[
                ScriptStep(
                    description="Need authorization",
                    action="click",
                    category=StepCategory.final_authorization,
                    risk=StepRisk.human_required,
                    requires_human_authorization=True,
                )
            ]
        )

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_watchdog = MagicMock()

        with (
            patch(
                "payswitch.engine.orchestrator.ProfileManager"
            ) as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch(
                "payswitch.engine.orchestrator.AdapterRegistry"
            ) as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch("payswitch.engine.orchestrator.RecoveryWatchdog", return_value=mock_watchdog),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=50.0, payee="jimeng")
                assert tx.status == TransactionStatus.human_action_required

                tx = await orchestrator.confirm(tx.tx_id)
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.completed
        mock_watchdog.clear.assert_called_once_with(tx.tx_id)

    @pytest.mark.asyncio
    async def test_guard_check_拦截超额交易(self, tmp_path: Path):
        """
        当金额超出单笔限额时，guard 应拒绝并返回 failed 状态，
        不会创建浏览器会话。
        """
        # 设置单笔限额为 100 元，支付 200 元应被拦截
        config = _make_test_config(tmp_path, max_per_transaction=100.0)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager"),
            patch("payswitch.engine.orchestrator.BrowserController") as MockBrowser,
            patch("payswitch.engine.orchestrator.AdapterRegistry"),
            patch("payswitch.engine.orchestrator.DisplayManager"),
            patch("payswitch.engine.orchestrator.DetectorPipeline"),
        ):
            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(amount=200.0, payee="deepseek")
            finally:
                orchestrator.close()

        # guard 拒绝：状态为 failed
        assert tx.status == TransactionStatus.failed
        assert tx.error is not None
        # 浏览器不应被启动
        MockBrowser.return_value.launch.assert_not_called()

    @pytest.mark.asyncio
    async def test_profile不存在返回failed(self, tmp_path: Path):
        """
        当指定平台的 Profile 不存在时（用户从未登录），
        orchestrator 应返回 failed 状态而非崩溃。
        """
        config = _make_test_config(tmp_path)

        mock_browser = _make_mock_browser()

        with (
            patch(
                "payswitch.engine.orchestrator.ProfileManager"
            ) as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch("payswitch.engine.orchestrator.DisplayManager"),
            patch("payswitch.engine.orchestrator.DetectorPipeline"),
        ):
            # Profile 管理器：找不到该平台的 Profile
            mock_pm_instance = MagicMock()
            mock_pm_instance.get_profile.return_value = None  # 无 Profile
            MockProfileManager.return_value = mock_pm_instance

            mock_adapter = MagicMock()
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(amount=200.0, payee="deepseek")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.failed
        assert tx.error is not None
        assert "Profile" in tx.error or "profile" in tx.error or "登录" in tx.error

    @pytest.mark.asyncio
    async def test_访问预检检测未登录后等待人工登录超时(self, tmp_path: Path):
        """未登录时应等待人工登录；超时后不能继续执行 adapter。"""
        config = _make_test_config(tmp_path)

        mock_profile = _make_mock_profile("kimi")
        mock_profile_dir = tmp_path / "profiles" / "kimi"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "KimiAdapter"
        mock_adapter.top_up_url = "https://www.kimi.com/recharge"
        mock_adapter.login_url = "https://www.kimi.com"
        mock_adapter.requires_login = True
        mock_adapter.ensure_logged_in = AsyncMock(
            side_effect=LoginRequiredError(
                "检测到 Kimi 未登录，请先执行 'payswitch login kimi'。"
            )
        )
        mock_adapter.execute_topup = AsyncMock(return_value=[])

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock(return_value=False)

        with (
            patch(
                "payswitch.engine.orchestrator.ProfileManager"
            ) as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch("payswitch.engine.orchestrator.DetectorPipeline"),
        ):
            mock_pm_instance = MagicMock()
            mock_pm_instance.get_profile.return_value = mock_profile
            mock_pm_instance.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm_instance
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(amount=10.0, payee="kimi")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.timeout
        assert tx.error is not None
        assert "Login preflight timed out" in tx.error
        assert tx.human_action is not None
        assert "登录" in tx.human_action.guidance
        mock_browser.navigate.assert_awaited_once_with("https://www.kimi.com/recharge")
        mock_adapter.ensure_logged_in.assert_awaited_once()
        mock_adapter.execute_topup.assert_not_called()
        mock_display.notify_human.assert_awaited_once()
        mock_display.wait_for_completion.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_脚本模式调用adapter_execute_topup(self, tmp_path: Path):
        """
        验证 orchestrator 在脚本模式下确实调用了适配器的 execute_topup，
        且传入了正确的 amount 参数。
        """
        config = _make_test_config(tmp_path)

        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = "https://platform.deepseek.com/top_up"
        mock_adapter.requires_login = False
        mock_adapter.execute_topup = AsyncMock(return_value=[])

        # 最终检测返回 completed
        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "test"
        mock_detection.description = "完成"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}

        with (
            patch(
                "payswitch.engine.orchestrator.ProfileManager"
            ) as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch(
                "payswitch.engine.orchestrator.AdapterRegistry"
            ) as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                await orchestrator.spend(amount=150.0, payee="deepseek")
            finally:
                orchestrator.close()

        # 确认 execute_topup 被调用，且 amount 参数正确
        mock_adapter.execute_topup.assert_called_once()
        call_kwargs = mock_adapter.execute_topup.call_args
        # 第一个位置参数是 page，第二个是 amount
        assert call_kwargs.kwargs.get("amount") == 150.0 or (
            len(call_kwargs.args) >= 2 and call_kwargs.args[1] == 150.0
        ), f"execute_topup 调用参数不符合预期：{call_kwargs}"

    @pytest.mark.asyncio
    async def test_脚本模式转发recipe_waypoint_telemetry(self, tmp_path: Path):
        config = _make_test_config(tmp_path)

        mock_profile = _make_mock_profile("kimi")
        mock_profile_dir = tmp_path / "profiles" / "kimi"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)
        mock_browser = _make_mock_browser(current_url="https://www.kimi.com/")

        async def execute_topup(**_: object):
            if mock_adapter.telemetry_callback is not None:
                await mock_adapter.telemetry_callback(
                    {
                        "kind": "waypoint.succeeded",
                        "summary": "选择月付套餐",
                        "message": "recipe waypoint succeeded",
                        "path": ["Pay-Switch", "Recipe Runner", "kimi"],
                        "risk": "medium",
                        "target": "kimi",
                        "extra": {
                            "waypoint_id": "select_monthly_plan",
                            "recipe_id": "kimi.membership_monthly_qr",
                            "recipe_version": "1.0.0",
                        },
                    }
                )
            return []

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "KimiAdapter"
        mock_adapter.display_name = "Kimi (Moonshot)"
        mock_adapter.name = "kimi"
        mock_adapter.top_up_url = "https://www.kimi.com/membership/pricing?from=pay_switch"
        mock_adapter.requires_login = False
        mock_adapter.allow_detector_completion = True
        mock_adapter.execute_topup = AsyncMock(side_effect=execute_topup)

        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "test"
        mock_detection.description = "完成"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": None}

        events: list[dict[str, object]] = []

        async def progress_sink(payload: dict[str, object]) -> None:
            events.append(payload)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config, progress_sink=progress_sink)
            try:
                await orchestrator.spend(amount=49.0, payee="kimi")
            finally:
                orchestrator.close()

        waypoint_events = [event for event in events if event.get("kind") == "waypoint.succeeded"]
        assert len(waypoint_events) == 1
        assert waypoint_events[0]["extra"]["waypoint_id"] == "select_monthly_plan"
        assert waypoint_events[0]["extra"]["recipe_id"] == "kimi.membership_monthly_qr"


# ===========================================================================
# 场景二：脚本模式 → Skyvern 回退
# ===========================================================================


class TestScenario2_ScriptToSkyvernFallback:
    """场景二：脚本模式失败后自动回退到 Skyvern 智能模式。

    验证：
    - 适配器 execute_topup 抛出 ScriptExecutionError
    - orchestrator 捕获异常并自动启动智能模式
    - SkyvernEngine.execute_task 被调用并成功完成
    - 交易记录中包含脚本失败步骤和 Skyvern 步骤
    """

    @pytest.mark.asyncio
    async def test_脚本失败后external_driver进入computer_use接力(self, tmp_path: Path):
        """
        默认 external driver 下，固定适配器失败后应先进入 Computer Use 接力态，
        而不是直接升级为人类完全接管。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.external
        )

        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://platform.deepseek.com/top_up"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError("页面结构变更")
        )

        mock_skyvern = MagicMock()
        mock_skyvern.execute_task = AsyncMock()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(amount=200.0, payee="deepseek")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.execution_mode == ExecutionMode.computer_use
        assert tx.human_action is not None
        assert tx.human_action.action_type == "external_computer_use"
        mock_browser.navigate.assert_any_await(target_url)
        mock_display.notify_human.assert_awaited_once()
        mock_display.wait_for_completion.assert_not_called()
        mock_skyvern.execute_task.assert_not_called()

    @pytest.mark.asyncio
    async def test_adapter_can_disable_computer_use_after_script_failure(self, tmp_path: Path):
        """High-risk adapters should hand off instead of letting CU guess checkout."""
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("jimeng")
        mock_profile_dir = tmp_path / "profiles" / "jimeng"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://jimeng.jianying.com/ai-tool/home"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "JimengAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.allow_smart_fallback = False
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError("points checkout button not found")
        )

        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=10.0, payee="jimeng")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.execution_mode == ExecutionMode.human_takeover
        assert tx.human_action is not None
        assert tx.human_action.action_type == "takeover"
        mock_skyvern.execute_task.assert_not_called()
        assert any("禁用 Computer Use" in step.description for step in tx.steps)

    @pytest.mark.asyncio
    async def test_script_failure_classified_as_login_required_uses_login_gate(
        self, tmp_path: Path
    ):
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.external
        )

        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://platform.deepseek.com/top_up"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError(
                "session expired, login required",
                failure_context={"login_required": True},
            )
        )

        mock_skyvern = MagicMock()
        mock_skyvern.execute_task = AsyncMock()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=88.0, payee="deepseek")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.human_action is not None
        assert tx.human_action.action_type == "login"
        assert tx.human_action.details["classification"] == "login_required"
        mock_skyvern.execute_task.assert_not_called()
        assert any("login_required" in step.description for step in tx.steps)

    @pytest.mark.asyncio
    async def test_script_failure_classified_as_hard_failure_skips_computer_use(
        self, tmp_path: Path
    ):
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("stripe")
        mock_profile_dir = tmp_path / "profiles" / "stripe"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://checkout.stripe.com/pay"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "StripeAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError(
                "Stripe SDK 未安装",
                failure_context={"is_retryable": False, "failure_type": "configuration"},
            )
        )

        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=20.0, payee="stripe")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.execution_mode == ExecutionMode.human_takeover
        assert tx.human_action is not None
        assert tx.human_action.action_type == "recovery"
        assert tx.human_action.details["classification"] == "hard_failure"
        mock_skyvern.execute_task.assert_not_called()
        assert any("hard_failure" in step.description for step in tx.steps)

    @pytest.mark.asyncio
    async def test_script_synchronous_policy_checkpoint_routes_to_human_gate(
        self, tmp_path: Path
    ):
        config = _make_test_config(
            tmp_path,
            computer_use_driver=ComputerUseDriver.hybrid,
            llm_api_key="encoded-test-key",
        )

        mock_profile = _make_mock_profile("qwen")
        mock_profile_dir = tmp_path / "profiles" / "qwen"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://tongyi.aliyun.com/recharge"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "QwenAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = True
        mock_adapter.allow_smart_fallback = True
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError(
                "policy checkpoint blocked confirm_qwen_checkout: missing visible payment markers",
                failure_context={
                    "requires_human_gate": True,
                    "synchronous_policy_checkpoint": True,
                    "waypoint_id": "confirm_qwen_checkout",
                    "waypoint_category": "final_authorization",
                    "waypoint_risk": "high",
                    "action_type": "confirm",
                },
            )
        )

        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=20.0, payee="qwen")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.execution_mode == ExecutionMode.human_takeover
        assert tx.human_action is not None
        assert tx.human_action.action_type == "recovery"
        assert tx.human_action.details["classification"] == "sensitive_action"
        assert tx.human_action.details["failure_context"]["waypoint_id"] == "confirm_qwen_checkout"
        mock_skyvern.execute_task.assert_not_called()
        assert any("sensitive_action" in step.description for step in tx.steps)

    @pytest.mark.asyncio
    async def test_hybrid_computer_use_timeout_respects_recovery_budget(
        self, tmp_path: Path
    ):
        config = _make_test_config(
            tmp_path,
            computer_use_driver=ComputerUseDriver.hybrid,
            recovery_max_computer_use_wall_time_seconds=1,
        )

        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://platform.deepseek.com/top_up"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError("页面结构变更")
        )

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        class _SlowExplorer:
            def __init__(self, _config):
                self._config = _config

            def is_available(self):
                return True

            async def explore_checkout(self, **_kwargs):
                await asyncio.sleep(1.2)
                return []

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.computer_use.ComputerUseExplorer",
                _SlowExplorer,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=20.0, payee="deepseek")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.execution_mode == ExecutionMode.computer_use
        assert tx.human_action is not None
        assert tx.human_action.action_type == "external_computer_use"
        assert "wall_time>1s" in (tx.error or "")
        assert tx.human_action.details["budget"]["max_wall_time_seconds"] == 1
        assert any("wall_time>1s" in step.description for step in tx.steps)

    @pytest.mark.asyncio
    async def test_hybrid_computer_use_verification_login_failure_routes_to_login_gate(
        self, tmp_path: Path
    ):
        config = _make_test_config(
            tmp_path,
            computer_use_driver=ComputerUseDriver.hybrid,
            llm_api_key="encoded-test-key",
        )

        mock_profile = _make_mock_profile("kimi")
        mock_profile_dir = tmp_path / "profiles" / "kimi"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://www.kimi.com/membership/pricing"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "KimiAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.allow_smart_fallback = True
        mock_adapter.execute_topup = AsyncMock(side_effect=ScriptExecutionError("页面结构变更"))

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        from payswitch.browser.computer_use import RecoveryStateVerificationError

        class _Explorer:
            def __init__(self, _config):
                self._config = _config

            def is_available(self):
                return True

            async def explore_checkout(self, **_kwargs):
                raise RecoveryStateVerificationError(
                    "recovery verification blocked action: login required",
                    failure_context={
                        "failure_type": "computer_use_recovery",
                        "login_required": True,
                        "current_url": "https://www.kimi.com/login",
                        "verification_stage": "pre_action",
                    },
                )

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch("payswitch.engine.orchestrator.BrowserController", return_value=mock_browser),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch("payswitch.engine.orchestrator.DisplayManager", return_value=mock_display),
            patch("payswitch.engine.orchestrator.DetectorPipeline", return_value=mock_pipeline),
            patch("payswitch.browser.computer_use.ComputerUseExplorer", _Explorer),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config, wait_for_human_completion=False)
            try:
                tx = await orchestrator.spend(amount=30.0, payee="kimi")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.human_action is not None
        assert tx.human_action.action_type == "login"
        assert tx.human_action.details["classification"] == "login_required"
        assert tx.execution_mode == ExecutionMode.smart

    @pytest.mark.asyncio
    async def test_hybrid_computer_use_verification_sensitive_failure_routes_to_recovery_gate(
        self, tmp_path: Path
    ):
        config = _make_test_config(
            tmp_path,
            computer_use_driver=ComputerUseDriver.hybrid,
            llm_api_key="encoded-test-key",
        )

        mock_profile = _make_mock_profile("kimi")
        mock_profile_dir = tmp_path / "profiles" / "kimi"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://www.kimi.com/membership/pricing"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "KimiAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.allow_smart_fallback = True
        mock_adapter.execute_topup = AsyncMock(side_effect=ScriptExecutionError("页面结构变更"))

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        from payswitch.browser.computer_use import RecoveryStateVerificationError

        class _Explorer:
            def __init__(self, _config):
                self._config = _config

            def is_available(self):
                return True

            async def explore_checkout(self, **_kwargs):
                raise RecoveryStateVerificationError(
                    "recovery verification blocked high-risk payment boundary action",
                    failure_context={
                        "failure_type": "computer_use_recovery",
                        "requires_human_gate": True,
                        "synchronous_policy_checkpoint": True,
                        "waypoint_category": "final_authorization",
                        "waypoint_risk": "high",
                        "action_type": "confirm",
                        "verification_stage": "pre_action",
                    },
                )

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch("payswitch.engine.orchestrator.BrowserController", return_value=mock_browser),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch("payswitch.engine.orchestrator.DisplayManager", return_value=mock_display),
            patch("payswitch.engine.orchestrator.DetectorPipeline", return_value=mock_pipeline),
            patch("payswitch.browser.computer_use.ComputerUseExplorer", _Explorer),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config, wait_for_human_completion=False)
            try:
                tx = await orchestrator.spend(amount=30.0, payee="kimi")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.human_action is not None
        assert tx.human_action.action_type == "recovery"
        assert tx.human_action.details["classification"] == "sensitive_action"
        assert tx.human_action.details["execution_mode"] == ExecutionMode.smart.value

    @pytest.mark.asyncio
    async def test_stale_script_recovery_resynchronizes_context_before_computer_use(
        self, tmp_path: Path
    ):
        config = _make_test_config(
            tmp_path,
            computer_use_driver=ComputerUseDriver.hybrid,
            llm_api_key="encoded-test-key",
        )

        mock_profile = _make_mock_profile("kimi")
        mock_profile_dir = tmp_path / "profiles" / "kimi"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://www.kimi.com/membership/pricing"
        mock_browser = _make_mock_browser(current_url=target_url)

        async def _evaluate(script: str):
            if "document.body?.innerText" in script:
                return "Kimi 会员\n立即开通\n支付宝"
            return {
                "title": "Kimi Membership",
                "headings": ["会员中心"],
                "buttons": ["立即开通", "支付宝"],
                "forms": ["membership-form"],
            }

        mock_browser.page.url = target_url
        mock_browser.page.evaluate = AsyncMock(side_effect=_evaluate)
        mock_browser.screenshot = AsyncMock()

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "KimiAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.allow_smart_fallback = True
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError(
                "membership entry moved",
                failure_context={
                    "waypoint_id": "find_membership_entry",
                    "recipe_id": "kimi.membership_alipay_qr",
                },
            )
        )

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(
            return_value=MagicMock(action_type="completed", description="检测到支付完成页面")
        )

        captured_kwargs: dict[str, object] = {}

        class _Explorer:
            def __init__(self, _config):
                self._config = _config

            def is_available(self):
                return True

            async def explore_checkout(self, **kwargs):
                captured_kwargs.update(kwargs)
                return []

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch("payswitch.engine.orchestrator.BrowserController", return_value=mock_browser),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch("payswitch.engine.orchestrator.DisplayManager", return_value=mock_display),
            patch("payswitch.engine.orchestrator.DetectorPipeline", return_value=mock_pipeline),
            patch("payswitch.browser.computer_use.ComputerUseExplorer", _Explorer),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config, wait_for_human_completion=False)
            orchestrator._recovery_watchdog.register_script_failure = MagicMock(  # type: ignore[method-assign]
                return_value=RecoveryDecision(
                    allow_recovery=True,
                    requires_human_gate=False,
                    requires_resync=True,
                    register_candidate_patch=True,
                    attempts_remaining=1,
                    reason="failure classified as retryable_drift",
                    is_high_risk=False,
                    stale_buffer_discarded=True,
                    classification="retryable_drift",
                    recommended_action="computer_use_recovery",
                )
            )
            try:
                tx = await orchestrator.spend(amount=30.0, payee="kimi")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.completed
        recovery_context = captured_kwargs["recovery_context"]
        assert isinstance(recovery_context, dict)
        assert recovery_context["waypoint_id"] == "find_membership_entry"
        assert recovery_context["resync_snapshot"]["current_url"] == target_url
        assert recovery_context["resync_snapshot"]["visible_text_summary"].startswith("Kimi 会员")
        assert recovery_context["resync_snapshot"]["dom_summary"]["title"] == "Kimi Membership"
        assert any("恢复上下文已重同步" in step.description for step in tx.steps)

    @pytest.mark.asyncio
    async def test_successful_computer_use_recovery_marks_patch_shadow_run(
        self, tmp_path: Path
    ):
        config = _make_test_config(
            tmp_path,
            computer_use_driver=ComputerUseDriver.internal,
            llm_api_key="encoded-test-key",
        )

        mock_profile = _make_mock_profile("kimi")
        mock_profile_dir = tmp_path / "profiles" / "kimi"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://www.kimi.com/membership/pricing?from=pay_switch"
        mock_browser = _make_mock_browser(current_url=target_url)
        mock_browser.page.url = target_url
        mock_browser.page.evaluate = AsyncMock(
            return_value="Pay with Alipay / WeChat\nAgree to Kimi's Agreements"
        )

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "KimiAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.allow_smart_fallback = True
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError(
                "waypoint assertion failed",
                failure_context={
                    "recipe_id": "kimi.membership_monthly_qr",
                    "recipe_version": "1.0.0",
                    "waypoint_id": "select_monthly_plan",
                    "failure_reason": "waypoint assertion failed",
                    "failed_assertion": {
                        "any_texts": ["Pay with Alipay / WeChat"],
                        "url_contains": [],
                        "any_selectors": [],
                    },
                },
            )
        )

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        qr_detection = MagicMock()
        qr_detection.action_type = "scan_qr"
        qr_detection.detector_name = "QRCodeDetector"
        qr_detection.description = "请使用支付宝扫码完成支付"
        qr_detection.data = {"qr_count": 1}

        qr_detector = MagicMock()
        qr_detector.name = "QRCodeDetector"
        qr_detector.requires_human.return_value = True
        qr_detector.detect_completion = AsyncMock(return_value=False)

        mock_pipeline = MagicMock()
        mock_pipeline._detectors = [qr_detector]
        mock_pipeline.scan = AsyncMock(return_value=qr_detection)

        class _Explorer:
            def __init__(self, _config):
                self._config = _config

            def is_available(self):
                return True

            async def explore_checkout(self, **_kwargs):
                return _make_skyvern_steps(count=1)

        from unittest.mock import patch as mock_patch

        with (
            mock_patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            mock_patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            mock_patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            mock_patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            mock_patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            mock_patch(
                "payswitch.browser.computer_use.ComputerUseExplorer",
                _Explorer,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=49.0, payee="kimi")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert any("recipe patch 候选" in step.description for step in tx.steps)

        store = ExperienceStore(tmp_path / "experience" / "recipes.db")
        patches = store.list_patches(
            platform="kimi",
            flow="membership_monthly_qr",
            source="script_recovery",
        )
        assert len(patches) == 1
        patch_record = patches[0]
        assert patch_record["state"] == "shadow_run"
        assert patch_record["shadow_run_success"] is True
        assert patch_record["metadata"]["recovery_outcome"] == "scan_qr"
        assert patch_record["metadata"]["recovery_waypoint_id"] == "select_monthly_plan"
        assert patch_record["metadata"]["shadow_run_tx_id"] == tx.tx_id
        assert patch_record["metadata"]["shadow_run_outcome"] == "scan_qr"
        assert Path(patch_record["metadata"]["recovery_artifact_path"]).exists()
        assert "请使用支付宝扫码完成支付" in patch_record["recipe"].waypoints[3].expected.any_texts
        assert target_url in patch_record["recipe"].start_urls
        improvements = store.list_recovery_improvements(platform="kimi")
        assert len(improvements) == 1
        assert improvements[0]["patch_id"] == patch_record["id"]
        assert improvements[0]["tx_id"] == tx.tx_id
        assert improvements[0]["summary"]["outcome"] == "scan_qr"

    @pytest.mark.asyncio
    async def test_adapter_requires_payment_gate_before_detector_completion(
        self, tmp_path: Path
    ):
        """A risky adapter cannot complete from a loose detector on a normal page."""
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("jimeng")
        mock_profile_dir = tmp_path / "profiles" / "jimeng"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        target_url = "https://jimeng.jianying.com/ai-tool/home"
        mock_browser = _make_mock_browser(current_url=target_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "JimengAdapter"
        mock_adapter.top_up_url = target_url
        mock_adapter.requires_login = False
        mock_adapter.allow_smart_fallback = False
        mock_adapter.allow_detector_completion = False
        mock_adapter.requires_payment_gate = True
        mock_adapter.execute_topup = AsyncMock(
            return_value=[
                ScriptStep(
                    description="Navigate to Jimeng AI",
                    action="navigate",
                    url=target_url,
                )
            ]
        )

        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "completion_detector"
        mock_detection.description = "Loose success-like home page copy"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_skyvern = MagicMock()
        mock_skyvern.execute_task = AsyncMock()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=50.0, payee="jimeng")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.execution_mode == ExecutionMode.human_takeover
        mock_skyvern.execute_task.assert_not_called()
        assert not any(step.status == "completed" for step in tx.steps)

    @pytest.mark.asyncio
    async def test_adapter_payment_gate_returns_human_action(self, tmp_path: Path):
        """A real payment gate is a user handoff, not an execution failure."""
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("jimeng")
        mock_profile_dir = tmp_path / "profiles" / "jimeng"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        payment_url = "https://jimeng.jianying.com/pay"
        mock_browser = _make_mock_browser(current_url=payment_url)

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "JimengAdapter"
        mock_adapter.top_up_url = "https://jimeng.jianying.com/ai-tool/home"
        mock_adapter.requires_login = False
        mock_adapter.allow_smart_fallback = False
        mock_adapter.allow_detector_completion = False
        mock_adapter.requires_payment_gate = True
        mock_adapter.execute_topup = AsyncMock(
            return_value=[
                ScriptStep(
                    description="Detected Jimeng QR/payment gate",
                    action="detect_payment",
                    category=StepCategory.final_authorization,
                    risk=StepRisk.human_required,
                    requires_human_authorization=True,
                )
            ]
        )

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        mock_skyvern = MagicMock()
        mock_skyvern.execute_task = AsyncMock()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed", "url": "http://vnc"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(
                config,
                wait_for_human_completion=False,
            )
            try:
                tx = await orchestrator.spend(amount=50.0, payee="jimeng")
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.execution_mode == ExecutionMode.script
        assert tx.human_action is not None
        assert tx.human_action.action_type == "payment_authorization"
        assert tx.human_action.details["current_url"] == payment_url
        mock_display.notify_human.assert_awaited_once()
        mock_skyvern.execute_task.assert_not_called()

    @pytest.mark.asyncio
    async def test_脚本失败后回退到skyvern_最终completed(self, tmp_path: Path):
        """
        当脚本模式抛出 ScriptExecutionError 时，
        orchestrator 应自动切换到 Skyvern 智能模式完成任务。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        # ---- 适配器：execute_topup 抛出 ScriptExecutionError ----
        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = "https://platform.deepseek.com/top_up"
        mock_adapter.requires_login = False
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError("页面结构变更，找不到充值金额输入框")
        )

        # ---- Skyvern：成功完成任务 ----
        skyvern_steps = _make_skyvern_steps(count=3)
        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock(return_value=skyvern_steps)

        # ---- 检测器：最终检测报告支付完成 ----
        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "completion_detector"
        mock_detection.description = "支付成功"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        # 脚本失败前检测 None，最终检测报告 completed
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}

        with (
            patch(
                "payswitch.engine.orchestrator.ProfileManager"
            ) as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch(
                "payswitch.engine.orchestrator.AdapterRegistry"
            ) as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            # patch SkyvernEngine：orchestrator 在方法体内延迟 import，
            # 需要 patch 原始模块中的类，使其在 import 时得到 mock
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(amount=200.0, payee="deepseek")
            finally:
                orchestrator.close()

        # ---- 断言 ----
        # 1. 最终状态为 completed
        assert tx.status == TransactionStatus.completed, (
            f"期望 completed，实际 {tx.status}（error={tx.error}）"
        )

        # 2. 执行模式最终为 smart（回退后被更新）
        assert tx.execution_mode == ExecutionMode.smart, (
            f"期望 smart 模式，实际 {tx.execution_mode}"
        )

        # 3. 交易步骤中应包含脚本失败的记录
        step_descriptions = [s.description for s in tx.steps]
        has_fallback_step = any(
            "失败" in desc or "回退" in desc or "ScriptExecutionError" in desc
            for desc in step_descriptions
        )
        assert has_fallback_step, (
            f"交易步骤中未找到脚本失败/回退记录。实际步骤：{step_descriptions}"
        )

    @pytest.mark.asyncio
    async def test_脚本失败后skyvern被调用(self, tmp_path: Path):
        """
        验证脚本模式失败时，SkyvernEngine.execute_task 确实被调用。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = "https://platform.deepseek.com/top_up"
        mock_adapter.requires_login = False
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError("脚本执行失败")
        )

        skyvern_steps = _make_skyvern_steps(count=2)
        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock(return_value=skyvern_steps)

        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "test"
        mock_detection.description = "完成"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                await orchestrator.spend(amount=200.0, payee="deepseek")
            finally:
                orchestrator.close()

        # 验证 SkyvernEngine.execute_task 被调用了一次
        mock_skyvern.execute_task.assert_called_once()

    @pytest.mark.asyncio
    async def test_脚本回退skyvern_步骤记录包含两个阶段(self, tmp_path: Path):
        """
        验证交易步骤记录中同时包含：
        - 脚本模式启动步骤（来自 _execute_script_mode）
        - 脚本失败步骤（ScriptExecutionError 被捕获后追加）
        - Skyvern 智能模式步骤
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("deepseek")
        mock_profile_dir = tmp_path / "profiles" / "deepseek"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        mock_adapter = MagicMock()
        mock_adapter.__class__.__name__ = "DeepSeekAdapter"
        mock_adapter.top_up_url = "https://platform.deepseek.com/top_up"
        mock_adapter.requires_login = False
        mock_adapter.execute_topup = AsyncMock(
            side_effect=ScriptExecutionError("DOM 结构变更")
        )

        # Skyvern 返回 2 个步骤
        skyvern_steps = _make_skyvern_steps(count=2)
        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock(return_value=skyvern_steps)

        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "test"
        mock_detection.description = "完成"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm
            MockRegistry.get.return_value = mock_adapter

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(amount=200.0, payee="deepseek")
            finally:
                orchestrator.close()

        # 步骤总数：1（脚本启动）+ 1（脚本失败/回退）+ 1（Skyvern 启动）+ 2（Skyvern 步骤）= 5
        # 实际可能因最终检测路径不同而有差异，但至少应有 3 步
        step_descriptions = [s.description for s in tx.steps]
        assert len(tx.steps) >= 3, (
            f"步骤数量不足，期望至少 3 步，实际 {len(tx.steps)} 步：{step_descriptions}"
        )

        # 必须包含脚本失败的步骤
        descriptions = [s.description for s in tx.steps]
        has_script_failure = any(
            "失败" in d or "回退" in d or "ScriptExecutionError" in d
            for d in descriptions
        )
        assert has_script_failure, f"步骤中缺少脚本失败记录，实际步骤：{descriptions}"

        # 必须包含 Skyvern 智能模式的步骤
        has_smart_step = any(
            "智能模式" in d or "Skyvern" in d or "SkyvernEngine" in d
            for d in descriptions
        )
        assert has_smart_step, f"步骤中缺少 Skyvern 智能模式记录，实际步骤：{descriptions}"


# ===========================================================================
# 场景三：Docker + noVNC（配置正确性验证）
# ===========================================================================


@pytest.mark.docker
class TestScenario3_DockerNoVNC:
    """场景三：Docker + noVNC 配置正确性验证。

    不实际启动 Docker，仅验证：
    - 必要文件存在（Dockerfile、entrypoint.sh、docker-compose.yml）
    - NoVNCManager 在 Windows 环境下行为正确
    - DisplayManager 在 novnc 模式下能返回正确的配置信息
    """

    def test_docker_必要文件存在(self):
        """Dockerfile、entrypoint.sh、docker-compose.yml 应存在于 docker/ 目录下。"""
        # 项目根目录（tests/ 的上一级）
        project_root = Path(__file__).parent.parent
        docker_dir = project_root / "docker"

        dockerfile = docker_dir / "Dockerfile"
        entrypoint = docker_dir / "entrypoint.sh"
        compose = docker_dir / "docker-compose.yml"

        assert docker_dir.exists(), f"docker/ 目录不存在：{docker_dir}"
        assert dockerfile.exists(), f"Dockerfile 不存在：{dockerfile}"
        assert entrypoint.exists(), f"entrypoint.sh 不存在：{entrypoint}"
        assert compose.exists(), f"docker-compose.yml 不存在：{compose}"

    def test_novnc_manager_在Windows上返回不支持提示(self):
        """
        NoVNCManager 在 Windows 系统上不应抛出崩溃，
        而是提供明确的不支持提示或跳过操作。
        此测试在 Windows 上验证防御性行为，在 Linux 上验证基础可导入性。
        """
        import platform

        # 尝试导入 NoVNCManager，Windows 上可能因依赖缺失而失败
        try:
            from payswitch.browser.novnc import NoVNCManager

            # 如果能导入，则创建实例不应崩溃
            manager = NoVNCManager(host="localhost", port=6080)
            # 验证基本属性存在
            assert hasattr(manager, "get_info"), "NoVNCManager 应有 get_info 方法"

        except ImportError as e:
            # Windows 上缺少 Linux 专有依赖（如 pyvnc）是预期行为
            if platform.system() == "Windows":
                # 在 Windows 上 ImportError 是可接受的
                assert True, f"Windows 上 NoVNCManager 不可用（预期）：{e}"
            else:
                pytest.fail(f"Linux 上 NoVNCManager 导入失败（非预期）：{e}")

    def test_display_manager_novnc模式_返回正确配置信息(self, tmp_path: Path):
        """
        DisplayManager 在 novnc 模式下，get_display_info 应返回包含 url 和 display 的字典。
        通过 mock NoVNCManager 避免实际启动 noVNC 进程。
        """
        from payswitch.browser.display import DisplayManager

        # mock NoVNCManager，避免导入/启动 Linux 专有工具
        mock_novnc_manager = MagicMock()
        mock_novnc_manager.get_info.return_value = {
            "url": "http://localhost:6080/vnc.html",
            "display": ":99",
        }

        with patch(
            "payswitch.browser.novnc.NoVNCManager",
            return_value=mock_novnc_manager,
        ):
            dm = DisplayManager(mode=DisplayMode.novnc)
            info = dm.get_display_info()

        # 验证返回值结构正确
        assert info["mode"] == "novnc", f"模式应为 novnc，实际：{info['mode']}"
        assert "url" in info, f"novnc 模式应包含 url 字段，实际：{info}"
        assert "http" in info["url"], f"url 应以 http 开头，实际：{info['url']}"
        assert "display" in info, f"novnc 模式应包含 display 字段，实际：{info}"

    def test_display_manager_headed模式_不含novnc_url(self):
        """
        DisplayManager 在 headed 模式下，get_display_info 应返回简单字典，
        不包含 noVNC URL（本地有头浏览器不需要 VNC 访问）。
        """
        from payswitch.browser.display import DisplayManager

        dm = DisplayManager(mode=DisplayMode.headed)
        info = dm.get_display_info()

        assert info["mode"] == "headed"
        assert "url" not in info, f"headed 模式不应有 url 字段，实际：{info}"

    def test_docker_compose_包含必要服务(self):
        """docker-compose.yml 应包含 payswitch 服务配置。"""
        project_root = Path(__file__).parent.parent
        compose_file = project_root / "docker" / "docker-compose.yml"

        if not compose_file.exists():
            pytest.skip("docker-compose.yml 不存在，跳过内容校验")

        content = compose_file.read_text(encoding="utf-8")
        # 验证包含服务定义关键词
        assert "services" in content, "docker-compose.yml 缺少 services 配置段"

    def test_entrypoint_sh_包含novnc相关命令(self):
        """entrypoint.sh 应包含 noVNC 或 Xvfb 相关的启动命令。"""
        project_root = Path(__file__).parent.parent
        entrypoint_file = project_root / "docker" / "entrypoint.sh"

        if not entrypoint_file.exists():
            pytest.skip("entrypoint.sh 不存在，跳过内容校验")

        content = entrypoint_file.read_text(encoding="utf-8", errors="replace")
        # 验证包含至少一个 noVNC 相关关键词
        novnc_keywords = ["novnc", "Xvfb", "x11vnc", "vnc", "VNC", "xvfb"]
        has_novnc = any(kw.lower() in content.lower() for kw in novnc_keywords)
        assert has_novnc, (
            f"entrypoint.sh 中未找到 noVNC/Xvfb 相关命令，"
            f"期望包含：{novnc_keywords}"
        )


# ===========================================================================
# 场景四：未知网站 + Skyvern 直接智能模式
# ===========================================================================


class TestScenario4_UnknownSiteSkyvern:
    """场景四：没有适配器的未知网站，直接使用 Skyvern 智能模式。

    验证：
    - AdapterRegistry.get 返回 None（无适配器注册）
    - orchestrator 直接进入智能模式（不经过脚本模式）
    - SkyvernEngine.execute_task 被调用
    - 执行模式为 smart
    """

    @pytest.mark.asyncio
    async def test_无适配器_external_driver进入computer_use接力(self, tmp_path: Path):
        """
        未知站点在 external driver 下应进入外部 Agent 接力态，
        而不是要求内部模型可用后才能继续。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.external
        )
        target_url = "https://unknown-payment-site.com/topup"

        mock_profile = _make_mock_profile("unknown_site")
        mock_profile_dir = tmp_path / "profiles" / "unknown_site"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser(current_url=target_url)

        mock_skyvern = MagicMock()
        mock_skyvern.execute_task = AsyncMock()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock()

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            MockRegistry.get.return_value = None

            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(
                    amount=100.0,
                    payee="unknown_site",
                    url=target_url,
                )
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.human_action_required
        assert tx.execution_mode == ExecutionMode.computer_use
        assert tx.human_action is not None
        assert tx.human_action.action_type == "external_computer_use"
        mock_browser.navigate.assert_any_await(target_url)
        mock_display.notify_human.assert_awaited_once()
        mock_display.wait_for_completion.assert_not_called()
        mock_skyvern.execute_task.assert_not_called()

    @pytest.mark.asyncio
    async def test_无适配器_直接进入skyvern模式(self, tmp_path: Path):
        """
        当 registry.get 返回 None 且提供了 url 参数时，
        orchestrator 应直接进入 Skyvern 智能模式，跳过脚本模式。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("unknown_site")
        mock_profile_dir = tmp_path / "profiles" / "unknown_site"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        # ---- Skyvern 引擎：成功完成任务 ----
        skyvern_steps = _make_skyvern_steps(count=3)
        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock(return_value=skyvern_steps)

        # ---- 检测器：报告支付完成 ----
        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "completion_detector"
        mock_detection.description = "支付成功"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            # 关键：registry.get 返回 None，表示没有适配器
            MockRegistry.get.return_value = None

            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(
                    amount=100.0,
                    payee="unknown_site",
                    url="https://unknown-payment-site.com/topup",
                )
            finally:
                orchestrator.close()

        # ---- 断言 ----
        # 1. 最终状态为 completed
        assert tx.status == TransactionStatus.completed, (
            f"期望 completed，实际 {tx.status}（error={tx.error}）"
        )

        # 2. 执行模式为 smart（直接智能模式，未经过脚本模式）
        assert tx.execution_mode == ExecutionMode.smart, (
            f"期望 smart 执行模式，实际 {tx.execution_mode}"
        )

    @pytest.mark.asyncio
    async def test_无适配器_skyvern_execute_task被调用(self, tmp_path: Path):
        """
        验证在无适配器情况下，SkyvernEngine.execute_task 确实被调用，
        且传入了正确的 url 参数。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )
        target_url = "https://unknown-payment-site.com/topup"

        mock_profile = _make_mock_profile("unknown_site")
        mock_profile_dir = tmp_path / "profiles" / "unknown_site"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        skyvern_steps = _make_skyvern_steps(count=2)
        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock(return_value=skyvern_steps)

        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "test"
        mock_detection.description = "完成"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            MockRegistry.get.return_value = None

            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                await orchestrator.spend(
                    amount=100.0,
                    payee="unknown_site",
                    url=target_url,
                )
            finally:
                orchestrator.close()

        # 验证 execute_task 被调用且传入了正确的 url
        mock_skyvern.execute_task.assert_called_once()
        call_kwargs = mock_skyvern.execute_task.call_args
        # url 通过关键字参数传入
        actual_url = call_kwargs.kwargs.get("url") or (
            call_kwargs.args[2] if len(call_kwargs.args) > 2 else None
        )
        assert actual_url == target_url, (
            f"execute_task 应传入 url={target_url!r}，实际传入：{actual_url!r}"
        )

    @pytest.mark.asyncio
    async def test_无适配器_无url_返回failed(self, tmp_path: Path):
        """
        当没有适配器且没有提供 url 参数时，
        orchestrator 应返回 failed 状态（无法执行任何支付流程）。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )

        mock_profile = _make_mock_profile("unknown_site")
        mock_profile_dir = tmp_path / "profiles" / "unknown_site"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch("payswitch.engine.orchestrator.DetectorPipeline"),
        ):
            # 无适配器，且不传 url 参数
            MockRegistry.get.return_value = None

            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                # 不传 url
                tx = await orchestrator.spend(
                    amount=100.0,
                    payee="unknown_site",
                )
            finally:
                orchestrator.close()

        # 期望返回 failed，error 中说明缺少适配器和 url
        assert tx.status == TransactionStatus.failed, (
            f"无适配器且无 url 应返回 failed，实际 {tx.status}"
        )
        assert tx.error is not None

    @pytest.mark.asyncio
    async def test_无适配器_不调用脚本模式(self, tmp_path: Path):
        """
        确认无适配器路径下，从未有脚本模式适配器的 execute_topup 被调用。
        这验证了"直接进入 Skyvern，不经过脚本模式"的行为。
        """
        config = _make_test_config(tmp_path)

        mock_profile = _make_mock_profile("unknown_site")
        mock_profile_dir = tmp_path / "profiles" / "unknown_site"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        # 创建一个假适配器来验证 execute_topup 不被调用
        fake_adapter_with_spy = MagicMock()
        fake_adapter_with_spy.execute_topup = AsyncMock()

        skyvern_steps = _make_skyvern_steps(count=1)
        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock(return_value=skyvern_steps)

        mock_detection = MagicMock()
        mock_detection.action_type = "completed"
        mock_detection.detector_name = "test"
        mock_detection.description = "完成"
        mock_detection.data = {}

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=mock_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            # 注册表返回 None → 无适配器路径
            MockRegistry.get.return_value = None

            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                await orchestrator.spend(
                    amount=100.0,
                    payee="unknown_site",
                    url="https://unknown-site.com/pay",
                )
            finally:
                orchestrator.close()

        # 验证 fake_adapter 的 execute_topup 从未被调用
        # （因为 MockRegistry.get 返回 None，不会实例化任何适配器）
        fake_adapter_with_spy.execute_topup.assert_not_called()

    @pytest.mark.asyncio
    async def test_无适配器_二维码触发通知并持续监听(self, tmp_path: Path):
        """
        未知站点的 Computer Use 探索抵达支付宝二维码后，
        orchestrator 必须触发人类通知并等待检测器报告完成。
        """
        config = _make_test_config(
            tmp_path,
            transaction_timeout=30,
            computer_use_driver=ComputerUseDriver.internal,
        )

        mock_profile = _make_mock_profile("unknown_site")
        mock_profile_dir = tmp_path / "profiles" / "unknown_site"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser()

        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = True
        mock_skyvern.execute_task = AsyncMock(return_value=_make_skyvern_steps(count=2))

        qr_detection = MagicMock()
        qr_detection.action_type = "scan_qr"
        qr_detection.detector_name = "QRCodeDetector"
        qr_detection.description = "请使用支付宝扫码完成支付"
        qr_detection.data = {"qr_count": 1}

        qr_detector = MagicMock()
        qr_detector.name = "QRCodeDetector"
        qr_detector.requires_human.return_value = True
        qr_detector.detect_completion = AsyncMock(return_value=True)

        mock_pipeline = MagicMock()
        mock_pipeline._detectors = [qr_detector]
        mock_pipeline.scan = AsyncMock(return_value=qr_detection)

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock(return_value=True)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            MockRegistry.get.return_value = None

            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(
                    amount=0.9,
                    payee="unknown_site",
                    method=PaymentMethod.alipay_qr,
                    url="https://unknown-site.com/buy/14",
                )
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.completed
        mock_display.notify_human.assert_awaited_once()
        notify_kwargs = mock_display.notify_human.await_args.kwargs
        assert notify_kwargs["action_type"] == "scan_qr"
        assert notify_kwargs["details"]["amount"] == "¥0.90"
        mock_display.wait_for_completion.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_无适配器_智能不可用时接管前导航到目标url(self, tmp_path: Path):
        """
        内部 Computer Use 不可用时，未知站点不能把用户留在 about:blank；
        人类接管前应先打开调用方传入的目标 URL。
        """
        config = _make_test_config(
            tmp_path, computer_use_driver=ComputerUseDriver.internal
        )
        target_url = "https://unknown-site.com/buy/14"

        mock_profile = _make_mock_profile("unknown_site")
        mock_profile_dir = tmp_path / "profiles" / "unknown_site"
        mock_profile_dir.mkdir(parents=True, exist_ok=True)

        mock_browser = _make_mock_browser(current_url=target_url)

        mock_skyvern = MagicMock()
        mock_skyvern.is_available.return_value = False

        mock_display = MagicMock()
        mock_display.mode = DisplayMode.headed
        mock_display.get_display_info.return_value = {"mode": "headed"}
        mock_display.notify_human = AsyncMock()
        mock_display.wait_for_completion = AsyncMock(return_value=True)

        mock_pipeline = MagicMock()
        mock_pipeline.scan = AsyncMock(return_value=None)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager") as MockProfileManager,
            patch(
                "payswitch.engine.orchestrator.BrowserController",
                return_value=mock_browser,
            ),
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch(
                "payswitch.engine.orchestrator.DisplayManager",
                return_value=mock_display,
            ),
            patch(
                "payswitch.engine.orchestrator.DetectorPipeline",
                return_value=mock_pipeline,
            ),
            patch(
                "payswitch.browser.skyvern.SkyvernEngine",
                return_value=mock_skyvern,
            ),
        ):
            MockRegistry.get.return_value = None

            mock_pm = MagicMock()
            mock_pm.get_profile.return_value = mock_profile
            mock_pm.get_profile_dir.return_value = mock_profile_dir
            MockProfileManager.return_value = mock_pm

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(
                    amount=0.9,
                    payee="unknown_site",
                    method=PaymentMethod.alipay_qr,
                    url=target_url,
                )
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.completed
        assert tx.execution_mode == ExecutionMode.human_takeover
        mock_browser.navigate.assert_any_await(target_url)
        notify_kwargs = mock_display.notify_human.await_args.kwargs
        assert notify_kwargs["details"]["current_url"] == target_url


# ===========================================================================
# 边界条件与补充测试
# ===========================================================================


class TestEdgeCases:
    """边界条件与辅助功能测试。"""

    @pytest.mark.asyncio
    async def test_dry_run模式_不启动浏览器(self, tmp_path: Path):
        """
        dry_run=True 时，orchestrator 应在安全检查通过后直接返回模拟结果，
        不启动浏览器，不执行真实支付。
        """
        config = _make_test_config(tmp_path)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager"),
            patch("payswitch.engine.orchestrator.BrowserController") as MockBrowser,
            patch("payswitch.engine.orchestrator.AdapterRegistry"),
            patch("payswitch.engine.orchestrator.DisplayManager"),
            patch("payswitch.engine.orchestrator.DetectorPipeline"),
        ):
            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(
                    amount=100.0,
                    payee="deepseek",
                    dry_run=True,
                )
            finally:
                orchestrator.close()

        # dry_run 返回 completed（模拟结果）
        assert tx.status == TransactionStatus.completed
        # 浏览器不应被实例化
        MockBrowser.assert_not_called()

    @pytest.mark.asyncio
    async def test_dry_run无适配器时展示computer_use兜底路径(self, tmp_path: Path):
        """dry_run 的模拟计划应反映无适配器时会进入 Computer Use 兜底。"""
        config = _make_test_config(tmp_path)

        with (
            patch("payswitch.engine.orchestrator.ProfileManager"),
            patch("payswitch.engine.orchestrator.BrowserController") as MockBrowser,
            patch("payswitch.engine.orchestrator.AdapterRegistry") as MockRegistry,
            patch("payswitch.engine.orchestrator.DisplayManager"),
            patch("payswitch.engine.orchestrator.DetectorPipeline"),
        ):
            MockRegistry.get.return_value = None

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(
                    amount=10.0,
                    payee="unknown-shop",
                    method=PaymentMethod.alipay_qr,
                    url="https://example.com/pay",
                    dry_run=True,
                )
            finally:
                orchestrator.close()

        assert tx.status == TransactionStatus.completed
        assert tx.execution_mode == ExecutionMode.smart
        assert any("Computer Use 兜底" in step.description for step in tx.steps)
        MockBrowser.assert_not_called()

    @pytest.mark.asyncio
    async def test_幂等键命中_直接返回已有交易(self, tmp_path: Path):
        """
        当 idempotency_key 在 48 小时内命中已有交易时，
        orchestrator 应直接返回该交易，不启动新的支付流程。
        """
        config = _make_test_config(tmp_path)

        # 创建一个"已完成的交易"作为幂等命中结果
        existing_tx = Transaction(
            amount=200.0,
            payee="deepseek",
            status=TransactionStatus.completed,
            idempotency_key="idem-key-001",
        )

        with (
            patch("payswitch.engine.orchestrator.ProfileManager"),
            patch("payswitch.engine.orchestrator.BrowserController") as MockBrowser,
            patch("payswitch.engine.orchestrator.AdapterRegistry"),
            patch("payswitch.engine.orchestrator.DisplayManager"),
            patch("payswitch.engine.orchestrator.DetectorPipeline"),
            # patch Ledger 和 Guard，使幂等检查命中
            patch("payswitch.engine.orchestrator.Ledger") as MockLedger,
            patch("payswitch.engine.orchestrator.SpendingGuard") as MockGuard,
        ):
            # Guard 报告幂等命中
            from payswitch.engine.guard import GuardResult

            mock_guard_instance = MagicMock()
            mock_guard_instance.check.return_value = GuardResult(
                allowed=True,
                existing_tx=existing_tx,
            )
            MockGuard.return_value = mock_guard_instance

            mock_ledger = MagicMock()
            mock_ledger.close = MagicMock()
            MockLedger.return_value = mock_ledger

            from payswitch.engine.orchestrator import PaymentOrchestrator

            orchestrator = PaymentOrchestrator(config)
            try:
                tx = await orchestrator.spend(
                    amount=200.0,
                    payee="deepseek",
                    idempotency_key="idem-key-001",
                )
            finally:
                orchestrator.close()

        # 返回的是已有交易，tx_id 相同
        assert tx.tx_id == existing_tx.tx_id
        assert tx.status == TransactionStatus.completed
        # 浏览器不应被启动（幂等命中直接返回）
        MockBrowser.return_value.launch.assert_not_called()

    def test_adapter_registry_get_返回None表示无适配器(self):
        """
        验证 AdapterRegistry.get 对于未注册的平台返回 None。
        这是场景四的前提条件。
        """
        from payswitch.adapters import AdapterRegistry

        result = AdapterRegistry.get("nonexistent_unknown_platform_xyz")
        assert result is None, (
            f"未注册的平台 get() 应返回 None，实际返回：{result}"
        )

    def test_adapter_registry_get_返回deepseek适配器(self):
        """
        验证已注册的 deepseek 平台能通过 AdapterRegistry.get 获取适配器实例。
        这是场景一的前提条件。
        """
        from payswitch.adapters import AdapterRegistry

        adapter = AdapterRegistry.get("deepseek")
        assert adapter is not None, "deepseek 适配器应已注册"
        assert hasattr(adapter, "execute_topup"), "适配器应有 execute_topup 方法"

    def test_script_execution_error_可被抛出和捕获(self):
        """
        验证 ScriptExecutionError 可以被正常抛出和捕获。
        这是场景二回退逻辑的基础。
        """
        with pytest.raises(ScriptExecutionError) as exc_info:
            raise ScriptExecutionError("测试：页面结构变更")
        assert "页面结构变更" in str(exc_info.value)
