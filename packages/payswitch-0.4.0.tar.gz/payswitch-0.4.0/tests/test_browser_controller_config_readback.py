"""BrowserController.launch() 配置回读测试。

修复：config 设了 browser_engine 后 launch() 真正用它。
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from payswitch.browser.controller import BrowserController
from payswitch.models.config import PaySwitchConfig


def _make_fake_context() -> MagicMock:
    ctx = MagicMock()
    ctx.new_page = AsyncMock(return_value=MagicMock())
    ctx.add_init_script = AsyncMock()
    return ctx


def _make_fake_pw_ctx() -> MagicMock:
    pw = MagicMock()
    pw_ctx = MagicMock()
    pw_ctx.start = AsyncMock(return_value=pw)
    return pw_ctx


@pytest.mark.asyncio
async def test_launch_persistent_reads_engine_from_config(tmp_path) -> None:
    """profile_dir + 不传 engine → 用 config 的 cloakbrowser。"""
    captured: dict = {}
    fake_engine = MagicMock()
    fake_engine.launch_persistent = AsyncMock(return_value=_make_fake_context())

    def _capture(name):
        captured["engine_name"] = name
        return fake_engine

    cfg = PaySwitchConfig(
        browser_engine="cloakbrowser",
        browser_humanize=True,
        browser_human_preset="careful",
    )

    with (
        patch(
            "payswitch.browser.controller.async_playwright",
            return_value=_make_fake_pw_ctx(),
        ),
        patch("payswitch.models.config.PaySwitchConfig.load", return_value=cfg),
        patch("payswitch.browser.engines.get_engine", side_effect=_capture),
    ):
        ctrl = BrowserController()
        await ctrl.launch(profile_dir=tmp_path / "prof")

    assert captured["engine_name"] == "cloakbrowser"
    call = fake_engine.launch_persistent.await_args
    assert call.kwargs["humanize"] is True
    assert call.kwargs["human_preset"] == "careful"


@pytest.mark.asyncio
async def test_launch_stateless_reads_engine_from_config() -> None:
    """stateless + 不传 engine → 用 config。"""
    captured: dict = {}
    fake_engine = MagicMock()
    fake_engine.launch_stateless = AsyncMock(
        return_value=(MagicMock(), _make_fake_context())
    )

    def _capture(name):
        captured["engine_name"] = name
        return fake_engine

    cfg = PaySwitchConfig(browser_engine="cloakbrowser", browser_humanize=True)

    with (
        patch(
            "payswitch.browser.controller.async_playwright",
            return_value=_make_fake_pw_ctx(),
        ),
        patch("payswitch.models.config.PaySwitchConfig.load", return_value=cfg),
        patch("payswitch.browser.engines.get_engine", side_effect=_capture),
    ):
        ctrl = BrowserController()
        await ctrl.launch(profile_dir=None)

    assert captured["engine_name"] == "cloakbrowser"
    call = fake_engine.launch_stateless.await_args
    assert call.kwargs["humanize"] is True


@pytest.mark.asyncio
async def test_launch_explicit_engine_beats_config(tmp_path) -> None:
    """显式参数覆盖 config。"""
    captured: dict = {}
    fake_engine = MagicMock()
    fake_engine.launch_persistent = AsyncMock(return_value=_make_fake_context())

    def _capture(name):
        captured["engine_name"] = name
        return fake_engine

    cfg = PaySwitchConfig(browser_engine="cloakbrowser", browser_humanize=True)

    with (
        patch(
            "payswitch.browser.controller.async_playwright",
            return_value=_make_fake_pw_ctx(),
        ),
        patch("payswitch.models.config.PaySwitchConfig.load", return_value=cfg),
        patch("payswitch.browser.engines.get_engine", side_effect=_capture),
    ):
        ctrl = BrowserController()
        await ctrl.launch(
            profile_dir=tmp_path / "prof",
            engine="playwright",
            humanize=False,
            human_preset="default",
        )

    assert captured["engine_name"] == "playwright"
    call = fake_engine.launch_persistent.await_args
    assert call.kwargs["humanize"] is False
    assert call.kwargs["human_preset"] == "default"


@pytest.mark.asyncio
async def test_launch_config_load_failure_safe_defaults(tmp_path) -> None:
    """config 读失败 → 回落 playwright + humanize=False。"""
    captured: dict = {}
    fake_engine = MagicMock()
    fake_engine.launch_persistent = AsyncMock(return_value=_make_fake_context())

    def _capture(name):
        captured["engine_name"] = name
        return fake_engine

    with (
        patch(
            "payswitch.browser.controller.async_playwright",
            return_value=_make_fake_pw_ctx(),
        ),
        patch(
            "payswitch.models.config.PaySwitchConfig.load",
            side_effect=RuntimeError("config not available"),
        ),
        patch("payswitch.browser.engines.get_engine", side_effect=_capture),
    ):
        ctrl = BrowserController()
        await ctrl.launch(profile_dir=tmp_path / "prof")

    assert captured["engine_name"] == "playwright"
    call = fake_engine.launch_persistent.await_args
    assert call.kwargs["humanize"] is False


@pytest.mark.asyncio
async def test_launch_stateless_passes_record_video_dir_to_engine(tmp_path) -> None:
    fake_engine = MagicMock()
    fake_engine.launch_stateless = AsyncMock(
        return_value=(MagicMock(), _make_fake_context())
    )

    with (
        patch(
            "payswitch.browser.controller.async_playwright",
            return_value=_make_fake_pw_ctx(),
        ),
        patch(
            "payswitch.models.config.PaySwitchConfig.load",
            return_value=PaySwitchConfig(browser_engine="playwright"),
        ),
        patch("payswitch.browser.engines.get_engine", return_value=fake_engine),
    ):
        ctrl = BrowserController()
        await ctrl.launch(profile_dir=None, record_video_dir=tmp_path / "recordings")

    call = fake_engine.launch_stateless.await_args
    assert call.kwargs["record_video_dir"] == (tmp_path / "recordings").resolve()
    assert ctrl.video_recording_enabled is True
    assert ctrl.record_video_dir == (tmp_path / "recordings").resolve()
