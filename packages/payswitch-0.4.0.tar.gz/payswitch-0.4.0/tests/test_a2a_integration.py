"""A2A 协议集成测试。

测试 Agent Card、A2A 任务生命周期、HITL、SSE 等端点。
不需要 Docker/Redis 的测试直接运行，需要的标记 @pytest.mark.docker。
"""

from __future__ import annotations

import pytest
from httpx import ASGITransport, AsyncClient

from server.a2a.models import A2ATaskStatus
from server.app import app


@pytest.fixture
async def client():
    """httpx 异步客户端（不触发 lifespan）。"""
    async with AsyncClient(
        transport=ASGITransport(app=app, raise_app_exceptions=False),
        base_url="http://test",
    ) as c:
        yield c


# ─── A2A 任务输入的测试 payload 工厂 ─────────────────────────

def _a2a_task_payload(
    task_id: str = "test-a2a-001",
    url: str = "https://example.com/checkout",
    amount: float = 49.99,
    card_alias: str = "my-visa-4242",
) -> dict:
    """生成 A2A 任务输入 payload（PRDv3 §4.4 格式）。"""
    return {
        "task": {
            "id": task_id,
            "message": {
                "role": "user",
                "parts": [
                    {
                        "type": "text",
                        "text": f"在 {url} 完成支付，金额 ${amount}",
                    }
                ],
            },
            "metadata": {
                "card_alias": card_alias,
                "max_amount": amount + 1.0,
                "currency": "USD",
                "require_human_confirmation": True,
            },
        }
    }


# ─── Test 1: Agent Card ─────────────────────────────────────

class TestAgentCard:
    """GET /.well-known/agent.json 返回合规 Agent Card。"""

    async def test_agent_card_returns_200(self, client: AsyncClient) -> None:
        r = await client.get("/.well-known/agent.json")
        assert r.status_code == 200

    async def test_agent_card_has_required_fields(self, client: AsyncClient) -> None:
        r = await client.get("/.well-known/agent.json")
        card = r.json()

        # 必须的顶层字段
        assert card["name"] == "payswitch-payment-agent"
        assert "description" in card
        assert "url" in card
        assert "version" in card

    async def test_agent_card_capabilities(self, client: AsyncClient) -> None:
        r = await client.get("/.well-known/agent.json")
        caps = r.json()["capabilities"]

        assert caps["streaming"] is True
        assert caps["pushNotifications"] is True
        assert caps["stateTransitionHistory"] is True

    async def test_agent_card_skills(self, client: AsyncClient) -> None:
        r = await client.get("/.well-known/agent.json")
        skills = r.json()["skills"]

        assert len(skills) == 2
        skill_ids = [s["id"] for s in skills]
        assert "web-checkout" in skill_ids
        assert "stripe-payment" in skill_ids

    async def test_agent_card_authentication(self, client: AsyncClient) -> None:
        r = await client.get("/.well-known/agent.json")
        auth = r.json()["authentication"]

        assert "schemes" in auth
        assert len(auth["schemes"]) >= 1

    async def test_agent_card_skills_have_io_modes(self, client: AsyncClient) -> None:
        r = await client.get("/.well-known/agent.json")
        for skill in r.json()["skills"]:
            assert "inputModes" in skill
            assert "outputModes" in skill
            assert len(skill["inputModes"]) >= 1
            assert len(skill["outputModes"]) >= 1


# ─── Test 2: 提交 A2A 任务 ──────────────────────────────────

class TestSubmitA2ATask:
    """POST /a2a 接收 A2A 格式任务。"""

    async def test_submit_without_lifespan_returns_503(self, client: AsyncClient) -> None:
        """lifespan 未就绪时应返回 503。"""
        r = await client.post("/a2a", json=_a2a_task_payload())
        assert r.status_code == 503

    async def test_submit_validates_payload(self, client: AsyncClient) -> None:
        """缺少必要字段时应返回 422。"""
        r = await client.post("/a2a", json={"task": {}})
        assert r.status_code == 422


# ─── Test 3: A2A 生命周期状态映射 ───────────────────────────

class TestA2ALifecycle:
    """A2A 状态流转完整性。"""

    def test_all_seven_statuses_defined(self) -> None:
        """A2A 定义了 7 种状态。"""
        statuses = list(A2ATaskStatus)
        assert len(statuses) == 7

        expected = {
            "submitted", "working", "input-required",
            "auth-required", "completed", "failed", "canceled",
        }
        actual = {s.value for s in statuses}
        assert actual == expected

    def test_status_mapping_covers_all(self) -> None:
        """内部状态 → A2A 状态映射完整性。"""
        from server.a2a.task_handler import _STATUS_MAP
        from server.models import TaskStatus

        for ts in TaskStatus:
            assert ts in _STATUS_MAP, f"内部状态 {ts} 缺少 A2A 映射"


# ─── Test 4: A2A HITL (Resume) ──────────────────────────────

class TestA2AHITL:
    """A2A Resume 端点（HITL 暂停/恢复）。"""

    async def test_resume_without_lifespan_returns_503(self, client: AsyncClient) -> None:
        r = await client.post("/a2a/resume/test-123", json={
            "action": "approve",
        })
        assert r.status_code == 503

    async def test_resume_validates_payload(self, client: AsyncClient) -> None:
        """缺少 action 字段应返回 422。"""
        r = await client.post("/a2a/resume/test-123", json={})
        assert r.status_code == 422


# ─── Test 5: A2A 幂等性 ─────────────────────────────────────

class TestA2AIdempotency:
    """同一 task_id 重复提交返回缓存。"""

    async def test_submit_same_task_id_twice_without_lifespan(
        self, client: AsyncClient
    ) -> None:
        """无 lifespan 时两次提交均返回 503（基本连通性验证）。"""
        payload = _a2a_task_payload(task_id="idem-test-001")
        r1 = await client.post("/a2a", json=payload)
        r2 = await client.post("/a2a", json=payload)
        assert r1.status_code == 503
        assert r2.status_code == 503


# ─── Test 6: A2A 取消任务 ──────────────────────────────────

class TestA2ACancel:
    """取消 A2A 任务。"""

    async def test_resume_reject_is_cancel(self) -> None:
        """验证 reject action 对应取消逻辑。"""
        from server.a2a.models import ResumeRequest

        resume = ResumeRequest(action="reject")
        assert resume.action == "reject"


# ─── Test 7: A2A SSE 流 ─────────────────────────────────────

class TestA2ASSEStream:
    """A2A SSE 事件流格式。"""

    async def test_sse_stream_without_lifespan(self, client: AsyncClient) -> None:
        """lifespan 未就绪时返回 503。"""
        r = await client.get("/a2a/stream/test-123")
        assert r.status_code == 503

    async def test_a2a_status_endpoint_without_lifespan(self, client: AsyncClient) -> None:
        """状态查询端点在无 lifespan 时返回 503。"""
        r = await client.get("/a2a/status/test-123")
        assert r.status_code == 503


# ─── A2A 模型测试 ───────────────────────────────────────────

class TestA2AModels:
    """A2A 数据模型验证。"""

    def test_a2a_task_input_parsing(self) -> None:
        """PRDv3 §4.4 格式解析。"""
        from server.a2a.models import A2ATaskInput

        payload = _a2a_task_payload()
        task_input = A2ATaskInput.model_validate(payload)

        assert task_input.task.id == "test-a2a-001"
        assert task_input.task.metadata.card_alias == "my-visa-4242"
        assert task_input.task.metadata.max_amount == 50.99
        assert task_input.task.message.role == "user"
        assert len(task_input.task.message.parts) == 1

    def test_a2a_task_response_with_artifact(self) -> None:
        """带 artifact 的终态响应。"""
        from server.a2a.models import A2ATaskResponse, Artifact

        resp = A2ATaskResponse(
            task_id="test-001",
            status=A2ATaskStatus.COMPLETED,
            artifacts=[Artifact(
                type="application/json",
                data={"transaction_id": "txn-123", "amount": 49.99},
                description="支付交易凭证",
            )],
            message="支付成功",
        )
        assert resp.status == A2ATaskStatus.COMPLETED
        assert len(resp.artifacts) == 1
        assert resp.artifacts[0].data["transaction_id"] == "txn-123"

    def test_resume_request_actions(self) -> None:
        """Resume 请求动作类型。"""
        from server.a2a.models import ResumeRequest

        for action in ("approve", "reject", "provide_input"):
            req = ResumeRequest(action=action)
            assert req.action == action

        # 带输入数据
        req = ResumeRequest(action="provide_input", input={"otp": "123456"})
        assert req.input == {"otp": "123456"}

    def test_url_extraction(self) -> None:
        """从文本中提取 URL。"""
        from server.a2a.task_handler import _extract_url_from_text

        assert _extract_url_from_text("在 https://x.com/pay 完成支付") == "https://x.com/pay"
        assert _extract_url_from_text("http://example.com 付款") == "http://example.com"
        assert _extract_url_from_text("没有链接") == ""

    def test_a2a_to_internal_conversion(self) -> None:
        """A2A → 内部 TaskRequest 转换。"""
        from server.a2a.models import A2ATaskInput
        from server.a2a.task_handler import A2ATaskHandler

        payload = _a2a_task_payload(url="https://shop.example.com")
        a2a_input = A2ATaskInput.model_validate(payload)

        # 直接调用转换方法（不需要完整 handler 初始化）
        handler = A2ATaskHandler.__new__(A2ATaskHandler)
        internal = handler._a2a_to_internal(a2a_input)

        assert internal.task_id == "test-a2a-001"
        assert internal.card_alias == "my-visa-4242"
        assert "shop.example.com" in internal.url
        assert internal.require_human_confirmation is True
