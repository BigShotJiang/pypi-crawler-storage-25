"""Ephemeral CDP mirror backend tests."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest

from payswitch.browser import cdp_mirror


def _source_chrome_profile(tmp_path: Path) -> Path:
    chrome_root = tmp_path / "Chrome"
    profile = chrome_root / "Profile 10"
    profile.mkdir(parents=True)
    (chrome_root / "Local State").write_text(
        json.dumps({"profile": {"last_used": "Profile 10"}}),
        encoding="utf-8",
    )
    (profile / "Cookies").write_text("cookie-db", encoding="utf-8")
    (profile / "SingletonLock").write_text("locked", encoding="utf-8")
    (profile / "Cache").mkdir()
    (profile / "Cache" / "entry").write_text("cache", encoding="utf-8")
    return chrome_root


def test_prepare_ephemeral_cdp_mirror_creates_temp_snapshot(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source_root = _source_chrome_profile(tmp_path)
    temp_root = tmp_path / "tmp"
    launched: list[cdp_mirror.CdpMirrorInstance] = []

    monkeypatch.setattr(cdp_mirror.tempfile, "gettempdir", lambda: str(temp_root))
    monkeypatch.setattr(cdp_mirror, "_find_free_port", lambda: 39111)
    monkeypatch.setattr(cdp_mirror, "_wait_for_port", lambda port, *, timeout_seconds: None)
    monkeypatch.setattr(
        cdp_mirror,
        "_launch_chrome",
        lambda instance, *, browser_channel: launched.append(instance),
    )

    instance = cdp_mirror.prepare_ephemeral_cdp_mirror(
        source_user_data_dir=source_root,
        profile_directory="Profile 10",
        session_key="tx:abc/123",
        browser_channel="chrome",
    )

    mirror_profile = instance.mirror_user_data_dir / "Profile 10"
    assert instance.cdp_url == "http://127.0.0.1:39111"
    assert launched == [instance]
    assert mirror_profile.exists()
    assert (mirror_profile / "Cookies").read_text(encoding="utf-8") == "cookie-db"
    assert not (mirror_profile / "SingletonLock").exists()
    assert not (mirror_profile / "Cache").exists()

    local_state = json.loads(
        (instance.mirror_user_data_dir / "Local State").read_text(encoding="utf-8")
    )
    assert local_state["devtools"]["remote_debugging"]["user-enabled"] is True

    metadata = json.loads(
        (instance.mirror_user_data_dir / ".payswitch-cdp-mirror.json").read_text(
            encoding="utf-8"
        )
    )
    assert metadata["source_user_data_dir"] == str(source_root.resolve())
    assert metadata["profile_directory"] == "Profile 10"
    assert metadata["cdp_port"] == 39111


def test_prepare_ephemeral_cdp_mirror_reuses_ready_metadata(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source_root = _source_chrome_profile(tmp_path)
    temp_root = tmp_path / "tmp"
    mirror_root = (
        temp_root
        / "payswitch-cdp-mirrors"
        / "tx-ready"
    )
    mirror_root.mkdir(parents=True)
    (mirror_root / ".payswitch-cdp-mirror.json").write_text(
        json.dumps(
            {
                "source_user_data_dir": str(source_root.resolve()),
                "profile_directory": "Profile 10",
                "cdp_port": 39222,
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(cdp_mirror.tempfile, "gettempdir", lambda: str(temp_root))
    monkeypatch.setattr(cdp_mirror, "_port_ready", lambda port: port == 39222)
    monkeypatch.setattr(
        cdp_mirror,
        "_sync_profile_snapshot",
        lambda **kwargs: pytest.fail("ready metadata should skip snapshot"),
    )
    monkeypatch.setattr(
        cdp_mirror,
        "_launch_chrome",
        lambda instance, *, browser_channel: pytest.fail("ready metadata should skip launch"),
    )

    instance = cdp_mirror.prepare_ephemeral_cdp_mirror(
        source_user_data_dir=source_root,
        profile_directory="Profile 10",
        session_key="tx-ready",
    )

    assert instance.cdp_port == 39222
    assert instance.cdp_url == "http://127.0.0.1:39222"


def test_cleanup_ephemeral_cdp_mirror_removes_temp_snapshot(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    temp_root = tmp_path / "tmp"
    mirror_root = temp_root / "payswitch-cdp-mirrors" / "cleanup-test"
    mirror_root.mkdir(parents=True)
    (mirror_root / "marker").write_text("x", encoding="utf-8")
    monkeypatch.setattr(cdp_mirror.tempfile, "gettempdir", lambda: str(temp_root))

    cdp_mirror.cleanup_ephemeral_cdp_mirror("cleanup-test")

    assert not mirror_root.exists()


def test_cleanup_stale_ephemeral_cdp_mirrors_keeps_live_ports(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    temp_root = tmp_path / "tmp"
    mirror_base = temp_root / "payswitch-cdp-mirrors"
    stale = mirror_base / "stale"
    live = mirror_base / "live"
    stale.mkdir(parents=True)
    live.mkdir()
    (stale / ".payswitch-cdp-mirror.json").write_text(
        json.dumps({"cdp_port": 39001}),
        encoding="utf-8",
    )
    (live / ".payswitch-cdp-mirror.json").write_text(
        json.dumps({"cdp_port": 39002}),
        encoding="utf-8",
    )
    old = time.time() - 100
    os.utime(stale, (old, old))
    os.utime(live, (old, old))
    monkeypatch.setattr(cdp_mirror.tempfile, "gettempdir", lambda: str(temp_root))
    monkeypatch.setattr(cdp_mirror, "_port_ready", lambda port: port == 39002)

    cdp_mirror.cleanup_stale_ephemeral_cdp_mirrors(max_age_seconds=10)

    assert not stale.exists()
    assert live.exists()


def test_prepare_ephemeral_cdp_mirror_requires_existing_profile(tmp_path: Path) -> None:
    chrome_root = tmp_path / "Chrome"
    chrome_root.mkdir()

    with pytest.raises(cdp_mirror.CdpMirrorError, match="profile 目录不存在"):
        cdp_mirror.prepare_ephemeral_cdp_mirror(
            source_user_data_dir=chrome_root,
            profile_directory="Profile 404",
            session_key="missing",
        )
