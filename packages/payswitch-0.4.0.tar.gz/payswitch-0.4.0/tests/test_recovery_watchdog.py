"""RecoveryWatchdog 单元测试。"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from payswitch.engine.watchdog import RecoveryWatchdog


def test_recovery_watchdog_limits_human_gate_after_budget_exhausted() -> None:
    """超过预算后应走人工恢复分支，不再允许无边界自动回退。"""
    watchdog = RecoveryWatchdog(max_attempts=2, context_ttl_seconds=900)

    first = watchdog.register_script_failure(
        tx_id="tx-1",
        failure_context={"waypoint_category": "checkout_prep", "action_type": "click"},
    )
    assert first.allow_recovery is True
    assert first.requires_human_gate is False
    assert first.attempts_remaining == 1
    assert first.stale_buffer_discarded is False
    assert first.classification == "retryable_drift"
    assert first.recommended_action == "computer_use_recovery"

    second = watchdog.register_script_failure(
        tx_id="tx-1",
        failure_context={"waypoint_category": "checkout_prep", "action_type": "click"},
    )
    assert second.allow_recovery is True
    assert second.requires_human_gate is False
    assert second.attempts_remaining == 0
    assert second.stale_buffer_discarded is False
    assert second.classification == "retryable_drift"

    third = watchdog.register_script_failure(
        tx_id="tx-1",
        failure_context={"waypoint_category": "checkout_prep", "action_type": "click"},
    )
    assert third.allow_recovery is False
    assert third.requires_human_gate is True
    assert third.attempts_remaining == 0
    assert third.stale_buffer_discarded is False
    assert third.classification == "retryable_drift"
    assert third.recommended_action == "human_recovery_gate"


def test_recovery_watchdog_detects_high_risk_failure_as_human_gate() -> None:
    """高风险上下文应立即触发人工恢复，不走脚本恢复。"""
    watchdog = RecoveryWatchdog(max_attempts=3, context_ttl_seconds=900)

    decision = watchdog.register_script_failure(
        tx_id="tx-high-risk",
        failure_context={"waypoint_risk": "human_required", "waypoint_id": "confirm"},
    )

    assert decision.allow_recovery is False
    assert decision.requires_human_gate is True
    assert decision.requires_resync is False
    assert decision.is_high_risk is True
    assert decision.stale_buffer_discarded is False
    assert decision.classification == "sensitive_action"
    assert decision.recommended_action == "human_recovery_gate"


def test_recovery_watchdog_classifies_login_required_failures() -> None:
    watchdog = RecoveryWatchdog(max_attempts=3, context_ttl_seconds=900)

    decision = watchdog.register_script_failure(
        tx_id="tx-login",
        failure_context={
            "failure_class": "LoginRequiredError",
            "failure_reason": "session expired, login required",
        },
    )
    snapshot = watchdog.describe_state("tx-login")

    assert decision.allow_recovery is False
    assert decision.requires_human_gate is True
    assert decision.is_high_risk is False
    assert decision.classification == "login_required"
    assert decision.recommended_action == "login_human_gate"
    assert snapshot is not None
    assert snapshot["last_classification"] == "login_required"
    assert snapshot["last_recommended_action"] == "login_human_gate"


def test_recovery_watchdog_classifies_unsupported_page_as_computer_use_candidate() -> None:
    watchdog = RecoveryWatchdog(max_attempts=3, context_ttl_seconds=900)

    decision = watchdog.register_script_failure(
        tx_id="tx-unsupported",
        failure_context={
            "unsupported_page": True,
            "failure_reason": "current page is an unsupported surface",
        },
    )

    assert decision.allow_recovery is True
    assert decision.requires_human_gate is False
    assert decision.classification == "unsupported_page"
    assert decision.recommended_action == "computer_use_recovery"


def test_recovery_watchdog_classifies_hard_failure_as_manual_only() -> None:
    watchdog = RecoveryWatchdog(max_attempts=3, context_ttl_seconds=900)

    decision = watchdog.register_script_failure(
        tx_id="tx-hard",
        failure_context={
            "is_retryable": False,
            "failure_reason": "Stripe SDK 未安装",
        },
    )

    assert decision.allow_recovery is False
    assert decision.requires_human_gate is True
    assert decision.is_high_risk is False
    assert decision.classification == "hard_failure"
    assert decision.recommended_action == "human_recovery_gate"


def test_recovery_watchdog_classifies_sync_policy_checkpoint_as_sensitive() -> None:
    watchdog = RecoveryWatchdog(max_attempts=3, context_ttl_seconds=900)

    decision = watchdog.register_script_failure(
        tx_id="tx-sync-policy",
        failure_context={
            "waypoint_id": "confirm_membership_checkout",
            "synchronous_policy_checkpoint": True,
        },
    )

    assert decision.allow_recovery is False
    assert decision.requires_human_gate is True
    assert decision.classification == "sensitive_action"
    assert decision.recommended_action == "human_recovery_gate"


def test_recovery_watchdog_resync_after_context_ttl_expire() -> None:
    """记录重试点后，超过 TTL 时应要求做一次预检重连。"""
    base = datetime(2026, 1, 1, tzinfo=UTC)
    watchdog = RecoveryWatchdog(max_attempts=3, context_ttl_seconds=60)

    watchdog.mark_checkpoint("tx-expire", now=base)

    immediate = watchdog.register_script_failure(
        tx_id="tx-expire",
        failure_context={"waypoint_category": "checkout_prep", "action_type": "click"},
        now=base + timedelta(seconds=30),
    )
    assert immediate.requires_resync is False

    later = watchdog.register_script_failure(
        tx_id="tx-expire",
        failure_context={"waypoint_category": "checkout_prep", "action_type": "click"},
        now=base + timedelta(seconds=90),
    )
    assert later.requires_resync is True
    assert later.stale_buffer_discarded is True


def test_recovery_watchdog_discards_stale_buffer_before_recovery_continues() -> None:
    base = datetime(2026, 1, 1, tzinfo=UTC)
    watchdog = RecoveryWatchdog(max_attempts=3, context_ttl_seconds=60, telemetry_buffer_size=4)

    watchdog.mark_checkpoint("tx-stale", now=base)
    watchdog.register_script_failure(
        tx_id="tx-stale",
        failure_context={"index": 1, "waypoint_category": "checkout_prep"},
        now=base + timedelta(seconds=10),
    )
    watchdog.register_script_failure(
        tx_id="tx-stale",
        failure_context={"index": 2, "waypoint_category": "checkout_prep"},
        now=base + timedelta(seconds=20),
    )

    stale = watchdog.register_script_failure(
        tx_id="tx-stale",
        failure_context={"index": 3, "waypoint_category": "checkout_prep"},
        now=base + timedelta(seconds=90),
    )
    snapshot = watchdog.describe_state("tx-stale")

    assert stale.requires_resync is True
    assert stale.stale_buffer_discarded is True
    assert snapshot is not None
    assert snapshot["stale_resync_count"] == 1
    assert snapshot["telemetry_ttl_seconds"] == 60
    assert snapshot["telemetry_buffer"] == [{"index": 3, "waypoint_category": "checkout_prep"}]
    assert snapshot["last_classification"] == "retryable_drift"
    assert snapshot["last_recommended_action"] == "computer_use_recovery"


def test_recovery_watchdog_keeps_bounded_telemetry_window() -> None:
    """失败上下文缓冲区应遵循固定上限，保留最新样本。"""
    watchdog = RecoveryWatchdog(max_attempts=10, telemetry_buffer_size=2)

    for index in range(3):
        watchdog.register_script_failure(
            tx_id="tx-buffer",
            failure_context={"waypoint_category": "checkout_prep", "index": index},
        )

    buffer = watchdog.get_telemetry_buffer("tx-buffer")
    assert len(buffer) == 2
    assert buffer[0]["index"] == 1
    assert buffer[1]["index"] == 2
