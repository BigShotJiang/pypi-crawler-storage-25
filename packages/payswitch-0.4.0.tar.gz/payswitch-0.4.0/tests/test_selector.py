from __future__ import annotations

from payswitch.engine.selector import (
    PaymentMethodResolver,
    detect_available_methods_from_page_state,
)
from payswitch.models.config import PaySwitchConfig
from payswitch.models.types import PaymentMethod


def test_detect_available_methods_from_page_state_classifies_qr_and_card() -> None:
    methods = detect_available_methods_from_page_state(
        {
            "visible_text": ["请选择支付宝或微信支付，也可以使用信用卡"],
            "clickables": [{"text": "Alipay"}, {"text": "WeChat Pay"}],
            "inputs": [{"name": "cardNumber", "placeholder": "Card number"}],
        }
    )

    assert methods == [
        PaymentMethod.alipay_qr,
        PaymentMethod.wechat_qr,
        PaymentMethod.card_number_only,
    ]


def test_resolver_uses_china_default_priority() -> None:
    resolver = PaymentMethodResolver(PaySwitchConfig(allow_card_number_only=True))

    result = resolver.resolve(
        available_methods=[
            PaymentMethod.stripe,
            PaymentMethod.wechat_qr,
            PaymentMethod.alipay_qr,
        ]
    )

    assert result.selected_method == PaymentMethod.alipay_qr
    assert result.fallback_methods == [PaymentMethod.wechat_qr, PaymentMethod.stripe]


def test_resolver_blocks_card_number_only_until_enabled() -> None:
    resolver = PaymentMethodResolver(PaySwitchConfig())

    result = resolver.resolve(
        available_methods=[PaymentMethod.card_number_only],
    )

    assert result.selected_method is None
    assert result.reason == "no available method matches configured priority"


def test_resolver_allows_requested_card_number_only_when_enabled() -> None:
    resolver = PaymentMethodResolver(PaySwitchConfig(allow_card_number_only=True))

    result = resolver.resolve(
        available_methods=[PaymentMethod.card_number_only],
        requested_method=PaymentMethod.card_number_only,
    )

    assert result.selected_method == PaymentMethod.card_number_only
    assert result.reason == "requested method is available"


def test_resolver_honors_disabled_methods() -> None:
    resolver = PaymentMethodResolver(
        PaySwitchConfig(
            disabled_payment_methods=[PaymentMethod.alipay_qr],
        )
    )

    result = resolver.resolve(
        available_methods=[PaymentMethod.alipay_qr, PaymentMethod.wechat_qr],
    )

    assert result.selected_method == PaymentMethod.wechat_qr
    assert result.available_methods == [PaymentMethod.wechat_qr]
