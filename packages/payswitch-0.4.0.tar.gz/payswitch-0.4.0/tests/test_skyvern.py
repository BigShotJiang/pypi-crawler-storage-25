"""Skyvern Computer Use model configuration tests."""

from __future__ import annotations

import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from payswitch.browser import skyvern
from payswitch.browser.skyvern import SkyvernEngine, SmartModeError
from payswitch.models.config import PaySwitchConfig


def test_skyvern_uses_server_github_ai_env_when_config_key_missing(
    monkeypatch,
    tmp_path,
):
    monkeypatch.setenv("PAYSWITCH_AI_PROVIDER", "github")
    monkeypatch.setenv("PAYSWITCH_AI_MODEL", "openai/gpt-4o-mini")
    monkeypatch.setenv("GITHUB_TOKEN", "github-model-token")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("PAYSWITCH_AI_TOKEN", raising=False)
    monkeypatch.setattr(skyvern, "_OPENAI_AVAILABLE", True)

    engine = SkyvernEngine(PaySwitchConfig(data_dir=tmp_path, llm_api_key=""))

    assert engine.is_available() is True
    assert engine._provider == "github"
    assert engine._model == "openai/gpt-4o-mini"
    assert engine._api_key == "github-model-token"
    assert (
        engine._base_url
        == "https://models.github.ai/inference/chat/completions"
    )


def test_skyvern_config_key_takes_precedence_over_server_ai_env(monkeypatch, tmp_path):
    monkeypatch.setenv("PAYSWITCH_AI_PROVIDER", "github")
    monkeypatch.setenv("GITHUB_TOKEN", "github-model-token")

    config = PaySwitchConfig(data_dir=tmp_path, llm_model="gpt-4o")
    config = config.model_copy(update={"llm_api_key": "plain-config-token"})
    engine = SkyvernEngine(config)

    assert engine._provider == "openai"
    assert engine._model == "gpt-4o"
    assert engine._api_key == "plain-config-token"
    assert engine._base_url == ""


def test_openai_base_url_accepts_chat_completions_endpoint():
    assert (
        SkyvernEngine._openai_base_url(
            "https://models.github.ai/inference/chat/completions"
        )
        == "https://models.github.ai/inference"
    )


@pytest.mark.asyncio
async def test_execute_task_runs_pre_action_callback_before_action(monkeypatch, tmp_path):
    monkeypatch.setattr(skyvern, "_OPENAI_AVAILABLE", True)
    engine = SkyvernEngine(PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded-test-key"))
    engine.is_available = lambda: True  # type: ignore[method-assign]
    engine._take_screenshot = AsyncMock(return_value="img")  # type: ignore[method-assign]
    engine._call_llm = AsyncMock(  # type: ignore[method-assign]
        side_effect=[
            {
                "action": "click",
                "selector": "Subscribe",
                "value": "",
                "description": "点击订阅",
                "reasoning": "进入会员页",
            },
            {
                "action": "done",
                "selector": "",
                "value": "",
                "description": "停在支付前",
                "reasoning": "已到达边界",
            },
        ]
    )
    call_order: list[str] = []

    async def _callback(page, action, step_index, history):
        del page, history
        call_order.append(f"callback:{step_index}:{action['action']}")

    async def _execute(page, action):
        del page
        call_order.append(f"execute:{action['action']}")
        return True

    engine._execute_llm_action = AsyncMock(side_effect=_execute)  # type: ignore[method-assign]
    mock_detector = MagicMock()
    mock_detector.scan = AsyncMock(return_value=None)
    monkeypatch.setitem(
        sys.modules,
        "payswitch.browser.detector",
        SimpleNamespace(DetectorPipeline=lambda: mock_detector),
    )

    steps = await engine.execute_task(
        page=MagicMock(),
        task_description="go to checkout",
        max_steps=2,
        pre_action_callback=_callback,
    )

    assert len(steps) == 2
    assert call_order == ["callback:0:click", "execute:click"]


@pytest.mark.asyncio
async def test_execute_task_blocks_when_pre_action_callback_raises(monkeypatch, tmp_path):
    monkeypatch.setattr(skyvern, "_OPENAI_AVAILABLE", True)
    engine = SkyvernEngine(PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded-test-key"))
    engine.is_available = lambda: True  # type: ignore[method-assign]
    engine._take_screenshot = AsyncMock(return_value="img")  # type: ignore[method-assign]
    engine._call_llm = AsyncMock(  # type: ignore[method-assign]
        return_value={
            "action": "click",
            "selector": "Continue",
            "value": "",
            "description": "点击继续",
            "reasoning": "准备支付",
        }
    )
    engine._execute_llm_action = AsyncMock(return_value=True)  # type: ignore[method-assign]
    mock_detector = MagicMock()
    mock_detector.scan = AsyncMock(return_value=None)
    monkeypatch.setitem(
        sys.modules,
        "payswitch.browser.detector",
        SimpleNamespace(DetectorPipeline=lambda: mock_detector),
    )

    async def _callback(_page, _action, _step_index, _history):
        raise SmartModeError("blocked before action")

    with pytest.raises(SmartModeError, match="blocked before action"):
        await engine.execute_task(
            page=MagicMock(),
            task_description="go to checkout",
            max_steps=1,
            pre_action_callback=_callback,
        )

    engine._execute_llm_action.assert_not_awaited()
