"""PaySwitchConfig 新增浏览器字段测试。

browser_engine / browser_humanize / browser_human_preset.
"""

from __future__ import annotations

import pytest

from payswitch.models.config import PaySwitchConfig


def test_defaults_are_backward_compatible() -> None:
    """默认配置必须保持 v0.2.x 行为。"""
    cfg = PaySwitchConfig()
    assert cfg.browser_engine == "playwright"
    assert cfg.browser_humanize is False
    assert cfg.browser_human_preset == "default"


def test_browser_engine_accepts_cloakbrowser() -> None:
    cfg = PaySwitchConfig(browser_engine="cloakbrowser")
    assert cfg.browser_engine == "cloakbrowser"


def test_browser_engine_is_case_insensitive() -> None:
    """大小写 + 空格都能用。"""
    assert PaySwitchConfig(browser_engine="PLAYWRIGHT").browser_engine == "playwright"
    assert (
        PaySwitchConfig(browser_engine=" CloakBrowser ").browser_engine
        == "cloakbrowser"
    )


def test_browser_engine_rejects_unknown() -> None:
    with pytest.raises(ValueError, match="browser_engine 不支持"):
        PaySwitchConfig(browser_engine="firefox")


def test_browser_human_preset_accepts_careful() -> None:
    cfg = PaySwitchConfig(browser_human_preset="careful")
    assert cfg.browser_human_preset == "careful"


def test_browser_human_preset_rejects_unknown() -> None:
    with pytest.raises(ValueError, match="browser_human_preset 不支持"):
        PaySwitchConfig(browser_human_preset="yolo")


def test_model_dump_contains_new_keys() -> None:
    """CLI config 命令基于 model_dump 动态查 key。"""
    import json

    data = json.loads(PaySwitchConfig().model_dump_json())
    assert "browser_engine" in data
    assert "browser_humanize" in data
    assert "browser_human_preset" in data
