from __future__ import annotations

from pathlib import Path

import pytest

from payswitch.experience import ExperienceStore, RecipePatchState, get_recipe
from payswitch.experience.models import RecoveryImprovementStatus


def _store(tmp_path: Path) -> ExperienceStore:
    return ExperienceStore(tmp_path / "experience" / "recipes.db")


def test_candidate_patch_cannot_affect_mainline_before_shadow_run(tmp_path: Path) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patched = builtin.model_copy(deep=True)
    patched.version = "1.1.0"
    patched.notes.append("candidate patch")

    patch_id = store.register_patch(recipe=patched, source="computer_use")

    assert get_recipe("kimi", "membership_monthly_qr", store=store).version == "1.0.0"
    with pytest.raises(ValueError, match="cannot become mainline"):
        store.update_patch_state(patch_id, state=RecipePatchState.mainline)

    store.mark_shadow_run_success(patch_id)
    store.update_patch_state(patch_id, state=RecipePatchState.mainline)

    resolved = get_recipe("kimi", "membership_monthly_qr", store=store)
    assert resolved is not None
    assert resolved.version == "1.1.0"


def test_reviewed_patch_can_be_promoted_without_shadow_run(tmp_path: Path) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    reviewed = builtin.model_copy(deep=True)
    reviewed.version = "1.2.0"

    patch_id = store.register_patch(recipe=reviewed, source="human_review")
    store.update_patch_state(
        patch_id,
        state=RecipePatchState.reviewed,
        metadata={"reviewed_by": "qa"},
    )
    store.update_patch_state(patch_id, state=RecipePatchState.mainline)

    patch = store.get_patch(patch_id)
    assert patch["state"] == RecipePatchState.mainline.value
    assert patch["metadata"]["reviewed_by"] == "qa"


def test_patch_recipe_update_and_filtered_listing(tmp_path: Path) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    candidate = builtin.model_copy(deep=True)
    candidate.notes.append("initial candidate")
    patch_id = store.register_patch(recipe=candidate, source="script_recovery")

    updated = candidate.model_copy(deep=True)
    updated.start_urls.append("https://www.kimi.com/membership/pricing")
    store.update_patch_recipe(
        patch_id,
        recipe=updated,
        metadata={"recovery_outcome": "scan_qr"},
    )
    store.review_patch(patch_id, reviewer="qa", note="looks good")

    reviewed = store.list_patches(
        platform="kimi",
        flow="membership_monthly_qr",
        state=RecipePatchState.reviewed,
        source="script_recovery",
    )
    assert len(reviewed) == 1
    assert reviewed[0]["id"] == patch_id
    assert reviewed[0]["metadata"]["recovery_outcome"] == "scan_qr"
    assert reviewed[0]["metadata"]["reviewed_by"] == "qa"
    assert reviewed[0]["recipe"].start_urls[-1] == "https://www.kimi.com/membership/pricing"


def test_store_records_recipe_outcomes(tmp_path: Path) -> None:
    store = _store(tmp_path)
    store.record_outcome(
        platform="kimi",
        flow="membership_monthly_qr",
        recipe_id="kimi.membership_monthly_qr",
        recipe_version="1.0.0",
        succeeded=False,
        confidence=0.86,
        details={"waypoint_id": "select_monthly_plan"},
    )
    store.record_outcome(
        platform="kimi",
        flow="membership_monthly_qr",
        recipe_id="kimi.membership_monthly_qr",
        recipe_version="1.0.0",
        succeeded=True,
        confidence=0.86,
        details={"step_count": 7},
    )

    outcomes = store.list_outcomes(platform="kimi", flow="membership_monthly_qr")
    assert len(outcomes) == 2
    assert outcomes[0]["succeeded"] is False
    assert outcomes[0]["details"]["waypoint_id"] == "select_monthly_plan"
    assert outcomes[1]["succeeded"] is True
    assert outcomes[1]["details"]["step_count"] == 7


def test_patch_queue_reports_promotion_readiness(tmp_path: Path) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    candidate_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    shadow_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    reviewed_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="human_review",
    )

    store.mark_shadow_run_success(shadow_id)
    store.review_patch(reviewed_id, reviewer="qa")

    queue = store.list_patch_queue(platform="kimi", flow="membership_monthly_qr")
    readiness = {entry["id"]: entry for entry in queue}

    assert readiness[candidate_id]["promotion_ready"] is False
    assert readiness[candidate_id]["blocking_reasons"] == ["needs_review_or_shadow_run"]
    assert readiness[shadow_id]["promotion_ready"] is True
    assert readiness[shadow_id]["promotion_basis"] == "shadow_run_success"
    assert readiness[reviewed_id]["promotion_ready"] is True
    assert readiness[reviewed_id]["promotion_basis"] == "reviewed"


def test_promote_ready_patches_supports_dry_run_and_basis_filters(tmp_path: Path) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    shadow_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    reviewed_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="human_review",
    )

    store.mark_shadow_run_success(shadow_id)
    store.review_patch(reviewed_id, reviewer="qa")

    dry_run = store.promote_ready_patches(
        platform="kimi",
        flow="membership_monthly_qr",
        basis="reviewed",
        actor="ops",
        note="batch preview",
        dry_run=True,
    )
    assert [entry["id"] for entry in dry_run] == [reviewed_id]
    assert dry_run[0]["state"] == "reviewed"
    assert dry_run[0]["dry_run"] is True
    assert store.get_patch(reviewed_id)["state"] == RecipePatchState.reviewed.value

    promoted = store.promote_ready_patches(
        platform="kimi",
        flow="membership_monthly_qr",
        actor="ops",
        note="batch promote",
    )
    assert [entry["id"] for entry in promoted] == [shadow_id, reviewed_id]
    shadow_patch = store.get_patch(shadow_id)
    reviewed_patch = store.get_patch(reviewed_id)
    assert shadow_patch["state"] == RecipePatchState.mainline.value
    assert reviewed_patch["state"] == RecipePatchState.mainline.value
    assert shadow_patch["metadata"]["promotion_basis"] == "shadow_run_success"
    assert reviewed_patch["metadata"]["promotion_basis"] == "reviewed"
    assert reviewed_patch["metadata"]["promoted_by"] == "ops"


def test_promote_ready_patches_respects_limit(tmp_path: Path) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    first_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    second_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(first_id)
    store.mark_shadow_run_success(second_id)

    promoted = store.promote_ready_patches(
        platform="kimi",
        flow="membership_monthly_qr",
        actor="ops",
        limit=1,
    )
    assert [entry["id"] for entry in promoted] == [first_id]
    assert store.get_patch(first_id)["state"] == RecipePatchState.mainline.value
    assert store.get_patch(second_id)["state"] == RecipePatchState.shadow_run.value


def test_patch_queue_and_promotion_can_require_multiple_shadow_runs(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(patch_id)

    queue = store.list_patch_queue(
        platform="kimi",
        flow="membership_monthly_qr",
        min_shadow_runs=2,
    )
    assert queue[0]["promotion_ready"] is False
    assert queue[0]["shadow_run_count"] == 1
    assert queue[0]["blocking_reasons"] == ["needs_more_shadow_runs:1/2"]

    preview = store.promote_ready_patches(
        platform="kimi",
        flow="membership_monthly_qr",
        basis="shadow_run_success",
        actor="ops",
        dry_run=True,
        min_shadow_runs=2,
    )
    assert preview == []

    store.mark_shadow_run_success(patch_id)
    promoted = store.promote_ready_patches(
        platform="kimi",
        flow="membership_monthly_qr",
        basis="shadow_run_success",
        actor="ops",
        min_shadow_runs=2,
    )
    assert [entry["id"] for entry in promoted] == [patch_id]
    assert promoted[0]["shadow_run_count"] == 2
    assert store.get_patch(patch_id)["state"] == RecipePatchState.mainline.value


def test_recovery_improvement_queue_records_and_updates_status(tmp_path: Path) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-123",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-123-patch-1.json",
        summary={
            "outcome": "scan_qr",
            "waypoint_id": "select_monthly_plan",
        },
    )

    queue = store.list_recovery_improvements(
        status=RecoveryImprovementStatus.open,
        platform="kimi",
    )
    assert [entry["id"] for entry in queue] == [improvement_id]
    assert queue[0]["summary"]["outcome"] == "scan_qr"

    store.update_recovery_improvement_status(
        improvement_id,
        status=RecoveryImprovementStatus.accepted,
        reviewer="qa",
        note="promote later",
    )
    updated = store.get_recovery_improvement(improvement_id)
    assert updated["status"] == RecoveryImprovementStatus.accepted.value
    assert updated["metadata"]["reviewed_by"] == "qa"
    assert updated["metadata"]["review_note"] == "promote later"


def test_accept_open_recovery_improvements_respects_shadow_run_policy(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    blocked_patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    accepted_patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(accepted_patch_id)

    blocked_improvement_id = store.record_recovery_improvement(
        patch_id=blocked_patch_id,
        tx_id="tx-blocked",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-blocked-patch-1.json",
        summary={"outcome": "scan_qr"},
    )
    accepted_improvement_id = store.record_recovery_improvement(
        patch_id=accepted_patch_id,
        tx_id="tx-accepted",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-accepted-patch-2.json",
        summary={"outcome": "scan_qr"},
    )

    preview = store.accept_open_recovery_improvements(
        reviewer="watchdog",
        basis="shadow_run_success",
        dry_run=True,
    )
    actions = {entry["improvement_id"]: entry for entry in preview}
    assert actions[blocked_improvement_id]["action"] == "blocked"
    assert actions[accepted_improvement_id]["action"] == "accepted"
    assert store.get_recovery_improvement(accepted_improvement_id)["status"] == "open"

    results = store.accept_open_recovery_improvements(
        reviewer="watchdog",
        note="nightly auto accept",
        basis="shadow_run_success",
    )
    actions = {entry["improvement_id"]: entry for entry in results}
    assert actions[blocked_improvement_id]["improvement_status_after"] == "open"
    assert actions[accepted_improvement_id]["improvement_status_after"] == "accepted"
    accepted = store.get_recovery_improvement(accepted_improvement_id)
    assert accepted["status"] == RecoveryImprovementStatus.accepted.value
    assert accepted["metadata"]["accepted_basis"] == "shadow_run_success"
    assert accepted["metadata"]["accepted_via"] == "open_queue_acceptor"


def test_process_accepted_recovery_improvements_reviews_patch(tmp_path: Path) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-123",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-123-patch-1.json",
        summary={"outcome": "scan_qr"},
    )
    store.update_recovery_improvement_status(
        improvement_id,
        status=RecoveryImprovementStatus.accepted,
        reviewer="qa",
        note="accepted for recipe review",
    )

    preview = store.process_accepted_recovery_improvements(
        reviewer="watchdog",
        dry_run=True,
    )
    assert preview[0]["patch_state_after"] == RecipePatchState.reviewed.value
    assert store.get_patch(patch_id)["state"] == RecipePatchState.candidate.value

    results = store.process_accepted_recovery_improvements(
        reviewer="watchdog",
        note="background apply",
    )
    assert results[0]["action"] == "review_patch"
    patch = store.get_patch(patch_id)
    improvement = store.get_recovery_improvement(improvement_id)
    assert patch["state"] == RecipePatchState.reviewed.value
    assert patch["metadata"]["improvement_id"] == improvement_id
    assert improvement["status"] == RecoveryImprovementStatus.applied.value


def test_process_accepted_recovery_improvements_marks_applied_for_reviewed_patch(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.review_patch(patch_id, reviewer="qa")
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-456",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-456-patch-1.json",
        summary={"outcome": "completed"},
    )
    store.update_recovery_improvement_status(
        improvement_id,
        status=RecoveryImprovementStatus.accepted,
        reviewer="qa",
        note="already reviewed",
    )

    results = store.process_accepted_recovery_improvements(reviewer="watchdog")
    assert results[0]["action"] == "already_reviewed"


def test_accept_open_recovery_improvements_respects_min_shadow_runs(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(patch_id)
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-shadow-threshold",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-shadow-threshold.json",
        summary={"outcome": "scan_qr"},
    )

    blocked = store.accept_open_recovery_improvements(
        reviewer="ops",
        platform="kimi",
        flow="membership_monthly_qr",
        basis="shadow_run_success",
        min_shadow_runs=2,
        dry_run=True,
    )
    assert blocked[0]["action"] == "blocked"
    assert blocked[0]["blocking_reasons"] == ["needs_more_shadow_runs:1/2"]

    store.mark_shadow_run_success(patch_id)
    accepted = store.accept_open_recovery_improvements(
        reviewer="ops",
        platform="kimi",
        flow="membership_monthly_qr",
        basis="shadow_run_success",
        min_shadow_runs=2,
    )
    assert accepted[0]["action"] == "accepted"
    assert accepted[0]["shadow_run_count"] == 2
    assert store.get_recovery_improvement(improvement_id)["status"] == "accepted"
