import json

from payswitch.engine.events import RuntimeEventSink, safe_session_id
from payswitch.models.config import PaySwitchConfig


def test_runtime_event_sink_writes_frontend_compatible_jsonl(tmp_path):
    config = PaySwitchConfig(data_dir=tmp_path)
    sink = RuntimeEventSink(config)

    event = sink.emit(
        "txn/unsafe id",
        "action.allowed",
        "允许点击充值按钮",
        "BrowserController 已执行。",
        path=["External Agent", "Pay-Switch", "Browser"],
        risk="medium",
        target="button:充值",
    )

    assert event["type"] == "action.allowed"
    assert event["id"].startswith("evt_")
    assert "[REDACTED" not in event["id"]
    assert event["summary"] == "允许点击充值按钮"
    assert event["path"] == ["External Agent", "Pay-Switch", "Browser"]
    assert safe_session_id("txn/unsafe id") == "txn_unsafe_id"

    log_path = sink.event_log_path("txn/unsafe id")
    payload = json.loads(log_path.read_text(encoding="utf-8").strip())
    assert payload["session_id"] == "txn/unsafe id"
    assert payload["risk"] == "medium"
