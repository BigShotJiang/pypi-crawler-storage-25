from __future__ import annotations

import asyncio
from pathlib import Path

from payswitch.experience import (
    ExperienceStore,
    ReadyPatchPromotionRunner,
    ReadyPatchPromotionSupervisor,
    get_recipe,
)


def _store(tmp_path: Path) -> ExperienceStore:
    return ExperienceStore(tmp_path / "experience" / "recipes.db")


def test_ready_patch_promotion_runner_run_once_promotes_ready_patch(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(patch_id)

    runner = ReadyPatchPromotionRunner(
        store,
        basis="shadow_run_success",
        poll_interval_seconds=0,
        batch_limit=10,
        max_idle_polls=2,
    )
    result = runner.run_once(actor="watchdog")
    assert result.promoted == 1
    assert store.get_patch(patch_id)["state"] == "mainline"


def test_ready_patch_promotion_runner_respects_min_shadow_runs(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(patch_id)

    runner = ReadyPatchPromotionRunner(
        store,
        basis="shadow_run_success",
        min_shadow_runs=2,
        poll_interval_seconds=0,
        batch_limit=10,
        max_idle_polls=2,
    )
    blocked = runner.run_once(actor="watchdog")
    assert blocked.promoted == 0
    assert store.get_patch(patch_id)["state"] == "shadow_run"

    store.mark_shadow_run_success(patch_id)
    promoted = runner.run_once(actor="watchdog")
    assert promoted.promoted == 1
    assert store.get_patch(patch_id)["state"] == "mainline"


def test_ready_patch_promotion_runner_run_loop_stops_after_idle_polls(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    sleeps: list[float] = []
    runner = ReadyPatchPromotionRunner(
        store,
        poll_interval_seconds=1.5,
        batch_limit=5,
        max_idle_polls=2,
        sleep_fn=sleeps.append,
    )

    summary = runner.run_loop(actor="watchdog", max_cycles=4)
    assert summary["cycles"] == 2
    assert summary["idle_polls"] == 2
    assert summary["total_promoted"] == 0
    assert sleeps == [1.5]


def test_ready_patch_promotion_supervisor_updates_snapshot(
    tmp_path: Path,
) -> None:
    async def _exercise() -> None:
        store = _store(tmp_path)
        builtin = get_recipe("kimi", "membership_monthly_qr")
        assert builtin is not None

        patch_id = store.register_patch(
            recipe=builtin.model_copy(deep=True),
            source="script_recovery",
        )
        store.mark_shadow_run_success(patch_id)

        supervisor = ReadyPatchPromotionSupervisor(
            store,
            actor="promoter",
            basis="shadow_run_success",
            poll_interval_seconds=0.01,
            batch_limit=5,
        )
        await supervisor.start()
        try:
            for _ in range(50):
                snapshot = supervisor.snapshot()
                if int(snapshot["total_promoted"]) >= 1:
                    break
                await asyncio.sleep(0.01)
            else:
                raise AssertionError("supervisor did not promote ready patches")
        finally:
            await supervisor.stop()

        snapshot = supervisor.snapshot()
        assert snapshot["enabled"] is True
        assert snapshot["running"] is False
        assert snapshot["basis"] == "shadow_run_success"
        assert snapshot["min_shadow_runs"] == 1
        assert int(snapshot["cycles"]) >= 1
        assert int(snapshot["total_promoted"]) >= 1
        assert store.get_patch(patch_id)["state"] == "mainline"

    asyncio.run(_exercise())
