"""Browser runtime backend planning tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from payswitch.browser.chrome_profiles import ChromeProfileIdentity
from payswitch.browser.runtime import (
    BrowserRuntimeConfigError,
    build_browser_runtime_plan,
    resolve_browser_backend,
)
from payswitch.models.config import PaySwitchConfig
from payswitch.models.types import BrowserControlBackend


def test_auto_backend_prefers_cdp() -> None:
    config = PaySwitchConfig(
        chrome_cdp_url="http://127.0.0.1:9222",
        chrome_user_data_dir="/tmp/chrome",
    )

    assert resolve_browser_backend(config) == BrowserControlBackend.cdp
    with patch(
        "payswitch.browser.runtime.is_cdp_url_ready",
        return_value=True,
    ), patch(
        "payswitch.browser.runtime.resolve_cdp_profile_identity",
        return_value=None,
    ):
        plan = build_browser_runtime_plan(config)

    assert plan.backend == BrowserControlBackend.cdp
    assert plan.uses_user_chrome is True
    assert plan.launch_kwargs["chrome_cdp_url"] == "http://127.0.0.1:9222"
    assert "chrome_user_data_dir" not in plan.launch_kwargs


def test_auto_backend_uses_cdp_for_bound_real_profile(tmp_path: Path) -> None:
    chrome_root = tmp_path / "Chrome"
    profile = chrome_root / "Profile 8"
    profile.mkdir(parents=True)
    config = PaySwitchConfig(
        chrome_user_data_dir=str(chrome_root),
        chrome_profile_directory="Profile 8",
    )

    assert resolve_browser_backend(config) == BrowserControlBackend.cdp
    with patch(
        "payswitch.browser.runtime.find_matching_chrome_debugging_process",
        return_value=None,
    ), patch(
        "payswitch.browser.runtime.resolve_profile_identity",
        return_value=None,
    ):
        plan = build_browser_runtime_plan(config)

    assert plan.backend == BrowserControlBackend.cdp
    assert plan.uses_user_chrome is True
    assert "chrome_cdp_url" not in plan.launch_kwargs


def test_cdp_backend_can_ensure_real_profile_url(tmp_path: Path) -> None:
    chrome_root = tmp_path / "Chrome"
    profile = chrome_root / "Profile 8"
    profile.mkdir(parents=True)
    identity = ChromeProfileIdentity(
        user_data_dir=chrome_root,
        profile_directory="Profile 8",
        name="g leon",
        user_name="g4426468@gmail.com",
        gaia_name="g leon",
    )
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.cdp,
        chrome_user_data_dir=str(chrome_root),
        chrome_profile_directory="Profile 8",
        chrome_expected_profile_email="g4426468@gmail.com",
    )

    with patch(
        "payswitch.browser.runtime.ensure_profile_cdp_url",
        return_value="http://127.0.0.1:9244",
    ) as ensure_cdp, patch(
        "payswitch.browser.runtime.is_cdp_url_ready",
        return_value=True,
    ), patch(
        "payswitch.browser.runtime.resolve_cdp_profile_identity",
        return_value=identity,
    ):
        plan = build_browser_runtime_plan(config, ensure_cdp=True)

    ensure_cdp.assert_called_once()
    assert plan.backend == BrowserControlBackend.cdp
    assert plan.launch_kwargs["chrome_cdp_url"] == "http://127.0.0.1:9244"
    assert plan.identity == identity


def test_configured_dead_cdp_url_is_rejected_without_ensure() -> None:
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.cdp,
        chrome_cdp_url="http://127.0.0.1:54036",
    )

    with patch(
        "payswitch.browser.runtime.is_cdp_url_ready",
        return_value=False,
    ), pytest.raises(BrowserRuntimeConfigError, match="不可连接"):
        build_browser_runtime_plan(config, ensure_cdp=False)


def test_cdp_backend_rejects_isolated_runtime_identity(tmp_path: Path) -> None:
    isolated_root = (
        tmp_path
        / ".paperclip"
        / "runtime"
        / "browser-profiles"
        / "direct-Profile_32"
    )
    identity = ChromeProfileIdentity(
        user_data_dir=isolated_root,
        profile_directory="Profile 32",
        name="isolated",
        user_name="",
        gaia_name="",
    )
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.cdp,
        chrome_cdp_url="http://127.0.0.1:9238",
    )

    with patch(
        "payswitch.browser.runtime.is_cdp_url_ready",
        return_value=True,
    ), patch(
        "payswitch.browser.runtime.resolve_cdp_profile_identity",
        return_value=identity,
    ), pytest.raises(BrowserRuntimeConfigError, match="隔离/镜像 Chrome profile"):
        build_browser_runtime_plan(config)


def test_cdp_backend_rejects_isolated_configured_user_data_dir(
    tmp_path: Path,
) -> None:
    isolated_root = (
        tmp_path
        / ".paperclip"
        / "runtime"
        / "browser-profiles"
        / "direct-Profile_32"
    )
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.cdp,
        chrome_user_data_dir=str(isolated_root),
        chrome_profile_directory="Profile 32",
    )

    with pytest.raises(BrowserRuntimeConfigError, match="隔离/镜像 Chrome profile"):
        build_browser_runtime_plan(config)


def test_managed_backend_ignores_real_profile_config() -> None:
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.managed_profile,
        chrome_user_data_dir="/tmp/chrome",
        chrome_profile_directory="Profile 10",
        chrome_expected_profile_email="user@example.com",
    )

    plan = build_browser_runtime_plan(config)

    assert plan.backend == BrowserControlBackend.managed_profile
    assert plan.uses_user_chrome is False
    assert plan.uses_managed_profile is True
    assert plan.launch_kwargs == {}


def test_user_profile_backend_requires_user_data_dir() -> None:
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.user_profile,
    )

    with pytest.raises(BrowserRuntimeConfigError, match="chrome_user_data_dir"):
        build_browser_runtime_plan(config)


def test_user_profile_backend_reports_occupancy(tmp_path: Path) -> None:
    chrome_root = tmp_path / "Chrome"
    chrome_root.mkdir()
    active_process = type(
        "ActiveProcess",
        (),
        {"remote_debugging_port": "9224"},
    )()
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.user_profile,
        chrome_user_data_dir=str(chrome_root),
    )

    with patch(
        "payswitch.browser.runtime.find_active_chrome_user_data_process",
        return_value=active_process,
    ), patch(
        "payswitch.browser.runtime.resolve_profile_identity",
        return_value=None,
    ):
        plan = build_browser_runtime_plan(config, preflight_occupancy=True)

    assert plan.occupied is True
    assert plan.remote_debugging_port == "9224"


def test_ephemeral_cdp_mirror_backend_uses_source_profile(tmp_path: Path) -> None:
    chrome_root = tmp_path / "Chrome"
    profile = chrome_root / "Profile 10"
    profile.mkdir(parents=True)
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.ephemeral_cdp_mirror,
        chrome_user_data_dir=str(chrome_root),
        chrome_profile_directory="Profile 10",
    )

    with patch(
        "payswitch.browser.runtime.resolve_profile_identity",
        return_value=None,
    ):
        plan = build_browser_runtime_plan(config)

    assert plan.backend == BrowserControlBackend.ephemeral_cdp_mirror
    assert plan.uses_user_chrome is True
    assert plan.launch_kwargs["ephemeral_cdp_mirror_source_user_data_dir"] == chrome_root
    assert plan.launch_kwargs["ephemeral_cdp_mirror_profile_directory"] == "Profile 10"
    assert plan.launch_kwargs["browser_channel"] == "chrome"


def test_ephemeral_cdp_mirror_backend_requires_user_data_dir() -> None:
    config = PaySwitchConfig(
        browser_control_backend=BrowserControlBackend.ephemeral_cdp_mirror,
    )

    with pytest.raises(BrowserRuntimeConfigError, match="chrome_user_data_dir"):
        build_browser_runtime_plan(config)
