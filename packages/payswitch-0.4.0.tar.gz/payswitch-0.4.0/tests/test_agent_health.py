from __future__ import annotations

from pathlib import Path

from payswitch.server import _health_payload, _novnc_url


def test_novnc_url_uses_public_override(monkeypatch):
    monkeypatch.setenv("PAYSWITCH_PUBLIC_NOVNC_URL", "https://viewer.example/vnc.html")

    assert _novnc_url(scheme="http", host="127.0.0.1", port=6080) == (
        "https://viewer.example/vnc.html"
    )


def test_novnc_url_builds_default_viewer_query(monkeypatch):
    monkeypatch.delenv("PAYSWITCH_PUBLIC_NOVNC_URL", raising=False)
    monkeypatch.setenv("PAYSWITCH_NOVNC_PATH", "vnc.html")

    assert _novnc_url(scheme="https", host="pay.example", port=6081) == (
        "https://pay.example:6081/vnc.html?autoconnect=true&resize=scale"
    )


def test_health_payload_reports_configured_live_computer(monkeypatch, tmp_path: Path):
    from payswitch.models.config import PaySwitchConfig

    cfg = PaySwitchConfig(
        browser_engine="cloakbrowser",
        browser_humanize=True,
        data_dir=tmp_path / "data",
    )

    novnc_web = tmp_path / "novnc"
    novnc_web.mkdir()
    monkeypatch.setattr("payswitch.server.PaySwitchConfig.load", lambda: cfg)
    monkeypatch.setenv("PAYSWITCH_DISPLAY", ":77")
    monkeypatch.setenv("PAYSWITCH_NOVNC_PORT", "6087")
    monkeypatch.setenv("PAYSWITCH_NOVNC_WEB", str(novnc_web))
    monkeypatch.delenv("PAYSWITCH_PUBLIC_NOVNC_URL", raising=False)

    payload = _health_payload()

    assert payload["computer_use"]["display"] == ":77"
    assert payload["computer_use"]["browser_engine"] == "cloakbrowser"
    assert payload["computer_use"]["humanize"] is True
    assert payload["computer_use"]["novnc_dependencies"]["novnc_web"] is True
    assert payload["computer_use"]["novnc_url"].startswith("http://127.0.0.1:6087/")
