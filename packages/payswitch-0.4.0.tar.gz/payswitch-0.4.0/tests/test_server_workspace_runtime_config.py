import pytest

from payswitch.server import build_workspace_manager_from_env


def test_build_workspace_manager_from_env_defaults_to_in_process(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("PAYSWITCH_WORKSPACE_RUNTIME_BACKEND", raising=False)
    monkeypatch.delenv("PAYSWITCH_WORKSPACE_CONTAINER_DRIVER", raising=False)
    monkeypatch.delenv("PAYSWITCH_WORKSPACE_CONTAINER_IMAGE", raising=False)

    manager = build_workspace_manager_from_env()

    assert manager.runtime_backend == "in_process"


def test_build_workspace_manager_from_env_supports_container_backend(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("PAYSWITCH_WORKSPACE_RUNTIME_BACKEND", "container")
    monkeypatch.setenv("PAYSWITCH_WORKSPACE_CONTAINER_DRIVER", "in_memory")
    monkeypatch.setenv(
        "PAYSWITCH_WORKSPACE_CONTAINER_IMAGE",
        "ghcr.io/example/payswitch-runtime:test",
    )

    manager = build_workspace_manager_from_env()

    assert manager.runtime_backend == "container"
    assert manager.container_driver_kind == "in_memory"
