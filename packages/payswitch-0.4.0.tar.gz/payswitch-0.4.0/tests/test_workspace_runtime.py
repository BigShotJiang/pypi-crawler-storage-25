import asyncio

import pytest

from payswitch.agent_language import PaymentIntent
from payswitch.agent_workspace import AgentWorkspaceManager
from payswitch.workspace_container_driver import InMemoryWorkspaceContainerDriver
from payswitch.workspace_runtime import (
    ContainerWorkspaceRuntime,
    InProcessWorkspaceRuntime,
    RuntimePolicy,
    WorkspaceRuntimeFactory,
)


def _intent(user_id: str, payee: str = "kimi") -> PaymentIntent:
    return PaymentIntent(
        amount=10,
        currency="CNY",
        payee=payee,
        reason=f"{payee} runtime boundary",
        method="alipay_qr",
        source_agent="codex",
        metadata={"user_id": user_id},
    )


def test_workspace_runtime_factory_defaults_to_in_process_backend() -> None:
    runtime = WorkspaceRuntimeFactory().create_runtime(
        workspace_id="uws_alice",
        user_id="alice",
        policy=RuntimePolicy(),
    )

    assert isinstance(runtime, InProcessWorkspaceRuntime)
    assert runtime.runtime_backend == "in_process"


def test_workspace_runtime_factory_can_create_container_runtime_skeleton() -> None:
    driver = InMemoryWorkspaceContainerDriver()
    runtime = WorkspaceRuntimeFactory(
        backend="container",
        container_image="ghcr.io/example/payswitch-runtime:test",
        container_driver=driver,
    ).create_runtime(
        workspace_id="uws_alice",
        user_id="alice",
        policy=RuntimePolicy(runtime_idle_seconds=60, runtime_memory_mb=512),
    )

    assert isinstance(runtime, ContainerWorkspaceRuntime)
    assert runtime.runtime_backend == "container"
    runtime.wake()
    snapshot = runtime.snapshot()
    assert snapshot["runtime_backend"] == "container"
    assert snapshot["container_image"] == "ghcr.io/example/payswitch-runtime:test"
    assert str(snapshot["container_id"]).startswith("ctr_")
    assert str(snapshot["profile_volume_name"]).startswith("uvol_")
    assert str(snapshot["novnc_route_key"]).startswith("vroute_")
    assert snapshot["container_driver"] == "in_memory"
    assert snapshot["container_status"] == "running"


def test_container_runtime_marks_sleeping_and_destroyed_through_driver() -> None:
    runtime = ContainerWorkspaceRuntime(
        workspace_id="uws_alice",
        user_id="alice",
        policy=RuntimePolicy(runtime_idle_seconds=60, runtime_memory_mb=512),
        container_image="ghcr.io/example/payswitch-runtime:test",
        container_driver=InMemoryWorkspaceContainerDriver(),
    )

    runtime.wake()
    running = runtime.snapshot()
    assert running["container_status"] == "running"

    runtime.mark_sleeping()
    sleeping = runtime.snapshot()
    assert sleeping["runtime_status"] == "sleeping"
    assert sleeping["container_status"] == "stopped"
    assert sleeping["container_stopped_at"] is not None

    runtime.mark_destroyed(reason="test_cleanup")
    destroyed = runtime.snapshot()
    assert destroyed["runtime_status"] == "destroyed"
    assert destroyed["container_status"] == "destroyed"


def test_runtime_snapshot_tracks_active_browser_selection_and_focus_lock() -> None:
    runtime = InProcessWorkspaceRuntime(
        workspace_id="uws_alice",
        user_id="alice",
        policy=RuntimePolicy(runtime_idle_seconds=60, runtime_memory_mb=256),
    )

    runtime.attach_session("task_a", "bctx_a")
    runtime.assign_display_surface(
        "task_a",
        state="visible_surface_ready",
        ready=True,
        reason="operator_select",
        browser_context_id="bctx_a",
    )
    locked = runtime.begin_visible_action(
        "task_a",
        browser_context_id="bctx_a",
        action="computer_use",
    )
    snapshot = runtime.snapshot()

    assert locked["allowed"] is True
    assert snapshot["browser_manager_state"] == "focus_locked"
    assert snapshot["active_browser_context_id"] == "bctx_a"
    assert snapshot["active_browser_task_id"] == "task_a"
    assert str(snapshot["display_focus_lock_id"]).startswith("vlock_")


def test_workspace_runtime_factory_rejects_unsupported_backend() -> None:
    factory = WorkspaceRuntimeFactory(backend="in_process")  # type: ignore[arg-type]
    object.__setattr__(factory, "backend", "bogus")

    with pytest.raises(ValueError, match="unsupported workspace runtime backend"):
        factory.create_runtime(
            workspace_id="uws_alice",
            user_id="alice",
            policy=RuntimePolicy(),
        )


@pytest.mark.asyncio
async def test_runtime_sleep_and_resume_reuse_same_workspace_runtime() -> None:
    manager = AgentWorkspaceManager(runtime_idle_seconds=0.01)
    first = await manager.start_session("task_a", _intent("alice", "kimi"))
    try:
        before = await manager.list_workspaces(user_id="alice")
        assert before[0]["runtime_status"] == "active"
        runtime_id = before[0]["runtime_id"]
    finally:
        await first.release()

    await asyncio.sleep(0.03)
    sleeping = await manager.list_workspaces(user_id="alice")
    assert sleeping[0]["runtime_status"] == "sleeping"

    second = await manager.start_session("task_b", _intent("alice", "jimeng"))
    try:
        resumed = await manager.list_workspaces(user_id="alice")
        assert resumed[0]["runtime_status"] == "active"
        assert resumed[0]["runtime_id"] == runtime_id
    finally:
        await second.release()


@pytest.mark.asyncio
async def test_runtime_admission_queues_new_user_when_active_capacity_is_full() -> None:
    manager = AgentWorkspaceManager(max_active_workspaces=1, runtime_idle_seconds=1)
    first = await manager.start_session("task_a", _intent("alice", "kimi"))
    second_task = asyncio.create_task(manager.start_session("task_b", _intent("bob", "kimi")))

    try:
        await asyncio.sleep(0.01)
        assert not second_task.done()
        queued = await manager.get_session("task_b")
        assert queued is not None
        assert queued.status == "queued"
        assert queued.queued_reason == "workspace_admission"

        health = await manager.runtime_health()
        assert health["host"]["active_workspaces"] == 1
        assert health["host"]["queued_admissions"] == 1

        await first.release()
        second = await asyncio.wait_for(second_task, timeout=1)
        try:
            assert second.workspace_id != first.workspace_id
        finally:
            await second.release()
    finally:
        if not first.released:
            await first.release()
        if not second_task.done():
            second_task.cancel()


@pytest.mark.asyncio
async def test_runtime_reclaims_warm_workspaces_when_warm_limit_is_zero() -> None:
    manager = AgentWorkspaceManager(max_warm_workspaces=0, runtime_idle_seconds=60)
    first = await manager.start_session("task_a", _intent("alice", "kimi"))
    await first.release()

    workspaces = await manager.list_workspaces(user_id="alice")
    health = await manager.runtime_health(user_id="alice")

    assert workspaces[0]["runtime_status"] == "destroyed"
    assert workspaces[0]["runtime_status_reason"] == "warm_runtime_reclaimed"
    assert health["host"]["warm_workspaces"] == 0
    assert health["host"]["destroyed_workspaces"] == 1


@pytest.mark.asyncio
async def test_workspace_manager_can_use_container_runtime_factory() -> None:
    driver = InMemoryWorkspaceContainerDriver()
    manager = AgentWorkspaceManager(
        runtime_factory=WorkspaceRuntimeFactory(
            backend="container",
            container_image="ghcr.io/example/payswitch-runtime:test",
            container_driver=driver,
        )
    )
    lease = await manager.start_session("task_a", _intent("alice", "kimi"))
    try:
        workspaces = await manager.list_workspaces(user_id="alice")
        assert workspaces[0]["runtime_backend"] == "container"
        assert workspaces[0]["runtime_status"] == "active"

        display = await manager.select_display_session("task_a")
        assert display["runtime_backend"] == "container"

        health = await manager.runtime_health(user_id="alice")
        assert health["runtimes"][0]["runtime_backend"] == "container"
        assert health["runtimes"][0]["container_image"] == "ghcr.io/example/payswitch-runtime:test"
    finally:
        await lease.release()


@pytest.mark.asyncio
async def test_container_runtime_sleeps_and_resumes_with_stable_profile_volume() -> None:
    driver = InMemoryWorkspaceContainerDriver()
    manager = AgentWorkspaceManager(
        runtime_idle_seconds=0.01,
        runtime_factory=WorkspaceRuntimeFactory(
            backend="container",
            container_image="ghcr.io/example/payswitch-runtime:test",
            container_driver=driver,
        ),
    )
    first = await manager.start_session("task_a", _intent("alice", "kimi"))
    try:
        active = await manager.runtime_health(user_id="alice")
        runtime = active["runtimes"][0]
        first_volume = runtime["profile_volume_name"]
        first_container = runtime["container_id"]
    finally:
        await first.release()

    await asyncio.sleep(0.03)
    sleeping = await manager.runtime_health(user_id="alice")
    runtime = sleeping["runtimes"][0]
    assert runtime["runtime_status"] == "sleeping"
    assert runtime["container_status"] == "stopped"
    assert runtime["profile_volume_name"] == first_volume

    second = await manager.start_session("task_b", _intent("alice", "jimeng"))
    try:
        resumed = await manager.runtime_health(user_id="alice")
        runtime = resumed["runtimes"][0]
        assert runtime["runtime_status"] == "active"
        assert runtime["container_status"] == "running"
        assert runtime["profile_volume_name"] == first_volume
        assert runtime["container_id"] == first_container
    finally:
        await second.release()


@pytest.mark.asyncio
async def test_workspace_manager_marks_session_failed_when_container_backend_cannot_start() -> None:
    class BrokenDriver:
        driver_kind = "in_memory"

        @property
        def available(self) -> bool:
            return False

        @property
        def availability_reason(self) -> str | None:
            return "broken_for_test"

        def start_workspace(self, *, spec, existing=None):  # type: ignore[no-untyped-def]
            raise RuntimeError("boom")

        def stop_workspace(self, record):  # type: ignore[no-untyped-def]
            return record

        def destroy_workspace(self, record) -> None:  # type: ignore[no-untyped-def]
            return None

    manager = AgentWorkspaceManager(
        runtime_factory=WorkspaceRuntimeFactory(
            backend="container",
            container_driver=BrokenDriver(),  # type: ignore[arg-type]
        )
    )

    with pytest.raises(RuntimeError, match="boom"):
        await manager.start_session("task_a", _intent("alice", "kimi"))

    failed = await manager.get_session("task_a")
    assert failed is not None
    assert failed.status == "failed"
    assert failed.queued_reason == "workspace_runtime_failed"
