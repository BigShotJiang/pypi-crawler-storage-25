from __future__ import annotations

import json
from pathlib import Path

from payswitch.security.artifacts import (
    ARTIFACT_ENVELOPE_SCHEMA,
    ARTIFACT_HANDOFF_SCHEMA,
    ArtifactSensitivity,
    ArtifactStore,
)


def test_artifact_store_encrypts_sensitive_json_and_round_trips(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "recovery" / "tx-1.json"
    payload = {
        "tx_id": "txn_sensitive_1",
        "current_url": "https://merchant.example/checkout",
        "visible_text_summary": "Pay with Alipay",
    }

    store.write_json(
        artifact_path,
        payload,
        artifact_kind="recovery_checkpoint",
        sensitivity=ArtifactSensitivity.sensitive,
        metadata={"tx_id": "txn_sensitive_1"},
    )

    raw = json.loads(artifact_path.read_text(encoding="utf-8"))
    assert raw["schema"] == ARTIFACT_ENVELOPE_SCHEMA
    assert "merchant.example/checkout" not in artifact_path.read_text(encoding="utf-8")
    assert store.read_json(artifact_path) == payload

    metadata = store.read_metadata(artifact_path)
    assert metadata["artifact_kind"] == "recovery_checkpoint"
    assert metadata["sensitivity"] == "sensitive"
    assert metadata["encrypted"] is True
    assert metadata["retention_hours"] == 72


def test_artifact_store_writes_internal_metadata_without_encryption(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "external" / "tx-1.json"
    payload = {"tx_id": "txn_internal_1", "current_url": "https://merchant.example/cart"}

    store.write_json(
        artifact_path,
        payload,
        artifact_kind="external_debug",
        sensitivity=ArtifactSensitivity.internal,
    )

    assert json.loads(artifact_path.read_text(encoding="utf-8")) == payload
    metadata = store.read_metadata(artifact_path)
    assert metadata["artifact_kind"] == "external_debug"
    assert metadata["sensitivity"] == "internal"
    assert metadata["encrypted"] is False
    assert metadata["retention_hours"] == 168


def test_artifact_store_encrypts_sensitive_bytes_and_round_trips(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "external" / "shot.png"
    payload = b"\x89PNG\r\nfake"

    store.write_bytes(
        artifact_path,
        payload,
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
        metadata={"tx_id": "txn_sensitive_png_1"},
    )

    raw = json.loads(artifact_path.read_text(encoding="utf-8"))
    assert raw["schema"] == ARTIFACT_ENVELOPE_SCHEMA
    assert store.read_bytes(artifact_path) == payload
    assert store.read_content_type(artifact_path) == "image/png"

    metadata = store.read_metadata(artifact_path)
    assert metadata["artifact_kind"] == "external_observation_screenshot"
    assert metadata["sensitivity"] == "sensitive"
    assert metadata["encrypted"] is True


def test_artifact_store_can_export_and_import_handoff_bundle(tmp_path: Path) -> None:
    source_store = ArtifactStore(tmp_path / "source")
    target_store = ArtifactStore(tmp_path / "target")
    artifact_path = tmp_path / "source" / "evidence" / "external" / "shot.png"
    payload = b"\x89PNG\r\nhandoff"

    source_store.write_bytes(
        artifact_path,
        payload,
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
        metadata={"tx_id": "txn_handoff_1"},
    )
    recipient_public_key = target_store.local_inbox_summary(include_public_key=True)["public_key"]
    bundle = source_store.export_handoff_bundle(
        artifact_path,
        recipient_public_key=recipient_public_key,
    )

    assert bundle["schema"] == ARTIFACT_HANDOFF_SCHEMA
    assert bundle["artifact"]["content_type"] == "image/png"

    imported_path = target_store.import_handoff_bundle(
        bundle,
        target_path=tmp_path / "target" / "imported" / "shot.png",
    )

    assert imported_path.exists()
    assert target_store.read_bytes(imported_path) == payload
    metadata = target_store.read_metadata(imported_path)
    assert metadata["artifact_kind"] == "external_observation_screenshot"
    assert metadata["metadata"]["tx_id"] == "txn_handoff_1"
    expected_source_id = source_store.local_inbox_summary()["recipient_id"]
    assert metadata["metadata"]["handoff_source_recipient_id"] == expected_source_id


def test_artifact_store_rotate_local_inbox_reencrypts_sensitive_artifacts(
    tmp_path: Path,
) -> None:
    store = ArtifactStore(tmp_path)
    image_path = tmp_path / "evidence" / "external" / "shot.png"
    json_path = tmp_path / "evidence" / "recovery" / "tx-1.json"
    store.write_bytes(
        image_path,
        b"\x89PNG\r\nrotate",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
        metadata={"tx_id": "txn_rotate_png"},
    )
    store.write_json(
        json_path,
        {"tx_id": "txn_rotate_json", "current_url": "https://merchant.example"},
        artifact_kind="recovery_checkpoint",
        sensitivity=ArtifactSensitivity.sensitive,
        metadata={"tx_id": "txn_rotate_json"},
    )
    old_summary = store.local_inbox_summary()

    result = store.rotate_local_inbox(reencrypt_existing=True)

    new_summary = store.local_inbox_summary()
    assert result["encrypted_artifacts"] == 2
    assert result["rotated_artifacts"] == 2
    assert new_summary["recipient_id"] != old_summary["recipient_id"]
    assert Path(result["backup_inbox_path"]).exists()
    assert store.read_bytes(image_path) == b"\x89PNG\r\nrotate"
    assert store.read_json(json_path)["tx_id"] == "txn_rotate_json"
    assert store.read_metadata(image_path)["recipient_id"] == new_summary["recipient_id"]
    assert (
        store.read_metadata(image_path)["rotation_source_recipient_id"]
        == old_summary["recipient_id"]
    )


def test_artifact_store_rotate_local_inbox_blocks_without_reencrypt_flag(
    tmp_path: Path,
) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "external" / "shot.png"
    store.write_bytes(
        artifact_path,
        b"\x89PNG\r\nblocked",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
    )

    preview = store.rotate_local_inbox(dry_run=True)

    assert preview["blocked"] is True
    assert preview["reason"] == "encrypted_artifacts_present"
    assert preview["encrypted_artifacts"] == 1
