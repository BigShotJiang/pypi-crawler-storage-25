from payswitch.subagent_harness import review_harness_events, review_harness_snapshot


def test_harness_review_flags_cross_user_foreground_and_missing_identity() -> None:
    findings = review_harness_snapshot(
        sessions=[
            {
                "task_id": "task_a",
                "session_id": "sag_a",
                "user_id": "alice",
                "workspace_id": "uws_alice",
                "status": "running",
                "foreground_lease_id": "fg_one",
            },
            {
                "task_id": "task_b",
                "session_id": "sag_b",
                "user_id": "bob",
                "workspace_id": "uws_alice",
                "status": "running",
                "foreground_lease_id": "fg_two",
            },
            {
                "task_id": "task_c",
                "status": "running",
            },
        ]
    )

    codes = {finding["code"] for finding in findings}
    assert "workspace_user_conflict" in codes
    assert "multiple_foreground_leases" in codes
    assert "missing_session_identity" in codes


def test_harness_review_flags_plaintext_secret_events() -> None:
    findings = review_harness_events(
        [
            {
                "type": "completed",
                "summary": "provider key returned",
                "details": {"api_key": "sk-live-leaked"},
            }
        ]
    )

    assert findings == [
        {
            "severity": "critical",
            "code": "plaintext_secret_event",
            "message": "event payload contains plaintext secret-like data",
            "event_index": 0,
        }
    ]
