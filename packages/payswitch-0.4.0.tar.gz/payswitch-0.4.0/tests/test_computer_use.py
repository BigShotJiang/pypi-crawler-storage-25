"""Controlled Computer Use explorer tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from payswitch.browser.computer_use import (
    ComputerUseExplorer,
    ComputerUseRecoveryBudget,
    ComputerUseUnavailableError,
    RecoveryStateVerificationError,
)
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import StepRecord
from payswitch.models.types import StepCategory, StepRisk


def _config(tmp_path: Path, **kwargs) -> PaySwitchConfig:
    return PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded-test-key", **kwargs)


def test_computer_use_explorer_availability_respects_config(tmp_path: Path):
    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path, computer_use_enabled=False))

    assert explorer.is_available() is False


@pytest.mark.asyncio
async def test_computer_use_explorer_marks_steps_as_checkout_prep(tmp_path: Path):
    raw_steps = [StepRecord(step_index=0, description="找到会员入口", status="success")]

    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        mock_engine.execute_task = AsyncMock(return_value=raw_steps)
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path))
        steps = await explorer.explore_checkout(
            page=MagicMock(),
            payee="kimi",
            amount=10.0,
            method="alipay_qr",
            url="https://www.kimi.com",
        )

    assert steps[0].category == StepCategory.checkout_prep
    assert steps[0].risk == StepRisk.medium
    mock_engine.execute_task.assert_awaited_once()


@pytest.mark.asyncio
async def test_computer_use_explorer_clamps_steps_to_token_budget(tmp_path: Path):
    raw_steps = [StepRecord(step_index=0, description="找到会员入口", status="success")]

    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        mock_engine.execute_task = AsyncMock(return_value=raw_steps)
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path))
        budget = ComputerUseRecoveryBudget(
            max_steps=8,
            max_screenshots=2,
            max_model_tokens=900,
            max_step_output_tokens=300,
            max_wall_time_seconds=60,
        )
        await explorer.explore_checkout(
            page=MagicMock(),
            payee="kimi",
            amount=10.0,
            method="alipay_qr",
            url="https://www.kimi.com",
            budget=budget,
        )

    call_kwargs = mock_engine.execute_task.await_args.kwargs
    assert call_kwargs["max_steps"] == 2
    assert call_kwargs["max_output_tokens"] == 300


@pytest.mark.asyncio
async def test_computer_use_explorer_includes_resync_snapshot_in_task_description(
    tmp_path: Path,
):
    raw_steps = [StepRecord(step_index=0, description="找到会员入口", status="success")]

    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        mock_engine.execute_task = AsyncMock(return_value=raw_steps)
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path))
        await explorer.explore_checkout(
            page=MagicMock(),
            payee="kimi",
            amount=10.0,
            method="alipay_qr",
            url="https://www.kimi.com",
            recovery_context={
                "waypoint_id": "find_membership_entry",
                "resync_snapshot": {
                    "current_url": "https://www.kimi.com/membership",
                    "visible_text_summary": "Kimi 会员\n立即开通",
                    "dom_summary": {
                        "title": "Kimi Membership",
                        "headings": ["会员中心"],
                        "buttons": ["立即开通"],
                    },
                },
            },
        )

    task_description = mock_engine.execute_task.await_args.kwargs["task_description"]
    assert "恢复上下文" in task_description
    assert "find_membership_entry" in task_description
    assert "https://www.kimi.com/membership" in task_description
    assert "Kimi Membership" in task_description


@pytest.mark.asyncio
async def test_computer_use_explorer_blocks_when_policy_disallows_checkout_prep(
    tmp_path: Path,
):
    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(
            _config(
                tmp_path,
                computer_use_max_autonomous_category=StepCategory.identity,
            )
        )

        with pytest.raises(ComputerUseUnavailableError):
            await explorer.explore_checkout(
                page=MagicMock(),
                payee="kimi",
                amount=10.0,
                method="alipay_qr",
                url="https://www.kimi.com",
            )


@pytest.mark.asyncio
async def test_recovery_state_verifier_blocks_login_surface(tmp_path: Path):
    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path))
        page = MagicMock()
        page.url = "https://www.kimi.com/login"
        page.evaluate = AsyncMock(return_value="Please sign in to continue")

        with pytest.raises(RecoveryStateVerificationError, match="login required") as exc:
            await explorer._verify_recovery_action(
                page,
                {
                    "action": "click",
                    "selector": "Continue",
                    "description": "点击继续",
                    "reasoning": "继续购买",
                },
                0,
                [],
            )

    assert exc.value.failure_context["login_required"] is True
    assert exc.value.failure_context["verification_stage"] == "pre_action"


@pytest.mark.asyncio
async def test_recovery_state_verifier_blocks_sensitive_payment_boundary(tmp_path: Path):
    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path))
        page = MagicMock()
        page.url = "https://www.kimi.com/membership/pricing"
        page.evaluate = AsyncMock(
            return_value="Pay with Alipay\nAgree to the terms\nContinue"
        )

        with pytest.raises(
            RecoveryStateVerificationError,
            match="high-risk payment boundary action",
        ) as exc:
            await explorer._verify_recovery_action(
                page,
                {
                    "action": "click",
                    "selector": "Continue",
                    "description": "点击继续",
                    "reasoning": "进入支付确认",
                },
                1,
                [],
            )

    assert exc.value.failure_context["requires_human_gate"] is True
    assert exc.value.failure_context["synchronous_policy_checkpoint"] is True
    assert exc.value.failure_context["waypoint_category"] == "final_authorization"


@pytest.mark.asyncio
async def test_recovery_state_verifier_projects_resync_snapshot_into_failure_context(
    tmp_path: Path,
):
    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path))
        page = MagicMock()
        page.url = "https://www.kimi.com/login"
        page.evaluate = AsyncMock(return_value="Please sign in to continue")

        with pytest.raises(RecoveryStateVerificationError) as exc:
            await explorer._verify_recovery_action(
                page,
                {"action": "click", "selector": "Continue"},
                0,
                [],
                recovery_context={
                    "waypoint_id": "find_membership_entry",
                    "resync_snapshot": {
                        "current_url": "https://www.kimi.com/login",
                        "visible_text_summary": "Please sign in to continue",
                        "dom_summary": {"title": "Login"},
                    },
                },
            )

    assert exc.value.failure_context["waypoint_id"] == "find_membership_entry"
    assert exc.value.failure_context["resync_snapshot"]["current_url"].endswith("/login")
    assert exc.value.failure_context["resync_snapshot"]["dom_summary"]["title"] == "Login"
