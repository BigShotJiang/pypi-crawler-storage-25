from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from payswitch.cli import app
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore


def test_artifact_budget_enforcement_cli_once_dry_run_and_delete(
    tmp_path: Path,
    monkeypatch,
) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "preview" / "public.png"
    store.write_bytes(
        artifact_path,
        b"public-preview",
        artifact_kind="public_preview",
        sensitivity=ArtifactSensitivity.public,
        content_type="image/png",
    )
    monkeypatch.setattr("payswitch.cli._artifact_store_from_config", lambda: store)
    budget_mb = max((int(store.inventory()["total_bytes"]) - 1) / (1024 * 1024), 0.000001)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--json",
            "artifact",
            "enforce-budget",
            "--once",
            "--dry-run",
            "--budget-mb",
            str(budget_mb),
        ],
    )
    assert result.exit_code == 0
    preview = json.loads(result.stdout)
    assert preview["triggered"] is True
    assert preview["cleaned"] == 1
    assert preview["items"][0]["action"] == "would_delete"
    assert artifact_path.exists()

    result = runner.invoke(
        app,
        ["--json", "artifact", "enforce-budget", "--once", "--budget-mb", str(budget_mb)],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["triggered"] is True
    assert payload["cleaned"] == 1
    assert payload["items"][0]["action"] == "deleted"
    assert not artifact_path.exists()
    assert not store.metadata_path(artifact_path).exists()
