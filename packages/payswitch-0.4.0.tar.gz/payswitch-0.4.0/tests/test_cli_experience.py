from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from payswitch.cli import app
from payswitch.experience import ExperienceStore, get_recipe
from payswitch.experience.models import RecoveryImprovementStatus


def _store(tmp_path: Path) -> ExperienceStore:
    return ExperienceStore(tmp_path / "experience" / "recipes.db")


def test_experience_patch_cli_review_flow(tmp_path: Path, monkeypatch) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    candidate = builtin.model_copy(deep=True)
    patch_id = store.register_patch(recipe=candidate, source="script_recovery")
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()

    result = runner.invoke(app, ["--json", "experience", "patch", "list"])
    assert result.exit_code == 0
    patches = json.loads(result.stdout)
    assert patches[0]["id"] == patch_id

    result = runner.invoke(
        app,
        [
            "experience",
            "patch",
            "review",
            str(patch_id),
            "--reviewer",
            "qa",
            "--note",
            "shadow looks stable",
        ],
    )
    assert result.exit_code == 0
    reviewed = json.loads(result.stdout)
    assert reviewed["state"] == "reviewed"
    assert reviewed["metadata"]["reviewed_by"] == "qa"

    result = runner.invoke(
        app,
        [
            "experience",
            "patch",
            "promote",
            str(patch_id),
        ],
    )
    assert result.exit_code == 0
    promoted = json.loads(result.stdout)
    assert promoted["state"] == "mainline"


def test_experience_patch_cli_shadow_pass(tmp_path: Path, monkeypatch) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    candidate = builtin.model_copy(deep=True)
    patch_id = store.register_patch(recipe=candidate, source="script_recovery")
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "experience",
            "patch",
            "shadow-pass",
            str(patch_id),
            "--note",
            "validated in sandbox",
        ],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["state"] == "shadow_run"
    assert payload["shadow_run_success"] is True
    assert payload["metadata"]["shadow_run_note"] == "validated in sandbox"


def test_experience_patch_cli_queue_reports_ready_and_blocked(
    tmp_path: Path, monkeypatch
) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    candidate_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    shadow_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(shadow_id)
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(app, ["--json", "experience", "patch", "queue"])
    assert result.exit_code == 0
    queue = json.loads(result.stdout)
    readiness = {entry["id"]: entry for entry in queue}
    assert readiness[candidate_id]["promotion_ready"] is False
    assert readiness[shadow_id]["promotion_ready"] is True
    assert readiness[shadow_id]["promotion_basis"] == "shadow_run_success"
    assert readiness[shadow_id]["shadow_run_count"] == 1

    result = runner.invoke(app, ["--json", "experience", "patch", "queue", "--ready-only"])
    assert result.exit_code == 0
    ready_only = json.loads(result.stdout)
    assert [entry["id"] for entry in ready_only] == [shadow_id]

    result = runner.invoke(
        app,
        ["--json", "experience", "patch", "queue", "--min-shadow-runs", "2"],
    )
    assert result.exit_code == 0
    threshold_queue = json.loads(result.stdout)
    threshold_readiness = {entry["id"]: entry for entry in threshold_queue}
    assert threshold_readiness[shadow_id]["promotion_ready"] is False
    assert threshold_readiness[shadow_id]["blocking_reasons"] == ["needs_more_shadow_runs:1/2"]


def test_experience_patch_cli_promote_ready(tmp_path: Path, monkeypatch) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    shadow_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    reviewed_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="human_review",
    )
    store.mark_shadow_run_success(shadow_id)
    store.review_patch(reviewed_id, reviewer="qa")
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "patch",
            "promote-ready",
            "--basis",
            "reviewed",
            "--actor",
            "ops",
            "--dry-run",
            "--min-shadow-runs",
            "2",
        ],
    )
    assert result.exit_code == 0
    preview = json.loads(result.stdout)
    assert [entry["id"] for entry in preview] == [reviewed_id]
    assert store.get_patch(reviewed_id)["state"] == "reviewed"

    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "patch",
            "promote-ready",
            "--basis",
            "shadow_run_success",
            "--actor",
            "ops",
            "--dry-run",
            "--min-shadow-runs",
            "2",
        ],
    )
    assert result.exit_code == 0
    blocked_shadow = json.loads(result.stdout)
    assert blocked_shadow == []

    store.mark_shadow_run_success(shadow_id)

    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "patch",
            "promote-ready",
            "--actor",
            "ops",
            "--note",
            "nightly queue",
        ],
    )
    assert result.exit_code == 0
    promoted = json.loads(result.stdout)
    assert [entry["id"] for entry in promoted] == [shadow_id, reviewed_id]
    assert store.get_patch(shadow_id)["state"] == "mainline"
    assert store.get_patch(reviewed_id)["metadata"]["promoted_by"] == "ops"


def test_experience_patch_cli_run_promoter(tmp_path: Path, monkeypatch) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(patch_id)
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "patch",
            "run-promoter",
            "--actor",
            "ops",
            "--basis",
            "shadow_run_success",
            "--once",
            "--min-shadow-runs",
            "2",
            "--batch-limit",
            "5",
            "--poll-interval-seconds",
            "0",
        ],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["promoted"] == 0
    assert store.get_patch(patch_id)["state"] == "shadow_run"

    store.mark_shadow_run_success(patch_id)
    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "patch",
            "run-promoter",
            "--actor",
            "ops",
            "--basis",
            "shadow_run_success",
            "--once",
            "--min-shadow-runs",
            "2",
            "--batch-limit",
            "5",
            "--poll-interval-seconds",
            "0",
        ],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["promoted"] == 1
    assert store.get_patch(patch_id)["state"] == "mainline"


def test_experience_improvement_cli_flow(tmp_path: Path, monkeypatch) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-123",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-123-patch-1.json",
        summary={"outcome": "scan_qr", "waypoint_id": "select_monthly_plan"},
    )
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(app, ["--json", "experience", "improvement", "list"])
    assert result.exit_code == 0
    queue = json.loads(result.stdout)
    assert [entry["id"] for entry in queue] == [improvement_id]

    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "improvement",
            "accept",
            str(improvement_id),
            "--reviewer",
            "ops",
            "--note",
            "keep for recipe review",
        ],
    )
    assert result.exit_code == 0
    accepted = json.loads(result.stdout)
    assert accepted["status"] == "accepted"
    assert accepted["metadata"]["reviewed_by"] == "ops"


def test_experience_improvement_cli_process(tmp_path: Path, monkeypatch) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-123",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-123-patch-1.json",
        summary={"outcome": "scan_qr"},
    )
    store.update_recovery_improvement_status(
        improvement_id,
        status=RecoveryImprovementStatus.accepted,
        reviewer="ops",
    )
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "improvement",
            "process",
            "--reviewer",
            "watchdog",
            "--dry-run",
        ],
    )
    assert result.exit_code == 0
    preview = json.loads(result.stdout)
    assert preview[0]["patch_state_after"] == "reviewed"
    assert store.get_patch(patch_id)["state"] == "candidate"

    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "improvement",
            "process",
            "--reviewer",
            "watchdog",
            "--note",
            "nightly accepted queue",
        ],
    )
    assert result.exit_code == 0
    processed = json.loads(result.stdout)
    assert processed[0]["action"] == "review_patch"
    assert store.get_patch(patch_id)["state"] == "reviewed"
    assert store.get_recovery_improvement(improvement_id)["status"] == "applied"


def test_experience_improvement_cli_accept_open(tmp_path: Path, monkeypatch) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    store.mark_shadow_run_success(patch_id)
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-123",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-123-patch-1.json",
        summary={"outcome": "scan_qr"},
    )
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "improvement",
            "accept-open",
            "--reviewer",
            "watchdog",
            "--dry-run",
            "--min-shadow-runs",
            "2",
        ],
    )
    assert result.exit_code == 0
    preview = json.loads(result.stdout)
    assert preview[0]["action"] == "blocked"
    assert preview[0]["blocking_reasons"] == ["needs_more_shadow_runs:1/2"]
    assert store.get_recovery_improvement(improvement_id)["status"] == "open"

    store.mark_shadow_run_success(patch_id)

    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "improvement",
            "accept-open",
            "--reviewer",
            "watchdog",
            "--note",
            "nightly auto accept",
            "--min-shadow-runs",
            "2",
        ],
    )
    assert result.exit_code == 0
    accepted = json.loads(result.stdout)
    assert accepted[0]["improvement_status_after"] == "accepted"
    assert store.get_recovery_improvement(improvement_id)["status"] == "accepted"


def test_experience_improvement_cli_run_loop(tmp_path: Path, monkeypatch) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-123",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-123-patch-1.json",
        summary={"outcome": "scan_qr"},
    )
    store.update_recovery_improvement_status(
        improvement_id,
        status=RecoveryImprovementStatus.accepted,
        reviewer="ops",
    )
    monkeypatch.setattr("payswitch.cli._experience_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--json",
            "experience",
            "improvement",
            "run-loop",
            "--reviewer",
            "watchdog",
            "--once",
            "--batch-limit",
            "5",
            "--poll-interval-seconds",
            "0",
        ],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["processed"] == 1
    assert payload["reviewed_patches"] == 1
    assert store.get_patch(patch_id)["state"] == "reviewed"
