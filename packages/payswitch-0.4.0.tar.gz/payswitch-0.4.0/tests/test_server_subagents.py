import asyncio

import pytest

from payswitch.agent_language import PaymentIntent
from payswitch.models.transaction import Transaction
from payswitch.models.types import PaymentMethod, TransactionStatus
from payswitch.server import _run_task, store, workspace_manager


class _FakePlan:
    summary = "fake route"

    def model_dump(self, mode: str = "json") -> dict:
        return {"summary": self.summary, "mode": mode}


class _FakePlanner:
    async def plan(self, intent: PaymentIntent) -> _FakePlan:
        return _FakePlan()


class _ConcurrentOrchestrator:
    running = 0
    max_running = 0

    def __init__(self, *args, **kwargs) -> None:
        pass

    async def spend(
        self,
        *,
        amount: float,
        payee: str,
        reason: str,
        method: PaymentMethod,
        **kwargs,
    ) -> Transaction:
        type(self).running += 1
        type(self).max_running = max(type(self).max_running, type(self).running)
        try:
            await asyncio.sleep(0.05)
            return Transaction(
                amount=amount,
                currency="CNY",
                payee=payee,
                reason=reason,
                payment_method=method,
                status=TransactionStatus.completed,
            )
        finally:
            type(self).running -= 1

    def close(self) -> None:
        pass


async def _reset_runtime() -> None:
    await store.clear()
    await workspace_manager.reset()
    _ConcurrentOrchestrator.running = 0
    _ConcurrentOrchestrator.max_running = 0


def _intent(user_id: str) -> PaymentIntent:
    return PaymentIntent(
        amount=10,
        currency="CNY",
        payee="kimi",
        reason="parallel user validation",
        method=PaymentMethod.alipay_qr,
        source_agent="codex",
        metadata={"user_id": user_id},
    )


@pytest.mark.asyncio
async def test_run_task_executes_different_users_as_parallel_subagents(monkeypatch) -> None:
    await _reset_runtime()
    monkeypatch.setattr("payswitch.server.PaymentPlanner", _FakePlanner)
    monkeypatch.setattr("payswitch.server.PaymentOrchestrator", _ConcurrentOrchestrator)

    first = await store.create(_intent("alice"))
    second = await store.create(_intent("bob"))

    await asyncio.gather(_run_task(first.id), _run_task(second.id))

    assert _ConcurrentOrchestrator.max_running == 2
    first_done = await store.get(first.id)
    second_done = await store.get(second.id)
    assert first_done is not None and first_done.status == "completed"
    assert second_done is not None and second_done.status == "completed"

    workspaces = await workspace_manager.list_workspaces()
    assert {workspace["user_id"] for workspace in workspaces} == {"alice", "bob"}
