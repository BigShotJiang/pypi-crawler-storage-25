from __future__ import annotations

from fastapi.testclient import TestClient

from payswitch.models.config import PaySwitchConfig
from payswitch.server import (
    app,
    build_ready_patch_promotion_supervisor_from_env,
)


def test_build_ready_patch_promotion_supervisor_from_env_defaults_disabled(
    monkeypatch,
) -> None:
    monkeypatch.delenv("PAYSWITCH_READY_PATCH_PROMOTER_ENABLED", raising=False)

    supervisor = build_ready_patch_promotion_supervisor_from_env()

    assert supervisor is None


def test_build_ready_patch_promotion_supervisor_from_env_supports_enabled_config(
    monkeypatch,
    tmp_path,
) -> None:
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_ENABLED", "1")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_ACTOR", "promoter")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_NOTE", "nightly")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_BASIS", "shadow_run_success")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_PLATFORM", "kimi")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_FLOW", "membership_monthly_qr")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_SOURCE", "script_recovery")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_MIN_SHADOW_RUNS", "2")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_POLL_INTERVAL_SECONDS", "2.5")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_BATCH_LIMIT", "4")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_DRY_RUN", "true")

    supervisor = build_ready_patch_promotion_supervisor_from_env(
        config_override=PaySwitchConfig(data_dir=tmp_path),
    )

    assert supervisor is not None
    snapshot = supervisor.snapshot()
    assert snapshot["enabled"] is True
    assert snapshot["running"] is False
    assert snapshot["actor"] == "promoter"
    assert snapshot["note"] == "nightly"
    assert snapshot["basis"] == "shadow_run_success"
    assert snapshot["platform"] == "kimi"
    assert snapshot["flow"] == "membership_monthly_qr"
    assert snapshot["source"] == "script_recovery"
    assert snapshot["min_shadow_runs"] == 2
    assert snapshot["poll_interval_seconds"] == 2.5
    assert snapshot["batch_limit"] == 4
    assert snapshot["dry_run"] is True


def test_ready_patch_promotion_health_endpoint_reports_service_supervision(
    monkeypatch,
    tmp_path,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_ENABLED", "1")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_ACTOR", "promoter")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_BASIS", "shadow_run_success")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_MIN_SHADOW_RUNS", "2")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_POLL_INTERVAL_SECONDS", "0.01")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_BATCH_LIMIT", "3")
    monkeypatch.setenv("PAYSWITCH_READY_PATCH_PROMOTER_DRY_RUN", "1")

    with TestClient(app) as client:
        promotion = client.get("/api/recovery-patch-promoter/health")
        health = client.get("/api/health")

        assert promotion.status_code == 200
        payload = promotion.json()
        assert payload["enabled"] is True
        assert payload["running"] is True
        assert payload["actor"] == "promoter"
        assert payload["basis"] == "shadow_run_success"
        assert payload["min_shadow_runs"] == 2
        assert payload["batch_limit"] == 3
        assert payload["dry_run"] is True

        assert health.status_code == 200
        health_payload = health.json()
        assert health_payload["recovery_patch_promoter"]["enabled"] is True
        assert health_payload["recovery_patch_promoter"]["running"] is True
        assert (
            health_payload["recovery_patch_promoter"]["basis"]
            == "shadow_run_success"
        )
        assert health_payload["recovery_patch_promoter"]["min_shadow_runs"] == 2
