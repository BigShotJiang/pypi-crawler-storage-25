import asyncio
from pathlib import Path

import pytest

from payswitch.agent_language import PaymentIntent
from payswitch.agent_workspace import AgentWorkspaceManager, resolve_task_identity
from payswitch.profile_manager import ProfileVaultManager


def _intent(user_id: str, payee: str = "kimi") -> PaymentIntent:
    return PaymentIntent(
        amount=10,
        currency="CNY",
        payee=payee,
        reason=f"{payee} service request",
        method="alipay_qr",
        source_agent="codex",
        metadata={"user_id": user_id},
    )


def test_resolve_task_identity_uses_user_workspace_and_site_ids() -> None:
    identity = resolve_task_identity(_intent("user-a", "jimeng"))

    assert identity.user_id == "user-a"
    assert identity.site_id == "jimeng"
    assert identity.workspace_id.startswith("uws_")
    assert identity.subagent_session_id.startswith("sag_")
    assert identity.site_lock_id.startswith("slk_")


@pytest.mark.asyncio
async def test_workspace_manager_allocates_isolated_workspaces_for_different_users() -> None:
    manager = AgentWorkspaceManager()
    first = await manager.start_session("task_a", _intent("user-a", "kimi"))
    second = await manager.start_session("task_b", _intent("user-b", "kimi"))
    try:
        assert first.workspace_id != second.workspace_id
        assert first.user_id == "user-a"
        assert second.user_id == "user-b"
        assert first.status == "running"
        assert second.status == "running"

        workspaces = await manager.list_workspaces()
        assert {workspace["user_id"] for workspace in workspaces} == {"user-a", "user-b"}
        assert all(workspace["active_sessions"] == 1 for workspace in workspaces)
    finally:
        await first.release()
        await second.release()


@pytest.mark.asyncio
async def test_workspace_manager_queues_same_user_same_site_until_lock_released() -> None:
    manager = AgentWorkspaceManager()
    first = await manager.start_session("task_a", _intent("user-a", "kimi"))
    second_task = asyncio.create_task(manager.start_session("task_b", _intent("user-a", "kimi")))

    try:
        await asyncio.sleep(0.01)
        assert not second_task.done()

        queued = await manager.get_session("task_b")
        assert queued is not None
        assert queued.status == "queued"
        assert queued.queued_reason == "site_lock"

        await first.release()
        second = await asyncio.wait_for(second_task, timeout=1)
        try:
            assert second.status == "running"
            assert second.workspace_id == first.workspace_id
        finally:
            await second.release()
    finally:
        if not first.released:
            await first.release()
        if not second_task.done():
            second_task.cancel()


@pytest.mark.asyncio
async def test_releasing_queued_session_does_not_unlock_running_site_lock() -> None:
    manager = AgentWorkspaceManager()
    first = await manager.start_session("task_a", _intent("user-a", "kimi"))
    second_task = asyncio.create_task(manager.start_session("task_b", _intent("user-a", "kimi")))

    try:
        await asyncio.sleep(0.01)
        assert not second_task.done()

        await manager.release_session("task_b", final_status="deleted")
        await asyncio.sleep(0.01)
        assert not second_task.done()

        await first.release()
        with pytest.raises(RuntimeError, match="deleted"):
            await asyncio.wait_for(second_task, timeout=1)
    finally:
        if not first.released:
            await first.release()
        if not second_task.done():
            second_task.cancel()


@pytest.mark.asyncio
async def test_select_display_session_assigns_scoped_surface_to_selected_task() -> None:
    manager = AgentWorkspaceManager()
    lease = await manager.start_session("task_a", _intent("user-a", "kimi"))
    try:
        display = await manager.select_display_session("task_a")

        assert display["display_ready"] is True
        assert display["display_state"] == "visible_surface_ready"
        assert display["display_owner_task_id"] == "task_a"
        assert str(display["display_route_token"]).startswith("dsp_")
        assert str(display["display_route_id"]).startswith("droute_")
        assert display["display_route_expires_at"] is not None
    finally:
        await lease.release()


@pytest.mark.asyncio
async def test_select_display_session_reports_waiting_when_other_task_holds_foreground() -> None:
    manager = AgentWorkspaceManager()
    first = await manager.start_session("task_a", _intent("user-a", "kimi"))
    second = await manager.start_session("task_b", _intent("user-a", "jimeng"))
    foreground = await manager.acquire_foreground("task_a", reason="human_gate")
    try:
        display = await manager.select_display_session("task_b")

        assert display["display_ready"] is False
        assert display["display_state"] == "waiting_for_foreground"
        assert display["display_reason"] == "foreground_owned_by_task_a"
    finally:
        await foreground.release()
        await first.release()
        await second.release()


@pytest.mark.asyncio
async def test_verify_visible_action_requires_selected_session_and_foreground_owner() -> None:
    manager = AgentWorkspaceManager()
    first = await manager.start_session("task_a", _intent("user-a", "kimi"))
    second = await manager.start_session("task_b", _intent("user-a", "jimeng"))
    try:
        denied = await manager.verify_visible_action("task_a", action="computer_use")
        assert denied["allowed"] is False
        assert denied["display_reason"] == "session_not_selected_for_display"

        await manager.select_display_session("task_a")
        allowed = await manager.verify_visible_action("task_a", action="computer_use")
        assert allowed["allowed"] is True

        foreground = await manager.acquire_foreground("task_b", reason="human_gate")
        try:
            blocked = await manager.verify_visible_action("task_a", action="computer_use")
            assert blocked["allowed"] is False
            assert blocked["display_reason"] == "foreground_owned_by_task_b"
        finally:
            await foreground.release()
    finally:
        await first.release()
        await second.release()


@pytest.mark.asyncio
async def test_begin_visible_action_acquires_focus_lock_and_blocks_reentry() -> None:
    manager = AgentWorkspaceManager()
    lease = await manager.start_session("task_a", _intent("user-a", "kimi"))
    try:
        session = await manager.get_session("task_a")
        assert session is not None
        await manager.select_display_session("task_a")

        first = await manager.begin_visible_action("task_a", action="computer_use")
        second = await manager.begin_visible_action("task_a", action="computer_use")
        display = await manager.describe_display_session("task_a")
        await manager.finish_visible_action(
            "task_a",
            focus_lock_id=str(first["display_focus_lock_id"]),
        )
        after = await manager.describe_display_session("task_a")

        assert first["allowed"] is True
        assert str(first["display_focus_lock_id"]).startswith("vlock_")
        assert second["allowed"] is False
        assert second["display_reason"] == "visible_action_already_locked"
        assert display is not None
        assert display["display_focus_lock_id"] == first["display_focus_lock_id"]
        assert display["active_browser_context_id"] == session.browser_context_id
        assert after is not None
        assert after["display_focus_lock_id"] is None
    finally:
        await lease.release()


@pytest.mark.asyncio
async def test_display_route_is_invalidated_when_workspace_switches_selected_session() -> None:
    manager = AgentWorkspaceManager()
    first = await manager.start_session("task_a", _intent("user-a", "kimi"))
    second = await manager.start_session("task_b", _intent("user-a", "jimeng"))
    try:
        selected_a = await manager.select_display_session("task_a")
        token_a = str(selected_a["display_route_token"])
        route_a = await manager.resolve_display_route(
            "task_a",
            user_id="user-a",
            route_token=token_a,
        )
        assert route_a is not None

        selected_b = await manager.select_display_session("task_b")
        token_b = str(selected_b["display_route_token"])
        assert token_b != token_a

        stale_a = await manager.resolve_display_route(
            "task_a",
            user_id="user-a",
            route_token=token_a,
        )
        active_b = await manager.resolve_display_route(
            "task_b",
            user_id="user-a",
            route_token=token_b,
        )

        assert stale_a is None
        assert active_b is not None
        assert active_b["workspace_id"] == first.workspace_id
    finally:
        await first.release()
        await second.release()


@pytest.mark.asyncio
async def test_workspace_manager_promotes_profile_after_successful_human_gate(tmp_path) -> None:
    manager = AgentWorkspaceManager(profile_manager=ProfileVaultManager(tmp_path / "profiles"))
    first = await manager.start_session("task_a", _intent("user-a", "kimi"))
    try:
        first_profile = await manager.describe_profile_session("task_a")
        assert first_profile is not None
        assert first_profile["profile_state"] == "task_profile_prepared"
        task_path = first_profile["profile_task_path"]
        assert task_path is not None
        with open(f"{task_path}/cookies.json", "w", encoding="utf-8") as handle:
            handle.write('{"loggedIn": true}')

        promoted = await manager.promote_task_profile("task_a")
        assert promoted["profile_state"] == "stable_ready"
    finally:
        await first.release(final_status="input-required")

    second = await manager.start_session("task_b", _intent("user-a", "kimi"))
    try:
        second_profile = await manager.describe_profile_session("task_b")
        assert second_profile is not None
        assert second_profile["profile_state"] == "task_profile_prepared"
        assert second_profile["profile_task_path"] is not None
        cookies_path = Path(second_profile["profile_task_path"]) / "cookies.json"
        with cookies_path.open(encoding="utf-8") as handle:
            assert handle.read() == '{"loggedIn": true}'
    finally:
        await second.release()


@pytest.mark.asyncio
async def test_workspace_manager_discards_profile_after_failed_task(tmp_path) -> None:
    manager = AgentWorkspaceManager(profile_manager=ProfileVaultManager(tmp_path / "profiles"))
    first = await manager.start_session("task_a", _intent("user-a", "kimi"))
    try:
        first_profile = await manager.describe_profile_session("task_a")
        assert first_profile is not None
        assert first_profile["profile_task_path"] is not None
        transient_path = Path(first_profile["profile_task_path"]) / "transient.json"
        with transient_path.open("w", encoding="utf-8") as handle:
            handle.write('{"transient": true}')
        discarded = await manager.discard_task_profile("task_a", reason="task_failed")
        assert discarded["profile_state"] == "stable_ready"
    finally:
        await first.release(final_status="failed")

    second = await manager.start_session("task_b", _intent("user-a", "kimi"))
    try:
        second_profile = await manager.describe_profile_session("task_b")
        assert second_profile is not None
        assert second_profile["profile_task_path"] is not None
        assert not Path(second_profile["profile_task_path"]).joinpath("transient.json").exists()
    finally:
        await second.release()
