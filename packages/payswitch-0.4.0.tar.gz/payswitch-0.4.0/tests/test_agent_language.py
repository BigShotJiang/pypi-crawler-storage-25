from payswitch.agent_language import intent_from_a2a_message, parse_psl, to_psl


def test_psl_round_trip() -> None:
    intent = parse_psl('PAY 200 CNY TO deepseek FOR "API top-up" VIA alipay_qr DRY_RUN')

    assert intent.amount == 200
    assert intent.currency == "CNY"
    assert intent.payee == "deepseek"
    assert intent.reason == "API top-up"
    assert intent.method == "alipay_qr"
    assert intent.dry_run is True
    assert to_psl(intent) == 'PAY 200 CNY TO deepseek FOR "API top-up" VIA alipay_qr DRY_RUN'


def test_a2a_data_part_to_intent() -> None:
    intent = intent_from_a2a_message(
        {
            "role": "user",
            "metadata": {"source_agent": "test-agent"},
            "parts": [
                {
                    "kind": "data",
                    "data": {
                        "payment": {
                            "amount": 39,
                            "currency": "CNY",
                            "payee": "kimi",
                            "reason": "subscription",
                        }
                    },
                }
            ],
        }
    )

    assert intent.source_agent == "test-agent"
    assert intent.payee == "kimi"
    assert intent.reason == "subscription"
