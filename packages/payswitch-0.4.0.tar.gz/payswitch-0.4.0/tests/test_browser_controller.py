"""BrowserController 轻量 computer-use 能力测试。"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from playwright.async_api import async_playwright

from payswitch.browser.cdp_mirror import CdpMirrorInstance
from payswitch.browser.controller import BrowserController, BrowserControllerError


@pytest.mark.asyncio
async def test_list_clickable_elements缓存识别结果() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.is_closed.return_value = False
    fake_page.evaluate = AsyncMock(
        return_value=[
            {
                "index": 0,
                "tag": "button",
                "text": "立即购买",
                "selector": "#buy",
                "x": 100,
                "y": 200,
            },
            {"index": 1, "tag": "a", "text": "去支付", "selector": "a.pay", "x": 120, "y": 220},
        ]
    )
    ctrl._page = fake_page

    items = await ctrl.list_clickable_elements(limit=10)

    assert len(items) == 2
    assert ctrl._last_clickables == items
    fake_page.evaluate.assert_awaited_once()


@pytest.mark.asyncio
async def test_list_clickable_elements当前页关闭时自动恢复到最新标签页() -> None:
    ctrl = BrowserController()
    closed_page = MagicMock()
    closed_page.is_closed.return_value = True

    live_page = MagicMock()
    live_page.is_closed.return_value = False
    live_page.evaluate = AsyncMock(
        return_value=[
            {
                "index": 0,
                "tag": "button",
                "text": "Subscribe",
                "selector": "button.subscribe",
                "x": 100,
                "y": 200,
            }
        ]
    )
    live_page.bring_to_front = AsyncMock()
    live_page.on = MagicMock()
    live_page.url = "https://www.kimi.com/membership/pricing"

    context = MagicMock()
    context.pages = [closed_page, live_page]

    ctrl._context = context
    ctrl._page = closed_page

    items = await ctrl.list_clickable_elements(limit=10)

    assert items[0]["text"] == "Subscribe"
    assert ctrl.page is live_page
    live_page.evaluate.assert_awaited_once()
    live_page.bring_to_front.assert_awaited_once()


@pytest.mark.asyncio
async def test_click_clickable_index按selector点击() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.is_closed.return_value = False
    fake_page.click = AsyncMock()
    fake_page.mouse = MagicMock()
    fake_page.mouse.click = AsyncMock()
    ctrl._page = fake_page
    ctrl._last_clickables = [
        {"index": 0, "tag": "button", "text": "提交", "selector": "#submit", "x": 50, "y": 60}
    ]

    target = await ctrl.click_clickable_index(0)

    assert target["text"] == "提交"
    fake_page.click.assert_awaited_once_with("#submit", timeout=5_000)
    fake_page.mouse.click.assert_not_called()


@pytest.mark.asyncio
async def test_click_clickable_index点击后自动接管新标签页() -> None:
    ctrl = BrowserController()
    current_page = MagicMock()
    current_page.is_closed.return_value = False
    current_page.mouse = MagicMock()
    current_page.mouse.click = AsyncMock()

    popup_page = MagicMock()
    popup_page.is_closed.return_value = False
    popup_page.bring_to_front = AsyncMock()
    popup_page.on = MagicMock()
    popup_page.url = "https://qr.alipay.com/mock"

    context = MagicMock()
    context.pages = [current_page]

    async def _click_and_open_popup(*args: object, **kwargs: object) -> None:  # noqa: ARG001
        context.pages.append(popup_page)

    current_page.click = AsyncMock(side_effect=_click_and_open_popup)
    ctrl._context = context
    ctrl._page = current_page
    ctrl._last_clickables = [
        {
            "index": 0,
            "tag": "button",
            "text": "Continue",
            "selector": "button.continue",
            "x": 50,
            "y": 60,
        }
    ]

    target = await ctrl.click_clickable_index(0)

    assert target["text"] == "Continue"
    assert ctrl.page is popup_page
    popup_page.bring_to_front.assert_awaited_once()
    popup_page.on.assert_called_once()


@pytest.mark.asyncio
async def test_inspect_page_state返回结构化页面上下文() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.is_closed.return_value = False
    fake_page.evaluate = AsyncMock(
        side_effect=[
            [
                {
                    "index": 0,
                    "tag": "button",
                    "text": "Next step",
                    "selector": "button.next",
                    "x": 100,
                    "y": 200,
                }
            ],
            {
                "title": "DeepSeek",
                "viewport": {"width": 1280, "height": 720, "scroll_x": 0, "scroll_y": 0},
                "inputs": [
                    {
                        "index": 0,
                        "tag": "input",
                        "type": "text",
                        "placeholder": "Amount",
                        "value_preview": "10",
                    }
                ],
                "visible_text": ["Top up", "Pricing", "Next step"],
            },
        ]
    )
    ctrl._page = fake_page

    state = await ctrl.inspect_page_state(clickable_limit=10, text_limit=20)

    assert state["title"] == "DeepSeek"
    assert state["clickables"][0]["text"] == "Next step"
    assert state["inputs"][0]["placeholder"] == "Amount"
    assert state["visible_text"] == ["Top up", "Pricing", "Next step"]
    assert fake_page.evaluate.await_count == 2


@pytest.mark.asyncio
async def test_click_clickable_text模糊匹配() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.is_closed.return_value = False
    fake_page.click = AsyncMock()
    fake_page.mouse = MagicMock()
    fake_page.mouse.click = AsyncMock()
    ctrl._page = fake_page
    ctrl._last_clickables = [
        {
            "index": 0,
            "tag": "button",
            "text": "确认并支付",
            "selector": "button.pay",
            "x": 11,
            "y": 22,
        }
    ]

    target = await ctrl.click_clickable_text("支付")

    assert target["index"] == 0
    fake_page.click.assert_awaited_once()


@pytest.mark.asyncio
async def test_click_clickable_text未命中抛错() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.is_closed.return_value = False
    fake_page.evaluate = AsyncMock(return_value=[])
    ctrl._page = fake_page

    with pytest.raises(BrowserControllerError, match="未找到匹配文本"):
        await ctrl.click_clickable_text("不存在的按钮")


@pytest.mark.asyncio
async def test_launch_ephemeral_cdp_mirror_connects_over_cdp(
    tmp_path: Path,
) -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.on = MagicMock()
    fake_context = MagicMock()
    fake_browser = MagicMock()
    fake_browser.contexts = [fake_context]
    fake_playwright = MagicMock()
    fake_playwright.chromium.connect_over_cdp = AsyncMock(return_value=fake_browser)
    fake_playwright_manager = MagicMock()
    fake_playwright_manager.start = AsyncMock(return_value=fake_playwright)
    mirror = CdpMirrorInstance(
        source_user_data_dir=tmp_path / "Chrome",
        mirror_user_data_dir=tmp_path / "tmp-mirror",
        profile_directory="Profile 10",
        cdp_port=39333,
        cdp_url="http://127.0.0.1:39333",
        log_path=tmp_path / "chrome.log",
    )

    with patch(
        "payswitch.browser.cdp_mirror.prepare_ephemeral_cdp_mirror",
        return_value=mirror,
    ) as prepare, patch(
        "payswitch.browser.controller.async_playwright",
        return_value=fake_playwright_manager,
    ), patch.object(
        BrowserController,
        "_resolve_attached_page",
        AsyncMock(return_value=fake_page),
    ):
        await ctrl.launch(
            ephemeral_cdp_mirror_source_user_data_dir=tmp_path / "Chrome",
            ephemeral_cdp_mirror_profile_directory="Profile 10",
            browser_channel="chrome",
            session_key="tx-1",
        )

    prepare.assert_called_once_with(
        source_user_data_dir=tmp_path / "Chrome",
        profile_directory="Profile 10",
        session_key="tx-1",
        browser_channel="chrome",
    )
    fake_playwright.chromium.connect_over_cdp.assert_awaited_once_with(
        "http://127.0.0.1:39333"
    )
    assert ctrl._attached_cdp is True
    assert ctrl.page is fake_page


@pytest.mark.asyncio
@pytest.mark.browser
async def test_list_clickable_elements识别文本包裹的可点击容器() -> None:
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=True)
        try:
            page = await browser.new_page()
            await page.set_content(
                """
                <div
                  class="upgrade-cta"
                  style="cursor: pointer; display: inline-block; padding: 12px 18px;"
                >
                  <span>Upgrade your plan</span>
                </div>
                """
            )
            ctrl = BrowserController()
            ctrl._page = page

            items = await ctrl.list_clickable_elements(limit=20)

            assert any(
                item["text"] == "Upgrade your plan" and "upgrade-cta" in item["selector"]
                for item in items
            )
        finally:
            await browser.close()


@pytest.mark.asyncio
async def test_launch_cdp_session_key复用已有标签页() -> None:
    ctrl = BrowserController()
    existing_page = MagicMock()
    existing_page.is_closed.return_value = False
    existing_page.evaluate = AsyncMock(return_value="payswitch:txn_123")
    existing_page.bring_to_front = AsyncMock()
    existing_page.on = MagicMock()

    context = MagicMock()
    context.pages = [existing_page]
    context.new_page = AsyncMock()

    browser = MagicMock()
    browser.contexts = [context]

    playwright = MagicMock()
    playwright.chromium.connect_over_cdp = AsyncMock(return_value=browser)
    playwright.stop = AsyncMock()

    starter = MagicMock()
    starter.start = AsyncMock(return_value=playwright)

    with patch("payswitch.browser.controller.async_playwright", return_value=starter):
        await ctrl.launch(
            chrome_cdp_url="http://127.0.0.1:9223",
            session_key="txn_123",
        )
        reused_flag = ctrl.reused_existing_page
        await ctrl.close()

    assert reused_flag is True
    context.new_page.assert_not_called()
    existing_page.bring_to_front.assert_awaited_once()
    existing_page.on.assert_called_once()


@pytest.mark.asyncio
async def test_launch_cdp_session_key未命中时新建并打标() -> None:
    ctrl = BrowserController()
    new_page = MagicMock()
    new_page.evaluate = AsyncMock()
    new_page.on = MagicMock()

    context = MagicMock()
    context.pages = []
    context.new_page = AsyncMock(return_value=new_page)

    browser = MagicMock()
    browser.contexts = [context]

    playwright = MagicMock()
    playwright.chromium.connect_over_cdp = AsyncMock(return_value=browser)
    playwright.stop = AsyncMock()

    starter = MagicMock()
    starter.start = AsyncMock(return_value=playwright)

    with patch("payswitch.browser.controller.async_playwright", return_value=starter):
        await ctrl.launch(
            chrome_cdp_url="http://127.0.0.1:9223",
            session_key="txn_456",
        )
        reused_flag = ctrl.reused_existing_page
        await ctrl.close()

    assert reused_flag is False
    context.new_page.assert_awaited_once()
    new_page.evaluate.assert_awaited_once_with(
        "(marker) => { window.name = marker; }",
        "payswitch:txn_456",
    )
    new_page.on.assert_called_once()


@pytest.mark.asyncio
async def test_launch_user_chrome_profile被占用时给出可操作错误(tmp_path) -> None:
    ctrl = BrowserController()
    chrome_root = tmp_path / "Chrome"
    chrome_root.mkdir()
    active_process = MagicMock()
    active_process.remote_debugging_port = "9224"

    with patch(
        "payswitch.browser.chrome_profiles.find_active_chrome_user_data_process",
        return_value=active_process,
    ), patch("payswitch.browser.controller.async_playwright") as mock_playwright:
        with pytest.raises(BrowserControllerError, match="同一个 Chrome User Data 目录已经在运行"):
            await ctrl.launch(
                chrome_user_data_dir=chrome_root,
                chrome_profile_directory="Profile 10",
                browser_channel="chrome",
            )

    mock_playwright.assert_not_called()
