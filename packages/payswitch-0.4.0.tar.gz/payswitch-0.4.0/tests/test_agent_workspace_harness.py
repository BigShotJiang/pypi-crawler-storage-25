import asyncio

import pytest

from payswitch.agent_language import PaymentIntent
from payswitch.agent_workspace import AgentWorkspaceManager


def _intent(user_id: str, payee: str = "kimi") -> PaymentIntent:
    return PaymentIntent(
        amount=10,
        currency="CNY",
        payee=payee,
        reason=f"{payee} subagent harness",
        method="alipay_qr",
        source_agent="codex",
        metadata={"user_id": user_id},
    )


def test_workspace_capacity_rejects_zero_limit() -> None:
    with pytest.raises(ValueError, match="max_active_sessions_per_workspace"):
        AgentWorkspaceManager(max_active_sessions_per_workspace=0)


@pytest.mark.asyncio
async def test_workspace_capacity_queues_same_user_but_not_other_users() -> None:
    manager = AgentWorkspaceManager(max_active_sessions_per_workspace=1)
    first = await manager.start_session("task_a", _intent("alice", "kimi"))
    same_user_task = asyncio.create_task(
        manager.start_session("task_b", _intent("alice", "jimeng"))
    )
    other_user = await manager.start_session("task_c", _intent("bob", "kimi"))

    try:
        await asyncio.sleep(0.01)
        assert not same_user_task.done()
        queued = await manager.get_session("task_b")
        assert queued is not None
        assert queued.status == "queued"
        assert queued.queued_reason == "workspace_capacity"

        await first.release()
        same_user = await asyncio.wait_for(same_user_task, timeout=1)
        try:
            assert same_user.status == "running"
            assert same_user.workspace_id == first.workspace_id
        finally:
            await same_user.release()
    finally:
        await other_user.release()
        if not first.released:
            await first.release()
        if not same_user_task.done():
            same_user_task.cancel()


@pytest.mark.asyncio
async def test_foreground_lease_is_one_per_workspace_and_isolated_by_user() -> None:
    manager = AgentWorkspaceManager()
    first = await manager.start_session("task_a", _intent("alice", "kimi"))
    second = await manager.start_session("task_b", _intent("alice", "jimeng"))
    other = await manager.start_session("task_c", _intent("bob", "kimi"))
    first_foreground = await manager.acquire_foreground("task_a", reason="human_gate")
    blocked_foreground = asyncio.create_task(
        manager.acquire_foreground("task_b", reason="human_gate")
    )
    other_foreground = await manager.acquire_foreground("task_c", reason="human_gate")

    try:
        await asyncio.sleep(0.01)
        assert not blocked_foreground.done()
        assert first_foreground.lease_id.startswith("fg_")
        assert other_foreground.lease_id.startswith("fg_")

        await first_foreground.release()
        resumed = await asyncio.wait_for(blocked_foreground, timeout=1)
        try:
            assert resumed.task_id == "task_b"
        finally:
            await resumed.release()
    finally:
        await other_foreground.release()
        await first.release()
        await second.release()
        await other.release()
        if not blocked_foreground.done():
            blocked_foreground.cancel()
