from __future__ import annotations

import asyncio
from pathlib import Path

from payswitch.experience import (
    ExperienceStore,
    RecoveryImprovementRunner,
    RecoveryImprovementSupervisor,
    get_recipe,
)
from payswitch.experience.models import RecoveryImprovementStatus


def _store(tmp_path: Path) -> ExperienceStore:
    return ExperienceStore(tmp_path / "experience" / "recipes.db")


def test_recovery_improvement_runner_run_once_processes_accepted_items(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    builtin = get_recipe("kimi", "membership_monthly_qr")
    assert builtin is not None

    patch_id = store.register_patch(
        recipe=builtin.model_copy(deep=True),
        source="script_recovery",
    )
    improvement_id = store.record_recovery_improvement(
        patch_id=patch_id,
        tx_id="tx-123",
        platform="kimi",
        flow="membership_monthly_qr",
        artifact_path="/tmp/tx-123-patch-1.json",
        summary={"outcome": "scan_qr"},
    )
    store.update_recovery_improvement_status(
        improvement_id,
        status=RecoveryImprovementStatus.accepted,
        reviewer="ops",
    )

    runner = RecoveryImprovementRunner(
        store,
        poll_interval_seconds=0,
        batch_limit=10,
        max_idle_polls=2,
    )
    result = runner.run_once(reviewer="watchdog")
    assert result.processed == 1
    assert result.reviewed_patches == 1
    assert store.get_patch(patch_id)["state"] == "reviewed"
    assert store.get_recovery_improvement(improvement_id)["status"] == "applied"


def test_recovery_improvement_runner_run_loop_stops_after_idle_polls(
    tmp_path: Path,
) -> None:
    store = _store(tmp_path)
    sleeps: list[float] = []
    runner = RecoveryImprovementRunner(
        store,
        poll_interval_seconds=1.5,
        batch_limit=5,
        max_idle_polls=2,
        sleep_fn=sleeps.append,
    )

    summary = runner.run_loop(reviewer="watchdog", max_cycles=4)
    assert summary["cycles"] == 2
    assert summary["idle_polls"] == 2
    assert summary["total_processed"] == 0
    assert sleeps == [1.5]


def test_recovery_improvement_supervisor_processes_items_and_updates_snapshot(
    tmp_path: Path,
) -> None:
    async def _exercise() -> None:
        store = _store(tmp_path)
        builtin = get_recipe("kimi", "membership_monthly_qr")
        assert builtin is not None

        patch_id = store.register_patch(
            recipe=builtin.model_copy(deep=True),
            source="script_recovery",
        )
        improvement_id = store.record_recovery_improvement(
            patch_id=patch_id,
            tx_id="tx-123",
            platform="kimi",
            flow="membership_monthly_qr",
            artifact_path="/tmp/tx-123-patch-1.json",
            summary={"outcome": "scan_qr"},
        )
        store.update_recovery_improvement_status(
            improvement_id,
            status=RecoveryImprovementStatus.accepted,
            reviewer="ops",
        )

        supervisor = RecoveryImprovementSupervisor(
            store,
            reviewer="watchdog",
            poll_interval_seconds=0.01,
            batch_limit=5,
        )
        await supervisor.start()
        try:
            for _ in range(50):
                snapshot = supervisor.snapshot()
                if int(snapshot["total_processed"]) >= 1:
                    break
                await asyncio.sleep(0.01)
            else:
                raise AssertionError("supervisor did not process accepted improvements")
        finally:
            await supervisor.stop()

        snapshot = supervisor.snapshot()
        assert snapshot["enabled"] is True
        assert snapshot["running"] is False
        assert int(snapshot["cycles"]) >= 1
        assert int(snapshot["total_processed"]) >= 1
        assert store.get_patch(patch_id)["state"] == "reviewed"
        assert store.get_recovery_improvement(improvement_id)["status"] == "applied"

    asyncio.run(_exercise())


def test_recovery_improvement_supervisor_can_auto_accept_open_improvements(
    tmp_path: Path,
) -> None:
    async def _exercise() -> None:
        store = _store(tmp_path)
        builtin = get_recipe("kimi", "membership_monthly_qr")
        assert builtin is not None

        patch_id = store.register_patch(
            recipe=builtin.model_copy(deep=True),
            source="script_recovery",
        )
        store.mark_shadow_run_success(patch_id)
        improvement_id = store.record_recovery_improvement(
            patch_id=patch_id,
            tx_id="tx-234",
            platform="kimi",
            flow="membership_monthly_qr",
            artifact_path="/tmp/tx-234-patch-1.json",
            summary={"outcome": "scan_qr"},
        )

        supervisor = RecoveryImprovementSupervisor(
            store,
            reviewer="watchdog",
            auto_accept_basis="shadow_run_success",
            poll_interval_seconds=0.01,
            batch_limit=5,
        )
        await supervisor.start()
        try:
            for _ in range(50):
                snapshot = supervisor.snapshot()
                if int(snapshot["total_auto_accepted"]) >= 1 and int(
                    snapshot["total_processed"]
                ) >= 1:
                    break
                await asyncio.sleep(0.01)
            else:
                raise AssertionError("supervisor did not auto-accept open improvements")
        finally:
            await supervisor.stop()

        snapshot = supervisor.snapshot()
        assert snapshot["auto_accept_basis"] == "shadow_run_success"
        assert snapshot["min_shadow_runs"] == 1
        assert int(snapshot["total_auto_accepted"]) >= 1
        assert store.get_recovery_improvement(improvement_id)["status"] == "applied"
        assert store.get_patch(patch_id)["state"] == "reviewed"

    asyncio.run(_exercise())


def test_recovery_improvement_supervisor_respects_min_shadow_runs(
    tmp_path: Path,
) -> None:
    async def _exercise() -> None:
        store = _store(tmp_path)
        builtin = get_recipe("kimi", "membership_monthly_qr")
        assert builtin is not None

        patch_id = store.register_patch(
            recipe=builtin.model_copy(deep=True),
            source="script_recovery",
        )
        store.mark_shadow_run_success(patch_id)
        improvement_id = store.record_recovery_improvement(
            patch_id=patch_id,
            tx_id="tx-shadow-threshold",
            platform="kimi",
            flow="membership_monthly_qr",
            artifact_path="/tmp/tx-shadow-threshold.json",
            summary={"outcome": "scan_qr"},
        )

        supervisor = RecoveryImprovementSupervisor(
            store,
            reviewer="watchdog",
            auto_accept_basis="shadow_run_success",
            min_shadow_runs=2,
            poll_interval_seconds=0.01,
            batch_limit=5,
        )
        await supervisor.start()
        try:
            await asyncio.sleep(0.05)
        finally:
            await supervisor.stop()

        snapshot = supervisor.snapshot()
        assert snapshot["min_shadow_runs"] == 2
        assert int(snapshot["total_auto_accepted"]) == 0
        assert store.get_recovery_improvement(improvement_id)["status"] == "open"
        assert store.get_patch(patch_id)["state"] == "shadow_run"

    asyncio.run(_exercise())
