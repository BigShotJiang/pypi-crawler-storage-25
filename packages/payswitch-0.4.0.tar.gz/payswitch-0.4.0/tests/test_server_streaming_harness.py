import asyncio
import json

from payswitch.agent_language import PaymentIntent
from payswitch.server import _event, _sse, store, workspace_manager


def _run(coro):
    return asyncio.run(coro)


async def _reset_store() -> None:
    await store.clear()
    await workspace_manager.reset()


def test_sse_payload_has_replayable_id_and_event_sequence() -> None:
    payload = {"sequence": 7, "type": "observe", "summary": "ready"}

    encoded = _sse(payload)

    assert encoded.startswith("id: 7\n")
    assert json.loads(encoded.split("data: ", 1)[1])["sequence"] == 7


def test_task_store_assigns_monotonic_sequences_and_replays_after_checkpoint() -> None:
    _run(_reset_store())
    intent = PaymentIntent(amount=10, currency="CNY", payee="kimi", source_agent="codex")
    task = _run(store.create(intent))

    _run(
        store.emit(
            task.id,
            _event(task=task, kind="observe", summary="first", message="first event"),
        )
    )
    _run(
        store.emit(
            task.id,
            _event(task=task, kind="observe", summary="second", message="second event"),
        )
    )

    saved = _run(store.get(task.id))
    assert saved is not None
    assert [event["sequence"] for event in saved.events] == [1, 2]

    queue = _run(store.subscribe(task.id, after_sequence=1))
    replay = _run(queue.get())
    assert replay["summary"] == "second"
    assert replay["sequence"] == 2


def test_task_store_status_updates_are_replayable_stream_events() -> None:
    _run(_reset_store())
    intent = PaymentIntent(
        amount=10,
        currency="CNY",
        payee="kimi",
        source_agent="codex",
        metadata={"user_id": "alice"},
    )
    task = _run(store.create(intent))

    _run(store.update(task.id, status="working"))

    saved = _run(store.get(task.id))
    assert saved is not None
    assert saved.events[-1]["sequence"] == 1
    assert saved.events[-1]["type"] == "observe"
    assert saved.events[-1]["user_id"] == "alice"
    assert saved.events[-1]["workspace_id"].startswith("uws_")


def test_streaming_events_redact_plaintext_secrets_before_storage() -> None:
    _run(_reset_store())
    intent = PaymentIntent(amount=10, currency="CNY", payee="deepseek", source_agent="codex")
    task = _run(store.create(intent))

    _run(
        store.emit(
            task.id,
            {
                "type": "completed",
                "summary": "secret delivered",
                "details": {
                    "api_key": "sk-live-plaintext",
                    "nested": {"refresh_token": "rt-refresh-plaintext"},
                },
            },
        )
    )

    saved = _run(store.get(task.id))
    assert saved is not None
    serialized = json.dumps(saved.events)
    assert "sk-live-plaintext" not in serialized
    assert "rt-refresh-plaintext" not in serialized
    assert saved.events[0]["details"]["api_key"] == "[REDACTED]"
