"""卡表单检测与填写引擎测试。

测试 is_field_match 匹配逻辑、Stripe 模式检测、动态挑战检测。
使用 MagicMock/AsyncMock 模拟 Playwright Page/Locator，不需要真实浏览器。
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from payswitch.engine.card_filler import (
    CARD_NUMBER_CONTAINS,
    CARD_NUMBER_OPTIONS,
    CARDHOLDER_CONTAINS,
    CARDHOLDER_OPTIONS,
    CVV_OPTIONS,
    EXPIRY_OPTIONS,
    CardFormFields,
    CardFormFiller,
    CardFormNotFoundError,
    detect_stripe_mode,
    is_field_match,
)
from payswitch.security.card_vault import BillingAddress, VirtualCardData


def _make_mock_page(url: str = "https://example.com/checkout") -> MagicMock:
    """创建 mock Page 对象。

    page.locator() 是同步方法（返回 Locator），
    locator.count() 是异步方法。
    """
    page = MagicMock()
    page.url = url
    # 默认 locator().count() 返回 0
    page.locator.return_value.count = AsyncMock(return_value=0)
    return page


def _make_locator_side_effect(match_keyword: str):
    """创建 locator side_effect，匹配 keyword 的 selector 返回 count=1。"""

    def side_effect(selector):
        loc = MagicMock()
        if match_keyword in selector:
            loc.count = AsyncMock(return_value=1)
        else:
            loc.count = AsyncMock(return_value=0)
        return loc

    return side_effect


# ============================================================================
# is_field_match 匹配逻辑测试
# ============================================================================


class TestIsFieldMatch:
    """is_field_match 匹配算法测试。"""

    def test_精确匹配_cc_number(self):
        assert is_field_match("cc-number", CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS)

    def test_精确匹配_不区分大小写(self):
        assert is_field_match("CC-Number", CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS)

    def test_子串匹配_card_number_input(self):
        """包含 card-number 的属性值应通过子串匹配。"""
        assert is_field_match("my-card-number-input", CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS)

    def test_子串匹配_number_被阻止(self):
        """'number' 不在 CARD_NUMBER_CONTAINS 中，不应子串匹配 'phone-number'。"""
        assert not is_field_match("phone-number", CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS)

    def test_精确匹配_number(self):
        """'number' 在 CARD_NUMBER_OPTIONS 中，精确匹配时应通过。"""
        assert is_field_match("number", CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS)

    def test_标准化_去除非字母数字(self):
        """Card--Number 标准化后应匹配 card-number。"""
        assert is_field_match("Card--Number", CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS)

    def test_空字符串返回False(self):
        assert not is_field_match("", CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS)

    def test_空白字符串返回False(self):
        assert not is_field_match("   ", CARD_NUMBER_OPTIONS, CARD_NUMBER_CONTAINS)

    def test_cvv匹配(self):
        assert is_field_match("cvv", CVV_OPTIONS)

    def test_cvv子串匹配(self):
        """CVV_OPTIONS 的 contains_options 为 None，全部允许子串匹配。"""
        assert is_field_match("my-cvv-input", CVV_OPTIONS)

    def test_cvc匹配(self):
        assert is_field_match("cvc", CVV_OPTIONS)

    def test_security_code匹配(self):
        assert is_field_match("security-code", CVV_OPTIONS)

    def test_expiry匹配(self):
        assert is_field_match("cc-exp", EXPIRY_OPTIONS)

    def test_持卡人_name_精确匹配(self):
        """'name' 在 CARDHOLDER_OPTIONS 中，精确匹配应通过。"""
        assert is_field_match("name", CARDHOLDER_OPTIONS, CARDHOLDER_CONTAINS)

    def test_持卡人_name_不子串匹配first_name(self):
        """'name' 不在 CARDHOLDER_CONTAINS 中，不应子串匹配 'first-name'。"""
        assert not is_field_match("first-name", CARDHOLDER_OPTIONS, CARDHOLDER_CONTAINS)

    def test_contains_options为None时全部允许子串(self):
        """contains_options=None 表示全部允许子串匹配。"""
        assert is_field_match("my-cvv-field", CVV_OPTIONS, None)


# ============================================================================
# Stripe 模式检测测试
# ============================================================================


class TestDetectStripeMode:
    """Stripe 集成模式检测测试。"""

    async def test_prebuilt_checkout_模式(self):
        page = _make_mock_page("https://checkout.stripe.com/c/pay/cs_test_xxx")
        result = await detect_stripe_mode(page)
        assert result == "prebuilt_checkout"

    async def test_checkout_sessions_模式(self):
        page = _make_mock_page()
        page.locator.side_effect = _make_locator_side_effect('title="Secure payment input frame"')
        result = await detect_stripe_mode(page)
        assert result == "checkout_sessions"

    async def test_payment_element_模式(self):
        page = _make_mock_page()
        page.locator.side_effect = _make_locator_side_effect("elements-inner-payment")
        result = await detect_stripe_mode(page)
        assert result == "payment_element"

    async def test_custom_elements_模式(self):
        page = _make_mock_page()
        page.locator.side_effect = _make_locator_side_effect("__privateStripeFrame")
        result = await detect_stripe_mode(page)
        assert result == "custom_elements"

    async def test_非Stripe页面返回None(self):
        page = _make_mock_page()
        result = await detect_stripe_mode(page)
        assert result is None


# ============================================================================
# CardFormFiller 动态挑战检测测试
# ============================================================================


class TestDynamicChallenges:
    """动态安全挑战检测测试。"""

    @pytest.fixture
    def filler(self):
        return CardFormFiller()

    async def test_检测OTP验证码(self, filler):
        page = _make_mock_page()
        page.locator.side_effect = _make_locator_side_effect("one-time-code")
        challenges = await filler._detect_dynamic_challenges(page)
        assert "OTP 验证码" in challenges

    async def test_检测3DS验证(self, filler):
        page = _make_mock_page()
        page.locator.side_effect = _make_locator_side_effect("3ds")
        challenges = await filler._detect_dynamic_challenges(page)
        assert "3DS 安全验证" in challenges

    async def test_检测CAPTCHA(self, filler):
        page = _make_mock_page()
        page.locator.side_effect = _make_locator_side_effect("recaptcha")
        challenges = await filler._detect_dynamic_challenges(page)
        assert "CAPTCHA 验证" in challenges

    async def test_无挑战返回空列表(self, filler):
        page = _make_mock_page()
        challenges = await filler._detect_dynamic_challenges(page)
        assert challenges == []


# ============================================================================
# CardFormFiller 填写流程测试
# ============================================================================


class TestCardFormFiller:
    """CardFormFiller 全字段填写流程测试。"""

    @pytest.fixture
    def card_data(self):
        return VirtualCardData(
            card_number="4242424242424242",
            expiry_month="04",
            expiry_year="31",
            cvv="625",
            holder_name="Loki White",
            billing_address=BillingAddress(
                line1="951 Brickell Ave 2800",
                city="Miami",
                state="FL",
                postal_code="33131",
                country="US",
            ),
        )

    @pytest.fixture
    def mock_fields(self):
        """创建全字段的 mock CardFormFields。"""
        return CardFormFields(
            card_number=AsyncMock(),
            expiry=AsyncMock(),
            cvv=AsyncMock(),
            cardholder_name=AsyncMock(),
            billing_address=AsyncMock(),
            billing_city=AsyncMock(),
            billing_state=AsyncMock(),
            billing_postal=AsyncMock(),
            billing_country=AsyncMock(),
            is_iframe=False,
            processor=None,
            confidence=0.8,
            detection_level=1,
        )

    def _make_filler_with_fields(self, fields):
        filler = CardFormFiller()
        filler.detector = MagicMock()
        filler.detector.detect = AsyncMock(return_value=fields)
        return filler

    def _make_challenge_free_page(self):
        page = _make_mock_page()
        return page

    async def test_全字段填写(self, card_data, mock_fields):
        """验证全部字段被填写。"""
        filler = self._make_filler_with_fields(mock_fields)
        page = self._make_challenge_free_page()

        with patch(
            "payswitch.security.card_vault.load_virtual_card",
            return_value=card_data,
        ):
            result = await filler.detect_and_fill(page, "test_ref")

        assert "card_number" in result.filled_fields
        assert "expiry" in result.filled_fields
        assert "cvv" in result.filled_fields
        assert "cardholder_name" in result.filled_fields
        assert "billing_address" in result.filled_fields

    async def test_dry_run不实际填写(self, card_data, mock_fields):
        """dry_run 模式不应调用 fill()。"""
        filler = self._make_filler_with_fields(mock_fields)
        page = self._make_challenge_free_page()

        with patch(
            "payswitch.security.card_vault.load_virtual_card",
            return_value=card_data,
        ):
            result = await filler.detect_and_fill(page, "test_ref", dry_run=True)

        mock_fields.card_number.fill.assert_not_called()
        assert "card_number" in result.filled_fields

    async def test_未检测到卡号抛出异常(self):
        """card_number 为 None 时应抛出 CardFormNotFoundError。"""
        filler = self._make_filler_with_fields(CardFormFields())
        page = MagicMock()

        with pytest.raises(CardFormNotFoundError, match="未检测到卡号"):
            await filler.detect_and_fill(page, "test_ref")

    async def test_向后兼容_仅卡号(self):
        """旧格式 card_number_only 应 fallback 到 load_card_number。"""
        fields = CardFormFields(card_number=AsyncMock())
        filler = self._make_filler_with_fields(fields)
        page = self._make_challenge_free_page()

        with (
            patch(
                "payswitch.security.card_vault.load_virtual_card",
                return_value=None,
            ),
            patch(
                "payswitch.security.card_vault.load_card_number",
                return_value="4242424242424242",
            ),
        ):
            result = await filler.detect_and_fill(page, "test_ref")

        assert "card_number" in result.filled_fields

    async def test_Stripe_iframe_用press_sequentially(self, card_data):
        """Stripe iframe 中应使用 press_sequentially 而不是 fill。"""
        card_number_locator = AsyncMock()
        fields = CardFormFields(
            card_number=card_number_locator,
            is_iframe=True,
            processor="stripe_custom_elements",
        )
        filler = self._make_filler_with_fields(fields)
        page = self._make_challenge_free_page()

        with patch(
            "payswitch.security.card_vault.load_virtual_card",
            return_value=card_data,
        ):
            await filler.detect_and_fill(page, "test_ref")

        card_number_locator.press_sequentially.assert_called_once_with("4242424242424242", delay=50)

    async def test_select元素用select_option(self):
        """state/country 的 <select> 应用 select_option。"""
        filler = CardFormFiller()
        country_locator = AsyncMock()
        country_locator.evaluate = AsyncMock(return_value="select")
        await filler._select_or_fill(country_locator, "US")
        country_locator.select_option.assert_called_once_with(value="US")

    async def test_input元素用fill(self):
        """普通 input 应用 fill。"""
        filler = CardFormFiller()
        state_locator = AsyncMock()
        state_locator.evaluate = AsyncMock(return_value="input")
        await filler._select_or_fill(state_locator, "FL")
        state_locator.fill.assert_called_once_with("FL")

    async def test_有效期分离字段(self, card_data):
        """月/年分离的有效期字段应分别填入。"""
        month_locator = AsyncMock()
        year_locator = AsyncMock()
        fields = CardFormFields(
            card_number=AsyncMock(),
            expiry_month=month_locator,
            expiry_year=year_locator,
        )
        filler = self._make_filler_with_fields(fields)
        page = self._make_challenge_free_page()

        with patch(
            "payswitch.security.card_vault.load_virtual_card",
            return_value=card_data,
        ):
            result = await filler.detect_and_fill(page, "test_ref")

        month_locator.fill.assert_called_once_with("04")
        year_locator.fill.assert_called_once_with("31")
        assert "expiry" in result.filled_fields

    async def test_地址填入后Escape和Tab(self, card_data):
        """地址字段填入后应按 Escape 关闭自动补全，再 Tab 到下一字段。"""
        addr_locator = AsyncMock()
        fields = CardFormFields(
            card_number=AsyncMock(),
            billing_address=addr_locator,
        )
        filler = self._make_filler_with_fields(fields)
        page = self._make_challenge_free_page()

        with patch(
            "payswitch.security.card_vault.load_virtual_card",
            return_value=card_data,
        ):
            await filler.detect_and_fill(page, "test_ref")

        addr_locator.press.assert_any_call("Escape")
        addr_locator.press.assert_any_call("Tab")
