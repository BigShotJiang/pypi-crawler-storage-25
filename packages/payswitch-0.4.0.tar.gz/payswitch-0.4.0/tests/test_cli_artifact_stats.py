from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from payswitch.cli import app
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore


def test_artifact_stats_cli_reports_budget_signal(
    tmp_path: Path,
    monkeypatch,
) -> None:
    store = ArtifactStore(tmp_path)
    store.write_bytes(
        tmp_path / "evidence" / "external" / "shot.png",
        b"\x89PNG\r\nfake",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
    )
    monkeypatch.setattr("payswitch.cli._artifact_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["--json", "artifact", "stats", "--budget-mb", "0.00001"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["artifacts"] == 1
    assert payload["encrypted_artifacts"] == 1
    assert payload["over_budget"] is True
