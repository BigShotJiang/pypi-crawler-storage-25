from __future__ import annotations

from pathlib import Path

from payswitch.engine.ledger import Ledger
from payswitch.models.transaction import Transaction
from payswitch.security.screenshot_budget import TransactionScreenshotBudget


def test_transaction_screenshot_budget_exhausts_and_applies_to_transaction() -> None:
    tx = Transaction(amount=19, payee="kimi")
    budget = TransactionScreenshotBudget.from_transaction(tx, limit=2)

    first = budget.register_capture(
        artifact_kind="external_observation_screenshot",
        capture_reason="first observe screenshot",
        artifact_path=Path("/tmp/shot-1.png"),
    )
    second = budget.register_capture(
        artifact_kind="recovery_screenshot",
        capture_reason="recovery checkpoint screenshot",
        artifact_path=Path("/tmp/shot-2.png"),
    )
    third = budget.register_capture(
        artifact_kind="recovery_screenshot",
        capture_reason="recovery resynchronization screenshot",
        artifact_path=Path("/tmp/shot-3.png"),
    )

    assert first.allowed is True
    assert second.allowed is True
    assert second.state.exhausted is True
    assert third.allowed is False
    assert "before recovery resynchronization screenshot" in third.reason

    updated = budget.apply(tx)
    assert updated.budget_state is not None
    assert updated.budget_state.screenshots is not None
    assert updated.budget_state.screenshots.used == 2
    assert updated.budget_state.screenshots.remaining == 0
    assert updated.budget_state.screenshots.exhausted is True
    assert updated.budget_state.screenshots.last_artifact_kind == "recovery_screenshot"


def test_ledger_round_trips_transaction_budget_state(tmp_path: Path) -> None:
    ledger = Ledger(tmp_path / "payswitch.db")
    try:
        tx = Transaction(amount=9, payee="deepseek")
        budget = TransactionScreenshotBudget.from_transaction(tx, limit=1)
        budget.register_capture(
            artifact_kind="recipe_waypoint_screenshot",
            capture_reason="recipe waypoint failure screenshot (confirm_checkout)",
            artifact_path=tmp_path / "shot.png",
        )
        persisted = budget.apply(tx)

        ledger.record(persisted)
        restored = ledger.get(persisted.tx_id)
    finally:
        ledger.close()

    assert restored is not None
    assert restored.budget_state is not None
    assert restored.budget_state.screenshots is not None
    assert restored.budget_state.screenshots.limit == 1
    assert restored.budget_state.screenshots.used == 1
    assert restored.budget_state.screenshots.exhausted is True
