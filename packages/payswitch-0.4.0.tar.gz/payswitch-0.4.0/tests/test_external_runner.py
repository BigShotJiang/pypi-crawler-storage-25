"""External-agent checkout runner tests."""

from __future__ import annotations

import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from payswitch.engine.external_runner import ExternalAction, ExternalCheckoutRunner
from payswitch.engine.ledger import Ledger
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import HumanAction, StepRecord, Transaction
from payswitch.models.types import (
    DisplayMode,
    ExecutionMode,
    PaymentMethod,
    TransactionStatus,
)
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore


def _config(tmp_path: Path) -> PaySwitchConfig:
    return PaySwitchConfig(
        data_dir=tmp_path,
        display_mode=DisplayMode.headed,
        transaction_timeout=30,
    )


def test_external_runner_projects_visual_fields_into_runtime_event_payload() -> None:
    payload = ExternalCheckoutRunner._action_result_event_payload(
        {
            "current_url": "https://platform.deepseek.com/topup",
            "screenshot_path": "/tmp/payswitch/evidence/shot.png",
            "detected_payment_methods": ["alipay_qr"],
            "payment_method_resolution": {"selected": "alipay_qr"},
            "interaction_hints": [{"kind": "requires_login", "blocking": True}],
            "screenshot_base64": "not-forwarded-to-sse",
        }
    )

    assert payload == {
        "current_url": "https://platform.deepseek.com/topup",
        "screenshot_path": "/tmp/payswitch/evidence/shot.png",
        "detected_payment_methods": ["alipay_qr"],
        "payment_method_resolution": {"selected": "alipay_qr"},
        "interaction_hints": [{"kind": "requires_login", "blocking": True}],
    }


@pytest.mark.asyncio
async def test_external_runner_stops_on_qr_human_gate(tmp_path: Path) -> None:
    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.get_current_url = AsyncMock(return_value="https://pay.example/qr")
    mock_browser.page = MagicMock()

    qr_detection = MagicMock()
    qr_detection.action_type = "scan_qr"
    qr_detection.detector_name = "QRCodeDetector"
    qr_detection.description = "请扫码完成支付"
    qr_detection.data = {
        "qr_count": 1,
        "qr_type": "img",
        "qr_src": "data:image/png;base64,ZmFrZS1xci1wbmc=",
    }

    qr_detector = MagicMock()
    qr_detector.name = "QRCodeDetector"
    qr_detector.requires_human.return_value = True

    mock_pipeline = MagicMock()
    mock_pipeline._detectors = [qr_detector]
    mock_pipeline.scan = AsyncMock(return_value=qr_detection)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(_config(tmp_path))
        try:
            tx = await runner.run(
                amount=0.9,
                payee="unknown_site",
                method=PaymentMethod.alipay_qr,
                actions=[ExternalAction(type="scan", description="检测支付状态")],
                stop_on_human=True,
            )
        finally:
            runner.close()

    assert tx.status == TransactionStatus.human_action_required
    assert tx.human_action is not None
    assert tx.human_action.action_type == "scan_qr"
    qr_artifact_path = Path(str(tx.human_action.details["qr_artifact_path"]))
    assert ArtifactStore(tmp_path).read_bytes(qr_artifact_path) == b"fake-qr-png"
    assert ArtifactStore(tmp_path).read_content_type(qr_artifact_path) == "image/png"
    mock_display.notify_human.assert_awaited_once()
    mock_display.wait_for_completion.assert_not_called()


@pytest.mark.asyncio
async def test_external_runner_persists_browser_recordings_on_terminal_close(
    tmp_path: Path,
) -> None:
    config = _config(tmp_path)
    raw_recording_dir = tmp_path / "recordings-raw" / "txn-video"
    raw_recording_dir.mkdir(parents=True, exist_ok=True)
    raw_video = raw_recording_dir / "page-1.webm"
    raw_video.write_bytes(b"fake-webm")

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.get_current_url = AsyncMock(return_value="https://pay.example/checkout")
    mock_browser.recorded_video_files = MagicMock(return_value=[raw_video])
    mock_browser.record_video_dir = raw_recording_dir
    mock_browser.video_recording_enabled = True
    mock_browser.page = MagicMock()
    mock_browser.page.bring_to_front = AsyncMock()

    completed_detection = MagicMock()
    completed_detection.action_type = "completed"
    completed_detection.detector_name = "CheckoutDetector"
    completed_detection.description = "支付完成"
    completed_detection.data = {}

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=completed_detection)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
        patch.object(
            ExternalCheckoutRunner,
            "_probe_browser_recording_duration_seconds",
            return_value=4.2,
        ),
        patch.object(
            ExternalCheckoutRunner,
            "_probe_browser_recording_frame_rate",
            return_value=30.0,
        ),
        patch.object(
            ExternalCheckoutRunner,
            "_probe_browser_recording_frame_dimensions",
            return_value=(1280, 720),
        ),
        patch.object(
            ExternalCheckoutRunner,
            "_probe_browser_recording_bit_rate",
            return_value=2_000_000,
        ),
        patch.object(
            ExternalCheckoutRunner,
            "_probe_browser_recording_codec_name",
            return_value="vp8",
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            tx = await runner.run(
                amount=9.9,
                payee="kimi",
                actions=[ExternalAction(type="scan", description="检测支付完成")],
                stop_on_human=False,
            )
        finally:
            runner.close()

    assert tx.status == TransactionStatus.completed
    mock_browser.launch.assert_awaited_once()
    launch_call = mock_browser.launch.await_args
    assert launch_call.kwargs["record_video_dir"] == (
        config.data_dir / "evidence" / "external-recordings-raw" / tx.tx_id
    )
    mock_browser.close.assert_awaited_once()

    persisted_path = config.data_dir / "evidence" / "external-media" / tx.tx_id / "page-1.webm"
    artifact_store = ArtifactStore(config.data_dir)
    assert artifact_store.read_bytes(persisted_path) == b"fake-webm"
    assert artifact_store.read_content_type(persisted_path) == "video/webm"
    metadata = artifact_store.read_metadata(persisted_path)
    assert metadata["artifact_kind"] == "external_browser_recording"
    assert metadata["encrypted"] is True
    assert metadata["metadata"]["tx_id"] == tx.tx_id
    assert metadata["metadata"]["artifact_id"] == "page_1_webm"
    assert metadata["metadata"]["capture_engine"] == "playwright_video"
    assert metadata["metadata"]["recording_index"] == 1
    assert metadata["metadata"]["duration_seconds"] == pytest.approx(4.2)
    assert metadata["metadata"]["frame_rate"] == pytest.approx(30.0)
    assert metadata["metadata"]["bit_rate"] == 2_000_000
    assert metadata["metadata"]["frame_width"] == 1280
    assert metadata["metadata"]["frame_height"] == 720
    assert metadata["metadata"]["codec_name"] == "vp8"
    assert metadata["metadata"]["size_bytes"] == len(b"fake-webm")
    assert raw_video.exists() is False
    assert raw_recording_dir.exists() is False

    event_log = config.data_dir / "events" / f"{tx.tx_id}.jsonl"
    payloads = [json.loads(line) for line in event_log.read_text(encoding="utf-8").splitlines()]
    media_event = next(payload for payload in payloads if payload["type"] == "media.persisted")
    assert media_event["media_artifacts"][0]["artifact_id"] == "page_1_webm"
    assert media_event["media_artifacts"][0]["artifactId"] == "page_1_webm"
    assert media_event["media_artifacts"][0]["recording_index"] == 1
    assert media_event["media_artifacts"][0]["recordingIndex"] == 1
    assert media_event["media_artifacts"][0]["capture_engine"] == "playwright_video"
    assert media_event["media_artifacts"][0]["captureEngine"] == "playwright_video"
    assert media_event["media_artifacts"][0]["duration_seconds"] == pytest.approx(4.2)
    assert media_event["media_artifacts"][0]["durationSeconds"] == pytest.approx(4.2)
    assert media_event["media_artifacts"][0]["frame_rate"] == pytest.approx(30.0)
    assert media_event["media_artifacts"][0]["frameRate"] == pytest.approx(30.0)
    assert media_event["media_artifacts"][0]["bit_rate"] == 2_000_000
    assert media_event["media_artifacts"][0]["bitRate"] == 2_000_000
    assert media_event["media_artifacts"][0]["frame_width"] == 1280
    assert media_event["media_artifacts"][0]["frameWidth"] == 1280
    assert media_event["media_artifacts"][0]["frame_height"] == 720
    assert media_event["media_artifacts"][0]["frameHeight"] == 720
    assert media_event["media_artifacts"][0]["codec_name"] == "vp8"
    assert media_event["media_artifacts"][0]["codecName"] == "vp8"
    assert media_event["media_artifacts"][0]["size_bytes"] == len(b"fake-webm")
    assert media_event["media_artifacts"][0]["sizeBytes"] == len(b"fake-webm")
    assert media_event["media_artifacts"][0]["artifact_path"] == str(persisted_path)
    assert media_event["media_artifacts"][0]["content_type"] == "video/webm"


@pytest.mark.asyncio
async def test_external_runner_synthesizes_browser_recording_from_observation_screenshots(
    tmp_path: Path,
) -> None:
    config = _config(tmp_path)
    raw_recording_dir = tmp_path / "recordings-raw" / "txn-video"
    raw_recording_dir.mkdir(parents=True, exist_ok=True)

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.get_current_url = AsyncMock(return_value="https://pay.example/checkout")
    mock_browser.recorded_video_files = MagicMock(return_value=[])
    mock_browser.record_video_dir = raw_recording_dir
    mock_browser.video_recording_enabled = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(
        return_value={
            "title": "Kimi Checkout",
            "viewport": {"width": 1280, "height": 720, "scroll_x": 0, "scroll_y": 0},
            "clickables": [],
            "inputs": [],
            "visible_text": ["Kimi", "Checkout"],
        }
    )
    mock_browser.page = MagicMock()
    mock_browser.page.bring_to_front = AsyncMock()

    completed_detection = MagicMock()
    completed_detection.action_type = "completed"
    completed_detection.detector_name = "CheckoutDetector"
    completed_detection.description = "支付完成"
    completed_detection.data = {}

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=completed_detection)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}

    def fake_ffmpeg_run(
        cmd: list[str],
        check: bool,
        capture_output: bool,
    ) -> subprocess.CompletedProcess[bytes]:
        output_path = Path(cmd[-1])
        output_path.write_bytes(b"fake-mp4")
        return subprocess.CompletedProcess(cmd, 0, stdout=b"", stderr=b"")

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
        patch("payswitch.engine.external_runner.shutil.which", return_value="/usr/bin/ffmpeg"),
        patch("payswitch.engine.external_runner.subprocess.run", side_effect=fake_ffmpeg_run),
        patch.object(
            ExternalCheckoutRunner,
            "_probe_browser_recording_frame_dimensions",
            return_value=(1280, 720),
        ),
        patch.object(
            ExternalCheckoutRunner,
            "_probe_browser_recording_bit_rate",
            return_value=800_000,
        ),
        patch.object(
            ExternalCheckoutRunner,
            "_probe_browser_recording_codec_name",
            return_value="mpeg4",
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            tx = await runner.run(
                amount=9.9,
                payee="kimi",
                actions=[ExternalAction(type="observe", description="观察并完成支付")],
                stop_on_human=False,
            )
        finally:
            runner.close()

    assert tx.status == TransactionStatus.completed
    persisted_path = (
        config.data_dir / "evidence" / "external-media" / tx.tx_id / "observation-replay.mp4"
    )
    artifact_store = ArtifactStore(config.data_dir)
    assert artifact_store.read_bytes(persisted_path) == b"fake-mp4"
    assert artifact_store.read_content_type(persisted_path) == "video/mp4"
    metadata = artifact_store.read_metadata(persisted_path)
    assert metadata["artifact_kind"] == "external_browser_recording"
    assert metadata["metadata"]["artifact_id"] == "observation_replay_mp4"
    assert metadata["metadata"]["capture_engine"] == "ffmpeg_replay"
    assert metadata["metadata"]["recording_index"] == 1
    assert metadata["metadata"]["duration_seconds"] == pytest.approx(1.0)
    assert metadata["metadata"]["frame_rate"] == pytest.approx(1.0)
    assert metadata["metadata"]["source_screenshot_count"] == 1
    assert metadata["metadata"]["bit_rate"] == 800_000
    assert metadata["metadata"]["frame_width"] == 1280
    assert metadata["metadata"]["frame_height"] == 720
    assert metadata["metadata"]["codec_name"] == "mpeg4"
    assert metadata["metadata"]["size_bytes"] == len(b"fake-mp4")
    assert metadata["metadata"]["recording_source"] == "observation_screenshots"

    event_log = config.data_dir / "events" / f"{tx.tx_id}.jsonl"
    payloads = [json.loads(line) for line in event_log.read_text(encoding="utf-8").splitlines()]
    media_event = next(payload for payload in payloads if payload["type"] == "media.persisted")
    assert media_event["media_artifacts"][0]["artifact_id"] == "observation_replay_mp4"
    assert media_event["media_artifacts"][0]["artifactId"] == "observation_replay_mp4"
    assert media_event["media_artifacts"][0]["recording_index"] == 1
    assert media_event["media_artifacts"][0]["recordingIndex"] == 1
    assert media_event["media_artifacts"][0]["capture_engine"] == "ffmpeg_replay"
    assert media_event["media_artifacts"][0]["captureEngine"] == "ffmpeg_replay"
    assert media_event["media_artifacts"][0]["duration_seconds"] == pytest.approx(1.0)
    assert media_event["media_artifacts"][0]["durationSeconds"] == pytest.approx(1.0)
    assert media_event["media_artifacts"][0]["frame_rate"] == pytest.approx(1.0)
    assert media_event["media_artifacts"][0]["frameRate"] == pytest.approx(1.0)
    assert media_event["media_artifacts"][0]["source_screenshot_count"] == 1
    assert media_event["media_artifacts"][0]["sourceScreenshotCount"] == 1
    assert media_event["media_artifacts"][0]["bit_rate"] == 800_000
    assert media_event["media_artifacts"][0]["bitRate"] == 800_000
    assert media_event["media_artifacts"][0]["frame_width"] == 1280
    assert media_event["media_artifacts"][0]["frameWidth"] == 1280
    assert media_event["media_artifacts"][0]["frame_height"] == 720
    assert media_event["media_artifacts"][0]["frameHeight"] == 720
    assert media_event["media_artifacts"][0]["codec_name"] == "mpeg4"
    assert media_event["media_artifacts"][0]["codecName"] == "mpeg4"
    assert media_event["media_artifacts"][0]["size_bytes"] == len(b"fake-mp4")
    assert media_event["media_artifacts"][0]["sizeBytes"] == len(b"fake-mp4")
    assert media_event["media_artifacts"][0]["artifact_path"] == str(persisted_path)
    assert media_event["media_artifacts"][0]["content_type"] == "video/mp4"
    assert media_event["media_artifacts"][0]["recording_source"] == "observation_screenshots"


@pytest.mark.asyncio
async def test_external_act_observes_existing_handoff_transaction(tmp_path: Path) -> None:
    config = _config(tmp_path)
    tx = Transaction(
        amount=19,
        payee="kimi",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    page_state = {
        "title": "Kimi",
        "viewport": {"width": 1280, "height": 720, "scroll_x": 0, "scroll_y": 0},
        "clickables": [{"index": 0, "text": "Upgrade", "selector": "button"}],
        "inputs": [
            {
                "index": 0,
                "tag": "input",
                "type": "text",
                "placeholder": "Coupon",
                "value_preview": "",
            }
        ],
        "visible_text": ["Kimi", "Upgrade"],
    }
    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.navigate = AsyncMock()
    mock_browser.get_current_url = AsyncMock(return_value="https://www.kimi.com")
    mock_browser.reused_existing_page = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(return_value=page_state)
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                start_url="https://www.kimi.com",
                action=ExternalAction(type="observe", description="观察 Kimi 首页"),
            )
        finally:
            runner.close()

    assert result.action_result["kind"] == "page_observation"
    assert result.action_result["current_url"] == "https://www.kimi.com"
    assert result.action_result["clickables"] == page_state["clickables"]
    assert result.action_result["inputs"] == page_state["inputs"]
    assert result.action_result["visible_text"] == page_state["visible_text"]
    assert result.action_result["screenshot_path"].endswith("-step-0.png")
    assert result.resumed_url == "https://www.kimi.com"
    assert result.current_url == "https://www.kimi.com"
    assert result.transaction.execution_mode == ExecutionMode.computer_use
    assert result.transaction.status == TransactionStatus.executing
    assert result.transaction.steps[-1].description == "观察 Kimi 首页"
    assert result.transaction.steps[-1].evidence_path is not None
    evidence = ArtifactStore(config.data_dir).read_json(
        Path(result.transaction.steps[-1].evidence_path)
    )
    assert evidence["current_url"] == "https://www.kimi.com"
    assert evidence["action"]["type"] == "observe"
    assert evidence["action_result"]["screenshot_path"].endswith("-step-0.png")
    assert evidence["action_result"]["clickables"] == page_state["clickables"]
    screenshot_path = Path(evidence["action_result"]["screenshot_path"])
    screenshot_store = ArtifactStore(config.data_dir)
    assert screenshot_store.read_bytes(screenshot_path) == b"fake-png"
    assert screenshot_store.read_content_type(screenshot_path) == "image/png"
    assert screenshot_store.read_metadata(screenshot_path)["encrypted"] is True
    mock_browser.navigate.assert_awaited_once_with("https://www.kimi.com")
    mock_browser.screenshot.assert_awaited_once()
    mock_browser.inspect_page_state.assert_awaited_once_with(
        clickable_limit=80,
        text_limit=80,
    )
    mock_display.notify_human.assert_not_called()


@pytest.mark.asyncio
async def test_external_act_stops_persisting_screenshots_after_budget_exhaustion(
    tmp_path: Path,
) -> None:
    config = PaySwitchConfig(
        data_dir=tmp_path,
        display_mode=DisplayMode.headed,
        transaction_timeout=30,
        transaction_max_screenshots=1,
    )
    tx = Transaction(
        amount=19,
        payee="kimi",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    page_state = {
        "title": "Kimi",
        "viewport": {"width": 1280, "height": 720, "scroll_x": 0, "scroll_y": 0},
        "clickables": [],
        "inputs": [],
        "visible_text": ["Kimi"],
    }
    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.navigate = AsyncMock()
    mock_browser.get_current_url = AsyncMock(return_value="https://www.kimi.com")
    mock_browser.reused_existing_page = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(return_value=page_state)
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            first = await runner.act(
                tx_id=tx.tx_id,
                start_url="https://www.kimi.com",
                action=ExternalAction(type="observe", description="第一次观察"),
            )
            second = await runner.act(
                tx_id=tx.tx_id,
                start_url="https://www.kimi.com",
                action=ExternalAction(type="observe", description="第二次观察"),
            )
        finally:
            runner.close()

    assert first.action_result["screenshot_path"].endswith("-step-0.png")
    assert first.transaction.budget_state is not None
    assert first.transaction.budget_state.screenshots is not None
    assert first.transaction.budget_state.screenshots.used == 1
    assert first.transaction.budget_state.screenshots.exhausted is True

    assert second.action_result["screenshot_path"] is None
    assert second.action_result["budget_exhausted"] is True
    assert "screenshot budget exhausted before" in second.action_result["budget_exhaustion_reason"]
    assert second.transaction.budget_state is not None
    assert second.transaction.budget_state.screenshots is not None
    assert second.transaction.budget_state.screenshots.used == 1
    assert second.transaction.budget_state.screenshots.exhausted is True
    assert mock_browser.screenshot.await_count == 1


@pytest.mark.asyncio
async def test_external_act_can_return_screenshot_base64(tmp_path: Path) -> None:
    config = _config(tmp_path)
    tx = Transaction(
        amount=10,
        payee="deepseek",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.get_current_url = AsyncMock(return_value="https://platform.deepseek.com/top_up")
    mock_browser.reused_existing_page = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(
        return_value={
            "title": "DeepSeek",
            "viewport": {},
            "clickables": [],
            "inputs": [],
            "visible_text": [],
        }
    )
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                action=ExternalAction(
                    type="observe",
                    description="观察 DeepSeek",
                    include_screenshot_base64=True,
                ),
            )
        finally:
            runner.close()

    assert result.action_result["screenshot_base64"] == "ZmFrZS1wbmc="


@pytest.mark.asyncio
async def test_external_act_observe_includes_login_hint(tmp_path: Path) -> None:
    config = _config(tmp_path)
    tx = Transaction(
        amount=10,
        payee="deepseek",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.get_current_url = AsyncMock(
        return_value="https://platform.deepseek.com/sign_in"
    )
    mock_browser.reused_existing_page = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(
        return_value={
            "title": "DeepSeek Platform",
            "viewport": {},
            "clickables": [{"index": 0, "text": "Log in", "selector": "button"}],
            "inputs": [
                {"placeholder": "Phone number / email address", "type": "text"},
                {"placeholder": "Password", "type": "password"},
            ],
            "visible_text": ["Log in", "Scan with Wechat to login"],
        }
    )
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                action=ExternalAction(type="observe", description="观察登录页"),
            )
        finally:
            runner.close()

    hints = result.action_result["interaction_hints"]
    login_hint = next(hint for hint in hints if hint["kind"] == "requires_login")
    assert login_hint["blocking"] is True
    assert "登录" in login_hint["summary"]
    assert login_hint["details"]["required_fields"] == [
        "Phone number / email address",
        "Password",
    ]


@pytest.mark.asyncio
async def test_external_act_acknowledges_blocking_human_gate(
    tmp_path: Path,
) -> None:
    config = _config(tmp_path)
    evidence_dir = config.data_dir / "evidence" / "external"
    evidence_dir.mkdir(parents=True)
    blocking_hint = {
        "kind": "requires_plan_confirmation",
        "blocking": True,
        "summary": "页面存在多档套餐/计费周期，继续点击前应先和用户确认买哪一种。",
        "details": {"current_url": "https://www.kimi.com/membership/pricing"},
    }
    tx = Transaction(
        amount=19,
        payee="kimi",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        human_action=HumanAction(
            action_type="requires_plan_confirmation",
            requested_at=datetime.now(UTC),
        ),
    )
    evidence_path = evidence_dir / f"{tx.tx_id}-step-0.json"
    evidence_path.write_text(
        json.dumps(
            {
                "tx_id": tx.tx_id,
                "step_index": 0,
                "current_url": "https://www.kimi.com/membership/pricing",
                "action": {"type": "observe"},
                "action_result": {"interaction_hints": [blocking_hint]},
            }
        ),
        encoding="utf-8",
    )
    tx = tx.model_copy(
        update={
            "steps": [
                StepRecord(
                    step_index=0,
                    description="观察套餐页",
                    status="success",
                    evidence_path=str(evidence_path),
                )
            ]
        }
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    mock_browser = MagicMock()
    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                action=ExternalAction(
                    type="ack_human_gate",
                    description="用户确认最低月付套餐",
                ),
            )
        finally:
            runner.close()

    assert result.transaction.status == TransactionStatus.executing
    assert result.action_result["kind"] == "human_gate_acknowledged"
    assert result.transaction.human_action is not None
    assert result.transaction.human_action.completed_at is not None
    assert result.transaction.steps[-1].evidence_path is not None
    assert isinstance(result.transaction.steps[-1].evidence_path, str)
    mock_display.notify_human.assert_not_awaited()
    mock_browser.launch.assert_not_called()


@pytest.mark.asyncio
async def test_external_act_observe_includes_identity_verification_hint(
    tmp_path: Path,
) -> None:
    config = _config(tmp_path)
    tx = Transaction(
        amount=10,
        payee="deepseek",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.get_current_url = AsyncMock(
        return_value="https://platform.deepseek.com/top_up"
    )
    mock_browser.reused_existing_page = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(
        return_value={
            "title": "DeepSeek Platform",
            "viewport": {},
            "clickables": [{"index": 0, "text": "Verify", "selector": "button"}],
            "inputs": [
                {"placeholder": "Real name", "type": "text"},
                {"placeholder": "ID Number", "type": "text"},
            ],
            "visible_text": [
                "Please complete real-name verification to enjoy more services",
                "Type of ID",
            ],
        }
    )
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                action=ExternalAction(type="observe", description="观察实名页"),
            )
        finally:
            runner.close()

    hints = result.action_result["interaction_hints"]
    identity_hint = next(
        hint for hint in hints if hint["kind"] == "requires_identity_verification"
    )
    assert identity_hint["blocking"] is True
    assert identity_hint["details"]["entrypoint"] == "Verify"
    assert identity_hint["details"]["required_fields"] == [
        "Real name",
        "ID Number",
    ]


@pytest.mark.asyncio
async def test_external_act_observe_includes_plan_confirmation_hint(
    tmp_path: Path,
) -> None:
    config = _config(tmp_path)
    tx = Transaction(
        amount=49,
        payee="kimi",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.get_current_url = AsyncMock(
        return_value="https://www.kimi.com/membership/pricing"
    )
    mock_browser.reused_existing_page = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(
        return_value={
            "title": "Kimi Pricing",
            "viewport": {},
            "clickables": [
                {"index": 0, "text": "Monthly", "selector": "button"},
                {"index": 1, "text": "Annually", "selector": "button"},
                {"index": 2, "text": "Business", "selector": "button"},
                {"index": 3, "text": "Subscribe", "selector": "button"},
            ],
            "inputs": [],
            "visible_text": ["Monthly", "Annually", "Business", "Subscribe"],
        }
    )
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                action=ExternalAction(type="observe", description="观察套餐页"),
            )
        finally:
            runner.close()

    hints = result.action_result["interaction_hints"]
    plan_hint = next(
        hint for hint in hints if hint["kind"] == "requires_plan_confirmation"
    )
    assert plan_hint["blocking"] is True
    assert plan_hint["details"]["options"] == [
        "Monthly",
        "Annually",
        "Business",
        "Subscribe",
    ]


@pytest.mark.asyncio
async def test_external_act_resumes_last_evidence_url(tmp_path: Path) -> None:
    config = _config(tmp_path)
    evidence_dir = config.data_dir / "evidence" / "external"
    evidence_dir.mkdir(parents=True)
    tx = Transaction(
        amount=19,
        payee="kimi",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        steps=[],
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    evidence_path = evidence_dir / f"{tx.tx_id}-step-0-handoff.json"
    evidence_path.write_text(
        json.dumps(
            {
                "tx_id": tx.tx_id,
                "step_index": 0,
                "kind": "external_computer_use_handoff",
                "current_url": "https://www.kimi.com/membership/pricing",
            }
        ),
        encoding="utf-8",
    )
    tx = tx.model_copy(
        update={
            "steps": [
                StepRecord(
                    step_index=0,
                    description="external handoff",
                    status="pending",
                    evidence_path=str(evidence_path),
                )
            ]
        }
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.navigate = AsyncMock()
    mock_browser.get_current_url = AsyncMock(
        return_value="https://www.kimi.com/membership/pricing"
    )
    mock_browser.reused_existing_page = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(
        return_value={
            "title": "Kimi",
            "viewport": {},
            "clickables": [],
            "inputs": [],
            "visible_text": [],
        }
    )
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                action=ExternalAction(type="observe", description="观察会员页"),
            )
        finally:
            runner.close()

    assert result.resumed_url == "https://www.kimi.com/membership/pricing"
    assert result.current_url == "https://www.kimi.com/membership/pricing"
    mock_browser.navigate.assert_awaited_once_with(
        "https://www.kimi.com/membership/pricing"
    )


@pytest.mark.asyncio
async def test_external_act_resumes_encrypted_last_evidence_url(tmp_path: Path) -> None:
    config = _config(tmp_path)
    evidence_dir = config.data_dir / "evidence" / "external"
    evidence_dir.mkdir(parents=True)
    tx = Transaction(
        amount=19,
        payee="kimi",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        steps=[],
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    evidence_path = evidence_dir / f"{tx.tx_id}-step-0-handoff.json"
    ArtifactStore(config.data_dir).write_json(
        evidence_path,
        {
            "tx_id": tx.tx_id,
            "step_index": 0,
            "kind": "external_computer_use_handoff",
            "current_url": "https://www.kimi.com/membership/pricing",
        },
        artifact_kind="external_computer_use_handoff",
        sensitivity=ArtifactSensitivity.sensitive,
        metadata={"tx_id": tx.tx_id, "step_index": 0},
    )
    tx = tx.model_copy(
        update={
            "steps": [
                StepRecord(
                    step_index=0,
                    description="external handoff",
                    status="pending",
                    evidence_path=str(evidence_path),
                )
            ]
        }
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.navigate = AsyncMock()
    mock_browser.get_current_url = AsyncMock(
        return_value="https://www.kimi.com/membership/pricing"
    )
    mock_browser.reused_existing_page = False
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(
        return_value={
            "title": "Kimi",
            "viewport": {},
            "clickables": [],
            "inputs": [],
            "visible_text": [],
        }
    )
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                action=ExternalAction(type="observe", description="观察会员页"),
            )
        finally:
            runner.close()

    assert result.resumed_url == "https://www.kimi.com/membership/pricing"
    assert result.current_url == "https://www.kimi.com/membership/pricing"
    mock_browser.navigate.assert_awaited_once_with(
        "https://www.kimi.com/membership/pricing"
    )


@pytest.mark.asyncio
async def test_external_act_reuses_tagged_page_without_re_navigate(tmp_path: Path) -> None:
    config = _config(tmp_path)
    evidence_dir = config.data_dir / "evidence" / "external"
    evidence_dir.mkdir(parents=True)
    tx = Transaction(
        amount=19,
        payee="kimi",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        steps=[],
        human_action=HumanAction(
            action_type="external_computer_use",
            requested_at=datetime.now(UTC),
        ),
    )
    evidence_path = evidence_dir / f"{tx.tx_id}-step-0-handoff.json"
    evidence_path.write_text(
        json.dumps(
            {
                "tx_id": tx.tx_id,
                "step_index": 0,
                "kind": "external_computer_use_handoff",
                "current_url": "https://www.kimi.com/membership/pricing",
            }
        ),
        encoding="utf-8",
    )
    tx = tx.model_copy(
        update={
            "steps": [
                StepRecord(
                    step_index=0,
                    description="external handoff",
                    status="pending",
                    evidence_path=str(evidence_path),
                )
            ]
        }
    )
    ledger = Ledger(config.data_dir / "payswitch.db")
    ledger.record(tx)
    ledger.close()

    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.navigate = AsyncMock()
    mock_browser.get_current_url = AsyncMock(
        side_effect=[
            "https://www.kimi.com/membership/pricing",
            "https://www.kimi.com/membership/pricing",
            "https://www.kimi.com/membership/pricing",
        ]
    )
    mock_browser.reused_existing_page = True
    mock_browser.screenshot = AsyncMock(return_value=b"fake-png")
    mock_browser.inspect_page_state = AsyncMock(
        return_value={
            "title": "Kimi",
            "viewport": {},
            "clickables": [],
            "inputs": [],
            "visible_text": [],
        }
    )
    mock_browser.page = MagicMock()

    mock_pipeline = MagicMock()
    mock_pipeline.scan = AsyncMock(return_value=None)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(config)
        try:
            result = await runner.act(
                tx_id=tx.tx_id,
                action=ExternalAction(type="observe", description="观察会员页"),
            )
        finally:
            runner.close()

    assert result.resumed_url == "https://www.kimi.com/membership/pricing"
    assert result.current_url == "https://www.kimi.com/membership/pricing"
    mock_browser.navigate.assert_not_called()
