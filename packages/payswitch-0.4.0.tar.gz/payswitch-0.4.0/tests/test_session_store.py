import asyncio

from payswitch.agent_language import PaymentIntent
from payswitch.session_store import TaskStore


def _run(coro):
    return asyncio.run(coro)


def _intent(user_id: str, payee: str) -> PaymentIntent:
    return PaymentIntent(
        amount=49,
        currency="CNY",
        payee=payee,
        reason=f"{payee} session store test",
        source_agent="codex",
        metadata={"user_id": user_id},
    )


def test_task_store_persists_sessions_and_events_across_reopen(tmp_path):
    db_path = tmp_path / "session_store.db"
    store = TaskStore(db_path)
    task = _run(store.create(_intent("alice", "kimi")))
    _run(store.update(task.id, status="working", result={"tx_id": "txn_store_1"}))
    _run(
        store.emit(
            task.id,
            {"type": "human.gate", "summary": "扫码", "message": "等待扫码支付"},
        )
    )
    store.close()

    reopened = TaskStore(db_path)
    try:
        restored = _run(reopened.get(task.id))
        assert restored is not None
        assert restored.user_id == "alice"
        assert restored.workspace_id.startswith("uws_")
        assert restored.subagent_session_id.startswith("sag_")
        assert restored.result == {"tx_id": "txn_store_1"}
        assert [event["sequence"] for event in restored.events] == [1, 2]
        assert restored.events[-1]["type"] == "human.gate"

        latest = _run(reopened.latest(user_id="alice"))
        assert latest is not None
        assert latest.id == task.id

        by_tx = _run(reopened.find_by_tx_id("txn_store_1", user_id="alice"))
        assert by_tx is not None
        assert by_tx.id == task.id
    finally:
        reopened.close()


def test_task_store_scopes_latest_and_clear_by_user(tmp_path):
    store = TaskStore(tmp_path / "session_scope.db")
    try:
        alice = _run(store.create(_intent("alice", "kimi")))
        bob = _run(store.create(_intent("bob", "jimeng")))
        _run(store.update(alice.id, status="working"))
        _run(store.update(bob.id, status="input-required"))

        alice_latest = _run(store.latest(user_id="alice"))
        bob_latest = _run(store.latest(user_id="bob"))
        assert alice_latest is not None and alice_latest.id == alice.id
        assert bob_latest is not None and bob_latest.id == bob.id

        deleted_ids = _run(store.clear(user_id="alice"))
        assert deleted_ids == [alice.id]
        remaining = _run(store.list())
        assert [task.id for task in remaining] == [bob.id]
    finally:
        store.close()


def test_task_store_derives_workspaces_and_subagents_from_sessions(tmp_path):
    store = TaskStore(tmp_path / "session_views.db")
    try:
        alice = _run(store.create(_intent("alice", "kimi")))
        bob = _run(store.create(_intent("bob", "jimeng")))
        _run(store.update(alice.id, status="working"))
        _run(store.update(bob.id, status="completed"))

        workspaces = _run(store.list_workspaces())
        subagents = _run(store.list_subagents())
        alice_workspace = next(item for item in workspaces if item["user_id"] == "alice")
        bob_workspace = next(item for item in workspaces if item["user_id"] == "bob")
        alice_subagent = next(item for item in subagents if item["task_id"] == alice.id)

        assert {workspace["user_id"] for workspace in workspaces} == {"alice", "bob"}
        assert alice_workspace["active_sessions"] == 1
        assert bob_workspace["active_sessions"] == 0
        assert {session["task_id"] for session in subagents} == {alice.id, bob.id}
        assert alice_subagent["session_id"].startswith("sag_")
    finally:
        store.close()
