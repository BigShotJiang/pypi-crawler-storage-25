from __future__ import annotations

from pathlib import Path

from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore


def test_artifact_inventory_reports_counts_bytes_and_budget(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path)
    screenshot_path = tmp_path / "evidence" / "external" / "shot.png"
    json_path = tmp_path / "evidence" / "recovery" / "tx-1.json"
    store.write_bytes(
        screenshot_path,
        b"\x89PNG\r\nfake",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
    )
    store.write_json(
        json_path,
        {"tx_id": "txn_inventory_1"},
        artifact_kind="recovery_checkpoint",
        sensitivity=ArtifactSensitivity.internal,
        retention_hours=0,
    )

    snapshot = store.inventory(budget_bytes=32)

    assert snapshot["artifacts"] == 2
    assert snapshot["expired_artifacts"] == 1
    assert snapshot["encrypted_artifacts"] == 1
    assert snapshot["orphaned_metadata"] == 0
    assert snapshot["total_bytes"] >= snapshot["primary_bytes"] >= 1
    assert snapshot["expired_bytes"] >= 1
    assert snapshot["over_budget"] is True
    assert snapshot["usage_ratio"] is not None
    assert snapshot["by_sensitivity"]["sensitive"]["artifacts"] == 1
    assert snapshot["by_sensitivity"]["internal"]["expired_artifacts"] == 1
    assert snapshot["by_kind"]["external_observation_screenshot"]["artifacts"] == 1
    assert snapshot["by_kind"]["recovery_checkpoint"]["expired_artifacts"] == 1
