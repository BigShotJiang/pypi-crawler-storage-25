import asyncio
import base64
import io
import zipfile
from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from payswitch.agent_language import PaymentIntent
from payswitch.engine.ledger import Ledger
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import HumanAction, Transaction
from payswitch.models.types import PaymentMethod, TransactionStatus
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore
from payswitch.security.secret_envelope import decrypt_secret_text, generate_secret_inbox
from payswitch.server import _as_a2a_task, _sse_generator, app, store, workspace_manager


def _run(coro):
    return asyncio.run(coro)


async def _first_sse(task_id: str) -> str:
    generator = _sse_generator(task_id)
    try:
        return await anext(generator)
    finally:
        await generator.aclose()


async def _reset_store() -> None:
    await store.clear()
    await workspace_manager.reset()


def test_health_and_agent_card_use_public_url_overrides(monkeypatch):
    public_url = "https://178-128-93-176.sslip.io"
    novnc_url = f"{public_url}/vnc.html?autoconnect=true&resize=scale"
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", public_url)
    monkeypatch.setenv("PAYSWITCH_PUBLIC_NOVNC_URL", novnc_url)

    client = TestClient(app)
    health = client.get("/api/health").json()
    agent_card = client.get("/.well-known/agent-card.json").json()

    assert health["public_url"] == public_url
    assert health["computer_use"]["novnc_url"] == novnc_url
    assert agent_card["url"] == public_url
    assert agent_card["metadata"]["rest"] == f"{public_url}/api/payments"
    assert agent_card["metadata"]["sse"] == f"{public_url}/events"
    assert agent_card["metadata"]["payagent_install"] == f"{public_url}/api/payagent/install.py"
    assert agent_card["metadata"]["payagent_bootstrap"] == f"{public_url}/api/payagent/bootstrap"
    assert agent_card["metadata"]["payagent_config"] == f"{public_url}/api/payagent/config"
    assert agent_card["metadata"]["secret_encrypt"] == f"{public_url}/api/secrets/encrypt"
    assert agent_card["metadata"]["secret_envelope_schema"] == "pay-switch.secret-envelope.v1"


def test_payagent_install_assets_are_served_from_public_url(monkeypatch):
    public_url = "https://178-128-93-176.sslip.io"
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", public_url)

    client = TestClient(app)
    installer = client.get("/api/payagent/install.py")
    plugin_zip = client.get("/api/payagent/plugin.zip")

    assert installer.status_code == 200
    assert f'REPO_ZIP_URL = "{public_url}/api/payagent/plugin.zip"' in installer.text
    assert f'DEFAULT_CONFIG_URL = "{public_url}/api/payagent/config"' in installer.text
    assert f'DEFAULT_PANEL_URL = "{public_url}"' in installer.text
    assert f'DEFAULT_BOOTSTRAP_URL = "{public_url}/api/payagent/bootstrap"' in installer.text
    assert "raw.githubusercontent.com" not in installer.text
    assert plugin_zip.status_code == 200
    assert plugin_zip.headers["content-type"] == "application/zip"
    with zipfile.ZipFile(io.BytesIO(plugin_zip.content)) as zf:
        names = set(zf.namelist())
    assert "payswitch-main/plugins/pay-switch-agent/install.py" in names
    assert "payswitch-main/plugins/pay-switch-agent/scripts/payswitch_agent.py" in names
    assert (
        "payswitch-main/plugins/pay-switch-agent/docs/remote-live-proof-2026-05-14-jimeng.json"
        in names
    )


def test_payagent_config_returns_direct_public_endpoints(monkeypatch):
    public_url = "https://178-128-93-176.sslip.io"
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", public_url)

    client = TestClient(app)
    config = client.get("/api/payagent/config").json()

    assert config["public_url"] == public_url
    assert config["rest_endpoint"] == f"{public_url}/api/payments"
    assert config["a2a_endpoint"] == f"{public_url}/a2a"
    assert config["payagent_bootstrap_url"] == f"{public_url}/api/payagent/bootstrap"
    assert config["sessions_endpoint"] == f"{public_url}/api/sessions"
    assert config["workspaces_endpoint"] == f"{public_url}/api/workspaces"
    assert config["subagents_endpoint"] == f"{public_url}/api/subagents"
    assert config["workspace_runtime_health_endpoint"] == (
        f"{public_url}/api/workspace-runtimes/health"
    )
    assert config["secret_encrypt_endpoint"] == f"{public_url}/api/secrets/encrypt"
    assert config["session_confirm_endpoint"] == f"{public_url}/api/sessions/{{session_id}}:confirm"
    assert config["secret_envelope_schema"] == "pay-switch.secret-envelope.v1"


def test_payagent_bootstrap_token_authenticates_without_exposing_master(monkeypatch):
    public_url = "https://178-128-93-176.sslip.io"
    master_token = "server-master-token"
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", public_url)
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)

    client = TestClient(app)
    bootstrap = client.post("/api/payagent/bootstrap").json()

    assert bootstrap["token_required"] is True
    assert bootstrap["token"].startswith("psw_agent_")
    assert bootstrap["token"] != master_token
    assert bootstrap["token_scope"] == "payagent:human-gated"

    psl = 'PAY 50 CNY TO jimeng FOR "test" VIA alipay_qr DRY_RUN'
    unauth = client.post("/psl:parse", json={"text": psl})
    authed = client.post(
        "/psl:parse",
        headers={"Authorization": f"Bearer {bootstrap['token']}"},
        json={"text": psl},
    )

    assert unauth.status_code == 401
    assert authed.status_code == 200


def test_secret_encrypt_endpoint_returns_agent_decryptable_envelope(monkeypatch):
    public_url = "https://178-128-93-176.sslip.io"
    master_token = "server-master-token"
    inbox = generate_secret_inbox()
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", public_url)
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)

    client = TestClient(app)
    response = client.post(
        "/api/secrets/encrypt",
        headers={"Authorization": f"Bearer {master_token}"},
        json={
            "provider": "deepseek",
            "secret": "sk-test-deepseek",
            "recipientPublicKey": inbox["public_key"],
            "secretType": "api_key",
        },
    )

    assert response.status_code == 200
    envelope = response.json()["envelope"]
    assert "sk-test-deepseek" not in response.text
    assert decrypt_secret_text(envelope, recipient_private_key=inbox["private_key"]) == (
        "sk-test-deepseek"
    )


def test_session_confirm_encrypts_api_key_and_closes_same_task(monkeypatch, tmp_path):
    _run(_reset_store())
    public_url = "https://178-128-93-176.sslip.io"
    master_token = "server-master-token"
    inbox = generate_secret_inbox()
    config = PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded")
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", public_url)
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))

    ledger = Ledger(tmp_path / "payswitch.db")
    try:
        tx = Transaction(
            amount=10,
            currency="CNY",
            payee="deepseek",
            reason="DeepSeek API key purchase",
            payment_method=PaymentMethod.alipay_qr,
            status=TransactionStatus.human_action_required,
            human_action=HumanAction(
                action_type="takeover",
                requested_at=datetime.now(UTC),
                guidance="Complete payment.",
            ),
        )
        ledger.record(tx)
    finally:
        ledger.close()

    intent = PaymentIntent(
        amount=10,
        currency="CNY",
        payee="deepseek",
        reason="DeepSeek API key purchase",
        method=PaymentMethod.alipay_qr,
        source_agent="codex",
        metadata={
            "secret_delivery": {
                "requested": True,
                "recipient_public_key": inbox["public_key"],
            }
        },
    )
    task = _run(store.create(intent))
    _run(store.update(task.id, status="input-required", result=tx.model_dump(mode="json")))

    client = TestClient(app)
    response = client.post(
        f"/api/sessions/{task.id}:confirm",
        headers={"Authorization": f"Bearer {master_token}"},
        json={
            "apiKey": "sk-confirmed-deepseek",
            "evidenceArtifacts": [{"kind": "receipt", "provider": "deepseek", "name": "receipt"}],
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["session"]["status"] == "completed"
    assert "sk-confirmed-deepseek" not in response.text
    secret_artifact = next(
        artifact
        for artifact in body["a2a_task"]["artifacts"]
        if artifact["artifactId"] == "encrypted_secret_1"
    )
    envelope = secret_artifact["parts"][0]["data"]
    assert decrypt_secret_text(envelope, recipient_private_key=inbox["private_key"]) == (
        "sk-confirmed-deepseek"
    )
    assert any(
        artifact["artifactId"] == "evidence_1" for artifact in body["a2a_task"]["artifacts"]
    )


def test_session_confirm_persists_binary_and_text_artifacts(monkeypatch, tmp_path):
    _run(_reset_store())
    master_token = "server-master-token"
    config = PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded")
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))

    ledger = Ledger(tmp_path / "payswitch.db")
    try:
        tx = Transaction(
            amount=19,
            currency="CNY",
            payee="kimi",
            reason="Kimi membership receipt test",
            payment_method=PaymentMethod.alipay_qr,
            status=TransactionStatus.human_action_required,
            human_action=HumanAction(
                action_type="scan_qr",
                requested_at=datetime.now(UTC),
                guidance="Complete payment.",
            ),
        )
        ledger.record(tx)
    finally:
        ledger.close()

    intent = PaymentIntent(
        amount=19,
        currency="CNY",
        payee="kimi",
        reason="Kimi membership receipt test",
        method=PaymentMethod.alipay_qr,
        source_agent="codex",
    )
    task = _run(store.create(intent))
    _run(store.update(task.id, status="input-required", result=tx.model_dump(mode="json")))

    receipt_bytes = b"\x89PNG\r\nreceipt-payload"
    receipt_base64 = base64.b64encode(receipt_bytes).decode("ascii")
    client = TestClient(app)
    response = client.post(
        f"/api/sessions/{task.id}:confirm",
        headers={"Authorization": f"Bearer {master_token}"},
        json={
            "evidenceArtifacts": [
                {
                    "artifactId": "receipt_png",
                    "kind": "receipt",
                    "provider": "kimi",
                    "name": "receipt.png",
                    "contentType": "image/png",
                    "contentBase64": receipt_base64,
                    "sensitivity": "sensitive",
                }
            ],
            "generatedOutputs": [
                {
                    "artifactId": "summary_txt",
                    "kind": "summary",
                    "name": "summary.txt",
                    "text": "operator summary",
                }
            ],
        },
    )

    assert response.status_code == 200
    assert receipt_base64 not in response.text
    assert "operator summary" not in response.text

    latest = _run(store.get(task.id))
    assert latest is not None
    receipt_item = next(
        item
        for item in latest.result["evidence_artifacts"]
        if item["artifact_id"] == "receipt_png"
    )
    summary_item = next(
        item
        for item in latest.result["generated_outputs"]
        if item["artifact_id"] == "summary_txt"
    )

    artifact_store = ArtifactStore(tmp_path)
    receipt_path = Path(receipt_item["artifact_path"])
    summary_path = Path(summary_item["artifact_path"])
    assert artifact_store.read_bytes(receipt_path) == receipt_bytes
    assert artifact_store.read_content_type(receipt_path) == "image/png"
    assert artifact_store.read_bytes(summary_path) == b"operator summary"
    assert artifact_store.read_content_type(summary_path) == "text/plain; charset=utf-8"

    body = response.json()
    receipt_artifact = next(
        artifact
        for artifact in body["a2a_task"]["artifacts"]
        if artifact["artifactId"] == "receipt_png"
    )
    assert receipt_artifact["metadata"]["download_url"] == (
        f"/api/sessions/{task.id}/artifacts/receipt_png"
    )
    assert receipt_artifact["metadata"]["content_type"] == "image/png"
    assert receipt_artifact["metadata"]["persisted"] is True

    pay_switch_result = next(
        artifact
        for artifact in body["a2a_task"]["artifacts"]
        if artifact["artifactId"] == "pay_switch_result"
    )
    result_payload = pay_switch_result["parts"][0]["data"]
    assert "artifact_path" not in result_payload["evidence_artifacts"][0]
    assert "artifact_path" not in result_payload["generated_outputs"][0]

    receipt_download = client.get(
        f"/api/sessions/{task.id}/artifacts/receipt_png",
        headers={"Authorization": f"Bearer {master_token}"},
    )
    assert receipt_download.status_code == 200
    assert receipt_download.content == receipt_bytes
    assert receipt_download.headers["content-type"].startswith("image/png")

    summary_download = client.get(
        f"/api/sessions/{task.id}/artifacts/summary_txt",
        headers={"Authorization": f"Bearer {master_token}"},
    )
    assert summary_download.status_code == 200
    assert summary_download.content == b"operator summary"
    assert summary_download.headers["content-type"].startswith("text/plain")


def test_scoped_session_confirm_and_artifact_download_require_user_scope(monkeypatch, tmp_path):
    _run(_reset_store())
    master_token = "server-master-token"
    config = PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded")
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))

    ledger = Ledger(tmp_path / "payswitch.db")
    try:
        tx = Transaction(
            amount=7,
            currency="CNY",
            payee="kimi",
            reason="Scoped confirm test",
            method=PaymentMethod.alipay_qr,
            status=TransactionStatus.human_action_required,
            human_action=HumanAction(
                action_type="takeover",
                requested_at=datetime.now(UTC),
                guidance="Complete payment.",
            ),
        )
        ledger.record(tx)
    finally:
        ledger.close()

    intent = PaymentIntent(
        amount=7,
        currency="CNY",
        payee="kimi",
        reason="Scoped confirm test",
        method=PaymentMethod.alipay_qr,
        source_agent="codex",
        metadata={"user_id": "alice"},
    )
    task = _run(store.create(intent))
    _run(store.update(task.id, status="input-required", result={"tx_id": tx.tx_id}))

    client = TestClient(app)
    headers = {"Authorization": f"Bearer {master_token}"}

    missing_scope = client.post(
        f"/api/sessions/{task.id}:confirm",
        headers=headers,
        json={"success": True},
    )
    assert missing_scope.status_code == 409
    assert "requires user_id" in missing_scope.json()["detail"]

    scoped = client.post(
        f"/api/sessions/{task.id}:confirm?user_id=alice",
        headers=headers,
        json={
            "success": True,
            "generatedOutputs": [{"name": "receipt", "text": "ok", "content_type": "text/plain"}],
        },
    )
    assert scoped.status_code == 200
    artifact = next(
        item
        for item in scoped.json()["a2a_task"]["artifacts"]
        if item["artifactId"] == "generated_1"
    )
    assert artifact["metadata"]["download_url"] == (
        f"/api/sessions/{task.id}/artifacts/generated_1?user_id=alice"
    )

    missing_download_scope = client.get(
        f"/api/sessions/{task.id}/artifacts/generated_1",
        headers=headers,
    )
    scoped_download = client.get(
        f"/api/sessions/{task.id}/artifacts/generated_1?user_id=alice",
        headers=headers,
    )

    assert missing_download_scope.status_code == 409
    assert "requires user_id" in missing_download_scope.json()["detail"]
    assert scoped_download.status_code == 200
    assert scoped_download.content == b"ok"


def test_persisted_result_artifacts_gain_download_metadata(monkeypatch, tmp_path):
    _run(_reset_store())
    master_token = "server-master-token"
    config = PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded")
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))

    artifact_store = ArtifactStore(tmp_path)
    media_path = tmp_path / "evidence" / "media" / "capture.webm"
    artifact_store.write_bytes(
        media_path,
        b"webm-payload",
        artifact_kind="checkout_capture",
        sensitivity=ArtifactSensitivity.internal,
        content_type="video/webm",
    )

    intent = PaymentIntent(
        amount=8,
        currency="CNY",
        payee="jimeng",
        reason="Jimeng capture artifact test",
        method=PaymentMethod.alipay_qr,
        source_agent="codex",
    )
    task = _run(store.create(intent))
    task = _run(
        store.update(
            task.id,
            status="completed",
            result={
                "tx_id": "txn_capture_1",
                "media_artifacts": [
                    {
                        "artifactId": "capture_webm",
                        "kind": "capture",
                        "name": "capture.webm",
                        "recording_source": "native_browser_video",
                        "artifact_path": str(media_path),
                    }
                ],
            },
        )
    )

    a2a_task = _as_a2a_task(task)
    media_artifact = next(
        artifact for artifact in a2a_task["artifacts"] if artifact["artifactId"] == "capture_webm"
    )
    assert media_artifact["metadata"]["download_url"] == (
        f"/api/sessions/{task.id}/artifacts/capture_webm"
    )
    assert media_artifact["metadata"]["content_type"] == "video/webm"
    assert media_artifact["metadata"]["persisted"] is True
    public_item = media_artifact["parts"][0]["data"]
    assert public_item["download_url"] == f"/api/sessions/{task.id}/artifacts/capture_webm"
    assert public_item["content_type"] == "video/webm"
    assert public_item["recording_source"] == "native_browser_video"
    assert public_item["recordingSource"] == "native_browser_video"
    assert "artifact_path" not in public_item

    pay_switch_result = next(
        artifact
        for artifact in a2a_task["artifacts"]
        if artifact["artifactId"] == "pay_switch_result"
    )
    result_media = pay_switch_result["parts"][0]["data"]["media_artifacts"][0]
    assert result_media["download_url"] == f"/api/sessions/{task.id}/artifacts/capture_webm"
    assert result_media["content_type"] == "video/webm"
    assert result_media["recording_source"] == "native_browser_video"
    assert result_media["recordingSource"] == "native_browser_video"
    assert "artifact_path" not in result_media

    client = TestClient(app)
    download = client.get(
        f"/api/sessions/{task.id}/artifacts/capture_webm",
        headers={"Authorization": f"Bearer {master_token}"},
    )
    assert download.status_code == 200
    assert download.content == b"webm-payload"
    assert download.headers["content-type"].startswith("video/webm")


def test_session_confirm_persists_media_artifacts(monkeypatch, tmp_path):
    _run(_reset_store())
    master_token = "server-master-token"
    config = PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded")
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))

    ledger = Ledger(tmp_path / "payswitch.db")
    try:
        tx = Transaction(
            amount=12,
            currency="CNY",
            payee="jimeng",
            reason="Jimeng media artifact confirm test",
            payment_method=PaymentMethod.alipay_qr,
            status=TransactionStatus.human_action_required,
            human_action=HumanAction(
                action_type="takeover",
                requested_at=datetime.now(UTC),
                guidance="Complete payment.",
            ),
        )
        ledger.record(tx)
    finally:
        ledger.close()

    intent = PaymentIntent(
        amount=12,
        currency="CNY",
        payee="jimeng",
        reason="Jimeng media artifact confirm test",
        method=PaymentMethod.alipay_qr,
        source_agent="codex",
    )
    task = _run(store.create(intent))
    _run(store.update(task.id, status="input-required", result=tx.model_dump(mode="json")))

    media_bytes = b"webm-session-confirm"
    media_base64 = base64.b64encode(media_bytes).decode("ascii")
    client = TestClient(app)
    response = client.post(
        f"/api/sessions/{task.id}:confirm",
        headers={"Authorization": f"Bearer {master_token}"},
        json={
            "mediaArtifacts": [
                {
                    "artifactId": "checkout_capture",
                    "kind": "capture",
                    "name": "capture.webm",
                    "contentType": "video/webm",
                    "contentBase64": media_base64,
                }
            ]
        },
    )

    assert response.status_code == 200
    assert media_base64 not in response.text

    latest = _run(store.get(task.id))
    assert latest is not None
    media_item = latest.result["media_artifacts"][0]
    media_path = Path(media_item["artifact_path"])
    artifact_store = ArtifactStore(tmp_path)
    assert artifact_store.read_bytes(media_path) == media_bytes
    assert artifact_store.read_content_type(media_path) == "video/webm"

    body = response.json()
    media_artifact = next(
        artifact
        for artifact in body["a2a_task"]["artifacts"]
        if artifact["artifactId"] == "checkout_capture"
    )
    assert media_artifact["metadata"]["download_url"] == (
        f"/api/sessions/{task.id}/artifacts/checkout_capture"
    )
    assert media_artifact["metadata"]["content_type"] == "video/webm"

    download = client.get(
        f"/api/sessions/{task.id}/artifacts/checkout_capture",
        headers={"Authorization": f"Bearer {master_token}"},
    )
    assert download.status_code == 200
    assert download.content == media_bytes
    assert download.headers["content-type"].startswith("video/webm")


def test_latest_session_projects_live_task_with_public_novnc(monkeypatch):
    _run(_reset_store())
    public_url = "https://178-128-93-176.sslip.io"
    monkeypatch.setenv("PAYSWITCH_PUBLIC_HOST", "178-128-93-176.sslip.io")
    monkeypatch.setenv("PAYSWITCH_PUBLIC_SCHEME", "https")
    monkeypatch.setenv("PAYSWITCH_PUBLIC_NOVNC_URL", f"{public_url}/vnc.html")

    intent = PaymentIntent(
        amount=49,
        currency="CNY",
        payee="kimi",
        reason="Kimi monthly membership",
        method="alipay_qr",
        idempotency_key="test-kimi",
        source_agent="codex",
    )
    task = _run(store.create(intent))
    _run(
        store.update(
            task.id,
            status="input-required",
            result={
                "tx_id": "txn_kimi_123",
                "amount": 49,
                "currency": "CNY",
                "payee": "kimi",
                "status": "human_action_required",
                "budget_state": {
                    "screenshots": {
                        "limit": 1,
                        "used": 1,
                        "remaining": 0,
                        "exhausted": True,
                        "exhaustion_reason": "screenshot budget exhausted after observe",
                    }
                },
                "human_action": {
                    "action_type": "scan_qr",
                    "requested_at": "2026-05-14T13:30:28Z",
                    "novnc_url": (
                        "http://0.0.0.0:6080/vnc.html"
                        "?autoconnect=true&resize=scale#token"
                    ),
                    "guidance": "检测到支付二维码，请使用手机扫码完成支付",
                    "details": {"qr_type": "canvas"},
                },
            },
        )
    )

    client = TestClient(app)
    session = client.get("/api/sessions/latest").json()["session"]

    assert session["id"] == task.id
    assert session["merchant"] == "kimi"
    assert session["amount"] == 49
    assert session["status"] == "waiting_human"
    assert session["budget_state"]["screenshots"]["exhausted"] is True
    human_event = session["events"][-1]
    assert human_event["type"] == "human.gate"
    assert human_event["summary"] == "已交付扫码付款"
    assert "novnc_url" in human_event
    assert human_event["novnc_url"].startswith(f"{public_url}/vnc.html?")
    assert human_event["novnc_url"].endswith("#token")
    assert "display_url" not in human_event


def test_sessions_list_returns_all_live_tasks_newest_first():
    _run(_reset_store())
    first_intent = PaymentIntent(amount=49, currency="CNY", payee="kimi", source_agent="codex")
    second_intent = PaymentIntent(amount=68, currency="CNY", payee="jimeng", source_agent="codex")
    first = _run(store.create(first_intent))
    second = _run(store.create(second_intent))
    _run(store.update(first.id, status="working"))
    _run(store.update(second.id, status="input-required"))

    client = TestClient(app)
    sessions = client.get("/api/sessions").json()["sessions"]

    assert [session["id"] for session in sessions] == [second.id, first.id]
    assert sessions[0]["merchant"] == "jimeng"
    assert sessions[0]["status"] == "waiting_human"
    assert sessions[1]["merchant"] == "kimi"
    assert sessions[1]["status"] == "running"


def test_sessions_list_requires_user_scope_when_multiple_users_exist():
    _run(_reset_store())
    _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    _run(
        store.create(
            PaymentIntent(
                amount=68,
                currency="CNY",
                payee="jimeng",
                source_agent="codex",
                metadata={"user_id": "bob"},
            )
        )
    )

    client = TestClient(app)
    ambiguous = client.get("/api/sessions")
    assert ambiguous.status_code == 409
    assert "provide user_id explicitly" in ambiguous.json()["detail"]

    alice_sessions = client.get("/api/sessions?user_id=alice").json()["sessions"]
    bob_sessions = client.get("/api/sessions?user_id=bob").json()["sessions"]

    assert len(alice_sessions) == 1
    assert len(bob_sessions) == 1


def test_sessions_list_filters_by_user_and_includes_subagent_metadata():
    _run(_reset_store())
    first_intent = PaymentIntent(
        amount=49,
        currency="CNY",
        payee="kimi",
        source_agent="codex",
        metadata={"user_id": "alice"},
    )
    second_intent = PaymentIntent(
        amount=68,
        currency="CNY",
        payee="jimeng",
        source_agent="codex",
        metadata={"user_id": "bob"},
    )
    first = _run(store.create(first_intent))
    second = _run(store.create(second_intent))

    client = TestClient(app)
    alice_sessions = client.get("/api/sessions?user_id=alice").json()["sessions"]
    bob_sessions = client.get("/api/sessions?user_id=bob").json()["sessions"]

    assert [session["id"] for session in alice_sessions] == [first.id]
    assert [session["id"] for session in bob_sessions] == [second.id]
    assert alice_sessions[0]["user_id"] == "alice"
    assert alice_sessions[0]["site_id"] == "kimi"
    assert alice_sessions[0]["workspace_id"].startswith("uws_")
    assert alice_sessions[0]["subagent_session_id"].startswith("sag_")


def test_workspace_and_subagent_reads_require_user_scope_when_multiple_users_exist():
    _run(_reset_store())
    _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    _run(
        store.create(
            PaymentIntent(
                amount=68,
                currency="CNY",
                payee="jimeng",
                source_agent="codex",
                metadata={"user_id": "bob"},
            )
        )
    )

    client = TestClient(app)

    workspaces = client.get("/api/workspaces")
    subagents = client.get("/api/subagents")
    runtime_health = client.get("/api/workspace-runtimes/health")

    assert workspaces.status_code == 409
    assert "provide user_id explicitly" in workspaces.json()["detail"]
    assert subagents.status_code == 409
    assert "provide user_id explicitly" in subagents.json()["detail"]
    assert runtime_health.status_code == 409
    assert "provide user_id explicitly" in runtime_health.json()["detail"]

    alice_workspaces = client.get("/api/workspaces?user_id=alice").json()["workspaces"]
    bob_subagents = client.get("/api/subagents?user_id=bob").json()["subagents"]
    alice_health = client.get("/api/workspace-runtimes/health?user_id=alice").json()

    assert len(alice_workspaces) == 1
    assert alice_workspaces[0]["user_id"] == "alice"
    assert len(bob_subagents) == 1
    assert bob_subagents[0]["user_id"] == "bob"
    assert "host" in alice_health
    assert "runtimes" in alice_health


def test_session_and_workspace_views_expose_profile_lifecycle_state():
    _run(_reset_store())
    intent = PaymentIntent(
        amount=49,
        currency="CNY",
        payee="kimi",
        source_agent="codex",
        metadata={"user_id": "alice"},
    )
    task = _run(store.create(intent))
    lease = _run(workspace_manager.start_session(task.id, intent))
    try:
        client = TestClient(app)
        session = client.get(f"/api/sessions/{task.id}?user_id=alice").json()["session"]
        assert session["profile_state"] == "task_profile_prepared"
        assert session["profile_task_path"] is not None
        Path(session["profile_task_path"]).joinpath("cookies.json").write_text(
            '{"loggedIn": true}',
            encoding="utf-8",
        )
        _run(workspace_manager.promote_task_profile(task.id))
    finally:
        _run(lease.release(final_status="input-required"))

    client = TestClient(app)
    refreshed = client.get(f"/api/sessions/{task.id}?user_id=alice").json()["session"]
    workspaces = client.get("/api/workspaces?user_id=alice").json()["workspaces"]

    assert refreshed["profile_state"] == "stable_ready"
    assert refreshed["profile_last_promotion_task_id"] == task.id
    assert workspaces[0]["profiles_total"] == 1
    assert workspaces[0]["active_task_profiles"] == 0


def test_sessions_list_excludes_dashboard_placeholders():
    _run(_reset_store())
    dashboard_intent = PaymentIntent(
        amount=1,
        currency="CNY",
        payee="payswitch",
        reason="Dashboard live connection",
        dry_run=True,
        source_agent="dashboard",
    )
    real_intent = PaymentIntent(amount=49, currency="CNY", payee="kimi", source_agent="codex")
    dashboard = _run(store.create(dashboard_intent))
    real = _run(store.create(real_intent))

    client = TestClient(app)
    sessions = client.get("/api/sessions").json()["sessions"]
    latest = client.get("/api/sessions/latest").json()["session"]

    assert dashboard.id not in [session["id"] for session in sessions]
    assert [session["id"] for session in sessions] == [real.id]
    assert latest["id"] == real.id


def test_latest_session_requires_user_scope_for_explicitly_scoped_single_session():
    _run(_reset_store())
    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )

    client = TestClient(app)
    ambiguous = client.get("/api/sessions/latest")
    scoped = client.get("/api/sessions/latest?user_id=alice")

    assert ambiguous.status_code == 409
    assert "requires user_id" in ambiguous.json()["detail"]
    assert scoped.status_code == 200
    assert scoped.json()["session"]["id"] == task.id


def test_session_clear_requires_user_scope_for_explicitly_scoped_sessions():
    _run(_reset_store())
    alice = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    bob = _run(
        store.create(
            PaymentIntent(
                amount=68,
                currency="CNY",
                payee="jimeng",
                source_agent="codex",
                metadata={"user_id": "bob"},
            )
        )
    )

    client = TestClient(app)
    ambiguous = client.delete("/api/sessions")
    assert ambiguous.status_code == 409
    assert "requires user_id" in ambiguous.json()["detail"]

    alice_clear = client.delete("/api/sessions?user_id=alice")
    assert alice_clear.status_code == 200
    assert alice_clear.json()["cleared"] == 1

    remaining = client.get("/api/sessions?user_id=bob").json()["sessions"]
    assert [session["id"] for session in remaining] == [bob.id]
    hidden = client.get(f"/api/sessions/{alice.id}?user_id=alice")
    assert hidden.status_code == 404


def test_latest_session_and_lookup_can_be_scoped_by_user():
    _run(_reset_store())
    alice = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    bob = _run(
        store.create(
            PaymentIntent(
                amount=68,
                currency="CNY",
                payee="jimeng",
                source_agent="codex",
                metadata={"user_id": "bob"},
            )
        )
    )

    client = TestClient(app)
    ambiguous = client.get("/api/sessions/latest")
    assert ambiguous.status_code == 409
    assert "requires user_id" in ambiguous.json()["detail"]

    alice_latest = client.get("/api/sessions/latest?user_id=alice").json()["session"]
    bob_latest = client.get("/api/sessions/latest?user_id=bob").json()["session"]
    hidden = client.get(f"/api/sessions/{bob.id}?user_id=alice")

    assert alice_latest["id"] == alice.id
    assert bob_latest["id"] == bob.id
    assert hidden.status_code == 404


def test_session_detail_requires_user_scope_for_scoped_session():
    _run(_reset_store())
    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )

    client = TestClient(app)
    missing_scope = client.get(f"/api/sessions/{task.id}")
    scoped = client.get(f"/api/sessions/{task.id}?user_id=alice")

    assert missing_scope.status_code == 409
    assert "requires user_id" in missing_scope.json()["detail"]
    assert scoped.status_code == 200
    assert scoped.json()["session"]["id"] == task.id


def test_workspaces_and_subagents_are_readable_from_durable_store_after_runtime_reset():
    _run(_reset_store())
    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    _run(store.update(task.id, status="working"))
    _run(workspace_manager.reset())

    client = TestClient(app)
    workspaces = client.get("/api/workspaces?user_id=alice").json()["workspaces"]
    subagents = client.get("/api/subagents?user_id=alice").json()["subagents"]

    assert len(workspaces) == 1
    assert workspaces[0]["workspace_id"].startswith("uws_")
    assert workspaces[0]["active_sessions"] == 1
    assert workspaces[0]["runtime_status"] == "offline"
    assert workspaces[0]["display_state"] == "no_runtime"
    assert len(subagents) == 1
    assert subagents[0]["task_id"] == task.id
    assert subagents[0]["session_id"].startswith("sag_")
    assert subagents[0]["runtime_status"] == "offline"


def test_workspace_runtime_health_endpoint_reports_live_runtime_state():
    _run(_reset_store())
    lease = _run(
        workspace_manager.start_session(
            "task_health",
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            ),
        )
    )
    try:
        client = TestClient(app)
        payload = client.get("/api/workspace-runtimes/health?user_id=alice").json()

        assert payload["host"]["active_workspaces"] == 1
        assert payload["host"]["capacity_status"] == "ok"
        assert len(payload["runtimes"]) == 1
        assert payload["runtimes"][0]["runtime_status"] == "active"
        assert payload["runtimes"][0]["display_ready"] is False
        assert payload["runtimes"][0]["display_state"] == "pending_scoped_display_route"
    finally:
        _run(lease.release())


def test_session_display_selection_exposes_scoped_view_route(monkeypatch):
    _run(_reset_store())
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", "https://panel.example")
    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    lease = _run(
        workspace_manager.start_session(
            task.id,
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            ),
        )
    )
    try:
        client = TestClient(app)
        selected = client.post(f"/api/sessions/{task.id}:display/select?user_id=alice")

        assert selected.status_code == 200
        session = selected.json()["session"]
        assert session["display_ready"] is True
        assert session["display_state"] == "visible_surface_ready"
        assert session["display_route_id"].startswith("droute_")
        assert session["display_route_expires_at"] is not None
        assert session["novnc_route_key"].startswith("vroute_")
        assert session["browser_manager_state"] == "selected"
        assert session["active_browser_context_id"] == task.browser_context_id
        assert session["active_browser_tab_id"].startswith("btab_")
        assert session["display_url"].startswith(
            f"https://panel.example/api/sessions/{task.id}/display/view?"
        )
        assert "token=dsp_" in session["display_url"]
    finally:
        _run(lease.release())


def test_session_display_selection_requires_user_scope_for_scoped_sessions(monkeypatch):
    _run(_reset_store())
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", "https://panel.example")
    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    lease = _run(
        workspace_manager.start_session(
            task.id,
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            ),
        )
    )
    try:
        client = TestClient(app)
        missing_scope = client.post(f"/api/sessions/{task.id}:display/select")
        wrong_scope = client.post(f"/api/sessions/{task.id}:display/select?user_id=bob")

        assert missing_scope.status_code == 409
        assert "requires user_id" in missing_scope.json()["detail"]
        assert wrong_scope.status_code == 404
    finally:
        _run(lease.release())


def test_session_display_view_redirects_only_for_current_scoped_token(monkeypatch):
    _run(_reset_store())
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", "https://panel.example")
    monkeypatch.setenv("PAYSWITCH_PUBLIC_NOVNC_URL", "https://panel.example/vnc.html")
    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    lease = _run(
        workspace_manager.start_session(
            task.id,
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            ),
        )
    )
    _run(store.update(task.id, status="working"))
    try:
        client = TestClient(app)
        selected = client.post(f"/api/sessions/{task.id}:display/select?user_id=alice").json()
        token = selected["session"]["display_route_token"]

        ready = client.get(
            f"/api/sessions/{task.id}/display/view?user_id=alice&token={token}",
            follow_redirects=False,
        )
        stale = client.get(
            f"/api/sessions/{task.id}/display/view?user_id=alice&token=stale",
            follow_redirects=False,
        )

        assert ready.status_code == 307
        assert ready.headers["location"].startswith("https://panel.example/vnc.html?")
        assert "route=vroute_" in ready.headers["location"]
        assert f"workspace_id={task.workspace_id}" in ready.headers["location"]
        assert f"session_id={task.id}" in ready.headers["location"]
        assert "display_route_id=droute_" in ready.headers["location"]
        assert stale.status_code == 409
        assert "已失效" in stale.text
    finally:
        _run(lease.release())


def test_session_display_view_becomes_unavailable_after_another_session_takes_foreground(
    monkeypatch,
):
    _run(_reset_store())
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", "https://panel.example")
    monkeypatch.setenv("PAYSWITCH_PUBLIC_NOVNC_URL", "https://panel.example/vnc.html")
    task_a = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    task_b = _run(
        store.create(
            PaymentIntent(
                amount=29,
                currency="CNY",
                payee="jimeng",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    lease_a = _run(
        workspace_manager.start_session(
            task_a.id,
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            ),
        )
    )
    lease_b = _run(
        workspace_manager.start_session(
            task_b.id,
            PaymentIntent(
                amount=29,
                currency="CNY",
                payee="jimeng",
                source_agent="codex",
                metadata={"user_id": "alice"},
            ),
        )
    )
    _run(store.update(task_a.id, status="working"))
    _run(store.update(task_b.id, status="working"))
    try:
        client = TestClient(app)
        selected_a = client.post(f"/api/sessions/{task_a.id}:display/select?user_id=alice").json()
        token_a = selected_a["session"]["display_route_token"]

        selected_b = client.post(f"/api/sessions/{task_b.id}:display/select?user_id=alice").json()
        token_b = selected_b["session"]["display_route_token"]
        assert token_b != token_a

        stale = client.get(
            f"/api/sessions/{task_a.id}/display/view?user_id=alice&token={token_a}",
            follow_redirects=False,
        )
        fresh = client.get(
            f"/api/sessions/{task_b.id}/display/view?user_id=alice&token={token_b}",
            follow_redirects=False,
        )

        assert stale.status_code == 409
        assert (
            "已失效" in stale.text
            or "不可用" in stale.text
            or "等待当前 Session 接管链接" in stale.text
        )
        assert fresh.status_code == 307
        assert f"session_id={task_b.id}" in fresh.headers["location"]
    finally:
        _run(lease_a.release())
        _run(lease_b.release())


def test_session_display_view_requires_matching_user_scope(monkeypatch):
    _run(_reset_store())
    monkeypatch.setenv("PAYSWITCH_PUBLIC_BASE_URL", "https://panel.example")
    monkeypatch.setenv("PAYSWITCH_PUBLIC_NOVNC_URL", "https://panel.example/vnc.html")
    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            )
        )
    )
    lease = _run(
        workspace_manager.start_session(
            task.id,
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "alice"},
            ),
        )
    )
    _run(store.update(task.id, status="working"))
    try:
        client = TestClient(app)
        selected = client.post(f"/api/sessions/{task.id}:display/select?user_id=alice").json()
        token = selected["session"]["display_route_token"]

        missing_scope = client.get(
            f"/api/sessions/{task.id}/display/view?token={token}",
            follow_redirects=False,
        )
        wrong_scope = client.get(
            f"/api/sessions/{task.id}/display/view?user_id=bob&token={token}",
            follow_redirects=False,
        )

        assert missing_scope.status_code == 409
        assert "requires user_id" in missing_scope.json()["detail"]
        assert wrong_scope.status_code == 404
    finally:
        _run(lease.release())


def test_events_unknown_session_does_not_create_dashboard_placeholder():
    _run(_reset_store())

    client = TestClient(app)
    with client.stream("GET", "/events?session_id=missing") as response:
        body = "".join(response.iter_text())

    assert "没有可用 Session" in body
    assert _run(store.list()) == []


def test_events_stream_is_scoped_by_user(monkeypatch):
    _run(_reset_store())
    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
                metadata={"user_id": "bob"},
            )
        )
    )

    async def fake_sse_generator(task_id: str, *, after_sequence=None, replay=True):
        assert task_id == task.id
        yield "data: scoped-ok\n\n"

    monkeypatch.setattr("payswitch.server._sse_generator", fake_sse_generator)

    client = TestClient(app)
    missing_scope = client.get(f"/events?session_id={task.id}")
    wrong_scope = client.get(f"/events?session_id={task.id}&user_id=alice")
    with client.stream("GET", f"/events?session_id={task.id}&user_id=bob") as response:
        body = "".join(response.iter_text())

    assert missing_scope.status_code == 409
    assert "requires user_id" in missing_scope.json()["detail"]
    assert wrong_scope.status_code == 404
    assert "scoped-ok" in body


def test_session_snapshot_can_be_loaded_by_transaction_id(monkeypatch):
    _run(_reset_store())
    monkeypatch.setenv("PAYSWITCH_PUBLIC_NOVNC_URL", "https://viewer.example/vnc.html")
    intent = PaymentIntent(amount=49, currency="CNY", payee="kimi", source_agent="codex")
    task = _run(store.create(intent))
    _run(
        store.update(
            task.id,
            status="input-required",
            result={
                "tx_id": "txn_lookup_123",
                "human_action": {"action_type": "scan_qr", "novnc_url": "http://0.0.0.0:6080/vnc.html"},
            },
        )
    )

    client = TestClient(app)
    session = client.get("/api/sessions/txn_lookup_123").json()["session"]

    assert session["id"] == task.id
    assert session["status"] == "waiting_human"


def test_session_snapshot_projects_media_persisted_event_downloads(monkeypatch, tmp_path):
    _run(_reset_store())
    master_token = "server-master-token"
    config = PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded")
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))

    artifact_store = ArtifactStore(tmp_path)
    capture_path = tmp_path / "evidence" / "external-media" / "psw_kimi" / "capture.webm"
    artifact_store.write_bytes(
        capture_path,
        b"webm-payload",
        artifact_kind="external_browser_recording",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="video/webm",
    )

    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
            )
        )
    )
    _run(store.update(task.id, status="completed"))
    _run(
        store.emit(
            task.id,
            {
                "type": "media.persisted",
                "summary": "录屏已归档",
                "message": "外部浏览器录屏已保存。",
                "source": "pay_switch",
                "path": ["Codex", "Pay-Switch", "Evidence"],
                "media_artifacts": [
                    {
                        "artifact_id": "capture_webm",
                        "recording_index": 2,
                        "name": "capture.webm",
                        "kind": "external_browser_recording",
                        "capture_engine": "playwright_video",
                        "duration_seconds": 4.2,
                        "frame_rate": 30.0,
                        "source_screenshot_count": 3,
                        "bit_rate": 2_000_000,
                        "frame_width": 1280,
                        "frame_height": 720,
                        "codec_name": "vp8",
                        "size_bytes": len(b"webm-payload"),
                        "recording_source": "native_browser_video",
                        "artifact_path": str(capture_path),
                    }
                ],
            },
        )
    )

    client = TestClient(app)
    session = client.get(f"/api/sessions/{task.id}").json()["session"]

    media_event = next(
        event for event in session["events"] if event.get("type") == "media.persisted"
    )
    media_item = media_event["media_artifacts"][0]
    assert media_item["download_url"] == f"/api/sessions/{task.id}/artifacts/capture_webm"
    assert media_item["content_type"] == "video/webm"
    assert media_item["recording_index"] == 2
    assert media_item["recordingIndex"] == 2
    assert media_item["capture_engine"] == "playwright_video"
    assert media_item["captureEngine"] == "playwright_video"
    assert media_item["duration_seconds"] == pytest.approx(4.2)
    assert media_item["durationSeconds"] == pytest.approx(4.2)
    assert media_item["frame_rate"] == pytest.approx(30.0)
    assert media_item["frameRate"] == pytest.approx(30.0)
    assert media_item["source_screenshot_count"] == 3
    assert media_item["sourceScreenshotCount"] == 3
    assert media_item["bit_rate"] == 2_000_000
    assert media_item["bitRate"] == 2_000_000
    assert media_item["frame_width"] == 1280
    assert media_item["frameWidth"] == 1280
    assert media_item["frame_height"] == 720
    assert media_item["frameHeight"] == 720
    assert media_item["codec_name"] == "vp8"
    assert media_item["codecName"] == "vp8"
    assert media_item["size_bytes"] == len(b"webm-payload")
    assert media_item["sizeBytes"] == len(b"webm-payload")
    assert media_item["recording_source"] == "native_browser_video"
    assert media_item["recordingSource"] == "native_browser_video"
    assert "artifact_path" not in media_item


def test_events_stream_projects_media_persisted_event_downloads(monkeypatch, tmp_path):
    _run(_reset_store())
    master_token = "server-master-token"
    config = PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded")
    monkeypatch.setenv("PAYSWITCH_AGENT_TOKEN", master_token)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))

    artifact_store = ArtifactStore(tmp_path)
    capture_path = tmp_path / "evidence" / "external-media" / "psw_kimi" / "capture.webm"
    artifact_store.write_bytes(
        capture_path,
        b"webm-payload",
        artifact_kind="external_browser_recording",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="video/webm",
    )

    task = _run(
        store.create(
            PaymentIntent(
                amount=49,
                currency="CNY",
                payee="kimi",
                source_agent="codex",
            )
        )
    )
    _run(
        store.emit(
            task.id,
            {
                "type": "media.persisted",
                "summary": "录屏已归档",
                "message": "外部浏览器录屏已保存。",
                "source": "pay_switch",
                "path": ["Codex", "Pay-Switch", "Evidence"],
                "media_artifacts": [
                    {
                        "artifact_id": "capture_webm",
                        "recording_index": 2,
                        "name": "capture.webm",
                        "kind": "external_browser_recording",
                        "capture_engine": "playwright_video",
                        "duration_seconds": 4.2,
                        "frame_rate": 30.0,
                        "source_screenshot_count": 3,
                        "bit_rate": 2_000_000,
                        "frame_width": 1280,
                        "frame_height": 720,
                        "codec_name": "vp8",
                        "size_bytes": len(b"webm-payload"),
                        "artifact_path": str(capture_path),
                    }
                ],
            },
        )
    )

    body = _run(_first_sse(task.id))

    assert f"/api/sessions/{task.id}/artifacts/capture_webm" in body
    assert "\"recording_index\": 2" in body
    assert "\"recordingIndex\": 2" in body
    assert "\"capture_engine\": \"playwright_video\"" in body
    assert "\"captureEngine\": \"playwright_video\"" in body
    assert "\"duration_seconds\": 4.2" in body
    assert "\"durationSeconds\": 4.2" in body
    assert "\"frame_rate\": 30.0" in body
    assert "\"frameRate\": 30.0" in body
    assert "\"source_screenshot_count\": 3" in body
    assert "\"sourceScreenshotCount\": 3" in body
    assert "\"bit_rate\": 2000000" in body
    assert "\"bitRate\": 2000000" in body
    assert "\"frame_width\": 1280" in body
    assert "\"frameWidth\": 1280" in body
    assert "\"frame_height\": 720" in body
    assert "\"frameHeight\": 720" in body
    assert "\"codec_name\": \"vp8\"" in body
    assert "\"codecName\": \"vp8\"" in body
    assert f"\"size_bytes\": {len(b'webm-payload')}" in body
    assert f"\"sizeBytes\": {len(b'webm-payload')}" in body
    assert "artifact_path" not in body
