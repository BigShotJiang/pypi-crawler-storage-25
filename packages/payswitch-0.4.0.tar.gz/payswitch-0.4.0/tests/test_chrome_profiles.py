"""Chrome profile identity helpers."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from payswitch.browser.chrome_profiles import (
    default_project_chrome_user_data_dir,
    ensure_project_chrome_profile,
    find_active_chrome_user_data_process,
    find_matching_chrome_debugging_process,
    identity_matches_email,
    is_chrome_user_data_dir_active,
    is_known_isolated_user_data_dir,
    list_chrome_debugging_processes,
    list_profile_identities,
    resolve_cdp_profile_identity,
    resolve_profile_identity,
)


def _write_local_state(root: Path, email: str) -> None:
    root.mkdir(parents=True, exist_ok=True)
    (root / "Local State").write_text(
        json.dumps(
            {
                "profile": {
                    "info_cache": {
                        "Default": {
                            "name": "用户1",
                            "user_name": email,
                            "gaia_name": "G Leon",
                        }
                    }
                }
            }
        ),
        encoding="utf-8",
    )


def test_resolve_profile_identity_matches_expected_email(tmp_path: Path) -> None:
    _write_local_state(tmp_path, "cine.dreamer.one@gmail.com")

    identity = resolve_profile_identity(tmp_path, "Default")

    assert identity is not None
    assert identity.user_name == "cine.dreamer.one@gmail.com"
    assert identity_matches_email(identity, "CINE.DREAMER.ONE@gmail.com")


def test_list_profile_identities_shows_directory_email_and_names(
    tmp_path: Path,
) -> None:
    (tmp_path / "Default").mkdir(parents=True)
    (tmp_path / "Profile 2").mkdir(parents=True)
    (tmp_path / "Profile 10").mkdir(parents=True)
    (tmp_path / "Profile 9").mkdir(parents=True)
    (tmp_path / "Local State").write_text(
        json.dumps(
            {
                "profile": {
                    "info_cache": {
                        "Profile 2": {
                            "name": "Work",
                            "user_name": "work@example.com",
                            "gaia_name": "Work User",
                            "gaia_given_name": "Work",
                            "is_consented_primary_account": True,
                            "active_time": 123.5,
                        },
                        "Profile 10": {
                            "name": "Later",
                            "user_name": "later@example.com",
                        },
                        "Default": {
                            "name": "Personal",
                            "user_name": "cine.dreamer.one@gmail.com",
                            "gaia_name": "Leon",
                        },
                        "Deleted": {
                            "name": "Old",
                            "user_name": "old@example.com",
                        },
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    identities = list_profile_identities(tmp_path)

    assert [identity.profile_directory for identity in identities] == [
        "Default",
        "Profile 2",
        "Profile 10",
    ]
    assert identities[0].user_name == "cine.dreamer.one@gmail.com"
    assert identities[1].name == "Work"
    assert identities[1].gaia_name == "Work User"
    assert identities[1].gaia_given_name == "Work"
    assert identities[1].is_consented_primary_account is True
    assert identities[1].active_time == 123.5


def test_resolve_cdp_profile_identity_parses_user_data_dir_with_spaces(
    tmp_path: Path,
) -> None:
    user_data_dir = tmp_path / "Application Support" / "Google" / "Chrome"
    _write_local_state(user_data_dir, "cine.dreamer.one@gmail.com")
    ps_output = (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome "
        f"--user-data-dir={user_data_dir} "
        "--profile-directory=Default "
        "--remote-debugging-address=127.0.0.1 "
        "--remote-debugging-port=9238 about:blank\n"
    )

    with patch("subprocess.check_output", return_value=ps_output):
        identity = resolve_cdp_profile_identity("http://127.0.0.1:9238")

    assert identity is not None
    assert identity.user_data_dir == user_data_dir
    assert identity.profile_directory == "Default"
    assert identity.user_name == "cine.dreamer.one@gmail.com"


def test_list_chrome_debugging_processes_returns_remote_debugging_only(
    tmp_path: Path,
) -> None:
    user_data_dir = tmp_path / "Application Support" / "Google" / "Chrome"
    ps_output = (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome "
        f"--user-data-dir={user_data_dir} "
        "--profile-directory=Profile 8 "
        "--remote-debugging-port=9238\n"
        "/Applications/Google Chrome.app/Contents/Frameworks/Google Chrome Helper "
        "--type=renderer --remote-debugging-port=9999\n"
    )

    with patch("subprocess.check_output", return_value=ps_output):
        processes = list_chrome_debugging_processes()

    assert len(processes) == 1
    assert processes[0].user_data_dir == user_data_dir
    assert processes[0].profile_directory == "Profile 8"
    assert processes[0].remote_debugging_port == "9238"


def test_find_matching_chrome_debugging_process_checks_profile_and_email(
    tmp_path: Path,
) -> None:
    user_data_dir = tmp_path / "Application Support" / "Google" / "Chrome"
    _write_local_state(user_data_dir, "g4426468@gmail.com")
    (user_data_dir / "Profile 8").mkdir(parents=True)
    (user_data_dir / "Local State").write_text(
        json.dumps(
            {
                "profile": {
                    "info_cache": {
                        "Profile 8": {
                            "name": "g leon",
                            "user_name": "g4426468@gmail.com",
                        }
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    ps_output = (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome "
        f"--user-data-dir={user_data_dir} "
        "--profile-directory=Profile 8 "
        "--remote-debugging-port=9244\n"
    )

    with patch("subprocess.check_output", return_value=ps_output):
        process = find_matching_chrome_debugging_process(
            user_data_dir,
            "Profile 8",
            expected_email="g4426468@gmail.com",
        )

    assert process is not None
    assert process.remote_debugging_port == "9244"


def test_find_active_chrome_user_data_process_matches_explicit_user_data_dir(
    tmp_path: Path,
) -> None:
    user_data_dir = tmp_path / "Application Support" / "Google" / "Chrome"
    ps_output = (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome "
        f"--user-data-dir={user_data_dir} "
        "--profile-directory=Profile 10 "
        "--remote-debugging-port=9224\n"
    )

    with patch("subprocess.check_output", return_value=ps_output):
        process = find_active_chrome_user_data_process(user_data_dir)

    assert process is not None
    assert process.user_data_dir == user_data_dir
    assert process.profile_directory == "Profile 10"
    assert process.remote_debugging_port == "9224"


def test_is_chrome_user_data_dir_active_ignores_renderer_process(
    tmp_path: Path,
) -> None:
    user_data_dir = tmp_path / "Chrome"
    ps_output = (
        "/Applications/Google Chrome.app/Contents/Frameworks/Google Chrome Helper "
        f"--type=renderer --user-data-dir={user_data_dir}\n"
    )

    with patch("subprocess.check_output", return_value=ps_output):
        assert is_chrome_user_data_dir_active(user_data_dir) is False


def test_is_known_isolated_user_data_dir_detects_runtime_copies(
    tmp_path: Path,
) -> None:
    paperclip_runtime = (
        tmp_path
        / ".paperclip"
        / "runtime"
        / "browser-profiles"
        / "direct-Profile_32"
    )
    payswitch_mirror = (
        tmp_path
        / "payswitch-cdp-mirrors"
        / "profile-Profile_8-abc123"
    )
    managed_profile = tmp_path / ".payswitch" / "profiles" / "kimi" / "browser_data"
    project_profile = tmp_path / ".payswitch" / "browser" / "chrome-user-data"
    real_chrome = tmp_path / "Library" / "Application Support" / "Google" / "Chrome"

    assert is_known_isolated_user_data_dir(paperclip_runtime) is True
    assert is_known_isolated_user_data_dir(payswitch_mirror) is True
    assert is_known_isolated_user_data_dir(managed_profile) is True
    assert is_known_isolated_user_data_dir(project_profile) is False
    assert is_known_isolated_user_data_dir(real_chrome) is False


def test_project_chrome_profile_helpers_create_persistent_root(
    tmp_path: Path,
) -> None:
    project_root = default_project_chrome_user_data_dir(tmp_path / ".payswitch")

    assert project_root == tmp_path / ".payswitch" / "browser" / "chrome-user-data"

    created = ensure_project_chrome_profile(project_root, "Default")

    assert created == project_root
    assert project_root.exists()
    assert (project_root / "Default").is_dir()
    assert (project_root / ".payswitch-project-profile").exists()
