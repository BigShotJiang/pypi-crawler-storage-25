"""Direct CDP attach tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from payswitch.browser.cdp_attach import (
    CdpAttachError,
    ensure_profile_cdp_url,
    find_profile_cdp_url,
    is_cdp_url_ready,
)


def test_find_profile_cdp_url_reuses_matching_process(tmp_path: Path) -> None:
    process = type("Process", (), {"remote_debugging_port": "9244"})()

    with patch(
        "payswitch.browser.cdp_attach.find_matching_chrome_debugging_process",
        return_value=process,
    ), patch(
        "payswitch.browser.cdp_attach.is_cdp_url_ready",
        return_value=True,
    ):
        cdp_url = find_profile_cdp_url(
            user_data_dir=tmp_path,
            profile_directory="Profile 8",
            expected_email="g4426468@gmail.com",
        )

    assert cdp_url == "http://127.0.0.1:9244"


def test_find_profile_cdp_url_ignores_dead_matching_port(tmp_path: Path) -> None:
    process = type("Process", (), {"remote_debugging_port": "9244"})()

    with patch(
        "payswitch.browser.cdp_attach.find_matching_chrome_debugging_process",
        return_value=process,
    ), patch(
        "payswitch.browser.cdp_attach.is_cdp_url_ready",
        return_value=False,
    ):
        cdp_url = find_profile_cdp_url(
            user_data_dir=tmp_path,
            profile_directory="Profile 8",
            expected_email="g4426468@gmail.com",
        )

    assert cdp_url is None


def test_ensure_profile_cdp_url_refuses_dead_matching_process(
    tmp_path: Path,
) -> None:
    chrome_root = tmp_path / "Chrome"
    (chrome_root / "Profile 8").mkdir(parents=True)
    process = type("Process", (), {"remote_debugging_port": "9244"})()

    with patch(
        "payswitch.browser.cdp_attach.find_profile_cdp_url",
        return_value=None,
    ), patch(
        "payswitch.browser.cdp_attach.find_matching_chrome_debugging_process",
        return_value=process,
    ), pytest.raises(CdpAttachError, match="端口不可连接"):
        ensure_profile_cdp_url(
            user_data_dir=chrome_root,
            profile_directory="Profile 8",
            expected_email="g4426468@gmail.com",
        )


def test_is_cdp_url_ready_rejects_invalid_url() -> None:
    assert is_cdp_url_ready("not-a-url") is False


def test_find_profile_cdp_url_rejects_isolated_runtime_profile(
    tmp_path: Path,
) -> None:
    isolated_root = (
        tmp_path
        / ".paperclip"
        / "runtime"
        / "browser-profiles"
        / "direct-Profile_32"
    )

    with pytest.raises(CdpAttachError, match="隔离/镜像 profile"):
        find_profile_cdp_url(
            user_data_dir=isolated_root,
            profile_directory="Profile 32",
        )


def test_ensure_profile_cdp_url_rejects_isolated_runtime_profile(
    tmp_path: Path,
) -> None:
    isolated_root = (
        tmp_path
        / ".paperclip"
        / "runtime"
        / "browser-profiles"
        / "direct-Profile_32"
    )

    with pytest.raises(CdpAttachError, match="隔离/镜像 profile"):
        ensure_profile_cdp_url(
            user_data_dir=isolated_root,
            profile_directory="Profile 32",
        )


def test_ensure_profile_cdp_url_requires_profile_directory(tmp_path: Path) -> None:
    chrome_root = tmp_path / "Chrome"
    chrome_root.mkdir()

    with patch(
        "payswitch.browser.cdp_attach.find_profile_cdp_url",
        return_value=None,
    ), pytest.raises(CdpAttachError, match="Chrome profile"):
        ensure_profile_cdp_url(
            user_data_dir=chrome_root,
            profile_directory="Profile 8",
        )


def test_ensure_profile_cdp_url_refuses_second_port_when_root_is_active(
    tmp_path: Path,
) -> None:
    chrome_root = tmp_path / "Chrome"
    (chrome_root / "Profile 8").mkdir(parents=True)
    active_process = type(
        "Process",
        (),
        {
            "remote_debugging_port": "9238",
            "profile_directory": "Profile 32",
        },
    )()

    with patch(
        "payswitch.browser.cdp_attach.find_profile_cdp_url",
        return_value=None,
    ), patch(
        "payswitch.browser.cdp_attach.find_active_chrome_user_data_process",
        return_value=active_process,
    ), pytest.raises(CdpAttachError, match="不会再尝试"):
        ensure_profile_cdp_url(
            user_data_dir=chrome_root,
            profile_directory="Profile 8",
        )
