"""Pay-Switch SpendingGuard 单元测试。

覆盖范围：
- 单笔限额：超出 / 未超出 / 限额为 0（不限制）
- 日累计限额：超出 / 未超出 / 限额为 0（不限制）
- 商户白名单：空白名单放行 / 在白名单中 / 不在白名单中
- 幂等去重：key 命中返回 existing_tx / key 为 None 跳过检查
- 检查短路语义：幂等命中后不执行后续检查

所有测试使用 unittest.mock.MagicMock 隔离 Ledger 依赖，
不依赖真实 SQLite 数据库。
"""

from __future__ import annotations

from unittest.mock import MagicMock

from payswitch.engine.guard import GuardResult, SpendingGuard
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import Transaction
from payswitch.models.types import TransactionStatus

# ===========================================================================
# Fixtures
# ===========================================================================


def _make_config(**kwargs) -> PaySwitchConfig:
    """创建测试用 PaySwitchConfig，支持关键字参数覆盖默认值。"""
    defaults = {
        "max_per_transaction": 500.0,
        "daily_limit": 2000.0,
        "whitelist": [],
    }
    defaults.update(kwargs)
    return PaySwitchConfig(**defaults)


def _make_mock_ledger(
    daily_total: float = 0.0,
    idempotency_result: Transaction | None = None,
) -> MagicMock:
    """创建 Ledger 的 Mock 对象，预设 get_daily_total 和 check_idempotency 的返回值。"""
    ledger = MagicMock()
    ledger.get_daily_total.return_value = daily_total
    ledger.check_idempotency.return_value = idempotency_result
    return ledger


def _make_existing_tx() -> Transaction:
    """创建一个用于幂等测试的已存在交易。"""
    return Transaction(
        amount=100.0,
        payee="deepseek",
        status=TransactionStatus.completed,
    )


# ===========================================================================
# 单笔限额测试
# ===========================================================================


class TestPerTransactionLimit:
    """单笔金额限额检查测试。"""

    def test_金额未超过单笔限额_放行(self):
        """金额在单笔限额以内时，guard 应放行（allowed=True）。"""
        config = _make_config(max_per_transaction=500.0)
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=499.99, payee="deepseek")
        assert result.allowed is True
        assert result.reason is None

    def test_金额恰好等于单笔限额_放行(self):
        """金额恰好等于单笔限额时，不超出，应放行。"""
        config = _make_config(max_per_transaction=500.0)
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=500.0, payee="deepseek")
        assert result.allowed is True

    def test_金额超过单笔限额_拦截(self):
        """金额超过单笔限额时，guard 应拒绝（allowed=False）并返回拒绝原因。"""
        config = _make_config(max_per_transaction=500.0)
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=500.01, payee="deepseek")
        assert result.allowed is False
        assert result.reason is not None
        assert "500.00" in result.reason  # 限额值应在 reason 中

    def test_单笔限额为0时不限制(self):
        """max_per_transaction=0 表示不限制，任意金额都应放行。"""
        config = _make_config(max_per_transaction=0.0, daily_limit=0.0)
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=99999.0, payee="deepseek")
        assert result.allowed is True

    def test_拦截消息包含超出金额(self):
        """拒绝原因应包含具体的超出金额，方便用户理解。"""
        config = _make_config(max_per_transaction=100.0)
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=150.0, payee="kimi")
        assert result.allowed is False
        assert "150.00" in result.reason  # 本次金额
        assert "100.00" in result.reason  # 限额


# ===========================================================================
# 日累计限额测试
# ===========================================================================


class TestDailyLimit:
    """日累计限额检查测试。"""

    def test_今日总额加本次未超出_放行(self):
        """今日已消费 + 本次金额 <= daily_limit 时，guard 应放行。"""
        config = _make_config(max_per_transaction=0.0, daily_limit=2000.0)
        # 今日已消费 1800，本次 199，合计 1999 < 2000
        ledger = _make_mock_ledger(daily_total=1800.0)
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=199.0, payee="qwen")
        assert result.allowed is True

    def test_今日总额加本次超出日限额_拦截(self):
        """今日已消费 + 本次金额 > daily_limit 时，guard 应拒绝。"""
        config = _make_config(max_per_transaction=0.0, daily_limit=2000.0)
        # 今日已消费 1900，本次 200，合计 2100 > 2000
        ledger = _make_mock_ledger(daily_total=1900.0)
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=200.0, payee="qwen")
        assert result.allowed is False
        assert result.reason is not None
        assert "2000.00" in result.reason  # 日限额

    def test_日限额为0时不限制(self):
        """daily_limit=0 表示不限制，任意金额都应放行。"""
        config = _make_config(max_per_transaction=0.0, daily_limit=0.0)
        # 今日已消费很多，但日限额为 0 不限制
        ledger = _make_mock_ledger(daily_total=99999.0)
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=50000.0, payee="deepseek")
        assert result.allowed is True

    def test_日限额拒绝消息包含已消费金额和剩余额度(self):
        """日限额拒绝消息应包含今日已消费、本次金额和剩余可用额度信息。"""
        config = _make_config(max_per_transaction=0.0, daily_limit=1000.0)
        ledger = _make_mock_ledger(daily_total=800.0)
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=300.0, payee="kimi")
        assert result.allowed is False
        assert "1000.00" in result.reason  # 日限额
        assert "800.00" in result.reason  # 今日已消费
        assert "300.00" in result.reason  # 本次金额

    def test_日限额检查调用ledger_get_daily_total(self):
        """日限额检查时应调用 ledger.get_daily_total() 获取当日总额。"""
        config = _make_config(max_per_transaction=0.0, daily_limit=100.0)
        ledger = _make_mock_ledger(daily_total=50.0)
        guard = SpendingGuard(config, ledger)
        guard.check(amount=30.0, payee="deepseek")
        ledger.get_daily_total.assert_called_once()


# ===========================================================================
# 商户白名单测试
# ===========================================================================


class TestWhitelist:
    """商户白名单检查测试。"""

    def test_空白名单_任何商户放行(self):
        """whitelist=[] 时，任何 payee 都应放行。"""
        config = _make_config(max_per_transaction=0.0, daily_limit=0.0, whitelist=[])
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=100.0, payee="unknown_merchant")
        assert result.allowed is True

    def test_payee在白名单中_放行(self):
        """payee 在 whitelist 中时，guard 应放行。"""
        config = _make_config(
            max_per_transaction=0.0,
            daily_limit=0.0,
            whitelist=["deepseek", "kimi"],
        )
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=50.0, payee="deepseek")
        assert result.allowed is True

    def test_payee不在白名单中_拦截(self):
        """payee 不在非空 whitelist 中时，guard 应拒绝。"""
        config = _make_config(
            max_per_transaction=0.0,
            daily_limit=0.0,
            whitelist=["deepseek", "kimi"],
        )
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=50.0, payee="unknown_site")
        assert result.allowed is False
        assert result.reason is not None
        assert "unknown_site" in result.reason  # 拒绝原因应包含被拒商户

    def test_白名单拒绝消息包含允许商户列表(self):
        """拒绝消息应包含当前白名单的商户列表，方便用户确认配置。"""
        config = _make_config(
            max_per_transaction=0.0,
            daily_limit=0.0,
            whitelist=["deepseek", "kimi"],
        )
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=50.0, payee="qwen")
        assert result.allowed is False
        # 拒绝原因应包含白名单中的商户
        assert "deepseek" in result.reason
        assert "kimi" in result.reason

    def test_白名单单个商户_其他商户被拦截(self):
        """仅一个商户在白名单时，其他所有商户应被拦截。"""
        config = _make_config(
            max_per_transaction=0.0,
            daily_limit=0.0,
            whitelist=["deepseek"],
        )
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        assert guard.check(amount=10.0, payee="deepseek").allowed is True
        assert guard.check(amount=10.0, payee="kimi").allowed is False
        assert guard.check(amount=10.0, payee="qwen").allowed is False


# ===========================================================================
# 幂等去重测试
# ===========================================================================


class TestIdempotency:
    """幂等键去重检查测试。"""

    def test_key命中返回existing_tx(self):
        """幂等 key 在 48 小时内命中时，应返回 allowed=True 且 existing_tx 非 None。"""
        existing = _make_existing_tx()
        config = _make_config()
        ledger = _make_mock_ledger(idempotency_result=existing)
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=100.0, payee="deepseek", idempotency_key="my-key")
        assert result.allowed is True
        assert result.existing_tx is not None
        assert result.existing_tx.tx_id == existing.tx_id

    def test_key未命中existing_tx为None(self):
        """幂等 key 未命中时，existing_tx 应为 None，流程继续检查其他规则。"""
        config = _make_config()
        ledger = _make_mock_ledger(idempotency_result=None)
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=10.0, payee="deepseek", idempotency_key="new-key")
        assert result.existing_tx is None

    def test_idempotency_key为None时跳过幂等检查(self):
        """idempotency_key=None 时，不应调用 ledger.check_idempotency。"""
        config = _make_config()
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        guard.check(amount=10.0, payee="deepseek", idempotency_key=None)
        # key 为 None 时不应调用 check_idempotency
        ledger.check_idempotency.assert_not_called()

    def test_幂等命中后不执行后续安全检查(self):
        """幂等命中时，应直接返回，不再执行单笔/日限额/白名单检查。"""
        existing = _make_existing_tx()
        # 设置会触发限额拦截的配置（如果被执行到的话）
        config = _make_config(
            max_per_transaction=50.0,  # 本次 100 > 50，本该被拦截
            daily_limit=100.0,         # 今日总额本该超出
            whitelist=["kimi"],        # payee=deepseek 不在白名单
        )
        ledger = _make_mock_ledger(
            daily_total=500.0,              # 已超出日限额
            idempotency_result=existing,    # 幂等命中
        )
        guard = SpendingGuard(config, ledger)
        result = guard.check(
            amount=100.0, payee="deepseek", idempotency_key="already-done"
        )
        # 幂等命中，即使其他条件会拦截也应放行
        assert result.allowed is True
        assert result.existing_tx is not None
        # 幂等命中后不应调用 get_daily_total（即日限额检查未执行）
        ledger.get_daily_total.assert_not_called()

    def test_幂等命中调用check_idempotency传入正确key(self):
        """幂等检查时，应将 idempotency_key 传递给 ledger.check_idempotency。"""
        config = _make_config()
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        guard.check(amount=10.0, payee="kimi", idempotency_key="specific-key")
        ledger.check_idempotency.assert_called_once_with("specific-key")


# ===========================================================================
# GuardResult 模型测试
# ===========================================================================


class TestGuardResult:
    """GuardResult 数据模型测试。"""

    def test_allowed_True时reason默认为None(self):
        """allowed=True 时，reason 字段默认应为 None。"""
        result = GuardResult(allowed=True)
        assert result.reason is None
        assert result.existing_tx is None

    def test_allowed_False时可携带reason(self):
        """allowed=False 时，应可携带中文拒绝原因。"""
        result = GuardResult(allowed=False, reason="单笔限额 ¥100.00 被超出")
        assert result.allowed is False
        assert result.reason == "单笔限额 ¥100.00 被超出"

    def test_幂等结果携带existing_tx(self):
        """幂等命中结果应携带 existing_tx。"""
        existing = _make_existing_tx()
        result = GuardResult(allowed=True, existing_tx=existing)
        assert result.allowed is True
        assert result.existing_tx is not None


# ===========================================================================
# 短路检查顺序测试
# ===========================================================================


class TestCheckOrderAndShortCircuit:
    """验证安全检查的顺序和短路语义。"""

    def test_单笔超出时不执行日限额检查(self):
        """单笔限额拦截后，不应调用 ledger.get_daily_total（日限额检查短路）。"""
        config = _make_config(max_per_transaction=100.0, daily_limit=1000.0)
        ledger = _make_mock_ledger()
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=200.0, payee="deepseek")
        assert result.allowed is False
        # 单笔拦截后，不应调用 get_daily_total
        ledger.get_daily_total.assert_not_called()

    def test_所有检查通过时allowed为True且无existing_tx(self):
        """所有检查均通过时，allowed=True 且 existing_tx 为 None。"""
        config = _make_config(
            max_per_transaction=0.0,
            daily_limit=0.0,
            whitelist=[],
        )
        ledger = _make_mock_ledger(daily_total=0.0, idempotency_result=None)
        guard = SpendingGuard(config, ledger)
        result = guard.check(amount=10.0, payee="any_merchant")
        assert result.allowed is True
        assert result.reason is None
        assert result.existing_tx is None
