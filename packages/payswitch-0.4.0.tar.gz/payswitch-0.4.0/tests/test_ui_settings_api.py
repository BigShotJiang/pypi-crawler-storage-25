import json
from datetime import UTC, datetime
from pathlib import Path

import pytest

from payswitch.cli import (
    _settings_api_config_payload,
    _settings_api_ensure_cdp_profile_updates,
    _settings_api_evidence_image_url,
    _settings_api_evidence_preview_url,
    _settings_api_profile_payload,
    _settings_api_project_media_artifacts,
    _settings_api_project_profile_updates,
    _settings_api_read_evidence_bytes,
    _settings_api_transaction_session_payload,
    _settings_api_validate_config_updates,
)
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import HumanAction, StepRecord, Transaction
from payswitch.models.types import ExecutionMode, PaymentMethod, TransactionStatus
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore


class DummyProfile:
    user_data_dir = Path("/tmp/chrome")
    profile_directory = "Profile 10"
    user_name = "yuan80060@gmail.com"
    name = "Yuan Leon"
    gaia_name = "Yuan Leon"
    gaia_given_name = "Yuan"
    is_consented_primary_account = True
    active_time = 123


def test_settings_api_masks_secrets() -> None:
    config = PaySwitchConfig(llm_api_key="encoded", stripe_secret_key="encoded")

    payload = _settings_api_config_payload(config)

    assert "llm_api_key" not in payload["config"]
    assert "stripe_secret_key" not in payload["config"]
    assert "vault" not in payload["config"]
    assert payload["config"]["secrets"]["llm_api_key"] is True
    assert payload["config"]["secrets"]["stripe_secret_key"] is True
    assert "browser_control_backends" in payload["options"]


def test_settings_api_rejects_protected_updates() -> None:
    config = PaySwitchConfig()

    with pytest.raises(ValueError, match="unsupported or protected"):
        _settings_api_validate_config_updates(config, {"llm_api_key": "secret"})


def test_settings_api_validates_update_types() -> None:
    config = PaySwitchConfig()

    updates = _settings_api_validate_config_updates(
        config,
        {
            "browser_control_backend": "cdp",
            "computer_use_enabled": False,
            "max_per_transaction": 88.0,
        },
    )

    assert updates["browser_control_backend"].value == "cdp"
    assert updates["computer_use_enabled"] is False
    assert updates["max_per_transaction"] == 88.0


def test_settings_api_profile_payload_has_selectable_identity() -> None:
    payload = _settings_api_profile_payload(DummyProfile(), 1)

    assert payload["id"] == "/tmp/chrome::Profile 10"
    assert payload["identity_label"] == "yuan80060@gmail.com"
    assert payload["profile_directory"] == "Profile 10"


def test_settings_api_project_profile_updates_create_dedicated_profile(
    tmp_path: Path,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path / "data")

    updates = _settings_api_project_profile_updates(config)

    profile_root = tmp_path / "data" / "browser" / "chrome-user-data"
    assert updates["browser_control_backend"] == "cdp"
    assert updates["chrome_user_data_dir"] == str(profile_root)
    assert updates["chrome_profile_directory"] == "Default"
    assert updates["chrome_cdp_url"] == ""
    assert (profile_root / "Default").exists()
    assert (profile_root / ".payswitch-project-profile").exists()


def test_settings_api_project_profile_can_launch_cdp(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path / "data")

    monkeypatch.setattr(
        "payswitch.cli.ensure_profile_cdp_url",
        lambda **_: "http://127.0.0.1:9333",
        raising=False,
    )
    monkeypatch.setattr(
        "payswitch.browser.cdp_attach.ensure_profile_cdp_url",
        lambda **_: "http://127.0.0.1:9333",
    )

    updates = _settings_api_project_profile_updates(
        config,
        expected_email="",
        ensure=True,
    )

    assert updates["chrome_cdp_url"] == "http://127.0.0.1:9333"


def test_settings_api_ensure_cdp_requires_configured_profile() -> None:
    config = PaySwitchConfig(chrome_user_data_dir="")

    with pytest.raises(ValueError, match="还没有配置 Chrome profile"):
        _settings_api_ensure_cdp_profile_updates(config)


def test_settings_api_transaction_session_payload_replays_steps_and_human_gate(
    tmp_path: Path,
) -> None:
    evidence_root = tmp_path / "evidence"
    evidence_dir = evidence_root / "external"
    evidence_dir.mkdir(parents=True)
    screenshot = evidence_dir / "shot.png"
    screenshot.write_bytes(b"png")
    qr_artifact = evidence_dir / "qr.png"
    ArtifactStore(tmp_path).write_bytes(
        qr_artifact,
        b"qr",
        artifact_kind="payment_qr_payload",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
    )
    evidence = evidence_dir / "step.json"
    evidence.write_text(
        json.dumps(
            {
                "current_url": "https://www.kimi.com/membership/pricing",
                "action": {"type": "observe"},
                "action_result": {
                    "kind": "page_observation",
                    "current_url": "https://www.kimi.com/membership/pricing",
                    "screenshot_path": str(screenshot),
                    "interaction_hints": [
                        {"kind": "requires_plan_confirmation", "blocking": True}
                    ],
                },
            }
        ),
        encoding="utf-8",
    )
    tx = Transaction(
        amount=19,
        currency="CNY",
        payee="kimi",
        reason="Kimi 月付测试",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        steps=[
            StepRecord(
                step_index=0,
                description="观察 Kimi 套餐页",
                status="success",
                evidence_path=str(evidence),
            )
        ],
        human_action=HumanAction(
            action_type="requires_plan_confirmation",
            requested_at=datetime.now(UTC),
            guidance="请确认月付还是年付。",
            details={
                "current_url": "https://www.kimi.com/membership/pricing",
                "qr_artifact_path": str(qr_artifact),
            },
        ),
    )

    payload = _settings_api_transaction_session_payload(
        tx,
        evidence_root=evidence_root.resolve(),
        request_base_url="http://127.0.0.1:8787",
    )

    assert payload["id"] == tx.tx_id
    assert payload["merchant"] == "kimi"
    assert payload["status"] == "waiting_human"
    assert [event["type"] for event in payload["events"]] == [
        "intent.received",
        "observe",
        "human.gate",
    ]
    assert payload["events"][1]["screenshot_url"].startswith(
        "http://127.0.0.1:8787/evidence?path="
    )
    assert payload["events"][2]["summary"] == "需要确认购买方案"
    assert payload["events"][2]["screenshot_url"].startswith(
        "http://127.0.0.1:8787/evidence?path="
    )
    assert payload["events"][2]["qr_artifact_url"].startswith(
        "http://127.0.0.1:8787/evidence?path="
    )


def test_settings_api_transaction_session_payload_reads_encrypted_evidence(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    monkeypatch.setattr(
        "payswitch.models.config.PaySwitchConfig.load",
        classmethod(lambda cls, config_path=None: config),
    )
    evidence_root = tmp_path / "evidence"
    evidence_dir = evidence_root / "external"
    evidence_dir.mkdir(parents=True)
    screenshot = evidence_dir / "shot.png"
    screenshot.write_bytes(b"png")
    evidence = evidence_dir / "step.json"
    ArtifactStore(config.data_dir).write_json(
        evidence,
        {
            "current_url": "https://www.kimi.com/membership/pricing",
            "action": {"type": "observe"},
            "action_result": {
                "kind": "page_observation",
                "current_url": "https://www.kimi.com/membership/pricing",
                "screenshot_path": str(screenshot),
                "interaction_hints": [
                    {"kind": "requires_plan_confirmation", "blocking": True}
                ],
            },
        },
        artifact_kind="external_action",
        sensitivity=ArtifactSensitivity.sensitive,
        metadata={"tx_id": "txn_settings_1", "step_index": 0},
    )
    tx = Transaction(
        amount=19,
        currency="CNY",
        payee="kimi",
        reason="Kimi 月付测试",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        steps=[
            StepRecord(
                step_index=0,
                description="观察 Kimi 套餐页",
                status="success",
                evidence_path=str(evidence),
            )
        ],
        human_action=HumanAction(
            action_type="requires_plan_confirmation",
            requested_at=datetime.now(UTC),
            guidance="请确认月付还是年付。",
            details={"current_url": "https://www.kimi.com/membership/pricing"},
        ),
    )

    payload = _settings_api_transaction_session_payload(
        tx,
        evidence_root=evidence_root.resolve(),
        request_base_url="http://127.0.0.1:8787",
    )

    assert payload["events"][1]["type"] == "observe"
    assert payload["events"][1]["screenshot_url"].startswith(
        "http://127.0.0.1:8787/evidence?path="
    )


def test_settings_api_transaction_session_payload_projects_media_artifacts(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    monkeypatch.setattr(
        "payswitch.models.config.PaySwitchConfig.load",
        classmethod(lambda cls, config_path=None: config),
    )
    evidence_root = tmp_path / "evidence"
    evidence_dir = evidence_root / "external"
    evidence_dir.mkdir(parents=True)
    capture = evidence_dir / "capture.webm"
    ArtifactStore(config.data_dir).write_bytes(
        capture,
        b"webm",
        artifact_kind="external_browser_recording",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="video/webm",
    )
    evidence = evidence_dir / "step.json"
    ArtifactStore(config.data_dir).write_json(
        evidence,
        {
            "current_url": "https://www.kimi.com/membership/pricing",
            "action": {"type": "observe"},
            "action_result": {
                "kind": "page_observation",
                "current_url": "https://www.kimi.com/membership/pricing",
                "media_artifacts": [
                    {
                        "artifactId": "capture_webm",
                        "name": "capture.webm",
                        "content_type": "video/webm",
                        "artifact_path": str(capture),
                    }
                ],
            },
        },
        artifact_kind="external_action",
        sensitivity=ArtifactSensitivity.sensitive,
        metadata={"tx_id": "txn_settings_media", "step_index": 0},
    )
    tx = Transaction(
        amount=19,
        currency="CNY",
        payee="kimi",
        reason="Kimi 月付测试",
        payment_method=PaymentMethod.alipay_qr,
        execution_mode=ExecutionMode.computer_use,
        status=TransactionStatus.human_action_required,
        steps=[
            StepRecord(
                step_index=0,
                description="观察 Kimi 套餐页",
                status="success",
                evidence_path=str(evidence),
            )
        ],
        human_action=HumanAction(
            action_type="requires_plan_confirmation",
            requested_at=datetime.now(UTC),
            guidance="请确认月付还是年付。",
            details={"current_url": "https://www.kimi.com/membership/pricing"},
        ),
    )

    payload = _settings_api_transaction_session_payload(
        tx,
        evidence_root=evidence_root.resolve(),
        request_base_url="http://127.0.0.1:8787",
    )

    media_item = payload["events"][1]["media_artifacts"][0]
    assert media_item["download_url"].startswith("http://127.0.0.1:8787/evidence?path=")
    assert media_item["downloadUrl"] == media_item["download_url"]


def test_settings_api_project_media_artifacts_adds_preview_urls(tmp_path: Path) -> None:
    artifact = tmp_path / "evidence" / "external" / "capture.webm"
    artifact.parent.mkdir(parents=True, exist_ok=True)
    artifact.write_bytes(b"webm")

    payload = _settings_api_project_media_artifacts(
        [
            {
                "recording_index": 2,
                "artifact_path": str(artifact),
                "content_type": "video/webm",
                "capture_engine": "ffmpeg_replay",
                "duration_seconds": 1.0,
                "frame_rate": 1.0,
                "source_screenshot_count": 1,
                "bit_rate": 800000,
                "frame_width": 1280,
                "frame_height": 720,
                "codec_name": "mpeg4",
                "recording_source": "observation_screenshots",
            }
        ],
        evidence_root=(tmp_path / "evidence").resolve(),
        request_base_url="http://127.0.0.1:8787",
    )

    assert payload[0]["download_url"].startswith("http://127.0.0.1:8787/evidence?path=")
    assert payload[0]["downloadUrl"] == payload[0]["download_url"]
    assert payload[0]["recording_index"] == 2
    assert payload[0]["recordingIndex"] == 2
    assert payload[0]["capture_engine"] == "ffmpeg_replay"
    assert payload[0]["captureEngine"] == "ffmpeg_replay"
    assert payload[0]["duration_seconds"] == pytest.approx(1.0)
    assert payload[0]["durationSeconds"] == pytest.approx(1.0)
    assert payload[0]["frame_rate"] == pytest.approx(1.0)
    assert payload[0]["frameRate"] == pytest.approx(1.0)
    assert payload[0]["source_screenshot_count"] == 1
    assert payload[0]["sourceScreenshotCount"] == 1
    assert payload[0]["bit_rate"] == 800000
    assert payload[0]["bitRate"] == 800000
    assert payload[0]["frame_width"] == 1280
    assert payload[0]["frameWidth"] == 1280
    assert payload[0]["frame_height"] == 720
    assert payload[0]["frameHeight"] == 720
    assert payload[0]["codec_name"] == "mpeg4"
    assert payload[0]["codecName"] == "mpeg4"
    assert payload[0]["recording_source"] == "observation_screenshots"
    assert payload[0]["recordingSource"] == "observation_screenshots"
    assert payload[0]["size_bytes"] == len(b"webm")
    assert payload[0]["sizeBytes"] == len(b"webm")


def test_settings_api_read_evidence_bytes_reads_encrypted_png(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    monkeypatch.setattr(
        "payswitch.models.config.PaySwitchConfig.load",
        classmethod(lambda cls, config_path=None: config),
    )
    screenshot = tmp_path / "evidence" / "external" / "shot.png"
    ArtifactStore(config.data_dir).write_bytes(
        screenshot,
        b"\x89PNG\r\nfake",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
    )

    payload = _settings_api_read_evidence_bytes(str(screenshot))

    assert payload == (b"\x89PNG\r\nfake", "image/png")


def test_settings_api_read_evidence_bytes_guesses_svg_content_type(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    monkeypatch.setattr(
        "payswitch.models.config.PaySwitchConfig.load",
        classmethod(lambda cls, config_path=None: config),
    )
    image = tmp_path / "evidence" / "qr" / "code.svg"
    image.parent.mkdir(parents=True, exist_ok=True)
    image.write_text("<svg xmlns='http://www.w3.org/2000/svg'></svg>", encoding="utf-8")

    payload = _settings_api_read_evidence_bytes(str(image))

    assert payload == (
        b"<svg xmlns='http://www.w3.org/2000/svg'></svg>",
        "image/svg+xml",
    )


@pytest.mark.parametrize("suffix", [".png", ".jpg", ".jpeg", ".webp", ".svg"])
def test_settings_api_evidence_image_url_accepts_supported_image_suffixes(
    tmp_path: Path,
    suffix: str,
) -> None:
    artifact = tmp_path / "evidence" / "preview" / f"artifact{suffix}"
    artifact.parent.mkdir(parents=True, exist_ok=True)
    artifact.write_bytes(b"data")

    url = _settings_api_evidence_image_url(
        str(artifact),
        evidence_root=(tmp_path / "evidence").resolve(),
        request_base_url="http://127.0.0.1:8787",
    )

    assert url.startswith("http://127.0.0.1:8787/evidence?path=")


@pytest.mark.parametrize("suffix", [".png", ".jpg", ".jpeg", ".webp", ".svg", ".webm", ".mp4"])
def test_settings_api_evidence_preview_url_accepts_supported_preview_suffixes(
    tmp_path: Path,
    suffix: str,
) -> None:
    artifact = tmp_path / "evidence" / "preview" / f"artifact{suffix}"
    artifact.parent.mkdir(parents=True, exist_ok=True)
    artifact.write_bytes(b"data")

    url = _settings_api_evidence_preview_url(
        str(artifact),
        evidence_root=(tmp_path / "evidence").resolve(),
        request_base_url="http://127.0.0.1:8787",
    )

    assert url.startswith("http://127.0.0.1:8787/evidence?path=")
