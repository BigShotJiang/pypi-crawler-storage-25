import importlib.util
import json
from pathlib import Path

import pytest
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from payswitch.agent_language import PaymentIntent
from payswitch.security import secret_envelope as envelope_mod
from payswitch.security.secret_envelope import (
    SECRET_ENVELOPE_ALGORITHM,
    SECRET_ENVELOPE_SCHEMA,
    SecretEnvelopeError,
    decrypt_secret_text,
    encrypt_secret,
    generate_secret_inbox,
)
from payswitch.server import _as_a2a_task, _maybe_encrypt_result_secret, store


def _run(coro):
    import asyncio

    return asyncio.run(coro)


async def _reset_store() -> None:
    await store.clear()


def _forge_envelope(
    secret: str,
    *,
    encrypt_to_public_key: str,
    advertised_public_key: str | None = None,
    algorithm: str = SECRET_ENVELOPE_ALGORITHM,
) -> dict:
    """Create a validly tagged envelope with adversarial metadata."""

    recipient = envelope_mod._public_key_from_b64(encrypt_to_public_key)
    ephemeral = x25519.X25519PrivateKey.generate()
    salt = b"\x11" * 16
    nonce = b"\x22" * 12
    aad_public_key = advertised_public_key or encrypt_to_public_key
    aes_key = envelope_mod._derive_key(ephemeral.exchange(recipient), salt)
    envelope = {
        "schema": SECRET_ENVELOPE_SCHEMA,
        "algorithm": algorithm,
        "provider": "deepseek",
        "secret_type": "api_key",
        "key_name": None,
        "created_at": "2026-05-15T00:00:00Z",
        "recipient_public_key": aad_public_key,
        "recipient_id": envelope_mod.public_key_fingerprint(aad_public_key),
        "ephemeral_public_key": envelope_mod._raw_public_key(ephemeral.public_key()),
        "salt": envelope_mod.b64url_encode(salt),
        "nonce": envelope_mod.b64url_encode(nonce),
        "metadata": {},
    }
    envelope["ciphertext"] = envelope_mod.b64url_encode(
        AESGCM(aes_key).encrypt(
            nonce,
            secret.encode("utf-8"),
            envelope_mod._canonical_json(envelope),
        )
    )
    return envelope


def _load_payagent_module():
    path = (
        Path(__file__).resolve().parents[1]
        / "plugins"
        / "pay-switch-agent"
        / "scripts"
        / "payswitch_agent.py"
    )
    spec = importlib.util.spec_from_file_location("payagent_under_test", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_secret_envelope_round_trips_without_plaintext_leak():
    inbox = generate_secret_inbox()
    envelope = encrypt_secret(
        "sk-test-deepseek",
        recipient_public_key=inbox["public_key"],
        provider="deepseek",
        metadata={"purchase_session": "psw_test"},
    )

    assert envelope["schema"] == SECRET_ENVELOPE_SCHEMA
    assert "sk-test-deepseek" not in json.dumps(envelope)
    assert decrypt_secret_text(envelope, recipient_private_key=inbox["private_key"]) == (
        "sk-test-deepseek"
    )

    wrong_inbox = generate_secret_inbox()
    with pytest.raises(SecretEnvelopeError):
        decrypt_secret_text(envelope, recipient_private_key=wrong_inbox["private_key"])


def test_secret_envelope_rejects_valid_tag_with_wrong_advertised_recipient():
    inbox = generate_secret_inbox()
    attacker_inbox = generate_secret_inbox()
    envelope = _forge_envelope(
        "sk-misbound",
        encrypt_to_public_key=inbox["public_key"],
        advertised_public_key=attacker_inbox["public_key"],
    )

    with pytest.raises(SecretEnvelopeError, match="recipient public key mismatch"):
        decrypt_secret_text(envelope, recipient_private_key=inbox["private_key"])


def test_secret_envelope_rejects_valid_tag_with_unsupported_algorithm():
    inbox = generate_secret_inbox()
    envelope = _forge_envelope(
        "sk-downgrade",
        encrypt_to_public_key=inbox["public_key"],
        algorithm="X25519-HKDF-SHA256-AES-128-GCM",
    )

    with pytest.raises(SecretEnvelopeError, match="unsupported secret envelope algorithm"):
        decrypt_secret_text(envelope, recipient_private_key=inbox["private_key"])


def test_payagent_decrypt_rejects_misbound_recipient_metadata():
    payagent = _load_payagent_module()
    inbox = payagent.generate_secret_inbox()
    attacker_inbox = payagent.generate_secret_inbox()
    envelope = _forge_envelope(
        "sk-payagent-misbound",
        encrypt_to_public_key=inbox["public_key"],
        advertised_public_key=attacker_inbox["public_key"],
    )

    with pytest.raises(SystemExit) as exc:
        payagent.decrypt_secret_envelope(envelope, inbox)
    assert "recipient public key mismatch" in str(exc.value)


def test_result_secret_delivery_encrypts_all_sensitive_secret_values():
    inbox = generate_secret_inbox()
    intent = PaymentIntent(
        amount=10,
        currency="CNY",
        payee="deepseek",
        reason="DeepSeek API key purchase",
        method="alipay_qr",
        source_agent="codex",
        metadata={
            "secret_delivery": {
                "requested": True,
                "recipient_public_key": inbox["public_key"],
                "secret_type": "api_key",
            }
        },
    )
    protected = _maybe_encrypt_result_secret(
        {
            "tx_id": "txn_deepseek_multi_secret",
            "payee": "deepseek",
            "status": "completed",
            "api_key": "sk-primary",
            "refresh_token": "rt-refresh",
            "provisioned_api_key": {
                "access_token": "atk-access",
                "public_label": "visible",
            },
        },
        intent,
    )

    serialized = json.dumps(protected)
    assert "sk-primary" not in serialized
    assert "rt-refresh" not in serialized
    assert "atk-access" not in serialized
    assert protected["provisioned_api_key"] == {"public_label": "visible"}

    decrypted = {
        decrypt_secret_text(envelope, recipient_private_key=inbox["private_key"])
        for envelope in protected["secret_envelopes"]
    }
    assert decrypted == {"sk-primary", "rt-refresh", "atk-access"}


def test_a2a_task_returns_encrypted_secret_artifact_and_redacted_result():
    _run(_reset_store())
    inbox = generate_secret_inbox()
    intent = PaymentIntent(
        amount=10,
        currency="CNY",
        payee="deepseek",
        reason="DeepSeek API key purchase",
        method="alipay_qr",
        source_agent="codex",
        metadata={
            "secret_delivery": {
                "requested": True,
                "recipient_public_key": inbox["public_key"],
                "secret_type": "api_key",
            }
        },
    )
    task = _run(store.create(intent))
    result = _maybe_encrypt_result_secret(
        {
            "tx_id": "txn_deepseek_1",
            "payee": "deepseek",
            "status": "completed",
            "api_key": "sk-test-deepseek",
        },
        intent,
    )
    task = _run(store.update(task.id, status="completed", result=result))

    a2a_task = _as_a2a_task(task)
    serialized = json.dumps(a2a_task)

    assert "sk-test-deepseek" not in serialized
    result_artifact = next(
        artifact
        for artifact in a2a_task["artifacts"]
        if artifact["artifactId"] == "pay_switch_result"
    )
    assert "api_key" not in result_artifact["parts"][0]["data"]
    secret_artifact = next(
        artifact
        for artifact in a2a_task["artifacts"]
        if artifact["artifactId"] == "encrypted_secret_1"
    )
    envelope = secret_artifact["parts"][0]["data"]
    assert decrypt_secret_text(envelope, recipient_private_key=inbox["private_key"]) == (
        "sk-test-deepseek"
    )
