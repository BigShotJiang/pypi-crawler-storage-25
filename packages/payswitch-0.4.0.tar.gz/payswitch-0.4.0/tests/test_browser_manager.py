from payswitch.browser.manager import RuntimeBrowserManager


def test_browser_manager_selects_visible_session_and_verifies_target() -> None:
    manager = RuntimeBrowserManager(workspace_id="uws_alice")
    manager.register_session("task_a", "bctx_a")

    manager.select_session(
        "task_a",
        browser_context_id="bctx_a",
        foreground_lease_id=None,
        reason="operator_select",
    )
    verified = manager.verify_visible_action(
        "task_a",
        browser_context_id="bctx_a",
        action="computer_use",
        foreground_lease_id=None,
    )

    assert verified["allowed"] is True
    assert verified["active_browser_context_id"] == "bctx_a"
    assert str(verified["active_browser_tab_id"]).startswith("btab_")
    assert str(verified["display_focus_z_order_token"]).startswith("zord_")


def test_browser_manager_rejects_context_mismatch_and_foreground_mismatch() -> None:
    manager = RuntimeBrowserManager(workspace_id="uws_alice")
    manager.register_session("task_a", "bctx_a")
    manager.select_session(
        "task_a",
        browser_context_id="bctx_a",
        foreground_lease_id="fg_a",
        reason="human_gate",
    )

    wrong_context = manager.verify_visible_action(
        "task_a",
        browser_context_id="bctx_other",
        action="computer_use",
        foreground_lease_id="fg_a",
    )
    wrong_lease = manager.verify_visible_action(
        "task_a",
        browser_context_id="bctx_a",
        action="computer_use",
        foreground_lease_id=None,
    )

    assert wrong_context["allowed"] is False
    assert wrong_context["reason"] == "browser_context_mismatch"
    assert wrong_lease["allowed"] is False
    assert wrong_lease["reason"] == "foreground_lease_mismatch"


def test_browser_manager_focus_lock_blocks_other_visible_actions() -> None:
    manager = RuntimeBrowserManager(workspace_id="uws_alice")
    manager.register_session("task_a", "bctx_a")
    manager.register_session("task_b", "bctx_b")
    manager.select_session(
        "task_a",
        browser_context_id="bctx_a",
        foreground_lease_id=None,
        reason="operator_select",
    )

    locked = manager.begin_visible_action(
        "task_a",
        browser_context_id="bctx_a",
        action="computer_use",
        foreground_lease_id=None,
    )
    blocked = manager.verify_visible_action(
        "task_b",
        browser_context_id="bctx_b",
        action="computer_use",
        foreground_lease_id=None,
    )
    manager.end_visible_action(lock_id=str(locked["display_focus_lock_id"]))
    manager.select_session(
        "task_b",
        browser_context_id="bctx_b",
        foreground_lease_id=None,
        reason="operator_select",
    )
    recovered = manager.begin_visible_action(
        "task_b",
        browser_context_id="bctx_b",
        action="computer_use",
        foreground_lease_id=None,
    )

    assert locked["allowed"] is True
    assert str(locked["display_focus_lock_id"]).startswith("vlock_")
    assert blocked["allowed"] is False
    assert blocked["reason"] == "session_not_visible_owner"
    assert recovered["allowed"] is True
