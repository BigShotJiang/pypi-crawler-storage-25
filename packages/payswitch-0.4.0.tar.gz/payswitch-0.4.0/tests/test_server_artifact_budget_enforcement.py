from __future__ import annotations

from fastapi.testclient import TestClient

from payswitch.models.config import PaySwitchConfig
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore
from payswitch.server import app, build_artifact_budget_enforcement_supervisor_from_env


def test_build_artifact_budget_enforcement_supervisor_from_env_defaults_disabled(
    monkeypatch,
) -> None:
    monkeypatch.delenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_ENABLED", raising=False)

    supervisor = build_artifact_budget_enforcement_supervisor_from_env()

    assert supervisor is None


def test_build_artifact_budget_enforcement_supervisor_from_env_supports_enabled_config(
    monkeypatch,
    tmp_path,
) -> None:
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_ENABLED", "1")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_STORAGE_BUDGET_MB", "1")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_POLL_INTERVAL_SECONDS", "2.5")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_BATCH_LIMIT", "4")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_TARGET_RATIO", "0.8")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_DRY_RUN", "true")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_INCLUDE_SENSITIVE", "1")

    supervisor = build_artifact_budget_enforcement_supervisor_from_env(
        config_override=PaySwitchConfig(data_dir=tmp_path),
    )

    assert supervisor is not None
    snapshot = supervisor.snapshot()
    assert snapshot["enabled"] is True
    assert snapshot["running"] is False
    assert snapshot["poll_interval_seconds"] == 2.5
    assert snapshot["batch_limit"] == 4
    assert snapshot["dry_run"] is True
    assert snapshot["include_sensitive"] is True


def test_artifact_budget_enforcement_health_endpoint_reports_service_supervision(
    monkeypatch,
    tmp_path,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    ArtifactStore(config.data_dir).write_bytes(
        tmp_path / "evidence" / "preview" / "public.png",
        b"public-preview",
        artifact_kind="public_preview",
        sensitivity=ArtifactSensitivity.public,
        content_type="image/png",
    )
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_ENABLED", "1")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_STORAGE_BUDGET_MB", "0.00001")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_POLL_INTERVAL_SECONDS", "0.01")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_BATCH_LIMIT", "3")
    monkeypatch.setenv("PAYSWITCH_ARTIFACT_BUDGET_ENFORCER_DRY_RUN", "1")

    with TestClient(app) as client:
        enforcement = client.get("/api/artifact-budget-enforcement/health")
        health = client.get("/api/health")

        assert enforcement.status_code == 200
        payload = enforcement.json()
        assert payload["enabled"] is True
        assert payload["running"] is True
        assert payload["batch_limit"] == 3
        assert payload["dry_run"] is True
        assert payload["budget_bytes"] is not None

        assert health.status_code == 200
        health_payload = health.json()
        assert health_payload["artifact_budget_enforcement"]["enabled"] is True
        assert health_payload["artifact_budget_enforcement"]["running"] is True
        assert health_payload["artifact_budget_enforcement"]["batch_limit"] == 3
