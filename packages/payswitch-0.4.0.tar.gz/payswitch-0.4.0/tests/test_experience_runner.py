from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from payswitch.adapters import ScriptStep
from payswitch.adapters.base import LoginRequiredError
from payswitch.experience import (
    ExperienceRecipe,
    RecipeExecutionError,
    RecipeExpectation,
    RecipeRunner,
    RecipeWaypoint,
)
from payswitch.models.transaction import Transaction
from payswitch.security.artifacts import ArtifactStore
from payswitch.security.screenshot_budget import TransactionScreenshotBudget


class _FakePage:
    def __init__(self) -> None:
        self.url = "https://example.test/start"
        self.goto = AsyncMock(side_effect=self._goto)
        self.wait_for_load_state = AsyncMock()
        self.evaluate = AsyncMock(side_effect=self._evaluate)
        self.screenshot = AsyncMock(side_effect=self._screenshot)
        self.locator = lambda selector: self
        self.count = AsyncMock(return_value=1)

    async def _goto(self, url: str, **_: object) -> None:
        self.url = url

    async def _evaluate(self, script: str) -> str:
        if "innerHTML" in script:
            return "<div>Plan card missing</div>"
        return "Plan card missing"

    async def _screenshot(self, path: Path | None = None) -> bytes:
        if path is not None:
            path.write_bytes(b"png")
        return b"png"


@pytest.mark.asyncio
async def test_runner_emits_structured_waypoint_failure_context(tmp_path: Path) -> None:
    recipe = ExperienceRecipe(
        recipe_id="kimi.membership_monthly_qr",
        platform="kimi",
        flow="membership_monthly_qr",
        waypoints=[
            RecipeWaypoint(
                id="reach_pricing_surface",
                intent="进入 Kimi 会员页",
                action="semantic",
                semantic_action="noop",
                expected=RecipeExpectation(any_texts=["Monthly"]),
            )
        ],
    )
    events: list[dict[str, object]] = []

    async def telemetry(payload: dict[str, object]) -> None:
        events.append(payload)

    page = _FakePage()
    runner = RecipeRunner(
        recipe=recipe,
        semantic_actions={"noop": AsyncMock()},
        telemetry_callback=telemetry,
        evidence_dir=tmp_path / "evidence",
        artifact_store=ArtifactStore(tmp_path),
    )
    steps: list[ScriptStep] = []

    async def record_step(step: ScriptStep) -> None:
        steps.append(step)

    with pytest.raises(RecipeExecutionError) as exc_info:
        await runner.run(page=page, amount=49.0, method=None, steps=steps, record_step=record_step)

    failure = exc_info.value.failure_context
    assert failure["waypoint_id"] == "reach_pricing_surface"
    assert failure["failed_assertion"]["any_texts"] == ["Monthly"]
    assert failure["visible_text_summary"] == "Plan card missing"
    assert Path(failure["screenshot_path"]).exists()
    assert ArtifactStore(tmp_path).read_bytes(Path(failure["screenshot_path"])) == b"png"
    assert [event["kind"] for event in events] == ["waypoint.started", "waypoint.failed"]


@pytest.mark.asyncio
async def test_runner_navigate_waypoint_records_step_and_success_event() -> None:
    recipe = ExperienceRecipe(
        recipe_id="demo.navigate",
        platform="demo",
        flow="start",
        waypoints=[
            RecipeWaypoint(
                id="open_home",
                intent="打开首页",
                action="navigate",
                description="打开首页",
                url="https://example.test/home",
                expected=RecipeExpectation(url_contains=["/home"]),
            )
        ],
    )
    events: list[dict[str, object]] = []

    async def telemetry(payload: dict[str, object]) -> None:
        events.append(payload)

    page = _FakePage()
    steps: list[ScriptStep] = []
    runner = RecipeRunner(
        recipe=recipe,
        semantic_actions={},
        telemetry_callback=telemetry,
    )

    async def record_step(step: ScriptStep) -> None:
        steps.append(step)

    await runner.run(page=page, amount=1.0, method=None, steps=steps, record_step=record_step)

    assert page.url == "https://example.test/home"
    assert steps[0].action == "navigate"
    assert [event["kind"] for event in events] == ["waypoint.started", "waypoint.succeeded"]


@pytest.mark.asyncio
async def test_runner_executes_synchronous_policy_checkpoint_before_waypoint() -> None:
    recipe = ExperienceRecipe(
        recipe_id="kimi.membership_monthly_qr",
        platform="kimi",
        flow="membership_monthly_qr",
        waypoints=[
            RecipeWaypoint(
                id="confirm_membership_checkout",
                intent="确认进入收银台",
                action="semantic",
                semantic_action="noop",
                synchronous_policy_checkpoint=True,
                expected=RecipeExpectation(any_texts=["Plan card missing"]),
            )
        ],
    )
    page = _FakePage()
    events: list[dict[str, object]] = []
    steps: list[ScriptStep] = []
    policy_checkpoint = AsyncMock()

    async def telemetry(payload: dict[str, object]) -> None:
        events.append(payload)

    async def record_step(step: ScriptStep) -> None:
        steps.append(step)

    runner = RecipeRunner(
        recipe=recipe,
        semantic_actions={"noop": AsyncMock()},
        telemetry_callback=telemetry,
        policy_checkpoint_callback=policy_checkpoint,
    )

    await runner.run(page=page, amount=49.0, method=None, steps=steps, record_step=record_step)

    policy_checkpoint.assert_awaited_once()
    assert steps[0].action == "policy_checkpoint"
    assert [event["kind"] for event in events] == [
        "waypoint.started",
        "waypoint.policy_checkpoint",
        "waypoint.succeeded",
    ]


@pytest.mark.asyncio
async def test_runner_marks_login_required_policy_checkpoint_failure() -> None:
    recipe = ExperienceRecipe(
        recipe_id="kimi.membership_monthly_qr",
        platform="kimi",
        flow="membership_monthly_qr",
        waypoints=[
            RecipeWaypoint(
                id="confirm_membership_checkout",
                intent="确认进入收银台",
                action="semantic",
                semantic_action="noop",
                synchronous_policy_checkpoint=True,
            )
        ],
    )
    page = _FakePage()
    runner = RecipeRunner(
        recipe=recipe,
        semantic_actions={"noop": AsyncMock()},
        policy_checkpoint_callback=AsyncMock(side_effect=LoginRequiredError("login required")),
    )

    with pytest.raises(RecipeExecutionError) as exc_info:
        await runner.run(
            page=page,
            amount=49.0,
            method=None,
            steps=[],
            record_step=AsyncMock(),
        )

    failure = exc_info.value.failure_context
    assert failure["login_required"] is True
    assert failure["synchronous_policy_checkpoint"] is True


@pytest.mark.asyncio
async def test_runner_marks_budget_exhaustion_in_failure_telemetry(tmp_path: Path) -> None:
    recipe = ExperienceRecipe(
        recipe_id="kimi.membership_monthly_qr",
        platform="kimi",
        flow="membership_monthly_qr",
        waypoints=[
            RecipeWaypoint(
                id="reach_pricing_surface",
                intent="进入 Kimi 会员页",
                action="semantic",
                semantic_action="noop",
                expected=RecipeExpectation(any_texts=["Monthly"]),
            )
        ],
    )
    events: list[dict[str, object]] = []

    async def telemetry(payload: dict[str, object]) -> None:
        events.append(payload)

    page = _FakePage()
    budget = TransactionScreenshotBudget.from_transaction(
        Transaction(amount=49, payee="kimi"),
        limit=1,
    )
    runner = RecipeRunner(
        recipe=recipe,
        semantic_actions={"noop": AsyncMock()},
        telemetry_callback=telemetry,
        evidence_dir=tmp_path / "evidence",
        artifact_store=ArtifactStore(tmp_path),
        screenshot_budget=budget,
    )

    with pytest.raises(RecipeExecutionError):
        await runner.run(
            page=page,
            amount=49.0,
            method=None,
            steps=[],
            record_step=AsyncMock(),
        )

    state = budget.snapshot()
    assert state.used == 1
    assert state.exhausted is True
    assert [event["kind"] for event in events] == [
        "waypoint.started",
        "waypoint.failed",
        "artifact.budget_exhausted",
    ]
