"""payswitch MCP Server 测试。

测试 MCP Tools 注册、核心 tool 功能、HTTP 挂载。
需要 mcp 库（server extras），CI 未安装时自动跳过。
"""

from __future__ import annotations

import json

import pytest

# mcp 库仅在 [server] extras 中，CI 用 --extra dev 运行时不可用
pytest.importorskip("mcp", reason="需要 mcp 库（uv run --extra server）")

from server.mcp_server import mcp  # noqa: E402

# ─── Test 1: MCP Tools 列表 ─────────────────────────────────

class TestMCPToolsList:
    """验证 9 个 tool 都已注册。"""

    def test_nine_tools_registered(self) -> None:
        tools = mcp._tool_manager._tools
        assert len(tools) == 9

    def test_expected_tool_names(self) -> None:
        tools = mcp._tool_manager._tools
        expected = {
            "load_card",
            "store_card",
            "check_spending_limit",
            "evaluate_risk",
            "launch_browser",
            "detect_payment_form",
            "fill_payment_form",
            "record_transaction",
            "execute_checkout",
        }
        assert set(tools.keys()) == expected

    def test_all_tools_have_description(self) -> None:
        """每个 tool 都有 docstring 作为描述。"""
        tools = mcp._tool_manager._tools
        for name, tool in tools.items():
            assert tool.description, f"Tool '{name}' 缺少描述"


# ─── Test 2: load_card ───────────────────────────────────────

class TestLoadCard:
    """load_card tool 功能测试。"""

    async def test_load_nonexistent_card(self) -> None:
        """加载不存在的卡应返回错误。"""
        from server.mcp_server import load_card

        result = await load_card("nonexistent-card-xyz")
        data = json.loads(result)
        assert "error" in data or "card_alias" in data

    async def test_load_card_returns_json(self) -> None:
        """返回值是有效 JSON 字符串。"""
        from server.mcp_server import load_card

        result = await load_card("test-card")
        # 应该能解析为 JSON
        data = json.loads(result)
        assert isinstance(data, dict)


# ─── Test 3: check_spending_limit ───────────────────────────

class TestCheckSpendingLimit:
    """限额检查 tool 测试。"""

    async def test_check_returns_json(self) -> None:
        from server.mcp_server import check_spending_limit

        result = await check_spending_limit(amount=10.0, payee="test-shop")
        data = json.loads(result)
        assert isinstance(data, dict)
        # 应包含 allowed 或 error
        assert "allowed" in data or "error" in data

    async def test_check_with_currency(self) -> None:
        from server.mcp_server import check_spending_limit

        result = await check_spending_limit(amount=5.0, payee="shop", currency="EUR")
        data = json.loads(result)
        assert isinstance(data, dict)


# ─── Test 4: fill_payment_form ──────────────────────────────

class TestFillPaymentForm:
    """支付表单填写 tool 测试。"""

    async def test_fill_nonexistent_card(self) -> None:
        """使用不存在的卡应返回错误。"""
        from server.mcp_server import fill_payment_form

        result = await fill_payment_form(
            url="https://example.com",
            card_alias="nonexistent-card",
        )
        data = json.loads(result)
        assert "error" in data or "status" in data

    async def test_fill_dry_run_nonexistent_card(self) -> None:
        """dry_run 模式，卡不存在。"""
        from server.mcp_server import fill_payment_form

        result = await fill_payment_form(
            url="https://example.com",
            card_alias="nonexistent-card",
            dry_run=True,
        )
        data = json.loads(result)
        assert isinstance(data, dict)


# ─── Test 5: MCP HTTP 挂载 ──────────────────────────────────

class TestMCPHTTPMount:
    """HTTP 模式挂载到 FastAPI 测试。"""

    async def test_mcp_endpoint_exists(self) -> None:
        """/mcp 路径已挂载。"""
        from httpx import ASGITransport, AsyncClient

        from server.app import app

        async with AsyncClient(
            transport=ASGITransport(app=app, raise_app_exceptions=False),
            base_url="http://test",
        ) as c:
            # MCP 端点挂载检查 — 发 GET 应该返回非 404
            r = await c.get("/mcp")
            # MCP Streamable HTTP 对 GET 可能返回 405（只支持 POST）
            # 关键是不应该返回 404（说明路由已挂载）
            assert r.status_code != 404


# ─── Test 6: 占位 tool 返回格式 ─────────────────────────────

class TestPlaceholderTools:
    """占位 tool（尚未实现）返回格式正确。"""

    async def test_launch_browser_placeholder(self) -> None:
        from server.mcp_server import launch_browser

        result = await launch_browser(url="https://example.com")
        data = json.loads(result)
        assert data["status"] == "not_yet_implemented"

    async def test_detect_payment_form_placeholder(self) -> None:
        from server.mcp_server import detect_payment_form

        result = await detect_payment_form(url="https://example.com")
        data = json.loads(result)
        assert data["status"] == "not_yet_implemented"

    async def test_execute_checkout_placeholder(self) -> None:
        from server.mcp_server import execute_checkout

        result = await execute_checkout(
            url="https://example.com",
            card_alias="test",
            max_amount=100.0,
        )
        data = json.loads(result)
        assert data["status"] == "not_yet_implemented"

    async def test_evaluate_risk_returns_json(self) -> None:
        from server.mcp_server import evaluate_risk

        result = await evaluate_risk(action="click pay button", category="navigation")
        data = json.loads(result)
        assert isinstance(data, dict)

    async def test_store_card_returns_json(self) -> None:
        from server.mcp_server import store_card

        result = await store_card(card_alias="test-mcp", card_number="4111111111111111")
        data = json.loads(result)
        assert isinstance(data, dict)

    async def test_record_transaction_returns_json(self) -> None:
        from server.mcp_server import record_transaction

        result = await record_transaction(
            amount=19.99,
            currency="USD",
            merchant="test-shop",
        )
        data = json.loads(result)
        assert isinstance(data, dict)
