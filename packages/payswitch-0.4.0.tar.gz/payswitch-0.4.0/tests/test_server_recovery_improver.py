from __future__ import annotations

from fastapi.testclient import TestClient

from payswitch.models.config import PaySwitchConfig
from payswitch.server import (
    app,
    build_recovery_improvement_supervisor_from_env,
)


def test_build_recovery_improvement_supervisor_from_env_defaults_disabled(
    monkeypatch,
) -> None:
    monkeypatch.delenv("PAYSWITCH_RECOVERY_IMPROVER_ENABLED", raising=False)

    supervisor = build_recovery_improvement_supervisor_from_env()

    assert supervisor is None


def test_build_recovery_improvement_supervisor_from_env_supports_enabled_config(
    monkeypatch,
    tmp_path,
) -> None:
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_ENABLED", "1")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_REVIEWER", "watchdog")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_NOTE", "nightly")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_PLATFORM", "kimi")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_FLOW", "membership_monthly_qr")
    monkeypatch.setenv(
        "PAYSWITCH_RECOVERY_IMPROVER_AUTO_ACCEPT_BASIS",
        "shadow_run_success",
    )
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_MIN_SHADOW_RUNS", "2")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_POLL_INTERVAL_SECONDS", "2.5")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_BATCH_LIMIT", "4")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_DRY_RUN", "true")

    supervisor = build_recovery_improvement_supervisor_from_env(
        config_override=PaySwitchConfig(data_dir=tmp_path),
    )

    assert supervisor is not None
    snapshot = supervisor.snapshot()
    assert snapshot["enabled"] is True
    assert snapshot["running"] is False
    assert snapshot["reviewer"] == "watchdog"
    assert snapshot["note"] == "nightly"
    assert snapshot["platform"] == "kimi"
    assert snapshot["flow"] == "membership_monthly_qr"
    assert snapshot["auto_accept_basis"] == "shadow_run_success"
    assert snapshot["min_shadow_runs"] == 2
    assert snapshot["poll_interval_seconds"] == 2.5
    assert snapshot["batch_limit"] == 4
    assert snapshot["dry_run"] is True


def test_recovery_improver_health_endpoint_reports_service_supervision(
    monkeypatch,
    tmp_path,
) -> None:
    config = PaySwitchConfig(data_dir=tmp_path)
    monkeypatch.setattr(PaySwitchConfig, "load", classmethod(lambda cls: config))
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_ENABLED", "1")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_REVIEWER", "watchdog")
    monkeypatch.setenv(
        "PAYSWITCH_RECOVERY_IMPROVER_AUTO_ACCEPT_BASIS",
        "shadow_run_success",
    )
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_MIN_SHADOW_RUNS", "2")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_POLL_INTERVAL_SECONDS", "0.01")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_BATCH_LIMIT", "3")
    monkeypatch.setenv("PAYSWITCH_RECOVERY_IMPROVER_DRY_RUN", "1")

    with TestClient(app) as client:
        recovery = client.get("/api/recovery-improvements/health")
        health = client.get("/api/health")

        assert recovery.status_code == 200
        payload = recovery.json()
        assert payload["enabled"] is True
        assert payload["running"] is True
        assert payload["reviewer"] == "watchdog"
        assert payload["auto_accept_basis"] == "shadow_run_success"
        assert payload["min_shadow_runs"] == 2
        assert payload["batch_limit"] == 3
        assert payload["dry_run"] is True

        assert health.status_code == 200
        health_payload = health.json()
        assert health_payload["recovery_improver"]["enabled"] is True
        assert health_payload["recovery_improver"]["running"] is True
        assert (
            health_payload["recovery_improver"]["auto_accept_basis"]
            == "shadow_run_success"
        )
        assert health_payload["recovery_improver"]["min_shadow_runs"] == 2
