"""Pay-Switch 检测器（DetectorPipeline）异步单元测试。

覆盖范围：
- DetectorPipeline 的初始化（默认检测器集合 / 自定义检测器）
- QRCodeDetector.detect：页面有 QR 码时返回 DetectionResult，无 QR 返回 None
- SensitiveFormDetector.detect：检测到敏感表单时返回结果
- PaymentConfirmDetector.detect：检测到确认按钮时返回结果
- CompletionDetector.detect：检测到成功文本时返回结果
- DetectorPipeline.scan：返回优先级最高的匹配检测器的结果
- 单个检测器异常不影响后续检测器继续执行
- requires_human 返回值校验
- detect_completion 的预期行为

使用 pytest-asyncio 的 asyncio_mode="auto" 配置（pyproject.toml 已设置）。
所有 page.evaluate 调用使用 AsyncMock 模拟。
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from playwright.async_api import async_playwright

from payswitch.browser.detector import (
    CompletionDetector,
    DetectionResult,
    DetectorPipeline,
    PaymentConfirmDetector,
    QRCodeDetector,
    SensitiveFormDetector,
)

# ===========================================================================
# 辅助函数
# ===========================================================================


def _make_page(evaluate_return_value=None) -> AsyncMock:
    """创建模拟 Playwright Page 对象。

    Args:
        evaluate_return_value: page.evaluate() 的返回值
    """
    page = MagicMock()
    page.evaluate = AsyncMock(return_value=evaluate_return_value)
    page.url = "https://example.com/payment"
    return page


# ===========================================================================
# QRCodeDetector 测试
# ===========================================================================


class TestQRCodeDetector:
    """QRCodeDetector 单元测试。"""

    async def test_检测到QR码_返回DetectionResult(self):
        """page.evaluate 返回 found=True 时，detect 应返回 scan_qr 类型的结果。"""
        detector = QRCodeDetector()
        page = _make_page({"found": True, "type": "img", "src": "https://qr.example.com/code.png"})
        result = await detector.detect(page)
        assert result is not None
        assert result.action_type == "scan_qr"
        assert result.detector_name == "QRCodeDetector"
        assert "qr_src" in result.data

    async def test_未检测到QR码_返回None(self):
        """page.evaluate 返回 found=False 时，detect 应返回 None。"""
        detector = QRCodeDetector()
        page = _make_page({"found": False, "type": "", "src": ""})
        result = await detector.detect(page)
        assert result is None

    async def test_page_evaluate异常时返回None(self):
        """page.evaluate 抛出异常时，detect 应捕获并返回 None（不传播异常）。"""
        detector = QRCodeDetector()
        page = MagicMock()
        page.evaluate = AsyncMock(side_effect=Exception("浏览器上下文错误"))
        result = await detector.detect(page)
        assert result is None

    async def test_requires_human返回True(self):
        """扫码操作必须由人类完成，requires_human 应返回 True。"""
        assert QRCodeDetector().requires_human() is True

    async def test_detect_completion_QR消失返回True(self):
        """QR 码消失时（done=True），detect_completion 应返回 True。"""
        detector = QRCodeDetector()
        page = _make_page({"done": True, "reason": "qr_disappeared"})
        result = await detector.detect_completion(page)
        assert result is True

    async def test_detect_completion_QR仍存在返回False(self):
        """QR 码仍然存在时（done=False），detect_completion 应返回 False。"""
        detector = QRCodeDetector()
        page = _make_page({"done": False, "reason": "qr_still_present"})
        result = await detector.detect_completion(page)
        assert result is False

    async def test_detect_completion_异常时返回False(self):
        """detect_completion 内 evaluate 抛出异常时，应返回 False。"""
        detector = QRCodeDetector()
        page = MagicMock()
        page.evaluate = AsyncMock(side_effect=RuntimeError("JS 错误"))
        result = await detector.detect_completion(page)
        assert result is False

    async def test_返回结果包含qr_src和qr_type数据(self):
        """DetectionResult.data 应包含 qr_src 和 qr_type 字段。"""
        detector = QRCodeDetector()
        page = _make_page({
            "found": True,
            "type": "canvas",
            "src": ""
        })
        result = await detector.detect(page)
        assert result is not None
        assert result.data.get("qr_type") == "canvas"

    @pytest.mark.browser
    async def test_真实页面_忽略没有支付语义的首页横幅图(self):
        detector = QRCodeDetector()
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True)
            try:
                page = await browser.new_page()
                await page.set_content(
                    """
                    <main>
                      <h1>Kimi Home</h1>
                      <img
                        src="data:image/png;base64,alipayfakebanner"
                        style="width: 420px; height: 120px; display: block;"
                      />
                    </main>
                    """
                )
                result = await detector.detect(page)
                assert result is None
            finally:
                await browser.close()

    @pytest.mark.browser
    async def test_真实页面_识别带支付语义的二维码(self):
        detector = QRCodeDetector()
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True)
            try:
                page = await browser.new_page()
                await page.set_content(
                    """
                    <section>
                      <p>请使用支付宝扫码支付</p>
                      <img
                        alt="支付宝二维码"
                        src="https://qr.alipay.com/mock-code"
                        style="width: 220px; height: 220px; display: block;"
                      />
                    </section>
                    """
                )
                result = await detector.detect(page)
                assert result is not None
                assert result.action_type == "scan_qr"
                assert result.data.get("qr_type") == "img"
            finally:
                await browser.close()


# ===========================================================================
# SensitiveFormDetector 测试
# ===========================================================================


class TestSensitiveFormDetector:
    """SensitiveFormDetector 单元测试。"""

    async def test_检测到敏感表单_返回DetectionResult(self):
        """page.evaluate 返回 found=True 时，detect 应返回 fill_form 类型的结果。"""
        detector = SensitiveFormDetector()
        page = _make_page({"found": True, "reason": "password_input", "field": ""})
        page.url = "https://pay.example.com/form"
        result = await detector.detect(page)
        assert result is not None
        assert result.action_type == "fill_form"
        assert result.detector_name == "SensitiveFormDetector"

    async def test_未检测到敏感表单_返回None(self):
        """page.evaluate 返回 found=False 时，detect 应返回 None。"""
        detector = SensitiveFormDetector()
        page = _make_page({"found": False, "reason": ""})
        result = await detector.detect(page)
        assert result is None

    async def test_page_evaluate异常时返回None(self):
        """page.evaluate 抛出异常时，detect 应捕获并返回 None。"""
        detector = SensitiveFormDetector()
        page = MagicMock()
        page.evaluate = AsyncMock(side_effect=Exception("DOM 错误"))
        result = await detector.detect(page)
        assert result is None

    async def test_requires_human返回True(self):
        """填写敏感信息必须由人类完成，requires_human 应返回 True。"""
        assert SensitiveFormDetector().requires_human() is True

    async def test_detect_completion_URL变化时返回True(self):
        """URL 从初始值变化时（表单已提交跳转），detect_completion 应返回 True。"""
        detector = SensitiveFormDetector()
        # 先 detect 以记录初始 URL
        page = MagicMock()
        page.evaluate = AsyncMock(return_value={"found": True, "reason": "password_input"})
        page.url = "https://pay.example.com/form"
        await detector.detect(page)
        # URL 已变化
        page.url = "https://pay.example.com/success"
        result = await detector.detect_completion(page)
        assert result is True

    async def test_detect_completion_表单消失时返回True(self):
        """密码框消失时（formGone=True），detect_completion 应返回 True。"""
        detector = SensitiveFormDetector()
        page = MagicMock()
        # 初始化 _initial_url（detect 时会赋值）
        page.evaluate = AsyncMock(return_value={"found": True, "reason": "password_input"})
        page.url = "https://pay.example.com/form"
        await detector.detect(page)
        # URL 未变，但密码框已消失
        page.evaluate = AsyncMock(return_value={"formGone": True})
        result = await detector.detect_completion(page)
        assert result is True

    async def test_detect_结果包含reason和field(self):
        """DetectionResult.data 应包含 reason 和 field 字段。"""
        detector = SensitiveFormDetector()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value={
            "found": True,
            "reason": "card_input",
            "field": "card_number"
        })
        page.url = "https://pay.example.com"
        result = await detector.detect(page)
        assert result is not None
        assert result.data.get("reason") == "card_input"
        assert result.data.get("field") == "card_number"

    @pytest.mark.browser
    async def test_真实页面_登录表单密码框不应误判为支付表单(self):
        detector = SensitiveFormDetector()
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True)
            try:
                page = await browser.new_page()
                await page.goto("data:text/html,<html><body></body></html>")
                await page.set_content(
                    """
                    <main>
                      <h1>DeepSeek Platform</h1>
                      <form>
                        <label>Phone number</label>
                        <input type="tel" placeholder="Phone number" />
                        <label>Password login</label>
                        <input type="password" placeholder="Password" />
                        <button type="submit">Log in</button>
                      </form>
                    </main>
                    """
                )
                result = await detector.detect(page)
                assert result is None
            finally:
                await browser.close()

    @pytest.mark.browser
    async def test_真实页面_支付密码框仍应识别(self):
        detector = SensitiveFormDetector()
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True)
            try:
                page = await browser.new_page()
                await page.goto("data:text/html,<html><body></body></html>")
                await page.set_content(
                    """
                    <section>
                      <h1>收银台</h1>
                      <label>支付密码</label>
                      <input type="password" placeholder="请输入支付密码" />
                      <p>请完成支付</p>
                    </section>
                    """
                )
                result = await detector.detect(page)
                assert result is not None
                assert result.action_type == "fill_form"
                assert result.data.get('reason') == "password_input"
            finally:
                await browser.close()


# ===========================================================================
# PaymentConfirmDetector 测试
# ===========================================================================


class TestPaymentConfirmDetector:
    """PaymentConfirmDetector 单元测试。"""

    async def test_检测到确认按钮_返回DetectionResult(self):
        """page.evaluate 返回 found=True 时，detect 应返回 confirm 类型的结果。"""
        detector = PaymentConfirmDetector()
        page = _make_page({"found": True, "text": "确认支付", "tag": "BUTTON"})
        page.url = "https://checkout.example.com"
        result = await detector.detect(page)
        assert result is not None
        assert result.action_type == "confirm"
        assert result.detector_name == "PaymentConfirmDetector"

    async def test_未检测到确认按钮_返回None(self):
        """page.evaluate 返回 found=False 时，detect 应返回 None。"""
        detector = PaymentConfirmDetector()
        page = _make_page({"found": False, "text": "", "tag": ""})
        result = await detector.detect(page)
        assert result is None

    async def test_page_evaluate异常时返回None(self):
        """page.evaluate 抛出异常时，detect 应捕获并返回 None。"""
        detector = PaymentConfirmDetector()
        page = MagicMock()
        page.evaluate = AsyncMock(side_effect=RuntimeError("浏览器崩溃"))
        result = await detector.detect(page)
        assert result is None

    async def test_requires_human返回True(self):
        """支付确认需要人类点击，requires_human 应返回 True。"""
        assert PaymentConfirmDetector().requires_human() is True

    async def test_detect_completion_URL变化时返回True(self):
        """URL 变化时，detect_completion 应返回 True。"""
        detector = PaymentConfirmDetector()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value={"found": True, "text": "立即支付", "tag": "BUTTON"})
        page.url = "https://checkout.example.com"
        await detector.detect(page)
        # 页面已跳转
        page.url = "https://success.example.com"
        result = await detector.detect_completion(page)
        assert result is True

    async def test_detect_completion_按钮消失时返回True(self):
        """确认按钮消失时（buttonGone=True），detect_completion 应返回 True。"""
        detector = PaymentConfirmDetector()
        page = MagicMock()
        page.evaluate = AsyncMock(return_value={"found": True, "text": "去支付", "tag": "BUTTON"})
        page.url = "https://checkout.example.com"
        await detector.detect(page)
        # URL 未变，但按钮已消失
        page.evaluate = AsyncMock(return_value={"buttonGone": True})
        result = await detector.detect_completion(page)
        assert result is True

    async def test_description包含按钮文本(self):
        """DetectionResult.description 应包含检测到的按钮文本。"""
        detector = PaymentConfirmDetector()
        page = _make_page({"found": True, "text": "去支付", "tag": "BUTTON"})
        page.url = "https://example.com"
        result = await detector.detect(page)
        assert result is not None
        assert "去支付" in result.description


# ===========================================================================
# CompletionDetector 测试
# ===========================================================================


class TestCompletionDetector:
    """CompletionDetector 单元测试。"""

    async def test_检测到成功文本_返回DetectionResult(self):
        """page.evaluate 返回 found=True 时，detect 应返回 completed 类型的结果。"""
        detector = CompletionDetector()
        page = _make_page({
            "found": True,
            "reason": "success_text",
            "matched": "支付成功"
        })
        result = await detector.detect(page)
        assert result is not None
        assert result.action_type == "completed"
        assert result.detector_name == "CompletionDetector"

    async def test_未检测到成功状态_返回None(self):
        """page.evaluate 返回 found=False 时，detect 应返回 None。"""
        detector = CompletionDetector()
        page = _make_page({"found": False, "reason": "", "matched": ""})
        result = await detector.detect(page)
        assert result is None

    async def test_page_evaluate异常时返回None(self):
        """page.evaluate 抛出异常时，detect 应捕获并返回 None。"""
        detector = CompletionDetector()
        page = MagicMock()
        page.evaluate = AsyncMock(side_effect=Exception("脚本超时"))
        result = await detector.detect(page)
        assert result is None

    async def test_requires_human返回False(self):
        """支付完成状态不需要人类介入，requires_human 应返回 False。"""
        assert CompletionDetector().requires_human() is False

    async def test_detect_completion始终返回True(self):
        """CompletionDetector.detect_completion 不依赖 page，始终返回 True。"""
        detector = CompletionDetector()
        page = MagicMock()
        result = await detector.detect_completion(page)
        assert result is True

    async def test_成功图标也能触发检测(self):
        """检测到成功图标时（reason=success_icon），也应返回正确结果。"""
        detector = CompletionDetector()
        page = _make_page({
            "found": True,
            "reason": "success_icon",
            "matched": "success-icon"
        })
        result = await detector.detect(page)
        assert result is not None
        assert result.data.get("reason") == "success_icon"

    def test_完成图标检测不使用宽泛class子串匹配(self):
        """避免 autocomplete 等普通收银台 class 被 complete 子串误判为成功。"""
        js = CompletionDetector._JS_DETECT
        assert '[class*="complete"]' not in js
        assert "startsWith('complete-')" in js


# ===========================================================================
# DetectorPipeline 测试
# ===========================================================================


class TestDetectorPipeline:
    """DetectorPipeline 单元测试。"""

    def test_默认初始化包含4个内置检测器(self):
        """默认 pipeline 应包含 4 个内置检测器，按优先级排列。"""
        pipeline = DetectorPipeline()
        assert len(pipeline._detectors) == 4
        # 验证优先级顺序
        names = [d.name for d in pipeline._detectors]
        assert names[0] == "CompletionDetector"    # 最高优先级
        assert names[1] == "QRCodeDetector"
        assert names[2] == "SensitiveFormDetector"
        assert names[3] == "PaymentConfirmDetector"

    def test_自定义检测器列表初始化(self):
        """传入自定义检测器列表时，应使用自定义列表而非默认列表。"""
        custom_detectors = [QRCodeDetector(), CompletionDetector()]
        pipeline = DetectorPipeline(detectors=custom_detectors)
        assert len(pipeline._detectors) == 2
        assert pipeline._detectors[0].name == "QRCodeDetector"

    async def test_scan_返回第一个匹配检测器的结果(self):
        """scan 应按顺序运行检测器，返回第一个匹配的结果。"""
        # QRCode 排第一，Completion 排第二，scan 应返回 QRCode 的结果
        qr_detector = AsyncMock(spec=QRCodeDetector)
        qr_detector.name = "QRCodeDetector"
        qr_result = DetectionResult(
            detector_name="QRCodeDetector",
            action_type="scan_qr",
            description="检测到二维码",
        )
        qr_detector.detect = AsyncMock(return_value=qr_result)

        completion_detector = AsyncMock(spec=CompletionDetector)
        completion_detector.name = "CompletionDetector"
        completion_detector.detect = AsyncMock(return_value=None)

        pipeline = DetectorPipeline(detectors=[completion_detector, qr_detector])
        # completion 先运行但返回 None，qr 返回结果
        page = MagicMock()
        result = await pipeline.scan(page)
        assert result is not None
        assert result.action_type == "scan_qr"

    async def test_scan_所有检测器均未匹配时返回None(self):
        """所有检测器 detect 均返回 None 时，scan 应返回 None。"""
        d1 = AsyncMock()
        d1.name = "Detector1"
        d1.detect = AsyncMock(return_value=None)
        d2 = AsyncMock()
        d2.name = "Detector2"
        d2.detect = AsyncMock(return_value=None)

        pipeline = DetectorPipeline(detectors=[d1, d2])
        page = MagicMock()
        result = await pipeline.scan(page)
        assert result is None

    async def test_scan_单个检测器异常不影响后续检测器(self):
        """某个检测器 detect 抛出异常时，pipeline 应跳过该检测器，继续运行后续检测器。"""
        # 第一个检测器抛异常
        d_fail = AsyncMock()
        d_fail.name = "FailingDetector"
        d_fail.detect = AsyncMock(side_effect=RuntimeError("检测器崩溃"))

        # 第二个检测器正常返回结果
        qr_result = DetectionResult(
            detector_name="QRCodeDetector",
            action_type="scan_qr",
            description="QR 码",
        )
        d_ok = AsyncMock()
        d_ok.name = "QRCodeDetector"
        d_ok.detect = AsyncMock(return_value=qr_result)

        pipeline = DetectorPipeline(detectors=[d_fail, d_ok])
        page = MagicMock()
        result = await pipeline.scan(page)
        # 第二个检测器的结果应被返回
        assert result is not None
        assert result.action_type == "scan_qr"

    async def test_scan_CompletionDetector优先于QRCode(self):
        """scan 遵循优先级：CompletionDetector 排在 QRCodeDetector 前，成功状态优先返回。"""
        pipeline = DetectorPipeline()
        # 模拟：页面同时有成功状态和 QR 码（理论上不会同时存在，但测试优先级逻辑）
        page = MagicMock()

        # evaluate 调用次数对应不同检测器，首次调用返回 completion
        page.evaluate = AsyncMock(return_value={
            "found": True, "reason": "success_text", "matched": "支付成功"
        })
        result = await pipeline.scan(page)
        assert result is not None
        # CompletionDetector 先执行，应返回 completed
        assert result.action_type == "completed"

    def test_find_detector按名称查找(self):
        """_find_detector 应能按 name 找到对应检测器实例。"""
        pipeline = DetectorPipeline()
        detector = pipeline._find_detector("QRCodeDetector")
        assert detector is not None
        assert detector.name == "QRCodeDetector"

    def test_find_detector_不存在的名称返回None(self):
        """_find_detector 查找不存在的名称时应返回 None。"""
        pipeline = DetectorPipeline()
        result = pipeline._find_detector("NonExistentDetector")
        assert result is None

    async def test_wait_for_completion_找不到检测器返回False(self):
        """result.detector_name 不在 pipeline 中时，wait_for_completion 应返回 False。"""
        pipeline = DetectorPipeline(detectors=[QRCodeDetector()])
        result = DetectionResult(
            detector_name="GhostDetector",
            action_type="scan_qr",
            description="幽灵检测器",
        )
        page = MagicMock()
        outcome = await pipeline.wait_for_completion(page, result, timeout=1)
        assert outcome is False


# ===========================================================================
# DetectionResult 模型测试
# ===========================================================================


class TestDetectionResult:
    """DetectionResult 数据模型测试。"""

    def test_基本创建(self):
        """验证 DetectionResult 能正确创建并携带必要字段。"""
        result = DetectionResult(
            detector_name="QRCodeDetector",
            action_type="scan_qr",
            description="请扫码",
        )
        assert result.detector_name == "QRCodeDetector"
        assert result.action_type == "scan_qr"
        assert result.description == "请扫码"
        assert result.data == {}

    def test_data字段默认为空字典(self):
        """data 字段未传入时默认为空字典。"""
        result = DetectionResult(
            detector_name="CompletionDetector",
            action_type="completed",
            description="支付完成",
        )
        assert result.data == {}

    def test_data字段可携带任意数据(self):
        """data 字段应能携带任意键值对。"""
        result = DetectionResult(
            detector_name="QRCodeDetector",
            action_type="scan_qr",
            description="请扫码",
            data={"qr_src": "https://qr.example.com/img.png", "qr_type": "img"},
        )
        assert result.data["qr_src"] == "https://qr.example.com/img.png"
        assert result.data["qr_type"] == "img"
