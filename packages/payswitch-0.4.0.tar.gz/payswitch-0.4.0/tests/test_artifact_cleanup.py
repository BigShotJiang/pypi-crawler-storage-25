from __future__ import annotations

from pathlib import Path

from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore
from payswitch.security.cleanup import ArtifactCleanupRunner


def test_artifact_cleanup_dry_run_preserves_expired_files(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "external" / "tx-1.json"
    store.write_json(
        artifact_path,
        {"tx_id": "txn_cleanup_1"},
        artifact_kind="external_debug",
        sensitivity=ArtifactSensitivity.internal,
        retention_hours=0,
    )

    results = store.cleanup_expired(dry_run=True)

    assert [entry["action"] for entry in results] == ["would_delete"]
    assert artifact_path.exists()
    assert store.metadata_path(artifact_path).exists()


def test_artifact_cleanup_deletes_expired_artifact_and_metadata(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "recovery" / "tx-2.json"
    store.write_json(
        artifact_path,
        {"tx_id": "txn_cleanup_2"},
        artifact_kind="recovery_checkpoint",
        sensitivity=ArtifactSensitivity.sensitive,
        retention_hours=0,
    )

    results = store.cleanup_expired()

    assert [entry["action"] for entry in results] == ["deleted"]
    assert not artifact_path.exists()
    assert not store.metadata_path(artifact_path).exists()


def test_artifact_cleanup_runner_stops_after_idle_polls(tmp_path: Path) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "external" / "tx-3.json"
    store.write_json(
        artifact_path,
        {"tx_id": "txn_cleanup_3"},
        artifact_kind="external_debug",
        sensitivity=ArtifactSensitivity.internal,
        retention_hours=0,
    )
    sleep_calls: list[float] = []
    runner = ArtifactCleanupRunner(
        store,
        poll_interval_seconds=0.0,
        batch_limit=10,
        max_idle_polls=2,
        sleep_fn=sleep_calls.append,
    )

    summary = runner.run_loop()

    assert summary["cycles"] == 3
    assert summary["idle_polls"] == 2
    assert summary["total_cleaned"] == 1
    assert summary["total_deleted"] == 1
    assert summary["total_metadata_only"] == 0
    assert sleep_calls == []
