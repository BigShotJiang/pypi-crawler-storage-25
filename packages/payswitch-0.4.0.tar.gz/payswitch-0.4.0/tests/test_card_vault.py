from __future__ import annotations

from types import SimpleNamespace

import pytest

from payswitch.security import card_vault
from payswitch.security.card_vault import (
    BillingAddress,
    VirtualCardData,
    delete_virtual_card,
    load_virtual_card,
    normalize_pan,
    store_card_number,
    store_virtual_card,
)
from payswitch.security.redaction import redact_sensitive_data, redact_sensitive_text


def test_normalize_pan_accepts_luhn_valid_card() -> None:
    assert normalize_pan("4242 4242 4242 4242") == "4242424242424242"


def test_normalize_pan_rejects_invalid_card() -> None:
    with pytest.raises(ValueError):
        normalize_pan("4242 4242 4242 4241")


def test_store_card_number_uses_keyring_without_returning_plain_pan(monkeypatch) -> None:
    calls = {}

    fake_keyring = SimpleNamespace(
        set_password=lambda service, key, value: calls.update(
            {"service": service, "key": key, "value": value}
        )
    )
    monkeypatch.setattr(card_vault, "_load_keyring", lambda: fake_keyring)

    masked = store_card_number("payswitch/card/test/pan", "4242 4242 4242 4242")

    assert masked == "424242******4242"
    assert calls == {
        "service": card_vault.SERVICE_NAME,
        "key": "payswitch/card/test/pan",
        "value": "4242424242424242",
    }


def test_redact_sensitive_text_masks_luhn_valid_pan() -> None:
    redacted = redact_sensitive_text("card=4242 4242 4242 4242")

    assert "4242 4242 4242 4242" not in redacted
    assert "[REDACTED_PAN:424242******4242]" in redacted


def test_redact_sensitive_data_recurses() -> None:
    payload = {
        "action": {"value": "4242424242424242"},
        "safe": "order 1234567890123",
    }

    redacted = redact_sensitive_data(payload)

    assert redacted["action"]["value"] == "[REDACTED_PAN:424242******4242]"
    assert redacted["safe"] == "order 1234567890123"


# ============================================================================
# VirtualCardData 存取测试
# ============================================================================


class TestVirtualCardVault:
    """虚拟卡 Vault 新 API 测试。"""

    def test_store_and_load_virtual_card(self, monkeypatch) -> None:
        """存储 VirtualCardData 后 load 能拿到完整数据。"""
        storage: dict[str, str] = {}

        fake_keyring = SimpleNamespace(
            set_password=lambda svc, key, val: storage.update({f"{svc}/{key}": val}),
            get_password=lambda svc, key: storage.get(f"{svc}/{key}"),
        )
        monkeypatch.setattr(card_vault, "_load_keyring", lambda: fake_keyring)

        card_data = VirtualCardData(
            card_number="4242424242424242",
            expiry_month="04",
            expiry_year="31",
            cvv="625",
            holder_name="Loki White",
        )
        masked = store_virtual_card("test/ref", card_data)
        assert "4242" in masked  # 返回脱敏后的卡号

        loaded = load_virtual_card("test/ref")
        assert loaded is not None
        assert loaded.card_number == "4242424242424242"
        assert loaded.expiry_month == "04"
        assert loaded.expiry_year == "31"
        assert loaded.cvv == "625"
        assert loaded.holder_name == "Loki White"

    def test_store_virtual_card_with_billing_address(self, monkeypatch) -> None:
        """含账单地址的虚拟卡完整往返。"""
        storage: dict[str, str] = {}

        fake_keyring = SimpleNamespace(
            set_password=lambda svc, key, val: storage.update({f"{svc}/{key}": val}),
            get_password=lambda svc, key: storage.get(f"{svc}/{key}"),
        )
        monkeypatch.setattr(card_vault, "_load_keyring", lambda: fake_keyring)

        card_data = VirtualCardData(
            card_number="4242424242424242",
            expiry_month="04",
            expiry_year="31",
            cvv="625",
            holder_name="Loki White",
            billing_address=BillingAddress(
                line1="951 Brickell Ave 2800",
                city="Miami",
                state="FL",
                postal_code="33131",
                country="US",
            ),
        )
        store_virtual_card("test/ref", card_data)

        loaded = load_virtual_card("test/ref")
        assert loaded is not None
        assert loaded.billing_address is not None
        assert loaded.billing_address.line1 == "951 Brickell Ave 2800"
        assert loaded.billing_address.city == "Miami"
        assert loaded.billing_address.state == "FL"
        assert loaded.billing_address.postal_code == "33131"
        assert loaded.billing_address.country == "US"

    def test_delete_virtual_card(self, monkeypatch) -> None:
        """删除后 load 返回 None。"""
        storage: dict[str, str] = {}

        fake_keyring = SimpleNamespace(
            set_password=lambda svc, key, val: storage.update({f"{svc}/{key}": val}),
            get_password=lambda svc, key: storage.get(f"{svc}/{key}"),
            delete_password=lambda svc, key: storage.pop(f"{svc}/{key}", None),
        )
        monkeypatch.setattr(card_vault, "_load_keyring", lambda: fake_keyring)

        card_data = VirtualCardData(card_number="4242424242424242")
        store_virtual_card("test/ref", card_data)
        assert load_virtual_card("test/ref") is not None

        delete_virtual_card("test/ref")
        assert load_virtual_card("test/ref") is None

    def test_load_virtual_card_返回None_不crash(self, monkeypatch) -> None:
        """load_virtual_card 找不到数据时应返回 None。"""
        fake_keyring = SimpleNamespace(
            get_password=lambda svc, key: None,
        )
        monkeypatch.setattr(card_vault, "_load_keyring", lambda: fake_keyring)

        result = load_virtual_card("nonexistent/ref")
        assert result is None
