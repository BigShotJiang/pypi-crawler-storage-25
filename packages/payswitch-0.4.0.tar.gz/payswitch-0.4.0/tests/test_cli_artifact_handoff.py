from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from payswitch.cli import app
from payswitch.security.artifacts import ArtifactSensitivity, ArtifactStore


def test_artifact_inbox_cli_can_show_public_key(tmp_path: Path, monkeypatch) -> None:
    store = ArtifactStore(tmp_path)
    monkeypatch.setattr("payswitch.cli._artifact_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(app, ["--json", "artifact", "inbox", "--include-public-key"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["recipient_id"]
    assert payload["public_key"]


def test_artifact_export_and_import_cli_round_trip(tmp_path: Path, monkeypatch) -> None:
    source_store = ArtifactStore(tmp_path / "source")
    target_store = ArtifactStore(tmp_path / "target")
    artifact_path = tmp_path / "source" / "evidence" / "external" / "shot.png"
    source_store.write_bytes(
        artifact_path,
        b"\x89PNG\r\ncli",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
        metadata={"tx_id": "txn_cli_handoff"},
    )
    monkeypatch.setattr("payswitch.cli._artifact_store_from_config", lambda: source_store)
    recipient_public_key = target_store.local_inbox_summary(include_public_key=True)["public_key"]
    bundle_path = tmp_path / "bundle.json"

    runner = CliRunner()
    export_result = runner.invoke(
        app,
        [
            "--json",
            "artifact",
            "export",
            "--path",
            str(artifact_path),
            "--recipient-public-key",
            recipient_public_key,
            "--output",
            str(bundle_path),
        ],
    )

    assert export_result.exit_code == 0
    export_payload = json.loads(export_result.stdout)
    assert export_payload["bundle_path"] == str(bundle_path)
    assert bundle_path.exists()

    monkeypatch.setattr("payswitch.cli._artifact_store_from_config", lambda: target_store)
    imported_path = tmp_path / "target" / "imported" / "shot.png"
    import_result = runner.invoke(
        app,
        [
            "--json",
            "artifact",
            "import",
            "--bundle",
            str(bundle_path),
            "--path",
            str(imported_path),
        ],
    )

    assert import_result.exit_code == 0
    import_payload = json.loads(import_result.stdout)
    assert import_payload["imported_path"] == str(imported_path)
    assert target_store.read_bytes(imported_path) == b"\x89PNG\r\ncli"
    assert import_payload["metadata"]["tx_id"] == "txn_cli_handoff"


def test_artifact_rotate_inbox_cli_reencrypts_sensitive_artifacts(
    tmp_path: Path,
    monkeypatch,
) -> None:
    store = ArtifactStore(tmp_path)
    artifact_path = tmp_path / "evidence" / "external" / "shot.png"
    store.write_bytes(
        artifact_path,
        b"\x89PNG\r\nrotate-cli",
        artifact_kind="external_observation_screenshot",
        sensitivity=ArtifactSensitivity.sensitive,
        content_type="image/png",
    )
    monkeypatch.setattr("payswitch.cli._artifact_store_from_config", lambda: store)

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "--json",
            "artifact",
            "rotate-inbox",
            "--reencrypt-existing",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["rotated_artifacts"] == 1
    assert store.read_bytes(artifact_path) == b"\x89PNG\r\nrotate-cli"
