import { describe, expect, it } from "vitest";

import { buildEventStreamUrl, parseStreamMessage } from "./eventStream";

describe("eventStream", () => {
  it("normalizes backend stream payloads into UI session events", () => {
    const event = parseStreamMessage(
      JSON.stringify({
        id: "evt_backend_1",
        ts: "2026-05-12T10:52:03Z",
        type: "action.allowed",
        summary: "允许点击充值按钮",
        message: "Guard 允许低风险点击，BrowserController 已执行。",
        source: "pay_switch",
        path: ["Codex", "Pay-Switch", "Browser", "DeepSeek"],
        risk: "medium",
        target: "button:充值",
        current_url: "https://platform.deepseek.com/topup",
        screenshot_url: "http://localhost:8787/evidence?path=/tmp/shot.png",
        qr_artifact_url: "http://localhost:8787/evidence?path=/tmp/qr.png",
        detected_payment_methods: ["alipay_qr"],
        interaction_hints: [{ kind: "requires_login", blocking: true }],
      }),
      4,
    );

    expect(event).toEqual({
      id: "evt_backend_1",
      at: "10:52:03",
      kind: "action_allowed",
      title: "允许点击充值按钮",
      detail: "Guard 允许低风险点击，BrowserController 已执行。",
      actor: "payswitch",
      path: "Codex / Pay-Switch / Browser / DeepSeek",
      risk: "medium",
      target: "button:充值",
      currentUrl: "https://platform.deepseek.com/topup",
      screenshotUrl: "http://localhost:8787/evidence?path=/tmp/shot.png",
      qrArtifactUrl: "http://localhost:8787/evidence?path=/tmp/qr.png",
      paymentMethods: ["alipay_qr"],
      interactionHints: [{ kind: "requires_login", blocking: true }],
    });
  });

  it("rejects malformed stream payloads instead of corrupting the timeline", () => {
    expect(() => parseStreamMessage("{\"type\":\"unknown.event\"}", 1)).toThrow(
      "Unsupported event kind",
    );
  });

  it("builds session-scoped SSE urls without losing existing query params", () => {
    expect(buildEventStreamUrl("http://localhost:8787/events?token=dev", "txn_123")).toBe(
      "http://localhost:8787/events?token=dev&session_id=txn_123",
    );
  });

  it("can scope the SSE stream to the current user workspace", () => {
    expect(
      buildEventStreamUrl("http://localhost:8787/events?token=dev", "txn_123", {
        userId: "alice",
      }),
    ).toBe("http://localhost:8787/events?token=dev&session_id=txn_123&user_id=alice");
  });

  // 新增：解析 tool_call_start 事件
  it("parses tool_call_start event from backend stream", () => {
    const event = parseStreamMessage(
      JSON.stringify({
        id: "evt-tc1",
        at: "10:30:05",
        kind: "tool_call_start",
        title: "调用工具: fill_payment_form",
        detail: '{"url": "https://example.com/checkout"}',
        actor: "payswitch",
        path: "Codex / Pay-Switch",
        target: "fill_payment_form",
      }),
      10,
    );

    expect(event.kind).toBe("tool_call_start");
    expect(event.target).toBe("fill_payment_form");
    expect(event.actor).toBe("payswitch");
  });

  // 新增：解析 tool_call_end 事件
  it("parses tool_call_end event from backend stream", () => {
    const event = parseStreamMessage(
      JSON.stringify({
        kind: "tool_call_end",
        title: "工具返回: fill_payment_form",
        detail: '{"status": "ok", "fields_filled": 4}',
        actor: "payswitch",
        path: "Codex / Pay-Switch",
        target: "fill_payment_form",
      }),
      11,
    );

    expect(event.kind).toBe("tool_call_end");
  });

  // 新增：解析 auth_required 事件
  it("parses auth_required event from backend stream", () => {
    const event = parseStreamMessage(
      JSON.stringify({
        kind: "auth_required",
        title: "需要 3DS 认证",
        detail: "银行要求额外验证",
        actor: "browser",
        path: "Codex / Pay-Switch / Browser",
      }),
      12,
    );

    expect(event.kind).toBe("auth_required");
  });

  // 新增：解析 failed / canceled 事件
  it("parses failed and canceled events from backend stream", () => {
    const failed = parseStreamMessage(
      JSON.stringify({ kind: "failed", title: "任务失败", actor: "payswitch" }),
      13,
    );
    expect(failed.kind).toBe("failed");

    const canceled = parseStreamMessage(
      JSON.stringify({ kind: "canceled", title: "任务取消", actor: "human" }),
      14,
    );
    expect(canceled.kind).toBe("canceled");
  });

  // 新增：解析使用 dot 分隔符的新事件类型
  it("parses dot-separated new event kinds", () => {
    const event = parseStreamMessage(
      JSON.stringify({ type: "tool_call.start", summary: "调用工具", source: "payswitch" }),
      15,
    );
    expect(event.kind).toBe("tool_call_start");

    const authEvt = parseStreamMessage(
      JSON.stringify({ type: "auth.required", summary: "需要认证", source: "browser" }),
      16,
    );
    expect(authEvt.kind).toBe("auth_required");
  });

  it("parses subagent harness and secret delivery events", () => {
    const workspace = parseStreamMessage(
      JSON.stringify({
        type: "workspace.acquired",
        summary: "Workspace acquired",
        source: "pay_switch",
        sequence: 3,
      }),
      17,
    );
    expect(workspace.kind).toBe("workspace_acquired");
    expect(workspace.sequence).toBe(3);

    const secret = parseStreamMessage(
      JSON.stringify({
        type: "secret.delivered",
        summary: "Encrypted secret delivered",
        source: "pay_switch",
      }),
      18,
    );
    expect(secret.kind).toBe("secret_delivered");
  });

  it("parses media persisted events with downloadable recording artifacts", () => {
    const event = parseStreamMessage(
      JSON.stringify({
        type: "media.persisted",
        summary: "录屏已归档",
        source: "pay_switch",
        media_artifacts: [
          {
            artifact_id: "capture_webm",
            recording_index: 2,
            name: "capture.webm",
            content_type: "video/webm",
            recording_source: "observation_screenshots",
            capture_engine: "ffmpeg_replay",
            duration_seconds: 1.0,
            frame_rate: 1.0,
            source_screenshot_count: 1,
            bit_rate: 800000,
            frame_width: 1280,
            frame_height: 720,
            codec_name: "mpeg4",
            size_bytes: 2048,
            download_url: "/api/sessions/psw_kimi/artifacts/capture_webm",
          },
        ],
      }),
      19,
    );

    expect(event.kind).toBe("media_persisted");
    expect(event.mediaArtifacts).toEqual([
      {
        artifactId: "capture_webm",
        recordingIndex: 2,
        name: "capture.webm",
        contentType: "video/webm",
        recordingSource: "observation_screenshots",
        captureEngine: "ffmpeg_replay",
        durationSeconds: 1,
        frameRate: 1,
        sourceScreenshotCount: 1,
        bitRate: 800000,
        frameWidth: 1280,
        frameHeight: 720,
        codecName: "mpeg4",
        sizeBytes: 2048,
        downloadUrl: "/api/sessions/psw_kimi/artifacts/capture_webm",
      },
    ]);
  });

  it("can disable historical event replay after a ledger snapshot is loaded", () => {
    expect(
      buildEventStreamUrl("http://localhost:8787/events?token=dev", "txn_123", {
        replay: false,
      }),
    ).toBe("http://localhost:8787/events?token=dev&session_id=txn_123&replay=0");
  });

  it("can resume a stream from the last acknowledged sequence", () => {
    expect(
      buildEventStreamUrl("http://localhost:8787/events?token=dev", "txn_123", {
        afterSequence: 42,
      }),
    ).toBe("http://localhost:8787/events?token=dev&session_id=txn_123&after=42");
  });

  it("ignores raw novnc_url unless backend already mapped display_url", () => {
    const event = parseStreamMessage(
      JSON.stringify({
        kind: "human.gate",
        summary: "已交付扫码付款",
        actor: "pay_switch",
        novnc_url: "https://panel.example/vnc.html?autoconnect=true",
      }),
      20,
    );

    expect(event.displayUrl).toBeUndefined();
  });
});
