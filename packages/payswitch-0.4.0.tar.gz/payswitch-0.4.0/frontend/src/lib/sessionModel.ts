export type AgentSource = "codex" | "claude" | "payswitch" | "browser" | "human" | "ledger";

export type EventKind =
  | "intent_received"
  | "guard_passed"
  | "route_selected"
  | "observe"
  | "action_proposed"
  | "action_allowed"
  | "action_blocked"
  | "detection"
  | "human_gate"
  | "completed"
  | "workspace_acquired"
  | "secret_delivered"
  | "media_persisted"
  // 新增：工具调用 + A2A 扩展状态
  | "tool_call_start"
  | "tool_call_end"
  | "auth_required"
  | "failed"
  | "canceled";

export interface SessionMediaArtifact {
  artifactId?: string;
  recordingIndex?: number;
  name?: string;
  kind?: string;
  contentType?: string;
  downloadUrl?: string;
  recordingSource?: string;
  sizeBytes?: number;
  captureEngine?: string;
  durationSeconds?: number;
  frameRate?: number;
  sourceScreenshotCount?: number;
  bitRate?: number;
  frameWidth?: number;
  frameHeight?: number;
  codecName?: string;
}

export type PaymentStageId =
  | "intent"
  | "guard"
  | "routing"
  | "browser"
  | "authorization"
  | "settlement";

export type EventRisk = "low" | "medium" | "high";

export interface SessionEvent {
  id: string;
  sequence?: number;
  at: string;
  kind: EventKind;
  title: string;
  detail: string;
  actor: AgentSource;
  path: string;
  risk?: EventRisk;
  target?: string;
  merchant?: string;
  amount?: number;
  currency?: string;
  reason?: string;
  currentUrl?: string;
  screenshotUrl?: string;
  screenshotPath?: string;
  qrArtifactUrl?: string;
  qrArtifactPath?: string;
  displayUrl?: string;
  mediaArtifacts?: SessionMediaArtifact[];
  paymentMethods?: string[];
  interactionHints?: Array<Record<string, unknown>>;
}

export interface PaymentStage {
  id: PaymentStageId;
  label: string;
  description: string;
}

export interface SessionSummary {
  allowedActions: number;
  blockedActions: number;
  humanGates: number;
  detections: number;
  toolCalls: number;
}

export interface CheckoutSession {
  id: string;
  agent: "Codex" | "Claude Code";
  merchant: string;
  amount: number;
  currency: string;
  reason: string;
  status: "idle" | "running" | "waiting_human" | "completed"
    | "submitted" | "input_required" | "auth_required" | "failed" | "canceled";
  startedAt: string;
  userId?: string;
  workspaceId?: string;
  subagentSessionId?: string;
  siteId?: string;
  siteLockId?: string;
  profileId?: string;
  browserContextId?: string;
  runtimeStatus?: string;
  displayState?: string;
  displayReady?: boolean;
  displayReason?: string;
  displaySurfaceId?: string;
  displayOwnerTaskId?: string;
  displayRouteToken?: string;
  displaySelectedAt?: string;
  displayUrl?: string;
  currentStage: PaymentStageId;
  events: SessionEvent[];
  summary: SessionSummary;
}

export interface InitialSessionOptions {
  id?: string;
  agent?: CheckoutSession["agent"];
  merchant?: string;
  amount?: number;
  currency?: string;
  reason?: string;
  startedAt?: string;
}

export const paymentStages: PaymentStage[] = [
  {
    id: "intent",
    label: "意图接入",
    description: "Codex 或 Claude Code 将花钱请求交给 Pay-Switch。",
  },
  {
    id: "guard",
    label: "风控检查",
    description: "额度、白名单、幂等键和敏感动作边界。",
  },
  {
    id: "routing",
    label: "能力路由",
    description: "优先协议能力，其次 adapter、经验库、Computer Use。",
  },
  {
    id: "browser",
    label: "受控执行",
    description: "外部 Agent 提议动作，Pay-Switch 决定是否执行。",
  },
  {
    id: "authorization",
    label: "已交付人工授权",
    description: "自动化到此结束；二维码、CVV、OTP、支付密码和最终确认交给用户。",
  },
  {
    id: "settlement",
    label: "完成入账",
    description: "检测结果、保存证据、写入 ledger。",
  },
];

const stageByEvent: Record<EventKind, PaymentStageId> = {
  intent_received: "intent",
  guard_passed: "guard",
  route_selected: "routing",
  observe: "browser",
  action_proposed: "browser",
  action_allowed: "browser",
  action_blocked: "browser",
  detection: "browser",
  human_gate: "authorization",
  completed: "settlement",
  workspace_acquired: "routing",
  secret_delivered: "settlement",
  media_persisted: "settlement",
  // 新增
  tool_call_start: "browser",
  tool_call_end: "browser",
  auth_required: "authorization",
  failed: "settlement",
  canceled: "settlement",
};

export function buildInitialSession(options: InitialSessionOptions = {}): CheckoutSession {
  return {
    id: options.id ?? "txn_live_0428",
    agent: options.agent ?? "Codex",
    merchant: options.merchant ?? "Pay-Switch",
    amount: options.amount ?? 0,
    currency: options.currency ?? "CNY",
    reason: options.reason ?? "等待真实 Pay-Switch 事件",
    status: "idle",
    startedAt:
      options.startedAt ?? new Date().toLocaleTimeString("zh-CN", { hour12: false }),
    runtimeStatus: "offline",
    displayState: "no_runtime",
    displayReady: false,
    displayReason: "no_live_runtime",
    currentStage: "intent",
    events: [],
    summary: {
      allowedActions: 0,
      blockedActions: 0,
      humanGates: 0,
      detections: 0,
      toolCalls: 0,
    },
  };
}

export function buildEmptySession(): CheckoutSession {
  return buildInitialSession({
    id: "",
    merchant: "暂无 Session",
    amount: 0,
    currency: "CNY",
    reason: "等待外部 Agent 通过 REST 或 A2A 发起付款请求",
  });
}

export function reduceSessionEvent(session: CheckoutSession, event: SessionEvent): CheckoutSession {
  if (session.events.some((existing) => existing.id === event.id)) {
    return session;
  }

  const summary = { ...session.summary };

  if (event.kind === "action_allowed") {
    summary.allowedActions += 1;
  }

  if (event.kind === "action_blocked") {
    summary.blockedActions += 1;
  }

  if (event.kind === "human_gate") {
    summary.humanGates += 1;
  }

  if (event.kind === "detection") {
    summary.detections += 1;
  }

  if (event.kind === "tool_call_start") {
    summary.toolCalls += 1;
  }

  return {
    ...session,
    merchant: event.merchant ?? event.target ?? session.merchant,
    amount: event.amount ?? session.amount,
    currency: event.currency ?? session.currency,
    reason: event.reason ?? session.reason,
    displayUrl: event.displayUrl ?? session.displayUrl,
    displayReady: event.displayUrl ? true : session.displayReady,
    displayState:
      event.kind === "human_gate"
        ? "human_gate_open"
        : event.displayUrl
          ? "visible_surface_ready"
          : session.displayState,
    displayReason:
      event.kind === "human_gate"
        ? "human_gate_event"
        : event.displayUrl
          ? "event_display_url"
          : session.displayReason,
    currentStage: event.kind === "media_persisted" ? session.currentStage : stageByEvent[event.kind],
    status: getStatusForEvent(session.status, event.kind),
    summary,
    events: [...session.events, event],
  };
}

export function getCurrentPaymentStage(session: CheckoutSession): PaymentStage {
  return paymentStages.find((stage) => stage.id === session.currentStage) ?? paymentStages[0];
}

export function getActivePath(session: CheckoutSession): string[] {
  const latestPath = session.events.at(-1)?.path;

  if (!latestPath) {
    return [session.agent, "Pay-Switch"];
  }

  return latestPath.split("/").map((part) => part.trim()).filter(Boolean);
}

function getStatusForEvent(
  currentStatus: CheckoutSession["status"],
  kind: EventKind,
): CheckoutSession["status"] {
  if (kind === "completed") return "completed";
  if (kind === "failed") return "failed";
  if (kind === "canceled") return "canceled";
  if (kind === "human_gate") return "waiting_human";
  if (kind === "auth_required") return "auth_required";
  if (kind === "media_persisted") return currentStatus;
  return "running";
}
