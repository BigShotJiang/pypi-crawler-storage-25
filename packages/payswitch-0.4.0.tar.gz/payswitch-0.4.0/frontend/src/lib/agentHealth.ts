export type AgentHealthStatus = "idle" | "loading" | "ready" | "error";

export interface AgentComputerUseHealth {
  display?: string;
  novnc_url?: string;
  novnc_dependencies?: Record<string, boolean>;
  browser_engine?: string;
  humanize?: boolean;
}

export interface AgentHealth {
  ok?: boolean;
  service?: string;
  ai?: {
    provider?: string;
    model?: string;
    configured?: boolean;
  };
  computer_use?: AgentComputerUseHealth;
}

export interface LocationLike {
  hostname: string;
  protocol: string;
}

export function buildFallbackNoVncUrl(location: LocationLike = window.location): string {
  const host = location.hostname || "127.0.0.1";
  return `${location.protocol}//${host}:6080/vnc.html?autoconnect=true&resize=scale&reconnect=true`;
}

export function resolveNoVncUrl(
  health: AgentHealth | null | undefined,
  explicitUrl?: string,
  location: LocationLike = window.location,
): string {
  const configured = explicitUrl?.trim();
  if (configured) {
    return configured;
  }

  const fromHealth = health?.computer_use?.novnc_url?.trim();
  if (fromHealth) {
    const url = new URL(fromHealth, `${location.protocol}//${location.hostname || "127.0.0.1"}`);
    url.searchParams.set("autoconnect", "true");
    url.searchParams.set("resize", "scale");
    url.searchParams.set("reconnect", "true");
    return url.toString();
  }

  return buildFallbackNoVncUrl(location);
}

export function summarizeComputerUse(health: AgentHealth | null | undefined): string {
  const computerUse = health?.computer_use;
  if (!computerUse) {
    return "computer screen pending";
  }

  const engine = computerUse.browser_engine || "browser";
  const display = computerUse.display || "display pending";
  const behavior = computerUse.humanize ? "humanized" : "standard";
  return `${engine} / ${behavior} / ${display}`;
}
