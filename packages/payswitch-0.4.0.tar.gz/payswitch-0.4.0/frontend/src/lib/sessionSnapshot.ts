import { normalizeStreamEvent } from "./eventStream";
import { resolveSettingsApiBaseUrl } from "./settingsApi";
import { buildInitialSession, reduceSessionEvent, type CheckoutSession } from "./sessionModel";

interface RawSessionSnapshot {
  session?: {
    id?: string;
    agent?: CheckoutSession["agent"];
    merchant?: string;
    amount?: number;
    currency?: string;
    reason?: string;
    status?: CheckoutSession["status"];
    startedAt?: string;
    user_id?: string;
    workspace_id?: string;
    subagent_session_id?: string;
    site_id?: string;
    site_lock_id?: string;
    profile_id?: string;
    browser_context_id?: string;
    runtime_status?: string;
    display_state?: string;
    display_ready?: boolean;
    display_reason?: string;
    display_surface_id?: string;
    display_owner_task_id?: string;
    display_route_token?: string;
    display_selected_at?: string;
    display_url?: string;
    events?: unknown[];
  } | null;
}

interface RawSessionListSnapshot {
  sessions?: Array<NonNullable<RawSessionSnapshot["session"]>>;
  detail?: string;
}

export function resolveRuntimeApiBaseUrl({
  explicitApiUrl,
  eventStreamUrl,
}: {
  explicitApiUrl?: string;
  eventStreamUrl?: string;
}) {
  return resolveSettingsApiBaseUrl({ explicitApiUrl, eventStreamUrl });
}

function buildSessionApiUrl(
  baseUrl: string,
  path: string,
  options: { userId?: string } = {},
): URL {
  const url = new URL(`${baseUrl}${path}`);
  if (options.userId) {
    url.searchParams.set("user_id", options.userId);
  }
  return url;
}

export async function fetchSessionSnapshot(
  baseUrl: string,
  sessionId?: string,
  options: { userId?: string } = {},
): Promise<CheckoutSession | null> {
  if (!baseUrl) {
    return null;
  }
  if (!sessionId) {
    return null;
  }
  const url = buildSessionApiUrl(
    baseUrl,
    `/api/sessions/${encodeURIComponent(sessionId)}`,
    options,
  );
  const response = await fetch(url.toString(), {
    headers: { "Content-Type": "application/json" },
  });
  const payload = (await response.json()) as RawSessionSnapshot & {
    detail?: string;
    error?: string;
  };
  if (!response.ok) {
    throw new Error(payload.error ?? payload.detail ?? `Pay-Switch API ${response.status}`);
  }
  if (!payload.session) {
    return null;
  }
  return buildSessionFromSnapshot(payload.session);
}

export async function deleteSession(
  baseUrl: string,
  sessionId: string,
  options: { userId?: string } = {},
): Promise<void> {
  const url = buildSessionApiUrl(
    baseUrl,
    `/api/sessions/${encodeURIComponent(sessionId)}`,
    options,
  );
  const response = await fetch(
    url.toString(),
    { method: "DELETE" },
  );
  if (!response.ok) {
    const payload = (await response.json().catch(() => ({}))) as { detail?: string };
    throw new Error(payload.detail ?? `删除失败 ${response.status}`);
  }
}

export async function clearAllSessions(
  baseUrl: string,
  options: { userId?: string } = {},
): Promise<number> {
  const url = buildSessionApiUrl(baseUrl, "/api/sessions", options);
  const response = await fetch(url.toString(), { method: "DELETE" });
  if (!response.ok) {
    const payload = (await response.json().catch(() => ({}))) as { detail?: string };
    throw new Error(payload.detail ?? `清除失败 ${response.status}`);
  }
  const data = (await response.json()) as { cleared: number };
  return data.cleared;
}

export async function selectSessionDisplay(
  baseUrl: string,
  sessionId: string,
  options: { userId?: string } = {},
): Promise<CheckoutSession | null> {
  const url = buildSessionApiUrl(
    baseUrl,
    `/api/sessions/${encodeURIComponent(sessionId)}:display/select`,
    options,
  );
  const response = await fetch(url.toString(), { method: "POST" });
  const payload = (await response.json()) as RawSessionSnapshot & { detail?: string; error?: string };
  if (!response.ok) {
    throw new Error(payload.detail ?? payload.error ?? `选择 Session 屏幕失败 ${response.status}`);
  }
  return payload.session ? buildSessionFromSnapshot(payload.session) : null;
}

export async function fetchSessionSnapshots(
  baseUrl: string,
  options: { userId?: string } = {},
): Promise<CheckoutSession[]> {
  if (!baseUrl) {
    return [];
  }
  const url = buildSessionApiUrl(baseUrl, "/api/sessions", options);
  const response = await fetch(url.toString(), {
    headers: { "Content-Type": "application/json" },
  });
  const payload = (await response.json()) as RawSessionListSnapshot & {
    detail?: string;
    error?: string;
  };
  if (!response.ok) {
    throw new Error(payload.error ?? payload.detail ?? `Pay-Switch API ${response.status}`);
  }
  return (payload.sessions ?? []).map(buildSessionFromSnapshot);
}

export function buildSessionFromSnapshot(
  snapshot: NonNullable<RawSessionSnapshot["session"]>,
): CheckoutSession {
  const base = buildInitialSession({
    id: snapshot.id,
    agent: snapshot.agent,
    merchant: snapshot.merchant,
    amount: snapshot.amount,
    currency: snapshot.currency,
    reason: snapshot.reason,
    startedAt: snapshot.startedAt,
  });
  const events = Array.isArray(snapshot.events) ? snapshot.events : [];
  let projected = base;
  events.forEach((raw, index) => {
    try {
      projected = reduceSessionEvent(
        projected,
        normalizeStreamEvent(raw as Parameters<typeof normalizeStreamEvent>[0], index),
      );
    } catch {
      // Ignore malformed historical events so one bad ledger line cannot blank the UI.
    }
  });
  return {
    ...projected,
    status: snapshot.status ?? projected.status,
    userId: snapshot.user_id,
    workspaceId: snapshot.workspace_id,
    subagentSessionId: snapshot.subagent_session_id,
    siteId: snapshot.site_id,
    siteLockId: snapshot.site_lock_id,
    profileId: snapshot.profile_id,
    browserContextId: snapshot.browser_context_id,
    runtimeStatus: snapshot.runtime_status,
    displayState: snapshot.display_state ?? projected.displayState,
    displayReady: snapshot.display_ready ?? projected.displayReady,
    displayReason: snapshot.display_reason ?? projected.displayReason,
    displaySurfaceId: snapshot.display_surface_id,
    displayOwnerTaskId: snapshot.display_owner_task_id,
    displayRouteToken: snapshot.display_route_token,
    displaySelectedAt: snapshot.display_selected_at,
    displayUrl: snapshot.display_url ?? projected.displayUrl,
  };
}
