import type { SessionEvent, SessionMediaArtifact } from "./sessionModel";

export function describeCaptureEngine(engine?: string): string | undefined {
  if (engine === "playwright_video") {
    return "Playwright";
  }
  if (engine === "ffmpeg_replay") {
    return "FFmpeg 回放";
  }
  return undefined;
}

export function describeCodecName(codec?: string): string | undefined {
  if (!codec) {
    return undefined;
  }
  if (codec === "h264") {
    return "H.264";
  }
  if (codec === "hevc") {
    return "HEVC";
  }
  if (codec === "vp8") {
    return "VP8";
  }
  if (codec === "vp9") {
    return "VP9";
  }
  if (codec === "av1") {
    return "AV1";
  }
  if (codec === "mpeg4") {
    return "MPEG-4";
  }
  return codec.toUpperCase();
}

export function describeRecordingFormat(contentType?: string): string | undefined {
  if (!contentType) {
    return undefined;
  }
  if (contentType === "video/webm") {
    return "WebM";
  }
  if (contentType === "video/mp4") {
    return "MP4";
  }
  if (contentType === "video/quicktime") {
    return "QuickTime";
  }
  return undefined;
}

export function sortMediaArtifactsByRecordingIndex<T extends SessionMediaArtifact>(
  artifacts: T[],
): T[] {
  return [...artifacts].sort((left, right) => {
    if (left.recordingIndex === undefined && right.recordingIndex === undefined) {
      return 0;
    }
    if (left.recordingIndex === undefined) {
      return 1;
    }
    if (right.recordingIndex === undefined) {
      return -1;
    }
    return left.recordingIndex - right.recordingIndex;
  });
}

export function findLatestVideoArtifact(
  events: SessionEvent[],
): SessionMediaArtifact | undefined {
  return findLatestVideoArtifacts(events).at(-1);
}

export function findLatestVideoArtifacts(
  events: SessionEvent[],
): SessionMediaArtifact[] {
  for (const event of [...events].reverse()) {
    const orderedArtifacts = sortMediaArtifactsByRecordingIndex(
      (event.mediaArtifacts ?? []).filter((artifact) =>
        Boolean(artifact.downloadUrl && artifact.contentType?.startsWith("video/")),
      ),
    );
    if (orderedArtifacts.length > 0) {
      return orderedArtifacts;
    }
  }
  return [];
}
