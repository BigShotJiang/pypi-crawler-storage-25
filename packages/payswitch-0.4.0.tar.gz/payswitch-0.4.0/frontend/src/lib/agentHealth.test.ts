import { describe, expect, it } from "vitest";

import { buildFallbackNoVncUrl, resolveNoVncUrl, summarizeComputerUse } from "./agentHealth";

const location = { hostname: "payswitch.example", protocol: "https:" };

describe("agentHealth", () => {
  it("builds a fallback noVNC URL from the dashboard host", () => {
    expect(buildFallbackNoVncUrl(location)).toBe(
      "https://payswitch.example:6080/vnc.html?autoconnect=true&resize=scale&reconnect=true",
    );
  });

  it("prefers the backend health noVNC URL and normalizes viewer params", () => {
    const url = resolveNoVncUrl(
      {
        computer_use: {
          novnc_url: "http://178.128.93.176:6081/vnc.html?resize=remote",
        },
      },
      undefined,
      location,
    );

    expect(url).toBe(
      "http://178.128.93.176:6081/vnc.html?resize=scale&autoconnect=true&reconnect=true",
    );
  });

  it("lets explicit frontend config override backend health", () => {
    expect(
      resolveNoVncUrl(
        { computer_use: { novnc_url: "http://backend:6080/vnc.html" } },
        "https://viewer.example/vnc.html",
        location,
      ),
    ).toBe("https://viewer.example/vnc.html");
  });

  it("summarizes the live computer runtime for compact status text", () => {
    expect(
      summarizeComputerUse({
        computer_use: {
          display: ":99",
          browser_engine: "cloakbrowser",
          humanize: true,
        },
      }),
    ).toBe("cloakbrowser / humanized / :99");
  });
});
