import type { CheckoutSession, SessionEvent } from "./sessionModel";

export interface SessionDisplaySummary {
  detail: string;
  label: string;
  tone: "ready" | "warning" | "muted";
  title: string;
}

export function resolveSessionDisplayUrl(
  session: CheckoutSession,
  ...candidates: Array<string | null | undefined>
): string | undefined {
  const values = [session.displayUrl, ...candidates];
  return values.find((value) => typeof value === "string" && value.trim().length > 0)?.trim();
}

export function hasReadySessionDisplay(
  session: CheckoutSession,
  ...candidates: Array<string | null | undefined>
): boolean {
  return Boolean(session.displayReady && resolveSessionDisplayUrl(session, ...candidates));
}

export function summarizeSessionDisplay(
  session: CheckoutSession,
  humanGate?: SessionEvent,
): SessionDisplaySummary {
  if (hasReadySessionDisplay(session)) {
    return {
      label: "可接管",
      title: "当前 Session 屏幕已就绪",
      detail: "这条 Session 已绑定独立 display route，可直接打开接管窗口。",
      tone: "ready",
    };
  }

  switch (session.displayState) {
    case "human_gate_open":
      return {
        label: "人工处理中",
        title: "已交付人工授权",
        detail: "当前 Session 已进入 Human Gate，可切换到对应接管窗口继续操作。",
        tone: "warning",
      };
    case "waiting_for_foreground":
      return {
        label: "等待前台",
        title: "等待前台切换",
        detail: "当前 workspace 的前台窗口正被另一条 Session 占用，请先切换或等待当前接管结束。",
        tone: "warning",
      };
    case "visible_adapter_not_available":
      return {
        label: "无可见窗口",
        title: "当前 Session 没有可见浏览器",
        detail: "这条 Session 目前没有可接管的可见 surface，不能把共享 noVNC 当成它的真实页面。",
        tone: "muted",
      };
    case "no_runtime":
      return {
        label: "无运行时",
        title: "当前 Session 没有运行时",
        detail: "这个 Session 目前没有在线 runtime，无法映射到真实浏览器窗口。",
        tone: "muted",
      };
    default:
      return {
        label: humanGate ? "等待人工" : "等待画面",
        title: humanGate ? "自动化已交付用户" : "等待真实浏览器画面",
        detail:
          humanGate?.detail ??
          "只有当前 Session 绑定了自己的截图或接管链接后，这里才显示对应画面。",
        tone: humanGate ? "warning" : "muted",
      };
  }
}
