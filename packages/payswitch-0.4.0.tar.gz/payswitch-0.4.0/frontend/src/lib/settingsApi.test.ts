import { afterEach, describe, expect, it, vi } from "vitest";

import {
  postEnsureBrowserCdpProfile,
  postProjectProfile,
  resolveSettingsApiBaseUrl,
  inferEventsUrlFromCurrentLocation,
  inferRuntimeBasePath,
} from "./settingsApi";

describe("settingsApi", () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("derives the API origin from the SSE endpoint", () => {
    expect(
      resolveSettingsApiBaseUrl({
        eventStreamUrl: "http://127.0.0.1:8787/events?session_id=txn_1",
      }),
    ).toBe("http://127.0.0.1:8787");
  });

  it("prefers an explicit API URL", () => {
    expect(
      resolveSettingsApiBaseUrl({
        explicitApiUrl: "http://localhost:9000/",
        eventStreamUrl: "http://127.0.0.1:8787/events",
      }),
    ).toBe("http://localhost:9000");
  });

  it("infers runtime base path from normal route", () => {
    expect(inferRuntimeBasePath("/pay-switch")).toBe("/pay-switch");
    expect(inferRuntimeBasePath("/pay-switch/")).toBe("/pay-switch");
    expect(inferRuntimeBasePath("/")).toBe("");
    expect(inferRuntimeBasePath("/pay-switch/index.html")).toBe("/pay-switch");
  });

  it("infers events URL from current location pathname", () => {
    expect(inferEventsUrlFromCurrentLocation("/pay-switch")).toBe("/pay-switch/events");
    expect(inferEventsUrlFromCurrentLocation("/pay-switch/")).toBe("/pay-switch/events");
    expect(inferEventsUrlFromCurrentLocation("/")).toBe("/events");
  });

  it("posts project profile requests", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(
        JSON.stringify({
          updated: ["chrome_user_data_dir"],
          project_profile: {
            user_data_dir: "/tmp/profile",
            profile_directory: "Default",
            chrome_cdp_url: "",
          },
          config: {},
          options: {},
          writable_keys: [],
        }),
      ),
    );

    const result = await postProjectProfile("http://127.0.0.1:8787", {
      ensure: true,
    });

    expect(fetchMock).toHaveBeenCalledWith(
      "http://127.0.0.1:8787/api/browser/project-profile",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ ensure: true }),
      }),
    );
    expect(result.project_profile.profile_directory).toBe("Default");
  });

  it("posts CDP ensure requests", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(
        JSON.stringify({
          updated: ["chrome_cdp_url"],
          cdp_url: "http://127.0.0.1:9333",
          config: {},
          options: {},
          writable_keys: [],
        }),
      ),
    );

    const result = await postEnsureBrowserCdpProfile("http://127.0.0.1:8787");

    expect(fetchMock).toHaveBeenCalledWith(
      "http://127.0.0.1:8787/api/browser/cdp-profile/ensure",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({}),
      }),
    );
    expect(result.cdp_url).toBe("http://127.0.0.1:9333");
  });
});
