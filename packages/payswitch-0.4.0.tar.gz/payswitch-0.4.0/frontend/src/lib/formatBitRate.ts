function formatRounded(value: number): string {
  const rounded = value >= 10 ? Math.round(value) : Math.round(value * 10) / 10;
  return String(rounded);
}

export function formatBitRate(value?: number): string | undefined {
  if (value === undefined || !Number.isFinite(value) || value < 0) {
    return undefined;
  }
  if (value >= 1_000_000) {
    return `${formatRounded(value / 1_000_000)} Mbps`;
  }
  if (value >= 1_000) {
    return `${formatRounded(value / 1_000)} kbps`;
  }
  return `${Math.round(value)} bps`;
}
