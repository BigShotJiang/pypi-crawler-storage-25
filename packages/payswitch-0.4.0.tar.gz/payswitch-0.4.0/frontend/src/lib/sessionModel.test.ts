import { describe, expect, it } from "vitest";

import {
  buildInitialSession,
  getActivePath,
  getCurrentPaymentStage,
  reduceSessionEvent,
} from "./sessionModel";
import type { SessionEvent } from "./sessionModel";
import { demoEvents } from "./demoSession";

describe("sessionModel", () => {
  it("projects live checkout events into payment stage, active path, and summary counts", () => {
    const events: SessionEvent[] = [
      {
        id: "evt-1",
        at: "18:30:00",
        kind: "intent_received",
        title: "收到 Codex 支付意图",
        detail: "deepseek 200 CNY",
        actor: "codex",
        path: "Codex",
      },
      {
        id: "evt-2",
        at: "18:30:04",
        kind: "action_allowed",
        title: "打开充值页",
        detail: "guard 允许导航动作",
        actor: "payswitch",
        path: "Codex / Pay-Switch / Browser / DeepSeek",
      },
      {
        id: "evt-3",
        at: "18:30:18",
        kind: "human_gate",
        title: "等待扫码确认",
        detail: "QR 检测器命中",
        actor: "human",
        path: "Codex / Pay-Switch / Human Gate",
      },
    ];

    const projected = events.reduce(reduceSessionEvent, buildInitialSession());

    expect(getCurrentPaymentStage(projected).label).toBe("已交付人工授权");
    expect(getActivePath(projected)).toEqual(["Codex", "Pay-Switch", "Human Gate"]);
    expect(projected.summary.allowedActions).toBe(1);
    expect(projected.summary.humanGates).toBe(1);
    expect(projected.events.map((event) => event.id)).toEqual(["evt-1", "evt-2", "evt-3"]);
  });

  // 新增：tool_call_start/end 事件处理
  it("reduces tool_call_start events and increments toolCalls counter", () => {
    const events: SessionEvent[] = [
      {
        id: "evt-tc1",
        at: "18:30:10",
        kind: "tool_call_start",
        title: "调用工具: fill_payment_form",
        detail: '{"url": "https://example.com"}',
        actor: "payswitch",
        path: "Codex / Pay-Switch",
        target: "fill_payment_form",
      },
      {
        id: "evt-tc2",
        at: "18:30:12",
        kind: "tool_call_end",
        title: "工具返回: fill_payment_form",
        detail: '{"status": "ok"}',
        actor: "payswitch",
        path: "Codex / Pay-Switch",
        target: "fill_payment_form",
      },
    ];

    const projected = events.reduce(reduceSessionEvent, buildInitialSession());

    expect(projected.summary.toolCalls).toBe(1);
    expect(projected.currentStage).toBe("browser");
    expect(projected.status).toBe("running");
  });

  // 新增：auth_required 状态转换
  it("transitions to auth_required status on auth_required event", () => {
    const event: SessionEvent = {
      id: "evt-auth",
      at: "18:30:15",
      kind: "auth_required",
      title: "需要认证",
      detail: "3DS 验证",
      actor: "browser",
      path: "Codex / Pay-Switch / Browser",
    };

    const projected = reduceSessionEvent(buildInitialSession(), event);

    expect(projected.status).toBe("auth_required");
    expect(projected.currentStage).toBe("authorization");
  });

  // 新增：failed 状态转换
  it("transitions to failed status on failed event", () => {
    const event: SessionEvent = {
      id: "evt-fail",
      at: "18:30:20",
      kind: "failed",
      title: "支付失败",
      detail: "卡余额不足",
      actor: "payswitch",
      path: "Codex / Pay-Switch",
      risk: "high",
    };

    const projected = reduceSessionEvent(buildInitialSession(), event);

    expect(projected.status).toBe("failed");
    expect(projected.currentStage).toBe("settlement");
  });

  // 新增：canceled 状态转换
  it("transitions to canceled status on canceled event", () => {
    const event: SessionEvent = {
      id: "evt-cancel",
      at: "18:30:20",
      kind: "canceled",
      title: "任务已取消",
      detail: "用户手动取消",
      actor: "human",
      path: "Codex / Pay-Switch",
    };

    const projected = reduceSessionEvent(buildInitialSession(), event);

    expect(projected.status).toBe("canceled");
    expect(projected.currentStage).toBe("settlement");
  });

  it("keeps the prior waiting_human stage when media artifacts arrive after human gate", () => {
    const base = reduceSessionEvent(
      buildInitialSession(),
      {
        id: "evt-human",
        at: "18:30:24",
        kind: "human_gate",
        title: "等待扫码确认",
        detail: "Pay-Switch 已停止自动化。",
        actor: "human",
        path: "Codex / Pay-Switch / Human Gate",
      },
    );

    const projected = reduceSessionEvent(base, {
      id: "evt-media",
      at: "18:30:25",
      kind: "media_persisted",
      title: "录屏已归档",
      detail: "外部浏览器录屏已持久化。",
      actor: "payswitch",
      path: "Codex / Pay-Switch / Evidence",
      mediaArtifacts: [
        {
          artifactId: "capture_webm",
          contentType: "video/webm",
          downloadUrl: "/api/sessions/psw_kimi/artifacts/capture_webm",
        },
      ],
    });

    expect(projected.status).toBe("waiting_human");
    expect(projected.currentStage).toBe("authorization");
    expect(projected.events.at(-1)?.mediaArtifacts?.[0].downloadUrl).toContain("/artifacts/");
  });

  // 回归测试：确保所有 10 个 demo 事件仍然正确处理
  it("processes all demo events without error (regression test)", () => {
    const projected = demoEvents.reduce(reduceSessionEvent, buildInitialSession());

    expect(projected.events).toHaveLength(10);
    expect(projected.status).toBe("completed");
    expect(projected.currentStage).toBe("settlement");
    expect(projected.summary.allowedActions).toBe(2);
    expect(projected.summary.humanGates).toBe(1);
    expect(projected.summary.detections).toBe(1);
  });
});
