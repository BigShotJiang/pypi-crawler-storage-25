export type SettingsConfig = {
  max_per_transaction: number;
  daily_limit: number;
  whitelist: string[];
  auto_confirm_threshold: number;
  payment_priority: string[];
  disabled_payment_methods: string[];
  allow_card_number_only: boolean;
  allow_virtual_card: boolean;
  require_human_for_expiry: boolean;
  require_human_for_cvv: boolean;
  require_human_for_otp: boolean;
  require_human_for_final_confirm: boolean;
  default_currency: string;
  llm_provider: string;
  llm_model: string;
  stripe_webhook_port: number;
  stripe_default_currency: string;
  computer_use_enabled: boolean;
  computer_use_driver: string;
  computer_use_max_autonomous_category: string;
  browser_control_backend: string;
  chrome_cdp_url: string;
  chrome_user_data_dir: string;
  chrome_profile_directory: string;
  chrome_expected_profile_email: string;
  browser_channel: string;
  browser_engine: string;
  browser_humanize: boolean;
  browser_human_preset: string;
  display_mode: string | null;
  novnc_port: number;
  transaction_timeout: number;
  data_dir: string;
  card_instruments: Array<{
    id: string;
    label: string;
    storage: string;
    autofill_level: string;
    has_expiry: boolean;
    has_cvv: boolean;
    has_holder_name: boolean;
    has_billing_address: boolean;
    allowed_payees: string[];
    max_per_transaction: number;
    currency_allowlist: string[];
  }>;
  secrets: {
    llm_api_key: boolean;
    stripe_secret_key: boolean;
    stripe_webhook_secret: boolean;
    legacy_vault_cards: number;
  };
};

export type SettingsOptions = {
  browser_channels: string[];
  browser_control_backends: string[];
  computer_use_drivers: string[];
  step_categories: string[];
  display_modes: string[];
  payment_methods: string[];
  browser_engines: string[];
  browser_human_presets: string[];
};

export type SettingsPayload = {
  config: SettingsConfig;
  options: SettingsOptions;
  writable_keys: string[];
};

export type ProjectProfileRequest = {
  user_data_dir?: string;
  profile_directory?: string;
  browser?: string;
  expected_email?: string;
  ensure?: boolean;
  timeout?: number;
};

export type ProjectProfileResponse = SettingsPayload & {
  updated: string[];
  project_profile: {
    user_data_dir: string;
    profile_directory: string;
    chrome_cdp_url: string;
  };
};

export type BrowserProfile = {
  index: number;
  id: string;
  user_data_dir: string;
  profile_directory: string;
  email: string;
  name: string;
  gaia_name: string;
  gaia_given_name: string;
  identity_label: string;
  is_consented_primary_account: boolean;
  active_time: number;
};

export type BrowserDoctor = {
  launch_mode: string;
  configured_backend: string;
  runnable: boolean;
  browser_channel: string;
  chrome_cdp_url: string;
  chrome_user_data_dir: string;
  chrome_profile_directory: string;
  expected_email: string;
  resolved_email: string;
  active_process: null | {
    user_data_dir: string;
    profile_directory: string;
    remote_debugging_port: string;
  };
  problems: string[];
  recommendations: string[];
};

export function resolveSettingsApiBaseUrl({
  explicitApiUrl,
  eventStreamUrl,
}: {
  explicitApiUrl?: string;
  eventStreamUrl?: string;
}) {
  const explicit = explicitApiUrl?.trim();
  if (explicit) {
    return explicit.replace(/\/+$/, "");
  }

  const streamUrl = eventStreamUrl?.trim();
  if (!streamUrl) {
    return "";
  }

  try {
    const url = new URL(streamUrl);
    url.pathname = url.pathname.replace(/\/events\/?$/, "") || "/";
    url.search = "";
    url.hash = "";
    return url.toString().replace(/\/+$/, "");
  } catch {
    return streamUrl.replace(/\/events(?:\?.*)?$/, "").replace(/\/+$/, "");
  }
}

export function inferRuntimeBasePath(pathname: string = window.location.pathname): string {
  const rawPath = (pathname ?? "").trim();
  const path = rawPath === "/" ? "" : rawPath.replace(/\/+$/, "");

  if (!path || path === "") {
    return "";
  }

  if (!/\.[a-z0-9]+$/i.test(path)) {
    return path;
  }

  return path.replace(/\/[^/]*\.[a-z0-9]+$/i, "") || "";
}

export function inferEventsUrlFromCurrentLocation(pathname: string = window.location.pathname): string {
  const basePath = inferRuntimeBasePath(pathname);
  return `${basePath}/events`;
}

async function requestJson<T>(baseUrl: string, path: string, init?: RequestInit): Promise<T> {
  if (!baseUrl) {
    throw new Error("未配置 VITE_PAYSWITCH_EVENTS_URL 或 VITE_PAYSWITCH_API_URL");
  }
  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  const payload = (await response.json()) as T & { error?: string };
  if (!response.ok) {
    throw new Error(payload.error ?? `Pay-Switch API ${response.status}`);
  }
  return payload;
}

export function fetchSettings(baseUrl: string) {
  return requestJson<SettingsPayload>(baseUrl, "/api/settings");
}

export function patchSettings(baseUrl: string, updates: Partial<SettingsConfig>) {
  return requestJson<SettingsPayload & { updated: string[] }>(baseUrl, "/api/settings", {
    method: "PATCH",
    body: JSON.stringify(updates),
  });
}

export async function fetchBrowserProfiles(
  baseUrl: string,
  params: { browser: string; query?: string },
) {
  const query = new URLSearchParams({ browser: params.browser });
  if (params.query?.trim()) {
    query.set("query", params.query.trim());
  }
  const payload = await requestJson<{ profiles: BrowserProfile[] }>(
    baseUrl,
    `/api/browser/profiles?${query.toString()}`,
  );
  return payload.profiles;
}

export function patchBrowserProfile(
  baseUrl: string,
  profile: Pick<BrowserProfile, "user_data_dir" | "profile_directory"> & {
    browser: string;
    keep_cdp?: boolean;
  },
) {
  return requestJson<SettingsPayload & { updated: string[] }>(baseUrl, "/api/browser/profile", {
    method: "PATCH",
    body: JSON.stringify(profile),
  });
}

export function postProjectProfile(baseUrl: string, request: ProjectProfileRequest = {}) {
  return requestJson<ProjectProfileResponse>(baseUrl, "/api/browser/project-profile", {
    method: "POST",
    body: JSON.stringify(request),
  });
}

export function postEnsureBrowserCdpProfile(baseUrl: string, request: { timeout?: number } = {}) {
  return requestJson<SettingsPayload & { updated: string[]; cdp_url: string }>(
    baseUrl,
    "/api/browser/cdp-profile/ensure",
    {
      method: "POST",
      body: JSON.stringify(request),
    },
  );
}

export async function fetchBrowserDoctor(baseUrl: string) {
  const payload = await requestJson<{ doctor: BrowserDoctor }>(baseUrl, "/api/browser/doctor");
  return payload.doctor;
}
