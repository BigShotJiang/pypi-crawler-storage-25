export function formatFrameSize(width?: number, height?: number): string | undefined {
  if (
    width === undefined
    || height === undefined
    || !Number.isInteger(width)
    || !Number.isInteger(height)
    || width < 0
    || height < 0
  ) {
    return undefined;
  }
  return `${width}x${height}`;
}
