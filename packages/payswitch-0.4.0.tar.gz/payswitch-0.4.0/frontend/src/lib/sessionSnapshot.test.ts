import { afterEach, describe, expect, it, vi } from "vitest";

import {
  buildSessionFromSnapshot,
  fetchSessionSnapshot,
  fetchSessionSnapshots,
  selectSessionDisplay,
} from "./sessionSnapshot";

describe("sessionSnapshot", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("hydrates a runtime panel from a ledger snapshot", () => {
    const session = buildSessionFromSnapshot({
      id: "txn_kimi",
      merchant: "kimi",
      amount: 19,
      currency: "CNY",
      reason: "Kimi 月付",
      status: "waiting_human",
      startedAt: "18:30:00",
      user_id: "alice",
      workspace_id: "uws_alice",
      subagent_session_id: "sag_kimi",
      site_id: "kimi",
      events: [
        {
          id: "txn_kimi-intent",
          ts: "2026-05-13T10:30:00Z",
          type: "intent.received",
          summary: "收到 kimi 支付请求",
          message: "CNY 19",
          source: "codex",
          path: ["External Agent", "Pay-Switch"],
        },
        {
          id: "txn_kimi-human-confirm",
          ts: "2026-05-13T10:31:00Z",
          type: "human.gate",
          summary: "等待最终付款确认",
          message: "检测到 Pay without Link，请确认后点击。",
          source: "human",
          path: ["External Agent", "Pay-Switch", "Human Gate"],
          current_url: "https://checkout.stripe.com/pay/cs_live",
          screenshot_url: "http://127.0.0.1:8787/evidence?path=shot.png",
        },
      ],
    });

    expect(session.id).toBe("txn_kimi");
    expect(session.merchant).toBe("kimi");
    expect(session.status).toBe("waiting_human");
    expect(session.userId).toBe("alice");
    expect(session.workspaceId).toBe("uws_alice");
    expect(session.subagentSessionId).toBe("sag_kimi");
    expect(session.siteId).toBe("kimi");
    expect(session.currentStage).toBe("authorization");
    expect(session.summary.humanGates).toBe(1);
    expect(session.events.at(-1)?.screenshotUrl).toContain("/evidence");
    expect(session.displayState).toBe("human_gate_open");
  });

  it("keeps terminal session status when replaying media persisted snapshot events", () => {
    const session = buildSessionFromSnapshot({
      id: "txn_kimi",
      merchant: "kimi",
      amount: 19,
      currency: "CNY",
      reason: "Kimi 月付",
      status: "waiting_human",
      startedAt: "18:30:00",
      events: [
        {
          id: "txn_kimi-human-confirm",
          ts: "2026-05-13T10:31:00Z",
          type: "human.gate",
          summary: "等待最终付款确认",
          message: "检测到 Pay without Link，请确认后点击。",
          source: "human",
          path: ["External Agent", "Pay-Switch", "Human Gate"],
        },
        {
          id: "txn_kimi-media",
          ts: "2026-05-13T10:31:01Z",
          type: "media.persisted",
          summary: "录屏已归档",
          source: "pay_switch",
          media_artifacts: [
            {
              artifact_id: "capture_webm",
              name: "capture.webm",
              content_type: "video/webm",
              download_url: "/api/sessions/txn_kimi/artifacts/capture_webm",
            },
          ],
        },
      ],
    });

    expect(session.status).toBe("waiting_human");
    expect(session.currentStage).toBe("authorization");
    expect(session.events.at(-1)?.mediaArtifacts?.[0].downloadUrl).toContain("/artifacts/");
  });

  it("loads all sessions for the runtime switcher", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        json: async () => ({
          sessions: [
            {
              id: "psw_kimi",
              merchant: "kimi",
              amount: 49,
              currency: "CNY",
              reason: "Kimi monthly",
              status: "waiting_human",
              startedAt: "2026-05-14T10:00:00Z",
              events: [
                {
                  id: "evt_kimi",
                  ts: "2026-05-14T10:01:00Z",
                  type: "human.gate",
                  summary: "已交付扫码付款",
                  message: "二维码已展示",
                  source: "human",
                  path: ["Codex", "Pay-Switch", "Human Gate"],
                },
              ],
            },
            {
              id: "psw_jimeng",
              merchant: "jimeng",
              amount: 68,
              currency: "CNY",
              reason: "即梦测试",
              status: "running",
              startedAt: "2026-05-14T10:02:00Z",
              events: [],
            },
          ],
        }),
        ok: true,
      })),
    );

    const sessions = await fetchSessionSnapshots("https://example.test");

    expect(fetch).toHaveBeenCalledWith("https://example.test/api/sessions", {
      headers: { "Content-Type": "application/json" },
    });
    expect(sessions).toHaveLength(2);
    expect(sessions[0].id).toBe("psw_kimi");
    expect(sessions[0].summary.humanGates).toBe(1);
    expect(sessions[1].merchant).toBe("jimeng");
  });

  it("does not call /api/sessions/latest without an explicit user context", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        json: async () => ({ session: null }),
        ok: true,
      })),
    );

    const session = await fetchSessionSnapshot("https://example.test");

    expect(fetch).not.toHaveBeenCalled();
    expect(session).toBeNull();
  });

  it("does not resolve latest snapshot when only user context is provided", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        json: async () => ({
          session: {
            id: "psw_kimi",
            merchant: "kimi",
            amount: 49,
            currency: "CNY",
            status: "running",
            reason: "Kimi monthly",
            startedAt: "2026-05-14T10:00:00Z",
            events: [],
          },
        }),
        ok: true,
      })),
    );

    const session = await fetchSessionSnapshot("https://example.test", undefined, { userId: "alice" });

    expect(fetch).not.toHaveBeenCalled();
    expect(session).toBeNull();
  });

  it("scopes session snapshot reads to the current user runtime", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        json: async () => ({
          session: {
            id: "psw_kimi",
            merchant: "kimi",
            amount: 49,
            currency: "CNY",
            status: "running",
            reason: "Kimi monthly",
            startedAt: "2026-05-14T10:00:00Z",
            events: [],
          },
        }),
        ok: true,
      })),
    );

    await fetchSessionSnapshot("https://example.test", "psw_kimi", { userId: "alice" });

    expect(fetch).toHaveBeenCalledWith("https://example.test/api/sessions/psw_kimi?user_id=alice", {
      headers: { "Content-Type": "application/json" },
    });
  });

  it("scopes session queries to the current user runtime", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        json: async () => ({ sessions: [] }),
        ok: true,
      })),
    );

    await fetchSessionSnapshots("https://example.test", { userId: "alice" });

    expect(fetch).toHaveBeenCalledWith("https://example.test/api/sessions?user_id=alice", {
      headers: { "Content-Type": "application/json" },
    });
  });

  it("projects session-scoped display ownership from snapshot fields", () => {
    const session = buildSessionFromSnapshot({
      id: "psw_kimi",
      merchant: "kimi",
      amount: 49,
      currency: "CNY",
      reason: "Kimi monthly",
      status: "running",
      startedAt: "2026-05-14T10:00:00Z",
      display_state: "visible_surface_ready",
      display_ready: true,
      display_reason: "operator_select",
      display_url: "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_x",
      display_route_token: "dsp_x",
      display_owner_task_id: "psw_kimi",
      events: [],
    });

    expect(session.displayReady).toBe(true);
    expect(session.displayState).toBe("visible_surface_ready");
    expect(session.displayRouteToken).toBe("dsp_x");
    expect(session.displayOwnerTaskId).toBe("psw_kimi");
    expect(session.displayUrl).toContain("/display/view");
  });

  it("posts display selection for the chosen session", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        json: async () => ({
          session: {
            id: "psw_kimi",
            merchant: "kimi",
            amount: 49,
            currency: "CNY",
            reason: "Kimi monthly",
            status: "running",
            display_state: "visible_surface_ready",
            display_ready: true,
            display_url: "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_x",
            events: [],
          },
        }),
        ok: true,
      })),
    );

    const session = await selectSessionDisplay("https://example.test", "psw_kimi", { userId: "alice" });

    expect(fetch).toHaveBeenCalledWith(
      "https://example.test/api/sessions/psw_kimi:display/select?user_id=alice",
      { method: "POST" },
    );
    expect(session?.displayReady).toBe(true);
  });
});
