import type { AgentSource, EventKind, EventRisk, SessionEvent } from "./sessionModel";

const eventKindMap: Record<string, EventKind> = {
  "intent.received": "intent_received",
  intent_received: "intent_received",
  "guard.passed": "guard_passed",
  guard_passed: "guard_passed",
  "route.selected": "route_selected",
  route_selected: "route_selected",
  observe: "observe",
  "action.proposed": "action_proposed",
  action_proposed: "action_proposed",
  "action.allowed": "action_allowed",
  action_allowed: "action_allowed",
  "action.blocked": "action_blocked",
  action_blocked: "action_blocked",
  detection: "detection",
  "human.gate": "human_gate",
  human_gate: "human_gate",
  completed: "completed",
  "workspace.acquired": "workspace_acquired",
  workspace_acquired: "workspace_acquired",
  "secret.delivered": "secret_delivered",
  secret_delivered: "secret_delivered",
  "media.persisted": "media_persisted",
  media_persisted: "media_persisted",
  // 新增：工具调用 + A2A 扩展状态
  "tool_call.start": "tool_call_start",
  tool_call_start: "tool_call_start",
  "tool_call.end": "tool_call_end",
  tool_call_end: "tool_call_end",
  "auth.required": "auth_required",
  auth_required: "auth_required",
  failed: "failed",
  canceled: "canceled",
};

const actorMap: Record<string, AgentSource> = {
  browser: "browser",
  claude: "claude",
  claude_code: "claude",
  codex: "codex",
  human: "human",
  ledger: "ledger",
  pay_switch: "payswitch",
  payswitch: "payswitch",
};

const risks = new Set<EventRisk>(["low", "medium", "high"]);

interface RawStreamEvent {
  id?: unknown;
  at?: unknown;
  ts?: unknown;
  timestamp?: unknown;
  kind?: unknown;
  type?: unknown;
  title?: unknown;
  summary?: unknown;
  detail?: unknown;
  message?: unknown;
  actor?: unknown;
  source?: unknown;
  path?: unknown;
  risk?: unknown;
  target?: unknown;
  merchant?: unknown;
  amount?: unknown;
  currency?: unknown;
  reason?: unknown;
  current_url?: unknown;
  currentUrl?: unknown;
  screenshot_url?: unknown;
  screenshotUrl?: unknown;
  screenshot_path?: unknown;
  screenshotPath?: unknown;
  qr_artifact_url?: unknown;
  qrArtifactUrl?: unknown;
  qr_artifact_path?: unknown;
  qrArtifactPath?: unknown;
  display_url?: unknown;
  displayUrl?: unknown;
  novnc_url?: unknown;
  media_artifacts?: unknown;
  mediaArtifacts?: unknown;
  detected_payment_methods?: unknown;
  paymentMethods?: unknown;
  interaction_hints?: unknown;
  interactionHints?: unknown;
  sequence?: unknown;
}

export function buildEventStreamUrl(
  baseUrl: string,
  sessionId: string,
  options: { afterSequence?: number; replay?: boolean; userId?: string } = {},
): string {
  const url = new URL(baseUrl, window.location.origin);
  url.searchParams.set("session_id", sessionId);
  if (options.userId) {
    url.searchParams.set("user_id", options.userId);
  }
  const afterSequence = options.afterSequence;
  if (afterSequence !== undefined && Number.isInteger(afterSequence) && afterSequence >= 0) {
    url.searchParams.set("after", String(afterSequence));
  }
  if (options.replay === false) {
    url.searchParams.set("replay", "0");
  }
  return url.toString();
}

export function parseStreamMessage(message: string, fallbackIndex: number): SessionEvent {
  const raw = JSON.parse(message) as RawStreamEvent;
  return normalizeStreamEvent(raw, fallbackIndex);
}

export function normalizeStreamEvent(raw: RawStreamEvent, fallbackIndex: number): SessionEvent {
  const kind = normalizeEventKind(stringValue(raw.kind ?? raw.type));
  const actor = normalizeActor(stringValue(raw.actor ?? raw.source));
  const title = stringValue(raw.title ?? raw.summary) ?? defaultTitle(kind);
  const detail = stringValue(raw.detail ?? raw.message) ?? "";
  const path = normalizePath(raw.path, actor);
  const risk = normalizeRisk(raw.risk);

  return {
    id: stringValue(raw.id) ?? `evt_stream_${fallbackIndex}`,
    at: normalizeTime(raw.at ?? raw.ts ?? raw.timestamp),
    kind,
    title,
    detail,
    actor,
    path,
    ...(numberValue(raw.sequence) !== undefined ? { sequence: numberValue(raw.sequence) } : {}),
    ...(risk ? { risk } : {}),
    ...(stringValue(raw.target) ? { target: stringValue(raw.target) } : {}),
    ...(stringValue(raw.merchant) ? { merchant: stringValue(raw.merchant) } : {}),
    ...(numberValue(raw.amount) !== undefined ? { amount: numberValue(raw.amount) } : {}),
    ...(stringValue(raw.currency) ? { currency: stringValue(raw.currency)?.toUpperCase() } : {}),
    ...(stringValue(raw.reason) ? { reason: stringValue(raw.reason) } : {}),
    ...(stringValue(raw.currentUrl ?? raw.current_url)
      ? { currentUrl: stringValue(raw.currentUrl ?? raw.current_url) }
      : {}),
    ...(stringValue(raw.screenshotUrl ?? raw.screenshot_url)
      ? { screenshotUrl: stringValue(raw.screenshotUrl ?? raw.screenshot_url) }
      : {}),
    ...(stringValue(raw.screenshotPath ?? raw.screenshot_path)
      ? { screenshotPath: stringValue(raw.screenshotPath ?? raw.screenshot_path) }
      : {}),
    ...(stringValue(raw.qrArtifactUrl ?? raw.qr_artifact_url)
      ? { qrArtifactUrl: stringValue(raw.qrArtifactUrl ?? raw.qr_artifact_url) }
      : {}),
    ...(stringValue(raw.qrArtifactPath ?? raw.qr_artifact_path)
      ? { qrArtifactPath: stringValue(raw.qrArtifactPath ?? raw.qr_artifact_path) }
      : {}),
    ...(stringValue(raw.displayUrl ?? raw.display_url)
      ? { displayUrl: stringValue(raw.displayUrl ?? raw.display_url) }
      : {}),
    ...arrayOfMediaArtifacts(raw.mediaArtifacts ?? raw.media_artifacts),
    ...arrayOfStrings(raw.paymentMethods ?? raw.detected_payment_methods),
    ...arrayOfRecords(raw.interactionHints ?? raw.interaction_hints),
  };
}

function normalizeEventKind(value: string | undefined): EventKind {
  const kind = value ? eventKindMap[value] : undefined;

  if (!kind) {
    throw new Error(`Unsupported event kind: ${value ?? "<missing>"}`);
  }

  return kind;
}

function normalizeActor(value: string | undefined): AgentSource {
  if (!value) {
    return "payswitch";
  }

  return actorMap[value] ?? "payswitch";
}

function normalizePath(value: unknown, actor: AgentSource): string {
  if (Array.isArray(value)) {
    return value.map(String).filter(Boolean).join(" / ");
  }

  if (typeof value === "string" && value.trim()) {
    return value;
  }

  return actor === "codex" || actor === "claude"
    ? `${actor === "codex" ? "Codex" : "Claude Code"} / Pay-Switch`
    : "Codex / Pay-Switch";
}

function normalizeRisk(value: unknown): EventRisk | undefined {
  if (typeof value !== "string") {
    return undefined;
  }

  return risks.has(value as EventRisk) ? (value as EventRisk) : undefined;
}

function normalizeTime(value: unknown): string {
  const raw = stringValue(value);

  if (!raw) {
    return new Date().toLocaleTimeString("zh-CN", { hour12: false });
  }

  const parsed = new Date(raw);

  if (Number.isNaN(parsed.getTime())) {
    return raw;
  }

  return parsed.toISOString().slice(11, 19);
}

function stringValue(value: unknown): string | undefined {
  if (typeof value !== "string") {
    return undefined;
  }

  const trimmed = value.trim();
  return trimmed ? trimmed : undefined;
}

function numberValue(value: unknown): number | undefined {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  if (typeof value === "string") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : undefined;
  }

  return undefined;
}

function nonNegativeIntegerValue(value: unknown): number | undefined {
  const parsed = numberValue(value);
  if (parsed === undefined || !Number.isInteger(parsed) || parsed < 0) {
    return undefined;
  }
  return parsed;
}

function nonNegativeNumberValue(value: unknown): number | undefined {
  const parsed = numberValue(value);
  if (parsed === undefined || parsed < 0) {
    return undefined;
  }
  return parsed;
}

function arrayOfStrings(value: unknown): { paymentMethods: string[] } | Record<string, never> {
  if (!Array.isArray(value)) {
    return {};
  }
  const items = value.map(String).map((item) => item.trim()).filter(Boolean);
  return items.length > 0 ? { paymentMethods: items } : {};
}

function arrayOfRecords(
  value: unknown,
): { interactionHints: Array<Record<string, unknown>> } | Record<string, never> {
  if (!Array.isArray(value)) {
    return {};
  }
  const items = value.filter(
    (item): item is Record<string, unknown> =>
      typeof item === "object" && item !== null && !Array.isArray(item),
  );
  return items.length > 0 ? { interactionHints: items } : {};
}

function arrayOfMediaArtifacts(
  value: unknown,
): { mediaArtifacts: NonNullable<SessionEvent["mediaArtifacts"]> } | Record<string, never> {
  if (!Array.isArray(value)) {
    return {};
  }
  const items = value
    .filter(
      (item): item is Record<string, unknown> =>
        typeof item === "object" && item !== null && !Array.isArray(item),
    )
    .map((item) => {
      const artifactId = stringValue(item.artifactId ?? item.artifact_id);
      const recordingIndex = nonNegativeIntegerValue(
        item.recordingIndex ?? item.recording_index,
      );
      const name = stringValue(item.name ?? item.label);
      const kind = stringValue(item.kind ?? item.type);
      const contentType = stringValue(item.contentType ?? item.content_type);
      const recordingSource = stringValue(item.recordingSource ?? item.recording_source);
      const captureEngine = stringValue(item.captureEngine ?? item.capture_engine);
      const sizeBytes = nonNegativeIntegerValue(item.sizeBytes ?? item.size_bytes);
      const durationSeconds = nonNegativeNumberValue(item.durationSeconds ?? item.duration_seconds);
      const frameRate = nonNegativeNumberValue(item.frameRate ?? item.frame_rate);
      const sourceScreenshotCount = nonNegativeIntegerValue(
        item.sourceScreenshotCount ?? item.source_screenshot_count,
      );
      const bitRate = nonNegativeIntegerValue(item.bitRate ?? item.bit_rate);
      const frameWidth = nonNegativeIntegerValue(item.frameWidth ?? item.frame_width);
      const frameHeight = nonNegativeIntegerValue(item.frameHeight ?? item.frame_height);
      const codecName = stringValue(item.codecName ?? item.codec_name)?.toLowerCase();
      const downloadUrl = stringValue(
        item.downloadUrl
          ?? item.download_url
          ?? item.previewUrl
          ?? item.preview_url
          ?? item.url,
      );
      return {
        ...(artifactId ? { artifactId } : {}),
        ...(recordingIndex !== undefined ? { recordingIndex } : {}),
        ...(name ? { name } : {}),
        ...(kind ? { kind } : {}),
        ...(contentType ? { contentType } : {}),
        ...(recordingSource ? { recordingSource } : {}),
        ...(captureEngine ? { captureEngine } : {}),
        ...(sizeBytes !== undefined ? { sizeBytes } : {}),
        ...(durationSeconds !== undefined ? { durationSeconds } : {}),
        ...(frameRate !== undefined ? { frameRate } : {}),
        ...(sourceScreenshotCount !== undefined ? { sourceScreenshotCount } : {}),
        ...(bitRate !== undefined ? { bitRate } : {}),
        ...(frameWidth !== undefined ? { frameWidth } : {}),
        ...(frameHeight !== undefined ? { frameHeight } : {}),
        ...(codecName ? { codecName } : {}),
        ...(downloadUrl ? { downloadUrl } : {}),
      };
    })
    .filter((item) => Object.keys(item).length > 0);
  return items.length > 0 ? { mediaArtifacts: items } : {};
}

function defaultTitle(kind: EventKind): string {
  if (kind === "workspace_acquired") {
    return "Workspace acquired";
  }
  if (kind === "secret_delivered") {
    return "Encrypted secret delivered";
  }
  const titles: Record<Exclude<EventKind, "workspace_acquired" | "secret_delivered">, string> = {
    intent_received: "收到支付意图",
    guard_passed: "安全检查通过",
    route_selected: "支付能力路由已选择",
    observe: "观察页面状态",
    action_proposed: "外部 Agent 提议动作",
    action_allowed: "动作已允许",
    action_blocked: "动作已拦截",
    detection: "检测器命中",
    human_gate: "已交付人工授权",
    completed: "支付完成",
    media_persisted: "媒体证据已归档",
    // 新增
    tool_call_start: "调用工具",
    tool_call_end: "工具返回",
    auth_required: "需要认证",
    failed: "任务失败",
    canceled: "任务已取消",
  };
  return titles[kind];
}
