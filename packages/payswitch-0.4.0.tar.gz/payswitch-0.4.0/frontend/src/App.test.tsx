import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { buildInitialSession, getCurrentPaymentStage, type CheckoutSession } from "./lib/sessionModel";

function makeSession(overrides: Partial<CheckoutSession> = {}): CheckoutSession {
  return {
    ...buildInitialSession(),
    id: "psw_kimi",
    merchant: "Kimi",
    amount: 49,
    currency: "CNY",
    reason: "Kimi monthly",
    status: "running",
    runtimeStatus: "online",
    ...overrides,
  };
}

const { selectSessionDisplayMock } = vi.hoisted(() => ({
  selectSessionDisplayMock: vi.fn(),
}));

const sessionsById: Record<string, CheckoutSession> = {
  psw_kimi: makeSession({
    id: "psw_kimi",
    merchant: "Kimi",
    reason: "Kimi monthly",
    displayReady: true,
    displayState: "visible_surface_ready",
    displayUrl: "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_kimi",
  }),
  psw_jimeng: makeSession({
    id: "psw_jimeng",
    merchant: "Jimeng",
    reason: "Jimeng recharge",
    displayReady: false,
    displayState: "waiting_for_foreground",
    displayReason: "foreground_owned_by_psw_kimi",
  }),
};

vi.mock("./hooks/useAgentHealth", () => ({
  useAgentHealth: () => ({ health: null, status: "idle" }),
}));

vi.mock("./hooks/useSessionList", () => ({
  useSessionList: () => ({
    clearAll: vi.fn(),
    deleteById: vi.fn(),
    error: null,
    isLoading: false,
    refresh: vi.fn(),
    resolvedUserId: "alice",
    sessions: [sessionsById.psw_kimi, sessionsById.psw_jimeng],
  }),
}));

vi.mock("./hooks/useCheckoutSession", () => ({
  useCheckoutSession: ({ sessionId }: { sessionId?: string }) => {
    const session = sessionId ? sessionsById[sessionId] : makeSession({ id: "", merchant: "暂无 Session" });
    return {
      activePath: ["Pay-Switch", session.merchant],
      connectLive: vi.fn(),
      connection: { status: "idle", message: "idle" },
      currentStage: getCurrentPaymentStage(session),
      isPlaying: false,
      play: vi.fn(),
      reset: vi.fn(),
      session,
    };
  },
}));

vi.mock("./lib/sessionSnapshot", () => ({
  selectSessionDisplay: (...args: unknown[]) => selectSessionDisplayMock(...args),
}));

import App from "./App";

describe("App session display ownership", () => {
  beforeEach(() => {
    selectSessionDisplayMock.mockReset();
    selectSessionDisplayMock.mockResolvedValue(null);
    window.history.replaceState(null, "", "/pay-switch?user_id=alice");
  });

  it("switches the selected session and updates the visible display state", async () => {
    render(<App />);

    await waitFor(() => {
      expect(screen.getByText("Kimi monthly")).toBeInTheDocument();
      expect(screen.getByRole("link", { name: "打开当前 Session" })).toHaveAttribute(
        "href",
        "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_kimi",
      );
    });

    fireEvent.click(screen.getByRole("button", { name: /Jimeng/i }));

    await waitFor(() => {
      expect(screen.getByText("Jimeng recharge")).toBeInTheDocument();
      expect(screen.getAllByText("等待前台").length).toBeGreaterThan(0);
      expect(screen.queryByRole("link", { name: "打开当前 Session" })).not.toBeInTheDocument();
    });

    expect(selectSessionDisplayMock).toHaveBeenCalledWith("/pay-switch", "psw_jimeng", {
      userId: "alice",
    });
  });

  it("persists inferred owner scope into the url even when the page did not start with user_id", async () => {
    window.history.replaceState(null, "", "/pay-switch");

    render(<App />);

    await waitFor(() => {
      expect(window.location.search).toContain("user_id=alice");
      expect(window.location.search).toContain("session_id=psw_kimi");
    });
  });
});
