/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_PAYSWITCH_EVENTS_URL?: string;
  readonly VITE_PAYSWITCH_API_URL?: string;
  readonly VITE_PAYSWITCH_HEALTH_URL?: string;
  readonly VITE_PAYSWITCH_NOVNC_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
