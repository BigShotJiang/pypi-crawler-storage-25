import { useCallback, useEffect, useMemo, useState } from "react";

import { clearAllSessions, deleteSession, fetchSessionSnapshots } from "../lib/sessionSnapshot";
import type { CheckoutSession } from "../lib/sessionModel";

interface UseSessionListOptions {
  apiUrl?: string;
  pollIntervalMs?: number;
  userId?: string;
}

export interface SessionListState {
  clearAll: () => Promise<void>;
  deleteById: (sessionId: string) => Promise<void>;
  error: string | null;
  isLoading: boolean;
  refresh: () => Promise<void>;
  resolvedUserId?: string;
  sessions: CheckoutSession[];
}

function inferSingleSessionOwner(sessions: CheckoutSession[]): string | undefined {
  const owners = Array.from(
    new Set(
      sessions
        .map((session) => session.userId?.trim())
        .filter((value): value is string => Boolean(value)),
    ),
  );
  return owners.length === 1 ? owners[0] : undefined;
}

export function useSessionList({
  apiUrl,
  pollIntervalMs = 5000,
  userId,
}: UseSessionListOptions): SessionListState {
  const [sessions, setSessions] = useState<CheckoutSession[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const resolvedUserId = useMemo(() => userId ?? inferSingleSessionOwner(sessions), [sessions, userId]);

  const refresh = useCallback(async () => {
    if (!apiUrl) {
      setSessions([]);
      return;
    }

    setIsLoading(true);
    try {
      const nextSessions = await fetchSessionSnapshots(apiUrl, { userId: resolvedUserId });
      setSessions(nextSessions);
      setError(null);
    } catch (refreshError) {
      setSessions([]);
      setError(refreshError instanceof Error ? refreshError.message : "读取 Session 列表失败。");
    } finally {
      setIsLoading(false);
    }
  }, [apiUrl, resolvedUserId]);

  useEffect(() => {
    void refresh();
    if (!pollIntervalMs) {
      return undefined;
    }
    const interval = window.setInterval(() => void refresh(), pollIntervalMs);
    return () => window.clearInterval(interval);
  }, [pollIntervalMs, refresh]);

  const deleteById = useCallback(
    async (sessionId: string) => {
      if (!apiUrl) return;
      await deleteSession(apiUrl, sessionId, { userId: resolvedUserId });
      await refresh();
    },
    [apiUrl, refresh, resolvedUserId],
  );

  const clearAll = useCallback(async () => {
    if (!apiUrl) return;
    await clearAllSessions(apiUrl, { userId: resolvedUserId });
    await refresh();
  }, [apiUrl, refresh, resolvedUserId]);

  return useMemo(
    () => ({ clearAll, deleteById, error, isLoading, refresh, resolvedUserId, sessions }),
    [clearAll, deleteById, error, isLoading, refresh, resolvedUserId, sessions],
  );
}
