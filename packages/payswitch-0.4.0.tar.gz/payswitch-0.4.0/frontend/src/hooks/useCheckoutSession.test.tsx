import { act, renderHook } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { useCheckoutSession } from "./useCheckoutSession";

class FakeEventSource {
  static instances: FakeEventSource[] = [];
  onopen: (() => void) | null = null;
  onmessage: ((event: MessageEvent<string>) => void) | null = null;
  onerror: (() => void) | null = null;
  closed = false;

  constructor(public readonly url: string) {
    FakeEventSource.instances.push(this);
  }

  emit(data: string) {
    this.onmessage?.({ data } as MessageEvent<string>);
  }

  close() {
    this.closed = true;
  }
}

describe("useCheckoutSession", () => {
  afterEach(() => {
    FakeEventSource.instances = [];
    vi.unstubAllGlobals();
  });

  it("connects to SSE and applies incoming payment events", async () => {
    vi.stubGlobal("EventSource", FakeEventSource);

    const { result } = renderHook(() =>
      useCheckoutSession({
        eventStreamUrl: "http://localhost:8787/events",
        sessionId: "txn_live_0428",
        userId: "alice",
      }),
    );

    await act(async () => {
      await result.current.connectLive();
    });

    expect(FakeEventSource.instances[0]?.url).toBe(
      "http://localhost:8787/events?session_id=txn_live_0428&user_id=alice",
    );
    expect(result.current.connection.status).toBe("connecting");

    act(() => {
      FakeEventSource.instances[0]?.emit(
        JSON.stringify({
          type: "human.gate",
          summary: "等待扫码确认",
          message: "二维码已展示，最终授权交给用户。",
          source: "human",
          path: ["Codex", "Pay-Switch", "Human Gate"],
        }),
      );
    });

    expect(result.current.connection.status).toBe("connected");
    expect(result.current.currentStage.label).toBe("已交付人工授权");
    expect(result.current.session.summary.humanGates).toBe(1);
  });

  it("does not connect live stream before a real session is selected", async () => {
    vi.stubGlobal("EventSource", FakeEventSource);

    const { result } = renderHook(() =>
      useCheckoutSession({ eventStreamUrl: "http://localhost:8787/events" }),
    );

    await act(async () => {
      await result.current.connectLive();
    });

    expect(FakeEventSource.instances).toHaveLength(0);
    expect(result.current.session.id).toBe("");
    expect(result.current.connection.message).toContain("暂无运行 Session");
  });

  it("uses the requested live session id when provided by the app", async () => {
    vi.stubGlobal("EventSource", FakeEventSource);

    const { result } = renderHook(() =>
      useCheckoutSession({
        eventStreamUrl: "http://localhost:8787/events",
        sessionId: "txn_kimi_123",
        userId: "alice",
      }),
    );

    await act(async () => {
      await result.current.connectLive();
    });

    expect(result.current.session.id).toBe("txn_kimi_123");
    expect(FakeEventSource.instances[0]?.url).toBe(
      "http://localhost:8787/events?session_id=txn_kimi_123&user_id=alice",
    );
  });

  it("reports unavailable live mode when no stream url is configured", async () => {
    const { result } = renderHook(() =>
      useCheckoutSession({ eventStreamUrl: undefined, sessionId: "txn_kimi_123" }),
    );

    await act(async () => {
      await result.current.connectLive();
    });

    expect(result.current.connection.status).toBe("unavailable");
    expect(result.current.connection.message).toContain("Pay-Switch SSE");
  });

  it("does not open SSE when the scoped snapshot request fails", async () => {
    vi.stubGlobal("EventSource", FakeEventSource);
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        json: async () => ({ detail: "session detail requires user_id for scoped session access" }),
        ok: false,
        status: 409,
      })),
    );

    const { result } = renderHook(() =>
      useCheckoutSession({
        apiUrl: "https://panel.example",
        eventStreamUrl: "http://localhost:8787/events",
        sessionId: "txn_kimi_123",
        userId: "alice",
      }),
    );

    await act(async () => {
      await result.current.connectLive();
    });

    expect(fetch).toHaveBeenCalledWith(
      "https://panel.example/api/sessions/txn_kimi_123?user_id=alice",
      { headers: { "Content-Type": "application/json" } },
    );
    expect(FakeEventSource.instances).toHaveLength(0);
    expect(result.current.connection.status).toBe("error");
    expect(result.current.connection.message).toContain("requires user_id");
  });
});
