import { useEffect, useRef, useState } from "react";

interface ScreenshotStreamResult {
  /** 最新一帧截图的 base64 data URI，null 表示尚无帧 */
  latestFrame: string | null;
  /** 是否正在等待首帧 */
  isLoading: boolean;
  /** 已接收帧数 */
  frameCount: number;
}

/**
 * 截图流 hook — 连接 SSE /task/{taskId}/screenshots 端点，
 * 接收 base64 JPEG 截图并返回最新一帧。
 *
 * @param taskId  任务 ID，为 null 时不连接
 * @param enabled 是否启用截图流（仅在实时模式下启用）
 */
export function useScreenshotStream(
  taskId: string | null,
  enabled: boolean,
): ScreenshotStreamResult {
  const [latestFrame, setLatestFrame] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [frameCount, setFrameCount] = useState(0);
  const eventSourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    if (!enabled || !taskId) {
      setLatestFrame(null);
      setIsLoading(false);
      setFrameCount(0);
      return undefined;
    }

    // 构建截图流 SSE URL
    const baseUrl = import.meta.env.VITE_PAYSWITCH_API_URL ?? "";
    const url = `${baseUrl}/task/${taskId}/screenshots`;

    setIsLoading(true);

    const source = new EventSource(url);
    eventSourceRef.current = source;

    source.onmessage = (message) => {
      try {
        const data = JSON.parse(message.data);
        if (data.data) {
          // base64 JPEG → data URI
          setLatestFrame(`data:image/jpeg;base64,${data.data}`);
          setFrameCount((prev) => prev + 1);
          setIsLoading(false);
        }
      } catch {
        // 解析失败，忽略此帧
      }
    };

    source.onerror = () => {
      setIsLoading(false);
      source.close();
      eventSourceRef.current = null;
    };

    return () => {
      source.close();
      eventSourceRef.current = null;
    };
  }, [taskId, enabled]);

  return { latestFrame, isLoading, frameCount };
}
