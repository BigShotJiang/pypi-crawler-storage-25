import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { demoEvents } from "../lib/demoSession";
import { buildEventStreamUrl, parseStreamMessage } from "../lib/eventStream";
import { fetchSessionSnapshot, resolveRuntimeApiBaseUrl } from "../lib/sessionSnapshot";
import {
  buildEmptySession,
  buildInitialSession,
  getActivePath,
  getCurrentPaymentStage,
  reduceSessionEvent,
} from "../lib/sessionModel";

type ConnectionStatus =
  | "idle"
  | "demo"
  | "connecting"
  | "connected"
  | "error"
  | "unavailable";

export interface LiveConnection {
  status: ConnectionStatus;
  message: string;
}

interface UseCheckoutSessionOptions {
  eventStreamUrl?: string;
  apiUrl?: string;
  sessionId?: string;
  userId?: string;
  autoConnect?: boolean;
}

const idleConnection: LiveConnection = {
  status: "idle",
  message: "可连接 Pay-Switch Agent 实时流，也可以播放内置演示。",
};

export function useCheckoutSession({
  eventStreamUrl,
  apiUrl,
  sessionId,
  userId,
  autoConnect = false,
}: UseCheckoutSessionOptions) {
  const eventSourceRef = useRef<EventSource | null>(null);
  const autoConnectSessionRef = useRef<string | null>(null);
  const streamEventIndexRef = useRef(0);
  const initialSession = useCallback(
    () => (sessionId ? buildInitialSession({ id: sessionId }) : buildEmptySession()),
    [sessionId],
  );
  const [connection, setConnection] = useState<LiveConnection>(idleConnection);
  const [isPlaying, setIsPlaying] = useState(false);
  const [runStartedAt, setRunStartedAt] = useState<number | null>(null);
  const [session, setSession] = useState(initialSession);

  const closeLiveStream = useCallback(() => {
    eventSourceRef.current?.close();
    eventSourceRef.current = null;
  }, []);

  const reset = useCallback(() => {
    closeLiveStream();
    streamEventIndexRef.current = 0;
    setSession(initialSession());
    setRunStartedAt(null);
    setIsPlaying(false);
    setConnection(idleConnection);
  }, [closeLiveStream, initialSession]);

  useEffect(() => {
    closeLiveStream();
    streamEventIndexRef.current = 0;
    setSession(initialSession());
    setRunStartedAt(null);
    setIsPlaying(false);
    setConnection(idleConnection);
    autoConnectSessionRef.current = null;
  }, [closeLiveStream, initialSession]);

  const play = useCallback(() => {
    closeLiveStream();
    streamEventIndexRef.current = 0;
    setSession(initialSession());
    setRunStartedAt(Date.now());
    setIsPlaying(true);
    setConnection({
      status: "demo",
      message: "内置演示事件正在播放。",
    });
  }, [closeLiveStream, initialSession]);

  const connectLive = useCallback(async () => {
    closeLiveStream();
    setIsPlaying(false);
    setRunStartedAt(null);

    let nextSession = initialSession();
    let hasSnapshot = false;
    const runtimeApiUrl = apiUrl
      ? resolveRuntimeApiBaseUrl({
          explicitApiUrl: apiUrl,
          eventStreamUrl,
        })
      : "";
    if (runtimeApiUrl) {
      try {
        const snapshot = await fetchSessionSnapshot(runtimeApiUrl, sessionId, { userId });
        if (snapshot) {
          nextSession = snapshot;
          hasSnapshot = true;
        }
      } catch (error) {
        setConnection({
          status: "error",
          message:
            error instanceof Error ? error.message : "读取 Pay-Switch 交易快照失败。",
        });
        setSession(nextSession);
        return;
      }
    }

    setSession(nextSession);
    streamEventIndexRef.current = nextSession.events.length;

    if (sessionId && runtimeApiUrl && !hasSnapshot) {
      setConnection({
        status: "error",
        message: "读取不到所选 Session 快照，请刷新列表后重试。",
      });
      return;
    }

    if (!sessionId && !hasSnapshot) {
      setConnection({
        status: "idle",
        message: "暂无运行 Session。请先从左侧选择真实任务，或让外部 Agent 发起付款请求。",
      });
      return;
    }

    if (!eventStreamUrl) {
      setConnection({
        status: "unavailable",
        message: "未配置 Pay-Switch SSE 地址。",
      });
      return;
    }

    if (!window.EventSource) {
      setConnection({
        status: "unavailable",
        message: "当前浏览器不支持 EventSource，无法连接 SSE 实时流。",
      });
      return;
    }

    const source = new EventSource(
      buildEventStreamUrl(eventStreamUrl, nextSession.id, {
        replay: !hasSnapshot,
        userId,
      }),
    );
    eventSourceRef.current = source;

    setConnection({
      status: "connecting",
      message: "正在连接 Pay-Switch 实时事件流。",
    });

    source.onopen = () => {
      setConnection({
        status: "connected",
        message: "已连接真实事件流，界面会随后端事件实时更新。",
      });
    };

    source.onmessage = (message) => {
      try {
        const event = parseStreamMessage(message.data, streamEventIndexRef.current);
        streamEventIndexRef.current += 1;
        setSession((current) => reduceSessionEvent(current, event));
        setConnection({
          status: "connected",
          message: "已连接真实事件流，界面会随 Pay-Switch 后端实时更新。",
        });
      } catch (error) {
        setConnection({
          status: "error",
          message: error instanceof Error ? error.message : "实时事件解析失败。",
        });
      }
    };

    source.onerror = () => {
      setConnection({
        status: "error",
        message: "实时事件流连接中断，请检查 Pay-Switch Agent 服务。",
      });
      source.close();
      eventSourceRef.current = null;
    };
  }, [apiUrl, closeLiveStream, eventStreamUrl, initialSession, sessionId, userId]);

  useEffect(() => {
    if (!isPlaying || runStartedAt === null) {
      return undefined;
    }

    const advance = () => {
      const elapsedMs = Date.now() - runStartedAt;
      const availableEvents = demoEvents.filter((event) => event.delayMs <= elapsedMs);

      setSession((current) => {
        if (availableEvents.length <= current.events.length) {
          return current;
        }

        return availableEvents
          .slice(current.events.length)
          .reduce(reduceSessionEvent, current);
      });

      if (availableEvents.length === demoEvents.length) {
        setIsPlaying(false);
        setConnection({
          status: "idle",
          message: "内置演示已完成。",
        });
      }
    };

    advance();
    const interval = window.setInterval(advance, 200);

    return () => window.clearInterval(interval);
  }, [isPlaying, runStartedAt]);

  useEffect(() => {
    if (isPlaying || !apiUrl || !sessionId) {
      return undefined;
    }

    const runtimeApiUrl = resolveRuntimeApiBaseUrl({
      explicitApiUrl: apiUrl,
      eventStreamUrl,
    });
    if (!runtimeApiUrl) {
      return undefined;
    }

    let cancelled = false;
    const refreshSnapshot = async () => {
      try {
        const snapshot = await fetchSessionSnapshot(runtimeApiUrl, sessionId, { userId });
        if (!snapshot || cancelled) {
          return;
        }
        setSession((current) => {
          if (snapshot.events.length < current.events.length) {
            return current;
          }
          streamEventIndexRef.current = Math.max(
            streamEventIndexRef.current,
            snapshot.events.length,
          );
          return snapshot;
        });
      } catch {
        // SSE remains the primary live path; snapshot polling is a stale-state fallback.
      }
    };

    void refreshSnapshot();
    const interval = window.setInterval(refreshSnapshot, 3000);

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, [apiUrl, eventStreamUrl, isPlaying, sessionId, userId]);

  useEffect(() => closeLiveStream, [closeLiveStream]);

  useEffect(() => {
    const sessionKey = sessionId ?? "__latest__";
    if (!autoConnect || autoConnectSessionRef.current === sessionKey) {
      return;
    }
    autoConnectSessionRef.current = sessionKey;
    void connectLive();
  }, [autoConnect, connectLive, sessionId]);

  return useMemo(
    () => ({
      activePath: getActivePath(session),
      connectLive,
      connection,
      currentStage: getCurrentPaymentStage(session),
      isPlaying,
      play,
      reset,
      session,
    }),
    [connectLive, connection, isPlaying, play, reset, session],
  );
}
