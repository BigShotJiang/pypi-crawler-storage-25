import { useEffect, useState } from "react";

import type { AgentHealth, AgentHealthStatus } from "../lib/agentHealth";

interface UseAgentHealthResult {
  health: AgentHealth | null;
  status: AgentHealthStatus;
}

export function useAgentHealth(healthUrl?: string): UseAgentHealthResult {
  const [health, setHealth] = useState<AgentHealth | null>(null);
  const [status, setStatus] = useState<AgentHealthStatus>("idle");

  useEffect(() => {
    if (!healthUrl) {
      setHealth(null);
      setStatus("idle");
      return undefined;
    }

    const controller = new AbortController();
    setStatus("loading");

    fetch(healthUrl, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`health check returned ${response.status}`);
        }
        return response.json() as Promise<AgentHealth>;
      })
      .then((payload) => {
        setHealth(payload);
        setStatus("ready");
      })
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setHealth(null);
        setStatus("error");
      });

    return () => controller.abort();
  }, [healthUrl]);

  return { health, status };
}
