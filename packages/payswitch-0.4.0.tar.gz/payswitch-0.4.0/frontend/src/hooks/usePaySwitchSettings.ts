import { useCallback, useEffect, useMemo, useState } from "react";

import {
  type BrowserDoctor,
  type BrowserProfile,
  type SettingsConfig,
  type SettingsPayload,
  fetchBrowserDoctor,
  fetchBrowserProfiles,
  fetchSettings,
  patchBrowserProfile,
  patchSettings,
  postEnsureBrowserCdpProfile,
  postProjectProfile,
  resolveSettingsApiBaseUrl,
} from "../lib/settingsApi";

type SettingsStatus = "idle" | "loading" | "ready" | "saving" | "error";

export function usePaySwitchSettings({
  apiUrl,
  eventStreamUrl,
}: {
  apiUrl?: string;
  eventStreamUrl?: string;
}) {
  const baseUrl = useMemo(
    () => resolveSettingsApiBaseUrl({ explicitApiUrl: apiUrl, eventStreamUrl }),
    [apiUrl, eventStreamUrl],
  );
  const [payload, setPayload] = useState<SettingsPayload | null>(null);
  const [doctor, setDoctor] = useState<BrowserDoctor | null>(null);
  const [profiles, setProfiles] = useState<BrowserProfile[]>([]);
  const [status, setStatus] = useState<SettingsStatus>("idle");
  const [message, setMessage] = useState("设置 API 未连接");

  const refreshDoctor = useCallback(async () => {
    const next = await fetchBrowserDoctor(baseUrl);
    setDoctor(next);
    return next;
  }, [baseUrl]);

  const load = useCallback(async () => {
    setStatus("loading");
    try {
      const next = await fetchSettings(baseUrl);
      setPayload(next);
      await refreshDoctor();
      setStatus("ready");
      setMessage("已加载本地 Pay-Switch 配置");
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "加载设置失败");
    }
  }, [baseUrl, refreshDoctor]);

  const save = useCallback(
    async (updates: Partial<SettingsConfig>) => {
      setStatus("saving");
      try {
        const next = await patchSettings(baseUrl, updates);
        setPayload(next);
        await refreshDoctor();
        setStatus("ready");
        setMessage(`已保存：${next.updated.join(", ")}`);
      } catch (error) {
        setStatus("error");
        setMessage(error instanceof Error ? error.message : "保存设置失败");
      }
    },
    [baseUrl, refreshDoctor],
  );

  const loadProfiles = useCallback(
    async (browser: string, query?: string) => {
      setStatus((current) => (current === "idle" ? "loading" : current));
      try {
        const next = await fetchBrowserProfiles(baseUrl, { browser, query });
        setProfiles(next);
        setMessage(`发现 ${next.length} 个 ${browser} profile`);
      } catch (error) {
        setStatus("error");
        setMessage(error instanceof Error ? error.message : "读取 profile 失败");
      }
    },
    [baseUrl],
  );

  const bindProfile = useCallback(
    async (browser: string, profile: BrowserProfile, keepCdp: boolean) => {
      setStatus("saving");
      try {
        const next = await patchBrowserProfile(baseUrl, {
          browser,
          user_data_dir: profile.user_data_dir,
          profile_directory: profile.profile_directory,
          keep_cdp: keepCdp,
        });
        setPayload(next);
        await refreshDoctor();
        setStatus("ready");
        setMessage(`已绑定 ${profile.identity_label} / ${profile.profile_directory}`);
      } catch (error) {
        setStatus("error");
        setMessage(error instanceof Error ? error.message : "绑定 profile 失败");
      }
    },
    [baseUrl, refreshDoctor],
  );

  const configureProjectProfile = useCallback(
    async (ensure = false) => {
      setStatus("saving");
      try {
        const next = await postProjectProfile(baseUrl, { ensure, browser: "chrome" });
        setPayload(next);
        await refreshDoctor();
        setStatus("ready");
        setMessage(
          ensure
            ? `已启动项目专用 Profile：${next.project_profile.chrome_cdp_url || "等待 CDP"}`
            : `已绑定项目专用 Profile：${next.project_profile.profile_directory}`,
        );
      } catch (error) {
        setStatus("error");
        setMessage(error instanceof Error ? error.message : "配置项目 profile 失败");
      }
    },
    [baseUrl, refreshDoctor],
  );

  const ensureCdpProfile = useCallback(async () => {
    setStatus("saving");
    try {
      const next = await postEnsureBrowserCdpProfile(baseUrl);
      setPayload(next);
      await refreshDoctor();
      setStatus("ready");
      setMessage(`已启动/复用 Chrome CDP：${next.cdp_url}`);
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "启动 Chrome CDP 失败");
    }
  }, [baseUrl, refreshDoctor]);

  useEffect(() => {
    void load();
  }, [load]);

  return {
    baseUrl,
    bindProfile,
    configureProjectProfile,
    doctor,
    ensureCdpProfile,
    load,
    loadProfiles,
    message,
    payload,
    profiles,
    save,
    status,
  };
}
