import { act, renderHook } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { useSessionList } from "./useSessionList";

function jsonResponse(payload: unknown, status: number, ok: boolean) {
  return {
    json: async () => payload,
    ok,
    status,
  } as Response;
}

describe("useSessionList", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("loads session list for current scope", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        jsonResponse(
          {
            sessions: [
              { id: "psw_1", merchant: "kimi", status: "running", reason: "", amount: 9, currency: "CNY", events: [] },
            ],
          },
          200,
          true,
        ),
      ),
    );

    const { result } = renderHook(() =>
      useSessionList({ apiUrl: "https://example.test", userId: "alice", pollIntervalMs: 0 }),
    );

    await act(async () => {
      await result.current.refresh();
    });

    expect(result.current.sessions).toHaveLength(1);
    expect(result.current.sessions[0]?.id).toBe("psw_1");
    expect(result.current.error).toBeNull();
    expect(result.current.resolvedUserId).toBe("alice");
  });

  it("clears stale list when session list request fails", async () => {
    let callCount = 0;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url: string) => {
        callCount += 1;
        if (callCount <= 2) {
          return jsonResponse(
            {
              sessions: [
                {
                  id: "psw_1",
                  merchant: "kimi",
                  status: "running",
                  reason: "",
                  amount: 9,
                  currency: "CNY",
                  events: [],
                },
              ],
            },
            200,
            true,
          );
        }

        return jsonResponse(
          {
            detail: "sessions list is ambiguous without user_id; provide user_id explicitly",
          },
          409,
          false,
        );
      }),
    );

    const { result } = renderHook(() =>
      useSessionList({ apiUrl: "https://example.test", pollIntervalMs: 0 }),
    );

    await act(async () => {
      await result.current.refresh();
    });

    expect(result.current.sessions).toHaveLength(1);

    await act(async () => {
      await result.current.refresh();
    });

    expect(result.current.sessions).toHaveLength(0);
    expect(result.current.error).toContain("provide user_id explicitly");
  });

  it("infers a single session owner and reuses it for deletes", async () => {
    const fetchMock = vi.fn(async (url: string, options?: RequestInit) => {
      if (url === "https://example.test/api/sessions/psw_1?user_id=alice") {
        return jsonResponse({}, 200, true);
      }
      if (url === "https://example.test/api/sessions") {
        return jsonResponse(
          {
            sessions: [
              {
                id: "psw_1",
                merchant: "kimi",
                status: "running",
                reason: "",
                amount: 9,
                currency: "CNY",
                user_id: "alice",
                events: [],
              },
            ],
          },
          200,
          true,
        );
      }
      if (url === "https://example.test/api/sessions?user_id=alice") {
        return jsonResponse(
          {
            sessions: options?.method === "DELETE"
              ? []
              : [
                  {
                    id: "psw_1",
                    merchant: "kimi",
                    status: "running",
                    reason: "",
                    amount: 9,
                    currency: "CNY",
                    user_id: "alice",
                    events: [],
                  },
                ],
          },
          200,
          true,
        );
      }
      throw new Error(`unexpected fetch: ${url}`);
    });
    vi.stubGlobal("fetch", fetchMock);

    const { result } = renderHook(() =>
      useSessionList({ apiUrl: "https://example.test", pollIntervalMs: 0 }),
    );

    await act(async () => {
      await result.current.refresh();
    });
    await act(async () => {
      await result.current.deleteById("psw_1");
    });

    expect(fetchMock).toHaveBeenCalledWith("https://example.test/api/sessions", {
      headers: { "Content-Type": "application/json" },
    });
    expect(fetchMock).toHaveBeenCalledWith("https://example.test/api/sessions?user_id=alice", {
      headers: { "Content-Type": "application/json" },
    });
    expect(fetchMock).toHaveBeenCalledWith("https://example.test/api/sessions/psw_1?user_id=alice", {
      method: "DELETE",
    });
  });
});
