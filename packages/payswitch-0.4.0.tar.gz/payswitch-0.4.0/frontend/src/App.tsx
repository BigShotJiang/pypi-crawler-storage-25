import "./App.css";

import { useCallback, useEffect, useState } from "react";

import { BrowserPreview } from "./components/BrowserPreview";
import { AgentInstallPanel } from "./components/AgentInstallPanel";
import { FlowMap } from "./components/FlowMap";
import { Header } from "./components/Header";
import { HumanGateModal } from "./components/HumanGateModal";
import { LiveTimeline } from "./components/LiveTimeline";
import { PaymentPanel } from "./components/PaymentPanel";
import { SettingsPanel } from "./components/SettingsPanel";
import { SessionSidebar } from "./components/SessionSidebar";
import { inferEventsUrlFromCurrentLocation, resolveSettingsApiBaseUrl } from "./lib/settingsApi";
import { useAgentHealth } from "./hooks/useAgentHealth";
import { useCheckoutSession } from "./hooks/useCheckoutSession";
import { useSessionList } from "./hooks/useSessionList";
import { selectSessionDisplay } from "./lib/sessionSnapshot";

export default function App() {
  const runtimeEventStreamUrl = import.meta.env.VITE_PAYSWITCH_EVENTS_URL?.trim();
  const eventStreamUrl = runtimeEventStreamUrl?.length
    ? runtimeEventStreamUrl
    : inferEventsUrlFromCurrentLocation(window.location.pathname);
  const apiUrl = resolveSettingsApiBaseUrl({
    explicitApiUrl: import.meta.env.VITE_PAYSWITCH_API_URL?.trim(),
    eventStreamUrl,
  });
  const healthUrl =
    import.meta.env.VITE_PAYSWITCH_HEALTH_URL?.trim() ??
    (apiUrl ? `${apiUrl}/api/health` : `${eventStreamUrl.replace(/\/events\/?$/, "")}/api/health`);
  const noVncUrl = import.meta.env.VITE_PAYSWITCH_NOVNC_URL;
  const agentHealth = useAgentHealth(healthUrl);
  const params = new URLSearchParams(window.location.search);
  const initialSessionId = params.get("session_id") ?? import.meta.env.VITE_PAYSWITCH_SESSION_ID;
  const userId = params.get("user_id") ?? import.meta.env.VITE_PAYSWITCH_USER_ID;
  const initialView = params.get("view") === "settings" ? "settings" : "runtime";
  const [view, setView] = useState<"runtime" | "settings">(initialView);
  const [selectedSessionId, setSelectedSessionId] = useState<string | undefined>(initialSessionId);
  const sessionList = useSessionList({ apiUrl, userId });
  const resolvedUserId = sessionList.resolvedUserId ?? userId;
  const selectSession = useCallback((nextSessionId: string) => {
    void selectSessionDisplay(apiUrl, nextSessionId, { userId: resolvedUserId }).catch(() => {
      // Snapshot polling and SSE remain the durable truth; selection failures surface there.
    });
    setSelectedSessionId(nextSessionId);
    const nextUrl = new URL(window.location.href);
    nextUrl.searchParams.set("session_id", nextSessionId);
    if (resolvedUserId) {
      nextUrl.searchParams.set("user_id", resolvedUserId);
    }
    window.history.replaceState(null, "", nextUrl);
  }, [apiUrl, resolvedUserId]);

  useEffect(() => {
    if (!resolvedUserId) {
      return;
    }
    const nextUrl = new URL(window.location.href);
    if (nextUrl.searchParams.get("user_id") === resolvedUserId) {
      return;
    }
    nextUrl.searchParams.set("user_id", resolvedUserId);
    window.history.replaceState(null, "", nextUrl);
  }, [resolvedUserId]);

  useEffect(() => {
    if (selectedSessionId || sessionList.sessions.length === 0) {
      return;
    }
    if (!resolvedUserId && sessionList.sessions.length > 1) {
      return;
    }
    selectSession(sessionList.sessions[0].id);
  }, [resolvedUserId, selectSession, selectedSessionId, sessionList.sessions]);

  const { activePath, connectLive, connection, currentStage, isPlaying, play, reset, session } =
    useCheckoutSession({
      apiUrl,
      autoConnect: Boolean(eventStreamUrl && selectedSessionId),
      eventStreamUrl,
      sessionId: selectedSessionId,
      userId: resolvedUserId,
    });

  useEffect(() => {
    if (!selectedSessionId || sessionList.isLoading) {
      return;
    }
    if (sessionList.sessions.some((item) => item.id === selectedSessionId)) {
      return;
    }
    setSelectedSessionId(undefined);
    const nextUrl = new URL(window.location.href);
    nextUrl.searchParams.delete("session_id");
    window.history.replaceState(null, "", nextUrl);
  }, [selectedSessionId, sessionList.isLoading, sessionList.sessions]);

  return (
    <div className="app-shell">
      <Header
        connection={connection}
        isPlaying={isPlaying}
        view={view}
        onConnectLive={connectLive}
        onPlay={play}
        onReset={reset}
        onShowRuntime={() => setView("runtime")}
        onShowSettings={() => setView("settings")}
      />
      {view === "settings" ? (
        <SettingsPanel apiUrl={apiUrl} eventStreamUrl={eventStreamUrl} />
      ) : (
        <main className="workspace">
          <SessionSidebar
            isLoadingSessions={sessionList.isLoading}
            onClearSessions={sessionList.clearAll}
            onDeleteSession={sessionList.deleteById}
            onRefreshSessions={sessionList.refresh}
            onSelectSession={selectSession}
            selectedSessionId={selectedSessionId}
            session={session}
            sessionListError={sessionList.error}
            sessions={sessionList.sessions}
          />
          <section className="main-column">
            <FlowMap activePath={activePath} />
            <BrowserPreview
              agentHealth={agentHealth.health}
              healthStatus={agentHealth.status}
              noVncUrl={noVncUrl}
              session={session}
            />
            <AgentInstallPanel />
            <LiveTimeline events={session.events} />
          </section>
          <PaymentPanel currentStage={currentStage} session={session} />
        </main>
      )}
      {view === "runtime" ? <HumanGateModal session={session} /> : null}
    </div>
  );
}
