import { ArrowRight, Bot, Database, Fingerprint, Globe2, Shield, UserCheck } from "lucide-react";

interface FlowMapProps {
  activePath: string[];
}

const nodes = [
  { label: "Codex", icon: Bot },
  { label: "Pay-Switch", icon: Shield },
  { label: "Guard", icon: Fingerprint },
  { label: "Browser", icon: Globe2 },
  { label: "Human Gate", icon: UserCheck },
  { label: "Ledger", icon: Database },
];

export function FlowMap({ activePath }: FlowMapProps) {
  const activeSet = new Set(activePath);

  return (
    <section className="flow-panel panel" aria-label="实时行为路径">
      <div className="panel-title">
        <div>
          <h2>实时行为路径</h2>
          <p>{activePath.join(" / ")}</p>
        </div>
        <ArrowRight size={18} />
      </div>

      <div className="flow-grid">
        {nodes.map((node, index) => {
          const Icon = node.icon;
          const active = activeSet.has(node.label);
          return (
            <div className="flow-node-wrap" key={node.label}>
              <div className={active ? "flow-node active" : "flow-node"}>
                <Icon size={18} />
                <span>{node.label}</span>
              </div>
              {index < nodes.length - 1 ? <span className={active ? "flow-link active" : "flow-link"} /> : null}
            </div>
          );
        })}
      </div>
    </section>
  );
}
