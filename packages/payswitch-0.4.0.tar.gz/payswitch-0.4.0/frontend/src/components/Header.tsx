import { Play, Radio, RotateCcw, Settings, ShieldCheck } from "lucide-react";

import type { LiveConnection } from "../hooks/useCheckoutSession";

interface HeaderProps {
  connection: LiveConnection;
  isPlaying: boolean;
  view: "runtime" | "settings";
  onConnectLive: () => void;
  onPlay: () => void;
  onReset: () => void;
  onShowRuntime: () => void;
  onShowSettings: () => void;
}

export function Header({
  connection,
  isPlaying,
  view,
  onConnectLive,
  onPlay,
  onReset,
  onShowRuntime,
  onShowSettings,
}: HeaderProps) {
  const liveLabel = connection.status === "connected" ? "已连接" : "连接实时流";

  return (
    <header className="app-header">
      <div className="brand">
        <span className="brand-mark">
          <ShieldCheck size={21} strokeWidth={2.4} />
        </span>
        <div>
          <h1>Pay-Switch Control Plane</h1>
          <p>外部 Agent 支付请求的实时执行面板</p>
        </div>
        <span className={`connection-pill ${connection.status}`}>{connection.message}</span>
      </div>
      <div className="header-actions" aria-label="演示控制">
        <button
          className={`icon-button secondary ${view === "runtime" ? "active" : ""}`}
          type="button"
          onClick={onShowRuntime}
          title="查看实时执行面板"
        >
          <Radio size={17} />
          <span>运行面板</span>
        </button>
        <button
          className={`icon-button secondary ${view === "settings" ? "active" : ""}`}
          type="button"
          onClick={onShowSettings}
          title="配置浏览器和支付策略"
        >
          <Settings size={17} />
          <span>设置</span>
        </button>
        <button className="icon-button secondary" type="button" onClick={onReset} title="重置演示">
          <RotateCcw size={17} />
          <span>重置</span>
        </button>
        <button
          className="icon-button secondary"
          type="button"
          onClick={onConnectLive}
          title="连接 Pay-Switch SSE 实时流"
        >
          <Radio size={17} />
          <span>{liveLabel}</span>
        </button>
        <button className="icon-button primary" type="button" onClick={onPlay} disabled={isPlaying} title="启动实时演示">
          <Play size={17} fill="currentColor" />
          <span>{isPlaying ? "运行中" : "启动演示"}</span>
        </button>
      </div>
    </header>
  );
}
