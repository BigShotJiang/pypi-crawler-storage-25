import { ExternalLink, ShieldAlert } from "lucide-react";
import { useState } from "react";

import { hasReadySessionDisplay, resolveSessionDisplayUrl } from "../lib/sessionDisplay";
import type { CheckoutSession } from "../lib/sessionModel";

interface HumanGateModalProps {
  session: CheckoutSession;
}

/**
 * Human Gate 提示弹窗。
 *
 * `human_gate` 是已经到达扫码、登录、CVV、OTP 或最终确认的状态，用户需要直接在
 * noVNC 里处理，不应该再出现一个会误导用户点击“批准执行”的覆盖弹窗。
 * 这里仅保留未来 `action_proposed` 事件的提示能力。
 */
export function HumanGateModal({ session }: HumanGateModalProps) {
  const [dismissedEventId, setDismissedEventId] = useState<string | null>(null);

  const canShowProposal = session.status === "running" || session.status === "waiting_human";
  const pendingEvent = session.events.at(-1);
  const displayUrl = resolveSessionDisplayUrl(session, pendingEvent?.displayUrl);
  const canOpenDisplay = hasReadySessionDisplay(session, pendingEvent?.displayUrl);

  if (
    !canShowProposal ||
    !pendingEvent ||
    pendingEvent.kind !== "action_proposed" ||
    dismissedEventId === pendingEvent.id
  ) {
    return null;
  }

  return (
    <div className="human-gate-overlay">
      <div className="human-gate-modal panel">
        <div className="human-gate-header">
          <ShieldAlert size={24} />
          <h3>需要人工授权</h3>
        </div>

        <div className="human-gate-body">
          <div className="human-gate-info">
            <div className="intent-row">
              <span>当前 Session</span>
              <strong>{session.id || "未命名 Session"}</strong>
            </div>
            <div className="intent-row">
              <span>目标商户</span>
              <strong>{session.merchant}</strong>
            </div>
            <div className="intent-row">
              <span>金额</span>
              <strong>
                {session.currency} {session.amount}
              </strong>
            </div>
            <div className="intent-row">
              <span>付款原因</span>
              <strong>{session.reason}</strong>
            </div>
            {pendingEvent && (
              <div className="human-gate-detail">
                <span>待确认操作</span>
                <strong>{pendingEvent.title}</strong>
                {pendingEvent.detail && <p>{pendingEvent.detail}</p>}
              </div>
            )}
          </div>

          <div className="human-gate-actions">
            <button
              className="icon-button secondary"
              onClick={() => setDismissedEventId(pendingEvent.id)}
              type="button"
            >
              <span>知道了</span>
            </button>
            {canOpenDisplay && displayUrl ? (
              <a
                className="icon-button primary"
                href={displayUrl}
                target="_blank"
                rel="noreferrer"
              >
                <ExternalLink size={16} />
                <span>打开实时窗口</span>
              </a>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
