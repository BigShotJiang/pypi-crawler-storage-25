import {
  CheckCircle2,
  CircleAlert,
  CircleDot,
  ExternalLink,
  Film,
  LockKeyhole,
  MousePointerClick,
  ShieldAlert,
  Wrench,
  XCircle,
} from "lucide-react";

import {
  describeCaptureEngine,
  describeCodecName,
  describeRecordingFormat,
  sortMediaArtifactsByRecordingIndex,
} from "../lib/browserRecording";
import { formatBitRate } from "../lib/formatBitRate";
import { formatBytes } from "../lib/formatBytes";
import { formatDurationSeconds } from "../lib/formatDuration";
import { formatFrameRate } from "../lib/formatFrameRate";
import { formatFrameSize } from "../lib/formatFrameSize";
import type { EventKind, SessionEvent } from "../lib/sessionModel";
import { ToolCallCard } from "./ToolCallCard";

interface LiveTimelineProps {
  events: SessionEvent[];
}

const eventIcons: Record<EventKind, React.ElementType> = {
  intent_received: CircleDot,
  guard_passed: CheckCircle2,
  route_selected: CheckCircle2,
  observe: CircleDot,
  action_proposed: MousePointerClick,
  action_allowed: CheckCircle2,
  action_blocked: CircleAlert,
  detection: CircleAlert,
  human_gate: LockKeyhole,
  completed: CheckCircle2,
  workspace_acquired: CircleDot,
  secret_delivered: LockKeyhole,
  media_persisted: CheckCircle2,
  // 新增：工具调用 + A2A 扩展状态
  tool_call_start: Wrench,
  tool_call_end: Wrench,
  auth_required: ShieldAlert,
  failed: XCircle,
  canceled: XCircle,
};

export function LiveTimeline({ events }: LiveTimelineProps) {
  return (
    <section className="timeline-panel panel" aria-label="实时事件流">
      <div className="panel-title compact">
        <div>
          <h2>实时事件流</h2>
          <p>每一次观察、提案、点击和拦截都会被记录</p>
        </div>
      </div>

      <div className="timeline">
        {events.length === 0 ? (
          <div className="empty-state">启动演示后，这里会像 Manus 一样滚动显示执行过程。</div>
        ) : (
          events.map((event) => {
            // 工具调用事件使用专用 ToolCallCard 组件
            const isToolCall = event.kind === "tool_call_start" || event.kind === "tool_call_end";
            if (isToolCall) {
              return <ToolCallCard event={event} key={event.id} />;
            }

            const Icon = eventIcons[event.kind];
            const isFailed = event.kind === "failed" || event.kind === "canceled";
            const extraClass = isFailed ? " event-failed" : "";
            return (
              <article
                className={`timeline-item risk-${event.risk ?? "low"}${extraClass}`}
                key={event.id}
              >
                <span className="timeline-icon">
                  <Icon size={16} />
                </span>
                <div>
                  <div className="timeline-top">
                    <strong>{event.title}</strong>
                    <time>{event.at}</time>
                  </div>
                  {event.detail && <p>{event.detail}</p>}
                  <span className="timeline-path">{event.path}</span>
                  {event.mediaArtifacts?.length ? (
                    <div className="timeline-artifacts">
                      {sortMediaArtifactsByRecordingIndex(event.mediaArtifacts)
                        .filter((artifact) => artifact.downloadUrl)
                        .map((artifact, index) => (
                          <a
                            className="timeline-artifact-link"
                            href={artifact.downloadUrl}
                            key={`${event.id}-artifact-${artifact.artifactId ?? index}`}
                            rel="noreferrer"
                            target="_blank"
                          >
                            <Film size={13} />
                            <span>{describeMediaArtifactLabel(artifact)}</span>
                            <ExternalLink size={12} />
                          </a>
                        ))}
                    </div>
                  ) : null}
                </div>
              </article>
            );
          })
        )}
      </div>
    </section>
  );
}

function describeMediaArtifactLabel(
  artifact: NonNullable<SessionEvent["mediaArtifacts"]>[number],
): string {
  const name = artifact.name ?? artifact.artifactId ?? "媒体证据";
  const recordingIndexLabel = artifact.recordingIndex !== undefined
    ? `#${artifact.recordingIndex}`
    : undefined;
  const screenshotSourceLabel = artifact.recordingSource === "observation_screenshots"
    && artifact.sourceScreenshotCount !== undefined
    ? `${artifact.sourceScreenshotCount} 截图`
    : undefined;

  if (artifact.recordingSource === "observation_screenshots") {
    return [
      name,
      "截图回放",
      recordingIndexLabel,
      screenshotSourceLabel,
      formatBytes(artifact.sizeBytes),
      formatDurationSeconds(artifact.durationSeconds),
      formatFrameSize(artifact.frameWidth, artifact.frameHeight),
      formatFrameRate(artifact.frameRate),
      formatBitRate(artifact.bitRate),
      describeCodecName(artifact.codecName),
      describeRecordingFormat(artifact.contentType),
      describeCaptureEngine(artifact.captureEngine),
    ].filter(Boolean).join(" · ");
  }

  if (artifact.recordingSource === "native_browser_video") {
    return [
      name,
      "浏览器录屏",
      recordingIndexLabel,
      screenshotSourceLabel,
      formatBytes(artifact.sizeBytes),
      formatDurationSeconds(artifact.durationSeconds),
      formatFrameSize(artifact.frameWidth, artifact.frameHeight),
      formatFrameRate(artifact.frameRate),
      formatBitRate(artifact.bitRate),
      describeCodecName(artifact.codecName),
      describeRecordingFormat(artifact.contentType),
      describeCaptureEngine(artifact.captureEngine),
    ].filter(Boolean).join(" · ");
  }

  return [
    name,
    recordingIndexLabel,
    screenshotSourceLabel,
    formatBytes(artifact.sizeBytes),
    formatDurationSeconds(artifact.durationSeconds),
    formatFrameSize(artifact.frameWidth, artifact.frameHeight),
    formatFrameRate(artifact.frameRate),
    formatBitRate(artifact.bitRate),
    describeCodecName(artifact.codecName),
    describeRecordingFormat(artifact.contentType),
    describeCaptureEngine(artifact.captureEngine),
  ].filter(Boolean).join(" · ");
}
