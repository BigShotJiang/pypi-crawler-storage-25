import { Check, Clock3, LockKeyhole } from "lucide-react";

import { paymentStages, type CheckoutSession, type PaymentStage } from "../lib/sessionModel";

interface PaymentPanelProps {
  currentStage: PaymentStage;
  session: CheckoutSession;
}

export function PaymentPanel({ currentStage, session }: PaymentPanelProps) {
  const currentIndex = paymentStages.findIndex((stage) => stage.id === currentStage.id);

  return (
    <aside className="payment-panel panel">
      <section className="stage-summary">
        <span className="stage-icon">
          {session.status === "waiting_human" ? <LockKeyhole size={20} /> : <Clock3 size={20} />}
        </span>
        <div>
          <span>当前付款阶段</span>
          <strong>{currentStage.label}</strong>
          <p>{currentStage.description}</p>
        </div>
      </section>

      <section className="stage-list" aria-label="付款阶段">
        {paymentStages.map((stage, index) => {
          const done = index < currentIndex || session.status === "completed";
          const active = index === currentIndex && session.status !== "completed";
          return (
            <div className={active ? "stage active" : "stage"} key={stage.id}>
              <span className={done ? "stage-dot done" : "stage-dot"}>
                {done ? <Check size={12} /> : index + 1}
              </span>
              <div>
                <strong>{stage.label}</strong>
                <p>{stage.description}</p>
              </div>
            </div>
          );
        })}
      </section>

      <section className="human-box">
        <div>
          <span>Human Gate 策略</span>
          <strong>最终授权不交给 Agent</strong>
        </div>
        <p>Pay-Switch 可以准备付款页、校验金额和记录证据，但扫码、密码、CVV、OTP 和最终确认必须由用户完成。</p>
      </section>
    </aside>
  );
}
