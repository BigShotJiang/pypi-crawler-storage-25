import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { buildInitialSession } from "../lib/sessionModel";
import type { CheckoutSession } from "../lib/sessionModel";
import { HumanGateModal } from "./HumanGateModal";

function makeWaitingSession(): CheckoutSession {
  return {
    ...buildInitialSession(),
    merchant: "kimi",
    amount: 49,
    status: "waiting_human",
    events: [
      {
        id: "evt-gate",
        at: "18:30:24",
        kind: "human_gate",
        title: "等待用户扫码确认",
        detail: "QR 检测器命中",
        actor: "human",
        path: "Codex / Pay-Switch / Human Gate",
        risk: "high",
      },
    ],
  };
}

function makeActionProposedSession(): CheckoutSession {
  return {
    ...buildInitialSession(),
    id: "psw_deepseek",
    merchant: "DeepSeek",
    amount: 200,
    reason: "购买年度会员",
    status: "running",
    displayReady: true,
    displayState: "visible_surface_ready",
    events: [
      {
        id: "evt-action",
        at: "18:30:24",
        kind: "action_proposed",
        title: "即将点击订阅按钮",
        detail: "外部 Agent 请求执行低风险点击",
        actor: "browser",
        path: "Codex / Pay-Switch / Browser",
        risk: "medium",
        displayUrl: "https://example.test/vnc",
      },
    ],
  };
}

describe("HumanGateModal", () => {
  it("does not render when session status is not waiting_human", () => {
    const session = buildInitialSession();
    const { container } = render(<HumanGateModal session={session} />);

    expect(container.querySelector(".human-gate-overlay")).not.toBeInTheDocument();
  });

  it("does not block human_gate sessions with an approval modal", () => {
    const session = makeWaitingSession();
    const { container } = render(<HumanGateModal session={session} />);

    expect(container.querySelector(".human-gate-overlay")).not.toBeInTheDocument();
    expect(screen.queryByText("批准执行")).not.toBeInTheDocument();
    expect(screen.queryByText("拒绝")).not.toBeInTheDocument();
  });

  it("does not show an older proposal after a human_gate event arrives", () => {
    const session: CheckoutSession = {
      ...makeActionProposedSession(),
      status: "waiting_human",
      events: [
        ...makeActionProposedSession().events,
        makeWaitingSession().events[0],
      ],
    };
    const { container } = render(<HumanGateModal session={session} />);

    expect(container.querySelector(".human-gate-overlay")).not.toBeInTheDocument();
    expect(screen.queryByText("即将点击订阅按钮")).not.toBeInTheDocument();
  });

  it("renders modal for future action_proposed events", () => {
    const session = makeActionProposedSession();
    render(<HumanGateModal session={session} />);

    expect(screen.getByText("需要人工授权")).toBeInTheDocument();
    expect(screen.getByText("打开实时窗口")).toBeInTheDocument();
    expect(screen.getByText("知道了")).toBeInTheDocument();
  });

  it("displays pending event details in modal", () => {
    const session = makeActionProposedSession();
    render(<HumanGateModal session={session} />);

    expect(screen.getByText("即将点击订阅按钮")).toBeInTheDocument();
    expect(screen.getByText("外部 Agent 请求执行低风险点击")).toBeInTheDocument();
  });

  it("shows merchant and amount info", () => {
    const session = makeActionProposedSession();
    render(<HumanGateModal session={session} />);

    expect(screen.getByText("DeepSeek")).toBeInTheDocument();
    expect(screen.getByText("CNY 200")).toBeInTheDocument();
    expect(screen.getByText("购买年度会员")).toBeInTheDocument();
  });

  it("names the current session and prefers the session display URL", () => {
    const session: CheckoutSession = {
      ...makeActionProposedSession(),
      id: "psw_deepseek_01",
      displayUrl: "https://panel.example/api/sessions/psw_deepseek_01/display/view?token=dsp_x",
    };
    render(<HumanGateModal session={session} />);

    expect(screen.getByText("psw_deepseek_01")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "打开实时窗口" })).toHaveAttribute(
      "href",
      "https://panel.example/api/sessions/psw_deepseek_01/display/view?token=dsp_x",
    );
  });

  it("does not expose a live display link when the session display is not ready", () => {
    const session: CheckoutSession = {
      ...makeActionProposedSession(),
      displayReady: false,
      displayState: "waiting_for_foreground",
      displayUrl: undefined,
      events: [
        {
          ...makeActionProposedSession().events[0],
          displayUrl: "https://example.test/not-ready",
        },
      ],
    };
    render(<HumanGateModal session={session} />);

    expect(screen.queryByRole("link", { name: "打开实时窗口" })).not.toBeInTheDocument();
  });
});
