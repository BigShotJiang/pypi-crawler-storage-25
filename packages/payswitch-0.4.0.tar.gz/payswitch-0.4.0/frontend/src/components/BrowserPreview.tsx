import {
  ExternalLink,
  Film,
  ImageOff,
  LockKeyhole,
  MonitorUp,
  MousePointer2,
  QrCode,
} from "lucide-react";

import type { AgentHealth, AgentHealthStatus } from "../lib/agentHealth";
import { resolveNoVncUrl, summarizeComputerUse } from "../lib/agentHealth";
import {
  hasReadySessionDisplay,
  resolveSessionDisplayUrl,
  summarizeSessionDisplay,
} from "../lib/sessionDisplay";
import {
  describeCaptureEngine,
  describeCodecName,
  findLatestVideoArtifact,
  findLatestVideoArtifacts,
  describeRecordingFormat,
} from "../lib/browserRecording";
import { formatBitRate } from "../lib/formatBitRate";
import { formatBytes } from "../lib/formatBytes";
import { formatDurationSeconds } from "../lib/formatDuration";
import { formatFrameRate } from "../lib/formatFrameRate";
import { formatFrameSize } from "../lib/formatFrameSize";
import type { CheckoutSession, SessionEvent } from "../lib/sessionModel";

interface BrowserPreviewProps {
  session: CheckoutSession;
  agentHealth?: AgentHealth | null;
  healthStatus?: AgentHealthStatus;
  noVncUrl?: string;
}

export function BrowserPreview({
  agentHealth,
  healthStatus = "idle",
  noVncUrl,
  session,
}: BrowserPreviewProps) {
  const latest = session.events.at(-1);
  const visual = findLatestVisualEvent(session.events);
  const humanGate = findLatestHumanGate(session.events);
  const target = latest?.target ?? "等待付款意图";
  const merchantLabel = session.merchant || "Pay-Switch";
  const computerUse = agentHealth?.computer_use;
  const display = computerUse?.display || ":99";
  const currentUrl = visual?.currentUrl ?? latest?.currentUrl ?? "等待浏览器页面";
  const sharedScreenUrl = resolveNoVncUrl(agentHealth, noVncUrl);
  const sharedScreenSummary =
    healthStatus === "error" ? "health unavailable" : summarizeComputerUse(agentHealth);
  const displayUrl = resolveSessionDisplayUrl(session, visual?.displayUrl, humanGate?.displayUrl);
  const canTakeOver = hasReadySessionDisplay(session, visual?.displayUrl, humanGate?.displayUrl);
  const isLive = session.status === "running" || session.status === "waiting_human";
  const emptyState = summarizeSessionDisplay(session, humanGate);
  const qrArtifactUrl = humanGate?.qrArtifactUrl;
  const latestVideoArtifacts = findLatestVideoArtifacts(session.events);
  const latestVideoArtifact = findLatestVideoArtifact(session.events);
  const artifactActions = [
    qrArtifactUrl
      ? {
          href: qrArtifactUrl,
          icon: QrCode,
          label: "打开二维码",
        }
      : null,
    ...latestVideoArtifacts.map((artifact) => ({
      href: artifact.downloadUrl!,
      icon: Film,
      label: describeBrowserRecordingAction(artifact),
    })),
  ].filter(Boolean) as Array<{
    href: string;
    icon: React.ElementType;
    label: string;
  }>;

  return (
    <section className="browser-panel panel live-screen-panel" aria-label="实时计算机屏幕">
      <div className="browser-toolbar">
        <span className="dot red" />
        <span className="dot yellow" />
        <span className="dot green" />
        <span className="url">{visual?.currentUrl ? currentUrl : `noVNC://PaySwitch/${display}/${merchantLabel}`}</span>
        {canTakeOver && displayUrl ? (
          <a className="screen-link" href={displayUrl} target="_blank" rel="noreferrer" title="在新窗口打开当前 Session 屏幕">
            <ExternalLink size={15} />
            <span>打开</span>
          </a>
        ) : null}
      </div>

      <div className="browser-body live">
        {isLive ? (
          <div className="browser-live-indicator" aria-label="运行状态">
            <span />
            {session.status === "waiting_human" ? "已交付用户处理" : "正在执行"}
          </div>
        ) : null}

        {session.displayReady && displayUrl ? (
          <iframe
            className="browser-takeover"
            src={displayUrl}
            title="Pay-Switch noVNC 接管窗口"
            allow="clipboard-read; clipboard-write; fullscreen"
          />
        ) : qrArtifactUrl ? (
          <img
            alt="Pay-Switch 支付二维码裁图"
            className="browser-screenshot"
            src={qrArtifactUrl}
          />
        ) : latestVideoArtifact?.downloadUrl ? (
          <video
            className="browser-video"
            controls
            preload="metadata"
            src={latestVideoArtifact.downloadUrl}
          />
        ) : visual?.screenshotUrl ? (
          <img
            alt="Pay-Switch 浏览器观察截图"
            className="browser-screenshot"
            src={visual.screenshotUrl}
          />
        ) : (
          <div className="browser-empty">
            <ImageOff size={26} />
            <strong>{emptyState.title}</strong>
            <p>{emptyState.detail}</p>
          </div>
        )}

        <div className="browser-status-strip">
          <span>
            <MousePointer2 size={16} />
            {target}
          </span>
          {canTakeOver ? (
            <span>
              <MonitorUp size={16} />
              {canTakeOver ? "noVNC 接管已就绪" : sharedScreenSummary}
            </span>
          ) : sharedScreenUrl ? (
            <span>
              <MonitorUp size={16} />
              等待当前 Session 接管链接
            </span>
          ) : null}
        </div>
      </div>

      {humanGate ? (
        <div className="human-gate-card">
          <span className="human-gate-icon">
            <LockKeyhole size={18} />
          </span>
          <div>
            <strong>{humanGate.title}</strong>
            <p>{humanGate.detail}</p>
            {humanGate.currentUrl ? <code>{humanGate.currentUrl}</code> : null}
          </div>
        </div>
      ) : null}

      {artifactActions.length ? (
        <div className="browser-artifact-actions">
          {artifactActions.map((action) => {
            const Icon = action.icon;
            return (
              <a
                className="browser-artifact-link"
                href={action.href}
                key={`${action.label}-${action.href}`}
                rel="noreferrer"
                target="_blank"
              >
                <Icon size={15} />
                <span>{action.label}</span>
                <ExternalLink size={13} />
              </a>
            );
          })}
        </div>
      ) : null}

      {visual?.paymentMethods?.length || visual?.interactionHints?.length ? (
        <div className="browser-insights">
          {visual.paymentMethods?.length ? (
            <div>
              <span>检测到支付方式</span>
              <strong>{visual.paymentMethods.join(" / ")}</strong>
            </div>
          ) : null}
          {visual.interactionHints?.length ? (
            <div>
              <span>页面闸门提示</span>
              <strong>{summarizeHint(visual.interactionHints[0])}</strong>
            </div>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function findLatestVisualEvent(events: SessionEvent[]): SessionEvent | undefined {
  return [...events]
    .reverse()
    .find((event) => event.screenshotUrl || event.displayUrl || event.currentUrl);
}

function findLatestHumanGate(events: SessionEvent[]): SessionEvent | undefined {
  return [...events].reverse().find((event) => event.kind === "human_gate");
}

function describeBrowserRecordingAction(
  artifact: NonNullable<ReturnType<typeof findLatestVideoArtifact>>,
): string {
  const baseLabel = artifact.recordingSource === "observation_screenshots"
    ? "打开回放"
    : "打开录屏";
  const recordingIndexLabel = artifact.recordingIndex !== undefined
    ? `#${artifact.recordingIndex}`
    : undefined;
  const screenshotSourceLabel = artifact.recordingSource === "observation_screenshots"
    && artifact.sourceScreenshotCount !== undefined
    ? `${artifact.sourceScreenshotCount} 截图`
    : undefined;
  return [
    artifact.name ? `${baseLabel} ${artifact.name}` : baseLabel,
    recordingIndexLabel,
    screenshotSourceLabel,
    formatBytes(artifact.sizeBytes),
    formatDurationSeconds(artifact.durationSeconds),
    formatFrameSize(artifact.frameWidth, artifact.frameHeight),
    formatFrameRate(artifact.frameRate),
    formatBitRate(artifact.bitRate),
    describeCodecName(artifact.codecName),
    describeRecordingFormat(artifact.contentType),
    describeCaptureEngine(artifact.captureEngine),
  ].filter(Boolean).join(" · ");
}

function summarizeHint(hint: Record<string, unknown>): string {
  const summary = hint.summary;
  if (typeof summary === "string" && summary.trim()) {
    return summary;
  }
  const kind = hint.kind;
  return typeof kind === "string" && kind.trim() ? kind : "需要用户确认后继续";
}
