import {
  Bot,
  CreditCard,
  ExternalLink,
  Gauge,
  ListTree,
  LockKeyhole,
  MonitorUp,
  ReceiptText,
  RefreshCw,
  Trash2,
  Wrench,
  X,
} from "lucide-react";

import { hasReadySessionDisplay, summarizeSessionDisplay } from "../lib/sessionDisplay";
import type { CheckoutSession } from "../lib/sessionModel";

interface SessionSidebarProps {
  isLoadingSessions?: boolean;
  onClearSessions?: () => void | Promise<void>;
  onDeleteSession?: (sessionId: string) => void | Promise<void>;
  onRefreshSessions?: () => void | Promise<void>;
  onSelectSession?: (sessionId: string) => void;
  selectedSessionId?: string;
  session: CheckoutSession;
  sessionListError?: string | null;
  sessions?: CheckoutSession[];
}

export function SessionSidebar({
  isLoadingSessions = false,
  onClearSessions,
  onDeleteSession,
  onRefreshSessions,
  onSelectSession,
  selectedSessionId,
  session,
  sessionListError,
  sessions = [],
}: SessionSidebarProps) {
  const statusLabels: Record<CheckoutSession["status"], string> = {
    idle: "待启动",
    running: "执行中",
    waiting_human: "已交付用户",
    completed: "已完成",
    submitted: "已提交",
    input_required: "等待输入",
    auth_required: "等待认证",
    failed: "已失败",
    canceled: "已取消",
  };
  const statusLabel = statusLabels[session.status];
  const selectedDisplay = summarizeSessionDisplay(session);

  return (
    <aside className="sidebar panel">
      <section className="session-picker">
        <div className="section-heading session-picker-heading">
          <span>
            <ListTree size={16} />
            <span>运行 Session</span>
          </span>
          <span className="session-heading-actions">
            {onClearSessions && sessions.length > 0 && (
              <button
                className="session-clear"
                disabled={isLoadingSessions}
                onClick={() => void onClearSessions()}
                type="button"
                title="清除全部 Session"
              >
                <Trash2 size={14} />
              </button>
            )}
            <button
              className="session-refresh"
              disabled={isLoadingSessions}
              onClick={() => void onRefreshSessions?.()}
              type="button"
              title="刷新 Session 列表"
            >
              <RefreshCw size={14} />
            </button>
          </span>
        </div>
        {sessionListError ? <p className="session-picker-error">{sessionListError}</p> : null}
        <div className="session-list">
          {sessions.length ? (
            sessions.map((item) => {
              const itemDisplay = summarizeSessionDisplay(item);
              return (
                <div
                  className={
                    item.id === selectedSessionId ? "session-list-item active" : "session-list-item"
                  }
                  key={item.id}
                >
                  <button
                    className="session-list-item-main"
                    onClick={() => onSelectSession?.(item.id)}
                    type="button"
                  >
                    <span className="session-list-item-top">
                      <strong>{item.merchant}</strong>
                      <code>{item.id}</code>
                    </span>
                    <small>
                      {statusLabels[item.status]} · {item.currency} {item.amount}
                    </small>
                    <small className="session-display-inline">
                      <span className={`session-display-badge ${itemDisplay.tone}`}>
                        {itemDisplay.label}
                      </span>
                      <span>{item.runtimeStatus === "online" ? "runtime 在线" : "runtime 未就绪"}</span>
                    </small>
                  </button>
                  {onDeleteSession && (
                    <button
                      className="session-delete-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        void onDeleteSession(item.id);
                      }}
                      type="button"
                      title="删除此 Session"
                    >
                      <X size={12} />
                    </button>
                  )}
                </div>
              );
            })
          ) : (
            <p className="session-picker-empty">
              {isLoadingSessions ? "正在读取..." : "暂无运行 Session"}
            </p>
          )}
        </div>
      </section>

      <section className="session-display-card">
        <div className="section-heading">
          <MonitorUp size={16} />
          <span>当前 Session 屏幕</span>
        </div>
        <div className="session-display-card-head">
          <strong>{session.merchant}</strong>
          <code>{session.id || "未选择 Session"}</code>
        </div>
        <div className="session-display-state">
          <span className={`session-display-badge ${selectedDisplay.tone}`}>
            {selectedDisplay.label}
          </span>
          <p>{selectedDisplay.detail}</p>
        </div>
        {hasReadySessionDisplay(session) && session.displayUrl ? (
          <a
            className="screen-link session-display-link"
            href={session.displayUrl}
            target="_blank"
            rel="noreferrer"
          >
            <ExternalLink size={14} />
            <span>打开当前 Session</span>
          </a>
        ) : null}
      </section>

      <section className="request-block">
        <div className="section-heading">
          <Bot size={16} />
          <span>调用来源</span>
        </div>
        <strong>{session.agent}</strong>
        <p>编译或运行项目时触发付款意图，由 Pay-Switch 接管支付执行。</p>
      </section>

      <section className="intent-box">
        <div className="intent-row">
          <span>目标</span>
          <strong>{session.merchant}</strong>
        </div>
        <div className="intent-row">
          <span>金额</span>
          <strong>
            {session.currency} {session.amount}
          </strong>
        </div>
        <div className="intent-row">
          <span>原因</span>
          <strong>{session.reason}</strong>
        </div>
      </section>

      <section className="metric-list">
        <Metric icon={<Gauge size={16} />} label="状态" value={statusLabel} />
        <Metric icon={<CreditCard size={16} />} label="允许动作" value={String(session.summary.allowedActions)} />
        <Metric icon={<LockKeyhole size={16} />} label="人工闸口" value={String(session.summary.humanGates)} />
        <Metric icon={<Wrench size={16} />} label="工具调用" value={String(session.summary.toolCalls)} />
        <Metric icon={<ReceiptText size={16} />} label="证据事件" value={String(session.events.length)} />
      </section>
    </aside>
  );
}

interface MetricProps {
  icon: React.ReactNode;
  label: string;
  value: string;
}

function Metric({ icon, label, value }: MetricProps) {
  return (
    <div className="metric">
      <span className="metric-icon">{icon}</span>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
