import {
  CreditCard,
  FolderPlus,
  MonitorCog,
  Play,
  RefreshCw,
  Save,
  Search,
  ShieldCheck,
} from "lucide-react";
import { useMemo, useState } from "react";

import { usePaySwitchSettings } from "../hooks/usePaySwitchSettings";
import type { SettingsConfig } from "../lib/settingsApi";

type SettingsDraft = Pick<
  SettingsConfig,
  | "browser_control_backend"
  | "chrome_cdp_url"
  | "computer_use_enabled"
  | "computer_use_driver"
  | "computer_use_max_autonomous_category"
  | "browser_engine"
  | "browser_humanize"
  | "browser_human_preset"
  | "max_per_transaction"
  | "daily_limit"
  | "auto_confirm_threshold"
  | "payment_priority"
  | "disabled_payment_methods"
  | "allow_card_number_only"
>;

export function SettingsPanel({
  apiUrl,
  eventStreamUrl,
}: {
  apiUrl?: string;
  eventStreamUrl?: string;
}) {
  const settings = usePaySwitchSettings({ apiUrl, eventStreamUrl });
  const config = settings.payload?.config;
  const options = settings.payload?.options;
  const [browser, setBrowser] = useState("chrome");
  const [profileQuery, setProfileQuery] = useState("");
  const [keepCdp, setKeepCdp] = useState(false);

  const draft = useMemo<SettingsDraft | null>(() => {
    if (!config) {
      return null;
    }
    return {
      browser_control_backend: config.browser_control_backend,
      chrome_cdp_url: config.chrome_cdp_url,
      computer_use_enabled: config.computer_use_enabled,
      computer_use_driver: config.computer_use_driver,
      computer_use_max_autonomous_category: config.computer_use_max_autonomous_category,
      browser_engine: config.browser_engine,
      browser_humanize: config.browser_humanize,
      browser_human_preset: config.browser_human_preset,
      max_per_transaction: config.max_per_transaction,
      daily_limit: config.daily_limit,
      auto_confirm_threshold: config.auto_confirm_threshold,
      payment_priority: config.payment_priority,
      disabled_payment_methods: config.disabled_payment_methods,
      allow_card_number_only: config.allow_card_number_only,
    };
  }, [config]);

  const [localDraft, setLocalDraft] = useState<SettingsDraft | null>(null);
  const editable = localDraft ?? draft;

  if (!config || !options || !editable) {
    return (
      <main className="settings-page">
        <section className="panel settings-hero">
          <h2>Pay-Switch 设置</h2>
          <p>{settings.message}</p>
          <button className="icon-button primary" type="button" onClick={settings.load}>
            <RefreshCw size={17} />
            <span>重新加载</span>
          </button>
        </section>
      </main>
    );
  }

  const updateDraft = <K extends keyof SettingsDraft>(key: K, value: SettingsDraft[K]) => {
    setLocalDraft({ ...editable, [key]: value });
  };

  const saveDraft = () => {
    void settings.save(editable);
    setLocalDraft(null);
  };

  return (
    <main className="settings-page">
      <section className="panel settings-hero">
        <div>
          <p className="eyebrow">Local Settings</p>
          <h2>配置真实浏览器、Browser Use 和支付策略</h2>
          <p>
            WebUI 负责选择和保存配置；Pay-Switch 后端负责读取本机 Chrome profile、
            校验身份、执行 Browser Doctor，并在敏感步骤停下。
          </p>
        </div>
        <span className={`doctor-badge ${settings.doctor?.runnable ? "ready" : "blocked"}`}>
          {settings.doctor?.runnable ? "可运行" : "需要处理"}
        </span>
      </section>

      <section className="settings-grid">
        <div className="panel settings-section">
          <div className="section-heading">
            <MonitorCog size={20} />
            <div>
              <h3>1. 项目专用 Chrome Profile</h3>
              <p>先创建 Pay-Switch 专用浏览器，再在这个浏览器里登录 Kimi、DeepSeek 等站点。</p>
            </div>
          </div>
          <div className="project-profile-card">
            <div>
              <span>项目 Profile</span>
              <strong>{config.chrome_profile_directory || "Default"}</strong>
              <small>
                {config.chrome_user_data_dir ||
                  `${config.data_dir}/browser/chrome-user-data`}
              </small>
            </div>
            <div>
              <span>CDP 状态</span>
              <strong>{config.chrome_cdp_url ? "已连接" : "未启动"}</strong>
              <small>{config.chrome_cdp_url || "点击启动后会打开专用 Chrome"}</small>
            </div>
          </div>
          <div className="project-profile-actions">
            <button
              className="icon-button secondary"
              type="button"
              onClick={() => void settings.configureProjectProfile(false)}
            >
              <FolderPlus size={17} />
              <span>仅保存专用 Profile</span>
            </button>
            <button
              className="icon-button primary"
              type="button"
              onClick={() => void settings.configureProjectProfile(true)}
            >
              <Play size={17} />
              <span>启动专用 Profile</span>
            </button>
            <button
              className="icon-button secondary"
              type="button"
              onClick={() => void settings.ensureCdpProfile()}
            >
              <Play size={17} />
              <span>启动已绑定 Profile</span>
            </button>
          </div>
          <p className="muted">
            启动后会复用同一个 CDP Chrome；下面的扫描列表只给需要绑定本机已有 Chrome profile 的高级场景使用。
          </p>
          <div className="current-profile">
            <span>当前绑定</span>
            <strong>{config.chrome_expected_profile_email || "未识别邮箱"}</strong>
            <small>
              {config.chrome_user_data_dir || "未设置 User Data"} /{" "}
              {config.chrome_profile_directory || "未设置 Profile"}
            </small>
          </div>
          <div className="settings-form-row">
            <label>
              浏览器
              <select value={browser} onChange={(event) => setBrowser(event.target.value)}>
                {options.browser_channels.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
            <label className="grow">
              搜索邮箱 / 昵称 / Profile
              <input
                value={profileQuery}
                onChange={(event) => setProfileQuery(event.target.value)}
                placeholder="例如 yuan80060@gmail.com 或 Profile 10"
              />
            </label>
            <button
              className="icon-button secondary"
              type="button"
              onClick={() => void settings.loadProfiles(browser, profileQuery)}
            >
              <Search size={17} />
              <span>扫描</span>
            </button>
          </div>
          <label className="checkbox-line">
            <input
              type="checkbox"
              checked={keepCdp}
              onChange={(event) => setKeepCdp(event.target.checked)}
            />
            绑定 profile 时保留现有 CDP 地址
          </label>
          <div className="profile-list" aria-label="Chrome profile 列表">
            {settings.profiles.map((profile) => (
              <button
                key={profile.id}
                className="profile-row"
                type="button"
                onClick={() => void settings.bindProfile(browser, profile, keepCdp)}
              >
                <span className="profile-index">{profile.index}</span>
                <span>
                  <strong>{profile.identity_label}</strong>
                  <small>{profile.profile_directory}</small>
                </span>
                <small>{profile.user_data_dir}</small>
              </button>
            ))}
            {settings.profiles.length === 0 ? (
              <p className="muted">点击“扫描”读取本机 Chrome profiles。</p>
            ) : null}
          </div>
        </div>

        <div className="panel settings-section">
          <div className="section-heading">
            <ShieldCheck size={20} />
            <div>
              <h3>2. Browser Use 执行方式</h3>
              <p>这里决定 Pay-Switch 怎么接管页面，不决定谁来思考下一步。</p>
            </div>
          </div>
          <div className="settings-form-row stacked">
            <label>
              浏览器接管后端
              <select
                value={editable.browser_control_backend}
                onChange={(event) =>
                  updateDraft("browser_control_backend", event.target.value)
                }
              >
                {options.browser_control_backends.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
            <label>
              浏览器 Engine
              <select
                value={editable.browser_engine}
                onChange={(event) => updateDraft("browser_engine", event.target.value)}
              >
                {options.browser_engines.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Humanize 预设
              <select
                value={editable.browser_human_preset}
                onChange={(event) =>
                  updateDraft("browser_human_preset", event.target.value)
                }
                disabled={editable.browser_engine !== "cloakbrowser"}
              >
                {options.browser_human_presets.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
            <label>
              CDP 地址
              <input
                value={editable.chrome_cdp_url}
                onChange={(event) => updateDraft("chrome_cdp_url", event.target.value)}
                placeholder="http://127.0.0.1:9222"
              />
            </label>
          </div>
          <label className="checkbox-line">
            <input
              type="checkbox"
              checked={editable.browser_humanize}
              disabled={editable.browser_engine !== "cloakbrowser"}
              onChange={(event) => updateDraft("browser_humanize", event.target.checked)}
            />
            启用 CloakBrowser 人类行为模拟
          </label>
          {editable.browser_control_backend === "cdp" ||
          editable.browser_control_backend === "ephemeral_cdp_mirror" ? (
            <p className="recommendation">
              当前后端是 CDP 连接模式：Pay-Switch 会接入已经启动的 Chrome/CDP
              进程，浏览器 Engine 不会替换底层浏览器。要实际使用 CloakBrowser，
              请切到 managed_profile 或 user_profile，并安装 payswitch[cloak]。
            </p>
          ) : null}
          {editable.browser_engine === "cloakbrowser" ? (
            <p className="muted">
              CloakBrowser 只降低浏览器指纹/反爬识别风险，不绕过交易风控；验证码、CVV、OTP
              和最终付款仍会进入 Human Gate。
            </p>
          ) : null}
          <div className="doctor-box">
            <strong>Browser Doctor</strong>
            <dl>
              <div>
                <dt>启动模式</dt>
                <dd>{settings.doctor?.launch_mode ?? "-"}</dd>
              </div>
              <div>
                <dt>识别邮箱</dt>
                <dd>{settings.doctor?.resolved_email || "未识别"}</dd>
              </div>
              <div>
                <dt>目录占用</dt>
                <dd>{settings.doctor?.active_process ? "是" : "否/未检测到"}</dd>
              </div>
            </dl>
            {settings.doctor?.problems.map((problem) => (
              <p className="problem" key={problem}>
                {problem}
              </p>
            ))}
            {settings.doctor?.recommendations.map((recommendation) => (
              <p className="recommendation" key={recommendation}>
                {recommendation}
              </p>
            ))}
          </div>
        </div>

        <div className="panel settings-section">
          <div className="section-heading">
            <MonitorCog size={20} />
            <div>
              <h3>3. Computer Use 驱动模式</h3>
              <p>external 是调用方 Agent 思考，Pay-Switch 执行和拦截；hybrid 后续再增强。</p>
            </div>
          </div>
          <label className="checkbox-line">
            <input
              type="checkbox"
              checked={editable.computer_use_enabled}
              onChange={(event) => updateDraft("computer_use_enabled", event.target.checked)}
            />
            启用未知站点兜底探索
          </label>
          <div className="settings-form-row">
            <label>
              驱动模式
              <select
                value={editable.computer_use_driver}
                onChange={(event) => updateDraft("computer_use_driver", event.target.value)}
              >
                {options.computer_use_drivers.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
            <label>
              自动推进上限
              <select
                value={editable.computer_use_max_autonomous_category}
                onChange={(event) =>
                  updateDraft("computer_use_max_autonomous_category", event.target.value)
                }
              >
                {options.step_categories.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </div>

        <div className="panel settings-section">
          <div className="section-heading">
            <CreditCard size={20} />
            <div>
              <h3>4. 支付策略</h3>
              <p>先控制限额和优先级；卡号/密钥只显示状态，明文配置仍走本机安全入口。</p>
            </div>
          </div>
          <div className="settings-form-row">
            <label>
              单笔限额
              <input
                type="number"
                min="0"
                value={editable.max_per_transaction}
                onChange={(event) =>
                  updateDraft("max_per_transaction", Number(event.target.value))
                }
              />
            </label>
            <label>
              日累计限额
              <input
                type="number"
                min="0"
                value={editable.daily_limit}
                onChange={(event) => updateDraft("daily_limit", Number(event.target.value))}
              />
            </label>
            <label>
              自动确认阈值
              <input
                type="number"
                min="0"
                value={editable.auto_confirm_threshold}
                onChange={(event) =>
                  updateDraft("auto_confirm_threshold", Number(event.target.value))
                }
              />
            </label>
          </div>
          <label className="checkbox-line">
            <input
              type="checkbox"
              checked={editable.allow_card_number_only}
              onChange={(event) => updateDraft("allow_card_number_only", event.target.checked)}
            />
            允许人工确认后仅代填卡号
          </label>
          <div className="secret-state">
            <span>LLM Key：{config.secrets.llm_api_key ? "已配置" : "未配置"}</span>
            <span>Stripe Key：{config.secrets.stripe_secret_key ? "已配置" : "未配置"}</span>
            <span>卡号工具：{config.card_instruments.length} 张</span>
          </div>
        </div>
      </section>

      <section className="settings-footer panel">
        <div>
          <strong>{settings.status}</strong>
          <p>{settings.message}</p>
        </div>
        <div className="header-actions">
          <button className="icon-button secondary" type="button" onClick={settings.load}>
            <RefreshCw size={17} />
            <span>重新加载</span>
          </button>
          <button className="icon-button primary" type="button" onClick={saveDraft}>
            <Save size={17} />
            <span>保存设置</span>
          </button>
        </div>
      </section>
    </main>
  );
}
