import { ChevronDown, ChevronRight, Wrench } from "lucide-react";
import { useState } from "react";

import type { SessionEvent } from "../lib/sessionModel";

interface ToolCallCardProps {
  event: SessionEvent;
}

/**
 * 工具调用卡片 — 在 LiveTimeline 中渲染 tool_call_start/end 事件。
 * 支持展开/收起，显示工具名称、参数和返回值。
 */
export function ToolCallCard({ event }: ToolCallCardProps) {
  const [expanded, setExpanded] = useState(false);
  const isEnd = event.kind === "tool_call_end";

  // 尝试解析 detail 中的 JSON（参数或返回值）
  let parsedDetail: string | null = null;
  if (event.detail) {
    try {
      const obj = JSON.parse(event.detail);
      parsedDetail = JSON.stringify(obj, null, 2);
    } catch {
      parsedDetail = event.detail;
    }
  }

  return (
    <article
      className={`timeline-item tool-call${isEnd ? " tool-call-end" : ""}`}
      key={event.id}
    >
      <span className="timeline-icon">
        <Wrench size={16} />
      </span>
      <div>
        <div className="timeline-top">
          <strong>{event.title}</strong>
          <time>{event.at}</time>
        </div>
        {/* 工具名称标签 */}
        {event.target && (
          <span className="tool-call-name">{event.target}</span>
        )}
        {/* 展开/收起按钮 */}
        {parsedDetail && (
          <button
            className="tool-call-toggle"
            onClick={() => setExpanded(!expanded)}
            type="button"
          >
            {expanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
            <span>{expanded ? "收起详情" : "展开详情"}</span>
          </button>
        )}
        {/* 展开后显示 JSON 详情 */}
        {expanded && parsedDetail && (
          <pre className="tool-call-detail">{parsedDetail}</pre>
        )}
        <span className="timeline-path">{event.path}</span>
      </div>
    </article>
  );
}
