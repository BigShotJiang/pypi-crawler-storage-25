import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { buildInitialSession, type CheckoutSession } from "../lib/sessionModel";
import { BrowserPreview } from "./BrowserPreview";

function makeSession(overrides: Partial<CheckoutSession> = {}): CheckoutSession {
  return {
    ...buildInitialSession(),
    id: "psw_kimi",
    merchant: "kimi",
    amount: 49,
    currency: "CNY",
    reason: "Kimi monthly",
    status: "running",
    events: [],
    ...overrides,
  };
}

describe("BrowserPreview", () => {
  it("shows a foreground wait reason instead of embedding a shared display", () => {
    render(
      <BrowserPreview
        session={makeSession({
          displayState: "waiting_for_foreground",
          displayReady: false,
          displayReason: "foreground_owned_by_task_a",
        })}
      />,
    );

    expect(screen.getByText("等待前台切换")).toBeInTheDocument();
    expect(screen.queryByTitle("Pay-Switch noVNC 接管窗口")).not.toBeInTheDocument();
  });

  it("embeds the scoped session display route once ready", () => {
    const { container } = render(
      <BrowserPreview
        session={makeSession({
          displayState: "visible_surface_ready",
          displayReady: true,
          displayUrl: "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_x",
        })}
      />,
    );

    const iframe = container.querySelector("iframe");
    expect(iframe).not.toBeNull();
    expect(iframe?.getAttribute("src")).toContain("/display/view?token=dsp_x");
  });

  it("does not show the open link before the session display is ready", () => {
    render(
      <BrowserPreview
        session={makeSession({
          displayState: "waiting_for_foreground",
          displayReady: false,
          displayUrl: "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_x",
        })}
      />,
    );

    expect(screen.queryByRole("link", { name: "打开" })).not.toBeInTheDocument();
  });

  it("shows qr artifact preview during a qr human gate before takeover is ready", () => {
    const { container } = render(
      <BrowserPreview
        session={makeSession({
          status: "waiting_human",
          events: [
            {
              id: "evt_qr_gate",
              at: "10:00:00",
              kind: "human_gate",
              title: "等待扫码付款",
              detail: "请扫码完成支付",
              actor: "human",
              path: "External Agent / Pay-Switch / Human Gate",
              target: "scan_qr",
              qrArtifactUrl: "https://panel.example/evidence?path=/tmp/qr.png",
            },
          ],
        })}
      />,
    );

    const image = container.querySelector("img");
    expect(image).not.toBeNull();
    expect(image?.getAttribute("src")).toContain("/tmp/qr.png");
    expect(screen.getByRole("link", { name: "打开二维码" })).toHaveAttribute(
      "href",
      "https://panel.example/evidence?path=/tmp/qr.png",
    );
  });

  it("plays the highest recording index from the latest persisted media event when no live display is ready", () => {
    const { container } = render(
      <BrowserPreview
        session={makeSession({
          status: "completed",
          events: [
            {
              id: "evt_media",
              at: "10:05:00",
              kind: "media_persisted",
              title: "录屏已归档",
              detail: "外部浏览器录屏已保存。",
              actor: "payswitch",
              path: "External Agent / Pay-Switch / Evidence",
              mediaArtifacts: [
                {
                  artifactId: "capture_webm_1",
                  recordingIndex: 1,
                  captureEngine: "playwright_video",
                  durationSeconds: 1.8,
                  frameWidth: 1280,
                  frameHeight: 720,
                  frameRate: 30,
                  bitRate: 1_000_000,
                  codecName: "vp8",
                  sizeBytes: 1024,
                  contentType: "video/webm",
                  downloadUrl:
                    "https://panel.example/api/sessions/psw_kimi/artifacts/capture_webm_1",
                },
                {
                  artifactId: "capture_webm",
                  recordingIndex: 2,
                  captureEngine: "playwright_video",
                  durationSeconds: 4.2,
                  frameWidth: 1280,
                  frameHeight: 720,
                  frameRate: 30,
                  bitRate: 2_000_000,
                  codecName: "vp8",
                  sizeBytes: 2048,
                  contentType: "video/webm",
                  downloadUrl: "https://panel.example/api/sessions/psw_kimi/artifacts/capture_webm",
                },
              ],
            },
          ],
        })}
      />,
    );

    const video = container.querySelector("video");
    expect(video).not.toBeNull();
    expect(video?.getAttribute("src")).toContain("/artifacts/capture_webm");
    expect(screen.getByRole("link", { name: /打开录屏 · #2 · 2 KB · 4\.2s · 1280x720 · 30fps · 2 Mbps · VP8 · WebM · Playwright/i })).toHaveAttribute(
      "href",
      "https://panel.example/api/sessions/psw_kimi/artifacts/capture_webm",
    );
    expect(screen.queryByRole("link", { name: /capture_webm_1/i })).not.toBeInTheDocument();
  });

  it("labels screenshot-replay artifacts as playback instead of native recording", () => {
    render(
      <BrowserPreview
        session={makeSession({
          status: "completed",
          events: [
            {
              id: "evt_media_replay",
              at: "10:06:00",
              kind: "media_persisted",
              title: "回放已归档",
              detail: "观察截图回放已保存。",
              actor: "payswitch",
              path: "External Agent / Pay-Switch / Evidence",
              mediaArtifacts: [
                {
                  artifactId: "observation_replay",
                  recordingIndex: 2,
                  name: "observation-replay.mp4",
                  contentType: "video/mp4",
                  recordingSource: "observation_screenshots",
                  captureEngine: "ffmpeg_replay",
                  durationSeconds: 1,
                  frameWidth: 1280,
                  frameHeight: 720,
                  frameRate: 1,
                  sourceScreenshotCount: 1,
                  bitRate: 800_000,
                  codecName: "mpeg4",
                  sizeBytes: 2048,
                  downloadUrl:
                    "https://panel.example/api/sessions/psw_kimi/artifacts/observation_replay",
                },
              ],
            },
          ],
        })}
      />,
    );

    expect(
      screen.getByRole(
        "link",
        { name: /打开回放 observation-replay\.mp4 · #2 · 1 截图 · 2 KB · 1s · 1280x720 · 1fps · 800 kbps · MPEG-4 · MP4 · FFmpeg 回放/i },
      ),
    ).toHaveAttribute(
      "href",
      "https://panel.example/api/sessions/psw_kimi/artifacts/observation_replay",
    );
    expect(screen.queryByRole("link", { name: /打开录屏 observation-replay\.mp4/i })).not.toBeInTheDocument();
  });

  it("does not render artifact quick actions when no persisted artifact url exists", () => {
    render(
      <BrowserPreview
        session={makeSession({
          status: "completed",
          events: [
            {
              id: "evt_media",
              at: "10:05:00",
              kind: "media_persisted",
              title: "录屏已归档",
              detail: "外部浏览器录屏已保存。",
              actor: "payswitch",
              path: "External Agent / Pay-Switch / Evidence",
              mediaArtifacts: [
                {
                  artifactId: "capture_webm",
                  contentType: "video/webm",
                },
              ],
            },
          ],
        })}
      />,
    );

    expect(screen.queryByRole("link", { name: /打开录屏/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "打开二维码" })).not.toBeInTheDocument();
  });

  it("renders one quick action per recording from the latest persisted media event in recording-index order", () => {
    render(
      <BrowserPreview
        session={makeSession({
          status: "completed",
          events: [
            {
              id: "evt_media_multi",
              at: "10:07:00",
              kind: "media_persisted",
              title: "多段录屏已归档",
              detail: "同一任务产生了多段录屏。",
              actor: "payswitch",
              path: "External Agent / Pay-Switch / Evidence",
              mediaArtifacts: [
                {
                  artifactId: "capture_webm_2",
                  recordingIndex: 2,
                  contentType: "video/webm",
                  downloadUrl:
                    "https://panel.example/api/sessions/psw_kimi/artifacts/capture_webm_2",
                },
                {
                  artifactId: "capture_webm_1",
                  recordingIndex: 1,
                  contentType: "video/webm",
                  downloadUrl:
                    "https://panel.example/api/sessions/psw_kimi/artifacts/capture_webm_1",
                },
              ],
            },
          ],
        })}
      />,
    );

    const links = screen.getAllByRole("link", { name: /打开录屏 · #/i });
    expect(links).toHaveLength(2);
    expect(links[0]).toHaveAttribute(
      "href",
      "https://panel.example/api/sessions/psw_kimi/artifacts/capture_webm_1",
    );
    expect(links[1]).toHaveAttribute(
      "href",
      "https://panel.example/api/sessions/psw_kimi/artifacts/capture_webm_2",
    );
  });
});
