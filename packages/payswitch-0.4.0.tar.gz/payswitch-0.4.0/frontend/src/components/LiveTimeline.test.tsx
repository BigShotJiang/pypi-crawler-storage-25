import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import type { SessionEvent } from "../lib/sessionModel";
import { LiveTimeline } from "./LiveTimeline";

describe("LiveTimeline", () => {
  it("renders downloadable recording links for media persisted events", () => {
    const events: SessionEvent[] = [
      {
        id: "evt_media",
        at: "10:05:00",
        kind: "media_persisted",
        title: "录屏已归档",
        detail: "外部浏览器录屏已保存。",
        actor: "payswitch",
        path: "Codex / Pay-Switch / Evidence",
        mediaArtifacts: [
          {
            artifactId: "capture_webm",
            name: "capture.webm",
            contentType: "video/webm",
            downloadUrl: "/api/sessions/psw_kimi/artifacts/capture_webm",
          },
        ],
      },
    ];

    render(<LiveTimeline events={events} />);

    const link = screen.getByRole("link", { name: /capture\.webm/i });
    expect(link).toHaveAttribute("href", "/api/sessions/psw_kimi/artifacts/capture_webm");
  });

  it("renders recording-source attribution for persisted replay artifacts", () => {
    const events: SessionEvent[] = [
      {
        id: "evt_media_replay",
        at: "10:06:00",
        kind: "media_persisted",
        title: "回放已归档",
        detail: "观察截图回放已保存。",
        actor: "payswitch",
        path: "Codex / Pay-Switch / Evidence",
        mediaArtifacts: [
          {
            artifactId: "observation_replay",
            recordingIndex: 2,
            name: "observation-replay.mp4",
            contentType: "video/mp4",
            recordingSource: "observation_screenshots",
            captureEngine: "ffmpeg_replay",
            durationSeconds: 1,
            frameWidth: 1280,
            frameHeight: 720,
            frameRate: 1,
            sourceScreenshotCount: 1,
            bitRate: 800_000,
            codecName: "mpeg4",
            sizeBytes: 2048,
            downloadUrl: "/api/sessions/psw_kimi/artifacts/observation_replay",
          },
        ],
      },
    ];

    render(<LiveTimeline events={events} />);

    const link = screen.getByRole(
      "link",
      { name: /observation-replay\.mp4 · 截图回放 · #2 · 1 截图 · 2 KB · 1s · 1280x720 · 1fps · 800 kbps · MPEG-4 · MP4 · FFmpeg 回放/i },
    );
    expect(link).toHaveAttribute("href", "/api/sessions/psw_kimi/artifacts/observation_replay");
  });

  it("orders media artifact links by recording index within one persisted event", () => {
    const events: SessionEvent[] = [
      {
        id: "evt_media_multi",
        at: "10:07:00",
        kind: "media_persisted",
        title: "多段录屏已归档",
        detail: "同一任务产生了多段录屏。",
        actor: "payswitch",
        path: "Codex / Pay-Switch / Evidence",
        mediaArtifacts: [
          {
            artifactId: "capture_2",
            recordingIndex: 2,
            name: "capture-2.webm",
            contentType: "video/webm",
            downloadUrl: "/api/sessions/psw_kimi/artifacts/capture_2",
          },
          {
            artifactId: "capture_1",
            recordingIndex: 1,
            name: "capture-1.webm",
            contentType: "video/webm",
            downloadUrl: "/api/sessions/psw_kimi/artifacts/capture_1",
          },
        ],
      },
    ];

    render(<LiveTimeline events={events} />);

    const links = screen.getAllByRole("link");
    expect(links).toHaveLength(2);
    expect(links[0]).toHaveAttribute("href", "/api/sessions/psw_kimi/artifacts/capture_1");
    expect(links[1]).toHaveAttribute("href", "/api/sessions/psw_kimi/artifacts/capture_2");
  });

  it("does not render artifact links when the persisted media has no download url", () => {
    const events: SessionEvent[] = [
      {
        id: "evt_media_pending",
        at: "10:06:00",
        kind: "media_persisted",
        title: "录屏已归档",
        detail: "媒体证据仍在投影中。",
        actor: "payswitch",
        path: "Codex / Pay-Switch / Evidence",
        mediaArtifacts: [
          {
            artifactId: "capture_pending",
            name: "capture-pending.webm",
            contentType: "video/webm",
          },
        ],
      },
    ];

    render(<LiveTimeline events={events} />);

    expect(screen.queryByRole("link", { name: /capture-pending\.webm/i })).not.toBeInTheDocument();
  });
});
