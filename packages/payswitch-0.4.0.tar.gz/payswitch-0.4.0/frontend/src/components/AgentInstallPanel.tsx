import { Clipboard, CreditCard, ExternalLink, KeyRound, TerminalSquare } from "lucide-react";

const installCommand =
  `python3 -c "import json, urllib.request; cfg=json.load(urllib.request.urlopen('https://clawhunt.store/api/pay-switch/config')); base=cfg['public_url'].rstrip('/'); exec(urllib.request.urlopen(base + '/api/payagent/install.py').read().decode())" --force && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py secret init && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py probe`;

const jimengPaymentCommand =
  'payagent submit --payee jimeng --amount 50 --currency CNY --reason "Jimeng points top-up for image and video generation" --method alipay_qr --execute';

const apiKeyPaymentCommand =
  'payagent submit --payee deepseek --product api-key --amount 10 --currency CNY --reason "DeepSeek API key purchase/top-up" --method alipay_qr --request-api-key --execute';

const decodeCommand = "payagent secret decrypt --in <encrypted-api-key-envelope.json>";

const confirmCommand = "payagent confirm --session-id <task_id> --api-key-file <provider-key.txt>";

const watchCommand = "payagent events --session-id <task_id> --with-token";

export function AgentInstallPanel() {
  const copyInstallCommand = () => {
    void navigator.clipboard?.writeText(installCommand);
  };

  return (
    <section className="agent-install-panel panel" aria-label="PayAgent install and usage">
      <div className="panel-title compact">
        <div>
          <h2>PayAgent 一行接入</h2>
          <p>无需 SSH key 或手动 token。复制一行即可安装、接入、配置受限付款凭证和 API key 解码器。</p>
        </div>
        <a
          className="screen-link"
          href="https://github.com/Arxchibobo/payswitch/tree/main/plugins/pay-switch-agent"
          target="_blank"
          rel="noreferrer"
          title="Open PayAgent plugin"
        >
          <ExternalLink size={15} />
          <span>插件</span>
        </a>
      </div>

      <div className="agent-command-card">
        <div className="agent-command-heading">
          <TerminalSquare size={18} />
          <span>安装命令</span>
          <button type="button" className="copy-command" onClick={copyInstallCommand}>
            <Clipboard size={15} />
            <span>复制</span>
          </button>
        </div>
        <code>{installCommand}</code>
      </div>

      <div className="agent-usage-grid">
        <div>
          <span>1. 已自动探测</span>
          <code>payagent probe</code>
        </div>
        <div>
          <span>2. 即梦真实付款</span>
          <code>{jimengPaymentCommand}</code>
        </div>
        <div>
          <span>3. 观察事件</span>
          <code>{watchCommand}</code>
        </div>
        <div>
          <span>4. API key 购买</span>
          <code>{apiKeyPaymentCommand}</code>
        </div>
        <div>
          <span>5. 解密回传 key</span>
          <code>{decodeCommand}</code>
        </div>
        <div>
          <span>6. 付款后收口</span>
          <code>{confirmCommand}</code>
        </div>
      </div>

      <div className="agent-safety-note">
        <KeyRound size={18} />
        <p>
          付款成功后，DeepSeek、Claude、Manus、火山等 adapter 取到的 API key 会以
          X25519 + AES-GCM 加密信封回传；接收 agent 用本地私钥解码，链路中不展示明文 key。
        </p>
      </div>
      <div className="agent-safety-note">
        <CreditCard size={18} />
        <p>
          登录、卡号、扫码、OTP、验证码、支付密码和最终确认仍全部保留在 Pay-Switch Human Gate
          内由用户完成，插件只保留用户授权入口。
        </p>
      </div>
    </section>
  );
}
