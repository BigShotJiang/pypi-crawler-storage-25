import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import { buildInitialSession, type CheckoutSession } from "../lib/sessionModel";
import { SessionSidebar } from "./SessionSidebar";

function makeSession(overrides: Partial<CheckoutSession> = {}): CheckoutSession {
  return {
    ...buildInitialSession(),
    id: "psw_kimi",
    merchant: "Kimi",
    amount: 49,
    currency: "CNY",
    reason: "Kimi monthly",
    status: "running",
    runtimeStatus: "online",
    ...overrides,
  };
}

describe("SessionSidebar", () => {
  it("shows the selected session display entry point when a route is ready", () => {
    render(
      <SessionSidebar
        selectedSessionId="psw_kimi"
        session={makeSession({
          displayReady: true,
          displayState: "visible_surface_ready",
          displayUrl: "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_x",
        })}
        sessions={[
          makeSession({
            displayReady: true,
            displayState: "visible_surface_ready",
            displayUrl: "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_x",
          }),
        ]}
      />,
    );

    expect(screen.getAllByText("可接管").length).toBeGreaterThan(0);
    expect(screen.getByRole("link", { name: "打开当前 Session" })).toHaveAttribute(
      "href",
      "https://panel.example/api/sessions/psw_kimi/display/view?token=dsp_x",
    );
  });

  it("shows foreground-wait messaging for the selected session", () => {
    render(
      <SessionSidebar
        selectedSessionId="psw_wait"
        session={makeSession({
          id: "psw_wait",
          merchant: "Jimeng",
          displayState: "waiting_for_foreground",
          displayReady: false,
          displayReason: "foreground_owned_by_other_task",
        })}
        sessions={[
          makeSession({
            id: "psw_wait",
            merchant: "Jimeng",
            displayState: "waiting_for_foreground",
            displayReady: false,
            displayReason: "foreground_owned_by_other_task",
          }),
        ]}
      />,
    );

    expect(screen.getAllByText("等待前台").length).toBeGreaterThan(0);
    expect(
      screen.getByText("当前 workspace 的前台窗口正被另一条 Session 占用，请先切换或等待当前接管结束。"),
    ).toBeInTheDocument();
  });

  it("does not expose the selected session link before the display is ready", () => {
    render(
      <SessionSidebar
        selectedSessionId="psw_wait"
        session={makeSession({
          id: "psw_wait",
          displayReady: false,
          displayState: "waiting_for_foreground",
          displayUrl: "https://panel.example/not-ready",
        })}
        sessions={[
          makeSession({
            id: "psw_wait",
            displayReady: false,
            displayState: "waiting_for_foreground",
            displayUrl: "https://panel.example/not-ready",
          }),
        ]}
      />,
    );

    expect(screen.queryByRole("link", { name: "打开当前 Session" })).not.toBeInTheDocument();
  });

  it("triggers refresh and select callbacks", () => {
    const onRefreshSessions = vi.fn();
    const onSelectSession = vi.fn();

    render(
      <SessionSidebar
        onRefreshSessions={onRefreshSessions}
        onSelectSession={onSelectSession}
        selectedSessionId="psw_kimi"
        session={makeSession()}
        sessions={[makeSession()]}
      />,
    );

    fireEvent.click(screen.getByTitle("刷新 Session 列表"));
    fireEvent.click(screen.getByRole("button", { name: /Kimi/i }));

    expect(onRefreshSessions).toHaveBeenCalledTimes(1);
    expect(onSelectSession).toHaveBeenCalledWith("psw_kimi");
  });
});
