import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import type { SessionEvent } from "../lib/sessionModel";
import { ToolCallCard } from "./ToolCallCard";

const toolCallStartEvent: SessionEvent = {
  id: "evt-tc1",
  at: "18:30:10",
  kind: "tool_call_start",
  title: "调用工具: fill_payment_form",
  detail: '{"url": "https://example.com", "card_alias": "my-visa-4242"}',
  actor: "payswitch",
  path: "Codex / Pay-Switch",
  target: "fill_payment_form",
};

const toolCallEndEvent: SessionEvent = {
  id: "evt-tc2",
  at: "18:30:12",
  kind: "tool_call_end",
  title: "工具返回: fill_payment_form",
  detail: '{"status": "ok", "fields_filled": 4}',
  actor: "payswitch",
  path: "Codex / Pay-Switch",
  target: "fill_payment_form",
};

describe("ToolCallCard", () => {
  it("renders tool call title and tool name tag", () => {
    render(<ToolCallCard event={toolCallStartEvent} />);

    expect(screen.getByText("调用工具: fill_payment_form")).toBeInTheDocument();
    expect(screen.getByText("fill_payment_form")).toBeInTheDocument();
  });

  it("expands and collapses detail on toggle click", () => {
    render(<ToolCallCard event={toolCallStartEvent} />);

    // 默认收起
    expect(screen.queryByText(/"url"/)).not.toBeInTheDocument();

    // 点击展开
    fireEvent.click(screen.getByText("展开详情"));
    expect(screen.getByText(/"url"/)).toBeInTheDocument();

    // 再次点击收起
    fireEvent.click(screen.getByText("收起详情"));
    expect(screen.queryByText(/"url"/)).not.toBeInTheDocument();
  });

  it("renders tool_call_end event with end class", () => {
    const { container } = render(<ToolCallCard event={toolCallEndEvent} />);

    const article = container.querySelector("article");
    expect(article?.classList.contains("tool-call-end")).toBe(true);
  });

  it("renders without detail when detail is empty", () => {
    const noDetailEvent: SessionEvent = {
      ...toolCallStartEvent,
      detail: "",
    };
    render(<ToolCallCard event={noDetailEvent} />);

    // 没有展开按钮
    expect(screen.queryByText("展开详情")).not.toBeInTheDocument();
  });
});
