# Jimeng Live Payment And Content Proof

Date: 2026-05-14

Remote target: `bobo@178.128.93.176`

## Payment

The user completed the final Alipay authorization for Jimeng. Pay-Switch was confirmed only after the user explicitly reported payment completion.

| Field | Value |
|---|---|
| Transaction | `txn_3221504d6c8d` |
| Idempotency key | `codex:remote:jimeng:takeover-50:20260514-145103` |
| Payee | `jimeng` |
| Amount | `CNY 50.00` |
| Method | `alipay_qr` |
| Execution mode | `human_takeover` |
| Ledger status | `completed` |
| Completed at | `2026-05-14T15:06:14.993061Z` |

## Content Evidence

Proof directory on the sandbox:

`/home/bobo/payswitch/proofs/txn_3221504d6c8d`

Jimeng image prompt:

`PaySwitch proof image, luminous blue robot holding a receipt, clean white studio, no text`

Image evidence:

| Artifact | SHA-256 | Bytes |
|---|---:|---:|
| `/home/bobo/payswitch/proofs/txn_3221504d6c8d/jimeng-image-result-1.png` | `4daaf563a858b87efd2147da1ca6a198a6191fd5baead687c6211b8d2a6a7195` | `302149` |

Jimeng video prompt:

`Short proof video: the blue robot gently waves while holding the receipt, white studio, smooth camera, no text`

Video evidence:

| Artifact | SHA-256 | Bytes |
|---|---:|---:|
| `/home/bobo/payswitch/proofs/txn_3221504d6c8d/jimeng-video-result.png` | `0d712f81bf4be948872450cba39a86a1a51dd176b43e9bcd1d99dd8e14246a53` | `279227` |
| `/home/bobo/payswitch/proofs/txn_3221504d6c8d/extracted/ed5eeaca9ed3eeba_0.mp4` | `dbe064ce4ec541953d102db704474e54a73f31b58bc4ebcf8555124a5f57cc5a` | `4441960` |
| `/home/bobo/payswitch/proofs/txn_3221504d6c8d/extracted/7f0f01b0ca0c1770_s.mp4` | `e68ff847c2e363e6ac2ddee9ea3314adb8c0829a6d4b3f96cf9845ab09c7fc55` | `2526737` |
| `/home/bobo/payswitch/proofs/txn_3221504d6c8d/extracted/ee3b4020dcfde3c1_s.mp4` | `fbefc98f0fdaab53c1b64cafb6a36786b83fd972aad43fca18fbf1a59c156c80` | `611180` |

## Verdict

This proves the Jimeng branch of the chain:

- `PAYSWITCH_AGENT_TOKEN`-protected Pay-Switch agent runtime was used without exposing the token.
- Jimeng payment reached a human authorization gate.
- The user completed real payment authorization.
- Pay-Switch ledger row `txn_3221504d6c8d` is completed.
- The same Jimeng logged-in browser profile produced image and video artifacts after payment.
- Evidence screenshots and extracted MP4 cache artifacts are fixed under the transaction proof directory.

This does not claim the Kimi, Qwen, or Volcano live branches are complete.
