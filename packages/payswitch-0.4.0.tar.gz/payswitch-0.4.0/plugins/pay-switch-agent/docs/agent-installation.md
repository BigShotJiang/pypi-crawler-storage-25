# PayAgent Installation And Request Flow

## Install

Public install and immediate connectivity probe, with no SSH key required:

```bash
python3 -c "import json, urllib.request; cfg=json.load(urllib.request.urlopen('https://clawhunt.store/api/pay-switch/config')); base=cfg['public_url'].rstrip('/'); exec(urllib.request.urlopen(base + '/api/payagent/install.py').read().decode())" --force && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py secret init && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py probe
```

Windows PowerShell:

```powershell
python -c "import json, urllib.request; cfg=json.load(urllib.request.urlopen('https://clawhunt.store/api/pay-switch/config')); base=cfg['public_url'].rstrip('/'); exec(urllib.request.urlopen(base + '/api/payagent/install.py').read().decode())" --force; if ($LASTEXITCODE -eq 0) { python "$HOME\.payagent\pay-switch-agent\scripts\payswitch_agent.py" secret init; python "$HOME\.payagent\pay-switch-agent\scripts\payswitch_agent.py" probe }
```

The installer copies the complete plugin into `~/.payagent/pay-switch-agent`,
creates a `payagent` command, and writes `~/.payagent/payagent.env` with the
public discovery URLs plus a managed PayAgent client token when the bootstrap
endpoint is available. The token is not printed.

`payagent secret init` creates the local receiving-agent keypair and decoder
inbox at `~/.payagent/secret-inbox.json`. Only the public key is sent to
Pay-Switch for API-key products.

## Configure

No manual token configuration is required for the public Pay-Switch install.
Card entry, OTP, QR scan, CAPTCHA, payment password, and final payment
confirmation remain Human Gate steps inside Pay-Switch.

## Request An API Key Product

For DeepSeek, Claude, Codex, Manus, Volcano, or another AI product that returns
an API key, request encrypted delivery:

```bash
payagent submit \
  --payee deepseek \
  --product api-key \
  --amount 10 \
  --currency CNY \
  --reason "DeepSeek API key purchase/top-up" \
  --method alipay_qr \
  --request-api-key \
  --execute
```

When Pay-Switch returns an encrypted secret artifact, decode it locally:

```bash
payagent secret decrypt --in encrypted-api-key-envelope.json
```

If the provider adapter extracts the key after payment, close the same
Pay-Switch session and attach the encrypted API-key artifact:

```bash
payagent confirm --session-id <task_id> --api-key-file provider-key.txt
```

## Submit A Payment Intent

REST transport:

```bash
payagent submit \
  --payee jimeng \
  --amount 50 \
  --currency CNY \
  --reason "Jimeng points top-up for image and video generation" \
  --method alipay_qr \
  --execute
```

A2A/JSON-RPC transport:

```bash
payagent submit \
  --endpoint a2a \
  --payee jimeng \
  --amount 50 \
  --currency CNY \
  --reason "Jimeng points top-up for image and video generation" \
  --method alipay_qr \
  --execute
```

## Watch The Result

The submit response contains a Pay-Switch `task_id`. Stream events with:

```bash
payagent events --session-id <task_id> --with-token
```

## Build The AI Media Chain Plan

```bash
payagent plan --out pay-switch-plan.json
payagent submit --plan pay-switch-plan.json --execute
```

The default plan submission targets `jimeng.credits` for a 50 CNY Jimeng points
top-up. The complete plan also covers fresh account setup, user card handoff,
Kimi paid activation, Qwen/Jimeng/Volcano image generation, and Jimeng video
generation in a sticky single Pay-Switch surface.
