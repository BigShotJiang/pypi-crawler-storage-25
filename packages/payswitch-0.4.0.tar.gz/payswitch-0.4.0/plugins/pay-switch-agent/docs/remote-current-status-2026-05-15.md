# Remote Current Status

Date: 2026-05-15

Remote target: `bobo@178.128.93.176`

Remote repository HEAD: `eb36ef5`

## Service

`https://178-128-93-176.sslip.io/api/health` returned OK.

The health payload reports:

- service `payswitch-agent`
- version `0.3.0`
- public URL `https://178-128-93-176.sslip.io`
- agent token configured
- PayAgent bootstrap enabled
- token scope `payagent:human-gated`
- encrypted A2A secret delivery enabled
- browser engine `cloakbrowser`
- noVNC available at `https://178-128-93-176.sslip.io/vnc.html?autoconnect=true&resize=scale`

## Payment Instrument

Remote config currently includes one sandbox card instrument:

| Field | Value |
|---|---|
| ID | `sandbox_visa_4242` |
| Label | `Stripe Sandbox Visa 4242 ending 4242` |
| Storage | `keyring` |
| Autofill level | `full` |
| Allowed payees | `stripe` |
| Currency allowlist | `USD`, `CNY` |
| Max transaction | `100.0` |

This proves the Stripe sandbox-card path is configured. It does not replace
provider-specific Human Gate approval for Jimeng, Kimi, Qwen, or Volcano.

## Provider Profiles

Remote `payswitch --json platforms` reports:

| Provider | Logged in | Status | Logged in at |
|---|---:|---|---|
| Kimi | true | `active` | `2026-05-14 11:33:41.947292+00:00` |
| Jimeng | true | `active` | `2026-05-14 15:23:00.602008+00:00` |
| Qwen | true | `active` | `2026-05-15 12:17:57.118823+00:00` |
| Volcano | true | `active` | `2026-05-15 13:18:40.338058+00:00` |

Volcano was saved from browser state after the login flow, but still needs a
merchant-side smoke run before it should be treated as fully proven.

## Latest Completed Live Proof

Latest completed real payment proof:

| Field | Value |
|---|---|
| Transaction | `txn_7a9d77b937e1` |
| Session/task | `psw_3067a961b8723449` |
| Payee | `jimeng` |
| Amount | `50 CNY` |
| Method | `alipay_qr` |
| Mode | `script` |
| Ledger status | `completed` |
| Idempotency key | `codex:remote:jimeng:gate-validation:20260515-1241` |

The corresponding proof directory is:

`/home/bobo/payswitch/proofs/txn_7a9d77b937e1`

Key proof files:

| Artifact | SHA-256 | Bytes |
|---|---|---:|
| `after-user-paid.png` | `b44408c8b4ad98a3aa87f9af820e4f5507cafcede8ceadb448ded10b0a9ee899` | `334274` |
| `jimeng-image-result.png` | `e5416bf66671bea36e82e0882068e76163670e7f29136db702108030fdf08cbb` | `348812` |
| `jimeng-video-real-latest.png` | `dcbea5c58c49dcba888c361ea72cdb93406d000282b47a87e57f9c3bce59f1f2` | `237298` |
| `extracted/jimeng-video-candidate-1.mp4` | `eaad8af4d74574618d6eddb6ebbcb7a4924ed56fe9a15c09d943b56fdd9d9c0e` | `3718511` |

The remote proof manifest hash is:

- `proof-manifest.json`: `8f351e544989edc9f6f6dc996a3fc2b1bf26acf95aed4b0ff324d6077adf40ed`
- `proof-summary.md`: `d4af551edd23c83b2113f7c5db8a9de98f1c4b8efb056c3bf3ac702b38db97ea`

The redacted manifest is committed as
`remote-live-proof-2026-05-15-jimeng.json`.

## Current Verdict

Proven:

- public control plane and noVNC are reachable
- token auth and managed PayAgent bootstrap are configured
- encrypted API-key envelope delivery is available
- Stripe sandbox card metadata is configured
- Kimi/Jimeng/Qwen/Volcano profiles report active on remote
- Jimeng 50 CNY payment reached Human Gate, was completed by the user, and was
  confirmed to the ledger
- the same Jimeng transaction has image and video artifacts

Not yet proven:

- Kimi same-session live payment completion
- Qwen same-session image generation artifact
- Volcano merchant-side smoke run and image generation artifact
- full all-platform Kimi/Qwen/Jimeng/Volcano proof

## Next Updates

1. Run Qwen image generation from the active Qwen profile and persist a
   same-session manifest.
2. Run Volcano profile smoke validation, then Volcano image generation and
   persist a same-session manifest.
3. Keep Kimi payment on-demand only, so a Jimeng request cannot accidentally
   open the Kimi checkout.
4. Rerun the remote proof collector after Qwen and Volcano artifacts exist.
