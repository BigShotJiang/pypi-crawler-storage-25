# Remote Sandbox Proof

Date: 2026-05-14

Remote target: `bobo@178.128.93.176`

This is a historical 2026-05-14 sandbox proof. For the current 2026-05-15
remote status, card metadata, active profiles, and latest Jimeng payment proof,
see `remote-current-status-2026-05-15.md`.

## Live Addendum

After this sandbox proof was first written, Jimeng was completed as a real live payment and content-generation branch.

See `remote-live-proof-2026-05-14-jimeng.md` and `remote-live-proof-2026-05-14-jimeng.json`.

Summary:

- Jimeng real payment transaction `txn_3221504d6c8d` is `completed`.
- Amount: `CNY 50.00`.
- Execution mode: `human_takeover`.
- Completion time: `2026-05-14T15:06:14.993061Z`.
- Jimeng image and video evidence is fixed under `/home/bobo/payswitch/proofs/txn_3221504d6c8d`.

## What Was Verified

- SSH access works for user `bobo`.
- Pay-Switch service root is `/home/bobo/payswitch`.
- Runtime env is `/home/bobo/.payswitch/server.env`.
- Ledger DB is `/home/bobo/.payswitch/payswitch.db`.
- `PAYSWITCH_AGENT_TOKEN` is present on the remote host and was used without printing it.
- Current running service is `python -m payswitch.cli serve --host 0.0.0.0 --port 8787`.
- Version is `0.3.0`.
- Public HTTPS endpoint is `https://178-128-93-176.sslip.io`.

## Authentication Proof

Unauthenticated `POST /api/payments` returned `401` with `missing or invalid Pay-Switch agent token`.

Authenticated dry-run requests succeeded:

| Payee | Session | Transaction | Status | Evidence |
|---|---|---|---|---|
| `kimi` | `psw_911c65bf9bc7c3ba` | `txn_84c6b4e22bec` | `completed` dry-run | `pay_switch_intent`, `pay_switch_psl`, `pay_switch_plan`, `pay_switch_result` |
| `qwen` | `psw_ef1dc8b2224e341b` | `txn_f3dd4b0c34ff` | `completed` dry-run | `pay_switch_intent`, `pay_switch_psl`, `pay_switch_plan`, `pay_switch_result` |

## Live Blocker Proof

Non-dry-run requests were submitted with stable idempotency keys. They did not reach payment pages or spend money. They failed before browser execution because required login profiles were missing.

| Payee | Session | Ledger Transaction | Status | Error |
|---|---|---|---|---|
| `kimi` | `psw_f13c8b8de728ce60` | `txn_135366e455d1` | `failed` | `平台 'kimi' 的 Profile 不存在，请先执行 'payswitch login kimi' 完成登录` |
| `qwen` | `psw_300fc8f81afdd390` | `txn_f02c05a87583` | `failed` | `平台 'qwen' 的 Profile 不存在，请先执行 'payswitch login qwen' 完成登录` |
| `jimeng` | `psw_0ca3a47eeaf1c694` | `txn_d1d4c66aa0ff` | `failed` | `平台 'jimeng' 的 Profile 不存在，请先执行 'payswitch login jimeng' 完成登录` |
| `volcano` | `psw_804fddd8ad97d314` | `txn_90b3f1babda7` | `failed` | `平台 'volcano' 的 Profile 不存在，请先执行 'payswitch login volcano' 完成登录` |

The ledger contains these four failed live-blocker rows. There are no same-session successful payment rows, image output rows, or video output rows.

## Adapter And Card Inventory

`payswitch --json platforms` reported registered adapters:

- `deepseek`
- `kimi`
- `nineemail`
- `qwen`
- `stripe`

It did not report `jimeng` or `volcano`.

Remote config reported:

- `allow_card_number_only`: `false`
- `allow_virtual_card`: `false`
- `card_instruments`: `[]`
- `vault.cards`: `[]`

Therefore no sandbox card or user-authorized card is currently configured in Pay-Switch.

## Verdict

The updated verdict is mixed:

> The remote sandbox now proves the Jimeng real payment plus Jimeng image/video generation branch. It still does not prove the full Kimi/Qwen/Jimeng/Volcano all-platform chain.

Missing proof items:

- Kimi login profile.
- Qwen login profile.
- Volcano adapter and login profile.
- sandbox or user-authorized card configured in Pay-Switch.
- same-session successful payment ledger rows for Kimi/Qwen/Volcano.
- same-session image artifacts for Qwen/Volcano.

## Re-run

```powershell
python .\plugins\pay-switch-agent\scripts\remote_sandbox_proof.py --include-live-blockers --out .\pay-switch-remote-proof.json
```

On the sandbox host itself:

```bash
cd /home/bobo/payswitch
python3 plugins/pay-switch-agent/scripts/remote_sandbox_proof.py --local --include-live-blockers --out /tmp/pay-switch-remote-proof.json
```
