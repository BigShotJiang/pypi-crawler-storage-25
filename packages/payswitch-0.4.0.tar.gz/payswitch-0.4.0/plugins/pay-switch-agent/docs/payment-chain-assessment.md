# Pay-Switch Payment Chain Assessment

Assessment date: 2026-05-15

Remote status update: see `remote-current-status-2026-05-15.md`.

Remote sandbox update: see `remote-sandbox-proof-2026-05-14.md`.

Latest live Jimeng proof: see `remote-live-proof-2026-05-15-jimeng.md` and
`remote-live-proof-2026-05-15-jimeng.json`.

Historical live Jimeng proof: see `remote-live-proof-2026-05-14-jimeng.md` and
`remote-live-proof-2026-05-14-jimeng.json`.

Code update on 2026-05-14:

- Added first-party Pay-Switch adapters for `jimeng` and `volcano`.
- Extended the remote proof collector to verify token enforcement, adapter registration, profile status, card configuration, live ledger rows, and image/video artifact manifests.
- Updated the plugin token handling to accept both `PAYSWITCH_AGENT_TOKEN` and `PAY_SWITCH_AGENT_TOKEN`.

Code update on 2026-05-15:

- Replaced the private SSH install path with a Pay-Switch-hosted public one-liner that installs and immediately runs `payagent probe`.
- Changed the default plan submission target to `jimeng.credits` for a 50 CNY Jimeng points top-up.
- Preserved Kimi/Qwen/Jimeng/Volcano in the full plan while preventing accidental Kimi submission as the default.
- Added PayAgent bootstrap so the installer receives a managed client token without asking the user to copy `PAYSWITCH_AGENT_TOKEN`.
- Added encrypted A2A API-key return support with a local receiving-agent decoder.
- Added same-session confirm support so a task can be closed with ledger evidence, media artifacts, or an encrypted API-key envelope after Human Gate.
- Changed script-mode payment gates to return explicit `payment_authorization` Human Gate actions instead of falling through as failed runs.
- Fixed proof collection to surface live Jimeng image/video manifests.

## Public Evidence

The public page `https://clawhunt.store/pay-switch` loads successfully and points the embedded Pay-Switch surface at `https://178-128-93-176.sslip.io`.

The config endpoint `https://clawhunt.store/api/pay-switch/config` returns:

- `public_url`: `https://178-128-93-176.sslip.io`
- `a2a_endpoint`: `https://178-128-93-176.sslip.io/a2a`
- `rest_endpoint`: `https://178-128-93-176.sslip.io/api/payments`
- `agent_card_url`: `https://178-128-93-176.sslip.io/.well-known/agent-card.json`
- `events_url`: `https://178-128-93-176.sslip.io/events`
- `novnc_url`: `https://178-128-93-176.sslip.io/vnc.html?autoconnect=true&resize=scale`

The health endpoint reports:

- `service`: `payswitch-agent`
- `version`: `0.3.0`
- AI provider configured: `github`
- AI model: `openai/gpt-4o-mini`
- bearer token configured on the server
- computer-use display available on `:99`
- noVNC dependencies available
- browser engine: `cloakbrowser`

The agent card reports:

- protocol version `0.3.0`
- preferred transport `HTTP+JSON`
- streaming enabled
- bearer auth scheme `agentToken`
- skill `payment_intent`
- REST and SSE metadata matching the public endpoints

Unauthenticated POST requests to both REST and A2A return `401`, which is the expected guardrail for a payment endpoint.

## Verdict

The current foundation is ready for authenticated Pay-Switch intent execution. The Jimeng branch now has a same-session real payment plus image/video generation proof from 2026-05-15. The full all-platform Kimi/Qwen/Jimeng/Volcano chain is not yet proven from public evidence alone.

What is proven:

- The control plane is reachable over HTTPS.
- The agent card is discoverable.
- REST, A2A, SSE, health, and noVNC endpoints are published.
- The upstream agent has an AI runtime and browser runtime configured.
- The server enforces bearer authentication on payment submission.
- Remote health is currently OK at `https://178-128-93-176.sslip.io/api/health`.
- The server reports token auth configured, PayAgent bootstrap enabled, and encrypted secret delivery enabled.
- Remote config includes `sandbox_visa_4242`, a Stripe sandbox Visa ending 4242 stored through keyring metadata.
- Kimi, Jimeng, Qwen, and Volcano profiles currently report `active` on the remote host.
- Jimeng live payment `txn_7a9d77b937e1` completed for 50 CNY after user Alipay authorization.
- The same Jimeng transaction produced image and video evidence under `/home/bobo/payswitch/proofs/txn_7a9d77b937e1`.
- The installable plugin can be fetched from the Pay-Switch public service without an SSH key or user-managed token and can probe the public endpoints immediately after installation.
- The plugin can request encrypted API-key delivery without exposing plaintext API keys over A2A.

What is not proven yet:

- The server master `PAYSWITCH_AGENT_TOKEN` exists and was verified, but it is not printed or handed to the user; installs receive a managed PayAgent client token instead.
- The configured sandbox card is a Stripe sandbox instrument, not a general Jimeng/Kimi/Qwen/Volcano payment card. Live merchant QR/card approval remains a user Human Gate step.
- The public agent card exposes only `payment_intent`; it does not expose account-registration or media-generation skills.
- Kimi, Qwen, Jimeng, and Volcano adapters exist in current `main`, but the public agent card still exposes the payment-intent surface rather than a full media-generation A2A surface.
- Qwen reports an active profile, but no same-session Qwen image artifact has been fixed in the public proof set yet.
- Volcano reports an active profile from saved browser state, but it still needs a merchant-side smoke run because the login command did not detect an explicit provider-side login marker before saving.
- No same-session ledger success artifact exists for Kimi payment, Qwen image generation, or Volcano image generation.

Therefore, the precise claim is:

> Pay-Switch can currently be driven through one-line plugin install, discovery, readiness proof, authenticated intent submission, AI planning, encrypted API-key handoff, and the proved Jimeng real-payment plus image/video branch. It cannot be rigorously claimed to have completed the full Kimi/Qwen/Jimeng/Volcano merchant-side chain until the remaining Kimi/Qwen/Volcano same-session adapter runs and success evidence are supplied.

## Required To Prove Full Chain

To prove the full chain end-to-end, run the plugin with:

- installer-provisioned `PAY_SWITCH_AGENT_TOKEN` or an operator-provided bearer token
- a sandbox card or explicit user-controlled live card handoff
- a fresh account identity approved for test use
- merchant adapter or browser-flow confirmation for Kimi, Qwen, Jimeng, and Volcano
- success detectors for payment completion, credit balance, image output, and video output
- ledger or event evidence from the same Pay-Switch session

## Single-Surface Strategy

The plugin plan keeps one sticky Pay-Switch session and one visible control-plane surface:

- all payment intents share one `session_id`
- agent actions are submitted through REST/A2A
- all observations and Human Gate events appear through the same SSE session
- card entry, OTP, CAPTCHA, and final confirmation stay inside the same Pay-Switch/noVNC handoff
- the agent does not switch the user's working content or ask them to leave the Pay-Switch surface

## Target Flow

1. Register or prepare a fresh account.
2. Attach card through Human Gate.
3. Complete the default Jimeng 50 CNY points intent.
4. Run Jimeng image generation and verify output.
5. Run Jimeng video generation and verify async output.
6. Complete Kimi paid plan intent when Kimi is requested.
7. Run Qwen and Volcano image generation when those providers are requested.
8. Persist event and ledger evidence.

## Next Updates

1. Add a public A2A media-generation skill once the provider-side success detectors are stable.
2. Run Qwen image generation in the active Qwen profile and persist a same-session manifest.
3. Run a Volcano profile smoke check, then Volcano image generation, and persist a same-session manifest.
4. Complete a Kimi live payment only when Kimi is the requested product, then confirm the ledger after user authorization.
5. Rerun the remote proof collector after those artifacts exist and replace the full-chain verdict with an all-platform proof only if every same-session ledger and artifact check passes.
