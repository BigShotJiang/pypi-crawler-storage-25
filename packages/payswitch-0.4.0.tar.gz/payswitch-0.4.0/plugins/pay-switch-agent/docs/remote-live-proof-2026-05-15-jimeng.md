# Jimeng Live Payment And Content Proof

Date: 2026-05-15

Remote target: `bobo@178.128.93.176`

## Payment

User completed the final Alipay authorization. Pay-Switch confirmed the ledger only after the user reported payment complete.

| Field | Value |
|---|---|
| Transaction | `txn_7a9d77b937e1` |
| Task | `psw_3067a961b8723449` |
| Payee | `jimeng` |
| Amount | `CNY 50.00` |
| Method | `alipay_qr` |
| Ledger status | `completed` |

## Content Evidence

Proof directory: `/home/bobo/payswitch/proofs/txn_7a9d77b937e1`

Image screenshot: `/home/bobo/payswitch/proofs/txn_7a9d77b937e1/jimeng-image-result.png` SHA-256 `e5416bf66671bea36e82e0882068e76163670e7f29136db702108030fdf08cbb` bytes `348812`.

Video screenshot: `/home/bobo/payswitch/proofs/txn_7a9d77b937e1/jimeng-video-real-latest.png` SHA-256 `dcbea5c58c49dcba888c361ea72cdb93406d000282b47a87e57f9c3bce59f1f2` bytes `237298`.

MP4 candidates:
- `/home/bobo/payswitch/proofs/txn_7a9d77b937e1/extracted/jimeng-video-candidate-1.mp4` SHA-256 `eaad8af4d74574618d6eddb6ebbcb7a4924ed56fe9a15c09d943b56fdd9d9c0e` bytes `3718511`
- `/home/bobo/payswitch/proofs/txn_7a9d77b937e1/extracted/jimeng-video-candidate-2.mp4` SHA-256 `eaad8af4d74574618d6eddb6ebbcb7a4924ed56fe9a15c09d943b56fdd9d9c0e` bytes `3718511`
- `/home/bobo/payswitch/proofs/txn_7a9d77b937e1/extracted/jimeng-video-candidate-3.mp4` SHA-256 `eaad8af4d74574618d6eddb6ebbcb7a4924ed56fe9a15c09d943b56fdd9d9c0e` bytes `3718511`

## Verdict

This proves the Jimeng branch: token-protected Pay-Switch request, real human payment authorization, completed ledger row, and same-tx image/video artifacts. It does not claim Kimi/Qwen/Volcano live branches are complete.
