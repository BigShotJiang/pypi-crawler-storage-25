---
name: pay-switch-payment-chain
description: Probe and operate the Pay-Switch Agent control plane for guarded payment intents, single-surface payment workflows, and AI media purchase/generation chains.
---

# Pay-Switch Payment Chain

Use this skill when the user asks about Pay-Switch, `clawhunt.store/pay-switch`, agent payment intents, A2A payment execution, Kimi paid flows, Qwen/Jimeng/Volcano image generation, Jimeng video generation, or a one-surface payment-chain proof.

## Safety Rules

- Default to dry-run and readiness proof.
- Never enter or store card numbers, expiry, CVV, OTP, SMS codes, email verification codes, payment passwords, CAPTCHA answers, or final payment confirmation.
- Treat card entry, issuer 3DS, QR scan, OTP, CAPTCHA, and final checkout confirmation as Human Gate steps.
- Public installs auto-provision a managed PayAgent client token. Live submission only requires `--execute`; real payment completion still requires explicit user approval in Pay-Switch Human Gate.
- For API-key products, use encrypted delivery: initialize the local decoder with `payagent secret init`, submit with `--request-api-key`, and decrypt returned envelopes with `payagent secret decrypt --in <envelope.json>`. Never ask the user to paste plaintext API keys into A2A messages.
- Do not claim a full merchant-side chain is proven unless there is success evidence for payment, ledger, and content output in the same Pay-Switch session.

## Workflow

1. If `payagent` is not installed, install it from Pay-Switch:

```bash
python3 -c "import json, urllib.request; cfg=json.load(urllib.request.urlopen('https://clawhunt.store/api/pay-switch/config')); base=cfg['public_url'].rstrip('/'); exec(urllib.request.urlopen(base + '/api/payagent/install.py').read().decode())" --force && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py secret init && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py probe
```

2. Locate the plugin root only when working inside the repository. From this skill file, it is two directories up.
3. Run the probe:

```powershell
payagent probe
```

4. For API-key products, make sure the receiving-agent decoder exists:

```powershell
payagent secret init
```

5. If the user asks for the Jimeng or Kimi/Qwen/Jimeng/Volcano chain, build the default single-surface plan:

```powershell
payagent plan --out .\pay-switch-plan.json
```

6. For an intent preview, use dry-run submit. Example:

```powershell
payagent submit --plan .\pay-switch-plan.json
```

7. For live submission, use the installer-provisioned token and require user approval in the Human Gate:

```powershell
payagent submit --plan .\pay-switch-plan.json --execute
```

8. Use A2A transport when the caller specifically needs an A2A/JSON-RPC request:

```powershell
payagent submit --endpoint a2a --payee jimeng --amount 50 --currency CNY --reason "Jimeng points top-up for image and video generation" --method alipay_qr --execute
```

9. For DeepSeek, Claude, Codex, Manus, Volcano, or another API-key product, request encrypted key return:

```powershell
payagent submit --payee deepseek --product api-key --amount 10 --currency CNY --reason "DeepSeek API key purchase/top-up" --method alipay_qr --request-api-key --execute
payagent confirm --session-id <task_id> --api-key-file <provider-key.txt>
payagent secret decrypt --in <encrypted-api-key-envelope.json>
```

10. Watch events only when needed:

```powershell
payagent events --session-id <session-id> --with-token
```

11. If the user provides the remote sandbox SSH target, collect token-safe proof:

```powershell
python <plugin-root>\scripts\remote_sandbox_proof.py --ssh-target bobo@178.128.93.176 --include-live-blockers --out .\pay-switch-remote-proof.json
```

## Expected Verdict Language

If probe passes but no managed token, merchant sandbox, or ledger evidence exists, say:

`The Pay-Switch control plane is ready for authenticated guarded intent execution, but the complete merchant-side payment and generation chain is not proven yet.`

If probe reports `jimeng_payment_and_generation: PROVEN`, say that the Jimeng
50 CNY live payment plus same-session image/video branch is proven, while the
full Kimi/Qwen/Jimeng/Volcano all-platform chain remains unproven unless the
probe or remote proof says otherwise. Prefer the newest bundled live proof when
multiple proof manifests are present.

If authenticated submit and same-session success evidence exist, report exactly which steps completed and which Human Gate actions the user performed.

## Plugin Assets

- Assessment: `docs/payment-chain-assessment.md`
- Latest remote status: `docs/remote-current-status-2026-05-15.md`
- Latest Jimeng live proof: `docs/remote-live-proof-2026-05-15-jimeng.md`
- Historical remote proof: `docs/remote-sandbox-proof-2026-05-14.md`
- Default plan: `flows/ai-media-payment-chain.json`
- Installer: `install.py`
- Environment template: `payagent.env.example`
- CLI: `scripts/payswitch_agent.py`
- Remote proof CLI: `scripts/remote_sandbox_proof.py`
