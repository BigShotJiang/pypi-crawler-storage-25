# Pay-Switch Agent Plugin

This repo-local Codex plugin also installs as a standalone `payagent` command.
It lets another agent submit guarded payment intents to a running Pay-Switch
server, then leaves Pay-Switch to route, guard, execute, and stop at Human Gate
for card details, OTP, QR scan, CAPTCHA, payment password, or final payment
confirmation.

It provides:

- A Codex skill for safe Pay-Switch operation.
- A Python CLI for endpoint discovery, readiness checks, plan generation, authenticated submit, encrypted API-key delivery, and SSE watch.
- A dependency-free installer that creates a local `payagent` command from this GitHub repo.
- A local receiving-agent decoder: `payagent secret init` creates the private key locally, and Pay-Switch receives only the public key.
- A default single-surface AI media flow covering new account setup, card handoff, Jimeng points top-up, Kimi paid plan, Qwen/Jimeng/Volcano image generation, and Jimeng video generation.
- A current readiness assessment based on the public Pay-Switch endpoint.

## One-command Install

Public install and immediate connectivity probe, with no SSH key required:

```bash
python3 -c "import json, urllib.request; cfg=json.load(urllib.request.urlopen('https://clawhunt.store/api/pay-switch/config')); base=cfg['public_url'].rstrip('/'); exec(urllib.request.urlopen(base + '/api/payagent/install.py').read().decode())" --force && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py secret init && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py probe
```

Windows PowerShell:

```powershell
python -c "import json, urllib.request; cfg=json.load(urllib.request.urlopen('https://clawhunt.store/api/pay-switch/config')); base=cfg['public_url'].rstrip('/'); exec(urllib.request.urlopen(base + '/api/payagent/install.py').read().decode())" --force; if ($LASTEXITCODE -eq 0) { python "$HOME\.payagent\pay-switch-agent\scripts\payswitch_agent.py" secret init; python "$HOME\.payagent\pay-switch-agent\scripts\payswitch_agent.py" probe }
```

The installer copies `plugins/pay-switch-agent` into `~/.payagent/pay-switch-agent`
and writes a `payagent` wrapper into the user Python scripts directory. If that
directory is not on `PATH`, the installer prints the full command path.

Local development install from this repository:

```bash
python plugins/pay-switch-agent/install.py --source plugins/pay-switch-agent --force
```

## Quick Start

```powershell
payagent probe
payagent secret init
payagent plan --out pay-switch-plan.json
payagent submit --plan pay-switch-plan.json
```

`payagent probe` also reports the bundled Jimeng live proof when present:
`txn_7a9d77b937e1`, 50 CNY, completed, with same-session image and video
artifacts from the 2026-05-15 remote validation run.

The `submit` command is dry-run by default. The public installer provisions a
managed PayAgent client token, so live submission only needs `--execute`; the
real payment still stops at Pay-Switch Human Gate for user authorization:

```bash
payagent submit --payee jimeng --amount 50 --currency CNY --reason "Jimeng points top-up for image and video generation" --method alipay_qr --execute
```

PowerShell:

```powershell
payagent submit --payee jimeng --amount 50 --currency CNY --reason "Jimeng points top-up for image and video generation" --method alipay_qr --execute
```

Use A2A JSON-RPC transport instead of REST when needed:

```bash
payagent submit --endpoint a2a --payee jimeng --amount 50 --currency CNY --reason "Jimeng points top-up for image and video generation" --method alipay_qr --execute
```

To buy or top up an AI product that returns an API key, ask for encrypted key
delivery. The local agent creates the receiving keypair; only its public key is
sent to Pay-Switch. After the user finishes login and payment in Human Gate, the
adapter returns an encrypted envelope artifact instead of a plaintext key:

```bash
payagent secret init
payagent submit --payee deepseek --product api-key --amount 10 --currency CNY --reason "DeepSeek API key purchase/top-up" --method alipay_qr --request-api-key --execute
payagent confirm --session-id <task_id> --api-key-file provider-key.txt
payagent secret decrypt --in encrypted-api-key-envelope.json
```

The decrypted output is written under `~/.payagent/secrets/` as an env file such
as `DEEPSEEK_API_KEY=...`. The private key stays in
`~/.payagent/secret-inbox.json`; do not copy it into prompts or A2A messages.

Adapters that finish the provider-side API key creation can close the same
Pay-Switch session with:

```bash
payagent confirm \
  --session-id <task_id> \
  --api-key-file provider-key.txt \
  --evidence '{"kind":"ledger","provider":"deepseek","name":"receipt","url":"https://..."}'
```

The server encrypts the supplied key with the recipient public key from the
original `--request-api-key` submit metadata and returns it as an A2A artifact.

Remote sandbox proof can be collected over SSH without printing the bearer token:

```powershell
python .\plugins\pay-switch-agent\scripts\remote_sandbox_proof.py --include-live-blockers --out .\pay-switch-remote-proof.json
```

If you are already on the sandbox host, avoid SSH and collect directly:

```bash
cd /home/bobo/payswitch
python3 plugins/pay-switch-agent/scripts/remote_sandbox_proof.py --local --include-live-blockers --out /tmp/pay-switch-remote-proof.json
```

## Environment

- `PAY_SWITCH_CONFIG_URL`: optional discovery URL. Defaults to `https://clawhunt.store/api/pay-switch/config`.
- `PAY_SWITCH_PANEL_URL`: optional user-facing control plane URL. Defaults to `https://clawhunt.store/pay-switch`.
- `PAY_SWITCH_AGENT_TOKEN`: managed client token written by the installer when the Pay-Switch bootstrap endpoint is available. It is not printed during install.
- `PAYSWITCH_AGENT_TOKEN`: optional operator-provided server token override for private deployments.
- `PAY_SWITCH_ALLOW_LIVE`: optional legacy override for operator-provided tokens. Installer-provisioned client tokens can submit `--execute` directly because Pay-Switch still requires Human Gate authorization before final payment.
- `~/.payagent/secret-inbox.json`: local receiving-agent private key used by `payagent secret decrypt`. Pay-Switch only receives the matching public key.

## Safety Boundary

The plugin does not enter card numbers, CVV, OTP, SMS codes, email verification
codes, payment passwords, CAPTCHA answers, QR scan approvals, or final payment
confirmation on behalf of the user. Those actions are treated as Human Gate
steps and must be performed by the user in the Pay-Switch surface.

## Agent Contract

After installation, the calling agent only needs to:

1. Discover readiness with `payagent probe`.
2. Call `payagent submit ... --execute`.
3. For API-key products, add `--request-api-key`; Pay-Switch will return an encrypted envelope artifact for the local decoder.
4. After the user finishes Human Gate and the provider key or media evidence is available, call `payagent confirm --session-id <task_id> ...` to close the same session.
5. Leave login, card/QR authorization, OTP, CAPTCHA, and final confirmation to the Pay-Switch Human Gate.
6. Watch `payagent events --session-id <task_id> --with-token` when it needs live status.

Pay-Switch owns the payment execution, ledger write, evidence capture, and Human
Gate. The plugin is only a client and installer.

See `docs/payment-chain-assessment.md` for the current end-to-end verdict.
See `docs/remote-current-status-2026-05-15.md` for the latest remote status
and `docs/remote-sandbox-proof-2026-05-14.md` for the historical sandbox proof.
