#!/usr/bin/env python3
"""Collect Pay-Switch sandbox proof over SSH or on the current host.

The script never prints the remote bearer token. It executes a short Python
collector on the target host, using the token only inside localhost requests.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

REMOTE_COLLECTOR = r"""
import json
import os
import shlex
import sqlite3
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path

ENV_FILE = Path("__ENV_FILE__")
DB_FILE = Path("__DB_FILE__")
PAYSWITCH_ROOT = Path("__PAYSWITCH_ROOT__")
DATA_DIR = DB_FILE.parent
BASE = "__BASE_URL__".rstrip("/")
RUN_LIVE_BLOCKERS = __RUN_LIVE_BLOCKERS__
PLATFORMS = ("kimi", "qwen", "jimeng", "volcano")
REQUIRED_MEDIA_STEPS = {
    "qwen.image": {"provider": "qwen", "capability": "image_generation"},
    "jimeng.image": {"provider": "jimeng", "capability": "image_generation"},
    "volcano.image": {"provider": "volcano", "capability": "image_generation"},
    "jimeng.video": {"provider": "jimeng", "capability": "video_generation"},
}


def load_env():
    if not ENV_FILE.exists():
        return
    for raw in ENV_FILE.read_text(encoding="utf-8").splitlines():
        raw = raw.strip()
        if raw and not raw.startswith("#") and "=" in raw:
            key, value = raw.split("=", 1)
            os.environ.setdefault(key, value.strip().strip('"').strip("'"))
    if os.environ.get("PAY_SWITCH_AGENT_TOKEN") and not os.environ.get("PAYSWITCH_AGENT_TOKEN"):
        os.environ["PAYSWITCH_AGENT_TOKEN"] = os.environ["PAY_SWITCH_AGENT_TOKEN"]
    if os.environ.get("PAYSWITCH_AGENT_TOKEN") and not os.environ.get("PAY_SWITCH_AGENT_TOKEN"):
        os.environ["PAY_SWITCH_AGENT_TOKEN"] = os.environ["PAYSWITCH_AGENT_TOKEN"]


def agent_token():
    return os.environ.get("PAYSWITCH_AGENT_TOKEN") or os.environ.get("PAY_SWITCH_AGENT_TOKEN") or ""


def request(method, path, payload=None, auth=True):
    token = agent_token()
    data = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if auth and token:
        headers["Authorization"] = "Bearer " + token
    req = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            text = resp.read().decode("utf-8", errors="replace")
            return {"status": resp.status, "ok": 200 <= resp.status < 300, "json": json.loads(text)}
    except urllib.error.HTTPError as exc:
        text = exc.read().decode("utf-8", errors="replace")
        try:
            body = json.loads(text)
        except json.JSONDecodeError:
            body = text
        return {"status": exc.code, "ok": False, "json": body}


def task_status(task_id):
    for _ in range(40):
        time.sleep(0.5)
        result = request("GET", "/tasks/" + task_id)
        state = ((result.get("json") or {}).get("status") or {}).get("state")
        if state in {"completed", "failed", "input-required"}:
            return result
    return request("GET", "/tasks/" + task_id)


def compact_task(task):
    payload = task.get("json") or {}
    compact = {
        "task_id": payload.get("id"),
        "state": ((payload.get("status") or {}).get("state")),
        "artifacts": [item.get("artifactId") for item in payload.get("artifacts", [])],
    }
    for item in payload.get("artifacts", []):
        if item.get("artifactId") == "pay_switch_result":
            result = ((item.get("parts") or [{}])[0]).get("data") or {}
            compact.update(
                {
                    "tx_id": result.get("tx_id"),
                    "tx_status": result.get("status"),
                    "error": result.get("error"),
                    "execution_mode": result.get("execution_mode"),
                    "step_count": len(result.get("steps") or []),
                }
            )
    return compact


def submit_case(payee, reason, dry_run, idempotency_key):
    submit = request(
        "POST",
        "/api/payments",
        {
            "amount": 10,
            "currency": "CNY",
            "payee": payee,
            "reason": reason,
            "method": "alipay_qr",
            "dryRun": dry_run,
            "sourceAgent": "codex-proof",
            "idempotencyKey": idempotency_key,
        },
    )
    task_id = (submit.get("json") or {}).get("task_id")
    final = task_status(task_id) if task_id else None
    return {
        "payee": payee,
        "dry_run": dry_run,
        "submit_status": submit.get("status"),
        "task_id": task_id,
        "psl": (submit.get("json") or {}).get("psl"),
        "final": compact_task(final) if final else None,
    }


def ledger_rows(keys):
    if not keys:
        return []
    if not DB_FILE.exists():
        return []
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    placeholders = ",".join("?" for _ in keys)
    rows = []
    for row in con.execute(
        "select tx_id, amount, currency, payee, reason, payment_method, "
        "execution_mode, status, idempotency_key, created_at, completed_at, error "
        f"from transactions where idempotency_key in ({placeholders}) order by created_at",
        keys,
    ):
        rows.append(dict(row))
    return rows


def ledger_rows_for_platforms():
    if not DB_FILE.exists():
        return []
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    placeholders = ",".join("?" for _ in PLATFORMS)
    rows = []
    for row in con.execute(
        "select tx_id, amount, currency, payee, reason, payment_method, "
        "execution_mode, status, idempotency_key, created_at, completed_at, error "
        f"from transactions where payee in ({placeholders}) order by created_at desc limit 40",
        list(PLATFORMS),
    ):
        rows.append(dict(row))
    return rows


def payswitch_json(*args):
    quoted = " ".join(shlex.quote(str(item)) for item in args)
    cmd = (
        "cd "
        + shlex.quote(str(PAYSWITCH_ROOT))
        + " && . .venv/bin/activate && payswitch --json "
        + quoted
    )
    try:
        raw = subprocess.check_output(
            ["bash", "-lc", cmd],
            text=True,
            stderr=subprocess.STDOUT,
            timeout=45,
        )
        return json.loads(raw)
    except Exception as exc:
        return {"error": str(exc)}


def platform_inventory():
    return payswitch_json("platforms")


def card_config():
    return payswitch_json("settings", "payment", "card", "list")


def profile_summary(platforms):
    by_name = {}
    if isinstance(platforms, list):
        by_name = {item.get("name"): item for item in platforms if isinstance(item, dict)}
    result = {}
    for platform in PLATFORMS:
        item = by_name.get(platform) or {}
        result[platform] = {
            "present": bool(item.get("logged_in")),
            "status": item.get("status"),
            "logged_in_at": item.get("logged_in_at"),
            "has_adapter": bool(item.get("has_adapter")),
        }
    return result


def _safe_json_file(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _asset_exists(payload):
    for key in ("asset_path", "path", "file", "file_path", "download_path"):
        value = payload.get(key) if isinstance(payload, dict) else None
        if not value:
            continue
        candidate = Path(str(value))
        if not candidate.is_absolute():
            candidate = DATA_DIR / candidate
        if candidate.exists() and candidate.is_file():
            return True
    if payload.get("url") or payload.get("asset_url") or payload.get("download_url"):
        return True
    return False


def _path_exists(value):
    if not value:
        return False
    candidate = Path(str(value))
    if not candidate.is_absolute():
        candidate = DATA_DIR / candidate
    return candidate.exists() and candidate.is_file()


def _media_key(payload):
    if not isinstance(payload, dict):
        return None
    step_id = payload.get("step_id") or payload.get("id") or payload.get("kind")
    if step_id in REQUIRED_MEDIA_STEPS:
        return step_id
    provider = payload.get("provider")
    capability = payload.get("capability") or payload.get("type")
    for key, expected in REQUIRED_MEDIA_STEPS.items():
        if provider == expected["provider"] and capability == expected["capability"]:
            return key
    return None


def _live_proof_entries(path, payload):
    if not isinstance(payload, dict):
        return []
    if payload.get("schema") != "pay-switch-agent.live-proof.v1":
        return []

    payment = payload.get("payment") if isinstance(payload.get("payment"), dict) else {}
    content_session = (
        payload.get("content_session")
        if isinstance(payload.get("content_session"), dict)
        else {}
    )
    artifacts = payload.get("artifacts") if isinstance(payload.get("artifacts"), dict) else {}
    tx_id = payment.get("tx_id") or content_session.get("linked_payment_tx_id")
    session_id = content_session.get("linked_payment_tx_id") or tx_id
    entries = []

    image = artifacts.get("jimeng_image") if isinstance(artifacts.get("jimeng_image"), dict) else {}
    if image:
        asset_path = image.get("result_screenshot") or image.get("path")
        entries.append(
            {
                "path": str(path),
                "step_id": "jimeng.image",
                "provider": "jimeng",
                "capability": "image_generation",
                "session_id": session_id,
                "tx_id": tx_id,
                "asset_present": _path_exists(asset_path) or bool(image.get("asset_url")),
                "asset_url_present": bool(image.get("asset_url") or image.get("url")),
            }
        )

    video = artifacts.get("jimeng_video") if isinstance(artifacts.get("jimeng_video"), dict) else {}
    if video:
        candidates = video.get("extracted_mp4_candidates")
        candidate_items = candidates if isinstance(candidates, list) else []
        has_mp4 = any(
            _path_exists(item.get("path"))
            for item in candidate_items
            if isinstance(item, dict)
        )
        asset_path = video.get("result_screenshot") or video.get("path")
        entries.append(
            {
                "path": str(path),
                "step_id": "jimeng.video",
                "provider": "jimeng",
                "capability": "video_generation",
                "session_id": session_id,
                "tx_id": tx_id,
                "asset_present": (
                    has_mp4 or _path_exists(asset_path) or bool(video.get("asset_url"))
                ),
                "asset_url_present": bool(video.get("asset_url") or video.get("url")),
            }
        )

    return entries


def media_artifacts():
    roots = [
        DATA_DIR / "evidence",
        DATA_DIR / "artifacts",
        DATA_DIR / "media",
        PAYSWITCH_ROOT / "evidence",
        PAYSWITCH_ROOT / "artifacts",
        PAYSWITCH_ROOT / "media",
        PAYSWITCH_ROOT / "proofs",
        PAYSWITCH_ROOT / "plugins" / "pay-switch-agent" / "docs",
    ]
    manifests = []
    candidate_files = []
    media_suffixes = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".mp4", ".mov", ".webm"}
    for root in roots:
        if not root.exists():
            continue
        for path in list(root.rglob("*"))[:500]:
            if not path.is_file():
                continue
            suffix = path.suffix.lower()
            if suffix == ".json":
                payload = _safe_json_file(path)
                if isinstance(payload, dict):
                    live_entries = _live_proof_entries(path, payload)
                    if live_entries:
                        manifests.extend(live_entries)
                        continue
                    key = _media_key(payload)
                    manifests.append(
                        {
                            "path": str(path),
                            "step_id": key,
                            "provider": payload.get("provider"),
                            "capability": payload.get("capability") or payload.get("type"),
                            "session_id": (
                                payload.get("session_id")
                                or payload.get("session")
                                or payload.get("task_id")
                            ),
                            "tx_id": payload.get("tx_id"),
                            "asset_present": _asset_exists(payload),
                            "asset_url_present": bool(
                                payload.get("url")
                                or payload.get("asset_url")
                                or payload.get("download_url")
                            ),
                        }
                    )
            elif suffix in media_suffixes:
                candidate_files.append(
                    {
                        "path": str(path),
                        "suffix": suffix,
                        "size": path.stat().st_size,
                    }
                )
    by_step = {}
    for item in manifests:
        step_id = item.get("step_id")
        if step_id and item.get("asset_present"):
            by_step.setdefault(step_id, []).append(item)
    sessions = [
        item.get("session_id")
        for items in by_step.values()
        for item in items
        if item.get("session_id")
    ]
    common_sessions = sorted(
        {sid for sid in sessions if sessions.count(sid) >= len(REQUIRED_MEDIA_STEPS)}
    )
    return {
        "required_steps": sorted(REQUIRED_MEDIA_STEPS),
        "by_step": by_step,
        "same_session_candidates": common_sessions,
        "manifests": manifests[:100],
        "candidate_files": candidate_files[:100],
    }


def build_verdict(proof):
    blockers = []
    health = proof.get("health") or {}
    auth_ok = bool(proof["remote"].get("token_present")) and proof["auth"].get(
        "unauthenticated_payment_status"
    ) in {401, 403}
    if not auth_ok:
        blockers.append(
            "PAYSWITCH_AGENT_TOKEN is not proven present or unauthenticated "
            "requests are not rejected."
        )

    platforms = proof.get("platforms")
    platform_items = platforms if isinstance(platforms, list) else []
    platform_map = {
        item.get("name"): item
        for item in platform_items
        if isinstance(item, dict)
    }
    adapter_ok = all((platform_map.get(name) or {}).get("has_adapter") for name in PLATFORMS)
    if not adapter_ok:
        missing = [
            name
            for name in PLATFORMS
            if not (platform_map.get(name) or {}).get("has_adapter")
        ]
        blockers.append("Missing registered adapters: " + ", ".join(missing))

    dry_ok = all(
        (item.get("final") or {}).get("state") == "completed"
        and (item.get("final") or {}).get("execution_mode") == "script"
        for item in proof.get("dry_runs", [])
    ) and len(proof.get("dry_runs", [])) >= len(PLATFORMS)
    if not dry_ok:
        blockers.append(
            "Dry-run adapter proof did not complete in script mode for all "
            "required platforms."
        )

    card = proof.get("card_config") or {}
    cards = card.get("card_instruments") if isinstance(card, dict) else []
    card_ok = bool(
        card.get("allow_card_number_only") or card.get("allow_virtual_card")
    ) and bool(cards)
    if not card_ok:
        blockers.append(
            "No configured sandbox/user-authorized card instrument is visible "
            "in Pay-Switch config."
        )

    profiles = proof.get("profiles") or {}
    profiles_ok = all((profiles.get(name) or {}).get("present") for name in PLATFORMS)
    if not profiles_ok:
        missing = [name for name in PLATFORMS if not (profiles.get(name) or {}).get("present")]
        blockers.append("Missing logged-in profiles: " + ", ".join(missing))

    ledger_by_key = {
        row.get("idempotency_key"): row
        for row in proof.get("ledger_rows", [])
        if isinstance(row, dict)
    }
    live_keys = proof.get("idempotency_keys", {}).get("live", {})
    ledger_ok = bool(live_keys) and all(
        (ledger_by_key.get(key) or {}).get("status") == "completed"
        for key in live_keys.values()
    )
    if not ledger_ok:
        blockers.append("Same-run ledger rows are not completed for all live payment intents.")

    media = proof.get("media_artifacts") or {}
    media_ok = all(media.get("by_step", {}).get(step) for step in REQUIRED_MEDIA_STEPS)
    same_session_ok = bool(media.get("same_session_candidates"))
    if not media_ok:
        blockers.append("Required image/video artifact manifests are missing or have no asset.")
    if media_ok and not same_session_ok:
        blockers.append("Image/video artifacts are not proven to share one session id.")

    return {
        "service_healthy": bool(health.get("ok")),
        "auth_proven": auth_ok,
        "adapters_registered": adapter_ok,
        "dry_run_adapter_proof": dry_ok,
        "card_configured": card_ok,
        "profiles_ready": profiles_ok,
        "live_ledger_completed": ledger_ok,
        "media_artifacts_present": media_ok,
        "same_session_media": same_session_ok,
        "complete_real_payment_and_generation_chain_proven": all(
            [
                auth_ok,
                adapter_ok,
                dry_ok,
                card_ok,
                profiles_ok,
                ledger_ok,
                media_ok,
                same_session_ok,
            ]
        ),
        "blockers": blockers,
    }


load_env()
health = request("GET", "/api/health", auth=False)
agent_card = request("GET", "/.well-known/agent-card.json", auth=False)
unauth = request(
    "POST",
    "/api/payments",
    {"amount": 10, "currency": "CNY", "payee": "kimi", "reason": "unauth proof", "dryRun": True},
    auth=False,
)

dry_keys = {name: "proof-" + name + "-dryrun-20260514" for name in PLATFORMS}
live_keys = {name: "proof-" + name + "-live-20260514" for name in PLATFORMS}

dry_runs = [
    submit_case(name, "sandbox dry-run adapter verification for " + name, True, dry_keys[name])
    for name in PLATFORMS
]
live_blockers = []
if RUN_LIVE_BLOCKERS:
    live_blockers = [
        submit_case(name, "live payment proof attempt for " + name, False, live_keys[name])
        for name in PLATFORMS
    ]

platforms = platform_inventory()
cards = card_config()
profiles = profile_summary(platforms)
media = media_artifacts()

proof = {
    "schema": "pay-switch-agent.remote-proof.v1",
    "remote": {
        "host": "__SSH_TARGET__",
        "payswitch_root": str(PAYSWITCH_ROOT),
        "env_file": str(ENV_FILE),
        "db_file": str(DB_FILE),
        "token_present": bool(agent_token()),
        "token_value": "<redacted>",
    },
    "health": health.get("json"),
    "agent_card": agent_card.get("json"),
    "auth": {
        "unauthenticated_payment_status": unauth.get("status"),
        "unauthenticated_payment_body": unauth.get("json"),
    },
    "platforms": platforms,
    "profiles": profiles,
    "card_config": cards,
    "idempotency_keys": {"dry_run": dry_keys, "live": live_keys},
    "dry_runs": dry_runs,
    "live_blockers": live_blockers,
    "ledger_rows": ledger_rows(list(live_keys.values())),
    "recent_platform_ledger_rows": ledger_rows_for_platforms(),
    "media_artifacts": media,
}
proof["verdict"] = build_verdict(proof)
print(json.dumps(proof, ensure_ascii=False, indent=2))
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Collect Pay-Switch sandbox proof over SSH or locally"
    )
    parser.add_argument("--ssh-target", default="bobo@178.128.93.176")
    parser.add_argument(
        "--local", action="store_true", help="Run the collector on this host without SSH"
    )
    parser.add_argument("--env-file", default="/home/bobo/.payswitch/server.env")
    parser.add_argument("--db-file", default="/home/bobo/.payswitch/payswitch.db")
    parser.add_argument("--payswitch-root", default="/home/bobo/payswitch")
    parser.add_argument("--base-url", default="http://127.0.0.1:8787")
    parser.add_argument("--include-live-blockers", action="store_true")
    parser.add_argument("--out", help="Write proof JSON to this path")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    replacements = {
        "__SSH_TARGET__": "local" if args.local else args.ssh_target,
        "__ENV_FILE__": args.env_file,
        "__DB_FILE__": args.db_file,
        "__PAYSWITCH_ROOT__": args.payswitch_root,
        "__BASE_URL__": args.base_url,
        "__RUN_LIVE_BLOCKERS__": "True" if args.include_live_blockers else "False",
    }
    remote_code = REMOTE_COLLECTOR
    for needle, value in replacements.items():
        remote_code = remote_code.replace(needle, value)

    command = [sys.executable or "python3", "-"]
    if not args.local:
        command = [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            args.ssh_target,
            "python3",
            "-",
        ]

    proc = subprocess.run(
        command,
        input=remote_code,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr)
        return proc.returncode
    if args.out:
        path = Path(args.out)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(proc.stdout, encoding="utf-8")
        print(f"Wrote remote proof: {path}")
    else:
        print(proc.stdout, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
