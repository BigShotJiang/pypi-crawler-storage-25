#!/usr/bin/env python3
"""Pay-Switch Agent plugin utility.

The default path is deliberately non-destructive: probe endpoints, generate plans,
and print payloads. Live submission requires `--execute` plus an agent token.
Installer-provisioned PayAgent client tokens are still stopped by Pay-Switch
Human Gate before any real payment is finalized.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import sys
import time
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urlparse, urlsplit, urlunsplit
from urllib.request import Request, urlopen

DEFAULT_PANEL_URL = "https://clawhunt.store/pay-switch"
DEFAULT_CONFIG_URL = "https://clawhunt.store/api/pay-switch/config"
DEFAULT_PANEL_HEALTH_URL = "https://clawhunt.store/api/pay-switch/health"
TOKEN_ENVS = ("PAYSWITCH_AGENT_TOKEN", "PAY_SWITCH_AGENT_TOKEN")
TOKEN_ENV_DISPLAY = "PAYSWITCH_AGENT_TOKEN or PAY_SWITCH_AGENT_TOKEN"
LIVE_ENV = "PAY_SWITCH_ALLOW_LIVE"
LIVE_TRUE = {"1", "true", "yes", "y", "on"}
BOOTSTRAP_TOKEN_PREFIX = "psw_agent_"
SECRET_ENVELOPE_SCHEMA = "pay-switch.secret-envelope.v1"
SECRET_INBOX_SCHEMA = "pay-switch.secret-inbox.v1"
SECRET_ENVELOPE_ALGORITHM = "X25519-HKDF-SHA256-AES-256-GCM"
DEFAULT_SECRET_INBOX = Path.home() / ".payagent" / "secret-inbox.json"
DEFAULT_SECRET_DIR = Path.home() / ".payagent" / "secrets"
_HKDF_INFO = b"pay-switch.secret-envelope.v1"


def now_iso() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def get_agent_token() -> str | None:
    for name in TOKEN_ENVS:
        token = os.environ.get(name, "").strip()
        if token:
            return token
    return None


def script_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise SystemExit(f"{path} must contain a JSON object")
    return payload


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=True)
        handle.write("\n")


def chmod_owner_only(path: Path) -> None:
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def canonical_json(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode(
        "utf-8"
    )


def secret_crypto() -> tuple[Any, Any, Any, Any, Any]:
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import x25519
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    except ModuleNotFoundError as exc:
        raise SystemExit(
            "Encrypted API key delivery requires the Python package 'cryptography'. "
            "Install it with: python -m pip install --user cryptography"
        ) from exc
    return x25519, hashes, serialization, AESGCM, HKDF


def public_key_fingerprint(public_key: str) -> str:
    digest = hashlib.sha256(public_key.encode("ascii")).digest()
    return b64url_encode(digest[:12])


def raw_public_key(public_key: Any) -> str:
    _x25519, _hashes, serialization, _AESGCM, _HKDF = secret_crypto()
    return b64url_encode(
        public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
    )


def raw_private_key(private_key: Any) -> str:
    _x25519, _hashes, serialization, _AESGCM, _HKDF = secret_crypto()
    return b64url_encode(
        private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )


def generate_secret_inbox() -> dict[str, Any]:
    x25519, _hashes, _serialization, _AESGCM, _HKDF = secret_crypto()
    private_key = x25519.X25519PrivateKey.generate()
    public_key = raw_public_key(private_key.public_key())
    return {
        "schema": SECRET_INBOX_SCHEMA,
        "algorithm": SECRET_ENVELOPE_ALGORITHM,
        "created_at": now_iso(),
        "private_key": raw_private_key(private_key),
        "public_key": public_key,
        "recipient_id": public_key_fingerprint(public_key),
    }


def load_secret_inbox(path: Path = DEFAULT_SECRET_INBOX) -> dict[str, Any]:
    if not path.exists():
        raise SystemExit(
            f"Secret inbox does not exist: {path}. Run: payagent secret init"
        )
    inbox = read_json(path)
    if inbox.get("schema") != SECRET_INBOX_SCHEMA:
        raise SystemExit(f"{path} is not a PayAgent secret inbox")
    if not inbox.get("private_key") or not inbox.get("public_key"):
        raise SystemExit(f"{path} is missing key material")
    return inbox


def ensure_secret_inbox(
    path: Path = DEFAULT_SECRET_INBOX, *, force: bool = False
) -> dict[str, Any]:
    if path.exists() and not force:
        return load_secret_inbox(path)
    inbox = generate_secret_inbox()
    write_json(path, inbox)
    chmod_owner_only(path)
    return inbox


def derive_secret_key(shared_secret: bytes, salt: bytes) -> bytes:
    _x25519, hashes, _serialization, _AESGCM, HKDF = secret_crypto()
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        info=_HKDF_INFO,
    ).derive(shared_secret)


def x25519_public_from_b64(public_key: str) -> Any:
    x25519, _hashes, _serialization, _AESGCM, _HKDF = secret_crypto()
    return x25519.X25519PublicKey.from_public_bytes(b64url_decode(public_key))


def x25519_private_from_b64(private_key: str) -> Any:
    x25519, _hashes, _serialization, _AESGCM, _HKDF = secret_crypto()
    return x25519.X25519PrivateKey.from_private_bytes(b64url_decode(private_key))


def encrypt_secret_envelope(
    secret: str | bytes,
    *,
    recipient_public_key: str,
    provider: str,
    secret_type: str = "api_key",
    key_name: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    x25519, _hashes, _serialization, AESGCM, _HKDF = secret_crypto()
    recipient = x25519_public_from_b64(recipient_public_key)
    ephemeral_private = x25519.X25519PrivateKey.generate()
    salt = os.urandom(16)
    nonce = os.urandom(12)
    aes_key = derive_secret_key(ephemeral_private.exchange(recipient), salt)
    plaintext = secret.encode("utf-8") if isinstance(secret, str) else secret
    envelope: dict[str, Any] = {
        "schema": SECRET_ENVELOPE_SCHEMA,
        "algorithm": SECRET_ENVELOPE_ALGORITHM,
        "provider": provider,
        "secret_type": secret_type or "api_key",
        "key_name": key_name,
        "created_at": now_iso(),
        "recipient_public_key": recipient_public_key,
        "recipient_id": public_key_fingerprint(recipient_public_key),
        "ephemeral_public_key": raw_public_key(ephemeral_private.public_key()),
        "salt": b64url_encode(salt),
        "nonce": b64url_encode(nonce),
        "metadata": dict(metadata or {}),
    }
    ciphertext = AESGCM(aes_key).encrypt(nonce, plaintext, canonical_json(envelope))
    envelope["ciphertext"] = b64url_encode(ciphertext)
    return envelope


def decrypt_secret_envelope(envelope: dict[str, Any], inbox: dict[str, Any]) -> bytes:
    if envelope.get("schema") != SECRET_ENVELOPE_SCHEMA:
        raise SystemExit("Unsupported secret envelope schema")
    if envelope.get("algorithm") != SECRET_ENVELOPE_ALGORITHM:
        raise SystemExit("Unsupported secret envelope algorithm")
    _x25519, _hashes, _serialization, AESGCM, _HKDF = secret_crypto()
    private_key = x25519_private_from_b64(str(inbox["private_key"]))
    actual_public_key = raw_public_key(private_key.public_key())
    inbox_public_key = str(inbox.get("public_key") or "")
    if inbox_public_key and not hmac.compare_digest(inbox_public_key, actual_public_key):
        raise SystemExit("Secret inbox public key does not match private key")
    recipient_public_key = str(envelope.get("recipient_public_key") or "")
    if not recipient_public_key:
        raise SystemExit("Missing recipient public key")
    if not hmac.compare_digest(recipient_public_key, actual_public_key):
        raise SystemExit("recipient public key mismatch")
    recipient_id = str(envelope.get("recipient_id") or "")
    if recipient_id and not hmac.compare_digest(
        recipient_id,
        public_key_fingerprint(actual_public_key),
    ):
        raise SystemExit("recipient id mismatch")
    ephemeral_public = x25519_public_from_b64(str(envelope["ephemeral_public_key"]))
    salt = b64url_decode(str(envelope["salt"]))
    nonce = b64url_decode(str(envelope["nonce"]))
    ciphertext = b64url_decode(str(envelope["ciphertext"]))
    aad_payload = dict(envelope)
    aad_payload.pop("ciphertext", None)
    aes_key = derive_secret_key(private_key.exchange(ephemeral_public), salt)
    try:
        return AESGCM(aes_key).decrypt(nonce, ciphertext, canonical_json(aad_payload))
    except Exception as exc:
        raise SystemExit("Secret envelope authentication failed") from exc


def secret_env_name(provider: str, secret_type: str) -> str:
    safe_provider = "".join(ch if ch.isalnum() else "_" for ch in provider.upper()).strip("_")
    safe_type = "".join(ch if ch.isalnum() else "_" for ch in secret_type.upper()).strip("_")
    if safe_type == "API_KEY":
        return f"{safe_provider}_API_KEY"
    return f"{safe_provider}_{safe_type}"


def default_secret_output_path(envelope: dict[str, Any]) -> Path:
    provider = str(envelope.get("provider") or "provider").lower().replace("/", "_")
    secret_type = str(envelope.get("secret_type") or "secret").lower().replace("/", "_")
    return DEFAULT_SECRET_DIR / f"{provider}-{secret_type}.env"


def maybe_json(text: str) -> Any:
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def request(
    url: str,
    *,
    method: str = "GET",
    payload: Any | None = None,
    token: str | None = None,
    timeout: int = 20,
    headers: dict[str, str] | None = None,
) -> dict[str, Any]:
    data = None
    merged_headers = {
        "Accept": "application/json, text/event-stream, text/plain;q=0.8, */*;q=0.5",
        "User-Agent": "pay-switch-agent-plugin/0.1.0",
    }
    if headers:
        merged_headers.update(headers)
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=True).encode("utf-8")
        merged_headers["Content-Type"] = "application/json"
    if token:
        merged_headers["Authorization"] = f"Bearer {token}"

    req = Request(url, data=data, headers=merged_headers, method=method.upper())
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            text = raw.decode("utf-8", errors="replace")
            parsed = maybe_json(text)
            return {
                "ok": 200 <= resp.status < 300,
                "status": resp.status,
                "url": url,
                "headers": dict(resp.headers.items()),
                "text": text,
                "json": parsed,
            }
    except HTTPError as exc:
        raw = exc.read()
        text = raw.decode("utf-8", errors="replace")
        parsed = maybe_json(text)
        return {
            "ok": False,
            "status": exc.code,
            "url": url,
            "headers": dict(exc.headers.items()) if exc.headers else {},
            "text": text,
            "json": parsed,
        }
    except URLError as exc:
        return {
            "ok": False,
            "status": None,
            "url": url,
            "headers": {},
            "text": str(exc.reason),
            "json": None,
        }


def with_query(url: str, **params: str) -> str:
    parts = urlsplit(url)
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    query.update({key: value for key, value in params.items() if value})
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def get_config(config_url: str) -> dict[str, Any]:
    response = request(config_url)
    if not response["ok"] or not isinstance(response["json"], dict):
        raise SystemExit(
            f"Could not load config from {config_url}: {response['status']} {response['text']}"
        )
    return response["json"]


def direct_health_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    upstream = payload.get("upstream")
    if isinstance(upstream, dict):
        return upstream
    return payload


def has_payment_skill(card: dict[str, Any]) -> bool:
    skills = card.get("skills")
    if not isinstance(skills, list):
        return False
    for skill in skills:
        if isinstance(skill, dict) and skill.get("id") == "payment_intent":
            return True
    return False


def check(name: str, passed: bool, detail: str) -> dict[str, Any]:
    return {"name": name, "passed": bool(passed), "detail": detail}


def bundled_live_proofs() -> list[dict[str, Any]]:
    proof_dir = script_root() / "docs"
    if not proof_dir.exists():
        return []
    proofs: list[dict[str, Any]] = []
    for path in sorted(proof_dir.glob("remote-live-proof-*.json")):
        try:
            proof = read_json(path)
        except (OSError, SystemExit, json.JSONDecodeError):
            continue
        payment = proof.get("payment") if isinstance(proof.get("payment"), dict) else {}
        content = (
            proof.get("content_session")
            if isinstance(proof.get("content_session"), dict)
            else {}
        )
        verdict = proof.get("verdict") if isinstance(proof.get("verdict"), dict) else {}
        artifacts = proof.get("artifacts") if isinstance(proof.get("artifacts"), dict) else {}
        provider = str(content.get("provider") or payment.get("payee") or "").strip()
        if not provider:
            continue
        proofs.append(
            {
                "path": path.relative_to(script_root()).as_posix(),
                "provider": provider,
                "tx_id": payment.get("tx_id"),
                "status": payment.get("status"),
                "amount": payment.get("amount"),
                "currency": payment.get("currency"),
                "method": payment.get("payment_method"),
                "completed_at": payment.get("completed_at"),
                "same_payment_tx_linked": bool(verdict.get("same_payment_tx_linked")),
                "image_generated": bool(
                    verdict.get(f"{provider}_image_generated")
                    or artifacts.get(f"{provider}_image")
                ),
                "video_generated": bool(
                    verdict.get(f"{provider}_video_generated")
                    or artifacts.get(f"{provider}_video")
                ),
                "full_all_platform_chain_completed": bool(
                    verdict.get("full_all_platform_chain_completed")
                ),
            }
        )
    return proofs


def has_jimeng_payment_and_generation_proof(proofs: list[dict[str, Any]]) -> bool:
    return any(
        proof.get("provider") == "jimeng"
        and proof.get("status") == "completed"
        and proof.get("same_payment_tx_linked")
        and proof.get("image_generated")
        and proof.get("video_generated")
        for proof in proofs
    )


def probe(config_url: str, panel_url: str, panel_health_url: str) -> dict[str, Any]:
    panel = request(panel_url, headers={"Accept": "text/html, */*;q=0.5"})
    config = get_config(config_url)
    public_url = str(
        os.environ.get("PAY_SWITCH_PUBLIC_URL") or config.get("public_url") or ""
    ).rstrip("/")
    health_url = str(config.get("health_url") or f"{public_url}/api/health")
    agent_card_url = str(
        config.get("agent_card_url") or f"{public_url}/.well-known/agent-card.json"
    )
    rest_endpoint = str(config.get("rest_endpoint") or f"{public_url}/api/payments")
    a2a_endpoint = str(config.get("a2a_endpoint") or f"{public_url}/a2a")
    events_url = str(config.get("events_url") or f"{public_url}/events")

    panel_health = request(panel_health_url)
    direct_health = request(health_url)
    card_response = request(agent_card_url)
    rest_options = request(
        rest_endpoint,
        method="OPTIONS",
        headers={
            "Origin": "https://clawhunt.store",
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "content-type,authorization",
        },
    )
    rest_unauth = request(rest_endpoint, method="POST", payload={})
    a2a_unauth = request(a2a_endpoint, method="POST", payload={})

    health = direct_health_payload(direct_health.get("json"))
    card = card_response.get("json") if isinstance(card_response.get("json"), dict) else {}
    ai = health.get("ai") if isinstance(health.get("ai"), dict) else {}
    auth = health.get("auth") if isinstance(health.get("auth"), dict) else {}
    computer = health.get("computer_use") if isinstance(health.get("computer_use"), dict) else {}

    checks = [
        check("panel_loads", panel["ok"], f"{panel_url} -> {panel['status']}"),
        check(
            "panel_health_reachable",
            panel_health["ok"],
            f"{panel_health_url} -> {panel_health['status']}",
        ),
        check(
            "public_url_is_https", urlparse(public_url).scheme == "https", public_url or "<missing>"
        ),
        check("config_has_rest", bool(rest_endpoint), rest_endpoint or "<missing>"),
        check("config_has_a2a", bool(a2a_endpoint), a2a_endpoint or "<missing>"),
        check("config_has_events", bool(events_url), events_url or "<missing>"),
        check(
            "direct_health_ok", bool(health.get("ok")), f"{health_url} -> {direct_health['status']}"
        ),
        check("ai_configured", bool(ai.get("configured")), str(ai)),
        check(
            "agent_token_configured_server_side",
            bool(auth.get("agent_token_configured")),
            str(auth),
        ),
        check("browser_runtime_present", bool(computer.get("browser_engine")), str(computer)),
        check(
            "agent_card_loads",
            card_response["ok"],
            f"{agent_card_url} -> {card_response['status']}",
        ),
        check("agent_card_has_payment_intent", has_payment_skill(card), "skill id payment_intent"),
        check(
            "agent_card_uses_bearer",
            "agentToken" in (card.get("securitySchemes") or {}),
            "security scheme agentToken",
        ),
        check(
            "rest_options_ok",
            rest_options["ok"],
            f"{rest_endpoint} OPTIONS -> {rest_options['status']}",
        ),
        check(
            "rest_requires_auth",
            rest_unauth["status"] in {401, 403},
            f"POST without token -> {rest_unauth['status']}",
        ),
        check(
            "a2a_requires_auth",
            a2a_unauth["status"] in {401, 403},
            f"POST without token -> {a2a_unauth['status']}",
        ),
    ]
    control_plane_ready = all(item["passed"] for item in checks)
    live_proofs = bundled_live_proofs()
    jimeng_branch_proven = has_jimeng_payment_and_generation_proof(live_proofs)
    full_chain_proven = any(
        bool(proof.get("full_all_platform_chain_completed")) for proof in live_proofs
    )

    blockers = []
    if not get_agent_token():
        blockers.append(
            f"{TOKEN_ENV_DISPLAY} is not set locally, so authenticated submit was not tested."
        )
    if jimeng_branch_proven:
        blockers.extend(
            [
                (
                    "No reusable sandbox card or stored card authorization is bundled; "
                    "live card or QR approval remains a Human Gate step."
                ),
                (
                    "Kimi, Qwen, and Volcano same-session success evidence is still "
                    "outside the bundled proof set."
                ),
            ]
        )
    else:
        blockers.extend(
            [
                "No sandbox card or user-approved live card handoff was supplied.",
                "No merchant adapter evidence was exposed for Kimi, Qwen, Jimeng, or Volcano.",
                "No same-session ledger, receipt, image, or video success artifact was supplied.",
            ]
        )

    return {
        "schema": "pay-switch-agent.probe.v1",
        "checked_at": now_iso(),
        "config_url": config_url,
        "panel_url": panel_url,
        "public_url": public_url,
        "endpoints": {
            "health": health_url,
            "a2a": a2a_endpoint,
            "rest": rest_endpoint,
            "agent_card": agent_card_url,
            "events": events_url,
            "novnc": config.get("novnc_url"),
        },
        "service": {
            "name": health.get("service"),
            "version": health.get("version"),
            "ai": ai,
            "auth": auth,
            "computer_use": computer,
        },
        "agent_card": {
            "name": card.get("name"),
            "version": card.get("version"),
            "protocolVersion": card.get("protocolVersion"),
            "preferredTransport": card.get("preferredTransport"),
            "skills": card.get("skills", []),
            "metadata": card.get("metadata", {}),
        },
        "checks": checks,
        "bundled_live_proofs": live_proofs,
        "verdict": {
            "control_plane_ready": control_plane_ready,
            "authenticated_intent_ready_if_token_supplied": control_plane_ready,
            "jimeng_payment_and_generation_proven": jimeng_branch_proven,
            "complete_payment_and_generation_chain_proven": full_chain_proven,
            "blockers": blockers,
        },
    }


def print_probe_report(payload: dict[str, Any]) -> None:
    print("Pay-Switch Agent probe")
    print(f"checked_at: {payload['checked_at']}")
    print(f"public_url: {payload['public_url']}")
    print("")
    for item in payload["checks"]:
        mark = "OK" if item["passed"] else "FAIL"
        print(f"[{mark}] {item['name']}: {item['detail']}")
    print("")
    verdict = payload["verdict"]
    ready = "READY" if verdict["control_plane_ready"] else "NOT READY"
    print(f"control_plane: {ready}")
    if payload.get("bundled_live_proofs"):
        print("bundled_live_proofs:")
        for proof in payload["bundled_live_proofs"]:
            outputs = []
            if proof.get("image_generated"):
                outputs.append("image")
            if proof.get("video_generated"):
                outputs.append("video")
            output_text = ",".join(outputs) if outputs else "none"
            amount = proof.get("amount")
            currency = proof.get("currency") or ""
            print(
                "- "
                f"{proof.get('provider')}: {proof.get('status')} "
                f"{amount} {currency} tx={proof.get('tx_id')} outputs={output_text} "
                f"proof={proof.get('path')}"
            )
    jimeng = "PROVEN" if verdict.get("jimeng_payment_and_generation_proven") else "NOT PROVEN"
    full = "PROVEN" if verdict["complete_payment_and_generation_chain_proven"] else "NOT PROVEN"
    print(f"jimeng_payment_and_generation: {jimeng}")
    print(f"complete_all_platform_chain: {full}")
    for blocker in verdict["blockers"]:
        print(f"- {blocker}")


def parse_amounts(items: list[str]) -> dict[str, float]:
    amounts: dict[str, float] = {}
    for item in items:
        if "=" not in item:
            raise SystemExit(f"Invalid --amount-map value: {item}. Use step=amount")
        key, raw = item.split("=", 1)
        try:
            amounts[key.strip()] = float(raw)
        except ValueError as exc:
            raise SystemExit(f"Invalid amount for {key}: {raw}") from exc
    return amounts


def build_plan(args: argparse.Namespace) -> dict[str, Any]:
    template = read_json(script_root() / "flows" / "ai-media-payment-chain.json")
    plan = json.loads(json.dumps(template))
    plan["created_at"] = now_iso()
    plan["session_id"] = args.session_id or f"psw_{uuid.uuid4().hex[:12]}"
    plan["operator"] = {
        "config_url": args.config_url,
        "token_env": TOKEN_ENV_DISPLAY,
        "token_envs": list(TOKEN_ENVS),
        "live_env": LIVE_ENV,
    }
    amount_map = parse_amounts(args.amount_map or [])
    for step in plan.get("steps", []):
        if isinstance(step, dict) and step.get("id") in amount_map:
            step["amount"] = amount_map[step["id"]]
    return plan


def psl_line(intent: dict[str, Any]) -> str:
    amount = intent.get("amount")
    amount_text = str(amount) if amount is not None else "<amount>"
    currency = intent.get("currency") or "CNY"
    payee = intent.get("payee") or intent.get("provider") or "<payee>"
    reason = intent.get("reason") or f"{payee} payment"
    method = intent.get("method") or "card"
    mode = "DRY_RUN" if intent.get("dry_run") else "EXECUTE"
    return f'PAY {amount_text} {currency} TO {payee} FOR "{reason}" VIA {method} {mode}'


def transport_payment_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Return the REST payment body accepted by Pay-Switch."""

    metadata = dict(payload.get("metadata") or {})
    if payload.get("session_id"):
        metadata.setdefault("client_session_id", payload["session_id"])
    body: dict[str, Any] = {
        "amount": payload["amount"],
        "currency": payload.get("currency") or "CNY",
        "payee": payload["payee"],
        "reason": payload.get("reason") or "",
        "method": payload.get("method") or "card",
        "dryRun": bool(payload.get("dry_run")),
        "sourceAgent": metadata.get("source") or "payagent",
        "metadata": metadata,
    }
    if payload.get("idempotency_key"):
        body["idempotencyKey"] = payload["idempotency_key"]
    if payload.get("product"):
        body["product"] = payload["product"]
    return body


def a2a_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Return a JSON-RPC A2A payload for /a2a."""

    payment = dict(payload)
    payment.pop("execute", None)
    metadata = dict(payment.get("metadata") or {})
    metadata.setdefault("source", "payagent")
    payment["metadata"] = metadata
    return {
        "jsonrpc": "2.0",
        "id": payload.get("idempotency_key") or f"payagent-{uuid.uuid4().hex}",
        "method": "message/send",
        "params": {
            "message": {
                "role": "user",
                "parts": [{"kind": "data", "data": {"payment": payment}}],
                "metadata": {"source_agent": metadata.get("source") or "payagent"},
            }
        },
    }


def transport_payload(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
    if endpoint == "a2a":
        return a2a_payload(payload)
    return transport_payment_payload(payload)


def attach_secret_delivery(args: argparse.Namespace, payload: dict[str, Any]) -> dict[str, Any]:
    request_api_key = bool(getattr(args, "request_api_key", False))
    recipient_public_key = str(getattr(args, "secret_recipient_public_key", "") or "").strip()
    if not request_api_key and not recipient_public_key:
        return payload
    if not recipient_public_key:
        inbox = ensure_secret_inbox()
        recipient_public_key = str(inbox["public_key"])

    metadata = dict(payload.get("metadata") or {})
    metadata["request_api_key"] = True
    metadata["secret_delivery"] = {
        "requested": True,
        "mode": "encrypted_a2a",
        "schema": SECRET_ENVELOPE_SCHEMA,
        "secret_type": getattr(args, "secret_type", None) or "api_key",
        "key_name": getattr(args, "secret_key_name", None),
        "recipient_public_key": recipient_public_key,
    }
    payload["metadata"] = metadata
    return payload


def find_step(plan: dict[str, Any], step_id: str) -> dict[str, Any]:
    steps = plan.get("steps")
    if not isinstance(steps, list):
        raise SystemExit("Plan does not contain a steps array")
    for step in steps:
        if isinstance(step, dict) and step.get("id") == step_id:
            return step
    raise SystemExit(f"Step not found: {step_id}")


def submit_payload(args: argparse.Namespace) -> dict[str, Any]:
    if args.plan:
        plan = read_json(Path(args.plan))
        step = find_step(plan, args.step)
        if step.get("type") != "payment_intent":
            raise SystemExit(
                f"Step {args.step} is {step.get('type')}; only payment_intent can be submitted"
            )
        amount = args.amount if args.amount is not None else step.get("amount")
        if amount is None:
            raise SystemExit("--amount is required because the plan step amount is null")
        payload = {
            "idempotency_key": args.idempotency_key or f"{args.step}:{uuid.uuid4().hex}",
            "session_id": plan.get("session_id") or f"psw_{uuid.uuid4().hex[:12]}",
            "amount": amount,
            "currency": args.currency or step.get("currency") or "CNY",
            "payee": args.payee or step.get("payee"),
            "reason": args.reason or step.get("reason"),
            "method": args.method or step.get("method") or "card",
            "metadata": {
                "source": "pay-switch-agent-plugin",
                "plan_schema": plan.get("schema"),
                "scenario": plan.get("scenario"),
                "step_id": args.step,
                "single_surface": bool((plan.get("mode") or {}).get("single_surface")),
            },
        }
        if step.get("product"):
            payload["product"] = step["product"]
        if args.product:
            payload["product"] = args.product
        return attach_secret_delivery(args, payload)

    missing = [name for name in ("payee", "amount", "reason") if getattr(args, name) in (None, "")]
    if missing:
        raise SystemExit(f"Missing required arguments without --plan: {', '.join(missing)}")
    payload = {
        "idempotency_key": args.idempotency_key or f"manual:{uuid.uuid4().hex}",
        "session_id": args.session_id or f"psw_{uuid.uuid4().hex[:12]}",
        "amount": args.amount,
        "currency": args.currency or "CNY",
        "payee": args.payee,
        "reason": args.reason,
        "method": args.method or "card",
        "metadata": {
            "source": "pay-switch-agent-plugin",
            "single_surface": True,
        },
    }
    if args.product:
        payload["product"] = args.product
    return attach_secret_delivery(args, payload)


def command_probe(args: argparse.Namespace) -> int:
    payload = probe(args.config_url, args.panel_url, args.panel_health_url)
    if args.json:
        print(json.dumps(payload, indent=2, ensure_ascii=True))
    else:
        print_probe_report(payload)
    return 0 if payload["verdict"]["control_plane_ready"] else 2


def command_plan(args: argparse.Namespace) -> int:
    plan = build_plan(args)
    if args.out:
        out = Path(args.out)
        write_json(out, plan)
        print(f"Wrote plan: {out}")
    else:
        print(json.dumps(plan, indent=2, ensure_ascii=True))
    return 0


def command_submit(args: argparse.Namespace) -> int:
    payload = submit_payload(args)
    payload["execute"] = bool(args.execute)
    payload["dry_run"] = not bool(args.execute)

    if not args.execute:
        print("Dry-run payload. No network submission was made.")
        print(json.dumps(payload, indent=2, ensure_ascii=True))
        print("")
        print(psl_line(payload))
        return 0

    token = get_agent_token()
    if not token:
        raise SystemExit(f"{TOKEN_ENV_DISPLAY} is required for --execute")
    live_allowed = token.startswith(BOOTSTRAP_TOKEN_PREFIX) or (
        os.environ.get(LIVE_ENV, "").lower() in LIVE_TRUE
    )
    if not live_allowed:
        raise SystemExit(f"{LIVE_ENV}=1 is required for --execute")

    config = get_config(args.config_url)
    endpoint = (
        config.get("rest_endpoint") if args.endpoint == "rest" else config.get("a2a_endpoint")
    )
    if not endpoint:
        raise SystemExit(f"Missing endpoint for {args.endpoint}")
    body = transport_payload(args.endpoint, payload)
    response = request(str(endpoint), method="POST", payload=body, token=token)
    print(
        json.dumps(
            {
                "endpoint": endpoint,
                "transport": args.endpoint,
                "status": response["status"],
                "ok": response["ok"],
                "response": response["json"] or response["text"],
            },
            indent=2,
            ensure_ascii=True,
        )
    )
    return 0 if response["ok"] else 3


def command_events(args: argparse.Namespace) -> int:
    config = get_config(args.config_url)
    events_url = str(config.get("events_url") or "").strip()
    if not events_url:
        raise SystemExit("Config does not include events_url")
    if args.session_id:
        events_url = with_query(events_url, session_id=args.session_id)
    token = get_agent_token() if args.with_token else None
    headers = {"Accept": "text/event-stream"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = Request(events_url, headers=headers, method="GET")
    count = 0
    started = time.time()
    try:
        with urlopen(req, timeout=args.timeout) as resp:
            print(f"Connected: {events_url}")
            for raw in resp:
                line = raw.decode("utf-8", errors="replace").rstrip("\n")
                if line.startswith("data:"):
                    print(line[5:].strip())
                    count += 1
                    if args.limit and count >= args.limit:
                        break
                if args.max_seconds and time.time() - started > args.max_seconds:
                    break
    except HTTPError as exc:
        print(f"Event stream failed: HTTP {exc.code}", file=sys.stderr)
        return 3
    except URLError as exc:
        print(f"Event stream failed: {exc.reason}", file=sys.stderr)
        return 3
    return 0


def read_optional_text(value: str | None, path: str | None) -> str | None:
    if value:
        return value
    if path:
        return Path(path).read_text(encoding="utf-8").strip()
    return None


def parse_json_items(items: list[str] | None) -> list[dict[str, Any]]:
    parsed: list[dict[str, Any]] = []
    for item in items or []:
        try:
            payload = json.loads(item)
        except json.JSONDecodeError:
            payload = read_json(Path(item))
        if not isinstance(payload, dict):
            raise SystemExit(f"Evidence item must be a JSON object: {item}")
        parsed.append(payload)
    return parsed


def command_confirm(args: argparse.Namespace) -> int:
    token = get_agent_token()
    if not token:
        raise SystemExit(f"{TOKEN_ENV_DISPLAY} is required for confirm")
    config = get_config(args.config_url)
    template = str(
        config.get("session_confirm_endpoint")
        or f"{str(config.get('public_url') or '').rstrip('/')}/api/sessions/{{session_id}}:confirm"
    )
    if not template or "{session_id}" not in template:
        raise SystemExit("Config does not include a valid session_confirm_endpoint")
    endpoint = template.replace("{session_id}", args.session_id)
    body = {
        "success": bool(args.success),
        "apiKey": read_optional_text(args.api_key, args.api_key_file),
        "secretType": args.secret_type,
        "keyName": args.key_name,
        "evidenceArtifacts": parse_json_items(args.evidence or []),
        "generatedOutputs": parse_json_items(args.output or []),
        "note": args.note,
    }
    body = {key: value for key, value in body.items() if value not in (None, [], "")}
    response = request(endpoint, method="POST", payload=body, token=token)
    print(
        json.dumps(
            {
                "endpoint": endpoint,
                "status": response["status"],
                "ok": response["ok"],
                "response": response["json"] or response["text"],
            },
            indent=2,
            ensure_ascii=True,
        )
    )
    return 0 if response["ok"] else 3


def command_secret_init(args: argparse.Namespace) -> int:
    path = Path(args.out) if args.out else DEFAULT_SECRET_INBOX
    inbox = ensure_secret_inbox(path, force=args.force)
    print("PayAgent encrypted secret inbox")
    print(f"path: {path}")
    print(f"recipient_id: {inbox['recipient_id']}")
    print(f"recipient_public_key: {inbox['public_key']}")
    print("private_key: stored locally only")
    return 0


def command_secret_public(args: argparse.Namespace) -> int:
    path = Path(args.inbox) if args.inbox else DEFAULT_SECRET_INBOX
    inbox = load_secret_inbox(path)
    payload = {
        "schema": SECRET_INBOX_SCHEMA,
        "algorithm": inbox.get("algorithm"),
        "recipient_id": inbox.get("recipient_id"),
        "recipient_public_key": inbox.get("public_key"),
    }
    if args.json:
        print(json.dumps(payload, indent=2, ensure_ascii=True))
    else:
        print(payload["recipient_public_key"])
    return 0


def read_secret_input(args: argparse.Namespace) -> bytes:
    if args.secret is not None:
        return args.secret.encode("utf-8")
    if args.secret_file:
        return Path(args.secret_file).read_bytes()
    raise SystemExit("--secret or --secret-file is required")


def command_secret_encrypt(args: argparse.Namespace) -> int:
    recipient_public_key = str(args.recipient_public_key or "").strip()
    if not recipient_public_key:
        inbox = load_secret_inbox(Path(args.inbox) if args.inbox else DEFAULT_SECRET_INBOX)
        recipient_public_key = str(inbox["public_key"])
    envelope = encrypt_secret_envelope(
        read_secret_input(args),
        recipient_public_key=recipient_public_key,
        provider=args.provider,
        secret_type=args.secret_type,
        key_name=args.key_name,
        metadata={"source": "payagent"},
    )
    if args.out:
        out = Path(args.out)
        write_json(out, envelope)
        chmod_owner_only(out)
        print(f"Wrote encrypted secret envelope: {out}")
    else:
        print(json.dumps(envelope, indent=2, ensure_ascii=True))
    return 0


def command_secret_decrypt(args: argparse.Namespace) -> int:
    inbox = load_secret_inbox(Path(args.inbox) if args.inbox else DEFAULT_SECRET_INBOX)
    payload = read_json(Path(args.input))
    envelope = payload.get("envelope") if isinstance(payload.get("envelope"), dict) else payload
    secret = decrypt_secret_envelope(envelope, inbox)
    out = Path(args.out) if args.out else default_secret_output_path(envelope)
    out.parent.mkdir(parents=True, exist_ok=True)
    if args.raw:
        out.write_bytes(secret)
    else:
        provider = str(envelope.get("provider") or "PROVIDER")
        secret_type = str(envelope.get("secret_type") or "SECRET")
        env_name = args.env_name or secret_env_name(provider, secret_type)
        out.write_text(f"{env_name}={secret.decode('utf-8')}\n", encoding="utf-8")
    chmod_owner_only(out)
    print(f"Wrote decrypted secret: {out}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Pay-Switch Agent plugin utility")
    sub = parser.add_subparsers(dest="command", required=True)

    probe_parser = sub.add_parser(
        "probe", help="Probe public endpoints and print readiness verdict"
    )
    probe_parser.add_argument(
        "--config-url", default=os.environ.get("PAY_SWITCH_CONFIG_URL", DEFAULT_CONFIG_URL)
    )
    probe_parser.add_argument(
        "--panel-url", default=os.environ.get("PAY_SWITCH_PANEL_URL", DEFAULT_PANEL_URL)
    )
    probe_parser.add_argument(
        "--panel-health-url",
        default=os.environ.get("PAY_SWITCH_PANEL_HEALTH_URL", DEFAULT_PANEL_HEALTH_URL),
    )
    probe_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    probe_parser.set_defaults(func=command_probe)

    plan_parser = sub.add_parser("plan", help="Build the default AI media payment-chain plan")
    plan_parser.add_argument(
        "--config-url", default=os.environ.get("PAY_SWITCH_CONFIG_URL", DEFAULT_CONFIG_URL)
    )
    plan_parser.add_argument("--session-id")
    plan_parser.add_argument(
        "--amount-map", action="append", help="Set step amount, for example jimeng.credits=50"
    )
    plan_parser.add_argument("--out", help="Write plan JSON to this path")
    plan_parser.set_defaults(func=command_plan)

    submit_parser = sub.add_parser("submit", help="Dry-run or execute a guarded payment intent")
    submit_parser.add_argument(
        "--config-url", default=os.environ.get("PAY_SWITCH_CONFIG_URL", DEFAULT_CONFIG_URL)
    )
    submit_parser.add_argument("--plan", help="Plan JSON path")
    submit_parser.add_argument("--step", default="jimeng.credits", help="Step id inside the plan")
    submit_parser.add_argument("--session-id")
    submit_parser.add_argument("--payee")
    submit_parser.add_argument("--amount", type=float)
    submit_parser.add_argument("--currency", default="CNY")
    submit_parser.add_argument("--reason")
    submit_parser.add_argument("--method")
    submit_parser.add_argument("--product")
    submit_parser.add_argument("--idempotency-key")
    submit_parser.add_argument("--endpoint", choices=["rest", "a2a"], default="rest")
    submit_parser.add_argument(
        "--request-api-key",
        action="store_true",
        help="Ask Pay-Switch to return the purchased provider API key as an encrypted envelope.",
    )
    submit_parser.add_argument(
        "--secret-recipient-public-key",
        help="Recipient public key for encrypted API-key delivery. Defaults to local inbox.",
    )
    submit_parser.add_argument("--secret-type", default="api_key")
    submit_parser.add_argument("--secret-key-name")
    submit_parser.add_argument(
        "--execute",
        action="store_true",
        help="Post to Pay-Switch using the managed client token or operator token.",
    )
    submit_parser.set_defaults(func=command_submit)

    confirm_parser = sub.add_parser(
        "confirm",
        help="Confirm a Human Gate session and attach encrypted API-key or media evidence",
    )
    confirm_parser.add_argument(
        "--config-url", default=os.environ.get("PAY_SWITCH_CONFIG_URL", DEFAULT_CONFIG_URL)
    )
    confirm_parser.add_argument("--session-id", required=True)
    confirm_parser.add_argument("--success", dest="success", action="store_true", default=True)
    confirm_parser.add_argument("--failed", dest="success", action="store_false")
    confirm_parser.add_argument("--api-key", help="Plain API key from a provider adapter")
    confirm_parser.add_argument("--api-key-file", help="File containing the provider API key")
    confirm_parser.add_argument("--secret-type", default="api_key")
    confirm_parser.add_argument("--key-name")
    confirm_parser.add_argument(
        "--evidence",
        action="append",
        help="Evidence JSON object or path. Repeat for ledger/image/video artifacts.",
    )
    confirm_parser.add_argument(
        "--output",
        action="append",
        help="Generated output JSON object or path. Repeat for image/video artifacts.",
    )
    confirm_parser.add_argument("--note")
    confirm_parser.set_defaults(func=command_confirm)

    secret_parser = sub.add_parser("secret", help="Manage encrypted API-key delivery")
    secret_sub = secret_parser.add_subparsers(dest="secret_command", required=True)

    secret_init = secret_sub.add_parser(
        "init", help="Create the local receiving-agent keypair and decoder inbox"
    )
    secret_init.add_argument("--out", help=f"Secret inbox path. Default: {DEFAULT_SECRET_INBOX}")
    secret_init.add_argument("--force", action="store_true", help="Rotate the local inbox keypair")
    secret_init.set_defaults(func=command_secret_init)

    secret_public = secret_sub.add_parser("public", help="Print the receiving-agent public key")
    secret_public.add_argument(
        "--inbox", help=f"Secret inbox path. Default: {DEFAULT_SECRET_INBOX}"
    )
    secret_public.add_argument("--json", action="store_true")
    secret_public.set_defaults(func=command_secret_public)

    secret_encrypt = secret_sub.add_parser(
        "encrypt", help="Encrypt a provider API key envelope for test or adapter handoff"
    )
    secret_encrypt.add_argument("--provider", required=True)
    secret_encrypt.add_argument("--secret-type", default="api_key")
    secret_encrypt.add_argument("--key-name")
    secret_encrypt.add_argument("--secret")
    secret_encrypt.add_argument("--secret-file")
    secret_encrypt.add_argument("--recipient-public-key")
    secret_encrypt.add_argument(
        "--inbox", help="Use the local inbox public key when recipient is omitted"
    )
    secret_encrypt.add_argument("--out")
    secret_encrypt.set_defaults(func=command_secret_encrypt)

    secret_decrypt = secret_sub.add_parser(
        "decrypt", help="Decrypt an encrypted API-key envelope into a local env file"
    )
    secret_decrypt.add_argument("--in", dest="input", required=True, help="Envelope JSON path")
    secret_decrypt.add_argument(
        "--inbox", help=f"Secret inbox path. Default: {DEFAULT_SECRET_INBOX}"
    )
    secret_decrypt.add_argument(
        "--out", help="Output path. Defaults to ~/.payagent/secrets/<provider>-<type>.env"
    )
    secret_decrypt.add_argument("--env-name", help="Environment variable name for env-file output")
    secret_decrypt.add_argument("--raw", action="store_true", help="Write only the secret bytes")
    secret_decrypt.set_defaults(func=command_secret_decrypt)

    events_parser = sub.add_parser("events", help="Watch the Pay-Switch SSE event stream")
    events_parser.add_argument(
        "--config-url", default=os.environ.get("PAY_SWITCH_CONFIG_URL", DEFAULT_CONFIG_URL)
    )
    events_parser.add_argument("--session-id")
    events_parser.add_argument("--with-token", action="store_true")
    events_parser.add_argument("--limit", type=int, default=0)
    events_parser.add_argument("--timeout", type=int, default=60)
    events_parser.add_argument("--max-seconds", type=int, default=0)
    events_parser.set_defaults(func=command_events)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
