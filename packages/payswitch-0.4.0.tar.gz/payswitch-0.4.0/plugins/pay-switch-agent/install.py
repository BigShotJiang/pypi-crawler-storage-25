#!/usr/bin/env python3
"""Install the Pay-Switch Agent plugin as a local ``payagent`` command.

The installer is intentionally dependency-free. When it is executed from inside
the repository it copies the local plugin directory. When it is executed through
the public Pay-Switch one-liner, it downloads a PayAgent plugin archive and
extracts only ``plugins/pay-switch-agent``.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import site
import stat
import tempfile
import urllib.request
import zipfile
from pathlib import Path

REPO_ZIP_URL = "https://github.com/Arxchibobo/payswitch/archive/refs/heads/main.zip"
ARCHIVE_PLUGIN_PREFIX = "payswitch-main/plugins/pay-switch-agent/"
DEFAULT_CONFIG_URL = "https://clawhunt.store/api/pay-switch/config"
DEFAULT_PANEL_URL = "https://clawhunt.store/pay-switch"
DEFAULT_BOOTSTRAP_URL = ""


def user_base_bin() -> Path:
    if os.name == "nt":
        return Path(site.getuserbase()) / "Scripts"
    return Path.home() / ".local" / "bin"


def default_install_dir() -> Path:
    return Path.home() / ".payagent" / "pay-switch-agent"


def is_plugin_root(path: Path) -> bool:
    return (
        (path / ".codex-plugin" / "plugin.json").exists()
        and (path / "scripts" / "payswitch_agent.py").exists()
        and (path / "flows" / "ai-media-payment-chain.json").exists()
    )


def local_plugin_root() -> Path | None:
    file_name = globals().get("__file__")
    if not file_name:
        return None
    here = Path(file_name).resolve().parent
    return here if is_plugin_root(here) else None


def copytree_clean(source: Path, target: Path, *, force: bool) -> None:
    if target.exists():
        if not force:
            raise SystemExit(
                f"{target} already exists. Re-run with --force to replace it."
            )
        shutil.rmtree(target)
    ignore = shutil.ignore_patterns(
        "__pycache__",
        "*.pyc",
        ".pytest_cache",
        "dist",
        "build",
        "*.egg-info",
    )
    shutil.copytree(source, target, ignore=ignore)


def download_plugin(target: Path, *, force: bool, repo_zip_url: str) -> None:
    with tempfile.TemporaryDirectory(prefix="payagent-install-") as tmp:
        tmp_path = Path(tmp)
        archive = tmp_path / "payswitch-main.zip"
        urllib.request.urlretrieve(repo_zip_url, archive)
        extracted = tmp_path / "plugin"
        extracted.mkdir()
        with zipfile.ZipFile(archive) as zf:
            members = [
                name for name in zf.namelist() if name.startswith(ARCHIVE_PLUGIN_PREFIX)
            ]
            if not members:
                raise SystemExit("Plugin archive did not contain plugins/pay-switch-agent")
            for name in members:
                rel = name.removeprefix(ARCHIVE_PLUGIN_PREFIX)
                if not rel:
                    continue
                destination = extracted / rel
                if name.endswith("/"):
                    destination.mkdir(parents=True, exist_ok=True)
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(name) as src, destination.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
        copytree_clean(extracted, target, force=force)


def install_plugin(
    source: Path | None,
    target: Path,
    *,
    force: bool,
    repo_zip_url: str,
) -> str:
    if source is not None:
        source = source.resolve()
        if not is_plugin_root(source):
            raise SystemExit(f"{source} is not a Pay-Switch Agent plugin root")
        copytree_clean(source, target, force=force)
        return "local"

    local = local_plugin_root()
    if local is not None:
        copytree_clean(local, target, force=force)
        return "local"

    download_plugin(target, force=force, repo_zip_url=repo_zip_url)
    return "archive"


def request_bootstrap_token(bootstrap_url: str) -> dict[str, str]:
    if not bootstrap_url:
        return {}
    req = urllib.request.Request(
        bootstrap_url,
        data=b"{}",
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        print(f"bootstrap: skipped ({exc})")
        return {}
    if not isinstance(payload, dict):
        return {}
    token = str(payload.get("token") or "").strip()
    if not token:
        return {}
    return {
        "PAY_SWITCH_AGENT_TOKEN": token,
        "PAY_SWITCH_ALLOW_LIVE": "1",
    }


def merge_env_lines(existing: list[str], updates: dict[str, str]) -> list[str]:
    if not updates:
        return existing
    seen: set[str] = set()
    merged: list[str] = []
    for line in existing:
        key = line.split("=", 1)[0].strip() if "=" in line and not line.lstrip().startswith("#") else ""
        if key in updates:
            merged.append(f"{key}={updates[key]}")
            seen.add(key)
        else:
            merged.append(line)
    for key, value in updates.items():
        if key not in seen:
            merged.append(f"{key}={value}")
    return merged


def write_env(
    home: Path,
    *,
    config_url: str,
    panel_url: str,
    bootstrap_env: dict[str, str],
) -> Path:
    home.mkdir(parents=True, exist_ok=True)
    env_path = home / "payagent.env"
    if env_path.exists():
        lines = env_path.read_text(encoding="utf-8").splitlines()
        env_path.write_text("\n".join(merge_env_lines(lines, bootstrap_env)) + "\n", encoding="utf-8")
        try:
            env_path.chmod(stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass
        return env_path
    lines = [
        f"PAY_SWITCH_CONFIG_URL={config_url}",
        f"PAY_SWITCH_PANEL_URL={panel_url}",
    ]
    if bootstrap_env:
        lines.extend(
            [
                "PAY_SWITCH_AGENT_TOKEN=" + bootstrap_env["PAY_SWITCH_AGENT_TOKEN"],
                "PAY_SWITCH_ALLOW_LIVE=1",
            ]
        )
    else:
        lines.extend(
            [
                "# PAY_SWITCH_AGENT_TOKEN=<auto-provisioned by installer when available>",
                "# PAY_SWITCH_ALLOW_LIVE=1",
            ]
        )
    env_path.write_text("\n".join([*lines, ""]), encoding="utf-8")
    try:
        env_path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
    return env_path


def shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\"'\"'") + "'"


def write_unix_wrapper(path: Path, install_dir: Path, env_path: Path) -> None:
    content = f"""#!/usr/bin/env sh
PAYAGENT_PLUGIN_DIR={shell_quote(str(install_dir))}
PAYAGENT_ENV={shell_quote(str(env_path))}
if [ -f "$PAYAGENT_ENV" ]; then
  set -a
  . "$PAYAGENT_ENV"
  set +a
fi
if command -v python3 >/dev/null 2>&1; then
  exec python3 "$PAYAGENT_PLUGIN_DIR/scripts/payswitch_agent.py" "$@"
fi
exec python "$PAYAGENT_PLUGIN_DIR/scripts/payswitch_agent.py" "$@"
"""
    path.write_text(content, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def write_windows_wrapper(path: Path, install_dir: Path, env_path: Path) -> None:
    content = f"""@echo off
set "PAYAGENT_PLUGIN_DIR={install_dir}"
set "PAYAGENT_ENV={env_path}"
if exist "%PAYAGENT_ENV%" (
  for /f "usebackq tokens=1,* delims==" %%A in ("%PAYAGENT_ENV%") do (
    echo %%A| findstr /b "#" >nul
    if errorlevel 1 set "%%A=%%B"
  )
)
python "%PAYAGENT_PLUGIN_DIR%\\scripts\\payswitch_agent.py" %*
"""
    path.write_text(content, encoding="utf-8")


def write_wrappers(bin_dir: Path, install_dir: Path, env_path: Path) -> list[Path]:
    bin_dir.mkdir(parents=True, exist_ok=True)
    wrappers: list[Path] = []
    if os.name == "nt":
        cmd = bin_dir / "payagent.cmd"
        write_windows_wrapper(cmd, install_dir, env_path)
        wrappers.append(cmd)
        ps1 = bin_dir / "payagent.ps1"
        install_dir_ps = str(install_dir).replace("'", "''")
        env_path_ps = str(env_path).replace("'", "''")
        ps1.write_text(
            "\n".join(
                [
                    f"$env:PAYAGENT_PLUGIN_DIR = '{install_dir_ps}'",
                    f"$env:PAYAGENT_ENV = '{env_path_ps}'",
                    "if (Test-Path $env:PAYAGENT_ENV) {",
                    "  Get-Content $env:PAYAGENT_ENV | ForEach-Object {",
                    "    if ($_ -and -not $_.StartsWith('#') -and $_.Contains('=')) {",
                    "      $k,$v = $_.Split('=',2)",
                    "      [Environment]::SetEnvironmentVariable($k, $v, 'Process')",
                    "    }",
                    "  }",
                    "}",
                    "python \"$env:PAYAGENT_PLUGIN_DIR\\scripts\\payswitch_agent.py\" @args",
                    "",
                ]
            ),
            encoding="utf-8",
        )
        wrappers.append(ps1)
    else:
        wrapper = bin_dir / "payagent"
        write_unix_wrapper(wrapper, install_dir, env_path)
        wrappers.append(wrapper)
    return wrappers


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Install the Pay-Switch Agent plugin")
    parser.add_argument(
        "--source",
        type=Path,
        help="Copy from a local plugin root instead of GitHub",
    )
    parser.add_argument("--install-dir", type=Path, default=default_install_dir())
    parser.add_argument("--bin-dir", type=Path, default=user_base_bin())
    parser.add_argument(
        "--config-url",
        default=os.environ.get("PAY_SWITCH_CONFIG_URL", DEFAULT_CONFIG_URL),
    )
    parser.add_argument(
        "--panel-url",
        default=os.environ.get("PAY_SWITCH_PANEL_URL", DEFAULT_PANEL_URL),
    )
    parser.add_argument(
        "--bootstrap-url",
        default=os.environ.get("PAY_SWITCH_BOOTSTRAP_URL", DEFAULT_BOOTSTRAP_URL),
        help="Optional Pay-Switch bootstrap endpoint for a managed client token",
    )
    parser.add_argument("--repo-zip-url", default=REPO_ZIP_URL)
    parser.add_argument(
        "--force",
        action="store_true",
        help="Replace an existing installed plugin directory",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    install_dir = args.install_dir.expanduser().resolve()
    bin_dir = args.bin_dir.expanduser().resolve()
    payagent_home = install_dir.parent

    source_kind = install_plugin(
        args.source,
        install_dir,
        force=args.force,
        repo_zip_url=args.repo_zip_url,
    )
    bootstrap_env = request_bootstrap_token(str(args.bootstrap_url or "").strip())
    env_path = write_env(
        payagent_home,
        config_url=args.config_url,
        panel_url=args.panel_url,
        bootstrap_env=bootstrap_env,
    )
    wrappers = write_wrappers(bin_dir, install_dir, env_path)

    print("PayAgent installed")
    print(f"source: {source_kind}")
    print(f"plugin: {install_dir}")
    print(f"env: {env_path}")
    print(f"token: {'auto-provisioned' if bootstrap_env else 'not configured'}")
    for wrapper in wrappers:
        print(f"command: {wrapper}")
    if str(bin_dir) not in os.environ.get("PATH", ""):
        print(f"PATH hint: add {bin_dir} to PATH, or run the command path above directly.")
    print("")
    print("Next:")
    print("  payagent secret init")
    print("  payagent probe")
    print(
        "  "
        'payagent submit --payee jimeng --amount 50 '
        '--currency CNY '
        '--reason "Jimeng points top-up for image and video generation" '
        "--method alipay_qr --execute"
    )
    print(
        "  "
        'payagent submit --payee deepseek --product api-key --amount 10 '
        '--currency CNY --reason "DeepSeek API key purchase/top-up" '
        "--method alipay_qr --request-api-key --execute"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
