# Pay-Switch Payment Channel Expansion Plan

Date: 2026-05-11

## Purpose

Pay-Switch has now validated the core control-plane idea:

```text
intent -> guard -> protocol / adapter / recipe / Computer Use -> human gate -> ledger
```

DeepSeek proved the loop in two useful ways:

1. an unknown-site Computer Use run can reach a real payment result, and
2. a successful trace can be promoted into a recipe-backed adapter.

The next question is payment-channel expansion. Today the proven happy path is
Alipay QR. The next product step is to make payment method selection explicit,
configurable, and safe enough to support WeChat QR, Stripe Checkout, and limited
credit-card autofill without blurring the human authorization boundary.

The card MVP is intentionally narrower than generic autofill:

```text
Pay-Switch may fill the card number.
The user fills expiry, CVV, OTP, 3DS, and final confirmation.
```

This should be named `card_number_only`, not `cc_autofill`, because the product
promise is deliberately limited.

## Architecture Review

### What is clear

The high-level framework is now understandable:

```text
Protocol connector
-> Site adapter
-> Experience recipe
-> External Computer Use
-> Human gate
```

This is the right shape. Pay-Switch is not a wallet, not the merchant of record,
and not a general browser bot. It is a governed checkout execution layer.

The current stage model is also directionally correct:

```text
guard
-> login/access preflight
-> intent resolution
-> offer discovery
-> selected offer confirmation
-> payment execution
-> human authorization
-> result detection
```

This prevents the dangerous failure mode we saw with Kimi: reaching payment
without first understanding the actual plan, billing cycle, or user intent.

### What is still unclear

The framework still needs three first-class contracts:

1. Payment method preference and routing.
2. Payment instrument safety.
3. Channel-specific human gates and result detection.

Without those contracts, `PaymentMethod.auto` is only a placeholder. It cannot
yet answer:

- should this checkout try Alipay first, then WeChat, then card?
- is Stripe a protocol path, a hosted checkout page, or a card form?
- is a saved card allowed for this merchant and amount?
- can Pay-Switch fill a card number, or must the browser/user do it?
- is the detected card form a direct DOM field or a provider iframe?
- when should CVV, OTP, payment password, QR scan, or final confirm pause?

## Product Principle

Payment expansion should not mean "automate more sensitive things."

It should mean:

```text
make more payment paths discoverable
make method selection explicit
make sensitive boundaries stricter
make the user-facing prompts more useful
```

The goal is not to hide risk. The goal is to route the user to the best available
payment path and stop at the exact point where human authorization is required.

## Payment Channel Taxonomy

Pay-Switch should separate payment channels into three layers.

### QR wallet channels

Examples:

- Alipay QR
- WeChat Pay QR

Runtime behavior:

```text
find or prepare checkout
select wallet channel
detect QR
ask user to scan
watch result
close ledger
```

Safety profile:

- Pay-Switch never holds wallet credentials.
- The user authorizes in the wallet app.
- This is the best China-market default path.

### Hosted payment channels

Examples:

- Stripe Checkout
- merchant-hosted card checkout where Stripe/Adyen/Checkout.com owns the page

Runtime behavior:

```text
reach hosted checkout
detect provider and amount
prefer saved browser/Stripe payment method when available
stop for CVV / 3DS / OTP / final confirm
watch result
```

Safety profile:

- Prefer provider-hosted pages over raw card form automation.
- Pay-Switch may select a saved card if it is visible and already tokenized by
  the provider/browser.
- Pay-Switch must not bypass 3DS, OTP, CVV, or final confirmation.

### Raw card-form channels

Examples:

- checkout pages with `autocomplete="cc-number"`
- merchant forms asking for card number, expiry, CVV, billing name/address

Runtime behavior:

```text
detect card form
resolve allowed instrument
fill only policy-allowed non-final fields
stop for CVV / OTP / final confirm
watch result
```

Safety profile:

- This is the highest-risk channel.
- It should be behind explicit configuration.
- It should use OS keychain or token pointers, not plaintext config files.
- The MVP should fill card number only.
- Expiry, CVV, OTP, 3DS, payment password, and final confirmation stay
  human-only.

## Configuration Contract

Add a `payment` settings section instead of growing flat config indefinitely.

Proposed config shape:

```json
{
  "payment": {
    "preferred_methods": ["alipay_qr", "wechat_qr", "card_number_only", "stripe_checkout"],
    "disabled_methods": [],
    "default_method": "auto",
    "allow_card_number_only": true,
    "allow_full_card_autofill": false,
    "allow_saved_browser_cards": true,
    "require_human_for_cvv": true,
    "require_human_for_expiry": true,
    "require_human_for_otp": true,
    "require_human_for_final_confirm": true,
    "card_instruments": [
      {
        "id": "personal_visa",
        "label": "Personal Visa ending 4242",
        "storage": "keychain",
        "secret_ref": "payswitch/card/personal_visa/pan",
        "autofill_level": "number_only",
        "allowed_payees": ["openai", "anthropic"],
        "max_per_transaction": 100.0,
        "currency_allowlist": ["USD", "CNY"]
      }
    ]
  }
}
```

CLI should guide this rather than forcing users to edit JSON:

```bash
payswitch settings payment
payswitch settings payment priority
payswitch settings payment card add
payswitch settings payment card list
payswitch settings payment card remove personal_visa
```

The wizard should explain each choice in plain language:

- Alipay and WeChat are QR wallet paths.
- Stripe Checkout is a hosted provider path.
- Card number only means Pay-Switch fills only the PAN from secure local
  storage, then pauses for expiry, CVV, OTP, and final confirmation.
- Saved browser cards and hosted provider methods are preferred over raw card
  forms.
- Full card autofill is high risk and off by default.
- CVV, expiry, OTP, payment password, and final confirm stay human-gated.

## Secure Card Strategy

Do not store raw card data in `~/.payswitch/config.json`.

Gemini's review raised an important point: card numbers are still PANs. Even
without expiry or CVV, they are high-value secrets and must be treated as toxic
assets. A "local vault" that writes PANs to JSON or simple encrypted files is
not acceptable for the MVP.

Recommended MVP:

1. Store only card metadata in Pay-Switch config:
   - label
   - last4
   - brand
   - secret reference
   - policy restrictions
2. Store the PAN in OS-backed secret storage through `keyring` or a platform
   provider such as macOS Keychain or Windows DPAPI.
3. If OS-backed storage is unavailable, do not offer card-number storage by
   default.
4. Do not store expiry or CVV in the MVP.
5. Prefer saved browser payment methods and hosted Stripe/Google/Apple Pay
   surfaces when the user profile already has them.

Security boundary:

```text
Computer Use may identify and select a saved instrument.
Computer Use may fill only the card number when policy allows.
Computer Use must stop for expiry, CVV, OTP, payment password, 3DS, and final confirm.
The external Agent must never receive the card number, expiry, CVV, OTP, or payment password.
```

This keeps the system useful without pretending to solve PCI-DSS or card custody
as an early product feature.

### Card Number Only Flow

The MVP flow should be:

```text
1. User adds card through CLI.
2. Pay-Switch stores the PAN in OS keychain and stores only metadata in config.
3. Checkout detector finds a card-number field.
4. Method resolver confirms `card_number_only` is allowed for this payee,
   amount, currency, URL, and HTTPS origin.
5. Pay-Switch asks the user before filling:
   "Fill card number for Personal Visa ending 4242 on example.com for $10?"
6. If approved, Pay-Switch fills only the card number.
7. User manually fills expiry and CVV.
8. Pay-Switch watches for OTP, 3DS, final confirmation, and payment result.
```

The runtime should never produce a state where card number + expiry + CVV are
all available to the Agent or stored in Pay-Switch config.

## Runtime Routing

`PaymentMethod.auto` should become a real resolver.

Input:

```json
{
  "amount": 10,
  "currency": "CNY",
  "payee": "deepseek",
  "requested_method": "auto",
  "available_page_methods": ["alipay_qr", "wechat_qr", "card_number_only"],
  "configured_priority": ["alipay_qr", "wechat_qr", "card_number_only", "stripe_checkout"],
  "payee_policy": {
    "allowed_methods": ["alipay_qr", "wechat_qr"],
    "blocked_methods": []
  }
}
```

Output:

```json
{
  "selected_method": "alipay_qr",
  "reason": "highest configured priority available on page and allowed by payee policy",
  "fallback_methods": ["wechat_qr"],
  "human_gate_expected": "scan_qr"
}
```

Routing order:

```text
1. explicit user/caller method
2. payee policy allowlist/blocklist
3. configured user priority
4. methods detected on current checkout page
5. channel risk ranking
```

Recommended default priority for China-market use:

```text
alipay_qr -> wechat_qr -> card_number_only -> stripe_checkout
```

## Human Gate Contract

The human gate should become channel-aware.

| Gate | Applies to | Default |
|---|---|---|
| `scan_qr` | Alipay QR, WeChat QR | required |
| `card_number_fill_confirmation` | card number only | required before fill |
| `expiry_required` | card number only | required |
| `cvv_required` | card forms, saved cards | required |
| `otp_required` | SMS/email/3DS | required |
| `payment_password_required` | wallet apps or banking pages | required |
| `final_confirm_required` | final irreversible purchase button | required |
| `method_confirmation_required` | ambiguous payment method choices | required when not resolved |

The gate should return structured guidance:

```json
{
  "action_type": "cvv_required",
  "guidance": "The checkout is asking for the card security code. Please enter it in the browser. Pay-Switch will continue watching for the result.",
  "details": {
    "method": "card_form",
    "instrument_label": "Personal Visa ending 4242",
    "amount": 10,
    "currency": "USD"
  }
}
```

This follows the same communication rule learned from login, real-name
verification, and plan ambiguity: more communication is fine; vague or useless
communication is not.

## Channel Detectors

Add channel-specific detectors instead of stretching one detector to cover all
cases.

Recommended detectors:

```text
QRCodeDetector
  -> classify alipay_qr vs wechat_qr when possible

HostedCheckoutDetector
  -> stripe_checkout / paypal / other hosted provider

CardFormDetector
  -> direct cc-number / expiry / cvv / billing fields

PaymentIframeDetector
  -> Stripe / Adyen / Braintree iframe card inputs

ThreeDSDetector
  -> bank challenge / authentication frame / OTP prompt

FinalConfirmDetector
  -> irreversible "Pay", "Subscribe", "Confirm payment" state

PaymentCompletionDetector
  -> receipt / success page / transaction list / callback URL
```

Each detector should output:

```json
{
  "channel": "wechat_qr",
  "action_type": "scan_qr",
  "requires_human": true,
  "confidence": 0.91,
  "evidence": {
    "url": "...",
    "texts": ["Scan with WeChat"],
    "screenshot_path": "..."
  }
}
```

## Experience Recipe Updates

Recipes should record payment-channel observations:

```json
{
  "payment_methods": {
    "selectors": {
      "alipay_qr": ["..."],
      "wechat_qr": ["..."],
      "card_form": ["..."]
    },
    "observed_priority": ["alipay_qr", "wechat_qr"]
  },
  "human_gates": ["scan_qr"],
  "completion_signals": ["Status: Success", "Amount: ..."]
}
```

This lets an adapter learn:

- which channels a site exposes
- how to switch from Alipay to WeChat
- whether a card form appears only after selecting a tab
- whether the card number field is direct DOM or iframe-backed
- which result page means the transaction actually completed

## Phased Implementation

### Phase 1: Make method routing real

Scope:

- Add payment method enum values:
  - `wechat_qr`
  - `stripe_checkout`
  - `saved_browser_card`
  - `card_number_only`
- Add `PaymentPreferences` config model.
- Add CLI commands for method priority.
- Add a resolver that turns `auto` into a selected method plus explanation.
- Persist selected method and fallback candidates into transaction state.

Acceptance:

- `auto` can explain why it selected Alipay, WeChat, Stripe, or card.
- Unknown pages can report detected methods before choosing.
- User can configure priority without editing JSON.

### Phase 2: WeChat QR support

Scope:

- Extend QR detector to classify WeChat QR separately from Alipay QR.
- Add method-selection selectors to recipes/adapters.
- Add tests for WeChat QR detection and completion waiting.
- Add at least one real-site WeChat QR validation after Alipay remains stable.

Acceptance:

- If both Alipay and WeChat are visible, configured priority picks the right one.
- QR human gate says which wallet app to use.
- Completion watch behaves the same as Alipay.

### Phase 3: Hosted Stripe Checkout

Scope:

- Detect Stripe-hosted checkout pages.
- Prefer saved payment methods on Stripe-hosted surfaces.
- Stop at CVV, 3DS, OTP, or final confirm.
- Record provider, amount, currency, selected method, and result.

Acceptance:

- Stripe page can be recognized as `stripe_checkout`, not generic `card_form`.
- Pay-Switch can choose a visible saved method but cannot final-authorize.
- 3DS/OTP prompts become structured human gates.

### Phase 4: Card instrument configuration

Scope:

- Add card metadata model.
- Add OS keychain-backed PAN storage through `keyring` or platform-specific
  providers.
- Add CLI wizard for adding/removing card references.
- Add payee allowlists and per-card spend limits.
- Rename any broad `cc_autofill` wording to `card_number_only` for MVP clarity.
- Keep full card autofill disabled.

Acceptance:

- Config file contains metadata and secret refs only.
- No raw PAN/CVV appears in config, logs, traces, screenshots, or JSON output.
- Card use requires explicit method configuration and policy allowlist.
- Expiry and CVV are not stored.

### Phase 5: Card number only fill

Scope:

- Add `CardFormDetector`.
- Add iframe-aware detection for Stripe, Adyen, and Braintree-style embedded
  fields.
- Fill card number only when policy allows and secure secret retrieval succeeds.
- Keep expiry, CVV, OTP, 3DS, and final confirmation human-gated.
- Add redaction for screenshots and traces around card fields.

Acceptance:

- A card form can be detected and classified.
- Pay-Switch can fill only the card number after local user confirmation.
- Pay-Switch can stop with clear guidance before expiry, CVV, and final confirm.
- Sensitive values are redacted from logs and evidence.

## What Not To Build Yet

Do not build a generic universal payment solver.

The next stable product is:

```text
method routing + QR wallets + hosted checkout + strict human gates
```

Avoid these traps:

- storing plaintext card numbers in local JSON
- storing expiry or CVV in the MVP
- trying to automate OTP/SMS/email approval
- treating CVV as ordinary autofill
- calling the feature `cc_autofill` when it only fills the card number
- generating adapters automatically after one success
- making `internal` Computer Use mandatory before the external mode is stable
- building a full PCI vault before proving hosted checkout and saved-card paths

## Immediate Next Tasks

1. Add `PaymentPreferences` and expanded `PaymentMethod` values.
2. Add `PaymentMethodResolver` with tests.
3. Add CLI payment settings wizard.
4. Extend QR detection to classify Alipay vs WeChat.
5. Extend external observation payload with detected payment methods.
6. Add transaction fields for:
   - requested method
   - selected method
   - method selection reason
   - fallback methods
   - expected human gate
7. Add a first WeChat QR test page or fixture.
8. Add `card_number_only` data model and CLI design, but defer PAN storage
   implementation until resolver and QR expansion are stable.
9. Add log/evidence redaction tests for 13-19 digit PAN-like sequences before
   any real card-number storage work.

## Success Criteria

The framework is ready for real channel expansion when:

- the user can configure payment priority from CLI
- `auto` produces an auditable method decision
- QR wallet flows distinguish Alipay and WeChat
- hosted Stripe is detected separately from raw card forms
- card number is stored only through OS-backed secret storage
- expiry and CVV are not stored in the MVP
- expiry, CVV, OTP, payment password, and final confirmation always become human gates
- the ledger records both what was bought and how it was paid
