# Payswitch Checkout Intent And Plan Selection Contract

Date: 2026-05-11

## Purpose

Payswitch must not treat checkout as "find a pay button and keep going".

For consumer subscriptions, top-ups, and nonstandard web purchases, the core
job is:

```text
understand what the user wants to buy
understand which plan or amount matches that intent
ask when intent is incomplete or ambiguous
only then prepare payment
```

This document defines the control-plane contract for that behavior.

## Product Principle

Computer Use is not only for navigation.

Computer Use must help Payswitch do four things before payment:

1. verify login state
2. inspect the product and plan surface
3. extract plan and pricing choices
4. stop and ask the user when the purchase intent is still ambiguous

If Payswitch skips those steps and clicks the first visible subscribe button,
the system is not trustworthy enough for real spending.

## Required Checkout Stages

Every real checkout should follow this order:

```text
1. Guard / ledger pre-check
2. Access preflight
3. Intent resolution
4. Offer and plan discovery
5. Plan selection confirmation
6. Capability routing and checkout execution
7. Human payment authorization
8. Result detection and ledger closeout
```

## Stage Definitions

### 1. Guard / ledger pre-check

Validate budget, whitelist, idempotency, and transaction policy before any
site interaction with spending intent.

Required output:

```json
{
  "amount_limit_ok": true,
  "idempotency_ok": true,
  "payee_allowed": true
}
```

### 2. Access preflight

Before choosing plans or exploring checkout, Payswitch must determine whether
the site requires login and whether the real browser context is already logged
in.

Rules:

- If login is required and no valid session exists, stop immediately.
- Do not continue to adapter, recipe, or Computer Use plan exploration on an
  unauthenticated page.
- The output must say whether login is required, whether login is present, and
  how that conclusion was reached.

Required output:

```json
{
  "login_required": true,
  "logged_in": true,
  "evidence": [
    "user avatar visible",
    "logout or account menu visible",
    "no login prompt text detected"
  ]
}
```

### 3. Intent resolution

Payswitch must normalize what the user actually wants to buy before clicking
purchase options.

Minimum normalized fields:

```json
{
  "target_product": "Kimi Membership",
  "purchase_type": "subscription",
  "currency": "CNY",
  "user_strategy": "cheapest_upfront",
  "billing_cycle_preference": "monthly",
  "segment_preference": "consumer",
  "specific_plan_name": null,
  "max_acceptable_amount": null
}
```

Intent can come from:

- explicit user request
- structured caller-agent payload
- prior confirmed preference stored in policy or session state

Intent must not be guessed when multiple commercially meaningful choices are
still possible.

### 4. Offer and plan discovery

Once logged in and on a plan surface, Payswitch must inspect the actual offers
before choosing anything.

Computer Use or an adapter should extract:

- product or membership name
- plan names
- monthly or annual cycle controls
- consumer or business segment controls
- displayed current amount
- renewal amount if present
- auto-renew indicator
- trial or introductory discount
- plan features when they are the only way to distinguish plans
- selector or action handle for each choice

Required normalized output shape:

```json
{
  "controls": {
    "billing_cycles": ["monthly", "annually"],
    "segments": ["consumer", "business"]
  },
  "plans": [
    {
      "plan_name": "Andante",
      "segment": "consumer",
      "billing_cycle": "monthly",
      "display_amount": 39,
      "display_amount_text": "¥39 / month",
      "renewal_amount": 39,
      "renewal_interval": "month",
      "auto_renew": true,
      "action_label": "Subscribe",
      "action_selector": "..."
    }
  ]
}
```

### 5. Plan selection confirmation

After discovery, Payswitch must resolve one concrete purchase target.

Selection can be automatic only when the user's intent is complete enough.

Safe auto-selection examples:

- user said "buy the monthly cheapest personal Kimi plan"
- caller-agent payload says `billing_cycle=monthly`, `segment=consumer`,
  `strategy=cheapest_upfront`
- user previously confirmed the exact plan in the same checkout session

Mandatory clarification examples:

- both monthly and annual plans exist, but the user only said "buy Kimi"
- consumer and business segments both exist, but no segment was chosen
- multiple price tiers exist and the user did not specify cheapest, fastest,
  or a named plan
- the detected renewal amount exceeds the user's stated budget

Required clarification prompt shape:

```text
我找到了以下可选项：
1. 个人月付 Andante：¥39 / month
2. 个人年付 Andante：¥468 / year
3. Business

你要我选哪一个？
```

The framework should ask only after it has extracted the real offers, not
before.

### 6. Capability routing and checkout execution

Only after plan selection is fixed may Payswitch continue into:

```text
protocol connector
-> site adapter
-> experience recipe
-> external Computer Use
```

At this point the selected offer becomes part of transaction state and must be
revalidated before any payment handoff.

Required transaction fields:

```json
{
  "selected_plan_name": "Andante",
  "selected_segment": "consumer",
  "selected_billing_cycle": "monthly",
  "selected_amount": 39,
  "selected_amount_text": "¥39 / month"
}
```

### 7. Human payment authorization

Human gate remains mandatory for:

- QR scan
- CVV or card secret
- SMS/OTP
- payment password
- final irreversible confirm
- subscription agreement acceptance when policy requires explicit human review

### 8. Result detection and ledger closeout

Result handling should record both:

- payment status
- selected commercial outcome

This matters because "payment completed" is not enough. The ledger should also
know what the user actually bought.

Required closeout fields:

```json
{
  "status": "completed",
  "selected_plan_name": "Andante",
  "selected_billing_cycle": "monthly",
  "charged_amount": 39,
  "charged_currency": "CNY"
}
```

## Decision Policy

Payswitch should support these first-class plan selection policies:

- `specific_plan_name`
- `cheapest_upfront`
- `cheapest_recurring`
- `lowest_total_commitment`
- `consumer_only`
- `business_only`
- `monthly_only`
- `annual_only`

Recommended default when the user said "buy the cheapest" and the page offers
multiple commercial dimensions:

```text
consumer_only
monthly_only
cheapest_upfront
```

Recommended default when the user did not specify enough:

```text
do not auto-purchase
extract the offer matrix
ask for confirmation
```

## Computer Use Responsibilities

Computer Use should be responsible for:

- locating login prompts and account indicators
- opening pricing or subscription entry points
- reading visible plan controls and prices
- toggling cycle or segment controls when needed to inspect choices
- collecting screenshots and structured observations for the caller

Computer Use should not decide plan intent by itself when multiple reasonable
purchase paths remain.

That decision belongs to:

- explicit user instruction
- caller-agent intent payload
- or a confirmation loop driven by Payswitch

## Adapter Responsibilities

Adapters should gradually absorb stable plan logic for important sites.

For subscription sites like Kimi, the adapter should eventually own:

- detecting the pricing entry point
- detecting billing cycle controls
- extracting the plan matrix
- selecting the confirmed plan deterministically
- handing off only at QR or other human-gated payment steps

The fallback path should remain available when the pricing UI changes.

## Immediate Implementation Priorities

1. Add an `offer_discovery` step category between `identity` and
   `checkout_prep`.
2. Extend external observation payloads with normalized offer extraction.
3. Add a transaction-level `purchase_intent` object.
4. Add a transaction-level `selected_offer` object.
5. Add a clarification contract for ambiguous subscription or pricing pages.
6. Upgrade Kimi logic to inspect `Monthly`, `Annually`, `Business`, and plan
   cards before clicking any `Subscribe` button.

## Success Criteria

Payswitch should be considered correct only when all of these are true:

- it refuses to continue on login-required pages without a session
- it can show the real offer matrix before purchase
- it can explain which plan it is about to buy and why
- it asks the user when intent is incomplete
- it reaches payment only after plan selection is fixed
- it records what was bought, not only that payment happened
