# Payswitch Agent Checkout Control Plane Roadmap

Date: 2026-05-10

## Purpose

Payswitch should become an Agent Checkout Control Plane for real spending flows, especially China-style and nonstandard web checkout paths. It should not hold user funds, and it should not be a generic browser automation toy. Its job is to receive a spending intent from an external agent, execute the safest available checkout path, stop at human authorization points, and record enough evidence to improve future runs.

The product goal is simple:

```text
External Agent says: spend amount X on target Y
Payswitch decides the execution path
Payswitch prepares the checkout
Human confirms final payment
Payswitch records the result and improves the next run
```

## Core Positioning

Payswitch is not a wallet.

Payswitch is not the merchant of record.

Payswitch is not a service that takes custody of user money.

Payswitch is a governed checkout execution layer:

```text
Intent -> Guard -> Adapter / Recipe / Computer Use -> Human Gate -> Ledger
```

The system should make external agents capable of spending money without giving them raw control over payment credentials, passwords, CVV, OTP, payment passwords, or final authorization buttons.

## Architecture

```mermaid
flowchart TD
    A["External Agent / MCP Client"] --> B["Payswitch API / CLI / MCP Server"]
    B --> C["Intent Normalizer"]
    C --> D["Guard: limits, whitelist, idempotency"]
    D --> E{"Known Target?"}

    E -->|"Official API available"| F["Official Payment Adapter: Alipay A2A / Stripe / platform API"]
    E -->|"Site Adapter available"| G["Script Adapter"]
    E -->|"Recipe available"| H["Experience Recipe"]
    E -->|"Unknown or changed page"| I["Computer Use Explorer"]

    G --> J{"Step succeeded?"}
    J -->|"yes"| K["Detector Pipeline"]
    J -->|"step failed"| I

    H --> K
    I --> L["Semantic Trace Recorder"]
    L --> M["Experience Store"]
    M --> H

    F --> K
    K --> N{"Human Required?"}
    N -->|"QR / CVV / OTP / final authorization"| O["Human Gate"]
    N -->|"completed"| P["Ledger Completed"]
    O --> Q["Completion Detector"]
    Q --> P
    Q --> R["Timeout / Manual Review"]
```

## Execution Ladder

Payswitch should always choose the cheapest reliable path first:

1. Official payment protocol or API.
   Use this when Alipay, Stripe, the merchant, or a platform provides a supported Agent/API checkout path.

2. Site Adapter.
   Use deterministic Playwright logic for known and important sites. This is the production fast path.

3. Experience Recipe.
   Use structured traces from previous Computer Use runs. A recipe is more flexible than a hardcoded adapter but cheaper and safer than fresh model exploration.

4. Computer Use Explorer.
   Use model-backed browser exploration for unknown pages, changed layouts, and adapter failures.

5. Human Gate.
   Use human confirmation for QR scan, final payment, payment password, OTP, CVV, suspicious changes, and unexpected risk prompts.

## Adapter Failure Recovery

Adapters will fail because websites change. This is expected, not exceptional.

The correct fallback is:

```text
Adapter step fails
-> capture current page evidence
-> hand off to Computer Use with intent and last successful step
-> Computer Use revalidates amount/payee/payment method
-> Computer Use continues from the current page
-> stop at QR or human authorization
-> save a semantic trace
```

Fallback should be step-level when possible. Full-flow fallback is allowed only when the adapter cannot identify the current state.

Bad fallback:

```text
Adapter failed -> restart from homepage -> let model improvise
```

Good fallback:

```text
Step "select_alipay" failed on checkout page
-> model receives current screenshot, DOM snippet, prior successful steps, target amount, target method
-> model finds the new Alipay selector
```

## Experience And Recipe Layer

Computer Use should not only finish a task. It must produce reusable experience.

## Computer Use Driver Modes

Payswitch should support three Computer Use driver modes. This keeps the
product boundary clear: Payswitch controls checkout execution and risk gates;
the reasoning engine can be provided either by Payswitch or by the caller.

```text
computer_use_driver = external
```

External Agent driven Computer Use. This should be the default product shape
for agent-platform integrations.

In this mode, the user's own agent is the brain. Payswitch provides the browser
session, observation, guarded actions, payment detectors, human gates, ledger,
and evidence trail. The external agent receives screenshots or page summaries
and proposes the next action, but Payswitch decides whether that action is
allowed to execute.

The external agent must never receive raw payment credentials, payment
passwords, CVV, OTP, or final authorization control.

```text
External Agent -> observe page
External Agent -> propose click/fill/scroll
Payswitch Guard -> allow, block, or require human
Payswitch Browser -> execute allowed action
Payswitch Detector -> stop at QR / CVV / OTP / final payment
Payswitch Ledger -> record every state transition
```

```text
computer_use_driver = internal
```

Payswitch internal model driven Computer Use. Payswitch calls its configured
LLM backend to interpret screenshots and choose browser actions. This is useful
for local demos and fallback execution, but it requires Payswitch to manage a
model key and model-selection policy.

```text
computer_use_driver = hybrid
```

Hybrid Computer Use. A known adapter or external agent can drive the main flow,
while Payswitch internal Computer Use performs local repair when a page changes
or a selector fails. This is a useful long-term mode, but it should not blur
the safety boundary: sensitive and final authorization steps still go to the
human gate.

Recommended direction:

```text
MVP product integrations: external
Local fallback demos: internal
Production repair path: hybrid
```

The immediate implementation gap is the external-agent action loop. The current
codebase already has low-level browser observation and click primitives, but
the MCP/API session contract still needs to expose them as governed tools:

```text
checkout.start
checkout.observe
checkout.act
checkout.detect
checkout.request_human
checkout.finish
```

These tools should be session-scoped, budget-scoped, and company/user scoped.

## Browser Context Strategy

The project must not confuse a Pay-Switch managed profile with the user's real
Chrome profile.

The current implementation originally created isolated Playwright persistent
profiles under:

```text
~/.payswitch/profiles/<platform>/browser_data
```

That is useful for tests and sandboxed automation, but it is not the same as a
normal user Chrome profile. For real checkout, especially Chinese consumer
payment flows, the user's already trusted Chrome environment matters: login
state, device trust, payment risk profile, cookies, extensions, and historical
browser state can all affect success.

Payswitch should therefore support three browser context modes:

```text
payswitch_managed_profile
```

Use an isolated Pay-Switch profile. This is acceptable for deterministic tests,
CI, and low-risk demos.

```text
user_chrome_profile
```

Launch system Chrome with a user-provided `chrome_user_data_dir` and
`chrome_profile_directory`. This uses the real Chrome profile, but it cannot be
used while the same profile is already open in ordinary Chrome because Chrome
locks the User Data directory.

If `chrome_expected_profile_email` is configured, Payswitch must verify the
selected profile's `Local State` identity before opening a checkout session.
Profile identity mismatch is a hard stop.

```text
existing_chrome_cdp
```

Connect to an already running Chrome through `chrome_cdp_url`, for example
`http://127.0.0.1:9222`. This is the cleanest mode for "use my existing
profile" because Payswitch attaches to a user-approved browser instead of
creating a separate empty Chromium profile.

For local CDP endpoints, Payswitch should also best-effort map the debugging
port back to the Chrome process command line and verify `user-data-dir`,
`profile-directory`, and expected account email before taking action.

Recommended product behavior:

```text
Local tests: payswitch_managed_profile
Real user checkout: existing_chrome_cdp
Fallback when Chrome is not already open: user_chrome_profile
```

The setup flow should be browser-first:

1. Let the operator choose the browser family, such as Chrome or Chromium. Firefox
   profile discovery is a future browser-provider extension, not part of the
   current Chrome Local State implementation.
2. Read that browser's local profile registry and show the machine profile
   directory beside human identity fields such as email, display name, and GAIA
   name.
3. Bind exactly one default profile for the current implementation. A later
   milestone can allow multiple named profiles per operator or company, but the
   checkout runtime must always resolve one explicit profile before acting.
4. Treat the chosen `chrome_profile_directory` and
   `chrome_expected_profile_email` as a hard identity binding. If runtime
   discovery maps to a different profile, stop instead of silently falling back.

Payswitch must not delete Chrome singleton lock files for user Chrome profiles,
and it must not close a user's existing Chrome process when disconnecting from
CDP.

Each successful Computer Use run should save a semantic trace:

```json
{
  "site": "example-shop",
  "intent": {
    "amount": 0.9,
    "currency": "CNY",
    "method": "alipay_qr"
  },
  "steps": [
    {
      "semantic_label": "quantity_input",
      "action": "fill",
      "selector": "#orderNumber",
      "value_policy": "derived_quantity",
      "evidence": "screenshot/path.png"
    },
    {
      "semantic_label": "submit_order",
      "action": "click",
      "selector": "button:has-text('下单')"
    }
  ],
  "stop_condition": "qr_detected"
}
```

The evolution path is:

```text
First run: Computer Use explores
Second run: recipe replays
Repeated stable runs: promote recipe into adapter
Adapter breakage: step-level fallback updates recipe
```

## Safety Boundaries

Minimum hard boundaries:

1. Computer Use may navigate, inspect login state, close harmless popups, choose candidate products, fill non-sensitive fields, and reach checkout.
2. Computer Use must not enter passwords, CVV, OTP, payment passwords, bank card numbers, or government identity fields.
3. Computer Use must not approve final payment, subscriptions, auto-renewal, or changed fees.
4. Before any handoff to a payment page, Payswitch must revalidate amount, payee, payment method, and one-time vs recurring status.
5. If page content mentions risk, account verification, automatic renewal, unexpected fee, or real-name verification, Payswitch should stop and require Human Gate.

## Near-Term Roadmap

### Phase 1: Prove Real Spending With Adapters

Goal: make known targets reliably spend to QR/human confirmation.

Deliverables:

- Keep NineEmail as the first working Alipay QR adapter.
- Fix step recording so every adapter step is written to ledger, not only early steps.
- Add screenshots and URL evidence for each step.
- Add idempotency examples for external agents.
- Run at least three successful low-value payments.

Acceptance:

```text
External agent issues one spend command
Payswitch reaches Alipay QR
Human scans and confirms
Ledger marks completed
Trace contains every meaningful step
```

### Phase 2: Step-Level Adapter Fallback

Goal: adapter failures become recoverable.

Deliverables:

- Add `ScriptStepError` carrying failed step, semantic label, current URL, screenshot path, and DOM snippet.
- Modify adapters to execute and report atomic steps.
- Let orchestrator call Computer Use with handoff context.
- Keep the browser session alive during fallback.

Acceptance:

```text
Break one selector in NineEmail adapter
Payswitch catches the failed step
Computer Use continues from the current page
Payswitch reaches QR without restarting the whole flow
```

### Phase 3: Computer Use First-Run Exploration

Goal: unknown sites can be explored without custom adapter code.

Deliverables:

- Configure a working model backend for `SkyvernEngine` or replace it with a supported local Computer Use driver.
- Improve prompts with typed goals: product, quantity, amount, payment method, stop condition.
- Add hard stop at QR/final authorization.
- Save semantic traces to `experience/<site>/`.

Acceptance:

```text
No adapter exists for a site
Agent provides URL and intent
Payswitch Computer Use reaches QR or human gate
Trace is saved and can be replayed
```

### Phase 4: Recipe Replay

Goal: avoid exploring from scratch every time.

Deliverables:

- Add `ExperienceStore`.
- Add recipe selection by domain, product URL, method, and prior success score.
- Add fallback from recipe to Computer Use.
- Add promotion workflow from recipe to adapter.

Acceptance:

```text
First run uses Computer Use
Second run uses recipe without LLM
If recipe fails, Computer Use repairs it
```

### Phase 5: MCP Product Interface

Goal: make Payswitch usable by external agents without shell-only coupling.

Deliverables:

- Expose `prepare_checkout`, `confirm_handoff`, `status`, and `history`.
- Expose the external-agent Computer Use action loop:
  `checkout.start`, `checkout.observe`, `checkout.act`, `checkout.detect`,
  `checkout.request_human`, and `checkout.finish`.
- Make `computer_use_driver=external` mean the caller supplies reasoning and
  Payswitch supplies browser control, guardrails, detectors, and ledger state.
- Do not expose raw browser click APIs as an ungoverned tool.
- Return typed states: `prepared`, `human_required`, `completed`, `failed`, `needs_login`, `needs_review`.

Acceptance:

```text
External agent calls MCP prepare_checkout
Payswitch opens a governed checkout session
External agent observes and proposes actions
Payswitch blocks sensitive/final-payment actions
Payswitch returns QR/human action state
Agent never receives raw payment credentials
```

## Current Truth After 2026-05-10 Tests

Proven:

- Known-site adapter path can complete a real Alipay QR payment flow.
- NineEmail adapter reached QR, waited for human scan, detected completion, and wrote ledger status.

Not yet proven:

- Unknown-site Computer Use can independently find the checkout path.
- Adapter failure can be repaired at step level.
- Experience traces can be replayed.

Immediate next test:

```text
Treat NineEmail as an unknown site:
payee = unknown-nineemail
url = https://www.nineemail.com/buy/14
method = alipay_qr
amount = 0.9

Expected:
Payswitch should use Computer Use, not NineEmailAdapter.
It should find the order form, generate Alipay QR, and stop for human scan.
```
