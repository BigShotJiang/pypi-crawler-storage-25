# payswitch 云端 Agent 服务

AI Agent 支付编排云端服务 — A2A 协议 + MCP Tools + Docker 浏览器沙箱。

## 快速开始

```bash
# 一键启动（Redis + payswitch-server）
docker compose up -d

# 或手动启动
uv run --extra server python -m server
```

服务默认监听 `http://0.0.0.0:8000`。

## API 端点

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/health` | 健康检查 |
| POST | `/task` | 提交支付任务 |
| GET | `/task/{id}` | 查询任务状态 |
| POST | `/task/{id}/cancel` | 取消任务 |
| GET | `/task/{id}/events` | SSE 事件流 |
| GET | `/task/{id}/screenshots` | SSE 截图流 |
| GET | `/sandbox/status` | 容器池状态 |
| GET | `/.well-known/agent.json` | A2A Agent Card |
| POST | `/a2a` | A2A 任务提交 |
| POST | `/a2a/resume/{id}` | A2A HITL 恢复 |
| GET | `/a2a/status/{id}` | A2A 状态查询 |
| GET | `/a2a/stream/{id}` | A2A SSE 状态流 |
| * | `/mcp` | MCP Streamable HTTP |

## 配置（环境变量）

所有配置均可通过 `PAYSWITCH_` 前缀的环境变量覆盖：

```bash
PAYSWITCH_PORT=8000                          # 服务端口
PAYSWITCH_REDIS_URL=redis://localhost:6379   # Redis 地址
PAYSWITCH_DOCKER_IMAGE=payswitch-sandbox:latest  # 沙箱镜像名
PAYSWITCH_MAX_CONCURRENT_TASKS=3             # 最大并发容器数
PAYSWITCH_API_KEY=your-secret-key            # API Key（空则不启用认证）
PAYSWITCH_CORS_ORIGINS='["http://localhost:5173"]'  # CORS 允许源
```

## MCP 集成

### Claude Desktop / Cursor（stdio 模式）

在 MCP 配置文件中添加：

```json
{
  "mcpServers": {
    "payswitch": {
      "command": "uv",
      "args": ["run", "--extra", "server", "python", "-m", "server.mcp_stdio"],
      "cwd": "/path/to/payswitch"
    }
  }
}
```

### HTTP 模式

MCP Server 自动挂载在 `/mcp` 路径，支持 Streamable HTTP 传输。

**可用工具（9 个）**:
- `load_card` — 从 Vault 加载卡数据
- `store_card` — 存储卡数据到 Vault
- `check_spending_limit` — Guard 限额检查
- `evaluate_risk` — 风险评估
- `fill_payment_form` — 表单填写（dry_run 模式）
- `record_transaction` — 记录交易到 Ledger
- `launch_browser` — 启动浏览器沙箱
- `detect_payment_form` — 检测支付表单
- `execute_checkout` — 执行结账流程

## A2A 集成

### Agent Card

```
GET /.well-known/agent.json
```

### 提交任务

```bash
curl -X POST http://localhost:8000/a2a \
  -H "Content-Type: application/json" \
  -d '{
    "task": {
      "id": "task-001",
      "message": "支付 200 CNY 到 https://platform.deepseek.com/topup",
      "metadata": {"card_alias": "my-visa-4242", "max_amount": 200}
    }
  }'
```

### HITL 审批

当任务进入 `input-required` 状态时，发送审批：

```bash
curl -X POST http://localhost:8000/a2a/resume/task-001 \
  -H "Content-Type: application/json" \
  -d '{"action": "approve", "message": "用户已批准"}'
```

## 构建沙箱镜像

```bash
docker build -f server/Dockerfile -t payswitch-sandbox:latest .
```

## 部署

```bash
# DigitalOcean 服务器部署
bash scripts/deploy.sh

# 冒烟测试
bash scripts/smoke_test.sh
```
