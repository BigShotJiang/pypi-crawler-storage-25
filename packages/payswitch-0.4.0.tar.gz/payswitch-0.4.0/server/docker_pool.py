"""Docker 容器池管理 — 创建/监控/销毁浏览器沙箱。

每个支付任务在独立的 Docker 容器中执行。容器运行 Playwright + payswitch engine，
通过 Redis Pub/Sub 与主服务通信。任务结束后容器自动销毁。
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from server.config import ServerConfig

logger = logging.getLogger(__name__)


class PoolExhaustedError(Exception):
    """容器池已满，无法创建新沙箱。"""


@dataclass
class SandboxInfo:
    """沙箱容器信息。"""

    container_id: str
    task_id: str
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    status: str = "running"


class DockerPool:
    """Docker 容器池管理 — 创建/监控/销毁浏览器沙箱。

    使用 Docker Python SDK（同步），通过 asyncio.to_thread 包装为异步调用。
    """

    def __init__(self, config: ServerConfig) -> None:
        self._config = config
        self._client: Any = None
        self._available = False
        # 活跃沙箱: container_id → SandboxInfo
        self._sandboxes: dict[str, SandboxInfo] = {}

    @property
    def available(self) -> bool:
        """Docker daemon 是否可用。"""
        return self._available

    @property
    def active_count(self) -> int:
        """当前活跃容器数。"""
        return len(self._sandboxes)

    def initialize(self) -> None:
        """初始化 Docker client（同步调用）。"""
        try:
            import docker

            self._client = docker.from_env()
            self._client.ping()
            self._available = True
            logger.info("Docker daemon 连接成功")
        except ImportError:
            logger.warning("docker 库未安装 — Docker 功能不可用")
            self._available = False
        except Exception:
            logger.warning("Docker daemon 不可用 — 容器池功能禁用", exc_info=True)
            self._available = False

    async def async_initialize(self) -> None:
        """异步初始化 Docker client。"""
        await asyncio.to_thread(self.initialize)

    async def create_sandbox(
        self,
        task_id: str,
        environment: dict[str, str] | None = None,
        card_data_json: str | None = None,
    ) -> SandboxInfo:
        """创建隔离的浏览器沙箱容器。

        Args:
            task_id: 任务 ID
            environment: 额外环境变量
            card_data_json: 卡数据 JSON（通过 Docker Secret 注入，非环境变量）

        Returns:
            SandboxInfo 容器信息

        Raises:
            PoolExhaustedError: 容器池已满
            RuntimeError: Docker 不可用
        """
        if not self._available or not self._client:
            raise RuntimeError("Docker daemon 不可用，无法创建沙箱容器")

        if self.active_count >= self._config.max_concurrent_tasks:
            raise PoolExhaustedError(
                f"容器池已满: {self.active_count}/{self._config.max_concurrent_tasks}"
            )

        # 构建环境变量（不包含卡数据，卡数据通过 Secret 注入）
        env = {
            "TASK_ID": task_id,
            "REDIS_URL": self._config.redis_url,
            "IN_DOCKER": "True",
        }
        if environment:
            env.update(environment)

        # 创建临时 Docker Secret（如果有卡数据）
        secret_id: str | None = None
        secret_name = f"card_data_{task_id}"
        if card_data_json and self._client:
            try:
                secret = self._client.secrets.create(
                    name=secret_name,
                    data=card_data_json.encode("utf-8"),
                    labels={"managed-by": "payswitch", "task-id": task_id},
                )
                secret_id = secret.id
                logger.info("Docker Secret 创建: %s (task_id=%s)", secret_name, task_id)
            except Exception:
                logger.warning(
                    "Docker Secret 创建失败，降级为环境变量注入: task_id=%s", task_id,
                    exc_info=True,
                )
                # 降级：将卡数据放入环境变量（Swarm mode 不可用时）
                env["CARD_DATA_JSON"] = card_data_json
                secret_id = None

        def _create() -> Any:
            kwargs: dict[str, Any] = {
                "image": self._config.docker_image,
                "detach": True,
                "auto_remove": True,
                "mem_limit": "2g",
                "cpu_quota": 100000,  # 1 core
                "network_mode": "payswitch-net",
                "user": "911:911",
                "environment": env,
                "labels": {
                    "managed-by": "payswitch",
                    "task-id": task_id,
                },
            }
            # Docker Secret 需要 Swarm mode，降级时跳过
            # 注意: secrets 参数只在 Swarm service 中可用
            return self._client.containers.run(**kwargs)

        try:
            container = await asyncio.to_thread(_create)
            info = SandboxInfo(
                container_id=container.id,
                task_id=task_id,
            )
            # 记录 Secret ID 以便销毁时清理
            if secret_id:
                info.secret_id = secret_id  # type: ignore[attr-defined]
            self._sandboxes[container.id] = info
            logger.info(
                "沙箱容器创建成功: task_id=%s, container=%s",
                task_id,
                container.short_id,
            )
            return info
        except Exception as e:
            # 创建失败时清理已创建的 Secret
            if secret_id and self._client:
                try:
                    self._client.secrets.get(secret_id).remove()
                except Exception:
                    pass
            logger.error("沙箱容器创建失败: task_id=%s, error=%s", task_id, e)
            raise

    async def destroy_sandbox(self, container_id: str) -> None:
        """销毁容器和关联的 Docker Secret（正常结束或异常清理）。"""
        if not self._client:
            return

        info = self._sandboxes.pop(container_id, None)

        def _destroy() -> None:
            try:
                container = self._client.containers.get(container_id)
                container.stop(timeout=5)
            except Exception:
                pass  # auto_remove 可能已经清理

            # 清理关联的 Docker Secret
            secret_id = getattr(info, "secret_id", None) if info else None
            if secret_id:
                try:
                    self._client.secrets.get(secret_id).remove()
                    logger.info("Docker Secret 已清理: task_id=%s", info.task_id)
                except Exception:
                    pass  # Secret 可能已被删除

        await asyncio.to_thread(_destroy)
        if info:
            logger.info("沙箱容器已销毁: task_id=%s, container=%s", info.task_id, container_id[:12])

    async def list_active(self) -> list[SandboxInfo]:
        """列出当前活跃的沙箱容器。"""
        return list(self._sandboxes.values())

    async def cleanup_stale(self, max_age_seconds: int = 600) -> int:
        """清理超时未销毁的容器（看门狗）。

        Args:
            max_age_seconds: 最大存活时间（默认 10 分钟）

        Returns:
            清理的容器数量
        """
        now = datetime.now(UTC)
        stale = [
            info
            for info in self._sandboxes.values()
            if (now - info.created_at).total_seconds() > max_age_seconds
        ]

        for info in stale:
            logger.warning(
                "清理僵尸容器: task_id=%s, container=%s, age=%ds",
                info.task_id,
                info.container_id[:12],
                (now - info.created_at).total_seconds(),
            )
            await self.destroy_sandbox(info.container_id)

        return len(stale)

    def find_by_task_id(self, task_id: str) -> SandboxInfo | None:
        """根据 task_id 查找沙箱。"""
        for info in self._sandboxes.values():
            if info.task_id == task_id:
                return info
        return None
