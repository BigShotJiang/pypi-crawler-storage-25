"""Redis Pub/Sub 通信桥 — 容器 ↔ 主服务。

容器内的 payswitch engine 通过 Redis 发布状态事件，
FastAPI 主服务订阅后转发为 SSE 推送到前端。
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import AsyncGenerator
from typing import Any

logger = logging.getLogger(__name__)


class RedisBridge:
    """Redis Pub/Sub 通信桥。

    - 容器侧调用 ``publish_event()`` 发布任务状态事件
    - 主服务侧调用 ``subscribe_events()`` 订阅事件流（用于 SSE 转发）
    - Channel 命名: ``task:{task_id}:events``
    """

    def __init__(self) -> None:
        self._redis: Any = None
        self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected

    async def connect(self, redis_url: str) -> None:
        """连接 Redis。"""
        try:
            import redis.asyncio as aioredis

            self._redis = aioredis.from_url(
                redis_url,
                decode_responses=True,
                retry_on_timeout=True,
            )
            # 测试连接
            await self._redis.ping()
            self._connected = True
            logger.info("Redis 连接成功: %s", redis_url)
        except Exception:
            logger.warning("Redis 连接失败: %s — 服务将以降级模式运行", redis_url, exc_info=True)
            self._redis = None
            self._connected = False

    async def close(self) -> None:
        """关闭 Redis 连接。"""
        if self._redis:
            await self._redis.aclose()
            self._connected = False
            logger.info("Redis 连接已关闭")

    def _channel(self, task_id: str) -> str:
        """生成任务事件 channel 名称。"""
        return f"task:{task_id}:events"

    async def publish_event(self, task_id: str, event: dict) -> None:
        """发布任务状态事件（容器侧调用）。

        Args:
            task_id: 任务 ID
            event: 事件数据，包含 type/status/message 等字段
        """
        if not self._redis:
            logger.warning("Redis 未连接，事件丢弃: task_id=%s", task_id)
            return

        # 补充时间戳
        if "timestamp" not in event:
            event["timestamp"] = time.time()

        channel = self._channel(task_id)
        try:
            await self._redis.publish(channel, json.dumps(event, ensure_ascii=False))
        except Exception:
            logger.error("Redis 发布事件失败: channel=%s", channel, exc_info=True)

    async def subscribe_events(self, task_id: str) -> AsyncGenerator[dict, None]:
        """订阅任务状态事件（主服务侧调用，SSE 转发用）。

        Yields:
            每个事件 dict（type/status/message/timestamp）
        """
        if not self._redis:
            logger.warning("Redis 未连接，无法订阅事件: task_id=%s", task_id)
            return

        channel = self._channel(task_id)
        pubsub = self._redis.pubsub()

        try:
            await pubsub.subscribe(channel)
            logger.info("开始订阅事件: %s", channel)

            async for message in pubsub.listen():
                if message["type"] == "message":
                    try:
                        data = json.loads(message["data"])
                        yield data
                        # 终态事件时自动退出
                        if data.get("status") in ("completed", "failed", "canceled"):
                            break
                    except json.JSONDecodeError:
                        logger.warning("无效的事件 JSON: %s", message["data"])
        except Exception:
            logger.error("Redis 订阅异常: channel=%s", channel, exc_info=True)
        finally:
            await pubsub.unsubscribe(channel)
            await pubsub.aclose()

    # ── HITL（Human-in-the-Loop）通信 ─────────────────────────

    def _hitl_channel(self, task_id: str) -> str:
        """HITL 审批结果 channel 名称。"""
        return f"task:{task_id}:hitl"

    async def publish_hitl_response(self, task_id: str, approved: bool) -> None:
        """发布 HITL 审批结果（主服务侧调用，来自前端 HumanGateModal）。

        Args:
            task_id: 任务 ID
            approved: True=批准执行, False=拒绝
        """
        if not self._redis:
            logger.warning("Redis 未连接，HITL 响应丢弃: task_id=%s", task_id)
            return

        channel = self._hitl_channel(task_id)
        payload = json.dumps({"approved": approved, "timestamp": time.time()})
        try:
            await self._redis.publish(channel, payload)
            logger.info("已发布 HITL 响应: task_id=%s approved=%s", task_id, approved)
        except Exception:
            logger.error("Redis 发布 HITL 响应失败: channel=%s", channel, exc_info=True)

    async def wait_for_hitl_response(self, task_id: str, timeout: int = 300) -> bool:
        """等待 HITL 审批结果（容器侧调用，阻塞直到收到响应或超时）。

        Args:
            task_id: 任务 ID
            timeout: 超时秒数，默认 5 分钟

        Returns:
            True=批准, False=拒绝或超时
        """
        if not self._redis:
            logger.warning("Redis 未连接，默认拒绝 HITL: task_id=%s", task_id)
            return False

        channel = self._hitl_channel(task_id)
        pubsub = self._redis.pubsub()

        try:
            await pubsub.subscribe(channel)
            logger.info("等待 HITL 审批: task_id=%s (超时 %ds)", task_id, timeout)

            import asyncio

            deadline = time.monotonic() + timeout
            async for message in pubsub.listen():
                if time.monotonic() > deadline:
                    logger.warning("HITL 审批超时: task_id=%s", task_id)
                    return False
                if message["type"] == "message":
                    try:
                        data = json.loads(message["data"])
                        approved = data.get("approved", False)
                        logger.info("收到 HITL 审批: task_id=%s approved=%s", task_id, approved)
                        return approved
                    except json.JSONDecodeError:
                        continue

            return False
        except asyncio.CancelledError:
            return False
        except Exception:
            logger.error("HITL 等待异常: task_id=%s", task_id, exc_info=True)
            return False
        finally:
            await pubsub.unsubscribe(channel)
            await pubsub.aclose()
