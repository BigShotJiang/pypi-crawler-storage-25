"""沙箱容器入口脚本。

在 Docker 容器内运行，负责：
1. 读取任务参数（从环境变量）
2. 连接 Redis 发布状态事件（兼容前端 SessionEvent 格式）
3. 执行支付任务（真实 engine 流程 + mock 降级）
4. 定期截图发布到独立 channel
5. 完成后发布终态事件
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import sys
import time
import uuid

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("sandbox")


def _now_str() -> str:
    """当前时间字符串 HH:MM:SS（UTC）。"""
    from datetime import UTC, datetime
    return datetime.now(UTC).strftime("%H:%M:%S")


def _evt_id() -> str:
    return f"evt-{uuid.uuid4().hex[:8]}"


# ── Redis 事件发布工具 ──────────────────────────────────────

async def publish_event(redis_client, task_id: str, event: dict) -> None:  # type: ignore[no-untyped-def]
    """发布事件到 Redis channel（兼容前端 SessionEvent 格式）。"""
    if "timestamp" not in event:
        event["timestamp"] = time.time()
    channel = f"task:{task_id}:events"
    await redis_client.publish(channel, json.dumps(event, ensure_ascii=False))
    logger.info("事件发布: %s → %s", event.get("kind", event.get("status")), channel)


async def publish_session_event(
    redis_client,  # type: ignore[no-untyped-def]
    task_id: str,
    kind: str,
    title: str,
    detail: str = "",
    actor: str = "payswitch",
    path: str = "Codex / Pay-Switch",
    risk: str | None = None,
    target: str | None = None,
    # 同时发送 status 字段供 task_handler 状态流转用
    status: str | None = None,
    result: dict | None = None,
) -> None:
    """发布兼容前端 SessionEvent 格式的事件。"""
    event: dict = {
        "id": _evt_id(),
        "at": _now_str(),
        "kind": kind,
        "title": title,
        "detail": detail,
        "actor": actor,
        "path": path,
        "timestamp": time.time(),
    }
    if risk:
        event["risk"] = risk
    if target:
        event["target"] = target
    if status:
        event["status"] = status
    if result:
        event["result"] = result

    channel = f"task:{task_id}:events"
    await redis_client.publish(channel, json.dumps(event, ensure_ascii=False))
    logger.info("SessionEvent: kind=%s, title=%s", kind, title)


async def publish_screenshot(redis_client, task_id: str, data_base64: str) -> None:  # type: ignore[no-untyped-def]
    """发布截图到独立 Redis channel。"""
    channel = f"task:{task_id}:screenshots"
    payload = json.dumps({
        "type": "screenshot",
        "data": data_base64,
        "timestamp": time.time(),
    })
    await redis_client.publish(channel, payload)


# ── 真实截图流 ─────────────────────────────────────────────

async def real_screenshot_loop(
    redis_client, task_id: str, page, stop_event: asyncio.Event,  # type: ignore[no-untyped-def]
) -> None:
    """真实截图流 — 从 Playwright page 截图并发布到 Redis。

    每 500ms 截一帧 JPEG（quality=50），去重后发布。
    """
    last_hash = ""
    while not stop_event.is_set():
        try:
            frame_bytes = await page.screenshot(type="jpeg", quality=50)
            frame_b64 = base64.b64encode(frame_bytes).decode()
            frame_hash = hashlib.md5(frame_bytes).hexdigest()
            if frame_hash != last_hash:
                await publish_screenshot(redis_client, task_id, frame_b64)
                last_hash = frame_hash
        except Exception:
            pass  # 页面可能已关闭，静默跳过
        await asyncio.sleep(0.5)


# ── 真实支付流程 ───────────────────────────────────────────

async def real_payment_flow(redis_client, task_id: str) -> None:  # type: ignore[no-untyped-def]
    """真实支付流程 — 使用 payswitch engine 执行完整的支付操作。

    流程: Guard → 浏览器启动 → 导航 → 检测 → 填写 → HITL → 完成
    """
    # 读取任务参数
    target_url = os.environ.get("TARGET_URL", "")
    card_alias = os.environ.get("CARD_ALIAS", "")
    max_amount = float(os.environ.get("MAX_AMOUNT", "0"))
    currency = os.environ.get("CURRENCY", "USD")
    redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")

    if not target_url:
        raise ValueError("TARGET_URL 环境变量未设置")
    if not card_alias:
        raise ValueError("CARD_ALIAS 环境变量未设置")

    # 1. 意图接收
    await publish_session_event(redis_client, task_id,
        kind="intent_received",
        title="沙箱收到支付任务",
        detail=f"目标: {target_url}, 金额上限: {max_amount} {currency}",
        actor="codex",
        path="Codex",
        status="working",
    )

    # 2. Guard 检查
    from payswitch.engine.guard import SpendingGuard
    from payswitch.engine.ledger import Ledger
    from payswitch.models.config import PaySwitchConfig

    try:
        config = PaySwitchConfig.load()
    except Exception:
        # 容器内可能没有完整 config，创建一个最小化实例
        config = PaySwitchConfig()

    ledger = Ledger()
    guard = SpendingGuard(config, ledger)
    guard_result = guard.check(amount=max_amount, payee=target_url)

    if not guard_result.allowed:
        await publish_session_event(redis_client, task_id,
            kind="action_blocked",
            title=f"Guard 拒绝: {guard_result.reason}",
            detail=guard_result.reason or "",
            risk="high",
            path="Codex / Pay-Switch / Guard",
            status="failed",
        )
        return

    # 幂等命中 — 直接返回已有结果
    if guard_result.existing_tx:
        await publish_session_event(redis_client, task_id,
            kind="completed",
            title="幂等命中，返回已有交易",
            detail=f"交易 {guard_result.existing_tx.id}",
            actor="ledger",
            path="Codex / Pay-Switch / Guard / Ledger",
            status="completed",
        )
        return

    await publish_session_event(redis_client, task_id,
        kind="guard_passed",
        title="Guard 检查通过",
        detail=f"金额 {max_amount} {currency} 通过限额检查",
        path="Codex / Pay-Switch / Guard",
        risk="low",
        status="working",
    )
    await asyncio.sleep(0.3)

    # 3. 路由选择
    await publish_session_event(redis_client, task_id,
        kind="route_selected",
        title="选择通道: browser",
        detail=f"目标 {target_url} 需要浏览器自动化",
        path="Codex / Pay-Switch / Guard",
        status="working",
    )

    # 4. 启动浏览器
    from payswitch.browser.controller import BrowserController

    browser = BrowserController()
    stop_screenshots = asyncio.Event()
    screenshot_task = None

    try:
        await browser.launch(headless=True)
        logger.info("Playwright 浏览器已启动")

        # 启动真实截图流
        screenshot_task = asyncio.create_task(
            real_screenshot_loop(redis_client, task_id, browser.page, stop_screenshots)
        )

        # 5. 导航到目标
        await browser.navigate(target_url)
        current_url = await browser.get_current_url()
        await publish_session_event(redis_client, task_id,
            kind="observe",
            title="已导航到目标页面",
            detail=f"当前 URL: {current_url}",
            actor="browser",
            path="Codex / Pay-Switch / Guard / Browser",
            status="working",
            target=current_url,
        )
        await asyncio.sleep(1.0)

        # 6. 检测并填写支付表单
        await publish_session_event(redis_client, task_id,
            kind="tool_call_start",
            title="调用工具: fill_payment_form",
            detail=json.dumps({"url": target_url, "card_alias": card_alias}),
            target="fill_payment_form",
            path="Codex / Pay-Switch",
            status="working",
        )

        from payswitch.engine.card_filler import CardFormFiller, CardFormNotFoundError

        filler = CardFormFiller()
        try:
            fill_result = await filler.detect_and_fill(
                browser.page, card_alias, dry_run=False
            )

            # 填写成功
            await publish_session_event(redis_client, task_id,
                kind="action_allowed",
                title=f"已填写 {len(fill_result.filled_fields)} 个字段",
                detail=f"字段: {', '.join(fill_result.filled_fields)}",
                actor="browser",
                path="Codex / Pay-Switch / Guard / Browser",
                risk="low",
                status="working",
            )

            await publish_session_event(redis_client, task_id,
                kind="tool_call_end",
                title="工具返回: fill_payment_form",
                detail=json.dumps({
                    "status": "ok",
                    "fields_filled": len(fill_result.filled_fields),
                    "processor": fill_result.processor,
                    "needs_human_gate": fill_result.needs_human_gate,
                }),
                target="fill_payment_form",
                path="Codex / Pay-Switch",
                status="working",
            )

            # 7. 检测到动态挑战（OTP/3DS/CAPTCHA）→ 触发 Human Gate
            if fill_result.needs_human_gate or fill_result.human_fields:
                challenge_type = ", ".join(fill_result.human_fields) or "未知挑战"
                await publish_session_event(redis_client, task_id,
                    kind="human_gate",
                    title=f"需要人工处理: {challenge_type}",
                    detail="Pay-Switch 暂停自动化，等待用户操作。",
                    actor="human",
                    path="Codex / Pay-Switch / Human Gate",
                    risk="high",
                    status="input-required",
                )

                # 等待 HITL 审批
                from server.redis_bridge import RedisBridge
                hitl_bridge = RedisBridge()
                await hitl_bridge.connect(redis_url)
                try:
                    approved = await hitl_bridge.wait_for_hitl_response(task_id, timeout=300)
                    if not approved:
                        await publish_session_event(redis_client, task_id,
                            kind="canceled",
                            title="用户拒绝或审批超时",
                            actor="human",
                            path="Codex / Pay-Switch / Human Gate",
                            status="canceled",
                        )
                        return
                    logger.info("HITL 审批通过，继续执行")
                finally:
                    await hitl_bridge.close()

        except CardFormNotFoundError:
            await publish_session_event(redis_client, task_id,
                kind="tool_call_end",
                title="工具返回: fill_payment_form — 未检测到表单",
                detail='{"status": "not_found"}',
                target="fill_payment_form",
                path="Codex / Pay-Switch",
                status="working",
            )
            await publish_session_event(redis_client, task_id,
                kind="detection",
                title="未检测到支付表单",
                detail="页面无卡号输入框，可能需要用户手动操作",
                actor="browser",
                path="Codex / Pay-Switch / Guard / Browser",
                risk="medium",
                status="working",
            )

        # 8. 完成
        await publish_session_event(redis_client, task_id,
            kind="completed",
            title="支付流程完成",
            detail=f"目标: {target_url}, 金额上限: {max_amount} {currency}",
            actor="ledger",
            path="Codex / Pay-Switch / Guard / Browser / Human Gate / Ledger",
            risk="low",
            status="completed",
            result={
                "transaction_id": f"txn_{task_id}",
                "amount": max_amount,
                "currency": currency,
                "merchant": target_url,
            },
        )

    finally:
        stop_screenshots.set()
        if screenshot_task:
            await screenshot_task
        await browser.close()
        ledger.close()
        logger.info("浏览器和资源已释放")


# ── Mock 支付流程（降级用）─────────────────────────────────

async def mock_payment_flow(redis_client, task_id: str) -> None:  # type: ignore[no-untyped-def]
    """模拟支付流程（无 Playwright/engine 依赖时使用的降级模式）。"""

    # 1. 意图接收
    await publish_session_event(redis_client, task_id,
        kind="intent_received",
        title="Codex 发起支付请求",
        detail="目标: https://example.com/checkout, 金额: 49.99 USD",
        actor="codex",
        path="Codex",
        status="working",
    )
    await asyncio.sleep(0.8)

    # 2. Guard 检查通过
    await publish_session_event(redis_client, task_id,
        kind="guard_passed",
        title="Guard 检查通过",
        detail="金额 49.99 通过限额检查",
        actor="payswitch",
        path="Codex / Pay-Switch / Guard",
        risk="low",
        status="working",
    )
    await asyncio.sleep(0.5)

    # 3. 路由选择
    await publish_session_event(redis_client, task_id,
        kind="route_selected",
        title="选择通道: browser",
        detail="目标页面需要浏览器自动化",
        actor="payswitch",
        path="Codex / Pay-Switch / Guard",
        status="working",
    )
    await asyncio.sleep(0.5)

    # 4. 检测支付表单
    await publish_session_event(redis_client, task_id,
        kind="detection",
        title="检测到 Stripe 支付表单",
        detail="Stripe Payment Element (Custom Elements 集成模式)",
        actor="browser",
        path="Codex / Pay-Switch / Guard / Browser",
        status="working",
    )
    await asyncio.sleep(0.8)

    # 5. 工具调用：填写卡号
    await publish_session_event(redis_client, task_id,
        kind="tool_call_start",
        title="调用工具: fill_payment_form",
        detail='{"url": "https://example.com/checkout", "card_alias": "my-visa-4242"}',
        actor="payswitch",
        path="Codex / Pay-Switch",
        target="fill_payment_form",
        status="working",
    )
    await asyncio.sleep(1.0)

    # 6. 填写动作
    await publish_session_event(redis_client, task_id,
        kind="action_allowed",
        title="填写卡号 **** 4242",
        actor="browser",
        path="Codex / Pay-Switch / Guard / Browser",
        risk="low",
        status="working",
    )
    await asyncio.sleep(0.5)

    await publish_session_event(redis_client, task_id,
        kind="action_allowed",
        title="填写有效期和安全码",
        actor="browser",
        path="Codex / Pay-Switch / Guard / Browser",
        risk="low",
        status="working",
    )
    await asyncio.sleep(0.5)

    # 7. 工具调用结束
    await publish_session_event(redis_client, task_id,
        kind="tool_call_end",
        title="工具返回: fill_payment_form",
        detail='{"status": "ok", "fields_filled": 4}',
        actor="payswitch",
        path="Codex / Pay-Switch",
        target="fill_payment_form",
        status="working",
    )
    await asyncio.sleep(0.5)

    # 8. 提交支付动作
    await publish_session_event(redis_client, task_id,
        kind="action_proposed",
        title="提议: 点击支付按钮",
        actor="browser",
        path="Codex / Pay-Switch / Guard / Browser",
        risk="medium",
        target="button.pay-submit",
        status="working",
    )
    await asyncio.sleep(0.3)

    await publish_session_event(redis_client, task_id,
        kind="action_allowed",
        title="执行: 点击支付按钮",
        actor="browser",
        path="Codex / Pay-Switch / Guard / Browser",
        risk="low",
        status="working",
    )
    await asyncio.sleep(1.0)

    # 9. 完成
    await publish_session_event(redis_client, task_id,
        kind="completed",
        title="支付完成",
        detail="交易 txn_mock_001, 金额 49.99 USD",
        actor="ledger",
        path="Codex / Pay-Switch / Guard / Browser / Human Gate / Ledger",
        risk="low",
        status="completed",
        result={
            "transaction_id": f"txn_{task_id}",
            "amount": 49.99,
            "currency": "USD",
            "merchant": "example.com",
            "card_last4": "4242",
        },
    )


async def mock_screenshot_loop(redis_client, task_id: str, stop_event: asyncio.Event) -> None:  # type: ignore[no-untyped-def]
    """模拟截图流（mock 降级模式）。"""
    # 1x1 白色 JPEG（最小合法 JPEG）
    placeholder = base64.b64encode(bytes([
        0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
        0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43,
        0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08, 0x07, 0x07, 0x07, 0x09,
        0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
        0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20,
        0x24, 0x2E, 0x27, 0x20, 0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29,
        0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27, 0x39, 0x3D, 0x38, 0x32,
        0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
        0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00,
        0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
        0x09, 0x0A, 0x0B, 0xFF, 0xC4, 0x00, 0xB5, 0x10, 0x00, 0x02, 0x01, 0x03,
        0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04, 0x00, 0x00, 0x01, 0x7D,
        0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06,
        0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xA1, 0x08,
        0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7B, 0x94,
        0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xD9,
    ])).decode()

    last_hash = ""
    while not stop_event.is_set():
        frame_hash = hashlib.md5(placeholder.encode()).hexdigest()
        if frame_hash != last_hash:
            await publish_screenshot(redis_client, task_id, placeholder)
            last_hash = frame_hash
        await asyncio.sleep(0.5)


# ── 主入口 ─────────────────────────────────────────────────

async def main() -> None:
    """沙箱容器主入口。

    模式选择：
    - 设置 TARGET_URL + CARD_ALIAS 环境变量 → 真实 engine 流程
    - 未设置 → mock 降级模式
    """
    task_id = os.environ.get("TASK_ID")
    redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")

    if not task_id:
        logger.error("TASK_ID 环境变量未设置")
        sys.exit(1)

    logger.info("沙箱启动: task_id=%s, redis_url=%s", task_id, redis_url)

    # 连接 Redis
    try:
        import redis.asyncio as aioredis

        redis_client = aioredis.from_url(redis_url, decode_responses=True)
        await redis_client.ping()
        logger.info("Redis 连接成功")
    except Exception as e:
        logger.error("Redis 连接失败: %s", e)
        sys.exit(1)

    # 判断执行模式：有 TARGET_URL 和 CARD_ALIAS → 真实模式
    use_real_engine = bool(os.environ.get("TARGET_URL") and os.environ.get("CARD_ALIAS"))

    if use_real_engine:
        logger.info("使用真实 engine 模式")
        try:
            await real_payment_flow(redis_client, task_id)
        except Exception as e:
            logger.error("真实支付流程异常: %s", e, exc_info=True)
            await publish_session_event(redis_client, task_id,
                kind="failed",
                title=f"支付流程异常: {type(e).__name__}",
                detail=str(e),
                actor="payswitch",
                path="Codex / Pay-Switch",
                risk="high",
                status="failed",
            )
    else:
        logger.info("使用 mock 降级模式（未设置 TARGET_URL/CARD_ALIAS）")
        # Mock 模式：启动 mock 截图流
        stop_screenshots = asyncio.Event()
        screenshot_task = asyncio.create_task(
            mock_screenshot_loop(redis_client, task_id, stop_screenshots)
        )
        try:
            await mock_payment_flow(redis_client, task_id)
        except Exception as e:
            logger.error("Mock 流程异常: %s", e)
            await publish_session_event(redis_client, task_id,
                kind="failed",
                title=f"支付流程异常: {e}",
                actor="payswitch",
                path="Codex / Pay-Switch",
                risk="high",
                status="failed",
            )
        finally:
            stop_screenshots.set()
            await screenshot_task

    await redis_client.aclose()
    logger.info("沙箱退出: task_id=%s", task_id)


if __name__ == "__main__":
    asyncio.run(main())
