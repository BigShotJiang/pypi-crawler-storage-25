"""幂等性管理 — 防重复扣款。

使用 Redis 实现：
- 终态缓存: ``task:{task_id}`` → JSON（completed/failed/canceled 结果）
- 分布式锁: ``task_lock:{task_id}`` → SET NX EX（防止并发执行）
"""

from __future__ import annotations

import json
import logging
from enum import StrEnum
from typing import Any

from pydantic import BaseModel

logger = logging.getLogger(__name__)

# 幂等缓存 TTL（24 小时）
RESULT_TTL = 86400
# 分布式锁超时（10 分钟）
LOCK_TTL = 600


class IdempotencyStatus(StrEnum):
    """幂等检查结果。"""

    CACHED = "cached"      # 已有终态结果
    LOCKED = "locked"      # 成功加锁，可以执行
    CONFLICT = "conflict"  # 另一进程正在执行


class IdempotencyResult(BaseModel):
    """幂等检查返回值。"""

    status: IdempotencyStatus
    cached_result: dict | None = None


class IdempotencyManager:
    """任务幂等性管理 — 防重复扣款。

    流程::

        check_and_lock(task_id)
        ├── 有缓存 → CACHED（直接返回缓存结果）
        ├── 加锁成功 → LOCKED（可以执行）
        └── 加锁失败 → CONFLICT（另一进程在执行）

        执行完成 → store_result(task_id, status, result)
        异常退出 → release_lock(task_id)
    """

    def __init__(self) -> None:
        self._redis: Any = None
        self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected

    async def connect(self, redis_url: str) -> None:
        """连接 Redis。"""
        try:
            import redis.asyncio as aioredis

            self._redis = aioredis.from_url(
                redis_url,
                decode_responses=True,
                retry_on_timeout=True,
            )
            await self._redis.ping()
            self._connected = True
            logger.info("IdempotencyManager Redis 连接成功")
        except Exception:
            logger.warning("IdempotencyManager Redis 连接失败 — 幂等性检查将被跳过", exc_info=True)
            self._redis = None
            self._connected = False

    async def close(self) -> None:
        """关闭连接。"""
        if self._redis:
            await self._redis.aclose()
            self._connected = False

    def _result_key(self, task_id: str) -> str:
        return f"task:{task_id}"

    def _lock_key(self, task_id: str) -> str:
        return f"task_lock:{task_id}"

    async def check_and_lock(self, task_id: str) -> IdempotencyResult:
        """检查 task_id 是否已有结果，若无则尝试加锁。

        Returns:
            - CACHED: 已有终态结果（附带 cached_result）
            - LOCKED: 成功加锁，可以执行
            - CONFLICT: 另一进程正在执行此 task_id
        """
        if not self._redis:
            # Redis 不可用时默认放行（降级模式）
            logger.warning("Redis 不可用，跳过幂等检查: task_id=%s", task_id)
            return IdempotencyResult(status=IdempotencyStatus.LOCKED)

        # 1. 检查是否有缓存结果
        cached = await self._redis.get(self._result_key(task_id))
        if cached:
            try:
                result = json.loads(cached)
                logger.info("幂等命中: task_id=%s, status=%s", task_id, result.get("status"))
                return IdempotencyResult(
                    status=IdempotencyStatus.CACHED,
                    cached_result=result,
                )
            except json.JSONDecodeError:
                logger.warning("幂等缓存 JSON 解析失败: task_id=%s", task_id)

        # 2. 尝试加锁（SET NX EX）
        locked = await self._redis.set(
            self._lock_key(task_id),
            "1",
            nx=True,
            ex=LOCK_TTL,
        )

        if locked:
            logger.info("加锁成功: task_id=%s", task_id)
            return IdempotencyResult(status=IdempotencyStatus.LOCKED)

        logger.info("加锁冲突: task_id=%s（另一进程正在执行）", task_id)
        return IdempotencyResult(status=IdempotencyStatus.CONFLICT)

    async def store_result(self, task_id: str, status: str, result: dict) -> None:
        """任务完成后写入缓存（仅终态）。

        Args:
            task_id: 任务 ID
            status: 终态（completed/failed/canceled）
            result: 任务结果
        """
        if not self._redis:
            return

        data = {"status": status, "result": result}
        try:
            await self._redis.set(
                self._result_key(task_id),
                json.dumps(data, ensure_ascii=False),
                ex=RESULT_TTL,
            )
            # 释放锁
            await self._redis.delete(self._lock_key(task_id))
            logger.info("幂等缓存写入: task_id=%s, status=%s, TTL=%ds", task_id, status, RESULT_TTL)
        except Exception:
            logger.error("幂等缓存写入失败: task_id=%s", task_id, exc_info=True)

    async def release_lock(self, task_id: str) -> None:
        """释放分布式锁（异常退出时调用）。"""
        if not self._redis:
            return
        try:
            await self._redis.delete(self._lock_key(task_id))
            logger.info("锁已释放: task_id=%s", task_id)
        except Exception:
            logger.error("释放锁失败: task_id=%s", task_id, exc_info=True)
