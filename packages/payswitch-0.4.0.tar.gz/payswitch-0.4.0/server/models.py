"""API 请求/响应模型。"""

from __future__ import annotations

import uuid
from enum import StrEnum

from pydantic import BaseModel, Field


class TaskStatus(StrEnum):
    """任务状态枚举 — 与 A2A 协议状态对齐。"""

    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input_required"
    AUTH_REQUIRED = "auth_required"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


class TaskRequest(BaseModel):
    """POST /task 请求体。"""

    task_id: str | None = Field(
        default=None,
        description="任务 ID（可选，不提供则自动生成；重试时复用同一 ID 实现幂等）",
    )
    card_alias: str = Field(description="虚拟卡别名（如 my-visa-4242）")
    url: str = Field(description="目标支付页面 URL")
    max_amount: float = Field(description="最大允许金额")
    currency: str = Field(default="USD", description="货币代码")
    require_human_confirmation: bool = Field(
        default=True,
        description="是否需要人类确认（Human Gate）",
    )


class TaskResponse(BaseModel):
    """统一的任务响应格式。"""

    task_id: str = Field(description="任务 ID")
    status: TaskStatus = Field(description="当前状态")
    message: str = Field(default="", description="状态说明")
    result: dict | None = Field(default=None, description="任务结果（仅终态时有值）")


def generate_task_id() -> str:
    """生成唯一任务 ID。"""
    return f"task-{uuid.uuid4().hex[:12]}"
