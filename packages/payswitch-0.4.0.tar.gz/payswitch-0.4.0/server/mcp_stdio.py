"""MCP stdio 模式入口 — 本地 IDE 集成（Claude Desktop / Cursor / VS Code）。

用法::

    python -m server.mcp_stdio

配置示例（Claude Desktop mcp-config.json）::

    {
      "mcpServers": {
        "payswitch": {
          "command": "uv",
          "args": ["run", "python", "-m", "server.mcp_stdio"],
          "cwd": "/path/to/payswitch"
        }
      }
    }

注意: stdout 专属 JSON-RPC 2.0 协议通信，所有日志必须输出到 stderr。
"""

from __future__ import annotations

import logging
import sys


def main() -> None:
    """启动 MCP stdio 模式。"""
    # 日志必须输出到 stderr（stdout 留给 JSON-RPC 协议）
    logging.basicConfig(
        stream=sys.stderr,
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )
    logger = logging.getLogger("mcp-stdio")
    logger.info("payswitch MCP Server (stdio 模式) 启动中...")

    from server.mcp_server import mcp

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
