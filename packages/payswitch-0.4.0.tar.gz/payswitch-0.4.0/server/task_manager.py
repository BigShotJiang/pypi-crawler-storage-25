"""任务管理器 — 编排 POST /task 的完整流程。

流程: 接收请求 → 幂等检查 → 创建 Docker 沙箱 → 后台监听完成 → 缓存结果
"""

from __future__ import annotations

import asyncio
import logging

from server.docker_pool import DockerPool, PoolExhaustedError
from server.idempotency import IdempotencyManager, IdempotencyStatus
from server.models import TaskRequest, TaskResponse, TaskStatus, generate_task_id
from server.redis_bridge import RedisBridge

logger = logging.getLogger(__name__)


class TaskManager:
    """任务管理器 — 编排完整的支付任务流程。"""

    def __init__(
        self,
        redis_bridge: RedisBridge,
        idempotency: IdempotencyManager,
        docker_pool: DockerPool,
    ) -> None:
        self._redis = redis_bridge
        self._idempotency = idempotency
        self._docker = docker_pool
        # 活跃任务: task_id → asyncio.Task
        self._background_tasks: dict[str, asyncio.Task[None]] = {}

    async def submit_task(self, request: TaskRequest) -> TaskResponse:
        """提交支付任务。

        流程:
        1. 生成/复用 task_id
        2. 幂等检查（CACHED → 直接返回 / CONFLICT → 409 / LOCKED → 继续）
        3. 创建 Docker 沙箱
        4. 后台任务监听容器完成
        5. 返回 submitted 状态
        """
        # 1. task_id
        task_id = request.task_id or generate_task_id()

        # 2. 幂等检查
        idem_result = await self._idempotency.check_and_lock(task_id)

        if idem_result.status == IdempotencyStatus.CACHED:
            cached = idem_result.cached_result or {}
            return TaskResponse(
                task_id=task_id,
                status=TaskStatus(cached.get("status", "completed")),
                message="幂等命中: 返回缓存结果",
                result=cached.get("result"),
            )

        if idem_result.status == IdempotencyStatus.CONFLICT:
            return TaskResponse(
                task_id=task_id,
                status=TaskStatus.WORKING,
                message="任务正在执行中（另一进程处理）",
            )

        # 3. 创建 Docker 沙箱
        try:
            env = {
                "TARGET_URL": request.url,
                "CARD_ALIAS": request.card_alias,
                "MAX_AMOUNT": str(request.max_amount),
                "CURRENCY": request.currency,
                "REQUIRE_HUMAN": str(request.require_human_confirmation),
            }
            sandbox = await self._docker.create_sandbox(task_id, environment=env)
        except PoolExhaustedError as e:
            await self._idempotency.release_lock(task_id)
            return TaskResponse(
                task_id=task_id,
                status=TaskStatus.FAILED,
                message=str(e),
            )
        except Exception as e:
            await self._idempotency.release_lock(task_id)
            logger.error("创建沙箱失败: task_id=%s, error=%s", task_id, e)
            return TaskResponse(
                task_id=task_id,
                status=TaskStatus.FAILED,
                message=f"沙箱创建失败: {e}",
            )

        # 4. 后台任务：监听容器完成事件
        bg_task = asyncio.create_task(
            self._monitor_task(task_id, sandbox.container_id)
        )
        self._background_tasks[task_id] = bg_task

        # 5. 返回 submitted
        return TaskResponse(
            task_id=task_id,
            status=TaskStatus.SUBMITTED,
            message="任务已提交，沙箱容器已启动",
        )

    async def get_task_status(self, task_id: str) -> TaskResponse:
        """查询任务状态。"""
        # 先检查幂等缓存（终态）
        if self._idempotency.connected:
            import json


            cached = await self._idempotency._redis.get(f"task:{task_id}")  # type: ignore[union-attr]
            if cached:
                data = json.loads(cached)
                return TaskResponse(
                    task_id=task_id,
                    status=TaskStatus(data.get("status", "completed")),
                    message="从缓存获取",
                    result=data.get("result"),
                )

        # 检查是否有活跃沙箱
        sandbox = self._docker.find_by_task_id(task_id)
        if sandbox:
            return TaskResponse(
                task_id=task_id,
                status=TaskStatus.WORKING,
                message=f"容器运行中: {sandbox.container_id[:12]}",
            )

        return TaskResponse(
            task_id=task_id,
            status=TaskStatus.FAILED,
            message="任务未找到",
        )

    async def cancel_task(self, task_id: str) -> TaskResponse:
        """取消任务（销毁容器 + 释放锁）。"""
        # 取消后台监听
        bg_task = self._background_tasks.pop(task_id, None)
        if bg_task:
            bg_task.cancel()

        # 销毁容器
        sandbox = self._docker.find_by_task_id(task_id)
        if sandbox:
            await self._docker.destroy_sandbox(sandbox.container_id)

        # 写入取消状态
        await self._idempotency.store_result(task_id, "canceled", {"reason": "用户取消"})

        return TaskResponse(
            task_id=task_id,
            status=TaskStatus.CANCELED,
            message="任务已取消",
        )

    async def _monitor_task(self, task_id: str, container_id: str) -> None:
        """后台监听任务完成事件，写入幂等缓存。"""
        try:
            async for event in self._redis.subscribe_events(task_id):
                status = event.get("status")
                if status in ("completed", "failed", "canceled"):
                    # 写入幂等缓存
                    await self._idempotency.store_result(
                        task_id,
                        status,
                        event.get("result", {}),
                    )
                    logger.info("任务终态: task_id=%s, status=%s", task_id, status)
                    break
        except asyncio.CancelledError:
            logger.info("任务监听已取消: task_id=%s", task_id)
        except Exception:
            logger.error("任务监听异常: task_id=%s", task_id, exc_info=True)
            await self._idempotency.release_lock(task_id)
        finally:
            # 清理容器（如果 auto_remove 没生效）
            await self._docker.destroy_sandbox(container_id)
            self._background_tasks.pop(task_id, None)
