"""A2A 协议集成 — Agent Card、任务处理器、状态流转。"""
