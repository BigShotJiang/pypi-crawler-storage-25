"""A2A Agent Card 生成 — ``/.well-known/agent.json`` 端点。

按 Google A2A 协议规范发布 Agent Card，描述 payswitch 的能力和技能，
让其他 Agent 发现并调用 payswitch 的支付服务。
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from server.config import ServerConfig


class AgentSkill(BaseModel):
    """A2A Agent Card 中的技能定义。"""

    id: str
    name: str
    description: str
    inputModes: list[str] = Field(default_factory=lambda: ["application/json"])
    outputModes: list[str] = Field(default_factory=lambda: ["application/json"])


class AgentCapabilities(BaseModel):
    """A2A Agent 能力声明。"""

    streaming: bool = True
    pushNotifications: bool = True
    stateTransitionHistory: bool = True


class AgentAuthentication(BaseModel):
    """A2A Agent 认证方式。"""

    schemes: list[str] = Field(default_factory=lambda: ["apiKey"])


class AgentCard(BaseModel):
    """A2A Agent Card — 完整的 Agent 自描述信息。

    参考: PRDv3 §4.1, Google A2A 规范
    """

    name: str = "payswitch-payment-agent"
    description: str = "AI Agent 支付编排服务 — 自动完成网站支付流程"
    url: str = ""
    version: str = "0.3.0"
    capabilities: AgentCapabilities = Field(default_factory=AgentCapabilities)
    skills: list[AgentSkill] = Field(default_factory=list)
    authentication: AgentAuthentication = Field(default_factory=AgentAuthentication)


# 预定义的技能列表
_DEFAULT_SKILLS: list[AgentSkill] = [
    AgentSkill(
        id="web-checkout",
        name="网站支付",
        description="在指定网站完成支付流程（浏览器自动化 + 卡信息填写 + 风控守卫）",
        inputModes=["text/plain", "application/json"],
        outputModes=["application/json"],
    ),
    AgentSkill(
        id="stripe-payment",
        name="Stripe API 支付",
        description="通过 Stripe API 直接完成支付（不走浏览器）",
        inputModes=["application/json"],
        outputModes=["application/json"],
    ),
]


def build_agent_card(config: ServerConfig) -> AgentCard:
    """根据服务配置动态生成 Agent Card。

    Args:
        config: 服务配置（用于确定 URL 等动态字段）

    Returns:
        完整的 AgentCard 实例
    """
    # 动态确定 Agent 服务 URL
    host = config.host if config.host != "0.0.0.0" else "localhost"
    base_url = f"http://{host}:{config.port}"

    return AgentCard(
        url=f"{base_url}/a2a",
        version=config.version,
        skills=_DEFAULT_SKILLS,
    )
