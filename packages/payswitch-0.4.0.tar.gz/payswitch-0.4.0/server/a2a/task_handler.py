"""A2A 任务生命周期处理器。

接收 A2A 格式任务 → 解析 → 内部 TaskManager → 状态映射 → A2A 响应。
复用已有 TaskManager，不重复实现业务逻辑。
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import AsyncGenerator

from server.a2a.models import (
    A2ATaskInput,
    A2ATaskResponse,
    A2ATaskStatus,
    Artifact,
    Message,
    MessagePart,
    ResumeRequest,
    StatusUpdate,
)
from server.models import TaskRequest, TaskResponse, TaskStatus
from server.redis_bridge import RedisBridge
from server.task_manager import TaskManager

logger = logging.getLogger(__name__)

# 内部状态 → A2A 状态映射
_STATUS_MAP: dict[TaskStatus, A2ATaskStatus] = {
    TaskStatus.SUBMITTED: A2ATaskStatus.SUBMITTED,
    TaskStatus.WORKING: A2ATaskStatus.WORKING,
    TaskStatus.INPUT_REQUIRED: A2ATaskStatus.INPUT_REQUIRED,
    TaskStatus.AUTH_REQUIRED: A2ATaskStatus.AUTH_REQUIRED,
    TaskStatus.COMPLETED: A2ATaskStatus.COMPLETED,
    TaskStatus.FAILED: A2ATaskStatus.FAILED,
    TaskStatus.CANCELED: A2ATaskStatus.CANCELED,
}


def _map_status(internal: TaskStatus) -> A2ATaskStatus:
    """内部状态 → A2A 状态。"""
    return _STATUS_MAP.get(internal, A2ATaskStatus.FAILED)


def _extract_url_from_text(text: str) -> str:
    """从文本中提取 URL。"""
    match = re.search(r"https?://\S+", text)
    return match.group(0) if match else ""


class A2ATaskHandler:
    """A2A 任务处理器 — 协议层适配。

    职责:
    1. 解析 A2A Task JSON → 内部 TaskRequest
    2. 调用 TaskManager 执行
    3. 将内部响应映射为 A2A 响应格式
    4. SSE 流式推送 A2A StatusUpdate
    """

    def __init__(self, task_manager: TaskManager, redis_bridge: RedisBridge) -> None:
        self._task_manager = task_manager
        self._redis_bridge = redis_bridge

    def _a2a_to_internal(self, a2a_input: A2ATaskInput) -> TaskRequest:
        """将 A2A 任务输入转换为内部 TaskRequest。"""
        task = a2a_input.task
        meta = task.metadata

        # 从消息文本中提取 URL（如果 metadata 没有显式指定）
        url = ""
        for part in task.message.parts:
            if part.text:
                url = _extract_url_from_text(part.text)
                if url:
                    break

        return TaskRequest(
            task_id=task.id,
            card_alias=meta.card_alias,
            url=url,
            max_amount=meta.max_amount,
            currency=meta.currency,
            require_human_confirmation=meta.require_human_confirmation,
        )

    def _internal_to_a2a(self, internal: TaskResponse) -> A2ATaskResponse:
        """将内部 TaskResponse 转换为 A2A 响应。"""
        a2a_status = _map_status(internal.status)

        # 构建 artifacts（仅终态且有结果时）
        artifacts = []
        if internal.result and a2a_status == A2ATaskStatus.COMPLETED:
            artifacts.append(Artifact(
                type="application/json",
                data=internal.result,
                description="支付交易凭证",
            ))

        return A2ATaskResponse(
            task_id=internal.task_id,
            status=a2a_status,
            artifacts=artifacts,
            message=internal.message,
        )

    async def handle_task(self, a2a_input: A2ATaskInput) -> A2ATaskResponse:
        """处理 A2A 任务请求。

        流程: 解析 → 内部 TaskManager → A2A 响应
        """
        logger.info("收到 A2A 任务: task_id=%s", a2a_input.task.id)

        # 1. 转换为内部请求
        internal_request = self._a2a_to_internal(a2a_input)

        # 2. 调用 TaskManager
        internal_response = await self._task_manager.submit_task(internal_request)

        # 3. 映射为 A2A 响应
        return self._internal_to_a2a(internal_response)

    async def handle_resume(self, task_id: str, resume: ResumeRequest) -> A2ATaskResponse:
        """处理 A2A Resume 请求（HITL 审批后继续）。

        Args:
            task_id: 任务 ID
            resume: 审批动作（approve/reject/provide_input）
        """
        logger.info("A2A Resume: task_id=%s, action=%s", task_id, resume.action)

        if resume.action == "reject":
            # 用户拒绝 → 通过 HITL channel 通知容器
            await self._redis_bridge.publish_hitl_response(task_id, approved=False)
            internal = await self._task_manager.cancel_task(task_id)
            return self._internal_to_a2a(internal)

        if resume.action in ("approve", "provide_input"):
            # 通过 HITL channel 通知容器继续执行
            await self._redis_bridge.publish_hitl_response(task_id, approved=True)
            # 同时发布 resume 事件到事件 channel（兼容旧订阅逻辑）
            await self._redis_bridge.publish_event(task_id, {
                "type": "resume",
                "action": resume.action,
                "input": resume.input,
            })
            return A2ATaskResponse(
                task_id=task_id,
                status=A2ATaskStatus.WORKING,
                message=f"任务已恢复执行 (action={resume.action})",
            )

        return A2ATaskResponse(
            task_id=task_id,
            status=A2ATaskStatus.FAILED,
            message=f"未知的 resume action: {resume.action}",
        )

    async def stream_status_updates(self, task_id: str) -> AsyncGenerator[str, None]:
        """SSE 流式推送 A2A StatusUpdate 事件。

        Yields:
            SSE 格式的事件字符串
        """
        if not self._redis_bridge.connected:
            update = StatusUpdate(
                status=A2ATaskStatus.FAILED,
                message=Message(
                    role="agent",
                    parts=[MessagePart(text="Redis 未连接，无法推送状态更新")],
                ),
            )
            yield f"data: {update.model_dump_json()}\n\n"
            return

        async for event in self._redis_bridge.subscribe_events(task_id):
            status_str = event.get("status", "working")

            # 尝试映射为 A2A 状态
            try:
                a2a_status = A2ATaskStatus(status_str)
            except ValueError:
                # 尝试从内部状态映射
                try:
                    internal_status = TaskStatus(status_str)
                    a2a_status = _map_status(internal_status)
                except ValueError:
                    a2a_status = A2ATaskStatus.WORKING

            update = StatusUpdate(
                status=a2a_status,
                message=Message(
                    role="agent",
                    parts=[MessagePart(text=event.get("message", ""))],
                ),
                timestamp=event.get("timestamp"),
            )

            yield f"data: {update.model_dump_json()}\n\n"

            # 终态时结束流
            if a2a_status in (
                A2ATaskStatus.COMPLETED,
                A2ATaskStatus.FAILED,
                A2ATaskStatus.CANCELED,
            ):
                # 如果有结果，追加 artifact 事件
                result = event.get("result")
                if result and a2a_status == A2ATaskStatus.COMPLETED:
                    artifact = Artifact(
                        type="application/json",
                        data=result,
                        description="支付交易凭证",
                    )
                    yield f"data: {json.dumps({'artifact': artifact.model_dump()})}\n\n"
                break

    async def get_task_status(self, task_id: str) -> A2ATaskResponse:
        """查询 A2A 任务状态。"""
        internal = await self._task_manager.get_task_status(task_id)
        return self._internal_to_a2a(internal)
