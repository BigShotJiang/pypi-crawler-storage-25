"""A2A 协议数据模型 — 兼容 Google A2A 规范的 Pydantic 模型。

自建模型而非依赖 a2a-python SDK，确保稳定性和可控性。
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field

# ─── A2A 任务状态 ────────────────────────────────────────────

class A2ATaskStatus(StrEnum):
    """A2A 协议定义的任务状态（含 payswitch 扩展）。"""

    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input-required"
    AUTH_REQUIRED = "auth-required"      # payswitch 扩展: 3DS/OTP/CAPTCHA
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


# ─── A2A 消息模型 ────────────────────────────────────────────

class MessagePart(BaseModel):
    """A2A 消息的单个部分。"""

    type: str = "text"
    text: str = ""
    data: dict | None = None
    mimeType: str | None = None


class Message(BaseModel):
    """A2A 消息。"""

    role: str = "user"
    parts: list[MessagePart] = Field(default_factory=list)


# ─── A2A 任务模型 ────────────────────────────────────────────

class TaskMetadata(BaseModel):
    """A2A 任务元数据 — payswitch 自定义字段。"""

    card_alias: str = Field(description="虚拟卡别名")
    max_amount: float = Field(default=0, description="最大允许金额")
    currency: str = Field(default="USD", description="货币代码")
    require_human_confirmation: bool = Field(default=True, description="是否需要人类确认")


class A2ATaskInput(BaseModel):
    """POST /a2a 请求体 — A2A 任务输入格式。

    参考: PRDv3 §4.4
    """

    task: TaskBody


class TaskBody(BaseModel):
    """A2A 任务内容。"""

    id: str | None = Field(default=None, description="任务 ID（可选）")
    message: Message
    metadata: TaskMetadata


# ─── A2A 状态更新 ────────────────────────────────────────────

class StatusUpdate(BaseModel):
    """A2A 状态更新事件。"""

    status: A2ATaskStatus
    message: Message | None = None
    timestamp: float | None = None


class Artifact(BaseModel):
    """A2A 任务结果产物（支付凭证）。"""

    type: str = "application/json"
    data: dict = Field(default_factory=dict)
    description: str = ""


class A2ATaskResponse(BaseModel):
    """A2A 任务响应格式。"""

    task_id: str
    status: A2ATaskStatus
    statusUpdates: list[StatusUpdate] = Field(default_factory=list)
    artifacts: list[Artifact] = Field(default_factory=list)
    message: str = ""


# ─── A2A Resume 请求 ─────────────────────────────────────────

class ResumeRequest(BaseModel):
    """A2A Resume 请求 — HITL 审批后继续执行。"""

    action: str = Field(description="动作: approve / reject / provide_input")
    input: dict | None = Field(default=None, description="用户提供的输入（如 OTP 码）")
