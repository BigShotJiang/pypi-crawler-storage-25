"""server 包入口 — ``python -m server`` 或 ``uv run --extra server python -m server``。"""

from __future__ import annotations

import uvicorn

from server.config import ServerConfig


def main() -> None:
    """启动 FastAPI 服务。"""
    config = ServerConfig()
    uvicorn.run(
        "server.app:app",
        host=config.host,
        port=config.port,
        reload=config.debug,
        log_level="info",
    )


if __name__ == "__main__":
    main()
