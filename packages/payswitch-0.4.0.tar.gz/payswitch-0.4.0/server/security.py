"""安全中间件 — API Key 认证 + 请求日志脱敏 + Docker Secret 管理。"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from server.config import ServerConfig

logger = logging.getLogger(__name__)

# ── 卡数据脱敏模式 ──────────────────────────────────────────

# 16~19 位数字（PAN 主账号）
_PAN_PATTERN = re.compile(r"\b(\d{4})\d{8,11}(\d{4})\b")
# CVV: 字段名 "cvv" 后跟 3~4 位数字
_CVV_PATTERN = re.compile(r'(cvv["\']:\s*["\'])\d{3,4}', re.IGNORECASE)
# 有效期: MM/YY 或 MM/YYYY
_EXPIRY_PATTERN = re.compile(r"\b(0[1-9]|1[0-2])[/\-](2[0-9]|[0-9]{4})\b")


def redact_log_message(message: str) -> str:
    """脱敏日志消息中的卡数据。

    将 PAN 替换为 ****NNNN 格式，CVV 替换为 ***，有效期替换为 **/**。
    """
    message = _PAN_PATTERN.sub(r"\1****\2", message)
    message = _CVV_PATTERN.sub(r"\1***", message)
    message = _EXPIRY_PATTERN.sub("**/**", message)
    return message


# ── API Key 认证中间件 ──────────────────────────────────────

# 不需要认证的路径前缀（健康检查、Agent Card、MCP 端点）
_PUBLIC_PATHS = (
    "/health",
    "/.well-known/",
    "/mcp",
    "/docs",
    "/openapi.json",
    "/redoc",
)


class ApiKeyMiddleware(BaseHTTPMiddleware):
    """API Key 认证中间件。

    检查 Authorization: Bearer <api_key> 头部。
    当 config.api_key 为空时，认证自动跳过（开发模式）。
    """

    def __init__(self, app: Any, config: ServerConfig) -> None:
        super().__init__(app)
        self._api_key = config.api_key

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # 未配置 API Key → 跳过认证
        if not self._api_key:
            return await call_next(request)

        # 公开路径 → 跳过认证
        path = request.url.path
        if any(path.startswith(p) for p in _PUBLIC_PATHS):
            return await call_next(request)

        # 提取 Authorization 头
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return JSONResponse(
                status_code=401,
                content={"detail": "缺少 Authorization: Bearer <api_key> 头部"},
            )

        token = auth_header[7:]  # 去掉 "Bearer " 前缀
        if token != self._api_key:
            return JSONResponse(
                status_code=403,
                content={"detail": "API Key 无效"},
            )

        return await call_next(request)


# ── 请求日志脱敏中间件 ──────────────────────────────────────

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """请求日志中间件 — 记录请求/响应并脱敏敏感数据。"""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start = time.monotonic()
        method = request.method
        path = request.url.path

        response = await call_next(request)

        duration_ms = (time.monotonic() - start) * 1000
        log_msg = f"{method} {path} → {response.status_code} ({duration_ms:.0f}ms)"
        # 脱敏日志中可能包含的敏感参数
        log_msg = redact_log_message(log_msg)
        logger.info(log_msg)

        return response


# ── Docker Secret 管理 ──────────────────────────────────────

_DOCKER_SECRET_BASE = "/run/secrets"


def read_docker_secret(name: str) -> str | None:
    """从 Docker Secret 文件读取内容。

    Args:
        name: Secret 名称（对应 /run/secrets/{name} 文件）

    Returns:
        Secret 内容字符串，不存在时返回 None
    """
    from pathlib import Path

    secret_path = Path(_DOCKER_SECRET_BASE) / name
    if not secret_path.exists():
        return None

    content = secret_path.read_text(encoding="utf-8").strip()
    logger.info("已读取 Docker Secret: %s (%d bytes)", name, len(content))
    return content


def read_card_secret() -> dict | None:
    """从 Docker Secret 读取卡数据 JSON。

    预期格式: /run/secrets/card_data 包含 JSON:
    {"card_number": "...", "expiry_month": "...", "expiry_year": "...", "cvv": "...", ...}

    Returns:
        解析后的字典，不存在或解析失败时返回 None
    """
    raw = read_docker_secret("card_data")
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.error("Docker Secret card_data 不是合法 JSON")
        return None
