"""服务配置 — Pydantic BaseSettings，从环境变量读取。"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class ServerConfig(BaseSettings):
    """payswitch 云端服务配置。

    所有字段均可通过环境变量覆盖，前缀为 ``PAYSWITCH_``。
    例如 ``PAYSWITCH_PORT=9000`` 可覆盖默认端口。
    """

    model_config = SettingsConfigDict(env_prefix="PAYSWITCH_")

    # FastAPI 服务
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False

    # Redis
    redis_url: str = "redis://localhost:6379"

    # Docker 沙箱
    docker_image: str = "payswitch-sandbox:latest"
    max_concurrent_tasks: int = 3

    # 服务版本
    version: str = "0.4.0"

    # CORS 允许的前端源
    cors_origins: list[str] = ["http://localhost:5173", "http://localhost:3000"]

    # API Key 认证（空字符串表示不启用认证）
    api_key: str = ""

    # 请求日志脱敏
    enable_request_logging: bool = True
