"""FastAPI 主入口 — A2A + MCP + 健康检查。

启动方式::

    uv run --extra server python -m server
    # 或
    uv run --extra server uvicorn server.app:app --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from server.a2a.agent_card import build_agent_card
from server.a2a.models import A2ATaskInput, A2ATaskResponse, ResumeRequest
from server.a2a.task_handler import A2ATaskHandler
from server.config import ServerConfig
from server.docker_pool import DockerPool
from server.idempotency import IdempotencyManager
from server.models import TaskRequest, TaskResponse, TaskStatus
from server.redis_bridge import RedisBridge
from server.security import ApiKeyMiddleware, RequestLoggingMiddleware
from server.task_manager import TaskManager

logger = logging.getLogger(__name__)

# 全局配置
config = ServerConfig()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """应用生命周期管理 — 初始化和清理资源。"""
    logger.info("payswitch 云端服务启动中... (v%s)", config.version)

    # 初始化 Redis 通信桥
    redis_bridge = RedisBridge()
    await redis_bridge.connect(config.redis_url)
    app.state.redis_bridge = redis_bridge

    # 初始化幂等性管理器
    idempotency = IdempotencyManager()
    await idempotency.connect(config.redis_url)
    app.state.idempotency = idempotency

    # 初始化 Docker 容器池
    docker_pool = DockerPool(config)
    await docker_pool.async_initialize()
    app.state.docker_pool = docker_pool

    # 初始化任务管理器
    task_manager = TaskManager(redis_bridge, idempotency, docker_pool)
    app.state.task_manager = task_manager

    # 初始化 A2A 处理器
    a2a_handler = A2ATaskHandler(task_manager, redis_bridge)
    app.state.a2a_handler = a2a_handler

    # 生成 Agent Card
    app.state.agent_card = build_agent_card(config)

    # 启动僵尸容器清理定时任务
    async def _cleanup_loop() -> None:
        while True:
            await asyncio.sleep(60)
            try:
                cleaned = await docker_pool.cleanup_stale()
                if cleaned:
                    logger.info("定时清理: 清理了 %d 个僵尸容器", cleaned)
            except Exception:
                logger.error("定时清理异常", exc_info=True)

    cleanup_task: asyncio.Task[None] | None = None
    if docker_pool.available:
        cleanup_task = asyncio.create_task(_cleanup_loop())

    logger.info("payswitch 云端服务已就绪 — %s:%d", config.host, config.port)
    yield

    # 清理资源
    logger.info("payswitch 云端服务关闭中...")
    if cleanup_task:
        cleanup_task.cancel()
    await redis_bridge.close()
    await idempotency.close()


app = FastAPI(
    title="payswitch 云端 Agent 服务",
    description="AI Agent 支付编排服务 — A2A + MCP + Docker 沙箱",
    version=config.version,
    lifespan=lifespan,
)

# CORS 中间件（允许前端跨域访问）
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 安全中间件
# API Key 认证（PAYSWITCH_API_KEY 环境变量，空则不启用）
app.add_middleware(ApiKeyMiddleware, config=config)

# 请求日志脱敏
if config.enable_request_logging:
    app.add_middleware(RequestLoggingMiddleware)

# MCP Server 挂载（HTTP 模式 — Streamable HTTP）
try:
    from server.mcp_server import mcp as mcp_server

    app.mount("/mcp", mcp_server.streamable_http_app())
    logger.info("MCP Server 已挂载到 /mcp")
except Exception:
    logger.warning("MCP Server 挂载失败（mcp 库可能未安装）", exc_info=True)


def _get_task_manager() -> TaskManager:
    """从 app.state 获取 TaskManager（lifespan 未就绪时报 503）。"""
    tm: TaskManager | None = getattr(app.state, "task_manager", None)
    if not tm:
        raise HTTPException(status_code=503, detail="服务未就绪")
    return tm


# ─── 健康检查 ─────────────────────────────────────────────

@app.get("/health")
async def health_check() -> dict:
    """健康检查端点。"""
    redis_ok = getattr(getattr(app.state, "redis_bridge", None), "connected", False)
    docker_ok = getattr(getattr(app.state, "docker_pool", None), "available", False)
    return {
        "status": "ok",
        "version": config.version,
        "redis": "connected" if redis_ok else "disconnected",
        "docker": "available" if docker_ok else "unavailable",
    }


# ─── 任务端点 ────────────────────────────────────────────────

@app.post("/task", response_model=TaskResponse, status_code=201)
async def submit_task(request: TaskRequest) -> TaskResponse:
    """提交支付任务。

    流程: 幂等检查 → 创建 Docker 沙箱 → 后台监听 → 返回 task_id
    """
    tm = _get_task_manager()
    response = await tm.submit_task(request)

    # 容器池满时返回 503
    if response.status == TaskStatus.FAILED and "容器池已满" in response.message:
        raise HTTPException(status_code=503, detail=response.message)

    return response


@app.get("/task/{task_id}", response_model=TaskResponse)
async def get_task_status(task_id: str) -> TaskResponse:
    """查询任务状态。"""
    tm = _get_task_manager()
    return await tm.get_task_status(task_id)


@app.post("/task/{task_id}/cancel", response_model=TaskResponse)
async def cancel_task(task_id: str) -> TaskResponse:
    """取消任务（销毁容器 + 释放锁）。"""
    tm = _get_task_manager()
    return await tm.cancel_task(task_id)


# ─── SSE 事件流端点 ──────────────────────────────────────────

@app.get("/task/{task_id}/events")
async def task_event_stream(task_id: str, request: Request) -> StreamingResponse:
    """SSE 端点 — 实时推送任务状态事件。

    前端通过 EventSource 连接此端点，接收任务生命周期中的所有事件。
    """
    redis_bridge: RedisBridge | None = getattr(app.state, "redis_bridge", None)

    async def event_generator() -> AsyncGenerator[str, None]:
        if not redis_bridge or not redis_bridge.connected:
            yield f"data: {json.dumps({'error': 'Redis 未连接'})}\n\n"
            return
        async for event in redis_bridge.subscribe_events(task_id):
            if await request.is_disconnected():
                break
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ─── 截图流端点 ──────────────────────────────────────────────

@app.get("/task/{task_id}/screenshots")
async def task_screenshot_stream(task_id: str, request: Request) -> StreamingResponse:
    """SSE 端点 — 实时推送浏览器截图流。

    沙箱容器定期截图 → base64 JPEG → Redis Pub/Sub → 本端点 → 前端 img 渲染。
    独立 channel: task:{task_id}:screenshots，不与状态事件混合。
    """
    redis_bridge: RedisBridge | None = getattr(app.state, "redis_bridge", None)

    async def screenshot_generator() -> AsyncGenerator[str, None]:
        if not redis_bridge or not redis_bridge.connected:
            yield f"data: {json.dumps({'error': 'Redis 未连接'})}\n\n"
            return


        channel = f"task:{task_id}:screenshots"
        pubsub = redis_bridge._redis.pubsub()
        try:
            await pubsub.subscribe(channel)
            async for message in pubsub.listen():
                if await request.is_disconnected():
                    break
                if message["type"] == "message":
                    yield f"data: {message['data']}\n\n"
        finally:
            await pubsub.unsubscribe(channel)
            await pubsub.aclose()

    return StreamingResponse(
        screenshot_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ─── 沙箱管理端点 ────────────────────────────────────────────

@app.get("/sandbox/status")
async def sandbox_status() -> dict:
    """返回活跃沙箱容器列表。"""
    docker_pool: DockerPool | None = getattr(app.state, "docker_pool", None)
    if not docker_pool or not docker_pool.available:
        return {"available": False, "active": [], "count": 0}

    active = await docker_pool.list_active()
    return {
        "available": True,
        "count": len(active),
        "max": config.max_concurrent_tasks,
        "active": [
            {
                "container_id": s.container_id[:12],
                "task_id": s.task_id,
                "created_at": s.created_at.isoformat(),
                "status": s.status,
            }
            for s in active
        ],
    }


# ─── A2A 协议端点 ─────────────────────────────────────────────

def _get_a2a_handler() -> A2ATaskHandler:
    """从 app.state 获取 A2ATaskHandler。"""
    handler: A2ATaskHandler | None = getattr(app.state, "a2a_handler", None)
    if not handler:
        raise HTTPException(status_code=503, detail="服务未就绪")
    return handler


@app.get("/.well-known/agent.json")
async def get_agent_card() -> dict:
    """A2A Agent Card 发现端点。

    其他 Agent 通过此端点了解 payswitch 的能力和技能。
    """
    card = getattr(app.state, "agent_card", None)
    if not card:
        # lifespan 未就绪时返回静态 Agent Card
        card = build_agent_card(config)
    return card.model_dump()


@app.post("/a2a", response_model=A2ATaskResponse, status_code=201)
async def handle_a2a_task(a2a_input: A2ATaskInput) -> A2ATaskResponse:
    """A2A 任务接收端点 — 接收标准 A2A 格式任务。"""
    handler = _get_a2a_handler()
    return await handler.handle_task(a2a_input)


@app.post("/a2a/resume/{task_id}", response_model=A2ATaskResponse)
async def resume_a2a_task(task_id: str, resume: ResumeRequest) -> A2ATaskResponse:
    """A2A Resume 端点 — HITL 审批后继续执行。"""
    handler = _get_a2a_handler()
    return await handler.handle_resume(task_id, resume)


@app.get("/a2a/status/{task_id}", response_model=A2ATaskResponse)
async def get_a2a_task_status(task_id: str) -> A2ATaskResponse:
    """查询 A2A 任务状态。"""
    handler = _get_a2a_handler()
    return await handler.get_task_status(task_id)


@app.get("/a2a/stream/{task_id}")
async def a2a_event_stream(task_id: str, request: Request) -> StreamingResponse:
    """A2A SSE 状态流 — 流式推送 StatusUpdate 事件。"""
    handler = _get_a2a_handler()

    async def sse_wrapper() -> AsyncGenerator[str, None]:
        async for chunk in handler.stream_status_updates(task_id):
            if await request.is_disconnected():
                break
            yield chunk

    return StreamingResponse(
        sse_wrapper(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
