"""SSE 事件发射器 — 生成兼容前端 SessionEvent 格式的事件。

与 ``frontend/src/lib/sessionModel.ts`` 中的 ``EventKind`` / ``SessionEvent``
接口完全对齐。前端 ``eventStream.ts`` 解析后端发来的 JSON 数据。
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from enum import StrEnum

from pydantic import BaseModel, Field

# ─── EventKind（与前端 sessionModel.ts 对齐）────────────────

class EventKind(StrEnum):
    """事件类型 — 与前端 EventKind 完全对齐 + 扩展。"""

    # 已有（前端已支持的 10 种）
    INTENT_RECEIVED = "intent_received"
    GUARD_PASSED = "guard_passed"
    ROUTE_SELECTED = "route_selected"
    OBSERVE = "observe"
    ACTION_PROPOSED = "action_proposed"
    ACTION_ALLOWED = "action_allowed"
    ACTION_BLOCKED = "action_blocked"
    DETECTION = "detection"
    HUMAN_GATE = "human_gate"
    COMPLETED = "completed"

    # 新增（需要前端同步扩展）
    TOOL_CALL_START = "tool_call_start"
    TOOL_CALL_END = "tool_call_end"
    AUTH_REQUIRED = "auth_required"
    FAILED = "failed"
    CANCELED = "canceled"


# ─── SessionEvent（与前端 SessionEvent 接口完全对齐）────────

class SessionEvent(BaseModel):
    """SSE 事件数据 — 字段名与前端 SessionEvent 接口完全一致。

    前端 ``eventStream.ts`` 会解析以下字段:
    - id: 事件唯一标识
    - at: 时间字符串 "HH:MM:SS"
    - kind: EventKind 枚举值
    - title: 事件标题
    - detail: 事件详情
    - actor: 行为主体（codex/payswitch/browser/human/ledger）
    - path: 行为路径（"Codex / Pay-Switch / Guard"）
    - risk: 风险等级（low/medium/high，可选）
    - target: 操作目标（可选）
    """

    id: str = Field(default_factory=lambda: f"evt-{uuid.uuid4().hex[:8]}")
    at: str = Field(
        default_factory=lambda: datetime.now(UTC).strftime("%H:%M:%S"),
    )
    kind: EventKind
    title: str
    detail: str = ""
    actor: str = "payswitch"
    path: str = ""
    risk: str | None = None
    target: str | None = None


# ─── EventEmitter（事件工厂）──────────────────────────────

class EventEmitter:
    """事件发射器 — 生成兼容前端的 SessionEvent。

    每个 emit_* 方法生成对应类型的事件，可直接序列化为 SSE JSON。
    """

    def emit_intent(
        self,
        agent: str,
        url: str,
        amount: float,
        currency: str = "USD",
    ) -> SessionEvent:
        """任务接收事件。"""
        return SessionEvent(
            kind=EventKind.INTENT_RECEIVED,
            title=f"{agent} 发起支付请求",
            detail=f"目标: {url}, 金额: {amount} {currency}",
            actor="codex",
            path="Codex",
        )

    def emit_guard_passed(
        self,
        amount: float,
        daily_remaining: float | None = None,
    ) -> SessionEvent:
        """Guard 检查通过事件。"""
        detail = f"金额 {amount} 通过限额检查"
        if daily_remaining is not None:
            detail += f", 日累计剩余 {daily_remaining}"
        return SessionEvent(
            kind=EventKind.GUARD_PASSED,
            title="Guard 检查通过",
            detail=detail,
            actor="payswitch",
            path="Codex / Pay-Switch / Guard",
            risk="low",
        )

    def emit_route_selected(self, route: str, reason: str = "") -> SessionEvent:
        """路由选择事件。"""
        return SessionEvent(
            kind=EventKind.ROUTE_SELECTED,
            title=f"选择通道: {route}",
            detail=reason,
            actor="payswitch",
            path="Codex / Pay-Switch / Guard",
        )

    def emit_observe(self, title: str, detail: str = "") -> SessionEvent:
        """浏览器观察事件。"""
        return SessionEvent(
            kind=EventKind.OBSERVE,
            title=title,
            detail=detail,
            actor="browser",
            path="Codex / Pay-Switch / Guard / Browser",
        )

    def emit_action_proposed(
        self,
        action: str,
        target: str = "",
        risk: str = "low",
    ) -> SessionEvent:
        """动作提议事件。"""
        return SessionEvent(
            kind=EventKind.ACTION_PROPOSED,
            title=f"提议: {action}",
            detail="",
            actor="browser",
            path="Codex / Pay-Switch / Guard / Browser",
            risk=risk,
            target=target,
        )

    def emit_action_allowed(self, action: str) -> SessionEvent:
        """动作允许事件。"""
        return SessionEvent(
            kind=EventKind.ACTION_ALLOWED,
            title=f"执行: {action}",
            actor="browser",
            path="Codex / Pay-Switch / Guard / Browser",
            risk="low",
        )

    def emit_action_blocked(self, action: str, reason: str = "") -> SessionEvent:
        """动作阻止事件。"""
        return SessionEvent(
            kind=EventKind.ACTION_BLOCKED,
            title=f"阻止: {action}",
            detail=reason,
            actor="payswitch",
            path="Codex / Pay-Switch / Guard / Browser",
            risk="high",
        )

    def emit_detection(self, what: str, detail: str = "") -> SessionEvent:
        """检测事件（表单检测、iframe 检测等）。"""
        return SessionEvent(
            kind=EventKind.DETECTION,
            title=what,
            detail=detail,
            actor="browser",
            path="Codex / Pay-Switch / Guard / Browser",
        )

    def emit_human_gate(self, reason: str, detail: str = "") -> SessionEvent:
        """Human Gate 触发事件。"""
        return SessionEvent(
            kind=EventKind.HUMAN_GATE,
            title=f"需要人类确认: {reason}",
            detail=detail,
            actor="human",
            path="Codex / Pay-Switch / Guard / Browser / Human Gate",
            risk="high",
        )

    def emit_completed(
        self,
        tx_id: str = "",
        amount: float = 0,
        currency: str = "USD",
    ) -> SessionEvent:
        """支付完成事件。"""
        return SessionEvent(
            kind=EventKind.COMPLETED,
            title="支付完成",
            detail=f"交易 {tx_id}, 金额 {amount} {currency}" if tx_id else "支付流程完成",
            actor="ledger",
            path="Codex / Pay-Switch / Guard / Browser / Human Gate / Ledger",
            risk="low",
        )

    def emit_tool_call(
        self,
        tool_name: str,
        args: dict | None = None,
        result: str | None = None,
    ) -> list[SessionEvent]:
        """工具调用事件（生成 start + end 两个事件）。"""
        events = [
            SessionEvent(
                kind=EventKind.TOOL_CALL_START,
                title=f"调用工具: {tool_name}",
                detail=str(args) if args else "",
                actor="payswitch",
                path="Codex / Pay-Switch",
                target=tool_name,
            ),
        ]
        if result is not None:
            events.append(SessionEvent(
                kind=EventKind.TOOL_CALL_END,
                title=f"工具返回: {tool_name}",
                detail=result[:200] if len(result) > 200 else result,
                actor="payswitch",
                path="Codex / Pay-Switch",
                target=tool_name,
            ))
        return events

    def emit_auth_required(self, auth_type: str, detail: str = "") -> SessionEvent:
        """认证挑战事件（3DS/OTP/CAPTCHA）。"""
        return SessionEvent(
            kind=EventKind.AUTH_REQUIRED,
            title=f"需要认证: {auth_type}",
            detail=detail,
            actor="browser",
            path="Codex / Pay-Switch / Guard / Browser",
            risk="high",
        )

    def emit_failed(self, reason: str, detail: str = "") -> SessionEvent:
        """失败事件。"""
        return SessionEvent(
            kind=EventKind.FAILED,
            title=f"失败: {reason}",
            detail=detail,
            actor="payswitch",
            path="Codex / Pay-Switch",
            risk="high",
        )

    def emit_canceled(self, reason: str = "用户取消") -> SessionEvent:
        """取消事件。"""
        return SessionEvent(
            kind=EventKind.CANCELED,
            title="任务已取消",
            detail=reason,
            actor="human",
            path="Codex / Pay-Switch",
        )
