"""payswitch 云端服务层 — A2A + MCP + Docker 沙箱。

本模块是 payswitch 的云端服务入口，提供：
- FastAPI REST API（A2A 任务接收、MCP 工具调用、健康检查）
- Docker 浏览器沙箱管理
- Redis 通信桥（Pub/Sub + 幂等缓存）
"""
