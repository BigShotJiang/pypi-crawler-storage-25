"""payswitch MCP Server — 将核心 engine 模块包装为 MCP Tools。

9 个 Tool 对应 PRDv3 §5.1 映射表:
- load_card / store_card（CardVault）
- check_spending_limit（SpendingGuard）
- evaluate_risk（RiskGate）
- launch_browser / detect_payment_form / fill_payment_form（Browser + CardFiller）
- record_transaction（Ledger）
- execute_checkout（Orchestrator）

双模式:
- HTTP 模式: ``app.mount("/mcp", mcp.streamable_http_app())``
- stdio 模式: ``python -m server.mcp_stdio``
"""

from __future__ import annotations

import json
import logging

from mcp.server.fastmcp import FastMCP

logger = logging.getLogger(__name__)

mcp = FastMCP(
    "payswitch",
    instructions=(
        "AI Agent 支付编排 MCP Server"
        " — 提供卡管理、限额检查、风控评估、表单填写、账本记录等能力"
    ),
)


# ─── Tool 1: load_card（CardVault.load_virtual_card）──────────

@mcp.tool()
async def load_card(card_alias: str) -> str:
    """从安全存储加载卡信息（返回脱敏信息，PAN/CVV 不会暴露）。

    Args:
        card_alias: 虚拟卡别名（如 my-visa-4242）

    Returns:
        JSON 字符串，包含脱敏后的卡信息
    """
    try:
        from payswitch.security.card_vault import load_virtual_card, mask_pan

        card = load_virtual_card(card_alias)
        if card is None:
            return json.dumps({"error": f"卡 '{card_alias}' 未找到"}, ensure_ascii=False)

        return json.dumps({
            "card_alias": card_alias,
            "card_number_masked": mask_pan(card.card_number),
            "expiry": f"{card.expiry_month}/{card.expiry_year}" if card.expiry_month else "未设置",
            "has_cvv": bool(getattr(card, "cvv", "")),
            "has_billing_address": bool(getattr(card, "billing_address", None)),
        }, ensure_ascii=False)
    except ImportError:
        return json.dumps({"error": "card_vault 模块不可用"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# ─── Tool 2: store_card（CardVault.store_virtual_card）────────

@mcp.tool()
async def store_card(
    card_alias: str,
    card_number: str,
    expiry_month: str = "",
    expiry_year: str = "",
    cvv: str = "",
    cardholder_name: str = "",
) -> str:
    """存储虚拟卡信息到安全存储（OS Keyring）。

    Args:
        card_alias: 卡别名
        card_number: 卡号
        expiry_month: 有效期月份（如 "04"）
        expiry_year: 有效期年份（如 "2031"）
        cvv: 安全码
        cardholder_name: 持卡人姓名

    Returns:
        存储结果（含脱敏卡号）
    """
    try:
        from payswitch.security.card_vault import (
            VirtualCardData,
            store_virtual_card,
        )

        card = VirtualCardData(
            card_number=card_number,
            expiry_month=expiry_month,
            expiry_year=expiry_year,
            cvv=cvv,
            cardholder_name=cardholder_name,
        )
        masked = store_virtual_card(card_alias, card)
        return json.dumps({
            "status": "ok",
            "card_alias": card_alias,
            "card_number_masked": masked,
        }, ensure_ascii=False)
    except ImportError:
        return json.dumps({"error": "card_vault 模块不可用"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# ─── Tool 3: check_spending_limit（SpendingGuard.check）──────

@mcp.tool()
async def check_spending_limit(
    amount: float,
    payee: str = "unknown",
    currency: str = "USD",
) -> str:
    """检查单笔/日累计限额是否允许本次支付。

    Args:
        amount: 金额
        payee: 商户名称
        currency: 货币代码

    Returns:
        JSON 字符串，包含 allowed/reason/remaining 等字段
    """
    try:
        from payswitch.engine.guard import SpendingGuard
        from payswitch.engine.ledger import Ledger
        from payswitch.models.config import PaySwitchConfig

        config = PaySwitchConfig()
        ledger = Ledger()
        guard = SpendingGuard(
            per_transaction_limit=config.per_transaction_limit,
            daily_limit=config.daily_limit,
            merchant_whitelist=config.merchant_whitelist,
        )
        result = guard.check(amount=amount, payee=payee, daily_total=ledger.daily_total())

        return json.dumps({
            "allowed": result.allowed,
            "reason": result.reason,
            "amount": amount,
            "currency": currency,
            "payee": payee,
        }, ensure_ascii=False)
    except ImportError:
        return json.dumps({"error": "guard/ledger 模块不可用"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# ─── Tool 4: evaluate_risk（RiskGate.can_run_autonomously）───

@mcp.tool()
async def evaluate_risk(
    action: str,
    category: str = "navigation",
    risk: str = "low",
) -> str:
    """评估步骤风险等级，决定是否允许自动执行。

    Args:
        action: 动作描述
        category: 步骤类别（navigation/form_fill/click/payment_confirm）
        risk: 风险等级（low/medium/high）

    Returns:
        JSON 字符串，包含 allowed/reason
    """
    try:
        from payswitch.engine.risk import RiskGate, StepCategory, StepRisk
        from payswitch.models.config import PaySwitchConfig

        config = PaySwitchConfig()
        gate = RiskGate(config)

        cat = (
            StepCategory(category)
            if category in StepCategory.__members__.values()
            else StepCategory.NAVIGATION
        )
        rsk = (
            StepRisk(risk)
            if risk in StepRisk.__members__.values()
            else StepRisk.LOW
        )

        decision = gate.can_run_autonomously(category=cat, risk=rsk)
        return json.dumps({
            "allowed": decision.allowed,
            "reason": decision.reason,
            "action": action,
            "category": category,
            "risk": risk,
        }, ensure_ascii=False)
    except ImportError:
        return json.dumps({"error": "risk 模块不可用"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# ─── Tool 5: launch_browser（BrowserController）──────────────

@mcp.tool()
async def launch_browser(url: str, headless: bool = True) -> str:
    """启动隔离浏览器实例（当前返回占位信息，Task 17 接入真实 engine）。

    Args:
        url: 目标 URL
        headless: 是否无头模式

    Returns:
        浏览器实例信息
    """
    # TODO Task 17: 接入 BrowserController
    return json.dumps({
        "status": "not_yet_implemented",
        "message": "浏览器启动功能将在 Task 17 中实现",
        "url": url,
        "headless": headless,
    }, ensure_ascii=False)


# ─── Tool 6: detect_payment_form（CardFormDetector）──────────

@mcp.tool()
async def detect_payment_form(url: str) -> str:
    """检测页面支付表单字段（当前返回占位信息，Task 17 接入真实 engine）。

    Args:
        url: 目标页面 URL

    Returns:
        检测到的表单字段列表
    """
    # TODO Task 17: 接入 CardFormDetector
    return json.dumps({
        "status": "not_yet_implemented",
        "message": "表单检测功能将在 Task 17 中实现",
        "url": url,
    }, ensure_ascii=False)


# ─── Tool 7: fill_payment_form（CardFormFiller）──────────────

@mcp.tool()
async def fill_payment_form(
    url: str,
    card_alias: str,
    dry_run: bool = False,
) -> str:
    """在指定 URL 检测并填写支付表单。

    Args:
        url: 目标支付页面 URL
        card_alias: 虚拟卡别名
        dry_run: 如果为 True，只检测不填写

    Returns:
        填写结果（含检测到的字段和填写状态）
    """
    # 先验证卡是否存在
    try:
        from payswitch.security.card_vault import load_virtual_card, mask_pan

        card = load_virtual_card(card_alias)
        if card is None:
            return json.dumps(
                {"error": f"卡 '{card_alias}' 未找到，请先存储卡信息"},
                ensure_ascii=False,
            )

        if dry_run:
            return json.dumps({
                "status": "dry_run",
                "card_alias": card_alias,
                "card_number_masked": mask_pan(card.card_number),
                "url": url,
                "message": "干运行模式: 卡信息已验证，表单填写功能将在 Task 17 中实现",
            }, ensure_ascii=False)

        # TODO Task 17: 接入 CardFormFiller
        return json.dumps({
            "status": "not_yet_implemented",
            "message": "表单填写功能将在 Task 17 中实现",
            "url": url,
            "card_alias": card_alias,
        }, ensure_ascii=False)
    except ImportError:
        return json.dumps({"error": "card_vault 模块不可用"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# ─── Tool 8: record_transaction（Ledger.record）─────────────

@mcp.tool()
async def record_transaction(
    amount: float,
    currency: str,
    merchant: str,
    status: str = "completed",
) -> str:
    """记录交易到 SQLite 账本。

    Args:
        amount: 交易金额
        currency: 货币代码
        merchant: 商户名称
        status: 交易状态（completed/failed/cancelled）

    Returns:
        记录结果（含 transaction_id）
    """
    try:
        import uuid

        from payswitch.engine.ledger import Ledger
        from payswitch.models.transaction import Transaction, TransactionStatus

        ledger = Ledger()
        tx = Transaction(
            tx_id=f"mcp-{uuid.uuid4().hex[:8]}",
            amount=amount,
            currency=currency,
            payee=merchant,
            status=TransactionStatus(status),
        )
        ledger.record(tx)

        return json.dumps({
            "status": "ok",
            "transaction_id": tx.tx_id,
            "amount": amount,
            "currency": currency,
            "merchant": merchant,
        }, ensure_ascii=False)
    except ImportError:
        return json.dumps({"error": "ledger 模块不可用"}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# ─── Tool 9: execute_checkout（Orchestrator）────────────────

@mcp.tool()
async def execute_checkout(
    url: str,
    card_alias: str,
    max_amount: float,
) -> str:
    """编排完整支付流程（Guard → 浏览器 → 检测 → 填写 → 确认）。

    Args:
        url: 目标支付页面 URL
        card_alias: 虚拟卡别名
        max_amount: 最大允许金额

    Returns:
        支付结果
    """
    # TODO Task 17: 接入 PaymentOrchestrator
    return json.dumps({
        "status": "not_yet_implemented",
        "message": "完整支付流程编排将在 Task 17 中实现",
        "url": url,
        "card_alias": card_alias,
        "max_amount": max_amount,
    }, ensure_ascii=False)
