# Pay-Switch 🚦

> **Teach your AI agents how to spend money — safely.**
> AI Agent 支付编排层：不是钱包，不是充值系统，是支付 GPS。

[![PyPI version](https://img.shields.io/badge/pypi-v0.1.0-blue)]()
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-green)]()
[![License: MIT](https://img.shields.io/badge/license-MIT-yellow)]()
[![Docker Ready](https://img.shields.io/badge/docker-ready-2496ED)]()

---

## Why Pay-Switch?

LLM Agents 已经能写代码、发邮件、订机票 —— **但它们不会花钱**。

现实是：
- 🤖 Agent 想给 DeepSeek 充 API 额度，卡在登录页。
- 🙈 直接把信用卡暴露给 LLM？没人敢。
- 🔁 每个网站的支付流程都不一样，硬编码难以维护。
- 🛑 失控的 Agent 可能把预算一次刷爆。

**Pay-Switch 把"花钱"抽象成一条 CLI 命令**，让 Agent 只需要说 *"spend 200 on deepseek"*，剩下的导航 / 登录 / 确认 / 风控 / 人类兜底全部由 Pay-Switch 处理。

> Agent 写意图，Pay-Switch 管执行。

---

## Core Concept

Pay-Switch 不是浏览器自动化库，也不是支付网关。它是一个**支付编排器（Payment Orchestrator）**，核心是"确定性接口优先 + 受控 Computer Use 兜底 + 人类授权"。

```
┌─────────────────────────────────────────────────────────────┐
│                    AI Agent (Claude / GPT / ...)            │
│                            │                                │
│                  payswitch spend 200 deepseek                  │
└────────────────────────────┼────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                 Pay-Switch CLI / MCP Server                  │
│    ┌──────────────┬──────────────┬──────────────┐           │
│    │ Safety Guard │  Idempotency │   Audit Log  │           │
│    └──────────────┴──────────────┴──────────────┘           │
└────────────────────────────┬────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────┐
│              Execution Engine (Policy Gated)                 │
│                                                             │
│ Official API/A2A/MCP ▶ Script Adapter ▶ Computer Use        │
│       │                    │                  │             │
│       └────────────── Risk Gate + Evidence Log ─────────────┤
│                                                │             │
│                                                ▼             │
│                                  Human Authorization         │
│                                  (Chrome / noVNC / QR)       │
└────────────────────────────┬────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────┐
│               4-Layer Browser Architecture                   │
│  ① Smart Engine   ② Profile Isolation                       │
│  ③ Human Bridge   ④ Security Sandbox                        │
└─────────────────────────────────────────────────────────────┘
```

**Detection signals** Pay-Switch 会识别：QR 码、敏感表单、确认按钮、支付完成页 —— 在正确的时机切换模式或召唤人类。

---

## Agent Workspace Framework

The current architecture work is centered on a user-scoped Agent Workspace
runtime, not on adding more hardcoded checkout scripts.

```text
User Workspace Runtime
-> logical Subagent session per payment task
-> fast recipe-backed Adapter
-> asynchronous Agent Watchdog
-> bounded Computer Use recovery
-> Human Gate for sensitive actions
-> encrypted Artifact and Ledger
```

Protocol connectors remain a future fast path, but they are not the current
implementation blocker. The near-term roadmap is to make browser runtime
ownership, session visibility, profile safety, noVNC routing, recipe promotion,
and Computer Use recovery verifiable before expanding site coverage.

Team-facing development and acceptance requirements live in:

- [`docs/agent-workspace-framework.md`](docs/agent-workspace-framework.md) — target architecture, data/API contracts, security model, phases, and Definition of Done.
- [`docs/framework-alignment-roadmap.md`](docs/framework-alignment-roadmap.md) — current-code gap analysis, workstream roadmap, implementation standards, and acceptance gates.
- [`docs/subagent-harness-architecture.md`](docs/subagent-harness-architecture.md) — subagent harness, stream replay, foreground lease, and adversarial review invariants.
- [`docs/session-display-ownership.md`](docs/session-display-ownership.md) — completed WebUI/control-plane module for session-scoped display ownership, route scoping, and acceptance criteria.
- [`docs/frontend-latest-session-fallback-removal.md`](docs/frontend-latest-session-fallback-removal.md) — completed frontend session-truth module for removing `/api/sessions/latest` snapshot fallback from the hosted WebUI runtime path.
- [`docs/session-scope-propagation-parity.md`](docs/session-scope-propagation-parity.md) — completed selected-session scope propagation module for carrying `user_id` through snapshot reads, scoped confirm/download URLs, and fail-closed snapshot gating before SSE attach.
- [`docs/frontend-inferred-session-owner-scope.md`](docs/frontend-inferred-session-owner-scope.md) — completed hosted-WebUI owner-inference module for carrying a single explicit session owner through refresh, select, delete, clear, SSE, and URL state even when the page did not start with `user_id`.
- [`docs/latest-session-explicit-user-scope.md`](docs/latest-session-explicit-user-scope.md) — completed server route-hardening module for requiring `user_id` on `/api/sessions/latest` whenever explicit scoped sessions exist, while preserving legacy non-explicit compatibility.
- [`docs/session-clear-explicit-user-scope.md`](docs/session-clear-explicit-user-scope.md) — completed bulk-clear hardening module for requiring `user_id` on `DELETE /api/sessions` whenever explicit scoped sessions exist, while preserving legacy non-explicit compatibility.
- [`docs/user-bound-control-plane-read-scope.md`](docs/user-bound-control-plane-read-scope.md) — completed control-plane read-scope module for rejecting ambiguous multi-user reads on `/api/workspaces`, `/api/subagents`, and `/api/workspace-runtimes/health`.
- [`docs/events-stream-explicit-user-scope.md`](docs/events-stream-explicit-user-scope.md) — completed hosted SSE scope-hardening module for requiring `user_id` on `/events` for explicit scoped sessions and keeping the empty dashboard stream only for truly missing sessions.
- [`docs/browser-display-ownership.md`](docs/browser-display-ownership.md) — completed runtime-local browser/display ownership module for visible-session binding, focus locks, and verification criteria.
- [`docs/watchdog-stale-context.md`](docs/watchdog-stale-context.md) — completed Watchdog stale-context module for telemetry TTL, rolling-buffer discard, and recovery evidence projection.
- [`docs/watchdog-classifier.md`](docs/watchdog-classifier.md) — completed Watchdog classifier module for failure taxonomy, recovery routing, and checkpoint evidence projection.
- [`docs/bounded-computer-use-recovery.md`](docs/bounded-computer-use-recovery.md) — completed bounded Computer Use recovery-entrypoint module for step/screenshot/token/wall-time budgets and visible timeout reasons.
- [`docs/recovery-patch-ready-promotion.md`](docs/recovery-patch-ready-promotion.md) — completed queue-driven ready-patch promotion module for dry-run preview, basis filtering, and audited mainline promotion.
- [`docs/service-owned-ready-patch-promotion.md`](docs/service-owned-ready-patch-promotion.md) — completed server-owned ready-patch promotion module for bounded runner loops, health visibility, and env-configured supervision.
- [`docs/recovery-improvement-queue.md`](docs/recovery-improvement-queue.md) — completed recovery improver queue baseline for durable artifact registration, queue triage, and reviewer metadata.
- [`docs/recovery-improvement-processor.md`](docs/recovery-improvement-processor.md) — completed accepted-improvement processor module for dry-run queue processing, patch review advancement, and applied-state closure.
- [`docs/recovery-improvement-runner.md`](docs/recovery-improvement-runner.md) — completed background improver runner module for bounded polling, idle-exit behavior, and reusable loop execution.
- [`docs/service-owned-improver-supervision.md`](docs/service-owned-improver-supervision.md) — completed server-owned improver supervision module for lifecycle wiring, health visibility, and env-configured background polling.
- [`docs/governed-open-improvement-acceptance.md`](docs/governed-open-improvement-acceptance.md) — completed governed open-queue acceptance module for basis-gated acceptance, CLI preview, and optional supervisor auto-accept.
- [`docs/artifact-encryption-baseline.md`](docs/artifact-encryption-baseline.md) — completed Milestone 7 baseline for sensitive JSON artifact encryption, retention sidecar metadata, and transparent runtime/WebUI reads.
- [`docs/artifact-retention-cleanup.md`](docs/artifact-retention-cleanup.md) — completed Milestone 7 cleanup baseline for expired-artifact discovery, bounded cleanup execution, and health-visible service supervision.
- [`docs/screenshot-artifact-encryption.md`](docs/screenshot-artifact-encryption.md) — completed screenshot artifact baseline for encrypted PNG evidence, recipe failure screenshot coverage, and compatibility reads through the local evidence endpoint.
- [`docs/qr-artifact-persistence.md`](docs/qr-artifact-persistence.md) — completed QR artifact persistence module for encrypted detector payload storage, session-visible QR artifact URLs, and QR-first WebUI preview.
- [`docs/evidence-image-format-parity.md`](docs/evidence-image-format-parity.md) — completed image-evidence compatibility module for shared suffix admission, MIME fallback reads, and `.webp`/`.svg` local evidence parity.
- [`docs/artifact-inbox-rotation.md`](docs/artifact-inbox-rotation.md) — completed manual inbox-rotation module for guarded preview, local encrypted-artifact re-encryption, and backup-before-swap key rotation.
- [`docs/session-confirm-artifact-persistence.md`](docs/session-confirm-artifact-persistence.md) — completed confirm-attachment persistence module for inline binary/text artifact storage, authenticated artifact download routes, and A2A download metadata.
- [`docs/persisted-result-artifact-downloads.md`](docs/persisted-result-artifact-downloads.md) — completed persisted-result artifact projection module for synthesized download metadata, MIME inference, and public-result alignment across evidence/generated/media artifacts.
- [`docs/session-confirm-media-artifacts.md`](docs/session-confirm-media-artifacts.md) — completed confirm-time media artifact module for first-class `mediaArtifacts` persistence, authenticated download delivery, and A2A projection.
- [`docs/external-browser-recording-baseline.md`](docs/external-browser-recording-baseline.md) — completed runtime browser-recording baseline for Pay-Switch-owned external sessions, encrypted terminal-close persistence, and `media.persisted` event projection.
- [`docs/timeline-media-artifact-actions.md`](docs/timeline-media-artifact-actions.md) — completed timeline media-action module for direct persisted-recording links from `media.persisted` events without changing timeline state semantics.
- [`docs/browser-evidence-quick-actions.md`](docs/browser-evidence-quick-actions.md) — completed BrowserPreview quick-action module for direct QR and persisted-recording opens from the main runtime panel.
- [`docs/screenshot-replay-browser-recordings.md`](docs/screenshot-replay-browser-recordings.md) — completed screenshot-replay fallback module for synthesizing terminal browser media when native recording is unavailable, including attached CDP-style browser lifecycles.
- [`docs/browser-recording-source-attribution.md`](docs/browser-recording-source-attribution.md) — completed frontend attribution module for distinguishing native browser recordings from screenshot-replay artifacts across BrowserPreview and the event timeline.
- [`docs/media-artifact-recording-source-alias-parity.md`](docs/media-artifact-recording-source-alias-parity.md) — completed control-plane parity module for projecting `recording_source` and `recordingSource` together across public server and local settings/events media-artifact payloads.
- [`docs/external-browser-recording-artifact-ids.md`](docs/external-browser-recording-artifact-ids.md) — completed runtime contract module for assigning stable `artifact_id` values to external-runner browser recordings and replay artifacts at the source event and metadata layer.
- [`docs/browser-recording-size-metadata.md`](docs/browser-recording-size-metadata.md) — completed recording-size parity module for source `size_bytes` emission, API/settings alias preservation, and WebUI size labels on persisted browser media actions.
- [`docs/browser-recording-capture-engine.md`](docs/browser-recording-capture-engine.md) — completed capture-engine parity module for source `capture_engine` emission, control-plane alias preservation, and engine provenance labels across BrowserPreview and the timeline.
- [`docs/browser-recording-duration-metadata.md`](docs/browser-recording-duration-metadata.md) — completed duration-metadata module for source `duration_seconds` emission, API/settings alias preservation, and WebUI duration labels on persisted browser media actions.
- [`docs/browser-recording-frame-rate-metadata.md`](docs/browser-recording-frame-rate-metadata.md) — completed frame-rate parity module for source `frame_rate` emission, API/settings alias preservation, and WebUI fps labels on persisted browser media actions.
- [`docs/browser-recording-frame-size-metadata.md`](docs/browser-recording-frame-size-metadata.md) — completed frame-size parity module for source `frame_width`/`frame_height` emission, API/settings alias preservation, and WebUI resolution labels on persisted browser media actions.
- [`docs/browser-recording-codec-metadata.md`](docs/browser-recording-codec-metadata.md) — completed codec-metadata parity module for source `codec_name` emission, API/settings alias preservation, and WebUI codec labels on persisted browser media actions.
- [`docs/browser-recording-bit-rate-metadata.md`](docs/browser-recording-bit-rate-metadata.md) — completed bit-rate parity module for source `bit_rate` emission, API/settings alias preservation, and WebUI bit-rate labels on persisted browser media actions.
- [`docs/browser-recording-format-labels.md`](docs/browser-recording-format-labels.md) — completed format-label module for human-readable `WebM`/`MP4`/`QuickTime` labels on persisted browser media actions without changing backend contracts.
- [`docs/browser-recording-source-screenshot-count.md`](docs/browser-recording-source-screenshot-count.md) — completed replay-provenance module for `source_screenshot_count` emission, API/settings alias preservation, and replay screenshot-count labels in the WebUI.
- [`docs/browser-recording-index-metadata.md`](docs/browser-recording-index-metadata.md) — completed recording-order module for `recording_index` emission, API/settings alias preservation, and `#<index>` labels across persisted browser media actions.
- [`docs/browser-recording-index-ordering.md`](docs/browser-recording-index-ordering.md) — completed index-aware ordering module for choosing the highest `recording_index` in BrowserPreview and rendering multi-recording timeline links in deterministic order.
- [`docs/browser-preview-multi-recording-actions.md`](docs/browser-preview-multi-recording-actions.md) — completed BrowserPreview quick-action module for exposing every recording from the newest persisted media event instead of only the newest one.
- [`docs/artifact-storage-budget-telemetry.md`](docs/artifact-storage-budget-telemetry.md) — completed artifact inventory baseline for byte-level disk usage, budget signals, and CLI/server health projection.
- [`docs/transaction-screenshot-budget-baseline.md`](docs/transaction-screenshot-budget-baseline.md) — completed transaction screenshot-budget baseline for per-task screenshot ceilings, persisted budget state, and user-visible exhaustion reasons.
- [`docs/artifact-storage-budget-enforcement.md`](docs/artifact-storage-budget-enforcement.md) — completed storage-budget enforcement module for deterministic reclaim order, CLI preview/execution, and service-owned background enforcement.

Key non-negotiables for the next implementation phase:

- no shared browser/display between users;
- no fake session switching in WebUI while runtime ownership remains shared;
- no Computer Use as the default path for normal adapter flows;
- no unreviewed recovery recipe patch entering the main fast path;
- no plaintext secret or unscoped noVNC access.

Current implementation status:

- Milestone 1 (`Durable session truth`) is now the active baseline:
  - session/task/event state is persisted in the control plane;
  - session/workspace/subagent read APIs support explicit `user_id` scoping;
  - WebUI critical read paths no longer need a global latest-session fallback.
  - the hosted frontend snapshot loader now requires an explicit `session_id`
    instead of calling `/api/sessions/latest` as an implicit fallback.
  - when the hosted WebUI starts without `user_id` but the current session list
    belongs to one explicit owner, the frontend now infers that owner and
    carries it through selected-session reads, delete/clear actions, display
    selection, SSE hydration, and URL state.
  - `/api/sessions/latest` now also requires `user_id` whenever explicit scoped
    sessions exist, so the remaining latest-session route no longer bypasses
    explicit ownership.
  - `DELETE /api/sessions` now also requires `user_id` whenever explicit scoped
    sessions exist, so bulk destructive session cleanup no longer bypasses
    explicit ownership.
  - `/api/workspaces`, `/api/subagents`, and
    `/api/workspace-runtimes/health` now also reject ambiguous multi-user reads
    without `user_id`, so user-bound control-plane surfaces no longer expose
    cross-user summaries by default.
  - `/events` now also requires `user_id` for explicit scoped sessions and no
    longer hides scope mismatches behind the empty dashboard stream.
- Milestone 2 (`User workspace runtime boundary`) now has an in-process baseline:
  - one runtime record per user workspace;
  - explicit runtime lifecycle (`active`, `warm`, `sleeping`, `destroyed`);
  - idle sleep and warm-runtime reclamation;
  - host-level admission control and `/api/workspace-runtimes/health`.
- Milestone 3 (`Session-to-display ownership`) now has a control-plane baseline:
  - session-scoped display selection and route tokens;
  - explicit `display_state` / `display_reason` on session snapshots;
  - scoped `/api/sessions/{id}:display/select` and `/api/sessions/{id}/display/view`;
  - foreground-ownership denial for visible actions when another session owns the workspace surface.
  - The current WebUI/control-plane closure is documented in
    [`docs/session-display-ownership.md`](docs/session-display-ownership.md):
    selected-session display state, ready-only takeover links, Human Gate
    ownership rendering, and scoped display-route access checks are complete.
- Workstream C (`Browser and display ownership`) now has a runtime-local baseline:
  - each workspace runtime tracks the selected visible session's browser context, tab, and window metadata;
  - visible actions now acquire a runtime-local `display_focus_lock_id`;
  - context mismatch, foreground-lease drift, and visible-action re-entry are denied before a visible action can proceed;
  - the current runtime-local closure is documented in
    [`docs/browser-display-ownership.md`](docs/browser-display-ownership.md).
- Milestone 4 (`Profile safety`) now has a control-plane baseline:
  - user/site-scoped stable profile vault layout;
  - per-task profile copies prepared from the stable profile before execution;
  - explicit promote/discard lifecycle with rollback and audit trail;
  - browser-engine and profile-schema compatibility gates before stable profiles are reused.
- Milestone 5 (`Fast adapter path`) now has a recipe-backed baseline:
  - the Kimi monthly membership path executes through a dedicated recipe runner;
  - waypoint telemetry emits start/success/failure events without blocking the fast path;
  - failure evidence now captures screenshot, DOM summary, visible text summary, and assertion context;
  - recovery-generated recipe patches stay out of the mainline path until review or shadow-run success.
- Milestone 6 (`Watchdog and bounded recovery`) now has a stale-context + classifier + bounded-entrypoint baseline:
  - default recovery telemetry TTL is 5 minutes;
  - stale rolling telemetry is discarded before recovery continues;
  - script failures are now classified as `retryable_drift`, `login_required`, `sensitive_action`, `unsupported_page`, or `hard_failure`;
  - login-tagged failures route to the login gate, while hard/sensitive failures fail closed to manual recovery;
  - internal/hybrid Computer Use recovery now carries explicit step/screenshot/token/wall-time budgets;
  - hybrid timeout/budget failures now remain visible when the flow falls through to external Computer Use;
  - successful bounded recovery now updates a durable recipe patch candidate and emits a review artifact plus transaction step evidence;
  - successful bounded recovery now also auto-marks that patch as `shadow_run`, while keeping `mainline` promotion outside the automatic path;
  - operators can now list, review, shadow-pass, and promote recovery patch candidates through `payswitch experience patch ...`;
  - operators can now inspect a promotion queue with explicit readiness/blocking reasons through `payswitch experience patch queue`;
  - operators can now batch-promote ready recovery patches through `payswitch experience patch promote-ready`, including `--dry-run`, basis filtering, limits, and durable promotion audit metadata;
  - ready recovery patches can now also run through a bounded promotion runner via `payswitch experience patch run-promoter`, and the server can own that same promotion loop through `/api/recovery-patch-promoter/health` plus `/api/health`;
  - successful bounded recovery now also lands in a durable recovery improvement queue, and operators can triage those items through `payswitch experience improvement ...`;
  - accepted recovery improvements can now be processed through `payswitch experience improvement process`, which advances linked patches into `reviewed` and closes the queue item as `applied`;
  - accepted recovery improvements can now also run through a bounded background runner via `payswitch experience improvement run-loop`, including one-cycle mode, idle-exit behavior, and dry-run preview;
  - accepted recovery improvements can now also run through a service-owned supervisor via FastAPI lifespan, with `/api/recovery-improvements/health` and `/api/health` surfacing the current supervisor state;
  - open recovery improvements can now be accepted through a governed basis gate, either manually via `payswitch experience improvement accept-open` or automatically through the service-owned supervisor when `PAYSWITCH_RECOVERY_IMPROVER_AUTO_ACCEPT_BASIS` is configured;
  - recipe-backed high-risk waypoints can now require a synchronous policy checkpoint before action, and Kimi's `confirm_membership_checkout` path now uses that contract;
  - DeepSeek's top-up fast path now also runs through the shared recipe runner, and its `confirm_topup_checkout` transition now uses the same synchronous policy checkpoint contract before `Next step`;
  - the remaining imperative browser adapters (Qwen, Jimeng, Volcano, and NineEmail) now fail closed behind the same checkpoint contract before their final pay/confirm click, and script recovery handoff now preserves that checkpoint failure context for audit/UI consumers;
  - Qwen's top-up fast path now also runs through the shared recipe runner, with a runner-level `confirm_topup_checkout` checkpoint and durable recipe outcomes;
  - Volcano's top-up fast path now also runs through the shared recipe runner, with a runner-level `confirm_topup_checkout` checkpoint and durable recipe outcomes;
  - Jimeng's top-up fast path now also runs through the shared recipe runner, with a runner-level `confirm_topup_checkout` checkpoint and durable recipe outcomes;
  - NineEmail's product-purchase fast path now also runs through the shared recipe runner, with a runner-level `confirm_topup_checkout` checkpoint and durable recipe outcomes;
  - recovery checkpoints now project watchdog stale-context metadata for review;
  - stale watchdog decisions now force an explicit recovery-state re-synchronization step that captures fresh URL, visible text, DOM summary, and screenshot evidence before Computer Use continues;
  - the bounded recovery-entrypoint slice is documented in
    [`docs/bounded-computer-use-recovery.md`](docs/bounded-computer-use-recovery.md);
  - the recovery patch review slice is documented in
    [`docs/recovery-recipe-patch-review.md`](docs/recovery-recipe-patch-review.md);
  - the recovery patch auto-shadow-run slice is documented in
    [`docs/recovery-patch-auto-shadow-run.md`](docs/recovery-patch-auto-shadow-run.md);
  - the recovery patch promotion-queue slice is documented in
    [`docs/recovery-patch-promotion-queue.md`](docs/recovery-patch-promotion-queue.md);
  - the ready-patch batch promotion slice is documented in
    [`docs/recovery-patch-ready-promotion.md`](docs/recovery-patch-ready-promotion.md);
  - the service-owned ready-patch promotion slice is documented in
    [`docs/service-owned-ready-patch-promotion.md`](docs/service-owned-ready-patch-promotion.md);
  - the recovery improvement-queue slice is documented in
    [`docs/recovery-improvement-queue.md`](docs/recovery-improvement-queue.md);
  - the accepted improvement-processor slice is documented in
    [`docs/recovery-improvement-processor.md`](docs/recovery-improvement-processor.md);
  - the background improvement-runner slice is documented in
    [`docs/recovery-improvement-runner.md`](docs/recovery-improvement-runner.md);
  - the service-owned improver supervision slice is documented in
    [`docs/service-owned-improver-supervision.md`](docs/service-owned-improver-supervision.md);
  - the governed open-improvement acceptance slice is documented in
    [`docs/governed-open-improvement-acceptance.md`](docs/governed-open-improvement-acceptance.md);
  - the adaptive promotion-criteria slice is documented in
    [`docs/adaptive-promotion-criteria.md`](docs/adaptive-promotion-criteria.md);
  - the cross-host artifact-handoff slice is documented in
    [`docs/cross-host-artifact-handoff.md`](docs/cross-host-artifact-handoff.md);
  - the QR artifact-persistence slice is documented in
    [`docs/qr-artifact-persistence.md`](docs/qr-artifact-persistence.md);
  - the image-evidence format-parity slice is documented in
    [`docs/evidence-image-format-parity.md`](docs/evidence-image-format-parity.md);
  - the artifact inbox-rotation slice is documented in
    [`docs/artifact-inbox-rotation.md`](docs/artifact-inbox-rotation.md);
  - the session-confirm artifact-persistence slice is documented in
    [`docs/session-confirm-artifact-persistence.md`](docs/session-confirm-artifact-persistence.md);
  - the persisted-result artifact-download slice is documented in
    [`docs/persisted-result-artifact-downloads.md`](docs/persisted-result-artifact-downloads.md);
  - the session-confirm media-artifact slice is documented in
    [`docs/session-confirm-media-artifacts.md`](docs/session-confirm-media-artifacts.md);
  - the external-browser recording slice is documented in
    [`docs/external-browser-recording-baseline.md`](docs/external-browser-recording-baseline.md);
  - the external-browser recording playback slice is documented in
    [`docs/external-browser-recording-playback.md`](docs/external-browser-recording-playback.md);
  - the timeline media-artifact action slice is documented in
    [`docs/timeline-media-artifact-actions.md`](docs/timeline-media-artifact-actions.md);
  - the BrowserPreview evidence-action slice is documented in
    [`docs/browser-evidence-quick-actions.md`](docs/browser-evidence-quick-actions.md);
  - the screenshot-replay browser-recording slice is documented in
    [`docs/screenshot-replay-browser-recordings.md`](docs/screenshot-replay-browser-recordings.md);
  - the browser-recording source-attribution slice is documented in
    [`docs/browser-recording-source-attribution.md`](docs/browser-recording-source-attribution.md);
  - the media-artifact recording-source alias-parity slice is documented in
    [`docs/media-artifact-recording-source-alias-parity.md`](docs/media-artifact-recording-source-alias-parity.md);
  - the external-browser recording artifact-id slice is documented in
    [`docs/external-browser-recording-artifact-ids.md`](docs/external-browser-recording-artifact-ids.md);
  - the browser-recording size-metadata slice is documented in
    [`docs/browser-recording-size-metadata.md`](docs/browser-recording-size-metadata.md);
  - the browser-recording capture-engine slice is documented in
    [`docs/browser-recording-capture-engine.md`](docs/browser-recording-capture-engine.md);
  - the browser-recording duration-metadata slice is documented in
    [`docs/browser-recording-duration-metadata.md`](docs/browser-recording-duration-metadata.md);
  - the browser-recording frame-rate-metadata slice is documented in
    [`docs/browser-recording-frame-rate-metadata.md`](docs/browser-recording-frame-rate-metadata.md);
  - the browser-recording frame-size-metadata slice is documented in
    [`docs/browser-recording-frame-size-metadata.md`](docs/browser-recording-frame-size-metadata.md);
  - the browser-recording codec-metadata slice is documented in
    [`docs/browser-recording-codec-metadata.md`](docs/browser-recording-codec-metadata.md);
  - the browser-recording bit-rate-metadata slice is documented in
    [`docs/browser-recording-bit-rate-metadata.md`](docs/browser-recording-bit-rate-metadata.md);
  - the browser-recording format-label slice is documented in
    [`docs/browser-recording-format-labels.md`](docs/browser-recording-format-labels.md);
  - the browser-recording source-screenshot-count slice is documented in
    [`docs/browser-recording-source-screenshot-count.md`](docs/browser-recording-source-screenshot-count.md);
  - the browser-recording index-metadata slice is documented in
    [`docs/browser-recording-index-metadata.md`](docs/browser-recording-index-metadata.md);
  - the browser-recording index-ordering slice is documented in
    [`docs/browser-recording-index-ordering.md`](docs/browser-recording-index-ordering.md);
  - the BrowserPreview multi-recording-action slice is documented in
    [`docs/browser-preview-multi-recording-actions.md`](docs/browser-preview-multi-recording-actions.md);
  - the current synchronous checkpoint slice is documented in
    [`docs/synchronous-policy-checkpoints.md`](docs/synchronous-policy-checkpoints.md);
  - the DeepSeek checkpoint expansion slice is documented in
    [`docs/deepseek-synchronous-policy-checkpoints.md`](docs/deepseek-synchronous-policy-checkpoints.md);
  - the imperative-adapter checkpoint retrofit slice is documented in
    [`docs/imperative-adapter-synchronous-policy-checkpoints.md`](docs/imperative-adapter-synchronous-policy-checkpoints.md);
  - the Qwen recipe migration slice is documented in
    [`docs/qwen-recipe-migration.md`](docs/qwen-recipe-migration.md);
  - the Volcano recipe migration slice is documented in
    [`docs/volcano-recipe-migration.md`](docs/volcano-recipe-migration.md);
  - the Jimeng recipe migration slice is documented in
    [`docs/jimeng-recipe-migration.md`](docs/jimeng-recipe-migration.md);
  - the NineEmail recipe migration slice is documented in
    [`docs/nineemail-recipe-migration.md`](docs/nineemail-recipe-migration.md);
  - the current per-action recovery-state verification slice is documented in
    [`docs/per-action-recovery-state-verification.md`](docs/per-action-recovery-state-verification.md);
  - the current classifier closure is documented in
    [`docs/watchdog-classifier.md`](docs/watchdog-classifier.md);
  - the stale-context re-synchronization slice is documented in
    [`docs/stale-context-resynchronization.md`](docs/stale-context-resynchronization.md);
  - the stale-context slice remains documented in
    [`docs/watchdog-stale-context.md`](docs/watchdog-stale-context.md).
- The rest of Milestone 6 and later work are still pending:
  - higher-fidelity browser media beyond the current screenshot, QR,
    session-confirm attachment, Pay-Switch-owned external browser
    recording/playback, and screenshot-replay fallback baseline, especially
    native live capture for CDP-attached user Chrome sessions;

---

## Payment Capability Router

Pay-Switch 的核心不是“自动点网页”，而是一个支付能力路由器。它会优先走官方、可验签、可回调的协议能力；只有协议不可用时，才逐级降级到站点 adapter、经验库 replay、external Computer Use 探索，最后才进入人工接管。

```mermaid
flowchart TD
    A["External Agent payment intent"] --> B["Pay-Switch Guard / Ledger / Policy"]
    B --> C["Payment Capability Router"]

    C --> D{"Protocol connector available?"}
    D -->|Yes| E["Protocol Layer<br/>Alipay A2A / MCP / ACT<br/>Stripe API / merchant API"]
    E --> F["Create order<br/>sign or verify callback<br/>bind user authorization"]

    D -->|No| G{"Stable site adapter available?"}
    G -->|Yes| H["Site Adapter<br/>deterministic checkout flow"]
    H --> I{"Adapter succeeds?"}
    I -->|Yes| F
    I -->|No| J{"Experience recipe available?"}

    G -->|No| J
    J -->|Yes| K["Experience Replay<br/>reuse learned selectors and steps"]
    K --> L{"Replay succeeds?"}
    L -->|Yes| F
    L -->|No| M["External Computer Use Exploration"]

    J -->|No| M
    M --> N["Pay-Switch executes bounded actions<br/>records evidence and state"]
    N --> O["Update Experience Recipe"]
    O --> P{"Stable after repeated runs?"}
    P -->|Yes| Q["Generate adapter candidate<br/>human review before registration"]
    P -->|No| R["Prefer recipe on next run"]

    F --> S{"Sensitive or final authorization?"}
    S -->|Yes| T["Human Gate<br/>QR / CVV / OTP / password / final confirm"]
    S -->|No| U["Continue controlled execution<br/>read result and update ledger"]

    M --> S
```

### Layer Responsibilities

| Layer | What it is for | What it must not do |
|---|---|---|
| Protocol Layer | Official payment and agent commerce protocols: Alipay A2A/MCP/ACT, Stripe API, merchant APIs, signed callbacks, order verification | Pretend to have protocol support when only page automation is available |
| Site Adapter | Stable, tested website flows for known merchants | Store or submit secrets, CVV, OTP, payment passwords, or final authorization without a human gate |
| Experience Recipe | Semi-structured learned checkout paths from prior Computer Use traces | Become production adapter automatically after a single success |
| External Computer Use | Explore unknown or changed pages through caller-agent decisions and Pay-Switch controlled actions | Bypass guardrails, execute sensitive fields, or authorize payment |
| Human Gate | User authorization for QR scan, CVC/CVV, OTP, payment password, final confirm, subscription agreement | Be used as the first fallback when a controlled non-sensitive path can still proceed |

The intended order is:

```text
Protocol connector -> Site adapter -> Experience recipe -> External Computer Use -> Human gate
```

This keeps Pay-Switch positioned as a payment control plane. Browser control is a fallback and learning mechanism, not the product definition.

### Learned Experience Recipes

Pay-Switch can promote successful unknown-site runs into a lightweight
experience layer before a full adapter is written.

- An **experience recipe** stores stable start URLs, selectors, text signals,
  and notes learned from prior supervised checkout runs.
- Adapters can consume that recipe data instead of duplicating every selector
  inline.
- If a recipe proves stable across repeated runs, it becomes the source material
  for a stricter adapter rather than a one-off trace that only lives in logs.

The current DeepSeek top-up path is the reference example: the unknown-site
replay that successfully reached QR payment and billing success was promoted
into a built-in recipe, and the dedicated DeepSeek adapter now reads that
recipe for amount, confirm, QR, and success signals.

### Fixed Checkout Flow

For user-facing checkout runs, the execution contract is:

```text
1. Guard / ledger pre-check
2. Access preflight
   - if the target requires login, verify the live browser session first
   - if not logged in, stop immediately and ask the user to run payswitch login <platform>
3. Intent resolution
   - normalize what the user wants to buy, how much they expect to spend, and whether they mean personal, business, monthly, annual, named plan, or lowest price
   - if the request is incomplete, do not guess
4. Offer and plan discovery
   - inspect the actual pricing page
   - extract cycle controls such as Monthly / Annually
   - extract segment controls such as consumer / Business
   - extract plan names, displayed amounts, renewal terms, and action selectors
5. Plan selection confirmation
   - if a single plan follows directly from the confirmed user intent, continue
   - if multiple commercially meaningful choices remain, ask the user which one to buy before clicking Subscribe or Pay
6. Capability routing
   - protocol connector
   - site adapter
   - experience recipe
   - external Computer Use
7. Human gate for QR / CVV / OTP / password / final authorization
8. Result detection, evidence capture, and ledger update
```

In other words: a checkout should never "accidentally" drift into adapter or Computer Use work before the login requirement is known. Login state is a hard gate, not a best-effort hint.

### Intent Before Payment

For subscription and pricing pages, "find a pay button" is not enough. Pay-Switch
must understand the purchase target before continuing.

The minimum contract is:

```text
login first
understand the user's intent
read the real offer matrix
ask if the intent is still ambiguous
only then click the plan and prepare payment
```

Examples:

- If the user says "buy the cheapest Kimi plan", Pay-Switch should inspect whether the page offers `Monthly`, `Annually`, and `Business`, then prefer `consumer + monthly + cheapest upfront` unless the user says otherwise.
- If the user says only "buy Kimi", Pay-Switch should stop after plan discovery and ask which plan to buy.
- If the page shows multiple tiers with different renewal commitments, Pay-Switch should not click the first visible `Subscribe` button.

Normalized purchase state should include:

```json
{
  "target_product": "Kimi Membership",
  "purchase_type": "subscription",
  "billing_cycle_preference": "monthly",
  "segment_preference": "consumer",
  "strategy": "cheapest_upfront",
  "selected_plan_name": "Andante",
  "selected_amount": 39
}
```

See [doc/plans/2026-05-11-checkout-intent-and-plan-selection.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch/doc/plans/2026-05-11-checkout-intent-and-plan-selection.md) for the full contract.

---

## Quick Start

### 30 秒上手

```bash
# 1. 安装
pip install payswitch

# 2. 初始化（下载 Playwright 浏览器、创建 ~/.payswitch/）
payswitch setup

# 3. 登录目标站点（首次需人类完成，之后复用 profile）
payswitch login deepseek

# 4. 让 Agent 花钱
payswitch spend 200 deepseek --reason "充值 API 额度"
```

### 前端控制台预览

仓库现在包含一个独立的 `frontend/` 工作台，用于展示外部 Agent
支付请求的实时执行状态。它不再只能看 demo：Pay-Switch runtime 会把
external Computer Use 的意图、风控、动作、检测、人工闸门和完成状态
写入本地事件日志，`payswitch ui-events` 会将这些事件转成 SSE 给前端。

```bash
cd frontend
npm install
npm run dev
```

连接真实 Pay-Switch 事件流：

```bash
uv run payswitch ui-events --port 8787

# frontend/.env.local
VITE_PAYSWITCH_EVENTS_URL=http://localhost:8787/events
```

前端会以 SSE 方式连接，并按页面上的 `session_id` 订阅对应交易：

```text
http://localhost:5173/?session_id=<tx_id>
GET /events?session_id=<tx_id>
```

同一个本地 `ui-events` 服务也提供 WebUI 设置接口。打开设置页：

```text
http://localhost:5173/?view=settings
GET /api/settings
GET /api/browser/profiles?browser=chrome
GET /api/browser/doctor
PATCH /api/settings
PATCH /api/browser/profile
POST /api/browser/project-profile
POST /api/browser/cdp-profile/ensure
```

设置页当前覆盖四类高频配置：创建/启动 Pay-Switch 项目专用 Chrome
profile、选择本机已有 Chrome profile、切换 `browser_control_backend` /
`chrome_cdp_url`、设置 `computer_use_driver` 和自动推进边界。LLM Key、
Stripe Secret、卡号明文等敏感内容只返回“已配置/未配置”状态，不在
WebUI 中回显。

事件 payload 示例：

```json
{
  "id": "evt_backend_1",
  "ts": "2026-05-12T10:52:03Z",
  "type": "action.allowed",
  "summary": "允许点击充值按钮",
  "message": "Guard 允许低风险点击，BrowserController 已执行。",
  "source": "pay_switch",
  "path": ["Codex", "Pay-Switch", "Browser", "DeepSeek"],
  "risk": "medium",
  "target": "button:充值",
  "current_url": "https://platform.deepseek.com/topup",
  "screenshot_url": "http://localhost:8787/evidence?path=/Users/me/.payswitch/evidence/tx-step-0.png",
  "detected_payment_methods": ["alipay_qr"],
  "interaction_hints": []
}
```

支持的事件类型包括：

```text
intent.received
guard.passed
route.selected
observe
action.proposed
action.allowed
action.blocked
detection
human.gate
completed
```

打开 Vite 输出的本地地址后：

- 点击 `连接实时流` 可以观察某个真实 `tx_id` 的执行过程
- 点击 `启动演示` 可以在没有后端事件时预览界面
- Codex / Claude Code 请求交给 Pay-Switch 后的实时行为路径
- Guard、能力路由、Browser、Human Gate、Ledger 的阶段状态
- 每次观察、动作提案、允许点击、检测结果和人工授权的事件流
- 真实浏览器观察截图、当前 URL、检测到的支付方式和页面闸门提示
- 进入人工闸门时可切到 noVNC 接管窗口，继续在同一浏览器上下文里完成登录、扫码、CVV 或最终授权

典型输出：

```
✓ Safety check passed (limit: 500/day, remaining: 500)
✓ Idempotency key: spd_01HXYZ...
→ Trying script mode for deepseek... OK
→ Navigating to topup page... OK
→ Filling amount: 200 CNY... OK
⚠ Payment confirmation required
  → Launching human takeover (local popup)
✓ Payment completed in 47s
  Transaction: TXN-20250115-8832
```

---

## CLI Reference

| Command | 说明 |
|---|---|
| `payswitch setup` | 首次初始化环境（浏览器、数据库、配置） |
| `payswitch login <platform>` | 登录并持久化 session profile |
| `payswitch browser-lite <platform> --url <url>` | 识别页面可点击元素，并可按索引/文本点击一次（轻量 computer-use） |
| `payswitch spend <amount> <platform> [--reason]` | **核心命令**：执行一次支付 |
| `payswitch confirm <txn_id>` | 二次确认待处理交易 |
| `payswitch status <txn_id>` | 查看交易状态 |
| `payswitch history [--limit N]` | 查询历史交易记录 |
| `payswitch config [--set KEY VALUE]` | 读写配置（限额、白名单、LLM Key 等） |
| `payswitch platforms` | 列出支持的站点适配器 |

> All commands 支持 `--json` 输出，方便 Agent 程序化解析。

---

## Execution Ladder

Pay-Switch 对同一个支付意图按稳定性和风险逐级执行：

1. **Official API / A2A / MCP**：当支付宝、Stripe、平台方提供官方 Agent/商户接口时优先使用。
2. **Script Adapter**：已知站点使用确定性的 Playwright 路径，适合 Kimi、DeepSeek、九号邮箱这类可沉淀经验的流程。
3. **Controlled Computer Use**：未知或改版站点用模型视觉能力探索登录态、入口、套餐、收银台，但只能推进到付款前或人工接管点。
4. **Human Authorization**：二维码、CVV、OTP、支付密码、最终付款、自动续费协议等必须交给人。

### 🏎️ Script Mode（已知站点快速路径）

针对适配过的站点（DeepSeek / Kimi / Qwen / ...），使用预先调校好的 Playwright 脚本：

- ✅ **快** — 10 秒内完成，无 LLM 调用成本
- ✅ **稳** — 确定性路径，可重放
- ❌ 站点改版可能失效 → 自动回退到 Controlled Computer Use

### 🧠 Controlled Computer Use（智能兜底）

用 LLM + 视觉理解实时解析页面。当前实现先复用 SkyvernEngine 作为视觉驱动，但外面包了一层 Pay-Switch 自己的 `ComputerUseExplorer` 和 `RiskGate`：

- ✅ **通用** — 理论上任何支付页都能跑
- ✅ **自愈** — 站点改版不需要手动修脚本
- ✅ **可控** — 步骤会标记 `category` / `risk`，超过边界就停止
- ❌ 慢 + 有 LLM 成本 → 作为回退存在

#### Browser engine（playwright / cloakbrowser）

浏览器后端分两种：默认 `playwright`（原生 Chromium），高级可换成 `cloakbrowser`。
CloakBrowser 是 Chromium 源码级指纹 patch 的 Playwright drop-in 替换，reCAPTCHA v3 实测 0.9、
Cloudflare Turnstile 自动过、FingerprintJS 显示 `normal browser`。海外支付页（OpenAI / Anthropic /
Replicate）强烈建议开：

```bash
pip install 'payswitch[cloak]'
payswitch config browser_engine cloakbrowser
payswitch config browser_humanize true    # 贝塞尔鼠标曲线 + 真人键盘节奏
```

详细对比、风险与 Docker 部署要点见 [`docs/browser-engines.md`](docs/browser-engines.md)。
**注意**：CloakBrowser 只解决“被识别为 bot”这一关，不解决 Stripe Radar 等交易风控；
Human Gate 仍是硬性红线。

自治边界：

| Step category | 可自治 | 说明 |
|---|---:|---|
| `nav` | ✅ | 打开页面、滚动、关闭普通弹窗 |
| `identity` | ✅/⚠️ | 检查登录态；真正登录密码/2FA 仍交给人 |
| `checkout_prep` | ✅ | 找入口、选套餐候选、进入收银台 |
| `sensitive` | ❌ | CVV、验证码、支付密码、银行卡等 |
| `final_authorization` | ❌ | 确认付款、订阅、自动续费协议 |

默认配置：

```yaml
computer_use_enabled: true
computer_use_driver: hybrid
computer_use_max_autonomous_category: checkout_prep
browser_control_backend: auto
```

浏览器上下文也必须分清楚：

| Context | 说明 |
|---|---|
| Pay-Switch project profile | 默认的 `~/.payswitch/browser/chrome-user-data`，推荐用于真实项目运行；你在这里登录各站点账号，和日常 Chrome 隔离，但会持久保存登录态 |
| Pay-Switch managed profile | 默认的 `~/.payswitch/profiles/<platform>/browser_data`，适合隔离测试，但不是用户日常 Chrome |
| User Chrome profile | `chrome_user_data_dir` + `chrome_profile_directory` 指向用户正常 Chrome profile；真实支付主路径会通过 CDP 复用或启动这个正式 profile |
| Existing Chrome via CDP | `chrome_cdp_url` 连接已经用 `--remote-debugging-port` 打开的 Chrome；连接前会校验 profile 身份 |
| Ephemeral CDP mirror | 从所选 Chrome profile 同步一个 `/tmp/payswitch-cdp-mirrors/profile-<profile>-<hash>` 临时镜像，再用独立 Chrome + CDP 控制；只适合隔离探索，不作为真实支付主路径 |

真实支付链路会拒绝已知隔离 profile，例如
`~/.paperclip/runtime/browser-profiles/*`、`/tmp/payswitch-cdp-mirrors/*`
和 `~/.payswitch/profiles/*`。这些窗口可能仍然显示 Chrome 的 profile 菜单，
但不是你的正式 Chrome 登录态，不能作为支付宝、微信、信用卡等真实消费上下文。
`~/.payswitch/browser/chrome-user-data` 是例外：它是 Pay-Switch 专用、持久、
受控的项目 profile，用来隔离登录付款账号。

真实支付/订阅测试应优先使用用户指定的 Chrome 上下文，而不是让 Pay-Switch 新建一个空 Chromium：

```bash
payswitch settings project-profile
payswitch settings wizard
payswitch settings profile
payswitch settings cdp-profile --ensure
payswitch settings browser-backend
payswitch settings browser-doctor
```

`settings project-profile` 是推荐的真实项目入口。它会创建并绑定
`~/.payswitch/browser/chrome-user-data / Default`，后续 Kimi、DeepSeek、
Seedance 等账号都在这个专用浏览器中登录。它不是日常 Chrome，也不是临时镜像；
因此不会抢占你的个人 Chrome profile，也能通过 CDP 稳定接管。
同一个能力也可以在 WebUI 设置页里完成：点击“仅保存专用 Profile”只写入配置，
点击“启动专用 Profile”会同时启动/复用带 CDP 端口的专用 Chrome。

`settings wizard` 是完整配置引导入口。`settings profile` 用于显式绑定已有
日常 Chrome profile；只有你确实想复用个人 Chrome 登录态时才应使用它。

`settings browser-doctor` 用来检查当前配置能不能直接运行：它会显示启动模式、绑定的 profile、识别到的邮箱、CDP 地址、真实 User Data 目录是否已经被普通 Chrome 占用，并给出下一步处理建议。

```bash
payswitch config chrome_user_data_dir "$HOME/Library/Application Support/Google/Chrome"
payswitch config chrome_profile_directory "Profile 2"
payswitch config chrome_expected_profile_email "user@example.com"
payswitch config browser_channel chrome
```

如果日常 Chrome 已经打开，Pay-Switch 不应复制或镜像 profile。应使用 CDP 模式：先复用已经打开且身份匹配的 remote-debugging 端口；如果没有，并且同一 User Data 没有被其他 Chrome/profile 接管，Pay-Switch 才会按绑定的正式 profile 启动一个带端口的新 Chrome 窗口，并在继续前校验邮箱/profile：

```bash
payswitch settings cdp-profile --ensure
```

直白规则：

- `browser_control_backend=auto`：有 `chrome_cdp_url` 就走 CDP；没有 CDP 但有 `chrome_user_data_dir` 就复用或启动绑定真实 profile 的 CDP；都没有就走自管 profile。
- `browser_control_backend=cdp`：强制使用 CDP；有 `chrome_cdp_url` 就连接并校验身份，没有 URL 但已绑定 profile 时会自动寻找匹配 CDP；只有同一 User Data 未被其他 profile 接管时才启动该 profile 的 CDP。
- `browser_control_backend=ephemeral_cdp_mirror`：从绑定 profile 创建 `/tmp` 临时镜像，启动独立 CDP Chrome，再由 Pay-Switch 接管；这不是正式账号支付主路径，站点可能因密钥绑定、登录风控或会话迁移限制要求重新验证。
- `browser_control_backend=user_profile`：强制独占启动真实 profile；如果普通 Chrome 已经打开，会先报占用错误。
- `browser_control_backend=managed_profile`：强制使用 Pay-Switch 自管 profile，忽略真实 Chrome 配置，适合隔离测试。
- `chrome_cdp_url` 已配置：Pay-Switch 连接一个已经打开且允许调试的 Chrome，不抢 profile。
- `chrome_user_data_dir` 已配置但 `chrome_cdp_url` 为空：Pay-Switch 会优先查找匹配 profile 的 CDP 端口；找不到且同一 User Data 未被其他 profile 接管时，才启动一个使用同一正式 profile 的 CDP Chrome。
- 两者都为空：Pay-Switch 使用自管 profile，适合隔离测试，不等于用户日常登录态。
- 如果 CDP 端口或 `chrome_user_data_dir` 指向 `.paperclip/runtime/browser-profiles`
  这类隔离目录，Pay-Switch 会直接停止，而不是继续付款探索。

临时镜像会按 `tx_id` 复用，以便 `external-act` 多轮观察/点击时不丢页面；新镜像启动前会清理已过期且 CDP 端口不再存活的旧镜像。高频测试大 profile 时要关注 `/tmp` 空间占用。

Computer Use 有三种驱动形态：

| Driver | 谁负责思考 | Pay-Switch 负责什么 | 适用场景 |
|---|---|---|---|
| `external` | 用户自己的 Agent | 浏览器会话、动作审核、检测、人工闸门、账本 | 明确只让调用方 Agent 推理时 |
| `internal` | Pay-Switch 配置的 LLM | 全流程受控探索和停止点判断 | 本地 demo / 无外部 Agent |
| `hybrid` | 外部 Agent + Pay-Switch 内部模型 | 适配器失败后的局部修复和兜底 | 生产自愈路径 |

默认产品形态是 `hybrid`：站点 adapter 先跑；adapter 失效时，Pay-Switch
优先使用内部模型做局部 Computer Use 修复，仍然在 CVV、OTP、支付密码、
二维码、最终确认付款、订阅协议等状态进入 Human Gate。需要只让用户自己的
Agent 思考页面下一步时，可以显式切到 `external`。

注意：`computer_use_driver` 只决定“谁思考页面下一步”；`browser_control_backend` 决定“浏览器这只手怎么接管”。两者必须分开配置，否则就会出现 external 模式已经打开，但底层仍然试图重新启动一个被占用 profile 的问题。

`external-act {"type":"observe"}` 会返回并留档页面感知证据：当前 URL、截图路径、可点击元素、可见输入框/表单、页面标题、viewport 和可见文本摘要。默认只在 JSON 中返回 `screenshot_path`，避免把 CLI 输出撑得过大；调用方确实需要内联图片时，可以在动作里设置 `include_screenshot_base64: true`。

```bash
payswitch settings computer-use --driver external --max-category checkout_prep --enable
```

### 💳 Payment Methods And Card-Number-Only Fallback

Pay-Switch 的默认支付顺序面向中国消费场景：

```text
alipay_qr -> wechat_qr -> card_number_only -> stripe
```

其中 `card_number_only` 是信用卡/银行卡 fallback 的安全 MVP。它只允许在用户确认后填写卡号；有效期、CVV/CVC、短信或邮箱 OTP、3DS 验证、支付密码和最终付款确认都必须由用户自己完成。Pay-Switch 不会把卡号写入 `config.json`、ledger、经验库或截图证据，卡号只保存到本机 OS keyring / macOS Keychain。

查看当前支付策略：

```bash
payswitch settings payment
```

配置支付优先级：

```bash
payswitch settings payment priority --methods alipay_qr,wechat_qr,card_number_only,stripe
```

添加一张仅代填卡号的本地卡片：

```bash
payswitch settings payment card add
```

这会保存卡号到系统安全存储，并在配置文件里只留下卡片 ID、展示名、`secret_ref`、允许收款方、限额和货币白名单等元数据。运行时 external Computer Use 的 `observe` 结果会带上 `detected_payment_methods` 和 `payment_method_resolution`，调用方 Agent 可以据此判断当前页面是否支持支付宝、微信、卡号表单或 Stripe，再按用户偏好选择路径。

### 👤 Human Takeover

当系统检测到以下情况时，**主动交回控制权**：

- 风控验证码 / 2FA
- 扫码支付（QR Code detected）
- 敏感确认按钮（"确认付款 ¥500"）
- 连续两次自动化失败

交互方式：
- **本地模式**：弹出 Chrome 窗口，人类直接操作
- **远程模式**：noVNC 暴露浏览器画面，适合 Docker / 远程 Agent

远程部署只需要 `payswitch-display.service` 提供 Xvfb/x11vnc/noVNC。
`payswitch-live-computer.service` 是一个可选 standby 浏览器；默认不再启动，
否则 noVNC 可能长期停在控制台或 `about:blank`，挡住真实交易窗口。
确实需要一个占位浏览器时，运行安装脚本前设置
`PAYSWITCH_ENABLE_STANDBY_BROWSER=true`。

---

## Safety & Guardrails

Pay-Switch 的设计原则是 **"Agent 犯错不能损失真金白银"**：

| 机制 | 作用 |
|---|---|
| 💰 **Limit Guard** | 单笔 / 每日限额，可按平台细分 |
| 🔒 **Platform Whitelist** | 未在白名单的平台直接拒绝 |
| 🔁 **Idempotency** | 每笔支付生成幂等键，重复调用不会重复扣款 |
| ✋ **Manual Confirm** | 超过阈值的金额必须二次确认 |
| 📜 **Audit Log** | SQLite 全量审计，append-only 不可篡改 |
| 🧊 **Profile Isolation** | 每个平台独立浏览器 profile，cookie 不互相污染 |
| 🛡️ **Sensitive Field Masking** | 检测到密码/CVV 时 Agent 不可操作 |

---

## Docker Deployment

一键启动，带 noVNC 的 Web UI：

```bash
cd docker/
docker compose up -d

# 访问 http://localhost:6080 查看浏览器画面
# 在容器内执行命令：
docker compose exec payswitch payswitch --help
```

`docker-compose.yml` 已内含：
- Xvfb 虚拟显示
- x11vnc + websockify + noVNC
- Playwright + Chromium
- 持久化卷（配置 + Profile + 数据库）

---

## Development

```bash
# 1. Clone
git clone https://github.com/Arxchibobo/payswitch.git
cd payswitch

# 2. Install with dev deps
pip install -e ".[smart,remote,dev]"
playwright install chromium

# 3. Run tests
pytest tests/ -v

# 4. Lint & format
ruff check .
ruff format .

# 5. Run locally
payswitch --help
```

### 项目结构

```
payswitch/
├── payswitch/
│   ├── cli.py            # Typer CLI 入口（所有子命令）
│   ├── engine/           # 编排引擎 + 安全守卫 + 账本
│   │   ├── orchestrator.py
│   │   ├── guard.py
│   │   └── ledger.py
│   ├── browser/          # 4 层浏览器架构
│   │   ├── controller.py
│   │   ├── detector.py
│   │   ├── display.py
│   │   ├── novnc.py
│   │   ├── profiles.py
│   │   ├── safety.py
│   │   └── skyvern.py
│   ├── adapters/         # 站点适配器
│   │   ├── deepseek.py
│   │   ├── kimi.py
│   │   └── qwen.py
│   └── models/           # Pydantic 数据模型
├── docker/               # Docker 部署
├── specs/                # 开发计划
├── tests/                # pytest 测试套件
└── PRD.md                # 产品需求文档
```

### 贡献一个站点适配器

```python
# payswitch/adapters/my_platform.py
from payswitch.adapters.base import SiteAdapter, AdapterRegistry
from payswitch.models.types import PaymentMethod

@AdapterRegistry.register
class MyPlatformAdapter(SiteAdapter):
    name = "my_platform"
    display_name = "My Platform"
    top_up_url = "https://example.com/billing"
    supported_methods = [PaymentMethod.alipay_qr]

    async def execute_topup(self, page, amount, method):
        # Your script here
        ...
```

欢迎 PR 新适配器！

### Versioning

Pay-Switch follows SemVer. The current version is stored in `VERSION`, and user-facing changes are recorded in `CHANGELOG.md` under `Unreleased` until a release is cut.

---

## Tech Stack

| Layer | Technology |
|---|---|
| CLI | Python 3.11+ / Typer / Rich |
| Browser | Playwright / Skyvern (LLM vision) |
| Storage | SQLite (append-only audit) |
| Remote | noVNC / Xvfb / websockify |
| Deploy | Docker / Docker Compose |
| Models | Pydantic V2 |

---

## Roadmap

- [x] CLI core (`setup` / `login` / `spend` / `confirm` / `status` / `history`)
- [x] Script + Skyvern dual mode with fallback chain
- [x] Human takeover (local popup + noVNC)
- [x] Adapters: DeepSeek / Kimi / Qwen
- [x] Safety: limits / whitelist / idempotency / audit
- [x] Docker deployment
- [ ] **v0.2** — HTTP API mode (for remote Agents without shell access)
- [ ] **v0.2** — Multi-account switching
- [ ] **v0.3** — Budget policies DSL (spending rules as code)
- [ ] **v0.3** — Webhook notifications (Slack / DingTalk)
- [ ] **v0.4** — More adapters: OpenAI / Anthropic / Replicate / HuggingFace
- [ ] **v0.5** — MCP Server（让 Claude Desktop 直连）
- [ ] **v0.5** — MPP / AP2 protocol compatibility
- [ ] **v1.0** — Production-ready + security audit

---

## License

[MIT](./LICENSE)

---

<p align="center">
  <sub>If Pay-Switch saved your agent from burning budget, give us a ⭐</sub>
</p>
