# Changelog

All notable changes to Pay-Switch are recorded here.

## [Unreleased]

### What changed

- Restored the runtime bridge from the earlier Computer Use architecture: external actions now emit JSONL runtime events that the frontend can stream by `session_id`.
- Restored session-bound frontend wiring so the WebUI can follow a real transaction instead of only showing the built-in demo.
- External Computer Use now records route, guard, action, detection, human-gate, and ledger events for the active transaction.
- External Computer Use now turns blocking page observations, such as login gates, into explicit human actions and blocks follow-up clicks until the caller observes again.
- External callers can now acknowledge a resolved non-payment human gate, such as plan selection confirmation, and continue the same transaction without losing ledger evidence.
- External browser actions now re-apply the transaction session marker after each step so CDP reconnects can recover the intended tab more reliably.
- Runtime browser observations now surface current URL, evidence screenshots, payment-method candidates, interaction hints, and noVNC takeover links to the WebUI instead of rendering a static mock checkout page.
- The WebUI runtime panel now hydrates from the latest ledger transaction before connecting to SSE, so already-running checkouts show their steps, current URL, screenshot evidence, and human gate instead of an empty waiting state.
- The WebUI now includes a local settings page backed by `payswitch ui-events` APIs for Chrome profile selection, Browser Doctor, Browser Use backend switching, Computer Use policy, and basic payment limits without returning secret values.
- Browser runtime planning now treats a bound real Chrome profile as a guarded CDP target: it reuses an existing matching remote-debugging port, and refuses to force-open a second CDP port when the same User Data root is already owned by another Chrome/profile instance.
- Real-payment CDP and `user_profile` paths now reject known isolated runtime profile copies such as `.paperclip/runtime/browser-profiles`, `/tmp/payswitch-cdp-mirrors`, and `~/.payswitch/profiles`.
- Added `payswitch settings project-profile` to create and bind a persistent Pay-Switch-only Chrome profile at `~/.payswitch/browser/chrome-user-data` for logging site accounts without touching the user's daily Chrome profile.
- Added `payswitch settings cdp-profile --ensure` to check, start, verify, and persist the current profile's CDP endpoint.
- Added WebUI settings actions for binding the Pay-Switch project profile and launching/reusing its CDP Chrome directly from the settings page.
- The WebUI settings page now exposes Browser Engine selection for `playwright` / `cloakbrowser`, including humanize controls and a clear CDP warning when CloakBrowser cannot replace the attached browser process.
- Real checkout runs in `novnc` / headed display modes now launch visible browser windows on the configured display and focus the active payment page before human gates.
- Pay-Switch now keeps non-terminal visible checkout browsers open so operators can take over QR, confirmation, or external Computer Use states from noVNC.
- The dashboard SSE endpoint is readable from the browser without a Bearer header, while write endpoints keep token protection.
- Kimi checkout discovery now recognizes the current `Upgrade your plan` entry and same-page membership dialogs instead of requiring the URL to change to a recharge path.
- Kimi checkout now uses the live membership pricing page, selects the monthly cycle, picks the matching `Subscribe` plan, accepts the pre-payment agreement prompt, and stops on the Alipay/WeChat QR human gate.
- Agent-server payment tasks now return `input-required` as soon as a real checkout reaches a human gate instead of keeping the REST task in `working` while waiting for scanner completion.
- The agent server now serves `/api/sessions/latest` and `/api/sessions/{id}` snapshots for the WebUI and rewrites internal noVNC URLs such as `0.0.0.0:6080` to the configured public noVNC URL.
- Existing adapter and proof helper scripts now satisfy the full-repository Ruff gate used by GitHub Actions.
- CloakBrowser persistent profiles now reuse a deterministic fingerprint seed derived from the profile path instead of rotating browser identity on every launch.
- Internal Computer Use now reuses the server AI provider environment (`PAYSWITCH_AI_*`, `OPENAI_API_KEY`, or `GITHUB_TOKEN`) when `llm_api_key` is not stored in config, so deployed hybrid mode can use the same configured model as `/api/health`.
- The default Computer Use driver is now `hybrid`, so adapter failures first try the internal model-backed repair loop before falling back to external handoff.
- The optional standby noVNC browser service no longer starts by default; deployments keep noVNC for real checkout windows without a placeholder browser occupying the display.
- The WebUI no longer opens the blocking approval modal for QR, login, OTP, CVV, or final-confirmation human gates, and it no longer calls the unsupported resume endpoint from that modal.
- The WebUI now lists all active Pay-Switch sessions and lets operators switch the runtime panel to a specific session instead of implicitly following the latest task.
- The BrowserPreview panel now waits for a session-specific screenshot or noVNC takeover URL instead of embedding the shared display for unrelated sessions.
- The WebUI no longer auto-connects SSE until a real session is selected, and the server no longer creates stored dashboard placeholder sessions for unknown `/events` requests.
- The WebUI now starts in an explicit empty-session state when no real payment task exists, instead of keeping the built-in demo session visible in the runtime panel.
- Selected-session snapshot reads now preserve `user_id`, and the runtime panel fails closed before opening SSE when the scoped snapshot request already fails.
- Explicitly user-scoped session detail, confirm, and persisted-artifact download paths now keep `user_id` parity across public URLs and reject missing scope without breaking legacy non-explicit sessions.
- Running checkout sessions now expose the noVNC takeover URL as soon as Pay-Switch starts browser execution, stream Kimi adapter steps while they happen, and poll the selected session snapshot as a stale-state fallback when SSE misses a transition.
- Session display ownership is now documented as a completed WebUI/control-plane module, including module scope, acceptance criteria, verification, and deferred non-goals.
- Session-scoped display takeover routes now reject missing or wrong `user_id` instead of resolving a user-bound session through bare `session_id` plus token.
- Kimi login detection now catches membership-page login dialogs and opens an explicit login human gate if the session expires after clicking Subscribe.
- Kimi checkout now opens the official homepage first, checks only visible login prompts, tries the homepage subscription entry before the direct pricing fallback, and uses that homepage URL for browser preflight.
- QR and final-confirmation human gates now read as user handoff states in the WebUI and server events, so operators can see that Pay-Switch automation has ended at the scan/authorization step.
- Added a validated Agent Workspace Framework document for the next architecture phase: user-level workspace containers, learned adapter recipes, asynchronous Agent watchdogs, Computer Use recovery, Human Gate boundaries, encrypted artifacts, evidence retention, dynamic noVNC routing, and phase-by-phase acceptance criteria.
- Added a framework-alignment roadmap that maps the current in-process workspace/subagent implementation to the target user-runtime architecture with concrete workstreams, milestone gates, and PR acceptance requirements.
- Added team-facing framework governance for host-level admission control, recipe patch candidate/shadow-run promotion, high-risk synchronous checkpoints, profile schema compatibility, stale telemetry re-sync, and harness review of candidate recipes.
- Updated the README with the Agent Workspace Framework entrypoint and links to the architecture, roadmap, and subagent harness documents.
- The PayAgent installer and MCP server test now satisfy the full-repository Ruff gate on Python 3.11 through 3.13.
- The `payswitch spend --mode` validation error now satisfies the repository-wide Ruff line-length gate from the latest main branch.
- The local desktop integration test now mocks the async display human-notification hook correctly after the latest main branch changes.
- Added a durable SQLite-backed session store for control-plane session truth, including replayable session events, transaction lookup, and durable workspace/subagent read models derived from stored sessions.
- The FastAPI session, workspace, subagent, and SSE read paths are now explicitly user-scoped so the WebUI no longer depends on a global latest-session view for critical runtime state.
- The WebUI now forwards `user_id` through session list, session snapshot, delete/clear, and SSE subscription flows so one operator only hydrates their own session view by default.
- The frontend runtime snapshot helper now requires an explicit `session_id` and no longer calls `/api/sessions/latest` as a hosted WebUI fallback, keeping single-session hydration aligned with the selected-session model.
- The hosted WebUI now infers a single explicit session owner from the session list when the page did not start with `user_id`, and reuses that scope for refresh, delete, clear, selected-session hydration, display selection, SSE attach, and URL state.
- `/api/sessions/latest` now requires `user_id` whenever explicit scoped sessions exist, while legacy non-explicit sessions keep their previous compatibility.
- `DELETE /api/sessions` now requires `user_id` whenever explicit scoped sessions exist, while legacy non-explicit sessions keep their previous compatibility.
- `/api/workspaces`, `/api/subagents`, and `/api/workspace-runtimes/health` now reject ambiguous multi-user reads without `user_id`, while explicit scoped reads keep working.
- `/events` now requires `user_id` for explicit scoped sessions, returns `404` on wrong scoped access, and keeps the empty dashboard SSE path only for truly missing sessions.
- Added an in-process `WorkspaceRuntime` layer with one runtime record per user workspace, explicit runtime lifecycle states (`starting`, `active`, `warm`, `sleeping`, `destroyed`), and typed runtime/display status surfaced through the control-plane APIs.
- Added host-level runtime admission control for active-workspace count, warm-workspace retention, runtime memory budget, and queued workspace admission so new user runtimes do not spawn unbounded browser ownership state on one host.
- Added `/api/workspace-runtimes/health` plus runtime-aware workspace/subagent snapshots so operators and reviewers can inspect runtime health, queued admissions, sleep state, and offline runtime fallbacks directly from the server.
- Added a session-scoped display ownership baseline: live runtimes now track which session owns the visible browser surface, issue scoped display-route tokens, and expose explicit `display_state` / `display_reason` / `display_url` fields on session snapshots.
- Added a runtime-local Browser Manager baseline: each workspace runtime now tracks the selected visible session's browser context/tab/window metadata and exposes that ownership through session snapshots.
- Added a runtime-local visible-action focus lock so foreground Computer Use or other visible actions cannot re-enter while the selected session already holds the runtime focus lock.
- Added a stale-context Watchdog baseline: recovery telemetry now defaults to a 5-minute TTL, discards expired rolling context, and projects watchdog stale-state metadata into recovery checkpoints.
- Added a Watchdog classifier baseline: script failures are now classified as `retryable_drift`, `login_required`, `sensitive_action`, `unsupported_page`, or `hard_failure`, and recovery routing now distinguishes login/manual-only stops from Computer Use candidates.
- Added a bounded Computer Use recovery baseline: internal/hybrid recovery now runs with explicit step, screenshot, token, and wall-time budgets, and hybrid timeout/budget failures remain visible when the flow falls through to external handoff.
- Added `POST /api/sessions/{id}:display/select` plus a scoped `/api/sessions/{id}/display/view` handoff route so the WebUI can switch to a specific session's visible surface instead of embedding a generic shared noVNC target.
- Added a pluggable workspace-runtime factory and user-scoped container driver layer so the control plane can move between in-process and per-user container runtime backends without changing the workspace/session API shape.
- Added a runtime-owned display-route registry that binds short-lived display handoff routes to `user_id`, `workspace_id`, `session_id`, `runtime_id`, and `novnc_route_key` instead of redirecting a valid session token straight to a shared viewer URL.
- Display handoff redirects now append runtime route metadata (`route`, `workspace_id`, `session_id`, `runtime_id`, `display_route_id`) to the public noVNC URL so a later reverse proxy can enforce the same contract without another API change.
- The BrowserPreview panel now follows session-level display truth first, showing explicit wait reasons such as `waiting_for_foreground`, `visible_adapter_not_available`, and `no_runtime` instead of silently falling back to an unrelated shared browser.
- Added a durable stable-vs-task profile vault lifecycle: task profiles are prepared from the stable profile before execution, then explicitly promoted or discarded when the task exits.
- Stable profile reuse now fails closed on browser-engine or profile-schema mismatch, records promotion audit metadata, and refuses promotion while browser lock-file residue remains.
- Session snapshots, subagent views, and workspace summaries now expose profile lifecycle state so profile safety is observable from the control plane.
- Added a recipe schema, runner, and durable experience store so fast-path adapters can execute semantic waypoints without hard-coding orchestration logic into each checkout flow.
- Kimi's monthly membership checkout path now runs through a recipe-backed fast path that emits structured waypoint telemetry and records recipe execution outcomes.
- Candidate recipe patches now stay out of the mainline fast path until they complete a shadow run or an explicit review promotion, matching the framework roadmap gates.
- Successful bounded recovery now upgrades those candidate patches with durable review artifacts, machine-readable recovery evidence, and CLI review/promotion commands under `payswitch experience patch ...`.
- Recipe-backed high-risk waypoints can now require a synchronous policy checkpoint before action, and Kimi's membership confirm waypoint now blocks on visible pricing/payment markers before it clicks `Continue` or similar confirm controls.
- Internal and hybrid Computer Use recovery now verifies every proposed action before execution, blocks login/sensitive payment-boundary actions with structured failure context, and routes those failures to the correct login/manual gate instead of always falling through to external handoff.
- DeepSeek top-up now runs through the shared recipe runner, records recipe outcomes, and blocks its `Next step` payment transition behind the same synchronous policy checkpoint contract used by Kimi.
- The remaining imperative browser adapters (Qwen, Jimeng, Volcano, and NineEmail) now apply the same synchronous checkpoint contract before their final pay/confirm click, record those clicks as `final_authorization` / `high`, and preserve checkpoint failure context in script recovery handoff details.
- Qwen top-up now runs through the shared recipe runner, exposes a built-in `confirm_topup_checkout` waypoint, and records durable recipe outcomes while keeping its fail-closed confirm checkpoint.
- Volcano top-up now runs through the shared recipe runner, exposes built-in continue/confirm/payment-gate waypoints, and records durable recipe outcomes while keeping its fail-closed confirm checkpoint.
- Jimeng top-up now runs through the shared recipe runner, exposes built-in checkout-entry/confirm/payment-gate waypoints, and records durable recipe outcomes while keeping its fail-closed confirm checkpoint.
- NineEmail product purchase now runs through the shared recipe runner, exposes built-in order-form/submit/confirm/QR waypoints, and records durable recipe outcomes while keeping its fail-closed confirm checkpoint.
- Sensitive JSON artifacts now write through a shared `ArtifactStore` that adds sensitivity classification, retention sidecar metadata, and local encrypted-envelope persistence for recovery checkpoints, patch reviews, external handoff artifacts, and external action evidence.
- Runtime evidence readers now decrypt those artifacts transparently, so external resume logic and WebUI session replay keep working without changing their API shape.
- Artifact retention metadata now drives deterministic expiry discovery and deletion, with a bounded cleanup runner, CLI entrypoint, and service-owned FastAPI supervisor health surface.
- Screenshot evidence now also writes through `ArtifactStore`, so external observations, recovery checkpoints, and recipe failure screenshots keep their original `.png` paths while storing encrypted payloads and retention metadata at rest.
- The local evidence-read path now decrypts screenshot artifacts before serving them, preserving existing `/evidence?path=...` consumers.
- Artifact inventory now reports byte-level usage, expired volume, sensitivity/kind breakdowns, and a configurable storage-budget warning signal through both CLI and server health surfaces.
- Added a transaction-level screenshot budget baseline that enforces `transaction_max_screenshots` across recipe failure screenshots, recovery screenshots, and external observe screenshots.
- Ledger transactions now persist `budget_state.screenshots`, including exhaustion metadata, and session snapshots expose that state directly for the control plane.
- External observe results and recovery/recipe telemetry now report explicit screenshot-budget exhaustion reasons instead of silently attempting more screenshot writes.
- Added automatic artifact storage-budget enforcement with deterministic reclaim order, CLI preview/execution, and a service-owned supervisor health surface.
- Artifact budget enforcement now prefers expired, then older public/internal artifacts, and skips sensitive artifacts by default unless explicitly enabled.
- QR human-gate detections now persist inline `data:` QR payloads as encrypted artifacts, project `qr_artifact_url` through session/event payloads, and let the WebUI prefer that QR artifact preview before screenshot fallback.
- The local settings/events evidence API now uses one shared image suffix policy for URL generation and `/evidence` admission, and metadata-less local `.svg`/`.webp` files now fall back to guessed MIME types instead of failing closed.
- Operators can now rotate the local artifact inbox key through a guarded preview-and-reencrypt flow, and the CLI exposes that baseline via `payswitch artifact rotate-inbox`.
- Session-confirm evidence and generated-output attachments can now persist inline binary/text payloads through `ArtifactStore`, expose authenticated download routes, and project persisted download metadata through A2A artifacts.
- Any persisted result artifact with `artifact_path` now automatically projects download metadata and MIME information through both top-level A2A artifacts and the redacted `pay_switch_result` payload.
- Session confirm now accepts first-class `mediaArtifacts`, persists inline media payloads, and serves them through the same authenticated artifact-delivery contract.
- Pay-Switch-owned external browser sessions can now record terminal-lifecycle videos and persist them as encrypted `external_browser_recording` artifacts when the browser closes.
- External runner terminal closes now emit `media.persisted` runtime events with the stored recording metadata.
- External runner terminal detection now updates the transaction state before `finally` releases the browser, so completed runs no longer keep a visible browser open and skip recording flush.
- Session snapshots and SSE replay now project persisted external-browser recording events through downloadable/public-preview `media_artifacts` metadata instead of exposing raw local artifact paths.
- The WebUI runtime model now understands `media.persisted`, preserves terminal session state when those events replay, and plays the latest persisted browser-recording video when no live display or QR preview is active.
- The local settings/events evidence server now treats `.webm` and `.mp4` as previewable evidence assets and projects preview URLs for persisted browser recordings.
- Public session/result payloads and the local settings/events API now project both `recording_source` and `recordingSource` for media artifacts, keeping browser-recording provenance casing-symmetric with the existing download/content-type fields.
- External-runner browser recording events now assign stable `artifact_id` values at the source, so native recordings and screenshot replays no longer rely on raw artifact paths alone.
- Browser recording persistence now preserves `size_bytes` from the runtime source through API projection and WebUI rendering, so persisted media actions expose file size alongside the existing ID, source, and download metadata.
- Browser recording persistence now also preserves `capture_engine`, so operators can distinguish native Playwright terminal video from FFmpeg-based screenshot replay across APIs and the WebUI.
- Browser recording persistence now preserves `duration_seconds`, so persisted media actions expose recording length across runtime events, API/settings projection, and WebUI labels.
- Browser recording persistence now preserves `frame_rate`, so persisted media actions expose fps metadata across runtime events, API/settings projection, and WebUI labels.
- Browser recording persistence now preserves `frame_width` and `frame_height`, so persisted media actions expose resolution metadata across runtime events, API/settings projection, and WebUI labels.
- Stale watchdog recovery decisions now force an explicit recovery-state re-synchronization step that captures fresh URL, visible text, DOM summary, and screenshot evidence before bounded Computer Use continues.
- Computer Use recovery prompts and verification failures now carry that fresh `resync_snapshot`, so stale script failures no longer fall through with only expired page context.
- Successful bounded recovery no longer leaves its recipe patch in raw `candidate` state; it now auto-marks the patch as `shadow_run` with durable validation metadata.
- Recovery-generated patches still do not auto-promote into `mainline`, so the automatic path now stops at `shadow_run` instead of bypassing review.
- Recovery patch storage and CLI now expose a promotion queue with explicit readiness and blocking reasons, so operators can see which patches are promotable without inferring state by hand.
- Persisted browser recordings now carry codec metadata from source emission through API/settings projection and into WebUI action labels, which makes recording compatibility and fidelity more legible without changing capture scope.
- Persisted browser recordings now carry bit-rate metadata from source emission through API/settings projection and into WebUI action labels, which makes encoded recording density more legible without changing capture scope.
- Persisted browser recordings now surface human-readable container labels from existing `content_type` metadata, which makes `WebM`/`MP4` playback format visible in WebUI action labels without changing backend contracts.
- Screenshot replay artifacts now carry the number of source observation screenshots through API/settings projection and into WebUI action labels, which makes replay provenance more concrete without changing replay synthesis.

### Why

- Sensitive recovery and external evidence was still landing as plaintext JSON on disk even after secret-envelope delivery existed for API keys.
- Retention sidecar metadata also existed without any execution path to enforce expiry, so expired artifacts would accumulate on disk indefinitely.
- Screenshot evidence still sat outside the artifact contract, which left QR and checkout screenshots as raw files and prevented cleanup from managing them through the same metadata path.
- Even after cleanup and screenshot encryption, operators still had no control-plane visibility into total artifact disk usage or whether a node had drifted past a reasonable storage budget.
- Even with artifact cleanup and storage telemetry in place, one transaction could still accumulate more screenshots than policy intended during repeated observe or recovery loops.
- Even after inventory telemetry existed, nodes that were already over budget still had no bounded built-in reclaim path beyond manual cleanup commands.
- Even after screenshot encryption, QR detections still kept their payloads inline in event data, which meant QR crops had no encrypted-at-rest artifact record and no stable WebUI preview URL.
- Even after QR artifact URLs were emitted, the local evidence server still rejected some supported image suffixes and returned `None` for metadata-less image files, so the UI path was not format-consistent end to end.
- Even after local artifact encryption and cross-host handoff existed, there was still no governed way to rotate the host's own artifact inbox key without risking unreadable local artifacts.
- Even after screenshot and QR coverage landed, session-confirm attachments still lived as inline blobs with no persisted download contract and no public-result path redaction.
- Even after confirm attachments gained persistence, older persisted evidence/media/generated artifacts still lacked synthesized download metadata unless their producer manually populated every public field.
- Even after generic persisted-artifact projection landed, the confirm API still had no first-class input contract for media artifacts, so capture-like payloads needed ad hoc result mutation.
- Even after confirm-time media persistence landed, the external Computer Use runtime still produced no real browser media artifact of its own.
- Playwright recording files are only finalized on browser/context close, so terminal-state returns had to update `tx` before `finally` released the browser or the recording flush would never happen.
- Even after runtime browser recordings were persisted, the control plane still lacked event-level download projection and WebUI playback, so operators could not actually consume those stored recordings from session state.
- Even after screenshot-replay fallback landed, the WebUI still rendered replay artifacts like native recordings, which blurred the difference between true browser video and synthesized playback.
- Even after provenance reached the WebUI, the public server and local settings/events APIs still did not guarantee both snake_case and camelCase source aliases, which kept the media-artifact contract inconsistent across control planes.
- Even after source attribution and alias parity landed, the external runner still emitted browser recording events without stable artifact IDs, which left downstream download and projection paths dependent on raw filenames and paths.
- Even after artifact IDs landed, persisted browser recordings still lacked end-to-end size metadata, which kept recording quick actions and media links weaker than the rest of the artifact contract.
- Even after size metadata landed, persisted browser recordings still did not expose which capture engine produced them, which kept native terminal video and screenshot replay too easy to confuse at the operator layer.
- Even after engine metadata landed, persisted browser recordings still did not expose duration end to end, which kept media evidence links less informative than the rest of the artifact contract.
- Even after duration metadata landed, persisted browser recordings still did not expose fps end to end, which kept replay fidelity and native video density harder to interpret from the control plane.
- Even after fps metadata landed, persisted browser recordings still did not expose resolution end to end, which kept replay fidelity and native video dimensions harder to interpret from the control plane.
- Even after resolution metadata landed, persisted browser recordings still did not expose codec information end to end, which kept capture compatibility and playback expectations harder to interpret from the control plane.
- Even after codec metadata landed, persisted browser recordings still did not expose bit-rate information end to end, which kept encoded density and replay-versus-native quality harder to interpret from the control plane.
- Even after bit-rate metadata landed, operators still had to infer `WebM` versus `MP4` from file names or MIME strings, which kept the media evidence surface less legible than the rest of the recording metadata.
- Even after format labels landed, screenshot replay still did not expose how many persisted observation screenshots fed the synthesized video, which kept replay provenance partially opaque in the control plane.
- Even after replay screenshot-count landed, operators still could not tell the intended order of multiple persisted recordings from the control plane, which kept media quick actions partially ambiguous for sessions with more than one archived video.
- Even after `recording_index` reached the WebUI, the preview still chose the first video artifact in the latest persisted-media event and the timeline still trusted raw array order, which meant multi-recording sessions could still foreground the wrong recording.
- Even after BrowserPreview learned how to choose the newest recording correctly, its quick-action row still exposed only one recording link, which left older recordings from the same archive event harder to reach than they needed to be.
- Even after selected-session scope propagation landed, the hosted frontend still behaved as unscoped when the URL lacked `user_id`, even if the fetched session list already proved that every visible session belonged to one explicit owner.
- Even after the hosted frontend stopped depending on `/api/sessions/latest`, the server still allowed one global latest-session shortcut whenever only one explicit owner happened to exist.
- Even after scoped deletes and latest-session hardening landed, `DELETE /api/sessions` still left one unscoped destructive path that could clear explicitly owned sessions in bulk.
- Even after session-route hardening landed, adjacent user-bound control-plane read routes still exposed one unscoped multi-user read surface across workspaces, subagents, and runtime health.
- Even after the rest of the selected-session routes were scoped, `/events` still allowed one live-stream shortcut that could attach to an explicit scoped session without `user_id`.

### Impact

- Sensitive JSON evidence now has a single storage contract with encryption-at-rest metadata, and existing runtime/WebUI evidence consumers continue to read those files transparently.
- Artifact retention now has a local enforcement baseline, so operators and the service can preview or execute bounded cleanup without inventing ad hoc scripts.
- Screenshot evidence now follows the same encrypted-at-rest and metadata-backed retention contract as JSON evidence, without changing transaction or recipe telemetry shapes.
- Artifact storage now has an observability baseline, so budget pressure can be detected deterministically before introducing more aggressive cleanup or quota policy.
- Each transaction now has a deterministic screenshot ceiling, and budget exhaustion is visible through ledger state, task/session results, and external observe responses without changing evidence-read APIs.
- Storage budget enforcement now has an executable local policy, so hosts can move back toward budget without ad hoc scripts while still protecting sensitive artifacts by default.
- QR handoff payloads now follow the same encrypted artifact contract as screenshots, and operators can render a stable QR image in the WebUI before the visible browser handoff is ready.
- Local evidence image handling is now deterministic across `.png`, `.jpg`, `.jpeg`, `.webp`, and `.svg`, so generated image URLs and actual evidence reads no longer drift apart.
- Artifact key lifecycle now has a manual local rotation baseline, so operators can deliberately rotate the inbox key and keep existing encrypted artifacts readable instead of treating the first generated key as permanent.
- Session-confirm attachment payloads now leave the response body as persisted artifacts, and agents can fetch them later through authenticated session artifact URLs instead of scraping inline blobs.
- Persisted result artifacts now have one public delivery shape, so legacy or future `media_artifacts` entries can be downloaded without custom per-producer metadata glue.
- Confirm-time media payloads now use the same governed persistence path as evidence and generated outputs, so post-payment captures no longer need a side-channel result writer.
- Pay-Switch-owned external browser runs now produce a durable encrypted video artifact on terminal close, giving the artifact layer its first real runtime browser-recording producer.
- Terminal browser release now reflects the final transaction state, which prevents completed external runs from leaving a visible browser open and dropping the pending recording file on the floor.
- CDP-attached user Chrome sessions are still explicitly outside the recording baseline, so the control plane does not overstate what is actually captured.
- Persisted external browser recordings now have one control-plane delivery path across `/api/sessions`, `/events`, the local settings/event server, and the WebUI runtime panel, so stored videos are observable without filesystem access.
- `media.persisted` replay no longer corrupts a waiting-human or completed session back into an in-flight UI state, which keeps playback additive to the existing workflow instead of rewriting it.
- Timeline `media.persisted` events now expose direct persisted-artifact actions, so operators can open the exact stored browser recording from the event that archived it instead of hunting through the main preview panel.
- The BrowserPreview panel now exposes direct QR and persisted-recording actions, so operators can jump from the main runtime surface to the exact stored evidence without leaving the selected session context.
- External sessions that lack native browser video recording can now synthesize a terminal replay video from persisted observation screenshots, which gives attached-CDP-style runs a browser-media artifact without changing the existing `media.persisted` contract.
- Operators can now tell whether a persisted browser video is a native recording or a screenshot replay before opening it, which keeps the evidence surface honest about capture fidelity.
- The WebUI now preserves browser recording provenance from `media.persisted` events and labels screenshot replays separately from native browser recordings across BrowserPreview and the timeline.
- Browser-recording provenance now survives both public server projection and local settings/events projection with the same field aliases, which lowers downstream parser drift and keeps artifact consumers casing-agnostic.
- Runtime browser-recording artifacts now start with stable IDs at emission time, which makes later download projection and contract reuse less path-dependent.
- Persisted browser recordings now carry byte-size metadata from source emission through API/settings projection and into WebUI action labels, which makes the media evidence surface more concrete without changing capture scope.
- Persisted browser recordings now carry capture-engine provenance from source emission through API/settings projection and into WebUI action labels, which makes replay versus native terminal video explicit without changing the recording pipeline.
- Persisted browser recordings now carry duration metadata from source emission through API/settings projection and into WebUI action labels, which makes the media evidence surface more descriptive without changing capture scope.
- Persisted browser recordings now carry frame-rate metadata from source emission through API/settings projection and into WebUI action labels, which makes replay fidelity more legible without changing capture scope.
- Persisted browser recordings now carry frame-size metadata from source emission through API/settings projection and into WebUI action labels, which makes recording resolution more legible without changing capture scope.
- Persisted browser recordings now carry codec metadata from source emission through API/settings projection and into WebUI action labels, which makes recording compatibility more legible without changing capture scope.
- Persisted browser recordings now carry bit-rate metadata from source emission through API/settings projection and into WebUI action labels, which makes encoded recording density more legible without changing capture scope.
- Persisted browser recordings now surface human-readable `WebM`/`MP4`/`QuickTime` labels in WebUI action labels, which makes playback format visible without changing persisted media contracts.
- Screenshot replay artifacts now surface their source screenshot count in persisted media payloads and WebUI action labels, which makes replay provenance more legible without changing native recording behavior.
- Media actions now surface `#2`-style recording-order labels across BrowserPreview and the timeline, so operators can distinguish multiple persisted recordings in one session without dropping into raw payload inspection.
- Persisted browser recordings now carry `recording_index` metadata from source emission through API/settings projection and into WebUI action labels, which makes multi-recording order visible without changing persisted media contracts.
- BrowserPreview now selects the highest indexed recording from the newest persisted media event, and LiveTimeline now orders multi-recording links by `recording_index`, so the WebUI no longer foregrounds the first raw array item by accident.
- BrowserPreview now exposes one quick action per recording from the newest persisted media event, so operators can open older archived recordings from the main preview panel instead of dropping into the timeline.
- Hosted WebUI session management now keeps single-owner scope stable even when the page is opened without `user_id`, which removes one remaining drift between list truth and selected-session behavior.
- The remaining latest-session route now matches the explicit-ownership direction of scoped session detail, confirm, and artifact-download paths instead of keeping a global shortcut for explicitly scoped sessions.
- Bulk session cleanup now follows the same explicit-ownership direction as scoped delete/detail/download routes instead of keeping one unscoped destructive shortcut.
- User-bound control-plane summaries now follow the same explicit-scope direction as session reads, which reduces cross-user visibility drift on shared hosts.
- The live SSE route now follows the same explicit-scope direction as selected-session detail and download paths, which removes one remaining runtime-path mismatch.

### Verification

- `ruff check payswitch/security/artifacts.py payswitch/engine/orchestrator.py payswitch/engine/external_runner.py payswitch/cli.py payswitch/models/config.py tests/test_artifact_store.py tests/test_external_runner.py tests/test_ui_settings_api.py`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_external_runner.py tests/test_ui_settings_api.py tests/test_secret_envelope.py -q`
- `.venv/bin/python -m pytest tests/test_integration.py -k test_successful_computer_use_recovery_marks_patch_shadow_run -q`
- `ruff check payswitch/security/artifacts.py payswitch/security/cleanup.py payswitch/server.py payswitch/cli.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py tests/test_ui_settings_api.py -q`
- `.venv/bin/python -m pytest tests/test_server_recovery_improver.py tests/test_cli_experience.py -q`
- `ruff check payswitch/security/artifacts.py payswitch/cli.py payswitch/engine/external_runner.py payswitch/engine/orchestrator.py payswitch/experience/runner.py payswitch/adapters/base.py payswitch/adapters/kimi.py payswitch/adapters/deepseek.py payswitch/adapters/qwen.py payswitch/adapters/volcano.py payswitch/adapters/jimeng.py payswitch/adapters/nineemail.py tests/test_artifact_store.py tests/test_external_runner.py tests/test_experience_runner.py tests/test_ui_settings_api.py`
- `ruff check payswitch/models/transaction.py payswitch/engine/ledger.py payswitch/models/config.py payswitch/security/screenshot_budget.py payswitch/adapters/base.py payswitch/experience/runner.py payswitch/adapters/kimi.py payswitch/adapters/deepseek.py payswitch/adapters/qwen.py payswitch/adapters/volcano.py payswitch/adapters/jimeng.py payswitch/adapters/nineemail.py payswitch/engine/orchestrator.py payswitch/engine/external_runner.py payswitch/server.py tests/test_screenshot_budget.py tests/test_models.py tests/test_experience_runner.py tests/test_external_runner.py tests/test_server_public_urls.py`
- `.venv/bin/python -m compileall payswitch/models/transaction.py payswitch/engine/ledger.py payswitch/models/config.py payswitch/security/screenshot_budget.py payswitch/adapters/base.py payswitch/experience/runner.py payswitch/adapters/kimi.py payswitch/adapters/deepseek.py payswitch/adapters/qwen.py payswitch/adapters/volcano.py payswitch/adapters/jimeng.py payswitch/adapters/nineemail.py payswitch/engine/orchestrator.py payswitch/engine/external_runner.py payswitch/server.py tests/test_screenshot_budget.py tests/test_models.py tests/test_experience_runner.py tests/test_external_runner.py tests/test_server_public_urls.py`
- `.venv/bin/python -m pytest tests/test_screenshot_budget.py tests/test_models.py tests/test_experience_runner.py tests/test_external_runner.py tests/test_server_public_urls.py -q`
- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_ui_settings_api.py tests/test_server_artifact_inventory.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py tests/test_cli_artifact_stats.py -q`
- `.venv/bin/python -m pytest tests/test_integration.py -k "recovery or checkpoint or human_gate" -q`
- `git diff --check`
- `ruff check payswitch/security/artifacts.py payswitch/security/cleanup.py payswitch/server.py payswitch/cli.py tests/test_artifact_budget_enforcement.py tests/test_server_artifact_budget_enforcement.py tests/test_cli_artifact_budget_enforcement.py`
- `.venv/bin/python -m pytest tests/test_artifact_budget_enforcement.py tests/test_server_artifact_budget_enforcement.py tests/test_cli_artifact_budget_enforcement.py tests/test_artifact_inventory.py tests/test_server_artifact_inventory.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py tests/test_cli_artifact_stats.py -q`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_external_runner.py tests/test_experience_runner.py tests/test_ui_settings_api.py -q`
- `ruff check payswitch/security/artifacts.py payswitch/cli.py payswitch/server.py tests/test_artifact_inventory.py tests/test_server_artifact_inventory.py tests/test_cli_artifact_stats.py`
- `.venv/bin/python -m pytest tests/test_artifact_inventory.py tests/test_server_artifact_inventory.py tests/test_cli_artifact_stats.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py -q`
- `ruff check payswitch/security/artifacts.py payswitch/engine/external_runner.py payswitch/cli.py tests/test_external_runner.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx`
- `npm run build`
- `ruff check payswitch/cli.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_ui_settings_api.py -q`
- `ruff check payswitch/security/artifacts.py payswitch/cli.py tests/test_artifact_store.py tests/test_cli_artifact_handoff.py`
- `./.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_cli_artifact_handoff.py -q`
- `ruff check payswitch/server.py tests/test_server_public_urls.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py tests/test_secret_envelope.py -q`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py -q`
- `ruff check payswitch/server.py tests/test_server_public_urls.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py -q`
- `ruff check payswitch/browser/controller.py payswitch/browser/engines/__init__.py payswitch/browser/engines/playwright_engine.py payswitch/browser/engines/cloakbrowser_engine.py payswitch/engine/external_runner.py tests/test_browser_engines.py tests/test_browser_controller_config_readback.py tests/test_external_runner.py`
- `./.venv/bin/python -m pytest tests/test_browser_engines.py tests/test_browser_controller_config_readback.py tests/test_external_runner.py -q`
- `./.venv/bin/python -m pytest tests/test_browser_controller.py -q`
- `./.venv/bin/python -m ruff check payswitch/server.py payswitch/cli.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/lib/sessionModel.test.ts src/lib/sessionSnapshot.test.ts src/components/BrowserPreview.test.tsx`
- `npm test -- --run src/components/LiveTimeline.test.tsx src/components/BrowserPreview.test.tsx src/lib/eventStream.test.ts src/lib/sessionModel.test.ts src/lib/sessionSnapshot.test.ts`
- `npm run build`
- `npm test -- --run src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx src/lib/eventStream.test.ts src/lib/sessionModel.test.ts src/lib/sessionSnapshot.test.ts`
- `npm run build`
- `./.venv/bin/python -m ruff check payswitch/server.py payswitch/cli.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py tests/test_external_runner.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py -q`

### Files

- `payswitch/security/artifacts.py`
- `payswitch/security/cleanup.py`
- `payswitch/server.py`
- `frontend/src/App.tsx`
- `frontend/src/App.test.tsx`
- `frontend/src/hooks/useSessionList.ts`
- `frontend/src/hooks/useSessionList.test.ts`
- `payswitch/server.py`
- `tests/test_server_public_urls.py`
- `payswitch/server.py`
- `tests/test_server_public_urls.py`
- `payswitch/server.py`
- `tests/test_server_public_urls.py`
- `payswitch/server.py`
- `tests/test_server_public_urls.py`
- `payswitch/engine/orchestrator.py`
- `payswitch/engine/external_runner.py`
- `payswitch/experience/runner.py`
- `payswitch/adapters/base.py`
- `payswitch/adapters/kimi.py`
- `payswitch/adapters/deepseek.py`
- `payswitch/adapters/qwen.py`
- `payswitch/adapters/volcano.py`
- `payswitch/adapters/jimeng.py`
- `payswitch/adapters/nineemail.py`
- `payswitch/cli.py`
- `frontend/src/lib/sessionModel.ts`
- `frontend/src/lib/eventStream.ts`
- `frontend/src/lib/formatFrameRate.ts`
- `frontend/src/lib/formatFrameSize.ts`
- `frontend/src/components/BrowserPreview.tsx`
- `frontend/src/components/LiveTimeline.tsx`
- `frontend/src/App.css`
- `payswitch/models/config.py`
- `payswitch/cli.py`
- `payswitch/security/artifacts.py`
- `tests/test_artifact_store.py`
- `tests/test_artifact_cleanup.py`
- `tests/test_server_artifact_cleanup.py`
- `tests/test_cli_artifact_cleanup.py`
- `tests/test_external_runner.py`
- `tests/test_experience_runner.py`
- `tests/test_ui_settings_api.py`
- `tests/test_artifact_inventory.py`
- `tests/test_server_artifact_inventory.py`
- `tests/test_cli_artifact_stats.py`
- `tests/test_server_public_urls.py`
- `payswitch/browser/engines/__init__.py`
- `payswitch/browser/engines/playwright_engine.py`
- `payswitch/browser/engines/cloakbrowser_engine.py`
- `payswitch/browser/controller.py`
- `tests/test_browser_engines.py`
- `tests/test_browser_controller.py`
- `tests/test_browser_controller_config_readback.py`
- `docs/session-confirm-artifact-persistence.md`
- `docs/persisted-result-artifact-downloads.md`
- `docs/session-confirm-media-artifacts.md`
- `docs/external-browser-recording-baseline.md`
- `docs/external-browser-recording-playback.md`
- `docs/timeline-media-artifact-actions.md`
- `docs/browser-evidence-quick-actions.md`
- `docs/screenshot-replay-browser-recordings.md`
- `docs/browser-recording-source-attribution.md`
- `docs/media-artifact-recording-source-alias-parity.md`
- `frontend/src/lib/eventStream.test.ts`
- `frontend/src/components/BrowserPreview.test.tsx`
- `frontend/src/lib/sessionModel.test.ts`
- `frontend/src/lib/sessionSnapshot.test.ts`
- `frontend/src/lib/formatBitRate.ts`
- `frontend/src/lib/browserRecording.ts`
- `frontend/src/components/LiveTimeline.test.tsx`
- `frontend/src/components/LiveTimeline.tsx`
- `docs/browser-recording-codec-metadata.md`
- `docs/browser-recording-bit-rate-metadata.md`
- `docs/browser-recording-format-labels.md`
- `docs/browser-recording-source-screenshot-count.md`
- `docs/browser-recording-index-metadata.md`
- `docs/browser-recording-index-ordering.md`
- `docs/browser-preview-multi-recording-actions.md`
- `frontend/src/lib/sessionModel.ts`
- `frontend/src/lib/eventStream.ts`
- `frontend/src/lib/browserRecording.ts`
- `frontend/src/lib/sessionSnapshot.ts`
- `frontend/src/components/BrowserPreview.tsx`
- `frontend/src/components/LiveTimeline.tsx`
- `frontend/src/App.css`
- `payswitch/engine/external_runner.py`
- `payswitch/server.py`
- `payswitch/cli.py`
- `tests/test_external_runner.py`
- `frontend/src/lib/sessionSnapshot.test.ts`
- `frontend/src/components/BrowserPreview.test.tsx`
- `docs/frontend-latest-session-fallback-removal.md`
- `docs/qr-artifact-persistence.md`
- `tests/test_ui_settings_api.py`
- `docs/evidence-image-format-parity.md`
- `tests/test_cli_artifact_handoff.py`
- `docs/artifact-inbox-rotation.md`
- Recovery patch storage and CLI now support governed batch promotion of ready patches, including basis filtering, dry-run preview, batch limits, and durable promotion audit metadata.
- Successful bounded recovery now also registers a durable recovery improvement queue item, and the CLI can list, inspect, accept, or dismiss those improver artifacts.
- Accepted recovery improvements can now be batch-processed into patch review progress, with dry-run preview and explicit `applied` closure for processed improvement items.
- Accepted recovery improvements can now run through a bounded background runner with one-cycle mode, idle-exit behavior, and reusable loop summaries.
- Accepted recovery improvements can now also run through a service-owned supervisor, with FastAPI lifecycle wiring and health-visible runtime state.
- Open recovery improvements can now be accepted through a governed basis gate, with CLI preview/execution and optional supervisor auto-accept.
- Ready recovery patches can now run through a service-owned promotion path, with bounded runner loops, CLI execution, and health-visible server supervision.
- Recovery patch readiness, ready-patch promotion, and open-improvement acceptance can now require a configurable minimum shadow-run count instead of assuming one successful shadow run is always enough.
- ArtifactStore now supports encrypted cross-host artifact handoff bundles, with CLI export/import commands and server-visible host inbox identity.

### Why

The dashboard could show the control plane while the real transaction browser was running in a separate or headless context, so users could not see or operate the actual payment page from noVNC. Browser `EventSource` also cannot attach the configured Bearer token, which prevented the WebUI from connecting to live events.

The previous mainline fallback stopped at a static external handoff when an adapter became stale. The earlier architecture had a runtime event stream and session-bound frontend, which are required for a web operator to see the live Computer Use loop after adapter failure.

Kimi's current homepage exposes membership purchase through an English `Upgrade your plan` control that opens an in-page membership surface. The previous adapter only looked for Chinese recharge/subscription text or URL changes, so it handed off before reaching the real offer surface.

Kimi's old `/recharge` path no longer represents the current purchase funnel. The working flow is the membership pricing page: monthly cycle, `Andante` at `¥49/month`, agreement prompt, then the combined Alipay/WeChat QR cashier. The adapter needs to follow that concrete path before invoking Computer Use fallback.

The agent HTTP service is an asynchronous control plane, so once the browser reaches a QR, OTP, CVV, or final-confirmation gate it must hand state back to the WebUI immediately. Blocking inside the orchestrator's terminal wait loop leaves the real browser visible but prevents `/tasks/{id}` and SSE from reflecting the human gate.

The hosted WebUI was requesting a latest-session snapshot before opening SSE. Without the FastAPI snapshot endpoints, it fell back to the built-in demo session, and human-gate events could still point at an internal `0.0.0.0` noVNC address that only makes sense from the server.

Persistent CloakBrowser sessions were saving profile files but reopening with a fresh random `--fingerprint` seed each time, which can make real sites treat saved cookies as a different browser environment.

The deployed agent already had a GitHub Models token for AI planning, but internal Computer Use only inspected `llm_api_key`; adapter failures therefore waited for external handoff instead of letting the model repair the checkout path. A separate standby browser service also kept a non-transaction window alive on the noVNC display, which made operators think the real checkout browser was stuck at `about:blank`.

The WebUI's approval modal was treating `human_gate` events as if they were agent action proposals. A QR scan gate already means Pay-Switch has stopped for the user to operate the visible noVNC page; showing approve/reject controls was misleading and posted to a method the server does not expose, which produced 405 errors.

Directly opening the hosted WebUI without `session_id` used the latest task as the only source of truth. With multiple users creating Kimi, Jimeng, or other payment runs, that made the panel appear to jump between unrelated tasks, and the shared noVNC desktop could show another operator's foreground or minimized browser.

The hosted WebUI could also create a synthetic `payswitch / CNY 1` session simply by opening the page. That placeholder had no real browser evidence, so selecting it left the preview in the waiting state and made the session switcher look broken.

The runtime hook still had a demo-oriented default session id. When the server had no live sessions, manual live-stream actions or a stale `session_id` URL could leave the operator looking at demo state instead of a clear "no real session" screen.

Kimi can expose login-required state inside the membership page or after the Subscribe click without redirecting to a login URL. The previous detection only covered URL/login prompt cases, so it could continue into payment-method selection while the page was actually waiting for account login.

Kimi also keeps hidden login templates in the page after a user is already signed in. The previous selector check counted hidden DOM nodes and started from the pricing URL, so a valid session could look logged out and operators could not see the homepage-to-subscription flow.

Scan-QR states are intentionally the end of Pay-Switch automation, but the dashboard still used "waiting" wording. That made a correctly handed-off payment look like an unfinished automation run.

The next Pay-Switch architecture needed a concrete engineering contract before implementation: one-user workspace isolation, adapter speed preservation, Agent recovery, profile promotion, display-focus safety, noVNC routing, E2EE artifact handling, cleanup, and cost controls had to be captured in one reviewable source of truth.

The architecture documents also needed an implementation bridge for the team: what the current code already satisfies, what remains transitional, which workstreams must come next, and how reviewers should reject changes that drift back to shared display, global latest-session, unscoped noVNC, or unreviewed recipe-patch behavior.

The latest main branch added PayAgent packaging files that were not yet compatible with the CI Ruff command used across all supported Python versions, blocking follow-up PRs from merging cleanly.

The latest main branch also made display human-notification awaitable in the orchestrator path, but one older local desktop integration test still used a synchronous mock. That made the GitHub Python matrix fail before it could validate frontend-only PRs.

The roadmap's first milestone required durable session truth before any real runtime/container isolation work. The previous control plane still kept authoritative session state in memory and let frontend read paths fall back to a global latest-session model, which is not compatible with user-scoped workspaces.

Even after the session sidebar and explicit selected-session flow landed, the frontend snapshot helper still preserved one `/api/sessions/latest` fallback path whenever only `userId` was present. That kept one implicit latest-session dependency alive inside the hosted WebUI runtime path.

Bounded Computer Use entry, stale-context classification, and synchronous policy checkpoints were already in place, but the action loop itself still trusted every model-produced click/fill once recovery had started. That left hybrid mode able to fall through to external continuation even when the page had already drifted into a login wall or a payment-confirmation surface.

The checkpoint contract also remained too narrow: only Kimi's recipe-backed flow used it. DeepSeek already had built-in recipe metadata and stable helper actions, so keeping it on a purely imperative confirm path left one of the main first-party top-up routes outside the shared checkpoint and outcome-recording model.

The next roadmap board required an explicit user-scoped runtime boundary before real container isolation. The server still only had logical workspace locks, so there was no typed runtime lifecycle, no workspace health surface, and no admission control to stop one-node deployments from over-allocating user runtimes.

The next roadmap board required real session-to-display ownership. Even with durable sessions and user-scoped runtimes, the frontend could still infer browser visibility from raw event `display_url` fields, which let a selected session appear to own a shared noVNC surface it did not actually control.

The next two roadmap boards also needed explicit backend contracts. Without a workspace container driver, the new container runtime path stayed as a test-only skeleton. Without a display-route registry, a valid display token still resolved to a generic noVNC page rather than a revocable runtime-owned route.

The stale-context slice was in place, but the recovery path still treated most `ScriptExecutionError` failures alike. That left login-expired sessions and terminal configuration failures on the same fallback branch as ordinary page drift.

Computer Use recovery also still depended on implicit limits from Skyvern defaults. There was no explicit recovery budget contract, and hybrid timeout failures could disappear once the flow fell through to external Computer Use handoff.

The next roadmap board required profile safety. `profile_id` existed, but there was still no durable stable/task vault lifecycle, no rollback on promotion failure, and no fail-closed compatibility gate to stop browser-engine or schema drift from corrupting a reused stable profile.

The next roadmap board required a real fast adapter path. Kimi and future learned adapters needed a recipe runner, durable outcome tracking, and a candidate/shadow-run promotion lifecycle so checkout knowledge can evolve without rewriting the orchestrator or promoting unreviewed recovery output into mainline automation.

The next Milestone 6 slice still had a gap after recovery succeeded: candidate patches existed, but the system was not persisting the successful recovery evidence that a reviewer would need, and there was no operator review surface for candidate promotion decisions.

The next recovery-governance gap was that `synchronous_policy_checkpoint` only existed as a Watchdog classification concept. Recipe-backed adapters still lacked a shared way to stop synchronously before a risky confirm/payment-surface action.

That same gap still existed in the legacy imperative browser adapters. Even after the Kimi and DeepSeek recipe work, Qwen, Jimeng, Volcano, and NineEmail could still click their final pay/confirm controls directly once a selector matched, without a shared visible-surface checkpoint or structured audit context.

After the checkpoint retrofit, Qwen was still outside the shared recipe runner and outcome model. That left one core top-up path unable to emit semantic waypoint telemetry or durable recipe outcomes, even though its confirm transition was already treated as a high-risk checkpoint boundary.

Volcano still had the same gap: the high-risk confirm guard existed, but the top-up path itself was still an imperative sequence with no shared waypoint telemetry or durable recipe outcome record.

Jimeng had the same structural gap. The path already failed closed on the final checkout click, but the adapter still had no semantic checkout-entry waypoint or durable recipe outcome contract.

NineEmail had the same gap on the product-purchase side. The path already failed closed on `立即支付`, but there was still no semantic order-form or submit-order waypoint model and no durable recipe outcome record.

The earlier stale-context slice only discarded the old watchdog buffer and annotated checkpoint evidence. Recovery could still continue with an expired failure reason and without a fresh page snapshot handed into Computer Use.

The recovery patch lifecycle also still had a gap: a bounded recovery could prove a patch on the very run that created it, but the store still left that patch in raw `candidate` state until someone manually marked `shadow_run`.

Even after auto shadow-run, reviewers still had to infer promotion readiness from raw patch state and metadata. There was no direct control-plane queue that answered "what can I promote right now?".

Even with queue visibility, promotion was still one patch at a time. Operators
could see which patches were ready, but they still lacked a governed batch path
that preserved readiness basis and promotion audit metadata.

Even after governed acceptance and service-owned promotion existed, both paths
still treated one successful shadow pass as a universal threshold. That made
noisier flows impossible to harden without forking queue logic or bypassing the
service-owned control plane.

Local artifact encryption and retention were already in place, but evidence
still had no governed host-to-host transfer path. Operators had to move files
manually, which broke provenance and bypassed the artifact store contract.

### Impact

Adaptive promotion policy is now durable and visible instead of implicit:

- queue entries expose `shadow_run_count` and exact threshold blockers;
- CLI operators can preview or execute with `--min-shadow-runs`;
- service-owned improver and promoter loops expose `min_shadow_runs` in health
  and enforce the same threshold as the store.
- Artifact handoff can now stay inside the encrypted artifact contract across
  hosts, with source provenance preserved on import.

### Verification

- `ruff check payswitch/experience/store.py payswitch/experience/promoter.py payswitch/experience/improver.py payswitch/server.py payswitch/cli.py tests/test_experience_store.py tests/test_experience_promoter.py tests/test_experience_improver.py tests/test_cli_experience.py tests/test_server_recovery_patch_promoter.py tests/test_server_recovery_improver.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_experience_promoter.py tests/test_experience_improver.py tests/test_cli_experience.py tests/test_server_recovery_patch_promoter.py tests/test_server_recovery_improver.py -q`
- `ruff check payswitch/security/artifacts.py payswitch/cli.py payswitch/server.py tests/test_artifact_store.py tests/test_cli_artifact_handoff.py tests/test_server_artifact_inbox.py`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_cli_artifact_handoff.py tests/test_server_artifact_inbox.py -q`
- `.venv/bin/python -m pytest tests/test_artifact_inventory.py tests/test_server_artifact_inventory.py tests/test_cli_artifact_stats.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py tests/test_artifact_budget_enforcement.py tests/test_server_artifact_budget_enforcement.py tests/test_cli_artifact_budget_enforcement.py -q`

### Files

- `payswitch/experience/store.py`
- `payswitch/experience/promoter.py`
- `payswitch/experience/improver.py`
- `payswitch/server.py`
- `payswitch/cli.py`
- `tests/test_experience_store.py`
- `tests/test_experience_promoter.py`
- `tests/test_experience_improver.py`
- `tests/test_cli_experience.py`
- `tests/test_server_recovery_patch_promoter.py`
- `tests/test_server_recovery_improver.py`
- `payswitch/security/artifacts.py`
- `payswitch/cli.py`
- `payswitch/server.py`
- `tests/test_artifact_store.py`
- `tests/test_cli_artifact_handoff.py`
- `tests/test_server_artifact_inbox.py`

Successful recovery also still ended at a disk artifact plus patch metadata. The
system had no durable queue for operators to triage improvement candidates as
accepted or dismissed work items.

After that queue existed, accepted improvements still had no deterministic path
to advance patch governance. Operators could mark an improvement accepted, but
the patch lifecycle still had to be nudged forward by hand.

After the accepted-queue processor existed, there was still no bounded
background execution contract. Improvement processing still depended on
one-shot operator invocation instead of a reusable polling loop.

After the bounded runner existed, there was still no server-owned supervision
contract. Accepted improvements could be looped from the CLI, but the service
itself had no lifecycle-owned improver path or health-visible execution state.

After service-owned supervision existed, there was still a manual gap at the
front of the queue: successful recovery artifacts stayed `open` until somebody
accepted them one by one, even when the linked patch already satisfied a stable
governance basis.

After governed acceptance existed, there was still a second operational gap:
promotion into `mainline` still depended on one-shot operator commands even
when patches were already ready under the existing promotion contract.

### Impact

- Operators opening the deployed WebUI can see the live noVNC checkout surface and take over the transaction when Pay-Switch reaches a human authorization gate.
- External Computer Use steps can reuse the visible browser for the same transaction instead of repeatedly closing the page.
- Pay-Switch can resume after the user confirms an ambiguous checkout decision, while still stopping before final payment authorization.
- Operators can open the frontend with `?session_id=<tx_id>` and watch the actual Pay-Switch route, browser actions, detections, human gates, and ledger completion events for that transaction.
- The BrowserPreview panel now shows the real page screenshot after `observe` and switches to the noVNC takeover surface when a human gate is waiting.
- Operators can open `?view=settings` to configure the same browser/profile and Computer Use controls that previously required CLI-only commands.
- Real-account checkout runs no longer have to choose between a profile mirror and Playwright's exclusive persistent-context launch when the desired browser profile is already bound.
- Operators can isolate all project payment logins in one persistent Pay-Switch browser profile, then let CDP operate that profile consistently.
- Operators no longer need to remember the profile startup CLI during normal WebUI use; the settings page can create/bind the profile and start Chrome.
- Operators need to see the live checkout conversation even when they open the UI after a transaction has already reached login, plan selection, QR, or final payment confirmation.
- Teams evaluating CloakBrowser can now see whether Pay-Switch is launching a CloakBrowser process or only attaching to an existing Chrome/CDP process.
- `/events` becomes a read-only browser-consumable stream; payment creation and A2A mutation APIs remain authenticated.
- Kimi runs can move from the logged-in homepage into the visible membership offer surface before plan/payment selection.
- Kimi's cheapest monthly membership flow can now reach the real QR cashier in the managed browser, where Pay-Switch pauses for the user to scan and authorize payment.
- The WebUI and agent callers now see `input-required` for a waiting QR transaction while the service-owned browser stays open for noVNC takeover.
- Opening the WebUI without a `session_id` now hydrates the latest real server task instead of showing the demo control-plane session, and the embedded noVNC frame receives a browser-reachable URL.
- Session switching in the WebUI now has a server-side ownership check behind it: selecting a session can yield a scoped display route, an explicit foreground-wait reason, or a no-runtime/adapter-unavailable state instead of a misleading black box.
- Visible browser actions now have a verification path that can deny Computer Use when another session owns the workspace foreground lease.
- Kimi and other Pay-Switch-managed CloakBrowser logins are less likely to fall back to a login gate immediately after a saved profile is reopened.
- Deployed hybrid Computer Use can use the same GitHub/OpenAI-compatible model provider that powers payment planning, without duplicating the secret into `config.json`.
- noVNC shows the real checkout browser when a transaction opens instead of a long-running standby browser window.
- Kimi QR sessions no longer show a misleading "批准执行" modal over the control plane; the operator should use the embedded noVNC panel or its open-window link to scan or confirm payment.
- Operators can see every in-memory session from the hosted WebUI, select the intended Kimi/Jimeng task, and avoid confusing another user's shared noVNC desktop for the selected session.
- Opening `/pay-switch` with no real payment tasks stays empty instead of creating a fake CNY 1 dashboard session; only REST/A2A-created payment sessions appear in the sidebar.
- Operators now get a clear empty runtime panel until a real session is selected or created, so demo state cannot be mistaken for an active server task.
- The hosted frontend now refuses to resolve a single-session snapshot without an explicit `session_id`, which keeps runtime hydration consistent with the selected-session sidebar instead of silently following a user-scoped latest-session fallback.
- BrowserPreview quick actions now expose the full newest-event recording set in `recording_index` order, so operators can inspect multiple archived recordings without leaving the main preview surface.
- Kimi runs now stop at a clear login human gate when the account is not authenticated, instead of stalling at the later Alipay selector step.
- Kimi operators can now see the run start from the real homepage and avoid false login gates caused by hidden login DOM nodes.
- Operators now see scan and final-confirmation gates as "handed off to user" instead of an apparently still-running automated step.
- Engineers now have a validated implementation guide for the upcoming user-workspace/subagent/runtime isolation work, including diagrams, data/API contracts, test standards, and Definition of Done gates.
- Teams now have a concrete roadmap and review standard for keeping implementation aligned with the agreed framework before adding more checkout sites or UI polish.
- README readers can find the architecture source of truth without digging through PR history or prior discussions.
- Follow-up PRs based on current main can pass the repository-wide Ruff gate instead of failing before tests run.
- Branches based on the latest main no longer fail Ruff before reaching functional test coverage.
- The GitHub Python matrix can run the local desktop login-preflight regression without a mock awaitability failure.
- Session list, snapshot, transaction lookup, and replay now survive process restarts because they are backed by the durable store instead of transient in-memory task objects.
- Operators opening the WebUI with `?user_id=<id>` now stay inside their own session scope for snapshots, event streams, and sidebar session management instead of accidentally hydrating another user's latest run.
- `/api/workspaces` and `/api/subagents` can still render durable control-plane state after an in-process workspace manager reset, which is the required bridge before runtime ownership itself becomes durable.
- Reviewers can now preview and promote multiple ready recovery patches in one governed batch without bypassing readiness checks, and every promoted patch records who promoted it and why it was eligible.
- Operators can now treat successful recovery output as a durable triage queue instead of hunting JSON artifacts by hand, and accepted or dismissed decisions are now persisted with reviewer metadata.
- Accepted recovery improvements can now advance linked patches into `reviewed` through a deterministic processor, while the improvement queue itself closes out processed items as `applied`.
- Teams can now run accepted recovery improvements through a bounded background runner, which provides a stable bridge from manual queue triage to future service-owned improver supervision.
- Server deployments can now own that accepted-improvement supervision path directly, with explicit lifecycle start/stop and health-visible supervisor telemetry.
- Operators and server-owned supervisors can now accept eligible `open` improvements through a deterministic basis gate instead of manually flipping every queue item before processing starts.
- Operators and server deployments can now promote ready recovery patches through the same bounded governance surface instead of relying on one-shot `promote-ready` invocations only.
- Runtime health now shows whether a user workspace is active, warm, sleeping, or reclaimed, and whether admission is currently blocked by active-workspace or memory pressure.
- A completed user workspace can sleep or be reclaimed without deleting its logical workspace identity, which gives the next runtime-isolation phase a clean lifecycle contract to build on.
- When the live runtime registry is reset, workspace and subagent API responses now degrade to explicit `offline` / `no_runtime` state instead of silently pretending a display surface still exists.
- Operators and reviewers can now see a stable `display_route_id`, expiry, and `novnc_route_key` in session snapshots and redirects instead of treating display ownership as an implicit side effect of the latest noVNC URL.
- A stale display token now dies at the registry boundary as soon as another session takes over the same workspace surface, instead of continuing to resolve against a generic shared viewer endpoint.
- Server deployments can now opt into a container-backed user workspace runtime through environment configuration while preserving the same admission, session, and display APIs.
- Control-plane and future WebUI layers can now reason about a concrete runtime-local browser ownership contract instead of only a loose `display_ready` flag.
- Visible-action guardrails now fail closed on browser-context mismatch, foreground-lease drift, and in-flight focus-lock re-entry before a foreground action can proceed.
- Recovery review can now distinguish fresh context from stale context before Computer Use or human recovery continues, which reduces the chance of acting on expired screenshots/DOM assumptions.
- Operators and reviewers can now see why script recovery stopped: login-tagged failures route to the login gate, hard failures fail closed to manual recovery, and retryable drift remains eligible for Computer Use.
- Operators and reviewers can now see the bounded recovery envelope and whether internal Computer Use hit its wall-time budget before external handoff took over.
- Successful human-gate and completed runs can now persist login-state changes through an audited promotion step, while failed runs discard task-profile mutations and leave the stable profile untouched.
- Operators and reviewers can now inspect profile lifecycle state directly from session and workspace APIs instead of guessing whether a run reused a safe stable profile or a dirty task copy.
- Kimi's fastest supported membership flow is now described in recipe data instead of imperative orchestrator logic, so adapter maintenance can update waypoints without reshaping the global payment engine.
- Waypoint failures now carry screenshot, DOM summary, visible text summary, and failed assertion data, which gives the upcoming Watchdog/Computer Use boards the evidence they need without slowing the success path.
- Recovery-derived recipe candidates now have a durable gate before they affect mainline automation, which reduces the chance of a single bad recovery mutating the stable checkout flow for all users.
- Successful recovery output is now reviewable instead of opaque: operators can inspect the patch candidate, mark it reviewed or shadow-validated, and only then promote it into the mainline recipe.
- The current recipe-backed fast path now has an auditable synchronous stop point before Kimi's confirm-to-payment transition, while still leaving room to retrofit older imperative adapters later.
- Legacy imperative browser adapters now fail closed before their final checkout click if the visible payment surface has drifted, and script-mode human recovery can surface the exact checkpoint metadata that blocked the action.
- Qwen now sits on the same fast-path governance model as Kimi and DeepSeek: semantic waypoints, runner-level synchronous checkpointing, and durable recipe outcomes.
- Volcano now sits on that same fast-path governance model for its recharge flow, including a semantic continue-to-payment waypoint and a durable outcome record for the payment-gate handoff.
- Jimeng now sits on that same fast-path governance model for its purchase flow, including a semantic checkout-entry waypoint and a durable outcome record for the payment-gate handoff.
- NineEmail now sits on that same fast-path governance model for its product purchase flow, including semantic order-form and submit-order waypoints and a durable outcome record for the QR handoff.
- Stale script failures now rebuild a fresh recovery snapshot before Computer Use continues, which makes the recovery prompt and later audit materially more trustworthy on changed pages.
- Successful bounded recovery now leaves the experience store in a stronger lifecycle state: the patch is automatically validated as `shadow_run`, but mainline safety still stays manual.
- Reviewers can now ask the CLI for a promotion queue and get explicit readiness or blocking reasons instead of reverse-engineering patch lifecycle state.

### Verification

- `git diff --check`
- `uv run --extra dev ruff check payswitch/browser/cdp_attach.py payswitch/browser/runtime.py payswitch/browser/chrome_profiles.py payswitch/engine/external_runner.py payswitch/cli.py tests/test_cdp_attach.py tests/test_browser_runtime.py tests/test_chrome_profiles.py tests/test_external_runner.py tests/test_runtime_events.py tests/test_ui_settings_api.py`
- `uv run --extra dev pytest tests/test_chrome_profiles.py tests/test_cdp_attach.py tests/test_browser_runtime.py tests/test_runtime_events.py tests/test_external_runner.py tests/test_ui_settings_api.py -q`
- `uv run python -m compileall -q payswitch/browser/cdp_attach.py payswitch/browser/runtime.py payswitch/browser/chrome_profiles.py payswitch/engine/external_runner.py payswitch/engine/events.py payswitch/cli.py`
- `npm test --prefix frontend -- --run src/lib/eventStream.test.ts src/lib/sessionSnapshot.test.ts src/lib/settingsApi.test.ts src/hooks/useCheckoutSession.test.tsx`
- `npm test --prefix frontend -- --run src/components/HumanGateModal.test.tsx`
- `uv run --extra dev pytest tests/test_server_public_urls.py -q`
- `npm run build --prefix frontend`
- `pytest tests/test_browser_engines.py -q`
- `pytest tests/test_skyvern.py tests/test_models.py::TestComputerUseConfigDefaults -q`
- `uv run --extra dev pytest tests/test_integration.py::TestScenario1_LocalDesktopScriptMode::test_访问预检检测未登录后等待人工登录超时 -q`
- `uv run --extra dev ruff check payswitch/adapters/kimi.py tests/test_adapters.py`
- `uv run --extra dev pytest tests/test_adapters.py::TestKimiAdapter -q`
- `.venv/bin/python -m pytest tests/test_adapters.py -q`
- `uv run --extra dev pytest -q tests/test_session_store.py tests/test_server_public_urls.py tests/test_server_streaming_harness.py tests/test_server_subagents.py tests/test_secret_envelope.py`
- `uv run --extra dev ruff check payswitch/session_store.py payswitch/server.py tests/test_session_store.py tests/test_server_public_urls.py tests/test_server_streaming_harness.py tests/test_secret_envelope.py`
- `npm test --prefix frontend -- --run src/lib/eventStream.test.ts src/lib/sessionSnapshot.test.ts src/hooks/useCheckoutSession.test.tsx`
- `npm run build --prefix frontend`
- `uv run --extra dev pytest -q tests/test_agent_workspace.py tests/test_agent_workspace_harness.py tests/test_workspace_runtime.py tests/test_server_public_urls.py tests/test_server_subagents.py`
- `ruff check payswitch/experience/store.py payswitch/engine/orchestrator.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`
- `.venv/bin/python -m compileall payswitch/experience/store.py payswitch/engine/orchestrator.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`
- `ruff check payswitch/experience/models.py payswitch/experience/runner.py payswitch/experience/registry.py payswitch/adapters/kimi.py tests/test_experience_runner.py tests/test_adapters.py tests/test_recovery_watchdog.py`
- `.venv/bin/python -m pytest tests/test_experience_runner.py tests/test_adapters.py tests/test_recovery_watchdog.py`
- `ruff check payswitch/adapters/base.py payswitch/adapters/qwen.py payswitch/adapters/jimeng.py payswitch/adapters/volcano.py payswitch/adapters/nineemail.py payswitch/engine/orchestrator.py tests/test_adapters.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_adapters.py tests/test_integration.py`
- `ruff check payswitch/adapters/qwen.py payswitch/experience/registry.py tests/test_adapters.py`
- `.venv/bin/python -m pytest tests/test_adapters.py`
- `ruff check payswitch/adapters/volcano.py payswitch/experience/registry.py tests/test_adapters.py`
- `.venv/bin/python -m pytest tests/test_adapters.py`
- `ruff check payswitch/adapters/jimeng.py payswitch/experience/registry.py tests/test_adapters.py`
- `.venv/bin/python -m pytest tests/test_adapters.py`
- `ruff check payswitch/adapters/nineemail.py payswitch/experience/registry.py tests/test_adapters.py`
- `.venv/bin/python -m pytest tests/test_adapters.py`
- `ruff check payswitch/browser/computer_use.py payswitch/engine/orchestrator.py tests/test_computer_use.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_computer_use.py tests/test_integration.py`
- `ruff check payswitch/engine/orchestrator.py tests/test_integration.py tests/test_experience_store.py`
- `.venv/bin/python -m pytest tests/test_integration.py tests/test_experience_store.py`
- `ruff check payswitch/experience/store.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py`
- `ruff check payswitch/experience/models.py payswitch/experience/store.py payswitch/engine/orchestrator.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`
- `ruff check payswitch/experience/models.py payswitch/experience/store.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py`
- `ruff check payswitch/experience/store.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py`
- `uv run --extra dev pytest -q tests/test_session_store.py tests/test_server_streaming_harness.py tests/test_secret_envelope.py tests/test_agent_health.py`
- `uv run --extra dev ruff check payswitch/agent_workspace.py payswitch/workspace_runtime.py payswitch/server.py tests/test_agent_workspace.py tests/test_agent_workspace_harness.py tests/test_workspace_runtime.py tests/test_server_public_urls.py tests/test_server_subagents.py`
- `uv run --extra dev pytest -q tests/test_agent_workspace.py tests/test_agent_workspace_harness.py tests/test_workspace_runtime.py tests/test_server_public_urls.py`
- `uv run --extra dev pytest -q tests/test_session_store.py tests/test_server_streaming_harness.py tests/test_server_subagents.py tests/test_secret_envelope.py tests/test_agent_health.py`
- `uv run --extra dev ruff check payswitch/agent_workspace.py payswitch/workspace_runtime.py payswitch/server.py tests/test_agent_workspace.py tests/test_server_public_urls.py`
- `npm test --prefix frontend -- --run src/lib/sessionSnapshot.test.ts src/components/BrowserPreview.test.tsx src/hooks/useCheckoutSession.test.tsx src/components/HumanGateModal.test.tsx`
- `npm run build --prefix frontend`
- `npm test`
- `.venv/bin/python -m pytest tests/test_server_public_urls.py tests/test_agent_workspace.py`
- `uv run --extra dev ruff check payswitch/profile_manager.py payswitch/agent_workspace.py payswitch/server.py tests/test_profile_manager.py tests/test_agent_workspace.py tests/test_server_public_urls.py`
- `uv run --extra dev pytest -q tests/test_profile_manager.py tests/test_agent_workspace.py tests/test_server_public_urls.py`
- `uv run --extra dev pytest -q tests/test_workspace_runtime.py tests/test_session_store.py tests/test_server_streaming_harness.py tests/test_server_subagents.py tests/test_secret_envelope.py tests/test_agent_health.py tests/test_agent_workspace_harness.py`
- `.venv/bin/python -m pytest tests/test_workspace_runtime.py tests/test_agent_workspace.py tests/test_agent_workspace_harness.py tests/test_server_workspace_runtime_config.py tests/test_server_public_urls.py tests/test_server_streaming_harness.py tests/test_server_subagents.py`
- `.venv/bin/python -m compileall payswitch/workspace_container_driver.py payswitch/display_route_registry.py payswitch/workspace_runtime.py payswitch/agent_workspace.py payswitch/server.py tests/test_workspace_runtime.py tests/test_agent_workspace.py tests/test_server_public_urls.py tests/test_server_workspace_runtime_config.py`
- `.venv/bin/python -m compileall payswitch/browser/manager.py payswitch/workspace_runtime.py payswitch/agent_workspace.py payswitch/server.py tests/test_browser_manager.py tests/test_workspace_runtime.py tests/test_agent_workspace.py tests/test_server_public_urls.py`
- `.venv/bin/python -m pytest tests/test_browser_manager.py tests/test_workspace_runtime.py tests/test_agent_workspace.py tests/test_server_public_urls.py`
- `.venv/bin/python -m pytest tests/test_workspace_runtime.py tests/test_agent_workspace.py tests/test_agent_workspace_harness.py tests/test_server_workspace_runtime_config.py tests/test_server_public_urls.py tests/test_server_streaming_harness.py tests/test_server_subagents.py tests/test_browser_manager.py`
- `ruff check payswitch/engine/watchdog.py payswitch/engine/orchestrator.py payswitch/models/config.py tests/test_recovery_watchdog.py tests/test_models.py`
- `.venv/bin/python -m pytest tests/test_recovery_watchdog.py tests/test_models.py`
- `.venv/bin/python -m pytest tests/test_integration.py -k "watchdog or recovery"`
- `uv run --extra dev ruff check payswitch/experience payswitch/adapters/kimi.py payswitch/adapters/base.py payswitch/engine/orchestrator.py tests/test_experience_store.py tests/test_experience_runner.py tests/test_adapters.py tests/test_integration.py`
- `uv run --extra dev pytest -q tests/test_experience_store.py tests/test_experience_runner.py tests/test_adapters.py tests/test_integration.py`
- `uv run --extra dev ruff check .`
- `ruff check .`
- Remote service-owned Kimi test: `POST /api/payments` for `49 CNY` reached `input-required` with `qr_type=canvas` and noVNC showing `Subscribe Andante` / `Pay with Alipay / WeChat ¥49`.
- FastAPI session snapshot tests cover latest-session hydration, transaction-id lookup, and public noVNC URL rewriting for human-gate snapshots.
- Mermaid CLI rendered the three Agent Workspace Framework diagrams successfully.
- Gemini reviewed the architecture document twice; the final pass returned `PASS` after the diagram routing and profile-promotion rollback criteria were corrected.
- Gemini completed a final re-review of the optimized architecture, roadmap, and subagent harness documents; the final verdict was `PASS`, approving the docs as comprehensive, implementable, and verifiable.

### Files

- `payswitch/browser/cdp_attach.py`
- `payswitch/browser/chrome_profiles.py`
- `payswitch/browser/runtime.py`
- `payswitch/browser/engines/cloakbrowser_engine.py`
- `plugins/pay-switch-agent/install.py`
- `tests/test_mcp_server.py`
- `payswitch/cli.py`
- `payswitch/engine/events.py`
- `payswitch/engine/external_runner.py`
- `payswitch/engine/orchestrator.py`
- `payswitch/experience/__init__.py`
- `payswitch/experience/models.py`
- `payswitch/experience/registry.py`
- `payswitch/experience/store.py`
- `tests/test_experience_store.py`
- `tests/test_cli_experience.py`
- `docs/recovery-patch-ready-promotion.md`
- `payswitch/experience/models.py`
- `payswitch/engine/orchestrator.py`
- `docs/recovery-improvement-queue.md`
- `docs/recovery-improvement-processor.md`
- `payswitch/experience/runner.py`
- `payswitch/experience/store.py`
- `payswitch/models/config.py`
- `payswitch/models/types.py`
- `payswitch/profile_manager.py`
- `payswitch/browser/skyvern.py`
- `scripts/install_live_computer_service.sh`
- `tests/test_skyvern.py`
- `payswitch/adapters/base.py`
- `payswitch/adapters/jimeng.py`
- `payswitch/adapters/kimi.py`
- `payswitch/adapters/nineemail.py`
- `payswitch/adapters/qwen.py`
- `payswitch/adapters/volcano.py`
- `tests/test_adapters.py`
- `docs/qwen-recipe-migration.md`
- `docs/volcano-recipe-migration.md`
- `docs/jimeng-recipe-migration.md`
- `docs/nineemail-recipe-migration.md`
- `docs/stale-context-resynchronization.md`
- `docs/recovery-patch-auto-shadow-run.md`
- `docs/recovery-patch-promotion-queue.md`
- `tests/test_experience_runner.py`
- `tests/test_experience_store.py`
- `payswitch/cli.py`
- `payswitch/browser/manager.py`
- `payswitch/workspace_runtime.py`
- `payswitch/agent_workspace.py`
- `payswitch/server.py`
- `tests/test_browser_manager.py`
- `tests/test_workspace_runtime.py`
- `tests/test_agent_workspace.py`
- `tests/test_server_public_urls.py`
- `tests/test_cli_experience.py`
- `tests/test_experience_runner.py`
- `docs/browser-display-ownership.md`
- `docs/imperative-adapter-synchronous-policy-checkpoints.md`
- `docs/recovery-recipe-patch-review.md`
- `docs/synchronous-policy-checkpoints.md`
- `payswitch/engine/watchdog.py`
- `payswitch/engine/orchestrator.py`
- `payswitch/models/config.py`
- `tests/test_recovery_watchdog.py`
- `tests/test_models.py`
- `docs/watchdog-stale-context.md`
- `README.md`
- `frontend/src/App.tsx`
- `frontend/src/App.css`
- `frontend/src/components/BrowserPreview.tsx`
- `frontend/src/components/BrowserPreview.test.tsx`
- `frontend/src/components/HumanGateModal.tsx`
- `frontend/src/components/HumanGateModal.test.tsx`
- `frontend/src/components/SessionSidebar.tsx`
- `frontend/src/components/SettingsPanel.tsx`
- `frontend/src/hooks/usePaySwitchSettings.ts`
- `frontend/src/hooks/useCheckoutSession.ts`
- `frontend/src/hooks/useSessionList.ts`
- `frontend/src/lib/eventStream.ts`
- `frontend/src/lib/eventStream.test.ts`
- `frontend/src/lib/sessionSnapshot.ts`
- `frontend/src/lib/sessionSnapshot.test.ts`
- `frontend/src/lib/settingsApi.ts`
- `frontend/src/lib/settingsApi.test.ts`
- `frontend/src/lib/sessionModel.ts`
- `README.md`
- `docs/agent-workspace-framework.md`
- `docs/framework-alignment-roadmap.md`
- `docs/session-display-ownership.md`
- `docs/subagent-harness-architecture.md`
- `tests/test_browser_runtime.py`
- `tests/test_cdp_attach.py`
- `tests/test_chrome_profiles.py`
- `tests/test_runtime_events.py`
- `tests/test_ui_settings_api.py`
- `tests/test_integration.py`
- `payswitch/agent_workspace.py`
- `payswitch/workspace_runtime.py`
- `payswitch/workspace_container_driver.py`
- `payswitch/display_route_registry.py`
- `tests/test_agent_workspace.py`
- `tests/test_agent_workspace_harness.py`
- `tests/test_workspace_runtime.py`
- `tests/test_server_workspace_runtime_config.py`
- `payswitch/session_store.py`
- `tests/test_session_store.py`
- `tests/test_profile_manager.py`
- `tests/test_server_public_urls.py`
- `docs/agent-workspace-framework.md`

## [0.3.0] - 2026-05-12

### What changed

- Added optional CloakBrowser browser engine (`pip install 'payswitch[cloak]'`). Default remains native Playwright; opt-in via `payswitch config browser_engine cloakbrowser`. Designed for overseas payment pages that fingerprint-detect or Cloudflare Turnstile-gate native Playwright.
- Added `browser_engine`, `browser_humanize`, `browser_human_preset` config keys. `humanize=True` turns on bezier mouse curves + human-like keyboard timing (CloakBrowser only).
- `BrowserController.launch()` now reads engine/humanize/human_preset from `PaySwitchConfig.load()` when the caller does not pass them explicitly, so `payswitch config browser_engine cloakbrowser` takes effect for every downstream call site (orchestrator, external_runner, CLI `login`, CLI `browser-lite`) without touching those call sites. Explicit kwargs still override config. Failure to load config falls back safely to `playwright` + `humanize=False`.
- Added `payswitch/browser/engines/` abstraction layer with a `BrowserEngine` protocol, `PlaywrightEngine` (default, backwards-compatible) and `CloakBrowserEngine` (opt-in).
- Added `docs/browser-engines.md` with comparison table, when-to-switch guidance, risks, Docker notes, and troubleshooting.
- Added 23 new tests covering engine factory, protocol compliance, config validation, CloakBrowser's missing-dep friendly error, and controller.launch() config readback (explicit-overrides-config, stateless path, config-load-failure safe default). Test count: 255 → 278.
- Fixed CLI `config <key> <value>` so that Pydantic validator rejections (e.g. `browser_engine=firefox`) are surfaced as friendly errors instead of a traceback.

## [0.2.0] - 2026-05-11

### What changed

- Added Stripe payment channel adapter for international credit/debit card payments via Stripe hosted checkout.
- Added FastAPI-based Stripe webhook listener to receive payment completion events and update transaction status asynchronously.
- Added Stripe configuration fields (`stripe_secret_key`, `stripe_webhook_secret`, `stripe_webhook_port`, `stripe_default_currency`) in PaySwitchConfig with base64 encoding for secure storage.
- Added orchestrator logic to handle Stripe payments without browser automation (API-only flow).
- Added CLI commands: `payswitch settings stripe` for configuration wizard, `payswitch stripe listen` to start webhook server.
- Added `PaymentMethod.stripe` enum value and support for `--method stripe` in spend command.
- Added comprehensive test suite for Stripe adapter with mocked Stripe API calls and webhook event handling (14 new tests).
- Rolled `stripe`, `fastapi`, `uvicorn`, and `httpx` into the dev extras so `uv run --extra dev pytest` works out of the box.

## [0.1.0] - 2026-05-10

### What changed

- Added controlled Computer Use policy primitives for checkout step categories, risk gates, and external/internal/hybrid driver selection.
- Added user Chrome context support so Pay-Switch can bind to a real Chrome User Data directory, profile directory, expected email, or existing CDP browser.
- Added a NineEmail Alipay checkout adapter for end-to-end QR handoff testing.
- Added an external checkout runner so a caller agent can drive browser actions while Pay-Switch enforces guardrails and human gates.
- Added a dated checkout control-plane roadmap for adapter, skill-memory, Computer Use fallback, notification, and audit flows.
- Added interactive CLI settings for discovering Chrome profiles, binding a profile by email/name/directory, and configuring Computer Use driver mode.
- Added a guided `payswitch settings wizard` onboarding flow that asks for browser first, then lists local profiles for selection, then configures Computer Use.
- Improved the settings wizard with beginner-friendly explanations for browser choice, profile identity, Computer Use driver modes, and autonomous checkout boundaries.
- Aligned the main `spend` fallback path with the configured Computer Use driver: adapter failures and unknown sites now enter `external` Computer Use handoff before human takeover.
- Persisted execution mode during status updates so external Computer Use handoff can be recovered from the ledger.
- Added `payswitch external-act` so an external Agent can submit one governed Computer Use action at a time against an existing transaction.
- Persisted external Computer Use page evidence so each action can resume from the last known browser URL instead of restarting exploration from a blank context.
- Upgraded external `observe` into a real perception handoff with screenshot evidence, clickables, visible inputs/forms, page title, viewport, and visible text summaries.
- Tightened payment completion detection to avoid treating Stripe checkout form elements such as autocomplete widgets as successful payments.
- Documented the Payment Capability Router in the README, including the protocol-first flow from official connectors to adapters, experience recipes, external Computer Use, and human gates.
- Added an explicit access preflight step before adapter/fallback execution so login-required sites fail early with a concrete `payswitch login <platform>` instruction.
- Hardened Kimi login detection to treat both Chinese and English "log in to sync chat history" prompts as unauthenticated state.
- Added a formal checkout intent and plan-selection contract so Payswitch must resolve login, user purchase intent, real offer matrix, and ambiguous plan choices before clicking any pay or subscribe control.
- Updated the README checkout flow to make intent resolution, offer discovery, and plan confirmation mandatory stages ahead of capability routing and payment.
- Added a lightweight experience-recipe registry and promoted the validated DeepSeek top-up replay into a recipe-backed adapter path for amount selection, confirm-step targeting, QR detection, and success verification.
- Added `card_number_only` as the safe credit-card MVP: Pay-Switch may store/fill only the card number through OS keyring after confirmation, while expiry, CVV, OTP/3DS, and final authorization remain human-only.
- Added payment method routing and page-state method detection so external Computer Use observations can report visible options such as Alipay QR, WeChat QR, card-number forms, and Stripe.
- Added `payswitch settings payment` and `payswitch settings payment card` CLI flows for payment priority, disabled methods, and local card-number instrument metadata.
- Added PAN-like evidence redaction so external action evidence does not persist card numbers in JSON artifacts.
- Added Chrome profile occupancy preflight and `payswitch settings browser-doctor` so real-profile runs explain when normal Chrome already owns the User Data directory and point operators to CDP or a closed-browser launch path.
- Added `browser_control_backend` (`auto`, `cdp`, `user_profile`, `managed_profile`) and centralized browser runtime planning so spend, external actions, login, and browser-lite share one browser backend decision model.
- Added `ephemeral_cdp_mirror` as a browser backend that creates a transaction-scoped `/tmp` Chrome profile mirror, launches an independent CDP Chrome, and lets Pay-Switch attach without locking the operator's daily Chrome process.

### Why

**Stripe adapter:** Stripe is a critical payment channel for international credit/debit card transactions. Unlike browser-automation adapters (Alipay QR code via Playwright), Stripe uses REST API to create hosted checkout sessions, returning a URL for users to complete payment in Stripe's secure environment. Webhook listeners enable asynchronous payment confirmation without blocking the orchestrator.

**Other changes:** Pay-Switch needs to behave like a payment control plane, not a one-off browser script. These changes make the runtime configurable, auditable, and usable with a real user browser profile while preserving human authorization at sensitive or final payment points.

### Impact

- **Stripe adapter:** Agents can now accept international payments via `payswitch spend 10 --method stripe --currency usd`. Users receive a Stripe checkout URL (or QR code), complete payment on Stripe's secure page, and webhook automatically updates transaction status to `completed`. No browser automation needed.
- **Stripe webhook:** Operators must run `payswitch stripe listen` (default port 4242) to receive Stripe events. In production, configure Stripe Dashboard webhook URL to point to this endpoint.
- **Configuration:** Use `payswitch settings stripe` to configure `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` (stored base64-encoded in `~/.payswitch/config.json`). Environment variables `STRIPE_SECRET_KEY` / `STRIPE_WEBHOOK_SECRET` take precedence.
- Agents can use `external` mode as the default brain/hand split: the caller agent reasons, while Pay-Switch owns execution policy, browser context, guardrails, and ledger state.
- Operators can select the correct Chrome profile from the CLI instead of hard-coding `Default` or guessing `Profile N`.
- Unknown checkout pages can be explored through governed browser actions up to `checkout_prep`, then handed back to the human for QR scan, CVV, OTP, payment password, or final authorization.
- Real Chrome profile failures now fail before Playwright starts when the profile root is already owned by normal Chrome, which avoids confusing "Opening in existing browser session" errors and makes the required browser mode explicit.
- `browser-doctor` process-occupancy detection is strongest on macOS/Linux; unsupported platforms fall back to the normal browser startup error path while preserving the same actionable guidance.
- Operators can now separate "who reasons" (`computer_use_driver`) from "how the browser is controlled" (`browser_control_backend`), removing the earlier ambiguity where external mode still silently depended on direct Playwright profile ownership.
- If a fixed adapter goes stale, Pay-Switch now preserves the intended order: adapter -> Computer Use fallback -> human takeover only when fallback cannot proceed.
- External mode now has a first step-by-step action loop for exploration instead of only a static handoff state.
- External action loops can now continue across CLI invocations: `spend` records the handoff URL, and each `external-act` records the resulting URL for the next action.
- Caller Agents can now reason from a screenshot-backed observation instead of guessing from a clickable-only list, which is required for unknown SPA checkout pages such as DeepSeek top-up.
- Stripe/card checkout pages are now expected to stop at the sensitive-form human gate instead of being marked completed by a loose success-icon match.
- The public README now makes the protocol layer explicit, so reviewers can see that browser control is a fallback and learning path rather than the system's primary payment strategy.
- Login-gated sites now have a fixed first step: validate the live session before any adapter or Computer Use exploration begins.
- Kimi no longer misclassifies the English homepage login prompt as a usable logged-in state, which avoids false fallbacks and QR misfires from the wrong page.
- Subscription and pricing pages now have an explicit product requirement: Payswitch should not guess between Monthly, Annually, Business, or multiple tiers when the user's purchase intent is incomplete.
- DeepSeek now has a clearer middle layer between raw Computer Use traces and a hard-coded adapter, so successful unknown-site exploration can be reused without copying brittle selectors into orchestration code.
- Card fallback now has a sharper boundary: it is available only when explicitly enabled and configured, and it does not try to save or fill expiry/CVV/OTP/final confirmation.
- External agents get a clearer payment-channel signal during unknown-site exploration, which lets them ask the user about method preference before clicking into a checkout path.
- Payment evidence is safer to keep for debugging and experience-library learning because Luhn-valid PAN-like values are masked before they are written.
- `ephemeral_cdp_mirror` gives operators a practical exploration mode when normal Chrome is already open, reuses the same `tx_id` mirror across external-action steps, and cleans stale inactive mirrors before new launches while still making clear that copied profile state may trigger site re-login or verification if a service binds sessions to the original profile/keychain context.

### Verification

- `uv add stripe` or `pip install 'payswitch[stripe]'` to install Stripe dependencies.
- `uv run --extra dev pytest tests/test_stripe_adapter.py -v` to run Stripe-specific tests.
- `uv run --extra dev pytest -q` to ensure all 242 existing tests still pass.
- `uv run --extra dev ruff check payswitch/` to lint new code.
- `uv run --with mypy mypy payswitch/adapters/stripe.py payswitch/engine/stripe_webhook.py` for type checking.
- Manual test: Set `STRIPE_SECRET_KEY=sk_test_...`, run `payswitch spend 10 --method stripe --dry-run`, verify it simulates Stripe checkout creation.
- Webhook test: Start `payswitch stripe listen`, use Stripe CLI (`stripe listen --forward-to localhost:4242/webhook`) to forward test events.
- `uv run --extra dev pytest -q` -> `248 passed`
- `uv run python -m compileall -q payswitch tests`
- `rm -rf dist && uv build`
- `uv run payswitch settings profile --list-only --query cine.dreamer.one`
- `uv run payswitch --json config`
- `uv run --extra dev ruff check payswitch/browser/chrome_profiles.py tests/test_chrome_profiles.py`
- `uv run --with mypy mypy payswitch/browser/chrome_profiles.py tests/test_chrome_profiles.py`
- `uv run --extra dev pytest tests/test_browser_controller.py tests/test_external_runner.py -q`
- `printf '\ncine.dreamer.one\n1\n\n\n\n' | uv run payswitch settings wizard`
- `uv run payswitch settings wizard --browser chrome --profile-index 1 --yes`
- `uv run --extra dev pytest tests/test_adapters.py tests/test_integration.py -q`
- `uv run --extra dev pytest tests/test_adapters.py tests/test_external_runner.py tests/test_detector.py -q`
- `uv run --extra dev ruff check payswitch/adapters/deepseek.py payswitch/experience tests/test_adapters.py`
- `uv run --with mypy mypy payswitch/adapters/deepseek.py payswitch/experience`
- `uv run payswitch --json spend 10 deepseek --reason "adapter verification after recipe promotion" --method alipay_qr`
- `uv run payswitch --json spend 12 kimi --reason "user-angle Kimi login-preflight retest" --method alipay_qr`
- Documentation review of the Kimi subscription flow evidence, including `Monthly`, `Annually`, `Business`, plan-card `Subscribe`, agreement `Continue`, and QR handoff states.
- `uv run pytest tests/test_models.py tests/test_selector.py tests/test_card_vault.py tests/test_external_runner.py -q` -> `86 passed`
- `uv run pytest -q` -> `288 passed`
- `uv run ruff check payswitch/engine/selector.py payswitch/security payswitch/models/config.py payswitch/models/types.py tests/test_selector.py tests/test_card_vault.py`
- `uv run pytest tests/test_browser_runtime.py tests/test_cdp_mirror.py tests/test_browser_controller.py tests/test_models.py -q` -> `92 passed`
- `uv run ruff check payswitch/browser/cdp_mirror.py payswitch/browser/runtime.py payswitch/browser/controller.py tests/test_browser_runtime.py tests/test_cdp_mirror.py tests/test_browser_controller.py`
- `uv run python -m compileall payswitch/browser/cdp_mirror.py payswitch/browser/runtime.py payswitch/browser/controller.py payswitch/models/types.py payswitch/models/config.py payswitch/cli.py`
- `uv run pytest -q` -> `304 passed`
- `HOME="$(mktemp -d)" uv run payswitch --json config browser_control_backend ephemeral_cdp_mirror`
- `HOME="$(mktemp -d)" uv run payswitch --json settings payment`
- `HOME="$(mktemp -d)" uv run payswitch --json settings payment priority --methods wechat_qr,alipay_qr,stripe`

### Files

- `pyproject.toml` (added `stripe` optional dependency group)
- `payswitch/models/types.py` (added `PaymentMethod.stripe`)
- `payswitch/models/config.py` (added Stripe config fields and helper methods)
- `payswitch/adapters/stripe.py` (new: StripeAdapter implementation)
- `payswitch/adapters/__init__.py` (registered StripeAdapter)
- `payswitch/engine/orchestrator.py` (added Stripe API branch in spend(), new `_execute_stripe_mode()` method)
- `payswitch/engine/stripe_webhook.py` (new: FastAPI webhook listener with signature verification)
- `payswitch/cli.py` (added `settings stripe` and `stripe listen` commands)
- `tests/test_stripe_adapter.py` (new: comprehensive Stripe adapter and webhook tests)
- `CHANGELOG.md` (this file)
- `README.md`
- `VERSION`
- `uv.lock`
- `payswitch/engine/external_runner.py`
- `payswitch/browser/chrome_profiles.py`
- `payswitch/browser/controller.py`
- `payswitch/models/types.py`
- `payswitch/models/config.py`
- `payswitch/engine/orchestrator.py`
- `payswitch/engine/selector.py`
- `payswitch/security/card_vault.py`
- `payswitch/security/redaction.py`
- `tests/test_selector.py`
- `tests/test_card_vault.py`
- `payswitch/adapters/base.py`
- `payswitch/adapters/deepseek.py`
- `payswitch/adapters/kimi.py`
- `payswitch/browser/cdp_mirror.py`
- `payswitch/browser/runtime.py`
- `payswitch/cli.py`
- `payswitch/experience/__init__.py`
- `payswitch/experience/registry.py`
- `payswitch/adapters/nineemail.py`
- `doc/plans/2026-05-10-agent-checkout-control-plane-roadmap.md`
- `doc/plans/2026-05-11-checkout-intent-and-plan-selection.md`
- `tests/test_chrome_profiles.py`
- `tests/test_cdp_mirror.py`
- `tests/test_browser_runtime.py`
- `tests/test_computer_use.py`
- `tests/test_external_runner.py`
- `tests/test_adapters.py`
- `tests/test_integration.py`
- `tests/test_models.py`

## [0.1.0] - 2026-05-10

### What changed

- Established the initial Pay-Switch Python package metadata and README concept documentation.

### Why

This records the first public baseline version before the control-plane changes are published.

### Impact

- The project has a SemVer starting point for future releases.

### Verification

- Baseline source tree was present before this changelog was introduced.

### Files

- `README.md`
- `pyproject.toml`
