# Recovery Patch Promotion Queue Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed control-plane slice for recovery patch
promotion readiness.

It closes one concrete operator gap after the earlier review and auto
shadow-run modules:

```text
stored patch lifecycle
+ promotion readiness classification
+ CLI queue view
+ ready-only filtering
```

## 1. Module Goal

Operators should not need to infer promotion readiness from raw patch state
and metadata by hand.

Pay-Switch now exposes a queue-oriented view that answers:

- which patches are ready for `mainline`;
- which patches are still blocked;
- what exact condition is blocking promotion.

## 2. Delivered Behavior

### 2.1 Store-level readiness classification

`ExperienceStore` now computes patch promotion readiness:

- `reviewed` -> ready
- `shadow_run_success=true` -> ready
- `candidate` without review/shadow-run -> blocked
- `mainline` -> not actionable

Each queue entry now carries:

- `promotion_ready`
- `promotion_basis`
- `blocking_reasons`

### 2.2 CLI queue surface

The CLI now exposes:

- `payswitch experience patch queue`
- `payswitch experience patch queue --ready-only`

This gives reviewers a direct control-plane view of promotable patches without
manually post-processing `patch list`.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Patch readiness is computed centrally in the experience store.
2. CLI queue output shows both ready and blocked patches with explicit basis or
   blocking reason.
3. `--ready-only` filters the queue down to promotable patches only.
4. Existing review/shadow-pass/promote commands remain unchanged.

## 4. Verification

- `ruff check payswitch/experience/store.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py`

## 5. Non-Goals

This module does not yet deliver:

- automatic `mainline` promotion;
- risk-scored promotion policies;
- server or WebUI patch-queue APIs.

## 6. Implementation References

- [payswitch/experience/store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/store.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_experience_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_store.py)
- [tests/test_cli_experience.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_experience.py)
