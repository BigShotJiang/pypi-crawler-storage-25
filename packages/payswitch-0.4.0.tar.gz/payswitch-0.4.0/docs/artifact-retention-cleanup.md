# Artifact Retention Cleanup Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed Milestone 7 cleanup baseline for artifact
retention enforcement.

It closes the next gap after encrypted JSON artifact persistence:

```text
artifact metadata sidecars
+ expired-artifact discovery
+ bounded cleanup runner
+ service-owned cleanup supervisor
+ CLI and health visibility
```

## 1. Module Goal

Pay-Switch already persisted retention metadata beside sensitive and internal
JSON artifacts, but nothing was enforcing those expiry timestamps. Expired
artifacts would accumulate on disk without any operator-visible cleanup path.

This module adds a deterministic retention-cleanup contract so the system can:

- discover expired artifacts from metadata sidecars;
- delete expired primary artifacts and orphaned metadata in bounded batches;
- run cleanup through a reusable CLI loop or a service-owned supervisor;
- expose cleanup status through server health endpoints.

## 2. Delivered Behavior

### 2.1 Expiry discovery and deletion

`ArtifactStore` now provides:

- `list_expired(...)` for metadata-driven expiry discovery;
- `cleanup_expired(...)` for bounded deletion;
- dry-run action reporting without deleting files;
- metadata-only cleanup when the primary artifact is already missing.

### 2.2 Reusable cleanup runner

`ArtifactCleanupRunner` now provides:

- one-cycle execution for operator preview or batch deletion;
- bounded polling loops with `max_idle_polls`;
- loop summaries with cleaned/deleted totals and per-cycle history.

### 2.3 Service-owned cleanup supervision

The FastAPI server now supports an env-configured cleanup supervisor:

- `PAYSWITCH_ARTIFACT_CLEANUP_ENABLED`
- `PAYSWITCH_ARTIFACT_CLEANUP_POLL_INTERVAL_SECONDS`
- `PAYSWITCH_ARTIFACT_CLEANUP_BATCH_LIMIT`
- `PAYSWITCH_ARTIFACT_CLEANUP_DRY_RUN`

When enabled, the service owns lifecycle start/stop and exposes health through:

- `/api/artifact-cleanup/health`
- `/api/health -> artifact_cleanup`

### 2.4 CLI cleanup surface

The CLI now provides:

- `payswitch artifact cleanup --once`
- `payswitch artifact cleanup --dry-run`
- `payswitch artifact cleanup --max-cycles ...`

This gives operators a deterministic path to preview or execute retention
cleanup outside the server supervisor.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Expired artifact metadata can be discovered deterministically from sidecars.
2. Dry-run cleanup does not delete files and reports intended actions.
3. Real cleanup deletes expired artifacts plus sidecar metadata.
4. A bounded runner exits after the configured idle threshold.
5. The server health surface reports cleanup supervision state when enabled.
6. The CLI can preview and execute one cleanup cycle in JSON mode.

## 4. Verification

- `ruff check payswitch/security/artifacts.py payswitch/security/cleanup.py payswitch/server.py payswitch/cli.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py tests/test_ui_settings_api.py -q`
- `.venv/bin/python -m pytest tests/test_server_recovery_improver.py tests/test_cli_experience.py -q`

## 5. Non-Goals

This module does not yet deliver:

- screenshot or other binary artifact encryption;
- distributed or cross-host cleanup coordination;
- retention budgeting tied to global storage quotas;
- automated artifact replication or archival tiers.

## 6. Implementation References

- [payswitch/security/artifacts.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/artifacts.py)
- [payswitch/security/cleanup.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/cleanup.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_artifact_cleanup.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_artifact_cleanup.py)
- [tests/test_server_artifact_cleanup.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_artifact_cleanup.py)
- [tests/test_cli_artifact_cleanup.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_artifact_cleanup.py)
