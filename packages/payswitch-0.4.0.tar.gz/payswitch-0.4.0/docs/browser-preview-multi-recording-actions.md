## BrowserPreview Multi-Recording Actions Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed BrowserPreview multi-recording quick-action
slice for persisted browser media.

It closes the next operator-facing gap this way:

```text
BrowserPreview already embeds the latest persisted browser recording
+ the latest persisted media event can now surface more than one recording action
+ actions are ordered by recording_index
+ operators no longer have to leave the main preview panel to open older recordings from the same archive event
```

## 1. Module Goal

After index-aware ordering landed, BrowserPreview could pick the right "latest"
recording for the embedded video. But its quick-action row still exposed only a
single recording link.

That meant multi-recording sessions still forced operators back into the event
timeline whenever they needed any recording besides the newest one.

This module lets the main preview panel expose all recordings from the newest
persisted media event.

## 2. Delivered Behavior

### 2.1 Latest-event recording collection

The shared browser-recording helper now returns all downloadable video
artifacts from the newest `media.persisted` event that contains recordings.

Those artifacts are ordered by `recordingIndex`.

### 2.2 BrowserPreview quick actions

`BrowserPreview` now renders one quick action per recording from that newest
persisted media event.

The embedded `<video>` preview still uses the newest recording from that set,
but the action row now also exposes the earlier recordings from the same event.

### 2.3 Deterministic ordering

When multiple recordings exist, the action row renders them in ascending
`recordingIndex` order, such as:

- `打开录屏 · #1`
- `打开录屏 · #2`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. BrowserPreview renders all downloadable video artifacts from the newest
   persisted-media event.
2. Those actions are ordered by `recordingIndex`.
3. The embedded video still points at the newest recording from that set.
4. Sessions with only one persisted recording remain unchanged.

## 4. Verification

- `npm test -- --run src/components/BrowserPreview.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- grouped actions across multiple persisted-media events;
- extra timeline behavior changes;
- per-recording thumbnails in the action row.

## 6. Implementation References

- [frontend/src/lib/browserRecording.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/browserRecording.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/BrowserPreview.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.test.tsx)
