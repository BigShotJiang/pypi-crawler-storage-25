# Session Clear Explicit User Scope Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed explicit-scope guard for bulk session
clears.

It closes one destructive scope gap:

```text
session delete already enforces explicit scope on one session
+ bulk session clear now also requires user_id when explicit scoped sessions exist
+ user-scoped clears still work
+ legacy non-explicit clears keep compatibility
```

## 1. Module Goal

Single-session destructive paths already enforced explicit `user_id` parity for
scoped sessions. But `DELETE /api/sessions` still allowed one unscoped bulk
clear, even when the stored sessions belonged to explicit owners.

That meant the control plane had already learned how to protect one scoped
session delete, but it still left one broader destructive shortcut behind.

This module brings the bulk clear route onto the same explicit-ownership line.

## 2. Delivered Behavior

### 2.1 Explicitly scoped bulk clear now requires `user_id`

If any visible session declares an explicit owner in metadata, calling
`DELETE /api/sessions` without `user_id` now fails with `409`.

Callers must request:

- `DELETE /api/sessions?user_id=<id>`

### 2.2 User-scoped clear behavior remains intact

When `user_id` is provided, the route still clears only that user's sessions
and releases those matching workspace leases.

### 2.3 Legacy non-explicit compatibility remains

Older non-explicit session sets still keep their existing compatibility when no
explicit scoped sessions are involved.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `DELETE /api/sessions` returns `409` when explicit scoped sessions exist and
   `user_id` is missing.
2. `DELETE /api/sessions?user_id=<id>` still clears only that user's sessions.
3. Remaining users' scoped sessions are preserved.
4. Server route tests pass after the contract change.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/server.py tests/test_server_public_urls.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py -q`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- changes to session-list read scope rules;
- removal of the bulk clear route itself;
- local developer helper parity outside the hosted API server.

## 6. Implementation References

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
