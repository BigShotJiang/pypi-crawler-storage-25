## Browser Recording Codec Metadata Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed codec-metadata slice for persisted browser
recording artifacts.

It closes the next metadata gap this way:

```text
browser recording artifact already has source, size, duration, fps, resolution, and engine
+ runtime source now emits codec_name
+ server and local settings/events preserve codec aliases
+ WebUI labels recordings with human-readable codec metadata
```

## 1. Module Goal

The browser recording pipeline already exposed:

- stable artifact IDs;
- recording source;
- byte size;
- capture engine;
- duration;
- fps;
- resolution;
- persisted download URLs.

But operators still could not tell which video codec a stored recording used.
That made replay output and native terminal video less legible when debugging
capture fidelity or interpreting playback compatibility.

This module adds codec metadata without changing how recordings are captured or
delivered.

## 2. Delivered Behavior

### 2.1 Runtime source codec metadata

`ExternalCheckoutRunner` now emits best-effort `codec_name` at the source:

- native browser video: `ffprobe` reads the first video stream codec after the
  recording file is finalized;
- screenshot replay: the same best-effort video-stream probe runs after replay
  synthesis completes.

The same value is written into:

- artifact metadata;
- emitted `media.persisted` payloads (`codec_name`, `codecName`).

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve both:

- `codec_name`
- `codecName`

This keeps codec metadata aligned with the alias policy already used for
artifact ID, source, size, duration, fps, resolution, engine, and download
metadata.

### 2.3 WebUI codec labels

The frontend runtime model now preserves `codecName`.

Browser media actions surface human-readable codec labels such as:

- `VP8`
- `MPEG-4`

These labels appear in both:

- `BrowserPreview`;
- `LiveTimeline`.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Native recording persistence can carry best-effort `codec_name`.
2. Screenshot replay persistence can carry the same codec metadata.
3. Public session projection preserves both codec aliases.
4. Local settings/events projection preserves the same aliases.
5. WebUI media actions render codec metadata when available.
6. Existing recording playback, source attribution, size, duration, fps,
   resolution, and engine labels stay intact.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- bit-rate or container-level inspection;
- audio stream inspection;
- native live capture for attached CDP user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/lib/browserRecording.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/browserRecording.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
