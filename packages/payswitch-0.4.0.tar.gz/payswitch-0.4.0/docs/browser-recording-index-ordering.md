## Browser Recording Index Ordering Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed index-aware ordering slice for persisted
browser recording artifacts in the WebUI.

It closes the next operator-facing gap this way:

```text
browser recordings already expose recording_index end to end
+ BrowserPreview now selects the highest recording index from the latest persisted media event
+ LiveTimeline now sorts multiple persisted media links by recording_index
+ multi-recording sessions no longer default to the first array item as the main recording
```

## 1. Module Goal

After `recording_index` reached the control plane, the WebUI could display
`#2`-style order labels. But the main preview still chose the first video entry
inside the latest `media.persisted` event, and timeline links still relied on
raw array order.

That meant multi-recording sessions could still foreground the wrong recording
even though the ordering metadata already existed.

This module makes the WebUI consume that metadata deterministically.

## 2. Delivered Behavior

### 2.1 Shared recording-index ordering helper

The frontend browser-recording helper now provides:

- stable sorting by `recordingIndex`;
- latest-video selection from the latest persisted media event with the highest
  `recordingIndex`.

Artifacts that do not carry an index preserve their relative order.

### 2.2 BrowserPreview latest-recording selection

`BrowserPreview` no longer picks the first downloadable video artifact from the
latest persisted-media event.

Instead, it now:

1. scans persisted media events from newest to oldest;
2. sorts artifacts inside each event by `recordingIndex`;
3. chooses the highest indexed downloadable video from the newest event.

This keeps the main preview aligned with the same order label shown in the
action text.

### 2.3 LiveTimeline link ordering

`LiveTimeline` now sorts persisted media links inside each event by
`recordingIndex` before rendering them.

This makes `#1`, `#2`, `#3` links appear in deterministic order instead of
mirroring whatever raw array order happened to arrive from the emitter.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. BrowserPreview chooses the highest `recordingIndex` from the newest
   `media.persisted` event.
2. LiveTimeline orders multiple persisted media links by `recordingIndex`.
3. Existing single-recording sessions remain unchanged.
4. Artifacts without `recordingIndex` do not disappear or fail to render.

## 4. Verification

- `npm test -- --run src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- grouping recordings across multiple persisted-media events;
- backend ordering changes to artifact persistence or API payloads;
- browser-tab or page-title attribution for each recording.

## 6. Implementation References

- [frontend/src/lib/browserRecording.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/browserRecording.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
- [frontend/src/components/BrowserPreview.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.test.tsx)
- [frontend/src/components/LiveTimeline.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.test.tsx)
