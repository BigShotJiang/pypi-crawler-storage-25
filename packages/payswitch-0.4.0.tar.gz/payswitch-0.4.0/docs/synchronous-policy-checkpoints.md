# Synchronous Policy Checkpoints

This document records the completed recipe-backed synchronous policy checkpoint
slice for Milestone 6.

## Goal

High-risk adapter waypoints must be able to stop synchronously before a risky
page action continues. The checkpoint must be explicit, typed, and reviewable by
Watchdog and later recovery layers.

## Scope shipped now

This slice covers the recipe runner and the current Kimi recipe-backed fast
path. It does not yet retrofit every older imperative adapter.

## What shipped

1. `RecipeWaypoint` now supports `synchronous_policy_checkpoint=true`.
2. `RecipeRunner` now accepts a `policy_checkpoint_callback`.
3. When a flagged waypoint executes, the runner now:
   - emits a `waypoint.policy_checkpoint` telemetry event;
   - requires the checkpoint callback to pass before the waypoint action runs;
   - records a durable `policy_checkpoint` script step for audit.
4. Failure context emitted from a blocked checkpoint now includes:
   - `synchronous_policy_checkpoint=true`
   - `waypoint_category`
   - `waypoint_risk`
   - `login_required` when the checkpoint failed because the session is not authenticated
5. Kimi's `confirm_membership_checkout` waypoint is now marked as a synchronous
   checkpoint and verifies visible pricing/payment markers before clicking
   `Continue` or other confirm controls.

## Acceptance criteria

- A flagged recipe waypoint cannot proceed without an explicit checkpoint pass.
- A blocked checkpoint raises structured failure context that Watchdog can
  classify as `login_required` or `sensitive_action`.
- The checkpoint leaves an auditable step in the script timeline.
- Kimi's high-risk subscription confirmation path now uses the shared runner
  contract instead of ad hoc orchestrator logic.

## Verification

- `ruff check payswitch/experience/models.py payswitch/experience/runner.py payswitch/experience/registry.py payswitch/adapters/kimi.py tests/test_experience_runner.py tests/test_adapters.py tests/test_recovery_watchdog.py`
- `.venv/bin/python -m pytest tests/test_experience_runner.py tests/test_adapters.py tests/test_recovery_watchdog.py`
- `git diff --check`

## Non-goals

- Retrofitting every legacy imperative adapter to the same checkpoint contract
- Full per-action recovery-state verification before every Computer Use action
- Automatic policy approval or promotion into mainline recipe behavior
