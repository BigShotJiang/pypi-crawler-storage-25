# Stale-Context Recovery Re-Synchronization Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed stale-context recovery re-synchronization
slice for Milestone 6.

It closes the earlier gap between stale-context detection and actual bounded
Computer Use recovery:

```text
stale watchdog signal
+ recovery-state re-synchronization step
+ fresh recovery context handed into Computer Use
```

## 1. Module Goal

When watchdog marks script recovery telemetry as stale, Pay-Switch must stop
trusting the old rolling buffer and rebuild a fresh recovery snapshot before
Computer Use continues.

That fresh snapshot must include enough current-state evidence for the
recovery model and later audit:

- current URL;
- current visible text summary;
- current DOM summary;
- updated recovery screenshot evidence.

## 2. Delivered Behavior

### 2.1 Explicit re-synchronization step in the orchestrator

When `RecoveryDecision.requires_resync` is true, the orchestrator now performs
an explicit recovery-state re-synchronization step after access preflight and
before Computer Use fallback starts.

The transaction timeline now records a durable step:

- `恢复上下文已重同步 (...)`

so operators can see that stale watchdog state was refreshed before recovery
continued.

### 2.2 Fresh recovery snapshot payload

The re-synchronization step now captures and stores a structured
`resync_snapshot` inside recovery context:

- `recorded_at`
- `current_url`
- `visible_text_summary`
- `dom_summary`
- `watchdog_state`
- `screenshot_path`

### 2.3 Computer Use prompt now receives fresh resync context

`ComputerUseExplorer.explore_checkout()` now accepts `recovery_context`.

When a `resync_snapshot` exists, the bounded Computer Use prompt now includes:

- failed waypoint identity;
- fresh current URL;
- fresh visible-text summary;
- fresh DOM title / heading / button summary.

This gives the model the current surface state instead of only the stale
script-failure reason.

### 2.4 Verification failures keep resync evidence

If pre-action recovery verification blocks a login or high-risk action, the
raised failure context now projects the same `resync_snapshot`, so later
human-gate review still has the fresh page evidence that recovery was using.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. A stale watchdog decision creates a visible re-synchronization step before
   Computer Use starts.
2. The recovery context handed to Computer Use contains a structured fresh
   `resync_snapshot`.
3. The bounded Computer Use prompt includes that fresh snapshot when present.
4. Verification failures raised during Computer Use keep the fresh
   re-synchronization evidence.
5. Regression tests prove both the prompt/context projection and the full
   orchestrator handoff path.

## 4. Verification

- `ruff check payswitch/browser/computer_use.py payswitch/engine/orchestrator.py tests/test_computer_use.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_computer_use.py tests/test_integration.py`

## 5. Non-Goals

This module does not yet deliver:

- full resume/reconnect recovery for every long-lived human-gate pause;
- automatic watchdog-driven recipe patch promotion;
- stronger DOM diffing than the current summary snapshot.

## 6. Implementation References

- [payswitch/browser/computer_use.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/computer_use.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [tests/test_computer_use.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_computer_use.py)
- [tests/test_integration.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_integration.py)
