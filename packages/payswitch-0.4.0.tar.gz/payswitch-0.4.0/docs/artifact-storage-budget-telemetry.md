# Artifact Storage Budget Telemetry Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed artifact inventory and storage-budget
observability baseline.

It closes the next gap after retention cleanup and screenshot artifact
encryption:

```text
artifact retention metadata
+ inventory snapshots
+ byte-level disk usage summary
+ budget threshold signal
+ CLI and health visibility
```

## 1. Module Goal

Pay-Switch already had artifact metadata, cleanup execution, and encrypted PNG
evidence, but operators still lacked an answer to basic runtime questions:

- how many artifacts exist right now;
- how much disk they occupy;
- how much of that usage is already expired;
- whether the node is past an expected storage budget.

This module adds that observability baseline without hard-coding automatic
budget enforcement.

## 2. Delivered Behavior

### 2.1 Inventory snapshots

`ArtifactStore.inventory(...)` now reports:

- total artifact count;
- expired artifact count;
- encrypted artifact count;
- orphaned metadata count;
- primary bytes, metadata bytes, and total bytes;
- expired bytes;
- breakdowns by sensitivity and artifact kind.

### 2.2 Budget signal

Inventory snapshots now accept an optional `budget_bytes` threshold and expose:

- `budget_bytes`
- `budget_mb`
- `usage_ratio`
- `over_budget`

This gives the control plane a deterministic disk-budget warning surface
without forcing automatic deletion policy.

### 2.3 CLI surface

The CLI now provides:

- `payswitch artifact stats`
- `payswitch artifact stats --budget-mb ...`

This makes local inspection and operator triage possible without opening the
database or writing ad hoc filesystem scripts.

### 2.4 Server health surface

The server now exposes:

- `/api/artifact-inventory/health`
- `/api/health -> artifact_inventory`

And supports the env-configured budget signal:

- `PAYSWITCH_ARTIFACT_STORAGE_BUDGET_MB`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Artifact inventory reports counts and byte totals from metadata-backed files.
2. Inventory distinguishes encrypted, expired, and orphaned entries.
3. A budget threshold can mark the inventory as `over_budget`.
4. The CLI can emit the budget signal in JSON mode.
5. The server health surface projects the same budget signal.

## 4. Verification

- `ruff check payswitch/security/artifacts.py payswitch/cli.py payswitch/server.py tests/test_artifact_inventory.py tests/test_server_artifact_inventory.py tests/test_cli_artifact_stats.py`
- `.venv/bin/python -m pytest tests/test_artifact_inventory.py tests/test_server_artifact_inventory.py tests/test_cli_artifact_stats.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py -q`

## 5. Non-Goals

This module does not yet deliver:

- automatic budget-triggered deletion beyond explicit cleanup execution;
- cross-host storage aggregation;
- tiered archive/export behavior;
- per-user or per-workspace storage quotas.

## 6. Implementation References

- [payswitch/security/artifacts.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/artifacts.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_artifact_inventory.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_artifact_inventory.py)
- [tests/test_server_artifact_inventory.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_artifact_inventory.py)
- [tests/test_cli_artifact_stats.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_artifact_stats.py)
