# Artifact Storage Budget Enforcement Module

## Goal

Turn artifact storage budgets from a health-only signal into an executable local
policy: when a node is over budget, Pay-Switch can now reclaim artifact disk
usage through a bounded runner, CLI, and service-owned supervisor.

## What changed

- `ArtifactStore` now exposes:
  - `list_budget_reclaim_candidates(...)`
  - `enforce_budget(...)`
- Budget enforcement uses a deterministic reclaim order:
  1. expired artifacts first;
  2. then older `public` artifacts;
  3. then older `internal` artifacts;
  4. `sensitive` artifacts are skipped by default.
- Added `ArtifactBudgetEnforcementRunner` for bounded execution loops with:
  - `budget_bytes`
  - `target_ratio`
  - `batch_limit`
  - `max_idle_polls`
  - optional `include_sensitive`
- Added `ArtifactBudgetEnforcementSupervisor` so the server can enforce storage
  budgets in the background.
- Added CLI entrypoint:
  - `payswitch artifact enforce-budget`
- Added server health surface:
  - `/api/artifact-budget-enforcement/health`
  - `/api/health -> artifact_budget_enforcement`

## Why

- Artifact inventory already exposed `over_budget`, but the system still needed
  a manual operator step to reclaim bytes.
- Retention cleanup only handled expired artifacts; it did not enforce a live
  node back under a configured storage budget.
- The roadmap requires not just observability, but enforceable local resource
  controls.

## Impact

- Over-budget nodes can now execute a bounded reclaim pass without inventing
  ad hoc scripts.
- Dry-run preview and service-owned supervision now share the same reclaim
  policy.
- Sensitive artifacts are protected by default, so automated reclaim starts
  from lower-risk evidence first.
- Health responses now show whether budget enforcement is enabled and how much
  data it has reclaimed.

## Acceptance criteria

1. A dry-run can preview which artifacts would be reclaimed and why.
2. Real enforcement deletes reclaim candidates in deterministic priority order.
3. `sensitive` artifacts are not reclaimed unless explicitly enabled.
4. CLI and server health expose the same budget-enforcement controls and state.

## Verification

- `ruff check payswitch/security/artifacts.py payswitch/security/cleanup.py payswitch/server.py payswitch/cli.py tests/test_artifact_budget_enforcement.py tests/test_server_artifact_budget_enforcement.py tests/test_cli_artifact_budget_enforcement.py`
- `.venv/bin/python -m pytest tests/test_artifact_budget_enforcement.py tests/test_server_artifact_budget_enforcement.py tests/test_cli_artifact_budget_enforcement.py tests/test_artifact_inventory.py tests/test_server_artifact_inventory.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py tests/test_cli_artifact_stats.py -q`
- `git diff --check`

## Files

- [payswitch/security/artifacts.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/artifacts.py)
- [payswitch/security/cleanup.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/cleanup.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_artifact_budget_enforcement.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_artifact_budget_enforcement.py)
- [tests/test_server_artifact_budget_enforcement.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_artifact_budget_enforcement.py)
- [tests/test_cli_artifact_budget_enforcement.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_artifact_budget_enforcement.py)
