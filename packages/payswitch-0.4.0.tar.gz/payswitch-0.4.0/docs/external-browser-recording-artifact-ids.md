## External Browser Recording Artifact ID Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed source-contract slice for runtime browser
recording artifacts.

It closes the current event-contract gap this way:

```text
external runner persists browser recordings
+ media.persisted event now carries stable artifact ids
+ artifact metadata stores the same id
+ downstream control planes can stop depending on raw paths only
```

## 1. Module Goal

The external runner already persisted encrypted browser recordings and emitted
`media.persisted` events.

But those runtime-emitted media items still relied on `artifact_path` alone.
That left the source contract weaker than the rest of the artifact system,
which normally uses stable `artifact_id` values for download routing and public
projection.

This module aligns runtime-emitted browser recording artifacts with that
artifact-id contract.

## 2. Delivered Behavior

### 2.1 Stable artifact IDs at the runtime source

`ExternalCheckoutRunner` now derives a stable artifact ID from each finalized
browser recording filename.

Examples:

- `page-1.webm` -> `page_1_webm`
- `observation-replay.mp4` -> `observation_replay_mp4`

If a filename ever normalizes to an empty string, the runner falls back to
`external_recording_{index}`.

### 2.2 Persisted metadata parity

The same generated ID is now written into artifact metadata alongside:

- `tx_id`
- `payee`
- `recording_source`
- `source_filename`

This keeps the encrypted artifact payload and emitted runtime event aligned.

### 2.3 Runtime event parity

Each `media.persisted` payload now includes:

- `artifact_id`
- `artifactId`

in addition to the existing path, content type, name, kind, and recording
source fields.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Native browser recording persistence emits a stable `artifact_id`.
2. Screenshot-replay fallback persistence emits the same kind of stable
   `artifact_id`.
3. The encrypted artifact metadata stores that same ID.
4. Existing recording persistence, cleanup, and event emission behavior remains
   unchanged otherwise.
5. Targeted external-runner tests cover both native and screenshot-replay
   recording paths.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py tests/test_external_runner.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py -q`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- authenticated session-artifact download projection for these runtime-emitted
  media items;
- poster/thumbnail extraction;
- native live capture for CDP-attached user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [tests/test_external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_external_runner.py)
- [docs/external-browser-recording-baseline.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/external-browser-recording-baseline.md)
- [docs/external-browser-recording-playback.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/external-browser-recording-playback.md)
