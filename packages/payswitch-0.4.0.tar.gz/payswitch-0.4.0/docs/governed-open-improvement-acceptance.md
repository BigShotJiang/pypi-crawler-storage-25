# Governed Open Improvement Acceptance Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed governed acceptance slice for `open`
recovery improvements.

It closes the next gap after service-owned improver supervision:

```text
service-owned accepted supervisor
+ deterministic open-queue acceptance policy
+ CLI preview and execution surface
+ optional supervisor auto-accept basis
```

## 1. Module Goal

Successful bounded recovery artifacts should not require a human to click every
single `open -> accepted` transition when the linked patch already satisfies a
deterministic governance basis.

This module adds a governed acceptance path that:

- evaluates `open` recovery improvements against explicit readiness basis;
- supports manual preview and execution from the CLI;
- allows the service-owned supervisor to auto-accept only when configured.

## 2. Delivered Behavior

### 2.1 Deterministic open-queue acceptor

`ExperienceStore.accept_open_recovery_improvements(...)` now evaluates open
items against a basis of:

- `shadow_run_success`
- `reviewed`

Items that do not satisfy the configured basis stay `open` and return explicit
blocking reasons.

### 2.2 CLI acceptance surface

The CLI now exposes:

- `payswitch experience improvement accept-open`

Supported controls:

- `--reviewer`
- `--note`
- `--platform`
- `--flow`
- `--limit`
- `--basis`
- `--dry-run`

### 2.3 Supervisor auto-accept option

`RecoveryImprovementSupervisor` now supports optional
`auto_accept_basis`.

When `PAYSWITCH_RECOVERY_IMPROVER_AUTO_ACCEPT_BASIS` is configured, the
supervisor can:

1. accept eligible `open` improvements;
2. process those accepted items through the existing accepted-improvement loop;
3. expose `auto_accept_basis` and `total_auto_accepted` in health payloads.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Open improvements can be previewed and accepted through a deterministic API.
2. Acceptance is basis-gated and does not silently advance blocked items.
3. The CLI can preview and execute governed acceptance.
4. The service-owned supervisor can auto-accept only when explicitly configured.
5. Regression tests cover store, CLI, supervisor, and server health projection.

## 4. Verification

- `ruff check payswitch/experience/store.py payswitch/experience/improver.py payswitch/server.py payswitch/cli.py tests/test_experience_store.py tests/test_experience_improver.py tests/test_cli_experience.py tests/test_server_recovery_improver.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_experience_improver.py tests/test_cli_experience.py tests/test_server_recovery_improver.py`

## 5. Non-Goals

This module does not yet deliver:

- fully unattended promotion from `reviewed` patches into `mainline`;
- LLM-driven or risk-scored acceptance policy changes beyond minimum shadow-run thresholds;
- cross-host improver coordination.

## 6. Implementation References

- [payswitch/experience/store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/store.py)
- [payswitch/experience/improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/improver.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_experience_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_store.py)
- [tests/test_experience_improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_improver.py)
- [tests/test_cli_experience.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_experience.py)
- [tests/test_server_recovery_improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_recovery_improver.py)
