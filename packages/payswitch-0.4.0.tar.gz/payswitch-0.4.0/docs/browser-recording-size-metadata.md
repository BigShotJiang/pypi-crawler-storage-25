## Browser Recording Size Metadata Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed size-metadata slice for persisted browser
recording artifacts.

It closes the next contract gap this way:

```text
external runner persists browser recording artifacts
+ source event includes size_bytes
+ server and local settings/events preserve size aliases
+ WebUI labels recording actions with file size
```

## 1. Module Goal

The recording pipeline already persisted browser media, projected download
links, preserved source attribution, and assigned stable artifact IDs.

But it still did not preserve file size consistently from the runtime source to
the operator-facing control plane. That left recording quick actions and
timeline links without one basic piece of evidence metadata that downstream
surfaces already use for other persisted artifacts.

This module makes browser recording size visible end to end without widening
the recording capture scope itself.

## 2. Delivered Behavior

### 2.1 Runtime source metadata

`ExternalCheckoutRunner` now records plaintext recording size in bytes when it
persists:

- native browser videos;
- screenshot-replay fallback videos.

The size is written into both:

- artifact metadata (`metadata.size_bytes`);
- emitted `media.persisted` payloads (`size_bytes` and `sizeBytes`).

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve size
metadata with both field aliases:

- `size_bytes`
- `sizeBytes`

This keeps browser recording metadata aligned with the artifact casing policy
already used for IDs, download URLs, content types, and recording sources.

### 2.3 WebUI size visibility

The frontend runtime model now preserves `sizeBytes` on media artifacts.

Browser recording actions now surface human-readable file size in:

- `BrowserPreview` quick actions;
- `LiveTimeline` persisted media links.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Runtime-emitted browser recording events include a stable byte size.
2. Encrypted artifact metadata stores the same byte size.
3. Public session projection preserves `size_bytes` and `sizeBytes`.
4. The local settings/events projection preserves the same aliases.
5. The WebUI renders recording size for persisted media actions when known.
6. Existing recording playback and attribution behavior stays unchanged.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- video duration, fps, or codec introspection;
- thumbnail or poster extraction;
- higher-fidelity live capture for CDP-attached user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/lib/sessionModel.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionModel.ts)
- [frontend/src/lib/formatBytes.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/formatBytes.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
