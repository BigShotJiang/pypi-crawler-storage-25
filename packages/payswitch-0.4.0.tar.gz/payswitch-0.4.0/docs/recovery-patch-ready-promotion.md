# Recovery Patch Ready Promotion Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed control-plane slice for governed batch
promotion of recovery-generated recipe patches that are already promotion-ready.

It closes the next lifecycle gap after queue visibility:

```text
promotion queue
+ readiness classification
+ dry-run preview
+ batch mainline promotion with audit metadata
```

## 1. Module Goal

Operators should be able to promote all currently ready recovery patches into
`mainline` without issuing one command per patch and without losing the exact
reason each patch was eligible.

This module adds a governed queue processor that:

- only operates on patches already marked ready;
- can filter by readiness basis;
- supports dry-run preview before mutation;
- records durable promotion metadata for audit.

## 2. Delivered Behavior

### 2.1 Store-level batch promotion

`ExperienceStore.promote_ready_patches(...)` now:

1. reads the existing promotion queue;
2. keeps only ready entries;
3. optionally filters by readiness basis (`reviewed` or
   `shadow_run_success`);
4. optionally limits batch size;
5. promotes selected entries to `mainline`.

### 2.2 Durable promotion audit metadata

Each promoted patch now records:

- `promotion_basis`
- `promotion_batch_id`
- `promoted_at`
- `promoted_by`
- `promoted_via=queue_auto`
- optional `promotion_note`

This means a later reviewer can see both why the patch was promotable and who
executed the promotion batch.

### 2.3 CLI queue processor

The CLI now exposes:

- `payswitch experience patch promote-ready`

Supported controls:

- `--basis`
- `--platform`
- `--flow`
- `--source`
- `--limit`
- `--actor`
- `--note`
- `--dry-run`

### 2.4 Safety boundary remains intact

This module still does **not** let a non-ready candidate become `mainline`.

The batch processor only promotes patches that the existing queue already
classified as ready.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Batch promotion only touches patches already marked promotion-ready.
2. Operators can preview the exact promotion set through `--dry-run`.
3. Operators can narrow the batch to `reviewed` or `shadow_run_success`
   readiness basis.
4. Successful batch promotion writes durable audit metadata.
5. Regression tests cover both store-level promotion semantics and the CLI
   surface.

## 4. Verification

- `ruff check payswitch/experience/store.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py`

## 5. Non-Goals

This module does not yet deliver:

- runtime-triggered automatic `mainline` promotion during live traffic;
- watchdog-driven improver loops;
- risk-weighted promotion scoring beyond the existing readiness basis.

## 6. Implementation References

- [payswitch/experience/store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/store.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_experience_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_store.py)
- [tests/test_cli_experience.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_experience.py)
