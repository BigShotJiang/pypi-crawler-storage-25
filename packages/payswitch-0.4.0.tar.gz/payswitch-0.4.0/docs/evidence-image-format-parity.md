## Evidence Image Format Parity Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed image-evidence compatibility slice for the
local settings/events API.

It closes the mismatch left after QR artifact persistence:

```text
session/event image URL generation
+ evidence-path admission parity
+ MIME fallback parity for local image reads
+ supported image suffix tests
```

## 1. Module Goal

After QR artifact persistence landed, the control plane could emit image URLs
for `.webp` and `.svg` artifacts, but the local `/evidence` handler still only
admitted `.png`, `.jpg`, and `.jpeg`. That mismatch meant the UI could receive
a valid-looking image URL that the local evidence server would later reject.

This module makes image evidence handling consistent from URL generation to byte
serving.

## 2. Delivered Behavior

### 2.1 Shared image suffix policy

The local settings/events API now uses one shared suffix allowlist for image
evidence:

- `.png`
- `.jpg`
- `.jpeg`
- `.webp`
- `.svg`

That allowlist now drives both:

- image URL generation; and
- `/evidence?path=...` request admission.

### 2.2 MIME fallback for metadata-less local files

`_settings_api_read_evidence_bytes(...)` now tolerates files that do not have an
artifact sidecar metadata file yet. When metadata is missing, it:

- reads raw bytes directly; and
- falls back to `mimetypes.guess_type(...)` instead of returning `None`.

That keeps local compatibility for image files created outside `ArtifactStore`
while preserving encrypted artifact reads for files that do use the artifact
contract.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `.webp` and `.svg` evidence paths are admitted by the local `/evidence`
   handler.
2. The image URL helper and the request-admission helper share the same allowed
   image suffix set.
3. Metadata-less local `.svg` evidence files still return bytes plus
   `image/svg+xml`.

## 4. Verification

- `ruff check payswitch/cli.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_ui_settings_api.py -q`

## 5. Non-Goals

This module does not yet deliver:

- non-image binary artifact serving through the local evidence endpoint;
- browser-stream or video artifact persistence;
- automatic artifact-key rotation.

## 6. Implementation References

- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_ui_settings_api.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_ui_settings_api.py)
