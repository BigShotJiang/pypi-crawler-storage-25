# Imperative Adapter Synchronous Policy Checkpoints

Date: 2026-05-16
Status: implemented in current branch

This document records the Milestone 6 slice that retrofits synchronous policy
checkpoints into the remaining imperative browser adapters.

## 1. Goal

Kimi and DeepSeek already had explicit synchronous stop points before their
high-risk confirm transitions. The older imperative adapters still clicked their
final checkout buttons directly once the selector matched.

This slice closes that gap for the remaining browser-driven imperative adapters:

- Qwen
- Jimeng
- Volcano
- NineEmail

The goal is to fail closed before a high-risk confirm/pay transition when the
visible surface no longer shows the expected payment markers.

## 2. Delivered Behavior

### 2.1 Shared adapter checkpoint helper

`SiteAdapter` now exposes a shared synchronous checkpoint helper that:

1. re-validates login state;
2. collects a compact visible-text snapshot from the current page;
3. checks adapter-authored payment-marker groups; and
4. raises `ScriptExecutionError` with structured `failure_context` when the
   payment surface no longer looks correct.

That failure context now carries:

- `requires_human_gate=true`
- `synchronous_policy_checkpoint=true`
- checkpoint / waypoint id
- risk/category/action metadata
- visible text excerpt
- required marker groups

### 2.2 Legacy browser adapters now fail closed before final confirm

The final payment-transition click paths in the imperative browser adapters now
enforce the shared checkpoint before clicking:

- `QwenAdapter._click_confirm()`
- `JimengAdapter._click_checkout()`
- `VolcanoAdapter._click_pay()`
- `NineEmailAdapter._click_pay_now()`

If the page has drifted away from a visible payment surface, the click no
longer executes.

### 2.3 Audit trail now marks these clicks as high-risk final authorization

The same final click steps are now recorded with:

- `category=final_authorization`
- `risk=high`

This keeps the fast path auditable even when the adapter remains imperative.

### 2.4 Human recovery handoff keeps the checkpoint failure context

When one of these script checkpoints blocks, the script recovery gate now keeps
the structured `failure_context` inside `human_action.details`.

That gives the WebUI and later audit tooling enough data to explain which
checkpoint blocked the click and why.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Qwen, Jimeng, Volcano, and NineEmail all enforce a synchronous checkpoint
   before their final payment-transition click.
2. Missing visible payment markers block the click with structured
   `ScriptExecutionError.failure_context`.
3. Those final click steps are recorded as `final_authorization` / `high`.
4. Script recovery handoff preserves the checkpoint `failure_context` for UI and
   audit consumers.
5. The regression suite proves both adapter-level checkpoint blocking and
   orchestrator-level human-gate routing.

## 4. Verification

- `ruff check payswitch/adapters/base.py payswitch/adapters/qwen.py payswitch/adapters/jimeng.py payswitch/adapters/volcano.py payswitch/adapters/nineemail.py payswitch/engine/orchestrator.py tests/test_adapters.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_adapters.py tests/test_integration.py`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- full recipe-runner migration for all legacy imperative adapters;
- stronger DOM/assertion models than visible-text checkpoint markers;
- protocol-level payment routing changes.

## 6. Implementation References

- [payswitch/adapters/base.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/base.py)
- [payswitch/adapters/qwen.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/qwen.py)
- [payswitch/adapters/jimeng.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/jimeng.py)
- [payswitch/adapters/volcano.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/volcano.py)
- [payswitch/adapters/nineemail.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/nineemail.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [tests/test_adapters.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_adapters.py)
- [tests/test_integration.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_integration.py)
