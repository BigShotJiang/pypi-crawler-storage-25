## Browser Recording Duration Metadata Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed duration-metadata slice for persisted
browser recording artifacts.

It closes the next metadata gap this way:

```text
browser recording artifact already has source, size, and engine
+ runtime source now emits duration_seconds
+ server and local settings/events preserve duration aliases
+ WebUI labels recordings with human-readable duration
```

## 1. Module Goal

The browser recording pipeline already exposed:

- stable artifact IDs;
- recording source;
- byte size;
- capture engine;
- persisted download URLs.

But operators still could not see how long a stored recording actually was.
That left the media-evidence surface weaker than the rest of the artifact
contract and made screenshot replay versus native terminal video harder to
interpret at a glance.

This module adds duration metadata without changing how recordings are produced
or delivered.

## 2. Delivered Behavior

### 2.1 Runtime source duration

`ExternalCheckoutRunner` now emits `duration_seconds` at the source:

- native browser video: best-effort `ffprobe` duration detection;
- screenshot replay: deterministic fallback based on the current 1fps replay
  synthesis rule.

The same value is written into:

- artifact metadata;
- emitted `media.persisted` payloads (`duration_seconds` and
  `durationSeconds`).

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve both:

- `duration_seconds`
- `durationSeconds`

This keeps duration aligned with the alias policy already used for artifact ID,
source, size, engine, and download metadata.

### 2.3 WebUI duration labels

The frontend runtime model now preserves `durationSeconds`.

Browser media actions surface human-readable duration labels such as:

- `4.2s`
- `1s`

These labels appear in both:

- `BrowserPreview`;
- `LiveTimeline`.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Native recording persistence can carry best-effort `duration_seconds`.
2. Screenshot replay persistence carries deterministic replay duration.
3. Public session projection preserves both duration aliases.
4. Local settings/events projection preserves the same aliases.
5. WebUI media actions render duration when available.
6. Existing recording playback, source attribution, size labels, and engine
   labels stay intact.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- fps metadata;
- codec-level inspection beyond duration;
- native live capture for attached CDP user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/lib/formatDuration.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/formatDuration.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
