## External Browser Recording Playback Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the follow-on module that projects persisted external
browser recordings through the session control plane and renders them in the
WebUI.

It closes the next gap left by the recording baseline:

```text
external_browser_recording artifact exists
+ session-scoped/public-preview URL projection
+ session snapshot and SSE event projection
+ WebUI playback fallback when no live display is active
```

## 1. Module Goal

The recording baseline already persisted encrypted browser videos on terminal
close, but those artifacts still stopped at storage.

That left three control-plane gaps:

- `/api/sessions` and `/events` still exposed raw `artifact_path` in
  `media_artifacts` instead of a consumable download contract;
- the local settings/event server could serve the files, but did not project
  preview URLs for video artifacts;
- the WebUI browser panel could show live display, QR, or screenshot state, but
  could not play back the stored browser recording after terminal close.

## 2. Delivered Behavior

### 2.1 Session-scoped media artifact projection

Server-side session snapshots and SSE replay now rewrite event
`media_artifacts` through the same public artifact projection contract already
used for persisted result artifacts.

Each projected recording now carries:

- `download_url`
- `downloadUrl`
- `content_type`
- `contentType`
- `persisted=true` when backed by a stored artifact

The raw local `artifact_path` is no longer surfaced in the public session event
payload.

### 2.2 Local settings/events preview projection

The local settings/events server now treats `.webm` and `.mp4` as previewable
evidence assets for `/evidence?path=...`.

For local event-log replay and ledger-backed session snapshots, projected media
artifacts now gain preview URLs through the existing evidence reader so the
browser UI can render them without an authenticated session-artifact endpoint.

### 2.3 Frontend media event support

The frontend runtime model now understands:

- `media.persisted` -> `media_persisted`
- normalized `mediaArtifacts`

Those artifacts are preserved on the session timeline without corrupting the
transaction state.

If a session was already in `waiting_human`, `completed`, `failed`, or another
terminal-ish state, a later `media_persisted` event no longer resets the
session back to `running` or advances the payment stage incorrectly.

### 2.4 BrowserPreview playback fallback

`BrowserPreview` now renders state in this order:

1. session-scoped live display iframe
2. QR crop preview during QR human gate
3. latest persisted browser-recording video
4. latest screenshot
5. empty-state explanation

That means a finished or human-gated session can now show the real recorded
browser video in the WebUI even after the live browser has been released.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Session snapshots project persisted recording event artifacts to a
   consumable URL shape instead of exposing raw artifact paths.
2. SSE replay projects the same recording metadata contract.
3. The local settings/events preview server accepts browser recording preview
   suffixes and projects preview URLs for local media artifacts.
4. Frontend event parsing recognizes `media.persisted` and normalizes video
   artifact metadata.
5. `BrowserPreview` can render a persisted recording when no live display or QR
   image is active.
6. `media_persisted` replay does not regress a `waiting_human` or completed
   session back to the wrong stage or status.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/server.py payswitch/cli.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/lib/sessionModel.test.ts src/lib/sessionSnapshot.test.ts src/components/BrowserPreview.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- video recording for CDP-attached user Chrome sessions;
- timeline-native video scrubbers, thumbnails, or multi-recording selection UI;
- automatic promotion of a stored video artifact into a long-term external media
  CDN or signed URL service.

## 6. Implementation References

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/sessionModel.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionModel.ts)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
- [tests/test_ui_settings_api.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_ui_settings_api.py)
- [frontend/src/lib/eventStream.test.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.test.ts)
- [frontend/src/lib/sessionModel.test.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionModel.test.ts)
- [frontend/src/lib/sessionSnapshot.test.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionSnapshot.test.ts)
- [frontend/src/components/BrowserPreview.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.test.tsx)
