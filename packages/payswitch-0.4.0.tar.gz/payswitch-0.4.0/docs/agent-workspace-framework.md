# Pay-Switch Agent Workspace Framework

This document defines the target architecture for the next Pay-Switch development phase.
It is written as an implementation guide, not only as a product concept.

For the current-code alignment plan, phased delivery route, and acceptance bridge
from today's implementation to this target architecture, see
[docs/framework-alignment-roadmap.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/framework-alignment-roadmap.md).

当前目标不是把 Pay-Switch 做成单纯的网页自动化脚本，也不是做成全程由大模型慢慢点页面的 Computer Use 产品。目标是：

```text
用户级隔离容器 + 可学习快速 Adapter + Agent 异步监督与恢复 + Computer Use 兜底 + Human Gate 安全授权
```

Protocol support, including X402 or other merchant/payment protocols, is kept as a future extension route. It is not the current implementation priority.

## 1. Target Positioning

Pay-Switch is a payment execution control plane for external agents.

It receives a payment intent from Codex, Claude Code, another agent, or an API client, then executes the payment workflow under policy, audit, user authorization, and cost limits.

### 1.1 Current Main Line

The current main line is:

```text
Payment intent
-> User Workspace Container
-> Fast learned adapter recipe
-> Agent telemetry watchdog
-> Computer Use recovery if adapter breaks
-> Human Gate for sensitive/final action
-> Encrypted artifact and ledger
```

### 1.2 Future Protocol Line

Protocol support is a future fast path:

```text
Payment intent
-> Protocol Provider
-> signed order / verified callback / merchant API / X402-like flow
-> Human Gate if required
-> Encrypted artifact and ledger
```

This route should be designed into interfaces now, but it should not block the current adapter + Computer Use framework.

### 1.3 Non-Goals

Pay-Switch must not become:

- A shared remote desktop where all users fight over one browser.
- A brittle set of hardcoded Python scripts with selectors buried in code.
- A fully autonomous payment bot that can scan QR codes, enter OTPs, CVV, passwords, or click final payment confirmation without the user.
- A plaintext credential storage service.
- A model-only Computer Use system that burns tokens for every basic click.

## 2. Design Principles

### 2.1 Fast Path Must Stay Fast

Adapters are the fast path. They must not wait for Agent approval before every click.

The adapter should execute directly, emit telemetry at defined milestones, and stop only when:

- a waypoint assertion fails,
- a sensitive action is reached,
- a policy guard blocks execution,
- a site lock or session conflict is detected,
- budget or timeout limits are reached.

### 2.2 Agent Is the Supervisor and Recovery Brain

The Agent is not the clicker for every adapter step.

The Agent participates as:

| Role | Responsibility |
|---|---|
| Planner | Convert user intent into concrete payment goals and constraints. |
| Watchdog | Consume adapter telemetry asynchronously and detect drift, risk, or failure. |
| Recovery Agent | Take over through Computer Use only when the fast path fails. |
| Recipe Improver | Convert successful recovery into recipe patches or adapter update suggestions. |
| Auditor | Verify merchant, amount, plan, and final user handoff evidence. |

### 2.3 User Isolation First, Task Isolation Inside User Workspace

The recommended isolation unit is:

```text
One user = one User Workspace Container
One payment task = one logical Subagent session inside that user workspace
One site/task = one browser context or guarded tab session
```

This avoids the cost and login-state churn of one container per payment while still preventing different users from sharing browser state.

### 2.4 Persistent User Profile, Temporary Task Context

The user should not have to log in again for every payment task.

Recommended model:

```text
Persistent user profile vault
-> task-level browser context derived from the user's profile
-> task runs in isolated context
-> safe state changes may be merged back
-> failed/cancelled task context is discarded
```

For sites where browser context cannot safely share login state, use one site-specific profile under the user's profile vault.

Important implementation correction:

```text
Do not implement file-level profile merge.
Browser profile stores cookies, local storage, IndexedDB, cache, and SQLite files.
They cannot be merged safely after two concurrent task copies diverge.
```

Use **profile promotion** instead:

```text
copy stable profile -> task profile
run task against task profile
if task succeeds and profile state should be kept:
  atomically replace the stable profile with the task profile
if task fails or is cancelled:
  delete the task profile
```

For V1, because promotion overwrites the stable profile, only one active payment task may mutate the same site profile at a time.

### 2.5 Sensitive Actions Always Belong to the User

Agent and adapter may prepare the page, verify the page, and surface the right state.

They must not perform:

- QR code scan,
- OTP input,
- payment password input,
- CVV/CVC input,
- final irreversible confirmation,
- consent to a recurring subscription if the user has not explicitly approved it.

Those actions must enter Human Gate.

## 3. System Overview

### 3.1 Architecture Diagram

```mermaid
flowchart TD
  U["用户 / User"] --> Client["外部 Agent 或 WebUI / External Agent or WebUI"]
  Client --> CP["控制平面 / Control Plane"]

  CP --> Auth["身份与权限 / Auth and Policy"]
  CP --> Budget["成本预算 / Cost Budget"]
  CP --> Registry["经验库 / Experience Registry"]
  CP --> Ledger["账本与审计 / Ledger and Audit"]
  CP --> Router["任务路由 / Task Router"]

  Router --> UWC["用户工作区容器 / User Workspace Container"]

  UWC --> PM["Profile 管理 / Profile Manager"]
  UWC --> BM["浏览器管理 / Browser Manager"]
  UWC --> SM["Subagent 管理器 / Subagent Manager"]
  UWC --> VNC["noVNC 网关 / noVNC Gateway"]

  SM --> TS["支付任务 Subagent / Payment Task Subagent"]

  TS --> Plan["意图规划 / Intent Planning"]
  Plan --> Recipe["快速 Adapter Recipe / Fast Learned Adapter"]
  Recipe --> Telemetry["里程碑留档 / Milestone Telemetry"]
  Telemetry --> Watchdog["Agent 监督器 / Agent Watchdog"]

  Recipe -->|敏感动作 / Sensitive Action| Gate["人工授权 / Human Gate"]
  Recipe -->|非敏感成功 / Non-sensitive Success| Extract["结果提取 / Result Extraction"]
  Recipe -->|失败 / Failure| CU["Computer Use 恢复 / Computer Use Recovery"]
  Watchdog -->|发现漂移 / Drift detected| CU

  CU -->|恢复成功 / Recovered| Patch["经验修复建议 / Recipe Patch"]
  Patch --> Registry
  Patch --> Recipe

  Gate --> Extract["结果提取 / Result Extraction"]
  Extract --> Encrypt["加密产物 / Encrypted Artifact"]
  Encrypt --> Ledger

  PM --> Vault["用户 Profile Vault / User Profile Vault"]
  BM --> Context["任务 Browser Context / Task Browser Context"]
```

### 3.2 Runtime Isolation Diagram

```mermaid
flowchart TD
  UserA["用户 A / User A"] --> C1["用户容器 A / User Workspace A"]
  UserB["用户 B / User B"] --> C2["用户容器 B / User Workspace B"]

  C1 --> AProfile["A Profile Vault / A 登录态保险库"]
  C2 --> BProfile["B Profile Vault / B 登录态保险库"]

  C1 --> ASessionMgr["A Session Manager / A 会话管理"]
  C2 --> BSessionMgr["B Session Manager / B 会话管理"]

  ASessionMgr --> ATask1["Kimi Task Subagent / Kimi 任务"]
  ASessionMgr --> ATask2["Jimeng Task Subagent / 即梦任务"]
  BSessionMgr --> BTask1["Kimi Task Subagent / Kimi 任务"]

  ATask1 --> ACtx1["Browser Context A1 / 浏览器上下文 A1"]
  ATask2 --> ACtx2["Browser Context A2 / 浏览器上下文 A2"]
  BTask1 --> BCtx1["Browser Context B1 / 浏览器上下文 B1"]

  ATask1 --> ALock1["Site Lock: kimi / 站点锁 kimi"]
  ATask2 --> ALock2["Site Lock: jimeng / 站点锁 jimeng"]
  BTask1 --> BLock1["Site Lock: kimi / 站点锁 kimi"]
```

### 3.3 Execution State Machine

```mermaid
stateDiagram-v2
  [*] --> Received: 收到意图 / Intent received
  Received --> GuardCheck: 风控和预算检查 / Guard and budget check
  GuardCheck --> ResolveIntent: 解析购买目标 / Resolve payment goal
  ResolveIntent --> AcquireWorkspace: 获取用户容器 / Acquire user workspace
  AcquireWorkspace --> AcquireProfile: 获取用户 Profile / Acquire user profile
  AcquireProfile --> AcquireSiteLock: 获取站点锁 / Acquire site lock
  AcquireSiteLock --> RunAdapter: 快速 Adapter / Fast adapter

  RunAdapter --> HumanGate: 敏感动作 / Sensitive action
  RunAdapter --> Recovery: waypoint 失败 / waypoint failed
  RunAdapter --> ExtractResult: 非敏感成功 / non-sensitive success

  Recovery --> VerifyState: Agent 校验当前页面 / Agent verifies page
  VerifyState --> ComputerUse: Computer Use 恢复 / Computer Use recovery
  ComputerUse --> HumanGate: 敏感动作 / sensitive action
  ComputerUse --> RecipePatch: 恢复并更新经验 / recovered and patch
  ComputerUse --> ExtractResult: 恢复且任务完成 / recovered and done
  ComputerUse --> Failed: 恢复失败 / recovery failed

  RecipePatch --> RunAdapter: 继续快速路径 / resume fast path
  HumanGate --> ExtractResult: 用户完成 / user completes action
  HumanGate --> Paused: 超时或用户离开 / timeout or user leaves
  Paused --> AcquireWorkspace: 恢复任务 / resume

  ExtractResult --> EncryptArtifact: 加密产物 / encrypt artifact
  EncryptArtifact --> Ledger: 写入账本 / write ledger
  Ledger --> Cleanup: 清理证据 / evidence cleanup
  Cleanup --> Completed
  Failed --> Cleanup
  Completed --> [*]
```

## 4. Core Components

### 4.1 Control Plane

The Control Plane owns user-facing APIs, authentication, policy, task routing, ledger, and session visibility.

Required responsibilities:

- Accept payment intent from CLI, agent plugin, REST API, or WebUI.
- Authenticate the caller with scoped tokens.
- Resolve the user identity and target user workspace.
- Enforce amount, merchant, currency, and live-execution policy.
- Assign task id, session id, idempotency key, and trace id.
- Issue short-lived noVNC/session access tokens.
- Persist high-level event stream and ledger entries.
- Store only encrypted sensitive artifacts.
- Expose all active sessions for the current user in the WebUI.

Suggested implementation:

- Keep FastAPI or current Python server as the initial API surface.
- Introduce a Task Router service boundary, even if implemented in-process first.
- Use typed event objects for session telemetry instead of ad-hoc dictionaries.
- Store persistent task/session metadata in SQLite initially, then PostgreSQL when multi-node deployment is required.

### 4.2 User Workspace Container

The User Workspace Container is the execution boundary for one user.

It contains:

- browser runtime,
- profile vault mount,
- Xvfb or display server,
- noVNC bridge,
- Subagent Manager,
- local telemetry buffer,
- cleanup worker,
- internal task API.

Required properties:

- One user container must never mount another user's profile volume.
- Only the Control Plane can call its internal API.
- noVNC access must go through a signed, scoped proxy route.
- It must support idle sleep and later resume.
- It must expose health, active sessions, memory usage, browser contexts, and profile state.
- The first single-node runtime must enforce host-level admission control. If the maximum active workspace count or memory budget is reached, new workspaces must queue or fail with typed capacity status instead of spawning containers until host exhaustion.

Suggested implementation path:

1. Start with Docker Compose on one server.
2. Use one container per user for runtime isolation.
3. Use local persistent volumes for profile vaults.
4. Move to Kubernetes or Nomad only after the single-node orchestration works.
5. Add a warm workspace pool later if container cold start becomes visible to users.

### 4.3 Subagent Manager

The Subagent Manager runs inside the User Workspace Container.

It owns logical payment sessions for that user.

Responsibilities:

- Start, stop, pause, resume, and list payment task subagents.
- Allocate browser contexts or guarded tabs.
- Enforce per-site locks.
- Maintain telemetry buffers for each session.
- Route noVNC foreground focus to the selected session.
- Enforce task budget, timeouts, and cleanup.

Important distinction:

```text
Subagent is a logical payment worker.
Container is the user isolation boundary.
Browser context is the task execution surface.
Profile vault is the user's persistent login state.
```

### 4.4 Browser Manager

Browser Manager owns visible and controllable browser surfaces.

Required capabilities:

- Create or attach to browser runtime.
- Create a task-level browser context.
- Bring a task context/tab to the foreground when the user selects a session.
- Provide screenshots for telemetry.
- Provide DOM summaries for recipe assertions.
- Support noVNC display for human intervention.
- Support safe shutdown and context cleanup.

Recommended rule:

- V1 strict rule: one user workspace may execute only one active payment task that can enter Computer Use or Human Gate at a time.
- Same user, same site, same profile: always one active payment task at a time.
- Same user, different sites: may run concurrently only for pure adapter execution that does not need visible Computer Use.
- Different users: always separated by container and profile volume.

Reason:

```text
Computer Use sees and clicks the active Xvfb/noVNC display.
If two tasks render on the same display, Computer Use can screenshot or click the wrong browser window.
```

Therefore V1 must prefer correctness over concurrency:

- When a task is in Computer Use, pause or queue other visible tasks in the same user workspace.
- Before every Computer Use screenshot/action, Browser Manager must hold a `display_focus_lock`.
- Browser Manager must bring the target task window/tab to the foreground and verify the active window belongs to the target session.
- Browser Manager must enforce window z-order during foreground lease. Background adapter tasks in the same workspace must not raise or steal the visible window over the foreground session.
- If a task cannot guarantee hidden/background-safe execution while another session owns the foreground lease, it must be queued or paused.
- If foreground verification fails, Computer Use must not act.

Future V2 may support higher concurrency only if the runtime provides one of:

- one display per active task,
- reliable window-manager isolation and focus verification,
- browser-level screenshot/action APIs that do not depend on shared X11 coordinates.

### 4.5 Profile Manager

Profile Manager owns persistent login state.

Recommended layout:

```text
profile-vault/
  user_<user_id>/
    default/
    kimi/
    jimeng/
    qwen/
    metadata.json
```

`metadata.json` should track:

- profile id,
- site id,
- expected login identity if known,
- last verified login time,
- last used task id,
- encryption metadata,
- browser engine version,
- profile schema version,
- dirty/clean status.

Rules:

- A profile cannot be shared across users.
- A task may use a derived task context from a profile.
- Failed task context should be discarded unless explicitly marked safe.
- Successful login/session updates must use profile promotion, not profile merge.
- A profile must be lockable during sensitive flows to prevent concurrent corruption.
- Browser engine version and profile schema version must be checked before opening a stable profile. A mismatch must enter migration, copy-on-write, or fail-closed state; it must not silently write into the stable profile.
- If profile schema compatibility fails closed, the user/client error must distinguish transient runtime failure from permanent profile incompatibility so operators know whether to retry, migrate, or reset the profile.

Profile promotion requirements:

- The source profile must be quiesced before copy.
- The task profile must be written in a separate directory.
- Promotion must be atomic: move current stable profile to backup, move task profile to stable path, then remove backup after verification.
- If promotion fails, rollback to the previous stable profile.
- Promotion must verify browser shutdown and absence of SQLite lock files.
- Graceful browser shutdown is preferred first, but profile promotion must escalate to force-terminating all browser processes that still hold the profile if lock files or file handles remain.
- Promotion must record old profile hash, new profile hash, task id, and timestamp.
- Two promotions for the same user/site profile must never run concurrently.

### 4.6 Experience Registry

Experience Registry stores learned adapter recipes and their validation history.

It should store:

- payee/site id,
- task type,
- recipe version,
- supported locales,
- supported plan names,
- semantic waypoints,
- selectors and text candidates,
- visual anchors if needed,
- assertions,
- fallback policy,
- last success/failure metadata,
- confidence score,
- owner/reviewer,
- test fixtures.

Recipe patch lifecycle:

```text
computer_use recovery patch
-> candidate
-> shadow_run
-> reviewed
-> mainline
```

Recovery-generated recipe patches must not update the main fast path directly. They must pass a shadow run or explicit review before promotion to `mainline`.

Shadow-run safety:

- Prefer dry or non-mutating browser contexts when the site supports them.
- If the site cannot support dry validation, use a dedicated sandbox profile or test account.
- A shadow run must not use the user's stable payment profile unless the validation is read-only and explicitly marked safe.

Example recipe:

```yaml
payee: kimi
task: subscribe_monthly
version: 2026-05-15
status: candidate
confidence: 0.72

waypoints:
  - id: open_home
    intent_zh: 打开 Kimi 官网
    intent_en: Open Kimi homepage
    action:
      type: goto
      url: https://www.kimi.com/
    assert:
      any_visible_text: ["登录", "会员", "升级", "充值", "Kimi"]

  - id: check_login
    intent_zh: 检查是否已登录
    intent_en: Check login state
    action:
      type: inspect
    assert:
      login_state_known: true
    on_fail: human_login_gate

  - id: find_subscription_entry
    intent_zh: 找到会员或充值入口
    intent_en: Find subscription or recharge entry
    action:
      type: click_semantic
      candidates: ["会员", "升级", "订阅", "充值", "Pro"]
    assert:
      any_visible_text: ["月", "套餐", "支付", "订阅"]

  - id: select_monthly_plan
    intent_zh: 选择月付套餐
    intent_en: Select monthly plan
    action:
      type: click_plan
      constraints:
        billing_cycle: monthly
        price_hint_cny: 49
    assert:
      amount_matches_intent: true

  - id: reach_payment_qr
    intent_zh: 到达付款二维码
    intent_en: Reach payment QR
    action:
      type: wait_for_payment_surface
    assert:
      qr_visible: true
      merchant_matches: kimi
      amount_matches_intent: true

fallback:
  selector_not_found: computer_use
  assertion_failed: computer_use
  login_required: human_gate
  sensitive_final_action: human_gate

retention:
  keep_success_screenshots: 5
  keep_failure_screenshots_hours: 72
```

### 4.7 Recipe Runner

Recipe Runner executes recipes without waiting for Agent approval per step.

Required behavior:

- Resolve semantic actions into concrete browser actions.
- Execute actions at near-script speed.
- Emit telemetry before and after major waypoints.
- Validate waypoint assertions.
- Stop immediately on sensitive or uncertain states.
- Return structured failure reasons.

Telemetry is asynchronous only for successful waypoint observation. It is synchronous at failure boundaries.

Required failure behavior:

```text
if a waypoint assertion fails:
  stop adapter immediately
  capture screenshot immediately
  capture DOM and visible text immediately
  lock the session
  emit failed waypoint telemetry
  hand control to Agent Watchdog
```

The adapter must not continue to the next waypoint while the previous waypoint's required assertions are pending or failed.

Each waypoint event should include:

```json
{
  "type": "waypoint.result",
  "session_id": "psw_xxx",
  "waypoint_id": "reach_payment_qr",
  "status": "passed",
  "url": "https://...",
  "title": "Kimi",
  "screenshot_ref": "artifact://...",
  "dom_hash": "sha256:...",
  "visible_text_hash": "sha256:...",
  "action_target": {
    "selector": "button[data-testid='subscribe']",
    "text": "订阅",
    "bounding_box": {"x": 612, "y": 421, "width": 132, "height": 40}
  },
  "duration_ms": 1234,
  "risk_flags": [],
  "assertions": [
    {"name": "qr_visible", "passed": true},
    {"name": "amount_matches_intent", "passed": true}
  ]
}
```

`bounding_box` is mandatory when the action interacted with a visible DOM element. The Watchdog uses it to explain to Computer Use what the recipe clicked and to overlay recovery context on screenshots.

### 4.8 Agent Watchdog

Agent Watchdog consumes telemetry asynchronously.

It must not block fast adapter execution unless:

- a high-risk event is detected,
- adapter emits an uncertain state,
- an assertion fails,
- policy requires pre-human-gate verification,
- cost or timeout threshold is near exhaustion.
- a recipe waypoint is marked `synchronous_policy_checkpoint`.

Watchdog responsibilities:

- Maintain a rolling buffer of the last N telemetry events.
- Detect page drift and recipe mismatch.
- Classify failure type.
- Decide whether to retry adapter, enter Computer Use, or require Human Gate.
- Produce recipe patch suggestions after successful recovery.

Recommended rolling buffer:

```text
last 5 waypoint events
last 3 screenshots
current DOM summary
current visible text summary
last action and assertion failure
```

Stale-context rule:

```text
if task is paused or disconnected beyond telemetry_ttl:
  discard trusted rolling-buffer state
  re-synchronize current URL, screenshot, DOM summary, and visible text
  only then continue watchdog classification or Computer Use recovery
```

High-risk sites or waypoints may require `synchronous_policy_checkpoint: true`. That keeps the default fast path asynchronous while still allowing the adapter to block before amount confirmation, merchant confirmation, subscription agreement confirmation, or entering a payment surface.

Default `telemetry_ttl` is 5 minutes. Site adapters may lower it for sensitive surfaces, but they must not silently extend it beyond the default for payment pages, QR pages, OTP pages, or subscription-confirmation pages.

### 4.9 Computer Use Recovery

Computer Use is the recovery path, not the default path.

Before taking any action, Computer Use must:

1. Verify current page state.
2. Compare current state with failed waypoint intent.
3. Explain intended next action.
4. Respect sensitive-action boundaries.
5. Execute a bounded number of actions.
6. Emit telemetry for each action.

Hard limits:

- maximum recovery steps per task,
- maximum screenshots per recovery,
- maximum model tokens/cost,
- maximum wall time,
- maximum retries per failed waypoint.

Recovery output:

```json
{
  "recovered": true,
  "failed_waypoint": "find_subscription_entry",
  "new_observation": "subscription entry moved under avatar menu",
  "actions_taken": ["click avatar", "click membership"],
  "recipe_patch": {
    "waypoint_id": "find_subscription_entry",
    "add_candidates": ["头像菜单 > 会员中心"]
  }
}
```

### 4.10 Human Gate

Human Gate is the user handoff layer.

It should support:

- QR scan,
- login required,
- OTP,
- CVV/CVC,
- payment password,
- final confirmation,
- subscription agreement confirmation,
- account selection.

Required UI behavior:

- Show selected session clearly.
- Show merchant, amount, currency, plan, and reason.
- Show why human input is required.
- Show the live browser if available.
- Provide short-lived noVNC access.
- Do not imply the Agent will complete the sensitive action.

Human Gate states:

```text
waiting_user
user_connected
user_action_detected
handoff_complete
expired
cancelled
```

Timeout behavior:

- If no user connects within the configured window, pause the task.
- If user connects but no action occurs for too long, pause or expire based on policy.
- Paused tasks must preserve enough state to resume without leaking sensitive screenshots indefinitely.

## 5. Data Model

### 5.1 Payment Task

Required fields:

```text
task_id
session_id
user_id
source_agent_id
payee
amount
currency
reason
method
status
state_machine_state
idempotency_key
created_at
updated_at
budget_limit
timeout_limit
human_gate_required
ledger_entry_id
artifact_refs
```

### 5.2 User Workspace

Required fields:

```text
workspace_id
user_id
container_id
status
last_active_at
display_url
vnc_route
profile_vault_path
active_sessions
resource_usage
sleep_policy
```

### 5.3 Subagent Session

Required fields:

```text
session_id
task_id
user_id
site_id
profile_id
browser_context_id
site_lock_id
status
current_waypoint
telemetry_buffer_ref
human_gate_state
novnc_token_id
cost_used
created_at
updated_at
```

### 5.4 Evidence Artifact

Required fields:

```text
artifact_id
task_id
session_id
type
classification
storage_tier
encrypted
redacted
hash
created_at
expires_at
retention_policy
```

Artifact classifications:

| Classification | Examples | Storage rule |
|---|---|---|
| public | generic UI screenshot without account/payment info | may be stored short term |
| internal | DOM summary, action log | stored with normal retention |
| sensitive | QR, account identity, token, API key, cookie, payment page | encrypt and short retention |
| secret | API key, cookie, session token | end-to-end encrypted only |

## 6. API and Event Contracts

### 6.1 Create Payment

```http
POST /api/payments
Authorization: Bearer <agent_or_user_token>
Content-Type: application/json
```

Request:

```json
{
  "payee": "kimi",
  "amount": 49,
  "currency": "CNY",
  "reason": "Kimi monthly membership",
  "method": "alipay_qr",
  "execute": true,
  "user_id": "usr_xxx",
  "client_public_key": "base64...",
  "budget": {
    "max_cost_usd": 0.3,
    "max_recovery_steps": 8,
    "max_wall_seconds": 300
  }
}
```

Response:

```json
{
  "task_id": "psw_xxx",
  "session_id": "pss_xxx",
  "status": "running",
  "events_url": "/api/sessions/pss_xxx/events",
  "dashboard_url": "/pay-switch?s=pss_xxx"
}
```

### 6.2 List User Sessions

```http
GET /api/sessions?status=active
Authorization: Bearer <user_token>
```

The WebUI must show every active session for the current user. The default `/pay-switch` page must not randomly show another user's session.

### 6.3 Open Human Gate

```http
POST /api/sessions/{session_id}/human-gate
Authorization: Bearer <user_token>
```

Response:

```json
{
  "session_id": "pss_xxx",
  "state": "waiting_user",
  "merchant": "kimi",
  "amount": 49,
  "currency": "CNY",
  "reason": "Kimi monthly membership",
  "novnc_url": "https://.../vnc/pss_xxx?token=...",
  "expires_at": "2026-05-15T12:00:00Z"
}
```

### 6.4 Resume Human Gate From Another Device

Human Gate may move from the original agent device to a phone or another browser. Artifact encryption must account for that.

```http
POST /api/sessions/{session_id}/human-gate/resume
Authorization: Bearer <user_token>
Content-Type: application/json
```

Request:

```json
{
  "client_public_key": "base64-new-device-public-key",
  "replace_artifact_key": true
}
```

Rules:

- If the finishing device needs to decrypt the final artifact, it may provide a new public key.
- Key replacement must be recorded in audit events.
- Existing encrypted artifacts are not automatically re-encrypted unless policy explicitly allows it.
- The final artifact must be encrypted with the active public key at extraction time.

### 6.5 Event Types

Required event types:

```text
task.created
workspace.acquired
profile.acquired
site_lock.acquired
adapter.started
waypoint.started
waypoint.result
adapter.failed
watchdog.observed
computer_use.started
computer_use.action
computer_use.recovered
human_gate.opened
human_gate.user_connected
human_gate.handoff_complete
artifact.encrypted
ledger.written
cleanup.completed
task.completed
task.failed
task.paused
```

## 7. Technology Stack

### 7.1 Current Recommended Stack

| Area | Recommended technology | Purpose |
|---|---|---|
| API server | FastAPI / current Python server | Keep current development speed and existing code compatibility. |
| Runtime worker | Python async worker | Reuse current orchestrator, adapter, and browser controller logic. |
| Browser automation | Playwright-compatible browser controller | Support contexts, screenshots, DOM, CDP, and existing adapter behavior. |
| Anti-detection engine | CloakBrowser where needed | Reduce bot-detection issues on hostile checkout pages. |
| Display | Xvfb per user workspace | Visible browser for noVNC and human gate. |
| Remote view | noVNC behind signed proxy | Human takeover and session visibility. |
| Dynamic routing | Traefik with Docker labels first, Nginx/Lua or Envoy later | Route `/vnc/{session_id}` to the correct workspace without proxy restart. |
| Container runtime | Docker Compose first, Kubernetes/Nomad later | Start simple, move to autoscaling after one-node model works. |
| State DB | SQLite first, PostgreSQL later | Keep local iteration fast, prepare for multi-node. |
| Event stream | SSE initially, Redis Streams/NATS later | WebUI session updates and telemetry bus. |
| Artifact storage | local encrypted files first, S3-compatible later | Evidence and encrypted outputs. |
| Encryption | libsodium / age / NaCl sealed boxes | Client-key artifact encryption. |
| WebUI | existing React frontend | Session list, selected session view, human gate UI. |

### 7.2 Why Not Kubernetes First

Kubernetes is useful later for autoscaling and isolation, but it adds operational complexity too early.

Recommended order:

```text
single server Docker Compose
-> user container manager
-> persistent volumes
-> signed noVNC proxy
-> metrics and cleanup
-> Kubernetes/Nomad after runtime contract stabilizes
```

### 7.3 Dynamic noVNC Routing

Docker Compose alone does not solve dynamic routing for per-user containers. A reverse proxy is mandatory.

V1 recommendation:

```text
Traefik watches Docker labels
-> User Workspace Container starts with labels for user/session route
-> Control Plane issues short-lived noVNC token
-> browser connects to https://host/vnc/{session_id}?token=...
-> Traefik routes to the workspace noVNC service
```

Required behavior:

- Starting a new user workspace must not require restarting the proxy.
- Removing a workspace must revoke its route.
- The proxy must validate or delegate validation of noVNC tokens.
- The route must bind to user id and session id.
- A route lookup failure must show a clear "session display unavailable" state, not a blank screen.

Alternative V2:

- Nginx with Lua querying Redis/Control Plane for `session_id -> upstream`.
- Envoy dynamic discovery service.
- Kubernetes ingress with per-workspace service labels.

## 8. Security Model

### 8.1 Token Scope

Use separate token types:

| Token | Scope |
|---|---|
| agent token | submit payment intent for allowed user/workspace only |
| user token | view and operate current user's sessions |
| novnc token | access one session's display for a short time |
| workspace token | internal Control Plane to User Workspace call |
| artifact key | encrypt output for the user/client |

No token should grant global access to all sessions or all users.

### 8.2 noVNC Security

Required:

- noVNC routes must be signed and short-lived.
- Route must bind to `user_id` and `session_id`.
- A noVNC URL for User A must not show User B's container.
- Expired noVNC token must stop new connections.
- Existing VNC connections must be dropped when a session is cancelled or expires.

### 8.3 Artifact Encryption

For API keys, cookies, profile exports, and any credential-like result:

```text
client generates key pair
-> client sends public key in task request
-> sandbox extracts artifact
-> sandbox encrypts artifact before leaving container
-> Control Plane stores ciphertext only
-> client decrypts locally
```

Device switching rule:

```text
If Human Gate is resumed from another device, the finishing device may provide a new client public key.
The final artifact is encrypted with the active public key at extraction time.
```

Acceptance rule:

```text
If the server database or logs contain plaintext API keys, session cookies, OTPs, CVV, passwords, or payment credentials, the implementation fails.
```

### 8.4 Profile Security

Required:

- profile vault per user,
- file permissions restricted to the runtime user/container,
- no cross-user volume mount,
- profile lock during sensitive flows,
- profile metadata without secrets,
- optional at-rest encryption for production.

## 9. Evidence, Retention, and Cleanup

Evidence is required for audit and recovery, but it must not become permanent sensitive storage.

### 9.1 Evidence Tiers

| Tier | Content | Storage | Retention |
|---|---|---|---|
| Hot | raw screenshots, DOM snapshots, action logs during execution | container tmpfs/RAM disk | task duration |
| Warm | key waypoint screenshots, final QR/handoff screenshot, failure screenshots | encrypted artifact store | 24-72 hours |
| Cold | semantic action log, hashes, ledger fields, final result summary | database | long term |

### 9.2 Cleanup Rules

Success task:

- keep semantic log,
- keep final result summary,
- keep at most 3-5 key screenshots,
- delete raw full-frame screenshots after task completion or short TTL.

Failed task:

- keep failure screenshots for debugging,
- keep telemetry buffer for limited TTL,
- encrypt or redact sensitive screenshots,
- delete raw artifacts after 72 hours unless manually pinned.

Human Gate:

- QR/payment page screenshots are sensitive.
- Store encrypted or redact by default.
- Do not keep raw QR images indefinitely.

## 10. Cost Control

### 10.1 Cost Strategy

Cost control comes from routing:

```text
Fast recipe success = almost no model cost
Waypoint telemetry = bounded storage cost
Watchdog = asynchronous, sampled, cheap
Computer Use = only on failure
Human Gate = pause model execution
```

### 10.2 Required Limits

Each task must have:

- max wall time,
- max adapter retries,
- max Computer Use recovery steps,
- max model tokens/cost,
- max screenshots,
- max noVNC idle time,
- max human gate waiting time.

### 10.3 Workspace Sleep Policy

User workspace containers must support sleep:

```text
if no active task and no noVNC connection for N minutes:
  flush profile changes
  persist workspace metadata
  stop browser
  stop container
```

Wake behavior:

```text
new task or user opens dashboard
-> start user workspace
-> mount profile vault
-> restore browser/runtime
```

## 11. Development Phases

### Phase 1: Session Visibility and User Runtime Boundary

Goal:

Fix the current shared-screen confusion and make every running task visible and selectable.

Implementation:

- Add user-aware session list API.
- WebUI defaults to current user's active sessions, not global latest session.
- Session selection must switch event stream and display state.
- Introduce a runtime abstraction for user workspace, even if it still maps to local process initially.
- Add display/session ownership metadata.

Acceptance criteria:

- Two sessions from the same user are listed separately.
- Selecting a session shows that session's state, not a random global state.
- A session with no display shows a clear state explaining why.
- Global `/pay-switch` must not leak or randomly display another user's session.

### Phase 2: User Workspace Container Prototype

Goal:

Move from shared `:99` runtime to user-level isolated runtime.

Implementation:

- Implement User Workspace Manager.
- Allocate one workspace per user.
- Mount per-user profile vault.
- Run browser/display/noVNC inside the workspace.
- Proxy noVNC through scoped route.
- Add workspace health endpoint.
- Add idle timeout, cleanup, and sleep policy as part of the runtime lifecycle, not as a later optional optimization.
- Add host-level admission control for active and warm user workspaces.

Acceptance criteria:

- User A and User B cannot see each other's noVNC.
- User A and User B can run different tasks simultaneously without display conflict.
- Stopping User A workspace does not affect User B.
- Restarting User A workspace preserves login state.
- Dynamic reverse proxy routes to a newly created User Workspace Container without restarting the proxy.
- noVNC route removal or token expiry prevents new connections to the stopped/expired workspace.
- Idle workspaces can sleep or clean up without exhausting host memory during multi-user test runs.
- Capacity exhaustion queues or rejects new workspace creation with typed status, and does not continue spawning containers until host OOM.

### Phase 3: Logical Subagent Sessions

Goal:

Make each payment task a logical subagent inside the user workspace.

Implementation:

- Add Subagent Manager inside workspace.
- Each payment task gets session id, browser context id, site lock id, telemetry buffer.
- Add site lock policy.
- Add pause/resume/cancel for session.

Acceptance criteria:

- Same user can list multiple active task sessions.
- Same site cannot run conflicting payment tasks on the same profile unless policy allows it.
- V1 concurrency is strictly managed: if a task may enter Computer Use or Human Gate, other visible tasks in the same workspace are queued or paused.
- If future concurrent visible tasks are enabled, focus locking proves Computer Use cannot act on the wrong browser window.
- Different site tasks can run concurrently only when contexts are isolated and display-focus policy is satisfied.
- Cancelling a task releases browser context and site lock.
- Profile promotion rollback is tested by injecting a promotion failure and verifying the prior stable profile is restored.

### Phase 4: Recipe Runner and Experience Registry

Goal:

Convert adapters from brittle code into learned, inspectable, versioned recipes.

Implementation:

- Define recipe schema.
- Build Recipe Runner.
- Convert Kimi path into recipe-backed adapter.
- Store recipe execution metrics.
- Add recipe version and confidence score.
- Store recovery-generated recipe patches as candidates until shadow-run validation or explicit review.

Acceptance criteria:

- Kimi normal path runs through recipe with telemetry.
- Successful recipe path does not require per-step Agent approval.
- Recipe failure returns a structured failed waypoint.
- Recipe can be updated without changing core orchestration code.
- Computer Use-generated recipe patches cannot affect the mainline recipe until promoted from candidate through shadow-run or review.

### Phase 5: Agent Watchdog and Computer Use Recovery

Goal:

Use Agent intelligently without destroying adapter speed.

Implementation:

- Add telemetry buffer.
- Add Watchdog process/thread.
- Add Computer Use recovery entrypoint that receives failed waypoint context.
- Add recipe patch output from recovery.
- Add recovery budgets.
- Add synchronous policy checkpoints for high-risk waypoints.
- Add stale rolling-buffer re-synchronization after pause/resume timeout.

Acceptance criteria:

- When a selector fails, Agent receives the last telemetry context.
- Computer Use verifies page state before acting.
- Recovery stops at Human Gate for sensitive actions.
- Successful recovery emits a recipe patch suggestion.
- Recovery cannot exceed configured budget.
- High-risk waypoints can block adapter progress until policy verification passes.
- Resumed tasks with stale telemetry must re-synchronize page state before recovery continues.

### Phase 6: Security and Artifact Encryption

Goal:

Protect login state, noVNC access, and extracted credentials.

Implementation:

- Add scoped tokens.
- Add signed noVNC URLs.
- Add client public key support.
- Add encrypted artifact writer.
- Add artifact classification and retention policy.

Acceptance criteria:

- noVNC URL for one session cannot access another session.
- Server DB does not store plaintext API keys or cookies.
- Sensitive screenshots are encrypted or redacted.
- Expired token blocks new VNC connections.

### Phase 7: Cleanup, Sleep, and Cost Controls

Goal:

Make runtime cost predictable.

Implementation:

- Add task budget enforcement.
- Add screenshot limit and retention worker.
- Add workspace idle sleep.
- Add workspace wake path.
- Add metrics for token, screenshot, wall time, and container memory.

Acceptance criteria:

- Idle workspace stops after policy timeout.
- Profile persists across workspace sleep/wake.
- Successful task stores no more than configured screenshot limit.
- Failed task artifacts expire automatically.
- Budget exceeded returns clear task status.

### Phase 8: Protocol Provider Interface

Goal:

Prepare future Protocol route without blocking current work.

Implementation:

- Define `ProtocolProvider` interface.
- Add capability discovery.
- Add signed callback verification contract.
- Do not require implementation for Kimi/Jimeng path.

Acceptance criteria:

- Code can register a future protocol provider.
- Router can choose protocol when available.
- Adapter route remains default when no provider exists.

## 12. Engineering Standards

### 12.1 Adapter and Recipe Standards

Every adapter/recipe must declare:

- supported payee,
- task type,
- supported plans or amount rules,
- login preflight,
- waypoints,
- assertions,
- sensitive action boundaries,
- fallback policy,
- telemetry requirements,
- test fixtures.

### 12.2 Test Standards

Required tests:

- recipe schema validation,
- recipe runner waypoint success/failure,
- site lock behavior,
- session list filtering by user,
- noVNC token scoping,
- artifact retention classification,
- Computer Use recovery budget limit,
- Human Gate transition,
- profile lock and cleanup.
- profile promotion rollback on move/lock failure.
- profile schema compatibility checks before stable profile write.
- host-level admission control under multi-user capacity pressure.
- recipe patch candidate/shadow-run promotion.
- stale watchdog context re-synchronization.

### 12.3 Runtime Verification

Before claiming a feature works, verify:

- API behavior with real task/session ids,
- WebUI shows correct session,
- noVNC connects to selected session,
- task events stream correctly,
- profile persists across restart,
- cleanup removes expired artifacts,
- logs do not contain plaintext secrets.

## 13. Definition of Done

The architecture is considered implemented only when:

1. Multi-user display isolation works.
2. User profile persists across tasks.
3. WebUI can list and switch all current user's sessions.
4. Kimi runs through recipe fast path without per-step Agent approval.
5. Adapter failure triggers Agent + Computer Use recovery with context.
6. Sensitive actions enter Human Gate.
7. noVNC access is scoped to one user/session.
8. Evidence retention and cleanup are enforced.
9. Secret artifacts are encrypted before leaving the workspace.
10. Runtime cost limits are enforced and visible in task status.
11. Computer Use cannot run against the wrong window on a shared display.
12. Profile promotion safely replaces the persistent profile without SQLite lock errors or file corruption, and successfully rolls back to the prior stable state if a failure or lock error occurs during promotion.
13. Dynamic noVNC routing works for newly created user workspaces without proxy restart.
14. Human Gate device switching can update the active artifact encryption public key.

## 14. Immediate Next Development Tasks

Recommended first implementation batch:

1. Add user/session ownership to task events and WebUI session list.
2. Stop global/latest-session display behavior.
3. Introduce `WorkspaceRuntime` abstraction.
4. Add per-session display URL ownership and scoped display state.
5. Define recipe schema and convert Kimi into recipe-backed execution.
6. Add telemetry buffer for recipe waypoints.
7. Add explicit failed-waypoint recovery API for Computer Use.

Recommended first acceptance demo:

```text
User A starts Kimi task.
User A starts Jimeng task.
WebUI lists both sessions.
Selecting Kimi shows Kimi session state.
Selecting Jimeng shows Jimeng session state.
Kimi adapter reaches QR through recipe fast path.
A deliberately broken Kimi waypoint triggers Computer Use recovery.
Computer Use stops at QR Human Gate.
Artifacts are cleaned according to policy.
```

## 15. Gemini Review Summary

The revised architecture was reviewed with Gemini as:

```text
Approved with reservations.
```

Gemini agreed with the move from task-per-container to user-workspace-container because it reduces profile churn, login friction, and hardware cost.

The reservations are:

- User container must not mean all tasks freely share one browser state.
- Browser contexts, site locks, and profile locks are required to avoid state pollution.
- Adapter speed is preserved only if Agent supervision is asynchronous and milestone-based.
- Long-lived user containers need sleep-to-disk policy to avoid zombie browser cost.
- Screenshot/evidence capture must have strict retention and cleanup.

This document incorporates those reservations as mandatory architecture requirements.
