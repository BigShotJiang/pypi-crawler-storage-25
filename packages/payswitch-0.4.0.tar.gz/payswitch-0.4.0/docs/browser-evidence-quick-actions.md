## Browser Evidence Quick Actions Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed BrowserPreview follow-on slice for persisted
browser evidence actions.

It closes the next operator gap left by the playback and timeline modules:

```text
persisted QR / recording evidence is visible
+ BrowserPreview exposes direct open actions for those stored artifacts
+ operator can jump from the main runtime panel to the exact persisted evidence
```

## 1. Module Goal

The runtime panel could already:

- show a QR crop during a QR human gate;
- play back the latest persisted recording when no live display was active;
- expose timeline-native links from `media.persisted` events.

But the main browser panel itself still lacked direct artifact actions. That
meant operators had to either use the embedded preview surface only or switch to
the event timeline to open the stored evidence in a separate tab.

## 2. Delivered Behavior

### 2.1 BrowserPreview quick actions

`BrowserPreview` now renders a compact evidence-action row when persisted
browser evidence is available for the selected session.

Supported actions:

- `打开二维码` for the latest QR artifact URL from the human gate event;
- `打开录屏` for the latest persisted browser recording with a real
  `downloadUrl`.

Each action opens in a new tab and stays bound to the currently selected
session's evidence payload.

### 2.2 Download-only rendering rule

The runtime panel only renders quick actions for evidence that already has a
real URL contract.

If a media artifact entry has no `downloadUrl`, the UI still preserves the
session state but does not render a dead link.

### 2.3 No state-machine changes

This module does not touch:

- session stage progression;
- human-gate semantics;
- display ownership or takeover routing;
- timeline replay logic.

It is a pure operator-surface improvement on top of the existing evidence
projection baseline.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. A QR human gate with `qrArtifactUrl` renders a direct `打开二维码` action.
2. A persisted video artifact with `downloadUrl` renders a direct `打开录屏`
   action.
3. Missing `downloadUrl` prevents the recording action from rendering.
4. The existing preview ordering remains unchanged: live display -> QR -> video
   -> screenshot -> empty state.
5. Frontend tests cover the positive and negative action-rendering cases.

## 4. Verification

- `npm test -- --run src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx src/lib/eventStream.test.ts src/lib/sessionModel.test.ts src/lib/sessionSnapshot.test.ts`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- inline download progress or save-state tracking;
- QR decoding or copied payment text from the runtime panel;
- richer evidence galleries or multi-artifact browsing.

## 6. Implementation References

- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/BrowserPreview.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.test.tsx)
- [frontend/src/App.css](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/App.css)
- [docs/external-browser-recording-playback.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/external-browser-recording-playback.md)
- [docs/timeline-media-artifact-actions.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/timeline-media-artifact-actions.md)
