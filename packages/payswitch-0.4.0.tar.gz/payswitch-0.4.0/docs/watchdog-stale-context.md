# Watchdog Stale Context Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed stale-context policy slice for the
Watchdog/Computer Use recovery workstream.

It does not implement the full watchdog classifier or bounded Computer Use
recovery loop. It closes one concrete gap:

```text
telemetry TTL
+ stale rolling-buffer discard
+ resync evidence projection
```

## 1. Module Goal

Recovery must not trust stale rolling telemetry after a task has been paused or
disconnected beyond the configured telemetry TTL.

When recovery context is stale, Pay-Switch must:

- discard trusted rolling-buffer telemetry from the expired window;
- keep only the current failure context;
- require a re-synchronization step before recovery continues;
- record that stale-context discard in recovery evidence.

## 2. Delivered Behavior

### 2.1 Default TTL policy

- `recovery_context_ttl_seconds` now defaults to `300` seconds.
- The config description explicitly treats this as the default 5-minute
  recovery telemetry window.

### 2.2 Stale rolling-buffer discard

When `RecoveryWatchdog.register_script_failure()` sees a failure after the
checkpoint is older than the configured TTL:

- old telemetry buffer entries are dropped;
- only the current failure context remains in the buffer;
- the decision returns `requires_resync=True`;
- the decision returns `stale_buffer_discarded=True`.

### 2.3 Structured watchdog snapshot

`RecoveryWatchdog.describe_state()` now exposes:

- `attempts`
- `last_failure_at`
- `last_checkpoint_at`
- `telemetry_ttl_seconds`
- `telemetry_buffer`
- `stale_resync_count`

This snapshot is attached to recovery checkpoint evidence so recovery review
can tell whether the agent is acting on fresh or stale context.

### 2.4 Recovery evidence projection

The orchestrator now includes stale-context metadata in recovery checkpoints:

- `stale_buffer_discarded`
- `watchdog_state`

If stale context triggered the checkpoint, the recovery step description now
states that old telemetry was discarded.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Default recovery telemetry TTL is 5 minutes.
2. Recovery before TTL expiry does not require re-sync.
3. Recovery after TTL expiry requires re-sync.
4. When TTL expiry happens, old buffered telemetry is discarded before
   recovery continues.
5. Recovery evidence can show the watchdog state and stale-discard metadata.

## 4. Verification

- `ruff check payswitch/engine/watchdog.py payswitch/engine/orchestrator.py payswitch/models/config.py tests/test_recovery_watchdog.py tests/test_models.py`
- `.venv/bin/python -m pytest tests/test_recovery_watchdog.py tests/test_models.py`
- `.venv/bin/python -m pytest tests/test_integration.py -k "watchdog or recovery"`

## 5. Non-Goals

This module does not yet deliver:

- the bounded Computer Use recovery loop;
- bounded Computer Use execution budgets;
- consistent adapter-authored synchronous policy checkpoints;
- watchdog-driven recipe patch review flow.

The watchdog classifier taxonomy is now documented separately in
[docs/watchdog-classifier.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/watchdog-classifier.md).

## 6. Implementation References

- [payswitch/engine/watchdog.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/watchdog.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [payswitch/models/config.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/models/config.py)
- [tests/test_recovery_watchdog.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_recovery_watchdog.py)
- [tests/test_models.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_models.py)
