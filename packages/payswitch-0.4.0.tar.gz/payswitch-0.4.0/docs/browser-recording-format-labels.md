## Browser Recording Format Labels Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed WebUI format-label slice for persisted
browser recording artifacts.

It closes the next operator-facing gap this way:

```text
browser recording artifact already projects content_type/contentType
+ WebUI now maps common video content types to human-readable container labels
+ BrowserPreview and LiveTimeline show format labels alongside fidelity metadata
```

## 1. Module Goal

The browser recording pipeline already exposed:

- persisted media download URLs;
- recording source and engine;
- size, duration, fps, bit rate, resolution, and codec;
- `content_type` / `contentType` across control-plane payloads.

But operators still had to infer whether a stored recording was `WebM`, `MP4`,
or `QuickTime` from file names or raw MIME values. That kept the evidence
surface less legible than it needed to be.

This module surfaces human-readable container labels without changing recording
persistence or API contracts.

## 2. Delivered Behavior

### 2.1 Format label mapping

The frontend browser-recording helper now maps:

- `video/webm` -> `WebM`
- `video/mp4` -> `MP4`
- `video/quicktime` -> `QuickTime`

Unknown content types remain unlabeled instead of inventing misleading output.

### 2.2 BrowserPreview format labels

`BrowserPreview` now includes the container format in persisted media action
labels when `contentType` is available.

Example:

- `打开录屏 · 2 KB · 4.2s · 1280x720 · 30fps · 2 Mbps · VP8 · WebM · Playwright`

### 2.3 Timeline format labels

`LiveTimeline` now renders the same format label in persisted media event links.

Example:

- `observation-replay.mp4 · 截图回放 · 2 KB · 1s · 1280x720 · 1fps · 800 kbps · MPEG-4 · MP4 · FFmpeg 回放`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `video/webm` renders as `WebM`.
2. `video/mp4` renders as `MP4`.
3. `video/quicktime` renders as `QuickTime`.
4. Unknown or missing `contentType` does not break existing action labels.
5. BrowserPreview and LiveTimeline both preserve the rest of the metadata
   sequence while adding the format label.

## 4. Verification

- `npm test -- --run src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx src/lib/eventStream.test.ts`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- backend content-type contract changes;
- container-level validation beyond the existing content type field;
- audio/video stream inventory.

## 6. Implementation References

- [frontend/src/lib/browserRecording.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/browserRecording.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
- [frontend/src/components/BrowserPreview.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.test.tsx)
- [frontend/src/components/LiveTimeline.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.test.tsx)
