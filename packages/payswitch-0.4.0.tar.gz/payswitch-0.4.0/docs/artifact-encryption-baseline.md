# Artifact Encryption Baseline Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed Milestone 7 baseline for sensitive JSON
artifact persistence.

It closes the first artifact-hardening gap after the service-owned recovery
improver modules:

```text
plaintext JSON evidence
+ sensitivity classification
+ retention sidecar metadata
+ local encrypted envelope storage
+ transparent read-path decryption
```

## 1. Module Goal

Pay-Switch already had secret-envelope protection for post-purchase API keys,
but recovery checkpoints, patch-review artifacts, and external action evidence
still landed as plaintext JSON on disk.

This module adds a single artifact-storage contract for those sensitive JSON
artifacts so the server can:

- classify artifact sensitivity;
- persist retention metadata beside each artifact;
- encrypt sensitive JSON artifacts before they are written to disk;
- transparently read encrypted evidence back through runtime and WebUI helpers.

## 2. Delivered Behavior

### 2.1 Shared artifact store

`ArtifactStore` now provides:

- sensitivity classification (`public`, `internal`, `sensitive`);
- sidecar metadata with `retention_hours`, `created_at`, and `expires_at`;
- local-at-rest encryption for sensitive JSON artifacts via X25519 envelope;
- transparent `read_json(...)` support for encrypted and plaintext JSON files.

### 2.2 Recovery artifact encryption

The orchestrator now writes these JSON artifacts through `ArtifactStore` as
`sensitive`:

- recovery checkpoints;
- recovery patch-review artifacts;
- external Computer Use handoff artifacts.

### 2.3 External action evidence encryption

The external runner now writes action evidence through `ArtifactStore` as
`sensitive`, and its resume logic now decrypts prior evidence before reading:

- `current_url` resume state;
- unresolved blocking interaction hints.

### 2.4 WebUI/session evidence compatibility

The settings API transaction/session payload path now reads encrypted step
evidence through `ArtifactStore`, so session replay and screenshot projection
continue to work after artifact encryption.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Sensitive JSON artifacts are not persisted as plaintext.
2. Artifact metadata records sensitivity and retention fields beside each artifact.
3. Existing runtime consumers can read encrypted evidence without changing their external API shape.
4. Recovery and external-runner flows continue to persist usable evidence paths.
5. Regression tests cover store round-trip, external-runner resume, WebUI session replay, and a recovery integration path.

## 4. Verification

- `ruff check payswitch/security/artifacts.py payswitch/engine/orchestrator.py payswitch/engine/external_runner.py payswitch/cli.py payswitch/models/config.py tests/test_artifact_store.py tests/test_external_runner.py tests/test_ui_settings_api.py`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_external_runner.py tests/test_ui_settings_api.py tests/test_secret_envelope.py -q`
- `.venv/bin/python -m pytest tests/test_integration.py -k test_successful_computer_use_recovery_marks_patch_shadow_run -q`

## 5. Non-Goals

This module does not yet deliver:

- screenshot or binary artifact encryption;
- artifact TTL enforcement or cleanup worker execution;
- cross-host artifact replication;
- automatic artifact-key rotation for device handoff.

## 6. Implementation References

- [payswitch/security/artifacts.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/artifacts.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [payswitch/models/config.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/models/config.py)
- [tests/test_artifact_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_artifact_store.py)
- [tests/test_external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_external_runner.py)
- [tests/test_ui_settings_api.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_ui_settings_api.py)
