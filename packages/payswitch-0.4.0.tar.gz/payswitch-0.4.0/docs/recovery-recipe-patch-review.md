# Recovery Recipe Patch Review

This document records the completed Milestone 6 slice for successful-recovery
recipe patch output and review flow.

## Goal

When a fast-path adapter fails and bounded Computer Use reaches a valid payment
surface, Pay-Switch should emit a durable, machine-readable recipe patch
candidate without letting that candidate affect the mainline recipe directly.

## What shipped

1. Script recovery still registers a `candidate` patch immediately after a
   waypoint failure.
2. When internal Computer Use later reaches a valid surface such as `scan_qr`
   or `completed`, the orchestrator now:
   - updates the candidate recipe with recovery-derived URL/text evidence;
   - writes a review artifact under
     `data_dir/experience/patch_reviews/<tx>-patch-<id>.json`;
   - appends a structured step record to the transaction timeline.
3. The review surface is now exposed through CLI:
   - `payswitch experience patch list`
   - `payswitch experience patch show <id>`
   - `payswitch experience patch review <id> --reviewer ...`
   - `payswitch experience patch shadow-pass <id>`
   - `payswitch experience patch promote <id>`

## Review contract

- Recovery output lands as `candidate`.
- `candidate` cannot become `mainline` until one of these is true:
  - explicit `reviewed` state; or
  - `shadow_run_success=true`.
- Review metadata is durable in the experience store.
- Promotion still uses the stored recipe payload, not ad hoc runtime memory.

## Acceptance criteria

- A successful recovery emits a machine-readable patch candidate.
- The candidate records `tx_id`, failed `waypoint_id`, recovery outcome, final
  URL, and bounded Computer Use step summaries.
- Reviewers can list, inspect, review, shadow-pass, and promote candidates from
  CLI.
- Unreviewed candidates still cannot affect the mainline fast path.

## Verification

- `ruff check payswitch/experience/store.py payswitch/engine/orchestrator.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`
- `.venv/bin/python -m compileall payswitch/experience/store.py payswitch/engine/orchestrator.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`

## Non-goals

- Automatic promotion into `mainline`
- Adapter-authored synchronous policy checkpoints
- Full per-action recovery-state verification
