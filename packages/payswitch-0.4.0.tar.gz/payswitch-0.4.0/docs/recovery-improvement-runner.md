# Recovery Improvement Runner Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed background execution slice for accepted
recovery improvements.

It closes the next gap after the accepted-improvement processor:

```text
accepted improvement processor
+ bounded polling loop
+ idle-exit behavior
+ single-cycle and multi-cycle execution
```

## 1. Module Goal

Accepted recovery improvements should be processable through a bounded
background runner instead of only one-off CLI invocations.

This module adds a reusable runner that:

- polls accepted improvements in batches;
- exits after bounded idle polls;
- supports one-cycle execution and multi-cycle loops;
- preserves dry-run behavior.

## 2. Delivered Behavior

### 2.1 Reusable background runner

`RecoveryImprovementRunner` now provides:

- `run_once(...)`
- `run_loop(...)`

The runner returns structured cycle summaries instead of only mutating the
store silently.

### 2.2 Explicit loop bounds

The runner is bounded by:

- `batch_limit`
- `poll_interval_seconds`
- `max_idle_polls`
- optional `max_cycles`

This keeps the improver path deterministic and testable.

### 2.3 CLI loop surface

The CLI now exposes:

- `payswitch experience improvement run-loop`

Supported controls:

- `--once`
- `--dry-run`
- `--batch-limit`
- `--poll-interval-seconds`
- `--max-idle-polls`
- `--max-cycles`
- `--reviewer`
- `--note`
- `--platform`
- `--flow`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Accepted improvements can be processed through a reusable loop object.
2. The loop exits after a bounded number of idle polls.
3. Operators can run one cycle or a bounded multi-cycle loop from the CLI.
4. Dry-run behavior remains available in both single-cycle and loop modes.
5. Regression tests cover runner behavior and CLI invocation.

## 4. Verification

- `ruff check payswitch/experience/__init__.py payswitch/experience/improver.py payswitch/experience/store.py payswitch/cli.py tests/test_experience_store.py tests/test_experience_improver.py tests/test_cli_experience.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_experience_improver.py tests/test_cli_experience.py`

## 5. Non-Goals

This module does not yet deliver:

- daemon/service supervision for the runner;
- runtime-triggered autonomous acceptance of open improvements;
- autonomous promotion from reviewed patches into `mainline`.

## 6. Implementation References

- [payswitch/experience/improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/improver.py)
- [payswitch/experience/store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/store.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_experience_improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_improver.py)
- [tests/test_cli_experience.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_experience.py)
