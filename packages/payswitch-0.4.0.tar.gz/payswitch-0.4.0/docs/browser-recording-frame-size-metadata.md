## Browser Recording Frame-Size Metadata Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed frame-size metadata slice for persisted
browser recording artifacts.

It closes the next metadata gap this way:

```text
browser recording artifact already has source, size, duration, fps, and engine
+ runtime source now emits frame_width/frame_height
+ server and local settings/events preserve frame-size aliases
+ WebUI labels recordings with human-readable resolution metadata
```

## 1. Module Goal

The browser recording pipeline already exposed:

- stable artifact IDs;
- recording source;
- byte size;
- capture engine;
- duration;
- fps;
- persisted download URLs.

But operators still could not tell the rendered dimensions of a stored
recording. That made native terminal video and screenshot replay harder to
compare when both were available as valid persisted artifacts.

This module adds frame-size metadata without changing how recordings are
captured or delivered.

## 2. Delivered Behavior

### 2.1 Runtime source frame-size metadata

`ExternalCheckoutRunner` now emits `frame_width` and `frame_height` at the
source:

- native browser video: best-effort `ffprobe` width/height detection from the
  first video stream;
- screenshot replay: the same best-effort video-stream probe after replay
  synthesis completes.

The same values are written into:

- artifact metadata;
- emitted `media.persisted` payloads (`frame_width`, `frameWidth`,
  `frame_height`, `frameHeight`).

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve both:

- `frame_width`
- `frameWidth`
- `frame_height`
- `frameHeight`

This keeps frame-size metadata aligned with the alias policy already used for
artifact ID, source, size, duration, fps, engine, and download metadata.

### 2.3 WebUI resolution labels

The frontend runtime model now preserves `frameWidth` and `frameHeight`.

Browser media actions surface human-readable resolution labels such as:

- `1280x720`

These labels appear in both:

- `BrowserPreview`;
- `LiveTimeline`.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Native recording persistence can carry best-effort `frame_width` and
   `frame_height`.
2. Screenshot replay persistence can carry the same frame-size metadata.
3. Public session projection preserves both frame-size alias pairs.
4. Local settings/events projection preserves the same aliases.
5. WebUI media actions render frame-size metadata when available.
6. Existing recording playback, source attribution, size, duration, fps, and
   engine labels stay intact.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- codec-level inspection beyond coarse resolution metadata;
- timeline-native scrubber or thumbnail generation;
- native live capture for attached CDP user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/lib/formatFrameSize.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/formatFrameSize.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
