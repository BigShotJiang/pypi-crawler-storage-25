# DeepSeek Synchronous Policy Checkpoints

Date: 2026-05-16
Status: implemented in current branch

This document records the DeepSeek expansion slice for Milestone 6 synchronous
policy checkpoint coverage.

## 1. Goal

The earlier checkpoint module only covered Kimi's recipe-backed membership flow.
This slice broadens the same contract to another first-party adapter path:
DeepSeek top-up.

The goal is not just to add another recipe. The goal is to ensure DeepSeek's
`Next step` payment transition is guarded by the same shared runner-level
checkpoint contract before the adapter enters the QR cashier surface.

## 2. Delivered Behavior

### 2.1 DeepSeek now runs through `RecipeRunner`

`DeepSeekAdapter.execute_topup()` now executes through the shared
`RecipeRunner`, instead of a purely imperative step chain.

The built-in DeepSeek recipe now defines explicit waypoints for:

- top-up page navigation
- login verification
- identity-verification gate check
- amount selection
- default payment-surface confirmation
- confirm-to-checkout transition
- QR wait state

### 2.2 Shared checkpoint on confirm transition

The `confirm_topup_checkout` waypoint is now marked with
`synchronous_policy_checkpoint=true`.

Before DeepSeek clicks `Next step`, the adapter now re-checks:

- login state
- identity-verification blockers
- visible payment-surface markers such as `Payment method`, `Online recharge`,
  or `Next step`

If those markers are missing, the waypoint fails closed before the click runs.

### 2.3 Durable recipe outcomes

Like Kimi, DeepSeek now records recipe success/failure outcomes into the
experience store with recipe id/version metadata.

This keeps DeepSeek on the same reviewable fast-path contract as the current
recipe-backed adapters.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. DeepSeek top-up runs through the shared recipe runner.
2. The DeepSeek confirm transition cannot proceed without a checkpoint pass.
3. Login and identity blockers are re-validated at the DeepSeek checkpoint.
4. Missing visible payment markers block the confirm transition.
5. DeepSeek recipe outcomes remain durable and queryable through the experience
   store.

## 4. Verification

- `ruff check payswitch/adapters/deepseek.py payswitch/experience/registry.py tests/test_adapters.py tests/test_experience_runner.py tests/test_recovery_watchdog.py`
- `.venv/bin/python -m pytest tests/test_adapters.py tests/test_experience_runner.py tests/test_recovery_watchdog.py`
- `.venv/bin/python -m compileall payswitch/adapters/deepseek.py payswitch/experience/registry.py tests/test_adapters.py`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- recipe-backed synchronous checkpoints for every remaining imperative adapter;
- automatic promotion of all legacy adapters into recipe-backed fast paths;
- protocol-level payment routing work.

## 6. Implementation References

- [payswitch/adapters/deepseek.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/deepseek.py)
- [payswitch/experience/registry.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/registry.py)
- [tests/test_adapters.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_adapters.py)
