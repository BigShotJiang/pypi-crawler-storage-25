# PaySwitch Multi-Subagent Harness Architecture

Date: 2026-05-15

This document maps the useful Claude Code task harness ideas into PaySwitch and
defines the production path for multi-user, multi-subagent payment execution.

## 1. Source Structure Mapped From Claude Code

Claude Code has four useful layers:

| Claude Code structure | PaySwitch equivalent | Adopted behavior |
|---|---|---|
| `AgentTool` | `POST /api/payments`, A2A `message:send`, PayAgent CLI | One entrypoint creates a typed task and decides sync, async, local, or remote execution. |
| `Task` / `LocalAgentTask` | `AgentTask`, `SubagentSession` | Every spawned worker has a stable id, status, output/event stream, cancellation, and terminal notification. |
| `runAsyncAgentLifecycle` | `_run_task` + workspace lease | Status transitions happen before slow cleanup. Completion, failure, and kill paths produce structured events. |
| `sessionRunner` NDJSON stream | PaySwitch SSE stream | Events are replayable by sequence and can resume from a checkpoint. |
| `worktree` / `remote` isolation | user workspace / process / container runtime | Isolation starts in-process, then moves to worker process and user container without changing API shape. |
| permission request callbacks | Human Gate | Sensitive tool invocations become user-owned authorization events. |

## 2. PaySwitch Harness Layers

```text
External Agent
  -> PaySwitch Control Plane
     -> TaskStore
     -> Subagent Harness
        -> User Workspace Manager
        -> Scheduler
        -> Foreground Lease Manager
        -> Stream Buffer
        -> Harness Review
     -> Payment Orchestrator
     -> Human Gate
     -> Ledger and Secret Delivery
```

### 2.1 TaskStore

TaskStore owns the canonical task record. It must:

- assign stable task ids,
- attach user/workspace/subagent identity,
- append stream events with monotonically increasing `sequence`,
- redact secrets before events are stored,
- replay events after a sequence checkpoint,
- publish live events to current subscribers.

### 2.2 User Workspace Manager

The workspace manager owns in-process scheduling semantics now and keeps the
same contract for later process/container runtimes.

Rules:

- one logical workspace per `user_id`,
- one logical subagent session per payment task,
- different users can run concurrently,
- same user can be capacity-limited,
- same user and same site/profile must serialize mutating work,
- same user workspace can expose only one foreground Human Gate lease at a time.

### 2.3 Foreground Lease

Foreground means the user is being asked to look at or operate the live browser.
Only one foreground lease may exist per workspace.

```text
task enters Human Gate
-> acquire_foreground(task_id, reason)
-> route noVNC/display token to that task
-> wait for user authorization or timeout
-> release foreground lease
-> resume queued foreground requests
```

### 2.4 Stream Mode

SSE payloads use event ids and embedded sequence numbers:

```text
id: 42
data: {"sequence":42,"type":"human.gate","summary":"..."}
```

Clients can reconnect with:

```text
GET /events?session_id=psw_xxx&after=42
GET /events?session_id=psw_xxx&replay=0
```

This gives three modes:

| Mode | Query | Use case |
|---|---|---|
| full replay | no query | open a session from scratch |
| checkpoint replay | `after=<sequence>` | reconnect after network loss |
| live only | `replay=0` | UI already loaded a ledger/session snapshot |

## 3. Scheduling Plan

V0 in-process:

```text
create task
-> resolve user/site/profile identity
-> acquire workspace capacity semaphore
-> acquire site/profile mutation lock
-> run adapter/orchestrator
-> optionally acquire foreground lease for Human Gate
-> release foreground lease
-> release site/profile lock
-> release workspace capacity
```

V1 process workers:

```text
Control Plane
-> enqueue task in durable queue
-> worker process per active user workspace
-> worker pulls task
-> local workspace manager applies the same locks
-> worker streams events back to Control Plane
```

V2 user containers:

```text
Control Plane
-> workspace runtime registry
-> one container per active user
-> browser/profile/noVNC inside container
-> dynamic route session_id -> workspace upstream
-> scoped noVNC token per session
```

## 4. Harness Review Invariants

The harness review must flag:

- a workspace containing sessions from multiple users,
- multiple foreground leases inside one workspace,
- sessions missing `task_id`, `session_id`, `user_id`, or `workspace_id`,
- plaintext secret-like values in stream events,
- global latest-session access without user scoping,
- noVNC/display URLs not scoped to session and user,
- completed purchase sessions without ledger and artifact evidence.
- loading a `candidate` recipe into a `mainline` execution path without `shadow_run_success` or explicit review metadata.

## 5. TODO

- [x] Add workspace capacity semaphore.
- [x] Add foreground lease manager.
- [x] Add replayable SSE event sequence.
- [x] Add checkpoint stream replay with `after=<sequence>`.
- [x] Add live-only stream mode with `replay=0`.
- [x] Redact secret-like event payloads before storage.
- [x] Add adversarial harness review helpers.
- [ ] Persist task/session/stream state to SQLite.
- [ ] Add process worker runtime behind the same manager interface.
- [ ] Add container runtime and dynamic noVNC route registry.
- [ ] Bind noVNC token to `user_id + session_id + foreground_lease_id`.
- [ ] Add durable queue with retry and idempotency leases.
- [ ] Add artifact verifier for same-session ledger/image/video/API key evidence.

## 6. Adversarial Review Checklist

Before claiming a full production multi-subagent chain:

- Run concurrent same-user and cross-user task tests.
- Kill a queued session and confirm it does not unlock a running session.
- Reconnect SSE from `after=<sequence>` and confirm no duplicate or missing events.
- Inject fake `api_key`, `refresh_token`, and `client_secret` into events and confirm storage is redacted.
- Attempt two foreground leases in one workspace and confirm the second blocks.
- Attempt same workspace id with different user ids and confirm review flags it.
- Confirm `/api/sessions?user_id=` never leaks another user's session.
- Confirm final A2A artifact includes only encrypted secrets, never plaintext keys.
