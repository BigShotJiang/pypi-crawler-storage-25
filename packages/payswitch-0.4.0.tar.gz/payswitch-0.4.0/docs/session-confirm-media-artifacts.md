## Session Confirm Media Artifacts Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed session-confirm media-artifact slice for
server artifact delivery.

It closes the next confirm-time binary coverage gap after persisted download
projection:

```text
confirm evidence/generated attachment persistence
+ confirm-time mediaArtifacts contract
+ persisted media artifact writes
+ authenticated media artifact download through the session route
```

## 1. Module Goal

Pay-Switch could already persist confirm-time `evidenceArtifacts` and
`generatedOutputs`, and the server could already project persisted artifact
downloads for result items with `artifact_path`. But the confirm request itself
still lacked a first-class `mediaArtifacts` input contract.

That meant media payloads such as captures or exported recordings still needed
out-of-band result mutation instead of the same governed confirm path used for
other post-payment attachments.

## 2. Delivered Behavior

### 2.1 Confirm request contract

`SessionConfirmRequest` now accepts:

- `mediaArtifacts`

using the same inline payload contract as other confirm attachment groups:

- `contentBase64` / `content_base64`
- `dataUrl` / `data_url`
- `text`
- `jsonPayload` / `json_payload`

### 2.2 Persisted media artifact writes

When a confirm request submits `mediaArtifacts`, the server now:

- normalizes `artifactId` and related metadata;
- persists inline payloads under `data_dir/evidence/session-confirm/{session_id}/`;
- stores them in `result["media_artifacts"]`;
- removes the inline payload from the stored result body.

### 2.3 Download and A2A projection

Confirmed media artifacts now automatically inherit the same persisted download
contract as other result artifacts:

- `GET /api/sessions/{session_id}/artifacts/{artifact_id}`
- `download_url` metadata in A2A artifact output
- inferred or stored `content_type`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `mediaArtifacts` is accepted by the confirm API.
2. Inline media payloads persist through `ArtifactStore`.
3. The confirm response does not echo the inline media payload.
4. The persisted media artifact is downloadable through the authenticated
   session artifact route.
5. A2A metadata exposes the download URL and content type for the media
   artifact.

## 4. Verification

- `ruff check payswitch/server.py tests/test_server_public_urls.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py -q`

## 5. Non-Goals

This module does not yet deliver:

- automatic browser-session video capture production;
- streaming playback surfaces for recorded artifacts in WebUI;
- unauthenticated public media artifact URLs.

## 6. Implementation References

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
