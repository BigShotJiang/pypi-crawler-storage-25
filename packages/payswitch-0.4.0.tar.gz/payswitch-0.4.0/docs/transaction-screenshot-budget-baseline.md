# Transaction Screenshot Budget Baseline

## Goal

Add a transaction-level screenshot budget that is enforced across adapter recipe
failure screenshots, recovery screenshots, and external observe screenshots,
while keeping the current evidence paths and session APIs stable.

## What changed

- `Transaction` now persists `budget_state.screenshots`, including:
  - `limit`
  - `used`
  - `remaining`
  - `exhausted`
  - `exhausted_at`
  - `exhaustion_reason`
  - `last_capture_reason`
  - `last_artifact_kind`
  - `last_artifact_path`
- `Ledger` now stores and restores `budget_state`, including schema migration for
  existing SQLite databases that do not yet have the `budget_state` column.
- `PaySwitchConfig` now exposes `transaction_max_screenshots`.
- Added `TransactionScreenshotBudget` as the shared controller for screenshot
  accounting.
- Adapter recipe failure screenshots now consume the same transaction budget as
  recovery and external observe screenshots.
- Recovery checkpoints and recovery resynchronization screenshots now stop
  writing new PNG artifacts once the transaction budget is exhausted.
- External `observe` actions now stop persisting new screenshots after the
  budget is exhausted and return explicit budget state plus exhaustion reason in
  the action result.
- Session snapshots now surface `budget_state` so the WebUI/control plane can
  display the current screenshot budget state without reading raw ledger rows.

## Why

- The artifact layer already had encryption, retention metadata, cleanup, and
  storage telemetry, but it still lacked a per-transaction screenshot ceiling.
- The roadmap explicitly requires recovery and screenshot budgets to appear in
  session state and task/result state.
- Without a transaction-level limiter, a long external observe loop or repeated
  recovery attempts could still accumulate more screenshots than the policy
  intended.

## Impact

- Successful tasks now stop storing screenshots after the configured limit is
  reached instead of growing unbounded evidence.
- Budget exhaustion is visible in:
  - ledger transaction state
  - session/task result
  - session snapshot API
  - external observe action results
  - recipe telemetry when a failure screenshot consumes the last budget slot
- Existing screenshot file paths stay stable; callers do not need a new
  evidence-read contract.

## Acceptance criteria

1. A transaction never persists more than `transaction_max_screenshots`
   screenshots across recipe, recovery, and external observe flows.
2. When the limit is reached, the next attempted screenshot is blocked without
   crashing the payment flow.
3. `budget_state` is persisted in ledger records and included in session/task
   result state.
4. External observe callers receive a clear exhaustion reason when no more
   screenshots can be written.

## Verification

- `ruff check payswitch/models/transaction.py payswitch/engine/ledger.py payswitch/models/config.py payswitch/security/screenshot_budget.py payswitch/adapters/base.py payswitch/experience/runner.py payswitch/adapters/kimi.py payswitch/adapters/deepseek.py payswitch/adapters/qwen.py payswitch/adapters/volcano.py payswitch/adapters/jimeng.py payswitch/adapters/nineemail.py payswitch/engine/orchestrator.py payswitch/engine/external_runner.py payswitch/server.py tests/test_screenshot_budget.py tests/test_models.py tests/test_experience_runner.py tests/test_external_runner.py tests/test_server_public_urls.py`
- `.venv/bin/python -m compileall payswitch/models/transaction.py payswitch/engine/ledger.py payswitch/models/config.py payswitch/security/screenshot_budget.py payswitch/adapters/base.py payswitch/experience/runner.py payswitch/adapters/kimi.py payswitch/adapters/deepseek.py payswitch/adapters/qwen.py payswitch/adapters/volcano.py payswitch/adapters/jimeng.py payswitch/adapters/nineemail.py payswitch/engine/orchestrator.py payswitch/engine/external_runner.py payswitch/server.py tests/test_screenshot_budget.py tests/test_models.py tests/test_experience_runner.py tests/test_external_runner.py tests/test_server_public_urls.py`
- `.venv/bin/python -m pytest tests/test_screenshot_budget.py tests/test_models.py tests/test_experience_runner.py tests/test_external_runner.py tests/test_server_public_urls.py -q`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_ui_settings_api.py tests/test_server_artifact_inventory.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py tests/test_cli_artifact_stats.py -q`
- `.venv/bin/python -m pytest tests/test_integration.py -k "recovery or checkpoint or human_gate" -q`
- `git diff --check`

## Files

- [payswitch/models/transaction.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/models/transaction.py)
- [payswitch/engine/ledger.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/ledger.py)
- [payswitch/models/config.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/models/config.py)
- [payswitch/security/screenshot_budget.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/screenshot_budget.py)
- [payswitch/experience/runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/runner.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_screenshot_budget.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_screenshot_budget.py)
- [tests/test_experience_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_runner.py)
- [tests/test_external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_external_runner.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
