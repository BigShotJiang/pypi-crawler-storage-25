# Per-Action Recovery-State Verification

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed per-action recovery-state verification slice
for Milestone 6.

It closes the gap between bounded Computer Use entry and safe recovery routing:

```text
before-each-action verification
+ structured failure context
+ fail-closed recovery routing
```

## 1. Module Goal

Once Pay-Switch enters internal or hybrid Computer Use recovery, every proposed
browser action must be checked against the current recovery surface before the
action executes.

If the page has drifted into a login wall, a payment-confirmation boundary, or
a sensitive input surface, Pay-Switch must stop before the action runs and emit
a structured failure that later routing can classify correctly.

## 2. Delivered Behavior

### 2.1 Skyvern pre-action callback contract

`SkyvernEngine.execute_task()` and `navigate_and_act()` now accept an optional
`pre_action_callback`.

The callback runs before every non-`done` action and may block execution by
raising a structured error.

### 2.2 Computer Use recovery-state verifier

`ComputerUseExplorer` now installs a default verifier for bounded recovery.

Before a `click` or `fill` executes, the verifier checks the visible recovery
surface for:

- login-required signals;
- sensitive fill targets such as password / CVV / OTP / card-number inputs;
- payment-boundary markers such as QR, agreement, subscribe, confirm payment,
  auto-renew, or similar final-authorization surfaces.

### 2.3 Structured verification failures

Blocked actions now raise `RecoveryStateVerificationError` with durable
`failure_context`, including:

- `verification_stage=pre_action`
- `current_url`
- `visible_text_summary`
- `action_type`
- `action_selector`
- `action_description`
- login or sensitive-action markers that Watchdog can classify

### 2.4 Orchestrator fail-closed routing

Internal/hybrid Computer Use failures now preserve structured
`failure_context` through `SmartModeError`.

When a structured recovery verification failure reaches the orchestrator:

- `login_required` routes to the login human gate;
- `sensitive_action` routes to the manual recovery gate;
- only retryable drift remains eligible for external Computer Use fallback.

### 2.5 External handoff evidence enrichment

When hybrid mode still falls through to external Computer Use, the handoff
payload now carries the normalized `failure_context` so the operator can see
why internal recovery yielded.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Every internal/hybrid Computer Use action can be checked before execution.
2. Login-required recovery surfaces fail closed before the action runs.
3. Sensitive payment-boundary actions fail closed before the action runs.
4. Structured verification failures route to login or manual recovery instead
   of always falling through to external Computer Use.
5. Hybrid external handoff evidence retains structured failure context when
   external continuation is still allowed.

## 4. Verification

- `ruff check payswitch/browser/skyvern.py payswitch/browser/computer_use.py payswitch/engine/orchestrator.py tests/test_skyvern.py tests/test_computer_use.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_skyvern.py tests/test_computer_use.py tests/test_integration.py`
- `.venv/bin/python -m compileall payswitch/browser/skyvern.py payswitch/browser/computer_use.py payswitch/engine/orchestrator.py tests/test_skyvern.py tests/test_computer_use.py tests/test_integration.py`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- broader adapter-wide synchronous policy checkpoint retrofits beyond the
  current recipe-backed Kimi path;
- autonomous approval of payment-boundary actions;
- post-handoff external-agent policy replay or promotion.

## 6. Implementation References

- [payswitch/browser/skyvern.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/skyvern.py)
- [payswitch/browser/computer_use.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/computer_use.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [tests/test_skyvern.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_skyvern.py)
- [tests/test_computer_use.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_computer_use.py)
- [tests/test_integration.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_integration.py)
