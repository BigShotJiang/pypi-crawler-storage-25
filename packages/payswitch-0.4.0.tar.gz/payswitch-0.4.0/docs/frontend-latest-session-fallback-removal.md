## Frontend Latest-Session Fallback Removal Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed frontend session-truth slice for removing
implicit `/api/sessions/latest` snapshot fallback from the hosted WebUI runtime
path.

It closes the remaining control-plane drift this way:

```text
session list and selected-session hydration already exist
+ fetchSessionSnapshot now requires an explicit session_id
+ the frontend no longer calls /api/sessions/latest as a runtime fallback
+ selected-session truth stays aligned with the session sidebar contract
```

## 1. Module Goal

The hosted WebUI already had a selected-session model, a session sidebar, and
session-scoped SSE/display routes. But the generic snapshot helper still kept a
fallback path to `/api/sessions/latest` when only `userId` was present.

That fallback was no longer part of the intended frontend architecture. It kept
one implicit "latest session" escape hatch alive even after the rest of the UI
had moved to explicit selected-session ownership.

This module removes that escape hatch from the frontend runtime path.

## 2. Delivered Behavior

### 2.1 Snapshot helper requires explicit session selection

`fetchSessionSnapshot(...)` now returns `null` unless `sessionId` is provided.

It no longer builds or requests `/api/sessions/latest`.

### 2.2 User-scoped selection remains in the session list path

The frontend still supports user-scoped session lists through
`fetchSessionSnapshots(..., { userId })`.

What changed is only the single-session fallback path: the UI must now resolve
the concrete session through the sidebar/session-list workflow before it asks
for a live snapshot.

### 2.3 Test contract now reflects the selected-session model

Frontend tests now verify:

- no network call occurs when `sessionId` is missing;
- no special-case latest-session request is made even if `userId` exists.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `fetchSessionSnapshot()` returns `null` when `sessionId` is omitted.
2. The frontend does not call `/api/sessions/latest` from the snapshot helper.
3. User-scoped session-list reads continue to work.
4. The frontend build passes without reintroducing a latest-session dependency.

## 4. Verification

- `npm test -- --run src/lib/sessionSnapshot.test.ts`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- removal of the server-side `/api/sessions/latest` endpoint itself;
- session-list auto-selection policy changes;
- any change to SSE replay or session-display routing behavior.

## 6. Implementation References

- [frontend/src/lib/sessionSnapshot.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionSnapshot.ts)
- [frontend/src/lib/sessionSnapshot.test.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionSnapshot.test.ts)
