# Session Display Ownership Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed module that closes the current
session-to-display ownership work in the WebUI and control plane.

It is intentionally narrow. It does not describe the full future runtime
architecture. It documents what this module now guarantees, how it works,
how to verify it, and what remains outside its scope.

## 1. Module Goal

Operators must be able to select a specific payment session and see whether
that session currently owns a usable live display surface.

The WebUI must not imply that a session owns a real browser window unless the
runtime has explicitly granted that ownership.

The server must not expose display takeover routes for a user-scoped session
without matching user scope.

## 2. Problem This Module Closes

Before this module:

- the WebUI could infer takeover state from loose event fields;
- sidebar, preview, and human-gate views could disagree about whether a live
  display was really available;
- a session-scoped display route could still be resolved without `user_id`
  for a user-scoped session.

That made the UI look more deterministic than the control plane actually was.

## 3. Delivered Behavior

### 3.1 Frontend behavior

- The session list shows display ownership state per session.
- The selected session summary shows whether the current session has a live
  display surface, is waiting for foreground, or is unavailable.
- The browser preview only exposes a live takeover link when the session is
  actually `displayReady`.
- The human-gate modal shows the current session identity and reason, and it
  prefers the session-owned display route over loose event URLs.
- Switching the selected session updates the visible ownership state in the
  main panel.

### 3.2 Server behavior

- `POST /api/sessions/{session_id}:display/select` selects the foreground
  display session and returns the refreshed session snapshot.
- `GET /api/sessions/{session_id}/display/view` redirects only when the
  display route token is current and the display is ready.
- For user-scoped sessions, both routes now require matching `user_id`.
- Missing `user_id` on a scoped session returns `409`.
- Wrong `user_id` on a scoped session returns `404`.

### 3.3 Snapshot contract used by the WebUI

The module relies on these session snapshot fields:

- `display_ready`
- `display_state`
- `display_reason`
- `display_route_token`
- `display_url`
- `user_id`

The frontend must treat `display_url` as valid only when the snapshot says the
session is display-ready.

## 4. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Selecting a session changes the sidebar and main-panel ownership state.
2. A session without `displayReady` does not expose an "open current session"
   live-display link.
3. Human Gate shows the active session identity and reason.
4. Human Gate prefers the session-owned display route when both snapshot and
   event data exist.
5. A scoped session display route rejects access without `user_id`.
6. A scoped session display route rejects access with the wrong `user_id`.
7. A valid scoped session display route still redirects correctly with the
   current token.

## 5. Verification

Frontend:

- `npm test`
- `npm run build`

Backend:

- `.venv/bin/python -m pytest tests/test_server_public_urls.py tests/test_agent_workspace.py`

Targeted test coverage:

- `frontend/src/components/SessionSidebar.test.tsx`
- `frontend/src/components/BrowserPreview.test.tsx`
- `frontend/src/components/HumanGateModal.test.tsx`
- `frontend/src/App.test.tsx`
- `tests/test_server_public_urls.py`
- `tests/test_agent_workspace.py`

## 6. Non-Goals

This module does not yet deliver:

- one visible browser process per session;
- guaranteed z-order or frontmost-window enforcement at the OS window level;
- multi-runtime container isolation for different users;
- bounded Computer Use recovery;
- protocol-first payment execution.

Those belong to later framework milestones.

## 7. Implementation References

- [frontend/src/components/SessionSidebar.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/SessionSidebar.tsx)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/HumanGateModal.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/HumanGateModal.tsx)
- [frontend/src/lib/sessionDisplay.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionDisplay.ts)
- [frontend/src/App.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/App.tsx)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
