## Timeline Media Artifact Actions Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed timeline follow-on slice for persisted
session media artifacts.

It closes the next operator gap left by the playback baseline:

```text
persisted browser recording is visible in BrowserPreview
+ timeline event exposes a direct artifact action
+ operator can open the exact stored recording from the event that produced it
```

## 1. Module Goal

The playback baseline made stored browser recordings visible inside the main
browser panel, but the event timeline still treated `media.persisted` like a
plain log line.

That left one real workflow gap:

- operators could see that a recording was archived, but they still had to hunt
  for it through the main preview area instead of opening the stored artifact
  directly from the event that announced it.

## 2. Delivered Behavior

### 2.1 Timeline-native artifact actions

`LiveTimeline` now renders session media artifacts with a direct action row when
an event carries persisted artifact metadata with a `downloadUrl`.

Each action:

- opens the persisted artifact in a new tab;
- shows a media-specific icon instead of a generic text blob;
- prefers the artifact `name`, then falls back to `artifactId`.

### 2.2 Download-only rendering rule

The timeline only renders these actions for artifacts that already have a real
download contract.

Artifacts without `downloadUrl` remain non-clickable event metadata, which
prevents the timeline from surfacing dead links or implying that an ephemeral
runtime-only capture can already be reopened.

### 2.3 Visual consistency

The new action chips reuse the existing timeline surface instead of adding a new
card or nested panel:

- compact inline pills;
- same timeline item ownership as the originating event;
- no change to event ordering or status semantics.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `media_persisted` events can render one or more direct artifact links inside
   the timeline item.
2. The rendered link targets the persisted `downloadUrl`.
3. Artifacts without `downloadUrl` do not render clickable actions.
4. The new UI does not change timeline ordering, session stage, or session
   status logic.
5. Frontend tests cover the positive and negative rendering cases.

## 4. Verification

- `npm test -- --run src/components/LiveTimeline.test.tsx src/components/BrowserPreview.test.tsx src/lib/eventStream.test.ts src/lib/sessionModel.test.ts src/lib/sessionSnapshot.test.ts`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- timeline-inline video playback or scrubbers;
- recording thumbnails or poster extraction;
- grouping multiple persisted recordings into a richer evidence browser.

## 6. Implementation References

- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
- [frontend/src/components/LiveTimeline.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.test.tsx)
- [frontend/src/App.css](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/App.css)
- [docs/external-browser-recording-playback.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/external-browser-recording-playback.md)
