# Browser and Display Ownership Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed runtime-local browser/display ownership
module for the current Pay-Switch branch.

It closes the first delivery slice of roadmap Workstream C:

```text
Browser Manager abstraction
+ visible-session binding
+ display focus lock
+ visible-action verification
```

It does not claim OS-level window control, real reverse-proxy noVNC routing, or
bounded Computer Use recovery. Those remain later milestones.

## 1. Module Goal

When a workspace runtime exposes a visible browser surface, Pay-Switch must
know which logical payment session owns that surface right now.

Before any visible action can run, the runtime must verify:

- the target session is the selected visible owner;
- the target browser context still matches that session;
- foreground lease state still matches the selected visible surface;
- no other visible action currently holds the focus lock.

## 2. Problem This Module Closes

Before this module:

- display selection existed at the control-plane level, but the runtime did
  not track browser-context ownership explicitly;
- visible-action checks could tell whether a session was selected, but could
  not prove a specific browser context/tab/window binding inside the runtime;
- the runtime had no dedicated focus lock for visible Computer Use or other
  foreground actions.

That meant the control plane could expose "selected display" state without a
runtime-local browser ownership contract.

## 3. Delivered Behavior

### 3.1 Runtime browser manager

Each workspace runtime now owns a runtime-local Browser Manager that tracks:

- registered session-to-browser-context bindings;
- the selected visible session;
- the active browser context, tab, and window ids for that visible surface;
- the current z-order token for the selected surface;
- the current focus lock, if a visible action is in progress.

### 3.2 Visible display selection

When a session is selected for display ownership, the runtime now binds:

- `task_id`
- `browser_context_id`
- `foreground_lease_id`
- active tab/window metadata
- z-order token

into the visible-surface snapshot.

### 3.3 Visible action guard

Visible actions now verify all of the following before they can proceed:

- runtime is active;
- the session still owns the selected display surface;
- the selected browser context matches the session;
- foreground lease has not drifted;
- another visible action is not already holding the focus lock.

The first accepted visible action acquires a `display_focus_lock_id`.
Subsequent visible actions for the same session are blocked until the lock is
released.

### 3.4 Session snapshot projection

Session snapshots now expose runtime-local browser ownership metadata:

- `browser_manager_state`
- `active_browser_context_id`
- `active_browser_tab_id`
- `active_browser_window_id`
- `active_browser_task_id`
- `display_focus_lock_id`
- `display_focus_lock_task_id`
- `display_focus_lock_action`
- `display_focus_lock_acquired_at`
- `display_focus_z_order_token`
- `display_focus_foreground_lease_id`
- `browser_selection_reason`
- `browser_selected_at`

This lets the control plane, tests, and future WebUI work reason about the
actual selected runtime surface instead of a loose "display ready" flag alone.

## 4. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Selecting a session binds the runtime to that session's browser context.
2. Session snapshots expose the active browser context/tab/window metadata for
   the selected visible session.
3. A visible action is denied when the selected browser context no longer
   matches the session.
4. A visible action is denied when foreground lease state no longer matches the
   selected visible surface.
5. Starting a visible action acquires a focus lock.
6. Re-entering a visible action while the focus lock is held is denied.
7. Releasing the focus lock makes the session visible-action-eligible again.

## 5. Verification

- `git diff --check`
- `.venv/bin/python -m compileall payswitch/browser/manager.py payswitch/workspace_runtime.py payswitch/agent_workspace.py payswitch/server.py tests/test_browser_manager.py tests/test_workspace_runtime.py tests/test_agent_workspace.py tests/test_server_public_urls.py`
- `.venv/bin/python -m pytest tests/test_browser_manager.py tests/test_workspace_runtime.py tests/test_agent_workspace.py tests/test_server_public_urls.py`
- `.venv/bin/python -m pytest tests/test_workspace_runtime.py tests/test_agent_workspace.py tests/test_agent_workspace_harness.py tests/test_server_workspace_runtime_config.py tests/test_server_public_urls.py tests/test_server_streaming_harness.py tests/test_server_subagents.py tests/test_browser_manager.py`

## 6. Non-Goals

This module does not yet deliver:

- OS-level frontmost-window or z-order enforcement;
- real browser-tab switching through Playwright/CDP inside the runtime;
- reverse-proxy enforcement of `novnc_route_key`;
- persistent browser-manager state across server restart;
- Watchdog-driven Computer Use recovery.

## 7. Implementation References

- [payswitch/browser/manager.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/manager.py)
- [payswitch/workspace_runtime.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/workspace_runtime.py)
- [payswitch/agent_workspace.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/agent_workspace.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_browser_manager.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_browser_manager.py)
- [tests/test_workspace_runtime.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_workspace_runtime.py)
- [tests/test_agent_workspace.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_agent_workspace.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
