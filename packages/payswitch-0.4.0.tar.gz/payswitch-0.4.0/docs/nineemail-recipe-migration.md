# NineEmail Recipe-Backed Migration

Date: 2026-05-16
Status: implemented in current branch

This document records the NineEmail fast-path migration slice for Milestone 6.

## 1. Goal

NineEmail already had a fail-closed final payment checkpoint, but the product
purchase path still executed as a purely imperative sequence.

This slice moves NineEmail onto the shared `RecipeRunner` contract so the path
can share semantic waypoint telemetry, runner-level synchronous checkpointing,
and durable recipe outcomes with the other migrated fast-path adapters.

## 2. Delivered Behavior

### 2.1 NineEmail now runs through `RecipeRunner`

`NineEmailAdapter.execute_topup()` now executes through the shared recipe runner.

The built-in NineEmail recipe now defines waypoints for:

- product-page navigation
- order-form preparation
- order submission
- confirm-to-payment transition
- QR wait state

### 2.2 Runner-level checkpoint is now present on NineEmail confirm

The `confirm_topup_checkout` waypoint is now marked with
`synchronous_policy_checkpoint=true`.

Before NineEmail enters the final payment transition, the runner-level
checkpoint now requires visible payment markers such as:

- `支付宝`
- `下单`
- `立即支付`
- `确认订单`
- `扫码支付`

The older adapter-level fail-closed confirm guard remains in place, so the path
is protected at both the runner layer and the direct click helper.

### 2.3 Durable recipe outcomes

NineEmail now records recipe success/failure outcomes into the experience store
with recipe id/version metadata.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. NineEmail purchase runs through the shared recipe runner.
2. NineEmail exposes a built-in recipe with explicit order-form, submit,
   confirm, and QR waypoints.
3. The NineEmail confirm transition cannot proceed without a runner-level
   checkpoint pass.
4. NineEmail recipe outcomes are durable in the experience store.
5. Targeted tests prove recipe metadata, checkpoint blocking, checkpoint pass,
   and outcome persistence.

## 4. Verification

- `ruff check payswitch/adapters/nineemail.py payswitch/experience/registry.py tests/test_adapters.py`
- `.venv/bin/python -m pytest tests/test_adapters.py`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- protocol-level payment routing changes;
- automatic promotion of NineEmail recovery candidates into mainline behavior.

## 6. Implementation References

- [payswitch/adapters/nineemail.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/nineemail.py)
- [payswitch/experience/registry.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/registry.py)
- [tests/test_adapters.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_adapters.py)
