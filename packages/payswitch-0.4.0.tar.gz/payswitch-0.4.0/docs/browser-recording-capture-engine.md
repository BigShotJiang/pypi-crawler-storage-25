## Browser Recording Capture Engine Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed capture-engine metadata slice for persisted
browser recording artifacts.

It closes the next metadata gap this way:

```text
browser recording artifact already has source and size
+ runtime source now declares capture engine
+ server and local settings/events preserve engine aliases
+ WebUI labels recordings with engine provenance
```

## 1. Module Goal

The browser recording pipeline already exposed:

- stable artifact IDs;
- recording source;
- byte size;
- persisted download URLs.

But operators still could not tell which capture engine produced a stored video.
That mattered because native terminal video and screenshot replay now coexist in
the same control plane.

This module makes the recording engine explicit without changing the underlying
capture topology.

## 2. Delivered Behavior

### 2.1 Runtime source metadata

`ExternalCheckoutRunner` now emits `capture_engine` at the source:

- `playwright_video` for native terminal browser video;
- `ffmpeg_replay` for screenshot-replay fallback videos.

The same value is written into:

- artifact metadata;
- emitted `media.persisted` payloads (`capture_engine` and `captureEngine`).

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve both:

- `capture_engine`
- `captureEngine`

This keeps browser recording engine metadata aligned with the alias policy used
for IDs, sources, sizes, and download URLs.

### 2.3 WebUI provenance labels

The frontend runtime model now preserves `captureEngine`.

Browser media actions surface engine provenance through labels:

- `Playwright`
- `FFmpeg 回放`

These labels appear in both:

- `BrowserPreview`;
- `LiveTimeline`.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Native recording persistence emits `capture_engine=playwright_video`.
2. Screenshot replay persistence emits `capture_engine=ffmpeg_replay`.
3. Public session projection preserves both capture-engine aliases.
4. Local settings/events projection preserves the same aliases.
5. WebUI media actions render engine provenance when available.
6. Existing recording playback, source attribution, and size labels stay
   intact.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- codec inspection beyond coarse engine identity;
- frame-rate or duration analysis;
- native live capture for attached CDP user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/browserRecording.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/browserRecording.ts)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
