# Watchdog Classifier Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed watchdog classifier slice for Milestone 6.

It closes one concrete gap between stale-context handling and bounded
Computer Use recovery:

```text
structured failure classification
+ explicit recovery routing
+ checkpoint evidence projection
```

It does not yet deliver the full bounded Computer Use recovery loop.

## 1. Module Goal

When script mode fails, Pay-Switch must classify the failure before deciding
whether to:

- continue into Computer Use recovery;
- stop for a login human gate; or
- stop for a manual recovery handoff.

The classifier must be stable enough to keep ordinary UI drift on the fast
recovery path, while failing closed on login, sensitive, and terminal errors.

## 2. Delivered Behavior

### 2.1 Failure taxonomy

`RecoveryWatchdog.register_script_failure()` now classifies failures into:

- `retryable_drift`
- `login_required`
- `sensitive_action`
- `unsupported_page`
- `hard_failure`

### 2.2 Recovery routing contract

The decision model now returns both:

- `classification`
- `recommended_action`

Current routing is:

- `retryable_drift` -> `computer_use_recovery`
- `unsupported_page` -> `computer_use_recovery`
- `login_required` -> `login_human_gate`
- `sensitive_action` -> `human_recovery_gate`
- `hard_failure` -> `human_recovery_gate`

If retryable recovery exhausts the configured attempt budget, the route is
promoted to `human_recovery_gate`.

### 2.3 Orchestrator enforcement

The orchestrator no longer treats all `ScriptExecutionError` failures the same.

It now:

- sends `login_required` failures to `_script_login_handoff()`;
- sends `sensitive_action` and `hard_failure` to `_script_recovery_handoff()`;
- keeps `retryable_drift` and `unsupported_page` on the Computer Use recovery
  path.

### 2.4 Evidence and human-gate metadata

Recovery checkpoint artifacts now include:

- `classification`
- `recommended_action`
- stale-context metadata from the earlier module

Human-gate payloads produced from classifier decisions also include the
resolved classification so the WebUI and operator logs can tell whether the
handoff is for login recovery or a manual-only stop.

### 2.5 Synchronous policy checkpoint signal

The classifier now treats an explicit `synchronous_policy_checkpoint=true`
signal as `sensitive_action`, so a high-risk adapter can fail closed before
recovery continues.

This is only the classification-side contract. It does not yet mean every
adapter emits those checkpoints consistently.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Script failures are classified into the agreed taxonomy.
2. Generic login-tagged script failures stop at the login human gate instead
   of falling through to Computer Use.
3. Hard failures stop at manual recovery instead of entering Computer Use.
4. Retryable drift remains eligible for Computer Use recovery until the retry
   budget is exhausted.
5. Recovery checkpoint evidence records both classification and recommended
   action.

## 4. Verification

- `ruff check payswitch/engine/watchdog.py payswitch/engine/orchestrator.py tests/test_recovery_watchdog.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_recovery_watchdog.py tests/test_integration.py`
- `.venv/bin/python -m compileall payswitch/engine/watchdog.py payswitch/engine/orchestrator.py tests/test_recovery_watchdog.py tests/test_integration.py`

## 5. Non-Goals

This module does not yet deliver:

- bounded Computer Use step/time/token budgets;
- consistent adapter-authored `synchronous_policy_checkpoint` coverage;
- watchdog-driven recipe patch review or promotion;
- full recovery-state verification before each Computer Use action.

## 6. Implementation References

- [payswitch/engine/watchdog.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/watchdog.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [tests/test_recovery_watchdog.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_recovery_watchdog.py)
- [tests/test_integration.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_integration.py)
