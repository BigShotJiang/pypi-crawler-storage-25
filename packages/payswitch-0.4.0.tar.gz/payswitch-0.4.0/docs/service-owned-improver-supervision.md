# Service-Owned Improver Supervision Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed service-owned supervision slice for accepted
recovery improvements.

It closes the next gap after the bounded CLI runner:

```text
accepted improvement runner
+ service-owned startup and shutdown wiring
+ health-visible supervisor state
+ env-configured background polling
```

## 1. Module Goal

Accepted recovery improvements should be processable by the server itself after
they have already been reviewed into the `accepted` state.

This module adds a service-owned supervisor that:

- starts with the FastAPI app lifecycle;
- processes accepted improvements in bounded batches;
- exposes runtime health and last-run telemetry;
- keeps `mainline` promotion outside the automatic path.

## 2. Delivered Behavior

### 2.1 Service-owned supervisor

`RecoveryImprovementSupervisor` now owns a long-running accepted-improvement
loop with:

- configured reviewer identity;
- optional note, platform, and flow filters;
- bounded `batch_limit`;
- configurable `poll_interval_seconds`;
- optional `dry_run`.

### 2.2 FastAPI lifecycle integration

The server now starts and stops the supervisor through FastAPI lifespan
handlers.

When `PAYSWITCH_RECOVERY_IMPROVER_ENABLED` is not enabled, the supervisor stays
disabled and the health surface reports that state explicitly.

### 2.3 Health-visible runtime state

The supervisor now projects its state through:

- `GET /api/recovery-improvements/health`
- `GET /api/health` under `recovery_improver`

The payload includes:

- `enabled`
- `running`
- `reviewer`
- `platform`
- `flow`
- `dry_run`
- `poll_interval_seconds`
- `batch_limit`
- `cycles`
- `total_processed`
- `total_reviewed_patches`
- `last_started_at`
- `last_finished_at`
- `last_error`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. The server can own an accepted-improvement polling loop without CLI input.
2. Supervisor configuration is sourced from environment variables.
3. Startup and shutdown are explicit and do not leave the loop orphaned.
4. Operators can inspect supervisor state through server health APIs.
5. Regression tests cover supervisor execution and server health projection.

## 4. Verification

- `ruff check payswitch/experience/__init__.py payswitch/experience/improver.py payswitch/server.py tests/test_experience_improver.py tests/test_server_recovery_improver.py`
- `.venv/bin/python -m pytest tests/test_experience_improver.py tests/test_server_recovery_improver.py tests/test_server_public_urls.py`

## 5. Non-Goals

This module does not yet deliver:

- autonomous acceptance of open recovery improvements;
- autonomous promotion from `reviewed` patches into `mainline`;
- external daemon packaging beyond the server-owned lifespan contract.

## 6. Implementation References

- [payswitch/experience/improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/improver.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_experience_improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_improver.py)
- [tests/test_server_recovery_improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_recovery_improver.py)
