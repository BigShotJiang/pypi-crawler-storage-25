## Browser Recording Frame-Rate Metadata Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed frame-rate metadata slice for persisted
browser recording artifacts.

It closes the next metadata gap this way:

```text
browser recording artifact already has source, size, duration, and engine
+ runtime source now emits frame_rate
+ server and local settings/events preserve frame-rate aliases
+ WebUI labels recordings with human-readable fps metadata
```

## 1. Module Goal

The browser recording pipeline already exposed:

- stable artifact IDs;
- recording source;
- byte size;
- capture engine;
- duration;
- persisted download URLs.

But operators still could not tell how dense a stored recording actually was.
That mattered because native terminal video and screenshot replay can have very
different visual fidelity even when they are both valid persisted artifacts.

This module adds frame-rate metadata without changing the current capture
topology.

## 2. Delivered Behavior

### 2.1 Runtime source frame-rate metadata

`ExternalCheckoutRunner` now emits `frame_rate` at the source:

- native browser video: best-effort `ffprobe` frame-rate detection from the
  first video stream;
- screenshot replay: deterministic `1fps` based on the current replay
  synthesis rule.

The same value is written into:

- artifact metadata;
- emitted `media.persisted` payloads (`frame_rate` and `frameRate`).

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve both:

- `frame_rate`
- `frameRate`

This keeps frame-rate metadata aligned with the alias policy already used for
artifact ID, source, size, duration, engine, and download metadata.

### 2.3 WebUI fps labels

The frontend runtime model now preserves `frameRate`.

Browser media actions surface human-readable fps labels such as:

- `30fps`
- `1fps`

These labels appear in both:

- `BrowserPreview`;
- `LiveTimeline`.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Native recording persistence can carry best-effort `frame_rate`.
2. Screenshot replay persistence carries deterministic `1fps`.
3. Public session projection preserves both frame-rate aliases.
4. Local settings/events projection preserves the same aliases.
5. WebUI media actions render fps metadata when available.
6. Existing recording playback, source attribution, size, duration, and engine
   labels stay intact.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- codec-level inspection beyond coarse fps metadata;
- timeline-native scrubber or thumbnail generation;
- native live capture for attached CDP user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/lib/formatFrameRate.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/formatFrameRate.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
