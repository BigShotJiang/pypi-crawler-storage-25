# Qwen Recipe-Backed Migration

Date: 2026-05-16
Status: implemented in current branch

This document records the Qwen fast-path migration slice for Milestone 6.

## 1. Goal

Qwen had already gained a fail-closed synchronous checkpoint on its final
confirm click, but the adapter still executed as a purely imperative step chain.

This slice moves Qwen onto the shared `RecipeRunner` contract so it can share
the same waypoint telemetry, synchronous policy checkpoint hook, and durable
outcome model already used by Kimi and DeepSeek.

## 2. Delivered Behavior

### 2.1 Qwen now runs through `RecipeRunner`

`QwenAdapter.execute_topup()` now executes through the shared recipe runner
instead of a purely imperative method body.

The built-in Qwen recipe now defines waypoints for:

- top-up page navigation
- login verification
- amount selection
- payment-method readiness
- confirm-to-checkout transition
- QR wait state

### 2.2 Runner-level checkpoint is now present on Qwen confirm

The `confirm_topup_checkout` waypoint is now marked with
`synchronous_policy_checkpoint=true`.

Before Qwen enters the final confirm transition, the runner-level checkpoint now
re-validates login state and requires visible payment markers such as:

- `支付宝`
- `支付方式`
- `确认充值`
- `去支付`

The older adapter-level fail-closed confirm guard remains in place, so the path
is protected both at the semantic runner layer and at the direct click helper.

### 2.3 Durable recipe outcomes

Qwen now records recipe success/failure outcomes into the experience store with
recipe id/version metadata, matching the current recipe-backed adapters.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Qwen top-up runs through the shared recipe runner.
2. Qwen exposes a built-in recipe with explicit confirm and QR waypoints.
3. The Qwen confirm transition cannot proceed without a runner-level checkpoint
   pass.
4. Qwen recipe outcomes are durable in the experience store.
5. Targeted tests prove recipe metadata, checkpoint blocking, checkpoint pass,
   and outcome persistence.

## 4. Verification

- `ruff check payswitch/adapters/qwen.py payswitch/experience/registry.py tests/test_adapters.py`
- `.venv/bin/python -m pytest tests/test_adapters.py`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- recipe-backed migration for Jimeng, Volcano, or NineEmail;
- protocol-level payment routing changes;
- promotion of Qwen recovery candidates into mainline behavior without review.

## 6. Implementation References

- [payswitch/adapters/qwen.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/qwen.py)
- [payswitch/experience/registry.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/registry.py)
- [tests/test_adapters.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_adapters.py)
