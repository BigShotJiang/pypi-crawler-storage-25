# Pay-Switch Framework Alignment Roadmap

Date: 2026-05-16
Status: active implementation guide

This document is the execution bridge between:

- the target architecture in [docs/agent-workspace-framework.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/agent-workspace-framework.md)
- the current in-repo implementation

It exists for one purpose:

```text
Pull the current project back onto the agreed framework line,
then define the exact development route, implementation rules,
and acceptance gates for the next iterations.
```

This is not a vision document. It is a delivery document.

## 1. Executive Decision

The project must continue on the following main line:

```text
User-scoped workspace runtime
-> logical subagent session per payment task
-> fast recipe-backed adapter
-> asynchronous Agent watchdog
-> bounded Computer Use recovery
-> Human Gate for sensitive actions
-> encrypted artifact and ledger
```

The project must **not** drift back to any of these anti-patterns:

- one shared browser/display for all users,
- global latest-session UI behavior,
- adapter logic buried as ad hoc selectors in orchestration code,
- Computer Use as the default path for ordinary flows,
- plaintext secret delivery or unscoped noVNC access,
- fake session switching in the UI while the runtime is still shared underneath.

## 2. Current Baseline vs Target Architecture

### 2.1 What already matches the architecture

The following parts are already aligned and should be preserved:

| Area | Current implementation evidence | Why it is aligned |
|---|---|---|
| User/workspace/subagent identity | [payswitch/agent_workspace.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/agent_workspace.py), [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py) | The system no longer treats a payment as only a bare task id. |
| Same-user site/profile serialization | [payswitch/agent_workspace.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/agent_workspace.py) | This is the correct first protection against profile pollution. |
| Foreground lease semantics | [payswitch/agent_workspace.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/agent_workspace.py), [payswitch/subagent_harness.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/subagent_harness.py) | This is the right seam for Human Gate and visible browser ownership. |
| Replayable event stream | [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py), [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts) | Replay and checkpoint reconnect are required for a real session model. |
| Session snapshot identity projection | [frontend/src/lib/sessionSnapshot.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionSnapshot.ts) | The UI can now reason about user/workspace/session identity. |
| Secret redaction and review invariants | [payswitch/subagent_harness.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/subagent_harness.py) | This is the correct direction for auditable harness behavior. |
| Secret envelope hardening | [payswitch/security/secret_envelope.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/secret_envelope.py) | This matches the agreed artifact-security model. |

### 2.2 What is still transitional and not yet the target architecture

These parts are transitional only. They must not be mistaken for the final design:

| Area | Current state | Required target |
|---|---|---|
| Runtime isolation | In-process `AgentWorkspaceManager` | user-scoped runtime or container with isolated browser/display/profile volume |
| Browser ownership | identity fields exist, but no real display/runtime binding yet | browser runtime, focus, and noVNC must be session-aware and enforced |
| Session visibility | UI can project session identity, but runtime display ownership is still incomplete | selecting a session must deterministically show the correct live runtime |
| Profile lifecycle | profile ids exist, but promotion/rollback lifecycle is not fully implemented | stable profile vault + task profile + atomic promotion + rollback |
| Adapter architecture | no recipe runner/registry mainline yet | recipe-backed fast path with waypoint telemetry |
| Agent role | no complete watchdog loop yet | asynchronous supervision and bounded recovery only at failure boundaries |
| Computer Use | not yet integrated as a fully bounded recovery subsystem | shared context aware, focus safe, budget enforced recovery path |
| Persistence | task/session state is still in memory | SQLite-backed durable metadata and replay |
| noVNC routing | public URL rewriting exists | user/session scoped route registry with lease-bound token |

### 2.3 Architecture verdict on the current code

The current codebase is **directionally correct** but **incomplete**.

Exact verdict:

```text
The project has entered the correct architecture seam,
but it is still implementing the control-plane and scheduling layer.
It has not yet completed the runtime-isolation layer,
the recipe execution layer, or the recovery loop.
```

This means:

- no rollback to the old model,
- no rewrite from scratch,
- no claim that the architecture is already fully implemented.

## 3. Mandatory Architecture Constraints

Every future change must satisfy all of the following constraints.

### 3.1 Isolation constraints

- One user must never see or operate another user's runtime.
- One user workspace must never mount another user's profile vault.
- One active foreground lease per workspace at a time.
- Same user + same site/profile mutating work must serialize.
- Any future visible concurrency must prove focus-safe operation before it is enabled.

### 3.2 Adapter constraints

- Adapter is the default path for supported sites.
- Adapter must execute without per-click Agent approval.
- Adapter must emit waypoint telemetry.
- Adapter must stop at sensitive actions.
- Adapter must fail fast on waypoint assertion failure.

### 3.3 Agent constraints

- Agent is not the default click loop.
- Agent consumes telemetry asynchronously.
- Agent intervenes only on failure, uncertainty, policy gate, or budget risk.
- Agent recovery must be bounded by explicit limits.
- Agent success should produce recipe-improvement output.

### 3.4 Human Gate constraints

- Human Gate owns QR scan, OTP, CVV/CVC, password, and final irreversible confirmation.
- Human Gate UI must name the selected session clearly.
- Human Gate must not imply that the agent will complete the sensitive step.
- Human Gate session access must be short-lived and scoped.

### 3.5 Security constraints

- noVNC access must be scoped to `user_id + session_id + lease`.
- Task/session/event persistence must never store plaintext secrets.
- Artifact delivery must use the active client public key.
- Profile storage must remain user-scoped and lock-aware.

## 4. Workstream Plan

The roadmap is organized by workstream, not by vague product milestone names.

### 4.1 Workstream A: Control Plane and Durable Session Model

### Goal

Turn the current in-memory session model into a durable, user-scoped control plane.

### Current baseline

- `AgentTask` already carries user/workspace/session identity.
- event streaming already supports sequence replay.
- session list/snapshot projection already exists in the frontend.

### Required implementation

1. Persist task metadata, session metadata, and event metadata to SQLite.
2. Add explicit user-scoped query rules for:
   - list sessions
   - fetch session
   - subscribe to events
3. Remove any remaining global latest-session behavior from server and UI decision paths.
4. Add typed persistence shape for:
   - task
   - session
   - workspace
   - event
   - human gate state

### Target files/modules

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- new persistent store module under `/payswitch/`
- [frontend/src/lib/sessionSnapshot.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionSnapshot.ts)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)

### Acceptance gates

- Restarting the server does not erase active session metadata that should be resumable.
- `/api/sessions` returns only the current user's visible sessions.
- `/api/sessions/latest` is either removed from UI-critical paths or explicitly user-scoped.
- Event replay after restart preserves ordering and sequence continuity rules.

### 4.2 Workstream B: User Workspace Runtime Boundary

### Goal

Replace logical-only workspace ownership with a real user-scoped runtime boundary.

### Current baseline

- `AgentWorkspaceManager` gives correct in-process ownership semantics.
- no real runtime/container boundary exists yet.

### Required implementation

1. Define `WorkspaceRuntime` interface.
2. Provide V1 implementation:
   - one runtime per user
   - one browser/display/noVNC stack per runtime
3. Bind runtime lifecycle to workspace lifecycle:
   - create
   - warm
   - sleep
   - resume
   - destroy
4. Route session display ownership through runtime, not through loose public URLs.
5. Include idle timeout, cleanup, and resource reclamation in the first runtime implementation so multi-user tests do not exhaust host memory.
6. Add host-level admission control for the first single-node runtime:
   - maximum active user workspaces,
   - maximum warm idle workspaces,
   - maximum workspace memory budget,
   - queued admission state when capacity is exhausted.

### Target files/modules

- [payswitch/agent_workspace.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/agent_workspace.py)
- new runtime modules under `/payswitch/`
- server routing and workspace registry code

### Acceptance gates

- User A and User B can run separate tasks without display conflict.
- Stopping one user's runtime does not affect another user.
- Session selection resolves to the correct runtime-owned display surface.
- Runtime health can report active sessions, memory use, and display readiness.
- Idle runtime can sleep or be reclaimed without dropping the persistent profile vault.
- When host capacity is exhausted, new workspace creation is queued or rejected with a typed capacity status; it must not keep spawning containers until the host OOMs.

### 4.3 Workstream C: Browser and Display Ownership

### Goal

Make visible browser operation session-correct and focus-safe.

### Current baseline

- session identity exists
- foreground lease exists
- no actual browser/display focus enforcement exists yet

### Required implementation

1. Introduce Browser Manager abstraction inside the user runtime.
2. Add `display_focus_lock` around any Computer Use or foreground-visible action.
3. Before every visible action:
   - bring target session/tab/context to front
   - verify active target matches the session
   - verify window z-order still matches the foreground lease
4. Support display-state reasons:
   - no runtime
   - waiting for foreground
   - visible adapter not available
   - human gate open
5. Background tasks in the same workspace must not raise a visible window while another session owns the foreground lease. If they cannot guarantee that, they must queue or pause.

### Target files/modules

- browser/runtime modules under `/payswitch/`
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- frontend session display components

### Acceptance gates

- UI session switch changes the actual visible runtime surface.
- Computer Use cannot act when foreground verification fails.
- A session with no active visible surface reports a clear reason instead of a fake black box.
- noVNC route points at the selected session's foreground lease, not a generic shared display.
- A background adapter task cannot steal focus or appear above the foreground Computer Use/Human Gate session.

### 4.4 Workstream D: Profile Vault and Promotion

### Goal

Move profile handling from identifiers to a safe lifecycle.

### Current baseline

- `profile_id` exists
- site/profile locking exists
- no full profile promotion workflow yet

### Required implementation

1. Define profile vault layout per user and per site.
2. Add task profile creation from stable profile.
3. Add profile promotion:
   - stable -> backup
   - task -> stable
   - verify
   - remove backup
4. Add rollback on promotion failure.
5. Record promotion audit metadata.
6. Require full browser quiescence before promotion. Graceful shutdown is attempted first, but any browser process still holding the profile must be force-terminated before atomic move.
7. Check profile schema compatibility before a stable profile is opened by a workspace runtime.

### Target files/modules

- new profile manager module under `/payswitch/`
- [payswitch/agent_workspace.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/agent_workspace.py)
- ledger/audit modules

### Acceptance gates

- Successful login state can persist across tasks.
- Failed or cancelled task profile changes do not pollute the stable profile.
- Forced promotion failure restores the previous stable profile.
- Same profile cannot be promoted concurrently.
- Promotion fails closed if browser locks remain after graceful shutdown and succeeds only after lock ownership is cleared.
- A browser/profile schema mismatch enters migration, copy-on-write, or fail-closed state; it must not write directly into the stable profile.

### 4.5 Workstream E: Recipe Runner and Experience Registry

### Goal

Make adapter execution fast, explicit, inspectable, and updatable without orchestration churn.

### Current baseline

- architecture doc defines the desired recipe model
- current code has not yet moved adapter execution onto recipe-backed primitives

### Required implementation

1. Define recipe schema and versioning.
2. Build Recipe Runner with semantic action resolution.
3. Emit structured waypoint telemetry.
4. Convert Kimi monthly membership path first.
5. Store recipe confidence and execution outcomes.
6. Store recovery-generated recipe patches as candidates first:
   - `candidate`
   - `shadow_run`
   - `reviewed`
   - `mainline`
7. Require shadow-run success or human review before a recovery-generated patch can affect the main fast path.

### Target files/modules

- new recipe/registry modules under `/payswitch/`
- current adapter/orchestrator path
- ledger/telemetry event emission path

### Acceptance gates

- Kimi supported flow executes through recipe runner.
- Recipe success path does not wait on Agent per step.
- Waypoint failure emits screenshot, DOM summary, visible text summary, and failed assertion data.
- Updating a recipe does not require core orchestration rewrites.
- A Computer Use-generated recipe patch cannot become mainline until it passes shadow-run validation or explicit review.

### 4.6 Workstream F: Agent Watchdog and Computer Use Recovery

### Goal

Use the Agent where it adds value and nowhere else.

### Current baseline

- event telemetry exists
- redaction and review helpers exist
- no complete watchdog-recovery loop yet

### Required implementation

1. Build rolling telemetry buffer per session.
2. Add watchdog classifier:
   - retryable drift
   - login required
   - sensitive action
   - unsupported page
   - hard failure
3. Add bounded Computer Use recovery entrypoint.
4. Feed recovery output back into recipe patch suggestions.
5. Add `synchronous_policy_checkpoint` support for high-risk waypoints where asynchronous supervision is not enough.
6. Add stale-context policy for rolling telemetry buffers after pause/resume.
7. Define a default `telemetry_ttl` configuration value. The default is 5 minutes unless a site-specific adapter requires a shorter value.

### Target files/modules

- new watchdog/recovery modules under `/payswitch/`
- orchestrator integration
- event stream integration

### Acceptance gates

- Failed waypoint hands a compact recovery context to Agent.
- Computer Use verifies page state before action.
- Recovery obeys configured step/token/time budgets.
- Sensitive recovery states still stop at Human Gate.
- Successful recovery can output a machine-readable recipe patch suggestion.
- High-risk waypoints can block adapter progress until Watchdog or policy verification passes.
- Resuming a task after the telemetry TTL forces page re-synchronization before Watchdog or Computer Use trusts old context.
- The default telemetry TTL is configured and testable; adapters may lower it but must not silently extend it for payment surfaces.

### 4.7 Workstream G: Human Gate and Session Handoff

### Goal

Make human handoff explicit, user-owned, and operationally clear.

### Current baseline

- wording improvements are already in place
- foreground lease primitives exist
- complete runtime-bound Human Gate flow is not done

### Required implementation

1. Make Human Gate state first-class in persisted session state.
2. Bind Human Gate to:
   - session
   - workspace
   - foreground lease
   - scoped access token
3. Support resume from another device with active artifact public key replacement.
4. Show why user input is required and what action is expected.

### Target files/modules

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- WebUI session and modal components
- artifact encryption flow

### Acceptance gates

- Human Gate can be reopened for the same session without losing session identity.
- User can resume on another device without exposing another user's session.
- Final sensitive action remains outside agent control.
- Session UI clearly names merchant, amount, reason, and required action.

### 4.8 Workstream H: noVNC Routing and Scoped Access

### Goal

Turn display access into a scoped routing system, not a public shared endpoint.

### Current baseline

- public noVNC URL rewriting exists
- route registry and scoped runtime binding do not exist yet

### Required implementation

1. Add runtime route registry.
2. Issue short-lived noVNC token bound to:
   - `user_id`
   - `session_id`
   - `foreground_lease_id`
3. Revoke route/token when:
   - session ends
   - foreground lease changes
   - token expires
4. Ensure `/pay-switch` does not render an unrelated display on default load.

### Target files/modules

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- runtime gateway/proxy modules
- frontend display ownership logic

### Acceptance gates

- One session token cannot open another session's display.
- Expired or replaced foreground lease invalidates prior display access.
- New runtime routes can be registered and removed without proxy restart.
- Default dashboard view never leaks another user's visible session.

### 4.9 Workstream I: Security, Retention, and Cost Controls

### Goal

Make the system safe and operationally affordable before scaling behavior is expanded.

### Current baseline

- secret envelope hardening exists
- event redaction exists
- retention and budget are not fully implemented end to end

### Required implementation

1. Add artifact classification and retention metadata.
2. Add cleanup worker for hot/warm artifact TTL.
3. Add recovery and screenshot budgets to session state.
4. Add workspace idle sleep and wake policy.
5. Add user-visible failure reasons when budget or timeout is hit.

### Target files/modules

- artifact writer/storage code
- session/task persistence
- runtime lifecycle manager
- ledger/audit code

### Acceptance gates

- Successful tasks retain at most policy-allowed screenshots.
- Sensitive artifacts are encrypted or redacted before storage.
- Expired artifacts are removed automatically.
- Budget exhaustion is reflected in session state and task result.
- Idle runtime sleeps without losing persistent profile state.

## 5. Ordered Delivery Roadmap

Development must proceed in the following order. Do not skip ahead for visible UI polish while the runtime model is still false underneath.

### Milestone 1: Durable session truth

Deliver:

- persistent session/task/event metadata
- user-scoped session APIs
- removal of global latest-session dependence in critical UI paths

Exit criteria:

- session list, snapshot, and event replay are durable and user-scoped

### Milestone 2: Real user runtime boundary

Deliver:

- `WorkspaceRuntime` abstraction
- one runtime per user
- runtime health and lifecycle
- scoped runtime display routing
- idle sleep and cleanup
- profile-vault lifecycle entrypoints
- host-level admission control

Exit criteria:

- one user's display/runtime cannot conflict with another user's

### Milestone 3: Real session-to-display ownership

Deliver:

- Browser Manager
- foreground/display focus lock
- runtime-backed display switching
- scoped noVNC route ownership
- window z-order enforcement

Exit criteria:

- selecting a session shows the correct actual browser surface

Current branch closure for the control-plane/WebUI portion:

- complete session-scoped display state projection in the frontend;
- display takeover links exposed only when `display_ready` is true;
- Human Gate bound to the active session identity and display route;
- user-scoped display selection and view routes now reject missing or wrong
  `user_id`.

Still deferred inside this milestone:

- guaranteed runtime/window z-order enforcement;
- true browser-process attachment of the selected session into a single
  visible runtime surface across all cases.

### Milestone 4: Profile safety

Deliver:

- profile vault layout
- task profile creation
- promotion and rollback
- profile schema compatibility gate

Exit criteria:

- login state persists safely without cross-task corruption

### Milestone 5: Fast adapter path

Deliver:

- recipe schema
- recipe runner
- Kimi recipe-backed path
- candidate/shadow-run promotion for recovered recipe patches

Exit criteria:

- supported Kimi path can reach payment surface at adapter speed with waypoint telemetry

### Milestone 6: Recovery intelligence

Deliver:

- telemetry buffer
- watchdog classifier
- bounded Computer Use recovery
- recipe patch suggestions
- synchronous policy checkpoints
- stale-context re-synchronization

Exit criteria:

- supported flow can recover from controlled UI drift without falling back to a blind manual process

### Milestone 7: Human Gate and artifact hardening

Deliver:

- complete Human Gate state
- scoped noVNC token
- encrypted artifact flow
- retention enforcement

Exit criteria:

- user handoff is secure, explicit, and resumable

## 6. Development Standards

These standards are mandatory for all framework-aligned changes.

### 6.1 Code structure standards

- Do not mix runtime-isolation logic into ad hoc route handlers.
- Do not bury profile lifecycle logic in browser helpers.
- Do not embed recipe definitions deep inside orchestration conditionals.
- Every major runtime concept must have its own module boundary:
  - workspace runtime
  - browser manager
  - profile manager
  - recipe runner
  - watchdog
  - recovery

### 6.2 Event standards

Every stateful feature must expose typed events or typed persistent state transitions.

Minimum required properties for significant events:

- `task_id`
- `session_id`
- `user_id`
- `workspace_id`
- `type`
- `sequence`
- `ts`

For visible actions, include enough context to debug the action later.

### 6.3 UI truthfulness standards

The WebUI must never imply a capability the runtime does not actually provide.

Examples:

- Do not show a generic shared display as if it belongs to the selected session.
- Do not label a task as resumable if no resumable state exists.
- Do not show Human Gate as live if no scoped visible surface is available.
- Do not show another user's or another session's noVNC state by default.

### 6.4 Testing standards

Every workstream above must ship with:

- unit tests for state transitions
- concurrency tests where locking semantics matter
- persistence/restart tests where session durability matters
- security tests where scope or secret handling matters
- UI projection tests where session selection or display state matters
- host-pressure tests for multi-user idle runtime cleanup
- profile-promotion tests that simulate browser lock-file residue after graceful shutdown
- admission-control tests that prove capacity exhaustion queues or rejects workspaces without spawning unbounded containers
- recipe-patch promotion tests that prove candidates cannot affect the mainline fast path before review or shadow-run success
- stale-watchdog-context tests that prove resumed tasks re-synchronize after telemetry TTL expiry
- telemetry TTL configuration tests that prove the default is applied and site-specific overrides cannot silently weaken payment-surface safety

### 6.5 Commit and review standards

Changes must stay atomic:

- one independent infrastructure step per commit
- one independent adapter or recipe step per commit
- no mixing architecture refactor with unrelated UI polish

PR review must answer:

1. Which architecture workstream does this change advance?
2. What false behavior, if any, still remains after this PR?
3. Which acceptance gate from this document is now satisfied?
4. Does this change affect profile, display, noVNC, secret handling, or Computer Use?
5. If it changes recipe behavior, is the change mainline, candidate, or shadow-run only?

## 7. Acceptance Checklist

No milestone is done until all relevant checks pass.

### 7.1 Runtime alignment checks

- [ ] Different users do not share browser runtime or display.
- [ ] Same user site/profile mutation is serialized.
- [ ] Foreground lease prevents visible action conflicts.
- [ ] Session switch maps to the correct runtime-owned visible surface.

### 7.2 Adapter alignment checks

- [ ] Supported path runs through recipe-backed adapter.
- [ ] Adapter emits waypoint telemetry.
- [ ] Adapter failure stops immediately and produces structured failure context.
- [ ] Sensitive actions stop at Human Gate.

### 7.3 Recovery alignment checks

- [ ] Agent intervention is asynchronous on the fast path.
- [ ] Computer Use recovery is bounded and focus-safe.
- [ ] Recovery output can produce recipe improvement artifacts.

### 7.4 Security alignment checks

- [ ] Session/display access is scoped to user and session.
- [ ] Secrets are redacted in stored events.
- [ ] Sensitive artifacts are encrypted before persistence.
- [ ] Profile promotion and rollback are auditable.

### 7.5 Operational alignment checks

- [ ] Session state survives process restart where required.
- [ ] Artifact retention is enforced automatically.
- [ ] Budget exhaustion and timeout are visible in task state.
- [ ] Idle runtime sleep/wake works without losing persistent profile state.
- [ ] Host-level admission control prevents unbounded workspace creation.
- [ ] Stale watchdog context is discarded or refreshed before recovery continues.

## 8. What must happen next

The next development batch should focus on these items only:

1. durable session/task/event persistence
2. user-scoped session querying
3. `WorkspaceRuntime` abstraction
4. real runtime-owned display routing
5. profile vault and promotion design
6. idle runtime cleanup and sleep policy
7. host-level admission control
8. recipe patch candidate/shadow-run policy
9. watchdog synchronous checkpoint and stale-context policy

The following should **not** be prioritized before the above are complete:

- broad adapter expansion to many sites
- cosmetic dashboard work
- pseudo-concurrency in the same visible runtime
- protocol-provider implementation

## 9. Final implementation stance

The correct implementation stance for the current repository is:

```text
Preserve the current workspace/subagent identity model.
Do not roll back the new session semantics.
Build downward into real runtime isolation and profile safety.
Build upward into recipe execution and Agent recovery.
Use the UI only to expose true runtime ownership, not to hide runtime gaps.
```

That is the line that keeps the current project aligned with the agreed framework and makes future development reviewable and testable.
