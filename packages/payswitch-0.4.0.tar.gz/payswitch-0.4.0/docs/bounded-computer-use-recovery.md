# Bounded Computer Use Recovery Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed bounded Computer Use recovery-entrypoint
slice for Milestone 6.

It closes one concrete gap between failure classification and later recovery
improvement work:

```text
bounded recovery entrypoint
+ explicit budget contract
+ user-visible timeout/budget state
```

It does not yet deliver the full recovery-improver loop.

## 1. Module Goal

Computer Use recovery must stop being an unbounded fallback path.

When Pay-Switch enters internal or hybrid Computer Use recovery, it must carry
an explicit budget envelope that limits:

- maximum recovery steps;
- maximum screenshot observations;
- maximum model output tokens;
- maximum wall time.

Those limits must be visible in task state and handoff state.

## 2. Delivered Behavior

### 2.1 Recovery budget configuration

`PaySwitchConfig` now defines:

- `recovery_max_computer_use_steps`
- `recovery_max_computer_use_screenshots`
- `recovery_max_computer_use_model_tokens`
- `recovery_max_computer_use_step_output_tokens`
- `recovery_max_computer_use_wall_time_seconds`

### 2.2 Shared budget object

`ComputerUseRecoveryBudget` is now the shared runtime contract between the
orchestrator and the explorer.

The current explorer treats one recovery step as one screenshot observation, so
the effective step ceiling is:

```text
min(max_steps, max_screenshots, max_model_tokens / max_step_output_tokens)
```

### 2.3 Explorer and Skyvern enforcement

The internal Computer Use path now:

- clamps recovery step count from the shared budget;
- passes `max_output_tokens` down to `SkyvernEngine`;
- enforces wall time through `asyncio.timeout(...)`.

### 2.4 Visible task-state projection

The orchestrator now projects the budget into:

- the Computer Use start step description;
- external Computer Use handoff details;
- external handoff evidence payloads.

If hybrid/internal recovery times out, the timeout reason is preserved in the
step stream and the external fallback handoff.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Recovery entrypoints use an explicit budget object instead of hard-coded
   implicit limits.
2. Effective recovery steps are bounded by step, screenshot, and token limits.
3. Internal recovery wall time is bounded and produces a user-visible reason on
   timeout.
4. Hybrid fallback preserves the bounded-recovery failure reason before
   switching to external Computer Use.
5. Budget metadata is visible in human handoff details/evidence.

## 4. Verification

- `ruff check payswitch/models/config.py payswitch/browser/computer_use.py payswitch/browser/skyvern.py payswitch/engine/orchestrator.py tests/test_models.py tests/test_computer_use.py tests/test_skyvern.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_models.py tests/test_computer_use.py tests/test_skyvern.py tests/test_integration.py`
- `.venv/bin/python -m compileall payswitch/models/config.py payswitch/browser/computer_use.py payswitch/browser/skyvern.py payswitch/engine/orchestrator.py tests/test_models.py tests/test_computer_use.py tests/test_skyvern.py tests/test_integration.py`

## 5. Non-Goals

This module does not yet deliver:

- actual model-usage metering from provider responses; the token budget is
  enforced as a deterministic upper envelope per step;
- recovery-generated recipe patch suggestions after successful Computer Use;
- full watchdog verification before every recovery action;
- adapter-wide `synchronous_policy_checkpoint` coverage.

## 6. Implementation References

- [payswitch/models/config.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/models/config.py)
- [payswitch/browser/computer_use.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/computer_use.py)
- [payswitch/browser/skyvern.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/skyvern.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [tests/test_computer_use.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_computer_use.py)
- [tests/test_skyvern.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_skyvern.py)
- [tests/test_integration.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_integration.py)
