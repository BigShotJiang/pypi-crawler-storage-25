# Cross-Host Artifact Handoff Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed cross-host artifact-coordination baseline
for encrypted evidence transfer between Pay-Switch hosts.

It closes the next storage-governance gap after local artifact budgets:

```text
local encrypted artifact store
+ host inbox identity
+ encrypted handoff export
+ encrypted handoff import
+ CLI and health visibility
```

## 1. Module Goal

Local artifact encryption and retention already existed, but there was still no
governed way to move evidence from one host to another without decrypting it
manually and rebuilding metadata by hand.

This module adds a cross-host handoff baseline so operators can:

- inspect the current host inbox identity;
- export any artifact into an encrypted handoff bundle for another host;
- import that bundle on the target host and re-encrypt it into the local
  artifact store;
- verify host inbox identity through the server health surface.

## 2. Delivered Behavior

### 2.1 Artifact inbox summary

`ArtifactStore` now exposes `local_inbox_summary(...)` with:

- `algorithm`
- `created_at`
- `recipient_id`
- optional `public_key`

The CLI now exposes:

- `payswitch artifact inbox`

### 2.2 Encrypted handoff bundles

`ArtifactStore.export_handoff_bundle(...)` now:

- reads artifact metadata and payload;
- decrypts local encrypted artifacts when needed;
- re-encrypts the payload to the target host public key;
- emits a durable handoff bundle with artifact kind, sensitivity, content type,
  retention, and source metadata.

### 2.3 Import into the target host store

`ArtifactStore.import_handoff_bundle(...)` now:

- decrypts the bundle with the local host inbox private key;
- writes the payload through the local artifact store;
- preserves artifact kind, sensitivity, retention, and prior metadata;
- records handoff provenance metadata such as source recipient id and import time.

### 2.4 CLI and server surfaces

The CLI now exposes:

- `payswitch artifact export`
- `payswitch artifact import`

The server now exposes:

- `GET /api/artifact-inbox/health`
- `GET /api/health` under `artifact_inbox`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Operators can inspect the current host inbox identity from the CLI.
2. An artifact can be exported as an encrypted handoff bundle for another host.
3. The target host can import that bundle and read the artifact through the local store.
4. Imported metadata retains source provenance.
5. Server health exposes host inbox identity without exposing private key material.

## 4. Verification

- `ruff check payswitch/security/artifacts.py payswitch/cli.py payswitch/server.py tests/test_artifact_store.py tests/test_cli_artifact_handoff.py tests/test_server_artifact_inbox.py`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_cli_artifact_handoff.py tests/test_server_artifact_inbox.py -q`
- `.venv/bin/python -m pytest tests/test_artifact_inventory.py tests/test_server_artifact_inventory.py tests/test_cli_artifact_stats.py tests/test_artifact_cleanup.py tests/test_server_artifact_cleanup.py tests/test_cli_artifact_cleanup.py tests/test_artifact_budget_enforcement.py tests/test_server_artifact_budget_enforcement.py tests/test_cli_artifact_budget_enforcement.py -q`

## 5. Non-Goals

This module does not yet deliver:

- distributed artifact replication or fan-out delivery;
- automatic artifact-key rotation;
- non-image binary coverage beyond the current screenshot PNG baseline;
- remote key escrow or third-party KMS integration.

## 6. Implementation References

- [payswitch/security/artifacts.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/artifacts.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_artifact_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_artifact_store.py)
- [tests/test_cli_artifact_handoff.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_artifact_handoff.py)
- [tests/test_server_artifact_inbox.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_artifact_inbox.py)
