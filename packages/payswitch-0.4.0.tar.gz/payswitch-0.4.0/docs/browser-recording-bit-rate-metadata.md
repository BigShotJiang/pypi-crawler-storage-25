## Browser Recording Bit-Rate Metadata Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed bit-rate metadata slice for persisted
browser recording artifacts.

It closes the next metadata gap this way:

```text
browser recording artifact already has source, size, duration, fps, resolution, codec, and engine
+ runtime source now emits bit_rate
+ server and local settings/events preserve bit-rate aliases
+ WebUI labels recordings with human-readable bit-rate metadata
```

## 1. Module Goal

The browser recording pipeline already exposed:

- stable artifact IDs;
- recording source;
- byte size;
- capture engine;
- duration;
- fps;
- resolution;
- codec;
- persisted download URLs.

But operators still could not tell the approximate encoded video bit rate of a
stored recording. That left playback density and replay-versus-native quality
harder to compare from the control plane.

This module adds bit-rate metadata without changing how recordings are captured
or delivered.

## 2. Delivered Behavior

### 2.1 Runtime source bit-rate metadata

`ExternalCheckoutRunner` now emits best-effort `bit_rate` at the source:

- native browser video: `ffprobe` reads the first video stream bit rate after
  the recording file is finalized;
- screenshot replay: the same best-effort video-stream probe runs after replay
  synthesis completes.

The same value is written into:

- artifact metadata;
- emitted `media.persisted` payloads (`bit_rate`, `bitRate`).

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve both:

- `bit_rate`
- `bitRate`

This keeps bit-rate metadata aligned with the alias policy already used for
artifact ID, source, size, duration, fps, resolution, codec, engine, and
download metadata.

### 2.3 WebUI bit-rate labels

The frontend runtime model now preserves `bitRate`.

Browser media actions surface human-readable bit-rate labels such as:

- `2 Mbps`
- `800 kbps`

These labels appear in both:

- `BrowserPreview`;
- `LiveTimeline`.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Native recording persistence can carry best-effort `bit_rate`.
2. Screenshot replay persistence can carry the same bit-rate metadata.
3. Public session projection preserves both bit-rate aliases.
4. Local settings/events projection preserves the same aliases.
5. WebUI media actions render bit-rate metadata when available.
6. Existing recording playback, source attribution, size, duration, fps,
   resolution, codec, and engine labels stay intact.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- per-scene or time-sliced quality metrics;
- audio stream bit-rate inspection;
- native live capture for attached CDP user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/lib/formatBitRate.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/formatBitRate.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
