# Pay-Switch Agent Service

Fixed server path:

```text
/home/bobo/payswitch
/home/bobo/payswitch/bin/payswitch-agent
/home/bobo/.payswitch/server.env
```

Pay-Switch Language:

```text
PAY <amount> <currency> TO <payee> FOR "<reason>" VIA <method> EXECUTE
PAY 50 CNY TO jimeng FOR "Jimeng points top-up for image and video generation" VIA alipay_qr DRY_RUN
```

REST payment request:

```bash
curl -X POST http://127.0.0.1:8787/api/payments \
  -H "Authorization: Bearer $PAYSWITCH_AGENT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"amount":50,"currency":"CNY","payee":"jimeng","reason":"Jimeng points top-up for image and video generation","method":"alipay_qr","dryRun":true}'
```

A2A message request:

```bash
curl -X POST http://127.0.0.1:8787/message:send \
  -H "Authorization: Bearer $PAYSWITCH_AGENT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "message": {
      "role": "user",
      "parts": [
        {
          "kind": "data",
          "data": {
            "payment": {
              "amount": 50,
              "currency": "CNY",
              "payee": "jimeng",
              "reason": "Jimeng points top-up for image and video generation",
              "method": "alipay_qr",
              "dryRun": true
            }
          }
        }
      ]
    }
  }'
```

Agent Card:

```text
GET /.well-known/agent-card.json
GET /.well-known/agent.json
```

Installable agent client:

```bash
python3 -c "import json, urllib.request; cfg=json.load(urllib.request.urlopen('https://clawhunt.store/api/pay-switch/config')); base=cfg['public_url'].rstrip('/'); exec(urllib.request.urlopen(base + '/api/payagent/install.py').read().decode())" --force && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py secret init && python3 ~/.payagent/pay-switch-agent/scripts/payswitch_agent.py probe
payagent submit --payee jimeng --amount 50 --currency CNY --reason "Jimeng points top-up for image and video generation" --method alipay_qr --execute
payagent submit --payee deepseek --product api-key --amount 10 --currency CNY --reason "DeepSeek API key purchase/top-up" --method alipay_qr --request-api-key --execute
```

Live dashboard:

```text
http://178.128.93.176:8787/
GET /events?session_id=<task_id>
```
