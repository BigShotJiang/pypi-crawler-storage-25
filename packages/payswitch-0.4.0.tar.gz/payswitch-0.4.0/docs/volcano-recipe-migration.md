# Volcano Recipe-Backed Migration

Date: 2026-05-16
Status: implemented in current branch

This document records the Volcano fast-path migration slice for Milestone 6.

## 1. Goal

Volcano already had a fail-closed final payment checkpoint, but its recharge
path still executed as a purely imperative sequence.

This slice moves Volcano onto the shared `RecipeRunner` contract so the path can
share the same semantic waypoint model, runner-level synchronous checkpoint, and
durable recipe outcomes used by the newer fast-path adapters.

## 2. Delivered Behavior

### 2.1 Volcano now runs through `RecipeRunner`

`VolcanoAdapter.execute_topup()` now executes through the shared recipe runner
instead of a purely imperative method body.

The built-in Volcano recipe now defines waypoints for:

- top-up page navigation
- login verification
- amount selection
- continue-to-payment transition
- payment-method readiness
- confirm-to-checkout transition
- QR/payment-gate wait state

### 2.2 Runner-level checkpoint is now present on Volcano confirm

The `confirm_topup_checkout` waypoint is now marked with
`synchronous_policy_checkpoint=true`.

Before Volcano enters the final pay transition, the runner-level checkpoint now
re-validates login state and requires visible payment markers such as:

- `支付宝`
- `微信`
- `网银`
- `支付方式`
- `去支付`
- `确认订单`

The older adapter-level fail-closed confirm guard remains in place, so the path
is protected at both the semantic runner layer and the direct click helper.

### 2.3 Durable recipe outcomes

Volcano now records recipe success/failure outcomes into the experience store
with recipe id/version metadata.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Volcano top-up runs through the shared recipe runner.
2. Volcano exposes a built-in recipe with explicit continue, confirm, and
   payment-gate waypoints.
3. The Volcano confirm transition cannot proceed without a runner-level
   checkpoint pass.
4. Volcano recipe outcomes are durable in the experience store.
5. Targeted tests prove recipe metadata, checkpoint blocking, checkpoint pass,
   and outcome persistence.

## 4. Verification

- `ruff check payswitch/adapters/volcano.py payswitch/experience/registry.py tests/test_adapters.py`
- `.venv/bin/python -m pytest tests/test_adapters.py`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- recipe-backed migration for Jimeng or NineEmail;
- protocol-level payment routing changes;
- automatic promotion of Volcano recovery candidates into mainline behavior.

## 6. Implementation References

- [payswitch/adapters/volcano.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/volcano.py)
- [payswitch/experience/registry.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/registry.py)
- [tests/test_adapters.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_adapters.py)
