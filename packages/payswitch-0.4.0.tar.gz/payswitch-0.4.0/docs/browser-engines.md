# Browser Engines

Pay-Switch 支持两种浏览器 engine，通过 `payswitch config browser_engine <name>` 切换。

## 快速选择

| 你的场景 | Engine |
|---|---|
| 国内 LLM 平台（DeepSeek / Kimi / 通义千问）充值 | `playwright`（默认，无需额外依赖） |
| 海外支付页（OpenAI / Anthropic / Replicate / HuggingFace） | `cloakbrowser` |
| 目标站挂 Cloudflare Turnstile / reCAPTCHA v3 / FingerprintJS | `cloakbrowser` |
| CI / 单元测试 | `playwright`（CloakBrowser 需下载 ~200MB binary） |
| noVNC Docker 部署需要最小镜像 | `playwright` |
| 连接用户已打开的 Chrome (`chrome_cdp_url`) | 无关：engine 参数被忽略，直接复用用户浏览器 |

## 对比表

| 维度 | `playwright`（默认） | `cloakbrowser` |
|---|---|---|
| 指纹 patch 层级 | 启动参数 + JS 注入 | Chromium C++ 源码（49+ patches） |
| navigator.webdriver | 可隐藏 | false（源码级） |
| reCAPTCHA v3 分数 | 0.1–0.3 | 0.9（人类级） |
| Cloudflare Turnstile（非交互） | 常被拦 | 自动过 |
| Cloudflare Turnstile（managed） | 常被拦 | 单次点击过 |
| FingerprintJS bot 检测 | detected | normal |
| TLS ja3n | 跟 Chromium headless 一致（可识别） | 跟真实 Chrome 一致 |
| humanize（贝塞尔鼠标 / 真人键盘） | ❌ | ✅ `--humanize=True` |
| Binary 下载 | 走 `playwright install chromium` | 自动下载 ~200MB patched binary |
| 跟 Chrome 主线版本 | 随 Playwright 发布周期 | 基于 Chromium 146（持续 rebase） |
| 维护状态 | Microsoft 官方 | CloakHQ 活跃（2026-04+） |
| 协议 | Apache 2.0 | MIT |
| 下游 API | 原生 Playwright | Playwright 兼容（drop-in） |

## 切换方式

### 1. 通过 config（推荐）

```bash
pip install 'payswitch[cloak]'

# 默认启用 CloakBrowser 做所有 payswitch-managed profile 与 stateless 启动
payswitch config browser_engine cloakbrowser

# 打开人类行为模拟（贝塞尔鼠标曲线 + 真人键盘节奏）
payswitch config browser_humanize true

# 高额支付场景用 careful 预设，动作更慢更稳
payswitch config browser_human_preset careful
```

### 2. 代码层显式覆盖

```python
from pathlib import Path
from payswitch.browser.controller import BrowserController

ctrl = BrowserController()
await ctrl.launch(
    profile_dir=Path("~/.payswitch/profiles/anthropic"),
    engine="cloakbrowser",
    humanize=True,
    human_preset="careful",
)
```

`engine` 仅作用于 payswitch 自管的 `profile_dir` / stateless 两条路径。
CDP attach (`chrome_cdp_url`) 与真实 Chrome profile (`chrome_user_data_dir`) 两条路径
会忽略 `engine` 参数——它们是用户已打开的浏览器，不应被 payswitch 替换。

## 风险与边界（重要）

CloakBrowser 让反爬检测**看不出来**这是 bot，但它**不是**万能钥匙：

1. **不解决"交易风控"**。Stripe Radar / PayPal Seller Protection 等支付层风控基于
   卡号、地理位置、频率、金额曲线，跟浏览器指纹无关。CloakBrowser 帮不了你。
2. **不绕过 Human Gate**。2FA / OTP / CVV / 最终确认按钮仍必须交由人类操作。这
   是 payswitch 的硬性红线，不能因为"反爬过了"就跳过。
3. **TOS 灰区**。部分支付网关 TOS 禁止 automation/bot 访问。能过检测 ≠ 合规。使
   用前请确认目标站点 TOS 并保留 payswitch 现有的 Audit Log + Limit Guard。
4. **Binary 供应链**。CloakBrowser 首次启动会从官方 registry 下载 patched
   Chromium，SHA-256 校验。生产环境建议：
   - 在 pyproject 里 pin 精确版本（已默认 `cloakbrowser>=0.3.28,<0.4`）
   - Docker image 预装 binary，避免 cold launch 外网拉
   - 如有企业内网要求，mirror 到私有 registry
5. **Chrome 主线升级影响**。CloakBrowser 跟着 Chromium 主线 rebase 每次升级要做
   回归测试（DeepSeek/Kimi/Qwen adapter 的 selector 稳定性）。

## Humanize 的副作用

`humanize=True` 会给每次交互加额外延迟：

- 鼠标移动改走贝塞尔曲线（单次点击 +200~600ms）
- 键盘输入按字符间隔 30~120ms
- 滚动走模拟真人节奏（-> 多 500~1500ms）

对 throughput 敏感的 batch agent 建议只在高风控场景（Stripe/Anthropic 充值）打开。

## Docker 部署注意

如果在 `docker/docker-compose.yml` 里用 CloakBrowser：

```dockerfile
# 预装 cloakbrowser binary，避免 cold launch
RUN pip install 'payswitch[cloak]' && \
    python -c "from cloakbrowser import ensure_binary; ensure_binary()"

# 把 binary 缓存挂成 volume（跨容器共享，避免每次重建下载 200MB）
VOLUME /root/.cache/cloakbrowser
```

## 故障排查

**`ImportError: CloakBrowser 未安装`**
→ 执行 `pip install 'payswitch[cloak]'`

**首次 launch 卡在"下载 binary"**
→ 网络问题。手动下载：`python -c "from cloakbrowser import download; download()"`

**CI 环境报 binary 下载超时**
→ CI 请锁死 `engine=playwright`；CloakBrowser 不适合 CI 流水线。

**目标站仍然拦**
→ CloakBrowser 不保证 100% 通过所有反爬。先确认：
  1. `payswitch config browser_humanize true` 是否打开
  2. 是否用了 proxy（某些站点按 IP 归属地拦）
  3. 是否提升 `human_preset` 到 `careful`
  4. 是否需要切 persistent profile 让 Cookie / LocalStorage 累积

## 进一步阅读

- CloakBrowser 上游：https://github.com/CloakHQ/CloakBrowser
- 对比基准：CloakBrowser README 的 "Detection Service" 表格
