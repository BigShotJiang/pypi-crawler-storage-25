# Session Scope Propagation Parity Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed selected-session scope propagation module.

It closes one concrete drift in the runtime contract:

```text
session list already knew the current user scope
+ single-session snapshot reads now carry that scope
+ scoped confirm/download URLs now preserve that scope
+ scoped sessions fail closed before SSE opens on stale selection
```

## 1. Module Goal

The hosted WebUI already had a user-scoped session list and session-scoped
display takeover flow. But the single-session snapshot helper still dropped
`user_id`, and confirm/download artifact URLs did not always preserve the same
scope.

That meant the control plane could list one user's sessions correctly while the
selected-session detail path drifted back to an unscoped request shape.

This module makes the selected-session runtime path carry the same scope
information consistently.

## 2. Delivered Behavior

### 2.1 Frontend single-session reads now preserve `user_id`

`fetchSessionSnapshot(...)` now appends `user_id` when the runtime already
knows the active user scope.

The helper no longer drops scope on the transition from session list to
selected-session detail.

### 2.2 Scoped snapshot failures now fail closed before SSE attaches

`useCheckoutSession.connectLive()` now stops before opening `EventSource` when
the selected-session snapshot request fails.

That prevents the runtime panel from opening an SSE stream for a session whose
scoped snapshot lookup already failed.

### 2.3 Explicit user-scoped confirm/download links now stay scoped

For sessions that declare an explicit user owner in intent metadata, persisted
artifact download URLs now include `user_id`.

This applies across:

- session snapshot result artifacts,
- A2A evidence artifacts,
- session-confirm persisted outputs.

### 2.4 Explicit user-scoped confirm/download routes now enforce parity

For explicitly user-scoped sessions:

- `GET /api/sessions/{session_id}` requires matching `user_id`;
- `POST /api/sessions/{session_id}:confirm` requires matching `user_id`;
- `GET /api/sessions/{session_id}/artifacts/{artifact_id}` requires matching
  `user_id`.

Compatibility remains intact for legacy sessions that only inherit
`source_agent` as their user identity and do not declare an explicit
user-binding in metadata.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. The frontend snapshot helper appends `user_id` for selected-session reads.
2. A scoped snapshot failure does not open SSE anyway.
3. Explicitly scoped confirm/download artifact URLs include `user_id`.
4. Explicitly scoped session detail reads reject missing `user_id`.
5. Explicitly scoped confirm routes reject missing `user_id`.
6. Explicitly scoped artifact download routes reject missing `user_id`.
7. Legacy non-explicit sessions keep their existing unscoped compatibility.

## 4. Verification

Frontend:

- `npm test -- --run src/lib/sessionSnapshot.test.ts src/hooks/useCheckoutSession.test.tsx`
- `npm run build`

Backend:

- `.venv/bin/python -m ruff check payswitch/server.py tests/test_server_public_urls.py`
- `.venv/bin/python -m pytest tests/test_server_public_urls.py -q`

## 5. Non-Goals

This module does not yet deliver:

- removal of the server-side `/api/sessions/latest` endpoint;
- full route hardening for legacy sessions that only inherit `source_agent`;
- browser-process isolation or multi-container routing;
- display-route redesign beyond the existing scoped display ownership module.

## 6. Implementation References

- [frontend/src/lib/sessionSnapshot.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionSnapshot.ts)
- [frontend/src/hooks/useCheckoutSession.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/hooks/useCheckoutSession.ts)
- [frontend/src/lib/sessionSnapshot.test.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionSnapshot.test.ts)
- [frontend/src/hooks/useCheckoutSession.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/hooks/useCheckoutSession.test.tsx)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
