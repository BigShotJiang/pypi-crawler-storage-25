# Recovery Improvement Queue Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed control-plane slice for durable recovery
improvement artifacts.

It closes the next gap after bounded recovery and patch review artifacts:

```text
successful recovery artifact
+ durable queue record
+ operator triage
+ explicit accepted or dismissed state
```

## 1. Module Goal

Successful bounded recovery should not only write a JSON artifact to disk. It
should also create a durable queue record that operators can inspect and triage
through the same Pay-Switch control plane.

This module makes recovery output visible as a queue of improvement items with:

- stable IDs;
- durable status;
- artifact linkage;
- review metadata.

## 2. Delivered Behavior

### 2.1 Durable recovery improvement records

`ExperienceStore` now persists `recovery_improvements` records with:

- `patch_id`
- `tx_id`
- `platform`
- `flow`
- `status`
- `artifact_path`
- summary payload
- review metadata

### 2.2 Automatic registration from successful recovery

When `_record_successful_recovery_patch(...)` writes a recovery patch review
artifact, it now also registers or refreshes a recovery improvement entry.

The queue summary records:

- recovery outcome
- waypoint ID
- final URL
- watchdog classification
- recommended action

### 2.3 CLI triage surface

The CLI now exposes:

- `payswitch experience improvement list`
- `payswitch experience improvement show <id>`
- `payswitch experience improvement accept <id> --reviewer ...`
- `payswitch experience improvement dismiss <id> --reviewer ...`

### 2.4 Explicit queue lifecycle

Recovery improvement entries now move through:

```text
open -> accepted
open -> dismissed
```

This module does not automatically apply recipe changes. It creates the durable
queue and triage contract first.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Successful bounded recovery creates a durable queue entry, not only a JSON
   file on disk.
2. Operators can list and inspect queued recovery improvements from the CLI.
3. Operators can explicitly mark an improvement `accepted` or `dismissed`.
4. Improvement records keep artifact linkage and reviewer metadata.
5. Regression tests cover store, CLI, and orchestrator registration behavior.

## 4. Verification

- `ruff check payswitch/experience/models.py payswitch/experience/store.py payswitch/engine/orchestrator.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py tests/test_integration.py`

## 5. Non-Goals

This module does not yet deliver:

- automatic recipe rewriting from accepted improvements;
- watchdog-driven background improver execution loops;
- automatic promotion from improvement acceptance into `mainline`.

## 6. Implementation References

- [payswitch/experience/models.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/models.py)
- [payswitch/experience/store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/store.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_experience_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_store.py)
- [tests/test_cli_experience.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_experience.py)
- [tests/test_integration.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_integration.py)
