## Artifact Inbox Rotation Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed manual artifact-inbox rotation slice for
artifact security.

It closes the next hardening gap after cross-host handoff and QR/image parity:

```text
local artifact inbox key
+ dry-run rotation preview
+ guarded encrypted-artifact detection
+ manual re-encryption of existing local artifacts
+ inbox backup before key replacement
```

## 1. Module Goal

Pay-Switch already had local artifact encryption and cross-host handoff
re-encryption, but the local host itself had no governed way to rotate its own
artifact inbox key. That meant a long-lived host kept one inbox key forever
unless operators manually deleted the inbox and lost access to encrypted local
artifacts.

This module adds a bounded local rotation path with explicit operator intent.

## 2. Delivered Behavior

### 2.1 Rotation preview and guardrail

`ArtifactStore.rotate_local_inbox(...)` now reports:

- old and new `recipient_id`;
- whether encrypted artifacts exist locally;
- whether rotation is blocked without re-encryption;
- which encrypted artifacts would need re-encryption.

If encrypted artifacts exist, a real rotation fails closed unless the caller
explicitly enables `reencrypt_existing=True`.

### 2.2 Manual re-encryption of local sensitive artifacts

When `reencrypt_existing=True`, the store now:

- stages new encrypted payloads for existing local encrypted artifacts;
- preserves metadata and content type;
- records `recipient_id`, `rotated_at`, and `rotation_source_recipient_id`;
- swaps the local inbox key only after staged artifact replacement succeeds.

### 2.3 Inbox backup before replacement

Before replacing the live inbox file, the store now writes a backup copy of the
previous inbox JSON under the local `security/` directory. That gives operators
an explicit recovery anchor instead of relying on ad hoc filesystem history.

### 2.4 CLI entrypoint

`payswitch artifact rotate-inbox` now exposes this flow with:

- `--dry-run`
- `--reencrypt-existing`

so operators can preview first, then perform the bounded rotation deliberately.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Rotation preview reports encrypted-artifact blocking state without mutating
   the local inbox.
2. Manual rotation with `reencrypt_existing=True` changes the local
   `recipient_id`.
3. Existing encrypted local artifacts remain readable after rotation.
4. Rotation writes an inbox backup path for operator recovery.
5. The CLI can execute the same rotation path successfully.

## 4. Verification

- `ruff check payswitch/security/artifacts.py payswitch/cli.py tests/test_artifact_store.py tests/test_cli_artifact_handoff.py`
- `./.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_cli_artifact_handoff.py -q`

## 5. Non-Goals

This module does not yet deliver:

- automatic scheduled inbox rotation;
- remote multi-host key orchestration;
- policy-driven artifact rotation windows or staged approval workflow.

## 6. Implementation References

- [payswitch/security/artifacts.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/artifacts.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_artifact_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_artifact_store.py)
- [tests/test_cli_artifact_handoff.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_artifact_handoff.py)
