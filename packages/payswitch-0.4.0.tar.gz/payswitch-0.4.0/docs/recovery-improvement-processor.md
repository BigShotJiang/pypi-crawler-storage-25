# Recovery Improvement Processor Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed control-plane slice for processing accepted
recovery improvements into patch-review progress.

It closes the next gap after the recovery improvement queue baseline:

```text
accepted improvement
+ deterministic processor
+ patch review advancement
+ applied queue state
```

## 1. Module Goal

Accepted recovery improvements should advance the recipe-governance lifecycle
without requiring manual patch-by-patch metadata edits.

This module adds a safe processor that:

- consumes only `accepted` recovery improvements;
- advances the linked patch to `reviewed` when needed;
- records an `applied` terminal state for the improvement item;
- supports dry-run preview before mutation.

## 2. Delivered Behavior

### 2.1 Applied improvement lifecycle

Recovery improvements now support:

```text
open -> accepted -> applied
open -> dismissed
```

`applied` means the accepted improvement has already been consumed by the
processor and should not be reprocessed as pending queue work.

### 2.2 Store-level accepted-queue processor

`ExperienceStore.process_accepted_recovery_improvements(...)` now:

1. selects accepted queue items;
2. loads the linked patch;
3. moves non-reviewed patches to `reviewed`;
4. writes improvement linkage metadata onto the patch;
5. marks the improvement item as `applied`.

If the patch is already `reviewed` or `mainline`, the processor records that
result and still closes the improvement as `applied`.

### 2.3 CLI processing surface

The CLI now exposes:

- `payswitch experience improvement process`

Supported controls:

- `--reviewer`
- `--note`
- `--platform`
- `--flow`
- `--limit`
- `--dry-run`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Only `accepted` recovery improvements are processable.
2. A dry run previews patch-state advancement without mutating the store.
3. Processing an accepted improvement can move a linked patch into `reviewed`.
4. Processed improvements become `applied` and stop appearing as pending
   accepted work.
5. Regression tests cover store and CLI processing semantics.

## 4. Verification

- `ruff check payswitch/experience/models.py payswitch/experience/store.py payswitch/cli.py tests/test_experience_store.py tests/test_cli_experience.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_cli_experience.py`

## 5. Non-Goals

This module does not yet deliver:

- automatic watchdog-triggered background execution;
- runtime-triggered patch promotion into `mainline`;
- autonomous recipe rewriting without accepted-queue review.

## 6. Implementation References

- [payswitch/experience/models.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/models.py)
- [payswitch/experience/store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/store.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_experience_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_store.py)
- [tests/test_cli_experience.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_experience.py)
