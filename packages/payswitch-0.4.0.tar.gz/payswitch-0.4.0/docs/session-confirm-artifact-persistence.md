## Session Confirm Artifact Persistence Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed session-confirm artifact persistence slice
for artifact security.

It closes the next binary-artifact gap after QR persistence and image parity:

```text
encrypted screenshot and QR artifact baseline
+ session-confirm inline attachment persistence
+ authenticated artifact download route
+ A2A artifact metadata for persisted confirm outputs
+ redaction of local artifact paths from public task results
```

## 1. Module Goal

Pay-Switch already had encrypted screenshot and QR artifact storage, but
`/api/sessions/{session_id}:confirm` still accepted evidence and generated
outputs as inline JSON blobs only. That left three problems:

- binary receipts or generated files could stay embedded in task results;
- there was no authenticated download route for those attachments;
- A2A artifacts could not point to a durable persisted file contract.

This module moves confirm-time attachments into `ArtifactStore` and exposes a
stable server-side retrieval path.

## 2. Delivered Behavior

### 2.1 Confirm-time inline attachment contract

`SessionConfirmRequest.evidenceArtifacts` and `generatedOutputs` now support
inline payload persistence through these fields:

- `contentBase64` / `content_base64`
- `dataUrl` / `data_url`
- `text`
- `jsonPayload` / `json_payload`

Optional metadata is preserved where relevant:

- `artifactId`
- `name`
- `kind`
- `provider`
- `contentType`
- `sensitivity`
- `retentionHours`

### 2.2 Persisted artifact writes

When an inline payload is present, confirm processing now:

- writes the payload through `ArtifactStore.write_bytes(...)`;
- stores artifacts under `data_dir/evidence/session-confirm/{session_id}/`;
- records normalized metadata such as `artifact_id`, `content_type`,
  `size_bytes`, and `download_url`;
- strips inline payload fields so raw base64/text blobs do not remain embedded
  in task results.

### 2.3 Authenticated artifact download route

The server now serves persisted confirm artifacts from:

- `GET /api/sessions/{session_id}/artifacts/{artifact_id}`

The route:

- requires the agent token;
- resolves the task by session ID or linked transaction ID;
- verifies that the stored artifact path remains inside the configured
  `data_dir`;
- returns the decrypted artifact bytes with the stored or inferred content
  type.

### 2.4 A2A artifact projection

Evidence and generated-output artifacts exposed through `_as_a2a_task(...)`
now include:

- persisted `download_url` metadata;
- persisted `content_type` metadata;
- `persisted=true` when a durable artifact payload exists.

The task result redactor also hides local filesystem paths such as
`artifact_path`, `qr_artifact_path`, and `screenshot_path` from public A2A
result payloads.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Confirm-time inline binary or text attachments are persisted through
   `ArtifactStore`.
2. The confirm response no longer echoes the inline base64/text payload.
3. Persisted confirm artifacts can be downloaded from an authenticated session
   artifact route.
4. A2A artifact metadata exposes the persisted download URL and content type.
5. Public task results redact local artifact paths instead of leaking host
   filesystem locations.

## 4. Verification

- `ruff check payswitch/server.py tests/test_server_public_urls.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py tests/test_secret_envelope.py -q`

## 5. Non-Goals

This module does not yet deliver:

- unauthenticated public download URLs for persisted confirm artifacts;
- browser-stream or video artifact persistence;
- automatic cross-host replication of confirm attachments.

## 6. Implementation References

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
