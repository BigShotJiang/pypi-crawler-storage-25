# Recovery Patch Auto Shadow-Run Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed Milestone 6 slice for automatic
`shadow_run` promotion after a successful bounded Computer Use recovery.

It closes one concrete lifecycle gap in the recovery-patch pipeline:

```text
successful bounded recovery
+ durable patch update
+ automatic shadow_run success
+ manual mainline promotion still required
```

## 1. Module Goal

When a recovery-generated recipe patch candidate proves itself during the same
bounded Computer Use run that created or updated it, Pay-Switch should stop
leaving that patch in raw `candidate` state.

Instead, it should automatically mark the patch as:

- `shadow_run`
- `shadow_run_success=true`

while still keeping `mainline` promotion manual or separately governed.

## 2. Delivered Behavior

### 2.1 Successful bounded recovery now auto-marks `shadow_run`

When `_record_successful_recovery_patch(...)` runs after a valid recovery
outcome such as `scan_qr` or `completed`, Pay-Switch now:

1. updates the candidate recipe payload with the latest recovery evidence;
2. marks the patch as `shadow_run`;
3. records `shadow_run_success=true`.

### 2.2 Durable shadow-run metadata

The automatic shadow-run update now records durable metadata:

- `shadow_run_tx_id`
- `shadow_run_outcome`
- `shadow_run_waypoint_id`
- `shadow_run_source=bounded_computer_use_recovery`

This makes it clear which recovery execution validated the patch.

### 2.3 Mainline still does not auto-promote

This module does **not** automatically promote patches into `mainline`.

The safety boundary remains:

- successful recovery can auto-prove `shadow_run`;
- mainline promotion still requires the existing review/promotion contract.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. A successful bounded recovery no longer leaves its patch in raw
   `candidate` state.
2. The stored patch becomes `shadow_run` with `shadow_run_success=true`.
3. Shadow-run metadata records which transaction and outcome validated the
   patch.
4. The patch still does not auto-promote to `mainline`.
5. Regression tests cover both the orchestrator path and the store lifecycle
   constraints.

## 4. Verification

- `ruff check payswitch/engine/orchestrator.py tests/test_integration.py tests/test_experience_store.py`
- `.venv/bin/python -m pytest tests/test_integration.py tests/test_experience_store.py`

## 5. Non-Goals

This module does not yet deliver:

- automatic promotion into `mainline`;
- watchdog-driven retry/replay loops that re-run a candidate against future
  traffic;
- risk-weighted promotion policies beyond the current successful-recovery
  signal.

## 6. Implementation References

- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [tests/test_integration.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_integration.py)
- [tests/test_experience_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_store.py)
