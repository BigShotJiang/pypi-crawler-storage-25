# Jimeng Recipe-Backed Migration

Date: 2026-05-16
Status: implemented in current branch

This document records the Jimeng fast-path migration slice for Milestone 6.

## 1. Goal

Jimeng already had a fail-closed final payment checkpoint, but the purchase path
still executed as a purely imperative sequence.

This slice moves Jimeng onto the shared `RecipeRunner` contract so it can share
semantic waypoint telemetry, runner-level synchronous checkpointing, and durable
recipe outcomes with the other migrated fast-path adapters.

## 2. Delivered Behavior

### 2.1 Jimeng now runs through `RecipeRunner`

`JimengAdapter.execute_topup()` now executes through the shared recipe runner.

The built-in Jimeng recipe now defines waypoints for:

- homepage navigation
- login verification
- checkout entry
- amount/package selection
- payment-method readiness
- confirm-to-checkout transition
- QR/payment-gate wait state

### 2.2 Runner-level checkpoint is now present on Jimeng confirm

The `confirm_topup_checkout` waypoint is now marked with
`synchronous_policy_checkpoint=true`.

Before Jimeng enters the final pay transition, the runner-level checkpoint now
re-validates login state and requires visible payment markers such as:

- `支付宝`
- `微信`
- `购买积分`
- `同意并支付`
- `去支付`
- `确认订单`

The older adapter-level fail-closed confirm guard remains in place, so the path
is protected at both the runner layer and the direct click helper.

### 2.3 Durable recipe outcomes

Jimeng now records recipe success/failure outcomes into the experience store
with recipe id/version metadata.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Jimeng top-up runs through the shared recipe runner.
2. Jimeng exposes a built-in recipe with explicit checkout-entry, confirm, and
   payment-gate waypoints.
3. The Jimeng confirm transition cannot proceed without a runner-level
   checkpoint pass.
4. Jimeng recipe outcomes are durable in the experience store.
5. Targeted tests prove recipe metadata, checkpoint blocking, checkpoint pass,
   and outcome persistence.

## 4. Verification

- `ruff check payswitch/adapters/jimeng.py payswitch/experience/registry.py tests/test_adapters.py`
- `.venv/bin/python -m pytest tests/test_adapters.py`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- recipe-backed migration for NineEmail;
- protocol-level payment routing changes;
- automatic promotion of Jimeng recovery candidates into mainline behavior.

## 6. Implementation References

- [payswitch/adapters/jimeng.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/adapters/jimeng.py)
- [payswitch/experience/registry.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/registry.py)
- [tests/test_adapters.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_adapters.py)
