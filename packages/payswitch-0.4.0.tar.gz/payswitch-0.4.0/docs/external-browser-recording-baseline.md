## External Browser Recording Baseline Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed external-browser recording slice for the
artifact-security milestone.

It closes the next runtime media-production gap after confirm-time media
artifact persistence:

```text
persisted media artifact contracts
+ runtime browser video recording for Pay-Switch-owned external sessions
+ encrypted recording persistence on terminal close
+ runtime-event projection for persisted recording metadata
```

## 1. Module Goal

Pay-Switch could already accept and store media artifacts that were produced
outside the runtime, such as confirm-time `mediaArtifacts`. But the external
Computer Use path still did not produce any real browser media artifact by
itself.

That left one architecture gap:

- no runtime-produced browser recording artifact for external checkout runs;
- no encrypted persistence for those recordings;
- no event-level proof that a terminal browser lifecycle actually flushed and
  stored the recording.

## 2. Delivered Behavior

### 2.1 Browser launch recording contract

`BrowserEngine`, `PlaywrightEngine`, `CloakBrowserEngine`, and
`BrowserController` now accept an optional `record_video_dir`.

For Pay-Switch-owned Playwright contexts, that directory enables context-level
video recording. For CDP-attached user Chrome sessions, the controller keeps
the behavior explicit and does not pretend recording is available.

### 2.2 External runner raw recording lifecycle

`ExternalCheckoutRunner` now allocates a raw recording directory for each
transaction browser lifecycle under:

- `data_dir/evidence/external-recordings-raw/{tx_id}/`

When a visible or headless external browser is relaunched or reaches a terminal
transaction state, the runner closes the browser and inspects finalized video
files from that raw directory.

### 2.3 Encrypted persisted recording artifacts

Finalized recordings are now persisted through `ArtifactStore.write_bytes(...)`
as:

- `artifact_kind="external_browser_recording"`
- `ArtifactSensitivity.sensitive`
- MIME-aware `video/webm` or `video/mp4`

Persisted recordings are stored under:

- `data_dir/evidence/external-media/{tx_id}/`

The raw recording files are deleted after persistence so the durable copy is
the encrypted artifact-store payload.

### 2.4 Runtime event projection

When terminal browser close persists one or more recordings, the external
runner now emits a `media.persisted` runtime event that includes:

- `artifact_path`
- `content_type`
- `name`
- `kind`

This gives the control plane a durable proof trail even before WebUI playback
or session download projection is added.

### 2.5 Terminal-state close correctness

The external runner now updates `tx` before early terminal returns in
`run(...)`. That ensures `finally` sees the terminal transaction state and
actually closes the browser, which is required for Playwright to flush the
recorded video file.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Pay-Switch-owned external browser launches can accept a recording directory.
2. Terminal external browser lifecycles persist finalized video files through
   `ArtifactStore`.
3. Persisted recordings are encrypted-at-rest and typed with the correct video
   MIME.
4. Raw recording files are cleaned up after persistence.
5. A terminal external run emits a `media.persisted` runtime event for the
   stored recording metadata.

## 4. Verification

- `ruff check payswitch/browser/controller.py payswitch/browser/engines/__init__.py payswitch/browser/engines/playwright_engine.py payswitch/browser/engines/cloakbrowser_engine.py payswitch/engine/external_runner.py tests/test_browser_engines.py tests/test_browser_controller_config_readback.py tests/test_external_runner.py`
- `./.venv/bin/python -m pytest tests/test_browser_engines.py tests/test_browser_controller_config_readback.py tests/test_external_runner.py -q`
- `./.venv/bin/python -m pytest tests/test_browser_controller.py -q`

## 5. Non-Goals

This module does not yet deliver:

- session-scoped authenticated download URLs for external runner recordings;
- WebUI recording playback;
- video recording for CDP-attached user Chrome sessions.

The first two follow-on gaps are closed by
[`docs/external-browser-recording-playback.md`](docs/external-browser-recording-playback.md).

## 6. Implementation References

- [payswitch/browser/engines/__init__.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/engines/__init__.py)
- [payswitch/browser/engines/playwright_engine.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/engines/playwright_engine.py)
- [payswitch/browser/engines/cloakbrowser_engine.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/engines/cloakbrowser_engine.py)
- [payswitch/browser/controller.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/browser/controller.py)
- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [tests/test_browser_engines.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_browser_engines.py)
- [tests/test_browser_controller.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_browser_controller.py)
- [tests/test_browser_controller_config_readback.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_browser_controller_config_readback.py)
- [tests/test_external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_external_runner.py)
