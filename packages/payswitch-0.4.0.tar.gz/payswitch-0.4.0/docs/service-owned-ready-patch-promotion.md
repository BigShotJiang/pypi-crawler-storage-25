# Service-Owned Ready Patch Promotion Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed service-owned promotion slice for ready
recovery recipe patches.

It closes the next gap after governed open-improvement acceptance:

```text
governed open improvement acceptance
+ ready-patch promotion runner
+ service-owned promotion supervisor
+ CLI loop and health-visible promoter state
```

## 1. Module Goal

Once improvement governance has already produced eligible ready patches,
promotion into `mainline` should be processable through the same bounded
service-owned control surface as the accepted-improvement queue.

This module adds a governed promotion path that:

- promotes only already-ready patches;
- preserves basis filtering and dry-run behavior;
- can run through CLI loops or service-owned supervision;
- exposes promotion supervisor state through health APIs.

## 2. Delivered Behavior

### 2.1 Ready patch promotion runner

`ReadyPatchPromotionRunner` now provides:

- `run_once(...)`
- `run_loop(...)`

The runner operates on top of `ExperienceStore.promote_ready_patches(...)` and
keeps the existing readiness contract intact.

### 2.2 CLI loop surface

The CLI now exposes:

- `payswitch experience patch run-promoter`

Supported controls:

- `--actor`
- `--note`
- `--platform`
- `--flow`
- `--source`
- `--basis`
- `--batch-limit`
- `--poll-interval-seconds`
- `--max-idle-polls`
- `--max-cycles`
- `--dry-run`
- `--once`

### 2.3 Service-owned promoter supervision

`ReadyPatchPromotionSupervisor` now provides a service-owned promotion loop
with:

- env-configured actor identity;
- optional basis, platform, flow, and source filters;
- bounded batch size and polling interval;
- health-visible cycle and promotion counters.

### 2.4 Server health projection

The server now exposes promoter state through:

- `GET /api/recovery-patch-promoter/health`
- `GET /api/health` under `recovery_patch_promoter`

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Ready patch promotion can run through a reusable bounded runner.
2. Operators can invoke the promoter from the CLI in one-cycle or loop mode.
3. The server can own a ready-patch promotion loop through lifespan startup and shutdown.
4. Promoter state is visible through server health APIs.
5. Regression tests cover runner execution, supervisor execution, CLI invocation, and health projection.

## 4. Verification

- `ruff check payswitch/experience/__init__.py payswitch/experience/promoter.py payswitch/server.py payswitch/cli.py tests/test_experience_promoter.py tests/test_server_recovery_patch_promoter.py tests/test_cli_experience.py`
- `.venv/bin/python -m pytest tests/test_experience_promoter.py tests/test_server_recovery_patch_promoter.py tests/test_cli_experience.py tests/test_server_public_urls.py`

## 5. Non-Goals

This module does not yet deliver:

- cross-host promoter coordination;
- protocol-level approval workflows outside the current experience store.

## 6. Implementation References

- [payswitch/experience/promoter.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/promoter.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_experience_promoter.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_promoter.py)
- [tests/test_server_recovery_patch_promoter.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_recovery_patch_promoter.py)
- [tests/test_cli_experience.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_experience.py)
