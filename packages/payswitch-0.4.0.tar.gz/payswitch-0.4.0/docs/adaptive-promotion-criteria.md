# Adaptive Promotion Criteria Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed adaptive-governance slice for recovery
patch promotion and open-improvement acceptance.

It closes the next gap after service-owned promotion and governed acceptance:

```text
service-owned ready patch promotion
+ governed open improvement acceptance
+ configurable minimum shadow-run threshold
+ store, CLI, and supervisor enforcement
```

## 1. Module Goal

Promotion and auto-accept behavior should not assume that one successful shadow
run is always enough.

This module adds a configurable minimum shadow-run threshold that can be
enforced consistently across:

- patch queue readiness;
- ready-patch batch promotion;
- service-owned ready-patch promotion;
- governed open-improvement acceptance;
- service-owned improver auto-accept.

## 2. Delivered Behavior

### 2.1 Store-level readiness now tracks shadow-run count

`ExperienceStore` now stores `shadow_run_count` per patch and backfills older
rows from the previous boolean-only `shadow_run_success` state.

Promotion readiness now supports:

- `reviewed` -> ready immediately;
- `shadow_run_count >= min_shadow_runs` -> ready through `shadow_run_success`;
- `shadow_run_success=true` but insufficient count -> blocked with
  `needs_more_shadow_runs:{count}/{min_shadow_runs}`.

### 2.2 CLI surfaces expose threshold control

The CLI now supports `--min-shadow-runs` on:

- `payswitch experience patch queue`
- `payswitch experience patch promote-ready`
- `payswitch experience patch run-promoter`
- `payswitch experience improvement accept-open`

Queue output now also includes the stored shadow-run count, so operators can
see both readiness basis and remaining threshold gap.

### 2.3 Service-owned loops honor the same threshold

The ready-patch promoter and recovery improver supervisors now accept
environment-configured minimum shadow-run thresholds:

- `PAYSWITCH_READY_PATCH_PROMOTER_MIN_SHADOW_RUNS`
- `PAYSWITCH_RECOVERY_IMPROVER_MIN_SHADOW_RUNS`

Their health payloads now expose the active threshold through
`min_shadow_runs`.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Patch readiness can require more than one shadow run.
2. Blocked queue entries return explicit
   `needs_more_shadow_runs:{count}/{min_shadow_runs}` reasons.
3. CLI commands can preview and execute with an explicit minimum threshold.
4. Ready-patch promotion and open-improvement auto-accept use the same threshold semantics.
5. Regression tests cover store, CLI, promoter, improver, and server-env health projection.

## 4. Verification

- `ruff check payswitch/experience/store.py payswitch/experience/promoter.py payswitch/experience/improver.py payswitch/server.py payswitch/cli.py tests/test_experience_store.py tests/test_experience_promoter.py tests/test_experience_improver.py tests/test_cli_experience.py tests/test_server_recovery_patch_promoter.py tests/test_server_recovery_improver.py`
- `.venv/bin/python -m pytest tests/test_experience_store.py tests/test_experience_promoter.py tests/test_experience_improver.py tests/test_cli_experience.py tests/test_server_recovery_patch_promoter.py tests/test_server_recovery_improver.py -q`

## 5. Non-Goals

This module does not yet deliver:

- cross-host promotion coordination;
- risk-scored or model-authored promotion policy changes;
- automatic protocol-level promotion outside the current experience store.

## 6. Implementation References

- [payswitch/experience/store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/store.py)
- [payswitch/experience/promoter.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/promoter.py)
- [payswitch/experience/improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/improver.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_experience_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_store.py)
- [tests/test_experience_promoter.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_promoter.py)
- [tests/test_experience_improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_improver.py)
- [tests/test_cli_experience.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_cli_experience.py)
- [tests/test_server_recovery_patch_promoter.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_recovery_patch_promoter.py)
- [tests/test_server_recovery_improver.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_recovery_improver.py)
