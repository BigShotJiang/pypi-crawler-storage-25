## QR Artifact Persistence Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed QR artifact persistence slice for the
artifact-security milestone.

It closes the next gap after screenshot encryption:

```text
encrypted screenshot evidence
+ encrypted QR payload persistence from human-gate detections
+ session/UI projection for QR artifact previews
+ compatibility reads through the existing evidence endpoint
```

## 1. Module Goal

Pay-Switch could already encrypt screenshot evidence, but QR detections still
carried inline `data:` payloads inside human-gate event details. That left QR
handoff artifacts outside the artifact contract:

- no retention metadata for QR payloads;
- no encrypted-at-rest storage for QR crops emitted by detectors;
- no stable artifact URL for the WebUI to render before noVNC takeover is
  ready.

This module moves QR payloads into `ArtifactStore` and projects them back out as
session-visible evidence URLs.

## 2. Delivered Behavior

### 2.1 Data-URL QR payload decoding

`payswitch.security.artifacts.decode_data_url_payload(...)` now decodes
`data:` payloads emitted by QR detectors, including:

- base64-encoded image payloads;
- URL-encoded image payloads;
- MIME-aware content-type extraction for downstream artifact writes.

### 2.2 Encrypted QR artifact persistence

External Computer Use human-gate handoff now persists QR payloads through
`ArtifactStore.write_bytes(...)` when detector output includes an inline
`qr_src` data URL.

Persisted QR artifacts now:

- use `artifact_kind="payment_qr_payload"`;
- are marked `ArtifactSensitivity.sensitive`;
- keep detector metadata such as `tx_id`, `detector_name`, `action_type`, and
  `qr_type`.

### 2.3 Human-gate session projection

The external runner now enriches human-gate details with `qr_artifact_path`,
and the settings/session event adapters project:

- `qr_artifact_path`
- `qr_artifact_url`

into replay and live-stream payloads for the selected session.

### 2.4 WebUI QR-first preview

`BrowserPreview` now prefers the persisted QR artifact image before falling back
to a screenshot when:

- a QR human gate is active; and
- the session does not yet have a ready visible takeover surface.

This gives operators a deterministic QR preview in WebUI without waiting for
the visible browser route.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. QR detector `data:` payloads can be decoded into bytes plus MIME type.
2. QR handoff payloads are persisted through `ArtifactStore` instead of staying
   inline-only in event details.
3. Session replay and live stream payloads expose `qr_artifact_url` for the
   selected session.
4. The WebUI shows the QR artifact preview during a QR human gate before
   display takeover becomes ready.

## 4. Verification

- `ruff check payswitch/security/artifacts.py payswitch/engine/external_runner.py payswitch/cli.py tests/test_external_runner.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx`
- `npm run build`

## 5. Non-Goals

This module does not yet deliver:

- browser-stream or video artifact encryption;
- automatic artifact-key rotation;
- non-image binary artifact coverage beyond the current QR and screenshot image
  baseline.

## 6. Implementation References

- [payswitch/security/artifacts.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/artifacts.py)
- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/sessionModel.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionModel.ts)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [tests/test_external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_external_runner.py)
- [tests/test_ui_settings_api.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_ui_settings_api.py)
- [frontend/src/lib/eventStream.test.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.test.ts)
- [frontend/src/components/BrowserPreview.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.test.tsx)
