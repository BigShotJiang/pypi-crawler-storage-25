## Browser Recording Index Metadata Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed recording-index metadata slice for
persisted browser recording artifacts.

It closes the next multi-recording operator gap this way:

```text
browser recording artifacts already expose source, size, duration, fps, resolution, codec, bit rate, and format
+ runtime media events now emit recording_index
+ server and local settings/events preserve recording_index and recordingIndex
+ WebUI labels persisted browser media actions with #<index> ordering markers
```

## 1. Module Goal

Persisted browser recordings already told operators what kind of media artifact
they were opening. But they still could not tell the intended order of multiple
recordings in the same session without opening raw payloads or inferring from
filenames.

This module surfaces explicit recording-order metadata end to end without
changing recording persistence, download routes, or capture behavior.

## 2. Delivered Behavior

### 2.1 Runtime recording-index emission

When `ExternalCheckoutRunner` persists a browser recording or screenshot replay,
it now emits:

- `recording_index`
- `recordingIndex`

The value matches the same persisted recording-order metadata already carried in
artifact metadata, so the event payload and stored contract stay aligned.

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve both:

- `recording_index`
- `recordingIndex`

This keeps recording-order metadata aligned with the alias policy already used
for source, size, duration, fps, resolution, codec, bit rate, and replay
provenance fields.

### 2.3 WebUI recording-order labels

The frontend runtime model now preserves `recordingIndex`.

Persisted media actions surface order labels such as:

- `#2`

These labels appear in both:

- `BrowserPreview`;
- `LiveTimeline`.

The order label is additive. It does not remove any existing source, replay,
size, duration, resolution, codec, format, or engine label.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Runtime `media.persisted` payloads expose both `recording_index` and
   `recordingIndex`.
2. Public session projection preserves both recording-index aliases.
3. Local settings/events projection preserves the same aliases.
4. BrowserPreview renders the `#<index>` label when a recording index exists.
5. LiveTimeline renders the same `#<index>` label for persisted media events.
6. Existing media label ordering stays intact apart from the additive index
   marker.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- deduplication or grouping of multiple recordings for the same session;
- browser-tab identity or page-title labels on media actions;
- native live capture for attached CDP user Chrome sessions.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/sessionModel.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionModel.ts)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
