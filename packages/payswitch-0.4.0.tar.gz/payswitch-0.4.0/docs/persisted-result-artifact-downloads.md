## Persisted Result Artifact Downloads Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed persisted-result artifact projection slice
for server/A2A artifact delivery.

It closes the next gap after session-confirm attachment persistence:

```text
persisted confirm attachments
+ auto-projected download metadata for any result artifact with artifact_path
+ MIME inference for legacy persisted artifacts
+ public-result cleanup for persisted evidence/media/generated outputs
```

## 1. Module Goal

Pay-Switch could now persist confirm-time attachments and serve them through an
authenticated artifact route, but older or non-confirm result items still had a
gap:

- a persisted `artifact_path` inside `evidence_artifacts`, `generated_outputs`,
  or `media_artifacts` did not automatically surface a `download_url`;
- legacy persisted items without an explicit `content_type` could not project a
  stable MIME contract through A2A metadata;
- the public task result path could still diverge from the artifact metadata
  shape for persisted result artifacts.

This module makes persisted artifact projection consistent for all result
artifact collections, not only newly normalized confirm attachments.

## 2. Delivered Behavior

### 2.1 Automatic persisted-artifact metadata projection

Any result item under:

- `evidence_artifacts`
- `generated_outputs`
- `media_artifacts`

now gains synthesized public metadata when it already has:

- `artifact_id` / `artifactId`
- `artifact_path` / `artifactPath`

The server derives:

- `download_url`
- `content_type`
- `persisted`

without requiring the producer to pre-populate those fields.

### 2.2 Legacy MIME inference

If a persisted result artifact does not already carry `content_type`, the
server now tries:

1. artifact-sidecar metadata via `ArtifactStore.read_content_type(...)`;
2. MIME inference from the artifact filename.

This keeps older persisted artifacts compatible with the new download metadata
contract.

### 2.3 Public task-result alignment

`pay_switch_result` now projects the same persisted artifact metadata that A2A
artifact entries expose, while continuing to omit local host paths from the
public payload.

That means persisted result artifacts now have one public shape across:

- the top-level A2A artifact entry; and
- the redacted `pay_switch_result` payload.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. A persisted result artifact with only `artifact_path` and `artifactId`
   automatically gets a public `download_url`.
2. The server infers `content_type` for persisted artifacts from sidecar
   metadata or filename when needed.
3. `pay_switch_result` uses the same download metadata shape as the top-level
   A2A artifact entry.
4. Public A2A payloads continue to hide local `artifact_path` values.

## 4. Verification

- `ruff check payswitch/server.py tests/test_server_public_urls.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py -q`

## 5. Non-Goals

This module does not yet deliver:

- a producer for browser-stream or video capture artifacts;
- unauthenticated artifact download URLs;
- artifact replication across hosts.

## 6. Implementation References

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
