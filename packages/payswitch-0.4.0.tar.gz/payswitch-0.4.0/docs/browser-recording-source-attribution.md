## Browser Recording Source Attribution Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed frontend attribution slice for persisted
browser recording sources.

It closes the next operator gap left by the screenshot-replay fallback:

```text
persisted browser media is downloadable
+ screenshot replay and native recording share the same media.persisted contract
+ WebUI now tells the operator which recording type they are opening
```

## 1. Module Goal

The artifact pipeline already persisted browser media with
`recording_source=native_browser_video` or
`recording_source=observation_screenshots`.

But the frontend still treated every stored video the same way. That meant the
operator could open a replay artifact while assuming it was a native browser
recording.

This module makes that distinction explicit in the WebUI without changing the
existing artifact-delivery contract.

## 2. Delivered Behavior

### 2.1 Session model and event normalization

The frontend session model now preserves `recordingSource` on
`SessionMediaArtifact`.

The event-stream parser normalizes both:

- `recordingSource`
- `recording_source`

into the same runtime field.

### 2.2 BrowserPreview action labeling

`BrowserPreview` now distinguishes the latest persisted browser video this way:

- native browser video -> `打开录屏`
- screenshot replay -> `打开回放`

This keeps the quick action aligned with the actual evidence provenance while
preserving the existing preview ordering.

### 2.3 Timeline artifact labeling

`LiveTimeline` now appends a source hint to persisted media actions when
available:

- `· 浏览器录屏`
- `· 截图回放`

This keeps the attribution next to the exact `media.persisted` event that
introduced the artifact.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `recording_source` survives SSE normalization into the frontend session
   model.
2. `BrowserPreview` renders screenshot-replay actions as `打开回放` instead of
   `打开录屏`.
3. `LiveTimeline` renders replay/native attribution in the media artifact
   action label when the source is known.
4. Existing persisted-media playback still works when `recordingSource` is
   absent.
5. Frontend tests cover normalization and the source-aware rendering cases.

## 4. Verification

- `npm test -- --run src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx src/lib/eventStream.test.ts src/lib/sessionModel.test.ts src/lib/sessionSnapshot.test.ts`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- native live screencast capture for attached CDP sessions;
- timeline-inline playback mode changes;
- richer recording metadata such as duration, fps, or capture engine badges.

## 6. Implementation References

- [frontend/src/lib/sessionModel.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionModel.ts)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/lib/eventStream.test.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.test.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/BrowserPreview.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.test.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
- [frontend/src/components/LiveTimeline.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.test.tsx)
- [docs/screenshot-replay-browser-recordings.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/screenshot-replay-browser-recordings.md)
