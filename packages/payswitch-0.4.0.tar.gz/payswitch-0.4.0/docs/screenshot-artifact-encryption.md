# Screenshot Artifact Encryption Module

Date: 2026-05-16
Status: implemented in current branch

This document defines the completed Milestone 7 screenshot/binary artifact
baseline for runtime evidence capture.

It closes the next gap after JSON artifact encryption and retention cleanup:

```text
sensitive JSON artifacts
+ sensitive screenshot artifact envelopes
+ recipe failure screenshot coverage
+ evidence-read compatibility
+ retention metadata for PNG evidence
```

## 1. Module Goal

Pay-Switch already encrypted sensitive JSON artifacts and enforced metadata-based
cleanup, but screenshot evidence still landed as raw PNG files on disk. Those
screenshots can contain QR codes, account state, checkout context, and recovery
breadcrumbs, so leaving them outside `ArtifactStore` broke the security and
retention contract.

This module extends the artifact contract to screenshot evidence so the system
can:

- store PNG evidence through `ArtifactStore`;
- encrypt sensitive screenshot payloads at rest;
- preserve the same screenshot paths in transaction and recipe telemetry;
- keep local evidence serving compatible by decrypting on read.

## 2. Delivered Behavior

### 2.1 Binary artifact storage support

`ArtifactStore` now provides:

- `write_bytes(...)` for metadata-backed binary artifacts;
- `read_bytes(...)` for plaintext or encrypted artifact payloads;
- `read_content_type(...)` so evidence readers can serve decrypted files with
  the correct MIME type.

### 2.2 External Computer Use screenshot protection

External observation screenshots now write through `ArtifactStore` as
`sensitive` PNG artifacts:

- the stored path remains `...step-N.png`;
- the file content is encrypted at rest;
- retention metadata is written beside the screenshot.

### 2.3 Recovery screenshot protection

Recovery checkpoint screenshots now write through `ArtifactStore` as
`sensitive` PNG artifacts, so script-recovery evidence follows the same storage
contract as the JSON checkpoint record.

### 2.4 Recipe failure screenshot protection

Recipe-runner failure screenshots now support `ArtifactStore` injection from the
orchestrator. Kimi, DeepSeek, Qwen, Volcano, Jimeng, and NineEmail recipe paths
now persist failure screenshots as `sensitive` PNG artifacts with recipe and
waypoint metadata.

### 2.5 Evidence-read compatibility

The local settings/events evidence endpoint now reads artifact bytes through
`ArtifactStore`, so encrypted screenshot payloads still render through the same
`/evidence?path=...` URL shape.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `ArtifactStore` can round-trip sensitive PNG payloads.
2. External observation screenshots are no longer persisted as raw PNG bytes.
3. Recovery screenshots are persisted through `ArtifactStore`.
4. Recipe failure screenshots can be read back through `ArtifactStore`.
5. The evidence-read helper can return decrypted bytes plus MIME type for an
   encrypted screenshot path.

## 4. Verification

- `ruff check payswitch/security/artifacts.py payswitch/cli.py payswitch/engine/external_runner.py payswitch/engine/orchestrator.py payswitch/experience/runner.py payswitch/adapters/base.py payswitch/adapters/kimi.py payswitch/adapters/deepseek.py payswitch/adapters/qwen.py payswitch/adapters/volcano.py payswitch/adapters/jimeng.py payswitch/adapters/nineemail.py tests/test_artifact_store.py tests/test_external_runner.py tests/test_experience_runner.py tests/test_ui_settings_api.py`
- `.venv/bin/python -m pytest tests/test_artifact_store.py tests/test_external_runner.py tests/test_experience_runner.py tests/test_ui_settings_api.py -q`

## 5. Non-Goals

This module does not yet deliver:

- browser-detected QR artifact persistence beyond the current screenshot PNG
  path;
- automatic artifact-key rotation;
- browser-stream/video artifact encryption;
- storage-budget enforcement beyond local retention cleanup.

## 6. Implementation References

- [payswitch/security/artifacts.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/security/artifacts.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/engine/orchestrator.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/orchestrator.py)
- [payswitch/experience/runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/experience/runner.py)
- [tests/test_artifact_store.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_artifact_store.py)
- [tests/test_external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_external_runner.py)
- [tests/test_experience_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_experience_runner.py)
- [tests/test_ui_settings_api.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_ui_settings_api.py)
