# User-Bound Control Plane Read Scope Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed read-scope guard for user-bound control
plane endpoints.

It closes one multi-user ambiguity gap:

```text
sessions already had user-scoped read rules
+ workspaces, subagents, and workspace-runtime health now reject ambiguous multi-user reads
+ explicit user-scoped reads still work
+ single-user compatibility remains unchanged
```

## 1. Module Goal

The control plane had already learned to scope session reads. But adjacent
user-bound endpoints still allowed an unscoped multi-user read:

- `GET /api/workspaces`
- `GET /api/subagents`
- `GET /api/workspace-runtimes/health`

That left one inconsistent read surface where a multi-user host could expose
cross-user workspace/runtime summaries without an explicit `user_id`.

This module brings those user-bound read routes onto the same ambiguity guard
contract as the session list.

## 2. Delivered Behavior

### 2.1 Ambiguous multi-user reads now fail closed

When these endpoints see more than one user owner and no `user_id`, they now
return `409`:

- `GET /api/workspaces`
- `GET /api/subagents`
- `GET /api/workspace-runtimes/health`

### 2.2 Explicit user-scoped reads still work

Callers can still read these routes with:

- `?user_id=alice`
- `?user_id=bob`

and receive only that user's records.

### 2.3 Single-user compatibility remains intact

If the underlying records only belong to one user, the current compatibility
behavior stays unchanged.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Unscoped multi-user reads on `/api/workspaces` return `409`.
2. Unscoped multi-user reads on `/api/subagents` return `409`.
3. Unscoped multi-user reads on `/api/workspace-runtimes/health` return `409`.
4. User-scoped reads on those same routes still return only that user's data.
5. Server route tests pass after the contract change.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/server.py tests/test_server_public_urls.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py -q`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- a stricter always-require-`user_id` rule for single-user deployments;
- changes to session-list read inference behavior;
- changes to the local developer helper server.

## 6. Implementation References

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
