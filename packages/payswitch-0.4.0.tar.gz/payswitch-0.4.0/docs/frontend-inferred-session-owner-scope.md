## Frontend Inferred Session Owner Scope Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed frontend inferred-owner scope module.

It closes one concrete hosted-WebUI gap:

```text
session list can already reveal explicit user ownership
+ hosted WebUI can now infer that single owner
+ selected-session detail and SSE hydration now reuse that owner scope
+ delete/clear/select flows now keep the same scope even when the page URL did not start with user_id
```

## 1. Module Goal

The hosted WebUI already supported explicit `?user_id=...` routing. But if the
operator opened the page without `user_id`, the frontend could still land on a
session list whose items all belonged to one explicit owner.

At that point the control plane already knew enough to stay inside one scope,
but the frontend kept treating itself as unscoped. That made selected-session
detail, delete, clear, and display-select flows drift away from the scope that
the session list had already exposed.

This module lets the frontend infer that single owner and keep the whole
selected-session path inside the same scope.

## 2. Delivered Behavior

### 2.1 Session list now resolves a single explicit owner

`useSessionList(...)` now computes `resolvedUserId`.

If the caller already passed `userId`, that remains the source of truth. If not
and every visible session belongs to the same non-empty owner, the hook infers
that owner from the session list itself.

### 2.2 Refresh/delete/clear now reuse inferred scope

Once the frontend resolves one owner, subsequent session-list refreshes reuse
that `user_id`.

The same inferred scope now also applies to:

- session delete;
- clear-all sessions.

### 2.3 Selected-session flows now stay in the inferred scope

`App` now passes the resolved owner scope through:

- selected-session snapshot hydration;
- SSE attach through `useCheckoutSession(...)`;
- display-select writes.

If the hosted page did not start with `user_id`, but the session list resolves
one explicit owner, the frontend now writes that `user_id` back into the URL so
the page state remains shareable and stable.

### 2.4 Auto-select now waits only when scope is still ambiguous

The hosted WebUI no longer blocks auto-select merely because the initial URL
lacked `user_id`.

It now blocks only when multiple sessions exist and owner scope is still
ambiguous.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `useSessionList(...)` exposes `resolvedUserId`.
2. A single explicit session owner is inferred when no `user_id` was supplied.
3. Session refresh/delete/clear reuse that inferred scope.
4. Selected-session snapshot and SSE hydration reuse that inferred scope.
5. Display selection reuses that inferred scope.
6. The hosted page URL is updated with `user_id` once a single owner is
   resolved.
7. Auto-select still refuses to guess when more than one owner remains visible.

## 4. Verification

- `npm test -- --run src/hooks/useSessionList.test.ts src/App.test.tsx src/lib/sessionSnapshot.test.ts src/hooks/useCheckoutSession.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- server-side inference of owner scope for ambiguous session lists;
- multi-owner URL switching heuristics;
- broader runtime isolation changes beyond the existing session-scope modules.

## 6. Implementation References

- [frontend/src/hooks/useSessionList.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/hooks/useSessionList.ts)
- [frontend/src/App.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/App.tsx)
- [frontend/src/hooks/useSessionList.test.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/hooks/useSessionList.test.ts)
- [frontend/src/App.test.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/App.test.tsx)
