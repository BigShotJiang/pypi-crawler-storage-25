# Events Stream Explicit User Scope Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed explicit-scope guard for the hosted SSE
events route.

It closes one remaining session-scope gap:

```text
session detail already enforced explicit user scope
+ /events now enforces the same rule for explicit scoped sessions
+ wrong user scope now fails as not found instead of silently opening an empty wait stream
+ only truly missing sessions still return the empty dashboard stream
```

## 1. Module Goal

The hosted control plane had already tightened selected-session snapshot,
download, confirm, delete, latest-session, and bulk-clear routes. But the SSE
route still allowed one gap:

- `GET /events?session_id=<id>`

could still connect to an explicitly scoped session without `user_id`.

That left one remaining live-runtime path weaker than the rest of the session
contract.

This module aligns `/events` with the same explicit-ownership rules.

## 2. Delivered Behavior

### 2.1 Explicitly scoped event streams now require `user_id`

If the target session declares an explicit owner in metadata, connecting to
`/events` without `user_id` now returns `409`.

### 2.2 Wrong user scope now fails closed

If a caller provides the wrong `user_id`, `/events` now returns `404` for that
session instead of silently falling back to the empty dashboard wait stream.

### 2.3 Truly missing sessions still return the empty dashboard stream

The empty dashboard SSE fallback remains only for:

- no `session_id`;
- unknown `session_id`.

That preserves the original “waiting for new task” behavior without masking
real scope violations.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. `/events?session_id=<id>` returns `409` for explicit scoped sessions when
   `user_id` is missing.
2. `/events?session_id=<id>&user_id=<wrong>` returns `404`.
3. `/events?session_id=<id>&user_id=<correct>` still opens the stream.
4. Unknown sessions still return the empty dashboard SSE payload.
5. Server route tests pass after the contract change.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/server.py tests/test_server_public_urls.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py -q`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- removal of the empty dashboard SSE fallback for truly missing sessions;
- local developer helper parity outside the hosted FastAPI route;
- changes to the internal `_sse_generator` replay semantics.

## 6. Implementation References

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
