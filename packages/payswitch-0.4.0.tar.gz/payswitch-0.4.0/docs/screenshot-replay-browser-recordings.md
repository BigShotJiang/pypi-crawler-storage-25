## Screenshot Replay Browser Recording Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed fallback recording slice for browser
sessions that do not have native Playwright video recording.

It narrows the remaining runtime-media gap this way:

```text
native browser recording unavailable
+ reuse persisted observation screenshots
+ synthesize a replay video at terminal close
+ project that replay through the existing media.persisted artifact path
```

## 1. Module Goal

The external-browser recording baseline only covered sessions where Pay-Switch
could launch a Playwright-owned browser context with native video recording.

That still left an important runtime gap:

- attached CDP sessions and other non-native-recording browser lifecycles could
  produce screenshots, but still emitted no terminal browser media artifact.

This module closes that gap with a bounded fallback: build one replay video from
the already-persisted observation screenshots.

## 2. Delivered Behavior

### 2.1 Screenshot-sequence replay synthesis

When terminal close happens and the browser lifecycle has no native recording
files, the external runner now:

1. collects ordered observation screenshots from the transaction evidence;
2. decodes those encrypted screenshot artifacts back to temporary raw PNG
   frames;
3. invokes local `ffmpeg` to synthesize `observation-replay.mp4`;
4. persists that replay into the existing artifact store as
   `external_browser_recording`;
5. emits the existing `media.persisted` event with
   `recording_source=observation_screenshots`.

### 2.2 Existing control-plane contract remains unchanged

The synthesized replay uses the same downstream contract as native recordings:

- same artifact persistence path;
- same `media.persisted` event family;
- same session snapshot/SSE/media download projection;
- same BrowserPreview and timeline consumers.

That keeps this module additive instead of creating a second browser-media
protocol.

### 2.3 Bounded fallback behavior

This module is intentionally a fallback, not a replacement for native video:

- it only runs when no native recording files are present;
- it depends on already-captured observation screenshots;
- if `ffmpeg` is unavailable or synthesis fails, the runner logs and exits
  without blocking transaction completion.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. A terminal external run with no native browser recording but with persisted
   observation screenshots produces one persisted replay video artifact.
2. The replay artifact is stored as `external_browser_recording`.
3. The emitted `media.persisted` event includes
   `recording_source=observation_screenshots`.
4. Existing native browser recording persistence continues to work unchanged.
5. Failure to synthesize a replay does not fail the transaction itself.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py tests/test_external_runner.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py -q`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- native CDP screencast capture;
- real-time recording while the session is still running;
- audio capture or higher-frame-rate video;
- replay synthesis for paths that never persisted any observation screenshots.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [tests/test_external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_external_runner.py)
- [docs/external-browser-recording-baseline.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/external-browser-recording-baseline.md)
- [docs/external-browser-recording-playback.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/external-browser-recording-playback.md)
