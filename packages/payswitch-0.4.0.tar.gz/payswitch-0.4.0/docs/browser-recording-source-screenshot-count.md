## Browser Recording Source Screenshot Count Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed replay-source screenshot-count slice for
persisted browser recording artifacts.

It closes the next replay provenance gap this way:

```text
screenshot replay already exposes source, size, fps, resolution, codec, bit rate, and format
+ runtime replay artifacts now emit source_screenshot_count
+ server and local settings/events preserve replay screenshot-count aliases
+ WebUI labels replay artifacts with the number of source screenshots used
```

## 1. Module Goal

Screenshot replay artifacts already told operators that a video came from
observation screenshots. But they still could not tell whether a replay came
from one screenshot or many without opening the evidence chain by hand.

This module surfaces the exact screenshot count used to synthesize a replay,
without changing native recording behavior or replay generation itself.

## 2. Delivered Behavior

### 2.1 Runtime replay screenshot-count metadata

When `ExternalCheckoutRunner` synthesizes `observation-replay.mp4`, it now also
records:

- `source_screenshot_count`
- `sourceScreenshotCount`

The count is derived from the same persisted observation screenshots that feed
replay synthesis.

### 2.2 Control-plane alias parity

Public session projection and the local settings/events API now preserve both:

- `source_screenshot_count`
- `sourceScreenshotCount`

This keeps replay screenshot-count metadata aligned with the alias policy used
across the rest of the media artifact contract.

### 2.3 WebUI replay provenance labels

The frontend runtime model now preserves `sourceScreenshotCount`.

Replay media actions surface screenshot-count labels such as:

- `1 截图`

These labels appear in both:

- `BrowserPreview`;
- `LiveTimeline`.

Native browser recordings remain unchanged and do not invent this label.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Screenshot replay persistence carries `source_screenshot_count`.
2. Public session projection preserves both screenshot-count aliases.
3. Local settings/events projection preserves the same aliases.
4. BrowserPreview shows the screenshot-count label only for replay artifacts.
5. LiveTimeline shows the screenshot-count label only for replay artifacts.
6. Existing replay/native recording labels and metadata remain intact.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/engine/external_runner.py payswitch/server.py payswitch/cli.py tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_external_runner.py tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `npm test -- --run src/lib/eventStream.test.ts src/components/BrowserPreview.test.tsx src/components/LiveTimeline.test.tsx`
- `npm run build`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- per-screenshot timing or ordering metadata in the UI;
- source screenshot thumbnails inside the replay action label;
- native recording frame-count inspection.

## 6. Implementation References

- [payswitch/engine/external_runner.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/engine/external_runner.py)
- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [frontend/src/lib/sessionModel.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/sessionModel.ts)
- [frontend/src/lib/eventStream.ts](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/lib/eventStream.ts)
- [frontend/src/components/BrowserPreview.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/BrowserPreview.tsx)
- [frontend/src/components/LiveTimeline.tsx](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/frontend/src/components/LiveTimeline.tsx)
