## Media Artifact Recording Source Alias Parity Module

Date: 2026-05-17
Status: implemented in current branch

This document defines the completed control-plane parity slice for browser
recording provenance metadata.

It closes the current API-shape gap this way:

```text
media artifact already carries recording_source
+ public server projection now also guarantees recordingSource
+ local settings/events projection now does the same
+ downstream consumers no longer depend on one casing only
```

## 1. Module Goal

Browser recording artifacts already stored provenance as:

- `recording_source=native_browser_video`
- `recording_source=observation_screenshots`

But the public server projection and local settings/events API did not
guarantee the camelCase alias alongside the existing snake_case field.

That left the control-plane contract asymmetric compared with `download_url` /
`downloadUrl` and `content_type` / `contentType`.

## 2. Delivered Behavior

### 2.1 Public session/result/event projection

`_confirm_artifact_public_item(...)` now preserves recording provenance through
both aliases whenever either casing is present:

- `recording_source`
- `recordingSource`

This applies to:

- session event projection;
- `pay_switch_result` artifact projection;
- top-level A2A artifact projection.

### 2.2 Local settings/events projection

`_settings_api_project_media_artifacts(...)` now performs the same alias
normalization before adding preview URLs.

That keeps the local `/events` and `/evidence` control plane aligned with the
main FastAPI projection contract.

## 3. Acceptance Criteria

This module is accepted only if all of the following hold:

1. Public media artifact payloads expose both `recording_source` and
   `recordingSource` when provenance is known.
2. Local settings/events projected media artifacts expose the same two fields.
3. Existing download URL and content-type projection behavior remains
   unchanged.
4. Targeted Python tests cover both the public server path and the local
   settings/events path.

## 4. Verification

- `./.venv/bin/python -m ruff check payswitch/server.py payswitch/cli.py tests/test_server_public_urls.py tests/test_ui_settings_api.py`
- `./.venv/bin/python -m pytest tests/test_server_public_urls.py tests/test_ui_settings_api.py -q`
- `git diff --check`

## 5. Non-Goals

This module does not yet deliver:

- new provenance values beyond the existing native/replay source set;
- richer browser-media metadata such as duration, fps, or capture backend;
- live-capture improvements for attached CDP sessions.

## 6. Implementation References

- [payswitch/server.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/server.py)
- [payswitch/cli.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/payswitch/cli.py)
- [tests/test_server_public_urls.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_server_public_urls.py)
- [tests/test_ui_settings_api.py](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/tests/test_ui_settings_api.py)
- [docs/browser-recording-source-attribution.md](/Users/leongong/Desktop/LeonProjects/gho_workspace/payswitch-visible-hybrid-fix/docs/browser-recording-source-attribution.md)
