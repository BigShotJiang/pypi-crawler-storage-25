"""End-user smoke test: run reveilio against the sample JD and resumes."""
from pathlib import Path

import reveilio

HERE = Path(__file__).parent

# 1. Configure OpenAI
reveilio.configure(
    provider="openai",
    api_key="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",
    model="gpt-4o-mini",
)

# 2. Load JD
jd = reveilio.JobDescription.from_file(HERE / "be_job_description.txt")
print("JD parsed. Position:", jd.parsed.get("position_title", "N/A"))
print()

# 3. Discover resumes
EXCLUDE = {"be_job_description.txt", "_run_test.py"}
resumes = sorted(
    p for p in HERE.iterdir()
    if p.is_file()
    and p.suffix.lower() in (".pdf", ".docx", ".doc", ".txt")
    and p.name not in EXCLUDE
    and not p.name.startswith(("report_", "ranking_"))
)

print(f"Found {len(resumes)} resume(s): {', '.join(p.name for p in resumes)}")
print()

# 4. Analyze each resume
results = []
for r_path in resumes:
    print(f"  Analyzing: {r_path.name} ...", end=" ", flush=True)
    result = reveilio.analyze_resume(r_path, jd)
    results.append(result)
    name = (result.candidate_data.name if result.candidate_data else None) or "?"
    print(f"{result.overall_score:.0f}% - {result.recommendation} ({name})")

# 5. Rank
results.sort(key=lambda r: float(r.overall_score or 0), reverse=True)
for i, r in enumerate(results, start=1):
    r.rank = i

# 6. Print summary
print()
print("=" * 70)
print(f"{'RANK':<6} {'CANDIDATE':<30} {'SCORE':>6}   {'RECOMMENDATION'}")
print("-" * 70)
for r in results:
    name = (r.candidate_data.name if r.candidate_data else None) or "Unknown"
    print(f"#{r.rank:<5} {name:<30} {r.overall_score:>5.1f}%   {r.recommendation}")
print("=" * 70)
print()

# Detail per candidate
for r in results:
    name = (r.candidate_data.name if r.candidate_data else None) or "Unknown"
    print(f"--- #{r.rank} {name} ---")
    print(f"  Score: {r.overall_score}%  |  Confidence: {r.confidence_level}")
    print(f"  Summary: {(r.ai_summary or 'N/A')[:200]}")
    if r.strengths:
        print(f"  Strengths: {'; '.join(str(s) for s in r.strengths[:3])}")
    if r.weaknesses:
        print(f"  Gaps: {'; '.join(str(w) for w in r.weaknesses[:3])}")
    if r.suggested_questions:
        print(f"  Interview Q: {r.suggested_questions[0]}")
    print()

# 7. Export PDFs
for r in results:
    name = (r.candidate_data.name if r.candidate_data else "candidate").replace(" ", "_")
    out = HERE / f"report_{r.rank:02d}_{name}.pdf"
    reveilio.save_report_pdf(r, out)
    print(f"  Wrote: {out.name}")

batch_out = HERE / "ranking_summary.pdf"
reveilio.save_batch_report_pdf(results, batch_out)
print(f"  Wrote: {batch_out.name}")

print()
print("Done.")
