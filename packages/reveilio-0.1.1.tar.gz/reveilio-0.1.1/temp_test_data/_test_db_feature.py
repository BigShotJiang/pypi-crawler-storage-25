"""End-user test: exercise the full database feature as a real user would.

No LLM calls needed — we create AnalysisResult objects directly to test
the database export/import/query/delete workflow across all scenarios.
"""
from pathlib import Path

import reveilio

HERE = Path(__file__).parent
DB_PATH = HERE / "test_user_analyses.db"

# Clean up from any previous run
if DB_PATH.exists():
    DB_PATH.unlink()

print("=" * 70)
print("  REVEILIO DATABASE FEATURE — END-USER TEST")
print("=" * 70)
print()

# ──────────────────────────────────────────────────────────────────────
# 1. CONNECT TO DATABASE
# ──────────────────────────────────────────────────────────────────────
print("[1] Connecting to SQLite database...")
cfg = reveilio.connect_db("sqlite", filepath=str(DB_PATH))
print(f"    Backend:    {cfg.backend}")
print(f"    File:       {cfg.filepath}")
print(f"    Table:      {cfg.table_name}")
print(f"    DB exists:  {DB_PATH.exists()}")
print()

# ──────────────────────────────────────────────────────────────────────
# 2. CREATE REALISTIC TEST DATA
# ──────────────────────────────────────────────────────────────────────
print("[2] Creating sample analysis results...")

candidates = [
    reveilio.AnalysisResult(
        overall_score=92.5,
        confidence_level="High",
        recommendation="Shortlist",
        ai_summary="Exceptional backend engineer with 8 years of Python and distributed systems experience.",
        strengths=["Python expertise", "System design", "Team leadership"],
        weaknesses=["No frontend experience"],
        career_flags=[],
        suggested_questions=["Describe your approach to designing a scalable microservices architecture."],
        suggested_roles=["Senior Backend Engineer", "Staff Engineer"],
        candidate_data=reveilio.ResumeData(
            name="Sarah Chen",
            email="sarah.chen@email.com",
            phone="+1-555-0101",
            skills=["Python", "Go", "PostgreSQL", "Redis", "Kubernetes", "AWS"],
            experience=[],
            education=[],
            certifications=["AWS Solutions Architect"],
            total_experience=8.0,
            filename="sarah_chen_resume.pdf",
        ),
        detailed_scores={"skills": 95, "experience": 90, "education": 85},
    ),
    reveilio.AnalysisResult(
        overall_score=78.0,
        confidence_level="High",
        recommendation="Shortlist",
        ai_summary="Solid mid-level developer with strong cloud-native skills and growing leadership.",
        strengths=["Cloud native", "CI/CD expertise", "Good communicator"],
        weaknesses=["Limited system design experience", "No mentoring track record"],
        career_flags=[],
        suggested_questions=["Walk me through a complex deployment pipeline you built."],
        suggested_roles=["Backend Engineer", "DevOps Engineer"],
        candidate_data=reveilio.ResumeData(
            name="Marcus Johnson",
            email="marcus.j@email.com",
            skills=["Python", "Docker", "Terraform", "GitHub Actions", "MySQL"],
            total_experience=4.5,
            filename="marcus_johnson_resume.pdf",
        ),
        detailed_scores={"skills": 80, "experience": 72, "education": 78},
    ),
    reveilio.AnalysisResult(
        overall_score=65.0,
        confidence_level="Medium",
        recommendation="Needs Review",
        ai_summary="Junior developer transitioning from data science with relevant Python skills.",
        strengths=["Python proficiency", "Data analysis", "Fast learner"],
        weaknesses=["No production backend experience", "Limited CS fundamentals"],
        career_flags=["Career transition"],
        suggested_questions=["How would you handle a production outage?"],
        suggested_roles=["Junior Backend Engineer", "Data Engineer"],
        candidate_data=reveilio.ResumeData(
            name="Priya Patel",
            email="priya.p@email.com",
            skills=["Python", "pandas", "SQL", "Flask", "Git"],
            total_experience=2.0,
            filename="priya_patel_resume.docx",
        ),
        detailed_scores={"skills": 60, "experience": 55, "education": 80},
    ),
    reveilio.AnalysisResult(
        overall_score=45.0,
        confidence_level="Medium",
        recommendation="Not Suitable",
        ai_summary="Frontend specialist with minimal backend overlap. Strong React but lacks server-side depth.",
        strengths=["React expert", "UI/UX eye", "TypeScript"],
        weaknesses=["No backend experience", "No database skills", "No cloud experience"],
        career_flags=["Role mismatch"],
        suggested_questions=[],
        suggested_roles=["Frontend Engineer", "Full-Stack (Frontend-heavy)"],
        candidate_data=reveilio.ResumeData(
            name="Alex Rivera",
            email="alex.r@email.com",
            skills=["JavaScript", "TypeScript", "React", "Next.js", "CSS"],
            total_experience=5.0,
            filename="alex_rivera_resume.pdf",
        ),
        detailed_scores={"skills": 30, "experience": 40, "education": 65},
    ),
    reveilio.AnalysisResult(
        overall_score=88.0,
        confidence_level="High",
        recommendation="Shortlist",
        ai_summary="Well-rounded senior engineer with excellent distributed systems background.",
        strengths=["Distributed systems", "Mentoring", "Open source contributor"],
        weaknesses=["Salary expectations may exceed budget"],
        career_flags=[],
        suggested_questions=["Tell me about a system you designed that handles millions of requests per day."],
        suggested_roles=["Senior Backend Engineer", "Principal Engineer"],
        candidate_data=reveilio.ResumeData(
            name="David Kim",
            email="david.kim@email.com",
            skills=["Java", "Python", "Kafka", "PostgreSQL", "gRPC", "AWS"],
            total_experience=10.0,
            filename="david_kim_resume.pdf",
        ),
        detailed_scores={"skills": 88, "experience": 92, "education": 80},
    ),
]

print(f"    Created {len(candidates)} candidate results")
print()

# ──────────────────────────────────────────────────────────────────────
# 3. EXPORT SINGLE RESULT
# ──────────────────────────────────────────────────────────────────────
print("[3] Exporting single result (Sarah Chen)...")
sarah_id = reveilio.export_result(
    candidates[0],
    job_title="Senior Backend Engineer",
)
print(f"    Stored with analysis_id: {sarah_id}")
print()

# ──────────────────────────────────────────────────────────────────────
# 4. EXPORT BATCH RESULTS
# ──────────────────────────────────────────────────────────────────────
print("[4] Exporting remaining candidates in batch...")
remaining_ids = reveilio.export_results(
    candidates[1:],
    job_title="Senior Backend Engineer",
)
print(f"    Stored {len(remaining_ids)} more candidates")
all_ids = [sarah_id] + remaining_ids
for name, aid in zip([c.candidate_data.name for c in candidates], all_ids):
    print(f"      {name}: {aid}")
print()

# ──────────────────────────────────────────────────────────────────────
# 5. IMPORT SINGLE RESULT BY ID
# ──────────────────────────────────────────────────────────────────────
print("[5] Importing Sarah's result back by ID...")
loaded_sarah = reveilio.import_result(sarah_id)
print(f"    Name:           {loaded_sarah.candidate_data.name}")
print(f"    Score:          {loaded_sarah.overall_score}")
print(f"    Recommendation: {loaded_sarah.recommendation}")
print(f"    Skills:         {loaded_sarah.candidate_data.skills}")
print(f"    Summary:        {loaded_sarah.ai_summary[:80]}...")
assert loaded_sarah.overall_score == 92.5, "Score mismatch!"
assert loaded_sarah.candidate_data.name == "Sarah Chen", "Name mismatch!"
assert loaded_sarah.recommendation == "Shortlist", "Recommendation mismatch!"
print("    PASS: Data integrity verified")
print()

# ──────────────────────────────────────────────────────────────────────
# 6. IMPORT ALL RESULTS
# ──────────────────────────────────────────────────────────────────────
print("[6] Importing all results (sorted by most recent)...")
all_loaded = reveilio.import_results(limit=100)
print(f"    Retrieved {len(all_loaded)} results")
for r in all_loaded:
    name = r.candidate_data.name if r.candidate_data else "?"
    print(f"      {name}: {r.overall_score}% — {r.recommendation}")
assert len(all_loaded) == 5, f"Expected 5 results, got {len(all_loaded)}"
print("    PASS: All 5 candidates retrieved")
print()

# ──────────────────────────────────────────────────────────────────────
# 7. IMPORT WITH ORDERING
# ──────────────────────────────────────────────────────────────────────
print("[7] Importing results ordered by score (descending)...")
by_score = reveilio.import_results(order_by="overall_score", descending=True)
scores = [r.overall_score for r in by_score]
print(f"    Scores: {scores}")
assert scores == sorted(scores, reverse=True), "Not in descending order!"
print("    PASS: Correctly ordered by score descending")
print()

# ──────────────────────────────────────────────────────────────────────
# 8. IMPORT WITH PAGINATION
# ──────────────────────────────────────────────────────────────────────
print("[8] Testing pagination (2 per page)...")
page1 = reveilio.import_results(limit=2, offset=0)
page2 = reveilio.import_results(limit=2, offset=2)
page3 = reveilio.import_results(limit=2, offset=4)
print(f"    Page 1: {len(page1)} results")
print(f"    Page 2: {len(page2)} results")
print(f"    Page 3: {len(page3)} results")
assert len(page1) == 2
assert len(page2) == 2
assert len(page3) == 1
print("    PASS: Pagination works correctly")
print()

# ──────────────────────────────────────────────────────────────────────
# 9. LIST ANALYSES (METADATA ONLY)
# ──────────────────────────────────────────────────────────────────────
print("[9] Listing analyses (metadata only, no full data)...")
entries = reveilio.list_analyses()
print(f"    {'CANDIDATE':<20} {'SCORE':>6}   {'RECOMMENDATION':<15}  {'JOB TITLE'}")
print(f"    {'-'*20} {'-'*6}   {'-'*15}  {'-'*25}")
for e in entries:
    print(f"    {e['candidate_name'] or '?':<20} {e['overall_score']:>5.1f}%   {e['recommendation']:<15}  {e['job_title'] or 'N/A'}")
assert len(entries) == 5
assert all("analysis_id" in e for e in entries)
assert all("created_at" in e for e in entries)
print("    PASS: Metadata listing works")
print()

# ──────────────────────────────────────────────────────────────────────
# 10. QUERY BY MINIMUM SCORE
# ──────────────────────────────────────────────────────────────────────
print("[10] Querying candidates with score >= 80...")
high_scorers = reveilio.query_results(min_score=80)
names = [r.candidate_data.name for r in high_scorers]
print(f"    Found: {names}")
assert len(high_scorers) == 2
assert all(r.overall_score >= 80 for r in high_scorers)
print("    PASS: min_score filter works")
print()

# ──────────────────────────────────────────────────────────────────────
# 11. QUERY BY RECOMMENDATION
# ──────────────────────────────────────────────────────────────────────
print("[11] Querying 'Shortlist' candidates...")
shortlisted = reveilio.query_results(recommendation="Shortlist")
names = [r.candidate_data.name for r in shortlisted]
print(f"    Found: {names}")
assert len(shortlisted) == 3
assert all(r.recommendation == "Shortlist" for r in shortlisted)
print("    PASS: recommendation filter works")

print()
print("[12] Querying 'Not Suitable' candidates...")
unsuitable = reveilio.query_results(recommendation="Not Suitable")
names = [r.candidate_data.name for r in unsuitable]
print(f"    Found: {names}")
assert len(unsuitable) == 1
assert unsuitable[0].candidate_data.name == "Alex Rivera"
print("    PASS: Not Suitable filter works")
print()

# ──────────────────────────────────────────────────────────────────────
# 13. QUERY BY CANDIDATE NAME
# ──────────────────────────────────────────────────────────────────────
print("[13] Searching for candidate name 'Kim'...")
kim = reveilio.query_results(candidate_name="Kim")
print(f"    Found: {[r.candidate_data.name for r in kim]}")
assert len(kim) == 1
assert kim[0].candidate_data.name == "David Kim"
print("    PASS: name search works")
print()

# ──────────────────────────────────────────────────────────────────────
# 14. QUERY BY SCORE RANGE
# ──────────────────────────────────────────────────────────────────────
print("[14] Querying candidates with score between 60 and 85...")
mid_range = reveilio.query_results(min_score=60, max_score=85)
names = [r.candidate_data.name for r in mid_range]
scores = [r.overall_score for r in mid_range]
print(f"    Found: {list(zip(names, scores))}")
assert all(60 <= r.overall_score <= 85 for r in mid_range)
assert len(mid_range) == 2  # Marcus (78) and Priya (65)
print("    PASS: score range filter works")
print()

# ──────────────────────────────────────────────────────────────────────
# 15. QUERY BY JOB TITLE
# ──────────────────────────────────────────────────────────────────────
print("[15] Querying by job title 'Backend'...")
backend = reveilio.query_results(job_title="Backend")
print(f"    Found {len(backend)} candidates tagged with 'Backend'")
assert len(backend) == 5
print("    PASS: job title filter works")
print()

# ──────────────────────────────────────────────────────────────────────
# 16. COMBINED FILTERS
# ──────────────────────────────────────────────────────────────────────
print("[16] Combined query: Shortlist + score >= 85 + job title 'Backend'...")
top_pick = reveilio.query_results(
    recommendation="Shortlist",
    min_score=85,
    job_title="Backend",
)
names = [r.candidate_data.name for r in top_pick]
print(f"    Found: {names}")
assert len(top_pick) == 2  # Sarah (92.5) and David (88)
print("    PASS: combined filters work")
print()

# ──────────────────────────────────────────────────────────────────────
# 17. QUERY WITH NO MATCHES
# ──────────────────────────────────────────────────────────────────────
print("[17] Querying with impossible filters (score >= 99)...")
none_found = reveilio.query_results(min_score=99)
print(f"    Found: {len(none_found)} results")
assert none_found == []
print("    PASS: empty results handled correctly")
print()

# ──────────────────────────────────────────────────────────────────────
# 18. IMPORT NONEXISTENT ID (ERROR HANDLING)
# ──────────────────────────────────────────────────────────────────────
print("[18] Attempting to import non-existent analysis ID...")
try:
    reveilio.import_result("this-id-does-not-exist")
    print("    FAIL: Should have raised KeyError!")
except KeyError as e:
    print(f"    Caught expected error: {e}")
    print("    PASS: Error handling works")
print()

# ──────────────────────────────────────────────────────────────────────
# 19. DELETE A RESULT
# ──────────────────────────────────────────────────────────────────────
print("[19] Deleting Alex Rivera's record...")
alex_id = all_ids[3]  # Alex is at index 3
deleted = reveilio.delete_result(alex_id)
print(f"    Deleted: {deleted}")
assert deleted is True

# Verify it's gone
remaining = reveilio.import_results(limit=100)
remaining_names = [r.candidate_data.name for r in remaining]
print(f"    Remaining candidates: {remaining_names}")
assert "Alex Rivera" not in remaining_names
assert len(remaining) == 4
print("    PASS: Delete works, record removed")
print()

# ──────────────────────────────────────────────────────────────────────
# 20. DELETE NON-EXISTENT (SHOULD RETURN FALSE)
# ──────────────────────────────────────────────────────────────────────
print("[20] Deleting non-existent record...")
not_deleted = reveilio.delete_result("fake-id")
print(f"    Result: {not_deleted}")
assert not_deleted is False
print("    PASS: Returns False for non-existent ID")
print()

# ──────────────────────────────────────────────────────────────────────
# 21. EXPORT WITH CUSTOM ID
# ──────────────────────────────────────────────────────────────────────
print("[21] Exporting with a custom analysis ID...")
custom_id = "hire-2026-q1-001"
reveilio.export_result(
    candidates[0],
    job_title="Lead Engineer",
    analysis_id=custom_id,
)
loaded = reveilio.import_result(custom_id)
print(f"    Custom ID:  {custom_id}")
print(f"    Loaded:     {loaded.candidate_data.name} — {loaded.overall_score}%")
assert loaded.candidate_data.name == "Sarah Chen"
print("    PASS: Custom ID works")
print()

# ──────────────────────────────────────────────────────────────────────
# 22. SWITCH TO A DIFFERENT TABLE
# ──────────────────────────────────────────────────────────────────────
print("[22] Switching to a different table name...")
reveilio.connect_db("sqlite", filepath=str(DB_PATH), table_name="q2_candidates")
reveilio.export_result(candidates[1], job_title="DevOps Engineer")
q2_entries = reveilio.list_analyses()
print(f"    Table 'q2_candidates' has {len(q2_entries)} entry")
assert len(q2_entries) == 1
assert q2_entries[0]["candidate_name"] == "Marcus Johnson"

# Switch back and verify original table still has data
reveilio.connect_db("sqlite", filepath=str(DB_PATH), table_name="reveilio_analyses")
original_entries = reveilio.list_analyses()
print(f"    Table 'reveilio_analyses' still has {len(original_entries)} entries")
assert len(original_entries) == 5  # 4 remaining + 1 custom-id sarah
print("    PASS: Multiple tables work independently")
print()

# ──────────────────────────────────────────────────────────────────────
# 23. SWITCH TO A DIFFERENT DATABASE FILE
# ──────────────────────────────────────────────────────────────────────
print("[23] Switching to a completely different database file...")
DB_PATH_2 = HERE / "test_user_analyses_2.db"
if DB_PATH_2.exists():
    DB_PATH_2.unlink()

reveilio.connect_db("sqlite", filepath=str(DB_PATH_2))
reveilio.export_result(candidates[4], job_title="Principal Engineer")
entries_db2 = reveilio.list_analyses()
print(f"    Second DB has {len(entries_db2)} entry: {entries_db2[0]['candidate_name']}")
assert len(entries_db2) == 1
assert entries_db2[0]["candidate_name"] == "David Kim"
print("    PASS: Database switching works")
print()

# ──────────────────────────────────────────────────────────────────────
# 24. EXPORT DICT INPUT (not AnalysisResult object)
# ──────────────────────────────────────────────────────────────────────
print("[24] Exporting a raw dict (not an AnalysisResult)...")
raw_dict = {
    "overall_score": 71.0,
    "recommendation": "Needs Review",
    "confidence_level": "Medium",
    "ai_summary": "Decent candidate from dict input.",
    "candidate_data": {
        "name": "Test DictUser",
        "skills": ["Python", "SQL"],
    },
}
dict_id = reveilio.export_result(raw_dict, job_title="Test Role")
loaded_dict = reveilio.import_result(dict_id)
print(f"    Loaded: {loaded_dict.candidate_data.name} — {loaded_dict.overall_score}%")
assert loaded_dict.overall_score == 71.0
assert loaded_dict.candidate_data.name == "Test DictUser"
print("    PASS: Dict input export/import works")
print()

# ──────────────────────────────────────────────────────────────────────
# 25. VERIFY DATA INTEGRITY (DEEP CHECK)
# ──────────────────────────────────────────────────────────────────────
print("[25] Deep data integrity check on Sarah's record...")
reveilio.connect_db("sqlite", filepath=str(DB_PATH))
loaded = reveilio.import_result(sarah_id)
original = candidates[0]

checks = [
    ("overall_score", loaded.overall_score == original.overall_score),
    ("confidence_level", loaded.confidence_level == original.confidence_level),
    ("recommendation", loaded.recommendation == original.recommendation),
    ("ai_summary", loaded.ai_summary == original.ai_summary),
    ("strengths", loaded.strengths == original.strengths),
    ("weaknesses", loaded.weaknesses == original.weaknesses),
    ("career_flags", loaded.career_flags == original.career_flags),
    ("suggested_questions", loaded.suggested_questions == original.suggested_questions),
    ("suggested_roles", loaded.suggested_roles == original.suggested_roles),
    ("candidate.name", loaded.candidate_data.name == original.candidate_data.name),
    ("candidate.email", loaded.candidate_data.email == original.candidate_data.email),
    ("candidate.phone", loaded.candidate_data.phone == original.candidate_data.phone),
    ("candidate.skills", loaded.candidate_data.skills == original.candidate_data.skills),
    ("candidate.certifications", loaded.candidate_data.certifications == original.candidate_data.certifications),
    ("candidate.total_experience", loaded.candidate_data.total_experience == original.candidate_data.total_experience),
    ("candidate.filename", loaded.candidate_data.filename == original.candidate_data.filename),
    ("detailed_scores", loaded.detailed_scores == original.detailed_scores),
]

all_pass = True
for field, ok in checks:
    status = "OK" if ok else "FAIL"
    if not ok:
        all_pass = False
    print(f"    {field:<30} {status}")

assert all_pass, "Some data integrity checks failed!"
print("    PASS: All fields preserved perfectly")
print()

# ──────────────────────────────────────────────────────────────────────
# 26. DISCONNECT
# ──────────────────────────────────────────────────────────────────────
print("[26] Disconnecting from database...")
reveilio.disconnect_db()

# Verify operations fail after disconnect
try:
    reveilio.import_results()
    print("    FAIL: Should have raised RuntimeError!")
except RuntimeError as e:
    print(f"    Caught expected error: {e}")
    print("    PASS: Operations correctly fail after disconnect")
print()

# ──────────────────────────────────────────────────────────────────────
# CLEANUP
# ──────────────────────────────────────────────────────────────────────
print("[Cleanup] Removing test database files...")
for p in [DB_PATH, DB_PATH_2]:
    if p.exists():
        p.unlink()
        print(f"    Removed: {p.name}")

print()
print("=" * 70)
print("  ALL 26 TESTS PASSED")
print("=" * 70)
