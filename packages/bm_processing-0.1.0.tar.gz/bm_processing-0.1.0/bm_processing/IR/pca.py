def run_pca():
    print("Performing PCA transformation")
