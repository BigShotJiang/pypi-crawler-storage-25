def run_pagerank():
    print("Running PageRank algorithm")
