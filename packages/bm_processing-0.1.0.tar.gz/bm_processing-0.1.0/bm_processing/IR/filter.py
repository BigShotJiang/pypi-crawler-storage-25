def apply_filter():
    print("Applying filter to data")
