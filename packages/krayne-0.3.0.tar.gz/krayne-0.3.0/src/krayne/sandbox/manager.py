from __future__ import annotations

import json
import subprocess
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from krayne.config.settings import (
    PRISM_DIR,
    clear_krayne_settings,
    load_krayne_settings,
    save_krayne_settings,
    KrayneSettings,
)
from krayne.errors import (
    ConfigValidationError,
    DockerNotFoundError,
    SandboxAlreadyExistsError,
    SandboxError,
    SandboxNotFoundError,
)

SANDBOX_CONTAINER_NAME = "krayne-sandbox"
K3S_IMAGE = "rancher/k3s:v1.35.2-k3s1"
HELM_IMAGE = "alpine/helm"
KUBERAY_HELM_REPO = "https://ray-project.github.io/kuberay-helm"
SANDBOX_KUBECONFIG = PRISM_DIR / "sandbox-kubeconfig"

MIN_CPUS = 2
MIN_MEMORY_GB = 4
SANDBOX_MEMORY_GB = 6

# Step names for progress reporting
STEP_DOCKER = "Docker"
STEP_K3S_CONTAINER = "K3S Container"
STEP_K3S_NODE = "K3S Node"
STEP_KUBECONFIG = "Kubeconfig"
STEP_HELM_INSTALL = "KubeRay Helm Chart"
STEP_CRD = "RayCluster CRD"
STEP_OPERATOR = "Operator Ready"

SETUP_STEPS = [
    STEP_DOCKER,
    STEP_K3S_CONTAINER,
    STEP_K3S_NODE,
    STEP_KUBECONFIG,
    STEP_HELM_INSTALL,
    STEP_CRD,
    STEP_OPERATOR,
]

ProgressCallback = Callable[[str, str], None] | None


@dataclass(frozen=True)
class SandboxStatus:
    running: bool
    container_id: str | None = None
    kubeconfig: str | None = None
    k3s_version: str | None = None
    created_at: str | None = None


def _run(cmd: list[str], check: bool = True, **kwargs) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            cmd, check=check, capture_output=True, text=True, **kwargs
        )
    except subprocess.CalledProcessError as exc:
        raise SandboxError(
            f"Command failed: {' '.join(cmd)}\n{exc.stderr}"
        ) from exc
    except FileNotFoundError as exc:
        raise SandboxError(f"Command not found: {cmd[0]}") from exc


def _container_exists() -> bool:
    result = subprocess.run(
        ["docker", "inspect", SANDBOX_CONTAINER_NAME],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _notify(on_progress: ProgressCallback, step: str, status: str) -> None:
    if on_progress is not None:
        on_progress(step, status)


def _wait_until(
    check_fn: Callable[[], bool],
    step_name: str,
    timeout: int,
    on_progress: ProgressCallback,
    poll_interval: float = 3.0,
    timeout_message: str | None = None,
) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        _notify(on_progress, step_name, "in_progress")
        if check_fn():
            _notify(on_progress, step_name, "done")
            return
        time.sleep(poll_interval)
    raise SandboxError(
        timeout_message or f"{step_name} not ready within {timeout}s"
    )


def _k3s_node_ready() -> bool:
    result = subprocess.run(
        [
            "docker", "exec", SANDBOX_CONTAINER_NAME,
            "kubectl", "get", "nodes",
            "-o", "jsonpath={.items[0].status.conditions[-1].type}",
        ],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0 and "Ready" in result.stdout


def _raycluster_crd_registered(kubeconfig: str) -> bool:
    result = subprocess.run(
        ["kubectl", "--kubeconfig", kubeconfig, "get", "crd", "rayclusters.ray.io"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _deployment_available(name: str, kubeconfig: str, namespace: str) -> bool:
    result = subprocess.run(
        [
            "kubectl", "--kubeconfig", kubeconfig,
            "get", "deployment", name,
            "-n", namespace,
            "-o", "jsonpath={.status.availableReplicas}",
        ],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0 and result.stdout.strip() not in ("", "0", "null")


def _check_docker(on_progress: ProgressCallback) -> None:
    _notify(on_progress, STEP_DOCKER, "in_progress")
    try:
        result = _run(["docker", "info", "--format", "{{.NCPU}} {{.MemTotal}}"])
    except SandboxError:
        _notify(on_progress, STEP_DOCKER, "failed")
        raise DockerNotFoundError()

    parts = result.stdout.strip().split()
    if len(parts) >= 2:
        ncpu = int(parts[0])
        mem_bytes = int(parts[1])
        mem_gb = mem_bytes / (1024 ** 3)
        if ncpu < MIN_CPUS or mem_gb < MIN_MEMORY_GB:
            _notify(on_progress, STEP_DOCKER, "failed")
            raise SandboxError(
                f"Docker has {ncpu} CPUs and {mem_gb:.1f}GB memory, "
                f"but the sandbox requires at least {MIN_CPUS} CPUs "
                f"and {MIN_MEMORY_GB}GB memory. "
                "Increase resources in your Docker/Rancher Desktop settings."
            )
    _notify(on_progress, STEP_DOCKER, "done")


def _start_k3s_container(on_progress: ProgressCallback) -> None:
    if _container_exists():
        _notify(on_progress, STEP_K3S_CONTAINER, "failed")
        raise SandboxAlreadyExistsError()

    _notify(on_progress, STEP_K3S_CONTAINER, "in_progress")
    _run([
        "docker", "run", "-d",
        "--name", SANDBOX_CONTAINER_NAME,
        "--privileged",
        "-p", "6443:6443",
        "-p", "30000-30100:30000-30100",
        "--cpus", str(MIN_CPUS),
        "--memory", f"{SANDBOX_MEMORY_GB}g",
        "-e", "K3S_KUBECONFIG_MODE=644",
        K3S_IMAGE,
        "server", "--disable=traefik",
        "--kube-apiserver-arg", "service-node-port-range=30000-30100",
    ])
    _notify(on_progress, STEP_K3S_CONTAINER, "done")


def _extract_kubeconfig(on_progress: ProgressCallback) -> str:
    _notify(on_progress, STEP_KUBECONFIG, "in_progress")
    result = _run([
        "docker", "exec", SANDBOX_CONTAINER_NAME,
        "cat", "/etc/rancher/k3s/k3s.yaml",
    ])
    raw_kubeconfig = result.stdout

    PRISM_DIR.mkdir(parents=True, exist_ok=True)
    SANDBOX_KUBECONFIG.write_text(raw_kubeconfig)
    _notify(on_progress, STEP_KUBECONFIG, "done")
    return raw_kubeconfig


def _install_kuberay(raw_kubeconfig: str, on_progress: ProgressCallback) -> None:
    _notify(on_progress, STEP_HELM_INSTALL, "in_progress")
    # Helm runs inside a sibling container that shares k3s's network namespace,
    # so it needs a kubeconfig file that's bind-mountable from the host.
    internal_kubeconfig = str(PRISM_DIR / "sandbox-kubeconfig-internal")
    Path(internal_kubeconfig).write_text(raw_kubeconfig)
    try:
        _run([
            "docker", "run", "--rm",
            "--network", f"container:{SANDBOX_CONTAINER_NAME}",
            "-v", f"{internal_kubeconfig}:/root/.kube/config:ro",
            HELM_IMAGE,
            "install", "kuberay-operator", "kuberay-operator",
            "--repo", KUBERAY_HELM_REPO,
            "--namespace", "default",
        ])
    finally:
        Path(internal_kubeconfig).unlink(missing_ok=True)
    _notify(on_progress, STEP_HELM_INSTALL, "done")


def setup_sandbox(on_progress: ProgressCallback = None) -> str:
    """Create a local k3s container with KubeRay and return the kubeconfig path."""
    _check_docker(on_progress)
    _start_k3s_container(on_progress)

    try:
        _wait_until(
            _k3s_node_ready,
            STEP_K3S_NODE,
            timeout=120,
            on_progress=on_progress,
            timeout_message="K3S node not ready within 120s",
        )

        raw_kubeconfig = _extract_kubeconfig(on_progress)
        _install_kuberay(raw_kubeconfig, on_progress)

        kubeconfig_path = str(SANDBOX_KUBECONFIG)

        _wait_until(
            lambda: _raycluster_crd_registered(kubeconfig_path),
            STEP_CRD,
            timeout=120,
            on_progress=on_progress,
            timeout_message="RayCluster CRD not registered within timeout",
        )

        _wait_until(
            lambda: _deployment_available("kuberay-operator", kubeconfig_path, "default"),
            STEP_OPERATOR,
            timeout=180,
            on_progress=on_progress,
            poll_interval=5.0,
            timeout_message="Deployment kuberay-operator not available within 180s",
        )

        save_krayne_settings(KrayneSettings(kubeconfig=kubeconfig_path))
        return kubeconfig_path

    except Exception:
        subprocess.run(
            ["docker", "rm", "-f", SANDBOX_CONTAINER_NAME],
            capture_output=True,
            text=True,
        )
        raise


def teardown_sandbox() -> None:
    if not _container_exists():
        raise SandboxNotFoundError()

    _run(["docker", "rm", "-f", SANDBOX_CONTAINER_NAME])

    if SANDBOX_KUBECONFIG.exists():
        SANDBOX_KUBECONFIG.unlink()

    # A ConfigValidationError here means the settings file is already in
    # a broken state (e.g. references a missing kubeconfig) — treat
    # that as "clear the settings" since the sandbox kubeconfig is
    # about to disappear anyway.
    try:
        settings = load_krayne_settings()
    except ConfigValidationError:
        clear_krayne_settings()
    else:
        if settings.kubeconfig == str(SANDBOX_KUBECONFIG):
            clear_krayne_settings()


def sandbox_status() -> SandboxStatus:
    result = subprocess.run(
        ["docker", "inspect", SANDBOX_CONTAINER_NAME],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return SandboxStatus(running=False)

    try:
        info = json.loads(result.stdout)[0]
    except (IndexError, json.JSONDecodeError):
        return SandboxStatus(running=False)

    running = info.get("State", {}).get("Running", False)
    container_id = info.get("Id", "")[:12]
    created_at = info.get("Created")
    image = info.get("Config", {}).get("Image", "")

    kubeconfig_str = str(SANDBOX_KUBECONFIG) if SANDBOX_KUBECONFIG.exists() else None

    return SandboxStatus(
        running=running,
        container_id=container_id,
        kubeconfig=kubeconfig_str,
        k3s_version=image,
        created_at=created_at,
    )
