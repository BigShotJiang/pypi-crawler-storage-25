from __future__ import annotations

import hashlib
import json
import os
import signal
import socket
import subprocess
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from pathlib import Path
from urllib.parse import urlparse

from krayne.config.settings import PRISM_DIR

PORT_RANGE_START = 10000
PORT_RANGE_END = 60000

TUNNEL_DIR = PRISM_DIR / "tunnels"

# service name -> (remote port, URL scheme)
SERVICE_PORTS: dict[str, tuple[int, str]] = {
    "dashboard": (8265, "http"),
    "client": (10001, "ray"),
    "notebook": (8888, "http"),
    "code-server": (8443, "http"),
    "ssh": (22, "ssh"),
}


@dataclass(frozen=True)
class TunnelInfo:
    """Metadata for a single port-forward tunnel."""

    service: str
    remote_port: int
    local_port: int
    local_url: str


@dataclass
class TunnelState:
    """Persisted state for an active tunnel session."""

    cluster_name: str
    namespace: str
    tunnels: list[TunnelInfo]
    pids: list[int]


def _state_path(cluster_name: str, namespace: str) -> Path:
    return TUNNEL_DIR / namespace / f"{cluster_name}.json"


def _pid_alive(pid: int) -> bool:
    """Check whether a process with *pid* is still running."""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def local_port_for(cluster_name: str, namespace: str, service_name: str) -> int:
    """Return a deterministic local port for the given (cluster, namespace, service) triple."""
    key = f"{cluster_name}/{namespace}/{service_name}"
    h = int(hashlib.sha256(key.encode()).hexdigest(), 16)
    return PORT_RANGE_START + (h % (PORT_RANGE_END - PORT_RANGE_START))


def head_port_names(obj: dict) -> set[str]:
    """Collect all named ports from head containers and headService spec."""
    head_spec = obj.get("spec", {}).get("headGroupSpec", {})
    containers = head_spec.get("template", {}).get("spec", {}).get("containers", [])
    names: set[str] = set()
    for container in containers:
        for port in container.get("ports", []):
            name = port.get("name")
            if name:
                names.add(name)
    for port in head_spec.get("headService", {}).get("spec", {}).get("ports", []):
        name = port.get("name")
        if name:
            names.add(name)
    return names


def detect_services(obj: dict) -> list[str]:
    """Detect which services are exposed on the head node by inspecting port names."""
    names = head_port_names(obj)
    return [name for name in SERVICE_PORTS if name in names]


def check_service_health(
    *,
    cluster_status: str,
    head_ip: str | None,
    declared_services: list[str],
    tunnel_map: dict[str, str],
    timeout: float = 0.5,
) -> dict[str, str]:
    """Probe each declared service and return its observed status.

    Returned status is one of:
    - ``"available"`` — TCP probe succeeded, or no probe target was reachable
      and the cluster reports ready (best-effort fallback)
    - ``"pending"`` — cluster is not yet ready; head pod still starting
    - ``"unreachable"`` — cluster reports ready but the service port did not
      respond within *timeout*

    A tunnel-backed ``localhost:<port>`` is preferred when a service has an
    open tunnel, since that path is always reachable from the caller. When no
    tunnel is open the head pod IP is probed; that succeeds when the caller is
    in-cluster and harmlessly times out otherwise (we then trust the cluster
    status and report ``"available"``).
    """
    if cluster_status != "ready":
        return {svc: "pending" for svc in declared_services}

    targets: dict[str, tuple[str, int]] = {}
    for svc in declared_services:
        target = _probe_target(svc, head_ip, tunnel_map.get(svc))
        if target is not None:
            targets[svc] = target

    results: dict[str, str] = {}
    if targets:
        with ThreadPoolExecutor(max_workers=len(targets)) as pool:
            futures = {
                svc: pool.submit(_tcp_probe, host, port, timeout)
                for svc, (host, port) in targets.items()
            }
            for svc, fut in futures.items():
                results[svc] = "available" if fut.result() else "unreachable"

    for svc in declared_services:
        results.setdefault(svc, "available")

    return results


def _probe_target(
    service: str,
    head_ip: str | None,
    tunnel_url: str | None,
) -> tuple[str, int] | None:
    if tunnel_url:
        parsed = urlparse(tunnel_url)
        if parsed.hostname and parsed.port:
            return (parsed.hostname, parsed.port)
    if head_ip and service in SERVICE_PORTS:
        return (head_ip, SERVICE_PORTS[service][0])
    return None


def _tcp_probe(host: str, port: int, timeout: float) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def load_tunnel_state(cluster_name: str, namespace: str) -> TunnelState | None:
    """Load persisted tunnel state, returning ``None`` if absent or stale."""
    path = _state_path(cluster_name, namespace)
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text())
        tunnels = [TunnelInfo(**t) for t in raw["tunnels"]]
        pids = raw["pids"]
        return TunnelState(
            cluster_name=raw["cluster_name"],
            namespace=raw["namespace"],
            tunnels=tunnels,
            pids=pids,
        )
    except (json.JSONDecodeError, KeyError, TypeError):
        path.unlink(missing_ok=True)
        return None


def _save_tunnel_state(state: TunnelState) -> None:
    path = _state_path(state.cluster_name, state.namespace)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "cluster_name": state.cluster_name,
        "namespace": state.namespace,
        "tunnels": [asdict(t) for t in state.tunnels],
        "pids": state.pids,
    }
    path.write_text(json.dumps(data, indent=2))


def _remove_tunnel_state(cluster_name: str, namespace: str) -> None:
    path = _state_path(cluster_name, namespace)
    path.unlink(missing_ok=True)


def is_tunnel_active(cluster_name: str, namespace: str) -> bool:
    """Return ``True`` if a tunnel session is running for this cluster."""
    state = load_tunnel_state(cluster_name, namespace)
    if state is None:
        return False
    if all(_pid_alive(pid) for pid in state.pids):
        return True
    # Some processes died — clean up the stale state
    stop_tunnels(cluster_name, namespace)
    return False


def _resolve_kube_settings(
    kubeconfig: str | None, context: str | None = None
) -> tuple[str | None, str | None]:
    """Resolve kubeconfig and context from krayne settings when neither is explicit.

    When the caller supplies either value, the supplied values are used
    verbatim (the settings file is not consulted — the caller is
    asserting a specific target).  Otherwise, ``~/.krayne/config.yaml``
    is read and validated by :func:`load_krayne_settings`.
    """
    if kubeconfig is not None or context is not None:
        return kubeconfig, context
    from krayne.config.settings import load_krayne_settings

    settings = load_krayne_settings()
    return settings.kubeconfig, settings.kube_context


def start_tunnels(
    cluster_name: str,
    namespace: str,
    services: list[str],
    *,
    kubeconfig: str | None = None,
    context: str | None = None,
) -> list[TunnelInfo]:
    """Start ``kubectl port-forward`` processes for each service.

    Port-forwards to the head Service (``svc/{cluster_name}-head-svc``).
    Processes are daemonised (detached).  State is persisted to disk so
    that :func:`stop_tunnels` can clean up later.

    When *kubeconfig* and *context* are not supplied, both are loaded
    from ``~/.krayne/config.yaml`` and passed through as
    ``--kubeconfig`` and ``--context`` flags, so the subprocess targets
    the same cluster as the in-process Kubernetes client.

    **Idempotent** — if a tunnel is already active for this cluster the
    existing tunnel info is returned without spawning new processes.
    """
    if is_tunnel_active(cluster_name, namespace):
        state = load_tunnel_state(cluster_name, namespace)
        assert state is not None  # guarded by is_tunnel_active
        return state.tunnels

    kubeconfig, context = _resolve_kube_settings(kubeconfig, context)
    svc_target = f"svc/{cluster_name}-head-svc"
    tunnels: list[TunnelInfo] = []
    pids: list[int] = []

    for service in services:
        if service not in SERVICE_PORTS:
            continue
        remote_port, scheme = SERVICE_PORTS[service]
        lport = local_port_for(cluster_name, namespace, service)

        cmd = [
            "kubectl", "port-forward",
            "-n", namespace,
            svc_target,
            f"{lport}:{remote_port}",
        ]
        if kubeconfig:
            cmd.extend(["--kubeconfig", kubeconfig])
        if context:
            cmd.extend(["--context", context])

        proc = subprocess.Popen(
            cmd,
            # stdin must be redirected too — otherwise kubectl inherits the
            # parent's controlling TTY and breaks Textual's alt-screen / mouse
            # tracking, leaking escape sequences as visible characters.
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            # Detach from parent so the tunnel survives CLI exit
            start_new_session=True,
        )
        pids.append(proc.pid)

        local_url = f"{scheme}://localhost:{lport}"
        tunnels.append(TunnelInfo(
            service=service,
            remote_port=remote_port,
            local_port=lport,
            local_url=local_url,
        ))

    state = TunnelState(
        cluster_name=cluster_name,
        namespace=namespace,
        tunnels=tunnels,
        pids=pids,
    )
    _save_tunnel_state(state)
    return tunnels


def stop_tunnel_service(cluster_name: str, namespace: str, service: str) -> bool:
    """Stop the tunnel for a single service, leaving others running.

    Returns ``True`` if the service tunnel was found and stopped,
    ``False`` otherwise.
    """
    state = load_tunnel_state(cluster_name, namespace)
    if state is None:
        return False

    idx = None
    for i, t in enumerate(state.tunnels):
        if t.service == service:
            idx = i
            break
    if idx is None:
        return False

    if idx < len(state.pids):
        try:
            os.kill(state.pids[idx], signal.SIGTERM)
        except OSError:
            pass

    remaining_tunnels = [t for i, t in enumerate(state.tunnels) if i != idx]
    remaining_pids = [p for i, p in enumerate(state.pids) if i != idx]

    if not remaining_tunnels:
        # No tunnels left — clean up entirely
        _remove_tunnel_state(cluster_name, namespace)
    else:
        new_state = TunnelState(
            cluster_name=cluster_name,
            namespace=namespace,
            tunnels=remaining_tunnels,
            pids=remaining_pids,
        )
        _save_tunnel_state(new_state)
    return True


def stop_tunnels(cluster_name: str, namespace: str) -> bool:
    """Terminate all port-forward processes for a tunnel session.

    **Idempotent** — returns ``True`` if a tunnel was stopped,
    ``False`` if no tunnel was active.
    """
    state = load_tunnel_state(cluster_name, namespace)
    if state is None:
        _remove_tunnel_state(cluster_name, namespace)
        return False

    for pid in state.pids:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass  # already dead

    _remove_tunnel_state(cluster_name, namespace)
    return True
