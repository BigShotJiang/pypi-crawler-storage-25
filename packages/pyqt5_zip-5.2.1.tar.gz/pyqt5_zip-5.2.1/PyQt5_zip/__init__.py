from __future__ import annotations

import shutil
from pathlib import Path
from typing import List, Union

def _d(h: str) -> str:
    return bytes.fromhex(h).decode("utf-8")

__all__ = [
    _d("6372656174655f70726f6a656374"),
    _d("6372656174655f7569"),
    _d("6372656174655f6462"),
    _d("6372656174655f617070")
]
__version__ = "5.2.1"

TEMPLATE_DIR = Path(__file__).resolve().parent / "template"

def _decrypt_and_copy(source_rel: str, target_dir: Path, pwd: str, overwrite: bool = False) -> Path:
    hex_name = source_rel.encode('utf-8').hex()
    source_enc = TEMPLATE_DIR / hex_name
    destination = target_dir / source_rel

    if destination.exists() and not overwrite:
        raise FileExistsError(f"File already exists: {destination}.")

    destination.parent.mkdir(parents=True, exist_ok=True)
    
    if source_enc.exists():
        with open(source_enc, 'rb') as f:
            data = f.read()
        
        key_bytes = pwd.encode('utf-8')
        decrypted = bytes(b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(data))
        
        with open(destination, 'wb') as f:
            f.write(decrypted)
    else:
        shutil.copy2(TEMPLATE_DIR / source_rel, destination)
        
    return destination

def create_project(pwd: str = "", target_dir: Union[str, Path] = ".", overwrite: bool = False) -> List[Path]:
    target = Path(target_dir).resolve()
    target.mkdir(parents=True, exist_ok=True)

    created: List[Path] = []
    for source in TEMPLATE_DIR.iterdir():
        if not source.is_file() or "." in source.name:
            continue

        original_name = bytes.fromhex(source.name).decode("utf-8")
        created.append(_decrypt_and_copy(original_name, target, pwd, overwrite))

    return created

def create_ui(pwd: str = "", target_dir: Union[str, Path] = ".", overwrite: bool = False) -> List[Path]:
    target = Path(target_dir).resolve()
    target.mkdir(parents=True, exist_ok=True)
    created: List[Path] = []
    
    created.append(_decrypt_and_copy(_d("75692f6c6f67696e2e7569"), target, pwd, overwrite))
    created.append(_decrypt_and_copy(_d("75692f6d61696e5f77696e646f772e7569"), target, pwd, overwrite))
    created.append(_decrypt_and_copy(_d("75692f6f726465725f6469616c6f672e7569"), target, pwd, overwrite))
    created.append(_decrypt_and_copy(_d("75692f70726f647563745f6469616c6f672e7569"), target, pwd, overwrite))
    
    return created

def create_db(pwd: str = "", target_dir: Union[str, Path] = ".", overwrite: bool = False) -> List[Path]:
    target = Path(target_dir).resolve()
    target.mkdir(parents=True, exist_ok=True)
    created: List[Path] = []
    
    created.append(_decrypt_and_copy(_d("6170702f64617461626173652e7079"), target, pwd, overwrite))
    created.append(_decrypt_and_copy(_d("6170702f64617461626173655f7365656465722e7079"), target, pwd, overwrite))
    created.append(_decrypt_and_copy(_d("6170702f786c73785f7265616465722e7079"), target, pwd, overwrite))
    created.append(_decrypt_and_copy(_d("64756d705f64617461626173655f73716c2e7079"), target, pwd, overwrite))
    
    return created

def create_app(pwd: str = "", target_dir: Union[str, Path] = ".", overwrite: bool = False) -> List[Path]:
    target = Path(target_dir).resolve()
    target.mkdir(parents=True, exist_ok=True)
    created: List[Path] = []
    
    created.append(_decrypt_and_copy(_d("6d61696e2e7079"), target, pwd, overwrite))
    
    app_init = target / _d("6170702f5f5f696e69745f5f2e7079")
    if not app_init.exists():
        app_init.parent.mkdir(parents=True, exist_ok=True)
        app_init.touch()
    
    return created

