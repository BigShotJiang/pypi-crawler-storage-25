from __future__ import annotations

import argparse

from . import create_project


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="PyQt5_zip",
        description="Create the PyQt/SQLite shoe shop project in a target folder.",
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=".",
        help="Target folder. Defaults to the current directory.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Replace existing files in the target folder.",
    )
    args = parser.parse_args()

    files = create_project(args.target, overwrite=args.overwrite)
    print(f"Created {len(files)} files in {args.target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
