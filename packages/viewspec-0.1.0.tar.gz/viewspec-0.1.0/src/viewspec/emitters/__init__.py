"""ViewSpec emitter plugins."""
