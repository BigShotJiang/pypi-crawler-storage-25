def load1_2():
    """Вывод кода статистики и отчёта в консоль."""
    text = """# Вывод статистики
total, false_cnt = len(all_files), len(false_files)
valid_cnt = total - false_cnt
pct = (false_cnt / total * 100) if total else 0.0
print(f"\\nВсего обработано: {total}\\nВалидных изображений: {valid_cnt}")
print(f"Ложных изображений: {false_cnt} ({pct:.1f}%)\\nПеремещено файлов: {false_cnt}")

# Формирование отчета
now = datetime.now()
doc = Document()

# базовый стиль
ns = doc.styles["Normal"]
ns.font.name, ns.font.size = "Times New Roman", Pt(12)


def add(txt, style_key=None, font="Times New Roman", sz=12, align=None):
    p = doc.add_paragraph()
    if style_key and style_key in doc.styles:
        p.style = doc.styles[style_key]
    if align:
        p.alignment = align  
    r = p.add_run(txt) 
    r.font.name, r.font.size = font, Pt(sz)
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)


# стили
add("Отчёт о проверке изображений", "Title", "Calibri", 26, WD_ALIGN_PARAGRAPH.CENTER)
add(f"Дата: {now.strftime('%d.%m.%Y %H:%M:%S')}")


add("Результаты анализа", "Heading 1", "Calibri", 14)
for n, t in all_files:
    add(f"Файл: {n}, Тип файла: {t}")

add("Статистика", "Heading 1", "Calibri", 14)
add(f"Всего обработано: {total}")
add(f"Валидных изображений: {valid_cnt}")
add(f"Ложных изображений: {false_cnt} ({pct:.1f}%)")

add("Перемещённые файлы", "Heading 1", "Calibri", 14)
for n, t in false_files:
    add(f"Файл: {n}, Тип файла: {t} — причина: неверный формат")


# сохранение
report_name = f"Task1_{now.strftime('%d%m%Y_%H%M%S')}.docx"
doc.save(os.path.join(os.getcwd(), report_name))
print(f"Отчёт сохранён: {report_name}")"""
    print(text)