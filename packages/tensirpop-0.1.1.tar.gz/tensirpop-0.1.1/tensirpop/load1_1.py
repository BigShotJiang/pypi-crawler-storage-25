def load1_1():
    """Вывод кода проверки изображений в консоль."""
    text = """import os, sys, shutil
from datetime import datetime
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

# сигнатуры
SIGS = {
    b"\\xff\\xd8\\xff": "JPEG",
    b"\\x89PNG\\r\\n\\x1a\\n": "PNG",
    b"BM": "BMP",
    b"GIF87a": "GIF87a",
    b"GIF89a": "GIF89a",
    b"II*\\x00": "TIFF",
    b"MM\\x00*": "TIFF",
    b"RIFF": "WEBP",
}
READ_LEN = max(len(s) for s in SIGS)
EXT_OK = {".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tiff", ".webp"}

folder = input("Введите путь к папке: ").strip().strip('"')
# if not os.path.isdir(folder):
#    sys.exit("Ошибка: папка не найдена.")

dec_path = os.path.join(os.getcwd(), "deception")
os.makedirs(dec_path, exist_ok=True)
all_files, false_files = [], []


# Чтение файлов
def get_type(path):
    with open(path, "rb") as f:
        hdr = f.read(READ_LEN)
    for sig, ftype in SIGS.items():
        if hdr.startswith(sig):
            return ftype
    return "UNKNOWN"


for fname in os.listdir(folder):
    if os.path.splitext(fname)[1].lower() not in EXT_OK:
        continue
    fpath = os.path.join(folder, fname)
    if not os.path.isfile(fpath):
        continue

    rtype = get_type(fpath)
    print(f"Файл: {fname}, Тип файла: {rtype}")
    all_files.append((fname, rtype))

    if rtype != "JPEG":
        false_files.append((fname, rtype))
        shutil.move(fpath, os.path.join(dec_path, fname))
"""
    print(text)