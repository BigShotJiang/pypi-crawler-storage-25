def load5_2():
    """Вывод кода отчёта классификации в консоль."""
    text = """# отчет
doc = Document()


def add_p(
    doc, text, size=12, font="Times New Roman", bold=False, align=None, style=None
):
    p = doc.add_paragraph()
    if style:
        try:
            p.style = doc.styles[style]
        except:
            pass
    run = p.add_run(text)
    run.font.name = font
    run.font.size = Pt(size)
    run.bold = bold
    if align:
        p.alignment = align

    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    return p


add_p(
    doc,
    "Отчет о классификации изображений",
    26,
    "Calibri",
    True,
    WD_ALIGN_PARAGRAPH.CENTER,
    style="Title",
)
add_p(doc, f"Дата и время генерации: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}")
add_p(
    doc,
    f"Всего обработано изображений: {len(results)}",
    14,
    "Calibri",
    True,
    style="Heading 1",
)
add_p(
    doc, "Статистика распределения по классам:", 14, "Calibri", True, style="Heading 1"
)

stats = {c: 0 for c in CLASSES + ["Error"]}
for _, c, _ in results:
    stats[c] += 1
for c, cnt in stats.items():
    if cnt:
        add_p(doc, f"{c}: {cnt} изображений ({cnt/len(results)*100:.1f}%)")

err_cnt = stats["Error"]
add_p(
    doc,
    f"Изображений с низкой уверенностью (<80%): {err_cnt} ({err_cnt/len(results)*100:.1f}%)",
)
add_p(
    doc,
    "Детальная информация по каждому изображению:",
    14,
    "Calibri",
    True,
    style="Heading 1",
)

for n, c, conf in results:
    add_p(doc, f"{n} – перемещен в: {c} (уверенность: {conf*100:.2f}%)")

doc.save(os.path.join(WORK, "classification_report.docx"))
print("\\n Отчет сохранен: classification_report.docx")"""
    print(text)