def load3_2():
    """Вывод кода компиляции и обучения модели в консоль."""
    text = """# Компиляция и обучение
model.compile(
    optimizer="adam",
    loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
    metrics=["accuracy"],
)
history = model.fit(train_ds, validation_data=val_ds, epochs=40)

# точность и потери
acc, val_acc = history.history["accuracy"], history.history["val_accuracy"]
loss, val_loss = history.history["loss"], history.history["val_loss"]
epochs_range = range(40)

# Создание графиков
os.makedirs("plots", exist_ok=True)
plt.figure(figsize=(8, 8))
plt.subplot(1, 2, 1)
plt.plot(epochs_range, acc, label="Точность обучения")
plt.plot(epochs_range, val_acc, label="Точность валидации")
plt.legend(loc="lower right")
plt.title("Точность обучения")
plt.subplot(1, 2, 2)
plt.plot(epochs_range, loss, label="Ошибка обучения")
plt.plot(epochs_range, val_loss, label="Ошибка валидации")
plt.legend(loc="upper right")
plt.title("Отображение потерь")
plt.savefig("plots/Task3_plots.png", dpi=100, bbox_inches="tight")
plt.show()

# Сохранение модели
model.save("Task3.hdf5")
print("Модель сохранена 'Task3.hdf5'")"""
    print(text)