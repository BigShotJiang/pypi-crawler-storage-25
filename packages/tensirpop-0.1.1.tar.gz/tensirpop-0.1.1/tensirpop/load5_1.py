def load5_1():
    """Вывод кода классификации изображений в консоль."""
    text = """import os, shutil
import tensorflow as tf
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from datetime import datetime

# пути
SRC = r"C:\Users\Miha\Desktop\Testo\Expert"
DST = r"C:\Users\Miha\Desktop\Testo\ISA"
WORK = r"C:\Users\Miha\Desktop\Testo"
CLASSES = ["chicken", "cows", "geese"]
MODEL_PATH = r"C:\Users\Testo\Task3.hdf5"

# создание папок
os.makedirs(DST, exist_ok=True)
for folder in CLASSES + ["Error"]:
    os.makedirs(os.path.join(DST, folder), exist_ok=True)

# загрузка модели
model = tf.keras.models.load_model(MODEL_PATH)

# работа с файлами
results = []
files = [f for f in os.listdir(SRC) if f.lower().endswith((".jpg", ".jpeg", ".png"))]
TARGET_SIZE = (180, 180)

for i, fname in enumerate(files, 1):
    src_path = os.path.join(SRC, fname)
    img = tf.keras.utils.load_img(src_path, target_size=TARGET_SIZE)
    x = tf.keras.utils.img_to_array(img)

    raw_preds = model.predict(tf.expand_dims(x, 0), verbose=0)[0]
    probs = (
        tf.nn.softmax(raw_preds).numpy()
        if abs(raw_preds.sum() - 1.0) > 0.01
        else raw_preds
    )

    conf = float(probs.max())
    cls = CLASSES[probs.argmax()]

    if conf < 0.8:
        cls, new_name = "Error", f"Error_{i}{os.path.splitext(fname)[1]}"
    else:
        new_name = f"{cls}_{i}{os.path.splitext(fname)[1]}"

    shutil.move(src_path, os.path.join(DST, cls, new_name))
    print(f"{fname} – перемещен в: {cls} (уверенность: {conf*100:.2f}%)")
    results.append((new_name, cls, conf))"""
    print(text)