"""tensirpop - библиотека для вывода примеров кода."""

__version__ = "0.1.1"
__author__ = "Your Name"

from .load1_1 import load1_1
from .load1_2 import load1_2
from .load3_1 import load3_1
from .load3_2 import load3_2
from .load4_1 import load4_1
from .load4_2 import load4_2
from .load5_1 import load5_1
from .load5_2 import load5_2

__all__ = [
    'load1_1',
    'load1_2',
    'load3_1',
    'load3_2',
    'load4_1',
    'load4_2',
    'load5_1',
    'load5_2'
]