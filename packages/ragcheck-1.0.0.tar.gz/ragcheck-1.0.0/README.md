# ragcheck

This package has been renamed to **evalsystem**.

```
pip install evalsystem
```

Then use it exactly as before:

```python
import evalops
result = evalops.evaluate(...)
```

See the full documentation at https://github.com/AarushSharmaa/evalops
