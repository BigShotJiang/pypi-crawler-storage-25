import warnings

warnings.warn(
    "ragcheck has been renamed to evalsystem. "
    "Please upgrade: pip install evalsystem\n"
    "The new package is a drop-in replacement: import evalops works the same way.",
    DeprecationWarning,
    stacklevel=2,
)
