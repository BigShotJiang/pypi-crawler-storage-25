#!/usr/bin/env python3
"""Optometry AI Safety MCP Server — FDA SaMD + CE marking for ophthalmic devices."""

import sys, os
sys.path.insert(0, os.path.expanduser('~/clawd/meok-labs-engine/shared'))
from auth_middleware import check_access

import json, hashlib
from datetime import datetime, timezone
from collections import defaultdict
from mcp.server.fastmcp import FastMCP

FREE_DAILY_LIMIT = 15
_usage = defaultdict(list)
def _rl(c="anon"):
    now = datetime.now(timezone.utc)
    _usage[c] = [t for t in _usage[c] if (now-t).total_seconds() < 86400]
    if len(_usage[c]) >= FREE_DAILY_LIMIT: return json.dumps({"error": f"Limit {FREE_DAILY_LIMIT}/day"})
    _usage[c].append(now); return None

mcp = FastMCP("optometry-ai-safety", instructions="MEOK AI Labs — FDA SaMD + CE marking compliance for ophthalmic AI devices.")

RISK_CATEGORIES = {
    "screening": {"eu_class": "Class IIa", "fda_class": "Class II", "risk": "moderate"},
    "diagnosis": {"eu_class": "Class IIb", "fda_class": "Class II", "risk": "significant"},
    "surgical_planning": {"eu_class": "Class III", "fda_class": "Class III", "risk": "high"},
    "monitoring": {"eu_class": "Class IIa", "fda_class": "Class II", "risk": "moderate"},
    "triage": {"eu_class": "Class IIa", "fda_class": "Class II", "risk": "moderate"},
    "treatment_recommendation": {"eu_class": "Class IIb", "fda_class": "Class III", "risk": "significant"},
    "image_analysis": {"eu_class": "Class IIa", "fda_class": "Class II", "risk": "moderate"},
    "predictive": {"eu_class": "Class IIb", "fda_class": "Class II", "risk": "significant"},
}

REQUIREMENTS = {
    "Class IIa": ["clinical_evaluation", "biocompatibility_if_contact", "software_lifecycle_iec62304",
                   "usability_study_iec62366", "risk_management_iso14971", "quality_management_iso13485"],
    "Class IIb": ["clinical_trial", "post_market_surveillance", "risk_management_iso14971",
                   "software_lifecycle_iec62304", "usability_study_iec62366", "quality_management_iso13485",
                   "notified_body_review", "performance_evaluation"],
    "Class III": ["pivotal_clinical_trial", "notified_body_audit", "risk_management_iso14971",
                   "software_lifecycle_iec62304", "usability_study_iec62366", "quality_management_iso13485",
                   "post_market_clinical_followup", "design_examination"],
}

FDA_PATHWAYS = {
    "Class I": {"pathway": "510(k) Exempt", "timeline_months": 3, "clinical_data": False},
    "Class II": {"pathway": "510(k) or De Novo", "timeline_months": 12, "clinical_data": "Sometimes"},
    "Class III": {"pathway": "PMA (Pre-Market Approval)", "timeline_months": 24, "clinical_data": True},
}

OPHTHALMIC_CONDITIONS = [
    "diabetic_retinopathy", "glaucoma", "age_related_macular_degeneration",
    "cataracts", "keratoconus", "retinal_detachment", "myopia_progression",
    "dry_eye_disease", "optic_neuritis", "corneal_dystrophy",
]

DEMOGRAPHIC_DIMENSIONS = ["age_range", "ethnicities", "sex_distribution",
                           "geographic_regions", "comorbidities", "severity_levels"]


@mcp.tool()
def classify_optometry_device(intended_use: str, device_name: str = "",
                               ai_autonomy_level: str = "assistive", api_key: str = "") -> str:
    """Classify an optometry AI device under EU MDR and FDA risk categories with detailed pathway guidance.

    Behavior:
        This tool is read-only and stateless — it produces analysis output
        without modifying any external systems, databases, or files.
        Safe to call repeatedly with identical inputs (idempotent).
        Free tier: 10/day rate limit. Pro tier: unlimited.
        No authentication required for basic usage.

    When to use:
        Use this tool when you need structured analysis or classification
        of inputs against established frameworks or standards.

    When NOT to use:
        Not suitable for real-time production decision-making without
        human review of results.

    Args:
        intended_use (str): The intended use to analyze or process.
        device_name (str): The device name to analyze or process.
        ai_autonomy_level (str): The ai autonomy level to analyze or process.
        api_key (str): The api key to analyze or process.

    Behavioral Transparency:
        - Side Effects: This tool is read-only and produces no side effects. It does not modify
          any external state, databases, or files. All output is computed in-memory and returned
          directly to the caller.
        - Authentication: No authentication required for basic usage. Pro/Enterprise tiers
          require a valid MEOK API key passed via the MEOK_API_KEY environment variable.
        - Rate Limits: Free tier: 10 calls/day. Pro tier: unlimited. Rate limit headers are
          included in responses (X-RateLimit-Remaining, X-RateLimit-Reset).
        - Error Handling: Returns structured error objects with 'error' key on failure.
          Never raises unhandled exceptions. Invalid inputs return descriptive validation errors.
        - Idempotency: Fully idempotent — calling with the same inputs always produces the
          same output. Safe to retry on timeout or transient failure.
        - Data Privacy: No input data is stored, logged, or transmitted to external services.
          All processing happens locally within the MCP server process.
    """
    allowed, msg, tier = check_access(api_key)
    if not allowed:
        return {"error": msg, "upgrade_url": "https://meok.ai/pricing"}
    if err := _rl(): return err

    use_lower = intended_use.lower().strip()
    category = RISK_CATEGORIES.get(use_lower)
    if not category:
        for key in RISK_CATEGORIES:
            if key in use_lower:
                category = RISK_CATEGORIES[key]
                break
    if not category:
        category = {"eu_class": "Unknown", "fda_class": "Unknown", "risk": "undetermined"}

    eu_class = category["eu_class"]
    fda_class = category["fda_class"]
    reqs = REQUIREMENTS.get(eu_class, [])
    fda_info = FDA_PATHWAYS.get(fda_class, {})

    if ai_autonomy_level == "autonomous":
        eu_class_bump = {"Class IIa": "Class IIb", "Class IIb": "Class III"}.get(eu_class, eu_class)
        if eu_class_bump != eu_class:
            reqs = REQUIREMENTS.get(eu_class_bump, reqs)
            eu_class = eu_class_bump

    ref_id = hashlib.sha256(f"{device_name}{intended_use}{datetime.now(timezone.utc).isoformat()}".encode()).hexdigest()[:12]
    return {
        "reference_id": ref_id,
        "device_name": device_name or "Unnamed Device",
        "intended_use": intended_use,
        "ai_autonomy_level": ai_autonomy_level,
        "eu_mdr": {"risk_class": eu_class, "requirements": reqs, "notified_body_required": eu_class in ("Class IIb", "Class III")},
        "fda": {"risk_class": fda_class, "pathway": fda_info.get("pathway", "Consult FDA"), "timeline_months": fda_info.get("timeline_months", 0), "clinical_data_required": fda_info.get("clinical_data", True)},
        "risk_level": category["risk"],
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@mcp.tool()
def check_fda_samd(device_function: str, clinical_situation: str = "non-serious",
                    information_type: str = "inform", api_key: str = "") -> str:
    """Check FDA Software as Medical Device (SaMD) classification using the IMDRF framework matrix.

    Behavior:
        This tool is read-only and stateless — it produces analysis output
        without modifying any external systems, databases, or files.
        Safe to call repeatedly with identical inputs (idempotent).
        Free tier: 10/day rate limit. Pro tier: unlimited.
        No authentication required for basic usage.

    When to use:
        Use this tool when you need structured analysis or classification
        of inputs against established frameworks or standards.

    When NOT to use:
        Not suitable for real-time production decision-making without
        human review of results.

    Args:
        device_function (str): The device function to analyze or process.
        clinical_situation (str): The clinical situation to analyze or process.
        information_type (str): The information type to analyze or process.
        api_key (str): The api key to analyze or process.

    Behavioral Transparency:
        - Side Effects: This tool is read-only and produces no side effects. It does not modify
          any external state, databases, or files. All output is computed in-memory and returned
          directly to the caller.
        - Authentication: No authentication required for basic usage. Pro/Enterprise tiers
          require a valid MEOK API key passed via the MEOK_API_KEY environment variable.
        - Rate Limits: Free tier: 10 calls/day. Pro tier: unlimited. Rate limit headers are
          included in responses (X-RateLimit-Remaining, X-RateLimit-Reset).
        - Error Handling: Returns structured error objects with 'error' key on failure.
          Never raises unhandled exceptions. Invalid inputs return descriptive validation errors.
        - Idempotency: Fully idempotent — calling with the same inputs always produces the
          same output. Safe to retry on timeout or transient failure.
        - Data Privacy: No input data is stored, logged, or transmitted to external services.
          All processing happens locally within the MCP server process.
    """
    allowed, msg, tier = check_access(api_key)
    if not allowed:
        return {"error": msg, "upgrade_url": "https://meok.ai/pricing"}
    if err := _rl(): return err

    situation_map = {"critical": 3, "serious": 2, "non-serious": 1}
    info_map = {"treat_or_diagnose": 3, "drive_clinical_management": 2, "inform": 1}
    sit_score = situation_map.get(clinical_situation.lower(), 1)
    info_score = info_map.get(information_type.lower(), 1)
    combined = sit_score + info_score

    if combined >= 5:
        level, pathway, risk = "IV", "PMA", "Very High"
    elif combined == 4:
        level, pathway, risk = "III", "De Novo or 510(k)", "High"
    elif combined == 3:
        level, pathway, risk = "II", "510(k)", "Moderate"
    else:
        level, pathway, risk = "I", "510(k) Exempt", "Low"

    predicate_needed = level in ("II", "III")
    special_controls = level in ("II", "III", "IV")

    return {
        "device_function": device_function,
        "clinical_situation": clinical_situation,
        "information_type": information_type,
        "samd_category": level,
        "risk_level": risk,
        "recommended_pathway": pathway,
        "predicate_device_needed": predicate_needed,
        "special_controls_required": special_controls,
        "documentation": ["software_description", "risk_analysis", "software_requirements",
                          "architecture_design", "verification_validation"] + (["clinical_evidence"] if level in ("III", "IV") else []),
        "estimated_review_months": {"I": 3, "II": 6, "III": 12, "IV": 18}.get(level, 12),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@mcp.tool()
def ce_marking_checklist(risk_class: str, device_type: str = "software",
                          has_clinical_data: bool = False, api_key: str = "") -> str:
    """Generate a detailed CE marking compliance checklist for optometry devices under EU MDR 2017/745.

    Behavior:
        This tool generates structured output without modifying external systems.
        Output is deterministic for identical inputs. No side effects.
        Free tier: 10/day rate limit. Pro tier: unlimited.
        No authentication required for basic usage.

    When to use:
        Use this tool when you need structured analysis or classification
        of inputs against established frameworks or standards.

    When NOT to use:
        Not suitable for real-time production decision-making without
        human review of results.

    Args:
        risk_class (str): The risk class to analyze or process.
        device_type (str): The device type to analyze or process.
        has_clinical_data (bool): The has clinical data to analyze or process.
        api_key (str): The api key to analyze or process.

    Behavioral Transparency:
        - Side Effects: This tool is read-only and produces no side effects. It does not modify
          any external state, databases, or files. All output is computed in-memory and returned
          directly to the caller.
        - Authentication: No authentication required for basic usage. Pro/Enterprise tiers
          require a valid MEOK API key passed via the MEOK_API_KEY environment variable.
        - Rate Limits: Free tier: 10 calls/day. Pro tier: unlimited. Rate limit headers are
          included in responses (X-RateLimit-Remaining, X-RateLimit-Reset).
        - Error Handling: Returns structured error objects with 'error' key on failure.
          Never raises unhandled exceptions. Invalid inputs return descriptive validation errors.
        - Idempotency: Fully idempotent — calling with the same inputs always produces the
          same output. Safe to retry on timeout or transient failure.
        - Data Privacy: No input data is stored, logged, or transmitted to external services.
          All processing happens locally within the MCP server process.
    """
    allowed, msg, tier = check_access(api_key)
    if not allowed:
        return {"error": msg, "upgrade_url": "https://meok.ai/pricing"}
    if err := _rl(): return err

    base_docs = REQUIREMENTS.get(risk_class, [])
    checklist = []
    for doc in base_docs:
        checklist.append({"requirement": doc, "status": "pending", "mandatory": True,
                          "standard": _get_standard(doc)})

    general_items = [
        {"requirement": "technical_documentation", "status": "pending", "mandatory": True, "standard": "MDR Annex II"},
        {"requirement": "declaration_of_conformity", "status": "pending", "mandatory": True, "standard": "MDR Annex IV"},
        {"requirement": "udi_registration", "status": "pending", "mandatory": True, "standard": "MDR Article 27"},
        {"requirement": "eudamed_registration", "status": "pending", "mandatory": True, "standard": "MDR Article 29"},
        {"requirement": "post_market_surveillance_plan", "status": "pending", "mandatory": True, "standard": "MDR Article 84"},
    ]
    if device_type == "software":
        general_items.append({"requirement": "cybersecurity_assessment", "status": "pending", "mandatory": True, "standard": "MDCG 2019-16"})
        general_items.append({"requirement": "algorithm_validation", "status": "pending", "mandatory": True, "standard": "IEC 62304"})

    checklist.extend(general_items)
    completed = sum(1 for item in checklist if item["status"] == "completed")
    return {
        "risk_class": risk_class,
        "device_type": device_type,
        "checklist": checklist,
        "total_items": len(checklist),
        "completed": completed,
        "completion_pct": round(completed / len(checklist) * 100, 1) if checklist else 0,
        "estimated_months": {"Class IIa": 6, "Class IIb": 12, "Class III": 18}.get(risk_class, 12),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def _get_standard(requirement: str) -> str:
    standards = {
        "clinical_evaluation": "MEDDEV 2.7/1 Rev 4",
        "clinical_trial": "ISO 14155",
        "pivotal_clinical_trial": "ISO 14155",
        "risk_management": "ISO 14971:2019",
        "risk_management_iso14971": "ISO 14971:2019",
        "software_lifecycle": "IEC 62304:2006+A1",
        "software_lifecycle_iec62304": "IEC 62304:2006+A1",
        "usability_study": "IEC 62366-1:2015",
        "usability_study_iec62366": "IEC 62366-1:2015",
        "quality_management_iso13485": "ISO 13485:2016",
        "post_market_surveillance": "MDR Article 83",
        "biocompatibility_if_contact": "ISO 10993",
        "notified_body_review": "MDR Annex IX",
        "notified_body_audit": "MDR Annex IX",
        "performance_evaluation": "MDR Annex XIV",
    }
    return standards.get(requirement, "EU MDR 2017/745")


@mcp.tool()
def ophthalmic_bias_audit(datasets: list, target_condition: str = "",
                           min_ethnicities: int = 5, min_age_groups: int = 4,
                           api_key: str = "") -> str:
    """Audit ophthalmic AI datasets for demographic bias across age, ethnicity, sex, and disease conditions.

    Behavior:
        This tool is read-only and stateless — it produces analysis output
        without modifying any external systems, databases, or files.
        Safe to call repeatedly with identical inputs (idempotent).
        Free tier: 10/day rate limit. Pro tier: unlimited.
        No authentication required for basic usage.

    When to use:
        Use this tool when you need structured analysis or classification
        of inputs against established frameworks or standards.

    When NOT to use:
        Not suitable for real-time production decision-making without
        human review of results.

    Args:
        datasets (list): The datasets to analyze or process.
        target_condition (str): The target condition to analyze or process.
        min_ethnicities (int): The min ethnicities to analyze or process.
        min_age_groups (int): The min age groups to analyze or process.
        api_key (str): The api key to analyze or process.

    Behavioral Transparency:
        - Side Effects: This tool is read-only and produces no side effects. It does not modify
          any external state, databases, or files. All output is computed in-memory and returned
          directly to the caller.
        - Authentication: No authentication required for basic usage. Pro/Enterprise tiers
          require a valid MEOK API key passed via the MEOK_API_KEY environment variable.
        - Rate Limits: Free tier: 10 calls/day. Pro tier: unlimited. Rate limit headers are
          included in responses (X-RateLimit-Remaining, X-RateLimit-Reset).
        - Error Handling: Returns structured error objects with 'error' key on failure.
          Never raises unhandled exceptions. Invalid inputs return descriptive validation errors.
        - Idempotency: Fully idempotent — calling with the same inputs always produces the
          same output. Safe to retry on timeout or transient failure.
        - Data Privacy: No input data is stored, logged, or transmitted to external services.
          All processing happens locally within the MCP server process.
    """
    allowed, msg, tier = check_access(api_key)
    if not allowed:
        return {"error": msg, "upgrade_url": "https://meok.ai/pricing"}
    if err := _rl(): return err

    issues = []
    warnings = []
    dataset_reports = []

    for i, d in enumerate(datasets):
        name = d.get("name", f"dataset_{i}")
        report = {"name": name, "issues": [], "warnings": []}

        age_range = d.get("age_range", "")
        if not age_range:
            report["issues"].append("Missing age range data — risk of age bias")
        elif isinstance(age_range, str) and "-" in age_range:
            parts = age_range.split("-")
            try:
                low, high = int(parts[0]), int(parts[1])
                if low > 30:
                    report["warnings"].append(f"Age range starts at {low} — pediatric underrepresented")
                if high < 70:
                    report["warnings"].append(f"Age range ends at {high} — elderly underrepresented")
            except ValueError:
                pass

        eth_count = d.get("ethnicities", 0)
        if isinstance(eth_count, int) and eth_count < min_ethnicities:
            report["issues"].append(f"Only {eth_count} ethnic groups (minimum {min_ethnicities}) — diversity gap")

        sample_size = d.get("sample_size", 0)
        if sample_size and sample_size < 500:
            report["warnings"].append(f"Small sample size ({sample_size}) — may not be statistically significant")
        if sample_size and sample_size < 100:
            report["issues"].append(f"Very small sample ({sample_size}) — insufficient for clinical validation")

        sex_ratio = d.get("sex_ratio", "")
        if not sex_ratio:
            report["warnings"].append("No sex distribution data provided")

        conditions = d.get("conditions", [])
        if target_condition and target_condition not in conditions:
            report["warnings"].append(f"Target condition '{target_condition}' not explicitly listed")

        if d.get("geographic_regions", 0) and d["geographic_regions"] < 3:
            report["warnings"].append("Limited geographic diversity")

        issues.extend(report["issues"])
        warnings.extend(report["warnings"])
        dataset_reports.append(report)

    risk_score = min(100, len(issues) * 20 + len(warnings) * 5)
    risk_level = "low" if risk_score < 25 else "moderate" if risk_score < 50 else "high" if risk_score < 75 else "critical"

    return {
        "datasets_checked": len(datasets),
        "target_condition": target_condition or "general",
        "dataset_reports": dataset_reports,
        "total_issues": len(issues),
        "total_warnings": len(warnings),
        "risk_score": risk_score,
        "risk_level": risk_level,
        "pass": len(issues) == 0,
        "recommendations": _bias_recommendations(issues, warnings),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def _bias_recommendations(issues: list, warnings: list) -> list:
    recs = []
    issue_text = " ".join(issues).lower()
    if "ethnic" in issue_text or "diversity" in issue_text:
        recs.append("Include datasets from diverse populations (min 5 ethnic groups per FDA guidance)")
    if "age" in issue_text or "pediatric" in " ".join(warnings).lower():
        recs.append("Expand age range to include pediatric (0-17) and geriatric (65+) populations")
    if "sample" in issue_text:
        recs.append("Increase sample size to minimum 500 for each demographic subgroup")
    if "geographic" in " ".join(warnings).lower():
        recs.append("Include data from at least 3 geographic regions to reduce population bias")
    if not recs:
        recs.append("Dataset diversity appears adequate — continue monitoring for distribution shifts")
    return recs


if __name__ == "__main__":
    mcp.run()
