#!/usr/bin/env python3
"""Smoke-test prepare_indico_pages and prepare_indico_nav without live API or real data."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    import requests as _requests_available
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from atlasdocs_theme.scripts.prepare_indico_pages import (
    build_search_index,
    create_indico_pages,
    is_descendant_of,
    _generate_meetings_page,
)
from atlasdocs_theme.scripts.prepare_indico_nav import create_indico_nav, render_nav


# ── is_descendant_of ───────────────────────────────────────────────────────────

class TestIsDescendantOf(unittest.TestCase):
    def setUp(self):
        # Simple tree: root → parent → child → grandchild
        self.meta = {
            "1": {"parent_id": None},
            "2": {"parent_id": "1"},
            "3": {"parent_id": "2"},
            "4": {"parent_id": "3"},
        }

    def test_direct_child(self):
        self.assertTrue(is_descendant_of("3", "2", self.meta))

    def test_grandchild(self):
        self.assertTrue(is_descendant_of("4", "1", self.meta))

    def test_non_descendant(self):
        self.assertFalse(is_descendant_of("2", "3", self.meta))

    def test_self_is_not_descendant(self):
        self.assertFalse(is_descendant_of("2", "2", self.meta))


# ── build_search_index ────────────────────────────────────────────────────────

class TestBuildSearchIndex(unittest.TestCase):
    def _make_events(self):
        return [
            {
                "title": "Workshop on Physics",
                "url": "https://indico.cern.ch/e/1",
                "date": "2025-04-01",
                "contributions": [
                    {
                        "title": "Opening Talk",
                        "url": "https://indico.cern.ch/c/1",
                        "speakers": [{"fullName": "Alice Smith", "affiliation": "CERN"}],
                    }
                ],
            }
        ]

    def test_records_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "events.json")
            dst = os.path.join(tmp, "search.json")
            with open(src, "w") as f:
                json.dump(self._make_events(), f)
            count = build_search_index(src, dst)
            self.assertGreater(count, 0)
            with open(dst) as f:
                records = json.load(f)
            types = {r["type"] for r in records}
            self.assertIn("event", types)
            self.assertIn("contribution", types)
            self.assertIn("speaker", types)

    def test_missing_src_returns_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            count = build_search_index("/no/such/file.json", os.path.join(tmp, "out.json"))
            self.assertEqual(count, 0)


# ── _generate_meetings_page ───────────────────────────────────────────────────

class TestGenerateMeetingsPage(unittest.TestCase):
    def _categories(self):
        return [
            {"id": "100", "label": "B-tagging"},
            {"id": "200", "label": "Higgs Physics"},
        ]

    def test_creates_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "docs", "meetings.md")
            _generate_meetings_page(self._categories(), out)
            self.assertTrue(os.path.exists(out))

    def test_contains_all_category_labels(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "docs", "meetings.md")
            _generate_meetings_page(self._categories(), out)
            content = Path(out).read_text()
            self.assertIn("B-tagging", content)
            self.assertIn("Higgs Physics", content)

    def test_links_to_category_pages(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "docs", "meetings.md")
            _generate_meetings_page(self._categories(), out)
            content = Path(out).read_text()
            self.assertIn("category/100/", content)
            self.assertIn("category/200/", content)

    def test_empty_categories_still_creates_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "docs", "meetings.md")
            _generate_meetings_page([], out)
            self.assertTrue(os.path.exists(out))

    def test_has_grid_cards_wrapper(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "docs", "meetings.md")
            _generate_meetings_page(self._categories(), out)
            content = Path(out).read_text()
            self.assertIn("grid cards", content)


# ── create_indico_pages (dry run) ─────────────────────────────────────────────

@unittest.skipUnless(HAS_REQUESTS, "requests not installed")
class TestLookupCategoryName(unittest.TestCase):
    def test_returns_title_from_api(self):
        from unittest.mock import MagicMock, patch
        from atlasdocs_theme.scripts.prepare_indico_pages import _lookup_category_name

        fake_response = MagicMock()
        fake_response.json.return_value = {"id": 42, "title": "B-tagging"}

        with patch(
            "atlasdocs_theme.scripts.indicoapi.indicorequests.requests.get",
            return_value=fake_response,
        ):
            name = _lookup_category_name("42", site="https://indico.cern.ch", api_token="tok")
        self.assertEqual(name, "B-tagging")

    def test_returns_none_on_error(self):
        from unittest.mock import patch
        from atlasdocs_theme.scripts.prepare_indico_pages import _lookup_category_name

        with patch(
            "atlasdocs_theme.scripts.indicoapi.indicorequests.requests.get",
            side_effect=ConnectionError("unreachable"),
        ):
            name = _lookup_category_name("42", site="https://indico.cern.ch", api_token="tok")
        self.assertIsNone(name)


class TestCreateIndicoPagesNoHierarchy(unittest.TestCase):
    def test_no_hierarchy_still_generates_pages(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp)
            cat_id = "777"
            data_dir = hub / "data/indico/category" / cat_id
            data_dir.mkdir(parents=True)
            events = [{"title": "No-hier Event", "date": "2025-05-01", "url": "", "contributions": []}]
            (data_dir / f"category_{cat_id}.json").write_text(json.dumps(events))

            create_indico_pages(hub_dir=str(hub))
            index = hub / "docs/category" / cat_id / "index.md"
            self.assertTrue(index.exists(), "index.md should be generated without hierarchy")

    def test_meetings_page_generated(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp)
            cat_id = "777"
            data_dir = hub / "data/indico/category" / cat_id
            data_dir.mkdir(parents=True)
            events = [{"title": "Event", "date": "2025-05-01", "url": "", "contributions": []}]
            (data_dir / f"category_{cat_id}.json").write_text(json.dumps(events))

            create_indico_pages(hub_dir=str(hub))
            meetings = hub / "docs/meetings.md"
            self.assertTrue(meetings.exists(), "meetings.md should be generated")

    @unittest.skipUnless(HAS_REQUESTS, "requests not installed")
    def test_no_hierarchy_uses_api_name(self):
        from unittest.mock import MagicMock, patch
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp)
            cat_id = "888"
            data_dir = hub / "data/indico/category" / cat_id
            data_dir.mkdir(parents=True)
            events = [{"title": "Meeting", "date": "2025-05-01", "url": "", "contributions": []}]
            (data_dir / f"category_{cat_id}.json").write_text(json.dumps(events))

            fake_response = MagicMock()
            fake_response.json.return_value = {"id": int(cat_id), "title": "B-tagging"}

            with patch(
                "atlasdocs_theme.scripts.indicoapi.indicorequests.requests.get",
                return_value=fake_response,
            ):
                create_indico_pages(hub_dir=str(hub), api_token="tok")

            content = (hub / "docs/category" / cat_id / "index.md").read_text()
            self.assertIn("B-tagging", content)


class TestCreateIndicoPagesLeaf(unittest.TestCase):
    def _make_hub(self, tmp):
        hub = Path(tmp)
        cat_id = "999"
        data_dir = hub / "data/indico/category" / cat_id
        data_dir.mkdir(parents=True)
        events = [{"title": "Test Event", "date": "2025-05-01", "url": "https://x.com", "contributions": []}]
        (data_dir / f"category_{cat_id}.json").write_text(json.dumps(events))

        hier_dir = hub / "commontools/indico/indicoapi/data"
        hier_dir.mkdir(parents=True)
        hierarchy = {
            "categories": [
                {"category_id": cat_id, "name": "Test Category", "parent_id": None,
                 "immediate_children": [], "all_descendants": []}
            ]
        }
        (hier_dir / "all_categories_enhanced.json").write_text(json.dumps(hierarchy))
        return hub, cat_id

    def test_index_md_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub, cat_id = self._make_hub(tmp)
            create_indico_pages(hub_dir=str(hub))
            index = hub / "docs/category" / cat_id / "index.md"
            self.assertTrue(index.exists(), f"Expected {index} to exist")
            content = index.read_text()
            self.assertIn("indico-meetings", content)
            self.assertIn(cat_id, content)

    def test_search_json_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub, cat_id = self._make_hub(tmp)
            create_indico_pages(hub_dir=str(hub))
            search = hub / "docs/category" / cat_id / f"category_{cat_id}_search.json"
            self.assertTrue(search.exists())

    def test_meetings_md_includes_category_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub, cat_id = self._make_hub(tmp)
            create_indico_pages(hub_dir=str(hub))
            meetings = hub / "docs/meetings.md"
            self.assertTrue(meetings.exists())
            content = meetings.read_text()
            self.assertIn("Test Category", content)


# ── render_nav ────────────────────────────────────────────────────────────────

class TestRenderNav(unittest.TestCase):
    def _sections(self):
        return [
            ("Home", [
                ("Home", "index.md"),
                ("Contacts", "contacts.md"),
            ]),
            ("Meetings", [
                ("Meetings", "meetings.md"),
                ("B-tagging", "category/1/index.md"),
            ]),
        ]

    def test_output_starts_with_nav(self):
        out = render_nav(self._sections())
        self.assertTrue(out.startswith("nav = ["))

    def test_home_section_present(self):
        out = render_nav(self._sections())
        self.assertIn('"Home"', out)
        self.assertIn("index.md", out)

    def test_meetings_section_present(self):
        out = render_nav(self._sections())
        self.assertIn('"Meetings"', out)
        self.assertIn("meetings.md", out)

    def test_category_entry_present(self):
        out = render_nav(self._sections())
        self.assertIn('"B-tagging"', out)
        self.assertIn("category/1/index.md", out)

    def test_nested_entries_rendered(self):
        sections = [("Home", [
            ("Resources", [
                ("Item", "item.md"),
            ]),
        ])]
        out = render_nav(sections)
        self.assertIn('"Resources"', out)
        self.assertIn("item.md", out)


# ── create_indico_nav (dry run) ───────────────────────────────────────────────

class TestCreateIndicoNavNoConfig(unittest.TestCase):
    def test_missing_indico_toml_exits_gracefully(self):
        with tempfile.TemporaryDirectory() as tmp:
            create_indico_nav(hub_dir=tmp)  # no indico.toml → no output, no crash


class TestCreateIndicoNavWithData(unittest.TestCase):
    def _make_hub(self, tmp, cat_id="999", label="B-tagging"):
        hub = Path(tmp)
        # indico.toml
        toml = f'[[categories]]\nid = {cat_id}\nlabel = "{label}"\n'
        (hub / "indico.toml").write_text(toml)
        # Generated docs page
        docs_dir = hub / "docs/category" / cat_id
        docs_dir.mkdir(parents=True)
        (docs_dir / "index.md").write_text("---\n---\n")
        return hub

    def test_nav_toml_generated(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub = self._make_hub(tmp)
            create_indico_nav(hub_dir=str(hub))
            out_file = hub / "config/zensical/nav-indico.toml"
            self.assertTrue(out_file.exists())

    def test_nav_contains_meetings_hub(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub = self._make_hub(tmp)
            create_indico_nav(hub_dir=str(hub))
            content = (hub / "config/zensical/nav-indico.toml").read_text()
            self.assertIn("meetings.md", content)

    def test_nav_contains_category_label(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub = self._make_hub(tmp, cat_id="999", label="B-tagging")
            create_indico_nav(hub_dir=str(hub))
            content = (hub / "config/zensical/nav-indico.toml").read_text()
            self.assertIn("B-tagging", content)
            self.assertIn("category/999/index.md", content)

    def test_category_without_docs_page_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp)
            toml = "[[categories]]\nid = 123\nlabel = \"Missing\"\n"
            (hub / "indico.toml").write_text(toml)
            # No docs/category/123/index.md created
            create_indico_nav(hub_dir=str(hub))
            out_file = hub / "config/zensical/nav-indico.toml"
            # File is still created (meetings.md entry always present)
            self.assertTrue(out_file.exists())
            content = out_file.read_text()
            self.assertNotIn("category/123/index.md", content)

    def test_config_order_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            hub = Path(tmp)
            toml = (
                "[[categories]]\nid = 1\nlabel = \"Zebra\"\n\n"
                "[[categories]]\nid = 2\nlabel = \"Apple\"\n"
            )
            (hub / "indico.toml").write_text(toml)
            for cat_id in ["1", "2"]:
                d = hub / "docs/category" / cat_id
                d.mkdir(parents=True)
                (d / "index.md").write_text("---\n---\n")
            create_indico_nav(hub_dir=str(hub))
            content = (hub / "config/zensical/nav-indico.toml").read_text()
            self.assertLess(content.index("Zebra"), content.index("Apple"))


if __name__ == "__main__":
    result = unittest.main(verbosity=2, exit=False)
    sys.exit(0 if result.result.wasSuccessful() else 1)
