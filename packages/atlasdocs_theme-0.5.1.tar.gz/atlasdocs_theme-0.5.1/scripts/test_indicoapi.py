#!/usr/bin/env python3
"""Smoke-test indicoapi data models and indicorequests helpers (no live API calls)."""
import os
import sys
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent.parent))

try:
    import requests as _req
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


@unittest.skipUnless(HAS_REQUESTS, "requests not installed")
class TestBearerAuth(unittest.TestCase):
    def test_token_added_to_header(self):
        from atlasdocs_theme.scripts.indicoapi.indicorequests import BearerAuth
        req = MagicMock()
        req.headers = {}
        auth = BearerAuth("my-secret-token")
        auth(req)
        self.assertEqual(req.headers["authorization"], "Bearer my-secret-token")


@unittest.skipUnless(HAS_REQUESTS, "requests not installed")
class TestUserAgent(unittest.TestCase):
    def test_default_user_agent(self):
        import importlib
        import atlasdocs_theme.scripts.indicoapi.indicorequests as mod
        self.assertIn("indicomb-atlasdocs", mod.HEADERS["User-Agent"])
        self.assertIn("gitlab.cern.ch", mod.HEADERS["User-Agent"])

    def test_ci_job_url_included_when_set(self):
        with patch.dict(os.environ, {"CI_JOB_URL": "https://gitlab.cern.ch/jobs/42"}):
            import importlib
            import atlasdocs_theme.scripts.indicoapi.indicorequests as mod
            importlib.reload(mod)
            self.assertIn("42", mod.HEADERS["User-Agent"])
        # reload without CI_JOB_URL to restore default state
        with patch.dict(os.environ, {}, clear=True):
            importlib.reload(mod)


@unittest.skipUnless(HAS_REQUESTS, "requests not installed")
class TestPageSizeConstants(unittest.TestCase):
    def test_page_sizes_are_positive(self):
        from atlasdocs_theme.scripts.indicoapi.indicorequests import (
            CONTRIBUTIONS_PAGE_SIZE,
            EVENTS_PAGE_SIZE,
            ICAL_PAGE_SIZE,
            SESSIONS_PAGE_SIZE,
            SUBCONTRIBUTIONS_PAGE_SIZE,
        )
        for name, val in [
            ("EVENTS_PAGE_SIZE", EVENTS_PAGE_SIZE),
            ("CONTRIBUTIONS_PAGE_SIZE", CONTRIBUTIONS_PAGE_SIZE),
            ("SUBCONTRIBUTIONS_PAGE_SIZE", SUBCONTRIBUTIONS_PAGE_SIZE),
            ("SESSIONS_PAGE_SIZE", SESSIONS_PAGE_SIZE),
            ("ICAL_PAGE_SIZE", ICAL_PAGE_SIZE),
        ]:
            with self.subTest(name):
                self.assertGreater(val, 0)


class TestCategory(unittest.TestCase):
    def test_url_built_from_base(self):
        from atlasdocs_theme.scripts.indicoapi.category import INDICO_BASE_URL, Category
        cat = Category(category_id="123", name="Test", num_events=5)
        self.assertEqual(cat.url, f"{INDICO_BASE_URL}/category/123/")

    def test_explicit_url_not_overwritten(self):
        from atlasdocs_theme.scripts.indicoapi.category import Category
        cat = Category(category_id="123", name="Test", num_events=5, url="https://custom/")
        self.assertEqual(cat.url, "https://custom/")

    def test_immediate_children_defaults_to_empty_list(self):
        from atlasdocs_theme.scripts.indicoapi.category import Category
        cat = Category(category_id="1", name="X", num_events=0)
        self.assertEqual(cat.immediate_children, [])


class TestEvent(unittest.TestCase):
    def test_sort_newest_first(self):
        from atlasdocs_theme.scripts.indicoapi.event import Event
        older = Event(url="", date="2024-01-01", title="Old", contributions=[])
        newer = Event(url="", date="2025-06-01", title="New", contributions=[])
        self.assertLess(newer, older)  # __lt__ sorts newest first


class TestContribution(unittest.TestCase):
    def test_defaults(self):
        from atlasdocs_theme.scripts.indicoapi.contribution import Contribution
        c = Contribution(title="My Talk", url="https://indico.cern.ch/event/1")
        self.assertEqual(c.speakers, [])
        self.assertIsNone(c.minutes)
        self.assertEqual(c.attachments, [])


@unittest.skipUnless(HAS_REQUESTS, "requests not installed")
class TestBuildRequest(unittest.TestCase):
    def test_params_sorted_and_url_constructed(self):
        from atlasdocs_theme.scripts.indicoapi.indicorequests import build_request

        captured = {}

        def fake_get(url, auth=None, headers=None):
            captured["url"] = url
            resp = MagicMock()
            resp.apparent_encoding = "utf-8"
            resp.json.return_value = {"results": ["event1"]}
            return resp

        with patch("atlasdocs_theme.scripts.indicoapi.indicorequests.requests.get", fake_get):
            result = build_request(
                site="https://indico.cern.ch",
                url="/export/categ/42.json",
                params={"to": "2025-12-31", "from": "2025-01-01", "limit": 500},
                api_token="tok",
            )

        self.assertEqual(result, ["event1"])
        # params must be sorted alphabetically by key
        self.assertIn("from=2025-01-01", captured["url"])
        idx_from = captured["url"].index("from=")
        idx_limit = captured["url"].index("limit=")
        idx_to = captured["url"].index("to=")
        self.assertLess(idx_from, idx_limit)
        self.assertLess(idx_limit, idx_to)


if __name__ == "__main__":
    result = unittest.main(verbosity=2, exit=False)
    sys.exit(0 if result.result.wasSuccessful() else 1)
