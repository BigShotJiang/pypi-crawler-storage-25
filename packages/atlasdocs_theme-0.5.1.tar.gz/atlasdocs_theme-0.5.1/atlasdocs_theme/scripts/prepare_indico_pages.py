from __future__ import annotations

import glob
import json
import os
import shutil
import tomllib
from pathlib import Path


# ── Configuration ──────────────────────────────────────────────────────────────

# Config file read from the hub root to determine which categories to process
INDICO_CONFIG_FILE = "indico.toml"

# Input: fetched category JSON files (one sub-folder per category)
DATA_DIR = "data/indico/category"

# Input: Indico category hierarchy (all_categories_enhanced.json) — optional
HIERARCHY_FILE = "commontools/indico/indicoapi/data/all_categories_enhanced.json"

# Output: generated MkDocs category pages
DOCS_OUTPUT_DIR = "docs/category"

# Output: meetings hub page that links to all configured categories
MEETINGS_PAGE = "docs/meetings.md"

# Ancestor IDs whose entire sub-trees are skipped during generation
EXCLUDE_ANCESTOR_IDS: list[str] = ["6869"]  # National and Institute Meetings

# Frontmatter written into every generated index.md
PAGE_ICON = "lucide/briefcase"
PAGE_STATUS = "script"
PAGE_SHOW_ACTIONS = False
PAGE_TAGS_BASE = ['"★ INDICOMB"']


# ── Config loading ─────────────────────────────────────────────────────────────

def load_indico_config(hub_dir: str = ".") -> list[dict]:
    """Load indico.toml and return the categories list: [{id, label}, ...]."""
    config_path = Path(hub_dir) / INDICO_CONFIG_FILE
    if not config_path.exists():
        return []
    with open(config_path, "rb") as f:
        data = tomllib.load(f)
    return [{"id": str(c["id"]), "label": c.get("label", f"Category {c['id']}")}
            for c in data.get("categories", [])]


# ── Fetch helpers ──────────────────────────────────────────────────────────────

def _normalize_name(raw: str) -> str:
    """Convert 'Last, First Middle' → 'First Middle Last'."""
    if not raw:
        return ""
    raw = raw.strip()
    if "," in raw:
        last, _, rest = raw.partition(",")
        return f"{rest.strip()} {last.strip()}"
    return raw


def _name_variants(full_name: str) -> list[str]:
    parts = full_name.split()
    if not parts:
        return []
    if len(parts) == 1:
        return parts
    return list({parts[0], f"{parts[0]} {parts[-1]}", full_name})


def is_descendant_of(cat_id: str, ancestor_id: str, category_metadata: dict) -> bool:
    current_id = str(cat_id)
    ancestor_id_str = str(ancestor_id)
    visited: set[str] = set()
    while current_id and current_id in category_metadata:
        if current_id in visited:
            break
        visited.add(current_id)
        parent_id = category_metadata[current_id].get("parent_id")
        if not parent_id:
            break
        parent_id_str = str(parent_id)
        if parent_id_str == ancestor_id_str:
            return True
        current_id = parent_id_str
    return False


def build_search_index(src_json_path: str, dst_json_path: str) -> int:
    """Build a flat Fuse.js-ready search index from a category JSON file.

    Records: speaker {name, variants, affiliation, event_title, event_url, date},
             event   {title, url, date},
             contribution {title, url, event_title, event_url, date}.
    """
    if not os.path.exists(src_json_path):
        return 0
    with open(src_json_path) as f:
        events = json.load(f)

    records: list[dict] = []
    for ev in events:
        if not ev.get("date"):
            continue
        event_title = ev.get("title", "")
        event_url = ev.get("url", "")
        date = ev.get("date", "")
        records.append({"type": "event", "title": event_title, "url": event_url, "date": date})

        seen_speakers: dict[str, dict] = {}
        for contrib in ev.get("contributions", []):
            contrib_title = contrib.get("title", "")
            contrib_url = contrib.get("url", "")
            if contrib_title:
                records.append({
                    "type": "contribution",
                    "title": contrib_title,
                    "url": contrib_url,
                    "event_title": event_title,
                    "event_url": event_url,
                    "date": date,
                })
            for sp in contrib.get("speakers", []):
                raw = sp.get("fullName") or f"{sp.get('first_name', '')} {sp.get('last_name', '')}".strip()
                full_name = _normalize_name(raw)
                if not full_name or full_name in seen_speakers:
                    continue
                seen_speakers[full_name] = {
                    "type": "speaker",
                    "name": full_name,
                    "variants": _name_variants(full_name),
                    "affiliation": sp.get("affiliation", ""),
                    "event_title": event_title,
                    "event_url": event_url,
                    "date": date,
                }
        records.extend(seen_speakers.values())

    with open(dst_json_path, "w") as f:
        json.dump(records, f, separators=(",", ":"))
    return len(records)


# ── Prepare ────────────────────────────────────────────────────────────────────

def _lookup_category_name(cat_id: str, site: str, api_token: str) -> str | None:
    """Return the category title from the Indico REST API, or None on failure."""
    try:
        from atlasdocs_theme.scripts.indicoapi.indicorequests import request_category_info
        info = request_category_info(cat_id, site=site, api_token=api_token)
        return info.get("title") or info.get("name")
    except Exception:
        return None


def create_indico_pages(
    hub_dir: str = ".",
    data_dir: str | None = None,
    hierarchy_file: str | None = None,
    docs_output_dir: str | None = None,
    api_token: str | None = None,
    site: str = "https://indico.cern.ch",
) -> None:
    """Generate MkDocs pages for fetched Indico category JSON files.

    Category names and selection come from indico.toml when present.
    When no hierarchy file is present, names are resolved via the Indico REST
    API if *api_token* is supplied, otherwise they fall back to "Category {id}".
    Writes docs/meetings.md as a hub page linking to all configured categories.
    """
    if api_token is None:
        api_token = os.environ.get("INDICO_API_TOKEN")

    hub = Path(hub_dir)
    data_dir = str(hub / (data_dir or DATA_DIR))
    hierarchy_file = str(hub / (hierarchy_file or HIERARCHY_FILE))
    docs_output_dir = str(hub / (docs_output_dir or DOCS_OUTPUT_DIR))
    meetings_page = str(hub / MEETINGS_PAGE)

    # Labels from indico.toml take priority over everything else
    config_cats = load_indico_config(hub_dir)
    config_labels: dict[str, str] = {c["id"]: c["label"] for c in config_cats}
    config_ids: set[str] | None = set(config_labels) if config_cats else None

    category_metadata: dict = {}
    if os.path.exists(hierarchy_file):
        with open(hierarchy_file) as f:
            hierarchy_data = json.load(f)
        category_metadata = {str(c["category_id"]): c for c in hierarchy_data["categories"]}
    elif not config_ids:
        token_status = "API token available — names will be resolved" if api_token else "no API token — titles will default to 'Category {id}'"
        print(f"[INFO] No hierarchy file and no indico.toml — generating all found categories ({token_status}).")

    category_json_files = glob.glob(os.path.join(data_dir, "**/category_*.json"), recursive=True)
    print(f"[INFO] Found {len(category_json_files)} category JSON files in {data_dir}")

    os.makedirs(docs_output_dir, exist_ok=True)

    generated_cats: list[dict] = []  # [{id, label}] for meetings.md
    skipped = generated = 0

    for json_file in category_json_files:
        try:
            cat_id = os.path.basename(json_file).replace("category_", "").replace(".json", "")

            # If indico.toml lists specific categories, skip anything not in it
            if config_ids is not None and cat_id not in config_ids:
                skipped += 1
                continue

            meta = category_metadata.get(cat_id, {})

            # Skip descendants of excluded ancestors (only when hierarchy available)
            if category_metadata and any(
                is_descendant_of(cat_id, excl, category_metadata)
                for excl in EXCLUDE_ANCESTOR_IDS
            ):
                skipped += 1
                continue

            # Skip parent categories (those with children listed in hierarchy)
            if meta.get("immediate_children"):
                continue

            # Name resolution: config label → hierarchy → API → fallback
            raw_name = (
                config_labels.get(cat_id)
                or meta.get("name")
            )
            if not raw_name and api_token:
                raw_name = _lookup_category_name(cat_id, site=site, api_token=api_token)
                if raw_name:
                    print(f"[INFO] Resolved name for {cat_id}: {raw_name}")
            category_name = (raw_name or f"Category {cat_id}").replace(">", "&gt;")

            cat_output_dir = os.path.join(docs_output_dir, cat_id)
            _generate_leaf_category(
                output_dir=cat_output_dir,
                cat_id=cat_id,
                data_dir=data_dir,
                custom_title=f'"{category_name}"',
                custom_tags=list(PAGE_TAGS_BASE),
                indico_url=f'"https://indico.cern.ch/category/{cat_id}/"',
            )
            generated_cats.append({"id": cat_id, "label": category_name})
            generated += 1

        except Exception as e:
            print(f"[ERROR] Failed to process {json_file}: {e}")

    # Generate the meetings hub page
    # Use config order when available, otherwise alphabetical
    if config_cats:
        ordered = [c for c in config_cats if c["id"] in {g["id"] for g in generated_cats}]
    else:
        ordered = sorted(generated_cats, key=lambda c: c["label"].lower())
    _generate_meetings_page(ordered, meetings_page)

    print(f"[FINISH] Generated {generated} category pages (skipped {skipped}).")


# ── Postprocess ────────────────────────────────────────────────────────────────

def _generate_frontmatter(
    title: str,
    tags: list[str] | None = None,
    contact_email: str | None = None,
) -> str:
    lines = [
        "---",
        f"title: {title}",
        f"icon: {PAGE_ICON}",
    ]
    if contact_email:
        lines.append(f"contact_email: {contact_email}")
    lines.append("")
    lines.append(f"showactions: {str(PAGE_SHOW_ACTIONS).lower()}")
    if tags:
        lines.append("tags:")
        for tag in tags:
            lines.append(f"  - {tag}")
    lines.append("")
    lines.append("---\n")
    return "\n".join(lines)


def _generate_leaf_category(
    output_dir: str,
    cat_id: str,
    data_dir: str,
    custom_title: str | None = None,
    custom_tags: list[str] | None = None,
    indico_url: str | None = None,
) -> None:
    os.makedirs(output_dir, exist_ok=True)

    src_json = os.path.join(data_dir, cat_id, f"category_{cat_id}.json")
    dst_json = os.path.join(output_dir, f"category_{cat_id}.json")
    if os.path.exists(src_json):
        shutil.copy2(src_json, dst_json)

    num_meetings = 0
    if os.path.exists(src_json):
        with open(src_json) as f:
            try:
                num_meetings = sum(1 for ev in json.load(f) if ev.get("date"))
            except Exception:
                pass

    dst_search = os.path.join(output_dir, f"category_{cat_id}_search.json")
    build_search_index(src_json, dst_search)

    frontmatter = _generate_frontmatter(
        title=custom_title or f'"Category {cat_id}"',
        tags=custom_tags,
        contact_email=indico_url,
    )
    md = [
        frontmatter,
        "",
        f'<div id="indico-meetings" data-json="./category_{cat_id}.json"></div>',
        '<script src="/assets/javascripts/indico_category_loader.js"></script>',
        "",
    ]
    with open(os.path.join(output_dir, "index.md"), "w") as f:
        f.write("\n".join(md))

    print(f"[DONE] {output_dir}/index.md — {num_meetings} meetings.")


def _generate_meetings_page(categories: list[dict], output_path: str) -> None:
    """Write docs/meetings.md as a hub page with grid cards for each category."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    lines = [
        "---",
        'title: "Meetings"',
        f"icon: {PAGE_ICON}",
        "",
        f"showactions: {str(PAGE_SHOW_ACTIONS).lower()}",
        "",
        "---",
        "",
        '<div class="grid cards" markdown>',
        "",
    ]

    for cat in categories:
        cat_id = cat["id"]
        label = cat["label"]
        lines += [
            f"-   **[{label}](category/{cat_id}/)**",
            "",
            f"    ---",
            "",
            f"    [:lucide-calendar: Browse meetings](category/{cat_id}/)",
            "",
        ]

    lines += ["</div>", ""]

    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    print(f"[DONE] {output_path} — {len(categories)} categories.")


def main() -> None:
    import sys
    hub_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
    create_indico_pages(hub_dir=str(hub_dir))


if __name__ == "__main__":
    main()
