"""Pre-cache git commit history for all docs/ files.

Reads the existing .git_history_cache.json (source-repo histories written by
import_docs), runs the hub's git log, merges the two, and writes the result
back to .git_history_cache.json.

Run after combine-docs so that the complete merged history is available to
directory-page generation and the build plugin.

Usage:
    python -m atlasdocs_theme.scripts.prepare_git_history [hub_dir]
"""

from __future__ import annotations

import sys
from pathlib import Path

from .fetch_git_history import DEFAULT_CACHE_FILE, LocalGitHistoryProvider


def main() -> None:
    hub_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()

    provider = LocalGitHistoryProvider(
        cache_file=hub_dir / DEFAULT_CACHE_FILE.name,
        docs_dir="docs",
        repo_root=str(hub_dir),
    )
    provider.load(docs_dir="docs", repo_root=str(hub_dir))
    provider.save_cache(hub_dir / DEFAULT_CACHE_FILE.name)


if __name__ == "__main__":
    main()
