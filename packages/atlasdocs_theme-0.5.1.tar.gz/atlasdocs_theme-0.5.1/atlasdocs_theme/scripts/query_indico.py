from __future__ import annotations

"""
Live-query Indico meetings from one or more categories. Output is tabular or iCal.
Does not write any files — useful for debugging or one-off lookups.

Usage examples
--------------
All meetings from a category:
    python -m atlasdocs_theme.scripts.query_indico --category 499

Multiple categories combined:
    python -m atlasdocs_theme.scripts.query_indico --category 499 --category 1234

Filter by title keyword (OR logic):
    python -m atlasdocs_theme.scripts.query_indico --category 499 --include atlas

Exclude a keyword:
    python -m atlasdocs_theme.scripts.query_indico --category 499 --exclude trigger

Filter by speaker:
    python -m atlasdocs_theme.scripts.query_indico --category 499 --author "Jason Oliver"

Dump combined iCal:
    python -m atlasdocs_theme.scripts.query_indico --category 499 --ical

Diagnose missing speaker data:
    python -m atlasdocs_theme.scripts.query_indico --category 499 --debug-speakers

Pixi (pass extra args after --):
    pixi run query-indico -- --category 499 --include atlas
"""

import argparse
import json
import os
import sys


# ── Configuration ──────────────────────────────────────────────────────────────

INDICO_SITE = "https://indico.cern.ch"
DEFAULT_YEARS = 1


# ── Fetch ──────────────────────────────────────────────────────────────────────

def _speaker_name(s) -> str:
    if isinstance(s, dict):
        return s.get("fullName") or s.get("full_name") or ""
    return str(s)


def _print_meetings(meetings, author_tokens: list[str] | None = None) -> None:
    rows = []
    for m in meetings:
        authors = []
        for c in m.contributions:
            for s in (c.speakers or []):
                name = _speaker_name(s)
                if not name:
                    continue
                if author_tokens:
                    if all(t in name.lower() for t in author_tokens) and name not in authors:
                        authors.append(name)
                elif name not in authors:
                    authors.append(name)
        rows.append((m.date, m.title, ", ".join(authors), m.url or ""))

    if not rows:
        return

    col_widths = [max(len(r[i]) for r in rows) for i in range(3)]
    for date, title, authors, url in rows:
        print(f"{date:<{col_widths[0]}}  {title:<{col_widths[1]}}  {authors:<{col_widths[2]}}  {url}")


def _debug_speakers(indico) -> None:
    seen = []
    for event in indico.events:
        for contrib in event.get("contributions", []):
            for field in ("speakers", "person_links"):
                for person in contrib.get(field, []):
                    if person not in seen:
                        seen.append(person)

    if not seen:
        print("No speaker records found in any contribution.")
        print("The API may not return speaker data at detail=contributions for this category.")
        return

    print(json.dumps(seen, indent=2))


# ── Main ───────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Live-query Indico meetings (no files written).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__.split("Usage examples")[1] if __doc__ and "Usage examples" in __doc__ else "",
    )
    parser.add_argument(
        "--category", "-c",
        metavar="ID",
        action="append",
        required=True,
        help="Category ID to query (repeat for multiple: -c 499 -c 1234)",
    )
    parser.add_argument("--token", help="Indico API token (default: $INDICO_API_TOKEN)")
    parser.add_argument("--site", default=INDICO_SITE, help=f"Indico base URL (default: {INDICO_SITE})")
    parser.add_argument("--years", type=int, default=DEFAULT_YEARS, help=f"Years of history to fetch (default: {DEFAULT_YEARS})")
    parser.add_argument("--include", "-i", metavar="KEYWORD", action="append",
                        help="Only show meetings whose title contains this keyword (repeat for OR)")
    parser.add_argument("--exclude", "-x", metavar="KEYWORD", action="append",
                        help="Hide meetings whose title contains this keyword (repeat for multiple)")
    parser.add_argument("--author", "-a", metavar="NAME",
                        help="Show only meetings where this person appears as a speaker")
    parser.add_argument("--ical", action="store_true", help="Output iCal instead of tabular")
    parser.add_argument("--debug-speakers", action="store_true",
                        help="Print raw speaker records from all contributions (diagnose --author issues)")

    args = parser.parse_args()

    api_token = args.token or os.environ.get("INDICO_API_TOKEN")
    if not api_token:
        parser.error("API token required: use --token or set INDICO_API_TOKEN")

    from .indicoapi.indico import Indico

    category_ids = [int(c) for c in args.category]
    indico = Indico(
        category_id=category_ids,
        api_token=api_token,
        site=args.site,
        years=args.years,
    )

    if args.debug_speakers:
        _debug_speakers(indico)
        return

    if args.ical:
        print(indico.get_ical())
        return

    if args.author:
        meetings = indico.get_meetings_for_author(args.author)
        author_tokens = args.author.lower().split()
    else:
        meetings = indico.get_meetings(include=args.include, exclude=args.exclude)
        author_tokens = None

    print(f"API calls: {indico.api_call_count}  Meetings: {len(meetings)}")
    _print_meetings(meetings, author_tokens=author_tokens)


if __name__ == "__main__":
    main()
