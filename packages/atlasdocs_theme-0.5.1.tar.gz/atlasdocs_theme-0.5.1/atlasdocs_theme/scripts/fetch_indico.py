from __future__ import annotations

"""
Fetch Indico category events and save them as JSON files.

Reads which categories to fetch from indico.toml in the hub directory.
Writes one file per category:
    data/indico/category/{id}/category_{id}.json

New events are merged with any existing file (most recent event wins on URL clash).
Requires an Indico API token via --token or the INDICO_API_TOKEN env variable.

Usage examples
--------------
Fetch all categories from indico.toml (no args needed):
    python -m atlasdocs_theme.scripts.fetch_indico

Override categories from the command line:
    python -m atlasdocs_theme.scripts.fetch_indico --category 1234
    python -m atlasdocs_theme.scripts.fetch_indico --category 1234 --category 5678

Limit the date range:
    python -m atlasdocs_theme.scripts.fetch_indico --years 2
    python -m atlasdocs_theme.scripts.fetch_indico --start-date 2023-01-01

Pixi (args after --):
    pixi run fetch-indico
    pixi run fetch-indico -- --category 1234
"""

import argparse
import json
import os
import sys
import tomllib
from pathlib import Path


# ── Configuration ──────────────────────────────────────────────────────────────

INDICO_SITE = "https://indico.cern.ch"
DATA_DIR = "data/indico/category"
DEFAULT_YEARS = 2
INDICO_CONFIG_FILE = "indico.toml"


# ── Config loading ─────────────────────────────────────────────────────────────

def load_indico_config(hub_dir: str = ".") -> dict:
    """Load indico.toml. Returns {categories: [{id, label}], site, years}."""
    config_path = Path(hub_dir) / INDICO_CONFIG_FILE
    if not config_path.exists():
        return {"categories": [], "site": INDICO_SITE, "years": DEFAULT_YEARS}
    with open(config_path, "rb") as f:
        data = tomllib.load(f)
    return {
        "categories": data.get("categories", []),
        "site": data.get("site", INDICO_SITE),
        "years": int(data.get("years", DEFAULT_YEARS)),
    }


# ── Fetch ──────────────────────────────────────────────────────────────────────

def fetch_category(
    category_id: int,
    api_token: str,
    site: str = INDICO_SITE,
    years: int = DEFAULT_YEARS,
    start_date: str | None = None,
    end_date: str | None = None,
) -> list[dict]:
    from .indicoapi.indico import Indico

    indico = Indico(
        category_id=category_id,
        api_token=api_token,
        site=site,
        years=years,
        start_date=start_date,
        end_date=end_date,
    )
    meetings = indico.get_meetings(include=None, exclude=None)

    events = []
    for event in meetings:
        contributions = [
            {
                "title": c.title,
                "url": c.url,
                "speakers": c.speakers,
                "minutes": c.minutes,
                "start_time": c.start_time,
                "attachments": c.attachments,
            }
            for c in event.contributions
        ]
        events.append({
            "url": event.url,
            "date": event.date,
            "title": event.title,
            "minutes_url": event.minutes_url,
            "contributions": contributions,
        })

    print(f"[{category_id}] Fetched {len(events)} events ({indico.api_call_count} API calls)")
    return events


# ── Prepare ────────────────────────────────────────────────────────────────────

def save_category(category_id: int | str, events: list[dict], data_dir: str) -> Path:
    cat_id = str(category_id)
    out_path = Path(data_dir) / cat_id / f"category_{cat_id}.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    existing: dict[str, dict] = {}
    if out_path.exists():
        try:
            with open(out_path) as f:
                for ev in json.load(f):
                    if ev.get("url"):
                        existing[ev["url"]] = ev
        except Exception:
            pass

    n_before = len(existing)
    for ev in events:
        if ev.get("url"):
            existing[ev["url"]] = ev

    merged = sorted(existing.values(), key=lambda e: e.get("date", ""), reverse=True)
    with open(out_path, "w") as f:
        json.dump(merged, f, separators=(",", ":"))

    print(f"[{cat_id}] Saved {len(merged)} events (+{len(merged) - n_before} new) → {out_path}")
    return out_path


def fetch_indico(
    category_ids: list[int],
    api_token: str,
    site: str = INDICO_SITE,
    years: int = DEFAULT_YEARS,
    start_date: str | None = None,
    end_date: str | None = None,
    data_dir: str = DATA_DIR,
    hub_dir: str = ".",
) -> None:
    resolved_data_dir = str(Path(hub_dir) / data_dir)
    errors = []
    for cat_id in category_ids:
        try:
            events = fetch_category(
                category_id=cat_id,
                api_token=api_token,
                site=site,
                years=years,
                start_date=start_date,
                end_date=end_date,
            )
            save_category(cat_id, events, data_dir=resolved_data_dir)
        except Exception as e:
            print(f"[ERROR] category {cat_id}: {e}")
            errors.append(cat_id)

    if errors:
        print(f"[FINISH] Done with {len(errors)} error(s): {errors}")
        sys.exit(1)
    print(f"[FINISH] Fetched {len(category_ids)} categor{'y' if len(category_ids) == 1 else 'ies'}.")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fetch Indico category events and save as JSON.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__.split("Usage examples")[1] if __doc__ and "Usage examples" in __doc__ else "",
    )
    parser.add_argument(
        "--category", "-c",
        metavar="ID",
        action="append",
        type=int,
        help="Category ID to fetch (repeat for multiple: -c 1234 -c 5678). "
             "Defaults to all categories listed in indico.toml.",
    )
    parser.add_argument("--token", help="Indico API token (default: $INDICO_API_TOKEN)")
    parser.add_argument("--site", default=None, help=f"Indico base URL (default: from indico.toml or {INDICO_SITE})")
    parser.add_argument("--years", type=int, default=None, help=f"Years of history to fetch (default: from indico.toml or {DEFAULT_YEARS})")
    parser.add_argument("--start-date", metavar="YYYY-MM-DD", help="Override start date")
    parser.add_argument("--end-date",   metavar="YYYY-MM-DD", help="Override end date")
    parser.add_argument("--data-dir", default=DATA_DIR, help=f"Output directory (default: {DATA_DIR})")

    args = parser.parse_args()

    hub_dir = str(Path.cwd())
    config = load_indico_config(hub_dir)

    api_token = args.token or os.environ.get("INDICO_API_TOKEN")
    if not api_token:
        parser.error("API token required — use --token or set INDICO_API_TOKEN")

    # --category overrides config; fall back to all categories in indico.toml
    if args.category:
        category_ids = args.category
    else:
        category_ids = [int(c["id"]) for c in config["categories"]]
        if not category_ids:
            parser.error("No categories specified — pass --category or add entries to indico.toml")

    site  = args.site  or config["site"]
    years = args.years or config["years"]

    fetch_indico(
        category_ids=category_ids,
        api_token=api_token,
        site=site,
        years=years,
        start_date=args.start_date,
        end_date=args.end_date,
        data_dir=args.data_dir,
        hub_dir=hub_dir,
    )


if __name__ == "__main__":
    main()
