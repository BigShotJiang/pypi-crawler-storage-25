"""Event data model for Indico API - pure data, no rendering."""

from dataclasses import dataclass, field


@dataclass
class Event:
    """Represents an Indico event with pure data (no markdown rendering)."""

    url: str
    date: str
    title: str
    contributions: list[dict]
    time: str = None
    end_date: str = None
    end_time: str = None
    room: str = None
    location: str = None
    minutes_url: str = None
    created_dt: str = None
    event_type: str = None
    description: str = None
    chairpersons: list[dict] = field(default_factory=list)
    label: dict = None
    category: str = None
    category_id: int = None

    def __lt__(self, other):
        """Sort by date (newest first)."""
        return self.date > other.date
