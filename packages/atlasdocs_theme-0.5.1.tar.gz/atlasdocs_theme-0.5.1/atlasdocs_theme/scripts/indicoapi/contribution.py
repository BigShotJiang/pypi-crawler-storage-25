"""Contribution data model for Indico API - pure data, no rendering."""

from dataclasses import dataclass, field


@dataclass
class Contribution:
    """Represents an Indico contribution with pure data (no markdown rendering)."""

    title: str
    url: str
    speakers: list[str] = field(default_factory=list)
    minutes: dict = None
    start_time: str = None
    end_time: str = None
    duration: int = None
    attachments: list[dict] = field(default_factory=list)
    description: str = None
    keywords: list[str] = field(default_factory=list)
    contribution_type: str = None
