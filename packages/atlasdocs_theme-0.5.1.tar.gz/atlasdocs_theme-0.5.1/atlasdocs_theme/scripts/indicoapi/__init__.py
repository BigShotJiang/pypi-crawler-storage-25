from __future__ import annotations


def __getattr__(name: str):
    if name == "Category":
        from .category import Category
        return Category
    if name == "Event":
        from .event import Event
        return Event
    if name == "Contribution":
        from .contribution import Contribution
        return Contribution
    if name == "Indico":
        from .indico import Indico
        return Indico
    if name == "BearerAuth":
        from .indicorequests import BearerAuth
        return BearerAuth
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["Category", "Event", "Contribution", "Indico", "BearerAuth"]
