"""Category data model for Indico API."""

from dataclasses import dataclass

# ── Configuration ──────────────────────────────────────────────────────────────

INDICO_BASE_URL = "https://indico.cern.ch"


@dataclass
class Category:
    """Represents an Indico category."""

    category_id: str
    name: str
    num_events: int
    is_protected: bool = False
    parent_id: str = None
    url: str = None
    immediate_children: list = None

    def __post_init__(self):
        if self.immediate_children is None:
            self.immediate_children = []
        if self.url is None:
            self.url = f"{INDICO_BASE_URL}/category/{self.category_id}/"
