import os
import urllib
import urllib.parse

import requests


_ci_job_url = os.environ.get("CI_JOB_URL")
_USER_AGENT = (
    f"indicomb-atlasdocs (gitlab.cern.ch/jaoliver/indicoapi), job {_ci_job_url}"
    if _ci_job_url
    else "indicomb-atlasdocs (gitlab.cern.ch/jaoliver/indicoapi)"
)
HEADERS = {"User-Agent": _USER_AGENT}

# Per-page limits matching Indico's MAX_RECORDS for each detail level
EVENTS_PAGE_SIZE = 1000  # detail=events
CONTRIBUTIONS_PAGE_SIZE = 500  # detail=contributions
SUBCONTRIBUTIONS_PAGE_SIZE = 500  # detail=subcontributions
SESSIONS_PAGE_SIZE = 100  # detail=sessions
ICAL_PAGE_SIZE = 1000


class BearerAuth(requests.auth.AuthBase):
    def __init__(self, token: str):
        self.token = token

    def __call__(self, req):
        req.headers["authorization"] = "Bearer " + self.token
        return req


def build_request(site: str, url: str, params: dict, api_token: str):
    items = list(params.items()) if hasattr(params, "items") else list(params)
    items = sorted(items, key=lambda x: x[0].lower())
    url = f"{site}{url}?{urllib.parse.urlencode(items)}"
    response = requests.get(url, auth=BearerAuth(api_token), headers=HEADERS)
    response.encoding = response.apparent_encoding
    response.raise_for_status()
    return response.json()["results"]


def request_category(
    category_id: int,
    start_date: str,
    end_date: str,
    offset: int = 0,
    limit: int = EVENTS_PAGE_SIZE,
    **kwargs,
):
    url = f"/export/categ/{category_id}.json"
    params = {
        "from": start_date,
        "to": end_date,
        "order": "start",
        "limit": limit,
        "offset": offset,
    }
    return build_request(url=url, params=params, **kwargs)


def request_category_contributions(
    category_id: int,
    start_date: str,
    end_date: str,
    offset: int = 0,
    limit: int = CONTRIBUTIONS_PAGE_SIZE,
    **kwargs,
):
    url = f"/export/categ/{category_id}.json"
    params = {
        "from": start_date,
        "to": end_date,
        "order": "start",
        "detail": "contributions",
        "limit": limit,
        "offset": offset,
    }
    return build_request(url=url, params=params, **kwargs)


def request_category_ical(
    category_ids: list,
    start_date: str,
    end_date: str,
    offset: int = 0,
    limit: int = ICAL_PAGE_SIZE,
    **kwargs,
):
    ids = ",".join(str(i) for i in category_ids)
    url = f"/export/categ/{ids}.ics"
    params = {"from": start_date, "to": end_date, "limit": limit, "offset": offset}
    items = sorted(params.items(), key=lambda x: x[0].lower())
    full_url = f"{kwargs['site']}{url}?{urllib.parse.urlencode(items)}"
    response = requests.get(
        full_url, auth=BearerAuth(kwargs["api_token"]), headers=HEADERS
    )
    response.raise_for_status()
    return response.text


def request_event(event_id: str, **kwargs):
    """Fetch a single event with contributions embedded (returns list of one event dict)."""
    url = f"/export/event/{event_id}.json"
    params = {"detail": "contributions", "limit": CONTRIBUTIONS_PAGE_SIZE}
    return build_request(url=url, params=params, **kwargs)


def request_event_contributions(event_id: str, offset: int = 0, **kwargs):
    """Return the contributions list for a single event, paginated by offset."""
    url = f"/export/event/{event_id}.json"
    params = {
        "detail": "contributions",
        "limit": CONTRIBUTIONS_PAGE_SIZE,
        "offset": offset,
    }
    result = build_request(url=url, params=params, **kwargs)
    return result[0].get("contributions", []) if result else []


def search(query: str, start_date: str, end_date: str, **kwargs):
    url = f"/export/event/search/{query}.json"
    params = {
        "from": start_date,
        "to": end_date,
        "detail": "contributions",
        "limit": CONTRIBUTIONS_PAGE_SIZE,
    }
    return build_request(url=url, params=params, **kwargs)


def request_user(identifier: str, **kwargs):
    url = f"/export/user/{identifier}.json"
    return build_request(url=url, params={}, **kwargs)


def request_vc_rooms(event_id: str, **kwargs):
    url = f"/api/event/{event_id}/vc-room-associations/"
    return build_request(url=url, params={}, **kwargs)


def request_category_info(category_id: int | str, site: str, api_token: str) -> dict:
    """Fetch category metadata from the Indico REST API.

    Returns a dict with at least 'title' and 'id'. Returns an empty dict on
    any error so callers can fall back to a default name gracefully.

    Uses /api/categories/{id}/ (REST API), not the legacy export endpoint.
    """
    url = f"{site}/api/categories/{category_id}/"
    try:
        response = requests.get(url, auth=BearerAuth(api_token), headers=HEADERS)
        response.raise_for_status()
        return response.json()
    except Exception:
        return {}
