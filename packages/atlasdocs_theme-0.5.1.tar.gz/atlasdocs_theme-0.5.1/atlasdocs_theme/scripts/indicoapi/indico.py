import datetime
import functools
import logging
import os
import re
import time
from dataclasses import dataclass, field

from . import indicorequests as ireq
from .contribution import Contribution
from .event import Event

logging.basicConfig(format="%(asctime)s - %(message)s", level=logging.INFO)

REQUEST_DELAY = 0  # seconds between pagination calls


def _paginate(fetch_fn, page_size: int, log_prefix: str) -> tuple[list, int]:
    """Returns (results, number_of_api_calls).

    Stops when Indico returns an empty page. With detail=contributions the limit
    controls a contribution offset (not a hard cap on returned events), so pages
    routinely come back with fewer than page_size events even when more exist.
    """
    all_results, offset, page_num = [], 0, 1
    while True:
        logging.info(f"[atlasdocs] [{log_prefix}] [GET] [PAGE {page_num}]")
        t0 = time.time()
        page = fetch_fn(offset=offset)
        elapsed_ms = int((time.time() - t0) * 1000)
        n_contribs = sum(len(e.get("contributions", [])) for e in page)
        logging.info(
            f"[atlasdocs] [{log_prefix}] [GET] [PAGE {page_num}] [{elapsed_ms}ms]"
            f" {len(page)} events, {n_contribs} contributions"
        )
        all_results.extend(page)
        if not page:
            logging.info(
                f"[atlasdocs] [{log_prefix}] Done — {len(all_results)} total events"
            )
            break
        offset += page_size
        page_num += 1
        if REQUEST_DELAY > 0:
            logging.info(f"[atlasdocs] [{log_prefix}] Sleeping {REQUEST_DELAY}s...")
            time.sleep(REQUEST_DELAY)
    return all_results, page_num


@dataclass
class Indico:
    # Accepts a single int or a list of ints; always stored as category_ids list.
    category_id: int | list[int]
    api_token: str = None
    site: str = "https://indico.cern.ch"
    years: int = 1
    # Explicit date overrides — take priority over years when provided (YYYY-MM-DD).
    start_date: str | None = None
    end_date: str | None = None

    def __post_init__(self):
        if self.api_token is None:
            self.api_token = os.environ.get("INDICO_API_TOKEN", None)
        if self.api_token is None:
            msg = "Please provide an API token or set INDICO_API_TOKEN in your env"
            raise ValueError(msg)

        # Normalise to list regardless of whether a single int was supplied.
        if isinstance(self.category_id, int):
            self.category_ids: list[int] = [self.category_id]
        else:
            self.category_ids = list(self.category_id)

        self.req_kwargs = {"site": self.site, "api_token": self.api_token}

        today = datetime.datetime.now(tz=datetime.timezone.utc).date()
        if self.start_date is None:
            self.start_date = (
                today - datetime.timedelta(days=365 * self.years)
            ).strftime("%Y-%m-%d")
        if self.end_date is None:
            self.end_date = (today + datetime.timedelta(days=15)).strftime("%Y-%m-%d")

        # Legacy single-category URL points at the primary (first) category.
        self.url = f"{self.site}/category/{self.category_ids[0]}/"

        all_events: list = []
        self.api_call_count: int = 0

        for cat_id in self.category_ids:
            logging.info(
                f"[{cat_id}] Fetching from {self.start_date} "
                f"with detail=contributions (page size {ireq.CONTRIBUTIONS_PAGE_SIZE} contributions)"
            )
            fetch_fn = functools.partial(
                ireq.request_category_contributions,
                category_id=cat_id,
                start_date=self.start_date,
                end_date=self.end_date,
                limit=ireq.CONTRIBUTIONS_PAGE_SIZE,
                **self.req_kwargs,
            )
            events, calls = _paginate(
                fetch_fn=fetch_fn,
                page_size=ireq.CONTRIBUTIONS_PAGE_SIZE,
                log_prefix=str(cat_id),
            )
            all_events.extend(events)
            self.api_call_count += calls

            if len(self.category_ids) > 1:
                logging.info(
                    f"[{cat_id}] Sleeping {REQUEST_DELAY}s before next category..."
                )
                time.sleep(REQUEST_DELAY)

        self.events = all_events

    @staticmethod
    def filter_events(
        results: list,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
    ) -> list:
        if include is None:
            include = []
        if exclude is None:
            exclude = []
        include = [x.lower() for x in include]
        exclude = [x.lower() for x in exclude]

        if not include:
            return results

        return [
            r
            for r in results
            if any(x in r["title"].lower() for x in include)
            and not any(x in r["title"].lower() for x in exclude)
            and not (
                "label" in r
                and r["label"] is not None
                and r["label"].get("title").lower() == "cancelled"
            )
        ]

    def get_meetings(
        self,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
        events_override: list | None = None,
    ) -> list[Event]:
        """Return filtered meetings as typed Event objects with Contribution objects."""
        if exclude is None:
            exclude = []
        exclude += ["cancelled"]
        raw_events = events_override if events_override is not None else self.events
        filtered = self.filter_events(raw_events, include=include, exclude=exclude)

        results = []
        for event in filtered:
            contributions = []
            for c in event.get("contributions", []):
                attachments = []
                for folder in c.get("folders", []):
                    for a in folder.get("attachments", []):
                        attachments.append(
                            {
                                "url": a.get("download_url", ""),
                                "filename": a.get(
                                    "filename", a.get("title", "unknown")
                                ),
                                "size": a.get("size"),
                                "content_type": a.get("content_type"),
                                "title": a.get("title"),
                            }
                        )
                contributions.append(
                    Contribution(
                        title=c.get("title", ""),
                        url=c.get("url", ""),
                        speakers=c.get("speakers", []),
                        minutes=c.get("note"),
                        start_time=(c.get("startDate") or {}).get("time"),
                        end_time=(c.get("endDate") or {}).get("time"),
                        duration=c.get("duration"),
                        attachments=attachments,
                        description=c.get("description"),
                        keywords=c.get("keywords") or [],
                        contribution_type=(c.get("type") or {}).get("name") if c.get("type") else None,
                    )
                )
            results.append(
                Event(
                    url=event.get("url", ""),
                    date=(event.get("startDate") or {}).get("date", ""),
                    title=event.get("title", ""),
                    contributions=contributions,
                    location=event.get("location"),
                    room=event.get("room"),
                    time=(event.get("startDate") or {}).get("time"),
                    end_date=(event.get("endDate") or {}).get("date"),
                    end_time=(event.get("endDate") or {}).get("time"),
                    minutes_url=(
                        event["note"]["url"]
                        if event.get("note") and "url" in event["note"]
                        else None
                    ),
                    created_dt=event.get("createdDT"),
                    event_type=event.get("type"),
                    description=event.get("description"),
                    chairpersons=event.get("chairpersons") or [],
                    label=event.get("label"),
                    category=event.get("category"),
                    category_id=event.get("categoryId"),
                )
            )

        logging.info(
            f"[{self.category_ids}] Returning {len(results)} meetings after filtering"
        )
        return sorted(results, key=lambda e: e.date, reverse=True)

    def get_meetings_for_author(self, author: str) -> list[Event]:
        """Return meetings where all tokens of `author` appear in a speaker's full_name."""
        tokens = author.lower().split()
        matching = []
        for event in self.events:
            for contrib in event.get("contributions", []):
                if any(
                    all(
                        t in (s.get("fullName") or s.get("full_name") or "").lower()
                        for t in tokens
                    )
                    for s in contrib.get("speakers", [])
                ):
                    matching.append(event)
                    break
        return self.get_meetings(events_override=matching)

    def get_ical(
        self,
        extra_category_ids: list[int] | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> str:
        """Return a combined iCal string for all stored categories (+ any extras).

        Paginates automatically if the range contains > 1000 events.
        Defaults to 60 days in the past through 15 days in the future.
        """
        today = datetime.datetime.now(tz=datetime.timezone.utc).date()
        if start_date is None:
            start_date = (today - datetime.timedelta(days=60)).strftime("%Y-%m-%d")
        if end_date is None:
            end_date = (today + datetime.timedelta(days=15)).strftime("%Y-%m-%d")
        ids = self.category_ids + (extra_category_ids or [])
        pages = []
        offset = 0
        page_num = 1
        while True:
            logging.info(
                f"[ical:{ids}] Fetching iCal page {page_num} (offset={offset})"
            )
            page = ireq.request_category_ical(
                category_ids=ids,
                start_date=start_date,
                end_date=end_date,
                offset=offset,
                **self.req_kwargs,
            )
            n_events = page.count("BEGIN:VEVENT")
            logging.info(f"[ical:{ids}] Page {page_num}: {n_events} VEVENTs")
            pages.append(page)
            if n_events < ireq.ICAL_PAGE_SIZE:
                break
            offset += ireq.ICAL_PAGE_SIZE
            page_num += 1
            logging.info(f"[ical:{ids}] Sleeping {REQUEST_DELAY}s before next page...")
            time.sleep(REQUEST_DELAY)

        return _merge_ical_pages(pages)


def _merge_ical_pages(pages: list[str]) -> str:
    if not pages:
        return ""
    all_text = "\n".join(pages)
    events = re.findall(r"BEGIN:VEVENT.*?END:VEVENT", all_text, re.DOTALL)
    header = pages[0].split("BEGIN:VEVENT")[0].rstrip()
    return "\n".join([header] + events + ["END:VCALENDAR"])
