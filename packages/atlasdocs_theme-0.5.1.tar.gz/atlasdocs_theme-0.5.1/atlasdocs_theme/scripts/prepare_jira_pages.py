from __future__ import annotations

"""
Generate MkDocs pages for Jira projects from fetched JSON files.

Reads which projects to include from jira.toml in the hub directory.
For each project that has a data/jira/{KEY}.json file:
  - Copies the JSON to docs/jira/projects/{KEY}/{KEY}.json
  - Writes docs/jira/projects/{KEY}/index.md (JS loader page)
Writes docs/jira/index.md as a hub page linking to all projects.
Writes config/zensical/nav-jira.toml with the Jira nav section.

Usage examples
--------------
    python -m atlasdocs_theme.scripts.prepare_jira_pages

Pixi:
    pixi run prepare-jira-pages
"""

import json
import os
import shutil
import sys
import tomllib
from pathlib import Path


# ── Configuration ──────────────────────────────────────────────────────────────

JIRA_CONFIG_FILE = "jira.toml"
DATA_DIR = "data/jira"
DOCS_OUTPUT_DIR = "docs/jira"
NAV_OUTPUT_FILE = "config/zensical/nav-jira.toml"

JIRA_SITE = "https://its.cern.ch/jira"

PAGE_ICON = "lucide/ticket"
PAGE_STATUS = "script"
PAGE_SHOW_ACTIONS = False
PAGE_TAGS_BASE = ['"★ JIRA"']


# ── Config loading ─────────────────────────────────────────────────────────────

def load_jira_config(hub_dir: str = ".") -> list[dict]:
    """Load jira.toml and return [{key, label}, ...]."""
    config_path = Path(hub_dir) / JIRA_CONFIG_FILE
    if not config_path.exists():
        return []
    with open(config_path, "rb") as f:
        data = tomllib.load(f)
    site = data.get("site", JIRA_SITE)
    return [
        {
            "key":   p["key"].upper(),
            "label": p.get("label", p["key"].upper()),
            "site":  site,
        }
        for p in data.get("projects", [])
    ]


# ── Stats helpers ──────────────────────────────────────────────────────────────

def _project_stats(json_path: str) -> dict:
    """Return {total, open, closed, first_year, year_counts} from a project JSON."""
    if not os.path.exists(json_path):
        return {}
    with open(json_path) as f:
        try:
            issues = json.load(f)
        except Exception:
            return {}

    total  = len(issues)
    open_  = sum(1 for i in issues if i.get("fields", {}).get("resolution") is None)
    closed = total - open_

    years = [int(i["fields"]["created"][:4])
             for i in issues if i.get("fields", {}).get("created")]
    first_year = min(years) if years else None

    year_map: dict[int, int] = {}
    for y in years:
        year_map[y] = year_map.get(y, 0) + 1
    year_counts = sorted(year_map.items())

    return {
        "total": total,
        "open": open_,
        "closed": closed,
        "first_year": first_year,
        "year_counts": year_counts,
    }


# ── Frontmatter ────────────────────────────────────────────────────────────────

def _frontmatter(title: str, tags: list[str] | None = None) -> str:
    lines = [
        "---",
        f"title: {title}",
        f"icon: {PAGE_ICON}",
        "",
        f"showactions: {str(PAGE_SHOW_ACTIONS).lower()}",
    ]
    if tags:
        lines.append("tags:")
        for tag in tags:
            lines.append(f"  - {tag}")
    lines += ["", "---", ""]
    return "\n".join(lines)


# ── Per-project page ───────────────────────────────────────────────────────────

def _generate_project_page(
    output_dir: str,
    key: str,
    label: str,
    data_dir: str,
    site: str,
) -> bool:
    """Generate docs/jira/projects/{KEY}/index.md and copy JSON. Returns True on success."""
    src_json = os.path.join(data_dir, f"{key}.json")
    if not os.path.exists(src_json):
        print(f"[SKIP] {key}: data/jira/{key}.json not found (run fetch-jira first)")
        return False

    os.makedirs(output_dir, exist_ok=True)

    dst_json = os.path.join(output_dir, f"{key}.json")
    shutil.copy2(src_json, dst_json)

    stats = _project_stats(src_json)
    total = stats.get("total", 0)

    fm = _frontmatter(
        title=f'"{label}"',
        tags=list(PAGE_TAGS_BASE) + [f'"▶ {key}"'],
    )
    md = [
        fm,
        f'<div id="jira-project"',
        f'     data-json="./{key}.json"',
        f'     data-project="{key}"',
        f'     data-jira-base="{site}"></div>',
        '<script src="/assets/javascripts/jira_project_loader.js"></script>',
        "",
    ]
    with open(os.path.join(output_dir, "index.md"), "w") as f:
        f.write("\n".join(md))

    print(f"[DONE] docs/jira/projects/{key}/index.md — {total} issues")
    return True


# ── Hub page ───────────────────────────────────────────────────────────────────

def _generate_hub_page(projects: list[dict], output_path: str, data_dir: str) -> None:
    """Write docs/jira/index.md with grid cards for each project."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    fm = _frontmatter(title='"Jira Projects"')
    lines = [fm, '<div class="grid cards" markdown>', ""]

    for p in projects:
        key   = p["key"]
        label = p["label"]
        site  = p["site"]
        stats = _project_stats(os.path.join(data_dir, f"{key}.json"))
        total = stats.get("total", "")
        open_ = stats.get("open", "")
        desc  = f"{open_} open · {total} total" if total else ""

        lines += [
            f"-   **[{label}](projects/{key}/)**",
            "",
            f"    ---",
            "",
        ]
        if desc:
            lines += [f"    {desc}", ""]
        lines += [
            f"    [:lucide-external-link: {key}]({site}/projects/{key})  "
            f"[:lucide-list: Browse](projects/{key}/)",
            "",
        ]

    lines += ["</div>", ""]

    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    print(f"[DONE] {output_path} — {len(projects)} projects")


# ── Nav ────────────────────────────────────────────────────────────────────────

def _generate_nav(projects: list[dict], output_path: str) -> None:
    """Write config/zensical/nav-jira.toml."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    lines = ["nav = [", '  { "Jira" = [']
    lines.append('    { "Overview" = "jira/index.md" },')
    for p in projects:
        key   = p["key"]
        label = p["label"]
        lines.append(f'    {{ "{label}" = "jira/projects/{key}/index.md" }},')
    lines += ["  ]},", "]", ""]

    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    print(f"[DONE] {output_path} — {len(projects)} projects")


# ── Prepare ────────────────────────────────────────────────────────────────────

def create_jira_pages(
    hub_dir: str = ".",
    data_dir: str | None = None,
    docs_output_dir: str | None = None,
    nav_output_file: str | None = None,
) -> None:
    """Generate MkDocs pages for Jira projects fetched into data/jira/."""
    hub = Path(hub_dir)
    resolved_data_dir  = str(hub / (data_dir or DATA_DIR))
    resolved_docs_dir  = str(hub / (docs_output_dir or DOCS_OUTPUT_DIR))
    resolved_nav_file  = str(hub / (nav_output_file or NAV_OUTPUT_FILE))

    config_projects = load_jira_config(hub_dir)
    if not config_projects:
        print("[INFO] No projects found in jira.toml — nothing to generate.")
        return

    generated: list[dict] = []
    for p in config_projects:
        output_dir = os.path.join(resolved_docs_dir, "projects", p["key"])
        ok = _generate_project_page(
            output_dir=output_dir,
            key=p["key"],
            label=p["label"],
            data_dir=resolved_data_dir,
            site=p["site"],
        )
        if ok:
            generated.append(p)

    _generate_hub_page(generated, os.path.join(resolved_docs_dir, "index.md"), resolved_data_dir)
    _generate_nav(generated, resolved_nav_file)

    print(f"[FINISH] Generated {len(generated)} Jira project page(s).")


def main() -> None:
    hub_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
    create_jira_pages(hub_dir=str(hub_dir))


if __name__ == "__main__":
    main()
