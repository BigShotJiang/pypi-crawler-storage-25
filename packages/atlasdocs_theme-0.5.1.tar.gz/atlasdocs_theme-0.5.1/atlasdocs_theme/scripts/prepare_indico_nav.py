from __future__ import annotations

"""
Generate config/zensical/nav-indico.toml — a full nav with a static "Home"
section and a dynamic "Meetings" section built from indico.toml.

Usage examples
--------------
    python -m atlasdocs_theme.scripts.prepare_indico_nav

Pixi:
    pixi run prepare-indico-nav
"""

import json
import os
import sys
import tomllib
from pathlib import Path


# ── Configuration ──────────────────────────────────────────────────────────────

INDICO_CONFIG_FILE = "indico.toml"
DOCS_OUTPUT_DIR = "docs/category"
MEETINGS_PAGE = "meetings.md"
OUTPUT_FILE = "config/zensical/nav-indico.toml"

# Nav entry type: (label, path_or_children)
# where children is a list of the same type
NavEntry = tuple[str, "str | list[NavEntry]"]

# Default Home section — edit this to match your hub structure,
# or override by providing config/nav-home.toml in your hub.
HOME_NAV_TEMPLATE: list[NavEntry] = [
    ("Home",      "index.md"),
    ("Contacts",  "contacts.md"),
    ("Meetings",  "meetings.md"),
    ("Glance",    "glance.md"),
    ("Directory", "directory.md"),
    ("<hr>", ""),
    ("Common resources", [
        ("Item",      "common/item.md"),
        ("Migration", "migrationstatus.md"),
    ]),
    ("<hr>", ""),
    ("Subgroups", [
        ("Group #1", [
            ("Home",             "group1/index.md"),
            ("Contacts",         "group1/contacts.md"),
            ("Meetings",         "group1/meetings.md"),
            ("Common resources", [
                ("Item", "group1/common/item.md"),
            ]),
            ("Subgroups", [
                ("Analysis 1", "analysis1/index.md"),
                ("Analysis 2", "analysis2/index.md"),
            ]),
        ]),
    ]),
]


# ── Config loading ─────────────────────────────────────────────────────────────

def load_indico_config(hub_dir: str = ".") -> list[dict]:
    """Load indico.toml and return [{id, label}, ...]."""
    config_path = Path(hub_dir) / INDICO_CONFIG_FILE
    if not config_path.exists():
        return []
    with open(config_path, "rb") as f:
        data = tomllib.load(f)
    return [{"id": str(c["id"]), "label": c.get("label", f"Category {c['id']}")}
            for c in data.get("categories", [])]


def _load_home_template(hub_dir: str) -> list[NavEntry]:
    """Load Home nav entries from config/nav-home.toml if present."""
    path = Path(hub_dir) / "config" / "nav-home.toml"
    if not path.exists():
        return HOME_NAV_TEMPLATE
    with open(path, "rb") as f:
        data = tomllib.load(f)
    return _toml_to_entries(data.get("home", []))


def _toml_to_entries(items: list) -> list[NavEntry]:
    """Convert [{label = path}] or [{label = [{...}]}] to NavEntry list."""
    result = []
    for item in items:
        for label, value in item.items():
            if isinstance(value, list):
                result.append((label, _toml_to_entries(value)))
            else:
                result.append((label, str(value)))
    return result


# ── Render ─────────────────────────────────────────────────────────────────────

def _render_entry(label: str, value: str | list, indent: int) -> list[str]:
    pad = "  " * indent
    label_str = json.dumps(label)
    if isinstance(value, str):
        return [f"{pad}{{ {label_str} = {json.dumps(value)} }},"]
    lines = [f"{pad}{{ {label_str} = ["]
    for sub_label, sub_value in value:
        lines.extend(_render_entry(sub_label, sub_value, indent + 1))
    lines.append(f"{pad}]}},")
    return lines


def render_nav(sections: list[NavEntry]) -> str:
    """Render top-level nav sections to TOML string."""
    lines = ["nav = ["]
    for label, entries in sections:
        lines.extend(_render_entry(label, entries, 1))
    lines.append("]")
    return "\n".join(lines) + "\n"


# ── Prepare ────────────────────────────────────────────────────────────────────

def create_indico_nav(
    hub_dir: str = ".",
    docs_output_dir: str | None = None,
    output_file: str | None = None,
) -> None:
    """Generate nav-indico.toml with a Home template + dynamic Meetings section."""
    hub = Path(hub_dir)
    docs_dir = str(hub / (docs_output_dir or DOCS_OUTPUT_DIR))
    output_path = str(hub / (output_file or OUTPUT_FILE))

    home_entries = _load_home_template(hub_dir)

    config_cats = load_indico_config(hub_dir)
    meetings_entries: list[NavEntry] = [("Meetings", MEETINGS_PAGE)]
    included = 0
    for cat in config_cats:
        cat_id = cat["id"]
        index_md = os.path.join(docs_dir, cat_id, "index.md")
        if not os.path.exists(index_md):
            print(f"[SKIP] {cat_id}: docs/category/{cat_id}/index.md not found (run prepare-indico-pages first)")
            continue
        meetings_entries.append((cat["label"], f"category/{cat_id}/index.md"))
        included += 1

    sections: list[NavEntry] = [
        ("Home", home_entries),
        ("Meetings", meetings_entries),
    ]

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        f.write(render_nav(sections))

    print(f"[DONE] {output_path} — {included} categories in Meetings")
    for label, path in meetings_entries[1:]:
        print(f"  {label}: {path}")


def main() -> None:
    hub_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
    create_indico_nav(hub_dir=str(hub_dir))


if __name__ == "__main__":
    main()
