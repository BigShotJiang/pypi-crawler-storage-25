from __future__ import annotations

"""
Fetch Jira project issues and save them as JSON files.

Reads which projects to fetch from jira.toml in the hub directory.
Writes one file per project:
    data/jira/{KEY}.json

Credentials: set JIRA_TOKEN (personal access token) or
             JIRA_USER + JIRA_PASSWORD in the environment.

Usage examples
--------------
Fetch all projects from jira.toml:
    python -m atlasdocs_theme.scripts.fetch_jira

Specific projects:
    python -m atlasdocs_theme.scripts.fetch_jira --projects ATLASDOC
    python -m atlasdocs_theme.scripts.fetch_jira --projects ATLASDOC,ATWIKIPHYS

Custom JQL query (saves to data/jira/tickets.json):
    python -m atlasdocs_theme.scripts.fetch_jira --jql "project = FOO AND status = Open"

Only issues created in the last 3 years:
    python -m atlasdocs_theme.scripts.fetch_jira --since -3y

List accessible projects:
    python -m atlasdocs_theme.scripts.fetch_jira --list-projects
    python -m atlasdocs_theme.scripts.fetch_jira --list-projects atlas

Re-fetch even if cached:
    python -m atlasdocs_theme.scripts.fetch_jira --refresh

Dry-run (print first 10 tickets, don't save):
    python -m atlasdocs_theme.scripts.fetch_jira --dry-run

Pixi (args after --):
    pixi run fetch-jira
    pixi run fetch-jira -- --projects ATLASDOC
"""

import argparse
import base64
import json
import os
import re
import sys
import time
import tomllib
import urllib.parse
import urllib.request
from datetime import date, timedelta
from pathlib import Path


# ── Configuration ──────────────────────────────────────────────────────────────

JIRA_SITE = "https://its.cern.ch/jira"
DATA_DIR = "data/jira"
JIRA_CONFIG_FILE = "jira.toml"
PAGE_SIZE = 1000
REQUEST_DELAY = 0.3

FIELDS = [
    "summary", "description", "status", "priority",
    "assignee", "reporter", "created", "updated",
    "labels", "components", "issuetype", "resolution",
    "resolutiondate", "comment",
]


# ── Config loading ─────────────────────────────────────────────────────────────

def load_jira_config(hub_dir: str = ".") -> dict:
    """Load jira.toml. Returns {projects: [{key, label}], site}."""
    config_path = Path(hub_dir) / JIRA_CONFIG_FILE
    if not config_path.exists():
        return {"projects": [], "site": JIRA_SITE}
    with open(config_path, "rb") as f:
        data = tomllib.load(f)
    return {
        "projects": data.get("projects", []),
        "site": data.get("site", JIRA_SITE),
    }


# ── Credentials ────────────────────────────────────────────────────────────────

def load_credentials() -> tuple[str, str, bool]:
    """Return (user, secret, is_token). Exits on missing credentials."""
    user     = os.environ.get("JIRA_USER", "")
    token    = os.environ.get("JIRA_TOKEN")
    password = os.environ.get("JIRA_PASSWORD")
    if token:
        return user, token, True
    if password:
        if not user:
            sys.exit("Error: JIRA_USER must be set when using JIRA_PASSWORD.")
        return user, password, False
    sys.exit("Error: JIRA_TOKEN or JIRA_PASSWORD not set in environment.")


def _auth_header(user: str, secret: str, is_token: bool) -> str:
    if is_token:
        return f"Bearer {secret}"
    return "Basic " + base64.b64encode(f"{user}:{secret}".encode()).decode()


# ── HTTP ───────────────────────────────────────────────────────────────────────

def _get(auth: str, url: str) -> dict:
    req = urllib.request.Request(url, headers={
        "Authorization": auth,
        "Accept": "application/json",
    })
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read())


# ── Date helpers ───────────────────────────────────────────────────────────────

def _since_to_jql_date(since: str) -> str:
    """Convert -3y / -6m / -2w / -30d or ISO date to a quoted JQL date string."""
    m = re.fullmatch(r"-?(\d+)([ymwd])", since)
    if not m:
        return f'"{since}"'
    n, unit = int(m.group(1)), m.group(2)
    today = date.today()
    if unit == "y":
        cutoff = today.replace(year=today.year - n)
    elif unit == "m":
        month = today.month - n
        year  = today.year + (month - 1) // 12
        month = (month - 1) % 12 + 1
        cutoff = today.replace(year=year, month=month)
    elif unit == "w":
        cutoff = today - timedelta(weeks=n)
    else:
        cutoff = today - timedelta(days=n)
    return f'"{cutoff.isoformat()}"'


# ── Fetch ──────────────────────────────────────────────────────────────────────

def fetch_projects(auth: str, site: str) -> list[dict]:
    return sorted(_get(auth, f"{site}/rest/api/2/project"), key=lambda p: p["key"])


def fetch_page(auth: str, site: str, jql: str, start_at: int) -> dict:
    params = urllib.parse.urlencode({
        "jql": jql,
        "startAt": start_at,
        "maxResults": PAGE_SIZE,
        "fields": ",".join(FIELDS),
    })
    return _get(auth, f"{site}/rest/api/2/search?{params}")


def fetch_all(auth: str, site: str, jql: str) -> list[dict]:
    tickets: list[dict] = []
    start_at = 0
    while True:
        print(f"  Fetching {start_at}–{start_at + PAGE_SIZE - 1}…", end="", flush=True)
        data = fetch_page(auth, site, jql, start_at)
        issues = data.get("issues", [])
        total  = data.get("total", 0)
        tickets.extend(issues)
        print(f" +{len(issues)} ({len(tickets)}/{total})")
        if not issues or len(tickets) >= total:
            break
        start_at += len(issues)
        time.sleep(REQUEST_DELAY)
    return tickets


def _print_row(t: dict) -> None:
    f        = t.get("fields", {})
    status   = (f.get("status")   or {}).get("name", "?")
    priority = (f.get("priority") or {}).get("name", "?")
    summary  = (f.get("summary")  or "").strip()
    updated  = (f.get("updated")  or "")[:10]
    print(f"  {t['key']:<18}  [{status:<12}]  [{priority:<16}]  {updated}  {summary[:70]}")


# ── Save ───────────────────────────────────────────────────────────────────────

def save_project(key: str, tickets: list[dict], data_dir: str) -> Path:
    out_dir = Path(data_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{key}.json"
    out_path.write_text(json.dumps(tickets, indent=2, ensure_ascii=False))
    return out_path


# ── Main ───────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fetch Jira project issues and save as JSON.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__.split("Usage examples")[1] if __doc__ and "Usage examples" in __doc__ else "",
    )
    parser.add_argument("--projects", metavar="KEY1,KEY2",
                        help="Comma-separated project keys (default: all projects in jira.toml)")
    parser.add_argument("--jql", help="Custom JQL query (saves to data/jira/tickets.json)")
    parser.add_argument("--since", metavar="DATE_OR_OFFSET",
                        help="Only fetch issues created on/after this date (e.g. -3y, 2022-01-01)")
    parser.add_argument("--list-projects", nargs="?", const="", metavar="PATTERN",
                        help="List accessible projects, optionally filtered by name/key pattern")
    parser.add_argument("--refresh", action="store_true",
                        help="Re-fetch even if cache exists")
    parser.add_argument("--dry-run", action="store_true",
                        help="Fetch 10 tickets, print summaries, exit without saving")
    parser.add_argument("--site", default=None,
                        help=f"Jira base URL (default: from jira.toml or {JIRA_SITE})")
    parser.add_argument("--data-dir", default=DATA_DIR,
                        help=f"Output directory (default: {DATA_DIR})")
    args = parser.parse_args()

    hub_dir = str(Path.cwd())
    config  = load_jira_config(hub_dir)
    site    = args.site or config["site"]

    user, secret, is_token = load_credentials()
    auth = _auth_header(user, secret, is_token)

    resolved_data_dir = str(Path(hub_dir) / args.data_dir)

    # ── list-projects ──────────────────────────────────────────────────────────
    if args.list_projects is not None:
        pattern  = args.list_projects.lower()
        projects = fetch_projects(auth, site)
        if pattern:
            projects = [p for p in projects
                        if pattern in p["key"].lower() or pattern in p["name"].lower()]
        print(f"{'KEY':<24} {'TYPE':<14} {'ID':<8} NAME")
        print("-" * 80)
        for p in projects:
            print(f"  {p['key']:<22} {p.get('projectTypeKey',''):<14} {p['id']:<8} {p['name']}")
        print(f"\n{len(projects)} project(s) shown")
        return

    # ── custom JQL mode ────────────────────────────────────────────────────────
    if args.jql:
        out_file = Path(resolved_data_dir) / "tickets.json"
        if out_file.exists() and not args.refresh:
            existing = json.loads(out_file.read_text())
            print(f"Cache hit: {len(existing):,} tickets in {out_file}  (use --refresh to re-fetch)")
            return
        if args.dry_run:
            data    = fetch_page(auth, site, args.jql, 0)
            tickets = data.get("issues", [])[:10]
            print(f"DRY RUN  JQL: {args.jql}\nTotal: {data.get('total',0):,}  (showing {len(tickets)})\n")
            for t in tickets:
                _print_row(t)
            return
        tickets = fetch_all(auth, site, args.jql)
        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_text(json.dumps(tickets, indent=2, ensure_ascii=False))
        print(f"\nSaved {len(tickets):,} tickets → {out_file}")
        return

    # ── per-project mode ───────────────────────────────────────────────────────
    if args.projects:
        keys = [k.strip().upper() for k in args.projects.split(",") if k.strip()]
    else:
        keys = [p["key"] for p in config["projects"]]
        if not keys:
            parser.error("No projects specified — use --projects or add entries to jira.toml")

    since_clause = f" AND created >= {_since_to_jql_date(args.since)}" if args.since else ""

    if args.dry_run:
        jql = f"project = {keys[0]}{since_clause} ORDER BY updated DESC"
        data    = fetch_page(auth, site, jql, 0)
        tickets = data.get("issues", [])[:10]
        print(f"DRY RUN — {keys[0]}  JQL: {jql}\nTotal: {data.get('total',0):,}  (showing {len(tickets)})\n")
        for t in tickets:
            _print_row(t)
        return

    print(f"\nFetching {len(keys)} project(s) → {resolved_data_dir}\n")
    grand_total = skipped = errors = 0
    for i, key in enumerate(keys, 1):
        out_file = Path(resolved_data_dir) / f"{key}.json"
        if out_file.exists() and not args.refresh:
            existing = json.loads(out_file.read_text())
            skipped += 1
            grand_total += len(existing)
            print(f"[{i}/{len(keys)}] {key}: cached ({len(existing):,} tickets) — skipping")
            continue
        jql = f"project = {key}{since_clause} ORDER BY updated DESC"
        print(f"[{i}/{len(keys)}] {key}")
        try:
            tickets = fetch_all(auth, site, jql)
        except Exception as e:
            print(f"  ERROR: {e} — skipping")
            errors += 1
            continue
        if tickets:
            save_project(key, tickets, resolved_data_dir)
            grand_total += len(tickets)
            print(f"  Saved {len(tickets):,} tickets → {out_file}")
        else:
            print(f"  (no tickets)")

    print(f"\n{'='*60}")
    print(f"Total: {grand_total:,} tickets  |  {skipped} cached, {len(keys) - skipped - errors} fetched, {errors} error(s)")

    if errors:
        sys.exit(1)


if __name__ == "__main__":
    main()
