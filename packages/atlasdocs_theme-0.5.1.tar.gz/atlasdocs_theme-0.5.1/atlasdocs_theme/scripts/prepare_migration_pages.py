from __future__ import annotations

import os
import re
import tomllib
from collections import defaultdict
from datetime import datetime
from pathlib import Path


# ── Configuration ──────────────────────────────────────────────────────────────

# Link filter — only URLs containing this string are collected
TWIKI_LINK_FILTER = "twiki"

# URL prefix replacements applied before display (order matters — most specific first)
URL_DISPLAY_REPLACEMENTS: list[tuple[str, str]] = [
    ("twiki.cern.ch/twiki/bin/viewauth", "Twiki: "),
    ("twiki.cern.ch/twiki/bin/view/",    "Twiki: "),
    ("twiki.cern.ch/twiki/bin/edit/",    "Twiki (edit): "),
    ("twiki.cern.ch/twiki/bin/attach/",  "Twiki (attach):"),
    ("twiki.cern.ch/twiki/bin/",         "Markdown > ... > "),
    ("/twiki/bin/view/",                 "Markdown > ... > "),
    ("/twiki/bin/edit/",                 "Markdown > ... > "),
]

# Maximum display length for a URL cell before truncation
URL_DISPLAY_MAX_LEN = 55

# Files excluded from link scanning regardless of directory config
SCAN_EXCLUDE_FILES = {"directory.md", "migrationstatus.md"}

# Top-level docs subdirectories skipped entirely during scanning
SCAN_EXCLUDE_DIRS = {"category", "jira", "glance", "archive", "assets", "images", "img", "diagrams", "files", "attachments"}

# Frontmatter written into every generated migrationstatus.md
PAGE_ICON = "lucide/link"
PAGE_BOOST = 0
PAGE_TAGS = ["★ MIGRATION"]
PAGE_HIDE = ["toc"]

# Content shown when no matching links are found in the directory
PAGE_NO_LINKS_MESSAGE = (
    ":lucide-circle-check: **No Twiki pages linked to!**\n\n"
    "This directory contains no links to Twiki. "
    "Nothing to migrate here."
)

# Tip admonition shown at the top of every migration status page
PAGE_TIP = (
    "How to use this page\"\n"
    "    - Hover over a link to see which pages use it (tooltip)\n"
    "    - The \"Usage Count\" column shows how many pages reference this link\n"
    "    - Focus on high-usage links first for maximum migration impact"
)


# ── Fetch ──────────────────────────────────────────────────────────────────────

def extract_links_from_file(file_path: str) -> list[dict[str, str]]:
    links = []
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        print(f"Warning: Could not read {file_path}: {e}")
        return links

    for match in re.finditer(r"\[([^\]]+)\]\(([^)]+)\)", content):
        text, url = match.groups()
        if url.strip() and TWIKI_LINK_FILTER in url.lower():
            links.append({"text": text, "url": url})

    return links


# ── Prepare ────────────────────────────────────────────────────────────────────

def create_migration_status(docs_root: str = "docs") -> None:
    directories = []
    for root, dirs, files in os.walk(docs_root):
        if "directory.toml" in files:
            print(f"Found directory.toml in {root}")
            directories.append(root)

    renderer = DefaultMigrationRenderer()

    for dir_path in directories:
        directory_config = {}
        try:
            with open(os.path.join(dir_path, "directory.toml"), "rb") as f:
                directory_config = tomllib.load(f)
        except Exception as e:
            print(f"Error loading config from {dir_path}: {e}")

        if not directory_config.get("migrationsummary", False):
            continue

        content = renderer.render(Path(dir_path))

        output_path = Path(dir_path) / "migrationstatus.md"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)

        link_count = content.count("\n| ") - 1
        print(f"Created migrationstatus.md in {dir_path} with {link_count} unique Twiki links")


# ── Postprocess ────────────────────────────────────────────────────────────────

class DefaultMigrationRenderer:
    def render(self, folder: Path) -> str:
        dir_path = str(folder)
        directory_config = {}
        try:
            with open(folder / "directory.toml", "rb") as f:
                directory_config = tomllib.load(f)
        except Exception as e:
            print(f"Error loading config from {folder / 'directory.toml'}: {e}")

        pagetitle = directory_config.get("title", "Directory")
        exclude = directory_config.get("exclude", [])

        md_files = []
        for root, dirs, files in os.walk(dir_path):
            dirs[:] = [d for d in dirs if d not in SCAN_EXCLUDE_DIRS]
            for f in files:
                if f.endswith(".md") and f not in SCAN_EXCLUDE_FILES:
                    rel_from_dir = os.path.relpath(os.path.join(root, f), dir_path)
                    if any(rel_from_dir.startswith(excl) or rel_from_dir == excl for excl in exclude):
                        continue
                    md_files.append(rel_from_dir)

        hide_block = "".join(f"    - {h}\n" for h in PAGE_HIDE)
        tags_block = "".join(f"    - {t}\n" for t in PAGE_TAGS)
        frontmatter = (
            f"---\n"
            f"title: Migration Status - {pagetitle}\n"
            f"icon: {PAGE_ICON}\n"
            f"hide:\n{hide_block}"
            f"tags:\n{tags_block}"
            f"boost: {PAGE_BOOST}\n"
            f"pagestatus: script\n"
            f"dategenerated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
            f"---\n\n"
        )

        if not md_files:
            return frontmatter + PAGE_NO_LINKS_MESSAGE + "\n"

        link_usage: dict[str, list] = defaultdict(list)
        for md_file in md_files:
            for link in extract_links_from_file(os.path.join(dir_path, md_file)):
                page_name = md_file.replace(".md", "").replace("\\", "/")
                link_usage[link["url"]].append({"page": page_name, "text": link["text"]})

        if not link_usage:
            print(f"No Twiki links found in {dir_path}")
            return frontmatter + PAGE_NO_LINKS_MESSAGE + "\n"

        def clean_page(page: str) -> str:
            if page.endswith("/index"):
                return page[:-6] if len(page) > 6 else page[:-5]
            return "" if page == "index" else page

        table_rows = []
        for i, (url, usages) in enumerate(sorted(link_usage.items()), 1):
            pages_links = "<br>".join(
                f"[{clean_page(p)}]({clean_page(p)})" if clean_page(p) else "[index](.)"
                for p in [u["page"] for u in usages]
            )

            url_display = url.replace("|", "\\|").replace("https://", "").replace("http://", "")
            for pattern, replacement in URL_DISPLAY_REPLACEMENTS:
                if pattern in url_display or url_display.startswith(pattern):
                    url_display = url_display.replace(pattern, replacement, 1)
                    break

            url_display = url_display.replace("#", "<br>Sub Header > #")
            if len(url_display) > URL_DISPLAY_MAX_LEN:
                url_display = "..." + url_display[-(URL_DISPLAY_MAX_LEN - 3):]

            has_query = "?" in url_display or "?" in url
            url_display_no_query = url_display.split("?")[0]
            url_link = f"[{url_display_no_query}{'*' if has_query else ''}]({url})"
            if has_query:
                url_link += " (query removed)"

            table_rows.append(f"| {i} | {url_link} | {len(usages)} | {pages_links} |")

        total_unique_links = len(link_usage)
        total_usages = sum(len(usages) for usages in link_usage.values())

        return (
            frontmatter
            + f"This folder contains **{total_unique_links} unique Twiki links** with **{total_usages} total usages** across {len(md_files)} pages.\n\n"
            + f"!!! tip \"{PAGE_TIP}\n\n"
            + f"<div class=\"compact-tables\" markdown>\n\n"
            + f"|:lucide-hash: | :lucide-external-link: URL | :lucide-list-ordered: Usage | :lucide-file-text: Pages |\n"
            + f"|:---|:-------------------|:------------------------|:---------------------|\n"
            + "\n".join(table_rows)
            + "\n</div>\n\n"
        )


def main() -> None:
    import sys
    hub_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
    create_migration_status(docs_root=str(hub_dir / "docs"))


if __name__ == "__main__":
    main()
