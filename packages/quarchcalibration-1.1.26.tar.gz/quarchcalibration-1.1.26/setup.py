import os
import re
from setuptools import setup

# Get the absolute path of the directory containing setup.py
# This ensures it builds correctly no matter where the command is run from
HERE = os.path.abspath(os.path.dirname(__file__))

# Safely construct OS-compatible file paths
VERSIONFILE = os.path.join(HERE, "quarchCalibration", "_version.py")
CHANGESFILE = os.path.join(HERE, "quarchCalibration", "Docs", "CHANGES.rst")

# Read version string (with utf-8 encoding for Windows safety)
with open(VERSIONFILE, "rt", encoding="utf-8") as f:
    verstrline = f.read()

VSRE = r"^__version__ = ['\"]([^'\"]*)['\"]"
mo = re.search(VSRE, verstrline, re.M)
if mo:
    verstr = mo.group(1)
else:
    raise RuntimeError("Unable to find version string in %s." % (VERSIONFILE,))

# Read long description safely
with open(CHANGESFILE, "rt", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name='quarchCalibration',
    version=verstr,
    description='This package offers calibration for Quarch Technology modules.',
    long_description_content_type='text/x-rst',
    long_description=long_description,
    url='https://www.quarch.com', # Note: 'url' is the modern standard over 'home_page'
    author='Quarch Technology ltd',
    author_email='support@quarch.com',
    license='Quarch Technology ltd',
    keywords='quarch quarchpy calibration torridon',
    packages=['quarchCalibration', 'quarchCalibration.Docs'],
    classifiers=[
        'Intended Audience :: Information Technology',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'Operating System :: MacOS',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: POSIX',
        'Programming Language :: Python',
        'Topic :: Scientific/Engineering :: Information Analysis',
        'Topic :: System',
        'Topic :: System :: Power (UPS)'
    ],
    include_package_data=True,
    zip_safe=False
)
