=============================
Changelog (QuarchCalibration)
=============================
QuarchCalibration
-----------------
*QuarchCalibration is a python package that allows calibration of Quarch modules.*


Change Log
----------

1.1.26
------
- AC PAM code made more common

1.1.23
------
- Released support for Delta PAM calibration

1.1.19
------
- Fixed some minor bugs

1.1.18
------
- Fixed 1995 6-way calibration
- Added Python Version Check

1.1.17
------
- Updated API for AC Calibration Instruments
- Minor bug fixes

1.1.16
------
- Added Device Test Check
- Added back Resetting of module

1.1.13
------
- Minor bug fixes

1.1.12
------
- Updated 2 channel device class to use one switchbox
- Updated report tables to display nicely and show the "Set" value. 
- Updated keithley_2460 api class to validate all returned values. 

1.1.11
------
- Improved keithley and switchbox shutdowns to help prevent popping PAMs

1.1.10
------
- Minor bug fixes
- Noise test made standalone and now uses QIS 
- Updated production filepath of calibration report files

1.1.9
-----
- Minor bug fixes
- Added support for QTL2910-02

1.1.8
-----
- Updates for AC Calibration
- Minor bug fixes 

1.1.7
-----
- Minor error logging fix
- Minor device selection for AC calibration fix

1.1.6
-----
- Uptades for AC Calibration
- Minor bug fixes 

1.1.5
-----
-Bug fixes 

1.1.4
-----
- Fixes for edsff calibration
- Fixes for modules with no noise test

1.1.3
-----
- Added QTL1944_06
- Added Noise Test.

1.1.2
-----
- Added QTL2887  Gen5 EDSFF Fixture (E1)
- Added QTL2888  GEN5 EDSFF Fixture (E3)

1.1.1
-----
- Added QTL2674 EDSFF Fixture (E3)

1.1.0
-----
- Added QTL2788 Gen 5 SFF PAM Fixture calibration

1.0.0
-----
- Added QTL2673 EDSFF Fixture (E1)
- fixes for import bug

0.0.0
-----
- Initial separation of calibration from QuarchPy
