# QuarchCalibration

QuarchCalibration is a project dedicated to providing tools, scripts, and resources for calibrating measurement hardware and systems developed by Quarch Technology Ltd. This repository aims to support automated calibration tasks, enable reproducible calibration workflows, and facilitate integration with Quarch’s suite of hardware products.

## Features

- **Automated calibration scripts:** Reduce manual intervention and improve consistency.
- **Hardware support:** Compatible with a variety of Quarch devices.
- **Extensible calibration routines:** Easily add support for new equipment or workflows.
- **Data logging:** Store results and logs for traceability and analysis.
- **Cross-platform:** Scripted tools are designed for use on major operating systems.

## Getting Started

### Prerequisites

- [Git](https://git-scm.com/) for version control and cloning the repository
- [Python 3.x](https://www.python.org/) (unless otherwise specified)
- [`quarchpy`](https://pypi.org/project/quarchpy/) Python package (see below)
- Any additional dependencies listed in `requirements.txt` (if present)

---

### Downloading the Project

To obtain a local copy of the QuarchCalibration repository, open a terminal or command prompt and run:

```sh
git clone https://github.com/QuarchTechnologyLtd/QuarchCalibration.git
```

This will create a folder named `QuarchCalibration` with all source code and resources.

### Setting Up Your Environment

We strongly recommend working in a Python virtual environment (venv):

1. **Navigate to the project directory:**
    ```sh
    cd QuarchCalibration
    ```
2. **Create and activate a virtual environment:**
    - On Linux / macOS:
        ```sh
        python3 -m venv venv
        source venv/bin/activate
        ```
    - On Windows:
        ```sh
        python -m venv venv
        venv\Scripts\activate
        ```
3. **Install required packages:**
    ```sh
    pip install quarchpy
    ```
    If there is a `requirements.txt` file, install all dependencies:
    ```sh
    pip install -r requirements.txt
    ```
    > **Note:** The core dependency for calibration is `quarchpy`.

---

### Running the Tools

- To get started with calibration, simply run:
    ```sh
    python CalibrationUtil.py
    ```
    This script offers an entry point for calibration tasks.

#### Want to change how calibration is launched, or run in "TestCenter mode"?

If you would like to modify how calibration is launched, or want to work with "TestCenter mode" (for integration with Quarch Test Center software), refer to the [Test_Center_Calibration_Kickoff_Scripts](https://github.com/QuarchTechnologyLtd/Test_Center_Calibration_Kickoff_Scripts) repository. It contains kickoff scripts for starting the calibration process and handling communication with Test Center.

---

## Contributing

This is a quarch internal github. The code is open sourse and available to download on pypi. Outside of Organisation contributing is not currently available. 

## License

Distributed under the [MIT License](LICENSE).

## Support

For questions or support, contact [Quarch Technology Ltd](https://quarch.com/contact/) or open an issue in this repository.

---

*QuarchCalibration is maintained by Quarch Technology Ltd.*
