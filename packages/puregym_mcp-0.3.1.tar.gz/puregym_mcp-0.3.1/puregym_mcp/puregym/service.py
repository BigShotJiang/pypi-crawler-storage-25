from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from puregym_mcp.puregym.client import PureGymClient
from puregym_mcp.puregym.models import (
    BookClassResult,
    CancelBookingResult,
    CenterGroup,
    CenterLiveStatus,
    CenterOpeningHours,
    GymClass,
    GymClassTypesGroup,
)


@dataclass(frozen=True)
class SearchDefaults:
    from_date: str
    to_date: str


class PureGymService:
    def __init__(self, client: PureGymClient):
        self.client = client

    @property
    def is_authenticated(self) -> bool:
        return self.client.has_credentials

    def default_search_window(self, now: datetime | None = None) -> SearchDefaults:
        now = now or datetime.today()
        search_days_allowed = 28 if self.is_authenticated else 14
        return SearchDefaults(
            from_date=now.strftime("%Y-%m-%d"),
            to_date=(now + timedelta(days=search_days_allowed)).strftime("%Y-%m-%d"),
        )

    async def list_class_types(self) -> list[GymClassTypesGroup]:
        return await self.client.get_all_class_types()

    async def list_centers(self) -> list[CenterGroup]:
        return await self.client.get_all_centers()

    async def search_classes(
        self,
        class_ids: list[int] | None = None,
        center_ids: list[int] | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
    ) -> list[GymClass]:
        defaults = self.default_search_window()
        return await self.client.get_available_classes(
            class_ids=class_ids,
            center_ids=center_ids,
            from_date=from_date or defaults.from_date,
            to_date=to_date or defaults.to_date,
        )

    async def list_my_bookings(
        self,
        class_ids: list[int] | None = None,
        center_ids: list[int] | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
    ) -> list[GymClass]:
        if not self.is_authenticated:
            raise ValueError("Authenticated PureGym credentials are required to list bookings")
        bookings = await self.client.get_my_bookings()
        filtered = bookings

        if from_date is not None:
            filtered = [booking for booking in filtered if booking.date >= from_date]
        if to_date is not None:
            filtered = [booking for booking in filtered if booking.date <= to_date]
        return filtered

    async def book_class(self, booking_id: str, activity_id: int, payment_type: str) -> BookClassResult:
        if not self.is_authenticated:
            raise ValueError("Authenticated PureGym credentials are required to create bookings")
        return await self.client.book_by_ids(booking_id, activity_id, payment_type)

    async def cancel_booking(self, participation_id: str) -> CancelBookingResult:
        if not self.is_authenticated:
            raise ValueError("Authenticated PureGym credentials are required to cancel bookings")
        return await self.client.unbook_participation(participation_id)

    async def get_center_live_status(self, center_id: int) -> CenterLiveStatus:
        if not self.is_authenticated:
            raise ValueError("Authenticated PureGym credentials are required to inspect center live status")
        return await self.client.get_center_live_status(center_id)

    async def get_center_open_hours(self, center_id: int) -> list[CenterOpeningHours]:
        if not self.is_authenticated:
            raise ValueError("Authenticated PureGym credentials are required to inspect center open hours")
        return await self.client.get_center_open_hours(center_id)

    async def aclose(self) -> None:
        await self.client.aclose()
