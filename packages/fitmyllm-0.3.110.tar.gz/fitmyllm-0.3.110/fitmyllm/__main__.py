"""Entry point for fitmyllm CLI."""
import sys

__version__ = "0.3.110"


def _check_update() -> None:
    """Quick check for newer version on PyPI (2s timeout, non-blocking)."""
    try:
        import httpx
        resp = httpx.get("https://pypi.org/pypi/fitmyllm/json", timeout=2.0)
        if resp.is_success:
            latest = resp.json().get("info", {}).get("version", "")
            if latest and latest != __version__:
                print(f"  [update] fitmyllm {latest} available (you have {__version__})")
                print(f"           pip install --upgrade fitmyllm\n")
    except Exception:
        pass


def main():
    # Handle --help before loading Textual
    if "--help" in sys.argv or "-h" in sys.argv:
        print(f"""
  fitmyllm {__version__} — Run the right LLM locally. Automatically.

  Usage:
    fitmyllm              Interactive TUI (recommended)
    fitmyllm setup        Save your API key
    fitmyllm chat <model> Chat with a model directly
    fitmyllm benchmark    Run a speed benchmark
    fitmyllm my-benchmarks View your submitted benchmarks
    fitmyllm telemetry on|off  Toggle anonymous speed telemetry

  API key:
    Get your free key at https://www.fitmyllm.com/?tab=mcp
    Save it with: fitmyllm setup
    Or: export FITMYLLM_API_KEY=fml_xxxxx

  Main menu (9 modes):
    Quick Run       Detect GPU -> best model -> download -> chat (zero config)
    Find Models     What can I run on my GPU?
    Find GPU        What GPU do I need for a model?
    Enterprise      Deploy at scale — sizing, cost, latency
    Model Library   Manage installed models (Ollama, llama-server, local GGUF)
    Tier List       Models ranked S-F by score
    Benchmarks      Model benchmark leaderboard
    GPU Prices      Search and compare GPU pricing
    Run Benchmark   Speed test with model selection + delta vs predicted

  Keyboard shortcuts (in TUI):
    f          Toggle filter panel
    g          Search/change GPU
    Space      Mark model for comparison
    c          Compare marked / chat from library
    d          Delete model (in Model Library)
    i          Install model
    m          Manual input (in Run Benchmark)
    t          Command simulator / toggle thinking
    s          Save model
    r          Refresh / HuggingFace README
    Enter      Open model detail
    Escape     Go back
    q          Quit

  Backends (auto-detected):
    Ollama          localhost:11434 (ollama pull / run)
    llama-server    localhost:8080 (auto-started or manual)
    OpenAI-compat   Any server speaking /v1/chat/completions

  Data storage:
    ~/.fitmyllm/config.json     Preferences, API key, saved models, telemetry
    ~/.fitmyllm/cache/          API response cache (24h TTL)
    ~/.fitmyllm/models/         Downloaded GGUF files + inventory

  Environment:
    FITMYLLM_API_KEY      API key
    FITMYLLM_API_URL      API base URL (default: https://www.fitmyllm.com/api/v1)
        """)
        return

    if "--version" in sys.argv or "-V" in sys.argv:
        print(f"fitmyllm {__version__}")
        return

    if "setup" in sys.argv:
        from .config import save_api_key, set_telemetry
        key = input("  API key: ").strip()
        if not key.startswith("fml_"):
            print("  Error: API key must start with 'fml_'")
            sys.exit(1)
        save_api_key(key)
        print("  Saved to ~/.fitmyllm/config.json\n")

        # Telemetry opt-in
        print("  [telemetry] Share anonymous speed data (tok/s, TTFT) while you chat?")
        print("  This helps improve speed predictions for your GPU and similar hardware.")
        print("  No message content is ever sent — only model name, GPU, and speed metrics.\n")
        choice = input("  Enable speed telemetry? [y/N]: ").strip().lower()
        set_telemetry(choice in ("y", "yes"))
        if choice in ("y", "yes"):
            print("  Telemetry enabled. Disable anytime: fitmyllm setup")
        else:
            print("  Telemetry disabled.")
        return

    # ── telemetry on/off ──
    if "telemetry" in sys.argv:
        from .config import is_telemetry_enabled, set_telemetry
        idx = sys.argv.index("telemetry")
        arg = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else ""
        if arg in ("on", "off"):
            set_telemetry(arg == "on")
            print(f"  Telemetry {'enabled' if arg == 'on' else 'disabled'}.")
        else:
            status = "on" if is_telemetry_enabled() else "off"
            print(f"  Telemetry is currently: {status}")
            print(f"  Usage: fitmyllm telemetry on|off")
        return

    # ── chat <model> ──
    if "chat" in sys.argv:
        idx = sys.argv.index("chat")
        tag = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else ""
        if not tag:
            print("  Usage: fitmyllm chat <model>")
            print("  Example: fitmyllm chat qwen3.5:4b-q8_0")
            sys.exit(1)
        _check_update()
        from .app import FitMyLLMApp
        app = FitMyLLMApp(direct_screen="chat", direct_args={"model_tag": tag})
        app.run()
        return

    # ── benchmark ──
    if "benchmark" in sys.argv:
        _check_update()
        from .app import FitMyLLMApp
        app = FitMyLLMApp(direct_screen="benchmark")
        app.run()
        return

    # ── my-benchmarks ──
    if "my-benchmarks" in sys.argv:
        _check_update()
        from .app import FitMyLLMApp
        app = FitMyLLMApp(direct_screen="my-benchmarks")
        app.run()
        return

    # Auto-update check (quick, non-blocking)
    _check_update()

    from .app import FitMyLLMApp
    app = FitMyLLMApp()
    result = app.run()
    if result:
        print(f"\n  Run: {result}\n")

if __name__ == "__main__":
    main()
