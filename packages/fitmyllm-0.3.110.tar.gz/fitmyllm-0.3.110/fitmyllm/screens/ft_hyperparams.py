"""Fine-tuning hyperparameter input screen — opened from the Enterprise FT tab."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Label, Select
from textual.containers import VerticalScroll
from textual.binding import Binding


PRESET_OPTIONS = [("Recommended", "recommended"), ("Custom", "custom")]

BATCH_OPTIONS = [("Auto (max that fits)", "auto"), ("1", "1"), ("2", "2"), ("4", "4"), ("8", "8")]
SEQ_OPTIONS = [("512", "512"), ("1024", "1024"), ("2048", "2048"), ("4096", "4096"), ("8192", "8192")]
RANK_OPTIONS = [("Auto (by model size)", "auto"), ("8", "8"), ("16", "16"), ("32", "32"), ("64", "64"), ("128", "128")]

LR_OPTIONS = [
    ("1e-5", "1e-5"), ("2e-5", "2e-5"), ("5e-5", "5e-5"),
    ("1e-4", "1e-4"), ("2e-4", "2e-4"), ("3e-4", "3e-4"),
    ("5e-4", "5e-4"), ("1e-3", "1e-3"),
]
SCHEDULER_OPTIONS = [
    ("cosine", "cosine"), ("linear", "linear"),
    ("constant", "constant"), ("constant + warmup", "constant_warmup"),
]
WARMUP_OPTIONS = [("none", "0"), ("1%", "0.01"), ("3%", "0.03"), ("5%", "0.05"), ("10%", "0.1")]
WEIGHT_DECAY_OPTIONS = [("0", "0"), ("0.001", "0.001"), ("0.01", "0.01"), ("0.1", "0.1")]
ALPHA_OPTIONS = [
    ("Auto (2×rank)", "auto"), ("8", "8"), ("16", "16"),
    ("32", "32"), ("64", "64"), ("128", "128"), ("256", "256"),
]
DROPOUT_OPTIONS = [("0", "0"), ("0.05", "0.05"), ("0.1", "0.1"), ("0.2", "0.2")]


def default_hyperparams() -> dict:
    """Default hyperparameters shown on first entry — 'recommended' preset."""
    return {
        "preset": "recommended",
        "batch_size": "auto",
        "seq_length": "2048",
        "lora_rank": "auto",
        "learning_rate": "2e-4",
        "lr_scheduler": "cosine",
        "warmup_ratio": "0.03",
        "weight_decay": "0",
        "lora_alpha": "auto",
        "lora_dropout": "0.05",
    }


def resolve_for_api(state: dict) -> dict:
    """Convert UI state into an ft_hyperparams body for the API.
    'auto' values are omitted so the server picks defaults."""
    out: dict = {}
    if state.get("batch_size") and state["batch_size"] != "auto":
        out["batch_size"] = int(state["batch_size"])
    if state.get("seq_length"):
        out["seq_length"] = int(state["seq_length"])
    if state.get("lora_rank") and state["lora_rank"] != "auto":
        out["lora_rank"] = int(state["lora_rank"])
    if state.get("preset") == "custom":
        out["learning_rate"] = float(state["learning_rate"])
        out["lr_scheduler"] = state["lr_scheduler"]
        out["warmup_ratio"] = float(state["warmup_ratio"])
        out["weight_decay"] = float(state["weight_decay"])
        if state.get("lora_alpha") and state["lora_alpha"] != "auto":
            out["lora_alpha"] = int(state["lora_alpha"])
        out["lora_dropout"] = float(state["lora_dropout"])
    return out


class FtHyperparamsScreen(Screen):
    """Screen for selecting fine-tuning training hyperparameters.

    Returns a dict via `self.dismiss(result)` when the user presses Enter.
    """

    DEFAULT_CSS = "FtHyperparamsScreen { layout: vertical; }"

    BINDINGS = [
        Binding("enter", "apply", "Apply", show=True),
        Binding("escape", "cancel", "Cancel", show=True),
    ]

    def __init__(self, initial: dict | None = None):
        super().__init__()
        self._initial = {**default_hyperparams(), **(initial or {})}

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with VerticalScroll():
            yield Static("\n  [bold cyan]Fine-tuning Hyperparameters[/]")
            yield Static("  [dim]Controls both the generated training code and VRAM/time estimates.[/]\n")

            yield Label("  Preset:")
            yield Select(PRESET_OPTIONS, value=self._initial["preset"], id="sel-preset", allow_blank=False)

            yield Static("\n  ─── [bold]Affect VRAM + time[/] ───")
            yield Label("  Batch size:")
            yield Select(BATCH_OPTIONS, value=self._initial["batch_size"], id="sel-batch", allow_blank=False)
            yield Label("  Sequence length:")
            yield Select(SEQ_OPTIONS, value=self._initial["seq_length"], id="sel-seq", allow_blank=False)
            yield Label("  LoRA rank:")
            yield Select(RANK_OPTIONS, value=self._initial["lora_rank"], id="sel-rank", allow_blank=False)

            yield Static("\n  ─── [bold]Convergence[/] [dim](used only when preset = Custom)[/] ───")
            yield Label("  Learning rate:")
            yield Select(LR_OPTIONS, value=self._initial["learning_rate"], id="sel-lr", allow_blank=False)
            yield Label("  LR scheduler:")
            yield Select(SCHEDULER_OPTIONS, value=self._initial["lr_scheduler"], id="sel-sched", allow_blank=False)
            yield Label("  Warmup ratio:")
            yield Select(WARMUP_OPTIONS, value=self._initial["warmup_ratio"], id="sel-warmup", allow_blank=False)
            yield Label("  Weight decay:")
            yield Select(WEIGHT_DECAY_OPTIONS, value=self._initial["weight_decay"], id="sel-wd", allow_blank=False)
            yield Label("  LoRA alpha:")
            yield Select(ALPHA_OPTIONS, value=self._initial["lora_alpha"], id="sel-alpha", allow_blank=False)
            yield Label("  LoRA dropout:")
            yield Select(DROPOUT_OPTIONS, value=self._initial["lora_dropout"], id="sel-dropout", allow_blank=False)

            yield Static("\n  [dim]Enter to apply · Esc to cancel[/]\n")
        yield Footer()

    def _collect(self) -> dict:
        def val(sel_id: str) -> str:
            return str(self.query_one(f"#{sel_id}", Select).value)
        return {
            "preset": val("sel-preset"),
            "batch_size": val("sel-batch"),
            "seq_length": val("sel-seq"),
            "lora_rank": val("sel-rank"),
            "learning_rate": val("sel-lr"),
            "lr_scheduler": val("sel-sched"),
            "warmup_ratio": val("sel-warmup"),
            "weight_decay": val("sel-wd"),
            "lora_alpha": val("sel-alpha"),
            "lora_dropout": val("sel-dropout"),
        }

    def action_apply(self) -> None:
        self.dismiss(self._collect())

    def action_cancel(self) -> None:
        self.dismiss(None)
