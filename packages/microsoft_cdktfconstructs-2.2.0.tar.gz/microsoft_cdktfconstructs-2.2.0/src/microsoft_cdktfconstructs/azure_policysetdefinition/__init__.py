r'''
# Azure Policy Set Definition (Initiative) Construct

This module provides a high-level TypeScript construct for managing Azure Policy Set Definitions (also known as Initiatives) using the Terraform CDK and Azure AZAPI provider.

## Features

* **Multiple API Version Support**: Supports 2023-04-01 (latest) and 2021-06-01 (for backward compatibility)
* **Automatic Version Resolution**: Uses the latest API version by default
* **Version Pinning**: Lock to a specific API version for stability
* **Type-Safe**: Full TypeScript support with comprehensive interfaces
* **JSII Compatible**: Can be used from TypeScript, Python, Java, and C#
* **Terraform Outputs**: Automatic creation of outputs for id, name, and policySetDefinitionId
* **Policy Definition References**: Support for including multiple policy definitions
* **Policy Definition Groups**: Organize policies within initiatives
* **Initiative Parameters**: Define parameters that can be used across policies in the set
* **Metadata Support**: Categorization with category, version, preview, and deprecated flags

## What is a Policy Set Definition (Initiative)?

A Policy Set Definition, also known as an "Initiative" in the Azure Portal, is a collection of policy definitions that are grouped together toward a specific goal. Initiatives simplify managing and assigning policies by grouping a set of policies as one single item.

**Key Benefits:**

* **Simplified Assignment**: Assign multiple policies at once
* **Compliance Grouping**: Group related compliance controls together
* **Parameter Inheritance**: Pass parameters to multiple policies from a single assignment
* **Organized Management**: Use groups to categorize policies within an initiative

## Supported API Versions

| Version | Status | Release Date | Notes |
|---------|--------|--------------|-------|
| 2023-04-01 | Active (Latest) | 2023-04-01 | Recommended for new deployments |
| 2021-06-01 | Active | 2021-06-01 | Stable release for backward compatibility |

## Installation

This module is part of the `@microsoft/terraform-cdk-constructs` package.

```bash
npm install @microsoft/terraform-cdk-constructs
```

## Basic Usage

### Simple Initiative with Built-in Policies

```python
import { App, TerraformStack } from "cdktn";
import { AzapiProvider } from "@microsoft/terraform-cdk-constructs/core-azure";
import { PolicySetDefinition } from "@microsoft/terraform-cdk-constructs/azure-policysetdefinition";

const app = new App();
const stack = new TerraformStack(app, "policy-stack");

// Configure the Azure provider
new AzapiProvider(stack, "azapi", {});

// Create a Policy Set Definition (Initiative)
const initiative = new PolicySetDefinition(stack, "security-initiative", {
  displayName: "Security Baseline Initiative",
  description: "Applies security baseline policies to ensure compliance",
  scope: "/subscriptions/00000000-0000-0000-0000-000000000000",
  policyDefinitions: [
    {
      // Audit VMs that do not use managed disks
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/06a78e20-9358-41c9-923c-fb736d382a4d",
      policyDefinitionReferenceId: "auditManagedDisks",
    },
    {
      // Audit location of resources
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c",
      policyDefinitionReferenceId: "allowedLocations",
    },
  ],
  tags: {
    environment: "production",
    compliance: "required",
  },
});

app.synth();
```

## Advanced Usage

### Initiative with Parameters

```python
const initiative = new PolicySetDefinition(stack, "parameterized-initiative", {
  displayName: "Tagging Governance Initiative",
  description: "Ensures all resources have required tags",
  scope: "/subscriptions/00000000-0000-0000-0000-000000000000",
  parameters: {
    requiredTagName: {
      type: "String",
      displayName: "Required Tag Name",
      description: "Name of the tag that must be present on resources",
      defaultValue: "costCenter",
    },
    requiredTagValue: {
      type: "String",
      displayName: "Required Tag Value",
      description: "Expected value for the required tag",
    },
  },
  policyDefinitions: [
    {
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/1e30110a-5ceb-460c-a204-c1c3969c6d62",
      policyDefinitionReferenceId: "requireTagOnResourceGroup",
      parameters: {
        tagName: { value: "[parameters('requiredTagName')]" },
      },
    },
    {
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/726aca4c-86e9-4b04-b0c5-073027359532",
      policyDefinitionReferenceId: "inheritTagFromResourceGroup",
      parameters: {
        tagName: { value: "[parameters('requiredTagName')]" },
      },
    },
  ],
});
```

### Initiative with Policy Groups

```python
const initiative = new PolicySetDefinition(stack, "grouped-initiative", {
  displayName: "Comprehensive Compliance Initiative",
  description: "Security and compliance policies organized by category",
  scope: "/subscriptions/00000000-0000-0000-0000-000000000000",
  metadata: {
    category: "Regulatory Compliance",
    version: "2.0.0",
  },
  policyDefinitionGroups: [
    {
      name: "NetworkSecurity",
      displayName: "Network Security Policies",
      category: "Network",
      description: "Policies for network security controls",
    },
    {
      name: "DataProtection",
      displayName: "Data Protection Policies",
      category: "Data",
      description: "Policies for data protection and encryption",
    },
    {
      name: "IdentityAndAccess",
      displayName: "Identity & Access Policies",
      category: "IAM",
      description: "Policies for identity and access management",
    },
  ],
  policyDefinitions: [
    {
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/policy-1",
      policyDefinitionReferenceId: "networkSecurityPolicy1",
      groupNames: ["NetworkSecurity"],
    },
    {
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/policy-2",
      policyDefinitionReferenceId: "dataProtectionPolicy1",
      groupNames: ["DataProtection"],
    },
    {
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/policy-3",
      policyDefinitionReferenceId: "crossCuttingPolicy",
      groupNames: ["NetworkSecurity", "DataProtection"],
    },
  ],
});
```

### Combining Custom and Built-in Policies

```python
import { PolicyDefinition } from "@microsoft/terraform-cdk-constructs/azure-policydefinition";

// Create a custom policy definition first
const customPolicy = new PolicyDefinition(stack, "custom-audit-policy", {
  displayName: "Audit Custom Tag",
  scope: "/subscriptions/00000000-0000-0000-0000-000000000000",
  policyRule: {
    if: {
      field: "tags['department']",
      exists: "false",
    },
    then: {
      effect: "audit",
    },
  },
});

// Create an initiative that combines the custom policy with built-in policies
const initiative = new PolicySetDefinition(stack, "combined-initiative", {
  displayName: "Combined Policies Initiative",
  scope: "/subscriptions/00000000-0000-0000-0000-000000000000",
  policyDefinitions: [
    {
      // Reference the custom policy
      policyDefinitionId: customPolicy.id,
      policyDefinitionReferenceId: "customAuditTag",
    },
    {
      // Built-in policy
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/06a78e20-9358-41c9-923c-fb736d382a4d",
      policyDefinitionReferenceId: "builtInAuditVMs",
    },
  ],
});
```

### Management Group Scope

```python
const mgInitiative = new PolicySetDefinition(stack, "mg-initiative", {
  displayName: "Organization-wide Initiative",
  description: "Applies to all subscriptions in the management group",
  scope: "/providers/Microsoft.Management/managementGroups/my-management-group",
  policyDefinitions: [
    {
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/policy-1",
      policyDefinitionReferenceId: "orgPolicy1",
    },
  ],
});
```

### Pinning to a Specific API Version

```python
const initiative = new PolicySetDefinition(stack, "pinned-initiative", {
  displayName: "Stable Initiative",
  scope: "/subscriptions/00000000-0000-0000-0000-000000000000",
  apiVersion: "2021-06-01", // Pin to specific version
  policyDefinitions: [
    {
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/policy-1",
    },
  ],
});
```

### Using Outputs for Policy Assignment

```python
import { TerraformOutput } from "cdktn";

const initiative = new PolicySetDefinition(stack, "initiative", {
  displayName: "My Initiative",
  scope: subscriptionId,
  policyDefinitions: [
    {
      policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/policy-1",
    },
  ],
});

// Use the initiative ID in a policy assignment
// The policySetDefinitionId property can be referenced from other resources
console.log(initiative.policySetDefinitionId); // Terraform interpolation string

// Create outputs for cross-stack references
new TerraformOutput(stack, "initiative-id", {
  value: initiative.idOutput,
});
```

## API Reference

### PolicySetDefinitionProps

Configuration properties for the Policy Set Definition construct.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `name` | `string` | No | Resource name. Auto-generated as UUID if not provided. |
| `displayName` | `string` | Yes | Display name shown in Azure Portal. |
| `description` | `string` | No | Description of the initiative. |
| `scope` | `string` | Yes | Subscription or management group scope for the definition. |
| `policyType` | `"BuiltIn" \| "Custom" \| "Static"` | No | Type of policy set. Default: "Custom". |
| `metadata` | `PolicySetMetadata` | No | Metadata for categorization. |
| `parameters` | `{ [key: string]: PolicySetParameterDefinition }` | No | Initiative parameter definitions. |
| `policyDefinitions` | `PolicyDefinitionReference[]` | Yes | Array of policy definition references. |
| `policyDefinitionGroups` | `PolicyDefinitionGroup[]` | No | Groups for organizing policies. |
| `tags` | `{ [key: string]: string }` | No | Resource tags. |
| `apiVersion` | `string` | No | Pin to a specific API version. |

### PolicyDefinitionReference

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `policyDefinitionId` | `string` | Yes | ID of the policy definition to include. |
| `policyDefinitionReferenceId` | `string` | No | Unique ID within the set. |
| `parameters` | `{ [key: string]: PolicyParameterValue }` | No | Parameter values for this policy. |
| `groupNames` | `string[]` | No | Groups this policy belongs to. |

### PolicyDefinitionGroup

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `name` | `string` | Yes | Unique group name within the set. |
| `displayName` | `string` | No | Display name in Azure Portal. |
| `category` | `string` | No | Category for organization. |
| `description` | `string` | No | Description of the group. |

### PolicySetMetadata

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `category` | `string` | No | Category for Azure Portal organization. |
| `version` | `string` | No | Version of the initiative. |
| `preview` | `boolean` | No | Whether this is a preview initiative. |
| `deprecated` | `boolean` | No | Whether this initiative is deprecated. |

### PolicySetParameterDefinition

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `type` | `string` | Yes | Data type: String, Array, Object, Boolean, Integer, Float, DateTime. |
| `displayName` | `string` | No | Display name in Azure Portal. |
| `description` | `string` | No | Parameter description. |
| `defaultValue` | `any` | No | Default value for the parameter. |
| `allowedValues` | `any[]` | No | Allowed values for the parameter. |
| `metadata` | `object` | No | Additional metadata (e.g., strongType). |

### Public Properties

| Property | Type | Description |
|----------|------|-------------|
| `id` | `string` | The Azure resource ID of the policy set definition. |
| `policySetDefinitionId` | `string` | Alias for id, for use in policy assignments. |
| `displayName` | `string` | The display name of the initiative. |
| `policyType` | `string` | The policy type (Custom, BuiltIn, Static). |
| `policyDefinitionCount` | `number` | Number of policy definitions in this set. |
| `props` | `PolicySetDefinitionProps` | The original input properties. |
| `resolvedApiVersion` | `string` | The API version being used. |

### Outputs

The construct automatically creates Terraform outputs:

* `id`: The policy set definition resource ID
* `name`: The policy set definition resource name
* `policy_set_definition_id`: The ID for use in policy assignments

## Best Practices

### 1. Use Descriptive Reference IDs

```python
policyDefinitions: [
  {
    policyDefinitionId: "...",
    policyDefinitionReferenceId: "auditStorageAccountEncryption", // Descriptive name
  },
]
```

### 2. Organize with Groups

Use policy definition groups to categorize policies for better management and compliance reporting:

```python
policyDefinitionGroups: [
  { name: "Security", category: "Security Center" },
  { name: "Compliance", category: "Regulatory" },
  { name: "CostManagement", category: "Cost" },
],
```

### 3. Use Initiative Parameters

Define parameters at the initiative level to allow flexibility during assignment:

```python
parameters: {
  effect: {
    type: "String",
    defaultValue: "Audit",
    allowedValues: ["Audit", "Deny", "Disabled"],
  },
},
```

### 4. Version Your Initiatives

Use metadata to track initiative versions:

```python
metadata: {
  category: "Security",
  version: "1.0.0",
},
```

### 5. Use Management Group Scope for Enterprise

For organization-wide initiatives, create them at management group level:

```python
scope: "/providers/Microsoft.Management/managementGroups/root-mg",
```

## Troubleshooting

### Common Issues

1. **Empty policyDefinitions**: At least one policy definition reference is required.
2. **Invalid Group Reference**: Ensure all groupNames in policy definitions exist in policyDefinitionGroups.
3. **Duplicate Group Names**: Each group name must be unique within the policy set.
4. **Missing policyDefinitionId**: Every policy definition reference requires a policyDefinitionId.
5. **API Version Errors**: Ensure the version is 2023-04-01 or 2021-06-01.

## Related Constructs

* [`PolicyDefinition`](../azure-policydefinition/README.md) - Create custom policy definitions
* [`PolicyAssignment`](../azure-policyassignment/README.md) - Assign policies and initiatives
* [`ResourceGroup`](../azure-resourcegroup/README.md) - Azure Resource Groups

## Additional Resources

* [Azure Policy Documentation](https://learn.microsoft.com/en-us/azure/governance/policy/overview)
* [Azure Policy Initiative Definition](https://learn.microsoft.com/en-us/azure/governance/policy/concepts/initiative-definition-structure)
* [Azure REST API Reference](https://learn.microsoft.com/en-us/rest/api/policy/policy-set-definitions)
* [Terraform CDK Documentation](https://developer.hashicorp.com/terraform/cdktf)

## Contributing

Contributions are welcome! Please see the [Contributing Guide](../../CONTRIBUTING.md) for details.

## License

This project is licensed under the MIT License - see the [LICENSE](../../LICENSE) file for details.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8
from ..core_azure import (
    ApiSchema as _ApiSchema_5ce0490e,
    AzapiResource as _AzapiResource_7e7f5b39,
    AzapiResourceProps as _AzapiResourceProps_141a2340,
    MonitoringConfig as _MonitoringConfig_7c28df74,
)


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicyDefinitionGroup",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "additional_metadata_id": "additionalMetadataId",
        "category": "category",
        "description": "description",
        "display_name": "displayName",
    },
)
class PolicyDefinitionGroup:
    def __init__(
        self,
        *,
        name: builtins.str,
        additional_metadata_id: typing.Optional[builtins.str] = None,
        category: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        display_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''A group for organizing policy definitions within a policy set.

        Groups provide a way to categorize and organize policies within an initiative
        for better management and compliance reporting.

        :param name: The name of the group (must be unique within the policy set). This name is referenced by policy definitions to indicate membership.
        :param additional_metadata_id: Additional metadata for the group.
        :param category: The category this group belongs to. Categories help organize groups and are displayed in the Azure Portal.
        :param description: A description of the group's purpose.
        :param display_name: The display name of the group shown in Azure Portal.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0be55d192f80f008dd84888ed7981b6288bcbdcf040a06852b6a21a7309f200b)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument additional_metadata_id", value=additional_metadata_id, expected_type=type_hints["additional_metadata_id"])
            check_type(argname="argument category", value=category, expected_type=type_hints["category"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument display_name", value=display_name, expected_type=type_hints["display_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }
        if additional_metadata_id is not None:
            self._values["additional_metadata_id"] = additional_metadata_id
        if category is not None:
            self._values["category"] = category
        if description is not None:
            self._values["description"] = description
        if display_name is not None:
            self._values["display_name"] = display_name

    @builtins.property
    def name(self) -> builtins.str:
        '''The name of the group (must be unique within the policy set).

        This name is referenced by policy definitions to indicate membership.

        Example::

            "Security"
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_metadata_id(self) -> typing.Optional[builtins.str]:
        '''Additional metadata for the group.'''
        result = self._values.get("additional_metadata_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def category(self) -> typing.Optional[builtins.str]:
        '''The category this group belongs to.

        Categories help organize groups and are displayed in the Azure Portal.

        Example::

            "Security Center"
        '''
        result = self._values.get("category")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''A description of the group's purpose.

        Example::

            "Policies related to security configuration and compliance"
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def display_name(self) -> typing.Optional[builtins.str]:
        '''The display name of the group shown in Azure Portal.

        Example::

            "Security Policies"
        '''
        result = self._values.get("display_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicyDefinitionGroup(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicyDefinitionReference",
    jsii_struct_bases=[],
    name_mapping={
        "policy_definition_id": "policyDefinitionId",
        "group_names": "groupNames",
        "parameters": "parameters",
        "policy_definition_reference_id": "policyDefinitionReferenceId",
    },
)
class PolicyDefinitionReference:
    def __init__(
        self,
        *,
        policy_definition_id: builtins.str,
        group_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        parameters: typing.Optional[typing.Mapping[builtins.str, typing.Union["PolicyParameterValue", typing.Dict[builtins.str, typing.Any]]]] = None,
        policy_definition_reference_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''A reference to a policy definition within a policy set.

        This defines which policy definitions are included in the initiative
        and how they are configured with parameters.

        :param policy_definition_id: The ID of the policy definition to include in the set. This can be: - A built-in policy: /providers/Microsoft.Authorization/policyDefinitions/{policyDefinitionId} - A custom policy at subscription level: /subscriptions/{subscriptionId}/providers/Microsoft.Authorization/policyDefinitions/{policyDefinitionId} - A custom policy at management group level: /providers/Microsoft.Management/managementGroups/{managementGroupId}/providers/Microsoft.Authorization/policyDefinitions/{policyDefinitionId}
        :param group_names: Group names that this policy definition belongs to. Groups help organize policies within an initiative and can be used for compliance reporting and management.
        :param parameters: Parameter values for this policy definition. These values override the default parameter values in the policy definition. Parameters can reference initiative-level parameters using the format: { "value": "[parameters('initiativeParameterName')]" }
        :param policy_definition_reference_id: A unique identifier for this policy definition reference within the set. This ID is used to reference this specific policy in the initiative and must be unique within the policy set definition.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff93cbbf4b1f90be5c69a6d94a87fa39b6600e783078f6f09d76940b737a000d)
            check_type(argname="argument policy_definition_id", value=policy_definition_id, expected_type=type_hints["policy_definition_id"])
            check_type(argname="argument group_names", value=group_names, expected_type=type_hints["group_names"])
            check_type(argname="argument parameters", value=parameters, expected_type=type_hints["parameters"])
            check_type(argname="argument policy_definition_reference_id", value=policy_definition_reference_id, expected_type=type_hints["policy_definition_reference_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "policy_definition_id": policy_definition_id,
        }
        if group_names is not None:
            self._values["group_names"] = group_names
        if parameters is not None:
            self._values["parameters"] = parameters
        if policy_definition_reference_id is not None:
            self._values["policy_definition_reference_id"] = policy_definition_reference_id

    @builtins.property
    def policy_definition_id(self) -> builtins.str:
        '''The ID of the policy definition to include in the set.

        This can be:

        - A built-in policy: /providers/Microsoft.Authorization/policyDefinitions/{policyDefinitionId}
        - A custom policy at subscription level: /subscriptions/{subscriptionId}/providers/Microsoft.Authorization/policyDefinitions/{policyDefinitionId}
        - A custom policy at management group level: /providers/Microsoft.Management/managementGroups/{managementGroupId}/providers/Microsoft.Authorization/policyDefinitions/{policyDefinitionId}

        Example::

            "/providers/Microsoft.Authorization/policyDefinitions/06a78e20-9358-41c9-923c-fb736d382a4d"
        '''
        result = self._values.get("policy_definition_id")
        assert result is not None, "Required property 'policy_definition_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def group_names(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Group names that this policy definition belongs to.

        Groups help organize policies within an initiative and can be used
        for compliance reporting and management.

        Example::

            ["Security", "Compliance"]
        '''
        result = self._values.get("group_names")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def parameters(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, "PolicyParameterValue"]]:
        '''Parameter values for this policy definition.

        These values override the default parameter values in the policy definition.
        Parameters can reference initiative-level parameters using the format:
        { "value": "[parameters('initiativeParameterName')]" }

        Example::

            { "tagName": { "value": "environment" }, "tagValue": { "value": "[parameters('requiredTagValue')]" } }
        '''
        result = self._values.get("parameters")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, "PolicyParameterValue"]], result)

    @builtins.property
    def policy_definition_reference_id(self) -> typing.Optional[builtins.str]:
        '''A unique identifier for this policy definition reference within the set.

        This ID is used to reference this specific policy in the initiative
        and must be unique within the policy set definition.

        Example::

            "auditVMsWithoutTags"
        '''
        result = self._values.get("policy_definition_reference_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicyDefinitionReference(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicyParameterValue",
    jsii_struct_bases=[],
    name_mapping={"value": "value"},
)
class PolicyParameterValue:
    def __init__(self, *, value: typing.Any) -> None:
        '''A parameter value, either a direct value or a reference.

        :param value: The value of the parameter. Can be a direct value or a reference to an initiative parameter using the format: "[parameters('parameterName')]"
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8fd478e4617ff36749fdc7813761b5b6a434473d6cd72d0e1ed1c5f2fcf78173)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "value": value,
        }

    @builtins.property
    def value(self) -> typing.Any:
        '''The value of the parameter.

        Can be a direct value or a reference to an initiative parameter
        using the format: "[parameters('parameterName')]"
        '''
        result = self._values.get("value")
        assert result is not None, "Required property 'value' is missing"
        return typing.cast(typing.Any, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicyParameterValue(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class PolicySetDefinition(
    _AzapiResource_7e7f5b39,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicySetDefinition",
):
    '''Unified Azure Policy Set Definition (Initiative) implementation.

    This class provides a single, version-aware implementation for managing Azure
    Policy Set Definitions. It automatically handles version resolution, schema validation,
    and property transformation.

    Policy Set Definitions allow you to group multiple policy definitions together
    and assign them as a single unit (also known as "Initiatives" in Azure Portal).

    Note: Policy set definitions are created at subscription or management group scope.
    They do not have a location property as they are not region-specific.

    Example::

        const initiative = new PolicySetDefinition(this, "security-initiative", {
          displayName: "Security Baseline",
          scope: "/subscriptions/00000000-0000-0000-0000-000000000000",
          policyDefinitions: [
            {
              policyDefinitionId: "/providers/Microsoft.Authorization/policyDefinitions/abc123",
              policyDefinitionReferenceId: "auditVMsWithoutExtensions",
            },
          ],
        });
    '''

    def __init__(
        self,
        scope_: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        display_name: builtins.str,
        policy_definitions: typing.Sequence[typing.Union["PolicyDefinitionReference", typing.Dict[builtins.str, typing.Any]]],
        scope: builtins.str,
        description: typing.Optional[builtins.str] = None,
        metadata: typing.Optional[typing.Union["PolicySetMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
        parameters: typing.Optional[typing.Mapping[builtins.str, typing.Union["PolicySetParameterDefinition", typing.Dict[builtins.str, typing.Any]]]] = None,
        policy_definition_groups: typing.Optional[typing.Sequence[typing.Union["PolicyDefinitionGroup", typing.Dict[builtins.str, typing.Any]]]] = None,
        policy_type: typing.Optional[builtins.str] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Creates a new Azure Policy Set Definition using the AzapiResource framework.

        The constructor automatically handles version resolution, schema registration,
        validation, and resource creation.

        :param scope_: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param display_name: The display name of the policy set definition. This is the name shown in the Azure Portal. Required property.
        :param policy_definitions: Array of policy definition references. Each reference specifies a policy definition to include in the set along with its parameter values and group memberships. Required property.
        :param scope: The scope at which to create the policy set definition. This can be: - A subscription: /subscriptions/{subscriptionId} - A management group: /providers/Microsoft.Management/managementGroups/{managementGroupId}
        :param description: Description of the policy set definition.
        :param metadata: Metadata for the policy set definition. Includes category, version, preview, and deprecated flags.
        :param parameters: Parameter definitions for the policy set. These parameters can be referenced by policy definitions in the set using the format: "[parameters('parameterName')]"
        :param policy_definition_groups: Groups for organizing policy definitions in the set. Groups help categorize policies for management and compliance reporting.
        :param policy_type: The type of policy set definition. Default: "Custom"
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e0aef0fe0fd124eb903574ed76db126c36fb0aa74fe02b2228942b538e095585)
            check_type(argname="argument scope_", value=scope_, expected_type=type_hints["scope_"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = PolicySetDefinitionProps(
            display_name=display_name,
            policy_definitions=policy_definitions,
            scope=scope,
            description=description,
            metadata=metadata,
            parameters=parameters,
            policy_definition_groups=policy_definition_groups,
            policy_type=policy_type,
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            monitoring=monitoring,
            name=name,
            tags=tags,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope_, id, props])

    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> "_ApiSchema_5ce0490e":
        '''Gets the API schema for the resolved version Uses the framework's schema resolution to get the appropriate schema.'''
        return typing.cast("_ApiSchema_5ce0490e", jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call Transforms the input properties into the JSON format expected by Azure REST API.

        Note: Policy set definitions do not have a location property as they are
        scope-specific resources deployed at subscription or management group level.

        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__02a9745e6c3da39a9afcecaf6d7db626cab7e4c339e7eda85b47a9c47b69019c)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [props]))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified Returns the most recent stable version as the default.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="resolveName")
    def _resolve_name(
        self,
        *,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> builtins.str:
        '''Overrides the name resolution to generate deterministic GUIDs for policy set definitions.

        Policy set definitions can use custom names or auto-generated GUIDs.
        This implementation generates a deterministic UUID based on the policy set definition's
        key properties if no name is provided.

        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        props = _AzapiResourceProps_141a2340(
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            monitoring=monitoring,
            name=name,
            tags=tags,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        return typing.cast(builtins.str, jsii.invoke(self, "resolveName", [props]))

    @jsii.member(jsii_name="resolveParentId")
    def _resolve_parent_id(self, props: typing.Any) -> builtins.str:
        '''Resolves the parent resource ID for Policy Set Definition Policy Set Definitions are created at subscription or management group scope.

        :param props: - The resource properties.

        :return: The parent resource ID (the scope)
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__720d8b03e065932e344aaa5135bf1954936b370b24cf070546d572bc18e405fb)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(builtins.str, jsii.invoke(self, "resolveParentId", [props]))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for Policy Set Definitions.'''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="displayName")
    def display_name(self) -> builtins.str:
        '''Get the display name of the policy set definition.'''
        return typing.cast(builtins.str, jsii.get(self, "displayName"))

    @builtins.property
    @jsii.member(jsii_name="idOutput")
    def id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "idOutput"))

    @builtins.property
    @jsii.member(jsii_name="nameOutput")
    def name_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "nameOutput"))

    @builtins.property
    @jsii.member(jsii_name="policyDefinitionCount")
    def policy_definition_count(self) -> jsii.Number:
        '''Get the number of policy definitions in this set.'''
        return typing.cast(jsii.Number, jsii.get(self, "policyDefinitionCount"))

    @builtins.property
    @jsii.member(jsii_name="policySetDefinitionId")
    def policy_set_definition_id(self) -> builtins.str:
        '''Get the full resource identifier for use in policy assignments Alias for the id property.'''
        return typing.cast(builtins.str, jsii.get(self, "policySetDefinitionId"))

    @builtins.property
    @jsii.member(jsii_name="policySetDefinitionIdOutput")
    def policy_set_definition_id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "policySetDefinitionIdOutput"))

    @builtins.property
    @jsii.member(jsii_name="policyType")
    def policy_type(self) -> builtins.str:
        '''Get the policy type.'''
        return typing.cast(builtins.str, jsii.get(self, "policyType"))

    @builtins.property
    @jsii.member(jsii_name="props")
    def props(self) -> "PolicySetDefinitionProps":
        '''The input properties for this Policy Set Definition instance.'''
        return typing.cast("PolicySetDefinitionProps", jsii.get(self, "props"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicySetDefinitionBody",
    jsii_struct_bases=[],
    name_mapping={"properties": "properties"},
)
class PolicySetDefinitionBody:
    def __init__(
        self,
        *,
        properties: typing.Union["PolicySetDefinitionProperties", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''The resource body interface for Azure Policy Set Definition API calls This matches the Azure REST API schema for policy set definitions.

        :param properties: The properties of the policy set definition.
        '''
        if isinstance(properties, dict):
            properties = PolicySetDefinitionProperties(**properties)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__070f68f7278aefef6157383fc4ed81c7cdffe41b059a0ece937e170ff9f41c37)
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "properties": properties,
        }

    @builtins.property
    def properties(self) -> "PolicySetDefinitionProperties":
        '''The properties of the policy set definition.'''
        result = self._values.get("properties")
        assert result is not None, "Required property 'properties' is missing"
        return typing.cast("PolicySetDefinitionProperties", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicySetDefinitionBody(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicySetDefinitionProperties",
    jsii_struct_bases=[],
    name_mapping={
        "display_name": "displayName",
        "policy_definitions": "policyDefinitions",
        "description": "description",
        "metadata": "metadata",
        "parameters": "parameters",
        "policy_definition_groups": "policyDefinitionGroups",
        "policy_type": "policyType",
    },
)
class PolicySetDefinitionProperties:
    def __init__(
        self,
        *,
        display_name: builtins.str,
        policy_definitions: typing.Sequence[typing.Union["PolicyDefinitionReference", typing.Dict[builtins.str, typing.Any]]],
        description: typing.Optional[builtins.str] = None,
        metadata: typing.Optional[typing.Union["PolicySetMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
        parameters: typing.Optional[typing.Mapping[builtins.str, typing.Union["PolicySetParameterDefinition", typing.Dict[builtins.str, typing.Any]]]] = None,
        policy_definition_groups: typing.Optional[typing.Sequence[typing.Union["PolicyDefinitionGroup", typing.Dict[builtins.str, typing.Any]]]] = None,
        policy_type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Properties interface for Azure Policy Set Definition This is required for JSII compliance to support multi-language code generation.

        :param display_name: The display name of the policy set definition.
        :param policy_definitions: Array of policy definition references.
        :param description: Description of the policy set definition.
        :param metadata: Metadata for the policy set definition.
        :param parameters: Parameter definitions for the policy set.
        :param policy_definition_groups: Groups for organizing policy definitions.
        :param policy_type: The type of policy set definition.
        '''
        if isinstance(metadata, dict):
            metadata = PolicySetMetadata(**metadata)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bca577d34e77cf0f9adb625b863a7b4157f4fbc1c28adce4c8e451081b9050b2)
            check_type(argname="argument display_name", value=display_name, expected_type=type_hints["display_name"])
            check_type(argname="argument policy_definitions", value=policy_definitions, expected_type=type_hints["policy_definitions"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
            check_type(argname="argument parameters", value=parameters, expected_type=type_hints["parameters"])
            check_type(argname="argument policy_definition_groups", value=policy_definition_groups, expected_type=type_hints["policy_definition_groups"])
            check_type(argname="argument policy_type", value=policy_type, expected_type=type_hints["policy_type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "display_name": display_name,
            "policy_definitions": policy_definitions,
        }
        if description is not None:
            self._values["description"] = description
        if metadata is not None:
            self._values["metadata"] = metadata
        if parameters is not None:
            self._values["parameters"] = parameters
        if policy_definition_groups is not None:
            self._values["policy_definition_groups"] = policy_definition_groups
        if policy_type is not None:
            self._values["policy_type"] = policy_type

    @builtins.property
    def display_name(self) -> builtins.str:
        '''The display name of the policy set definition.'''
        result = self._values.get("display_name")
        assert result is not None, "Required property 'display_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def policy_definitions(self) -> typing.List["PolicyDefinitionReference"]:
        '''Array of policy definition references.'''
        result = self._values.get("policy_definitions")
        assert result is not None, "Required property 'policy_definitions' is missing"
        return typing.cast(typing.List["PolicyDefinitionReference"], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Description of the policy set definition.'''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def metadata(self) -> typing.Optional["PolicySetMetadata"]:
        '''Metadata for the policy set definition.'''
        result = self._values.get("metadata")
        return typing.cast(typing.Optional["PolicySetMetadata"], result)

    @builtins.property
    def parameters(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, "PolicySetParameterDefinition"]]:
        '''Parameter definitions for the policy set.'''
        result = self._values.get("parameters")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, "PolicySetParameterDefinition"]], result)

    @builtins.property
    def policy_definition_groups(
        self,
    ) -> typing.Optional[typing.List["PolicyDefinitionGroup"]]:
        '''Groups for organizing policy definitions.'''
        result = self._values.get("policy_definition_groups")
        return typing.cast(typing.Optional[typing.List["PolicyDefinitionGroup"]], result)

    @builtins.property
    def policy_type(self) -> typing.Optional[builtins.str]:
        '''The type of policy set definition.'''
        result = self._values.get("policy_type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicySetDefinitionProperties(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicySetDefinitionProps",
    jsii_struct_bases=[_AzapiResourceProps_141a2340],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "monitoring": "monitoring",
        "name": "name",
        "tags": "tags",
        "display_name": "displayName",
        "policy_definitions": "policyDefinitions",
        "scope": "scope",
        "description": "description",
        "metadata": "metadata",
        "parameters": "parameters",
        "policy_definition_groups": "policyDefinitionGroups",
        "policy_type": "policyType",
    },
)
class PolicySetDefinitionProps(_AzapiResourceProps_141a2340):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        display_name: builtins.str,
        policy_definitions: typing.Sequence[typing.Union["PolicyDefinitionReference", typing.Dict[builtins.str, typing.Any]]],
        scope: builtins.str,
        description: typing.Optional[builtins.str] = None,
        metadata: typing.Optional[typing.Union["PolicySetMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
        parameters: typing.Optional[typing.Mapping[builtins.str, typing.Union["PolicySetParameterDefinition", typing.Dict[builtins.str, typing.Any]]]] = None,
        policy_definition_groups: typing.Optional[typing.Sequence[typing.Union["PolicyDefinitionGroup", typing.Dict[builtins.str, typing.Any]]]] = None,
        policy_type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Properties for the unified Azure Policy Set Definition.

        Extends AzapiResourceProps with Policy Set Definition specific properties

        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param display_name: The display name of the policy set definition. This is the name shown in the Azure Portal. Required property.
        :param policy_definitions: Array of policy definition references. Each reference specifies a policy definition to include in the set along with its parameter values and group memberships. Required property.
        :param scope: The scope at which to create the policy set definition. This can be: - A subscription: /subscriptions/{subscriptionId} - A management group: /providers/Microsoft.Management/managementGroups/{managementGroupId}
        :param description: Description of the policy set definition.
        :param metadata: Metadata for the policy set definition. Includes category, version, preview, and deprecated flags.
        :param parameters: Parameter definitions for the policy set. These parameters can be referenced by policy definitions in the set using the format: "[parameters('parameterName')]"
        :param policy_definition_groups: Groups for organizing policy definitions in the set. Groups help categorize policies for management and compliance reporting.
        :param policy_type: The type of policy set definition. Default: "Custom"
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(monitoring, dict):
            monitoring = _MonitoringConfig_7c28df74(**monitoring)
        if isinstance(metadata, dict):
            metadata = PolicySetMetadata(**metadata)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c199b0815f2152d205815bad5acfe8f71bdf85b288478154c905e3396d6957e1)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument display_name", value=display_name, expected_type=type_hints["display_name"])
            check_type(argname="argument policy_definitions", value=policy_definitions, expected_type=type_hints["policy_definitions"])
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
            check_type(argname="argument parameters", value=parameters, expected_type=type_hints["parameters"])
            check_type(argname="argument policy_definition_groups", value=policy_definition_groups, expected_type=type_hints["policy_definition_groups"])
            check_type(argname="argument policy_type", value=policy_type, expected_type=type_hints["policy_type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "display_name": display_name,
            "policy_definitions": policy_definitions,
            "scope": scope,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if monitoring is not None:
            self._values["monitoring"] = monitoring
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags
        if description is not None:
            self._values["description"] = description
        if metadata is not None:
            self._values["metadata"] = metadata
        if parameters is not None:
            self._values["parameters"] = parameters
        if policy_definition_groups is not None:
            self._values["policy_definition_groups"] = policy_definition_groups
        if policy_type is not None:
            self._values["policy_type"] = policy_type

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.

        :default: Varies by resource type - see specific resource documentation

        :remarks:

        Location handling varies by resource type:

        - **Top-level resources**: Most require an explicit location (e.g., "eastus", "westus")
        - **Global resources**: Some use "global" as location (e.g., Private DNS Zones)
        - **Child resources**: Inherit location from parent and should NOT set this property

        Each resource type may provide its own default through the ``resolveLocation()`` method.
        If no location is specified and no default exists, resource creation may fail.

        Example::

            // Child resource (Subnet) - do not set location
            // location: undefined (inherited from parent Virtual Network)
        '''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def monitoring(self) -> typing.Optional["_MonitoringConfig_7c28df74"]:
        '''Monitoring configuration for this resource.

        Enables integrated monitoring with diagnostic settings, metric alerts,
        and activity log alerts. All monitoring is optional and disabled by default.

        Example::

            monitoring: {
              enabled: true,
              diagnosticSettings: {
                workspaceId: logAnalytics.id,
                metrics: ['AllMetrics'],
                logs: ['AuditLogs']
              },
              metricAlerts: [{
                name: 'high-cpu-alert',
                severity: 2,
                scopes: [], // Automatically set to this resource
                criteria: { ... },
                actions: [{ actionGroupId: actionGroup.id }]
              }]
            }
        '''
        result = self._values.get("monitoring")
        return typing.cast(typing.Optional["_MonitoringConfig_7c28df74"], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def display_name(self) -> builtins.str:
        '''The display name of the policy set definition.

        This is the name shown in the Azure Portal.
        Required property.

        Example::

            "Security Baseline Initiative"
        '''
        result = self._values.get("display_name")
        assert result is not None, "Required property 'display_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def policy_definitions(self) -> typing.List["PolicyDefinitionReference"]:
        '''Array of policy definition references.

        Each reference specifies a policy definition to include in the set
        along with its parameter values and group memberships.
        Required property.
        '''
        result = self._values.get("policy_definitions")
        assert result is not None, "Required property 'policy_definitions' is missing"
        return typing.cast(typing.List["PolicyDefinitionReference"], result)

    @builtins.property
    def scope(self) -> builtins.str:
        '''The scope at which to create the policy set definition.

        This can be:

        - A subscription: /subscriptions/{subscriptionId}
        - A management group: /providers/Microsoft.Management/managementGroups/{managementGroupId}

        Example::

            "/providers/Microsoft.Management/managementGroups/my-management-group"
        '''
        result = self._values.get("scope")
        assert result is not None, "Required property 'scope' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Description of the policy set definition.

        Example::

            "This initiative applies a set of security policies to ensure baseline compliance."
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def metadata(self) -> typing.Optional["PolicySetMetadata"]:
        '''Metadata for the policy set definition.

        Includes category, version, preview, and deprecated flags.
        '''
        result = self._values.get("metadata")
        return typing.cast(typing.Optional["PolicySetMetadata"], result)

    @builtins.property
    def parameters(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, "PolicySetParameterDefinition"]]:
        '''Parameter definitions for the policy set.

        These parameters can be referenced by policy definitions in the set
        using the format: "[parameters('parameterName')]"
        '''
        result = self._values.get("parameters")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, "PolicySetParameterDefinition"]], result)

    @builtins.property
    def policy_definition_groups(
        self,
    ) -> typing.Optional[typing.List["PolicyDefinitionGroup"]]:
        '''Groups for organizing policy definitions in the set.

        Groups help categorize policies for management and compliance reporting.
        '''
        result = self._values.get("policy_definition_groups")
        return typing.cast(typing.Optional[typing.List["PolicyDefinitionGroup"]], result)

    @builtins.property
    def policy_type(self) -> typing.Optional[builtins.str]:
        '''The type of policy set definition.

        :default: "Custom"
        '''
        result = self._values.get("policy_type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicySetDefinitionProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicySetMetadata",
    jsii_struct_bases=[],
    name_mapping={
        "category": "category",
        "deprecated": "deprecated",
        "preview": "preview",
        "version": "version",
    },
)
class PolicySetMetadata:
    def __init__(
        self,
        *,
        category: typing.Optional[builtins.str] = None,
        deprecated: typing.Optional[builtins.bool] = None,
        preview: typing.Optional[builtins.bool] = None,
        version: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Metadata for the policy set definition.

        Metadata provides additional information about the policy set
        without affecting its evaluation logic.

        :param category: The category of the policy set for Azure Portal organization.
        :param deprecated: Whether this policy set is deprecated. Default: false
        :param preview: Whether this policy set is in preview. Default: false
        :param version: The version of the policy set definition.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4079f1abe6a3f3ff80582f4b8a7bbb3393b0c58bc6c39ccc9cdc4f9fd6ed133a)
            check_type(argname="argument category", value=category, expected_type=type_hints["category"])
            check_type(argname="argument deprecated", value=deprecated, expected_type=type_hints["deprecated"])
            check_type(argname="argument preview", value=preview, expected_type=type_hints["preview"])
            check_type(argname="argument version", value=version, expected_type=type_hints["version"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if category is not None:
            self._values["category"] = category
        if deprecated is not None:
            self._values["deprecated"] = deprecated
        if preview is not None:
            self._values["preview"] = preview
        if version is not None:
            self._values["version"] = version

    @builtins.property
    def category(self) -> typing.Optional[builtins.str]:
        '''The category of the policy set for Azure Portal organization.

        Example::

            "Security Center"
        '''
        result = self._values.get("category")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def deprecated(self) -> typing.Optional[builtins.bool]:
        '''Whether this policy set is deprecated.

        :default: false
        '''
        result = self._values.get("deprecated")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def preview(self) -> typing.Optional[builtins.bool]:
        '''Whether this policy set is in preview.

        :default: false
        '''
        result = self._values.get("preview")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def version(self) -> typing.Optional[builtins.str]:
        '''The version of the policy set definition.

        Example::

            "1.0.0"
        '''
        result = self._values.get("version")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicySetMetadata(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicySetParameterDefinition",
    jsii_struct_bases=[],
    name_mapping={
        "type": "type",
        "allowed_values": "allowedValues",
        "default_value": "defaultValue",
        "description": "description",
        "display_name": "displayName",
        "metadata": "metadata",
    },
)
class PolicySetParameterDefinition:
    def __init__(
        self,
        *,
        type: builtins.str,
        allowed_values: typing.Optional[typing.Sequence[typing.Any]] = None,
        default_value: typing.Any = None,
        description: typing.Optional[builtins.str] = None,
        display_name: typing.Optional[builtins.str] = None,
        metadata: typing.Optional[typing.Union["PolicySetParameterMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Parameter definition for the policy set.

        These parameters can be referenced by policy definitions within the set.

        :param type: The data type of the parameter.
        :param allowed_values: Allowed values for the parameter.
        :param default_value: Default value for the parameter.
        :param description: Description of the parameter.
        :param display_name: Display name for the parameter in Azure Portal.
        :param metadata: Metadata for the parameter (e.g., strongType for Azure Portal integration).
        '''
        if isinstance(metadata, dict):
            metadata = PolicySetParameterMetadata(**metadata)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ae0c695aaa5d8b1f9bfb00360367f62ecafc21f5e5da249db404771a8c8624d)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument allowed_values", value=allowed_values, expected_type=type_hints["allowed_values"])
            check_type(argname="argument default_value", value=default_value, expected_type=type_hints["default_value"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument display_name", value=display_name, expected_type=type_hints["display_name"])
            check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if allowed_values is not None:
            self._values["allowed_values"] = allowed_values
        if default_value is not None:
            self._values["default_value"] = default_value
        if description is not None:
            self._values["description"] = description
        if display_name is not None:
            self._values["display_name"] = display_name
        if metadata is not None:
            self._values["metadata"] = metadata

    @builtins.property
    def type(self) -> builtins.str:
        '''The data type of the parameter.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def allowed_values(self) -> typing.Optional[typing.List[typing.Any]]:
        '''Allowed values for the parameter.'''
        result = self._values.get("allowed_values")
        return typing.cast(typing.Optional[typing.List[typing.Any]], result)

    @builtins.property
    def default_value(self) -> typing.Any:
        '''Default value for the parameter.'''
        result = self._values.get("default_value")
        return typing.cast(typing.Any, result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Description of the parameter.'''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def display_name(self) -> typing.Optional[builtins.str]:
        '''Display name for the parameter in Azure Portal.'''
        result = self._values.get("display_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def metadata(self) -> typing.Optional["PolicySetParameterMetadata"]:
        '''Metadata for the parameter (e.g., strongType for Azure Portal integration).'''
        result = self._values.get("metadata")
        return typing.cast(typing.Optional["PolicySetParameterMetadata"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicySetParameterDefinition(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_policysetdefinition.PolicySetParameterMetadata",
    jsii_struct_bases=[],
    name_mapping={
        "description": "description",
        "display_name": "displayName",
        "strong_type": "strongType",
    },
)
class PolicySetParameterMetadata:
    def __init__(
        self,
        *,
        description: typing.Optional[builtins.str] = None,
        display_name: typing.Optional[builtins.str] = None,
        strong_type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Metadata for a policy set parameter.

        Provides additional information for Azure Portal integration.

        :param description: Description in Azure Portal.
        :param display_name: Display name in Azure Portal.
        :param strong_type: Strong type for Azure Portal resource picker integration.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2221bbd8ec6c9315730568c7ccb93a1675e05cb445b9a8e39cebc391321b1a4)
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument display_name", value=display_name, expected_type=type_hints["display_name"])
            check_type(argname="argument strong_type", value=strong_type, expected_type=type_hints["strong_type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if description is not None:
            self._values["description"] = description
        if display_name is not None:
            self._values["display_name"] = display_name
        if strong_type is not None:
            self._values["strong_type"] = strong_type

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Description in Azure Portal.'''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def display_name(self) -> typing.Optional[builtins.str]:
        '''Display name in Azure Portal.'''
        result = self._values.get("display_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def strong_type(self) -> typing.Optional[builtins.str]:
        '''Strong type for Azure Portal resource picker integration.'''
        result = self._values.get("strong_type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PolicySetParameterMetadata(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "PolicyDefinitionGroup",
    "PolicyDefinitionReference",
    "PolicyParameterValue",
    "PolicySetDefinition",
    "PolicySetDefinitionBody",
    "PolicySetDefinitionProperties",
    "PolicySetDefinitionProps",
    "PolicySetMetadata",
    "PolicySetParameterDefinition",
    "PolicySetParameterMetadata",
]

publication.publish()

def _typecheckingstub__0be55d192f80f008dd84888ed7981b6288bcbdcf040a06852b6a21a7309f200b(
    *,
    name: builtins.str,
    additional_metadata_id: typing.Optional[builtins.str] = None,
    category: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    display_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff93cbbf4b1f90be5c69a6d94a87fa39b6600e783078f6f09d76940b737a000d(
    *,
    policy_definition_id: builtins.str,
    group_names: typing.Optional[typing.Sequence[builtins.str]] = None,
    parameters: typing.Optional[typing.Mapping[builtins.str, typing.Union[PolicyParameterValue, typing.Dict[builtins.str, typing.Any]]]] = None,
    policy_definition_reference_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8fd478e4617ff36749fdc7813761b5b6a434473d6cd72d0e1ed1c5f2fcf78173(
    *,
    value: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e0aef0fe0fd124eb903574ed76db126c36fb0aa74fe02b2228942b538e095585(
    scope_: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    display_name: builtins.str,
    policy_definitions: typing.Sequence[typing.Union[PolicyDefinitionReference, typing.Dict[builtins.str, typing.Any]]],
    scope: builtins.str,
    description: typing.Optional[builtins.str] = None,
    metadata: typing.Optional[typing.Union[PolicySetMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    parameters: typing.Optional[typing.Mapping[builtins.str, typing.Union[PolicySetParameterDefinition, typing.Dict[builtins.str, typing.Any]]]] = None,
    policy_definition_groups: typing.Optional[typing.Sequence[typing.Union[PolicyDefinitionGroup, typing.Dict[builtins.str, typing.Any]]]] = None,
    policy_type: typing.Optional[builtins.str] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__02a9745e6c3da39a9afcecaf6d7db626cab7e4c339e7eda85b47a9c47b69019c(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__720d8b03e065932e344aaa5135bf1954936b370b24cf070546d572bc18e405fb(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__070f68f7278aefef6157383fc4ed81c7cdffe41b059a0ece937e170ff9f41c37(
    *,
    properties: typing.Union[PolicySetDefinitionProperties, typing.Dict[builtins.str, typing.Any]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bca577d34e77cf0f9adb625b863a7b4157f4fbc1c28adce4c8e451081b9050b2(
    *,
    display_name: builtins.str,
    policy_definitions: typing.Sequence[typing.Union[PolicyDefinitionReference, typing.Dict[builtins.str, typing.Any]]],
    description: typing.Optional[builtins.str] = None,
    metadata: typing.Optional[typing.Union[PolicySetMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    parameters: typing.Optional[typing.Mapping[builtins.str, typing.Union[PolicySetParameterDefinition, typing.Dict[builtins.str, typing.Any]]]] = None,
    policy_definition_groups: typing.Optional[typing.Sequence[typing.Union[PolicyDefinitionGroup, typing.Dict[builtins.str, typing.Any]]]] = None,
    policy_type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c199b0815f2152d205815bad5acfe8f71bdf85b288478154c905e3396d6957e1(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    display_name: builtins.str,
    policy_definitions: typing.Sequence[typing.Union[PolicyDefinitionReference, typing.Dict[builtins.str, typing.Any]]],
    scope: builtins.str,
    description: typing.Optional[builtins.str] = None,
    metadata: typing.Optional[typing.Union[PolicySetMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    parameters: typing.Optional[typing.Mapping[builtins.str, typing.Union[PolicySetParameterDefinition, typing.Dict[builtins.str, typing.Any]]]] = None,
    policy_definition_groups: typing.Optional[typing.Sequence[typing.Union[PolicyDefinitionGroup, typing.Dict[builtins.str, typing.Any]]]] = None,
    policy_type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4079f1abe6a3f3ff80582f4b8a7bbb3393b0c58bc6c39ccc9cdc4f9fd6ed133a(
    *,
    category: typing.Optional[builtins.str] = None,
    deprecated: typing.Optional[builtins.bool] = None,
    preview: typing.Optional[builtins.bool] = None,
    version: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ae0c695aaa5d8b1f9bfb00360367f62ecafc21f5e5da249db404771a8c8624d(
    *,
    type: builtins.str,
    allowed_values: typing.Optional[typing.Sequence[typing.Any]] = None,
    default_value: typing.Any = None,
    description: typing.Optional[builtins.str] = None,
    display_name: typing.Optional[builtins.str] = None,
    metadata: typing.Optional[typing.Union[PolicySetParameterMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2221bbd8ec6c9315730568c7ccb93a1675e05cb445b9a8e39cebc391321b1a4(
    *,
    description: typing.Optional[builtins.str] = None,
    display_name: typing.Optional[builtins.str] = None,
    strong_type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass
