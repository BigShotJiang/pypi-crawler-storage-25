r'''
# Azure Log Analytics Workspace Construct

This module provides a high-level TypeScript construct for managing Azure Log Analytics Workspaces using the Terraform CDK and Azure AZAPI provider.

## Features

* **Multiple API Version Support**: Supports 2023-09-01 (latest) and 2022-10-01 (for backward compatibility)
* **Automatic Version Resolution**: Uses the latest API version by default
* **Version Pinning**: Lock to a specific API version for stability
* **Type-Safe**: Full TypeScript support with comprehensive interfaces
* **JSII Compatible**: Can be used from TypeScript, Python, Java, and C#
* **Terraform Outputs**: Automatic creation of outputs for id, name, workspaceId, and customerId
* **Tag Management**: Built-in methods for managing resource tags

## Supported API Versions

| Version | Status | Release Date | Notes |
|---------|--------|--------------|-------|
| 2023-09-01 | Active (Latest) | 2023-09-01 | Recommended for new deployments, includes Data Collection Rule support |
| 2022-10-01 | Active | 2022-10-01 | Stable release for backward compatibility |

## Installation

This module is part of the `@microsoft/terraform-cdk-constructs` package.

```bash
npm install @microsoft/terraform-cdk-constructs
```

## Basic Usage

### Simple Log Analytics Workspace

```python
import { App, TerraformStack } from "cdktn";
import { AzapiProvider } from "@microsoft/terraform-cdk-constructs/core-azure";
import { ResourceGroup } from "@microsoft/terraform-cdk-constructs/azure-resourcegroup";
import { LogAnalyticsWorkspace } from "@microsoft/terraform-cdk-constructs/azure-loganalyticsworkspace";

const app = new App();
const stack = new TerraformStack(app, "log-analytics-stack");

// Configure the Azure provider
new AzapiProvider(stack, "azapi", {});

// Create a resource group
const resourceGroup = new ResourceGroup(stack, "rg", {
  name: "my-resource-group",
  location: "eastus",
});

// Create a Log Analytics Workspace
const workspace = new LogAnalyticsWorkspace(stack, "workspace", {
  name: "my-log-analytics",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  tags: {
    environment: "production",
    project: "monitoring",
  },
});

app.synth();
```

## Advanced Usage

### Custom Retention Period

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace-retention", {
  name: "workspace-with-retention",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  retentionInDays: 90, // Keep data for 90 days (range: 30-730)
});
```

### PerGB2018 Pricing (Pay-as-you-go)

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace-pergb", {
  name: "workspace-pergb",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  sku: {
    name: "PerGB2018",
  },
  retentionInDays: 60,
});
```

### Capacity Reservation Pricing

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace-capacity", {
  name: "workspace-capacity-reservation",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  sku: {
    name: "CapacityReservation",
    capacityReservationLevel: 500, // Valid values: 100, 200, 300, 400, 500, 1000, 2000, 5000
  },
  retentionInDays: 365,
});
```

### Daily Volume Cap (Workspace Capping)

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace-capped", {
  name: "workspace-with-cap",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  workspaceCapping: {
    dailyQuotaGb: 100, // Stop ingestion after 100GB per day
  },
});
```

### Private Network Access

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace-private", {
  name: "workspace-private",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  publicNetworkAccessForIngestion: "Disabled",
  publicNetworkAccessForQuery: "Disabled",
});
```

### Workspace Features

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace-features", {
  name: "workspace-with-features",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  features: {
    enableDataExport: true,
    immediatePurgeDataOn30Days: false,
    disableLocalAuth: true,
    enableLogAccessUsingOnlyResourcePermissions: true,
  },
});
```

### Managed Identity

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace-identity", {
  name: "workspace-with-identity",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  identity: {
    type: "SystemAssigned",
  },
});
```

### Pinning to a Specific API Version

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace-pinned", {
  name: "workspace-stable",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  apiVersion: "2022-10-01", // Pin to specific version
});
```

### Using Outputs

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace", {
  name: "my-workspace",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
});

// Access workspace ID for use in other resources (e.g., Diagnostic Settings)
console.log(workspace.id); // Terraform interpolation string

// Use outputs for cross-stack references
new TerraformOutput(stack, "workspace-id", {
  value: workspace.idOutput,
});

new TerraformOutput(stack, "workspace-customer-id", {
  value: workspace.customerIdOutput,
});
```

## API Reference

### LogAnalyticsWorkspaceProps

Configuration properties for the Log Analytics Workspace construct.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `name` | `string` | No* | Name of the workspace. If not provided, uses the construct ID. Must be 4-63 characters, alphanumeric and hyphens. |
| `location` | `string` | Yes | Azure region where the workspace will be created. |
| `resourceGroupId` | `string` | Yes | Resource group ID where the workspace will be created. |
| `retentionInDays` | `number` | No | Data retention in days (30-730). Default: 30. |
| `sku` | `LogAnalyticsWorkspaceSku` | No | SKU configuration. Default: { name: "PerGB2018" }. |
| `workspaceCapping` | `LogAnalyticsWorkspaceCapping` | No | Daily volume cap configuration. |
| `publicNetworkAccessForIngestion` | `"Enabled" \| "Disabled"` | No | Network access for data ingestion. Default: "Enabled". |
| `publicNetworkAccessForQuery` | `"Enabled" \| "Disabled"` | No | Network access for queries. Default: "Enabled". |
| `features` | `LogAnalyticsWorkspaceFeatures` | No | Workspace feature flags. |
| `forceCmkForQuery` | `boolean` | No | Require customer-managed keys for saved searches/alerts. |
| `defaultDataCollectionRuleResourceId` | `string` | No | Default DCR resource ID (API 2023-09-01+). |
| `identity` | `LogAnalyticsWorkspaceIdentity` | No | Managed identity configuration. |
| `tags` | `{ [key: string]: string }` | No | Resource tags. |
| `apiVersion` | `string` | No | Pin to a specific API version. |

### LogAnalyticsWorkspaceSku

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `name` | `string` | Yes | SKU name: "Free", "Standard", "Premium", "PerNode", "PerGB2018", "Standalone", "CapacityReservation" |
| `capacityReservationLevel` | `number` | No | Capacity in GB/day for CapacityReservation SKU. Valid: 100, 200, 300, 400, 500, 1000, 2000, 5000. |

### LogAnalyticsWorkspaceCapping

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `dailyQuotaGb` | `number` | Yes | Daily volume cap in GB. Use -1 for no cap. |

### LogAnalyticsWorkspaceFeatures

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `enableDataExport` | `boolean` | No | Enable data export capability. |
| `immediatePurgeDataOn30Days` | `boolean` | No | Purge data immediately after 30 days. |
| `disableLocalAuth` | `boolean` | No | Disable local authentication. |
| `enableLogAccessUsingOnlyResourcePermissions` | `boolean` | No | Enable resource-based access only. |

### LogAnalyticsWorkspaceIdentity

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `type` | `string` | Yes | Identity type: "SystemAssigned", "UserAssigned", "SystemAssigned,UserAssigned", "None" |
| `userAssignedIdentities` | `object` | No | User-assigned identity resource IDs. |

### Public Properties

| Property | Type | Description |
|----------|------|-------------|
| `id` | `string` | The Azure resource ID of the workspace. |
| `props` | `LogAnalyticsWorkspaceProps` | The original input properties. |
| `resolvedApiVersion` | `string` | The API version being used. |

### Outputs

The construct automatically creates Terraform outputs:

* `id`: The workspace resource ID
* `name`: The workspace name
* `workspace_id`: The workspace unique identifier (GUID)
* `customer_id`: The workspace customer ID (same as workspace_id)

### Methods

| Method | Parameters | Description |
|--------|-----------|-------------|
| `addTag` | `key: string, value: string` | Add a tag to the workspace. |
| `addAccess` | `objectId: string, roleDefinitionName: string` | Add RBAC role assignment. |

## Best Practices

### 1. Use PerGB2018 for Most Workloads

Unless you have specific requirements, the pay-as-you-go model is most cost-effective:

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace", {
  name: "my-workspace",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  sku: { name: "PerGB2018" },
});
```

### 2. Set Appropriate Retention

Balance between compliance requirements and cost:

```python
// Production: longer retention for compliance
const prodWorkspace = new LogAnalyticsWorkspace(stack, "prod-workspace", {
  name: "prod-logs",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  retentionInDays: 365,
});

// Development: shorter retention to save costs
const devWorkspace = new LogAnalyticsWorkspace(stack, "dev-workspace", {
  name: "dev-logs",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  retentionInDays: 30,
});
```

### 3. Use Daily Cap for Cost Control

Prevent unexpected charges from log spikes:

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace", {
  name: "cost-controlled",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  workspaceCapping: {
    dailyQuotaGb: 50, // Stop at 50GB/day
  },
});
```

### 4. Apply Consistent Tags

```python
const workspace = new LogAnalyticsWorkspace(stack, "workspace", {
  name: "my-workspace",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  tags: {
    environment: "production",
    "cost-center": "platform-team",
    "managed-by": "terraform",
  },
});
```

## Troubleshooting

### Common Issues

1. **Retention Out of Range**: Ensure `retentionInDays` is between 30 and 730.
2. **Invalid Capacity Reservation Level**: Valid values are 100, 200, 300, 400, 500, 1000, 2000, 5000.
3. **Name Validation**: Workspace names must be 4-63 characters, start and end with alphanumeric, and contain only letters, numbers, and hyphens.
4. **API Version Errors**: Ensure the version is 2023-09-01 or 2022-10-01.

## Related Constructs

* [`ResourceGroup`](../azure-resourcegroup/README.md) - Azure Resource Groups
* [`DiagnosticSettings`](../azure-diagnosticsettings/README.md) - Send logs to this workspace
* [`MetricAlert`](../azure-metricalert/README.md) - Create alerts based on workspace metrics

## Additional Resources

* [Azure Log Analytics Documentation](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/log-analytics-overview)
* [Log Analytics Pricing](https://azure.microsoft.com/en-us/pricing/details/monitor/)
* [Azure REST API Reference](https://learn.microsoft.com/en-us/rest/api/loganalytics/)
* [Terraform CDK Documentation](https://developer.hashicorp.com/terraform/cdktf)

## Contributing

Contributions are welcome! Please see the [Contributing Guide](../../CONTRIBUTING.md) for details.

## License

This project is licensed under the MIT License - see the [LICENSE](../../LICENSE) file for details.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8
from ..core_azure import (
    ApiSchema as _ApiSchema_5ce0490e,
    AzapiResource as _AzapiResource_7e7f5b39,
    AzapiResourceProps as _AzapiResourceProps_141a2340,
    MonitoringConfig as _MonitoringConfig_7c28df74,
)


class LogAnalyticsWorkspace(
    _AzapiResource_7e7f5b39,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.azure_loganalyticsworkspace.LogAnalyticsWorkspace",
):
    '''Unified Azure Log Analytics Workspace implementation.

    This class provides a single, version-aware implementation that automatically handles version
    resolution, schema validation, and property transformation while maintaining full JSII compliance.

    Log Analytics Workspace is the central destination for log data from Azure resources,
    applications, and on-premises infrastructure. It enables querying, analysis, and
    visualization of log data using Kusto Query Language (KQL).

    Example::

        // Log Analytics Workspace with capacity reservation:
        const workspace = new LogAnalyticsWorkspace(this, "high-volume-workspace", {
          name: "high-volume-logs",
          location: "eastus",
          resourceGroupId: resourceGroup.id,
          retentionInDays: 365,
          sku: {
            name: "CapacityReservation",
            capacityReservationLevel: 500
          },
          workspaceCapping: {
            dailyQuotaGb: 100
          }
        });
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        resource_group_id: builtins.str,
        default_data_collection_rule_resource_id: typing.Optional[builtins.str] = None,
        features: typing.Optional[typing.Union["LogAnalyticsWorkspaceFeatures", typing.Dict[builtins.str, typing.Any]]] = None,
        force_cmk_for_query: typing.Optional[builtins.bool] = None,
        identity: typing.Optional[typing.Union["LogAnalyticsWorkspaceIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        public_network_access_for_ingestion: typing.Optional[builtins.str] = None,
        public_network_access_for_query: typing.Optional[builtins.str] = None,
        retention_in_days: typing.Optional[jsii.Number] = None,
        sku: typing.Optional[typing.Union["LogAnalyticsWorkspaceSku", typing.Dict[builtins.str, typing.Any]]] = None,
        workspace_capping: typing.Optional[typing.Union["LogAnalyticsWorkspaceCapping", typing.Dict[builtins.str, typing.Any]]] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Creates a new Azure Log Analytics Workspace using the AzapiResource framework.

        The constructor automatically handles version resolution, schema registration,
        validation, and resource creation.

        :param scope: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param resource_group_id: Resource Group ID where the workspace will be created The workspace will be created as a child of this resource group.
        :param default_data_collection_rule_resource_id: Resource ID of the default Data Collection Rule. Associates a default DCR with the workspace for data collection. Only available in API version 2023-09-01 and later.
        :param features: Workspace features configuration. Enables or disables specific workspace features like data export, immediate purge, and local authentication.
        :param force_cmk_for_query: Whether customer-managed keys are required for saved searches and alerts. When enabled, all saved searches and alerts must use customer-managed keys.
        :param identity: Managed identity configuration for the workspace. Enables managed identity authentication for the workspace.
        :param public_network_access_for_ingestion: Public network access for data ingestion. Controls whether data can be ingested over the public internet. Default: "Enabled"
        :param public_network_access_for_query: Public network access for querying data. Controls whether queries can be executed over the public internet. Default: "Enabled"
        :param retention_in_days: Data retention period in days. Values between 30 and 730 are supported for pay-as-you-go pricing. Free tier is limited to 7 days. Default: 30
        :param sku: SKU configuration for the workspace. Determines pricing tier and capabilities of the workspace. Default: { name: "PerGB2018" }
        :param workspace_capping: Daily volume cap for data ingestion. When the daily cap is reached, data ingestion stops until the next day. A value of dailyQuotaGb: -1 means no cap.
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ffcb9b035ddd368de7f0b3ac1a8059c13fc52654627efeb2660748f085b8b6b3)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = LogAnalyticsWorkspaceProps(
            resource_group_id=resource_group_id,
            default_data_collection_rule_resource_id=default_data_collection_rule_resource_id,
            features=features,
            force_cmk_for_query=force_cmk_for_query,
            identity=identity,
            public_network_access_for_ingestion=public_network_access_for_ingestion,
            public_network_access_for_query=public_network_access_for_query,
            retention_in_days=retention_in_days,
            sku=sku,
            workspace_capping=workspace_capping,
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            monitoring=monitoring,
            name=name,
            tags=tags,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> "_ApiSchema_5ce0490e":
        '''Gets the API schema for the resolved version Uses the framework's schema resolution to get the appropriate schema.'''
        return typing.cast("_ApiSchema_5ce0490e", jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call Transforms the input properties into the JSON format expected by Azure REST API.

        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f3e034b254613f244add1d11808ea0df49c566ffb2e3264e7f888ad9da5b5e19)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [props]))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified Returns the latest stable version as the default.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="requiresLocation")
    def _requires_location(self) -> builtins.bool:
        '''Indicates that this resource type requires a location.'''
        return typing.cast(builtins.bool, jsii.invoke(self, "requiresLocation", []))

    @jsii.member(jsii_name="resolveParentId")
    def _resolve_parent_id(self, props: typing.Any) -> builtins.str:
        '''Resolves the parent resource ID for Log Analytics Workspace Log Analytics Workspace is a top-level resource within a resource group.

        :param props: - The resource properties.

        :return: The parent resource ID (the resource group)
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf545375ea34f528c0906d3cfbe5320e9787cd88a471b9d9bece4fbc4a51a88b)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(builtins.str, jsii.invoke(self, "resolveParentId", [props]))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for Log Analytics Workspace.'''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="customerIdOutput")
    def customer_id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "customerIdOutput"))

    @builtins.property
    @jsii.member(jsii_name="idOutput")
    def id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "idOutput"))

    @builtins.property
    @jsii.member(jsii_name="nameOutput")
    def name_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "nameOutput"))

    @builtins.property
    @jsii.member(jsii_name="props")
    def props(self) -> "LogAnalyticsWorkspaceProps":
        '''The input properties for this Log Analytics Workspace instance.'''
        return typing.cast("LogAnalyticsWorkspaceProps", jsii.get(self, "props"))

    @builtins.property
    @jsii.member(jsii_name="workspaceIdOutput")
    def workspace_id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "workspaceIdOutput"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_loganalyticsworkspace.LogAnalyticsWorkspaceBody",
    jsii_struct_bases=[],
    name_mapping={"properties": "properties", "identity": "identity"},
)
class LogAnalyticsWorkspaceBody:
    def __init__(
        self,
        *,
        properties: typing.Union["LogAnalyticsWorkspaceBodyProperties", typing.Dict[builtins.str, typing.Any]],
        identity: typing.Optional[typing.Union["LogAnalyticsWorkspaceIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''The resource body interface for Azure Log Analytics Workspace API calls.

        :param properties: 
        :param identity: 
        '''
        if isinstance(properties, dict):
            properties = LogAnalyticsWorkspaceBodyProperties(**properties)
        if isinstance(identity, dict):
            identity = LogAnalyticsWorkspaceIdentity(**identity)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__960a152857cc2899d33a53b93f758a4ba1faa55fe843f4aa586a68f22661909a)
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "properties": properties,
        }
        if identity is not None:
            self._values["identity"] = identity

    @builtins.property
    def properties(self) -> "LogAnalyticsWorkspaceBodyProperties":
        result = self._values.get("properties")
        assert result is not None, "Required property 'properties' is missing"
        return typing.cast("LogAnalyticsWorkspaceBodyProperties", result)

    @builtins.property
    def identity(self) -> typing.Optional["LogAnalyticsWorkspaceIdentity"]:
        result = self._values.get("identity")
        return typing.cast(typing.Optional["LogAnalyticsWorkspaceIdentity"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LogAnalyticsWorkspaceBody(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_loganalyticsworkspace.LogAnalyticsWorkspaceBodyProperties",
    jsii_struct_bases=[],
    name_mapping={
        "default_data_collection_rule_resource_id": "defaultDataCollectionRuleResourceId",
        "features": "features",
        "force_cmk_for_query": "forceCmkForQuery",
        "public_network_access_for_ingestion": "publicNetworkAccessForIngestion",
        "public_network_access_for_query": "publicNetworkAccessForQuery",
        "retention_in_days": "retentionInDays",
        "sku": "sku",
        "workspace_capping": "workspaceCapping",
    },
)
class LogAnalyticsWorkspaceBodyProperties:
    def __init__(
        self,
        *,
        default_data_collection_rule_resource_id: typing.Optional[builtins.str] = None,
        features: typing.Optional[typing.Union["LogAnalyticsWorkspaceFeatures", typing.Dict[builtins.str, typing.Any]]] = None,
        force_cmk_for_query: typing.Optional[builtins.bool] = None,
        public_network_access_for_ingestion: typing.Optional[builtins.str] = None,
        public_network_access_for_query: typing.Optional[builtins.str] = None,
        retention_in_days: typing.Optional[jsii.Number] = None,
        sku: typing.Optional[typing.Union["LogAnalyticsWorkspaceSku", typing.Dict[builtins.str, typing.Any]]] = None,
        workspace_capping: typing.Optional[typing.Union["LogAnalyticsWorkspaceCapping", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Properties for the Log Analytics Workspace request body.

        :param default_data_collection_rule_resource_id: 
        :param features: 
        :param force_cmk_for_query: 
        :param public_network_access_for_ingestion: 
        :param public_network_access_for_query: 
        :param retention_in_days: 
        :param sku: 
        :param workspace_capping: 
        '''
        if isinstance(features, dict):
            features = LogAnalyticsWorkspaceFeatures(**features)
        if isinstance(sku, dict):
            sku = LogAnalyticsWorkspaceSku(**sku)
        if isinstance(workspace_capping, dict):
            workspace_capping = LogAnalyticsWorkspaceCapping(**workspace_capping)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dc1302c059ad34ae7b5c0c119a11967896d64c178381753310157c8289cb998b)
            check_type(argname="argument default_data_collection_rule_resource_id", value=default_data_collection_rule_resource_id, expected_type=type_hints["default_data_collection_rule_resource_id"])
            check_type(argname="argument features", value=features, expected_type=type_hints["features"])
            check_type(argname="argument force_cmk_for_query", value=force_cmk_for_query, expected_type=type_hints["force_cmk_for_query"])
            check_type(argname="argument public_network_access_for_ingestion", value=public_network_access_for_ingestion, expected_type=type_hints["public_network_access_for_ingestion"])
            check_type(argname="argument public_network_access_for_query", value=public_network_access_for_query, expected_type=type_hints["public_network_access_for_query"])
            check_type(argname="argument retention_in_days", value=retention_in_days, expected_type=type_hints["retention_in_days"])
            check_type(argname="argument sku", value=sku, expected_type=type_hints["sku"])
            check_type(argname="argument workspace_capping", value=workspace_capping, expected_type=type_hints["workspace_capping"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if default_data_collection_rule_resource_id is not None:
            self._values["default_data_collection_rule_resource_id"] = default_data_collection_rule_resource_id
        if features is not None:
            self._values["features"] = features
        if force_cmk_for_query is not None:
            self._values["force_cmk_for_query"] = force_cmk_for_query
        if public_network_access_for_ingestion is not None:
            self._values["public_network_access_for_ingestion"] = public_network_access_for_ingestion
        if public_network_access_for_query is not None:
            self._values["public_network_access_for_query"] = public_network_access_for_query
        if retention_in_days is not None:
            self._values["retention_in_days"] = retention_in_days
        if sku is not None:
            self._values["sku"] = sku
        if workspace_capping is not None:
            self._values["workspace_capping"] = workspace_capping

    @builtins.property
    def default_data_collection_rule_resource_id(self) -> typing.Optional[builtins.str]:
        result = self._values.get("default_data_collection_rule_resource_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def features(self) -> typing.Optional["LogAnalyticsWorkspaceFeatures"]:
        result = self._values.get("features")
        return typing.cast(typing.Optional["LogAnalyticsWorkspaceFeatures"], result)

    @builtins.property
    def force_cmk_for_query(self) -> typing.Optional[builtins.bool]:
        result = self._values.get("force_cmk_for_query")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def public_network_access_for_ingestion(self) -> typing.Optional[builtins.str]:
        result = self._values.get("public_network_access_for_ingestion")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def public_network_access_for_query(self) -> typing.Optional[builtins.str]:
        result = self._values.get("public_network_access_for_query")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def retention_in_days(self) -> typing.Optional[jsii.Number]:
        result = self._values.get("retention_in_days")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def sku(self) -> typing.Optional["LogAnalyticsWorkspaceSku"]:
        result = self._values.get("sku")
        return typing.cast(typing.Optional["LogAnalyticsWorkspaceSku"], result)

    @builtins.property
    def workspace_capping(self) -> typing.Optional["LogAnalyticsWorkspaceCapping"]:
        result = self._values.get("workspace_capping")
        return typing.cast(typing.Optional["LogAnalyticsWorkspaceCapping"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LogAnalyticsWorkspaceBodyProperties(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_loganalyticsworkspace.LogAnalyticsWorkspaceCapping",
    jsii_struct_bases=[],
    name_mapping={"daily_quota_gb": "dailyQuotaGb"},
)
class LogAnalyticsWorkspaceCapping:
    def __init__(self, *, daily_quota_gb: jsii.Number) -> None:
        '''Workspace capping configuration for daily data ingestion limits.

        :param daily_quota_gb: Daily volume cap in GB A value of -1 means no cap.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e340bf85531587043873071390dc6cecf0969d4b9685e8df4f25d91e150ea04)
            check_type(argname="argument daily_quota_gb", value=daily_quota_gb, expected_type=type_hints["daily_quota_gb"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "daily_quota_gb": daily_quota_gb,
        }

    @builtins.property
    def daily_quota_gb(self) -> jsii.Number:
        '''Daily volume cap in GB A value of -1 means no cap.'''
        result = self._values.get("daily_quota_gb")
        assert result is not None, "Required property 'daily_quota_gb' is missing"
        return typing.cast(jsii.Number, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LogAnalyticsWorkspaceCapping(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_loganalyticsworkspace.LogAnalyticsWorkspaceFeatures",
    jsii_struct_bases=[],
    name_mapping={
        "disable_local_auth": "disableLocalAuth",
        "enable_data_export": "enableDataExport",
        "enable_log_access_using_only_resource_permissions": "enableLogAccessUsingOnlyResourcePermissions",
        "immediate_purge_data_on30_days": "immediatePurgeDataOn30Days",
    },
)
class LogAnalyticsWorkspaceFeatures:
    def __init__(
        self,
        *,
        disable_local_auth: typing.Optional[builtins.bool] = None,
        enable_data_export: typing.Optional[builtins.bool] = None,
        enable_log_access_using_only_resource_permissions: typing.Optional[builtins.bool] = None,
        immediate_purge_data_on30_days: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''Workspace features configuration.

        :param disable_local_auth: Flag indicating whether log access using AADIAM is disabled.
        :param enable_data_export: Flag indicating whether data export is enabled.
        :param enable_log_access_using_only_resource_permissions: Flag indicating whether cluster resource permissions are enabled.
        :param immediate_purge_data_on30_days: Flag indicating whether data should be immediately purged after 30 days instead of the configured retention period.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c6285c0e0b993d3c4f6d1b3fb98e47f2fa852019f67c69e45a193e72b1966d6)
            check_type(argname="argument disable_local_auth", value=disable_local_auth, expected_type=type_hints["disable_local_auth"])
            check_type(argname="argument enable_data_export", value=enable_data_export, expected_type=type_hints["enable_data_export"])
            check_type(argname="argument enable_log_access_using_only_resource_permissions", value=enable_log_access_using_only_resource_permissions, expected_type=type_hints["enable_log_access_using_only_resource_permissions"])
            check_type(argname="argument immediate_purge_data_on30_days", value=immediate_purge_data_on30_days, expected_type=type_hints["immediate_purge_data_on30_days"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if disable_local_auth is not None:
            self._values["disable_local_auth"] = disable_local_auth
        if enable_data_export is not None:
            self._values["enable_data_export"] = enable_data_export
        if enable_log_access_using_only_resource_permissions is not None:
            self._values["enable_log_access_using_only_resource_permissions"] = enable_log_access_using_only_resource_permissions
        if immediate_purge_data_on30_days is not None:
            self._values["immediate_purge_data_on30_days"] = immediate_purge_data_on30_days

    @builtins.property
    def disable_local_auth(self) -> typing.Optional[builtins.bool]:
        '''Flag indicating whether log access using AADIAM is disabled.'''
        result = self._values.get("disable_local_auth")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_data_export(self) -> typing.Optional[builtins.bool]:
        '''Flag indicating whether data export is enabled.'''
        result = self._values.get("enable_data_export")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_log_access_using_only_resource_permissions(
        self,
    ) -> typing.Optional[builtins.bool]:
        '''Flag indicating whether cluster resource permissions are enabled.'''
        result = self._values.get("enable_log_access_using_only_resource_permissions")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def immediate_purge_data_on30_days(self) -> typing.Optional[builtins.bool]:
        '''Flag indicating whether data should be immediately purged after 30 days instead of the configured retention period.'''
        result = self._values.get("immediate_purge_data_on30_days")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LogAnalyticsWorkspaceFeatures(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_loganalyticsworkspace.LogAnalyticsWorkspaceIdentity",
    jsii_struct_bases=[],
    name_mapping={
        "type": "type",
        "user_assigned_identities": "userAssignedIdentities",
    },
)
class LogAnalyticsWorkspaceIdentity:
    def __init__(
        self,
        *,
        type: builtins.str,
        user_assigned_identities: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    ) -> None:
        '''Managed identity configuration for the workspace.

        :param type: Type of managed identity.
        :param user_assigned_identities: User-assigned identity resource IDs Required when type includes UserAssigned.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d08cf15fbfe38462621c940f87116ff1eb3fb60684c1809e512689ff03224e77)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument user_assigned_identities", value=user_assigned_identities, expected_type=type_hints["user_assigned_identities"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if user_assigned_identities is not None:
            self._values["user_assigned_identities"] = user_assigned_identities

    @builtins.property
    def type(self) -> builtins.str:
        '''Type of managed identity.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def user_assigned_identities(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''User-assigned identity resource IDs Required when type includes UserAssigned.'''
        result = self._values.get("user_assigned_identities")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LogAnalyticsWorkspaceIdentity(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_loganalyticsworkspace.LogAnalyticsWorkspaceProps",
    jsii_struct_bases=[_AzapiResourceProps_141a2340],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "monitoring": "monitoring",
        "name": "name",
        "tags": "tags",
        "resource_group_id": "resourceGroupId",
        "default_data_collection_rule_resource_id": "defaultDataCollectionRuleResourceId",
        "features": "features",
        "force_cmk_for_query": "forceCmkForQuery",
        "identity": "identity",
        "public_network_access_for_ingestion": "publicNetworkAccessForIngestion",
        "public_network_access_for_query": "publicNetworkAccessForQuery",
        "retention_in_days": "retentionInDays",
        "sku": "sku",
        "workspace_capping": "workspaceCapping",
    },
)
class LogAnalyticsWorkspaceProps(_AzapiResourceProps_141a2340):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        resource_group_id: builtins.str,
        default_data_collection_rule_resource_id: typing.Optional[builtins.str] = None,
        features: typing.Optional[typing.Union["LogAnalyticsWorkspaceFeatures", typing.Dict[builtins.str, typing.Any]]] = None,
        force_cmk_for_query: typing.Optional[builtins.bool] = None,
        identity: typing.Optional[typing.Union["LogAnalyticsWorkspaceIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        public_network_access_for_ingestion: typing.Optional[builtins.str] = None,
        public_network_access_for_query: typing.Optional[builtins.str] = None,
        retention_in_days: typing.Optional[jsii.Number] = None,
        sku: typing.Optional[typing.Union["LogAnalyticsWorkspaceSku", typing.Dict[builtins.str, typing.Any]]] = None,
        workspace_capping: typing.Optional[typing.Union["LogAnalyticsWorkspaceCapping", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Properties for the unified Azure Log Analytics Workspace.

        Extends AzapiResourceProps with Log Analytics Workspace specific properties

        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param resource_group_id: Resource Group ID where the workspace will be created The workspace will be created as a child of this resource group.
        :param default_data_collection_rule_resource_id: Resource ID of the default Data Collection Rule. Associates a default DCR with the workspace for data collection. Only available in API version 2023-09-01 and later.
        :param features: Workspace features configuration. Enables or disables specific workspace features like data export, immediate purge, and local authentication.
        :param force_cmk_for_query: Whether customer-managed keys are required for saved searches and alerts. When enabled, all saved searches and alerts must use customer-managed keys.
        :param identity: Managed identity configuration for the workspace. Enables managed identity authentication for the workspace.
        :param public_network_access_for_ingestion: Public network access for data ingestion. Controls whether data can be ingested over the public internet. Default: "Enabled"
        :param public_network_access_for_query: Public network access for querying data. Controls whether queries can be executed over the public internet. Default: "Enabled"
        :param retention_in_days: Data retention period in days. Values between 30 and 730 are supported for pay-as-you-go pricing. Free tier is limited to 7 days. Default: 30
        :param sku: SKU configuration for the workspace. Determines pricing tier and capabilities of the workspace. Default: { name: "PerGB2018" }
        :param workspace_capping: Daily volume cap for data ingestion. When the daily cap is reached, data ingestion stops until the next day. A value of dailyQuotaGb: -1 means no cap.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(monitoring, dict):
            monitoring = _MonitoringConfig_7c28df74(**monitoring)
        if isinstance(features, dict):
            features = LogAnalyticsWorkspaceFeatures(**features)
        if isinstance(identity, dict):
            identity = LogAnalyticsWorkspaceIdentity(**identity)
        if isinstance(sku, dict):
            sku = LogAnalyticsWorkspaceSku(**sku)
        if isinstance(workspace_capping, dict):
            workspace_capping = LogAnalyticsWorkspaceCapping(**workspace_capping)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__baead22d1e1c7060ead6be62a2f2a4ec07189d92faac36851059d71ce6ebbd02)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument resource_group_id", value=resource_group_id, expected_type=type_hints["resource_group_id"])
            check_type(argname="argument default_data_collection_rule_resource_id", value=default_data_collection_rule_resource_id, expected_type=type_hints["default_data_collection_rule_resource_id"])
            check_type(argname="argument features", value=features, expected_type=type_hints["features"])
            check_type(argname="argument force_cmk_for_query", value=force_cmk_for_query, expected_type=type_hints["force_cmk_for_query"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument public_network_access_for_ingestion", value=public_network_access_for_ingestion, expected_type=type_hints["public_network_access_for_ingestion"])
            check_type(argname="argument public_network_access_for_query", value=public_network_access_for_query, expected_type=type_hints["public_network_access_for_query"])
            check_type(argname="argument retention_in_days", value=retention_in_days, expected_type=type_hints["retention_in_days"])
            check_type(argname="argument sku", value=sku, expected_type=type_hints["sku"])
            check_type(argname="argument workspace_capping", value=workspace_capping, expected_type=type_hints["workspace_capping"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "resource_group_id": resource_group_id,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if monitoring is not None:
            self._values["monitoring"] = monitoring
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags
        if default_data_collection_rule_resource_id is not None:
            self._values["default_data_collection_rule_resource_id"] = default_data_collection_rule_resource_id
        if features is not None:
            self._values["features"] = features
        if force_cmk_for_query is not None:
            self._values["force_cmk_for_query"] = force_cmk_for_query
        if identity is not None:
            self._values["identity"] = identity
        if public_network_access_for_ingestion is not None:
            self._values["public_network_access_for_ingestion"] = public_network_access_for_ingestion
        if public_network_access_for_query is not None:
            self._values["public_network_access_for_query"] = public_network_access_for_query
        if retention_in_days is not None:
            self._values["retention_in_days"] = retention_in_days
        if sku is not None:
            self._values["sku"] = sku
        if workspace_capping is not None:
            self._values["workspace_capping"] = workspace_capping

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.

        :default: Varies by resource type - see specific resource documentation

        :remarks:

        Location handling varies by resource type:

        - **Top-level resources**: Most require an explicit location (e.g., "eastus", "westus")
        - **Global resources**: Some use "global" as location (e.g., Private DNS Zones)
        - **Child resources**: Inherit location from parent and should NOT set this property

        Each resource type may provide its own default through the ``resolveLocation()`` method.
        If no location is specified and no default exists, resource creation may fail.

        Example::

            // Child resource (Subnet) - do not set location
            // location: undefined (inherited from parent Virtual Network)
        '''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def monitoring(self) -> typing.Optional["_MonitoringConfig_7c28df74"]:
        '''Monitoring configuration for this resource.

        Enables integrated monitoring with diagnostic settings, metric alerts,
        and activity log alerts. All monitoring is optional and disabled by default.

        Example::

            monitoring: {
              enabled: true,
              diagnosticSettings: {
                workspaceId: logAnalytics.id,
                metrics: ['AllMetrics'],
                logs: ['AuditLogs']
              },
              metricAlerts: [{
                name: 'high-cpu-alert',
                severity: 2,
                scopes: [], // Automatically set to this resource
                criteria: { ... },
                actions: [{ actionGroupId: actionGroup.id }]
              }]
            }
        '''
        result = self._values.get("monitoring")
        return typing.cast(typing.Optional["_MonitoringConfig_7c28df74"], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def resource_group_id(self) -> builtins.str:
        '''Resource Group ID where the workspace will be created The workspace will be created as a child of this resource group.'''
        result = self._values.get("resource_group_id")
        assert result is not None, "Required property 'resource_group_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def default_data_collection_rule_resource_id(self) -> typing.Optional[builtins.str]:
        '''Resource ID of the default Data Collection Rule.

        Associates a default DCR with the workspace for data collection.
        Only available in API version 2023-09-01 and later.
        '''
        result = self._values.get("default_data_collection_rule_resource_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def features(self) -> typing.Optional["LogAnalyticsWorkspaceFeatures"]:
        '''Workspace features configuration.

        Enables or disables specific workspace features like data export,
        immediate purge, and local authentication.
        '''
        result = self._values.get("features")
        return typing.cast(typing.Optional["LogAnalyticsWorkspaceFeatures"], result)

    @builtins.property
    def force_cmk_for_query(self) -> typing.Optional[builtins.bool]:
        '''Whether customer-managed keys are required for saved searches and alerts.

        When enabled, all saved searches and alerts must use customer-managed keys.
        '''
        result = self._values.get("force_cmk_for_query")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def identity(self) -> typing.Optional["LogAnalyticsWorkspaceIdentity"]:
        '''Managed identity configuration for the workspace.

        Enables managed identity authentication for the workspace.
        '''
        result = self._values.get("identity")
        return typing.cast(typing.Optional["LogAnalyticsWorkspaceIdentity"], result)

    @builtins.property
    def public_network_access_for_ingestion(self) -> typing.Optional[builtins.str]:
        '''Public network access for data ingestion.

        Controls whether data can be ingested over the public internet.

        :default: "Enabled"
        '''
        result = self._values.get("public_network_access_for_ingestion")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def public_network_access_for_query(self) -> typing.Optional[builtins.str]:
        '''Public network access for querying data.

        Controls whether queries can be executed over the public internet.

        :default: "Enabled"
        '''
        result = self._values.get("public_network_access_for_query")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def retention_in_days(self) -> typing.Optional[jsii.Number]:
        '''Data retention period in days.

        Values between 30 and 730 are supported for pay-as-you-go pricing.
        Free tier is limited to 7 days.

        :default: 30
        '''
        result = self._values.get("retention_in_days")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def sku(self) -> typing.Optional["LogAnalyticsWorkspaceSku"]:
        '''SKU configuration for the workspace.

        Determines pricing tier and capabilities of the workspace.

        :default: { name: "PerGB2018" }
        '''
        result = self._values.get("sku")
        return typing.cast(typing.Optional["LogAnalyticsWorkspaceSku"], result)

    @builtins.property
    def workspace_capping(self) -> typing.Optional["LogAnalyticsWorkspaceCapping"]:
        '''Daily volume cap for data ingestion.

        When the daily cap is reached, data ingestion stops until the next day.
        A value of dailyQuotaGb: -1 means no cap.
        '''
        result = self._values.get("workspace_capping")
        return typing.cast(typing.Optional["LogAnalyticsWorkspaceCapping"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LogAnalyticsWorkspaceProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_loganalyticsworkspace.LogAnalyticsWorkspaceSku",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "capacity_reservation_level": "capacityReservationLevel",
    },
)
class LogAnalyticsWorkspaceSku:
    def __init__(
        self,
        *,
        name: builtins.str,
        capacity_reservation_level: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''SKU configuration for Log Analytics Workspace.

        :param name: SKU name for the Log Analytics Workspace. Available options: - "Free" - Free tier (limited to 500MB/day, 7 day retention) - "Standard" - Standard tier (legacy) - "Premium" - Premium tier (legacy) - "PerNode" - Per node pricing (legacy, for OMS customers) - "PerGB2018" - Pay-as-you-go pricing based on data ingestion - "Standalone" - Standalone tier (legacy) - "CapacityReservation" - Commitment tier with reserved capacity Default: "PerGB2018"
        :param capacity_reservation_level: Capacity reservation level in GB per day Only applicable when SKU name is "CapacityReservation" Valid values: 100, 200, 300, 400, 500, 1000, 2000, 5000.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f2ee1fb2acc20729cb4f1bb9195678654adbaa3eba720f868f60b26a87fdabb)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument capacity_reservation_level", value=capacity_reservation_level, expected_type=type_hints["capacity_reservation_level"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }
        if capacity_reservation_level is not None:
            self._values["capacity_reservation_level"] = capacity_reservation_level

    @builtins.property
    def name(self) -> builtins.str:
        '''SKU name for the Log Analytics Workspace.

        Available options:

        - "Free" - Free tier (limited to 500MB/day, 7 day retention)
        - "Standard" - Standard tier (legacy)
        - "Premium" - Premium tier (legacy)
        - "PerNode" - Per node pricing (legacy, for OMS customers)
        - "PerGB2018" - Pay-as-you-go pricing based on data ingestion
        - "Standalone" - Standalone tier (legacy)
        - "CapacityReservation" - Commitment tier with reserved capacity

        :default: "PerGB2018"
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def capacity_reservation_level(self) -> typing.Optional[jsii.Number]:
        '''Capacity reservation level in GB per day Only applicable when SKU name is "CapacityReservation" Valid values: 100, 200, 300, 400, 500, 1000, 2000, 5000.'''
        result = self._values.get("capacity_reservation_level")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LogAnalyticsWorkspaceSku(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "LogAnalyticsWorkspace",
    "LogAnalyticsWorkspaceBody",
    "LogAnalyticsWorkspaceBodyProperties",
    "LogAnalyticsWorkspaceCapping",
    "LogAnalyticsWorkspaceFeatures",
    "LogAnalyticsWorkspaceIdentity",
    "LogAnalyticsWorkspaceProps",
    "LogAnalyticsWorkspaceSku",
]

publication.publish()

def _typecheckingstub__ffcb9b035ddd368de7f0b3ac1a8059c13fc52654627efeb2660748f085b8b6b3(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    resource_group_id: builtins.str,
    default_data_collection_rule_resource_id: typing.Optional[builtins.str] = None,
    features: typing.Optional[typing.Union[LogAnalyticsWorkspaceFeatures, typing.Dict[builtins.str, typing.Any]]] = None,
    force_cmk_for_query: typing.Optional[builtins.bool] = None,
    identity: typing.Optional[typing.Union[LogAnalyticsWorkspaceIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
    public_network_access_for_ingestion: typing.Optional[builtins.str] = None,
    public_network_access_for_query: typing.Optional[builtins.str] = None,
    retention_in_days: typing.Optional[jsii.Number] = None,
    sku: typing.Optional[typing.Union[LogAnalyticsWorkspaceSku, typing.Dict[builtins.str, typing.Any]]] = None,
    workspace_capping: typing.Optional[typing.Union[LogAnalyticsWorkspaceCapping, typing.Dict[builtins.str, typing.Any]]] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f3e034b254613f244add1d11808ea0df49c566ffb2e3264e7f888ad9da5b5e19(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf545375ea34f528c0906d3cfbe5320e9787cd88a471b9d9bece4fbc4a51a88b(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__960a152857cc2899d33a53b93f758a4ba1faa55fe843f4aa586a68f22661909a(
    *,
    properties: typing.Union[LogAnalyticsWorkspaceBodyProperties, typing.Dict[builtins.str, typing.Any]],
    identity: typing.Optional[typing.Union[LogAnalyticsWorkspaceIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dc1302c059ad34ae7b5c0c119a11967896d64c178381753310157c8289cb998b(
    *,
    default_data_collection_rule_resource_id: typing.Optional[builtins.str] = None,
    features: typing.Optional[typing.Union[LogAnalyticsWorkspaceFeatures, typing.Dict[builtins.str, typing.Any]]] = None,
    force_cmk_for_query: typing.Optional[builtins.bool] = None,
    public_network_access_for_ingestion: typing.Optional[builtins.str] = None,
    public_network_access_for_query: typing.Optional[builtins.str] = None,
    retention_in_days: typing.Optional[jsii.Number] = None,
    sku: typing.Optional[typing.Union[LogAnalyticsWorkspaceSku, typing.Dict[builtins.str, typing.Any]]] = None,
    workspace_capping: typing.Optional[typing.Union[LogAnalyticsWorkspaceCapping, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e340bf85531587043873071390dc6cecf0969d4b9685e8df4f25d91e150ea04(
    *,
    daily_quota_gb: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c6285c0e0b993d3c4f6d1b3fb98e47f2fa852019f67c69e45a193e72b1966d6(
    *,
    disable_local_auth: typing.Optional[builtins.bool] = None,
    enable_data_export: typing.Optional[builtins.bool] = None,
    enable_log_access_using_only_resource_permissions: typing.Optional[builtins.bool] = None,
    immediate_purge_data_on30_days: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d08cf15fbfe38462621c940f87116ff1eb3fb60684c1809e512689ff03224e77(
    *,
    type: builtins.str,
    user_assigned_identities: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__baead22d1e1c7060ead6be62a2f2a4ec07189d92faac36851059d71ce6ebbd02(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    resource_group_id: builtins.str,
    default_data_collection_rule_resource_id: typing.Optional[builtins.str] = None,
    features: typing.Optional[typing.Union[LogAnalyticsWorkspaceFeatures, typing.Dict[builtins.str, typing.Any]]] = None,
    force_cmk_for_query: typing.Optional[builtins.bool] = None,
    identity: typing.Optional[typing.Union[LogAnalyticsWorkspaceIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
    public_network_access_for_ingestion: typing.Optional[builtins.str] = None,
    public_network_access_for_query: typing.Optional[builtins.str] = None,
    retention_in_days: typing.Optional[jsii.Number] = None,
    sku: typing.Optional[typing.Union[LogAnalyticsWorkspaceSku, typing.Dict[builtins.str, typing.Any]]] = None,
    workspace_capping: typing.Optional[typing.Union[LogAnalyticsWorkspaceCapping, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f2ee1fb2acc20729cb4f1bb9195678654adbaa3eba720f868f60b26a87fdabb(
    *,
    name: builtins.str,
    capacity_reservation_level: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass
