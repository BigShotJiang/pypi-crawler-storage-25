r'''
# Azure Private DNS Zone Virtual Network Link Construct (AZAPI)

This Construct represents a Virtual Network Link for Azure Private DNS Zones using the AZAPI provider for direct Azure REST API access.

## What is Azure Private DNS Zone Virtual Network Link?

A Virtual Network Link connects a Private DNS Zone to an Azure Virtual Network, enabling DNS resolution from that VNet. Without a virtual network link, the private DNS zone exists but cannot be used by resources in any virtual network.

**Key Features:**

* **Enable DNS Resolution**: Allow VMs in a VNet to resolve private DNS zone records
* **Auto-Registration**: Optionally enable automatic hostname registration for VMs
* **Resolution Policies**: Configure how DNS queries are resolved
* **Cross-VNet Resolution**: Support DNS resolution across peered virtual networks
* **Multiple Links**: Link a single private DNS zone to multiple virtual networks
* **Bidirectional**: VMs can resolve names in the private DNS zone, and optionally register their names

**Use Cases:**

* Connect VNets to private DNS zones for internal name resolution
* Enable automatic VM hostname registration
* Set up hub-spoke DNS resolution topologies
* Configure split-brain DNS scenarios

You can learn more about Virtual Network Links in the [official Azure documentation](https://docs.microsoft.com/azure/dns/private-dns-virtual-network-links).

## AZAPI Provider Benefits

This Virtual Network Link construct uses the AZAPI provider, which provides:

* **Direct Azure REST API Access**: No dependency on AzureRM provider limitations
* **Immediate Feature Access**: Get new Azure features as soon as they're available
* **Child Resource Support**: Properly handles parent-child resource relationships
* **Enhanced Type Safety**: Better IDE support and compile-time validation

## Best Practices

### Virtual Network Linking Strategy

* **Link strategically**: Only link VNets that need DNS resolution from the private DNS zone
* **Minimize links**: Each private DNS zone has limits on the number of VNet links
* **Plan for scale**: Consider the maximum number of links when designing your architecture
* **Use hub-spoke**: In hub-spoke topologies, link to the hub and rely on peering for spoke resolution

### Auto-Registration

* **Enable selectively**: Only enable auto-registration on VNets where VMs should automatically register
* **One registration VNet**: Typically enable auto-registration on only one VNet per private DNS zone
* **DHCP required**: VMs must use DHCP for auto-registration to work
* **Monitor registrations**: Track auto-registered records to prevent conflicts

### Resolution Policies

* **Default policy**: Use "Default" for standard DNS resolution within Azure
* **NxDomainRedirect**: Use "NxDomainRedirect" to fallback to Azure DNS for unresolved queries
* **Consistency**: Use consistent policies across links for predictable behavior

### Security and Compliance

* **Implement RBAC**: Control who can create and manage virtual network links
* **Monitor changes**: Enable diagnostic logging to track link changes
* **Tag appropriately**: Use tags to identify link purpose and ownership

## Properties

This Construct supports the following properties:

### Required Properties

* **`name`**: (Required) The name of the Virtual Network Link. Must be unique within the Private DNS Zone
* **`privateDnsZoneId`**: (Required) The resource ID of the parent Private DNS Zone
* **`virtualNetworkId`**: (Required) The resource ID of the Virtual Network to link

### Optional Properties

* **`location`**: (Optional) The Azure region (typically "global" for VNet links as they are global resources). Default: "global"
* **`registrationEnabled`**: (Optional) Enable auto-registration of VM hostnames. Default: `false`
* **`resolutionPolicy`**: (Optional) Resolution policy for the link. Values: "Default" or "NxDomainRedirect". Default: "Default"
* **`tags`**: (Optional) Key-value pairs for resource tagging and organization
* **`ignoreChanges`**: (Optional) Lifecycle rules to ignore changes for specific properties
* **`apiVersion`**: (Optional) Explicit API version to use (defaults to latest: "2024-06-01")

### Read-Only Properties (Available as Outputs)

* **`provisioningState`**: Current provisioning state of the link
* **`virtualNetworkLinkState`**: State of the virtual network link ("InProgress" or "Completed")

## Supported API Versions

| API Version | Status  | Features                                                |
|-------------|---------|--------------------------------------------------------|
| 2024-06-01  | ✅ Latest | Full support for VNet links with auto-registration and resolution policies |

## Basic Usage

### Simple Virtual Network Link

```python
import { PrivateDnsZoneLink } from "@microsoft/terraform-cdk-constructs/azure-privatednszonelink";
import { PrivateDnsZone } from "@microsoft/terraform-cdk-constructs/azure-privatednszone";
import { VirtualNetwork } from "@microsoft/terraform-cdk-constructs/azure-virtualnetwork";
import { ResourceGroup } from "@microsoft/terraform-cdk-constructs/azure-resourcegroup";

// Create a resource group
const resourceGroup = new ResourceGroup(this, 'rg', {
  name: 'dns-rg',
  location: 'eastus',
});

// Create a private DNS zone
const privateDnsZone = new PrivateDnsZone(this, 'privateDns', {
  name: 'internal.contoso.com',
  location: 'global',
  resourceGroupId: resourceGroup.id,
});

// Create a virtual network
const vnet = new VirtualNetwork(this, 'vnet', {
  name: 'my-vnet',
  location: 'eastus',
  resourceGroupId: resourceGroup.id,
  addressSpace: {
    addressPrefixes: ['10.0.0.0/16'],
  },
});

// Create virtual network link
const link = new PrivateDnsZoneLink(this, 'link', {
  name: 'my-vnet-link',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: vnet.id,
  tags: {
    environment: 'production',
    purpose: 'dns-resolution',
  },
});
```

### Virtual Network Link with Auto-Registration

```python
// Create link with auto-registration enabled
const linkWithReg = new PrivateDnsZoneLink(this, 'link-with-reg', {
  name: 'vnet-link-with-registration',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: vnet.id,
  registrationEnabled: true, // Enable automatic VM hostname registration
  tags: {
    auto-registration: 'enabled',
  },
});
```

### Virtual Network Link with Resolution Policy

```python
// Create link with NxDomainRedirect resolution policy
const linkWithPolicy = new PrivateDnsZoneLink(this, 'link-with-policy', {
  name: 'vnet-link-with-policy',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: vnet.id,
  resolutionPolicy: 'NxDomainRedirect', // Fallback to Azure DNS for unresolved queries
  tags: {
    policy: 'nxdomain-redirect',
  },
});
```

## Advanced Features

### Version Pinning

Pin to a specific API version for stability:

```python
const link = new PrivateDnsZoneLink(this, 'link', {
  name: 'my-vnet-link',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: vnet.id,
  apiVersion: '2024-06-01', // Pin to specific version
});
```

### Ignore Changes

Prevent Terraform from detecting changes to specific properties:

```python
const link = new PrivateDnsZoneLink(this, 'link', {
  name: 'my-vnet-link',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: vnet.id,
  ignoreChanges: ['tags'], // Ignore tag changes
});
```

### Tag Management

Add and remove tags programmatically:

```python
const link = new PrivateDnsZoneLink(this, 'link', {
  name: 'my-vnet-link',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: vnet.id,
  tags: {
    environment: 'production',
  },
});

// Add a tag
link.addTag('owner', 'platform-team');

// Remove a tag
link.removeTag('environment');
```

## Outputs

The Virtual Network Link construct provides several outputs for use in other resources:

```python
// Resource ID
console.log(link.id);

// Virtual Network Link name
console.log(link.name);

// Location
console.log(link.location);

// Virtual Network ID
console.log(link.virtualNetworkId);

// Registration enabled status
console.log(link.registrationEnabled);

// Resolution policy
console.log(link.resolutionPolicy);

// Provisioning state
console.log(link.provisioningState);

// Link state
console.log(link.virtualNetworkLinkState);

// Terraform outputs
link.idOutput;
link.nameOutput;
link.virtualNetworkIdOutput;
link.registrationEnabledOutput;
link.resolutionPolicyOutput;
link.provisioningStateOutput;
link.virtualNetworkLinkStateOutput;
```

## Common Patterns

### Hub-Spoke Topology with Private DNS

```python
// Create hub virtual network
const hubVnet = new VirtualNetwork(this, 'hub', {
  name: 'hub-vnet',
  location: 'eastus',
  resourceGroupId: resourceGroup.id,
  addressSpace: {
    addressPrefixes: ['10.0.0.0/16'],
  },
});

// Create spoke virtual networks
const spoke1Vnet = new VirtualNetwork(this, 'spoke1', {
  name: 'spoke1-vnet',
  location: 'eastus',
  resourceGroupId: resourceGroup.id,
  addressSpace: {
    addressPrefixes: ['10.1.0.0/16'],
  },
});

const spoke2Vnet = new VirtualNetwork(this, 'spoke2', {
  name: 'spoke2-vnet',
  location: 'eastus',
  resourceGroupId: resourceGroup.id,
  addressSpace: {
    addressPrefixes: ['10.2.0.0/16'],
  },
});

// Create private DNS zone
const privateDnsZone = new PrivateDnsZone(this, 'privateDns', {
  name: 'internal.contoso.com',
  location: 'global',
  resourceGroupId: resourceGroup.id,
});

// Link hub with auto-registration
const hubLink = new PrivateDnsZoneLink(this, 'hub-link', {
  name: 'hub-vnet-link',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: hubVnet.id,
  registrationEnabled: true, // Auto-register hub VMs
});

// Link spokes for resolution only
const spoke1Link = new PrivateDnsZoneLink(this, 'spoke1-link', {
  name: 'spoke1-vnet-link',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: spoke1Vnet.id,
  registrationEnabled: false, // Resolution only
});

const spoke2Link = new PrivateDnsZoneLink(this, 'spoke2-link', {
  name: 'spoke2-vnet-link',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: spoke2Vnet.id,
  registrationEnabled: false, // Resolution only
});
```

### Multi-Environment with Dedicated Links

```python
// Production environment
const prodVnet = new VirtualNetwork(this, 'prod-vnet', {
  name: 'prod-vnet',
  location: 'eastus',
  resourceGroupId: prodResourceGroup.id,
  addressSpace: {
    addressPrefixes: ['10.10.0.0/16'],
  },
});

const prodLink = new PrivateDnsZoneLink(this, 'prod-link', {
  name: 'prod-vnet-link',
  location: 'global',
  privateDnsZoneId: prodPrivateDnsZone.id,
  virtualNetworkId: prodVnet.id,
  registrationEnabled: true,
  tags: { environment: 'production' },
});

// Staging environment
const stagingVnet = new VirtualNetwork(this, 'staging-vnet', {
  name: 'staging-vnet',
  location: 'eastus',
  resourceGroupId: stagingResourceGroup.id,
  addressSpace: {
    addressPrefixes: ['10.20.0.0/16'],
  },
});

const stagingLink = new PrivateDnsZoneLink(this, 'staging-link', {
  name: 'staging-vnet-link',
  location: 'global',
  privateDnsZoneId: stagingPrivateDnsZone.id,
  virtualNetworkId: stagingVnet.id,
  registrationEnabled: true,
  tags: { environment: 'staging' },
});
```

### Shared Services DNS with Multiple Links

```python
// Create a shared private DNS zone
const sharedDns = new PrivateDnsZone(this, 'shared-dns', {
  name: 'services.internal.contoso.com',
  location: 'global',
  resourceGroupId: sharedResourceGroup.id,
});

// Link multiple VNets from different regions/subscriptions
const regions = ['eastus', 'westus', 'northeurope'];
const links = regions.map((region, index) => {
  const vnet = new VirtualNetwork(this, `vnet-${region}`, {
    name: `vnet-${region}`,
    location: region,
    resourceGroupId: resourceGroup.id,
    addressSpace: {
      addressPrefixes: [`10.${100 + index}.0.0/16`],
    },
  });

  return new PrivateDnsZoneLink(this, `link-${region}`, {
    name: `link-${region}`,
    location: 'global',
    privateDnsZoneId: sharedDns.id,
    virtualNetworkId: vnet.id,
    registrationEnabled: false, // Resolution only
    tags: {
      region: region,
      purpose: 'shared-services',
    },
  });
});
```

## Error Handling

The construct includes built-in validation:

```python
// Invalid - missing required properties
const link = new PrivateDnsZoneLink(this, 'link', {
  name: 'my-link',
  // ❌ Missing privateDnsZoneId and virtualNetworkId
});

// Invalid - incorrect resolution policy
const link = new PrivateDnsZoneLink(this, 'link', {
  name: 'my-link',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: vnet.id,
  resolutionPolicy: 'InvalidPolicy', // ❌ Must be "Default" or "NxDomainRedirect"
});

// Valid
const link = new PrivateDnsZoneLink(this, 'link', {
  name: 'my-link',
  location: 'global',
  privateDnsZoneId: privateDnsZone.id,
  virtualNetworkId: vnet.id,
  registrationEnabled: true,
  resolutionPolicy: 'Default', // ✅ Correct
});
```

## Troubleshooting

### DNS Resolution Not Working

If DNS resolution isn't working after creating a link:

1. Verify the link provisioning state is "Succeeded"
2. Check that VMs are using Azure DNS (168.63.129.16) - this is the default
3. Ensure the VNet is properly peered if using hub-spoke topology
4. Verify NSG rules aren't blocking DNS traffic (UDP port 53)
5. Test DNS resolution using `nslookup` or `dig` from a VM in the linked VNet

### Auto-Registration Not Working

If VM hostnames aren't auto-registering:

1. Confirm `registrationEnabled` is set to `true` on the link
2. Ensure VMs are in a subnet of the linked virtual network
3. Check that VMs are using DHCP for their IP configuration (required for auto-registration)
4. Verify VMs have been started/restarted after the link was created
5. Look for any errors in the VM's network configuration

### Link Creation Failures

If link creation fails:

1. Verify the private DNS zone exists and the ID is correct
2. Check that the virtual network exists and the ID is correct
3. Ensure you have permissions to create links in both resources
4. Review Azure resource limits for your subscription
5. Check for any naming conflicts with existing links

### Resolution Policy Issues

If resolution policy isn't behaving as expected:

1. Verify the policy is set to the correct value ("Default" or "NxDomainRedirect")
2. Understand that "Default" only resolves names in the private DNS zone
3. Know that "NxDomainRedirect" falls back to Azure DNS for unresolved queries
4. Test DNS resolution to confirm the expected behavior

## Related Constructs

* **Private DNS Zone**: Parent resource that must exist before creating links
* **Virtual Network**: The VNet to be linked to the private DNS zone
* **Resource Group**: Container for private DNS zone resources
* **DNS Record Sets**: (To be implemented) Create DNS records in the private DNS zone

## Resolution Policy Comparison

| Policy | Behavior | Use Case |
|--------|----------|----------|
| **Default** | Only resolves names in the private DNS zone. Returns NXDOMAIN for unresolved queries. | Standard internal DNS resolution |
| **NxDomainRedirect** | Resolves private DNS zone names first, then falls back to Azure DNS for unresolved queries. | Mixed internal/external resolution |

## Limits and Quotas

| Resource | Default Limit | Notes |
|----------|---------------|-------|
| Virtual network links per private DNS zone | 1000 | Can be increased via support request |
| Virtual network links with auto-registration | 100 | Per private DNS zone |
| Private DNS zones linked to a virtual network | 1000 | Per virtual network |

## References

* [Azure Private DNS Virtual Network Links Documentation](https://docs.microsoft.com/azure/dns/private-dns-virtual-network-links)
* [Private DNS REST API Reference](https://docs.microsoft.com/rest/api/dns/privatedns/virtualnetworklinks)
* [Azure Private DNS Best Practices](https://docs.microsoft.com/azure/dns/private-dns-scenarios)
* [Hub-Spoke Network Topology](https://docs.microsoft.com/azure/architecture/reference-architectures/hybrid-networking/hub-spoke)
* [Azure DNS Private Resolver](https://docs.microsoft.com/azure/dns/dns-private-resolver-overview)
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8
from ..core_azure import (
    ApiSchema as _ApiSchema_5ce0490e,
    AzapiResource as _AzapiResource_7e7f5b39,
    AzapiResourceProps as _AzapiResourceProps_141a2340,
    MonitoringConfig as _MonitoringConfig_7c28df74,
)


class PrivateDnsZoneLink(
    _AzapiResource_7e7f5b39,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.azure_privatednszonelink.PrivateDnsZoneLink",
):
    '''Azure Private DNS Zone Virtual Network Link implementation.

    Virtual Network Links connect private DNS zones to virtual networks, enabling DNS
    resolution from those VNets. They support auto-registration of VM DNS records and
    configurable resolution policies.

    Example::

        // Virtual network link with resolution policy:
        const link = new PrivateDnsZoneLink(this, "vnet-link", {
          name: "my-vnet-link",
          privateDnsZoneId: privateDnsZone.id,
          virtualNetworkId: vnet.id,
          resolutionPolicy: "NxDomainRedirect",
          location: "global",
          apiVersion: "2024-06-01"
        });
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        private_dns_zone_id: builtins.str,
        virtual_network_id: builtins.str,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        registration_enabled: typing.Optional[builtins.bool] = None,
        resolution_policy: typing.Optional[builtins.str] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Creates a new Azure Private DNS Zone Virtual Network Link using the AzapiResource framework.

        :param scope: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param private_dns_zone_id: Resource ID of the parent Private DNS Zone.
        :param virtual_network_id: Resource ID of the Virtual Network to link.
        :param ignore_changes: The lifecycle rules to ignore changes.
        :param registration_enabled: Whether auto-registration of virtual machine records is enabled When enabled, VMs in the VNet will automatically register DNS records. Default: false
        :param resolution_policy: The resolution policy for the virtual network link Only applicable to Private Link zones (zones containing "privatelink." in the name) - "Default": Standard DNS resolution - "NxDomainRedirect": Fallback to Azure DNS for unresolved queries Note: This property will be silently ignored if the zone is not a Private Link zone.
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1f4bb5ac99c29987acac4dd7f75614dac9396f8a933699ac0b91e62877cad86)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = PrivateDnsZoneLinkProps(
            private_dns_zone_id=private_dns_zone_id,
            virtual_network_id=virtual_network_id,
            ignore_changes=ignore_changes,
            registration_enabled=registration_enabled,
            resolution_policy=resolution_policy,
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            monitoring=monitoring,
            name=name,
            tags=tags,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addTag")
    def add_tag(self, key: builtins.str, value: builtins.str) -> None:
        '''Add a tag to the Virtual Network Link.

        :param key: -
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7ea17a0a2babdea7e44c2f971ddcf6ba8251ef147fa070d56574cb63af399f1)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "addTag", [key, value]))

    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> "_ApiSchema_5ce0490e":
        '''Gets the API schema for the resolved version.'''
        return typing.cast("_ApiSchema_5ce0490e", jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call.

        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a70820d4a7942fe20fef2efc2efd6bf9e24829e4696a06dfb7da633483ffbef1)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [props]))

    @jsii.member(jsii_name="defaultLocation")
    def _default_location(self) -> builtins.str:
        '''Gets the default location for this resource type Private DNS Zone Links use "global" location.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultLocation", []))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="removeTag")
    def remove_tag(self, key: builtins.str) -> None:
        '''Remove a tag from the Virtual Network Link.

        :param key: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5cb767339a8d72967603b5422b5dd2033ee85e7119939a6caae5d6d89e05ffb3)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
        return typing.cast(None, jsii.invoke(self, "removeTag", [key]))

    @jsii.member(jsii_name="resolveParentId")
    def _resolve_parent_id(self, props: typing.Any) -> builtins.str:
        '''Resolves the parent resource ID for the Virtual Network Link Virtual Network Links are child resources of Private DNS Zones.

        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e15e196e39492ad05edabfb9315d61e50c38a4912c0f883aabe2cbf7fe87d55)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(builtins.str, jsii.invoke(self, "resolveParentId", [props]))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for Virtual Network Links.'''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="idOutput")
    def id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "idOutput"))

    @builtins.property
    @jsii.member(jsii_name="locationOutput")
    def location_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "locationOutput"))

    @builtins.property
    @jsii.member(jsii_name="nameOutput")
    def name_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "nameOutput"))

    @builtins.property
    @jsii.member(jsii_name="props")
    def props(self) -> "PrivateDnsZoneLinkProps":
        '''The input properties for this Virtual Network Link instance.'''
        return typing.cast("PrivateDnsZoneLinkProps", jsii.get(self, "props"))

    @builtins.property
    @jsii.member(jsii_name="provisioningState")
    def provisioning_state(self) -> builtins.str:
        '''Get the provisioning state of the Virtual Network Link.'''
        return typing.cast(builtins.str, jsii.get(self, "provisioningState"))

    @builtins.property
    @jsii.member(jsii_name="provisioningStateOutput")
    def provisioning_state_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "provisioningStateOutput"))

    @builtins.property
    @jsii.member(jsii_name="registrationEnabled")
    def registration_enabled(self) -> builtins.str:
        '''Get whether auto-registration is enabled Returns a Terraform interpolation string for JSII compliance.'''
        return typing.cast(builtins.str, jsii.get(self, "registrationEnabled"))

    @builtins.property
    @jsii.member(jsii_name="resolutionPolicy")
    def resolution_policy(self) -> builtins.str:
        '''Get the resolution policy Returns a Terraform interpolation string for JSII compliance.'''
        return typing.cast(builtins.str, jsii.get(self, "resolutionPolicy"))

    @builtins.property
    @jsii.member(jsii_name="virtualNetworkId")
    def virtual_network_id(self) -> builtins.str:
        '''Get the Virtual Network ID Note: This returns the input value as Azure API doesn't return it in output.'''
        return typing.cast(builtins.str, jsii.get(self, "virtualNetworkId"))

    @builtins.property
    @jsii.member(jsii_name="virtualNetworkLinkState")
    def virtual_network_link_state(self) -> builtins.str:
        '''Get the state of the Virtual Network Link.'''
        return typing.cast(builtins.str, jsii.get(self, "virtualNetworkLinkState"))

    @builtins.property
    @jsii.member(jsii_name="virtualNetworkLinkStateOutput")
    def virtual_network_link_state_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "virtualNetworkLinkStateOutput"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_privatednszonelink.PrivateDnsZoneLinkBody",
    jsii_struct_bases=[],
    name_mapping={"location": "location", "properties": "properties", "tags": "tags"},
)
class PrivateDnsZoneLinkBody:
    def __init__(
        self,
        *,
        location: builtins.str,
        properties: typing.Union["PrivateDnsZoneLinkProperties", typing.Dict[builtins.str, typing.Any]],
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''The resource body interface for Azure Virtual Network Link API calls.

        :param location: 
        :param properties: 
        :param tags: 
        '''
        if isinstance(properties, dict):
            properties = PrivateDnsZoneLinkProperties(**properties)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de441573f07cb579e7eee08dcb82ce6c34a61cff69b6e68e05abe9ac50532951)
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "location": location,
            "properties": properties,
        }
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def location(self) -> builtins.str:
        result = self._values.get("location")
        assert result is not None, "Required property 'location' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def properties(self) -> "PrivateDnsZoneLinkProperties":
        result = self._values.get("properties")
        assert result is not None, "Required property 'properties' is missing"
        return typing.cast("PrivateDnsZoneLinkProperties", result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PrivateDnsZoneLinkBody(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_privatednszonelink.PrivateDnsZoneLinkProperties",
    jsii_struct_bases=[],
    name_mapping={
        "virtual_network": "virtualNetwork",
        "registration_enabled": "registrationEnabled",
        "resolution_policy": "resolutionPolicy",
    },
)
class PrivateDnsZoneLinkProperties:
    def __init__(
        self,
        *,
        virtual_network: typing.Union["PrivateDnsZoneLinkVirtualNetworkReference", typing.Dict[builtins.str, typing.Any]],
        registration_enabled: typing.Optional[builtins.bool] = None,
        resolution_policy: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Properties for Virtual Network Link body.

        :param virtual_network: 
        :param registration_enabled: 
        :param resolution_policy: 
        '''
        if isinstance(virtual_network, dict):
            virtual_network = PrivateDnsZoneLinkVirtualNetworkReference(**virtual_network)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4caff43870ab61e3988c205c65bb85f16bf87ef5c5f9f2a54a660dc198331cdb)
            check_type(argname="argument virtual_network", value=virtual_network, expected_type=type_hints["virtual_network"])
            check_type(argname="argument registration_enabled", value=registration_enabled, expected_type=type_hints["registration_enabled"])
            check_type(argname="argument resolution_policy", value=resolution_policy, expected_type=type_hints["resolution_policy"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "virtual_network": virtual_network,
        }
        if registration_enabled is not None:
            self._values["registration_enabled"] = registration_enabled
        if resolution_policy is not None:
            self._values["resolution_policy"] = resolution_policy

    @builtins.property
    def virtual_network(self) -> "PrivateDnsZoneLinkVirtualNetworkReference":
        result = self._values.get("virtual_network")
        assert result is not None, "Required property 'virtual_network' is missing"
        return typing.cast("PrivateDnsZoneLinkVirtualNetworkReference", result)

    @builtins.property
    def registration_enabled(self) -> typing.Optional[builtins.bool]:
        result = self._values.get("registration_enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def resolution_policy(self) -> typing.Optional[builtins.str]:
        result = self._values.get("resolution_policy")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PrivateDnsZoneLinkProperties(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_privatednszonelink.PrivateDnsZoneLinkProps",
    jsii_struct_bases=[_AzapiResourceProps_141a2340],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "monitoring": "monitoring",
        "name": "name",
        "tags": "tags",
        "private_dns_zone_id": "privateDnsZoneId",
        "virtual_network_id": "virtualNetworkId",
        "ignore_changes": "ignoreChanges",
        "registration_enabled": "registrationEnabled",
        "resolution_policy": "resolutionPolicy",
    },
)
class PrivateDnsZoneLinkProps(_AzapiResourceProps_141a2340):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        private_dns_zone_id: builtins.str,
        virtual_network_id: builtins.str,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        registration_enabled: typing.Optional[builtins.bool] = None,
        resolution_policy: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Properties for the Azure Private DNS Zone Virtual Network Link.

        Extends AzapiResourceProps with Virtual Network Link specific properties

        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param private_dns_zone_id: Resource ID of the parent Private DNS Zone.
        :param virtual_network_id: Resource ID of the Virtual Network to link.
        :param ignore_changes: The lifecycle rules to ignore changes.
        :param registration_enabled: Whether auto-registration of virtual machine records is enabled When enabled, VMs in the VNet will automatically register DNS records. Default: false
        :param resolution_policy: The resolution policy for the virtual network link Only applicable to Private Link zones (zones containing "privatelink." in the name) - "Default": Standard DNS resolution - "NxDomainRedirect": Fallback to Azure DNS for unresolved queries Note: This property will be silently ignored if the zone is not a Private Link zone.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(monitoring, dict):
            monitoring = _MonitoringConfig_7c28df74(**monitoring)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76f7e0a23c0f3855106574dadb5504046728829649202497a5de8da16591ed14)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument private_dns_zone_id", value=private_dns_zone_id, expected_type=type_hints["private_dns_zone_id"])
            check_type(argname="argument virtual_network_id", value=virtual_network_id, expected_type=type_hints["virtual_network_id"])
            check_type(argname="argument ignore_changes", value=ignore_changes, expected_type=type_hints["ignore_changes"])
            check_type(argname="argument registration_enabled", value=registration_enabled, expected_type=type_hints["registration_enabled"])
            check_type(argname="argument resolution_policy", value=resolution_policy, expected_type=type_hints["resolution_policy"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "private_dns_zone_id": private_dns_zone_id,
            "virtual_network_id": virtual_network_id,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if monitoring is not None:
            self._values["monitoring"] = monitoring
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags
        if ignore_changes is not None:
            self._values["ignore_changes"] = ignore_changes
        if registration_enabled is not None:
            self._values["registration_enabled"] = registration_enabled
        if resolution_policy is not None:
            self._values["resolution_policy"] = resolution_policy

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.

        :default: Varies by resource type - see specific resource documentation

        :remarks:

        Location handling varies by resource type:

        - **Top-level resources**: Most require an explicit location (e.g., "eastus", "westus")
        - **Global resources**: Some use "global" as location (e.g., Private DNS Zones)
        - **Child resources**: Inherit location from parent and should NOT set this property

        Each resource type may provide its own default through the ``resolveLocation()`` method.
        If no location is specified and no default exists, resource creation may fail.

        Example::

            // Child resource (Subnet) - do not set location
            // location: undefined (inherited from parent Virtual Network)
        '''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def monitoring(self) -> typing.Optional["_MonitoringConfig_7c28df74"]:
        '''Monitoring configuration for this resource.

        Enables integrated monitoring with diagnostic settings, metric alerts,
        and activity log alerts. All monitoring is optional and disabled by default.

        Example::

            monitoring: {
              enabled: true,
              diagnosticSettings: {
                workspaceId: logAnalytics.id,
                metrics: ['AllMetrics'],
                logs: ['AuditLogs']
              },
              metricAlerts: [{
                name: 'high-cpu-alert',
                severity: 2,
                scopes: [], // Automatically set to this resource
                criteria: { ... },
                actions: [{ actionGroupId: actionGroup.id }]
              }]
            }
        '''
        result = self._values.get("monitoring")
        return typing.cast(typing.Optional["_MonitoringConfig_7c28df74"], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def private_dns_zone_id(self) -> builtins.str:
        '''Resource ID of the parent Private DNS Zone.

        Example::

            "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg/providers/Microsoft.Network/privateDnsZones/internal.contoso.com"
        '''
        result = self._values.get("private_dns_zone_id")
        assert result is not None, "Required property 'private_dns_zone_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def virtual_network_id(self) -> builtins.str:
        '''Resource ID of the Virtual Network to link.

        Example::

            "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg/providers/Microsoft.Network/virtualNetworks/vnet1"
        '''
        result = self._values.get("virtual_network_id")
        assert result is not None, "Required property 'virtual_network_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def ignore_changes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The lifecycle rules to ignore changes.

        Example::

            ["tags"]
        '''
        result = self._values.get("ignore_changes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def registration_enabled(self) -> typing.Optional[builtins.bool]:
        '''Whether auto-registration of virtual machine records is enabled When enabled, VMs in the VNet will automatically register DNS records.

        :default: false
        '''
        result = self._values.get("registration_enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def resolution_policy(self) -> typing.Optional[builtins.str]:
        '''The resolution policy for the virtual network link Only applicable to Private Link zones (zones containing "privatelink." in the name) - "Default": Standard DNS resolution - "NxDomainRedirect": Fallback to Azure DNS for unresolved queries Note: This property will be silently ignored if the zone is not a Private Link zone.'''
        result = self._values.get("resolution_policy")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PrivateDnsZoneLinkProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_privatednszonelink.PrivateDnsZoneLinkVirtualNetworkReference",
    jsii_struct_bases=[],
    name_mapping={"id": "id"},
)
class PrivateDnsZoneLinkVirtualNetworkReference:
    def __init__(self, *, id: builtins.str) -> None:
        '''Virtual Network reference for the Private DNS Zone link.

        :param id: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5592b0825e5ec5d3e020e34b0cc8eb7bd7764d1501d3a7ba822f4d822dc91ee)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "id": id,
        }

    @builtins.property
    def id(self) -> builtins.str:
        result = self._values.get("id")
        assert result is not None, "Required property 'id' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "PrivateDnsZoneLinkVirtualNetworkReference(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "PrivateDnsZoneLink",
    "PrivateDnsZoneLinkBody",
    "PrivateDnsZoneLinkProperties",
    "PrivateDnsZoneLinkProps",
    "PrivateDnsZoneLinkVirtualNetworkReference",
]

publication.publish()

def _typecheckingstub__d1f4bb5ac99c29987acac4dd7f75614dac9396f8a933699ac0b91e62877cad86(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    private_dns_zone_id: builtins.str,
    virtual_network_id: builtins.str,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    registration_enabled: typing.Optional[builtins.bool] = None,
    resolution_policy: typing.Optional[builtins.str] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7ea17a0a2babdea7e44c2f971ddcf6ba8251ef147fa070d56574cb63af399f1(
    key: builtins.str,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a70820d4a7942fe20fef2efc2efd6bf9e24829e4696a06dfb7da633483ffbef1(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5cb767339a8d72967603b5422b5dd2033ee85e7119939a6caae5d6d89e05ffb3(
    key: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e15e196e39492ad05edabfb9315d61e50c38a4912c0f883aabe2cbf7fe87d55(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de441573f07cb579e7eee08dcb82ce6c34a61cff69b6e68e05abe9ac50532951(
    *,
    location: builtins.str,
    properties: typing.Union[PrivateDnsZoneLinkProperties, typing.Dict[builtins.str, typing.Any]],
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4caff43870ab61e3988c205c65bb85f16bf87ef5c5f9f2a54a660dc198331cdb(
    *,
    virtual_network: typing.Union[PrivateDnsZoneLinkVirtualNetworkReference, typing.Dict[builtins.str, typing.Any]],
    registration_enabled: typing.Optional[builtins.bool] = None,
    resolution_policy: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76f7e0a23c0f3855106574dadb5504046728829649202497a5de8da16591ed14(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    private_dns_zone_id: builtins.str,
    virtual_network_id: builtins.str,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    registration_enabled: typing.Optional[builtins.bool] = None,
    resolution_policy: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5592b0825e5ec5d3e020e34b0cc8eb7bd7764d1501d3a7ba822f4d822dc91ee(
    *,
    id: builtins.str,
) -> None:
    """Type checking stubs"""
    pass
