r'''
# Azure Network Watcher Construct

This module provides a high-level TypeScript construct for managing Azure Network Watchers using the Terraform CDK and Azure AZAPI provider.

## Features

* **Multiple API Version Support**: Supports 2024-01-01 (latest) and 2023-11-01 (for backward compatibility)
* **Automatic Version Resolution**: Uses the latest API version by default
* **Version Pinning**: Lock to a specific API version for stability
* **Type-Safe**: Full TypeScript support with comprehensive interfaces
* **JSII Compatible**: Can be used from TypeScript, Python, Java, and C#
* **Terraform Outputs**: Automatic creation of outputs for id, name, location, and provisioningState
* **Tag Management**: Built-in methods for managing resource tags

## Important Note: One Per Region Limitation

⚠️ **Azure only allows one Network Watcher per subscription per region.**

If you attempt to create a Network Watcher in a region where one already exists, the deployment will fail. This is an Azure platform limitation, not a construct limitation.

Azure automatically creates Network Watchers in a resource group named `NetworkWatcherRG` when certain network features are used. Before creating a Network Watcher, check if one already exists in your target region.

## Supported API Versions

| Version | Status | Release Date | Notes |
|---------|--------|--------------|-------|
| 2024-01-01 | Active (Latest) | 2024-01-01 | Recommended for new deployments |
| 2023-11-01 | Active | 2023-11-01 | Stable release for backward compatibility |

## Installation

This module is part of the `@microsoft/terraform-cdk-constructs` package.

```bash
npm install @microsoft/terraform-cdk-constructs
```

## Basic Usage

### Simple Network Watcher

```python
import { App, TerraformStack } from "cdktn";
import { AzapiProvider } from "@microsoft/terraform-cdk-constructs/core-azure";
import { ResourceGroup } from "@microsoft/terraform-cdk-constructs/azure-resourcegroup";
import { NetworkWatcher } from "@microsoft/terraform-cdk-constructs/azure-networkwatcher";

const app = new App();
const stack = new TerraformStack(app, "network-watcher-stack");

// Configure the Azure provider
new AzapiProvider(stack, "azapi", {});

// Create a resource group
const resourceGroup = new ResourceGroup(stack, "rg", {
  name: "my-resource-group",
  location: "eastus",
});

// Create a Network Watcher
const networkWatcher = new NetworkWatcher(stack, "network-watcher", {
  name: "my-network-watcher",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  tags: {
    environment: "production",
  },
});

app.synth();
```

### Using Azure's Default Naming Convention

Azure typically uses a naming convention of `NetworkWatcher_<region>` for auto-provisioned Network Watchers:

```python
const networkWatcher = new NetworkWatcher(stack, "network-watcher", {
  name: "NetworkWatcher_eastus",
  location: "eastus",
  resourceGroupId: networkWatcherRg.id,
});
```

### Pinning to a Specific API Version

```python
const networkWatcher = new NetworkWatcher(stack, "network-watcher", {
  name: "my-network-watcher",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  apiVersion: "2023-11-01", // Pin to specific version
});
```

## Using Network Watcher with Flow Logs

Network Watcher is primarily used as a dependency for other Network Watcher features. Here's an example of how you might use it with NSG Flow Logs (once the Flow Log construct is available):

```python
// Create the Network Watcher
const networkWatcher = new NetworkWatcher(stack, "network-watcher", {
  name: "NetworkWatcher_eastus",
  location: "eastus",
  resourceGroupId: networkWatcherRg.id,
});

// Use the Network Watcher ID with Flow Logs or other features
// (Flow Log construct example - coming soon)
// const flowLog = new NsgFlowLog(stack, "flow-log", {
//   networkWatcherId: networkWatcher.id,
//   networkSecurityGroupId: nsg.id,
//   storageAccountId: storageAccount.id,
// });
```

## Network Watcher Features

Network Watcher serves as the anchor for various network monitoring and diagnostic features:

| Feature | Description |
|---------|-------------|
| **NSG Flow Logs** | Capture information about IP traffic flowing through NSGs |
| **Connection Monitor** | Monitor reachability, latency, and network topology changes |
| **Packet Capture** | Capture packets to/from virtual machines |
| **IP Flow Verify** | Check if a packet is allowed or denied to/from a VM |
| **Next Hop** | Get the next hop from a VM |
| **VPN Troubleshoot** | Diagnose Azure VPN Gateway and connections |
| **Network Topology** | View network resources and their relationships |
| **Security Group View** | View NSGs and rules applied to a VM |

## API Reference

### NetworkWatcherProps

Configuration properties for the Network Watcher construct.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `name` | `string` | No* | Name of the Network Watcher. If not provided, uses the construct ID. |
| `location` | `string` | Yes | Azure region where the Network Watcher will be created. Only one per region per subscription. |
| `resourceGroupId` | `string` | Yes | Resource group ID where the Network Watcher will be created. |
| `tags` | `{ [key: string]: string }` | No | Resource tags. |
| `apiVersion` | `string` | No | Pin to a specific API version. |

### Public Properties

| Property | Type | Description |
|----------|------|-------------|
| `id` | `string` | The Azure resource ID of the Network Watcher. |
| `props` | `NetworkWatcherProps` | The original input properties. |
| `resolvedApiVersion` | `string` | The API version being used. |

### Outputs

The construct automatically creates Terraform outputs:

* `id`: The Network Watcher resource ID
* `name`: The Network Watcher name
* `location`: The Network Watcher location (region)
* `provisioning_state`: The provisioning state of the Network Watcher

### Methods

| Method | Parameters | Description |
|--------|-----------|-------------|
| `addTag` | `key: string, value: string` | Add a tag to the Network Watcher. |
| `addAccess` | `objectId: string, roleDefinitionName: string` | Add RBAC role assignment. |

## Best Practices

### 1. Use a Dedicated Resource Group

Consider using a dedicated resource group for Network Watchers, similar to Azure's convention:

```python
const networkWatcherRg = new ResourceGroup(stack, "network-watcher-rg", {
  name: "NetworkWatcherRG",
  location: "eastus",
});

const networkWatcher = new NetworkWatcher(stack, "network-watcher", {
  name: "NetworkWatcher_eastus",
  location: "eastus",
  resourceGroupId: networkWatcherRg.id,
});
```

### 2. Check for Existing Network Watchers

Before creating a Network Watcher, verify that one doesn't already exist in the target region:

```bash
az network watcher list --query "[?location=='eastus']"
```

### 3. Create Network Watchers for Each Required Region

If you need Network Watcher features in multiple regions, create a Network Watcher for each:

```python
const regions = ["eastus", "westus2", "northeurope"];

regions.forEach(region => {
  new NetworkWatcher(stack, `network-watcher-${region}`, {
    name: `NetworkWatcher_${region}`,
    location: region,
    resourceGroupId: networkWatcherRg.id,
  });
});
```

### 4. Use Consistent Naming and Tagging

```python
const networkWatcher = new NetworkWatcher(stack, "network-watcher", {
  name: "NetworkWatcher_eastus",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  tags: {
    environment: "production",
    "managed-by": "terraform-cdk",
    "created-by": "platform-team",
  },
});
```

## Troubleshooting

### Common Issues

1. **"A network watcher already exists in the subscription for region"**

   A Network Watcher already exists in that region. Azure allows only one per region per subscription.

   Solution: Import the existing Network Watcher or use a different region.
2. **"Resource group not found"**

   The specified resource group doesn't exist.

   Solution: Ensure the resource group is created before the Network Watcher, either using a `ResourceGroup` construct or by referencing an existing resource group.
3. **"Location is required"**

   Network Watcher requires a location to be specified.

   Solution: Always provide the `location` property.

## Related Constructs

* [`ResourceGroup`](../azure-resourcegroup/README.md) - Azure Resource Groups
* [`VirtualNetwork`](../azure-virtualnetwork/README.md) - Azure Virtual Networks
* [`NetworkSecurityGroup`](../azure-networksecuritygroup/README.md) - Network Security Groups

## Additional Resources

* [Azure Network Watcher Documentation](https://learn.microsoft.com/en-us/azure/network-watcher/network-watcher-overview)
* [Network Watcher REST API Reference](https://learn.microsoft.com/en-us/rest/api/network-watcher/)
* [NSG Flow Logs Documentation](https://learn.microsoft.com/en-us/azure/network-watcher/nsg-flow-logs-overview)
* [Connection Monitor Documentation](https://learn.microsoft.com/en-us/azure/network-watcher/connection-monitor-overview)
* [Terraform CDK Documentation](https://developer.hashicorp.com/terraform/cdktf)

## Contributing

Contributions are welcome! Please see the [Contributing Guide](../../CONTRIBUTING.md) for details.

## License

This project is licensed under the MIT License - see the [LICENSE](../../LICENSE) file for details.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8
from ..core_azure import (
    ApiSchema as _ApiSchema_5ce0490e,
    AzapiResource as _AzapiResource_7e7f5b39,
    AzapiResourceProps as _AzapiResourceProps_141a2340,
    MonitoringConfig as _MonitoringConfig_7c28df74,
)


class NetworkWatcher(
    _AzapiResource_7e7f5b39,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.azure_networkwatcher.NetworkWatcher",
):
    '''Unified Azure Network Watcher implementation.

    This class provides a single, version-aware implementation that automatically handles version
    resolution, schema validation, and property transformation while maintaining full JSII compliance.

    Network Watcher is a regional service that provides tools to monitor, diagnose, and gain
    insights into your network health and performance in Azure. It serves as the anchor for
    Network Watcher features like Flow Logs, Connection Monitor, and Packet Capture.

    IMPORTANT CONSTRAINT: Azure only allows one Network Watcher per subscription per region.
    If you need Network Watcher functionality in multiple regions, you must create a separate
    Network Watcher for each region.

    Example::

        // Network Watcher for use with Flow Logs:
        const networkWatcher = new NetworkWatcher(this, "network-watcher", {
          name: "NetworkWatcher_eastus",
          location: "eastus",
          resourceGroupId: networkWatcherRg.id,
        });
        
        // Then use it with NSG Flow Logs
        const flowLog = new NsgFlowLog(this, "flow-log", {
          networkWatcherId: networkWatcher.id,
          // ... other properties
        });
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        resource_group_id: builtins.str,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Creates a new Azure Network Watcher using the AzapiResource framework.

        The constructor automatically handles version resolution, schema registration,
        validation, and resource creation.

        IMPORTANT: Azure only allows one Network Watcher per subscription per region.
        Attempting to create a Network Watcher in a region where one already exists
        will result in a deployment error.

        :param scope: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param resource_group_id: Resource Group ID where the Network Watcher will be created. The Network Watcher will be created as a child of this resource group. It's recommended to use a dedicated resource group for Network Watchers, as Azure automatically creates one named "NetworkWatcherRG" when certain network features are used.
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c38496e289a99ff742d2ed5013ee297ffeec0c62927f8bb500213837797c152f)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = NetworkWatcherProps(
            resource_group_id=resource_group_id,
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            monitoring=monitoring,
            name=name,
            tags=tags,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> "_ApiSchema_5ce0490e":
        '''Gets the API schema for the resolved version Uses the framework's schema resolution to get the appropriate schema.'''
        return typing.cast("_ApiSchema_5ce0490e", jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, _props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call.

        Network Watcher is a simple resource with an empty properties block.
        All configuration is handled at the resource level (name, location, tags).

        :param _props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ead90f6113c88b23f1bc00c96935731997ed2bf3b170a1130fcde32ec63d19fc)
            check_type(argname="argument _props", value=_props, expected_type=type_hints["_props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [_props]))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified Returns the latest stable version as the default.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="requiresLocation")
    def _requires_location(self) -> builtins.bool:
        '''Indicates that this resource type requires a location.'''
        return typing.cast(builtins.bool, jsii.invoke(self, "requiresLocation", []))

    @jsii.member(jsii_name="resolveParentId")
    def _resolve_parent_id(self, props: typing.Any) -> builtins.str:
        '''Resolves the parent resource ID for Network Watcher Network Watcher is a top-level resource within a resource group.

        :param props: - The resource properties.

        :return: The parent resource ID (the resource group)
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__21bc32cfcadf7ef583d925a18acb967c3ae57313dca4e8afd930d1bc4af59af3)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(builtins.str, jsii.invoke(self, "resolveParentId", [props]))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for Network Watcher.'''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="idOutput")
    def id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        '''Terraform output for the Network Watcher resource ID.'''
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "idOutput"))

    @builtins.property
    @jsii.member(jsii_name="locationOutput")
    def location_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        '''Terraform output for the Network Watcher location.'''
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "locationOutput"))

    @builtins.property
    @jsii.member(jsii_name="nameOutput")
    def name_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        '''Terraform output for the Network Watcher name.'''
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "nameOutput"))

    @builtins.property
    @jsii.member(jsii_name="props")
    def props(self) -> "NetworkWatcherProps":
        '''The input properties for this Network Watcher instance.'''
        return typing.cast("NetworkWatcherProps", jsii.get(self, "props"))

    @builtins.property
    @jsii.member(jsii_name="provisioningStateOutput")
    def provisioning_state_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        '''Terraform output for the Network Watcher provisioning state.'''
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "provisioningStateOutput"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_networkwatcher.NetworkWatcherBody",
    jsii_struct_bases=[],
    name_mapping={"properties": "properties"},
)
class NetworkWatcherBody:
    def __init__(self, *, properties: typing.Mapping[builtins.str, typing.Any]) -> None:
        '''The resource body interface for Azure Network Watcher API calls.

        Network Watcher is a simple resource with minimal properties.
        The properties block is typically empty.

        :param properties: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f4e6069b9580f3505c2461d545a03ec6138773bbf0a731b1f5db212a1080533b)
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "properties": properties,
        }

    @builtins.property
    def properties(self) -> typing.Mapping[builtins.str, typing.Any]:
        result = self._values.get("properties")
        assert result is not None, "Required property 'properties' is missing"
        return typing.cast(typing.Mapping[builtins.str, typing.Any], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NetworkWatcherBody(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_networkwatcher.NetworkWatcherProps",
    jsii_struct_bases=[_AzapiResourceProps_141a2340],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "monitoring": "monitoring",
        "name": "name",
        "tags": "tags",
        "resource_group_id": "resourceGroupId",
    },
)
class NetworkWatcherProps(_AzapiResourceProps_141a2340):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        resource_group_id: builtins.str,
    ) -> None:
        '''Properties for the unified Azure Network Watcher.

        Extends AzapiResourceProps with Network Watcher specific properties.

        IMPORTANT: Azure only allows one Network Watcher per subscription per region.
        Attempting to create multiple Network Watchers in the same region will fail.

        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param resource_group_id: Resource Group ID where the Network Watcher will be created. The Network Watcher will be created as a child of this resource group. It's recommended to use a dedicated resource group for Network Watchers, as Azure automatically creates one named "NetworkWatcherRG" when certain network features are used.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(monitoring, dict):
            monitoring = _MonitoringConfig_7c28df74(**monitoring)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63b43ed4e94bd315fb060b6fb608dca16146891e868d261fd6205321c215ad33)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument resource_group_id", value=resource_group_id, expected_type=type_hints["resource_group_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "resource_group_id": resource_group_id,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if monitoring is not None:
            self._values["monitoring"] = monitoring
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.

        :default: Varies by resource type - see specific resource documentation

        :remarks:

        Location handling varies by resource type:

        - **Top-level resources**: Most require an explicit location (e.g., "eastus", "westus")
        - **Global resources**: Some use "global" as location (e.g., Private DNS Zones)
        - **Child resources**: Inherit location from parent and should NOT set this property

        Each resource type may provide its own default through the ``resolveLocation()`` method.
        If no location is specified and no default exists, resource creation may fail.

        Example::

            // Child resource (Subnet) - do not set location
            // location: undefined (inherited from parent Virtual Network)
        '''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def monitoring(self) -> typing.Optional["_MonitoringConfig_7c28df74"]:
        '''Monitoring configuration for this resource.

        Enables integrated monitoring with diagnostic settings, metric alerts,
        and activity log alerts. All monitoring is optional and disabled by default.

        Example::

            monitoring: {
              enabled: true,
              diagnosticSettings: {
                workspaceId: logAnalytics.id,
                metrics: ['AllMetrics'],
                logs: ['AuditLogs']
              },
              metricAlerts: [{
                name: 'high-cpu-alert',
                severity: 2,
                scopes: [], // Automatically set to this resource
                criteria: { ... },
                actions: [{ actionGroupId: actionGroup.id }]
              }]
            }
        '''
        result = self._values.get("monitoring")
        return typing.cast(typing.Optional["_MonitoringConfig_7c28df74"], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def resource_group_id(self) -> builtins.str:
        '''Resource Group ID where the Network Watcher will be created.

        The Network Watcher will be created as a child of this resource group.
        It's recommended to use a dedicated resource group for Network Watchers,
        as Azure automatically creates one named "NetworkWatcherRG" when certain
        network features are used.
        '''
        result = self._values.get("resource_group_id")
        assert result is not None, "Required property 'resource_group_id' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "NetworkWatcherProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "NetworkWatcher",
    "NetworkWatcherBody",
    "NetworkWatcherProps",
]

publication.publish()

def _typecheckingstub__c38496e289a99ff742d2ed5013ee297ffeec0c62927f8bb500213837797c152f(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    resource_group_id: builtins.str,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ead90f6113c88b23f1bc00c96935731997ed2bf3b170a1130fcde32ec63d19fc(
    _props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__21bc32cfcadf7ef583d925a18acb967c3ae57313dca4e8afd930d1bc4af59af3(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f4e6069b9580f3505c2461d545a03ec6138773bbf0a731b1f5db212a1080533b(
    *,
    properties: typing.Mapping[builtins.str, typing.Any],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63b43ed4e94bd315fb060b6fb608dca16146891e868d261fd6205321c215ad33(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    resource_group_id: builtins.str,
) -> None:
    """Type checking stubs"""
    pass
