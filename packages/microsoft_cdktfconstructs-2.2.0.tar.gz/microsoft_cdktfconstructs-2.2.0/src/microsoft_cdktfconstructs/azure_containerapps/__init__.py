r'''
# Azure Container Apps Module

This module provides unified, version-aware Azure Container App constructs using the AZAPI provider for direct Azure REST API access. Includes `ContainerAppEnvironment` (`Microsoft.App/managedEnvironments`) and `ContainerApp` (`Microsoft.App/containerApps`).

## Features

* **Automatic Version Management** - Uses latest API version by default
* **Version Pinning** - Pin to a specific API version for stability
* **Schema Validation** - Properties validated against API schemas
* **Ingress** - External/internal HTTP, HTTP/2, TCP with TLS, CORS, sticky sessions, IP restrictions
* **Dapr Integration** - Sidecar injection with health checks and observability
* **Auto-Scaling** - HTTP, TCP, custom KEDA, and Azure Queue scaling rules
* **Secrets Management** - Inline secrets and Azure Key Vault references
* **Managed Identity** - SystemAssigned, UserAssigned, or both
* **Workload Profiles** - Consumption, GeneralPurpose, MemoryOptimized, ComputeOptimized
* **VNet Injection** - Network isolation with internal-only load balancer option
* **Zone Redundancy** - High availability across availability zones
* **Peer Authentication** - Mutual TLS (mTLS) between apps (2025-07-01+)
* **Peer Traffic Encryption** - Encrypt traffic between apps (2025-07-01+)

## Supported API Versions

* `2024-03-01` - Stable release
* `2025-07-01` - Latest (default) — adds mTLS, peer traffic encryption, ingress configuration, public network access

## Basic Usage

### Container App Environment

```python
import { ContainerAppEnvironment } from "@microsoft/terraform-cdk-constructs";

const environment = new ContainerAppEnvironment(this, "env", {
  name: "my-container-env",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  appLogsConfiguration: {
    destination: "log-analytics",
    logAnalyticsConfiguration: {
      customerId: logAnalytics.workspaceId,
      sharedKey: logAnalytics.primarySharedKey,
    },
  },
});
```

### Container App

```python
import { ContainerApp } from "@microsoft/terraform-cdk-constructs";

const app = new ContainerApp(this, "app", {
  name: "my-web-app",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  environmentId: environment.id,
  template: {
    containers: [{
      name: "web",
      image: "mcr.microsoft.com/azuredocs/containerapps-helloworld:latest",
      resources: { cpu: 0.25, memory: "0.5Gi" },
    }],
    scale: {
      minReplicas: 1,
      maxReplicas: 5,
    },
  },
  configuration: {
    ingress: {
      external: true,
      targetPort: 80,
    },
  },
});
```

## Advanced Usage

### VNet Injection with Zone Redundancy

```python
const environment = new ContainerAppEnvironment(this, "env", {
  name: "secure-env",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  vnetConfiguration: {
    infrastructureSubnetId: subnet.id,
    internal: true,
  },
  zoneRedundant: true,
  workloadProfiles: [
    { name: "Consumption", workloadProfileType: "Consumption" },
    {
      name: "My-GP-01",
      workloadProfileType: "GeneralPurpose",
      minimumCount: 3,
      maximumCount: 12,
    },
  ],
});
```

### Container App with Dapr

```python
const app = new ContainerApp(this, "app", {
  name: "my-dapr-app",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  environmentId: environment.id,
  template: {
    containers: [{
      name: "api",
      image: "myregistry.azurecr.io/myapi:latest",
      resources: { cpu: 0.5, memory: "1Gi" },
    }],
  },
  configuration: {
    ingress: { external: true, targetPort: 3000 },
    dapr: {
      enabled: true,
      appId: "my-api",
      appPort: 3000,
      appProtocol: "http",
    },
  },
});
```

### Container App with Managed Identity and Private Registry

```python
const app = new ContainerApp(this, "app", {
  name: "my-secure-app",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  environmentId: environment.id,
  identity: {
    type: "SystemAssigned,UserAssigned",
    userAssignedIdentities: {
      [myIdentity.id]: {},
    },
  },
  template: {
    containers: [{
      name: "web",
      image: "myregistry.azurecr.io/myapp:v2",
      resources: { cpu: 1.0, memory: "2Gi" },
      env: [
        { name: "DB_CONNECTION", secretRef: "db-conn" },
      ],
    }],
  },
  configuration: {
    ingress: { external: true, targetPort: 8080 },
    registries: [{
      server: "myregistry.azurecr.io",
      identity: myIdentity.id,
    }],
    secrets: [{
      name: "db-conn",
      keyVaultUrl: "https://myvault.vault.azure.net/secrets/db-connection",
      identity: "system",
    }],
  },
});
```

### Peer Authentication (mTLS) - API 2025-07-01

```python
const environment = new ContainerAppEnvironment(this, "env", {
  name: "mtls-env",
  location: "eastus",
  resourceGroupId: resourceGroup.id,
  peerAuthentication: {
    mtls: { enabled: true },
  },
  peerTrafficConfiguration: {
    encryption: { enabled: true },
  },
  publicNetworkAccess: "Disabled",
});
```

## Properties

### ContainerAppEnvironment

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| name | string | Yes | Name of the environment |
| location | string | Yes | Azure region |
| resourceGroupId | string | No | Parent resource group |
| appLogsConfiguration | object | No | Log Analytics or Azure Monitor |
| vnetConfiguration | object | No | VNet injection settings |
| workloadProfiles | array | No | Compute profile configurations |
| zoneRedundant | boolean | No | Zone redundancy (default: false) |
| daprAIInstrumentationKey | string | No | App Insights key for Dapr |
| daprAIConnectionString | string | No | App Insights connection string |
| customDomainConfiguration | object | No | Custom DNS suffix and certificate |
| infrastructureResourceGroup | string | No | Platform-managed RG name |
| peerAuthentication | object | No | mTLS settings (2025-07-01+) |
| peerTrafficConfiguration | object | No | Traffic encryption (2025-07-01+) |
| ingressConfiguration | object | No | Environment ingress settings (2025-07-01+) |
| publicNetworkAccess | string | No | 'Enabled' or 'Disabled' (2025-07-01+) |

### ContainerApp

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| name | string | Yes | Name of the container app |
| location | string | Yes | Azure region |
| environmentId | string | Yes | Environment resource ID |
| template | object | Yes | Container definitions, scale, volumes |
| resourceGroupId | string | No | Parent resource group |
| configuration | object | No | Ingress, Dapr, secrets, registries |
| identity | object | No | Managed identity configuration |
| workloadProfileName | string | No | Target workload profile |

## Outputs

### ContainerAppEnvironment

* `idOutput` - Resource ID
* `nameOutput` - Resource name
* `locationOutput` - Azure region
* `tagsOutput` - Resource tags
* `defaultDomainOutput` - Default domain name
* `staticIpOutput` - Static IP address
* `provisioningStateOutput` - Provisioning state

### ContainerApp

* `idOutput` - Resource ID
* `nameOutput` - Resource name
* `locationOutput` - Azure region
* `tagsOutput` - Resource tags
* `fqdnOutput` - Ingress FQDN
* `latestRevisionFqdnOutput` - Latest revision FQDN
* `latestReadyRevisionNameOutput` - Latest ready revision name
* `provisioningStateOutput` - Provisioning state

## Methods

Both constructs support:

* `addTag(key, value)` - Add a tag
* `removeTag(key)` - Remove a tag
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8
from ..core_azure import (
    ApiSchema as _ApiSchema_5ce0490e,
    AzapiResource as _AzapiResource_7e7f5b39,
    AzapiResourceProps as _AzapiResourceProps_141a2340,
    MonitoringConfig as _MonitoringConfig_7c28df74,
)


class ContainerApp(
    _AzapiResource_7e7f5b39,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerApp",
):
    '''Unified Azure Container App implementation.

    Azure Container Apps enable you to run microservices and containerized applications
    on a serverless platform. They provide built-in support for ingress, scaling,
    Dapr integration, and more.

    Key features:

    - External and internal ingress with TLS, CORS, and sticky sessions
    - Dapr sidecar integration for microservice patterns
    - Horizontal auto-scaling with HTTP, TCP, custom (KEDA), and Azure Queue rules
    - Secrets management with Azure Key Vault references
    - Managed identity (SystemAssigned, UserAssigned, or both)
    - Init containers for setup tasks
    - Volume mounts (Azure Files, NFS, Ephemeral, Secret)
    - Health probes (Liveness, Readiness, Startup)
    - Multiple revision mode for blue-green and canary deployments
    - Service binds for dev services (Redis, Postgres, Kafka)

    Example::

        // Container App with external ingress and scaling:
        const app = new ContainerApp(this, "app", {
          name: "my-web-app",
          location: "eastus",
          resourceGroupId: resourceGroup.id,
          environmentId: environment.id,
          template: {
            containers: [{
              name: "web",
              image: "myregistry.azurecr.io/myapp:latest",
              resources: { cpu: 0.5, memory: "1Gi" },
              env: [{ name: "PORT", value: "3000" }],
            }],
            scale: {
              minReplicas: 1,
              maxReplicas: 10,
              rules: [{
                name: "http-rule",
                http: { metadata: { concurrentRequests: "50" } },
              }],
            },
          },
          configuration: {
            ingress: {
              external: true,
              targetPort: 3000,
              transport: "http",
            },
          },
        });
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        environment_id: builtins.str,
        template: typing.Union["ContainerAppTemplate", typing.Dict[builtins.str, typing.Any]],
        configuration: typing.Optional[typing.Union["ContainerAppConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        identity: typing.Optional[typing.Union["ContainerAppIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_group_id: typing.Optional[builtins.str] = None,
        workload_profile_name: typing.Optional[builtins.str] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Creates a new Azure Container App.

        :param scope: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param environment_id: Resource ID of the Container App Environment where this app will be hosted.
        :param template: Container App versioned application definition.
        :param configuration: Non-versioned Container App configuration properties.
        :param identity: Managed identity configuration.
        :param ignore_changes: The lifecycle rules to ignore changes.
        :param resource_group_id: Resource group ID where the Container App will be created.
        :param workload_profile_name: Workload profile name to pin for container app execution.
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0651acdf6079c9914eb1cab900c2e98140615d397b878ab1103e91a06e1639e0)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = ContainerAppProps(
            environment_id=environment_id,
            template=template,
            configuration=configuration,
            identity=identity,
            ignore_changes=ignore_changes,
            resource_group_id=resource_group_id,
            workload_profile_name=workload_profile_name,
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            monitoring=monitoring,
            name=name,
            tags=tags,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addTag")
    def add_tag(self, key: builtins.str, value: builtins.str) -> None:
        '''Add a tag to the Container App.

        :param key: -
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__09cfe1185a0e8a41dd366ecafae45bc671e75a3e10af3f47c6f5406c30c8810b)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "addTag", [key, value]))

    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> "_ApiSchema_5ce0490e":
        '''Gets the API schema for the resolved version.'''
        return typing.cast("_ApiSchema_5ce0490e", jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call.

        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8db58e55cf8fc4ad46dc58a7ad7361526a89ebd42dae0559689c024ecd19cedd)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [props]))

    @jsii.member(jsii_name="customizeResourceConfig")
    def _customize_resource_config(self, config: typing.Any) -> typing.Any:
        '''Customizes the resource configuration to handle Azure value normalization.

        Azure normalizes values in API responses:

        - Location: "eastus" → "East US"
        - Enum values: "auto" → "Auto", "enabled" → "Enabled"

        This override:

        1. Removes ``location`` from the body (the framework passes it as a top-level
           attribute which the azapi provider normalizes properly)
        2. Enables ``ignoreCasing`` to suppress diffs from Azure's value normalization
           (e.g., "auto" vs "Auto" for transport, "enabled" vs "Enabled")

        :param config: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eddb363d286309f85d99d6c908674b3f0219d00b8ecfa9a412cc086c242b3977)
            check_type(argname="argument config", value=config, expected_type=type_hints["config"])
        return typing.cast(typing.Any, jsii.invoke(self, "customizeResourceConfig", [config]))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="removeTag")
    def remove_tag(self, key: builtins.str) -> None:
        '''Remove a tag from the Container App.

        :param key: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d8d1051db2e407c487766b9bb976daea374ee3da86f6bb1a00e7b1adb6ea8cc8)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
        return typing.cast(None, jsii.invoke(self, "removeTag", [key]))

    @jsii.member(jsii_name="requiresLocation")
    def _requires_location(self) -> builtins.bool:
        '''Indicates that location is required for Container Apps.'''
        return typing.cast(builtins.bool, jsii.invoke(self, "requiresLocation", []))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for Container Apps.'''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="fqdn")
    def fqdn(self) -> builtins.str:
        '''Get the FQDN of the Container App (from ingress configuration).'''
        return typing.cast(builtins.str, jsii.get(self, "fqdn"))

    @builtins.property
    @jsii.member(jsii_name="fqdnOutput")
    def fqdn_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "fqdnOutput"))

    @builtins.property
    @jsii.member(jsii_name="idOutput")
    def id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "idOutput"))

    @builtins.property
    @jsii.member(jsii_name="latestReadyRevisionName")
    def latest_ready_revision_name(self) -> builtins.str:
        '''Get the name of the latest ready revision.'''
        return typing.cast(builtins.str, jsii.get(self, "latestReadyRevisionName"))

    @builtins.property
    @jsii.member(jsii_name="latestReadyRevisionNameOutput")
    def latest_ready_revision_name_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "latestReadyRevisionNameOutput"))

    @builtins.property
    @jsii.member(jsii_name="latestRevisionFqdn")
    def latest_revision_fqdn(self) -> builtins.str:
        '''Get the FQDN of the latest revision.'''
        return typing.cast(builtins.str, jsii.get(self, "latestRevisionFqdn"))

    @builtins.property
    @jsii.member(jsii_name="latestRevisionFqdnOutput")
    def latest_revision_fqdn_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "latestRevisionFqdnOutput"))

    @builtins.property
    @jsii.member(jsii_name="locationOutput")
    def location_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "locationOutput"))

    @builtins.property
    @jsii.member(jsii_name="nameOutput")
    def name_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "nameOutput"))

    @builtins.property
    @jsii.member(jsii_name="props")
    def props(self) -> "ContainerAppProps":
        return typing.cast("ContainerAppProps", jsii.get(self, "props"))

    @builtins.property
    @jsii.member(jsii_name="provisioningState")
    def provisioning_state(self) -> builtins.str:
        '''Get the provisioning state of the Container App.'''
        return typing.cast(builtins.str, jsii.get(self, "provisioningState"))

    @builtins.property
    @jsii.member(jsii_name="provisioningStateOutput")
    def provisioning_state_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "provisioningStateOutput"))

    @builtins.property
    @jsii.member(jsii_name="runningStatus")
    def running_status(self) -> builtins.str:
        '''Get the running status of the Container App.'''
        return typing.cast(builtins.str, jsii.get(self, "runningStatus"))

    @builtins.property
    @jsii.member(jsii_name="tagsOutput")
    def tags_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "tagsOutput"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppAzureQueueScaleRule",
    jsii_struct_bases=[],
    name_mapping={
        "account_name": "accountName",
        "identity": "identity",
        "queue_length": "queueLength",
        "queue_name": "queueName",
    },
)
class ContainerAppAzureQueueScaleRule:
    def __init__(
        self,
        *,
        account_name: typing.Optional[builtins.str] = None,
        identity: typing.Optional[builtins.str] = None,
        queue_length: typing.Optional[jsii.Number] = None,
        queue_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Azure Queue scale rule configuration.

        :param account_name: Azure Storage account name.
        :param identity: Managed identity to authenticate with the storage account.
        :param queue_length: Queue length threshold to trigger scaling.
        :param queue_name: Azure Storage queue name.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0e05ce12887e895b3e225c010b7072f8223a2aff66c82ccdf9c24b0db46723a1)
            check_type(argname="argument account_name", value=account_name, expected_type=type_hints["account_name"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument queue_length", value=queue_length, expected_type=type_hints["queue_length"])
            check_type(argname="argument queue_name", value=queue_name, expected_type=type_hints["queue_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if account_name is not None:
            self._values["account_name"] = account_name
        if identity is not None:
            self._values["identity"] = identity
        if queue_length is not None:
            self._values["queue_length"] = queue_length
        if queue_name is not None:
            self._values["queue_name"] = queue_name

    @builtins.property
    def account_name(self) -> typing.Optional[builtins.str]:
        '''Azure Storage account name.'''
        result = self._values.get("account_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def identity(self) -> typing.Optional[builtins.str]:
        '''Managed identity to authenticate with the storage account.'''
        result = self._values.get("identity")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def queue_length(self) -> typing.Optional[jsii.Number]:
        '''Queue length threshold to trigger scaling.'''
        result = self._values.get("queue_length")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def queue_name(self) -> typing.Optional[builtins.str]:
        '''Azure Storage queue name.'''
        result = self._values.get("queue_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppAzureQueueScaleRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppBody",
    jsii_struct_bases=[],
    name_mapping={
        "location": "location",
        "identity": "identity",
        "properties": "properties",
        "tags": "tags",
    },
)
class ContainerAppBody:
    def __init__(
        self,
        *,
        location: builtins.str,
        identity: typing.Any = None,
        properties: typing.Any = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''The resource body interface for Azure Container App API calls.

        :param location: 
        :param identity: 
        :param properties: 
        :param tags: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57a15e4ed0b4da152b29bc4fda0d34f5af17e8c63de33e317aee99755458dcd8)
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "location": location,
        }
        if identity is not None:
            self._values["identity"] = identity
        if properties is not None:
            self._values["properties"] = properties
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def location(self) -> builtins.str:
        result = self._values.get("location")
        assert result is not None, "Required property 'location' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def identity(self) -> typing.Any:
        result = self._values.get("identity")
        return typing.cast(typing.Any, result)

    @builtins.property
    def properties(self) -> typing.Any:
        result = self._values.get("properties")
        return typing.cast(typing.Any, result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppBody(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppConfiguration",
    jsii_struct_bases=[],
    name_mapping={
        "active_revisions_mode": "activeRevisionsMode",
        "dapr": "dapr",
        "identity_settings": "identitySettings",
        "ingress": "ingress",
        "max_inactive_revisions": "maxInactiveRevisions",
        "registries": "registries",
        "runtime": "runtime",
        "secrets": "secrets",
        "service": "service",
    },
)
class ContainerAppConfiguration:
    def __init__(
        self,
        *,
        active_revisions_mode: typing.Optional[builtins.str] = None,
        dapr: typing.Optional[typing.Union["ContainerAppDapr", typing.Dict[builtins.str, typing.Any]]] = None,
        identity_settings: typing.Optional[typing.Sequence[typing.Union["ContainerAppIdentitySetting", typing.Dict[builtins.str, typing.Any]]]] = None,
        ingress: typing.Optional[typing.Union["ContainerAppIngress", typing.Dict[builtins.str, typing.Any]]] = None,
        max_inactive_revisions: typing.Optional[jsii.Number] = None,
        registries: typing.Optional[typing.Sequence[typing.Union["ContainerAppRegistry", typing.Dict[builtins.str, typing.Any]]]] = None,
        runtime: typing.Optional[typing.Union["ContainerAppRuntime", typing.Dict[builtins.str, typing.Any]]] = None,
        secrets: typing.Optional[typing.Sequence[typing.Union["ContainerAppSecret", typing.Dict[builtins.str, typing.Any]]]] = None,
        service: typing.Optional[typing.Union["ContainerAppService", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Configuration properties for the Container App.

        :param active_revisions_mode: Active revisions mode: 'Single' or 'Multiple'. Default: "Single"
        :param dapr: Dapr configuration.
        :param identity_settings: Identity settings for lifecycle phases (2025-07-01+).
        :param ingress: Ingress configuration.
        :param max_inactive_revisions: Maximum number of inactive revisions to keep.
        :param registries: Collection of private container registry credentials.
        :param runtime: Runtime configuration (2025-07-01+).
        :param secrets: Collection of secrets used by a Container App.
        :param service: Container App to be a dev Container App Service (2025-07-01+).
        '''
        if isinstance(dapr, dict):
            dapr = ContainerAppDapr(**dapr)
        if isinstance(ingress, dict):
            ingress = ContainerAppIngress(**ingress)
        if isinstance(runtime, dict):
            runtime = ContainerAppRuntime(**runtime)
        if isinstance(service, dict):
            service = ContainerAppService(**service)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80a3aea48086146fff5f7f088a6cbe14c24e7f61937fc881e5d822e0e7d42ed3)
            check_type(argname="argument active_revisions_mode", value=active_revisions_mode, expected_type=type_hints["active_revisions_mode"])
            check_type(argname="argument dapr", value=dapr, expected_type=type_hints["dapr"])
            check_type(argname="argument identity_settings", value=identity_settings, expected_type=type_hints["identity_settings"])
            check_type(argname="argument ingress", value=ingress, expected_type=type_hints["ingress"])
            check_type(argname="argument max_inactive_revisions", value=max_inactive_revisions, expected_type=type_hints["max_inactive_revisions"])
            check_type(argname="argument registries", value=registries, expected_type=type_hints["registries"])
            check_type(argname="argument runtime", value=runtime, expected_type=type_hints["runtime"])
            check_type(argname="argument secrets", value=secrets, expected_type=type_hints["secrets"])
            check_type(argname="argument service", value=service, expected_type=type_hints["service"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if active_revisions_mode is not None:
            self._values["active_revisions_mode"] = active_revisions_mode
        if dapr is not None:
            self._values["dapr"] = dapr
        if identity_settings is not None:
            self._values["identity_settings"] = identity_settings
        if ingress is not None:
            self._values["ingress"] = ingress
        if max_inactive_revisions is not None:
            self._values["max_inactive_revisions"] = max_inactive_revisions
        if registries is not None:
            self._values["registries"] = registries
        if runtime is not None:
            self._values["runtime"] = runtime
        if secrets is not None:
            self._values["secrets"] = secrets
        if service is not None:
            self._values["service"] = service

    @builtins.property
    def active_revisions_mode(self) -> typing.Optional[builtins.str]:
        '''Active revisions mode: 'Single' or 'Multiple'.

        :default: "Single"
        '''
        result = self._values.get("active_revisions_mode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def dapr(self) -> typing.Optional["ContainerAppDapr"]:
        '''Dapr configuration.'''
        result = self._values.get("dapr")
        return typing.cast(typing.Optional["ContainerAppDapr"], result)

    @builtins.property
    def identity_settings(
        self,
    ) -> typing.Optional[typing.List["ContainerAppIdentitySetting"]]:
        '''Identity settings for lifecycle phases (2025-07-01+).'''
        result = self._values.get("identity_settings")
        return typing.cast(typing.Optional[typing.List["ContainerAppIdentitySetting"]], result)

    @builtins.property
    def ingress(self) -> typing.Optional["ContainerAppIngress"]:
        '''Ingress configuration.'''
        result = self._values.get("ingress")
        return typing.cast(typing.Optional["ContainerAppIngress"], result)

    @builtins.property
    def max_inactive_revisions(self) -> typing.Optional[jsii.Number]:
        '''Maximum number of inactive revisions to keep.'''
        result = self._values.get("max_inactive_revisions")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def registries(self) -> typing.Optional[typing.List["ContainerAppRegistry"]]:
        '''Collection of private container registry credentials.'''
        result = self._values.get("registries")
        return typing.cast(typing.Optional[typing.List["ContainerAppRegistry"]], result)

    @builtins.property
    def runtime(self) -> typing.Optional["ContainerAppRuntime"]:
        '''Runtime configuration (2025-07-01+).'''
        result = self._values.get("runtime")
        return typing.cast(typing.Optional["ContainerAppRuntime"], result)

    @builtins.property
    def secrets(self) -> typing.Optional[typing.List["ContainerAppSecret"]]:
        '''Collection of secrets used by a Container App.'''
        result = self._values.get("secrets")
        return typing.cast(typing.Optional[typing.List["ContainerAppSecret"]], result)

    @builtins.property
    def service(self) -> typing.Optional["ContainerAppService"]:
        '''Container App to be a dev Container App Service (2025-07-01+).'''
        result = self._values.get("service")
        return typing.cast(typing.Optional["ContainerAppService"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppContainer",
    jsii_struct_bases=[],
    name_mapping={
        "image": "image",
        "name": "name",
        "args": "args",
        "command": "command",
        "env": "env",
        "probes": "probes",
        "resources": "resources",
        "volume_mounts": "volumeMounts",
    },
)
class ContainerAppContainer:
    def __init__(
        self,
        *,
        image: builtins.str,
        name: builtins.str,
        args: typing.Optional[typing.Sequence[builtins.str]] = None,
        command: typing.Optional[typing.Sequence[builtins.str]] = None,
        env: typing.Optional[typing.Sequence[typing.Union["ContainerAppEnvVar", typing.Dict[builtins.str, typing.Any]]]] = None,
        probes: typing.Optional[typing.Sequence[typing.Union["ContainerAppProbe", typing.Dict[builtins.str, typing.Any]]]] = None,
        resources: typing.Optional[typing.Union["ContainerAppContainerResources", typing.Dict[builtins.str, typing.Any]]] = None,
        volume_mounts: typing.Optional[typing.Sequence[typing.Union["ContainerAppVolumeMount", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> None:
        '''Container definition.

        :param image: Container image tag.
        :param name: Custom container name.
        :param args: Container start command arguments.
        :param command: Container start command.
        :param env: Container environment variables.
        :param probes: List of probes for the container.
        :param resources: Container resource requirements.
        :param volume_mounts: Container volume mounts.
        '''
        if isinstance(resources, dict):
            resources = ContainerAppContainerResources(**resources)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dae8cd5fe6faef01c13848afbcba6df7b27546f0fa0e192e438a0b64f42e81e0)
            check_type(argname="argument image", value=image, expected_type=type_hints["image"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument args", value=args, expected_type=type_hints["args"])
            check_type(argname="argument command", value=command, expected_type=type_hints["command"])
            check_type(argname="argument env", value=env, expected_type=type_hints["env"])
            check_type(argname="argument probes", value=probes, expected_type=type_hints["probes"])
            check_type(argname="argument resources", value=resources, expected_type=type_hints["resources"])
            check_type(argname="argument volume_mounts", value=volume_mounts, expected_type=type_hints["volume_mounts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "image": image,
            "name": name,
        }
        if args is not None:
            self._values["args"] = args
        if command is not None:
            self._values["command"] = command
        if env is not None:
            self._values["env"] = env
        if probes is not None:
            self._values["probes"] = probes
        if resources is not None:
            self._values["resources"] = resources
        if volume_mounts is not None:
            self._values["volume_mounts"] = volume_mounts

    @builtins.property
    def image(self) -> builtins.str:
        '''Container image tag.'''
        result = self._values.get("image")
        assert result is not None, "Required property 'image' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Custom container name.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def args(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Container start command arguments.'''
        result = self._values.get("args")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def command(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Container start command.'''
        result = self._values.get("command")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def env(self) -> typing.Optional[typing.List["ContainerAppEnvVar"]]:
        '''Container environment variables.'''
        result = self._values.get("env")
        return typing.cast(typing.Optional[typing.List["ContainerAppEnvVar"]], result)

    @builtins.property
    def probes(self) -> typing.Optional[typing.List["ContainerAppProbe"]]:
        '''List of probes for the container.'''
        result = self._values.get("probes")
        return typing.cast(typing.Optional[typing.List["ContainerAppProbe"]], result)

    @builtins.property
    def resources(self) -> typing.Optional["ContainerAppContainerResources"]:
        '''Container resource requirements.'''
        result = self._values.get("resources")
        return typing.cast(typing.Optional["ContainerAppContainerResources"], result)

    @builtins.property
    def volume_mounts(self) -> typing.Optional[typing.List["ContainerAppVolumeMount"]]:
        '''Container volume mounts.'''
        result = self._values.get("volume_mounts")
        return typing.cast(typing.Optional[typing.List["ContainerAppVolumeMount"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppContainer(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppContainerResources",
    jsii_struct_bases=[],
    name_mapping={"cpu": "cpu", "memory": "memory"},
)
class ContainerAppContainerResources:
    def __init__(
        self,
        *,
        cpu: typing.Optional[jsii.Number] = None,
        memory: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Container resource requirements.

        :param cpu: Required CPU in cores (e.g., 0.25, 0.5, 1.0, 2.0).
        :param memory: Required memory (e.g., "0.5Gi", "1Gi", "2Gi").
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca6a732c69983114f0e1c7f5f8c17b908e359789d4ddbd84c7aabb2e16d15a2f)
            check_type(argname="argument cpu", value=cpu, expected_type=type_hints["cpu"])
            check_type(argname="argument memory", value=memory, expected_type=type_hints["memory"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if cpu is not None:
            self._values["cpu"] = cpu
        if memory is not None:
            self._values["memory"] = memory

    @builtins.property
    def cpu(self) -> typing.Optional[jsii.Number]:
        '''Required CPU in cores (e.g., 0.25, 0.5, 1.0, 2.0).'''
        result = self._values.get("cpu")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def memory(self) -> typing.Optional[builtins.str]:
        '''Required memory (e.g., "0.5Gi", "1Gi", "2Gi").'''
        result = self._values.get("memory")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppContainerResources(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppCustomScaleRule",
    jsii_struct_bases=[],
    name_mapping={"type": "type", "identity": "identity", "metadata": "metadata"},
)
class ContainerAppCustomScaleRule:
    def __init__(
        self,
        *,
        type: builtins.str,
        identity: typing.Optional[builtins.str] = None,
        metadata: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''Custom (KEDA) scale rule configuration.

        :param type: KEDA trigger type.
        :param identity: Managed identity for the custom scaler.
        :param metadata: Trigger metadata as key-value pairs.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e72b06cb64f7db613c08d1b7af7480f6084f5d06ca33025beb3c9916060d66e5)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if identity is not None:
            self._values["identity"] = identity
        if metadata is not None:
            self._values["metadata"] = metadata

    @builtins.property
    def type(self) -> builtins.str:
        '''KEDA trigger type.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def identity(self) -> typing.Optional[builtins.str]:
        '''Managed identity for the custom scaler.'''
        result = self._values.get("identity")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def metadata(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Trigger metadata as key-value pairs.'''
        result = self._values.get("metadata")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppCustomScaleRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppDapr",
    jsii_struct_bases=[],
    name_mapping={
        "app_health": "appHealth",
        "app_id": "appId",
        "app_port": "appPort",
        "app_protocol": "appProtocol",
        "enable_api_logging": "enableApiLogging",
        "enabled": "enabled",
        "http_max_request_size": "httpMaxRequestSize",
        "http_read_buffer_size": "httpReadBufferSize",
        "log_level": "logLevel",
        "max_concurrency": "maxConcurrency",
    },
)
class ContainerAppDapr:
    def __init__(
        self,
        *,
        app_health: typing.Optional[typing.Union["ContainerAppDaprHealthConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        app_id: typing.Optional[builtins.str] = None,
        app_port: typing.Optional[jsii.Number] = None,
        app_protocol: typing.Optional[builtins.str] = None,
        enable_api_logging: typing.Optional[builtins.bool] = None,
        enabled: typing.Optional[builtins.bool] = None,
        http_max_request_size: typing.Optional[jsii.Number] = None,
        http_read_buffer_size: typing.Optional[jsii.Number] = None,
        log_level: typing.Optional[builtins.str] = None,
        max_concurrency: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''Dapr configuration for the Container App.

        :param app_health: App health check configuration.
        :param app_id: Dapr application identifier.
        :param app_port: Port on which the Dapr side car will listen.
        :param app_protocol: Protocol used by Dapr to communicate with the app: 'http' or 'grpc'. Default: "http"
        :param enable_api_logging: Whether to enable API logging for the Dapr sidecar.
        :param enabled: Whether Dapr is enabled.
        :param http_max_request_size: Max size of HTTP request body in MB to handle by Dapr HTTP server.
        :param http_read_buffer_size: Max size of HTTP header read buffer in KB to handle by Dapr HTTP server.
        :param log_level: Dapr log level: 'debug', 'info', 'warn', 'error'.
        :param max_concurrency: Maximum number of concurrent requests.
        '''
        if isinstance(app_health, dict):
            app_health = ContainerAppDaprHealthConfig(**app_health)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4101ad841339d829cdd9d6acb457e8daa7c2e816c97fc643e668d8b741551d3e)
            check_type(argname="argument app_health", value=app_health, expected_type=type_hints["app_health"])
            check_type(argname="argument app_id", value=app_id, expected_type=type_hints["app_id"])
            check_type(argname="argument app_port", value=app_port, expected_type=type_hints["app_port"])
            check_type(argname="argument app_protocol", value=app_protocol, expected_type=type_hints["app_protocol"])
            check_type(argname="argument enable_api_logging", value=enable_api_logging, expected_type=type_hints["enable_api_logging"])
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument http_max_request_size", value=http_max_request_size, expected_type=type_hints["http_max_request_size"])
            check_type(argname="argument http_read_buffer_size", value=http_read_buffer_size, expected_type=type_hints["http_read_buffer_size"])
            check_type(argname="argument log_level", value=log_level, expected_type=type_hints["log_level"])
            check_type(argname="argument max_concurrency", value=max_concurrency, expected_type=type_hints["max_concurrency"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if app_health is not None:
            self._values["app_health"] = app_health
        if app_id is not None:
            self._values["app_id"] = app_id
        if app_port is not None:
            self._values["app_port"] = app_port
        if app_protocol is not None:
            self._values["app_protocol"] = app_protocol
        if enable_api_logging is not None:
            self._values["enable_api_logging"] = enable_api_logging
        if enabled is not None:
            self._values["enabled"] = enabled
        if http_max_request_size is not None:
            self._values["http_max_request_size"] = http_max_request_size
        if http_read_buffer_size is not None:
            self._values["http_read_buffer_size"] = http_read_buffer_size
        if log_level is not None:
            self._values["log_level"] = log_level
        if max_concurrency is not None:
            self._values["max_concurrency"] = max_concurrency

    @builtins.property
    def app_health(self) -> typing.Optional["ContainerAppDaprHealthConfig"]:
        '''App health check configuration.'''
        result = self._values.get("app_health")
        return typing.cast(typing.Optional["ContainerAppDaprHealthConfig"], result)

    @builtins.property
    def app_id(self) -> typing.Optional[builtins.str]:
        '''Dapr application identifier.'''
        result = self._values.get("app_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def app_port(self) -> typing.Optional[jsii.Number]:
        '''Port on which the Dapr side car will listen.'''
        result = self._values.get("app_port")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def app_protocol(self) -> typing.Optional[builtins.str]:
        '''Protocol used by Dapr to communicate with the app: 'http' or 'grpc'.

        :default: "http"
        '''
        result = self._values.get("app_protocol")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_api_logging(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable API logging for the Dapr sidecar.'''
        result = self._values.get("enable_api_logging")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enabled(self) -> typing.Optional[builtins.bool]:
        '''Whether Dapr is enabled.'''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def http_max_request_size(self) -> typing.Optional[jsii.Number]:
        '''Max size of HTTP request body in MB to handle by Dapr HTTP server.'''
        result = self._values.get("http_max_request_size")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def http_read_buffer_size(self) -> typing.Optional[jsii.Number]:
        '''Max size of HTTP header read buffer in KB to handle by Dapr HTTP server.'''
        result = self._values.get("http_read_buffer_size")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def log_level(self) -> typing.Optional[builtins.str]:
        '''Dapr log level: 'debug', 'info', 'warn', 'error'.'''
        result = self._values.get("log_level")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def max_concurrency(self) -> typing.Optional[jsii.Number]:
        '''Maximum number of concurrent requests.'''
        result = self._values.get("max_concurrency")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppDapr(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppDaprHealthConfig",
    jsii_struct_bases=[],
    name_mapping={
        "enabled": "enabled",
        "path": "path",
        "probe_interval_seconds": "probeIntervalSeconds",
        "probe_timeout_milliseconds": "probeTimeoutMilliseconds",
        "threshold": "threshold",
    },
)
class ContainerAppDaprHealthConfig:
    def __init__(
        self,
        *,
        enabled: typing.Optional[builtins.bool] = None,
        path: typing.Optional[builtins.str] = None,
        probe_interval_seconds: typing.Optional[jsii.Number] = None,
        probe_timeout_milliseconds: typing.Optional[jsii.Number] = None,
        threshold: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''Dapr app health check configuration.

        :param enabled: Whether app health check is enabled.
        :param path: Health check endpoint path.
        :param probe_interval_seconds: Probe interval in seconds.
        :param probe_timeout_milliseconds: Probe timeout in milliseconds.
        :param threshold: Number of consecutive failures before marking unhealthy.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9d2bd337da80fc4713316e25fcc1986debb68f781eb654e464df8036165b7cf3)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument path", value=path, expected_type=type_hints["path"])
            check_type(argname="argument probe_interval_seconds", value=probe_interval_seconds, expected_type=type_hints["probe_interval_seconds"])
            check_type(argname="argument probe_timeout_milliseconds", value=probe_timeout_milliseconds, expected_type=type_hints["probe_timeout_milliseconds"])
            check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if enabled is not None:
            self._values["enabled"] = enabled
        if path is not None:
            self._values["path"] = path
        if probe_interval_seconds is not None:
            self._values["probe_interval_seconds"] = probe_interval_seconds
        if probe_timeout_milliseconds is not None:
            self._values["probe_timeout_milliseconds"] = probe_timeout_milliseconds
        if threshold is not None:
            self._values["threshold"] = threshold

    @builtins.property
    def enabled(self) -> typing.Optional[builtins.bool]:
        '''Whether app health check is enabled.'''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def path(self) -> typing.Optional[builtins.str]:
        '''Health check endpoint path.'''
        result = self._values.get("path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def probe_interval_seconds(self) -> typing.Optional[jsii.Number]:
        '''Probe interval in seconds.'''
        result = self._values.get("probe_interval_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def probe_timeout_milliseconds(self) -> typing.Optional[jsii.Number]:
        '''Probe timeout in milliseconds.'''
        result = self._values.get("probe_timeout_milliseconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def threshold(self) -> typing.Optional[jsii.Number]:
        '''Number of consecutive failures before marking unhealthy.'''
        result = self._values.get("threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppDaprHealthConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvVar",
    jsii_struct_bases=[],
    name_mapping={"name": "name", "secret_ref": "secretRef", "value": "value"},
)
class ContainerAppEnvVar:
    def __init__(
        self,
        *,
        name: builtins.str,
        secret_ref: typing.Optional[builtins.str] = None,
        value: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Environment variable for a container.

        :param name: Environment variable name.
        :param secret_ref: Name of the secret from which to pull the value.
        :param value: Non-secret environment variable value.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__383eafd8dc6e93d1bcbd6cbcfbc81536469b52b27ccff40a0af683574bf3704d)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument secret_ref", value=secret_ref, expected_type=type_hints["secret_ref"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }
        if secret_ref is not None:
            self._values["secret_ref"] = secret_ref
        if value is not None:
            self._values["value"] = value

    @builtins.property
    def name(self) -> builtins.str:
        '''Environment variable name.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def secret_ref(self) -> typing.Optional[builtins.str]:
        '''Name of the secret from which to pull the value.'''
        result = self._values.get("secret_ref")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def value(self) -> typing.Optional[builtins.str]:
        '''Non-secret environment variable value.'''
        result = self._values.get("value")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvVar(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ContainerAppEnvironment(
    _AzapiResource_7e7f5b39,
    metaclass=jsii.JSIIMeta,
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironment",
):
    '''Unified Azure Container App Managed Environment implementation.

    Azure Container App Environments provide the hosting infrastructure for
    Container Apps. They manage the underlying Kubernetes cluster, networking,
    and observability resources.

    Key features:

    - Log Analytics and Azure Monitor integration for observability
    - VNet injection for network isolation
    - Workload profiles for compute customization (Consumption, Dedicated)
    - Zone redundancy for high availability
    - Custom domain support
    - Dapr integration for microservice patterns
    - Peer authentication (mTLS) and traffic encryption (2025-07-01+)

    Example::

        // Environment with VNet injection and zone redundancy:
        const environment = new ContainerAppEnvironment(this, "env", {
          name: "my-container-env",
          location: "eastus",
          resourceGroupId: resourceGroup.id,
          vnetConfiguration: {
            infrastructureSubnetId: subnet.id,
            internal: true,
          },
          zoneRedundant: true,
        });
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        app_logs_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentAppLogsConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        custom_domain_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentCustomDomainConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        dapr_ai_connection_string: typing.Optional[builtins.str] = None,
        dapr_ai_instrumentation_key: typing.Optional[builtins.str] = None,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        infrastructure_resource_group: typing.Optional[builtins.str] = None,
        ingress_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentIngressConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        peer_authentication: typing.Optional[typing.Union["ContainerAppEnvironmentPeerAuthentication", typing.Dict[builtins.str, typing.Any]]] = None,
        peer_traffic_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentPeerTrafficConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        public_network_access: typing.Optional[builtins.str] = None,
        resource_group_id: typing.Optional[builtins.str] = None,
        vnet_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentVnetConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        workload_profiles: typing.Optional[typing.Sequence[typing.Union["ContainerAppEnvironmentWorkloadProfile", typing.Dict[builtins.str, typing.Any]]]] = None,
        zone_redundant: typing.Optional[builtins.bool] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Creates a new Azure Container App Managed Environment.

        :param scope: - The scope in which to define this construct.
        :param id: - The unique identifier for this instance.
        :param app_logs_configuration: Application logs configuration.
        :param custom_domain_configuration: Custom domain configuration for the environment.
        :param dapr_ai_connection_string: Application Insights connection string used by Dapr to export Service to Service communication telemetry.
        :param dapr_ai_instrumentation_key: Azure Monitor instrumentation key used by Dapr to export Service to Service communication telemetry.
        :param ignore_changes: The lifecycle rules to ignore changes.
        :param infrastructure_resource_group: Name of the platform-managed resource group created for the Managed Environment to host infrastructure resources.
        :param ingress_configuration: Ingress configuration for the Managed Environment. Available in API version 2025-07-01+.
        :param peer_authentication: Peer authentication settings for the Managed Environment (mTLS). Available in API version 2025-07-01+.
        :param peer_traffic_configuration: Peer traffic settings for the Managed Environment (encryption). Available in API version 2025-07-01+.
        :param public_network_access: Property to allow or block all public traffic. Allowed Values: 'Enabled', 'Disabled'. Available in API version 2025-07-01+.
        :param resource_group_id: Resource group ID where the Container App Environment will be created.
        :param vnet_configuration: VNet configuration for the environment.
        :param workload_profiles: Workload profiles configured for the Managed Environment.
        :param zone_redundant: Whether or not this Managed Environment is zone-redundant. Default: false
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08aa04bf7bc241fa4f090c508581dc13c405e1c017a5f9065657658db8882593)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = ContainerAppEnvironmentProps(
            app_logs_configuration=app_logs_configuration,
            custom_domain_configuration=custom_domain_configuration,
            dapr_ai_connection_string=dapr_ai_connection_string,
            dapr_ai_instrumentation_key=dapr_ai_instrumentation_key,
            ignore_changes=ignore_changes,
            infrastructure_resource_group=infrastructure_resource_group,
            ingress_configuration=ingress_configuration,
            peer_authentication=peer_authentication,
            peer_traffic_configuration=peer_traffic_configuration,
            public_network_access=public_network_access,
            resource_group_id=resource_group_id,
            vnet_configuration=vnet_configuration,
            workload_profiles=workload_profiles,
            zone_redundant=zone_redundant,
            api_version=api_version,
            enable_migration_analysis=enable_migration_analysis,
            enable_transformation=enable_transformation,
            enable_validation=enable_validation,
            location=location,
            monitoring=monitoring,
            name=name,
            tags=tags,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="addTag")
    def add_tag(self, key: builtins.str, value: builtins.str) -> None:
        '''Add a tag to the Container App Environment.

        :param key: -
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__715b6c5afbb7e8cc118dd306bed3ec0aa0f53f4ab0aa3aa8f94eb2dfde4260bf)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "addTag", [key, value]))

    @jsii.member(jsii_name="apiSchema")
    def _api_schema(self) -> "_ApiSchema_5ce0490e":
        '''Gets the API schema for the resolved version.'''
        return typing.cast("_ApiSchema_5ce0490e", jsii.invoke(self, "apiSchema", []))

    @jsii.member(jsii_name="createResourceBody")
    def _create_resource_body(self, props: typing.Any) -> typing.Any:
        '''Creates the resource body for the Azure API call.

        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66f4388ba9a0e81a3242e10030d125672c6cf5a4785b1b4e89941a3e9d846e4b)
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        return typing.cast(typing.Any, jsii.invoke(self, "createResourceBody", [props]))

    @jsii.member(jsii_name="customizeResourceConfig")
    def _customize_resource_config(self, config: typing.Any) -> typing.Any:
        '''Customizes the resource configuration to handle Azure value normalization.

        Azure normalizes values in API responses:

        - Location: "eastus" → "East US"
        - Enum values: "auto" → "Auto", "enabled" → "Enabled"

        This override:

        1. Removes ``location`` from the body (the framework passes it as a top-level
           attribute which the azapi provider normalizes properly)
        2. Enables ``ignoreCasing`` to suppress diffs from Azure's value normalization
           (e.g., "auto" vs "Auto" for transport, "enabled" vs "Enabled")

        :param config: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b8b4a87ad5ba442ff2d96aef3ee6c25acf7bb175a86696647be4849489a1d3b5)
            check_type(argname="argument config", value=config, expected_type=type_hints["config"])
        return typing.cast(typing.Any, jsii.invoke(self, "customizeResourceConfig", [config]))

    @jsii.member(jsii_name="defaultVersion")
    def _default_version(self) -> builtins.str:
        '''Gets the default API version to use when no explicit version is specified.'''
        return typing.cast(builtins.str, jsii.invoke(self, "defaultVersion", []))

    @jsii.member(jsii_name="removeTag")
    def remove_tag(self, key: builtins.str) -> None:
        '''Remove a tag from the Container App Environment.

        :param key: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__405652e06fb1aeb40510cb2c958f2479603225be419322d2dd628bc8495c6e6a)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
        return typing.cast(None, jsii.invoke(self, "removeTag", [key]))

    @jsii.member(jsii_name="requiresLocation")
    def _requires_location(self) -> builtins.bool:
        '''Indicates that location is required for Container App Environments.'''
        return typing.cast(builtins.bool, jsii.invoke(self, "requiresLocation", []))

    @jsii.member(jsii_name="resourceType")
    def _resource_type(self) -> builtins.str:
        '''Gets the Azure resource type for Container App Environments.'''
        return typing.cast(builtins.str, jsii.invoke(self, "resourceType", []))

    @builtins.property
    @jsii.member(jsii_name="defaultDomain")
    def default_domain(self) -> builtins.str:
        '''Get the default domain of the Container App Environment.'''
        return typing.cast(builtins.str, jsii.get(self, "defaultDomain"))

    @builtins.property
    @jsii.member(jsii_name="defaultDomainOutput")
    def default_domain_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "defaultDomainOutput"))

    @builtins.property
    @jsii.member(jsii_name="idOutput")
    def id_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "idOutput"))

    @builtins.property
    @jsii.member(jsii_name="locationOutput")
    def location_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "locationOutput"))

    @builtins.property
    @jsii.member(jsii_name="nameOutput")
    def name_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "nameOutput"))

    @builtins.property
    @jsii.member(jsii_name="props")
    def props(self) -> "ContainerAppEnvironmentProps":
        return typing.cast("ContainerAppEnvironmentProps", jsii.get(self, "props"))

    @builtins.property
    @jsii.member(jsii_name="provisioningState")
    def provisioning_state(self) -> builtins.str:
        '''Get the provisioning state of the Container App Environment.'''
        return typing.cast(builtins.str, jsii.get(self, "provisioningState"))

    @builtins.property
    @jsii.member(jsii_name="provisioningStateOutput")
    def provisioning_state_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "provisioningStateOutput"))

    @builtins.property
    @jsii.member(jsii_name="staticIp")
    def static_ip(self) -> builtins.str:
        '''Get the static IP of the Container App Environment.'''
        return typing.cast(builtins.str, jsii.get(self, "staticIp"))

    @builtins.property
    @jsii.member(jsii_name="staticIpOutput")
    def static_ip_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "staticIpOutput"))

    @builtins.property
    @jsii.member(jsii_name="tagsOutput")
    def tags_output(self) -> "_cdktn_78ede62e.TerraformOutput":
        return typing.cast("_cdktn_78ede62e.TerraformOutput", jsii.get(self, "tagsOutput"))


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentAppLogsConfig",
    jsii_struct_bases=[],
    name_mapping={
        "destination": "destination",
        "log_analytics_configuration": "logAnalyticsConfiguration",
    },
)
class ContainerAppEnvironmentAppLogsConfig:
    def __init__(
        self,
        *,
        destination: typing.Optional[builtins.str] = None,
        log_analytics_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentLogAnalyticsConfig", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Application logs configuration for the Container App Environment.

        :param destination: Logs destination. Can be 'log-analytics', 'azure-monitor', or 'none'. Default: "log-analytics"
        :param log_analytics_configuration: Log Analytics configuration. Required when destination is 'log-analytics'.
        '''
        if isinstance(log_analytics_configuration, dict):
            log_analytics_configuration = ContainerAppEnvironmentLogAnalyticsConfig(**log_analytics_configuration)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a3e755b7d998e39d35d4312526bd109260ed1db4cc91f38b88558d75a24a435)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
            check_type(argname="argument log_analytics_configuration", value=log_analytics_configuration, expected_type=type_hints["log_analytics_configuration"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if destination is not None:
            self._values["destination"] = destination
        if log_analytics_configuration is not None:
            self._values["log_analytics_configuration"] = log_analytics_configuration

    @builtins.property
    def destination(self) -> typing.Optional[builtins.str]:
        '''Logs destination.

        Can be 'log-analytics', 'azure-monitor', or 'none'.

        :default: "log-analytics"
        '''
        result = self._values.get("destination")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def log_analytics_configuration(
        self,
    ) -> typing.Optional["ContainerAppEnvironmentLogAnalyticsConfig"]:
        '''Log Analytics configuration.

        Required when destination is 'log-analytics'.
        '''
        result = self._values.get("log_analytics_configuration")
        return typing.cast(typing.Optional["ContainerAppEnvironmentLogAnalyticsConfig"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentAppLogsConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentBody",
    jsii_struct_bases=[],
    name_mapping={"location": "location", "properties": "properties", "tags": "tags"},
)
class ContainerAppEnvironmentBody:
    def __init__(
        self,
        *,
        location: builtins.str,
        properties: typing.Any = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''The resource body interface for Azure Container App Environment API calls.

        :param location: 
        :param properties: 
        :param tags: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6ba5230fad4f5cdcc6362556f0e2b81d4c000079cb433d01343dc08009cd18f6)
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument properties", value=properties, expected_type=type_hints["properties"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "location": location,
        }
        if properties is not None:
            self._values["properties"] = properties
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def location(self) -> builtins.str:
        result = self._values.get("location")
        assert result is not None, "Required property 'location' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def properties(self) -> typing.Any:
        result = self._values.get("properties")
        return typing.cast(typing.Any, result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentBody(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentCustomDomainConfig",
    jsii_struct_bases=[],
    name_mapping={
        "certificate_password": "certificatePassword",
        "certificate_value": "certificateValue",
        "dns_suffix": "dnsSuffix",
    },
)
class ContainerAppEnvironmentCustomDomainConfig:
    def __init__(
        self,
        *,
        certificate_password: typing.Optional[builtins.str] = None,
        certificate_value: typing.Optional[builtins.str] = None,
        dns_suffix: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Custom domain configuration for the environment.

        :param certificate_password: Certificate password.
        :param certificate_value: PFX or PEM certificate value (base64 encoded).
        :param dns_suffix: Custom DNS suffix for the environment.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55c1fe4908d7eb5bf923052e35e83c655d75048998353a29fb62ad02f4e3601e)
            check_type(argname="argument certificate_password", value=certificate_password, expected_type=type_hints["certificate_password"])
            check_type(argname="argument certificate_value", value=certificate_value, expected_type=type_hints["certificate_value"])
            check_type(argname="argument dns_suffix", value=dns_suffix, expected_type=type_hints["dns_suffix"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if certificate_password is not None:
            self._values["certificate_password"] = certificate_password
        if certificate_value is not None:
            self._values["certificate_value"] = certificate_value
        if dns_suffix is not None:
            self._values["dns_suffix"] = dns_suffix

    @builtins.property
    def certificate_password(self) -> typing.Optional[builtins.str]:
        '''Certificate password.'''
        result = self._values.get("certificate_password")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def certificate_value(self) -> typing.Optional[builtins.str]:
        '''PFX or PEM certificate value (base64 encoded).'''
        result = self._values.get("certificate_value")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def dns_suffix(self) -> typing.Optional[builtins.str]:
        '''Custom DNS suffix for the environment.'''
        result = self._values.get("dns_suffix")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentCustomDomainConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentEncryptionConfig",
    jsii_struct_bases=[],
    name_mapping={"enabled": "enabled"},
)
class ContainerAppEnvironmentEncryptionConfig:
    def __init__(self, *, enabled: typing.Optional[builtins.bool] = None) -> None:
        '''Encryption settings for peer traffic.

        :param enabled: Whether encryption is enabled.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__90edafbe3dadbf9f328bf72ce73d505c46d86ed4a63b5354b5ff0e42851dcb0f)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if enabled is not None:
            self._values["enabled"] = enabled

    @builtins.property
    def enabled(self) -> typing.Optional[builtins.bool]:
        '''Whether encryption is enabled.'''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentEncryptionConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentIngressConfig",
    jsii_struct_bases=[],
    name_mapping={
        "header_count_limit": "headerCountLimit",
        "request_idle_timeout": "requestIdleTimeout",
        "termination_grace_period_seconds": "terminationGracePeriodSeconds",
        "workload_profile_name": "workloadProfileName",
    },
)
class ContainerAppEnvironmentIngressConfig:
    def __init__(
        self,
        *,
        header_count_limit: typing.Optional[jsii.Number] = None,
        request_idle_timeout: typing.Optional[jsii.Number] = None,
        termination_grace_period_seconds: typing.Optional[jsii.Number] = None,
        workload_profile_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Ingress configuration settings for the Managed Environment.

        Available in API version 2025-07-01+.

        :param header_count_limit: Header count limit.
        :param request_idle_timeout: Request idle timeout in seconds.
        :param termination_grace_period_seconds: Termination grace period in seconds.
        :param workload_profile_name: Workload profile name for the ingress component.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd7ba58de0b213dd1456857a22c28d6ad7bb212a7601fa9cdde6fb4185d679b6)
            check_type(argname="argument header_count_limit", value=header_count_limit, expected_type=type_hints["header_count_limit"])
            check_type(argname="argument request_idle_timeout", value=request_idle_timeout, expected_type=type_hints["request_idle_timeout"])
            check_type(argname="argument termination_grace_period_seconds", value=termination_grace_period_seconds, expected_type=type_hints["termination_grace_period_seconds"])
            check_type(argname="argument workload_profile_name", value=workload_profile_name, expected_type=type_hints["workload_profile_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if header_count_limit is not None:
            self._values["header_count_limit"] = header_count_limit
        if request_idle_timeout is not None:
            self._values["request_idle_timeout"] = request_idle_timeout
        if termination_grace_period_seconds is not None:
            self._values["termination_grace_period_seconds"] = termination_grace_period_seconds
        if workload_profile_name is not None:
            self._values["workload_profile_name"] = workload_profile_name

    @builtins.property
    def header_count_limit(self) -> typing.Optional[jsii.Number]:
        '''Header count limit.'''
        result = self._values.get("header_count_limit")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def request_idle_timeout(self) -> typing.Optional[jsii.Number]:
        '''Request idle timeout in seconds.'''
        result = self._values.get("request_idle_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def termination_grace_period_seconds(self) -> typing.Optional[jsii.Number]:
        '''Termination grace period in seconds.'''
        result = self._values.get("termination_grace_period_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def workload_profile_name(self) -> typing.Optional[builtins.str]:
        '''Workload profile name for the ingress component.'''
        result = self._values.get("workload_profile_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentIngressConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentLogAnalyticsConfig",
    jsii_struct_bases=[],
    name_mapping={"customer_id": "customerId", "shared_key": "sharedKey"},
)
class ContainerAppEnvironmentLogAnalyticsConfig:
    def __init__(self, *, customer_id: builtins.str, shared_key: builtins.str) -> None:
        '''Log Analytics configuration for the Container App Environment.

        :param customer_id: Log Analytics workspace customer ID (workspace ID).
        :param shared_key: Log Analytics workspace shared key.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4103865ef206fb8f6a839003e1cf04d2a7d4449c1854a51e11b49876af52298b)
            check_type(argname="argument customer_id", value=customer_id, expected_type=type_hints["customer_id"])
            check_type(argname="argument shared_key", value=shared_key, expected_type=type_hints["shared_key"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "customer_id": customer_id,
            "shared_key": shared_key,
        }

    @builtins.property
    def customer_id(self) -> builtins.str:
        '''Log Analytics workspace customer ID (workspace ID).'''
        result = self._values.get("customer_id")
        assert result is not None, "Required property 'customer_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def shared_key(self) -> builtins.str:
        '''Log Analytics workspace shared key.'''
        result = self._values.get("shared_key")
        assert result is not None, "Required property 'shared_key' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentLogAnalyticsConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentMtlsConfig",
    jsii_struct_bases=[],
    name_mapping={"enabled": "enabled"},
)
class ContainerAppEnvironmentMtlsConfig:
    def __init__(self, *, enabled: typing.Optional[builtins.bool] = None) -> None:
        '''Mutual TLS settings for peer authentication.

        :param enabled: Whether mTLS is enabled.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35f159904a466f243d60677901d2925493ce38791f65baba5f3eebc99a3d135f)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if enabled is not None:
            self._values["enabled"] = enabled

    @builtins.property
    def enabled(self) -> typing.Optional[builtins.bool]:
        '''Whether mTLS is enabled.'''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentMtlsConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentPeerAuthentication",
    jsii_struct_bases=[],
    name_mapping={"mtls": "mtls"},
)
class ContainerAppEnvironmentPeerAuthentication:
    def __init__(
        self,
        *,
        mtls: typing.Optional[typing.Union["ContainerAppEnvironmentMtlsConfig", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Peer authentication settings (mTLS) for the Managed Environment.

        Available in API version 2025-07-01+.

        :param mtls: Mutual TLS settings.
        '''
        if isinstance(mtls, dict):
            mtls = ContainerAppEnvironmentMtlsConfig(**mtls)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a4c8f85c9bf5164c753c977501b332de8e60cce7aa0c01f46b8a960a6da432a)
            check_type(argname="argument mtls", value=mtls, expected_type=type_hints["mtls"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if mtls is not None:
            self._values["mtls"] = mtls

    @builtins.property
    def mtls(self) -> typing.Optional["ContainerAppEnvironmentMtlsConfig"]:
        '''Mutual TLS settings.'''
        result = self._values.get("mtls")
        return typing.cast(typing.Optional["ContainerAppEnvironmentMtlsConfig"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentPeerAuthentication(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentPeerTrafficConfig",
    jsii_struct_bases=[],
    name_mapping={"encryption": "encryption"},
)
class ContainerAppEnvironmentPeerTrafficConfig:
    def __init__(
        self,
        *,
        encryption: typing.Optional[typing.Union["ContainerAppEnvironmentEncryptionConfig", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Peer traffic encryption settings for the Managed Environment.

        Available in API version 2025-07-01+.

        :param encryption: Encryption settings.
        '''
        if isinstance(encryption, dict):
            encryption = ContainerAppEnvironmentEncryptionConfig(**encryption)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__887130688b4f1b6f57022942bc1cf2bc92287634f8cf7f92e43e2c730e725ee5)
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption is not None:
            self._values["encryption"] = encryption

    @builtins.property
    def encryption(self) -> typing.Optional["ContainerAppEnvironmentEncryptionConfig"]:
        '''Encryption settings.'''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["ContainerAppEnvironmentEncryptionConfig"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentPeerTrafficConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentProps",
    jsii_struct_bases=[_AzapiResourceProps_141a2340],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "monitoring": "monitoring",
        "name": "name",
        "tags": "tags",
        "app_logs_configuration": "appLogsConfiguration",
        "custom_domain_configuration": "customDomainConfiguration",
        "dapr_ai_connection_string": "daprAIConnectionString",
        "dapr_ai_instrumentation_key": "daprAIInstrumentationKey",
        "ignore_changes": "ignoreChanges",
        "infrastructure_resource_group": "infrastructureResourceGroup",
        "ingress_configuration": "ingressConfiguration",
        "peer_authentication": "peerAuthentication",
        "peer_traffic_configuration": "peerTrafficConfiguration",
        "public_network_access": "publicNetworkAccess",
        "resource_group_id": "resourceGroupId",
        "vnet_configuration": "vnetConfiguration",
        "workload_profiles": "workloadProfiles",
        "zone_redundant": "zoneRedundant",
    },
)
class ContainerAppEnvironmentProps(_AzapiResourceProps_141a2340):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        app_logs_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentAppLogsConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        custom_domain_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentCustomDomainConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        dapr_ai_connection_string: typing.Optional[builtins.str] = None,
        dapr_ai_instrumentation_key: typing.Optional[builtins.str] = None,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        infrastructure_resource_group: typing.Optional[builtins.str] = None,
        ingress_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentIngressConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        peer_authentication: typing.Optional[typing.Union["ContainerAppEnvironmentPeerAuthentication", typing.Dict[builtins.str, typing.Any]]] = None,
        peer_traffic_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentPeerTrafficConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        public_network_access: typing.Optional[builtins.str] = None,
        resource_group_id: typing.Optional[builtins.str] = None,
        vnet_configuration: typing.Optional[typing.Union["ContainerAppEnvironmentVnetConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        workload_profiles: typing.Optional[typing.Sequence[typing.Union["ContainerAppEnvironmentWorkloadProfile", typing.Dict[builtins.str, typing.Any]]]] = None,
        zone_redundant: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''Properties for the unified Azure Container App Environment.

        Extends AzapiResourceProps with Container App Environment specific properties

        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param app_logs_configuration: Application logs configuration.
        :param custom_domain_configuration: Custom domain configuration for the environment.
        :param dapr_ai_connection_string: Application Insights connection string used by Dapr to export Service to Service communication telemetry.
        :param dapr_ai_instrumentation_key: Azure Monitor instrumentation key used by Dapr to export Service to Service communication telemetry.
        :param ignore_changes: The lifecycle rules to ignore changes.
        :param infrastructure_resource_group: Name of the platform-managed resource group created for the Managed Environment to host infrastructure resources.
        :param ingress_configuration: Ingress configuration for the Managed Environment. Available in API version 2025-07-01+.
        :param peer_authentication: Peer authentication settings for the Managed Environment (mTLS). Available in API version 2025-07-01+.
        :param peer_traffic_configuration: Peer traffic settings for the Managed Environment (encryption). Available in API version 2025-07-01+.
        :param public_network_access: Property to allow or block all public traffic. Allowed Values: 'Enabled', 'Disabled'. Available in API version 2025-07-01+.
        :param resource_group_id: Resource group ID where the Container App Environment will be created.
        :param vnet_configuration: VNet configuration for the environment.
        :param workload_profiles: Workload profiles configured for the Managed Environment.
        :param zone_redundant: Whether or not this Managed Environment is zone-redundant. Default: false
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(monitoring, dict):
            monitoring = _MonitoringConfig_7c28df74(**monitoring)
        if isinstance(app_logs_configuration, dict):
            app_logs_configuration = ContainerAppEnvironmentAppLogsConfig(**app_logs_configuration)
        if isinstance(custom_domain_configuration, dict):
            custom_domain_configuration = ContainerAppEnvironmentCustomDomainConfig(**custom_domain_configuration)
        if isinstance(ingress_configuration, dict):
            ingress_configuration = ContainerAppEnvironmentIngressConfig(**ingress_configuration)
        if isinstance(peer_authentication, dict):
            peer_authentication = ContainerAppEnvironmentPeerAuthentication(**peer_authentication)
        if isinstance(peer_traffic_configuration, dict):
            peer_traffic_configuration = ContainerAppEnvironmentPeerTrafficConfig(**peer_traffic_configuration)
        if isinstance(vnet_configuration, dict):
            vnet_configuration = ContainerAppEnvironmentVnetConfig(**vnet_configuration)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__16e71ade4fd449cacaef25724975f0f627f6ea8714125fec70dce530cdb52ea0)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument app_logs_configuration", value=app_logs_configuration, expected_type=type_hints["app_logs_configuration"])
            check_type(argname="argument custom_domain_configuration", value=custom_domain_configuration, expected_type=type_hints["custom_domain_configuration"])
            check_type(argname="argument dapr_ai_connection_string", value=dapr_ai_connection_string, expected_type=type_hints["dapr_ai_connection_string"])
            check_type(argname="argument dapr_ai_instrumentation_key", value=dapr_ai_instrumentation_key, expected_type=type_hints["dapr_ai_instrumentation_key"])
            check_type(argname="argument ignore_changes", value=ignore_changes, expected_type=type_hints["ignore_changes"])
            check_type(argname="argument infrastructure_resource_group", value=infrastructure_resource_group, expected_type=type_hints["infrastructure_resource_group"])
            check_type(argname="argument ingress_configuration", value=ingress_configuration, expected_type=type_hints["ingress_configuration"])
            check_type(argname="argument peer_authentication", value=peer_authentication, expected_type=type_hints["peer_authentication"])
            check_type(argname="argument peer_traffic_configuration", value=peer_traffic_configuration, expected_type=type_hints["peer_traffic_configuration"])
            check_type(argname="argument public_network_access", value=public_network_access, expected_type=type_hints["public_network_access"])
            check_type(argname="argument resource_group_id", value=resource_group_id, expected_type=type_hints["resource_group_id"])
            check_type(argname="argument vnet_configuration", value=vnet_configuration, expected_type=type_hints["vnet_configuration"])
            check_type(argname="argument workload_profiles", value=workload_profiles, expected_type=type_hints["workload_profiles"])
            check_type(argname="argument zone_redundant", value=zone_redundant, expected_type=type_hints["zone_redundant"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if monitoring is not None:
            self._values["monitoring"] = monitoring
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags
        if app_logs_configuration is not None:
            self._values["app_logs_configuration"] = app_logs_configuration
        if custom_domain_configuration is not None:
            self._values["custom_domain_configuration"] = custom_domain_configuration
        if dapr_ai_connection_string is not None:
            self._values["dapr_ai_connection_string"] = dapr_ai_connection_string
        if dapr_ai_instrumentation_key is not None:
            self._values["dapr_ai_instrumentation_key"] = dapr_ai_instrumentation_key
        if ignore_changes is not None:
            self._values["ignore_changes"] = ignore_changes
        if infrastructure_resource_group is not None:
            self._values["infrastructure_resource_group"] = infrastructure_resource_group
        if ingress_configuration is not None:
            self._values["ingress_configuration"] = ingress_configuration
        if peer_authentication is not None:
            self._values["peer_authentication"] = peer_authentication
        if peer_traffic_configuration is not None:
            self._values["peer_traffic_configuration"] = peer_traffic_configuration
        if public_network_access is not None:
            self._values["public_network_access"] = public_network_access
        if resource_group_id is not None:
            self._values["resource_group_id"] = resource_group_id
        if vnet_configuration is not None:
            self._values["vnet_configuration"] = vnet_configuration
        if workload_profiles is not None:
            self._values["workload_profiles"] = workload_profiles
        if zone_redundant is not None:
            self._values["zone_redundant"] = zone_redundant

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.

        :default: Varies by resource type - see specific resource documentation

        :remarks:

        Location handling varies by resource type:

        - **Top-level resources**: Most require an explicit location (e.g., "eastus", "westus")
        - **Global resources**: Some use "global" as location (e.g., Private DNS Zones)
        - **Child resources**: Inherit location from parent and should NOT set this property

        Each resource type may provide its own default through the ``resolveLocation()`` method.
        If no location is specified and no default exists, resource creation may fail.

        Example::

            // Child resource (Subnet) - do not set location
            // location: undefined (inherited from parent Virtual Network)
        '''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def monitoring(self) -> typing.Optional["_MonitoringConfig_7c28df74"]:
        '''Monitoring configuration for this resource.

        Enables integrated monitoring with diagnostic settings, metric alerts,
        and activity log alerts. All monitoring is optional and disabled by default.

        Example::

            monitoring: {
              enabled: true,
              diagnosticSettings: {
                workspaceId: logAnalytics.id,
                metrics: ['AllMetrics'],
                logs: ['AuditLogs']
              },
              metricAlerts: [{
                name: 'high-cpu-alert',
                severity: 2,
                scopes: [], // Automatically set to this resource
                criteria: { ... },
                actions: [{ actionGroupId: actionGroup.id }]
              }]
            }
        '''
        result = self._values.get("monitoring")
        return typing.cast(typing.Optional["_MonitoringConfig_7c28df74"], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def app_logs_configuration(
        self,
    ) -> typing.Optional["ContainerAppEnvironmentAppLogsConfig"]:
        '''Application logs configuration.'''
        result = self._values.get("app_logs_configuration")
        return typing.cast(typing.Optional["ContainerAppEnvironmentAppLogsConfig"], result)

    @builtins.property
    def custom_domain_configuration(
        self,
    ) -> typing.Optional["ContainerAppEnvironmentCustomDomainConfig"]:
        '''Custom domain configuration for the environment.'''
        result = self._values.get("custom_domain_configuration")
        return typing.cast(typing.Optional["ContainerAppEnvironmentCustomDomainConfig"], result)

    @builtins.property
    def dapr_ai_connection_string(self) -> typing.Optional[builtins.str]:
        '''Application Insights connection string used by Dapr to export Service to Service communication telemetry.'''
        result = self._values.get("dapr_ai_connection_string")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def dapr_ai_instrumentation_key(self) -> typing.Optional[builtins.str]:
        '''Azure Monitor instrumentation key used by Dapr to export Service to Service communication telemetry.'''
        result = self._values.get("dapr_ai_instrumentation_key")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_changes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The lifecycle rules to ignore changes.

        Example::

            ["tags"]
        '''
        result = self._values.get("ignore_changes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def infrastructure_resource_group(self) -> typing.Optional[builtins.str]:
        '''Name of the platform-managed resource group created for the Managed Environment to host infrastructure resources.'''
        result = self._values.get("infrastructure_resource_group")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ingress_configuration(
        self,
    ) -> typing.Optional["ContainerAppEnvironmentIngressConfig"]:
        '''Ingress configuration for the Managed Environment.

        Available in API version 2025-07-01+.
        '''
        result = self._values.get("ingress_configuration")
        return typing.cast(typing.Optional["ContainerAppEnvironmentIngressConfig"], result)

    @builtins.property
    def peer_authentication(
        self,
    ) -> typing.Optional["ContainerAppEnvironmentPeerAuthentication"]:
        '''Peer authentication settings for the Managed Environment (mTLS).

        Available in API version 2025-07-01+.
        '''
        result = self._values.get("peer_authentication")
        return typing.cast(typing.Optional["ContainerAppEnvironmentPeerAuthentication"], result)

    @builtins.property
    def peer_traffic_configuration(
        self,
    ) -> typing.Optional["ContainerAppEnvironmentPeerTrafficConfig"]:
        '''Peer traffic settings for the Managed Environment (encryption).

        Available in API version 2025-07-01+.
        '''
        result = self._values.get("peer_traffic_configuration")
        return typing.cast(typing.Optional["ContainerAppEnvironmentPeerTrafficConfig"], result)

    @builtins.property
    def public_network_access(self) -> typing.Optional[builtins.str]:
        '''Property to allow or block all public traffic.

        Allowed Values: 'Enabled', 'Disabled'.
        Available in API version 2025-07-01+.
        '''
        result = self._values.get("public_network_access")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def resource_group_id(self) -> typing.Optional[builtins.str]:
        '''Resource group ID where the Container App Environment will be created.'''
        result = self._values.get("resource_group_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vnet_configuration(
        self,
    ) -> typing.Optional["ContainerAppEnvironmentVnetConfig"]:
        '''VNet configuration for the environment.'''
        result = self._values.get("vnet_configuration")
        return typing.cast(typing.Optional["ContainerAppEnvironmentVnetConfig"], result)

    @builtins.property
    def workload_profiles(
        self,
    ) -> typing.Optional[typing.List["ContainerAppEnvironmentWorkloadProfile"]]:
        '''Workload profiles configured for the Managed Environment.'''
        result = self._values.get("workload_profiles")
        return typing.cast(typing.Optional[typing.List["ContainerAppEnvironmentWorkloadProfile"]], result)

    @builtins.property
    def zone_redundant(self) -> typing.Optional[builtins.bool]:
        '''Whether or not this Managed Environment is zone-redundant.

        :default: false
        '''
        result = self._values.get("zone_redundant")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentVnetConfig",
    jsii_struct_bases=[],
    name_mapping={
        "infrastructure_subnet_id": "infrastructureSubnetId",
        "internal": "internal",
    },
)
class ContainerAppEnvironmentVnetConfig:
    def __init__(
        self,
        *,
        infrastructure_subnet_id: typing.Optional[builtins.str] = None,
        internal: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''VNet configuration for the Container App Environment.

        :param infrastructure_subnet_id: Resource ID of a subnet for infrastructure components. Must be at least /21 for consumption-only environments or /23 for workload profile environments.
        :param internal: Whether the environment only has an internal load balancer (no public endpoint). Default: false
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__121dcc943f85f4f806bdfbab83e24f6020d5541d10370a8613ce88feba7695b0)
            check_type(argname="argument infrastructure_subnet_id", value=infrastructure_subnet_id, expected_type=type_hints["infrastructure_subnet_id"])
            check_type(argname="argument internal", value=internal, expected_type=type_hints["internal"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if infrastructure_subnet_id is not None:
            self._values["infrastructure_subnet_id"] = infrastructure_subnet_id
        if internal is not None:
            self._values["internal"] = internal

    @builtins.property
    def infrastructure_subnet_id(self) -> typing.Optional[builtins.str]:
        '''Resource ID of a subnet for infrastructure components.

        Must be at least /21 for consumption-only environments or /23 for workload profile environments.
        '''
        result = self._values.get("infrastructure_subnet_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def internal(self) -> typing.Optional[builtins.bool]:
        '''Whether the environment only has an internal load balancer (no public endpoint).

        :default: false
        '''
        result = self._values.get("internal")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentVnetConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppEnvironmentWorkloadProfile",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "workload_profile_type": "workloadProfileType",
        "maximum_count": "maximumCount",
        "minimum_count": "minimumCount",
    },
)
class ContainerAppEnvironmentWorkloadProfile:
    def __init__(
        self,
        *,
        name: builtins.str,
        workload_profile_type: builtins.str,
        maximum_count: typing.Optional[jsii.Number] = None,
        minimum_count: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''Workload profile configuration.

        :param name: Friendly name of the workload profile.
        :param workload_profile_type: Workload profile type. Values include 'Consumption', 'GeneralPurpose', 'MemoryOptimized', 'ComputeOptimized', 'D4', 'D8', 'D16', 'D32', 'E4', 'E8', 'E16', 'E32'.
        :param maximum_count: Maximum number of instances for this workload profile (not applicable for Consumption).
        :param minimum_count: Minimum number of instances for this workload profile (not applicable for Consumption).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b71438cdde49694bbc2e9b8a814777be95e77a038c2398d057fdd4afba8e7674)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument workload_profile_type", value=workload_profile_type, expected_type=type_hints["workload_profile_type"])
            check_type(argname="argument maximum_count", value=maximum_count, expected_type=type_hints["maximum_count"])
            check_type(argname="argument minimum_count", value=minimum_count, expected_type=type_hints["minimum_count"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
            "workload_profile_type": workload_profile_type,
        }
        if maximum_count is not None:
            self._values["maximum_count"] = maximum_count
        if minimum_count is not None:
            self._values["minimum_count"] = minimum_count

    @builtins.property
    def name(self) -> builtins.str:
        '''Friendly name of the workload profile.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def workload_profile_type(self) -> builtins.str:
        '''Workload profile type.

        Values include 'Consumption', 'GeneralPurpose',
        'MemoryOptimized', 'ComputeOptimized', 'D4', 'D8', 'D16', 'D32',
        'E4', 'E8', 'E16', 'E32'.
        '''
        result = self._values.get("workload_profile_type")
        assert result is not None, "Required property 'workload_profile_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def maximum_count(self) -> typing.Optional[jsii.Number]:
        '''Maximum number of instances for this workload profile (not applicable for Consumption).'''
        result = self._values.get("maximum_count")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def minimum_count(self) -> typing.Optional[jsii.Number]:
        '''Minimum number of instances for this workload profile (not applicable for Consumption).'''
        result = self._values.get("minimum_count")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppEnvironmentWorkloadProfile(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppHttpScaleRule",
    jsii_struct_bases=[],
    name_mapping={"metadata": "metadata"},
)
class ContainerAppHttpScaleRule:
    def __init__(
        self,
        *,
        metadata: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''HTTP scale rule configuration.

        :param metadata: HTTP trigger metadata as key-value pairs.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f5b88eb361156a85588ffd2b6f8ada3da5f1e364e4518886590b79a09d8be8d6)
            check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metadata is not None:
            self._values["metadata"] = metadata

    @builtins.property
    def metadata(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''HTTP trigger metadata as key-value pairs.'''
        result = self._values.get("metadata")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppHttpScaleRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppIdentity",
    jsii_struct_bases=[],
    name_mapping={
        "type": "type",
        "user_assigned_identities": "userAssignedIdentities",
    },
)
class ContainerAppIdentity:
    def __init__(
        self,
        *,
        type: builtins.str,
        user_assigned_identities: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
    ) -> None:
        '''Managed service identity configuration.

        :param type: Type of managed service identity: 'None', 'SystemAssigned', 'UserAssigned', or 'SystemAssigned,UserAssigned'.
        :param user_assigned_identities: User-assigned identity resource IDs.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f6435e272c8bb7d4166c2414b721c63a19653afcd40b6efcc7b287210278105)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument user_assigned_identities", value=user_assigned_identities, expected_type=type_hints["user_assigned_identities"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if user_assigned_identities is not None:
            self._values["user_assigned_identities"] = user_assigned_identities

    @builtins.property
    def type(self) -> builtins.str:
        '''Type of managed service identity: 'None', 'SystemAssigned', 'UserAssigned', or 'SystemAssigned,UserAssigned'.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def user_assigned_identities(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, typing.Any]]:
        '''User-assigned identity resource IDs.'''
        result = self._values.get("user_assigned_identities")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, typing.Any]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppIdentity(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppIdentitySetting",
    jsii_struct_bases=[],
    name_mapping={"identity": "identity", "lifecycle": "lifecycle"},
)
class ContainerAppIdentitySetting:
    def __init__(self, *, identity: builtins.str, lifecycle: builtins.str) -> None:
        '''Identity settings for lifecycle phases (2025-07-01+).

        :param identity: Resource ID of a managed identity or 'system' for system-assigned.
        :param lifecycle: The lifecycle stage: 'All', 'Init', or 'Main'.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a13588971b9d659ff53e7001f7c327534520238e9d274ffa72ef4cf0c6d71fa)
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "identity": identity,
            "lifecycle": lifecycle,
        }

    @builtins.property
    def identity(self) -> builtins.str:
        '''Resource ID of a managed identity or 'system' for system-assigned.'''
        result = self._values.get("identity")
        assert result is not None, "Required property 'identity' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def lifecycle(self) -> builtins.str:
        '''The lifecycle stage: 'All', 'Init', or 'Main'.'''
        result = self._values.get("lifecycle")
        assert result is not None, "Required property 'lifecycle' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppIdentitySetting(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppIngress",
    jsii_struct_bases=[],
    name_mapping={
        "additional_port_mappings": "additionalPortMappings",
        "client_certificate_mode": "clientCertificateMode",
        "cors_policy": "corsPolicy",
        "custom_domains": "customDomains",
        "external": "external",
        "ip_security_restrictions": "ipSecurityRestrictions",
        "sticky_sessions": "stickySessions",
        "target_port": "targetPort",
        "traffic": "traffic",
        "transport": "transport",
    },
)
class ContainerAppIngress:
    def __init__(
        self,
        *,
        additional_port_mappings: typing.Optional[typing.Sequence[typing.Union["ContainerAppIngressAdditionalPortMapping", typing.Dict[builtins.str, typing.Any]]]] = None,
        client_certificate_mode: typing.Optional[builtins.str] = None,
        cors_policy: typing.Optional[typing.Union["ContainerAppIngressCorsPolicy", typing.Dict[builtins.str, typing.Any]]] = None,
        custom_domains: typing.Optional[typing.Sequence[typing.Any]] = None,
        external: typing.Optional[builtins.bool] = None,
        ip_security_restrictions: typing.Optional[typing.Sequence[typing.Union["ContainerAppIngressIpSecurityRestriction", typing.Dict[builtins.str, typing.Any]]]] = None,
        sticky_sessions: typing.Optional[typing.Union["ContainerAppIngressStickySessions", typing.Dict[builtins.str, typing.Any]]] = None,
        target_port: typing.Optional[jsii.Number] = None,
        traffic: typing.Optional[typing.Sequence[typing.Union["ContainerAppIngressTraffic", typing.Dict[builtins.str, typing.Any]]]] = None,
        transport: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Ingress configuration for the Container App.

        :param additional_port_mappings: Additional port mappings for the Container App (2025-07-01+).
        :param client_certificate_mode: Client certificate mode.
        :param cors_policy: CORS policy for the Container App.
        :param custom_domains: Custom domain bindings for the Container App's hostname.
        :param external: Whether the ingress is externally accessible.
        :param ip_security_restrictions: IP security restrictions.
        :param sticky_sessions: Sticky sessions configuration.
        :param target_port: Target port in the container for incoming traffic.
        :param traffic: Traffic weights for revisions.
        :param transport: Ingress transport protocol: 'auto', 'http', 'http2', or 'tcp'. Default: "auto"
        '''
        if isinstance(cors_policy, dict):
            cors_policy = ContainerAppIngressCorsPolicy(**cors_policy)
        if isinstance(sticky_sessions, dict):
            sticky_sessions = ContainerAppIngressStickySessions(**sticky_sessions)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__156776725704f25c0c5a687fc4624b45f5205cc2118f117177a7d1771b403600)
            check_type(argname="argument additional_port_mappings", value=additional_port_mappings, expected_type=type_hints["additional_port_mappings"])
            check_type(argname="argument client_certificate_mode", value=client_certificate_mode, expected_type=type_hints["client_certificate_mode"])
            check_type(argname="argument cors_policy", value=cors_policy, expected_type=type_hints["cors_policy"])
            check_type(argname="argument custom_domains", value=custom_domains, expected_type=type_hints["custom_domains"])
            check_type(argname="argument external", value=external, expected_type=type_hints["external"])
            check_type(argname="argument ip_security_restrictions", value=ip_security_restrictions, expected_type=type_hints["ip_security_restrictions"])
            check_type(argname="argument sticky_sessions", value=sticky_sessions, expected_type=type_hints["sticky_sessions"])
            check_type(argname="argument target_port", value=target_port, expected_type=type_hints["target_port"])
            check_type(argname="argument traffic", value=traffic, expected_type=type_hints["traffic"])
            check_type(argname="argument transport", value=transport, expected_type=type_hints["transport"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if additional_port_mappings is not None:
            self._values["additional_port_mappings"] = additional_port_mappings
        if client_certificate_mode is not None:
            self._values["client_certificate_mode"] = client_certificate_mode
        if cors_policy is not None:
            self._values["cors_policy"] = cors_policy
        if custom_domains is not None:
            self._values["custom_domains"] = custom_domains
        if external is not None:
            self._values["external"] = external
        if ip_security_restrictions is not None:
            self._values["ip_security_restrictions"] = ip_security_restrictions
        if sticky_sessions is not None:
            self._values["sticky_sessions"] = sticky_sessions
        if target_port is not None:
            self._values["target_port"] = target_port
        if traffic is not None:
            self._values["traffic"] = traffic
        if transport is not None:
            self._values["transport"] = transport

    @builtins.property
    def additional_port_mappings(
        self,
    ) -> typing.Optional[typing.List["ContainerAppIngressAdditionalPortMapping"]]:
        '''Additional port mappings for the Container App (2025-07-01+).'''
        result = self._values.get("additional_port_mappings")
        return typing.cast(typing.Optional[typing.List["ContainerAppIngressAdditionalPortMapping"]], result)

    @builtins.property
    def client_certificate_mode(self) -> typing.Optional[builtins.str]:
        '''Client certificate mode.'''
        result = self._values.get("client_certificate_mode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def cors_policy(self) -> typing.Optional["ContainerAppIngressCorsPolicy"]:
        '''CORS policy for the Container App.'''
        result = self._values.get("cors_policy")
        return typing.cast(typing.Optional["ContainerAppIngressCorsPolicy"], result)

    @builtins.property
    def custom_domains(self) -> typing.Optional[typing.List[typing.Any]]:
        '''Custom domain bindings for the Container App's hostname.'''
        result = self._values.get("custom_domains")
        return typing.cast(typing.Optional[typing.List[typing.Any]], result)

    @builtins.property
    def external(self) -> typing.Optional[builtins.bool]:
        '''Whether the ingress is externally accessible.'''
        result = self._values.get("external")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def ip_security_restrictions(
        self,
    ) -> typing.Optional[typing.List["ContainerAppIngressIpSecurityRestriction"]]:
        '''IP security restrictions.'''
        result = self._values.get("ip_security_restrictions")
        return typing.cast(typing.Optional[typing.List["ContainerAppIngressIpSecurityRestriction"]], result)

    @builtins.property
    def sticky_sessions(self) -> typing.Optional["ContainerAppIngressStickySessions"]:
        '''Sticky sessions configuration.'''
        result = self._values.get("sticky_sessions")
        return typing.cast(typing.Optional["ContainerAppIngressStickySessions"], result)

    @builtins.property
    def target_port(self) -> typing.Optional[jsii.Number]:
        '''Target port in the container for incoming traffic.'''
        result = self._values.get("target_port")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def traffic(self) -> typing.Optional[typing.List["ContainerAppIngressTraffic"]]:
        '''Traffic weights for revisions.'''
        result = self._values.get("traffic")
        return typing.cast(typing.Optional[typing.List["ContainerAppIngressTraffic"]], result)

    @builtins.property
    def transport(self) -> typing.Optional[builtins.str]:
        '''Ingress transport protocol: 'auto', 'http', 'http2', or 'tcp'.

        :default: "auto"
        '''
        result = self._values.get("transport")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppIngress(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppIngressAdditionalPortMapping",
    jsii_struct_bases=[],
    name_mapping={
        "target_port": "targetPort",
        "exposed_port": "exposedPort",
        "external": "external",
    },
)
class ContainerAppIngressAdditionalPortMapping:
    def __init__(
        self,
        *,
        target_port: jsii.Number,
        exposed_port: typing.Optional[jsii.Number] = None,
        external: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''Additional port mapping for ingress (2025-07-01+).

        :param target_port: Target port in the container.
        :param exposed_port: Specifies the exposed port for the target port.
        :param external: Whether the port is externally accessible.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95d33f69ebdd89d294e52e2cf9c09340922019b110e78d2d0f6642dd7adeca5d)
            check_type(argname="argument target_port", value=target_port, expected_type=type_hints["target_port"])
            check_type(argname="argument exposed_port", value=exposed_port, expected_type=type_hints["exposed_port"])
            check_type(argname="argument external", value=external, expected_type=type_hints["external"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "target_port": target_port,
        }
        if exposed_port is not None:
            self._values["exposed_port"] = exposed_port
        if external is not None:
            self._values["external"] = external

    @builtins.property
    def target_port(self) -> jsii.Number:
        '''Target port in the container.'''
        result = self._values.get("target_port")
        assert result is not None, "Required property 'target_port' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def exposed_port(self) -> typing.Optional[jsii.Number]:
        '''Specifies the exposed port for the target port.'''
        result = self._values.get("exposed_port")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def external(self) -> typing.Optional[builtins.bool]:
        '''Whether the port is externally accessible.'''
        result = self._values.get("external")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppIngressAdditionalPortMapping(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppIngressCorsPolicy",
    jsii_struct_bases=[],
    name_mapping={
        "allow_credentials": "allowCredentials",
        "allowed_headers": "allowedHeaders",
        "allowed_methods": "allowedMethods",
        "allowed_origins": "allowedOrigins",
        "expose_headers": "exposeHeaders",
        "max_age": "maxAge",
    },
)
class ContainerAppIngressCorsPolicy:
    def __init__(
        self,
        *,
        allow_credentials: typing.Optional[builtins.bool] = None,
        allowed_headers: typing.Optional[typing.Sequence[builtins.str]] = None,
        allowed_methods: typing.Optional[typing.Sequence[builtins.str]] = None,
        allowed_origins: typing.Optional[typing.Sequence[builtins.str]] = None,
        expose_headers: typing.Optional[typing.Sequence[builtins.str]] = None,
        max_age: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''CORS policy for ingress.

        :param allow_credentials: Allow credentials.
        :param allowed_headers: Allowed headers.
        :param allowed_methods: Allowed methods.
        :param allowed_origins: Allowed origins.
        :param expose_headers: Expose headers.
        :param max_age: Max age in seconds.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9463d556a2a90206cdaf75c853133c2d618db6cf71ac0b0d47000435d9c3eedc)
            check_type(argname="argument allow_credentials", value=allow_credentials, expected_type=type_hints["allow_credentials"])
            check_type(argname="argument allowed_headers", value=allowed_headers, expected_type=type_hints["allowed_headers"])
            check_type(argname="argument allowed_methods", value=allowed_methods, expected_type=type_hints["allowed_methods"])
            check_type(argname="argument allowed_origins", value=allowed_origins, expected_type=type_hints["allowed_origins"])
            check_type(argname="argument expose_headers", value=expose_headers, expected_type=type_hints["expose_headers"])
            check_type(argname="argument max_age", value=max_age, expected_type=type_hints["max_age"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if allow_credentials is not None:
            self._values["allow_credentials"] = allow_credentials
        if allowed_headers is not None:
            self._values["allowed_headers"] = allowed_headers
        if allowed_methods is not None:
            self._values["allowed_methods"] = allowed_methods
        if allowed_origins is not None:
            self._values["allowed_origins"] = allowed_origins
        if expose_headers is not None:
            self._values["expose_headers"] = expose_headers
        if max_age is not None:
            self._values["max_age"] = max_age

    @builtins.property
    def allow_credentials(self) -> typing.Optional[builtins.bool]:
        '''Allow credentials.'''
        result = self._values.get("allow_credentials")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def allowed_headers(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Allowed headers.'''
        result = self._values.get("allowed_headers")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def allowed_methods(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Allowed methods.'''
        result = self._values.get("allowed_methods")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def allowed_origins(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Allowed origins.'''
        result = self._values.get("allowed_origins")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def expose_headers(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Expose headers.'''
        result = self._values.get("expose_headers")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def max_age(self) -> typing.Optional[jsii.Number]:
        '''Max age in seconds.'''
        result = self._values.get("max_age")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppIngressCorsPolicy(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppIngressIpSecurityRestriction",
    jsii_struct_bases=[],
    name_mapping={
        "action": "action",
        "ip_address_range": "ipAddressRange",
        "name": "name",
        "description": "description",
    },
)
class ContainerAppIngressIpSecurityRestriction:
    def __init__(
        self,
        *,
        action: builtins.str,
        ip_address_range: builtins.str,
        name: builtins.str,
        description: typing.Optional[builtins.str] = None,
    ) -> None:
        '''IP security restriction for ingress.

        :param action: Allow or Deny.
        :param ip_address_range: CIDR notation to match incoming IP address.
        :param name: Name for the restriction.
        :param description: Description of the restriction.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6211844a6098352fc4e04817b8b069267f935f7862528e924f964feaa7b5de33)
            check_type(argname="argument action", value=action, expected_type=type_hints["action"])
            check_type(argname="argument ip_address_range", value=ip_address_range, expected_type=type_hints["ip_address_range"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "action": action,
            "ip_address_range": ip_address_range,
            "name": name,
        }
        if description is not None:
            self._values["description"] = description

    @builtins.property
    def action(self) -> builtins.str:
        '''Allow or Deny.'''
        result = self._values.get("action")
        assert result is not None, "Required property 'action' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def ip_address_range(self) -> builtins.str:
        '''CIDR notation to match incoming IP address.'''
        result = self._values.get("ip_address_range")
        assert result is not None, "Required property 'ip_address_range' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Name for the restriction.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Description of the restriction.'''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppIngressIpSecurityRestriction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppIngressStickySessions",
    jsii_struct_bases=[],
    name_mapping={"affinity": "affinity"},
)
class ContainerAppIngressStickySessions:
    def __init__(self, *, affinity: typing.Optional[builtins.str] = None) -> None:
        '''Sticky session configuration.

        :param affinity: Sticky session affinity: 'none' or 'sticky'.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81fe05939add05cafb1a14cfece2ae6383c8e72f09e08792f0286f7f349f3f16)
            check_type(argname="argument affinity", value=affinity, expected_type=type_hints["affinity"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if affinity is not None:
            self._values["affinity"] = affinity

    @builtins.property
    def affinity(self) -> typing.Optional[builtins.str]:
        '''Sticky session affinity: 'none' or 'sticky'.'''
        result = self._values.get("affinity")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppIngressStickySessions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppIngressTraffic",
    jsii_struct_bases=[],
    name_mapping={
        "label": "label",
        "latest_revision": "latestRevision",
        "revision_name": "revisionName",
        "weight": "weight",
    },
)
class ContainerAppIngressTraffic:
    def __init__(
        self,
        *,
        label: typing.Optional[builtins.str] = None,
        latest_revision: typing.Optional[builtins.bool] = None,
        revision_name: typing.Optional[builtins.str] = None,
        weight: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''Traffic weight configuration for ingress.

        :param label: Associates a traffic label with a revision.
        :param latest_revision: Indicates if this is the latest revision.
        :param revision_name: Name of a revision.
        :param weight: Traffic weight assigned to the revision.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ec975e16035b1efb18fefb142880d2040fcad55ec4df1afbe7dddbe6e46832f)
            check_type(argname="argument label", value=label, expected_type=type_hints["label"])
            check_type(argname="argument latest_revision", value=latest_revision, expected_type=type_hints["latest_revision"])
            check_type(argname="argument revision_name", value=revision_name, expected_type=type_hints["revision_name"])
            check_type(argname="argument weight", value=weight, expected_type=type_hints["weight"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if label is not None:
            self._values["label"] = label
        if latest_revision is not None:
            self._values["latest_revision"] = latest_revision
        if revision_name is not None:
            self._values["revision_name"] = revision_name
        if weight is not None:
            self._values["weight"] = weight

    @builtins.property
    def label(self) -> typing.Optional[builtins.str]:
        '''Associates a traffic label with a revision.'''
        result = self._values.get("label")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def latest_revision(self) -> typing.Optional[builtins.bool]:
        '''Indicates if this is the latest revision.'''
        result = self._values.get("latest_revision")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def revision_name(self) -> typing.Optional[builtins.str]:
        '''Name of a revision.'''
        result = self._values.get("revision_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def weight(self) -> typing.Optional[jsii.Number]:
        '''Traffic weight assigned to the revision.'''
        result = self._values.get("weight")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppIngressTraffic(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppJavaRuntimeConfig",
    jsii_struct_bases=[],
    name_mapping={"enable_metrics": "enableMetrics"},
)
class ContainerAppJavaRuntimeConfig:
    def __init__(
        self,
        *,
        enable_metrics: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''Java runtime configuration (2025-07-01+).

        :param enable_metrics: Whether to enable Java metrics.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__022a572310ba6a9aa3526ef7c29e87eb22416f93adf72fdc860a8a79d3d1bc22)
            check_type(argname="argument enable_metrics", value=enable_metrics, expected_type=type_hints["enable_metrics"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if enable_metrics is not None:
            self._values["enable_metrics"] = enable_metrics

    @builtins.property
    def enable_metrics(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable Java metrics.'''
        result = self._values.get("enable_metrics")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppJavaRuntimeConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppProbe",
    jsii_struct_bases=[],
    name_mapping={
        "failure_threshold": "failureThreshold",
        "http_get": "httpGet",
        "initial_delay_seconds": "initialDelaySeconds",
        "period_seconds": "periodSeconds",
        "success_threshold": "successThreshold",
        "tcp_socket": "tcpSocket",
        "timeout_seconds": "timeoutSeconds",
        "type": "type",
    },
)
class ContainerAppProbe:
    def __init__(
        self,
        *,
        failure_threshold: typing.Optional[jsii.Number] = None,
        http_get: typing.Optional[typing.Union["ContainerAppProbeHttpGet", typing.Dict[builtins.str, typing.Any]]] = None,
        initial_delay_seconds: typing.Optional[jsii.Number] = None,
        period_seconds: typing.Optional[jsii.Number] = None,
        success_threshold: typing.Optional[jsii.Number] = None,
        tcp_socket: typing.Optional[typing.Union["ContainerAppProbeTcpSocket", typing.Dict[builtins.str, typing.Any]]] = None,
        timeout_seconds: typing.Optional[jsii.Number] = None,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Container probe (liveness, readiness, or startup).

        :param failure_threshold: Minimum consecutive failures for the probe to be considered failed.
        :param http_get: HTTPGet specifies the HTTP request to perform.
        :param initial_delay_seconds: Number of seconds after the container has started before probes are initiated.
        :param period_seconds: How often (in seconds) to perform the probe.
        :param success_threshold: Minimum consecutive successes for the probe to be considered successful.
        :param tcp_socket: TCPSocket specifies an action involving a TCP port.
        :param timeout_seconds: Number of seconds after which the probe times out.
        :param type: The type of probe: Liveness, Readiness, or Startup.
        '''
        if isinstance(http_get, dict):
            http_get = ContainerAppProbeHttpGet(**http_get)
        if isinstance(tcp_socket, dict):
            tcp_socket = ContainerAppProbeTcpSocket(**tcp_socket)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__815613d5f6a44319cc69d7e5c2e815e61ce7e5e66a90124c2f5c76f41137c631)
            check_type(argname="argument failure_threshold", value=failure_threshold, expected_type=type_hints["failure_threshold"])
            check_type(argname="argument http_get", value=http_get, expected_type=type_hints["http_get"])
            check_type(argname="argument initial_delay_seconds", value=initial_delay_seconds, expected_type=type_hints["initial_delay_seconds"])
            check_type(argname="argument period_seconds", value=period_seconds, expected_type=type_hints["period_seconds"])
            check_type(argname="argument success_threshold", value=success_threshold, expected_type=type_hints["success_threshold"])
            check_type(argname="argument tcp_socket", value=tcp_socket, expected_type=type_hints["tcp_socket"])
            check_type(argname="argument timeout_seconds", value=timeout_seconds, expected_type=type_hints["timeout_seconds"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if failure_threshold is not None:
            self._values["failure_threshold"] = failure_threshold
        if http_get is not None:
            self._values["http_get"] = http_get
        if initial_delay_seconds is not None:
            self._values["initial_delay_seconds"] = initial_delay_seconds
        if period_seconds is not None:
            self._values["period_seconds"] = period_seconds
        if success_threshold is not None:
            self._values["success_threshold"] = success_threshold
        if tcp_socket is not None:
            self._values["tcp_socket"] = tcp_socket
        if timeout_seconds is not None:
            self._values["timeout_seconds"] = timeout_seconds
        if type is not None:
            self._values["type"] = type

    @builtins.property
    def failure_threshold(self) -> typing.Optional[jsii.Number]:
        '''Minimum consecutive failures for the probe to be considered failed.'''
        result = self._values.get("failure_threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def http_get(self) -> typing.Optional["ContainerAppProbeHttpGet"]:
        '''HTTPGet specifies the HTTP request to perform.'''
        result = self._values.get("http_get")
        return typing.cast(typing.Optional["ContainerAppProbeHttpGet"], result)

    @builtins.property
    def initial_delay_seconds(self) -> typing.Optional[jsii.Number]:
        '''Number of seconds after the container has started before probes are initiated.'''
        result = self._values.get("initial_delay_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def period_seconds(self) -> typing.Optional[jsii.Number]:
        '''How often (in seconds) to perform the probe.'''
        result = self._values.get("period_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def success_threshold(self) -> typing.Optional[jsii.Number]:
        '''Minimum consecutive successes for the probe to be considered successful.'''
        result = self._values.get("success_threshold")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def tcp_socket(self) -> typing.Optional["ContainerAppProbeTcpSocket"]:
        '''TCPSocket specifies an action involving a TCP port.'''
        result = self._values.get("tcp_socket")
        return typing.cast(typing.Optional["ContainerAppProbeTcpSocket"], result)

    @builtins.property
    def timeout_seconds(self) -> typing.Optional[jsii.Number]:
        '''Number of seconds after which the probe times out.'''
        result = self._values.get("timeout_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''The type of probe: Liveness, Readiness, or Startup.'''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppProbe(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppProbeHttpGet",
    jsii_struct_bases=[],
    name_mapping={
        "port": "port",
        "http_headers": "httpHeaders",
        "path": "path",
        "scheme": "scheme",
    },
)
class ContainerAppProbeHttpGet:
    def __init__(
        self,
        *,
        port: jsii.Number,
        http_headers: typing.Optional[typing.Sequence[typing.Union["ContainerAppProbeHttpHeader", typing.Dict[builtins.str, typing.Any]]]] = None,
        path: typing.Optional[builtins.str] = None,
        scheme: typing.Optional[builtins.str] = None,
    ) -> None:
        '''HTTP GET action for a probe.

        :param port: Port number to access on the container.
        :param http_headers: Custom headers to set in the request.
        :param path: Path to access on the HTTP server.
        :param scheme: Scheme to use for connecting to the host (HTTP or HTTPS).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54083032728a61f1fb7f0b8959156bdd261257a798189adf47ed52d0ef4b98e1)
            check_type(argname="argument port", value=port, expected_type=type_hints["port"])
            check_type(argname="argument http_headers", value=http_headers, expected_type=type_hints["http_headers"])
            check_type(argname="argument path", value=path, expected_type=type_hints["path"])
            check_type(argname="argument scheme", value=scheme, expected_type=type_hints["scheme"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "port": port,
        }
        if http_headers is not None:
            self._values["http_headers"] = http_headers
        if path is not None:
            self._values["path"] = path
        if scheme is not None:
            self._values["scheme"] = scheme

    @builtins.property
    def port(self) -> jsii.Number:
        '''Port number to access on the container.'''
        result = self._values.get("port")
        assert result is not None, "Required property 'port' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def http_headers(
        self,
    ) -> typing.Optional[typing.List["ContainerAppProbeHttpHeader"]]:
        '''Custom headers to set in the request.'''
        result = self._values.get("http_headers")
        return typing.cast(typing.Optional[typing.List["ContainerAppProbeHttpHeader"]], result)

    @builtins.property
    def path(self) -> typing.Optional[builtins.str]:
        '''Path to access on the HTTP server.'''
        result = self._values.get("path")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def scheme(self) -> typing.Optional[builtins.str]:
        '''Scheme to use for connecting to the host (HTTP or HTTPS).'''
        result = self._values.get("scheme")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppProbeHttpGet(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppProbeHttpHeader",
    jsii_struct_bases=[],
    name_mapping={"name": "name", "value": "value"},
)
class ContainerAppProbeHttpHeader:
    def __init__(self, *, name: builtins.str, value: builtins.str) -> None:
        '''HTTP header for a probe.

        :param name: The header field name.
        :param value: The header field value.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__13cd67381702f9bf29fb3c39305e931a80087d39f3efd6f0d5afbd56b3683922)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
            "value": value,
        }

    @builtins.property
    def name(self) -> builtins.str:
        '''The header field name.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def value(self) -> builtins.str:
        '''The header field value.'''
        result = self._values.get("value")
        assert result is not None, "Required property 'value' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppProbeHttpHeader(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppProbeTcpSocket",
    jsii_struct_bases=[],
    name_mapping={"port": "port"},
)
class ContainerAppProbeTcpSocket:
    def __init__(self, *, port: jsii.Number) -> None:
        '''TCP socket action for a probe.

        :param port: TCP port to connect to.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__756cbe0b9d24cdea677583029f9d3e5f5a77b474d1050d38f0f0aaafd4321516)
            check_type(argname="argument port", value=port, expected_type=type_hints["port"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "port": port,
        }

    @builtins.property
    def port(self) -> jsii.Number:
        '''TCP port to connect to.'''
        result = self._values.get("port")
        assert result is not None, "Required property 'port' is missing"
        return typing.cast(jsii.Number, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppProbeTcpSocket(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppProps",
    jsii_struct_bases=[_AzapiResourceProps_141a2340],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "api_version": "apiVersion",
        "enable_migration_analysis": "enableMigrationAnalysis",
        "enable_transformation": "enableTransformation",
        "enable_validation": "enableValidation",
        "location": "location",
        "monitoring": "monitoring",
        "name": "name",
        "tags": "tags",
        "environment_id": "environmentId",
        "template": "template",
        "configuration": "configuration",
        "identity": "identity",
        "ignore_changes": "ignoreChanges",
        "resource_group_id": "resourceGroupId",
        "workload_profile_name": "workloadProfileName",
    },
)
class ContainerAppProps(_AzapiResourceProps_141a2340):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        api_version: typing.Optional[builtins.str] = None,
        enable_migration_analysis: typing.Optional[builtins.bool] = None,
        enable_transformation: typing.Optional[builtins.bool] = None,
        enable_validation: typing.Optional[builtins.bool] = None,
        location: typing.Optional[builtins.str] = None,
        monitoring: typing.Optional[typing.Union["_MonitoringConfig_7c28df74", typing.Dict[builtins.str, typing.Any]]] = None,
        name: typing.Optional[builtins.str] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        environment_id: builtins.str,
        template: typing.Union["ContainerAppTemplate", typing.Dict[builtins.str, typing.Any]],
        configuration: typing.Optional[typing.Union["ContainerAppConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        identity: typing.Optional[typing.Union["ContainerAppIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_group_id: typing.Optional[builtins.str] = None,
        workload_profile_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Properties for the unified Azure Container App.

        Extends AzapiResourceProps with Container App specific properties

        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param api_version: Explicit API version to use for this resource. If not specified, the latest active version will be automatically resolved. Use this for version pinning when stability is required over latest features. Default: Latest active version from ApiVersionManager
        :param enable_migration_analysis: Whether to enable migration analysis warnings. When true, the framework will analyze the current version for deprecation status and provide migration recommendations in the deployment output. Default: true
        :param enable_transformation: Whether to apply property transformations automatically. When true, properties will be automatically transformed according to the target schema's transformation rules. This enables backward compatibility. Default: true
        :param enable_validation: Whether to validate properties against the schema. When true, all properties will be validated against the API schema before resource creation. Validation errors will cause deployment failures. Default: true
        :param location: The location where the resource should be created. Default: Varies by resource type - see specific resource documentation
        :param monitoring: Monitoring configuration for this resource. Enables integrated monitoring with diagnostic settings, metric alerts, and activity log alerts. All monitoring is optional and disabled by default.
        :param name: The name of the resource.
        :param tags: Tags to apply to the resource.
        :param environment_id: Resource ID of the Container App Environment where this app will be hosted.
        :param template: Container App versioned application definition.
        :param configuration: Non-versioned Container App configuration properties.
        :param identity: Managed identity configuration.
        :param ignore_changes: The lifecycle rules to ignore changes.
        :param resource_group_id: Resource group ID where the Container App will be created.
        :param workload_profile_name: Workload profile name to pin for container app execution.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(monitoring, dict):
            monitoring = _MonitoringConfig_7c28df74(**monitoring)
        if isinstance(template, dict):
            template = ContainerAppTemplate(**template)
        if isinstance(configuration, dict):
            configuration = ContainerAppConfiguration(**configuration)
        if isinstance(identity, dict):
            identity = ContainerAppIdentity(**identity)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56668be42531cffd6e33b71d24eaffe4106f7b3eb4e1bd6b76e0715052d25044)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
            check_type(argname="argument enable_migration_analysis", value=enable_migration_analysis, expected_type=type_hints["enable_migration_analysis"])
            check_type(argname="argument enable_transformation", value=enable_transformation, expected_type=type_hints["enable_transformation"])
            check_type(argname="argument enable_validation", value=enable_validation, expected_type=type_hints["enable_validation"])
            check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument environment_id", value=environment_id, expected_type=type_hints["environment_id"])
            check_type(argname="argument template", value=template, expected_type=type_hints["template"])
            check_type(argname="argument configuration", value=configuration, expected_type=type_hints["configuration"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument ignore_changes", value=ignore_changes, expected_type=type_hints["ignore_changes"])
            check_type(argname="argument resource_group_id", value=resource_group_id, expected_type=type_hints["resource_group_id"])
            check_type(argname="argument workload_profile_name", value=workload_profile_name, expected_type=type_hints["workload_profile_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "environment_id": environment_id,
            "template": template,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if api_version is not None:
            self._values["api_version"] = api_version
        if enable_migration_analysis is not None:
            self._values["enable_migration_analysis"] = enable_migration_analysis
        if enable_transformation is not None:
            self._values["enable_transformation"] = enable_transformation
        if enable_validation is not None:
            self._values["enable_validation"] = enable_validation
        if location is not None:
            self._values["location"] = location
        if monitoring is not None:
            self._values["monitoring"] = monitoring
        if name is not None:
            self._values["name"] = name
        if tags is not None:
            self._values["tags"] = tags
        if configuration is not None:
            self._values["configuration"] = configuration
        if identity is not None:
            self._values["identity"] = identity
        if ignore_changes is not None:
            self._values["ignore_changes"] = ignore_changes
        if resource_group_id is not None:
            self._values["resource_group_id"] = resource_group_id
        if workload_profile_name is not None:
            self._values["workload_profile_name"] = workload_profile_name

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def api_version(self) -> typing.Optional[builtins.str]:
        '''Explicit API version to use for this resource.

        If not specified, the latest active version will be automatically resolved.
        Use this for version pinning when stability is required over latest features.

        :default: Latest active version from ApiVersionManager

        Example::

            "2024-11-01"
        '''
        result = self._values.get("api_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def enable_migration_analysis(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable migration analysis warnings.

        When true, the framework will analyze the current version for deprecation
        status and provide migration recommendations in the deployment output.

        :default: true
        '''
        result = self._values.get("enable_migration_analysis")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_transformation(self) -> typing.Optional[builtins.bool]:
        '''Whether to apply property transformations automatically.

        When true, properties will be automatically transformed according to the
        target schema's transformation rules. This enables backward compatibility.

        :default: true
        '''
        result = self._values.get("enable_transformation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_validation(self) -> typing.Optional[builtins.bool]:
        '''Whether to validate properties against the schema.

        When true, all properties will be validated against the API schema before
        resource creation. Validation errors will cause deployment failures.

        :default: true
        '''
        result = self._values.get("enable_validation")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def location(self) -> typing.Optional[builtins.str]:
        '''The location where the resource should be created.

        :default: Varies by resource type - see specific resource documentation

        :remarks:

        Location handling varies by resource type:

        - **Top-level resources**: Most require an explicit location (e.g., "eastus", "westus")
        - **Global resources**: Some use "global" as location (e.g., Private DNS Zones)
        - **Child resources**: Inherit location from parent and should NOT set this property

        Each resource type may provide its own default through the ``resolveLocation()`` method.
        If no location is specified and no default exists, resource creation may fail.

        Example::

            // Child resource (Subnet) - do not set location
            // location: undefined (inherited from parent Virtual Network)
        '''
        result = self._values.get("location")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def monitoring(self) -> typing.Optional["_MonitoringConfig_7c28df74"]:
        '''Monitoring configuration for this resource.

        Enables integrated monitoring with diagnostic settings, metric alerts,
        and activity log alerts. All monitoring is optional and disabled by default.

        Example::

            monitoring: {
              enabled: true,
              diagnosticSettings: {
                workspaceId: logAnalytics.id,
                metrics: ['AllMetrics'],
                logs: ['AuditLogs']
              },
              metricAlerts: [{
                name: 'high-cpu-alert',
                severity: 2,
                scopes: [], // Automatically set to this resource
                criteria: { ... },
                actions: [{ actionGroupId: actionGroup.id }]
              }]
            }
        '''
        result = self._values.get("monitoring")
        return typing.cast(typing.Optional["_MonitoringConfig_7c28df74"], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''The name of the resource.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Tags to apply to the resource.'''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def environment_id(self) -> builtins.str:
        '''Resource ID of the Container App Environment where this app will be hosted.'''
        result = self._values.get("environment_id")
        assert result is not None, "Required property 'environment_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def template(self) -> "ContainerAppTemplate":
        '''Container App versioned application definition.'''
        result = self._values.get("template")
        assert result is not None, "Required property 'template' is missing"
        return typing.cast("ContainerAppTemplate", result)

    @builtins.property
    def configuration(self) -> typing.Optional["ContainerAppConfiguration"]:
        '''Non-versioned Container App configuration properties.'''
        result = self._values.get("configuration")
        return typing.cast(typing.Optional["ContainerAppConfiguration"], result)

    @builtins.property
    def identity(self) -> typing.Optional["ContainerAppIdentity"]:
        '''Managed identity configuration.'''
        result = self._values.get("identity")
        return typing.cast(typing.Optional["ContainerAppIdentity"], result)

    @builtins.property
    def ignore_changes(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The lifecycle rules to ignore changes.

        Example::

            ["tags"]
        '''
        result = self._values.get("ignore_changes")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def resource_group_id(self) -> typing.Optional[builtins.str]:
        '''Resource group ID where the Container App will be created.'''
        result = self._values.get("resource_group_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def workload_profile_name(self) -> typing.Optional[builtins.str]:
        '''Workload profile name to pin for container app execution.'''
        result = self._values.get("workload_profile_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppRegistry",
    jsii_struct_bases=[],
    name_mapping={
        "server": "server",
        "identity": "identity",
        "password_secret_ref": "passwordSecretRef",
        "username": "username",
    },
)
class ContainerAppRegistry:
    def __init__(
        self,
        *,
        server: builtins.str,
        identity: typing.Optional[builtins.str] = None,
        password_secret_ref: typing.Optional[builtins.str] = None,
        username: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Container registry configuration.

        :param server: Container registry server URL.
        :param identity: Managed identity to authenticate with the registry.
        :param password_secret_ref: Name of the secret containing the registry password.
        :param username: Registry username.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4dc682bd87546dd1560c6240165d1bd45ccbfa993b7d76b097dc3c27c4dc7187)
            check_type(argname="argument server", value=server, expected_type=type_hints["server"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument password_secret_ref", value=password_secret_ref, expected_type=type_hints["password_secret_ref"])
            check_type(argname="argument username", value=username, expected_type=type_hints["username"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "server": server,
        }
        if identity is not None:
            self._values["identity"] = identity
        if password_secret_ref is not None:
            self._values["password_secret_ref"] = password_secret_ref
        if username is not None:
            self._values["username"] = username

    @builtins.property
    def server(self) -> builtins.str:
        '''Container registry server URL.'''
        result = self._values.get("server")
        assert result is not None, "Required property 'server' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def identity(self) -> typing.Optional[builtins.str]:
        '''Managed identity to authenticate with the registry.'''
        result = self._values.get("identity")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def password_secret_ref(self) -> typing.Optional[builtins.str]:
        '''Name of the secret containing the registry password.'''
        result = self._values.get("password_secret_ref")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def username(self) -> typing.Optional[builtins.str]:
        '''Registry username.'''
        result = self._values.get("username")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppRegistry(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppRuntime",
    jsii_struct_bases=[],
    name_mapping={"java": "java"},
)
class ContainerAppRuntime:
    def __init__(
        self,
        *,
        java: typing.Optional[typing.Union["ContainerAppJavaRuntimeConfig", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Runtime configuration (2025-07-01+).

        :param java: Java runtime configuration.
        '''
        if isinstance(java, dict):
            java = ContainerAppJavaRuntimeConfig(**java)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4e4e45dc9b6bd79fe233fd2c893702f598e5da95ed6835f8563f06c167bdbdf8)
            check_type(argname="argument java", value=java, expected_type=type_hints["java"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if java is not None:
            self._values["java"] = java

    @builtins.property
    def java(self) -> typing.Optional["ContainerAppJavaRuntimeConfig"]:
        '''Java runtime configuration.'''
        result = self._values.get("java")
        return typing.cast(typing.Optional["ContainerAppJavaRuntimeConfig"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppRuntime(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppScale",
    jsii_struct_bases=[],
    name_mapping={
        "cooldown_period": "cooldownPeriod",
        "max_replicas": "maxReplicas",
        "min_replicas": "minReplicas",
        "polling_interval": "pollingInterval",
        "rules": "rules",
    },
)
class ContainerAppScale:
    def __init__(
        self,
        *,
        cooldown_period: typing.Optional[jsii.Number] = None,
        max_replicas: typing.Optional[jsii.Number] = None,
        min_replicas: typing.Optional[jsii.Number] = None,
        polling_interval: typing.Optional[jsii.Number] = None,
        rules: typing.Optional[typing.Sequence[typing.Union["ContainerAppScaleRule", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> None:
        '''Scale configuration for the Container App.

        :param cooldown_period: Cooldown period in seconds before scaling down (2025-07-01+).
        :param max_replicas: Maximum number of replicas. Default: 10
        :param min_replicas: Minimum number of replicas. Default: 0
        :param polling_interval: Polling interval in seconds for checking scale rules (2025-07-01+).
        :param rules: Scaling rules.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b9bd71884c3f965233e2fbb5563b22aca146361f6b9c521e86806f535473ad9)
            check_type(argname="argument cooldown_period", value=cooldown_period, expected_type=type_hints["cooldown_period"])
            check_type(argname="argument max_replicas", value=max_replicas, expected_type=type_hints["max_replicas"])
            check_type(argname="argument min_replicas", value=min_replicas, expected_type=type_hints["min_replicas"])
            check_type(argname="argument polling_interval", value=polling_interval, expected_type=type_hints["polling_interval"])
            check_type(argname="argument rules", value=rules, expected_type=type_hints["rules"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if cooldown_period is not None:
            self._values["cooldown_period"] = cooldown_period
        if max_replicas is not None:
            self._values["max_replicas"] = max_replicas
        if min_replicas is not None:
            self._values["min_replicas"] = min_replicas
        if polling_interval is not None:
            self._values["polling_interval"] = polling_interval
        if rules is not None:
            self._values["rules"] = rules

    @builtins.property
    def cooldown_period(self) -> typing.Optional[jsii.Number]:
        '''Cooldown period in seconds before scaling down (2025-07-01+).'''
        result = self._values.get("cooldown_period")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def max_replicas(self) -> typing.Optional[jsii.Number]:
        '''Maximum number of replicas.

        :default: 10
        '''
        result = self._values.get("max_replicas")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def min_replicas(self) -> typing.Optional[jsii.Number]:
        '''Minimum number of replicas.

        :default: 0
        '''
        result = self._values.get("min_replicas")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def polling_interval(self) -> typing.Optional[jsii.Number]:
        '''Polling interval in seconds for checking scale rules (2025-07-01+).'''
        result = self._values.get("polling_interval")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def rules(self) -> typing.Optional[typing.List["ContainerAppScaleRule"]]:
        '''Scaling rules.'''
        result = self._values.get("rules")
        return typing.cast(typing.Optional[typing.List["ContainerAppScaleRule"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppScale(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppScaleRule",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "azure_queue": "azureQueue",
        "custom": "custom",
        "http": "http",
        "tcp": "tcp",
    },
)
class ContainerAppScaleRule:
    def __init__(
        self,
        *,
        name: builtins.str,
        azure_queue: typing.Optional[typing.Union["ContainerAppAzureQueueScaleRule", typing.Dict[builtins.str, typing.Any]]] = None,
        custom: typing.Optional[typing.Union["ContainerAppCustomScaleRule", typing.Dict[builtins.str, typing.Any]]] = None,
        http: typing.Optional[typing.Union["ContainerAppHttpScaleRule", typing.Dict[builtins.str, typing.Any]]] = None,
        tcp: typing.Optional[typing.Union["ContainerAppTcpScaleRule", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''Scale rule definition.

        :param name: Scale rule name.
        :param azure_queue: Azure Queue scale rule.
        :param custom: Custom scale rule (KEDA).
        :param http: HTTP scale rule.
        :param tcp: TCP scale rule.
        '''
        if isinstance(azure_queue, dict):
            azure_queue = ContainerAppAzureQueueScaleRule(**azure_queue)
        if isinstance(custom, dict):
            custom = ContainerAppCustomScaleRule(**custom)
        if isinstance(http, dict):
            http = ContainerAppHttpScaleRule(**http)
        if isinstance(tcp, dict):
            tcp = ContainerAppTcpScaleRule(**tcp)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d536edaf2e13f635c63c8248b98ed31409be601e1d94fde96bfce31ace52604f)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument azure_queue", value=azure_queue, expected_type=type_hints["azure_queue"])
            check_type(argname="argument custom", value=custom, expected_type=type_hints["custom"])
            check_type(argname="argument http", value=http, expected_type=type_hints["http"])
            check_type(argname="argument tcp", value=tcp, expected_type=type_hints["tcp"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }
        if azure_queue is not None:
            self._values["azure_queue"] = azure_queue
        if custom is not None:
            self._values["custom"] = custom
        if http is not None:
            self._values["http"] = http
        if tcp is not None:
            self._values["tcp"] = tcp

    @builtins.property
    def name(self) -> builtins.str:
        '''Scale rule name.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def azure_queue(self) -> typing.Optional["ContainerAppAzureQueueScaleRule"]:
        '''Azure Queue scale rule.'''
        result = self._values.get("azure_queue")
        return typing.cast(typing.Optional["ContainerAppAzureQueueScaleRule"], result)

    @builtins.property
    def custom(self) -> typing.Optional["ContainerAppCustomScaleRule"]:
        '''Custom scale rule (KEDA).'''
        result = self._values.get("custom")
        return typing.cast(typing.Optional["ContainerAppCustomScaleRule"], result)

    @builtins.property
    def http(self) -> typing.Optional["ContainerAppHttpScaleRule"]:
        '''HTTP scale rule.'''
        result = self._values.get("http")
        return typing.cast(typing.Optional["ContainerAppHttpScaleRule"], result)

    @builtins.property
    def tcp(self) -> typing.Optional["ContainerAppTcpScaleRule"]:
        '''TCP scale rule.'''
        result = self._values.get("tcp")
        return typing.cast(typing.Optional["ContainerAppTcpScaleRule"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppScaleRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppSecret",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "identity": "identity",
        "key_vault_url": "keyVaultUrl",
        "value": "value",
    },
)
class ContainerAppSecret:
    def __init__(
        self,
        *,
        name: builtins.str,
        identity: typing.Optional[builtins.str] = None,
        key_vault_url: typing.Optional[builtins.str] = None,
        value: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Secret configuration for the Container App.

        :param name: Secret name.
        :param identity: Resource ID of a managed identity to authenticate with Key Vault.
        :param key_vault_url: Key Vault secret URI (mutually exclusive with value).
        :param value: Secret value (mutually exclusive with keyVaultUrl).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c9bd8547859fdbde215e3258ffdef25cbd5f8a6b6cc5441c7663128c04c85826)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument identity", value=identity, expected_type=type_hints["identity"])
            check_type(argname="argument key_vault_url", value=key_vault_url, expected_type=type_hints["key_vault_url"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }
        if identity is not None:
            self._values["identity"] = identity
        if key_vault_url is not None:
            self._values["key_vault_url"] = key_vault_url
        if value is not None:
            self._values["value"] = value

    @builtins.property
    def name(self) -> builtins.str:
        '''Secret name.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def identity(self) -> typing.Optional[builtins.str]:
        '''Resource ID of a managed identity to authenticate with Key Vault.'''
        result = self._values.get("identity")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def key_vault_url(self) -> typing.Optional[builtins.str]:
        '''Key Vault secret URI (mutually exclusive with value).'''
        result = self._values.get("key_vault_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def value(self) -> typing.Optional[builtins.str]:
        '''Secret value (mutually exclusive with keyVaultUrl).'''
        result = self._values.get("value")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppSecret(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppService",
    jsii_struct_bases=[],
    name_mapping={"type": "type"},
)
class ContainerAppService:
    def __init__(self, *, type: builtins.str) -> None:
        '''Service configuration for dev services.

        :param type: Dev Service type (e.g., 'redis', 'postgres', 'kafka').
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__68be900da3a6d735bb9e72efcf8ac84aa004f87ca4814b8860e6cf7ef5f25699)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }

    @builtins.property
    def type(self) -> builtins.str:
        '''Dev Service type (e.g., 'redis', 'postgres', 'kafka').'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppService(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppServiceBind",
    jsii_struct_bases=[],
    name_mapping={"name": "name", "service_id": "serviceId"},
)
class ContainerAppServiceBind:
    def __init__(self, *, name: builtins.str, service_id: builtins.str) -> None:
        '''Service bind configuration (2025-07-01+).

        :param name: Name of the service binding.
        :param service_id: Resource ID of the service to bind to.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb8e9460db2dca1fbd51f4bb909ec1d53fe390b1752eb91226292099329a31f2)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument service_id", value=service_id, expected_type=type_hints["service_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
            "service_id": service_id,
        }

    @builtins.property
    def name(self) -> builtins.str:
        '''Name of the service binding.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def service_id(self) -> builtins.str:
        '''Resource ID of the service to bind to.'''
        result = self._values.get("service_id")
        assert result is not None, "Required property 'service_id' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppServiceBind(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppTcpScaleRule",
    jsii_struct_bases=[],
    name_mapping={"metadata": "metadata"},
)
class ContainerAppTcpScaleRule:
    def __init__(
        self,
        *,
        metadata: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''TCP scale rule configuration.

        :param metadata: TCP trigger metadata as key-value pairs.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__57e6d5886cedd64ecf0c53fd79c0841c8ecc4f6597b37a48ace494af0b07b4a6)
            check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if metadata is not None:
            self._values["metadata"] = metadata

    @builtins.property
    def metadata(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''TCP trigger metadata as key-value pairs.'''
        result = self._values.get("metadata")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppTcpScaleRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppTemplate",
    jsii_struct_bases=[],
    name_mapping={
        "containers": "containers",
        "init_containers": "initContainers",
        "revision_suffix": "revisionSuffix",
        "scale": "scale",
        "service_binds": "serviceBinds",
        "termination_grace_period_seconds": "terminationGracePeriodSeconds",
        "volumes": "volumes",
    },
)
class ContainerAppTemplate:
    def __init__(
        self,
        *,
        containers: typing.Sequence[typing.Union["ContainerAppContainer", typing.Dict[builtins.str, typing.Any]]],
        init_containers: typing.Optional[typing.Sequence[typing.Union["ContainerAppContainer", typing.Dict[builtins.str, typing.Any]]]] = None,
        revision_suffix: typing.Optional[builtins.str] = None,
        scale: typing.Optional[typing.Union["ContainerAppScale", typing.Dict[builtins.str, typing.Any]]] = None,
        service_binds: typing.Optional[typing.Sequence[typing.Union["ContainerAppServiceBind", typing.Dict[builtins.str, typing.Any]]]] = None,
        termination_grace_period_seconds: typing.Optional[jsii.Number] = None,
        volumes: typing.Optional[typing.Sequence[typing.Union["ContainerAppVolume", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> None:
        '''Container App template.

        :param containers: List of container definitions for the Container App.
        :param init_containers: List of specialized containers that run before app containers.
        :param revision_suffix: User friendly suffix appended to the revision name.
        :param scale: Scaling properties for the Container App.
        :param service_binds: List of container app services bound to the app (2025-07-01+).
        :param termination_grace_period_seconds: Optional duration in seconds for graceful termination.
        :param volumes: List of volume definitions for the Container App.
        '''
        if isinstance(scale, dict):
            scale = ContainerAppScale(**scale)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80332833d4c98a833cd74ae637bfb72b3f9b947c13bff3e3e954e2bf9e080255)
            check_type(argname="argument containers", value=containers, expected_type=type_hints["containers"])
            check_type(argname="argument init_containers", value=init_containers, expected_type=type_hints["init_containers"])
            check_type(argname="argument revision_suffix", value=revision_suffix, expected_type=type_hints["revision_suffix"])
            check_type(argname="argument scale", value=scale, expected_type=type_hints["scale"])
            check_type(argname="argument service_binds", value=service_binds, expected_type=type_hints["service_binds"])
            check_type(argname="argument termination_grace_period_seconds", value=termination_grace_period_seconds, expected_type=type_hints["termination_grace_period_seconds"])
            check_type(argname="argument volumes", value=volumes, expected_type=type_hints["volumes"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "containers": containers,
        }
        if init_containers is not None:
            self._values["init_containers"] = init_containers
        if revision_suffix is not None:
            self._values["revision_suffix"] = revision_suffix
        if scale is not None:
            self._values["scale"] = scale
        if service_binds is not None:
            self._values["service_binds"] = service_binds
        if termination_grace_period_seconds is not None:
            self._values["termination_grace_period_seconds"] = termination_grace_period_seconds
        if volumes is not None:
            self._values["volumes"] = volumes

    @builtins.property
    def containers(self) -> typing.List["ContainerAppContainer"]:
        '''List of container definitions for the Container App.'''
        result = self._values.get("containers")
        assert result is not None, "Required property 'containers' is missing"
        return typing.cast(typing.List["ContainerAppContainer"], result)

    @builtins.property
    def init_containers(self) -> typing.Optional[typing.List["ContainerAppContainer"]]:
        '''List of specialized containers that run before app containers.'''
        result = self._values.get("init_containers")
        return typing.cast(typing.Optional[typing.List["ContainerAppContainer"]], result)

    @builtins.property
    def revision_suffix(self) -> typing.Optional[builtins.str]:
        '''User friendly suffix appended to the revision name.'''
        result = self._values.get("revision_suffix")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def scale(self) -> typing.Optional["ContainerAppScale"]:
        '''Scaling properties for the Container App.'''
        result = self._values.get("scale")
        return typing.cast(typing.Optional["ContainerAppScale"], result)

    @builtins.property
    def service_binds(self) -> typing.Optional[typing.List["ContainerAppServiceBind"]]:
        '''List of container app services bound to the app (2025-07-01+).'''
        result = self._values.get("service_binds")
        return typing.cast(typing.Optional[typing.List["ContainerAppServiceBind"]], result)

    @builtins.property
    def termination_grace_period_seconds(self) -> typing.Optional[jsii.Number]:
        '''Optional duration in seconds for graceful termination.'''
        result = self._values.get("termination_grace_period_seconds")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def volumes(self) -> typing.Optional[typing.List["ContainerAppVolume"]]:
        '''List of volume definitions for the Container App.'''
        result = self._values.get("volumes")
        return typing.cast(typing.Optional[typing.List["ContainerAppVolume"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppTemplate(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppVolume",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "storage_name": "storageName",
        "storage_type": "storageType",
    },
)
class ContainerAppVolume:
    def __init__(
        self,
        *,
        name: builtins.str,
        storage_name: typing.Optional[builtins.str] = None,
        storage_type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Volume definition for the Container App.

        :param name: Volume name.
        :param storage_name: Name of the storage resource (for AzureFile and NfsAzureFile).
        :param storage_type: Storage type: AzureFile, EmptyDir, NfsAzureFile, or Secret.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41e94f2ce6dd86ef1fb9e39989e2b4fb1696c7adfdd3bda10cad69d825b68cc6)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument storage_name", value=storage_name, expected_type=type_hints["storage_name"])
            check_type(argname="argument storage_type", value=storage_type, expected_type=type_hints["storage_type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }
        if storage_name is not None:
            self._values["storage_name"] = storage_name
        if storage_type is not None:
            self._values["storage_type"] = storage_type

    @builtins.property
    def name(self) -> builtins.str:
        '''Volume name.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def storage_name(self) -> typing.Optional[builtins.str]:
        '''Name of the storage resource (for AzureFile and NfsAzureFile).'''
        result = self._values.get("storage_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def storage_type(self) -> typing.Optional[builtins.str]:
        '''Storage type: AzureFile, EmptyDir, NfsAzureFile, or Secret.'''
        result = self._values.get("storage_type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppVolume(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@microsoft/terraform-cdk-constructs.azure_containerapps.ContainerAppVolumeMount",
    jsii_struct_bases=[],
    name_mapping={
        "mount_path": "mountPath",
        "volume_name": "volumeName",
        "sub_path": "subPath",
    },
)
class ContainerAppVolumeMount:
    def __init__(
        self,
        *,
        mount_path: builtins.str,
        volume_name: builtins.str,
        sub_path: typing.Optional[builtins.str] = None,
    ) -> None:
        '''Volume mount for a container.

        :param mount_path: Path within the container to mount the volume.
        :param volume_name: Name of the volume to mount (must match a volume name).
        :param sub_path: Path within the volume from which the container's volume should be mounted.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b5dcc603f89b98c359a40dd21cbed0f72de9f74e65f6b6c0d45918cb7481eeb)
            check_type(argname="argument mount_path", value=mount_path, expected_type=type_hints["mount_path"])
            check_type(argname="argument volume_name", value=volume_name, expected_type=type_hints["volume_name"])
            check_type(argname="argument sub_path", value=sub_path, expected_type=type_hints["sub_path"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "mount_path": mount_path,
            "volume_name": volume_name,
        }
        if sub_path is not None:
            self._values["sub_path"] = sub_path

    @builtins.property
    def mount_path(self) -> builtins.str:
        '''Path within the container to mount the volume.'''
        result = self._values.get("mount_path")
        assert result is not None, "Required property 'mount_path' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def volume_name(self) -> builtins.str:
        '''Name of the volume to mount (must match a volume name).'''
        result = self._values.get("volume_name")
        assert result is not None, "Required property 'volume_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def sub_path(self) -> typing.Optional[builtins.str]:
        '''Path within the volume from which the container's volume should be mounted.'''
        result = self._values.get("sub_path")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ContainerAppVolumeMount(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "ContainerApp",
    "ContainerAppAzureQueueScaleRule",
    "ContainerAppBody",
    "ContainerAppConfiguration",
    "ContainerAppContainer",
    "ContainerAppContainerResources",
    "ContainerAppCustomScaleRule",
    "ContainerAppDapr",
    "ContainerAppDaprHealthConfig",
    "ContainerAppEnvVar",
    "ContainerAppEnvironment",
    "ContainerAppEnvironmentAppLogsConfig",
    "ContainerAppEnvironmentBody",
    "ContainerAppEnvironmentCustomDomainConfig",
    "ContainerAppEnvironmentEncryptionConfig",
    "ContainerAppEnvironmentIngressConfig",
    "ContainerAppEnvironmentLogAnalyticsConfig",
    "ContainerAppEnvironmentMtlsConfig",
    "ContainerAppEnvironmentPeerAuthentication",
    "ContainerAppEnvironmentPeerTrafficConfig",
    "ContainerAppEnvironmentProps",
    "ContainerAppEnvironmentVnetConfig",
    "ContainerAppEnvironmentWorkloadProfile",
    "ContainerAppHttpScaleRule",
    "ContainerAppIdentity",
    "ContainerAppIdentitySetting",
    "ContainerAppIngress",
    "ContainerAppIngressAdditionalPortMapping",
    "ContainerAppIngressCorsPolicy",
    "ContainerAppIngressIpSecurityRestriction",
    "ContainerAppIngressStickySessions",
    "ContainerAppIngressTraffic",
    "ContainerAppJavaRuntimeConfig",
    "ContainerAppProbe",
    "ContainerAppProbeHttpGet",
    "ContainerAppProbeHttpHeader",
    "ContainerAppProbeTcpSocket",
    "ContainerAppProps",
    "ContainerAppRegistry",
    "ContainerAppRuntime",
    "ContainerAppScale",
    "ContainerAppScaleRule",
    "ContainerAppSecret",
    "ContainerAppService",
    "ContainerAppServiceBind",
    "ContainerAppTcpScaleRule",
    "ContainerAppTemplate",
    "ContainerAppVolume",
    "ContainerAppVolumeMount",
]

publication.publish()

def _typecheckingstub__0651acdf6079c9914eb1cab900c2e98140615d397b878ab1103e91a06e1639e0(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    environment_id: builtins.str,
    template: typing.Union[ContainerAppTemplate, typing.Dict[builtins.str, typing.Any]],
    configuration: typing.Optional[typing.Union[ContainerAppConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    identity: typing.Optional[typing.Union[ContainerAppIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_group_id: typing.Optional[builtins.str] = None,
    workload_profile_name: typing.Optional[builtins.str] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__09cfe1185a0e8a41dd366ecafae45bc671e75a3e10af3f47c6f5406c30c8810b(
    key: builtins.str,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8db58e55cf8fc4ad46dc58a7ad7361526a89ebd42dae0559689c024ecd19cedd(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eddb363d286309f85d99d6c908674b3f0219d00b8ecfa9a412cc086c242b3977(
    config: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8d1051db2e407c487766b9bb976daea374ee3da86f6bb1a00e7b1adb6ea8cc8(
    key: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0e05ce12887e895b3e225c010b7072f8223a2aff66c82ccdf9c24b0db46723a1(
    *,
    account_name: typing.Optional[builtins.str] = None,
    identity: typing.Optional[builtins.str] = None,
    queue_length: typing.Optional[jsii.Number] = None,
    queue_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57a15e4ed0b4da152b29bc4fda0d34f5af17e8c63de33e317aee99755458dcd8(
    *,
    location: builtins.str,
    identity: typing.Any = None,
    properties: typing.Any = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80a3aea48086146fff5f7f088a6cbe14c24e7f61937fc881e5d822e0e7d42ed3(
    *,
    active_revisions_mode: typing.Optional[builtins.str] = None,
    dapr: typing.Optional[typing.Union[ContainerAppDapr, typing.Dict[builtins.str, typing.Any]]] = None,
    identity_settings: typing.Optional[typing.Sequence[typing.Union[ContainerAppIdentitySetting, typing.Dict[builtins.str, typing.Any]]]] = None,
    ingress: typing.Optional[typing.Union[ContainerAppIngress, typing.Dict[builtins.str, typing.Any]]] = None,
    max_inactive_revisions: typing.Optional[jsii.Number] = None,
    registries: typing.Optional[typing.Sequence[typing.Union[ContainerAppRegistry, typing.Dict[builtins.str, typing.Any]]]] = None,
    runtime: typing.Optional[typing.Union[ContainerAppRuntime, typing.Dict[builtins.str, typing.Any]]] = None,
    secrets: typing.Optional[typing.Sequence[typing.Union[ContainerAppSecret, typing.Dict[builtins.str, typing.Any]]]] = None,
    service: typing.Optional[typing.Union[ContainerAppService, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dae8cd5fe6faef01c13848afbcba6df7b27546f0fa0e192e438a0b64f42e81e0(
    *,
    image: builtins.str,
    name: builtins.str,
    args: typing.Optional[typing.Sequence[builtins.str]] = None,
    command: typing.Optional[typing.Sequence[builtins.str]] = None,
    env: typing.Optional[typing.Sequence[typing.Union[ContainerAppEnvVar, typing.Dict[builtins.str, typing.Any]]]] = None,
    probes: typing.Optional[typing.Sequence[typing.Union[ContainerAppProbe, typing.Dict[builtins.str, typing.Any]]]] = None,
    resources: typing.Optional[typing.Union[ContainerAppContainerResources, typing.Dict[builtins.str, typing.Any]]] = None,
    volume_mounts: typing.Optional[typing.Sequence[typing.Union[ContainerAppVolumeMount, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca6a732c69983114f0e1c7f5f8c17b908e359789d4ddbd84c7aabb2e16d15a2f(
    *,
    cpu: typing.Optional[jsii.Number] = None,
    memory: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e72b06cb64f7db613c08d1b7af7480f6084f5d06ca33025beb3c9916060d66e5(
    *,
    type: builtins.str,
    identity: typing.Optional[builtins.str] = None,
    metadata: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4101ad841339d829cdd9d6acb457e8daa7c2e816c97fc643e668d8b741551d3e(
    *,
    app_health: typing.Optional[typing.Union[ContainerAppDaprHealthConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    app_id: typing.Optional[builtins.str] = None,
    app_port: typing.Optional[jsii.Number] = None,
    app_protocol: typing.Optional[builtins.str] = None,
    enable_api_logging: typing.Optional[builtins.bool] = None,
    enabled: typing.Optional[builtins.bool] = None,
    http_max_request_size: typing.Optional[jsii.Number] = None,
    http_read_buffer_size: typing.Optional[jsii.Number] = None,
    log_level: typing.Optional[builtins.str] = None,
    max_concurrency: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9d2bd337da80fc4713316e25fcc1986debb68f781eb654e464df8036165b7cf3(
    *,
    enabled: typing.Optional[builtins.bool] = None,
    path: typing.Optional[builtins.str] = None,
    probe_interval_seconds: typing.Optional[jsii.Number] = None,
    probe_timeout_milliseconds: typing.Optional[jsii.Number] = None,
    threshold: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__383eafd8dc6e93d1bcbd6cbcfbc81536469b52b27ccff40a0af683574bf3704d(
    *,
    name: builtins.str,
    secret_ref: typing.Optional[builtins.str] = None,
    value: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08aa04bf7bc241fa4f090c508581dc13c405e1c017a5f9065657658db8882593(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    app_logs_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentAppLogsConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    custom_domain_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentCustomDomainConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    dapr_ai_connection_string: typing.Optional[builtins.str] = None,
    dapr_ai_instrumentation_key: typing.Optional[builtins.str] = None,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    infrastructure_resource_group: typing.Optional[builtins.str] = None,
    ingress_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentIngressConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    peer_authentication: typing.Optional[typing.Union[ContainerAppEnvironmentPeerAuthentication, typing.Dict[builtins.str, typing.Any]]] = None,
    peer_traffic_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentPeerTrafficConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    public_network_access: typing.Optional[builtins.str] = None,
    resource_group_id: typing.Optional[builtins.str] = None,
    vnet_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentVnetConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    workload_profiles: typing.Optional[typing.Sequence[typing.Union[ContainerAppEnvironmentWorkloadProfile, typing.Dict[builtins.str, typing.Any]]]] = None,
    zone_redundant: typing.Optional[builtins.bool] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__715b6c5afbb7e8cc118dd306bed3ec0aa0f53f4ab0aa3aa8f94eb2dfde4260bf(
    key: builtins.str,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66f4388ba9a0e81a3242e10030d125672c6cf5a4785b1b4e89941a3e9d846e4b(
    props: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b8b4a87ad5ba442ff2d96aef3ee6c25acf7bb175a86696647be4849489a1d3b5(
    config: typing.Any,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__405652e06fb1aeb40510cb2c958f2479603225be419322d2dd628bc8495c6e6a(
    key: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a3e755b7d998e39d35d4312526bd109260ed1db4cc91f38b88558d75a24a435(
    *,
    destination: typing.Optional[builtins.str] = None,
    log_analytics_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentLogAnalyticsConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ba5230fad4f5cdcc6362556f0e2b81d4c000079cb433d01343dc08009cd18f6(
    *,
    location: builtins.str,
    properties: typing.Any = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55c1fe4908d7eb5bf923052e35e83c655d75048998353a29fb62ad02f4e3601e(
    *,
    certificate_password: typing.Optional[builtins.str] = None,
    certificate_value: typing.Optional[builtins.str] = None,
    dns_suffix: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__90edafbe3dadbf9f328bf72ce73d505c46d86ed4a63b5354b5ff0e42851dcb0f(
    *,
    enabled: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd7ba58de0b213dd1456857a22c28d6ad7bb212a7601fa9cdde6fb4185d679b6(
    *,
    header_count_limit: typing.Optional[jsii.Number] = None,
    request_idle_timeout: typing.Optional[jsii.Number] = None,
    termination_grace_period_seconds: typing.Optional[jsii.Number] = None,
    workload_profile_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4103865ef206fb8f6a839003e1cf04d2a7d4449c1854a51e11b49876af52298b(
    *,
    customer_id: builtins.str,
    shared_key: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35f159904a466f243d60677901d2925493ce38791f65baba5f3eebc99a3d135f(
    *,
    enabled: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a4c8f85c9bf5164c753c977501b332de8e60cce7aa0c01f46b8a960a6da432a(
    *,
    mtls: typing.Optional[typing.Union[ContainerAppEnvironmentMtlsConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__887130688b4f1b6f57022942bc1cf2bc92287634f8cf7f92e43e2c730e725ee5(
    *,
    encryption: typing.Optional[typing.Union[ContainerAppEnvironmentEncryptionConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__16e71ade4fd449cacaef25724975f0f627f6ea8714125fec70dce530cdb52ea0(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    app_logs_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentAppLogsConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    custom_domain_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentCustomDomainConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    dapr_ai_connection_string: typing.Optional[builtins.str] = None,
    dapr_ai_instrumentation_key: typing.Optional[builtins.str] = None,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    infrastructure_resource_group: typing.Optional[builtins.str] = None,
    ingress_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentIngressConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    peer_authentication: typing.Optional[typing.Union[ContainerAppEnvironmentPeerAuthentication, typing.Dict[builtins.str, typing.Any]]] = None,
    peer_traffic_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentPeerTrafficConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    public_network_access: typing.Optional[builtins.str] = None,
    resource_group_id: typing.Optional[builtins.str] = None,
    vnet_configuration: typing.Optional[typing.Union[ContainerAppEnvironmentVnetConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    workload_profiles: typing.Optional[typing.Sequence[typing.Union[ContainerAppEnvironmentWorkloadProfile, typing.Dict[builtins.str, typing.Any]]]] = None,
    zone_redundant: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__121dcc943f85f4f806bdfbab83e24f6020d5541d10370a8613ce88feba7695b0(
    *,
    infrastructure_subnet_id: typing.Optional[builtins.str] = None,
    internal: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b71438cdde49694bbc2e9b8a814777be95e77a038c2398d057fdd4afba8e7674(
    *,
    name: builtins.str,
    workload_profile_type: builtins.str,
    maximum_count: typing.Optional[jsii.Number] = None,
    minimum_count: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f5b88eb361156a85588ffd2b6f8ada3da5f1e364e4518886590b79a09d8be8d6(
    *,
    metadata: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f6435e272c8bb7d4166c2414b721c63a19653afcd40b6efcc7b287210278105(
    *,
    type: builtins.str,
    user_assigned_identities: typing.Optional[typing.Mapping[builtins.str, typing.Any]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a13588971b9d659ff53e7001f7c327534520238e9d274ffa72ef4cf0c6d71fa(
    *,
    identity: builtins.str,
    lifecycle: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__156776725704f25c0c5a687fc4624b45f5205cc2118f117177a7d1771b403600(
    *,
    additional_port_mappings: typing.Optional[typing.Sequence[typing.Union[ContainerAppIngressAdditionalPortMapping, typing.Dict[builtins.str, typing.Any]]]] = None,
    client_certificate_mode: typing.Optional[builtins.str] = None,
    cors_policy: typing.Optional[typing.Union[ContainerAppIngressCorsPolicy, typing.Dict[builtins.str, typing.Any]]] = None,
    custom_domains: typing.Optional[typing.Sequence[typing.Any]] = None,
    external: typing.Optional[builtins.bool] = None,
    ip_security_restrictions: typing.Optional[typing.Sequence[typing.Union[ContainerAppIngressIpSecurityRestriction, typing.Dict[builtins.str, typing.Any]]]] = None,
    sticky_sessions: typing.Optional[typing.Union[ContainerAppIngressStickySessions, typing.Dict[builtins.str, typing.Any]]] = None,
    target_port: typing.Optional[jsii.Number] = None,
    traffic: typing.Optional[typing.Sequence[typing.Union[ContainerAppIngressTraffic, typing.Dict[builtins.str, typing.Any]]]] = None,
    transport: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95d33f69ebdd89d294e52e2cf9c09340922019b110e78d2d0f6642dd7adeca5d(
    *,
    target_port: jsii.Number,
    exposed_port: typing.Optional[jsii.Number] = None,
    external: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9463d556a2a90206cdaf75c853133c2d618db6cf71ac0b0d47000435d9c3eedc(
    *,
    allow_credentials: typing.Optional[builtins.bool] = None,
    allowed_headers: typing.Optional[typing.Sequence[builtins.str]] = None,
    allowed_methods: typing.Optional[typing.Sequence[builtins.str]] = None,
    allowed_origins: typing.Optional[typing.Sequence[builtins.str]] = None,
    expose_headers: typing.Optional[typing.Sequence[builtins.str]] = None,
    max_age: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6211844a6098352fc4e04817b8b069267f935f7862528e924f964feaa7b5de33(
    *,
    action: builtins.str,
    ip_address_range: builtins.str,
    name: builtins.str,
    description: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81fe05939add05cafb1a14cfece2ae6383c8e72f09e08792f0286f7f349f3f16(
    *,
    affinity: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ec975e16035b1efb18fefb142880d2040fcad55ec4df1afbe7dddbe6e46832f(
    *,
    label: typing.Optional[builtins.str] = None,
    latest_revision: typing.Optional[builtins.bool] = None,
    revision_name: typing.Optional[builtins.str] = None,
    weight: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__022a572310ba6a9aa3526ef7c29e87eb22416f93adf72fdc860a8a79d3d1bc22(
    *,
    enable_metrics: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__815613d5f6a44319cc69d7e5c2e815e61ce7e5e66a90124c2f5c76f41137c631(
    *,
    failure_threshold: typing.Optional[jsii.Number] = None,
    http_get: typing.Optional[typing.Union[ContainerAppProbeHttpGet, typing.Dict[builtins.str, typing.Any]]] = None,
    initial_delay_seconds: typing.Optional[jsii.Number] = None,
    period_seconds: typing.Optional[jsii.Number] = None,
    success_threshold: typing.Optional[jsii.Number] = None,
    tcp_socket: typing.Optional[typing.Union[ContainerAppProbeTcpSocket, typing.Dict[builtins.str, typing.Any]]] = None,
    timeout_seconds: typing.Optional[jsii.Number] = None,
    type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54083032728a61f1fb7f0b8959156bdd261257a798189adf47ed52d0ef4b98e1(
    *,
    port: jsii.Number,
    http_headers: typing.Optional[typing.Sequence[typing.Union[ContainerAppProbeHttpHeader, typing.Dict[builtins.str, typing.Any]]]] = None,
    path: typing.Optional[builtins.str] = None,
    scheme: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__13cd67381702f9bf29fb3c39305e931a80087d39f3efd6f0d5afbd56b3683922(
    *,
    name: builtins.str,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__756cbe0b9d24cdea677583029f9d3e5f5a77b474d1050d38f0f0aaafd4321516(
    *,
    port: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56668be42531cffd6e33b71d24eaffe4106f7b3eb4e1bd6b76e0715052d25044(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    api_version: typing.Optional[builtins.str] = None,
    enable_migration_analysis: typing.Optional[builtins.bool] = None,
    enable_transformation: typing.Optional[builtins.bool] = None,
    enable_validation: typing.Optional[builtins.bool] = None,
    location: typing.Optional[builtins.str] = None,
    monitoring: typing.Optional[typing.Union[_MonitoringConfig_7c28df74, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[builtins.str] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    environment_id: builtins.str,
    template: typing.Union[ContainerAppTemplate, typing.Dict[builtins.str, typing.Any]],
    configuration: typing.Optional[typing.Union[ContainerAppConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    identity: typing.Optional[typing.Union[ContainerAppIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
    ignore_changes: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_group_id: typing.Optional[builtins.str] = None,
    workload_profile_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4dc682bd87546dd1560c6240165d1bd45ccbfa993b7d76b097dc3c27c4dc7187(
    *,
    server: builtins.str,
    identity: typing.Optional[builtins.str] = None,
    password_secret_ref: typing.Optional[builtins.str] = None,
    username: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4e4e45dc9b6bd79fe233fd2c893702f598e5da95ed6835f8563f06c167bdbdf8(
    *,
    java: typing.Optional[typing.Union[ContainerAppJavaRuntimeConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b9bd71884c3f965233e2fbb5563b22aca146361f6b9c521e86806f535473ad9(
    *,
    cooldown_period: typing.Optional[jsii.Number] = None,
    max_replicas: typing.Optional[jsii.Number] = None,
    min_replicas: typing.Optional[jsii.Number] = None,
    polling_interval: typing.Optional[jsii.Number] = None,
    rules: typing.Optional[typing.Sequence[typing.Union[ContainerAppScaleRule, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d536edaf2e13f635c63c8248b98ed31409be601e1d94fde96bfce31ace52604f(
    *,
    name: builtins.str,
    azure_queue: typing.Optional[typing.Union[ContainerAppAzureQueueScaleRule, typing.Dict[builtins.str, typing.Any]]] = None,
    custom: typing.Optional[typing.Union[ContainerAppCustomScaleRule, typing.Dict[builtins.str, typing.Any]]] = None,
    http: typing.Optional[typing.Union[ContainerAppHttpScaleRule, typing.Dict[builtins.str, typing.Any]]] = None,
    tcp: typing.Optional[typing.Union[ContainerAppTcpScaleRule, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c9bd8547859fdbde215e3258ffdef25cbd5f8a6b6cc5441c7663128c04c85826(
    *,
    name: builtins.str,
    identity: typing.Optional[builtins.str] = None,
    key_vault_url: typing.Optional[builtins.str] = None,
    value: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__68be900da3a6d735bb9e72efcf8ac84aa004f87ca4814b8860e6cf7ef5f25699(
    *,
    type: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb8e9460db2dca1fbd51f4bb909ec1d53fe390b1752eb91226292099329a31f2(
    *,
    name: builtins.str,
    service_id: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57e6d5886cedd64ecf0c53fd79c0841c8ecc4f6597b37a48ace494af0b07b4a6(
    *,
    metadata: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80332833d4c98a833cd74ae637bfb72b3f9b947c13bff3e3e954e2bf9e080255(
    *,
    containers: typing.Sequence[typing.Union[ContainerAppContainer, typing.Dict[builtins.str, typing.Any]]],
    init_containers: typing.Optional[typing.Sequence[typing.Union[ContainerAppContainer, typing.Dict[builtins.str, typing.Any]]]] = None,
    revision_suffix: typing.Optional[builtins.str] = None,
    scale: typing.Optional[typing.Union[ContainerAppScale, typing.Dict[builtins.str, typing.Any]]] = None,
    service_binds: typing.Optional[typing.Sequence[typing.Union[ContainerAppServiceBind, typing.Dict[builtins.str, typing.Any]]]] = None,
    termination_grace_period_seconds: typing.Optional[jsii.Number] = None,
    volumes: typing.Optional[typing.Sequence[typing.Union[ContainerAppVolume, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41e94f2ce6dd86ef1fb9e39989e2b4fb1696c7adfdd3bda10cad69d825b68cc6(
    *,
    name: builtins.str,
    storage_name: typing.Optional[builtins.str] = None,
    storage_type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b5dcc603f89b98c359a40dd21cbed0f72de9f74e65f6b6c0d45918cb7481eeb(
    *,
    mount_path: builtins.str,
    volume_name: builtins.str,
    sub_path: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass
