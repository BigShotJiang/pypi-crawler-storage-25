"""
Tests for `chives.text`.
"""

import pytest

from chives.text import coloured, smartify, TextColour


@pytest.mark.parametrize(
    "text, expected",
    [
        ("<", "<"),
        ("<0", "<0"),
        ("--", "–"),
        ("---", "—"),
        ("&quot;", "“"),
        ("'", "‘"),
        ("Isn't it delightful -- she said", "Isn’t it delightful – she said"),
        ("Are you ... sure?", "Are you … sure?"),
        ("<h2>Isn't it delightful?</h2>", "<h2>Isn’t it delightful?</h2>"),
        ("<li>Isn't it delightful?</li>", "<li>Isn’t it delightful?</li>"),
        ("<p>&quot;It's nice&quot;, he said</p>", "<p>“It’s nice”, he said</p>"),
        (
            "<!-- this -- is -- not -- a -- valid -- comment -->",
            "<!– this – is – not – a – valid – comment –>",
        ),
    ],
)
def test_smartify(text: str, expected: str) -> None:
    """
    Test smartify().
    """
    actual = smartify(text)
    assert actual == expected

    assert smartify(actual) == actual


@pytest.mark.parametrize(
    "text",
    [
        "<",
        "<0",
        '<a href="https://example.com">example.com</a>',
        '<pre>print("hello world")</pre>',
        '<pre><code data-lang="python">print("hello world")</code></pre>',
        "<br/>",
        "</br>",
        '<style>\n  @use "components/list_of_posts";\n</style>',
    ],
)
def test_is_unchanged_by_smartify(text: str) -> None:
    """
    Test these strings are unaffected by "smart" punctuation.
    """
    assert smartify(text) == text


@pytest.mark.parametrize(
    "text, colour, expected",
    [
        ("hello world", "red", "\033[91mhello world\033[0m"),
        ("hello world", "yellow", "\033[93mhello world\033[0m"),
        ("hello world", "green", "\033[92mhello world\033[0m"),
        ("hello world", "blue", "\033[94mhello world\033[0m"),
    ],
)
def test_coloured(text: str, colour: TextColour, expected: str) -> None:
    """
    Tests for `coloured`.
    """
    assert coloured(text, colour) == expected


def test_unrecognised_colour() -> None:
    """
    Calling `coloured` with an unrecognised colour is a ValueError.
    """
    with pytest.raises(ValueError, match="unrecognised colour"):
        coloured("hello world", colour="gray")  # type: ignore
