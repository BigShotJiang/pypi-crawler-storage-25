"""
Functions for dealing with text.
"""

from typing import Literal

from chives.smartypants import smartypants


__all__ = ["smartify", "coloured"]


def smartify(text: str) -> str:
    """
    Add curly quotes and smart dashes to a string.
    """
    return smartypants(text)


TextColour = Literal["red", "yellow", "green", "blue"]


def coloured(text: str, colour: TextColour) -> str:
    """
    Add ANSI escape codes to print text in a colour.
    """
    try:
        start_code = {
            "red": "\033[91m",
            "yellow": "\033[93m",
            "green": "\033[92m",
            "blue": "\033[94m",
        }[colour]
    except KeyError:
        raise ValueError(f"unrecognised colour: {colour!r}")

    end_code = "\033[0m"

    return start_code + text + end_code
