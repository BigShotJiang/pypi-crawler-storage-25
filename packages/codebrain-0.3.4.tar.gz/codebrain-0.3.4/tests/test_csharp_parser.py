"""Tests for the C# tree-sitter parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.csharp_parser import CSharpParser, _CSHARP_AVAILABLE

pytestmark = pytest.mark.skipif(not _CSHARP_AVAILABLE, reason="tree-sitter-languages not installed")


@pytest.fixture
def parser():
    return CSharpParser()


@pytest.fixture
def csharp_project(tmp_path: Path) -> Path:
    """Create a small C# project for testing."""
    src = tmp_path / "src"
    src.mkdir(parents=True)

    (src / "UserService.cs").write_text("""\
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyApp.Services
{
    /// <summary>
    /// Service for managing users.
    /// </summary>
    [Authorize]
    public class UserService : BaseService, IUserService
    {
        private readonly IUserRepository _repo;
        public static int MaxUsers = 100;

        public UserService(IUserRepository repo)
        {
            _repo = repo;
        }

        /// <summary>
        /// Gets all users from the repository.
        /// </summary>
        public List<User> GetAll()
        {
            return _repo.FindAll();
        }

        public User FindById(int id)
        {
            var user = _repo.Get(id);
            Validate(user);
            return user;
        }

        public async Task<User> FindByIdAsync(int id)
        {
            var user = await _repo.GetAsync(id);
            Validate(user);
            return user;
        }

        private void Validate(User user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }
        }

        public static User CreateDefault()
        {
            return new User();
        }

        public string Name { get; set; }
        public int Age { get; private set; }

        public enum Status
        {
            Active,
            Inactive,
            Suspended
        }

        public interface IValidator
        {
            bool Check(User user);
        }

        private class InnerHelper
        {
            public void Help()
            {
                Console.WriteLine("helping");
            }
        }
    }
}
""")

    (src / "BaseService.cs").write_text("""\
namespace MyApp.Services
{
    /// <summary>
    /// Abstract base service with common functionality.
    /// </summary>
    public abstract class BaseService
    {
        protected string ServiceName;

        public abstract void Init();

        protected void Log(string message)
        {
            Console.WriteLine(message);
        }
    }
}
""")

    (src / "IUserService.cs").write_text("""\
using System.Collections.Generic;

namespace MyApp.Services
{
    public interface IUserService : IDisposable
    {
        List<User> GetAll();
        User FindById(int id);
    }
}
""")

    (src / "UserController.cs").write_text("""\
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace MyApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _service;

        public UserController(IUserService service)
        {
            _service = service;
        }

        [HttpGet]
        public List<User> GetAll()
        {
            return _service.GetAll();
        }

        [HttpGet("{id}")]
        public User GetById(int id)
        {
            return _service.FindById(id);
        }

        [HttpPost]
        public User Create(User user)
        {
            return _service.Save(user);
        }
    }
}
""")

    (src / "Models.cs").write_text("""\
using System;
using System.Collections.Generic;

namespace MyApp.Models
{
    /// <summary>
    /// Represents a user in the system.
    /// </summary>
    [Serializable]
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public List<Order> Orders { get; set; }
    }

    public struct Point
    {
        public double X;
        public double Y;

        public double Distance(Point other)
        {
            return Math.Sqrt(0);
        }
    }

    public delegate void NotifyHandler(string message);

    public event EventHandler Changed;
}
""")

    return tmp_path


class TestBasicParsing:
    """Test basic C# symbol extraction."""

    def test_parses_cs_file(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        assert result.path.endswith("UserService.cs")
        assert result.line_count > 0

    def test_finds_class(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        classes = [n for n in result.nodes if n.type == "class" and n.name == "UserService"]
        assert len(classes) == 1
        assert classes[0].is_exported is True

    def test_finds_struct(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/Models.cs"
        result = parser.parse(path, csharp_project)
        structs = [n for n in result.nodes if n.type == "class" and "struct" in n.decorators]
        assert any(n.name == "Point" for n in structs)

    def test_finds_interface(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/IUserService.cs"
        result = parser.parse(path, csharp_project)
        ifaces = [n for n in result.nodes if "interface" in n.decorators]
        assert any(n.name == "IUserService" for n in ifaces)

    def test_finds_enum(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        enums = [n for n in result.nodes if "enum" in n.decorators]
        assert any(n.name == "Status" for n in enums)
        # Check enum members
        members = [n for n in result.nodes if n.type == "variable"
                   and n.qualified_name.startswith("Status.")]
        names = {m.name for m in members}
        assert "Active" in names
        assert "Inactive" in names
        assert "Suspended" in names

    def test_finds_methods(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        methods = [n for n in result.nodes if n.type == "method"]
        method_names = {m.name for m in methods}
        assert "GetAll" in method_names
        assert "FindById" in method_names
        assert "Validate" in method_names

    def test_finds_property(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        props = [n for n in result.nodes if n.type == "variable" and n.name == "Name"
                 and n.qualified_name == "UserService.Name"]
        assert len(props) == 1
        assert "get" in props[0].signature
        assert "set" in props[0].signature

    def test_finds_field(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        fields = [n for n in result.nodes if n.type == "variable" and n.name == "_repo"]
        assert len(fields) == 1

    def test_finds_namespace(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        file_node = [n for n in result.nodes if n.type == "file"]
        assert len(file_node) == 1
        assert "MyApp.Services" in file_node[0].docstring


class TestRelationships:
    """Test edge extraction (CALLS, IMPORTS, EXTENDS, IMPLEMENTS, CONTAINS)."""

    def test_using_imports(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        targets = {e.target for e in imports}
        assert "System" in targets
        assert "System.Collections.Generic" in targets
        assert "System.Threading.Tasks" in targets

    def test_method_calls(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert "Validate" in targets or any("Validate" in t for t in targets)

    def test_extends(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        extends = [e for e in result.edges if e.type == "EXTENDS"]
        targets = {e.target for e in extends}
        assert "BaseService" in targets

    def test_implements(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        impls = [e for e in result.edges if e.type == "IMPLEMENTS"]
        targets = {e.target for e in impls}
        assert "IUserService" in targets

    def test_contains_edges(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        contains = [e for e in result.edges if e.type == "CONTAINS"]
        assert len(contains) > 5  # file->class, class->methods, class->fields

    def test_constructor_calls(self, parser: CSharpParser, csharp_project: Path):
        """new ClassName() should generate a CALLS edge."""
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        # CreateDefault does: new User()
        assert "User" in targets

    def test_interface_extends(self, parser: CSharpParser, csharp_project: Path):
        """Interface extending another interface should produce EXTENDS edge."""
        path = csharp_project / "src/IUserService.cs"
        result = parser.parse(path, csharp_project)
        extends = [e for e in result.edges if e.type == "EXTENDS"]
        targets = {e.target for e in extends}
        assert "IDisposable" in targets


class TestMetadata:
    """Test signatures, XML docs, modifiers."""

    def test_public_methods_exported(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        get_all = [n for n in result.nodes if n.name == "GetAll" and n.type == "method"]
        validate = [n for n in result.nodes if n.name == "Validate" and n.type == "method"]
        assert get_all[0].is_exported is True
        assert validate[0].is_exported is False

    def test_xml_doc_comment(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        cls = [n for n in result.nodes if n.name == "UserService" and n.type == "class"]
        assert len(cls) == 1
        assert "managing users" in cls[0].docstring.lower()

    def test_attributes(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/Models.cs"
        result = parser.parse(path, csharp_project)
        user = [n for n in result.nodes if n.name == "User" and n.type == "class"]
        assert len(user) == 1
        attr_names = []
        for a in user[0].decorators:
            paren = a.find("(")
            attr_names.append(a[:paren] if paren != -1 else a)
        assert "Serializable" in attr_names

    def test_async_method(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        async_method = [n for n in result.nodes if n.name == "FindByIdAsync"]
        assert len(async_method) == 1
        assert "async" in async_method[0].signature

    def test_static_method(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        static_method = [n for n in result.nodes if n.name == "CreateDefault"]
        assert len(static_method) == 1
        assert "static" in static_method[0].signature

    def test_method_signature_params(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        find_by_id = [n for n in result.nodes if n.name == "FindById" and n.type == "method"]
        assert len(find_by_id) == 1
        assert "int id" in find_by_id[0].signature

    def test_qualified_names(self, parser: CSharpParser, csharp_project: Path):
        path = csharp_project / "src/UserService.cs"
        result = parser.parse(path, csharp_project)
        get_all = [n for n in result.nodes if n.name == "GetAll" and n.type == "method"]
        assert get_all[0].qualified_name == "UserService.GetAll"

    def test_extensions(self, parser: CSharpParser):
        assert ".cs" in parser.extensions()


class TestIndexIntegration:
    """Test that C# files work with the full indexing pipeline."""

    def test_index_csharp_project(self, csharp_project: Path):
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index

        result = full_index(csharp_project)
        assert result["errors"] == []
        assert result["files_parsed"] == 5

        db = csharp_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            stats = store.get_stats()
            assert stats["nodes"] > 10
            assert stats["edges"] > 10
            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            results = engine.search_nodes("UserService")
            assert any(r["name"] == "UserService" for r in results)

    def test_impact_analysis_csharp(self, csharp_project: Path):
        """Impact analysis should work on C# symbols."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.graph.query import QueryEngine
        from codebrain.indexer import full_index

        full_index(csharp_project)
        db = csharp_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)
            results = engine.search_nodes("BaseService")
            assert len(results) > 0

    def test_kt_document_csharp(self, csharp_project: Path):
        """KT document generation should work on C# codebases."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index
        from codebrain.kt import KTGenerator

        full_index(csharp_project)
        db = csharp_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            gen = KTGenerator(store)
            doc = gen.generate(project_name="CSharpTestProject")
            assert "# CSharpTestProject" in doc
            assert "## Architecture Overview" in doc
            assert "```mermaid" in doc
