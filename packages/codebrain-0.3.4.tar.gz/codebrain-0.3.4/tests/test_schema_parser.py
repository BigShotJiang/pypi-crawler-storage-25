"""Tests for schema_parser.py — SQL and Prisma parsing."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

from codebrain.parser.schema_parser import SchemaParser


@pytest.fixture
def parser():
    return SchemaParser()


@pytest.fixture
def tmp_repo(tmp_path):
    return tmp_path


def _write(repo: Path, name: str, content: str) -> Path:
    p = repo / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return p


# =========================================================================
# SQL Parsing
# =========================================================================

class TestSQLParsing:
    """SQL CREATE TABLE parsing."""

    def test_create_table_extracts_table_name(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.sql", """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY,
                name VARCHAR(255)
            );
        """)
        result = parser.parse(p, tmp_repo)
        table_nodes = [n for n in result.nodes if "sql_table" in n.decorators]
        assert len(table_nodes) == 1
        assert table_nodes[0].name == "users"

    def test_column_names_and_types(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.sql", """
            CREATE TABLE products (
                id INTEGER PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                price DECIMAL(10,2)
            );
        """)
        result = parser.parse(p, tmp_repo)
        col_nodes = [n for n in result.nodes if "sql_column" in n.decorators]
        names = {n.name for n in col_nodes}
        assert "id" in names
        assert "name" in names
        assert "price" in names

    def test_not_null_primary_key_constraints(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.sql", """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY,
                email VARCHAR(255) NOT NULL UNIQUE
            );
        """)
        result = parser.parse(p, tmp_repo)
        col_nodes = {n.name: n for n in result.nodes if "sql_column" in n.decorators}
        assert "PRIMARY KEY" in col_nodes["id"].signature
        assert "NOT NULL" in col_nodes["email"].signature

    def test_foreign_key_creates_references_edge(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.sql", """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY
            );
            CREATE TABLE orders (
                id INTEGER PRIMARY KEY,
                user_id INTEGER,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
        """)
        result = parser.parse(p, tmp_repo)
        ref_edges = [e for e in result.edges if e.type == "REFERENCES"]
        assert len(ref_edges) >= 1
        assert any("user_id" in e.source and "users" in e.target for e in ref_edges)

    def test_create_table_if_not_exists(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.sql", """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY
            );
        """)
        result = parser.parse(p, tmp_repo)
        table_nodes = [n for n in result.nodes if "sql_table" in n.decorators]
        assert len(table_nodes) == 1
        assert table_nodes[0].name == "users"

    def test_multiple_tables(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.sql", """
            CREATE TABLE users (id INTEGER PRIMARY KEY);
            CREATE TABLE orders (id INTEGER PRIMARY KEY, total DECIMAL);
            CREATE TABLE items (id INTEGER PRIMARY KEY, name TEXT);
        """)
        result = parser.parse(p, tmp_repo)
        table_nodes = [n for n in result.nodes if "sql_table" in n.decorators]
        assert len(table_nodes) == 3

    def test_create_index_in_summary(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.sql", """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY,
                email VARCHAR(255)
            );
            CREATE INDEX idx_users_email ON users(email);
        """)
        result = parser.parse(p, tmp_repo)
        table_nodes = [n for n in result.nodes if "sql_table" in n.decorators]
        assert any("idx" in (n.summary or "") for n in table_nodes)

    def test_non_create_table_silently_skipped(self, parser, tmp_repo):
        p = _write(tmp_repo, "migrate.sql", """
            INSERT INTO users (name) VALUES ('test');
            ALTER TABLE users ADD COLUMN age INTEGER;
            DROP TABLE IF EXISTS temp;
            CREATE TABLE actual (id INTEGER PRIMARY KEY);
        """)
        result = parser.parse(p, tmp_repo)
        table_nodes = [n for n in result.nodes if "sql_table" in n.decorators]
        assert len(table_nodes) == 1
        assert table_nodes[0].name == "actual"

    def test_sql_integration_index(self, parser, tmp_repo):
        """Integration: index a project with .sql file, verify graph nodes/edges."""
        p = _write(tmp_repo, "db/schema.sql", """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY,
                email VARCHAR(255) NOT NULL
            );
            CREATE TABLE orders (
                id INTEGER PRIMARY KEY,
                user_id INTEGER,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
        """)
        result = parser.parse(p, tmp_repo)
        # File node
        assert any(n.type == "file" for n in result.nodes)
        # Tables
        table_nodes = [n for n in result.nodes if "sql_table" in n.decorators]
        assert len(table_nodes) == 2
        # Columns
        col_nodes = [n for n in result.nodes if "sql_column" in n.decorators]
        assert len(col_nodes) >= 4
        # FK edge
        ref_edges = [e for e in result.edges if e.type == "REFERENCES"]
        assert len(ref_edges) >= 1


# =========================================================================
# Prisma Parsing
# =========================================================================

class TestPrismaParsing:
    """Prisma schema parsing."""

    def test_model_creates_class_node(self, parser, tmp_repo):
        p = _write(tmp_repo, "prisma/schema.prisma", """
            model User {
                id    String @id @default(uuid())
                email String @unique
                name  String
            }
        """)
        result = parser.parse(p, tmp_repo)
        model_nodes = [n for n in result.nodes if "prisma_model" in n.decorators]
        assert len(model_nodes) == 1
        assert model_nodes[0].name == "User"

    def test_fields_with_array_type(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.prisma", """
            model User {
                id    String  @id
                posts Post[]
            }
        """)
        result = parser.parse(p, tmp_repo)
        field_nodes = [n for n in result.nodes if "prisma_field" in n.decorators]
        names = {n.name for n in field_nodes}
        assert "id" in names
        assert "posts" in names
        # Check array type in signature
        posts_node = [n for n in field_nodes if n.name == "posts"][0]
        assert "Post[]" in posts_node.signature

    def test_explicit_relation_creates_references_edge(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.prisma", """
            model Post {
                id       String @id
                authorId String
                author   User   @relation(fields: [authorId], references: [id])
            }
            model User {
                id    String @id
                posts Post[]
            }
        """)
        result = parser.parse(p, tmp_repo)
        ref_edges = [e for e in result.edges if e.type == "REFERENCES"]
        assert len(ref_edges) >= 1
        assert any("authorId" in e.source and "User" in e.target for e in ref_edges)

    def test_implicit_relation_no_references_edge(self, parser, tmp_repo):
        """V1 limitation: implicit relations (Post[] without @relation) get no REFERENCES edge."""
        p = _write(tmp_repo, "schema.prisma", """
            model User {
                id    String @id
                posts Post[]
            }
        """)
        result = parser.parse(p, tmp_repo)
        ref_edges = [e for e in result.edges if e.type == "REFERENCES"]
        assert len(ref_edges) == 0

    def test_enum_node(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.prisma", """
            enum Role {
                ADMIN
                USER
                MODERATOR
            }
        """)
        result = parser.parse(p, tmp_repo)
        enum_nodes = [n for n in result.nodes if "prisma_enum" in n.decorators]
        assert len(enum_nodes) == 1
        assert enum_nodes[0].name == "Role"
        assert "ADMIN" in enum_nodes[0].summary
        assert "USER" in enum_nodes[0].summary

    def test_map_table_name(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.prisma", """
            model User {
                id String @id

                @@map("app_users")
            }
        """)
        result = parser.parse(p, tmp_repo)
        model_nodes = [n for n in result.nodes if "prisma_model" in n.decorators]
        assert any("app_users" in (n.summary or "") for n in model_nodes)

    def test_prisma_integration(self, parser, tmp_repo):
        """Integration: full prisma file with models, enums, relations."""
        p = _write(tmp_repo, "schema.prisma", """
            model User {
                id    String  @id @default(uuid())
                email String  @unique
                posts Post[]
            }

            model Post {
                id       String @id @default(uuid())
                title    String
                authorId String
                author   User   @relation(fields: [authorId], references: [id])
            }

            enum Status {
                DRAFT
                PUBLISHED
            }
        """)
        result = parser.parse(p, tmp_repo)
        assert any("prisma_model" in n.decorators for n in result.nodes)
        assert any("prisma_enum" in n.decorators for n in result.nodes)
        assert any(e.type == "REFERENCES" for e in result.edges)
        assert len([n for n in result.nodes if "prisma_field" in n.decorators]) >= 5


# =========================================================================
# Edge Cases
# =========================================================================

class TestSchemaEdgeCases:
    """Edge cases for schema parsing."""

    def test_empty_sql_file(self, parser, tmp_repo):
        p = _write(tmp_repo, "empty.sql", "")
        result = parser.parse(p, tmp_repo)
        assert len([n for n in result.nodes if "sql_table" in n.decorators]) == 0

    def test_sql_comments_ignored(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.sql", """
            -- This is a comment
            /* Block comment
               spanning multiple lines */
            CREATE TABLE users (
                id INTEGER PRIMARY KEY
            );
        """)
        result = parser.parse(p, tmp_repo)
        table_nodes = [n for n in result.nodes if "sql_table" in n.decorators]
        assert len(table_nodes) == 1

    def test_prisma_comments_ignored(self, parser, tmp_repo):
        p = _write(tmp_repo, "schema.prisma", """
            // This is a comment
            /// This is a doc comment
            model User {
                id String @id
            }
        """)
        result = parser.parse(p, tmp_repo)
        model_nodes = [n for n in result.nodes if "prisma_model" in n.decorators]
        assert len(model_nodes) == 1

    def test_mixed_sql_py_project(self, parser, tmp_repo):
        """Both .sql and .py files can coexist."""
        p = _write(tmp_repo, "schema.sql", """
            CREATE TABLE users (id INTEGER PRIMARY KEY);
        """)
        result = parser.parse(p, tmp_repo)
        assert len([n for n in result.nodes if "sql_table" in n.decorators]) == 1
