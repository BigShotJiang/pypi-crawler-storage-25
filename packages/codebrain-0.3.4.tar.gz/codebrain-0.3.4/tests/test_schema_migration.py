"""Tests for codebrain.schema_migration — ORM schema extraction, diff, and migration generation."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.schema_migration import (
    Column,
    DatabaseSchema,
    Relationship,
    SchemaDiff,
    SchemaMigrator,
    Table,
    _normalize_type,
    _parse_column_entry,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SQLALCHEMY_CODE = '''\
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(255))
    is_active = Column(Boolean, default=True)

    posts = relationship("Post")


class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
'''

SQLALCHEMY_V2_CODE = '''\
from sqlalchemy import Column, Integer, String, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(255))
    is_active = Column(Boolean, default=True)
    bio = Column(Text)

    posts = relationship("Post")


class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    body = Column(Text)
    user_id = Column(Integer, ForeignKey("users.id"))


class Comment(Base):
    __tablename__ = "comments"

    id = Column(Integer, primary_key=True)
    text = Column(Text, nullable=False)
    post_id = Column(Integer, ForeignKey("posts.id"))
'''


def _index_project(tmp_path: Path, code: str, filename: str = "models.py") -> Path:
    """Write code to a temp project and index it. Return db path."""
    src = tmp_path / filename
    src.write_text(code, encoding="utf-8")
    db = tmp_path / ".codebrain" / "graph.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    from codebrain.indexer import full_index
    full_index(tmp_path, db)
    return db


# ---------------------------------------------------------------------------
# Unit tests: _normalize_type
# ---------------------------------------------------------------------------

class TestNormalizeType:
    def test_string_with_length(self):
        assert _normalize_type("String(255)") == "VARCHAR(255)"

    def test_integer(self):
        assert _normalize_type("Integer") == "INTEGER"

    def test_boolean(self):
        assert _normalize_type("Boolean") == "BOOLEAN"

    def test_char_field(self):
        assert _normalize_type("CharField(100)") == "VARCHAR(100)"

    def test_datetime(self):
        assert _normalize_type("DateTime") == "TIMESTAMP"

    def test_text(self):
        assert _normalize_type("Text") == "TEXT"

    def test_unknown_type(self):
        assert _normalize_type("CustomType") == "CUSTOMTYPE"

    def test_empty(self):
        assert _normalize_type("") == ""

    def test_biginteger(self):
        assert _normalize_type("BigInteger") == "BIGINT"

    def test_django_auto_field(self):
        assert _normalize_type("AutoField") == "SERIAL"


# ---------------------------------------------------------------------------
# Unit tests: _parse_column_entry
# ---------------------------------------------------------------------------

class TestParseColumnEntry:
    def test_basic(self):
        col = _parse_column_entry("name/String(100)/notnull")
        assert col.name == "name"
        assert col.type == "String(100)"
        assert col.nullable is False
        assert col.primary_key is False

    def test_primary_key(self):
        col = _parse_column_entry("id/Integer/pk")
        assert col.name == "id"
        assert col.type == "Integer"
        assert col.primary_key is True

    def test_default(self):
        col = _parse_column_entry("is_active/Boolean/default=True")
        assert col.default == "True"

    def test_no_flags(self):
        col = _parse_column_entry("email/String(255)/")
        assert col.nullable is True
        assert col.primary_key is False
        assert col.foreign_key is False

    def test_multiple_flags(self):
        col = _parse_column_entry("user_id/Integer/notnull,fk")
        assert col.nullable is False
        assert col.foreign_key is True

    def test_fk_flag(self):
        col = _parse_column_entry("ref/Integer/fk")
        assert col.foreign_key is True


# ---------------------------------------------------------------------------
# Integration tests: detect_orm
# ---------------------------------------------------------------------------

class TestDetectOrm:
    def test_detect_sqlalchemy(self, tmp_path):
        db = _index_project(tmp_path, SQLALCHEMY_CODE)
        from codebrain.graph.store import GraphStore
        with GraphStore(str(db)) as store:
            migrator = SchemaMigrator(store)
            assert migrator.detect_orm() == "sqlalchemy"

    def test_detect_unknown_no_orm(self, tmp_path):
        code = "class Foo:\n    pass\n"
        db = _index_project(tmp_path, code)
        from codebrain.graph.store import GraphStore
        with GraphStore(str(db)) as store:
            migrator = SchemaMigrator(store)
            assert migrator.detect_orm() == "unknown"


# ---------------------------------------------------------------------------
# Integration tests: extract_schema
# ---------------------------------------------------------------------------

class TestExtractSchema:
    def test_extracts_tables(self, tmp_path):
        db = _index_project(tmp_path, SQLALCHEMY_CODE)
        from codebrain.graph.store import GraphStore
        with GraphStore(str(db)) as store:
            migrator = SchemaMigrator(store)
            schema = migrator.extract_schema()
            assert schema.orm_type == "sqlalchemy"
            table_names = {t.name for t in schema.tables}
            assert "users" in table_names
            assert "posts" in table_names

    def test_extracts_columns(self, tmp_path):
        db = _index_project(tmp_path, SQLALCHEMY_CODE)
        from codebrain.graph.store import GraphStore
        with GraphStore(str(db)) as store:
            migrator = SchemaMigrator(store)
            schema = migrator.extract_schema()
            users_table = schema.get_table("users")
            assert users_table is not None
            col_names = {c.name for c in users_table.columns}
            assert "id" in col_names
            assert "name" in col_names
            assert "email" in col_names
            assert "is_active" in col_names

    def test_column_attributes(self, tmp_path):
        db = _index_project(tmp_path, SQLALCHEMY_CODE)
        from codebrain.graph.store import GraphStore
        with GraphStore(str(db)) as store:
            migrator = SchemaMigrator(store)
            schema = migrator.extract_schema()
            users_table = schema.get_table("users")
            assert users_table is not None
            cols = {c.name: c for c in users_table.columns}
            assert cols["id"].primary_key is True
            assert cols["name"].nullable is False
            assert cols["email"].nullable is True

    def test_extracts_relationships(self, tmp_path):
        db = _index_project(tmp_path, SQLALCHEMY_CODE)
        from codebrain.graph.store import GraphStore
        with GraphStore(str(db)) as store:
            migrator = SchemaMigrator(store)
            schema = migrator.extract_schema()
            posts_table = schema.get_table("posts")
            assert posts_table is not None
            rel_targets = {r.target_table for r in posts_table.relationships}
            assert "users" in rel_targets

    def test_to_dict(self, tmp_path):
        db = _index_project(tmp_path, SQLALCHEMY_CODE)
        from codebrain.graph.store import GraphStore
        with GraphStore(str(db)) as store:
            migrator = SchemaMigrator(store)
            schema = migrator.extract_schema()
            d = migrator.to_dict(schema)
            assert d["orm_type"] == "sqlalchemy"
            assert len(d["tables"]) >= 2


# ---------------------------------------------------------------------------
# Unit tests: diff
# ---------------------------------------------------------------------------

class TestDiff:
    def _make_schema(self, tables):
        return DatabaseSchema(orm_type="sqlalchemy", tables=tables)

    def test_added_table(self):
        old = self._make_schema([])
        new_table = Table(name="users", class_name="User", file_path="m.py",
                          columns=[Column(name="id", type="Integer", primary_key=True)])
        new = self._make_schema([new_table])
        migrator = SchemaMigrator.__new__(SchemaMigrator)
        diff = migrator.diff(old, new)
        assert len(diff.added_tables) == 1
        assert diff.added_tables[0].name == "users"
        assert len(diff.removed_tables) == 0

    def test_removed_table(self):
        old_table = Table(name="users", class_name="User", file_path="m.py")
        old = self._make_schema([old_table])
        new = self._make_schema([])
        migrator = SchemaMigrator.__new__(SchemaMigrator)
        diff = migrator.diff(old, new)
        assert len(diff.removed_tables) == 1

    def test_added_column(self):
        old_table = Table(name="users", class_name="User", file_path="m.py",
                          columns=[Column(name="id", type="Integer")])
        new_table = Table(name="users", class_name="User", file_path="m.py",
                          columns=[Column(name="id", type="Integer"),
                                   Column(name="bio", type="Text")])
        old = self._make_schema([old_table])
        new = self._make_schema([new_table])
        migrator = SchemaMigrator.__new__(SchemaMigrator)
        diff = migrator.diff(old, new)
        assert "users" in diff.added_columns
        assert diff.added_columns["users"][0].name == "bio"

    def test_removed_column(self):
        old_table = Table(name="users", class_name="User", file_path="m.py",
                          columns=[Column(name="id", type="Integer"),
                                   Column(name="old_field", type="Text")])
        new_table = Table(name="users", class_name="User", file_path="m.py",
                          columns=[Column(name="id", type="Integer")])
        old = self._make_schema([old_table])
        new = self._make_schema([new_table])
        migrator = SchemaMigrator.__new__(SchemaMigrator)
        diff = migrator.diff(old, new)
        assert "users" in diff.removed_columns

    def test_type_change(self):
        old_table = Table(name="users", class_name="User", file_path="m.py",
                          columns=[Column(name="name", type="String(100)")])
        new_table = Table(name="users", class_name="User", file_path="m.py",
                          columns=[Column(name="name", type="Text")])
        old = self._make_schema([old_table])
        new = self._make_schema([new_table])
        migrator = SchemaMigrator.__new__(SchemaMigrator)
        diff = migrator.diff(old, new)
        assert len(diff.type_changes) == 1
        assert diff.type_changes[0]["column"] == "name"
        assert diff.type_changes[0]["old_type"] == "String(100)"
        assert diff.type_changes[0]["new_type"] == "Text"

    def test_no_changes(self):
        table = Table(name="users", class_name="User", file_path="m.py",
                      columns=[Column(name="id", type="Integer")])
        old = self._make_schema([table])
        new = self._make_schema([Table(name="users", class_name="User", file_path="m.py",
                                       columns=[Column(name="id", type="Integer")])])
        migrator = SchemaMigrator.__new__(SchemaMigrator)
        diff = migrator.diff(old, new)
        assert not diff.has_changes

    def test_relationship_added(self):
        old_table = Table(name="posts", class_name="Post", file_path="m.py")
        new_table = Table(name="posts", class_name="Post", file_path="m.py",
                          relationships=[Relationship(source_table="posts", target_table="users")])
        old = self._make_schema([old_table])
        new = self._make_schema([new_table])
        migrator = SchemaMigrator.__new__(SchemaMigrator)
        diff = migrator.diff(old, new)
        assert len(diff.added_relationships) == 1


# ---------------------------------------------------------------------------
# Unit tests: generate_sql
# ---------------------------------------------------------------------------

class TestGenerateSQL:
    def _make_migrator(self):
        return SchemaMigrator.__new__(SchemaMigrator)

    def test_create_table(self):
        diff = SchemaDiff(
            added_tables=[
                Table(name="users", class_name="User", file_path="m.py",
                      columns=[
                          Column(name="id", type="Integer", primary_key=True),
                          Column(name="name", type="String(100)", nullable=False),
                      ])
            ]
        )
        sql = self._make_migrator().generate_sql(diff)
        assert "CREATE TABLE users" in sql
        assert "id INTEGER PRIMARY KEY" in sql
        assert "name VARCHAR(100) NOT NULL" in sql

    def test_drop_table(self):
        diff = SchemaDiff(
            removed_tables=[Table(name="old_table", class_name="Old", file_path="m.py")]
        )
        sql = self._make_migrator().generate_sql(diff)
        assert "DROP TABLE IF EXISTS old_table" in sql

    def test_add_column(self):
        diff = SchemaDiff(
            added_columns={"users": [Column(name="bio", type="Text")]}
        )
        sql = self._make_migrator().generate_sql(diff)
        assert "ALTER TABLE users ADD COLUMN bio TEXT" in sql

    def test_drop_column(self):
        diff = SchemaDiff(
            removed_columns={"users": [Column(name="old_col", type="Integer")]}
        )
        sql = self._make_migrator().generate_sql(diff)
        assert "ALTER TABLE users DROP COLUMN old_col" in sql

    def test_type_change_comment(self):
        diff = SchemaDiff(
            type_changes=[{
                "table": "users", "column": "name",
                "old_type": "String(100)", "new_type": "Text",
                "old_normalized": "VARCHAR(100)", "new_normalized": "TEXT",
            }]
        )
        sql = self._make_migrator().generate_sql(diff)
        assert "TYPE CHANGE" in sql
        assert "manual review" in sql


# ---------------------------------------------------------------------------
# Unit tests: generate_alembic
# ---------------------------------------------------------------------------

class TestGenerateAlembic:
    def _make_migrator(self):
        return SchemaMigrator.__new__(SchemaMigrator)

    def test_create_table(self):
        diff = SchemaDiff(
            added_tables=[
                Table(name="users", class_name="User", file_path="m.py",
                      columns=[Column(name="id", type="Integer", primary_key=True)])
            ]
        )
        code = self._make_migrator().generate_alembic(diff)
        assert "def upgrade()" in code
        assert "def downgrade()" in code
        assert "op.create_table" in code
        assert "'users'" in code

    def test_add_column(self):
        diff = SchemaDiff(
            added_columns={"users": [Column(name="bio", type="Text")]}
        )
        code = self._make_migrator().generate_alembic(diff)
        assert "op.add_column" in code
        assert "'bio'" in code

    def test_drop_column(self):
        diff = SchemaDiff(
            removed_columns={"users": [Column(name="old_col", type="Integer")]}
        )
        code = self._make_migrator().generate_alembic(diff)
        assert "op.drop_column" in code
        assert "'old_col'" in code


# ---------------------------------------------------------------------------
# Unit tests: generate_flyway
# ---------------------------------------------------------------------------

class TestGenerateFlyway:
    def test_flyway_header(self):
        diff = SchemaDiff(
            added_tables=[
                Table(name="users", class_name="User", file_path="m.py",
                      columns=[Column(name="id", type="Integer", primary_key=True)])
            ]
        )
        migrator = SchemaMigrator.__new__(SchemaMigrator)
        sql = migrator.generate_flyway(diff)
        assert "V1__" in sql
        assert "Flyway" in sql
        assert "CREATE TABLE users" in sql


# ---------------------------------------------------------------------------
# End-to-end: full pipeline with two projects
# ---------------------------------------------------------------------------

class TestEndToEnd:
    def test_full_pipeline(self, tmp_path):
        """Index two versions of ORM code, diff, and generate migration."""
        old_dir = tmp_path / "old_project"
        new_dir = tmp_path / "new_project"
        old_dir.mkdir()
        new_dir.mkdir()

        old_db = _index_project(old_dir, SQLALCHEMY_CODE)
        new_db = _index_project(new_dir, SQLALCHEMY_V2_CODE)

        from codebrain.graph.store import GraphStore
        with GraphStore(str(old_db)) as old_store:
            with GraphStore(str(new_db)) as new_store:
                old_migrator = SchemaMigrator(old_store)
                new_migrator = SchemaMigrator(new_store)

                old_schema = old_migrator.extract_schema()
                new_schema = new_migrator.extract_schema()

                diff = old_migrator.diff(old_schema, new_schema)

                # comments table added
                added_names = {t.name for t in diff.added_tables}
                assert "comments" in added_names

                # bio column added to users
                assert "users" in diff.added_columns
                bio_cols = [c for c in diff.added_columns["users"] if c.name == "bio"]
                assert len(bio_cols) == 1

                # body column added to posts
                assert "posts" in diff.added_columns
                body_cols = [c for c in diff.added_columns["posts"] if c.name == "body"]
                assert len(body_cols) == 1

                # Generate all formats
                sql = old_migrator.generate_sql(diff)
                assert "CREATE TABLE comments" in sql

                alembic = old_migrator.generate_alembic(diff)
                assert "op.create_table" in alembic
                assert "'comments'" in alembic

                flyway = old_migrator.generate_flyway(diff)
                assert "V1__" in flyway

    def test_diff_to_dict(self, tmp_path):
        """Verify diff_to_dict produces serializable output."""
        old_dir = tmp_path / "old"
        new_dir = tmp_path / "new"
        old_dir.mkdir()
        new_dir.mkdir()

        old_db = _index_project(old_dir, SQLALCHEMY_CODE)
        new_db = _index_project(new_dir, SQLALCHEMY_V2_CODE)

        from codebrain.graph.store import GraphStore
        with GraphStore(str(old_db)) as old_store:
            with GraphStore(str(new_db)) as new_store:
                old_migrator = SchemaMigrator(old_store)
                new_migrator = SchemaMigrator(new_store)
                old_schema = old_migrator.extract_schema()
                new_schema = new_migrator.extract_schema()
                diff = old_migrator.diff(old_schema, new_schema)
                d = old_migrator.diff_to_dict(diff)

                assert d["has_changes"] is True
                assert "comments" in d["added_tables"]
                import json
                # Must be JSON-serializable
                json.dumps(d)
