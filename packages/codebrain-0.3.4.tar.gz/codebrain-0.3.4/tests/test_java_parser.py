"""Tests for the Java tree-sitter parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.java_parser import JavaParser, _JAVA_AVAILABLE

pytestmark = pytest.mark.skipif(not _JAVA_AVAILABLE, reason="tree-sitter-languages not installed")


@pytest.fixture
def parser():
    return JavaParser()


@pytest.fixture
def java_project(tmp_path: Path) -> Path:
    """Create a small Java project for testing."""
    src = tmp_path / "src" / "main" / "java" / "com" / "example"
    src.mkdir(parents=True)

    (src / "UserService.java").write_text("""\
package com.example;

import java.util.List;
import java.util.ArrayList;
import com.example.models.User;

/**
 * Service for managing users.
 * Handles CRUD operations.
 */
public class UserService extends BaseService implements Serializable {
    private final UserRepository repo;
    private static final int MAX_USERS = 100;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    public List<User> findAll() {
        return repo.getAll();
    }

    public User findById(int id) {
        User user = repo.get(id);
        validate(user);
        return user;
    }

    private void validate(User user) {
        if (user == null) {
            throw new RuntimeException("Not found");
        }
    }

    public enum Status {
        ACTIVE, INACTIVE
    }

    public interface Validator {
        boolean check(User user);
    }

    private class InnerHelper {
        void help() {
            findAll();
        }
    }
}
""")

    (src / "BaseService.java").write_text("""\
package com.example;

/**
 * Abstract base service with common functionality.
 */
public abstract class BaseService {
    protected String name;

    public abstract void init();

    protected void log(String message) {
        System.out.println(message);
    }
}
""")

    (src / "Main.java").write_text("""\
package com.example;

import com.example.UserService;

public class Main {
    public static void main(String[] args) {
        UserService service = new UserService(null);
        service.findAll();
        service.findById(1);
    }
}
""")

    return tmp_path


class TestBasicParsing:
    """Test basic Java symbol extraction."""

    def test_parses_java_file(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        assert result.path.endswith("UserService.java")
        assert result.line_count > 0

    def test_finds_class(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        classes = [n for n in result.nodes if n.type == "class" and n.name == "UserService"]
        assert len(classes) == 1
        assert classes[0].is_exported is True

    def test_finds_methods(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        methods = [n for n in result.nodes if n.type == "method"]
        method_names = {m.name for m in methods}
        assert "findAll" in method_names
        assert "findById" in method_names
        assert "validate" in method_names

    def test_finds_constructor(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        constructors = [n for n in result.nodes if n.name == "__init__"]
        assert len(constructors) >= 1

    def test_finds_fields(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        variables = [n for n in result.nodes if n.type == "variable"]
        var_names = {v.name for v in variables}
        assert "repo" in var_names
        assert "MAX_USERS" in var_names

    def test_finds_inner_enum(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        enums = [n for n in result.nodes if "enum" in n.decorators]
        assert any(n.name == "Status" for n in enums)

    def test_finds_inner_interface(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        ifaces = [n for n in result.nodes if "interface" in n.decorators]
        assert any(n.name == "Validator" for n in ifaces)

    def test_finds_inner_class(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        classes = [n for n in result.nodes if n.type == "class"]
        names = {c.name for c in classes}
        assert "InnerHelper" in names

    def test_enum_constants(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        constants = [n for n in result.nodes if n.type == "variable"
                     and n.qualified_name.startswith("Status.")]
        names = {c.name for c in constants}
        assert "ACTIVE" in names
        assert "INACTIVE" in names


class TestRelationships:
    """Test edge extraction (CALLS, IMPORTS, EXTENDS, IMPLEMENTS, CONTAINS)."""

    def test_imports(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        targets = {e.target for e in imports}
        assert "java.util.List" in targets
        assert "java.util.ArrayList" in targets
        assert "com.example.models.User" in targets

    def test_extends(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        extends = [e for e in result.edges if e.type == "EXTENDS"]
        targets = {e.target for e in extends}
        assert "BaseService" in targets

    def test_implements(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        impls = [e for e in result.edges if e.type == "IMPLEMENTS"]
        targets = {e.target for e in impls}
        assert "Serializable" in targets

    def test_contains_edges(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        contains = [e for e in result.edges if e.type == "CONTAINS"]
        assert len(contains) > 5  # file->class, class->methods, class->fields

    def test_method_calls(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert "validate" in targets or any("validate" in t for t in targets)

    def test_constructor_calls(self, parser: JavaParser, java_project: Path):
        """new ClassName() should generate a CALLS edge."""
        path = java_project / "src/main/java/com/example/Main.java"
        result = parser.parse(path, java_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert "UserService" in targets

    def test_method_invocation_calls(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/Main.java"
        result = parser.parse(path, java_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert any("findAll" in t for t in targets)
        assert any("findById" in t for t in targets)


class TestMetadata:
    """Test signatures, javadoc, modifiers."""

    def test_method_signature(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        find_by_id = [n for n in result.nodes if n.name == "findById"]
        assert len(find_by_id) == 1
        sig = find_by_id[0].signature
        assert "int id" in sig

    def test_javadoc_extraction(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        cls = [n for n in result.nodes if n.name == "UserService" and n.type == "class"]
        assert len(cls) == 1
        assert "managing users" in cls[0].docstring.lower()

    def test_package_in_file_docstring(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        file_node = [n for n in result.nodes if n.type == "file"]
        assert len(file_node) == 1
        assert "com.example" in file_node[0].docstring

    def test_public_methods_exported(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        find_all = [n for n in result.nodes if n.name == "findAll"]
        validate = [n for n in result.nodes if n.name == "validate"]
        assert find_all[0].is_exported is True
        assert validate[0].is_exported is False

    def test_abstract_class(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/BaseService.java"
        result = parser.parse(path, java_project)
        cls = [n for n in result.nodes if n.name == "BaseService" and n.type == "class"]
        assert len(cls) == 1

    def test_qualified_names(self, parser: JavaParser, java_project: Path):
        path = java_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, java_project)
        find_all = [n for n in result.nodes if n.name == "findAll"]
        assert find_all[0].qualified_name == "UserService.findAll"

    def test_extensions(self, parser: JavaParser):
        assert ".java" in parser.extensions()


class TestSpringBoot:
    """Test Spring Boot annotation awareness."""

    @pytest.fixture
    def spring_project(self, tmp_path: Path) -> Path:
        """Create a Spring Boot project for testing."""
        src = tmp_path / "src" / "main" / "java" / "com" / "example"
        src.mkdir(parents=True)

        (src / "UserController.java").write_text("""\
package com.example;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

/**
 * REST controller for user operations.
 */
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private NotificationService notificationService;

    @GetMapping
    public List<User> listUsers() {
        return userService.findAll();
    }

    @GetMapping("/{id}")
    public User getUser(@PathVariable int id) {
        return userService.findById(id);
    }

    @PostMapping
    public User createUser(@RequestBody User user) {
        User created = userService.save(user);
        notificationService.notify(created);
        return created;
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable int id) {
        userService.delete(id);
    }
}
""")

        (src / "UserService.java").write_text("""\
package com.example;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> findAll() {
        return userRepository.findAll();
    }

    public User findById(int id) {
        return userRepository.findById(id);
    }

    public User save(User user) {
        return userRepository.save(user);
    }

    public void delete(int id) {
        userRepository.deleteById(id);
    }
}
""")

        (src / "User.java").write_text("""\
package com.example;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String email;

    @OneToMany(mappedBy = "user")
    private List<Order> orders;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
}
""")

        (src / "UserRepository.java").write_text("""\
package com.example;

import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository {
    User findById(int id);
    java.util.List<User> findAll();
    User save(User user);
    void deleteById(int id);
}
""")

        return tmp_path

    def test_rest_controller_detected(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserController.java"
        result = parser.parse(path, spring_project)
        ctrl = [n for n in result.nodes if n.name == "UserController" and n.type == "class"]
        assert len(ctrl) == 1
        ann_names = {a.split("(")[0] for a in ctrl[0].decorators}
        assert "RestController" in ann_names

    def test_request_mapping_base_path(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserController.java"
        result = parser.parse(path, spring_project)
        ctrl = [n for n in result.nodes if n.name == "UserController" and n.type == "class"]
        assert len(ctrl) == 1
        assert "/api/users" in ctrl[0].docstring

    def test_get_mapping_in_signature(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserController.java"
        result = parser.parse(path, spring_project)
        list_users = [n for n in result.nodes if n.name == "listUsers"]
        assert len(list_users) == 1
        assert "[GET]" in list_users[0].signature

    def test_post_mapping_in_signature(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserController.java"
        result = parser.parse(path, spring_project)
        create = [n for n in result.nodes if n.name == "createUser"]
        assert len(create) == 1
        assert "[POST]" in create[0].signature

    def test_delete_mapping_in_signature(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserController.java"
        result = parser.parse(path, spring_project)
        delete = [n for n in result.nodes if n.name == "deleteUser"]
        assert len(delete) == 1
        assert "[DELETE /{id}]" in delete[0].signature

    def test_get_mapping_with_path(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserController.java"
        result = parser.parse(path, spring_project)
        get_user = [n for n in result.nodes if n.name == "getUser"]
        assert len(get_user) == 1
        assert "/{id}" in get_user[0].signature

    def test_autowired_dataflow_edges(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserController.java"
        result = parser.parse(path, spring_project)
        dataflow = [e for e in result.edges if e.type == "DATAFLOW"]
        targets = {e.target for e in dataflow}
        assert "UserService" in targets
        assert "NotificationService" in targets

    def test_service_annotation(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, spring_project)
        svc = [n for n in result.nodes if n.name == "UserService" and n.type == "class"]
        assert len(svc) == 1
        ann_names = {a.split("(")[0] for a in svc[0].decorators}
        assert "Service" in ann_names

    def test_service_autowired(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserService.java"
        result = parser.parse(path, spring_project)
        dataflow = [e for e in result.edges if e.type == "DATAFLOW"]
        targets = {e.target for e in dataflow}
        assert "UserRepository" in targets

    def test_jpa_entity_detected(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/User.java"
        result = parser.parse(path, spring_project)
        user = [n for n in result.nodes if n.name == "User" and n.type == "class"]
        assert len(user) == 1
        ann_names = {a.split("(")[0] for a in user[0].decorators}
        assert "Entity" in ann_names

    def test_jpa_table_name(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/User.java"
        result = parser.parse(path, spring_project)
        user = [n for n in result.nodes if n.name == "User" and n.type == "class"]
        assert len(user) == 1
        assert "users" in user[0].docstring

    def test_jpa_one_to_many(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/User.java"
        result = parser.parse(path, spring_project)
        dataflow = [e for e in result.edges if e.type == "DATAFLOW"]
        targets = {e.target for e in dataflow}
        assert "Order" in targets

    def test_jpa_many_to_one(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/User.java"
        result = parser.parse(path, spring_project)
        dataflow = [e for e in result.edges if e.type == "DATAFLOW"]
        targets = {e.target for e in dataflow}
        assert "Department" in targets

    def test_repository_annotation(self, parser: JavaParser, spring_project: Path):
        path = spring_project / "src/main/java/com/example/UserRepository.java"
        result = parser.parse(path, spring_project)
        repo = [n for n in result.nodes if n.name == "UserRepository" and n.type == "class"]
        assert len(repo) == 1
        ann_names = {a.split("(")[0] for a in repo[0].decorators}
        assert "Repository" in ann_names

    def test_spring_index_integration(self, spring_project: Path):
        """Full indexing pipeline should work with Spring Boot code."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index

        result = full_index(spring_project)
        assert result["errors"] == []
        assert result["files_parsed"] == 4

        db = spring_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            stats = store.get_stats()
            assert stats["nodes"] > 10
            assert stats["edges"] > 10

            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            results = engine.search_nodes("UserController")
            assert any(r["name"] == "UserController" for r in results)


class TestIndexIntegration:
    """Test that Java files work with the full indexing pipeline."""

    def test_index_java_project(self, java_project: Path):
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index

        result = full_index(java_project)
        assert result["errors"] == []
        assert result["files_parsed"] == 3

        db = java_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            stats = store.get_stats()
            assert stats["nodes"] > 10
            assert stats["edges"] > 10
            # Check we can find classes
            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            results = engine.search_nodes("UserService")
            assert any(r["name"] == "UserService" for r in results)

    def test_impact_analysis_java(self, java_project: Path):
        """Impact analysis should work on Java symbols."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.graph.query import QueryEngine
        from codebrain.indexer import full_index

        full_index(java_project)
        db = java_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)
            results = engine.search_nodes("BaseService")
            assert len(results) > 0

    def test_kt_document_java(self, java_project: Path):
        """KT document generation should work on Java codebases."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index
        from codebrain.kt import KTGenerator

        full_index(java_project)
        db = java_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            gen = KTGenerator(store)
            doc = gen.generate(project_name="JavaTestProject")
            assert "# JavaTestProject" in doc
            assert "## Architecture Overview" in doc
            assert "```mermaid" in doc
