"""Tests for the Dart parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.dart_parser import DartParser


@pytest.fixture
def parser():
    return DartParser()


@pytest.fixture
def flutter_project(tmp_path: Path) -> Path:
    """Create a small Flutter/Dart project for testing."""
    lib = tmp_path / "lib"
    lib.mkdir()

    (lib / "main.dart").write_text("""\
import 'package:flutter/material.dart';
import 'package:myapp/services/auth_service.dart';
import 'package:myapp/models/user.dart' as models;

/// Application entry point.
void main() {
  runApp(MyApp());
}

/// Root application widget.
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}
""")

    (lib / "models.dart").write_text("""\
/// Data models for the application.

/// Represents a user in the system.
class User {
  final String name;
  final int age;
  final String? email;

  const User({required this.name, required this.age, this.email});

  /// Create user from JSON map.
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      name: json['name'],
      age: json['age'],
      email: json['email'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'name': name, 'age': age, 'email': email};
  }

  @override
  String toString() => 'User($name, $age)';
}

/// Admin user with extra permissions.
class AdminUser extends User {
  final List<String> permissions;

  const AdminUser({
    required super.name,
    required super.age,
    super.email,
    required this.permissions,
  });

  bool hasPermission(String perm) {
    return permissions.contains(perm);
  }
}

/// Account status.
enum AccountStatus {
  active,
  inactive,
  suspended;

  bool get isActive => this == AccountStatus.active;
}
""")

    (lib / "services.dart").write_text("""\
import 'package:myapp/models.dart';

/// Base service with common functionality.
abstract class BaseService {
  final String baseUrl;

  BaseService(this.baseUrl);

  /// Initialize the service.
  Future<void> init();

  void log(String message) {
    print('[Service] $message');
  }
}

/// Handles user authentication.
class AuthService extends BaseService implements Disposable {
  String? _token;

  AuthService(String baseUrl) : super(baseUrl);

  @override
  Future<void> init() async {
    log('AuthService initialized');
  }

  /// Authenticate user with credentials.
  Future<User?> login(String username, String password) async {
    log('Logging in $username');
    _token = 'mock_token';
    return User(name: username, age: 0);
  }

  Future<void> logout() async {
    _token = null;
  }

  bool get isAuthenticated => _token != null;

  @override
  void dispose() {
    _token = null;
  }
}

/// Interface for disposable resources.
abstract class Disposable {
  void dispose();
}

/// Mixin for retry logic.
mixin RetryMixin on BaseService {
  int maxRetries = 3;

  Future<T> withRetry<T>(Future<T> Function() action) async {
    for (var i = 0; i < maxRetries; i++) {
      try {
        return await action();
      } catch (e) {
        if (i == maxRetries - 1) rethrow;
        log('Retry ${i + 1}/$maxRetries');
      }
    }
    throw Exception('Should not reach here');
  }
}

/// Extension on String for validation.
extension StringValidation on String {
  bool get isValidEmail => contains('@') && contains('.');

  bool get isNotBlank => trim().isNotEmpty;
}
""")

    (lib / "utils.dart").write_text("""\
/// Utility functions.

/// Format a date for display.
String formatDate(DateTime date) {
  return '${date.year}-${date.month}-${date.day}';
}

/// Parse an integer safely.
int? tryParseInt(String value) {
  return int.tryParse(value);
}

/// Application-wide constants.
const String appName = 'MyApp';
final int maxRetries = 3;

/// Private helper (not exported).
void _logInternal(String msg) {
  print(msg);
}
""")

    return tmp_path


class TestBasicParsing:
    """Test basic Dart symbol extraction."""

    def test_parses_dart_file(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "main.dart"
        result = parser.parse(path, flutter_project)
        assert result.path.endswith("main.dart")
        assert result.line_count > 0

    def test_finds_class(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "main.dart"
        result = parser.parse(path, flutter_project)
        classes = [n for n in result.nodes if n.type == "class" and n.name == "MyApp"]
        assert len(classes) == 1
        assert classes[0].is_exported is True

    def test_finds_top_level_function(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "utils.dart"
        result = parser.parse(path, flutter_project)
        funcs = [n for n in result.nodes if n.type == "function"]
        names = {f.name for f in funcs}
        assert "formatDate" in names
        assert "tryParseInt" in names

    def test_private_not_exported(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "utils.dart"
        result = parser.parse(path, flutter_project)
        internal = [n for n in result.nodes if n.name == "_logInternal"]
        assert len(internal) == 1
        assert internal[0].is_exported is False

    def test_finds_methods(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        methods = [n for n in result.nodes if n.type == "method"]
        method_names = {m.name for m in methods}
        assert "toJson" in method_names
        assert "toString" in method_names

    def test_finds_constructor(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        ctors = [n for n in result.nodes if n.name == "__init__"]
        assert len(ctors) >= 1  # User constructor

    def test_finds_named_constructor(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        named = [n for n in result.nodes if "fromJson" in n.name]
        assert len(named) >= 1

    def test_finds_fields(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        fields = [n for n in result.nodes if n.type == "variable"
                  and n.qualified_name.startswith("User.")]
        names = {f.name for f in fields}
        assert "name" in names
        assert "age" in names

    def test_finds_enum(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        enums = [n for n in result.nodes if "enum" in n.decorators]
        assert any(n.name == "AccountStatus" for n in enums)

    def test_enum_values(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        vals = [n for n in result.nodes if n.type == "variable"
                and n.qualified_name.startswith("AccountStatus.")]
        names = {v.name for v in vals}
        assert "active" in names
        assert "inactive" in names
        assert "suspended" in names

    def test_finds_abstract_class(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        base = [n for n in result.nodes if n.name == "BaseService"]
        assert len(base) == 1
        assert "abstract" in base[0].decorators

    def test_finds_mixin(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        mixins = [n for n in result.nodes if "mixin" in n.decorators]
        assert any(n.name == "RetryMixin" for n in mixins)

    def test_finds_extension(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        exts = [n for n in result.nodes if "extension" in n.decorators]
        assert any(n.name == "StringValidation" for n in exts)

    def test_finds_getter(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        getters = [n for n in result.nodes if n.name == "isAuthenticated"]
        assert len(getters) >= 1

    def test_top_level_variables(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "utils.dart"
        result = parser.parse(path, flutter_project)
        vars_ = [n for n in result.nodes if n.type == "variable"
                 and not n.qualified_name.startswith(("User.", "Admin", "Account"))]
        names = {v.name for v in vars_}
        assert "appName" in names or "maxRetries" in names

    def test_extensions_method(self, parser: DartParser):
        assert ".dart" in parser.extensions()


class TestRelationships:
    """Test edge extraction (CALLS, IMPORTS, EXTENDS, IMPLEMENTS, CONTAINS)."""

    def test_imports(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "main.dart"
        result = parser.parse(path, flutter_project)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        targets = {e.target for e in imports}
        assert "package:flutter/material.dart" in targets
        assert "package:myapp/services/auth_service.dart" in targets

    def test_extends(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "main.dart"
        result = parser.parse(path, flutter_project)
        extends_ = [e for e in result.edges if e.type == "EXTENDS"]
        targets = {e.target for e in extends_}
        assert "StatelessWidget" in targets

    def test_class_extends(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        extends_ = [e for e in result.edges if e.type == "EXTENDS"]
        targets = {e.target for e in extends_}
        assert "User" in targets  # AdminUser extends User

    def test_implements(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        impls = [e for e in result.edges if e.type == "IMPLEMENTS"]
        targets = {e.target for e in impls}
        assert "Disposable" in targets  # AuthService implements Disposable

    def test_mixin_on(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        extends_ = [e for e in result.edges if e.type == "EXTENDS"
                     and "RetryMixin" in e.source]
        assert len(extends_) > 0
        assert any(e.target == "BaseService" for e in extends_)

    def test_extension_on(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        extends_ = [e for e in result.edges if e.type == "EXTENDS"
                     and "StringValidation" in e.source]
        assert len(extends_) > 0
        assert any(e.target == "String" for e in extends_)

    def test_contains_edges(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        contains = [e for e in result.edges if e.type == "CONTAINS"]
        assert len(contains) > 5  # file->classes, class->methods, class->fields

    def test_method_calls(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert "log" in targets or any("log" in t for t in targets)


class TestMetadata:
    """Test docstrings, annotations, signatures."""

    def test_docstring_extraction(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        user = [n for n in result.nodes if n.name == "User" and n.type == "class"]
        assert len(user) == 1
        assert "user" in user[0].docstring.lower()

    def test_function_signature(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "utils.dart"
        result = parser.parse(path, flutter_project)
        fmt = [n for n in result.nodes if n.name == "formatDate"]
        assert len(fmt) == 1
        assert "DateTime date" in fmt[0].signature

    def test_override_annotation(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "main.dart"
        result = parser.parse(path, flutter_project)
        build = [n for n in result.nodes if n.name == "build"]
        if build:
            assert "override" in build[0].decorators

    def test_method_signature(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "services.dart"
        result = parser.parse(path, flutter_project)
        login = [n for n in result.nodes if n.name == "login"]
        assert len(login) >= 1
        assert "username" in login[0].signature or "String" in login[0].signature

    def test_file_docstring(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "utils.dart"
        result = parser.parse(path, flutter_project)
        file_node = [n for n in result.nodes if n.type == "file"]
        assert len(file_node) == 1
        assert "Utility" in file_node[0].docstring or file_node[0].docstring

    def test_qualified_names(self, parser: DartParser, flutter_project: Path):
        path = flutter_project / "lib" / "models.dart"
        result = parser.parse(path, flutter_project)
        to_json = [n for n in result.nodes if n.name == "toJson"]
        assert len(to_json) >= 1
        assert to_json[0].qualified_name == "User.toJson"


class TestIndexIntegration:
    """Test that Dart files work with the full indexing pipeline."""

    def test_index_dart_project(self, flutter_project: Path):
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index

        result = full_index(flutter_project)
        assert result["errors"] == []
        assert result["files_parsed"] == 4

        db = flutter_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            stats = store.get_stats()
            assert stats["nodes"] > 15
            assert stats["edges"] > 15

            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            results = engine.search_nodes("AuthService")
            assert any(r["name"] == "AuthService" for r in results)

    def test_impact_analysis_dart(self, flutter_project: Path):
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.graph.query import QueryEngine
        from codebrain.indexer import full_index

        full_index(flutter_project)
        db = flutter_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)
            results = engine.search_nodes("User")
            assert len(results) > 0

    def test_kt_document_dart(self, flutter_project: Path):
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index
        from codebrain.kt import KTGenerator

        full_index(flutter_project)
        db = flutter_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            gen = KTGenerator(store)
            doc = gen.generate(project_name="FlutterTestProject")
            assert "# FlutterTestProject" in doc
            assert "## Architecture Overview" in doc

    def test_modernize_spec_dart(self, flutter_project: Path):
        """Modernization spec should work on Dart codebases."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index
        from codebrain.modernize import SpecGenerator

        full_index(flutter_project)
        db = flutter_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            gen = SpecGenerator(store)
            spec = gen.generate_full_spec()
            assert spec["total_modules"] > 0
            assert len(spec["module_specs"]) > 0
