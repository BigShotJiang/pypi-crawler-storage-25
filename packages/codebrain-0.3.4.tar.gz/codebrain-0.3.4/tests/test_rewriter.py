"""Tests for the rewrite engine — prompt building, validation, engine loop."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.rewriter import (
    LLMClient,
    LLMResponse,
    PipelineResult,
    RewriteEngine,
    ModuleTestResult,
    ValidationResult,
    _build_file_rewrite_prompt,
    _build_retry_prompt,
    _build_system_prompt,
    _extract_code,
    _generate_test_for_module,
    _run_pytest,
    create_client,
    rewrite_and_verify,
    validate_rewrite,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def project(tmp_path: Path) -> tuple[Path, GraphStore]:
    """Create and index a sample project for rewriting."""
    root = tmp_path / "oldapp"
    pkg = root / "myapp"
    pkg.mkdir(parents=True)

    (pkg / "__init__.py").write_text(
        '"""Old app."""\nfrom myapp.core import process\n'
    )

    (pkg / "core.py").write_text('''\
"""Core module."""
from myapp.utils import helper

__all__ = ["process", "DataProcessor"]

def process(data):
    """Process incoming data."""
    return helper(data) * 2

def _internal():
    """Not exported."""
    pass

class DataProcessor:
    """Main processor."""
    def __init__(self, config):
        self.config = config

    def run(self, items):
        """Run processing."""
        return [process(i) for i in items]

    def validate(self, item):
        """Check item."""
        return item is not None
''')

    (pkg / "utils.py").write_text('''\
"""Utilities."""

__all__ = ["helper"]

def helper(x):
    """Help with stuff."""
    return x + 1
''')

    full_index(root)
    db = root / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db)
    yield root, store
    store.close()


class MockLLMClient(LLMClient):
    """Mock LLM that returns pre-set responses."""

    def __init__(self, responses: list[str] | None = None):
        self._responses = responses or []
        self._call_count = 0
        self.prompts: list[tuple[str, str]] = []

    def complete(self, system: str, user: str, temperature: float = 0.1) -> LLMResponse:
        self.prompts.append((system, user))
        idx = min(self._call_count, len(self._responses) - 1)
        content = self._responses[idx] if self._responses else "# empty"
        self._call_count += 1
        return LLMResponse(content=content, model="mock", tokens_used=100)

    def is_available(self) -> bool:
        return True


class FailingLLMClient(LLMClient):
    """Mock LLM that always raises errors."""

    def complete(self, system: str, user: str, temperature: float = 0.1) -> LLMResponse:
        raise ConnectionError("LLM unreachable")

    def is_available(self) -> bool:
        return False


# ---------------------------------------------------------------------------
# Tests: Code extraction
# ---------------------------------------------------------------------------


class TestCodeExtraction:

    def test_extract_from_fenced_python(self):
        response = '```python\ndef hello():\n    return "hi"\n```'
        code = _extract_code(response)
        assert 'def hello():' in code
        assert '```' not in code

    def test_extract_from_fenced_no_lang(self):
        response = '```\nclass Foo:\n    pass\n```'
        code = _extract_code(response)
        assert 'class Foo:' in code

    def test_extract_plain_code(self):
        response = 'def hello():\n    return "hi"'
        code = _extract_code(response)
        assert 'def hello():' in code

    def test_extract_with_explanation(self):
        response = 'Here is the code:\n```python\ndef foo():\n    pass\n```\nDone.'
        code = _extract_code(response)
        assert 'def foo():' in code
        assert 'Here is' not in code

    def test_extract_multiple_fences_picks_longest(self):
        response = '```python\nx = 1\n```\n\n```python\ndef foo():\n    return 1\n\ndef bar():\n    return 2\n```'
        code = _extract_code(response)
        assert 'def foo():' in code
        assert 'def bar():' in code


# ---------------------------------------------------------------------------
# Tests: Prompt building
# ---------------------------------------------------------------------------


class TestPromptBuilding:

    def test_system_prompt_basics(self):
        prompt = _build_system_prompt("FastAPI", "Use async")
        assert "FastAPI" in prompt
        assert "Use async" in prompt
        assert "public API contract" in prompt.lower() or "public api" in prompt.lower()

    def test_system_prompt_empty(self):
        prompt = _build_system_prompt("", "")
        assert "rewrite" in prompt.lower() or "modernization" in prompt.lower()

    def test_file_rewrite_prompt(self):
        source = 'def foo():\n    return 1'
        spec = {
            "file_path": "myapp/core.py",
            "symbols": [
                {"name": "foo", "type": "function", "signature": "foo()",
                 "is_exported": True, "docstring": "Do foo."},
            ],
            "dependencies": ["myapp.utils"],
            "dependents": ["myapp.api"],
            "rewrite_notes": ["Leaf module"],
            "test_scenarios": [
                {"description": "foo exists", "checks": ["Function foo is importable"]},
            ],
        }
        prompt = _build_file_rewrite_prompt(source, spec)
        assert "def foo():" in prompt
        assert "myapp/core.py" in prompt
        assert "myapp.utils" in prompt
        assert "MUST preserve" in prompt

    def test_retry_prompt_includes_errors(self):
        prompt = _build_retry_prompt(
            "original prompt",
            "def foo(): pass",
            ["Missing exported function 'bar'"],
        )
        assert "Missing exported function" in prompt
        assert "FAILED VALIDATION" in prompt
        assert "original prompt" in prompt


# ---------------------------------------------------------------------------
# Tests: Validation
# ---------------------------------------------------------------------------


class TestValidation:

    def test_valid_python(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "process", "type": "function", "signature": "process(data)",
                 "is_exported": True},
            ],
        }
        code = 'def process(data):\n    return data * 2'
        result = validate_rewrite(spec, code)
        assert result.valid
        assert len(result.errors) == 0

    def test_syntax_error(self):
        spec = {"file_path": "test.py", "symbols": []}
        code = 'def foo(\n'
        result = validate_rewrite(spec, code)
        assert not result.valid
        assert any("Syntax error" in e for e in result.errors)

    def test_missing_exported_function(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "process", "type": "function", "signature": "process(data)",
                 "is_exported": True},
            ],
        }
        code = 'def helper(x):\n    return x'
        result = validate_rewrite(spec, code)
        assert not result.valid
        assert any("process" in e for e in result.errors)

    def test_missing_exported_class(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "MyClass", "type": "class", "is_exported": True},
            ],
        }
        code = 'def something():\n    pass'
        result = validate_rewrite(spec, code)
        assert not result.valid
        assert any("MyClass" in e for e in result.errors)

    def test_class_methods_warning(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "MyClass", "type": "class", "is_exported": True,
                 "methods": [
                     {"name": "run", "is_exported": True},
                     {"name": "_private", "is_exported": False},
                 ]},
            ],
        }
        old_source = 'class MyClass:\n    def run(self):\n        pass\n    def _private(self):\n        pass'
        code = 'class MyClass:\n    pass'
        result = validate_rewrite(spec, code, old_source=old_source)
        assert result.valid  # Missing methods are warnings, not errors
        assert any("run" in w for w in result.warnings)

    def test_internal_symbols_ignored(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "_internal", "type": "function", "is_exported": False},
                {"name": "public_fn", "type": "function", "is_exported": True},
            ],
        }
        code = 'def public_fn():\n    return 42'
        result = validate_rewrite(spec, code)
        assert result.valid  # _internal not required

    def test_java_validation(self):
        spec = {
            "file_path": "Main.java",
            "symbols": [
                {"name": "Main", "type": "class", "is_exported": True},
            ],
        }
        code = 'public class Main {\n    public static void main(String[] args) {}\n}'
        result = validate_rewrite(spec, code)
        assert result.valid

    def test_java_missing_class(self):
        spec = {
            "file_path": "Main.java",
            "symbols": [],
        }
        code = '// empty'
        result = validate_rewrite(spec, code)
        assert not result.valid

    def test_vue_sfc_default_export(self):
        """Vue SFCs with export default should not fail on 'missing exported symbol'."""
        spec = {
            "file_path": "MyComponent.vue",
            "symbols": [
                {"name": "MyComponent", "type": "component", "is_exported": True},
            ],
        }
        code = "<template><div>Hello</div></template>\n<script>\nexport default { name: 'MyComponent' }\n</script>"
        result = validate_rewrite(spec, code)
        assert result.valid

    def test_vue_sfc_script_setup(self):
        """Vue SFCs with <script setup> auto-export — should pass."""
        spec = {
            "file_path": "Dashboard.vue",
            "symbols": [
                {"name": "Dashboard", "type": "component", "is_exported": True},
            ],
        }
        code = "<template><div>Dashboard</div></template>\n<script setup>\nconst count = ref(0)\n</script>"
        result = validate_rewrite(spec, code)
        assert result.valid

    def test_vue_sfc_truly_missing_symbol(self):
        """Vue SFC that genuinely misses the symbol should still fail."""
        spec = {
            "file_path": "Widget.vue",
            "symbols": [
                {"name": "Widget", "type": "component", "is_exported": True},
            ],
        }
        code = "<template><div></div></template>\n<script>\nconst x = 1;\n</script>"
        result = validate_rewrite(spec, code)
        assert not result.valid
        assert any("Widget" in e for e in result.errors)


# ---------------------------------------------------------------------------
# Tests: Deep AST validation (old_source comparison)
# ---------------------------------------------------------------------------


class TestDeepValidation:
    """Tests for parameter-level signature comparison."""

    def test_removed_required_param_is_error(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "process", "type": "function", "is_exported": True,
                 "external_caller_count": 2},
            ],
        }
        old = "def process(data, config):\n    pass"
        new = "def process(data):\n    pass"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("config" in e for e in result.errors)

    def test_added_optional_param_is_ok(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "process", "type": "function", "is_exported": True},
            ],
        }
        old = "def process(data):\n    pass"
        new = "def process(data, verbose=False):\n    pass"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid

    def test_init_removed_required_param_is_error(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "Storage", "type": "class", "is_exported": True,
                 "external_caller_count": 3},
            ],
        }
        old = "class Storage:\n    def __init__(self, db_path):\n        self.db = db_path"
        new = "class Storage:\n    def __init__(self):\n        self.db = ':memory:'"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("db_path" in e for e in result.errors)

    def test_init_removed_optional_param_is_error_when_exported(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "Storage", "type": "class", "is_exported": True,
                 "external_caller_count": 3},
            ],
        }
        old = "class Storage:\n    def __init__(self, data_dir='./data'):\n        self.dir = data_dir"
        new = "class Storage:\n    def __init__(self):\n        self.dir = './data'"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("data_dir" in e for e in result.errors)

    def test_init_removed_optional_param_is_warning_when_internal(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "Storage", "type": "class", "is_exported": False,
                 "external_caller_count": 0},
            ],
        }
        old = "class Storage:\n    def __init__(self, data_dir='./data'):\n        pass"
        new = "class Storage:\n    def __init__(self):\n        pass"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid  # Not exported, so warning only
        assert any("data_dir" in w for w in result.warnings)

    def test_added_required_init_param_is_error(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "Service", "type": "class", "is_exported": True,
                 "external_caller_count": 5},
            ],
        }
        old = "class Service:\n    def __init__(self):\n        pass"
        new = "class Service:\n    def __init__(self, db):\n        self.db = db"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("db" in e for e in result.errors)

    def test_public_method_removed_is_warning(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "Repo", "type": "class", "is_exported": True},
            ],
        }
        old = "class Repo:\n    def save(self, item):\n        pass\n    def load(self, key):\n        pass"
        new = "class Repo:\n    def save(self, item):\n        pass"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid  # Removed method is warning, not error
        assert any("load" in w for w in result.warnings)

    def test_base_class_changed_is_warning(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "Task", "type": "class", "is_exported": True},
            ],
        }
        old = "class Task:\n    pass"
        new = "from pydantic import BaseModel\nclass Task(BaseModel):\n    pass"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid  # Adding base is fine

    def test_base_class_removed_is_warning(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "Task", "type": "class", "is_exported": True},
            ],
        }
        old = "class Task(BaseModel):\n    pass"
        new = "class Task:\n    pass"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid
        assert any("BaseModel" in w for w in result.warnings)

    def test_no_old_source_falls_back_to_spec_only(self):
        spec = {
            "file_path": "test.py",
            "symbols": [
                {"name": "run", "type": "function", "is_exported": True},
            ],
        }
        code = "def run():\n    pass"
        result = validate_rewrite(spec, code)  # No old_source
        assert result.valid


# ---------------------------------------------------------------------------
# Tests: Rewrite engine
# ---------------------------------------------------------------------------


class TestRewriteEngine:

    def test_dry_run(self, project):
        root, store = project
        client = MockLLMClient()
        engine = RewriteEngine(root, store, client)

        out = root.parent / "output"
        result = engine.rewrite_all(out, dry_run=True)

        assert result.total_modules > 0
        assert result.succeeded > 0
        assert result.total_tokens == 0  # No LLM calls
        for m in result.modules:
            assert m.status in ("success", "skipped")

    def test_successful_rewrite(self, project):
        root, store = project
        good_code = '''\
"""Core module v2."""
from myapp.utils import helper

__all__ = ["process", "DataProcessor"]

def process(data):
    """Process incoming data."""
    return helper(data) * 2

class DataProcessor:
    """Main processor."""
    def __init__(self, config):
        self.config = config

    def run(self, items):
        """Run processing."""
        return [process(i) for i in items]

    def validate(self, item):
        return item is not None
'''
        client = MockLLMClient(responses=[good_code])
        engine = RewriteEngine(root, store, client)

        out = root.parent / "output"
        result = engine.rewrite_all(
            out, modules=["myapp/core.py"],
        )

        assert result.succeeded >= 1
        core_results = [m for m in result.modules if "core.py" in m.file_path]
        assert len(core_results) == 1
        assert core_results[0].status in ("success", "partial")

        # File should be written
        assert (out / "myapp" / "core.py").exists()

    def test_retry_on_validation_failure(self, project):
        root, store = project

        bad_code = 'def wrong_name():\n    pass'
        good_code = '''\
"""Utils v2."""

__all__ = ["helper"]

def helper(x):
    """Help with stuff."""
    return x + 1
'''
        client = MockLLMClient(responses=[bad_code, good_code])
        engine = RewriteEngine(root, store, client, max_retries=3)

        out = root.parent / "output"
        result = engine.rewrite_all(out, modules=["myapp/utils.py"])

        utils_results = [m for m in result.modules if "utils.py" in m.file_path]
        assert len(utils_results) == 1
        # Should have retried and succeeded
        assert utils_results[0].attempts >= 2
        assert utils_results[0].status in ("success", "partial")

    def test_all_retries_exhausted(self, project):
        root, store = project
        bad_code = 'def wrong():\n    pass'
        client = MockLLMClient(responses=[bad_code, bad_code, bad_code])
        engine = RewriteEngine(root, store, client, max_retries=3)

        out = root.parent / "output"
        result = engine.rewrite_all(out, modules=["myapp/utils.py"])

        utils_results = [m for m in result.modules if "utils.py" in m.file_path]
        assert len(utils_results) == 1
        assert utils_results[0].status == "failed"
        assert utils_results[0].attempts == 3
        assert len(utils_results[0].errors) > 0

    def test_llm_error_handled(self, project):
        root, store = project
        client = FailingLLMClient()
        engine = RewriteEngine(root, store, client, max_retries=2)

        out = root.parent / "output"
        result = engine.rewrite_all(out, modules=["myapp/utils.py"])

        utils_results = [m for m in result.modules if "utils.py" in m.file_path]
        assert len(utils_results) == 1
        assert utils_results[0].status == "failed"
        assert any("LLM error" in e for e in utils_results[0].errors)

    def test_single_module_rewrite(self, project):
        root, store = project
        good_code = '"""Utils."""\n\n__all__ = ["helper"]\n\ndef helper(x):\n    return x + 1\n'
        client = MockLLMClient(responses=[good_code])
        engine = RewriteEngine(root, store, client)

        result = engine.rewrite_module(
            "myapp/utils.py",
            output_dir=root.parent / "single_out",
        )
        assert result.status in ("success", "partial")
        assert (root.parent / "single_out" / "myapp" / "utils.py").exists()

    def test_progress_callback(self, project):
        root, store = project
        good_code = '"""Utils."""\n\n__all__ = ["helper"]\n\ndef helper(x):\n    return x + 1\n'
        client = MockLLMClient(responses=[good_code])
        engine = RewriteEngine(root, store, client)

        progress_log = []

        def on_progress(fp, status):
            progress_log.append((fp, status))

        out = root.parent / "output"
        engine.rewrite_all(out, modules=["myapp/utils.py"], on_progress=on_progress)

        assert len(progress_log) >= 2  # at least "rewriting" and final status

    def test_result_to_dict(self, project):
        root, store = project
        client = MockLLMClient()
        engine = RewriteEngine(root, store, client)

        out = root.parent / "output"
        result = engine.rewrite_all(out, dry_run=True)
        d = result.to_dict()
        assert "total_modules" in d
        assert "succeeded" in d
        assert "modules" in d

    def test_result_to_markdown(self, project):
        root, store = project
        client = MockLLMClient()
        engine = RewriteEngine(root, store, client)

        out = root.parent / "output"
        result = engine.rewrite_all(out, dry_run=True)
        md = result.to_markdown()
        assert "# Modernization Report" in md
        assert "Summary" in md


# ---------------------------------------------------------------------------
# Tests: Client factory
# ---------------------------------------------------------------------------


class TestClientFactory:

    def test_create_ollama_client(self):
        client = create_client(provider="ollama")
        assert isinstance(client, LLMClient)

    def test_create_anthropic_client(self):
        client = create_client(provider="anthropic", api_key="test-key")
        assert isinstance(client, LLMClient)

    def test_create_openai_client(self):
        client = create_client(provider="openai", api_key="test-key")
        assert isinstance(client, LLMClient)

    def test_default_is_ollama(self):
        client = create_client()
        assert isinstance(client, LLMClient)


# ---------------------------------------------------------------------------
# Tests: Full pipeline (rewrite_and_verify)
# ---------------------------------------------------------------------------


class TestPipeline:

    def test_pipeline_result_to_dict(self):
        from codebrain.rewriter import ModernizationResult
        pr = PipelineResult(
            rewrite=ModernizationResult(total_modules=2, succeeded=2),
            tests_generated=6, tests_passed=5, tests_failed=1,
        )
        d = pr.to_dict()
        assert d["tests_generated"] == 6
        assert d["tests_passed"] == 5
        assert d["rewrite"]["succeeded"] == 2

    def test_pipeline_result_to_markdown(self):
        from codebrain.rewriter import ModernizationResult
        pr = PipelineResult(
            rewrite=ModernizationResult(total_modules=1, succeeded=1),
            tests_generated=3, tests_passed=3,
            test_results=[
                ModuleTestResult(
                    test_file="tests/test_core.py",
                    module_file="myapp/core.py",
                    passed=True, test_count=3, failures=0, output="",
                ),
            ],
        )
        md = pr.to_markdown()
        assert "Test Verification" in md
        assert "test_core.py" in md

    def test_generate_test_for_module(self):
        code = "def add(a, b):\n    return a + b\n"
        mock = MockLLMClient([
            "import pytest\nfrom myapp.core import add\n\n"
            "def test_add_positive():\n    assert add(1, 2) == 3\n\n"
            "def test_add_negative():\n    assert add(-1, 1) == 0\n"
        ])
        result = _generate_test_for_module(
            mock, "myapp/core.py", code, Path("/tmp"), "Python",
        )
        assert "def test_add" in result
        assert "import" in result

    def test_generate_test_for_module_empty(self):
        """No testable symbols → empty result."""
        code = "# just a comment\n_private = 1\n"
        mock = MockLLMClient(["whatever"])
        result = _generate_test_for_module(
            mock, "myapp/core.py", code, Path("/tmp"), "",
        )
        assert result == ""

    def test_generate_test_syntax_error_code(self):
        """Invalid syntax → empty result."""
        mock = MockLLMClient(["whatever"])
        result = _generate_test_for_module(
            mock, "myapp/core.py", "def broken(:", Path("/tmp"), "",
        )
        assert result == ""

    def test_pipeline_full_with_mock(self, project):
        """Test full pipeline with mock LLM — rewrite + test gen."""
        root, store = project

        # Mock that returns valid rewrites and tests
        valid_core = '''\
"""Core module."""
from myapp.utils import helper

__all__ = ["process", "DataProcessor"]

def process(data):
    """Process incoming data."""
    return helper(data) * 2

def _internal():
    """Not exported."""
    pass

class DataProcessor:
    """Main processor."""
    def __init__(self, config):
        self.config = config

    def run(self, items):
        """Run processing."""
        return [process(i) for i in items]

    def validate(self, item):
        """Check item."""
        return item is not None
'''

        valid_utils = '''\
"""Utilities."""

__all__ = ["helper"]

def helper(x):
    """Help with stuff."""
    return x + 1
'''

        valid_init = '"""Old app."""\nfrom myapp.core import process\n'

        # Tests for core
        test_core = (
            "import pytest\nfrom myapp.core import process, DataProcessor\n\n"
            "def test_process():\n    assert process(1) == 4\n\n"
            "def test_data_processor_run():\n    dp = DataProcessor({})\n"
            "    assert dp.run([1]) == [4]\n"
        )

        mock = MockLLMClient([
            valid_init, valid_core, valid_utils,  # rewrites
            test_core,  # test gen for each module
            test_core, test_core,
        ])

        out = root / "output"
        result = rewrite_and_verify(
            old_root=root,
            store=store,
            client=mock,
            output_dir=out,
            max_retries=1,
            max_fix_rounds=1,
        )

        assert isinstance(result, PipelineResult)
        assert result.rewrite.succeeded > 0
        # Tests should have been generated
        assert result.tests_generated >= 0  # May be 0 if module has no symbols
        assert result.total_tokens > 0

    def test_run_pytest_missing_file(self, tmp_path):
        """Test running a non-existent test file."""
        fake_test = tmp_path / "test_nothing.py"
        fake_test.write_text("def test_x(): assert False")
        result = _run_pytest(fake_test, tmp_path)
        assert isinstance(result, ModuleTestResult)
        assert result.test_file == str(fake_test)

    def test_run_pytest_passing(self, tmp_path):
        """Test running a passing test file."""
        test_file = tmp_path / "test_pass.py"
        test_file.write_text("def test_one():\n    assert True\n")
        result = _run_pytest(test_file, tmp_path)
        assert result.passed
        assert result.test_count >= 1
        assert result.failures == 0


# ---------------------------------------------------------------------------
# Tests: JS/TS signature parsing
# ---------------------------------------------------------------------------


class TestJSSignatureParsing:
    """Tests for _parse_js_signatures — tree-sitter based JS/TS extraction."""

    def test_function_declaration(self):
        from codebrain.rewriter import _parse_js_signatures
        code = "function greet(name, age) { return name; }"
        sigs = _parse_js_signatures(code)
        assert "greet" in sigs
        assert sigs["greet"]["type"] == "function"
        assert sigs["greet"]["params"] == ["name", "age"]
        assert sigs["greet"]["required_params"] == ["name", "age"]

    def test_arrow_function(self):
        from codebrain.rewriter import _parse_js_signatures
        code = "const fetchData = (url, options) => { return fetch(url); };"
        sigs = _parse_js_signatures(code)
        assert "fetchData" in sigs
        assert sigs["fetchData"]["type"] == "function"
        assert "url" in sigs["fetchData"]["params"]

    def test_exported_function(self):
        from codebrain.rewriter import _parse_js_signatures
        code = "export function processItems(items, config) { return items; }"
        sigs = _parse_js_signatures(code)
        assert "processItems" in sigs
        assert sigs["processItems"]["params"] == ["items", "config"]

    def test_class_with_constructor(self):
        from codebrain.rewriter import _parse_js_signatures
        code = """
class UserService {
    constructor(db, logger) {
        this.db = db;
        this.logger = logger;
    }
    findById(id) { return this.db.find(id); }
    save(user) { this.db.save(user); }
}
"""
        sigs = _parse_js_signatures(code)
        assert "UserService" in sigs
        info = sigs["UserService"]
        assert info["type"] == "class"
        assert info["init_params"] == ["db", "logger"]
        assert info["init_required"] == ["db", "logger"]
        assert "findById" in info["methods"]
        assert "save" in info["methods"]

    def test_class_extends(self):
        from codebrain.rewriter import _parse_js_signatures
        code = "class Admin extends User { getRole() { return 'admin'; } }"
        sigs = _parse_js_signatures(code)
        assert "Admin" in sigs
        assert "User" in sigs["Admin"]["bases"]

    def test_interface_with_methods(self):
        from codebrain.rewriter import _parse_js_signatures
        code = """
interface Repository {
    findAll(): Promise<Item[]>;
    findById(id: string): Promise<Item>;
    save(item: Item): Promise<void>;
}
"""
        sigs = _parse_js_signatures(code)
        assert "Repository" in sigs
        info = sigs["Repository"]
        assert info["type"] == "class"  # interfaces are class-like
        assert "findById" in info["methods"]
        assert "save" in info["methods"]

    def test_enum_members(self):
        from codebrain.rewriter import _parse_js_signatures
        code = """
enum Status {
    Active = 'active',
    Inactive = 'inactive',
    Pending = 'pending'
}
"""
        sigs = _parse_js_signatures(code)
        assert "Status" in sigs
        assert sigs["Status"]["type"] == "enum"
        assert set(sigs["Status"]["members"]) == {"Active", "Inactive", "Pending"}

    def test_optional_params(self):
        from codebrain.rewriter import _parse_js_signatures
        code = "function query(table: string, limit?: number, offset?: number) { }"
        sigs = _parse_js_signatures(code)
        assert "query" in sigs
        assert "table" in sigs["query"]["required_params"]
        # optional params should NOT be in required
        assert "limit" not in sigs["query"]["required_params"]
        assert "limit" in sigs["query"]["params"]


# ---------------------------------------------------------------------------
# Tests: Java signature parsing
# ---------------------------------------------------------------------------


class TestJavaSignatureParsing:
    """Tests for _parse_java_signatures — tree-sitter based Java extraction."""

    def test_class_with_methods(self):
        from codebrain.rewriter import _parse_java_signatures
        code = """
public class UserService {
    private final Database db;

    public UserService(Database db) {
        this.db = db;
    }

    public User findById(String id) {
        return db.find(id);
    }

    public void save(User user) {
        db.save(user);
    }
}
"""
        sigs = _parse_java_signatures(code)
        assert "UserService" in sigs
        info = sigs["UserService"]
        assert info["type"] == "class"
        assert info["init_params"] == ["db"]
        assert "findById" in info["methods"]
        assert info["methods"]["findById"]["params"] == ["id"]
        assert "save" in info["methods"]

    def test_class_extends_implements(self):
        from codebrain.rewriter import _parse_java_signatures
        code = "public class AdminService extends BaseService implements Auditable { }"
        sigs = _parse_java_signatures(code)
        assert "AdminService" in sigs
        bases = sigs["AdminService"]["bases"]
        assert "BaseService" in bases
        assert "Auditable" in bases

    def test_interface(self):
        from codebrain.rewriter import _parse_java_signatures
        code = """
public interface Repository {
    User findById(String id);
    void save(User user);
    List<User> findAll();
}
"""
        sigs = _parse_java_signatures(code)
        assert "Repository" in sigs
        info = sigs["Repository"]
        assert info["type"] == "class"
        assert "findById" in info["methods"]
        assert "save" in info["methods"]

    def test_enum_constants(self):
        from codebrain.rewriter import _parse_java_signatures
        code = """
public enum Status {
    ACTIVE,
    INACTIVE,
    PENDING;

    public String display() { return name().toLowerCase(); }
}
"""
        sigs = _parse_java_signatures(code)
        assert "Status" in sigs
        assert sigs["Status"]["type"] == "enum"
        assert set(sigs["Status"]["members"]) == {"ACTIVE", "INACTIVE", "PENDING"}

    def test_interface_extends(self):
        from codebrain.rewriter import _parse_java_signatures
        code = "public interface AdminRepo extends BaseRepo { void audit(String action); }"
        sigs = _parse_java_signatures(code)
        assert "AdminRepo" in sigs
        assert "BaseRepo" in sigs["AdminRepo"]["bases"]


# ---------------------------------------------------------------------------
# Tests: Cross-language deep validation (JS/TS)
# ---------------------------------------------------------------------------


class TestJSDeepValidation:
    """Tests for deep structural validation on JS/TS rewrites."""

    def test_js_removed_param_is_error(self):
        spec = {
            "file_path": "service.ts",
            "symbols": [
                {"name": "fetchUser", "type": "function", "is_exported": True,
                 "external_caller_count": 3},
            ],
        }
        old = "export function fetchUser(id: string, options: RequestOptions) { }"
        new = "export function fetchUser(id: string) { }"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("options" in e for e in result.errors)

    def test_js_added_optional_param_ok(self):
        spec = {
            "file_path": "service.ts",
            "symbols": [
                {"name": "fetchUser", "type": "function", "is_exported": True},
            ],
        }
        old = "export function fetchUser(id: string) { }"
        new = "export function fetchUser(id: string, cache?: boolean) { }"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid

    def test_js_class_constructor_changed(self):
        spec = {
            "file_path": "store.ts",
            "symbols": [
                {"name": "DataStore", "type": "class", "is_exported": True,
                 "external_caller_count": 5},
            ],
        }
        old = "export class DataStore { constructor(dbPath: string, logger: Logger) {} }"
        new = "export class DataStore { constructor(dbPath: string) {} }"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("logger" in e for e in result.errors)

    def test_js_enum_member_removed(self):
        spec = {
            "file_path": "types.ts",
            "symbols": [
                {"name": "Role", "type": "enum", "is_exported": True},
            ],
        }
        old = "export enum Role { Admin = 'admin', User = 'user', Guest = 'guest' }"
        new = "export enum Role { Admin = 'admin', User = 'user' }"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("Guest" in e for e in result.errors)

    def test_js_class_hierarchy_changed(self):
        spec = {
            "file_path": "component.tsx",
            "symbols": [
                {"name": "Modal", "type": "class", "is_exported": True},
            ],
        }
        old = "export class Modal extends BaseComponent { render() {} }"
        new = "export class Modal { render() {} }"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid  # hierarchy change is warning
        assert any("BaseComponent" in w for w in result.warnings)

    def test_js_method_removed_is_warning(self):
        spec = {
            "file_path": "api.ts",
            "symbols": [
                {"name": "ApiClient", "type": "class", "is_exported": True},
            ],
        }
        old = "export class ApiClient { get(url: string) {} post(url: string, data: any) {} delete(url: string) {} }"
        new = "export class ApiClient { get(url: string) {} post(url: string, data: any) {} }"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid  # method removal = warning
        assert any("delete" in w for w in result.warnings)

    def test_js_missing_exported_symbol(self):
        spec = {
            "file_path": "utils.ts",
            "symbols": [
                {"name": "formatDate", "type": "function", "is_exported": True},
                {"name": "parseDate", "type": "function", "is_exported": True},
            ],
        }
        new = "export function formatDate(d: Date) { return d.toISOString(); }"
        result = validate_rewrite(spec, new, old_source="")
        assert not result.valid
        assert any("parseDate" in e for e in result.errors)


# ---------------------------------------------------------------------------
# Tests: Cross-language deep validation (Java)
# ---------------------------------------------------------------------------


class TestJavaDeepValidation:
    """Tests for deep structural validation on Java rewrites."""

    def test_java_removed_method_param(self):
        spec = {
            "file_path": "UserService.java",
            "symbols": [
                {"name": "UserService", "type": "class", "is_exported": True},
            ],
        }
        old = """
public class UserService {
    public User findById(String id, boolean eager) { return null; }
}
"""
        new = """
public class UserService {
    public User findById(String id) { return null; }
}
"""
        result = validate_rewrite(spec, new, old_source=old)
        # Method param removal is a warning
        assert any("eager" in w for w in result.warnings)

    def test_java_constructor_param_removed(self):
        spec = {
            "file_path": "Service.java",
            "symbols": [
                {"name": "Service", "type": "class", "is_exported": True,
                 "external_caller_count": 10},
            ],
        }
        old = "public class Service { public Service(Database db, Logger log) {} }"
        new = "public class Service { public Service(Database db) {} }"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("log" in e for e in result.errors)

    def test_java_enum_member_removed(self):
        spec = {
            "file_path": "Status.java",
            "symbols": [
                {"name": "Status", "type": "enum", "is_exported": True},
            ],
        }
        old = "public enum Status { ACTIVE, INACTIVE, PENDING; }"
        new = "public enum Status { ACTIVE, INACTIVE; }"
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("PENDING" in e for e in result.errors)

    def test_java_interface_hierarchy_changed(self):
        spec = {
            "file_path": "AdminRepo.java",
            "symbols": [
                {"name": "AdminRepo", "type": "class", "is_exported": True},
            ],
        }
        old = "public interface AdminRepo extends BaseRepo { void audit(String action); }"
        new = "public interface AdminRepo { void audit(String action); }"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid  # warning
        assert any("BaseRepo" in w for w in result.warnings)

    def test_java_valid_rewrite_passes(self):
        spec = {
            "file_path": "Calculator.java",
            "symbols": [
                {"name": "Calculator", "type": "class", "is_exported": True},
            ],
        }
        old = "public class Calculator { public int add(int a, int b) { return a + b; } }"
        new = "public class Calculator { public int add(int a, int b) { return a + b; } public int subtract(int a, int b) { return a - b; } }"
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid
        assert len(result.errors) == 0


# ---------------------------------------------------------------------------
# Tests: M33 — DB/Infra rewrite integration
# ---------------------------------------------------------------------------


class TestDBPromptIntegration:
    """System/per-module prompt includes DB context."""

    def test_system_prompt_includes_db_technology(self):
        from codebrain.rewriter import _build_system_prompt
        prompt = _build_system_prompt("Python 3.12", "", db_technology="sqlalchemy")
        assert "sqlalchemy" in prompt
        assert "__tablename__" in prompt

    def test_system_prompt_no_db_when_empty(self):
        from codebrain.rewriter import _build_system_prompt
        prompt = _build_system_prompt("Python 3.12", "")
        assert "__tablename__" not in prompt
        assert "Database:" not in prompt

    def test_system_prompt_db_with_guidelines(self):
        from codebrain.rewriter import _build_system_prompt
        prompt = _build_system_prompt("Python 3.12", "Use type hints", db_technology="django_orm")
        assert "django_orm" in prompt
        assert "Use type hints" in prompt


class TestORMValidation:
    """ORM validation in Python rewrites."""

    def test_tablename_removal_is_error(self):
        spec = {
            "file_path": "models.py",
            "symbols": [
                {"name": "User", "type": "class", "is_exported": True,
                 "decorators": ["orm_model", "sqlalchemy"]},
            ],
        }
        old = '''
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
'''
        new = '''
class User(Base):
    id = Column(Integer, primary_key=True)
'''
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("users" in e for e in result.errors)

    def test_orm_base_class_preserved_passes(self):
        spec = {
            "file_path": "models.py",
            "symbols": [
                {"name": "User", "type": "class", "is_exported": True,
                 "decorators": ["orm_model", "sqlalchemy"]},
            ],
        }
        old = '''
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
'''
        new = '''
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(255))
'''
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid

    def test_foreignkey_removal_is_warning(self):
        spec = {
            "file_path": "models.py",
            "symbols": [
                {"name": "Order", "type": "class", "is_exported": True,
                 "decorators": ["orm_model", "sqlalchemy"]},
            ],
        }
        old = '''
class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
'''
        new = '''
class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
'''
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid  # warning only
        assert any("ForeignKey" in w for w in result.warnings)


class TestJPAValidation:
    """JPA entity validation in Java rewrites."""

    def test_entity_annotation_removed_is_error(self):
        spec = {
            "file_path": "User.java",
            "symbols": [
                {"name": "User", "type": "class", "is_exported": True,
                 "decorators": ["Entity"]},
            ],
        }
        old = '@Entity\n@Table(name = "users")\npublic class User { private Long id; }'
        new = 'public class User { private Long id; }'
        result = validate_rewrite(spec, new, old_source=old)
        assert not result.valid
        assert any("@Entity" in e for e in result.errors)

    def test_jpa_relationship_removed_is_warning(self):
        spec = {
            "file_path": "User.java",
            "symbols": [
                {"name": "User", "type": "class", "is_exported": True,
                 "decorators": ["Entity"]},
            ],
        }
        old = '@Entity\npublic class User { @OneToMany private List<Order> orders; }'
        new = '@Entity\npublic class User { private List<Order> orders; }'
        result = validate_rewrite(spec, new, old_source=old)
        assert result.valid  # warning only
        assert any("@OneToMany" in w for w in result.warnings)
