"""Tests for the Go tree-sitter parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.go_parser import GoParser, _GO_AVAILABLE

pytestmark = pytest.mark.skipif(not _GO_AVAILABLE, reason="tree-sitter-languages not installed")


@pytest.fixture
def parser():
    return GoParser()


@pytest.fixture
def go_project(tmp_path: Path) -> Path:
    """Create a small Go project for testing."""
    pkg = tmp_path / "pkg" / "server"
    pkg.mkdir(parents=True)

    (pkg / "server.go").write_text("""\
package server

import (
	"fmt"
	"net/http"
	"encoding/json"
)

// Server handles HTTP requests.
// It manages routing and middleware.
type Server struct {
	BaseHandler
	router *Router
	Port   int
	Name   string
}

// Router manages URL routing.
type Router struct {
	routes map[string]http.HandlerFunc
}

// NewServer creates a new Server instance.
func NewServer(port int, name string) *Server {
	r := NewRouter()
	return &Server{Port: port, Name: name, router: r}
}

// Handle registers a route and starts listening.
func (s *Server) Handle(path string, handler http.HandlerFunc) {
	s.router.Register(path, handler)
	Validate(path)
}

// Start begins listening on the configured port.
func (s *Server) Start() error {
	addr := fmt.Sprintf(":%d", s.Port)
	return http.ListenAndServe(addr, nil)
}

func (s *Server) internal() {
	// unexported method
}

// Register adds a route to the router.
func (r *Router) Register(path string, handler http.HandlerFunc) {
	r.routes[path] = handler
}

// Validate checks that a path is valid.
func Validate(path string) bool {
	return len(path) > 0
}

// init sets up default configuration.
func init() {
	SetupDefaults()
}
""")

    (pkg / "handler.go").write_text("""\
package server

import "net/http"

// BaseHandler provides common handler functionality.
type BaseHandler struct {
	Logger LoggerInterface
}

// LoggerInterface defines logging methods.
type LoggerInterface interface {
	Log(msg string)
	Error(msg string, err error)
}

// ServeHTTP implements the http.Handler interface.
func (b *BaseHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	b.Logger.Log("request received")
}
""")

    (pkg / "config.go").write_text("""\
package server

// MaxConnections is the maximum number of connections.
const MaxConnections = 100

// DefaultPort is the default listening port.
const DefaultPort int = 8080

const (
	// StatusOK indicates success.
	StatusOK = 200
	StatusNotFound = 404
)

// Version is the current server version.
var Version string = "1.0.0"

var (
	Debug   bool
	Timeout int
)

// ID is a type alias for string identifiers.
type ID string

// HandlerFunc is a function type for request handlers.
type HandlerFunc func(w ResponseWriter, r *Request) error
""")

    main = tmp_path / "cmd"
    main.mkdir(parents=True)

    (main / "main.go").write_text("""\
package main

import (
	"fmt"
	"pkg/server"
)

func main() {
	srv := server.NewServer(8080, "myapp")
	srv.Handle("/api", apiHandler)
	srv.Start()
}

func apiHandler(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
}
""")

    return tmp_path


class TestBasicParsing:
    """Test basic Go symbol extraction."""

    def test_parses_go_file(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        assert result.path.endswith("server.go")
        assert result.line_count > 0

    def test_finds_package(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        file_node = [n for n in result.nodes if n.type == "file"]
        assert len(file_node) == 1
        assert "package server" in file_node[0].docstring

    def test_finds_function(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        funcs = [n for n in result.nodes if n.type == "function"]
        func_names = {f.name for f in funcs}
        assert "NewServer" in func_names
        assert "Validate" in func_names
        assert "init" in func_names

    def test_finds_struct(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        structs = [n for n in result.nodes if n.type == "class"
                   and "interface" not in n.decorators]
        names = {s.name for s in structs}
        assert "Server" in names
        assert "Router" in names

    def test_finds_interface(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/handler.go"
        result = parser.parse(path, go_project)
        ifaces = [n for n in result.nodes if "interface" in n.decorators]
        assert any(n.name == "LoggerInterface" for n in ifaces)

    def test_finds_method_with_receiver(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        methods = [n for n in result.nodes if n.type == "method"]
        method_names = {m.name for m in methods}
        assert "Handle" in method_names
        assert "Start" in method_names
        assert "Register" in method_names

    def test_finds_constants(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/config.go"
        result = parser.parse(path, go_project)
        consts = [n for n in result.nodes if n.type == "variable"
                  and "const" in n.decorators]
        names = {c.name for c in consts}
        assert "MaxConnections" in names
        assert "DefaultPort" in names
        assert "StatusOK" in names
        assert "StatusNotFound" in names

    def test_finds_variables(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/config.go"
        result = parser.parse(path, go_project)
        variables = [n for n in result.nodes if n.type == "variable"
                     and "const" not in n.decorators
                     and n.name not in ("ID", "HandlerFunc")]
        names = {v.name for v in variables}
        assert "Version" in names
        assert "Debug" in names
        assert "Timeout" in names

    def test_multiple_return_values(self, parser: GoParser, go_project: Path):
        """Functions with multiple return values should show them in the signature."""
        src = go_project / "pkg/server"
        (src / "multi.go").write_text("""\
package server

func Divide(a, b float64) (float64, error) {
	if b == 0 {
		return 0, nil
	}
	return a / b, nil
}
""")
        result = parser.parse(src / "multi.go", go_project)
        divide = [n for n in result.nodes if n.name == "Divide"]
        assert len(divide) == 1
        assert "float64" in divide[0].signature


class TestRelationships:
    """Test edge extraction (CALLS, IMPORTS, EXTENDS, CONTAINS)."""

    def test_imports(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        targets = {e.target for e in imports}
        assert "net/http" in targets
        assert "encoding/json" in targets

    def test_function_calls(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert "NewRouter" in targets
        assert "Validate" in targets

    def test_method_calls(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        # s.router.Register -> should find Register
        assert "Register" in targets or any("Register" in t for t in targets)

    def test_struct_embedding_extends(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        extends = [e for e in result.edges if e.type == "EXTENDS"]
        targets = {e.target for e in extends}
        assert "BaseHandler" in targets

    def test_contains_edges(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        contains = [e for e in result.edges if e.type == "CONTAINS"]
        # File contains structs, functions; structs contain fields
        assert len(contains) > 5

    def test_interface_methods(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/handler.go"
        result = parser.parse(path, go_project)
        methods = [n for n in result.nodes if n.type == "method"
                   and n.qualified_name.startswith("LoggerInterface.")]
        names = {m.name for m in methods}
        assert "Log" in names
        assert "Error" in names

    def test_calls_skip_noise(self, parser: GoParser, go_project: Path):
        """Builtin calls like fmt.Sprintf, len, append should be skipped."""
        src = go_project / "pkg/server"
        (src / "noise.go").write_text("""\
package server

import "fmt"

func NoisyFunc() {
	x := make([]int, 10)
	x = append(x, 1)
	n := len(x)
	fmt.Println(n)
	close(make(chan int))
	DoReal()
}
""")
        result = parser.parse(src / "noise.go", go_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert "DoReal" in targets
        assert "make" not in targets
        assert "append" not in targets
        assert "len" not in targets
        assert "fmt.Println" not in targets


class TestMetadata:
    """Test exported detection, doc comments, signatures."""

    def test_exported_detection(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        # NewServer is exported (uppercase)
        new_server = [n for n in result.nodes if n.name == "NewServer"]
        assert len(new_server) == 1
        assert new_server[0].is_exported is True

        # internal is unexported (lowercase)
        internal = [n for n in result.nodes if n.name == "internal"]
        assert len(internal) == 1
        assert internal[0].is_exported is False

    def test_doc_comments(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        server_struct = [n for n in result.nodes if n.name == "Server" and n.type == "class"]
        assert len(server_struct) == 1
        assert "handles http requests" in server_struct[0].docstring.lower()

    def test_init_function(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        init_funcs = [n for n in result.nodes if n.name == "init"]
        assert len(init_funcs) == 1
        assert init_funcs[0].type == "function"

    def test_type_alias(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/config.go"
        result = parser.parse(path, go_project)
        id_type = [n for n in result.nodes if n.name == "ID"]
        assert len(id_type) == 1
        assert "type ID" in id_type[0].signature

    def test_multiple_var_declaration(self, parser: GoParser, go_project: Path):
        """var blocks with multiple vars should all be extracted."""
        path = go_project / "pkg/server/config.go"
        result = parser.parse(path, go_project)
        names = {n.name for n in result.nodes}
        assert "Debug" in names
        assert "Timeout" in names

    def test_method_receiver_in_signature(self, parser: GoParser, go_project: Path):
        path = go_project / "pkg/server/server.go"
        result = parser.parse(path, go_project)
        handle = [n for n in result.nodes if n.name == "Handle" and n.type == "method"]
        assert len(handle) == 1
        # Signature should include receiver
        assert "Server" in handle[0].signature or "*Server" in handle[0].signature

    def test_extensions(self, parser: GoParser):
        assert ".go" in parser.extensions()


class TestIndexIntegration:
    """Test that Go files work with the full indexing pipeline."""

    def test_index_go_project(self, go_project: Path):
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index

        result = full_index(go_project)
        assert result["errors"] == []
        assert result["files_parsed"] == 4

        db = go_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            stats = store.get_stats()
            assert stats["nodes"] > 10
            assert stats["edges"] > 10
            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            results = engine.search_nodes("Server")
            assert any(r["name"] == "Server" for r in results)

    def test_impact_analysis_go(self, go_project: Path):
        """Impact analysis should work on Go symbols."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.graph.query import QueryEngine
        from codebrain.indexer import full_index

        full_index(go_project)
        db = go_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)
            results = engine.search_nodes("BaseHandler")
            assert len(results) > 0

    def test_kt_document_go(self, go_project: Path):
        """KT document generation should work on Go codebases."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index
        from codebrain.kt import KTGenerator

        full_index(go_project)
        db = go_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            gen = KTGenerator(store)
            doc = gen.generate(project_name="GoTestProject")
            assert "# GoTestProject" in doc
            assert "## Architecture Overview" in doc
            assert "```mermaid" in doc
