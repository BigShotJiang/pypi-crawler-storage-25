"""Tests for git hook integration and hook_runner validation."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.hooks import install_hook, uninstall_hook


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """Create a fake git repo structure."""
    git_dir = tmp_path / ".git" / "hooks"
    git_dir.mkdir(parents=True)
    return tmp_path


class TestInstallHook:
    def test_install_creates_hook(self, git_repo: Path) -> None:
        result = install_hook(git_repo)
        assert "Installed" in result
        hook = git_repo / ".git" / "hooks" / "pre-commit"
        assert hook.exists()
        assert "codebrain" in hook.read_text().lower()

    def test_install_twice_is_idempotent(self, git_repo: Path) -> None:
        install_hook(git_repo)
        result = install_hook(git_repo)
        assert "already installed" in result.lower()

    def test_install_chains_existing_hook(self, git_repo: Path) -> None:
        hook = git_repo / ".git" / "hooks" / "pre-commit"
        hook.write_text("#!/bin/sh\necho existing\n")
        install_hook(git_repo)
        backup = git_repo / ".git" / "hooks" / "pre-commit.backup"
        assert backup.exists()

    def test_install_not_git_repo(self, tmp_path: Path) -> None:
        result = install_hook(tmp_path)
        assert "not a git repository" in result.lower()


class TestUninstallHook:
    def test_uninstall(self, git_repo: Path) -> None:
        install_hook(git_repo)
        result = uninstall_hook(git_repo)
        assert "Removed" in result
        hook = git_repo / ".git" / "hooks" / "pre-commit"
        assert not hook.exists()

    def test_uninstall_restores_backup(self, git_repo: Path) -> None:
        hook = git_repo / ".git" / "hooks" / "pre-commit"
        hook.write_text("#!/bin/sh\necho original\n")
        install_hook(git_repo)
        uninstall_hook(git_repo)
        assert hook.exists()
        assert "original" in hook.read_text()

    def test_uninstall_no_hook(self, git_repo: Path) -> None:
        result = uninstall_hook(git_repo)
        assert "No pre-commit hook" in result


@pytest.fixture
def indexed_repo(tmp_path):
    """Create a real git repo with indexed codebase for hook_runner tests."""
    root = tmp_path / "repo"
    root.mkdir()
    pkg = root / "mypkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "core.py").write_text(
        "def greet(name):\n    return f'hello {name}'\n",
        encoding="utf-8",
    )
    (pkg / "cli.py").write_text(
        "from mypkg.core import greet\n\ndef main():\n    print(greet('world'))\n",
        encoding="utf-8",
    )

    subprocess.run(["git", "init", "-b", "main"], cwd=str(root), capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(root), capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=str(root), capture_output=True)
    subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
    subprocess.run(["git", "commit", "-m", "initial"], cwd=str(root), capture_output=True)

    from codebrain.indexer import full_index
    db_path = root / CODEBRAIN_DIR / DB_FILENAME
    db_path.parent.mkdir(parents=True, exist_ok=True)
    full_index(root, db_path)

    return root


class TestHookRunner:

    def test_safe_change_exits_0(self, indexed_repo):
        from codebrain.hook_runner import main

        core = indexed_repo / "mypkg" / "core.py"
        content = core.read_text(encoding="utf-8")
        core.write_text(content + "\ndef helper():\n    pass\n", encoding="utf-8")

        old_argv, old_cwd = sys.argv, Path.cwd()
        try:
            os.chdir(indexed_repo)
            sys.argv = ["hook_runner", "mypkg/core.py"]
            assert main() == 0
        finally:
            os.chdir(old_cwd)
            sys.argv = old_argv

    def test_breaking_change_exits_1(self, indexed_repo):
        from codebrain.hook_runner import main

        core = indexed_repo / "mypkg" / "core.py"
        core.write_text("def farewell():\n    return 'bye'\n", encoding="utf-8")

        old_argv, old_cwd = sys.argv, Path.cwd()
        try:
            os.chdir(indexed_repo)
            sys.argv = ["hook_runner", "mypkg/core.py"]
            assert main() == 1
        finally:
            os.chdir(old_cwd)
            sys.argv = old_argv

    def test_no_files_exits_0(self):
        from codebrain.hook_runner import main

        old_argv = sys.argv
        try:
            sys.argv = ["hook_runner"]
            assert main() == 0
        finally:
            sys.argv = old_argv


class TestPreToolUseHook:
    """Claude Code PreToolUse — intercept risky edits BEFORE they happen."""

    def test_safe_edit_allowed(self, indexed_repo):
        import json as _json
        from codebrain.hook_runner import pretooluse

        old_cwd = Path.cwd()
        try:
            os.chdir(indexed_repo)
            # Appending a helper — no contracts broken.
            new_content = (
                "def greet(name):\n    return f'hello {name}'\n\n"
                "def helper():\n    pass\n"
            )
            event = _json.dumps({
                "tool_name": "Write",
                "tool_input": {
                    "file_path": "mypkg/core.py",
                    "content": new_content,
                },
            })
            assert pretooluse(event) == 0
        finally:
            os.chdir(old_cwd)

    def test_breaking_edit_blocked(self, indexed_repo):
        import json as _json
        from codebrain.hook_runner import pretooluse

        old_cwd = Path.cwd()
        try:
            os.chdir(indexed_repo)
            # Gutting the module removes `greet`, which mypkg/cli.py calls.
            event = _json.dumps({
                "tool_name": "Write",
                "tool_input": {
                    "file_path": "mypkg/core.py",
                    "content": "def unrelated():\n    pass\n",
                },
            })
            assert pretooluse(event) == 2
        finally:
            os.chdir(old_cwd)

    def test_non_mutating_tool_is_passthrough(self, indexed_repo):
        import json as _json
        from codebrain.hook_runner import pretooluse

        event = _json.dumps({
            "tool_name": "Read",
            "tool_input": {"file_path": str(indexed_repo / "mypkg" / "core.py")},
        })
        assert pretooluse(event) == 0

    def test_non_python_file_is_passthrough(self, indexed_repo):
        import json as _json
        from codebrain.hook_runner import pretooluse

        event = _json.dumps({
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(indexed_repo / "README.md"),
                "content": "# anything",
            },
        })
        assert pretooluse(event) == 0

    def test_bypass_env_var(self, indexed_repo, monkeypatch):
        """CODEBRAIN_SKIP_HOOK=1 must disarm the hook entirely."""
        from codebrain.hook_runner import dispatch
        import io

        monkeypatch.setenv("CODEBRAIN_SKIP_HOOK", "1")
        monkeypatch.setattr(sys, "stdin", io.StringIO('{"tool_name":"Write",'
            '"tool_input":{"file_path":"mypkg/core.py","content":"x"}}'))
        monkeypatch.setattr(sys, "argv", ["hook_runner", "--pretooluse"])

        old_cwd = Path.cwd()
        try:
            os.chdir(indexed_repo)
            assert dispatch() == 0
        finally:
            os.chdir(old_cwd)

    def test_malformed_input_is_passthrough(self):
        from codebrain.hook_runner import pretooluse
        # Defensive: never block on parse failure.
        assert pretooluse("not json") == 0
        assert pretooluse("") == 0
        assert pretooluse("{}") == 0


class TestClaudeHookInstall:
    """`brain hook install-claude` writes a valid PreToolUse entry."""

    def test_install_creates_claude_hook(self, tmp_path):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(
            cli, ["--repo", str(tmp_path), "hook", "install-claude"],
        )
        assert result.exit_code == 0, result.output

        import json as _json
        settings = _json.loads(
            (tmp_path / ".claude" / "settings.local.json").read_text(encoding="utf-8"),
        )
        pretool = settings["hooks"]["PreToolUse"]
        assert len(pretool) == 1
        assert pretool[0]["matcher"] == "Edit|Write|MultiEdit"
        assert "hook_runner" in pretool[0]["hooks"][0]["command"]

    def test_install_is_idempotent(self, tmp_path):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        runner.invoke(cli, ["--repo", str(tmp_path), "hook", "install-claude"])
        runner.invoke(cli, ["--repo", str(tmp_path), "hook", "install-claude"])

        import json as _json
        settings = _json.loads(
            (tmp_path / ".claude" / "settings.local.json").read_text(encoding="utf-8"),
        )
        # Second install should replace the prior entry, not duplicate it.
        assert len(settings["hooks"]["PreToolUse"]) == 1

    def test_install_preserves_other_settings(self, tmp_path):
        import json as _json
        from click.testing import CliRunner
        from codebrain.cli import cli

        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "settings.local.json").write_text(
            _json.dumps({"permissions": {"allow": ["Bash(ls:*)"]}}),
            encoding="utf-8",
        )

        runner = CliRunner()
        runner.invoke(cli, ["--repo", str(tmp_path), "hook", "install-claude"])

        settings = _json.loads(
            (tmp_path / ".claude" / "settings.local.json").read_text(encoding="utf-8"),
        )
        assert settings["permissions"]["allow"] == ["Bash(ls:*)"]
        assert "PreToolUse" in settings["hooks"]

    def test_uninstall_removes_hook_only(self, tmp_path):
        import json as _json
        from click.testing import CliRunner
        from codebrain.cli import cli

        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "settings.local.json").write_text(
            _json.dumps({"permissions": {"allow": ["Bash(ls:*)"]}}),
            encoding="utf-8",
        )

        runner = CliRunner()
        runner.invoke(cli, ["--repo", str(tmp_path), "hook", "install-claude"])
        runner.invoke(cli, ["--repo", str(tmp_path), "hook", "uninstall-claude"])

        settings = _json.loads(
            (tmp_path / ".claude" / "settings.local.json").read_text(encoding="utf-8"),
        )
        assert settings["permissions"]["allow"] == ["Bash(ls:*)"]
        assert "hooks" not in settings or "PreToolUse" not in settings.get("hooks", {})
