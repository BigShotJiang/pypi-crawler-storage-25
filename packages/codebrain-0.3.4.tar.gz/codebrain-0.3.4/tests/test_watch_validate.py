"""M7: Watch mode validates on save.

Tests that the watcher validates changed files after re-indexing.
"""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index


@pytest.fixture
def watch_project(tmp_path):
    """Create a small project and index it."""
    root = tmp_path / "proj"
    root.mkdir()
    pkg = root / "mypkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "core.py").write_text(
        "def greet(name):\n    return f'hello {name}'\n",
        encoding="utf-8",
    )
    (pkg / "cli.py").write_text(
        "from mypkg.core import greet\n\ndef main():\n    print(greet('world'))\n",
        encoding="utf-8",
    )

    db_path = root / ".codebrain" / "codebrain.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    full_index(root, db_path)
    return root, db_path


class TestWatcherValidation:

    def test_validate_changed_detects_breakage(self, watch_project):
        """Watcher's _validate_changed detects structural breakage."""
        from codebrain.watcher.file_watcher import _DebouncedHandler

        root, db_path = watch_project
        with GraphStore(db_path) as store:
            handler = _DebouncedHandler(root, store, debounce=0.1)

            # Break core.py by removing greet
            core_py = root / "mypkg" / "core.py"
            core_py.write_text("def farewell():\n    return 'bye'\n", encoding="utf-8")

            # Validate BEFORE re-indexing (graph still has old state)
            handler._validate_changed([core_py])

            # Should have a validation result
            validations = handler.get_recent_validations()
            assert "mypkg/core.py" in validations
            report = validations["mypkg/core.py"]
            assert not report["is_valid"], "Removing greet should be UNSAFE"

    def test_validate_changed_safe_change(self, watch_project):
        """Watcher's _validate_changed passes safe changes."""
        from codebrain.watcher.file_watcher import _DebouncedHandler

        root, db_path = watch_project
        with GraphStore(db_path) as store:
            handler = _DebouncedHandler(root, store, debounce=0.1)

            # Add a new function (safe change)
            core_py = root / "mypkg" / "core.py"
            content = core_py.read_text(encoding="utf-8")
            core_py.write_text(content + "\ndef helper():\n    pass\n", encoding="utf-8")

            # Validate before re-indexing (graph still has old state)
            handler._validate_changed([core_py])

            validations = handler.get_recent_validations()
            assert "mypkg/core.py" in validations
            report = validations["mypkg/core.py"]
            assert report["is_valid"], "Adding function should be SAFE"

    def test_get_recent_validations_returns_dict(self, watch_project):
        """get_recent_validations returns a dict of file -> report."""
        from codebrain.watcher.file_watcher import _DebouncedHandler

        root, db_path = watch_project
        with GraphStore(db_path) as store:
            handler = _DebouncedHandler(root, store, debounce=0.1)
            result = handler.get_recent_validations()
            assert isinstance(result, dict)
            assert len(result) == 0  # No validations yet

    def test_start_watching_background_returns_handler(self, watch_project):
        """start_watching_background returns handler for polling."""
        from codebrain.watcher.file_watcher import start_watching_background

        root, db_path = watch_project
        observer, store, handler = start_watching_background(root, db_path)
        try:
            assert handler is not None
            assert hasattr(handler, "get_recent_validations")
        finally:
            observer.stop()
            observer.join()
            store.close()
