"""Tests for multi-project CLI support (--project flag and --discover)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from codebrain.cli import cli
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME


@pytest.fixture
def two_projects(tmp_path):
    """Create two indexed projects: alpha and beta."""
    from codebrain.indexer import full_index

    alpha = tmp_path / "alpha"
    alpha.mkdir()
    pkg_a = alpha / "mypkg"
    pkg_a.mkdir()
    (pkg_a / "__init__.py").write_text("")
    (pkg_a / "core.py").write_text(
        'def hello():\n    """Greet the world."""\n    return "hello"\n'
    )
    full_index(alpha)

    beta = tmp_path / "beta"
    beta.mkdir()
    pkg_b = beta / "mypkg"
    pkg_b.mkdir()
    (pkg_b / "__init__.py").write_text("")
    (pkg_b / "core.py").write_text(
        'class GraphStore:\n    """A store for graphs."""\n    pass\n'
    )
    full_index(beta)

    return alpha, beta


class TestProjectOption:
    """Test --project flag on individual CLI commands."""

    def test_status_with_project_alpha(self, two_projects):
        alpha, beta = two_projects
        runner = CliRunner()
        result = runner.invoke(cli, ["--project", str(alpha), "status"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "nodes" in result.output or "files" in result.output

    def test_status_with_project_beta(self, two_projects):
        alpha, beta = two_projects
        runner = CliRunner()
        result = runner.invoke(cli, ["--project", str(beta), "status"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "nodes" in result.output or "files" in result.output

    def test_search_with_project_alpha(self, two_projects):
        alpha, beta = two_projects
        runner = CliRunner()
        result = runner.invoke(cli, ["--project", str(alpha), "search", "hello"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "hello" in result.output

    def test_search_with_project_beta(self, two_projects):
        alpha, beta = two_projects
        runner = CliRunner()
        result = runner.invoke(cli, ["--project", str(beta), "search", "GraphStore"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "GraphStore" in result.output

    def test_no_cross_contamination(self, two_projects):
        """Searching for alpha's symbol in beta should find nothing."""
        alpha, beta = two_projects
        runner = CliRunner()
        result = runner.invoke(cli, ["--project", str(beta), "search", "hello"], catch_exceptions=False)
        assert result.exit_code == 0
        assert "No results" in result.output

    def test_project_overrides_repo(self, two_projects):
        """--project takes precedence over --repo."""
        alpha, beta = two_projects
        runner = CliRunner()
        # --repo points to alpha but --project points to beta
        result = runner.invoke(
            cli, ["--repo", str(alpha), "--project", str(beta), "search", "GraphStore"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0
        assert "GraphStore" in result.output

    def test_project_nonexistent_path(self, tmp_path):
        """--project with a nonexistent path should fail."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--project", str(tmp_path / "nope"), "status"])
        assert result.exit_code != 0


class TestDiscover:
    """Test --discover flag on brain serve."""

    def test_discover_finds_sibling_directories(self, two_projects):
        """--discover finds sibling projects with .codebrain databases."""
        alpha, beta = two_projects
        runner = CliRunner()
        # Run serve with --discover but we can't actually start the server,
        # so we test by importing and calling the discovery logic directly.
        # Instead, let's invoke serve and let it fail on uvicorn import gracefully
        # or test the output before server start.

        # We'll test the discover logic by checking the output includes discovered projects.
        # Since serve needs uvicorn, we mock the actual server start.
        from unittest.mock import patch

        with patch("codebrain.cli.sys.exit") as mock_exit:
            # If uvicorn is available, it will try to start the server.
            # We need to handle both cases.
            try:
                import uvicorn  # noqa: F401
                has_uvicorn = True
            except ImportError:
                has_uvicorn = False

            if has_uvicorn:
                with patch("uvicorn.run"):
                    result = runner.invoke(
                        cli,
                        ["--project", str(alpha), "serve", "--discover"],
                        catch_exceptions=False,
                    )
                    assert result.exit_code == 0
                    assert "discovered" in result.output
                    assert "beta" in result.output
            else:
                # Without uvicorn, serve exits with error. Just verify discovery output.
                result = runner.invoke(
                    cli,
                    ["--project", str(alpha), "serve", "--discover"],
                )
                # The command will fail but discovery messages appear before failure
                assert "discovered" in result.output or "uvicorn" in result.output.lower()

    def test_discover_skips_non_indexed(self, tmp_path):
        """--discover skips sibling directories without .codebrain databases."""
        from codebrain.indexer import full_index

        alpha = tmp_path / "alpha"
        alpha.mkdir()
        pkg_a = alpha / "mypkg"
        pkg_a.mkdir()
        (pkg_a / "__init__.py").write_text("")
        (pkg_a / "core.py").write_text("def hello(): pass\n")
        full_index(alpha)

        # gamma has no .codebrain - should be skipped
        gamma = tmp_path / "gamma"
        gamma.mkdir()
        (gamma / "main.py").write_text("x = 1\n")

        try:
            import uvicorn  # noqa: F401
            has_uvicorn = True
        except ImportError:
            has_uvicorn = False

        runner = CliRunner()
        if has_uvicorn:
            from unittest.mock import patch
            with patch("uvicorn.run"):
                result = runner.invoke(
                    cli,
                    ["--project", str(alpha), "serve", "--discover"],
                    catch_exceptions=False,
                )
                # gamma should NOT appear in discovered
                assert "gamma" not in result.output
        else:
            result = runner.invoke(
                cli,
                ["--project", str(alpha), "serve", "--discover"],
            )
            assert "gamma" not in result.output
