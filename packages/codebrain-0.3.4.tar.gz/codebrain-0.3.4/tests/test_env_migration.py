"""Tests for M37 — Environment Migration."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from codebrain.env_migration import (
    Dependency,
    EnvironmentMigrator,
    EnvironmentProfile,
    GeneratedFile,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_python_project(tmp_path: Path) -> Path:
    """Create a synthetic Python project with typical infra files."""
    proj = tmp_path / "myapp"
    proj.mkdir()
    (proj / "requirements.txt").write_text(
        "flask==2.3.0\nrequests>=2.28\nsqlalchemy\ncelery~=5.3\ngunicorn\n",
        encoding="utf-8",
    )
    (proj / "Dockerfile").write_text(
        "FROM python:3.11-slim\nWORKDIR /app\nCOPY . .\n"
        "RUN pip install -r requirements.txt\nEXPOSE 5000\nCMD [\"gunicorn\", \"app:app\"]\n",
        encoding="utf-8",
    )
    wf_dir = proj / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "ci.yml").write_text(
        "name: CI\non:\n  push:\n    branches: [main]\njobs:\n"
        "  test:\n    runs-on: ubuntu-latest\n    steps:\n"
        "      - uses: actions/checkout@v4\n      - run: pytest\n",
        encoding="utf-8",
    )
    (proj / ".env").write_text(
        "DATABASE_URL=postgres://localhost/myapp\n"
        "SECRET_KEY=supersecret\n"
        "DEBUG=true\n",
        encoding="utf-8",
    )
    return proj


# ---------------------------------------------------------------------------
# Analyze tests
# ---------------------------------------------------------------------------

class TestAnalyze:
    def test_analyze_finds_requirements_txt(self, tmp_path: Path) -> None:
        proj = _make_python_project(tmp_path)
        migrator = EnvironmentMigrator()
        profile = migrator.analyze(proj)
        assert profile.language == "python"
        assert len(profile.dependencies) == 5
        names = [d.name for d in profile.dependencies]
        assert "flask" in names
        assert "requests" in names

    def test_analyze_finds_package_json(self, tmp_path: Path) -> None:
        proj = tmp_path / "jsapp"
        proj.mkdir()
        (proj / "package.json").write_text(json.dumps({
            "name": "jsapp",
            "dependencies": {"express": "^4.18.0", "pg": "^8.11.0"},
            "devDependencies": {"jest": "^29.0.0"},
        }), encoding="utf-8")
        migrator = EnvironmentMigrator()
        profile = migrator.analyze(proj)
        assert profile.language == "javascript"
        assert len(profile.dependencies) == 3
        dev_deps = [d for d in profile.dependencies if d.dev]
        assert len(dev_deps) == 1
        assert dev_deps[0].name == "jest"

    def test_analyze_finds_dockerfile(self, tmp_path: Path) -> None:
        proj = _make_python_project(tmp_path)
        migrator = EnvironmentMigrator()
        profile = migrator.analyze(proj)
        assert profile.has_dockerfile is True
        assert profile.dockerfile_port == 5000
        assert "python" in profile.dockerfile_base_image

    def test_analyze_finds_github_actions(self, tmp_path: Path) -> None:
        proj = _make_python_project(tmp_path)
        migrator = EnvironmentMigrator()
        profile = migrator.analyze(proj)
        assert profile.ci_platform == "github_actions"
        assert profile.ci_file == "ci.yml"

    def test_analyze_finds_env_file(self, tmp_path: Path) -> None:
        proj = _make_python_project(tmp_path)
        migrator = EnvironmentMigrator()
        profile = migrator.analyze(proj)
        assert len(profile.env_vars) == 3
        keys = [k for k, _ in profile.env_vars]
        assert "DATABASE_URL" in keys
        assert "SECRET_KEY" in keys
        assert "DEBUG" in keys

    def test_analyze_empty_project(self, tmp_path: Path) -> None:
        proj = tmp_path / "empty"
        proj.mkdir()
        migrator = EnvironmentMigrator()
        profile = migrator.analyze(proj)
        assert profile.language == ""
        assert profile.dependencies == []
        assert profile.env_vars == []
        assert profile.has_dockerfile is False
        assert profile.ci_platform == ""


# ---------------------------------------------------------------------------
# Generate tests
# ---------------------------------------------------------------------------

class TestGenerate:
    def _profile(self, port: int = 5000) -> EnvironmentProfile:
        return EnvironmentProfile(
            language="python",
            dependencies=[Dependency("flask", "2.3.0")],
            env_vars=[("DB_URL", "postgres://localhost/db"), ("SECRET", "abc")],
            has_dockerfile=True,
            dockerfile_base_image="python:3.11-slim",
            dockerfile_port=port,
            ci_platform="github_actions",
            ci_file="ci.yml",
        )

    def test_generate_dockerfile_go(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_dockerfile(self._profile(), "go")
        assert gf.path == "Dockerfile"
        assert "golang:1.21" in gf.content
        assert "EXPOSE 5000" in gf.content
        assert "CGO_ENABLED=0" in gf.content

    def test_generate_dockerfile_rust(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_dockerfile(self._profile(), "rust")
        assert "rust:1.75" in gf.content
        assert "cargo build --release" in gf.content
        assert "EXPOSE 5000" in gf.content

    def test_generate_dockerfile_java(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_dockerfile(self._profile(), "java")
        assert "eclipse-temurin:21" in gf.content
        assert "mvn package" in gf.content
        assert "EXPOSE 5000" in gf.content

    def test_generate_dockerfile_uses_original_port(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_dockerfile(self._profile(port=3000), "go")
        assert "EXPOSE 3000" in gf.content

    def test_generate_ci_github_actions_go(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_ci(self._profile(), "go")
        assert gf is not None
        assert gf.path == ".github/workflows/ci.yml"
        assert "go build" in gf.content
        assert "go test" in gf.content

    def test_generate_ci_github_actions_rust(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_ci(self._profile(), "rust")
        assert gf is not None
        assert "cargo build" in gf.content
        assert "cargo test" in gf.content

    def test_generate_env_copies_vars(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_env(self._profile())
        assert "DB_URL=postgres://localhost/db" in gf.content
        assert "SECRET=abc" in gf.content

    def test_generate_dep_file_go_mod(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_dep_file(self._profile(), "go")
        assert gf is not None
        assert gf.path == "go.mod"
        assert "module translated" in gf.content
        assert "TODO" in gf.content

    def test_generate_dep_file_cargo_toml(self) -> None:
        migrator = EnvironmentMigrator()
        gf = migrator._generate_dep_file(self._profile(), "rust")
        assert gf is not None
        assert gf.path == "Cargo.toml"
        assert 'name = "translated"' in gf.content
        assert "TODO" in gf.content

    def test_generate_writes_files(self, tmp_path: Path) -> None:
        migrator = EnvironmentMigrator()
        profile = self._profile()
        out = tmp_path / "output"
        files = migrator.generate(profile, "go", output_dir=out)
        assert len(files) >= 3  # dep file + Dockerfile + CI + .env
        assert (out / "go.mod").is_file()
        assert (out / "Dockerfile").is_file()
        assert (out / ".env").is_file()
        assert (out / ".github" / "workflows" / "ci.yml").is_file()


# ---------------------------------------------------------------------------
# CLI tests
# ---------------------------------------------------------------------------

class TestCLI:
    def test_cli_env_analyze(self, tmp_path: Path) -> None:
        """CLI env-analyze command exists and produces output."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        proj = _make_python_project(tmp_path)
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(proj), "env-analyze", "--json"])
        # Command should run without crashing; may fail on missing index or license
        out = result.output or ""
        assert result.exit_code == 0 or "not initialized" in out or "license" in out.lower()

    def test_cli_env_migrate(self, tmp_path: Path) -> None:
        """CLI env-migrate command exists and produces output."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        proj = _make_python_project(tmp_path)
        out = tmp_path / "out"
        runner = CliRunner()
        result = runner.invoke(cli, [
            "--repo", str(proj), "env-migrate",
            "-o", str(out), "--target-lang", "go",
        ])
        out_text = result.output or ""
        assert result.exit_code == 0 or "not initialized" in out_text or "license" in out_text.lower()
