"""Tests for the structural analyzer."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.analyzer import StructuralAnalyzer
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME


@pytest.fixture
def analyzer_project(simple_project: Path) -> tuple[Path, GraphStore, StructuralAnalyzer]:
    full_index(simple_project)
    db_path = simple_project / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db_path)
    analyzer = StructuralAnalyzer(store)
    return simple_project, store, analyzer


class TestCouplingAnalysis:
    def test_returns_pairs(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.coupling_analysis()
        assert "pairs" in result
        assert "file_ranking" in result
        assert isinstance(result["pairs"], list)
        store.close()

    def test_pair_has_score(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.coupling_analysis()
        if result["pairs"]:
            pair = result["pairs"][0]
            assert "coupling_score" in pair
            assert pair["coupling_score"] > 0
        store.close()


class TestCohesionAnalysis:
    def test_returns_per_file(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.cohesion_analysis()
        assert isinstance(result, list)
        if result:
            assert "file_path" in result[0]
            assert "cohesion_score" in result[0]
        store.close()


class TestContractDetection:
    def test_returns_list(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.detect_contracts()
        assert isinstance(result, list)
        store.close()

    def test_contract_has_type(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.detect_contracts()
        for c in result:
            assert "type" in c
            assert c["type"] in ("co_import", "co_call", "shared_interface")
            assert "message" in c
        store.close()


class TestStructuralPatterns:
    def test_returns_list(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.detect_structural_patterns()
        assert isinstance(result, list)
        store.close()

    def test_patterns_have_fields(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.detect_structural_patterns()
        for p in result:
            assert "type" in p
            assert p["type"] == "structural_group"
            assert "files" in p
            assert "shared_pattern" in p
            assert "similarity" in p
            assert isinstance(p["files"], list)
            assert len(p["files"]) >= 2
        store.close()

    def test_patterns_find_similar_modules(self, tmp_path) -> None:
        """Create two files with identical symbol names and verify pattern detection."""
        from codebrain.parser.models import ParsedFile, ParsedNode, ParsedEdge

        db_path = tmp_path / "test.db"
        store = GraphStore(db_path)

        # Two handler files with identical symbol names (handle, validate, transform)
        for name in ["auth", "users"]:
            store.upsert_file(ParsedFile(
                path=f"handlers/{name}.py",
                content_hash=name,
                line_count=30,
                nodes=[
                    ParsedNode(id=f"handlers/{name}.py::f", name=name, qualified_name=name,
                               type="file", file_path=f"handlers/{name}.py",
                               line_start=1, line_end=30, is_exported=True),
                    ParsedNode(id=f"handlers/{name}.py::handle", name="handle",
                               qualified_name=f"{name}.handle", type="function",
                               file_path=f"handlers/{name}.py", line_start=3, line_end=10),
                    ParsedNode(id=f"handlers/{name}.py::validate", name="validate",
                               qualified_name=f"{name}.validate", type="function",
                               file_path=f"handlers/{name}.py", line_start=12, line_end=18),
                    ParsedNode(id=f"handlers/{name}.py::transform", name="transform",
                               qualified_name=f"{name}.transform", type="function",
                               file_path=f"handlers/{name}.py", line_start=20, line_end=28),
                ],
                edges=[],
            ))

        analyzer = StructuralAnalyzer(store)
        patterns = analyzer.detect_structural_patterns()
        assert len(patterns) >= 1
        group = patterns[0]
        assert len(group["files"]) == 2
        assert group["similarity"] >= 0.6
        store.close()


class TestLayers:
    def test_returns_layers(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.detect_layers()
        assert "layers" in result
        assert isinstance(result["layers"], list)
        store.close()

    def test_layers_have_files(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.detect_layers()
        total_files = sum(len(l["files"]) for l in result["layers"])
        assert total_files > 0
        store.close()

    def test_layers_have_descriptions(self, analyzer_project) -> None:
        _, store, analyzer = analyzer_project
        result = analyzer.detect_layers()
        for layer in result["layers"]:
            assert "description" in layer
            assert len(layer["description"]) > 0
        store.close()

    def test_layers_resolve_import_targets(self, tmp_path) -> None:
        """Dotted import name targets (e.g. 'mylib.utils') should be resolved to file paths."""
        from codebrain.parser.models import ParsedFile, ParsedNode, ParsedEdge

        db_path = tmp_path / "test.db"
        store = GraphStore(db_path)

        # a.py imports "mylib.utils" (dotted name, not a node ID)
        store.upsert_file(ParsedFile(
            path="mylib/a.py", content_hash="a", line_count=10,
            nodes=[
                ParsedNode(id="mylib/a.py::a", name="a", qualified_name="a", type="file",
                           file_path="mylib/a.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="mylib/a.py::do_stuff", name="do_stuff", qualified_name="do_stuff",
                           type="function", file_path="mylib/a.py", line_start=3, line_end=8),
            ],
            edges=[
                ParsedEdge(source="mylib/a.py::a", target="mylib.utils", type="IMPORTS",
                           file_path="mylib/a.py", line=1),
            ],
        ))
        store.upsert_file(ParsedFile(
            path="mylib/utils.py", content_hash="u", line_count=10,
            nodes=[
                ParsedNode(id="mylib/utils.py::u", name="utils", qualified_name="utils", type="file",
                           file_path="mylib/utils.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="mylib/utils.py::helper", name="helper", qualified_name="helper",
                           type="function", file_path="mylib/utils.py", line_start=3, line_end=8),
            ],
            edges=[],
        ))

        analyzer = StructuralAnalyzer(store)
        result = analyzer.detect_layers()
        layer_numbers = {l["layer"] for l in result["layers"]}
        assert len(layer_numbers) >= 2, f"Dotted import not resolved — all in {layer_numbers}"
        store.close()

    def test_layers_resolve_bare_name_targets(self, tmp_path) -> None:
        """Bare-name targets (e.g. 'helper') should resolve via name index."""
        from codebrain.parser.models import ParsedFile, ParsedNode, ParsedEdge

        db_path = tmp_path / "test.db"
        store = GraphStore(db_path)

        store.upsert_file(ParsedFile(
            path="app.py", content_hash="a", line_count=10,
            nodes=[
                ParsedNode(id="app.py::app", name="app", qualified_name="app", type="file",
                           file_path="app.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="app.py::main", name="main", qualified_name="main", type="function",
                           file_path="app.py", line_start=3, line_end=8),
            ],
            edges=[
                ParsedEdge(source="app.py::main", target="helper", type="CALLS",
                           file_path="app.py", line=5),
            ],
        ))
        store.upsert_file(ParsedFile(
            path="lib.py", content_hash="l", line_count=10,
            nodes=[
                ParsedNode(id="lib.py::lib", name="lib", qualified_name="lib", type="file",
                           file_path="lib.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="lib.py::helper", name="helper", qualified_name="helper",
                           type="function", file_path="lib.py", line_start=3, line_end=8),
            ],
            edges=[],
        ))

        analyzer = StructuralAnalyzer(store)
        result = analyzer.detect_layers()
        layer_numbers = {l["layer"] for l in result["layers"]}
        assert len(layer_numbers) >= 2, f"Bare-name target not resolved — all in {layer_numbers}"
        store.close()

    def test_layers_real_project(self, analyzer_project) -> None:
        """On the indexed simple_project fixture, layers should produce >1 distinct layer."""
        _, store, analyzer = analyzer_project
        result = analyzer.detect_layers()
        layer_numbers = {l["layer"] for l in result["layers"]}
        assert len(layer_numbers) > 1, f"Expected multiple layers, got {layer_numbers}"
        store.close()

    def test_layers_use_calls_edges(self, tmp_path) -> None:
        """Layers should consider CALLS edges, not just IMPORTS."""
        from codebrain.parser.models import ParsedFile, ParsedNode, ParsedEdge

        db_path = tmp_path / "test.db"
        store = GraphStore(db_path)

        # a.py calls b.py::func (no IMPORTS, only CALLS)
        store.upsert_file(ParsedFile(
            path="a.py", content_hash="a", line_count=10,
            nodes=[
                ParsedNode(id="a.py::a", name="a", qualified_name="a", type="file",
                           file_path="a.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="a.py::main", name="main", qualified_name="main", type="function",
                           file_path="a.py", line_start=3, line_end=8),
            ],
            edges=[
                ParsedEdge(source="a.py::main", target="b.py::func", type="CALLS", file_path="a.py", line=5),
            ],
        ))
        store.upsert_file(ParsedFile(
            path="b.py", content_hash="b", line_count=10,
            nodes=[
                ParsedNode(id="b.py::b", name="b", qualified_name="b", type="file",
                           file_path="b.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="b.py::func", name="func", qualified_name="func", type="function",
                           file_path="b.py", line_start=3, line_end=8),
            ],
            edges=[],
        ))

        analyzer = StructuralAnalyzer(store)
        result = analyzer.detect_layers()
        # Should produce at least 2 layers since a.py depends on b.py
        layer_numbers = {l["layer"] for l in result["layers"]}
        assert len(layer_numbers) >= 2, f"Expected multiple layers, got {layer_numbers}"
        store.close()

    def test_layers_have_metadata_fields(self, analyzer_project) -> None:
        """Layers should include summary, files_truncated, and total_files."""
        _, store, analyzer = analyzer_project
        result = analyzer.detect_layers()
        for layer in result["layers"]:
            assert "total_files" in layer, "Missing total_files"
            assert "files_truncated" in layer, "Missing files_truncated"
            assert "summary" in layer, "Missing summary"
            assert isinstance(layer["total_files"], int)
            assert isinstance(layer["files_truncated"], bool)
            assert isinstance(layer["summary"], str)
            assert layer["total_files"] >= len(layer["files"])
        store.close()

    def test_layer_label_uses_package_name(self) -> None:
        """When a layer is dominated by one package, the label should use its name."""
        from codebrain.graph.store import GraphStore
        # Create a minimal analyzer just to call _layer_label
        analyzer = StructuralAnalyzer.__new__(StructuralAnalyzer)
        files = [
            "backend/routes/auth.py",
            "backend/routes/users.py",
            "backend/routes/items.py",
        ]
        label = analyzer._layer_label(2, files)
        assert label == "backend", f"Expected 'backend' but got '{label}'"

    def test_layer_label_entry_points(self) -> None:
        """Entry point files should get 'entry_points' label."""
        analyzer = StructuralAnalyzer.__new__(StructuralAnalyzer)
        files = ["pkg/cli.py", "pkg/utils.py"]
        label = analyzer._layer_label(3, files)
        assert label == "entry_points"

    def test_layer_description_includes_packages(self) -> None:
        """Layer description should mention packages when files span directories."""
        analyzer = StructuralAnalyzer.__new__(StructuralAnalyzer)
        files = ["backend/auth.py", "backend/users.py", "frontend/app.py"]
        desc = analyzer._layer_description(2, files)
        assert "backend" in desc
        assert "frontend" in desc


class TestCouplingResolution:
    """Test that coupling_analysis uses multi-strategy target resolution."""

    def test_coupling_resolves_bare_names(self, tmp_path) -> None:
        """Coupling should find pairs when edges use bare name targets."""
        from codebrain.parser.models import ParsedFile, ParsedNode, ParsedEdge

        db_path = tmp_path / "test.db"
        store = GraphStore(db_path)

        # a.py calls "helper" which is defined in b.py
        store.upsert_file(ParsedFile(
            path="a.py", content_hash="a", line_count=10,
            nodes=[
                ParsedNode(id="a.py::a", name="a", qualified_name="a", type="file",
                           file_path="a.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="a.py::main", name="main", qualified_name="main", type="function",
                           file_path="a.py", line_start=3, line_end=8),
            ],
            edges=[
                ParsedEdge(source="a.py::main", target="helper", type="CALLS",
                           file_path="a.py", line=5),
            ],
        ))
        store.upsert_file(ParsedFile(
            path="b.py", content_hash="b", line_count=10,
            nodes=[
                ParsedNode(id="b.py::b", name="b", qualified_name="b", type="file",
                           file_path="b.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="b.py::helper", name="helper", qualified_name="helper",
                           type="function", file_path="b.py", line_start=3, line_end=8),
            ],
            edges=[],
        ))

        analyzer = StructuralAnalyzer(store)
        result = analyzer.coupling_analysis()
        assert len(result["pairs"]) >= 1, "Coupling should find at least one pair"
        pair = result["pairs"][0]
        assert pair["coupling_score"] > 0
        files = {pair["file_a"], pair["file_b"]}
        assert files == {"a.py", "b.py"}
        store.close()


class TestCohesionResolution:
    """Test that cohesion_analysis resolves edge targets by name/qname."""

    def test_cohesion_resolves_bare_name_targets(self, tmp_path) -> None:
        """Cohesion should count edges with bare name targets as internal."""
        from codebrain.parser.models import ParsedFile, ParsedNode, ParsedEdge

        db_path = tmp_path / "test.db"
        store = GraphStore(db_path)

        # a.py has func_a calling "func_b" (bare name), both in a.py
        store.upsert_file(ParsedFile(
            path="a.py", content_hash="a", line_count=20,
            nodes=[
                ParsedNode(id="a.py::a", name="a", qualified_name="a", type="file",
                           file_path="a.py", line_start=1, line_end=20, is_exported=True),
                ParsedNode(id="a.py::func_a", name="func_a", qualified_name="func_a",
                           type="function", file_path="a.py", line_start=3, line_end=10),
                ParsedNode(id="a.py::func_b", name="func_b", qualified_name="func_b",
                           type="function", file_path="a.py", line_start=12, line_end=18),
            ],
            edges=[
                ParsedEdge(source="a.py::func_a", target="func_b", type="CALLS",
                           file_path="a.py", line=5),
            ],
        ))

        analyzer = StructuralAnalyzer(store)
        result = analyzer.cohesion_analysis()
        assert len(result) >= 1
        a_cohesion = next((r for r in result if r["file_path"] == "a.py"), None)
        assert a_cohesion is not None, "a.py should appear in cohesion results"
        assert a_cohesion["internal_edges"] >= 1, "Bare name target should be counted as internal"
        assert a_cohesion["cohesion_score"] > 0, "Cohesion should be > 0"
        store.close()


class TestPatternNoiseReduction:
    """Test that pattern detection excludes test files and low-signal groups."""

    def test_patterns_exclude_test_files(self, tmp_path) -> None:
        """Test files should not be candidates for pattern detection."""
        from codebrain.parser.models import ParsedFile, ParsedNode, ParsedEdge

        db_path = tmp_path / "test.db"
        store = GraphStore(db_path)

        # Create test files that share symbols
        for name in ["auth", "users", "items"]:
            store.upsert_file(ParsedFile(
                path=f"tests/test_{name}.py",
                content_hash=name,
                line_count=30,
                nodes=[
                    ParsedNode(id=f"tests/test_{name}.py::f", name=f"test_{name}",
                               qualified_name=f"test_{name}", type="file",
                               file_path=f"tests/test_{name}.py",
                               line_start=1, line_end=30, is_exported=True),
                    ParsedNode(id=f"tests/test_{name}.py::setup", name="setup",
                               qualified_name=f"test_{name}.setup", type="function",
                               file_path=f"tests/test_{name}.py", line_start=3, line_end=10),
                    ParsedNode(id=f"tests/test_{name}.py::teardown", name="teardown",
                               qualified_name=f"test_{name}.teardown", type="function",
                               file_path=f"tests/test_{name}.py", line_start=12, line_end=18),
                    ParsedNode(id=f"tests/test_{name}.py::run", name="run",
                               qualified_name=f"test_{name}.run", type="function",
                               file_path=f"tests/test_{name}.py", line_start=20, line_end=28),
                ],
                edges=[],
            ))

        analyzer = StructuralAnalyzer(store)
        patterns = analyzer.detect_structural_patterns()
        # Test files should be excluded, so no patterns found
        assert len(patterns) == 0, f"Test files should be excluded, got {len(patterns)} patterns"
        store.close()

    def test_is_test_file(self) -> None:
        """Verify _is_test_file detects common test file patterns."""
        assert StructuralAnalyzer._is_test_file("tests/test_foo.py")
        assert StructuralAnalyzer._is_test_file("test/test_bar.py")
        assert StructuralAnalyzer._is_test_file("src/tests/test_baz.py")
        assert StructuralAnalyzer._is_test_file("foo_test.py")
        assert not StructuralAnalyzer._is_test_file("src/foo.py")
        assert not StructuralAnalyzer._is_test_file("handlers/auth.py")
