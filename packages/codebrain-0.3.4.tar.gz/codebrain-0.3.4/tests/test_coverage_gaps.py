"""Tests for structural test coverage gap analysis (M23)."""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import asdict
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.test_gaps import TestCoverageAnalyzer


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_store():
    """Create an in-memory-ish GraphStore in a temp dir."""
    tmp = tempfile.mkdtemp()
    db = Path(tmp) / ".codebrain" / "graph.db"
    return GraphStore(db)


def _node(nid: str, name: str, ntype: str, file_path: str,
          is_exported: bool = False, line: int = 1) -> ParsedNode:
    return ParsedNode(
        id=nid, name=name, qualified_name=name, type=ntype,
        file_path=file_path, line_start=line, line_end=line + 5,
        is_exported=is_exported,
    )


def _edge(source: str, target: str, etype: str = "CALLS",
          file_path: str = "src/mod.py", line: int = 1) -> ParsedEdge:
    return ParsedEdge(source=source, target=target, type=etype,
                      file_path=file_path, line=line)


def _index(store: GraphStore, nodes: list[ParsedNode], edges: list[ParsedEdge]):
    """Group nodes/edges by file and upsert."""
    files: dict[str, tuple[list[ParsedNode], list[ParsedEdge]]] = {}
    for n in nodes:
        files.setdefault(n.file_path, ([], []))[0].append(n)
    for e in edges:
        files.setdefault(e.file_path, ([], []))[1].append(e)
    for fp, (ns, es) in files.items():
        store.upsert_file(ParsedFile(path=fp, content_hash="h", nodes=ns, edges=es))


# ---------------------------------------------------------------------------
# Unit Tests
# ---------------------------------------------------------------------------

class TestBasicCoverage:

    def test_basic_coverage_classification(self):
        """3 prod functions, 1 test that calls 2 → 66.7% coverage, 1 gap."""
        store = _make_store()
        nodes = [
            _node("src/mod.py::mod", "mod", "file", "src/mod.py"),
            _node("src/mod.py::func_a", "func_a", "function", "src/mod.py", is_exported=True),
            _node("src/mod.py::func_b", "func_b", "function", "src/mod.py"),
            _node("src/mod.py::func_c", "func_c", "function", "src/mod.py"),
            _node("tests/test_mod.py::test_mod", "test_mod", "file", "tests/test_mod.py"),
            _node("tests/test_mod.py::test_stuff", "test_stuff", "function", "tests/test_mod.py"),
        ]
        edges = [
            _edge("tests/test_mod.py::test_stuff", "func_a", file_path="tests/test_mod.py"),
            _edge("tests/test_mod.py::test_stuff", "func_b", file_path="tests/test_mod.py"),
        ]
        _index(store, nodes, edges)

        analyzer = TestCoverageAnalyzer(store)
        report = analyzer.analyze(max_depth=1)

        assert report.total_production_symbols == 3
        assert report.tested_symbols == 2
        assert report.untested_symbols == 1
        assert abs(report.coverage_percent - 66.7) < 1.0
        assert len(report.gaps) == 1
        assert report.gaps[0].name == "func_c"
        store.close()

    def test_transitive_coverage(self):
        """test→A→B→C, depth=3 → all covered; depth=1 → only A covered."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::A", "A", "function", "src/m.py"),
            _node("src/m.py::B", "B", "function", "src/m.py"),
            _node("src/m.py::C", "C", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        edges = [
            _edge("tests/t.py::test_x", "A", file_path="tests/t.py"),
            _edge("src/m.py::A", "B"),
            _edge("src/m.py::B", "C"),
        ]
        _index(store, nodes, edges)
        analyzer = TestCoverageAnalyzer(store)

        report3 = analyzer.analyze(max_depth=3)
        assert report3.tested_symbols == 3
        assert report3.untested_symbols == 0

        report1 = analyzer.analyze(max_depth=1)
        assert report1.tested_symbols == 1
        assert report1.untested_symbols == 2
        store.close()

    def test_depth_limit(self):
        """test→A→B→C→D, depth=2 → C and D are gaps."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::A", "A", "function", "src/m.py"),
            _node("src/m.py::B", "B", "function", "src/m.py"),
            _node("src/m.py::C", "C", "function", "src/m.py"),
            _node("src/m.py::D", "D", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        edges = [
            _edge("tests/t.py::test_x", "A", file_path="tests/t.py"),
            _edge("src/m.py::A", "B"),
            _edge("src/m.py::B", "C"),
            _edge("src/m.py::C", "D"),
        ]
        _index(store, nodes, edges)
        analyzer = TestCoverageAnalyzer(store)

        report = analyzer.analyze(max_depth=2)
        assert report.tested_symbols == 2  # A and B
        gap_names = {g.name for g in report.gaps}
        assert "C" in gap_names
        assert "D" in gap_names
        store.close()

    def test_no_tests(self):
        """Codebase with 0 test files → 0% coverage."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
        ]
        _index(store, nodes, [])
        analyzer = TestCoverageAnalyzer(store)
        report = analyzer.analyze()

        assert report.coverage_percent == 0.0
        assert report.test_node_count == 0
        assert "No test files found" in report.narrative
        store.close()

    def test_full_coverage(self):
        """Every prod symbol called by a test → 100%, 0 gaps."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::f1", "f1", "function", "src/m.py"),
            _node("src/m.py::f2", "f2", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_all", "test_all", "function", "tests/t.py"),
        ]
        edges = [
            _edge("tests/t.py::test_all", "f1", file_path="tests/t.py"),
            _edge("tests/t.py::test_all", "f2", file_path="tests/t.py"),
        ]
        _index(store, nodes, edges)
        report = TestCoverageAnalyzer(store).analyze()

        assert report.coverage_percent == 100.0
        assert len(report.gaps) == 0
        store.close()


class TestRiskScoring:

    def test_risk_scoring(self):
        """Exported function with 10 dependents scores higher than private with 0."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::important", "important", "function", "src/m.py", is_exported=True),
            _node("src/m.py::trivial", "trivial", "function", "src/m.py"),
        ]
        # 10 prod callers for important (no tests at all — both are untested)
        callers = []
        for i in range(10):
            caller_id = f"src/m.py::caller_{i}"
            nodes.append(_node(caller_id, f"caller_{i}", "function", "src/m.py"))
            callers.append(_edge(caller_id, "src/m.py::important"))
        _index(store, nodes, callers)
        report = TestCoverageAnalyzer(store).analyze()

        gap_map = {g.name: g for g in report.gaps}
        assert "important" in gap_map
        assert "trivial" in gap_map
        assert gap_map["important"].risk_score > gap_map["trivial"].risk_score
        assert gap_map["important"].is_exported is True
        store.close()


class TestExclusions:

    def test_excludes_dunders(self):
        """__init__, __repr__ not in gaps list."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::__init__", "__init__", "method", "src/m.py"),
            _node("src/m.py::__repr__", "__repr__", "method", "src/m.py"),
            _node("src/m.py::real_func", "real_func", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        _index(store, nodes, [])
        report = TestCoverageAnalyzer(store).analyze()

        gap_names = {g.name for g in report.gaps}
        assert "__init__" not in gap_names
        assert "__repr__" not in gap_names
        assert "real_func" in gap_names
        store.close()

    def test_excludes_file_nodes(self):
        """File-level nodes not counted."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        _index(store, nodes, [])
        report = TestCoverageAnalyzer(store).analyze()

        assert report.total_production_symbols == 1  # only func, not file nodes
        store.close()

    def test_excludes_test_nodes(self):
        """Test functions not counted as production."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
            _node("tests/t.py::TestClass", "TestClass", "class", "tests/t.py"),
        ]
        _index(store, nodes, [])
        report = TestCoverageAnalyzer(store).analyze()

        assert report.total_production_symbols == 1
        gap_names = {g.name for g in report.gaps}
        assert "test_x" not in gap_names
        assert "TestClass" not in gap_names
        store.close()

    def test_excludes_variables(self):
        """Variable/constant nodes not counted as production symbols."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::MY_CONST", "MY_CONST", "variable", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        _index(store, nodes, [])
        report = TestCoverageAnalyzer(store).analyze()

        assert report.total_production_symbols == 1  # only func
        gap_names = {g.name for g in report.gaps}
        assert "MY_CONST" not in gap_names
        store.close()


class TestEdgeCases:

    def test_conftest_counts(self):
        """conftest.py function calling prod code → that prod code is tested."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::setup_db", "setup_db", "function", "src/m.py"),
            _node("tests/conftest.py::conftest", "conftest", "file", "tests/conftest.py"),
            _node("tests/conftest.py::db_fixture", "db_fixture", "function", "tests/conftest.py"),
        ]
        edges = [
            _edge("tests/conftest.py::db_fixture", "setup_db", file_path="tests/conftest.py"),
        ]
        _index(store, nodes, edges)
        report = TestCoverageAnalyzer(store).analyze()

        assert report.tested_symbols == 1
        assert report.gaps == []
        store.close()

    def test_method_inclusion(self):
        """Methods included by default, excluded with include_methods=False."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::MyClass", "MyClass", "class", "src/m.py"),
            _node("src/m.py::MyClass.do_stuff", "do_stuff", "method", "src/m.py"),
            _node("src/m.py::top_func", "top_func", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        _index(store, nodes, [])
        analyzer = TestCoverageAnalyzer(store)

        with_methods = analyzer.analyze(include_methods=True)
        assert with_methods.total_production_symbols == 3  # class + method + func

        without_methods = analyzer.analyze(include_methods=False)
        assert without_methods.total_production_symbols == 2  # class + func
        gap_names = {g.name for g in without_methods.gaps}
        assert "do_stuff" not in gap_names
        store.close()

    def test_min_risk_filter(self):
        """min_risk=0.5 filters out low-risk gaps."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::exported_func", "exported_func", "function", "src/m.py", is_exported=True),
            _node("src/m.py::private_func", "private_func", "function", "src/m.py"),
        ]
        # Add 5 prod callers for exported_func to get risk >= 0.5 (no tests)
        for i in range(5):
            nodes.append(_node(f"src/m.py::c{i}", f"c{i}", "function", "src/m.py"))
        edges = [_edge(f"src/m.py::c{i}", "src/m.py::exported_func") for i in range(5)]
        _index(store, nodes, edges)

        report = TestCoverageAnalyzer(store).analyze(min_risk=0.5)
        gap_names = {g.name for g in report.gaps}
        assert "exported_func" in gap_names
        assert "private_func" not in gap_names  # risk < 0.5
        store.close()

    def test_file_level_stats(self):
        """Per-file coverage stats correct."""
        store = _make_store()
        nodes = [
            _node("src/a.py::a", "a", "file", "src/a.py"),
            _node("src/a.py::f1", "f1", "function", "src/a.py"),
            _node("src/a.py::f2", "f2", "function", "src/a.py"),
            _node("src/b.py::b", "b", "file", "src/b.py"),
            _node("src/b.py::g1", "g1", "function", "src/b.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        edges = [
            _edge("tests/t.py::test_x", "f1", file_path="tests/t.py"),
        ]
        _index(store, nodes, edges)
        report = TestCoverageAnalyzer(store).analyze()

        assert report.tested_files == 1  # src/a.py has f1 tested
        assert report.untested_files == 1  # src/b.py has 0 tested
        store.close()

    def test_narrative_generation(self):
        """Narrative includes coverage %, top gaps, recommendations."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py", is_exported=True),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        _index(store, nodes, [])
        report = TestCoverageAnalyzer(store).analyze()

        assert "0.0%" in report.narrative
        assert "Test Coverage Analysis" in report.narrative
        store.close()

    def test_unresolved_targets(self):
        """Bare-name edge targets resolved via name fallback."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::helper", "helper", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        # Edge target is bare name "helper", not full ID
        edges = [
            _edge("tests/t.py::test_x", "helper", file_path="tests/t.py"),
        ]
        _index(store, nodes, edges)
        report = TestCoverageAnalyzer(store).analyze()

        assert report.tested_symbols == 1
        assert report.untested_symbols == 0
        store.close()


# ---------------------------------------------------------------------------
# Integration Tests
# ---------------------------------------------------------------------------

class TestCLI:

    def test_cli_test_gaps_command(self):
        """CLI runs and outputs human-readable format."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        with runner.isolated_filesystem():
            Path(".codebrain").mkdir()
            store = GraphStore(Path(".codebrain/graph.db"))
            nodes = [
                _node("src/m.py::m", "m", "file", "src/m.py"),
                _node("src/m.py::func", "func", "function", "src/m.py"),
            ]
            _index(store, nodes, [])
            store.close()

            result = runner.invoke(cli, ["test-gaps"])
            assert result.exit_code == 0
            assert "Test Coverage Analysis" in result.output or "production symbols" in result.output

    def test_cli_test_gaps_json(self):
        """CLI with --json outputs valid JSON."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        with runner.isolated_filesystem():
            Path(".codebrain").mkdir()
            store = GraphStore(Path(".codebrain/graph.db"))
            nodes = [
                _node("src/m.py::m", "m", "file", "src/m.py"),
                _node("src/m.py::func", "func", "function", "src/m.py"),
            ]
            _index(store, nodes, [])
            store.close()

            result = runner.invoke(cli, ["test-gaps", "--json"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert "coverage_percent" in data

    def test_mcp_tool(self):
        """MCP tool returns valid JSON with expected fields."""
        # This is tested via the analyzer directly since MCP requires a server
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_x", "test_x", "function", "tests/t.py"),
        ]
        edges = [_edge("tests/t.py::test_x", "func", file_path="tests/t.py")]
        _index(store, nodes, edges)
        report = TestCoverageAnalyzer(store).analyze()

        # Simulate MCP JSON output
        result = {
            "coverage_percent": report.coverage_percent,
            "total_production": report.total_production_symbols,
            "tested": report.tested_symbols,
            "untested": report.untested_symbols,
            "narrative": report.narrative,
            "top_gaps": [asdict(g) for g in report.gaps[:30]],
            "test_stats": {"test_functions": report.test_node_count},
        }
        output = json.dumps(result)
        parsed = json.loads(output)
        assert parsed["coverage_percent"] == 100.0
        store.close()


# ---------------------------------------------------------------------------
# Self-validation on a real repo — uses the session-scoped saleor fixture by
# default, or the repo at $CODEBRAIN_TEST_REPO if that env var is set.
# ---------------------------------------------------------------------------

class TestRealRepo:

    @pytest.fixture(scope="class")
    def real_repo_db(self, saleor_indexed_db):
        """Prefer $CODEBRAIN_TEST_REPO's pre-built .codebrain/graph.db if set;
        otherwise fall back to the session-indexed Saleor fixture."""
        env_repo = os.environ.get("CODEBRAIN_TEST_REPO")
        if env_repo:
            env_db = Path(env_repo) / ".codebrain" / "graph.db"
            if env_db.exists():
                return env_db
        # Fixture path provided by tests/conftest.py — Saleor, indexed once
        # per pytest session.
        return saleor_indexed_db

    def test_real_repo_coverage(self, real_repo_db):
        """Run on real repo, verify coverage % is plausible."""
        with GraphStore(real_repo_db) as store:
            report = TestCoverageAnalyzer(store).analyze()
        assert 0.0 <= report.coverage_percent <= 100.0
        assert report.total_production_symbols > 0

    def test_real_repo_gaps_have_risk(self, real_repo_db):
        """Gaps have risk_score > 0."""
        with GraphStore(real_repo_db) as store:
            report = TestCoverageAnalyzer(store).analyze()
        if report.gaps:
            assert any(g.risk_score > 0 for g in report.gaps)
