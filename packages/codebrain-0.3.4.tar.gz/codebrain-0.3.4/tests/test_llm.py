"""Tests for the Grok LLM explanation layer (codebrain.llm).

All tests mock _call_grok_sync — no real HTTP calls are made.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from codebrain.llm import (
    KeyRotator,
    LLMNarrator,
    LLMSettings,
    ResponseCache,
    load_llm_settings,
)


# ===================================================================
# TestKeyRotator
# ===================================================================


class TestKeyRotator:
    def test_round_robin(self) -> None:
        r = KeyRotator(["k1", "k2", "k3"])
        assert r.get_key() == "k1"
        assert r.get_key() == "k2"
        assert r.get_key() == "k3"
        assert r.get_key() == "k1"

    def test_empty_keys(self) -> None:
        r = KeyRotator([])
        assert r.get_key() is None
        assert r.total == 0
        assert r.available_count == 0

    def test_cooldown_skips_key(self) -> None:
        r = KeyRotator(["k1", "k2"], cooldown=60.0)
        r.report_rate_limit("k1")
        # Should skip k1 and return k2
        assert r.get_key() == "k2"
        assert r.available_count == 1

    def test_all_keys_on_cooldown(self) -> None:
        r = KeyRotator(["k1", "k2"], cooldown=60.0)
        r.report_rate_limit("k1")
        r.report_rate_limit("k2")
        assert r.get_key() is None
        assert r.available_count == 0

    def test_cooldown_expiry(self) -> None:
        r = KeyRotator(["k1"], cooldown=0.01)
        r.report_rate_limit("k1")
        time.sleep(0.02)
        assert r.get_key() == "k1"

    def test_report_success_clears_cooldown(self) -> None:
        r = KeyRotator(["k1", "k2"], cooldown=60.0)
        r.report_rate_limit("k1")
        assert r.available_count == 1
        r.report_success("k1")
        assert r.available_count == 2

    def test_total_and_available(self) -> None:
        r = KeyRotator(["k1", "k2", "k3"])
        assert r.total == 3
        assert r.available_count == 3
        r.report_rate_limit("k2")
        assert r.total == 3
        assert r.available_count == 2


# ===================================================================
# TestResponseCache
# ===================================================================


class TestResponseCache:
    def test_put_and_get(self, tmp_path: Path) -> None:
        cache = ResponseCache(tmp_path, ttl=3600)
        cache.put("abc", "hello world")
        assert cache.get("abc") == "hello world"
        cache.close()

    def test_ttl_expiry(self, tmp_path: Path) -> None:
        cache = ResponseCache(tmp_path, ttl=0)  # instant expiry
        cache.put("abc", "hello")
        # With ttl=0, any positive elapsed time means expired
        time.sleep(0.01)
        assert cache.get("abc") is None
        cache.close()

    def test_missing_key(self, tmp_path: Path) -> None:
        cache = ResponseCache(tmp_path, ttl=3600)
        assert cache.get("nonexistent") is None
        cache.close()

    def test_clear(self, tmp_path: Path) -> None:
        cache = ResponseCache(tmp_path, ttl=3600)
        cache.put("a", "1")
        cache.put("b", "2")
        cache.clear()
        assert cache.get("a") is None
        assert cache.get("b") is None
        cache.close()

    def test_make_key_deterministic(self) -> None:
        k1 = ResponseCache.make_key("system", "data_abc")
        k2 = ResponseCache.make_key("system", "data_abc")
        k3 = ResponseCache.make_key("module", "data_abc")
        assert k1 == k2
        assert k1 != k3


# ===================================================================
# TestLLMSettings
# ===================================================================


class TestLLMSettings:
    def test_defaults(self) -> None:
        s = LLMSettings()
        assert s.enabled is False
        assert s.api_keys == []
        assert s.model == "grok-3-mini-fast"
        assert s.base_url == "https://api.x.ai/v1"
        assert s.max_tokens == 1024
        assert s.temperature == 0.3
        assert s.timeout == 30.0
        assert s.cache_ttl == 3600

    def test_auto_enable_with_keys(self) -> None:
        """If keys are provided but enabled is not set, auto-enable."""
        with patch.dict("os.environ", {"CODEBRAIN_LLM_API_KEYS": "key1,key2"}, clear=False):
            s = load_llm_settings()
        assert s.enabled is True
        assert s.api_keys == ["key1", "key2"]

    def test_explicit_disable_overrides_auto(self) -> None:
        """If enabled=false explicitly, keys don't auto-enable."""
        with patch.dict(
            "os.environ",
            {"CODEBRAIN_LLM_API_KEYS": "key1", "CODEBRAIN_LLM_ENABLED": "false"},
            clear=False,
        ):
            s = load_llm_settings()
        assert s.enabled is False
        assert s.api_keys == ["key1"]

    def test_env_overrides(self) -> None:
        env = {
            "CODEBRAIN_LLM_API_KEYS": "a,b,c",
            "CODEBRAIN_LLM_MODEL": "grok-2",
            "CODEBRAIN_LLM_ENABLED": "true",
            "CODEBRAIN_LLM_MAX_TOKENS": "512",
            "CODEBRAIN_LLM_TEMPERATURE": "0.7",
        }
        with patch.dict("os.environ", env, clear=False):
            s = load_llm_settings()
        assert s.api_keys == ["a", "b", "c"]
        assert s.model == "grok-2"
        assert s.enabled is True
        assert s.max_tokens == 512
        assert s.temperature == 0.7

    def test_toml_loading(self, tmp_path: Path) -> None:
        toml_content = b'[llm]\nenabled = true\napi_keys = ["tok1", "tok2"]\nmodel = "grok-3"\ncache_ttl = 7200\n'
        (tmp_path / ".codebrain.toml").write_bytes(toml_content)
        s = load_llm_settings(tmp_path)
        assert s.enabled is True
        assert s.api_keys == ["tok1", "tok2"]
        assert s.model == "grok-3"
        assert s.cache_ttl == 7200

    def test_no_keys_means_disabled(self) -> None:
        s = load_llm_settings()
        assert s.enabled is False
        assert s.api_keys == []


# ===================================================================
# TestLLMNarrator
# ===================================================================


class TestLLMNarrator:
    def test_disabled_returns_null_explanation(self, indexed_project) -> None:
        """When LLM is disabled, llm_explanation should be None."""
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=False)
        narrator = LLMNarrator(store, settings)
        result = narrator.explain_system()
        assert "summary" in result
        assert result["llm_explanation"] is None

    @patch("codebrain.llm._call_grok_sync", return_value="AI generated explanation")
    def test_enabled_returns_explanation(self, mock_grok, indexed_project) -> None:
        """When LLM is enabled and Grok returns, llm_explanation is populated."""
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=True, api_keys=["test_key"])
        narrator = LLMNarrator(store, settings)
        result = narrator.explain_system()
        assert result["llm_explanation"] == "AI generated explanation"
        assert "summary" in result

    @patch("codebrain.llm._call_grok_sync", return_value="Module explanation")
    def test_explain_module(self, mock_grok, indexed_project) -> None:
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=True, api_keys=["test_key"])
        narrator = LLMNarrator(store, settings)
        result = narrator.explain_module("mypackage/core.py")
        assert result["llm_explanation"] == "Module explanation"
        assert "summary" in result

    def test_explain_module_not_found(self, indexed_project) -> None:
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=False)
        narrator = LLMNarrator(store, settings)
        result = narrator.explain_module("nonexistent/file.py")
        assert "error" in result

    @patch("codebrain.llm._call_grok_sync", return_value="Health explanation")
    def test_explain_health(self, mock_grok, indexed_project) -> None:
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=True, api_keys=["test_key"])
        narrator = LLMNarrator(store, settings)
        result = narrator.explain_health()
        assert result["llm_explanation"] == "Health explanation"
        assert "score" in result
        assert "grade" in result

    @patch("codebrain.llm._call_grok_sync", return_value=None)
    def test_grok_failure_returns_null(self, mock_grok, indexed_project) -> None:
        """When Grok returns None (failure), llm_explanation should be None."""
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=True, api_keys=["test_key"])
        narrator = LLMNarrator(store, settings)
        result = narrator.explain_system()
        assert result["llm_explanation"] is None
        # Deterministic data should still be present
        assert "summary" in result

    def test_status(self, indexed_project) -> None:
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=True, api_keys=["k1", "k2"])
        narrator = LLMNarrator(store, settings)
        s = narrator.status()
        assert s["enabled"] is True
        assert s["keys_configured"] == 2
        assert s["keys_available"] == 2
        assert "model" in s

    @patch("codebrain.llm._call_grok_sync", return_value="Cached response")
    def test_cache_hit_avoids_api_call(self, mock_grok, indexed_project, tmp_path) -> None:
        """Second call for same data should use cache, not call Grok again."""
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=True, api_keys=["test_key"], cache_ttl=3600)
        cache_dir = tmp_path / ".codebrain"
        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)

        # First call — hits Grok
        result1 = narrator.explain_system()
        assert result1["llm_explanation"] == "Cached response"
        assert mock_grok.call_count == 1

        # Second call — should use cache
        result2 = narrator.explain_system()
        assert result2["llm_explanation"] == "Cached response"
        assert mock_grok.call_count == 1  # Still 1, not 2


# ===================================================================
# TestExplainAPI
# ===================================================================


class TestExplainAPI:
    @pytest.fixture
    def client(self, indexed_project):
        from codebrain.api import app, configure
        from fastapi.testclient import TestClient

        repo_root, store = indexed_project
        store.close()
        configure(repo_root)
        with TestClient(app) as c:
            yield c

    def test_llm_status_in_status_endpoint(self, client) -> None:
        r = client.get("/api/status")
        assert r.status_code == 200
        data = r.json()
        assert "llm" in data
        llm = data["llm"]
        assert "enabled" in llm

    def test_overview_explain_without_keys(self, client) -> None:
        r = client.get("/api/overview?explain=true")
        assert r.status_code == 200
        data = r.json()
        assert "stats" in data


# ===================================================================
# TestAnswerQuestionDeterministic
# ===================================================================


class TestAnswerQuestionDeterministic:
    """Test that answer_question() returns useful structural answers
    WITHOUT any LLM — purely deterministic fallback."""

    def test_what_depends_on_symbol(self, indexed_project) -> None:
        """'What depends on DataProcessor?' should find the symbol and report impact."""
        _, store = indexed_project
        from codebrain.comprehension import ComprehensionEngine

        comp = ComprehensionEngine(store)
        result = comp.answer_question("What depends on DataProcessor?")

        assert result["intent"] == "impact"
        assert result["answer"]  # non-empty
        # Should mention DataProcessor or the file it lives in
        assert "DataProcessor" in result["answer"] or "core" in result["answer"].lower()
        assert result["sources"]  # should have a source

    def test_what_is_riskiest_file(self, indexed_project) -> None:
        """'What is the riskiest file?' should identify high-risk files."""
        _, store = indexed_project
        from codebrain.comprehension import ComprehensionEngine

        comp = ComprehensionEngine(store)
        result = comp.answer_question("What is the riskiest file?")

        assert result["intent"] == "risk"
        assert result["answer"]  # non-empty
        # Should either list hotspots or say none found
        assert "hotspot" in result["answer"].lower() or "risk" in result["answer"].lower() or "no" in result["answer"].lower()
        assert result["sources"]

    def test_what_are_main_packages(self, indexed_project) -> None:
        """'What are the main packages?' should list packages."""
        _, store = indexed_project
        from codebrain.comprehension import ComprehensionEngine

        comp = ComprehensionEngine(store)
        result = comp.answer_question("What are the main packages?")

        assert result["intent"] == "overview"
        assert result["answer"]  # non-empty
        # The simple_project has 'mypackage'
        assert "mypackage" in result["answer"].lower()
        assert result["sources"]

    def test_what_would_break_if_change(self, indexed_project) -> None:
        """'What would break if I change core.py?' should list dependents."""
        _, store = indexed_project
        from codebrain.comprehension import ComprehensionEngine

        comp = ComprehensionEngine(store)
        result = comp.answer_question("What would break if I change core.py?")

        assert result["answer"]  # non-empty
        # Should be routed to risk or impact and provide useful data
        assert result["intent"] in ("risk", "impact")
        assert result["sources"]
        # The answer should contain some structural data
        assert result["data"] is not None


# ===================================================================
# TestCacheInvalidation
# ===================================================================


class TestCacheInvalidation:
    """Verify that cache keys include graph stats so re-indexing invalidates."""

    @patch("codebrain.llm._call_grok_sync", return_value="First answer")
    def test_cache_invalidates_on_reindex(self, mock_grok, indexed_project, tmp_path) -> None:
        """After re-indexing (changing node/edge counts), cache should miss."""
        repo_root, store = indexed_project
        settings = LLMSettings(enabled=True, api_keys=["test_key"], cache_ttl=3600)
        cache_dir = tmp_path / ".codebrain"
        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)

        # First call — hits Grok and caches
        result1 = narrator.explain_system()
        assert result1["llm_explanation"] == "First answer"
        assert mock_grok.call_count == 1

        # Second call — should use cache
        result2 = narrator.explain_system()
        assert mock_grok.call_count == 1

        # Simulate re-index by adding a new node (changes graph stats)
        store.conn.execute(
            "INSERT INTO nodes (id, name, qualified_name, type, file_path, "
            "line_start, line_end, signature, decorators, docstring, is_exported) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("new_module.new_func", "new_func", "new_module.new_func",
             "function", "new_module.py", 1, 5, "", "[]", "", 0),
        )
        store.conn.commit()

        # Now the cache key should be different due to changed node count
        mock_grok.return_value = "Updated answer"
        result3 = narrator.explain_system()
        # Should have called Grok again (cache miss due to new stats)
        assert mock_grok.call_count == 2


# ===================================================================
# TestMCPToolsGracefulFallback
# ===================================================================


class TestMCPToolsGracefulFallback:
    """Verify ask_codebase and explain_code MCP tools return valid JSON
    (not tracebacks) when LLM keys are missing."""

    def test_ask_codebase_returns_json_without_llm(self, indexed_project) -> None:
        """ask_codebase should return valid JSON when no LLM keys configured."""
        repo_root, store = indexed_project
        store.close()

        from codebrain import mcp_server
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME

        db_path = repo_root / CODEBRAIN_DIR / DB_FILENAME

        env_overrides = {
            "CODEBRAIN_LLM_API_KEYS": "",
            "CODEBRAIN_LLM_ENABLED": "false",
        }
        import asyncio
        with patch.object(mcp_server, "_find_db", return_value=db_path):
            with patch.dict("os.environ", env_overrides, clear=False):
                result = asyncio.run(mcp_server.ask_codebase("What are the main packages?"))

        # Must be valid JSON
        data = json.loads(result)
        assert "error" not in data or data.get("answer")
        # Should have structural answer fields
        assert "answer" in data
        assert "intent" in data

    def test_explain_code_returns_json_without_llm(self, indexed_project) -> None:
        """explain_code should return valid JSON when no LLM keys configured."""
        repo_root, store = indexed_project
        store.close()

        from codebrain import mcp_server
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME

        db_path = repo_root / CODEBRAIN_DIR / DB_FILENAME

        env_overrides = {
            "CODEBRAIN_LLM_API_KEYS": "",
            "CODEBRAIN_LLM_ENABLED": "false",
        }
        import asyncio
        with patch.object(mcp_server, "_find_db", return_value=db_path):
            with patch.dict("os.environ", env_overrides, clear=False):
                result = asyncio.run(mcp_server.explain_code("system"))

        # Must be valid JSON
        data = json.loads(result)
        assert "error" not in data or data.get("summary")
        # Should have deterministic narrative fields
        assert "summary" in data
