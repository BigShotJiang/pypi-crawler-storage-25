"""Tests for the TypeScript/JavaScript parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.typescript_parser import parse_typescript_file


def _write_and_parse(tmp_path: Path, code: str, filename: str = "test.ts") -> "ParsedFile":
    p = tmp_path / filename
    p.write_text(code, encoding="utf-8")
    return parse_typescript_file(p, tmp_path)


class TestFunctions:
    def test_named_function(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "function greet(name: string): string {\n  return `Hello ${name}`;\n}\n")
        names = [n.name for n in pf.nodes]
        assert "greet" in names

    def test_arrow_function(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "const add = (a: number, b: number) => a + b;\n")
        names = [n.name for n in pf.nodes]
        assert "add" in names

    def test_async_function(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "async function fetchData(url: string) {\n  return await fetch(url);\n}\n")
        names = [n.name for n in pf.nodes]
        assert "fetchData" in names

    def test_exported_function(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "export function helper() {\n  return 42;\n}\n")
        func = [n for n in pf.nodes if n.name == "helper"][0]
        assert func.is_exported is True


class TestClasses:
    def test_class_declaration(self, tmp_path: Path) -> None:
        code = "class Animal {\n  name: string;\n  speak() {\n    console.log(this.name);\n  }\n}\n"
        pf = _write_and_parse(tmp_path, code)
        cls = [n for n in pf.nodes if n.name == "Animal"][0]
        assert cls.type == "class"

    def test_class_extends(self, tmp_path: Path) -> None:
        code = "class Dog extends Animal {\n  bark() { }\n}\n"
        pf = _write_and_parse(tmp_path, code)
        extends = [e for e in pf.edges if e.type == "EXTENDS"]
        assert len(extends) >= 1
        assert extends[0].target == "Animal"

    def test_class_implements(self, tmp_path: Path) -> None:
        code = "class MyService implements Service {\n  run() { }\n}\n"
        pf = _write_and_parse(tmp_path, code)
        impls = [e for e in pf.edges if e.type == "IMPLEMENTS"]
        assert len(impls) >= 1

    def test_class_methods(self, tmp_path: Path) -> None:
        code = "class Calc {\n  add(a: number, b: number): number {\n    return a + b;\n  }\n}\n"
        pf = _write_and_parse(tmp_path, code)
        methods = [n for n in pf.nodes if n.type == "method"]
        assert any(m.name == "add" for m in methods)


class TestImports:
    def test_named_import(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "import { useState, useEffect } from 'react';\n")
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        targets = [e.target for e in imports]
        assert "react.useState" in targets
        assert "react.useEffect" in targets

    def test_default_import(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "import React from 'react';\n")
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        assert any("react" in e.target for e in imports)

    def test_star_import(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "import * as utils from './utils';\n")
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        assert any("./utils" in e.target for e in imports)


class TestInterfaces:
    def test_interface(self, tmp_path: Path) -> None:
        code = "export interface User {\n  name: string;\n  age: number;\n}\n"
        pf = _write_and_parse(tmp_path, code)
        iface = [n for n in pf.nodes if n.name == "User"][0]
        assert iface.type == "class"
        assert "interface" in iface.decorators

    def test_interface_extends(self, tmp_path: Path) -> None:
        code = "interface Admin extends User {\n  role: string;\n}\n"
        pf = _write_and_parse(tmp_path, code)
        extends = [e for e in pf.edges if e.type == "EXTENDS"]
        assert len(extends) >= 1


class TestTypeAliasesAndEnums:
    def test_type_alias(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "export type ID = string | number;\n")
        node = [n for n in pf.nodes if n.name == "ID"][0]
        assert node.type == "variable"

    def test_enum(self, tmp_path: Path) -> None:
        code = "enum Color {\n  Red,\n  Green,\n  Blue,\n}\n"
        pf = _write_and_parse(tmp_path, code)
        node = [n for n in pf.nodes if n.name == "Color"][0]
        assert "enum" in node.decorators


class TestJSX:
    def test_tsx_file(self, tmp_path: Path) -> None:
        code = "import React from 'react';\n\nexport function App() {\n  return <div>Hello</div>;\n}\n"
        pf = _write_and_parse(tmp_path, code, "App.tsx")
        assert any(n.name == "App" for n in pf.nodes)


class TestNestedBraces:
    """Verify function body extraction handles nested braces."""

    def test_calls_after_nested_braces(self, tmp_path: Path) -> None:
        code = """function process(items: string[]) {
  items.forEach(item => {
    if (item) {
      console.log(item);
    }
  });
  cleanup();
}
"""
        pf = _write_and_parse(tmp_path, code)
        calls = [e for e in pf.edges if e.type == "CALLS"]
        call_targets = [e.target for e in calls]
        assert "cleanup" in call_targets, f"Expected 'cleanup' in call targets, got {call_targets}"

    def test_large_class_methods_past_2000_chars(self, tmp_path: Path) -> None:
        """Methods past 2000 chars should still be found (no truncation)."""
        padding = "  // " + "x" * 200 + "\n"
        code = "class BigClass {\n"
        code += padding * 15  # ~3000 chars of padding
        code += "  lateMethod(a: number): number {\n    return a;\n  }\n"
        code += "}\n"
        pf = _write_and_parse(tmp_path, code)
        methods = [n for n in pf.nodes if n.type == "method"]
        assert any(m.name == "lateMethod" for m in methods), \
            f"Expected 'lateMethod' in methods, got {[m.name for m in methods]}"


class TestArrowFunctionEdgeCases:
    def test_arrow_with_generics(self, tmp_path: Path) -> None:
        code = "const identity = <T>(value: T): T => value;\n"
        pf = _write_and_parse(tmp_path, code)
        names = [n.name for n in pf.nodes]
        assert "identity" in names, f"Expected 'identity' in {names}"

    def test_arrow_with_destructuring(self, tmp_path: Path) -> None:
        code = "const handler = ({ name, age }: Props) => name;\n"
        pf = _write_and_parse(tmp_path, code)
        names = [n.name for n in pf.nodes]
        assert "handler" in names, f"Expected 'handler' in {names}"


class TestFileNode:
    def test_file_node_exists(self, tmp_path: Path) -> None:
        pf = _write_and_parse(tmp_path, "const x = 1;\n")
        file_nodes = [n for n in pf.nodes if n.type == "file"]
        assert len(file_nodes) == 1
