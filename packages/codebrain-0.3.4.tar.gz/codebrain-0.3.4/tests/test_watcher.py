"""Tests for the file watcher debounced handler."""

from __future__ import annotations

import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class MockEvent:
    """Minimal stand-in for watchdog FileSystemEvent."""

    def __init__(self, src_path: str, is_directory: bool = False, dest_path: str = ""):
        self.src_path = src_path
        self.dest_path = dest_path
        self.is_directory = is_directory


class TestDebouncedHandler:
    def _make_handler(self, repo_root, store, debounce=0.05):
        from codebrain.watcher.file_watcher import _DebouncedHandler
        return _DebouncedHandler(
            repo_root=repo_root,
            store=store,
            debounce=debounce,
            extensions=frozenset({".py", ".ts"}),
        )

    def test_on_modified_collects_path(self, tmp_path):
        store = MagicMock()
        handler = self._make_handler(tmp_path, store)
        event = MockEvent(str(tmp_path / "foo.py"))
        handler.on_modified(event)
        assert Path(event.src_path) in handler._changed

    def test_ignores_irrelevant_extensions(self, tmp_path):
        store = MagicMock()
        handler = self._make_handler(tmp_path, store)
        event = MockEvent(str(tmp_path / "readme.md"))
        handler.on_modified(event)
        assert len(handler._changed) == 0

    def test_ignores_directories(self, tmp_path):
        store = MagicMock()
        handler = self._make_handler(tmp_path, store)
        event = MockEvent(str(tmp_path / "subdir"), is_directory=True)
        handler.on_modified(event)
        assert len(handler._changed) == 0

    def test_on_created_collects_path(self, tmp_path):
        store = MagicMock()
        handler = self._make_handler(tmp_path, store)
        event = MockEvent(str(tmp_path / "new.py"))
        handler.on_created(event)
        assert Path(event.src_path) in handler._changed

    def test_on_deleted_collects_path(self, tmp_path):
        store = MagicMock()
        handler = self._make_handler(tmp_path, store)
        event = MockEvent(str(tmp_path / "old.py"))
        handler.on_deleted(event)
        assert Path(event.src_path) in handler._deleted

    def test_deleted_removes_from_changed(self, tmp_path):
        store = MagicMock()
        handler = self._make_handler(tmp_path, store)
        path = str(tmp_path / "old.py")
        handler.on_modified(MockEvent(path))
        assert Path(path) in handler._changed
        handler.on_deleted(MockEvent(path))
        assert Path(path) not in handler._changed
        assert Path(path) in handler._deleted

    def test_on_moved_tracks_both(self, tmp_path):
        store = MagicMock()
        handler = self._make_handler(tmp_path, store)
        event = MockEvent(
            str(tmp_path / "old.py"),
            dest_path=str(tmp_path / "new.py"),
        )
        handler.on_moved(event)
        assert Path(event.src_path) in handler._deleted
        assert Path(event.dest_path) in handler._changed

    @patch("codebrain.watcher.file_watcher.incremental_update")
    def test_flush_calls_incremental_update(self, mock_update, tmp_path):
        mock_update.return_value = {
            "files_updated": 1,
            "files_removed": 0,
            "errors": [],
            "elapsed_seconds": 0.001,
        }
        store = MagicMock()
        handler = self._make_handler(tmp_path, store, debounce=0.01)
        handler.on_modified(MockEvent(str(tmp_path / "foo.py")))
        # Wait for debounce to fire
        time.sleep(0.1)
        assert mock_update.called

    @patch("codebrain.watcher.file_watcher.incremental_update")
    def test_debounce_collapses_events(self, mock_update, tmp_path):
        mock_update.return_value = {
            "files_updated": 1,
            "files_removed": 0,
            "errors": [],
            "elapsed_seconds": 0.001,
        }
        store = MagicMock()
        handler = self._make_handler(tmp_path, store, debounce=0.05)
        # Rapid-fire multiple events
        for i in range(5):
            handler.on_modified(MockEvent(str(tmp_path / "foo.py")))
        # Wait for debounce to fire
        time.sleep(0.15)
        # Should only flush once
        assert mock_update.call_count == 1

    @patch("codebrain.watcher.file_watcher.incremental_update")
    def test_flush_clears_sets(self, mock_update, tmp_path):
        mock_update.return_value = {
            "files_updated": 1,
            "files_removed": 0,
            "errors": [],
            "elapsed_seconds": 0.001,
        }
        store = MagicMock()
        handler = self._make_handler(tmp_path, store, debounce=0.01)
        handler.on_modified(MockEvent(str(tmp_path / "foo.py")))
        handler.on_deleted(MockEvent(str(tmp_path / "bar.py")))
        time.sleep(0.1)
        assert len(handler._changed) == 0
        assert len(handler._deleted) == 0
