"""Tests for the Python module resolver."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.resolver import ModuleResolver


@pytest.fixture
def resolver_project(simple_project: Path) -> tuple[Path, GraphStore, ModuleResolver]:
    full_index(simple_project)
    db_path = simple_project / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db_path)
    resolver = ModuleResolver(store)
    return simple_project, store, resolver


class TestResolve:
    def test_resolve_by_module_dot_name(self, resolver_project) -> None:
        _, store, resolver = resolver_project
        results = resolver.resolve("mypackage.utils.helper")
        assert len(results) >= 1
        assert any("helper" in r for r in results)
        store.close()

    def test_resolve_bare_name(self, resolver_project) -> None:
        _, store, resolver = resolver_project
        results = resolver.resolve("process")
        assert len(results) >= 1
        assert any("process" in r for r in results)
        store.close()

    def test_resolve_module_path(self, resolver_project) -> None:
        _, store, resolver = resolver_project
        results = resolver.resolve("mypackage.utils")
        assert len(results) >= 1
        store.close()

    def test_resolve_nonexistent(self, resolver_project) -> None:
        _, store, resolver = resolver_project
        results = resolver.resolve("nonexistent.module.thing")
        assert results == []
        store.close()

    def test_resolve_class(self, resolver_project) -> None:
        _, store, resolver = resolver_project
        results = resolver.resolve("mypackage.models.Item")
        assert len(results) >= 1
        assert any("Item" in r for r in results)
        store.close()


class TestResolveAllEdges:
    def test_resolution_stats(self, resolver_project) -> None:
        _, store, resolver = resolver_project
        stats = resolver.resolve_all_edges()
        assert stats["total_edges"] > 0
        assert stats["resolution_rate"] >= 0.0
        assert stats["resolution_rate"] <= 1.0
        store.close()
