"""Tests for the equivalence test generator."""

from __future__ import annotations

import textwrap
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from codebrain.equivalence import (
    EquivalenceTestGenerator,
    EquivalenceResult,
    EquivalenceTest,
    _IO_PARAM_NAMES,
    _SKIP_DUNDERS,
)
from codebrain.graph.store import GraphStore
from codebrain.rewriter import LLMClient


# ---------------------------------------------------------------------------
# Mock LLM client
# ---------------------------------------------------------------------------

@dataclass
class _FakeLLMResponse:
    content: str = '{"inputs": [{"a": 1, "b": 2}]}'
    model: str = "fake"
    tokens_used: int = 10
    latency_ms: int = 50


class FakeLLMClient(LLMClient):
    """Mock LLM client that returns canned JSON test inputs."""

    def __init__(self, response: str = '{"inputs": [{"a": 1, "b": 2}]}'):
        self._response = response

    def complete(self, system: str, user: str, temperature: float = 0.1):
        return _FakeLLMResponse(content=self._response)

    def is_available(self) -> bool:
        return True


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def equiv_project(tmp_path: Path):
    """Create a small project with pure + I/O functions for testing."""
    pkg = tmp_path / "mylib"
    pkg.mkdir()

    (pkg / "__init__.py").write_text('"""mylib."""\n')

    (pkg / "math_utils.py").write_text(textwrap.dedent('''\
        """Pure math utilities."""

        def add(a: int, b: int) -> int:
            """Add two numbers."""
            return a + b

        def multiply(x: int, y: int) -> int:
            """Multiply two numbers."""
            return x * y

        def completion_rate(done: int, total: int) -> float:
            """Return percentage complete."""
            if total == 0:
                return 0.0
            return done / total * 100.0
    '''))

    (pkg / "io_stuff.py").write_text(textwrap.dedent('''\
        """I/O functions that should be skipped."""

        def save_to_db(db, data):
            """Save data to database."""
            db.write(data)

        def read_file(file):
            """Read from a file."""
            return file.read()

        def send_request(request, url):
            """Send HTTP request."""
            pass
    '''))

    (pkg / "lifecycle.py").write_text(textwrap.dedent('''\
        """Class with lifecycle methods."""

        class Manager:
            def __init__(self):
                self.items = []

            def __enter__(self):
                return self

            def __exit__(self, *args):
                pass

            def process(self, data: str) -> str:
                """Public method that is testable."""
                return data.upper()
    '''))

    return tmp_path


@pytest.fixture
def indexed_equiv(equiv_project: Path):
    """Index the equiv_project and return (root, store)."""
    from codebrain.indexer import full_index
    from codebrain.config import CODEBRAIN_DIR, DB_FILENAME

    result = full_index(equiv_project)
    assert result["errors"] == []

    db_path = equiv_project / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db_path)
    yield equiv_project, store
    store.close()


@pytest.fixture
def fake_client():
    return FakeLLMClient()


@pytest.fixture
def generator(indexed_equiv, fake_client):
    root, store = indexed_equiv
    return EquivalenceTestGenerator(store, fake_client), root


# ---------------------------------------------------------------------------
# _is_testable tests
# ---------------------------------------------------------------------------

class TestIsTestable:
    def test_pure_function_is_testable(self, generator):
        gen, _ = generator
        symbol = {
            "name": "add",
            "type": "function",
            "is_exported": True,
            "params": "a: int, b: int",
            "return_type": "int",
        }
        assert gen._is_testable(symbol) is True

    def test_io_function_not_testable(self, generator):
        gen, _ = generator
        symbol = {
            "name": "save_to_db",
            "type": "function",
            "is_exported": True,
            "params": "db, data",
        }
        assert gen._is_testable(symbol) is False

    def test_dunder_init_not_testable(self, generator):
        gen, _ = generator
        symbol = {
            "name": "__init__",
            "type": "method",
            "is_exported": True,
            "params": "self",
        }
        assert gen._is_testable(symbol) is False

    def test_dunder_enter_not_testable(self, generator):
        gen, _ = generator
        symbol = {
            "name": "__enter__",
            "type": "method",
            "is_exported": True,
            "params": "self",
        }
        assert gen._is_testable(symbol) is False

    def test_file_param_not_testable(self, generator):
        gen, _ = generator
        symbol = {
            "name": "read_file",
            "type": "function",
            "is_exported": True,
            "params": "file",
        }
        assert gen._is_testable(symbol) is False

    def test_session_param_not_testable(self, generator):
        gen, _ = generator
        symbol = {
            "name": "get_user",
            "type": "function",
            "is_exported": True,
            "params": "session, user_id",
        }
        assert gen._is_testable(symbol) is False


# ---------------------------------------------------------------------------
# _extract_testable tests
# ---------------------------------------------------------------------------

class TestExtractTestable:
    def test_finds_public_functions(self, generator):
        gen, _ = generator
        testable = gen._extract_testable()
        names = [s["name"] for s in testable]
        # add and multiply should be testable
        assert "add" in names
        assert "multiply" in names

    def test_skips_io_functions(self, generator):
        gen, _ = generator
        testable = gen._extract_testable()
        names = [s["name"] for s in testable]
        assert "save_to_db" not in names
        assert "read_file" not in names
        assert "send_request" not in names

    def test_skips_dunder_methods(self, generator):
        gen, _ = generator
        testable = gen._extract_testable()
        names = [s["name"] for s in testable]
        assert "__init__" not in names
        assert "__enter__" not in names
        assert "__exit__" not in names


# ---------------------------------------------------------------------------
# _generate_same_lang_test tests
# ---------------------------------------------------------------------------

class TestGenerateSameLangTest:
    def test_uses_importlib(self, generator):
        gen, root = generator
        symbol = {
            "name": "add",
            "type": "function",
            "is_exported": True,
            "params": "a: int, b: int",
            "return_type": "int",
            "file_path": "mylib/math_utils.py",
            "qualified_name": "add",
        }
        code = gen._generate_same_lang_test(symbol, root, root)
        assert "importlib.util.spec_from_file_location" in code
        assert "importlib.util" in code

    def test_loads_both_projects(self, generator):
        gen, root = generator
        symbol = {
            "name": "add",
            "type": "function",
            "is_exported": True,
            "params": "a: int, b: int",
            "return_type": "int",
            "file_path": "mylib/math_utils.py",
            "qualified_name": "add",
        }
        new_root = root  # same for testing
        code = gen._generate_same_lang_test(symbol, root, new_root)
        # Should load module twice (old and new)
        assert code.count("_load_module(") >= 2

    def test_asserts_equal(self, generator):
        gen, root = generator
        symbol = {
            "name": "add",
            "type": "function",
            "is_exported": True,
            "params": "a: int, b: int",
            "return_type": "int",
            "file_path": "mylib/math_utils.py",
            "qualified_name": "add",
        }
        code = gen._generate_same_lang_test(symbol, root, root)
        assert "assert old_result == new_result" in code or "pytest.approx" in code


# ---------------------------------------------------------------------------
# Cross-language tests
# ---------------------------------------------------------------------------

class TestCrossLang:
    def test_wrapper_old_uses_json(self, generator):
        gen, root = generator
        symbols = [
            {"name": "add", "params": "a, b", "file_path": "mylib/math_utils.py",
             "qualified_name": "add"},
        ]
        wrapper = gen._generate_cross_lang_wrapper(symbols, root, "python")
        assert "json.load(sys.stdin)" in wrapper
        assert "json.dump(" in wrapper

    def test_cross_lang_test_uses_subprocess(self, generator):
        gen, _ = generator
        symbol = {
            "name": "add",
            "type": "function",
            "params": "a: int, b: int",
            "return_type": "int",
            "file_path": "mylib/math_utils.py",
            "qualified_name": "add",
        }
        code = gen._generate_cross_lang_test(symbol, "go")
        assert "subprocess.run" in code
        assert "_call_old" in code
        assert "_call_new" in code

    def test_cross_lang_test_uses_approx(self, generator):
        gen, _ = generator
        symbol = {
            "name": "completion_rate",
            "type": "function",
            "params": "done: int, total: int",
            "return_type": "float",
            "file_path": "mylib/math_utils.py",
            "qualified_name": "completion_rate",
        }
        code = gen._generate_cross_lang_test(symbol, "go")
        assert "pytest.approx" in code


# ---------------------------------------------------------------------------
# generate() integration
# ---------------------------------------------------------------------------

class TestGenerate:
    def test_run_passes_on_identical_code(self, indexed_equiv, fake_client, tmp_path):
        """Same code as old and new should generate tests successfully."""
        root, store = indexed_equiv
        gen = EquivalenceTestGenerator(store, fake_client)
        out = tmp_path / "equiv_out"
        result = gen.generate(root, root, out)
        assert result.total > 0
        assert isinstance(result, EquivalenceResult)
        for t in result.tests:
            assert t.status == "generated"
            assert Path(t.test_file).exists()

    def test_skipped_count_matches(self, indexed_equiv, fake_client, tmp_path):
        """Skipped count should reflect functions skipped due to I/O etc."""
        root, store = indexed_equiv
        gen = EquivalenceTestGenerator(store, fake_client)
        out = tmp_path / "equiv_out2"
        result = gen.generate(root, root, out)
        # We have some I/O functions that should be skipped
        assert result.skipped >= 0
        # total + skipped should cover a reasonable portion of public functions
        all_nodes = store.get_all_nodes()
        public_fns = [
            n for n in all_nodes
            if n.get("is_exported") and n["type"] in ("function", "method")
        ]
        assert result.total + result.skipped == len(public_fns)


# ---------------------------------------------------------------------------
# CLI test
# ---------------------------------------------------------------------------

class TestCLI:
    def test_cli_equiv_tests_command(self):
        """CLI command exists with correct options."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["equiv-tests", "--help"])
        assert result.exit_code == 0
        assert "equiv" in result.output.lower()
        assert "--output-dir" in result.output
        assert "--target-lang" in result.output
        assert "--provider" in result.output
        assert "--model" in result.output
        assert "new_project_path" in result.output.lower()
