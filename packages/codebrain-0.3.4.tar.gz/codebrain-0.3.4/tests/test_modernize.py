"""Tests for the modernization spec generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.modernize import SpecGenerator, ModernizationWorkflow


@pytest.fixture
def project(tmp_path: Path) -> tuple[Path, GraphStore]:
    """Create and index a sample project."""
    root = tmp_path / "myproject"
    pkg = root / "myapp"
    pkg.mkdir(parents=True)

    (pkg / "__init__.py").write_text(
        '"""My application."""\nfrom myapp.core import process\n'
    )

    (pkg / "core.py").write_text('''\
"""Core business logic."""
from myapp.utils import helper

__all__ = ["process", "DataProcessor"]

def process(data: dict) -> dict:
    """Process incoming data."""
    result = helper(data)
    return transform(result)

def transform(value):
    """Internal transform."""
    return value * 2

class DataProcessor:
    """Main processor class."""
    def __init__(self, config: dict):
        self.config = config

    def run(self, items: list) -> list:
        """Run processing on items."""
        return [process(i) for i in items]

    def validate(self, item):
        """Validate a single item."""
        return item is not None
''')

    (pkg / "utils.py").write_text('''\
"""Utility functions."""

__all__ = ["helper", "format_output"]

def helper(x):
    """Help with data transformation."""
    return x + 1

def format_output(data):
    """Format data for display."""
    return str(data)

def _internal():
    pass
''')

    (pkg / "models.py").write_text('''\
"""Data models."""
from dataclasses import dataclass

__all__ = ["Item", "SpecialItem"]

@dataclass
class Item:
    """A single item."""
    name: str
    value: int = 0

class SpecialItem(Item):
    """Extended item with compute."""
    def compute(self):
        return self.value * 10
''')

    (pkg / "api.py").write_text('''\
"""API endpoints."""
from myapp.core import process, DataProcessor
from myapp.models import Item

__all__ = ["handle_request"]

def handle_request(data):
    """Handle an incoming request."""
    item = Item(name="test", value=data.get("value", 0))
    return process({"item": item})
''')

    full_index(root)
    db = root / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db)
    yield root, store
    store.close()


@pytest.fixture
def rewritten_project(tmp_path: Path) -> tuple[Path, GraphStore]:
    """Create a partially rewritten project."""
    root = tmp_path / "new_project"
    pkg = root / "myapp"
    pkg.mkdir(parents=True)

    (pkg / "__init__.py").write_text(
        '"""My application v2."""\nfrom myapp.core import process\n'
    )

    (pkg / "core.py").write_text('''\
"""Core business logic v2."""
from myapp.utils import helper

__all__ = ["process", "DataProcessor"]

def process(data: dict) -> dict:
    """Process incoming data (v2)."""
    return helper(data)

class DataProcessor:
    """Main processor v2."""
    def __init__(self, config: dict):
        self.config = config

    def run(self, items: list) -> list:
        """Run processing on items."""
        return [process(i) for i in items]
''')

    (pkg / "utils.py").write_text('''\
"""Utilities v2."""

__all__ = ["helper"]

def helper(x):
    """Help with data transformation."""
    return x + 1
''')

    # models.py and api.py not yet rewritten

    full_index(root)
    db = root / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db)
    yield root, store
    store.close()


class TestSpecGenerator:
    """Tests for the spec generator."""

    def test_full_spec_structure(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        assert "project_name" in spec
        assert "system_context" in spec
        assert "rewrite_plan" in spec
        assert "module_specs" in spec
        assert spec["total_modules"] > 0

    def test_system_context(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        ctx = spec["system_context"]
        assert "health" in ctx
        assert ctx["health"]["score"] > 0
        assert "stats" in ctx
        assert ctx["stats"]["files"] > 0

    def test_rewrite_plan_has_phases(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        rp = spec["rewrite_plan"]
        assert rp["total_phases"] > 0
        assert len(rp["phase_order"]) > 0

    def test_module_spec_has_symbols(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        # Find core.py spec
        core_specs = [
            v for k, v in spec["module_specs"].items()
            if "core.py" in k
        ]
        assert len(core_specs) > 0
        core = core_specs[0]
        assert core["total_symbols"] > 0
        assert len(core["symbols"]) > 0

    def test_module_spec_has_contracts(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        # Find a module with contracts
        with_contracts = [
            v for v in spec["module_specs"].values()
            if v.get("contracts")
        ]
        assert len(with_contracts) > 0

    def test_module_spec_has_test_scenarios(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        all_scenarios = []
        for mod in spec["module_specs"].values():
            all_scenarios.extend(mod.get("test_scenarios", []))
        assert len(all_scenarios) > 0
        # Check scenario structure
        for s in all_scenarios:
            assert "name" in s
            assert "type" in s
            assert "checks" in s

    def test_module_spec_has_rewrite_notes(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        all_notes = []
        for mod in spec["module_specs"].values():
            all_notes.extend(mod.get("rewrite_notes", []))
        assert len(all_notes) > 0

    def test_module_spec_structure(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        for mod in spec["module_specs"].values():
            assert "dependencies" in mod
            assert "dependents" in mod
            assert "dependency_count" in mod
            assert "dependent_count" in mod
            assert isinstance(mod["dependencies"], list)
            assert isinstance(mod["dependents"], list)

    def test_single_module_spec(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_module_spec("myapp/core.py")
        assert spec["file_path"] == "myapp/core.py"
        assert spec["total_symbols"] > 0
        assert "symbols" in spec
        assert "test_scenarios" in spec

    def test_single_module_not_found(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_module_spec("nonexistent.py")
        assert "error" in spec

    def test_target_stack_in_spec(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec(target_stack="FastAPI + SQLAlchemy + React")
        assert spec["target_stack"] == "FastAPI + SQLAlchemy + React"

    def test_guidelines_in_spec(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec(guidelines="Use async/await everywhere")
        assert spec["guidelines"] == "Use async/await everywhere"

    def test_to_markdown(self, project):
        _, store = project
        gen = SpecGenerator(store)
        md = gen.to_markdown()
        assert "# Modernization Spec" in md
        assert "## Overview" in md
        assert "## Rewrite Plan" in md
        assert "## Module Specs" in md
        assert "## Test Strategy" in md

    def test_markdown_includes_target_stack(self, project):
        _, store = project
        gen = SpecGenerator(store)
        md = gen.to_markdown(target_stack="Django + PostgreSQL")
        assert "Django + PostgreSQL" in md

    def test_role_detection(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        roles = {v["role"] for v in spec["module_specs"].values()}
        # Should detect at least some roles
        assert len(roles) > 1

    def test_exported_symbols_marked(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        all_symbols = [
            s for mod in spec["module_specs"].values()
            for s in mod["symbols"]
        ]
        exported = [s for s in all_symbols if s["is_exported"]]
        assert len(exported) > 0

    def test_class_specs_have_methods(self, project):
        _, store = project
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        all_symbols = [
            s for mod in spec["module_specs"].values()
            for s in mod["symbols"]
        ]
        classes = [s for s in all_symbols if s["type"] == "class"]
        classes_with_methods = [c for c in classes if c.get("methods")]
        assert len(classes_with_methods) > 0


class TestModernizationWorkflow:
    """Tests for the full modernization workflow."""

    def test_generate_spec(self, project):
        root, store = project
        workflow = ModernizationWorkflow(root, store)
        md = workflow.step1_generate_spec()
        assert isinstance(md, str)
        assert "# Modernization Spec" in md

    def test_generate_spec_json(self, project):
        root, store = project
        workflow = ModernizationWorkflow(root, store)
        result = workflow.step1_generate_spec(output_format="json")
        assert isinstance(result, dict)
        assert "module_specs" in result

    def test_track_progress(self, project, rewritten_project):
        root, old_store = project
        _, new_store = rewritten_project
        workflow = ModernizationWorkflow(root, old_store)
        result = workflow.step2_track_progress(new_store)
        assert "summary" in result
        assert result["summary"]["migrated"] > 0
        assert result["summary"]["pending"] > 0

    def test_equivalence_report(self, project, rewritten_project):
        root, old_store = project
        _, new_store = rewritten_project
        workflow = ModernizationWorkflow(root, old_store)
        md = workflow.step3_equivalence_report(new_store)
        assert isinstance(md, str)
        assert "Migration" in md

    def test_equivalence_report_json(self, project, rewritten_project):
        root, old_store = project
        _, new_store = rewritten_project
        workflow = ModernizationWorkflow(root, old_store)
        result = workflow.step3_equivalence_report(new_store, output_format="json")
        assert isinstance(result, dict)
        assert "migration_status" in result
        assert "structural_diff" in result
