"""Tests for KT document and video generators."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.kt import KTGenerator
from codebrain.kt_video import KTVideoGenerator


@pytest.fixture
def kt_store(indexed_project: tuple[Path, GraphStore]):
    """Return the store from the indexed_project fixture."""
    _, store = indexed_project
    return store


class TestKTDocument:
    """Tests for the Markdown KT document generator."""

    def test_generates_markdown(self, kt_store: GraphStore):
        gen = KTGenerator(kt_store)
        doc = gen.generate(project_name="TestProject")
        assert "# TestProject — Knowledge Transfer Document" in doc

    def test_contains_all_sections(self, kt_store: GraphStore):
        gen = KTGenerator(kt_store)
        doc = gen.generate(project_name="TestProject")
        assert "## Executive Summary" in doc
        assert "## Architecture Overview" in doc
        assert "## Package Structure" in doc
        assert "## Architectural Layers" in doc
        assert "## Key Components & Risk Hotspots" in doc
        assert "## Health Assessment" in doc
        assert "## Module Details" in doc
        assert "## Recommendations" in doc

    def test_contains_mermaid_diagrams(self, kt_store: GraphStore):
        gen = KTGenerator(kt_store)
        doc = gen.generate(project_name="TestProject")
        assert "```mermaid" in doc
        assert "graph LR" in doc or "graph TB" in doc

    def test_contains_stats_table(self, kt_store: GraphStore):
        gen = KTGenerator(kt_store)
        doc = gen.generate(project_name="TestProject")
        assert "| Metric | Value |" in doc
        assert "| Files |" in doc
        assert "| Symbols |" in doc

    def test_health_dimensions_clean(self, kt_store: GraphStore):
        """Health dimensions should show clean numbers, not dict repr."""
        gen = KTGenerator(kt_store)
        doc = gen.generate(project_name="TestProject")
        # Should NOT contain raw dict representation
        assert "{'score'" not in doc
        # Should contain clean score format
        assert "/100 |" in doc

    def test_auto_names_project(self, kt_store: GraphStore):
        gen = KTGenerator(kt_store)
        doc = gen.generate()
        # Should pick 'mypackage', not 'tests' or '(root)'
        assert "# mypackage" in doc or "# " in doc

    def test_no_module_details(self, kt_store: GraphStore):
        gen = KTGenerator(kt_store)
        doc = gen.generate(project_name="X", include_module_details=False)
        assert "## Module Details" not in doc

    def test_custom_hotspot_count(self, kt_store: GraphStore):
        gen = KTGenerator(kt_store)
        doc = gen.generate(project_name="X", max_hotspots=2)
        # Should work with fewer hotspots
        assert "## Key Components" in doc

    def test_codebrain_attribution(self, kt_store: GraphStore):
        gen = KTGenerator(kt_store)
        doc = gen.generate(project_name="X")
        assert "CodeBrain" in doc
        assert "auto-generated from static analysis" in doc


class TestKTVideo:
    """Tests for the Remotion video project generator."""

    def test_generates_project_structure(self, kt_store: GraphStore, tmp_path: Path):
        gen = KTVideoGenerator(kt_store)
        out = gen.generate(tmp_path / "video", project_name="TestProject")
        assert (out / "package.json").exists()
        assert (out / "remotion.config.ts").exists()
        assert (out / "src" / "index.tsx").exists()
        assert (out / "src" / "Root.tsx").exists()
        assert (out / "src" / "KTVideo.tsx").exists()
        assert (out / "src" / "props.ts").exists()
        assert (out / "src" / "styles.ts").exists()

    def test_generates_scene_components(self, kt_store: GraphStore, tmp_path: Path):
        gen = KTVideoGenerator(kt_store)
        out = gen.generate(tmp_path / "video", project_name="TestProject")
        scenes_dir = out / "src" / "scenes"
        assert (scenes_dir / "TitleScene.tsx").exists()
        assert (scenes_dir / "ArchitectureScene.tsx").exists()
        assert (scenes_dir / "HotspotsScene.tsx").exists()
        assert (scenes_dir / "HealthScene.tsx").exists()
        assert (scenes_dir / "RecommendationsScene.tsx").exists()
        assert (scenes_dir / "index.ts").exists()

    def test_props_contain_project_data(self, kt_store: GraphStore, tmp_path: Path):
        import json
        gen = KTVideoGenerator(kt_store)
        out = gen.generate(tmp_path / "video", project_name="TestProject")
        props_content = (out / "src" / "props.ts").read_text()
        assert '"projectName": "TestProject"' in props_content
        assert '"files":' in props_content
        assert '"symbols":' in props_content
        assert '"hotspots":' in props_content
        assert '"health":' in props_content

    def test_package_json_valid(self, kt_store: GraphStore, tmp_path: Path):
        import json
        gen = KTVideoGenerator(kt_store)
        out = gen.generate(tmp_path / "video", project_name="TestProject")
        pkg = json.loads((out / "package.json").read_text())
        assert "remotion" in pkg["dependencies"]
        assert "react" in pkg["dependencies"]
        assert "render" in pkg["scripts"]

    def test_auto_names_project(self, kt_store: GraphStore, tmp_path: Path):
        gen = KTVideoGenerator(kt_store)
        out = gen.generate(tmp_path / "video")
        props_content = (out / "src" / "props.ts").read_text()
        # Should auto-detect a name, not be empty
        assert '"projectName": ""' not in props_content

    def test_custom_hotspot_count(self, kt_store: GraphStore, tmp_path: Path):
        gen = KTVideoGenerator(kt_store)
        out = gen.generate(tmp_path / "video", project_name="X", max_hotspots=2)
        props_content = (out / "src" / "props.ts").read_text()
        assert '"hotspots":' in props_content
