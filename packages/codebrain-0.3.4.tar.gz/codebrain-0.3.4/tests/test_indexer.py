"""Tests for the indexer orchestrator."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.graph.store import GraphStore
from codebrain.indexer import discover_files, full_index, incremental_update


class TestDiscoverFiles:
    def test_finds_python_files(self, simple_project: Path) -> None:
        files = discover_files(simple_project)
        suffixes = {f.suffix for f in files}
        assert suffixes == {".py"}

    def test_skips_pycache(self, simple_project: Path) -> None:
        cache_dir = simple_project / "mypackage" / "__pycache__"
        cache_dir.mkdir()
        (cache_dir / "core.cpython-311.pyc").write_text("bytecode")
        (cache_dir / "cached.py").write_text("x = 1")

        files = discover_files(simple_project)
        paths = [str(f) for f in files]
        assert not any("__pycache__" in p for p in paths)

    def test_skips_venv(self, simple_project: Path) -> None:
        venv_dir = simple_project / ".venv" / "lib"
        venv_dir.mkdir(parents=True)
        (venv_dir / "some_lib.py").write_text("x = 1")

        files = discover_files(simple_project)
        paths = [str(f) for f in files]
        assert not any(".venv" in p for p in paths)

    def test_respects_gitignore(self, simple_project: Path) -> None:
        (simple_project / ".gitignore").write_text("generated.py\n")
        (simple_project / "generated.py").write_text("x = 1")

        files = discover_files(simple_project)
        names = [f.name for f in files]
        assert "generated.py" not in names


class TestFullIndex:
    def test_indexes_simple_project(self, simple_project: Path) -> None:
        result = full_index(simple_project)
        assert result["files_parsed"] == 4  # __init__, core, utils, models
        assert result["total_nodes"] > 0
        assert result["total_edges"] > 0
        assert result["errors"] == []

    def test_creates_db_file(self, simple_project: Path) -> None:
        full_index(simple_project)
        db_path = simple_project / CODEBRAIN_DIR / DB_FILENAME
        assert db_path.exists()

    def test_stats_after_index(self, simple_project: Path) -> None:
        full_index(simple_project)
        db_path = simple_project / CODEBRAIN_DIR / DB_FILENAME
        store = GraphStore(db_path)
        stats = store.get_stats()
        store.close()

        assert stats["files"] == 4
        assert stats["nodes"] >= 8
        assert stats["edges"] >= 5


class TestIncrementalUpdate:
    def test_update_changed_file(self, indexed_project: tuple[Path, GraphStore]) -> None:
        repo_root, store = indexed_project

        # Modify a file
        core = repo_root / "mypackage" / "core.py"
        core.write_text("def new_func():\n    pass\n")

        result = incremental_update(
            repo_root, changed_files=[core], deleted_files=[], store=store
        )
        assert result["files_updated"] == 1

        # Verify the new function is in the store
        nodes = store.get_nodes_by_name("new_func")
        assert len(nodes) == 1
        store.close()

    def test_delete_file(self, indexed_project: tuple[Path, GraphStore]) -> None:
        repo_root, store = indexed_project

        utils = repo_root / "mypackage" / "utils.py"
        utils.unlink()

        result = incremental_update(
            repo_root, changed_files=[], deleted_files=[utils], store=store
        )
        assert result["files_removed"] == 1

        nodes = store.get_nodes_by_file("mypackage/utils.py")
        assert nodes == []
        store.close()

    def test_skip_unchanged_file(self, indexed_project: tuple[Path, GraphStore]) -> None:
        repo_root, store = indexed_project

        core = repo_root / "mypackage" / "core.py"
        # Don't modify it — hash should match
        result = incremental_update(
            repo_root, changed_files=[core], deleted_files=[], store=store
        )
        assert result["files_updated"] == 0
        store.close()
