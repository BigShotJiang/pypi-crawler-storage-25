"""Tests for cross-repo dependency tracking.

Tests cover:
- CrossRegistry: register, unregister, list, resolve, package detection
- CrossQueryEngine: dependency_graph, cross_impact, find_external_consumers
- CLI: brain cross register/list/deps/impact
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from codebrain.cross_registry import CrossRegistry, detect_packages
from codebrain.cross_query import CrossQueryEngine
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_python_repo(root: Path, package_name: str, files: dict[str, str]) -> Path:
    """Create a minimal Python repo with given files."""
    pkg_dir = root / package_name
    pkg_dir.mkdir(parents=True, exist_ok=True)
    (pkg_dir / "__init__.py").write_text("", encoding="utf-8")
    for name, content in files.items():
        (pkg_dir / name).write_text(content, encoding="utf-8")
    # Create pyproject.toml
    (root / "pyproject.toml").write_text(
        f'[project]\nname = "{package_name}"\nversion = "0.1.0"\n',
        encoding="utf-8",
    )
    return root


def _index_repo(repo_path: Path, db_dir: Path) -> Path:
    """Index a repo and return the DB path."""
    db_path = db_dir / f"{repo_path.name}.db"
    full_index(repo_path, db_path)
    return db_path


# ---------------------------------------------------------------------------
# Package Detection
# ---------------------------------------------------------------------------

class TestPackageDetection:

    def test_detect_python_pyproject(self, tmp_path):
        """Should detect package from pyproject.toml."""
        repo = tmp_path / "mylib"
        repo.mkdir()
        (repo / "pyproject.toml").write_text(
            '[project]\nname = "my-awesome-lib"\nversion = "1.0"\n',
            encoding="utf-8",
        )
        packages = detect_packages(repo)
        assert "my_awesome_lib" in packages

    def test_detect_python_init(self, tmp_path):
        """Should detect package from __init__.py directory."""
        repo = tmp_path / "repo"
        repo.mkdir()
        pkg = repo / "coolpkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("", encoding="utf-8")
        packages = detect_packages(repo)
        assert "coolpkg" in packages

    def test_detect_node_package(self, tmp_path):
        """Should detect package from package.json."""
        repo = tmp_path / "node-repo"
        repo.mkdir()
        (repo / "package.json").write_text(
            '{"name": "@company/shared-types", "version": "1.0.0"}',
            encoding="utf-8",
        )
        packages = detect_packages(repo)
        assert "@company/shared-types" in packages

    def test_detect_go_module(self, tmp_path):
        """Should detect package from go.mod."""
        repo = tmp_path / "go-repo"
        repo.mkdir()
        (repo / "go.mod").write_text(
            "module github.com/company/myservice\n\ngo 1.21\n",
            encoding="utf-8",
        )
        packages = detect_packages(repo)
        assert "github.com/company/myservice" in packages
        assert "myservice" in packages

    def test_detect_rust_cargo(self, tmp_path):
        """Should detect package from Cargo.toml."""
        repo = tmp_path / "rust-repo"
        repo.mkdir()
        (repo / "Cargo.toml").write_text(
            '[package]\nname = "my_crate"\nversion = "0.1.0"\n',
            encoding="utf-8",
        )
        packages = detect_packages(repo)
        assert "my_crate" in packages

    def test_fallback_to_dirname(self, tmp_path):
        """Should fall back to directory name if nothing else detected."""
        repo = tmp_path / "mystery-repo"
        repo.mkdir()
        packages = detect_packages(repo)
        assert "mystery-repo" in packages


# ---------------------------------------------------------------------------
# CrossRegistry
# ---------------------------------------------------------------------------

class TestCrossRegistry:

    @pytest.fixture
    def registry(self, tmp_path):
        db = tmp_path / "test_registry.db"
        reg = CrossRegistry(db)
        yield reg
        reg.close()

    def test_register_and_list(self, registry, tmp_path):
        """Register a repo and list it."""
        repo = tmp_path / "myrepo"
        repo.mkdir()
        pkg = repo / "mylib"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("", encoding="utf-8")
        db_path = repo / ".codebrain" / "graph.db"

        slug = registry.register(repo, db_path=db_path)
        assert slug == "myrepo"

        repos = registry.list_repos()
        assert len(repos) == 1
        assert repos[0]["slug"] == "myrepo"
        assert "mylib" in repos[0]["packages"]

    def test_unregister(self, registry, tmp_path):
        """Unregister removes the repo."""
        repo = tmp_path / "repo"
        repo.mkdir()
        registry.register(repo)
        assert len(registry.list_repos()) == 1

        assert registry.unregister("repo") is True
        assert len(registry.list_repos()) == 0
        assert registry.unregister("repo") is False

    def test_get_repo(self, registry, tmp_path):
        """Get a specific repo by slug."""
        repo = tmp_path / "target"
        repo.mkdir()
        registry.register(repo)

        info = registry.get_repo("target")
        assert info is not None
        assert info["slug"] == "target"

        assert registry.get_repo("nonexistent") is None

    def test_resolve_package_dotted(self, registry, tmp_path):
        """Resolve a dotted import like 'mylib.utils.helper'."""
        repo = tmp_path / "myrepo"
        repo.mkdir()
        pkg = repo / "mylib"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("", encoding="utf-8")
        db_path = repo / ".codebrain" / "graph.db"

        registry.register(repo, db_path=db_path)
        result = registry.resolve_package("mylib.utils.helper")
        assert len(result) > 0
        assert result[0]["slug"] == "myrepo"

    def test_resolve_package_exact(self, registry, tmp_path):
        """Resolve an exact package name."""
        repo = tmp_path / "repo"
        repo.mkdir()
        pkg = repo / "coolpkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("", encoding="utf-8")

        registry.register(repo)
        result = registry.resolve_package("coolpkg")
        assert len(result) > 0

    def test_resolve_package_no_match(self, registry):
        """No match returns empty list."""
        result = registry.resolve_package("nonexistent.package")
        assert result == []

    def test_multiple_repos(self, registry, tmp_path):
        """Register multiple repos and list them."""
        for name in ("repo_a", "repo_b", "repo_c"):
            d = tmp_path / name
            d.mkdir()
            registry.register(d)

        repos = registry.list_repos()
        assert len(repos) == 3
        slugs = {r["slug"] for r in repos}
        assert slugs == {"repo_a", "repo_b", "repo_c"}

    def test_custom_slug(self, registry, tmp_path):
        """Register with a custom slug."""
        repo = tmp_path / "my-really-long-repo-name"
        repo.mkdir()
        slug = registry.register(repo, slug="short")
        assert slug == "short"
        assert registry.get_repo("short") is not None


# ---------------------------------------------------------------------------
# CrossQueryEngine
# ---------------------------------------------------------------------------

class TestCrossQueryEngine:

    @pytest.fixture
    def two_repos(self, tmp_path):
        """Create two Python repos where repo_b imports from repo_a."""
        # Repo A: provides "libA" package
        repo_a = tmp_path / "repo_a"
        _make_python_repo(repo_a, "libA", {
            "core.py": "def important_function():\n    return 42\n\nclass CoreModel:\n    pass\n",
            "utils.py": "def helper():\n    return 'help'\n",
        })

        # Repo B: imports from libA
        repo_b = tmp_path / "repo_b"
        _make_python_repo(repo_b, "libB", {
            "service.py": (
                "from libA.core import important_function\n"
                "from libA.utils import helper\n\n"
                "def my_service():\n"
                "    result = important_function()\n"
                "    return helper()\n"
            ),
            "api.py": (
                "from libA.core import CoreModel\n\n"
                "def get_model():\n"
                "    return CoreModel()\n"
            ),
        })

        # Index both
        db_dir = tmp_path / "dbs"
        db_dir.mkdir()
        db_a = _index_repo(repo_a, db_dir)
        db_b = _index_repo(repo_b, db_dir)

        # Registry
        reg_db = tmp_path / "registry.db"
        reg = CrossRegistry(reg_db)
        reg.register(repo_a, slug="repo_a", db_path=db_a)
        reg.register(repo_b, slug="repo_b", db_path=db_b)

        return {
            "registry": reg,
            "repo_a": repo_a,
            "repo_b": repo_b,
            "db_a": db_a,
            "db_b": db_b,
        }

    def test_dependency_graph(self, two_repos):
        """Should detect that repo_b depends on repo_a."""
        engine = CrossQueryEngine(two_repos["registry"])
        result = engine.dependency_graph()

        assert len(result["repos"]) == 2
        assert len(result["edges"]) >= 1

        # Find the edge from repo_b -> repo_a
        edge = None
        for e in result["edges"]:
            if e["source"] == "repo_b" and e["target"] == "repo_a":
                edge = e
                break
        assert edge is not None, f"No edge from repo_b to repo_a. Edges: {result['edges']}"
        assert edge["import_count"] > 0
        two_repos["registry"].close()

    def test_cross_impact(self, two_repos):
        """Changing important_function in repo_a should show impact in repo_b."""
        engine = CrossQueryEngine(two_repos["registry"])
        result = engine.cross_impact("repo_a", "important_function")

        assert result["origin_repo"] == "repo_a"
        assert result["total_affected"] > 0
        assert "narrative" in result
        two_repos["registry"].close()

    def test_cross_impact_file_level(self, two_repos):
        """Cross impact by file path should work."""
        engine = CrossQueryEngine(two_repos["registry"])
        result = engine.cross_impact("repo_a", "libA/core.py")

        assert result["origin_repo"] == "repo_a"
        assert len(result["internal_impact"]) >= 0  # At least the file's own symbols
        two_repos["registry"].close()

    def test_find_external_consumers(self, two_repos):
        """Should find repo_b as consumer of important_function."""
        engine = CrossQueryEngine(two_repos["registry"])
        consumers = engine.find_external_consumers("repo_a", "important_function")

        # repo_b imports important_function from libA
        assert len(consumers) > 0
        consumer_repos = {c["repo_slug"] for c in consumers}
        assert "repo_b" in consumer_repos
        two_repos["registry"].close()

    def test_find_unresolved_imports(self, two_repos):
        """repo_b's imports of libA should resolve (not unresolved)."""
        engine = CrossQueryEngine(two_repos["registry"])
        unresolved = engine.find_unresolved_imports("repo_b")

        # libA imports should NOT be in unresolved
        liba_unresolved = [u for u in unresolved if "libA" in u["target"]]
        assert len(liba_unresolved) == 0, \
            f"libA imports should be resolved: {liba_unresolved}"
        two_repos["registry"].close()

    def test_no_external_impact_for_internal_only(self, two_repos):
        """Changing something only used internally should not affect other repos."""
        engine = CrossQueryEngine(two_repos["registry"])
        # helper is imported by repo_b, but let's test something truly internal
        result = engine.cross_impact("repo_b", "my_service")
        # my_service is in repo_b, not imported by anyone
        assert result["origin_repo"] == "repo_b"
        two_repos["registry"].close()

    def test_dependency_graph_narrative(self, two_repos):
        """Narrative should mention the dependency."""
        engine = CrossQueryEngine(two_repos["registry"])
        result = engine.dependency_graph()
        assert "repo_b" in result["narrative"]
        assert "repo_a" in result["narrative"]
        two_repos["registry"].close()


# ---------------------------------------------------------------------------
# CLI Integration
# ---------------------------------------------------------------------------

class TestCrossCLI:

    def test_cross_register_and_list(self, tmp_path):
        """brain cross register + brain cross list."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        import os
        reg_db = str(tmp_path / "registry.db")

        repo = tmp_path / "myrepo"
        repo.mkdir()
        pkg = repo / "mypkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")

        runner = CliRunner()

        env = {"CODEBRAIN_REGISTRY_PATH": reg_db}
        result = runner.invoke(cli, ["cross", "register", str(repo)], env=env)
        assert result.exit_code == 0, result.output
        assert "Registered" in result.output

        result = runner.invoke(cli, ["cross", "list"], env=env)
        assert result.exit_code == 0, result.output
        assert "myrepo" in result.output

    def test_cross_list_json(self, tmp_path):
        """brain cross list --json."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        reg_db = str(tmp_path / "registry.db")
        repo = tmp_path / "testrepo"
        repo.mkdir()

        runner = CliRunner()
        env = {"CODEBRAIN_REGISTRY_PATH": reg_db}
        runner.invoke(cli, ["cross", "register", str(repo)], env=env)
        result = runner.invoke(cli, ["cross", "list", "--json"], env=env)
        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        assert len(data) == 1

    def test_cross_unregister(self, tmp_path):
        """brain cross unregister."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        reg_db = str(tmp_path / "registry.db")
        repo = tmp_path / "temp"
        repo.mkdir()

        runner = CliRunner()
        env = {"CODEBRAIN_REGISTRY_PATH": reg_db}
        runner.invoke(cli, ["cross", "register", str(repo)], env=env)
        result = runner.invoke(cli, ["cross", "unregister", "temp"], env=env)
        assert result.exit_code == 0
        assert "Unregistered" in result.output

    def test_cross_deps(self, tmp_path):
        """brain cross deps."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        reg_db = str(tmp_path / "registry.db")

        runner = CliRunner()
        env = {"CODEBRAIN_REGISTRY_PATH": reg_db}
        result = runner.invoke(cli, ["cross", "deps"], env=env)
        assert result.exit_code == 0
        assert "dependency graph" in result.output.lower() or "0 repos" in result.output


# ---------------------------------------------------------------------------
# Real Repo Integration (uses test repos if available)
# ---------------------------------------------------------------------------

import os as _os
_TEMP = Path(_os.environ.get("TEMP", _os.environ.get("TMP", "/tmp")))
REPOS_ROOT = _TEMP / "codebrain-test-repos"

_has_petclinic = (REPOS_ROOT / "spring-petclinic").exists()
_has_saleor = (REPOS_ROOT / "saleor").exists()


@pytest.mark.skipif(not (_has_petclinic and _has_saleor),
                    reason="need both petclinic and saleor cloned")
class TestCrossRepoRealRepos:

    @pytest.fixture(scope="class")
    def setup(self, tmp_path_factory):
        """Register and index petclinic and saleor."""
        tmp = tmp_path_factory.mktemp("cross_real")
        reg_db = tmp / "registry.db"
        reg = CrossRegistry(reg_db)

        # Index both repos
        pc_db = tmp / "petclinic.db"
        sal_db = tmp / "saleor.db"
        full_index(REPOS_ROOT / "spring-petclinic", pc_db)
        full_index(REPOS_ROOT / "saleor", sal_db)

        reg.register(REPOS_ROOT / "spring-petclinic", slug="petclinic", db_path=pc_db)
        reg.register(REPOS_ROOT / "saleor", slug="saleor", db_path=sal_db)

        yield {"registry": reg, "pc_db": pc_db, "sal_db": sal_db}
        reg.close()

    def test_real_dependency_graph(self, setup):
        """Dependency graph should work on real repos."""
        engine = CrossQueryEngine(setup["registry"])
        result = engine.dependency_graph()
        assert len(result["repos"]) == 2
        assert "narrative" in result

    def test_real_cross_impact(self, setup):
        """Cross impact should not crash on real repos."""
        engine = CrossQueryEngine(setup["registry"])
        # Pick a symbol from saleor
        result = engine.cross_impact("saleor", "saleor/graphql/core/types/common.py")
        assert "origin_repo" in result
        assert "narrative" in result
