"""M9: TypeScript AST parser via tree-sitter.

Validates the tree-sitter TS parser finds real symbols in extension.ts.
"""

from __future__ import annotations

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).parent.parent

try:
    from codebrain.parser.typescript_treesitter import TypeScriptTreeSitterParser, _TS_AVAILABLE
except ImportError:
    _TS_AVAILABLE = False

pytestmark = pytest.mark.skipif(not _TS_AVAILABLE, reason="tree-sitter-languages not installed")


@pytest.fixture
def parser():
    return TypeScriptTreeSitterParser()


class TestVSCodeExtensionParsing:
    """Parse the VS Code extension's extension.ts — a real TS file."""

    def test_finds_activate_and_deactivate(self, parser):
        ext = REPO_ROOT / "vscode-extension" / "src" / "extension.ts"
        if not ext.exists():
            pytest.skip("extension.ts not found")
        result = parser.parse(ext, REPO_ROOT)
        names = {n.name for n in result.nodes}
        assert "activate" in names, f"Should find activate. Found: {names}"
        assert "deactivate" in names, f"Should find deactivate. Found: {names}"

    def test_finds_more_than_regex(self, parser):
        """Tree-sitter should find >10 symbols (regex finds ~2.4)."""
        ext = REPO_ROOT / "vscode-extension" / "src" / "extension.ts"
        if not ext.exists():
            pytest.skip("extension.ts not found")
        result = parser.parse(ext, REPO_ROOT)
        non_file = [n for n in result.nodes if n.type != "file"]
        assert len(non_file) >= 10, f"Should find >=10 symbols, got {len(non_file)}"

    def test_creates_imports_edges(self, parser):
        ext = REPO_ROOT / "vscode-extension" / "src" / "extension.ts"
        if not ext.exists():
            pytest.skip("extension.ts not found")
        result = parser.parse(ext, REPO_ROOT)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        assert len(imports) > 0, "Should find import edges"

    def test_creates_calls_edges(self, parser):
        ext = REPO_ROOT / "vscode-extension" / "src" / "extension.ts"
        if not ext.exists():
            pytest.skip("extension.ts not found")
        result = parser.parse(ext, REPO_ROOT)
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert len(calls) > 0, "Should find call edges"

    def test_exported_functions_marked(self, parser):
        ext = REPO_ROOT / "vscode-extension" / "src" / "extension.ts"
        if not ext.exists():
            pytest.skip("extension.ts not found")
        result = parser.parse(ext, REPO_ROOT)
        exported = [n for n in result.nodes if n.is_exported and n.type != "file"]
        assert len(exported) >= 2, "activate and deactivate should be exported"


class TestSyntheticTS:

    def test_parse_class_with_methods(self, parser, tmp_path):
        ts_file = tmp_path / "test.ts"
        ts_file.write_text("""
export class MyService {
    constructor(private db: Database) {}

    async getUser(id: string): Promise<User> {
        return this.db.findOne(id);
    }

    deleteUser(id: string): void {
        this.db.delete(id);
    }
}
""", encoding="utf-8")
        result = parser.parse(ts_file, tmp_path)
        names = {n.name for n in result.nodes}
        assert "MyService" in names
        assert "__init__" in names  # constructor mapped to __init__
        assert "getUser" in names
        assert "deleteUser" in names

    def test_parse_arrow_functions(self, parser, tmp_path):
        ts_file = tmp_path / "test.ts"
        ts_file.write_text("""
export const add = (a: number, b: number): number => a + b;
const multiply = (a: number, b: number) => { return a * b; };
""", encoding="utf-8")
        result = parser.parse(ts_file, tmp_path)
        names = {n.name for n in result.nodes}
        assert "add" in names
        assert "multiply" in names

    def test_parse_interface(self, parser, tmp_path):
        ts_file = tmp_path / "test.ts"
        ts_file.write_text("""
export interface UserRepository {
    findById(id: string): Promise<User>;
    save(user: User): Promise<void>;
}
""", encoding="utf-8")
        result = parser.parse(ts_file, tmp_path)
        names = {n.name for n in result.nodes}
        assert "UserRepository" in names

    def test_parse_enum(self, parser, tmp_path):
        ts_file = tmp_path / "test.ts"
        ts_file.write_text("""
export enum Status {
    Active = 'active',
    Inactive = 'inactive',
}
""", encoding="utf-8")
        result = parser.parse(ts_file, tmp_path)
        names = {n.name for n in result.nodes}
        assert "Status" in names
