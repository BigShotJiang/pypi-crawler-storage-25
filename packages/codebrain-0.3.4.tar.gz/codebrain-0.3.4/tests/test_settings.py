"""Tests for settings loading."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from codebrain.settings import Settings, load_settings


class TestDefaults:
    def test_default_settings(self):
        s = Settings()
        assert s.codebrain_dir == ".codebrain"
        assert s.db_filename == "graph.db"
        assert ".py" in s.indexable_extensions
        assert s.parallel_threshold == 50
        assert s.max_workers is None
        assert s.watcher_debounce == 0.3

    def test_db_path_property(self):
        s = Settings()
        assert s.db_path == ".codebrain/graph.db"


class TestLoadNoConfig:
    def test_load_without_repo(self):
        s = load_settings(None)
        assert isinstance(s, Settings)
        assert s.parallel_threshold == 50

    def test_load_with_empty_dir(self, tmp_path):
        s = load_settings(tmp_path)
        assert isinstance(s, Settings)
        assert s.parallel_threshold == 50


class TestLoadToml:
    def test_load_toml(self, tmp_path):
        toml = tmp_path / ".codebrain.toml"
        toml.write_text(
            '[codebrain]\n'
            'parallel_threshold = 100\n'
            'watcher_debounce = 0.5\n'
            'extensions = [".py", ".rb"]\n'
            'skip_dirs = ["vendor", "tmp"]\n'
        )
        s = load_settings(tmp_path)
        assert s.parallel_threshold == 100
        assert s.watcher_debounce == 0.5
        assert ".rb" in s.indexable_extensions
        assert "vendor" in s.skip_dirs

    def test_toml_partial_override(self, tmp_path):
        toml = tmp_path / ".codebrain.toml"
        toml.write_text(
            '[codebrain]\n'
            'parallel_threshold = 200\n'
        )
        s = load_settings(tmp_path)
        assert s.parallel_threshold == 200
        # Other fields keep defaults
        assert ".py" in s.indexable_extensions


class TestEnvOverrides:
    def test_env_overrides_toml(self, tmp_path, monkeypatch):
        toml = tmp_path / ".codebrain.toml"
        toml.write_text(
            '[codebrain]\n'
            'parallel_threshold = 100\n'
        )
        monkeypatch.setenv("CODEBRAIN_PARALLEL_THRESHOLD", "999")
        s = load_settings(tmp_path)
        assert s.parallel_threshold == 999

    def test_env_skip_dirs(self, tmp_path, monkeypatch):
        monkeypatch.setenv("CODEBRAIN_SKIP_DIRS", "vendor,tmp")
        s = load_settings(tmp_path)
        assert s.skip_dirs == frozenset({"vendor", "tmp"})

    def test_env_extensions(self, tmp_path, monkeypatch):
        monkeypatch.setenv("CODEBRAIN_EXTENSIONS", ".py,.go")
        s = load_settings(tmp_path)
        assert s.indexable_extensions == frozenset({".py", ".go"})

    def test_env_debounce(self, tmp_path, monkeypatch):
        monkeypatch.setenv("CODEBRAIN_DEBOUNCE", "1.5")
        s = load_settings(tmp_path)
        assert s.watcher_debounce == 1.5

    def test_env_max_workers(self, tmp_path, monkeypatch):
        monkeypatch.setenv("CODEBRAIN_MAX_WORKERS", "4")
        s = load_settings(tmp_path)
        assert s.max_workers == 4


class TestPrecedence:
    def test_env_beats_toml_beats_default(self, tmp_path, monkeypatch):
        toml = tmp_path / ".codebrain.toml"
        toml.write_text(
            '[codebrain]\n'
            'parallel_threshold = 100\n'
            'max_workers = 8\n'
        )
        monkeypatch.setenv("CODEBRAIN_PARALLEL_THRESHOLD", "500")
        s = load_settings(tmp_path)
        # Env wins over toml
        assert s.parallel_threshold == 500
        # Toml wins over default
        assert s.max_workers == 8
