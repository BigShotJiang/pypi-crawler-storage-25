"""Tests for cross-language translation pipeline (SPEC-M34)."""
from __future__ import annotations

import os
import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from codebrain.rewriter import (
    BUILD_TOOLS,
    TARGET_EXTENSIONS,
    TRANSLATION_WARNINGS,
    BuildResult,
    LLMResponse,
    RewriteEngine,
    _build_translation_system_prompt,
    _detect_build_cmd,
    _detect_construct_warnings,
    _parse_compiler_errors,
    _run_build,
    _scaffold_project,
    _target_file_path_for_lang,
)


# ---------------------------------------------------------------------------
# T1: Translation prompt & construct warnings
# ---------------------------------------------------------------------------


class TestTranslationPrompt:
    def test_prompt_specifies_source_and_target_lang(self):
        prompt = _build_translation_system_prompt("python", "go", "", "")
        assert "python" in prompt.lower() or "Python" in prompt
        assert "go" in prompt.lower() or "Go" in prompt
        assert "translat" in prompt.lower()

    def test_prompt_includes_target_stack(self):
        prompt = _build_translation_system_prompt("python", "go", "gin", "")
        assert "gin" in prompt.lower() or "Gin" in prompt

    def test_prompt_preserves_api_names(self):
        prompt = _build_translation_system_prompt("python", "java", "", "")
        assert "public API" in prompt or "function/class names" in prompt

    def test_prompt_includes_guidelines(self):
        prompt = _build_translation_system_prompt("python", "rust", "", "use tokio for async")
        assert "tokio" in prompt

    def test_prompt_warns_about_manual_review(self):
        prompt = _build_translation_system_prompt("java", "go", "", "")
        assert "manual review" in prompt.lower() or "WARNING" in prompt


class TestConstructWarnings:
    def test_detects_generators(self):
        code = "def gen():\n    yield 1\n    yield 2\n"
        warnings = _detect_construct_warnings(code, "python", "go")
        assert any("generator" in w.lower() for w in warnings)

    def test_detects_decorators(self):
        code = "@app.route('/foo')\ndef handler():\n    pass\n"
        warnings = _detect_construct_warnings(code, "python", "java")
        assert any("decorator" in w.lower() for w in warnings)

    def test_detects_metaclass(self):
        code = "class Meta(type, metaclass=ABCMeta):\n    pass\n"
        warnings = _detect_construct_warnings(code, "python", "go")
        assert any("metaclass" in w.lower() for w in warnings)

    def test_detects_context_managers(self):
        code = "with open('f') as fp:\n    data = fp.read()\n"
        warnings = _detect_construct_warnings(code, "python", "go")
        assert any("context manager" in w.lower() for w in warnings)

    def test_detects_async(self):
        code = "async def fetch():\n    await get_data()\n"
        warnings = _detect_construct_warnings(code, "python", "rust")
        assert any("async" in w.lower() for w in warnings)

    def test_detects_variadic(self):
        code = "def func(*args, **kwargs):\n    pass\n"
        warnings = _detect_construct_warnings(code, "python", "go")
        assert any("variadic" in w.lower() for w in warnings)

    def test_no_warnings_for_clean_code(self):
        code = "def add(a, b):\n    return a + b\n"
        warnings = _detect_construct_warnings(code, "python", "go")
        assert len(warnings) == 0

    def test_java_streams_warning(self):
        code = "list.stream().filter(x -> x > 0).collect(Collectors.toList());"
        warnings = _detect_construct_warnings(code, "java", "go")
        assert any("stream" in w.lower() for w in warnings)

    def test_typescript_utility_types(self):
        code = "type Props = Partial<Config> & Required<Base>;"
        warnings = _detect_construct_warnings(code, "typescript", "go")
        assert any("utility type" in w.lower() for w in warnings)

    def test_unknown_source_lang_returns_empty(self):
        warnings = _detect_construct_warnings("anything", "cobol", "java")
        assert warnings == []

    def test_warning_includes_direction(self):
        code = "def gen():\n    yield 1\n"
        warnings = _detect_construct_warnings(code, "python", "go")
        # Should contain [python->go] prefix
        assert any("python" in w and "go" in w for w in warnings)


# ---------------------------------------------------------------------------
# T1: File extension mapping
# ---------------------------------------------------------------------------


class TestTargetFilePath:
    def test_python_to_go(self):
        assert _target_file_path_for_lang("module/utils.py", "go") == "module/utils.go"

    def test_python_to_java(self):
        assert _target_file_path_for_lang("src/app.py", "java") == "src/app.java"

    def test_python_to_kotlin(self):
        assert _target_file_path_for_lang("main.py", "kotlin") == "main.kt"

    def test_python_to_rust(self):
        assert _target_file_path_for_lang("lib.py", "rust") == "lib.rs"

    def test_python_to_typescript(self):
        assert _target_file_path_for_lang("api.py", "typescript") == "api.ts"

    def test_python_to_csharp(self):
        assert _target_file_path_for_lang("service.py", "csharp") == "service.cs"

    def test_unknown_lang_returns_original(self):
        assert _target_file_path_for_lang("file.py", "brainfuck") == "file.py"

    def test_preserves_directory_structure(self):
        result = _target_file_path_for_lang("src/pkg/handler.py", "go")
        assert result == "src/pkg/handler.go"


# ---------------------------------------------------------------------------
# T2: Build verification
# ---------------------------------------------------------------------------


class TestDetectBuildCmd:
    @patch("shutil.which", return_value="/usr/bin/go")
    def test_detects_go(self, mock_which):
        cmd, tool = _detect_build_cmd("go", Path("/tmp/out"))
        assert cmd == ["go", "build", "./..."]
        assert tool == "go"

    @patch("shutil.which", return_value=None)
    def test_missing_tool_returns_empty(self, mock_which):
        cmd, tool = _detect_build_cmd("go", Path("/tmp/out"))
        assert cmd == []
        assert tool == ""

    @patch("shutil.which", return_value="/usr/bin/cargo")
    def test_detects_rust(self, mock_which):
        cmd, tool = _detect_build_cmd("rust", Path("/tmp/out"))
        assert cmd == ["cargo", "build"]
        assert tool == "cargo"

    @patch("shutil.which", return_value="/usr/bin/tsc")
    def test_detects_typescript(self, mock_which):
        cmd, tool = _detect_build_cmd("typescript", Path("/tmp/out"))
        assert cmd == ["tsc", "--noEmit"]
        assert tool == "tsc"

    def test_unknown_lang_returns_empty(self):
        cmd, tool = _detect_build_cmd("brainfuck", Path("/tmp/out"))
        assert cmd == []
        assert tool == ""

    @patch("shutil.which", return_value="/usr/bin/mvn")
    def test_java_maven(self, mock_which, tmp_path):
        (tmp_path / "pom.xml").write_text("<project/>")
        cmd, tool = _detect_build_cmd("java", tmp_path)
        assert "mvn" in cmd
        assert tool == "mvn"

    @patch("shutil.which", return_value="/usr/bin/gradle")
    def test_java_gradle(self, mock_which, tmp_path):
        (tmp_path / "build.gradle").write_text("apply plugin: 'java'")
        cmd, tool = _detect_build_cmd("java", tmp_path)
        assert "gradle" in cmd
        assert tool == "gradle"


class TestScaffoldProject:
    def test_creates_go_mod(self, tmp_path):
        _scaffold_project("go", tmp_path)
        go_mod = tmp_path / "go.mod"
        assert go_mod.exists()
        assert "module translated" in go_mod.read_text()

    def test_creates_cargo_toml(self, tmp_path):
        _scaffold_project("rust", tmp_path)
        cargo = tmp_path / "Cargo.toml"
        assert cargo.exists()
        assert "translated" in cargo.read_text()

    def test_creates_tsconfig(self, tmp_path):
        _scaffold_project("typescript", tmp_path)
        tsconfig = tmp_path / "tsconfig.json"
        assert tsconfig.exists()
        assert "strict" in tsconfig.read_text()

    def test_does_not_overwrite_existing(self, tmp_path):
        go_mod = tmp_path / "go.mod"
        go_mod.write_text("module myapp\n")
        _scaffold_project("go", tmp_path)
        assert "myapp" in go_mod.read_text()

    def test_unknown_lang_does_nothing(self, tmp_path):
        _scaffold_project("brainfuck", tmp_path)
        assert list(tmp_path.iterdir()) == []


class TestParseCompilerErrors:
    def test_go_errors(self):
        stderr = "main.go:10:5: undefined: SomeFunc\nmain.go:15:3: cannot find module\n"
        errors = _parse_compiler_errors(stderr, "go")
        assert len(errors) == 2
        assert "undefined" in errors[0]

    def test_java_errors(self):
        stderr = "App.java:10: error: cannot find symbol\n  symbol: variable foo\n"
        errors = _parse_compiler_errors(stderr, "java")
        assert any("cannot find symbol" in e for e in errors)

    def test_rust_errors(self):
        stderr = "error[E0425]: cannot find value `x` in this scope\n --> src/main.rs:5:5\n"
        errors = _parse_compiler_errors(stderr, "rust")
        assert any("cannot find value" in e for e in errors)

    def test_empty_stderr(self):
        errors = _parse_compiler_errors("", "go")
        assert errors == []

    def test_caps_at_20(self):
        stderr = "\n".join(f"file.go:{i}: error: something" for i in range(50))
        errors = _parse_compiler_errors(stderr, "go")
        assert len(errors) == 20


class TestRunBuild:
    @patch("codebrain.rewriter._detect_build_cmd", return_value=([], ""))
    def test_missing_toolchain(self, mock_detect, tmp_path):
        result = _run_build(tmp_path, "go")
        assert not result.success
        assert result.build_tool == "none"
        assert any("not found" in e for e in result.errors)

    @patch("codebrain.rewriter._detect_build_cmd", return_value=(["go", "build", "./..."], "go"))
    @patch("subprocess.run")
    def test_successful_build(self, mock_run, mock_detect, tmp_path):
        mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="")
        result = _run_build(tmp_path, "go")
        assert result.success
        assert result.build_tool == "go"

    @patch("codebrain.rewriter._detect_build_cmd", return_value=(["go", "build", "./..."], "go"))
    @patch("subprocess.run")
    def test_failed_build(self, mock_run, mock_detect, tmp_path):
        mock_run.return_value = MagicMock(
            returncode=1,
            stderr="main.go:5:3: undefined: Foo\n",
            stdout="",
        )
        result = _run_build(tmp_path, "go")
        assert not result.success
        assert any("undefined" in e for e in result.errors)

    @patch("codebrain.rewriter._detect_build_cmd", return_value=(["cargo", "build"], "cargo"))
    @patch("subprocess.run", side_effect=TimeoutError)
    def test_build_timeout(self, mock_run, mock_detect, tmp_path):
        import subprocess as sp
        with patch("subprocess.run", side_effect=sp.TimeoutExpired(cmd="cargo", timeout=120)):
            result = _run_build(tmp_path, "rust", timeout=120)
        assert not result.success
        assert any("timed out" in e.lower() for e in result.errors)


# ---------------------------------------------------------------------------
# T1+T2: RewriteEngine integration
# ---------------------------------------------------------------------------


class TestRewriteEngineTranslation:
    """Integration tests using mocked LLM."""

    def _make_project(self, tmp_path):
        """Create a minimal Python project for testing."""
        src = tmp_path / "src"
        src.mkdir()
        (src / "app.py").write_text(textwrap.dedent("""\
            def greet(name: str) -> str:
                return f"Hello, {name}!"

            def add(a: int, b: int) -> int:
                return a + b

            class Calculator:
                def multiply(self, x: int, y: int) -> int:
                    return x * y
        """))
        return src

    def _make_store(self, src_path):
        """Create a GraphStore and index the project."""
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index

        db_path = src_path / ".codebrain" / "codebrain.db"
        db_path.parent.mkdir(parents=True, exist_ok=True)
        full_index(src_path, db_path)
        store = GraphStore(str(db_path))
        store.__enter__()
        return store

    def test_target_lang_stored(self, tmp_path):
        src = self._make_project(tmp_path)
        store = self._make_store(src)
        try:
            client = MagicMock()
            engine = RewriteEngine(
                old_root=src, store=store, client=client, target_lang="go",
            )
            assert engine.target_lang == "go"
        finally:
            store.close()

    def test_empty_target_lang_is_same_language(self, tmp_path):
        src = self._make_project(tmp_path)
        store = self._make_store(src)
        try:
            client = MagicMock()
            engine = RewriteEngine(
                old_root=src, store=store, client=client, target_lang="",
            )
            assert engine.target_lang == ""
        finally:
            store.close()

    def test_translate_module_changes_extension(self, tmp_path):
        src = self._make_project(tmp_path)
        store = self._make_store(src)
        out = tmp_path / "out"
        out.mkdir()

        go_code = textwrap.dedent("""\
            package main

            import "fmt"

            // greet translates from Python greet()
            func greet(name string) string {
                return fmt.Sprintf("Hello, %s!", name)
            }

            // add translates from Python add()
            func add(a, b int) int {
                return a + b
            }

            // Calculator translates from Python Calculator class
            type Calculator struct{}

            func (c *Calculator) multiply(x, y int) int {
                return x * y
            }
        """)

        client = MagicMock()
        client.complete.return_value = LLMResponse(content=go_code)
        client.is_available.return_value = True

        try:
            engine = RewriteEngine(
                old_root=src, store=store, client=client, target_lang="go",
            )
            result = engine.rewrite_module(
                "app.py", output_dir=out,
            )
            # Should produce .go file
            assert result.file_path.endswith(".go")
            assert (out / result.file_path).exists()
        finally:
            store.close()

    def test_translate_preserves_contracts(self, tmp_path):
        """Translated code must contain all exported symbol names."""
        src = self._make_project(tmp_path)
        store = self._make_store(src)

        # Go code that preserves the API names
        go_code = textwrap.dedent("""\
            package main

            func greet(name string) string { return name }
            func add(a, b int) int { return a + b }
            type Calculator struct{}
            func (c *Calculator) multiply(x, y int) int { return x * y }
        """)

        client = MagicMock()
        client.complete.return_value = LLMResponse(content=go_code)

        try:
            engine = RewriteEngine(
                old_root=src, store=store, client=client, target_lang="go",
            )
            result = engine.rewrite_module("app.py")
            # The validate_rewrite checks should pass for exported symbols
            assert result.status in ("success", "partial")
        finally:
            store.close()

    def test_detect_source_lang(self, tmp_path):
        src = self._make_project(tmp_path)
        store = self._make_store(src)
        try:
            client = MagicMock()
            engine = RewriteEngine(
                old_root=src, store=store, client=client, target_lang="go",
            )
            lang = engine._detect_source_lang()
            assert lang == "python"
        finally:
            store.close()

    def test_detect_lang_for_file(self):
        assert RewriteEngine._detect_lang_for_file("app.py") == "python"
        assert RewriteEngine._detect_lang_for_file("Main.java") == "java"
        assert RewriteEngine._detect_lang_for_file("lib.rs") == "rust"
        assert RewriteEngine._detect_lang_for_file("index.ts") == "typescript"
        assert RewriteEngine._detect_lang_for_file("app.go") == "go"
        assert RewriteEngine._detect_lang_for_file("Service.kt") == "kotlin"


# ---------------------------------------------------------------------------
# T3: CLI tests
# ---------------------------------------------------------------------------


class TestTranslateCLI:
    def test_translate_command_exists(self):
        """The translate command should be registered."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["translate", "--help"])
        assert result.exit_code == 0
        assert "--target-lang" in result.output
        assert "--target-stack" in result.output
        assert "--dry-run" in result.output

    def test_translate_requires_target_lang(self):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["translate", "-o", "/tmp/out"])
        assert result.exit_code != 0
        assert "target-lang" in result.output.lower() or "Missing" in result.output

    def test_translate_requires_output_dir(self):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["translate", "--target-lang", "go"])
        assert result.exit_code != 0

    def test_translate_validates_target_lang_choices(self):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, [
            "translate", "-o", "/tmp/out", "--target-lang", "brainfuck",
        ])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Constants tests
# ---------------------------------------------------------------------------


class TestConstants:
    def test_target_extensions_complete(self):
        assert "go" in TARGET_EXTENSIONS
        assert "java" in TARGET_EXTENSIONS
        assert "kotlin" in TARGET_EXTENSIONS
        assert "rust" in TARGET_EXTENSIONS
        assert "typescript" in TARGET_EXTENSIONS
        assert "csharp" in TARGET_EXTENSIONS
        assert "python" in TARGET_EXTENSIONS

    def test_build_tools_complete(self):
        assert "go" in BUILD_TOOLS
        assert "java" in BUILD_TOOLS
        assert "rust" in BUILD_TOOLS
        assert "typescript" in BUILD_TOOLS
        assert "csharp" in BUILD_TOOLS

    def test_translation_warnings_have_python(self):
        assert "python" in TRANSLATION_WARNINGS
        assert len(TRANSLATION_WARNINGS["python"]) >= 5

    def test_translation_warnings_patterns_are_valid_regex(self):
        import re
        for lang, patterns in TRANSLATION_WARNINGS.items():
            for pattern in patterns:
                re.compile(pattern)  # Should not raise
