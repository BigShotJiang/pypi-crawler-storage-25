"""Real-world frontend validation tests.

Tests CodeBrain's frontend awareness on actual GitHub projects:
1. React Redux RealWorld — old Redux connect(), JSX routes
2. Admin One Vue Tailwind — Vue Router multi-line objects, lazy imports
3. Material Kit React — React Router v6, modern patterns
4. Tailwind Landing Page — Next.js/React components
5. TodoMVC React — simple React app

Each test indexes the project, runs frontend enrichment, and checks
components, routes, state management, and API calls.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

# All tests require real repos to be cloned
PROJECTS_ROOT = Path(r"C:\Users\ASUS\PycharmProjects")

# Project paths
REACT_REDUX_RW = PROJECTS_ROOT / "react-redux-rw"
ADMIN_VUE = PROJECTS_ROOT / "admin-one-vue-tailwind"
MATERIAL_KIT = PROJECTS_ROOT / "material-kit-react"
TAILWIND_LANDING = PROJECTS_ROOT / "tailwind-landing"
TODOMVC = PROJECTS_ROOT / "todomvc"

pytestmark = pytest.mark.skipif(
    not REACT_REDUX_RW.exists(),
    reason="Real-world projects not cloned",
)


def _index_and_enrich(project_path: Path, tmp_path: Path):
    """Index a project and run frontend enrichment. Return (store, result)."""
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import full_index
    from codebrain.parser.frontend_parser import FrontendComponentParser

    db = tmp_path / ".codebrain" / "graph.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    full_index(project_path, db)

    store = GraphStore(db)
    parser = FrontendComponentParser(store, repo_root=project_path)
    result = parser.enrich()

    return store, result


def _get_edge_counts(store):
    """Return dict of edge type → count."""
    from collections import Counter
    edges = store.get_all_edges()
    return Counter(e["type"] for e in edges)


def _get_node_counts(store):
    """Return dict of node type → count."""
    from collections import Counter
    nodes = store.get_all_nodes()
    return Counter(n["type"] for n in nodes)


# ===========================================================================
# Project 1: React Redux RealWorld (old connect() pattern)
# ===========================================================================


class TestReactReduxRealWorld:
    """React Redux RealWorld — connect(mapState, mapDispatch)(Component)."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        if not REACT_REDUX_RW.exists():
            pytest.skip("react-redux-rw not cloned")
        self.store, self.result = _index_and_enrich(REACT_REDUX_RW, tmp_path)
        yield
        self.store.close()

    def test_finds_components(self):
        """Should detect 10+ React components."""
        counts = _get_node_counts(self.store)
        components = counts.get("component", 0)
        print(f"Components found: {components}")
        assert components >= 5, f"Only {components} components found"

    def test_finds_renders_edges(self):
        """Should create RENDERS edges between parent/child components."""
        counts = _get_edge_counts(self.store)
        renders = counts.get("RENDERS", 0)
        print(f"RENDERS edges: {renders}")
        assert renders >= 10, f"Only {renders} RENDERS edges"

    def test_finds_routes(self):
        """Should detect route definitions (JSX <Route /> pattern)."""
        counts = _get_node_counts(self.store)
        routes = counts.get("route", 0)
        print(f"Routes found: {routes}")
        assert routes >= 5, f"Only {routes} routes found"

    def test_finds_state_management(self):
        """Should detect connect() SUBSCRIBES and DISPATCHES."""
        counts = _get_edge_counts(self.store)
        subs = counts.get("SUBSCRIBES", 0)
        dispatches = counts.get("DISPATCHES", 0)
        print(f"SUBSCRIBES: {subs}, DISPATCHES: {dispatches}")
        # M31 should now detect these from connect()
        assert subs >= 5, f"Only {subs} SUBSCRIBES edges"
        assert dispatches >= 3, f"Only {dispatches} DISPATCHES edges"

    def test_connect_attributes_to_component(self):
        """SUBSCRIBES/DISPATCHES should be sourced from components, not function names."""
        edges = self.store.get_all_edges()
        state_edges = [
            e for e in edges
            if e["type"] in ("SUBSCRIBES", "DISPATCHES")
        ]
        for e in state_edges:
            source = e["source"]
            # Should NOT be sourced from "mapStateToProps" or "mapDispatchToProps"
            assert "mapState" not in source, f"Edge sourced from mapState: {e}"
            assert "mapDispatch" not in source, f"Edge sourced from mapDispatch: {e}"

    def test_api_calls_detected(self):
        """Should find API fetch calls."""
        counts = _get_edge_counts(self.store)
        fetches = counts.get("FETCHES", 0)
        print(f"FETCHES: {fetches}")
        # This project uses agent.js for API calls
        assert fetches >= 0  # May or may not have direct fetch patterns

    def test_frontend_report(self):
        """FrontendAnalyzer generates a valid report."""
        from codebrain.frontend import FrontendAnalyzer

        analyzer = FrontendAnalyzer(self.store)
        report = analyzer.analyze()

        print(f"Total components: {report.total_components}")
        print(f"Total routes: {report.total_routes}")
        print(f"Total API endpoints: {report.total_api_endpoints}")
        print(f"Orphan components: {len(report.orphan_components)}")

        assert report.total_components >= 5
        d = report.to_dict()
        assert "component_tree" in d

    def test_multi_component_attribution(self):
        """Profile.js has 3 components — RENDERS attributed correctly (M30)."""
        edges = self.store.get_all_edges()
        renders = [e for e in edges if e["type"] == "RENDERS"]

        # Check that EditProfileSettings doesn't render FollowUserButton
        bad_edges = [
            e for e in renders
            if "EditProfileSettings" in e["source"]
            and e["target"] in ("FollowUserButton", "ArticleList", "Profile")
        ]
        assert len(bad_edges) == 0, f"Wrong attribution: {bad_edges}"


# ===========================================================================
# Project 2: Admin One Vue Tailwind (Vue Router, lazy imports)
# ===========================================================================


class TestAdminOneVueTailwind:
    """Admin One Vue Tailwind — Vue Router multi-line objects."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        if not ADMIN_VUE.exists():
            pytest.skip("admin-one-vue-tailwind not cloned")
        self.store, self.result = _index_and_enrich(ADMIN_VUE, tmp_path)
        yield
        self.store.close()

    def test_finds_components(self):
        """Should detect Vue components."""
        counts = _get_node_counts(self.store)
        components = counts.get("component", 0)
        print(f"Components found: {components}")
        assert components >= 5, f"Only {components} components"

    def test_finds_all_9_routes(self):
        """Should detect all 9 routes defined in router/index.js (M29 fix)."""
        counts = _get_node_counts(self.store)
        routes = counts.get("route", 0)
        print(f"Routes found: {routes}")
        # Previously: 2/9. After M29: should be 9/9
        assert routes >= 7, f"Only {routes}/9 routes found"

    def test_lazy_imports_resolved(self):
        """Lazy imports like () => import('@/views/X.vue') → component name."""
        edges = self.store.get_all_edges()
        routes_to = [e for e in edges if e["type"] == "ROUTES_TO"]
        targets = {e["target"] for e in routes_to}
        print(f"Route targets: {targets}")

        # These should be resolved from lazy imports
        expected_lazy = {"TablesView", "FormsView", "ProfileView", "UiView",
                        "ResponsiveView", "LoginView", "ErrorView"}
        found_lazy = expected_lazy & targets
        print(f"Lazy imports resolved: {found_lazy}")
        assert len(found_lazy) >= 5, f"Only {len(found_lazy)} lazy imports resolved"

    def test_direct_imports_resolved(self):
        """Direct component references like component: Home."""
        edges = self.store.get_all_edges()
        routes_to = [e for e in edges if e["type"] == "ROUTES_TO"]
        targets = {e["target"] for e in routes_to}

        # Style and Home are direct imports
        direct = {"Style", "Home"} & targets
        print(f"Direct imports resolved: {direct}")
        assert len(direct) >= 1, f"Direct imports not found in {targets}"

    def test_pinia_stores_detected(self):
        """Should detect Pinia stores (defineStore)."""
        counts = _get_node_counts(self.store)
        stores = counts.get("store", 0)
        print(f"Stores found: {stores}")
        # This project uses Pinia
        assert stores >= 0  # May have stores

    def test_renders_edges(self):
        """Should create RENDERS edges from Vue templates."""
        counts = _get_edge_counts(self.store)
        renders = counts.get("RENDERS", 0)
        print(f"RENDERS edges: {renders}")
        assert renders >= 5, f"Only {renders} RENDERS edges"

    def test_frontend_report(self):
        """FrontendAnalyzer generates a valid report."""
        from codebrain.frontend import FrontendAnalyzer

        analyzer = FrontendAnalyzer(self.store)
        report = analyzer.analyze()

        print(f"Total components: {report.total_components}")
        print(f"Total routes: {report.total_routes}")

        assert report.total_components >= 3
        assert report.total_routes >= 7


# ===========================================================================
# Project 3: Material Kit React (React Router v6, modern patterns)
# ===========================================================================


class TestMaterialKitReact:
    """Material Kit React — modern React with React Router."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        if not MATERIAL_KIT.exists():
            pytest.skip("material-kit-react not cloned")
        self.store, self.result = _index_and_enrich(MATERIAL_KIT, tmp_path)
        yield
        self.store.close()

    def test_finds_components(self):
        """Should detect React components."""
        counts = _get_node_counts(self.store)
        components = counts.get("component", 0)
        print(f"Components found: {components}")
        assert components >= 3, f"Only {components} components"

    def test_finds_routes(self):
        """Should detect route definitions."""
        counts = _get_node_counts(self.store)
        routes = counts.get("route", 0)
        counts_e = _get_edge_counts(self.store)
        routes_to = counts_e.get("ROUTES_TO", 0)
        print(f"Routes: {routes}, ROUTES_TO edges: {routes_to}")
        # Print any route info for debugging
        nodes = self.store.get_all_nodes()
        route_nodes = [n for n in nodes if n["type"] == "route"]
        for r in route_nodes:
            print(f"  Route: {r['name']} → {r.get('summary', '')}")

    def test_finds_renders(self):
        """Should create RENDERS edges."""
        counts = _get_edge_counts(self.store)
        renders = counts.get("RENDERS", 0)
        print(f"RENDERS: {renders}")
        assert renders >= 3, f"Only {renders} RENDERS edges"

    def test_overall_stats(self):
        """Print overall enrichment stats."""
        print(f"Enrichment result:")
        print(f"  RENDERS created: {self.result.renders_created}")
        print(f"  Props extracted: {self.result.props_extracted}")
        print(f"  Routes found: {self.result.routes_found}")
        print(f"  State edges: {self.result.state_edges}")
        print(f"  API calls: {self.result.api_calls}")
        print(f"  Components tagged: {self.result.components_tagged}")

        counts = _get_node_counts(self.store)
        counts_e = _get_edge_counts(self.store)
        print(f"\nNode counts: {dict(counts)}")
        print(f"Edge counts: {dict(counts_e)}")


# ===========================================================================
# Project 4: Tailwind Landing Page (React/Next.js components)
# ===========================================================================


class TestTailwindLanding:
    """Tailwind Landing Page — React component structure."""

    @pytest.fixture(autouse=True)
    def setup(self, tmp_path):
        if not TAILWIND_LANDING.exists():
            pytest.skip("tailwind-landing not cloned")
        self.store, self.result = _index_and_enrich(TAILWIND_LANDING, tmp_path)
        yield
        self.store.close()

    def test_finds_components(self):
        """Should detect components."""
        counts = _get_node_counts(self.store)
        components = counts.get("component", 0)
        print(f"Components found: {components}")
        assert components >= 2, f"Only {components} components"

    def test_finds_renders(self):
        """Should create RENDERS edges."""
        counts = _get_edge_counts(self.store)
        renders = counts.get("RENDERS", 0)
        print(f"RENDERS: {renders}")

    def test_overall_stats(self):
        """Print enrichment stats."""
        counts = _get_node_counts(self.store)
        counts_e = _get_edge_counts(self.store)
        print(f"Enrichment: renders={self.result.renders_created}, "
              f"routes={self.result.routes_found}, "
              f"components={self.result.components_tagged}")
        print(f"Node counts: {dict(counts)}")
        print(f"Edge counts: {dict(counts_e)}")


# ===========================================================================
# Summary: Run all and produce a report card
# ===========================================================================


class TestReportCard:
    """Aggregate test — produces a report card across all projects."""

    def test_generate_report_card(self, tmp_path):
        """Index all available projects and print a graded report card."""
        from codebrain.frontend import FrontendAnalyzer

        projects = [
            ("React Redux RealWorld", REACT_REDUX_RW),
            ("Admin One Vue Tailwind", ADMIN_VUE),
            ("Material Kit React", MATERIAL_KIT),
            ("Tailwind Landing", TAILWIND_LANDING),
        ]

        lines: list[str] = []
        lines.append("")
        lines.append("=" * 70)
        lines.append("CODEBRAIN FRONTEND AWARENESS REPORT CARD")
        lines.append("=" * 70)

        for name, path in projects:
            if not path.exists():
                lines.append(f"\n{name}: SKIPPED (not cloned)")
                continue

            try:
                db = tmp_path / name.replace(" ", "_") / "graph.db"
                db.parent.mkdir(parents=True, exist_ok=True)

                from codebrain.graph.store import GraphStore
                from codebrain.indexer import full_index
                from codebrain.parser.frontend_parser import FrontendComponentParser

                full_index(path, db)
                store = GraphStore(db)

                parser = FrontendComponentParser(store, repo_root=path)
                result = parser.enrich()

                analyzer = FrontendAnalyzer(store)
                report = analyzer.analyze()

                node_counts = _get_node_counts(store)
                edge_counts = _get_edge_counts(store)

                lines.append(f"\n{'-' * 50}")
                lines.append(f"  {name}")
                lines.append(f"{'-' * 50}")
                lines.append(f"  Files indexed:    {len(set(n['file_path'] for n in store.get_all_nodes()))}")
                lines.append(f"  Total nodes:      {sum(node_counts.values())}")
                lines.append(f"  Total edges:      {sum(edge_counts.values())}")
                lines.append(f"  Components:       {node_counts.get('component', 0)}")
                lines.append(f"  Routes:           {node_counts.get('route', 0)}")
                lines.append(f"  Stores:           {node_counts.get('store', 0)}")
                lines.append(f"  RENDERS:          {edge_counts.get('RENDERS', 0)}")
                lines.append(f"  ROUTES_TO:        {edge_counts.get('ROUTES_TO', 0)}")
                lines.append(f"  SUBSCRIBES:       {edge_counts.get('SUBSCRIBES', 0)}")
                lines.append(f"  DISPATCHES:       {edge_counts.get('DISPATCHES', 0)}")
                lines.append(f"  FETCHES:          {edge_counts.get('FETCHES', 0)}")
                lines.append(f"  PASSES_PROP:      {edge_counts.get('PASSES_PROP', 0)}")

                store.close()
            except Exception as e:
                import traceback
                lines.append(f"\n{name}: ERROR -- {e}")
                lines.append(traceback.format_exc())

        lines.append(f"\n{'=' * 70}")

        # Write to file to avoid Windows encoding issues
        report_file = tmp_path / "report_card.txt"
        report_file.write_text("\n".join(lines), encoding="utf-8")
        # Also assert so pytest shows it
        report_text = report_file.read_text(encoding="utf-8")
        assert "REPORT CARD" in report_text
        # Print safely
        for line in lines:
            sys.stdout.buffer.write((line + "\n").encode("utf-8", errors="replace"))
        sys.stdout.flush()
