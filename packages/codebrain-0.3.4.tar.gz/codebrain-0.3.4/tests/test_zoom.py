"""M13: Multi-resolution zoom — system, package, module, and symbol levels."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index


@pytest.fixture
def zoom_engine(tmp_path):
    """Create an indexed project and return a ComprehensionEngine."""
    root = tmp_path / "repo"
    root.mkdir()
    pkg = root / "mypkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "core.py").write_text(
        "def greet(name):\n    return f'hello {name}'\n\n"
        "def farewell(name):\n    return f'goodbye {name}'\n",
        encoding="utf-8",
    )
    (pkg / "cli.py").write_text(
        "from mypkg.core import greet\n\ndef main():\n    print(greet('world'))\n",
        encoding="utf-8",
    )
    (pkg / "utils.py").write_text(
        "def helper():\n    pass\n",
        encoding="utf-8",
    )
    # Sub-package for deeper hierarchy testing
    sub = pkg / "sub"
    sub.mkdir()
    (sub / "__init__.py").write_text("", encoding="utf-8")
    (sub / "deep.py").write_text(
        "from mypkg.core import farewell\n\ndef deep_fn():\n    return farewell('deep')\n",
        encoding="utf-8",
    )

    db = root / ".codebrain" / "graph.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    full_index(root, db)

    store = GraphStore(db)
    engine = ComprehensionEngine(store)
    yield engine
    store.close()


class TestZoom:

    def test_system_level(self, zoom_engine):
        result = zoom_engine.zoom()
        assert result["level"] == "system"
        assert "narrative" in result
        assert "drill_down" in result
        assert len(result["drill_down"]) > 0
        # System now drills into packages
        assert "zoom_out" in result  # present but None at top level

    def test_package_level(self, zoom_engine):
        result = zoom_engine.zoom("mypkg")
        assert result["level"] == "package"
        assert result["package"] == "mypkg"
        assert result["file_count"] >= 3  # __init__, core, cli, utils + sub files
        assert "files" in result
        assert len(result["files"]) >= 3
        # Each file has role, symbol_count, drill_down
        for f in result["files"]:
            assert "file_path" in f
            assert "role" in f
            assert "symbol_count" in f
            assert "drill_down" in f
        # Navigation hints
        assert "zoom_out" in result
        assert "drill_down" in result

    def test_package_returns_files_in_package(self, zoom_engine):
        """Package-level zoom returns all files belonging to the package."""
        result = zoom_engine.zoom("mypkg")
        file_paths = [f["file_path"] for f in result["files"]]
        assert any("core.py" in fp for fp in file_paths)
        assert any("cli.py" in fp for fp in file_paths)
        assert any("utils.py" in fp for fp in file_paths)

    def test_package_detects_sub_packages(self, zoom_engine):
        """Package view lists sub-packages."""
        result = zoom_engine.zoom("mypkg")
        assert "sub_packages" in result
        assert any("mypkg/sub" in sp for sp in result["sub_packages"])

    def test_module_level(self, zoom_engine):
        result = zoom_engine.zoom("mypkg/core.py")
        assert result["level"] == "module"
        assert result["file"] == "mypkg/core.py"
        assert "narrative" in result
        assert len(result["symbols"]) >= 2  # greet, farewell
        assert "zoom_out" in result
        # Module zoom_out should point to package
        assert result["zoom_out"]["target"] == "mypkg"

    def test_symbol_level(self, zoom_engine):
        result = zoom_engine.zoom("greet")
        assert result["level"] == "symbol"
        assert result["name"] == "greet"
        assert "narrative" in result
        assert "zoom_out" in result
        assert result["zoom_out"]["target"] == "mypkg/core.py"

    def test_symbol_not_found(self, zoom_engine):
        result = zoom_engine.zoom("nonexistent_symbol_xyz")
        assert result["level"] == "symbol"
        assert "error" in result

    def test_four_level_drill_down(self, zoom_engine):
        """Full 4-level drill-down: system -> package -> module -> symbol."""
        # Level 1: System
        system = zoom_engine.zoom()
        assert system["level"] == "system"
        assert len(system["drill_down"]) > 0

        # Level 2: Package (drill into first package)
        pkg_target = system["drill_down"][0]["target"]
        package = zoom_engine.zoom(pkg_target)
        assert package["level"] == "package"
        assert len(package["files"]) > 0

        # Level 3: Module (drill into first file)
        file_target = package["files"][0]["file_path"]
        module = zoom_engine.zoom(file_target)
        assert module["level"] == "module"
        assert len(module["symbols"]) > 0

        # Level 4: Symbol (drill into first symbol)
        sym_target = module["symbols"][0]["name"]
        symbol = zoom_engine.zoom(sym_target)
        assert symbol["level"] == "symbol"

    def test_navigation_hints_at_every_level(self, zoom_engine):
        """Every zoom level includes zoom_out and drill_down hints."""
        # System
        system = zoom_engine.zoom()
        assert "zoom_out" in system
        assert "drill_down" in system

        # Package
        package = zoom_engine.zoom("mypkg")
        assert "zoom_out" in package
        assert "drill_down" in package

        # Module
        module = zoom_engine.zoom("mypkg/core.py")
        assert "zoom_out" in module
        assert "drill_down" in module

        # Symbol
        symbol = zoom_engine.zoom("greet")
        assert "zoom_out" in symbol

    def test_drill_down_hints_are_valid(self, zoom_engine):
        system = zoom_engine.zoom()
        # System drill-down now points to packages
        if system["drill_down"]:
            target = system["drill_down"][0]["target"]
            result = zoom_engine.zoom(target)
            assert result["level"] == "package"

    def test_zoom_out_from_symbol(self, zoom_engine):
        symbol = zoom_engine.zoom("greet")
        zoom_out_target = symbol["zoom_out"]["target"]
        module = zoom_engine.zoom(zoom_out_target)
        assert module["level"] == "module"

    def test_zoom_out_from_module_to_package(self, zoom_engine):
        """Module zoom_out goes to the package level."""
        module = zoom_engine.zoom("mypkg/core.py")
        zoom_out_target = module["zoom_out"]["target"]
        package = zoom_engine.zoom(zoom_out_target)
        assert package["level"] == "package"

    def test_package_view_method(self, zoom_engine):
        """The public package_view() method works."""
        result = zoom_engine.package_view("mypkg")
        assert result["level"] == "package"
        assert result["file_count"] >= 3
