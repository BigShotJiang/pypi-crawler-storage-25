"""Tests for the multi-resolution comprehension engine."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME


@pytest.fixture
def comp_project(simple_project: Path) -> tuple[Path, GraphStore, ComprehensionEngine]:
    full_index(simple_project)
    db_path = simple_project / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db_path)
    engine = ComprehensionEngine(store)
    return simple_project, store, engine


class TestSystemOverview:
    def test_returns_stats(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.system_overview()
        assert "stats" in result
        assert result["stats"]["files"] > 0
        store.close()

    def test_discovers_packages(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.system_overview()
        assert "mypackage" in result["packages"]
        store.close()

    def test_package_has_node_count(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.system_overview()
        pkg = result["packages"]["mypackage"]
        assert pkg["node_count"] > 0
        assert pkg["file_count"] > 0
        store.close()


class TestModuleView:
    def test_module_view_returns_symbols(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_view("mypackage/core.py")
        assert len(result["symbols"]) > 0
        store.close()

    def test_module_view_has_imports(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_view("mypackage/core.py")
        assert len(result["imports"]) > 0
        store.close()

    def test_module_view_has_role(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_view("mypackage/utils.py")
        assert result["role"] == "utility"
        store.close()

    def test_module_view_has_coupling(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_view("mypackage/core.py")
        assert "coupling" in result
        assert isinstance(result["coupling"]["incoming"], int)
        store.close()

    def test_missing_module(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_view("nonexistent.py")
        assert "error" in result
        store.close()


class TestRiskHotspots:
    def test_returns_ranked_list(self, comp_project) -> None:
        _, store, engine = comp_project
        hotspots = engine.risk_hotspots()
        assert isinstance(hotspots, list)
        if len(hotspots) >= 2:
            assert hotspots[0]["risk_score"] >= hotspots[1]["risk_score"]
        store.close()

    def test_hotspot_has_fields(self, comp_project) -> None:
        _, store, engine = comp_project
        hotspots = engine.risk_hotspots()
        if hotspots:
            h = hotspots[0]
            assert "node_id" in h
            assert "risk_score" in h
            assert "direct_dependents" in h
        store.close()


class TestSystemNarrative:
    def test_returns_summary(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.system_narrative()
        assert "summary" in result
        assert isinstance(result["summary"], str)
        assert len(result["summary"]) > 0
        store.close()

    def test_has_architecture(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.system_narrative()
        assert "architecture" in result
        assert len(result["architecture"]) > 0
        store.close()

    def test_has_health_summary(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.system_narrative()
        assert "health_summary" in result
        assert "Health:" in result["health_summary"]
        store.close()

    def test_has_recommendations(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.system_narrative()
        assert "recommendations" in result
        assert isinstance(result["recommendations"], list)
        assert len(result["recommendations"]) > 0
        store.close()

    def test_has_key_components(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.system_narrative()
        assert "key_components" in result
        assert isinstance(result["key_components"], list)
        store.close()


class TestModuleNarrative:
    def test_returns_summary(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_narrative("mypackage/core.py")
        assert "summary" in result
        assert isinstance(result["summary"], str)
        assert len(result["summary"]) > 0
        store.close()

    def test_has_importance(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_narrative("mypackage/core.py")
        assert "importance" in result
        store.close()

    def test_has_dependencies(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_narrative("mypackage/core.py")
        assert "dependencies" in result
        store.close()

    def test_has_exports_summary(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_narrative("mypackage/core.py")
        assert "exports_summary" in result
        store.close()

    def test_missing_module(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_narrative("nonexistent.py")
        assert "error" in result
        store.close()


class TestSymbolNarrative:
    def test_returns_summary(self, comp_project) -> None:
        _, store, engine = comp_project
        # Find a node to test with
        nodes = store.get_all_nodes()
        symbol = next((n for n in nodes if n["type"] == "function"), None)
        if symbol:
            result = engine.symbol_narrative(symbol["id"])
            assert "summary" in result
            assert isinstance(result["summary"], str)
            assert len(result["summary"]) > 0
        store.close()

    def test_has_importance(self, comp_project) -> None:
        _, store, engine = comp_project
        nodes = store.get_all_nodes()
        symbol = next((n for n in nodes if n["type"] == "function"), None)
        if symbol:
            result = engine.symbol_narrative(symbol["id"])
            assert "importance" in result
        store.close()

    def test_has_usage(self, comp_project) -> None:
        _, store, engine = comp_project
        nodes = store.get_all_nodes()
        symbol = next((n for n in nodes if n["type"] == "function"), None)
        if symbol:
            result = engine.symbol_narrative(symbol["id"])
            assert "usage" in result
            assert "callers_summary" in result
            assert "dependencies" in result
        store.close()

    def test_missing_symbol(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.symbol_narrative("nonexistent::xyz")
        assert "error" in result
        store.close()


class TestHealthScore:
    def test_health_returns_score(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.health_score()
        assert "score" in result
        assert "grade" in result
        assert 0 <= result["score"] <= 100
        assert result["grade"] in ("A", "B", "C", "D", "F")
        store.close()

    def test_health_details(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.health_score()
        d = result["details"]
        assert "dead_code_count" in d
        assert "import_cycles" in d
        assert "high_risk_hotspots" in d
        store.close()


class TestChangeSummary:
    def test_change_summary(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.change_summary("mypackage/core.py")
        assert "affected_file_count" in result
        assert "affected_files" in result
        store.close()


class TestTestFileFiltering:
    """A2: Test files and test functions should not appear in risk hotspots."""

    def test_no_test_files_in_hotspots(self, store) -> None:
        from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode

        # Create a test file with a widely-called test helper
        store.upsert_file(ParsedFile(
            path="tests/test_core.py",
            content_hash="t1",
            line_count=30,
            nodes=[
                ParsedNode(id="tests/test_core.py::file", name="test_core", qualified_name="test_core",
                           type="file", file_path="tests/test_core.py", line_start=1, line_end=30, is_exported=True),
                ParsedNode(id="tests/test_core.py::test_helper", name="test_helper", qualified_name="test_helper",
                           type="function", file_path="tests/test_core.py", line_start=5, line_end=15, is_exported=True),
                ParsedNode(id="tests/test_core.py::TestSuite", name="TestSuite", qualified_name="TestSuite",
                           type="class", file_path="tests/test_core.py", line_start=18, line_end=28, is_exported=True),
            ],
            edges=[],
        ))
        # Create a real module that gets called
        store.upsert_file(ParsedFile(
            path="core.py",
            content_hash="c1",
            line_count=20,
            nodes=[
                ParsedNode(id="core.py::file", name="core", qualified_name="core",
                           type="file", file_path="core.py", line_start=1, line_end=20, is_exported=True),
                ParsedNode(id="core.py::main_func", name="main_func", qualified_name="main_func",
                           type="function", file_path="core.py", line_start=3, line_end=18, is_exported=True),
            ],
            edges=[],
        ))
        # Many files call both test_helper and main_func
        for i in range(5):
            store.upsert_file(ParsedFile(
                path=f"mod{i}.py",
                content_hash=f"m{i}",
                line_count=10,
                nodes=[
                    ParsedNode(id=f"mod{i}.py::file", name=f"mod{i}", qualified_name=f"mod{i}",
                               type="file", file_path=f"mod{i}.py", line_start=1, line_end=10, is_exported=True),
                    ParsedNode(id=f"mod{i}.py::fn{i}", name=f"fn{i}", qualified_name=f"fn{i}",
                               type="function", file_path=f"mod{i}.py", line_start=3, line_end=8, is_exported=True),
                ],
                edges=[
                    ParsedEdge(source=f"mod{i}.py::fn{i}", target="tests/test_core.py::test_helper",
                               type="CALLS", file_path=f"mod{i}.py", line=5),
                    ParsedEdge(source=f"mod{i}.py::fn{i}", target="core.py::main_func",
                               type="CALLS", file_path=f"mod{i}.py", line=6),
                ],
            ))

        comp = ComprehensionEngine(store)
        hotspots = comp.risk_hotspots(top_n=10)

        # No test files or test functions should appear
        for h in hotspots:
            assert not h["file_path"].startswith("tests/"), f"Test file in hotspots: {h['file_path']}"
            assert not h["name"].startswith("test_"), f"Test function in hotspots: {h['name']}"
            assert not h["name"].startswith("Test"), f"Test class in hotspots: {h['name']}"


class TestGenericNameFiltering:
    """Verify that generic method names (get, set, etc.) don't inflate hotspot scores."""

    def test_generic_name_not_over_scored(self, store) -> None:
        from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode

        # Create a class with a .get() method and many callers using bare "get"
        store.upsert_file(ParsedFile(
            path="cache.py",
            content_hash="c1",
            line_count=20,
            nodes=[
                ParsedNode(id="cache.py::cache", name="cache", qualified_name="cache", type="file",
                           file_path="cache.py", line_start=1, line_end=20, is_exported=True),
                ParsedNode(id="cache.py::Cache", name="Cache", qualified_name="Cache", type="class",
                           file_path="cache.py", line_start=3, line_end=18, is_exported=True),
                ParsedNode(id="cache.py::Cache.get", name="get", qualified_name="Cache.get", type="method",
                           file_path="cache.py", line_start=5, line_end=10),
            ],
            edges=[
                ParsedEdge(source="cache.py::Cache", target="cache.py::Cache.get", type="CONTAINS",
                           file_path="cache.py", line=5),
            ],
        ))
        # Create many files that call "get" (generic name, e.g. dict.get())
        for i in range(10):
            store.upsert_file(ParsedFile(
                path=f"user{i}.py",
                content_hash=f"u{i}",
                line_count=10,
                nodes=[
                    ParsedNode(id=f"user{i}.py::user{i}", name=f"user{i}", qualified_name=f"user{i}", type="file",
                               file_path=f"user{i}.py", line_start=1, line_end=10, is_exported=True),
                    ParsedNode(id=f"user{i}.py::func{i}", name=f"func{i}", qualified_name=f"func{i}", type="function",
                               file_path=f"user{i}.py", line_start=3, line_end=8, is_exported=True),
                ],
                edges=[
                    # These use bare "get" — should NOT be attributed to Cache.get
                    ParsedEdge(source=f"user{i}.py::func{i}", target="get", type="CALLS",
                               file_path=f"user{i}.py", line=5),
                ],
            ))

        comp = ComprehensionEngine(store)
        hotspots = comp.risk_hotspots(top_n=5)
        # Cache.get should either not appear or have a low score
        cache_get = [h for h in hotspots if h["node_id"] == "cache.py::Cache.get"]
        if cache_get:
            # The 10 bare "get" calls should NOT be counted as dependents
            assert cache_get[0]["direct_dependents"] < 5, (
                f"Cache.get has {cache_get[0]['direct_dependents']} dependents — "
                "generic name filtering is not working"
            )


class TestTestFileAtPathStartFiltered:
    """Test files at the start of the path (tests/foo.py) should be excluded from hotspots."""

    def test_test_files_at_path_start_filtered(self, store) -> None:
        from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode

        # Create a helper in tests/ (no leading slash)
        store.upsert_file(ParsedFile(
            path="tests/helpers.py",
            content_hash="th",
            line_count=10,
            nodes=[
                ParsedNode(id="tests/helpers.py::file", name="helpers", qualified_name="helpers",
                           type="file", file_path="tests/helpers.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="tests/helpers.py::make_fixture", name="make_fixture",
                           qualified_name="make_fixture", type="function",
                           file_path="tests/helpers.py", line_start=3, line_end=8, is_exported=True),
            ],
            edges=[],
        ))
        # Create prod module
        store.upsert_file(ParsedFile(
            path="app.py",
            content_hash="a1",
            line_count=10,
            nodes=[
                ParsedNode(id="app.py::file", name="app", qualified_name="app",
                           type="file", file_path="app.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="app.py::run", name="run", qualified_name="run",
                           type="function", file_path="app.py", line_start=3, line_end=8, is_exported=True),
            ],
            edges=[],
        ))
        # 5 callers for both
        for i in range(5):
            store.upsert_file(ParsedFile(
                path=f"mod{i}.py",
                content_hash=f"m{i}",
                line_count=10,
                nodes=[
                    ParsedNode(id=f"mod{i}.py::file", name=f"mod{i}", qualified_name=f"mod{i}",
                               type="file", file_path=f"mod{i}.py", line_start=1, line_end=10, is_exported=True),
                    ParsedNode(id=f"mod{i}.py::fn{i}", name=f"fn{i}", qualified_name=f"fn{i}",
                               type="function", file_path=f"mod{i}.py", line_start=3, line_end=8, is_exported=True),
                ],
                edges=[
                    ParsedEdge(source=f"mod{i}.py::fn{i}", target="tests/helpers.py::make_fixture",
                               type="CALLS", file_path=f"mod{i}.py", line=5),
                    ParsedEdge(source=f"mod{i}.py::fn{i}", target="app.py::run",
                               type="CALLS", file_path=f"mod{i}.py", line=6),
                ],
            ))

        comp = ComprehensionEngine(store)
        hotspots = comp.risk_hotspots(top_n=10)

        for h in hotspots:
            assert not h["file_path"].startswith("tests/"), (
                f"Test file 'tests/helpers.py' leaked into hotspots: {h}"
            )


class TestBareNameCallersFromTestsExcluded:
    """Callers from test files should not inflate hotspot scores via bare-name matching."""

    def test_bare_name_callers_from_tests_excluded(self, store) -> None:
        from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode

        # Production function
        store.upsert_file(ParsedFile(
            path="core.py",
            content_hash="c1",
            line_count=10,
            nodes=[
                ParsedNode(id="core.py::file", name="core", qualified_name="core",
                           type="file", file_path="core.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="core.py::compute", name="compute", qualified_name="compute",
                           type="function", file_path="core.py", line_start=3, line_end=8, is_exported=True),
            ],
            edges=[],
        ))
        # 1 real caller
        store.upsert_file(ParsedFile(
            path="app.py",
            content_hash="a1",
            line_count=10,
            nodes=[
                ParsedNode(id="app.py::file", name="app", qualified_name="app",
                           type="file", file_path="app.py", line_start=1, line_end=10, is_exported=True),
                ParsedNode(id="app.py::main", name="main", qualified_name="main",
                           type="function", file_path="app.py", line_start=3, line_end=8, is_exported=True),
            ],
            edges=[
                ParsedEdge(source="app.py::main", target="compute", type="CALLS",
                           file_path="app.py", line=5),
            ],
        ))
        # 10 test callers using bare name "compute"
        for i in range(10):
            store.upsert_file(ParsedFile(
                path=f"tests/test_core_{i}.py",
                content_hash=f"t{i}",
                line_count=10,
                nodes=[
                    ParsedNode(id=f"tests/test_core_{i}.py::file", name=f"test_core_{i}",
                               qualified_name=f"test_core_{i}", type="file",
                               file_path=f"tests/test_core_{i}.py", line_start=1, line_end=10, is_exported=True),
                    ParsedNode(id=f"tests/test_core_{i}.py::test_fn{i}", name=f"test_fn{i}",
                               qualified_name=f"test_fn{i}", type="function",
                               file_path=f"tests/test_core_{i}.py", line_start=3, line_end=8),
                ],
                edges=[
                    ParsedEdge(source=f"tests/test_core_{i}.py::test_fn{i}", target="compute",
                               type="CALLS", file_path=f"tests/test_core_{i}.py", line=5),
                ],
            ))

        comp = ComprehensionEngine(store)
        hotspots = comp.risk_hotspots(top_n=10)

        compute = [h for h in hotspots if h["name"] == "compute"]
        if compute:
            # Should only count the 1 real caller, not the 10 test callers
            assert compute[0]["direct_dependents"] <= 2, (
                f"compute has {compute[0]['direct_dependents']} dependents — "
                "test callers are inflating the score"
            )


class TestModuleNarrativeTopCallers:
    """module_narrative() should include top_callers field."""

    def test_module_narrative_has_top_callers(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.module_narrative("mypackage/utils.py")
        assert "top_callers" in result
        assert isinstance(result["top_callers"], str)
        store.close()


class TestCodebaseAnatomy:
    """Tests for the codebase_anatomy() method."""

    def test_returns_purpose(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.codebase_anatomy()
        assert "purpose" in result
        assert isinstance(result["purpose"], str)
        assert len(result["purpose"]) > 0
        store.close()

    def test_returns_subsystems(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.codebase_anatomy()
        assert "subsystems" in result
        assert len(result["subsystems"]) >= 1
        store.close()

    def test_subsystem_has_required_fields(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.codebase_anatomy()
        for sub in result["subsystems"]:
            assert "name" in sub
            assert "slug" in sub
            assert "files" in sub
            assert "importance" in sub
            assert "description" in sub
            assert isinstance(sub["name"], str)
            assert isinstance(sub["slug"], str)
            assert isinstance(sub["files"], list)
            assert isinstance(sub["importance"], (int, float))
            assert isinstance(sub["description"], str)
        store.close()

    def test_subsystem_importance_normalized(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.codebase_anatomy()
        for sub in result["subsystems"]:
            assert 0.0 <= sub["importance"] <= 1.0, (
                f"Importance {sub['importance']} out of range for {sub['name']}"
            )
        store.close()

    def test_connections_reference_valid_slugs(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.codebase_anatomy()
        valid_slugs = {sub["slug"] for sub in result["subsystems"]}
        for conn in result.get("connections", []):
            assert conn["from"] in valid_slugs, f"Invalid from slug: {conn['from']}"
            assert conn["to"] in valid_slugs, f"Invalid to slug: {conn['to']}"
        store.close()


class TestAnswerQuestion:
    """Tests for the answer_question() conversational KT feature."""

    def test_answer_returns_required_fields(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.answer_question("What is this codebase?")
        assert "question" in result
        assert "intent" in result
        assert "answer" in result
        assert "data" in result
        assert "sources" in result
        assert "suggestions" in result
        store.close()

    def test_overview_intent(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.answer_question("What is this codebase about?")
        assert result["intent"] == "overview"
        store.close()

    def test_risk_intent(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.answer_question("What are the riskiest files?")
        assert result["intent"] == "risk"
        store.close()

    def test_health_intent(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.answer_question("What's the health score?")
        assert result["intent"] == "health"
        store.close()

    def test_general_intent(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.answer_question("Tell me something random and unrelated")
        assert result["intent"] == "general"
        store.close()

    def test_answer_is_nonempty(self, comp_project) -> None:
        _, store, engine = comp_project
        for q in [
            "What is this codebase?",
            "What are the riskiest files?",
            "What's the health score?",
            "How is the codebase organized?",
        ]:
            result = engine.answer_question(q)
            assert len(result["answer"]) > 0, f"Empty answer for: {q}"
        store.close()

    def test_dead_code_intent(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.answer_question("Is there any dead code?")
        assert result["intent"] == "dead_code"
        store.close()

    def test_cycles_intent(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.answer_question("Are there circular import loops?")
        assert result["intent"] == "cycles"
        store.close()

    def test_suggestions_present(self, comp_project) -> None:
        _, store, engine = comp_project
        result = engine.answer_question("What's the health score?")
        assert isinstance(result["suggestions"], list)
        assert len(result["suggestions"]) > 0
        store.close()


class TestSymbolNarrativeCallerFiles:
    """symbol_narrative() should include caller_files field."""

    def test_symbol_narrative_has_caller_files(self, comp_project) -> None:
        _, store, engine = comp_project
        nodes = store.get_all_nodes()
        symbol = next((n for n in nodes if n["type"] == "function"), None)
        if symbol:
            result = engine.symbol_narrative(symbol["id"])
            assert "caller_files" in result
            assert isinstance(result["caller_files"], list)
        store.close()
