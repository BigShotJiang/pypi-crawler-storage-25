"""Real-codebase validation for features never tested on real code.

Tests migration tools, code reviewer, refactorer, test runner,
KT generator, KT video, and hook runner against real GitHub repos.

Repos expected at $TEMP/codebrain-test-repos/ — skip if not present.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index

_HERE = Path(__file__).resolve().parent
_LOCAL_REPOS = _HERE / "fixtures" / "repos"
_TEMP = Path(os.environ.get("TEMP", os.environ.get("TMP", "/tmp")))
_TEMP_REPOS = _TEMP / "codebrain-test-repos"


def _pick_repo_root(name: str) -> Path:
    local = _LOCAL_REPOS / name
    if local.exists():
        return local
    return _TEMP_REPOS / name


REPOS_ROOT = _LOCAL_REPOS if _LOCAL_REPOS.exists() else _TEMP_REPOS
PETCLINIC = _pick_repo_root("spring-petclinic")
SALEOR = _pick_repo_root("saleor")
K8S_DEMO = _pick_repo_root("k8s-demo")


def _index_repo(repo_path: Path, tmp_path: Path) -> GraphStore:
    db_path = tmp_path / "test.db"
    full_index(repo_path, db_path)
    return GraphStore(db_path)


def _has_sources(root: Path, *patterns: str) -> bool:
    if not root.exists():
        return False
    for pat in patterns:
        if next(root.rglob(pat), None) is not None:
            return True
    return False


# ---------------------------------------------------------------------------
# Fixtures: index Spring PetClinic (small, fast) for most tests
# ---------------------------------------------------------------------------

petclinic_skip = pytest.mark.skipif(
    not _has_sources(PETCLINIC, "*.java"),
    reason="spring-petclinic not cloned or empty",
)

saleor_skip = pytest.mark.skipif(
    not _has_sources(SALEOR, "*.py"),
    reason="saleor not cloned or empty",
)

k8s_skip = pytest.mark.skipif(
    not _has_sources(K8S_DEMO, "*.yaml", "*.yml"),
    reason="k8s-demo not cloned or empty",
)


@pytest.fixture(scope="module")
def petclinic_store(petclinic_indexed_db):
    s = GraphStore(petclinic_indexed_db)
    yield s
    s.close()


@pytest.fixture(scope="module")
def saleor_store(saleor_indexed_db):
    s = GraphStore(saleor_indexed_db)
    yield s
    s.close()


# ---------------------------------------------------------------------------
# Migration Tools — on real codebases
# ---------------------------------------------------------------------------


@petclinic_skip
class TestMigrationPlanReal:
    """MigrationPlanGenerator on Spring PetClinic."""

    def test_generates_plan(self, petclinic_store):
        from codebrain.migration import MigrationPlanGenerator
        gen = MigrationPlanGenerator(petclinic_store)
        plan = gen.generate_plan()
        assert isinstance(plan, dict)
        assert "phases" in plan or "modules" in plan or "summary" in plan

    def test_plan_has_modules(self, petclinic_store):
        from codebrain.migration import MigrationPlanGenerator
        gen = MigrationPlanGenerator(petclinic_store)
        plan = gen.generate_plan()
        # Should identify modules/files to migrate
        modules = plan.get("phases", plan.get("modules", []))
        assert len(modules) > 0, f"Empty plan: {list(plan.keys())}"

    def test_plan_to_markdown(self, petclinic_store):
        from codebrain.migration import MigrationPlanGenerator
        gen = MigrationPlanGenerator(petclinic_store)
        md = gen.to_markdown()
        assert len(md) > 50
        assert "#" in md  # has headers


@petclinic_skip
class TestContractExtractorReal:
    """ContractExtractor on Spring PetClinic."""

    def test_extracts_contracts(self, petclinic_store):
        from codebrain.migration import ContractExtractor
        ext = ContractExtractor(petclinic_store)
        contracts = ext.extract()
        assert isinstance(contracts, dict)
        assert len(contracts) > 0, "No contracts extracted"

    def test_extracts_for_specific_file(self, petclinic_store):
        from codebrain.migration import ContractExtractor
        nodes = petclinic_store.get_all_nodes()
        # Find a Java file with functions
        java_files = {n["file_path"] for n in nodes
                      if n.get("file_path", "").endswith(".java")
                      and n.get("type") in ("method", "function")}
        if not java_files:
            pytest.skip("No Java files with methods found")
        target = next(iter(java_files))
        ext = ContractExtractor(petclinic_store)
        contracts = ext.extract(file_path=target)
        assert isinstance(contracts, dict)

    def test_contracts_to_markdown(self, petclinic_store):
        from codebrain.migration import ContractExtractor
        ext = ContractExtractor(petclinic_store)
        md = ext.to_markdown()
        assert len(md) > 20


@saleor_skip
class TestMigrationPlanSaleor:
    """Migration plan on a large Django project."""

    def test_generates_plan_at_scale(self, saleor_store):
        from codebrain.migration import MigrationPlanGenerator
        gen = MigrationPlanGenerator(saleor_store)
        plan = gen.generate_plan()
        assert isinstance(plan, dict)
        phases = plan.get("phases", plan.get("modules", []))
        assert len(phases) > 3, f"Only {len(phases)} phases for 4000+ file project"


# ---------------------------------------------------------------------------
# Code Reviewer — on real codebases
# ---------------------------------------------------------------------------


@petclinic_skip
class TestCodeReviewerReal:
    """CodeReviewer on Spring PetClinic."""

    def test_review_files(self, petclinic_store):
        from codebrain.actions.reviewer import CodeReviewer
        reviewer = CodeReviewer(petclinic_store, PETCLINIC)
        nodes = petclinic_store.get_all_nodes()
        java_files = list({n["file_path"] for n in nodes
                          if n.get("file_path", "").endswith(".java")})[:3]
        if not java_files:
            pytest.skip("No Java files")
        review = reviewer.review_files(java_files)
        assert review is not None
        # Should produce some findings or at least not crash
        assert hasattr(review, "findings") or hasattr(review, "issues")

    def test_review_to_markdown(self, petclinic_store):
        from codebrain.actions.reviewer import CodeReviewer
        reviewer = CodeReviewer(petclinic_store, PETCLINIC)
        nodes = petclinic_store.get_all_nodes()
        java_files = list({n["file_path"] for n in nodes
                          if n.get("file_path", "").endswith(".java")})[:2]
        if not java_files:
            pytest.skip("No Java files")
        review = reviewer.review_files(java_files)
        md = reviewer.to_markdown(review)
        assert isinstance(md, str)
        assert len(md) > 0


@saleor_skip
class TestCodeReviewerSaleor:
    """CodeReviewer on Saleor (large Django project)."""

    def test_review_django_models(self, saleor_store):
        from codebrain.actions.reviewer import CodeReviewer
        reviewer = CodeReviewer(saleor_store, SALEOR)
        nodes = saleor_store.get_all_nodes()
        # Find model files
        model_files = list({n["file_path"] for n in nodes
                           if "model" in n.get("file_path", "").lower()
                           and n.get("file_path", "").endswith(".py")})[:3]
        if not model_files:
            pytest.skip("No model files found")
        review = reviewer.review_files(model_files)
        assert review is not None


# ---------------------------------------------------------------------------
# Refactorer — on real codebases
# ---------------------------------------------------------------------------


@petclinic_skip
class TestRefactorerReal:
    """Refactorer.suggest() on Spring PetClinic (no LLM needed for dead code)."""

    def test_suggest_returns_list(self, petclinic_store):
        from codebrain.actions.refactor import Refactorer
        refactorer = Refactorer(petclinic_store, PETCLINIC)
        suggestions = refactorer.suggest(category="all")
        assert isinstance(suggestions, list)
        # May or may not find suggestions, but should not crash

    def test_suggest_dead_code(self, petclinic_store):
        from codebrain.actions.refactor import Refactorer
        refactorer = Refactorer(petclinic_store, PETCLINIC)
        suggestions = refactorer.suggest(category="dead_code")
        assert isinstance(suggestions, list)


@saleor_skip
class TestRefactorerSaleor:
    """Refactorer on Saleor — should find real suggestions in 4000+ files."""

    def test_suggest_at_scale(self, saleor_store):
        from codebrain.actions.refactor import Refactorer
        refactorer = Refactorer(saleor_store, SALEOR)
        suggestions = refactorer.suggest(category="all")
        assert isinstance(suggestions, list)
        # A 4000-file Django project should have some suggestions
        assert len(suggestions) > 0, "No refactoring suggestions for 4000+ file project"


# ---------------------------------------------------------------------------
# Test Runner — detection on real codebases
# ---------------------------------------------------------------------------


@petclinic_skip
class TestTestRunnerReal:
    """TestRunner detection on Spring PetClinic (has JUnit tests)."""

    def test_detect_runner(self, petclinic_store):
        """TestRunner only supports pytest/jest/go — should fail on Java projects."""
        from codebrain.test_runner import TestRunner
        runner = TestRunner(petclinic_store, PETCLINIC)
        # PetClinic uses Maven/Gradle which TestRunner doesn't support yet
        # This documents a real gap — TestRunner is Python/JS/Go only
        with pytest.raises(RuntimeError, match="No test runner detected"):
            runner.detect_runner()

    def test_affected_tests(self, petclinic_store):
        from codebrain.test_runner import TestRunner
        runner = TestRunner(petclinic_store, PETCLINIC)
        nodes = petclinic_store.get_all_nodes()
        java_files = [n["file_path"] for n in nodes
                      if n.get("file_path", "").endswith(".java")
                      and "test" not in n.get("file_path", "").lower()][:2]
        if not java_files:
            pytest.skip("No Java source files")
        affected = runner.affected_tests(changed_files=java_files)
        assert isinstance(affected, list)
        # May or may not find affected tests, but should not crash

    def test_test_for_symbol(self, petclinic_store):
        from codebrain.test_runner import TestRunner
        runner = TestRunner(petclinic_store, PETCLINIC)
        # Look up a known symbol
        nodes = petclinic_store.get_all_nodes()
        methods = [n for n in nodes if n.get("type") in ("method", "function")
                   and n.get("file_path", "").endswith(".java")]
        if not methods:
            pytest.skip("No Java methods")
        result = runner.test_for_symbol(methods[0]["name"])
        assert isinstance(result, dict)


# ---------------------------------------------------------------------------
# KT Generator — on real codebases
# ---------------------------------------------------------------------------


@petclinic_skip
class TestKTGeneratorReal:
    """KT document generation on Spring PetClinic."""

    def test_generates_kt_document(self, petclinic_store):
        from codebrain.kt import KTGenerator
        gen = KTGenerator(petclinic_store)
        md = gen.generate(project_name="Spring PetClinic")
        assert len(md) > 200
        assert "Spring PetClinic" in md

    def test_kt_has_sections(self, petclinic_store):
        from codebrain.kt import KTGenerator
        gen = KTGenerator(petclinic_store)
        md = gen.generate(project_name="PetClinic")
        # Should have standard KT sections
        md_lower = md.lower()
        assert "architecture" in md_lower or "overview" in md_lower
        assert "hotspot" in md_lower or "risk" in md_lower

    def test_kt_without_modules(self, petclinic_store):
        from codebrain.kt import KTGenerator
        gen = KTGenerator(petclinic_store)
        md = gen.generate(include_module_details=False)
        assert len(md) > 100


@saleor_skip
class TestKTGeneratorSaleor:
    """KT document on a large project — should not crash or timeout."""

    def test_generates_kt_at_scale(self, saleor_store):
        from codebrain.kt import KTGenerator
        gen = KTGenerator(saleor_store)
        md = gen.generate(project_name="Saleor", max_modules=5, max_hotspots=5)
        assert len(md) > 300
        assert "Saleor" in md


# ---------------------------------------------------------------------------
# KT Video Generator — on real codebases
# ---------------------------------------------------------------------------


@petclinic_skip
class TestKTVideoReal:
    """KT video project generation on Spring PetClinic."""

    def test_generates_video_project(self, petclinic_store):
        from codebrain.kt_video import KTVideoGenerator
        gen = KTVideoGenerator(petclinic_store)
        with tempfile.TemporaryDirectory() as tmp:
            output = gen.generate(tmp, project_name="PetClinic")
            assert output.exists()
            # Should create Remotion project files
            files = list(Path(tmp).rglob("*"))
            assert len(files) > 3, f"Only {len(files)} files generated"

    def test_video_has_package_json(self, petclinic_store):
        from codebrain.kt_video import KTVideoGenerator
        gen = KTVideoGenerator(petclinic_store)
        with tempfile.TemporaryDirectory() as tmp:
            gen.generate(tmp, project_name="PetClinic")
            # Remotion projects need package.json
            pkg = Path(tmp) / "package.json"
            assert pkg.exists(), "No package.json in video output"


# ---------------------------------------------------------------------------
# Modernize Spec — on real codebases
# ---------------------------------------------------------------------------


@petclinic_skip
class TestModernizeSpecReal:
    """Modernization spec on Spring PetClinic."""

    def test_generates_spec(self, petclinic_store):
        from codebrain.modernize import SpecGenerator
        gen = SpecGenerator(petclinic_store)
        spec = gen.generate_full_spec()
        assert isinstance(spec, dict)
        assert "module_specs" in spec

    def test_spec_has_modules(self, petclinic_store):
        from codebrain.modernize import SpecGenerator
        gen = SpecGenerator(petclinic_store)
        spec = gen.generate_full_spec()
        modules = spec.get("module_specs", {})
        assert len(modules) > 0, f"No modules in spec. Keys: {list(spec.keys())}"


@saleor_skip
class TestModernizeSpecSaleor:
    """Modernization spec on a large Django project."""

    def test_spec_at_scale(self, saleor_store):
        from codebrain.modernize import SpecGenerator
        gen = SpecGenerator(saleor_store)
        spec = gen.generate_full_spec()
        modules = spec.get("module_specs", {})
        assert len(modules) > 5, f"Only {len(modules)} modules for 4000+ file project"


# ---------------------------------------------------------------------------
# Comprehension + Analysis cross-check on real repos
# ---------------------------------------------------------------------------


@saleor_skip
class TestComprehensionSaleor:
    """Comprehension engine on a real large project."""

    def test_health_score(self, saleor_store):
        from codebrain.comprehension import ComprehensionEngine
        engine = ComprehensionEngine(saleor_store)
        health = engine.health_score()
        assert isinstance(health, dict)
        score = health.get("score", health.get("overall", -1))
        assert 0 <= score <= 100, f"Invalid health score: {score}"

    def test_hotspots(self, saleor_store):
        from codebrain.comprehension import ComprehensionEngine
        engine = ComprehensionEngine(saleor_store)
        hotspots = engine.risk_hotspots(top_n=10)
        assert isinstance(hotspots, list)
        assert len(hotspots) > 0, "No hotspots in 4000+ file project"


@petclinic_skip
class TestAnalyzerPetClinic:
    """StructuralAnalyzer on Spring PetClinic."""

    def test_coupling_analysis(self, petclinic_store):
        from codebrain.analyzer import StructuralAnalyzer
        analyzer = StructuralAnalyzer(petclinic_store)
        coupling = analyzer.coupling_analysis()
        assert isinstance(coupling, dict)

    def test_layer_detection(self, petclinic_store):
        from codebrain.analyzer import StructuralAnalyzer
        analyzer = StructuralAnalyzer(petclinic_store)
        layers = analyzer.detect_layers()
        assert isinstance(layers, dict)
