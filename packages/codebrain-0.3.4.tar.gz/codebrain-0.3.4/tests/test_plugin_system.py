"""Tests for the plugin system — parser ABC, registry, and built-in parsers."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedFile
from codebrain.parser.registry import ParserRegistry, get_registry


class TestBaseParser:
    def test_cannot_instantiate_abc(self):
        with pytest.raises(TypeError):
            BaseParser()

    def test_custom_parser_must_implement_extensions(self):
        class Incomplete(BaseParser):
            def parse(self, path, repo_root):
                return ParsedFile(path="x", content_hash="h")

        with pytest.raises(TypeError):
            Incomplete()

    def test_custom_parser_must_implement_parse(self):
        class Incomplete(BaseParser):
            def extensions(self):
                return frozenset({".xyz"})

        with pytest.raises(TypeError):
            Incomplete()

    def test_custom_parser_works(self):
        class MyParser(BaseParser):
            def extensions(self):
                return frozenset({".xyz"})

            def parse(self, path, repo_root):
                return ParsedFile(path="x", content_hash="h")

        p = MyParser()
        assert ".xyz" in p.extensions()


class TestParserRegistry:
    def test_empty_registry(self):
        reg = ParserRegistry()
        assert reg.supported_extensions == frozenset()
        assert reg.parsers == []

    def test_register_parser(self):
        class MyParser(BaseParser):
            def extensions(self):
                return frozenset({".xyz"})

            def parse(self, path, repo_root):
                return ParsedFile(path="test", content_hash="h")

        reg = ParserRegistry()
        reg.register(MyParser())
        assert ".xyz" in reg.supported_extensions
        assert len(reg.parsers) == 1

    def test_can_parse(self):
        class MyParser(BaseParser):
            def extensions(self):
                return frozenset({".xyz"})

            def parse(self, path, repo_root):
                return ParsedFile(path="test", content_hash="h")

        reg = ParserRegistry()
        reg.register(MyParser())
        assert reg.can_parse(Path("test.xyz"))
        assert not reg.can_parse(Path("test.abc"))

    def test_parse_dispatches(self, tmp_path):
        called_with = {}

        class MyParser(BaseParser):
            def extensions(self):
                return frozenset({".txt"})

            def parse(self, path, repo_root):
                called_with["path"] = path
                return ParsedFile(path=str(path), content_hash="h")

        reg = ParserRegistry()
        reg.register(MyParser())
        test_file = tmp_path / "test.txt"
        test_file.write_text("hello")
        reg.parse(test_file, tmp_path)
        assert called_with["path"] == test_file

    def test_parse_raises_for_unknown_extension(self, tmp_path):
        reg = ParserRegistry()
        test_file = tmp_path / "test.unknown"
        test_file.write_text("hello")
        with pytest.raises(ValueError, match="No parser registered"):
            reg.parse(test_file, tmp_path)

    def test_multiple_parsers(self):
        class ParserA(BaseParser):
            def extensions(self):
                return frozenset({".a"})

            def parse(self, path, repo_root):
                return ParsedFile(path="a", content_hash="h")

        class ParserB(BaseParser):
            def extensions(self):
                return frozenset({".b", ".c"})

            def parse(self, path, repo_root):
                return ParsedFile(path="b", content_hash="h")

        reg = ParserRegistry()
        reg.register(ParserA())
        reg.register(ParserB())
        assert reg.supported_extensions == frozenset({".a", ".b", ".c"})
        assert len(reg.parsers) == 2

    def test_later_parser_overrides_extension(self, tmp_path):
        class Parser1(BaseParser):
            def extensions(self):
                return frozenset({".py"})

            def parse(self, path, repo_root):
                return ParsedFile(path="parser1", content_hash="h")

        class Parser2(BaseParser):
            def extensions(self):
                return frozenset({".py"})

            def parse(self, path, repo_root):
                return ParsedFile(path="parser2", content_hash="h")

        reg = ParserRegistry()
        reg.register(Parser1())
        reg.register(Parser2())
        test_file = tmp_path / "test.py"
        test_file.write_text("pass")
        result = reg.parse(test_file, tmp_path)
        assert result.path == "parser2"


class TestBuiltinParsers:
    def test_python_parser_registered(self):
        from codebrain.parser.python_parser import PythonParser

        p = PythonParser()
        assert ".py" in p.extensions()

    def test_typescript_parser_registered(self):
        from codebrain.parser.typescript_parser import TypeScriptParser

        p = TypeScriptParser()
        exts = p.extensions()
        assert ".ts" in exts
        assert ".tsx" in exts
        assert ".js" in exts
        assert ".jsx" in exts

    def test_python_parser_parses(self, tmp_path):
        from codebrain.parser.python_parser import PythonParser

        p = PythonParser()
        test_file = tmp_path / "test.py"
        test_file.write_text("def hello(): pass")
        result = p.parse(test_file, tmp_path)
        assert result.path == "test.py"
        assert len(result.nodes) > 0

    def test_typescript_parser_parses(self, tmp_path):
        from codebrain.parser.typescript_parser import TypeScriptParser

        p = TypeScriptParser()
        test_file = tmp_path / "test.ts"
        test_file.write_text("function hello() { return 42; }")
        result = p.parse(test_file, tmp_path)
        assert result.path == "test.ts"
        assert len(result.nodes) > 0


class TestGlobalRegistry:
    def test_get_registry_returns_singleton(self):
        # Reset the singleton for this test
        import codebrain.parser.registry as reg_mod
        old = reg_mod._registry
        reg_mod._registry = None
        try:
            r1 = get_registry()
            r2 = get_registry()
            assert r1 is r2
        finally:
            reg_mod._registry = old

    def test_registry_has_builtin_parsers(self):
        import codebrain.parser.registry as reg_mod
        old = reg_mod._registry
        reg_mod._registry = None
        try:
            reg = get_registry()
            assert ".py" in reg.supported_extensions
            assert ".ts" in reg.supported_extensions
            assert ".tsx" in reg.supported_extensions
            assert ".js" in reg.supported_extensions
            assert ".jsx" in reg.supported_extensions
        finally:
            reg_mod._registry = old

    def test_indexing_still_works(self, simple_project):
        """Verify that the plugin system doesn't break normal indexing."""
        from codebrain.indexer import full_index

        result = full_index(simple_project)
        assert result["errors"] == []
        assert result["files_parsed"] > 0
        assert result["total_nodes"] > 0
