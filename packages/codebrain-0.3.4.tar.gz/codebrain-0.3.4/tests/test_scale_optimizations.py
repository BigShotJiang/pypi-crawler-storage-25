"""Regression tests for M21 scale optimization code paths.

These tests verify that the optimization infrastructure exists and works
correctly, WITHOUT requiring network access or large repos. They are NOT
marked with @pytest.mark.scale and run in the normal test suite.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from codebrain.graph.schema import init_db, migrate_db
from codebrain.graph.store import GraphStore
from codebrain.indexer import _PARALLEL_THRESHOLD, full_index
from codebrain.settings import Settings, load_settings


# ------------------------------------------------------------------
# 1. Schema indexes exist
# ------------------------------------------------------------------
class TestSchemaIndexes:
    """Verify all performance-critical indexes are created."""

    REQUIRED_INDEXES = {
        # Node indexes
        "idx_nodes_file_path",
        "idx_nodes_type",
        "idx_nodes_name",
        # Edge indexes
        "idx_edges_source",
        "idx_edges_target",
        "idx_edges_type",
        "idx_edges_file_path",
        # Compound / unique indexes
        "idx_edges_unique",
        "idx_edges_target_type",
    }

    def _get_indexes(self, conn: sqlite3.Connection) -> set[str]:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%'"
        ).fetchall()
        return {row[0] for row in rows}

    def test_all_indexes_created_on_init(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        init_db(conn)
        indexes = self._get_indexes(conn)
        missing = self.REQUIRED_INDEXES - indexes
        assert not missing, f"Missing indexes after init_db: {missing}"
        conn.close()

    def test_all_indexes_created_on_migrate(self, tmp_path):
        db = tmp_path / "test.db"
        conn = sqlite3.connect(str(db))
        migrate_db(conn)
        indexes = self._get_indexes(conn)
        missing = self.REQUIRED_INDEXES - indexes
        assert not missing, f"Missing indexes after migrate_db: {missing}"
        conn.close()

    def test_indexes_present_via_graphstore(self, tmp_path):
        """GraphStore constructor runs migrate_db, so indexes should exist."""
        db = tmp_path / "test.db"
        with GraphStore(db) as store:
            indexes = self._get_indexes(store.conn)
        missing = self.REQUIRED_INDEXES - indexes
        assert not missing, f"Missing indexes via GraphStore: {missing}"


# ------------------------------------------------------------------
# 2. Parallel threshold configuration
# ------------------------------------------------------------------
class TestParallelThreshold:
    """Verify the parallel parsing threshold is configurable."""

    def test_default_threshold_is_reasonable(self):
        assert _PARALLEL_THRESHOLD == 50

    def test_settings_default_threshold(self):
        settings = Settings()
        assert settings.parallel_threshold == 50

    def test_settings_custom_threshold(self):
        settings = Settings(parallel_threshold=100)
        assert settings.parallel_threshold == 100

    def test_settings_from_toml(self, tmp_path):
        """parallel_threshold can be set in .codebrain.toml."""
        toml_content = '[codebrain]\nparallel_threshold = 200\n'
        (tmp_path / ".codebrain.toml").write_text(toml_content)
        settings = load_settings(tmp_path)
        assert settings.parallel_threshold == 200

    def test_settings_max_workers(self):
        settings = Settings(max_workers=4)
        assert settings.max_workers == 4

    def test_full_index_accepts_parallel_threshold(self, simple_project):
        """full_index accepts parallel_threshold kwarg without error."""
        result = full_index(simple_project, parallel_threshold=9999)
        assert result["files_parsed"] > 0

    def test_full_index_accepts_max_workers(self, simple_project):
        """full_index accepts max_workers kwarg without error."""
        result = full_index(simple_project, max_workers=2)
        assert result["files_parsed"] > 0


# ------------------------------------------------------------------
# 3. Batch inserts (executemany)
# ------------------------------------------------------------------
class TestBatchInserts:
    """Verify upsert_file uses executemany for bulk efficiency."""

    def test_upsert_file_handles_many_nodes(self, tmp_path):
        """Inserting a file with many nodes should work (proves executemany path)."""
        from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode

        db = tmp_path / "test.db"
        nodes = [
            ParsedNode(
                id=f"test.py::func_{i}",
                name=f"func_{i}",
                qualified_name=f"func_{i}",
                type="function",
                file_path="test.py",
                line_start=i * 3 + 1,
                line_end=i * 3 + 2,
            )
            for i in range(100)
        ]
        edges = [
            ParsedEdge(
                source=f"test.py::func_{i}",
                target=f"test.py::func_{(i + 1) % 100}",
                type="CALLS",
                file_path="test.py",
                line=i * 3 + 2,
            )
            for i in range(100)
        ]
        pf = ParsedFile(
            path="test.py",
            content_hash="abc123",
            line_count=300,
            nodes=nodes,
            edges=edges,
        )

        with GraphStore(db) as store:
            store.upsert_file(pf)
            stored_nodes = store.get_nodes_by_file("test.py")
            stored_edges = store.get_all_edges()

        assert len(stored_nodes) == 100
        assert len(stored_edges) == 100

    def test_upsert_file_replaces_on_reindex(self, tmp_path):
        """Re-indexing a file should replace old data, not duplicate."""
        from codebrain.parser.models import ParsedFile, ParsedNode

        db = tmp_path / "test.db"
        pf1 = ParsedFile(
            path="mod.py",
            content_hash="v1",
            line_count=10,
            nodes=[
                ParsedNode(
                    id="mod.py::old_func",
                    name="old_func",
                    qualified_name="old_func",
                    type="function",
                    file_path="mod.py",
                    line_start=1,
                    line_end=3,
                )
            ],
            edges=[],
        )
        pf2 = ParsedFile(
            path="mod.py",
            content_hash="v2",
            line_count=10,
            nodes=[
                ParsedNode(
                    id="mod.py::new_func",
                    name="new_func",
                    qualified_name="new_func",
                    type="function",
                    file_path="mod.py",
                    line_start=1,
                    line_end=3,
                )
            ],
            edges=[],
        )

        with GraphStore(db) as store:
            store.upsert_file(pf1)
            store.upsert_file(pf2)
            nodes = store.get_nodes_by_file("mod.py")

        assert len(nodes) == 1
        assert nodes[0]["name"] == "new_func"


# ------------------------------------------------------------------
# 4. SQLite pragmas for performance
# ------------------------------------------------------------------
class TestSQLitePragmas:
    """Verify WAL mode and other performance pragmas are set."""

    def test_wal_mode_enabled(self, tmp_path):
        db = tmp_path / "test.db"
        with GraphStore(db) as store:
            mode = store.conn.execute("PRAGMA journal_mode").fetchone()[0]
            assert mode == "wal"

    def test_synchronous_normal(self, tmp_path):
        db = tmp_path / "test.db"
        with GraphStore(db) as store:
            sync = store.conn.execute("PRAGMA synchronous").fetchone()[0]
            # NORMAL = 1
            assert sync == 1
