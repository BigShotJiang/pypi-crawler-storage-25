"""Tests for legacy language parsers (SPEC-M38): COBOL, PL/SQL, Fortran, MUMPS."""
from __future__ import annotations

from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# COBOL Parser Tests
# ---------------------------------------------------------------------------


class TestCobolParser:
    def _parse(self, tmp_path, code, ext=".cob"):
        from codebrain.parser.cobol_parser import CobolParser
        f = tmp_path / f"test{ext}"
        f.write_text(code, encoding="utf-8")
        parser = CobolParser()
        return parser.parse(f, tmp_path)

    def test_parse_program_id(self, tmp_path):
        code = "       IDENTIFICATION DIVISION.\n       PROGRAM-ID. HELLO-WORLD.\n       PROCEDURE DIVISION.\n       STOP RUN.\n"
        result = self._parse(tmp_path, code)
        names = [n.name for n in result.nodes]
        assert "HELLO-WORLD" in names

    def test_parse_paragraphs(self, tmp_path):
        code = (
            "       IDENTIFICATION DIVISION.\n"
            "       PROGRAM-ID. TEST1.\n"
            "       PROCEDURE DIVISION.\n"
            "       MAIN-LOGIC.\n"
            "           DISPLAY 'Hello'.\n"
            "       CLEANUP.\n"
            "           STOP RUN.\n"
        )
        result = self._parse(tmp_path, code)
        func_names = [n.name for n in result.nodes if n.type == "function"]
        assert "MAIN-LOGIC" in func_names
        assert "CLEANUP" in func_names

    def test_parse_perform_calls(self, tmp_path):
        code = (
            "       IDENTIFICATION DIVISION.\n"
            "       PROGRAM-ID. TEST2.\n"
            "       PROCEDURE DIVISION.\n"
            "       MAIN-PARA.\n"
            "           PERFORM INIT-PARA.\n"
            "       INIT-PARA.\n"
            "           DISPLAY 'INIT'.\n"
        )
        result = self._parse(tmp_path, code)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = [e.target for e in calls]
        assert any("INIT-PARA" in t for t in targets)

    def test_parse_perform_thru(self, tmp_path):
        code = (
            "       IDENTIFICATION DIVISION.\n"
            "       PROGRAM-ID. TEST3.\n"
            "       PROCEDURE DIVISION.\n"
            "       MAIN.\n"
            "           PERFORM STEP-A THRU STEP-C.\n"
            "       STEP-A.\n"
            "           DISPLAY 'A'.\n"
            "       STEP-C.\n"
            "           DISPLAY 'C'.\n"
        )
        result = self._parse(tmp_path, code)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = [e.target for e in calls]
        assert any("STEP-A" in t for t in targets)
        assert any("STEP-C" in t for t in targets)

    def test_parse_copy_imports(self, tmp_path):
        code = (
            "       IDENTIFICATION DIVISION.\n"
            "       PROGRAM-ID. TEST4.\n"
            "       DATA DIVISION.\n"
            "       WORKING-STORAGE SECTION.\n"
            "       COPY CUSTOMER-REC.\n"
            "       PROCEDURE DIVISION.\n"
            "       STOP RUN.\n"
        )
        result = self._parse(tmp_path, code)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        assert any("CUSTOMER-REC" in e.target for e in imports)

    def test_parse_call_external(self, tmp_path):
        code = (
            "       IDENTIFICATION DIVISION.\n"
            "       PROGRAM-ID. TEST5.\n"
            "       PROCEDURE DIVISION.\n"
            "       MAIN.\n"
            "           CALL 'SUBPROG1'.\n"
        )
        result = self._parse(tmp_path, code)
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert any("SUBPROG1" in e.target for e in calls)

    def test_parse_working_storage(self, tmp_path):
        code = (
            "       IDENTIFICATION DIVISION.\n"
            "       PROGRAM-ID. TEST6.\n"
            "       DATA DIVISION.\n"
            "       WORKING-STORAGE SECTION.\n"
            "       01 WS-NAME PIC X(30).\n"
            "       01 WS-AGE PIC 99.\n"
            "       PROCEDURE DIVISION.\n"
            "       STOP RUN.\n"
        )
        result = self._parse(tmp_path, code)
        vars_ = [n.name for n in result.nodes if n.type == "variable"]
        assert "WS-NAME" in vars_
        assert "WS-AGE" in vars_

    def test_fixed_format_comment_skipped(self, tmp_path):
        code = (
            "000100 IDENTIFICATION DIVISION.\n"
            "000200*THIS IS A COMMENT.\n"
            "000300 PROGRAM-ID. TEST7.\n"
            "000400 PROCEDURE DIVISION.\n"
            "000500 STOP RUN.\n"
        )
        result = self._parse(tmp_path, code)
        assert result.nodes  # should not crash

    def test_free_format(self, tmp_path):
        code = (
            ">>SOURCE FORMAT IS FREE\n"
            "IDENTIFICATION DIVISION.\n"
            "PROGRAM-ID. FREETEST.\n"
            "PROCEDURE DIVISION.\n"
            "MAIN-PARA.\n"
            "    DISPLAY 'Hello'.\n"
            "    STOP RUN.\n"
        )
        result = self._parse(tmp_path, code)
        names = [n.name for n in result.nodes]
        assert "FREETEST" in names

    def test_copybook_file(self, tmp_path):
        code = "       01 SHARED-REC.\n          05 SHARED-NAME PIC X(20).\n"
        result = self._parse(tmp_path, code, ext=".cpy")
        assert result.line_count > 0

    def test_sections(self, tmp_path):
        code = (
            "       IDENTIFICATION DIVISION.\n"
            "       PROGRAM-ID. TEST8.\n"
            "       PROCEDURE DIVISION.\n"
            "       INIT-SECTION SECTION.\n"
            "       STEP-ONE.\n"
            "           DISPLAY 'ONE'.\n"
        )
        result = self._parse(tmp_path, code)
        section_nodes = [n for n in result.nodes if n.summary == "section"]
        assert any("INIT-SECTION" in n.name for n in section_nodes)


# ---------------------------------------------------------------------------
# PL/SQL Parser Tests
# ---------------------------------------------------------------------------


class TestPLSQLParser:
    def _parse(self, tmp_path, code, ext=".pks"):
        from codebrain.parser.plsql_parser import PLSQLParser
        f = tmp_path / f"test{ext}"
        f.write_text(code, encoding="utf-8")
        parser = PLSQLParser()
        return parser.parse(f, tmp_path)

    def test_parse_package_spec(self, tmp_path):
        code = "CREATE OR REPLACE PACKAGE my_pkg AS\n  PROCEDURE do_stuff(p_id IN NUMBER);\nEND my_pkg;\n"
        result = self._parse(tmp_path, code)
        pkg_nodes = [n for n in result.nodes if "package" in (n.summary or "")]
        assert any("my_pkg" in n.name for n in pkg_nodes)
        # Spec → symbols should be exported
        procs = [n for n in result.nodes if n.type == "function"]
        assert any(n.is_exported for n in procs)

    def test_parse_package_body(self, tmp_path):
        code = "CREATE OR REPLACE PACKAGE BODY my_pkg AS\n  PROCEDURE do_stuff(p_id IN NUMBER) IS\n  BEGIN\n    NULL;\n  END;\nEND my_pkg;\n"
        result = self._parse(tmp_path, code, ext=".pkb")
        procs = [n for n in result.nodes if n.type == "function"]
        # Body → symbols should NOT be exported
        assert all(not n.is_exported for n in procs)

    def test_parse_procedure(self, tmp_path):
        code = "CREATE PROCEDURE calc_total(p_amount IN NUMBER, p_tax OUT NUMBER) IS\nBEGIN\n  p_tax := p_amount * 0.1;\nEND;\n"
        result = self._parse(tmp_path, code)
        procs = [n for n in result.nodes if n.type == "function"]
        assert any("calc_total" in n.name for n in procs)

    def test_parse_function(self, tmp_path):
        code = "CREATE FUNCTION get_name(p_id IN NUMBER) RETURN VARCHAR2 IS\nBEGIN\n  RETURN 'test';\nEND;\n"
        result = self._parse(tmp_path, code)
        funcs = [n for n in result.nodes if n.summary == "function"]
        assert any("get_name" in n.name for n in funcs)
        assert any("VARCHAR2" in (n.signature or "") for n in funcs)

    def test_parse_cursor(self, tmp_path):
        code = "CREATE PACKAGE BODY test AS\n  CURSOR emp_cursor IS SELECT * FROM employees;\nEND;\n"
        result = self._parse(tmp_path, code, ext=".pkb")
        cursors = [n for n in result.nodes if n.summary == "cursor"]
        assert any("emp_cursor" in n.name for n in cursors)

    def test_parse_type_reference(self, tmp_path):
        code = "CREATE PROCEDURE test_proc IS\n  v_name employees.name%TYPE;\nBEGIN\n  NULL;\nEND;\n"
        result = self._parse(tmp_path, code)
        df_edges = [e for e in result.edges if e.type == "DATAFLOW"]
        assert any("employees" in e.target for e in df_edges)

    def test_dynamic_sql_warning(self, tmp_path):
        code = "CREATE PROCEDURE dyn_test IS\nBEGIN\n  EXECUTE IMMEDIATE 'DROP TABLE x';\nEND;\n"
        result = self._parse(tmp_path, code)
        assert any("dynamic_sql" in (n.summary or "") for n in result.nodes)

    def test_exception_handler(self, tmp_path):
        code = "CREATE PROCEDURE safe_proc IS\nBEGIN\n  NULL;\nEXCEPTION\n  WHEN OTHERS THEN NULL;\nEND;\n"
        result = self._parse(tmp_path, code)
        assert any("exception_handlers" in (n.summary or "") for n in result.nodes)

    def test_sql_extension_not_claimed(self):
        from codebrain.parser.plsql_parser import PLSQLParser
        parser = PLSQLParser()
        assert ".sql" not in parser.extensions()


# ---------------------------------------------------------------------------
# Fortran Parser Tests
# ---------------------------------------------------------------------------


class TestFortranParser:
    def _parse(self, tmp_path, code, ext=".f90"):
        from codebrain.parser.fortran_parser import FortranParser
        f = tmp_path / f"test{ext}"
        f.write_text(code, encoding="utf-8")
        parser = FortranParser()
        return parser.parse(f, tmp_path)

    def test_parse_module(self, tmp_path):
        code = "MODULE math_utils\n  IMPLICIT NONE\nCONTAINS\n  FUNCTION add(a, b)\n    INTEGER :: a, b, add\n    add = a + b\n  END FUNCTION\nEND MODULE math_utils\n"
        result = self._parse(tmp_path, code)
        mod_nodes = [n for n in result.nodes if n.summary == "module"]
        assert any("math_utils" in n.name for n in mod_nodes)

    def test_parse_program(self, tmp_path):
        code = "PROGRAM hello\n  PRINT *, 'Hello'\nEND PROGRAM hello\n"
        result = self._parse(tmp_path, code)
        assert any("hello" in n.name for n in result.nodes)

    def test_parse_subroutine(self, tmp_path):
        code = "SUBROUTINE init_data(n, data)\n  INTEGER :: n\n  REAL :: data(n)\n  data = 0.0\nEND SUBROUTINE\n"
        result = self._parse(tmp_path, code)
        subs = [n for n in result.nodes if n.summary == "subroutine"]
        assert any("init_data" in n.name for n in subs)

    def test_parse_function(self, tmp_path):
        code = "REAL FUNCTION square(x)\n  REAL :: x\n  square = x * x\nEND FUNCTION\n"
        result = self._parse(tmp_path, code)
        funcs = [n for n in result.nodes if n.type == "function"]
        assert any("square" in n.name for n in funcs)

    def test_parse_function_result(self, tmp_path):
        code = "FUNCTION compute(x) RESULT(res)\n  REAL :: x, res\n  res = x * 2\nEND FUNCTION\n"
        result = self._parse(tmp_path, code)
        funcs = [n for n in result.nodes if n.type == "function" and "compute" in n.name]
        assert len(funcs) == 1
        assert "RESULT" in (funcs[0].signature or "")

    def test_parse_use_imports(self, tmp_path):
        code = "PROGRAM test\n  USE math_utils\n  CALL init_data(10)\nEND PROGRAM\n"
        result = self._parse(tmp_path, code)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        assert any("math_utils" in e.target for e in imports)

    def test_parse_use_only(self, tmp_path):
        code = "PROGRAM test\n  USE math_utils, ONLY: add, multiply\nEND PROGRAM\n"
        result = self._parse(tmp_path, code)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        targets = [e.target for e in imports]
        assert "math_utils" in targets
        assert "add" in targets

    def test_parse_call(self, tmp_path):
        code = "PROGRAM test\n  CALL init_data(10)\nEND PROGRAM\n"
        result = self._parse(tmp_path, code)
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert any("init_data" in e.target for e in calls)

    def test_parse_common_block(self, tmp_path):
        code = "SUBROUTINE test\n  COMMON /SHARED/ x, y, z\n  x = 1.0\nEND SUBROUTINE\n"
        result = self._parse(tmp_path, code)
        common_nodes = [n for n in result.nodes if "common_block" in (n.summary or "")]
        assert len(common_nodes) >= 1
        df_edges = [e for e in result.edges if e.type == "DATAFLOW"]
        assert len(df_edges) >= 1

    def test_parse_implicit_none(self, tmp_path):
        code = "MODULE safe_mod\n  IMPLICIT NONE\nEND MODULE\n"
        result = self._parse(tmp_path, code)
        assert any("implicit_none" in (n.summary or "") for n in result.nodes)

    def test_fixed_format_f77(self, tmp_path):
        code = (
            "      PROGRAM OLDSTYLE\n"
            "C     THIS IS A COMMENT\n"
            "      CALL MYSUB\n"
            "      STOP\n"
            "      END\n"
        )
        result = self._parse(tmp_path, code, ext=".f")
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert any("MYSUB" in e.target for e in calls)

    def test_free_format_f90(self, tmp_path):
        code = "program modern\n  implicit none\n  call do_work()\nend program\n"
        result = self._parse(tmp_path, code, ext=".f90")
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert any("do_work" in e.target for e in calls)

    def test_equivalence_warning(self, tmp_path):
        code = "SUBROUTINE test\n  REAL :: a, b\n  EQUIVALENCE (a, b)\nEND SUBROUTINE\n"
        result = self._parse(tmp_path, code)
        assert any("equivalence_warning" in (n.summary or "") for n in result.nodes)


# ---------------------------------------------------------------------------
# MUMPS Parser Tests
# ---------------------------------------------------------------------------


class TestMUMPSParser:
    def _parse(self, tmp_path, code, ext=".mps"):
        from codebrain.parser.mumps_parser import MUMPSParser
        f = tmp_path / f"test{ext}"
        f.write_text(code, encoding="utf-8")
        parser = MUMPSParser()
        return parser.parse(f, tmp_path)

    def test_parse_labels(self, tmp_path):
        code = "MAIN ; Entry point\n SET X=1\n DO INIT\n QUIT\nINIT ; Initialize\n SET Y=0\n QUIT\n"
        result = self._parse(tmp_path, code)
        func_names = [n.name for n in result.nodes if n.type == "function"]
        assert "MAIN" in func_names
        assert "INIT" in func_names

    def test_parse_do_calls(self, tmp_path):
        code = "MAIN ; start\n DO CLEANUP\n QUIT\nCLEANUP ; cleanup\n QUIT\n"
        result = self._parse(tmp_path, code)
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert any("CLEANUP" in e.target for e in calls)

    def test_parse_do_routine(self, tmp_path):
        code = "MAIN ; start\n DO INIT^SETUPRTN\n QUIT\n"
        result = self._parse(tmp_path, code)
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert any("SETUPRTN" in e.target for e in calls)

    def test_parse_goto_with_warning(self, tmp_path):
        code = "MAIN ; start\n GOTO CLEANUP\n QUIT\nCLEANUP ; end\n QUIT\n"
        result = self._parse(tmp_path, code)
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert any("CLEANUP" in e.target for e in calls)
        assert any("goto_count" in (n.summary or "") for n in result.nodes)

    def test_parse_globals(self, tmp_path):
        code = "MAIN ; start\n SET ^PATIENT(1)=\"John\"\n SET ^PATIENT(2)=\"Jane\"\n QUIT\n"
        result = self._parse(tmp_path, code)
        globals_ = [n for n in result.nodes if n.summary == "global"]
        assert any("PATIENT" in n.name for n in globals_)
        df = [e for e in result.edges if e.type == "DATAFLOW"]
        assert len(df) >= 1

    def test_parse_set_variables(self, tmp_path):
        code = "MAIN ; start\n SET X=1\n SET Y=2\n QUIT\n"
        result = self._parse(tmp_path, code)
        # Variables tracked internally, at minimum labels parsed
        assert len(result.nodes) >= 2  # file + MAIN label

    def test_single_letter_commands(self, tmp_path):
        code = "MAIN ; start\n S X=1\n D INIT\n Q\nINIT ; init\n S Y=0\n Q\n"
        result = self._parse(tmp_path, code)
        calls = [e for e in result.edges if e.type == "CALLS"]
        assert any("INIT" in e.target for e in calls)

    def test_indirect_reference_warning(self, tmp_path):
        code = "MAIN ; start\n SET X=@Y\n QUIT\n"
        result = self._parse(tmp_path, code)
        assert any("indirect_reference" in (n.summary or "") for n in result.nodes)

    def test_dynamic_dispatch_warning(self, tmp_path):
        code = 'MAIN ; start\n XECUTE "SET X=1"\n QUIT\n'
        result = self._parse(tmp_path, code)
        assert any("dynamic_dispatch" in (n.summary or "") for n in result.nodes)

    def test_label_with_params(self, tmp_path):
        code = "CALC(X,Y) ; Calculate\n SET RESULT=X+Y\n QUIT RESULT\n"
        result = self._parse(tmp_path, code)
        funcs = [n for n in result.nodes if n.type == "function"]
        assert any("CALC" in n.name for n in funcs)
        assert any("X,Y" in (n.signature or "") for n in funcs)


# ---------------------------------------------------------------------------
# Content sniffing tests
# ---------------------------------------------------------------------------


class TestContentSniffing:
    def test_detect_mumps(self, tmp_path):
        from codebrain.parser.mumps_parser import detect_m_language
        f = tmp_path / "test.m"
        f.write_text("MAIN ; Entry\n SET ^PATIENT=1\n DO INIT\n QUIT\n")
        assert detect_m_language(f) == "mumps"

    def test_detect_objc(self, tmp_path):
        from codebrain.parser.mumps_parser import detect_m_language
        f = tmp_path / "test.m"
        f.write_text('#import <Foundation/Foundation.h>\n@interface Foo : NSObject\n@end\n')
        assert detect_m_language(f) == "objc"

    def test_detect_matlab(self, tmp_path):
        from codebrain.parser.mumps_parser import detect_m_language
        f = tmp_path / "test.m"
        f.write_text("function result = add(a, b)\n  result = a + b;\nend\n")
        assert detect_m_language(f) == "matlab"


# ---------------------------------------------------------------------------
# Registration tests
# ---------------------------------------------------------------------------


class TestRegistration:
    def test_cobol_extensions_registered(self):
        from codebrain.parser.registry import get_registry
        reg = get_registry()
        assert reg.can_parse(Path("test.cob"))

    def test_plsql_extensions_registered(self):
        from codebrain.parser.registry import get_registry
        reg = get_registry()
        assert reg.can_parse(Path("test.pks"))

    def test_fortran_extensions_registered(self):
        from codebrain.parser.registry import get_registry
        reg = get_registry()
        assert reg.can_parse(Path("test.f90"))

    def test_mumps_extensions_registered(self):
        from codebrain.parser.registry import get_registry
        reg = get_registry()
        assert reg.can_parse(Path("test.mps"))

    def test_legacy_extensions_in_indexable(self):
        from codebrain.config import INDEXABLE_EXTENSIONS
        for ext in [".cob", ".cbl", ".cpy", ".pks", ".pkb", ".f90", ".f", ".mps"]:
            assert ext in INDEXABLE_EXTENSIONS, f"{ext} not in INDEXABLE_EXTENSIONS"
