"""Tests for M27 autonomous actions engine."""

from __future__ import annotations

import json
import textwrap
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from codebrain.actions.base import ActionEngine
from codebrain.actions.test_gen import TestGenerator, GeneratedTest
from codebrain.actions.reviewer import CodeReviewer, CodeReview, ReviewFinding
from codebrain.actions.refactor import Refactorer, RefactorSuggestion, RefactorResult
from codebrain.graph.store import GraphStore
from codebrain.rewriter import LLMClient, LLMResponse


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


class FakeLLM(LLMClient):
    """Fake LLM that returns canned responses."""

    def __init__(self, response: str = ""):
        self.response = response
        self.calls: list[tuple[str, str]] = []

    def complete(self, system: str, user: str, temperature: float = 0.1) -> LLMResponse:
        self.calls.append((system, user))
        return LLMResponse(content=self.response, model="fake", tokens_used=100)

    def is_available(self) -> bool:
        return True


@pytest.fixture
def indexed_project(tmp_path):
    """Create a simple indexed project for testing."""
    # Create source files
    src = tmp_path / "mypackage"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "core.py").write_text(textwrap.dedent("""\
        def process(data):
            \"\"\"Process input data and return result.\"\"\"
            result = helper(data)
            return {"status": "ok", "data": result}

        def helper(x):
            \"\"\"Internal helper function.\"\"\"
            return x * 2

        class Calculator:
            \"\"\"A calculator with many methods.\"\"\"
            def add(self, a, b):
                return a + b
            def subtract(self, a, b):
                return a - b
            def multiply(self, a, b):
                return a * b
    """))
    (src / "api.py").write_text(textwrap.dedent("""\
        from mypackage.core import process

        def handle_request(req):
            \"\"\"Handle API request.\"\"\"
            return process(req)

        def validate_input(data):
            \"\"\"Validate input data.\"\"\"
            if not data:
                raise ValueError("Empty data")
            return True
    """))

    # Create a test file
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "test_core.py").write_text(textwrap.dedent("""\
        from mypackage.core import process

        def test_process_returns_dict():
            result = process(42)
            assert isinstance(result, dict)
            assert result["status"] == "ok"
    """))

    # Index
    db = tmp_path / ".codebrain" / "graph.db"
    db.parent.mkdir()
    from codebrain.indexer import full_index
    full_index(tmp_path, db)

    return tmp_path, db


# ---------------------------------------------------------------------------
# TestGenerator tests
# ---------------------------------------------------------------------------


class TestGeneratorPrompts:
    def test_builds_prompt_with_context(self, indexed_project):
        tmp_path, db = indexed_project
        fake_llm = FakeLLM("```python\nimport pytest\ndef test_helper():\n    assert True\n```")

        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, fake_llm)
            result = gen.generate_for_symbol("helper")

        # LLM was called
        assert len(fake_llm.calls) >= 1
        system, user = fake_llm.calls[0]
        assert "pytest" in system.lower()
        assert "helper" in user

    def test_interprets_fingerprint(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, FakeLLM())
            guidance = gen._interpret_fingerprint("returns: dict, None | raises: ValueError")
            assert "Returns" in guidance
            assert "Raises" in guidance

    def test_interprets_empty_fingerprint(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, FakeLLM())
            guidance = gen._interpret_fingerprint("")
            assert "No structural fingerprint" in guidance

    def test_interprets_io_fingerprint(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, FakeLLM())
            guidance = gen._interpret_fingerprint("io: sql, http | async with awaits")
            assert "I/O" in guidance
            assert "Async" in guidance

    def test_includes_existing_test_patterns(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, FakeLLM())
            patterns = gen._get_existing_tests("mypackage/core.py")
            assert "test_" in patterns


class TestGeneratorExecution:
    def test_generates_valid_test(self, indexed_project):
        tmp_path, db = indexed_project
        fake_code = textwrap.dedent("""\
            ```python
            import pytest
            from mypackage.core import helper

            def test_helper_doubles_input():
                assert helper(5) == 10

            def test_helper_with_zero():
                assert helper(0) == 0
            ```
        """)
        fake_llm = FakeLLM(fake_code)

        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, fake_llm)
            result = gen.generate_for_symbol("helper")

        assert result.validated
        assert result.test_count == 2
        assert result.error == ""

    def test_retries_on_invalid_syntax(self, indexed_project):
        tmp_path, db = indexed_project

        class RetryLLM(LLMClient):
            def __init__(self):
                self.call_count = 0

            def complete(self, system, user, temperature=0.1):
                self.call_count += 1
                if self.call_count == 1:
                    return LLMResponse(content="def test_bad(:\n    pass", tokens_used=50)
                return LLMResponse(
                    content="import pytest\ndef test_good():\n    assert True\n",
                    tokens_used=50,
                )

            def is_available(self):
                return True

        llm = RetryLLM()
        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, llm)
            result = gen.generate_for_symbol("helper")

        assert llm.call_count >= 2  # retried
        assert result.validated

    def test_handles_symbol_not_found(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, FakeLLM())
            result = gen.generate_for_symbol("nonexistent_xyz")

        assert not result.validated
        assert "not found" in result.error

    def test_validates_must_have_test_function(self, indexed_project):
        tmp_path, db = indexed_project
        fake_llm = FakeLLM("# just a comment\nx = 1")

        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, fake_llm)
            result = gen.generate_for_symbol("helper")

        assert not result.validated

    def test_generates_for_gaps(self, indexed_project):
        tmp_path, db = indexed_project
        fake_code = "import pytest\ndef test_something():\n    assert True\n"
        fake_llm = FakeLLM(fake_code)

        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, fake_llm, max_retries=1)
            results = gen.generate_for_gaps(min_risk=0.0, max_count=3)

        assert isinstance(results, list)
        # Should have tried to generate at least one test
        assert len(results) >= 0  # May be 0 if all symbols are tested

    def test_test_file_path(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, FakeLLM())
            path = gen._test_file_path("mypackage/core.py", "helper", None)
            assert "test_core_helper.py" in path

    def test_test_file_path_with_output_dir(self, indexed_project):
        tmp_path, db = indexed_project
        out = tmp_path / "out"
        with GraphStore(db) as store:
            gen = TestGenerator(store, tmp_path, FakeLLM())
            path = gen._test_file_path("mypackage/core.py", "helper", out)
            assert "out" in path


# ---------------------------------------------------------------------------
# CodeReviewer tests
# ---------------------------------------------------------------------------


class TestReviewerStructural:
    def test_reviews_safe_file(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            reviewer = CodeReviewer(store, tmp_path)
            result = reviewer.review_files(["mypackage/core.py"])

        assert isinstance(result, CodeReview)
        assert result.changed_files == 1

    def test_detects_deleted_file_callers(self, indexed_project):
        tmp_path, db = indexed_project
        # Delete core.py (which api.py imports from)
        (tmp_path / "mypackage" / "core.py").unlink()

        with GraphStore(db) as store:
            reviewer = CodeReviewer(store, tmp_path)
            result = reviewer.review_files(["mypackage/core.py"])

        # Should find callers of the deleted file
        critical = [f for f in result.findings if f.severity == "critical"]
        assert len(critical) >= 1
        assert not result.approved

    def test_risk_score_zero_for_no_findings(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            reviewer = CodeReviewer(store, tmp_path)
            # Review a file with no breaking changes
            result = reviewer.review_files(["tests/test_core.py"])

        assert result.risk_score <= 0.5  # Low risk for test file

    def test_summary_says_safe_when_no_criticals(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            reviewer = CodeReviewer(store, tmp_path)
            result = reviewer.review_files(["tests/test_core.py"])

        # No critical findings on a test file
        assert "UNSAFE" not in result.summary or result.approved

    def test_markdown_output(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            reviewer = CodeReviewer(store, tmp_path)
            result = reviewer.review_files(["mypackage/core.py"])
            md = reviewer.to_markdown(result)

        assert "CodeBrain Structural Review" in md
        assert "Reviewed" in md


class TestReviewerLLM:
    def test_full_review_calls_llm(self, indexed_project):
        tmp_path, db = indexed_project
        fake_llm = FakeLLM(json.dumps([
            {
                "severity": "warning",
                "file": "mypackage/core.py",
                "line": 3,
                "message": "process() doesn't validate input",
                "suggestion": "Add input validation",
            }
        ]))

        with GraphStore(db) as store:
            reviewer = CodeReviewer(store, tmp_path, fake_llm)
            result = reviewer.review_files(["mypackage/core.py"], full=True)

        # LLM was called
        assert len(fake_llm.calls) >= 1
        # LLM finding included
        llm_findings = [f for f in result.findings if f.category == "llm_finding"]
        assert len(llm_findings) >= 1

    def test_handles_llm_error_gracefully(self, indexed_project):
        tmp_path, db = indexed_project
        fake_llm = FakeLLM("not valid json at all")

        with GraphStore(db) as store:
            reviewer = CodeReviewer(store, tmp_path, fake_llm)
            result = reviewer.review_files(["mypackage/core.py"], full=True)

        # Should not crash
        assert isinstance(result, CodeReview)


# ---------------------------------------------------------------------------
# Refactorer tests
# ---------------------------------------------------------------------------


class TestRefactorerSuggestions:
    def test_suggests_dead_code(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)
            suggestions = refactorer.suggest("dead_code")

        # May or may not find dead code in our simple project
        assert isinstance(suggestions, list)
        for s in suggestions:
            assert s.category == "dead_code"
            assert s.strategy == "remove"

    def test_suggests_god_class(self, indexed_project):
        tmp_path, db = indexed_project
        # Our Calculator has only 3 methods, so it shouldn't be flagged
        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)
            suggestions = refactorer.suggest("god_class")

        # No god class in our simple project
        for s in suggestions:
            assert s.category == "god_class"

    def test_suggests_all_categories(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)
            suggestions = refactorer.suggest("all")

        assert isinstance(suggestions, list)

    def test_suggestions_sorted_by_severity(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)
            suggestions = refactorer.suggest("all")

        if len(suggestions) >= 2:
            order = {"high": 0, "medium": 1, "low": 2}
            for i in range(len(suggestions) - 1):
                assert order.get(suggestions[i].severity, 3) <= order.get(suggestions[i + 1].severity, 3)


class TestRefactorerFixes:
    def test_fix_dead_code_removes_symbol(self, indexed_project):
        tmp_path, db = indexed_project

        suggestion = RefactorSuggestion(
            category="dead_code", severity="medium",
            file_path="mypackage/core.py", symbol_name="Calculator",
            message="Dead code: Calculator", strategy="remove",
        )

        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)
            result = refactorer.fix(suggestion, dry_run=True)

        assert result.status == "success"
        assert "Calculator" not in result.new_code
        assert result.patch  # Has a diff

    def test_fix_without_llm_skips(self, indexed_project):
        tmp_path, db = indexed_project

        suggestion = RefactorSuggestion(
            category="god_class", severity="high",
            file_path="mypackage/core.py", symbol_name="Calculator",
            message="God class", strategy="split_class",
        )

        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)  # no LLM
            result = refactorer.fix(suggestion, dry_run=True)

        assert result.status == "skipped"
        assert "LLM" in result.error

    def test_fix_with_llm(self, indexed_project):
        tmp_path, db = indexed_project
        new_code = textwrap.dedent("""\
            class Adder:
                def add(self, a, b):
                    return a + b

            class Subtractor:
                def subtract(self, a, b):
                    return a - b
        """)
        fake_llm = FakeLLM(f"```python\n{new_code}\n```")

        suggestion = RefactorSuggestion(
            category="god_class", severity="high",
            file_path="mypackage/core.py", symbol_name="Calculator",
            message="God class", strategy="split_class",
        )

        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path, fake_llm)
            result = refactorer.fix(suggestion, dry_run=True)

        assert result.status == "success"
        assert "Adder" in result.new_code

    def test_fix_all_dead_code(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)
            results = refactorer.fix_all("dead_code", dry_run=True, max_count=5)

        assert isinstance(results, list)


class TestRefactorerHelpers:
    def test_remove_symbol_from_source(self, indexed_project):
        tmp_path, db = indexed_project
        source = textwrap.dedent("""\
            def keep_me():
                pass

            def remove_me():
                x = 1
                return x

            def also_keep():
                pass
        """)

        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)
            result = refactorer._remove_symbol_from_source(source, "remove_me")

        assert "keep_me" in result
        assert "also_keep" in result
        assert "remove_me" not in result

    def test_make_patch(self, indexed_project):
        tmp_path, db = indexed_project
        old = "def foo():\n    pass\n"
        new = "def foo():\n    return 42\n"

        with GraphStore(db) as store:
            refactorer = Refactorer(store, tmp_path)
            patch = refactorer._make_patch("test.py", old, new)

        assert "---" in patch
        assert "+++" in patch


# ---------------------------------------------------------------------------
# ActionEngine base tests
# ---------------------------------------------------------------------------


class TestActionEngineBase:
    def test_extract_code_from_fences(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            engine = ActionEngine(store, tmp_path, FakeLLM())
            code = engine._extract_code("Here's the code:\n```python\ndef foo():\n    pass\n```\nDone!")
            assert code == "def foo():\n    pass"

    def test_extract_code_no_fences(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            engine = ActionEngine(store, tmp_path, FakeLLM())
            code = engine._extract_code("def foo():\n    pass\n")
            assert "def foo" in code

    def test_validate_python_valid(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            engine = ActionEngine(store, tmp_path, FakeLLM())
            errors = engine._validate_python("def foo():\n    pass\n")
            assert errors == []

    def test_validate_python_invalid(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            engine = ActionEngine(store, tmp_path, FakeLLM())
            errors = engine._validate_python("def foo(:\n    pass\n")
            assert len(errors) >= 1

    def test_get_file_source(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            engine = ActionEngine(store, tmp_path, FakeLLM())
            source = engine._get_file_source("mypackage/core.py")
            assert "process" in source

    def test_get_function_source(self, indexed_project):
        tmp_path, db = indexed_project
        with GraphStore(db) as store:
            engine = ActionEngine(store, tmp_path, FakeLLM())
            source = engine._get_function_source("mypackage/core.py", "process", 1)
            assert "process" in source


# ---------------------------------------------------------------------------
# CLI tests
# ---------------------------------------------------------------------------


class TestCLI:
    def test_gen_test_no_args_shows_error(self, indexed_project):
        tmp_path, db = indexed_project
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(tmp_path), "gen-test"])
        assert result.exit_code != 0

    def test_review_structural(self, indexed_project):
        tmp_path, db = indexed_project
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, [
            "--repo", str(tmp_path), "review",
            "--files", "mypackage/core.py",
        ])
        assert result.exit_code == 0, f"output={result.output}"
        assert "CodeBrain" in result.output

    def test_review_json(self, indexed_project):
        tmp_path, db = indexed_project
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, [
            "--repo", str(tmp_path), "review",
            "--files", "mypackage/core.py", "--json",
        ])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "findings" in data
        assert "approved" in data

    def test_refactor_suggest(self, indexed_project):
        tmp_path, db = indexed_project
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, [
            "--repo", str(tmp_path), "refactor", "--suggest",
        ])
        assert result.exit_code == 0

    def test_refactor_suggest_json(self, indexed_project):
        tmp_path, db = indexed_project
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, [
            "--repo", str(tmp_path), "refactor", "--suggest", "--json",
        ])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)
