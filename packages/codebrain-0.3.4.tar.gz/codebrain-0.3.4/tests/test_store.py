"""Tests for the GraphStore."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode


def _make_parsed_file() -> ParsedFile:
    """Create a sample ParsedFile for testing."""
    return ParsedFile(
        path="pkg/module.py",
        content_hash="abc123",
        line_count=50,
        nodes=[
            ParsedNode(
                id="pkg/module.py::module",
                name="module",
                qualified_name="pkg.module",
                type="file",
                file_path="pkg/module.py",
                line_start=1,
                line_end=50,
                is_exported=True,
            ),
            ParsedNode(
                id="pkg/module.py::foo",
                name="foo",
                qualified_name="foo",
                type="function",
                file_path="pkg/module.py",
                line_start=5,
                line_end=10,
                signature="(x: int) -> str",
                docstring="Do foo things.",
                is_exported=True,
            ),
            ParsedNode(
                id="pkg/module.py::Bar",
                name="Bar",
                qualified_name="Bar",
                type="class",
                file_path="pkg/module.py",
                line_start=12,
                line_end=30,
                decorators=["dataclass"],
                is_exported=True,
            ),
            ParsedNode(
                id="pkg/module.py::Bar.baz",
                name="baz",
                qualified_name="Bar.baz",
                type="method",
                file_path="pkg/module.py",
                line_start=15,
                line_end=20,
                signature="(self)",
            ),
        ],
        edges=[
            ParsedEdge(
                source="pkg/module.py::foo",
                target="pkg/module.py::Bar.baz",
                type="CALLS",
                file_path="pkg/module.py",
                line=8,
            ),
            ParsedEdge(
                source="pkg/module.py::module",
                target="os",
                type="IMPORTS",
                file_path="pkg/module.py",
                line=1,
            ),
            ParsedEdge(
                source="pkg/module.py::module",
                target="pkg/module.py::foo",
                type="CONTAINS",
                file_path="pkg/module.py",
                line=5,
            ),
        ],
    )


class TestUpsertFile:
    def test_upsert_creates_nodes(self, store: GraphStore) -> None:
        pf = _make_parsed_file()
        store.upsert_file(pf)
        nodes = store.get_nodes_by_file("pkg/module.py")
        assert len(nodes) == 4

    def test_upsert_creates_edges(self, store: GraphStore) -> None:
        pf = _make_parsed_file()
        store.upsert_file(pf)
        edges = store.get_edges_from("pkg/module.py::foo")
        assert len(edges) == 1
        assert edges[0]["type"] == "CALLS"

    def test_upsert_replaces_on_second_call(self, store: GraphStore) -> None:
        pf = _make_parsed_file()
        store.upsert_file(pf)
        # Upsert again with fewer nodes
        pf2 = ParsedFile(
            path="pkg/module.py",
            content_hash="def456",
            line_count=10,
            nodes=[
                ParsedNode(
                    id="pkg/module.py::module",
                    name="module",
                    qualified_name="pkg.module",
                    type="file",
                    file_path="pkg/module.py",
                    line_start=1,
                    line_end=10,
                ),
            ],
            edges=[],
        )
        store.upsert_file(pf2)
        nodes = store.get_nodes_by_file("pkg/module.py")
        assert len(nodes) == 1


class TestRemoveFile:
    def test_remove_deletes_everything(self, store: GraphStore) -> None:
        pf = _make_parsed_file()
        store.upsert_file(pf)
        store.remove_file("pkg/module.py")
        assert store.get_nodes_by_file("pkg/module.py") == []
        assert store.get_edges_from("pkg/module.py::foo") == []


class TestNodeQueries:
    def test_get_node_by_id(self, store: GraphStore) -> None:
        store.upsert_file(_make_parsed_file())
        node = store.get_node("pkg/module.py::foo")
        assert node is not None
        assert node["name"] == "foo"
        assert node["signature"] == "(x: int) -> str"

    def test_get_node_missing(self, store: GraphStore) -> None:
        assert store.get_node("nonexistent") is None

    def test_get_nodes_by_name(self, store: GraphStore) -> None:
        store.upsert_file(_make_parsed_file())
        nodes = store.get_nodes_by_name("foo")
        assert len(nodes) == 1

    def test_get_all_nodes_with_filter(self, store: GraphStore) -> None:
        store.upsert_file(_make_parsed_file())
        functions = store.get_all_nodes(type_filter="function")
        assert all(n["type"] == "function" for n in functions)
        assert len(functions) == 1


class TestEdgeQueries:
    def test_edges_from(self, store: GraphStore) -> None:
        store.upsert_file(_make_parsed_file())
        edges = store.get_edges_from("pkg/module.py::foo")
        assert len(edges) == 1

    def test_edges_to(self, store: GraphStore) -> None:
        store.upsert_file(_make_parsed_file())
        edges = store.get_edges_to("pkg/module.py::Bar.baz")
        assert len(edges) == 1
        assert edges[0]["source"] == "pkg/module.py::foo"


class TestStats:
    def test_stats(self, store: GraphStore) -> None:
        store.upsert_file(_make_parsed_file())
        stats = store.get_stats()
        assert stats["files"] == 1
        assert stats["nodes"] == 4
        assert stats["edges"] == 3
        assert "CALLS" in stats["edge_types"]

    def test_file_hash(self, store: GraphStore) -> None:
        store.upsert_file(_make_parsed_file())
        h = store.get_file_hash("pkg/module.py")
        assert h == "abc123"

    def test_file_hash_missing(self, store: GraphStore) -> None:
        assert store.get_file_hash("nonexistent.py") is None
