"""Tests for the git diff impact analyzer."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from codebrain.graph.store import GraphStore
from codebrain.diff_impact import DiffImpactAnalyzer


@pytest.fixture
def impact_store(indexed_project: tuple[Path, GraphStore]):
    _, store = indexed_project
    return store


@pytest.fixture
def repo_root(indexed_project: tuple[Path, GraphStore]):
    root, _ = indexed_project
    return root


class TestDiffImpactAnalyzer:
    def test_no_changes(self, impact_store: GraphStore, repo_root: Path):
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=[]):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze()
            assert result["blast_radius"]["files"] == 0
            assert result["risk_assessment"] == "low"
            assert "No changes" in result["narrative"]

    def test_result_structure(self, impact_store: GraphStore, repo_root: Path):
        changed = [{"path": "myapp/models.py", "status": "modified"}]
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=changed):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze()
            assert "changed_files" in result
            assert "affected_symbols" in result
            assert "blast_radius" in result
            assert "risk_assessment" in result
            assert "risk_details" in result
            assert "cross_layer_impact" in result
            assert "narrative" in result

    def test_risk_levels_valid(self, impact_store: GraphStore, repo_root: Path):
        changed = [{"path": "myapp/models.py", "status": "modified"}]
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=changed):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze()
            assert result["risk_assessment"] in ("low", "medium", "high", "critical")

    def test_blast_radius_percentage(self, impact_store: GraphStore, repo_root: Path):
        changed = [{"path": "myapp/models.py", "status": "modified"}]
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=changed):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze()
            pct = result["blast_radius"]["percentage"]
            assert isinstance(pct, float)
            assert 0 <= pct <= 100

    def test_ref_in_narrative(self, impact_store: GraphStore, repo_root: Path):
        changed = [{"path": "myapp/models.py", "status": "modified"}]
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=changed):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze(ref="main")
            assert "main" in result["narrative"]

    def test_git_diff_parsing(self, impact_store: GraphStore, repo_root: Path):
        mock_result = MagicMock()
        mock_result.stdout = "M\tmyapp/models.py\nA\tmyapp/new.py\nD\tmyapp/old.py\n"
        mock_untracked = MagicMock()
        mock_untracked.stdout = ""

        with patch("subprocess.run", side_effect=[mock_result, mock_untracked]):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            files = analyzer._get_changed_files()
            assert len(files) == 3
            statuses = {f["status"] for f in files}
            assert "modified" in statuses
            assert "added" in statuses
            assert "deleted" in statuses

    def test_deleted_file_risk(self, impact_store: GraphStore, repo_root: Path):
        changed = [{"path": "myapp/models.py", "status": "deleted"}]
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=changed):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze()
            assert any("deleted" in d.lower() for d in result["risk_details"])

    def test_multiple_files_changed(self, impact_store: GraphStore, repo_root: Path):
        changed = [
            {"path": "myapp/models.py", "status": "modified"},
            {"path": "myapp/api.py", "status": "modified"},
        ]
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=changed):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze()
            assert len(result["changed_files"]) == 2

    def test_affected_symbols_capped(self, impact_store: GraphStore, repo_root: Path):
        changed = [{"path": "myapp/models.py", "status": "modified"}]
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=changed):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze()
            assert len(result["affected_symbols"]) <= 100

    def test_narrative_mentions_files(self, impact_store: GraphStore, repo_root: Path):
        changed = [{"path": "myapp/models.py", "status": "modified"}]
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=changed):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze()
            assert "1 file" in result["narrative"]

    def test_staged_only_flag(self, impact_store: GraphStore, repo_root: Path):
        """staged_only parameter should be accepted."""
        with patch.object(DiffImpactAnalyzer, '_get_changed_files', return_value=[]):
            analyzer = DiffImpactAnalyzer(impact_store, repo_root)
            result = analyzer.analyze(staged_only=True)
            assert result["risk_assessment"] == "low"
