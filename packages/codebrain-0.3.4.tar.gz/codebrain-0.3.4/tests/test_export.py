"""Tests for the export module."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from codebrain.export import GraphExporter
from codebrain.graph.store import GraphStore


class TestDotExport:
    def test_dot_full_graph(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        dot = exporter.to_dot()
        assert dot.startswith('digraph "CodeBrain"')
        assert "}" in dot
        assert "->" in dot
        store.close()

    def test_dot_custom_title(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        dot = exporter.to_dot(title="My Project")
        assert 'digraph "My Project"' in dot
        store.close()

    def test_dot_subgraph_by_symbol(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name="process")
        dot = exporter.to_dot(nodes, edges)
        assert "digraph" in dot
        store.close()

    def test_dot_subgraph_by_file(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(file_path="mypackage/core.py")
        dot = exporter.to_dot(nodes, edges)
        assert "digraph" in dot
        store.close()

    def test_dot_empty_subgraph(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name="nonexistent_xyz")
        dot = exporter.to_dot(nodes, edges)
        assert "digraph" in dot
        store.close()


class TestMermaidExport:
    def test_mermaid_full_graph(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        mermaid = exporter.to_mermaid()
        assert mermaid.startswith("flowchart LR")
        store.close()

    def test_mermaid_subgraph(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name="process")
        mermaid = exporter.to_mermaid(nodes, edges)
        assert "flowchart" in mermaid
        store.close()

    def test_mermaid_contains_nodes(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        mermaid = exporter.to_mermaid()
        # Should contain some node definitions
        assert "function" in mermaid or "class" in mermaid or "file" in mermaid
        store.close()


class TestHtmlExport:
    def test_html_report(self, indexed_project):
        pytest.importorskip("jinja2")
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        html = exporter.to_html_report()
        assert "<!DOCTYPE html>" in html
        assert "CodeBrain Report" in html
        assert "Overview" in html
        store.close()

    def test_html_contains_stats(self, indexed_project):
        pytest.importorskip("jinja2")
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        html = exporter.to_html_report()
        assert "Files" in html
        assert "Symbols" in html
        store.close()

    def test_html_write_to_file(self, indexed_project, tmp_path):
        pytest.importorskip("jinja2")
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        html = exporter.to_html_report()
        out = tmp_path / "report.html"
        out.write_text(html)
        assert out.exists()
        assert out.stat().st_size > 0
        store.close()


class TestGetSubgraph:
    def test_full_graph(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph()
        assert len(nodes) > 0
        assert len(edges) > 0
        store.close()

    def test_symbol_subgraph(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name="helper")
        assert len(nodes) > 0
        store.close()

    def test_file_subgraph(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(file_path="mypackage/utils.py")
        assert len(nodes) > 0
        store.close()

    def test_nonexistent_symbol(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name="does_not_exist_xyz")
        assert nodes == []
        assert edges == []
        store.close()


class TestCliExport:
    def test_export_dot_cli(self, indexed_project):
        from click.testing import CliRunner
        from codebrain.cli import cli

        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(repo_root), "export", "dot"])
        assert result.exit_code == 0
        assert "digraph" in result.output

    def test_export_mermaid_cli(self, indexed_project):
        from click.testing import CliRunner
        from codebrain.cli import cli

        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(repo_root), "export", "mermaid"])
        assert result.exit_code == 0
        assert "flowchart" in result.output

    def test_export_dot_to_file(self, indexed_project, tmp_path):
        from click.testing import CliRunner
        from codebrain.cli import cli

        repo_root, store = indexed_project
        store.close()
        out = tmp_path / "test.dot"
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(repo_root), "export", "dot", "-o", str(out)])
        assert result.exit_code == 0
        assert out.exists()
        content = out.read_text()
        assert "digraph" in content

    def test_export_html_cli(self, indexed_project, tmp_path):
        pytest.importorskip("jinja2")
        from click.testing import CliRunner
        from codebrain.cli import cli

        repo_root, store = indexed_project
        store.close()
        out = tmp_path / "report.html"
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(repo_root), "export", "html", "-o", str(out)])
        assert result.exit_code == 0
        assert out.exists()


class TestSubgraphEdgeResolution:
    """Verify that get_subgraph resolves unresolved edge targets so CALLS edges appear."""

    def test_calls_edges_in_mermaid_subgraph(self, indexed_project):
        repo_root, store = indexed_project
        exporter = GraphExporter(store)
        # "process" calls "helper" — the edge target may be bare "helper" in the DB
        nodes, edges = exporter.get_subgraph(name="process")
        mermaid = exporter.to_mermaid(nodes, edges)
        # The CALLS edge should be renderable (both source and target are known nodes)
        calls_edges = [e for e in edges if e["type"] == "CALLS"]
        node_ids = {n["id"] for n in nodes}
        rendered_calls = [e for e in calls_edges if e["source"] in node_ids and e["target"] in node_ids]
        assert len(rendered_calls) > 0, (
            f"No CALLS edges rendered. Node IDs: {node_ids}, "
            f"CALLS edges: {[(e['source'], e['target']) for e in calls_edges]}"
        )
        store.close()
