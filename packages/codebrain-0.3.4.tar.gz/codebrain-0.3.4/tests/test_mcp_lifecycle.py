"""Tests for codebrain.mcp_lifecycle — watchdog and PID-file self-heal logic.

Most tests exercise the helper functions directly. The exit paths
(parent_watchdog, idle_watchdog) call os._exit(0), which would kill the
pytest runner; we verify their behavior end-to-end via subprocess.
"""
from __future__ import annotations

import os
import subprocess
import sys
import textwrap
import time
from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR
from codebrain import mcp_lifecycle as ml


# ---------------------------------------------------------------------------
# Helper-function tests (do not trigger os._exit)
# ---------------------------------------------------------------------------


def test_mark_activity_advances_timestamp():
    before = ml._last_activity
    time.sleep(0.01)
    ml.mark_activity()
    assert ml._last_activity > before


def test_read_pid_file_handles_missing(tmp_path):
    assert ml._read_pid_file(tmp_path / "missing.pid") is None


def test_read_pid_file_returns_first_line(tmp_path):
    pid_file = tmp_path / "mcp.pid"
    pid_file.write_text("12345\n1700000000\n")
    assert ml._read_pid_file(pid_file) == 12345


def test_read_pid_file_handles_garbage(tmp_path):
    pid_file = tmp_path / "mcp.pid"
    pid_file.write_text("not-a-number\n")
    assert ml._read_pid_file(pid_file) is None


def test_write_pid_file_creates_parent(tmp_path):
    pid_file = tmp_path / "deep" / CODEBRAIN_DIR / "mcp.pid"
    ml._write_pid_file(pid_file)
    assert pid_file.exists()
    assert ml._read_pid_file(pid_file) == os.getpid()


def test_remove_pid_file_only_removes_own(tmp_path):
    pid_file = tmp_path / "mcp.pid"
    # File owned by a different PID — must NOT be removed.
    pid_file.write_text("99999999\n0\n")
    ml._remove_pid_file(pid_file)
    assert pid_file.exists()

    # File owned by us — should be removed.
    ml._write_pid_file(pid_file)
    ml._remove_pid_file(pid_file)
    assert not pid_file.exists()


def test_kill_stale_predecessor_no_file_is_noop(tmp_path):
    pid_file = tmp_path / "mcp.pid"
    # Should not raise.
    ml._kill_stale_predecessor(pid_file)


def test_kill_stale_predecessor_skips_dead_pid(tmp_path):
    # Fabricated dead PID. _kill_stale_predecessor must return cleanly.
    pid_file = tmp_path / "mcp.pid"
    pid_file.write_text("99999998\n0\n")
    ml._kill_stale_predecessor(pid_file)


def test_kill_stale_predecessor_skips_non_codebrain_pid(tmp_path):
    """If the PID belongs to an unrelated process (e.g. PID was reused),
    we must NOT terminate it."""
    pid_file = tmp_path / "mcp.pid"
    # Use the test runner's own PID — definitely not a codebrain.mcp_server.
    pid_file.write_text(f"{os.getpid()}\n0\n")
    # This must not call os._exit or terminate the test runner.
    ml._kill_stale_predecessor(pid_file)


def test_find_db_lock_holder_no_pid_file(tmp_path):
    assert ml.find_db_lock_holder(tmp_path) is None


def test_find_db_lock_holder_stale_pid_returns_none(tmp_path):
    pid_file = tmp_path / CODEBRAIN_DIR / "mcp.pid"
    pid_file.parent.mkdir(parents=True)
    pid_file.write_text("99999997\n0\n")
    assert ml.find_db_lock_holder(tmp_path) is None


def test_find_db_lock_holder_skips_unrelated_process(tmp_path):
    """A live PID that isn't a codebrain.mcp_server must not be reported."""
    pid_file = tmp_path / CODEBRAIN_DIR / "mcp.pid"
    pid_file.parent.mkdir(parents=True)
    pid_file.write_text(f"{os.getpid()}\n0\n")
    assert ml.find_db_lock_holder(tmp_path) is None


def test_find_watch_target_falls_back_when_no_host_match(monkeypatch):
    """No claude/cursor/etc. ancestor → return the start pid unchanged."""
    psutil = pytest.importorskip("psutil")

    class _Proc:
        def __init__(self, pid, name, parent=None, ctime=123.0):
            self.pid = pid
            self._name = name
            self._parent = parent
            self._ctime = ctime
        def name(self): return self._name
        def parent(self): return self._parent
        def create_time(self): return self._ctime

    great = _Proc(10, "init")
    grand = _Proc(11, "bash", parent=great, ctime=200.0)
    parent = _Proc(12, "python", parent=grand, ctime=300.0)

    def fake_process(pid):
        return {10: great, 11: grand, 12: parent}[pid]

    monkeypatch.setattr(psutil, "Process", fake_process)
    pid, ctime = ml._find_watch_target(12)
    assert pid == 12
    assert ctime == 300.0


def test_find_watch_target_walks_to_claude(monkeypatch):
    """Ancestor named claude.exe → watch that, not the immediate parent."""
    psutil = pytest.importorskip("psutil")

    class _Proc:
        def __init__(self, pid, name, parent=None, ctime=0.0):
            self.pid = pid
            self._name = name
            self._parent = parent
            self._ctime = ctime
        def name(self): return self._name
        def parent(self): return self._parent
        def create_time(self): return self._ctime

    claude = _Proc(100, "claude.exe", ctime=1000.0)
    launcher = _Proc(200, "cmd.exe", parent=claude, ctime=2000.0)
    py = _Proc(300, "python.exe", parent=launcher, ctime=3000.0)

    monkeypatch.setattr(psutil, "Process", lambda pid: {100: claude, 200: launcher, 300: py}[pid])
    pid, ctime = ml._find_watch_target(300)
    assert pid == 100
    assert ctime == 1000.0


def test_find_watch_target_handles_no_psutil(monkeypatch):
    """psutil missing → return start_pid with no create_time."""
    import builtins
    real_import = builtins.__import__

    def blocked(name, *a, **k):
        if name == "psutil":
            raise ImportError("simulated")
        return real_import(name, *a, **k)

    monkeypatch.setattr(builtins, "__import__", blocked)
    pid, ctime = ml._find_watch_target(42)
    assert pid == 42
    assert ctime is None


def test_install_watchdogs_is_idempotent(tmp_path, monkeypatch):
    monkeypatch.setattr(ml, "_installed", False)
    ml.install_watchdogs(tmp_path)
    assert ml._installed is True
    # Second call must not raise / write a new PID file twice / start more threads.
    ml.install_watchdogs(tmp_path)


def test_install_watchdogs_writes_pid_file(tmp_path, monkeypatch):
    monkeypatch.setattr(ml, "_installed", False)
    ml.install_watchdogs(tmp_path)
    pid_file = tmp_path / CODEBRAIN_DIR / "mcp.pid"
    assert pid_file.exists()
    assert ml._read_pid_file(pid_file) == os.getpid()


def test_install_watchdogs_kills_stale_predecessor(tmp_path, monkeypatch):
    """A previous PID file pointing to a real codebrain.mcp_server should be
    killed. We simulate by spawning a real subprocess that imports
    codebrain.mcp_server (so the cmdline check passes), then writing its
    PID. The host-detection is stubbed because the pytest runner's ancestor
    chain may legitimately contain an IDE host on dev machines (VS Code,
    PyCharm) which would otherwise correctly spare the spawned process."""
    monkeypatch.setattr(ml, "_installed", False)
    monkeypatch.setattr(ml, "_predecessor_has_live_host", lambda _pid: False)
    pid_file = tmp_path / CODEBRAIN_DIR / "mcp.pid"
    pid_file.parent.mkdir(parents=True)

    # Spawn a fake "codebrain.mcp_server" process that just sleeps.
    # We have to make psutil's cmdline check succeed, so include the literal
    # string in argv.
    proc = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(60)", "codebrain.mcp_server"],
    )
    try:
        time.sleep(0.5)
        pid_file.write_text(f"{proc.pid}\n0\n")

        ml.install_watchdogs(tmp_path)

        # Wait briefly for terminate.
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pytest.fail(f"Stale predecessor PID {proc.pid} was not terminated")
    finally:
        if proc.poll() is None:
            proc.kill()


def test_kill_stale_predecessor_spares_sibling_with_live_host(tmp_path, monkeypatch):
    """Predecessor whose ancestor chain contains a live IDE host represents a
    concurrent sibling Claude session — must not be terminated."""
    pytest.importorskip("psutil")
    monkeypatch.setattr(ml, "_predecessor_has_live_host", lambda _pid: True)

    proc = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(10)", "codebrain.mcp_server"],
    )
    try:
        time.sleep(0.3)
        pid_file = tmp_path / "mcp.pid"
        pid_file.write_text(f"{proc.pid}\n0\n")

        ml._kill_stale_predecessor(pid_file)

        time.sleep(0.5)
        assert proc.poll() is None, "Sibling MCP killed despite live host"
    finally:
        proc.kill()
        proc.wait(timeout=5)


def test_predecessor_has_live_host_returns_true_for_claude_ancestor(monkeypatch):
    psutil = pytest.importorskip("psutil")

    class _Proc:
        def __init__(self, pid, name, parent=None):
            self.pid = pid
            self._name = name
            self._parent = parent
        def name(self): return self._name
        def parent(self): return self._parent

    claude = _Proc(100, "claude.exe")
    cmd = _Proc(200, "cmd.exe", parent=claude)
    py = _Proc(300, "python.exe", parent=cmd)
    monkeypatch.setattr(psutil, "Process", lambda pid: {100: claude, 200: cmd, 300: py}[pid])

    assert ml._predecessor_has_live_host(300) is True


def test_predecessor_has_live_host_returns_false_for_orphan(monkeypatch):
    psutil = pytest.importorskip("psutil")

    class _Proc:
        def __init__(self, pid, name, parent=None):
            self.pid = pid
            self._name = name
            self._parent = parent
        def name(self): return self._name
        def parent(self): return self._parent

    # python ← bash ← init — no IDE host anywhere.
    init = _Proc(1, "init")
    sh = _Proc(2, "bash", parent=init)
    py = _Proc(3, "python.exe", parent=sh)
    monkeypatch.setattr(psutil, "Process", lambda pid: {1: init, 2: sh, 3: py}[pid])

    assert ml._predecessor_has_live_host(3) is False


# ---------------------------------------------------------------------------
# Stale-MCP discovery
# ---------------------------------------------------------------------------


def test_find_stale_mcps_excludes_self():
    # The test runner is not a codebrain.mcp_server, so this should be empty
    # (or at least not contain our PID).
    stale = ml.find_stale_mcps()
    assert all(s["pid"] != os.getpid() for s in stale)


def test_find_stale_mcps_detects_orphaned_process(tmp_path):
    """Spawn a child that pretends to be codebrain.mcp_server (via argv),
    then kill its parent representation by detaching. Cross-platform
    detection of 'parent dead' is messy in a pytest harness, so we test the
    age path instead by mocking create_time."""
    import psutil

    proc = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(30)", "codebrain.mcp_server"],
    )
    try:
        time.sleep(0.3)
        pid = proc.pid

        # Force the age path: monkey-patch create_time for this PID.
        original = psutil.Process.create_time

        def fake_create_time(self):
            if self.pid == pid:
                return time.time() - (ml.STALE_AGE_SECONDS + 100)
            return original(self)

        psutil.Process.create_time = fake_create_time
        try:
            stale = ml.find_stale_mcps()
        finally:
            psutil.Process.create_time = original

        pids = [s["pid"] for s in stale]
        assert pid in pids, f"expected PID {pid} in stale list, got {pids}"
        entry = next(s for s in stale if s["pid"] == pid)
        assert "running" in entry["reason"]
    finally:
        proc.kill()
        proc.wait(timeout=5)


def test_kill_pid_handles_dead_process():
    # Fabricated dead PID. kill_pid must return an error string, not raise.
    result = ml.kill_pid(99999996, timeout=0.5)
    assert result.startswith("error")


def test_kill_pid_terminates_live_process():
    proc = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(30)"],
    )
    try:
        time.sleep(0.3)
        result = ml.kill_pid(proc.pid, timeout=3)
        assert result in ("terminated", "killed")
        assert proc.wait(timeout=3) is not None
    finally:
        if proc.poll() is None:
            proc.kill()


# ---------------------------------------------------------------------------
# Subprocess-based watchdog tests (verify os._exit actually fires)
# ---------------------------------------------------------------------------


def _run_watchdog_subprocess(script: str, env_overrides: dict | None = None, timeout: float = 30.0) -> tuple[int, str]:
    """Run a tiny script that installs the watchdogs and waits to be killed."""
    env = os.environ.copy()
    if env_overrides:
        env.update(env_overrides)
    result = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
    )
    return result.returncode, result.stderr


def test_idle_watchdog_exits_subprocess(tmp_path):
    """Force a 2s idle timeout and verify the subprocess exits within ~10s."""
    script = textwrap.dedent("""
        import os, time, sys, pathlib
        from codebrain import mcp_lifecycle as ml
        ml.IDLE_TIMEOUT_SECONDS = 2
        ml.install_watchdogs(pathlib.Path(os.environ["CB_TEST_REPO"]))
        time.sleep(20)
        sys.exit(99)  # should never reach this
    """)
    start = time.time()
    rc, _err = _run_watchdog_subprocess(
        script,
        env_overrides={"CB_TEST_REPO": str(tmp_path), "CODEBRAIN_MCP_IDLE_TIMEOUT": "2"},
        timeout=15,
    )
    elapsed = time.time() - start
    assert rc == 0, f"expected clean exit from idle watchdog, got rc={rc} stderr={_err[-500:]}"
    assert elapsed < 12, f"idle watchdog took too long ({elapsed:.1f}s)"


def test_parent_watchdog_exits_when_parent_dies(tmp_path):
    """Spawn a parent that spawns the MCP-style child, then kill the parent."""
    parent_script = textwrap.dedent("""
        import os, subprocess, sys, time
        child_script = (
            "import os, time, pathlib\\n"
            "from codebrain import mcp_lifecycle as ml\\n"
            "ml.PARENT_POLL_SECONDS = 1\\n"
            "ml.install_watchdogs(pathlib.Path(os.environ['CB_TEST_REPO']))\\n"
            "time.sleep(60)\\n"
        )
        proc = subprocess.Popen([sys.executable, "-c", child_script])
        print(proc.pid, flush=True)
        time.sleep(60)
    """)

    env = os.environ.copy()
    env["CB_TEST_REPO"] = str(tmp_path)
    # Without this, _find_watch_target may walk past the test parent to the
    # IDE running pytest (claude/cursor/code) and watch *that* — which stays
    # alive when we kill the immediate parent, defeating the test.
    env["CODEBRAIN_MCP_DISABLE_ANCESTOR_WALK"] = "1"
    parent = subprocess.Popen(
        [sys.executable, "-c", parent_script],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=env,
    )
    try:
        # Read child PID
        child_pid_line = parent.stdout.readline().strip()
        child_pid = int(child_pid_line)
        time.sleep(2)  # let watchdog install

        # Kill the parent. Child should self-terminate within PARENT_POLL_SECONDS+grace.
        parent.kill()
        parent.wait(timeout=5)

        # Wait up to 10s for child to exit.
        import psutil
        deadline = time.time() + 10
        while time.time() < deadline:
            if not psutil.pid_exists(child_pid):
                return
            time.sleep(0.5)
        # Cleanup if still alive
        try:
            psutil.Process(child_pid).kill()
        except psutil.NoSuchProcess:
            return
        pytest.fail(f"child PID {child_pid} did not exit after parent died")
    finally:
        if parent.poll() is None:
            parent.kill()
