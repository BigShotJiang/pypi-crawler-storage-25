"""Tests for SPEC-M24: full docstrings + structural code fingerprints."""

from __future__ import annotations

import ast
import textwrap

import pytest

from codebrain.parser.python_parser import (
    _build_class_fingerprint,
    _build_fingerprint,
    _collect_io_patterns,
    _get_docstring,
    _summarize_expr,
)


# ---------- Helpers ----------

def _fp(code: str) -> str:
    """Parse a function and return its fingerprint."""
    tree = ast.parse(textwrap.dedent(code))
    func = tree.body[0]
    return _build_fingerprint(func)


def _class_fp(code: str) -> str:
    """Parse a class and return its fingerprint."""
    tree = ast.parse(textwrap.dedent(code))
    cls = tree.body[0]
    return _build_class_fingerprint(cls)


# ================================================================
# 1. Full Docstring Storage
# ================================================================

class TestFullDocstrings:
    def test_multiline_docstring_preserved(self):
        code = textwrap.dedent('''\
            def foo():
                """This is a long docstring.

                It has multiple paragraphs explaining
                the function's behavior in detail.

                Args:
                    x: something
                """
                pass
        ''')
        tree = ast.parse(code)
        ds = _get_docstring(tree.body[0])
        assert "multiple paragraphs" in ds
        assert "Args:" in ds

    def test_single_line_docstring(self):
        code = 'def foo():\n    """Short."""\n    pass'
        tree = ast.parse(code)
        assert _get_docstring(tree.body[0]) == "Short."

    def test_no_docstring(self):
        code = "def foo():\n    pass"
        tree = ast.parse(code)
        assert _get_docstring(tree.body[0]) == ""

    def test_docstring_truncated_at_max_length(self):
        code = f'def foo():\n    """{"x" * 5000}"""\n    pass'
        tree = ast.parse(code)
        ds = _get_docstring(tree.body[0], max_length=4000)
        assert len(ds) == 4000

    def test_class_docstring(self):
        code = textwrap.dedent('''\
            class Foo:
                """Full class documentation.

                Detailed explanation here.
                """
                pass
        ''')
        tree = ast.parse(code)
        ds = _get_docstring(tree.body[0])
        assert "Full class documentation" in ds
        assert "Detailed explanation" in ds


# ================================================================
# 2. _summarize_expr
# ================================================================

class TestSummarizeExpr:
    def test_none_literal(self):
        node = ast.parse("None", mode="eval").body
        assert _summarize_expr(node) == "None"

    def test_bool_literal(self):
        node = ast.parse("True", mode="eval").body
        assert _summarize_expr(node) == "bool"

    def test_string_literal(self):
        node = ast.parse("'hello'", mode="eval").body
        assert _summarize_expr(node) == "str"

    def test_number_literal(self):
        node = ast.parse("42", mode="eval").body
        assert _summarize_expr(node) == "number"

    def test_name(self):
        node = ast.parse("result", mode="eval").body
        assert _summarize_expr(node) == "result"

    def test_call(self):
        node = ast.parse("foo()", mode="eval").body
        assert _summarize_expr(node) == "foo()"

    def test_attribute_call(self):
        node = ast.parse("obj.method()", mode="eval").body
        assert _summarize_expr(node) == "*.method()"

    def test_dict(self):
        node = ast.parse("{}", mode="eval").body
        assert _summarize_expr(node) == "dict"

    def test_list(self):
        node = ast.parse("[]", mode="eval").body
        assert _summarize_expr(node) == "list"

    def test_fstring(self):
        node = ast.parse("f'hello {x}'", mode="eval").body
        assert _summarize_expr(node) == "f-string"


# ================================================================
# 3. _build_fingerprint — Returns
# ================================================================

class TestFingerprintReturns:
    def test_single_return(self):
        fp = _fp("def f():\n    return 42")
        assert "returns: number" in fp

    def test_multiple_returns(self):
        fp = _fp("def f(x):\n    if x:\n        return True\n    return False")
        assert "returns: bool" in fp

    def test_no_return(self):
        fp = _fp("def f():\n    pass")
        assert fp == ""

    def test_return_call(self):
        fp = _fp("def f():\n    return foo()")
        assert "returns: foo()" in fp


# ================================================================
# 4. _build_fingerprint — Raises & Mutations
# ================================================================

class TestFingerprintRaisesAndMutations:
    def test_raises(self):
        fp = _fp("def f():\n    raise ValueError('bad')")
        assert "raises: ValueError" in fp

    def test_mutations(self):
        fp = _fp("def f(self):\n    self.x = 1\n    self.y = 2")
        assert "mutates:" in fp
        assert "self.x" in fp
        assert "self.y" in fp

    def test_augmented_mutation(self):
        fp = _fp("def f(self):\n    self.count += 1")
        assert "mutates: self.count" in fp


# ================================================================
# 5. _build_fingerprint — Control Flow
# ================================================================

class TestFingerprintControlFlow:
    def test_loop(self):
        fp = _fp("def f():\n    for x in y:\n        pass")
        assert "control: loop" in fp

    def test_while_loop(self):
        fp = _fp("def f():\n    while True:\n        break")
        assert "control: while-loop" in fp

    def test_try_except(self):
        fp = _fp("def f():\n    try:\n        x()\n    except ValueError:\n        pass")
        assert "try/except ValueError" in fp

    def test_context_manager(self):
        fp = _fp("def f():\n    with open('x') as fh:\n        pass")
        assert "context-manager" in fp

    def test_assert(self):
        fp = _fp("def f(x):\n    assert x > 0")
        assert "assert" in fp


# ================================================================
# 6. _build_fingerprint — I/O Patterns
# ================================================================

class TestFingerprintIO:
    def test_open_detected(self):
        fp = _fp("def f():\n    open('file.txt')")
        assert "io: file-io" in fp

    def test_print_detected(self):
        fp = _fp("def f():\n    print('hello')")
        assert "io: stdout" in fp

    def test_subprocess_run(self):
        fp = _fp("def f():\n    subprocess.run(['ls'])")
        assert "io: subprocess" in fp

    def test_requests_get(self):
        fp = _fp("def f():\n    requests.get(url)")
        assert "io: http" in fp

    def test_cursor_execute(self):
        fp = _fp("def f():\n    cursor.execute('SELECT 1')")
        assert "io: sql" in fp

    def test_no_false_positive_on_generic_names(self):
        """get(), run(), read() should NOT trigger I/O detection."""
        fp = _fp("def f():\n    data.get('key')\n    task.run()")
        assert "io:" not in fp


# ================================================================
# 7. _build_fingerprint — Async & Generators
# ================================================================

class TestFingerprintAsync:
    def test_async_function(self):
        fp = _fp("async def f():\n    pass")
        assert "async" in fp

    def test_async_with_await(self):
        fp = _fp("async def f():\n    await something()")
        assert "async with awaits" in fp

    def test_generator(self):
        fp = _fp("def f():\n    yield 1")
        assert "yields values (generator)" in fp


# ================================================================
# 8. _build_class_fingerprint
# ================================================================

class TestClassFingerprint:
    def test_method_counts(self):
        fp = _class_fp(textwrap.dedent("""\
            class Foo:
                def a(self): pass
                def b(self): pass
                def _c(self): pass
        """))
        assert "2 public methods, 1 private" in fp

    def test_init_state(self):
        fp = _class_fp(textwrap.dedent("""\
            class Foo:
                def __init__(self):
                    self.x = 1
                    self.y = 2
        """))
        assert "state: x, y" in fp

    def test_extends(self):
        fp = _class_fp("class Foo(Bar):\n    pass")
        assert "extends: Bar" in fp

    def test_dataclass(self):
        fp = _class_fp("@dataclass\nclass Foo:\n    x: int = 0")
        assert "dataclass" in fp

    def test_abstract(self):
        fp = _class_fp(textwrap.dedent("""\
            class Foo:
                @abstractmethod
                def do(self): pass
        """))
        assert "abstract" in fp

    def test_empty_class(self):
        fp = _class_fp("class Foo:\n    pass")
        assert "0 public methods, 0 private" in fp


# ================================================================
# 9. _collect_io_patterns
# ================================================================

class TestCollectIO:
    def test_bare_name(self):
        tree = ast.parse("open('f')")
        call = tree.body[0].value
        patterns = set()
        _collect_io_patterns(call, patterns)
        assert "file-io" in patterns

    def test_qualified_method(self):
        tree = ast.parse("cursor.fetchall()")
        call = tree.body[0].value
        patterns = set()
        _collect_io_patterns(call, patterns)
        assert "sql" in patterns

    def test_receiver_method(self):
        tree = ast.parse("requests.post(url)")
        call = tree.body[0].value
        patterns = set()
        _collect_io_patterns(call, patterns)
        assert "http" in patterns

    def test_no_match(self):
        tree = ast.parse("foo.bar()")
        call = tree.body[0].value
        patterns = set()
        _collect_io_patterns(call, patterns)
        assert len(patterns) == 0
