"""Tests for the Click CLI."""

from __future__ import annotations

import json

from click.testing import CliRunner

from codebrain.cli import cli


def _invoke(runner: CliRunner, args: list[str], repo: str) -> object:
    return runner.invoke(cli, ["--repo", repo] + args, catch_exceptions=False)


class TestVersion:
    def test_version_flag(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "CodeBrain" in result.output
        import re
        assert re.search(r"\d+\.\d+\.\d+", result.output), result.output


class TestInit:
    def test_init_creates_db(self, simple_project):
        runner = CliRunner()
        result = _invoke(runner, ["init"], str(simple_project))
        assert result.exit_code == 0
        assert "Indexing" in result.output
        assert "Done" in result.output

    def test_init_shows_stats(self, simple_project):
        runner = CliRunner()
        result = _invoke(runner, ["init"], str(simple_project))
        assert "Files parsed:" in result.output
        assert "Nodes:" in result.output
        assert "Edges:" in result.output


class TestSetup:
    def test_setup_cold(self, simple_project):
        runner = CliRunner()
        result = _invoke(runner, ["setup"], str(simple_project))
        assert result.exit_code == 0, result.output
        assert (simple_project / "CLAUDE.md").exists()
        config = json.loads((simple_project / ".mcp.json").read_text())
        assert "codebrain" in config["mcpServers"]
        assert config["mcpServers"]["codebrain"]["args"] == ["-m", "codebrain.mcp_server"]

    def test_setup_preserves_existing_mcp_servers(self, simple_project):
        existing = {"mcpServers": {"other": {"command": "node", "args": ["server.js"]}}}
        (simple_project / ".mcp.json").write_text(json.dumps(existing))
        runner = CliRunner()
        result = _invoke(runner, ["setup"], str(simple_project))
        assert result.exit_code == 0, result.output
        config = json.loads((simple_project / ".mcp.json").read_text())
        assert "other" in config["mcpServers"]
        assert "codebrain" in config["mcpServers"]

    def test_setup_idempotent_without_force(self, simple_project):
        runner = CliRunner()
        first = _invoke(runner, ["setup"], str(simple_project))
        assert first.exit_code == 0
        (simple_project / "CLAUDE.md").write_text("custom user content")
        second = _invoke(runner, ["setup"], str(simple_project))
        assert second.exit_code == 0
        assert (simple_project / "CLAUDE.md").read_text() == "custom user content"


class TestStatus:
    def test_status_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["status"], str(repo_root))
        assert result.exit_code == 0
        assert "files" in result.output

    def test_status_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["status", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "files" in data
        assert "nodes" in data

    def test_status_without_init(self, tmp_repo):
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(tmp_repo), "status"])
        assert result.exit_code != 0


class TestSearch:
    def test_search_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["search", "process"], str(repo_root))
        assert result.exit_code == 0
        assert "process" in result.output

    def test_search_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["search", "--json", "process"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)

    def test_search_no_results(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["search", "nonexistent_xyz_abc"], str(repo_root))
        assert result.exit_code == 0
        assert "No results" in result.output


class TestTrace:
    def test_trace_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["trace", "process"], str(repo_root))
        assert result.exit_code == 0
        assert "Call chain" in result.output

    def test_trace_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["trace", "--json", "process"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)

    def test_trace_not_found(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(repo_root), "trace", "nonexistent_xyz"])
        assert result.exit_code != 0


class TestImpact:
    def test_impact_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["impact", "helper"], str(repo_root))
        assert result.exit_code == 0
        assert "Impact" in result.output

    def test_impact_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["impact", "--json", "helper"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)


class TestDeps:
    def test_deps_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["deps", "process"], str(repo_root))
        assert result.exit_code == 0

    def test_deps_file(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["deps", "mypackage/core.py"], str(repo_root))
        assert result.exit_code == 0
        assert "Dependencies" in result.output


class TestDeadcode:
    def test_deadcode_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["deadcode"], str(repo_root))
        assert result.exit_code == 0

    def test_deadcode_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["deadcode", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)


class TestCycles:
    def test_cycles_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["cycles"], str(repo_root))
        assert result.exit_code == 0

    def test_cycles_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["cycles", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)


class TestValidate:
    def test_validate_file(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["validate", "mypackage/core.py"], str(repo_root))
        assert result.exit_code == 0
        assert "Validation" in result.output

    def test_validate_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["validate", "--json", "mypackage/core.py"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "is_valid" in data

    def test_validate_deleted_file(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["validate", "mypackage/nonexistent.py"], str(repo_root))
        assert result.exit_code == 0


class TestOverview:
    def test_overview_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["overview"], str(repo_root))
        assert result.exit_code == 0
        assert "Codebase" in result.output

    def test_overview_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["overview", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "stats" in data


class TestModule:
    def test_module_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["module", "mypackage/core.py"], str(repo_root))
        assert result.exit_code == 0
        assert "Module" in result.output

    def test_module_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["module", "--json", "mypackage/core.py"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "file_path" in data


class TestContext:
    def test_context_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["context", "process"], str(repo_root))
        assert result.exit_code == 0

    def test_context_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["context", "--json", "process"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)


class TestHotspots:
    def test_hotspots_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["hotspots"], str(repo_root))
        assert result.exit_code == 0

    def test_hotspots_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["hotspots", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)


class TestCoupling:
    def test_coupling_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["coupling"], str(repo_root))
        assert result.exit_code == 0

    def test_coupling_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["coupling", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "pairs" in data


class TestContracts:
    def test_contracts_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["contracts"], str(repo_root))
        assert result.exit_code == 0

    def test_contracts_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["contracts", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, list)


class TestLayers:
    def test_layers_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["layers"], str(repo_root))
        assert result.exit_code == 0

    def test_layers_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["layers", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "layers" in data


class TestInitJson:
    def test_init_json(self, simple_project):
        runner = CliRunner()
        result = _invoke(runner, ["init", "--json"], str(simple_project))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "files_parsed" in data
        assert "total_nodes" in data
        assert "total_edges" in data


class TestReindex:
    def test_reindex_with_yes(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["reindex", "--yes"], str(repo_root))
        assert result.exit_code == 0
        assert "Reindexing" in result.output
        assert "Done" in result.output

    def test_reindex_confirmation_aborted(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(repo_root), "reindex"], input="n\n")
        assert result.exit_code == 0
        assert "Aborted" in result.output

    def test_reindex_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["reindex", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "files_parsed" in data


class TestDoctor:
    def test_doctor_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["doctor"], str(repo_root))
        assert result.exit_code == 0
        assert "checks passed" in result.output

    def test_doctor_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["doctor", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "checks" in data

    def test_doctor_no_db(self, tmp_repo):
        runner = CliRunner()
        result = _invoke(runner, ["doctor"], str(tmp_repo))
        assert result.exit_code == 0
        assert "FAIL" in result.output


class TestResolve:
    def test_resolve_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["resolve", "mypackage.core"], str(repo_root))
        assert result.exit_code == 0

    def test_resolve_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["resolve", "--json", "mypackage.core"], str(repo_root))
        assert result.exit_code == 0


class TestHealth:
    def test_health_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["health"], str(repo_root))
        assert result.exit_code == 0
        assert "Health" in result.output
        assert "Score" in result.output

    def test_health_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["health", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "score" in data
        assert "grade" in data
        assert "details" in data
        assert 0 <= data["score"] <= 100


class TestExportJson:
    def test_export_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["export", "json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "nodes" in data
        assert "edges" in data


class TestDiff:
    def test_diff_text(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["diff"], str(repo_root))
        assert result.exit_code == 0

    def test_diff_json(self, indexed_project):
        repo_root, store = indexed_project
        store.close()
        runner = CliRunner()
        result = _invoke(runner, ["diff", "--json"], str(repo_root))
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "added" in data
