"""Tests for infrastructure parsing — Dockerfile, K8s YAML, Terraform."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.config_parser import ConfigParser


@pytest.fixture
def parser():
    return ConfigParser()


@pytest.fixture
def tmp_repo(tmp_path):
    return tmp_path


def _write(repo: Path, name: str, content: str) -> Path:
    p = repo / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return p


# =========================================================================
# Dockerfile Parsing
# =========================================================================

class TestDockerfileParsing:
    """Dockerfile parsing — stages, ports, env vars."""

    def test_from_stage_creates_function_node(self, parser, tmp_repo):
        p = _write(tmp_repo, "Dockerfile", """
FROM python:3.11-slim AS builder
RUN pip install poetry
FROM python:3.11-slim AS runtime
COPY --from=builder /app /app
        """)
        result = parser.parse(p, tmp_repo)
        stage_nodes = [n for n in result.nodes if n.type == "function" and "dockerfile" in n.decorators]
        assert len(stage_nodes) == 2
        names = {n.name for n in stage_nodes}
        assert "builder" in names
        assert "runtime" in names

    def test_expose_in_summary(self, parser, tmp_repo):
        p = _write(tmp_repo, "Dockerfile", """
FROM python:3.11
EXPOSE 8080
EXPOSE 443
CMD ["python", "app.py"]
        """)
        result = parser.parse(p, tmp_repo)
        file_node = [n for n in result.nodes if n.type == "file"][0]
        assert "8080" in (file_node.summary or "")

    def test_env_creates_variable_nodes(self, parser, tmp_repo):
        p = _write(tmp_repo, "Dockerfile", """
FROM python:3.11
ENV APP_PORT=8080
ENV DATABASE_URL=postgres://localhost/db
        """)
        result = parser.parse(p, tmp_repo)
        env_nodes = [n for n in result.nodes if "env_var" in n.decorators]
        names = {n.name for n in env_nodes}
        assert "APP_PORT" in names
        assert "DATABASE_URL" in names


# =========================================================================
# Kubernetes YAML Parsing
# =========================================================================

class TestK8sParsing:
    """Kubernetes YAML parsing — content-based detection."""

    def test_deployment_creates_k8s_resource_node(self, parser, tmp_repo):
        p = _write(tmp_repo, "deploy/app.yaml", """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  replicas: 3
  template:
    spec:
      containers:
        - name: app
          image: myregistry/app:latest
          ports:
            - containerPort: 8080
        """)
        result = parser.parse(p, tmp_repo)
        k8s_nodes = [n for n in result.nodes if "k8s_resource" in n.decorators]
        assert len(k8s_nodes) == 1
        assert k8s_nodes[0].name == "my-app"
        assert "Deployment" in (k8s_nodes[0].summary or "")

    def test_service_with_ports(self, parser, tmp_repo):
        p = _write(tmp_repo, "k8s/svc.yaml", """
apiVersion: v1
kind: Service
metadata:
  name: my-service
spec:
  ports:
    - port: 80
      targetPort: 8080
        """)
        result = parser.parse(p, tmp_repo)
        k8s_nodes = [n for n in result.nodes if "k8s_resource" in n.decorators]
        assert len(k8s_nodes) == 1
        assert "Service" in (k8s_nodes[0].summary or "")

    def test_multi_document_yaml(self, parser, tmp_repo):
        p = _write(tmp_repo, "manifests.yaml", """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web
spec:
  replicas: 2
---
apiVersion: v1
kind: Service
metadata:
  name: web-svc
spec:
  ports:
    - port: 80
        """)
        result = parser.parse(p, tmp_repo)
        k8s_nodes = [n for n in result.nodes if "k8s_resource" in n.decorators]
        assert len(k8s_nodes) == 2

    def test_non_k8s_yaml_returns_empty(self, parser, tmp_repo):
        p = _write(tmp_repo, "config.yaml", """
database:
  host: localhost
  port: 5432
logging:
  level: info
        """)
        result = parser.parse(p, tmp_repo)
        # No k8s resources, only empty or file node
        k8s_nodes = [n for n in result.nodes if "k8s_resource" in n.decorators]
        assert len(k8s_nodes) == 0

    def test_k8s_detected_by_content_not_path(self, parser, tmp_repo):
        """K8s manifests in arbitrary paths should be detected by content."""
        p = _write(tmp_repo, "infra/random/stuff.yml", """
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  KEY: value
        """)
        result = parser.parse(p, tmp_repo)
        k8s_nodes = [n for n in result.nodes if "k8s_resource" in n.decorators]
        assert len(k8s_nodes) == 1
        assert k8s_nodes[0].name == "app-config"


# =========================================================================
# Terraform Parsing
# =========================================================================

class TestTerraformParsing:
    """Terraform .tf file parsing."""

    def test_resource_block(self, parser, tmp_repo):
        p = _write(tmp_repo, "main.tf", """
resource "aws_instance" "web" {
  ami           = "ami-12345"
  instance_type = "t3.micro"
}

resource "aws_s3_bucket" "data" {
  bucket = "my-bucket"
}
        """)
        result = parser.parse(p, tmp_repo)
        res_nodes = [n for n in result.nodes if "terraform_resource" in n.decorators]
        assert len(res_nodes) == 2
        names = {n.name for n in res_nodes}
        assert "aws_instance.web" in names
        assert "aws_s3_bucket.data" in names

    def test_data_block(self, parser, tmp_repo):
        p = _write(tmp_repo, "data.tf", """
data "aws_ami" "latest" {
  most_recent = true
}
        """)
        result = parser.parse(p, tmp_repo)
        data_nodes = [n for n in result.nodes if "terraform_data" in n.decorators]
        assert len(data_nodes) == 1
        assert data_nodes[0].name == "aws_ami.latest"

    def test_variable_block(self, parser, tmp_repo):
        p = _write(tmp_repo, "variables.tf", """
variable "region" {
  default = "us-east-1"
}

variable "instance_type" {
  type = string
}
        """)
        result = parser.parse(p, tmp_repo)
        var_nodes = [n for n in result.nodes if "terraform_variable" in n.decorators]
        assert len(var_nodes) == 2
        names = {n.name for n in var_nodes}
        assert "region" in names
        assert "instance_type" in names


# =========================================================================
# ConfigParser Routing
# =========================================================================

class TestConfigParserRouting:
    """ConfigParser correctly routes files to the right handler."""

    def test_yaml_not_compose_not_k8s_returns_empty(self, parser, tmp_repo):
        """YAML that isn't docker-compose or K8s should return empty."""
        p = _write(tmp_repo, "settings.yml", """
app:
  name: test
  debug: true
        """)
        result = parser.parse(p, tmp_repo)
        assert len(result.nodes) == 0
        assert len(result.edges) == 0
