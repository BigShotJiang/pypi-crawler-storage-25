"""Tests for the guided architecture tour generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.tour import TourGenerator


@pytest.fixture
def tour_store(indexed_project: tuple[Path, GraphStore]):
    _, store = indexed_project
    return store


class TestTourGenerator:
    def test_generate_returns_dict(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate()
        assert isinstance(result, dict)
        assert "steps" in result
        assert "summary" in result
        assert "total_files" in result
        assert "total_symbols" in result

    def test_generate_has_steps(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate()
        assert len(result["steps"]) > 0

    def test_steps_have_required_fields(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate()
        for step in result["steps"]:
            assert "title" in step
            assert "layer" in step
            assert "files" in step
            assert "symbol_count" in step

    def test_max_steps_respected(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate(max_steps=1)
        assert len(result["steps"]) <= 1

    def test_generate_markdown(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        md = gen.generate_markdown(max_steps=10)
        assert isinstance(md, str)
        assert "# " in md
        assert "Architecture Tour" in md
        assert "Stop 1:" in md

    def test_generate_markdown_custom_name(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        md = gen.generate_markdown(project_name="TestProject")
        assert "TestProject" in md

    def test_empty_store(self, store: GraphStore):
        gen = TourGenerator(store)
        result = gen.generate()
        assert result["steps"] == []
        assert result["total_files"] == 0

    def test_total_symbols_positive(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate()
        assert result["total_symbols"] > 0

    def test_files_in_steps_have_paths(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate()
        for step in result["steps"]:
            for f in step["files"]:
                assert "path" in f
                assert "symbols" in f

    def test_key_symbols_included(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate(include_details=True)
        has_symbols = any(
            step.get("key_symbols") for step in result["steps"]
        )
        assert has_symbols

    def test_summary_generated(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate()
        assert len(result["summary"]) > 0

    def test_project_name_detected(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        result = gen.generate()
        assert result["project"]  # Should be non-empty

    def test_markdown_has_codebrain_attribution(self, tour_store: GraphStore):
        gen = TourGenerator(tour_store)
        md = gen.generate_markdown()
        assert "CodeBrain" in md
