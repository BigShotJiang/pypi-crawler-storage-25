"""Tests for SPEC-M25: Test Runner Integration."""

from __future__ import annotations

import json
import tempfile
import textwrap
import uuid
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from codebrain.graph.store import GraphStore
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.test_runner import TestRunner, TestResult, AtRiskSymbol, TestRunReport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_store():
    tmp = tempfile.mkdtemp()
    db = Path(tmp) / ".codebrain" / "graph.db"
    return GraphStore(db)


def _node(nid, name, ntype, file_path, is_exported=False, line=1):
    return ParsedNode(
        id=nid, name=name, qualified_name=name, type=ntype,
        file_path=file_path, line_start=line, line_end=line + 5,
        is_exported=is_exported,
    )


def _edge(source, target, etype="CALLS", file_path="src/mod.py", line=1):
    return ParsedEdge(source=source, target=target, type=etype,
                      file_path=file_path, line=line)


def _index(store, nodes, edges):
    files: dict[str, tuple[list, list]] = {}
    for n in nodes:
        files.setdefault(n.file_path, ([], []))[0].append(n)
    for e in edges:
        files.setdefault(e.file_path, ([], []))[1].append(e)
    for fp, (ns, es) in files.items():
        store.upsert_file(ParsedFile(path=fp, content_hash="h", nodes=ns, edges=es))


# ================================================================
# 1. Runner Detection
# ================================================================

class TestRunnerDetection:

    def test_detects_pytest_from_pyproject(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text("[tool.pytest.ini_options]\n")
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        name, cmd = tr.detect_runner()
        assert name == "pytest"
        store.close()

    def test_detects_pytest_from_conftest(self, tmp_path):
        (tmp_path / "conftest.py").write_text("")
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        name, _ = tr.detect_runner()
        assert name == "pytest"
        store.close()

    def test_detects_jest_from_package_json(self, tmp_path):
        (tmp_path / "package.json").write_text('{"devDependencies": {"jest": "^29"}}')
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        name, _ = tr.detect_runner()
        assert name == "jest"
        store.close()

    def test_returns_error_for_unknown(self, tmp_path):
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        with pytest.raises(RuntimeError, match="No test runner"):
            tr.detect_runner()
        store.close()


# ================================================================
# 2. JUnit XML Parsing
# ================================================================

class TestJunitXMLParsing:

    def _write_xml(self, tmp_path, content):
        xml_file = tmp_path / "results.xml"
        xml_file.write_text(content)
        return str(xml_file)

    def test_parses_passing_tests(self, tmp_path):
        xml = self._write_xml(tmp_path, textwrap.dedent("""\
            <?xml version="1.0" ?>
            <testsuite tests="2">
              <testcase classname="tests.test_foo" name="test_one" time="0.01"/>
              <testcase classname="tests.test_foo" name="test_two" time="0.02"/>
            </testsuite>
        """))
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        results = tr._parse_junit_xml(xml)
        assert len(results) == 2
        assert all(r.status == "pass" for r in results)
        store.close()

    def test_parses_failing_tests(self, tmp_path):
        xml = self._write_xml(tmp_path, textwrap.dedent("""\
            <?xml version="1.0" ?>
            <testsuite tests="1">
              <testcase classname="tests.test_foo" name="test_bad" time="0.01">
                <failure message="assert 1 == 2">Traceback...</failure>
              </testcase>
            </testsuite>
        """))
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        results = tr._parse_junit_xml(xml)
        assert len(results) == 1
        assert results[0].status == "fail"
        assert "1 == 2" in results[0].error_message
        store.close()

    def test_parses_skipped_tests(self, tmp_path):
        xml = self._write_xml(tmp_path, textwrap.dedent("""\
            <?xml version="1.0" ?>
            <testsuite tests="1">
              <testcase classname="tests.test_foo" name="test_skip" time="0.0">
                <skipped message="not ready"/>
              </testcase>
            </testsuite>
        """))
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        results = tr._parse_junit_xml(xml)
        assert results[0].status == "skip"
        store.close()

    def test_parses_error_tests(self, tmp_path):
        xml = self._write_xml(tmp_path, textwrap.dedent("""\
            <?xml version="1.0" ?>
            <testsuite tests="1">
              <testcase classname="tests.test_foo" name="test_err" time="0.0">
                <error message="ImportError">...</error>
              </testcase>
            </testsuite>
        """))
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        results = tr._parse_junit_xml(xml)
        assert results[0].status == "error"
        store.close()

    def test_handles_empty_suite(self, tmp_path):
        xml = self._write_xml(tmp_path, '<testsuite tests="0"/>')
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        results = tr._parse_junit_xml(xml)
        assert results == []
        store.close()


# ================================================================
# 3. Jest JSON Parsing
# ================================================================

class TestJestParsing:

    def test_parses_jest_output(self, tmp_path):
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        jest_json = json.dumps({
            "testResults": [{
                "testFilePath": str(tmp_path / "src" / "test.js"),
                "testResults": [
                    {"fullName": "adds numbers", "status": "passed", "duration": 10},
                    {"fullName": "fails", "status": "failed", "duration": 5,
                     "failureMessages": ["Expected 1 to be 2"]},
                ],
            }],
        })
        results = tr._parse_jest_json(jest_json)
        assert len(results) == 2
        assert results[0].status == "pass"
        assert results[1].status == "fail"
        assert "Expected 1 to be 2" in results[1].error_message
        store.close()

    def test_parses_jest_pending(self, tmp_path):
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        jest_json = json.dumps({
            "testResults": [{
                "testFilePath": "test.js",
                "testResults": [
                    {"fullName": "todo test", "status": "pending", "duration": 0},
                ],
            }],
        })
        results = tr._parse_jest_json(jest_json)
        assert results[0].status == "skip"
        store.close()


# ================================================================
# 4. Runner Error Handling
# ================================================================

class TestRunnerErrorHandling:

    def test_distinguishes_test_failure_from_crash(self, tmp_path):
        """Exit code 1 = test failure (parse results). Exit > 1 = crash."""
        (tmp_path / "conftest.py").write_text("")
        store = _make_store()
        tr = TestRunner(store, tmp_path)

        # Mock subprocess that returns exit code 5 (crash) with no XML
        with patch("codebrain.test_runner.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=5, stdout="", stderr="Collection error"
            )
            with pytest.raises(RuntimeError, match="crashed"):
                tr._run_pytest(["python", "-m", "pytest"], None, 30)
        store.close()

    def test_handles_timeout(self, tmp_path):
        import subprocess as sp
        (tmp_path / "conftest.py").write_text("")
        store = _make_store()
        tr = TestRunner(store, tmp_path)

        with patch("codebrain.test_runner.subprocess.run", side_effect=sp.TimeoutExpired("cmd", 30)):
            with pytest.raises(RuntimeError, match="timed out"):
                tr._run_pytest(["python", "-m", "pytest"], None, 30)
        store.close()

    def test_runner_not_found(self, tmp_path):
        store = _make_store()
        tr = TestRunner(store, tmp_path)
        with pytest.raises(RuntimeError, match="No test runner"):
            tr.detect_runner()
        store.close()


# ================================================================
# 5. Graph Mapping
# ================================================================

class TestGraphMapping:

    def test_maps_passing_test_to_verified(self):
        store = _make_store()
        nodes = [
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_a", "test_a", "function", "tests/t.py"),
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
        ]
        edges = [_edge("tests/t.py::test_a", "src/m.py::func", file_path="tests/t.py")]
        _index(store, nodes, edges)

        tr = TestRunner(store, Path("."))
        results = [TestResult("tests/t.py::test_a", "test_a", "tests/t.py", "pass")]
        at_risk = tr.map_to_graph(results)
        # All pass → no at-risk symbols
        assert len(at_risk) == 0
        store.close()

    def test_maps_failing_test_to_at_risk(self):
        store = _make_store()
        nodes = [
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_a", "test_a", "function", "tests/t.py"),
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py", is_exported=True),
        ]
        edges = [_edge("tests/t.py::test_a", "src/m.py::func", file_path="tests/t.py")]
        _index(store, nodes, edges)

        tr = TestRunner(store, Path("."))
        results = [TestResult("tests/t.py::test_a", "test_a", "tests/t.py", "fail", error_message="boom")]
        at_risk = tr.map_to_graph(results)
        assert len(at_risk) == 1
        assert at_risk[0].name == "func"
        assert at_risk[0].status == "at_risk"
        assert at_risk[0].failing_tests == 1
        store.close()

    def test_combines_multiple_tests(self):
        store = _make_store()
        nodes = [
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_a", "test_a", "function", "tests/t.py"),
            _node("tests/t.py::test_b", "test_b", "function", "tests/t.py"),
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
        ]
        edges = [
            _edge("tests/t.py::test_a", "src/m.py::func", file_path="tests/t.py"),
            _edge("tests/t.py::test_b", "src/m.py::func", file_path="tests/t.py"),
        ]
        _index(store, nodes, edges)

        tr = TestRunner(store, Path("."))
        results = [
            TestResult("tests/t.py::test_a", "test_a", "tests/t.py", "pass"),
            TestResult("tests/t.py::test_b", "test_b", "tests/t.py", "fail"),
        ]
        at_risk = tr.map_to_graph(results)
        assert len(at_risk) == 1
        assert at_risk[0].covering_tests == 2
        assert at_risk[0].failing_tests == 1
        store.close()

    def test_handles_unmatched_test(self):
        """Unmatched test results don't crash — just produce no at-risk symbols."""
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
        ]
        _index(store, nodes, [])

        tr = TestRunner(store, Path("."))
        results = [TestResult("nonexistent::test_x", "test_x", "nonexistent", "fail")]
        at_risk = tr.map_to_graph(results)
        assert len(at_risk) == 0
        store.close()

    def test_risk_score_boosted_by_failure(self):
        store = _make_store()
        nodes = [
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_a", "test_a", "function", "tests/t.py"),
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py", is_exported=True),
        ]
        edges = [_edge("tests/t.py::test_a", "src/m.py::func", file_path="tests/t.py")]
        _index(store, nodes, edges)

        tr = TestRunner(store, Path("."))
        results = [TestResult("tests/t.py::test_a", "test_a", "tests/t.py", "fail")]
        at_risk = tr.map_to_graph(results)
        assert at_risk[0].risk_score > 0
        store.close()


# ================================================================
# 6. Smart Test Selection
# ================================================================

class TestSmartSelection:

    def test_finds_affected_tests(self):
        store = _make_store()
        nodes = [
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_a", "test_a", "function", "tests/t.py"),
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
        ]
        edges = [_edge("tests/t.py::test_a", "src/m.py::func", file_path="tests/t.py")]
        _index(store, nodes, edges)

        tr = TestRunner(store, Path("."))
        affected = tr.affected_tests(["src/m.py"])
        assert "tests/t.py" in affected
        store.close()

    def test_finds_transitive_affected_tests(self):
        """test_a → helper → func. Changing func should find test_a."""
        store = _make_store()
        nodes = [
            _node("tests/t.py::t", "t", "file", "tests/t.py"),
            _node("tests/t.py::test_a", "test_a", "function", "tests/t.py"),
            _node("src/h.py::h", "h", "file", "src/h.py"),
            _node("src/h.py::helper", "helper", "function", "src/h.py"),
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
        ]
        edges = [
            _edge("tests/t.py::test_a", "src/h.py::helper", file_path="tests/t.py"),
            _edge("src/h.py::helper", "src/m.py::func", file_path="src/h.py"),
        ]
        _index(store, nodes, edges)

        tr = TestRunner(store, Path("."))
        affected = tr.affected_tests(["src/m.py"])
        assert "tests/t.py" in affected
        store.close()

    def test_returns_empty_for_uncovered_file(self):
        store = _make_store()
        nodes = [
            _node("src/m.py::m", "m", "file", "src/m.py"),
            _node("src/m.py::func", "func", "function", "src/m.py"),
        ]
        _index(store, nodes, [])

        tr = TestRunner(store, Path("."))
        affected = tr.affected_tests(["src/m.py"])
        assert affected == []
        store.close()

    def test_uses_git_diff_when_no_files(self):
        store = _make_store()
        tr = TestRunner(store, Path("."))
        with patch("codebrain.test_runner.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="")
            result = tr.affected_tests(None)
            assert result == []
        store.close()


# ================================================================
# 7. Persistence
# ================================================================

class TestPersistence:

    def test_stores_and_retrieves_test_run(self):
        store = _make_store()
        run_id = str(uuid.uuid4())
        store.store_test_run(
            run_id=run_id, timestamp=1000.0, commit_hash="abc123",
            total=3, passed=2, failed=1, skipped=0, errored=0,
            duration_ms=500.0, runner="pytest", command="pytest -v",
            scope="full",
            results=[
                {"test_id": "t::a", "test_name": "a", "file_path": "t.py",
                 "status": "pass", "duration_ms": 100, "error_message": ""},
                {"test_id": "t::b", "test_name": "b", "file_path": "t.py",
                 "status": "fail", "duration_ms": 200, "error_message": "boom"},
                {"test_id": "t::c", "test_name": "c", "file_path": "t.py",
                 "status": "pass", "duration_ms": 100, "error_message": ""},
            ],
        )
        last = store.get_last_test_run()
        assert last is not None
        assert last["id"] == run_id
        assert last["passed"] == 2
        assert last["failed"] == 1
        assert len(last["results"]) == 3
        store.close()

    def test_retrieves_history(self):
        store = _make_store()
        for i in range(3):
            store.store_test_run(
                run_id=str(uuid.uuid4()), timestamp=1000.0 + i,
                commit_hash="", total=1, passed=1, failed=0,
                skipped=0, errored=0, duration_ms=100,
                runner="pytest", command="", scope="full", results=[],
            )
        history = store.get_test_history(limit=2)
        assert len(history) == 2
        assert history[0]["timestamp"] > history[1]["timestamp"]
        store.close()

    def test_run_results_linked(self):
        store = _make_store()
        run_id = str(uuid.uuid4())
        store.store_test_run(
            run_id=run_id, timestamp=1000.0, commit_hash="",
            total=1, passed=1, failed=0, skipped=0, errored=0,
            duration_ms=50, runner="pytest", command="", scope="full",
            results=[{"test_id": "t::x", "test_name": "x", "file_path": "t.py",
                      "status": "pass", "duration_ms": 50}],
        )
        results = store.get_test_results_for_run(run_id)
        assert len(results) == 1
        assert results[0]["test_name"] == "x"
        store.close()


# ================================================================
# 8. CLI
# ================================================================

class TestCLI:

    def test_cli_test_status_no_runs(self):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        with runner.isolated_filesystem():
            Path(".codebrain").mkdir()
            store = GraphStore(Path(".codebrain/graph.db"))
            store.close()

            result = runner.invoke(cli, ["test", "--status"])
            assert result.exit_code == 0
            assert "No test runs" in result.output

    def test_cli_test_status_json(self):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        with runner.isolated_filesystem():
            Path(".codebrain").mkdir()
            store = GraphStore(Path(".codebrain/graph.db"))
            store.close()

            result = runner.invoke(cli, ["test", "--status", "--json"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data is None  # No runs yet

    def test_cli_test_history_empty(self):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        with runner.isolated_filesystem():
            Path(".codebrain").mkdir()
            store = GraphStore(Path(".codebrain/graph.db"))
            store.close()

            result = runner.invoke(cli, ["test", "--history"])
            assert result.exit_code == 0
            assert "No test runs" in result.output

    def test_cli_test_for_symbol_not_found(self):
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        with runner.isolated_filesystem():
            Path(".codebrain").mkdir()
            store = GraphStore(Path(".codebrain/graph.db"))
            store.close()

            result = runner.invoke(cli, ["test", "--for", "nonexistent"])
            assert result.exit_code == 0
            assert "not found" in result.output.lower() or "Symbol not found" in result.output
