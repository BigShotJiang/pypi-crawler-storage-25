"""Output quality validation — cross-checks between CodeBrain tools.

No human review needed. Tests verify that tools produce internally
consistent, structurally sound output on real codebases.

Principles:
- If tool A says X, tool B should agree
- Outputs should be proportional to input size
- Known ground truth assertions (PetClinic IS MVC, Saleor IS Django)
- Suspicious outputs flagged (0 issues on 4000 files = broken)
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from codebrain.architecture import ArchitectureDetector
from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.analyzer import StructuralAnalyzer

_HERE = Path(__file__).resolve().parent
_LOCAL_REPOS = _HERE / "fixtures" / "repos"
_TEMP = Path(os.environ.get("TEMP", os.environ.get("TMP", "/tmp")))
_TEMP_REPOS = _TEMP / "codebrain-test-repos"


def _pick_repo_root(name: str) -> Path:
    """Prefer tests/fixtures/repos/<name>; fall back to legacy $TEMP/codebrain-test-repos/<name>."""
    local = _LOCAL_REPOS / name
    if local.exists():
        return local
    return _TEMP_REPOS / name


REPOS_ROOT = _LOCAL_REPOS if _LOCAL_REPOS.exists() else _TEMP_REPOS
PETCLINIC = _pick_repo_root("spring-petclinic")
SALEOR = _pick_repo_root("saleor")


def _has_sources(root: Path, *patterns: str) -> bool:
    """True only if the directory contains at least one real source file.

    Guards against empty scaffold checkouts (e.g. %TEMP% cleanup that
    leaves directories behind but removes their contents).
    """
    if not root.exists():
        return False
    for pat in patterns:
        if next(root.rglob(pat), None) is not None:
            return True
    return False


petclinic_skip = pytest.mark.skipif(
    not _has_sources(PETCLINIC, "*.java"),
    reason="spring-petclinic not cloned or empty",
)
saleor_skip = pytest.mark.skipif(
    not _has_sources(SALEOR, "*.py"),
    reason="saleor not cloned or empty",
)


def _index(repo: Path, tmp: Path) -> GraphStore:
    db = tmp / "test.db"
    full_index(repo, db)
    return GraphStore(db)


# ---------------------------------------------------------------------------
# Spring PetClinic — known ground truth
# ---------------------------------------------------------------------------

@petclinic_skip
class TestPetClinicGroundTruth:
    """PetClinic is a well-known Spring Boot MVC app. We know the answers."""

    @pytest.fixture(scope="class")
    def store(self, petclinic_indexed_db):
        s = GraphStore(petclinic_indexed_db)
        yield s
        s.close()

    @pytest.fixture(scope="class")
    def arch(self, store):
        return ArchitectureDetector(store).detect()

    @pytest.fixture(scope="class")
    def comp(self, store):
        return ComprehensionEngine(store)

    @pytest.fixture(scope="class")
    def nodes(self, store):
        return store.get_all_nodes()

    # -- Architecture ground truth --

    def test_pattern_is_mvc(self, arch):
        """PetClinic is the canonical MVC example. Must detect MVC."""
        assert arch.pattern == "mvc", \
            f"Got '{arch.pattern}'. Evidence: {arch.pattern_evidence}"

    def test_spring_boot_is_primary_framework(self, arch):
        """Spring Boot must be the detected framework."""
        assert "spring_boot" in arch.frameworks

    def test_db_technology_is_jpa_or_sql(self, arch):
        """PetClinic uses JPA with H2/MySQL. Should detect JPA or raw SQL."""
        assert arch.db_technology in ("hibernate_jpa", "raw_sql", ""), \
            f"Got '{arch.db_technology}' — PetClinic doesn't use {arch.db_technology}"

    def test_no_false_frameworks(self, arch):
        """PetClinic doesn't use Django, Flask, React, Vue, Angular."""
        false_positives = {"django", "flask", "react", "vue", "angular", "express"}
        detected_false = false_positives & set(arch.frameworks)
        assert len(detected_false) == 0, \
            f"False framework detection: {detected_false}"

    # -- Module roles ground truth --

    def test_controller_files_have_api_role(self, arch):
        """Files named *Controller.java should be api_layer."""
        controller_roles = {
            path: role for path, role in arch.module_roles.items()
            if "Controller" in path
        }
        if controller_roles:
            api_roles = [r for r in controller_roles.values()
                         if r == "api_layer"]
            assert len(api_roles) > 0, \
                f"Controller files got roles: {controller_roles}"

    def test_repository_files_have_data_role(self, arch):
        """Files named *Repository.java should be data_access."""
        repo_roles = {
            path: role for path, role in arch.module_roles.items()
            if "Repository" in path and "test" not in path.lower()
        }
        if repo_roles:
            data_roles = [r for r in repo_roles.values()
                          if r in ("data_access", "data_model")]
            assert len(data_roles) > 0, \
                f"Repository files got roles: {repo_roles}"

    # -- KT document cross-check with comprehension --

    def test_kt_mentions_top_hotspot(self, store, comp):
        """KT document should mention whatever comprehension says is the top hotspot."""
        from codebrain.kt import KTGenerator
        hotspots = comp.risk_hotspots(top_n=3)
        if not hotspots:
            pytest.skip("No hotspots found")
        top_name = hotspots[0].get("name", hotspots[0].get("symbol", ""))

        gen = KTGenerator(store)
        kt = gen.generate(project_name="PetClinic", max_hotspots=5)
        assert top_name in kt, \
            f"Top hotspot '{top_name}' not in KT document"

    # -- Migration plan proportionality --

    def test_migration_plan_proportional(self, store, nodes):
        """Plan phases should be proportional to codebase size."""
        from codebrain.migration import MigrationPlanGenerator
        gen = MigrationPlanGenerator(store)
        plan = gen.generate_plan()
        phases = plan.get("phases", [])
        unique_files = len({n.get("file_path", "") for n in nodes})
        # Phases should not exceed number of files
        assert len(phases) <= unique_files, \
            f"{len(phases)} phases for {unique_files} files is suspicious"
        # Should have at least 1 phase
        assert len(phases) >= 1

    # -- Contract extraction consistency --

    def test_contracts_match_graph(self, store):
        """Extracted contracts should reference symbols that exist in the graph."""
        from codebrain.migration import ContractExtractor
        ext = ContractExtractor(store)
        result = ext.extract()
        modules = result.get("modules", {})
        all_nodes = store.get_all_nodes()
        all_names = {n.get("name", "") for n in all_nodes}

        # At least some contract function/class names should be in the graph
        contract_names = set()
        for file_data in modules.values():
            if isinstance(file_data, dict):
                for fn in file_data.get("functions", []):
                    if isinstance(fn, dict):
                        contract_names.add(fn.get("name", ""))
                for cls in file_data.get("classes", []):
                    if isinstance(cls, dict):
                        contract_names.add(cls.get("name", ""))

        if contract_names:
            overlap = contract_names & all_names
            assert len(overlap) > 0, \
                f"No contract names found in graph. Contracts: {list(contract_names)[:5]}"

    # -- Modernize spec cross-check --

    def test_modernize_spec_includes_contracts(self, store):
        """Modernize spec modules should contain contract info."""
        from codebrain.modernize import SpecGenerator
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        module_specs = spec.get("module_specs", {})
        if not module_specs:
            pytest.skip("No module specs")
        # At least some modules should have contracts
        has_contracts = [
            k for k, v in module_specs.items()
            if isinstance(v, dict) and v.get("contracts")
        ]
        assert len(has_contracts) > 0, "No modules have contracts in spec"

    def test_modernize_spec_modules_match_graph(self, store):
        """Spec module file paths should match actual indexed files."""
        from codebrain.modernize import SpecGenerator
        gen = SpecGenerator(store)
        spec = gen.generate_full_spec()
        module_specs = spec.get("module_specs", {})

        all_nodes = store.get_all_nodes()
        indexed_files = {n.get("file_path", "") for n in all_nodes}

        spec_files = set(module_specs.keys())
        # All spec files should be in the index
        missing = spec_files - indexed_files
        # Allow some tolerance (path normalization)
        assert len(missing) <= len(spec_files) * 0.1, \
            f"{len(missing)}/{len(spec_files)} spec files not in index: {list(missing)[:5]}"


# ---------------------------------------------------------------------------
# Saleor — scale + Django ground truth
# ---------------------------------------------------------------------------

@saleor_skip
class TestSaleorGroundTruth:
    """Saleor is a large Django e-commerce platform. Known facts to verify."""

    @pytest.fixture(scope="class")
    def store(self, saleor_indexed_db):
        s = GraphStore(saleor_indexed_db)
        yield s
        s.close()

    @pytest.fixture(scope="class")
    def arch(self, store):
        return ArchitectureDetector(store).detect()

    @pytest.fixture(scope="class")
    def comp(self, store):
        return ComprehensionEngine(store)

    # -- Django ground truth --

    def test_django_is_primary_framework(self, arch):
        assert "django" in arch.frameworks

    def test_db_is_django_orm(self, arch):
        assert arch.db_technology == "django_orm"

    def test_no_spring_boot(self, arch):
        """Saleor is Python — should not detect Java frameworks."""
        assert "spring_boot" not in arch.frameworks

    # -- Scale proportionality --

    def test_health_score_reasonable(self, comp):
        """4000+ file project health score should be between 20-100."""
        health = comp.health_score()
        score = health.get("score", health.get("overall", -1))
        assert 20 <= score <= 100, f"Score {score} is suspicious for 4000+ files"

    def test_hotspots_are_real(self, store, comp):
        """Top hotspots should have significant dependents."""
        hotspots = comp.risk_hotspots(top_n=5)
        if not hotspots:
            pytest.skip("No hotspots")
        top = hotspots[0]
        dep_count = top.get("direct_dependents", 0)
        assert dep_count > 1, \
            f"Top hotspot '{top.get('name')}' has only {dep_count} dependents in 4000+ file project"

    def test_reviewer_finds_issues(self, store):
        """Code reviewer on a 4000-file project should find something."""
        from codebrain.actions.reviewer import CodeReviewer
        reviewer = CodeReviewer(store, SALEOR)
        nodes = store.get_all_nodes()
        files = list({n["file_path"] for n in nodes
                      if n.get("file_path", "").endswith(".py")
                      and n.get("type") in ("function", "method")})[:10]
        if not files:
            pytest.skip("No Python files with functions")
        review = reviewer.review_files(files)
        findings = getattr(review, "findings", getattr(review, "issues", []))
        assert len(findings) > 0, \
            f"Code reviewer found 0 issues in 10 files from a 4000-file project — suspicious"

    def test_refactorer_finds_suggestions(self, store):
        """Refactorer should find dead code or other suggestions in 4000+ files."""
        from codebrain.actions.refactor import Refactorer
        refactorer = Refactorer(store, SALEOR)
        suggestions = refactorer.suggest(category="all")
        assert len(suggestions) > 0, \
            "0 refactoring suggestions in 4000+ file project — suspicious"

    def test_kt_document_substantial(self, store):
        """KT doc for 4000+ files should be substantial, not a stub."""
        from codebrain.kt import KTGenerator
        gen = KTGenerator(store)
        kt = gen.generate(project_name="Saleor", max_modules=10)
        # Should be substantial
        assert len(kt) > 1000, f"KT doc is only {len(kt)} chars for 4000+ file project"
        # Should mention Django since it's the framework
        assert "django" in kt.lower() or "Django" in kt

    def test_migration_plan_not_trivial(self, store):
        """4000+ file project should have multiple migration phases."""
        from codebrain.migration import MigrationPlanGenerator
        gen = MigrationPlanGenerator(store)
        plan = gen.generate_plan()
        phases = plan.get("phases", [])
        assert len(phases) >= 3, \
            f"Only {len(phases)} phases for 4000+ file project — too few"

    # -- Cross-tool consistency --

    def test_arch_frameworks_in_kt(self, store, arch):
        """Primary framework detected by architecture should appear in KT document."""
        from codebrain.kt import KTGenerator
        gen = KTGenerator(store)
        kt = gen.generate(project_name="Saleor").lower()
        # At least the primary framework (django) should be in the KT doc
        primary = arch.frameworks[0] if arch.frameworks else ""
        assert primary.replace("_", " ") in kt or primary in kt, \
            f"Primary framework '{primary}' not in KT document"

    def test_orm_models_in_contracts(self, store):
        """Django ORM models should appear in contract extraction."""
        from codebrain.migration import ContractExtractor
        ext = ContractExtractor(store)
        all_nodes = store.get_all_nodes()

        # Find Django ORM model names
        orm_names = set()
        for n in all_nodes:
            decs = n.get("decorators", [])
            if isinstance(decs, str):
                try:
                    decs = json.loads(decs)
                except (ValueError, TypeError):
                    decs = []
            if "orm_model" in decs and "django" in decs:
                orm_names.add(n.get("name", ""))

        if not orm_names:
            pytest.skip("No ORM models found")

        # Extract ALL contracts (no file filter — avoids path mismatch)
        result = ext.extract()
        modules = result.get("modules", {})

        # Collect all class names from contracts
        contract_classes = set()
        for file_data in modules.values():
            if isinstance(file_data, dict):
                for cls in file_data.get("classes", []):
                    if isinstance(cls, dict):
                        contract_classes.add(cls.get("name", ""))

        overlap = orm_names & contract_classes
        assert len(overlap) > 0, \
            f"ORM models {list(orm_names)[:5]} not in contracts {list(contract_classes)[:5]}"
