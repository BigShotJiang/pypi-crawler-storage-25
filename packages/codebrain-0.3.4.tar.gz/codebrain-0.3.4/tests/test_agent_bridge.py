"""Tests for the agent bridge."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.agent_bridge import generate_claude_md, generate_context_json, write_agent_files
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.indexer import full_index


@pytest.fixture
def bridge_project(simple_project: Path) -> Path:
    full_index(simple_project)
    return simple_project


class TestGenerateClaudeMd:
    def test_generates_content(self, bridge_project: Path) -> None:
        content = generate_claude_md(bridge_project)
        assert "# Codebase Structure" in content
        assert "mypackage" in content

    def test_includes_hotspots(self, bridge_project: Path) -> None:
        content = generate_claude_md(bridge_project)
        assert "High-Impact" in content or "CodeBrain Tools" in content

    def test_includes_instructions(self, bridge_project: Path) -> None:
        content = generate_claude_md(bridge_project)
        assert "brain search" in content
        assert "brain validate" in content


class TestGenerateContextJson:
    def test_generates_dict(self, bridge_project: Path) -> None:
        ctx = generate_context_json(bridge_project)
        assert "overview" in ctx
        assert "risk_hotspots" in ctx
        assert "architectural_layers" in ctx
        assert "instructions" in ctx


class TestWriteAgentFiles:
    def test_writes_files(self, bridge_project: Path) -> None:
        written = write_agent_files(bridge_project)
        assert len(written) == 3

        claude_md = bridge_project / "CLAUDE.md"
        assert claude_md.exists()

        ctx_json = bridge_project / CODEBRAIN_DIR / "context.json"
        assert ctx_json.exists()

        mcp_json = bridge_project / CODEBRAIN_DIR / "mcp_config.json"
        assert mcp_json.exists()
