"""Tests for the onboarding guide generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.onboard import OnboardingGenerator


@pytest.fixture
def onboard_store(indexed_project: tuple[Path, GraphStore]):
    _, store = indexed_project
    return store


class TestOnboardingGenerator:
    def test_generate_returns_markdown(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate()
        assert isinstance(result, str)
        assert "# Welcome to" in result

    def test_contains_all_sections(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate()
        assert "## Project Overview" in result
        assert "## Quick Stats" in result
        assert "## Architecture" in result
        assert "## Guided Tour" in result
        assert "## File Map" in result
        assert "## Risk Hotspots" in result
        assert "## Health & Quality" in result
        assert "## Next Steps" in result

    def test_custom_project_name(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate(project_name="SuperApp")
        assert "SuperApp" in result

    def test_brief_detail_level(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate(detail_level="brief")
        assert "## Module Details" not in result

    def test_deep_detail_level(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate(detail_level="deep")
        assert "## Module Details" in result

    def test_stats_table(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate()
        assert "| Files |" in result
        assert "| Symbols" in result

    def test_tour_section_has_stops(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate()
        assert "Stop 1:" in result

    def test_next_steps_mentions_commands(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate()
        assert "brain impact" in result
        assert "brain diff-impact" in result

    def test_empty_store(self, store: GraphStore):
        gen = OnboardingGenerator(store)
        result = gen.generate()
        assert isinstance(result, str)
        assert "# Welcome to" in result

    def test_health_section(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate()
        assert "Dead Code" in result
        assert "Import Cycles" in result

    def test_codebrain_attribution(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate()
        assert "CodeBrain" in result

    def test_file_map_present(self, onboard_store: GraphStore):
        gen = OnboardingGenerator(onboard_store)
        result = gen.generate()
        assert "| File |" in result
