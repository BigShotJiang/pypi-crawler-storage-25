"""Tests for the Kotlin tree-sitter parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.kotlin_parser import KotlinParser, _KOTLIN_AVAILABLE

pytestmark = pytest.mark.skipif(not _KOTLIN_AVAILABLE, reason="tree-sitter-languages not installed")


@pytest.fixture
def parser():
    return KotlinParser()


@pytest.fixture
def kotlin_project(tmp_path: Path) -> Path:
    """Create a small Kotlin project for testing."""
    src = tmp_path / "src" / "main" / "kotlin" / "com" / "example"
    src.mkdir(parents=True)

    (src / "UserService.kt").write_text("""\
package com.example

import java.util.UUID
import com.example.models.User
import com.example.repo.UserRepository

/**
 * Service for managing users.
 * Handles CRUD operations.
 */
class UserService(private val repo: UserRepository) : BaseService(), Loggable {

    fun findAll(): List<User> {
        return repo.getAll()
    }

    fun findById(id: Int): User? {
        val user = repo.get(id)
        validate(user)
        return user
    }

    private fun validate(user: User?) {
        requireNotNull(user) { "User not found" }
    }

    companion object {
        const val MAX_USERS = 100

        fun create(repo: UserRepository): UserService {
            return UserService(repo)
        }
    }
}
""")

    (src / "Models.kt").write_text("""\
package com.example

/**
 * A user in the system.
 */
data class User(
    val id: Int,
    val name: String,
    var email: String,
    val age: Int = 0
)

sealed class Result {
    data class Success(val data: String) : Result()
    data class Error(val message: String) : Result()
}

enum class Role(val level: Int) {
    ADMIN(3),
    EDITOR(2),
    VIEWER(1);

    fun canEdit(): Boolean = level >= 2
}

@Deprecated("Use NewConfig instead")
object AppConfig {
    val version: String = "1.0"
    fun getEnv(): String = "production"
}

interface Repository<T> {
    fun findById(id: Int): T?
    fun save(entity: T): T
    fun deleteById(id: Int)
}

typealias UserList = List<User>
""")

    (src / "Extensions.kt").write_text("""\
package com.example

fun String.toSlug(): String {
    return this.lowercase().replace(" ", "-")
}

suspend fun fetchData(url: String): String {
    return NetworkClient.get(url)
}

internal fun helperFunction(): Boolean = true

val globalConfig: Map<String, String> = mapOf("key" to "value")
""")

    (src / "Main.kt").write_text("""\
package com.example

import com.example.UserService

fun main() {
    val service = UserService(InMemoryRepo())
    service.findAll()
    service.findById(1)
    val slug = "Hello World".toSlug()
}
""")

    return tmp_path


class TestBasicParsing:
    """Test basic Kotlin symbol extraction."""

    def test_parses_kotlin_file(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        assert result.path.endswith("UserService.kt")
        assert result.line_count > 0

    def test_finds_class(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        classes = [n for n in result.nodes if n.type == "class" and n.name == "UserService"]
        assert len(classes) == 1
        assert classes[0].is_exported is True

    def test_finds_data_class(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        user = [n for n in result.nodes if n.name == "User" and n.type == "class"]
        assert len(user) == 1
        assert "data_class" in user[0].decorators

    def test_finds_object(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        obj = [n for n in result.nodes if n.name == "AppConfig" and n.type == "class"]
        assert len(obj) == 1
        assert "object" in obj[0].decorators

    def test_finds_interface(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        ifaces = [n for n in result.nodes if "interface" in n.decorators]
        assert any(n.name == "Repository" for n in ifaces)

    def test_finds_enum_class(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        enums = [n for n in result.nodes if n.name == "Role" and n.type == "class"]
        assert len(enums) == 1
        assert "enum" in enums[0].decorators

    def test_finds_functions(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        methods = [n for n in result.nodes if n.type == "method"]
        method_names = {m.name for m in methods}
        assert "findAll" in method_names
        assert "findById" in method_names
        assert "validate" in method_names

    def test_finds_properties(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Extensions.kt"
        result = parser.parse(path, kotlin_project)
        props = [n for n in result.nodes if n.type == "variable" and n.name == "globalConfig"]
        assert len(props) == 1

    def test_finds_sealed_class(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        sealed = [n for n in result.nodes if n.name == "Result" and n.type == "class"]
        assert len(sealed) == 1
        assert "sealed" in sealed[0].decorators


class TestRelationships:
    """Test edge extraction (CALLS, IMPORTS, EXTENDS, IMPLEMENTS, CONTAINS)."""

    def test_imports(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        targets = {e.target for e in imports}
        assert "java.util.UUID" in targets
        assert "com.example.models.User" in targets

    def test_function_calls(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert "validate" in targets

    def test_method_calls(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Main.kt"
        result = parser.parse(path, kotlin_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert any("findAll" in t for t in targets)
        assert any("findById" in t for t in targets)

    def test_extends(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        extends = [e for e in result.edges if e.type == "EXTENDS"]
        targets = {e.target for e in extends}
        assert "BaseService" in targets

    def test_implements(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        impls = [e for e in result.edges if e.type == "IMPLEMENTS"]
        targets = {e.target for e in impls}
        assert "Loggable" in targets

    def test_contains_edges(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        contains = [e for e in result.edges if e.type == "CONTAINS"]
        assert len(contains) > 5  # file->class, class->methods, companion->members

    def test_companion_object(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        companion = [n for n in result.nodes if "companion_object" in n.decorators]
        assert len(companion) >= 1
        # Companion should contain MAX_USERS and create method
        comp_id = companion[0].id
        contains = [e for e in result.edges if e.type == "CONTAINS" and e.source == comp_id]
        child_ids = {e.target for e in contains}
        child_names = {n.name for n in result.nodes if n.id in child_ids}
        assert "MAX_USERS" in child_names or "create" in child_names


class TestMetadata:
    """Test signatures, KDoc, modifiers, annotations."""

    def test_default_public(self, parser: KotlinParser, kotlin_project: Path):
        """In Kotlin, symbols without visibility modifier are public."""
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        find_all = [n for n in result.nodes if n.name == "findAll"]
        assert len(find_all) == 1
        assert find_all[0].is_exported is True
        # private function should NOT be exported
        validate = [n for n in result.nodes if n.name == "validate"]
        assert len(validate) == 1
        assert validate[0].is_exported is False

    def test_kdoc_extraction(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        cls = [n for n in result.nodes if n.name == "UserService" and n.type == "class"]
        assert len(cls) == 1
        assert "managing users" in cls[0].docstring.lower()

    def test_annotations(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        config = [n for n in result.nodes if n.name == "AppConfig" and n.type == "class"]
        assert len(config) == 1
        ann_names = [a.split("(")[0] for a in config[0].decorators if a not in ("object",)]
        assert "Deprecated" in ann_names

    def test_suspend_function(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Extensions.kt"
        result = parser.parse(path, kotlin_project)
        fetch = [n for n in result.nodes if n.name == "fetchData"]
        assert len(fetch) == 1
        assert "suspend" in fetch[0].decorators
        assert "suspend" in fetch[0].signature

    def test_extension_function(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Extensions.kt"
        result = parser.parse(path, kotlin_project)
        slug = [n for n in result.nodes if n.name == "toSlug"]
        assert len(slug) == 1
        assert "extension" in slug[0].decorators
        assert "String" in slug[0].signature

    def test_internal_not_exported(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Extensions.kt"
        result = parser.parse(path, kotlin_project)
        helper = [n for n in result.nodes if n.name == "helperFunction"]
        assert len(helper) == 1
        assert helper[0].is_exported is False

    def test_package_in_file_docstring(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        file_node = [n for n in result.nodes if n.type == "file"]
        assert len(file_node) == 1
        assert "com.example" in file_node[0].docstring

    def test_extensions_property(self, parser: KotlinParser):
        assert ".kt" in parser.extensions()
        assert ".kts" in parser.extensions()

    def test_enum_entries(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        entries = [n for n in result.nodes if n.type == "variable"
                   and n.qualified_name.startswith("Role.")]
        names = {e.name for e in entries}
        assert "ADMIN" in names
        assert "EDITOR" in names
        assert "VIEWER" in names

    def test_qualified_names(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/UserService.kt"
        result = parser.parse(path, kotlin_project)
        find_all = [n for n in result.nodes if n.name == "findAll"]
        assert find_all[0].qualified_name == "UserService.findAll"

    def test_typealias(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        aliases = [n for n in result.nodes if "typealias" in n.decorators]
        assert any(n.name == "UserList" for n in aliases)

    def test_data_class_properties(self, parser: KotlinParser, kotlin_project: Path):
        """Data class primary constructor val/var params should be properties."""
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        user_props = [n for n in result.nodes if n.type == "variable"
                      and n.qualified_name.startswith("User.")]
        prop_names = {p.name for p in user_props}
        assert "id" in prop_names
        assert "name" in prop_names
        assert "email" in prop_names

    def test_sealed_subclasses_extend_parent(self, parser: KotlinParser, kotlin_project: Path):
        path = kotlin_project / "src/main/kotlin/com/example/Models.kt"
        result = parser.parse(path, kotlin_project)
        extends = [e for e in result.edges if e.type == "EXTENDS"]
        targets_by_source = {e.source: e.target for e in extends}
        # Success and Error should extend Result
        success_id = None
        error_id = None
        for n in result.nodes:
            if n.name == "Success" and n.type == "class":
                success_id = n.id
            if n.name == "Error" and n.type == "class":
                error_id = n.id
        if success_id:
            assert targets_by_source.get(success_id) == "Result"
        if error_id:
            assert targets_by_source.get(error_id) == "Result"


class TestIndexIntegration:
    """Test that Kotlin files work with the full indexing pipeline."""

    def test_index_kotlin_project(self, kotlin_project: Path):
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index

        result = full_index(kotlin_project)
        assert result["errors"] == []
        assert result["files_parsed"] == 4

        db = kotlin_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            stats = store.get_stats()
            assert stats["nodes"] > 10
            assert stats["edges"] > 10
            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            results = engine.search_nodes("UserService")
            assert any(r["name"] == "UserService" for r in results)

    def test_impact_analysis_kotlin(self, kotlin_project: Path):
        """Impact analysis should work on Kotlin symbols."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.graph.query import QueryEngine
        from codebrain.indexer import full_index

        full_index(kotlin_project)
        db = kotlin_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)
            results = engine.search_nodes("User")
            assert len(results) > 0

    def test_kt_document_kotlin(self, kotlin_project: Path):
        """KT document generation should work on Kotlin codebases."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index
        from codebrain.kt import KTGenerator

        full_index(kotlin_project)
        db = kotlin_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            gen = KTGenerator(store)
            doc = gen.generate(project_name="KotlinTestProject")
            assert "# KotlinTestProject" in doc
            assert "## Architecture Overview" in doc
            assert "```mermaid" in doc
