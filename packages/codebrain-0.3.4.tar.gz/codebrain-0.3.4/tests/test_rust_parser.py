"""Tests for the Rust tree-sitter parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.rust_parser import RustParser, _RUST_AVAILABLE

pytestmark = pytest.mark.skipif(not _RUST_AVAILABLE, reason="tree-sitter-languages not installed")


@pytest.fixture
def parser():
    return RustParser()


@pytest.fixture
def rust_project(tmp_path: Path) -> Path:
    """Create a small Rust project for testing."""
    src = tmp_path / "src"
    src.mkdir(parents=True)

    (src / "lib.rs").write_text("""\
use std::collections::HashMap;
use std::io::{self, Read};

mod models;
mod utils;

/// The main application entry point.
pub fn run(config: &Config) -> Result<(), AppError> {
    let service = UserService::new(config);
    service.process_all();
    Ok(())
}

fn helper() {
    let x = compute_value(42);
    custom_macro!(x);
}

pub const MAX_RETRIES: u32 = 3;

pub static APP_NAME: &str = "myapp";

pub type UserId = u64;
""")

    (src / "models.rs").write_text("""\
use serde::{Serialize, Deserialize};

/// A user in the system.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct User {
    pub id: u64,
    pub name: String,
    email: String,
}

/// Possible user roles.
#[derive(Debug, PartialEq)]
pub enum Role {
    Admin,
    Editor,
    Viewer(String),
}

/// Trait for objects that can be validated.
pub trait Validatable {
    /// Check if the object is valid.
    fn validate(&self) -> bool;

    fn error_message(&self) -> String;
}

impl Validatable for User {
    fn validate(&self) -> bool {
        !self.name.is_empty()
    }

    fn error_message(&self) -> String {
        format!("Invalid user: {}", self.name)
    }
}

impl User {
    pub fn new(id: u64, name: String, email: String) -> Self {
        User { id, name, email }
    }

    pub fn display_name(&self) -> &str {
        &self.name
    }

    fn internal_check(&self) -> bool {
        self.validate()
    }
}

/// Configuration settings.
pub struct Config {
    pub database_url: String,
    pub port: u16,
}
""")

    (src / "utils.rs").write_text("""\
use crate::models::User;

/// Compute a hash for the given user.
pub fn compute_hash(user: &User) -> u64 {
    let name = user.display_name();
    hash_string(name)
}

fn hash_string(s: &str) -> u64 {
    s.len() as u64
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_hash() {
        let user = User::new(1, "test".to_string(), "t@t.com".to_string());
        assert_eq!(compute_hash(&user), 4);
    }
}
""")

    return tmp_path


# ─── Basic Parsing ───────────────────────────────────────────────────────


class TestBasicParsing:
    """Test basic Rust symbol extraction."""

    def test_parses_rust_file(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        assert result.path.endswith("lib.rs")
        assert result.line_count > 0

    def test_finds_function(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        funcs = [n for n in result.nodes if n.type == "function" and n.name == "run"]
        assert len(funcs) == 1
        assert funcs[0].is_exported is True

    def test_finds_struct(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        structs = [n for n in result.nodes if n.type == "class" and n.name == "User"]
        assert len(structs) == 1
        assert structs[0].is_exported is True

    def test_finds_enum(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        enums = [n for n in result.nodes if n.type == "class" and "enum" in n.decorators]
        assert any(n.name == "Role" for n in enums)

    def test_finds_trait(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        traits = [n for n in result.nodes if n.type == "class" and "trait" in n.decorators]
        assert any(n.name == "Validatable" for n in traits)

    def test_finds_impl_methods(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        methods = [n for n in result.nodes if n.type == "method"]
        method_names = {m.name for m in methods}
        assert "new" in method_names
        assert "display_name" in method_names
        assert "validate" in method_names

    def test_finds_constants(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        consts = [n for n in result.nodes if n.type == "variable" and n.name == "MAX_RETRIES"]
        assert len(consts) == 1
        assert consts[0].is_exported is True
        assert "const" in consts[0].signature

    def test_finds_type_alias(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        types = [n for n in result.nodes if n.name == "UserId"]
        assert len(types) == 1

    def test_finds_module_declaration(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        mods = [n for n in result.nodes if n.name == "models" and "mod" in n.decorators]
        assert len(mods) == 1


# ─── Relationships ───────────────────────────────────────────────────────


class TestRelationships:
    """Test edge extraction (CALLS, IMPORTS, IMPLEMENTS, CONTAINS)."""

    def test_use_imports(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        targets = {e.target for e in imports}
        assert "std::collections::HashMap" in targets

    def test_use_list_imports(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        imports = [e for e in result.edges if e.type == "IMPORTS"]
        targets = {e.target for e in imports}
        # use std::io::{self, Read} should produce std::io and std::io::Read
        assert "std::io" in targets
        assert "std::io::Read" in targets

    def test_function_calls(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        assert any("UserService" in t for t in targets)

    def test_method_calls_in_impl(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        # internal_check calls validate()
        assert any("validate" in t for t in targets)

    def test_trait_impl_implements_edge(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        impls = [e for e in result.edges if e.type == "IMPLEMENTS"]
        # User implements Validatable
        assert any(e.target == "Validatable" and "User" in e.source for e in impls)

    def test_contains_edges(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        contains = [e for e in result.edges if e.type == "CONTAINS"]
        # file->struct, struct->fields, file->enum, enum->variants, etc.
        assert len(contains) > 10

    def test_derive_attributes_in_decorators(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        user = [n for n in result.nodes if n.name == "User" and n.type == "class"]
        assert len(user) == 1
        # Should have derive(Debug, Clone, Serialize, Deserialize)
        derive_attrs = [a for a in user[0].decorators if "derive" in a.lower() or "Derive" in a]
        assert len(derive_attrs) > 0
        assert any("Debug" in a for a in derive_attrs)


# ─── Metadata ────────────────────────────────────────────────────────────


class TestMetadata:
    """Test signatures, doc comments, pub detection, attributes."""

    def test_pub_detection(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        user_new = [n for n in result.nodes if n.qualified_name == "User.new"]
        assert len(user_new) == 1
        assert user_new[0].is_exported is True

        internal = [n for n in result.nodes if n.qualified_name == "User.internal_check"]
        assert len(internal) == 1
        assert internal[0].is_exported is False

    def test_doc_comments(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        user = [n for n in result.nodes if n.name == "User" and n.type == "class"
                and "enum" not in n.decorators]
        assert len(user) == 1
        assert "user in the system" in user[0].docstring.lower()

    def test_derive_attributes(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        role = [n for n in result.nodes if n.name == "Role" and "enum" in n.decorators]
        assert len(role) == 1
        derive_attrs = [a for a in role[0].decorators if "derive" in a.lower() or "Debug" in a]
        assert len(derive_attrs) > 0

    def test_enum_variants(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        variants = [n for n in result.nodes if n.type == "variable"
                    and n.qualified_name.startswith("Role.")]
        names = {v.name for v in variants}
        assert "Admin" in names
        assert "Editor" in names
        assert "Viewer" in names

    def test_lifetime_stripping(self, parser: RustParser, tmp_path: Path):
        """Lifetimes should be stripped from signatures."""
        src = tmp_path / "src"
        src.mkdir(parents=True)
        (src / "lt.rs").write_text("""\
pub fn longest<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() > y.len() { x } else { y }
}
""")
        result = parser.parse(src / "lt.rs", tmp_path)
        func = [n for n in result.nodes if n.name == "longest"]
        assert len(func) == 1
        sig = func[0].signature
        assert "'a" not in sig
        assert "&str" in sig


# ─── Integration ─────────────────────────────────────────────────────────


class TestIntegration:
    """Test that Rust files work with the full indexing pipeline."""

    def test_index_rust_project(self, rust_project: Path):
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index

        # Register the Rust parser
        from codebrain.parser.registry import get_registry
        from codebrain.parser.rust_parser import RustParser as RP
        registry = get_registry()
        if ".rs" not in registry.supported_extensions:
            registry.register(RP())

        result = full_index(rust_project)
        assert result["errors"] == []
        assert result["files_parsed"] == 3

        db = rust_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            stats = store.get_stats()
            assert stats["nodes"] > 10
            assert stats["edges"] > 10

            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            results = engine.search_nodes("User")
            assert any(r["name"] == "User" for r in results)

    def test_impact_analysis_rust(self, rust_project: Path):
        """Impact analysis should work on Rust symbols."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.graph.query import QueryEngine
        from codebrain.indexer import full_index

        from codebrain.parser.registry import get_registry
        from codebrain.parser.rust_parser import RustParser as RP
        registry = get_registry()
        if ".rs" not in registry.supported_extensions:
            registry.register(RP())

        full_index(rust_project)
        db = rust_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)
            results = engine.search_nodes("Validatable")
            assert len(results) > 0

    def test_kt_document_rust(self, rust_project: Path):
        """KT document generation should work on Rust codebases."""
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.indexer import full_index
        from codebrain.kt import KTGenerator

        from codebrain.parser.registry import get_registry
        from codebrain.parser.rust_parser import RustParser as RP
        registry = get_registry()
        if ".rs" not in registry.supported_extensions:
            registry.register(RP())

        full_index(rust_project)
        db = rust_project / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            gen = KTGenerator(store)
            doc = gen.generate(project_name="RustTestProject")
            assert "# RustTestProject" in doc
            assert "## Architecture Overview" in doc


class TestExtensions:
    """Test parser extension registration."""

    def test_extensions(self, parser: RustParser):
        assert ".rs" in parser.extensions()

    def test_static_item(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/lib.rs"
        result = parser.parse(path, rust_project)
        statics = [n for n in result.nodes if n.name == "APP_NAME"]
        assert len(statics) == 1
        assert "static" in statics[0].signature

    def test_struct_fields(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        fields = [n for n in result.nodes if n.type == "variable"
                  and n.qualified_name.startswith("User.")]
        field_names = {f.name for f in fields}
        assert "id" in field_names
        assert "name" in field_names
        assert "email" in field_names

    def test_pub_struct_field(self, parser: RustParser, rust_project: Path):
        path = rust_project / "src/models.rs"
        result = parser.parse(path, rust_project)
        id_field = [n for n in result.nodes if n.qualified_name == "User.id"]
        assert len(id_field) == 1
        assert id_field[0].is_exported is True
        email_field = [n for n in result.nodes if n.qualified_name == "User.email"]
        assert len(email_field) == 1
        assert email_field[0].is_exported is False

    def test_cfg_test_module(self, parser: RustParser, rust_project: Path):
        """#[cfg(test)] mod tests should be detected."""
        path = rust_project / "src/utils.rs"
        result = parser.parse(path, rust_project)
        mods = [n for n in result.nodes if n.name == "tests"]
        assert len(mods) == 1
        attrs = mods[0].decorators
        assert any("cfg" in a for a in attrs)


# ─── Scoped Identifier / Path Expression References ──────────────────────


class TestScopedIdentifierReferences:
    """Test that enum variant access and match patterns emit CALLS edges."""

    def test_scoped_identifier_creates_calls_edge(self, parser: RustParser, tmp_path: Path):
        """Round::Down should emit a CALLS edge to Round::Down."""
        src = tmp_path / "src"
        src.mkdir(parents=True)
        (src / "lib.rs").write_text("""\
pub enum Round {
    Up,
    Down,
}

pub fn apply_rounding(x: f64) -> f64 {
    let mode = Round::Down;
    match mode {
        Round::Up => x.ceil(),
        Round::Down => x.floor(),
    }
}
""")
        result = parser.parse(src / "lib.rs", tmp_path)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        # Should have CALLS edges for Round.Down and Round.Up (:: normalized to .)
        assert any("Round" in t for t in targets), f"Expected Round reference in {targets}"
        assert "Round.Down" in targets or "Round.Up" in targets, \
            f"Expected Round.Down or Round.Up in {targets}"

    def test_match_arm_tuple_struct_pattern(self, parser: RustParser, tmp_path: Path):
        """TransferState::Running(buf) in match should emit a CALLS edge."""
        src = tmp_path / "src"
        src.mkdir(parents=True)
        (src / "lib.rs").write_text("""\
pub enum TransferState {
    Running(Vec<u8>),
    Done,
}

pub fn process(state: TransferState) {
    match state {
        TransferState::Running(buf) => {
            handle_buf(buf);
        }
        TransferState::Done => {}
    }
}

fn handle_buf(buf: Vec<u8>) {}
""")
        result = parser.parse(src / "lib.rs", tmp_path)
        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = {e.target for e in calls}
        # Match arm pattern TransferState::Running(buf) should create a reference
        assert any("TransferState" in t for t in targets), \
            f"Expected TransferState reference in {targets}"

    def test_scoped_identifier_not_duplicated_in_call_expression(self, parser: RustParser, tmp_path: Path):
        """Scoped identifiers inside call_expression should not double-emit."""
        src = tmp_path / "src"
        src.mkdir(parents=True)
        (src / "lib.rs").write_text("""\
pub struct Foo;
impl Foo {
    pub fn bar() -> i32 { 42 }
}

pub fn test_it() {
    let x = Foo::bar();
}
""")
        result = parser.parse(src / "lib.rs", tmp_path)
        calls = [e for e in result.edges if e.type == "CALLS"]
        foo_bar_calls = [e for e in calls if e.target == "Foo::bar"]
        # Should appear exactly once (from call_expression), not twice
        assert len(foo_bar_calls) == 1, \
            f"Expected 1 Foo::bar CALLS edge, got {len(foo_bar_calls)}"

    def test_dead_code_not_flagged_for_referenced_enum(self, parser: RustParser, tmp_path: Path):
        """Enum used via path expression should not be flagged as dead code."""
        src = tmp_path / "src"
        src.mkdir(parents=True)
        (src / "lib.rs").write_text("""\
pub enum Round {
    Up,
    Down,
}

pub fn do_round() -> i32 {
    let r = Round::Up;
    match r {
        Round::Up => 1,
        Round::Down => -1,
    }
}
""")
        from codebrain.parser.registry import get_registry
        from codebrain.parser.rust_parser import RustParser as RP
        registry = get_registry()
        if ".rs" not in registry.supported_extensions:
            registry.register(RP())

        from codebrain.indexer import full_index
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.graph.query import QueryEngine

        full_index(tmp_path)
        db = tmp_path / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)
            dead = engine.find_dead_code()
            dead_names = {d["name"] for d in dead if d.get("confidence", "high") == "high"}
            assert "Round" not in dead_names, \
                f"Round should not be dead code, dead={dead_names}"


class TestTokioScopedRefs:
    """Validate scoped identifier fix on real Tokio codebase."""

    TOKIO_PATH = Path(r"C:\Users\ASUS\AppData\Local\Temp\codebrain-test-repos\tokio")

    @pytest.fixture(autouse=True)
    def _skip_if_no_tokio(self):
        if not self.TOKIO_PATH.exists():
            pytest.skip("Tokio repo not available")

    def test_tokio_round_not_dead_code(self):
        """Round and TransferState should not be flagged as dead in Tokio."""
        from codebrain.parser.registry import get_registry
        from codebrain.parser.rust_parser import RustParser as RP
        from codebrain.indexer import full_index
        from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
        from codebrain.graph.store import GraphStore
        from codebrain.graph.query import QueryEngine

        registry = get_registry()
        if ".rs" not in registry.supported_extensions:
            registry.register(RP())

        full_index(self.TOKIO_PATH)
        db = self.TOKIO_PATH / CODEBRAIN_DIR / DB_FILENAME
        with GraphStore(db) as store:
            engine = QueryEngine(store)
            dead = engine.find_dead_code()
            dead_high = {d["name"] for d in dead if d.get("confidence", "high") == "high"}
            assert "Round" not in dead_high, "Round should not be high-confidence dead code"
            assert "TransferState" not in dead_high, \
                "TransferState should not be high-confidence dead code"
