"""Tests for SPEC-M39: UI Framework Translation.

Covers:
- UITranslator.detect_framework: vue, react, unknown
- UITranslator.extract_component_specs: props, events, children, api_calls
- UITranslator.build_enriched_prompt: props, children, event->callback mapping
- UITranslator.validate_translation: missing prop/callback/child/api_call, all present
- UITranslator.generate_wiring_checklist: routes and stores
- CLI: ui-detect, ui-translate commands exist
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_store(tmp_path: Path) -> GraphStore:
    """Create a fresh store."""
    db = tmp_path / ".codebrain" / "graph.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    return GraphStore(db)


def _insert_node(store: GraphStore, *, id: str, name: str, type: str,
                 file_path: str, signature: str = "", **kwargs) -> None:
    """Insert a single node into the store."""
    store.conn.execute(
        """INSERT OR REPLACE INTO nodes
           (id, name, qualified_name, type, file_path,
            line_start, line_end, signature, decorators, docstring,
            is_exported, summary)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (id, name, kwargs.get("qualified_name", name), type, file_path,
         kwargs.get("line_start", 1), kwargs.get("line_end", 10),
         signature, kwargs.get("decorators", "[]"), kwargs.get("docstring", ""),
         int(kwargs.get("is_exported", True)), kwargs.get("summary", "")),
    )
    store.conn.commit()


def _insert_edge(store: GraphStore, *, source: str, target: str,
                 type: str, file_path: str, line: int = 1) -> None:
    """Insert a single edge into the store."""
    store.conn.execute(
        """INSERT OR IGNORE INTO edges (source, target, type, file_path, line)
           VALUES (?, ?, ?, ?, ?)""",
        (source, target, type, file_path, line),
    )
    store.conn.commit()


def _make_vue_store(tmp_path: Path) -> GraphStore:
    """Create a store with a synthetic Vue project."""
    store = _make_store(tmp_path)

    # Components
    _insert_node(store, id="App.vue::App", name="App", type="component",
                 file_path="App.vue",
                 signature='[{"name": "title", "type": "string"}]')
    _insert_node(store, id="Header.vue::Header", name="Header", type="component",
                 file_path="Header.vue",
                 signature='[{"name": "title", "type": "string"}]')
    _insert_node(store, id="TaskList.vue::TaskList", name="TaskList", type="component",
                 file_path="TaskList.vue",
                 signature='[{"name": "tasks", "type": "array"}]')
    _insert_node(store, id="TaskForm.vue::TaskForm", name="TaskForm", type="component",
                 file_path="TaskForm.vue",
                 signature='[{"name": "task", "type": "object"}]')

    # RENDERS edges (parent -> child)
    _insert_edge(store, source="App.vue::App", target="Header",
                 type="RENDERS", file_path="App.vue", line=5)
    _insert_edge(store, source="App.vue::App", target="TaskList",
                 type="RENDERS", file_path="App.vue", line=6)

    # EMITS edges (component -> event name)
    _insert_edge(store, source="Header.vue::Header", target="search",
                 type="EMITS", file_path="Header.vue", line=10)
    _insert_edge(store, source="TaskList.vue::TaskList", target="select",
                 type="EMITS", file_path="TaskList.vue", line=15)
    _insert_edge(store, source="TaskForm.vue::TaskForm", target="save",
                 type="EMITS", file_path="TaskForm.vue", line=20)
    _insert_edge(store, source="TaskForm.vue::TaskForm", target="cancel",
                 type="EMITS", file_path="TaskForm.vue", line=21)

    # FETCHES edges (component -> API URL)
    _insert_edge(store, source="TaskList.vue::TaskList", target="/api/tasks",
                 type="FETCHES", file_path="TaskList.vue", line=12)

    # Route node + ROUTES_TO edge
    _insert_node(store, id="router.js::route:/tasks", name="/tasks", type="route",
                 file_path="router.js")
    _insert_edge(store, source="router.js::route:/tasks", target="TaskList",
                 type="ROUTES_TO", file_path="router.js", line=3)

    # Store node + SUBSCRIBES edge
    _insert_node(store, id="store/tasks.js::taskStore", name="taskStore", type="store",
                 file_path="store/tasks.js")
    _insert_edge(store, source="TaskList.vue::TaskList", target="taskStore",
                 type="SUBSCRIBES", file_path="TaskList.vue", line=8)

    return store


def _make_react_store(tmp_path: Path) -> GraphStore:
    """Create a store with a synthetic React project."""
    store = _make_store(tmp_path)

    _insert_node(store, id="App.tsx::App", name="App", type="component",
                 file_path="App.tsx")
    _insert_node(store, id="hooks/useAuth.ts::useAuth", name="useAuth", type="hook",
                 file_path="hooks/useAuth.ts")
    _insert_node(store, id="UserCard.tsx::UserCard", name="UserCard", type="component",
                 file_path="UserCard.tsx",
                 signature='[{"name": "user", "type": "User"}]')

    _insert_edge(store, source="App.tsx::App", target="UserCard",
                 type="RENDERS", file_path="App.tsx", line=10)

    return store


def _make_empty_store(tmp_path: Path) -> GraphStore:
    """Create a store with only backend nodes (no components)."""
    store = _make_store(tmp_path)

    _insert_node(store, id="main.py::main", name="main", type="function",
                 file_path="main.py")
    _insert_node(store, id="utils.py::helper", name="helper", type="function",
                 file_path="utils.py")

    return store


# ---------------------------------------------------------------------------
# detect_framework tests
# ---------------------------------------------------------------------------


class TestDetectFramework:
    def test_detect_framework_vue(self, tmp_path):
        """Detects Vue from .vue file paths."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        assert translator.detect_framework() == "vue"
        store.close()

    def test_detect_framework_react(self, tmp_path):
        """Detects React from .tsx file paths and hook nodes."""
        store = _make_react_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        assert translator.detect_framework() == "react"
        store.close()

    def test_detect_framework_unknown(self, tmp_path):
        """Returns 'unknown' for backend-only projects."""
        store = _make_empty_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        assert translator.detect_framework() == "unknown"
        store.close()


# ---------------------------------------------------------------------------
# extract_component_specs tests
# ---------------------------------------------------------------------------


class TestExtractComponentSpecs:
    def test_extract_component_specs_props(self, tmp_path):
        """Extracts props from component signature."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        header_spec = next(s for s in specs if s.name == "Header")
        assert len(header_spec.props) == 1
        assert header_spec.props[0]["name"] == "title"
        store.close()

    def test_extract_component_specs_events(self, tmp_path):
        """Extracts events/emits from EMITS edges."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        header_spec = next(s for s in specs if s.name == "Header")
        assert "search" in header_spec.events

        form_spec = next(s for s in specs if s.name == "TaskForm")
        assert "save" in form_spec.events
        assert "cancel" in form_spec.events
        store.close()

    def test_extract_component_specs_children(self, tmp_path):
        """Extracts child component names from RENDERS edges."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        app_spec = next(s for s in specs if s.name == "App")
        assert "Header" in app_spec.children
        assert "TaskList" in app_spec.children
        store.close()

    def test_extract_component_specs_api_calls(self, tmp_path):
        """Extracts API URLs from FETCHES edges."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        list_spec = next(s for s in specs if s.name == "TaskList")
        assert "/api/tasks" in list_spec.api_calls
        store.close()


# ---------------------------------------------------------------------------
# build_enriched_prompt tests
# ---------------------------------------------------------------------------


class TestBuildEnrichedPrompt:
    def test_enriched_prompt_includes_props(self, tmp_path):
        """Prompt lists all props."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        header_spec = next(s for s in specs if s.name == "Header")
        prompt = translator.build_enriched_prompt(header_spec, "react")
        assert "title" in prompt
        assert "Props" in prompt
        store.close()

    def test_enriched_prompt_includes_children(self, tmp_path):
        """Prompt lists child components."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        app_spec = next(s for s in specs if s.name == "App")
        prompt = translator.build_enriched_prompt(app_spec, "react")
        assert "Header" in prompt
        assert "TaskList" in prompt
        assert "Children" in prompt
        store.close()

    def test_enriched_prompt_vue_events_to_react_callbacks(self, tmp_path):
        """Events are mapped to onXxx callback names when target is React."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        header_spec = next(s for s in specs if s.name == "Header")
        prompt = translator.build_enriched_prompt(header_spec, "react")
        assert "onSearch" in prompt
        assert "callback" in prompt.lower()
        store.close()

    def test_enriched_prompt_includes_api_calls(self, tmp_path):
        """Prompt lists API endpoints."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        list_spec = next(s for s in specs if s.name == "TaskList")
        prompt = translator.build_enriched_prompt(list_spec, "react")
        assert "/api/tasks" in prompt
        assert "API" in prompt
        store.close()


# ---------------------------------------------------------------------------
# validate_translation tests
# ---------------------------------------------------------------------------


class TestValidateTranslation:
    def test_validate_missing_prop(self, tmp_path):
        """Catches missing prop in translated code."""
        from codebrain.ui_migration import UITranslator, ComponentSpec
        store = _make_store(tmp_path)
        translator = UITranslator(store)

        spec = ComponentSpec(
            name="Header", file_path="Header.vue", framework="vue",
            props=[{"name": "title", "type": "string"}],
        )
        # Code that does NOT contain the prop name
        code = "function Header() { return <div>Hello</div>; }"
        errors = translator.validate_translation(spec, code, "react")
        assert any("title" in e for e in errors)
        store.close()

    def test_validate_missing_callback(self, tmp_path):
        """Catches missing onXxx callback when translating Vue events to React."""
        from codebrain.ui_migration import UITranslator, ComponentSpec
        store = _make_store(tmp_path)
        translator = UITranslator(store)

        spec = ComponentSpec(
            name="Header", file_path="Header.vue", framework="vue",
            events=["search"],
        )
        # Code without onSearch or search
        code = "function Header() { return <div>Hello</div>; }"
        errors = translator.validate_translation(spec, code, "react")
        assert any("onSearch" in e for e in errors)
        store.close()

    def test_validate_missing_child(self, tmp_path):
        """Catches missing child component reference."""
        from codebrain.ui_migration import UITranslator, ComponentSpec
        store = _make_store(tmp_path)
        translator = UITranslator(store)

        spec = ComponentSpec(
            name="App", file_path="App.vue", framework="vue",
            children=["Header", "TaskList"],
        )
        # Code with only Header, missing TaskList
        code = "function App() { return <div><Header /></div>; }"
        errors = translator.validate_translation(spec, code, "react")
        assert any("TaskList" in e for e in errors)
        assert not any("Header" in e for e in errors)
        store.close()

    def test_validate_missing_api_call(self, tmp_path):
        """Catches missing API endpoint in translated code."""
        from codebrain.ui_migration import UITranslator, ComponentSpec
        store = _make_store(tmp_path)
        translator = UITranslator(store)

        spec = ComponentSpec(
            name="TaskList", file_path="TaskList.vue", framework="vue",
            api_calls=["/api/tasks"],
        )
        code = "function TaskList() { return <div>Tasks</div>; }"
        errors = translator.validate_translation(spec, code, "react")
        assert any("/api/tasks" in e for e in errors)
        store.close()

    def test_validate_all_present(self, tmp_path):
        """No errors when everything is preserved."""
        from codebrain.ui_migration import UITranslator, ComponentSpec
        store = _make_store(tmp_path)
        translator = UITranslator(store)

        spec = ComponentSpec(
            name="Header", file_path="Header.vue", framework="vue",
            props=[{"name": "title", "type": "string"}],
            events=["search"],
            children=["SearchBox"],
            api_calls=["/api/search"],
        )
        code = (
            "function Header({ title, onSearch }) {\n"
            "  return <div><SearchBox /><button onClick={onSearch} />"
            "fetch('/api/search')</div>;\n"
            "}"
        )
        errors = translator.validate_translation(spec, code, "react")
        assert errors == []
        store.close()


# ---------------------------------------------------------------------------
# generate_wiring_checklist tests
# ---------------------------------------------------------------------------


class TestWiringChecklist:
    def test_wiring_checklist_includes_routes(self, tmp_path):
        """Checklist mentions route setup."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        checklist = translator.generate_wiring_checklist("react")

        assert "Routing" in checklist or "route" in checklist.lower()
        assert "/tasks" in checklist
        assert "React Router" in checklist
        store.close()

    def test_wiring_checklist_includes_stores(self, tmp_path):
        """Checklist mentions state management stores."""
        store = _make_vue_store(tmp_path)
        from codebrain.ui_migration import UITranslator
        translator = UITranslator(store)
        checklist = translator.generate_wiring_checklist("react")

        assert "State Management" in checklist or "store" in checklist.lower()
        assert "taskStore" in checklist
        store.close()


# ---------------------------------------------------------------------------
# CLI tests
# ---------------------------------------------------------------------------


class TestCLI:
    def test_cli_ui_detect(self):
        """ui-detect command is registered."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["ui-detect", "--help"])
        assert result.exit_code == 0
        assert "Detect" in result.output or "detect" in result.output

    def test_cli_ui_translate(self):
        """ui-translate command is registered."""
        from click.testing import CliRunner
        from codebrain.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["ui-translate", "--help"])
        assert result.exit_code == 0
        assert "target" in result.output.lower()
        assert "output" in result.output.lower()


# ---------------------------------------------------------------------------
# SPEC-M39 "Validation" section — end-to-end Vue -> React pipeline
# ---------------------------------------------------------------------------
# Builds the 5-component synthetic Vue project the spec calls out
# (App / Header / MainContent / TaskList / TaskForm), runs the real indexer
# and UITranslator, mocks RewriteEngine.rewrite_module to return deterministic
# React translations, and asserts the full pipeline preserves every
# structural contract: props, events -> callbacks, children, API calls.


_VUE_APP = """\
<template>
  <div id=\"app\">
    <Header :title=\"title\" @search=\"onSearch\" />
    <MainContent :tasks=\"tasks\" />
  </div>
</template>
<script setup>
import Header from './Header.vue'
import MainContent from './MainContent.vue'
const title = 'Tasks'
const tasks = []
const onSearch = (q) => {}
</script>
"""

_VUE_HEADER = """\
<template>
  <header>
    <h1>{{ title }}</h1>
    <input @input=\"onInput\" />
  </header>
</template>
<script setup>
const props = defineProps({ title: String })
const emit = defineEmits(['search'])
const onInput = (e) => emit('search', e.target.value)
</script>
"""

_VUE_MAIN_CONTENT = """\
<template>
  <main>
    <TaskList :tasks=\"tasks\" @select=\"onSelect\" />
    <TaskForm :task=\"current\" @save=\"onSave\" @cancel=\"onCancel\" />
  </main>
</template>
<script setup>
import TaskList from './TaskList.vue'
import TaskForm from './TaskForm.vue'
const props = defineProps({ tasks: Array })
const current = null
const onSelect = (t) => {}
const onSave = (t) => {}
const onCancel = () => {}
</script>
"""

_VUE_TASK_LIST = """\
<template>
  <ul>
    <li v-for=\"t in items\" :key=\"t.id\" @click=\"select(t)\">{{ t.title }}</li>
  </ul>
</template>
<script setup>
const props = defineProps({ tasks: Array })
const emit = defineEmits(['select'])
const items = props.tasks
const select = (t) => emit('select', t)
fetch('/api/tasks')
</script>
"""

_VUE_TASK_FORM = """\
<template>
  <form>
    <input :value=\"task.title\" />
    <button @click=\"$emit('save', task)\">Save</button>
    <button @click=\"$emit('cancel')\">Cancel</button>
  </form>
</template>
<script setup>
const props = defineProps({ task: Object })
const emit = defineEmits(['save', 'cancel'])
</script>
"""


@pytest.fixture
def vue_project(tmp_path):
    """Write the 5 spec-mandated Vue SFCs and index them."""
    from codebrain.indexer import full_index

    root = tmp_path / "vue-app"
    root.mkdir()
    (root / "App.vue").write_text(_VUE_APP, encoding="utf-8")
    (root / "Header.vue").write_text(_VUE_HEADER, encoding="utf-8")
    (root / "MainContent.vue").write_text(_VUE_MAIN_CONTENT, encoding="utf-8")
    (root / "TaskList.vue").write_text(_VUE_TASK_LIST, encoding="utf-8")
    (root / "TaskForm.vue").write_text(_VUE_TASK_FORM, encoding="utf-8")

    db = root / ".codebrain" / "graph.db"
    db.parent.mkdir(exist_ok=True)
    full_index(root, db)
    return root, db


class TestSpecM39Validation:
    """The end-to-end scenario the SPEC-M39 'Validation' section mandates."""

    def test_all_five_components_indexed_as_components(self, vue_project):
        root, db = vue_project
        with GraphStore(db) as store:
            nodes = store.get_all_nodes()
            components = {n["name"] for n in nodes if n["type"] == "component"}
        expected = {"App", "Header", "MainContent", "TaskList", "TaskForm"}
        assert expected.issubset(components), (
            f"Expected {expected}, got components={components}"
        )

    def test_extract_specs_for_all_five(self, vue_project):
        root, db = vue_project
        from codebrain.ui_migration import UITranslator
        with GraphStore(db) as store:
            translator = UITranslator(store)
            assert translator.detect_framework() == "vue"
            specs = {s.name: s for s in translator.extract_component_specs()}
        for name in ("App", "Header", "MainContent", "TaskList", "TaskForm"):
            assert name in specs, f"Missing spec for {name}: got {list(specs)}"

    def test_enriched_prompts_carry_props_and_children(self, vue_project):
        root, db = vue_project
        from codebrain.ui_migration import UITranslator
        with GraphStore(db) as store:
            translator = UITranslator(store)
            specs = {s.name: s for s in translator.extract_component_specs()}

            header_prompt = translator.build_enriched_prompt(specs["Header"], "react")
            assert "title" in header_prompt, \
                f"Header prompt missing 'title' prop: {header_prompt}"

            app_prompt = translator.build_enriched_prompt(specs["App"], "react")
            # App renders Header and MainContent
            assert "Header" in app_prompt and "MainContent" in app_prompt

    def test_validation_catches_missing_contracts(self, vue_project):
        root, db = vue_project
        from codebrain.ui_migration import UITranslator
        with GraphStore(db) as store:
            translator = UITranslator(store)
            specs = {s.name: s for s in translator.extract_component_specs()}

            # Good translation: preserves title prop + onSearch callback
            good_header = (
                "export function Header({ title, onSearch }: "
                "{ title: string; onSearch?: (q: string) => void }) "
                "{ return <header><h1>{title}</h1></header> }"
            )
            assert translator.validate_translation(
                specs["Header"], good_header, "react",
            ) == []

            # Bad translation: title prop dropped
            bad_header = "export function Header() { return <header/> }"
            errors = translator.validate_translation(
                specs["Header"], bad_header, "react",
            )
            assert any("title" in e for e in errors), errors

    def test_full_pipeline_via_cli_mocked_llm(self, vue_project, tmp_path,
                                              monkeypatch):
        """ui-translate CLI with a mocked RewriteEngine produces per-component
        React files + a wiring checklist, and validation flags components the
        mock translator butchered."""
        from unittest.mock import patch, MagicMock
        from click.testing import CliRunner
        from codebrain.cli import cli

        root, _db = vue_project
        out_dir = tmp_path / "react-out"

        # Deterministic React output per component: preserves name + every
        # known prop/child/emit. Done as a factory so we can also produce a
        # broken output for one component to exercise the validation path.
        def fake_rewrite_module(self, file_path, output_dir, target_stack,
                                guidelines):
            comp_name = Path(file_path).stem
            # Collect everything the prompt mentioned that should survive.
            parts = [f"export function {comp_name}("]
            parts.append("{ title, tasks, task, onSearch, onSelect, onSave, onCancel }")
            parts.append(") { return (<>")
            if comp_name == "App":
                parts.append("<Header /><MainContent />")
            elif comp_name == "MainContent":
                parts.append("<TaskList /><TaskForm />")
            elif comp_name == "TaskList":
                parts.append("fetch('/api/tasks')")
            parts.append("</>); }")
            code = "".join(parts)

            # Write into output_dir so CLI sees the file.
            out_path = Path(output_dir) / f"{comp_name}.tsx"
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(code, encoding="utf-8")

            result = MagicMock()
            result.code = code
            result.output_path = out_path
            return result

        # Client must advertise availability so the CLI doesn't short-circuit.
        fake_client = MagicMock()
        fake_client.is_available.return_value = True

        runner = CliRunner()
        with patch("codebrain.rewriter.create_client", return_value=fake_client), \
             patch("codebrain.rewriter.RewriteEngine.rewrite_module",
                   new=fake_rewrite_module):
            result = runner.invoke(
                cli,
                ["--repo", str(root), "ui-translate",
                 "-o", str(out_dir),
                 "--target", "react",
                 "--provider", "anthropic",
                 "--model", "claude-x"],
            )

        assert result.exit_code == 0, \
            f"ui-translate failed:\n{result.output}\n{result.exception}"

        # Every source Vue component should have produced a React file.
        for name in ("App", "Header", "MainContent", "TaskList", "TaskForm"):
            tsx = out_dir / f"{name}.tsx"
            assert tsx.exists(), f"Missing {tsx}: CLI output was\n{result.output}"
            body = tsx.read_text(encoding="utf-8")
            assert f"export function {name}" in body

        # Wiring checklist should be written next to the translated files.
        checklist = out_dir / "WIRING_CHECKLIST.md"
        assert checklist.exists(), "WIRING_CHECKLIST.md not produced"
        checklist_text = checklist.read_text(encoding="utf-8")
        assert "Wiring Checklist" in checklist_text
