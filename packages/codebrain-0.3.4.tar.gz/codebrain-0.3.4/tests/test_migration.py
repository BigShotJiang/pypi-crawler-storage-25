"""Tests for the migration tools (plan, contracts, tracker, equivalence)."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.migration import (
    ContractExtractor,
    EquivalenceReporter,
    MigrationPlanGenerator,
    MigrationTracker,
)


@pytest.fixture
def old_project(tmp_path: Path) -> tuple[Path, GraphStore]:
    """Create and index an 'old' project."""
    root = tmp_path / "old"
    pkg = root / "myapp"
    pkg.mkdir(parents=True)

    (pkg / "__init__.py").write_text(
        '"""My app."""\nfrom myapp.core import process\n'
    )

    (pkg / "core.py").write_text('''\
"""Core module."""
from myapp.utils import helper

__all__ = ["process", "DataProcessor"]

def process(data):
    """Process incoming data."""
    result = helper(data)
    return transform(result)

def transform(value):
    """Internal transform."""
    return value * 2

class DataProcessor:
    """Main processor."""
    def __init__(self, config):
        self.config = config

    def run(self, items):
        """Run processing."""
        return [process(i) for i in items]
''')

    (pkg / "utils.py").write_text('''\
"""Utilities."""

__all__ = ["helper", "format_output"]

def helper(x):
    """Help with stuff."""
    return x + 1

def format_output(data):
    """Format data for display."""
    return str(data)

def _internal():
    pass
''')

    (pkg / "models.py").write_text('''\
"""Data models."""
from dataclasses import dataclass

__all__ = ["Item", "SpecialItem"]

@dataclass
class Item:
    """A single item."""
    name: str
    value: int = 0

class SpecialItem(Item):
    """Extended item."""
    def compute(self):
        return self.value * 10
''')

    full_index(root)
    db = root / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db)
    yield root, store
    store.close()


@pytest.fixture
def new_project(tmp_path: Path) -> tuple[Path, GraphStore]:
    """Create and index a 'new' project (partial rewrite of old)."""
    root = tmp_path / "new"
    pkg = root / "myapp"
    pkg.mkdir(parents=True)

    (pkg / "__init__.py").write_text(
        '"""My app v2."""\nfrom myapp.core import process\n'
    )

    # Core rewritten with different signature
    (pkg / "core.py").write_text('''\
"""Core module v2."""
from myapp.utils import helper

__all__ = ["process", "DataProcessor"]

def process(data: dict) -> dict:
    """Process incoming data (v2 with types)."""
    result = helper(data)
    return result

class DataProcessor:
    """Main processor v2."""
    def __init__(self, config: dict):
        self.config = config

    def run(self, items: list) -> list:
        """Run processing."""
        return [process(i) for i in items]
''')

    # Utils: helper migrated, format_output removed, new function added
    (pkg / "utils.py").write_text('''\
"""Utilities v2."""

__all__ = ["helper", "validate_input"]

def helper(x):
    """Help with stuff."""
    return x + 1

def validate_input(data):
    """New validation function."""
    return data is not None
''')

    # models.py not created (not migrated yet)

    full_index(root)
    db = root / CODEBRAIN_DIR / DB_FILENAME
    store = GraphStore(db)
    yield root, store
    store.close()


class TestMigrationPlanGenerator:
    """Tests for the migration plan generator."""

    def test_plan_has_phases(self, old_project):
        _, store = old_project
        gen = MigrationPlanGenerator(store)
        plan = gen.generate_plan()
        assert "phases" in plan
        assert len(plan["phases"]) > 0

    def test_plan_has_totals(self, old_project):
        _, store = old_project
        gen = MigrationPlanGenerator(store)
        plan = gen.generate_plan()
        assert plan["total_files"] > 0
        assert plan["total_symbols"] > 0
        assert plan["total_phases"] > 0

    def test_modules_have_public_api(self, old_project):
        _, store = old_project
        gen = MigrationPlanGenerator(store)
        plan = gen.generate_plan()
        all_modules = [m for p in plan["phases"] for m in p["modules"]]
        modules_with_api = [m for m in all_modules if m["public_api"]]
        assert len(modules_with_api) > 0

    def test_complexity_values(self, old_project):
        _, store = old_project
        gen = MigrationPlanGenerator(store)
        plan = gen.generate_plan()
        for phase in plan["phases"]:
            assert phase["complexity"] in ("low", "medium", "high")

    def test_to_markdown(self, old_project):
        _, store = old_project
        gen = MigrationPlanGenerator(store)
        md = gen.to_markdown()
        assert "# Migration Plan" in md
        assert "## Phase" in md
        assert "Public API" in md

    def test_risk_hotspots_included(self, old_project):
        _, store = old_project
        gen = MigrationPlanGenerator(store)
        plan = gen.generate_plan()
        assert "risk_hotspots" in plan


class TestContractExtractor:
    """Tests for the contract extractor."""

    def test_extracts_contracts(self, old_project):
        _, store = old_project
        ext = ContractExtractor(store)
        result = ext.extract()
        assert result["total_modules"] > 0
        assert result["total_contracts"] > 0

    def test_function_has_signature(self, old_project):
        _, store = old_project
        ext = ContractExtractor(store)
        result = ext.extract()
        all_fns = [
            fn for mod in result["modules"].values()
            for fn in mod["functions"]
        ]
        assert any(fn["signature"] for fn in all_fns)

    def test_class_has_methods(self, old_project):
        _, store = old_project
        ext = ContractExtractor(store)
        result = ext.extract()
        all_classes = [
            cls for mod in result["modules"].values()
            for cls in mod["classes"]
        ]
        classes_with_methods = [c for c in all_classes if c["methods"]]
        assert len(classes_with_methods) > 0

    def test_file_filter(self, old_project):
        _, store = old_project
        ext = ContractExtractor(store)
        result = ext.extract(file_path="myapp/utils.py")
        assert len(result["modules"]) == 1
        assert "myapp/utils.py" in result["modules"]

    def test_class_has_bases(self, old_project):
        _, store = old_project
        ext = ContractExtractor(store)
        result = ext.extract()
        all_classes = [
            cls for mod in result["modules"].values()
            for cls in mod["classes"]
        ]
        special = [c for c in all_classes if c["name"] == "SpecialItem"]
        if special:
            assert len(special[0]["bases"]) > 0

    def test_to_markdown(self, old_project):
        _, store = old_project
        ext = ContractExtractor(store)
        md = ext.to_markdown()
        assert "# API Contracts" in md


class TestMigrationTracker:
    """Tests for the migration tracker."""

    def test_identifies_migrated(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        tracker = MigrationTracker()
        result = tracker.compare(old_store, new_store)
        assert result["summary"]["migrated"] > 0

    def test_identifies_pending(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        tracker = MigrationTracker()
        result = tracker.compare(old_store, new_store)
        # format_output and models are not in new
        assert result["summary"]["pending"] > 0

    def test_coverage_percentage(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        tracker = MigrationTracker()
        result = tracker.compare(old_store, new_store)
        assert 0 <= result["summary"]["coverage_pct"] <= 100

    def test_by_module_exists(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        tracker = MigrationTracker()
        result = tracker.compare(old_store, new_store)
        assert len(result["by_module"]) > 0

    def test_module_status(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        tracker = MigrationTracker()
        result = tracker.compare(old_store, new_store)
        statuses = {mod["status"] for mod in result["by_module"].values()}
        assert statuses <= {"migrated", "partial", "pending"}

    def test_unmapped_new_symbols(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        tracker = MigrationTracker()
        result = tracker.compare(old_store, new_store)
        # validate_input is new and not in old
        assert "unmapped_new_symbols" in result


class TestEquivalenceReporter:
    """Tests for the equivalence reporter."""

    def test_report_structure(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        reporter = EquivalenceReporter()
        result = reporter.report(old_store, new_store)
        assert "migration_status" in result
        assert "structural_diff" in result
        assert "stats" in result

    def test_stats_comparison(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        reporter = EquivalenceReporter()
        result = reporter.report(old_store, new_store)
        stats = result["stats"]
        assert stats["old_files"] > 0
        assert stats["new_files"] > 0
        assert stats["old_symbols"] > 0
        assert stats["new_symbols"] > 0

    def test_file_diff(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        reporter = EquivalenceReporter()
        result = reporter.report(old_store, new_store)
        fd = result["structural_diff"]["file_diff"]
        assert "old_only" in fd
        assert "new_only" in fd
        assert "common" in fd

    def test_includes_migration_status(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        reporter = EquivalenceReporter()
        result = reporter.report(old_store, new_store)
        assert "coverage_pct" in result["migration_status"]["summary"]

    def test_to_markdown(self, old_project, new_project):
        _, old_store = old_project
        _, new_store = new_project
        reporter = EquivalenceReporter()
        md = reporter.to_markdown(old_store=old_store, new_store=new_store)
        assert "# Migration Equivalence Report" in md
        assert "Coverage" in md

    def test_missing_hierarchies_detected(self, old_project, new_project):
        """SpecialItem extends Item, but models.py not in new project."""
        _, old_store = old_project
        _, new_store = new_project
        reporter = EquivalenceReporter()
        result = reporter.report(old_store, new_store)
        hierarchies = result["structural_diff"]["missing_class_hierarchies"]
        # SpecialItem -> Item should be missing since models.py not in new
        assert len(hierarchies) > 0
