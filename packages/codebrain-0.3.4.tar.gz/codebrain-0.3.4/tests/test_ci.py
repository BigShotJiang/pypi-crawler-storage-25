"""M10: CI integration — brain ci command.

Tests that brain ci correctly validates changed files in a git repo.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
from click.testing import CliRunner

from codebrain.cli import cli
from codebrain.indexer import full_index


@pytest.fixture
def git_project(tmp_path):
    """Create a git repo with indexed CodeBrain, make a branch."""
    root = tmp_path / "repo"
    root.mkdir()
    pkg = root / "mypkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "core.py").write_text(
        "def greet(name):\n    return f'hello {name}'\n",
        encoding="utf-8",
    )
    (pkg / "cli.py").write_text(
        "from mypkg.core import greet\n\ndef main():\n    print(greet('world'))\n",
        encoding="utf-8",
    )

    # Init git repo
    subprocess.run(["git", "init", "-b", "main"], cwd=str(root), capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(root), capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=str(root), capture_output=True)
    subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
    subprocess.run(["git", "commit", "-m", "initial"], cwd=str(root), capture_output=True)

    # Index
    db_path = root / ".codebrain" / "graph.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    full_index(root, db_path)

    # Create feature branch
    subprocess.run(["git", "checkout", "-b", "feature"], cwd=str(root), capture_output=True)

    return root


class TestCICommand:

    def test_safe_change_exits_0(self, git_project):
        """Adding a new function should be SAFE (exit 0)."""
        root = git_project
        core = root / "mypkg" / "core.py"
        content = core.read_text(encoding="utf-8")
        core.write_text(content + "\ndef helper():\n    pass\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
        subprocess.run(["git", "commit", "-m", "safe change"], cwd=str(root), capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "ci", "--base", "main"])
        assert result.exit_code == 0, f"Safe change should exit 0: {result.output}"
        assert "SAFE" in result.output

    def test_breaking_change_exits_1(self, git_project):
        """Removing greet (called by cli.py) should be UNSAFE (exit 1)."""
        root = git_project
        core = root / "mypkg" / "core.py"
        core.write_text("def farewell():\n    return 'bye'\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
        subprocess.run(["git", "commit", "-m", "break"], cwd=str(root), capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "ci", "--base", "main"])
        assert result.exit_code == 1, f"Breaking change should exit 1: {result.output}"
        assert "UNSAFE" in result.output

    def test_json_output(self, git_project):
        """--json flag produces machine-readable output."""
        import json

        root = git_project
        core = root / "mypkg" / "core.py"
        content = core.read_text(encoding="utf-8")
        core.write_text(content + "\ndef helper():\n    pass\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
        subprocess.run(["git", "commit", "-m", "safe"], cwd=str(root), capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "ci", "--base", "main", "--json"])
        data = json.loads(result.output)
        assert "verdict" in data
        assert "changed_files" in data
        assert data["verdict"] == "SAFE"

    def test_no_changes_is_safe(self, git_project):
        """No changes should be SAFE."""
        root = git_project
        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "ci", "--base", "main"])
        assert result.exit_code == 0

    def test_json_has_per_file_verdicts(self, git_project):
        """--json output includes per-file data with is_valid and violations."""
        import json

        root = git_project
        core = root / "mypkg" / "core.py"
        # Remove greet (breaking change) to get violations in per-file output
        core.write_text("def farewell():\n    return 'bye'\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
        subprocess.run(["git", "commit", "-m", "break"], cwd=str(root), capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "ci", "--base", "main", "--json"])
        data = json.loads(result.output)

        assert "files" in data, "JSON output must include 'files' array"
        assert len(data["files"]) > 0, "Should have at least one changed file"
        for f in data["files"]:
            assert "file" in f, "Each file entry must have 'file' key"
            assert "is_valid" in f, "Each file entry must have 'is_valid' key"
            assert "violations" in f, "Each file entry must have 'violations' key"

    def test_human_output_has_per_file_verdicts(self, git_project):
        """Human-readable output shows per-file verdict table."""
        root = git_project
        core = root / "mypkg" / "core.py"
        content = core.read_text(encoding="utf-8")
        core.write_text(content + "\ndef helper():\n    pass\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
        subprocess.run(["git", "commit", "-m", "add helper"], cwd=str(root), capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "ci", "--base", "main"])

        assert "CodeBrain Structural Validation" in result.output
        assert "Changed files:" in result.output
        assert "core.py" in result.output
        assert "Verdict:" in result.output

    def test_breaking_json_has_violation_details(self, git_project):
        """Breaking change JSON includes violation severity and message."""
        import json

        root = git_project
        core = root / "mypkg" / "core.py"
        core.write_text("def farewell():\n    return 'bye'\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
        subprocess.run(["git", "commit", "-m", "break"], cwd=str(root), capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "ci", "--base", "main", "--json"])
        data = json.loads(result.output)

        assert data["verdict"] == "UNSAFE"
        assert data["exit_code"] == 1
        # Find file with violations
        has_violations = False
        for f in data["files"]:
            for v in f.get("violations", []):
                has_violations = True
                assert "severity" in v
                assert "message" in v
                assert v["severity"] in ("critical", "high", "medium", "low", "info")
        assert has_violations, "Breaking change should produce at least one violation"

    def test_fail_on_caution(self, git_project):
        """--fail-on caution exits 1 even for medium-severity violations."""
        root = git_project
        core = root / "mypkg" / "core.py"
        # A safe addition won't trigger caution, so test that safe change + caution flag = exit 0
        content = core.read_text(encoding="utf-8")
        core.write_text(content + "\ndef helper():\n    pass\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
        subprocess.run(["git", "commit", "-m", "safe"], cwd=str(root), capture_output=True)

        runner = CliRunner()
        result = runner.invoke(cli, ["--repo", str(root), "ci", "--base", "main", "--fail-on", "caution"])
        assert result.exit_code == 0, f"Safe change should exit 0 even with --fail-on caution: {result.output}"
