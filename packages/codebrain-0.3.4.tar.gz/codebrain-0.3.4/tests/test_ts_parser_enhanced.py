"""Tests for enhanced TypeScript/JavaScript parser features."""

from __future__ import annotations

from pathlib import Path

import pytest

from codebrain.parser.typescript_parser import parse_typescript_file


def _write_and_parse(tmp_path: Path, code: str, filename: str = "test.ts") -> "ParsedFile":
    p = tmp_path / filename
    p.write_text(code, encoding="utf-8")
    return parse_typescript_file(p, tmp_path)


class TestReExports:
    def test_named_reexport(self, tmp_path: Path) -> None:
        code = 'export { formatDate, parseDate } from "./utils/date";\n'
        pf = _write_and_parse(tmp_path, code)
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        targets = [e.target for e in imports]
        assert "./utils/date" in targets
        assert "./utils/date.formatDate" in targets
        assert "./utils/date.parseDate" in targets
        # re-exported names should be nodes
        names = [n.name for n in pf.nodes]
        assert "formatDate" in names
        assert "parseDate" in names
        # They should be exported
        fmt_node = [n for n in pf.nodes if n.name == "formatDate"][0]
        assert fmt_node.is_exported is True
        assert "re-export" in fmt_node.decorators

    def test_star_reexport(self, tmp_path: Path) -> None:
        code = 'export * from "./constants";\n'
        pf = _write_and_parse(tmp_path, code)
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        assert any("./constants" in e.target for e in imports)

    def test_default_as_reexport(self, tmp_path: Path) -> None:
        code = 'export { default as MainComponent } from "./MainComponent";\n'
        pf = _write_and_parse(tmp_path, code)
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        targets = [e.target for e in imports]
        assert "./MainComponent.default" in targets
        names = [n.name for n in pf.nodes]
        assert "MainComponent" in names

    def test_star_as_reexport(self, tmp_path: Path) -> None:
        code = 'export * as types from "./types";\n'
        pf = _write_and_parse(tmp_path, code)
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        assert any("./types" in e.target for e in imports)
        names = [n.name for n in pf.nodes]
        assert "types" in names

    def test_type_reexport(self, tmp_path: Path) -> None:
        code = 'export type { Config, Options } from "./config";\n'
        pf = _write_and_parse(tmp_path, code)
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        targets = [e.target for e in imports]
        assert "./config" in targets
        assert "./config.Config" in targets


class TestTypeImports:
    def test_type_import(self, tmp_path: Path) -> None:
        code = 'import type { User, Role } from "./types";\n'
        pf = _write_and_parse(tmp_path, code)
        imports = [e for e in pf.edges if e.type == "IMPORTS"]
        targets = [e.target for e in imports]
        assert "./types.User" in targets
        assert "./types.Role" in targets


class TestDecorators:
    def test_class_decorators(self, tmp_path: Path) -> None:
        code = "@Injectable()\n@Singleton\nclass UserService {\n  run() { }\n}\n"
        pf = _write_and_parse(tmp_path, code)
        cls = [n for n in pf.nodes if n.name == "UserService"][0]
        assert "Injectable" in cls.decorators
        assert "Singleton" in cls.decorators

    def test_function_decorator(self, tmp_path: Path) -> None:
        code = "@log\nexport function doWork() {\n  return 1;\n}\n"
        pf = _write_and_parse(tmp_path, code)
        func = [n for n in pf.nodes if n.name == "doWork"][0]
        assert "log" in func.decorators

    def test_arrow_decorator(self, tmp_path: Path) -> None:
        code = "@memoize\nconst compute = (x: number) => x * 2;\n"
        pf = _write_and_parse(tmp_path, code)
        func = [n for n in pf.nodes if n.name == "compute"][0]
        assert "memoize" in func.decorators


class TestNamespaces:
    def test_namespace_declaration(self, tmp_path: Path) -> None:
        code = "export namespace Validators {\n  export function isEmail(s: string): boolean {\n    return s.includes('@');\n  }\n}\n"
        pf = _write_and_parse(tmp_path, code)
        ns = [n for n in pf.nodes if n.name == "Validators"][0]
        assert "namespace" in ns.decorators
        assert ns.is_exported is True
        # Should find nested function
        names = [n.name for n in pf.nodes]
        assert "isEmail" in names

    def test_namespace_with_interface(self, tmp_path: Path) -> None:
        code = "namespace MyNS {\n  interface Foo {\n    bar: string;\n  }\n}\n"
        pf = _write_and_parse(tmp_path, code)
        names = [n.name for n in pf.nodes]
        assert "MyNS" in names
        assert "Foo" in names

    def test_module_declaration(self, tmp_path: Path) -> None:
        code = 'declare module "my-lib" {\n  function init(): void;\n}\n'
        pf = _write_and_parse(tmp_path, code)
        # We just care it doesn't crash and finds something
        names = [n.name for n in pf.nodes]
        # Module name might be captured differently but shouldn't crash
        assert len(pf.nodes) >= 1


class TestNestedFunctions:
    def test_nested_function_in_function(self, tmp_path: Path) -> None:
        code = "function outer(x: number) {\n  function inner(y: number) {\n    return x + y;\n  }\n  return inner(x);\n}\n"
        pf = _write_and_parse(tmp_path, code)
        names = [n.name for n in pf.nodes]
        assert "outer" in names
        assert "inner" in names

    def test_nested_arrow_in_function(self, tmp_path: Path) -> None:
        code = "function process(items: string[]) {\n  const transform = (s: string) => s.toUpperCase();\n  return items.map(transform);\n}\n"
        pf = _write_and_parse(tmp_path, code)
        names = [n.name for n in pf.nodes]
        assert "process" in names
        assert "transform" in names


class TestObjectMethods:
    def test_object_shorthand_methods(self, tmp_path: Path) -> None:
        code = "const utils = {\n  greet(name: string) {\n    return 'Hello ' + name;\n  },\n  farewell(name: string) {\n    return 'Bye ' + name;\n  },\n};\n"
        pf = _write_and_parse(tmp_path, code)
        names = [n.name for n in pf.nodes]
        assert "greet" in names
        assert "farewell" in names

    def test_object_arrow_methods(self, tmp_path: Path) -> None:
        code = "const api = {\n  fetch: (url: string) => fetch(url),\n  post: async (url: string) => fetch(url),\n};\n"
        pf = _write_and_parse(tmp_path, code)
        names = [n.name for n in pf.nodes]
        # fetch and post should be found as methods
        method_nodes = [n for n in pf.nodes if n.type == "method"]
        method_names = [n.name for n in method_nodes]
        assert "post" in method_names


class TestNestedGenerics:
    def test_nested_angle_brackets(self, tmp_path: Path) -> None:
        """The parser should not break on <T extends Array<U>>."""
        code = "function process<T extends Array<U>, U>(items: T): U[] {\n  return items.flat();\n}\n"
        pf = _write_and_parse(tmp_path, code)
        names = [n.name for n in pf.nodes]
        assert "process" in names


class TestSymbolCount:
    def test_realistic_file_symbol_count(self, tmp_path: Path) -> None:
        """A realistic TS file should yield 10+ symbols."""
        code = '''
import { useState, useEffect } from "react";
import type { User } from "./types";

export { formatDate } from "./utils";
export * from "./constants";

export interface UserProps {
  user: User;
  onUpdate: (u: User) => void;
}

export type ID = string | number;

export enum Status {
  Active,
  Inactive,
}

@Component
export class UserCard {
  render() {
    return null;
  }
}

export function useUser(id: ID) {
  const [user, setUser] = useState<User | null>(null);
  function fetchUser() {
    return fetch(`/api/users/${id}`);
  }
  useEffect(() => { fetchUser(); }, [id]);
  return user;
}

export const UserList = ({ users }: { users: User[] }) => {
  return users.map(u => u.name);
};

const helpers = {
  format(user: User) {
    return user.name;
  },
  validate: (user: User) => !!user.name,
};
'''
        pf = _write_and_parse(tmp_path, code)
        # Count non-file nodes
        symbols = [n for n in pf.nodes if n.type != "file"]
        print(f"Symbol count: {len(symbols)}")
        for s in symbols:
            print(f"  {s.type:10s} {s.name}")
        assert len(symbols) >= 10, f"Expected 10+ symbols, got {len(symbols)}: {[s.name for s in symbols]}"
