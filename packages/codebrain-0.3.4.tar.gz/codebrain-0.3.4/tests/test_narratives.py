"""M5: Narratives that actually help — relative comparisons, not raw numbers.

Tests that narratives contain comparison language and don't just restate data.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.graph.query import QueryEngine
from codebrain.comprehension import ComprehensionEngine
from codebrain.indexer import full_index

REPO_ROOT = Path(__file__).parent.parent

# Words that indicate relative comparisons or recommendations
RELATIVE_WORDS = re.compile(
    r"(average|ranked|most|highest|lowest|backbone|foundational|load-bearing|"
    r"low-risk|high|moderate|critical|lightweight|\d+%|grade|small|medium|large|"
    r"depended-on|blast radius|extreme care|safe|good shape|aim for)",
    re.IGNORECASE,
)


@pytest.fixture(scope="module")
def indexed_db(tmp_path_factory):
    db_path = tmp_path_factory.mktemp("m5") / "codebrain.db"
    full_index(REPO_ROOT, db_path)
    return db_path


class TestSystemNarrative:

    def test_contains_size_characterization(self, indexed_db):
        """system_narrative should characterize the codebase size."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.system_narrative()

        summary = result["summary"]
        assert any(w in summary for w in ("small", "medium-sized", "large")), (
            f"Summary should characterize size: {summary}"
        )

    def test_identifies_backbone(self, indexed_db):
        """system_narrative should identify backbone modules."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.system_narrative()

        assert "backbone" in result["summary"].lower(), (
            f"Summary should mention backbone: {result['summary']}"
        )

    def test_health_has_relative_context(self, indexed_db):
        """Health summary should have relative context, not just raw numbers."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.system_narrative()

        health = result["health_summary"]
        assert RELATIVE_WORDS.search(health), (
            f"Health summary should use relative language: {health}"
        )

    def test_key_components_have_percentage(self, indexed_db):
        """Key components should show blast radius as percentage."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.system_narrative()

        if result["key_components"]:
            first = result["key_components"][0]
            assert "%" in first["why"], (
                f"Key component why should include percentage: {first['why']}"
            )


class TestModuleNarrative:

    def test_contains_relative_comparison(self, indexed_db):
        """module_narrative should compare to codebase average."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.module_narrative("codebrain/mcp_server.py")

        assert "error" not in result
        # Should contain average or ranked or similar comparative language
        combined = " ".join(str(v) for v in result.values())
        assert RELATIVE_WORDS.search(combined), (
            f"Module narrative should use relative language: {combined}"
        )

    def test_importance_has_rank(self, indexed_db):
        """High-importance modules should show rank."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.module_narrative("codebrain/graph/store.py")

        importance = result.get("importance", "")
        # store.py is heavily depended on, should have ranking info
        assert RELATIVE_WORDS.search(importance), (
            f"Importance should use relative language: {importance}"
        )

    def test_no_dependents_module_says_low_risk(self, indexed_db):
        """Modules with no dependents should say low-risk."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            # config.py or settings.py typically has few dependents
            result = comp.module_narrative("codebrain/settings.py")

        if "error" not in result:
            importance = result.get("importance", "")
            # Should indicate low importance or few dependents
            assert any(w in importance.lower() for w in ("low", "no other", "ranked")), (
                f"Low-dependency module should indicate low risk: {importance}"
            )


class TestSymbolNarrative:

    def test_blast_radius_percentage(self, indexed_db):
        """symbol_narrative should include blast radius as percentage."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.symbol_narrative("codebrain/graph/store.py::GraphStore.get_node")

        if "error" not in result:
            importance = result.get("importance", "")
            assert "%" in importance, (
                f"Symbol importance should include percentage: {importance}"
            )

    def test_importance_always_has_context(self, indexed_db):
        """Symbol importance should always have relative context (% or risk level)."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.symbol_narrative("codebrain/config.py::CODEBRAIN_DIR")

        if "error" not in result:
            importance = result.get("importance", "")
            assert RELATIVE_WORDS.search(importance), (
                f"Importance should have relative context: {importance}"
            )


class TestNoRawNumberRestating:
    """Verify narratives don't just restate raw numbers."""

    def test_module_not_just_counts(self, indexed_db):
        """Module narrative should not just say 'has N symbols'."""
        with GraphStore(indexed_db) as store:
            comp = ComprehensionEngine(store)
            result = comp.module_narrative("codebrain/graph/store.py")

        if "error" not in result:
            summary = result.get("summary", "")
            # It should add context beyond just counts
            assert RELATIVE_WORDS.search(summary) or "class" in summary or "function" in summary, (
                f"Summary should have context beyond raw counts: {summary}"
            )
