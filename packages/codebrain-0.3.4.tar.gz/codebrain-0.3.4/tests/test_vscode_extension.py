"""VS Code extension validation tests.

Tests the extension from the outside by:
1. Verifying TypeScript compilation
2. Testing CLI commands that the extension calls
3. Validating JSON output format matches what the extension expects
4. Checking that all registered commands exist in package.json

No actual VS Code runtime needed — these tests verify the contract
between the extension and the CodeBrain CLI.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index

VSCODE_DIR = Path(__file__).parent.parent / "vscode-extension"


# ---------------------------------------------------------------------------
# Extension Structure
# ---------------------------------------------------------------------------

class TestExtensionStructure:
    """Verify the extension is correctly structured."""

    def test_package_json_exists(self):
        assert (VSCODE_DIR / "package.json").is_file()

    def test_source_exists(self):
        assert (VSCODE_DIR / "src" / "extension.ts").is_file()

    def test_package_json_valid(self):
        data = json.loads((VSCODE_DIR / "package.json").read_text(encoding="utf-8"))
        assert data["name"] == "codebrain"
        assert "version" in data
        assert "activationEvents" in data or "main" in data

    def test_commands_registered(self):
        """All 5 commands should be in package.json."""
        data = json.loads((VSCODE_DIR / "package.json").read_text(encoding="utf-8"))
        commands = [c["command"] for c in data.get("contributes", {}).get("commands", [])]
        expected = [
            "codebrain.impact",
            "codebrain.context",
            "codebrain.search",
            "codebrain.validate",
            "codebrain.hotspots",
        ]
        for cmd in expected:
            assert cmd in commands, f"Command {cmd} not in package.json"

    def test_settings_registered(self):
        """Extension settings should be in package.json."""
        data = json.loads((VSCODE_DIR / "package.json").read_text(encoding="utf-8"))
        props = data.get("contributes", {}).get("configuration", {}).get("properties", {})
        assert "codebrain.validateOnSave" in props
        assert "codebrain.brainPath" in props

    def test_typescript_compiles(self):
        """Extension should compile without errors."""
        # Use shell=True on Windows for npx to resolve properly
        import platform
        use_shell = platform.system() == "Windows"
        result = subprocess.run(
            "npx tsc --noEmit",
            cwd=str(VSCODE_DIR),
            capture_output=True,
            text=True,
            timeout=60,
            shell=use_shell,
        )
        assert result.returncode == 0, f"TypeScript errors:\n{result.stdout}\n{result.stderr}"


# ---------------------------------------------------------------------------
# CLI Contract Tests — verify the JSON output format
# ---------------------------------------------------------------------------

class TestCLIContractForExtension:
    """The extension expects specific JSON shapes from CLI commands.
    Verify these contracts are met."""

    @pytest.fixture(scope="class")
    def indexed_db(self, tmp_path_factory):
        """Create a simple indexed project with .codebrain/graph.db."""
        tmp = tmp_path_factory.mktemp("vscode_test")
        project = tmp / "project"
        project.mkdir()
        (project / "main.py").write_text(
            "def process_data(items: list) -> dict:\n"
            "    return {i: len(i) for i in items}\n\n"
            "class DataProcessor:\n"
            "    def run(self):\n"
            "        return process_data([])\n",
            encoding="utf-8",
        )
        # CLI expects .codebrain/graph.db at repo root
        cb_dir = project / ".codebrain"
        cb_dir.mkdir()
        db = cb_dir / "graph.db"
        full_index(project, db)
        return {"project": project, "db": db}

    def test_search_returns_list(self, indexed_db):
        """brain search X --json should return a list of nodes."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain",
             "--repo", str(indexed_db["project"]),
             "search", "process", "--json"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0, f"Error: {result.stderr}"
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        if data:
            node = data[0]
            assert "name" in node
            assert "file_path" in node
            assert "line_start" in node
            assert "type" in node

    def test_impact_returns_json(self, indexed_db):
        """brain impact X --json should return structured impact data."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain",
             "--repo", str(indexed_db["project"]),
             "impact", "process_data", "--json"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0, f"Error: {result.stderr}"
        data = json.loads(result.stdout)
        assert isinstance(data, (list, dict))

    def test_hotspots_returns_list(self, indexed_db):
        """brain hotspots --json should return a list."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain",
             "--repo", str(indexed_db["project"]),
             "hotspots", "--top", "5", "--json"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0, f"Error: {result.stderr}"
        data = json.loads(result.stdout)
        assert isinstance(data, list)

    def test_validate_returns_json(self, indexed_db):
        """brain validate X --json should return validation result."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain",
             "--repo", str(indexed_db["project"]),
             "validate", "main.py", "--json"],
            capture_output=True, text=True, timeout=30,
        )
        # May return 0 (valid) or non-zero (violations found)
        output = result.stdout or result.stderr
        try:
            data = json.loads(output)
            # Should have at least these fields that the extension checks
            assert isinstance(data, dict)
        except json.JSONDecodeError:
            # Some validate outputs aren't JSON — that's a known gap
            pass

    def test_context_returns_json(self, indexed_db):
        """brain context X --json should return context data."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain",
             "--repo", str(indexed_db["project"]),
             "context", "process_data", "--json"],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0, f"Error: {result.stderr}"
        data = json.loads(result.stdout)
        assert isinstance(data, (dict, list))

    def test_search_json_has_extension_fields(self, indexed_db):
        """Extension expects: name, type, file_path, line_start, signature, docstring."""
        result = subprocess.run(
            [sys.executable, "-m", "codebrain",
             "--repo", str(indexed_db["project"]),
             "search", "DataProcessor", "--json"],
            capture_output=True, text=True, timeout=30,
        )
        data = json.loads(result.stdout)
        assert len(data) > 0, "No results for DataProcessor"
        node = data[0]
        # These fields are used by the extension's search command
        assert "name" in node
        assert "type" in node
        assert "file_path" in node
        assert "line_start" in node

    def test_validate_json_has_violations_field(self, indexed_db):
        """Extension expects data.violations to be an array."""
        # Create a file with a removed function to trigger validation
        project = indexed_db["project"]
        (project / "test_file.py").write_text(
            "# This file exists but we validate main.py\n",
            encoding="utf-8",
        )
        result = subprocess.run(
            [sys.executable, "-m", "codebrain",
             "--repo", str(project),
             "validate", "main.py", "--json"],
            capture_output=True, text=True, timeout=30,
        )
        output = result.stdout or result.stderr
        try:
            data = json.loads(output)
            if "violations" in data:
                assert isinstance(data["violations"], list)
            if "is_valid" in data:
                assert isinstance(data["is_valid"], bool)
        except json.JSONDecodeError:
            pass  # Not all validate outputs are JSON


# ---------------------------------------------------------------------------
# Extension Source Code Quality
# ---------------------------------------------------------------------------

class TestExtensionCodeQuality:
    """Static checks on the extension source code."""

    @pytest.fixture
    def source(self):
        return (VSCODE_DIR / "src" / "extension.ts").read_text(encoding="utf-8")

    def test_xss_protection(self, source):
        """Should use escapeHtml for all user data."""
        assert "escapeHtml" in source

    def test_no_eval(self, source):
        """Should never use eval()."""
        assert "eval(" not in source

    def test_no_shell_true(self, source):
        """Should not use shell: true (command injection risk)."""
        assert "shell: true" not in source
        assert "shell:true" not in source

    def test_async_validate(self, source):
        """validateFile should use async execFile, not execFileSync."""
        # Find the validateFile function and verify it uses execFile (async)
        idx = source.index("function validateFile")
        func_body = source[idx:idx+500]
        assert "execFile(" in func_body
        assert "execFileSync" not in func_body

    def test_timeout_set(self, source):
        """All exec calls should have a timeout."""
        # Count exec calls and timeout settings
        exec_count = source.count("execFileSync(") + source.count("execFile(")
        timeout_count = source.count("timeout:")
        assert timeout_count >= exec_count, \
            f"Found {exec_count} exec calls but only {timeout_count} timeouts"

    def test_error_handling(self, source):
        """All try blocks should have catch blocks."""
        try_count = source.count("try {")
        catch_count = source.count("catch")
        assert catch_count >= try_count

    def test_html_escaping_complete(self, source):
        """escapeHtml should handle all major XSS vectors."""
        assert "&amp;" in source  # &
        assert "&lt;" in source   # <
        assert "&gt;" in source   # >
        assert "&quot;" in source # "
