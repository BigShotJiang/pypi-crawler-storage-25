"""Real-codebase validation for M32 (architecture) and M33 (schema/ORM/infra).

Indexes CodeBrain's own repo and validates detection results against
known ground truth. No mocks, no synthetic data — the actual codebase.

CodeBrain is a Python project using:
- FastAPI (api.py)
- Click CLI (cli.py)
- FastMCP (mcp_server.py)
- SQLite via custom GraphStore (no ORM)
- pytest for testing
- No Docker/K8s/Terraform in main source

These tests verify M32/M33 produce correct results on real code.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from codebrain.architecture import ArchitectureDetector, ArchitectureReport
from codebrain.graph.store import GraphStore
from codebrain.indexer import full_index
from codebrain.test_gaps import TestCoverageAnalyzer

# CodeBrain's own source directory
CODEBRAIN_ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def indexed_store():
    """Index CodeBrain's own source into a fresh DB."""
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "test.db"
        full_index(CODEBRAIN_ROOT, db_path)
        with GraphStore(db_path) as store:
            yield store


@pytest.fixture(scope="module")
def report(indexed_store) -> ArchitectureReport:
    """Run architecture detection on CodeBrain's indexed graph."""
    detector = ArchitectureDetector(indexed_store)
    return detector.detect()


# ── M32: Architecture Detection on Real Code ────────────────────────────────


class TestRealArchitectureDetection:
    """Validate M32 architecture detection against CodeBrain's known structure."""

    def test_detects_fastapi_framework(self, report):
        """CodeBrain uses FastAPI — must be detected."""
        assert "fastapi" in report.frameworks

    def test_detects_click_framework(self, report):
        """CodeBrain uses Click CLI — must be detected."""
        assert "click" in report.frameworks

    def test_detects_pytest_framework(self, report):
        """CodeBrain uses pytest — should be in evidence or frameworks."""
        all_evidence = " ".join(report.framework_evidence).lower()
        has_pytest = "pytest" in report.frameworks or "pytest" in all_evidence
        assert has_pytest

    def test_pattern_is_not_empty(self, report):
        """Must detect some architectural pattern."""
        assert report.pattern != ""

    def test_pattern_is_reasonable(self, report):
        """CodeBrain is layered (graph/store → query → analyzer → cli/api/mcp).
        Should detect layered or repository_service, not MVC."""
        assert report.pattern in ("layered", "repository_service", "monolith", "mvc")

    def test_no_db_orm_detected(self, report):
        """CodeBrain uses raw SQLite (GraphStore), not an ORM.
        db_technology should be empty or 'sqlite' — NOT sqlalchemy/django."""
        if report.db_technology:
            assert report.db_technology not in ("sqlalchemy", "django_orm")

    def test_module_roles_assigned(self, report):
        """Must assign roles to modules."""
        assert len(report.module_roles) > 0

    def test_api_module_has_api_role(self, report):
        """api.py should be detected as api_layer."""
        api_roles = {
            path: role
            for path, role in report.module_roles.items()
            if "api.py" in path and "test" not in path
        }
        assert len(api_roles) > 0
        # At least one api.py file should have api_layer role
        assert any(r == "api_layer" for r in api_roles.values())

    def test_layers_detected(self, report):
        """CodeBrain has clear layers — should detect some."""
        assert len(report.layers) >= 2

    def test_no_false_docker_infra(self, report):
        """CodeBrain has no Dockerfile in source — should not detect Docker infra."""
        docker_infra = [
            i for i in report.infrastructure
            if "docker" in i.lower()
        ]
        # We have no Dockerfile, so this should be empty
        # (unless someone added one — test will catch that change)
        assert len(docker_infra) <= 1  # test fixtures may reference Docker

    def test_report_narrative_not_empty(self, report):
        """Narrative should produce readable output."""
        narrative = report.narrative()
        assert len(narrative) > 100
        assert "pattern" in narrative.lower() or "architecture" in narrative.lower()

    def test_report_to_dict_serializable(self, report):
        """to_dict() must produce a clean dict (for JSON output)."""
        d = report.to_dict()
        assert isinstance(d, dict)
        assert "pattern" in d
        assert "frameworks" in d
        assert isinstance(d["frameworks"], list)

    def test_framework_evidence_has_details(self, report):
        """Evidence should explain why frameworks were detected."""
        assert len(report.framework_evidence) > 0
        # Evidence strings should mention actual files or imports
        evidence_text = " ".join(report.framework_evidence)
        assert len(evidence_text) > 20


class TestRealPatternEvidence:
    """Validate pattern detection evidence is substantive."""

    def test_pattern_evidence_not_empty(self, report):
        """Pattern detection should provide evidence."""
        assert len(report.pattern_evidence) > 0

    def test_pattern_confidence_reasonable(self, report):
        """Confidence should be > 0 for any detected pattern."""
        assert report.pattern_confidence > 0.0


# ── M23: Test Coverage Gaps on Real Code ────────────────────────────────────


class TestRealTestCoverageGaps:
    """Validate test-gaps analysis on CodeBrain's own test suite."""

    def test_coverage_report_structure(self, indexed_store):
        """Analyzer should produce a valid report."""
        analyzer = TestCoverageAnalyzer(indexed_store)
        report = analyzer.analyze()
        assert report.total_production_symbols > 0
        assert report.coverage_percent >= 0.0
        assert report.coverage_percent <= 100.0

    def test_has_tested_symbols(self, indexed_store):
        """CodeBrain has 800+ tests — many symbols should be marked tested."""
        analyzer = TestCoverageAnalyzer(indexed_store)
        report = analyzer.analyze()
        assert report.tested_symbols > 0

    def test_coverage_not_zero(self, indexed_store):
        """With 800+ tests, coverage should not be 0%."""
        analyzer = TestCoverageAnalyzer(indexed_store)
        report = analyzer.analyze()
        assert report.coverage_percent > 0.0

    def test_gaps_have_risk_scores(self, indexed_store):
        """Untested symbols should have risk scores."""
        analyzer = TestCoverageAnalyzer(indexed_store)
        report = analyzer.analyze()
        if report.gaps:
            # At least some gaps should have non-zero risk
            scored_gaps = [g for g in report.gaps if g.risk_score > 0.0]
            assert len(scored_gaps) > 0

    def test_narrative_mentions_coverage(self, indexed_store):
        """Narrative should mention coverage percentage."""
        analyzer = TestCoverageAnalyzer(indexed_store)
        report = analyzer.analyze()
        assert "%" in report.narrative or "coverage" in report.narrative.lower()


# ── Sanity: Index Quality ───────────────────────────────────────────────────


class TestIndexQuality:
    """Verify the index itself is reasonable before trusting analysis."""

    def test_enough_nodes_indexed(self, indexed_store):
        """CodeBrain has 30+ Python files — should produce many nodes."""
        nodes = indexed_store.get_all_nodes()
        assert len(nodes) > 200  # conservative lower bound

    def test_enough_edges_indexed(self, indexed_store):
        """Should have CALLS, IMPORTS, CONTAINS edges."""
        edges = indexed_store.get_all_edges()
        assert len(edges) > 100

    def test_key_files_present(self, indexed_store):
        """Core files must be in the graph."""
        nodes = indexed_store.get_all_nodes()
        file_paths = {n.get("file_path", "") for n in nodes}
        # Normalize to forward slashes for comparison
        normalized = {p.replace("\\", "/") for p in file_paths}

        key_files = ["cli.py", "api.py", "mcp_server.py", "architecture.py"]
        for kf in key_files:
            found = any(p.endswith(f"codebrain/{kf}") for p in normalized)
            assert found, f"{kf} not found in indexed files"

    def test_edge_types_present(self, indexed_store):
        """Should have diverse edge types."""
        edges = indexed_store.get_all_edges()
        edge_types = {e.get("type", "") for e in edges}
        assert "CALLS" in edge_types
        assert "IMPORTS" in edge_types
