"""End-to-end CodeBrain tests on the JyotishyaMitra project (~1300 files).

Validates that all CodeBrain features work correctly on a real, large,
mixed Python+TypeScript codebase.
"""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.analyzer import StructuralAnalyzer
from codebrain.validator import ChangeValidator

import os

# Set CODEBRAIN_TEST_REPO to point at a large indexed codebase for real-world tests.
# Falls back to JyotishyaMitra default path if not set.
REPO = Path(os.environ.get(
    "CODEBRAIN_TEST_REPO",
    r"C:\Users\ASUS\PycharmProjects\JyotishyaMitra",
))
DB = REPO / ".codebrain" / "codebrain.db"

pytestmark = pytest.mark.skipif(
    not DB.exists(), reason="Real-world test repo not indexed (set CODEBRAIN_TEST_REPO)"
)


@pytest.fixture(scope="module")
def store():
    with GraphStore(DB) as s:
        yield s


@pytest.fixture(scope="module")
def engine(store):
    return QueryEngine(store)


@pytest.fixture(scope="module")
def comp(store):
    return ComprehensionEngine(store)


@pytest.fixture(scope="module")
def analyzer(store):
    return StructuralAnalyzer(store)


# ── Basic stats ──────────────────────────────────────────────────────────────

class TestBasicStats:

    def test_files_indexed(self, store):
        stats = store.get_stats()
        assert stats["files"] > 1000, f"Expected 1000+ files, got {stats['files']}"

    def test_nodes_exist(self, store):
        stats = store.get_stats()
        assert stats["nodes"] > 10000

    def test_edges_exist(self, store):
        stats = store.get_stats()
        assert stats["edges"] > 50000

    def test_node_types(self, store):
        stats = store.get_stats()
        types = stats["node_types"]
        assert "function" in types
        assert "class" in types

    def test_edge_types(self, store):
        stats = store.get_stats()
        types = stats["edge_types"]
        assert "CALLS" in types
        assert "IMPORTS" in types
        assert "CONTAINS" in types


# ── Search ───────────────────────────────────────────────────────────────────

class TestSearch:

    def test_search_finds_symbols(self, engine):
        results = engine.search_nodes("calculate")
        assert len(results) > 0

    def test_search_returns_structured_data(self, engine):
        results = engine.search_nodes("api")
        assert len(results) > 0
        for r in results[:5]:
            assert "id" in r
            assert "name" in r
            assert "type" in r
            assert "file_path" in r

    def test_search_empty_returns_empty(self, engine):
        results = engine.search_nodes("zzz_nonexistent_symbol_xyz_999")
        assert len(results) == 0


# ── Impact Analysis ──────────────────────────────────────────────────────────

class TestImpactAnalysis:

    def test_impact_returns_results(self, engine):
        nodes = engine.search_nodes("calculate")
        assert nodes, "No 'calculate' symbols found"
        impact = engine.impact_of_change(nodes[0]["id"])
        # Should return a list (possibly empty for leaf nodes)
        assert isinstance(impact, list)

    def test_impact_under_5s(self, engine):
        nodes = engine.search_nodes("calculate")
        assert nodes
        start = time.perf_counter()
        engine.impact_of_change(nodes[0]["id"])
        elapsed = time.perf_counter() - start
        assert elapsed < 5.0, f"Impact took {elapsed:.2f}s"


# ── Call Chain ───────────────────────────────────────────────────────────────

class TestCallChain:

    def test_call_chain_returns_results(self, engine):
        nodes = engine.search_nodes("calculate")
        assert nodes
        chain = engine.get_call_chain(nodes[0]["id"], max_depth=3)
        assert isinstance(chain, list)

    def test_call_chain_under_5s(self, engine):
        nodes = engine.search_nodes("calculate")
        assert nodes
        start = time.perf_counter()
        engine.get_call_chain(nodes[0]["id"], max_depth=3)
        elapsed = time.perf_counter() - start
        assert elapsed < 5.0


# ── Dead Code ────────────────────────────────────────────────────────────────

class TestDeadCode:

    def test_dead_code_returns_results(self, engine):
        dead = engine.find_dead_code()
        assert isinstance(dead, list)
        assert len(dead) > 0, "Expected some dead code in a 1300-file project"

    def test_dead_code_has_confidence(self, engine):
        dead = engine.find_dead_code()
        for d in dead[:10]:
            assert "confidence" in d, f"Missing confidence on {d}"
            assert d["confidence"] in ("high", "medium", "low")

    def test_dead_code_under_10s(self, engine):
        start = time.perf_counter()
        engine.find_dead_code()
        elapsed = time.perf_counter() - start
        assert elapsed < 10.0


# ── Import Cycles ────────────────────────────────────────────────────────────

class TestCycles:

    def test_detect_cycles(self, engine):
        cycles = engine.detect_cycles()
        assert isinstance(cycles, list)


# ── Comprehension ────────────────────────────────────────────────────────────

class TestComprehension:

    def test_system_overview(self, comp):
        overview = comp.system_overview()
        assert "stats" in overview
        assert "packages" in overview
        assert overview["stats"]["files"] > 1000

    def test_system_narrative(self, comp):
        narrative = comp.system_narrative()
        # May return str or dict depending on implementation
        assert narrative is not None
        if isinstance(narrative, str):
            assert len(narrative) > 50
        else:
            assert isinstance(narrative, dict)

    def test_module_view(self, comp, store):
        nodes = store.get_all_nodes(type_filter="function")
        assert nodes
        view = comp.module_view(nodes[0]["file_path"])
        assert "symbols" in view or "nodes" in view

    def test_module_narrative(self, comp, store):
        nodes = store.get_all_nodes(type_filter="function")
        assert nodes
        narrative = comp.module_narrative(nodes[0]["file_path"])
        assert narrative is not None

    def test_symbol_narrative(self, comp, engine):
        nodes = engine.search_nodes("calculate")
        assert nodes
        narrative = comp.symbol_narrative(nodes[0]["id"])
        assert narrative is not None

    def test_risk_hotspots(self, comp):
        hotspots = comp.risk_hotspots(top_n=10)
        assert len(hotspots) > 0
        for h in hotspots:
            assert "name" in h

    def test_risk_hotspots_under_10s(self, comp):
        start = time.perf_counter()
        comp.risk_hotspots()
        elapsed = time.perf_counter() - start
        assert elapsed < 10.0

    def test_health_score(self, comp):
        health = comp.health_score()
        assert 0 <= health["score"] <= 100

    def test_codebase_anatomy(self, comp):
        anatomy = comp.codebase_anatomy()
        assert isinstance(anatomy, dict)

    def test_dependency_map(self, comp):
        dep_map = comp.dependency_map()
        assert isinstance(dep_map, dict)


# ── Zoom ─────────────────────────────────────────────────────────────────────

class TestZoom:

    def test_zoom_system(self, comp):
        z = comp.zoom()
        assert isinstance(z, dict)

    def test_zoom_package(self, comp):
        overview = comp.system_overview()
        pkgs = overview.get("packages", {})
        if not pkgs:
            pytest.skip("No packages")
        # packages may be dict (name->data) or list
        if isinstance(pkgs, dict):
            name = next(iter(pkgs))
        elif isinstance(pkgs, list):
            pkg = pkgs[0]
            name = pkg if isinstance(pkg, str) else pkg.get("name", pkg.get("package", ""))
        else:
            pytest.skip("Unexpected packages format")
        z = comp.zoom(name)
        assert isinstance(z, dict)

    def test_zoom_module(self, comp, store):
        nodes = store.get_all_nodes(type_filter="function")
        assert nodes
        z = comp.zoom(nodes[0]["file_path"])
        assert isinstance(z, dict)


# ── Answer Questions ─────────────────────────────────────────────────────────

class TestAnswerQuestion:

    def test_overview_question(self, comp):
        answer = comp.answer_question("What is this codebase about?")
        assert isinstance(answer, dict)

    def test_risk_question(self, comp):
        answer = comp.answer_question("What are the riskiest files?")
        assert isinstance(answer, dict)

    def test_health_question(self, comp):
        answer = comp.answer_question("What's the health score?")
        assert isinstance(answer, dict)

    def test_dead_code_question(self, comp):
        answer = comp.answer_question("Is there any dead code?")
        assert isinstance(answer, dict)

    def test_cycle_question(self, comp):
        answer = comp.answer_question("Are there circular imports?")
        assert isinstance(answer, dict)


# ── Analyzer ─────────────────────────────────────────────────────────────────

class TestAnalyzer:

    def test_detect_contracts(self, analyzer):
        contracts = analyzer.detect_contracts()
        assert isinstance(contracts, list)

    def test_module_coupling(self, analyzer):
        if hasattr(analyzer, "module_coupling"):
            coupling = analyzer.module_coupling()
        elif hasattr(analyzer, "coupling_analysis"):
            coupling = analyzer.coupling_analysis()
        else:
            coupling = analyzer.detect_coupling()
        assert coupling is not None
        # May return list or dict with pairs
        if isinstance(coupling, dict):
            assert "pairs" in coupling

    def test_architectural_layers(self, analyzer):
        if hasattr(analyzer, "architectural_layers"):
            result = analyzer.architectural_layers()
        elif hasattr(analyzer, "detect_layers"):
            result = analyzer.detect_layers()
        else:
            pytest.skip("No layer detection method found")
        assert result is not None
        if isinstance(result, dict):
            assert "layers" in result

    def test_structural_patterns(self, analyzer):
        patterns = analyzer.detect_structural_patterns()
        assert isinstance(patterns, (list, dict))


# ── Validator ────────────────────────────────────────────────────────────────

class TestValidator:

    def test_validate_existing_file(self, store):
        validator = ChangeValidator(store)
        nodes = store.get_all_nodes(type_filter="function")
        assert nodes
        file_path = REPO / nodes[0]["file_path"]
        if file_path.exists():
            result = validator.validate_file(file_path, REPO)
            # Result may be dict, dataclass, or ValidationReport
            assert result is not None
            if hasattr(result, "is_valid"):
                assert isinstance(result.is_valid, bool)
            elif isinstance(result, dict):
                assert "is_valid" in result


# ── Performance ──────────────────────────────────────────────────────────────

class TestPerformance:

    def test_search_under_1s(self, engine):
        start = time.perf_counter()
        engine.search_nodes("api")
        assert time.perf_counter() - start < 1.0

    def test_overview_under_10s(self, comp):
        start = time.perf_counter()
        comp.system_overview()
        assert time.perf_counter() - start < 10.0

    def test_health_under_30s(self, comp):
        start = time.perf_counter()
        comp.health_score()
        assert time.perf_counter() - start < 30.0
