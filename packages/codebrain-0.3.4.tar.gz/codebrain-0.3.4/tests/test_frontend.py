"""Tests for SPEC-M28: Frontend-Aware Modernization Support.

Covers:
- FrontendComponentParser (post-processor): RENDERS, props, routes, state, API calls
- VueParser: SFC parsing, template analysis
- FrontendAnalyzer: component tree, route map, state graph, API surface
- Spec generation: frontend roles, component_info
- Rewrite validation: frontend contracts
"""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_store(tmp_path: Path) -> GraphStore:
    """Create a fresh in-memory-like store."""
    db = tmp_path / ".codebrain" / "graph.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    return GraphStore(db)


def _insert_tsx_project(store: GraphStore, tmp_path: Path) -> None:
    """Insert a small React project into the graph and create source files."""
    # App.tsx — root component
    app_source = textwrap.dedent("""\
        import React from 'react';
        import { BrowserRouter, Route, Routes } from 'react-router-dom';
        import { useSelector, useDispatch } from 'react-redux';
        import HomePage from './HomePage';
        import UserProfile from './UserProfile';

        function App() {
            const user = useSelector(state => state.auth.user);
            const dispatch = useDispatch();

            return (
                <BrowserRouter>
                    <Routes>
                        <Route path="/" component={HomePage} />
                        <Route path="/users/:id" element={<UserProfile />} />
                    </Routes>
                    <HomePage title="Welcome" />
                    <UserProfile userId={user.id} onBack={() => dispatch(goBack())} />
                </BrowserRouter>
            );
        }

        export default App;
    """)

    # HomePage.tsx
    home_source = textwrap.dedent("""\
        import React, { useState } from 'react';
        import UserCard from './UserCard';

        function HomePage({ title }) {
            const [users, setUsers] = useState([]);

            React.useEffect(() => {
                fetch('/api/users').then(r => r.json()).then(setUsers);
            }, []);

            return (
                <div>
                    <h1>{title}</h1>
                    {users.map(u => <UserCard key={u.id} name={u.name} onSelect={() => {}} />)}
                </div>
            );
        }

        export default HomePage;
    """)

    # UserProfile.tsx
    profile_source = textwrap.dedent("""\
        import React from 'react';
        import { useSelector } from 'react-redux';
        import axios from 'axios';
        import UserCard from './UserCard';

        function UserProfile({ userId, onBack }) {
            const user = useSelector(state => state.auth.user);
            const posts = useSelector(state => state.posts.byUser);

            React.useEffect(() => {
                axios.get('/api/users/' + userId);
                axios.get('/api/users/' + userId + '/posts');
            }, [userId]);

            return (
                <div>
                    <UserCard name={user.name} />
                    <button onClick={onBack}>Back</button>
                </div>
            );
        }

        export default UserProfile;
    """)

    # UserCard.tsx — leaf component
    card_source = textwrap.dedent("""\
        import React from 'react';

        function UserCard({ name, onSelect }) {
            return <div onClick={onSelect}>{name}</div>;
        }

        export default UserCard;
    """)

    # Redux store
    store_source = textwrap.dedent("""\
        import { createSlice } from '@reduxjs/toolkit';

        const authSlice = createSlice({
            name: 'auth',
            initialState: { user: null },
            reducers: {
                login: (state, action) => { state.user = action.payload; },
                logout: (state) => { state.user = null; },
            },
        });

        export const { login, logout } = authSlice.actions;
        export default authSlice.reducer;
    """)

    # Write source files
    src = tmp_path / "src"
    src.mkdir(exist_ok=True)
    (src / "App.tsx").write_text(app_source)
    (src / "HomePage.tsx").write_text(home_source)
    (src / "UserProfile.tsx").write_text(profile_source)
    (src / "UserCard.tsx").write_text(card_source)
    (src / "store.ts").write_text(store_source)

    # Insert parsed nodes into graph (simulating TS parser output)
    files_data = [
        # App.tsx
        ParsedFile(
            path="src/App.tsx", content_hash="aaa", line_count=20,
            nodes=[
                ParsedNode(
                    id="src/App.tsx::__module__", name="App",
                    qualified_name="__module__", type="file",
                    file_path="src/App.tsx", line_start=1, line_end=20,
                ),
                ParsedNode(
                    id="src/App.tsx::App", name="App",
                    qualified_name="App", type="function",
                    file_path="src/App.tsx", line_start=7, line_end=20,
                    is_exported=True,
                ),
            ],
            edges=[
                ParsedEdge(source="src/App.tsx::App", target="HomePage", type="CALLS", file_path="src/App.tsx", line=14),
                ParsedEdge(source="src/App.tsx::App", target="UserProfile", type="CALLS", file_path="src/App.tsx", line=15),
            ],
        ),
        # HomePage.tsx
        ParsedFile(
            path="src/HomePage.tsx", content_hash="bbb", line_count=15,
            nodes=[
                ParsedNode(
                    id="src/HomePage.tsx::__module__", name="HomePage",
                    qualified_name="__module__", type="file",
                    file_path="src/HomePage.tsx", line_start=1, line_end=15,
                ),
                ParsedNode(
                    id="src/HomePage.tsx::HomePage", name="HomePage",
                    qualified_name="HomePage", type="function",
                    file_path="src/HomePage.tsx", line_start=4, line_end=15,
                    is_exported=True,
                ),
            ],
            edges=[
                ParsedEdge(source="src/HomePage.tsx::HomePage", target="UserCard", type="CALLS", file_path="src/HomePage.tsx", line=12),
            ],
        ),
        # UserProfile.tsx
        ParsedFile(
            path="src/UserProfile.tsx", content_hash="ccc", line_count=18,
            nodes=[
                ParsedNode(
                    id="src/UserProfile.tsx::__module__", name="UserProfile",
                    qualified_name="__module__", type="file",
                    file_path="src/UserProfile.tsx", line_start=1, line_end=18,
                ),
                ParsedNode(
                    id="src/UserProfile.tsx::UserProfile", name="UserProfile",
                    qualified_name="UserProfile", type="function",
                    file_path="src/UserProfile.tsx", line_start=6, line_end=18,
                    is_exported=True,
                ),
            ],
            edges=[
                ParsedEdge(source="src/UserProfile.tsx::UserProfile", target="UserCard", type="CALLS", file_path="src/UserProfile.tsx", line=15),
            ],
        ),
        # UserCard.tsx
        ParsedFile(
            path="src/UserCard.tsx", content_hash="ddd", line_count=6,
            nodes=[
                ParsedNode(
                    id="src/UserCard.tsx::__module__", name="UserCard",
                    qualified_name="__module__", type="file",
                    file_path="src/UserCard.tsx", line_start=1, line_end=6,
                ),
                ParsedNode(
                    id="src/UserCard.tsx::UserCard", name="UserCard",
                    qualified_name="UserCard", type="function",
                    file_path="src/UserCard.tsx", line_start=3, line_end=5,
                    is_exported=True,
                ),
            ],
            edges=[],
        ),
        # store.ts
        ParsedFile(
            path="src/store.ts", content_hash="eee", line_count=15,
            nodes=[
                ParsedNode(
                    id="src/store.ts::__module__", name="store",
                    qualified_name="__module__", type="file",
                    file_path="src/store.ts", line_start=1, line_end=15,
                ),
                ParsedNode(
                    id="src/store.ts::authSlice", name="authSlice",
                    qualified_name="authSlice", type="variable",
                    file_path="src/store.ts", line_start=3, line_end=12,
                    is_exported=True,
                ),
            ],
            edges=[],
        ),
    ]

    for pf in files_data:
        store.upsert_file(pf)


# ===========================================================================
# Parser tests (10)
# ===========================================================================


class TestFrontendComponentParser:
    """Tests for the post-processor that enriches the graph."""

    def test_detects_react_functional_component(self, tmp_path):
        """PascalCase functions in TSX files are tagged as components."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.components_tagged > 0

        # Check that UserCard is now a component
        node = store.get_node("src/UserCard.tsx::UserCard")
        assert node is not None
        assert node["type"] == "component"
        store.close()

    def test_detects_react_class_component(self, tmp_path):
        """Classes with PascalCase in TSX are tagged as components."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "ClassComp.tsx").write_text("class MyComponent extends React.Component { render() {} }")

        store.upsert_file(ParsedFile(
            path="src/ClassComp.tsx", content_hash="x", line_count=1,
            nodes=[ParsedNode(
                id="src/ClassComp.tsx::MyComponent", name="MyComponent",
                qualified_name="MyComponent", type="class",
                file_path="src/ClassComp.tsx", line_start=1, line_end=1,
                is_exported=True,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        node = store.get_node("src/ClassComp.tsx::MyComponent")
        assert node["type"] == "component"
        store.close()

    def test_upgrades_calls_to_renders(self, tmp_path):
        """CALLS edges to PascalCase targets become RENDERS."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.renders_created > 0

        # Check that App → HomePage is now RENDERS
        edges = store.get_edges_from("src/App.tsx::App")
        renders = [e for e in edges if e["type"] == "RENDERS"]
        assert len(renders) >= 1
        targets = [e["target"] for e in renders]
        assert "HomePage" in targets or "UserProfile" in targets
        store.close()

    def test_extracts_props_from_jsx(self, tmp_path):
        """PASSES_PROP edges created from JSX attribute bindings."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.props_extracted > 0
        store.close()

    def test_extracts_react_router_routes(self, tmp_path):
        """Detects React Router route definitions."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 1

        # Check route nodes exist
        all_nodes = store.get_all_nodes()
        route_nodes = [n for n in all_nodes if n["type"] == "route"]
        assert len(route_nodes) >= 1
        store.close()

    def test_extracts_vue_router_routes(self, tmp_path):
        """Detects Vue Router { path, component } patterns."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "router.ts").write_text(textwrap.dedent("""\
            const routes = [
                { path: '/home', component: HomeView },
                { path: '/about', component: AboutView },
            ];
        """))

        store.upsert_file(ParsedFile(
            path="src/router.ts", content_hash="r", line_count=4,
            nodes=[ParsedNode(
                id="src/router.ts::__module__", name="router",
                qualified_name="__module__", type="file",
                file_path="src/router.ts", line_start=1, line_end=4,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 2
        store.close()

    def test_extracts_redux_use_selector(self, tmp_path):
        """useSelector → SUBSCRIBES edge."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.state_edges >= 1

        # Check SUBSCRIBES edges exist
        all_edges = store.get_all_edges()
        subs = [e for e in all_edges if e["type"] == "SUBSCRIBES"]
        assert len(subs) >= 1
        store.close()

    def test_extracts_redux_dispatch(self, tmp_path):
        """dispatch(action()) → DISPATCHES edge."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        # The App.tsx has dispatch(goBack())
        all_edges = store.get_all_edges()
        dispatches = [e for e in all_edges if e["type"] == "DISPATCHES"]
        assert len(dispatches) >= 1
        store.close()

    def test_extracts_fetch_api_calls(self, tmp_path):
        """fetch('/api/...') → FETCHES edge."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.api_calls >= 1

        all_edges = store.get_all_edges()
        fetches = [e for e in all_edges if e["type"] == "FETCHES"]
        assert len(fetches) >= 1
        urls = [e["target"] for e in fetches]
        assert "/api/users" in urls
        store.close()

    def test_handles_component_with_no_children(self, tmp_path):
        """Leaf component (no JSX children) doesn't break."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "Leaf.tsx").write_text("function Leaf() { return <div>Hello</div>; }")

        store.upsert_file(ParsedFile(
            path="src/Leaf.tsx", content_hash="l", line_count=1,
            nodes=[ParsedNode(
                id="src/Leaf.tsx::Leaf", name="Leaf",
                qualified_name="Leaf", type="function",
                file_path="src/Leaf.tsx", line_start=1, line_end=1,
                is_exported=True,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()  # Should not crash

        node = store.get_node("src/Leaf.tsx::Leaf")
        assert node["type"] == "component"
        store.close()


# ===========================================================================
# Vue parser tests (8)
# ===========================================================================


class TestVueParser:
    """Tests for the Vue SFC parser."""

    def _parse(self, tmp_path, filename, source):
        from codebrain.parser.vue_parser import VueParser
        (tmp_path / filename).write_text(source)
        parser = VueParser()
        return parser.parse(tmp_path / filename, tmp_path)

    def test_parses_basic_sfc(self, tmp_path):
        """Basic Vue SFC with template + script."""
        result = self._parse(tmp_path, "MyComp.vue", textwrap.dedent("""\
            <template>
                <div>Hello</div>
            </template>
            <script>
            export default {
                name: 'MyComp'
            }
            </script>
        """))

        assert len(result.nodes) >= 2  # file + component
        comp = [n for n in result.nodes if n.type == "component"]
        assert len(comp) == 1
        assert comp[0].name == "MyComp"

    def test_extracts_component_references(self, tmp_path):
        """Finds component references in template."""
        result = self._parse(tmp_path, "Parent.vue", textwrap.dedent("""\
            <template>
                <div>
                    <ChildOne />
                    <ChildTwo>content</ChildTwo>
                </div>
            </template>
            <script>
            import ChildOne from './ChildOne.vue'
            import ChildTwo from './ChildTwo.vue'
            </script>
        """))

        renders = [e for e in result.edges if e.type == "RENDERS"]
        targets = [e.target for e in renders]
        assert "ChildOne" in targets
        assert "ChildTwo" in targets

    def test_extracts_prop_bindings(self, tmp_path):
        """Finds :propName="expr" bindings."""
        result = self._parse(tmp_path, "PropComp.vue", textwrap.dedent("""\
            <template>
                <UserCard :name="userName" :age="userAge" />
            </template>
            <script>
            </script>
        """))

        comp = [n for n in result.nodes if n.type == "component"][0]
        # Props should be in signature or fingerprint
        assert "name" in comp.summary or "props" in comp.summary

    def test_extracts_event_handlers(self, tmp_path):
        """Finds @eventName="handler" patterns."""
        result = self._parse(tmp_path, "EventComp.vue", textwrap.dedent("""\
            <template>
                <button @click="handleClick">Click</button>
                <input @input="onInput" />
            </template>
            <script>
            </script>
        """))

        calls = [e for e in result.edges if e.type == "CALLS"]
        targets = [e.target for e in calls]
        assert "handleClick" in targets

    def test_handles_script_setup(self, tmp_path):
        """<script setup> is detected."""
        result = self._parse(tmp_path, "Setup.vue", textwrap.dedent("""\
            <template>
                <div>{{ msg }}</div>
            </template>
            <script setup>
            const msg = ref('hello')
            </script>
        """))

        comp = [n for n in result.nodes if n.type == "component"]
        assert len(comp) == 1
        assert "script_setup" in comp[0].decorators

    def test_handles_script_lang_ts(self, tmp_path):
        """<script lang="ts"> is detected."""
        result = self._parse(tmp_path, "TsComp.vue", textwrap.dedent("""\
            <template>
                <div>TS</div>
            </template>
            <script lang="ts">
            export default {}
            </script>
        """))

        comp = [n for n in result.nodes if n.type == "component"]
        assert len(comp) == 1
        assert "typescript" in comp[0].decorators

    def test_creates_renders_edges(self, tmp_path):
        """RENDERS edges created for each child component."""
        result = self._parse(tmp_path, "Multi.vue", textwrap.dedent("""\
            <template>
                <TopBar />
                <MainContent />
                <BottomBar />
            </template>
            <script>
            </script>
        """))

        renders = [e for e in result.edges if e.type == "RENDERS"]
        assert len(renders) == 3
        targets = sorted(e.target for e in renders)
        assert targets == ["BottomBar", "MainContent", "TopBar"]

    def test_creates_passes_prop_edges(self, tmp_path):
        """PASSES_PROP edges for prop bindings."""
        result = self._parse(tmp_path, "Props.vue", textwrap.dedent("""\
            <template>
                <Child :title="t" :count="c" />
            </template>
            <script>
            </script>
        """))

        prop_edges = [e for e in result.edges if e.type == "PASSES_PROP"]
        assert len(prop_edges) >= 1


# ===========================================================================
# Analyzer tests (7)
# ===========================================================================


class TestFrontendAnalyzer:
    """Tests for the cross-file frontend analyzer."""

    def _setup(self, tmp_path):
        from codebrain.parser.frontend_parser import FrontendComponentParser
        from codebrain.frontend import FrontendAnalyzer

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        # Run enrichment
        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        return store, FrontendAnalyzer(store)

    def test_builds_component_tree(self, tmp_path):
        """Component tree has roots and nested children."""
        store, analyzer = self._setup(tmp_path)
        tree = analyzer.get_component_tree()

        assert "roots" in tree
        assert "tree" in tree
        assert tree["total_components"] >= 2
        store.close()

    def test_finds_root_components(self, tmp_path):
        """Root components are those not rendered by others."""
        store, analyzer = self._setup(tmp_path)
        tree = analyzer.get_component_tree()

        # App should be a root (nothing renders App)
        roots = tree["roots"]
        assert "App" in roots
        # UserCard should NOT be a root (it's rendered by others)
        assert "UserCard" not in roots
        store.close()

    def test_builds_route_map(self, tmp_path):
        """Route map extracted from ROUTES_TO edges."""
        store, analyzer = self._setup(tmp_path)
        routes = analyzer.get_route_map()

        assert len(routes) >= 1
        paths = [r["path"] for r in routes]
        # At least one of our routes should be found
        assert any("/" in p for p in paths)
        store.close()

    def test_builds_state_graph(self, tmp_path):
        """State graph from SUBSCRIBES/DISPATCHES edges."""
        store, analyzer = self._setup(tmp_path)
        state = analyzer.get_state_graph()

        # Should have some state entries
        assert len(state) >= 1
        store.close()

    def test_extracts_api_surface(self, tmp_path):
        """API surface from FETCHES edges."""
        store, analyzer = self._setup(tmp_path)
        api = analyzer.get_api_surface()

        assert len(api) >= 1
        urls = [a["url"] for a in api]
        assert "/api/users" in urls
        store.close()

    def test_detects_orphan_components(self, tmp_path):
        """Orphan components not rendered or routed."""
        store, analyzer = self._setup(tmp_path)
        report = analyzer.analyze()

        # App should be orphan (nothing renders it AND it's not routed)
        # or have specific orphans
        assert isinstance(report.orphan_components, list)
        store.close()

    def test_generates_component_contract(self, tmp_path):
        """Component contract includes props, children, state, API."""
        store, analyzer = self._setup(tmp_path)
        contract = analyzer.get_component_contract("App")

        assert "name" in contract
        assert contract["name"] == "App"
        assert "children_rendered" in contract
        assert "api_calls" in contract
        store.close()


# ===========================================================================
# Spec generation tests (5)
# ===========================================================================


class TestFrontendSpecGeneration:
    """Tests for frontend-aware spec generation."""

    def _setup(self, tmp_path):
        from codebrain.parser.frontend_parser import FrontendComponentParser
        from codebrain.modernize import SpecGenerator

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        # Run enrichment
        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        return store, SpecGenerator(store)

    def test_infers_component_role(self, tmp_path):
        """React component files get role 'component'."""
        store, gen = self._setup(tmp_path)
        spec = gen.generate_module_spec("src/App.tsx")

        assert spec["role"] == "component"
        store.close()

    def test_includes_component_info(self, tmp_path):
        """Module spec includes component_info for frontend files."""
        store, gen = self._setup(tmp_path)
        spec = gen.generate_module_spec("src/App.tsx")

        assert "component_info" in spec
        info = spec["component_info"]
        assert "name" in info
        assert "children_rendered" in info
        store.close()

    def test_generates_frontend_rewrite_notes(self, tmp_path):
        """Rewrite notes mention frontend-specific concerns."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        # Insert route nodes to trigger route notes
        store.conn.execute(
            """INSERT OR REPLACE INTO nodes
               (id, name, qualified_name, type, file_path,
                line_start, line_end, signature, decorators, docstring,
                is_exported, summary)
               VALUES (?, ?, ?, 'route', ?, ?, ?, '', '[]', '', 0, '')""",
            ("src/App.tsx::route:/", "/", "/", "src/App.tsx", 1, 1),
        )
        store.conn.commit()

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        from codebrain.modernize import SpecGenerator
        gen = SpecGenerator(store)
        spec = gen.generate_module_spec("src/App.tsx")

        notes = spec.get("rewrite_notes", [])
        # Should mention routes
        has_route_note = any("route" in n.lower() for n in notes)
        assert has_route_note
        store.close()

    def test_generates_frontend_test_scenarios(self, tmp_path):
        """Test scenarios include component-specific checks."""
        store, gen = self._setup(tmp_path)
        spec = gen.generate_module_spec("src/App.tsx")

        scenarios = spec.get("test_scenarios", [])
        assert len(scenarios) >= 1
        store.close()

    def test_phase_ordering_shared_before_pages(self, tmp_path):
        """In the rewrite plan, shared components come before pages."""
        store, gen = self._setup(tmp_path)
        full_spec = gen.generate_full_spec(project_name="test")

        modules = full_spec["module_specs"]
        assert "src/App.tsx" in modules
        assert "src/UserCard.tsx" in modules
        store.close()


# ===========================================================================
# Rewrite validation tests (5)
# ===========================================================================


class TestFrontendRewriteValidation:
    """Tests for frontend-aware rewrite validation."""

    def test_catches_missing_child_component(self):
        """Validation fails if a child component is missing from rewrite."""
        from codebrain.rewriter import validate_rewrite

        spec = {
            "file_path": "src/App.tsx",
            "symbols": [{"name": "App", "type": "function", "is_exported": True}],
            "component_info": {
                "name": "App",
                "children_rendered": ["UserCard", "Header"],
                "api_calls": [],
                "routes_served": [],
            },
        }
        new_code = textwrap.dedent("""\
            function App() {
                return <div><UserCard /></div>;
            }
            export default App;
        """)

        result = validate_rewrite(spec, new_code)
        assert not result.valid
        assert any("Header" in e for e in result.errors)

    def test_catches_removed_prop(self):
        """Validation warns if an API endpoint URL is missing."""
        from codebrain.rewriter import validate_rewrite

        spec = {
            "file_path": "src/UserList.tsx",
            "symbols": [{"name": "UserList", "type": "function", "is_exported": True}],
            "component_info": {
                "name": "UserList",
                "children_rendered": [],
                "api_calls": ["/api/users", "/api/users/count"],
                "routes_served": [],
            },
        }
        new_code = textwrap.dedent("""\
            function UserList() {
                fetch('/api/users');
                return <div>List</div>;
            }
            export default UserList;
        """)

        result = validate_rewrite(spec, new_code)
        # Should have warning about missing /api/users/count
        assert any("/api/users/count" in w for w in result.warnings)

    def test_passes_valid_rewrite(self):
        """Validation passes when all children and APIs preserved."""
        from codebrain.rewriter import validate_rewrite

        spec = {
            "file_path": "src/App.tsx",
            "symbols": [{"name": "App", "type": "function", "is_exported": True}],
            "component_info": {
                "name": "App",
                "children_rendered": ["UserCard"],
                "api_calls": ["/api/users"],
                "routes_served": ["/users"],
            },
        }
        new_code = textwrap.dedent("""\
            function App() {
                fetch('/api/users');
                return (
                    <Router>
                        <Route path="/users" element={<UserCard />} />
                    </Router>
                );
            }
            export default App;
        """)

        result = validate_rewrite(spec, new_code)
        assert result.valid

    def test_catches_missing_route(self):
        """Warns when a route path is missing from rewrite."""
        from codebrain.rewriter import validate_rewrite

        spec = {
            "file_path": "src/routes.tsx",
            "symbols": [{"name": "Routes", "type": "function", "is_exported": True}],
            "component_info": {
                "name": "Routes",
                "children_rendered": [],
                "api_calls": [],
                "routes_served": ["/users", "/settings"],
            },
        }
        new_code = textwrap.dedent("""\
            function Routes() {
                return <Route path="/users" />;
            }
            export default Routes;
        """)

        result = validate_rewrite(spec, new_code)
        assert any("/settings" in w for w in result.warnings)

    def test_validation_skips_when_no_component_info(self):
        """No component_info in spec → basic validation only."""
        from codebrain.rewriter import validate_rewrite

        spec = {
            "file_path": "src/utils.ts",
            "symbols": [{"name": "formatDate", "type": "function", "is_exported": True}],
        }
        new_code = "function formatDate(d) { return d.toISOString(); }\nexport { formatDate };"

        result = validate_rewrite(spec, new_code)
        assert result.valid


# ===========================================================================
# Integration tests (5)
# ===========================================================================


class TestFrontendIntegration:
    """End-to-end integration tests."""

    def test_index_react_project_to_report(self, tmp_path):
        """Index a React project → enrich → frontend report."""
        from codebrain.parser.frontend_parser import FrontendComponentParser
        from codebrain.frontend import FrontendAnalyzer

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        analyzer = FrontendAnalyzer(store)
        report = analyzer.analyze()

        assert report.total_components >= 2
        assert report.total_api_endpoints >= 1

        # Report to dict
        d = report.to_dict()
        assert "component_tree" in d
        assert "api_surface" in d

        # Report to markdown
        md = analyzer.to_markdown(report)
        assert "## Summary" in md
        assert "Components" in md
        store.close()

    def test_index_vue_project_to_report(self, tmp_path):
        """Index a Vue project → frontend report."""
        from codebrain.parser.vue_parser import VueParser
        from codebrain.parser.frontend_parser import FrontendComponentParser
        from codebrain.frontend import FrontendAnalyzer

        store = _make_store(tmp_path)
        vue_parser = VueParser()

        # Create Vue files
        (tmp_path / "App.vue").write_text(textwrap.dedent("""\
            <template>
                <Header />
                <router-view />
            </template>
            <script>
            import Header from './Header.vue'
            </script>
        """))
        (tmp_path / "Header.vue").write_text(textwrap.dedent("""\
            <template>
                <nav>
                    <Logo />
                </nav>
            </template>
            <script>
            import Logo from './Logo.vue'
            </script>
        """))
        (tmp_path / "Logo.vue").write_text(textwrap.dedent("""\
            <template>
                <img src="/logo.png" />
            </template>
            <script>
            </script>
        """))

        for fname in ["App.vue", "Header.vue", "Logo.vue"]:
            pf = vue_parser.parse(tmp_path / fname, tmp_path)
            store.upsert_file(pf)

        # Enrich
        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        analyzer = FrontendAnalyzer(store)
        report = analyzer.analyze()

        assert report.total_components >= 3
        store.close()

    def test_rewrite_spec_includes_component_contracts(self, tmp_path):
        """Full spec generation includes component contracts."""
        from codebrain.parser.frontend_parser import FrontendComponentParser
        from codebrain.modernize import SpecGenerator

        store = _make_store(tmp_path)
        _insert_tsx_project(store, tmp_path)

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        gen = SpecGenerator(store)
        full_spec = gen.generate_full_spec(project_name="react-app")

        # At least one module should have component_info
        has_comp_info = any(
            "component_info" in m
            for m in full_spec["module_specs"].values()
        )
        assert has_comp_info
        store.close()

    def test_validate_catches_missing_child(self, tmp_path):
        """Validation catches a missing child component in rewrite output."""
        from codebrain.rewriter import validate_rewrite

        spec = {
            "file_path": "src/Dashboard.tsx",
            "symbols": [
                {"name": "Dashboard", "type": "function", "is_exported": True},
            ],
            "component_info": {
                "name": "Dashboard",
                "children_rendered": ["Sidebar", "MainPanel", "Footer"],
                "api_calls": [],
                "routes_served": [],
            },
        }
        # Missing Footer
        new_code = "function Dashboard() { return <div><Sidebar /><MainPanel /></div>; }\nexport default Dashboard;"

        result = validate_rewrite(spec, new_code)
        assert not result.valid
        assert any("Footer" in e for e in result.errors)

    def test_enrichment_result_dataclass(self, tmp_path):
        """FrontendEnrichmentResult has correct fields."""
        from codebrain.parser.frontend_parser import FrontendEnrichmentResult

        r = FrontendEnrichmentResult()
        assert r.renders_created == 0
        assert r.props_extracted == 0
        assert r.routes_found == 0
        assert r.state_edges == 0
        assert r.api_calls == 0
        assert r.components_tagged == 0


# ===========================================================================
# SPEC-M29: Route Detection Fix (8 tests)
# ===========================================================================


class TestRouteDetectionFix:
    """Tests for SPEC-M29: block-based multi-line route parsing."""

    def test_multiline_vue_route_objects(self, tmp_path):
        """Multi-line { path, component } objects are detected."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "router.js").write_text(textwrap.dedent("""\
            const routes = [
              {
                meta: { title: 'Dashboard' },
                path: '/dashboard',
                name: 'dashboard',
                component: Home,
              },
              {
                path: '/tables',
                name: 'tables',
                component: Tables,
              },
            ];
        """))

        store.upsert_file(ParsedFile(
            path="src/router.js", content_hash="r1", line_count=13,
            nodes=[ParsedNode(
                id="src/router.js::__module__", name="router",
                qualified_name="__module__", type="file",
                file_path="src/router.js", line_start=1, line_end=13,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 2
        all_nodes = store.get_all_nodes()
        route_nodes = [n for n in all_nodes if n["type"] == "route"]
        paths = [n["name"] for n in route_nodes]
        assert "/dashboard" in paths
        assert "/tables" in paths
        store.close()

    def test_lazy_import_component(self, tmp_path):
        """component: () => import('@/views/X.vue') → X detected."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "router.js").write_text(textwrap.dedent("""\
            const routes = [
              {
                path: '/tables',
                component: () => import('@/views/TablesView.vue'),
              },
              {
                path: '/forms',
                component: () => import('@/views/FormsView.vue'),
              },
            ];
        """))

        store.upsert_file(ParsedFile(
            path="src/router.js", content_hash="r2", line_count=10,
            nodes=[ParsedNode(
                id="src/router.js::__module__", name="router",
                qualified_name="__module__", type="file",
                file_path="src/router.js", line_start=1, line_end=10,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 2
        edges = store.get_all_edges()
        routes_to = [e for e in edges if e["type"] == "ROUTES_TO"]
        targets = [e["target"] for e in routes_to]
        assert "TablesView" in targets
        assert "FormsView" in targets
        store.close()

    def test_direct_import_component(self, tmp_path):
        """component: Home → Home detected."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "router.js").write_text(textwrap.dedent("""\
            const routes = [
              {
                path: '/',
                component: Home,
              },
            ];
        """))

        store.upsert_file(ParsedFile(
            path="src/router.js", content_hash="r3", line_count=6,
            nodes=[ParsedNode(
                id="src/router.js::__module__", name="router",
                qualified_name="__module__", type="file",
                file_path="src/router.js", line_start=1, line_end=6,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 1
        edges = store.get_all_edges()
        routes_to = [e for e in edges if e["type"] == "ROUTES_TO"]
        assert any(e["target"] == "Home" for e in routes_to)
        store.close()

    def test_react_router_v6_create_browser_router(self, tmp_path):
        """createBrowserRouter([{ path, element }])."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "router.tsx").write_text(textwrap.dedent("""\
            const router = createBrowserRouter([
              {
                path: '/',
                element: <Home />,
              },
              {
                path: '/about',
                element: <About />,
              },
            ]);
        """))

        store.upsert_file(ParsedFile(
            path="src/router.tsx", content_hash="r4", line_count=10,
            nodes=[ParsedNode(
                id="src/router.tsx::__module__", name="router",
                qualified_name="__module__", type="file",
                file_path="src/router.tsx", line_start=1, line_end=10,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 2
        edges = store.get_all_edges()
        routes_to = [e for e in edges if e["type"] == "ROUTES_TO"]
        targets = {e["target"] for e in routes_to}
        assert "Home" in targets
        assert "About" in targets
        store.close()

    def test_vue_router_create_router_inline(self, tmp_path):
        """createRouter({ routes: [{...}] })."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "router.js").write_text(textwrap.dedent("""\
            const router = createRouter({
              history: createWebHistory(),
              routes: [
                {
                  path: '/home',
                  component: HomeView,
                },
              ],
            });
        """))

        store.upsert_file(ParsedFile(
            path="src/router.js", content_hash="r5", line_count=9,
            nodes=[ParsedNode(
                id="src/router.js::__module__", name="router",
                qualified_name="__module__", type="file",
                file_path="src/router.js", line_start=1, line_end=9,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 1
        store.close()

    def test_vue_router_create_router_reference(self, tmp_path):
        """const routes = [...]; createRouter({ routes }) — routes array detected."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "router.js").write_text(textwrap.dedent("""\
            const routes = [
              {
                path: '/dashboard',
                component: Home,
              },
              {
                path: '/login',
                component: () => import('@/views/LoginView.vue'),
              },
            ];

            const router = createRouter({
              history: createWebHashHistory(),
              routes,
            });
        """))

        store.upsert_file(ParsedFile(
            path="src/router.js", content_hash="r6", line_count=15,
            nodes=[ParsedNode(
                id="src/router.js::__module__", name="router",
                qualified_name="__module__", type="file",
                file_path="src/router.js", line_start=1, line_end=15,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 2
        edges = store.get_all_edges()
        routes_to = [e for e in edges if e["type"] == "ROUTES_TO"]
        targets = {e["target"] for e in routes_to}
        assert "Home" in targets
        assert "LoginView" in targets
        store.close()

    def test_nested_children_routes(self, tmp_path):
        """children: [{ path: '/sub', component: Sub }]."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)
        (src / "router.js").write_text(textwrap.dedent("""\
            const routes = [
              {
                path: '/dashboard',
                component: Dashboard,
                children: [
                  {
                    path: '/settings',
                    component: Settings,
                  },
                  {
                    path: '/profile',
                    component: Profile,
                  },
                ],
              },
            ];
        """))

        store.upsert_file(ParsedFile(
            path="src/router.js", content_hash="r7", line_count=15,
            nodes=[ParsedNode(
                id="src/router.js::__module__", name="router",
                qualified_name="__module__", type="file",
                file_path="src/router.js", line_start=1, line_end=15,
            )],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        result = parser.enrich()

        assert result.routes_found >= 3  # dashboard + settings + profile
        all_nodes = store.get_all_nodes()
        route_nodes = [n for n in all_nodes if n["type"] == "route"]
        paths = {n["name"] for n in route_nodes}
        assert "/dashboard" in paths
        assert "/settings" in paths
        assert "/profile" in paths
        store.close()

    def test_filename_to_component_helper(self):
        """_filename_to_component extracts names correctly."""
        from codebrain.parser.frontend_parser import _filename_to_component

        assert _filename_to_component("@/views/TablesView.vue") == "TablesView"
        assert _filename_to_component("../pages/Home") == "Home"
        assert _filename_to_component("./Dashboard.tsx") == "Dashboard"
        assert _filename_to_component("@/components/UserCard.vue") == "UserCard"


# ===========================================================================
# SPEC-M30: Multi-Component File Handling (6 tests)
# ===========================================================================


class TestMultiComponentFiles:
    """Tests for SPEC-M30: line-range attribution in multi-component files."""

    def test_multi_component_file_attribution(self, tmp_path):
        """3 components in one file — JSX attributed to correct parent."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src" / "components"
        src.mkdir(parents=True, exist_ok=True)

        (src / "Profile.js").write_text(textwrap.dedent("""\
            function EditProfileSettings({ onSubmit }) {
                return <Link to="/settings">Edit Profile</Link>;
            }

            function FollowUserButton({ user }) {
                return <button>Follow {user.name}</button>;
            }

            class Profile extends React.Component {
                render() {
                    return (
                        <div>
                            <EditProfileSettings onSubmit={this.handleSubmit} />
                            <FollowUserButton user={this.props.user} />
                            <ArticleList articles={this.props.articles} />
                        </div>
                    );
                }
            }
        """))

        store.upsert_file(ParsedFile(
            path="src/components/Profile.js", content_hash="prof", line_count=20,
            nodes=[
                ParsedNode(
                    id="src/components/Profile.js::__module__", name="Profile",
                    qualified_name="__module__", type="file",
                    file_path="src/components/Profile.js", line_start=1, line_end=20,
                ),
                ParsedNode(
                    id="src/components/Profile.js::EditProfileSettings",
                    name="EditProfileSettings", qualified_name="EditProfileSettings",
                    type="function", file_path="src/components/Profile.js",
                    line_start=1, line_end=3, is_exported=False,
                ),
                ParsedNode(
                    id="src/components/Profile.js::FollowUserButton",
                    name="FollowUserButton", qualified_name="FollowUserButton",
                    type="function", file_path="src/components/Profile.js",
                    line_start=5, line_end=7, is_exported=False,
                ),
                ParsedNode(
                    id="src/components/Profile.js::Profile",
                    name="Profile", qualified_name="Profile",
                    type="class", file_path="src/components/Profile.js",
                    line_start=9, line_end=20, is_exported=True,
                ),
                ParsedNode(
                    id="src/components/Profile.js::ArticleList",
                    name="ArticleList", qualified_name="ArticleList",
                    type="function", file_path="src/components/Profile.js",
                    line_start=0, line_end=0,  # defined elsewhere
                ),
            ],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        edges = store.get_all_edges()
        renders = [e for e in edges if e["type"] == "RENDERS"]

        # Profile should render EditProfileSettings, FollowUserButton, ArticleList
        profile_renders = [
            e for e in renders
            if e["source"] == "src/components/Profile.js::Profile"
        ]
        profile_targets = {e["target"] for e in profile_renders}
        assert "EditProfileSettings" in profile_targets
        assert "FollowUserButton" in profile_targets
        assert "ArticleList" in profile_targets

        # EditProfileSettings should NOT render anything (except maybe Link, which isn't a node)
        edit_renders = [
            e for e in renders
            if e["source"] == "src/components/Profile.js::EditProfileSettings"
        ]
        edit_targets = {e["target"] for e in edit_renders}
        assert "FollowUserButton" not in edit_targets
        assert "ArticleList" not in edit_targets

        store.close()

    def test_self_render_prevention(self, tmp_path):
        """Component doesn't get RENDERS edge to itself."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src" / "components"
        src.mkdir(parents=True, exist_ok=True)

        (src / "Recursive.js").write_text(textwrap.dedent("""\
            function TreeNode({ children }) {
                return (
                    <div>
                        {children.map(c => <TreeNode key={c.id} children={c.children} />)}
                    </div>
                );
            }
        """))

        store.upsert_file(ParsedFile(
            path="src/components/Recursive.js", content_hash="rec", line_count=7,
            nodes=[
                ParsedNode(
                    id="src/components/Recursive.js::__module__", name="Recursive",
                    qualified_name="__module__", type="file",
                    file_path="src/components/Recursive.js", line_start=1, line_end=7,
                ),
                ParsedNode(
                    id="src/components/Recursive.js::TreeNode",
                    name="TreeNode", qualified_name="TreeNode",
                    type="function", file_path="src/components/Recursive.js",
                    line_start=1, line_end=7, is_exported=True,
                ),
            ],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        edges = store.get_all_edges()
        renders = [e for e in edges if e["type"] == "RENDERS"]
        self_renders = [
            e for e in renders
            if e["source"].endswith("::TreeNode") and e["target"] == "TreeNode"
        ]
        assert len(self_renders) == 0
        store.close()

    def test_class_component_with_render(self, tmp_path):
        """JSX inside render() method attributed to class."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src" / "components"
        src.mkdir(parents=True, exist_ok=True)

        (src / "Dashboard.js").write_text(textwrap.dedent("""\
            class Dashboard extends React.Component {
                render() {
                    return (
                        <div>
                            <Sidebar />
                            <MainPanel />
                        </div>
                    );
                }
            }
        """))

        store.upsert_file(ParsedFile(
            path="src/components/Dashboard.js", content_hash="dash", line_count=10,
            nodes=[
                ParsedNode(
                    id="src/components/Dashboard.js::__module__", name="Dashboard",
                    qualified_name="__module__", type="file",
                    file_path="src/components/Dashboard.js", line_start=1, line_end=10,
                ),
                ParsedNode(
                    id="src/components/Dashboard.js::Dashboard",
                    name="Dashboard", qualified_name="Dashboard",
                    type="class", file_path="src/components/Dashboard.js",
                    line_start=1, line_end=10, is_exported=True,
                ),
                ParsedNode(
                    id="src/components/Dashboard.js::Sidebar",
                    name="Sidebar", qualified_name="Sidebar",
                    type="function", file_path="other.js",
                    line_start=1, line_end=5,
                ),
                ParsedNode(
                    id="src/components/Dashboard.js::MainPanel",
                    name="MainPanel", qualified_name="MainPanel",
                    type="function", file_path="other.js",
                    line_start=1, line_end=5,
                ),
            ],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        edges = store.get_all_edges()
        renders = [e for e in edges if e["type"] == "RENDERS"]
        dashboard_renders = [
            e for e in renders
            if e["source"] == "src/components/Dashboard.js::Dashboard"
        ]
        targets = {e["target"] for e in dashboard_renders}
        assert "Sidebar" in targets
        assert "MainPanel" in targets
        store.close()

    def test_helper_plus_main_pattern(self, tmp_path):
        """Helper component at top, main at bottom — main renders helper."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src" / "views"
        src.mkdir(parents=True, exist_ok=True)

        (src / "Page.tsx").write_text(textwrap.dedent("""\
            function Banner({ text }) {
                return <h1>{text}</h1>;
            }

            function Page() {
                return (
                    <div>
                        <Banner text="Welcome" />
                    </div>
                );
            }
        """))

        store.upsert_file(ParsedFile(
            path="src/views/Page.tsx", content_hash="pg", line_count=11,
            nodes=[
                ParsedNode(
                    id="src/views/Page.tsx::__module__", name="Page",
                    qualified_name="__module__", type="file",
                    file_path="src/views/Page.tsx", line_start=1, line_end=11,
                ),
                ParsedNode(
                    id="src/views/Page.tsx::Banner",
                    name="Banner", qualified_name="Banner",
                    type="function", file_path="src/views/Page.tsx",
                    line_start=1, line_end=3, is_exported=False,
                ),
                ParsedNode(
                    id="src/views/Page.tsx::Page",
                    name="Page", qualified_name="Page",
                    type="function", file_path="src/views/Page.tsx",
                    line_start=5, line_end=11, is_exported=True,
                ),
            ],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        edges = store.get_all_edges()
        renders = [e for e in edges if e["type"] == "RENDERS"]

        # Page renders Banner (not Banner renders Banner)
        page_renders = [
            e for e in renders
            if e["source"] == "src/views/Page.tsx::Page"
        ]
        assert any(e["target"] == "Banner" for e in page_renders)

        banner_renders = [
            e for e in renders
            if e["source"] == "src/views/Page.tsx::Banner"
        ]
        assert len(banner_renders) == 0
        store.close()

    def test_fallback_to_file_level(self, tmp_path):
        """JSX outside any component gets attributed to __module__."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src"
        src.mkdir(exist_ok=True)

        # JSX at top level (before any function)
        (src / "index.tsx").write_text(textwrap.dedent("""\
            ReactDOM.render(<App />, document.getElementById('root'));
        """))

        store.upsert_file(ParsedFile(
            path="src/index.tsx", content_hash="idx", line_count=1,
            nodes=[
                ParsedNode(
                    id="src/index.tsx::__module__", name="index",
                    qualified_name="__module__", type="file",
                    file_path="src/index.tsx", line_start=1, line_end=1,
                ),
                ParsedNode(
                    id="other::App", name="App", qualified_name="App",
                    type="function", file_path="src/App.tsx",
                    line_start=1, line_end=20,
                ),
            ],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        edges = store.get_all_edges()
        renders = [e for e in edges if e["type"] == "RENDERS"]
        # Should fall back to __module__
        module_renders = [
            e for e in renders
            if e["source"] == "src/index.tsx::__module__"
        ]
        assert any(e["target"] == "App" for e in module_renders)
        store.close()

    def test_build_component_ranges(self, tmp_path):
        """_build_component_ranges returns correct sorted ranges."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        parser = FrontendComponentParser(store, repo_root=tmp_path)

        nodes = [
            {"id": "f::Alpha", "name": "Alpha", "type": "function", "line_start": 1, "line_end": 5},
            {"id": "f::Beta", "name": "Beta", "type": "class", "line_start": 10, "line_end": 20},
            {"id": "f::helper", "name": "helper", "type": "function", "line_start": 22, "line_end": 25},  # lowercase — excluded
        ]
        ranges = parser._build_component_ranges(nodes)
        assert len(ranges) == 2
        # Should be sorted descending by line_start (Beta first)
        assert ranges[0][0] == "f::Beta"
        assert ranges[1][0] == "f::Alpha"
        store.close()


# ===========================================================================
# SPEC-M31: Redux connect() State Detection (8 tests)
# ===========================================================================


class TestReduxConnectPattern:
    """Tests for SPEC-M31: proper parsing of connect(mapState, mapDispatch)(Component)."""

    def test_connect_wrap_attributes_to_component(self, tmp_path):
        """Edges attributed to Component, not mapState/mapDispatch."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src" / "components"
        src.mkdir(parents=True, exist_ok=True)

        (src / "App.js").write_text(textwrap.dedent("""\
            const mapStateToProps = state => ({
                currentUser: state.common.currentUser,
                appName: state.common.appName,
            });

            const mapDispatchToProps = dispatch => ({
                onLoad: (payload) => dispatch({ type: APP_LOAD, payload }),
                onRedirect: () => dispatch({ type: REDIRECT }),
            });

            class App extends React.Component {
                render() { return <div />; }
            }

            export default connect(mapStateToProps, mapDispatchToProps)(App);
        """))

        store.upsert_file(ParsedFile(
            path="src/components/App.js", content_hash="capp", line_count=15,
            nodes=[
                ParsedNode(
                    id="src/components/App.js::__module__", name="App",
                    qualified_name="__module__", type="file",
                    file_path="src/components/App.js", line_start=1, line_end=15,
                ),
                ParsedNode(
                    id="src/components/App.js::App", name="App",
                    qualified_name="App", type="class",
                    file_path="src/components/App.js", line_start=11, line_end=13,
                    is_exported=True,
                ),
            ],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        edges = store.get_all_edges()
        subs = [e for e in edges if e["type"] == "SUBSCRIBES"]
        dispatches = [e for e in edges if e["type"] == "DISPATCHES"]

        # Edges should be sourced from App, not mapStateToProps
        for e in subs:
            assert "App" in e["source"]
        for e in dispatches:
            assert "App" in e["source"]

        store.close()

    def test_map_state_arrow_function(self, tmp_path):
        """state => ({ x: state.auth.user }) → SUBSCRIBES to auth.user."""
        from codebrain.parser.frontend_parser import _parse_map_state_to_props

        source = textwrap.dedent("""\
            const mapStateToProps = state => ({
                currentUser: state.auth.user,
                posts: state.posts.list,
                count: state.stats,
            });
        """)

        subs = _parse_map_state_to_props(source, "mapStateToProps")
        assert "auth.user" in subs
        assert "posts.list" in subs
        assert "stats" in subs

    def test_map_state_regular_function(self, tmp_path):
        """function mapStateToProps(state) { return {...} } → same result."""
        from codebrain.parser.frontend_parser import _parse_map_state_to_props

        source = textwrap.dedent("""\
            function mapStateToProps(state) {
                return {
                    user: state.auth.currentUser,
                    token: state.auth.token,
                };
            }
        """)

        subs = _parse_map_state_to_props(source, "mapStateToProps")
        assert "auth.currentUser" in subs
        assert "auth.token" in subs

    def test_map_dispatch_function(self, tmp_path):
        """dispatch => ({ login: () => dispatch(login()) }) → DISPATCHES to login."""
        from codebrain.parser.frontend_parser import _parse_map_dispatch_to_props

        source = textwrap.dedent("""\
            const mapDispatchToProps = dispatch => ({
                login: (creds) => dispatch(loginUser(creds)),
                logout: () => dispatch(logoutUser()),
            });
        """)

        actions = _parse_map_dispatch_to_props(source, "mapDispatchToProps")
        assert "loginUser" in actions
        assert "logoutUser" in actions

    def test_map_dispatch_type_literal(self, tmp_path):
        """dispatch({ type: APP_LOAD }) → DISPATCHES to APP_LOAD."""
        from codebrain.parser.frontend_parser import _parse_map_dispatch_to_props

        source = textwrap.dedent("""\
            const mapDispatchToProps = dispatch => ({
                onLoad: (payload) => dispatch({ type: APP_LOAD, payload }),
                onRedirect: () => dispatch({ type: REDIRECT }),
            });
        """)

        actions = _parse_map_dispatch_to_props(source, "mapDispatchToProps")
        assert "APP_LOAD" in actions
        assert "REDIRECT" in actions

    def test_map_dispatch_object_shorthand(self, tmp_path):
        """connect(mapState, { action1, action2 }) → DISPATCHES to each."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src" / "components"
        src.mkdir(parents=True, exist_ok=True)

        (src / "Widget.js").write_text(textwrap.dedent("""\
            const mapStateToProps = state => ({
                data: state.widget.data,
            });

            function Widget({ data, fetchData, resetData }) {
                return <div>{data}</div>;
            }

            export default connect(mapStateToProps, { fetchData, resetData })(Widget);
        """))

        store.upsert_file(ParsedFile(
            path="src/components/Widget.js", content_hash="widg", line_count=10,
            nodes=[
                ParsedNode(
                    id="src/components/Widget.js::__module__", name="Widget",
                    qualified_name="__module__", type="file",
                    file_path="src/components/Widget.js", line_start=1, line_end=10,
                ),
                ParsedNode(
                    id="src/components/Widget.js::Widget", name="Widget",
                    qualified_name="Widget", type="function",
                    file_path="src/components/Widget.js", line_start=5, line_end=7,
                    is_exported=True,
                ),
            ],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        edges = store.get_all_edges()
        dispatches = [e for e in edges if e["type"] == "DISPATCHES"]
        targets = {e["target"] for e in dispatches}
        assert "fetchData" in targets
        assert "resetData" in targets

        # Should be sourced from Widget
        for e in dispatches:
            assert "Widget" in e["source"]

        store.close()

    def test_connect_with_null(self, tmp_path):
        """connect(null, mapDispatch)(Component) → only DISPATCHES, no SUBSCRIBES."""
        from codebrain.parser.frontend_parser import FrontendComponentParser

        store = _make_store(tmp_path)
        src = tmp_path / "src" / "components"
        src.mkdir(parents=True, exist_ok=True)

        (src / "Actions.js").write_text(textwrap.dedent("""\
            const mapDispatchToProps = dispatch => ({
                doAction: () => dispatch({ type: DO_SOMETHING }),
            });

            function Actions() {
                return <button>Go</button>;
            }

            export default connect(null, mapDispatchToProps)(Actions);
        """))

        store.upsert_file(ParsedFile(
            path="src/components/Actions.js", content_hash="act", line_count=9,
            nodes=[
                ParsedNode(
                    id="src/components/Actions.js::__module__", name="Actions",
                    qualified_name="__module__", type="file",
                    file_path="src/components/Actions.js", line_start=1, line_end=9,
                ),
                ParsedNode(
                    id="src/components/Actions.js::Actions", name="Actions",
                    qualified_name="Actions", type="function",
                    file_path="src/components/Actions.js", line_start=5, line_end=7,
                    is_exported=True,
                ),
            ],
            edges=[],
        ))

        parser = FrontendComponentParser(store, repo_root=tmp_path)
        parser.enrich()

        edges = store.get_all_edges()
        # Only DISPATCHES, no SUBSCRIBES from connect
        subs = [e for e in edges if e["type"] == "SUBSCRIBES"
                and "Actions" in e["source"]]
        dispatches = [e for e in edges if e["type"] == "DISPATCHES"
                      and "Actions" in e["source"]]
        assert len(subs) == 0
        assert len(dispatches) >= 1
        assert any(e["target"] == "DO_SOMETHING" for e in dispatches)
        store.close()

    def test_parse_dispatch_object_shorthand_helper(self):
        """_parse_dispatch_object_shorthand extracts action names."""
        from codebrain.parser.frontend_parser import _parse_dispatch_object_shorthand

        actions = _parse_dispatch_object_shorthand("{ fetchData, resetData }")
        assert "fetchData" in actions
        assert "resetData" in actions
        assert len(actions) == 2
