"""Tests for architecture.py — pattern, framework, DB, infra, boundary detection."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from codebrain.graph.store import GraphStore
from codebrain.architecture import ArchitectureDetector, ArchitectureReport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


from codebrain.parser.models import ParsedFile, ParsedNode, ParsedEdge
from collections import defaultdict


class _GraphBuilder:
    """Accumulate nodes and edges, then flush to store."""

    def __init__(self, store: GraphStore):
        self.store = store
        self._nodes: dict[str, list[ParsedNode]] = defaultdict(list)
        self._edges: dict[str, list[ParsedEdge]] = defaultdict(list)

    def add_node(self, *, id: str, name: str, type: str = "file",
                 file_path: str = "", decorators: list[str] | None = None,
                 is_exported: bool = True) -> None:
        fp = file_path or id.split("::")[0]
        self._nodes[fp].append(ParsedNode(
            id=id, name=name, qualified_name=name, type=type,
            file_path=fp, line_start=1, line_end=10,
            signature="", decorators=decorators or [],
            docstring="", is_exported=is_exported,
        ))

    def add_edge(self, *, source: str, target: str, type: str,
                 file_path: str = "") -> None:
        fp = file_path or source.split("::")[0]
        self._edges[fp].append(ParsedEdge(
            source=source, target=target, type=type, file_path=fp, line=1,
        ))

    def flush(self) -> None:
        """Upsert all accumulated data."""
        all_fps = set(self._nodes.keys()) | set(self._edges.keys())
        for fp in all_fps:
            self.store.upsert_file(ParsedFile(
                path=fp, content_hash="h",
                nodes=self._nodes.get(fp, []),
                edges=self._edges.get(fp, []),
            ))


def _make_store(tmp_path: Path) -> GraphStore:
    """Create a fresh GraphStore in tmp_path."""
    db_path = tmp_path / ".codebrain" / "graph.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return GraphStore(str(db_path))


def _add_node(store, *, id: str, name: str, type: str = "file",
              file_path: str = "", decorators: list[str] | None = None,
              is_exported: bool = True) -> None:
    fp = file_path or id.split("::")[0]
    store.upsert_file(ParsedFile(path=fp, content_hash="h", nodes=[
        ParsedNode(
            id=id, name=name, qualified_name=name, type=type,
            file_path=fp, line_start=1, line_end=10,
            signature="", decorators=decorators or [],
            docstring="", is_exported=is_exported,
        ),
    ], edges=[]))


def _add_edge(store, *, source: str, target: str, type: str,
              file_path: str = "") -> None:
    fp = file_path or source.split("::")[0]
    store.upsert_file(ParsedFile(path=fp, content_hash="h", nodes=[], edges=[
        ParsedEdge(source=source, target=target, type=type, file_path=fp, line=1),
    ]))


# =========================================================================
# Framework Detection
# =========================================================================


class TestFrameworkDetection:
    """Framework detection from imports + files + decorators."""

    def test_django_project(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="app/views.py::views", name="views", file_path="app/views.py")
        g.add_node(id="app/models.py::models", name="models", file_path="app/models.py")
        g.add_node(id="manage.py::manage", name="manage", file_path="manage.py")
        for i in range(4):
            g.add_edge(source="app/views.py::views", target=f"django.http.mod{i}", type="IMPORTS", file_path="app/views.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert "django" in report.frameworks

    def test_fastapi_project(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="main.py::main", name="main", file_path="main.py")
        for i in range(4):
            g.add_edge(source="main.py::main", target=f"fastapi.routing.r{i}", type="IMPORTS", file_path="main.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert "fastapi" in report.frameworks

    def test_spring_boot_project(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="App.java::App", name="App", file_path="App.java",
                   decorators=["SpringBootApplication"])
        g.add_node(id="pom.xml::pom", name="pom", file_path="pom.xml")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert "spring_boot" in report.frameworks

    def test_express_project(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="app.js::app", name="app", file_path="app.js")
        for i in range(4):
            g.add_edge(source="app.js::app", target=f"express.mod{i}", type="IMPORTS", file_path="app.js")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert "express" in report.frameworks

    def test_multi_framework(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="api/main.py::main", name="main", file_path="api/main.py")
        g.add_node(id="frontend/App.tsx::App", name="App", file_path="frontend/App.tsx")
        g.add_node(id="tasks/worker.py::worker", name="worker", file_path="tasks/worker.py")
        for i in range(4):
            g.add_edge(source="api/main.py::main", target=f"fastapi.r{i}", type="IMPORTS", file_path="api/main.py")
            g.add_edge(source="frontend/App.tsx::App", target=f"react.r{i}", type="IMPORTS", file_path="frontend/App.tsx")
            g.add_edge(source="tasks/worker.py::worker", target=f"celery.r{i}", type="IMPORTS", file_path="tasks/worker.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert "fastapi" in report.frameworks
        assert "react" in report.frameworks
        assert "celery" in report.frameworks

    def test_single_import_below_threshold(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="test.py::test", name="test", file_path="test.py")
        _add_edge(store, source="test.py::test", target="flask.testing", type="IMPORTS", file_path="test.py")

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert "flask" not in report.frameworks


# =========================================================================
# DB Technology Detection
# =========================================================================


class TestDBTechDetection:
    """DB technology detection from M33 ORM tags."""

    def test_sqlalchemy_orm_tags(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="models.py::User", name="User", type="class",
                   file_path="models.py", decorators=["orm_model", "sqlalchemy"])
        _add_node(store, id="models.py::Order", name="Order", type="class",
                   file_path="models.py", decorators=["orm_model", "sqlalchemy"])

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.db_technology == "sqlalchemy"

    def test_django_orm_tags(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="models.py::User", name="User", type="class",
                   file_path="models.py", decorators=["orm_model", "django"])

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.db_technology == "django_orm"

    def test_raw_sql_tags(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="schema.sql::table:users", name="users", type="class",
                   file_path="schema.sql", decorators=["sql_table"])

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.db_technology == "raw_sql"

    def test_no_orm_tags_empty(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="utils.py::helper", name="helper", file_path="utils.py")

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.db_technology == ""


# =========================================================================
# Pattern Detection
# =========================================================================


class TestPatternDetection:
    """Architecture pattern detection with mutually exclusive discriminators."""

    def test_mvc_with_django(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        for i in range(3):
            g.add_node(id=f"app/views{i}.py::v{i}", name=f"views{i}", file_path=f"app/views{i}.py")
        for i in range(3):
            g.add_node(id=f"app/models{i}.py::m{i}", name=f"models{i}", file_path=f"app/models{i}.py")
        for i in range(4):
            g.add_edge(source="app/views0.py::v0", target=f"django.http.r{i}",
                       type="IMPORTS", file_path="app/views0.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern == "mvc"

    def test_repository_service(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        for i in range(3):
            g.add_node(id=f"repos/user_repo{i}.py::r{i}", name=f"repo{i}", file_path=f"repos/user_repo{i}.py")
        for i in range(3):
            g.add_node(id=f"services/user_service{i}.py::s{i}", name=f"svc{i}", file_path=f"services/user_service{i}.py")
        # Add edges: services → repos (creates layering)
        for i in range(3):
            g.add_edge(source=f"services/user_service{i}.py::s{i}",
                       target=f"repos/user_repo{i}.py::r{i}",
                       type="IMPORTS", file_path=f"services/user_service{i}.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern == "repository_service"

    def test_layered(self, tmp_path):
        """Well-structured codebase without specific framework → layered."""
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="api/routes.py::routes", name="routes", file_path="api/routes.py")
        g.add_node(id="services/core.py::core", name="core", file_path="services/core.py")
        g.add_node(id="db/store.py::store", name="store", file_path="db/store.py")
        g.add_node(id="utils/helpers.py::h", name="helpers", file_path="utils/helpers.py")
        g.add_node(id="config/settings.py::s", name="settings", file_path="config/settings.py")
        g.add_edge(source="api/routes.py::routes", target="services/core.py::core",
                   type="IMPORTS", file_path="api/routes.py")
        g.add_edge(source="services/core.py::core", target="db/store.py::store",
                   type="IMPORTS", file_path="services/core.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern in ("layered", "repository_service")

    def test_event_driven(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="handler.py::h", name="handler", file_path="handler.py")
        g.add_node(id="events.py::e", name="events", file_path="events.py")
        for i in range(12):
            g.add_edge(source="handler.py::h", target=f"events.py::evt{i}",
                       type="DISPATCHES", file_path="handler.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern == "event_driven"

    def test_monolith(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="app.py::app", name="app", file_path="app.py")
        _add_node(store, id="main.py::main", name="main", file_path="main.py")

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern == "monolith"

    def test_hybrid_mvc_celery(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        for i in range(3):
            g.add_node(id=f"views/v{i}.py::v{i}", name=f"v{i}", file_path=f"views/v{i}.py")
            g.add_node(id=f"models/m{i}.py::m{i}", name=f"m{i}", file_path=f"models/m{i}.py")
        for i in range(4):
            g.add_edge(source="views/v0.py::v0", target=f"django.http.r{i}",
                       type="IMPORTS", file_path="views/v0.py")
        for i in range(4):
            g.add_edge(source="views/v1.py::v1", target=f"celery.r{i}",
                       type="IMPORTS", file_path="views/v1.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern == "mvc" or report.secondary_pattern == "mvc"
        assert "celery" in report.frameworks

    def test_confidence_scores(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="app.py::app", name="app", file_path="app.py")

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern_confidence > 0


# =========================================================================
# Infrastructure Detection
# =========================================================================


class TestInfraDetection:
    """Infrastructure detection from M33 infra nodes."""

    def test_dockerfile_node(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="Dockerfile::d", name="Dockerfile", file_path="Dockerfile",
                   decorators=["dockerfile"])

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert "docker" in report.infrastructure

    def test_k8s_node(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="deploy/app.yaml::k", name="app", file_path="deploy/app.yaml",
                   decorators=["k8s_resource"])

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert "kubernetes" in report.infrastructure

    def test_no_infra_empty(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="app.py::app", name="app", file_path="app.py")

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert len(report.infrastructure) == 0


# =========================================================================
# Boundary Violations
# =========================================================================


class TestBoundaryViolations:
    """Boundary violation detection."""

    def test_model_calls_controller(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="models/user.py::User", name="User", file_path="models/user.py")
        g.add_node(id="api/views.py::handler", name="handler", file_path="api/views.py")
        g.add_edge(source="models/user.py::User", target="api/views.py::handler",
                   type="CALLS", file_path="models/user.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        violations = [v for v in report.boundary_violations if v["violation"] == "model_calls_controller"]
        assert len(violations) >= 1

    def test_clean_layered_no_violations(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="api/routes.py::r", name="routes", file_path="api/routes.py")
        g.add_node(id="services/core.py::c", name="core", file_path="services/core.py")
        g.add_edge(source="api/routes.py::r", target="services/core.py::c",
                   type="CALLS", file_path="api/routes.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        role_violations = [v for v in report.boundary_violations
                          if v["violation"] in ("model_calls_controller", "controller_direct_db")]
        assert len(role_violations) == 0

    def test_controller_direct_db(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        g.add_node(id="api/views.py::v", name="views", file_path="api/views.py")
        g.add_node(id="db/repo.py::r", name="repo", file_path="db/repo.py")
        g.add_edge(source="api/views.py::v", target="db/repo.py::r",
                   type="IMPORTS", file_path="api/views.py")
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        violations = [v for v in report.boundary_violations if v["violation"] == "controller_direct_db"]
        assert len(violations) >= 1


# =========================================================================
# Edge Cases
# =========================================================================


class TestEdgeCases:
    """Edge cases: tiny/empty codebases."""

    def test_tiny_codebase(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="app.py::app", name="app", file_path="app.py")
        _add_node(store, id="utils.py::utils", name="utils", file_path="utils.py")

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern == "monolith"
        assert report.frameworks == []
        assert report.pattern_confidence > 0

    def test_empty_graph(self, tmp_path):
        store = _make_store(tmp_path)
        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()
        assert report.pattern == ""
        assert report.frameworks == []
        assert report.db_technology == ""
        assert report.infrastructure == []


# =========================================================================
# Integration
# =========================================================================


class TestIntegration:
    """Integration: full report on synthetic project."""

    def test_full_django_report(self, tmp_path):
        store = _make_store(tmp_path)
        g = _GraphBuilder(store)
        # Models
        g.add_node(id="app/models.py::User", name="User", type="class",
                   file_path="app/models.py", decorators=["orm_model", "django"])
        g.add_node(id="app/models.py::Order", name="Order", type="class",
                   file_path="app/models.py", decorators=["orm_model", "django"])
        # Views
        g.add_node(id="app/views.py::user_view", name="user_view",
                   file_path="app/views.py")
        g.add_node(id="app/views2.py::order_view", name="order_view",
                   file_path="app/views2.py")
        # Django imports
        for i in range(5):
            g.add_edge(source="app/views.py::user_view", target=f"django.http.r{i}",
                       type="IMPORTS", file_path="app/views.py")
        # Infra
        g.add_node(id="Dockerfile::df", name="Dockerfile",
                   file_path="Dockerfile", decorators=["dockerfile"])
        g.flush()

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()

        assert report.pattern != ""
        assert "django" in report.frameworks
        assert report.db_technology == "django_orm"
        assert "docker" in report.infrastructure
        assert len(report.module_roles) > 0
        narrative = report.narrative()
        assert len(narrative) > 0

    def test_to_dict_serializable(self, tmp_path):
        store = _make_store(tmp_path)
        _add_node(store, id="app.py::app", name="app", file_path="app.py")

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()

        d = report.to_dict()
        import json
        json_str = json.dumps(d)
        assert isinstance(json_str, str)


# =========================================================================
# Rewrite Prompt Integration (M32 spec tests 28-30)
# =========================================================================


class TestRewritePromptIntegration:
    """Architecture context in rewrite prompts."""

    def test_system_prompt_includes_pattern_and_frameworks(self):
        """System prompt should include architecture pattern and frameworks."""
        from codebrain.rewriter import _build_system_prompt
        # db_technology already tested in M33 tests; here we verify it doesn't break
        prompt = _build_system_prompt("Python 3.12", "", db_technology="sqlalchemy")
        assert "sqlalchemy" in prompt

    def test_module_role_assignment(self, tmp_path):
        """Per-module role context is available."""
        store = _make_store(tmp_path)
        _add_node(store, id="api/views.py::v", name="views", file_path="api/views.py")
        _add_node(store, id="models/user.py::u", name="user", file_path="models/user.py")

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()

        assert report.module_roles.get("api/views.py") == "api_layer"
        assert report.module_roles.get("models/user.py") == "data_model"

    def test_data_layer_module_has_db_context(self, tmp_path):
        """Data-layer module should have DB technology in report."""
        store = _make_store(tmp_path)
        _add_node(store, id="models.py::User", name="User", type="class",
                   file_path="models.py", decorators=["orm_model", "sqlalchemy"])

        detector = ArchitectureDetector(store)
        report = detector.detect()
        store.close()

        assert report.db_technology == "sqlalchemy"
        assert report.module_roles.get("models.py") == "data_model"
