"""M16: Installation tests — verify package imports and CLI entry point work."""

from __future__ import annotations

import subprocess
import sys


def test_cli_entry_point():
    """brain CLI is accessible after install."""
    result = subprocess.run(
        [sys.executable, "-m", "codebrain", "--help"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0
    assert "brain" in result.stdout.lower() or "usage" in result.stdout.lower()


def test_import_version():
    """Core package exports __version__."""
    import codebrain
    assert hasattr(codebrain, "__version__")
    assert isinstance(codebrain.__version__, str)
    assert len(codebrain.__version__) > 0


def test_import_core_modules():
    """All core public modules import without errors."""
    from codebrain.graph.store import GraphStore
    from codebrain.graph.query import QueryEngine
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.validator import ChangeValidator
    from codebrain.indexer import full_index
    from codebrain.analyzer import StructuralAnalyzer

    assert GraphStore is not None
    assert QueryEngine is not None
    assert ComprehensionEngine is not None
    assert ChangeValidator is not None
    assert full_index is not None
    assert StructuralAnalyzer is not None
