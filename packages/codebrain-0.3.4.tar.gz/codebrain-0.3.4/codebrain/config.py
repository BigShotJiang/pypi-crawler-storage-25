"""Project-wide constants and configuration."""

from pathlib import Path

# Directory name for CodeBrain data at repo root
CODEBRAIN_DIR = ".codebrain"

# SQLite database filename inside CODEBRAIN_DIR
DB_FILENAME = "graph.db"

# Schema version for future migrations
SCHEMA_VERSION = 4

# Directories/patterns to always skip during indexing
SKIP_DIRS = frozenset({
    "__pycache__",
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "env",
    ".env",
    "node_modules",
    ".tox",
    ".nox",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "dist",
    "build",
    "*.egg-info",
    "coverage",
    ".coverage",
    ".nyc_output",
    ".next",
    ".nuxt",
    "_reference",
    # Leading-dot scratch/cache dirs — anything the user actively hid
    # should not leak into indexing / dead-code reports.
    ".test_*",
    ".cache",
    ".idea",
    ".vscode",
    # Test fixture clones: real third-party repos under
    # tests/fixtures/repos/ used only for parser validation.
    "fixtures",
    # Top-level scratch projects that accumulate during rewriter iteration.
    "test_java_project",
    "test_rewrite_project",
    CODEBRAIN_DIR,
})

# File extensions to index
INDEXABLE_EXTENSIONS = frozenset({
    ".py", ".ts", ".tsx", ".js", ".jsx", ".java", ".dart", ".vue",
    ".go", ".rs", ".cs", ".kt", ".kts",
    ".sql", ".prisma", ".tf", ".yaml", ".yml",
    # Legacy languages
    ".cob", ".cbl", ".cpy",                           # COBOL
    ".pls", ".plb", ".pks", ".pkb",                   # PL/SQL
    ".f", ".f90", ".f95", ".f03", ".f08", ".for",     # Fortran
    ".mps", ".zwr",                                    # MUMPS
})

# Watcher debounce interval in seconds
WATCHER_DEBOUNCE_SECONDS = 0.3
