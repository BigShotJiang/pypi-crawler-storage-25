"""UI Framework Translation — prompt enrichment + validation for frontend migrations.

Works WITH the existing RewriteEngine, not as a parallel engine.
Extracts component specs from the knowledge graph, builds enriched prompts
with structural context, and validates that translations preserve contracts.

Supported paths: Vue <-> React, Vue 2 Options -> Vue 3 Composition,
React Class -> React Hooks.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from codebrain.graph.store import GraphStore
from codebrain.frontend import FrontendAnalyzer


_VUE_PROPS_RE = re.compile(r"\(\s*props\s*:\s*\{([^}]*)\}")


def _parse_props_signature(sig: str) -> list[dict]:
    """Parse prop metadata from a component signature string.

    Accepts three formats in priority order:
      1. JSON array/object (unit-test convention): '[{"name":"x","type":"T"}]'
      2. Vue parser output: '(props: {name: type, age: type})'
      3. Plain Python-style param list: '(a, b, c)'
    """
    sig = sig.strip()
    if not sig or sig == "()":
        return []

    # 1) JSON
    try:
        parsed = json.loads(sig)
        if isinstance(parsed, list):
            return [p for p in parsed if isinstance(p, dict) and "name" in p]
        if isinstance(parsed, dict) and "name" in parsed:
            return [parsed]
    except (json.JSONDecodeError, TypeError):
        pass

    # 2) Vue (props: {name: type, ...})
    m = _VUE_PROPS_RE.search(sig)
    if m:
        out: list[dict] = []
        for part in m.group(1).split(","):
            part = part.strip()
            if not part:
                continue
            if ":" in part:
                name, _, ty = part.partition(":")
                out.append({"name": name.strip(), "type": ty.strip() or "any"})
            else:
                out.append({"name": part, "type": "any"})
        return out

    # 3) Plain list
    out: list[dict] = []
    for part in sig.strip("()").split(","):
        part = part.strip()
        if part:
            out.append({"name": part, "type": "any"})
    return out


@dataclass
class ComponentSpec:
    """Frontend-enriched spec for a single component."""

    name: str
    file_path: str
    framework: str           # "react", "vue"
    props: list[dict] = field(default_factory=list)
    events: list[str] = field(default_factory=list)
    children: list[str] = field(default_factory=list)
    state: list[dict] = field(default_factory=list)
    hooks: list[str] = field(default_factory=list)
    api_calls: list[str] = field(default_factory=list)
    source_code: str = ""


@dataclass
class UITranslationResult:
    """Result of translating a single component."""

    component_name: str
    source_framework: str
    target_framework: str
    translated_code: str = ""
    validation_errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    status: str = "pending"


class UITranslator:
    """Prompt enrichment + validation layer for UI framework translation.

    Not a standalone engine — works with RewriteEngine for LLM calls.
    """

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.analyzer = FrontendAnalyzer(store)

    def detect_framework(self) -> str:
        """Detect source frontend framework from indexed components.

        Returns 'vue', 'react', or 'unknown'.
        No jQuery/Angular detection (see SPEC-M39).
        """
        nodes = self.store.get_all_nodes()

        vue_count = sum(1 for n in nodes if n["file_path"].endswith(".vue"))
        component_count = sum(1 for n in nodes if n["type"] == "component")
        hook_count = sum(1 for n in nodes if n["type"] == "hook")
        tsx_count = sum(1 for n in nodes if n["file_path"].endswith(".tsx"))

        if vue_count > 0:
            return "vue"
        if tsx_count > 0 or (component_count > 0 and hook_count > 0):
            return "react"
        if component_count > 0:
            return "react"  # JSX components without hooks -> likely React
        return "unknown"

    def extract_component_specs(self) -> list[ComponentSpec]:
        """Extract ComponentSpec for each component using knowledge graph.

        Uses FrontendAnalyzer data plus direct edge queries to build
        per-component specs with props, events, children, state, and API calls.
        """
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Detect framework once
        framework = self.detect_framework()

        # Filter relevant nodes
        components = [n for n in all_nodes if n["type"] == "component"]
        hooks = [n for n in all_nodes if n["type"] == "hook"]

        # Build edge lookup by source
        edges_by_source: dict[str, list[dict]] = {}
        for e in all_edges:
            edges_by_source.setdefault(e["source"], []).append(e)

        # Build edge lookup by type
        edges_by_type: dict[str, list[dict]] = {}
        for e in all_edges:
            edges_by_type.setdefault(e["type"], []).append(e)

        # Get API surface from analyzer
        api_surface = self.analyzer.get_api_surface(edges_by_type)
        url_to_callers: dict[str, list[str]] = {}
        for api in api_surface:
            for caller in api["callers"]:
                url_to_callers.setdefault(caller, []).append(api["url"])

        specs: list[ComponentSpec] = []
        for comp in components:
            comp_id = comp["id"]
            comp_name = comp["name"]
            comp_edges = edges_by_source.get(comp_id, [])

            # Children: targets of RENDERS edges
            children = [
                e["target"].rsplit("::", 1)[-1] if "::" in e["target"] else e["target"]
                for e in comp_edges if e["type"] == "RENDERS"
            ]

            # Props: from signature or PASSES_PROP edges
            props: list[dict] = []
            sig = comp.get("signature", "")
            if sig:
                props = _parse_props_signature(sig)

            # Events: from EMITS edges or decorators
            events: list[str] = []
            for e in comp_edges:
                if e["type"] == "EMITS":
                    events.append(e["target"])

            # State: from SUBSCRIBES edges (store subscriptions)
            state: list[dict] = []
            for e in comp_edges:
                if e["type"] == "SUBSCRIBES":
                    state.append({"name": e["target"], "type": "store"})

            # Hooks: from hook nodes referenced by this component
            comp_hooks: list[str] = []
            for e in comp_edges:
                if e["type"] == "CALLS":
                    target_name = e["target"].rsplit("::", 1)[-1] if "::" in e["target"] else e["target"]
                    # Check if target is a hook
                    for h in hooks:
                        if h["name"] == target_name:
                            comp_hooks.append(target_name)
                            break

            # API calls: from FETCHES edges
            api_calls: list[str] = []
            for e in comp_edges:
                if e["type"] == "FETCHES":
                    api_calls.append(e["target"])

            # Try to read source code from disk
            source_code = ""
            file_path = comp["file_path"]
            try:
                p = Path(file_path)
                if p.exists():
                    source_code = p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                pass

            specs.append(ComponentSpec(
                name=comp_name,
                file_path=file_path,
                framework=framework,
                props=props,
                events=events,
                children=children,
                state=state,
                hooks=comp_hooks,
                api_calls=api_calls,
                source_code=source_code,
            ))

        return specs

    def build_enriched_prompt(
        self,
        spec: ComponentSpec,
        target_framework: str,
    ) -> str:
        """Build translation prompt with structural context from knowledge graph.

        This is CodeBrain's value add: the LLM gets component contracts
        (props, events, children, state, API calls) as structured context,
        not just raw source code.
        """
        parts = [
            f"## Component: {spec.name}",
            f"Translate from {spec.framework} to {target_framework}.",
            "",
            "## Structural Context (from CodeBrain analysis)",
        ]

        if spec.props:
            parts.append(f"- Props: {json.dumps(spec.props)}")
            parts.append("  All props MUST exist in translated component.")

        if spec.events:
            if target_framework == "react":
                callbacks = [f"on{e[0].upper()}{e[1:]}" for e in spec.events]
                parts.append(f"- Events -> callback props: {callbacks}")
                parts.append("  Each event becomes an optional callback prop.")
            else:
                parts.append(f"- Events emitted: {spec.events}")

        if spec.children:
            parts.append(f"- Children rendered: {spec.children}")
            parts.append("  All child component references MUST exist.")

        if spec.state:
            parts.append(f"- Local state: {json.dumps(spec.state)}")
            if target_framework == "react":
                parts.append("  Use useState hooks for each state variable.")

        if spec.api_calls:
            parts.append(f"- API calls: {spec.api_calls}")
            parts.append("  All API endpoints MUST be called in translated code.")

        if spec.hooks:
            parts.append(f"- Lifecycle hooks: {spec.hooks}")

        parts.extend(["", "## Source Code", f"```\n{spec.source_code}\n```"])
        parts.extend([
            "",
            "## Task",
            f"Translate to a {target_framework} component.",
            "Preserve ALL props, events, children, and API calls.",
        ])
        return "\n".join(parts)

    def validate_translation(
        self,
        spec: ComponentSpec,
        translated_code: str,
        target_framework: str,
    ) -> list[str]:
        """Validate translated component preserves structural contracts.

        Checks that props, events/callbacks, children, and API calls
        all appear in the translated code.
        """
        errors: list[str] = []

        # Check props exist
        for prop in spec.props:
            if prop["name"] not in translated_code:
                errors.append(f"Missing prop '{prop['name']}'")

        # Check events/callbacks exist
        for event in spec.events:
            if target_framework == "react":
                # Vue emit -> React callback prop
                callback = f"on{event[0].upper()}{event[1:]}"
                if callback not in translated_code and event not in translated_code:
                    errors.append(
                        f"Missing callback prop '{callback}' (from event '{event}')"
                    )
            else:
                if event not in translated_code:
                    errors.append(f"Missing event '{event}'")

        # Check child components referenced
        for child in spec.children:
            if child not in translated_code:
                errors.append(f"Missing child component '{child}'")

        # Check API calls preserved
        for url in spec.api_calls:
            if url not in translated_code:
                errors.append(f"Missing API call to '{url}'")

        return errors

    def generate_wiring_checklist(self, target_framework: str) -> str:
        """Generate Markdown checklist of ecosystem wiring needed.

        Lists routes needing setup and stores needing migration,
        based on the knowledge graph analysis.
        """
        report = self.analyzer.analyze()

        lines = [f"# Wiring Checklist for {target_framework} Migration", ""]

        # Routes
        if report.route_map:
            lines.append("## Routing")
            lines.append("")
            if target_framework == "react":
                lines.append("Set up React Router with these routes:")
            elif target_framework == "vue":
                lines.append("Set up Vue Router with these routes:")
            else:
                lines.append(f"Set up routing for {target_framework}:")
            lines.append("")
            for route in report.route_map:
                comp = route.get("component", "?")
                path = route.get("path", "?")
                lines.append(f"- [ ] `{path}` -> `{comp}`")
            lines.append("")

        # State management
        if report.state_graph:
            lines.append("## State Management")
            lines.append("")
            if target_framework == "react":
                lines.append("Configure Redux/Zustand stores:")
            elif target_framework == "vue":
                lines.append("Configure Pinia/Vuex stores:")
            else:
                lines.append(f"Configure state management for {target_framework}:")
            lines.append("")
            for store_name, info in sorted(report.state_graph.items()):
                subs = info.get("subscribers", [])
                lines.append(
                    f"- [ ] `{store_name}` (used by {len(subs)} component(s))"
                )
            lines.append("")

        # API surface
        if report.api_surface:
            lines.append("## API Integration")
            lines.append("")
            lines.append("Ensure these API endpoints are still called:")
            lines.append("")
            for api in report.api_surface:
                lines.append(f"- [ ] `{api['url']}` (called by {api['caller_count']} component(s))")
            lines.append("")

        if not report.route_map and not report.state_graph and not report.api_surface:
            lines.append("No ecosystem wiring detected. Components are self-contained.")
            lines.append("")

        return "\n".join(lines)
