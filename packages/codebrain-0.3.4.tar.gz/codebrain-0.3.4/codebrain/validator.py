"""Pre-change impact validator.

Before an AI modification lands, this module answers:
  - What nodes were added / removed / modified?
  - Which callers break because a function was removed or renamed?
  - Which callers break because a signature changed?
  - What is the transitive blast radius?
  - What is the overall risk level?
"""

from __future__ import annotations

import ast
import json
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.parser.models import ParsedFile, ParsedNode
from codebrain.parser.registry import get_registry
from codebrain.utils import content_hash


class Severity(str, Enum):
    CRITICAL = "critical"  # Removed/renamed exported symbol with dependents
    HIGH = "high"          # Signature change on symbol with dependents
    MEDIUM = "medium"      # Internal symbol removed with dependents
    LOW = "low"            # Structural change, no known dependents
    INFO = "info"          # Addition, safe change


@dataclass(slots=True)
class Violation:
    severity: str
    category: str  # removed_symbol | signature_change | broken_caller | contract_violation
    message: str
    node_id: str
    file_path: str
    line: int = 0
    affected_dependents: int = 0
    callers: list[dict] = field(default_factory=list)


@dataclass(slots=True)
class ValidationReport:
    file_path: str
    is_valid: bool  # True if no CRITICAL or HIGH violations
    risk_score: float  # 0.0 (safe) to 1.0 (dangerous)
    violations: list[Violation] = field(default_factory=list)
    nodes_added: list[str] = field(default_factory=list)
    nodes_removed: list[str] = field(default_factory=list)
    nodes_modified: list[str] = field(default_factory=list)
    affected_files: list[str] = field(default_factory=list)
    summary: str = ""
    narrative: str = ""

    def __post_init__(self) -> None:
        if not self.narrative:
            self.narrative = self.generate_narrative()

    def to_dict(self) -> dict:
        return {
            "file_path": self.file_path,
            "is_valid": self.is_valid,
            "risk_score": round(self.risk_score, 3),
            "summary": self.summary,
            "violations": [
                {
                    "severity": v.severity,
                    "category": v.category,
                    "message": v.message,
                    "node_id": v.node_id,
                    "file_path": v.file_path,
                    "line": v.line,
                    "affected_dependents": v.affected_dependents,
                    "callers": v.callers[:10],
                }
                for v in self.violations
            ],
            "nodes_added": self.nodes_added,
            "nodes_removed": self.nodes_removed,
            "nodes_modified": self.nodes_modified,
            "affected_files": self.affected_files,
            "narrative": self.narrative,
        }

    def generate_narrative(self, total_symbols: int = 0) -> str:
        """Generate a human-readable narrative of the validation result."""
        parts = []

        if not self.violations:
            if self.nodes_added and not self.nodes_removed:
                parts.append(f"Safe change: added {len(self.nodes_added)} new symbol(s) with no breakage.")
            elif not self.nodes_added and not self.nodes_removed and not self.nodes_modified:
                parts.append("No structural changes detected.")
            else:
                parts.append("Change looks safe — no callers or contracts affected.")
        else:
            critical = [v for v in self.violations if v.severity in ("critical", "high")]
            if critical:
                parts.append(f"UNSAFE: {len(critical)} breaking violation(s) detected.")
                for v in critical[:3]:
                    if v.category == "removed_symbol":
                        dep_word = f"{v.affected_dependents} dependent(s)" if v.affected_dependents else "callers"
                        parts.append(f"  - Removing '{v.node_id}' breaks {dep_word}.")
                    elif v.category == "signature_change":
                        parts.append(f"  - Signature change in '{v.node_id}' may break callers.")
                    elif v.category == "broken_caller":
                        parts.append(f"  - '{v.node_id}' calls a symbol that no longer exists.")
            else:
                parts.append(f"Caution: {len(self.violations)} non-critical issue(s).")

        if self.affected_files:
            pct = (len(self.affected_files) / total_symbols * 100) if total_symbols else 0
            if pct > 20:
                parts.append(f"Blast radius: {len(self.affected_files)} files ({pct:.0f}% of codebase) — high impact.")
            elif self.affected_files:
                parts.append(f"Blast radius: {len(self.affected_files)} file(s) affected.")

        return " ".join(parts)


class ChangeValidator:
    """Validates proposed code changes against the existing knowledge graph."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.engine = QueryEngine(store)

    def validate_file(self, file_path: Path, repo_root: Path) -> ValidationReport:
        """Validate a modified file against the current graph.

        Parses the file's current on-disk content and compares against
        what the graph knows.
        """
        rel_path = file_path.relative_to(repo_root).as_posix()
        new_parsed = get_registry().parse(file_path, repo_root)
        return self._validate(rel_path, new_parsed)

    def validate_content(self, rel_path: str, new_content: str, repo_root: Path) -> ValidationReport:
        """Validate new content for a file before it's written."""
        # Write to a temp-like approach: parse from string
        new_hash = content_hash(new_content.encode())
        try:
            tree = ast.parse(new_content)
        except SyntaxError as e:
            return ValidationReport(
                file_path=rel_path,
                is_valid=False,
                risk_score=1.0,
                violations=[Violation(
                    severity=Severity.CRITICAL,
                    category="syntax_error",
                    message=f"Syntax error: {e}",
                    node_id="",
                    file_path=rel_path,
                    line=e.lineno or 0,
                )],
                summary="File has syntax errors and cannot be parsed.",
            )

        # Use the parser by writing a temp file, preserving directory structure
        # so that relative imports and node IDs resolve correctly.
        import tempfile
        with tempfile.TemporaryDirectory() as tmpdir:
            # Recreate the directory structure: tmpdir/pkg/subpkg/file.py
            target = Path(tmpdir) / rel_path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(new_content, encoding="utf-8")
            fake_root = Path(tmpdir)
            new_parsed = get_registry().parse(target, fake_root)
        # Fix the paths to use the real relative path
        new_parsed.path = rel_path
        for node in new_parsed.nodes:
            node.file_path = rel_path
            # Fix node IDs to use real path
            if "::" in node.id:
                _, qname = node.id.split("::", 1)
                node.id = f"{rel_path}::{qname}"
        for edge in new_parsed.edges:
            edge.file_path = rel_path
            if "::" in edge.source:
                parts = edge.source.split("::", 1)
                if parts[0] != rel_path:
                    edge.source = f"{rel_path}::{parts[1]}"
            if "::" in edge.target:
                parts = edge.target.split("::", 1)
                if parts[0] != rel_path:
                    edge.target = f"{rel_path}::{parts[1]}"

        return self._validate(rel_path, new_parsed)

    def validate_deletion(self, rel_path: str) -> ValidationReport:
        """Validate what breaks if a file is deleted."""
        old_nodes = self.store.get_nodes_by_file(rel_path)
        violations: list[Violation] = []
        affected_files: set[str] = set()

        for node in old_nodes:
            if node["type"] == "file":
                continue
            incoming = self.store.get_edges_to_symbol(node["id"], node["name"], node["qualified_name"])
            callers = [e for e in incoming if e["type"] in ("CALLS", "IMPORTS")]
            external_callers = [e for e in callers if e["file_path"] != rel_path]

            if external_callers:
                severity = Severity.CRITICAL if node["is_exported"] else Severity.HIGH
                del_caller_details = [
                    {"file": e["file_path"], "line": e["line"], "source": e["source"]}
                    for e in external_callers[:10]
                ]
                violations.append(Violation(
                    severity=severity,
                    category="removed_symbol",
                    message=f"Deleting file removes '{node['name']}' which is used by {len(external_callers)} external caller(s)",
                    node_id=node["id"],
                    file_path=rel_path,
                    line=node["line_start"],
                    affected_dependents=len(external_callers),
                    callers=del_caller_details,
                ))
                for e in external_callers:
                    affected_files.add(e["file_path"])

        risk = self._compute_risk(violations)
        return ValidationReport(
            file_path=rel_path,
            is_valid=not any(v.severity in (Severity.CRITICAL, Severity.HIGH) for v in violations),
            risk_score=risk,
            violations=violations,
            nodes_removed=[n["id"] for n in old_nodes],
            affected_files=sorted(affected_files),
            summary=self._build_summary([], [n["id"] for n in old_nodes], [], violations),
        )

    def _validate(self, rel_path: str, new_parsed: ParsedFile) -> ValidationReport:
        """Core validation logic comparing new parse against stored graph."""
        old_nodes = self.store.get_nodes_by_file(rel_path)
        old_by_name: dict[str, dict] = {}
        for n in old_nodes:
            if n["type"] != "file":
                old_by_name[n["name"]] = n

        new_by_name: dict[str, ParsedNode] = {}
        for n in new_parsed.nodes:
            if n.type != "file":
                new_by_name[n.name] = n

        old_names = set(old_by_name.keys())
        new_names = set(new_by_name.keys())

        added = new_names - old_names
        removed = old_names - new_names
        common = old_names & new_names

        violations: list[Violation] = []
        affected_files: set[str] = set()
        nodes_added: list[str] = []
        nodes_removed: list[str] = []
        nodes_modified: list[str] = []

        # --- Removed symbols ---
        for name in removed:
            old_node = old_by_name[name]
            incoming = self.store.get_edges_to_symbol(old_node["id"], old_node["name"], old_node["qualified_name"])
            callers = [e for e in incoming if e["type"] in ("CALLS", "IMPORTS")]
            external_callers = [e for e in callers if e["file_path"] != rel_path]

            nodes_removed.append(old_node["id"])

            if external_callers:
                severity = Severity.CRITICAL if old_node["is_exported"] else Severity.HIGH
                caller_details = [
                    {"file": e["file_path"], "line": e["line"], "source": e["source"]}
                    for e in external_callers[:10]
                ]
                violations.append(Violation(
                    severity=severity,
                    category="removed_symbol",
                    message=f"Removed '{name}' ({old_node['type']}) — {len(external_callers)} external caller(s) will break",
                    node_id=old_node["id"],
                    file_path=rel_path,
                    line=old_node["line_start"],
                    affected_dependents=len(external_callers),
                    callers=caller_details,
                ))
                for e in external_callers:
                    affected_files.add(e["file_path"])

                    # Add broken caller violations
                    violations.append(Violation(
                        severity=Severity.HIGH,
                        category="broken_caller",
                        message=f"'{e['source']}' calls removed symbol '{name}'",
                        node_id=e["source"],
                        file_path=e["file_path"],
                        line=e["line"],
                    ))
            elif callers:
                violations.append(Violation(
                    severity=Severity.MEDIUM,
                    category="removed_symbol",
                    message=f"Removed '{name}' ({old_node['type']}) — {len(callers)} internal caller(s)",
                    node_id=old_node["id"],
                    file_path=rel_path,
                    line=old_node["line_start"],
                    affected_dependents=len(callers),
                ))

        # --- Signature changes, decorator changes, type changes ---
        for name in common:
            old_node = old_by_name[name]
            new_node = new_by_name[name]

            # Type change (e.g. function -> class)
            if old_node["type"] != new_node.type:
                nodes_modified.append(old_node["id"])
                incoming = self.store.get_edges_to_symbol(old_node["id"], old_node["name"], old_node["qualified_name"])
                callers = [e for e in incoming if e["type"] in ("CALLS", "IMPORTS")]
                external_callers = [e for e in callers if e["file_path"] != rel_path]
                severity = Severity.HIGH if external_callers else Severity.MEDIUM
                violations.append(Violation(
                    severity=severity,
                    category="type_change",
                    message=f"'{name}' changed type: {old_node['type']} -> {new_node.type}",
                    node_id=old_node["id"],
                    file_path=rel_path,
                    line=new_node.line_start,
                    affected_dependents=len(external_callers),
                ))
                for e in external_callers:
                    affected_files.add(e["file_path"])
                continue

            if old_node["type"] in ("function", "method") and new_node.type in ("function", "method"):
                old_sig = old_node["signature"]
                new_sig = new_node.signature

                if old_sig and new_sig and old_sig != new_sig:
                    # Check if the change is backward-compatible (only added optional params)
                    if self._is_signature_compatible(old_sig, new_sig):
                        nodes_modified.append(old_node["id"])
                        continue

                    incoming = self.store.get_edges_to_symbol(old_node["id"], old_node["name"], old_node["qualified_name"])
                    callers = [e for e in incoming if e["type"] == "CALLS"]
                    external_callers = [e for e in callers if e["file_path"] != rel_path]

                    nodes_modified.append(old_node["id"])

                    if external_callers:
                        sig_caller_details = [
                            {"file": e["file_path"], "line": e["line"], "source": e["source"]}
                            for e in external_callers[:10]
                        ]
                        violations.append(Violation(
                            severity=Severity.HIGH,
                            category="signature_change",
                            message=f"Signature of '{name}' changed: {old_sig} -> {new_sig} -- {len(external_callers)} external caller(s) may break",
                            node_id=old_node["id"],
                            file_path=rel_path,
                            line=new_node.line_start,
                            affected_dependents=len(external_callers),
                            callers=sig_caller_details,
                        ))
                        for e in external_callers:
                            affected_files.add(e["file_path"])
                    elif callers:
                        violations.append(Violation(
                            severity=Severity.MEDIUM,
                            category="signature_change",
                            message=f"Signature of '{name}' changed: {old_sig} -> {new_sig} -- {len(callers)} internal caller(s)",
                            node_id=old_node["id"],
                            file_path=rel_path,
                            line=new_node.line_start,
                            affected_dependents=len(callers),
                        ))
                    else:
                        violations.append(Violation(
                            severity=Severity.LOW,
                            category="signature_change",
                            message=f"Signature of '{name}' changed: {old_sig} -> {new_sig} -- no known callers",
                            node_id=old_node["id"],
                            file_path=rel_path,
                            line=new_node.line_start,
                        ))

            # Decorator changes (e.g. removing @dataclass, @property, @abstractmethod)
            old_decorators = old_node.get("decorators") or "[]"
            if isinstance(old_decorators, str):
                try:
                    old_decorators = json.loads(old_decorators)
                except (ValueError, TypeError):
                    old_decorators = []
            new_decorators = list(new_node.decorators) if new_node.decorators else []
            old_dec_set = set(old_decorators)
            new_dec_set = set(new_decorators)
            removed_decs = old_dec_set - new_dec_set
            # Only flag structurally significant decorators
            _SIGNIFICANT_DECS = {"dataclass", "property", "staticmethod", "classmethod",
                                 "abstractmethod", "overload", "cached_property", "lru_cache",
                                 "validator", "field_validator", "model_validator"}
            significant_removed = {d for d in removed_decs if any(s in d for s in _SIGNIFICANT_DECS)}
            if significant_removed:
                nodes_modified.append(old_node["id"])
                incoming = self.store.get_edges_to_symbol(old_node["id"], old_node["name"], old_node["qualified_name"])
                callers = [e for e in incoming if e["type"] in ("CALLS", "IMPORTS")]
                external_callers = [e for e in callers if e["file_path"] != rel_path]
                severity = Severity.HIGH if external_callers else Severity.MEDIUM
                violations.append(Violation(
                    severity=severity,
                    category="decorator_change",
                    message=f"Removed decorator(s) from '{name}': {', '.join(sorted(significant_removed))} -- may change behavior",
                    node_id=old_node["id"],
                    file_path=rel_path,
                    line=new_node.line_start,
                    affected_dependents=len(external_callers),
                ))
                for e in external_callers:
                    affected_files.add(e["file_path"])

        # --- Added symbols ---
        for name in added:
            new_node = new_by_name[name]
            node_id = f"{rel_path}::{new_node.qualified_name}"
            nodes_added.append(node_id)

        # --- Transitive impact: collect all affected files ---
        for name in removed | {n for n in common if old_by_name[n]["id"] in nodes_modified}:
            if name in old_by_name:
                node_id = old_by_name[name]["id"]
                impacted = self.engine.impact_of_change(node_id, max_depth=5)
                for entry in impacted:
                    # Resolve to a file
                    target_node = self.store.get_node(entry["node_id"])
                    if target_node:
                        affected_files.add(target_node["file_path"])

        affected_files.discard(rel_path)
        risk = self._compute_risk(violations)

        return ValidationReport(
            file_path=rel_path,
            is_valid=not any(v.severity in (Severity.CRITICAL, Severity.HIGH) for v in violations),
            risk_score=risk,
            violations=sorted(violations, key=lambda v: list(Severity).index(Severity(v.severity))),
            nodes_added=nodes_added,
            nodes_removed=nodes_removed,
            nodes_modified=nodes_modified,
            affected_files=sorted(affected_files),
            summary=self._build_summary(nodes_added, nodes_removed, nodes_modified, violations),
        )

    @staticmethod
    def _is_signature_compatible(old_sig: str, new_sig: str) -> bool:
        """Check if a signature change is backward-compatible.

        A change is compatible if all original parameters are preserved
        and any new parameters have default values.
        """
        try:
            # Parse signatures as function defs to extract args
            old_func = ast.parse(f"def f{old_sig}: pass").body[0]
            new_func = ast.parse(f"def f{new_sig}: pass").body[0]
        except SyntaxError:
            return False

        old_args = old_func.args
        new_args = new_func.args

        # Get positional arg names (excluding self/cls)
        def _param_names(args_node: ast.arguments) -> list[str]:
            names = [a.arg for a in args_node.args]
            if names and names[0] in ("self", "cls"):
                names = names[1:]
            return names

        old_names = _param_names(old_args)
        new_names = _param_names(new_args)

        # All old params must still exist in the same order at the start
        if new_names[:len(old_names)] != old_names:
            return False

        # Any new params must have defaults
        # In ast, defaults are right-aligned: if there are 3 args and 1 default,
        # the default applies to the last arg
        added_params = new_names[len(old_names):]
        if not added_params:
            # Params didn't change — maybe return type or annotation changed
            return True

        num_new_total = len(new_args.args)
        # Filter out self/cls for counting
        has_self = new_args.args and new_args.args[0].arg in ("self", "cls")
        num_non_self = num_new_total - (1 if has_self else 0)
        num_defaults = len(new_args.defaults)

        # Number of params without defaults
        num_required = num_non_self - num_defaults
        # All old params were required (or had defaults) — we just need
        # every added param to have a default
        old_required = len(old_names)
        if num_required > old_required:
            # New required params were added — not compatible
            return False

        # Also check *args/**kwargs haven't been removed
        if old_args.vararg and not new_args.vararg:
            return False
        if old_args.kwarg and not new_args.kwarg:
            return False

        return True

    def _compute_risk(self, violations: list[Violation]) -> float:
        """Compute a 0-1 risk score from violations with diminishing returns.

        Uses a logarithmic scale so 1 CRITICAL = 0.7, 2 = 0.85, 5 = 0.95.
        This prevents the score from becoming meaningless when many violations exist.
        """
        if not violations:
            return 0.0
        weights = {
            Severity.CRITICAL: 1.0,
            Severity.HIGH: 0.5,
            Severity.MEDIUM: 0.2,
            Severity.LOW: 0.05,
            Severity.INFO: 0.0,
        }
        total = sum(weights.get(Severity(v.severity), 0) for v in violations)
        # Logarithmic diminishing returns: approaches 1.0 but never flat-caps
        import math
        return min(1.0, 1.0 - 1.0 / (1.0 + total))

    def _build_summary(
        self,
        added: list[str],
        removed: list[str],
        modified: list[str],
        violations: list[Violation],
    ) -> str:
        parts: list[str] = []
        if added:
            parts.append(f"{len(added)} symbol(s) added")
        if removed:
            parts.append(f"{len(removed)} symbol(s) removed")
        if modified:
            parts.append(f"{len(modified)} symbol(s) modified")

        critical = sum(1 for v in violations if v.severity == Severity.CRITICAL)
        high = sum(1 for v in violations if v.severity == Severity.HIGH)

        if critical:
            parts.append(f"{critical} CRITICAL violation(s)")
        if high:
            parts.append(f"{high} HIGH violation(s)")
        if not violations:
            parts.append("no violations detected")

        return "; ".join(parts) + "."
