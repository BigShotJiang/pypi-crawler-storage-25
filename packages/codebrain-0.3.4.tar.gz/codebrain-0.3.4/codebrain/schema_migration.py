"""Schema migration generator — detect ORM models, extract DB schema, diff, generate migrations."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from codebrain.graph.store import GraphStore

# Type normalization map: ORM type → SQL canonical type
CANONICAL_TYPES = {
    "Integer": "INTEGER", "BigInteger": "BIGINT", "SmallInteger": "SMALLINT",
    "String": "VARCHAR", "Text": "TEXT", "Boolean": "BOOLEAN",
    "Float": "FLOAT", "Numeric": "DECIMAL", "Date": "DATE",
    "DateTime": "TIMESTAMP", "LargeBinary": "BLOB",
    "CharField": "VARCHAR", "IntegerField": "INTEGER", "TextField": "TEXT",
    "FloatField": "FLOAT", "BooleanField": "BOOLEAN", "DateField": "DATE",
    "DateTimeField": "TIMESTAMP", "DecimalField": "DECIMAL",
    "AutoField": "SERIAL", "BigAutoField": "BIGSERIAL",
    "JSONField": "JSONB", "UUIDField": "UUID",
    "Int": "INTEGER", "BigInt": "BIGINT",
}


@dataclass
class Column:
    """A single database column extracted from ORM metadata."""
    name: str
    type: str  # raw ORM type, e.g. "String(255)"
    nullable: bool = True
    primary_key: bool = False
    default: str | None = None
    foreign_key: bool = False


@dataclass
class Relationship:
    """A foreign-key relationship between two tables."""
    source_table: str
    target_table: str
    source_column: str = ""
    edge_type: str = "REFERENCES"


@dataclass
class Table:
    """A database table extracted from an ORM class."""
    name: str
    class_name: str
    file_path: str
    columns: list[Column] = field(default_factory=list)
    relationships: list[Relationship] = field(default_factory=list)


@dataclass
class DatabaseSchema:
    """Full schema extracted from a codebase."""
    orm_type: str  # "sqlalchemy", "django", or "unknown"
    tables: list[Table] = field(default_factory=list)

    def get_table(self, name: str) -> Table | None:
        for t in self.tables:
            if t.name == name:
                return t
        return None


@dataclass
class SchemaDiff:
    """Difference between two database schemas."""
    added_tables: list[Table] = field(default_factory=list)
    removed_tables: list[Table] = field(default_factory=list)
    added_columns: dict[str, list[Column]] = field(default_factory=dict)  # table_name -> columns
    removed_columns: dict[str, list[Column]] = field(default_factory=dict)
    type_changes: list[dict[str, Any]] = field(default_factory=list)
    added_relationships: list[Relationship] = field(default_factory=list)
    removed_relationships: list[Relationship] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        return bool(
            self.added_tables or self.removed_tables
            or self.added_columns or self.removed_columns
            or self.type_changes
            or self.added_relationships or self.removed_relationships
        )


def _parse_column_entry(entry: str) -> Column:
    """Parse a single column entry like 'name/String(100)/notnull,pk' into a Column."""
    parts = entry.split("/", 2)
    name = parts[0] if len(parts) > 0 else ""
    col_type = parts[1] if len(parts) > 1 else ""
    flags_str = parts[2] if len(parts) > 2 else ""

    nullable = True
    primary_key = False
    default = None
    foreign_key = False

    if flags_str:
        flags = [f.strip() for f in flags_str.split(",")]
        for flag in flags:
            if flag == "pk":
                primary_key = True
            elif flag == "notnull":
                nullable = False
            elif flag == "fk":
                foreign_key = True
            elif flag.startswith("default="):
                default = flag[len("default="):]

    return Column(
        name=name,
        type=col_type,
        nullable=nullable,
        primary_key=primary_key,
        default=default,
        foreign_key=foreign_key,
    )


def _normalize_type(raw: str) -> str:
    """Normalize an ORM type to a canonical SQL type.

    Examples:
        "String(255)" → "VARCHAR(255)"
        "Integer" → "INTEGER"
        "CharField(100)" → "VARCHAR(100)"
    """
    if not raw:
        return raw

    # Extract base type and optional length
    m = re.match(r"^(\w+)(\(.*\))?$", raw)
    if not m:
        return raw.upper()

    base = m.group(1)
    length = m.group(2) or ""

    canonical = CANONICAL_TYPES.get(base, base.upper())
    return canonical + length


class SchemaMigrator:
    """Extract database schemas from ORM models and generate migrations."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store

    def detect_orm(self) -> str:
        """Detect which ORM framework is used by inspecting node decorators.

        Returns 'sqlalchemy', 'django', or 'unknown'.
        """
        nodes = self.store.get_all_nodes(type_filter="class")
        for node in nodes:
            decorators = node.get("decorators", "[]")
            if isinstance(decorators, str):
                try:
                    import json
                    decorators = json.loads(decorators)
                except (ValueError, TypeError):
                    decorators = []

            if "sqlalchemy" in decorators or "orm_model" in decorators:
                # Check specifically for sqlalchemy vs django
                if "sqlalchemy" in decorators:
                    return "sqlalchemy"
                if "django" in decorators:
                    return "django"
            if "django" in decorators:
                return "django"

        return "unknown"

    def extract_schema(self) -> DatabaseSchema:
        """Extract the full database schema from ORM class nodes.

        Parses the cols: summary format from nodes that have 'orm_model'
        in their decorators.
        """
        import json as _json

        orm_type = self.detect_orm()
        tables: list[Table] = []

        nodes = self.store.get_all_nodes(type_filter="class")
        for node in nodes:
            decorators = node.get("decorators", "[]")
            if isinstance(decorators, str):
                try:
                    decorators = _json.loads(decorators)
                except (ValueError, TypeError):
                    decorators = []

            if "orm_model" not in decorators:
                continue

            summary = node.get("summary", "") or ""
            table_name = self._extract_table_name(summary, node["name"])
            columns = self._extract_columns(summary)

            # Extract relationships from REFERENCES edges
            relationships: list[Relationship] = []
            edges = self.store.get_edges_from(node["id"])
            for edge in edges:
                if edge.get("type") == "REFERENCES":
                    relationships.append(Relationship(
                        source_table=table_name,
                        target_table=edge["target"],
                        edge_type="REFERENCES",
                    ))

            table = Table(
                name=table_name,
                class_name=node["name"],
                file_path=node.get("file_path", ""),
                columns=columns,
                relationships=relationships,
            )
            tables.append(table)

        return DatabaseSchema(orm_type=orm_type, tables=tables)

    def _extract_table_name(self, summary: str, class_name: str) -> str:
        """Extract table name from summary or default to lowercase class name."""
        m = re.search(r"table=(\S+)", summary)
        if m:
            return m.group(1)
        # Default: lowercase class name + 's' (convention)
        return class_name.lower()

    def _extract_columns(self, summary: str) -> list[Column]:
        """Parse column entries from the summary cols: format."""
        m = re.search(r"cols:(\S+)", summary)
        if not m:
            return []

        cols_str = m.group(1)
        columns: list[Column] = []
        for entry in cols_str.split(";"):
            entry = entry.strip()
            if entry:
                columns.append(_parse_column_entry(entry))
        return columns

    def diff(self, old_schema: DatabaseSchema, new_schema: DatabaseSchema) -> SchemaDiff:
        """Compare two schemas and return the differences."""
        result = SchemaDiff()

        old_tables = {t.name: t for t in old_schema.tables}
        new_tables = {t.name: t for t in new_schema.tables}

        # Added / removed tables
        for name, table in new_tables.items():
            if name not in old_tables:
                result.added_tables.append(table)
        for name, table in old_tables.items():
            if name not in new_tables:
                result.removed_tables.append(table)

        # Column changes in tables that exist in both
        for name in old_tables:
            if name not in new_tables:
                continue
            old_t = old_tables[name]
            new_t = new_tables[name]

            old_cols = {c.name: c for c in old_t.columns}
            new_cols = {c.name: c for c in new_t.columns}

            # Added columns
            added = [c for n, c in new_cols.items() if n not in old_cols]
            if added:
                result.added_columns[name] = added

            # Removed columns
            removed = [c for n, c in old_cols.items() if n not in new_cols]
            if removed:
                result.removed_columns[name] = removed

            # Type changes
            for col_name in old_cols:
                if col_name not in new_cols:
                    continue
                old_type = _normalize_type(old_cols[col_name].type)
                new_type = _normalize_type(new_cols[col_name].type)
                if old_type != new_type:
                    result.type_changes.append({
                        "table": name,
                        "column": col_name,
                        "old_type": old_cols[col_name].type,
                        "new_type": new_cols[col_name].type,
                        "old_normalized": old_type,
                        "new_normalized": new_type,
                    })

        # Relationship changes
        old_rels = set()
        new_rels = set()
        for t in old_schema.tables:
            for r in t.relationships:
                old_rels.add((r.source_table, r.target_table))
        for t in new_schema.tables:
            for r in t.relationships:
                new_rels.add((r.source_table, r.target_table))

        for src, tgt in new_rels - old_rels:
            result.added_relationships.append(Relationship(source_table=src, target_table=tgt))
        for src, tgt in old_rels - new_rels:
            result.removed_relationships.append(Relationship(source_table=src, target_table=tgt))

        return result

    def generate_sql(self, diff: SchemaDiff) -> str:
        """Generate plain SQL migration statements from a schema diff."""
        lines: list[str] = []
        lines.append("-- Auto-generated schema migration")
        lines.append("")

        # CREATE TABLE for added tables
        for table in diff.added_tables:
            lines.append(f"CREATE TABLE {table.name} (")
            col_defs: list[str] = []
            for col in table.columns:
                parts = [f"    {col.name} {_normalize_type(col.type)}"]
                if col.primary_key:
                    parts.append("PRIMARY KEY")
                if not col.nullable:
                    parts.append("NOT NULL")
                if col.default is not None:
                    parts.append(f"DEFAULT {col.default}")
                col_defs.append(" ".join(parts))
            lines.append(",\n".join(col_defs))
            lines.append(");")
            lines.append("")

        # DROP TABLE for removed tables
        for table in diff.removed_tables:
            lines.append(f"DROP TABLE IF EXISTS {table.name};")
            lines.append("")

        # ALTER TABLE ADD COLUMN
        for table_name, columns in diff.added_columns.items():
            for col in columns:
                parts = [f"ALTER TABLE {table_name} ADD COLUMN {col.name} {_normalize_type(col.type)}"]
                if col.primary_key:
                    parts.append("PRIMARY KEY")
                if not col.nullable:
                    parts.append("NOT NULL")
                if col.default is not None:
                    parts.append(f"DEFAULT {col.default}")
                lines.append(" ".join(parts) + ";")
            lines.append("")

        # ALTER TABLE DROP COLUMN
        for table_name, columns in diff.removed_columns.items():
            for col in columns:
                lines.append(f"ALTER TABLE {table_name} DROP COLUMN {col.name};")
            lines.append("")

        # Type changes as comments
        for change in diff.type_changes:
            lines.append(
                f"-- TYPE CHANGE: {change['table']}.{change['column']} "
                f"{change['old_type']} -> {change['new_type']} "
                f"(requires manual review)"
            )

        return "\n".join(lines).strip()

    def generate_alembic(self, diff: SchemaDiff) -> str:
        """Generate Alembic migration script from a schema diff."""
        lines: list[str] = []
        lines.append('"""Auto-generated Alembic migration."""')
        lines.append("")
        lines.append("from alembic import op")
        lines.append("import sqlalchemy as sa")
        lines.append("")
        lines.append("")
        lines.append("def upgrade() -> None:")

        has_upgrade = False

        for table in diff.added_tables:
            has_upgrade = True
            cols_code: list[str] = []
            for col in table.columns:
                sa_type = _normalize_type(col.type)
                col_parts = [f"sa.Column('{col.name}', sa.{sa_type}"]
                if col.primary_key:
                    col_parts.append(", primary_key=True")
                if not col.nullable:
                    col_parts.append(", nullable=False")
                col_parts.append(")")
                cols_code.append("        " + "".join(col_parts) + ",")
            lines.append(f"    op.create_table(")
            lines.append(f"        '{table.name}',")
            lines.extend(cols_code)
            lines.append(f"    )")

        for table_name, columns in diff.added_columns.items():
            has_upgrade = True
            for col in columns:
                sa_type = _normalize_type(col.type)
                nullable = "True" if col.nullable else "False"
                lines.append(
                    f"    op.add_column('{table_name}', "
                    f"sa.Column('{col.name}', sa.{sa_type}, nullable={nullable}))"
                )

        for table_name, columns in diff.removed_columns.items():
            has_upgrade = True
            for col in columns:
                lines.append(f"    op.drop_column('{table_name}', '{col.name}')")

        for table in diff.removed_tables:
            has_upgrade = True
            lines.append(f"    op.drop_table('{table.name}')")

        if not has_upgrade:
            lines.append("    pass")

        lines.append("")
        lines.append("")
        lines.append("def downgrade() -> None:")

        has_downgrade = False

        # Reverse of upgrade
        for table in diff.added_tables:
            has_downgrade = True
            lines.append(f"    op.drop_table('{table.name}')")

        for table_name, columns in diff.added_columns.items():
            has_downgrade = True
            for col in columns:
                lines.append(f"    op.drop_column('{table_name}', '{col.name}')")

        for table_name, columns in diff.removed_columns.items():
            has_downgrade = True
            for col in columns:
                sa_type = _normalize_type(col.type)
                nullable = "True" if col.nullable else "False"
                lines.append(
                    f"    op.add_column('{table_name}', "
                    f"sa.Column('{col.name}', sa.{sa_type}, nullable={nullable}))"
                )

        for table in diff.removed_tables:
            has_downgrade = True
            cols_code = []
            for col in table.columns:
                sa_type = _normalize_type(col.type)
                col_parts = [f"sa.Column('{col.name}', sa.{sa_type}"]
                if col.primary_key:
                    col_parts.append(", primary_key=True")
                if not col.nullable:
                    col_parts.append(", nullable=False")
                col_parts.append(")")
                cols_code.append("        " + "".join(col_parts) + ",")
            lines.append(f"    op.create_table(")
            lines.append(f"        '{table.name}',")
            lines.extend(cols_code)
            lines.append(f"    )")

        if not has_downgrade:
            lines.append("    pass")

        return "\n".join(lines)

    def generate_flyway(self, diff: SchemaDiff) -> str:
        """Generate Flyway-style versioned SQL migration."""
        lines: list[str] = []
        lines.append("-- V1__auto_generated_migration.sql")
        lines.append("-- Flyway versioned migration")
        lines.append("")

        sql_body = self.generate_sql(diff)
        # Strip the header comment from generate_sql since we have our own
        for line in sql_body.split("\n"):
            if line.startswith("-- Auto-generated"):
                continue
            lines.append(line)

        return "\n".join(lines).strip()

    def to_dict(self, schema: DatabaseSchema) -> dict[str, Any]:
        """Convert a DatabaseSchema to a JSON-serializable dict."""
        return {
            "orm_type": schema.orm_type,
            "tables": [
                {
                    "name": t.name,
                    "class_name": t.class_name,
                    "file_path": t.file_path,
                    "columns": [
                        {
                            "name": c.name,
                            "type": c.type,
                            "normalized_type": _normalize_type(c.type),
                            "nullable": c.nullable,
                            "primary_key": c.primary_key,
                            "default": c.default,
                            "foreign_key": c.foreign_key,
                        }
                        for c in t.columns
                    ],
                    "relationships": [
                        {
                            "source_table": r.source_table,
                            "target_table": r.target_table,
                        }
                        for r in t.relationships
                    ],
                }
                for t in schema.tables
            ],
        }

    def diff_to_dict(self, diff: SchemaDiff) -> dict[str, Any]:
        """Convert a SchemaDiff to a JSON-serializable dict."""
        return {
            "has_changes": diff.has_changes,
            "added_tables": [t.name for t in diff.added_tables],
            "removed_tables": [t.name for t in diff.removed_tables],
            "added_columns": {
                table: [{"name": c.name, "type": c.type} for c in cols]
                for table, cols in diff.added_columns.items()
            },
            "removed_columns": {
                table: [{"name": c.name, "type": c.type} for c in cols]
                for table, cols in diff.removed_columns.items()
            },
            "type_changes": diff.type_changes,
            "added_relationships": [
                {"source": r.source_table, "target": r.target_table}
                for r in diff.added_relationships
            ],
            "removed_relationships": [
                {"source": r.source_table, "target": r.target_table}
                for r in diff.removed_relationships
            ],
        }
