"""Architecture detection — pattern, framework, DB, infra, boundaries.

Reads the knowledge graph built by parsers (including M33 infra/ORM tags)
and synthesizes an architectural diagnosis: what pattern the codebase follows,
what frameworks it uses, what role each module plays, and where architectural
boundaries are violated.
"""

from __future__ import annotations

import json as _json
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from codebrain.analyzer import StructuralAnalyzer
from codebrain.graph.store import GraphStore
from codebrain.modernize import infer_module_role


def _parse_decorators(raw: str | list) -> list[str]:
    """Parse decorators which may be a JSON string or already a list."""
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str) and raw.startswith("["):
        try:
            return _json.loads(raw)
        except (ValueError, TypeError):
            return []
    return []


# ---------------------------------------------------------------------------
# Report dataclass
# ---------------------------------------------------------------------------


@dataclass
class ArchitectureReport:
    """Complete architecture analysis result."""

    # High-level pattern
    pattern: str = ""  # mvc, layered, event_driven, repository_service, monolith
    secondary_pattern: str = ""
    pattern_confidence: float = 0.0
    pattern_evidence: list[str] = field(default_factory=list)

    # Frameworks
    frameworks: list[str] = field(default_factory=list)
    framework_evidence: list[str] = field(default_factory=list)

    # Database — reads M33 ORM tags only
    db_technology: str = ""
    db_evidence: list[str] = field(default_factory=list)

    # Infrastructure — reads M33 infra nodes
    infrastructure: list[str] = field(default_factory=list)
    infra_evidence: list[str] = field(default_factory=list)

    # Module role map
    module_roles: dict[str, str] = field(default_factory=dict)

    # Layer mapping
    layers: dict[str, int] = field(default_factory=dict)

    # Boundary violations
    boundary_violations: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        """JSON-serializable dictionary."""
        return {
            "pattern": self.pattern,
            "secondary_pattern": self.secondary_pattern,
            "pattern_confidence": self.pattern_confidence,
            "pattern_evidence": self.pattern_evidence,
            "frameworks": self.frameworks,
            "framework_evidence": self.framework_evidence,
            "db_technology": self.db_technology,
            "db_evidence": self.db_evidence,
            "infrastructure": self.infrastructure,
            "infra_evidence": self.infra_evidence,
            "module_roles": self.module_roles,
            "layers": self.layers,
            "boundary_violations": self.boundary_violations,
        }

    def narrative(self) -> str:
        """Human-readable summary."""
        parts: list[str] = []

        if self.pattern:
            conf = f"{self.pattern_confidence:.0%}"
            line = f"Architecture: {self.pattern} ({conf} confidence)"
            if self.secondary_pattern:
                line += f", secondary: {self.secondary_pattern}"
            parts.append(line)

        if self.frameworks:
            parts.append(f"Frameworks: {', '.join(self.frameworks)}")

        if self.db_technology:
            parts.append(f"Database: {self.db_technology}")

        if self.infrastructure:
            parts.append(f"Infrastructure: {', '.join(self.infrastructure)}")

        # Role distribution
        if self.module_roles:
            role_counts = Counter(self.module_roles.values())
            top = role_counts.most_common(5)
            dist = ", ".join(f"{r}: {c}" for r, c in top)
            parts.append(f"Module roles: {dist}")

        if self.boundary_violations:
            parts.append(f"Boundary violations: {len(self.boundary_violations)}")
            for v in self.boundary_violations[:5]:
                parts.append(f"  - {v.get('violation', '?')}: {v.get('source_file', '?')} → {v.get('target_file', '?')}")

        if self.pattern_evidence:
            parts.append("\nEvidence:")
            for e in self.pattern_evidence:
                parts.append(f"  - {e}")

        return "\n".join(parts)


# ---------------------------------------------------------------------------
# Framework detection config
# ---------------------------------------------------------------------------

_FRAMEWORK_RULES: list[dict] = [
    {
        "name": "django",
        "imports": ["django"],
        "threshold": 3,
        "files": ["manage.py", "wsgi.py"],
    },
    {
        "name": "fastapi",
        "imports": ["fastapi"],
        "threshold": 3,
        "decorators": ["app.get", "app.post", "app.put", "app.delete"],
    },
    {
        "name": "flask",
        "imports": ["flask"],
        "threshold": 3,
        "decorators": ["app.route"],
    },
    {
        "name": "spring_boot",
        "imports": [],
        "threshold": 0,
        "decorators": ["SpringBootApplication", "RestController", "Controller"],
        "files": ["pom.xml", "build.gradle"],
    },
    {
        "name": "express",
        "imports": ["express"],
        "threshold": 3,
    },
    {
        "name": "nextjs",
        "imports": ["next/"],  # "next/" avoids matching Python's next()
        "threshold": 1,
        "files": ["next.config.js", "next.config.ts", "next.config.mjs"],
    },
    {
        "name": "angular",
        "imports": ["@angular/core", "@angular"],
        "threshold": 3,
        "files": ["angular.json"],
    },
    {
        "name": "react",
        "imports": ["react", "react-dom"],
        "threshold": 3,
    },
    {
        "name": "vue",
        "imports": ["vue"],
        "threshold": 3,
    },
    {
        "name": "celery",
        "imports": ["celery"],
        "threshold": 3,
    },
    {
        "name": "task_queue",
        "imports": ["dramatiq", "rq"],
        "threshold": 3,
    },
    {
        "name": "click",
        "imports": ["click"],
        "threshold": 3,
        "decorators": ["click.command", "click.group", "click.option", "click.argument"],
    },
    {
        "name": "pytest",
        "imports": ["pytest"],
        "threshold": 3,
        "files": ["conftest.py", "pytest.ini"],
    },
    {
        "name": "sqlalchemy",
        "imports": ["sqlalchemy"],
        "threshold": 3,
    },
    {
        "name": "pydantic",
        "imports": ["pydantic"],
        "threshold": 3,
    },
    # Go frameworks
    {
        "name": "gin",
        "imports": ["github.com/gin-gonic/gin"],
        "threshold": 1,
    },
    {
        "name": "echo",
        "imports": ["github.com/labstack/echo"],
        "threshold": 1,
    },
    {
        "name": "fiber",
        "imports": ["github.com/gofiber/fiber"],
        "threshold": 1,
    },
    {
        "name": "gorilla_mux",
        "imports": ["github.com/gorilla/mux"],
        "threshold": 1,
    },
    {
        "name": "gorm",
        "imports": ["gorm.io/gorm"],
        "threshold": 1,
    },
    # Rust frameworks
    {
        "name": "actix_web",
        "imports": ["actix_web", "actix_rt"],
        "threshold": 1,
    },
    {
        "name": "axum",
        "imports": ["axum"],
        "threshold": 1,
    },
    {
        "name": "rocket",
        "imports": ["rocket"],
        "threshold": 1,
        "decorators": ["get", "post", "put", "delete", "launch"],
    },
    {
        "name": "tokio",
        "imports": ["tokio"],
        "threshold": 1,
    },
    {
        "name": "diesel",
        "imports": ["diesel"],
        "threshold": 1,
    },
    {
        "name": "serde",
        "imports": ["serde"],
        "threshold": 1,
        "decorators": ["Serialize", "Deserialize"],
    },
    # C# / .NET frameworks
    {
        "name": "aspnet_core",
        "imports": ["Microsoft.AspNetCore"],
        "threshold": 1,
        "decorators": ["ApiController", "HttpGet", "HttpPost", "Authorize"],
        "files": ["Program.cs", "Startup.cs"],
    },
    {
        "name": "entity_framework",
        "imports": ["Microsoft.EntityFrameworkCore", "System.Data.Entity"],
        "threshold": 1,
    },
    {
        "name": "blazor",
        "imports": ["Microsoft.AspNetCore.Components"],
        "threshold": 1,
    },
    # Kotlin frameworks
    {
        "name": "ktor",
        "imports": ["io.ktor"],
        "threshold": 1,
    },
    {
        "name": "spring_kotlin",
        "imports": ["org.springframework"],
        "threshold": 1,
        "files": ["build.gradle.kts"],
    },
    {
        "name": "exposed",
        "imports": ["org.jetbrains.exposed"],
        "threshold": 1,
    },
    {
        "name": "android",
        "imports": ["android.", "androidx."],
        "threshold": 3,
        "files": ["AndroidManifest.xml"],
    },
]

# MVC frameworks
_MVC_FRAMEWORKS = {"django", "flask", "spring_boot", "rails", "aspnet_core", "spring_kotlin"}


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------


class ArchitectureDetector:
    """Detect codebase architecture from the knowledge graph.

    Takes a GraphStore, performs bulk queries, and returns an ArchitectureReport.
    """

    def __init__(self, store: GraphStore) -> None:
        self._store = store

    def detect(self) -> ArchitectureReport:
        """Run full architecture detection."""
        report = ArchitectureReport()

        # Bulk fetch
        all_nodes = self._store.get_all_nodes()
        all_edges = self._store.get_all_edges()

        if not all_nodes:
            return report

        # Build indexes
        nodes_by_file = defaultdict(list)
        file_paths: set[str] = set()
        for n in all_nodes:
            fp = n.get("file_path", "")
            if fp:
                nodes_by_file[fp].append(n)
                file_paths.add(fp)

        edges_by_type = defaultdict(list)
        for e in all_edges:
            edges_by_type[e.get("type", "")].append(e)

        # Step 1: Module roles
        report.module_roles = self._assign_roles(dict(nodes_by_file))

        # Step 2: Layers (from StructuralAnalyzer)
        report.layers = self._detect_layers()

        # Step 3: Frameworks
        _ebt = dict(edges_by_type)
        report.frameworks, report.framework_evidence = self._detect_frameworks(
            all_nodes, _ebt, file_paths
        )

        # Step 4: DB technology (from M33 ORM tags)
        report.db_technology, report.db_evidence = self._detect_db_technology(all_nodes)

        # Step 5: Infrastructure (from M33 infra nodes)
        report.infrastructure, report.infra_evidence = self._detect_infrastructure(
            all_nodes, file_paths
        )

        # Step 6: Pattern detection
        self._detect_pattern(report, _ebt)

        # Step 7: Boundary violations
        report.boundary_violations = self._detect_violations(
            report.module_roles, report.layers, _ebt
        )

        return report

    # ------------------------------------------------------------------
    # Role assignment
    # ------------------------------------------------------------------

    def _assign_roles(self, nodes_by_file: dict[str, list[dict]]) -> dict[str, str]:
        """Assign architectural role to each file."""
        roles: dict[str, str] = {}
        for fp, nodes in nodes_by_file.items():
            symbols = [
                {"type": n.get("type", ""), "name": n.get("name", "")}
                for n in nodes
            ]
            roles[fp] = infer_module_role(fp, symbols)
        return roles

    # ------------------------------------------------------------------
    # Layer detection
    # ------------------------------------------------------------------

    def _detect_layers(self) -> dict[str, int]:
        """Get layer assignments from StructuralAnalyzer."""
        try:
            analyzer = StructuralAnalyzer(self._store)
            layer_result = analyzer.detect_layers()
            layers: dict[str, int] = {}
            for layer_info in layer_result.get("layers", []):
                layer_num = layer_info.get("layer", 0)
                for fp in layer_info.get("files", []):
                    layers[fp] = layer_num
            return layers
        except Exception:
            return {}

    # ------------------------------------------------------------------
    # Framework detection
    # ------------------------------------------------------------------

    def _detect_frameworks(
        self,
        all_nodes: list[dict],
        edges_by_type: dict[str, list[dict]],
        file_paths: set[str],
    ) -> tuple[list[str], list[str]]:
        """Detect frameworks from imports, decorators, and file presence."""
        frameworks: list[str] = []
        evidence: list[str] = []

        # Count imports per framework prefix
        import_edges = edges_by_type.get("IMPORTS", [])
        import_targets: list[str] = [e.get("target", "") for e in import_edges]

        # Decorator scan
        all_decorators: list[str] = []
        for n in all_nodes:
            for d in _parse_decorators(n.get("decorators", [])):
                all_decorators.append(d)

        for rule in _FRAMEWORK_RULES:
            name = rule["name"]
            threshold = rule["threshold"]

            # Count imports matching this framework.
            # Match as module prefix (not substring) to avoid false positives
            # like "express" matching "django.utils.expression".
            import_count = 0
            for target in import_targets:
                for prefix in rule.get("imports", []):
                    # Must match: exact, or as a module prefix (followed by '.')
                    if target == prefix or target.startswith(prefix + "."):
                        import_count += 1
                        break

            # Check file presence
            has_file = False
            for f in rule.get("files", []):
                if any(fp.endswith(f) or fp.endswith("/" + f) for fp in file_paths):
                    has_file = True
                    break

            # Check decorators
            has_decorator = False
            for d in rule.get("decorators", []):
                if d in all_decorators:
                    has_decorator = True
                    break

            # Decision
            detected = False
            if threshold > 0 and import_count >= threshold:
                detected = True
                evidence.append(f"{name}: {import_count} imports")
            if has_file:
                if detected or threshold == 0:
                    detected = True
                    evidence.append(f"{name}: config file found")
            if has_decorator:
                detected = True
                evidence.append(f"{name}: framework decorators found")

            # Spring Boot special: needs either decorator or files
            if name == "spring_boot" and not has_decorator and not has_file:
                detected = False

            if detected:
                frameworks.append(name)

        # Sort by import frequency
        return frameworks, evidence

    # ------------------------------------------------------------------
    # DB technology detection (M33 ORM tags)
    # ------------------------------------------------------------------

    def _detect_db_technology(
        self, all_nodes: list[dict]
    ) -> tuple[str, list[str]]:
        """Detect DB technology from M33 ORM/schema tags."""
        orm_counts: Counter[str] = Counter()
        evidence: list[str] = []

        for n in all_nodes:
            decorators = _parse_decorators(n.get("decorators", []))
            if "orm_model" in decorators:
                if "sqlalchemy" in decorators:
                    orm_counts["sqlalchemy"] += 1
                elif "django" in decorators:
                    orm_counts["django_orm"] += 1
                elif "hibernate_jpa" in decorators or "Entity" in decorators:
                    orm_counts["hibernate_jpa"] += 1
            if "sql_table" in decorators:
                orm_counts["raw_sql"] += 1
            if "prisma_model" in decorators:
                orm_counts["prisma"] += 1

        if not orm_counts:
            return "", []

        dominant = orm_counts.most_common(1)[0]
        evidence.append(f"{dominant[0]}: {dominant[1]} tagged nodes")
        return dominant[0], evidence

    # ------------------------------------------------------------------
    # Infrastructure detection (M33 infra nodes)
    # ------------------------------------------------------------------

    def _detect_infrastructure(
        self,
        all_nodes: list[dict],
        file_paths: set[str],
    ) -> tuple[list[str], list[str]]:
        """Detect infrastructure from M33 infra nodes and file paths."""
        infra: list[str] = []
        evidence: list[str] = []

        # Check decorator tags from M33 parsers
        decorator_map = {
            "dockerfile": "docker",
            "docker_compose": "docker_compose",
            "docker_service": "docker_compose",
            "k8s_resource": "kubernetes",
            "k8s_manifest": "kubernetes",
            "terraform_resource": "terraform",
            "terraform_data": "terraform",
            "terraform": "terraform",
        }
        found: set[str] = set()
        for n in all_nodes:
            for d in _parse_decorators(n.get("decorators", [])):
                if d in decorator_map:
                    found.add(decorator_map[d])

        # Check file paths for CI/CD
        for fp in file_paths:
            if ".github/workflows/" in fp or ".github\\workflows\\" in fp:
                found.add("github_actions")
            if fp.endswith("Jenkinsfile") or "/Jenkinsfile" in fp:
                found.add("jenkins")
            if fp.endswith(".gitlab-ci.yml"):
                found.add("gitlab_ci")

        for item in sorted(found):
            infra.append(item)
            evidence.append(f"{item}: detected in graph")

        return infra, evidence

    # ------------------------------------------------------------------
    # Pattern detection
    # ------------------------------------------------------------------

    def _detect_pattern(
        self,
        report: ArchitectureReport,
        edges_by_type: dict[str, list[dict]],
    ) -> None:
        """Detect architecture pattern with mutually exclusive discriminators."""
        roles = report.module_roles
        layers = report.layers
        frameworks = set(report.frameworks)

        # Role counts
        role_counts = Counter(roles.values())

        # Layer stats
        distinct_layers = len(set(layers.values())) if layers else 0
        total_files = len(roles) or 1
        layer_file_counts = Counter(layers.values())
        max_layer_pct = (max(layer_file_counts.values()) / total_files) if layer_file_counts else 1.0

        # Cross-layer violations (for layered check)
        violation_count = 0
        total_cross_layer = 0
        if layers:
            for edges in edges_by_type.values():
                for e in edges:
                    src_file = e.get("file_path", "")
                    # Approximate target file from target
                    tgt = e.get("target", "")
                    tgt_file = ""
                    if "::" in tgt:
                        tgt_file = tgt.split("::")[0]
                    if src_file in layers and tgt_file in layers:
                        if layers[src_file] != layers[tgt_file]:
                            total_cross_layer += 1
                            # "Violation" = lower layer calling higher layer
                            if layers[src_file] < layers[tgt_file]:
                                violation_count += 1

        cross_layer_violation_rate = (
            violation_count / total_cross_layer if total_cross_layer > 0 else 0
        )

        # Dispatch/subscribe edge counts
        dispatch_sub_count = (
            len(edges_by_type.get("DISPATCHES", []))
            + len(edges_by_type.get("SUBSCRIBES", []))
        )

        # --- Pattern checks in resolution order ---
        candidates: list[tuple[str, float, list[str]]] = []

        # Event-Driven
        ed_signals = 0
        ed_total = 2
        ed_evidence: list[str] = []
        if dispatch_sub_count >= 10:
            ed_signals += 1
            ed_evidence.append(f"{dispatch_sub_count} dispatch/subscribe edges")
        event_frameworks = {"celery", "task_queue"}
        if frameworks & event_frameworks:
            ed_signals += 1
            ed_evidence.append(f"event framework: {frameworks & event_frameworks}")
        if ed_signals > 0:
            candidates.append(("event_driven", ed_signals / ed_total, ed_evidence))

        # MVC
        mvc_signals = 0
        mvc_total = 3
        mvc_evidence: list[str] = []
        if role_counts.get("api_layer", 0) >= 2:
            mvc_signals += 1
            mvc_evidence.append(f"{role_counts['api_layer']} api_layer files")
        if role_counts.get("data_model", 0) >= 2:
            mvc_signals += 1
            mvc_evidence.append(f"{role_counts['data_model']} data_model files")
        if frameworks & _MVC_FRAMEWORKS:
            mvc_signals += 1
            mvc_evidence.append(f"MVC framework: {frameworks & _MVC_FRAMEWORKS}")
        # Discriminator: must have MVC framework
        if not (frameworks & _MVC_FRAMEWORKS):
            mvc_signals = 0
        if mvc_signals > 0:
            candidates.append(("mvc", mvc_signals / mvc_total, mvc_evidence))

        # Repository-Service
        rs_signals = 0
        rs_total = 3
        rs_evidence: list[str] = []
        da_with_repo = sum(
            1 for fp, r in roles.items()
            if r == "data_access" and any(
                kw in fp.lower() for kw in ("repo", "dao", "repository")
            )
        )
        bl_with_service = sum(
            1 for fp, r in roles.items()
            if r == "business_logic" and "service" in fp.lower()
        )
        if da_with_repo >= 2:
            rs_signals += 1
            rs_evidence.append(f"{da_with_repo} repository/DAO files")
        if bl_with_service >= 2:
            rs_signals += 1
            rs_evidence.append(f"{bl_with_service} service files")
        # Discriminator: data_access and business_logic in different layers
        da_layers = {layers.get(fp, -99) for fp, r in roles.items() if r == "data_access"}
        bl_layers = {layers.get(fp, -99) for fp, r in roles.items() if r == "business_logic"}
        if da_layers and bl_layers and da_layers != bl_layers:
            rs_signals += 1
            rs_evidence.append("repo and service layers are separate")
        if rs_signals > 0:
            candidates.append(("repository_service", rs_signals / rs_total, rs_evidence))

        # Layered — REQUIRES ≥3 distinct layers (discriminator)
        lay_signals = 0
        lay_total = 2
        lay_evidence: list[str] = []
        if distinct_layers >= 3:
            lay_signals += 1
            lay_evidence.append(f"{distinct_layers} distinct layers")
            if cross_layer_violation_rate < 0.2:
                lay_signals += 1
                lay_evidence.append(f"cross-layer violations: {cross_layer_violation_rate:.0%}")
        if lay_signals > 0:
            candidates.append(("layered", lay_signals / lay_total, lay_evidence))

        # Monolith
        mono_signals = 0
        mono_total = 2
        mono_evidence: list[str] = []
        if distinct_layers <= 2:
            mono_signals += 1
            mono_evidence.append(f"only {distinct_layers} layers")
        if max_layer_pct > 0.4:
            mono_signals += 1
            mono_evidence.append(f"{max_layer_pct:.0%} of files in single layer")
        candidates.append(("monolith", mono_signals / mono_total, mono_evidence))

        # Resolution order: Event-Driven → MVC → Repository-Service → Layered → Monolith
        # First match with signals > 0 wins (per spec)
        _resolution_order = ["event_driven", "mvc", "repository_service", "layered", "monolith"]
        cand_map = {c[0]: c for c in candidates if c[1] > 0}

        primary = None
        secondary = None
        for pat in _resolution_order:
            if pat in cand_map:
                if primary is None:
                    primary = cand_map[pat]
                elif secondary is None:
                    secondary = cand_map[pat]
                    break

        if primary:
            report.pattern = primary[0]
            report.pattern_confidence = primary[1]
            report.pattern_evidence = primary[2]
        if secondary:
            report.secondary_pattern = secondary[0]

    # ------------------------------------------------------------------
    # Boundary violation detection
    # ------------------------------------------------------------------

    def _detect_violations(
        self,
        roles: dict[str, str],
        layers: dict[str, int],
        edges_by_type: dict[str, list[dict]],
    ) -> list[dict]:
        """Detect architectural boundary violations using edge lookups."""
        violations: list[dict] = []

        # Build reverse index: for each edge, find source/target file roles
        check_types = {"CALLS", "IMPORTS"}
        for etype in check_types:
            for e in edges_by_type.get(etype, []):
                src_file = e.get("file_path", "")
                tgt = e.get("target", "")
                tgt_file = tgt.split("::")[0] if "::" in tgt else ""

                if not src_file or not tgt_file:
                    continue

                src_role = roles.get(src_file, "")
                tgt_role = roles.get(tgt_file, "")

                # Model → Controller
                if src_role == "data_model" and tgt_role == "api_layer":
                    violations.append({
                        "source_file": src_file,
                        "target_file": tgt_file,
                        "edge_type": etype,
                        "violation": "model_calls_controller",
                    })

                # Controller → DB direct
                if src_role == "api_layer" and tgt_role == "data_access":
                    violations.append({
                        "source_file": src_file,
                        "target_file": tgt_file,
                        "edge_type": etype,
                        "violation": "controller_direct_db",
                    })

                # Utility → API
                if src_role == "utility" and tgt_role == "api_layer":
                    violations.append({
                        "source_file": src_file,
                        "target_file": tgt_file,
                        "edge_type": etype,
                        "violation": "utility_calls_api",
                    })

        # Circular layer dependency (pair check)
        # Build adjacency: layer_src → set(layer_tgt)
        if layers:
            layer_edges = defaultdict(set)
            for etype in check_types:
                for e in edges_by_type.get(etype, []):
                    src_file = e.get("file_path", "")
                    tgt = e.get("target", "")
                    tgt_file = tgt.split("::")[0] if "::" in tgt else ""
                    if src_file in layers and tgt_file in layers:
                        src_l = layers[src_file]
                        tgt_l = layers[tgt_file]
                        if src_l != tgt_l:
                            layer_edges[src_l].add(tgt_l)

            # Check for bidirectional edges between layers
            seen_pairs: set[tuple[int, int]] = set()
            for src_l, tgts in layer_edges.items():
                for tgt_l in tgts:
                    pair = (min(src_l, tgt_l), max(src_l, tgt_l))
                    if pair in seen_pairs:
                        continue
                    if tgt_l in layer_edges and src_l in layer_edges[tgt_l]:
                        seen_pairs.add(pair)
                        violations.append({
                            "source_file": f"layer_{src_l}",
                            "target_file": f"layer_{tgt_l}",
                            "edge_type": "BIDIRECTIONAL",
                            "violation": "circular_layer_dependency",
                        })

        return violations
