"""Hook runner — invoked by the pre-commit hook to validate staged files.

Exit code 0 = all clear.
Exit code 1 = CRITICAL or HIGH violations found, block commit.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.logging import get_logger

_log = get_logger("hook_runner")


def _find_repo_root(start: Path) -> Path | None:
    cur = start
    while cur != cur.parent:
        if (cur / CODEBRAIN_DIR / DB_FILENAME).exists():
            return cur
        cur = cur.parent
    return None


def pretooluse(stdin_text: str) -> int:
    """Claude Code PreToolUse hook handler — validate edits BEFORE they happen.

    Reads one JSON event per invocation from Claude Code's hook protocol,
    validates Edit/Write/MultiEdit tool calls against the knowledge graph,
    and exits 2 (block) if any CRITICAL violation is found.

    Input schema (Claude Code hook):
      {"tool_name": "Edit"|"Write"|"MultiEdit",
       "tool_input": {"file_path": "...", "content"|"new_string": "..."}}

    Output:
      exit 0  → allow the edit
      exit 2  → block; stderr message is shown to the user
      other   → treated as non-blocking warning
    """
    try:
        event = json.loads(stdin_text) if stdin_text.strip() else {}
    except json.JSONDecodeError:
        return 0  # be lenient; never block on malformed input

    tool = event.get("tool_name") or event.get("tool") or ""
    tool_input = event.get("tool_input") or {}

    # Only gate file-mutating tools.
    if tool not in ("Edit", "Write", "MultiEdit"):
        return 0

    file_path = tool_input.get("file_path") or tool_input.get("path") or ""
    if not file_path:
        return 0

    # For Write / Edit: the full intended content lives in different keys.
    new_content = (
        tool_input.get("content")
        or tool_input.get("new_string")
        or ""
    )
    if not new_content:
        # MultiEdit / Edit-with-only-diffs — skip graph validation, allow.
        return 0

    # Only gate Python (validator is AST-based for now).
    if not file_path.endswith(".py"):
        return 0

    repo_root = _find_repo_root(Path(file_path).resolve())
    if repo_root is None:
        return 0  # no index → nothing to validate against

    db_path = repo_root / CODEBRAIN_DIR / DB_FILENAME

    try:
        rel_path = Path(file_path).resolve().relative_to(repo_root).as_posix()
    except ValueError:
        return 0  # file outside repo

    from codebrain.graph.store import GraphStore
    from codebrain.validator import ChangeValidator, Severity

    with GraphStore(db_path) as store:
        report = ChangeValidator(store).validate_content(
            rel_path, new_content, repo_root,
        )

    critical = [v for v in report.violations if v.severity == Severity.CRITICAL]
    if critical:
        # Exit 2 tells Claude Code to block the tool call and surface stderr.
        print(
            f"[CodeBrain] BLOCKED edit to {rel_path} — "
            f"{len(critical)} critical violation(s):",
            file=sys.stderr,
        )
        for v in critical[:5]:
            print(f"  - {v.message}", file=sys.stderr)
        print(
            "  Run `brain propose-change` or `brain validate-change` "
            "for the full report. Set CODEBRAIN_SKIP_HOOK=1 to bypass.",
            file=sys.stderr,
        )
        return 2

    return 0


def main() -> int:
    files = sys.argv[1:]
    if not files:
        return 0

    # Find repo root
    cwd = Path.cwd()
    repo_root = cwd
    while repo_root != repo_root.parent:
        if (repo_root / CODEBRAIN_DIR / DB_FILENAME).exists():
            break
        repo_root = repo_root.parent
    else:
        # No index found, skip validation
        return 0

    db_path = repo_root / CODEBRAIN_DIR / DB_FILENAME
    if not db_path.exists():
        return 0

    from codebrain.graph.store import GraphStore
    from codebrain.validator import ChangeValidator, Severity

    with GraphStore(db_path) as store:
        validator = ChangeValidator(store)

        all_violations = []
        for file_str in files:
            file_path = repo_root / file_str
            if not file_path.exists():
                report = validator.validate_deletion(file_str)
            else:
                report = validator.validate_file(file_path, repo_root)

            critical_or_high = [
                v for v in report.violations
                if v.severity in (Severity.CRITICAL, Severity.HIGH)
            ]
            if critical_or_high:
                all_violations.extend(critical_or_high)
                _log.warning("[CodeBrain] %s — risk: %.0f%%", file_str, report.risk_score * 100)
                for v in critical_or_high:
                    _log.warning("  [%8s] %s", v.severity, v.message)

    if all_violations:
        _log.warning("[CodeBrain] %d violation(s) found. Commit blocked.", len(all_violations))
        _log.warning("  Use `git commit --no-verify` to bypass (not recommended).")
        return 1

    return 0


def dispatch() -> int:
    """Entry point: choose pretooluse vs pre-commit by --mode flag."""
    import os
    if os.environ.get("CODEBRAIN_SKIP_HOOK") == "1":
        return 0
    if "--pretooluse" in sys.argv:
        return pretooluse(sys.stdin.read())
    return main()


if __name__ == "__main__":
    sys.exit(dispatch())
