"""Equivalence test generation — prove old_fn(x) == new_fn(x) after migration.

Generates and runs tests that compare old and new code behavior for the same
inputs.  Same-language tests use importlib isolation; cross-language tests use
JSON stdin/stdout wrapper scripts invoked via subprocess.
"""

from __future__ import annotations

import json
import os
import subprocess
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from codebrain.graph.store import GraphStore
from codebrain.migration import ContractExtractor
from codebrain.rewriter import LLMClient


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class EquivalenceTest:
    symbol_name: str
    test_code: str
    test_file: str
    status: str = "generated"  # generated | passed | failed | skipped | error
    error_message: str = ""


@dataclass
class EquivalenceResult:
    total: int = 0
    passed: int = 0
    failed: int = 0
    skipped: int = 0
    tests: list[EquivalenceTest] = field(default_factory=list)


# ---------------------------------------------------------------------------
# I/O indicators — params/calls that mark a function as side-effectful
# ---------------------------------------------------------------------------

_IO_PARAM_NAMES = {"file", "db", "conn", "session", "request", "cursor"}

_IO_CALL_TARGETS = {
    "print", "sys.exit", "os.remove", "os.unlink",
    "open", "shutil.rmtree", "shutil.copy",
}

_SKIP_DUNDERS = {"__init__", "__del__", "__enter__", "__exit__"}


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------

class EquivalenceTestGenerator:
    """Generate and run equivalence tests comparing old and new code."""

    def __init__(self, old_store: GraphStore, client: LLMClient) -> None:
        self.old_store = old_store
        self.client = client
        self.contracts = ContractExtractor(old_store)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(
        self,
        old_root: Path,
        new_root: Path,
        output_dir: Path,
        target_lang: str = "",
    ) -> EquivalenceResult:
        """Generate equivalence tests for all migrated symbols."""
        output_dir.mkdir(parents=True, exist_ok=True)
        testable = self._extract_testable()

        result = EquivalenceResult()
        same_lang = not target_lang or target_lang.lower() == "python"

        # For cross-lang, generate wrapper scripts once
        if not same_lang:
            wrapper_old = self._generate_cross_lang_wrapper(
                testable, old_root, "python",
            )
            wrapper_old_path = output_dir / "_equiv_wrapper_old.py"
            wrapper_old_path.write_text(wrapper_old, encoding="utf-8")

            wrapper_new = self._generate_cross_lang_wrapper(
                testable, new_root, target_lang,
            )
            ext = {"go": ".go", "java": ".java", "kotlin": ".kt",
                   "rust": ".rs", "typescript": ".ts", "csharp": ".cs",
                   "dart": ".dart"}.get(target_lang.lower(), ".txt")
            wrapper_new_path = output_dir / f"_equiv_wrapper_new{ext}"
            wrapper_new_path.write_text(wrapper_new, encoding="utf-8")

        for sym in testable:
            if same_lang:
                code = self._generate_same_lang_test(sym, old_root, new_root)
            else:
                code = self._generate_cross_lang_test(sym, target_lang)

            fname = f"test_equiv_{sym['name']}.py"
            fpath = output_dir / fname
            fpath.write_text(code, encoding="utf-8")

            result.tests.append(EquivalenceTest(
                symbol_name=sym["name"],
                test_code=code,
                test_file=str(fpath),
            ))
            result.total += 1

        # Count skipped (total symbols minus testable)
        all_nodes = self.old_store.get_all_nodes()
        public_syms = [
            n for n in all_nodes
            if n.get("is_exported")
            and n["type"] in ("function", "method")
        ]
        result.skipped = max(0, len(public_syms) - len(testable))

        return result

    def run(self, test_dir: Path) -> EquivalenceResult:
        """Run generated equivalence tests via pytest."""
        test_files = sorted(test_dir.glob("test_equiv_*.py"))
        result = EquivalenceResult(total=len(test_files))

        if not test_files:
            return result

        try:
            proc = subprocess.run(
                ["python", "-m", "pytest", str(test_dir), "-v", "--tb=short"],
                capture_output=True,
                text=True,
                timeout=120,
                cwd=str(test_dir),
            )
        except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
            for tf in test_files:
                result.tests.append(EquivalenceTest(
                    symbol_name=tf.stem.replace("test_equiv_", ""),
                    test_code="",
                    test_file=str(tf),
                    status="error",
                    error_message=str(exc),
                ))
            return result

        # Parse pytest output for pass/fail per test
        for tf in test_files:
            sym_name = tf.stem.replace("test_equiv_", "")
            if f"PASSED" in proc.stdout and sym_name in proc.stdout:
                result.passed += 1
                status = "passed"
                err = ""
            elif f"FAILED" in proc.stdout and sym_name in proc.stdout:
                result.failed += 1
                status = "failed"
                err = proc.stdout
            else:
                result.skipped += 1
                status = "skipped"
                err = ""

            result.tests.append(EquivalenceTest(
                symbol_name=sym_name,
                test_code=tf.read_text(encoding="utf-8") if tf.exists() else "",
                test_file=str(tf),
                status=status,
                error_message=err,
            ))

        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _extract_testable(self) -> list[dict]:
        """Find public functions/methods with deterministic signatures."""
        all_nodes = self.old_store.get_all_nodes()
        all_edges = self.old_store.get_all_edges()

        # Build call graph for I/O detection
        calls_from: dict[str, set[str]] = {}
        for e in all_edges:
            if e["type"] == "CALLS":
                calls_from.setdefault(e["source"], set()).add(e["target"])

        testable = []
        for node in all_nodes:
            if not node.get("is_exported"):
                continue
            if node["type"] not in ("function", "method"):
                continue
            if not self._is_testable(node, calls_from):
                continue
            testable.append(node)

        return testable

    def _is_testable(
        self,
        symbol: dict,
        calls_from: dict[str, set[str]] | None = None,
    ) -> bool:
        """Check if a symbol can be tested for equivalence."""
        name = symbol.get("name", "")

        # Skip dunder lifecycle methods
        if name in _SKIP_DUNDERS:
            return False

        # Skip private symbols
        if name.startswith("_") and not name.startswith("__"):
            return False

        # Check params for I/O indicators — stored as 'params' or 'signature'
        params_raw = symbol.get("params", "") or symbol.get("signature", "") or ""
        # Strip surrounding parentheses from signature
        if isinstance(params_raw, str):
            params_raw = params_raw.strip()
            if params_raw.startswith("(") and params_raw.endswith(")"):
                params_raw = params_raw[1:-1]
            param_names = [
                p.strip().split(":")[0].strip().split("=")[0].strip()
                for p in params_raw.split(",") if p.strip()
            ]
        else:
            param_names = list(params_raw)

        # Remove 'self'/'cls' for check
        param_names_clean = [p for p in param_names if p not in ("self", "cls")]

        for pn in param_names_clean:
            if pn.lower() in _IO_PARAM_NAMES:
                return False

        # Must have params (besides self/cls) or return value
        returns = symbol.get("return_type", "") or ""

        # Check call chain for I/O
        if calls_from:
            visited: set[str] = set()
            stack = list(calls_from.get(symbol.get("id", ""), set()))
            stack += list(calls_from.get(name, set()))
            while stack:
                target = stack.pop()
                if target in visited:
                    continue
                visited.add(target)
                # Check target name against I/O patterns
                target_base = target.split(".")[-1] if "." in target else target
                if target in _IO_CALL_TARGETS or target_base in _IO_CALL_TARGETS:
                    return False
                # Recurse
                for next_target in calls_from.get(target, set()):
                    if next_target not in visited:
                        stack.append(next_target)

        return True

    def _generate_same_lang_test(
        self,
        symbol: dict,
        old_root: Path,
        new_root: Path,
    ) -> str:
        """Generate pytest using importlib isolation for both projects."""
        file_path = symbol.get("file_path", "")
        sym_name = symbol.get("name", "")
        qualified = symbol.get("qualified_name", sym_name)
        params_raw = symbol.get("params", "") or ""
        return_type = symbol.get("return_type", "") or ""

        # Ask the LLM for test inputs
        contract_info = self._get_contract_info(symbol)
        prompt = textwrap.dedent(f"""\
            Generate a Python dict of test inputs for the function below.
            Return ONLY a JSON object with key "inputs" containing a list of
            dicts, each dict maps parameter names to values.
            Do NOT include 'self' or 'cls' parameters.

            Function: {qualified}
            Parameters: {params_raw}
            Return type: {return_type}
            Contract info: {contract_info}

            Example response:
            {{"inputs": [{{"a": 1, "b": 2}}, {{"a": 0, "b": -1}}]}}
        """)

        try:
            resp = self.client.complete(
                system="You are a test input generator. Return only valid JSON.",
                user=prompt,
                temperature=0.2,
            )
            inputs_data = self._parse_json(resp.content)
        except Exception:
            inputs_data = {"inputs": [{}]}

        inputs_list = inputs_data.get("inputs", [{}])
        if not inputs_list:
            inputs_list = [{}]

        # Determine if method (has self)
        is_method = "self" in (params_raw or "")
        class_name = ""
        method_name = sym_name
        if is_method and "." in qualified:
            parts = qualified.rsplit(".", 1)
            class_name = parts[0].split(".")[-1]
            method_name = parts[1]

        # Build test cases
        test_cases = []
        for i, inp in enumerate(inputs_list[:5]):  # Limit to 5 inputs
            args_str = ", ".join(f"{k}={repr(v)}" for k, v in inp.items())
            if is_method and class_name:
                call = f"mod.{class_name}().{method_name}({args_str})"
            else:
                call = f"mod.{sym_name}({args_str})"

            test_cases.append(textwrap.dedent(f"""\
                def test_equiv_{sym_name}_case{i}():
                    old_mod = _load_module({repr(str(old_root))}, {repr(file_path)})
                    new_mod = _load_module({repr(str(new_root))}, {repr(file_path)})

                    old_result = (lambda mod: {call})(old_mod)
                    new_result = (lambda mod: {call})(new_mod)

                    if isinstance(old_result, float):
                        assert old_result == pytest.approx(new_result, rel=1e-6)
                    else:
                        assert old_result == new_result
            """))

        test_body = "\n\n".join(test_cases)

        code = textwrap.dedent(f"""\
            \"\"\"Equivalence tests for {sym_name}.\"\"\"
            from __future__ import annotations

            import importlib.util
            import os
            import pytest


            def _load_module(root_path, module_path):
                \"\"\"Load a module from a specific project root without polluting sys.path.\"\"\"
                full_path = os.path.join(root_path, module_path)
                spec = importlib.util.spec_from_file_location(
                    f"_equiv_{{module_path.replace('/', '.')}}", full_path,
                )
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                return mod


        """) + test_body

        return code

    def _generate_cross_lang_wrapper(
        self,
        symbols: list[dict],
        root: Path,
        lang: str,
    ) -> str:
        """Generate JSON stdin->stdout wrapper for a project's functions."""
        if lang.lower() == "python":
            # Python wrapper
            cases = []
            for sym in symbols:
                name = sym.get("name", "")
                qualified = sym.get("qualified_name", name)
                file_path = sym.get("file_path", "")
                module_name = Path(file_path).stem if file_path else "unknown"

                params_raw = sym.get("params", "") or ""
                param_names = [
                    p.strip().split(":")[0].strip().split("=")[0].strip()
                    for p in params_raw.split(",") if p.strip()
                ]
                param_names = [p for p in param_names if p not in ("self", "cls")]

                args = ", ".join(f'{p}=args.get("{p}")' for p in param_names)
                cases.append(f'    if fn_name == "{name}":\n'
                             f'        from {module_name} import {name}\n'
                             f'        result = {name}({args})\n'
                             f'        json.dump({{"result": result}}, sys.stdout)')

            cases_code = "\n    el".join(cases) if cases else '    pass'

            return textwrap.dedent(f"""\
                \"\"\"Wrapper: call old function with JSON args from stdin, print JSON result.\"\"\"
                import json
                import sys
                sys.path.insert(0, {repr(str(root))})


                def main():
                    req = json.load(sys.stdin)
                    fn_name = req["function"]
                    args = req.get("args", {{}})

                {cases_code}


                if __name__ == "__main__":
                    main()
            """)
        else:
            # Ask LLM to generate target-lang wrapper
            sym_list = ", ".join(s.get("name", "") for s in symbols)
            prompt = textwrap.dedent(f"""\
                Generate a {lang} program that reads JSON from stdin with keys
                "function" (string) and "args" (object), calls the named function
                with those args, and writes JSON to stdout with key "result".

                Functions to support: {sym_list}
                Project root: {root}

                The program should import from the translated project.
                Return ONLY the source code, no explanations.
            """)
            try:
                resp = self.client.complete(
                    system=f"You generate {lang} wrapper scripts for equivalence testing.",
                    user=prompt,
                    temperature=0.1,
                )
                return resp.content
            except Exception:
                return f"// TODO: Generate {lang} wrapper for: {sym_list}\n"

    def _generate_cross_lang_test(
        self,
        symbol: dict,
        target_lang: str,
    ) -> str:
        """Generate subprocess-based comparison test."""
        sym_name = symbol.get("name", "")
        params_raw = symbol.get("params", "") or ""
        return_type = symbol.get("return_type", "") or ""

        # Ask LLM for test inputs
        contract_info = self._get_contract_info(symbol)
        prompt = textwrap.dedent(f"""\
            Generate test inputs for function '{sym_name}'.
            Parameters: {params_raw}
            Return type: {return_type}
            Contract: {contract_info}
            Return ONLY a JSON object: {{"inputs": [{{"param": value}}]}}
        """)

        try:
            resp = self.client.complete(
                system="You are a test input generator. Return only valid JSON.",
                user=prompt,
                temperature=0.2,
            )
            inputs_data = self._parse_json(resp.content)
        except Exception:
            inputs_data = {"inputs": [{}]}

        inputs_list = inputs_data.get("inputs", [{}])
        if not inputs_list:
            inputs_list = [{}]

        # Determine runner command for target lang
        runner = {"go": '["go", "run", "_equiv_wrapper_new.go"]',
                  "java": '["java", "_equiv_wrapper_new.java"]',
                  "kotlin": '["kotlin", "_equiv_wrapper_new.kt"]',
                  "rust": '["cargo", "run"]',
                  "typescript": '["npx", "ts-node", "_equiv_wrapper_new.ts"]',
                  "csharp": '["dotnet", "run"]',
                  "dart": '["dart", "run", "_equiv_wrapper_new.dart"]',
                  }.get(target_lang.lower(), '["python", "_equiv_wrapper_new.py"]')

        test_cases = []
        for i, inp in enumerate(inputs_list[:5]):
            test_cases.append(textwrap.dedent(f"""\
                def test_equiv_{sym_name}_case{i}():
                    args = {repr(inp)}
                    old = _call_old("{sym_name}", args)
                    new = _call_new("{sym_name}", args)
                    if isinstance(old.get("result"), float):
                        assert old["result"] == pytest.approx(new["result"], rel=1e-6)
                    else:
                        assert old["result"] == new["result"]
            """))

        test_body = "\n\n".join(test_cases)

        code = textwrap.dedent(f"""\
            \"\"\"Cross-language equivalence tests for {sym_name}.\"\"\"
            from __future__ import annotations

            import json
            import subprocess

            import pytest


            def _call_old(fn_name, args):
                proc = subprocess.run(
                    ["python", "_equiv_wrapper_old.py"],
                    input=json.dumps({{"function": fn_name, "args": args}}),
                    capture_output=True, text=True, timeout=10,
                )
                return json.loads(proc.stdout)


            def _call_new(fn_name, args):
                proc = subprocess.run(
                    {runner},
                    input=json.dumps({{"function": fn_name, "args": args}}),
                    capture_output=True, text=True, timeout=10,
                )
                return json.loads(proc.stdout)


        """) + test_body

        return code

    def _get_contract_info(self, symbol: dict) -> str:
        """Get contract info for a symbol from ContractExtractor."""
        try:
            file_path = symbol.get("file_path", "")
            contracts = self.contracts.extract(file_path=file_path)
            # Find matching symbol in contracts
            for fp, mod_info in contracts.items():
                for fn in mod_info.get("functions", []):
                    if fn.get("name") == symbol.get("name"):
                        return json.dumps(fn)
                for cls in mod_info.get("classes", []):
                    for method in cls.get("methods", []):
                        if method.get("name") == symbol.get("name"):
                            return json.dumps(method)
        except Exception:
            pass
        return "{}"

    @staticmethod
    def _parse_json(text: str) -> dict:
        """Extract JSON from LLM response text."""
        # Try direct parse
        text = text.strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        # Try to find JSON in markdown code block
        import re
        match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1).strip())
            except json.JSONDecodeError:
                pass
        # Try to find first { ... }
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except json.JSONDecodeError:
                pass
        return {}
