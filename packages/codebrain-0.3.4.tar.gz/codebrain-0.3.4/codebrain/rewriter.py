"""Rewrite engine — function-level rewriting with validate-retry loop.

LLM-agnostic: works with Ollama, Claude API, OpenAI, Azure, or any
OpenAI-compatible endpoint.  CodeBrain compensates for LLM weakness
with surgical prompts + structural validation + auto-retry.

The loop:
    For each module (dependency order):
        For each function/class:
            prompt  = spec + source + contracts + callers
            code    = LLM(prompt)
            valid?  = CodeBrain.validate(code)
            if not  → retry with error context (up to N times)
            write file
        Re-index → verify equivalence
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import textwrap
import time
from abc import ABC, abstractmethod
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.graph.store import GraphStore
from codebrain.modernize import SpecGenerator


# ---------------------------------------------------------------------------
# Cross-language translation constants
# ---------------------------------------------------------------------------

TARGET_EXTENSIONS: dict[str, str] = {
    "go": ".go",
    "java": ".java",
    "kotlin": ".kt",
    "rust": ".rs",
    "typescript": ".ts",
    "csharp": ".cs",
    "python": ".py",
    "dart": ".dart",
}

# Constructs that are hard to translate — surface as warnings, not blockers.
TRANSLATION_WARNINGS: dict[str, dict[str, str]] = {
    "python": {
        r"yield\s": "Source uses generators. Verify target equivalent (Go channels, Java iterators, etc.).",
        r"@[\w.]+.*\n\s*def\s": "Source uses decorators. Verify target equivalent (annotations, middleware, etc.).",
        r"metaclass\s*=": "Source uses metaclasses. No direct equivalent in most languages.",
        r"__getattr__|__setattr__|__getitem__": "Source uses dynamic attribute/item access. Verify target handles this.",
        r"with\s+\w+": "Source uses context managers. Verify target has equivalent resource cleanup (defer, try-with-resources, etc.).",
        r"async\s+def\s": "Source uses async/await. Verify target async model is compatible.",
        r"\*args|\*\*kwargs": "Source uses variadic arguments. Map to target conventions (varargs, spread, etc.).",
        r"lambda\s": "Source uses lambda expressions. Verify target function literal syntax.",
    },
    "java": {
        r"@FunctionalInterface": "Source uses functional interfaces. Map to target function types.",
        r"Stream\.\w+|\.stream\(\)": "Source uses Java Streams. Map to target collection pipeline.",
        r"Optional<": "Source uses Optional. Map to target null-safety (Option, ?, nil, etc.).",
        r"synchronized\s": "Source uses synchronized blocks. Map to target concurrency primitives.",
    },
    "typescript": {
        r"as\s+\w+|<\w+>": "Source uses type assertions/casts. Verify target type system handles this.",
        r"keyof\s|typeof\s": "Source uses advanced TypeScript types. May not map to target.",
        r"Partial<|Required<|Pick<|Omit<": "Source uses utility types. Verify target equivalents.",
    },
}

# Build tools for compilation verification.
BUILD_TOOLS: dict[str, dict[str, Any]] = {
    "go": {
        "cmd": "go",
        "build": ["go", "build", "./..."],
        "check": ["go", "vet", "./..."],
        "scaffold": {"go.mod": 'module translated\n\ngo 1.21\n'},
    },
    "java": {
        "cmd": "javac",
        "build_detect": True,  # detect maven/gradle first
        "fallback": ["javac", "-d", "out"],
        "scaffold": {},
    },
    "kotlin": {
        "cmd": "kotlinc",
        "build_detect": True,
        "fallback": ["kotlinc"],
        "scaffold": {},
    },
    "rust": {
        "cmd": "cargo",
        "build": ["cargo", "build"],
        "scaffold": {
            "Cargo.toml": '[package]\nname = "translated"\nversion = "0.1.0"\nedition = "2021"\n',
        },
    },
    "typescript": {
        "cmd": "tsc",
        "build": ["tsc", "--noEmit"],
        "fallback_cmd": "npx",
        "fallback": ["npx", "tsc", "--noEmit"],
        "scaffold": {
            "tsconfig.json": '{"compilerOptions":{"target":"ES2020","module":"commonjs","strict":true,"outDir":"./dist","skipLibCheck":true},"include":["./**/*.ts"]}',
        },
    },
    "csharp": {
        "cmd": "dotnet",
        "build": ["dotnet", "build"],
        "scaffold": {},
    },
}


# ---------------------------------------------------------------------------
# LLM client abstraction
# ---------------------------------------------------------------------------


@dataclass
class LLMResponse:
    """Response from an LLM call."""
    content: str
    model: str = ""
    tokens_used: int = 0
    latency_ms: int = 0


class LLMClient(ABC):
    """Abstract LLM client — any provider that can complete a prompt."""

    @abstractmethod
    def complete(self, system: str, user: str, temperature: float = 0.1) -> LLMResponse:
        """Send a chat completion request."""

    @abstractmethod
    def is_available(self) -> bool:
        """Check if the LLM endpoint is reachable."""


class OpenAICompatibleClient(LLMClient):
    """Client for OpenAI-compatible APIs (Ollama, vLLM, LM Studio, Azure, OpenAI)."""

    def __init__(
        self,
        base_url: str = "http://localhost:11434/v1",
        model: str = "codellama:13b",
        api_key: str = "",
        timeout: int = 300,
        max_tokens: int = 8192,
    ):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.max_tokens = max_tokens

    def complete(self, system: str, user: str, temperature: float = 0.1) -> LLMResponse:
        import httpx

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": self.max_tokens,
        }

        start = time.monotonic()
        resp = httpx.post(
            f"{self.base_url}/chat/completions",
            json=payload,
            headers=headers,
            timeout=self.timeout,
        )
        latency = int((time.monotonic() - start) * 1000)
        resp.raise_for_status()
        data = resp.json()

        content = data["choices"][0]["message"]["content"]
        tokens = data.get("usage", {}).get("total_tokens", 0)

        return LLMResponse(
            content=content,
            model=data.get("model", self.model),
            tokens_used=tokens,
            latency_ms=latency,
        )

    def is_available(self) -> bool:
        import httpx

        try:
            resp = httpx.get(f"{self.base_url}/models", timeout=5)
            return resp.status_code == 200
        except Exception:
            return False


class AnthropicClient(LLMClient):
    """Client for the Anthropic Messages API."""

    def __init__(
        self,
        api_key: str = "",
        model: str = "claude-sonnet-4-20250514",
        timeout: int = 120,
    ):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.model = model
        self.timeout = timeout

    def complete(self, system: str, user: str, temperature: float = 0.1) -> LLMResponse:
        import httpx

        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
        }

        payload = {
            "model": self.model,
            "max_tokens": 4096,
            "system": system,
            "messages": [{"role": "user", "content": user}],
            "temperature": temperature,
        }

        start = time.monotonic()
        resp = httpx.post(
            "https://api.anthropic.com/v1/messages",
            json=payload,
            headers=headers,
            timeout=self.timeout,
        )
        latency = int((time.monotonic() - start) * 1000)
        resp.raise_for_status()
        data = resp.json()

        content = data["content"][0]["text"]
        tokens = data.get("usage", {}).get("input_tokens", 0) + data.get("usage", {}).get("output_tokens", 0)

        return LLMResponse(
            content=content,
            model=data.get("model", self.model),
            tokens_used=tokens,
            latency_ms=latency,
        )

    def is_available(self) -> bool:
        return bool(self.api_key)


def create_client(
    provider: str = "",
    base_url: str = "",
    model: str = "",
    api_key: str = "",
) -> LLMClient:
    """Create an LLM client from config or environment variables.

    Config precedence: explicit args > env vars > defaults.
    """
    provider = provider or os.environ.get("CODEBRAIN_LLM_PROVIDER", "ollama")
    base_url = base_url or os.environ.get("CODEBRAIN_LLM_BASE_URL", "")
    model = model or os.environ.get("CODEBRAIN_LLM_MODEL", "")
    api_key = api_key or os.environ.get("CODEBRAIN_LLM_API_KEY", "")

    provider = provider.lower()

    if provider == "anthropic":
        return AnthropicClient(
            api_key=api_key or os.environ.get("ANTHROPIC_API_KEY", ""),
            model=model or "claude-sonnet-4-20250514",
        )
    elif provider == "openai":
        return OpenAICompatibleClient(
            base_url=base_url or "https://api.openai.com/v1",
            model=model or "gpt-4o",
            api_key=api_key or os.environ.get("OPENAI_API_KEY", ""),
        )
    elif provider == "azure":
        return OpenAICompatibleClient(
            base_url=base_url,  # User must provide Azure endpoint
            model=model or "gpt-4o",
            api_key=api_key,
        )
    else:
        # Default: Ollama / any OpenAI-compatible local server
        return OpenAICompatibleClient(
            base_url=base_url or "http://localhost:11434/v1",
            model=model or "codellama:13b",
            api_key=api_key,
        )


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------


def _build_system_prompt(
    target_stack: str,
    guidelines: str,
    db_technology: str = "",
) -> str:
    """Build the system prompt for rewriting."""
    parts = [
        "You are a senior software engineer performing a codebase modernization.",
        "You rewrite code ONE FUNCTION OR CLASS at a time.",
        "You MUST preserve the exact public API contract — same function name, "
        "compatible parameters, compatible return type.",
        "You MUST NOT add, remove, or rename any exported symbol.",
        "Output ONLY the rewritten code block. No explanation, no markdown fences "
        "around the entire response — just the code.",
    ]
    if target_stack:
        parts.append(f"\nTarget stack: {target_stack}")
    if guidelines:
        parts.append(f"\nGuidelines: {guidelines}")
    if db_technology:
        parts.append(f"\nDatabase: {db_technology}")
        parts.append("Rules:")
        parts.append("- Preserve ORM model base classes and field definitions")
        parts.append("- Database relationships (foreign keys, OneToMany, etc.) must be preserved")
        parts.append("- __tablename__ / @Table values MUST NOT change")
        parts.append("- @Entity annotations MUST be preserved on JPA classes")
    return "\n".join(parts)


def _build_rewrite_prompt(
    source_code: str,
    symbol_spec: dict,
    module_spec: dict,
    file_context: str = "",
) -> str:
    """Build the user prompt for rewriting a single symbol."""
    parts = []

    # Source code
    parts.append("## Current Source Code\n")
    parts.append(f"File: `{module_spec.get('file_path', '?')}`\n")
    parts.append(f"```\n{source_code}\n```\n")

    # Symbol contract
    parts.append("## Symbol to Rewrite\n")
    parts.append(f"- **Name:** {symbol_spec['name']}")
    parts.append(f"- **Type:** {symbol_spec['type']}")
    if symbol_spec.get("signature"):
        parts.append(f"- **Signature (MUST preserve):** `{symbol_spec['signature']}`")
    if symbol_spec.get("docstring"):
        parts.append(f"- **Docstring:** {symbol_spec['docstring']}")
    parts.append(f"- **Exported:** {symbol_spec.get('is_exported', False)}")

    # Class-specific
    if symbol_spec.get("bases"):
        bases = ", ".join(f"{b['name']} ({b['relationship']})" for b in symbol_spec["bases"])
        parts.append(f"- **Inherits:** {bases}")
    if symbol_spec.get("methods"):
        methods = ", ".join(m["name"] for m in symbol_spec["methods"])
        parts.append(f"- **Methods (MUST preserve public ones):** {methods}")

    # Callers
    if symbol_spec.get("external_caller_count", 0) > 0:
        parts.append(f"\n## External Callers ({symbol_spec['external_caller_count']})")
        parts.append("These call sites MUST continue to work after rewrite:")
        for c in symbol_spec.get("callers", [])[:10]:
            if c.get("is_external"):
                parts.append(f"- `{c['source']}` in `{c['source_file']}`")

    # Dependencies
    if module_spec.get("dependencies"):
        parts.append(f"\n## Module Dependencies")
        for d in module_spec["dependencies"][:10]:
            parts.append(f"- `{d}`")

    # Rewrite notes
    if module_spec.get("rewrite_notes"):
        parts.append(f"\n## Rewrite Notes")
        for note in module_spec["rewrite_notes"]:
            parts.append(f"- {note}")

    # Extra file context (other symbols in same file already rewritten)
    if file_context:
        parts.append(f"\n## Already Rewritten (same file)\n")
        parts.append(f"```\n{file_context}\n```")

    parts.append("\n## Task")
    parts.append("Rewrite the symbol above for the modern stack. "
                 "Preserve the public contract. Output ONLY the code.")

    return "\n".join(parts)


def _build_file_rewrite_prompt(
    source_code: str,
    module_spec: dict,
) -> str:
    """Build a prompt to rewrite an entire file at once."""
    parts = []

    parts.append("## Current Source Code\n")
    parts.append(f"File: `{module_spec.get('file_path', '?')}`\n")
    parts.append(f"```\n{source_code}\n```\n")

    # Contracts to preserve
    exported = [s for s in module_spec.get("symbols", []) if s.get("is_exported")]
    if exported:
        parts.append("## Public API (MUST preserve all of these):\n")
        for s in exported:
            sig = f" `{s['signature']}`" if s.get("signature") else ""
            parts.append(f"- **{s['name']}** ({s['type']}){sig}")
            if s.get("bases"):
                bases = ", ".join(b["name"] for b in s["bases"])
                parts.append(f"  - Inherits: {bases}")
            if s.get("methods"):
                public = [m["name"] for m in s["methods"] if m.get("is_exported")]
                if public:
                    parts.append(f"  - Public methods: {', '.join(public)}")

    # Dependencies
    if module_spec.get("dependencies"):
        parts.append(f"\n## Dependencies (this file imports from):")
        for d in module_spec["dependencies"][:15]:
            parts.append(f"- `{d}`")

    # Dependents
    if module_spec.get("dependents"):
        parts.append(f"\n## Dependents ({len(module_spec['dependents'])} files import from this):")
        for d in module_spec["dependents"][:10]:
            parts.append(f"- `{d}`")

    # Rewrite notes
    if module_spec.get("rewrite_notes"):
        parts.append(f"\n## Rewrite Notes:")
        for note in module_spec["rewrite_notes"]:
            parts.append(f"- {note}")

    # Test scenarios
    if module_spec.get("test_scenarios"):
        parts.append(f"\n## Validation Tests (code must pass these):")
        for t in module_spec["test_scenarios"][:8]:
            parts.append(f"- {t['description']}")
            for check in t.get("checks", [])[:3]:
                parts.append(f"  - {check}")

    # Frontend component contract
    comp_info = module_spec.get("component_info", {})
    if comp_info:
        parts.append("\n## Component Contract (MUST PRESERVE)")
        if comp_info.get("props"):
            parts.append(f"- **Props:** `{comp_info['props']}`")
        if comp_info.get("children_rendered"):
            parts.append(f"- **Renders:** {', '.join(comp_info['children_rendered'])}")
        if comp_info.get("routes_served"):
            parts.append(f"- **Routes:** {', '.join(comp_info['routes_served'])}")
        if comp_info.get("api_calls"):
            parts.append(f"- **API:** {', '.join(comp_info['api_calls'])}")
        if comp_info.get("state_subscriptions"):
            parts.append(f"- **State:** {', '.join(comp_info['state_subscriptions'])}")
        if comp_info.get("hooks_used"):
            parts.append(f"- **Hooks:** {', '.join(comp_info['hooks_used'])}")
        parts.append("")
        parts.append("Preserve the component hierarchy — every child component must still be rendered.")
        parts.append("Preserve the props interface — do not add required props or remove existing ones.")
        parts.append("Preserve all route paths exactly.")
        parts.append("Preserve all API endpoint URLs.")

    parts.append("\n## Task")
    parts.append("Rewrite this entire file for the modern stack. "
                 "Preserve ALL exported symbols with compatible signatures. "
                 "Output ONLY the complete file code, nothing else.")

    return "\n".join(parts)


def _build_translation_system_prompt(
    source_lang: str,
    target_lang: str,
    target_stack: str,
    guidelines: str,
) -> str:
    """Build the system prompt for cross-language translation."""
    parts = [
        f"You are a senior software engineer translating code from {source_lang} to {target_lang}.",
        f"Translate the code to idiomatic {target_lang}. Use {target_lang} conventions, "
        f"naming styles, error handling patterns, and standard library features.",
        "You MUST preserve the exact public API contract — same function/class names, "
        "compatible parameters (adapted to target language conventions), "
        "compatible return types.",
        "You MUST NOT remove any exported symbol. All public functions, classes, "
        "and constants must exist in the translated code.",
        "If a construct has no direct equivalent in the target language, add a "
        "comment: // WARNING: manual review needed — [explain what changed]",
        "Output ONLY the translated code. No explanation, no markdown fences — just the code.",
    ]
    if target_stack:
        parts.append(f"\nTarget stack/framework: {target_stack}")
        parts.append(f"Use {target_stack} idioms and APIs. Do NOT use raw stdlib "
                     f"when {target_stack} provides a higher-level API.")
    if guidelines:
        parts.append(f"\nGuidelines: {guidelines}")
    return "\n".join(parts)


def _detect_construct_warnings(
    source_code: str,
    source_lang: str,
    target_lang: str,
) -> list[str]:
    """Scan source code for constructs that are hard to translate.

    Returns human-readable warnings — not blockers, just things to verify.
    """
    patterns = TRANSLATION_WARNINGS.get(source_lang, {})
    warnings = []
    for pattern, message in patterns.items():
        if re.search(pattern, source_code):
            warnings.append(f"[{source_lang}→{target_lang}] {message}")
    return warnings


def _build_retry_prompt(
    original_prompt: str,
    previous_code: str,
    validation_errors: list[str],
) -> str:
    """Build a retry prompt with structural feedback."""
    parts = [
        "## Previous Attempt (FAILED VALIDATION)\n",
        f"```\n{previous_code}\n```\n",
        "## Validation Errors\n",
    ]
    for err in validation_errors:
        parts.append(f"- {err}")

    parts.append("\n## Original Requirements\n")
    parts.append(original_prompt)
    parts.append("\n## Task")
    parts.append("Fix the validation errors above. The previous code broke the "
                 "structural contract. Output ONLY the corrected code.")

    return "\n".join(parts)


def _extract_code(response: str) -> str:
    """Extract code from LLM response, stripping markdown fences if present."""
    # Try to extract from code fences
    pattern = r"```(?:python|java|typescript|javascript|tsx|jsx|go|golang|rust|rs|kotlin|kt|csharp|cs|dart)?\s*\n(.*?)```"
    matches = re.findall(pattern, response, re.DOTALL)
    if matches:
        # Return the longest match (likely the full code)
        return max(matches, key=len).strip()

    # If no fences, strip any leading/trailing explanation
    lines = response.strip().split("\n")

    # Remove leading text lines that look like explanations
    start = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if (stripped.startswith(("import ", "from ", "def ", "class ", "#!", "\"\"\"",
                                 "package ", "public ", "private ", "protected ",
                                 "const ", "let ", "var ", "function ", "export ",
                                 "//", "/*", "#"))
                or stripped == ""
                or stripped.startswith("@")):
            start = i
            break

    return "\n".join(lines[start:]).strip()


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


@dataclass
class ValidationResult:
    """Result of validating a rewrite."""
    valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _parse_python_signatures(code: str) -> dict[str, dict]:
    """Parse all function/class signatures from Python code using AST.

    Returns {name: {"params": [...], "type": "function"|"class", "methods": {name: {"params": [...]}}}}
    """
    import ast as _ast

    result: dict[str, dict] = {}
    try:
        tree = _ast.parse(code)
    except SyntaxError:
        return result

    for node in _ast.iter_child_nodes(tree):
        if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
            params = [a.arg for a in node.args.args]
            defaults_count = len(node.args.defaults)
            required = params[: len(params) - defaults_count] if defaults_count else params
            result[node.name] = {
                "type": "function",
                "params": params,
                "required_params": required,
                "is_async": isinstance(node, _ast.AsyncFunctionDef),
            }
        elif isinstance(node, _ast.ClassDef):
            bases = [
                _ast.unparse(b) if hasattr(_ast, "unparse") else ""
                for b in node.bases
            ]
            methods: dict[str, dict] = {}
            init_params: list[str] = []
            init_required: list[str] = []
            for item in node.body:
                if isinstance(item, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
                    m_params = [a.arg for a in item.args.args if a.arg != "self"]
                    m_defaults = len(item.args.defaults)
                    m_required = m_params[: len(m_params) - m_defaults] if m_defaults else m_params
                    methods[item.name] = {
                        "params": m_params,
                        "required_params": m_required,
                    }
                    if item.name == "__init__":
                        init_params = m_params
                        init_required = m_required
            result[node.name] = {
                "type": "class",
                "bases": bases,
                "methods": methods,
                "init_params": init_params,
                "init_required": init_required,
            }
    return result


def _parse_js_signatures(code: str) -> dict[str, dict]:
    """Parse JS/TS code to extract function/class/enum signatures via tree-sitter.

    Returns same structure as _parse_python_signatures for reuse of validation logic.
    """
    try:
        from tree_sitter_languages import get_language, get_parser
    except ImportError:
        return {}

    result: dict[str, dict] = {}
    try:
        parser = get_parser("typescript")
        tree = parser.parse(code.encode("utf-8"))
    except Exception:
        return result

    def _text(node) -> str:
        return node.text.decode("utf-8") if node else ""

    def _find(node, type_name):
        for c in node.children:
            if c.type == type_name:
                return c
        return None

    def _extract_params(formal_params):
        """Extract param names from formal_parameters node."""
        params, required = [], []
        if not formal_params:
            return params, required
        for p in formal_params.children:
            if p.type in ("required_parameter", "formal_parameter"):
                # Name is the first identifier (skip type annotations)
                ident = _find(p, "identifier")
                if ident:
                    name = _text(ident)
                    params.append(name)
                    required.append(name)
                else:
                    # Destructured param — use full text
                    pat = _find(p, "object_pattern") or _find(p, "array_pattern")
                    if pat:
                        params.append(_text(pat))
                        required.append(_text(pat))
            elif p.type == "optional_parameter":
                ident = _find(p, "identifier")
                if ident:
                    params.append(_text(ident))
            elif p.type == "rest_parameter":
                ident = _find(p, "identifier")
                if ident:
                    params.append(_text(ident))
        return params, required

    def _process_function(node, name=None):
        if not name:
            ident = _find(node, "identifier")
            name = _text(ident) if ident else None
        if not name:
            return
        fp = _find(node, "formal_parameters")
        params, required = _extract_params(fp)
        result[name] = {"type": "function", "params": params, "required_params": required}

    def _process_class(node):
        ident = _find(node, "type_identifier") or _find(node, "identifier")
        name = _text(ident) if ident else None
        if not name:
            return

        bases = []
        heritage = _find(node, "class_heritage")
        if heritage:
            for clause in heritage.children:
                if clause.type in ("extends_clause", "implements_clause"):
                    for c in clause.children:
                        if c.type in ("type_identifier", "identifier", "generic_type"):
                            bases.append(_text(c).split("<")[0])

        methods: dict[str, dict] = {}
        init_params: list[str] = []
        init_required: list[str] = []

        body = _find(node, "class_body")
        if body:
            for member in body.children:
                if member.type in ("method_definition", "public_field_definition"):
                    mname_node = _find(member, "property_identifier")
                    mname = _text(mname_node) if mname_node else ""
                    fp = _find(member, "formal_parameters")
                    mparams, mreq = _extract_params(fp)
                    if mname == "constructor":
                        init_params = mparams
                        init_required = mreq
                    elif mname:
                        methods[mname] = {"params": mparams, "required_params": mreq}

        result[name] = {
            "type": "class", "bases": bases, "methods": methods,
            "init_params": init_params, "init_required": init_required,
        }

    def _process_interface(node):
        ident = _find(node, "type_identifier") or _find(node, "identifier")
        name = _text(ident) if ident else None
        if not name:
            return
        bases = []
        ext = _find(node, "extends_type_clause")
        if ext:
            for c in ext.children:
                if c.type in ("type_identifier", "generic_type"):
                    bases.append(_text(c).split("<")[0])
        methods: dict[str, dict] = {}
        body = _find(node, "interface_body") or _find(node, "object_type")
        if body:
            for member in body.children:
                if member.type in ("method_signature", "property_signature"):
                    mname_node = _find(member, "property_identifier")
                    mname = _text(mname_node) if mname_node else ""
                    fp = _find(member, "formal_parameters")
                    mparams, mreq = _extract_params(fp)
                    if mname:
                        methods[mname] = {"params": mparams, "required_params": mreq}
        result[name] = {
            "type": "class", "bases": bases, "methods": methods,
            "init_params": [], "init_required": [],
        }

    def _process_enum(node):
        ident = _find(node, "identifier")
        name = _text(ident) if ident else None
        if not name:
            return
        members = []
        body = _find(node, "enum_body")
        if body:
            for m in body.children:
                if m.type == "enum_assignment":
                    mid = _find(m, "property_identifier")
                    if mid:
                        members.append(_text(mid))
                elif m.type == "property_identifier":
                    members.append(_text(m))
        result[name] = {"type": "enum", "members": members}

    def _process_node(node):
        if node.type in ("function_declaration", "generator_function_declaration"):
            _process_function(node)
        elif node.type in ("class_declaration", "abstract_class_declaration"):
            _process_class(node)
        elif node.type == "interface_declaration":
            _process_interface(node)
        elif node.type == "enum_declaration":
            _process_enum(node)
        elif node.type in ("lexical_declaration", "variable_declaration"):
            for decl in node.children:
                if decl.type == "variable_declarator":
                    ident = _find(decl, "identifier")
                    val = None
                    for c in decl.children:
                        if c.type in ("arrow_function", "function_expression",
                                      "function", "generator_function"):
                            val = c
                            break
                    if val and ident:
                        _process_function(val, name=_text(ident))
                    elif ident and not val:
                        # Could be a constant — record it
                        name = _text(ident)
                        if name and name[0].isupper() or name.isupper():
                            result[name] = {"type": "constant"}
        elif node.type == "export_statement":
            for c in node.children:
                _process_node(c)
        elif node.type == "type_alias_declaration":
            ident = _find(node, "type_identifier")
            if ident:
                result[_text(ident)] = {"type": "type_alias"}

    for child in tree.root_node.children:
        _process_node(child)

    return result


def _parse_java_signatures(code: str) -> dict[str, dict]:
    """Parse Java code to extract class/interface/enum signatures via tree-sitter."""
    try:
        from tree_sitter_languages import get_language, get_parser
    except ImportError:
        return {}

    result: dict[str, dict] = {}
    try:
        parser = get_parser("java")
        tree = parser.parse(code.encode("utf-8"))
    except Exception:
        return result

    def _text(node) -> str:
        return node.text.decode("utf-8") if node else ""

    def _find(node, type_name):
        for c in node.children:
            if c.type == type_name:
                return c
        return None

    def _extract_params(formal_params):
        params, required = [], []
        if not formal_params:
            return params, required
        for p in formal_params.children:
            if p.type in ("formal_parameter", "spread_parameter"):
                ident = _find(p, "identifier")
                if ident:
                    name = _text(ident)
                    params.append(name)
                    required.append(name)
        return params, required

    def _process_class(node):
        ident = _find(node, "identifier")
        name = _text(ident) if ident else None
        if not name:
            return

        bases = []
        superclass = _find(node, "superclass")
        if superclass:
            for c in superclass.children:
                if c.type in ("type_identifier", "generic_type"):
                    bases.append(_text(c).split("<")[0])
        ifaces = _find(node, "super_interfaces")
        if ifaces:
            for c in ifaces.children:
                if c.type == "type_list":
                    for t in c.children:
                        if t.type in ("type_identifier", "generic_type"):
                            bases.append(_text(t).split("<")[0])

        methods: dict[str, dict] = {}
        init_params: list[str] = []
        init_required: list[str] = []

        body = _find(node, "class_body")
        if body:
            for member in body.children:
                if member.type == "method_declaration":
                    mident = _find(member, "identifier")
                    mname = _text(mident) if mident else ""
                    fp = _find(member, "formal_parameters")
                    mparams, mreq = _extract_params(fp)
                    if mname:
                        methods[mname] = {"params": mparams, "required_params": mreq}
                elif member.type == "constructor_declaration":
                    fp = _find(member, "formal_parameters")
                    init_params, init_required = _extract_params(fp)

        result[name] = {
            "type": "class", "bases": bases, "methods": methods,
            "init_params": init_params, "init_required": init_required,
        }

    def _process_interface(node):
        ident = _find(node, "identifier")
        name = _text(ident) if ident else None
        if not name:
            return
        bases = []
        ext = _find(node, "extends_interfaces")
        if ext:
            for c in ext.children:
                if c.type == "type_list":
                    for t in c.children:
                        if t.type in ("type_identifier", "generic_type"):
                            bases.append(_text(t).split("<")[0])
        methods: dict[str, dict] = {}
        body = _find(node, "interface_body")
        if body:
            for member in body.children:
                if member.type == "method_declaration":
                    mident = _find(member, "identifier")
                    mname = _text(mident) if mident else ""
                    fp = _find(member, "formal_parameters")
                    mparams, mreq = _extract_params(fp)
                    if mname:
                        methods[mname] = {"params": mparams, "required_params": mreq}
        result[name] = {
            "type": "class", "bases": bases, "methods": methods,
            "init_params": [], "init_required": [],
        }

    def _process_enum(node):
        ident = _find(node, "identifier")
        name = _text(ident) if ident else None
        if not name:
            return
        members = []
        body = _find(node, "enum_body")
        if body:
            for m in body.children:
                if m.type == "enum_constant":
                    mid = _find(m, "identifier")
                    if mid:
                        members.append(_text(mid))
        result[name] = {"type": "enum", "members": members}

    def _walk(node):
        if node.type in ("class_declaration",):
            _process_class(node)
        elif node.type == "interface_declaration":
            _process_interface(node)
        elif node.type == "enum_declaration":
            _process_enum(node)
        for c in node.children:
            if c.type in ("class_declaration", "interface_declaration",
                          "enum_declaration", "program"):
                _walk(c)

    _walk(tree.root_node)
    return result


def _validate_signatures(
    old_sigs: dict[str, dict],
    new_sigs: dict[str, dict],
    spec_symbols: dict[str, dict],
    errors: list[str],
    warnings: list[str],
    *,
    language: str = "python",
) -> None:
    """Shared signature validation logic for all languages (checks 2-6 + enum)."""

    # 2. Check exported symbols exist (skip variables — checked separately)
    for sym_name, sym_info in spec_symbols.items():
        if not sym_info.get("is_exported"):
            continue
        if sym_info.get("type") == "variable":
            continue  # variables validated via text match in caller
        if sym_name not in new_sigs:
            errors.append(
                f"Missing exported symbol '{sym_name}' ({sym_info.get('type', '?')})"
            )

    # 3. Function signature compatibility
    for name, old_info in old_sigs.items():
        if old_info.get("type") != "function" or name not in new_sigs:
            continue
        new_info = new_sigs[name]
        if new_info.get("type") != "function":
            continue

        old_required = old_info.get("required_params", [])
        is_exported = spec_symbols.get(name, {}).get("is_exported", False)
        callers = spec_symbols.get(name, {}).get("external_caller_count", 0)

        for param in old_required:
            if param not in new_info.get("params", []):
                msg = (
                    f"Function '{name}': removed required parameter '{param}'. "
                    f"Old: ({', '.join(old_info.get('params', []))}), "
                    f"New: ({', '.join(new_info.get('params', []))})"
                )
                if is_exported or callers > 0:
                    errors.append(msg + " — callers will break")
                else:
                    warnings.append(msg)

    # 4. Constructor contract
    for name, old_info in old_sigs.items():
        if old_info.get("type") != "class" or name not in new_sigs:
            continue
        new_info = new_sigs[name]
        if new_info.get("type") != "class":
            errors.append(f"'{name}' changed from class to {new_info.get('type')}")
            continue

        old_init = old_info.get("init_required", [])
        old_init_all = old_info.get("init_params", [])
        new_init = new_info.get("init_required", [])
        new_init_all = new_info.get("init_params", [])

        is_exported = spec_symbols.get(name, {}).get("is_exported", False)
        callers = spec_symbols.get(name, {}).get("external_caller_count", 0)

        ctor_name = "__init__" if language == "python" else "constructor"

        for param in old_init:
            if param not in new_init_all:
                msg = (
                    f"Class '{name}.{ctor_name}': removed required parameter '{param}'. "
                    f"Old: ({', '.join(old_init_all)}), New: ({', '.join(new_init_all)})"
                )
                if is_exported or callers > 0:
                    errors.append(msg)
                else:
                    warnings.append(msg)

        for param in old_init_all:
            if param in old_init:
                continue
            if param not in new_init_all:
                msg = (
                    f"Class '{name}.{ctor_name}': removed optional parameter '{param}'. "
                    f"Old: ({', '.join(old_init_all)}), New: ({', '.join(new_init_all)})"
                )
                if is_exported or callers > 0:
                    errors.append(msg)
                else:
                    warnings.append(msg)

        for param in new_init:
            if param not in old_init_all:
                if is_exported or callers > 0:
                    errors.append(
                        f"Class '{name}.{ctor_name}': added new required parameter '{param}'. "
                        f"Old: ({', '.join(old_init_all)}), New: ({', '.join(new_init_all)})"
                    )

    # 5. Public method signatures
    for name, old_info in old_sigs.items():
        if old_info.get("type") != "class" or name not in new_sigs:
            continue
        new_info = new_sigs[name]
        if new_info.get("type") != "class":
            continue
        old_methods = old_info.get("methods", {})
        new_methods = new_info.get("methods", {})
        skip_prefix = "_" if language == "python" else None
        ctor = "__init__" if language == "python" else "constructor"

        for mname, old_m in old_methods.items():
            if skip_prefix and mname.startswith(skip_prefix) and mname != ctor:
                continue
            if mname == ctor:
                continue  # Checked above
            if mname not in new_methods:
                warnings.append(f"Class '{name}': public method '{mname}' removed")
                continue
            new_m = new_methods[mname]
            for param in old_m.get("required_params", []):
                if param not in new_m.get("params", []):
                    warnings.append(
                        f"Class '{name}.{mname}': parameter '{param}' removed. "
                        f"Old: ({', '.join(old_m.get('params', []))}), "
                        f"New: ({', '.join(new_m.get('params', []))})"
                    )

    # 6. Class hierarchies
    for name, old_info in old_sigs.items():
        if old_info.get("type") != "class" or name not in new_sigs:
            continue
        new_info = new_sigs[name]
        if new_info.get("type") != "class":
            continue
        old_bases = set(old_info.get("bases", []))
        new_bases = set(new_info.get("bases", []))
        for base in old_bases:
            if base and base not in new_bases and base not in ("object", "Object"):
                warnings.append(
                    f"Class '{name}': no longer extends '{base}'. "
                    f"Old bases: {old_bases}, New bases: {new_bases}"
                )

    # 7. Enum member preservation
    for name, old_info in old_sigs.items():
        if old_info.get("type") != "enum" or name not in new_sigs:
            continue
        new_info = new_sigs[name]
        if new_info.get("type") != "enum":
            errors.append(f"'{name}' changed from enum to {new_info.get('type')}")
            continue
        old_members = set(old_info.get("members", []))
        new_members = set(new_info.get("members", []))
        for member in old_members:
            if member not in new_members:
                errors.append(
                    f"Enum '{name}': removed member '{member}' — "
                    f"code referencing {name}.{member} will break"
                )


def _validate_orm_python(
    old_spec: dict,
    old_source: str,
    new_code: str,
    errors: list[str],
    warnings: list[str],
) -> None:
    """Validate ORM model preservation in Python rewrites."""
    # Check if any symbols have orm_model decorator
    has_orm = any(
        "orm_model" in s.get("decorators", [])
        for s in old_spec.get("symbols", [])
    )
    if not has_orm:
        return

    # __tablename__ preservation (regex scan)
    tablename_re = re.compile(r'__tablename__\s*=\s*["\'](\w+)["\']')
    old_tables = tablename_re.findall(old_source)
    for table in old_tables:
        if table not in new_code:
            errors.append(
                f"ORM __tablename__ = '{table}' removed — "
                f"database table mapping MUST be preserved"
            )

    # Check relationship/ForeignKey fields exist
    for field_name in ("relationship", "ForeignKey"):
        if field_name + "(" in old_source and field_name + "(" not in new_code:
            warnings.append(
                f"ORM {field_name}() appears to be removed — "
                f"check that database relationships are preserved"
            )


def _validate_jpa_java(
    old_spec: dict,
    old_source: str,
    new_code: str,
    errors: list[str],
    warnings: list[str],
) -> None:
    """Validate JPA entity preservation in Java rewrites."""
    has_entity = any(
        "@Entity" in s.get("decorators", []) or "Entity" in s.get("decorators", [])
        for s in old_spec.get("symbols", [])
    )
    # Also check old_source directly
    if not has_entity and "@Entity" not in old_source:
        return

    if "@Entity" in old_source and "@Entity" not in new_code:
        errors.append("JPA @Entity annotation removed — MUST be preserved")

    if "@Table" in old_source and "@Table" not in new_code:
        errors.append("JPA @Table annotation removed — MUST be preserved")

    # Relationship annotations
    jpa_rels = ["@OneToMany", "@ManyToOne", "@OneToOne", "@ManyToMany"]
    for ann in jpa_rels:
        if ann in old_source and ann not in new_code:
            warnings.append(
                f"JPA {ann} annotation removed — "
                f"check that entity relationships are preserved"
            )


def validate_rewrite(
    old_spec: dict,
    new_code: str,
    store: GraphStore | None = None,
    old_source: str = "",
    target_lang: str = "",
) -> ValidationResult:
    """Validate that rewritten code preserves structural contracts.

    Deep validation using AST/tree-sitter comparison:
    1. Syntax check (per language)
    2. All exported symbols still exist
    3. Function signatures are compatible (parameter-level)
    4. Class constructor signatures preserved
    5. Public method signatures preserved
    6. Class hierarchies preserved
    7. Enum members preserved

    For cross-language translation (target_lang set), syntax is checked
    against the target language, and only text-level symbol checks are used
    (no AST comparison since languages differ).
    """
    errors: list[str] = []
    warnings: list[str] = []

    file_path = old_spec.get("file_path", "")
    spec_symbols = {s["name"]: s for s in old_spec.get("symbols", [])}

    # Cross-language translation: skip source-language AST validation,
    # just check exported symbols exist in translated code as text.
    if target_lang:
        if len(new_code.strip()) < 10:
            errors.append("Generated code is too short / empty")
            return ValidationResult(valid=False, errors=errors)

        # Check exported symbols exist as text in translated code
        exported = [s for s in old_spec.get("symbols", []) if s.get("is_exported")]
        for sym in exported:
            name = sym["name"]
            if name not in new_code:
                errors.append(
                    f"Missing exported symbol '{name}' in translated code"
                )
        return ValidationResult(valid=len(errors) == 0, errors=errors, warnings=warnings)

    # 1. Syntax check (same-language rewrite)
    if file_path.endswith(".py"):
        import ast as _ast
        try:
            _ast.parse(new_code)
        except SyntaxError as e:
            errors.append(f"Syntax error: {e.msg} at line {e.lineno}")
            return ValidationResult(valid=False, errors=errors)
    elif file_path.endswith(".java"):
        if "class " not in new_code and "interface " not in new_code and "enum " not in new_code:
            errors.append("Java file must contain at least one class, interface, or enum")
    elif file_path.endswith((".ts", ".tsx", ".js", ".jsx")):
        if len(new_code.strip()) < 10:
            errors.append("Generated code is too short / empty")
    elif file_path.endswith(".vue"):
        if len(new_code.strip()) < 10:
            errors.append("Generated code is too short / empty")

    if errors:
        return ValidationResult(valid=False, errors=errors)

    # Route: Python — deep AST validation
    if file_path.endswith(".py"):
        import ast as _ast
        new_sigs = _parse_python_signatures(new_code)
        old_sigs = _parse_python_signatures(old_source) if old_source else {}
        _validate_signatures(old_sigs, new_sigs, spec_symbols, errors, warnings, language="python")

        # Fallback: check exported symbols via text if not in sigs
        exported = [s for s in old_spec.get("symbols", []) if s.get("is_exported")]
        for sym in exported:
            name = sym["name"]
            if name not in new_sigs:
                # Check for functions, classes, and variable assignments
                if (f"def {name}" not in new_code
                        and f"class {name}" not in new_code
                        and f"{name} =" not in new_code
                        and f"{name}:" not in new_code):
                    errors.append(
                        f"Missing exported symbol '{name}' ({sym['type']}) — "
                        f"was: {sym.get('signature', '?')}"
                    )

    # Route: JS/TS — tree-sitter deep validation
    elif file_path.endswith((".ts", ".tsx", ".js", ".jsx")):
        new_sigs = _parse_js_signatures(new_code)
        old_sigs = _parse_js_signatures(old_source) if old_source else {}

        if new_sigs or old_sigs:
            # Deep validation available
            _validate_signatures(old_sigs, new_sigs, spec_symbols, errors, warnings, language="js")
        else:
            # Fallback: string matching
            exported = [s for s in old_spec.get("symbols", []) if s.get("is_exported")]
            for sym in exported:
                if sym["name"] not in new_code:
                    errors.append(f"Missing exported symbol '{sym['name']}'")

    # Route: Java — tree-sitter deep validation
    elif file_path.endswith(".java"):
        new_sigs = _parse_java_signatures(new_code)
        old_sigs = _parse_java_signatures(old_source) if old_source else {}

        if new_sigs or old_sigs:
            _validate_signatures(old_sigs, new_sigs, spec_symbols, errors, warnings, language="java")
        else:
            exported = [s for s in old_spec.get("symbols", []) if s.get("is_exported")]
            for sym in exported:
                if sym["name"] not in new_code:
                    errors.append(f"Missing exported symbol '{sym['name']}'")

    # Route: Vue/other — basic string matching
    elif file_path.endswith(".vue"):
        # Vue SFCs use default exports via <script> or <script setup> — symbol names
        # appear as `name: 'Foo'` or are inferred from filename, not `export function Foo`.
        # Only error if the symbol name is completely absent AND no script/template tags exist.
        exported = [s for s in old_spec.get("symbols", []) if s.get("is_exported")]
        for sym in exported:
            name = sym["name"]
            # Check: name in code, or name: 'X' pattern, or <script setup> (auto-export)
            found = (
                name in new_code
                or f"name: '{name}'" in new_code
                or f'name: "{name}"' in new_code
                or "<script setup" in new_code
                or "export default" in new_code
            )
            if not found:
                errors.append(f"Missing exported symbol '{name}'")
    else:
        exported = [s for s in old_spec.get("symbols", []) if s.get("is_exported")]
        for sym in exported:
            if sym["name"] not in new_code:
                errors.append(f"Missing exported symbol '{sym['name']}'")

    # Frontend-specific: component children, routes, API calls
    comp_info = old_spec.get("component_info", {})
    if comp_info and file_path.endswith((".tsx", ".jsx", ".vue", ".js", ".ts")):
        for child in comp_info.get("children_rendered", []):
            if f"<{child}" not in new_code:
                errors.append(
                    f"Missing child component '<{child}>' — "
                    f"the original renders this component"
                )
        for route in comp_info.get("routes_served", []):
            if route not in new_code:
                warnings.append(f"Route path '{route}' not found in rewritten code")
        for url in comp_info.get("api_calls", []):
            if url not in new_code:
                warnings.append(f"API endpoint '{url}' not found in rewritten code")

    # ORM model validation (Python)
    if file_path.endswith(".py") and old_source:
        _validate_orm_python(old_spec, old_source, new_code, errors, warnings)

    # JPA entity validation (Java)
    if file_path.endswith(".java") and old_source:
        _validate_jpa_java(old_spec, old_source, new_code, errors, warnings)

    return ValidationResult(valid=len(errors) == 0, errors=errors, warnings=warnings)


# ---------------------------------------------------------------------------
# Build verification
# ---------------------------------------------------------------------------


@dataclass
class BuildResult:
    """Result of running the target language build tool."""
    success: bool
    errors: list[str] = field(default_factory=list)
    raw_stderr: str = ""
    build_tool: str = ""
    elapsed_ms: int = 0


def _detect_build_cmd(target_lang: str, output_dir: Path) -> tuple[list[str], str]:
    """Detect the build command for a target language.

    Returns (command_list, tool_name). Empty list if tool not found.
    """
    spec = BUILD_TOOLS.get(target_lang)
    if not spec:
        return [], ""

    # Java/Kotlin: prefer maven/gradle over bare compiler
    if spec.get("build_detect"):
        if (output_dir / "pom.xml").exists() and shutil.which("mvn"):
            return ["mvn", "compile", "-q"], "mvn"
        if (output_dir / "build.gradle").exists() and shutil.which("gradle"):
            cmd = "compileJava" if target_lang == "java" else "compileKotlin"
            return ["gradle", cmd, "-q"], "gradle"
        if (output_dir / "build.gradle.kts").exists() and shutil.which("gradle"):
            cmd = "compileJava" if target_lang == "java" else "compileKotlin"
            return ["gradle", cmd, "-q"], "gradle"
        # Fallback to bare compiler
        if shutil.which(spec["cmd"]):
            return spec.get("fallback", []), spec["cmd"]
        return [], ""

    # Standard: check primary command
    if shutil.which(spec["cmd"]):
        return spec.get("build", []), spec["cmd"]

    # Fallback command (e.g., npx tsc)
    fallback_cmd = spec.get("fallback_cmd")
    if fallback_cmd and shutil.which(fallback_cmd):
        return spec.get("fallback", []), fallback_cmd

    return [], ""


def _scaffold_project(target_lang: str, output_dir: Path) -> None:
    """Generate minimal project files if missing (go.mod, Cargo.toml, etc.)."""
    spec = BUILD_TOOLS.get(target_lang)
    if not spec:
        return
    for filename, content in spec.get("scaffold", {}).items():
        filepath = output_dir / filename
        if not filepath.exists():
            filepath.write_text(content, encoding="utf-8")


def _parse_compiler_errors(stderr: str, target_lang: str) -> list[str]:
    """Extract structured error messages from compiler output."""
    errors = []
    for line in stderr.splitlines():
        line = line.strip()
        if not line:
            continue
        # Match common error patterns across compilers:
        # Go:   "file.go:10:5: undefined: SomeFunc"
        # Java: "file.java:10: error: cannot find symbol"
        # Rust: "error[E0425]: cannot find value `x`"
        # TS:   "file.ts(10,5): error TS2304: Cannot find name 'x'"
        # C#:   "file.cs(10,5): error CS0246: The type or namespace..."
        markers = ["error", "Error", "ERROR", "undefined", "cannot find",
                   "unresolved", "not found", "no such", "expected"]
        if any(m in line for m in markers):
            errors.append(line)
    return errors[:20]  # cap to keep retry prompt manageable


def _run_build(
    output_dir: Path,
    target_lang: str,
    timeout: int = 120,
) -> BuildResult:
    """Run the target language build tool. Returns structured result."""
    build_cmd, tool_name = _detect_build_cmd(target_lang, output_dir)

    if not build_cmd:
        tool_needed = BUILD_TOOLS.get(target_lang, {}).get("cmd", target_lang)
        return BuildResult(
            success=False,
            errors=[
                f"Build tool for {target_lang} not found on PATH. "
                f"Install '{tool_needed}' and retry for build verification."
            ],
            build_tool="none",
        )

    # Scaffold project files if missing
    _scaffold_project(target_lang, output_dir)

    start = time.monotonic()
    try:
        proc = subprocess.run(
            build_cmd,
            cwd=str(output_dir),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        elapsed = int((time.monotonic() - start) * 1000)

        if proc.returncode == 0:
            return BuildResult(
                success=True, build_tool=tool_name, elapsed_ms=elapsed,
            )

        stderr = proc.stderr or proc.stdout or ""
        errors = _parse_compiler_errors(stderr, target_lang)
        if not errors:
            errors = [f"Build failed with exit code {proc.returncode}"]

        return BuildResult(
            success=False,
            errors=errors,
            raw_stderr=stderr[:4000],
            build_tool=tool_name,
            elapsed_ms=elapsed,
        )

    except subprocess.TimeoutExpired:
        elapsed = int((time.monotonic() - start) * 1000)
        return BuildResult(
            success=False,
            errors=[f"Build timed out after {timeout}s"],
            build_tool=tool_name,
            elapsed_ms=elapsed,
        )
    except FileNotFoundError:
        return BuildResult(
            success=False,
            errors=[f"Build command not found: {build_cmd[0]}"],
            build_tool="none",
        )


# ---------------------------------------------------------------------------
# Rewrite engine
# ---------------------------------------------------------------------------


@dataclass
class RewriteResult:
    """Result of rewriting a single module."""
    file_path: str
    status: str  # "success", "partial", "failed", "skipped", "unverified"
    code: str = ""
    attempts: int = 0
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    tokens_used: int = 0
    latency_ms: int = 0


@dataclass
class ModernizationResult:
    """Result of the full modernization run."""
    total_modules: int = 0
    succeeded: int = 0
    failed: int = 0
    skipped: int = 0
    modules: list[RewriteResult] = field(default_factory=list)
    total_tokens: int = 0
    total_time_ms: int = 0
    output_dir: str = ""

    def to_dict(self) -> dict:
        return {
            "total_modules": self.total_modules,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "skipped": self.skipped,
            "total_tokens": self.total_tokens,
            "total_time_ms": self.total_time_ms,
            "output_dir": self.output_dir,
            "modules": [
                {
                    "file_path": m.file_path,
                    "status": m.status,
                    "attempts": m.attempts,
                    "errors": m.errors,
                    "warnings": m.warnings,
                    "tokens_used": m.tokens_used,
                }
                for m in self.modules
            ],
        }

    def to_markdown(self) -> str:
        lines = []
        lines.append("# Modernization Report\n")
        lines.append(f"*Generated on {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n")
        lines.append("## Summary\n")
        lines.append(f"| Metric | Value |")
        lines.append(f"|--------|-------|")
        lines.append(f"| Total modules | {self.total_modules} |")
        lines.append(f"| Succeeded | {self.succeeded} |")
        lines.append(f"| Failed | {self.failed} |")
        lines.append(f"| Skipped | {self.skipped} |")
        lines.append(f"| Total tokens | {self.total_tokens} |")
        lines.append(f"| Output | `{self.output_dir}` |")
        lines.append("")

        if self.failed > 0:
            lines.append("## Failed Modules\n")
            for m in self.modules:
                if m.status == "failed":
                    lines.append(f"### `{m.file_path}` ({m.attempts} attempts)\n")
                    for e in m.errors:
                        lines.append(f"- {e}")
                    lines.append("")

        lines.append("## All Modules\n")
        lines.append("| File | Status | Attempts | Warnings |")
        lines.append("|------|--------|----------|----------|")
        for m in self.modules:
            warn_count = len(m.warnings)
            lines.append(f"| `{m.file_path}` | {m.status} | {m.attempts} | {warn_count} |")

        return "\n".join(lines)


class RewriteEngine:
    """Orchestrate module-by-module rewriting with validate-retry loop.

    Usage::

        engine = RewriteEngine(
            old_root=Path("old-project"),
            store=store,
            client=create_client(provider="ollama"),
        )
        result = engine.rewrite_all(
            output_dir=Path("new-project"),
            target_stack="FastAPI + SQLAlchemy",
        )
    """

    def __init__(
        self,
        old_root: Path,
        store: GraphStore,
        client: LLMClient,
        max_retries: int = 3,
        target_lang: str = "",
    ):
        self.old_root = old_root
        self.store = store
        self.client = client
        self.max_retries = max_retries
        self.target_lang = target_lang  # "" = same-language rewrite
        self.spec_gen = SpecGenerator(store)

    def rewrite_all(
        self,
        output_dir: Path,
        *,
        target_stack: str = "",
        guidelines: str = "",
        modules: list[str] | None = None,
        dry_run: bool = False,
        on_progress: Any = None,
    ) -> ModernizationResult:
        """Rewrite the entire codebase module by module.

        Args:
            output_dir: Where to write the modernized code.
            target_stack: Target technology description.
            guidelines: Additional constraints.
            modules: Specific modules to rewrite (None = all).
            dry_run: Generate prompts but don't call LLM.
            on_progress: Callback(file_path, status) for progress updates.
        """
        start_time = time.monotonic()
        result = ModernizationResult(output_dir=str(output_dir))

        # Generate full spec
        spec = self.spec_gen.generate_full_spec(
            target_stack=target_stack,
            guidelines=guidelines,
        )

        effective_lang = self.target_lang

        # Choose prompt based on translation vs rewrite mode
        if effective_lang:
            source_lang = self._detect_source_lang()
            system_prompt = _build_translation_system_prompt(
                source_lang, effective_lang, target_stack, guidelines,
            )
        else:
            system_prompt = _build_system_prompt(target_stack, guidelines)

        # Determine module order (from rewrite plan phases)
        phase_order = spec["rewrite_plan"]["phase_order"]
        all_modules = list(spec["module_specs"].keys())

        # Sort by phase (dependency order)
        def sort_key(fp):
            info = phase_order.get(fp, {})
            return (info.get("phase", 999), fp)

        ordered = sorted(all_modules, key=sort_key)

        # Filter if specific modules requested
        if modules:
            ordered = [fp for fp in ordered if fp in modules]

        result.total_modules = len(ordered)

        for fp in ordered:
            mod_spec = spec["module_specs"][fp]

            # Skip test files
            if mod_spec.get("role") == "test":
                result.skipped += 1
                result.modules.append(RewriteResult(
                    file_path=fp, status="skipped",
                ))
                if on_progress:
                    on_progress(fp, "skipped")
                continue

            # Read source
            source_path = self.old_root / fp
            if not source_path.exists():
                result.skipped += 1
                result.modules.append(RewriteResult(
                    file_path=fp, status="skipped",
                    errors=[f"Source file not found: {source_path}"],
                ))
                continue

            source_code = source_path.read_text(encoding="utf-8", errors="replace")

            if on_progress:
                action = "translating" if effective_lang else "rewriting"
                on_progress(fp, action)

            # Detect construct warnings for translation
            if effective_lang:
                source_lang = self._detect_lang_for_file(fp)
                construct_warnings = _detect_construct_warnings(
                    source_code, source_lang, effective_lang,
                )
            else:
                construct_warnings = []

            # Rewrite/translate with retry loop
            mod_result = self._rewrite_module(
                fp, source_code, mod_spec, system_prompt, dry_run,
            )

            # Add construct warnings
            mod_result.warnings.extend(construct_warnings)

            # Write output
            if mod_result.status in ("success", "partial") and mod_result.code and not dry_run:
                if effective_lang:
                    out_fp = _target_file_path_for_lang(fp, effective_lang)
                else:
                    out_fp = _target_file_path(fp, mod_result.code)
                out_path = output_dir / out_fp
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(mod_result.code, encoding="utf-8")
                mod_result.file_path = out_fp

            result.modules.append(mod_result)
            result.total_tokens += mod_result.tokens_used

            if mod_result.status == "success":
                result.succeeded += 1
            elif mod_result.status == "failed":
                result.failed += 1
            elif mod_result.status in ("partial", "unverified"):
                result.succeeded += 1  # Count partial/unverified as success

            if on_progress:
                on_progress(fp, mod_result.status)

        # --- Build verification for cross-language translation ---
        if effective_lang and not dry_run and result.succeeded > 0:
            if on_progress:
                on_progress("", "building")
            build_result = _run_build(output_dir, effective_lang)
            if build_result.success:
                if on_progress:
                    on_progress("", f"build OK ({build_result.build_tool})")
            elif build_result.build_tool == "none":
                # No toolchain — mark all as unverified
                for m in result.modules:
                    if m.status == "success":
                        m.status = "unverified"
                        m.warnings.extend(build_result.errors)
                if on_progress:
                    on_progress("", "build skipped (toolchain not found)")
            else:
                # Build failed — report but don't fail individual modules
                # (build errors are often cross-module, not per-module)
                if on_progress:
                    on_progress("", f"build FAILED ({build_result.build_tool})")
                for m in result.modules:
                    if m.status == "success":
                        m.status = "partial"
                        m.warnings.append(
                            f"Build failed: {'; '.join(build_result.errors[:3])}"
                        )

        result.total_time_ms = int((time.monotonic() - start_time) * 1000)
        return result

    def _detect_source_lang(self) -> str:
        """Detect the primary source language from indexed files."""
        ext_counts: dict[str, int] = defaultdict(int)
        for n in self.store.get_all_nodes():
            fp = n.get("file_path", "")
            ext = Path(fp).suffix.lower()
            ext_counts[ext] += 1

        ext_to_lang = {
            ".py": "python", ".js": "javascript", ".ts": "typescript",
            ".tsx": "typescript", ".jsx": "javascript", ".java": "java",
            ".kt": "kotlin", ".go": "go", ".rs": "rust", ".cs": "csharp",
            ".dart": "dart",
        }
        best_ext = max(ext_counts, key=ext_counts.get, default=".py")
        return ext_to_lang.get(best_ext, "python")

    @staticmethod
    def _detect_lang_for_file(file_path: str) -> str:
        """Detect source language from file extension."""
        ext = Path(file_path).suffix.lower()
        return {
            ".py": "python", ".js": "javascript", ".ts": "typescript",
            ".tsx": "typescript", ".jsx": "javascript", ".java": "java",
            ".kt": "kotlin", ".go": "go", ".rs": "rust", ".cs": "csharp",
            ".dart": "dart",
        }.get(ext, "python")

    def rewrite_module(
        self,
        file_path: str,
        *,
        target_stack: str = "",
        guidelines: str = "",
        output_dir: Path | None = None,
    ) -> RewriteResult:
        """Rewrite or translate a single module."""
        mod_spec = self.spec_gen.generate_module_spec(file_path)
        if "error" in mod_spec:
            return RewriteResult(
                file_path=file_path, status="failed",
                errors=[mod_spec["error"]],
            )

        source_path = self.old_root / file_path
        if not source_path.exists():
            return RewriteResult(
                file_path=file_path, status="failed",
                errors=[f"Source file not found: {source_path}"],
            )

        source_code = source_path.read_text(encoding="utf-8", errors="replace")

        if self.target_lang:
            source_lang = self._detect_lang_for_file(file_path)
            system_prompt = _build_translation_system_prompt(
                source_lang, self.target_lang, target_stack, guidelines,
            )
        else:
            system_prompt = _build_system_prompt(target_stack, guidelines)

        result = self._rewrite_module(file_path, source_code, mod_spec, system_prompt)

        if output_dir and result.code and result.status in ("success", "partial"):
            if self.target_lang:
                out_fp = _target_file_path_for_lang(file_path, self.target_lang)
            else:
                out_fp = _target_file_path(file_path, result.code)
            out_path = output_dir / out_fp
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(result.code, encoding="utf-8")
            result.file_path = out_fp

        return result

    def _rewrite_module(
        self,
        file_path: str,
        source_code: str,
        mod_spec: dict,
        system_prompt: str,
        dry_run: bool = False,
    ) -> RewriteResult:
        """Rewrite a module with validate-retry loop."""
        user_prompt = _build_file_rewrite_prompt(source_code, mod_spec)

        if dry_run:
            return RewriteResult(
                file_path=file_path, status="success",
                code=f"# DRY RUN — prompt length: {len(user_prompt)} chars",
                attempts=0,
            )

        total_tokens = 0
        total_latency = 0
        last_errors: list[str] = []
        all_warnings: list[str] = []
        new_code = ""

        for attempt in range(1, self.max_retries + 1):
            try:
                if attempt == 1 or not new_code:
                    prompt = user_prompt
                else:
                    prompt = _build_retry_prompt(
                        user_prompt, new_code, last_errors,
                    )

                response = self.client.complete(system_prompt, prompt)
                total_tokens += response.tokens_used
                total_latency += response.latency_ms

                new_code = _extract_code(response.content)

                # Validate
                validation = validate_rewrite(
                    mod_spec, new_code, old_source=source_code,
                    target_lang=self.target_lang,
                )
                all_warnings.extend(validation.warnings)

                if validation.valid:
                    status = "partial" if validation.warnings else "success"
                    return RewriteResult(
                        file_path=file_path,
                        status=status,
                        code=new_code,
                        attempts=attempt,
                        warnings=all_warnings,
                        tokens_used=total_tokens,
                        latency_ms=total_latency,
                    )

                last_errors = validation.errors

            except Exception as e:
                last_errors = [f"LLM error: {str(e)}"]

        # All retries exhausted
        return RewriteResult(
            file_path=file_path,
            status="failed",
            code=new_code,
            attempts=self.max_retries,
            errors=last_errors,
            warnings=all_warnings,
            tokens_used=total_tokens,
            latency_ms=total_latency,
        )


# ---------------------------------------------------------------------------
# Full pipeline: rewrite → validate → test → fix
# ---------------------------------------------------------------------------


@dataclass
class ModuleTestResult:
    """Result of running a single generated test file."""
    test_file: str
    module_file: str
    passed: bool
    test_count: int
    failures: int
    output: str  # pytest stdout/stderr


@dataclass
class PipelineResult:
    """Result of the full rewrite-and-verify pipeline."""
    rewrite: ModernizationResult
    tests_generated: int = 0
    tests_passed: int = 0
    tests_failed: int = 0
    test_results: list[ModuleTestResult] = field(default_factory=list)
    fix_attempts: int = 0
    fix_successes: int = 0
    total_tokens: int = 0
    total_time_ms: int = 0

    def to_dict(self) -> dict:
        return {
            "rewrite": self.rewrite.to_dict(),
            "tests_generated": self.tests_generated,
            "tests_passed": self.tests_passed,
            "tests_failed": self.tests_failed,
            "fix_attempts": self.fix_attempts,
            "fix_successes": self.fix_successes,
            "total_tokens": self.total_tokens,
            "total_time_ms": self.total_time_ms,
            "test_results": [
                {
                    "test_file": t.test_file,
                    "module_file": t.module_file,
                    "passed": t.passed,
                    "test_count": t.test_count,
                    "failures": t.failures,
                }
                for t in self.test_results
            ],
        }

    def to_markdown(self) -> str:
        lines = [self.rewrite.to_markdown()]
        lines.append("\n\n## Test Verification\n")
        lines.append(f"| Metric | Value |")
        lines.append(f"|--------|-------|")
        lines.append(f"| Tests generated | {self.tests_generated} |")
        lines.append(f"| Tests passed | {self.tests_passed} |")
        lines.append(f"| Tests failed | {self.tests_failed} |")
        lines.append(f"| Fix attempts | {self.fix_attempts} |")
        lines.append(f"| Fix successes | {self.fix_successes} |")
        lines.append(f"| Total tokens | {self.total_tokens} |")
        lines.append("")
        if self.test_results:
            lines.append("### Test Details\n")
            lines.append("| Module | Test File | Passed | Count | Failures |")
            lines.append("|--------|-----------|--------|-------|----------|")
            for t in self.test_results:
                status = "pass" if t.passed else "FAIL"
                lines.append(
                    f"| `{t.module_file}` | `{t.test_file}` "
                    f"| {status} | {t.test_count} | {t.failures} |"
                )
        return "\n".join(lines)


def rewrite_and_verify(
    old_root: Path,
    store: "GraphStore",
    client: LLMClient,
    output_dir: Path,
    *,
    target_stack: str = "",
    guidelines: str = "",
    max_retries: int = 3,
    max_fix_rounds: int = 2,
    on_progress: Any = None,
) -> PipelineResult:
    """Full pipeline: rewrite → validate → generate tests → run → fix.

    This is the top-level orchestrator that:
    1. Rewrites all modules (with structural validation + retry)
    2. Generates pytest tests for each rewritten module
    3. Runs the tests against the rewritten code
    4. If tests fail, feeds failures back to LLM to fix the code
    5. Re-runs tests until they pass or fix rounds exhausted

    Args:
        old_root: Path to the original project.
        store: GraphStore with the indexed original project.
        client: LLM client for code generation.
        output_dir: Where to write rewritten code.
        target_stack: Target technology description.
        guidelines: Additional constraints.
        max_retries: Retries per module during rewrite.
        max_fix_rounds: How many test-fix cycles to attempt.
        on_progress: Callback(stage, file_path, detail) for updates.
    """
    start_time = time.monotonic()

    def _progress(stage: str, fp: str, detail: str = ""):
        if on_progress:
            on_progress(stage, fp, detail)

    # --- Phase 1: Rewrite ---
    _progress("rewrite", "", "starting")
    engine = RewriteEngine(
        old_root=old_root,
        store=store,
        client=client,
        max_retries=max_retries,
    )

    def rewrite_progress(fp, status):
        _progress("rewrite", fp, status)

    rewrite_result = engine.rewrite_all(
        output_dir=output_dir,
        target_stack=target_stack,
        guidelines=guidelines,
        on_progress=rewrite_progress,
    )

    pipeline = PipelineResult(rewrite=rewrite_result)
    pipeline.total_tokens = rewrite_result.total_tokens

    # Collect successfully rewritten modules
    rewritten_modules = [
        m for m in rewrite_result.modules
        if m.status in ("success", "partial") and m.code
    ]

    if not rewritten_modules:
        pipeline.total_time_ms = int((time.monotonic() - start_time) * 1000)
        return pipeline

    # --- Phase 1.5: Validate cross-module imports ---
    _progress("validate", "", "checking imports")
    written_files = set()
    for mod in rewritten_modules:
        written_files.add(mod.file_path)

    for mod in rewritten_modules:
        code = mod.code
        if not code:
            continue
        # Retry import fixes up to 3 times (LLM may not fix all issues at once)
        for _fix_round in range(3):
            import_issues = _check_intra_package_imports(
                code, mod.file_path, written_files, output_dir,
            )
            if not import_issues:
                break
            _progress("validate", mod.file_path,
                       f"bad imports: {', '.join(import_issues)}")
            fix_prompt = (
                f"## Module: `{mod.file_path}`\n\n"
                f"```python\n{code}\n```\n\n"
                f"## Problem\n"
                f"These imports reference modules that DO NOT EXIST:\n"
                + "\n".join(f"- {issue}" for issue in import_issues) + "\n\n"
                f"## Available modules in the project (ONLY these exist)\n"
                + "\n".join(f"- {f}" for f in sorted(written_files)) + "\n\n"
                f"## Task\n"
                "Remove ALL broken imports and any code that uses them.\n"
                "Only use modules listed above.\n"
                "Output ONLY the corrected Python code — no explanations."
            )
            try:
                response = client.complete(
                    "Fix ALL broken imports. Remove them entirely. Output only Python code.",
                    fix_prompt,
                )
                fixed = _extract_code(response.content)
                pipeline.total_tokens += response.tokens_used
                import ast as _ast
                try:
                    _ast.parse(fixed)
                    out_path = output_dir / mod.file_path
                    out_path.write_text(fixed, encoding="utf-8")
                    code = fixed
                    mod.code = fixed
                    _progress("validate", mod.file_path, "imports fixed")
                except SyntaxError:
                    break
            except Exception:
                break

    # --- Phase 2: Generate tests ---
    _progress("test-gen", "", "starting")
    tests_dir = output_dir / "tests"
    tests_dir.mkdir(parents=True, exist_ok=True)

    # Create minimal pyproject.toml so pytest doesn't climb to parent project
    pyproject = output_dir / "pyproject.toml"
    if not pyproject.exists():
        pyproject.write_text(
            "[tool.pytest.ini_options]\n"
            'testpaths = ["tests"]\n'
            'asyncio_mode = "auto"\n',
            encoding="utf-8",
        )

    for mod in rewritten_modules:
        fp = mod.file_path
        _progress("test-gen", fp, "generating")

        test_code = _generate_test_for_module(
            client, fp, mod.code, old_root, target_stack,
        )
        if not test_code:
            continue

        pipeline.total_tokens += getattr(test_code, "_tokens", 0)

        # Write test file
        base = Path(fp).stem
        test_file = tests_dir / f"test_{base}.py"
        test_file.write_text(test_code, encoding="utf-8")

        test_count = test_code.count("def test_")
        pipeline.tests_generated += test_count

    # --- Phase 3: Run tests ---
    test_files = sorted(tests_dir.glob("test_*.py"))
    if not test_files:
        pipeline.total_time_ms = int((time.monotonic() - start_time) * 1000)
        return pipeline

    for round_num in range(1, max_fix_rounds + 1):
        _progress("test-run", "", f"round {round_num}")

        all_passed = True
        pipeline.test_results = []

        for test_file in test_files:
            _progress("test-run", str(test_file.name), "running")
            tr = _run_pytest(test_file, output_dir)
            pipeline.test_results.append(tr)

            if tr.passed:
                pipeline.tests_passed += tr.test_count
            else:
                all_passed = False
                pipeline.tests_failed += tr.failures

        if all_passed:
            _progress("test-run", "", "all passed")
            break

        # --- Phase 4: Fix failures ---
        if round_num < max_fix_rounds:
            _progress("fix", "", f"round {round_num}")
            failed_tests = [t for t in pipeline.test_results if not t.passed]

            for ft in failed_tests:
                _progress("fix", ft.module_file, "fixing")
                pipeline.fix_attempts += 1

                # Read current module code
                mod_path = output_dir / ft.module_file
                if not mod_path.exists():
                    continue
                current_code = mod_path.read_text(encoding="utf-8", errors="replace")

                # Read the test file
                test_path = Path(ft.test_file)
                if not test_path.exists():
                    continue
                test_code = test_path.read_text(encoding="utf-8", errors="replace")

                # Ask LLM to fix
                fixed = _fix_module_from_test_failures(
                    client, ft.module_file, current_code,
                    test_code, ft.output, target_stack,
                )
                if fixed:
                    pipeline.total_tokens += getattr(fixed, "_tokens", 0)
                    # Validate the fix before writing
                    old_source_path = old_root / ft.module_file
                    old_source = ""
                    if old_source_path.exists():
                        old_source = old_source_path.read_text(
                            encoding="utf-8", errors="replace"
                        )
                    # Minimal spec for validation
                    validation = validate_rewrite(
                        {"file_path": ft.module_file, "symbols": []},
                        fixed,
                        old_source=old_source,
                    )
                    if validation.valid or not validation.errors:
                        mod_path.write_text(fixed, encoding="utf-8")
                        pipeline.fix_successes += 1
                        _progress("fix", ft.module_file, "applied")
                    else:
                        _progress("fix", ft.module_file,
                                  f"rejected: {validation.errors[0]}")

            # Reset counts for next round
            pipeline.tests_passed = 0
            pipeline.tests_failed = 0

    pipeline.total_time_ms = int((time.monotonic() - start_time) * 1000)
    pipeline.total_tokens += rewrite_result.total_tokens
    return pipeline


def _generate_test_for_module(
    client: LLMClient,
    file_path: str,
    module_code: str,
    old_root: Path,
    target_stack: str,
) -> str:
    """Generate pytest tests for a rewritten module."""
    import ast as _ast

    # Parse to find testable symbols
    try:
        tree = _ast.parse(module_code)
    except SyntaxError:
        return ""

    symbols = []
    for node in _ast.iter_child_nodes(tree):
        if isinstance(node, _ast.ClassDef):
            methods = [
                n.name for n in node.body
                if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef))
                and not n.name.startswith("_")
            ]
            symbols.append(f"class {node.name} (methods: {', '.join(methods)})")
        elif isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
            if not node.name.startswith("_"):
                symbols.append(f"def {node.name}")

    if not symbols:
        return ""

    module_name = file_path.replace("/", ".").replace("\\", ".").replace(".py", "")

    system = (
        "You are an expert test engineer. Generate pytest tests for the module below.\n"
        "Output ONLY Python code — no markdown fences, no explanations.\n"
        "Include all necessary imports.\n"
        "Use descriptive test names: test_<function>_<scenario>.\n"
        "Each test should be independent and test one behavior.\n"
        "Mock external dependencies (databases, HTTP, file I/O) with unittest.mock."
    )

    prompt = (
        f"## Module to test: `{file_path}`\n\n"
        f"```python\n{module_code}\n```\n\n"
        f"## Testable symbols\n{chr(10).join('- ' + s for s in symbols)}\n\n"
        f"## Import as\n`from {module_name} import ...`\n\n"
        f"## Target stack: {target_stack or 'Python standard library'}\n\n"
        "## Requirements\n"
        "- Test each public function and class method\n"
        "- Test normal cases, edge cases, and error handling\n"
        "- Mock any database, file, or network I/O\n"
        "- Generate at least 3 tests per symbol\n"
        "- All tests must be runnable with `pytest`\n"
    )

    try:
        response = client.complete(system, prompt)
        code = _extract_code(response.content)
        # Tag with token count for tracking
        code = type(code)(code)
        object.__setattr__(code, "_tokens", response.tokens_used) if hasattr(code, "__dict__") else None
        return code
    except Exception:
        return ""


def _run_pytest(test_file: Path, project_dir: Path) -> ModuleTestResult:
    """Run a single test file and parse results."""
    test_file = test_file.resolve()
    project_dir = project_dir.resolve()

    module_file = test_file.stem.replace("test_", "", 1) + ".py"
    # Find actual module path
    for candidate in project_dir.rglob(module_file):
        if "tests" not in str(candidate):
            module_file = str(candidate.relative_to(project_dir))
            break

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", str(test_file), "-v", "--tb=short",
             "-p", "no:cacheprovider", f"--rootdir={project_dir}"],
            capture_output=True, text=True, timeout=120,
            cwd=str(project_dir),
            env={**os.environ, "PYTHONPATH": str(project_dir)},
        )
        output = result.stdout + result.stderr

        # Parse counts from pytest output
        test_count = 0
        failures = 0
        for line in output.splitlines():
            if " passed" in line or " failed" in line:
                import re as _re
                m = _re.search(r"(\d+) passed", line)
                if m:
                    test_count += int(m.group(1))
                m = _re.search(r"(\d+) failed", line)
                if m:
                    failures += int(m.group(1))
                    test_count += failures

        return ModuleTestResult(
            test_file=str(test_file),
            module_file=module_file,
            passed=result.returncode == 0,
            test_count=test_count,
            failures=failures,
            output=output[-3000:],  # Truncate to last 3000 chars
        )
    except subprocess.TimeoutExpired:
        return ModuleTestResult(
            test_file=str(test_file),
            module_file=module_file,
            passed=False,
            test_count=0,
            failures=1,
            output="Test execution timed out (120s)",
        )
    except Exception as e:
        return ModuleTestResult(
            test_file=str(test_file),
            module_file=module_file,
            passed=False,
            test_count=0,
            failures=1,
            output=f"Failed to run tests: {e}",
        )


def _target_file_path(original_path: str, code: str) -> str:
    """Determine the output file path based on the generated code's language.

    For cross-language rewrites (e.g., Java → Python), rename the extension
    to match the target language detected from the code content.
    Used for same-language rewrite mode (no explicit target_lang).
    """
    p = Path(original_path)
    ext = p.suffix.lower()

    # Already a Python file → no change
    if ext == ".py":
        return original_path

    # Detect if the generated code is Python
    is_python = (
        code.lstrip().startswith(("import ", "from ", "def ", "class ", "#!", '"""', "'''"))
        or "\ndef " in code
        or "\nclass " in code
    )

    if is_python and ext in (".java", ".ts", ".tsx", ".js", ".jsx", ".dart", ".rb", ".cs"):
        return str(p.with_suffix(".py"))

    return original_path


def _target_file_path_for_lang(original_path: str, target_lang: str) -> str:
    """Map source file path to target language extension.

    Used for cross-language translation mode (explicit target_lang).
    """
    ext = TARGET_EXTENSIONS.get(target_lang)
    if not ext:
        return original_path
    p = Path(original_path)
    return str(p.with_suffix(ext)).replace("\\", "/")


def _check_intra_package_imports(
    code: str,
    file_path: str,
    written_files: set[str],
    output_dir: Path,
) -> list[str]:
    """Check if a module imports other modules that don't exist."""
    import ast as _ast

    issues = []
    try:
        tree = _ast.parse(code)
    except SyntaxError:
        return issues

    # Determine the package this file belongs to
    parts = Path(file_path).parts
    if len(parts) < 2:
        return issues  # Top-level file, no package imports to check
    package = parts[0]  # e.g., "taskmanager"

    for node in _ast.walk(tree):
        if isinstance(node, _ast.ImportFrom) and node.level > 0:
            if node.level == 1 and node.module:
                # from .X import Y — check if X exists
                target = f"{package}/{node.module}.py"
                target_pkg = f"{package}/{node.module}/__init__.py"
                if (target not in written_files
                        and target_pkg not in written_files
                        and not (output_dir / target).exists()
                        and not (output_dir / target_pkg).exists()):
                    issues.append(
                        f"Relative import 'from .{node.module}' — "
                        f"module '{target}' does not exist"
                    )
            elif node.level == 1 and not node.module and node.names:
                # from . import name1, name2
                for alias in node.names:
                    target = f"{package}/{alias.name}.py"
                    target_pkg = f"{package}/{alias.name}/__init__.py"
                    if (target not in written_files
                            and target_pkg not in written_files
                            and not (output_dir / target).exists()
                            and not (output_dir / target_pkg).exists()):
                        issues.append(
                            f"Relative import 'from . import {alias.name}' — "
                            f"module '{target}' does not exist"
                        )
    return issues


def _fix_module_from_test_failures(
    client: LLMClient,
    file_path: str,
    module_code: str,
    test_code: str,
    test_output: str,
    target_stack: str,
) -> str:
    """Ask LLM to fix a module based on test failures."""
    system = (
        "You are an expert software engineer fixing code that fails tests.\n"
        "You receive: the module code, the test code, and the test output.\n"
        "Fix ONLY the module code — do NOT modify the tests.\n"
        "Output ONLY the corrected module code — no explanations, no markdown fences.\n"
        "Preserve all function signatures and class interfaces."
    )

    prompt = (
        f"## Module: `{file_path}` ({target_stack or 'Python'})\n\n"
        f"```python\n{module_code}\n```\n\n"
        f"## Test code\n```python\n{test_code}\n```\n\n"
        f"## Test output (FAILURES)\n```\n{test_output[-2000:]}\n```\n\n"
        "## Task\n"
        "Fix the module code so all tests pass.\n"
        "Do NOT change function signatures or remove any public API.\n"
        "Output ONLY the corrected Python code."
    )

    try:
        response = client.complete(system, prompt)
        code = _extract_code(response.content)
        code = type(code)(code)
        object.__setattr__(code, "_tokens", response.tokens_used) if hasattr(code, "__dict__") else None
        return code
    except Exception:
        return ""
