"""App modernization engine — index, learn, spec, rewrite, validate.

Generates comprehensive rewrite specifications from an indexed codebase.
Each spec contains everything an AI agent needs to rewrite a module:
contracts, dependencies, behavior, call chains, and test scenarios.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from pathlib import Path

from codebrain.analyzer import StructuralAnalyzer
from codebrain.comprehension import ComprehensionEngine
from codebrain.context import ContextGenerator
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.migration import (
    ContractExtractor,
    MigrationPlanGenerator,
    MigrationTracker,
    EquivalenceReporter,
)


def infer_module_role(file_path: str, symbols: list[dict]) -> str:
    """Infer the architectural role of a module from its path and symbols.

    Used by both SpecGenerator and ArchitectureDetector.
    """
    fp = file_path.lower()
    ext = Path(fp).suffix

    # Frontend-specific roles
    if ext == ".vue":
        return "component"
    components = [s for s in symbols if s["type"] == "component"]
    hooks = [s for s in symbols if s["type"] == "hook"]
    stores_sym = [s for s in symbols if s["type"] == "store"]
    routes_sym = [s for s in symbols if s["type"] == "route"]
    if components:
        if "page" in fp or "view" in fp:
            return "page"
        return "component"
    if routes_sym and not components:
        return "route_config"
    if stores_sym:
        return "state_store"
    if hooks:
        return "hook"

    # Extract filename (without extension) for matching
    fname = Path(fp).stem
    # Path segments for segment-level matching (avoid substring false positives)
    segments = set(Path(fp).parts)
    segments.add(fname)

    if "__init__" in fname:
        return "package_init"
    if "test" in fname or "test" in segments or "tests" in segments:
        return "test"
    if "config" in fname or "settings" in fname:
        return "configuration"

    # Java/general naming conventions (filename-based)
    if fname.endswith("controller") or fname.endswith("resource"):
        return "api_layer"
    if fname.endswith("repository") or fname.endswith("dao"):
        return "data_access"
    if fname.endswith("service") or fname.endswith("serviceimpl"):
        return "business_logic"
    if fname.endswith("entity") or fname.endswith("dto"):
        return "data_model"

    # Match against filename or directory segments
    # Use substring match on segments to handle plurals (models/ -> model)
    def _seg_match(*keywords: str) -> bool:
        for k in keywords:
            if k in fname:
                return True
            for seg in segments:
                if k in seg:
                    return True
        return False

    if _seg_match("model", "schema"):
        return "data_model"
    if _seg_match("api", "route", "view", "endpoint"):
        return "api_layer"
    if fname == "cli" or "command" in fname or "cli" in segments:
        return "cli"
    if _seg_match("util", "helper", "common"):
        return "utility"
    if _seg_match("service", "engine", "core"):
        return "business_logic"
    if _seg_match("store", "repo", "db", "dao"):
        return "data_access"
    if _seg_match("parser"):
        return "parser"
    if _seg_match("middleware"):
        return "middleware"

    classes = [s for s in symbols if s["type"] == "class"]
    functions = [s for s in symbols if s["type"] == "function"]
    if len(classes) > len(functions):
        return "class_module"
    return "module"


class SpecGenerator:
    """Generate per-module rewrite specifications from the knowledge graph.

    Produces actionable specs that an AI agent can follow to rewrite
    each module while preserving contracts, dependencies, and behavior.
    """

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.comp = ComprehensionEngine(store)
        self.analyzer = StructuralAnalyzer(store)
        self.engine = QueryEngine(store)
        self.ctx = ContextGenerator(store)
        self.contracts = ContractExtractor(store)
        self.planner = MigrationPlanGenerator(store)

    def generate_full_spec(
        self,
        *,
        project_name: str | None = None,
        target_stack: str = "",
        guidelines: str = "",
    ) -> dict:
        """Generate a complete modernization spec for the entire codebase.

        Args:
            project_name: Name for the project (auto-detected if None).
            target_stack: Description of the target tech stack.
            guidelines: Additional rewrite guidelines/constraints.

        Returns a structured dict with system-level context + per-module specs.
        """
        overview = self.comp.system_overview()
        health = self.comp.health_score()
        hotspots = self.comp.risk_hotspots(top_n=20)
        layers = self.analyzer.detect_layers()
        plan = self.planner.generate_plan()
        contracts = self.contracts.extract()
        coupling = self.analyzer.coupling_analysis()
        narrative = self.comp.system_narrative()

        # Auto-detect project name
        if not project_name:
            project_name = self._detect_project_name(overview)

        # Build per-module specs
        module_specs = {}
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        nodes_by_file = defaultdict(list)
        for n in all_nodes:
            nodes_by_file[n["file_path"]].append(n)

        node_by_id = {n["id"]: n for n in all_nodes}

        # Edge lookups
        edges_from = defaultdict(list)
        edges_to = defaultdict(list)
        for e in all_edges:
            edges_from[e["source"]].append(e)
            edges_to[e["target"]].append(e)

        # File dependency map
        file_deps = defaultdict(set)
        file_dependents = defaultdict(set)
        for e in all_edges:
            if e["type"] in ("IMPORTS", "CALLS"):
                src_file = e["file_path"]
                tgt = node_by_id.get(e["target"])
                if tgt and tgt["file_path"] != src_file:
                    file_deps[src_file].add(tgt["file_path"])
                    file_dependents[tgt["file_path"]].add(src_file)

        # Hotspot set
        hotspot_names = {h["name"] for h in hotspots[:10]}

        # Freeze defaultdicts once. Previously each iteration rebuilt four
        # N-entry dicts, which on Saleor-scale (4k files × 4 dicts × thousands
        # of entries) pushed this loop past 10 minutes.
        edges_from_frozen = dict(edges_from)
        edges_to_frozen = dict(edges_to)
        file_deps_frozen = dict(file_deps)
        file_dependents_frozen = dict(file_dependents)

        for fp, file_nodes in sorted(nodes_by_file.items()):
            spec = self._build_module_spec(
                fp, file_nodes, node_by_id, edges_from_frozen, edges_to_frozen,
                file_deps_frozen, file_dependents_frozen, hotspot_names,
                contracts.get("modules", {}).get(fp),
            )
            module_specs[fp] = spec

        # Phase ordering from migration plan
        phase_order = {}
        for phase in plan.get("phases", []):
            for mod in phase.get("modules", []):
                phase_order[mod["file_path"]] = {
                    "phase": phase["phase"],
                    "label": phase["label"],
                    "complexity": phase["complexity"],
                }

        # Tightly coupled pairs
        high_coupling = [
            p for p in coupling.get("pairs", [])
            if p.get("coupling_score", 0) >= 5
        ]

        return {
            "project_name": project_name,
            "generated_at": datetime.now().isoformat(),
            "target_stack": target_stack,
            "guidelines": guidelines,
            "system_context": {
                "summary": narrative.get("summary", ""),
                "architecture": narrative.get("architecture", ""),
                "health": {
                    "score": health.get("score", 0),
                    "grade": health.get("grade", "?"),
                    "dimensions": health.get("dimensions", {}),
                },
                "stats": overview.get("stats", {}),
                "packages": list(overview.get("packages", {}).keys()),
                "entry_points": [
                    ep.get("id", "") for ep in overview.get("entry_points", [])
                ],
                "recommendations": narrative.get("recommendations", []),
            },
            "rewrite_plan": {
                "total_phases": plan.get("total_phases", 0),
                "phase_order": phase_order,
                "risk_hotspots": [
                    {
                        "name": h["name"],
                        "file_path": h["file_path"],
                        "risk_score": h["risk_score"],
                        "dependents": h["direct_dependents"],
                    }
                    for h in hotspots[:10]
                ],
                "high_coupling_pairs": [
                    {
                        "file_a": p["file_a"],
                        "file_b": p["file_b"],
                        "score": p["coupling_score"],
                    }
                    for p in high_coupling[:10]
                ],
            },
            "module_specs": module_specs,
            "total_modules": len(module_specs),
        }

    def generate_module_spec(self, file_path: str) -> dict:
        """Generate a rewrite spec for a single module."""
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        nodes_by_file = defaultdict(list)
        for n in all_nodes:
            nodes_by_file[n["file_path"]].append(n)

        node_by_id = {n["id"]: n for n in all_nodes}

        edges_from = defaultdict(list)
        edges_to = defaultdict(list)
        for e in all_edges:
            edges_from[e["source"]].append(e)
            edges_to[e["target"]].append(e)

        file_deps = defaultdict(set)
        file_dependents = defaultdict(set)
        for e in all_edges:
            if e["type"] in ("IMPORTS", "CALLS"):
                src_file = e["file_path"]
                tgt = node_by_id.get(e["target"])
                if tgt and tgt["file_path"] != src_file:
                    file_deps[src_file].add(tgt["file_path"])
                    file_dependents[tgt["file_path"]].add(src_file)

        hotspots = self.comp.risk_hotspots(top_n=20)
        hotspot_names = {h["name"] for h in hotspots[:10]}

        contracts = self.contracts.extract(file_path=file_path)
        contract_data = contracts.get("modules", {}).get(file_path)

        file_nodes = nodes_by_file.get(file_path, [])
        if not file_nodes:
            return {"error": f"No indexed file: {file_path}"}

        return self._build_module_spec(
            file_path, file_nodes, node_by_id, dict(edges_from), dict(edges_to),
            dict(file_deps), dict(file_dependents), hotspot_names, contract_data,
        )

    def _build_module_spec(
        self,
        file_path: str,
        file_nodes: list[dict],
        node_by_id: dict[str, dict],
        edges_from: dict[str, list[dict]],
        edges_to: dict[str, list[dict]],
        file_deps: dict[str, set[str]],
        file_dependents: dict[str, set[str]],
        hotspot_names: set[str],
        contract_data: dict | None,
    ) -> dict:
        """Build a detailed rewrite spec for one module."""
        file_node = None
        symbols = []
        for n in file_nodes:
            if n["type"] == "file":
                file_node = n
            else:
                symbols.append(n)

        exported = [s for s in symbols if s.get("is_exported")]
        internal = [s for s in symbols if not s.get("is_exported")]

        # Build symbol details
        symbol_specs = []
        for s in symbols:
            # Calls made by this symbol
            calls_out = []
            for e in edges_from.get(s["id"], []):
                if e["type"] == "CALLS":
                    target = node_by_id.get(e["target"])
                    calls_out.append({
                        "target": e["target"],
                        "target_file": target["file_path"] if target else None,
                        "is_external": target["file_path"] != file_path if target else True,
                    })

            # Callers of this symbol
            callers = []
            for e in edges_to.get(s["id"], []):
                if e["type"] in ("CALLS", "IMPORTS"):
                    src = node_by_id.get(e["source"])
                    callers.append({
                        "source": e["source"],
                        "source_file": e["file_path"],
                        "is_external": e["file_path"] != file_path,
                    })
            # Also check by name and qualified_name
            for key in (s["name"], s["qualified_name"]):
                for e in edges_to.get(key, []):
                    if e["type"] in ("CALLS", "IMPORTS"):
                        callers.append({
                            "source": e["source"],
                            "source_file": e["file_path"],
                            "is_external": e["file_path"] != file_path,
                        })

            # Deduplicate callers
            seen = set()
            unique_callers = []
            for c in callers:
                key = (c["source"], c["source_file"])
                if key not in seen:
                    seen.add(key)
                    unique_callers.append(c)

            # Class-specific info
            methods = None
            bases = None
            if s["type"] == "class":
                methods = []
                for e in edges_from.get(s["id"], []):
                    if e["type"] == "CONTAINS":
                        child = node_by_id.get(e["target"])
                        if child and child["type"] == "method":
                            methods.append({
                                "name": child["name"],
                                "signature": child.get("signature", ""),
                                "is_exported": child.get("is_exported", False),
                                "docstring": child.get("docstring", ""),
                            })

                bases = []
                for e in edges_from.get(s["id"], []):
                    if e["type"] in ("EXTENDS", "IMPLEMENTS"):
                        bases.append({
                            "name": e["target"],
                            "relationship": e["type"],
                        })

            external_callers = [c for c in unique_callers if c["is_external"]]

            symbol_specs.append({
                "name": s["name"],
                "qualified_name": s["qualified_name"],
                "type": s["type"],
                "signature": s.get("signature", ""),
                "docstring": s.get("docstring", ""),
                "is_exported": bool(s.get("is_exported")),
                "is_hotspot": s["name"] in hotspot_names,
                "line_start": s["line_start"],
                "line_end": s["line_end"],
                "calls": calls_out[:30],
                "callers": unique_callers[:30],
                "external_caller_count": len(external_callers),
                "methods": methods,
                "bases": bases,
            })

        # Dependencies and dependents
        deps = sorted(file_deps.get(file_path, set()))
        dependents = sorted(file_dependents.get(file_path, set()))

        # Generate test scenarios from contracts
        test_scenarios = self._generate_test_scenarios(
            file_path, symbol_specs, contract_data
        )

        # Rewrite notes
        rewrite_notes = self._generate_rewrite_notes(
            file_path, symbol_specs, deps, dependents
        )

        role = self._infer_role(file_path, symbol_specs)
        result = {
            "file_path": file_path,
            "docstring": file_node["docstring"] if file_node else "",
            "line_count": file_node["line_end"] if file_node else 0,
            "role": role,
            "exported_count": len(exported),
            "internal_count": len(internal),
            "total_symbols": len(symbols),
            "dependencies": deps,
            "dependents": dependents,
            "dependency_count": len(deps),
            "dependent_count": len(dependents),
            "symbols": symbol_specs,
            "contracts": contract_data,
            "test_scenarios": test_scenarios,
            "rewrite_notes": rewrite_notes,
        }

        # Frontend component info
        if role in ("component", "page", "hook", "route_config", "state_store"):
            result["component_info"] = self._build_component_info(
                file_path, symbol_specs, edges_from, edges_to, node_by_id
            )

        return result

    def _infer_role(self, file_path: str, symbols: list[dict]) -> str:
        """Infer the role of a module from its contents."""
        return infer_module_role(file_path, symbols)

    def _build_component_info(
        self,
        file_path: str,
        symbols: list[dict],
        edges_from: dict[str, list[dict]],
        edges_to: dict[str, list[dict]],
        node_by_id: dict[str, dict],
    ) -> dict:
        """Build frontend component info for the module spec."""
        info: dict = {}
        for s in symbols:
            if s["type"] not in ("component", "hook", "store", "route"):
                continue
            comp_edges = edges_from.get(s.get("_id", "") or f"{file_path}::{s['qualified_name']}", [])
            # Use the symbol's edges from the spec
            renders = []
            props = []
            state_subs = []
            api_calls = []
            routes_served = []
            hooks_used = []

            for e in edges_from.get(f"{file_path}::{s['qualified_name']}", []):
                if e["type"] == "RENDERS":
                    target_name = e["target"].rsplit("::", 1)[-1].rsplit(".", 1)[-1]
                    if target_name not in renders:
                        renders.append(target_name)
                elif e["type"] == "PASSES_PROP":
                    target_name = e["target"].rsplit("::", 1)[-1].rsplit(".", 1)[-1]
                    if target_name not in props:
                        props.append(target_name)
                elif e["type"] == "SUBSCRIBES":
                    if e["target"] not in state_subs:
                        state_subs.append(e["target"])
                elif e["type"] == "DISPATCHES":
                    pass  # tracked separately
                elif e["type"] == "FETCHES":
                    if e["target"] not in api_calls:
                        api_calls.append(e["target"])
                elif e["type"] == "CALLS":
                    target_name = e["target"].rsplit("::", 1)[-1].rsplit(".", 1)[-1]
                    if target_name.startswith("use") and target_name[3:4].isupper():
                        hooks_used.append(target_name)

            # Routes served (from ROUTES_TO edges targeting this component)
            for key in (s["name"], s["qualified_name"], f"{file_path}::{s['qualified_name']}"):
                for e in edges_to.get(key, []):
                    if e["type"] == "ROUTES_TO":
                        route_node = node_by_id.get(e["source"])
                        if route_node:
                            routes_served.append(route_node["name"])

            info = {
                "name": s["name"],
                "type": s["type"],
                "props": s.get("signature", ""),
                "children_rendered": renders,
                "state_subscriptions": state_subs,
                "api_calls": api_calls,
                "routes_served": routes_served,
                "hooks_used": hooks_used,
            }
            break  # Use first component found

        return info

    def _generate_test_scenarios(
        self,
        file_path: str,
        symbols: list[dict],
        contract_data: dict | None,
    ) -> list[dict]:
        """Generate test scenarios to validate the rewrite."""
        scenarios = []

        for s in symbols:
            if not s["is_exported"]:
                continue

            if s["type"] in ("function", "method", "component", "hook"):
                # Basic contract test
                scenarios.append({
                    "name": f"test_{s['name']}_exists",
                    "description": f"Verify {s['name']} is exported with compatible signature",
                    "type": "contract",
                    "target": s["qualified_name"],
                    "checks": [
                        f"Function/method '{s['name']}' exists and is importable",
                        f"Signature is compatible: {s['signature']}" if s["signature"] else None,
                    ],
                })

                # Caller compatibility test
                if s["external_caller_count"] > 0:
                    scenarios.append({
                        "name": f"test_{s['name']}_caller_compatibility",
                        "description": f"{s['name']} has {s['external_caller_count']} external callers",
                        "type": "integration",
                        "target": s["qualified_name"],
                        "checks": [
                            f"All {s['external_caller_count']} external callers can still invoke this",
                            "Return type is compatible with existing consumers",
                        ],
                    })

            elif s["type"] == "class":
                # Class contract test
                checks = [f"Class '{s['name']}' exists and is importable"]
                if s["bases"]:
                    for b in s["bases"]:
                        checks.append(
                            f"Preserves {b['relationship'].lower()} relationship with {b['name']}"
                        )
                if s["methods"]:
                    public_methods = [m for m in s["methods"] if m["is_exported"]]
                    if public_methods:
                        checks.append(
                            f"Has public methods: {', '.join(m['name'] for m in public_methods)}"
                        )

                scenarios.append({
                    "name": f"test_{s['name']}_class_contract",
                    "description": f"Verify {s['name']} class contract is preserved",
                    "type": "contract",
                    "target": s["qualified_name"],
                    "checks": checks,
                })

        # Filter None checks
        for s in scenarios:
            s["checks"] = [c for c in s["checks"] if c]

        return scenarios

    def _generate_rewrite_notes(
        self,
        file_path: str,
        symbols: list[dict],
        deps: list[str],
        dependents: list[str],
    ) -> list[str]:
        """Generate actionable rewrite guidance."""
        notes = []

        hotspots = [s for s in symbols if s.get("is_hotspot")]
        if hotspots:
            names = ", ".join(s["name"] for s in hotspots)
            notes.append(
                f"CAUTION: {names} are risk hotspots with many dependents. "
                f"Preserve their exact signatures and return types."
            )

        high_caller = [s for s in symbols if s.get("external_caller_count", 0) > 3]
        if high_caller:
            names = ", ".join(s["name"] for s in high_caller)
            notes.append(
                f"High-dependency symbols: {names}. "
                f"These are heavily used — any signature change will cascade."
            )

        if len(dependents) > 5:
            notes.append(
                f"This module has {len(dependents)} dependents. "
                f"Rewrite it early and keep the API stable."
            )

        if not deps:
            notes.append(
                "Leaf module (no internal dependencies). Safe to rewrite first."
            )
        elif len(deps) > 5:
            notes.append(
                f"Complex dependency chain ({len(deps)} deps). "
                f"Ensure all dependencies are rewritten first."
            )

        exported = [s for s in symbols if s["is_exported"]]
        internal = [s for s in symbols if not s["is_exported"]]
        if internal and not exported:
            notes.append("All symbols are internal. Can be freely restructured.")
        elif exported:
            notes.append(
                f"Exports {len(exported)} public symbols. "
                f"Preserve all exported names and signatures for backwards compatibility."
            )

        # Frontend-specific notes
        components = [s for s in symbols if s["type"] == "component"]
        if components:
            for comp in components:
                comp_renders = [
                    e for e in
                    (comp.get("calls") or [])
                    if isinstance(e, dict)
                ]
                if comp.get("is_hotspot"):
                    notes.append(
                        f"Component '{comp['name']}' is a risk hotspot — "
                        f"preserve props interface and child component rendering."
                    )

        routes = [s for s in symbols if s["type"] == "route"]
        if routes:
            notes.append(
                f"This file defines {len(routes)} routes. "
                f"Preserve all route paths exactly in the rewritten version."
            )

        stores = [s for s in symbols if s["type"] == "store"]
        if stores:
            names = ", ".join(s["name"] for s in stores)
            notes.append(
                f"State stores: {names}. "
                f"Preserve store names and action/getter interfaces."
            )

        return notes

    def to_markdown(
        self,
        spec: dict | None = None,
        *,
        project_name: str | None = None,
        target_stack: str = "",
        guidelines: str = "",
        include_symbols: bool = True,
        max_modules: int = 50,
    ) -> str:
        """Render the full spec as a Markdown document."""
        if spec is None:
            spec = self.generate_full_spec(
                project_name=project_name,
                target_stack=target_stack,
                guidelines=guidelines,
            )

        lines = []
        pname = spec["project_name"]

        # Header
        lines.append(f"# Modernization Spec: {pname}\n")
        lines.append(
            f"*Generated by [CodeBrain](https://github.com/monk0062006/CodeBrain) "
            f"on {spec['generated_at'][:16]}*\n"
        )

        # Table of contents
        lines.append("## Table of Contents\n")
        lines.append("1. [Overview](#overview)")
        lines.append("2. [Target Stack](#target-stack)")
        lines.append("3. [Rewrite Plan](#rewrite-plan)")
        lines.append("4. [Risk Hotspots](#risk-hotspots)")
        lines.append("5. [Module Specs](#module-specs)")
        lines.append("6. [Test Strategy](#test-strategy)")
        lines.append("")

        # Overview
        ctx = spec["system_context"]
        lines.append("## Overview\n")
        if ctx.get("summary"):
            lines.append(f"{ctx['summary']}\n")
        if ctx.get("architecture"):
            lines.append(f"**Architecture:** {ctx['architecture']}\n")

        stats = ctx.get("stats", {})
        health = ctx.get("health", {})
        lines.append(f"| Metric | Value |")
        lines.append(f"|--------|-------|")
        lines.append(f"| Files | {stats.get('files', '?')} |")
        lines.append(f"| Symbols | {stats.get('nodes', '?')} |")
        lines.append(f"| Relationships | {stats.get('edges', '?')} |")
        lines.append(f"| Health Score | {health.get('score', '?')}/100 ({health.get('grade', '?')}) |")
        lines.append(f"| Packages | {len(ctx.get('packages', []))} |")
        lines.append("")

        # Target stack
        lines.append("## Target Stack\n")
        if spec.get("target_stack"):
            lines.append(f"{spec['target_stack']}\n")
        else:
            lines.append("*Not specified. Add `--target-stack` to provide target technology details.*\n")

        if spec.get("guidelines"):
            lines.append("### Guidelines\n")
            lines.append(f"{spec['guidelines']}\n")

        # Rewrite plan
        rp = spec["rewrite_plan"]
        lines.append("## Rewrite Plan\n")
        lines.append(f"**{rp['total_phases']} phases** — migrate leaf modules first, "
                      f"then work upward to orchestrators.\n")

        if rp["phase_order"]:
            # Group by phase
            phases = defaultdict(list)
            for fp, info in rp["phase_order"].items():
                phases[info["phase"]].append((fp, info))

            for phase_num in sorted(phases.keys()):
                items = phases[phase_num]
                label = items[0][1]["label"]
                complexity = items[0][1]["complexity"]
                lines.append(f"### Phase {phase_num}: {label} ({complexity})\n")
                for fp, _ in sorted(items):
                    lines.append(f"- `{fp}`")
                lines.append("")

        # Risk hotspots
        lines.append("## Risk Hotspots\n")
        lines.append("Rewrite these symbols with extreme care:\n")
        if rp.get("risk_hotspots"):
            lines.append("| Symbol | File | Risk | Dependents |")
            lines.append("|--------|------|------|-----------|")
            for h in rp["risk_hotspots"]:
                lines.append(
                    f"| `{h['name']}` | `{h['file_path']}` | "
                    f"{h['risk_score']:.0f} | {h['dependents']} |"
                )
            lines.append("")

        if rp.get("high_coupling_pairs"):
            lines.append("### Tightly Coupled File Pairs\n")
            lines.append("These files must be rewritten together:\n")
            for p in rp["high_coupling_pairs"]:
                lines.append(f"- `{p['file_a']}` ↔ `{p['file_b']}` (coupling: {p['score']})")
            lines.append("")

        # Module specs
        lines.append("## Module Specs\n")
        module_list = sorted(
            spec["module_specs"].items(),
            key=lambda x: rp["phase_order"].get(x[0], {}).get("phase", 999),
        )

        for i, (fp, mod) in enumerate(module_list[:max_modules]):
            phase_info = rp["phase_order"].get(fp, {})
            phase_tag = f" (Phase {phase_info['phase']})" if phase_info else ""

            lines.append(f"### `{fp}`{phase_tag}\n")

            if mod.get("docstring"):
                lines.append(f"*{mod['docstring']}*\n")

            lines.append(f"**Role:** {mod['role']} | "
                          f"**Symbols:** {mod['total_symbols']} "
                          f"({mod['exported_count']} exported) | "
                          f"**Lines:** {mod.get('line_count', '?')}")
            lines.append(f"**Deps:** {mod['dependency_count']} | "
                          f"**Dependents:** {mod['dependent_count']}\n")

            # Rewrite notes
            if mod.get("rewrite_notes"):
                lines.append("**Rewrite Notes:**\n")
                for note in mod["rewrite_notes"]:
                    lines.append(f"- {note}")
                lines.append("")

            # Dependencies
            if mod.get("dependencies"):
                lines.append(f"**Dependencies:** {', '.join(f'`{d}`' for d in mod['dependencies'][:10])}")
                if len(mod["dependencies"]) > 10:
                    lines.append(f"  ...and {len(mod['dependencies']) - 10} more")
                lines.append("")

            if mod.get("dependents"):
                lines.append(f"**Depended on by:** {', '.join(f'`{d}`' for d in mod['dependents'][:10])}")
                if len(mod["dependents"]) > 10:
                    lines.append(f"  ...and {len(mod['dependents']) - 10} more")
                lines.append("")

            # Symbol details
            if include_symbols and mod.get("symbols"):
                lines.append("**Symbols to Rewrite:**\n")
                for s in mod["symbols"]:
                    exported_tag = " [EXPORTED]" if s["is_exported"] else ""
                    hotspot_tag = " [HOTSPOT]" if s.get("is_hotspot") else ""
                    sig = f" `{s['signature']}`" if s.get("signature") else ""
                    doc = f" — {s['docstring']}" if s.get("docstring") else ""

                    lines.append(f"- **{s['name']}** ({s['type']}){exported_tag}{hotspot_tag}{sig}{doc}")

                    if s.get("bases"):
                        bases_str = ", ".join(
                            f"{b['name']} ({b['relationship']})" for b in s["bases"]
                        )
                        lines.append(f"  - Inherits: {bases_str}")

                    if s.get("methods"):
                        public = [m for m in s["methods"] if m["is_exported"]]
                        if public:
                            lines.append(f"  - Public methods: {', '.join(m['name'] for m in public)}")

                    if s.get("external_caller_count", 0) > 0:
                        lines.append(f"  - External callers: {s['external_caller_count']}")

                lines.append("")

            # Test scenarios
            if mod.get("test_scenarios"):
                lines.append("**Validation Tests:**\n")
                for t in mod["test_scenarios"][:10]:
                    lines.append(f"- `{t['name']}` [{t['type']}]: {t['description']}")
                    for check in t["checks"][:3]:
                        lines.append(f"  - {check}")
                lines.append("")

        if len(module_list) > max_modules:
            lines.append(f"\n*...and {len(module_list) - max_modules} more modules.*\n")

        # Test strategy
        lines.append("## Test Strategy\n")
        total_scenarios = sum(
            len(m.get("test_scenarios", []))
            for m in spec["module_specs"].values()
        )
        lines.append(f"**{total_scenarios} test scenarios** across "
                      f"{spec['total_modules']} modules.\n")
        lines.append("### Approach\n")
        lines.append("1. **Contract tests**: Verify all exported symbols exist with compatible signatures")
        lines.append("2. **Integration tests**: Verify cross-module call chains work")
        lines.append("3. **Equivalence tests**: Use `brain migrate-status` to track progress")
        lines.append("4. **Structural validation**: Use `brain migrate-report` for full comparison\n")

        # Recommendations
        if ctx.get("recommendations"):
            lines.append("## Recommendations\n")
            for r in ctx["recommendations"]:
                lines.append(f"- {r}")
            lines.append("")

        lines.append("---\n")
        lines.append("*Use `brain modernize-spec --module <path>` for a single module's spec.*\n")

        return "\n".join(lines)

    def _detect_project_name(self, overview: dict) -> str:
        """Auto-detect project name from packages."""
        packages = overview.get("packages", {})
        skip = {"tests", "test", "benchmarks", "docs", "examples", "scripts"}
        candidates = {
            name: info for name, info in packages.items()
            if name.lower() not in skip
        }
        if candidates:
            best = max(candidates.items(), key=lambda x: x[1].get("node_count", 0))
            return best[0]
        return "project"


class ModernizationWorkflow:
    """Orchestrate the full modernization workflow.

    Steps:
    1. Index the old codebase (already done via `brain init`)
    2. Generate modernization spec
    3. (AI agent rewrites code based on spec)
    4. Index the new codebase
    5. Track migration progress
    6. Generate equivalence report
    """

    def __init__(self, old_root: Path, old_store: GraphStore) -> None:
        self.old_root = old_root
        self.old_store = old_store
        self.spec_gen = SpecGenerator(old_store)

    def step1_generate_spec(
        self,
        *,
        target_stack: str = "",
        guidelines: str = "",
        output_format: str = "markdown",
    ) -> str | dict:
        """Step 1: Generate the modernization spec.

        This is what guides the rewrite. Pass it to an AI agent.
        """
        spec = self.spec_gen.generate_full_spec(
            target_stack=target_stack,
            guidelines=guidelines,
        )
        if output_format == "markdown":
            return self.spec_gen.to_markdown(spec)
        return spec

    def step2_track_progress(self, new_store: GraphStore) -> dict:
        """Step 2: Compare old and new codebases to track progress."""
        tracker = MigrationTracker()
        return tracker.compare(self.old_store, new_store)

    def step3_equivalence_report(
        self,
        new_store: GraphStore,
        output_format: str = "markdown",
    ) -> str | dict:
        """Step 3: Full structural equivalence report."""
        reporter = EquivalenceReporter()
        result = reporter.report(self.old_store, new_store)
        if output_format == "markdown":
            return reporter.to_markdown(result)
        return result
