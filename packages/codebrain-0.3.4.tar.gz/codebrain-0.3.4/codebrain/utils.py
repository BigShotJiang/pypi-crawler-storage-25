"""Hashing, path normalization, and timing helpers."""

from __future__ import annotations

import hashlib
import time
from contextlib import contextmanager
from pathlib import Path

from codebrain.logging import get_logger

_log = get_logger("utils")


def content_hash(data: bytes) -> str:
    """Return the SHA-256 hex digest of *data*."""
    return hashlib.sha256(data).hexdigest()


def file_hash(path: Path) -> str:
    """Return the SHA-256 hex digest of the file at *path*."""
    return content_hash(path.read_bytes())


def normalize_path(path: Path, repo_root: Path) -> str:
    """Return *path* relative to *repo_root* using forward slashes."""
    return path.relative_to(repo_root).as_posix()


def is_test_file(file_path: str) -> bool:
    """Return True if *file_path* looks like a test file.

    Detects test files across languages:
    - Python: test_*.py, *_test.py, conftest.py
    - Go: *_test.go
    - Java/Kotlin: *Test.java, *Tests.java, *Spec.kt
    - JS/TS: *.test.ts, *.spec.ts, *.test.js, *.spec.js
    - C#: *Tests.cs, *Test.cs
    - Directories: /tests/, /test/, /__tests__/, /spec/
    """
    # Normalize backslashes for consistent matching
    fp = file_path.replace("\\", "/")
    name = fp.rsplit("/", 1)[-1]
    stem = name.rsplit(".", 1)[0] if "." in name else name

    # Python
    if name.startswith("test_") or name.startswith("Test") or name == "conftest.py":
        return True
    # Go: *_test.go
    if name.endswith("_test.go"):
        return True
    # Python/Go/etc: *_test.py, *_test.ts, etc.
    if "_test." in name:
        return True
    # Java/Kotlin/C#: *Test.java, *Tests.java, *Spec.kt, *Tests.cs
    if stem.endswith(("Test", "Tests", "Spec", "Specs")):
        return True
    # JS/TS: *.test.ts, *.spec.ts, *.test.js, *.spec.js, *.test.tsx, *.spec.tsx
    if ".test." in name or ".spec." in name:
        return True
    # Directory patterns
    if ("/tests/" in fp or "/test/" in fp or "/__tests__/" in fp or "/spec/" in fp):
        return True
    if fp.startswith("tests/") or fp.startswith("test/"):
        return True
    return False


@contextmanager
def timed(label: str | None = None):
    """Context manager that yields a dict and fills in ``elapsed`` on exit."""
    result: dict = {}
    start = time.perf_counter()
    try:
        yield result
    finally:
        result["elapsed"] = time.perf_counter() - start
        if label:
            _log.debug("%s: %.3fs", label, result["elapsed"])
