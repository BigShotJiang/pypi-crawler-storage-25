"""GraphStore — CRUD interface over the SQLite knowledge graph."""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

from codebrain.graph.schema import migrate_db
from codebrain.logging import get_logger
from codebrain.parser.models import ParsedFile

_log = get_logger("store")


class GraphStore:
    """Persistent graph backed by a single SQLite database."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        _log.debug("Opening database %s", self.db_path)
        self.conn = sqlite3.connect(str(self.db_path), timeout=30, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA foreign_keys=OFF")
        migrate_db(self.conn)

    def close(self) -> None:
        _log.debug("Closing database %s", self.db_path)
        # Checkpoint WAL before closing so the -wal/-shm files are released.
        # Without this, Windows keeps the database locked after conn.close().
        try:
            self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass
        self.conn.close()

    def __enter__(self) -> "GraphStore":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # File-level operations
    # ------------------------------------------------------------------
    def upsert_file(self, pf: ParsedFile) -> None:
        """Replace all nodes/edges for a file in a single transaction."""
        with self.conn:
            self.conn.execute("DELETE FROM edges WHERE file_path = ?", (pf.path,))
            self.conn.execute("DELETE FROM nodes WHERE file_path = ?", (pf.path,))
            self.conn.execute("DELETE FROM files WHERE path = ?", (pf.path,))

            self.conn.execute(
                "INSERT INTO files (path, content_hash, last_indexed, line_count) VALUES (?, ?, ?, ?)",
                (pf.path, pf.content_hash, time.time(), pf.line_count),
            )

            if pf.nodes:
                self.conn.executemany(
                    """INSERT OR REPLACE INTO nodes
                       (id, name, qualified_name, type, file_path,
                        line_start, line_end, signature, decorators, docstring,
                        is_exported, summary)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    [
                        (
                            node.id, node.name, node.qualified_name, node.type,
                            node.file_path, node.line_start, node.line_end,
                            node.signature, json.dumps(node.decorators),
                            node.docstring, int(node.is_exported),
                            node.summary,
                        )
                        for node in pf.nodes
                    ],
                )

            if pf.edges:
                self.conn.executemany(
                    """INSERT OR IGNORE INTO edges (source, target, type, file_path, line)
                       VALUES (?, ?, ?, ?, ?)""",
                    [
                        (edge.source, edge.target, edge.type, edge.file_path, edge.line)
                        for edge in pf.edges
                    ],
                )

    def remove_file(self, path: str) -> None:
        """Delete a file and all its nodes/edges."""
        with self.conn:
            self.conn.execute("DELETE FROM edges WHERE file_path = ?", (path,))
            self.conn.execute("DELETE FROM nodes WHERE file_path = ?", (path,))
            self.conn.execute("DELETE FROM files WHERE path = ?", (path,))

    def clear_all(self) -> None:
        """Delete all data from the graph (files, nodes, edges).

        Unlike deleting and recreating the database file, this works
        even when other connections hold the file open (e.g., MCP server).
        """
        with self.conn:
            self.conn.execute("DELETE FROM edges")
            self.conn.execute("DELETE FROM nodes")
            self.conn.execute("DELETE FROM files")

    def get_file_hash(self, path: str) -> str | None:
        """Return the stored content hash for a file, or None."""
        row = self.conn.execute(
            "SELECT content_hash FROM files WHERE path = ?", (path,)
        ).fetchone()
        return row["content_hash"] if row else None

    # ------------------------------------------------------------------
    # Node operations
    # ------------------------------------------------------------------
    def get_node(self, node_id: str) -> dict | None:
        row = self.conn.execute("SELECT * FROM nodes WHERE id = ?", (node_id,)).fetchone()
        return dict(row) if row else None

    def get_nodes_by_file(self, path: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE file_path = ? ORDER BY line_start", (path,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_nodes_by_name(self, name: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE name = ?", (name,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_all_nodes(self, type_filter: str | None = None) -> list[dict]:
        if type_filter:
            rows = self.conn.execute(
                "SELECT * FROM nodes WHERE type = ? ORDER BY file_path, line_start",
                (type_filter,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM nodes ORDER BY file_path, line_start"
            ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Edge operations
    # ------------------------------------------------------------------
    def get_edges_from(self, node_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM edges WHERE source = ?", (node_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_edges_to(self, node_id: str) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM edges WHERE target = ?", (node_id,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_edges_to_symbol(self, node_id: str, name: str, qualified_name: str) -> list[dict]:
        """Find all edges targeting a node by ID, simple name, or qualified name.

        Edge targets are stored as unresolved names (e.g. "helper",
        "mypackage.utils.helper"), not node IDs. This method searches
        all possible forms.
        """
        # Build the set of possible target strings
        candidates = {node_id, name, qualified_name}
        # Also try dotted module.name forms
        if "::" in node_id:
            file_part, qname_part = node_id.split("::", 1)
            module = file_part.replace("/", ".").removesuffix(".py")
            if module.endswith(".__init__"):
                module = module.removesuffix(".__init__")
            candidates.add(f"{module}.{name}")
            candidates.add(f"{module}.{qname_part}")
            candidates.add(qname_part)
            # Handle dotted sub-parts
            parts = qname_part.split(".")
            if len(parts) > 1:
                candidates.add(parts[-1])  # bare method name

        # Also match attribute chain targets like "obj.method" or "self.attr.method"
        # by adding a LIKE clause for targets ending with ".name"
        suffix_patterns = set()
        if name and name not in ("__init__", "__str__", "__repr__", "__eq__",
                                  "__hash__", "__enter__", "__exit__", "__call__",
                                  "__len__", "__iter__", "__next__", "__contains__",
                                  "__getattr__", "__setattr__",
                                  "get", "set", "delete", "update", "create",
                                  "save", "load", "run", "read", "write",
                                  "send", "close", "open", "add", "remove",
                                  "pop", "push", "clear", "reset", "start", "stop",
                                  "equals", "hashCode", "toString", "compareTo",
                                  "clone", "iterator", "hasNext", "next", "size",
                                  "isEmpty", "contains", "main", "test",
                                  "Equals", "GetHashCode", "ToString", "Dispose"):
            suffix_patterns.add(f"%.{name}")

        placeholders = ",".join("?" for _ in candidates)
        like_clauses = " OR ".join(f"target LIKE ?" for _ in suffix_patterns)
        if like_clauses:
            sql = f"SELECT DISTINCT * FROM edges WHERE target IN ({placeholders}) OR ({like_clauses})"
            params = tuple(candidates) + tuple(suffix_patterns)
        else:
            sql = f"SELECT DISTINCT * FROM edges WHERE target IN ({placeholders})"
            params = tuple(candidates)
        rows = self.conn.execute(sql, params).fetchall()
        # Deduplicate by edge id (candidates can match the same edge row)
        seen: set[int] = set()
        result: list[dict] = []
        for r in rows:
            d = dict(r)
            eid = d["id"]
            if eid not in seen:
                seen.add(eid)
                result.append(d)
        return result

    # ------------------------------------------------------------------
    # Bulk edge operations
    # ------------------------------------------------------------------
    def get_all_edges(self, type_filter: str | None = None) -> list[dict]:
        """Return all edges, optionally filtered by type."""
        if type_filter:
            rows = self.conn.execute(
                "SELECT * FROM edges WHERE type = ?", (type_filter,)
            ).fetchall()
        else:
            rows = self.conn.execute("SELECT * FROM edges").fetchall()
        return [dict(r) for r in rows]

    def get_all_edges_from_nodes(self, node_ids: set[str]) -> list[dict]:
        """Return all outgoing edges from any of the given node IDs."""
        if not node_ids:
            return []
        placeholders = ",".join("?" for _ in node_ids)
        rows = self.conn.execute(
            f"SELECT * FROM edges WHERE source IN ({placeholders})",
            tuple(node_ids),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_nodes_by_ids(self, node_ids: set[str]) -> list[dict]:
        """Return nodes matching any of the given IDs."""
        if not node_ids:
            return []
        placeholders = ",".join("?" for _ in node_ids)
        rows = self.conn.execute(
            f"SELECT * FROM nodes WHERE id IN ({placeholders})",
            tuple(node_ids),
        ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Resilience
    # ------------------------------------------------------------------
    def check_integrity(self) -> bool:
        """Run PRAGMA integrity_check on the database."""
        try:
            result = self.conn.execute("PRAGMA integrity_check").fetchone()
            return result[0] == "ok"
        except sqlite3.DatabaseError:
            return False

    def _execute_with_retry(self, sql: str, params: tuple = (), max_retries: int = 3):
        """Execute SQL with retry on SQLITE_BUSY."""
        for attempt in range(max_retries):
            try:
                return self.conn.execute(sql, params)
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and attempt < max_retries - 1:
                    time.sleep(0.1 * (attempt + 1))
                else:
                    raise

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------
    def get_stats(self) -> dict:
        file_count = self.conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        node_count = self.conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
        edge_count = self.conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]

        node_types = {}
        for row in self.conn.execute("SELECT type, COUNT(*) as cnt FROM nodes GROUP BY type"):
            node_types[row["type"]] = row["cnt"]

        edge_types = {}
        for row in self.conn.execute("SELECT type, COUNT(*) as cnt FROM edges GROUP BY type"):
            edge_types[row["type"]] = row["cnt"]

        return {
            "files": file_count,
            "nodes": node_count,
            "edges": edge_count,
            "node_types": node_types,
            "edge_types": edge_types,
        }

    # ------------------------------------------------------------------
    # Test run persistence
    # ------------------------------------------------------------------
    def store_test_run(
        self,
        run_id: str,
        timestamp: float,
        commit_hash: str,
        total: int,
        passed: int,
        failed: int,
        skipped: int,
        errored: int,
        duration_ms: float,
        runner: str,
        command: str,
        scope: str,
        results: list[dict],
    ) -> None:
        """Persist a test run and its individual results."""
        import uuid
        with self.conn:
            self.conn.execute(
                """INSERT OR REPLACE INTO test_runs
                   (id, timestamp, commit_hash, total, passed, failed,
                    skipped, errored, duration_ms, runner, command, scope)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (run_id, timestamp, commit_hash, total, passed, failed,
                 skipped, errored, duration_ms, runner, command, scope),
            )
            self.conn.executemany(
                """INSERT OR REPLACE INTO test_results
                   (id, run_id, test_id, test_name, file_path, status,
                    duration_ms, error_message)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                [
                    (str(uuid.uuid4()), run_id, r["test_id"], r["test_name"],
                     r["file_path"], r["status"], r["duration_ms"],
                     r.get("error_message", ""))
                    for r in results
                ],
            )

    def get_last_test_run(self) -> dict | None:
        """Return the most recent test run with its results, or None."""
        row = self.conn.execute(
            "SELECT * FROM test_runs ORDER BY timestamp DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        run = dict(row)
        run["results"] = [
            dict(r) for r in self.conn.execute(
                "SELECT * FROM test_results WHERE run_id = ?", (run["id"],)
            ).fetchall()
        ]
        return run

    def get_test_history(self, limit: int = 10) -> list[dict]:
        """Return recent test runs (summary only, no individual results)."""
        rows = self.conn.execute(
            "SELECT * FROM test_runs ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_test_results_for_run(self, run_id: str) -> list[dict]:
        """Return individual test results for a specific run."""
        rows = self.conn.execute(
            "SELECT * FROM test_results WHERE run_id = ?", (run_id,)
        ).fetchall()
        return [dict(r) for r in rows]
