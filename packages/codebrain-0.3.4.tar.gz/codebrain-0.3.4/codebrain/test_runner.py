"""Test runner integration — execute tests, map results to the knowledge graph.

Runs the project's native test runner (pytest/jest/go test), parses results,
maps pass/fail back to production symbols via CALLS edges, and persists
everything for historical tracking.
"""

from __future__ import annotations

import json
import subprocess
import tempfile
import time
import uuid
import xml.etree.ElementTree as ET
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar

from codebrain.graph.store import GraphStore
from codebrain.utils import is_test_file


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class TestResult:
    __test__: ClassVar[bool] = False  # not a pytest test class
    test_id: str
    test_name: str
    file_path: str
    status: str  # "pass", "fail", "skip", "error"
    duration_ms: float = 0.0
    error_message: str = ""


@dataclass
class AtRiskSymbol:
    node_id: str
    name: str
    file_path: str
    line_start: int
    status: str  # "verified" or "at_risk"
    covering_tests: int
    failing_tests: int
    risk_score: float


@dataclass
class TestRunReport:
    __test__: ClassVar[bool] = False  # not a pytest test class
    run_id: str
    timestamp: float
    total: int
    passed: int
    failed: int
    skipped: int
    errored: int
    duration_ms: float
    runner: str
    scope: str
    command: str
    results: list[TestResult]
    at_risk_symbols: list[AtRiskSymbol]
    narrative: str


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

class TestRunner:
    """Execute tests and map results to the structural knowledge graph."""

    __test__ = False  # not a pytest test class

    def __init__(self, store: GraphStore, repo_root: Path) -> None:
        self.store = store
        self.repo_root = repo_root

    # ---- Runner detection ------------------------------------------------

    def detect_runner(self, override: str | None = None) -> tuple[str, list[str]]:
        """Detect the project's test framework.

        Returns (runner_name, base_command_parts).
        Raises RuntimeError if no runner found.
        """
        if override and override != "auto":
            return self._runner_command(override)

        root = self.repo_root

        # pytest detection
        if (root / "pytest.ini").exists() or (root / "conftest.py").exists():
            return self._runner_command("pytest")
        pyproject = root / "pyproject.toml"
        if pyproject.exists():
            try:
                text = pyproject.read_text(encoding="utf-8", errors="ignore")
                if "[tool.pytest" in text:
                    return self._runner_command("pytest")
            except OSError:
                pass
        # Fallback: any test_*.py files?
        for p in root.rglob("test_*.py"):
            if not any(skip in p.parts for skip in ("node_modules", ".venv", "venv", "__pycache__")):
                return self._runner_command("pytest")

        # jest detection
        pkg_json = root / "package.json"
        if pkg_json.exists():
            try:
                pkg = json.loads(pkg_json.read_text(encoding="utf-8"))
                deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
                if "jest" in deps:
                    return self._runner_command("jest")
            except (OSError, json.JSONDecodeError):
                pass
        if any((root / f"jest.config.{ext}").exists() for ext in ("js", "ts", "cjs", "mjs", "json")):
            return self._runner_command("jest")

        # go test detection
        if (root / "go.mod").exists():
            return self._runner_command("go")

        raise RuntimeError(
            "No test runner detected. Ensure pytest, jest, or go test is configured."
        )

    @staticmethod
    def _runner_command(runner: str) -> tuple[str, list[str]]:
        if runner == "pytest":
            return ("pytest", ["python", "-m", "pytest"])
        elif runner == "jest":
            return ("jest", ["npx", "jest", "--json"])
        elif runner == "go":
            return ("go", ["go", "test", "-json", "./..."])
        raise RuntimeError(f"Unknown runner: {runner}")

    # ---- Test execution --------------------------------------------------

    def run_tests(
        self,
        scope: str = "all",
        runner: str = "auto",
        timeout: int = 300,
        changed_files: list[str] | None = None,
    ) -> TestRunReport:
        """Run tests, parse results, map to graph, persist, return report."""
        start = time.time()
        runner_name, cmd = self.detect_runner(runner if runner != "auto" else None)

        # Determine scope / target files
        test_files: list[str] | None = None
        if scope == "affected":
            test_files = self.affected_tests(changed_files)
            if not test_files:
                return self._empty_report(runner_name, scope, "No affected tests found.")
        elif scope.startswith("file:"):
            target = scope[5:]
            test_files = self.affected_tests([target])
            if not test_files:
                return self._empty_report(runner_name, scope, f"No tests cover {target}.")

        # Build the actual command
        if runner_name == "pytest":
            results, full_cmd = self._run_pytest(cmd, test_files, timeout)
        elif runner_name == "jest":
            results, full_cmd = self._run_jest(cmd, test_files, timeout)
        elif runner_name == "go":
            results, full_cmd = self._run_go(cmd, timeout)
        else:
            raise RuntimeError(f"Unsupported runner: {runner_name}")

        elapsed = (time.time() - start) * 1000

        # Stats
        passed = sum(1 for r in results if r.status == "pass")
        failed = sum(1 for r in results if r.status == "fail")
        skipped = sum(1 for r in results if r.status == "skip")
        errored = sum(1 for r in results if r.status == "error")

        # Map to graph
        at_risk = self.map_to_graph(results)

        # Get commit hash
        commit = self._get_commit_hash()

        # Build report
        run_id = str(uuid.uuid4())
        report = TestRunReport(
            run_id=run_id,
            timestamp=time.time(),
            total=len(results),
            passed=passed,
            failed=failed,
            skipped=skipped,
            errored=errored,
            duration_ms=round(elapsed, 1),
            runner=runner_name,
            scope=scope,
            command=" ".join(full_cmd),
            results=results,
            at_risk_symbols=at_risk,
            narrative="",
        )
        report.narrative = self._build_narrative(report)

        # Persist
        self.store.store_test_run(
            run_id=run_id,
            timestamp=report.timestamp,
            commit_hash=commit,
            total=report.total,
            passed=passed,
            failed=failed,
            skipped=skipped,
            errored=errored,
            duration_ms=report.duration_ms,
            runner=runner_name,
            command=report.command,
            scope=scope,
            results=[
                {
                    "test_id": r.test_id,
                    "test_name": r.test_name,
                    "file_path": r.file_path,
                    "status": r.status,
                    "duration_ms": r.duration_ms,
                    "error_message": r.error_message,
                }
                for r in results
            ],
        )

        return report

    # ---- pytest ----------------------------------------------------------

    def _run_pytest(
        self, base_cmd: list[str], test_files: list[str] | None, timeout: int,
    ) -> tuple[list[TestResult], list[str]]:
        with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as tmp:
            xml_path = tmp.name

        cmd = base_cmd + [f"--junitxml={xml_path}", "-v", "--tb=short"]
        if test_files:
            cmd.extend(test_files)

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=timeout, cwd=str(self.repo_root),
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Test execution timed out after {timeout}s")

        # exit code 0 = all pass, 1 = some fail, >1 = runner error
        if proc.returncode > 1:
            # Check if XML was still written (partial results)
            try:
                results = self._parse_junit_xml(xml_path)
                if results:
                    return results, cmd
            except Exception:
                pass
            raise RuntimeError(
                f"pytest crashed (exit code {proc.returncode}):\n{proc.stderr[-1000:]}"
            )

        try:
            results = self._parse_junit_xml(xml_path)
        except Exception as exc:
            raise RuntimeError(f"Failed to parse JUnit XML: {exc}")
        finally:
            Path(xml_path).unlink(missing_ok=True)

        return results, cmd

    def _parse_junit_xml(self, xml_path: str) -> list[TestResult]:
        """Parse JUnit XML into TestResult objects."""
        tree = ET.parse(xml_path)
        root = tree.getroot()
        results: list[TestResult] = []

        # Handle both <testsuites><testsuite>... and <testsuite>... formats
        testcases = root.iter("testcase")
        for tc in testcases:
            classname = tc.get("classname", "")
            name = tc.get("name", "")
            time_s = float(tc.get("time", "0"))

            # Derive file path from classname
            file_path = classname.replace(".", "/") + ".py" if classname else ""
            # pytest classname format: "tests.test_foo" or "tests.test_foo.TestClass"
            # Try to find actual file
            if file_path and not Path(self.repo_root / file_path).exists():
                # Strip trailing class name
                parts = classname.rsplit(".", 1)
                if len(parts) == 2:
                    alt = parts[0].replace(".", "/") + ".py"
                    if Path(self.repo_root / alt).exists():
                        file_path = alt

            test_id = f"{file_path}::{name}" if file_path else name

            # Determine status from child elements
            failure = tc.find("failure")
            error = tc.find("error")
            skip = tc.find("skipped")

            if failure is not None:
                status = "fail"
                msg = failure.get("message", "")
            elif error is not None:
                status = "error"
                msg = error.get("message", "")
            elif skip is not None:
                status = "skip"
                msg = skip.get("message", "")
            else:
                status = "pass"
                msg = ""

            results.append(TestResult(
                test_id=test_id,
                test_name=name,
                file_path=file_path,
                status=status,
                duration_ms=round(time_s * 1000, 1),
                error_message=msg,
            ))

        return results

    # ---- jest ------------------------------------------------------------

    def _run_jest(
        self, base_cmd: list[str], test_files: list[str] | None, timeout: int,
    ) -> tuple[list[TestResult], list[str]]:
        cmd = list(base_cmd)
        if test_files:
            cmd.extend(test_files)

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=timeout, cwd=str(self.repo_root),
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Jest timed out after {timeout}s")

        # Jest outputs JSON to stdout even on failure (exit 1)
        try:
            results = self._parse_jest_json(proc.stdout)
        except Exception as exc:
            if proc.returncode > 1:
                raise RuntimeError(f"Jest crashed (exit {proc.returncode}):\n{proc.stderr[-1000:]}")
            raise RuntimeError(f"Failed to parse Jest output: {exc}")

        return results, cmd

    def _parse_jest_json(self, stdout: str) -> list[TestResult]:
        """Parse jest --json output."""
        data = json.loads(stdout)
        results: list[TestResult] = []

        for suite in data.get("testResults", []):
            file_path = suite.get("testFilePath", "")
            # Make relative to repo root
            try:
                file_path = str(Path(file_path).relative_to(self.repo_root))
            except ValueError:
                pass

            for tr in suite.get("testResults", []):
                name = tr.get("fullName", tr.get("title", ""))
                jest_status = tr.get("status", "")
                status_map = {"passed": "pass", "failed": "fail", "pending": "skip"}
                status = status_map.get(jest_status, "error")

                msg = ""
                if tr.get("failureMessages"):
                    msg = "\n".join(tr["failureMessages"])[:1000]

                results.append(TestResult(
                    test_id=f"{file_path}::{name}",
                    test_name=name,
                    file_path=file_path,
                    status=status,
                    duration_ms=float(tr.get("duration", 0)),
                    error_message=msg,
                ))

        return results

    # ---- go test ---------------------------------------------------------

    def _run_go(
        self, base_cmd: list[str], timeout: int,
    ) -> tuple[list[TestResult], list[str]]:
        cmd = list(base_cmd)

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=timeout, cwd=str(self.repo_root),
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"go test timed out after {timeout}s")

        try:
            results = self._parse_go_json(proc.stdout)
        except Exception as exc:
            if proc.returncode > 2:
                raise RuntimeError(f"go test crashed:\n{proc.stderr[-1000:]}")
            raise RuntimeError(f"Failed to parse go test output: {exc}")

        return results, cmd

    def _parse_go_json(self, stdout: str) -> list[TestResult]:
        """Parse go test -json NDJSON output."""
        results: list[TestResult] = []
        seen: set[str] = set()

        for line in stdout.strip().splitlines():
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue

            action = obj.get("Action", "")
            test_name = obj.get("Test", "")
            pkg = obj.get("Package", "")

            if not test_name or action not in ("pass", "fail", "skip"):
                continue

            key = f"{pkg}::{test_name}"
            if key in seen:
                continue
            seen.add(key)

            results.append(TestResult(
                test_id=key,
                test_name=test_name,
                file_path=pkg,
                status=action,
                duration_ms=round(float(obj.get("Elapsed", 0)) * 1000, 1),
                error_message=obj.get("Output", "")[:1000] if action == "fail" else "",
            ))

        return results

    # ---- Graph mapping ---------------------------------------------------

    def map_to_graph(self, results: list[TestResult]) -> list[AtRiskSymbol]:
        """Map test results to production symbols via CALLS edge traversal."""
        if not results:
            return []

        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        node_by_id: dict[str, dict] = {n["id"]: n for n in all_nodes}
        id_set = set(node_by_id.keys())

        # Name indexes for resolving targets
        name_to_ids: dict[str, list[str]] = {}
        qname_to_ids: dict[str, list[str]] = {}
        for node in all_nodes:
            name_to_ids.setdefault(node["name"], []).append(node["id"])
            qname_to_ids.setdefault(node["qualified_name"], []).append(node["id"])

        # Partition nodes
        test_node_ids: set[str] = set()
        prod_node_ids: set[str] = set()
        for node in all_nodes:
            if node["type"] in ("file", "variable"):
                continue
            name = node["name"]
            if name.startswith("__") and name.endswith("__"):
                continue
            fp = node["file_path"]
            if is_test_file(fp) or name.startswith("test_") or name.startswith("Test"):
                test_node_ids.add(node["id"])
            else:
                prod_node_ids.add(node["id"])

        # Build forward adjacency (CALLS)
        adj: dict[str, set[str]] = {}
        for edge in all_edges:
            if edge["type"] != "CALLS":
                continue
            source = edge["source"]
            target_raw = edge["target"]

            resolved: list[str] = []
            if target_raw in id_set:
                resolved.append(target_raw)
            elif target_raw in qname_to_ids:
                resolved.extend(qname_to_ids[target_raw])
            elif target_raw in name_to_ids:
                resolved.extend(name_to_ids[target_raw])
            elif target_raw.startswith("self."):
                method_name = target_raw[5:]
                if method_name in name_to_ids:
                    resolved.extend(name_to_ids[method_name])

            for tid in resolved:
                adj.setdefault(source, set()).add(tid)

        # Match test results to graph node IDs
        result_by_test_id: dict[str, TestResult] = {}
        for r in results:
            # Try exact match
            if r.test_id in id_set:
                result_by_test_id[r.test_id] = r
                continue
            # Try file_path::test_name
            candidate = f"{r.file_path}::{r.test_name}"
            if candidate in id_set:
                result_by_test_id[candidate] = r
                continue
            # Try bare name lookup
            if r.test_name in name_to_ids:
                for nid in name_to_ids[r.test_name]:
                    if nid in test_node_ids:
                        result_by_test_id[nid] = r
                        break

        # BFS from each matched test node
        # Track: prod_symbol -> {covering_tests, failing_tests}
        symbol_coverage: dict[str, dict] = {}  # node_id -> {total, failing}

        for test_nid, result in result_by_test_id.items():
            queue: deque[tuple[str, int]] = deque([(test_nid, 0)])
            visited: set[str] = {test_nid}
            while queue:
                current, depth = queue.popleft()
                if current in prod_node_ids:
                    if current not in symbol_coverage:
                        symbol_coverage[current] = {"total": 0, "failing": 0}
                    symbol_coverage[current]["total"] += 1
                    if result.status in ("fail", "error"):
                        symbol_coverage[current]["failing"] += 1
                if depth >= 3:
                    continue
                for neighbor in adj.get(current, ()):
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append((neighbor, depth + 1))

        # Build AtRiskSymbol list
        at_risk: list[AtRiskSymbol] = []
        for nid, cov in symbol_coverage.items():
            node = node_by_id.get(nid)
            if not node:
                continue

            failing_ratio = cov["failing"] / max(cov["total"], 1)
            # Base risk from M23 factors
            is_exp = bool(node["is_exported"])
            base_risk = 0.3 if is_exp else 0.0

            status = "at_risk" if cov["failing"] > 0 else "verified"
            risk = base_risk * (1.0 + 0.5 * failing_ratio) if status == "at_risk" else 0.0

            if status == "at_risk":
                at_risk.append(AtRiskSymbol(
                    node_id=nid,
                    name=node["name"],
                    file_path=node["file_path"],
                    line_start=node["line_start"],
                    status=status,
                    covering_tests=cov["total"],
                    failing_tests=cov["failing"],
                    risk_score=round(risk, 2),
                ))

        at_risk.sort(key=lambda s: s.risk_score, reverse=True)
        return at_risk

    # ---- Smart test selection --------------------------------------------

    def affected_tests(self, changed_files: list[str] | None = None) -> list[str]:
        """Return test file paths that cover symbols in changed_files."""
        if not changed_files:
            changed_files = self._get_changed_files()
        if not changed_files:
            return []

        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()
        node_by_id = {n["id"]: n for n in all_nodes}
        id_set = set(node_by_id.keys())

        # Name indexes
        name_to_ids: dict[str, list[str]] = {}
        qname_to_ids: dict[str, list[str]] = {}
        for node in all_nodes:
            name_to_ids.setdefault(node["name"], []).append(node["id"])
            qname_to_ids.setdefault(node["qualified_name"], []).append(node["id"])

        # Build REVERSE adjacency: target → set[source]
        rev_adj: dict[str, set[str]] = {}
        for edge in all_edges:
            if edge["type"] != "CALLS":
                continue
            source = edge["source"]
            target_raw = edge["target"]

            resolved: list[str] = []
            if target_raw in id_set:
                resolved.append(target_raw)
            elif target_raw in qname_to_ids:
                resolved.extend(qname_to_ids[target_raw])
            elif target_raw in name_to_ids:
                resolved.extend(name_to_ids[target_raw])
            elif target_raw.startswith("self."):
                method_name = target_raw[5:]
                if method_name in name_to_ids:
                    resolved.extend(name_to_ids[method_name])

            for tid in resolved:
                rev_adj.setdefault(tid, set()).add(source)

        # Find changed symbol IDs
        changed_ids: set[str] = set()
        for fp in changed_files:
            nodes = self.store.get_nodes_by_file(fp)
            for n in nodes:
                if n["type"] != "file":
                    changed_ids.add(n["id"])

        # Reverse BFS (no depth limit) to find test nodes
        test_files: set[str] = set()
        visited: set[str] = set()
        queue: deque[str] = deque(changed_ids)
        visited.update(changed_ids)

        while queue:
            current = queue.popleft()
            node = node_by_id.get(current)
            if node and (is_test_file(node["file_path"])
                         or node["name"].startswith("test_")
                         or node["name"].startswith("Test")):
                test_files.add(node["file_path"])
                continue  # Don't traverse further from test nodes
            for source in rev_adj.get(current, ()):
                if source not in visited:
                    visited.add(source)
                    queue.append(source)

        return sorted(test_files)

    # ---- Status / history ------------------------------------------------

    def test_status(self) -> dict | None:
        """Return the last test run with current at-risk symbols."""
        run = self.store.get_last_test_run()
        if not run:
            return None

        # Re-map results to get current at-risk symbols
        results = [
            TestResult(
                test_id=r["test_id"],
                test_name=r["test_name"],
                file_path=r["file_path"],
                status=r["status"],
                duration_ms=r["duration_ms"],
                error_message=r.get("error_message", ""),
            )
            for r in run.get("results", [])
        ]
        at_risk = self.map_to_graph(results)

        return {
            "run_id": run["id"],
            "timestamp": run["timestamp"],
            "total": run["total"],
            "passed": run["passed"],
            "failed": run["failed"],
            "skipped": run["skipped"],
            "errored": run["errored"],
            "duration_ms": run["duration_ms"],
            "runner": run["runner"],
            "scope": run["scope"],
            "commit_hash": run["commit_hash"],
            "at_risk_symbols": [
                {
                    "name": s.name,
                    "file_path": s.file_path,
                    "line_start": s.line_start,
                    "covering_tests": s.covering_tests,
                    "failing_tests": s.failing_tests,
                    "risk_score": s.risk_score,
                }
                for s in at_risk
            ],
        }

    def test_for_symbol(self, name: str) -> dict:
        """Find which tests cover a symbol and their last pass/fail status."""
        from codebrain.graph.query import QueryEngine
        engine = QueryEngine(self.store)
        nodes = engine.resolve_node(name)
        if not nodes:
            return {"error": f"Symbol not found: {name}", "tests": []}

        node = nodes[0]
        node_id = node["id"]

        # Find test nodes that reach this symbol via reverse BFS
        test_files = self.affected_tests_for_symbol(node_id)

        # Cross-reference with last test run
        last_run = self.store.get_last_test_run()
        result_map: dict[str, str] = {}
        if last_run:
            for r in last_run.get("results", []):
                result_map[r["file_path"]] = r["status"]

        tests = []
        for tf in test_files:
            last_status = result_map.get(tf, "unknown")
            tests.append({"file_path": tf, "last_status": last_status})

        return {
            "symbol": name,
            "node_id": node_id,
            "file_path": node["file_path"],
            "covering_tests": len(tests),
            "tests": tests,
        }

    def affected_tests_for_symbol(self, node_id: str) -> list[str]:
        """Return test file paths that reach a specific node via reverse BFS."""
        return self.affected_tests_for_ids({node_id})

    def affected_tests_for_ids(self, target_ids: set[str]) -> list[str]:
        """Return test file paths that reach any of the given node IDs."""
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()
        node_by_id = {n["id"]: n for n in all_nodes}
        id_set = set(node_by_id.keys())

        name_to_ids: dict[str, list[str]] = {}
        qname_to_ids: dict[str, list[str]] = {}
        for node in all_nodes:
            name_to_ids.setdefault(node["name"], []).append(node["id"])
            qname_to_ids.setdefault(node["qualified_name"], []).append(node["id"])

        rev_adj: dict[str, set[str]] = {}
        for edge in all_edges:
            if edge["type"] != "CALLS":
                continue
            source = edge["source"]
            target_raw = edge["target"]
            resolved: list[str] = []
            if target_raw in id_set:
                resolved.append(target_raw)
            elif target_raw in qname_to_ids:
                resolved.extend(qname_to_ids[target_raw])
            elif target_raw in name_to_ids:
                resolved.extend(name_to_ids[target_raw])
            for tid in resolved:
                rev_adj.setdefault(tid, set()).add(source)

        test_files: set[str] = set()
        visited: set[str] = set()
        queue: deque[str] = deque(target_ids)
        visited.update(target_ids)

        while queue:
            current = queue.popleft()
            node = node_by_id.get(current)
            if node and (is_test_file(node["file_path"])
                         or node["name"].startswith("test_")
                         or node["name"].startswith("Test")):
                test_files.add(node["file_path"])
                continue
            for source in rev_adj.get(current, ()):
                if source not in visited:
                    visited.add(source)
                    queue.append(source)

        return sorted(test_files)

    # ---- Helpers ---------------------------------------------------------

    def _get_changed_files(self) -> list[str]:
        """Get changed files from git diff HEAD + untracked."""
        files: list[str] = []
        try:
            r = subprocess.run(
                ["git", "diff", "--name-only", "HEAD"],
                capture_output=True, text=True, cwd=str(self.repo_root),
            )
            if r.returncode == 0:
                files.extend(r.stdout.strip().splitlines())
            r2 = subprocess.run(
                ["git", "ls-files", "--others", "--exclude-standard"],
                capture_output=True, text=True, cwd=str(self.repo_root),
            )
            if r2.returncode == 0:
                files.extend(r2.stdout.strip().splitlines())
        except FileNotFoundError:
            pass  # git not available
        return [f for f in files if f]

    def _get_commit_hash(self) -> str:
        try:
            r = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                capture_output=True, text=True, cwd=str(self.repo_root),
            )
            return r.stdout.strip() if r.returncode == 0 else ""
        except FileNotFoundError:
            return ""

    def _empty_report(self, runner: str, scope: str, msg: str) -> TestRunReport:
        return TestRunReport(
            run_id=str(uuid.uuid4()),
            timestamp=time.time(),
            total=0, passed=0, failed=0, skipped=0, errored=0,
            duration_ms=0, runner=runner, scope=scope, command="",
            results=[], at_risk_symbols=[], narrative=msg,
        )

    @staticmethod
    def _build_narrative(report: TestRunReport) -> str:
        lines: list[str] = []
        lines.append("Test Run Summary")
        lines.append("=" * 16)

        if report.total == 0:
            lines.append("No tests were executed.")
            return "\n".join(lines)

        dur = f"{report.duration_ms / 1000:.1f}s"
        lines.append(
            f"Ran {report.total} tests in {dur}: "
            f"{report.passed} passed, {report.failed} failed, "
            f"{report.skipped} skipped."
        )

        if report.failed > 0:
            lines.append("")
            lines.append("Failed:")
            for r in report.results:
                if r.status in ("fail", "error"):
                    msg = f" — {r.error_message[:100]}" if r.error_message else ""
                    lines.append(f"  {r.test_id}{msg}")

        if report.at_risk_symbols:
            lines.append("")
            lines.append(f"At-risk production symbols ({len(report.at_risk_symbols)}):")
            for s in report.at_risk_symbols[:10]:
                lines.append(
                    f"  {s.risk_score:.2f}  {s.name:30s} {s.file_path}:{s.line_start}"
                    f"  ({s.failing_tests} failing test{'s' if s.failing_tests != 1 else ''})"
                )
            if len(report.at_risk_symbols) > 10:
                lines.append(f"  ... and {len(report.at_risk_symbols) - 10} more")

        if report.failed == 0 and report.total > 0:
            lines.append("")
            lines.append("All tests passed.")

        return "\n".join(lines)
