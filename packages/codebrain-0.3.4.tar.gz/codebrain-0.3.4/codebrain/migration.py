"""Migration tools — plan, contracts, tracking, equivalence.

Helps rewrite applications by analyzing the old codebase structure
and comparing it with the new implementation.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime

from codebrain.analyzer import StructuralAnalyzer
from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore


class MigrationPlanGenerator:
    """Generate a dependency-ordered migration plan."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.comp = ComprehensionEngine(store)
        self.analyzer = StructuralAnalyzer(store)
        self.engine = QueryEngine(store)

    def generate_plan(self) -> dict:
        """Analyze the codebase and produce a phased migration plan.

        Returns a structured dict with phases ordered by dependency
        (leaves first, roots last).
        """
        layers = self.analyzer.detect_layers()
        overview = self.comp.system_overview()
        hotspots = self.comp.risk_hotspots(top_n=20)

        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Build lookups
        nodes_by_file = defaultdict(list)
        for n in all_nodes:
            nodes_by_file[n["file_path"]].append(n)

        # Coupling scores per file
        edges_by_file = defaultdict(int)
        for e in all_edges:
            if e["type"] in ("CALLS", "IMPORTS"):
                edges_by_file[e["file_path"]] += 1

        # Hotspot files for risk flagging
        hotspot_files = {h["file_path"] for h in hotspots[:10]}

        # File dependencies
        file_deps = defaultdict(set)
        node_by_id = {n["id"]: n for n in all_nodes}
        for e in all_edges:
            if e["type"] in ("IMPORTS", "CALLS"):
                src_file = e["file_path"]
                target_node = node_by_id.get(e["target"])
                if target_node and target_node["file_path"] != src_file:
                    file_deps[src_file].add(target_node["file_path"])

        # Build phases from layers
        phases = []
        layer_list = layers.get("layers", [])

        for i, layer in enumerate(layer_list):
            files = layer.get("files", [])
            if not files:
                continue

            modules = []
            total_symbols = 0
            total_coupling = 0

            for fp in files:
                file_nodes = nodes_by_file.get(fp, [])
                symbols = [n for n in file_nodes if n["type"] != "file"]
                exported = [n for n in symbols if n.get("is_exported")]
                symbol_count = len(symbols)
                total_symbols += symbol_count

                coupling = edges_by_file.get(fp, 0)
                total_coupling += coupling

                # Dependent count
                dependent_count = len([
                    f for f, deps in file_deps.items()
                    if fp in deps and f != fp
                ])

                # Public API
                public_api = []
                for n in exported:
                    public_api.append({
                        "name": n["name"],
                        "type": n["type"],
                        "signature": n.get("signature", ""),
                        "docstring": n.get("docstring", ""),
                    })

                # Dependencies (internal only)
                deps = sorted(file_deps.get(fp, set()))

                modules.append({
                    "file_path": fp,
                    "symbol_count": symbol_count,
                    "exported_count": len(exported),
                    "coupling_score": coupling,
                    "dependent_count": dependent_count,
                    "is_hotspot": fp in hotspot_files,
                    "public_api": public_api,
                    "dependencies": deps,
                })

            # Sort modules within phase: simplest first
            modules.sort(key=lambda m: m["coupling_score"] + m["dependent_count"])

            # Complexity estimate
            avg_coupling = total_coupling / max(len(files), 1)
            if avg_coupling < 5 and total_symbols < 30:
                complexity = "low"
            elif avg_coupling < 20 or total_symbols < 100:
                complexity = "medium"
            else:
                complexity = "high"

            label = layer.get("label", f"Phase {i + 1}")
            description = layer.get("description", "")

            phases.append({
                "phase": i + 1,
                "label": label,
                "description": description,
                "module_count": len(modules),
                "total_symbols": total_symbols,
                "complexity": complexity,
                "modules": modules,
            })

        stats = overview["stats"]
        return {
            "total_files": stats.get("files", 0),
            "total_symbols": stats.get("nodes", 0),
            "total_phases": len(phases),
            "phases": phases,
            "risk_hotspots": [
                {
                    "name": h["name"],
                    "file_path": h["file_path"],
                    "risk_score": h["risk_score"],
                    "dependents": h["direct_dependents"],
                }
                for h in hotspots[:10]
            ],
        }

    def to_markdown(self, plan: dict | None = None) -> str:
        """Render the migration plan as a Markdown document."""
        if plan is None:
            plan = self.generate_plan()

        lines = []
        lines.append("# Migration Plan\n")
        lines.append(
            f"*Generated by [CodeBrain](https://github.com/monk0062006/CodeBrain) "
            f"on {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n"
        )

        lines.append("## Summary\n")
        lines.append(f"- **Files:** {plan['total_files']}")
        lines.append(f"- **Symbols:** {plan['total_symbols']}")
        lines.append(f"- **Migration phases:** {plan['total_phases']}")
        lines.append(f"- **Strategy:** Migrate leaf modules first (no dependents), "
                      f"then work upward to orchestrators\n")

        # Phase overview
        lines.append("## Phase Overview\n")
        lines.append("| Phase | Label | Modules | Symbols | Complexity |")
        lines.append("|-------|-------|---------|---------|------------|")
        for phase in plan["phases"]:
            lines.append(
                f"| {phase['phase']} | {phase['label']} | "
                f"{phase['module_count']} | {phase['total_symbols']} | "
                f"{phase['complexity']} |"
            )
        lines.append("")

        # Detailed phases
        for phase in plan["phases"]:
            lines.append(f"## Phase {phase['phase']}: {phase['label']}\n")
            if phase["description"]:
                lines.append(f"*{phase['description']}*\n")
            lines.append(f"**Complexity:** {phase['complexity']} | "
                          f"**Modules:** {phase['module_count']} | "
                          f"**Symbols:** {phase['total_symbols']}\n")

            for mod in phase["modules"]:
                hotspot_tag = " **[HOTSPOT]**" if mod["is_hotspot"] else ""
                lines.append(f"### `{mod['file_path']}`{hotspot_tag}\n")
                lines.append(
                    f"- Symbols: {mod['symbol_count']} "
                    f"({mod['exported_count']} exported)"
                )
                lines.append(f"- Coupling: {mod['coupling_score']}")
                lines.append(f"- Dependents: {mod['dependent_count']} files depend on this")

                if mod["dependencies"]:
                    lines.append(f"- Dependencies: {', '.join(f'`{d}`' for d in mod['dependencies'][:8])}")
                    if len(mod["dependencies"]) > 8:
                        lines.append(f"  ...and {len(mod['dependencies']) - 8} more")

                if mod["public_api"]:
                    lines.append("\n**Public API (must be preserved in new code):**\n")
                    for api in mod["public_api"][:20]:
                        sig = f" `{api['signature']}`" if api["signature"] else ""
                        doc = f" — {api['docstring']}" if api["docstring"] else ""
                        lines.append(f"- `{api['name']}` ({api['type']}){sig}{doc}")
                    if len(mod["public_api"]) > 20:
                        lines.append(f"- ...and {len(mod['public_api']) - 20} more")
                lines.append("")

        # Risk hotspots
        if plan.get("risk_hotspots"):
            lines.append("## Risk Hotspots\n")
            lines.append("These symbols have the most dependents. Migrate carefully:\n")
            lines.append("| Name | File | Risk Score | Dependents |")
            lines.append("|------|------|-----------|-----------|")
            for h in plan["risk_hotspots"]:
                lines.append(
                    f"| `{h['name']}` | `{h['file_path']}` | "
                    f"{h['risk_score']:.0f} | {h['dependents']} |"
                )
            lines.append("")

        lines.append("---\n")
        lines.append("*Migrate phases in order. Each phase depends only on "
                      "phases before it.*\n")

        return "\n".join(lines)


class ContractExtractor:
    """Extract public API contracts from the codebase."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.engine = QueryEngine(store)

    def extract(self, file_path: str | None = None) -> dict:
        """Extract API contracts for all modules or a specific file.

        Returns a dict mapping file paths to their public API surface.
        """
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Build edge lookups
        edges_from = defaultdict(list)
        edges_to = defaultdict(list)
        for e in all_edges:
            edges_from[e["source"]].append(e)
            edges_to[e["target"]].append(e)

        # Group nodes by file
        nodes_by_file = defaultdict(list)
        for n in all_nodes:
            nodes_by_file[n["file_path"]].append(n)

        node_by_id = {n["id"]: n for n in all_nodes}

        # Filter to specific file or all files
        if file_path:
            target_files = [file_path] if file_path in nodes_by_file else []
        else:
            target_files = sorted(nodes_by_file.keys())

        modules = {}
        for fp in target_files:
            file_nodes = nodes_by_file[fp]
            exported = [n for n in file_nodes if n.get("is_exported") and n["type"] != "file"]

            if not exported:
                continue

            functions = []
            classes = []

            for n in exported:
                if n["type"] in ("function", "method"):
                    # Find callers
                    callers = []
                    for e in edges_to.get(n["id"], []):
                        if e["type"] == "CALLS" and e["file_path"] != fp:
                            src = node_by_id.get(e["source"])
                            callers.append(src["qualified_name"] if src else e["source"])
                    # Also check by name
                    for e in edges_to.get(n["name"], []):
                        if e["type"] == "CALLS" and e["file_path"] != fp:
                            src = node_by_id.get(e["source"])
                            name = src["qualified_name"] if src else e["source"]
                            if name not in callers:
                                callers.append(name)

                    # Find callees
                    callees = []
                    for e in edges_from.get(n["id"], []):
                        if e["type"] == "CALLS":
                            callees.append(e["target"])

                    functions.append({
                        "name": n["name"],
                        "qualified_name": n["qualified_name"],
                        "signature": n.get("signature", ""),
                        "docstring": n.get("docstring", ""),
                        "decorators": n.get("decorators", []),
                        "callers": callers[:20],
                        "callees": callees[:20],
                        "line": n["line_start"],
                    })

                elif n["type"] == "class":
                    # Find methods
                    methods = []
                    for e in edges_from.get(n["id"], []):
                        if e["type"] == "CONTAINS":
                            child = node_by_id.get(e["target"])
                            if child and child["type"] == "method":
                                methods.append({
                                    "name": child["name"],
                                    "signature": child.get("signature", ""),
                                    "is_public": child.get("is_exported", False),
                                    "docstring": child.get("docstring", ""),
                                })

                    # Find base classes
                    bases = []
                    for e in edges_from.get(n["id"], []):
                        if e["type"] in ("EXTENDS", "IMPLEMENTS"):
                            bases.append({
                                "name": e["target"],
                                "relationship": e["type"],
                            })

                    classes.append({
                        "name": n["name"],
                        "qualified_name": n["qualified_name"],
                        "docstring": n.get("docstring", ""),
                        "decorators": n.get("decorators", []),
                        "bases": bases,
                        "methods": methods,
                        "line": n["line_start"],
                    })

            # Data flows
            data_flows = []
            for n in file_nodes:
                for e in edges_from.get(n["id"], []):
                    if e["type"] == "DATAFLOW":
                        producer = node_by_id.get(e["target"])
                        data_flows.append({
                            "consumer": n["qualified_name"],
                            "producer": producer["qualified_name"] if producer else e["target"],
                        })

            modules[fp] = {
                "functions": functions,
                "classes": classes,
                "data_flows": data_flows[:30],
                "total_exported": len(exported),
            }

        return {
            "modules": modules,
            "total_modules": len(modules),
            "total_contracts": sum(
                len(m["functions"]) + len(m["classes"]) for m in modules.values()
            ),
        }

    def to_markdown(self, contracts: dict | None = None) -> str:
        """Render contracts as Markdown."""
        if contracts is None:
            contracts = self.extract()

        lines = []
        lines.append("# API Contracts\n")
        lines.append(
            f"*Generated by CodeBrain on {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n"
        )
        lines.append(f"**{contracts['total_modules']} modules** with "
                      f"**{contracts['total_contracts']} contracts**\n")

        for fp, mod in contracts["modules"].items():
            lines.append(f"## `{fp}`\n")

            if mod["classes"]:
                lines.append("### Classes\n")
                for cls in mod["classes"]:
                    bases_str = ""
                    if cls["bases"]:
                        bases_str = " extends " + ", ".join(
                            f"`{b['name']}`" for b in cls["bases"]
                        )
                    doc = f" — {cls['docstring']}" if cls["docstring"] else ""
                    lines.append(f"**`{cls['name']}`**{bases_str}{doc}\n")

                    if cls["methods"]:
                        for m in cls["methods"]:
                            vis = "public" if m["is_public"] else "private"
                            sig = f" `{m['signature']}`" if m["signature"] else ""
                            lines.append(f"- [{vis}] `{m['name']}`{sig}")
                    lines.append("")

            if mod["functions"]:
                lines.append("### Functions\n")
                for fn in mod["functions"]:
                    sig = f"`{fn['signature']}`" if fn["signature"] else ""
                    doc = f" — {fn['docstring']}" if fn["docstring"] else ""
                    lines.append(f"**`{fn['name']}`** {sig}{doc}\n")
                    if fn["callers"]:
                        lines.append(f"  Called by: {', '.join(f'`{c}`' for c in fn['callers'][:5])}")
                    if fn["callees"]:
                        lines.append(f"  Calls: {', '.join(f'`{c}`' for c in fn['callees'][:5])}")
                    lines.append("")

        return "\n".join(lines)


class MigrationTracker:
    """Compare old and new codebases to track migration progress."""

    def compare(self, old_store: GraphStore, new_store: GraphStore) -> dict:
        """Compare two indexed codebases and classify symbols.

        Matches symbols by name and qualified_name across codebases.
        """
        old_nodes = old_store.get_all_nodes()
        new_nodes = new_store.get_all_nodes()

        # Get exported symbols (skip file nodes and test files)
        old_symbols = self._get_exported_symbols(old_nodes)
        new_symbols = self._get_exported_symbols(new_nodes)

        # Build lookup by name and qualified_name for new symbols
        new_by_name = defaultdict(list)
        new_by_qname: dict[str, dict] = {}
        for s in new_symbols:
            new_by_name[s["name"]].append(s)
            new_by_qname[s["qualified_name"]] = s

        # Track old symbol names that matched
        matched_new_names: set[str] = set()

        # Classify each old symbol
        migrated = []
        partial = []
        pending = []

        by_module = defaultdict(lambda: {"symbols": [], "status": "pending"})

        for sym in old_symbols:
            # Try qualified name match first, then bare name
            match = new_by_qname.get(sym["qualified_name"])
            if not match:
                candidates = new_by_name.get(sym["name"], [])
                # Prefer same type
                typed = [c for c in candidates if c["type"] == sym["type"]]
                match = typed[0] if typed else (candidates[0] if candidates else None)

            if match:
                matched_new_names.add(match["name"])
                if sym["signature"] == match["signature"]:
                    status = "migrated"
                    migrated.append(sym["name"])
                else:
                    status = "partial"
                    partial.append(sym["name"])

                by_module[sym["file_path"]]["symbols"].append({
                    "name": sym["name"],
                    "type": sym["type"],
                    "status": status,
                    "old_signature": sym["signature"],
                    "new_signature": match["signature"],
                    "new_file": match["file_path"],
                })
            else:
                status = "pending"
                pending.append(sym["name"])
                by_module[sym["file_path"]]["symbols"].append({
                    "name": sym["name"],
                    "type": sym["type"],
                    "status": "pending",
                    "old_signature": sym["signature"],
                })

        # Determine per-module status
        for fp, mod in by_module.items():
            statuses = {s["status"] for s in mod["symbols"]}
            if statuses == {"migrated"}:
                mod["status"] = "migrated"
            elif "pending" not in statuses and "partial" in statuses:
                mod["status"] = "partial"
            elif "migrated" in statuses or "partial" in statuses:
                mod["status"] = "partial"
            else:
                mod["status"] = "pending"

        # Find new symbols not in old
        unmapped_new = [
            {
                "name": s["name"],
                "type": s["type"],
                "file_path": s["file_path"],
                "signature": s["signature"],
            }
            for s in new_symbols
            if s["name"] not in matched_new_names
            and s["name"] not in {o["name"] for o in old_symbols}
        ]

        total = len(old_symbols)
        return {
            "summary": {
                "total_symbols": total,
                "migrated": len(migrated),
                "partial": len(partial),
                "pending": len(pending),
                "coverage_pct": round(
                    (len(migrated) + len(partial) * 0.5) / max(total, 1) * 100, 1
                ),
            },
            "by_module": dict(by_module),
            "unmapped_new_symbols": unmapped_new,
        }

    def _get_exported_symbols(self, nodes: list[dict]) -> list[dict]:
        """Filter to exported, non-test, non-file symbols."""
        from codebrain.utils import is_test_file

        return [
            n for n in nodes
            if n.get("is_exported")
            and n["type"] != "file"
            and not is_test_file(n["file_path"])
        ]


class EquivalenceReporter:
    """Compare old and new codebases for structural equivalence."""

    def __init__(self):
        self.tracker = MigrationTracker()

    def report(self, old_store: GraphStore, new_store: GraphStore) -> dict:
        """Generate a full equivalence report between old and new codebases."""
        # Base migration status
        migration = self.tracker.compare(old_store, new_store)

        # Structural comparison
        old_nodes = old_store.get_all_nodes()
        new_nodes = new_store.get_all_nodes()
        old_edges = old_store.get_all_edges()
        new_edges = new_store.get_all_edges()

        # Compare class hierarchies
        old_extends = {
            (e["source"].split("::")[-1], e["target"])
            for e in old_edges if e["type"] == "EXTENDS"
        }
        new_extends = {
            (e["source"].split("::")[-1], e["target"])
            for e in new_edges if e["type"] == "EXTENDS"
        }

        missing_hierarchies = []
        for cls_name, base in old_extends:
            if (cls_name, base) not in new_extends:
                # Check if the class exists at all
                new_classes = {n["name"] for n in new_nodes if n["type"] == "class"}
                if cls_name in new_classes:
                    missing_hierarchies.append({
                        "class": cls_name,
                        "missing_base": base,
                        "status": "base_removed",
                    })
                else:
                    missing_hierarchies.append({
                        "class": cls_name,
                        "missing_base": base,
                        "status": "class_not_migrated",
                    })

        # Compare file-level dependencies
        old_files = {n["file_path"] for n in old_nodes if n["type"] == "file"}
        new_files = {n["file_path"] for n in new_nodes if n["type"] == "file"}

        # Compare implements
        old_implements = {
            (e["source"].split("::")[-1], e["target"])
            for e in old_edges if e["type"] == "IMPLEMENTS"
        }
        new_implements = {
            (e["source"].split("::")[-1], e["target"])
            for e in new_edges if e["type"] == "IMPLEMENTS"
        }
        missing_implementations = [
            {"class": cls, "interface": iface}
            for cls, iface in old_implements
            if (cls, iface) not in new_implements
        ]

        # Find broken call chains: exported symbols in old that are called
        # but missing in new
        old_exported = {
            n["name"] for n in old_nodes
            if n.get("is_exported") and n["type"] != "file"
        }
        new_exported = {
            n["name"] for n in new_nodes
            if n.get("is_exported") and n["type"] != "file"
        }

        # Symbols that existed and were called, but are missing in new
        old_call_targets = {
            e["target"].split(".")[-1] if "." in e["target"] else e["target"]
            for e in old_edges if e["type"] == "CALLS"
        }
        broken_calls = [
            name for name in (old_exported & old_call_targets) - new_exported
        ]

        return {
            "migration_status": migration,
            "structural_diff": {
                "missing_class_hierarchies": missing_hierarchies,
                "missing_implementations": missing_implementations,
                "broken_call_targets": sorted(broken_calls),
                "file_diff": {
                    "old_only": sorted(old_files - new_files),
                    "new_only": sorted(new_files - old_files),
                    "common": sorted(old_files & new_files),
                },
            },
            "stats": {
                "old_files": len(old_files),
                "new_files": len(new_files),
                "old_symbols": len([n for n in old_nodes if n["type"] != "file"]),
                "new_symbols": len([n for n in new_nodes if n["type"] != "file"]),
                "old_edges": len(old_edges),
                "new_edges": len(new_edges),
            },
        }

    def to_markdown(self, result: dict | None = None,
                    old_store: GraphStore | None = None,
                    new_store: GraphStore | None = None) -> str:
        """Render the equivalence report as Markdown."""
        if result is None:
            result = self.report(old_store, new_store)

        lines = []
        lines.append("# Migration Equivalence Report\n")
        lines.append(
            f"*Generated by CodeBrain on {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n"
        )

        # Summary
        ms = result["migration_status"]["summary"]
        lines.append("## Migration Coverage\n")
        lines.append(f"**Coverage: {ms['coverage_pct']}%**\n")
        lines.append(f"| Status | Count |")
        lines.append(f"|--------|-------|")
        lines.append(f"| Migrated | {ms['migrated']} |")
        lines.append(f"| Partial | {ms['partial']} |")
        lines.append(f"| Pending | {ms['pending']} |")
        lines.append(f"| **Total** | **{ms['total_symbols']}** |")
        lines.append("")

        # Stats comparison
        stats = result["stats"]
        lines.append("## Codebase Comparison\n")
        lines.append("| Metric | Old | New |")
        lines.append("|--------|-----|-----|")
        lines.append(f"| Files | {stats['old_files']} | {stats['new_files']} |")
        lines.append(f"| Symbols | {stats['old_symbols']} | {stats['new_symbols']} |")
        lines.append(f"| Relationships | {stats['old_edges']} | {stats['new_edges']} |")
        lines.append("")

        # Structural diff
        sd = result["structural_diff"]

        if sd["broken_call_targets"]:
            lines.append("## Broken Call Targets\n")
            lines.append("These exported symbols existed in the old codebase and were "
                          "called by other code, but are missing in the new codebase:\n")
            for name in sd["broken_call_targets"]:
                lines.append(f"- `{name}`")
            lines.append("")

        if sd["missing_class_hierarchies"]:
            lines.append("## Missing Class Hierarchies\n")
            for h in sd["missing_class_hierarchies"]:
                lines.append(f"- `{h['class']}` extends `{h['missing_base']}` — {h['status']}")
            lines.append("")

        if sd["missing_implementations"]:
            lines.append("## Missing Interface Implementations\n")
            for impl in sd["missing_implementations"]:
                lines.append(f"- `{impl['class']}` implements `{impl['interface']}`")
            lines.append("")

        # Pending modules
        by_module = result["migration_status"]["by_module"]
        pending_mods = {
            fp: mod for fp, mod in by_module.items()
            if mod["status"] == "pending"
        }
        if pending_mods:
            lines.append("## Pending Modules\n")
            for fp, mod in sorted(pending_mods.items()):
                symbols = ", ".join(f"`{s['name']}`" for s in mod["symbols"][:10])
                lines.append(f"- `{fp}`: {symbols}")
            lines.append("")

        lines.append("---\n")
        return "\n".join(lines)
