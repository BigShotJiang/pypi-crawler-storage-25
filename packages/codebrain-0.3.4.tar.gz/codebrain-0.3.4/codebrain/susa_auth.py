"""SUSA Authentication for CodeBrain CLI.

Authenticates CodeBrain users via SUSA API key.
Validates plan and features on startup.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

import httpx

logger = logging.getLogger(__name__)

CONFIG_DIR = Path.home() / ".codebrain"
CONFIG_FILE = CONFIG_DIR / "config.json"
SUSA_API_BASE = os.getenv("SUSA_API_BASE", "https://susatest.com")


def get_stored_key() -> str:
    """Get stored SUSA API key from config."""
    if CONFIG_FILE.exists():
        try:
            config = json.loads(CONFIG_FILE.read_text())
            return config.get("susa_api_key", "")
        except Exception:
            pass
    # Check environment variable
    return os.getenv("SUSA_API_KEY", "")


def store_key(api_key: str) -> None:
    """Store SUSA API key in config."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config = {}
    if CONFIG_FILE.exists():
        try:
            config = json.loads(CONFIG_FILE.read_text())
        except Exception:
            pass
    config["susa_api_key"] = api_key
    CONFIG_FILE.write_text(json.dumps(config, indent=2))
    logger.info("API key stored in %s", CONFIG_FILE)


def validate_key(api_key: str = "") -> dict | None:
    """Validate API key against SUSA server.

    Returns plan info dict or None if invalid.
    """
    key = api_key or get_stored_key()
    if not key:
        return None

    try:
        resp = httpx.get(
            f"{SUSA_API_BASE}/api/auth/validate-key",
            params={"key": key},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
        else:
            logger.warning("API key validation failed: %s", resp.status_code)
            return None
    except Exception as e:
        logger.debug("Cannot reach SUSA server: %s (offline mode OK)", e)
        # Offline mode — allow basic functionality
        return {"valid": True, "plan": "offline", "features": {}}


def login_interactive() -> bool:
    """Interactive login flow — opens browser for SUSA OAuth.

    Returns True if login succeeded.
    """
    import webbrowser
    import http.server
    import threading
    import urllib.parse

    received_key = {"key": ""}

    class CallbackHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            if "token" in params:
                received_key["key"] = params["token"][0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"""
                <html><body style="font-family:sans-serif;text-align:center;padding:50px;">
                <h1>Login Successful!</h1>
                <p>You can close this tab and return to the terminal.</p>
                </body></html>
                """)
            else:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Missing token")

        def log_message(self, format, *args):
            pass  # Suppress HTTP logs

    # Start local callback server
    server = http.server.HTTPServer(("localhost", 9876), CallbackHandler)
    thread = threading.Thread(target=server.handle_request, daemon=True)
    thread.start()

    # Open browser
    login_url = f"{SUSA_API_BASE}/login?callback=http://localhost:9876&cli=true"
    print(f"\nOpening browser for login...")
    print(f"If browser doesn't open, visit: {login_url}\n")
    webbrowser.open(login_url)

    # Wait for callback (30s timeout)
    thread.join(timeout=30)
    server.server_close()

    if received_key["key"]:
        store_key(received_key["key"])
        print("Login successful! API key stored.")
        return True
    else:
        print("Login timed out. Try again or set SUSA_API_KEY environment variable.")
        return False


def require_auth(feature: str = "") -> dict:
    """Require authentication. Exit if not authenticated.

    Args:
        feature: Optional feature name to check access for.

    Returns plan info dict.
    """
    key = get_stored_key()
    if not key:
        print("Not authenticated. Run: codebrain auth login")
        print("Or set SUSA_API_KEY environment variable.")
        raise SystemExit(1)

    info = validate_key(key)
    if not info:
        print("Invalid API key. Run: codebrain auth login")
        raise SystemExit(1)

    if feature and info.get("features"):
        if not info["features"].get(feature, True):
            print(f"Feature '{feature}' requires a Pro plan. Upgrade at susatest.com/pricing")
            raise SystemExit(1)

    return info
