"""MCP server lifecycle management — watchdogs and PID-file self-heal.

Stdio MCP servers leak on Windows when the parent (e.g. Claude Code) dies
ungracefully. The 25s tool-deadline only fires during a request, so abandoned
idle servers sit forever holding the SQLite DB. This module adds three
watchdogs that run as daemon threads inside the MCP process; any one of them
tripping calls os._exit(0):

  1. Parent-PID watchdog  — exits when the parent process is gone or the PID
                            has been reused (create_time drift).
  2. Idle watchdog        — exits after CODEBRAIN_MCP_IDLE_TIMEOUT seconds
                            with no tool activity (default 1800s = 30 min).
  3. Lifetime watchdog    — optional hard cap via CODEBRAIN_MCP_MAX_LIFETIME.

Plus a PID file at <repo>/.codebrain/mcp.pid that lets `brain reindex` and
`brain doctor` find — and offer to clean — stale MCP servers without the user
needing to read process tables.
"""
from __future__ import annotations

import atexit
import os
import sys
import threading
import time
from pathlib import Path

from codebrain.logging import get_logger

_log = get_logger("mcp_lifecycle")

PID_FILE_NAME = "mcp.pid"
PARENT_POLL_SECONDS = 5
IDLE_TIMEOUT_SECONDS = int(os.environ.get("CODEBRAIN_MCP_IDLE_TIMEOUT", "1800"))
MAX_LIFETIME_SECONDS = int(os.environ.get("CODEBRAIN_MCP_MAX_LIFETIME", "0"))
STALE_AGE_SECONDS = 3600  # 1h with no parent-death signal still counts as stale
ANCESTOR_WALK_DEPTH = 6
# Names of host processes that own the MCP lifecycle. If any of these is found
# while walking up the ancestor chain, we watch *it* rather than the immediate
# parent — survives transient launchers (cmd.exe, Electron worker shells) that
# Claude Code uses on Windows. Match is case-insensitive substring.
HOST_PROCESS_NAME_HINTS = ("claude", "cursor", "vscode", "code")

_last_activity_lock = threading.Lock()
_last_activity: float = time.time()
_installed = False


def mark_activity() -> None:
    """Reset the idle-timeout clock. Called from the MCP tool wrapper."""
    global _last_activity
    with _last_activity_lock:
        _last_activity = time.time()


def _exit(reason: str) -> None:
    _log.warning("MCP server self-terminating: %s", reason)
    try:
        sys.stderr.flush()
    except Exception:
        pass
    os._exit(0)


def _is_codebrain_mcp(pid: int) -> bool:
    try:
        import psutil
        cmdline = " ".join(psutil.Process(pid).cmdline())
    except Exception:
        return False
    return "codebrain.mcp_server" in cmdline


def _read_pid_file(pid_file: Path) -> int | None:
    try:
        first_line = pid_file.read_text(encoding="utf-8").strip().split("\n", 1)[0]
        return int(first_line)
    except (OSError, ValueError):
        return None


def _predecessor_has_live_host(pid: int) -> bool:
    """True if ``pid``'s ancestor chain contains a live host (claude/cursor/...).

    Such a predecessor belongs to a *concurrent* sibling Claude session and
    must not be terminated — its disappearance would silently break that
    session's MCP. Without psutil we cannot tell, so be safe and assume yes.
    """
    try:
        import psutil
    except ImportError:
        return True
    try:
        proc = psutil.Process(pid)
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return False
    for _ in range(ANCESTOR_WALK_DEPTH):
        try:
            parent = proc.parent()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return False
        if parent is None:
            return False
        try:
            name = (parent.name() or "").lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return False
        if any(hint in name for hint in HOST_PROCESS_NAME_HINTS):
            return True
        proc = parent
    return False


def _kill_stale_predecessor(pid_file: Path) -> None:
    if not pid_file.exists():
        return
    old_pid = _read_pid_file(pid_file)
    if old_pid is None or old_pid == os.getpid():
        return
    try:
        import psutil
    except ImportError:
        return
    if not psutil.pid_exists(old_pid):
        # Stale file — predecessor already gone.
        return
    if not _is_codebrain_mcp(old_pid):
        # PID was reused by an unrelated process. Don't touch.
        _log.debug("PID %d reused by unrelated process; leaving alone", old_pid)
        return
    if _predecessor_has_live_host(old_pid):
        # Concurrent sibling Claude session is still using this MCP — leave it.
        # Without this, two Claude windows on the same repo race each other and
        # whichever started last kills the other's MCP.
        _log.debug("PID %d has a live IDE host; sibling MCP, leaving alone", old_pid)
        return
    try:
        proc = psutil.Process(old_pid)
        _log.warning("Killing stale CodeBrain MCP predecessor PID %d", old_pid)
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except psutil.TimeoutExpired:
            proc.kill()
    except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
        _log.debug("Could not kill predecessor %d: %s", old_pid, exc)


def _write_pid_file(pid_file: Path) -> None:
    try:
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        pid_file.write_text(
            f"{os.getpid()}\n{int(time.time())}\n",
            encoding="utf-8",
        )
    except OSError as exc:
        _log.debug("Could not write PID file %s: %s", pid_file, exc)


def _remove_pid_file(pid_file: Path) -> None:
    try:
        if not pid_file.exists():
            return
        if _read_pid_file(pid_file) == os.getpid():
            pid_file.unlink()
    except OSError:
        pass


def _find_watch_target(start_pid: int) -> tuple[int, float | None]:
    """Pick the PID whose death should kill the MCP.

    Walks up the ancestor chain (up to ANCESTOR_WALK_DEPTH levels) looking
    for a process whose name matches HOST_PROCESS_NAME_HINTS — that's the
    real IDE host. Falls back to ``start_pid`` if no hint matches, psutil
    is unavailable, or ``CODEBRAIN_MCP_DISABLE_ANCESTOR_WALK=1`` is set.

    Why: on Windows, Claude Code spawns the MCP via a transient launcher
    (cmd.exe wrapper or Electron worker shell). The launcher exits soon
    after the python child starts, so watching ``os.getppid()`` directly
    causes the parent watchdog to mis-fire while Claude Code is still up.
    """
    try:
        import psutil
    except ImportError:
        return start_pid, None

    fallback_create_time: float | None = None
    try:
        fallback_create_time = psutil.Process(start_pid).create_time()
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return start_pid, None

    if os.environ.get("CODEBRAIN_MCP_DISABLE_ANCESTOR_WALK") == "1":
        return start_pid, fallback_create_time

    try:
        proc = psutil.Process(start_pid)
        for _ in range(ANCESTOR_WALK_DEPTH):
            try:
                name = (proc.name() or "").lower()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                break
            if any(hint in name for hint in HOST_PROCESS_NAME_HINTS):
                return proc.pid, proc.create_time()
            try:
                parent = proc.parent()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                break
            if parent is None:
                break
            proc = parent
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass
    return start_pid, fallback_create_time


def _parent_watchdog(initial_ppid: int, initial_create_time: float | None) -> None:
    try:
        import psutil
    except ImportError:
        _log.debug("psutil not installed; parent watchdog disabled")
        return
    while True:
        time.sleep(PARENT_POLL_SECONDS)
        try:
            if not psutil.pid_exists(initial_ppid):
                _exit(f"parent PID {initial_ppid} no longer exists")
            if initial_create_time is not None:
                try:
                    if abs(psutil.Process(initial_ppid).create_time() - initial_create_time) > 1:
                        _exit(f"parent PID {initial_ppid} was reused by a different process")
                except psutil.NoSuchProcess:
                    _exit(f"parent PID {initial_ppid} gone")
            current_ppid = os.getppid()
            if current_ppid != initial_ppid and current_ppid in (0, 1):
                _exit(f"reparented to init ({current_ppid}); orphan")
        except SystemExit:
            raise
        except Exception as exc:  # noqa: BLE001
            _log.debug("parent watchdog tick error: %s", exc)


def _idle_watchdog() -> None:
    if IDLE_TIMEOUT_SECONDS <= 0:
        return
    poll = max(5, min(60, IDLE_TIMEOUT_SECONDS // 4))
    while True:
        time.sleep(poll)
        with _last_activity_lock:
            idle = time.time() - _last_activity
        if idle > IDLE_TIMEOUT_SECONDS:
            _exit(f"idle for {idle:.0f}s (limit {IDLE_TIMEOUT_SECONDS}s)")


def _lifetime_watchdog(start: float) -> None:
    if MAX_LIFETIME_SECONDS <= 0:
        return
    while True:
        time.sleep(60)
        if time.time() - start > MAX_LIFETIME_SECONDS:
            _exit(f"max lifetime {MAX_LIFETIME_SECONDS}s reached")


def install_watchdogs(repo_root: Path | None = None) -> None:
    """Start watchdog threads + write the PID file. Idempotent.

    Pass ``repo_root`` to enable PID-file based self-heal (kills stale
    predecessor on this repo, writes own PID, schedules cleanup on exit).
    Without ``repo_root`` only the in-process watchdogs run.
    """
    global _installed
    if _installed:
        return
    _installed = True

    start = time.time()
    mark_activity()

    if repo_root is not None:
        from codebrain.config import CODEBRAIN_DIR
        pid_file = repo_root / CODEBRAIN_DIR / PID_FILE_NAME
        _kill_stale_predecessor(pid_file)
        _write_pid_file(pid_file)
        atexit.register(_remove_pid_file, pid_file)

    immediate_ppid = os.getppid()
    initial_ppid, initial_create_time = _find_watch_target(immediate_ppid)

    _log.info(
        "MCP watchdogs installed (ppid=%d via=%d, idle_timeout=%ds, max_lifetime=%ds)",
        initial_ppid,
        immediate_ppid,
        IDLE_TIMEOUT_SECONDS,
        MAX_LIFETIME_SECONDS,
    )

    threading.Thread(
        target=_parent_watchdog,
        args=(initial_ppid, initial_create_time),
        name="cb-parent-watchdog",
        daemon=True,
    ).start()
    threading.Thread(
        target=_idle_watchdog,
        name="cb-idle-watchdog",
        daemon=True,
    ).start()
    if MAX_LIFETIME_SECONDS > 0:
        threading.Thread(
            target=_lifetime_watchdog,
            args=(start,),
            name="cb-lifetime-watchdog",
            daemon=True,
        ).start()


# ---------------------------------------------------------------------------
# Operational helpers (used by `brain doctor` and `brain reindex`).
# ---------------------------------------------------------------------------


def find_db_lock_holder(repo_root: Path) -> int | None:
    """Return the PID holding the MCP-side lock for this repo, if recorded.

    Reads <repo>/.codebrain/mcp.pid and verifies the PID is still alive AND
    is actually a codebrain.mcp_server process. Stale records return None.
    """
    from codebrain.config import CODEBRAIN_DIR
    pid_file = repo_root / CODEBRAIN_DIR / PID_FILE_NAME
    if not pid_file.exists():
        return None
    pid = _read_pid_file(pid_file)
    if pid is None:
        return None
    try:
        import psutil
    except ImportError:
        return None
    if not psutil.pid_exists(pid):
        return None
    if not _is_codebrain_mcp(pid):
        return None
    return pid


def kill_pid(pid: int, timeout: float = 3.0) -> str:
    """Terminate then kill a PID. Returns 'terminated' / 'killed' / 'error: ...'."""
    try:
        import psutil
        proc = psutil.Process(pid)
        proc.terminate()
        try:
            proc.wait(timeout=timeout)
            return "terminated"
        except psutil.TimeoutExpired:
            proc.kill()
            return "killed"
    except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
        return f"error: {exc}"
    except ImportError:
        return "error: psutil not installed"


def find_stale_mcps() -> list[dict]:
    """List CodeBrain MCP processes that look abandoned.

    Stale criteria (any one):
      - parent PID no longer exists
      - process has been running > STALE_AGE_SECONDS

    Skips the calling process itself.
    """
    try:
        import psutil
    except ImportError:
        return []
    stale: list[dict] = []
    self_pid = os.getpid()
    for proc in psutil.process_iter(["pid", "cmdline", "create_time", "ppid"]):
        try:
            info = proc.info
            if info["pid"] == self_pid:
                continue
            cmdline_list = info.get("cmdline") or []
            cmdline = " ".join(cmdline_list)
            if "codebrain.mcp_server" not in cmdline:
                continue
            ppid = info.get("ppid")
            parent_alive = bool(ppid) and psutil.pid_exists(ppid)
            create = info.get("create_time") or time.time()
            age = time.time() - create
            reason = None
            if not parent_alive:
                reason = f"parent PID {ppid} dead"
            elif age > STALE_AGE_SECONDS:
                reason = f"running {age / 3600:.1f}h"
            if reason:
                stale.append({
                    "pid": info["pid"],
                    "ppid": ppid,
                    "age_hours": round(age / 3600, 2),
                    "reason": reason,
                })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return stale


def kill_stale_mcps() -> list[dict]:
    """Kill every process returned by find_stale_mcps. Returns per-PID status."""
    return [
        {"pid": entry["pid"], "status": kill_pid(entry["pid"])}
        for entry in find_stale_mcps()
    ]
