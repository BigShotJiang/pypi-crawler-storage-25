"""Git diff impact analysis.

Maps actual git changes to the knowledge graph to compute blast radius,
risk assessment, and affected components. Shows what your uncommitted
or branch changes will break BEFORE you commit.

Inspired by Understand-Anything's /understand-diff, but built on
CodeBrain's deterministic impact analysis — no LLM required.
"""

from __future__ import annotations

import subprocess
from collections import defaultdict
from pathlib import Path

from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.utils import is_test_file


class DiffImpactAnalyzer:
    """Analyze the structural impact of git changes."""

    def __init__(self, store: GraphStore, repo_root: Path) -> None:
        self.store = store
        self.repo_root = repo_root
        self.engine = QueryEngine(store)
        self.comp = ComprehensionEngine(store)

    def analyze(
        self,
        *,
        ref: str | None = None,
        staged_only: bool = False,
    ) -> dict:
        """Analyze impact of git changes.

        Args:
            ref: Git ref to diff against (e.g. 'main', 'HEAD~3', 'abc1234').
                 If None, shows uncommitted changes (staged + unstaged).
            staged_only: Only analyze staged changes.

        Returns:
            dict with: changed_files, affected_symbols, blast_radius,
                       risk_assessment, cross_layer_impact, narrative
        """
        # Get changed files from git
        changed_files = self._get_changed_files(ref=ref, staged_only=staged_only)
        if not changed_files:
            return {
                "changed_files": [],
                "affected_symbols": [],
                "blast_radius": {"files": 0, "symbols": 0, "percentage": 0.0},
                "risk_assessment": "low",
                "risk_details": [],
                "cross_layer_impact": [],
                "narrative": "No changes detected.",
            }

        # Map changed files to graph nodes
        changed_symbols = self._map_files_to_symbols(changed_files)

        # Compute transitive impact for each changed symbol
        self.engine.preload_reverse_index()
        all_affected = self._compute_blast_radius(changed_symbols)

        # Get total stats for percentage calculation
        stats = self.store.get_stats()
        total_files = max(stats.get("files", 1), 1)
        total_nodes = max(stats.get("nodes", 1), 1)

        # Affected files (unique)
        affected_files = set()
        for a in all_affected:
            node = self.store.get_node(a["node_id"])
            if node and node.get("file_path"):
                affected_files.add(node["file_path"])

        # Cross-layer impact
        cross_layer = self._detect_cross_layer_impact(changed_files, affected_files)

        # Risk assessment
        risk, risk_details = self._assess_risk(
            changed_files, changed_symbols, all_affected,
            affected_files, cross_layer, total_files,
        )

        # Build narrative
        narrative = self._build_narrative(
            changed_files, changed_symbols, all_affected,
            affected_files, risk, cross_layer, ref,
        )

        return {
            "changed_files": [
                {"path": f["path"], "status": f["status"]}
                for f in changed_files
            ],
            "affected_symbols": [
                {
                    "node_id": a["node_id"],
                    "depth": a["depth"],
                    "via": a["via"],
                    "edge_type": a["edge_type"],
                }
                for a in all_affected[:100]  # cap output
            ],
            "blast_radius": {
                "files": len(affected_files),
                "symbols": len(all_affected),
                "percentage": round(len(affected_files) / total_files * 100, 1),
                "files_changed": len(changed_files),
                "symbols_changed": len(changed_symbols),
            },
            "risk_assessment": risk,
            "risk_details": risk_details,
            "cross_layer_impact": cross_layer,
            "narrative": narrative,
        }

    # ------------------------------------------------------------------
    # Git integration
    # ------------------------------------------------------------------

    def _get_changed_files(
        self,
        *,
        ref: str | None = None,
        staged_only: bool = False,
    ) -> list[dict]:
        """Get changed files from git diff."""
        try:
            if ref:
                # Diff against a specific ref
                cmd = ["git", "diff", "--name-status", ref]
            elif staged_only:
                cmd = ["git", "diff", "--name-status", "--cached"]
            else:
                # Uncommitted changes (staged + unstaged + untracked)
                cmd = ["git", "diff", "--name-status", "HEAD"]

            result = subprocess.run(
                cmd,
                cwd=str(self.repo_root),
                capture_output=True,
                text=True,
                timeout=30,
            )

            files = []
            for line in result.stdout.strip().split("\n"):
                if not line.strip():
                    continue
                parts = line.split("\t", 1)
                if len(parts) == 2:
                    status_code = parts[0].strip()
                    file_path = parts[1].strip()
                    status = {
                        "A": "added",
                        "M": "modified",
                        "D": "deleted",
                    }.get(status_code[0], "modified")
                    files.append({"path": file_path, "status": status})

            # Also get untracked files if no ref specified
            if not ref and not staged_only:
                untracked = subprocess.run(
                    ["git", "ls-files", "--others", "--exclude-standard"],
                    cwd=str(self.repo_root),
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                for line in untracked.stdout.strip().split("\n"):
                    if line.strip():
                        files.append({"path": line.strip(), "status": "added"})

            return files

        except (subprocess.TimeoutExpired, FileNotFoundError):
            return []

    # ------------------------------------------------------------------
    # Graph mapping
    # ------------------------------------------------------------------

    def _map_files_to_symbols(self, changed_files: list[dict]) -> list[dict]:
        """Map changed file paths to graph nodes."""
        symbols = []
        for cf in changed_files:
            path = cf["path"]
            nodes = self.store.get_nodes_by_file(path)
            for n in nodes:
                if n["type"] != "file":
                    symbols.append({
                        "node_id": n["id"],
                        "name": n["name"],
                        "type": n["type"],
                        "file_path": path,
                        "change_status": cf["status"],
                    })
        return symbols

    def _compute_blast_radius(self, changed_symbols: list[dict]) -> list[dict]:
        """Compute transitive impact across all changed symbols."""
        all_affected: list[dict] = []
        seen: set[str] = {s["node_id"] for s in changed_symbols}

        for sym in changed_symbols:
            impact = self.engine.impact_of_change(sym["node_id"], max_depth=5)
            for item in impact:
                if item["node_id"] not in seen:
                    seen.add(item["node_id"])
                    all_affected.append(item)

        # Sort by depth (closest impact first)
        all_affected.sort(key=lambda x: x["depth"])
        return all_affected

    # ------------------------------------------------------------------
    # Risk assessment
    # ------------------------------------------------------------------

    def _detect_cross_layer_impact(
        self, changed_files: list[dict], affected_files: set[str],
    ) -> list[dict]:
        """Detect when changes in one layer affect another."""
        try:
            from codebrain.analyzer import StructuralAnalyzer
            analyzer = StructuralAnalyzer(self.store)
            layers_data = analyzer.detect_layers()
        except Exception:
            return []

        if not layers_data or not layers_data.get("layers"):
            return []

        # Map files to layers
        file_to_layer: dict[str, str] = {}
        for layer in layers_data["layers"]:
            label = layer.get("label", "Unknown")
            for f in layer.get("files", []):
                file_to_layer[f] = label

        changed_layers = set()
        for cf in changed_files:
            layer = file_to_layer.get(cf["path"])
            if layer:
                changed_layers.add(layer)

        affected_layers = set()
        for f in affected_files:
            layer = file_to_layer.get(f)
            if layer:
                affected_layers.add(layer)

        cross_impacts = []
        spillover = affected_layers - changed_layers
        for layer in spillover:
            affected_in_layer = [
                f for f in affected_files if file_to_layer.get(f) == layer
            ]
            cross_impacts.append({
                "layer": layer,
                "affected_files": len(affected_in_layer),
                "source_layers": list(changed_layers),
            })

        return cross_impacts

    def _assess_risk(
        self,
        changed_files: list[dict],
        changed_symbols: list[dict],
        all_affected: list[dict],
        affected_files: set[str],
        cross_layer: list[dict],
        total_files: int,
    ) -> tuple[str, list[str]]:
        """Assess overall risk level of the changes."""
        details = []
        risk_score = 0

        # Factor 1: Blast radius percentage
        pct = len(affected_files) / total_files * 100
        if pct > 30:
            risk_score += 3
            details.append(f"High blast radius: {pct:.0f}% of codebase affected")
        elif pct > 10:
            risk_score += 2
            details.append(f"Moderate blast radius: {pct:.0f}% of codebase affected")
        elif pct > 0:
            risk_score += 1

        # Factor 2: Cross-layer impact
        if len(cross_layer) > 2:
            risk_score += 3
            details.append(f"Changes ripple across {len(cross_layer)} additional layers")
        elif cross_layer:
            risk_score += 1
            details.append(f"Changes affect {len(cross_layer)} other layer(s)")

        # Factor 3: Deleted files
        deleted = [f for f in changed_files if f["status"] == "deleted"]
        if deleted:
            risk_score += 2
            details.append(f"{len(deleted)} file(s) deleted — check for broken imports")

        # Factor 4: Number of affected symbols
        if len(all_affected) > 50:
            risk_score += 2
            details.append(f"{len(all_affected)} symbols transitively affected")
        elif len(all_affected) > 20:
            risk_score += 1

        # Factor 5: Hotspot involvement
        try:
            hotspots = self.comp.risk_hotspots(top_n=10)
            hotspot_files = {h["file_path"] for h in hotspots}
            touched_hotspots = [
                f["path"] for f in changed_files if f["path"] in hotspot_files
            ]
            if touched_hotspots:
                risk_score += 2
                details.append(
                    f"Touches {len(touched_hotspots)} risk hotspot(s): "
                    + ", ".join(f"`{f}`" for f in touched_hotspots[:3])
                )
        except Exception:
            pass

        if risk_score >= 6:
            return "critical", details
        elif risk_score >= 4:
            return "high", details
        elif risk_score >= 2:
            return "medium", details
        return "low", details

    # ------------------------------------------------------------------
    # Narrative
    # ------------------------------------------------------------------

    def _build_narrative(
        self,
        changed_files: list[dict],
        changed_symbols: list[dict],
        all_affected: list[dict],
        affected_files: set[str],
        risk: str,
        cross_layer: list[dict],
        ref: str | None,
    ) -> str:
        """Build a plain-English narrative of the impact."""
        parts = []

        # Opening
        ref_desc = f"compared to `{ref}`" if ref else "in uncommitted changes"
        parts.append(
            f"**{len(changed_files)} file(s) changed** {ref_desc}, "
            f"containing {len(changed_symbols)} modified symbol(s)."
        )

        # Blast radius
        if all_affected:
            parts.append(
                f"These changes ripple to **{len(all_affected)} additional symbols** "
                f"across **{len(affected_files)} files**."
            )
        else:
            parts.append("No downstream impact detected — changes are self-contained.")

        # Cross-layer
        if cross_layer:
            layers_str = ", ".join(c["layer"] for c in cross_layer)
            parts.append(f"Cross-layer impact: changes spill into {layers_str}.")

        # Risk
        risk_emoji = {
            "critical": "🔴",
            "high": "🟠",
            "medium": "🟡",
            "low": "🟢",
        }.get(risk, "⚪")
        parts.append(f"**Risk: {risk_emoji} {risk.upper()}**")

        # Top affected (by depth=1, direct callers)
        direct = [a for a in all_affected if a["depth"] == 1]
        if direct:
            parts.append(
                f"\nDirect dependents ({len(direct)}):"
            )
            for d in direct[:10]:
                parts.append(f"  - `{d['node_id']}` (via {d['edge_type']})")
            if len(direct) > 10:
                parts.append(f"  ...and {len(direct) - 10} more")

        return "\n".join(parts)
