"""Structural test coverage gap analysis.

Traces CALLS edges from test functions into production code to find
symbols that no test path reaches. Gaps are ranked by risk.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import ClassVar

from codebrain.graph.store import GraphStore
from codebrain.utils import is_test_file


@dataclass
class CoverageGap:
    node_id: str
    name: str
    qualified_name: str
    symbol_type: str
    file_path: str
    line_start: int
    is_exported: bool
    direct_dependents: int
    risk_score: float
    risk_reason: str


@dataclass
class TestCoverageReport:
    __test__: ClassVar[bool] = False  # not a pytest test class
    total_production_symbols: int
    tested_symbols: int
    untested_symbols: int
    coverage_percent: float
    gaps: list[CoverageGap]
    tested_files: int
    untested_files: int
    most_tested_files: list[dict]
    least_tested_files: list[dict]
    test_node_count: int
    narrative: str


class TestCoverageAnalyzer:
    """Structural test coverage gap analysis."""

    __test__ = False  # not a pytest test class

    def __init__(self, store: GraphStore):
        self.store = store

    def analyze(
        self,
        max_depth: int = 3,
        include_methods: bool = True,
        min_risk: float = 0.0,
    ) -> TestCoverageReport:
        """Analyze structural test coverage gaps.

        Args:
            max_depth: How far to trace calls from test functions (1=direct only, 0=unlimited)
            include_methods: If True, methods are included in PROD_NODES.
                If False, methods are excluded entirely from coverage stats.
            min_risk: Only report gaps with risk_score >= this threshold

        Returns:
            TestCoverageReport with stats, gaps, and narrative
        """
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # --- Step 1-2: Partition nodes ---
        test_node_ids: set[str] = set()
        prod_node_ids: set[str] = set()
        node_by_id: dict[str, dict] = {}

        for node in all_nodes:
            node_by_id[node["id"]] = node
            ntype = node["type"]
            name = node["name"]
            fp = node["file_path"]

            # Skip file nodes, dunders, variables
            if ntype == "file":
                continue
            if ntype == "variable":
                continue
            if name.startswith("__") and name.endswith("__"):
                continue

            # Skip methods if not included
            if not include_methods and ntype == "method":
                continue

            # Classify as test or prod
            if is_test_file(fp) or name.startswith("test_") or name.startswith("Test"):
                test_node_ids.add(node["id"])
            else:
                prod_node_ids.add(node["id"])

        # --- Step 3-4: Build forward call graph with name resolution ---
        # Build name indexes for resolving unresolved targets
        id_set = set(node_by_id.keys())
        name_to_ids: dict[str, list[str]] = {}
        qname_to_ids: dict[str, list[str]] = {}
        for node in all_nodes:
            name_to_ids.setdefault(node["name"], []).append(node["id"])
            qname_to_ids.setdefault(node["qualified_name"], []).append(node["id"])

        # Build adjacency list: source -> [resolved target IDs]
        adj: dict[str, set[str]] = {}
        # Also count incoming prod CALLS for risk scoring
        prod_incoming: dict[str, int] = {}

        for edge in all_edges:
            if edge["type"] != "CALLS":
                continue
            source = edge["source"]
            target_raw = edge["target"]

            # Resolve target to node IDs
            resolved: list[str] = []
            if target_raw in id_set:
                resolved.append(target_raw)
            elif target_raw in qname_to_ids:
                resolved.extend(qname_to_ids[target_raw])
            elif target_raw in name_to_ids:
                resolved.extend(name_to_ids[target_raw])
            # Handle self.method targets
            elif target_raw.startswith("self."):
                method_name = target_raw[5:]
                if method_name in name_to_ids:
                    resolved.extend(name_to_ids[method_name])

            for tid in resolved:
                adj.setdefault(source, set()).add(tid)
                # Count incoming calls from prod nodes
                if source in prod_node_ids and tid in prod_node_ids:
                    prod_incoming[tid] = prod_incoming.get(tid, 0) + 1

        # --- Step 5: BFS from test nodes ---
        tested: set[str] = set()
        effective_depth = None if max_depth == 0 else max_depth

        for test_id in test_node_ids:
            queue: deque[tuple[str, int]] = deque([(test_id, 0)])
            visited: set[str] = {test_id}
            while queue:
                current, depth = queue.popleft()
                if current in prod_node_ids:
                    tested.add(current)
                if effective_depth is not None and depth >= effective_depth:
                    continue
                for neighbor in adj.get(current, ()):
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append((neighbor, depth + 1))

        # --- Step 6: Compute untested ---
        untested = prod_node_ids - tested

        # --- Step 7: Risk scoring + gaps ---
        gaps: list[CoverageGap] = []
        for nid in untested:
            node = node_by_id[nid]
            deps = prod_incoming.get(nid, 0)
            is_exp = bool(node["is_exported"])
            stype = node["type"]

            risk = 0.0
            reasons: list[str] = []
            if is_exp:
                risk += 0.3
                reasons.append("exported")
            if deps >= 5:
                risk += 0.3
                reasons.append(f"{deps} dependents")
            elif deps >= 2:
                risk += 0.15
                reasons.append(f"{deps} dependents")
            if stype == "class":
                risk += 0.1
                reasons.append("class")
            if deps >= 10:
                risk += 0.2
                reasons.append("high fan-in")
            risk = min(risk, 1.0)

            if risk < min_risk:
                continue

            gaps.append(CoverageGap(
                node_id=nid,
                name=node["name"],
                qualified_name=node["qualified_name"],
                symbol_type=stype,
                file_path=node["file_path"],
                line_start=node["line_start"],
                is_exported=is_exp,
                direct_dependents=deps,
                risk_score=round(risk, 2),
                risk_reason=", ".join(reasons) if reasons else "low risk",
            ))

        gaps.sort(key=lambda g: g.risk_score, reverse=True)

        # --- Step 8: File-level stats ---
        prod_files: dict[str, dict] = {}  # file -> {tested: int, total: int}
        for nid in prod_node_ids:
            node = node_by_id[nid]
            fp = node["file_path"]
            if fp not in prod_files:
                prod_files[fp] = {"tested": 0, "total": 0}
            prod_files[fp]["total"] += 1
            if nid in tested:
                prod_files[fp]["tested"] += 1

        tested_file_count = sum(1 for v in prod_files.values() if v["tested"] > 0)
        untested_file_count = sum(1 for v in prod_files.values() if v["tested"] == 0)

        file_stats = [
            {"file": fp, "tested_count": v["tested"], "total_count": v["total"]}
            for fp, v in prod_files.items()
        ]
        file_stats.sort(key=lambda x: x["tested_count"] / max(x["total_count"], 1), reverse=True)
        most_tested = file_stats[:5]
        least_tested = file_stats[-5:] if len(file_stats) > 5 else list(reversed(file_stats))

        # --- Step 9: Narrative ---
        total_prod = len(prod_node_ids)
        tested_count = len(tested)
        untested_count = len(untested)
        coverage_pct = (tested_count / total_prod * 100) if total_prod > 0 else 0.0

        narrative = self._build_narrative(
            test_count=len(test_node_ids),
            total_prod=total_prod,
            tested_count=tested_count,
            coverage_pct=coverage_pct,
            gaps=gaps,
            tested_file_count=tested_file_count,
            untested_file_count=untested_file_count,
            prod_files=prod_files,
        )

        return TestCoverageReport(
            total_production_symbols=total_prod,
            tested_symbols=tested_count,
            untested_symbols=untested_count,
            coverage_percent=round(coverage_pct, 1),
            gaps=gaps,
            tested_files=tested_file_count,
            untested_files=untested_file_count,
            most_tested_files=most_tested,
            least_tested_files=least_tested,
            test_node_count=len(test_node_ids),
            narrative=narrative,
        )

    @staticmethod
    def _build_narrative(
        test_count: int,
        total_prod: int,
        tested_count: int,
        coverage_pct: float,
        gaps: list[CoverageGap],
        tested_file_count: int,
        untested_file_count: int,
        prod_files: dict[str, dict],
    ) -> str:
        lines: list[str] = []
        lines.append("Test Coverage Analysis")
        lines.append("=" * 22)

        if test_count == 0:
            lines.append("No test files found in the codebase.")
            lines.append(f"{total_prod} production symbols have zero structural test coverage.")
            return "\n".join(lines)

        lines.append(
            f"CodeBrain traced CALLS edges from {test_count} test functions "
            f"into your production code."
        )
        lines.append("")
        lines.append(
            f"Coverage: {coverage_pct:.1f}% of production symbols are structurally "
            f"reached by tests ({tested_count}/{total_prod})."
        )

        # Critical gaps
        high_risk = [g for g in gaps if g.risk_score >= 0.5]
        if high_risk:
            lines.append("")
            lines.append("Critical gaps (high-risk, untested):")
            for g in high_risk[:5]:
                lines.append(
                    f"  - {g.name} ({g.file_path}:{g.line_start}) "
                    f"— {g.risk_reason}"
                )

        # File coverage
        lines.append("")
        lines.append(
            f"File coverage: {tested_file_count}/{tested_file_count + untested_file_count} "
            f"production files have at least one tested symbol."
        )
        if untested_file_count > 0:
            zero_files = [fp for fp, v in prod_files.items() if v["tested"] == 0]
            lines.append(f"  {untested_file_count} files have zero test coverage:")
            for fp in zero_files[:5]:
                count = prod_files[fp]["total"]
                lines.append(f"    {fp} ({count} symbols)")

        # Recommendation
        if high_risk:
            lines.append("")
            lines.append(
                f"Recommendation: Prioritize tests for the {min(len(high_risk), 5)} "
                f"high-risk gaps above."
            )

        return "\n".join(lines)
