"""Frontend analyzer — cross-file component analysis.

Queries the enriched graph (after FrontendComponentParser runs) to produce:
- Component tree (hierarchical from RENDERS edges)
- Route map (from ROUTES_TO edges)
- State graph (from SUBSCRIBES/DISPATCHES edges)
- API surface (from FETCHES edges)
- Component contracts (full contract for a single component)
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field

from codebrain.graph.store import GraphStore
from codebrain.logging import get_logger

_log = get_logger("frontend")


@dataclass
class FrontendReport:
    """Complete frontend analysis report."""

    total_components: int = 0
    total_routes: int = 0
    total_stores: int = 0
    total_api_endpoints: int = 0
    component_tree: dict = field(default_factory=dict)
    route_map: list = field(default_factory=list)
    state_graph: dict = field(default_factory=dict)
    api_surface: list = field(default_factory=list)
    orphan_components: list = field(default_factory=list)
    unrouted_pages: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "total_components": self.total_components,
            "total_routes": self.total_routes,
            "total_stores": self.total_stores,
            "total_api_endpoints": self.total_api_endpoints,
            "component_tree": self.component_tree,
            "route_map": self.route_map,
            "state_graph": self.state_graph,
            "api_surface": self.api_surface,
            "orphan_components": self.orphan_components,
            "unrouted_pages": self.unrouted_pages,
        }


class FrontendAnalyzer:
    """Cross-file frontend analysis using the enriched knowledge graph."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store

    def analyze(self) -> FrontendReport:
        """Run full frontend analysis and return a FrontendReport."""
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Categorize nodes
        components = [n for n in all_nodes if n["type"] == "component"]
        hooks = [n for n in all_nodes if n["type"] == "hook"]
        routes = [n for n in all_nodes if n["type"] == "route"]
        stores = [n for n in all_nodes if n["type"] == "store"]

        # Edge maps
        _edges_by_type = defaultdict(list)
        for e in all_edges:
            _edges_by_type[e["type"]].append(e)
        edges_by_type = dict(_edges_by_type)

        # Build report
        component_tree = self.get_component_tree(components, edges_by_type)
        route_map = self.get_route_map(routes, edges_by_type)
        state_graph = self.get_state_graph(stores, edges_by_type)
        api_surface = self.get_api_surface(edges_by_type)

        # Find orphan components (not rendered by anyone, not served by a route)
        rendered_targets: set[str] = set()
        for e in edges_by_type.get("RENDERS", []):
            rendered_targets.add(e["target"])
        routed_targets: set[str] = set()
        for e in edges_by_type.get("ROUTES_TO", []):
            routed_targets.add(e["target"])

        orphans = []
        unrouted = []
        for comp in components:
            name = comp["name"]
            is_rendered = name in rendered_targets or comp["id"] in rendered_targets
            is_routed = name in routed_targets or comp["id"] in routed_targets

            if not is_rendered and not is_routed:
                orphans.append(name)
            # Page-like components (in a "page" or "pages" directory) without routes
            fp = comp["file_path"].lower()
            if ("page" in fp or "view" in fp) and not is_routed:
                unrouted.append(name)

        report = FrontendReport(
            total_components=len(components),
            total_routes=len(routes),
            total_stores=len(stores),
            total_api_endpoints=len(api_surface),
            component_tree=component_tree,
            route_map=route_map,
            state_graph=state_graph,
            api_surface=api_surface,
            orphan_components=orphans,
            unrouted_pages=unrouted,
        )

        _log.info(
            "Frontend analysis: %d components, %d routes, %d stores, %d API endpoints",
            report.total_components, report.total_routes,
            report.total_stores, report.total_api_endpoints,
        )
        return report

    def get_component_tree(
        self,
        components: list[dict] | None = None,
        edges_by_type: dict[str, list[dict]] | None = None,
    ) -> dict:
        """Build hierarchical component tree from RENDERS edges.

        Returns a dict with 'roots' (components not rendered by others)
        and 'tree' (nested structure).
        """
        if components is None or edges_by_type is None:
            all_nodes = self.store.get_all_nodes()
            all_edges = self.store.get_all_edges()
            components = [n for n in all_nodes if n["type"] == "component"]
            edges_by_type = defaultdict(list)
            for e in all_edges:
                edges_by_type[e["type"]].append(e)

        # Map component name → node
        comp_by_name: dict[str, dict] = {}
        for c in components:
            comp_by_name[c["name"]] = c

        # Build parent → children map from RENDERS edges
        children_of = defaultdict(list)
        rendered_set: set[str] = set()
        for e in edges_by_type.get("RENDERS", []):
            source_name = e["source"].rsplit("::", 1)[-1] if "::" in e["source"] else e["source"]
            target_name = e["target"].rsplit("::", 1)[-1] if "::" in e["target"] else e["target"]
            children_of[source_name].append(target_name)
            rendered_set.add(target_name)

        # Props passed
        props_map = defaultdict(list)
        for e in edges_by_type.get("PASSES_PROP", []):
            source_name = e["source"].rsplit("::", 1)[-1] if "::" in e["source"] else e["source"]
            target_name = e["target"].rsplit("::", 1)[-1] if "::" in e["target"] else e["target"]
            props_map[(source_name, target_name)].append("prop")

        # Find roots (not rendered by anyone)
        roots = [c["name"] for c in components if c["name"] not in rendered_set]

        # BFS to build tree
        def _build_subtree(name: str, visited: set[str]) -> dict:
            if name in visited:
                return {"name": name, "circular": True}
            visited.add(name)
            comp = comp_by_name.get(name, {})
            children = []
            for child_name in children_of.get(name, []):
                children.append(_build_subtree(child_name, visited.copy()))
            node = {
                "name": name,
                "file": comp.get("file_path", ""),
                "children": children,
            }
            if comp.get("signature"):
                node["props"] = comp["signature"]
            return node

        tree = {}
        for root in sorted(roots):
            tree[root] = _build_subtree(root, set())

        return {
            "roots": sorted(roots),
            "tree": tree,
            "total_components": len(components),
        }

    def get_route_map(
        self,
        routes: list[dict] | None = None,
        edges_by_type: dict[str, list[dict]] | None = None,
    ) -> list[dict]:
        """Extract all routes with their target components."""
        if routes is None or edges_by_type is None:
            all_nodes = self.store.get_all_nodes()
            all_edges = self.store.get_all_edges()
            routes = [n for n in all_nodes if n["type"] == "route"]
            edges_by_type = defaultdict(list)
            for e in all_edges:
                edges_by_type[e["type"]].append(e)

        route_to_comp: dict[str, str] = {}
        for e in edges_by_type.get("ROUTES_TO", []):
            route_to_comp[e["source"]] = e["target"]

        result = []
        for route in routes:
            component = route_to_comp.get(route["id"], "")
            result.append({
                "path": route["name"],
                "component": component,
                "file": route["file_path"],
            })

        return sorted(result, key=lambda r: r["path"])

    def get_state_graph(
        self,
        stores: list[dict] | None = None,
        edges_by_type: dict[str, list[dict]] | None = None,
    ) -> dict:
        """Map which components subscribe to / dispatch to which stores."""
        if stores is None or edges_by_type is None:
            all_nodes = self.store.get_all_nodes()
            all_edges = self.store.get_all_edges()
            stores = [n for n in all_nodes if n["type"] == "store"]
            edges_by_type = defaultdict(list)
            for e in all_edges:
                edges_by_type[e["type"]].append(e)

        store_graph: dict[str, dict] = {}
        for s in stores:
            store_graph[s["name"]] = {
                "file": s["file_path"],
                "subscribers": [],
                "dispatchers": [],
            }

        for e in edges_by_type.get("SUBSCRIBES", []):
            source_name = e["source"].rsplit("::", 1)[-1] if "::" in e["source"] else e["source"]
            store_graph.setdefault(e["target"], {
                "file": "", "subscribers": [], "dispatchers": [],
            })
            if source_name not in store_graph[e["target"]]["subscribers"]:
                store_graph[e["target"]]["subscribers"].append(source_name)

        for e in edges_by_type.get("DISPATCHES", []):
            source_name = e["source"].rsplit("::", 1)[-1] if "::" in e["source"] else e["source"]
            store_graph.setdefault(e["target"], {
                "file": "", "subscribers": [], "dispatchers": [],
            })
            if source_name not in store_graph[e["target"]]["dispatchers"]:
                store_graph[e["target"]]["dispatchers"].append(source_name)

        return store_graph

    def get_api_surface(
        self,
        edges_by_type: dict[str, list[dict]] | None = None,
    ) -> list[dict]:
        """All API endpoints called by the frontend."""
        if edges_by_type is None:
            all_edges = self.store.get_all_edges()
            edges_by_type = defaultdict(list)
            for e in all_edges:
                edges_by_type[e["type"]].append(e)

        url_to_callers = defaultdict(list)
        for e in edges_by_type.get("FETCHES", []):
            url = e["target"]
            source_name = e["source"].rsplit("::", 1)[-1] if "::" in e["source"] else e["source"]
            if source_name not in url_to_callers[url]:
                url_to_callers[url].append(source_name)

        result = []
        for url, callers in sorted(url_to_callers.items()):
            result.append({
                "url": url,
                "callers": callers,
                "caller_count": len(callers),
            })

        return result

    def get_component_contract(self, name: str) -> dict:
        """Full contract for a single component."""
        nodes = self.store.get_nodes_by_name(name)
        component = None
        for n in nodes:
            if n["type"] == "component":
                component = n
                break
        if not component:
            return {"error": f"Component '{name}' not found"}

        comp_id = component["id"]
        edges_from = self.store.get_edges_from(comp_id)
        edges_to = self.store.get_edges_to(comp_id)
        # Also check by name
        edges_to_name = self.store.get_edges_to(name)

        # Children rendered
        renders = [e["target"] for e in edges_from if e["type"] == "RENDERS"]

        # Props
        props_passed = [e["target"] for e in edges_from if e["type"] == "PASSES_PROP"]

        # State subscriptions
        subscribes = [e["target"] for e in edges_from if e["type"] == "SUBSCRIBES"]

        # Dispatches
        dispatches = [e["target"] for e in edges_from if e["type"] == "DISPATCHES"]

        # API calls
        fetches = [e["target"] for e in edges_from if e["type"] == "FETCHES"]

        # Routes served (from ROUTES_TO edges targeting this component)
        routes_served = []
        for e in edges_to + edges_to_name:
            if e["type"] == "ROUTES_TO":
                # Source is the route node
                route_node = self.store.get_node(e["source"])
                if route_node:
                    routes_served.append(route_node["name"])

        # Rendered by (parents)
        rendered_by = []
        for e in edges_to + edges_to_name:
            if e["type"] == "RENDERS":
                source_name = e["source"].rsplit("::", 1)[-1] if "::" in e["source"] else e["source"]
                if source_name not in rendered_by:
                    rendered_by.append(source_name)

        return {
            "name": name,
            "file": component["file_path"],
            "signature": component.get("signature", ""),
            "decorators": json.loads(component.get("decorators", "[]") or "[]"),
            "summary": component.get("summary", ""),
            "children_rendered": renders,
            "props_passed_to_children": list(set(props_passed)),
            "state_subscriptions": subscribes,
            "dispatches": dispatches,
            "api_calls": fetches,
            "routes_served": routes_served,
            "rendered_by": rendered_by,
        }

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def to_markdown(self, report: FrontendReport | None = None) -> str:
        """Render the frontend report as Markdown."""
        if report is None:
            report = self.analyze()

        lines = [
            "# Frontend Analysis Report\n",
            "## Summary\n",
            f"| Metric | Count |",
            f"|--------|-------|",
            f"| Components | {report.total_components} |",
            f"| Routes | {report.total_routes} |",
            f"| State Stores | {report.total_stores} |",
            f"| API Endpoints | {report.total_api_endpoints} |",
            "",
        ]

        # Component tree
        if report.component_tree.get("roots"):
            lines.append("## Component Tree\n")
            tree = report.component_tree.get("tree", {})
            for root_name in report.component_tree["roots"]:
                self._render_tree_node(tree.get(root_name, {}), lines, indent=0)
            lines.append("")

        # Route map
        if report.route_map:
            lines.append("## Routes\n")
            lines.append("| Path | Component | File |")
            lines.append("|------|-----------|------|")
            for route in report.route_map:
                lines.append(
                    f"| `{route['path']}` | `{route['component']}` | `{route['file']}` |"
                )
            lines.append("")

        # State graph
        if report.state_graph:
            lines.append("## State Management\n")
            for store_name, info in sorted(report.state_graph.items()):
                lines.append(f"### Store: `{store_name}`\n")
                if info.get("subscribers"):
                    lines.append(f"**Subscribers:** {', '.join(f'`{s}`' for s in info['subscribers'])}")
                if info.get("dispatchers"):
                    lines.append(f"**Dispatchers:** {', '.join(f'`{d}`' for d in info['dispatchers'])}")
                lines.append("")

        # API surface
        if report.api_surface:
            lines.append("## API Surface\n")
            lines.append("| Endpoint | Callers |")
            lines.append("|----------|---------|")
            for api in report.api_surface:
                callers = ", ".join(f"`{c}`" for c in api["callers"])
                lines.append(f"| `{api['url']}` | {callers} |")
            lines.append("")

        # Orphans
        if report.orphan_components:
            lines.append("## Orphan Components\n")
            lines.append("Components not rendered by any parent or route:\n")
            for name in sorted(report.orphan_components):
                lines.append(f"- `{name}`")
            lines.append("")

        if report.unrouted_pages:
            lines.append("## Unrouted Pages\n")
            lines.append("Page-like components without route definitions:\n")
            for name in sorted(report.unrouted_pages):
                lines.append(f"- `{name}`")
            lines.append("")

        return "\n".join(lines)

    def _render_tree_node(self, node: dict, lines: list[str], indent: int) -> None:
        """Recursively render a component tree node as ASCII."""
        prefix = "  " * indent
        marker = "├── " if indent > 0 else ""
        name = node.get("name", "?")
        file_info = f" ({node['file']})" if node.get("file") else ""
        circular = " [CIRCULAR]" if node.get("circular") else ""
        lines.append(f"{prefix}{marker}**{name}**{file_info}{circular}")

        for child in node.get("children", []):
            self._render_tree_node(child, lines, indent + 1)
