"""KT Video generator — outputs a Remotion project for architecture walkthrough videos.

Generates a ready-to-render Remotion (React) project that animates through:
1. Title slide with project stats
2. Architecture overview (package dependency diagram)
3. Key components spotlight
4. Risk hotspots with blast radius
5. Health assessment summary
6. Recommendations

Usage:
    brain kt-video -o ./my-video
    cd my-video && npm install && npx remotion render KTVideo out/kt.mp4
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.store import GraphStore


class KTVideoGenerator:
    """Generate a Remotion project for KT video rendering."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.comp = ComprehensionEngine(store)

    def generate(
        self,
        output_dir: str | Path,
        *,
        project_name: str | None = None,
        max_hotspots: int = 5,
    ) -> Path:
        """Generate a complete Remotion project directory.

        Args:
            output_dir: Directory to create the project in.
            project_name: Name for the video title.
            max_hotspots: Max hotspots to feature.

        Returns:
            Path to the generated project directory.
        """
        output = Path(output_dir)
        output.mkdir(parents=True, exist_ok=True)
        (output / "src").mkdir(exist_ok=True)
        (output / "public").mkdir(exist_ok=True)

        # Gather data
        overview = self.comp.system_overview()
        narrative = self.comp.system_narrative()
        hotspots = self.comp.risk_hotspots(top_n=max_hotspots)
        health = self.comp.health_score(hotspots=hotspots)

        packages = overview["packages"]

        if not project_name:
            candidates = {
                k: v for k, v in packages.items()
                if k not in ("(root)", "tests", "test", "benchmarks", "docs",
                             "vscode-extension", "node_modules")
            }
            if candidates:
                project_name = max(
                    candidates.items(), key=lambda x: x[1]["node_count"]
                )[0]
            else:
                project_name = "Project"

        # Build props data for the Remotion components
        props = self._build_props(
            project_name, overview, narrative, hotspots, health
        )

        # Write all files
        self._write_package_json(output, project_name)
        self._write_remotion_config(output)
        self._write_index(output)
        self._write_root(output)
        self._write_props(output, props)
        self._write_components(output)
        self._write_styles(output)

        return output

    def _build_props(
        self,
        project_name: str,
        overview: dict,
        narrative: dict,
        hotspots: list[dict],
        health: dict,
    ) -> dict:
        """Build the video props JSON."""
        stats = overview["stats"]
        packages = overview["packages"]

        # Package data for diagram
        pkg_data = []
        for name, info in sorted(packages.items(), key=lambda x: x[1]["node_count"], reverse=True):
            pkg_data.append({
                "name": name,
                "files": info["file_count"],
                "symbols": info["node_count"],
                "depends_on": info.get("depends_on", []),
            })

        # Hotspot data
        hotspot_data = []
        total_files = max(stats.get("files", 1), 1)
        for h in hotspots:
            pct = round(h["affected_files"] / total_files * 100)
            hotspot_data.append({
                "name": h["name"],
                "type": h["type"],
                "risk_score": round(h["risk_score"]),
                "dependents": h["direct_dependents"],
                "blast_radius_pct": pct,
                "file": h["file_path"],
            })

        # Health dimensions
        dims = health.get("dimensions", {})
        dead_dim = dims.get("dead_code", {})
        cycle_dim = dims.get("import_cycles", {})
        coupling_dim = dims.get("coupling", {})

        return {
            "projectName": project_name,
            "generatedAt": datetime.now().strftime("%Y-%m-%d"),
            "stats": {
                "files": stats.get("files", 0),
                "symbols": stats.get("nodes", 0),
                "relationships": stats.get("edges", 0),
                "packages": len(packages),
            },
            "summary": narrative["summary"],
            "architecture": narrative["architecture"],
            "packages": pkg_data,
            "hotspots": hotspot_data,
            "health": {
                "score": health["score"],
                "grade": health["grade"],
                "deadCode": dead_dim.get("score", 0) if isinstance(dead_dim, dict) else 0,
                "cycles": cycle_dim.get("score", 0) if isinstance(cycle_dim, dict) else 0,
                "coupling": coupling_dim.get("score", 0) if isinstance(coupling_dim, dict) else 0,
            },
            "recommendations": narrative.get("recommendations", []),
            "keyComponents": narrative.get("key_components", []),
        }

    def _write_package_json(self, output: Path, name: str) -> None:
        pkg = {
            "name": f"{name.lower()}-kt-video",
            "version": "1.0.0",
            "description": f"KT video for {name} — generated by CodeBrain",
            "scripts": {
                "preview": "npx remotion preview",
                "render": "npx remotion render KTVideo out/kt-video.mp4",
                "render-gif": "npx remotion render KTVideo out/kt-video.gif --image-format=png"
            },
            "dependencies": {
                "@remotion/cli": "4.0.0",
                "react": "^18.2.0",
                "react-dom": "^18.2.0",
                "remotion": "4.0.0",
            },
            "devDependencies": {
                "typescript": "^5.0.0",
                "@types/react": "^18.2.0",
            },
        }
        (output / "package.json").write_text(json.dumps(pkg, indent=2))

    def _write_remotion_config(self, output: Path) -> None:
        (output / "remotion.config.ts").write_text(
            'import {Config} from "@remotion/cli/config";\n'
            "Config.setVideoImageFormat('jpeg');\n"
        )

    def _write_index(self, output: Path) -> None:
        (output / "src" / "index.tsx").write_text(
            'import {registerRoot} from "remotion";\n'
            'import {Root} from "./Root";\n'
            "registerRoot(Root);\n"
        )

    def _write_root(self, output: Path) -> None:
        content = """\
import {Composition} from "remotion";
import {KTVideo} from "./KTVideo";
import {ktProps} from "./props";

export const Root: React.FC = () => {
  // Each scene ~5 seconds at 30fps = 150 frames
  // 6 scenes = 900 frames = 30 seconds
  const totalFrames = 900;

  return (
    <Composition
      id="KTVideo"
      component={KTVideo}
      durationInFrames={totalFrames}
      fps={30}
      width={1920}
      height={1080}
      defaultProps={ktProps}
    />
  );
};
"""
        (output / "src" / "Root.tsx").write_text(content)

    def _write_props(self, output: Path, props: dict) -> None:
        content = (
            f"export const ktProps = {json.dumps(props, indent=2)} as const;\n"
            "\nexport type KTProps = typeof ktProps;\n"
        )
        (output / "src" / "props.ts").write_text(content)

    def _write_components(self, output: Path) -> None:
        """Write the main video component and scene components."""
        # Main video component
        (output / "src" / "KTVideo.tsx").write_text(_KT_VIDEO_COMPONENT)
        # Scene components
        (output / "src" / "scenes").mkdir(exist_ok=True)
        (output / "src" / "scenes" / "TitleScene.tsx").write_text(_TITLE_SCENE)
        (output / "src" / "scenes" / "ArchitectureScene.tsx").write_text(_ARCHITECTURE_SCENE)
        (output / "src" / "scenes" / "HotspotsScene.tsx").write_text(_HOTSPOTS_SCENE)
        (output / "src" / "scenes" / "HealthScene.tsx").write_text(_HEALTH_SCENE)
        (output / "src" / "scenes" / "RecommendationsScene.tsx").write_text(_RECOMMENDATIONS_SCENE)
        (output / "src" / "scenes" / "index.ts").write_text(
            'export {TitleScene} from "./TitleScene";\n'
            'export {ArchitectureScene} from "./ArchitectureScene";\n'
            'export {HotspotsScene} from "./HotspotsScene";\n'
            'export {HealthScene} from "./HealthScene";\n'
            'export {RecommendationsScene} from "./RecommendationsScene";\n'
        )

    def _write_styles(self, output: Path) -> None:
        (output / "src" / "styles.ts").write_text(_STYLES)


# ---------------------------------------------------------------------------
# Component templates
# ---------------------------------------------------------------------------

_STYLES = """\
export const colors = {
  bg: "#0f172a",
  bgLight: "#1e293b",
  primary: "#3b82f6",
  accent: "#10b981",
  warning: "#f59e0b",
  danger: "#ef4444",
  text: "#f8fafc",
  textMuted: "#94a3b8",
  border: "#334155",
};

export const fonts = {
  heading: "Inter, system-ui, sans-serif",
  body: "Inter, system-ui, sans-serif",
  mono: "'JetBrains Mono', 'Fira Code', monospace",
};
"""

_KT_VIDEO_COMPONENT = """\
import {AbsoluteFill, Sequence} from "remotion";
import {TitleScene, ArchitectureScene, HotspotsScene, HealthScene, RecommendationsScene} from "./scenes";
import {colors} from "./styles";

const SCENE_DURATION = 150; // 5 seconds per scene at 30fps

export const KTVideo: React.FC<{
  projectName: string;
  generatedAt: string;
  stats: {files: number; symbols: number; relationships: number; packages: number};
  summary: string;
  architecture: string;
  packages: Array<{name: string; files: number; symbols: number; depends_on: string[]}>;
  hotspots: Array<{name: string; type: string; risk_score: number; dependents: number; blast_radius_pct: number; file: string}>;
  health: {score: number; grade: string; deadCode: number; cycles: number; coupling: number};
  recommendations: string[];
  keyComponents: Array<{name: string; role: string; risk: string; why: string}>;
}> = (props) => {
  return (
    <AbsoluteFill style={{backgroundColor: colors.bg}}>
      <Sequence from={0} durationInFrames={SCENE_DURATION}>
        <TitleScene
          projectName={props.projectName}
          stats={props.stats}
          summary={props.summary}
          generatedAt={props.generatedAt}
        />
      </Sequence>

      <Sequence from={SCENE_DURATION} durationInFrames={SCENE_DURATION}>
        <ArchitectureScene
          packages={props.packages}
          architecture={props.architecture}
        />
      </Sequence>

      <Sequence from={SCENE_DURATION * 2} durationInFrames={SCENE_DURATION}>
        <HotspotsScene
          hotspots={props.hotspots}
          keyComponents={props.keyComponents}
        />
      </Sequence>

      <Sequence from={SCENE_DURATION * 3} durationInFrames={SCENE_DURATION}>
        <HealthScene health={props.health} />
      </Sequence>

      <Sequence from={SCENE_DURATION * 4} durationInFrames={SCENE_DURATION * 2}>
        <RecommendationsScene
          recommendations={props.recommendations}
          projectName={props.projectName}
        />
      </Sequence>
    </AbsoluteFill>
  );
};
"""

_TITLE_SCENE = """\
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {colors, fonts} from "../styles";

export const TitleScene: React.FC<{
  projectName: string;
  stats: {files: number; symbols: number; relationships: number; packages: number};
  summary: string;
  generatedAt: string;
}> = ({projectName, stats, summary, generatedAt}) => {
  const frame = useCurrentFrame();

  const titleOpacity = interpolate(frame, [0, 20], [0, 1], {extrapolateRight: "clamp"});
  const titleY = interpolate(frame, [0, 20], [40, 0], {extrapolateRight: "clamp"});
  const statsOpacity = interpolate(frame, [20, 40], [0, 1], {extrapolateRight: "clamp"});
  const summaryOpacity = interpolate(frame, [50, 70], [0, 1], {extrapolateRight: "clamp"});
  const badgeOpacity = interpolate(frame, [70, 85], [0, 1], {extrapolateRight: "clamp"});

  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        alignItems: "center",
        padding: 80,
        fontFamily: fonts.heading,
      }}
    >
      {/* Title */}
      <div
        style={{
          opacity: titleOpacity,
          transform: `translateY(${titleY}px)`,
          fontSize: 72,
          fontWeight: 800,
          color: colors.text,
          textAlign: "center",
          marginBottom: 20,
        }}
      >
        {projectName}
      </div>

      <div
        style={{
          opacity: titleOpacity,
          fontSize: 28,
          color: colors.primary,
          textAlign: "center",
          marginBottom: 60,
          letterSpacing: 4,
          textTransform: "uppercase",
        }}
      >
        Knowledge Transfer
      </div>

      {/* Stats grid */}
      <div
        style={{
          opacity: statsOpacity,
          display: "flex",
          gap: 40,
          marginBottom: 50,
        }}
      >
        {[
          {label: "Files", value: stats.files},
          {label: "Symbols", value: stats.symbols},
          {label: "Relationships", value: stats.relationships},
          {label: "Packages", value: stats.packages},
        ].map((stat) => (
          <div
            key={stat.label}
            style={{
              textAlign: "center",
              padding: "20px 30px",
              background: colors.bgLight,
              borderRadius: 12,
              border: `1px solid ${colors.border}`,
            }}
          >
            <div style={{fontSize: 48, fontWeight: 700, color: colors.accent}}>
              {stat.value.toLocaleString()}
            </div>
            <div style={{fontSize: 18, color: colors.textMuted, marginTop: 4}}>
              {stat.label}
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div
        style={{
          opacity: summaryOpacity,
          fontSize: 22,
          color: colors.textMuted,
          textAlign: "center",
          maxWidth: 900,
          lineHeight: 1.6,
        }}
      >
        {summary}
      </div>

      {/* CodeBrain badge */}
      <div
        style={{
          opacity: badgeOpacity,
          position: "absolute",
          bottom: 40,
          right: 60,
          fontSize: 16,
          color: colors.textMuted,
          fontFamily: fonts.mono,
        }}
      >
        Generated by CodeBrain \u00b7 {generatedAt}
      </div>
    </AbsoluteFill>
  );
};
"""

_ARCHITECTURE_SCENE = """\
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {colors, fonts} from "../styles";

export const ArchitectureScene: React.FC<{
  packages: Array<{name: string; files: number; symbols: number; depends_on: string[]}>;
  architecture: string;
}> = ({packages, architecture}) => {
  const frame = useCurrentFrame();
  const headerOpacity = interpolate(frame, [0, 15], [0, 1], {extrapolateRight: "clamp"});

  // Calculate layout positions for packages in a grid
  const cols = Math.min(packages.length, 3);
  const rows = Math.ceil(packages.length / cols);

  return (
    <AbsoluteFill
      style={{
        padding: 80,
        fontFamily: fonts.heading,
      }}
    >
      <div
        style={{
          opacity: headerOpacity,
          fontSize: 48,
          fontWeight: 700,
          color: colors.text,
          marginBottom: 50,
        }}
      >
        Architecture Overview
      </div>

      {/* Package boxes */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 24,
          justifyContent: "center",
          alignItems: "flex-start",
        }}
      >
        {packages.map((pkg, i) => {
          const delay = 15 + i * 10;
          const opacity = interpolate(frame, [delay, delay + 15], [0, 1], {extrapolateRight: "clamp"});
          const scale = interpolate(frame, [delay, delay + 15], [0.8, 1], {extrapolateRight: "clamp"});

          // Size based on symbol count
          const maxSymbols = Math.max(...packages.map((p) => p.symbols));
          const relSize = pkg.symbols / maxSymbols;
          const boxWidth = 220 + relSize * 180;

          return (
            <div
              key={pkg.name}
              style={{
                opacity,
                transform: `scale(${scale})`,
                background: colors.bgLight,
                border: `2px solid ${colors.primary}`,
                borderRadius: 16,
                padding: 24,
                width: boxWidth,
                textAlign: "center",
              }}
            >
              <div
                style={{
                  fontSize: 24,
                  fontWeight: 600,
                  color: colors.text,
                  marginBottom: 8,
                  fontFamily: fonts.mono,
                }}
              >
                {pkg.name}
              </div>
              <div style={{fontSize: 36, fontWeight: 700, color: colors.accent}}>
                {pkg.symbols}
              </div>
              <div style={{fontSize: 14, color: colors.textMuted}}>
                symbols in {pkg.files} files
              </div>
              {pkg.depends_on.length > 0 && (
                <div
                  style={{
                    fontSize: 12,
                    color: colors.warning,
                    marginTop: 8,
                  }}
                >
                  depends on: {pkg.depends_on.join(", ")}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Architecture description */}
      <div
        style={{
          opacity: interpolate(frame, [80, 100], [0, 1], {extrapolateRight: "clamp"}),
          position: "absolute",
          bottom: 60,
          left: 80,
          right: 80,
          fontSize: 18,
          color: colors.textMuted,
          textAlign: "center",
          lineHeight: 1.5,
        }}
      >
        {architecture}
      </div>
    </AbsoluteFill>
  );
};
"""

_HOTSPOTS_SCENE = """\
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {colors, fonts} from "../styles";

export const HotspotsScene: React.FC<{
  hotspots: Array<{name: string; type: string; risk_score: number; dependents: number; blast_radius_pct: number; file: string}>;
  keyComponents: Array<{name: string; role: string; risk: string; why: string}>;
}> = ({hotspots}) => {
  const frame = useCurrentFrame();
  const headerOpacity = interpolate(frame, [0, 15], [0, 1], {extrapolateRight: "clamp"});

  return (
    <AbsoluteFill
      style={{
        padding: 80,
        fontFamily: fonts.heading,
      }}
    >
      <div
        style={{
          opacity: headerOpacity,
          fontSize: 48,
          fontWeight: 700,
          color: colors.text,
          marginBottom: 20,
        }}
      >
        Risk Hotspots
      </div>
      <div
        style={{
          opacity: headerOpacity,
          fontSize: 20,
          color: colors.textMuted,
          marginBottom: 40,
        }}
      >
        Changes here have the widest blast radius
      </div>

      {/* Hotspot bars */}
      <div style={{display: "flex", flexDirection: "column", gap: 16}}>
        {hotspots.map((h, i) => {
          const delay = 15 + i * 15;
          const opacity = interpolate(frame, [delay, delay + 10], [0, 1], {extrapolateRight: "clamp"});
          const barWidth = interpolate(
            frame,
            [delay + 5, delay + 20],
            [0, h.blast_radius_pct],
            {extrapolateRight: "clamp"}
          );

          const riskColor =
            h.risk_score > 20 ? colors.danger : h.risk_score > 5 ? colors.warning : colors.accent;

          return (
            <div key={h.name} style={{opacity}}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 6,
                }}
              >
                <div style={{display: "flex", alignItems: "center", gap: 12}}>
                  <span
                    style={{
                      fontFamily: fonts.mono,
                      fontSize: 22,
                      fontWeight: 600,
                      color: colors.text,
                    }}
                  >
                    {h.name}
                  </span>
                  <span
                    style={{
                      fontSize: 14,
                      color: colors.textMuted,
                      background: colors.bgLight,
                      padding: "2px 8px",
                      borderRadius: 4,
                    }}
                  >
                    {h.type}
                  </span>
                </div>
                <div style={{fontSize: 16, color: colors.textMuted}}>
                  {h.dependents} dependents \u00b7 risk: {h.risk_score}
                </div>
              </div>

              {/* Bar */}
              <div
                style={{
                  height: 28,
                  background: colors.bgLight,
                  borderRadius: 8,
                  overflow: "hidden",
                  position: "relative",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${barWidth}%`,
                    background: riskColor,
                    borderRadius: 8,
                    display: "flex",
                    alignItems: "center",
                    paddingLeft: 12,
                  }}
                >
                  <span
                    style={{
                      fontSize: 14,
                      fontWeight: 600,
                      color: colors.bg,
                    }}
                  >
                    {h.blast_radius_pct}% blast radius
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
"""

_HEALTH_SCENE = """\
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {colors, fonts} from "../styles";

export const HealthScene: React.FC<{
  health: {score: number; grade: string; deadCode: number; cycles: number; coupling: number};
}> = ({health}) => {
  const frame = useCurrentFrame();
  const headerOpacity = interpolate(frame, [0, 15], [0, 1], {extrapolateRight: "clamp"});

  // Animate the score counter
  const displayScore = Math.round(
    interpolate(frame, [20, 60], [0, health.score], {extrapolateRight: "clamp"})
  );

  const gradeColor =
    health.grade === "A"
      ? colors.accent
      : health.grade === "B"
      ? colors.primary
      : health.grade === "C"
      ? colors.warning
      : colors.danger;

  const dimensions = [
    {label: "Dead Code", score: health.deadCode, icon: "\\u2620\\ufe0f"},
    {label: "Import Cycles", score: health.cycles, icon: "\\ud83d\\udd04"},
    {label: "Coupling", score: health.coupling, icon: "\\ud83d\\udd17"},
  ];

  return (
    <AbsoluteFill
      style={{
        padding: 80,
        fontFamily: fonts.heading,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div
        style={{
          opacity: headerOpacity,
          fontSize: 48,
          fontWeight: 700,
          color: colors.text,
          marginBottom: 50,
          position: "absolute",
          top: 80,
          left: 80,
        }}
      >
        Health Assessment
      </div>

      {/* Big score circle */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          marginBottom: 60,
        }}
      >
        <div
          style={{
            width: 220,
            height: 220,
            borderRadius: "50%",
            border: `6px solid ${gradeColor}`,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            background: colors.bgLight,
          }}
        >
          <div style={{fontSize: 72, fontWeight: 800, color: gradeColor}}>
            {displayScore}
          </div>
          <div style={{fontSize: 24, color: colors.textMuted}}>/100</div>
        </div>
        <div
          style={{
            marginTop: 16,
            fontSize: 36,
            fontWeight: 700,
            color: gradeColor,
          }}
        >
          Grade {health.grade}
        </div>
      </div>

      {/* Dimension bars */}
      <div style={{display: "flex", gap: 40, width: "80%", justifyContent: "center"}}>
        {dimensions.map((dim, i) => {
          const delay = 60 + i * 15;
          const opacity = interpolate(frame, [delay, delay + 10], [0, 1], {extrapolateRight: "clamp"});
          const barHeight = interpolate(
            frame,
            [delay + 5, delay + 20],
            [0, dim.score],
            {extrapolateRight: "clamp"}
          );

          const barColor = dim.score >= 80 ? colors.accent : dim.score >= 50 ? colors.warning : colors.danger;

          return (
            <div key={dim.label} style={{opacity, textAlign: "center", flex: 1}}>
              <div style={{fontSize: 28, marginBottom: 8}}>{dim.icon}</div>
              <div
                style={{
                  height: 120,
                  background: colors.bgLight,
                  borderRadius: 8,
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "flex-end",
                  overflow: "hidden",
                  marginBottom: 8,
                }}
              >
                <div
                  style={{
                    height: `${barHeight}%`,
                    background: barColor,
                    borderRadius: 8,
                    transition: "height 0.3s",
                  }}
                />
              </div>
              <div style={{fontSize: 18, color: colors.text, fontWeight: 600}}>
                {dim.label}
              </div>
              <div style={{fontSize: 24, color: barColor, fontWeight: 700}}>
                {dim.score}/100
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
"""

_RECOMMENDATIONS_SCENE = """\
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {colors, fonts} from "../styles";

export const RecommendationsScene: React.FC<{
  recommendations: string[];
  projectName: string;
}> = ({recommendations, projectName}) => {
  const frame = useCurrentFrame();
  const headerOpacity = interpolate(frame, [0, 15], [0, 1], {extrapolateRight: "clamp"});

  return (
    <AbsoluteFill
      style={{
        padding: 80,
        fontFamily: fonts.heading,
        justifyContent: "center",
      }}
    >
      <div
        style={{
          opacity: headerOpacity,
          fontSize: 48,
          fontWeight: 700,
          color: colors.text,
          marginBottom: 50,
        }}
      >
        Recommendations
      </div>

      <div style={{display: "flex", flexDirection: "column", gap: 24}}>
        {recommendations.map((rec, i) => {
          const delay = 20 + i * 20;
          const opacity = interpolate(frame, [delay, delay + 15], [0, 1], {extrapolateRight: "clamp"});
          const x = interpolate(frame, [delay, delay + 15], [30, 0], {extrapolateRight: "clamp"});

          return (
            <div
              key={i}
              style={{
                opacity,
                transform: `translateX(${x}px)`,
                display: "flex",
                alignItems: "flex-start",
                gap: 20,
                padding: 24,
                background: colors.bgLight,
                borderRadius: 12,
                borderLeft: `4px solid ${colors.primary}`,
              }}
            >
              <div
                style={{
                  fontSize: 28,
                  fontWeight: 700,
                  color: colors.primary,
                  minWidth: 40,
                }}
              >
                {i + 1}.
              </div>
              <div style={{fontSize: 22, color: colors.text, lineHeight: 1.5}}>
                {rec}
              </div>
            </div>
          );
        })}
      </div>

      {/* End card */}
      <div
        style={{
          opacity: interpolate(frame, [120, 140], [0, 1], {extrapolateRight: "clamp"}),
          position: "absolute",
          bottom: 80,
          left: 0,
          right: 0,
          textAlign: "center",
        }}
      >
        <div style={{fontSize: 20, color: colors.textMuted}}>
          Generated by CodeBrain for {projectName}
        </div>
      </div>
    </AbsoluteFill>
  );
};
"""
