"""Environment migration — analyze and generate infrastructure files.

Reads requirements.txt, package.json, Dockerfile, .env, CI configs from an
existing project and generates equivalent infrastructure files for a target
language/stack.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Dependency:
    name: str
    version: str = ""
    dev: bool = False


@dataclass
class EnvironmentProfile:
    language: str  # detected source language
    dependencies: list[Dependency] = field(default_factory=list)
    env_vars: list[tuple[str, str]] = field(default_factory=list)
    has_dockerfile: bool = False
    dockerfile_base_image: str = ""
    dockerfile_port: int = 0
    has_docker_compose: bool = False
    docker_services: list[str] = field(default_factory=list)
    ci_platform: str = ""
    ci_file: str = ""


@dataclass
class GeneratedFile:
    path: str  # relative output path
    content: str
    description: str  # what this file is for


# ---------------------------------------------------------------------------
# Dockerfile templates
# ---------------------------------------------------------------------------

DOCKERFILE_TEMPLATES: dict[str, str] = {
    "go": """FROM golang:1.21-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 go build -o /app/server ./...

FROM alpine:3.19
COPY --from=builder /app/server /server
EXPOSE {port}
CMD ["/server"]
""",
    "rust": """FROM rust:1.75 AS builder
WORKDIR /app
COPY Cargo.toml Cargo.lock ./
COPY src/ src/
RUN cargo build --release

FROM debian:bookworm-slim
COPY --from=builder /app/target/release/app /app
EXPOSE {port}
CMD ["/app"]
""",
    "java": """FROM eclipse-temurin:21-jdk AS builder
WORKDIR /app
COPY pom.xml .
RUN mvn dependency:resolve
COPY src/ src/
RUN mvn package -DskipTests

FROM eclipse-temurin:21-jre
COPY --from=builder /app/target/*.jar /app.jar
EXPOSE {port}
CMD ["java", "-jar", "/app.jar"]
""",
    "typescript": """FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-alpine
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
EXPOSE {port}
CMD ["node", "dist/index.js"]
""",
}

# ---------------------------------------------------------------------------
# CI templates
# ---------------------------------------------------------------------------

_GITHUB_ACTIONS_TEMPLATES: dict[str, str] = {
    "go": """name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with:
          go-version: '1.21'
      - run: go build ./...
      - run: go test ./...
""",
    "rust": """name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: dtolnay/rust-toolchain@stable
      - run: cargo build
      - run: cargo test
""",
    "java": """name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '21'
      - run: mvn package
""",
    "typescript": """name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci
      - run: npm run build
      - run: npm test
""",
}

_GITLAB_CI_TEMPLATES: dict[str, str] = {
    "go": """stages:
  - build
  - test

build:
  stage: build
  image: golang:1.21
  script:
    - go build ./...

test:
  stage: test
  image: golang:1.21
  script:
    - go test ./...
""",
    "rust": """stages:
  - build
  - test

build:
  stage: build
  image: rust:1.75
  script:
    - cargo build

test:
  stage: test
  image: rust:1.75
  script:
    - cargo test
""",
    "java": """stages:
  - build

build:
  stage: build
  image: eclipse-temurin:21-jdk
  script:
    - mvn package
""",
    "typescript": """stages:
  - build
  - test

build:
  stage: build
  image: node:20
  script:
    - npm ci
    - npm run build

test:
  stage: test
  image: node:20
  script:
    - npm ci
    - npm test
""",
}


# ---------------------------------------------------------------------------
# EnvironmentMigrator
# ---------------------------------------------------------------------------

class EnvironmentMigrator:
    """Analyze existing project infrastructure and generate configs for a target language."""

    def __init__(self, store=None):
        self.store = store

    # ----- analyze ----------------------------------------------------------

    def analyze(self, project_dir: Path) -> EnvironmentProfile:
        """Analyze existing project infrastructure."""
        project_dir = Path(project_dir)
        language = ""
        dependencies: list[Dependency] = []
        env_vars: list[tuple[str, str]] = []
        has_dockerfile = False
        dockerfile_base_image = ""
        dockerfile_port = 0
        has_docker_compose = False
        docker_services: list[str] = []
        ci_platform = ""
        ci_file = ""

        # Detect language + dependencies
        req_txt = project_dir / "requirements.txt"
        pkg_json = project_dir / "package.json"

        if req_txt.is_file():
            language = "python"
            dependencies = self._parse_requirements(req_txt)
        elif pkg_json.is_file():
            language = "javascript"
            dependencies = self._parse_package_json(pkg_json)

        # Dockerfile
        dockerfile = project_dir / "Dockerfile"
        if dockerfile.is_file():
            has_dockerfile = True
            dockerfile_base_image, dockerfile_port = self._parse_dockerfile(dockerfile)

        # docker-compose
        compose = project_dir / "docker-compose.yml"
        if not compose.is_file():
            compose = project_dir / "docker-compose.yaml"
        if compose.is_file():
            has_docker_compose = True
            docker_services = self._parse_compose_services(compose)

        # CI
        ci_platform, ci_file = self._detect_ci(project_dir)

        # .env
        env_file = project_dir / ".env"
        if env_file.is_file():
            env_vars = self._parse_env_file(env_file)

        return EnvironmentProfile(
            language=language,
            dependencies=dependencies,
            env_vars=env_vars,
            has_dockerfile=has_dockerfile,
            dockerfile_base_image=dockerfile_base_image,
            dockerfile_port=dockerfile_port,
            has_docker_compose=has_docker_compose,
            docker_services=docker_services,
            ci_platform=ci_platform,
            ci_file=ci_file,
        )

    # ----- generate ---------------------------------------------------------

    def generate(
        self,
        profile: EnvironmentProfile,
        target_lang: str,
        target_stack: str = "",
        output_dir: Path | None = None,
    ) -> list[GeneratedFile]:
        """Generate infrastructure files for the target language."""
        files: list[GeneratedFile] = []

        # Dependency file
        dep = self._generate_dep_file(profile, target_lang)
        if dep:
            files.append(dep)

        # Dockerfile
        if profile.has_dockerfile or True:  # Always generate Dockerfile
            files.append(self._generate_dockerfile(profile, target_lang))

        # CI
        ci = self._generate_ci(profile, target_lang)
        if ci:
            files.append(ci)

        # .env
        if profile.env_vars:
            files.append(self._generate_env(profile))

        # Write to disk if output_dir provided
        if output_dir:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            for gf in files:
                out_path = output_dir / gf.path
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(gf.content, encoding="utf-8")

        return files

    # ----- private generators -----------------------------------------------

    def _generate_dep_file(
        self, profile: EnvironmentProfile, target_lang: str
    ) -> GeneratedFile | None:
        """Generate skeleton dependency file."""
        if target_lang == "go":
            return GeneratedFile(
                path="go.mod",
                content="module translated\n\ngo 1.21\n\n// TODO: add dependencies after translation\n",
                description="Go module file (skeleton — add deps after translation)",
            )
        if target_lang == "rust":
            return GeneratedFile(
                path="Cargo.toml",
                content=(
                    '[package]\nname = "translated"\nversion = "0.1.0"\n'
                    'edition = "2021"\n\n[dependencies]\n'
                    "# TODO: add dependencies after translation\n"
                ),
                description="Cargo manifest (skeleton — add deps after translation)",
            )
        if target_lang == "java":
            return GeneratedFile(
                path="pom.xml",
                content=(
                    '<?xml version="1.0" encoding="UTF-8"?>\n'
                    "<project>\n"
                    "  <modelVersion>4.0.0</modelVersion>\n"
                    "  <groupId>com.translated</groupId>\n"
                    "  <artifactId>translated</artifactId>\n"
                    "  <version>0.1.0</version>\n"
                    "  <properties>\n"
                    "    <maven.compiler.source>21</maven.compiler.source>\n"
                    "    <maven.compiler.target>21</maven.compiler.target>\n"
                    "  </properties>\n"
                    "  <dependencies>\n"
                    "    <!-- TODO: add dependencies after translation -->\n"
                    "  </dependencies>\n"
                    "</project>\n"
                ),
                description="Maven POM (skeleton — add deps after translation)",
            )
        if target_lang == "typescript":
            return GeneratedFile(
                path="package.json",
                content=(
                    '{\n  "name": "translated",\n  "version": "0.1.0",\n'
                    '  "scripts": {\n    "build": "tsc",\n    "start": "node dist/index.js"\n'
                    "  },\n"
                    '  "dependencies": {},\n'
                    '  "devDependencies": {\n    "typescript": "^5.0.0"\n  }\n}\n'
                ),
                description="package.json (skeleton — add deps after translation)",
            )
        return None

    def _generate_dockerfile(
        self, profile: EnvironmentProfile, target_lang: str
    ) -> GeneratedFile:
        """Generate multi-stage Dockerfile for target language."""
        port = profile.dockerfile_port if profile.dockerfile_port else 8080
        template = DOCKERFILE_TEMPLATES.get(target_lang, DOCKERFILE_TEMPLATES.get("go", ""))
        content = template.format(port=port)
        return GeneratedFile(
            path="Dockerfile",
            content=content,
            description=f"Multi-stage Dockerfile for {target_lang}",
        )

    def _generate_ci(
        self, profile: EnvironmentProfile, target_lang: str
    ) -> GeneratedFile | None:
        """Generate CI/CD pipeline matching original triggers."""
        if profile.ci_platform == "github_actions":
            tmpl = _GITHUB_ACTIONS_TEMPLATES.get(target_lang)
            if tmpl:
                return GeneratedFile(
                    path=".github/workflows/ci.yml",
                    content=tmpl,
                    description=f"GitHub Actions workflow for {target_lang}",
                )
        elif profile.ci_platform == "gitlab_ci":
            tmpl = _GITLAB_CI_TEMPLATES.get(target_lang)
            if tmpl:
                return GeneratedFile(
                    path=".gitlab-ci.yml",
                    content=tmpl,
                    description=f"GitLab CI pipeline for {target_lang}",
                )
        return None

    def _generate_env(self, profile: EnvironmentProfile) -> GeneratedFile:
        """Copy .env variables to output (language-agnostic)."""
        lines = [f"{key}={value}" for key, value in profile.env_vars]
        return GeneratedFile(
            path=".env",
            content="\n".join(lines) + "\n" if lines else "",
            description="Environment variables (copied from original)",
        )

    # ----- private parsers --------------------------------------------------

    @staticmethod
    def _parse_requirements(path: Path) -> list[Dependency]:
        deps = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            m = re.match(r"^([A-Za-z0-9_.-]+)\s*(?:[><=!~]+\s*(.+))?", line)
            if m:
                deps.append(Dependency(name=m.group(1), version=m.group(2) or ""))
        return deps

    @staticmethod
    def _parse_package_json(path: Path) -> list[Dependency]:
        import json as _json

        deps = []
        try:
            data = _json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return deps
        for name, ver in data.get("dependencies", {}).items():
            deps.append(Dependency(name=name, version=ver))
        for name, ver in data.get("devDependencies", {}).items():
            deps.append(Dependency(name=name, version=ver, dev=True))
        return deps

    @staticmethod
    def _parse_dockerfile(path: Path) -> tuple[str, int]:
        """Return (base_image, expose_port) from a Dockerfile."""
        base_image = ""
        port = 0
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.upper().startswith("FROM ") and not base_image:
                base_image = line.split()[1] if len(line.split()) > 1 else ""
            m = re.match(r"^EXPOSE\s+(\d+)", line, re.IGNORECASE)
            if m:
                port = int(m.group(1))
        return base_image, port

    @staticmethod
    def _parse_compose_services(path: Path) -> list[str]:
        """Extract service names from docker-compose.yml (simple regex)."""
        services = []
        in_services = False
        for line in path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped == "services:":
                in_services = True
                continue
            if in_services:
                # top-level key under services: (2-space indent, no further indent)
                if line and not line.startswith(" "):
                    break  # left services block
                m = re.match(r"^  ([a-zA-Z0-9_-]+):", line)
                if m:
                    services.append(m.group(1))
        return services

    @staticmethod
    def _detect_ci(project_dir: Path) -> tuple[str, str]:
        gh_dir = project_dir / ".github" / "workflows"
        if gh_dir.is_dir():
            ymls = list(gh_dir.glob("*.yml")) + list(gh_dir.glob("*.yaml"))
            return "github_actions", str(ymls[0].name) if ymls else ""
        if (project_dir / ".gitlab-ci.yml").exists():
            return "gitlab_ci", ".gitlab-ci.yml"
        if (project_dir / "Jenkinsfile").exists():
            return "jenkins", "Jenkinsfile"
        return "", ""

    @staticmethod
    def _parse_env_file(path: Path) -> list[tuple[str, str]]:
        env_vars = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, _, value = line.partition("=")
                env_vars.append((key.strip(), value.strip()))
        return env_vars

    def to_dict(self, profile: EnvironmentProfile) -> dict:
        """Serialize profile to a JSON-safe dict."""
        return {
            "language": profile.language,
            "dependencies": [
                {"name": d.name, "version": d.version, "dev": d.dev}
                for d in profile.dependencies
            ],
            "env_vars": [{"key": k, "value": v} for k, v in profile.env_vars],
            "has_dockerfile": profile.has_dockerfile,
            "dockerfile_base_image": profile.dockerfile_base_image,
            "dockerfile_port": profile.dockerfile_port,
            "has_docker_compose": profile.has_docker_compose,
            "docker_services": profile.docker_services,
            "ci_platform": profile.ci_platform,
            "ci_file": profile.ci_file,
        }
