"""Allow running as `python -m codebrain`."""

from codebrain.cli import cli

if __name__ == "__main__":
    cli()
