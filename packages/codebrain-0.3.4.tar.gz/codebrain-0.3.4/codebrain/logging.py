"""Structured logging for CodeBrain — stdlib only."""

from __future__ import annotations

import logging
import sys

_configured = False


def get_logger(name: str) -> logging.Logger:
    """Return a logger under the ``codebrain`` namespace."""
    return logging.getLogger(f"codebrain.{name}")


def configure_logging(verbose: bool = False) -> None:
    """Set up the root ``codebrain`` logger.

    * Normal mode  — WARNING and above to stderr.
    * Verbose mode — DEBUG and above, with timestamps.
    """
    global _configured
    if _configured:
        return
    _configured = True

    root = logging.getLogger("codebrain")
    root.setLevel(logging.DEBUG if verbose else logging.WARNING)

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(logging.DEBUG if verbose else logging.WARNING)

    if verbose:
        fmt = logging.Formatter(
            "%(asctime)s %(name)s %(levelname)s  %(message)s",
            datefmt="%H:%M:%S",
        )
    else:
        fmt = logging.Formatter("%(levelname)s: %(message)s")

    handler.setFormatter(fmt)
    root.addHandler(handler)
