"""LLM context generator.

Instead of an LLM agent grepping fragments, this module produces
structured context for any symbol — everything the agent needs to
reason about it without scanning the repo.

The output is a JSON-serializable dict designed to be injected into
an LLM's context window as structured knowledge.
"""

from __future__ import annotations

import json
from codebrain.comprehension import _GENERIC_NAMES
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore


class ContextGenerator:
    """Generates structured context for LLM consumption."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.engine = QueryEngine(store)

    def for_symbol(self, name: str) -> list[dict]:
        """Generate full context for every node matching *name*.

        Returns a list (one per match) of context dicts.
        """
        nodes = self.engine.resolve_node(name)
        return [self._build_symbol_context(node) for node in nodes]

    def for_file(self, file_path: str) -> dict:
        """Generate context for an entire file."""
        nodes = self.store.get_nodes_by_file(file_path)
        if not nodes:
            return {"error": f"No indexed file: {file_path}"}

        # Pre-build cache for bulk node lookups
        all_nodes = self.store.get_all_nodes()
        cache = {"node_by_id": {n["id"]: n for n in all_nodes}}

        file_node = None
        symbols: list[dict] = []
        for n in nodes:
            if n["type"] == "file":
                file_node = n
            else:
                symbols.append(self._build_symbol_context(n, _cache=cache))

        imports = self.engine.get_file_dependencies(file_path)

        # Who depends on this file — batch lookup via all edges
        all_edges = self.store.get_all_edges()
        node_ids = {n["id"] for n in nodes}
        node_names = {n["name"] for n in nodes}
        node_qnames = {n["qualified_name"] for n in nodes}
        dependents: list[dict] = []
        seen_deps: set[tuple] = set()
        for e in all_edges:
            if e["type"] in ("CALLS", "IMPORTS") and e["file_path"] != file_path:
                # Match by node ID or qualified name (always safe)
                if e["target"] in node_ids or e["target"] in node_qnames:
                    matched = True
                elif e["target"] in node_names and e["target"] not in _GENERIC_NAMES:
                    # Bare-name match — skip generic names to avoid over-counting
                    matched = True
                else:
                    matched = False
                if matched:
                    key = (e["source"], e["target"], e["line"])
                    if key not in seen_deps:
                        seen_deps.add(key)
                        dependents.append({
                            "source": e["source"],
                            "type": e["type"],
                            "file_path": e["file_path"],
                            "line": e["line"],
                        })

        return {
            "type": "file_context",
            "file_path": file_path,
            "docstring": file_node["docstring"] if file_node else "",
            "imports": imports,
            "symbols": symbols,
            "external_dependents": dependents,
        }

    def for_task(self, description: str, relevant_names: list[str]) -> dict:
        """Generate task-focused context.

        Given a task description and a list of symbol names the agent
        thinks are relevant, produce a combined context package.
        """
        # Pre-build cache for bulk node lookups
        all_nodes = self.store.get_all_nodes()
        cache = {"node_by_id": {n["id"]: n for n in all_nodes}}
        node_by_id = cache["node_by_id"]

        symbol_contexts: list[dict] = []
        seen_files: set[str] = set()
        affected_files: set[str] = set()

        for name in relevant_names:
            nodes = self.engine.resolve_node(name)
            for node in nodes:
                ctx = self._build_symbol_context(node, _cache=cache)
                symbol_contexts.append(ctx)
                seen_files.add(node["file_path"])

                # Gather affected files — use cache for file resolution
                impacted = self.engine.impact_of_change(node["id"], max_depth=3)
                for entry in impacted:
                    target = node_by_id.get(entry["node_id"])
                    if target:
                        affected_files.add(target["file_path"])

        return {
            "type": "task_context",
            "task_description": description,
            "symbols": symbol_contexts,
            "directly_involved_files": sorted(seen_files),
            "potentially_affected_files": sorted(affected_files - seen_files),
            "guidance": self._generate_guidance(symbol_contexts),
        }

    def _build_symbol_context(self, node: dict, _cache: dict | None = None) -> dict:
        """Build complete context for a single node.

        Optionally accepts a _cache dict with pre-fetched 'node_by_id' and
        'all_edges' to avoid repeated DB queries when called in a loop.
        """
        node_id = node["id"]

        # Use cache if provided, else fetch per-node (single-symbol case)
        if _cache and "node_by_id" in _cache:
            node_by_id = _cache["node_by_id"]
        else:
            node_by_id = None

        # Outgoing edges (what this symbol uses)
        outgoing = self.store.get_edges_from(node_id)
        calls = [e for e in outgoing if e["type"] == "CALLS"]
        imports = [e for e in outgoing if e["type"] == "IMPORTS"]

        # Incoming edges (what uses this symbol)
        incoming = self.store.get_edges_to_symbol(node_id, node["name"], node["qualified_name"])
        callers = [e for e in incoming if e["type"] in ("CALLS", "IMPORTS")]
        contains = [e for e in incoming if e["type"] == "CONTAINS"]

        # Parent (class or file that contains this)
        parent = None
        for e in contains:
            if node_by_id:
                parent_node = node_by_id.get(e["source"])
            else:
                parent_node = self.store.get_node(e["source"])
            if parent_node:
                parent = {
                    "id": parent_node["id"],
                    "name": parent_node["name"],
                    "type": parent_node["type"],
                }
                break

        # Siblings (other symbols in same parent)
        siblings: list[dict] = []
        if parent:
            parent_outgoing = self.store.get_edges_from(parent["id"])
            for e in parent_outgoing:
                if e["type"] == "CONTAINS" and e["target"] != node_id:
                    if node_by_id:
                        sibling = node_by_id.get(e["target"])
                    else:
                        sibling = self.store.get_node(e["target"])
                    if sibling:
                        siblings.append({
                            "name": sibling["name"],
                            "type": sibling["type"],
                            "signature": sibling["signature"],
                        })

        # Class methods (if this is a class)
        methods: list[dict] = []
        if node["type"] == "class":
            class_outgoing = self.store.get_edges_from(node_id)
            for e in class_outgoing:
                if e["type"] == "CONTAINS":
                    if node_by_id:
                        method = node_by_id.get(e["target"])
                    else:
                        method = self.store.get_node(e["target"])
                    if method:
                        methods.append({
                            "name": method["name"],
                            "type": method["type"],
                            "signature": method["signature"],
                            "docstring": method["docstring"],
                        })

        # Base classes (if this is a class)
        bases: list[str] = []
        if node["type"] == "class":
            for e in outgoing:
                if e["type"] == "EXTENDS":
                    bases.append(e["target"])

        decorators = node["decorators"]
        if isinstance(decorators, str):
            try:
                decorators = json.loads(decorators)
            except (json.JSONDecodeError, TypeError):
                decorators = []

        return {
            "type": "symbol_context",
            "id": node_id,
            "name": node["name"],
            "qualified_name": node["qualified_name"],
            "symbol_type": node["type"],
            "file_path": node["file_path"],
            "line_start": node["line_start"],
            "line_end": node["line_end"],
            "signature": node["signature"],
            "docstring": node["docstring"],
            "summary": node.get("summary", ""),
            "decorators": decorators,
            "is_exported": bool(node["is_exported"]),
            "parent": parent,
            "siblings": siblings,
            "calls": [{"target": e["target"], "line": e["line"]} for e in calls],
            "imports": [{"target": e["target"], "line": e["line"]} for e in imports],
            "called_by": [
                {"source": e["source"], "file_path": e["file_path"], "line": e["line"]}
                for e in callers
            ],
            "methods": methods if methods else None,
            "bases": bases if bases else None,
        }

    def _generate_guidance(self, symbol_contexts: list[dict]) -> list[str]:
        """Produce actionable guidance from the context."""
        guidance: list[str] = []

        high_dep_symbols = [
            s for s in symbol_contexts
            if len(s.get("called_by", [])) > 3
        ]
        if high_dep_symbols:
            names = ", ".join(s["name"] for s in high_dep_symbols)
            guidance.append(
                f"High-dependency symbols ({names}) — changes here affect multiple callers. "
                f"Validate all call sites after modification."
            )

        exported = [s for s in symbol_contexts if s.get("is_exported")]
        if exported:
            names = ", ".join(s["name"] for s in exported)
            guidance.append(
                f"Exported symbols ({names}) — part of the module's public API. "
                f"Signature changes may break external consumers."
            )

        cross_file_deps = set()
        for s in symbol_contexts:
            for caller in s.get("called_by", []):
                if caller["file_path"] != s["file_path"]:
                    cross_file_deps.add(caller["file_path"])
        if cross_file_deps:
            guidance.append(
                f"Cross-file dependencies detected from: {', '.join(sorted(cross_file_deps))}. "
                f"Test these files after changes."
            )

        return guidance
