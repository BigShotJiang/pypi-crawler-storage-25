"""MemoryStore — persistent structured memory backed by SQLite + FTS5."""

from __future__ import annotations

import json
import sqlite3
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from codebrain.logging import get_logger

_log = get_logger("memory")

_SCHEMA_SQL = """\
CREATE TABLE IF NOT EXISTS memories (
    id         TEXT PRIMARY KEY,
    content    TEXT NOT NULL,
    category   TEXT NOT NULL,
    tags       TEXT NOT NULL DEFAULT '[]',
    confidence REAL NOT NULL DEFAULT 1.0,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    expires_at REAL,
    source     TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_mem_category ON memories(category);
CREATE INDEX IF NOT EXISTS idx_mem_created ON memories(created_at DESC);
"""

_FTS_SQL = """\
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
    content, category, tags, content=memories, content_rowid=rowid
);
"""

_TRIGGERS_SQL = """\
CREATE TRIGGER IF NOT EXISTS memory_ai AFTER INSERT ON memories BEGIN
    INSERT INTO memory_fts(rowid, content, category, tags)
    VALUES (NEW.rowid, NEW.content, NEW.category, NEW.tags);
END;
CREATE TRIGGER IF NOT EXISTS memory_ad AFTER DELETE ON memories BEGIN
    INSERT INTO memory_fts(memory_fts, rowid, content, category, tags)
    VALUES ('delete', OLD.rowid, OLD.content, OLD.category, OLD.tags);
END;
CREATE TRIGGER IF NOT EXISTS memory_au AFTER UPDATE ON memories BEGIN
    INSERT INTO memory_fts(memory_fts, rowid, content, category, tags)
    VALUES ('delete', OLD.rowid, OLD.content, OLD.category, OLD.tags);
    INSERT INTO memory_fts(rowid, content, category, tags)
    VALUES (NEW.rowid, NEW.content, NEW.category, NEW.tags);
END;
"""

VALID_CATEGORIES = frozenset({"session", "pattern", "decision", "preference", "risk"})


def _epoch_to_iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()


def _row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    d["tags"] = json.loads(d["tags"]) if isinstance(d["tags"], str) else d["tags"]
    d["created_at"] = _epoch_to_iso(d["created_at"])
    d["updated_at"] = _epoch_to_iso(d["updated_at"])
    if d.get("expires_at") is not None:
        d["expires_at"] = _epoch_to_iso(d["expires_at"])
    return d


class MemoryStore:
    """Persistent structured memory backed by SQLite with FTS5 search."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        _log.debug("Opening memory database %s", self.db_path)
        self.conn = sqlite3.connect(str(self.db_path), timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=FULL")
        self._init_schema()

    def _init_schema(self) -> None:
        with self.conn:
            self.conn.executescript(_SCHEMA_SQL)
            self.conn.executescript(_FTS_SQL)
            self.conn.executescript(_TRIGGERS_SQL)

    def close(self) -> None:
        _log.debug("Closing memory database %s", self.db_path)
        try:
            self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass
        self.conn.close()

    def __enter__(self) -> "MemoryStore":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def save(
        self,
        content: str,
        category: str,
        tags: list[str] | None = None,
        confidence: float = 1.0,
        expires_at: float | None = None,
        source: str = "",
    ) -> str:
        """Save a new memory. Returns the generated ID."""
        if category not in VALID_CATEGORIES:
            raise ValueError(
                f"Invalid category '{category}'. Must be one of: {sorted(VALID_CATEGORIES)}"
            )
        memory_id = uuid.uuid4().hex[:12]
        now = time.time()
        tags_json = json.dumps(tags or [])
        with self.conn:
            self.conn.execute(
                """INSERT INTO memories (id, content, category, tags, confidence,
                   created_at, updated_at, expires_at, source)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (memory_id, content, category, tags_json, confidence,
                 now, now, expires_at, source),
            )
        return memory_id

    def get(self, memory_id: str) -> dict | None:
        """Get a memory by ID."""
        row = self.conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        return _row_to_dict(row) if row else None

    def update(
        self,
        memory_id: str,
        content: str | None = None,
        confidence: float | None = None,
        tags: list[str] | None = None,
    ) -> bool:
        """Update an existing memory. Returns True if found and updated."""
        existing = self.conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        if not existing:
            return False

        new_content = content if content is not None else existing["content"]
        new_confidence = confidence if confidence is not None else existing["confidence"]
        new_tags = json.dumps(tags) if tags is not None else existing["tags"]
        now = time.time()

        with self.conn:
            self.conn.execute(
                """UPDATE memories SET content = ?, confidence = ?, tags = ?,
                   updated_at = ? WHERE id = ?""",
                (new_content, new_confidence, new_tags, now, memory_id),
            )
        return True

    def delete(self, memory_id: str) -> bool:
        """Delete a memory by ID. Returns True if it existed."""
        with self.conn:
            cursor = self.conn.execute(
                "DELETE FROM memories WHERE id = ?", (memory_id,)
            )
        return cursor.rowcount > 0

    # ------------------------------------------------------------------
    # Search & query
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        category: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """Full-text search across memories using FTS5."""
        # Build FTS5 query — quote terms to handle special chars
        terms = query.strip().split()
        if not terms:
            return []
        fts_query = " OR ".join(f'"{t}"' for t in terms)

        if category:
            rows = self.conn.execute(
                """SELECT m.*, rank
                   FROM memory_fts f
                   JOIN memories m ON m.rowid = f.rowid
                   WHERE memory_fts MATCH ? AND m.category = ?
                   ORDER BY rank
                   LIMIT ?""",
                (fts_query, category, limit),
            ).fetchall()
        else:
            rows = self.conn.execute(
                """SELECT m.*, rank
                   FROM memory_fts f
                   JOIN memories m ON m.rowid = f.rowid
                   WHERE memory_fts MATCH ?
                   ORDER BY rank
                   LIMIT ?""",
                (fts_query, limit),
            ).fetchall()

        results = []
        for row in rows:
            d = _row_to_dict(row)
            d.pop("rank", None)
            results.append(d)
        return results

    def list_recent(
        self,
        category: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """List memories sorted by updated_at DESC."""
        if category:
            rows = self.conn.execute(
                "SELECT * FROM memories WHERE category = ? ORDER BY updated_at DESC LIMIT ?",
                (category, limit),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM memories ORDER BY updated_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [_row_to_dict(row) for row in rows]

    def cleanup_expired(self) -> int:
        """Delete memories past their expires_at. Returns count deleted."""
        now = time.time()
        with self.conn:
            cursor = self.conn.execute(
                "DELETE FROM memories WHERE expires_at IS NOT NULL AND expires_at < ?",
                (now,),
            )
        return cursor.rowcount

    def stats(self) -> dict:
        """Return summary statistics about stored memories."""
        total = self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        by_category = {}
        for row in self.conn.execute(
            "SELECT category, COUNT(*) as cnt FROM memories GROUP BY category"
        ).fetchall():
            by_category[row["category"]] = row["cnt"]
        oldest = self.conn.execute(
            "SELECT MIN(created_at) FROM memories"
        ).fetchone()[0]
        newest = self.conn.execute(
            "SELECT MAX(updated_at) FROM memories"
        ).fetchone()[0]
        return {
            "total": total,
            "by_category": by_category,
            "oldest": _epoch_to_iso(oldest) if oldest else None,
            "newest": _epoch_to_iso(newest) if newest else None,
        }
