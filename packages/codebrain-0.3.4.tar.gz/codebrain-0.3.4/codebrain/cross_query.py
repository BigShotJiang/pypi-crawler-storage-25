"""Cross-repo query engine — impact analysis and dependency graphs across repos.

Uses the CrossRegistry to resolve inter-repo dependencies and perform
cross-repo impact analysis by opening multiple GraphStore databases.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from codebrain.cross_registry import CrossRegistry
from codebrain.graph.store import GraphStore
from codebrain.graph.query import QueryEngine
from codebrain.logging import get_logger

_log = get_logger("cross_query")


class CrossQueryEngine:
    """Performs cross-repo queries by bridging multiple indexed repositories."""

    def __init__(self, registry: CrossRegistry) -> None:
        self._registry = registry

    def dependency_graph(self) -> dict[str, Any]:
        """Build repo-level dependency DAG.

        For each registered repo, scans its IMPORTS edges and resolves them
        against other registered repos to build the inter-repo dependency graph.

        Returns:
            {
                "repos": [{slug, repo_path, packages, dep_count}],
                "edges": [{source, target, import_count, sample_imports}],
                "narrative": str
            }
        """
        all_repos = self._registry.list_repos()
        pkg_to_slug = self._registry.get_all_packages()

        repo_nodes = []
        dep_edges: dict[tuple[str, str], list[str]] = {}  # (from, to) -> [import_names]

        for repo in all_repos:
            slug = repo["slug"]
            db_path = Path(repo["db_path"])

            if not db_path.is_file():
                _log.debug("Skipping %s — DB not found at %s", slug, db_path)
                repo_nodes.append({
                    "slug": slug, "repo_path": repo["repo_path"],
                    "packages": repo["packages"], "dep_count": 0,
                })
                continue

            # Open the repo's DB read-only
            try:
                store = GraphStore(db_path)
            except Exception as e:
                _log.warning("Failed to open %s: %s", db_path, e)
                repo_nodes.append({
                    "slug": slug, "repo_path": repo["repo_path"],
                    "packages": repo["packages"], "dep_count": 0,
                })
                continue

            try:
                edges = store.get_all_edges()
                own_packages = set(repo["packages"])

                for edge in edges:
                    if edge.get("type") != "IMPORTS":
                        continue
                    target = edge.get("target", "")
                    if not target:
                        continue

                    # Try to resolve this import to a registered repo
                    resolved = self._registry.resolve_package(target)
                    for r in resolved:
                        dep_slug = r["slug"]
                        if dep_slug == slug:
                            continue  # Self-import
                        key = (slug, dep_slug)
                        dep_edges.setdefault(key, [])
                        if len(dep_edges[key]) < 10:  # Cap samples
                            dep_edges[key].append(target)
                        elif target not in dep_edges[key]:
                            dep_edges[key].append(target)
            finally:
                store.close()

            dep_count = len({t for (s, t) in dep_edges if s == slug})
            repo_nodes.append({
                "slug": slug, "repo_path": repo["repo_path"],
                "packages": repo["packages"], "dep_count": dep_count,
            })

        edges_list = []
        for (src, tgt), imports in dep_edges.items():
            edges_list.append({
                "source": src,
                "target": tgt,
                "import_count": len(imports),
                "sample_imports": imports[:5],
            })

        # Build narrative
        narrative_parts = [f"Cross-repo dependency graph: {len(repo_nodes)} repos registered."]
        if edges_list:
            narrative_parts.append(f"{len(edges_list)} inter-repo dependencies found:")
            for e in sorted(edges_list, key=lambda x: -x["import_count"]):
                narrative_parts.append(
                    f"  {e['source']} -> {e['target']} ({e['import_count']} imports)"
                )
        else:
            narrative_parts.append("No inter-repo dependencies detected.")

        return {
            "repos": repo_nodes,
            "edges": edges_list,
            "narrative": "\n".join(narrative_parts),
        }

    def cross_impact(self, repo_slug: str, symbol: str,
                     max_depth: int = 5) -> dict[str, Any]:
        """Cross-repo impact analysis.

        1. Run impact_of_change within the origin repo.
        2. Collect affected exported symbols.
        3. Search other repos for imports of those symbols.
        4. Run local impact in consuming repos.

        Args:
            repo_slug: The repo where the change originates.
            symbol: Node ID or file path of the changed symbol.
            max_depth: Max BFS depth for impact analysis.

        Returns:
            {
                "origin_repo": str,
                "origin_symbol": str,
                "internal_impact": [nodes],
                "external_impact": [{repo_slug, affected_nodes}],
                "total_affected": int,
                "narrative": str
            }
        """
        repo_info = self._registry.get_repo(repo_slug)
        if repo_info is None:
            return {
                "origin_repo": repo_slug, "origin_symbol": symbol,
                "internal_impact": [], "external_impact": [],
                "total_affected": 0,
                "narrative": f"Repo '{repo_slug}' not found in registry.",
            }

        db_path = Path(repo_info["db_path"])
        if not db_path.is_file():
            return {
                "origin_repo": repo_slug, "origin_symbol": symbol,
                "internal_impact": [], "external_impact": [],
                "total_affected": 0,
                "narrative": f"Database not found for '{repo_slug}'. Run 'brain init' first.",
            }

        # Step 1: Internal impact
        origin_store = GraphStore(db_path)
        try:
            qe = QueryEngine(origin_store)
            internal_impact = qe.impact_of_change(symbol, max_depth=max_depth)

            # Step 2: Collect affected exported symbols
            affected_exported: set[str] = set()
            for node in internal_impact:
                if node.get("is_exported"):
                    qname = node.get("qualified_name", node.get("name", ""))
                    if qname:
                        affected_exported.add(qname)
                    name = node.get("name", "")
                    if name:
                        affected_exported.add(name)

            # Also add the original symbol
            orig_nodes = qe.search_nodes(symbol, limit=10)
            for n in orig_nodes:
                if n.get("is_exported"):
                    qname = n.get("qualified_name", n.get("name", ""))
                    if qname:
                        affected_exported.add(qname)
        finally:
            origin_store.close()

        # Step 3: Search other repos
        origin_packages = repo_info["packages"]
        external_impact: list[dict[str, Any]] = []
        all_repos = self._registry.list_repos()

        for other_repo in all_repos:
            if other_repo["slug"] == repo_slug:
                continue
            other_db = Path(other_repo["db_path"])
            if not other_db.is_file():
                continue

            try:
                other_store = GraphStore(other_db)
            except Exception:
                continue

            try:
                other_edges = other_store.get_all_edges()
                # Find imports that reference our affected symbols
                importing_nodes: set[str] = set()
                for edge in other_edges:
                    if edge.get("type") != "IMPORTS":
                        continue
                    target = edge.get("target", "")
                    # Check if this import references any of our affected symbols
                    # Import targets come in various forms:
                    # - "libA.core" (module-level import)
                    # - "libA.core.important_function" (direct symbol import)
                    # - "important_function" (bare name from from-import)
                    matched = False
                    for pkg in origin_packages:
                        if matched:
                            break
                        # Quick check: does target start with this package?
                        if not (target.startswith(f"{pkg}.")
                                or target == pkg
                                or target in affected_exported):
                            continue
                        for exported_sym in affected_exported:
                            full_ref = f"{pkg}.{exported_sym}"
                            if (target == full_ref
                                    or target == exported_sym
                                    or target.endswith(f".{exported_sym}")):
                                importing_nodes.add(edge["source"])
                                matched = True
                                break
                        # If target is a module import from this package,
                        # it may expose our symbols (from X import *)
                        if not matched and target.startswith(f"{pkg}."):
                            importing_nodes.add(edge["source"])
                            matched = True

                if importing_nodes:
                    # Step 4: Run local impact in consuming repo
                    other_qe = QueryEngine(other_store)
                    all_other_nodes = other_store.get_all_nodes()
                    node_by_id = {n["id"]: n for n in all_other_nodes}

                    affected_in_other: list[dict] = []
                    seen: set[str] = set()

                    # Include the importing nodes themselves as affected
                    for imp_node in importing_nodes:
                        if imp_node in node_by_id and imp_node not in seen:
                            seen.add(imp_node)
                            affected_in_other.append(node_by_id[imp_node])
                        # Also trace downstream impact
                        for affected in other_qe.impact_of_change(imp_node, max_depth=3):
                            nid = affected.get("id", "")
                            if nid not in seen:
                                seen.add(nid)
                                affected_in_other.append(affected)

                    external_impact.append({
                        "repo_slug": other_repo["slug"],
                        "repo_path": other_repo["repo_path"],
                        "importing_nodes": len(importing_nodes),
                        "affected_nodes": len(affected_in_other),
                        "sample_affected": [
                            {"name": n.get("name"), "file": n.get("file_path"),
                             "type": n.get("type")}
                            for n in affected_in_other[:10]
                        ],
                    })
            finally:
                other_store.close()

        total = len(internal_impact) + sum(
            e["affected_nodes"] for e in external_impact
        )

        # Build narrative
        parts = [
            f"Impact analysis for '{symbol}' in repo '{repo_slug}':",
            f"  Internal: {len(internal_impact)} symbols affected",
        ]
        if external_impact:
            parts.append(f"  External: {len(external_impact)} repos affected:")
            for ext in external_impact:
                parts.append(
                    f"    {ext['repo_slug']}: {ext['affected_nodes']} symbols "
                    f"({ext['importing_nodes']} direct imports)"
                )
        else:
            parts.append("  No external repos affected.")
        parts.append(f"  Total blast radius: {total} symbols")

        return {
            "origin_repo": repo_slug,
            "origin_symbol": symbol,
            "internal_impact": [
                {"name": n.get("name"), "file": n.get("file_path"),
                 "type": n.get("type"), "id": n.get("id")}
                for n in internal_impact
            ],
            "external_impact": external_impact,
            "total_affected": total,
            "narrative": "\n".join(parts),
        }

    def find_external_consumers(self, repo_slug: str,
                                symbol_name: str) -> list[dict[str, Any]]:
        """Find which other repos import a specific symbol from this repo.

        Returns list of {repo_slug, file_path, line, source_node}.
        """
        repo_info = self._registry.get_repo(repo_slug)
        if repo_info is None:
            return []

        origin_packages = repo_info["packages"]
        consumers: list[dict[str, Any]] = []

        for other_repo in self._registry.list_repos():
            if other_repo["slug"] == repo_slug:
                continue
            other_db = Path(other_repo["db_path"])
            if not other_db.is_file():
                continue

            try:
                store = GraphStore(other_db)
            except Exception:
                continue

            try:
                edges = store.get_all_edges()
                for edge in edges:
                    if edge.get("type") != "IMPORTS":
                        continue
                    target = edge.get("target", "")
                    for pkg in origin_packages:
                        full_ref = f"{pkg}.{symbol_name}"
                        if target == full_ref or target == symbol_name or target.endswith(f".{symbol_name}"):
                            consumers.append({
                                "repo_slug": other_repo["slug"],
                                "file_path": edge.get("file_path", ""),
                                "line": edge.get("line", 0),
                                "source_node": edge.get("source", ""),
                                "import_target": target,
                            })
            finally:
                store.close()

        return consumers

    def find_unresolved_imports(self, repo_slug: str) -> list[dict[str, Any]]:
        """Find imports in a repo that don't resolve to any registered repo.

        Returns list of {target, file_path, line, source_node}.
        """
        repo_info = self._registry.get_repo(repo_slug)
        if repo_info is None:
            return []

        db_path = Path(repo_info["db_path"])
        if not db_path.is_file():
            return []

        own_packages = set(repo_info["packages"])
        store = GraphStore(db_path)
        try:
            edges = store.get_all_edges()
            all_nodes = store.get_all_nodes()
            internal_names = {n.get("name", "") for n in all_nodes}
            internal_names |= {n.get("qualified_name", "") for n in all_nodes}

            unresolved: list[dict[str, Any]] = []
            seen_targets: set[str] = set()

            for edge in edges:
                if edge.get("type") != "IMPORTS":
                    continue
                target = edge.get("target", "")
                if not target or target in seen_targets:
                    continue

                # Skip if it resolves internally
                if target in internal_names:
                    continue

                # Skip standard library / well-known packages
                top_level = target.split(".")[0]
                if top_level in _STDLIB_PREFIXES:
                    continue

                # Try to resolve via registry
                resolved = self._registry.resolve_package(target)
                if resolved:
                    continue

                seen_targets.add(target)
                unresolved.append({
                    "target": target,
                    "file_path": edge.get("file_path", ""),
                    "line": edge.get("line", 0),
                    "source_node": edge.get("source", ""),
                })
        finally:
            store.close()

        return unresolved


# Well-known stdlib/package prefixes to skip in unresolved analysis
_STDLIB_PREFIXES = frozenset({
    # Python stdlib
    "os", "sys", "re", "json", "pathlib", "typing", "collections",
    "functools", "itertools", "dataclasses", "abc", "io", "datetime",
    "logging", "unittest", "importlib", "contextlib", "asyncio",
    "concurrent", "threading", "multiprocessing", "subprocess",
    "hashlib", "sqlite3", "http", "urllib", "email", "html", "xml",
    "math", "statistics", "random", "decimal", "fractions",
    "copy", "pprint", "textwrap", "string", "enum", "struct",
    "tempfile", "shutil", "glob", "fnmatch", "time", "calendar",
    "argparse", "configparser", "csv", "socket", "ssl", "select",
    "signal", "mmap", "ctypes", "warnings", "traceback", "inspect",
    "dis", "code", "codeop", "compileall", "pdb", "profile",
    # Common third-party
    "pytest", "numpy", "pandas", "requests", "flask", "django",
    "fastapi", "pydantic", "sqlalchemy", "celery", "redis",
    "boto3", "click", "rich", "httpx", "aiohttp",
    # Node.js
    "react", "vue", "angular", "express", "next", "nuxt",
    "lodash", "axios", "moment", "webpack", "vite", "esbuild",
    # Java
    "java", "javax", "org.springframework", "org.junit", "org.apache",
    "com.google", "io.netty",
    # Go
    "fmt", "net", "strings", "strconv", "context", "sync", "errors",
    # Rust
    "std", "serde", "tokio", "clap", "anyhow", "thiserror",
    # C#
    "System", "Microsoft", "Newtonsoft",
})
