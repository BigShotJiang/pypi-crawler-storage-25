"""Click CLI — the ``brain`` command."""

from __future__ import annotations

import functools
import json
import sys
import threading
import time
import traceback
from pathlib import Path

import click

from codebrain import __version__
from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.logging import configure_logging, get_logger

_log = get_logger("cli")


def _db_path(repo_root: Path) -> Path:
    return repo_root / CODEBRAIN_DIR / DB_FILENAME


def _require_index(repo_root: Path) -> Path:
    """Return db_path or exit with an error if not initialized."""
    db = _db_path(repo_root)
    if not db.exists():
        click.echo(click.style("Error: CodeBrain not initialized.", fg="red"), err=True)
        click.echo("  Run: brain init", err=True)
        sys.exit(1)
    # Quick integrity check
    try:
        import sqlite3
        conn = sqlite3.connect(str(db))
        try:
            conn.execute("SELECT count(*) FROM nodes")
            # Check for incomplete index
            row = conn.execute(
                "SELECT value FROM meta WHERE key = 'index_status'"
            ).fetchone()
            if row and row[0] == "in_progress":
                total_row = conn.execute(
                    "SELECT value FROM meta WHERE key = 'index_files_total'"
                ).fetchone()
                file_count = conn.execute("SELECT count(*) FROM files").fetchone()[0]
                total = int(total_row[0]) if total_row else "?"
                click.echo(click.style(
                    f"Warning: Index is incomplete ({file_count} of {total} files).",
                    fg="yellow",
                ), err=True)
                click.echo("  Run: brain reindex", err=True)
        finally:
            conn.close()
    except Exception:
        click.echo(click.style("Warning: Database may be corrupted. Rebuilding...", fg="yellow"), err=True)
        import gc
        gc.collect()  # Release any lingering connections
        try:
            db.unlink(missing_ok=True)
            for wal in db.parent.glob(f"{db.name}-*"):
                wal.unlink(missing_ok=True)
            from codebrain.indexer import full_index
            full_index(repo_root, db)
            click.echo(click.style("Database rebuilt successfully.", fg="green"), err=True)
        except Exception as rebuild_err:
            click.echo(click.style(f"Rebuild failed: {rebuild_err}", fg="red"), err=True)
            sys.exit(1)
    return db


def _output(data: object, *, as_json: bool) -> None:
    """Print *data* as JSON or human-readable text."""
    if as_json:
        click.echo(json.dumps(data, indent=2))
    elif isinstance(data, dict):
        for key, value in data.items():
            click.echo(f"  {key}: {value}")
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                parts = [f"{k}={v}" for k, v in item.items()]
                click.echo("  " + "  ".join(parts))
            else:
                click.echo(f"  {item}")


def _get_timeout(ctx: click.Context) -> int:
    """Get CLI timeout from context (--timeout flag or settings default)."""
    if ctx and ctx.obj:
        explicit = ctx.obj.get("timeout")
        if explicit is not None:
            return explicit
    from codebrain.settings import load_settings
    repo = ctx.obj["repo_root"] if ctx and ctx.obj else None
    return load_settings(repo).cli_timeout


def _is_json_mode() -> bool:
    """Check if the current click command was invoked with --json."""
    ctx = click.get_current_context(silent=True)
    if ctx and ctx.params:
        return bool(ctx.params.get("as_json"))
    return False


def _run_with_timeout(fn, timeout: int, label: str = "Computing", quiet: bool = False):
    """Run *fn* in a thread with a timeout. Shows spinner on stderr.

    If *quiet* is True, the command was invoked with ``--json``, or stderr
    is not a TTY (piped, redirected, or CI), the spinner is suppressed so
    its braille frames cannot corrupt captured output.

    Returns the result or exits with a timeout message.
    """
    # Suppress spinner when producing JSON output or writing to a non-TTY
    # (e.g. a pipe via `2>&1 | tee`, or a CI log). The carriage-return
    # redraw trick only works on a real terminal.
    show_spinner = (
        not quiet
        and not _is_json_mode()
        and sys.stderr.isatty()
    )

    result_box = [None]
    error_box = [None]

    def _target():
        try:
            result_box[0] = fn()
        except Exception as exc:
            error_box[0] = exc

    thread = threading.Thread(target=_target, daemon=True)
    thread.start()

    if show_spinner:
        # Show spinner while waiting, tracking total elapsed time
        spinner_chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        idx = 0
        deadline = time.perf_counter() + timeout
        thread.join(timeout=0.1)
        while thread.is_alive() and time.perf_counter() < deadline:
            char = spinner_chars[idx % len(spinner_chars)]
            click.echo(f"\r  {char} {label}...", nl=False, err=True)
            idx += 1
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                break
            thread.join(timeout=min(0.2, remaining))
    else:
        # No spinner — just wait for thread to finish or timeout
        thread.join(timeout=timeout)

    if thread.is_alive():
        # Timeout — thread is still running (daemon, will be cleaned up)
        if show_spinner:
            click.echo(f"\r  ", nl=False, err=True)  # Clear spinner
            click.echo(err=True)
        click.echo(click.style(
            f"Operation timed out after {timeout}s.", fg="yellow"
        ), err=True)
        click.echo(f"  Use --timeout N to increase (e.g. --timeout 300).", err=True)
        sys.exit(1)

    # Clear spinner line
    if show_spinner:
        click.echo(f"\r  ", nl=False, err=True)

    if error_box[0] is not None:
        raise error_box[0]
    return result_box[0]


def _safe_command(fn):  # noqa: ANN001, ANN201
    """Decorator that catches exceptions and shows user-friendly messages."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        try:
            return fn(*args, **kwargs)
        except SystemExit:
            raise
        except PermissionError as exc:
            click.echo(click.style(f"Permission denied: {exc}", fg="red"), err=True)
            click.echo("  Another process may be using the database. Close other brain/MCP instances and retry.", err=True)
            sys.exit(1)
        except Exception as exc:
            import sqlite3
            ctx = click.get_current_context(silent=True)
            verbose = ctx.obj.get("verbose", False) if ctx and ctx.obj else False
            if isinstance(exc, sqlite3.DatabaseError):
                click.echo(click.style(f"Database error: {exc}", fg="red"), err=True)
                click.echo("  Run: brain reindex", err=True)
            elif isinstance(exc, ModuleNotFoundError) and "tree_sitter" in str(exc):
                click.echo(click.style(f"Missing dependency: {exc}", fg="red"), err=True)
                click.echo("  Install with: pip install codebrain[ts]", err=True)
            elif verbose:
                click.echo(traceback.format_exc(), err=True)
            else:
                click.echo(click.style(f"Error: {exc}", fg="red"), err=True)
                click.echo("  (use --verbose for full traceback)", err=True)
            sys.exit(1)
    return wrapper


@click.group()
@click.version_option(version=__version__, prog_name="CodeBrain")
@click.option("--repo", default=".", help="Repository root (default: current directory).")
@click.option("--project", default=None, help="Project directory path (overrides --repo).")
@click.option("--verbose", is_flag=True, help="Enable debug logging and full tracebacks.")
@click.option("--timeout", type=int, default=None, help="Timeout in seconds for analysis commands (default: 120).")
@click.pass_context
def cli(ctx: click.Context, repo: str, project: str | None, verbose: bool, timeout: int | None) -> None:
    """CodeBrain — structural knowledge graph for your codebase."""
    ctx.ensure_object(dict)
    if timeout is not None:
        ctx.obj["timeout"] = timeout
    if project is not None:
        project_path = Path(project).resolve()
        if not project_path.is_dir():
            click.echo(click.style(f"Error: Project path does not exist: {project_path}", fg="red"), err=True)
            sys.exit(1)
        ctx.obj["repo_root"] = project_path
    else:
        ctx.obj["repo_root"] = Path(repo).resolve()
    ctx.obj["verbose"] = verbose
    configure_logging(verbose)


# ------------------------------------------------------------------ init
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def init(ctx: click.Context, as_json: bool) -> None:
    """Index the current repository and create the CodeBrain database."""
    from codebrain.indexer import discover_files, full_index

    repo_root: Path = ctx.obj["repo_root"]
    files = discover_files(repo_root)

    if not files:
        click.echo(click.style("No parseable files found.", fg="yellow"), err=True)
        click.echo(f"  CodeBrain supports: .py, .ts, .tsx, .js, .jsx, .env, docker-compose.yml", err=True)
        click.echo(f"  Check that you're in the right directory: {repo_root}", err=True)
        return

    if as_json:
        result = full_index(repo_root)
        click.echo(json.dumps(result, indent=2))
        return

    click.echo(f"Indexing {repo_root} ({len(files)} files) ...")

    with click.progressbar(length=len(files), label="Parsing") as bar:
        def _progress(current: int, total: int) -> None:
            bar.update(1)
        result = full_index(repo_root, progress_callback=_progress)

    click.echo(f"Done in {result['elapsed_seconds']}s")
    click.echo(f"  Files parsed: {result['files_parsed']}")
    click.echo(f"  Nodes: {result['total_nodes']}")
    click.echo(f"  Edges: {result['total_edges']}")
    if result["errors"]:
        click.echo(f"  Errors: {len(result['errors'])}")
        for err in result["errors"][:5]:
            click.echo(f"    {err}")

    # Warn if TypeScript files were indexed
    ts_exts = (".ts", ".tsx", ".js", ".jsx")
    if any(str(f).endswith(ts_exts) for f in files):
        click.echo()
        click.echo(click.style("Note:", fg="yellow") + " TypeScript parsing is experimental (regex-based). Results may be incomplete.")

    # Instant findings — show the most interesting results right after indexing
    try:
        _show_init_findings(repo_root, result)
    except Exception:
        pass  # Don't let findings crash init

    # D3: Post-init onboarding
    click.echo()
    click.echo(click.style("Quick start:", bold=True))
    click.echo("  brain search <q>    Search for symbols")
    click.echo("  brain trace <fn>    Show call chain from a function")
    click.echo("  brain impact <fn>   What breaks if a function changes")
    click.echo("  brain deadcode      Find unreferenced symbols")
    click.echo("  brain health        Full codebase health report")
    click.echo("  brain setup         Set up Claude Code integration (CLAUDE.md + MCP)")


def _show_init_findings(repo_root: Path, index_result: dict) -> None:
    """Show instant findings after indexing — the 'aha moment'."""
    from codebrain.graph.store import GraphStore
    from codebrain.graph.query import QueryEngine
    from codebrain.comprehension import ComprehensionEngine

    db = _db_path(repo_root)
    if not db.exists():
        return

    with GraphStore(db) as store:
        engine = QueryEngine(store)
        comp = ComprehensionEngine(store)

        click.echo()
        click.echo(click.style("=== Instant Findings ===", bold=True))

        # Health score
        try:
            health = comp.health_score(repo_root=str(repo_root))
            score = health.get("score", 0)
            grade = health.get("grade", "?")
            color = "green" if score >= 80 else "yellow" if score >= 60 else "red"
            click.echo(f"\nHealth: {click.style(f'{score}/100 ({grade})', fg=color)}")
        except Exception:
            pass

        # Top 3 hotspots
        try:
            hotspots = comp.risk_hotspots(top_n=3)
            if hotspots:
                click.echo(f"\nRiskiest symbols (change these carefully):")
                for h in hotspots:
                    name = h.get("name", "?")
                    affected = h.get("affected_files", 0)
                    fp = h.get("file_path", "")
                    click.echo(f"  {click.style(name, fg='red')} — affects {affected} files ({fp})")
        except Exception:
            pass

        # High-confidence dead code count
        try:
            dead = engine.find_dead_code(repo_root=str(repo_root))
            high = [d for d in dead if d.get("confidence") == "high"]
            if high:
                click.echo(f"\nDead code: {click.style(str(len(high)), fg='yellow')} high-confidence unreferenced symbols")
                for d in high[:3]:
                    click.echo(f"  {d['name']} ({d['type']}) in {d['file_path']}")
                if len(high) > 3:
                    click.echo(f"  ... run `brain deadcode` for full list")
            elif dead:
                click.echo(f"\nDead code: {len(dead)} candidates (none high-confidence)")
        except Exception:
            pass

        # Architecture
        try:
            from codebrain.architecture import detect_architecture
            arch = detect_architecture(store, repo_root=str(repo_root))
            if arch.get("frameworks"):
                fws = ", ".join(arch["frameworks"][:3])
                click.echo(f"\nDetected: {fws}")
            if arch.get("pattern"):
                click.echo(f"Architecture: {arch['pattern']}")
        except Exception:
            pass


# ------------------------------------------------------------------ setup
@cli.command()
@click.option("--force", is_flag=True, help="Overwrite existing CLAUDE.md.")
@click.pass_context
@_safe_command
def setup(ctx: click.Context, force: bool) -> None:
    """Set up Claude Code integration: index + CLAUDE.md + MCP config.

    Creates a CLAUDE.md with instructions for Claude Code to use CodeBrain
    tools, and ensures the MCP server is configured globally.
    """
    from codebrain.indexer import discover_files, full_index

    repo_root: Path = ctx.obj["repo_root"]
    project_name = repo_root.name

    # 1. Index if needed
    db_path = _db_path(repo_root)
    if not db_path.exists():
        files = discover_files(repo_root)
        click.echo(f"Indexing {repo_root} ({len(files)} files) ...")
        with click.progressbar(length=len(files), label="Parsing") as bar:
            result = full_index(repo_root, progress_callback=lambda c, t: bar.update(1))
        click.echo(f"  {result['files_parsed']} files, {result['total_nodes']} nodes, {result['total_edges']} edges")
    else:
        click.echo(f"Index exists at {db_path}")

    # 2. Create CLAUDE.md
    claude_md = repo_root / "CLAUDE.md"
    if claude_md.exists() and not force:
        click.echo(f"CLAUDE.md already exists (use --force to overwrite)")
    else:
        template_path = Path(__file__).parent.parent / "templates" / "CLAUDE.md.template"
        if template_path.exists():
            content = template_path.read_text().replace("{{PROJECT_NAME}}", project_name)
        else:
            content = _generate_claude_md(project_name)
        claude_md.write_text(content)
        click.echo(f"Created {claude_md}")

    # 3. Configure MCP scoped to *this* project via .mcp.json
    #
    # Project-local config is the right scope: CodeBrain's DB lives in
    # <repo>/.codebrain/, the MCP only makes sense for the repo it was
    # indexed against, and a global config makes every Claude session in
    # every project fight over the same DB and PID file.
    mcp_config_path = repo_root / ".mcp.json"
    if mcp_config_path.exists():
        try:
            mcp_config = json.loads(mcp_config_path.read_text())
        except json.JSONDecodeError:
            mcp_config = {}
    else:
        mcp_config = {}
    mcp_config.setdefault("mcpServers", {})
    if "codebrain" in mcp_config["mcpServers"] and not force:
        click.echo(f"MCP server already configured in {mcp_config_path}")
    else:
        mcp_config["mcpServers"]["codebrain"] = {
            "command": "python",
            "args": ["-m", "codebrain.mcp_server"],
        }
        mcp_config_path.write_text(json.dumps(mcp_config, indent=2) + "\n")
        click.echo(f"Wrote MCP config to {mcp_config_path}")

    click.echo()
    click.echo(click.style("Done! Restart Claude Code (in this repo) to activate.", bold=True))
    click.echo("On first launch Claude Code will ask you to approve the project MCP server.")


def _generate_claude_md(project_name: str) -> str:
    """Generate a CLAUDE.md without the template file."""
    return f"""# {project_name} — Claude Code Instructions

## CodeBrain Integration

This project is indexed by CodeBrain. You have MCP tools that give you structural understanding of the entire codebase. **USE THEM.**

### Workflow

1. **Starting a task** -> `codebase_overview()` and `query_modules("", 3)`
2. **Before modifying code** -> `impact_analysis("function_name")` and `query_dependencies("module/path")`
3. **After modifying code** -> `validate_change("file/path.py")` on every changed file
4. **Need to understand code** -> `get_symbol_context("name")` or `explain_code("file/path")`
5. **Have a question** -> `ask_codebase("how does X work?")`

### Key Rule
**Never modify a function with >5 dependents without running `impact_analysis` first.**
"""


# ------------------------------------------------------------------ status
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def status(ctx: click.Context, as_json: bool) -> None:
    """Show index statistics."""
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import discover_files

    repo_root: Path = ctx.obj["repo_root"]
    db = _require_index(repo_root)
    with GraphStore(db) as store:
        stats = store.get_stats()

    # M20: Index completeness — compare indexed files vs actual files on disk
    actual_files = len(discover_files(repo_root))
    indexed_files = stats.get("files", 0)
    stats["index_completeness"] = {
        "indexed": indexed_files,
        "total": actual_files,
        "complete": indexed_files >= actual_files * 0.95,
    }

    _output(stats, as_json=as_json)


# ------------------------------------------------------------------ trace
@cli.command()
@click.argument("name")
@click.option("--depth", default=10, help="Max traversal depth.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def trace(ctx: click.Context, name: str, depth: int, as_json: bool) -> None:
    """Show the forward call chain from a function."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(f"No node found matching '{name}'.", err=True)
            sys.exit(1)

        results: list[dict] = []
        for node in nodes:
            chain = engine.get_call_chain(node["id"], max_depth=depth)
            results.append({"root": node["id"], "chain": chain})

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for r in results:
            click.echo(f"Call chain from {r['root']}:")
            if not r["chain"]:
                click.echo("  (no outgoing calls)")
            for entry in r["chain"]:
                indent = "  " * entry["depth"]
                click.echo(f"  {indent}{entry['node_id']}  (via {entry['from']})")


# ------------------------------------------------------------------ callers
@cli.command()
@click.argument("name")
@click.option("--depth", default=3, help="Max traversal depth.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def callers(ctx: click.Context, name: str, depth: int, as_json: bool) -> None:
    """Show what calls a function/class (reverse call chain)."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(click.style(f"No symbol matching '{name}' found.", fg="red"), err=True)
            sys.exit(1)

        def _compute():
            engine.preload_reverse_index()
            results = []
            for node in nodes:
                impacted = engine.impact_of_change(node["id"], max_depth=depth)
                # Filter to direct callers only (depth 1) for clarity
                direct = [e for e in impacted if e["depth"] == 1]
                results.append({"target": node["id"], "callers": direct, "total_transitive": len(impacted)})
            return results

        results = _run_with_timeout(_compute, timeout, f"Finding callers of '{name}'")

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for r in results:
            direct = r["callers"]
            total = r["total_transitive"]
            click.echo(f"Callers of {r['target']}:")
            if not direct:
                click.echo("  (no callers found)")
            else:
                # Group by edge type
                by_type: dict[str, list[dict]] = {}
                for c in direct:
                    by_type.setdefault(c["edge_type"], []).append(c)
                for etype, entries in sorted(by_type.items()):
                    click.echo(f"  {etype} ({len(entries)}):")
                    for entry in entries[:20]:
                        click.echo(f"    {entry['node_id']}")
                    if len(entries) > 20:
                        click.echo(f"    ... and {len(entries) - 20} more")
                click.echo()
                click.echo(f"  Total: {len(direct)} direct, {total} transitive")


# ------------------------------------------------------------------ impact
@cli.command()
@click.argument("name")
@click.option("--depth", default=10, help="Max traversal depth.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def impact(ctx: click.Context, name: str, depth: int, as_json: bool) -> None:
    """Show what could break if a function/class changes."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(click.style(f"No symbol matching '{name}' found.", fg="red"), err=True)
            click.echo(f"  Try: brain search {name}", err=True)
            sys.exit(1)

        def _compute():
            engine.preload_reverse_index()
            results = []
            for node in nodes:
                impacted = engine.impact_of_change(node["id"], max_depth=depth)
                results.append({"target": node["id"], "impacted": impacted})
            return results

        results = _run_with_timeout(_compute, timeout, f"Analyzing impact of '{name}'")

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for r in results:
            impacted = r["impacted"]
            total = len(impacted)
            # Collect affected files for blast radius
            affected_files: set[str] = set()
            for entry in impacted:
                nid = entry["node_id"]
                if "::" in nid:
                    affected_files.add(nid.split("::")[0])
            with GraphStore(_require_index(repo_root)) as st:
                total_files = st.conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
            blast_pct = (len(affected_files) / max(total_files, 1)) * 100

            click.echo(f"Impact of changing {r['target']}:")
            if not impacted:
                click.echo("  (no dependents found)")
            elif total <= 30:
                # Small enough to show all
                for entry in impacted:
                    click.echo(f"  [{entry['depth']}] {entry['node_id']}  ({entry['edge_type']} via {entry['via']})")
            else:
                # Summarize: show by file, top entries, and blast radius
                click.echo(f"  {total} dependents across {len(affected_files)} files ({blast_pct:.1f}% blast radius)")
                click.echo()
                # Group by depth
                by_depth: dict[int, int] = {}
                for entry in impacted:
                    by_depth[entry["depth"]] = by_depth.get(entry["depth"], 0) + 1
                click.echo("  By depth:")
                for d in sorted(by_depth):
                    click.echo(f"    depth {d}: {by_depth[d]} symbols")
                click.echo()
                # Group by edge type
                by_type: dict[str, int] = {}
                for entry in impacted:
                    by_type[entry["edge_type"]] = by_type.get(entry["edge_type"], 0) + 1
                click.echo("  By relationship:")
                for t, cnt in sorted(by_type.items(), key=lambda x: -x[1]):
                    click.echo(f"    {t}: {cnt}")
                click.echo()
                # Top 10 most affected files
                file_counts: dict[str, int] = {}
                for entry in impacted:
                    nid = entry["node_id"]
                    if "::" in nid:
                        f = nid.split("::")[0]
                        file_counts[f] = file_counts.get(f, 0) + 1
                top_files = sorted(file_counts.items(), key=lambda x: -x[1])[:10]
                click.echo("  Most affected files:")
                for f, cnt in top_files:
                    click.echo(f"    {f} ({cnt} symbols)")
                if len(file_counts) > 10:
                    click.echo(f"    ... and {len(file_counts) - 10} more files")


# ------------------------------------------------------------------ deps
@cli.command()
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def deps(ctx: click.Context, name: str, as_json: bool) -> None:
    """Show dependencies of a symbol (what it calls/imports)."""
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        # Try resolving as a file first
        file_nodes = store.get_nodes_by_file(name)
        if file_nodes:
            from codebrain.graph.query import QueryEngine
            engine = QueryEngine(store)
            file_deps = engine.get_file_dependencies(name)
            if as_json:
                click.echo(json.dumps({"file": name, "imports": file_deps}, indent=2))
            else:
                click.echo(f"Dependencies of {name}:")
                for dep in file_deps:
                    click.echo(f"  {dep}")
            return

        # Resolve as a symbol
        from codebrain.graph.query import QueryEngine
        engine = QueryEngine(store)
        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(f"No node found matching '{name}'.", err=True)
            sys.exit(1)

        results: list[dict] = []
        for node in nodes:
            edges = store.get_edges_from(node["id"])
            results.append({
                "node": node["id"],
                "dependencies": [
                    {"target": e["target"], "type": e["type"], "line": e["line"]}
                    for e in edges
                ],
            })

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for r in results:
            click.echo(f"Dependencies of {r['node']}:")
            for dep in r["dependencies"]:
                click.echo(f"  {dep['type']} → {dep['target']}  (line {dep['line']})")


# ------------------------------------------------------------------ deadcode
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def deadcode(ctx: click.Context, as_json: bool) -> None:
    """List potentially unused functions and classes."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)
        dead = _run_with_timeout(
            lambda: engine.find_dead_code(repo_root=str(repo_root)),
            timeout, "Scanning for dead code",
        )

    if as_json:
        click.echo(json.dumps(dead, indent=2))
    else:
        if not dead:
            click.echo("No dead code detected.")
        else:
            click.echo(click.style(f"Potentially unused symbols ({len(dead)}):", bold=True))
            for item in dead:
                click.echo(f"  {item['type']:10s} {item['name']:30s} {item['file_path']}:{item['line_start']}")


# --------------------------------------------------------------- test-gaps
@cli.command("test-gaps")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--depth", default=3, help="Max BFS depth from test nodes (0=unlimited).")
@click.option("--min-risk", default=0.0, type=float, help="Only show gaps with risk >= this.")
@click.option("--include-methods/--no-methods", default=True, help="Include methods in coverage stats.")
@click.pass_context
@_safe_command
def test_gaps(ctx: click.Context, as_json: bool, depth: int, min_risk: float, include_methods: bool) -> None:
    """Structural test coverage gap analysis."""
    from dataclasses import asdict
    from codebrain.graph.store import GraphStore
    from codebrain.test_gaps import TestCoverageAnalyzer

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = TestCoverageAnalyzer(store)
        report = _run_with_timeout(
            lambda: analyzer.analyze(
                max_depth=depth,
                include_methods=include_methods,
                min_risk=min_risk,
            ),
            timeout,
            "Analyzing test coverage",
        )

    if as_json:
        click.echo(json.dumps(asdict(report), indent=2))
    else:
        click.echo(report.narrative)
        if report.gaps and not as_json:
            click.echo("")
            click.echo(click.style(f"Untested symbols ({len(report.gaps)}):", bold=True))
            for gap in report.gaps[:30]:
                risk_color = "red" if gap.risk_score >= 0.5 else ("yellow" if gap.risk_score >= 0.3 else "white")
                click.echo(
                    f"  {click.style(f'{gap.risk_score:.2f}', fg=risk_color)} "
                    f"{gap.symbol_type:10s} {gap.name:30s} {gap.file_path}:{gap.line_start}"
                )
            if len(report.gaps) > 30:
                click.echo(f"  ... and {len(report.gaps) - 30} more (use --json for full list)")


# ------------------------------------------------------------- architecture
@cli.command("architecture")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def architecture(ctx: click.Context, as_json: bool) -> None:
    """Detect codebase architecture pattern, frameworks, and DB technology."""
    from codebrain.architecture import ArchitectureDetector
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        detector = ArchitectureDetector(store)
        report = _run_with_timeout(
            detector.detect, timeout, "Detecting architecture"
        )

    if as_json:
        click.echo(json.dumps(report.to_dict(), indent=2))
    else:
        click.echo(report.narrative())


# -------------------------------------------------------------------- test
@cli.command("test")
@click.option("--affected", is_flag=True, help="Run only tests affected by uncommitted changes.")
@click.option("--file", "target_file", default=None, help="Run tests covering a specific file.")
@click.option("--runner", default="auto", type=click.Choice(["auto", "pytest", "jest", "go"]),
              help="Override runner detection.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--status", "show_status", is_flag=True, help="Show last run results (no execution).")
@click.option("--history", "show_history", is_flag=True, help="Show run history.")
@click.option("--limit", default=10, help="Limit history entries.")
@click.option("--for", "for_symbol", default=None, help="Show tests covering a symbol.")
@click.option("--timeout", "test_timeout", default=300, type=int, help="Test execution timeout (seconds).")
@click.pass_context
@_safe_command
def test_cmd(ctx: click.Context, affected: bool, target_file: str | None,
             runner: str, as_json: bool, show_status: bool, show_history: bool,
             limit: int, for_symbol: str | None, test_timeout: int) -> None:
    """Run tests and map results to the structural knowledge graph."""
    from dataclasses import asdict
    from codebrain.graph.store import GraphStore
    from codebrain.test_runner import TestRunner

    repo_root: Path = ctx.obj["repo_root"]

    with GraphStore(_require_index(repo_root)) as store:
        tr = TestRunner(store, repo_root)

        if show_status:
            status = tr.test_status()
            if as_json:
                click.echo(json.dumps(status, indent=2))
            elif status is None:
                click.echo("No test runs recorded yet. Run: brain test")
            else:
                _display_test_status(status)
            return

        if show_history:
            history = store.get_test_history(limit)
            if as_json:
                click.echo(json.dumps(history, indent=2))
            elif not history:
                click.echo("No test runs recorded yet.")
            else:
                click.echo(click.style("Test run history:", bold=True))
                for run in history:
                    import datetime
                    ts = datetime.datetime.fromtimestamp(run["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
                    status_str = click.style("PASS", fg="green") if run["failed"] == 0 else click.style(f"{run['failed']} FAIL", fg="red")
                    click.echo(f"  {ts}  {run['total']:4d} tests  {status_str}  ({run['duration_ms']/1000:.1f}s)  [{run['scope']}]")
            return

        if for_symbol:
            result = tr.test_for_symbol(for_symbol)
            if as_json:
                click.echo(json.dumps(result, indent=2))
            elif "error" in result:
                click.echo(result["error"])
            else:
                click.echo(click.style(f"Tests covering {for_symbol}:", bold=True))
                for t in result["tests"]:
                    color = "green" if t["last_status"] == "pass" else ("red" if t["last_status"] == "fail" else "white")
                    status_text = t["last_status"].ljust(8)
                    click.echo(f"  {click.style(status_text, fg=color)} {t['file_path']}")
            return

        # Run tests
        scope = "all"
        if affected:
            scope = "affected"
        elif target_file:
            scope = f"file:{target_file}"

        report = tr.run_tests(scope=scope, runner=runner, timeout=test_timeout)

        if as_json:
            click.echo(json.dumps(asdict(report), indent=2))
        else:
            click.echo(report.narrative)


def _display_test_status(status: dict) -> None:
    import datetime
    ts = datetime.datetime.fromtimestamp(status["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
    click.echo(click.style(f"Last run: {ts}", bold=True))
    color = "green" if status["failed"] == 0 else "red"
    click.echo(click.style(
        f"  {status['passed']} passed, {status['failed']} failed, "
        f"{status['skipped']} skipped ({status['duration_ms']/1000:.1f}s)",
        fg=color,
    ))
    click.echo(f"  Runner: {status['runner']} | Scope: {status['scope']} | Commit: {status['commit_hash']}")
    if status.get("at_risk_symbols"):
        click.echo("")
        click.echo(click.style(f"At-risk symbols ({len(status['at_risk_symbols'])}):", fg="red", bold=True))
        for s in status["at_risk_symbols"][:10]:
            click.echo(f"  {s['name']:30s} {s['file_path']}:{s['line_start']}  ({s['failing_tests']} failing)")


# ------------------------------------------------------------------ cycles
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def cycles(ctx: click.Context, as_json: bool) -> None:
    """Detect import cycles."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)
        found_cycles = _run_with_timeout(
            engine.detect_cycles, timeout, "Detecting cycles"
        )

    if as_json:
        click.echo(json.dumps(found_cycles, indent=2))
    else:
        if not found_cycles:
            click.echo("No import cycles detected.")
        else:
            click.echo(click.style(f"Import cycles ({len(found_cycles)}):", bold=True))
            for cycle in found_cycles:
                click.echo(f"  {' → '.join(cycle)}")


# ------------------------------------------------------------------ search
@cli.command()
@click.argument("query")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def search(ctx: click.Context, query: str, as_json: bool) -> None:
    """Search for nodes by name."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)
        results = engine.search_nodes(query)

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        if not results:
            click.echo(f"No results for '{query}'.")
        else:
            click.echo(f"Results for '{query}' ({len(results)}):")
            for node in results:
                sig = f"  {node['signature']}" if node["signature"] else ""
                click.echo(f"  {node['type']:10s} {node['qualified_name']}{sig}  ({node['file_path']}:{node['line_start']})")


# ------------------------------------------------------------------ validate
@cli.command()
@click.argument("file")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def validate(ctx: click.Context, file: str, as_json: bool) -> None:
    """Validate a changed file against the graph — detect what breaks."""
    from codebrain.graph.store import GraphStore
    from codebrain.validator import ChangeValidator

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        validator = ChangeValidator(store)

        target = Path(file)
        if not target.is_absolute():
            target = repo_root / target

        if not target.exists():
            rel = target.relative_to(repo_root).as_posix()
            report = validator.validate_deletion(rel)
        else:
            report = validator.validate_file(target, repo_root)

    if as_json:
        click.echo(json.dumps(report.to_dict(), indent=2))
    else:
        risk_bar = "#" * int(report.risk_score * 20)
        risk_color = "red" if report.risk_score > 0.7 else ("yellow" if report.risk_score > 0.3 else "green")
        valid_str = click.style("YES", fg="green") if report.is_valid else click.style("NO", fg="red")
        click.echo(click.style(f"Validation: {report.file_path}", bold=True))
        click.echo(f"  Valid:      {valid_str}")
        click.echo(f"  Risk:       [{click.style(risk_bar, fg=risk_color):<20s}] {report.risk_score:.1%}")
        click.echo(f"  Summary:    {report.summary}")
        if report.violations:
            click.echo(f"  Violations ({len(report.violations)}):")
            for v in report.violations:
                sev_color = {"critical": "red", "high": "yellow", "medium": "cyan"}.get(v.severity, None)
                sev_str = click.style(f"[{v.severity:8s}]", fg=sev_color) if sev_color else f"[{v.severity:8s}]"
                click.echo(f"    {sev_str} {v.message}")
        if report.affected_files:
            click.echo(f"  Affected files ({len(report.affected_files)}):")
            for f in report.affected_files:
                click.echo(f"    {f}")


# ------------------------------------------------------------------ overview
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def overview(ctx: click.Context, as_json: bool) -> None:
    """System-level overview of the codebase."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        result = _run_with_timeout(
            comp.system_overview, timeout, "Building overview"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        stats = result["stats"]
        click.echo(f"Codebase: {stats['files']} files, {stats['nodes']} symbols, {stats['edges']} edges")
        click.echo()
        click.echo("Packages:")
        for name, info in result["packages"].items():
            doc = f" — {info['docstring']}" if info["docstring"] else ""
            deps = f"  depends on: {', '.join(info['depends_on'])}" if info["depends_on"] else ""
            click.echo(f"  {name}: {info['file_count']} files, {info['node_count']} symbols{doc}")
            if deps:
                click.echo(f"    {deps}")
        if result["entry_points"]:
            click.echo()
            click.echo("Entry points:")
            for ep in result["entry_points"]:
                click.echo(f"  {ep['file_path']}:{ep['line']}")


# ------------------------------------------------------------------ anatomy
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def anatomy(ctx: click.Context, as_json: bool) -> None:
    """Codebase anatomy — subsystem map for new developers."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        result = comp.codebase_anatomy()

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(click.style(result["purpose"], bold=True))
        click.echo()
        click.echo("Subsystems:")
        for sub in sorted(result["subsystems"], key=lambda s: -s["importance"]):
            imp = sub["importance"]
            if imp >= 0.75:
                stars = "***"
            elif imp >= 0.50:
                stars = "** "
            elif imp >= 0.25:
                stars = "*  "
            else:
                stars = "   "
            click.echo(
                f"  {stars} {sub['name']:<20} "
                f"{sub['file_count']} files, {sub['symbol_count']} symbols"
            )
            click.echo(f"        {sub['description']}")
            if sub["depends_on"]:
                click.echo(f"        depends on: {', '.join(sub['depends_on'])}")
        if result["connections"]:
            click.echo()
            click.echo("Connections:")
            for conn in result["connections"][:10]:
                click.echo(f"  {conn['from']} → {conn['to']}  ({conn['label']})")


# ------------------------------------------------------------------ module
@cli.command()
@click.argument("file")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def module(ctx: click.Context, file: str, as_json: bool) -> None:
    """Module-level view of a file."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        result = comp.module_view(file)

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if "error" in result:
            click.echo(result["error"], err=True)
            sys.exit(1)
        click.echo(f"Module: {result['file_path']}  ({result['role']})")
        if result["docstring"]:
            click.echo(f"  {result['docstring']}")
        click.echo(f"  Lines: {result['line_count']}  Coupling: in={result['coupling']['incoming']} out={result['coupling']['outgoing']}")
        click.echo()
        if result["symbols"]:
            click.echo("  Symbols:")
            for s in result["symbols"]:
                exp = "*" if s["is_exported"] else " "
                sig = f"  {s['signature']}" if s["signature"] else ""
                click.echo(f"    {exp} {s['type']:10s} {s['name']}{sig}")
        if result["imports"]:
            click.echo(f"  Imports: {', '.join(result['imports'])}")
        if result["imported_by"]:
            click.echo(f"  Imported by: {', '.join(result['imported_by'])}")


# ------------------------------------------------------------------ context
@cli.command()
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def context(ctx: click.Context, name: str, as_json: bool) -> None:
    """Generate structured LLM context for a symbol."""
    from codebrain.context import ContextGenerator
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        gen = ContextGenerator(store)
        results = gen.for_symbol(name)

    if not results:
        click.echo(f"No node found matching '{name}'.", err=True)
        sys.exit(1)

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        for ctx_data in results:
            click.echo(f"{ctx_data['symbol_type']} {ctx_data['qualified_name']}  {ctx_data['signature']}")
            click.echo(f"  File: {ctx_data['file_path']}:{ctx_data['line_start']}-{ctx_data['line_end']}")
            if ctx_data["docstring"]:
                click.echo(f"  Doc: {ctx_data['docstring']}")
            if ctx_data["parent"]:
                click.echo(f"  Parent: {ctx_data['parent']['name']} ({ctx_data['parent']['type']})")
            if ctx_data["calls"]:
                click.echo(f"  Calls: {', '.join(c['target'] for c in ctx_data['calls'])}")
            if ctx_data["called_by"]:
                click.echo(f"  Called by: {', '.join(c['source'] for c in ctx_data['called_by'])}")
            if ctx_data.get("methods"):
                click.echo(f"  Methods: {', '.join(m['name'] for m in ctx_data['methods'])}")
            if ctx_data.get("bases"):
                click.echo(f"  Extends: {', '.join(ctx_data['bases'])}")
            click.echo()


# ------------------------------------------------------------------ hotspots
@cli.command()
@click.option("--top", default=20, help="Number of hotspots to show.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def hotspots(ctx: click.Context, top: int, as_json: bool) -> None:
    """Show the riskiest symbols in the codebase."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        results = _run_with_timeout(
            lambda: comp.risk_hotspots(top_n=top), timeout, "Finding hotspots"
        )

    if as_json:
        click.echo(json.dumps(results, indent=2))
    else:
        if not results:
            click.echo("No risk hotspots found.")
        else:
            click.echo(click.style(f"Risk hotspots (top {len(results)}):", bold=True))
            click.echo(f"  {'Score':>6s}  {'Type':10s} {'Name':30s} {'Deps':>5s} {'Files':>5s} Location")
            for h in results:
                score = h["risk_score"]
                score_color = "red" if score > 20 else ("yellow" if score > 5 else "green")
                click.echo(
                    f"  {click.style(f'{score:6.1f}', fg=score_color)}  {h['type']:10s} {h['name']:30s} "
                    f"{h['direct_dependents']:5d} {h['affected_files']:5d} "
                    f"{h['file_path']}:{h['line_start']}"
                )


# ------------------------------------------------------------------ health
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def health(ctx: click.Context, as_json: bool) -> None:
    """Show codebase health score (0-100)."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        comp = ComprehensionEngine(store)
        result = _run_with_timeout(
            lambda: comp.health_score(repo_root=str(repo_root)),
            timeout, "Computing health score",
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        score = result["score"]
        grade = result["grade"]
        details = result["details"]

        if score >= 80:
            color = "green"
        elif score >= 60:
            color = "yellow"
        else:
            color = "red"

        bar_len = score // 5
        bar = "#" * bar_len + "-" * (20 - bar_len)

        click.echo(click.style("Codebase Health", bold=True))
        click.echo(f"  Score: [{click.style(bar, fg=color)}] {click.style(str(score), fg=color, bold=True)}/100  (Grade: {click.style(grade, fg=color, bold=True)})")
        click.echo()
        dims = result.get("dimensions", {})
        click.echo(click.style("Dimensions:", bold=True))
        dc = dims.get("dead_code", {})
        cy = dims.get("import_cycles", {})
        cp = dims.get("coupling", {})
        dc_count = dc.get('count', details.get('dead_code_count', 0))
        dc_high = dc.get('high_confidence', dc_count)
        click.echo(f"  Dead code:     {dc_high} high-confidence ({dc.get('ratio', details.get('dead_code_ratio', 0)):.1%})  score {dc.get('score', '?')}/100")
        click.echo(f"  Import cycles: {cy.get('count', details.get('import_cycles', 0))}  score {cy.get('score', '?')}/100")
        top_risk = cp.get('top_risk_score', 0)
        click.echo(f"  Coupling:      top risk {top_risk:.0f}, {cp.get('hotspots_analyzed', 0)} hotspot(s)  score {cp.get('score', '?')}/100")


# ------------------------------------------------------------------ coupling
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def coupling(ctx: click.Context, as_json: bool) -> None:
    """Analyze module coupling across the codebase."""
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = StructuralAnalyzer(store)
        result = _run_with_timeout(
            analyzer.coupling_analysis, timeout, "Analyzing coupling"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result["pairs"]:
            click.echo(click.style("Most coupled file pairs:", bold=True))
            for pair in result["pairs"][:15]:
                click.echo(f"  {pair['coupling_score']:3d}  {pair['file_a']}  <->  {pair['file_b']}")
        click.echo()
        if result["file_ranking"]:
            click.echo(click.style("Most coupled files (aggregate):", bold=True))
            for f in result["file_ranking"][:15]:
                click.echo(f"  {f['total_coupling']:3d}  {f['file']}")


# ------------------------------------------------------------------ contracts
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def contracts(ctx: click.Context, as_json: bool) -> None:
    """Detect implicit contracts in the codebase."""
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = StructuralAnalyzer(store)
        result = _run_with_timeout(
            analyzer.detect_contracts, timeout, "Detecting contracts"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if not result:
            click.echo("No implicit contracts detected.")
        else:
            click.echo(f"Implicit contracts ({len(result)}):")
            for c in result:
                conf = f"{c['confidence']:.0%}"
                click.echo(f"  [{c['type']:16s}] ({conf}) {c['message']}")


# ------------------------------------------------------------------ layers
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def layers(ctx: click.Context, as_json: bool) -> None:
    """Show architectural layers inferred from dependencies."""
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = StructuralAnalyzer(store)
        result = _run_with_timeout(
            analyzer.detect_layers, timeout, "Computing layers"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        for layer in result["layers"]:
            click.echo(f"{layer['label']}  ({layer['description']})")
            for f in layer["files"]:
                click.echo(f"    {f}")
            click.echo()


# ------------------------------------------------------------------ watch
@cli.command()
@click.pass_context
@_safe_command
def watch(ctx: click.Context) -> None:
    """Start file watcher daemon for incremental updates."""
    from codebrain.watcher.file_watcher import start_watching

    repo_root: Path = ctx.obj["repo_root"]
    _require_index(repo_root)
    click.echo(f"Watching {repo_root} for changes... (Ctrl+C to stop)")
    start_watching(repo_root, _db_path(repo_root))


# ------------------------------------------------------------------ zoom
@cli.command()
@click.argument("target", required=False, default=None)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def zoom(ctx: click.Context, target: str | None, as_json: bool) -> None:
    """Multi-resolution zoom — navigate system, module, or symbol level.

    No target: system overview. File path: module view. Symbol name: symbol context.
    """
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    db = _db_path(repo_root)
    _require_index(repo_root)

    timeout = _get_timeout(ctx)

    with GraphStore(db) as store:
        comp = ComprehensionEngine(store)
        result = _run_with_timeout(
            lambda: comp.zoom(target), timeout, "Zooming"
        )

    if as_json:
        click.echo(json.dumps(result, indent=2, default=str))
    else:
        level = result.get("level", "unknown")
        if level == "system":
            narr = result.get("narrative", {})
            click.echo(f"System: {narr.get('summary', '')}")
            click.echo(f"Health: {narr.get('health', '')}")
            click.echo()
            if result.get("drill_down"):
                click.echo("Top modules (drill down):")
                for d in result["drill_down"][:8]:
                    click.echo(f"  {d['target']:<50} ({d['symbols']} symbols)")
        elif level == "module":
            narr = result.get("narrative", {})
            click.echo(f"Module: {result.get('file', '')}")
            click.echo(f"  {narr.get('summary', '')}")
            click.echo(f"  {narr.get('importance', '')}")
            click.echo()
            if result.get("symbols"):
                click.echo("Symbols:")
                for s in result["symbols"][:15]:
                    click.echo(f"  {s['type']:<10} {s['name']:<30} line {s['line']}")
        elif level == "symbol":
            narr = result.get("narrative", {})
            click.echo(f"Symbol: {result.get('name', '')} ({result.get('type', '')})")
            click.echo(f"  File: {result.get('file', '')}:{result.get('line', '')}")
            click.echo(f"  {narr.get('summary', '')}")
            if result.get("callers"):
                click.echo(f"\n  Callers ({len(result['callers'])}):")
                for c in result["callers"][:5]:
                    click.echo(f"    {c['name']}")
        elif "error" in result:
            click.echo(click.style(result["error"], fg="red"), err=True)


# ------------------------------------------------------------------ ci
@cli.command()
@click.option("--base", default="main", help="Base branch to diff against.")
@click.option("--fail-on", type=click.Choice(["unsafe", "caution"]), default="unsafe",
              help="Exit non-zero on this verdict level or worse.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def ci(ctx: click.Context, base: str, fail_on: str, as_json: bool) -> None:
    """Run structural validation on changed files (for CI pipelines).

    Compares HEAD against base branch and validates all changed files.
    Exits non-zero if structural breakage is detected.
    """
    import subprocess
    from codebrain.graph.store import GraphStore
    from codebrain.validator import ChangeValidator

    repo_root: Path = ctx.obj["repo_root"]
    db = _db_path(repo_root)

    # Auto-init if needed
    if not db.exists():
        from codebrain.indexer import full_index
        if not as_json:
            click.echo("Index not found, running brain init...")
        full_index(repo_root, db)

    # Get changed files — try three-dot diff first (PR changes only),
    # then two-dot diff, then direct comparison
    import os
    git_env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
    diff_output = ""
    for diff_spec in [f"{base}...HEAD", f"{base}..HEAD", base]:
        try:
            diff_output = subprocess.check_output(
                ["git", "diff", "--name-only", diff_spec],
                cwd=str(repo_root), text=True, stderr=subprocess.DEVNULL,
                env=git_env,
            ).strip()
            if diff_output:
                break
        except subprocess.CalledProcessError:
            continue

    if not diff_output:
        if as_json:
            click.echo(json.dumps({"verdict": "SAFE", "changed_files": 0, "message": "No changes"}))
        else:
            click.echo("No changes detected. Verdict: SAFE")
        return

    # Filter to supported extensions
    from codebrain.config import INDEXABLE_EXTENSIONS
    changed = [f for f in diff_output.splitlines()
               if Path(f).suffix in INDEXABLE_EXTENSIONS]

    if not changed:
        if as_json:
            click.echo(json.dumps({"verdict": "SAFE", "changed_files": 0, "message": "No structural changes"}))
        else:
            click.echo("No structural changes. Verdict: SAFE")
        return

    # Validate each file
    results = []
    with GraphStore(db) as store:
        validator = ChangeValidator(store)
        for rel_path in changed:
            abs_path = repo_root / rel_path
            if abs_path.exists():
                report = validator.validate_file(abs_path, repo_root)
            else:
                report = validator.validate_deletion(rel_path)
            results.append({"file": rel_path, "report": report})

    # Determine overall verdict
    has_critical = any(
        any(v.severity == "critical" for v in r["report"].violations)
        for r in results
    )
    has_high = any(
        any(v.severity == "high" for v in r["report"].violations)
        for r in results
    )
    has_medium = any(
        any(v.severity == "medium" for v in r["report"].violations)
        for r in results
    )

    if has_critical or has_high:
        verdict = "UNSAFE"
    elif has_medium:
        verdict = "CAUTION"
    else:
        verdict = "SAFE"

    # Determine exit code
    if fail_on == "unsafe" and verdict == "UNSAFE":
        exit_code = 1
    elif fail_on == "caution" and verdict in ("UNSAFE", "CAUTION"):
        exit_code = 1
    else:
        exit_code = 0

    if as_json:
        output = {
            "verdict": verdict,
            "changed_files": len(changed),
            "exit_code": exit_code,
            "files": [
                {"file": r["file"], **r["report"].to_dict()}
                for r in results
            ],
        }
        click.echo(json.dumps(output, indent=2))
    else:
        click.echo("CodeBrain Structural Validation")
        click.echo("=" * 32)
        click.echo(f"Changed files: {len(changed)}")
        for r in results:
            file_verdict = "UNSAFE" if not r["report"].is_valid else (
                "CAUTION" if any(v.severity == "medium" for v in r["report"].violations) else "SAFE"
            )
            violations_count = len(r["report"].violations)
            if violations_count:
                label = "warning" if file_verdict == "CAUTION" else "violation"
                label = label + "s" if violations_count > 1 else label
                suffix = f"  ({violations_count} {label})"
            else:
                suffix = ""
            color = {"SAFE": "green", "CAUTION": "yellow", "UNSAFE": "red"}[file_verdict]
            click.echo(f"  {r['file']:<50} {click.style(file_verdict, fg=color)}{suffix}")

        # Print violations
        all_violations = []
        for r in results:
            for v in r["report"].violations:
                if v.severity in ("critical", "high"):
                    all_violations.append(v)
        if all_violations:
            click.echo()
            click.echo("Violations:")
            for v in all_violations:
                click.echo(f"  [{v.severity.upper()}] {v.file_path}:{v.line} — {v.message}")

        click.echo()
        color = {"SAFE": "green", "CAUTION": "yellow", "UNSAFE": "red"}[verdict]
        click.echo(f"Verdict: {click.style(verdict, fg=color, bold=True)}")
        if exit_code:
            click.echo(f"Exit code: {exit_code}")

    sys.exit(exit_code)


# ------------------------------------------------------------------ reindex
@cli.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def reindex(ctx: click.Context, yes: bool, as_json: bool) -> None:
    """Force a full rebuild of the index."""
    from codebrain.indexer import discover_files, full_index

    repo_root: Path = ctx.obj["repo_root"]
    db = _db_path(repo_root)

    if not yes and not as_json:
        if not click.confirm("This will delete and rebuild the entire index. Continue?"):
            click.echo("Aborted.")
            return

    if db.exists():
        try:
            db.unlink()
        except PermissionError:
            from codebrain.mcp_lifecycle import find_db_lock_holder, kill_pid
            holder = find_db_lock_holder(repo_root)
            if holder is None:
                click.echo(
                    "  Database is locked but no recorded MCP holder.\n"
                    "  Find the holder with `Get-Process python` (Windows) or `lsof` (Unix) and stop it."
                )
                raise
            should_kill = yes or as_json or click.confirm(
                f"Database locked by CodeBrain MCP server PID {holder}. Terminate it and continue?"
            )
            if not should_kill:
                click.echo("Aborted.")
                return
            status = kill_pid(holder)
            click.echo(f"  Killed MCP PID {holder}: {status}")
            import time as _time
            _time.sleep(1)
            db.unlink()

    files = discover_files(repo_root)

    if as_json:
        result = full_index(repo_root, db)
        click.echo(json.dumps(result, indent=2))
        return

    click.echo(f"Reindexing {repo_root} ({len(files)} files) ...")

    with click.progressbar(length=len(files), label="Parsing") as bar:
        def _progress(current: int, total: int) -> None:
            bar.update(1)
        result = full_index(repo_root, db, progress_callback=_progress)

    click.echo(f"Done in {result['elapsed_seconds']}s")
    click.echo(f"  Files parsed: {result['files_parsed']}")
    click.echo(f"  Nodes: {result['total_nodes']}")
    click.echo(f"  Edges: {result['total_edges']}")
    if result["errors"]:
        click.echo(f"  Errors ({len(result['errors'])})")


# ------------------------------------------------------------------ doctor
@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option(
    "--kill-stale-mcps",
    is_flag=True,
    help="Terminate any stale CodeBrain MCP servers (parent dead or running >1h) before running checks.",
)
@click.pass_context
@_safe_command
def doctor(ctx: click.Context, as_json: bool, kill_stale_mcps: bool) -> None:
    """Run diagnostic checks on the CodeBrain index."""
    if kill_stale_mcps:
        from codebrain.mcp_lifecycle import kill_stale_mcps as _kill_stale_mcps
        results = _kill_stale_mcps()
        if as_json:
            click.echo(json.dumps({"killed": results}, indent=2))
        else:
            if not results:
                click.echo("No stale MCP servers found.")
            for r in results:
                click.echo(f"  PID {r['pid']}: {r['status']}")
            click.echo("")
    from codebrain.graph.schema import get_schema_version
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import discover_files
    from codebrain.utils import file_hash, normalize_path
    from codebrain.config import SCHEMA_VERSION

    repo_root: Path = ctx.obj["repo_root"]
    checks: list[dict] = []

    # Check 1: DB exists and is readable
    db = _db_path(repo_root)
    if not db.exists():
        checks.append({"check": "database", "status": "FAIL", "message": "Database not found. Run `brain init`."})
        if as_json:
            click.echo(json.dumps({"checks": checks}, indent=2))
        else:
            for c in checks:
                _print_check(c)
        return

    checks.append({"check": "database", "status": "OK", "message": f"Database found at {db}"})

    with GraphStore(db) as store:
        # Check 2: Schema version
        version = get_schema_version(store.conn)
        if version == SCHEMA_VERSION:
            checks.append({"check": "schema_version", "status": "OK", "message": f"Schema version {version} (current)"})
        else:
            checks.append({"check": "schema_version", "status": "WARN", "message": f"Schema version {version}, expected {SCHEMA_VERSION}"})

        # Check 3: Stats
        stats = store.get_stats()
        checks.append({"check": "stats", "status": "OK", "message": f"{stats['files']} files, {stats['nodes']} nodes, {stats['edges']} edges"})

        # Check 4: Sample hash check (stale detection)
        disk_files = discover_files(repo_root)
        sample = disk_files[:5]
        stale = 0
        for fp in sample:
            rel = normalize_path(fp, repo_root)
            stored = store.get_file_hash(rel)
            if stored is None:
                stale += 1
            elif stored != file_hash(fp):
                stale += 1

        if stale == 0:
            checks.append({"check": "freshness", "status": "OK", "message": f"Sample of {len(sample)} files matches stored hashes"})
        else:
            checks.append({"check": "freshness", "status": "WARN", "message": f"{stale}/{len(sample)} sampled files are stale — consider `brain reindex`"})

        # Check 5: Edge resolution rate
        all_edges_count = stats["edges"]
        if all_edges_count > 0:
            resolved = store.conn.execute(
                "SELECT COUNT(*) FROM edges WHERE target IN (SELECT id FROM nodes)"
            ).fetchone()[0]
            rate = resolved / all_edges_count if all_edges_count else 0
            status = "OK" if rate > 0.5 else "WARN"
            checks.append({"check": "edge_resolution", "status": status, "message": f"{resolved}/{all_edges_count} edges resolve to known nodes ({rate:.0%})"})

        # Check 6: Orphaned nodes (nodes with no edges)
        orphaned = store.conn.execute(
            "SELECT COUNT(*) FROM nodes WHERE type != 'file' AND id NOT IN (SELECT source FROM edges) AND id NOT IN (SELECT target FROM edges)"
        ).fetchone()[0]
        total_non_file = store.conn.execute("SELECT COUNT(*) FROM nodes WHERE type != 'file'").fetchone()[0]
        if total_non_file > 0:
            orphan_rate = orphaned / total_non_file
            status = "OK" if orphan_rate < 0.3 else "WARN"
            checks.append({"check": "orphaned_nodes", "status": status, "message": f"{orphaned}/{total_non_file} symbols have no edges ({orphan_rate:.0%})"})

    # Check 7: Stale MCP servers — abandoned children that hold the DB lock.
    from codebrain.mcp_lifecycle import find_stale_mcps
    stale = find_stale_mcps()
    if stale:
        details = ", ".join(f"PID {s['pid']} ({s['reason']})" for s in stale[:3])
        more = f" +{len(stale) - 3} more" if len(stale) > 3 else ""
        checks.append({
            "check": "mcp_processes",
            "status": "WARN",
            "message": f"{len(stale)} stale MCP server(s): {details}{more}. Run `brain doctor --kill-stale-mcps` to clean.",
            "stale_pids": [s["pid"] for s in stale],
        })
    else:
        checks.append({
            "check": "mcp_processes",
            "status": "OK",
            "message": "No stale MCP servers detected",
        })

    if as_json:
        click.echo(json.dumps({"checks": checks}, indent=2))
    else:
        for c in checks:
            _print_check(c)

        ok = sum(1 for c in checks if c["status"] == "OK")
        total = len(checks)
        click.echo(f"\n{ok}/{total} checks passed.")


def _print_check(check: dict) -> None:
    status = check["status"]
    if status == "OK":
        label = click.style("[OK]  ", fg="green")
    elif status == "WARN":
        label = click.style("[WARN]", fg="yellow")
    else:
        label = click.style("[FAIL]", fg="red")
    click.echo(f"  {label} {check['check']}: {check['message']}")


# ------------------------------------------------------------------ repair
@cli.command()
@click.pass_context
@_safe_command
def repair(ctx: click.Context) -> None:
    """Check database integrity and rebuild if corrupted."""
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import full_index

    repo_root: Path = ctx.obj["repo_root"]
    db = _db_path(repo_root)

    if not db.exists():
        click.echo("No database found. Run 'brain init' first.")
        return

    needs_rebuild = False
    try:
        import sqlite3 as _sqlite3
        conn = _sqlite3.connect(str(db))
        try:
            result = conn.execute("PRAGMA integrity_check").fetchone()
            if result[0] != "ok":
                needs_rebuild = True
        except _sqlite3.DatabaseError:
            needs_rebuild = True
        finally:
            conn.close()
    except Exception:
        needs_rebuild = True

    if not needs_rebuild:
        click.echo("Database integrity: OK")
        return

    click.echo("Database corrupted. Rebuilding...")
    import gc, time as _time
    gc.collect()
    for _attempt in range(5):
        try:
            db.unlink(missing_ok=True)
            break
        except PermissionError:
            _time.sleep(0.2)
    # Also clean up WAL/SHM files
    for suffix in ("-wal", "-shm"):
        wal = db.parent / (db.name + suffix)
        wal.unlink(missing_ok=True)
    full_index(repo_root, db)
    click.echo("Rebuilt successfully.")


# ------------------------------------------------------------------ mcp
@cli.command(name="mcp")
@click.pass_context
@_safe_command
def mcp_cmd(ctx: click.Context) -> None:
    """Start the MCP server (for LLM agent integration)."""
    from codebrain.mcp_server import run_server

    repo_root: Path = ctx.obj["repo_root"]
    _require_index(repo_root)
    import os
    os.chdir(repo_root)
    run_server()


# ------------------------------------------------------------------ hook
@cli.group()
def hook() -> None:
    """Manage git pre-commit hooks."""
    pass


@hook.command()
@click.pass_context
def install(ctx: click.Context) -> None:
    """Install the CodeBrain pre-commit validation hook."""
    from codebrain.hooks import install_hook

    repo_root: Path = ctx.obj["repo_root"]
    result = install_hook(repo_root)
    click.echo(result)


@hook.command()
@click.pass_context
def uninstall(ctx: click.Context) -> None:
    """Remove the CodeBrain pre-commit hook."""
    from codebrain.hooks import uninstall_hook

    repo_root: Path = ctx.obj["repo_root"]
    result = uninstall_hook(repo_root)
    click.echo(result)


@hook.command(name="install-claude")
@click.pass_context
def install_claude(ctx: click.Context) -> None:
    """Install a Claude Code PreToolUse hook that validates edits BEFORE they happen.

    Writes to .claude/settings.local.json. Blocks Edit / Write / MultiEdit calls
    on .py files that would introduce CRITICAL structural violations against the
    current knowledge graph. Set CODEBRAIN_SKIP_HOOK=1 to temporarily bypass.
    """
    repo_root: Path = ctx.obj["repo_root"]
    settings_path = repo_root / ".claude" / "settings.local.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    if settings_path.exists():
        try:
            cfg = json.loads(settings_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            cfg = {}
    else:
        cfg = {}

    hooks = cfg.setdefault("hooks", {})
    pretool = hooks.setdefault("PreToolUse", [])

    # Idempotent: replace any existing CodeBrain hook entry.
    pretool = [
        h for h in pretool
        if not any(
            "codebrain.hook_runner" in (step.get("command", "") or "")
            for step in h.get("hooks", [])
        )
    ]
    pretool.append({
        "matcher": "Edit|Write|MultiEdit",
        "hooks": [{
            "type": "command",
            "command": f"{sys.executable} -m codebrain.hook_runner --pretooluse",
        }],
    })
    hooks["PreToolUse"] = pretool
    cfg["hooks"] = hooks

    settings_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    click.echo(f"Installed Claude Code PreToolUse hook at {settings_path}")
    click.echo("  Bypass temporarily with: CODEBRAIN_SKIP_HOOK=1")


@hook.command(name="uninstall-claude")
@click.pass_context
def uninstall_claude(ctx: click.Context) -> None:
    """Remove the CodeBrain PreToolUse hook from .claude/settings.local.json."""
    repo_root: Path = ctx.obj["repo_root"]
    settings_path = repo_root / ".claude" / "settings.local.json"
    if not settings_path.exists():
        click.echo("No .claude/settings.local.json to clean up.")
        return

    cfg = json.loads(settings_path.read_text(encoding="utf-8"))
    pretool = cfg.get("hooks", {}).get("PreToolUse", [])
    pretool = [
        h for h in pretool
        if not any(
            "codebrain.hook_runner" in (step.get("command", "") or "")
            for step in h.get("hooks", [])
        )
    ]
    if pretool:
        cfg["hooks"]["PreToolUse"] = pretool
    else:
        cfg.get("hooks", {}).pop("PreToolUse", None)
        if not cfg.get("hooks"):
            cfg.pop("hooks", None)

    settings_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    click.echo(f"Removed CodeBrain PreToolUse hook from {settings_path}")


# ------------------------------------------------------------------ agent
@cli.command()
@click.pass_context
@_safe_command
def agent(ctx: click.Context) -> None:
    """Generate agent integration files (CLAUDE.md, context.json, MCP config)."""
    from codebrain.agent_bridge import write_agent_files

    repo_root: Path = ctx.obj["repo_root"]
    _require_index(repo_root)
    written = write_agent_files(repo_root)
    click.echo(f"Generated {len(written)} agent integration files:")
    for f in written:
        click.echo(f"  {f}")


# ------------------------------------------------------------------ resolve
@cli.command()
@click.argument("target")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def resolve(ctx: click.Context, target: str, as_json: bool) -> None:
    """Resolve an import string to graph node IDs."""
    from codebrain.graph.store import GraphStore
    from codebrain.resolver import ModuleResolver

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        resolver = ModuleResolver(store)
        results = resolver.resolve(target)

    if as_json:
        click.echo(json.dumps({"target": target, "resolved": results}, indent=2))
    else:
        if not results:
            click.echo(f"Could not resolve '{target}'.")
        else:
            click.echo(f"Resolved '{target}':")
            for r in results:
                click.echo(f"  {r}")


# ------------------------------------------------------------------ diff
@cli.command(name="diff")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def diff_cmd(ctx: click.Context, as_json: bool) -> None:
    """Show files changed since last index (added/modified/deleted)."""
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import discover_files
    from codebrain.utils import file_hash, normalize_path

    repo_root: Path = ctx.obj["repo_root"]
    disk_files = discover_files(repo_root)
    disk_map: dict[str, str] = {}
    for fp in disk_files:
        rel = normalize_path(fp, repo_root)
        disk_map[rel] = file_hash(fp)

    with GraphStore(_require_index(repo_root)) as store:
        rows = store.conn.execute("SELECT path, content_hash FROM files").fetchall()
        all_stored = {row["path"]: row["content_hash"] for row in rows}

    added = [f for f in disk_map if f not in all_stored]
    deleted = [f for f in all_stored if f not in disk_map]
    modified = [
        f for f in disk_map
        if f in all_stored and disk_map[f] != all_stored[f]
    ]

    result = {"added": sorted(added), "modified": sorted(modified), "deleted": sorted(deleted)}

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        total = len(added) + len(modified) + len(deleted)
        if total == 0:
            click.echo("Index is up to date.")
        else:
            click.echo(f"Changes since last index ({total} files):")
            for f in sorted(added):
                click.echo(f"  + {f}")
            for f in sorted(modified):
                click.echo(f"  ~ {f}")
            for f in sorted(deleted):
                click.echo(f"  - {f}")


# ------------------------------------------------------------------ ask
@cli.command()
@click.argument("question")
@click.option("--no-llm", is_flag=True, help="Skip LLM, use only structural data.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def ask(ctx: click.Context, question: str, no_llm: bool, as_json: bool) -> None:
    """Ask a natural language question about the codebase."""
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    db = _require_index(repo_root)

    with GraphStore(db) as store:
        comp = ComprehensionEngine(store)
        result = comp.answer_question(question)

    # Try LLM enhancement
    if not no_llm:
        try:
            from codebrain.llm import LLMNarrator, load_llm_settings

            settings = load_llm_settings(repo_root)
            if settings.enabled and settings.api_keys:
                with GraphStore(db) as store:
                    narrator = LLMNarrator(
                        store, settings,
                        cache_dir=repo_root / CODEBRAIN_DIR,
                    )
                    result = narrator.ask(question)
        except ImportError:
            pass

    if as_json:
        click.echo(json.dumps(result, indent=2, default=str))
        return

    click.echo(click.style(f"\nQuestion: {question}\n", fg="cyan"))

    # Show LLM answer if available
    if result.get("llm_answer"):
        click.echo(click.style("[AI Answer]", fg="green", bold=True))
        click.echo(result["llm_answer"])
        click.echo()

    # Show structural answer
    click.echo(click.style("[Structural Answer]", fg="yellow", bold=True))
    click.echo(result["answer"])
    click.echo()

    # Suggestions
    if result.get("suggestions"):
        click.echo(click.style("Suggested follow-ups:", fg="blue"))
        for s in result["suggestions"]:
            click.echo(f"  - {s}")
    click.echo()




# ------------------------------------------------------------------ serve
@cli.command()
@click.option("--host", default="127.0.0.1", help="Host to bind to.")
@click.option("--port", default=8484, help="Port to listen on.")
@click.option(
    "--projects", "project_dirs", multiple=True,
    type=click.Path(exists=True, file_okay=False),
    help="Additional project directories to serve (repeatable).",
)
@click.option("--watch", is_flag=True, help="Also start file watcher for incremental validation.")
@click.option("--discover", is_flag=True, help="Auto-discover sibling projects with .codebrain databases.")
@click.pass_context
@_safe_command
def serve(ctx: click.Context, host: str, port: int, project_dirs: tuple[str, ...], watch: bool, discover: bool) -> None:
    """Start the REST API server (requires fastapi + uvicorn)."""
    try:
        import uvicorn
    except ImportError:
        click.echo("Error: 'uvicorn' not installed. Install with: pip install codebrain[api]", err=True)
        sys.exit(1)

    from codebrain.api import app, configure, configure_multi

    repo_root: Path = ctx.obj["repo_root"]
    _require_index(repo_root)
    configure(repo_root)

    # Auto-discover sibling project directories
    if discover:
        parent = repo_root.parent
        discovered = []
        for d in sorted(parent.iterdir()):
            if d.is_dir() and d != repo_root and (d / CODEBRAIN_DIR / DB_FILENAME).exists():
                discovered.append(str(d))
                click.echo(f"  ~ discovered: {d.name} ({d})")
        project_dirs = tuple(project_dirs) + tuple(discovered)

    if project_dirs:
        extra = []
        for d in project_dirs:
            p = Path(d).resolve()
            db = _db_path(p)
            if db.exists():
                extra.append(p)
                click.echo(f"  + project: {p.name} ({p})")
            else:
                click.echo(f"  ! skipping {p.name} (not indexed)", err=True)
        if extra:
            configure_multi(extra)

    if watch:
        from codebrain.watcher.file_watcher import start_watching_background
        db = _db_path(repo_root)
        observer, handler = start_watching_background(repo_root, db)
        app.state.watcher_handler = handler
        click.echo("File watcher started (validates on save).")

    click.echo(f"Starting CodeBrain API on http://{host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")


# ------------------------------------------------------------------ export
@cli.group()
def export() -> None:
    """Export the knowledge graph in various formats."""
    pass


# ------------------------------------------------------------------ explain
@cli.group()
def explain() -> None:
    """AI-powered explanations using Grok LLM."""
    pass


@explain.command(name="system")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def explain_system(ctx: click.Context, as_json: bool) -> None:
    """AI-generated explanation of the codebase architecture."""
    from codebrain.graph.store import GraphStore
    from codebrain.llm import LLMNarrator, load_llm_settings

    repo_root: Path = ctx.obj["repo_root"]
    settings = load_llm_settings(repo_root)
    if not settings.enabled:
        click.echo(click.style("Error: LLM not configured. Set CODEBRAIN_LLM_API_KEYS or add [llm] to .codebrain.toml.", fg="red"), err=True)
        sys.exit(1)

    cache_dir = repo_root / CODEBRAIN_DIR
    with GraphStore(_require_index(repo_root)) as store:
        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
        result = narrator.explain_system()

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result.get("llm_explanation"):
            click.echo(click.style("AI Explanation", bold=True))
            click.echo(result["llm_explanation"])
            click.echo()
        click.echo(click.style("Structural Summary", bold=True))
        click.echo(f"  {result['summary']}")
        click.echo(f"  {result['health_summary']}")
        if result.get("recommendations"):
            click.echo(click.style("Recommendations:", bold=True))
            for rec in result["recommendations"]:
                click.echo(f"  - {rec}")


@explain.command(name="module")
@click.argument("file")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def explain_module(ctx: click.Context, file: str, as_json: bool) -> None:
    """AI-generated explanation of a module."""
    from codebrain.graph.store import GraphStore
    from codebrain.llm import LLMNarrator, load_llm_settings

    repo_root: Path = ctx.obj["repo_root"]
    settings = load_llm_settings(repo_root)
    if not settings.enabled:
        click.echo(click.style("Error: LLM not configured. Set CODEBRAIN_LLM_API_KEYS or add [llm] to .codebrain.toml.", fg="red"), err=True)
        sys.exit(1)

    cache_dir = repo_root / CODEBRAIN_DIR
    with GraphStore(_require_index(repo_root)) as store:
        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
        result = narrator.explain_module(file)

    if "error" in result:
        click.echo(click.style(f"Error: {result['error']}", fg="red"), err=True)
        sys.exit(1)

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result.get("llm_explanation"):
            click.echo(click.style("AI Explanation", bold=True))
            click.echo(result["llm_explanation"])
            click.echo()
        click.echo(click.style("Structural Summary", bold=True))
        click.echo(f"  {result['summary']}")
        click.echo(f"  Importance: {result['importance']}")
        click.echo(f"  {result['dependencies']}")


@explain.command(name="symbol")
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def explain_symbol(ctx: click.Context, name: str, as_json: bool) -> None:
    """AI-generated explanation of a symbol."""
    from codebrain.graph.query import QueryEngine
    from codebrain.graph.store import GraphStore
    from codebrain.llm import LLMNarrator, load_llm_settings

    repo_root: Path = ctx.obj["repo_root"]
    settings = load_llm_settings(repo_root)
    if not settings.enabled:
        click.echo(click.style("Error: LLM not configured. Set CODEBRAIN_LLM_API_KEYS or add [llm] to .codebrain.toml.", fg="red"), err=True)
        sys.exit(1)

    cache_dir = repo_root / CODEBRAIN_DIR
    with GraphStore(_require_index(repo_root)) as store:
        engine = QueryEngine(store)
        nodes = engine.resolve_node(name)
        if not nodes:
            click.echo(f"No symbol found matching '{name}'.", err=True)
            sys.exit(1)

        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
        result = narrator.explain_symbol(nodes[0]["id"])

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result.get("llm_explanation"):
            click.echo(click.style("AI Explanation", bold=True))
            click.echo(result["llm_explanation"])
            click.echo()
        click.echo(click.style("Structural Summary", bold=True))
        click.echo(f"  {result['summary']}")
        click.echo(f"  Importance: {result['importance']}")
        click.echo(f"  {result['usage']}")


@explain.command(name="health")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def explain_health(ctx: click.Context, as_json: bool) -> None:
    """AI-generated health analysis with recommendations."""
    from codebrain.graph.store import GraphStore
    from codebrain.llm import LLMNarrator, load_llm_settings

    repo_root: Path = ctx.obj["repo_root"]
    settings = load_llm_settings(repo_root)
    if not settings.enabled:
        click.echo(click.style("Error: LLM not configured. Set CODEBRAIN_LLM_API_KEYS or add [llm] to .codebrain.toml.", fg="red"), err=True)
        sys.exit(1)

    cache_dir = repo_root / CODEBRAIN_DIR
    with GraphStore(_require_index(repo_root)) as store:
        narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
        result = narrator.explain_health()

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if result.get("llm_explanation"):
            click.echo(click.style("AI Explanation", bold=True))
            click.echo(result["llm_explanation"])
            click.echo()
        click.echo(click.style("Health Score", bold=True))
        click.echo(f"  Score: {result['score']}/100 (Grade: {result['grade']})")
        details = result.get("details", {})
        click.echo(f"  Dead code: {details.get('dead_code_count', 0)} symbols")
        click.echo(f"  Import cycles: {details.get('import_cycles', 0)}")
        click.echo(f"  High-risk hotspots: {details.get('high_risk_hotspots', 0)}")


@export.command(name="dot")
@click.option("--symbol", default=None, help="Limit to subgraph around a symbol.")
@click.option("--file", "file_path", default=None, help="Limit to a specific file.")
@click.option("-o", "--output", default=None, help="Output file path (default: stdout).")
@click.pass_context
@_safe_command
def export_dot(ctx: click.Context, symbol: str | None, file_path: str | None, output: str | None) -> None:
    """Export the graph as Graphviz DOT format."""
    from codebrain.export import GraphExporter
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=symbol, file_path=file_path)
        content = exporter.to_dot(nodes, edges)

    if output:
        Path(output).write_text(content)
        click.echo(f"Written to {output}")
    else:
        click.echo(content)


@export.command(name="mermaid")
@click.option("--symbol", default=None, help="Limit to subgraph around a symbol.")
@click.option("--file", "file_path", default=None, help="Limit to a specific file.")
@click.option("-o", "--output", default=None, help="Output file path (default: stdout).")
@click.pass_context
@_safe_command
def export_mermaid(ctx: click.Context, symbol: str | None, file_path: str | None, output: str | None) -> None:
    """Export the graph as Mermaid flowchart format."""
    from codebrain.export import GraphExporter
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=symbol, file_path=file_path)
        content = exporter.to_mermaid(nodes, edges)

    if output:
        Path(output).write_text(content)
        click.echo(f"Written to {output}")
    else:
        click.echo(content)


@export.command(name="json")
@click.option("--symbol", default=None, help="Limit to subgraph around a symbol.")
@click.option("--file", "file_path", default=None, help="Limit to a specific file.")
@click.option("-o", "--output", default=None, help="Output file path (default: stdout).")
@click.pass_context
@_safe_command
def export_json(ctx: click.Context, symbol: str | None, file_path: str | None, output: str | None) -> None:
    """Export the graph as JSON (nodes + edges)."""
    from codebrain.export import GraphExporter
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=symbol, file_path=file_path)
        content = json.dumps({"nodes": nodes, "edges": edges}, indent=2)

    if output:
        Path(output).write_text(content)
        click.echo(f"Written to {output}")
    else:
        click.echo(content)


@export.command(name="html")
@click.option("-o", "--output", default="codebrain_report.html", help="Output file path.")
@click.pass_context
@_safe_command
def export_html(ctx: click.Context, output: str) -> None:
    """Export a self-contained HTML report."""
    from codebrain.export import GraphExporter
    from codebrain.graph.store import GraphStore

    repo_root: Path = ctx.obj["repo_root"]
    with GraphStore(_require_index(repo_root)) as store:
        exporter = GraphExporter(store)
        content = exporter.to_html_report()

    Path(output).write_text(content)
    click.echo(f"Report written to {output}")


@cli.command()
@click.option("-o", "--output", default=None, help="Output file path (default: <project>-kt.md).")
@click.option("--name", default=None, help="Project name for title.")
@click.option("--no-modules", is_flag=True, help="Skip per-module detail sections.")
@click.option("--hotspots", default=10, type=int, help="Max risk hotspots to include.")
@click.option("--modules", "max_modules", default=15, type=int, help="Max modules to detail.")
@click.pass_context
@_safe_command
def kt(ctx: click.Context, output: str | None, name: str | None, no_modules: bool,
       hotspots: int, max_modules: int) -> None:
    """Generate a Knowledge Transfer document with architectural diagrams."""
    from codebrain.graph.store import GraphStore
    from codebrain.kt import KTGenerator

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _generate() -> str:
        with GraphStore(_require_index(repo_root)) as store:
            gen = KTGenerator(store)
            return gen.generate(
                project_name=name,
                include_module_details=not no_modules,
                max_hotspots=hotspots,
                max_modules=max_modules,
            )

    content = _run_with_timeout(_generate, timeout, "Generating KT document")

    if output is None:
        # Auto-name from project
        project = name or repo_root.name
        output = f"{project}-kt.md"

    Path(output).write_text(content, encoding="utf-8")
    click.echo(f"KT document written to {output}")


@cli.command(name="tour")
@click.option("-o", "--output", default=None, help="Output file (default: stdout).")
@click.option("--name", default=None, help="Project name for title.")
@click.option("--steps", default=15, type=int, help="Max tour stops.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def tour_cmd(ctx: click.Context, output: str | None, name: str | None,
             steps: int, as_json: bool) -> None:
    """Generate a guided architecture tour (dependency-ordered learning path)."""
    from codebrain.graph.store import GraphStore
    from codebrain.tour import TourGenerator

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _generate():
        with GraphStore(_require_index(repo_root)) as store:
            gen = TourGenerator(store)
            if as_json:
                return gen.generate(max_steps=steps)
            return gen.generate_markdown(max_steps=steps, project_name=name)

    result = _run_with_timeout(_generate, timeout, "Generating tour")

    if as_json:
        click.echo(json.dumps(result, indent=2))
    elif output:
        Path(output).write_text(result, encoding="utf-8")
        click.echo(f"Tour written to {output}")
    else:
        click.echo(result)


@cli.command(name="diff-impact")
@click.option("--ref", default=None, help="Git ref to diff against (e.g. main, HEAD~3).")
@click.option("--staged", is_flag=True, help="Only analyze staged changes.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def diff_impact_cmd(ctx: click.Context, ref: str | None, staged: bool,
                    as_json: bool) -> None:
    """Analyze blast radius of git changes before committing."""
    from codebrain.graph.store import GraphStore
    from codebrain.diff_impact import DiffImpactAnalyzer

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _analyze():
        with GraphStore(_require_index(repo_root)) as store:
            analyzer = DiffImpactAnalyzer(store, repo_root)
            return analyzer.analyze(ref=ref, staged_only=staged)

    result = _run_with_timeout(_analyze, timeout, "Analyzing diff impact")

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(result["narrative"])


@cli.command(name="onboard")
@click.option("-o", "--output", default=None, help="Output file (default: <project>-onboarding.md).")
@click.option("--name", default=None, help="Project name for title.")
@click.option("--detail", type=click.Choice(["brief", "standard", "deep"]),
              default="standard", help="Detail level.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def onboard_cmd(ctx: click.Context, output: str | None, name: str | None,
                detail: str, as_json: bool) -> None:
    """Generate a developer onboarding guide for the codebase."""
    from codebrain.graph.store import GraphStore
    from codebrain.onboard import OnboardingGenerator

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _generate() -> str:
        with GraphStore(_require_index(repo_root)) as store:
            gen = OnboardingGenerator(store)
            return gen.generate(
                project_name=name,
                detail_level=detail,
            )

    content = _run_with_timeout(_generate, timeout, "Generating onboarding guide")

    if output is None:
        project = name or repo_root.name
        output = f"{project}-onboarding.md"

    Path(output).write_text(content, encoding="utf-8")
    click.echo(f"Onboarding guide written to {output}")


@cli.command(name="kt-video")
@click.option("-o", "--output", default=None, help="Output directory (default: <project>-kt-video).")
@click.option("--name", default=None, help="Project name for title.")
@click.option("--hotspots", default=5, type=int, help="Max risk hotspots to feature.")
@click.pass_context
@_safe_command
def kt_video(ctx: click.Context, output: str | None, name: str | None, hotspots: int) -> None:
    """Generate a Remotion video project for KT presentations.

    Creates a complete Remotion (React) project with animated architecture
    walkthrough. After generation, run:

        cd <output-dir> && npm install && npx remotion render KTVideo out/kt.mp4
    """
    from codebrain.graph.store import GraphStore
    from codebrain.kt_video import KTVideoGenerator

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    if output is None:
        project = name or repo_root.name
        output = f"{project}-kt-video"

    def _generate() -> Path:
        with GraphStore(_require_index(repo_root)) as store:
            gen = KTVideoGenerator(store)
            return gen.generate(
                output,
                project_name=name,
                max_hotspots=hotspots,
            )

    result = _run_with_timeout(_generate, timeout, "Generating video project")
    click.echo(f"Remotion project generated at: {result}")
    click.echo(f"\nTo render the video:")
    click.echo(f"  cd {result}")
    click.echo(f"  npm install")
    click.echo(f"  npx remotion render KTVideo out/kt-video.mp4")


# ---------------------------------------------------------------------------
# Migration commands
# ---------------------------------------------------------------------------

@cli.command(name="migrate-plan")
@click.option("-o", "--output", default=None, help="Output file (default: stdout summary).")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def migrate_plan(ctx: click.Context, output: str | None, as_json: bool) -> None:
    """Generate a dependency-ordered migration plan.

    Analyzes the codebase and outputs a phased rewrite plan:
    leaf modules first, orchestrators last.
    """
    from codebrain.graph.store import GraphStore
    from codebrain.migration import MigrationPlanGenerator

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _generate():
        with GraphStore(_require_index(repo_root)) as store:
            gen = MigrationPlanGenerator(store)
            plan = gen.generate_plan()
            if as_json:
                return json.dumps(plan, indent=2)
            if output:
                return gen.to_markdown(plan)
            # Summary for stdout
            lines = [f"Migration Plan: {plan['total_phases']} phases, "
                     f"{plan['total_files']} files, {plan['total_symbols']} symbols\n"]
            for phase in plan["phases"]:
                lines.append(f"  Phase {phase['phase']}: {phase['label']} "
                             f"({phase['module_count']} modules, "
                             f"complexity: {phase['complexity']})")
            return "\n".join(lines)

    content = _run_with_timeout(_generate, timeout, "Generating migration plan")

    if output:
        Path(output).write_text(content, encoding="utf-8")
        click.echo(f"Migration plan written to {output}")
    else:
        click.echo(content)


@cli.command(name="api-contracts")
@click.option("--file", "file_path", default=None, help="Extract contracts for a specific file.")
@click.option("-o", "--output", default=None, help="Output file (default: stdout).")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def api_contracts(ctx: click.Context, file_path: str | None, output: str | None,
                  as_json: bool) -> None:
    """Extract public API contracts from the codebase.

    Shows function signatures, class interfaces, callers/callees,
    and data flow paths — the spec the new code must match.
    """
    from codebrain.graph.store import GraphStore
    from codebrain.migration import ContractExtractor

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _generate():
        with GraphStore(_require_index(repo_root)) as store:
            ext = ContractExtractor(store)
            result = ext.extract(file_path=file_path)
            if as_json:
                return json.dumps(result, indent=2)
            return ext.to_markdown(result)

    content = _run_with_timeout(_generate, timeout, "Extracting contracts")

    if output:
        Path(output).write_text(content, encoding="utf-8")
        click.echo(f"Contracts written to {output}")
    else:
        click.echo(content)


@cli.command(name="migrate-status")
@click.argument("new_project", type=click.Path(exists=True))
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def migrate_status(ctx: click.Context, new_project: str, as_json: bool) -> None:
    """Compare old and new codebases to track migration progress.

    Current project = old codebase. NEW_PROJECT = path to new codebase
    (must be indexed with 'brain init' first).
    """
    from codebrain.graph.store import GraphStore
    from codebrain.migration import MigrationTracker

    repo_root: Path = ctx.obj["repo_root"]
    new_root = Path(new_project)
    new_db = new_root / ".codebrain" / "graph.db"
    if not new_db.exists():
        click.echo(click.style(
            f"Error: New project not indexed. Run: cd {new_project} && brain init",
            fg="red",
        ), err=True)
        sys.exit(1)

    with GraphStore(_require_index(repo_root)) as old_store:
        with GraphStore(new_db) as new_store:
            tracker = MigrationTracker()
            result = tracker.compare(old_store, new_store)

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        s = result["summary"]
        click.echo(f"Migration Status: {s['coverage_pct']}% coverage\n")
        click.echo(f"  Migrated: {s['migrated']}")
        click.echo(f"  Partial:  {s['partial']}")
        click.echo(f"  Pending:  {s['pending']}")
        click.echo(f"  Total:    {s['total_symbols']}")
        if result["unmapped_new_symbols"]:
            click.echo(f"\n  New symbols (not in old): {len(result['unmapped_new_symbols'])}")


@cli.command(name="migrate-report")
@click.argument("new_project", type=click.Path(exists=True))
@click.option("-o", "--output", default=None, help="Output file.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def migrate_report(ctx: click.Context, new_project: str, output: str | None,
                   as_json: bool) -> None:
    """Generate a full equivalence report between old and new codebases.

    Compares API coverage, class hierarchies, call chains, and
    dependency structure. Current project = old, NEW_PROJECT = new.
    """
    from codebrain.graph.store import GraphStore
    from codebrain.migration import EquivalenceReporter

    repo_root: Path = ctx.obj["repo_root"]
    new_root = Path(new_project)
    new_db = new_root / ".codebrain" / "graph.db"
    if not new_db.exists():
        click.echo(click.style(
            f"Error: New project not indexed. Run: cd {new_project} && brain init",
            fg="red",
        ), err=True)
        sys.exit(1)

    timeout = _get_timeout(ctx)

    def _generate():
        with GraphStore(_require_index(repo_root)) as old_store:
            with GraphStore(new_db) as new_store:
                reporter = EquivalenceReporter()
                result = reporter.report(old_store, new_store)
                if as_json:
                    return json.dumps(result, indent=2)
                return reporter.to_markdown(result)

    content = _run_with_timeout(_generate, timeout, "Generating equivalence report")

    if output:
        Path(output).write_text(content, encoding="utf-8")
        click.echo(f"Report written to {output}")
    else:
        click.echo(content)


# ── Modernization commands ────────────────────────────────────────────


@cli.command(name="modernize-spec")
@click.option("--module", default=None, help="Generate spec for a single module.")
@click.option("--target-stack", default="", help="Target tech stack description.")
@click.option("--guidelines", default="", help="Additional rewrite guidelines.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("-o", "--output", default=None, help="Output file.")
@click.option("--max-modules", default=50, help="Max modules in Markdown output.")
@click.pass_context
@_safe_command
def modernize_spec(ctx: click.Context, module: str | None, target_stack: str,
                   guidelines: str, as_json: bool, output: str | None,
                   max_modules: int) -> None:
    """Generate a modernization/rewrite spec from the indexed codebase.

    Produces a comprehensive specification that an AI agent can follow
    to rewrite each module — with contracts, dependencies, call chains,
    and test scenarios.

    Use --module to generate for a single file, or omit for the full codebase.
    """
    from codebrain.graph.store import GraphStore
    from codebrain.modernize import SpecGenerator

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _generate():
        with GraphStore(_require_index(repo_root)) as store:
            gen = SpecGenerator(store)
            if module:
                spec = gen.generate_module_spec(module)
                if as_json:
                    return json.dumps(spec, indent=2)
                # Wrap in a minimal full spec for markdown rendering
                full = gen.generate_full_spec(
                    target_stack=target_stack, guidelines=guidelines,
                )
                full["module_specs"] = {module: spec}
                full["total_modules"] = 1
                return gen.to_markdown(full, max_modules=1)
            else:
                spec = gen.generate_full_spec(
                    target_stack=target_stack, guidelines=guidelines,
                )
                if as_json:
                    return json.dumps(spec, indent=2)
                return gen.to_markdown(spec, max_modules=max_modules)

    content = _run_with_timeout(_generate, timeout, "Generating modernization spec")

    if output:
        Path(output).write_text(content, encoding="utf-8")
        click.echo(f"Spec written to {output}")
    else:
        click.echo(content)


@cli.command(name="modernize")
@click.argument("new_project", required=False, type=click.Path(exists=True))
@click.option("--target-stack", default="", help="Target tech stack description.")
@click.option("--guidelines", default="", help="Additional rewrite guidelines.")
@click.option("-o", "--output", default=None, help="Output file.")
@click.pass_context
@_safe_command
def modernize(ctx: click.Context, new_project: str | None, target_stack: str,
              guidelines: str, output: str | None) -> None:
    """Full modernization workflow.

    Without NEW_PROJECT: generates a modernization spec for the current codebase.
    With NEW_PROJECT: generates spec + progress report comparing old vs new.
    """
    from codebrain.graph.store import GraphStore
    from codebrain.modernize import ModernizationWorkflow

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _run():
        with GraphStore(_require_index(repo_root)) as old_store:
            workflow = ModernizationWorkflow(repo_root, old_store)
            parts = []

            # Always generate spec
            spec_md = workflow.step1_generate_spec(
                target_stack=target_stack, guidelines=guidelines,
            )
            parts.append(spec_md)

            # If new project provided, add progress tracking
            if new_project:
                new_root = Path(new_project)
                new_db = new_root / ".codebrain" / "graph.db"
                if not new_db.exists():
                    parts.append(
                        f"\n## Error\nNew project not indexed. "
                        f"Run: cd {new_project} && brain init\n"
                    )
                else:
                    with GraphStore(new_db) as new_store:
                        parts.append("\n---\n")
                        equiv_md = workflow.step3_equivalence_report(new_store)
                        parts.append(equiv_md)

            return "\n".join(parts)

    content = _run_with_timeout(_run, timeout, "Running modernization workflow")

    if output:
        Path(output).write_text(content, encoding="utf-8")
        click.echo(f"Output written to {output}")
    else:
        click.echo(content)


@cli.command(name="rewrite")
@click.option("-o", "--output-dir", required=True, type=click.Path(),
              help="Directory for the rewritten code.")
@click.option("--target-stack", default="", help="Target tech stack description.")
@click.option("--guidelines", default="", help="Additional rewrite guidelines.")
@click.option("--provider", default="", help="LLM provider: ollama, openai, anthropic, azure.")
@click.option("--model", default="", help="LLM model name.")
@click.option("--base-url", default="", help="LLM API base URL.")
@click.option("--api-key", default="", help="LLM API key.")
@click.option("--module", default=None, help="Rewrite a single module only.")
@click.option("--max-retries", default=3, help="Max retry attempts per module.")
@click.option("--dry-run", is_flag=True, help="Generate prompts without calling LLM.")
@click.pass_context
@_safe_command
def rewrite(ctx: click.Context, output_dir: str, target_stack: str,
            guidelines: str, provider: str, model: str, base_url: str,
            api_key: str, module: str | None, max_retries: int,
            dry_run: bool) -> None:
    """Rewrite codebase using AI with structural validation.

    Reads the indexed codebase, generates rewrite specs, calls an LLM
    to rewrite each module, validates structural equivalence after each
    step, and retries with error feedback if validation fails.

    Works with any LLM: Ollama (local), OpenAI, Anthropic, Azure, or
    any OpenAI-compatible endpoint.

    Examples:

        brain rewrite -o ./modernized --provider ollama --model codellama:13b

        brain rewrite -o ./new-app --provider anthropic --target-stack "FastAPI"

        brain rewrite -o ./out --dry-run  # preview without calling LLM
    """
    from codebrain.graph.store import GraphStore
    from codebrain.rewriter import RewriteEngine, create_client

    repo_root: Path = ctx.obj["repo_root"]
    out_path = Path(output_dir)

    if not dry_run:
        client = create_client(
            provider=provider, base_url=base_url,
            model=model, api_key=api_key,
        )
        if not client.is_available():
            click.echo(click.style(
                "Error: LLM endpoint not reachable. Check provider/URL/API key.",
                fg="red",
            ), err=True)
            click.echo("  Set via --provider, --base-url, --model, --api-key", err=True)
            click.echo("  Or env vars: CODEBRAIN_LLM_PROVIDER, CODEBRAIN_LLM_BASE_URL, "
                       "CODEBRAIN_LLM_MODEL, CODEBRAIN_LLM_API_KEY", err=True)
            sys.exit(1)
    else:
        client = None

    def _progress(fp: str, status: str) -> None:
        icons = {"rewriting": "⟳", "success": "✓", "partial": "~",
                 "failed": "✗", "skipped": "−"}
        icon = icons.get(status, "?")
        click.echo(f"  {icon} {fp} [{status}]")

    click.echo(f"Rewriting to: {out_path}")
    if dry_run:
        click.echo("(dry run — no LLM calls)")

    with GraphStore(_require_index(repo_root)) as store:
        engine = RewriteEngine(
            old_root=repo_root, store=store,
            client=client,  # type: ignore
            max_retries=max_retries,
        )

        modules_list = [module] if module else None
        result = engine.rewrite_all(
            output_dir=out_path,
            target_stack=target_stack,
            guidelines=guidelines,
            modules=modules_list,
            dry_run=dry_run,
            on_progress=_progress,
        )

    click.echo(f"\nDone: {result.succeeded} succeeded, "
               f"{result.failed} failed, {result.skipped} skipped "
               f"({result.total_tokens} tokens)")

    if result.failed > 0:
        click.echo(click.style(
            f"\n{result.failed} modules failed. Run with --dry-run to check prompts.",
            fg="yellow",
        ))


@cli.command(name="translate")
@click.option("-o", "--output-dir", required=True, type=click.Path(),
              help="Directory for the translated code.")
@click.option("--target-lang", required=True,
              type=click.Choice(["go", "java", "kotlin", "rust", "typescript", "csharp", "python", "dart"]),
              help="Target programming language.")
@click.option("--target-stack", default="", help="Target framework (e.g., gin, spring, fastapi).")
@click.option("--guidelines", default="", help="Additional translation guidelines.")
@click.option("--provider", default="", help="LLM provider: ollama, openai, anthropic, azure.")
@click.option("--model", default="", help="LLM model name.")
@click.option("--base-url", default="", help="LLM API base URL.")
@click.option("--api-key", default="", help="LLM API key.")
@click.option("--module", default=None, help="Translate a single module only.")
@click.option("--max-retries", default=3, help="Max retry attempts per module.")
@click.option("--dry-run", is_flag=True, help="Generate prompts without calling LLM.")
@click.pass_context
@_safe_command
def translate(ctx: click.Context, output_dir: str, target_lang: str,
              target_stack: str, guidelines: str, provider: str, model: str,
              base_url: str, api_key: str, module: str | None,
              max_retries: int, dry_run: bool) -> None:
    """Translate codebase to a different programming language.

    Uses AI with structural validation to translate each module,
    preserving public API contracts. Optionally verifies the output
    compiles with the target language toolchain.

    Examples:

        brain translate -o ./app-go --target-lang go --provider ollama --model codellama:13b

        brain translate -o ./app-kt --target-lang kotlin --target-stack ktor --provider anthropic

        brain translate -o ./out --target-lang rust --dry-run
    """
    from codebrain.graph.store import GraphStore
    from codebrain.rewriter import RewriteEngine, create_client

    repo_root: Path = ctx.obj["repo_root"]
    out_path = Path(output_dir)

    if not dry_run:
        client = create_client(
            provider=provider, base_url=base_url,
            model=model, api_key=api_key,
        )
        if not client.is_available():
            click.echo(click.style(
                "Error: LLM endpoint not reachable. Check provider/URL/API key.",
                fg="red",
            ), err=True)
            click.echo("  Set via --provider, --base-url, --model, --api-key", err=True)
            click.echo("  Or env vars: CODEBRAIN_LLM_PROVIDER, CODEBRAIN_LLM_BASE_URL, "
                       "CODEBRAIN_LLM_MODEL, CODEBRAIN_LLM_API_KEY", err=True)
            sys.exit(1)
    else:
        client = None

    def _progress(fp: str, status: str) -> None:
        icons = {"translating": "->", "success": "+", "partial": "~",
                 "failed": "x", "skipped": "-", "unverified": "?",
                 "building": "B", "build OK": "+"}
        icon = icons.get(status, "?")
        if fp:
            click.echo(f"  {icon} {fp} [{status}]")
        else:
            click.echo(f"  {icon} [{status}]")

    click.echo(f"Translating to {target_lang}: {out_path}")
    if target_stack:
        click.echo(f"Target stack: {target_stack}")
    if dry_run:
        click.echo("(dry run - no LLM calls)")

    with GraphStore(_require_index(repo_root)) as store:
        engine = RewriteEngine(
            old_root=repo_root, store=store,
            client=client,  # type: ignore
            max_retries=max_retries,
            target_lang=target_lang,
        )

        modules_list = [module] if module else None
        result = engine.rewrite_all(
            output_dir=out_path,
            target_stack=target_stack,
            guidelines=guidelines,
            modules=modules_list,
            dry_run=dry_run,
            on_progress=_progress,
        )

    click.echo(f"\nDone: {result.succeeded} succeeded, "
               f"{result.failed} failed, {result.skipped} skipped "
               f"({result.total_tokens} tokens)")

    # Report construct warnings
    all_warnings = []
    for m in result.modules:
        for w in m.warnings:
            if w.startswith("["):
                all_warnings.append(w)
    if all_warnings:
        click.echo(click.style(
            f"\n{len(all_warnings)} translation warning(s) — review manually:",
            fg="yellow",
        ))
        for w in all_warnings[:10]:
            click.echo(f"  ! {w}")
        if len(all_warnings) > 10:
            click.echo(f"  ... and {len(all_warnings) - 10} more")

    if result.failed > 0:
        click.echo(click.style(
            f"\n{result.failed} modules failed. Run with --dry-run to check prompts.",
            fg="yellow",
        ))


@cli.command(name="rewrite-verify")
@click.option("-o", "--output-dir", required=True, type=click.Path(),
              help="Directory for the rewritten code.")
@click.option("--target-stack", default="", help="Target tech stack description.")
@click.option("--guidelines", default="", help="Additional rewrite guidelines.")
@click.option("--provider", default="", help="LLM provider: ollama, openai, anthropic, azure.")
@click.option("--model", default="", help="LLM model name.")
@click.option("--base-url", default="", help="LLM API base URL.")
@click.option("--api-key", default="", help="LLM API key.")
@click.option("--max-retries", default=3, help="Max retry attempts per module.")
@click.option("--max-fix-rounds", default=2, help="Max test-fix cycles.")
@click.option("--json", "as_json", is_flag=True, help="JSON output.")
@click.pass_context
@_safe_command
def rewrite_verify(ctx: click.Context, output_dir: str, target_stack: str,
                   guidelines: str, provider: str, model: str, base_url: str,
                   api_key: str, max_retries: int, max_fix_rounds: int,
                   as_json: bool) -> None:
    """Full pipeline: rewrite -> validate -> test -> fix -> verify.

    Rewrites all modules, generates tests for the rewritten code,
    runs them, and feeds failures back to the LLM for fixing.
    Loops until tests pass or fix rounds are exhausted.

    Examples:

        brain rewrite-verify -o ./modernized --provider openai --model gpt-4o

        brain rewrite-verify -o ./out --provider ollama --target-stack "FastAPI"
    """
    from codebrain.graph.store import GraphStore
    from codebrain.rewriter import create_client, rewrite_and_verify

    repo_root: Path = ctx.obj["repo_root"]
    out_path = Path(output_dir)

    client = create_client(
        provider=provider, base_url=base_url,
        model=model, api_key=api_key,
    )
    if not client.is_available():
        click.echo(click.style(
            "Error: LLM endpoint not reachable. Check provider/URL/API key.",
            fg="red",
        ), err=True)
        sys.exit(1)

    def _progress(stage: str, fp: str, detail: str = "") -> None:
        icons = {
            "rewrite": "⟳", "test-gen": "🧪", "test-run": "▶",
            "fix": "🔧",
        }
        icon = icons.get(stage, "•")
        parts = [f"  {icon} [{stage}]"]
        if fp:
            parts.append(fp)
        if detail:
            parts.append(f"({detail})")
        click.echo(" ".join(parts))

    click.echo(f"Full pipeline: rewrite → validate → test → fix")
    click.echo(f"Output: {out_path}")
    click.echo(f"Fix rounds: {max_fix_rounds}\n")

    with GraphStore(_require_index(repo_root)) as store:
        result = rewrite_and_verify(
            old_root=repo_root,
            store=store,
            client=client,
            output_dir=out_path,
            target_stack=target_stack,
            guidelines=guidelines,
            max_retries=max_retries,
            max_fix_rounds=max_fix_rounds,
            on_progress=_progress,
        )

    if as_json:
        click.echo(json.dumps(result.to_dict(), indent=2))
    else:
        click.echo(f"\n{'='*50}")
        click.echo(f"Rewrite: {result.rewrite.succeeded} succeeded, "
                    f"{result.rewrite.failed} failed")
        click.echo(f"Tests: {result.tests_generated} generated, "
                    f"{result.tests_passed} passed, "
                    f"{result.tests_failed} failed")
        click.echo(f"Fixes: {result.fix_attempts} attempted, "
                    f"{result.fix_successes} succeeded")
        click.echo(f"Tokens: {result.total_tokens}")
        click.echo(f"Time: {result.total_time_ms}ms")

        if result.test_results:
            click.echo(f"\nTest details:")
            for t in result.test_results:
                status = click.style("PASS", fg="green") if t.passed else click.style("FAIL", fg="red")
                click.echo(f"  {status} {t.module_file} ({t.test_count} tests, {t.failures} failures)")


# ---------------------------------------------------------------------------
# Autonomous actions (M27)
# ---------------------------------------------------------------------------


@cli.command(name="gen-test")
@click.argument("symbol", default="")
@click.option("--gaps", is_flag=True, help="Generate tests for top untested symbols.")
@click.option("--file", "file_path", default=None, help="Generate for all untested in a file.")
@click.option("--count", default=5, help="Max symbols to generate for (with --gaps).")
@click.option("--min-risk", default=0.3, help="Minimum risk score (with --gaps).")
@click.option("-o", "--output-dir", default=None, type=click.Path(), help="Output directory.")
@click.option("--run", "run_tests", is_flag=True, help="Run generated tests to verify.")
@click.option("--dry-run", is_flag=True, help="Show what would be generated.")
@click.option("--provider", default="", help="LLM provider.")
@click.option("--model", default="", help="LLM model name.")
@click.option("--base-url", default="", help="LLM API base URL.")
@click.option("--api-key", default="", help="LLM API key.")
@click.option("--json", "as_json", is_flag=True, help="JSON output.")
@click.pass_context
@_safe_command
def gen_test(ctx: click.Context, symbol: str, gaps: bool, file_path: str | None,
             count: int, min_risk: float, output_dir: str | None,
             run_tests: bool, dry_run: bool,
             provider: str, model: str, base_url: str, api_key: str,
             as_json: bool) -> None:
    """Generate tests for untested symbols using AI.

    Uses structural context (fingerprints, call graphs, coverage gaps)
    to produce targeted, runnable pytest tests.

    Examples:

        brain gen-test calculate_total

        brain gen-test --gaps --count 10

        brain gen-test --file src/billing.py -o tests/generated/
    """
    repo_root = ctx.obj["repo_root"]
    db = _require_index(repo_root)

    from codebrain.graph.store import GraphStore
    from codebrain.rewriter import create_client
    from codebrain.actions.test_gen import TestGenerator

    if dry_run:
        click.echo("Dry run — showing what would be generated")

    client = create_client(provider, base_url, model, api_key)

    out = Path(output_dir) if output_dir else None

    with GraphStore(db) as store:
        gen = TestGenerator(store, repo_root, client)

        if gaps:
            results = gen.generate_for_gaps(
                min_risk=min_risk, max_count=count,
                output_dir=out, run_tests=run_tests,
            )
        elif file_path:
            results = gen.generate_for_file(
                file_path, output_dir=out, run_tests=run_tests,
            )
        elif symbol:
            results = [gen.generate_for_symbol(
                symbol, output_dir=out, run_tests=run_tests,
            )]
        else:
            click.echo("Specify a symbol, --gaps, or --file.", err=True)
            sys.exit(1)

    if as_json:
        data = [
            {
                "symbol": r.symbol_name,
                "file": r.file_path,
                "test_file": r.test_file_path,
                "test_count": r.test_count,
                "validated": r.validated,
                "ran_successfully": r.ran_successfully,
                "error": r.error,
                "tokens": r.tokens_used,
            }
            for r in results
        ]
        click.echo(json.dumps(data, indent=2))
    else:
        total_tests = 0
        for r in results:
            icon = click.style("✓", fg="green") if r.validated else click.style("✗", fg="red")
            click.echo(f"  {icon} {r.symbol_name}: {r.test_count} tests → {r.test_file_path}")
            if r.error:
                click.echo(click.style(f"    Error: {r.error}", fg="red"))
            if r.ran_successfully is True:
                click.echo(click.style("    Tests passed!", fg="green"))
            elif r.ran_successfully is False:
                click.echo(click.style("    Tests failed.", fg="yellow"))
            total_tests += r.test_count

        validated = sum(1 for r in results if r.validated)
        click.echo(f"\nGenerated {total_tests} tests for {len(results)} symbols "
                   f"({validated} validated)")


@cli.command(name="review")
@click.option("--base", default="HEAD~1", help="Compare against this git ref.")
@click.option("--files", default=None, help="Comma-separated file paths to review.")
@click.option("--full", is_flag=True, help="Full review with LLM suggestions.")
@click.option("--structural-only", is_flag=True, help="Structural analysis only (no LLM).")
@click.option("--provider", default="", help="LLM provider.")
@click.option("--model", default="", help="LLM model name.")
@click.option("--base-url", default="", help="LLM API base URL.")
@click.option("--api-key", default="", help="LLM API key.")
@click.option("--json", "as_json", is_flag=True, help="JSON output.")
@click.pass_context
@_safe_command
def review(ctx: click.Context, base: str, files: str | None, full: bool,
           structural_only: bool, provider: str, model: str, base_url: str,
           api_key: str, as_json: bool) -> None:
    """Structural code review of changes.

    Analyzes changed files against the knowledge graph: detects breaking
    changes, missing tests, and suggests fixes with full caller context.

    Examples:

        brain review

        brain review --base main --full

        brain review --files src/billing.py,src/api.py
    """
    repo_root = ctx.obj["repo_root"]
    db = _require_index(repo_root)

    from codebrain.graph.store import GraphStore
    from codebrain.actions.reviewer import CodeReviewer

    llm = None
    if full and not structural_only:
        from codebrain.rewriter import create_client
        llm = create_client(provider, base_url, model, api_key)

    with GraphStore(db) as store:
        reviewer = CodeReviewer(store, repo_root, llm)

        if files:
            changed = [f.strip() for f in files.split(",")]
            result = reviewer.review_files(changed, full=full and not structural_only)
        else:
            result = reviewer.review_diff(base=base, full=full and not structural_only)

    if as_json:
        data = {
            "changed_files": result.changed_files,
            "findings": [
                {
                    "severity": f.severity,
                    "category": f.category,
                    "file": f.file_path,
                    "line": f.line,
                    "message": f.message,
                    "suggestion": f.suggestion,
                }
                for f in result.findings
            ],
            "summary": result.summary,
            "risk_score": result.risk_score,
            "test_suggestions": result.test_suggestions,
            "approved": result.approved,
        }
        click.echo(json.dumps(data, indent=2))
    else:
        click.echo(reviewer.to_markdown(result))


@cli.command(name="refactor")
@click.option("--suggest", "suggest_only", is_flag=True, help="Show suggestions only.")
@click.option("--category", default="all",
              type=click.Choice(["all", "dead_code", "cycles", "coupling", "god_class"]),
              help="Category of refactoring to suggest.")
@click.option("--fix", is_flag=True, help="Generate fixes (requires LLM for non-dead-code).")
@click.option("--dry-run", is_flag=True, default=True, help="Don't write changes (default).")
@click.option("--apply", is_flag=True, help="Actually apply changes to files.")
@click.option("--count", default=10, help="Max suggestions to process.")
@click.option("--provider", default="", help="LLM provider.")
@click.option("--model", default="", help="LLM model name.")
@click.option("--base-url", default="", help="LLM API base URL.")
@click.option("--api-key", default="", help="LLM API key.")
@click.option("--json", "as_json", is_flag=True, help="JSON output.")
@click.pass_context
@_safe_command
def refactor(ctx: click.Context, suggest_only: bool, category: str,
             fix: bool, dry_run: bool, apply: bool, count: int,
             provider: str, model: str, base_url: str, api_key: str,
             as_json: bool) -> None:
    """Detect structural problems and generate fixes.

    Finds dead code, import cycles, high coupling, and god classes.
    Can suggest fixes or generate them with LLM assistance.

    Examples:

        brain refactor --suggest

        brain refactor --category dead_code --fix

        brain refactor --category god_class --fix --apply
    """
    repo_root = ctx.obj["repo_root"]
    db = _require_index(repo_root)

    from codebrain.graph.store import GraphStore
    from codebrain.actions.refactor import Refactorer

    llm = None
    if fix and not suggest_only:
        from codebrain.rewriter import create_client
        llm = create_client(provider, base_url, model, api_key)

    actual_dry_run = not apply

    with GraphStore(db) as store:
        refactorer = Refactorer(store, repo_root, llm)
        suggestions = refactorer.suggest(category)[:count]

        if as_json and (suggest_only or not fix):
            data = [
                {
                    "category": s.category,
                    "severity": s.severity,
                    "file": s.file_path,
                    "symbol": s.symbol_name,
                    "message": s.message,
                    "strategy": s.strategy,
                    "effort": s.estimated_effort,
                }
                for s in suggestions
            ]
            click.echo(json.dumps(data, indent=2))
            return

        if not fix or suggest_only:
            # Just show suggestions
            if not suggestions:
                click.echo("No refactoring suggestions found.")
                return
            click.echo(f"Found {len(suggestions)} refactoring opportunities:\n")
            for i, s in enumerate(suggestions, 1):
                sev_color = {"high": "red", "medium": "yellow", "low": "white"}.get(s.severity, "white")
                click.echo(f"  {i}. [{click.style(s.severity.upper(), fg=sev_color)}] {s.message}")
                click.echo(f"     Strategy: {s.strategy} | Effort: {s.estimated_effort}")
                click.echo(f"     File: {s.file_path}")
                click.echo()
            return

        # Generate fixes
        results = [refactorer.fix(s, dry_run=actual_dry_run) for s in suggestions]

        if as_json:
            data = [
                {
                    "category": r.suggestion.category,
                    "symbol": r.suggestion.symbol_name,
                    "file": r.suggestion.file_path,
                    "status": r.status,
                    "error": r.error,
                    "tokens": r.tokens_used,
                    "patch": r.patch[:500] if r.patch else "",
                }
                for r in results
            ]
            click.echo(json.dumps(data, indent=2))
        else:
            for r in results:
                icon = click.style("✓", fg="green") if r.status == "success" else click.style("✗", fg="red")
                click.echo(f"  {icon} {r.suggestion.symbol_name or r.suggestion.file_path}: {r.status}")
                if r.error:
                    click.echo(click.style(f"    Error: {r.error}", fg="red"))
                if r.patch and actual_dry_run:
                    click.echo(f"    Patch preview:\n{r.patch[:300]}")

            succeeded = sum(1 for r in results if r.status == "success")
            click.echo(f"\n{succeeded}/{len(results)} fixes generated"
                       f"{' (dry run)' if actual_dry_run else ''}")


# -------------------------------------------------------- frontend commands

@cli.command(name="components")
@click.option("--tree", is_flag=True, help="Show component hierarchy as a tree.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def components(ctx: click.Context, tree: bool, as_json: bool) -> None:
    """List all frontend components with hierarchy."""
    from codebrain.graph.store import GraphStore
    from codebrain.frontend import FrontendAnalyzer

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = FrontendAnalyzer(store)
        result = _run_with_timeout(
            lambda: analyzer.get_component_tree(),
            timeout,
            "Analyzing components",
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        roots = result.get("roots", [])
        total = result.get("total_components", 0)
        click.echo(f"Components: {total} total, {len(roots)} root(s)\n")
        if tree and result.get("tree"):
            for root_name in roots:
                subtree = result["tree"].get(root_name, {})
                _print_component_tree(subtree, indent=0)
        elif roots:
            for name in roots:
                click.echo(f"  {name}")


def _print_component_tree(node: dict, indent: int = 0) -> None:
    """Print a component tree node recursively."""
    prefix = "  " * indent
    marker = "├── " if indent > 0 else ""
    name = node.get("name", "?")
    file_info = f" ({node['file']})" if node.get("file") else ""
    circular = click.style(" [CIRCULAR]", fg="yellow") if node.get("circular") else ""
    click.echo(f"{prefix}{marker}{click.style(name, bold=True)}{file_info}{circular}")
    for child in node.get("children", []):
        _print_component_tree(child, indent + 1)


@cli.command(name="routes")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def routes(ctx: click.Context, as_json: bool) -> None:
    """List all routes with their target components."""
    from codebrain.graph.store import GraphStore
    from codebrain.frontend import FrontendAnalyzer

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = FrontendAnalyzer(store)
        result = _run_with_timeout(
            lambda: analyzer.get_route_map(),
            timeout,
            "Analyzing routes",
        )

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if not result:
            click.echo("No routes found.")
        else:
            click.echo(f"Routes ({len(result)}):\n")
            for route in result:
                click.echo(f"  {route['path']:30s} → {route['component']:20s} ({route['file']})")


@cli.command(name="frontend-report")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("-o", "--output", "output_file", default=None, help="Write report to file.")
@click.pass_context
@_safe_command
def frontend_report(ctx: click.Context, as_json: bool, output_file: str | None) -> None:
    """Full frontend analysis report."""
    from codebrain.graph.store import GraphStore
    from codebrain.frontend import FrontendAnalyzer

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    with GraphStore(_require_index(repo_root)) as store:
        analyzer = FrontendAnalyzer(store)
        report = _run_with_timeout(
            lambda: analyzer.analyze(),
            timeout,
            "Analyzing frontend",
        )

    if as_json:
        text = json.dumps(report.to_dict(), indent=2)
    else:
        text = analyzer.to_markdown(report)

    if output_file:
        Path(output_file).write_text(text, encoding="utf-8")
        click.echo(f"Report written to {output_file}")
    else:
        click.echo(text)


# ================================================================== cross
# Cross-repo dependency tracking commands
# ==================================================================

@cli.group()
def cross():
    """Cross-repo dependency tracking and impact analysis."""
    pass


@cross.command("register")
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--slug", default=None, help="Short name for this repo (default: directory name).")
@click.pass_context
@_safe_command
def cross_register(ctx: click.Context, path: str, slug: str | None) -> None:
    """Register a repo in the cross-repo registry."""
    from codebrain.cross_registry import CrossRegistry, detect_packages

    repo_path = Path(path).resolve()
    with CrossRegistry() as reg:
        used_slug = reg.register(repo_path, slug=slug)
        packages = detect_packages(repo_path)
    click.echo(f"Registered '{used_slug}' with packages: {', '.join(packages)}")


@cross.command("unregister")
@click.argument("slug")
@_safe_command
def cross_unregister(slug: str) -> None:
    """Remove a repo from the cross-repo registry."""
    from codebrain.cross_registry import CrossRegistry

    with CrossRegistry() as reg:
        if reg.unregister(slug):
            click.echo(f"Unregistered '{slug}'")
        else:
            click.echo(f"Repo '{slug}' not found in registry.")


@cross.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@_safe_command
def cross_list(as_json: bool) -> None:
    """List all registered repos."""
    from codebrain.cross_registry import CrossRegistry

    with CrossRegistry() as reg:
        repos = reg.list_repos()

    if as_json:
        click.echo(json.dumps(repos, indent=2))
    else:
        if not repos:
            click.echo("No repos registered. Use 'brain cross register <path>' to add repos.")
            return
        click.echo(f"Registered repos ({len(repos)}):\n")
        for r in repos:
            pkgs = ", ".join(r["packages"]) if r["packages"] else "(none)"
            click.echo(f"  {r['slug']}")
            click.echo(f"    Path: {r['repo_path']}")
            click.echo(f"    Packages: {pkgs}")
            click.echo()


@cross.command("deps")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@_safe_command
def cross_deps(as_json: bool) -> None:
    """Show inter-repo dependency graph."""
    from codebrain.cross_registry import CrossRegistry
    from codebrain.cross_query import CrossQueryEngine

    with CrossRegistry() as reg:
        engine = CrossQueryEngine(reg)
        result = engine.dependency_graph()

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(result["narrative"])


@cross.command("impact")
@click.argument("symbol")
@click.option("--repo", default=None, help="Repo slug (default: current directory name).")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--depth", default=5, type=int, help="Max BFS depth.")
@click.pass_context
@_safe_command
def cross_impact(ctx: click.Context, symbol: str, repo: str | None,
                 as_json: bool, depth: int) -> None:
    """Cross-repo impact analysis — what breaks across ALL repos."""
    from codebrain.cross_registry import CrossRegistry
    from codebrain.cross_query import CrossQueryEngine

    repo_root: Path = ctx.obj["repo_root"]
    slug = repo or repo_root.name

    with CrossRegistry() as reg:
        engine = CrossQueryEngine(reg)
        result = engine.cross_impact(slug, symbol, max_depth=depth)

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(result["narrative"])


@cross.command("unresolved")
@click.option("--repo", default=None, help="Repo slug (default: current directory name).")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def cross_unresolved(ctx: click.Context, repo: str | None, as_json: bool) -> None:
    """Show imports that point to unregistered external packages."""
    from codebrain.cross_registry import CrossRegistry
    from codebrain.cross_query import CrossQueryEngine

    repo_root: Path = ctx.obj["repo_root"]
    slug = repo or repo_root.name

    with CrossRegistry() as reg:
        engine = CrossQueryEngine(reg)
        result = engine.find_unresolved_imports(slug)

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if not result:
            click.echo("No unresolved cross-repo imports found.")
        else:
            click.echo(f"Unresolved imports ({len(result)}):\n")
            for item in result[:50]:
                click.echo(f"  {item['target']}")
                click.echo(f"    File: {item['file_path']}:{item['line']}")


# ---------------------------------------------------------------------------
# Environment migration commands
# ---------------------------------------------------------------------------

@cli.command(name="env-analyze")
@click.option("-o", "--output", default=None, help="Output file (default: stdout).")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def env_analyze(ctx: click.Context, output: str | None, as_json: bool) -> None:
    """Analyze project infrastructure (deps, Docker, CI, env vars).

    Scans requirements.txt / package.json, Dockerfile, .github/workflows,
    .gitlab-ci.yml, and .env to build an environment profile.
    """
    from codebrain.env_migration import EnvironmentMigrator

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _run():
        migrator = EnvironmentMigrator()
        profile = migrator.analyze(repo_root)
        if as_json:
            return json.dumps(migrator.to_dict(profile), indent=2)
        lines = [f"Language: {profile.language or '(unknown)'}"]
        lines.append(f"Dependencies: {len(profile.dependencies)}")
        lines.append(f"Dockerfile: {'yes' if profile.has_dockerfile else 'no'}")
        if profile.dockerfile_port:
            lines.append(f"  Port: {profile.dockerfile_port}")
        if profile.dockerfile_base_image:
            lines.append(f"  Base image: {profile.dockerfile_base_image}")
        lines.append(f"Docker Compose: {'yes' if profile.has_docker_compose else 'no'}")
        if profile.docker_services:
            lines.append(f"  Services: {', '.join(profile.docker_services)}")
        lines.append(f"CI: {profile.ci_platform or 'none'}")
        if profile.ci_file:
            lines.append(f"  File: {profile.ci_file}")
        lines.append(f"Env vars: {len(profile.env_vars)}")
        return "\n".join(lines)

    content = _run_with_timeout(_run, timeout, "Analyzing environment")

    if output:
        Path(output).write_text(content, encoding="utf-8")
        click.echo(f"Environment profile written to {output}")
    else:
        click.echo(content)


@cli.command(name="env-migrate")
@click.option("-o", "--output", "output_dir", required=True, help="Output directory for generated files.")
@click.option("--target-lang", required=True, help="Target language (go, rust, java, typescript).")
@click.option("--target-stack", default="", help="Target framework/stack (optional).")
@click.pass_context
@_safe_command
def env_migrate(ctx: click.Context, output_dir: str, target_lang: str,
                target_stack: str) -> None:
    """Generate infrastructure files for a target language.

    Reads the current project's environment profile and generates
    Dockerfile, CI config, dependency file, and .env for the target
    language.

    Examples:

        brain env-migrate -o ./app-go --target-lang go

        brain env-migrate -o ./out --target-lang rust --target-stack actix
    """
    from codebrain.env_migration import EnvironmentMigrator

    repo_root: Path = ctx.obj["repo_root"]
    out_path = Path(output_dir)
    timeout = _get_timeout(ctx)

    def _run():
        migrator = EnvironmentMigrator()
        profile = migrator.analyze(repo_root)
        files = migrator.generate(profile, target_lang, target_stack, out_path)
        return files

    files = _run_with_timeout(_run, timeout, "Generating environment files")

    click.echo(f"Generated {len(files)} files in {out_path}:")
    for gf in files:
        click.echo(f"  {gf.path} — {gf.description}")


# ---------------------------------------------------------------------------
# Equivalence test generation
# ---------------------------------------------------------------------------

@cli.command(name="equiv-tests")
@click.argument("new_project_path", type=click.Path(exists=True))
@click.option("-o", "--output-dir", default="", type=click.Path(),
              help="Directory for generated equivalence tests.")
@click.option("--target-lang", default="",
              help="Target language for cross-language tests (e.g., go, java).")
@click.option("--provider", default="", help="LLM provider: ollama, openai, anthropic, azure.")
@click.option("--model", default="", help="LLM model name.")
@click.option("--base-url", default="", help="LLM API base URL.")
@click.option("--api-key", default="", help="LLM API key.")
@click.pass_context
@_safe_command
def equiv_tests(ctx: click.Context, new_project_path: str, output_dir: str,
                target_lang: str, provider: str, model: str,
                base_url: str, api_key: str) -> None:
    """Generate equivalence tests proving old_fn(x) == new_fn(x).

    Compare the current (old) project with NEW_PROJECT_PATH to generate
    tests that verify behavioral equivalence after a migration.

    Examples:

        brain equiv-tests ./rewritten-app -o ./equiv_tests

        brain equiv-tests ./app-go -o ./equiv_tests --target-lang go --provider ollama --model codellama:13b
    """
    from codebrain.equivalence import EquivalenceTestGenerator
    from codebrain.graph.store import GraphStore
    from codebrain.rewriter import create_client

    repo_root: Path = ctx.obj["repo_root"]
    new_root = Path(new_project_path)
    out_path = Path(output_dir) if output_dir else repo_root / "equiv_tests"

    client = create_client(
        provider=provider, base_url=base_url,
        model=model, api_key=api_key,
    )
    if not client.is_available():
        click.echo(click.style(
            "Error: LLM endpoint not reachable. Check provider/URL/API key.",
            fg="red",
        ), err=True)
        click.echo("  Set via --provider, --base-url, --model, --api-key", err=True)
        click.echo("  Or env vars: CODEBRAIN_LLM_PROVIDER, CODEBRAIN_LLM_BASE_URL, "
                   "CODEBRAIN_LLM_MODEL, CODEBRAIN_LLM_API_KEY", err=True)
        sys.exit(1)

    click.echo(f"Generating equivalence tests: {out_path}")
    if target_lang:
        click.echo(f"Cross-language mode: {target_lang}")

    with GraphStore(_require_index(repo_root)) as store:
        gen = EquivalenceTestGenerator(store, client)
        result = gen.generate(
            old_root=repo_root,
            new_root=new_root,
            output_dir=out_path,
            target_lang=target_lang,
        )

    click.echo(click.style(
        f"\nGenerated {result.total} equivalence tests, {result.skipped} skipped.",
        fg="green" if result.total > 0 else "yellow",
    ))
    for t in result.tests:
        click.echo(f"  + {t.symbol_name} -> {t.test_file}")
    if result.total > 0:
        click.echo(f"\nRun: python -m pytest {out_path} -v")


# ------------------------------------------------------------------ ui-detect
@cli.command(name="ui-detect")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.pass_context
@_safe_command
def ui_detect(ctx: click.Context, as_json: bool) -> None:
    """Detect the frontend framework used in the indexed codebase.

    Returns 'vue', 'react', or 'unknown' based on indexed component nodes.
    """
    from codebrain.graph.store import GraphStore
    from codebrain.ui_migration import UITranslator

    repo_root: Path = ctx.obj["repo_root"]
    db = _require_index(repo_root)

    with GraphStore(db) as store:
        translator = UITranslator(store)
        framework = translator.detect_framework()
        stats = store.get_stats()
        component_count = stats.get("node_types", {}).get("component", 0)
        route_count = stats.get("node_types", {}).get("route", 0)

    if as_json:
        click.echo(json.dumps({
            "framework": framework,
            "component_count": component_count,
            "route_count": route_count,
        }, indent=2))
    else:
        click.echo(f"Detected framework: {framework}")
        click.echo(f"  Components: {component_count}")
        click.echo(f"  Routes: {route_count}")


# ------------------------------------------------------------------ ui-translate
@cli.command(name="ui-translate")
@click.option("-o", "--output-dir", required=True, type=click.Path(),
              help="Directory for translated components.")
@click.option("--target", required=True, type=click.Choice(["react", "vue"]),
              help="Target UI framework.")
@click.option("--provider", default="", help="LLM provider: ollama, openai, anthropic, azure.")
@click.option("--model", default="", help="LLM model name.")
@click.option("--base-url", default="", help="LLM API base URL.")
@click.option("--api-key", default="", help="LLM API key.")
@click.option("--component", default=None, help="Translate a single component only.")
@click.option("--max-retries", default=3, help="Max retry attempts per component.")
@click.option("--dry-run", is_flag=True, help="Generate prompts without calling LLM.")
@click.pass_context
@_safe_command
def ui_translate(ctx: click.Context, output_dir: str, target: str,
                 provider: str, model: str, base_url: str, api_key: str,
                 component: str | None, max_retries: int,
                 dry_run: bool) -> None:
    """Translate UI components between frontend frameworks.

    Uses CodeBrain's structural analysis to enrich LLM prompts with
    component contracts (props, events, children, state, API calls).

    Examples:

        brain ui-translate -o ./react-app --target react --provider ollama --model codellama:13b

        brain ui-translate -o ./vue-app --target vue --provider anthropic

        brain ui-translate -o ./out --target react --dry-run
    """
    from codebrain.graph.store import GraphStore
    from codebrain.rewriter import RewriteEngine, create_client
    from codebrain.ui_migration import UITranslationResult, UITranslator

    repo_root: Path = ctx.obj["repo_root"]
    out_path = Path(output_dir)

    if not dry_run:
        client = create_client(
            provider=provider, base_url=base_url,
            model=model, api_key=api_key,
        )
        if not client.is_available():
            click.echo(click.style(
                "Error: LLM endpoint not reachable. Check provider/URL/API key.",
                fg="red",
            ), err=True)
            click.echo("  Set via --provider, --base-url, --model, --api-key", err=True)
            click.echo("  Or env vars: CODEBRAIN_LLM_PROVIDER, CODEBRAIN_LLM_BASE_URL, "
                       "CODEBRAIN_LLM_MODEL, CODEBRAIN_LLM_API_KEY", err=True)
            sys.exit(1)
    else:
        client = None

    with GraphStore(_require_index(repo_root)) as store:
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        if component:
            specs = [s for s in specs if s.name == component]
            if not specs:
                click.echo(click.style(
                    f"Component '{component}' not found.", fg="red",
                ), err=True)
                sys.exit(1)

        source_fw = translator.detect_framework()
        click.echo(f"Translating {len(specs)} component(s): {source_fw} -> {target}")
        click.echo(f"Output: {out_path}")
        if dry_run:
            click.echo("(dry run - no LLM calls)")

        target_lang = "typescript" if target == "react" else "javascript"

        if not dry_run:
            engine = RewriteEngine(
                old_root=repo_root, store=store,
                client=client,  # type: ignore
                max_retries=max_retries,
                target_lang=target_lang,
            )

        results: list[UITranslationResult] = []
        for spec in specs:
            prompt = translator.build_enriched_prompt(spec, target)
            if dry_run:
                click.echo(f"\n--- Prompt for {spec.name} ---")
                click.echo(prompt[:500] + "..." if len(prompt) > 500 else prompt)
                results.append(UITranslationResult(
                    component_name=spec.name,
                    source_framework=spec.framework,
                    target_framework=target,
                    status="dry_run",
                ))
                continue

            try:
                result = engine.rewrite_module(
                    spec.file_path,
                    output_dir=out_path,
                    target_stack=target,
                    guidelines=prompt,
                )
                code = getattr(result, "code", "") or ""
                ui_errors = translator.validate_translation(spec, code, target) if code else []
                if code and ui_errors:
                    status = "warnings"
                    click.echo(f"  ~ {spec.name} [warnings: {len(ui_errors)}]")
                    for err in ui_errors:
                        click.echo(f"    - {err}")
                elif code:
                    status = "success"
                    click.echo(f"  + {spec.name} [success]")
                else:
                    status = "failed"
                    click.echo(f"  x {spec.name} [failed]")
                results.append(UITranslationResult(
                    component_name=spec.name,
                    source_framework=spec.framework,
                    target_framework=target,
                    translated_code=code,
                    validation_errors=ui_errors,
                    status=status,
                ))
            except Exception as exc:
                click.echo(f"  x {spec.name} [error: {exc}]")
                results.append(UITranslationResult(
                    component_name=spec.name,
                    source_framework=spec.framework,
                    target_framework=target,
                    validation_errors=[str(exc)],
                    status="failed",
                ))

        succeeded = sum(1 for r in results if r.status in ("success", "warnings", "dry_run"))
        failed = sum(1 for r in results if r.status == "failed")

        # Generate wiring checklist
        checklist = translator.generate_wiring_checklist(target)
        checklist_path = out_path / "WIRING_CHECKLIST.md"
        out_path.mkdir(parents=True, exist_ok=True)
        checklist_path.write_text(checklist, encoding="utf-8")
        click.echo(f"\nWiring checklist: {checklist_path}")

    click.echo(f"\nDone: {succeeded} succeeded, {failed} failed")


# ---------------------------------------------------------------------------
# Schema migration commands
# ---------------------------------------------------------------------------

@cli.command(name="schema-extract")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("-o", "--output", default=None, help="Output file.")
@click.pass_context
@_safe_command
def schema_extract(ctx: click.Context, as_json: bool, output: str | None) -> None:
    """Extract database schema from ORM models in the codebase.

    Detects SQLAlchemy/Django models and extracts tables, columns,
    types, constraints, and relationships.
    """
    from codebrain.graph.store import GraphStore
    from codebrain.schema_migration import SchemaMigrator

    repo_root: Path = ctx.obj["repo_root"]
    timeout = _get_timeout(ctx)

    def _extract():
        with GraphStore(_require_index(repo_root)) as store:
            migrator = SchemaMigrator(store)
            schema = migrator.extract_schema()
            return migrator.to_dict(schema)

    result = _run_with_timeout(_extract, timeout, "Extracting schema")

    if output:
        Path(output).write_text(json.dumps(result, indent=2), encoding="utf-8")
        click.echo(f"Schema written to {output}")
    elif as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(f"ORM: {result['orm_type']}")
        click.echo(f"Tables: {len(result['tables'])}")
        for t in result["tables"]:
            click.echo(f"\n  {t['name']} ({t['class_name']})  [{t['file_path']}]")
            for c in t["columns"]:
                flags = []
                if c["primary_key"]:
                    flags.append("PK")
                if not c["nullable"]:
                    flags.append("NOT NULL")
                if c["default"]:
                    flags.append(f"DEFAULT {c['default']}")
                if c["foreign_key"]:
                    flags.append("FK")
                flag_str = f"  [{', '.join(flags)}]" if flags else ""
                click.echo(f"    {c['name']:<20} {c['normalized_type']:<15}{flag_str}")
            for r in t["relationships"]:
                click.echo(f"    -> {r['target_table']}")


@cli.command(name="schema-diff")
@click.argument("new_project", type=click.Path(exists=True))
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("-o", "--output", default=None, help="Output file.")
@click.pass_context
@_safe_command
def schema_diff(ctx: click.Context, new_project: str, as_json: bool,
                output: str | None) -> None:
    """Compare database schemas between current and new project.

    Indexes the new project if needed, extracts schemas from both,
    and reports differences in tables, columns, types, and relationships.
    """
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import full_index
    from codebrain.schema_migration import SchemaMigrator

    repo_root: Path = ctx.obj["repo_root"]
    new_root = Path(new_project)
    timeout = _get_timeout(ctx)

    def _diff():
        # Index new project
        new_db = new_root / ".codebrain" / "codebrain.db"
        new_db.parent.mkdir(parents=True, exist_ok=True)
        full_index(new_root, new_db)

        with GraphStore(_require_index(repo_root)) as old_store:
            with GraphStore(str(new_db)) as new_store:
                old_migrator = SchemaMigrator(old_store)
                new_migrator = SchemaMigrator(new_store)
                old_schema = old_migrator.extract_schema()
                new_schema = new_migrator.extract_schema()
                diff = old_migrator.diff(old_schema, new_schema)
                return old_migrator.diff_to_dict(diff)

    result = _run_with_timeout(_diff, timeout, "Comparing schemas")

    if output:
        Path(output).write_text(json.dumps(result, indent=2), encoding="utf-8")
        click.echo(f"Schema diff written to {output}")
    elif as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        if not result["has_changes"]:
            click.echo("No schema differences found.")
            return
        if result["added_tables"]:
            click.echo(f"Added tables: {', '.join(result['added_tables'])}")
        if result["removed_tables"]:
            click.echo(f"Removed tables: {', '.join(result['removed_tables'])}")
        for table, cols in result["added_columns"].items():
            for c in cols:
                click.echo(f"  + {table}.{c['name']} ({c['type']})")
        for table, cols in result["removed_columns"].items():
            for c in cols:
                click.echo(f"  - {table}.{c['name']} ({c['type']})")
        for change in result["type_changes"]:
            click.echo(
                f"  ~ {change['table']}.{change['column']}: "
                f"{change['old_type']} -> {change['new_type']}"
            )


@cli.command(name="schema-migrate")
@click.argument("new_project", type=click.Path(exists=True))
@click.option("--format", "fmt", type=click.Choice(["sql", "alembic", "flyway"]),
              default="sql", help="Migration format.")
@click.option("-o", "--output", default=None, help="Output file.")
@click.pass_context
@_safe_command
def schema_migrate(ctx: click.Context, new_project: str, fmt: str,
                   output: str | None) -> None:
    """Generate migration scripts between current and new project schemas.

    Supports SQL, Alembic (Python), and Flyway (versioned SQL) formats.

    Examples:

        brain schema-migrate ./new-app --format sql

        brain schema-migrate ./new-app --format alembic -o migration.py
    """
    from codebrain.graph.store import GraphStore
    from codebrain.indexer import full_index
    from codebrain.schema_migration import SchemaMigrator

    repo_root: Path = ctx.obj["repo_root"]
    new_root = Path(new_project)
    timeout = _get_timeout(ctx)

    def _migrate():
        new_db = new_root / ".codebrain" / "codebrain.db"
        new_db.parent.mkdir(parents=True, exist_ok=True)
        full_index(new_root, new_db)

        with GraphStore(_require_index(repo_root)) as old_store:
            with GraphStore(str(new_db)) as new_store:
                old_migrator = SchemaMigrator(old_store)
                new_migrator = SchemaMigrator(new_store)
                old_schema = old_migrator.extract_schema()
                new_schema = new_migrator.extract_schema()
                diff = old_migrator.diff(old_schema, new_schema)

                if fmt == "alembic":
                    return old_migrator.generate_alembic(diff)
                elif fmt == "flyway":
                    return old_migrator.generate_flyway(diff)
                else:
                    return old_migrator.generate_sql(diff)

    content = _run_with_timeout(_migrate, timeout, "Generating migration")

    if output:
        Path(output).write_text(content, encoding="utf-8")
        click.echo(f"Migration written to {output}")
    else:
        click.echo(content)
