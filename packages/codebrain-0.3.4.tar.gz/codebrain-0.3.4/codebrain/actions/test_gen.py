"""Autonomous test generation — Action 1.

Takes untested symbols (from M23 coverage gaps or user request) and generates
real, runnable pytest tests using structural context + LLM.
"""

from __future__ import annotations

import ast
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

from codebrain.actions.base import ActionEngine
from codebrain.graph.store import GraphStore
from codebrain.rewriter import LLMClient
from codebrain.test_gaps import TestCoverageAnalyzer
from codebrain.utils import is_test_file


@dataclass
class GeneratedTest:
    symbol_name: str
    file_path: str
    test_file_path: str
    test_code: str
    test_count: int
    validated: bool
    ran_successfully: bool | None  # None if not run
    error: str
    tokens_used: int


class TestGenerator(ActionEngine):
    """Generate tests for untested symbols using structural context + LLM."""

    __test__ = False  # not a pytest test class

    def __init__(
        self,
        store: GraphStore,
        repo_root: Path,
        llm: LLMClient,
        max_retries: int = 3,
    ):
        super().__init__(store, repo_root, llm)
        self.max_retries = max_retries

    def generate_for_symbol(
        self,
        name: str,
        output_dir: Path | None = None,
        run_tests: bool = False,
    ) -> GeneratedTest:
        """Generate test for a single symbol by name."""
        # Resolve symbol
        contexts = self._get_symbol_context(name)
        if not contexts:
            return GeneratedTest(
                symbol_name=name, file_path="", test_file_path="",
                test_code="", test_count=0, validated=False,
                ran_successfully=None, error=f"Symbol '{name}' not found",
                tokens_used=0,
            )

        ctx = contexts[0]
        node = ctx.get("node", ctx)
        file_path = node.get("file_path", "")
        line_start = node.get("line_start", 0)

        # Get source code of the function
        source = self._get_function_source(file_path, name, line_start)
        if not source:
            source = self._get_file_source(file_path)

        # Build the prompt
        prompt = self._build_test_prompt(node, source, ctx)
        system = self._system_prompt()

        # Generate with retry loop
        total_tokens = 0
        last_error = ""

        for attempt in range(1, self.max_retries + 1):
            try:
                if attempt > 1:
                    prompt = self._build_retry_prompt(prompt, test_code, last_error)

                response = self.llm.complete(system, prompt)
                total_tokens += response.tokens_used
                test_code = self._extract_code(response.content)

                # Validate
                errors = self._validate_test(test_code)
                if not errors:
                    test_count = test_code.count("def test_")
                    test_file = self._test_file_path(file_path, name, output_dir)

                    # Write if output dir specified
                    if output_dir or test_file:
                        path = Path(test_file)
                        path.parent.mkdir(parents=True, exist_ok=True)
                        path.write_text(test_code, encoding="utf-8")

                    # Optionally run
                    ran = None
                    if run_tests and test_file:
                        ran = self._run_test(test_file)

                    return GeneratedTest(
                        symbol_name=name, file_path=file_path,
                        test_file_path=test_file, test_code=test_code,
                        test_count=test_count, validated=True,
                        ran_successfully=ran, error="",
                        tokens_used=total_tokens,
                    )

                last_error = "; ".join(errors)

            except Exception as e:
                last_error = str(e)

        # All retries failed
        return GeneratedTest(
            symbol_name=name, file_path=file_path, test_file_path="",
            test_code=test_code if "test_code" in dir() else "",
            test_count=0, validated=False, ran_successfully=None,
            error=last_error, tokens_used=total_tokens,
        )

    def generate_for_gaps(
        self,
        min_risk: float = 0.3,
        max_count: int = 10,
        output_dir: Path | None = None,
        run_tests: bool = False,
    ) -> list[GeneratedTest]:
        """Generate tests for top untested symbols from coverage gaps."""
        analyzer = TestCoverageAnalyzer(self.store)
        report = analyzer.analyze(min_risk=min_risk)
        results = []
        for gap in report.gaps[:max_count]:
            result = self.generate_for_symbol(
                gap.name, output_dir=output_dir, run_tests=run_tests,
            )
            results.append(result)
        return results

    def generate_for_file(
        self,
        file_path: str,
        output_dir: Path | None = None,
        run_tests: bool = False,
    ) -> list[GeneratedTest]:
        """Generate tests for all untested symbols in a file."""
        analyzer = TestCoverageAnalyzer(self.store)
        report = analyzer.analyze()
        file_gaps = [g for g in report.gaps if g.file_path == file_path]
        results = []
        for gap in file_gaps:
            result = self.generate_for_symbol(
                gap.name, output_dir=output_dir, run_tests=run_tests,
            )
            results.append(result)
        return results

    def _system_prompt(self) -> str:
        return (
            "You are an expert test engineer. You write pytest tests that are "
            "thorough, readable, and focused on behavior — not implementation details.\n"
            "Output ONLY the complete test file code. No explanations, no markdown "
            "fences around the entire response — just the Python code.\n"
            "Include all necessary imports at the top of the file.\n"
            "Use descriptive test names: test_<function>_<scenario>.\n"
            "Each test should be independent and test one behavior."
        )

    def _build_test_prompt(self, node: dict, source: str, ctx: dict) -> str:
        """Build a test generation prompt with full structural context."""
        parts = []
        parts.append("Generate pytest tests for the following function.\n")

        # Source code
        parts.append("## Function Under Test")
        parts.append(f"```python\n{source}\n```\n")

        # Structural context
        parts.append("## Structural Context")
        parts.append(f"- **Name:** {node.get('name', '?')}")
        parts.append(f"- **File:** {node.get('file_path', '?')}")
        if node.get("signature"):
            parts.append(f"- **Signature:** {node['signature']}")
        if node.get("docstring"):
            doc = node["docstring"][:500]
            parts.append(f"- **Docstring:** {doc}")
        if node.get("summary"):
            parts.append(f"- **Fingerprint:** {node['summary']}")
        parts.append(f"- **Exported:** {node.get('is_exported', False)}")

        # Calls and callers
        calls = ctx.get("calls", ctx.get("outgoing", []))
        called_by = ctx.get("called_by", ctx.get("incoming", []))
        if calls:
            names = [c.get("target", c.get("name", "?")) for c in calls[:10]]
            parts.append(f"- **Calls:** {', '.join(names)}")
        if called_by:
            names = [c.get("source", c.get("name", "?")) for c in called_by[:10]]
            parts.append(f"- **Called by:** {', '.join(names)}")

        # Fingerprint guidance
        fingerprint = node.get("summary", "")
        if fingerprint:
            parts.append(f"\n## What the fingerprint tells you")
            parts.append(self._interpret_fingerprint(fingerprint))

        # Existing test patterns
        file_path = node.get("file_path", "")
        test_patterns = self._get_existing_tests(file_path)
        if test_patterns and "No " not in test_patterns:
            parts.append(f"\n## Existing test patterns in this repo")
            parts.append(f"```python\n{test_patterns}\n```")

        # Requirements
        parts.append("\n## Requirements")
        parts.append("- Generate pytest test functions (not unittest classes)")
        parts.append("- Test actual behavior from docstring and fingerprint")
        parts.append("- If the function raises exceptions, test those paths")
        parts.append("- If the function mutates state, verify mutations")
        parts.append("- If the function does I/O, mock the I/O")
        parts.append("- If multiple return paths, test each one")
        parts.append("- Include necessary imports")
        parts.append("- Do NOT test private implementation details")
        parts.append(f"- Import from: {file_path.replace('/', '.').replace('.py', '')}")

        return "\n".join(parts)

    def _build_retry_prompt(self, original: str, code: str, error: str) -> str:
        parts = [
            "## Previous Attempt (FAILED VALIDATION)\n",
            f"```python\n{code}\n```\n",
            f"## Errors: {error}\n",
            "## Original Requirements\n",
            original,
            "\n## Task: Fix the errors. Output ONLY corrected Python code.",
        ]
        return "\n".join(parts)

    def _validate_test(self, code: str) -> list[str]:
        """Validate generated test code."""
        errors = self._validate_python(code)
        if errors:
            return errors
        # Must contain at least one test function
        if "def test_" not in code:
            errors.append("No test functions found (must have 'def test_...')")
        # Must have imports
        if "import " not in code:
            errors.append("No imports found — tests need to import the module under test")
        return errors

    def _test_file_path(
        self, file_path: str, symbol_name: str, output_dir: Path | None,
    ) -> str:
        """Determine output path for the generated test file."""
        if output_dir:
            base = Path(file_path).stem
            return str(output_dir / f"test_{base}_{symbol_name}.py")
        # Default: tests/ directory relative to repo root
        base = Path(file_path).stem
        return str(self.repo_root / "tests" / "generated" / f"test_{base}_{symbol_name}.py")

    def _run_test(self, test_file: str) -> bool:
        """Run a generated test file and return True if it passes."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pytest", test_file, "-x", "-q"],
                capture_output=True, text=True, timeout=60,
                cwd=str(self.repo_root),
            )
            return result.returncode == 0
        except Exception:
            return False
