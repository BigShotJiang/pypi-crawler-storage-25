"""Autonomous code review — Action 2.

Structural code review that sees the entire dependency graph, not just the diff.
Detects breaking changes, missing tests, rule violations, and suggests fixes.
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from codebrain.actions.base import ActionEngine
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.rewriter import LLMClient
from codebrain.test_gaps import TestCoverageAnalyzer
from codebrain.validator import ChangeValidator


@dataclass
class ReviewFinding:
    severity: str  # "critical", "warning", "suggestion"
    category: str  # "breaking_change", "missing_test", "dead_code", "complexity"
    file_path: str
    line: int
    message: str
    suggestion: str
    affected_callers: list[dict] = field(default_factory=list)


@dataclass
class CodeReview:
    changed_files: int
    findings: list[ReviewFinding]
    summary: str
    risk_score: float
    test_suggestions: list[str]
    approved: bool  # True if no critical findings


class CodeReviewer(ActionEngine):
    """Structural code review with full dependency graph awareness."""

    def __init__(
        self,
        store: GraphStore,
        repo_root: Path,
        llm: LLMClient | None = None,
    ):
        if llm is None:
            # Allow structural-only reviews without LLM
            self.store = store
            self.repo_root = repo_root
            self.llm = None  # type: ignore[assignment]
            self.context = None  # type: ignore[assignment]
            self.engine = QueryEngine(store)
        else:
            super().__init__(store, repo_root, llm)

    def review_files(
        self,
        changed_files: list[str],
        full: bool = False,
    ) -> CodeReview:
        """Review a set of changed files.

        Args:
            changed_files: List of file paths relative to repo root.
            full: If True, use LLM for deeper analysis. If False, structural only.
        """
        findings: list[ReviewFinding] = []
        test_suggestions: list[str] = []

        # Run structural validation on each file
        validator = ChangeValidator(self.store)
        for fp in changed_files:
            full_path = self.repo_root / fp
            if not full_path.exists():
                # File was deleted — check for callers
                findings.extend(self._check_deleted_file(fp))
                continue

            # Validate changes structurally
            try:
                content = full_path.read_text(encoding="utf-8", errors="replace")
                report = validator.validate_content(fp, content)
                for v in report.violations:
                    findings.append(ReviewFinding(
                        severity="critical" if v.severity in ("critical", "high") else "warning",
                        category="breaking_change",
                        file_path=fp,
                        line=v.line,
                        message=v.message,
                        suggestion=f"Review callers: {v.affected_dependents} dependents affected",
                        affected_callers=v.callers,
                    ))
            except Exception:
                pass

            # Check test coverage
            coverage_findings = self._check_coverage(fp)
            findings.extend(coverage_findings)
            for f in coverage_findings:
                test_suggestions.append(
                    f"Add tests for {f.message.split(':')[-1].strip() if ':' in f.message else fp}"
                )

        # LLM-enhanced review
        if full and self.llm is not None and changed_files:
            llm_findings = self._llm_review(changed_files)
            findings.extend(llm_findings)

        # Compute risk score
        risk = self._compute_risk(findings)
        critical_count = sum(1 for f in findings if f.severity == "critical")

        summary = self._build_summary(changed_files, findings, risk)

        return CodeReview(
            changed_files=len(changed_files),
            findings=findings,
            summary=summary,
            risk_score=risk,
            test_suggestions=test_suggestions,
            approved=critical_count == 0,
        )

    def review_diff(self, base: str = "HEAD~1", full: bool = False) -> CodeReview:
        """Review changes compared to a git ref."""
        changed = self._get_changed_files(base)
        return self.review_files(changed, full=full)

    def _check_deleted_file(self, file_path: str) -> list[ReviewFinding]:
        """Check if a deleted file has callers."""
        findings = []
        nodes = self.store.get_nodes_by_file(file_path)
        if not nodes:
            return findings

        all_edges = self.store.get_all_edges()
        all_nodes = self.store.get_all_nodes()
        node_ids = {n["id"] for n in nodes}
        node_names = {n["name"] for n in nodes}

        # Edges where target matches a node in this file (by ID or name suffix)
        callers = []
        for e in all_edges:
            if e["type"] in ("CALLS", "IMPORTS"):
                target = e.get("target", "")
                target_match = (
                    target in node_ids
                    or target.split(".")[-1] in node_names
                    or target in node_names
                )
                if target_match and e["file_path"] != file_path:
                    callers.append({
                        "source": e.get("source", ""),
                        "file": e["file_path"],
                    })

        if callers:
            findings.append(ReviewFinding(
                severity="critical",
                category="breaking_change",
                file_path=file_path,
                line=0,
                message=f"Deleted file still referenced by {len(callers)} callers",
                suggestion="Update or remove callers before deleting this file",
                affected_callers=callers,
            ))
        return findings

    def _check_coverage(self, file_path: str) -> list[ReviewFinding]:
        """Check if changed file has test coverage gaps."""
        findings = []
        try:
            analyzer = TestCoverageAnalyzer(self.store)
            report = analyzer.analyze()
            file_gaps = [g for g in report.gaps if g.file_path == file_path]
            for gap in file_gaps:
                if gap.is_exported and gap.risk_score >= 0.3:
                    findings.append(ReviewFinding(
                        severity="warning",
                        category="missing_test",
                        file_path=file_path,
                        line=gap.line_start,
                        message=f"No test coverage: {gap.name} (risk: {gap.risk_score:.1f})",
                        suggestion=f"Add tests for {gap.name} — {gap.risk_reason}",
                    ))
        except Exception:
            pass
        return findings

    def _llm_review(self, changed_files: list[str]) -> list[ReviewFinding]:
        """Use LLM for deeper code review."""
        findings = []

        # Build context for LLM
        parts = ["Review these code changes for bugs, design issues, and risks.\n"]

        for fp in changed_files[:5]:  # Limit to 5 files to fit context
            source = self._get_file_source(fp)
            if not source:
                continue
            # Get structural context
            nodes = self.store.get_nodes_by_file(fp)
            exported = [n["name"] for n in nodes if n.get("is_exported")]

            parts.append(f"## {fp}")
            parts.append(f"Exported symbols: {', '.join(exported)}")
            parts.append(f"```python\n{source[:3000]}\n```\n")

        parts.append("\n## Output Format")
        parts.append("Return a JSON array of findings:")
        parts.append('[{"severity": "critical|warning|suggestion", '
                      '"file": "path", "line": 0, '
                      '"message": "what is wrong", '
                      '"suggestion": "how to fix it"}]')

        system = (
            "You are a senior code reviewer. Find real bugs, not style nits. "
            "Focus on: breaking changes, missing error handling, security issues, "
            "and logic errors. Output ONLY valid JSON."
        )

        try:
            response = self.llm.complete(system, "\n".join(parts))
            code = self._extract_code(response.content)
            # Try to parse JSON
            data = json.loads(code)
            if isinstance(data, list):
                for item in data:
                    findings.append(ReviewFinding(
                        severity=item.get("severity", "suggestion"),
                        category="llm_finding",
                        file_path=item.get("file", changed_files[0]),
                        line=item.get("line", 0),
                        message=item.get("message", ""),
                        suggestion=item.get("suggestion", ""),
                    ))
        except Exception:
            pass

        return findings

    def _compute_risk(self, findings: list[ReviewFinding]) -> float:
        """Compute overall risk score from findings."""
        if not findings:
            return 0.0
        weights = {"critical": 0.4, "warning": 0.15, "suggestion": 0.05}
        score = sum(weights.get(f.severity, 0.05) for f in findings)
        return min(1.0, score)

    def _build_summary(
        self,
        files: list[str],
        findings: list[ReviewFinding],
        risk: float,
    ) -> str:
        critical = sum(1 for f in findings if f.severity == "critical")
        warnings = sum(1 for f in findings if f.severity == "warning")
        if critical > 0:
            verdict = f"UNSAFE — {critical} critical finding(s)"
        elif warnings > 0:
            verdict = f"CAUTION — {warnings} warning(s)"
        elif findings:
            verdict = "SAFE with suggestions"
        else:
            verdict = "SAFE — no structural issues found"
        return (
            f"Reviewed {len(files)} file(s). Risk score: {risk:.2f}. "
            f"Verdict: {verdict}."
        )

    def _get_changed_files(self, base: str) -> list[str]:
        """Get list of changed files from git diff."""
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", base],
                capture_output=True, text=True, timeout=10,
                cwd=str(self.repo_root),
            )
            if result.returncode == 0:
                return [f.strip() for f in result.stdout.strip().split("\n") if f.strip()]
        except Exception:
            pass
        return []

    def to_markdown(self, review: CodeReview) -> str:
        """Format review as markdown."""
        lines = ["## CodeBrain Structural Review\n"]
        lines.append(f"**{review.summary}**\n")

        if review.findings:
            lines.append("### Findings\n")
            lines.append("| Severity | File | Message |")
            lines.append("|----------|------|---------|")
            for f in review.findings:
                lines.append(f"| {f.severity.upper()} | {f.file_path}:{f.line} | {f.message} |")

            lines.append("")
            for f in review.findings:
                if f.suggestion:
                    lines.append(f"- **{f.file_path}:{f.line}** — {f.suggestion}")

        if review.test_suggestions:
            lines.append("\n### Test Suggestions")
            for s in review.test_suggestions:
                lines.append(f"- {s}")

        return "\n".join(lines)
