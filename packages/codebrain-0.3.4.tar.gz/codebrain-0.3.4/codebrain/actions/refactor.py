"""Autonomous refactoring — Action 3.

Detects structural problems and generates fixes, not just reports.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path

from codebrain.actions.base import ActionEngine
from codebrain.analyzer import StructuralAnalyzer
from codebrain.comprehension import ComprehensionEngine
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.rewriter import LLMClient


@dataclass
class RefactorSuggestion:
    category: str  # "dead_code", "import_cycle", "high_coupling", "god_class"
    severity: str  # "high", "medium", "low"
    file_path: str
    symbol_name: str
    message: str
    strategy: str  # "remove", "extract_interface", "split_class", "extract_module"
    affected_files: list[str] = field(default_factory=list)
    estimated_effort: str = "small"  # "small", "medium", "large"


@dataclass
class RefactorResult:
    suggestion: RefactorSuggestion
    status: str  # "success", "failed", "skipped"
    new_code: str  # the refactored code
    patch: str  # unified diff
    error: str
    tokens_used: int


class Refactorer(ActionEngine):
    """Detect structural problems and generate fixes."""

    def __init__(
        self,
        store: GraphStore,
        repo_root: Path,
        llm: LLMClient | None = None,
    ):
        if llm is None:
            self.store = store
            self.repo_root = repo_root
            self.llm = None  # type: ignore[assignment]
            self.context = None  # type: ignore[assignment]
            self.engine = QueryEngine(store)
        else:
            super().__init__(store, repo_root, llm)
        self.analyzer = StructuralAnalyzer(store)
        self.comp = ComprehensionEngine(store)

    def suggest(self, category: str = "all") -> list[RefactorSuggestion]:
        """Analyze codebase and return refactoring suggestions."""
        suggestions: list[RefactorSuggestion] = []

        if category in ("all", "dead_code"):
            suggestions.extend(self._suggest_dead_code())
        if category in ("all", "import_cycle", "cycles"):
            suggestions.extend(self._suggest_cycle_fixes())
        if category in ("all", "high_coupling", "coupling"):
            suggestions.extend(self._suggest_coupling_fixes())
        if category in ("all", "god_class"):
            suggestions.extend(self._suggest_god_class_splits())

        # Sort by severity
        order = {"high": 0, "medium": 1, "low": 2}
        suggestions.sort(key=lambda s: order.get(s.severity, 3))
        return suggestions

    def fix(
        self,
        suggestion: RefactorSuggestion,
        dry_run: bool = True,
    ) -> RefactorResult:
        """Generate a fix for a refactoring suggestion."""
        # Dead code removal can work without LLM (AST-based)
        if suggestion.category == "dead_code":
            return self._fix_dead_code(suggestion, dry_run)

        if self.llm is None:
            return RefactorResult(
                suggestion=suggestion, status="skipped",
                new_code="", patch="",
                error="No LLM configured — cannot generate fix",
                tokens_used=0,
            )

        if suggestion.category == "god_class":
            return self._fix_god_class(suggestion, dry_run)
        else:
            return self._fix_generic(suggestion, dry_run)

    def fix_all(
        self,
        category: str = "dead_code",
        dry_run: bool = True,
        max_count: int = 10,
    ) -> list[RefactorResult]:
        """Suggest and fix multiple refactoring opportunities."""
        suggestions = self.suggest(category)[:max_count]
        return [self.fix(s, dry_run=dry_run) for s in suggestions]

    # -----------------------------------------------------------------------
    # Suggestion generators
    # -----------------------------------------------------------------------

    def _suggest_dead_code(self) -> list[RefactorSuggestion]:
        suggestions = []
        dead = self.engine.find_dead_code()
        for node in dead:
            if node.get("type") in ("function", "class") and node.get("confidence") == "high":
                suggestions.append(RefactorSuggestion(
                    category="dead_code",
                    severity="medium",
                    file_path=node["file_path"],
                    symbol_name=node["name"],
                    message=f"Dead code: {node['name']} has no callers (high confidence)",
                    strategy="remove",
                    estimated_effort="small",
                ))
        return suggestions

    def _suggest_cycle_fixes(self) -> list[RefactorSuggestion]:
        suggestions = []
        cycles = self.engine.detect_cycles()
        for cycle in cycles:
            files = cycle if isinstance(cycle, list) else [str(cycle)]
            suggestions.append(RefactorSuggestion(
                category="import_cycle",
                severity="high",
                file_path=files[0] if files else "",
                symbol_name="",
                message=f"Import cycle: {' → '.join(files)}",
                strategy="extract_interface",
                affected_files=files,
                estimated_effort="medium",
            ))
        return suggestions

    def _suggest_coupling_fixes(self) -> list[RefactorSuggestion]:
        suggestions = []
        coupling = self.analyzer.coupling_analysis()
        pairs = coupling.get("pairs", [])
        for pair in pairs:
            score = pair.get("coupling_score", pair.get("shared_symbols", 0))
            if score >= 5:
                suggestions.append(RefactorSuggestion(
                    category="high_coupling",
                    severity="medium" if score < 10 else "high",
                    file_path=pair.get("file_a", pair.get("module_a", "")),
                    symbol_name="",
                    message=(
                        f"High coupling ({score} shared symbols) between "
                        f"{pair.get('file_a', pair.get('module_a', '?'))} and "
                        f"{pair.get('file_b', pair.get('module_b', '?'))}"
                    ),
                    strategy="extract_module",
                    affected_files=[
                        pair.get("file_a", pair.get("module_a", "")),
                        pair.get("file_b", pair.get("module_b", "")),
                    ],
                    estimated_effort="large",
                ))
        return suggestions

    def _suggest_god_class_splits(self) -> list[RefactorSuggestion]:
        suggestions = []
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Find classes with many methods via CONTAINS edges
        class_nodes = {n["id"]: n for n in all_nodes if n["type"] == "class"}
        methods_per_class: dict[str, int] = {}
        for e in all_edges:
            if e["type"] == "CONTAINS" and e["source"] in class_nodes:
                methods_per_class[e["source"]] = methods_per_class.get(e["source"], 0) + 1

        for class_id, count in methods_per_class.items():
            if count >= 15:
                cls = class_nodes[class_id]
                suggestions.append(RefactorSuggestion(
                    category="god_class",
                    severity="high" if count >= 25 else "medium",
                    file_path=cls["file_path"],
                    symbol_name=cls["name"],
                    message=f"God class: {cls['name']} has {count} methods",
                    strategy="split_class",
                    estimated_effort="large",
                ))
        return suggestions

    # -----------------------------------------------------------------------
    # Fix generators
    # -----------------------------------------------------------------------

    def _fix_dead_code(self, suggestion: RefactorSuggestion, dry_run: bool) -> RefactorResult:
        """Remove dead code from a file."""
        source = self._get_file_source(suggestion.file_path)
        if not source:
            return RefactorResult(
                suggestion=suggestion, status="failed",
                new_code="", patch="", error="Could not read source file",
                tokens_used=0,
            )

        # Try AST-based removal first (no LLM needed)
        try:
            new_code = self._remove_symbol_from_source(source, suggestion.symbol_name)
            if new_code and new_code != source:
                patch = self._make_patch(suggestion.file_path, source, new_code)
                if not dry_run:
                    (self.repo_root / suggestion.file_path).write_text(
                        new_code, encoding="utf-8",
                    )
                return RefactorResult(
                    suggestion=suggestion, status="success",
                    new_code=new_code, patch=patch, error="",
                    tokens_used=0,
                )
        except Exception:
            pass

        # Fallback to LLM
        return self._fix_generic(suggestion, dry_run)

    def _fix_god_class(self, suggestion: RefactorSuggestion, dry_run: bool) -> RefactorResult:
        """Use LLM to split a god class."""
        source = self._get_file_source(suggestion.file_path)
        if not source:
            return RefactorResult(
                suggestion=suggestion, status="failed",
                new_code="", patch="", error="Could not read source file",
                tokens_used=0,
            )

        # Get class context
        contexts = self._get_symbol_context(suggestion.symbol_name)
        ctx_str = ""
        if contexts:
            callers = contexts[0].get("incoming", [])
            ctx_str = f"Called by: {', '.join(c.get('name', '?') for c in callers[:10])}"

        prompt = (
            f"Split this god class into smaller, focused classes.\n\n"
            f"## Current Code\n```python\n{source[:4000]}\n```\n\n"
            f"## Class: {suggestion.symbol_name} ({suggestion.message})\n"
            f"{ctx_str}\n\n"
            f"## Requirements\n"
            f"- Split into 2-3 focused classes by responsibility\n"
            f"- Preserve ALL public methods (callers must still work)\n"
            f"- Use composition or delegation where needed\n"
            f"- Output ONLY the complete refactored Python code\n"
        )

        return self._llm_fix(suggestion, source, prompt, dry_run)

    def _fix_generic(self, suggestion: RefactorSuggestion, dry_run: bool) -> RefactorResult:
        """Generic LLM-based fix."""
        source = self._get_file_source(suggestion.file_path)
        if not source:
            return RefactorResult(
                suggestion=suggestion, status="failed",
                new_code="", patch="", error="Could not read source file",
                tokens_used=0,
            )

        prompt = (
            f"Refactor this code to fix: {suggestion.message}\n\n"
            f"Strategy: {suggestion.strategy}\n\n"
            f"## Current Code\n```python\n{source[:4000]}\n```\n\n"
            f"## Requirements\n"
            f"- Preserve ALL public API (exported functions and classes)\n"
            f"- Fix the structural issue described above\n"
            f"- Output ONLY the complete refactored Python code\n"
        )

        return self._llm_fix(suggestion, source, prompt, dry_run)

    def _llm_fix(
        self,
        suggestion: RefactorSuggestion,
        original: str,
        prompt: str,
        dry_run: bool,
    ) -> RefactorResult:
        """Common LLM fix logic with validation."""
        system = (
            "You are a senior software engineer performing surgical refactoring. "
            "Preserve all public APIs. Output ONLY Python code, no explanations."
        )

        try:
            response = self.llm.complete(system, prompt)
            new_code = self._extract_code(response.content)

            errors = self._validate_python(new_code)
            if errors:
                return RefactorResult(
                    suggestion=suggestion, status="failed",
                    new_code=new_code, patch="",
                    error="; ".join(errors), tokens_used=response.tokens_used,
                )

            patch = self._make_patch(suggestion.file_path, original, new_code)

            if not dry_run:
                (self.repo_root / suggestion.file_path).write_text(
                    new_code, encoding="utf-8",
                )

            return RefactorResult(
                suggestion=suggestion, status="success",
                new_code=new_code, patch=patch, error="",
                tokens_used=response.tokens_used,
            )

        except Exception as e:
            return RefactorResult(
                suggestion=suggestion, status="failed",
                new_code="", patch="", error=str(e), tokens_used=0,
            )

    # -----------------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------------

    def _remove_symbol_from_source(self, source: str, name: str) -> str:
        """Remove a function or class from source code using AST."""
        tree = ast.parse(source)
        lines = source.splitlines(keepends=True)

        # Find the node to remove
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if node.name == name:
                    start = node.lineno - 1
                    end = getattr(node, "end_lineno", start + 1)
                    # Also remove decorators
                    if node.decorator_list:
                        start = node.decorator_list[0].lineno - 1
                    # Remove the lines
                    new_lines = lines[:start] + lines[end:]
                    return "".join(new_lines)
        return source

    def _make_patch(self, file_path: str, old: str, new: str) -> str:
        """Generate a simple unified diff."""
        import difflib
        old_lines = old.splitlines(keepends=True)
        new_lines = new.splitlines(keepends=True)
        diff = difflib.unified_diff(
            old_lines, new_lines,
            fromfile=f"a/{file_path}", tofile=f"b/{file_path}",
        )
        return "".join(diff)
