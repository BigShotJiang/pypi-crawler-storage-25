"""Shared infrastructure for autonomous actions."""

from __future__ import annotations

import ast
import re
from pathlib import Path

from codebrain.context import ContextGenerator
from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore
from codebrain.rewriter import LLMClient
from codebrain.utils import is_test_file


class ActionEngine:
    """Base class for all autonomous actions."""

    def __init__(self, store: GraphStore, repo_root: Path, llm: LLMClient):
        self.store = store
        self.repo_root = repo_root
        self.llm = llm
        self.context = ContextGenerator(store)
        self.engine = QueryEngine(store)

    def _get_symbol_context(self, name: str) -> list[dict]:
        """Full structural context for a symbol."""
        return self.context.for_symbol(name)

    def _get_file_source(self, file_path: str) -> str:
        """Read actual source code from disk."""
        full = self.repo_root / file_path
        if not full.exists():
            return ""
        try:
            return full.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""

    def _get_function_source(self, file_path: str, name: str, line_start: int) -> str:
        """Extract a single function/class source from a file."""
        source = self._get_file_source(file_path)
        if not source:
            return ""
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return ""
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if node.name == name:
                    lines = source.splitlines()
                    end = getattr(node, "end_lineno", None) or (node.lineno + 20)
                    return "\n".join(lines[node.lineno - 1 : end])
        # Fallback: return from line_start
        if line_start > 0:
            lines = source.splitlines()
            return "\n".join(lines[line_start - 1 : line_start + 30])
        return ""

    def _get_existing_tests(self, file_path: str) -> str:
        """Find existing test files and return a sample of test patterns."""
        # Look for test files in tests/ directory
        tests_dir = self.repo_root / "tests"
        if not tests_dir.exists():
            tests_dir = self.repo_root / "test"
        if not tests_dir.exists():
            return "# No existing test directory found"

        samples = []
        for tf in sorted(tests_dir.iterdir()):
            if tf.name.startswith("test_") and tf.suffix == ".py":
                try:
                    content = tf.read_text(encoding="utf-8", errors="replace")
                    # Extract first test function as pattern example
                    for match in re.finditer(
                        r"((?:@\w+.*\n)*def test_\w+\(.*?\):.*?)(?=\ndef |\nclass |\Z)",
                        content,
                        re.DOTALL,
                    ):
                        sample = match.group(1).strip()
                        if len(sample) < 500:
                            samples.append(f"# From {tf.name}:\n{sample}")
                            break
                except Exception:
                    continue
            if len(samples) >= 3:
                break

        return "\n\n".join(samples) if samples else "# No test examples found"

    def _validate_python(self, code: str) -> list[str]:
        """Check Python syntax and basic correctness."""
        errors = []
        try:
            ast.parse(code)
        except SyntaxError as e:
            errors.append(f"Syntax error: {e.msg} at line {e.lineno}")
        return errors

    def _extract_code(self, response: str) -> str:
        """Strip markdown fences from LLM output."""
        pattern = r"```(?:python|java|typescript|javascript)?\s*\n(.*?)```"
        matches = re.findall(pattern, response, re.DOTALL)
        if matches:
            return max(matches, key=len).strip()
        # If no fences, return as-is but trim non-code lines at start
        lines = response.strip().split("\n")
        for i, line in enumerate(lines):
            s = line.strip()
            if s.startswith(("import ", "from ", "def ", "class ", "#", '"""', "@", "async ")):
                return "\n".join(lines[i:]).strip()
        return response.strip()

    def _interpret_fingerprint(self, fingerprint: str) -> str:
        """Convert structural fingerprint to actionable guidance."""
        if not fingerprint:
            return "- No structural fingerprint available."
        guidance = []
        if "returns:" in fingerprint:
            returns = fingerprint.split("returns:")[1].split("|")[0].strip()
            guidance.append(f"- Returns: {returns}. Test each return path.")
        if "raises:" in fingerprint:
            exc = fingerprint.split("raises:")[1].split("|")[0].strip()
            guidance.append(f"- Raises: {exc}. Test exception paths.")
        if "mutates:" in fingerprint:
            mut = fingerprint.split("mutates:")[1].split("|")[0].strip()
            guidance.append(f"- Mutates: {mut}. Verify state changes.")
        if "io:" in fingerprint:
            io = fingerprint.split("io:")[1].split("|")[0].strip()
            guidance.append(f"- I/O: {io}. Mock these in tests.")
        if "yields" in fingerprint:
            guidance.append("- Generator function. Test iteration and empty case.")
        if "async" in fingerprint:
            guidance.append("- Async function. Use @pytest.mark.asyncio.")
        if "control:" in fingerprint:
            ctrl = fingerprint.split("control:")[1].split("|")[0].strip()
            guidance.append(f"- Control flow: {ctrl}. Test each branch.")
        return "\n".join(guidance) if guidance else "- No special patterns detected."
