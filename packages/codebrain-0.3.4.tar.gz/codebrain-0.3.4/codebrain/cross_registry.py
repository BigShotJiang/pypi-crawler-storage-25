"""Cross-repo registry — maps packages to indexed repositories.

Stores a lightweight SQLite database at ~/.codebrain/registry.db that
tracks all repos indexed by CodeBrain and which packages they provide.
This enables cross-repo dependency tracking and impact analysis.
"""

from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path
from typing import Any

from codebrain.logging import get_logger

_log = get_logger("cross_registry")

_DEFAULT_REGISTRY_DIR = Path.home() / ".codebrain"
_REGISTRY_FILENAME = "registry.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS repos (
    slug        TEXT PRIMARY KEY,
    repo_path   TEXT NOT NULL,
    db_path     TEXT NOT NULL,
    last_indexed REAL DEFAULT 0,
    packages    TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS package_map (
    package_name TEXT NOT NULL,
    repo_slug    TEXT NOT NULL REFERENCES repos(slug) ON DELETE CASCADE,
    PRIMARY KEY (package_name, repo_slug)
);

CREATE INDEX IF NOT EXISTS idx_package_name ON package_map(package_name);
"""


def _default_registry_path() -> Path:
    """Return registry DB path from env or default."""
    env_path = os.environ.get("CODEBRAIN_REGISTRY_PATH")
    if env_path:
        return Path(env_path)
    return _DEFAULT_REGISTRY_DIR / _REGISTRY_FILENAME


def detect_packages(repo_path: Path) -> list[str]:
    """Detect package names exported by a repository.

    Scans pyproject.toml, package.json, go.mod, Cargo.toml.
    Falls back to directory name.
    """
    packages: list[str] = []
    repo_path = repo_path.resolve()

    # Python: pyproject.toml
    pyproject = repo_path / "pyproject.toml"
    if pyproject.is_file():
        try:
            import tomllib
        except ModuleNotFoundError:
            try:
                import tomli as tomllib  # type: ignore[no-redef]
            except ModuleNotFoundError:
                tomllib = None  # type: ignore[assignment]
        if tomllib:
            try:
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                # [project].name
                name = data.get("project", {}).get("name", "")
                if name:
                    # PyPI names use dashes but import names use underscores
                    packages.append(name.replace("-", "_"))
                # [tool.setuptools.packages]
                pkgs = (data.get("tool", {}).get("setuptools", {})
                        .get("packages", {}).get("find", {})
                        .get("include", []))
                for p in pkgs:
                    if p and not p.startswith("test"):
                        packages.append(p.rstrip("*").rstrip("."))
            except Exception as e:
                _log.debug("Error reading pyproject.toml: %s", e)

    # Python fallback: top-level packages with __init__.py
    if not packages:
        for d in repo_path.iterdir():
            if d.is_dir() and (d / "__init__.py").is_file():
                name = d.name
                if not name.startswith((".", "_", "test")):
                    packages.append(name)

    # Node.js: package.json
    pkg_json = repo_path / "package.json"
    if pkg_json.is_file():
        try:
            data = json.loads(pkg_json.read_text(encoding="utf-8"))
            name = data.get("name", "")
            if name:
                packages.append(name)
        except Exception as e:
            _log.debug("Error reading package.json: %s", e)

    # Go: go.mod
    go_mod = repo_path / "go.mod"
    if go_mod.is_file():
        try:
            for line in go_mod.read_text(encoding="utf-8").splitlines():
                if line.startswith("module "):
                    mod_name = line.split(None, 1)[1].strip()
                    packages.append(mod_name)
                    # Also add the short name (last segment)
                    short = mod_name.rsplit("/", 1)[-1]
                    if short != mod_name:
                        packages.append(short)
                    break
        except Exception as e:
            _log.debug("Error reading go.mod: %s", e)

    # Rust: Cargo.toml
    cargo = repo_path / "Cargo.toml"
    _tomllib = None
    try:
        import tomllib as _tomllib
    except ModuleNotFoundError:
        try:
            import tomli as _tomllib  # type: ignore[no-redef]
        except ModuleNotFoundError:
            pass
    if cargo.is_file() and _tomllib:
        try:
            with open(cargo, "rb") as f:
                data = _tomllib.load(f)
            name = data.get("package", {}).get("name", "")
            if name:
                packages.append(name)
        except Exception:
            pass

    # Kotlin/Java: settings.gradle.kts or build.gradle.kts
    for gradle_file in ("settings.gradle.kts", "settings.gradle"):
        gf = repo_path / gradle_file
        if gf.is_file():
            try:
                text = gf.read_text(encoding="utf-8")
                for line in text.splitlines():
                    if "rootProject.name" in line:
                        # rootProject.name = "ktor"
                        name = line.split("=", 1)[1].strip().strip('"').strip("'")
                        if name:
                            packages.append(name)
                        break
            except Exception:
                pass

    # C#: .csproj files
    for csproj in repo_path.glob("**/*.csproj"):
        try:
            text = csproj.read_text(encoding="utf-8")
            import re
            m = re.search(r"<RootNamespace>([^<]+)</RootNamespace>", text)
            if m:
                packages.append(m.group(1))
            m = re.search(r"<AssemblyName>([^<]+)</AssemblyName>", text)
            if m:
                packages.append(m.group(1))
        except Exception:
            pass
        break  # Only check first .csproj

    # Fallback: directory name
    if not packages:
        packages.append(repo_path.name)

    # Deduplicate
    seen: set[str] = set()
    result: list[str] = []
    for p in packages:
        p = p.strip()
        if p and p not in seen:
            seen.add(p)
            result.append(p)
    return result


class CrossRegistry:
    """Manages the cross-repo registry database."""

    def __init__(self, db_path: Path | None = None) -> None:
        self._db_path = db_path or _default_registry_path()
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_SCHEMA)

    def close(self) -> None:
        self._conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def register(self, repo_path: Path, slug: str | None = None,
                 db_path: Path | None = None) -> str:
        """Register a repo in the cross-repo registry.

        Returns the slug used.
        """
        repo_path = repo_path.resolve()
        if slug is None:
            slug = repo_path.name
        if db_path is None:
            from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
            db_path = repo_path / CODEBRAIN_DIR / DB_FILENAME

        packages = detect_packages(repo_path)

        import time
        self._conn.execute(
            """INSERT OR REPLACE INTO repos (slug, repo_path, db_path, last_indexed, packages)
               VALUES (?, ?, ?, ?, ?)""",
            (slug, str(repo_path), str(db_path), time.time(), json.dumps(packages)),
        )

        # Update package_map
        self._conn.execute("DELETE FROM package_map WHERE repo_slug = ?", (slug,))
        for pkg in packages:
            self._conn.execute(
                "INSERT OR IGNORE INTO package_map (package_name, repo_slug) VALUES (?, ?)",
                (pkg, slug),
            )
        self._conn.commit()
        _log.info("Registered repo '%s' with packages: %s", slug, packages)
        return slug

    def unregister(self, slug: str) -> bool:
        """Remove a repo from the registry. Returns True if it existed."""
        cursor = self._conn.execute("DELETE FROM repos WHERE slug = ?", (slug,))
        self._conn.commit()
        return cursor.rowcount > 0

    def list_repos(self) -> list[dict[str, Any]]:
        """Return all registered repos."""
        rows = self._conn.execute(
            "SELECT slug, repo_path, db_path, last_indexed, packages FROM repos"
        ).fetchall()
        result = []
        for r in rows:
            result.append({
                "slug": r["slug"],
                "repo_path": r["repo_path"],
                "db_path": r["db_path"],
                "last_indexed": r["last_indexed"],
                "packages": json.loads(r["packages"]),
            })
        return result

    def get_repo(self, slug: str) -> dict[str, Any] | None:
        """Get a single repo by slug."""
        row = self._conn.execute(
            "SELECT slug, repo_path, db_path, last_indexed, packages FROM repos WHERE slug = ?",
            (slug,),
        ).fetchone()
        if row is None:
            return None
        return {
            "slug": row["slug"],
            "repo_path": row["repo_path"],
            "db_path": row["db_path"],
            "last_indexed": row["last_indexed"],
            "packages": json.loads(row["packages"]),
        }

    def resolve_package(self, import_name: str) -> list[dict[str, str]]:
        """Resolve an import name to repo(s).

        Walks up the dotted path: "mylib.utils.helper" -> "mylib.utils" -> "mylib"
        Returns list of {slug, db_path, package_name, repo_path}.
        """
        parts = import_name.split(".")
        for i in range(len(parts), 0, -1):
            candidate = ".".join(parts[:i])
            rows = self._conn.execute(
                """SELECT pm.package_name, r.slug, r.db_path, r.repo_path
                   FROM package_map pm
                   JOIN repos r ON pm.repo_slug = r.slug
                   WHERE pm.package_name = ?""",
                (candidate,),
            ).fetchall()
            if rows:
                return [
                    {"slug": r["slug"], "db_path": r["db_path"],
                     "package_name": r["package_name"], "repo_path": r["repo_path"]}
                    for r in rows
                ]
        # Also try the full import name against Go-style module paths (with /)
        slash_name = import_name.replace(".", "/")
        parts_slash = slash_name.split("/")
        for i in range(len(parts_slash), 0, -1):
            candidate = "/".join(parts_slash[:i])
            rows = self._conn.execute(
                """SELECT pm.package_name, r.slug, r.db_path, r.repo_path
                   FROM package_map pm
                   JOIN repos r ON pm.repo_slug = r.slug
                   WHERE pm.package_name = ?""",
                (candidate,),
            ).fetchall()
            if rows:
                return [
                    {"slug": r["slug"], "db_path": r["db_path"],
                     "package_name": r["package_name"], "repo_path": r["repo_path"]}
                    for r in rows
                ]
        return []

    def get_all_packages(self) -> dict[str, str]:
        """Return mapping of package_name -> repo_slug for all packages."""
        rows = self._conn.execute(
            "SELECT package_name, repo_slug FROM package_map"
        ).fetchall()
        return {r["package_name"]: r["repo_slug"] for r in rows}
