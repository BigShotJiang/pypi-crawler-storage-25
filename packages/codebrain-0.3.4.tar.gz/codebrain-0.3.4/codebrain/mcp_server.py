"""MCP (Model Context Protocol) server for CodeBrain.

Exposes the knowledge graph as tools that LLM agents can call directly,
eliminating the need to grep/glob the codebase.

Usage:
    brain mcp                         # start server on stdio
    python -m codebrain.mcp_server    # direct invocation
"""

from __future__ import annotations

import functools
import json
import os
import sys
import traceback
import warnings
from pathlib import Path

import anyio
import anyio.to_thread

# Suppress tree-sitter FutureWarning — it writes to stderr but better safe than sorry.
# Any stray stdout write kills the MCP stdio transport.
warnings.filterwarnings("ignore", category=FutureWarning, module="tree_sitter")

from mcp.server.fastmcp import FastMCP

from codebrain.config import CODEBRAIN_DIR, DB_FILENAME
from codebrain.logging import get_logger

_log = get_logger("mcp_server")

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

mcp = FastMCP("CodeBrain")

# Active project path — set via set_project() tool or CODEBRAIN_PROJECT env var.
# When set, overrides the CWD-based _find_db() search.
_active_project: Path | None = None

# Per-tool wall-clock deadline. If a tool runs past this we return a timeout
# error so the client doesn't have to wait. The wrapper is async, so when the
# client cancels first (Esc / its own timeout), the asyncio cancellation
# propagates and the lowlevel SDK suppresses the response (mcp/server/lowlevel/
# server.py:766-771). Either way: no late JSON-RPC reply on the wire, no
# "unknown message ID" tear-down of the stdio transport.
TOOL_DEADLINE_SECONDS = int(os.environ.get("CODEBRAIN_MCP_TOOL_TIMEOUT", "25"))

# Tools that are explicitly long-running write/admin operations. Bypass the
# deadline (env var still respected). Users invoking these via MCP have opted
# into the wait; the cancellation pathway still drops late responses cleanly.
LONG_RUNNING_TOOLS = frozenset({
    "reindex_codebase",
    "rewrite",
    "modernize_spec",
    "translate_codebase",
    "translate_module",
    "translate_ui",
    "generate_tests",
    "generate_kt",
    "generate_onboard",
    "generate_equivalence_tests",
})


def _find_db() -> Path:
    """Find the graph.db for the active project.

    Priority:
    1. _active_project (set via set_project() tool)
    2. CODEBRAIN_PROJECT env var
    3. Walk up from CWD (original behavior)
    """
    # Check explicit project path first
    for candidate in (_active_project, os.environ.get("CODEBRAIN_PROJECT")):
        if candidate:
            p = Path(candidate)
            db = p / CODEBRAIN_DIR / DB_FILENAME
            if db.exists():
                return db
            # Maybe they pointed to the .codebrain dir itself
            if p.name == CODEBRAIN_DIR and (p / DB_FILENAME).exists():
                return p / DB_FILENAME

    # Fall back to CWD walk-up
    current = Path.cwd()
    for parent in [current, *current.parents]:
        db = parent / CODEBRAIN_DIR / DB_FILENAME
        if db.exists():
            return db

    hint = "Run `brain init` in the repo root first."
    if _active_project:
        hint = f"No index at {_active_project}. Run `brain init` there first."
    raise FileNotFoundError(f"No CodeBrain index found. {hint}")


def _get_repo_root() -> Path:
    """Return the repo root (parent of .codebrain/)."""
    db = _find_db()
    return db.parent.parent


def _make_store():
    from codebrain.graph.store import GraphStore
    return GraphStore(_find_db())


def _safe_tool(fn):  # noqa: ANN001, ANN201
    """Wrap an MCP tool so it cooperates with MCP cancellation.

    The returned wrapper is *async*. Sync tool work is dispatched to a worker
    thread via ``anyio.to_thread.run_sync(..., cancellable=True)``, which lets
    the asyncio event loop keep running while the tool executes. That
    matters because:

      - Without offloading, FastMCP calls sync tools directly in the event
        loop thread (``func_metadata.py:95``). The loop blocks; the client's
        ``notifications/cancelled`` queues; when the tool finally returns,
        the SDK still sends the (now-stale) response and the client tears
        down the stdio transport on the unknown message ID.
      - With offloading, asyncio can deliver the cancellation. The await
        raises ``CancelledError`` and the lowlevel SDK suppresses the
        response (``mcp/server/lowlevel/server.py:766-771``).

    Also enforces a wall-clock deadline (``TOOL_DEADLINE_SECONDS``) so
    runaway tools don't sit waiting on the user's Esc.
    """
    import sqlite3 as _sqlite3

    @functools.wraps(fn)
    async def wrapper(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        # Reset the idle-timeout clock on every tool entry. See mcp_lifecycle.
        from codebrain.mcp_lifecycle import mark_activity
        mark_activity()

        _log.debug("Tool invoked: %s", fn.__name__)

        deadline = (
            None if fn.__name__ in LONG_RUNNING_TOOLS else TOOL_DEADLINE_SECONDS
        )

        async def _invoke():
            return await anyio.to_thread.run_sync(
                _run_sync_protected, fn, args, kwargs,
                abandon_on_cancel=True,
            )

        try:
            if deadline is None:
                result = await _invoke()
            else:
                with anyio.move_on_after(deadline) as scope:
                    result = await _invoke()
                if scope.cancel_called:
                    _log.warning(
                        "Tool %s exceeded %ds deadline — returning timeout error",
                        fn.__name__, deadline,
                    )
                    return json.dumps({
                        "error": f"Tool exceeded {deadline}s server-side deadline.",
                        "tool": fn.__name__,
                        "hint": (
                            "The query took too long. Common causes: stale index "
                            "with vendored deps (run `brain reindex`), very deep "
                            "call chain, or a broad codebase-wide search. Try a "
                            "narrower query. Raise the limit with "
                            "CODEBRAIN_MCP_TOOL_TIMEOUT=<seconds>."
                        ),
                    })
            return result
        except FileNotFoundError:
            return json.dumps({
                "error": "No CodeBrain index found. Run `brain init` first.",
                "tool": fn.__name__,
            })
        except _sqlite3.OperationalError as exc:
            msg = str(exc).lower()
            _log.exception("Tool %s database error", fn.__name__)
            if "locked" in msg or "busy" in msg:
                return json.dumps({
                    "error": "Database is locked by another process.",
                    "tool": fn.__name__,
                    "hint": "Another CodeBrain process (CLI, API, or MCP) is using the database. Wait a few seconds and retry.",
                })
            return json.dumps({
                "error": str(exc),
                "tool": fn.__name__,
                "hint": "Database error. Try `reindex_codebase` to rebuild the index.",
            })
        except Exception as exc:
            _log.exception("Tool %s failed", fn.__name__)
            return json.dumps({
                "error": str(exc),
                "tool": fn.__name__,
                "hint": "Try running `reindex_codebase` if the index seems stale.",
            })
    return wrapper


def _run_sync_protected(fn, args, kwargs):  # noqa: ANN001, ANN202
    """Run a sync tool function with stdout redirected to stderr.

    Runs inside the anyio worker thread. Stdout is redirected for the
    duration of the call so any stray print or C-extension write goes to
    stderr instead of corrupting the MCP stdio transport. The transport
    grabbed its own ``sys.stdout.buffer`` reference at startup (see
    ``mcp/server/stdio.py:49``) so it is unaffected by this swap.
    """
    saved_stdout = sys.stdout
    sys.stdout = sys.stderr
    try:
        return fn(*args, **kwargs)
    finally:
        sys.stdout = saved_stdout


# ---------------------------------------------------------------------------
# Project management tools
# ---------------------------------------------------------------------------


@mcp.tool()
def set_project(path: str) -> str:
    """Switch CodeBrain to analyze a different project.

    Call this FIRST when working on a project that isn't in the current directory.
    All subsequent tool calls will use this project's knowledge graph.

    Args:
        path: Absolute path to the project root (must have .codebrain/graph.db).
              If not indexed yet, run `brain init` in that directory first.
    """
    global _active_project
    p = Path(path).resolve()
    db = p / CODEBRAIN_DIR / DB_FILENAME
    if not db.exists():
        return json.dumps({
            "error": f"No CodeBrain index found at {p}",
            "hint": f"Run `brain init` in {p} first, then call set_project again.",
        })
    _active_project = p
    _log.info("Active project set to %s", p)

    # Count nodes to confirm it's working
    from codebrain.graph.store import GraphStore
    with GraphStore(db) as store:
        nodes = store.get_all_nodes()
        node_count = len(nodes)

    return json.dumps({
        "status": "ok",
        "project": str(p),
        "db": str(db),
        "nodes": node_count,
        "message": f"Now analyzing {p.name} ({node_count} symbols indexed)",
    })


@mcp.tool()
def get_project() -> str:
    """Show which project CodeBrain is currently analyzing.

    Returns the active project path and basic stats.
    """
    try:
        db = _find_db()
        root = db.parent.parent
        from codebrain.graph.store import GraphStore
        with GraphStore(db) as store:
            nodes = store.get_all_nodes()
        return json.dumps({
            "project": str(root),
            "db": str(db),
            "nodes": len(nodes),
            "source": "set_project" if _active_project else "auto-detected",
        })
    except FileNotFoundError as e:
        return json.dumps({
            "error": str(e),
            "hint": "Use set_project('/path/to/repo') to point to an indexed project.",
        })


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool()
@_safe_tool
def search_symbol(query: str) -> str:
    """Search for functions, classes, methods, or variables by name.

    Use this as the starting point when you need to find code symbols.
    Returns matching nodes with file paths, line numbers, signatures, and docstrings.
    """
    from codebrain.graph.query import QueryEngine

    with _make_store() as store:
        engine = QueryEngine(store)
        results = engine.search_nodes(query, limit=30)
    return json.dumps(results)


@mcp.tool()
@_safe_tool
def get_symbol_context(name: str) -> str:
    """Get complete structural context for a symbol — everything needed to reason about it.

    Returns: signature, docstring, callers, callees, parent class/module,
    sibling functions, methods (if class), base classes, decorators,
    plus a plain-English summary explaining importance and risk.

    Tip: For file-level context, use get_file_context() instead.
    If you pass a file path here, it will automatically redirect.
    """
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.context import ContextGenerator

    with _make_store() as store:
        gen = ContextGenerator(store)
        comp = ComprehensionEngine(store)

        # Auto-detect file paths and redirect to get_file_context
        if "/" in name or name.endswith((".py", ".ts", ".js", ".tsx", ".jsx")):
            file_result = gen.for_file(name)
            if "error" not in file_result:
                file_result["_note"] = (
                    f"'{name}' is a file, not a symbol. "
                    "Showing file context instead. Use get_file_context() for files."
                )
                return json.dumps(file_result)

        results = gen.for_symbol(name)
        if not results:
            return json.dumps({"error": f"No symbol found matching '{name}'"})

        # Enrich each result with a narrative
        for ctx in results:
            node_id = ctx.get("id", "")
            if node_id:
                try:
                    narrative = comp.symbol_narrative(node_id)
                    if "error" not in narrative:
                        ctx["narrative"] = narrative
                except Exception:
                    pass

            # Add parser note for TypeScript/JavaScript files
            fp = ctx.get("file_path", "")
            if fp.endswith((".ts", ".tsx", ".js", ".jsx")):
                ctx["parser_note"] = "Parsed with experimental regex-based TypeScript parser. Some symbols and relationships may be missing."

    return json.dumps(results)


@mcp.tool()
@_safe_tool
def get_file_context(file_path: str, top_n: int = 30) -> str:
    """Get structural context for an entire file — symbols, imports, dependents.

    Returns structural data plus a plain-English narrative explaining
    what this file does, how important it is, and what risks to watch for.
    Use this instead of reading the full file when you need to understand
    what a module does and how it relates to the rest of the codebase.
    """
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.context import ContextGenerator

    with _make_store() as store:
        gen = ContextGenerator(store)
        comp = ComprehensionEngine(store)
        result = gen.for_file(file_path)

        # Enrich with narrative
        if "error" not in result:
            try:
                narrative = comp.module_narrative(file_path)
                if "error" not in narrative:
                    result["narrative"] = narrative
            except Exception:
                pass

    # Add parser note for TypeScript/JavaScript files
    if file_path.endswith((".ts", ".tsx", ".js", ".jsx")):
        result["parser_note"] = "Parsed with experimental regex-based TypeScript parser. Some symbols and relationships may be missing."

    # Truncate large lists to keep MCP responses manageable
    if "symbols" in result:
        total_symbols = len(result["symbols"])
        if total_symbols > top_n:
            result["symbols"] = result["symbols"][:top_n]
            result["total_symbols"] = total_symbols
    if "external_dependents" in result:
        total_deps = len(result["external_dependents"])
        if total_deps > top_n:
            result["external_dependents"] = result["external_dependents"][:top_n]
            result["total_external_dependents"] = total_deps

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def get_task_context(task_description: str, relevant_symbols: list[str]) -> str:
    """Get focused context for a task — combines multiple symbols with guidance.

    Provide a task description and the names of symbols you think are relevant.
    Returns structural context for all symbols, affected files, and actionable guidance.
    """
    from codebrain.context import ContextGenerator

    with _make_store() as store:
        gen = ContextGenerator(store)
        result = gen.for_task(task_description, relevant_symbols)
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def validate_change(file_path: str) -> str:
    """Validate a modified file against the knowledge graph BEFORE committing.

    Detects: removed symbols that have callers, signature changes that break
    call sites, and the full blast radius of the change. Returns a risk score (0-1)
    and specific violations with severity levels.

    Call this after modifying a file to check if the change is safe.
    """
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.query import QueryEngine
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)

        target = repo_root / file_path
        if not target.exists():
            report = validator.validate_deletion(file_path)
        else:
            report = validator.validate_file(target, repo_root)

        result = report.to_dict()

        # Active validation: automatically include impact, contracts, patterns, narrative
        try:
            engine = QueryEngine(store)
            comp = ComprehensionEngine(store)
            analyzer = StructuralAnalyzer(store)

            # Impact analysis on all symbols in the file
            nodes = store.get_nodes_by_file(file_path)
            all_nodes_list = store.get_all_nodes()
            node_by_id = {n["id"]: n for n in all_nodes_list}
            affected_files: set[str] = set()
            for node in nodes:
                if node["type"] == "file":
                    continue
                impacted = engine.impact_of_change(node["id"], max_depth=3)
                for entry in impacted:
                    t = node_by_id.get(entry["node_id"])
                    if t and t["file_path"] != file_path:
                        affected_files.add(t["file_path"])

            result["impact"] = {
                "affected_files": sorted(affected_files),
                "total_impacted": len(affected_files),
            }

            # Contract violations — filter to affected symbols
            contracts = analyzer.detect_contracts(min_confidence=0.5)
            node_names = {n["name"] for n in nodes}
            node_ids = {n["id"] for n in nodes}
            warnings = []
            for c in contracts:
                symbols = c.get("symbols", [])
                if any(s in node_names or s in node_ids for s in symbols):
                    warnings.append(c["message"])
            result["warnings"] = warnings[:10]

            # Narrative
            narrative = comp.module_narrative(file_path)
            if "error" not in narrative:
                result["narrative"] = (
                    f"{narrative['summary']} {narrative['importance']}"
                )
        except Exception as exc:
            _log.warning("Enrichment failed for %s: %s", file_path, exc)
            result["enrichment_partial"] = True
            result["enrichment_error"] = str(exc)

        # Add remediation guidance for violations
        if result.get("violations"):
            guidance = []
            for v in result["violations"]:
                if v["category"] == "removed_symbol":
                    guidance.append(f"Update callers of '{v['node_id']}' before removing it")
                elif v["category"] == "signature_change":
                    guidance.append(f"Check callers of '{v['node_id']}' for parameter compatibility")
                elif v["category"] == "broken_caller":
                    guidance.append(f"Fix '{v['node_id']}' in {v['file_path']}:{v['line']}")
            result["remediation"] = guidance[:10]

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def validate_changes(file_paths: list[str]) -> str:
    """Validate multiple modified files at once — the batch safety gate.

    Call this after modifying multiple files to get a single pass/fail verdict
    with aggregated impact analysis. Returns a clear verdict: SAFE, CAUTION, or UNSAFE.

    Args:
        file_paths: List of file paths that were modified.
    """
    from codebrain.analyzer import StructuralAnalyzer
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.query import QueryEngine
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)
        engine = QueryEngine(store)
        comp = ComprehensionEngine(store)

        all_violations = []
        all_affected: set[str] = set()
        file_results = []

        all_nodes_list = store.get_all_nodes()
        node_by_id = {n["id"]: n for n in all_nodes_list}

        for fp in file_paths:
            target = repo_root / fp
            if not target.exists():
                report = validator.validate_deletion(fp)
            else:
                report = validator.validate_file(target, repo_root)

            file_report = report.to_dict()

            # Impact analysis
            nodes = store.get_nodes_by_file(fp)
            for node in nodes:
                if node["type"] == "file":
                    continue
                impacted = engine.impact_of_change(node["id"], max_depth=3)
                for entry in impacted:
                    t = node_by_id.get(entry["node_id"])
                    if t and t["file_path"] != fp and t["file_path"] not in file_paths:
                        all_affected.add(t["file_path"])

            all_violations.extend(file_report.get("violations", []))
            file_results.append({
                "file": fp,
                "risk_score": file_report.get("risk_score", 0),
                "violations": len(file_report.get("violations", [])),
            })

        # Determine verdict
        max_risk = max((fr["risk_score"] for fr in file_results), default=0)
        total_violations = len(all_violations)
        if total_violations == 0 and len(all_affected) < 5:
            verdict = "SAFE"
        elif total_violations <= 2 and max_risk < 0.5:
            verdict = "CAUTION"
        else:
            verdict = "UNSAFE"

        # Build narrative
        if verdict == "SAFE":
            narrative = f"Changes to {len(file_paths)} file(s) look safe. No structural violations detected."
        elif verdict == "CAUTION":
            narrative = (
                f"Changes to {len(file_paths)} file(s) have minor risks: "
                f"{total_violations} violation(s), {len(all_affected)} external file(s) affected. Review recommended."
            )
        else:
            narrative = (
                f"Changes to {len(file_paths)} file(s) are UNSAFE: "
                f"{total_violations} violation(s), {len(all_affected)} external file(s) affected. "
                f"Fix violations before committing."
            )

        result = {
            "verdict": verdict,
            "narrative": narrative,
            "files": file_results,
            "total_violations": total_violations,
            "affected_external_files": sorted(all_affected),
            "violations": all_violations[:20],
        }

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def validate_after_write(file_paths: list[str]) -> str:
    """Re-validate files AFTER writing them to disk.

    Call this after writing modified files to verify nothing broke.
    Reads the files from disk and validates against the current knowledge graph.

    Args:
        file_paths: List of relative file paths that were just written.
    """
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)
        results = []

        for fp in file_paths:
            abs_path = repo_root / fp
            if not abs_path.exists():
                results.append({"file": fp, "status": "MISSING"})
                continue
            try:
                report = validator.validate_file(abs_path, repo_root)
                if report.is_valid:
                    results.append({"file": fp, "status": "OK"})
                else:
                    results.append({
                        "file": fp,
                        "status": "BROKEN",
                        "violations": [
                            {"severity": v.severity, "message": v.message}
                            for v in report.violations
                            if v.severity in ("critical", "high")
                        ][:5],
                    })
            except Exception as e:
                results.append({"file": fp, "status": "ERROR", "error": str(e)})

        all_ok = all(r["status"] == "OK" for r in results)
        return json.dumps({
            "verdict": "PASS" if all_ok else "FAIL",
            "files": results,
        })


@mcp.tool()
@_safe_tool
def get_validation_status() -> str:
    """Check if recent file changes caused structural breakage.

    Call this after writing files to verify nothing broke.
    Returns validation results from the file watcher if running,
    or validates recently modified files against the knowledge graph.
    """
    import os
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)
        # Find files modified in the last 60 seconds
        import time
        threshold = time.time() - 60
        results = []
        for root_dir, _dirs, files in os.walk(str(repo_root)):
            for fname in files:
                if not fname.endswith(('.py', '.ts', '.tsx', '.js', '.jsx')):
                    continue
                fpath = Path(root_dir) / fname
                try:
                    if fpath.stat().st_mtime > threshold:
                        rel = str(fpath.relative_to(repo_root)).replace("\\", "/")
                        report = validator.validate_file(fpath, repo_root)
                        status = "OK" if report.is_valid else "BROKEN"
                        entry: dict = {"file": rel, "status": status}
                        if not report.is_valid:
                            entry["violations"] = [
                                {"severity": v.severity, "message": v.message}
                                for v in report.violations
                                if v.severity in ("critical", "high")
                            ][:5]
                        results.append(entry)
                except Exception:
                    continue

        if not results:
            return json.dumps({"verdict": "PASS", "message": "No recently modified files.", "files": []})

        all_ok = all(r["status"] == "OK" for r in results)
        return json.dumps({
            "verdict": "PASS" if all_ok else "FAIL",
            "files": results,
        })


@mcp.tool()
@_safe_tool
def propose_change(file_path: str, new_content: str) -> str:
    """Check if proposed code is safe BEFORE writing it to disk.

    This is the structural safety gate. Pass the file path and the full
    new content you plan to write. Returns a verdict (SAFE/CAUTION/UNSAFE)
    with specific violations, affected files, and remediation steps.

    Use this before writing any file that modifies existing functions/classes.
    For new files, validation is less critical but still catches syntax errors.

    Args:
        file_path: Relative path within the repo (e.g. 'codebrain/api.py').
        new_content: The complete new file content to validate.
    """
    from codebrain.validator import ChangeValidator

    with _make_store() as store:
        repo_root = _get_repo_root()
        validator = ChangeValidator(store)
        report = validator.validate_content(file_path, new_content, repo_root)
        result = report.to_dict()

        # Determine verdict
        critical = sum(1 for v in result.get("violations", []) if v["severity"] == "critical")
        high = sum(1 for v in result.get("violations", []) if v["severity"] == "high")

        if critical > 0:
            verdict = "UNSAFE"
        elif high > 0:
            verdict = "CAUTION"
        else:
            verdict = "SAFE"

        # Build plain-English verdict
        if verdict == "SAFE":
            narrative = f"Proposed change to {file_path} is safe. {result.get('summary', '')}"
        elif verdict == "CAUTION":
            affected = result.get("affected_files", [])
            narrative = (
                f"Proposed change to {file_path} has risks: {result.get('summary', '')} "
                f"Affected files: {', '.join(affected[:5]) if affected else 'none'}."
            )
        else:
            narrative = (
                f"UNSAFE: Proposed change to {file_path} will break things. "
                f"{result.get('summary', '')} Fix violations before writing."
            )

        # Build response — verdict first, short for SAFE, detailed for UNSAFE
        response: dict = {"verdict": verdict, "narrative": narrative}

        if verdict == "SAFE":
            # Keep it short — don't waste agent context window
            response["changes"] = {
                "added": len(result.get("nodes_added", [])),
                "removed": len(result.get("nodes_removed", [])),
                "modified": len(result.get("nodes_modified", [])),
            }
        else:
            # Detailed response for CAUTION/UNSAFE
            response["violations"] = [
                v for v in result.get("violations", [])
                if v["severity"] in ("critical", "high")
            ]
            response["affected_files"] = result.get("affected_files", [])

            # files_to_update: extract caller file paths from violations
            files_to_update: dict[str, dict] = {}
            for v in result.get("violations", []):
                for caller in v.get("callers", []):
                    fp = caller.get("file", "")
                    if fp and fp != file_path:
                        if fp not in files_to_update:
                            files_to_update[fp] = {"file": fp, "reasons": []}
                        files_to_update[fp]["reasons"].append(
                            f"{v['category']}: {v['message'][:100]}"
                        )
            response["files_to_update"] = list(files_to_update.values())

            # Remediation guidance
            guidance = []
            for v in result.get("violations", []):
                if v["category"] == "removed_symbol":
                    guidance.append(f"Update callers of '{v['node_id']}' before removing it")
                elif v["category"] == "signature_change":
                    guidance.append(f"Check callers of '{v['node_id']}' for parameter compatibility")
                elif v["category"] == "broken_caller":
                    guidance.append(f"Fix '{v['node_id']}' in {v['file_path']}:{v['line']}")
                elif v["category"] == "syntax_error":
                    guidance.append(f"Fix syntax error at line {v['line']}: {v['message']}")
            response["remediation"] = guidance[:10]

    return json.dumps(response)


@mcp.tool()
@_safe_tool
def impact_analysis(name: str, max_depth: int = 5) -> str:
    """Show what could break if a function/class changes.

    Traces transitive reverse dependencies — every symbol that directly
    or indirectly depends on this one. Essential before modifying
    high-traffic code.

    Args:
        name: Symbol name, qualified name, or file path (e.g. 'auth.py' or 'backend/auth.py').
              File paths are expanded to all symbols in the file.
        max_depth: How many levels of transitive dependents to trace (default 5).
    """
    from codebrain.graph.query import QueryEngine

    with _make_store() as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        # Fallback: try as file path if resolve_node found nothing
        if not nodes:
            file_nodes = store.get_nodes_by_file(name)
            if file_nodes:
                nodes = file_nodes

        if not nodes:
            return json.dumps({"error": f"No symbol found matching '{name}'"})

        # Expand file-level nodes to their contained symbols
        expanded: list[dict] = []
        for node in nodes:
            if node["type"] == "file":
                file_symbols = store.get_nodes_by_file(node["file_path"])
                expanded.extend(s for s in file_symbols if s["type"] != "file")
            else:
                expanded.append(node)

        if not expanded:
            return json.dumps({"error": f"No symbols found in '{name}'"})

        _MAX_IMPACT_RESULTS = 200
        results = []
        seen_ids: set[str] = set()
        truncated = False
        for node in expanded:
            if len(seen_ids) >= _MAX_IMPACT_RESULTS:
                truncated = True
                break
            impacted = engine.impact_of_change(node["id"], max_depth=max_depth)
            # Deduplicate across symbols from the same file
            new_impacted = []
            for entry in impacted:
                if entry["node_id"] not in seen_ids:
                    seen_ids.add(entry["node_id"])
                    new_impacted.append(entry)
                    if len(seen_ids) >= _MAX_IMPACT_RESULTS:
                        truncated = True
                        break
            if new_impacted:
                results.append({"target": node["id"], "impacted": new_impacted})

        # Add narrative summary
        total_impacted = len(seen_ids)
        affected_files = {nid.split("::")[0] for nid in seen_ids if "::" in nid}
        if total_impacted == 0:
            narrative = f"No downstream dependents found for '{name}'. Safe to modify."
        elif total_impacted <= 5:
            narrative = f"Low blast radius: {total_impacted} symbol(s) in {len(affected_files)} file(s) depend on '{name}'."
        elif total_impacted <= 20:
            narrative = f"Medium blast radius: {total_impacted} symbol(s) in {len(affected_files)} file(s). Test thoroughly after changes."
        else:
            narrative = f"HIGH blast radius: {total_impacted} symbol(s) in {len(affected_files)} file(s). This is load-bearing code — changes are risky."

        resp = {"narrative": narrative, "total_impacted": total_impacted, "affected_files": len(affected_files), "details": results}
        if truncated:
            resp["truncated"] = True
            resp["note"] = f"Results capped at {_MAX_IMPACT_RESULTS}. Actual impact may be larger."

    return json.dumps(resp)


@mcp.tool()
@_safe_tool
def call_chain(name: str, max_depth: int = 5) -> str:
    """Trace forward call chain from a function — what does it call, transitively.

    Useful for understanding execution flow and identifying all code paths
    triggered by calling a function.

    Args:
        name: Symbol name, qualified name, or file path (e.g. 'auth.py' or 'backend/auth.py').
              File paths are expanded to all symbols in the file.
        max_depth: How many levels deep to trace (default 5).
    """
    from codebrain.graph.query import QueryEngine

    with _make_store() as store:
        engine = QueryEngine(store)

        nodes = engine.resolve_node(name)
        # Fallback: try as file path if resolve_node found nothing
        if not nodes:
            file_nodes = store.get_nodes_by_file(name)
            if file_nodes:
                nodes = file_nodes

        if not nodes:
            return json.dumps({"error": f"No symbol found matching '{name}'"})

        # Expand file-level nodes to their contained symbols
        expanded: list[dict] = []
        for node in nodes:
            if node["type"] == "file":
                file_symbols = store.get_nodes_by_file(node["file_path"])
                expanded.extend(s for s in file_symbols if s["type"] != "file")
            else:
                expanded.append(node)

        if not expanded:
            return json.dumps({"error": f"No symbols found in '{name}'"})

        _MAX_CHAIN_RESULTS = 200
        results = []
        seen_ids: set[str] = set()
        truncated = False
        for node in expanded:
            if len(seen_ids) >= _MAX_CHAIN_RESULTS:
                truncated = True
                break
            chain = engine.get_call_chain(node["id"], max_depth=max_depth)
            # Deduplicate across symbols from the same file
            new_chain = []
            for entry in chain:
                if entry["node_id"] not in seen_ids:
                    seen_ids.add(entry["node_id"])
                    new_chain.append(entry)
                    if len(seen_ids) >= _MAX_CHAIN_RESULTS:
                        truncated = True
                        break
            if new_chain:
                results.append({"root": node["id"], "chain": new_chain})

        # Build narrative
        total_calls = len(seen_ids)
        call_files = {nid.split("::")[0] for nid in seen_ids if "::" in nid}
        if total_calls == 0:
            narrative = f"'{name}' makes no outgoing calls to other indexed symbols."
        elif total_calls <= 5:
            narrative = f"'{name}' has a shallow call tree: {total_calls} function(s) across {len(call_files)} file(s)."
        else:
            narrative = f"'{name}' triggers {total_calls} function(s) across {len(call_files)} file(s). Deep call tree — changes to callees may affect this function's behavior."

        resp = {"narrative": narrative, "total_calls": total_calls, "call_files": len(call_files), "details": results}
        if truncated:
            resp["truncated"] = True
            resp["note"] = f"Results capped at {_MAX_CHAIN_RESULTS}."

    return json.dumps(resp)


@mcp.tool()
@_safe_tool
def codebase_overview() -> str:
    """Get a high-level overview of the entire codebase.

    Returns: package structure, symbol counts, entry points,
    inter-package dependencies, plus a human-readable narrative.
    Use this first to orient yourself in an unfamiliar codebase.
    """
    from codebrain.comprehension import ComprehensionEngine

    with _make_store() as store:
        comp = ComprehensionEngine(store)
        result = comp.system_overview()
        narrative = comp.system_narrative()
        result["narrative"] = {
            "summary": narrative["summary"],
            "architecture": narrative["architecture"],
            "health": narrative["health_summary"],
            "recommendations": narrative["recommendations"],
        }
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def codebase_anatomy() -> str:
    """Get a subsystem map of the codebase — the 'truck parts' view.

    Groups files into named subsystems with descriptions, importance
    rankings, and inter-subsystem connections. Ideal for onboarding
    new developers or understanding how the codebase is organized.

    Tries LLM-enhanced descriptions first, falls back to deterministic.
    """
    repo_root = _get_repo_root()
    try:
        from codebrain.llm import LLMNarrator, load_llm_settings
        settings = load_llm_settings(repo_root)
        if settings.enabled:
            from codebrain.config import CODEBRAIN_DIR
            cache_dir = repo_root / CODEBRAIN_DIR
            with _make_store() as store:
                narrator = LLMNarrator(store, settings, cache_dir)
                result = narrator.explain_anatomy()
            return json.dumps(result)
    except ImportError:
        pass

    from codebrain.comprehension import ComprehensionEngine
    with _make_store() as store:
        comp = ComprehensionEngine(store)
        result = comp.codebase_anatomy()
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def module_overview(file_path: str) -> str:
    """Get overview of a package (directory) or module (file).

    Pass a package name like 'codebrain/graph' for package view,
    or a file path like 'codebrain/graph/store.py' for file view.
    Auto-detects based on whether input ends with a source file extension.

    Returns: role, symbols, exports, imports, imported_by, coupling score,
    plus a human-readable narrative explaining importance and risks.
    """
    from codebrain.comprehension import ComprehensionEngine

    _source_exts = ('.py', '.ts', '.tsx', '.js', '.jsx')
    with _make_store() as store:
        comp = ComprehensionEngine(store)
        if file_path.endswith(_source_exts):
            # File/module level
            result = comp.module_view(file_path)
            if "error" not in result:
                narrative = comp.module_narrative(file_path)
                result["narrative"] = {
                    "summary": narrative["summary"],
                    "importance": narrative["importance"],
                    "risks": narrative["risks"],
                    "top_callers": narrative["top_callers"],
                }
            result["zoom_out"] = "Use codebase_overview() for system view."
            result["drill_down"] = "Use get_symbol_context('<name>') for symbol details."
        else:
            # Package level
            result = comp.package_view(file_path)
            result["zoom_out"] = "Use codebase_overview() for system view."
            result["drill_down"] = "Use module_overview('<file_path>') for file details."
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def risk_hotspots(top_n: int = 15) -> str:
    """Find the riskiest symbols in the codebase.

    Ranked by: number of dependents, cross-file impact, transitive reach.
    These are the symbols where changes are most likely to cause breakage.
    Returns data plus a human-readable narrative per hotspot.
    """
    from codebrain.comprehension import ComprehensionEngine

    with _make_store() as store:
        comp = ComprehensionEngine(store)
        stats = store.get_stats()
        total_files = stats.get("files", 1)
        results = comp.risk_hotspots(top_n=top_n)
        for item in results:
            risk_level = "HIGH" if item["risk_score"] > 20 else ("MEDIUM" if item["risk_score"] > 5 else "LOW")
            pct = item["affected_files"] / max(total_files, 1) * 100
            item["narrative"] = (
                f"{item['name']} ({item['type']}) — {risk_level} risk. "
                f"{item['direct_dependents']} direct dependents, "
                f"affects {item['affected_files']} files ({pct:.0f}% of codebase)."
            )
            # Per-hotspot why field with specific file names
            caller_files = []
            if "callers" in item:
                caller_files = list({c.get("file", "").rsplit("/", 1)[-1]
                                     for c in item.get("callers", []) if c.get("file")})[:4]
            item["why"] = (
                f"Called by {item['direct_dependents']} symbols across {item['affected_files']} files. "
                f"A signature change would cascade through "
                f"{', '.join(caller_files) if caller_files else 'dependent modules'}."
            )
    return json.dumps(results)


@mcp.tool()
@_safe_tool
def find_dead_code(top_n: int = 50) -> str:
    """Find potentially unused functions and classes.

    Returns symbols with no incoming calls or imports, excluding
    entry points and exported APIs.

    Args:
        top_n: Maximum number of dead code entries to return (default 50).
    """
    from codebrain.graph.query import QueryEngine

    repo_root = str(_get_repo_root())

    with _make_store() as store:
        engine = QueryEngine(store)
        dead = engine.find_dead_code(repo_root=repo_root)

    total = len(dead)

    # Group by confidence
    high = [d for d in dead if d.get("confidence") == "high"]
    medium = [d for d in dead if d.get("confidence") == "medium"]
    low = [d for d in dead if d.get("confidence") == "low"]

    if total == 0:
        narrative = "No dead code detected. All symbols have incoming references."
    else:
        parts = []
        if high:
            parts.append(f"{len(high)} high-confidence (likely truly dead)")
        if medium:
            parts.append(f"{len(medium)} medium (in files with dynamic dispatch)")
        if low:
            parts.append(f"{len(low)} low (private helpers)")
        narrative = f"Found {total} potentially unused symbols. {', '.join(parts)}."

    summary = {
        "total_dead_code_found": total,
        "narrative": narrative,
        "high_confidence": high[:top_n],
        "medium_confidence": medium[:top_n],
        "low_confidence": low[:top_n],
        "note": (
            "Excludes: test files, framework entry points, exported symbols, "
            "dunder methods, variables/constants, __all__ listed symbols. "
            "High-confidence items are most likely truly unused."
        ),
    }
    return json.dumps(summary)


@mcp.tool()
@_safe_tool
def detect_import_cycles() -> str:
    """Find circular import dependencies in the codebase.

    Returns cycles with a narrative explaining severity and fix suggestions.
    """
    from codebrain.graph.query import QueryEngine

    with _make_store() as store:
        engine = QueryEngine(store)
        cycles = engine.detect_cycles()

    if not cycles:
        narrative = "No import cycles detected. Clean dependency structure."
    elif len(cycles) == 1:
        narrative = f"Found 1 import cycle involving {len(cycles[0])} module(s). Consider extracting shared code into a separate module."
    else:
        total_files = len({f for c in cycles for f in c})
        narrative = f"Found {len(cycles)} import cycles involving {total_files} module(s). These create tight coupling and make layering impossible. Break cycles by extracting shared interfaces."

    return json.dumps({"narrative": narrative, "total_cycles": len(cycles), "cycles": cycles})


@mcp.tool()
@_safe_tool
def test_coverage_gaps(
    max_depth: int = 3,
    include_methods: bool = True,
    min_risk: float = 0.0,
) -> str:
    """Structural test coverage gap analysis.

    Traces CALLS edges from test functions into production code to find
    symbols that no test path reaches. Gaps are ranked by risk.

    Args:
        max_depth: How far to trace calls from test functions (0=unlimited).
        include_methods: Include methods in coverage stats.
        min_risk: Only report gaps with risk_score >= this threshold.
    """
    from dataclasses import asdict
    from codebrain.test_gaps import TestCoverageAnalyzer

    with _make_store() as store:
        analyzer = TestCoverageAnalyzer(store)
        report = analyzer.analyze(
            max_depth=max_depth,
            include_methods=include_methods,
            min_risk=min_risk,
        )

    result = asdict(report)
    # Trim gaps to top 50 for MCP context window
    result["gaps"] = result["gaps"][:50]
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def detect_architecture() -> str:
    """Detect codebase architecture pattern, frameworks, DB, and infrastructure.

    Returns architecture report including pattern (MVC, layered, etc.),
    frameworks, database technology, infrastructure, module roles,
    layer mapping, and boundary violations.
    """
    from codebrain.architecture import ArchitectureDetector

    with _make_store() as store:
        detector = ArchitectureDetector(store)
        report = detector.detect()

    return json.dumps(report.to_dict())


@mcp.tool()
@_safe_tool
def run_tests(
    scope: str = "all",
    runner: str = "auto",
    timeout: int = 300,
) -> str:
    """Run the project's test suite and map results to the knowledge graph.

    Executes tests via the detected runner (pytest/jest/go test), parses
    results, and maps pass/fail back to production symbols via CALLS edges.

    WARNING: This executes the project's test suite. Tests may have side
    effects (database writes, network calls, file I/O).

    Args:
        scope: "all" (run everything), "affected" (only tests for uncommitted changes),
               or "file:<path>" (tests covering a specific file).
        runner: "auto" (detect), "pytest", "jest", or "go".
        timeout: Max seconds for test execution (default 300).
    """
    from dataclasses import asdict
    from codebrain.test_runner import TestRunner

    repo_root = _get_repo_root()
    with _make_store() as store:
        tr = TestRunner(store, repo_root)
        report = tr.run_tests(scope=scope, runner=runner, timeout=timeout)

    result = asdict(report)
    result["at_risk_symbols"] = result["at_risk_symbols"][:30]
    result["results"] = result["results"][:100]
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def test_status() -> str:
    """Show the last test run results and at-risk production symbols.

    Does not execute any tests. Returns the most recent stored run
    with current at-risk symbols mapped to the knowledge graph.
    """
    from codebrain.test_runner import TestRunner

    repo_root = _get_repo_root()
    with _make_store() as store:
        tr = TestRunner(store, repo_root)
        status = tr.test_status()

    if not status:
        return json.dumps({"narrative": "No test runs recorded yet. Use run_tests() first."})
    return json.dumps(status)


@mcp.tool()
@_safe_tool
def affected_tests(changed_files: list[str] | None = None) -> str:
    """Find which test files need to run after code changes.

    Reverse-traverses CALLS edges from changed symbols to find all
    test functions that exercise those symbols. Does not run tests.

    Args:
        changed_files: List of changed file paths. If empty/None, uses git diff HEAD.
    """
    from codebrain.test_runner import TestRunner

    repo_root = _get_repo_root()
    with _make_store() as store:
        tr = TestRunner(store, repo_root)
        files = tr.affected_tests(changed_files or None)

    return json.dumps({
        "affected_test_files": files,
        "count": len(files),
        "narrative": f"Found {len(files)} test file(s) affected by the changes."
                     if files else "No test files are affected by the changes.",
    })


@mcp.tool()
@_safe_tool
def test_for_symbol(name: str) -> str:
    """Find which tests cover a specific symbol and their last pass/fail status.

    Args:
        name: Symbol name to look up.
    """
    from codebrain.test_runner import TestRunner

    repo_root = _get_repo_root()
    with _make_store() as store:
        tr = TestRunner(store, repo_root)
        result = tr.test_for_symbol(name)

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def architectural_layers(top_n: int = 30) -> str:
    """Show how the codebase layers from foundation to top-level orchestrators.

    Layer 0 = leaf modules with no internal dependencies (safest to modify).
    Higher layers depend on lower ones. Cycles are flagged.

    Args:
        top_n: Maximum modules per layer to show (default 30).
    """
    from codebrain.analyzer import StructuralAnalyzer

    with _make_store() as store:
        analyzer = StructuralAnalyzer(store)
        result = analyzer.detect_layers()

    # Truncate each layer's files list to top_n entries
    if "layers" in result:
        for layer in result["layers"]:
            files = layer.get("files", [])
            total = len(files)
            if total > top_n:
                truncated = files[:top_n]
                layer["files"] = truncated
                layer["total_files"] = total
                layer["files_truncated"] = True
            else:
                layer["total_files"] = total
                layer["files_truncated"] = False
            # Add per-layer summary string
            shown = layer["files"]
            short_names = [f.rsplit("/", 1)[-1] for f in shown[:3]]
            remaining = total - len(short_names)
            if remaining > 0:
                layer["summary"] = f"{total} files ({', '.join(short_names)}, +{remaining} more)"
            else:
                layer["summary"] = f"{total} files ({', '.join(short_names)})"

    # Add overall narrative
    layers = result.get("layers", [])
    cycle_layers = [l for l in layers if l["layer"] == -1]
    normal_layers = [l for l in layers if l["layer"] >= 0]
    edge_res = result.get("edge_resolution", {})

    parts = [f"Architecture has {len(normal_layers)} layer(s)."]
    if cycle_layers:
        cycle_files = sum(l["total_files"] for l in cycle_layers)
        parts.append(f"{cycle_files} file(s) are in dependency cycles (layer -1) — consider breaking these.")
    if edge_res.get("unresolved", 0) > 0:
        parts.append(
            f"Edge resolution: {edge_res['resolution_rate']} of dependencies resolved. "
            f"{edge_res['unresolved']} unresolved edges (mostly third-party imports)."
        )
    result["narrative"] = " ".join(parts)

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def implicit_contracts(top_n: int = 30) -> str:
    """Detect implicit contracts — patterns that are fragile but not enforced.

    Finds: co-imported symbol pairs, co-called function groups,
    and duck-typing interfaces (classes sharing method sets).
    Breaking these patterns causes subtle bugs.

    Args:
        top_n: Maximum entries per contract type to return (default 30).
    """
    from codebrain.analyzer import StructuralAnalyzer

    with _make_store() as store:
        analyzer = StructuralAnalyzer(store)
        contracts = analyzer.detect_contracts()
        violations = analyzer.check_contract_violations(contracts)

    total = len(contracts)
    contracts = contracts[:top_n]

    # Narrative
    if total == 0:
        narrative = "No implicit contracts detected. The codebase has few tightly co-used symbol pairs."
    else:
        co_imports = sum(1 for c in contracts if c["type"] == "co_import")
        co_calls = sum(1 for c in contracts if c["type"] == "co_call")
        interfaces = sum(1 for c in contracts if c["type"] in ("shared_interface", "interface"))
        parts = []
        if co_imports:
            parts.append(f"{co_imports} co-import contracts")
        if co_calls:
            parts.append(f"{co_calls} co-call contracts")
        if interfaces:
            parts.append(f"{interfaces} interface contracts")
        violation_note = f" {len(violations)} violation(s) found." if violations else " No violations."
        narrative = f"Found {total} implicit contracts: {'; '.join(parts)}.{violation_note}"

    summary = {
        "narrative": narrative,
        "total_contracts_found": total,
        "showing": len(contracts),
        "items": contracts,
        "violations": violations,
    }
    return json.dumps(summary)


@mcp.tool()
@_safe_tool
def reindex_codebase() -> str:
    """Force a full reindex of the codebase.

    Call this after major refactoring or if the index seems stale.
    """
    from codebrain.indexer import full_index

    repo_root = _get_repo_root()
    db_path = repo_root / CODEBRAIN_DIR / DB_FILENAME
    # Clear tables in-place instead of deleting the file.
    # This avoids file lock conflicts when the MCP server holds the DB open.
    if db_path.exists():
        with _make_store() as store:
            store.clear_all()
    result = full_index(repo_root, db_path)
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def export_dot(name: str = "") -> str:
    """Export graph as Graphviz DOT format.

    Optionally limit to a subgraph around a symbol name.
    Returns a DOT string that can be rendered with Graphviz.
    """
    from codebrain.export import GraphExporter

    with _make_store() as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=name or None)
        return exporter.to_dot(nodes, edges)


@mcp.tool()
@_safe_tool
def export_mermaid(name: str = "") -> str:
    """Export graph as Mermaid flowchart format.

    Optionally limit to a subgraph around a symbol name.
    Returns a Mermaid string for use in Markdown.
    """
    from codebrain.export import GraphExporter

    with _make_store() as store:
        exporter = GraphExporter(store)
        nodes, edges = exporter.get_subgraph(name=name or None)
        return exporter.to_mermaid(nodes, edges)


@mcp.tool()
@_safe_tool
def query_modules(package: str = "", depth: int = 3) -> str:
    """Show the high-level module/subsystem structure of the codebase.

    Groups files by directory structure and shows inter-module dependencies.
    Use this to understand how the codebase is organized before diving into details.

    Args:
        package: Filter to a specific package (e.g. 'backend'). Empty = all.
        depth: Directory depth for grouping (2-4). Higher = more granular.
    """
    from collections import defaultdict

    with _make_store() as store:
        file_nodes = store.get_all_nodes(type_filter="file")
        all_edges = store.get_all_edges()
        all_nodes = store.get_all_nodes()

    def _mod_key(fp: str) -> str:
        parts = fp.split("/")
        dp = parts[:-1] if len(parts) > 1 else parts
        return "/".join(dp[:depth]) if len(dp) >= depth else "/".join(dp)

    if package:
        file_nodes = [n for n in file_nodes if n["file_path"].startswith(package + "/")]

    mod_files = defaultdict(int)
    mod_symbols = defaultdict(int)
    for n in file_nodes:
        mod_files[_mod_key(n["file_path"])] += 1
    for n in all_nodes:
        if n["type"] != "file" and n.get("file_path"):
            k = _mod_key(n["file_path"])
            if k in mod_files:
                mod_symbols[k] += 1

    node_mod: dict[str, str] = {}
    for n in all_nodes:
        fp = n.get("file_path", "")
        if fp:
            node_mod[n["id"]] = _mod_key(fp)
            node_mod[n["name"]] = _mod_key(fp)

    edge_w = defaultdict(int)
    for e in all_edges:
        if e["type"] not in ("CALLS", "IMPORTS"):
            continue
        sm = node_mod.get(e["source"])
        tm = node_mod.get(e["target"])
        if sm and tm and sm != tm and sm in mod_files and tm in mod_files:
            edge_w[(sm, tm)] += 1

    modules = []
    for mod, fc in sorted(mod_files.items(), key=lambda x: -mod_symbols.get(x[0], 0)):
        modules.append({"module": mod, "files": fc, "symbols": mod_symbols.get(mod, 0)})

    connections = []
    for (s, t), w in sorted(edge_w.items(), key=lambda x: -x[1])[:50]:
        connections.append({"from": s, "to": t, "references": w})

    # Narrative
    if not modules:
        narrative = "No modules found."
    else:
        top3 = sorted(modules, key=lambda m: -m["symbols"])[:3]
        top_str = ", ".join(f"{m['module']} ({m['symbols']} symbols)" for m in top3)
        narrative = f"{len(modules)} modules found. Largest: {top_str}."
        if connections:
            heaviest = connections[0]
            narrative += f" Strongest dependency: {heaviest['from']} -> {heaviest['to']} ({heaviest['references']} references)."

    return json.dumps({"narrative": narrative, "modules": modules, "connections": connections})


@mcp.tool()
@_safe_tool
def query_dependencies(module_path: str, direction: str = "both") -> str:
    """Show what a module/directory depends on and what depends on it.

    Args:
        module_path: Directory path (e.g. 'backend/palmistry' or 'backend/vedic-profiles/engines').
        direction: 'incoming' (who calls this), 'outgoing' (what this calls), or 'both'.
    """
    from collections import defaultdict

    with _make_store() as store:
        all_nodes = store.get_all_nodes()
        all_edges = store.get_all_edges()

    # Map each node to its module
    node_mod: dict[str, str] = {}
    mod_nodes: set[str] = set()
    for n in all_nodes:
        fp = n.get("file_path", "")
        if fp:
            node_mod[n["id"]] = fp
            node_mod[n["name"]] = fp
            if fp.startswith(module_path + "/") or fp == module_path:
                mod_nodes.add(n["id"])

    # Detect language of the target module to filter cross-language false positives
    _PY_EXTS = (".py",)
    _JS_EXTS = (".ts", ".tsx", ".js", ".jsx")

    def _lang(path: str) -> str:
        ext = os.path.splitext(path)[1].lower() if path else ""
        if ext in _PY_EXTS:
            return "python"
        if ext in _JS_EXTS:
            return "js"
        return "other"

    # Determine language of the module from its files
    mod_langs = {_lang(node_mod.get(nid, "")) for nid in mod_nodes}
    mod_langs.discard("other")

    incoming = defaultdict(int)
    outgoing = defaultdict(int)
    for e in all_edges:
        if e["type"] not in ("CALLS", "IMPORTS"):
            continue
        src_in = e["source"] in mod_nodes
        tgt_fp = node_mod.get(e["target"], "")
        tgt_in = tgt_fp.startswith(module_path + "/") or tgt_fp == module_path

        if src_in and not tgt_in and tgt_fp:
            # Skip cross-language edges (Python <-> JS/TS)
            if mod_langs and _lang(tgt_fp) not in mod_langs and _lang(tgt_fp) != "other":
                continue
            outgoing[tgt_fp.rsplit("/", 1)[0] if "/" in tgt_fp else tgt_fp] += 1
        if tgt_in and not src_in:
            src_fp = node_mod.get(e["source"], "")
            if src_fp:
                # Skip cross-language edges
                if mod_langs and _lang(src_fp) not in mod_langs and _lang(src_fp) != "other":
                    continue
                incoming[src_fp.rsplit("/", 1)[0] if "/" in src_fp else src_fp] += 1

    result = {"module": module_path}
    if direction in ("both", "incoming"):
        result["used_by"] = [{"module": k, "references": v} for k, v in sorted(incoming.items(), key=lambda x: -x[1])[:20]]
    if direction in ("both", "outgoing"):
        result["depends_on"] = [{"module": k, "references": v} for k, v in sorted(outgoing.items(), key=lambda x: -x[1])[:20]]

    # Narrative
    in_count = len(incoming)
    out_count = len(outgoing)
    if in_count == 0 and out_count == 0:
        narrative = f"'{module_path}' has no detected dependencies in either direction."
    elif in_count > out_count * 2:
        narrative = f"'{module_path}' is a provider: {in_count} modules depend on it, it depends on {out_count}. Changes here have wide blast radius."
    elif out_count > in_count * 2:
        narrative = f"'{module_path}' is a consumer: depends on {out_count} modules, only {in_count} depend on it. Lower risk to modify."
    else:
        narrative = f"'{module_path}' has balanced dependencies: {in_count} incoming, {out_count} outgoing."
    result["narrative"] = narrative

    return json.dumps(result)


@mcp.tool()
@_safe_tool
def explain_code(target: str) -> str:
    """Get an AI-generated explanation of a module, file, or the whole system.

    Uses the LLM layer (xAI Grok) to produce a natural language explanation
    of the structural data. Falls back to deterministic narrative if LLM unavailable.

    Args:
        target: 'system' for codebase overview, or a file path for module explanation.
    """
    from codebrain.comprehension import ComprehensionEngine
    from codebrain.graph.query import QueryEngine

    repo_root = _get_repo_root()
    try:
        from codebrain.llm import LLMNarrator, load_llm_settings
        settings = load_llm_settings(repo_root)
        cache_dir = repo_root / CODEBRAIN_DIR
    except ImportError:
        settings = None

    with _make_store() as store:
        engine = QueryEngine(store)
        comp = ComprehensionEngine(store)

        if target == "system":
            narrative = comp.system_narrative()
            if settings and settings.enabled:
                narrator = LLMNarrator(store, settings, cache_dir)
                result = narrator.explain_system()
                return json.dumps(result)
            return json.dumps(narrative)
        else:
            narrative = comp.module_narrative(target)
            if narrative.get("error"):
                return json.dumps(narrative)
            if settings and settings.enabled:
                narrator = LLMNarrator(store, settings, cache_dir)
                result = narrator.explain_module(target)
                return json.dumps(result)
            return json.dumps(narrative)


@mcp.tool()
@_safe_tool
def ask_codebase(question: str) -> str:
    """Ask a natural language question about the codebase structure.

    Analyzes the question, queries the knowledge graph, and uses LLM to
    generate a clear answer. Works best for structural questions like:
    - "How do the astrology modules interact?"
    - "What are the main subsystems?"
    - "What would break if I change the auth middleware?"
    - "What are the riskiest files?"

    Args:
        question: Your question about the codebase.
    """
    from codebrain.comprehension import ComprehensionEngine

    repo_root = _get_repo_root()

    with _make_store() as store:
        comp = ComprehensionEngine(store)
        result = comp.answer_question(question)

    # Try LLM enhancement
    try:
        from codebrain.llm import LLMNarrator, load_llm_settings

        settings = load_llm_settings(repo_root)
        if settings.enabled and settings.api_keys:
            cache_dir = repo_root / CODEBRAIN_DIR
            with _make_store() as store:
                narrator = LLMNarrator(store, settings, cache_dir=cache_dir)
                result = narrator.ask(question)
    except ImportError:
        pass

    return json.dumps(result, default=str)


# ---------------------------------------------------------------------------
# Memory tools
# ---------------------------------------------------------------------------


def _make_memory_store(scope: str = "project"):
    """Create a MemoryStore for the given scope."""
    from codebrain.memory.store import MemoryStore

    if scope == "global":
        db = Path.home() / ".codebrain" / "memory.db"
    else:
        db = _get_repo_root() / CODEBRAIN_DIR / "memory.db"
    db.parent.mkdir(parents=True, exist_ok=True)
    return MemoryStore(db)


@mcp.tool()
@_safe_tool
def save_memory(
    content: str,
    category: str,
    tags: list[str] | None = None,
    scope: str = "project",
    expires_in_days: float | None = None,
    source: str = "",
) -> str:
    """Save a memory to CodeBrain's persistent memory store.

    Use this to remember session context, codebase patterns, architectural
    decisions, user preferences, or risk notes across conversations.

    Args:
        content: The memory content — be specific and self-contained.
        category: One of 'session', 'pattern', 'decision', 'preference', 'risk'.
        tags: Optional list of tags for filtering (e.g. ['auth', 'api']).
        scope: 'project' (default) or 'global' (cross-project).
        expires_in_days: Auto-expire after N days. None = never.
        source: Where this memory came from (e.g. 'conversation', 'code-review').
    """
    import time

    expires_at = None
    if expires_in_days is not None:
        expires_at = time.time() + (expires_in_days * 86400)

    with _make_memory_store(scope) as store:
        memory_id = store.save(
            content=content,
            category=category,
            tags=tags or [],
            expires_at=expires_at,
            source=source,
        )
        result = store.get(memory_id)

    return json.dumps({"saved": result})


@mcp.tool()
@_safe_tool
def recall_memories(
    query: str,
    category: str | None = None,
    scope: str = "both",
    limit: int = 20,
) -> str:
    """Search memories using full-text search.

    Finds memories matching the query across content, category, and tags.
    Use this to recall context from previous sessions, known patterns,
    or past decisions.

    Args:
        query: Search terms (e.g. 'auth middleware', 'database migration').
        category: Filter to a specific category. None = all.
        scope: 'project', 'global', or 'both' (default — merges results).
        limit: Max results to return (default 20).
    """
    results = []
    seen_ids: set[str] = set()

    scopes = ["project", "global"] if scope == "both" else [scope]
    for s in scopes:
        try:
            with _make_memory_store(s) as store:
                store.cleanup_expired()
                hits = store.search(query, category=category, limit=limit)
                for hit in hits:
                    if hit["id"] not in seen_ids:
                        hit["scope"] = s
                        seen_ids.add(hit["id"])
                        results.append(hit)
        except FileNotFoundError:
            continue

    results = results[:limit]
    return json.dumps({"count": len(results), "memories": results})


@mcp.tool()
@_safe_tool
def list_memories(
    category: str | None = None,
    scope: str = "project",
    limit: int = 20,
) -> str:
    """List recent memories sorted by last updated.

    Args:
        category: Filter to a specific category. None = all.
        scope: 'project' (default), 'global', or 'both'.
        limit: Max results to return (default 20).
    """
    results = []
    seen_ids: set[str] = set()

    scopes = ["project", "global"] if scope == "both" else [scope]
    for s in scopes:
        try:
            with _make_memory_store(s) as store:
                store.cleanup_expired()
                hits = store.list_recent(category=category, limit=limit)
                for hit in hits:
                    if hit["id"] not in seen_ids:
                        hit["scope"] = s
                        seen_ids.add(hit["id"])
                        results.append(hit)
        except FileNotFoundError:
            continue

    # Sort merged results by updated_at DESC
    results.sort(key=lambda m: m["updated_at"], reverse=True)
    results = results[:limit]

    stats = {}
    for s in scopes:
        try:
            with _make_memory_store(s) as store:
                stats[s] = store.stats()
        except FileNotFoundError:
            continue

    return json.dumps({"count": len(results), "memories": results, "stats": stats})


@mcp.tool()
@_safe_tool
def update_memory(
    memory_id: str,
    content: str | None = None,
    confidence: float | None = None,
    tags: list[str] | None = None,
    scope: str = "project",
) -> str:
    """Update an existing memory.

    Args:
        memory_id: The ID of the memory to update.
        content: New content (optional).
        confidence: New confidence score 0.0-1.0 (optional).
        tags: New tags list (optional).
        scope: 'project' (default) or 'global'.
    """
    with _make_memory_store(scope) as store:
        updated = store.update(
            memory_id, content=content, confidence=confidence, tags=tags,
        )
        if not updated:
            return json.dumps({"error": f"Memory '{memory_id}' not found in {scope} store"})
        result = store.get(memory_id)

    return json.dumps({"updated": result})


@mcp.tool()
@_safe_tool
def delete_memory(memory_id: str, scope: str = "project") -> str:
    """Delete a memory by ID.

    Args:
        memory_id: The ID of the memory to delete.
        scope: 'project' (default) or 'global'.
    """
    with _make_memory_store(scope) as store:
        deleted = store.delete(memory_id)

    if not deleted:
        return json.dumps({"error": f"Memory '{memory_id}' not found in {scope} store"})
    return json.dumps({"deleted": memory_id, "scope": scope})


@mcp.tool()
@_safe_tool
def migration_plan() -> str:
    """Generate a dependency-ordered migration plan.

    Analyzes the codebase and outputs a phased rewrite plan.
    Leaf modules (no dependents) go first, orchestrators last.
    Each phase includes public API contracts that must be preserved.
    """
    from codebrain.migration import MigrationPlanGenerator

    with _make_store() as store:
        gen = MigrationPlanGenerator(store)
        plan = gen.generate_plan()
    return json.dumps(plan, default=str)


@mcp.tool()
@_safe_tool
def extract_contracts(file_path: str = "") -> str:
    """Extract public API contracts from the codebase.

    Returns function signatures, class interfaces, callers/callees,
    and data flow paths — the spec new code must match.

    Args:
        file_path: Limit to a specific file (empty = all files).
    """
    from codebrain.migration import ContractExtractor

    with _make_store() as store:
        ext = ContractExtractor(store)
        result = ext.extract(file_path=file_path if file_path else None)
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def migration_status(new_project_path: str) -> str:
    """Compare old and new codebases to track migration progress.

    Current project = old codebase. Provide the path to the new
    codebase (must be indexed with 'brain init' first).

    Args:
        new_project_path: Path to the new project root.
    """
    from codebrain.migration import MigrationTracker

    from codebrain.graph.store import GraphStore as _GS

    new_db = Path(new_project_path) / ".codebrain" / "graph.db"
    if not new_db.exists():
        return json.dumps({"error": f"New project not indexed at {new_project_path}"})

    with _make_store() as old_store:
        with _GS(new_db) as new_store:
            tracker = MigrationTracker()
            result = tracker.compare(old_store, new_store)
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def migration_report(new_project_path: str) -> str:
    """Generate a full equivalence report between old and new codebases.

    Compares API coverage, class hierarchies, broken call chains.
    Current project = old, new_project_path = new.

    Args:
        new_project_path: Path to the new project root.
    """
    from codebrain.graph.store import GraphStore as _GS
    from codebrain.migration import EquivalenceReporter

    new_db = Path(new_project_path) / ".codebrain" / "graph.db"
    if not new_db.exists():
        return json.dumps({"error": f"New project not indexed at {new_project_path}"})

    with _make_store() as old_store:
        with _GS(new_db) as new_store:
            reporter = EquivalenceReporter()
            result = reporter.report(old_store, new_store)
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def modernize_spec(
    file_path: str = "",
    target_stack: str = "",
    guidelines: str = "",
) -> str:
    """Generate a modernization/rewrite spec for the codebase.

    Produces comprehensive specifications that an AI agent can follow to
    rewrite modules — with contracts, dependencies, call chains, test
    scenarios, and rewrite guidance.

    Args:
        file_path: Single module to spec (empty = full codebase).
        target_stack: Description of the target tech stack.
        guidelines: Additional rewrite guidelines/constraints.
    """
    from codebrain.modernize import SpecGenerator

    with _make_store() as store:
        gen = SpecGenerator(store)
        if file_path:
            spec = gen.generate_module_spec(file_path)
            return json.dumps(spec, default=str)
        else:
            spec = gen.generate_full_spec(
                target_stack=target_stack,
                guidelines=guidelines,
            )
            return gen.to_markdown(spec, max_modules=30)


@mcp.tool()
@_safe_tool
def translate_module(
    file_path: str,
    target_lang: str,
    target_stack: str = "",
    provider: str = "",
    model: str = "",
    base_url: str = "",
    api_key: str = "",
) -> str:
    """Translate a single module to a different programming language.

    Uses AI with structural validation to translate the module while
    preserving public API contracts. Flags constructs that need manual
    review (generators, decorators, metaclasses, etc.).

    Args:
        file_path: Source file to translate.
        target_lang: Target language (go, java, kotlin, rust, typescript, csharp, dart).
        target_stack: Target framework (e.g., gin, spring, fastapi).
        provider: LLM provider (ollama, openai, anthropic, azure).
        model: LLM model name.
        base_url: LLM API base URL.
        api_key: LLM API key.
    """
    from codebrain.rewriter import RewriteEngine, create_client

    valid_langs = {"go", "java", "kotlin", "rust", "typescript", "csharp", "python", "dart"}
    if target_lang not in valid_langs:
        return json.dumps({"error": f"Invalid target_lang '{target_lang}'. Must be one of: {', '.join(sorted(valid_langs))}"})

    client = create_client(
        provider=provider, base_url=base_url,
        model=model, api_key=api_key,
    )
    if not client.is_available():
        return json.dumps({"error": "LLM endpoint not reachable. Check provider/URL/API key."})

    repo_root = _get_repo_root()
    with _make_store() as store:
        engine = RewriteEngine(
            old_root=repo_root, store=store,
            client=client, target_lang=target_lang,
        )
        result = engine.rewrite_module(
            file_path, target_stack=target_stack,
        )

    return json.dumps({
        "file_path": result.file_path,
        "status": result.status,
        "attempts": result.attempts,
        "warnings": result.warnings,
        "errors": result.errors,
        "code_length": len(result.code) if result.code else 0,
        "target_lang": target_lang,
    })


@mcp.tool()
@_safe_tool
def translate_codebase(
    output_dir: str,
    target_lang: str,
    target_stack: str = "",
    provider: str = "",
    model: str = "",
    base_url: str = "",
    api_key: str = "",
) -> str:
    """Translate the entire codebase to a different programming language.

    Translates module by module in dependency order, preserving public
    API contracts. Optionally verifies the output compiles with the
    target language toolchain.

    Args:
        output_dir: Directory for translated code output.
        target_lang: Target language (go, java, kotlin, rust, typescript, csharp, dart).
        target_stack: Target framework (e.g., gin, spring, fastapi).
        provider: LLM provider (ollama, openai, anthropic, azure).
        model: LLM model name.
        base_url: LLM API base URL.
        api_key: LLM API key.
    """
    from codebrain.rewriter import RewriteEngine, create_client

    valid_langs = {"go", "java", "kotlin", "rust", "typescript", "csharp", "python", "dart"}
    if target_lang not in valid_langs:
        return json.dumps({"error": f"Invalid target_lang '{target_lang}'. Must be one of: {', '.join(sorted(valid_langs))}"})

    client = create_client(
        provider=provider, base_url=base_url,
        model=model, api_key=api_key,
    )
    if not client.is_available():
        return json.dumps({"error": "LLM endpoint not reachable. Check provider/URL/API key."})

    repo_root = _get_repo_root()
    out_path = Path(output_dir)

    with _make_store() as store:
        engine = RewriteEngine(
            old_root=repo_root, store=store,
            client=client, target_lang=target_lang,
        )
        result = engine.rewrite_all(
            output_dir=out_path,
            target_stack=target_stack,
        )

    return json.dumps(result.to_dict())


@mcp.tool()
@_safe_tool
def generate_kt(project_name: str = "", include_module_details: bool = True) -> str:
    """Generate a Knowledge Transfer document with architectural diagrams.

    Produces a comprehensive Markdown document with embedded Mermaid diagrams
    covering: executive summary, architecture overview, package structure,
    layers, risk hotspots, health assessment, and module details.

    Args:
        project_name: Name for the document title (auto-detected if empty).
        include_module_details: Include per-module breakdowns (default True).
    """
    from codebrain.kt import KTGenerator

    with _make_store() as store:
        gen = KTGenerator(store)
        return gen.generate(
            project_name=project_name if project_name else None,
            include_module_details=include_module_details,
        )


@mcp.tool()
@_safe_tool
def architecture_tour(max_steps: int = 15) -> str:
    """Generate a guided architecture tour — dependency-ordered learning path.

    Produces a topologically sorted tour through the codebase, starting from
    foundations (data models, utilities) and building up through layers to
    the entry points. Each stop includes files to read and key symbols.

    Args:
        max_steps: Maximum number of tour stops (default 15).
    """
    from codebrain.tour import TourGenerator

    with _make_store() as store:
        gen = TourGenerator(store)
        result = gen.generate(max_steps=max_steps)
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def diff_impact(ref: str = "", staged_only: bool = False) -> str:
    """Analyze blast radius of git changes before committing.

    Maps changed files to the knowledge graph and computes which symbols
    and layers are transitively affected. Shows risk level and cross-layer impact.

    Args:
        ref: Git ref to diff against (e.g. 'main', 'HEAD~3'). Empty = uncommitted changes.
        staged_only: Only analyze staged changes (default False).
    """
    from codebrain.diff_impact import DiffImpactAnalyzer

    repo_root = _get_repo_root()
    with _make_store() as store:
        analyzer = DiffImpactAnalyzer(store, repo_root)
        result = analyzer.analyze(
            ref=ref if ref else None,
            staged_only=staged_only,
        )
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def generate_onboard(project_name: str = "", detail_level: str = "standard") -> str:
    """Generate a developer onboarding guide for the codebase.

    Produces a comprehensive Markdown guide including: project overview,
    architecture, guided tour, key concepts, file map, risk hotspots,
    and next steps for new developers.

    Args:
        project_name: Name for the guide title (auto-detected if empty).
        detail_level: 'brief', 'standard', or 'deep' (default 'standard').
    """
    from codebrain.onboard import OnboardingGenerator

    with _make_store() as store:
        gen = OnboardingGenerator(store)
        return gen.generate(
            project_name=project_name if project_name else None,
            detail_level=detail_level,
        )


@mcp.tool()
@_safe_tool
def zoom(target: str = "") -> str:
    """Multi-resolution zoom — like Google Maps for your codebase.

    Navigate between three zoom levels with drill-down/zoom-out hints:
    - No target (empty string): system level — what is this codebase?
    - File path: module level — what does this file do?
    - Symbol name: symbol level — full context for one function/class

    Each response includes navigation hints to zoom in or out.
    """
    from codebrain.comprehension import ComprehensionEngine

    with _make_store() as store:
        comp = ComprehensionEngine(store)
        result = comp.zoom(target if target else None)
    return json.dumps(result, default=str)


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------

def _get_status_impl() -> str:
    """Current index status — file count, node count, edge count."""
    with _make_store() as store:
        stats = store.get_stats()
    return json.dumps(stats)


@mcp.resource("codebrain://status")
def _get_status_resource() -> str:
    """Current index status."""
    return _get_status_impl()


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Autonomous actions (M27)
# ---------------------------------------------------------------------------


@mcp.tool()
@_safe_tool
def generate_tests(
    symbol: str = "",
    file_path: str = "",
    gaps: bool = False,
    count: int = 5,
    min_risk: float = 0.3,
    run_tests: bool = False,
) -> str:
    """Generate pytest tests for untested symbols using AI + structural context.

    Uses CodeBrain's knowledge graph (call chains, fingerprints, coverage gaps)
    to produce targeted, runnable tests.

    REQUIRES an LLM configured via environment variables:
    - CODEBRAIN_LLM_PROVIDER (anthropic, openai, ollama)
    - CODEBRAIN_LLM_MODEL
    - CODEBRAIN_LLM_API_KEY

    Args:
        symbol: Generate test for this specific symbol.
        file_path: Generate tests for all untested symbols in this file.
        gaps: Generate for top untested symbols from coverage analysis.
        count: Max symbols to generate for (with gaps=True).
        min_risk: Minimum risk score filter (with gaps=True).
        run_tests: Actually execute generated tests to verify.
    """
    from codebrain.rewriter import create_client
    from codebrain.actions.test_gen import TestGenerator

    client = create_client()
    repo_root = _get_repo_root()

    with _make_store() as store:
        gen = TestGenerator(store, repo_root, client)

        if gaps:
            results = gen.generate_for_gaps(min_risk=min_risk, max_count=count)
        elif file_path:
            results = gen.generate_for_file(file_path)
        elif symbol:
            results = [gen.generate_for_symbol(symbol)]
        else:
            return json.dumps({"error": "Specify symbol, file_path, or gaps=True"})

    data = [
        {
            "symbol": r.symbol_name,
            "file": r.file_path,
            "test_file": r.test_file_path,
            "test_count": r.test_count,
            "validated": r.validated,
            "ran_successfully": r.ran_successfully,
            "error": r.error,
        }
        for r in results
    ]
    total = sum(r.test_count for r in results)
    validated = sum(1 for r in results if r.validated)
    return json.dumps({
        "results": data,
        "summary": f"Generated {total} tests for {len(results)} symbols ({validated} validated)",
    }, indent=2)


@mcp.tool()
@_safe_tool
def code_review(
    base: str = "HEAD~1",
    full: bool = False,
    changed_files: str = "",
) -> str:
    """Structural code review of changes with full dependency graph awareness.

    Detects breaking changes (removed symbols, signature changes),
    missing test coverage, and optionally uses LLM for deeper analysis.

    Args:
        base: Git ref to compare against (default: HEAD~1).
        full: Include LLM-powered suggestions (requires LLM config).
        changed_files: Comma-separated file paths (overrides git diff).
    """
    from codebrain.actions.reviewer import CodeReviewer

    repo_root = _get_repo_root()
    llm = None
    if full:
        from codebrain.rewriter import create_client
        llm = create_client()

    with _make_store() as store:
        reviewer = CodeReviewer(store, repo_root, llm)

        if changed_files:
            files = [f.strip() for f in changed_files.split(",")]
            result = reviewer.review_files(files, full=full)
        else:
            result = reviewer.review_diff(base=base, full=full)

    return json.dumps({
        "changed_files": result.changed_files,
        "findings": [
            {
                "severity": f.severity,
                "category": f.category,
                "file": f.file_path,
                "line": f.line,
                "message": f.message,
                "suggestion": f.suggestion,
            }
            for f in result.findings
        ],
        "summary": result.summary,
        "risk_score": result.risk_score,
        "approved": result.approved,
        "test_suggestions": result.test_suggestions,
    }, indent=2)


@mcp.tool()
@_safe_tool
def suggest_refactorings(
    category: str = "all",
    auto_fix: bool = False,
    dry_run: bool = True,
    count: int = 10,
) -> str:
    """Detect structural problems and optionally generate fixes.

    Finds dead code, import cycles, high coupling, and god classes.
    Can suggest fixes or generate them with LLM assistance.

    Args:
        category: Filter: "all", "dead_code", "cycles", "coupling", "god_class".
        auto_fix: If True, generate fix code (requires LLM config).
        dry_run: If True, don't write changes to disk.
        count: Max suggestions to return.
    """
    from codebrain.actions.refactor import Refactorer

    repo_root = _get_repo_root()
    llm = None
    if auto_fix:
        from codebrain.rewriter import create_client
        llm = create_client()

    with _make_store() as store:
        refactorer = Refactorer(store, repo_root, llm)
        suggestions = refactorer.suggest(category)[:count]

        if not auto_fix:
            return json.dumps({
                "suggestions": [
                    {
                        "category": s.category,
                        "severity": s.severity,
                        "file": s.file_path,
                        "symbol": s.symbol_name,
                        "message": s.message,
                        "strategy": s.strategy,
                        "effort": s.estimated_effort,
                    }
                    for s in suggestions
                ],
                "count": len(suggestions),
            }, indent=2)

        results = [refactorer.fix(s, dry_run=dry_run) for s in suggestions]

    return json.dumps({
        "results": [
            {
                "category": r.suggestion.category,
                "symbol": r.suggestion.symbol_name,
                "file": r.suggestion.file_path,
                "status": r.status,
                "error": r.error,
                "patch_preview": r.patch[:300] if r.patch else "",
            }
            for r in results
        ],
        "succeeded": sum(1 for r in results if r.status == "success"),
        "failed": sum(1 for r in results if r.status == "failed"),
    }, indent=2)


# ---------------------------------------------------------------------------
# Frontend analysis tools
# ---------------------------------------------------------------------------


@mcp.tool()
@_safe_tool
def component_tree() -> str:
    """Get the frontend component hierarchy.

    Returns a tree structure showing which components render which children,
    which props are passed, and which components are root (not rendered by others).
    """
    from codebrain.frontend import FrontendAnalyzer

    with _make_store() as store:
        analyzer = FrontendAnalyzer(store)
        result = analyzer.get_component_tree()
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def route_map() -> str:
    """Get all frontend routes with their target components.

    Returns route paths mapped to the components they render.
    Supports React Router, Vue Router, and Angular Router patterns.
    """
    from codebrain.frontend import FrontendAnalyzer

    with _make_store() as store:
        analyzer = FrontendAnalyzer(store)
        result = analyzer.get_route_map()
    return json.dumps(result, default=str)


@mcp.tool()
@_safe_tool
def frontend_report() -> str:
    """Full frontend analysis report.

    Includes: component tree, route map, state management graph,
    API surface (all fetch/axios calls), orphan components,
    and unrouted page components.
    """
    from codebrain.frontend import FrontendAnalyzer

    with _make_store() as store:
        analyzer = FrontendAnalyzer(store)
        report = analyzer.analyze()
    return json.dumps(report.to_dict(), default=str)


@mcp.tool()
@_safe_tool
def component_contract(name: str) -> str:
    """Get the full contract for a single frontend component.

    Shows: props interface, children rendered, state subscriptions,
    API calls, routes served, and parent components.
    """
    from codebrain.frontend import FrontendAnalyzer

    with _make_store() as store:
        analyzer = FrontendAnalyzer(store)
        result = analyzer.get_component_contract(name)
    return json.dumps(result, default=str)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Cross-repo tools
# ---------------------------------------------------------------------------


@mcp.tool()
@_safe_tool
def cross_repo_list() -> str:
    """List all repos registered in the cross-repo registry.

    Shows repo slugs, paths, and detected packages.
    Use 'brain cross register <path>' to add repos.
    """
    from codebrain.cross_registry import CrossRegistry
    with CrossRegistry() as reg:
        repos = reg.list_repos()
    return json.dumps({"repos": repos, "count": len(repos)})


@mcp.tool()
@_safe_tool
def cross_repo_deps() -> str:
    """Show the inter-repo dependency graph.

    Analyzes imports across all registered repos to show which repos
    depend on which. Returns repos, edges with import counts, and a narrative.
    """
    from codebrain.cross_registry import CrossRegistry
    from codebrain.cross_query import CrossQueryEngine
    with CrossRegistry() as reg:
        engine = CrossQueryEngine(reg)
        result = engine.dependency_graph()
    return json.dumps(result)


@mcp.tool()
@_safe_tool
def cross_repo_impact(symbol: str, repo_slug: str = "") -> str:
    """Cross-repo impact analysis — what breaks across ALL registered repos.

    Args:
        symbol: Name or ID of the symbol being changed.
        repo_slug: Repo where the change originates (default: current repo name).

    Returns internal impact + external repos affected with blast radius.
    """
    from codebrain.cross_registry import CrossRegistry
    from codebrain.cross_query import CrossQueryEngine
    slug = repo_slug or _get_repo_root().name
    with CrossRegistry() as reg:
        engine = CrossQueryEngine(reg)
        result = engine.cross_impact(slug, symbol)
    return json.dumps(result)


# ---------------------------------------------------------------------------
# Environment migration tools
# ---------------------------------------------------------------------------

@mcp.tool()
@_safe_tool
def environment_analyze() -> str:
    """Analyze project infrastructure (deps, Docker, CI, env vars).

    Scans the current project for requirements.txt, package.json,
    Dockerfile, CI configs, and .env files. Returns a structured
    environment profile.
    """
    from codebrain.env_migration import EnvironmentMigrator

    repo_root = _get_repo_root()
    migrator = EnvironmentMigrator()
    profile = migrator.analyze(repo_root)
    return json.dumps(migrator.to_dict(profile), indent=2)


@mcp.tool()
@_safe_tool
def environment_migrate(
    output_dir: str,
    target_lang: str,
    target_stack: str = "",
) -> str:
    """Generate infrastructure files for a target language.

    Reads the current project's environment profile and generates
    Dockerfile, CI config, dependency file skeleton, and .env for the
    target language.

    Args:
        output_dir: Directory to write generated files.
        target_lang: Target language (go, rust, java, typescript).
        target_stack: Optional target framework/stack.
    """
    from codebrain.env_migration import EnvironmentMigrator

    repo_root = _get_repo_root()
    migrator = EnvironmentMigrator()
    profile = migrator.analyze(repo_root)
    files = migrator.generate(
        profile, target_lang, target_stack, Path(output_dir),
    )
    result = [
        {"path": gf.path, "description": gf.description}
        for gf in files
    ]
    return json.dumps({"files_generated": len(result), "files": result}, indent=2)


# ---------------------------------------------------------------------------
# Equivalence test generation
# ---------------------------------------------------------------------------

@mcp.tool()
@_safe_tool
def generate_equivalence_tests(
    new_project_path: str,
    output_dir: str = "",
    target_lang: str = "",
    provider: str = "",
    model: str = "",
    base_url: str = "",
    api_key: str = "",
) -> str:
    """Generate equivalence tests proving old_fn(x) == new_fn(x) after migration.

    Compares the current (old) project with new_project_path and generates
    pytest tests that call both old and new code with the same inputs and
    assert outputs match.  Uses importlib isolation for same-language tests
    and JSON stdin/stdout wrappers for cross-language tests.

    Args:
        new_project_path: Path to the new/rewritten project root.
        output_dir: Directory for generated tests (default: <repo>/equiv_tests).
        target_lang: Target language for cross-language tests (empty = same-language).
        provider: LLM provider (ollama, openai, anthropic, azure).
        model: LLM model name.
        base_url: LLM API base URL.
        api_key: LLM API key.
    """
    from codebrain.equivalence import EquivalenceTestGenerator
    from codebrain.rewriter import create_client

    new_root = Path(new_project_path)
    if not new_root.exists():
        return json.dumps({"error": f"New project path not found: {new_project_path}"})

    client = create_client(
        provider=provider, base_url=base_url,
        model=model, api_key=api_key,
    )
    if not client.is_available():
        return json.dumps({"error": "LLM endpoint not reachable. Check provider/URL/API key."})

    repo_root = _get_repo_root()
    out_path = Path(output_dir) if output_dir else repo_root / "equiv_tests"

    with _make_store() as store:
        gen = EquivalenceTestGenerator(store, client)
        result = gen.generate(
            old_root=repo_root,
            new_root=new_root,
            output_dir=out_path,
            target_lang=target_lang,
        )

    return json.dumps({
        "total": result.total,
        "skipped": result.skipped,
        "output_dir": str(out_path),
        "tests": [
            {"symbol": t.symbol_name, "file": t.test_file, "status": t.status}
            for t in result.tests
        ],
    })


# ---------------------------------------------------------------------------
# Schema migration tools
# ---------------------------------------------------------------------------

@mcp.tool()
@_safe_tool
def schema_extract() -> str:
    """Extract database schema from ORM models in the codebase.

    Detects SQLAlchemy/Django models and returns tables, columns,
    types, constraints, and relationships as structured JSON.
    """
    from codebrain.schema_migration import SchemaMigrator

    with _make_store() as store:
        migrator = SchemaMigrator(store)
        schema = migrator.extract_schema()
        return json.dumps(migrator.to_dict(schema), indent=2)


@mcp.tool()
@_safe_tool
def schema_diff(new_project_path: str) -> str:
    """Compare database schemas between current and new project.

    Indexes the new project, extracts schemas from both codebases,
    and returns differences in tables, columns, types, and relationships.

    Args:
        new_project_path: Path to the new project root.
    """
    from codebrain.graph.store import GraphStore as _GS
    from codebrain.indexer import full_index
    from codebrain.schema_migration import SchemaMigrator

    new_root = Path(new_project_path)
    new_db = new_root / ".codebrain" / "codebrain.db"
    new_db.parent.mkdir(parents=True, exist_ok=True)
    full_index(new_root, new_db)

    with _make_store() as old_store:
        with _GS(str(new_db)) as new_store:
            old_migrator = SchemaMigrator(old_store)
            new_migrator = SchemaMigrator(new_store)
            old_schema = old_migrator.extract_schema()
            new_schema = new_migrator.extract_schema()
            diff_result = old_migrator.diff(old_schema, new_schema)
            return json.dumps(old_migrator.diff_to_dict(diff_result), indent=2)


@mcp.tool()
@_safe_tool
def schema_migrate(new_project_path: str, fmt: str = "sql") -> str:
    """Generate migration scripts between current and new project schemas.

    Supports SQL, Alembic (Python), and Flyway (versioned SQL) formats.

    Args:
        new_project_path: Path to the new project root.
        fmt: Migration format — 'sql', 'alembic', or 'flyway'.
    """
    from codebrain.graph.store import GraphStore as _GS
    from codebrain.indexer import full_index
    from codebrain.schema_migration import SchemaMigrator

    new_root = Path(new_project_path)
    new_db = new_root / ".codebrain" / "codebrain.db"
    new_db.parent.mkdir(parents=True, exist_ok=True)
    full_index(new_root, new_db)

    with _make_store() as old_store:
        with _GS(str(new_db)) as new_store:
            old_migrator = SchemaMigrator(old_store)
            new_migrator = SchemaMigrator(new_store)
            old_schema = old_migrator.extract_schema()
            new_schema = new_migrator.extract_schema()
            diff_result = old_migrator.diff(old_schema, new_schema)

            if fmt == "alembic":
                content = old_migrator.generate_alembic(diff_result)
            elif fmt == "flyway":
                content = old_migrator.generate_flyway(diff_result)
            else:
                content = old_migrator.generate_sql(diff_result)

            return json.dumps({
                "format": fmt,
                "has_changes": diff_result.has_changes,
                "migration": content,
            }, indent=2)


# ---------------------------------------------------------------------------
# UI Framework Translation
# ---------------------------------------------------------------------------

@mcp.tool()
@_safe_tool
def detect_ui_framework() -> str:
    """Detect the frontend framework used in the indexed codebase.

    Returns the detected framework ('vue', 'react', or 'unknown'),
    component count, and route count.
    """
    from codebrain.ui_migration import UITranslator

    with _make_store() as store:
        translator = UITranslator(store)
        framework = translator.detect_framework()
        stats = store.get_stats()
        component_count = stats.get("node_types", {}).get("component", 0)
        route_count = stats.get("node_types", {}).get("route", 0)

    return json.dumps({
        "framework": framework,
        "component_count": component_count,
        "route_count": route_count,
    })


@mcp.tool()
@_safe_tool
def translate_ui(
    output_dir: str,
    target_framework: str,
    provider: str = "",
    model: str = "",
    component: str = "",
) -> str:
    """Translate UI components between frontend frameworks (Vue <-> React).

    Uses CodeBrain's structural analysis to enrich LLM prompts with
    component contracts (props, events, children, state, API calls),
    then delegates to RewriteEngine for the actual translation.

    Args:
        output_dir: Directory for translated component files.
        target_framework: Target framework ('react' or 'vue').
        provider: LLM provider (ollama, openai, anthropic, azure).
        model: LLM model name.
        component: Optional single component name to translate.
    """
    from dataclasses import asdict
    from codebrain.rewriter import RewriteEngine, create_client
    from codebrain.ui_migration import UITranslationResult, UITranslator

    repo_root = _get_repo_root()
    out_path = Path(output_dir)

    client = create_client(provider=provider, model=model)
    if not client.is_available():
        return json.dumps({
            "error": "LLM endpoint not reachable. Set provider/model/API key.",
        })

    target_lang = "typescript" if target_framework == "react" else "javascript"

    with _make_store() as store:
        translator = UITranslator(store)
        specs = translator.extract_component_specs()

        if component:
            specs = [s for s in specs if s.name == component]
            if not specs:
                return json.dumps({"error": f"Component '{component}' not found."})

        engine = RewriteEngine(
            old_root=repo_root, store=store,
            client=client,
            target_lang=target_lang,
        )

        results: list[UITranslationResult] = []
        for spec in specs:
            prompt = translator.build_enriched_prompt(spec, target_framework)
            try:
                result = engine.rewrite_module(
                    spec.file_path,
                    output_dir=out_path,
                    target_stack=target_framework,
                    guidelines=prompt,
                )
                code = getattr(result, "code", "") or ""
                ui_errors = translator.validate_translation(
                    spec, code, target_framework,
                ) if code else ["No code generated"]
                results.append(UITranslationResult(
                    component_name=spec.name,
                    source_framework=spec.framework,
                    target_framework=target_framework,
                    translated_code=code,
                    validation_errors=ui_errors,
                    status="success" if code and not ui_errors else (
                        "warnings" if code else "failed"
                    ),
                ))
            except Exception as exc:
                results.append(UITranslationResult(
                    component_name=spec.name,
                    source_framework=spec.framework,
                    target_framework=target_framework,
                    validation_errors=[str(exc)],
                    status="failed",
                ))

        checklist = translator.generate_wiring_checklist(target_framework)

    return json.dumps({
        "components_translated": len(results),
        "results": [asdict(r) for r in results],
        "wiring_checklist": checklist,
    }, indent=2)


def run_server() -> None:
    """Start the MCP server on stdio with automatic background file watching.

    Protects the MCP stdio transport from stray stdout writes that would
    corrupt the JSON-RPC stream and disconnect the client. This is the #1
    cause of "MCP keeps disconnecting" — any print(), C-extension write,
    or logging misconfiguration that hits stdout breaks the protocol.
    """
    _log.info("Starting CodeBrain MCP server on stdio")

    # Redirect stdout to stderr during watcher init to catch any import-time prints.
    _real_stdout = sys.stdout
    sys.stdout = sys.stderr

    observer = None
    watcher_store = None
    repo_root_for_watchdogs: Path | None = None
    try:
        db_path = _find_db()
        repo_root = db_path.parent.parent
        repo_root_for_watchdogs = repo_root
        from codebrain.watcher.file_watcher import start_watching_background
        observer, watcher_store, _watcher_handler = start_watching_background(repo_root, db_path)
        _log.info("Auto-indexing enabled for %s", repo_root)
    except FileNotFoundError:
        _log.info("No index found — auto-indexing disabled (run `brain init` first)")
    except Exception as exc:
        _log.warning("Could not start file watcher: %s", exc)

    # Install lifecycle watchdogs: parent-PID, idle timeout, PID file.
    # Without these the server leaks when Claude Code disconnects ungracefully —
    # the SQLite DB stays locked and `brain reindex` hits WinError 32.
    from codebrain.mcp_lifecycle import install_watchdogs
    install_watchdogs(repo_root_for_watchdogs)

    # Restore stdout for the MCP transport (FastMCP needs the real stdout)
    sys.stdout = _real_stdout

    try:
        mcp.run(transport="stdio")
    finally:
        if observer is not None:
            try:
                observer.stop()
                observer.join(timeout=5)
            except Exception:
                pass
        if watcher_store is not None:
            try:
                watcher_store.close()
            except Exception:
                pass


if __name__ == "__main__":
    run_server()
