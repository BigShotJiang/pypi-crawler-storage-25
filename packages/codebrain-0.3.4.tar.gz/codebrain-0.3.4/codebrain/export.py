"""Export module — DOT, Mermaid, and HTML report generation."""

from __future__ import annotations

from codebrain.graph.query import QueryEngine
from codebrain.graph.store import GraphStore


class GraphExporter:
    """Export graph data in multiple visualization formats."""

    def __init__(self, store: GraphStore) -> None:
        self.store = store
        self.engine = QueryEngine(store)

    def to_dot(
        self,
        nodes: list[dict] | None = None,
        edges: list[dict] | None = None,
        title: str = "CodeBrain",
    ) -> str:
        """Generate Graphviz DOT format string.

        If *nodes* and *edges* are not provided, uses the full graph.
        """
        if nodes is None:
            nodes = self.store.get_all_nodes()
        if edges is None:
            edges = self.store.get_all_edges()

        lines = [
            f'digraph "{title}" {{',
            '  rankdir=LR;',
            '  node [shape=box, style=filled, fontname="Helvetica"];',
        ]

        type_colors = {
            "file": "#E8F5E9",
            "class": "#E3F2FD",
            "function": "#FFF3E0",
            "method": "#FFF8E1",
            "variable": "#F3E5F5",
        }

        node_ids = set()
        for n in nodes:
            nid = _dot_id(n["id"])
            node_ids.add(n["id"])
            color = type_colors.get(n["type"], "#FAFAFA")
            label = f"{n['type']}\\n{n['name']}"
            lines.append(f'  {nid} [label="{label}", fillcolor="{color}"];')

        for e in edges:
            if e["source"] in node_ids and e["target"] in node_ids:
                sid = _dot_id(e["source"])
                tid = _dot_id(e["target"])
                style = _dot_edge_style(e["type"])
                lines.append(f"  {sid} -> {tid} [{style}];")

        lines.append("}")
        return "\n".join(lines)

    def to_mermaid(
        self,
        nodes: list[dict] | None = None,
        edges: list[dict] | None = None,
        title: str = "CodeBrain",
    ) -> str:
        """Generate Mermaid flowchart string.

        If *nodes* and *edges* are not provided, uses the full graph.
        """
        if nodes is None:
            nodes = self.store.get_all_nodes()
        if edges is None:
            edges = self.store.get_all_edges()

        lines = [f"flowchart LR"]

        node_ids = set()
        for n in nodes:
            mid = _mermaid_id(n["id"])
            node_ids.add(n["id"])
            label = f'{n["type"]}: {n["name"]}'
            shape = _mermaid_shape(n["type"])
            lines.append(f"  {mid}{shape[0]}\"{label}\"{shape[1]}")

        for e in edges:
            if e["source"] in node_ids and e["target"] in node_ids:
                sid = _mermaid_id(e["source"])
                tid = _mermaid_id(e["target"])
                arrow = _mermaid_arrow(e["type"])
                lines.append(f"  {sid} {arrow}|{e['type']}| {tid}")

        return "\n".join(lines)

    def to_html_report(
        self,
        overview: dict | None = None,
        hotspots: list[dict] | None = None,
        layers: dict | None = None,
    ) -> str:
        """Generate a self-contained HTML report.

        Uses Jinja2 for templating. All CSS/JS is inlined.
        """
        from codebrain.comprehension import ComprehensionEngine
        from codebrain.analyzer import StructuralAnalyzer

        if overview is None:
            comp = ComprehensionEngine(self.store)
            overview = comp.system_overview()
        if hotspots is None:
            comp = ComprehensionEngine(self.store)
            hotspots = comp.risk_hotspots(top_n=30)
        if layers is None:
            analyzer = StructuralAnalyzer(self.store)
            layers = analyzer.detect_layers()

        try:
            from jinja2 import Template
        except ImportError:
            raise ImportError(
                "jinja2 is required for HTML reports. Install with: pip install jinja2"
            )

        template = Template(_HTML_TEMPLATE)
        return template.render(
            overview=overview,
            hotspots=hotspots,
            layers=layers,
        )

    def get_subgraph(
        self,
        name: str | None = None,
        file_path: str | None = None,
    ) -> tuple[list[dict], list[dict]]:
        """Get a subgraph for a specific symbol or file.

        Returns (nodes, edges) limited to the relevant scope.
        """
        if name:
            resolved = self.engine.resolve_node(name)
            if not resolved:
                return [], []
            root = resolved[0]
            # Get the node and its direct connections
            node_ids = {root["id"]}
            edges = self.store.get_edges_from(root["id"])
            incoming = self.store.get_edges_to(root["id"])
            all_edges = edges + incoming

            # Also fetch edges targeting the root by name/qualified_name
            root_node = root
            for alt_key in (root_node["name"], root_node["qualified_name"]):
                if alt_key != root_node["id"]:
                    alt_edges = self.store.get_edges_to(alt_key)
                    all_edges.extend(alt_edges)

            for e in all_edges:
                node_ids.add(e["source"])
                node_ids.add(e["target"])

            # Resolve edge targets that don't match any node ID (unresolved names)
            nodes = self.store.get_nodes_by_ids(node_ids)
            found_ids = {n["id"] for n in nodes}
            for e in list(all_edges):
                for field in ("source", "target"):
                    val = e[field]
                    if val not in found_ids:
                        resolved_nodes = self.engine.resolve_node(val)
                        if resolved_nodes:
                            rn = resolved_nodes[0]
                            if rn["id"] not in found_ids:
                                nodes.append(rn)
                                found_ids.add(rn["id"])
                            e[field] = rn["id"]

            return nodes, all_edges

        if file_path:
            nodes = self.store.get_nodes_by_file(file_path)
            node_ids = {n["id"] for n in nodes}
            edges = self.store.get_all_edges_from_nodes(node_ids)
            return nodes, edges

        # Full graph
        return self.store.get_all_nodes(), self.store.get_all_edges()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dot_id(node_id: str) -> str:
    """Convert a node ID to a valid DOT identifier."""
    return '"' + node_id.replace('"', '\\"') + '"'


def _dot_edge_style(edge_type: str) -> str:
    styles = {
        "CALLS": 'color="#1976D2"',
        "IMPORTS": 'color="#388E3C", style=dashed',
        "CONTAINS": 'color="#757575", style=dotted',
        "EXTENDS": 'color="#D32F2F", arrowhead=empty',
        "IMPLEMENTS": 'color="#7B1FA2", style=dashed, arrowhead=empty',
        "DATAFLOW": 'color="#F57C00", style=bold',
    }
    return styles.get(edge_type, 'color="#9E9E9E"')


def _mermaid_id(node_id: str) -> str:
    """Convert a node ID to a valid Mermaid identifier."""
    return node_id.replace("::", "__").replace("/", "_").replace(".", "_").replace("-", "_")


def _mermaid_shape(node_type: str) -> tuple[str, str]:
    shapes = {
        "file": ("[/", "/]"),
        "class": ("[[", "]]"),
        "function": ("([", "])"),
        "method": ("([", "])"),
        "variable": ("[", "]"),
    }
    return shapes.get(node_type, ("[", "]"))


def _mermaid_arrow(edge_type: str) -> str:
    arrows = {
        "CALLS": "-->",
        "IMPORTS": "-.->",
        "CONTAINS": "---",
        "EXTENDS": "==>",
        "IMPLEMENTS": "-.->",
        "DATAFLOW": "-->",
    }
    return arrows.get(edge_type, "-->")


# ---------------------------------------------------------------------------
# HTML template
# ---------------------------------------------------------------------------

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CodeBrain Report</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
         background: #f5f5f5; color: #333; line-height: 1.6; }
  .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
  h1 { color: #1a237e; margin-bottom: 20px; }
  h2 { color: #283593; margin: 30px 0 15px; border-bottom: 2px solid #c5cae9; padding-bottom: 8px; }
  .card { background: white; border-radius: 8px; padding: 20px; margin: 15px 0;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
  .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; }
  .stat { text-align: center; padding: 15px; background: #e8eaf6; border-radius: 8px; }
  .stat .value { font-size: 2em; font-weight: bold; color: #1a237e; }
  .stat .label { font-size: 0.9em; color: #666; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; }
  th, td { text-align: left; padding: 8px 12px; border-bottom: 1px solid #e0e0e0; }
  th { background: #e8eaf6; font-weight: 600; }
  tr:hover { background: #f5f5f5; }
  .risk-high { color: #d32f2f; font-weight: bold; }
  .risk-medium { color: #f57c00; }
  .risk-low { color: #388e3c; }
  .layer { margin: 10px 0; padding: 10px 15px; background: #e8eaf6; border-radius: 6px;
           border-left: 4px solid #3f51b5; }
  .layer-files { font-size: 0.9em; color: #555; margin-top: 5px; }
  .pkg { display: inline-block; padding: 4px 12px; margin: 4px; background: #c5cae9;
         border-radius: 4px; font-size: 0.9em; }
</style>
</head>
<body>
<div class="container">
  <h1>CodeBrain Report</h1>

  <div class="card">
    <h2>Overview</h2>
    <div class="stats">
      <div class="stat"><div class="value">{{ overview.stats.files }}</div><div class="label">Files</div></div>
      <div class="stat"><div class="value">{{ overview.stats.nodes }}</div><div class="label">Symbols</div></div>
      <div class="stat"><div class="value">{{ overview.stats.edges }}</div><div class="label">Edges</div></div>
    </div>
    <h3 style="margin-top:20px;">Packages</h3>
    <div>
    {% for name, info in overview.packages.items() %}
      <span class="pkg">{{ name }} ({{ info.file_count }} files, {{ info.node_count }} symbols)</span>
    {% endfor %}
    </div>
  </div>

  {% if hotspots %}
  <div class="card">
    <h2>Risk Hotspots</h2>
    <table>
      <tr><th>Score</th><th>Type</th><th>Name</th><th>Dependents</th><th>Files</th><th>Location</th></tr>
      {% for h in hotspots %}
      <tr>
        <td class="{{ 'risk-high' if h.risk_score > 20 else ('risk-medium' if h.risk_score > 5 else 'risk-low') }}">
          {{ "%.1f"|format(h.risk_score) }}
        </td>
        <td>{{ h.type }}</td>
        <td>{{ h.name }}</td>
        <td>{{ h.direct_dependents }}</td>
        <td>{{ h.affected_files }}</td>
        <td>{{ h.file_path }}:{{ h.line_start }}</td>
      </tr>
      {% endfor %}
    </table>
  </div>
  {% endif %}

  {% if layers and layers.layers %}
  <div class="card">
    <h2>Architectural Layers</h2>
    {% for layer in layers.layers %}
    <div class="layer">
      <strong>{{ layer.label }}</strong> — {{ layer.description }}
      <div class="layer-files">{{ layer.files | join(', ') }}</div>
    </div>
    {% endfor %}
  </div>
  {% endif %}

</div>
</body>
</html>
"""
