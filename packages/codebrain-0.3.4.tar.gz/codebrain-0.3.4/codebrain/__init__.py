"""CodeBrain — persistent structural knowledge graph for codebases."""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("codebrain")
except PackageNotFoundError:
    # Source checkout without installation (e.g. running from a worktree).
    # Keep in sync with [project.version] in pyproject.toml.
    __version__ = "0.3.4"
