"""Parser registry — dispatches file parsing to the correct language parser."""

from __future__ import annotations

from pathlib import Path

from codebrain.logging import get_logger
from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedFile

_log = get_logger("parser.registry")

# Module-level singleton
_registry: "ParserRegistry | None" = None


class ParserRegistry:
    """Manages registered language parsers and dispatches parse requests."""

    def __init__(self) -> None:
        self._parsers: list[BaseParser] = []
        self._ext_map: dict[str, BaseParser] = {}
        self._name_map: dict[str, BaseParser] = {}

    def register(self, parser: BaseParser) -> None:
        """Register a parser instance."""
        self._parsers.append(parser)
        for ext in parser.extensions():
            if ext in self._ext_map:
                _log.debug(
                    "Extension %s already registered by %s, overriding with %s",
                    ext,
                    type(self._ext_map[ext]).__name__,
                    type(parser).__name__,
                )
            self._ext_map[ext] = parser

    def register_name(self, name: str, parser: BaseParser) -> None:
        """Register a parser for a specific filename (e.g. 'docker-compose.yml')."""
        self._name_map[name] = parser

    def can_parse(self, path: Path) -> bool:
        """Return True if any registered parser handles this file."""
        return path.suffix in self._ext_map or path.name in self._name_map

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        """Parse a file using the appropriate registered parser.

        Raises ValueError if no parser handles this file.
        """
        # Name-based match takes priority
        parser = self._name_map.get(path.name)
        if parser is None:
            parser = self._ext_map.get(path.suffix)
        if parser is None:
            raise ValueError(f"No parser registered for '{path.name}' (ext '{path.suffix}')")
        return parser.parse(path, repo_root)

    @property
    def supported_extensions(self) -> frozenset[str]:
        """Return all extensions supported by registered parsers."""
        return frozenset(self._ext_map.keys())

    @property
    def supported_names(self) -> frozenset[str]:
        """Return all filenames with name-based parser matching."""
        return frozenset(self._name_map.keys())

    @property
    def parsers(self) -> list[BaseParser]:
        """Return list of registered parsers."""
        return list(self._parsers)

    def load_entrypoints(self) -> None:
        """Discover and load parsers from the ``codebrain.parsers`` entry-points group."""
        try:
            from importlib.metadata import entry_points
        except ImportError:
            return

        eps = entry_points()
        # Python 3.12+ returns a SelectableGroups, older returns dict
        if hasattr(eps, "select"):
            group = eps.select(group="codebrain.parsers")
        elif isinstance(eps, dict):
            group = eps.get("codebrain.parsers", [])
        else:
            group = [ep for ep in eps if ep.group == "codebrain.parsers"]

        for ep in group:
            try:
                parser_cls = ep.load()
                # Skip entry-point parsers whose extensions are all already
                # covered by built-in parsers (avoids regex overriding tree-sitter).
                parser = parser_cls()
                new_exts = parser.extensions() - frozenset(self._ext_map.keys())
                if not new_exts:
                    _log.debug(
                        "Skipping plugin %s (%s) — all extensions already registered",
                        ep.name, type(parser).__name__,
                    )
                    continue
                self.register(parser)
                _log.debug("Loaded plugin parser: %s (%s)", ep.name, type(parser).__name__)
            except Exception as exc:
                _log.warning("Failed to load parser plugin %s: %s", ep.name, exc)


def get_registry() -> ParserRegistry:
    """Return the global parser registry, initializing it on first call."""
    global _registry
    if _registry is None:
        _registry = ParserRegistry()
        _init_builtin_parsers(_registry)
        _registry.load_entrypoints()
    return _registry


def _init_builtin_parsers(registry: ParserRegistry) -> None:
    """Register the built-in Python, TypeScript, and config parsers."""
    from codebrain.parser.python_parser import PythonParser
    from codebrain.parser.config_parser import ConfigParser

    registry.register(PythonParser())

    # Prefer tree-sitter AST parser for TypeScript/JavaScript when available
    try:
        from codebrain.parser.typescript_treesitter import TypeScriptTreeSitterParser, _TS_AVAILABLE
        if _TS_AVAILABLE:
            registry.register(TypeScriptTreeSitterParser())
            _log.debug("Using tree-sitter AST parser for TypeScript/JavaScript")
        else:
            from codebrain.parser.typescript_parser import TypeScriptParser
            registry.register(TypeScriptParser())
            _log.debug("tree-sitter not available, using regex parser for TypeScript/JavaScript")
    except ImportError:
        from codebrain.parser.typescript_parser import TypeScriptParser
        registry.register(TypeScriptParser())

    # Java parser (requires tree-sitter-languages)
    try:
        from codebrain.parser.java_parser import JavaParser, _JAVA_AVAILABLE
        if _JAVA_AVAILABLE:
            registry.register(JavaParser())
            _log.debug("Using tree-sitter AST parser for Java")
    except ImportError:
        _log.debug("Java parser not available (tree-sitter-languages not installed)")

    # Go parser (requires tree-sitter-languages)
    try:
        from codebrain.parser.go_parser import GoParser, _GO_AVAILABLE
        if _GO_AVAILABLE:
            registry.register(GoParser())
            _log.debug("Using tree-sitter AST parser for Go")
    except ImportError:
        _log.debug("Go parser not available (tree-sitter-languages not installed)")

    # Rust parser (requires tree-sitter-languages)
    try:
        from codebrain.parser.rust_parser import RustParser, _RUST_AVAILABLE
        if _RUST_AVAILABLE:
            registry.register(RustParser())
            _log.debug("Using tree-sitter AST parser for Rust")
    except ImportError:
        _log.debug("Rust parser not available (tree-sitter-languages not installed)")

    # C# parser (requires tree-sitter-languages)
    try:
        from codebrain.parser.csharp_parser import CSharpParser, _CSHARP_AVAILABLE
        if _CSHARP_AVAILABLE:
            registry.register(CSharpParser())
            _log.debug("Using tree-sitter AST parser for C#")
    except ImportError:
        _log.debug("C# parser not available (tree-sitter-languages not installed)")

    # Kotlin parser (requires tree-sitter-languages)
    try:
        from codebrain.parser.kotlin_parser import KotlinParser, _KOTLIN_AVAILABLE
        if _KOTLIN_AVAILABLE:
            registry.register(KotlinParser())
            _log.debug("Using tree-sitter AST parser for Kotlin")
    except ImportError:
        _log.debug("Kotlin parser not available (tree-sitter-languages not installed)")

    # Dart parser (regex-based, no external dependency)
    try:
        from codebrain.parser.dart_parser import DartParser
        registry.register(DartParser())
        _log.debug("Dart parser registered")
    except ImportError:
        _log.debug("Dart parser not available")

    # Vue SFC parser (.vue files)
    try:
        from codebrain.parser.vue_parser import VueParser
        registry.register(VueParser())
        _log.debug("Vue parser registered")
    except ImportError:
        _log.debug("Vue parser not available")

    # Legacy language parsers (regex-based, no external dependency)
    try:
        from codebrain.parser.cobol_parser import CobolParser
        registry.register(CobolParser())
        _log.debug("COBOL parser registered")
    except ImportError:
        _log.debug("COBOL parser not available")

    try:
        from codebrain.parser.plsql_parser import PLSQLParser
        registry.register(PLSQLParser())
        _log.debug("PL/SQL parser registered")
    except ImportError:
        _log.debug("PL/SQL parser not available")

    try:
        from codebrain.parser.fortran_parser import FortranParser
        registry.register(FortranParser())
        _log.debug("Fortran parser registered")
    except ImportError:
        _log.debug("Fortran parser not available")

    try:
        from codebrain.parser.mumps_parser import MUMPSParser
        registry.register(MUMPSParser())
        _log.debug("MUMPS parser registered")
    except ImportError:
        _log.debug("MUMPS parser not available")

    # Schema parser: .sql and .prisma files
    from codebrain.parser.schema_parser import SchemaParser
    registry.register(SchemaParser())

    # Config parser: .env by extension, docker-compose by name, Dockerfile, K8s YAML, Terraform
    config = ConfigParser()
    registry.register(config)
    for name in config._COMPOSE_NAMES:
        registry.register_name(name, config)
    # Dockerfile by name match
    registry.register_name("Dockerfile", config)
