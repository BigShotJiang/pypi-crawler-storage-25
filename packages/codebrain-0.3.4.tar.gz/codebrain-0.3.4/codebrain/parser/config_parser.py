"""Config file parsers for .env and docker-compose.yml.

Extracts configuration keys, service definitions, ports, and environment
variables into the knowledge graph so infrastructure is visible.
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash


# ---------------------------------------------------------------------------
# .env parser
# ---------------------------------------------------------------------------

_ENV_LINE = re.compile(r"""^([A-Z_][A-Z0-9_]*)\s*=\s*(.*)$""", re.MULTILINE)


def _parse_env_file(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a .env file — extract key=value pairs as variable nodes."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").replace(".env", "env")

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"
    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["config"],
    ))

    for m in _ENV_LINE.finditer(source):
        key = m.group(1)
        value = m.group(2).strip().strip("'\"")
        line = source.count("\n", 0, m.start()) + 1

        # Mask secrets
        is_secret = any(s in key.lower() for s in ("secret", "password", "key", "token", "api_key"))
        display_value = "***" if is_secret else (value[:50] if value else "")

        node_id = f"{rel_path}::{key}"
        nodes.append(ParsedNode(
            id=node_id,
            name=key,
            qualified_name=key,
            type="variable",
            file_path=rel_path,
            line_start=line,
            line_end=line,
            signature=display_value,
            is_exported=True,
            decorators=["env_var"],
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=node_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# docker-compose.yml parser (simple regex, no PyYAML dependency)
# ---------------------------------------------------------------------------

_SERVICE_DECL = re.compile(r"""^  (\w[\w-]+):\s*$""", re.MULTILINE)
_PORT_MAPPING = re.compile(r"""['"]?(\d+):(\d+)['"]?""")
_IMAGE_LINE = re.compile(r"""^\s+image:\s*['"]?(\S+?)['"]?\s*$""", re.MULTILINE)
_DEPENDS_ON = re.compile(r"""^\s+-\s*(\w[\w-]+)\s*$""", re.MULTILINE)
_ENV_VAR_LINE = re.compile(r"""^\s+-?\s*([A-Z_][A-Z0-9_]*)\s*[:=]""", re.MULTILINE)


def _parse_docker_compose(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a docker-compose.yml — extract services, ports, dependencies."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").replace(".yml", "").replace(".yaml", "")

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"
    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["docker_compose"],
    ))

    # Find services section
    services_match = re.search(r"^services:\s*$", source, re.MULTILINE)
    if not services_match:
        return ParsedFile(path=rel_path, content_hash=hash_val, nodes=nodes,
                          edges=edges, line_count=line_count)

    services_section = source[services_match.end():]

    # Find each service
    service_positions = list(_SERVICE_DECL.finditer(services_section))
    for i, sm in enumerate(service_positions):
        svc_name = sm.group(1)
        svc_line = source.count("\n", 0, services_match.end() + sm.start()) + 1

        # Get service body (until next service or end)
        start = sm.end()
        end = service_positions[i + 1].start() if i + 1 < len(service_positions) else len(services_section)
        svc_body = services_section[start:end]

        # Extract ports
        ports = []
        for pm in _PORT_MAPPING.finditer(svc_body):
            ports.append(f"{pm.group(1)}:{pm.group(2)}")

        # Extract image
        image = ""
        im = _IMAGE_LINE.search(svc_body)
        if im:
            image = im.group(1)

        sig = ""
        if image:
            sig += f"image={image}"
        if ports:
            sig += f" ports={','.join(ports)}"

        node_id = f"{rel_path}::service:{svc_name}"
        nodes.append(ParsedNode(
            id=node_id,
            name=svc_name,
            qualified_name=f"service:{svc_name}",
            type="class",
            file_path=rel_path,
            line_start=svc_line,
            line_end=svc_line,
            signature=sig.strip(),
            is_exported=True,
            decorators=["docker_service"],
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=node_id,
            type="CONTAINS", file_path=rel_path, line=svc_line,
        ))

        # Extract depends_on
        depends_section = re.search(r"depends_on:", svc_body)
        if depends_section:
            deps_text = svc_body[depends_section.end():depends_section.end() + 200]
            for dm in _DEPENDS_ON.finditer(deps_text):
                dep_name = dm.group(1)
                edges.append(ParsedEdge(
                    source=node_id,
                    target=f"{rel_path}::service:{dep_name}",
                    type="DEPENDS",
                    file_path=rel_path,
                    line=svc_line,
                ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# Combined config parser
# ---------------------------------------------------------------------------

    # ---------------------------------------------------------------------------
# Dockerfile parser
# ---------------------------------------------------------------------------

_DOCKERFILE_FROM = re.compile(r"^FROM\s+(\S+)(?:\s+AS\s+(\w+))?", re.MULTILINE | re.IGNORECASE)
_DOCKERFILE_EXPOSE = re.compile(r"^EXPOSE\s+(\d+)", re.MULTILINE)
_DOCKERFILE_ENV = re.compile(r"^ENV\s+(\w+)[=\s]\s*(.*?)$", re.MULTILINE)
_DOCKERFILE_CMD = re.compile(r"^(?:CMD|ENTRYPOINT)\s+(.+)$", re.MULTILINE)


def _parse_dockerfile(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a Dockerfile — extract stages, base images, ports, env vars."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".")

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"

    # Collect summary info
    ports: list[str] = []
    for m in _DOCKERFILE_EXPOSE.finditer(source):
        ports.append(m.group(1))

    entrypoint = ""
    for m in _DOCKERFILE_CMD.finditer(source):
        entrypoint = m.group(1).strip()

    summary_parts = ["dockerfile"]
    if ports:
        summary_parts.append(f"ports:{','.join(ports)}")
    if entrypoint:
        summary_parts.append(f"entry:{entrypoint[:60]}")

    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["dockerfile"],
        summary="|".join(summary_parts),
    ))

    # Stage nodes (one per FROM)
    for m in _DOCKERFILE_FROM.finditer(source):
        image = m.group(1)
        stage = m.group(2) or "default"
        line = source.count("\n", 0, m.start()) + 1
        stage_id = f"{rel_path}::stage:{stage}"
        nodes.append(ParsedNode(
            id=stage_id,
            name=stage,
            qualified_name=f"docker::{stage}",
            type="function",
            file_path=rel_path,
            line_start=line,
            line_end=line,
            signature=f"FROM {image}",
            is_exported=True,
            decorators=["dockerfile"],
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=stage_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    # ENV variable nodes
    for m in _DOCKERFILE_ENV.finditer(source):
        key = m.group(1)
        value = m.group(2).strip().strip("'\"")
        line = source.count("\n", 0, m.start()) + 1

        is_secret = any(s in key.lower() for s in ("secret", "password", "key", "token"))
        display = "***" if is_secret else (value[:50] if value else "")

        env_id = f"{rel_path}::env:{key}"
        nodes.append(ParsedNode(
            id=env_id,
            name=key,
            qualified_name=key,
            type="variable",
            file_path=rel_path,
            line_start=line,
            line_end=line,
            signature=display,
            is_exported=True,
            decorators=["env_var"],
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=env_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# Kubernetes YAML parser (content-based detection)
# ---------------------------------------------------------------------------

def _is_k8s_yaml(source: str) -> bool:
    """Quick check: has both apiVersion: and kind: markers."""
    return "apiVersion:" in source and "kind:" in source


def _parse_k8s_yaml(path: Path, repo_root: Path) -> ParsedFile:
    """Parse Kubernetes manifests — extract resources, images, ports."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").rsplit(".", 1)[0]

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"
    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["k8s_manifest"],
    ))

    # Split multi-document YAML
    docs = re.split(r"^---\s*$", source, flags=re.MULTILINE)

    # Try PyYAML first, fall back to regex
    use_yaml = False
    try:
        import yaml
        use_yaml = True
    except ImportError:
        pass

    for doc_idx, doc in enumerate(docs):
        doc = doc.strip()
        if not doc or "apiVersion:" not in doc or "kind:" not in doc:
            continue

        kind = ""
        name = ""
        images: list[str] = []
        k8s_ports: list[str] = []
        replicas = ""

        if use_yaml:
            try:
                data = yaml.safe_load(doc)
                if not isinstance(data, dict):
                    continue
                kind = data.get("kind", "")
                meta = data.get("metadata", {}) or {}
                name = meta.get("name", "")
                spec = data.get("spec", {}) or {}
                replicas = str(spec.get("replicas", "")) if "replicas" in spec else ""
                # Extract containers
                tmpl = spec.get("template", {}) or {}
                tmpl_spec = tmpl.get("spec", {}) or {}
                containers = tmpl_spec.get("containers", []) or []
                # Direct containers (e.g., Pod)
                if not containers:
                    containers = spec.get("containers", []) or []
                for c in containers:
                    if isinstance(c, dict):
                        img = c.get("image", "")
                        if img:
                            images.append(img)
                        for p in c.get("ports", []) or []:
                            if isinstance(p, dict) and "containerPort" in p:
                                k8s_ports.append(str(p["containerPort"]))
                # Service ports
                svc_ports = spec.get("ports", []) or []
                for p in svc_ports:
                    if isinstance(p, dict) and "port" in p:
                        k8s_ports.append(str(p["port"]))
            except Exception:
                use_yaml = False  # fall back for remaining docs

        if not kind:
            # Regex fallback
            km = re.search(r"^kind:\s*(\S+)", doc, re.MULTILINE)
            nm = re.search(r"^\s+name:\s*(\S+)", doc, re.MULTILINE)
            im = re.findall(r"image:\s*(\S+)", doc)
            pm = re.findall(r"containerPort:\s*(\d+)", doc)
            rm = re.search(r"replicas:\s*(\d+)", doc)
            kind = km.group(1) if km else "Unknown"
            name = nm.group(1) if nm else f"resource_{doc_idx}"
            images = im
            k8s_ports = pm
            replicas = rm.group(1) if rm else ""

        line = source.count("\n", 0, source.find(doc[:30])) + 1 if doc[:30] in source else 1

        summary_parts = [f"k8s:{kind}"]
        if images:
            summary_parts.append(f"images:{','.join(images)}")
        if k8s_ports:
            summary_parts.append(f"ports:{','.join(k8s_ports)}")
        if replicas:
            summary_parts.append(f"replicas:{replicas}")

        res_id = f"{rel_path}::k8s:{kind.lower()}:{name}"
        nodes.append(ParsedNode(
            id=res_id,
            name=name,
            qualified_name=f"k8s::{kind}::{name}",
            type="class",
            file_path=rel_path,
            line_start=line,
            line_end=line,
            is_exported=True,
            decorators=["k8s_resource"],
            summary="|".join(summary_parts),
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=res_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# Terraform .tf parser (regex-based HCL)
# ---------------------------------------------------------------------------

_TF_RESOURCE = re.compile(r'^resource\s+"([^"]+)"\s+"([^"]+)"', re.MULTILINE)
_TF_DATA = re.compile(r'^data\s+"([^"]+)"\s+"([^"]+)"', re.MULTILINE)
_TF_VARIABLE = re.compile(r'^variable\s+"([^"]+)"', re.MULTILINE)


def _parse_terraform(path: Path, repo_root: Path) -> ParsedFile:
    """Parse Terraform .tf files — extract resources, data sources, variables."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").rsplit(".", 1)[0]

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"
    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["terraform"],
    ))

    # Resources
    for m in _TF_RESOURCE.finditer(source):
        res_type = m.group(1)
        res_name = m.group(2)
        line = source.count("\n", 0, m.start()) + 1
        res_id = f"{rel_path}::resource:{res_type}.{res_name}"
        nodes.append(ParsedNode(
            id=res_id,
            name=f"{res_type}.{res_name}",
            qualified_name=f"terraform::{res_type}.{res_name}",
            type="class",
            file_path=rel_path,
            line_start=line,
            line_end=line,
            signature=res_type,
            is_exported=True,
            decorators=["terraform_resource"],
            summary=f"resource|type:{res_type}",
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=res_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    # Data sources
    for m in _TF_DATA.finditer(source):
        data_type = m.group(1)
        data_name = m.group(2)
        line = source.count("\n", 0, m.start()) + 1
        data_id = f"{rel_path}::data:{data_type}.{data_name}"
        nodes.append(ParsedNode(
            id=data_id,
            name=f"{data_type}.{data_name}",
            qualified_name=f"terraform::data.{data_type}.{data_name}",
            type="class",
            file_path=rel_path,
            line_start=line,
            line_end=line,
            signature=data_type,
            is_exported=True,
            decorators=["terraform_data"],
            summary=f"data|type:{data_type}",
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=data_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    # Variables
    for m in _TF_VARIABLE.finditer(source):
        var_name = m.group(1)
        line = source.count("\n", 0, m.start()) + 1
        var_id = f"{rel_path}::var:{var_name}"
        nodes.append(ParsedNode(
            id=var_id,
            name=var_name,
            qualified_name=f"terraform::var.{var_name}",
            type="variable",
            file_path=rel_path,
            line_start=line,
            line_end=line,
            is_exported=True,
            decorators=["terraform_variable"],
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=var_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# Empty result helper (for non-infra YAML)
# ---------------------------------------------------------------------------

def _empty_result(path: Path, repo_root: Path) -> ParsedFile:
    """Return an empty ParsedFile for non-infra files."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    return ParsedFile(
        path=rel_path,
        content_hash=content_hash(raw),
        nodes=[],
        edges=[],
        line_count=raw.count(b"\n") + 1,
    )


# ---------------------------------------------------------------------------
# Combined config parser
# ---------------------------------------------------------------------------

class ConfigParser(BaseParser):
    """Parser for configuration files (.env, docker-compose, Dockerfile, K8s, Terraform)."""

    _EXTENSIONS = frozenset({".env", ".tf", ".yaml", ".yml"})
    _COMPOSE_NAMES = {"docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml"}
    _DOCKERFILE_NAMES = {"Dockerfile"}

    def extensions(self) -> frozenset[str]:
        return self._EXTENSIONS

    def can_parse(self, path: Path) -> bool:
        """Check if this parser handles the file (extension or name match)."""
        return (
            path.suffix in self._EXTENSIONS
            or path.name in self._COMPOSE_NAMES
            or path.name in self._DOCKERFILE_NAMES
            or path.name.startswith("Dockerfile.")
        )

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        # Docker Compose
        if path.name in self._COMPOSE_NAMES:
            return _parse_docker_compose(path, repo_root)

        # Dockerfile
        if path.name in self._DOCKERFILE_NAMES or path.name.startswith("Dockerfile."):
            return _parse_dockerfile(path, repo_root)

        # Terraform
        if path.suffix == ".tf":
            return _parse_terraform(path, repo_root)

        # .env files
        if path.suffix == ".env" or path.name == ".env":
            return _parse_env_file(path, repo_root)

        # YAML files: K8s if content matches, otherwise empty
        if path.suffix in (".yaml", ".yml"):
            try:
                raw = path.read_bytes()
                source = raw.decode("utf-8", errors="replace")
                if _is_k8s_yaml(source):
                    return _parse_k8s_yaml(path, repo_root)
            except Exception:
                pass
            return _empty_result(path, repo_root)

        return _empty_result(path, repo_root)
