"""Schema file parsers for .sql and .prisma files.

Extracts tables, columns, foreign keys, models, fields, and relations
into the knowledge graph so database structure is visible during rewrites.
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash


# ---------------------------------------------------------------------------
# SQL parser — ANSI DDL (CREATE TABLE only)
# ---------------------------------------------------------------------------

# Strip comments
_SQL_LINE_COMMENT = re.compile(r"--[^\n]*")
_SQL_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)

# CREATE TABLE
_CREATE_TABLE = re.compile(
    r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"
    r"""["'`\[]?(\w+)["'`\]]?\s*\(""",
    re.IGNORECASE,
)

# Foreign key constraint
_FK_CONSTRAINT = re.compile(
    r"FOREIGN\s+KEY\s*\(\s*"
    r"""["'`]?(\w+)["'`]?\s*\)\s*REFERENCES\s+["'`\[]?(\w+)["'`\]]?\s*\(\s*["'`]?(\w+)["'`]?\s*\)""",
    re.IGNORECASE,
)

# CREATE INDEX (just detect, don't create separate node)
_CREATE_INDEX = re.compile(
    r"CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?"
    r"""["'`]?(\w+)["'`]?\s+ON\s+["'`\[]?(\w+)["'`\]]?""",
    re.IGNORECASE,
)

# Column constraints keywords
_CONSTRAINT_KEYWORDS = {"NOT NULL", "PRIMARY KEY", "UNIQUE", "DEFAULT", "CHECK", "AUTOINCREMENT", "AUTO_INCREMENT"}


def _extract_balanced_parens(text: str, start: int) -> str:
    """Extract content between balanced parentheses starting at `start`."""
    depth = 0
    i = start
    while i < len(text):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return text[start + 1:i]
        i += 1
    return text[start + 1:]


def _parse_columns(body: str) -> list[tuple[str, str, list[str]]]:
    """Parse column definitions from CREATE TABLE body.

    Returns list of (name, type, constraints).
    Skips CONSTRAINT, PRIMARY KEY, FOREIGN KEY, CHECK, INDEX lines.
    """
    columns: list[tuple[str, str, list[str]]] = []
    skip_prefixes = ("CONSTRAINT", "PRIMARY", "FOREIGN", "CHECK", "INDEX", "UNIQUE", "KEY")

    # Split on commas at top level (not inside parens)
    parts: list[str] = []
    depth = 0
    current: list[str] = []
    for ch in body:
        if ch == "(":
            depth += 1
            current.append(ch)
        elif ch == ")":
            depth -= 1
            current.append(ch)
        elif ch == "," and depth == 0:
            parts.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        parts.append("".join(current).strip())

    for part in parts:
        part = part.strip()
        if not part:
            continue
        upper = part.upper().lstrip()
        if any(upper.startswith(p) for p in skip_prefixes):
            continue

        # First word = column name (strip quotes)
        tokens = part.split()
        if len(tokens) < 2:
            continue
        col_name = tokens[0].strip("\"'`[]")
        # Skip if looks like a keyword
        if col_name.upper() in ("CONSTRAINT", "PRIMARY", "FOREIGN", "CHECK", "INDEX", "UNIQUE", "KEY"):
            continue
        col_type = tokens[1].strip("\"'`[]")
        # If type has parens like VARCHAR(255), include it
        if len(tokens) > 2 and tokens[1].endswith("(") or "(" in col_type:
            # Rejoin type with size
            rest = part[len(tokens[0]):].strip()
            paren_end = rest.find(")")
            if paren_end >= 0:
                col_type = rest[:paren_end + 1].strip()

        constraints: list[str] = []
        upper_part = part.upper()
        for kw in _CONSTRAINT_KEYWORDS:
            if kw in upper_part:
                constraints.append(kw)

        columns.append((col_name, col_type, constraints))

    return columns


def _parse_sql(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a .sql file — extract CREATE TABLE statements."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").rsplit(".", 1)[0]

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"
    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["sql_schema"],
    ))

    # Strip comments
    cleaned = _SQL_LINE_COMMENT.sub("", source)
    cleaned = _SQL_BLOCK_COMMENT.sub("", cleaned)

    # Track indexes per table for summary
    table_indexes: dict[str, list[str]] = {}
    for m in _CREATE_INDEX.finditer(cleaned):
        idx_name = m.group(1)
        tbl_name = m.group(2)
        table_indexes.setdefault(tbl_name, []).append(idx_name)

    # Find CREATE TABLE statements
    for m in _CREATE_TABLE.finditer(cleaned):
        table_name = m.group(1)
        line = source.count("\n", 0, m.start()) + 1

        # Extract body between parens
        body = _extract_balanced_parens(cleaned, m.end() - 1)

        columns = _parse_columns(body)
        fk_edges: list[tuple[str, str, str]] = []

        # Find FK constraints in body
        for fk in _FK_CONSTRAINT.finditer(body):
            fk_col = fk.group(1)
            ref_table = fk.group(2)
            ref_col = fk.group(3)
            fk_edges.append((fk_col, ref_table, ref_col))

        # Also check inline REFERENCES in column defs
        for col_name, col_type, constraints in columns:
            # Inline FK: column_name TYPE REFERENCES other_table(col)
            col_text_idx = body.lower().find(col_name.lower())
            if col_text_idx >= 0:
                after = body[col_text_idx:col_text_idx + 200]
                ref_m = re.search(
                    r"REFERENCES\s+[\"'`\[]?(\w+)[\"'`\]]?\s*\(\s*[\"'`]?(\w+)[\"'`]?\s*\)",
                    after, re.IGNORECASE,
                )
                if ref_m:
                    fk_edges.append((col_name, ref_m.group(1), ref_m.group(2)))

        # Build summary
        pk_cols = [c[0] for c in columns if "PRIMARY KEY" in c[2]]
        fk_strs = [f"{fk[0]}->{fk[1]}.{fk[2]}" for fk in fk_edges]
        indexes = table_indexes.get(table_name, [])
        summary_parts = [f"table|cols:{len(columns)}"]
        if pk_cols:
            summary_parts.append(f"pk:{','.join(pk_cols)}")
        if fk_strs:
            summary_parts.append(f"fks:{','.join(fk_strs)}")
        if indexes:
            summary_parts.append(f"idx:{','.join(indexes)}")

        table_node_id = f"{rel_path}::table:{table_name}"
        nodes.append(ParsedNode(
            id=table_node_id,
            name=table_name,
            qualified_name=f"schema::{table_name}",
            type="class",
            file_path=rel_path,
            line_start=line,
            line_end=line + body.count("\n") + 1,
            is_exported=True,
            decorators=["sql_table"],
            summary="|".join(summary_parts),
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=table_node_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

        # Column nodes
        for col_name, col_type, constraints in columns:
            constraint_str = " ".join(constraints)
            sig = f"{col_type} {constraint_str}".strip()
            col_node_id = f"{rel_path}::table:{table_name}.{col_name}"
            nodes.append(ParsedNode(
                id=col_node_id,
                name=col_name,
                qualified_name=f"schema::{table_name}.{col_name}",
                type="variable",
                file_path=rel_path,
                line_start=line,
                line_end=line,
                signature=sig,
                is_exported=True,
                decorators=["sql_column"],
            ))
            edges.append(ParsedEdge(
                source=table_node_id, target=col_node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))

        # FK REFERENCES edges (source=FK column, target=referenced table)
        for fk_col, ref_table, ref_col in fk_edges:
            col_node_id = f"{rel_path}::table:{table_name}.{fk_col}"
            # Target could be in same file or different — use qualified name
            ref_table_id = f"{rel_path}::table:{ref_table}"
            edges.append(ParsedEdge(
                source=col_node_id,
                target=ref_table_id,
                type="REFERENCES",
                file_path=rel_path,
                line=line,
            ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# Prisma parser
# ---------------------------------------------------------------------------

_PRISMA_LINE_COMMENT = re.compile(r"//[^\n]*")
_PRISMA_MODEL = re.compile(r"^\s*model\s+(\w+)\s*\{", re.MULTILINE)
_PRISMA_ENUM = re.compile(r"^\s*enum\s+(\w+)\s*\{", re.MULTILINE)
_PRISMA_FIELD = re.compile(r"^[^\S\n]+(\w+)[^\S\n]+(\w+(?:\[\])?)[^\S\n]*(.*?)$", re.MULTILINE)
_PRISMA_RELATION = re.compile(
    r"@relation\(.*?fields:\s*\[(\w+)\].*?references:\s*\[(\w+)\]",
    re.DOTALL,
)
_PRISMA_MAP = re.compile(r'@@map\(\s*["\'](\w+)["\']\s*\)')


def _extract_block(source: str, start: int) -> str:
    """Extract body of a { ... } block starting at position of '{'."""
    brace_pos = source.find("{", start)
    if brace_pos < 0:
        return ""
    depth = 0
    i = brace_pos
    while i < len(source):
        if source[i] == "{":
            depth += 1
        elif source[i] == "}":
            depth -= 1
            if depth == 0:
                return source[brace_pos + 1:i]
        i += 1
    return source[brace_pos + 1:]


def _parse_prisma(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a .prisma file — extract models, fields, relations, enums."""
    rel_path = path.relative_to(repo_root).as_posix()
    raw = path.read_bytes()
    hash_val = content_hash(raw)

    try:
        source = raw.decode("utf-8")
    except UnicodeDecodeError:
        source = raw.decode("utf-8", errors="replace")

    line_count = source.count("\n") + 1
    module_name = rel_path.replace("/", ".").rsplit(".", 1)[0]

    nodes: list[ParsedNode] = []
    edges: list[ParsedEdge] = []

    file_node_id = f"{rel_path}::{module_name}"
    nodes.append(ParsedNode(
        id=file_node_id,
        name=path.name,
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        is_exported=True,
        decorators=["prisma_schema"],
    ))

    # Strip comments for parsing
    cleaned = _PRISMA_LINE_COMMENT.sub("", source)

    # Parse models
    for m in _PRISMA_MODEL.finditer(cleaned):
        model_name = m.group(1)
        line = source.count("\n", 0, m.start()) + 1
        body = _extract_block(cleaned, m.start())

        # Check for @@map
        table_name = model_name
        map_m = _PRISMA_MAP.search(body)
        if map_m:
            table_name = map_m.group(1)

        # Parse fields
        fields: list[tuple[str, str, str]] = []  # (name, type, modifiers)
        fk_edges: list[tuple[str, str]] = []  # (local_field, referenced_model)

        for fm in _PRISMA_FIELD.finditer(body):
            fname = fm.group(1)
            ftype = fm.group(2)
            fmods = fm.group(3).strip()

            # Skip @@-level directives
            if fname.startswith("@@"):
                continue

            fields.append((fname, ftype, fmods))

            # Check for explicit @relation
            rel_m = _PRISMA_RELATION.search(fmods)
            if rel_m:
                local_field = rel_m.group(1)
                fk_edges.append((local_field, ftype.rstrip("[]")))

        # Build summary
        fk_strs = [f"{fk[0]}->{fk[1]}" for fk in fk_edges]
        summary_parts = [f"model|fields:{len(fields)}"]
        if table_name != model_name:
            summary_parts.append(f"table:{table_name}")
        if fk_strs:
            summary_parts.append(f"fks:{','.join(fk_strs)}")

        model_node_id = f"{rel_path}::model:{model_name}"
        nodes.append(ParsedNode(
            id=model_node_id,
            name=model_name,
            qualified_name=f"schema::{model_name}",
            type="class",
            file_path=rel_path,
            line_start=line,
            line_end=line + body.count("\n") + 1,
            is_exported=True,
            decorators=["prisma_model"],
            summary="|".join(summary_parts),
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=model_node_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

        # Field nodes
        for fname, ftype, fmods in fields:
            sig = f"{ftype} {fmods}".strip()
            field_node_id = f"{rel_path}::model:{model_name}.{fname}"
            nodes.append(ParsedNode(
                id=field_node_id,
                name=fname,
                qualified_name=f"schema::{model_name}.{fname}",
                type="variable",
                file_path=rel_path,
                line_start=line,
                line_end=line,
                signature=sig,
                is_exported=True,
                decorators=["prisma_field"],
            ))
            edges.append(ParsedEdge(
                source=model_node_id, target=field_node_id,
                type="CONTAINS", file_path=rel_path, line=line,
            ))

        # REFERENCES edges from FK fields
        for local_field, ref_model in fk_edges:
            local_id = f"{rel_path}::model:{model_name}.{local_field}"
            ref_id = f"{rel_path}::model:{ref_model}"
            edges.append(ParsedEdge(
                source=local_id,
                target=ref_id,
                type="REFERENCES",
                file_path=rel_path,
                line=line,
            ))

    # Parse enums
    for m in _PRISMA_ENUM.finditer(cleaned):
        enum_name = m.group(1)
        line = source.count("\n", 0, m.start()) + 1
        body = _extract_block(cleaned, m.start())

        members: list[str] = []
        for eline in body.strip().split("\n"):
            member = eline.strip()
            if member and not member.startswith("@@") and not member.startswith("//"):
                members.append(member)

        enum_node_id = f"{rel_path}::enum:{enum_name}"
        nodes.append(ParsedNode(
            id=enum_node_id,
            name=enum_name,
            qualified_name=f"schema::{enum_name}",
            type="class",
            file_path=rel_path,
            line_start=line,
            line_end=line + body.count("\n") + 1,
            is_exported=True,
            decorators=["prisma_enum"],
            summary=f"enum|members:{','.join(members)}",
        ))
        edges.append(ParsedEdge(
            source=file_node_id, target=enum_node_id,
            type="CONTAINS", file_path=rel_path, line=line,
        ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


# ---------------------------------------------------------------------------
# Combined schema parser
# ---------------------------------------------------------------------------


class SchemaParser(BaseParser):
    """Parser for database schema files (.sql, .prisma)."""

    _EXTENSIONS = frozenset({".sql", ".prisma"})

    def extensions(self) -> frozenset[str]:
        return self._EXTENSIONS

    def can_parse(self, path: Path) -> bool:
        return path.suffix in self._EXTENSIONS

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        if path.suffix == ".prisma":
            return _parse_prisma(path, repo_root)
        return _parse_sql(path, repo_root)
