"""COBOL parser for legacy codebase analysis.

Extracts programs, sections, paragraphs, variables, and relationships
(CALLS via PERFORM, IMPORTS via COPY) from COBOL source files.

Regex-based. Handles both fixed-format (columns 1-72) and free-format
(>>SOURCE FORMAT IS FREE). Expected accuracy ~80% on real-world code.

Known limitations:
- COPY REPLACING: parsed as IMPORTS but substitutions not applied
- Nested PERFORM THRU: only captures start paragraph
- Embedded SQL (EXEC SQL): flagged as metadata, not parsed
- Multi-line continuations may miss some statements
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash


# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

_PROGRAM_ID_RE = re.compile(
    r"PROGRAM-ID\.\s+(\S+)", re.IGNORECASE
)

_SECTION_RE = re.compile(
    r"^(\s*)(\w[\w-]+)\s+SECTION\s*\.", re.IGNORECASE | re.MULTILINE
)

# Paragraph: a label at the start of a line followed by a period
# Must be in PROCEDURE DIVISION. We detect by position after finding PROCEDURE DIVISION.
_PARAGRAPH_RE = re.compile(
    r"^(\w[\w-]+)\s*\.\s*$", re.MULTILINE
)

_PERFORM_RE = re.compile(
    r"PERFORM\s+([\w-]+)(?:\s+THRU\s+([\w-]+))?", re.IGNORECASE
)

_CALL_RE = re.compile(
    r"CALL\s+['\"](\w+)['\"]", re.IGNORECASE
)

_COPY_RE = re.compile(
    r"COPY\s+([\w-]+)", re.IGNORECASE
)

# WORKING-STORAGE 01-level items
_WS_LEVEL_RE = re.compile(
    r"^\s*(01|1)\s+([\w-]+)", re.IGNORECASE | re.MULTILINE
)

# FILE SECTION FD entries
_FD_RE = re.compile(
    r"^\s*FD\s+([\w-]+)", re.IGNORECASE | re.MULTILINE
)

# Division markers
_PROCEDURE_DIV_RE = re.compile(
    r"PROCEDURE\s+DIVISION", re.IGNORECASE
)
_DATA_DIV_RE = re.compile(
    r"DATA\s+DIVISION", re.IGNORECASE
)
_WORKING_STORAGE_RE = re.compile(
    r"WORKING-STORAGE\s+SECTION", re.IGNORECASE
)
_FILE_SECTION_RE = re.compile(
    r"FILE\s+SECTION", re.IGNORECASE
)

# EVALUATE (complexity indicator)
_EVALUATE_RE = re.compile(r"\bEVALUATE\b", re.IGNORECASE)


class CobolParser(BaseParser):
    """Parser for COBOL source files (.cob, .cbl, .cpy)."""

    def extensions(self) -> frozenset[str]:
        return frozenset({".cob", ".cbl", ".cpy"})

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = str(path.relative_to(repo_root)).replace("\\", "/")
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ParsedFile(path=rel_path, content_hash="", line_count=0)

        chash = content_hash(raw.encode("utf-8"))
        lines = raw.splitlines()
        line_count = len(lines)

        # Detect format
        is_free = self._is_free_format(raw)
        if not is_free:
            code = self._strip_fixed_format(lines)
        else:
            code = "\n".join(lines)

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []

        module_name = Path(rel_path).stem
        file_id = f"{rel_path}::{module_name}"

        # File node
        nodes.append(ParsedNode(
            id=file_id, name=module_name, qualified_name=module_name,
            type="file", file_path=rel_path,
            line_start=1, line_end=line_count,
            is_exported=True,
        ))

        # PROGRAM-ID
        m = _PROGRAM_ID_RE.search(code)
        if m:
            prog_name = m.group(1).rstrip(".")
            nodes[0].name = prog_name
            nodes[0].qualified_name = prog_name
            nodes[0].id = f"{rel_path}::{prog_name}"
            file_id = nodes[0].id

        # Find PROCEDURE DIVISION boundary
        proc_match = _PROCEDURE_DIV_RE.search(code)
        proc_start = proc_match.start() if proc_match else len(code)

        # DATA DIVISION — WORKING-STORAGE variables
        ws_match = _WORKING_STORAGE_RE.search(code)
        if ws_match:
            ws_section = code[ws_match.end():proc_start]
            for vm in _WS_LEVEL_RE.finditer(ws_section):
                var_name = vm.group(2)
                if var_name.upper() in ("FILLER", "PIC", "PICTURE"):
                    continue
                var_id = f"{rel_path}::{var_name}"
                nodes.append(ParsedNode(
                    id=var_id, name=var_name, qualified_name=var_name,
                    type="variable", file_path=rel_path,
                    line_start=1, line_end=1,
                    is_exported=True,
                ))
                edges.append(ParsedEdge(
                    source=file_id, target=var_id,
                    type="CONTAINS", file_path=rel_path, line=1,
                ))

        # FILE SECTION — FD entries
        fs_match = _FILE_SECTION_RE.search(code)
        if fs_match:
            fs_end = ws_match.start() if ws_match and ws_match.start() > fs_match.end() else proc_start
            fs_section = code[fs_match.end():fs_end]
            for fm in _FD_RE.finditer(fs_section):
                fd_name = fm.group(1)
                fd_id = f"{rel_path}::{fd_name}"
                nodes.append(ParsedNode(
                    id=fd_id, name=fd_name, qualified_name=fd_name,
                    type="variable", file_path=rel_path,
                    line_start=1, line_end=1,
                    summary="file-descriptor",
                ))
                edges.append(ParsedEdge(
                    source=file_id, target=fd_id,
                    type="CONTAINS", file_path=rel_path, line=1,
                ))

        # PROCEDURE DIVISION — sections and paragraphs
        if proc_match:
            proc_code = code[proc_start:]

            # Sections
            section_names: set[str] = set()
            for sm in _SECTION_RE.finditer(proc_code):
                sec_name = sm.group(2)
                section_names.add(sec_name.upper())
                sec_id = f"{rel_path}::{sec_name}"
                nodes.append(ParsedNode(
                    id=sec_id, name=sec_name, qualified_name=sec_name,
                    type="class", file_path=rel_path,  # section as container
                    line_start=1, line_end=line_count,
                    is_exported=True, summary="section",
                ))
                edges.append(ParsedEdge(
                    source=file_id, target=sec_id,
                    type="CONTAINS", file_path=rel_path, line=1,
                ))

            # Paragraphs (labels that aren't sections or division headers)
            skip_words = {
                "IDENTIFICATION", "ENVIRONMENT", "DATA", "PROCEDURE",
                "WORKING-STORAGE", "FILE", "LINKAGE", "SCREEN",
                "INPUT-OUTPUT", "CONFIGURATION",
            }
            for pm in _PARAGRAPH_RE.finditer(proc_code):
                para_name = pm.group(1)
                if para_name.upper() in skip_words:
                    continue
                if para_name.upper() in section_names:
                    continue
                if para_name.upper().endswith("SECTION"):
                    continue
                para_id = f"{rel_path}::{para_name}"
                nodes.append(ParsedNode(
                    id=para_id, name=para_name, qualified_name=para_name,
                    type="function", file_path=rel_path,
                    line_start=1, line_end=1,
                    is_exported=True,
                ))
                edges.append(ParsedEdge(
                    source=file_id, target=para_id,
                    type="CONTAINS", file_path=rel_path, line=1,
                ))

            # PERFORM calls
            for pm in _PERFORM_RE.finditer(proc_code):
                target_name = pm.group(1)
                if target_name.upper() in ("UNTIL", "VARYING", "WITH", "TEST", "TIMES"):
                    continue
                edges.append(ParsedEdge(
                    source=file_id, target=f"{rel_path}::{target_name}",
                    type="CALLS", file_path=rel_path, line=1,
                ))
                # THRU target
                if pm.group(2):
                    thru_name = pm.group(2)
                    edges.append(ParsedEdge(
                        source=file_id, target=f"{rel_path}::{thru_name}",
                        type="CALLS", file_path=rel_path, line=1,
                    ))

            # EVALUATE (metadata)
            eval_count = len(_EVALUATE_RE.findall(proc_code))
            if eval_count > 0 and nodes:
                nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + f"evaluate_count={eval_count}"

        # CALL 'PROGRAM' — external calls (search entire code)
        for cm in _CALL_RE.finditer(code):
            called_prog = cm.group(1)
            edges.append(ParsedEdge(
                source=file_id, target=called_prog,
                type="CALLS", file_path=rel_path, line=1,
            ))

        # COPY — imports (search entire code)
        for cm in _COPY_RE.finditer(code):
            copybook = cm.group(1)
            edges.append(ParsedEdge(
                source=file_id, target=copybook,
                type="IMPORTS", file_path=rel_path, line=1,
            ))

        return ParsedFile(
            path=rel_path, content_hash=chash,
            nodes=nodes, edges=edges, line_count=line_count,
        )

    @staticmethod
    def _is_free_format(content: str) -> bool:
        """Check if the source uses free-format COBOL."""
        return ">>SOURCE FORMAT IS FREE" in content.upper()

    @staticmethod
    def _strip_fixed_format(lines: list[str]) -> str:
        """Strip fixed-format columns: 1-6 sequence, 7 indicator, 73-80 comment.

        Column 7: * or / = comment, - = continuation, D = debug line.
        Code is in columns 8-72 (0-indexed: [7:72]).
        """
        result: list[str] = []
        for line in lines:
            if len(line) < 7:
                continue
            indicator = line[6] if len(line) > 6 else " "
            if indicator in ("*", "/"):  # comment line
                continue
            if indicator == "D" or indicator == "d":  # debug line — skip
                continue
            if indicator == "-":  # continuation
                # Append to previous line (strip leading spaces)
                cont = line[11:72].rstrip() if len(line) > 11 else ""
                if result and cont:
                    result[-1] = result[-1] + cont
                continue
            code = line[7:72].rstrip() if len(line) > 7 else ""
            if code:
                result.append(code)
        return "\n".join(result)
