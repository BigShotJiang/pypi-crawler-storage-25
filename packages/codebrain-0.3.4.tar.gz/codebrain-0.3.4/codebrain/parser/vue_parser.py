"""Vue Single File Component (.vue) parser.

Implements BaseParser for .vue files by splitting them into
<template>, <script>, and <style> blocks, parsing each appropriately.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from codebrain.logging import get_logger
from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode

_log = get_logger("vue_parser")

# ---------------------------------------------------------------------------
# Template parsing regexes
# ---------------------------------------------------------------------------

# SFC block extraction
_TEMPLATE_RE = re.compile(
    r"<template(?:\s[^>]*)?>(.*?)</template>", re.DOTALL
)
_SCRIPT_RE = re.compile(
    r"<script(?P<attrs>[^>]*)>(?P<body>.*?)</script>", re.DOTALL
)

# <script setup> detection
_SCRIPT_SETUP_RE = re.compile(r"\bsetup\b")
# <script lang="ts"> detection
_SCRIPT_LANG_TS_RE = re.compile(r"""lang=["']ts["']""")

# Template: component references (PascalCase or kebab-case)
_COMPONENT_REF_RE = re.compile(
    r"<([A-Z][a-zA-Z0-9]+)[\s/>]"
)
# Also kebab-case that maps to PascalCase components
_KEBAB_COMPONENT_RE = re.compile(
    r"<([a-z]+-[a-z0-9-]+)[\s/>]"
)

# Prop bindings: :propName="expr" or v-bind:propName="expr"
_PROP_BINDING_RE = re.compile(
    r"""(?::|\bv-bind:)([a-zA-Z_][\w-]*)=["']([^"']*)["']"""
)
# Static props: propName="value"
_STATIC_PROP_RE = re.compile(
    r"""\b([a-zA-Z_][\w-]*)=["']([^"']*)["']"""
)

# Event handlers: @eventName="handler" or v-on:eventName="handler"
_EVENT_HANDLER_RE = re.compile(
    r"""(?:@|\bv-on:)([a-zA-Z_][\w-]*)=["']([^"']*)["']"""
)

# Directives: v-for, v-if, v-show, etc.
_DIRECTIVE_RE = re.compile(
    r"""\b(v-(?:for|if|else-if|else|show|model|slot|html|text))\b"""
)

# Slot usage: <template #slotName> or <template v-slot:slotName>
_SLOT_RE = re.compile(
    r"""<template\s+(?:#|v-slot:)(\w+)"""
)

# Script: defineProps, defineEmits, defineStore imports
_DEFINE_PROPS_RE = re.compile(
    r"defineProps\s*(?:<([^>]+)>)?\s*\(([^)]*)\)?", re.DOTALL
)
_DEFINE_EMITS_RE = re.compile(
    r"defineEmits\s*(?:<([^>]+)>)?\s*\(([^)]*)\)?", re.DOTALL
)
_IMPORT_RE = re.compile(
    r"""import\s+(?:\{([^}]+)\}|\s*(\w+))\s+from\s+['"]([^'"]+)['"]"""
)

# HTML tags to skip (not components)
_HTML_TAGS = frozenset({
    "div", "span", "p", "a", "img", "ul", "ol", "li", "h1", "h2", "h3",
    "h4", "h5", "h6", "table", "tr", "td", "th", "thead", "tbody", "form",
    "input", "button", "select", "option", "textarea", "label", "section",
    "article", "header", "footer", "nav", "main", "aside", "template",
    "slot", "component", "transition", "keep-alive", "teleport", "suspense",
    "br", "hr", "pre", "code", "strong", "em", "b", "i", "small", "sub",
    "sup", "mark", "del", "ins", "blockquote", "figure", "figcaption",
    "details", "summary", "dialog", "svg", "path", "circle", "rect",
    "line", "polyline", "polygon", "text", "g", "defs", "use", "symbol",
    "video", "audio", "source", "canvas", "iframe",
})


def _kebab_to_pascal(name: str) -> str:
    """Convert kebab-case to PascalCase: my-component → MyComponent."""
    return "".join(part.capitalize() for part in name.split("-"))


class VueParser(BaseParser):
    """Parser for Vue Single File Components (.vue files)."""

    def extensions(self) -> frozenset[str]:
        return frozenset({".vue"})

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        """Parse a .vue file into nodes and edges."""
        rel_path = str(path.relative_to(repo_root)).replace("\\", "/")
        try:
            source = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, IOError):
            return ParsedFile(
                path=rel_path,
                content_hash="",
                nodes=[],
                edges=[],
                line_count=0,
            )

        content_hash = hashlib.sha256(source.encode("utf-8", errors="replace")).hexdigest()[:16]
        line_count = source.count("\n") + 1

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []

        # File-level node
        file_id = f"{rel_path}::__module__"
        nodes.append(ParsedNode(
            id=file_id,
            name=path.stem,
            qualified_name="__module__",
            type="file",
            file_path=rel_path,
            line_start=1,
            line_end=line_count,
            is_exported=False,
        ))

        # Component name from filename (PascalCase)
        component_name = _kebab_to_pascal(path.stem) if "-" in path.stem else path.stem
        # Ensure PascalCase
        if component_name and component_name[0].islower():
            component_name = component_name[0].upper() + component_name[1:]

        component_id = f"{rel_path}::{component_name}"

        # Extract SFC blocks
        template_source = ""
        template_match = _TEMPLATE_RE.search(source)
        if template_match:
            template_source = template_match.group(1)

        script_source = ""
        is_setup = False
        is_ts = False
        script_match = _SCRIPT_RE.search(source)
        if script_match:
            script_source = script_match.group("body")
            attrs = script_match.group("attrs")
            is_setup = bool(_SCRIPT_SETUP_RE.search(attrs))
            is_ts = bool(_SCRIPT_LANG_TS_RE.search(attrs))

        # Build component node
        decorators = ["vue_sfc"]
        if is_setup:
            decorators.append("script_setup")
        if is_ts:
            decorators.append("typescript")

        # Build fingerprint
        fingerprint_parts = ["component"]
        children_rendered: list[str] = []
        props_passed: list[str] = []
        events_handled: list[str] = []
        directives_used: set[str] = set()
        slots_used: list[str] = []

        # Parse template
        if template_source:
            # Component references
            for match in _COMPONENT_REF_RE.finditer(template_source):
                name = match.group(1)
                # PascalCase names (starting uppercase) are Vue components by
                # convention, even when they share a name with an HTML tag
                # (e.g. `<Header>` the component vs `<header>` the element).
                is_pascal = name[:1].isupper()
                if is_pascal or name.lower() not in _HTML_TAGS:
                    children_rendered.append(name)
                    line = source[:source.find(match.group(0))].count("\n") + 1
                    edges.append(ParsedEdge(
                        source=component_id,
                        target=name,
                        type="RENDERS",
                        file_path=rel_path,
                        line=line,
                    ))

            # Kebab-case component references
            for match in _KEBAB_COMPONENT_RE.finditer(template_source):
                kebab_name = match.group(1)
                if kebab_name not in _HTML_TAGS and "-" in kebab_name:
                    pascal_name = _kebab_to_pascal(kebab_name)
                    if pascal_name not in children_rendered:
                        children_rendered.append(pascal_name)
                        line = source[:source.find(match.group(0))].count("\n") + 1
                        edges.append(ParsedEdge(
                            source=component_id,
                            target=pascal_name,
                            type="RENDERS",
                            file_path=rel_path,
                            line=line,
                        ))

            # Prop bindings
            for match in _PROP_BINDING_RE.finditer(template_source):
                prop_name = match.group(1)
                if prop_name not in ("key", "class", "style", "id"):
                    props_passed.append(prop_name)

            # Event handlers
            for match in _EVENT_HANDLER_RE.finditer(template_source):
                event_name = match.group(1)
                handler = match.group(2)
                events_handled.append(event_name)
                # Create CALLS edge for the handler
                edges.append(ParsedEdge(
                    source=component_id,
                    target=handler.split("(")[0].strip(),
                    type="CALLS",
                    file_path=rel_path,
                    line=1,
                ))

            # Directives
            for match in _DIRECTIVE_RE.finditer(template_source):
                directives_used.add(match.group(1))

            # Slots
            for match in _SLOT_RE.finditer(template_source):
                slots_used.append(match.group(1))

        # Parse script block
        props_from_script: list[str] = []
        emits_from_script: list[str] = []

        if script_source:
            # Imports
            for match in _IMPORT_RE.finditer(script_source):
                named = match.group(1)
                default = match.group(2)
                module = match.group(3)
                line_in_script = script_source[:match.start()].count("\n") + 1

                if named:
                    for name in named.split(","):
                        name = name.strip().split(" as ")[0].strip()
                        if name:
                            edges.append(ParsedEdge(
                                source=component_id,
                                target=name,
                                type="IMPORTS",
                                file_path=rel_path,
                                line=line_in_script,
                            ))
                if default:
                    edges.append(ParsedEdge(
                        source=component_id,
                        target=default,
                        type="IMPORTS",
                        file_path=rel_path,
                        line=line_in_script,
                    ))

            # defineProps
            for match in _DEFINE_PROPS_RE.finditer(script_source):
                type_params = match.group(1) or ""
                runtime_args = match.group(2) or ""
                # Extract prop names from type or runtime
                for prop_match in re.finditer(r"(\w+)\s*[?:,]", type_params + runtime_args):
                    props_from_script.append(prop_match.group(1))

            # defineEmits
            for match in _DEFINE_EMITS_RE.finditer(script_source):
                type_params = match.group(1) or ""
                runtime_args = match.group(2) or ""
                for emit_match in re.finditer(r"['\"](\w+)['\"]", runtime_args):
                    emits_from_script.append(emit_match.group(1))
                for emit_match in re.finditer(r"\(\s*e\s*:\s*['\"](\w+)['\"]", type_params):
                    emits_from_script.append(emit_match.group(1))

        # Build fingerprint
        if children_rendered:
            fingerprint_parts.append(f"renders:{len(children_rendered)}")
        all_props = list(set(props_passed + props_from_script))
        if all_props:
            fingerprint_parts.append(f"props:{len(all_props)}")
        if events_handled:
            fingerprint_parts.append(f"events:{len(events_handled)}")
        if directives_used:
            fingerprint_parts.append(f"directives:{','.join(sorted(directives_used))}")
        if slots_used:
            fingerprint_parts.append(f"slots:{','.join(slots_used)}")

        # Build signature from props
        sig_parts = []
        for p in all_props[:10]:
            sig_parts.append(f"{p}: any")
        signature = f"(props: {{{', '.join(sig_parts)}}})" if sig_parts else "()"

        # Create component node
        nodes.append(ParsedNode(
            id=component_id,
            name=component_name,
            qualified_name=component_name,
            type="component",
            file_path=rel_path,
            line_start=1,
            line_end=line_count,
            signature=signature,
            decorators=decorators,
            is_exported=True,
            summary="|".join(fingerprint_parts),
        ))

        # CONTAINS edge: file → component
        edges.append(ParsedEdge(
            source=file_id,
            target=component_id,
            type="CONTAINS",
            file_path=rel_path,
            line=1,
        ))

        # Add PASSES_PROP edges for each prop binding found in template
        for child in children_rendered:
            for prop in props_passed[:20]:  # cap
                edges.append(ParsedEdge(
                    source=component_id,
                    target=child,
                    type="PASSES_PROP",
                    file_path=rel_path,
                    line=1,
                ))
                break  # One PASSES_PROP per child (they're already tracked)

        return ParsedFile(
            path=rel_path,
            content_hash=content_hash,
            nodes=nodes,
            edges=edges,
            line_count=line_count,
        )
